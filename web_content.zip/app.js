(function () {
  'use strict';

  // Self-contained VDOM + Hooks runtime (zero external CDN or ES module dependencies; 100% offline file:// compatible)
  var PROVIDER_SENTINEL = { __isProvider: true };
  var hooks = [];
  var hookCursor = 0;
  var pendingEffects = [];
  var renderScheduled = false;
  var rootContainer = null;
  var rootDom = null;
  var prevRootVNode = null;
  var rootComponent = null;

  function depsChanged(oldDeps, newDeps) {
    if (!oldDeps || !newDeps || oldDeps.length !== newDeps.length) return true;
    for (var i = 0; i < newDeps.length; i++) {
      if (oldDeps[i] !== newDeps[i]) return true;
    }
    return false;
  }

  function flattenChildren(rawList, out) {
    for (var i = 0; i < rawList.length; i++) {
      var item = rawList[i];
      if (Array.isArray(item)) {
        flattenChildren(item, out);
      } else if (item === null || item === undefined || typeof item === 'boolean') {
        out.push({ type: '#comment', props: null, children: [] });
      } else if (typeof item === 'string' || typeof item === 'number') {
        out.push({ type: '#text', text: String(item), props: null, children: [] });
      } else {
        out.push(item);
      }
    }
  }

  function h(type, props) {
    var rawChildren = [];
    for (var i = 2; i < arguments.length; i++) {
      rawChildren.push(arguments[i]);
    }
    var children = [];
    flattenChildren(rawChildren, children);
    if (type && type.__isProvider) {
      return children.length === 1 ? children[0] : h('div', null, children);
    }
    return {
      type: type,
      props: props || {},
      children: children
    };
  }

  function bindDelegatedEvent(el, domEvent, handler) {
    if (!el.__handlers) el.__handlers = {};
    if (!el.__boundEvents) el.__boundEvents = {};
    el.__handlers[domEvent] = handler;
    if (!el.__boundEvents[domEvent]) {
      el.__boundEvents[domEvent] = true;
      el.addEventListener(domEvent, function (ev) {
        var fn = el.__handlers && el.__handlers[domEvent];
        if (typeof fn === 'function') fn(ev);
      });
    }
  }

  function applyProps(el, oldProps, newProps) {
    var k;
    oldProps = oldProps || {};
    newProps = newProps || {};

    if (newProps.type && oldProps.type !== newProps.type) {
      el.setAttribute('type', newProps.type);
    }

    for (k in oldProps) {
      if (k === 'key' || k in newProps) continue;
      if (k === 'className') {
        el.className = '';
      } else if (k === 'style') {
        el.removeAttribute('style');
      } else if (k === 'onClick' && el.__handlers) {
        el.__handlers.click = null;
      } else if (k === 'onChange' && el.__handlers) {
        el.__handlers.input = null;
        el.__handlers.change = null;
      } else {
        el.removeAttribute(k);
      }
    }

    for (k in newProps) {
      if (k === 'key' || k === 'type') continue;
      var val = newProps[k];
      if (k === 'className') {
        var cls = val || '';
        if (el.className !== cls) el.className = cls;
      } else if (k === 'style') {
        var prevStyle = oldProps.style || {};
        var sk;
        for (sk in prevStyle) {
          if (!val || !(sk in val)) el.style[sk] = '';
        }
        if (val) {
          for (sk in val) {
            if (prevStyle[sk] !== val[sk]) el.style[sk] = val[sk];
          }
        }
      } else if (k === 'checked') {
        el.checked = !!val;
      } else if (k === 'value') {
        var strVal = val === null || val === undefined ? '' : String(val);
        if (el.value !== strVal) el.value = strVal;
      } else if (k === 'onClick') {
        bindDelegatedEvent(el, 'click', val);
      } else if (k === 'onChange') {
        var tag = el.tagName;
        var inpType = (newProps.type || '').toLowerCase();
        var useInputEv =
          tag === 'TEXTAREA' ||
          (tag === 'INPUT' && inpType !== 'checkbox' && inpType !== 'radio');
        bindDelegatedEvent(el, useInputEv ? 'input' : 'change', val);
      } else if (oldProps[k] !== val) {
        if (val === false || val === null || val === undefined) {
          el.removeAttribute(k);
        } else {
          el.setAttribute(k, String(val));
        }
      }
    }
  }

  function createDom(vnode) {
    if (vnode.type === '#comment') return document.createComment('');
    if (vnode.type === '#text') return document.createTextNode(vnode.text);
    var el = document.createElement(vnode.type);
    for (var i = 0; i < vnode.children.length; i++) {
      el.appendChild(createDom(vnode.children[i]));
    }
    applyProps(el, {}, vnode.props);
    return el;
  }

  function patchDom(parent, domNode, oldVNode, newVNode) {
    if (!oldVNode && newVNode) {
      var created = createDom(newVNode);
      parent.appendChild(created);
      return created;
    }
    if (oldVNode && !newVNode) {
      if (domNode && domNode.parentNode === parent) parent.removeChild(domNode);
      return null;
    }
    if (!oldVNode && !newVNode) return null;

    if (oldVNode.type !== newVNode.type) {
      var replacement = createDom(newVNode);
      parent.replaceChild(replacement, domNode);
      return replacement;
    }
    if (newVNode.type === '#comment') return domNode;
    if (newVNode.type === '#text') {
      if (domNode.nodeValue !== newVNode.text) domNode.nodeValue = newVNode.text;
      return domNode;
    }

    var childNodesSnap = Array.prototype.slice.call(domNode.childNodes);
    var maxLen = Math.max(oldVNode.children.length, newVNode.children.length);
    for (var i = 0; i < maxLen; i++) {
      patchDom(domNode, childNodesSnap[i], oldVNode.children[i], newVNode.children[i]);
    }
    applyProps(domNode, oldVNode.props, newVNode.props);
    return domNode;
  }

  function flushRender() {
    renderScheduled = false;
    if (!rootContainer || !rootComponent) return;
    hookCursor = 0;
    pendingEffects = [];
    var nextVNode = rootComponent();
    rootDom = patchDom(rootContainer, rootDom, prevRootVNode, nextVNode);
    prevRootVNode = nextVNode;
    var effectsToRun = pendingEffects.slice();
    pendingEffects = [];
    for (var i = 0; i < effectsToRun.length; i++) {
      var slot = effectsToRun[i];
      if (typeof slot.cleanup === 'function') slot.cleanup();
      var cleanup = slot.effect();
      slot.cleanup = typeof cleanup === 'function' ? cleanup : null;
    }
  }

  function scheduleRender() {
    if (renderScheduled) return;
    renderScheduled = true;
    Promise.resolve().then(flushRender);
  }

  function useState(initial) {
    var idx = hookCursor++;
    if (idx >= hooks.length) {
      hooks[idx] = typeof initial === 'function' ? initial() : initial;
    }
    var setState = function (updater) {
      var nextVal = typeof updater === 'function' ? updater(hooks[idx]) : updater;
      if (nextVal !== hooks[idx]) {
        hooks[idx] = nextVal;
        scheduleRender();
      }
    };
    return [hooks[idx], setState];
  }

  function useMemo(factory, deps) {
    var idx = hookCursor++;
    var prev = hooks[idx];
    if (!prev || depsChanged(prev.deps, deps)) {
      var val = factory();
      hooks[idx] = { value: val, deps: deps };
      return val;
    }
    return prev.value;
  }

  function useEffect(effect, deps) {
    var idx = hookCursor++;
    var prev = hooks[idx];
    if (!prev || depsChanged(prev.deps, deps)) {
      var slot = { effect: effect, deps: deps, cleanup: prev ? prev.cleanup : null };
      hooks[idx] = slot;
      pendingEffects.push(slot);
    }
  }

  function createContext() {
    return { Provider: PROVIDER_SENTINEL };
  }

  // Pure-JS PKZIP (STORE + CRC32) builder for 100% offline ZIP creation
  var CRC_TABLE = (function () {
    var tbl = new Uint32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) {
        c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      tbl[n] = c >>> 0;
    }
    return tbl;
  })();

  function crc32Bytes(bytes) {
    var crc = 0xffffffff;
    for (var i = 0; i < bytes.length; i++) {
      crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function encodeUtf8(str) {
    if (window.TextEncoder) return new TextEncoder().encode(str);
    var arr = [];
    for (var i = 0; i < str.length; i++) arr.push(str.charCodeAt(i) & 0xff);
    return new Uint8Array(arr);
  }

  function buildOfflineZipBlob(entries) {
    var localParts = [];
    var centralParts = [];
    var offset = 0;

    for (var i = 0; i < entries.length; i++) {
      var nameBytes = encodeUtf8(entries[i].name);
      var dataBytes = encodeUtf8(entries[i].content || '');
      var crc = crc32Bytes(dataBytes);

      var localHdr = new Uint8Array(30 + nameBytes.length);
      var lv = new DataView(localHdr.buffer);
      lv.setUint32(0, 0x04034b50, true);
      lv.setUint16(4, 20, true);
      lv.setUint32(14, crc, true);
      lv.setUint32(18, dataBytes.length, true);
      lv.setUint32(22, dataBytes.length, true);
      lv.setUint16(26, nameBytes.length, true);
      localHdr.set(nameBytes, 30);

      var centralHdr = new Uint8Array(46 + nameBytes.length);
      var cv = new DataView(centralHdr.buffer);
      cv.setUint32(0, 0x02014b50, true);
      cv.setUint16(4, 20, true);
      cv.setUint16(6, 20, true);
      cv.setUint32(16, crc, true);
      cv.setUint32(20, dataBytes.length, true);
      cv.setUint32(24, dataBytes.length, true);
      cv.setUint16(28, nameBytes.length, true);
      cv.setUint32(42, offset, true);
      centralHdr.set(nameBytes, 46);

      localParts.push(localHdr, dataBytes);
      centralParts.push(centralHdr);
      offset += localHdr.length + dataBytes.length;
    }

    var centralSize = 0;
    for (var j = 0; j < centralParts.length; j++) centralSize += centralParts[j].length;

    var eocd = new Uint8Array(22);
    var ev = new DataView(eocd.buffer);
    ev.setUint32(0, 0x06054b50, true);
    ev.setUint16(8, entries.length, true);
    ev.setUint16(10, entries.length, true);
    ev.setUint32(12, centralSize, true);
    ev.setUint32(16, offset, true);

    return new Blob(localParts.concat(centralParts, [eocd]), { type: 'application/zip' });
  }

  // Safe localStorage wrapper (handles restricted file:// WebView storage policies gracefully)
  var safeStorage = {
    get: function (key, fallback) {
      try {
        var val = window.localStorage.getItem(key);
        return val !== null ? val : fallback;
      } catch (e) {
        return fallback;
      }
    },
    set: function (key, value) {
      try {
        window.localStorage.setItem(key, value);
      } catch (e) {
        // Ignore quota or file:// WebView restriction errors
      }
    }
  };

  // Decimal SI byte formatting matching Samsung One UI (1 GB = 1,000,000,000 bytes)
  function formatDecimalBytes(bytes) {
    var b = Math.max(0, Number(bytes) || 0);
    if (b >= 1000000000) return (b / 1000000000).toFixed(1) + ' GB';
    if (b >= 1000000) return (b / 1000000).toFixed(1) + ' MB';
    if (b >= 1000) return (b / 1000).toFixed(1) + ' KB';
    return b + ' B';
  }

  var ACCENTS = [
    { id: 'blue', label: 'Blue', hex: '#0381fe' },
    { id: 'teal', label: 'Teal', hex: '#00a896' },
    { id: 'green', label: 'Green', hex: '#2b9348' },
    { id: 'purple', label: 'Purple', hex: '#7b2cbf' },
    { id: 'pink', label: 'Pink', hex: '#e01e5a' },
    { id: 'red', label: 'Red', hex: '#d90429' },
    { id: 'orange', label: 'Orange', hex: '#f77f00' },
    { id: 'amber', label: 'Amber', hex: '#ffb703' }
  ];

  var INITIAL_TREE = {
    '/Internal storage': [
      { name: 'DCIM', isDir: true, modified: 'Oct 27, 2026', items: 2 },
      { name: 'Download', isDir: true, modified: 'Oct 27, 2026', items: 4 },
      { name: 'Documents', isDir: true, modified: 'Oct 26, 2026', items: 3 },
      { name: 'Pictures', isDir: true, modified: 'Oct 25, 2026', items: 2 },
      { name: 'Music', isDir: true, modified: 'Oct 21, 2026', items: 2 },
      { name: 'Movies', isDir: true, modified: 'Oct 20, 2026', items: 1 },
      { name: 'Android', isDir: true, modified: 'Oct 18, 2026', items: 1 }
    ],
    '/Internal storage/DCIM': [
      { name: 'Camera_Sunset_4K.jpg', isDir: false, size: 4820000, kind: 'image', modified: 'Oct 27, 2026' },
      { name: 'Galaxy_Clip_1080p.mp4', isDir: false, size: 28400000, kind: 'video', modified: 'Oct 27, 2026' }
    ],
    '/Internal storage/Download': [
      {
        name: 'GalaxyCompanion_v2.4.apk',
        isDir: false,
        size: 34200000,
        kind: 'apk',
        pkg: 'com.galaxy.companion',
        ver: '2.4.0 (240)',
        modified: 'Oct 27, 2026'
      },
      { name: 'DesktopSetup.exe', isDir: false, size: 19500000, kind: 'exe', modified: 'Oct 25, 2026' },
      {
        name: 'invoice_scan.jpg.exe',
        isDir: false,
        size: 1240000,
        kind: 'exe',
        doubleExt: true,
        modified: 'Oct 24, 2026'
      },
      { name: 'ProjectAssets.zip', isDir: false, size: 12600000, kind: 'zip', modified: 'Oct 23, 2026' }
    ],
    '/Internal storage/Documents': [
      { name: 'Q4_Architecture_Spec.pdf', isDir: false, size: 2450000, kind: 'pdf', modified: 'Oct 26, 2026' },
      { name: 'Budget_2026.xlsx', isDir: false, size: 640000, kind: 'sheet', modified: 'Oct 22, 2026' },
      {
        name: 'Release_Notes.txt',
        isDir: false,
        size: 14200,
        kind: 'text',
        content:
          'Galaxy My Files — One UI Release Notes\n- StorageProvider Adapter\n- Magic Byte & APK Inspector\n- USB OTG & Safe Eject\n- Gemini AI Suite',
        modified: 'Oct 27, 2026'
      }
    ],
    '/Internal storage/Pictures': [
      { name: 'Wallpaper_OneUI7.png', isDir: false, size: 3900000, kind: 'image', modified: 'Oct 25, 2026' },
      { name: 'Portrait_Studio.jpg', isDir: false, size: 2750000, kind: 'image', modified: 'Oct 23, 2026' }
    ],
    '/Internal storage/Music': [
      { name: 'Over_The_Horizon_2026.flac', isDir: false, size: 24100000, kind: 'audio', modified: 'Oct 21, 2026' },
      { name: 'Voice_Memo_01.m4a', isDir: false, size: 1850000, kind: 'audio', modified: 'Oct 19, 2026' }
    ],
    '/Internal storage/Movies': [
      { name: 'Travel_Highlight_Reel.mp4', isDir: false, size: 84500000, kind: 'video', modified: 'Oct 20, 2026' }
    ],
    '/Internal storage/Android': [{ name: 'data', isDir: true, modified: 'Oct 18, 2026', items: 0 }],
    '/Internal storage/Android/data': [],
    '/USB SanDisk Ultra': [
      { name: 'Backups', isDir: true, modified: 'Oct 15, 2026', items: 1 },
      { name: 'Portable_Archive.zip', isDir: false, size: 46000000, kind: 'zip', modified: 'Oct 15, 2026' }
    ],
    '/USB SanDisk Ultra/Backups': [
      { name: 'Photos_2025.zip', isDir: false, size: 512000000, kind: 'zip', modified: 'Oct 10, 2026' }
    ]
  };

  var AnimationContext = createContext({ mode: 'medium', setMode: function () {} });

  function iconBadgeForItem(item) {
    if (item.isDir) return { icon: '\uD83D\uDCC1', badge: null, warn: false };
    if (item.doubleExt) return { icon: '\u26A0\uFE0F', badge: 'Suspicious double ext', warn: true };
    switch (item.kind) {
      case 'apk':
        return { icon: '\uD83E\uDD16', badge: 'Installation file', warn: false };
      case 'exe':
        return { icon: '\uD83E\uDE9F', badge: 'Cannot run on Android', warn: true };
      case 'zip':
        return { icon: '\uD83D\uDDDC\uFE0F', badge: 'ZIP Archive', warn: false };
      case 'pdf':
        return { icon: '\uD83D\uDCD5', badge: 'PDF', warn: false };
      case 'image':
        return { icon: '\uD83D\uDDBC\uFE0F', badge: null, warn: false };
      case 'video':
        return { icon: '\uD83C\uDFAC', badge: null, warn: false };
      case 'audio':
        return { icon: '\uD83C\uDFB5', badge: null, warn: false };
      default:
        return { icon: '\uD83D\uDCC4', badge: null, warn: false };
    }
  }

  function App() {
    var _screen = useState('home');
    var screen = _screen[0];
    var setScreen = _screen[1];

    var _tree = useState(INITIAL_TREE);
    var tree = _tree[0];
    var setTree = _tree[1];

    var _currentPath = useState('/Internal storage');
    var currentPath = _currentPath[0];
    var setCurrentPath = _currentPath[1];

    var _selected = useState([]);
    var selected = _selected[0];
    var setSelected = _selected[1];

    var _trash = useState([]);
    var trash = _trash[0];
    var setTrash = _trash[1];

    var _searchQuery = useState('');
    var searchQuery = _searchQuery[0];
    var setSearchQuery = _searchQuery[1];

    var _theme = useState(function () {
      return safeStorage.get('mf_theme', 'dark');
    });
    var theme = _theme[0];
    var setTheme = _theme[1];

    var _amoled = useState(function () {
      return safeStorage.get('mf_amoled', 'false') === 'true';
    });
    var amoled = _amoled[0];
    var setAmoled = _amoled[1];

    var _accent = useState(function () {
      return safeStorage.get('mf_accent', '#0381fe');
    });
    var accent = _accent[0];
    var setAccent = _accent[1];

    var _animMode = useState(function () {
      return safeStorage.get('mf_anim', 'medium');
    });
    var animMode = _animMode[0];
    var setAnimMode = _animMode[1];

    var _usbConnected = useState(true);
    var usbConnected = _usbConnected[0];
    var setUsbConnected = _usbConnected[1];

    var _usbFs = useState('exFAT');
    var usbFs = _usbFs[0];
    var setUsbFs = _usbFs[1];

    var _storageEst = useState({ used: 52300000000, total: 128000000000 });
    var storageEstimate = _storageEst[0];
    var setStorageEstimate = _storageEst[1];

    var _activeModal = useState(null);
    var activeModal = _activeModal[0];
    var setActiveModal = _activeModal[1];

    var _toast = useState(null);
    var toast = _toast[0];
    var setToast = _toast[1];

    function showToast(msg) {
      setToast(msg);
      setTimeout(function () {
        setToast(null);
      }, 2800);
    }

    useEffect(
      function () {
        var rootEl = document.documentElement;
        var sysDark =
          window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        var isDark = theme === 'dark' || (theme === 'system' && sysDark);
        if (isDark) rootEl.classList.add('dark');
        else rootEl.classList.remove('dark');

        if (isDark && amoled) rootEl.classList.add('amoled');
        else rootEl.classList.remove('amoled');

        rootEl.style.setProperty('--accent', accent);
        rootEl.style.setProperty('--accent-soft', accent + '24');
        rootEl.style.setProperty(
          '--anim-ms',
          animMode === 'off' ? '0ms' : animMode === 'high' ? '280ms' : '190ms'
        );

        safeStorage.set('mf_theme', theme);
        safeStorage.set('mf_amoled', String(amoled));
        safeStorage.set('mf_accent', accent);
        safeStorage.set('mf_anim', animMode);
      },
      [theme, amoled, accent, animMode]
    );

    useEffect(function () {
      if (navigator.storage && navigator.storage.estimate) {
        navigator.storage
          .estimate()
          .then(function (est) {
            if (est && est.quota && est.quota > 0) {
              setStorageEstimate({
                used: est.usage || 52300000000,
                total: est.quota
              });
            }
          })
          .catch(function () {});
      }
    }, []);

    function mountRealBrowserDirectory() {
      if (!window.showDirectoryPicker) {
        showToast('Directory picker requires HTTPS or native SAF wrapper — using workspace adapter.');
        return;
      }
      window
        .showDirectoryPicker()
        .then(async function (dirHandle) {
          var entries = [];
          for await (var entry of dirHandle.entries()) {
            var name = entry[0];
            var handle = entry[1];
            if (handle.kind === 'directory') {
              entries.push({ name: name, isDir: true, modified: 'Mounted Folder', items: 0 });
            } else {
              var file = await handle.getFile();
              var parts = name.split('.');
              var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase() : '';
              var kind =
                ['jpg', 'jpeg', 'png', 'webp', 'gif'].indexOf(ext) !== -1
                  ? 'image'
                  : ['mp4', 'webm', 'mov'].indexOf(ext) !== -1
                  ? 'video'
                  : ['mp3', 'wav', 'flac', 'm4a'].indexOf(ext) !== -1
                  ? 'audio'
                  : ext === 'pdf'
                  ? 'pdf'
                  : ext === 'apk'
                  ? 'apk'
                  : ext === 'zip'
                  ? 'zip'
                  : 'file';
              entries.push({
                name: name,
                isDir: false,
                size: file.size,
                kind: kind,
                modified: new Date(file.lastModified).toLocaleDateString()
              });
            }
          }
          var mountPath = '/Mounted: ' + dirHandle.name;
          setTree(function (prev) {
            var copy = Object.assign({}, prev);
            copy[mountPath] = entries;
            return copy;
          });
          setCurrentPath(mountPath);
          setScreen('browser');
          showToast('Mounted "' + dirHandle.name + '" (' + entries.length + ' items)');
        })
        .catch(function (err) {
          if (err && err.name !== 'AbortError') showToast('Folder access denied.');
        });
    }

    var currentItems = useMemo(
      function () {
        var list = tree[currentPath] || [];
        return list.slice().sort(function (a, b) {
          if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
          return a.name.localeCompare(b.name);
        });
      },
      [tree, currentPath]
    );

    var allFiles = useMemo(
      function () {
        var acc = [];
        Object.keys(tree).forEach(function (folder) {
          (tree[folder] || []).forEach(function (it) {
            if (!it.isDir) {
              acc.push(Object.assign({}, it, { folder: folder }));
            }
          });
        });
        return acc;
      },
      [tree]
    );

    function openPath(path) {
      setSelected([]);
      setCurrentPath(path);
      setScreen('browser');
    }

    function navigateUp() {
      var parts = currentPath.split('/').filter(Boolean);
      if (parts.length <= 1) {
        setScreen('home');
      } else {
        parts.pop();
        setCurrentPath('/' + parts.join('/'));
      }
    }

    function createFolder() {
      var name = window.prompt('New folder name:');
      if (!name || !name.trim()) return;
      var clean = name.trim();
      var newSubPath = currentPath + '/' + clean;
      setTree(function (prev) {
        var copy = Object.assign({}, prev);
        copy[currentPath] = (prev[currentPath] || []).concat([
          { name: clean, isDir: true, modified: 'Just now', items: 0 }
        ]);
        copy[newSubPath] = [];
        return copy;
      });
      showToast('Created folder "' + clean + '"');
    }

    function deleteSelectedToTrash() {
      if (!selected.length) return;
      var list = tree[currentPath] || [];
      var remaining = list.filter(function (it) {
        return selected.indexOf(it.name) === -1;
      });
      var removed = list
        .filter(function (it) {
          return selected.indexOf(it.name) !== -1;
        })
        .map(function (it) {
          return Object.assign({}, it, {
            originalPath: currentPath,
            deletedAt: new Date().toLocaleTimeString()
          });
        });

      setTree(function (prev) {
        var copy = Object.assign({}, prev);
        copy[currentPath] = remaining;
        return copy;
      });
      setTrash(function (prev) {
        return removed.concat(prev);
      });
      setSelected([]);
      showToast('Moved ' + removed.length + ' item(s) to Trash');
    }

    function compressSelectedZip() {
      if (!selected.length) return;
      var zipName = 'Archive_' + String(Date.now()).slice(-4) + '.zip';
      var list = tree[currentPath] || [];
      var zipEntries = selected.map(function (name) {
        var found = null;
        for (var i = 0; i < list.length; i++) {
          if (list[i].name === name) found = list[i];
        }
        return {
          name: name,
          content:
            (found && found.content) ||
            'Archived from ' + currentPath + '/' + name
        };
      });
      var blob = buildOfflineZipBlob(zipEntries);
      setTree(function (prev) {
        var copy = Object.assign({}, prev);
        copy[currentPath] = (prev[currentPath] || []).concat([
          {
            name: zipName,
            isDir: false,
            size: (blob && blob.size) || 2048,
            kind: 'zip',
            modified: 'Just now'
          }
        ]);
        return copy;
      });
      setSelected([]);
      showToast('Compressed to ' + zipName + ' (' + formatDecimalBytes(blob.size) + ')');
    }

    var categories = [
      {
        label: 'Images',
        icon: '\uD83D\uDDBC\uFE0F',
        filter: function (f) {
          return f.kind === 'image';
        }
      },
      {
        label: 'Videos',
        icon: '\uD83C\uDFAC',
        filter: function (f) {
          return f.kind === 'video';
        }
      },
      {
        label: 'Audio',
        icon: '\uD83C\uDFB5',
        filter: function (f) {
          return f.kind === 'audio';
        }
      },
      {
        label: 'Documents',
        icon: '\uD83D\uDCC4',
        filter: function (f) {
          return ['pdf', 'sheet', 'text'].indexOf(f.kind) !== -1;
        }
      },
      {
        label: 'Downloads',
        icon: '\u2B07\uFE0F',
        filter: function (f) {
          return f.folder.indexOf('Download') !== -1;
        }
      },
      {
        label: 'Installation files',
        icon: '\uD83E\uDD16',
        filter: function (f) {
          return ['apk', 'exe'].indexOf(f.kind) !== -1;
        }
      },
      {
        label: 'Compressed',
        icon: '\uD83D\uDDDC\uFE0F',
        filter: function (f) {
          return f.kind === 'zip';
        }
      }
    ];

    var wrapperClass =
      'app-shell ' + (animMode === 'high' ? 'anim-high' : animMode === 'off' ? 'anim-off' : '');

    var titleText =
      screen === 'home'
        ? 'My Files'
        : screen === 'browser'
        ? currentPath.split('/').pop()
        : screen.charAt(0).toUpperCase() + screen.slice(1);

    var usedPct = Math.min(
      100,
      Math.round((storageEstimate.used / Math.max(1, storageEstimate.total)) * 100)
    );

    return h(
      AnimationContext.Provider,
      { value: { mode: animMode, setMode: setAnimMode } },
      h(
        'div',
        { className: wrapperClass },
        // Top Header
        h(
          'header',
          { className: 'top-header' },
          h(
            'div',
            { className: 'row-gap' },
            screen !== 'home'
              ? h(
                  'button',
                  {
                    className: 'icon-btn',
                    onClick: function () {
                      if (screen === 'browser') navigateUp();
                      else setScreen('home');
                    },
                    'aria-label': 'Back'
                  },
                  '\u2190'
                )
              : null,
            h(
              'div',
              null,
              h('h1', { className: 'main-title' }, titleText),
              h(
                'p',
                { className: 'sub-caption' },
                screen === 'home' ? 'One UI \u2022 Mobile File Manager' : currentPath
              )
            )
          ),
          h(
            'div',
            { className: 'row-gap' },
            h(
              'button',
              {
                className: 'pill-btn',
                style: { backgroundColor: accent, color: '#ffffff' },
                onClick: mountRealBrowserDirectory
              },
              '+ Mount Folder'
            ),
            h(
              'button',
              {
                className: 'icon-btn',
                onClick: function () {
                  setScreen('settings');
                },
                title: 'Settings'
              },
              '\u2699\uFE0F'
            )
          )
        ),

        // Search Bar on Home
        screen === 'home'
          ? h(
              'div',
              { className: 'section-block' },
              h('input', {
                type: 'search',
                value: searchQuery,
                onChange: function (e) {
                  setSearchQuery(e.target.value);
                },
                placeholder: 'Search files or types (e.g. apk, pdf, video)...',
                className: 'search-input'
              }),
              searchQuery.trim()
                ? h(
                    'div',
                    { className: 'oneui-card pad-sm mt-sm' },
                    h('div', { className: 'section-label' }, 'Search results'),
                    allFiles
                      .filter(function (f) {
                        var q = searchQuery.toLowerCase();
                        return (
                          f.name.toLowerCase().indexOf(q) !== -1 ||
                          (f.kind && f.kind.indexOf(q) !== -1)
                        );
                      })
                      .map(function (f) {
                        return h(
                          'div',
                          {
                            key: f.folder + '/' + f.name,
                            className: 'list-row',
                            onClick: function () {
                              setActiveModal(f);
                            }
                          },
                          h('span', { className: 'item-title' }, f.name),
                          h('span', { className: 'sub-caption' }, formatDecimalBytes(f.size))
                        );
                      })
                  )
                : null
            )
          : null,

        // HOME SCREEN
        screen === 'home'
          ? h(
              'div',
              { className: 'stack-lg' },
              // Recent files
              h(
                'section',
                null,
                h('h2', { className: 'section-label' }, 'Recent files'),
                h(
                  'div',
                  { className: 'oneui-card recent-strip' },
                  allFiles.slice(0, 6).map(function (file) {
                    var info = iconBadgeForItem(file);
                    return h(
                      'button',
                      {
                        key: file.name,
                        className: 'recent-tile oneui-press',
                        onClick: function () {
                          setActiveModal(file);
                        }
                      },
                      h('div', { className: 'recent-icon' }, info.icon),
                      h('span', { className: 'recent-name' }, file.name),
                      h('span', { className: 'sub-caption' }, formatDecimalBytes(file.size))
                    );
                  })
                )
              ),

              // Categories Grid
              h(
                'section',
                null,
                h('h2', { className: 'section-label' }, 'Categories'),
                h(
                  'div',
                  { className: 'oneui-card cat-grid' },
                  categories.map(function (cat) {
                    var matched = allFiles.filter(cat.filter);
                    var sum = matched.reduce(function (s, x) {
                      return s + (x.size || 0);
                    }, 0);
                    return h(
                      'button',
                      {
                        key: cat.label,
                        className: 'cat-tile oneui-press',
                        onClick: function () {
                          openPath('/Internal storage');
                        }
                      },
                      h('span', { className: 'cat-emoji' }, cat.icon),
                      h(
                        'div',
                        { className: 'cat-meta' },
                        h('div', { className: 'item-title' }, cat.label),
                        h(
                          'div',
                          { className: 'sub-caption' },
                          matched.length + ' \u2022 ' + formatDecimalBytes(sum)
                        )
                      )
                    );
                  })
                )
              ),

              // Storage Section
              h(
                'section',
                null,
                h('h2', { className: 'section-label' }, 'Storage'),
                h(
                  'div',
                  { className: 'oneui-card' },
                  h(
                    'div',
                    {
                      className: 'pad-md clickable-block border-bottom',
                      onClick: function () {
                        openPath('/Internal storage');
                      }
                    },
                    h(
                      'div',
                      { className: 'row-between' },
                      h(
                        'div',
                        { className: 'row-gap' },
                        h('span', null, '\uD83D\uDCF1'),
                        h('span', { className: 'item-title' }, 'Internal storage'),
                        h(
                          'span',
                          {
                            className: 'badge-pill',
                            style: { backgroundColor: 'var(--accent-soft)', color: accent }
                          },
                          'F2FS / OPFS'
                        )
                      ),
                      h(
                        'span',
                        { className: 'sub-caption' },
                        formatDecimalBytes(storageEstimate.used) +
                          ' / ' +
                          formatDecimalBytes(storageEstimate.total)
                      )
                    ),
                    h(
                      'div',
                      { className: 'progress-track' },
                      h('div', {
                        className: 'progress-fill',
                        style: { width: usedPct + '%', backgroundColor: accent }
                      })
                    )
                  ),

                  usbConnected
                    ? h(
                        'div',
                        { className: 'pad-md row-between' },
                        h(
                          'div',
                          {
                            className: 'clickable-flex',
                            onClick: function () {
                              openPath('/USB SanDisk Ultra');
                            }
                          },
                          h(
                            'div',
                            { className: 'row-gap' },
                            h('span', null, '\uD83D\uDD0C'),
                            h('span', { className: 'item-title' }, 'USB SanDisk Ultra'),
                            h(
                              'span',
                              {
                                className: 'badge-pill',
                                style: { backgroundColor: 'var(--accent-soft)', color: accent }
                              },
                              usbFs
                            ),
                            ['NTFS', 'ext4'].indexOf(usbFs) !== -1
                              ? h('span', { className: 'badge-pill warn-pill' }, 'Read-only')
                              : null
                          ),
                          h(
                            'div',
                            { className: 'sub-caption' },
                            '14.2 GB / 64.0 GB \u2022 Tap to browse'
                          )
                        ),
                        h(
                          'div',
                          { className: 'row-gap' },
                          h(
                            'select',
                            {
                              value: usbFs,
                              onChange: function (e) {
                                setUsbFs(e.target.value);
                              },
                              className: 'small-select'
                            },
                            h('option', { value: 'exFAT' }, 'exFAT'),
                            h('option', { value: 'FAT32' }, 'FAT32'),
                            h('option', { value: 'NTFS' }, 'NTFS (RO)'),
                            h('option', { value: 'ext4' }, 'ext4 (RO)')
                          ),
                          h(
                            'button',
                            {
                              className: 'small-btn',
                              onClick: function () {
                                setUsbConnected(false);
                                showToast('Safely ejected USB SanDisk Ultra');
                              }
                            },
                            'Eject'
                          )
                        )
                      )
                    : h(
                        'div',
                        { className: 'pad-md row-between' },
                        h('span', { className: 'sub-caption' }, '\uD83D\uDD0C USB storage safely ejected'),
                        h(
                          'button',
                          {
                            className: 'small-btn',
                            style: { color: accent },
                            onClick: function () {
                              setUsbConnected(true);
                            }
                          },
                          'Reconnect USB'
                        )
                      )
                )
              ),

              // Storage Tools
              h(
                'section',
                null,
                h('h2', { className: 'section-label' }, 'Storage Tools'),
                h(
                  'div',
                  { className: 'oneui-card' },
                  h(
                    'button',
                    {
                      className: 'tool-row border-bottom',
                      onClick: function () {
                        setScreen('trash');
                      }
                    },
                    h(
                      'div',
                      null,
                      h('div', { className: 'item-title' }, '\uD83D\uDDD1\uFE0F Trash'),
                      h(
                        'div',
                        { className: 'sub-caption' },
                        trash.length + ' item(s) \u2022 Auto-empty after 30 days'
                      )
                    ),
                    h('span', null, '\u203A')
                  ),
                  h(
                    'button',
                    {
                      className: 'tool-row',
                      onClick: function () {
                        setScreen('analyze');
                      }
                    },
                    h(
                      'div',
                      null,
                      h('div', { className: 'item-title' }, '\uD83D\uDCCA Analyze storage'),
                      h(
                        'div',
                        { className: 'sub-caption' },
                        'Category breakdown, large files & cleanup'
                      )
                    ),
                    h('span', null, '\u203A')
                  )
                )
              )
            )
          : null,

        // BROWSER SCREEN
        screen === 'browser'
          ? h(
              'div',
              { className: 'stack-md' },
              h(
                'div',
                { className: 'row-between' },
                h('span', { className: 'sub-caption' }, currentItems.length + ' item(s)'),
                h(
                  'div',
                  { className: 'row-gap' },
                  h('button', { className: 'small-btn', onClick: createFolder }, '+ New Folder'),
                  selected.length > 0
                    ? h(
                        'button',
                        { className: 'small-btn', onClick: compressSelectedZip },
                        '\uD83D\uDDDC\uFE0F ZIP (' + selected.length + ')'
                      )
                    : null,
                  selected.length > 0
                    ? h(
                        'button',
                        { className: 'small-btn warn-pill', onClick: deleteSelectedToTrash },
                        '\uD83D\uDDD1\uFE0F Delete'
                      )
                    : null
                )
              ),
              h(
                'div',
                { className: 'oneui-card' },
                currentItems.length === 0
                  ? h('div', { className: 'empty-box' }, 'Folder is empty')
                  : currentItems.map(function (item, idx) {
                      var info = iconBadgeForItem(item);
                      var isSel = selected.indexOf(item.name) !== -1;
                      return h(
                        'div',
                        {
                          key: item.name,
                          className:
                            'file-row ' +
                            (idx < currentItems.length - 1 ? 'border-bottom ' : '') +
                            (isSel ? 'selected-row' : ''),
                          onClick: function () {
                            if (item.isDir) openPath(currentPath + '/' + item.name);
                            else setActiveModal(item);
                          }
                        },
                        h(
                          'div',
                          { className: 'row-gap min-zero' },
                          h('input', {
                            type: 'checkbox',
                            checked: isSel,
                            onClick: function (e) {
                              e.stopPropagation();
                            },
                            onChange: function () {
                              setSelected(function (prev) {
                                return isSel
                                  ? prev.filter(function (x) {
                                      return x !== item.name;
                                    })
                                  : prev.concat([item.name]);
                              });
                            }
                          }),
                          h('span', { className: 'cat-emoji' }, info.icon),
                          h(
                            'div',
                            { className: 'min-zero' },
                            h('div', { className: 'item-title truncate' }, item.name),
                            h(
                              'div',
                              { className: 'row-gap' },
                              h(
                                'span',
                                { className: 'sub-caption' },
                                (item.isDir
                                  ? (item.items || 0) + ' items'
                                  : formatDecimalBytes(item.size)) +
                                  ' \u2022 ' +
                                  item.modified
                              ),
                              info.badge
                                ? h(
                                    'span',
                                    {
                                      className:
                                        'badge-pill ' + (info.warn ? 'warn-pill' : 'info-pill')
                                    },
                                    info.badge
                                  )
                                : null
                            )
                          )
                        ),
                        h('span', { className: 'sub-caption' }, item.isDir ? '\u203A' : '\u24D8')
                      );
                    })
              )
            )
          : null,

        // ANALYZE STORAGE SCREEN
        screen === 'analyze'
          ? h(
              'div',
              { className: 'stack-md' },
              h(
                'div',
                { className: 'oneui-card pad-md' },
                h('div', { className: 'item-title' }, 'Storage Breakdown'),
                h(
                  'div',
                  { className: 'sub-caption mb-sm' },
                  formatDecimalBytes(storageEstimate.used) +
                    ' used of ' +
                    formatDecimalBytes(storageEstimate.total)
                ),
                categories.map(function (cat) {
                  var bytes = allFiles.filter(cat.filter).reduce(function (s, f) {
                    return s + (f.size || 0);
                  }, 0);
                  return h(
                    'div',
                    { key: cat.label, className: 'list-row' },
                    h('span', null, cat.icon + ' ' + cat.label),
                    h('span', { className: 'sub-caption' }, formatDecimalBytes(bytes))
                  );
                })
              ),
              h(
                'div',
                { className: 'oneui-card pad-md' },
                h('div', { className: 'item-title mb-sm' }, 'Large files (> 10 MB)'),
                allFiles
                  .filter(function (f) {
                    return f.size > 10000000;
                  })
                  .map(function (f) {
                    return h(
                      'div',
                      { key: f.name, className: 'list-row' },
                      h('span', { className: 'truncate' }, f.name),
                      h('span', { className: 'sub-caption' }, formatDecimalBytes(f.size))
                    );
                  })
              )
            )
          : null,

        // TRASH SCREEN
        screen === 'trash'
          ? h(
              'div',
              { className: 'oneui-card pad-md' },
              h(
                'div',
                { className: 'row-between mb-sm' },
                h('span', { className: 'item-title' }, 'Recycle Bin (' + trash.length + ')'),
                trash.length > 0
                  ? h(
                      'button',
                      {
                        className: 'small-btn warn-pill',
                        onClick: function () {
                          setTrash([]);
                          showToast('Trash emptied');
                        }
                      },
                      'Empty Trash'
                    )
                  : null
              ),
              trash.length === 0
                ? h('div', { className: 'empty-box' }, 'No items in Trash')
                : trash.map(function (t, idx) {
                    return h(
                      'div',
                      { key: idx, className: 'list-row' },
                      h(
                        'div',
                        null,
                        h('div', { className: 'item-title' }, t.name),
                        h('div', { className: 'sub-caption' }, 'From ' + t.originalPath)
                      ),
                      h(
                        'button',
                        {
                          className: 'pill-btn',
                          style: { backgroundColor: accent, color: '#ffffff' },
                          onClick: function () {
                            setTree(function (prev) {
                              var copy = Object.assign({}, prev);
                              copy[t.originalPath] = (prev[t.originalPath] || []).concat([t]);
                              return copy;
                            });
                            setTrash(function (prev) {
                              return prev.filter(function (_, i) {
                                return i !== idx;
                              });
                            });
                            showToast('Restored ' + t.name);
                          }
                        },
                        'Restore'
                      )
                    );
                  })
            )
          : null,

        // SETTINGS SCREEN
        screen === 'settings'
          ? h(
              'div',
              { className: 'stack-md' },
              h(
                'div',
                { className: 'oneui-card pad-md stack-sm' },
                h('div', { className: 'item-title' }, 'Appearance'),
                h(
                  'div',
                  { className: 'row-gap' },
                  ['light', 'dark', 'system'].map(function (m) {
                    var active = theme === m;
                    return h(
                      'button',
                      {
                        key: m,
                        className: 'small-btn',
                        style: active ? { backgroundColor: accent, color: '#ffffff' } : {},
                        onClick: function () {
                          setTheme(m);
                        }
                      },
                      m.toUpperCase()
                    );
                  })
                ),
                h(
                  'label',
                  { className: 'row-between' },
                  h('span', null, 'AMOLED Pure Black (Dark mode)'),
                  h('input', {
                    type: 'checkbox',
                    checked: amoled,
                    onChange: function (e) {
                      setAmoled(e.target.checked);
                    }
                  })
                ),
                h(
                  'div',
                  null,
                  h('div', { className: 'sub-caption mb-sm' }, 'Accent Palette'),
                  h(
                    'div',
                    { className: 'row-gap wrap-row' },
                    ACCENTS.map(function (a) {
                      return h('button', {
                        key: a.id,
                        className: 'swatch-dot ' + (accent === a.hex ? 'swatch-active' : ''),
                        style: { backgroundColor: a.hex },
                        title: a.label,
                        onClick: function () {
                          setAccent(a.hex);
                        }
                      });
                    })
                  )
                )
              ),
              h(
                'div',
                { className: 'oneui-card pad-md stack-sm' },
                h('div', { className: 'item-title' }, 'Animations'),
                [
                  { id: 'off', label: 'Off \u2014 Instant state changes' },
                  { id: 'medium', label: 'Medium (Default) \u2014 Crisp 190ms transitions' },
                  { id: 'high', label: 'High \u2014 Spring physics & tactile scale' }
                ].map(function (opt) {
                  return h(
                    'label',
                    { key: opt.id, className: 'row-gap clickable-block' },
                    h('input', {
                      type: 'radio',
                      name: 'anim',
                      checked: animMode === opt.id,
                      onChange: function () {
                        setAnimMode(opt.id);
                      }
                    }),
                    h('span', null, opt.label)
                  );
                })
              )
            )
          : null,

        // Inspector Modal
        activeModal
          ? h(
              'div',
              {
                className: 'modal-backdrop',
                onClick: function () {
                  setActiveModal(null);
                }
              },
              h(
                'div',
                {
                  className: 'oneui-card modal-sheet stack-sm',
                  onClick: function (e) {
                    e.stopPropagation();
                  }
                },
                h('div', { className: 'main-title' }, activeModal.name),
                h(
                  'div',
                  { className: 'sub-caption' },
                  'Size: ' +
                    formatDecimalBytes(activeModal.size) +
                    ' \u2022 Modified: ' +
                    activeModal.modified
                ),
                activeModal.doubleExt
                  ? h(
                      'div',
                      { className: 'alert-box warn-pill' },
                      'Security Warning: Suspicious double extension (.jpg.exe) detected.'
                    )
                  : null,
                activeModal.kind === 'exe'
                  ? h(
                      'div',
                      { className: 'alert-box warn-pill' },
                      'Windows PE executable (.exe) cannot run natively on Android.'
                    )
                  : null,
                activeModal.kind === 'apk'
                  ? h(
                      'div',
                      { className: 'alert-box info-pill' },
                      h('div', null, 'Package: ' + (activeModal.pkg || 'com.android.archive')),
                      h('div', null, 'Version: ' + (activeModal.ver || '1.0.0'))
                    )
                  : null,
                activeModal.content
                  ? h('pre', { className: 'code-preview' }, activeModal.content)
                  : null,
                h(
                  'div',
                  { className: 'row-end' },
                  h(
                    'button',
                    {
                      className: 'pill-btn',
                      style: { backgroundColor: accent, color: '#ffffff' },
                      onClick: function () {
                        setActiveModal(null);
                      }
                    },
                    'Close'
                  )
                )
              )
            )
          : null,

        toast ? h('div', { className: 'toast-pill' }, toast) : null
      )
    );
  }

  var container = document.getElementById('root');
  if (container) {
    rootContainer = container;
    rootComponent = App;
    flushRender();
  }

  // Register Service Worker only on http/https origins (never throws on file://)
  if ('serviceWorker' in navigator && window.location.protocol.indexOf('http') === 0) {
    navigator.serviceWorker.register('./sw.js').catch(function () {});
  }
})();
