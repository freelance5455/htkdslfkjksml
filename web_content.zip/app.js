/* FoodGo BD customer app — vanilla JS + Supabase */
const sb = window.supabase.createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY);
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (_) { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} };
let lang = localStorage.getItem("lang") || "bn";
const nf = (n) => Number(n || 0).toLocaleString(lang === "bn" ? "bn-BD" : "en-US");
const money = (n) => CONFIG.CURRENCY + nf(n);

/* ---------- i18n ---------- */
const T = {
  bn: {
    navHome: "হোম", navSearch: "সার্চ", navOrders: "অর্ডার", navProfile: "প্রোফাইল",
    deliverTo: "ডেলিভারি লোকেশন", pickArea: "এলাকা বাছুন", useGps: "আমার বর্তমান লোকেশন ব্যবহার করুন",
    gpsFinding: "লোকেশন খোঁজা হচ্ছে…", gpsOk: "লোকেশন পাওয়া গেছে। কাছের এলাকা:", gpsPick: "লোকেশন পাওয়া গেছে। এবার নিচ থেকে আপনার এলাকা বাছুন।",
    gpsDenied: "লোকেশন পাওয়া যায়নি। ফোনের লোকেশন অন করে অনুমতি দিন, অথবা নিচ থেকে এলাকা বাছুন।", gpsNo: "এই ব্রাউজারে লোকেশন সাপোর্ট নেই, নিচ থেকে এলাকা বাছুন।",
    findArea: "এলাকা খুঁজুন…", noArea: "কোনো এলাকা পাওয়া যায়নি", areasFail: "এলাকার তালিকা লোড হয়নি",
    gpsOn: "GPS লোকেশন যুক্ত", change: "পরিবর্তন",
    heroTitle: "ক্ষুধা পেলে, খাবার চলে আসবে দরজায়", searchPh: "রেস্টুরেন্ট বা খাবার খুঁজুন…",
    popular: "জনপ্রিয় খাবার", restaurants: "রেস্টুরেন্ট", all: "সব", closed: "বন্ধ", unavailable: "শেষ",
    delivery: "ডেলিভারি", minOrder: "মিনিমাম", couponBanner: "ছাড় পেতে কোড ব্যবহার করুন", off: "ছাড়",
    cart: "আপনার কার্ট", cartEmpty: "কার্ট খালি। পছন্দের খাবার যোগ করুন।", subtotal: "সাবটোটাল", discount: "ডিসকাউন্ট", total: "মোট",
    checkout: "চেকআউট", clear: "কার্ট খালি করুন", diffRest: "অন্য রেস্টুরেন্টের খাবার কার্টে আছে। কার্ট খালি করে নতুন যোগ করবেন?",
    name: "নাম", phone: "ফোন নম্বর", address: "ঠিকানার বিস্তারিত (বাড়ি, রাস্তা, ল্যান্ডমার্ক)", note: "নোট (ঐচ্ছিক)", coupon: "কুপন কোড", apply: "অ্যাপ্লাই",
    couponOk: "কুপন প্রয়োগ হয়েছে", couponBad: "কুপন সঠিক নয় বা শর্ত পূরণ হয়নি",
    payment: "পেমেন্ট মাধ্যম", cod: "ক্যাশ অন ডেলিভারি", trx: "ট্রানজেকশন আইডি (TrxID)",
    payHelp: "এই নম্বরে Send Money করুন এবং TrxID লিখুন:", amount: "পরিমাণ", payNote: "পেমেন্টে সমস্যা হলে কল করুন",
    place: "অর্ডার কনফার্ম করুন", placed: "অর্ডার সফল হয়েছে!", needLogin: "অর্ডার দেখতে আগে লগইন করুন",
    badPhone: "সঠিক ফোন নম্বর দিন (01XXXXXXXXX)", needTrx: "TrxID দিন", needAddr: "ঠিকানার বিস্তারিত লিখুন", needName: "নাম লিখুন",
    minNotMet: "মিনিমাম অর্ডার পূরণ হয়নি:", km: "কিমি",
    login: "লগইন", logout: "লগআউট", email: "ইমেইল", password: "পাসওয়ার্ড", signup: "সাইন আপ", haveAcc: "অ্যাকাউন্ট আছে? লগইন", noAcc: "অ্যাকাউন্ট নেই? সাইন আপ",
    confirmMail: "সাইন আপ হয়েছে। ইমেইল ভেরিফাই করে লগইন করুন।",
    myOrders: "আমার অর্ডার", noOrders: "এখনও কোনো অর্ডার নেই", orderNo: "অর্ডার #",
    s_pending: "অপেক্ষমান", s_confirmed: "কনফার্মড", s_preparing: "রান্না হচ্ছে", s_on_the_way: "পথে আছে", s_delivered: "ডেলিভারড", s_cancelled: "বাতিল",
    helpline: "হেল্পলাইন", helpSub: "যেকোনো সমস্যায় কল করুন", search: "সার্চ", typeToSearch: "কমপক্ষে ২টি অক্ষর লিখুন", dishes: "খাবার",
    profile: "প্রোফাইল", language: "ভাষা", loginPrompt: "অর্ডার ট্র্যাক করতে ও দ্রুত চেকআউটে লগইন করুন",
    loading: "লোড হচ্ছে…", err: "কিছু ভুল হয়েছে", noResult: "কিছু পাওয়া যায়নি", close: "বন্ধ করুন", splashTag: "আপনার পছন্দের খাবার, আপনার দরজায়"
  },
  en: {
    navHome: "Home", navSearch: "Search", navOrders: "Orders", navProfile: "Profile",
    deliverTo: "Delivery location", pickArea: "Choose area", useGps: "Use my current location",
    gpsFinding: "Finding your location…", gpsOk: "Location found. Nearest area:", gpsPick: "Location found. Now choose your area below.",
    gpsDenied: "Could not get location. Turn on phone location and allow access, or choose your area below.", gpsNo: "This browser does not support location. Choose your area below.",
    findArea: "Search area…", noArea: "No area found", areasFail: "Could not load areas",
    gpsOn: "GPS location attached", change: "Change",
    heroTitle: "Hungry? Food at your door.", searchPh: "Search restaurants or dishes…",
    popular: "Popular dishes", restaurants: "Restaurants", all: "All", closed: "Closed", unavailable: "Sold out",
    delivery: "Delivery", minOrder: "Min", couponBanner: "Use code to get", off: "off",
    cart: "Your cart", cartEmpty: "Your cart is empty. Add something tasty.", subtotal: "Subtotal", discount: "Discount", total: "Total",
    checkout: "Checkout", clear: "Clear cart", diffRest: "Your cart has items from another restaurant. Clear it and add this?",
    name: "Name", phone: "Phone number", address: "Address details (house, road, landmark)", note: "Note (optional)", coupon: "Coupon code", apply: "Apply",
    couponOk: "Coupon applied", couponBad: "Invalid coupon or conditions not met",
    payment: "Payment method", cod: "Cash on Delivery", trx: "Transaction ID (TrxID)",
    payHelp: "Send Money to this number and enter the TrxID:", amount: "Amount", payNote: "Payment problem? Call us",
    place: "Confirm order", placed: "Order placed!", needLogin: "Please log in to see your orders",
    badPhone: "Enter a valid phone (01XXXXXXXXX)", needTrx: "Enter the TrxID", needAddr: "Enter address details", needName: "Enter your name",
    minNotMet: "Minimum order not met:", km: "km",
    login: "Login", logout: "Logout", email: "Email", password: "Password", signup: "Sign up", haveAcc: "Have an account? Log in", noAcc: "No account? Sign up",
    confirmMail: "Signed up. Verify your email, then log in.",
    myOrders: "My orders", noOrders: "No orders yet", orderNo: "Order #",
    s_pending: "Pending", s_confirmed: "Confirmed", s_preparing: "Preparing", s_on_the_way: "On the way", s_delivered: "Delivered", s_cancelled: "Cancelled",
    helpline: "Helpline", helpSub: "Call us for any problem", search: "Search", typeToSearch: "Type at least 2 letters", dishes: "Dishes",
    profile: "Profile", language: "Language", loginPrompt: "Log in to track orders and check out faster",
    loading: "Loading…", err: "Something went wrong", noResult: "Nothing found", close: "Close", splashTag: "Your favourite food, at your door"
  }
};
const t = (k) => T[lang][k] ?? k;

const PAY_ALL = [
  { id: "cod", icon: "💵", label: () => t("cod") },
  { id: "bkash", icon: "🟣", label: () => "bKash" },
  { id: "nagad", icon: "🟠", label: () => "Nagad" },
  { id: "rocket", icon: "🟪", label: () => "Rocket" },
  { id: "upay", icon: "🟡", label: () => "Upay" }
];
const PAY = PAY_ALL.filter((m) => m.id === "cod" || (CONFIG.PAY_NUMBERS[m.id] || "").trim());

const EMO = [["biryani|kacchi|polao|rice|বিরিয়ানি|কাচ্চি|পোলাও", "🍛"], ["burger|বার্গার", "🍔"], ["pizza|পিজা|পিৎজা", "🍕"], ["chicken|fried|roast|চিকেন", "🍗"],
  ["pasta|noodle|chinese|চাইনিজ|নুডলস", "🍜"], ["sweet|dessert|cake|মিষ্টি|কেক", "🍰"], ["drink|juice|coffee|tea|borhani|বোরহানি", "🥤"], ["roll|wrap|shawarma|শর্মা", "🌯"],
  ["fish|seafood|মাছ", "🐟"], ["fast|fries|sides", "🍟"], ["curry|bhuna|bangla|bengali|ভর্তা|ভুনা", "🍲"], ["bread|garlic", "🥖"]];
const emo = (s) => { const x = String(s || "").toLowerCase(); for (const [k, e] of EMO) if (new RegExp(k).test(x)) return e; return "🍽️"; };
const picture = (url, name) => url ? `<img class="ph" loading="lazy" src="${esc(url)}" alt="" onerror="this.outerHTML='<div class=&quot;phe&quot;>${emo(name)}</div>'">` : `<div class="phe">${emo(name)}</div>`;

/* ---------- state ---------- */
const state = {
  user: null, profile: null, restaurants: [], areas: [], coupons: [], dishes: null, menuCache: {}, idx: {},
  settings: { fee_mode: "area", dist_base: 30, dist_per_km: 10, dist_free_km: 1, dist_factor: 1.3 },
  loc: load("loc", { areaId: null, areaName: "", lat: null, lng: null }),
  cart: load("cart", null) || { rid: null, rname: "", min: 0, rlat: null, rlng: null, items: {} },
  coupon: null, channel: null
};
if (!state.cart.items) state.cart.items = {};
const emptyCart = () => ({ rid: null, rname: "", min: 0, rlat: null, rlng: null, items: {} });
const saveCart = () => { save("cart", state.cart); updateCartCount(); };
const saveLoc = () => save("loc", state.loc);
const cartItems = () => Object.values(state.cart.items);
const cartSubtotal = () => cartItems().reduce((s, i) => s + i.price * i.qty, 0);
const updateCartCount = () => { const n = cartItems().reduce((s, i) => s + i.qty, 0); const b = $("#cartCount"); b.textContent = nf(n); b.classList.toggle("hidden", !n); };

/* ---------- ui helpers ---------- */
function toast(msg) { const el = $("#toast"); el.textContent = msg; el.classList.remove("hidden"); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.add("hidden"), 2800); }
function openModal(html) { $("#modalCard").innerHTML = `<div class="grab"></div>` + html; $("#modal").classList.remove("hidden"); }
function closeModal() { $("#modal").classList.add("hidden"); }
$("#modal").addEventListener("click", (e) => { if (e.target.id === "modal") closeModal(); });
const callLink = () => { const h = (CONFIG.HELPLINES || [])[0]; return h ? "tel:" + h : "#"; };
function applyLang() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => (el.textContent = t(el.dataset.i18n)));
  $("#splashTag").textContent = t("splashTag");
  updateCartCount();
}

/* ---------- data ---------- */
function hav(a, b, c, d) {
  const R = 6371, rad = (x) => (x * Math.PI) / 180, dLat = rad(c - a), dLon = rad(d - b);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a)) * Math.cos(rad(c)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
async function loadBase() {
  const [r, a, s, c] = await Promise.all([
    sb.from("restaurants").select("*").order("is_open", { ascending: false }).order("rating", { ascending: false }),
    sb.from("delivery_areas").select("*").eq("active", true).order("sort").order("id"),
    sb.from("app_settings").select("*"),
    sb.from("coupons").select("*").eq("active", true)
  ]);
  if (r.error) throw r.error;
  state.restaurants = r.data || [];
  state.areas = a.data || [];
  (s.data || []).forEach((x) => (state.settings[x.key] = x.value));
  state.coupons = c.data || [];
  const cur = state.areas.find((x) => x.id === state.loc.areaId);
  if (cur) state.loc.areaName = cur.name; else if (state.areas.length) { state.loc.areaId = null; state.loc.areaName = ""; }
}
async function loadDishes() {
  if (state.dishes) return state.dishes;
  const { data } = await sb.from("menu_items").select("*, restaurants(*)").eq("is_available", true).order("id").limit(14);
  state.dishes = (data || []).filter((d) => d.restaurants);
  return state.dishes;
}

/* ---------- delivery fee ---------- */
function feeInfo() {
  const s = state.settings, a = state.areas.find((x) => x.id === state.loc.areaId);
  if (s.fee_mode === "distance" && state.loc.lat != null && state.cart.rlat != null) {
    const km = hav(state.loc.lat, state.loc.lng, state.cart.rlat, state.cart.rlng) * Number(s.dist_factor || 1);
    const fee = Math.round(Number(s.dist_base) + Math.max(0, km - Number(s.dist_free_km)) * Number(s.dist_per_km));
    return { fee, km: Math.round(km * 10) / 10, ok: true };
  }
  if (a) return { fee: a.fee, km: null, ok: true };
  return { fee: 0, km: null, ok: false };
}
function calc() {
  const sub = cartSubtotal(), fi = feeInfo();
  const disc = state.coupon ? Math.min(Math.floor((sub * state.coupon.discount_percent) / 100), state.coupon.max_discount ?? Infinity) : 0;
  return { sub, fi, fee: fi.fee, disc, total: sub + fi.fee - disc };
}

/* ---------- auth ---------- */
async function loadSession() {
  const { data } = await sb.auth.getSession();
  state.user = data.session?.user || null;
  if (state.user) { const { data: p } = await sb.from("profiles").select("*").eq("id", state.user.id).maybeSingle(); state.profile = p; }
  else state.profile = null;
}
sb.auth.onAuthStateChange(() => { loadSession().then(() => { subscribeOrders(); if (/^#\/(profile|orders)/.test(location.hash)) route(); }); });

function openAuth(mode = "login", after) {
  const su = mode === "signup";
  openModal(`<h2>${su ? t("signup") : t("login")}</h2>
    ${su ? `<label>${t("name")}</label><input id="aName"><label>${t("phone")}</label><input id="aPhone" inputmode="tel">` : ""}
    <label>${t("email")}</label><input id="aEmail" type="email" autocomplete="email">
    <label>${t("password")}</label><input id="aPass" type="password" autocomplete="${su ? "new-password" : "current-password"}">
    <p id="aErr" class="err"></p>
    <button class="btn block" id="aGo">${su ? t("signup") : t("login")}</button>
    <p style="text-align:center"><button class="link" id="aSwap">${su ? t("haveAcc") : t("noAcc")}</button></p>`);
  $("#aSwap").onclick = () => openAuth(su ? "login" : "signup", after);
  $("#aGo").onclick = async () => {
    const email = $("#aEmail").value.trim(), password = $("#aPass").value;
    $("#aGo").disabled = true;
    const res = su
      ? await sb.auth.signUp({ email, password, options: { data: { name: $("#aName").value.trim(), phone: $("#aPhone").value.trim() } } })
      : await sb.auth.signInWithPassword({ email, password });
    $("#aGo").disabled = false;
    if (res.error) { $("#aErr").textContent = res.error.message; return; }
    if (su && !res.data.session) { closeModal(); toast(t("confirmMail")); return; }
    await loadSession(); closeModal(); subscribeOrders();
    if (after) after(); else route();
  };
}

/* ---------- location ---------- */
function setArea(a) { state.loc.areaId = a.id; state.loc.areaName = a.name; saveLoc(); }
function nearestArea(lat, lng) {
  let best = null, bd = 3;
  state.areas.forEach((a) => { if (a.lat != null && a.lng != null) { const d = hav(lat, lng, a.lat, a.lng); if (d < bd) { bd = d; best = a; } } });
  return best;
}
function openLocation(after) {
  const groups = [...new Set(state.areas.map((a) => a.grp))];
  openModal(`<h2>📍 ${t("deliverTo")}</h2>
    <button class="gps" id="gpsBtn">📍 ${t("useGps")}</button>
    <p class="mut" id="gpsMsg" style="min-height:20px;margin:8px 0">${state.loc.lat != null ? "✓ " + t("gpsOn") : ""}</p>
    <input id="areaQ" placeholder="${esc(t("findArea"))}">
    <div class="areas" id="areaList"></div>`);
  const done = () => { closeModal(); if (after) after(); else route(); };
  const draw = () => {
    const q = $("#areaQ").value.trim().toLowerCase();
    const showFee = state.settings.fee_mode === "area";
    const html = groups.map((g) => {
      const rows = state.areas.filter((a) => a.grp === g && a.name.toLowerCase().includes(q));
      return rows.length ? `<div class="ag">${esc(g)}</div>` + rows.map((a) => `<button class="ar ${a.id === state.loc.areaId ? "sel" : ""}" data-a="${a.id}"><span>${esc(a.name)}</span>${showFee ? `<span class="fee">${money(a.fee)}</span>` : ""}</button>`).join("") : "";
    }).join("");
    $("#areaList").innerHTML = html || `<div class="empty">${state.areas.length ? t("noArea") : t("areasFail")}</div>`;
    document.querySelectorAll(".ar").forEach((b) => (b.onclick = () => { setArea(state.areas.find((a) => a.id === Number(b.dataset.a))); done(); }));
  };
  $("#areaQ").oninput = draw; draw();
  const msg = (m) => ($("#gpsMsg").textContent = m);
  $("#gpsBtn").onclick = () => {
    if (!navigator.geolocation) return msg(t("gpsNo"));
    msg(t("gpsFinding"));
    navigator.geolocation.getCurrentPosition((pos) => {
      state.loc.lat = pos.coords.latitude; state.loc.lng = pos.coords.longitude; saveLoc();
      const near = nearestArea(state.loc.lat, state.loc.lng);
      if (near) { setArea(near); msg(`✓ ${t("gpsOk")} ${near.name}`); draw(); setTimeout(done, 900); }
      else { msg("✓ " + t("gpsPick")); draw(); }
    }, () => msg(t("gpsDenied")), { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
  };
}

/* ---------- router ---------- */
const NAV = (h) => (h.startsWith("#/search") ? "search" : h.startsWith("#/orders") ? "orders" : h.startsWith("#/profile") ? "profile" : "home");
async function route() {
  const h = location.hash || "#/";
  document.querySelectorAll("#tabbar a").forEach((a) => a.classList.toggle("on", a.dataset.tab === NAV(h) && !h.startsWith("#/r/")));
  $("#footer").innerHTML = "";
  $("#app").innerHTML = `<div class="empty">${t("loading")}</div>`;
  window.scrollTo(0, 0);
  try {
    if (h.startsWith("#/r/")) await renderRestaurant(Number(h.slice(4)));
    else if (h.startsWith("#/search")) await renderSearch();
    else if (h.startsWith("#/orders")) await renderOrders();
    else if (h.startsWith("#/profile")) { if (!state.restaurants.length) await loadBase().catch(() => {}); renderProfile(); }
    else await renderHome();
  } catch (e) { console.error(e); $("#app").innerHTML = `<div class="empty">${t("err")}: ${esc(e.message)}</div>`; }
}
window.addEventListener("hashchange", route);

/* ---------- item controls ---------- */
function ctrl(id) {
  const o = state.idx[id]; if (!o) return "";
  if (!(o.r.is_open && o.item.is_available)) return `<span class="na">${t("unavailable")}</span>`;
  const q = state.cart.items[id]?.qty || 0;
  return q ? `<div class="stp"><button data-step="${id}" data-d="-1" aria-label="-">−</button><b>${nf(q)}</b><button data-step="${id}" data-d="1" aria-label="+">+</button></div>`
           : `<button class="addb" data-add="${id}" aria-label="Add">+</button>`;
}
function paintCtrls() { document.querySelectorAll("[data-ctrl]").forEach((el) => (el.innerHTML = ctrl(el.dataset.ctrl))); }
const reg = (item, r) => { state.idx[item.id] = { item, r }; };
document.addEventListener("click", (e) => {
  const a = e.target.closest("[data-add]");
  if (a) { const o = state.idx[a.dataset.add]; if (o) addToCart(o.r, o.item); return; }
  const s = e.target.closest("[data-step]");
  if (s) changeQty(s.dataset.step, Number(s.dataset.d));
});
function addToCart(r, item) {
  if (state.cart.rid && state.cart.rid !== r.id && cartItems().length) {
    if (!confirm(t("diffRest"))) return;
    state.cart.items = {};
  }
  Object.assign(state.cart, { rid: r.id, rname: r.name, min: r.min_order || 0, rlat: r.lat ?? null, rlng: r.lng ?? null });
  const cur = state.cart.items[item.id];
  state.cart.items[item.id] = cur ? { ...cur, qty: cur.qty + 1 } : { id: item.id, name: item.name, price: item.price, qty: 1 };
  state.coupon = null; saveCart(); paintCtrls();
}
function changeQty(id, d) {
  const it = state.cart.items[id]; if (!it) return;
  it.qty += d; if (it.qty <= 0) delete state.cart.items[id];
  if (!cartItems().length) state.cart.rid = null;
  state.coupon = null; saveCart(); paintCtrls();
}

/* ---------- home ---------- */
const dishCard = (d) => { reg(d, d.restaurants); return `<div class="dish ${d.restaurants.is_open ? "" : "closed"}"><div class="im">${picture(d.image_url, d.name + " " + d.category)}</div>
  <div class="b"><h4>${esc(d.name)}</h4><span class="rn">${esc(d.restaurants.name)}</span>
  <div class="pr"><span class="price">${money(d.price)}</span><span data-ctrl="${d.id}">${ctrl(d.id)}</span></div></div></div>`; };
const restCard = (r) => `<div class="rcard ${r.is_open ? "" : "closed"}" data-id="${r.id}"><div class="im">${r.is_open ? "" : `<span class="ribbon">${t("closed")}</span>`}${picture(r.image_url, r.cuisine)}</div>
  <div class="b"><div class="rt"><h3>${esc(r.name)}</h3><span class="rate">★ ${nf(r.rating)}</span></div>
  <div class="meta">${esc(r.cuisine || "")}</div><div class="meta tags"><span>🕒 ${esc(r.eta || "")}</span><span>${t("minOrder")} ${money(r.min_order)}</span></div></div></div>`;
const bindRest = () => document.querySelectorAll(".rcard").forEach((c) => (c.onclick = () => (location.hash = "#/r/" + c.dataset.id)));

async function renderHome() {
  if (!state.restaurants.length) await loadBase();
  const dishes = await loadDishes();
  const cuisines = [...new Set(state.restaurants.flatMap((r) => (r.cuisine || "").split(",").map((c) => c.trim()).filter(Boolean)))];
  const cp = state.coupons[0];
  let cf = "";
  $("#app").innerHTML = `
    <section class="hhead"><div class="htop">
      <button class="loc" id="locBtn"><span>📍</span><span style="min-width:0"><small>${t("deliverTo")}</small><b>${esc(state.loc.areaName || t("pickArea"))} ▾</b></span></button>
      <div class="hbtns"><a class="ib" href="${callLink()}" aria-label="Call">📞</a><button class="ib" id="langBtn">${lang === "bn" ? "EN" : "বাং"}</button></div></div>
      <h1>${t("heroTitle")}</h1>
      <div class="searchbox"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input id="q" placeholder="${esc(t("searchPh"))}"></div></section>
    ${cp ? `<div class="banner"><div><b>${nf(cp.discount_percent)}% ${t("off")}</b><span>${t("couponBanner")}</span></div><span class="code">${esc(cp.code)}</span></div>` : `<div style="height:44px"></div>`}
    ${cuisines.length ? `<div class="hs cats" id="chips" style="margin-top:14px"><button class="cc on" data-c=""><span>🍽️</span>${t("all")}</button>${cuisines.map((c) => `<button class="cc" data-c="${esc(c)}"><span>${emo(c)}</span>${esc(c)}</button>`).join("")}</div>` : ""}
    ${dishes.length ? `<div class="sec"><h2>${t("popular")}</h2></div><div class="hs">${dishes.map(dishCard).join("")}</div>` : ""}
    <div class="sec"><h2>${t("restaurants")}</h2></div><div class="grid" id="list"></div>`;
  const draw = () => {
    const q = $("#q").value.toLowerCase();
    const list = state.restaurants.filter((r) => (r.name + " " + (r.cuisine || "")).toLowerCase().includes(q) && (!cf || (r.cuisine || "").includes(cf)));
    $("#list").innerHTML = list.length ? list.map(restCard).join("") : `<div class="empty">${t("noResult")}</div>`;
    bindRest();
  };
  $("#q").oninput = draw;
  const chips = $("#chips");
  if (chips) chips.onclick = (e) => { const b = e.target.closest(".cc"); if (!b) return; cf = b.dataset.c; chips.querySelectorAll(".cc").forEach((x) => x.classList.toggle("on", x === b)); draw(); };
  $("#locBtn").onclick = () => openLocation();
  $("#langBtn").onclick = toggleLang;
  draw(); renderFooter();
}
function toggleLang() { lang = lang === "bn" ? "en" : "bn"; localStorage.setItem("lang", lang); applyLang(); route(); }
function renderFooter() {
  const hl = CONFIG.HELPLINES || [];
  $("#footer").innerHTML = hl.length ? `<div class="fh">📞 ${t("helpline")}</div><div class="fs">${t("helpSub")}</div><div class="fn">${hl.map((n) => `<a href="tel:${esc(n)}">${esc(n)}</a>`).join("")}</div><div class="fc">© FoodGo BD</div>` : "";
}

/* ---------- search ---------- */
async function renderSearch() {
  if (!state.restaurants.length) await loadBase();
  $("#app").innerHTML = `<div class="ptitle"><h2>${t("search")}</h2></div>
    <div class="sbar"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input id="sq" placeholder="${esc(t("searchPh"))}"></div>
    <div id="sres"><div class="empty">${t("typeToSearch")}</div></div>`;
  let timer;
  $("#sq").oninput = (e) => {
    clearTimeout(timer);
    const q = e.target.value.trim();
    if (q.length < 2) { $("#sres").innerHTML = `<div class="empty">${t("typeToSearch")}</div>`; return; }
    timer = setTimeout(async () => {
      const ql = q.toLowerCase();
      const rs = state.restaurants.filter((r) => (r.name + " " + (r.cuisine || "")).toLowerCase().includes(ql));
      const { data } = await sb.from("menu_items").select("*, restaurants(*)").ilike("name", `%${q.replace(/[%_]/g, "")}%`).eq("is_available", true).limit(20);
      const ds = (data || []).filter((d) => d.restaurants);
      const html = (rs.length ? `<div class="sec"><h2>${t("restaurants")}</h2></div><div class="grid">${rs.map(restCard).join("")}</div>` : "") +
        (ds.length ? `<div class="sec"><h2>${t("dishes")}</h2></div>${ds.map((d) => { reg(d, d.restaurants); return `<div class="item"><div class="im">${picture(d.image_url, d.name)}</div><div class="info"><h4>${esc(d.name)}</h4><p>${esc(d.restaurants.name)}</p><div class="pr"><span class="price">${money(d.price)}</span><span data-ctrl="${d.id}">${ctrl(d.id)}</span></div></div></div>`; }).join("")}` : "");
      $("#sres").innerHTML = html || `<div class="empty">${t("noResult")}</div>`;
      bindRest();
    }, 250);
  };
}

/* ---------- restaurant ---------- */
async function renderRestaurant(id) {
  if (!state.restaurants.length) await loadBase();
  const r = state.restaurants.find((x) => x.id === id);
  if (!r) { $("#app").innerHTML = `<div class="empty">${t("noResult")}</div>`; return; }
  if (!state.menuCache[id]) {
    const { data, error } = await sb.from("menu_items").select("*").eq("restaurant_id", id).order("category").order("name");
    if (error) throw error;
    state.menuCache[id] = data;
  }
  const items = state.menuCache[id];
  items.forEach((i) => reg(i, r));
  const cats = [...new Set(items.map((i) => i.category || "Other"))];
  $("#app").innerHTML = `
    <div class="rhero ${r.is_open ? "" : "closed"}"><button class="back" onclick="history.length>1?history.back():location.hash='#/'" aria-label="Back">←</button>${picture(r.image_url, r.cuisine)}</div>
    <div class="rinfo"><div class="rt"><h2>${esc(r.name)}</h2><span class="rate">★ ${nf(r.rating)}</span></div>
      <div class="meta">${esc(r.cuisine || "")}</div>
      <div class="meta tags"><span>🕒 ${esc(r.eta || "")}</span><span>${t("minOrder")} ${money(r.min_order)}</span>${r.is_open ? "" : `<span style="color:var(--red);font-weight:700">${t("closed")}</span>`}</div></div>
    ${cats.map((c) => `<h3 class="cat">${esc(c)}</h3>` + items.filter((i) => (i.category || "Other") === c).map((i) => `
      <div class="item"><div class="im">${picture(i.image_url, i.name)}</div>
        <div class="info"><h4>${esc(i.name)}</h4>${i.description ? `<p>${esc(i.description)}</p>` : ""}
        <div class="pr"><span class="price">${money(i.price)}</span><span data-ctrl="${i.id}">${ctrl(i.id)}</span></div></div></div>`).join("")).join("")}`;
}

/* ---------- cart ---------- */
$("#cartBtn").onclick = openCart;
function openCart() {
  const items = cartItems();
  if (!items.length) return openModal(`<h2>${t("cart")}</h2><div class="empty">🛒<br>${t("cartEmpty")}</div><button class="btn ghost block" onclick="closeModal()">${t("close")}</button>`);
  const sub = cartSubtotal(), fi = feeInfo();
  openModal(`<h2>${t("cart")}</h2><div class="mut" style="margin-bottom:6px">${esc(state.cart.rname)}</div>
    ${items.map((i) => `<div class="crow"><div class="nm">${esc(i.name)}<div class="mut">${money(i.price)}</div></div>
      <div class="stp"><button data-cq="${i.id}" data-d="-1">−</button><b>${nf(i.qty)}</b><button data-cq="${i.id}" data-d="1">+</button></div>
      <b style="min-width:64px;text-align:right">${money(i.price * i.qty)}</b></div>`).join("")}
    <hr><div class="row"><span>${t("subtotal")}</span><b>${money(sub)}</b></div>
    <div class="row"><span>${t("delivery")}${fi.km != null ? ` (${nf(fi.km)} ${t("km")})` : ""}</span>${fi.ok ? `<b>${money(fi.fee)}</b>` : `<button class="link" id="pickA">${t("pickArea")}</button>`}</div>
    <button class="btn block" id="toCheckout" style="margin-top:10px">${t("checkout")}</button>
    <p style="text-align:center"><button class="link" id="clr">${t("clear")}</button></p>`);
  document.querySelectorAll("[data-cq]").forEach((b) => (b.onclick = () => { changeQty(b.dataset.cq, Number(b.dataset.d)); openCart(); }));
  $("#clr").onclick = () => { state.cart = emptyCart(); state.coupon = null; saveCart(); paintCtrls(); closeModal(); };
  if ($("#pickA")) $("#pickA").onclick = () => openLocation(openCart);
  $("#toCheckout").onclick = () => (state.user ? openCheckout() : openAuth("login", openCheckout));
}

/* ---------- checkout ---------- */
function openCheckout() {
  if (!state.user) return openAuth("login", openCheckout);
  if (!state.loc.areaId) return openLocation(openCheckout);
  const p = state.profile || {}, c = calc();
  openModal(`<h2>${t("checkout")}</h2>
    <div class="locbox"><div><b>📍 ${esc(state.loc.areaName)}</b>${state.loc.lat != null ? `<div class="mut">✓ ${t("gpsOn")}</div>` : ""}</div><button class="link" id="chLoc">${t("change")}</button></div>
    <label>${t("name")}</label><input id="cName" value="${esc(p.name || "")}">
    <label>${t("phone")}</label><input id="cPhone" inputmode="tel" value="${esc(p.phone || "")}">
    <label>${t("address")}</label><textarea id="cAddr" rows="2"></textarea>
    <label>${t("note")}</label><input id="cNote">
    <label>${t("coupon")}</label>
    <div style="display:flex;gap:6px"><input id="cCoupon" value="${esc(state.coupon?.code || "")}"><button class="btn ghost" id="cApply" style="white-space:nowrap">${t("apply")}</button></div>
    <label>${t("payment")}</label>
    <div class="pay-opts">${PAY.map((m, i) => `<label class="${i === 0 ? "sel" : ""}"><input type="radio" name="pay" value="${m.id}" ${i === 0 ? "checked" : ""}> ${m.icon} ${esc(m.label())}</label>`).join("")}</div>
    <div id="payInfo"></div>
    <p class="mut" style="margin:8px 0 0">${t("payNote")}: ${(CONFIG.HELPLINES || []).map((n) => `<a href="tel:${esc(n)}">${esc(n)}</a>`).join(" / ")}</p>
    <hr>
    <div class="row"><span>${t("subtotal")}</span><span>${money(c.sub)}</span></div>
    <div class="row"><span>${t("delivery")}${c.fi.km != null ? ` (${nf(c.fi.km)} ${t("km")})` : ""}</span><span>${money(c.fee)}</span></div>
    ${c.disc ? `<div class="row"><span>${t("discount")}</span><span>−${money(c.disc)}</span></div>` : ""}
    <div class="row total"><span>${t("total")}</span><span>${money(c.total)}</span></div>
    <p id="cErr" class="err"></p>
    <button class="btn block" id="cPlace">${t("place")}</button>`);
  $("#chLoc").onclick = () => openLocation(openCheckout);
  const payInfo = () => {
    const m = document.querySelector("input[name=pay]:checked").value;
    document.querySelectorAll(".pay-opts label").forEach((l) => l.classList.toggle("sel", l.querySelector("input").checked));
    $("#payInfo").innerHTML = m === "cod" ? "" : `<div class="paybox">${t("payHelp")}<br><b style="font-size:18px">${esc(CONFIG.PAY_NUMBERS[m])}</b><br>${t("amount")}: <b>${money(calc().total)}</b>
      <label>${t("trx")}</label><input id="cTrx" autocapitalize="characters"></div>`;
  };
  document.querySelectorAll("input[name=pay]").forEach((r) => (r.onchange = payInfo)); payInfo();
  $("#cApply").onclick = async () => {
    const code = $("#cCoupon").value.trim().toUpperCase(); if (!code) { state.coupon = null; return openCheckout(); }
    const { data } = await sb.from("coupons").select("*").eq("code", code).eq("active", true).maybeSingle();
    if (data && cartSubtotal() >= (data.min_order || 0)) { state.coupon = data; toast(t("couponOk")); } else { state.coupon = null; toast(t("couponBad")); }
    openCheckout();
  };
  $("#cPlace").onclick = async () => {
    const err = (m) => ($("#cErr").textContent = m);
    const name = $("#cName").value.trim(), phone = $("#cPhone").value.trim().replace(/[\s-]/g, ""), addr = $("#cAddr").value.trim();
    const method = document.querySelector("input[name=pay]:checked").value;
    const trx = method === "cod" ? null : ($("#cTrx").value.trim() || "");
    const cc = calc();
    if (!name) return err(t("needName"));
    if (!/^(\+?88)?01[3-9]\d{8}$/.test(phone)) return err(t("badPhone"));
    if (!addr) return err(t("needAddr"));
    if (method !== "cod" && trx.length < 6) return err(t("needTrx"));
    if (cc.sub < state.cart.min) return err(`${t("minNotMet")} ${money(state.cart.min)}`);
    $("#cPlace").disabled = true;
    const { error } = await sb.from("orders").insert({
      user_id: state.user.id, restaurant_id: state.cart.rid, restaurant_name: state.cart.rname,
      customer_name: name, phone, address: addr, note: $("#cNote").value.trim() || null,
      area_id: state.loc.areaId, area_name: state.loc.areaName, lat: state.loc.lat, lng: state.loc.lng, distance_km: cc.fi.km,
      items: cartItems().map(({ id, name, price, qty }) => ({ id, name, price, qty })),
      subtotal: cc.sub, delivery_fee: cc.fee, discount: cc.disc, total: cc.total,
      payment_method: method, payment_trx_id: trx
    });
    if (error) { $("#cPlace").disabled = false; return err(error.message); }
    state.cart = emptyCart(); state.coupon = null; saveCart();
    closeModal(); toast(t("placed")); location.hash = "#/orders";
  };
}

/* ---------- orders ---------- */
const STEPS = ["pending", "confirmed", "preparing", "on_the_way", "delivered"];
async function renderOrders() {
  if (!state.user) { $("#app").innerHTML = `<div class="ptitle"><h2>${t("myOrders")}</h2></div><div class="empty">${t("needLogin")}<br><br><button class="btn" id="oLogin">${t("login")}</button></div>`; $("#oLogin").onclick = () => openAuth("login"); return; }
  const { data, error } = await sb.from("orders").select("*").eq("user_id", state.user.id).order("created_at", { ascending: false });
  if (error) throw error;
  $("#app").innerHTML = `<div class="ptitle"><h2>${t("myOrders")}</h2></div>` + (data.length ? data.map((o) => {
    const idx = STEPS.indexOf(o.status);
    return `<div class="ocard"><div class="row"><b>${t("orderNo")}${nf(o.id)} · ${esc(o.restaurant_name || "")}</b><span class="status s-${o.status}">${t("s_" + o.status)}</span></div>
      ${o.status === "cancelled" ? "" : `<div class="steps">${STEPS.map((_, i) => `<i class="${i <= idx ? "on" : ""}"></i>`).join("")}</div>`}
      <div class="meta">${o.items.map((i) => `${esc(i.name)} ×${nf(i.qty)}`).join(", ")}</div>
      ${o.area_name ? `<div class="meta" style="margin-top:4px">📍 ${esc(o.area_name)}</div>` : ""}
      <div class="row"><span class="meta">${new Date(o.created_at).toLocaleString(lang === "bn" ? "bn-BD" : "en-GB")} · ${esc(o.payment_method.toUpperCase())}</span><b>${money(o.total)}</b></div></div>`;
  }).join("") : `<div class="empty">🧾<br>${t("noOrders")}</div>`);
}
function subscribeOrders() {
  if (state.channel) { sb.removeChannel(state.channel); state.channel = null; }
  if (!state.user) return;
  state.channel = sb.channel("my-orders").on("postgres_changes", { event: "UPDATE", schema: "public", table: "orders", filter: `user_id=eq.${state.user.id}` }, (p) => {
    toast(`${t("orderNo")}${nf(p.new.id)}: ${t("s_" + p.new.status)}`);
    if (location.hash === "#/orders") renderOrders();
  }).subscribe();
}

/* ---------- profile ---------- */
function renderProfile() {
  const u = state.user, p = state.profile || {}, hl = CONFIG.HELPLINES || [];
  $("#app").innerHTML = `<div class="ptitle"><h2>${t("profile")}</h2></div>
    ${u ? `<div class="phead"><div class="av">${esc((p.name || u.email || "?").trim().charAt(0).toUpperCase())}</div><div style="min-width:0"><b style="font-size:18px">${esc(p.name || "")}</b><div class="mut">${esc(u.email)}</div><div class="mut">${esc(p.phone || "")}</div></div></div>`
        : `<div class="phead" style="flex-direction:column;align-items:stretch;text-align:center"><p class="mut" style="margin:0">${t("loginPrompt")}</p><button class="btn block" id="pLogin">${t("login")} / ${t("signup")}</button></div>`}
    <div class="pcard">
      <button class="prow" id="pLoc"><span>📍 ${t("deliverTo")}<div class="mut">${esc(state.loc.areaName || t("pickArea"))}</div></span><span>›</span></button>
      <button class="prow" id="pLang"><span>🌐 ${t("language")}<div class="mut">${lang === "bn" ? "বাংলা" : "English"}</div></span><span>⇄</span></button>
      ${u ? `<button class="prow" id="pOut"><span style="color:var(--red)">⎋ ${t("logout")}</span></button>` : ""}
    </div>
    ${hl.length ? `<div class="pcard" style="padding:14px 16px"><b>📞 ${t("helpline")}</b><div class="mut" style="margin:2px 0 10px">${t("helpSub")}</div><div class="callrow">${hl.map((n) => `<a href="tel:${esc(n)}">${esc(n)}</a>`).join("")}</div></div>` : ""}`;
  $("#pLoc").onclick = () => openLocation(() => route());
  $("#pLang").onclick = toggleLang;
  if ($("#pLogin")) $("#pLogin").onclick = () => openAuth("login");
  if ($("#pOut")) $("#pOut").onclick = async () => { await sb.auth.signOut(); state.user = null; state.profile = null; route(); };
}

/* ---------- boot ---------- */
(async function init() {
  const t0 = Date.now();
  let skip = null; try { skip = sessionStorage.getItem("splash"); } catch (_) {}
  if (skip) $("#splash").classList.add("out");
  applyLang();
  try { await loadSession(); } catch (_) {}
  subscribeOrders();
  await route();
  if (!skip) setTimeout(() => { $("#splash").classList.add("out"); try { sessionStorage.setItem("splash", "1"); } catch (_) {} }, Math.max(0, 1900 - (Date.now() - t0)));
  if (!state.loc.areaId && state.areas.length && !load("locAsked", false)) { save("locAsked", true); setTimeout(() => openLocation(), skip ? 300 : 2500); }
})();
window.openAuth = openAuth; window.closeModal = closeModal;
