(()=>{'use strict';
const TILE=256,MIN_Z=3,MAX_Z=18,DB='offline-map-db',STORE='tiles';
const $=id=>document.getElementById(id),canvas=$('map'),ctx=canvas.getContext('2d');
let view={lat:40.4093,lng:49.8671,z:12},A=null,B=null,selectNext='A',cache=new Map(),db=null;
const fa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const world=z=>TILE*2**z;
function project(lat,lng,z){let s=world(z),v=Math.sin(lat*Math.PI/180);return{x:(lng+180)/360*s,y:(.5-Math.log((1+v)/(1-v))/(4*Math.PI))*s}}
function unproject(x,y,z){let s=world(z),n=Math.PI-2*Math.PI*y/s;return{lat:180/Math.PI*Math.atan(Math.sinh(n)),lng:x/s*360-180}}
function distance(a,b){let r=Math.PI/180,d1=(b.lat-a.lat)*r,d2=(b.lng-a.lng)*r,h=Math.sin(d1/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(d2/2)**2;return 6371*2*Math.asin(Math.sqrt(h))}
function openDB(){return new Promise((resolve,reject)=>{let req=indexedDB.open(DB,1);req.onupgradeneeded=()=>req.result.createObjectStore(STORE);req.onsuccess=()=>{db=req.result;resolve(db)};req.onerror=()=>reject(req.error)})}
function dbGet(k){return new Promise(resolve=>{try{let r=db.transaction(STORE).objectStore(STORE).get(k);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>resolve(null)}catch{resolve(null)}})}
function dbPut(k,v){return new Promise((resolve,reject)=>{let t=db.transaction(STORE,'readwrite');t.objectStore(STORE).put(v,k);t.oncomplete=resolve;t.onerror=()=>reject(t.error)})}
function tile(z,x,y){let key=`${z}/${x}/${y}`;if(cache.has(key))return cache.get(key);let t={state:'loading',img:new Image()};cache.set(key,t);
(async()=>{let blob=await dbGet(key);if(blob){t.img.src=URL.createObjectURL(blob);t.img.onload=()=>{t.state='ok';draw()};t.img.onerror=()=>t.state='missing';return}
t.img.onload=()=>{t.state='ok';draw()};t.img.onerror=()=>{t.state='missing'};t.img.src=`tiles/${key}.png`;})();return t}
const W=()=>canvas.clientWidth,H=()=>canvas.clientHeight;
function resize(){let d=devicePixelRatio||1;canvas.width=Math.round(W()*d);canvas.height=Math.round(H()*d);ctx.setTransform(d,0,0,d,0,0);draw()}
function screen(p){let c=project(view.lat,view.lng,view.z),q=project(p.lat,p.lng,view.z);return{x:q.x-c.x+W()/2,y:q.y-c.y+H()/2}}
function latlng(x,y){let c=project(view.lat,view.lng,view.z);return unproject(c.x+x-W()/2,c.y+y-H()/2,view.z)}
function draw(){if(!ctx)return;ctx.clearRect(0,0,W(),H());let c=project(view.lat,view.lng,view.z),left=c.x-W()/2,top=c.y-H()/2,n=2**view.z;
for(let y=Math.floor(top/TILE);y<=Math.floor((top+H())/TILE);y++){if(y<0||y>=n)continue;for(let x=Math.floor(left/TILE);x<=Math.floor((left+W())/TILE);x++){let xx=(x%n+n)%n,px=x*TILE-left,py=y*TILE-top,t=tile(view.z,xx,y);if(t.state==='ok')ctx.drawImage(t.img,px,py,TILE,TILE);else{ctx.fillStyle='#e9e6dc';ctx.fillRect(px,py,TILE,TILE);ctx.strokeStyle='#d5d0c5';ctx.strokeRect(px,py,TILE,TILE)}}}
if(A&&B){let a=screen(A),b=screen(B);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle='#1976d2';ctx.lineWidth=4;ctx.stroke()}
if(A)pin(A,'#16834a','A');if(B)pin(B,'#d33b35','B');updateInfo()}
function pin(p,color,label){let s=screen(p);ctx.beginPath();ctx.arc(s.x,s.y,10,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();ctx.lineWidth=3;ctx.strokeStyle='white';ctx.stroke();ctx.fillStyle='white';ctx.font='bold 11px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,s.x,s.y)}
function updateInfo(){if(A&&B)$('info').textContent=`فاصله مستقیم: ${fa(distance(A,B).toFixed(2))} کیلومتر — این خط مسیر جاده‌ای نیست.`;else if(A)$('info').textContent='مبدأ ثبت شد؛ مقصد را انتخاب کنید.';else $('info').textContent='برای شروع، نقطه مبدأ را روی نقشه انتخاب کنید.'}
function zoomAt(x,y,dz){let z=Math.max(MIN_Z,Math.min(MAX_Z,view.z+dz));if(z===view.z)return;let p=latlng(x,y);view.z=z;let q=project(p.lat,p.lng,z);let c=unproject(q.x-(x-W()/2),q.y-(y-H()/2),z);view.lat=c.lat;view.lng=c.lng;draw()}
let pointers=new Map(),lastPinch=0,moved=0;
canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.offsetX,y:e.offsetY});moved=0});
canvas.addEventListener('pointermove',e=>{let p=pointers.get(e.pointerId);if(!p)return;let dx=e.offsetX-p.x,dy=e.offsetY-p.y;if(pointers.size===1){moved+=Math.abs(dx)+Math.abs(dy);let c=project(view.lat,view.lng,view.z),ll=unproject(c.x-dx,c.y-dy,view.z);view.lat=Math.max(-85,Math.min(85,ll.lat));view.lng=ll.lng;p.x=e.offsetX;p.y=e.offsetY;draw()}else if(pointers.size===2){p.x=e.offsetX;p.y=e.offsetY;let[a,b]=[...pointers.values()],d=Math.hypot(a.x-b.x,a.y-b.y);if(lastPinch&&Math.abs(d-lastPinch)>35){zoomAt((a.x+b.x)/2,(a.y+b.y)/2,d>lastPinch?1:-1);lastPinch=d}else if(!lastPinch)lastPinch=d}});
canvas.addEventListener('pointerup',e=>{let one=pointers.size===1;pointers.delete(e.pointerId);lastPinch=0;if(one&&moved<7){let ll=latlng(e.offsetX,e.offsetY);if(selectNext==='A'){A=ll;selectNext='B'}else{B=ll;selectNext='A'}draw()}});
canvas.addEventListener('pointercancel',e=>pointers.delete(e.pointerId));canvas.addEventListener('wheel',e=>{e.preventDefault();zoomAt(e.offsetX,e.offsetY,e.deltaY<0?1:-1)},{passive:false});
$('zin').onclick=()=>zoomAt(W()/2,H()/2,1);$('zout').onclick=()=>zoomAt(W()/2,H()/2,-1);
$('reset').onclick=()=>{view={lat:40.4093,lng:49.8671,z:12};draw()};
$('clearRoute').onclick=()=>{A=B=null;selectNext='A';draw()};
$('swap').onclick=()=>{[A,B]=[B,A];draw()};
$('fit').onclick=()=>fitBounds();
function fitBounds(){if(!A&&!B)return;let p=A||B;view={lat:p.lat,lng:p.lng,z:14};if(A&&B){for(let z=MAX_Z;z>=MIN_Z;z--){let a=project(A.lat,A.lng,z),b=project(B.lat,B.lng,z);if(Math.abs(a.x-b.x)<W()*.65&&Math.abs(a.y-b.y)<H()*.65){view={lat:(A.lat+B.lat)/2,lng:(A.lng+B.lng)/2,z};break}}}draw()}
$('locate').onclick=()=>{if(!navigator.geolocation){alert('مرورگر شما GPS را پشتیبانی نمی‌کند.');return}$('status').textContent='در حال دریافت موقعیت…';navigator.geolocation.getCurrentPosition(pos=>{view={lat:pos.coords.latitude,lng:pos.coords.longitude,z:15};A={...view};B=null;selectNext='B';$('status').textContent='موقعیت دریافت شد';draw()},err=>{$('status').textContent='خطا در GPS';alert('دریافت موقعیت ناموفق بود. دسترسی مکان و اتصال امن (HTTPS) را بررسی کنید.')},{enableHighAccuracy:true,timeout:15000})};
$('importBtn').onclick=()=> $('folderInput').click();
$('folderInput').addEventListener('change',async e=>{let files=[...e.target.files].filter(f=>/\.(png|jpe?g)$/i.test(f.name));if(!files.length){alert('فایل تصویری کاشی پیدا نشد. پوشه z/x/y.png را انتخاب کنید.');return}
$('status').textContent='در حال وارد کردن…';let done=0,skipped=0;
for(let f of files){let rel=f.webkitRelativePath||f.name,parts=rel.split('/'),idx=parts.findIndex(x=>/^\d{1,2}$/.test(x));if(idx<0||parts.length<idx+4){skipped++;continue}let key=parts.slice(idx,idx+3).join('/').replace(/\.(png|jpe?g)$/i,'');if(!/^\d+\/\d+\/\d+$/.test(key)){skipped++;continue}try{await dbPut(key,f);cache.delete(key);done++}catch{skipped++}}
$('status').textContent='واردسازی تمام شد';$('tileStatus').textContent=`${fa(done)} کاشی وارد شد${skipped?`، ${fa(skipped)} فایل نادیده گرفته شد`:''}.`;cache.clear();draw();e.target.value=''});
$('storageBtn').onclick=async()=>{let count=0;try{count=await new Promise((resolve,reject)=>{let r=db.transaction(STORE).objectStore(STORE).count();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}catch{}let estimate=navigator.storage?.estimate?await navigator.storage.estimate():null;let used=estimate?`${(estimate.usage/1048576).toFixed(1)} MB`:'نامشخص';alert(`تعداد کاشی‌های ذخیره‌شده: ${fa(count)}\\nحافظه استفاده‌شده در مرورگر: ${fa(used)}`)};
window.addEventListener('resize',resize);
openDB().then(()=>{$('tileStatus').textContent='آماده دریافت نقشه از حافظه گوشی؛ نقشه‌های واردشده در همین مرورگر ذخیره می‌شوند.';resize()}).catch(()=>{$('tileStatus').textContent='ذخیره‌سازی مرورگر در دسترس نیست.';resize()});
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
})();