/* Offline Student Learning App - demo/local-only */
const DB_NAME='ShikkhaOfflineDB', DB_VERSION=1, STORE='records';
const CLASSES=['Class 1','Class 2','Class 3','Class 4','Class 5','Class 6','Class 7','Class 8','Class 9','Class 10','SSC','HSC','Honours 1st Year','Honours 2nd Year','Honours 3rd Year','Honours 4th Year','Degree','Masters'];
const SUBJECTS={
 'Class 1':['বাংলা','English','গণিত','পরিবেশ পরিচিতি'],
 'Class 2':['বাংলা','English','গণিত','পরিবেশ পরিচিতি'],
 'Class 3':['বাংলা','English','গণিত','প্রাথমিক বিজ্ঞান','বাংলাদেশ ও বিশ্বপরিচয়'],
 'Class 4':['বাংলা','English','গণিত','প্রাথমিক বিজ্ঞান','বাংলাদেশ ও বিশ্বপরিচয়'],
 'Class 5':['বাংলা','English','গণিত','প্রাথমিক বিজ্ঞান','বাংলাদেশ ও বিশ্বপরিচয়'],
 'Class 6':['বাংলা','English','গণিত','বিজ্ঞান','ইতিহাস ও সামাজিক বিজ্ঞান','ডিজিটাল প্রযুক্তি'],
 'Class 7':['বাংলা','English','গণিত','বিজ্ঞান','ইতিহাস ও সামাজিক বিজ্ঞান','ডিজিটাল প্রযুক্তি'],
 'Class 8':['বাংলা','English','গণিত','বিজ্ঞান','ইতিহাস','ভূগোল'],
 'Class 9':['বাংলা','English','গণিত','পদার্থবিজ্ঞান','রসায়ন','জীববিজ্ঞান','উচ্চতর গণিত','বাংলাদেশ ও বিশ্বপরিচয়'],
 'Class 10':['বাংলা','English','গণিত','পদার্থবিজ্ঞান','রসায়ন','জীববিজ্ঞান','উচ্চতর গণিত','বাংলাদেশ ও বিশ্বপরিচয়'],
 'SSC':['বাংলা','English','গণিত','পদার্থবিজ্ঞান','রসায়ন','জীববিজ্ঞান','উচ্চতর গণিত'],
 'HSC':['বাংলা','English','পদার্থবিজ্ঞান','রসায়ন','জীববিজ্ঞান','উচ্চতর গণিত','হিসাববিজ্ঞান','অর্থনীতি'],
 'Honours 1st Year':['বাংলা','English','গণিত','পদার্থবিজ্ঞান','রসায়ন','জীববিজ্ঞান','হিসাববিজ্ঞান','অর্থনীতি','রাষ্ট্রবিজ্ঞান','ইতিহাস'],
 'Honours 2nd Year':['বাংলা','English','গণিত','পদার্থবিজ্ঞান','রসায়ন','জীববিজ্ঞান','হিসাববিজ্ঞান','অর্থনীতি','রাষ্ট্রবিজ্ঞান','ইতিহাস'],
 'Honours 3rd Year':['বাংলা','English','গণিত','পদার্থবিজ্ঞান','রসায়ন','জীববিজ্ঞান','হিসাববিজ্ঞান','অর্থনীতি','রাষ্ট্রবিজ্ঞান','ইতিহাস'],
 'Honours 4th Year':['বাংলা','English','গণিত','পদার্থবিজ্ঞান','রসায়ন','জীববিজ্ঞান','হিসাববিজ্ঞান','অর্থনীতি','রাষ্ট্রবিজ্ঞান','ইতিহাস'],
 'Degree':['বাংলা','English','গণিত','হিসাববিজ্ঞান','অর্থনীতি','রাষ্ট্রবিজ্ঞান','ইতিহাস'],
 'Masters':['বাংলা','English','গণিত','পদার্থবিজ্ঞান','রসায়ন','জীববিজ্ঞান','হিসাববিজ্ঞান','অর্থনীতি','রাষ্ট্রবিজ্ঞান','ইতিহাস']
};
const TOPICS=['ভূমিকা ও মৌলিক ধারণা','সংজ্ঞা ও বৈশিষ্ট্য','কারণ ও ফলাফল','উদাহরণসহ ব্যাখ্যা','গুরুত্ব ও প্রয়োগ','অনুশীলনী'];
let db, data={version:3,defaultAdminSeeded:false,admins:[],students:[],practice:[],knowledgeBase:[],settings:{appName:'শিক্ষা Offline',announcement:'',modelId:'onnx-community/SmolLM2-360M-Instruct-ONNX'}}, session=null;
const $=id=>document.getElementById(id);
function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,DB_VERSION);req.onupgradeneeded=()=>req.result.createObjectStore(STORE);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
function readData(){return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readonly'),r=tx.objectStore(STORE).get('app');r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>reject(r.error)})}
function writeData(){return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(data,'app');tx.oncomplete=()=>{ $('saveStatus').textContent='ডিভাইসে সেভ হয়েছে';resolve()};tx.onerror=()=>reject(tx.error)})}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function show(id){['setupView','loginView','appView'].forEach(x=>$(x).classList.toggle('hidden',x!==id))}
function fillClassSelect(el){el.innerHTML=CLASSES.map(c=>`<option>${esc(c)}</option>`).join('')}
function currentStudent(){return data.students.find(s=>s.id===session.id)}


// Optional local generative model using Transformers.js. Model is downloaded on first use.
let aiPipeline=null, aiLoadPromise=null;
const DEFAULT_AI_MODEL='onnx-community/SmolLM2-360M-Instruct-ONNX';
const AI_MODEL=()=>data.settings?.modelId||DEFAULT_AI_MODEL;
function setAiStatus(message,kind=''){ $('aiStatus').textContent=message; $('aiStatus').className='ai-status '+kind; }
async function loadOfflineAI(){
  if(aiPipeline)return aiPipeline;
  if(aiLoadPromise)return aiLoadPromise;
  aiLoadPromise=(async()=>{
    setAiStatus('লাইব্রেরি লোড হচ্ছে');
    $('aiProgress').textContent='প্রথমবার চালু করতে ইন্টারনেট লাগবে। 360M quantized মডেল ডাউনলোড হতে কয়েক মিনিট লাগতে পারে। পেজ খোলা রাখুন।';
    try{
      if(!('indexedDB' in window)) throw new Error('এই ব্রাউজারে IndexedDB নেই।');
      if(location.protocol==='file:') throw new Error('অ্যাপটি সরাসরি file:// থেকে চালানো যাবে না। HTTPS hosting বা localhost ব্যবহার করুন।');
      if(!navigator.onLine) throw new Error('প্রথমবার মডেল ডাউনলোডের জন্য ইন্টারনেট সংযোগ চালু করুন।');
      const mod=await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.2');
      if(mod.env){mod.env.allowRemoteModels=true;mod.env.useBrowserCache=true;}
      const model=AI_MODEL();
      $('aiProgress').textContent='মডেল: '+model+' — প্রায় 400 MB বা তার বেশি ডেটা লাগতে পারে। ডাউনলোড শেষ না হওয়া পর্যন্ত অ্যাপ বন্ধ করবেন না।';
      const options={dtype:'q4',progress_callback:(p)=>{
        if(p && p.status){
          const file=p.file||p.name||'Model file';
          const progress=p.progress!=null?' '+Math.round(p.progress)+'%':'';
          $('aiProgress').textContent=file+' — '+p.status+progress;
        }
      }};
      // Mobile WebGPU support varies. Try WebGPU first where available, then retry on WASM.
      if(navigator.gpu){
        try{
          setAiStatus('WebGPU দিয়ে লোড হচ্ছে');
          aiPipeline=await mod.pipeline('text-generation',model,{...options,device:'webgpu'});
        }catch(gpuError){
          aiPipeline=null;
          $('aiProgress').textContent='WebGPU-তে চালু হয়নি; CPU/WASM দিয়ে আবার চেষ্টা করছি…';
          setAiStatus('CPU মোডে চেষ্টা হচ্ছে');
        }
      }
      if(!aiPipeline){
        setAiStatus('CPU/WASM দিয়ে লোড হচ্ছে');
        aiPipeline=await mod.pipeline('text-generation',model,{...options,device:'wasm'});
      }
      setAiStatus('AI প্রস্তুত','ready');
      $('aiProgress').textContent='AI মডেল লোড হয়েছে। একই ব্রাউজারের ক্যাশে অক্ষত থাকলে পরের বার অফলাইনে চালানো যাবে।';
      return aiPipeline;
    }catch(err){
      aiPipeline=null;setAiStatus('লোড হয়নি','error');
      const msg=err?.message||String(err);
      $('aiProgress').textContent='AI লোড হয়নি: '+msg+'। পরীক্ষা করুন: (১) HTTPS/localhost, (২) ইন্টারনেট ও পর্যাপ্ত ডেটা, (৩) অন্তত 2 GB ফাঁকা স্টোরেজ, (৪) ব্রাউজারের Cache/সাইট ডেটা মুছে যায়নি। এরপর আবার চেষ্টা করুন।';
      throw err;
    }finally{aiLoadPromise=null}
  })();
  return aiLoadPromise;
}
async function generateWithOfflineAI(prompt,subject,topic,type,level){
  const pipe=await loadOfflineAI();
  const instruction=type==='mcq'
    ? 'You are a careful tutor. Create a practice MCQ in Bengali for the requested topic. If the user gives a specific question, answer it cautiously. Give four options A-D and mark the likely correct answer with a brief explanation. If unsure, say you are unsure. Do not claim textbook accuracy.'
    : 'You are a helpful tutor. Answer the student question in Bengali at the appropriate level. Give a clear explanation, examples when useful, and say when you are uncertain. Do not invent citations or claim textbook accuracy.';
  const userPrompt=`শ্রেণি/স্তর: ${level}\nবিষয়: ${subject}\nটপিক: ${topic}\nশিক্ষার্থীর প্রশ্ন: ${prompt||topic}\nবাংলায় উত্তর দিন।`;
  const out=await pipe([{role:'system',content:instruction},{role:'user',content:userPrompt}],{max_new_tokens:320,temperature:0.3,do_sample:false});
  let textOut='';
  try{
    const generated=out?.[0]?.generated_text;
    if(Array.isArray(generated)){textOut=generated.filter(m=>m.role==='assistant').map(m=>m.content).join('\n')}
    else if(typeof generated==='string')textOut=generated;
    if(!textOut && out?.[0]?.generated_text)textOut=String(out[0].generated_text);
  }catch(e){}
  if(!textOut)textOut=JSON.stringify(out);
  return textOut.trim();
}

function normalizeText(s=''){return String(s).toLowerCase().replace(/[^\p{L}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim()}
function similarity(query, record){
  const q=normalizeText(query), hay=normalizeText([record.question,record.topic,record.subject,record.answer].join(' '));
  if(!q)return 0;
  if(hay.includes(q))return 10+q.length/100;
  const stop=new Set(['কি','কী','কেন','কিভাবে','ব্যাখ্যা','কর','করো','বল','লিখ','হলো','হয়','হয়','the','what','is','are','of','and','explain']);
  const words=[...new Set(q.split(' ').filter(w=>w.length>1&&!stop.has(w)))];
  if(!words.length)return 0;
  const hit=words.filter(w=>hay.includes(w)).length;
  return hit/words.length;
}
function answerFromKnowledge(query, subject, topic, type, level){
  const all=(data.knowledgeBase||[]).filter(k=>(!k.classLevel||k.classLevel===level||k.classLevel==='সব শ্রেণি')&&normalizeText(k.subject)===normalizeText(subject));
  const target=type==='mcq'?all.filter(k=>k.kind==='mcq'):all.filter(k=>k.kind!=='mcq');
  const ranked=target.map(k=>({k,score:Math.max(similarity(query,k),similarity(topic,k.topic+' '+k.question)*0.8)})).sort((a,b)=>b.score-a.score);
  if(ranked.length && ranked[0].score>=0.34){
    const k=ranked[0].k;
    if(type==='mcq'){
      const options=[['A',k.optionA],['B',k.optionB],['C',k.optionC],['D',k.optionD]].filter(x=>x[1]);
      return `মিল পাওয়া MCQ (Offline Knowledge Base)\nশ্রেণি: ${k.classLevel}\nবিষয়: ${k.subject}\nটপিক: ${k.topic}\n\nপ্রশ্ন: ${k.question}\n${options.map(o=>o[0]+') '+o[1]).join('\\n')}\n\nসঠিক উত্তর: ${k.correct||'ডেটাবেসে উল্লেখ নেই'}\nব্যাখ্যা: ${k.answer}`;
    }
    return `মিল পাওয়া উত্তর (Offline Knowledge Base)\nশ্রেণি: ${k.classLevel}\nবিষয়: ${k.subject}\nটপিক: ${k.topic}\n\nপ্রশ্ন: ${k.question}\n\nউত্তর:\n${k.answer}`;
  }
  // Safe fallback: never invent a factual answer.
  return `এই প্রশ্নের জন্য Offline Knowledge Base-এ নির্ভরযোগ্য মিল পাওয়া যায়নি।\n\nশ্রেণি: ${level}\nবিষয়: ${subject}\nটপিক: ${topic}\nপ্রশ্ন: ${query||topic}\n\nকরণীয়:\n১. Admin Panel → Offline Knowledge-এ গিয়ে বই অনুযায়ী যাচাইকৃত প্রশ্ন-উত্তর যোগ করুন।\n২. MCQ হলে প্রশ্ন, A/B/C/D অপশন এবং সঠিক উত্তর যোগ করুন।\n৩. তারপর আবার Get Answer চাপুন।\n\nনির্ভুলতা: ডেটাবেসে যোগ করা কনটেন্টের ওপর নির্ভরশীল।`;
}
function renderKnowledge(){
 const list=data.knowledgeBase||[];
 $('knowledgeList').innerHTML=list.length?list.map((k,i)=>`<div class="history-item"><b>${esc(k.classLevel)} · ${esc(k.subject)} · ${esc(k.topic)} · ${k.kind==='mcq'?'MCQ':'Q&A'}</b><div>${esc(k.question)}</div><p>${esc(k.answer)}</p><button class="danger" data-kb-delete="${i}">Delete</button></div>`).join(''):'<p class="muted">এখনও কোনো offline content যোগ করা হয়নি।</p>';
}

function bootUI(){
  fillClassSelect($('profileClass'));fillClassSelect($('practiceClass'));fillClassSelect($('adminClass'));
  $('practiceClass').value='Class 6';updateSubjects();
  if(!data.admins.length)show('setupView');else show('loginView');
}
function enter(user,role){session={id:user.id,role};$('logoutBtn').classList.remove('hidden');$('roleLabel').textContent=role==='admin'?'ADMIN DASHBOARD':'STUDENT DASHBOARD';$('welcomeTitle').textContent=role==='admin'?'Admin Dashboard':`স্বাগতম, ${user.name||user.id}`;$('userChip').textContent=user.id;
  document.querySelectorAll('.admin-only').forEach(x=>x.classList.toggle('hidden',role!=='admin'));
  document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('hidden',x.dataset.tab==='admin'&&role!=='admin'));
  if(role==='student')loadProfile();renderStudents();renderHistory();renderKnowledge();switchTab(role==='admin'?'admin':'profile');show('appView');
}
function switchTab(name){if((name==='admin'||name==='knowledge'||name==='manage')&&session?.role!=='admin')return;document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));document.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('hidden',p.id!==name+'Tab'))}
function loadProfile(){const s=currentStudent();if(!s)return;const f=$('profileForm');['name','studentId','classLevel','institution','roll','contact','about'].forEach(k=>{f.elements[k].value=k==='studentId'?s.id:(s.profile?.[k]|| (k==='classLevel'?s.classLevel:''))});$('practiceClass').value=s.profile?.classLevel||s.classLevel;updateSubjects()}
function updateSubjects(){const c=$('practiceClass').value;const subjects=SUBJECTS[c]||['সাধারণ জ্ঞান','অন্যান্য'];$('subjectSelect').innerHTML=subjects.map(s=>`<option>${esc(s)}</option>`).join('');$('topicSelect').innerHTML=TOPICS.map(s=>`<option>${esc(s)}</option>`).join('')}
function renderStudents(){if(!data.students.length){$('studentRows').innerHTML='<tr><td colspan="4">এখনও কোনো শিক্ষার্থী যোগ করা হয়নি।</td></tr>';return}$('studentRows').innerHTML=data.students.map(s=>`<tr><td>${esc(s.id)}</td><td>${esc(s.profile?.name||s.name||'—')}</td><td>${esc(s.profile?.classLevel||s.classLevel||'—')}</td><td><button class="secondary" data-reset="${esc(s.id)}">Password</button> <button class="secondary" data-class="${esc(s.id)}">Class</button> <button class="danger" data-delete="${esc(s.id)}">Delete</button></td></tr>`).join('');if($('adminHistoryList')){$('adminHistoryList').innerHTML=data.practice.slice().reverse().map((p,i)=>`<div class="history-item"><b>${esc(p.studentId)} · ${esc(p.classLevel)} · ${esc(p.subject)}</b><div>${esc(p.prompt||p.topic||'')}</div><p>${esc(p.answer||'')}</p><button class="danger" data-practice-delete="${esc(p.createdAt+'|'+p.studentId+'|'+i)}">Delete Practice</button></div>`).join('')||'<p class="muted">কোনো Practice History নেই।</p>'}}
function renderHistory(){const list=data.practice.filter(p=>p.studentId===session?.id).slice().reverse();$('historyList').innerHTML=list.length?list.map((p,i)=>`<div class="history-item"><b>${esc(p.classLevel)} · ${esc(p.subject)} · ${esc(p.type==='mcq'?'MCQ':'Question')}</b><div>${esc(p.topic)} — ${esc(p.prompt||'প্রশ্ন নেই')}</div><p>${esc(p.answer)}</p><small class="muted">${new Date(p.createdAt).toLocaleString()}</small> <button class="danger" data-own-practice-delete="${esc(p.createdAt+'|'+i)}">Delete</button></div>`).join(''):'<p class="muted">এখনও কোনো practice সেভ করা হয়নি।</p>'}
function generateOfflineAnswer(prompt,subject,topic,type,level){
  const p=prompt.trim();
  if(type==='mcq')return `অফলাইন MCQ Practice\nশ্রেণি: ${level}\nবিষয়: ${subject}\nটপিক: ${topic}\n\nপ্রশ্ন: ${p||topic+' সম্পর্কে সঠিক উত্তর নির্বাচন করুন।'}\n\nA) বিষয়টির মৌলিক ধারণা\nB) বিষয়টির একটি উদাহরণ\nC) বিষয়টির প্রয়োগ\nD) উপরের কোনোটিই নয়\n\nউত্তর: এই ডেমোতে নির্ভরযোগ্য উত্তর নির্ধারণের জন্য বিষয়ভিত্তিক MCQ ডেটাবেস নেই। বই/শিক্ষকের সহায়তায় উত্তর যাচাই করুন।`;
  return `অফলাইন স্টাডি গাইড\nশ্রেণি: ${level}\nবিষয়: ${subject}\nটপিক: ${topic}\n\nআপনার প্রশ্ন: ${p||topic+' ব্যাখ্যা কর।'}\n\nউত্তর লেখার কাঠামো:\n১. ভূমিকা: বিষয়টির সংক্ষিপ্ত পরিচয় দিন।\n২. মূল আলোচনা: সংজ্ঞা, বৈশিষ্ট্য, ধাপ বা কারণ ধারাবাহিকভাবে লিখুন।\n৩. উদাহরণ: পাঠ্যবই থেকে প্রাসঙ্গিক উদাহরণ দিন।\n৪. উপসংহার: মূল বক্তব্য সংক্ষেপে লিখুন।\n\nনোট: এটি কোনো প্রকৃত AI-উৎপন্ন বা বিষয়-যাচাইকৃত উত্তর নয়; এটি অফলাইন উত্তর লেখার কাঠামো। নির্দিষ্ট উত্তর পেতে বিষয়ভিত্তিক অফলাইন কনটেন্ট যোগ করুন।`;
}
$('setupForm').addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.target),id=f.get('adminId').trim();if(data.admins.some(a=>a.id.toLowerCase()===id.toLowerCase())){toast('এই Admin ID আগে থেকেই আছে');return}data.admins.push({id,pass:hash(f.get('password')),createdAt:new Date().toISOString()});await writeData();toast('Admin তৈরি হয়েছে');enter(data.admins[data.admins.length-1],'admin')});
$('loginForm').addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target),id=f.get('id').trim(),pass=hash(f.get('password'));const s=data.students.find(x=>x.id===id&&x.pass===pass);if(s){enter(s,'student');return}toast('Student ID বা পাসওয়ার্ড সঠিক নয়')});
$('adminLoginForm').addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target),id=f.get('id').trim(),pass=hash(f.get('password'));const a=data.admins.find(x=>x.id.toLowerCase()===id.toLowerCase()&&x.pass===pass);if(a){$('adminLoginForm').classList.add('hidden');enter(a,'admin');return}toast('Admin ID বা পাসওয়ার্ড সঠিক নয়')});
$('closeAdminLogin').addEventListener('click',()=>$('adminLoginForm').classList.add('hidden'));
let flowerTimer=null,flowerInterval=null,flowerHeld=false,flowerCountdownStarted=false;const flower=$('secretFlower');function stopFlower(){flowerHeld=false;if(flowerInterval)clearInterval(flowerInterval);flowerInterval=null;if(flowerTimer)clearTimeout(flowerTimer);flowerTimer=null;flowerCountdownStarted=false;if($('flowerCountdown')){$('flowerCountdown').textContent='';$('flowerCountdown').classList.remove('show')}flower?.classList.remove('holding')}function startFlower(){if(flowerHeld)return;flowerHeld=true;flower.classList.add('holding');$('flowerCountdown').textContent='';$('flowerCountdown').classList.remove('show');flowerTimer=setTimeout(()=>{if(!flowerHeld)return;flowerCountdownStarted=true;$('flowerCountdown').classList.add('show');let remaining=10;$('flowerCountdown').textContent=String(remaining);flowerInterval=setInterval(()=>{if(!flowerHeld){clearInterval(flowerInterval);flowerInterval=null;return}remaining--;if(remaining>0){$('flowerCountdown').textContent=String(remaining)}else{clearInterval(flowerInterval);flowerInterval=null;flowerTimer=null;flowerHeld=false;flowerCountdownStarted=false;flower.classList.remove('holding');$('flowerCountdown').textContent='';$('flowerCountdown').classList.remove('show');$('adminLoginForm').classList.remove('hidden');$('adminLoginForm').scrollIntoView({behavior:'smooth',block:'center'});$('adminLoginForm').elements.id.focus()}},1000)},5000)}flower.addEventListener('pointerdown',e=>{e.preventDefault();startFlower()});['pointerup','pointerleave','pointercancel'].forEach(ev=>flower.addEventListener(ev,stopFlower));
$('logoutBtn').addEventListener('click',()=>{session=null;$('logoutBtn').classList.add('hidden');show('loginView')});
$('tabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b)switchTab(b.dataset.tab)});
$('profileForm').addEventListener('submit',async e=>{e.preventDefault();if(session?.role!=='student')return;const s=currentStudent(),f=new FormData(e.target);s.profile={name:f.get('name').trim(),studentId:s.id,classLevel:f.get('classLevel'),institution:f.get('institution').trim(),roll:f.get('roll').trim(),contact:f.get('contact').trim(),about:f.get('about').trim()};s.name=s.profile.name;s.classLevel=s.profile.classLevel;await writeData();$('welcomeTitle').textContent='স্বাগতম, '+s.name;toast('প্রোফাইল সেভ হয়েছে')});
$('practiceClass').addEventListener('change',updateSubjects);
$('getAnswerBtn').addEventListener('click',async()=>{
 const level=$('practiceClass').value,subject=$('subjectSelect').value,topic=$('topicSelect').value,type=$('questionType').value,prompt=$('promptInput').value;
 const btn=$('getAnswerBtn');btn.disabled=true;btn.textContent='AI উত্তর তৈরি করছে…';$('answerBox').textContent='Offline AI উত্তর তৈরি করছে…';
 try{
   const answer=await generateWithOfflineAI(prompt,subject,topic,type,level);
   $('answerBox').textContent=answer;$('answerBox').dataset.answer=answer;$('aiProgress').textContent='উত্তর তৈরি সম্পন্ন। AI-এর উত্তর যাচাই করে নিন।';
 }catch(err){
   const fallback=answerFromKnowledge(prompt,subject,topic,type,level);
   $('answerBox').textContent='Generative AI চালু করা যায়নি। নিচে Offline Knowledge Base-এর ফলাফল দেখানো হলো।\n\n'+fallback;
   $('answerBox').dataset.answer=$('answerBox').textContent;
 }finally{btn.disabled=false;btn.textContent='Get Answer'}
}); 
$('loadAiBtn').addEventListener('click',async()=>{try{await loadOfflineAI();toast('Offline AI প্রস্তুত')}catch(e){toast('AI load হয়নি; বিস্তারিত status-এ দেখুন')}});
$('unloadAiBtn').addEventListener('click',()=>{aiPipeline=null;aiLoadPromise=null;setAiStatus('মডেল আনলোড','');$('aiProgress').textContent='মডেল র‍্যাম থেকে রেফারেন্স সরানো হয়েছে; browser cache মুছে ফেলা হয়নি।';toast('AI pipeline বন্ধ করা হয়েছে')});
$('savePracticeBtn').addEventListener('click',async()=>{if(!session){toast('আগে লগইন করুন');return}const answer=$('answerBox').dataset.answer;if(!answer){toast('আগে Get Answer চাপুন');return}data.practice.push({studentId:session.id,classLevel:$('practiceClass').value,subject:$('subjectSelect').value,topic:$('topicSelect').value,type:$('questionType').value,prompt:$('promptInput').value,answer,createdAt:new Date().toISOString()});await writeData();renderHistory();toast('Practice history সেভ হয়েছে')});
$('studentForm').addEventListener('submit',async e=>{e.preventDefault();if(session?.role!=='admin')return;const f=new FormData(e.target),id=f.get('id').trim();if(data.students.some(s=>s.id===id)||data.admins.some(a=>a.id===id)){toast('এই ID আগে থেকেই আছে');return}data.students.push({id,pass:hash(f.get('password')),name:f.get('name').trim(),classLevel:f.get('classLevel'),profile:null,createdAt:new Date().toISOString()});await writeData();e.target.reset();renderStudents();toast('Student যোগ হয়েছে')});
$('studentRows').addEventListener('click',async e=>{if(session?.role!=='admin')return;const id=e.target.dataset.delete;if(id){if(!confirm(`Student ${id} এবং তার Practice History মুছে ফেলবেন?`))return;data.students=data.students.filter(s=>s.id!==id);data.practice=data.practice.filter(p=>p.studentId!==id);await writeData();renderStudents();toast('Student মুছে ফেলা হয়েছে');return}const reset=e.target.dataset.reset;if(reset){const password=prompt(`${reset} এর নতুন পাসওয়ার্ড দিন (কমপক্ষে ৪ অক্ষর):`);if(password===null)return;if(password.length<4){toast('পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে');return}const st=data.students.find(s=>s.id===reset);if(st){st.pass=hash(password);await writeData();toast('Student password reset হয়েছে')}return}const cls=e.target.dataset.class;if(cls){const st=data.students.find(s=>s.id===cls);const level=prompt('নতুন শ্রেণি/স্তর লিখুন:',st?.classLevel||'Class 1');if(level&&st){st.classLevel=level;if(st.profile)st.profile.classLevel=level;await writeData();renderStudents();toast('শ্রেণি আপডেট হয়েছে')}}});
$('adminHistoryList').addEventListener('click',async e=>{if(session?.role!=='admin')return;const token=e.target.dataset.practiceDelete;if(!token)return;const parts=token.split('|'),idx=Number(parts[2]);const target=data.practice.slice().reverse()[idx];if(target&&confirm('এই Practice entry মুছবেন?')){data.practice=data.practice.filter(p=>p!==target);await writeData();renderStudents();toast('Practice মুছে ফেলা হয়েছে')}});
$('historyList').addEventListener('click',async e=>{const token=e.target.dataset.ownPracticeDelete;if(!token||session?.role!=='student')return;const parts=token.split('|'),idx=Number(parts[1]);const list=data.practice.filter(p=>p.studentId===session.id).slice().reverse();const target=list[idx];if(target&&confirm('এই Practice entry মুছবেন?')){data.practice=data.practice.filter(p=>p!==target);await writeData();renderHistory();toast('Practice মুছে ফেলা হয়েছে')}});
$('settingsForm').addEventListener('submit',async e=>{e.preventDefault();if(session?.role!=='admin')return;const f=new FormData(e.target);data.settings={appName:(f.get('appName')||'শিক্ষা Offline').trim(),announcement:(f.get('announcement')||'').trim(),modelId:(f.get('modelId')||DEFAULT_AI_MODEL).trim()};document.querySelector('.brand b').textContent=data.settings.appName;document.title=data.settings.appName;aiPipeline=null;aiLoadPromise=null;await writeData();toast('App settings সেভ হয়েছে')});
$('adminPasswordForm').addEventListener('submit',async e=>{e.preventDefault();if(session?.role!=='admin')return;const f=new FormData(e.target),a=data.admins.find(x=>x.id===session.id);if(!a||a.pass!==hash(f.get('oldPassword'))){toast('বর্তমান পাসওয়ার্ড সঠিক নয়');return}a.pass=hash(f.get('newPassword'));await writeData();e.target.reset();toast('Admin password আপডেট হয়েছে')});
$('clearAllPracticeBtn').addEventListener('click',async()=>{if(session?.role!=='admin'||!confirm('সব শিক্ষার্থীর সব Practice History স্থায়ীভাবে মুছবেন?'))return;data.practice=[];await writeData();renderStudents();renderHistory();toast('সব Practice History মুছে ফেলা হয়েছে')});

fillClassSelect($('kbClass'));
$('knowledgeForm').addEventListener('submit',async e=>{
 e.preventDefault();if(session?.role!=='admin'){toast('শুধু Admin কনটেন্ট যোগ করতে পারবেন');return}
 const f=new FormData(e.target),kind=f.get('kind'),correct=(f.get('correct')||'').trim().toUpperCase();
 if(kind==='mcq'&&correct&&!['A','B','C','D'].includes(correct)){toast('সঠিক উত্তর A, B, C অথবা D দিন');return}
 const item={classLevel:f.get('classLevel'),subject:f.get('subject').trim(),topic:f.get('topic').trim(),kind,question:f.get('question').trim(),answer:f.get('answer').trim(),optionA:f.get('optionA').trim(),optionB:f.get('optionB').trim(),optionC:f.get('optionC').trim(),optionD:f.get('optionD').trim(),correct,createdAt:new Date().toISOString()};
 data.knowledgeBase=data.knowledgeBase||[];data.knowledgeBase.push(item);await writeData();e.target.reset();fillClassSelect($('kbClass'));renderKnowledge();toast('Offline Knowledge Base-এ যোগ হয়েছে');
});
$('knowledgeList').addEventListener('click',async e=>{const idx=e.target.dataset.kbDelete;if(idx===undefined||session?.role!=='admin')return;if(!confirm('এই কনটেন্ট মুছবেন?'))return;data.knowledgeBase.splice(Number(idx),1);await writeData();renderKnowledge();toast('কনটেন্ট মুছে ফেলা হয়েছে')});
$('exportKnowledgeBtn').addEventListener('click',()=>{const blob=new Blob([JSON.stringify({version:1,knowledgeBase:data.knowledgeBase||[]},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='offline-knowledge-pack.json';a.click();URL.revokeObjectURL(url)});
$('importKnowledgeFile').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{const parsed=JSON.parse(await file.text());if(!Array.isArray(parsed.knowledgeBase))throw new Error('Invalid');data.knowledgeBase=data.knowledgeBase||[];data.knowledgeBase.push(...parsed.knowledgeBase);await writeData();renderKnowledge();toast('Knowledge pack import হয়েছে')}catch(err){toast('Knowledge pack ফাইল সঠিক নয়')}finally{e.target.value=''}});

$('exportBtn').addEventListener('click',()=>{const blob=new Blob([JSON.stringify({...data,exportedAt:new Date().toISOString()},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='shikkha-offline-backup.json';a.click();URL.revokeObjectURL(url);$('backupInfo').textContent='Backup export অনুরোধ করা হয়েছে। ফাইলটি Downloads-এ সংরক্ষণ করুন।'});
$('importFile').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{const parsed=JSON.parse(await file.text());if(!parsed||![1,2].includes(parsed.version)||!Array.isArray(parsed.admins)||!Array.isArray(parsed.students)||!Array.isArray(parsed.practice))throw new Error('Invalid');if(!confirm('বর্তমান ডেটা backup ফাইল দিয়ে প্রতিস্থাপন করবেন?'))return;data={version:3,defaultAdminSeeded:parsed.defaultAdminSeeded===true,admins:parsed.admins,students:parsed.students,practice:parsed.practice,knowledgeBase:parsed.knowledgeBase||[],settings:{appName:'শিক্ষা Offline',announcement:'',modelId:DEFAULT_AI_MODEL,...(parsed.settings||{})}};if(!data.defaultAdminSeeded){let a=data.admins.find(x=>String(x.id).toLowerCase()==='abir');if(a){a.id='Abir';a.pass=hash('Abir@123')}else data.admins.push({id:'Abir',pass:hash('Abir@123'),createdAt:new Date().toISOString()});data.defaultAdminSeeded=true}await writeData();session=null;toast('Backup import হয়েছে। আবার লগইন করুন।');bootUI()}catch(err){toast('Backup ফাইলটি সঠিক নয়')}finally{e.target.value=''}});
(async()=>{try{db=await openDB();const saved=await readData();if(saved)data={version:3,defaultAdminSeeded:saved.defaultAdminSeeded===true,admins:saved.admins||[],students:saved.students||[],practice:saved.practice||[],knowledgeBase:saved.knowledgeBase||[],settings:{appName:'শিক্ষা Offline',announcement:'',modelId:DEFAULT_AI_MODEL,...(saved.settings||{})}};if(!data.settings.modelId||data.settings.modelId==='onnx-community/SmolLM2-1.7B-Instruct')data.settings.modelId=DEFAULT_AI_MODEL;if(!data.defaultAdminSeeded){let a=data.admins.find(x=>String(x.id).toLowerCase()==='abir');if(a){a.id='Abir';a.pass=hash('Abir@123')}else{data.admins.push({id:'Abir',pass:hash('Abir@123'),createdAt:new Date().toISOString()})}data.defaultAdminSeeded=true;await writeData()}bootUI();document.querySelector('.brand b').textContent=data.settings.appName;document.title=data.settings.appName;const sf=$('settingsForm');if(sf){sf.elements.appName.value=data.settings.appName;sf.elements.announcement.value=data.settings.announcement;sf.elements.modelId.value=data.settings.modelId}}catch(e){show('setupView');toast('এই ব্রাউজারে IndexedDB চালু করা যাচ্ছে না')}})();
if('serviceWorker' in navigator && location.protocol!=='file:'){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))}
