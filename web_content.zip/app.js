(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const ui = {
    audioInput: $('audioInput'),
    systemAudio: $('systemAudio'),
    microphoneEnabled: $('microphoneEnabled'),
    allowMicButton: $('allowMicButton'),
    screenIndicator: $('screenIndicator'),
    screenIndicatorText: $('screenIndicatorText'),
    micIndicator: $('micIndicator'),
    micIndicatorText: $('micIndicatorText'),
    systemIndicator: $('systemIndicator'),
    systemIndicatorText: $('systemIndicatorText'),
    setupTag: $('setupTag'),
    micMeter: $('micMeter'),
    systemMeter: $('systemMeter'),
    micMeterState: $('micMeterState'),
    systemMeterState: $('systemMeterState'),
    micMeterDot: $('micMeterDot'),
    systemMeterDot: $('systemMeterDot'),
    previewFrame: $('previewFrame'),
    preview: $('recordingPreview'),
    previewPlaceholder: $('previewPlaceholder'),
    previewTitle: $('previewTitle'),
    previewSubtitle: $('previewSubtitle'),
    recordState: $('recordState'),
    recordStateText: $('recordStateText'),
    elapsedTime: $('elapsedTime'),
    timerStatus: $('timerStatus'),
    timerStatusDot: $('timerStatusDot'),
    startButton: $('startButton'),
    transportActions: $('transportActions'),
    pauseButton: $('pauseButton'),
    stopButton: $('stopButton'),
    reviewActions: $('reviewActions'),
    downloadButton: $('downloadButton'),
    newRecordingButton: $('newRecordingButton'),
    actionHint: $('actionHint'),
    fileDetail: $('fileDetail'),
    fileName: $('fileName'),
    fileMeta: $('fileMeta'),
    captureFootnote: $('captureFootnote'),
    errorMessage: $('errorMessage'),
    supportText: $('supportText'),
    micMeterTrack: document.querySelector('[aria-label="Microphone input level"]'),
    systemMeterTrack: document.querySelector('[aria-label="System audio input level"]'),
  };

  let recorder = null;
  let displayStream = null;
  let micStream = null;
  let audioContext = null;
  let meterAnimation = 0;
  let meterAnalysers = {};
  let chunks = [];
  let finishedBlob = null;
  let previewUrl = null;
  let timerInterval = null;
  let startedAt = 0;
  let pausedAt = 0;
  let pausedDuration = 0;
  let captureState = 'ready';
  let micPermissionGranted = false;

  const mediaAvailable = Boolean(navigator.mediaDevices);
  const displayAvailable = Boolean(mediaAvailable && navigator.mediaDevices.getDisplayMedia);
  const audioContextAvailable = Boolean(window.AudioContext || window.webkitAudioContext);

  function setIndicator(element, textElement, tone, text) {
    if (!element || !textElement) return;
    element.className = `status-indicator status-${tone}`;
    textElement.textContent = text;
  }

  function setRecordState(state, label) {
    ui.recordState.className = `record-state state-${state}`;
    ui.recordStateText.textContent = label;
  }

  function setError(message) {
    ui.errorMessage.textContent = message;
    ui.errorMessage.hidden = !message;
  }

  function updateMicControls() {
    const enabled = ui.microphoneEnabled.checked;
    ui.audioInput.disabled = !enabled || captureState === 'capturing' || captureState === 'paused';
    ui.allowMicButton.disabled = !enabled || captureState === 'capturing' || captureState === 'paused';
    if (!enabled && captureState === 'ready') {
      setIndicator(ui.micIndicator, ui.micIndicatorText, 'neutral', 'Turned off');
      ui.micMeterState.textContent = 'Off';
      ui.micMeter.style.width = '0%';
    } else if (enabled && captureState === 'ready') {
      setIndicator(ui.micIndicator, ui.micIndicatorText, micPermissionGranted ? 'good' : 'neutral', micPermissionGranted ? 'Microphone ready' : 'Permission needed');
      ui.micMeterState.textContent = micPermissionGranted ? 'Ready' : 'Waiting';
    }
    ui.systemAudio.disabled = captureState === 'capturing' || captureState === 'paused';
  }

  async function refreshMicrophones({ keepSelection = true } = {}) {
    if (!mediaAvailable || !navigator.mediaDevices.enumerateDevices) return;
    const previous = keepSelection ? ui.audioInput.value : '';
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const microphones = devices.filter((device) => device.kind === 'audioinput');
      ui.audioInput.replaceChildren();
      const defaultOption = document.createElement('option');
      defaultOption.value = '';
      defaultOption.textContent = 'Default microphone';
      ui.audioInput.append(defaultOption);
      microphones.forEach((device, index) => {
        const option = document.createElement('option');
        option.value = device.deviceId;
        option.textContent = device.label || `Microphone ${index + 1}`;
        ui.audioInput.append(option);
      });
      if (previous && microphones.some((device) => device.deviceId === previous)) {
        ui.audioInput.value = previous;
      }
      if (microphones.length === 0 && captureState === 'ready' && ui.microphoneEnabled.checked) {
        setIndicator(ui.micIndicator, ui.micIndicatorText, 'warn', 'No input found');
      }
    } catch (_) {
      // Device names can be hidden until the browser grants microphone permission.
    }
  }

  function formatTime(milliseconds) {
    const seconds = Math.max(0, Math.floor(milliseconds / 1000));
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remaining = seconds % 60;
    return hours > 0
      ? `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(remaining).padStart(2, '0')}`
      : `${String(minutes).padStart(2, '0')}:${String(remaining).padStart(2, '0')}`;
  }

  function currentElapsed() {
    if (!startedAt) return 0;
    const until = captureState === 'paused' ? pausedAt : Date.now();
    return Math.max(0, until - startedAt - pausedDuration);
  }

  function updateTimer() {
    ui.elapsedTime.textContent = formatTime(currentElapsed());
  }

  function setTimerStatus(text, state = '') {
    ui.timerStatus.textContent = text;
    ui.timerStatus.className = `timer-caption ${state ? `is-${state}` : ''}`;
  }

  function setBusy(busy) {
    ui.startButton.disabled = busy;
    ui.startButton.querySelector('span:nth-child(2)').textContent = busy ? 'Opening capture permissions…' : 'Choose screen & start';
    ui.setupTag.innerHTML = busy ? '<i></i> REQUESTING ACCESS' : '<i></i> READY WHEN YOU ARE';
  }

  function stopTracks(stream) {
    if (!stream) return;
    stream.getTracks().forEach((track) => {
      try { track.stop(); } catch (_) { /* Track may already be closed. */ }
    });
  }

  function errorText(error, source) {
    if (error && error.name === 'NotAllowedError') {
      return source === 'screen'
        ? 'Screen sharing was cancelled or blocked. Choose a screen, window, or tab in the browser picker, then try again.'
        : 'Microphone permission was denied. Allow microphone access in your browser settings, or turn off “Record microphone” and try again.';
    }
    if (error && error.name === 'NotFoundError') {
      return source === 'screen'
        ? 'No shareable screen source was found. Try another browser or device.'
        : 'No microphone was found. Connect an input device, choose another microphone, or turn off microphone recording.';
    }
    if (error && error.name === 'NotReadableError') {
      return source === 'screen'
        ? 'The selected screen could not be read. Close other screen-capture apps and try again.'
        : 'The microphone could not be opened. It may be in use by another app.';
    }
    if (error && error.name === 'InvalidStateError') {
      return 'The browser could not start capture from this page state. Click the start button again.';
    }
    if (error && error.name === 'SecurityError') {
      return 'Screen capture requires a secure browser page. Open this app over HTTPS or from localhost.';
    }
    return source === 'screen'
      ? 'The browser could not start screen capture. Check browser support and permissions, then try again.'
      : 'The microphone could not be opened. Check your browser permissions and selected input device.';
  }

  function selectedMimeType() {
    if (!window.MediaRecorder || !MediaRecorder.isTypeSupported) return '';
    const options = [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm',
      'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
      'video/mp4',
    ];
    return options.find((type) => MediaRecorder.isTypeSupported(type)) || '';
  }

  function mixAudioSources(screenAudioTracks, microphoneTracks) {
    const hasScreen = screenAudioTracks.length > 0;
    const hasMic = microphoneTracks.length > 0;
    if (!hasScreen && !hasMic) return { stream: null, context: null, analysers: {} };

    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) {
      // Fallback is for unusual browsers; standard desktop browsers support Web Audio.
      return { stream: new MediaStream([...screenAudioTracks, ...microphoneTracks]), context: null, analysers: {} };
    }

    const context = new AudioContextClass();
    const destination = context.createMediaStreamDestination();
    const analysers = {};
    const gainValue = hasScreen && hasMic ? 0.72 : 1;

    const connectSource = (tracks, name) => {
      if (!tracks.length) return;
      const inputStream = new MediaStream(tracks);
      const source = context.createMediaStreamSource(inputStream);
      const gain = context.createGain();
      const analyser = context.createAnalyser();
      analyser.fftSize = 256;
      gain.gain.value = gainValue;
      source.connect(gain);
      gain.connect(destination);
      gain.connect(analyser);
      analysers[name] = analyser;
    };

    connectSource(screenAudioTracks, 'system');
    connectSource(microphoneTracks, 'mic');
    return { stream: destination.stream, context, analysers };
  }

  function setMeter(element, track, analyser, stateElement, valueElement) {
    let level = 0;
    if (analyser && audioContext && audioContext.state === 'running') {
      const values = new Uint8Array(analyser.fftSize);
      analyser.getByteTimeDomainData(values);
      let sum = 0;
      for (let i = 0; i < values.length; i += 1) {
        const sample = (values[i] - 128) / 128;
        sum += sample * sample;
      }
      level = Math.min(100, Math.round(Math.sqrt(sum / values.length) * 370));
    }
    element.style.width = `${level}%`;
    const meterTrack = valueElement === ui.micMeter ? ui.micMeterTrack : ui.systemMeterTrack;
    if (meterTrack) meterTrack.setAttribute('aria-valuenow', String(level));
    const live = Boolean(track && track.readyState === 'live');
    const dot = valueElement === ui.micMeter ? ui.micMeterDot : ui.systemMeterDot;
    dot.classList.toggle('is-live', live);
    stateElement.textContent = !live ? 'Waiting' : level > 2 ? `${level}%` : 'Live';
  }

  function animateMeters() {
    if (captureState !== 'capturing') return;
    const micTrack = micStream && micStream.getAudioTracks()[0];
    const systemTrack = displayStream && displayStream.getAudioTracks()[0];
    setMeter(ui.micMeter, micTrack, meterAnalysers.mic, ui.micMeterState, ui.micMeter);
    setMeter(ui.systemMeter, systemTrack, meterAnalysers.system, ui.systemMeterState, ui.systemMeter);
    meterAnimation = requestAnimationFrame(animateMeters);
  }

  async function startCapture() {
    setError('');
    if (!displayAvailable) {
      setError('This browser does not provide screen capture. Open Softwave Studio in a recent desktop browser over HTTPS.');
      return;
    }
    if (!window.MediaRecorder) {
      setError('Recording is not supported in this browser. Try a recent version of Chrome, Edge, Firefox, or Safari.');
      return;
    }
    if (captureState !== 'ready') return;

    setBusy(true);
    let screenRequest;
    let microphoneRequest;
    const wantsMic = ui.microphoneEnabled.checked;
    const wantsSystemAudio = ui.systemAudio.checked;

    // Start both browser permission requests directly from the user's button click.
    try {
      screenRequest = navigator.mediaDevices.getDisplayMedia({ video: true, audio: wantsSystemAudio });
    } catch (error) {
      setBusy(false);
      setError(errorText(error, 'screen'));
      return;
    }
    if (wantsMic) {
      const audio = ui.audioInput.value ? { deviceId: { exact: ui.audioInput.value } } : true;
      try {
        microphoneRequest = navigator.mediaDevices.getUserMedia({ audio, video: false });
      } catch (error) {
        microphoneRequest = Promise.reject(error);
      }
    } else {
      microphoneRequest = Promise.resolve(null);
    }

    const results = await Promise.allSettled([screenRequest, microphoneRequest]);
    const screenResult = results[0];
    const microphoneResult = results[1];
    if (screenResult.status === 'rejected' || microphoneResult.status === 'rejected') {
      if (screenResult.status === 'fulfilled') stopTracks(screenResult.value);
      if (microphoneResult.status === 'fulfilled' && microphoneResult.value) stopTracks(microphoneResult.value);
      setBusy(false);
      const source = screenResult.status === 'rejected' ? 'screen' : 'mic';
      setError(errorText(source === 'screen' ? screenResult.reason : microphoneResult.reason, source));
      if (source === 'mic') setIndicator(ui.micIndicator, ui.micIndicatorText, 'bad', 'Access blocked');
      return;
    }

    displayStream = screenResult.value;
    micStream = microphoneResult.value;
    if (!displayStream.getVideoTracks().length) {
      stopTracks(displayStream);
      stopTracks(micStream);
      displayStream = null;
      micStream = null;
      setBusy(false);
      setError('The browser did not provide a video track. Choose a screen or window and try again.');
      return;
    }

    try {
      const mixed = mixAudioSources(displayStream.getAudioTracks(), micStream ? micStream.getAudioTracks() : []);
      audioContext = mixed.context;
      meterAnalysers = mixed.analysers;
      if (audioContext && audioContext.state === 'suspended') await audioContext.resume();

      const recordedTracks = [...displayStream.getVideoTracks()];
      if (mixed.stream) recordedTracks.push(...mixed.stream.getAudioTracks());
      const recordingStream = new MediaStream(recordedTracks);
      const mimeType = selectedMimeType();
      recorder = mimeType ? new MediaRecorder(recordingStream, { mimeType }) : new MediaRecorder(recordingStream);
      chunks = [];
      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) chunks.push(event.data);
      };
      recorder.onerror = () => {
        setError('A recording error occurred. Stop the capture and try again.');
      };
      recorder.onstop = finishCapture;
      recorder.start(1000);
    } catch (error) {
      stopTracks(displayStream);
      stopTracks(micStream);
      displayStream = null;
      micStream = null;
      if (audioContext) audioContext.close().catch(() => {});
      audioContext = null;
      setBusy(false);
      setError(error && error.name === 'NotSupportedError'
        ? 'This browser cannot encode the selected recording format. Try an up-to-date desktop browser.'
        : 'Capture could not start. Check your browser permissions and try again.');
      return;
    }

    captureState = 'capturing';
    startedAt = Date.now();
    pausedDuration = 0;
    ui.preview.srcObject = displayStream;
    ui.preview.muted = true;
    ui.preview.controls = false;
    ui.preview.play().catch(() => {});
    ui.previewFrame.classList.add('is-live');
    ui.previewFrame.classList.remove('has-video');
    ui.previewTitle.textContent = 'Capturing your screen';
    ui.previewSubtitle.textContent = 'This preview is visible only in your browser.';
    setRecordState('recording', 'RECORDING');
    setTimerStatus('Recording in progress', 'recording');
    setIndicator(ui.screenIndicator, ui.screenIndicatorText, 'good', 'Sharing');
    if (micStream && micStream.getAudioTracks().length) {
      micPermissionGranted = true;
      setIndicator(ui.micIndicator, ui.micIndicatorText, 'good', 'Microphone live');
    } else {
      setIndicator(ui.micIndicator, ui.micIndicatorText, 'neutral', 'Turned off');
    }
    if (displayStream.getAudioTracks().length) {
      setIndicator(ui.systemIndicator, ui.systemIndicatorText, 'good', 'Audio captured');
      ui.systemMeterState.textContent = 'Live';
    } else if (wantsSystemAudio) {
      setIndicator(ui.systemIndicator, ui.systemIndicatorText, 'warn', 'Not shared');
      ui.systemMeterState.textContent = 'Not available';
      ui.supportText.textContent = 'Your shared source did not provide system audio. You can continue with the microphone, or stop and choose a source with audio enabled in the browser picker.';
    } else {
      setIndicator(ui.systemIndicator, ui.systemIndicatorText, 'neutral', 'Turned off');
    }
    ui.startButton.hidden = true;
    ui.transportActions.hidden = false;
    ui.reviewActions.hidden = true;
    ui.actionHint.textContent = 'Your recording is local to this browser. Stop sharing or press Stop when you are done.';
    ui.fileDetail.hidden = true;
    ui.captureFootnote.hidden = true;
    setBusy(false);
    updateMicControls();
    timerInterval = window.setInterval(updateTimer, 250);
    meterAnimation = requestAnimationFrame(animateMeters);

    const videoTrack = displayStream.getVideoTracks()[0];
    videoTrack.addEventListener('ended', () => {
      if (recorder && recorder.state !== 'inactive') stopCapture();
    }, { once: true });
    refreshMicrophones();
  }

  function stopCapture() {
    if (recorder && recorder.state !== 'inactive') {
      try { recorder.stop(); } catch (_) { finishCapture(); }
    } else {
      finishCapture();
    }
    stopTracks(displayStream);
    stopTracks(micStream);
  }

  function finishCapture() {
    if (captureState === 'ready' || captureState === 'review') return;
    window.clearInterval(timerInterval);
    timerInterval = null;
    window.cancelAnimationFrame(meterAnimation);
    const duration = currentElapsed();
    const mimeType = (recorder && recorder.mimeType) || (chunks[0] && chunks[0].type) || 'video/webm';
    if (chunks.length) {
      finishedBlob = new Blob(chunks, { type: mimeType });
    }
    if (ui.preview.srcObject) ui.preview.srcObject = null;
    stopTracks(displayStream);
    stopTracks(micStream);
    displayStream = null;
    micStream = null;
    meterAnalysers = {};
    if (audioContext) {
      audioContext.close().catch(() => {});
      audioContext = null;
    }
    captureState = finishedBlob && finishedBlob.size ? 'review' : 'ready';
    ui.previewFrame.classList.remove('is-live');
    ui.preview.pause();
    if (finishedBlob && finishedBlob.size) {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      previewUrl = URL.createObjectURL(finishedBlob);
      ui.preview.src = previewUrl;
      ui.preview.controls = true;
      ui.preview.muted = false;
      ui.preview.load();
      ui.previewFrame.classList.add('has-video');
      ui.previewTitle.textContent = 'Your recording is ready';
      ui.previewSubtitle.textContent = 'Preview it here before saving your video.';
      setRecordState('done', 'READY TO REVIEW');
      setTimerStatus(`Recording complete · ${formatTime(duration)}`);
      ui.fileDetail.hidden = false;
      ui.fileName.textContent = `softwave-recording.${fileExtension(mimeType)}`;
      ui.fileMeta.textContent = `${formatBytes(finishedBlob.size)} · ${formatTime(duration)} · saved on this device when you download`;
      ui.startButton.hidden = true;
      ui.transportActions.hidden = true;
      ui.reviewActions.hidden = false;
      ui.actionHint.textContent = 'Preview your video, then save a copy to your device.';
      ui.captureFootnote.hidden = true;
      setIndicator(ui.screenIndicator, ui.screenIndicatorText, 'neutral', 'Capture complete');
      if (ui.microphoneEnabled.checked && micPermissionGranted) {
        setIndicator(ui.micIndicator, ui.micIndicatorText, 'good', 'Microphone ready');
      } else if (!ui.microphoneEnabled.checked) {
        setIndicator(ui.micIndicator, ui.micIndicatorText, 'neutral', 'Turned off');
      }
    } else {
      captureState = 'ready';
      setRecordState('ready', 'STANDING BY');
      setTimerStatus('Ready to record');
      ui.elapsedTime.textContent = '00:00';
      ui.startButton.hidden = false;
      ui.transportActions.hidden = true;
      ui.reviewActions.hidden = true;
      ui.actionHint.textContent = 'No video data was received. Choose a source and try again.';
      setError('The recording did not contain any video data. Try a different share source.');
      setIndicator(ui.screenIndicator, ui.screenIndicatorText, 'neutral', 'Not sharing');
    }
    updateMicControls();
  }

  function pauseCapture() {
    if (!recorder || recorder.state !== 'recording') return;
    recorder.pause();
    captureState = 'paused';
    pausedAt = Date.now();
    window.cancelAnimationFrame(meterAnimation);
    setRecordState('paused', 'PAUSED');
    setTimerStatus('Recording paused', 'paused');
    ui.pauseButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 10 6-10 6V6Z" fill="currentColor" stroke="none"/></svg><span>Resume</span>';
    ui.preview.pause();
    updateMicControls();
  }

  function resumeCapture() {
    if (!recorder || recorder.state !== 'paused') return;
    recorder.resume();
    pausedDuration += Date.now() - pausedAt;
    pausedAt = 0;
    captureState = 'capturing';
    setRecordState('recording', 'RECORDING');
    setTimerStatus('Recording in progress', 'recording');
    ui.pauseButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6v12M15 6v12"/></svg><span>Pause</span>';
    ui.preview.play().catch(() => {});
    updateMicControls();
    meterAnimation = requestAnimationFrame(animateMeters);
  }

  function fileExtension(mimeType) {
    return mimeType.includes('mp4') ? 'mp4' : 'webm';
  }

  function formatBytes(bytes) {
    if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  function downloadRecording() {
    if (!finishedBlob || !finishedBlob.size) return;
    const url = URL.createObjectURL(finishedBlob);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `softwave-recording-${stamp}.${fileExtension(finishedBlob.type)}`;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function startNewRecording() {
    if (captureState === 'capturing' || captureState === 'paused') return;
    window.clearInterval(timerInterval);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = null;
    finishedBlob = null;
    chunks = [];
    recorder = null;
    captureState = 'ready';
    startedAt = 0;
    pausedAt = 0;
    pausedDuration = 0;
    ui.preview.pause();
    ui.preview.removeAttribute('src');
    ui.preview.srcObject = null;
    ui.preview.controls = false;
    ui.preview.muted = true;
    ui.preview.load();
    ui.previewFrame.classList.remove('has-video', 'is-live');
    ui.elapsedTime.textContent = '00:00';
    setRecordState('ready', 'STANDING BY');
    setTimerStatus('Ready to record');
    setIndicator(ui.screenIndicator, ui.screenIndicatorText, 'neutral', 'Not sharing');
    setIndicator(ui.systemIndicator, ui.systemIndicatorText, 'neutral', ui.systemAudio.checked ? 'Select a source' : 'Turned off');
    if (ui.microphoneEnabled.checked) {
      setIndicator(ui.micIndicator, ui.micIndicatorText, micPermissionGranted ? 'good' : 'neutral', micPermissionGranted ? 'Microphone ready' : 'Permission needed');
    }
    ui.previewTitle.textContent = 'Your preview will appear here';
    ui.previewSubtitle.textContent = 'Set your audio, then choose what to share.';
    ui.startButton.hidden = false;
    ui.transportActions.hidden = true;
    ui.reviewActions.hidden = true;
    ui.actionHint.textContent = 'The browser will ask you what to share before recording begins.';
    ui.fileDetail.hidden = true;
    ui.captureFootnote.hidden = false;
    ui.supportText.textContent = displayAvailable
      ? 'For the best experience, use a desktop browser and allow screen and microphone access when prompted.'
      : 'This browser does not appear to support screen capture. Open this page in a recent desktop browser over HTTPS.';
    setError('');
    updateMicControls();
  }

  async function allowMicrophone() {
    if (!ui.microphoneEnabled.checked || captureState !== 'ready') return;
    if (!mediaAvailable || !navigator.mediaDevices.getUserMedia) {
      setIndicator(ui.micIndicator, ui.micIndicatorText, 'bad', 'Not supported');
      setError('This browser does not provide microphone access. Use a recent browser over HTTPS or localhost.');
      return;
    }
    ui.allowMicButton.disabled = true;
    ui.allowMicButton.textContent = 'Checking…';
    setError('');
    try {
      const temporaryStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      stopTracks(temporaryStream);
      micPermissionGranted = true;
      await refreshMicrophones({ keepSelection: false });
      setIndicator(ui.micIndicator, ui.micIndicatorText, 'good', 'Microphone ready');
      ui.micMeterState.textContent = 'Ready';
    } catch (error) {
      setIndicator(ui.micIndicator, ui.micIndicatorText, 'bad', 'Access blocked');
      setError(errorText(error, 'mic'));
    } finally {
      ui.allowMicButton.disabled = !ui.microphoneEnabled.checked;
      ui.allowMicButton.textContent = 'Allow mic';
    }
  }

  function initialize() {
    setIndicator(ui.screenIndicator, ui.screenIndicatorText, displayAvailable ? 'neutral' : 'bad', displayAvailable ? 'Not sharing' : 'Not supported');
    setIndicator(ui.micIndicator, ui.micIndicatorText, mediaAvailable ? 'neutral' : 'bad', mediaAvailable ? 'Permission needed' : 'Not supported');
    setIndicator(ui.systemIndicator, ui.systemIndicatorText, ui.systemAudio.checked ? 'warn' : 'neutral', ui.systemAudio.checked ? 'Browser dependent' : 'Turned off');
    if (!displayAvailable || !window.MediaRecorder) {
      ui.supportText.textContent = 'Screen recording is unavailable in this browser. Try a recent desktop browser over HTTPS.';
    }
    if (!audioContextAvailable) {
      ui.supportText.textContent = 'This browser may not be able to mix microphone and system audio. Use a recent desktop Chrome or Edge browser for the most reliable results.';
    }
    refreshMicrophones({ keepSelection: false });
    updateMicControls();

    ui.startButton.addEventListener('click', startCapture);
    ui.pauseButton.addEventListener('click', () => captureState === 'paused' ? resumeCapture() : pauseCapture());
    ui.stopButton.addEventListener('click', stopCapture);
    ui.downloadButton.addEventListener('click', downloadRecording);
    ui.newRecordingButton.addEventListener('click', startNewRecording);
    ui.allowMicButton.addEventListener('click', allowMicrophone);
    ui.microphoneEnabled.addEventListener('change', updateMicControls);
    ui.systemAudio.addEventListener('change', () => {
      if (captureState === 'ready') {
        setIndicator(ui.systemIndicator, ui.systemIndicatorText, ui.systemAudio.checked ? 'warn' : 'neutral', ui.systemAudio.checked ? 'Browser dependent' : 'Turned off');
      }
    });
    ui.audioInput.addEventListener('change', () => {
      if (ui.audioInput.value) setIndicator(ui.micIndicator, ui.micIndicatorText, micPermissionGranted ? 'good' : 'neutral', micPermissionGranted ? 'Microphone ready' : 'Input selected');
    });
    if (mediaAvailable && navigator.mediaDevices.addEventListener) {
      navigator.mediaDevices.addEventListener('devicechange', () => refreshMicrophones());
    }
    window.addEventListener('beforeunload', (event) => {
      if (captureState === 'capturing' || captureState === 'paused') {
        event.preventDefault();
        event.returnValue = '';
      }
    });
  }

  initialize();
})();
