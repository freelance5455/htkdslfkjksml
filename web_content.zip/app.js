/* Stockly v4 — Sales vs Owner · Anti-theft · Themes · Calendar */
const KEY = 'stockly_elites_v4';
const OWNER_PIN = 'childrenofthesun';

const THEMES = ['emerald', 'ocean', 'sunset', 'midnight', 'light'];

const DEFAULT_MENU = [
  { name: 'Bread loaf', cat: 'Ingredients', type: 'Ingredient', cost: 18, sell: 0, unit: 'loaf', stock: 8, low: 2 },
  { name: 'Polony', cat: 'Ingredients', type: 'Ingredient', cost: 1, sell: 1, unit: 'slice', stock: 120, low: 20 },
  { name: 'Russian', cat: 'Ingredients', type: 'Ingredient', cost: 8, sell: 10, unit: 'unit', stock: 40, low: 10 },
  { name: 'Vienna', cat: 'Ingredients', type: 'Ingredient', cost: 5, sell: 0, unit: 'unit', stock: 35, low: 8 },
  { name: 'Cheese', cat: 'Ingredients', type: 'Ingredient', cost: 2.5, sell: 3, unit: 'slice', stock: 80, low: 15 },
  { name: 'Atchaar', cat: 'Ingredients', type: 'Ingredient', cost: 0.8, sell: 0, unit: 'portion', stock: 60, low: 12 },
  { name: 'Chakalaka', cat: 'Ingredients', type: 'Ingredient', cost: 0.9, sell: 0, unit: 'portion', stock: 50, low: 12 },
  { name: 'Chicken pattie', cat: 'Ingredients', type: 'Ingredient', cost: 12, sell: 0, unit: 'unit', stock: 25, low: 8 },
  { name: 'Beef pattie', cat: 'Ingredients', type: 'Ingredient', cost: 14, sell: 0, unit: 'unit', stock: 20, low: 6 },
  { name: 'Bun', cat: 'Ingredients', type: 'Ingredient', cost: 3, sell: 0, unit: 'unit', stock: 40, low: 10 },
  { name: 'Lettuce', cat: 'Ingredients', type: 'Ingredient', cost: 0.5, sell: 0, unit: 'portion', stock: 40, low: 10 },
  { name: 'Tomato', cat: 'Ingredients', type: 'Ingredient', cost: 0.4, sell: 0, unit: 'slice', stock: 80, low: 20 },
  { name: 'Onion', cat: 'Ingredients', type: 'Ingredient', cost: 0.3, sell: 0, unit: 'portion', stock: 50, low: 12 },
  { name: 'Potatoes', cat: 'Ingredients', type: 'Ingredient', cost: 0.02, sell: 0, unit: 'g', stock: 12000, low: 2000 },
  { name: 'Oil', cat: 'Ingredients', type: 'Ingredient', cost: 0.01, sell: 0, unit: 'ml', stock: 5000, low: 800 },
  { name: 'Packaging', cat: 'Packaging', type: 'Packaging', cost: 1.2, sell: 0, unit: 'unit', stock: 100, low: 20 },
  { name: 'Kota R15', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 15, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R20', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 20, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R25', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 25, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R30', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 30, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R35', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R40', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 40, unit: 'unit', stock: 0, low: 0 },
  { name: 'Plain Hotdog', cat: 'Hotdogs', type: 'Menu Product', cost: 0, sell: 10, unit: 'unit', stock: 0, low: 0 },
  { name: 'Hotdog Lettuce & Cheese', cat: 'Hotdogs', type: 'Menu Product', cost: 0, sell: 20, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chips Small', cat: 'Chips', type: 'Menu Product', cost: 0, sell: 20, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chips Medium', cat: 'Chips', type: 'Menu Product', cost: 0, sell: 30, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chips Large', cat: 'Chips', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chicken Burger', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0 },
  { name: 'Beef Burger', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 40, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chicken Burger + Chips', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 50, unit: 'unit', stock: 0, low: 0 },
  { name: 'Beef Burger + Chips', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 55, unit: 'unit', stock: 0, low: 0 },
  { name: 'Club Sandwich', cat: 'Sandwiches', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0 },
  { name: 'Extra Polony', cat: 'Extras', type: 'Other', cost: 1, sell: 1, unit: 'unit', stock: 0, low: 0 },
  { name: 'Extra Special', cat: 'Extras', type: 'Other', cost: 1.5, sell: 2, unit: 'unit', stock: 0, low: 0 },
  { name: 'Extra Cheese', cat: 'Extras', type: 'Other', cost: 2.5, sell: 3, unit: 'unit', stock: 0, low: 0 },
  { name: 'Extra Russian', cat: 'Extras', type: 'Other', cost: 8, sell: 10, unit: 'unit', stock: 0, low: 0 },
];

const DEFAULT_RECIPES = {
  'Kota R15': [['Bread loaf', 0.15], ['Polony', 2], ['Atchaar', 1], ['Packaging', 1]],
  'Kota R20': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Vienna', 1], ['Packaging', 1]],
  'Kota R25': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Russian', 1], ['Packaging', 1]],
  'Kota R30': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Cheese', 1], ['Russian', 1], ['Packaging', 1]],
  'Kota R35': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Cheese', 1], ['Russian', 1], ['Vienna', 1], ['Packaging', 1]],
  'Kota R40': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Cheese', 1], ['Russian', 1], ['Chicken pattie', 1], ['Vienna', 1], ['Packaging', 1]],
  'Plain Hotdog': [['Bun', 1], ['Vienna', 1], ['Packaging', 1]],
  'Hotdog Lettuce & Cheese': [['Bun', 1], ['Vienna', 1], ['Lettuce', 1], ['Cheese', 1], ['Packaging', 1]],
  'Chips Small': [['Potatoes', 150], ['Oil', 20], ['Packaging', 1]],
  'Chips Medium': [['Potatoes', 250], ['Oil', 30], ['Packaging', 1]],
  'Chips Large': [['Potatoes', 350], ['Oil', 40], ['Packaging', 1]],
  'Chicken Burger': [['Bun', 1], ['Chicken pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Packaging', 1]],
  'Beef Burger': [['Bun', 1], ['Beef pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Packaging', 1]],
  'Chicken Burger + Chips': [['Bun', 1], ['Chicken pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Potatoes', 150], ['Oil', 20], ['Packaging', 1]],
  'Beef Burger + Chips': [['Bun', 1], ['Beef pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Potatoes', 150], ['Oil', 20], ['Packaging', 1]],
  'Club Sandwich': [['Bread loaf', 0.25], ['Chicken pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Packaging', 1]],
  'Extra Polony': [['Polony', 1]], 'Extra Special': [['Polony', 1], ['Atchaar', 1]],
  'Extra Cheese': [['Cheese', 1]], 'Extra Russian': [['Russian', 1]],
};

const EXTRA_PRICES = {
  'Extra Cheese': 5, 'Extra Sauce': 3, 'Extra Chilli': 2, 'Extra Atchaar': 2,
  'Extra Chakalaka': 2, 'Extra Polony': 1, 'Extra Russian': 10, 'Extra Vienna': 5
};

function emptyCustom() {
  return { remove: [], spice: 'Normal', salt: 'Normal', vinegar: 'Normal', extras: [], prep: 'Normal', note: '' };
}
function uid(p = 'id') { return p + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7); }
function today() { return new Date(); }
function iso(d = today()) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
const DOW_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function defaultCustomOpts(name, cat) {
  const isKota = /kota/i.test(name) || cat === 'Kota';
  const isChips = /chips/i.test(name) || cat === 'Chips';
  const isBurger = /burger|sandwich/i.test(name);
  const opts = { remove: [], spice: true, salt: true, vinegar: isKota || isChips, extras: [], prep: true };
  if (isKota) {
    opts.remove = ['Atchaar', 'Chakalaka', 'Polony', 'Russian', 'Vienna', 'Cheese', 'Onion'];
    opts.extras = Object.keys(EXTRA_PRICES);
  } else if (isChips) {
    opts.extras = ['Extra Sauce', 'Extra Chilli'];
  } else if (isBurger) {
    opts.remove = ['Cheese', 'Lettuce', 'Tomato', 'Onion'];
    opts.extras = ['Extra Cheese', 'Extra Sauce'];
    opts.vinegar = false;
  } else {
    opts.spice = opts.salt = opts.vinegar = opts.prep = false;
  }
  return opts;
}

function seed() {
  const items = DEFAULT_MENU.map(m => ({
    id: uid('it'), name: m.name, cat: m.cat, type: m.type, cost: m.cost, sell: m.sell,
    unit: m.unit, stock: m.stock, low: m.low, archived: false,
    costHistory: [{ date: iso(), cost: m.cost }],
    customOpts: defaultCustomOpts(m.name, m.cat)
  }));
  const byName = Object.fromEntries(items.map(i => [i.name, i.id]));
  const recipes = {};
  Object.entries(DEFAULT_RECIPES).forEach(([prod, lines]) => {
    const pid = byName[prod];
    if (pid) recipes[pid] = lines.map(([n, q]) => ({ itemId: byName[n], qty: q })).filter(x => x.itemId);
  });
  items.forEach(it => { if (recipes[it.id]) it.cost = recipeCost(it.id, items, recipes); });
  return {
    settings: {
      cafe: 'ELITES CAFÉ', currency: 'ZAR', locale: 'en-ZA', theme: 'emerald',
      dailyTarget: 1500, fixedMonthly: 5500, orderSeq: 1,
      sellerName: '', safetyDays: 1.5, leadDays: 1
    },
    items, recipes, movements: [], sales: [], expenses: [], book: [],
    orders: [], customers: [],
    templates: [
      { id: uid('tpl'), name: 'Kids Kota', custom: { ...emptyCustom(), spice: 'None', salt: 'Less', remove: ['Atchaar'] } },
      { id: uid('tpl'), name: 'No Vinegar', custom: { ...emptyCustom(), vinegar: 'None' } },
      { id: uid('tpl'), name: 'Extra Hot', custom: { ...emptyCustom(), spice: 'Extra Hot', extras: ['Extra Chilli', 'Extra Sauce'] } },
      { id: uid('tpl'), name: 'Mild No Atchaar', custom: { ...emptyCustom(), spice: 'Mild', remove: ['Atchaar'] } },
    ],
    workers: [
      { id: uid('wk'), name: 'Worker 1', role: 'Kitchen', payType: 'Daily', rate: 120, active: true },
      { id: uid('wk'), name: 'Worker 2', role: 'Front', payType: 'Daily', rate: 100, active: true },
    ],
    payments: [], waste: [], forecasts: [], audit: [],
    calendar: [
      { id: uid('ev'), title: 'Rent due', date: iso().slice(0, 8) + '01', type: 'expense', recur: 'monthly' },
      { id: uid('ev'), title: 'Stock count', date: iso().slice(0, 8) + '28', type: 'stock', recur: 'monthly' },
    ]
  };
}

let data = null;
try {
  data = JSON.parse(localStorage.getItem(KEY) || 'null');
  if (!data?.items?.length) {
    for (const k of ['stockly_elites_v3', 'stockly_elites_v2', 'stockly_elites_v1']) {
      const old = JSON.parse(localStorage.getItem(k) || 'null');
      if (old?.items?.length) {
        data = { ...seed(), ...old };
        data.items.forEach(it => { if (!it.customOpts) it.customOpts = defaultCustomOpts(it.name, it.cat); });
        if (!data.calendar) data.calendar = seed().calendar;
        if (!data.audit) data.audit = [];
        break;
      }
    }
  }
} catch (_) {}
if (!data?.items?.length) data = seed();
['orders', 'customers', 'templates', 'forecasts', 'audit', 'calendar', 'waste', 'payments'].forEach(k => {
  if (!Array.isArray(data[k])) data[k] = seed()[k] || [];
});
if (!data.settings.theme) data.settings.theme = 'emerald';

let ownerMode = false;
let salesTab = 'queue';
let twinTab = 'overview';
let stockFilter = 'ALL';
let draftOrder = null;
let calMonth = new Date();

function save() {
  localStorage.setItem(KEY, JSON.stringify(data));
}
function applyTheme() {
  document.body.setAttribute('data-theme', data.settings.theme || 'emerald');
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content',
    getComputedStyle(document.body).getPropertyValue('--bg').trim() || '#0c1210');
}
function M(n) {
  try {
    return new Intl.NumberFormat(data.settings.locale || 'en-ZA', {
      style: 'currency', currency: data.settings.currency || 'ZAR', maximumFractionDigits: 2
    }).format(Number(n) || 0);
  } catch { return 'R' + Number(n || 0).toLocaleString('en-ZA', { maximumFractionDigits: 2 }); }
}
function toast(t) {
  const x = document.getElementById('toast');
  x.textContent = t; x.classList.add('show');
  setTimeout(() => x.classList.remove('show'), 1800);
}
function audit(action, detail) {
  data.audit.unshift({
    id: uid('au'), at: new Date().toISOString(), date: iso(),
    action, detail: detail || '', mode: ownerMode ? 'owner' : 'sales',
    seller: data.settings.sellerName || '—'
  });
  if (data.audit.length > 300) data.audit.length = 300;
}

function itemById(id) { return (data.items || []).find(i => i.id === id); }
function activeItems() { return (data.items || []).filter(i => !i.archived); }
function menuProducts() { return activeItems().filter(i => i.sell > 0 && (i.type === 'Menu Product' || i.cat === 'Extras')); }

function recipeCost(productId, items = data.items, recipes = data.recipes) {
  return (recipes[productId] || []).reduce((s, l) => {
    const it = items.find(x => x.id === l.itemId);
    return s + (it ? Number(it.cost) * Number(l.qty) : 0);
  }, 0);
}
function refreshMenuCosts() {
  data.items.forEach(it => { if (data.recipes[it.id]?.length) it.cost = recipeCost(it.id); });
}

function lowStock() {
  return activeItems().filter(i => (i.type === 'Ingredient' || i.type === 'Packaging') && i.low > 0 && i.stock > 0 && i.stock <= i.low);
}
function outStock() {
  return activeItems().filter(i => (i.type === 'Ingredient' || i.type === 'Packaging') && i.stock <= 0);
}
/* Sales-safe stock status — no quantities or costs */
function stockStatus(item) {
  if (!(item.type === 'Ingredient' || item.type === 'Packaging')) return null;
  if (item.stock <= 0) return 'out';
  if (item.low > 0 && item.stock <= item.low) return 'low';
  return 'ok';
}

function dayTotals(date = iso()) {
  let revenue = 0, cogs = 0, items = 0;
  (data.sales || []).filter(s => s.date === date && s.status === 'confirmed').forEach(s => {
    revenue += Number(s.revenue || 0);
    cogs += Number(s.cogs || 0);
    items += (s.lines || []).reduce((n, l) => n + Number(l.qty || 0), 0);
  });
  const expenses = (data.expenses || []).filter(e => e.date === date).reduce((s, e) => s + Number(e.amount || 0), 0);
  return { revenue, cogs, gross: revenue - cogs, expenses, net: revenue - cogs - expenses, items };
}

function addMovement(itemId, qty, reason, meta = {}) {
  const it = itemById(itemId);
  if (!it) return;
  it.stock = Number(it.stock || 0) + Number(qty);
  data.movements.unshift({
    id: uid('mv'), date: iso(), time: new Date().toISOString(),
    itemId, name: it.name, qty: Number(qty), reason, ...meta
  });
}
function bookEntry(type, category, amount, note, date = iso()) {
  data.book.unshift({ id: uid('bk'), date, type, category, amount: Number(amount), note: note || '' });
}

function customLabels(c) {
  if (!c) return [];
  const tags = [];
  (c.remove || []).forEach(r => tags.push('NO ' + r.toUpperCase()));
  if (c.spice && c.spice !== 'Normal') tags.push(c.spice.toUpperCase());
  if (c.salt === 'Less') tags.push('LESS SALT');
  if (c.salt === 'None') tags.push('NO SALT');
  if (c.vinegar === 'Less') tags.push('LESS VINEGAR');
  if (c.vinegar === 'None') tags.push('NO VINEGAR');
  (c.extras || []).forEach(x => tags.push(x.toUpperCase()));
  if (c.prep && c.prep !== 'Normal') tags.push(c.prep.toUpperCase());
  if (c.note) tags.push('NOTE: ' + c.note);
  return tags;
}
function customExtraCost(c) {
  return (c?.extras || []).reduce((s, e) => s + (EXTRA_PRICES[e] || 0), 0);
}
function isCustomized(c) {
  if (!c) return false;
  return !!(c.remove?.length || c.extras?.length || (c.spice && c.spice !== 'Normal') ||
    (c.salt && c.salt !== 'Normal') || (c.vinegar && c.vinegar !== 'Normal') ||
    (c.prep && c.prep !== 'Normal') || (c.note && c.note.trim()));
}
function recipeLinesForCustom(productId, custom) {
  const removeNames = new Set((custom?.remove || []).map(x => x.toLowerCase()));
  const lines = (data.recipes[productId] || []).filter(l => {
    const it = itemById(l.itemId);
    if (!it) return true;
    return ![...removeNames].some(r => it.name.toLowerCase().includes(r) || r.includes(it.name.toLowerCase()));
  });
  const extras = (custom?.extras || []).map(ex => {
    const map = { 'Extra Cheese': 'Cheese', 'Extra Polony': 'Polony', 'Extra Russian': 'Russian', 'Extra Vienna': 'Vienna', 'Extra Atchaar': 'Atchaar', 'Extra Chakalaka': 'Chakalaka' };
    const it = activeItems().find(i => i.name === map[ex]);
    return it ? { itemId: it.id, qty: 1 } : null;
  }).filter(Boolean);
  return lines.concat(extras);
}
function deductCustomized(productId, qty, custom) {
  recipeLinesForCustom(productId, custom).forEach(l => addMovement(l.itemId, -Number(l.qty) * Number(qty), 'SALE', { productId }));
}
function cogsCustomized(productId, qty, custom) {
  return recipeLinesForCustom(productId, custom).reduce((s, l) => {
    const it = itemById(l.itemId);
    return s + (it ? Number(it.cost) * Number(l.qty) * qty : 0);
  }, 0);
}

function nextOrderNo() {
  const n = data.settings.orderSeq || 1;
  data.settings.orderSeq = n + 1;
  return n;
}

function completeOrder(order) {
  if (order.status === 'completed') return;
  let cogs = 0;
  const saleLines = [];
  (order.items || []).forEach(line => {
    const lineCogs = cogsCustomized(line.productId, line.qty, line.custom);
    cogs += lineCogs;
    deductCustomized(line.productId, line.qty, line.custom);
    saleLines.push({
      itemId: line.productId, name: line.name, qty: line.qty,
      sell: line.unitPrice, cost: lineCogs / Math.max(1, line.qty),
      custom: line.custom, variation: customLabels(line.custom).join(', ')
    });
  });
  order.status = 'completed';
  order.completedAt = new Date().toISOString();
  order.completedDate = iso();
  order.completedBy = data.settings.sellerName || '—';
  order.cogs = cogs;
  order.gross = order.total - cogs;
  data.sales.unshift({
    id: uid('sl'), date: iso(), payment: order.payment || 'Cash', status: 'confirmed',
    orderId: order.id, orderNo: order.number, seller: order.completedBy,
    lines: saleLines, revenue: order.total, cogs, gross: order.total - cogs,
    customer: order.customer || '', source: order.source || ''
  });
  bookEntry('Income', 'Sales', order.total, 'Order #' + order.number);
  bookEntry('Cost of sales', 'COGS', cogs, 'Order #' + order.number);
  data.forecasts.push({ date: iso(), expected: expectedSalesForDate(iso()), actual: order.total });
  audit('order_complete', '#' + order.number + ' · ' + M(order.total));
  save();
}

/* Twin helpers */
function dailyRevenueByDow() {
  const buckets = Array.from({ length: 7 }, () => []);
  const byDay = {};
  (data.sales || []).filter(s => s.status === 'confirmed').forEach(s => {
    byDay[s.date] = (byDay[s.date] || 0) + Number(s.revenue || 0);
  });
  Object.entries(byDay).forEach(([date, rev]) => {
    const d = new Date(date + 'T12:00:00');
    if (!isNaN(d)) buckets[d.getDay()].push(rev);
  });
  return buckets.map((arr, i) => {
    if (!arr.length) {
      const base = Number(data.settings.dailyTarget) || 1500;
      const factors = [0.7, 0.55, 0.6, 0.58, 0.72, 0.95, 1.05];
      return { dow: i, expected: Math.round(base * factors[i] * 0.55), samples: 0 };
    }
    return { dow: i, expected: Math.round(arr.reduce((a, b) => a + b, 0) / arr.length), samples: arr.length };
  });
}
function expectedSalesForDate(dateStr) {
  const d = new Date(dateStr + 'T12:00:00');
  return dailyRevenueByDow()[isNaN(d) ? today().getDay() : d.getDay()].expected;
}
function avgDailyUsage(itemId) {
  const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 30);
  const cut = iso(cutoff);
  const byDay = {};
  (data.movements || []).filter(m => m.itemId === itemId && m.reason === 'SALE' && m.date >= cut).forEach(m => {
    byDay[m.date] = (byDay[m.date] || 0) + Math.abs(Number(m.qty) || 0);
  });
  const vals = Object.values(byDay);
  return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
}
function stockRisks() {
  return activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging').map(it => {
    const use = avgDailyUsage(it.id);
    const daysLeft = use > 0 ? it.stock / use : (it.stock > 0 ? 99 : 0);
    const lead = Number(data.settings.leadDays) || 1;
    const safety = Number(data.settings.safetyDays) || 1.5;
    return {
      id: it.id, name: it.name, stock: it.stock, unit: it.unit, usePerDay: use, daysLeft,
      reorderQty: use > 0 ? Math.ceil(use * (lead + safety + 2)) : 0,
      risk: daysLeft <= lead + safety ? (daysLeft <= lead ? 'critical' : 'warn') : 'ok'
    };
  }).filter(r => r.usePerDay > 0 || r.stock <= (itemById(r.id)?.low || 0)).sort((a, b) => a.daysLeft - b.daysLeft);
}
function margin() {
  const recent = (data.sales || []).filter(s => s.status === 'confirmed').slice(0, 80);
  let rev = 0, cogs = 0;
  recent.forEach(s => { rev += s.revenue; cogs += s.cogs; });
  return rev > 0 ? (rev - cogs) / rev : 0.42;
}
function multiMonthForecast(months = 3, scenario = 'expected') {
  const m = margin();
  const avg = dailyRevenueByDow().reduce((s, x) => s + x.expected, 0) / 7;
  let growth = 0, costBump = 0;
  if (scenario === 'best') { growth = 0.12; costBump = -0.03; }
  if (scenario === 'worst') { growth = -0.15; costBump = 0.08; }
  const fixed = Number(data.settings.fixedMonthly) || 5500;
  const out = [];
  for (let i = 0; i < months; i++) {
    const d = new Date(); d.setMonth(d.getMonth() + i);
    const factor = Math.pow(1 + growth, i);
    const rev = avg * 26 * factor;
    const cogs = rev * (1 - m) * (1 + costBump);
    const exp = fixed * (1 + costBump * 0.5);
    out.push({ label: d.toLocaleString('en', { month: 'short', year: '2-digit' }), rev, cogs, exp, profit: rev - cogs - exp });
  }
  return out;
}
function productRanking() {
  const month = iso().slice(0, 7);
  const map = {};
  (data.sales || []).filter(s => s.date.startsWith(month) && s.status === 'confirmed').forEach(s => {
    (s.lines || []).forEach(l => {
      map[l.name] = map[l.name] || { qty: 0, rev: 0, cogs: 0 };
      map[l.name].qty += l.qty;
      map[l.name].rev += l.sell * l.qty;
      map[l.name].cogs += l.cost * l.qty;
    });
  });
  return Object.entries(map).map(([name, v]) => ({
    name, ...v, profit: v.rev - v.cogs, margin: v.rev ? (v.rev - v.cogs) / v.rev : 0
  })).sort((a, b) => b.profit - a.profit);
}

/* UI */
function closeModal() { document.getElementById('modal')?.remove(); }
function openModal(title, body, onSubmit, submitLabel = 'Save') {
  closeModal();
  const el = document.createElement('div');
  el.id = 'modal';
  el.innerHTML = `<div class="modal-backdrop" data-x="1"></div>
    <div class="modal-card"><div class="modal-head"><strong>${esc(title)}</strong>
    <button type="button" class="btn" data-x="1" style="padding:8px 10px">Close</button></div>
    <form id="modalForm" class="form">${body}${onSubmit ? `<button type="submit" class="btn primary">${esc(submitLabel)}</button>` : ''}</form></div>`;
  document.body.appendChild(el);
  el.querySelectorAll('[data-x]').forEach(b => b.onclick = closeModal);
  if (onSubmit) document.getElementById('modalForm').onsubmit = e => { e.preventDefault(); if (onSubmit(e) !== false) closeModal(); };
}

function requireOwner(cb) {
  if (ownerMode) { cb(); return; }
  openModal('Owner unlock', `
    <div class="infobox">Owner tools: stock quantities, costs, twin, books, calendar, themes, audit.</div>
    <label class="small">Password<input id="ow_pin" type="password" required autocomplete="current-password"></label>
  `, () => {
    if (document.getElementById('ow_pin').value !== OWNER_PIN) { toast('Wrong password'); return false; }
    ownerMode = true;
    audit('owner_unlock', 'Owner mode entered');
    save();
    toast('Owner unlocked');
    buildNav();
    cb();
    return true;
  }, 'Unlock');
}

function buildNav() {
  const nav = document.getElementById('mainNav');
  const modePill = document.getElementById('modePill');
  const tag = document.getElementById('tagLine');
  if (ownerMode) {
    modePill.textContent = 'OWNER';
    tag.textContent = (data.settings.cafe || 'ELITES CAFÉ') + ' · Owner';
    nav.innerHTML = `
      <button data-s="home"><b>⌂</b>Home</button>
      <button data-s="sales"><b>R</b>Orders</button>
      <button data-s="stock"><b>▣</b>Stock</button>
      <button data-s="twin"><b>◎</b>Twin</button>
      <button data-s="book"><b>≡</b>Book</button>
      <button data-s="calendar"><b>📅</b>Cal</button>
      <button data-s="more"><b>⋮</b>More</button>`;
  } else {
    modePill.textContent = 'SALES';
    tag.textContent = (data.settings.cafe || 'ELITES CAFÉ') + ' · Sales';
    nav.innerHTML = `
      <button data-s="home"><b>⌂</b>Home</button>
      <button data-s="sales"><b>R</b>Orders</button>
      <button data-s="customers"><b>☺</b>Customers</button>
      <button data-s="more"><b>⋮</b>More</button>`;
  }
  nav.querySelectorAll('button').forEach(b => {
    b.onclick = () => show(b.dataset.s);
  });
}

function show(id) {
  // Block owner-only screens in sales mode
  if (!ownerMode && ['stock', 'twin', 'book', 'calendar'].includes(id)) {
    toast('Owner only');
    id = 'home';
  }
  document.querySelectorAll('.screen').forEach(x => x.classList.remove('active'));
  const el = document.getElementById(id);
  if (!el) { id = 'home'; }
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('#mainNav button').forEach(x => x.classList.toggle('active', x.dataset.s === id));
  const map = { home, sales, customers, stock, twin, book, calendar, more };
  (map[id] || home)();
}

/* —— SCREENS —— */
function home() {
  const t = dayTotals();
  const low = lowStock();
  const out = outStock();
  const open = (data.orders || []).filter(o => o.status !== 'completed' && o.status !== 'cancelled').length;

  if (!ownerMode) {
    // SALES HOME — basic
    document.getElementById('home').innerHTML = `
      <div class="title">Sales floor</div>
      ${!data.settings.sellerName ? `
        <div class="warn">Set your name before taking orders (anti-theft trail).
          <button type="button" class="btn primary" style="margin-top:8px" data-action="set-seller">Set seller name</button>
        </div>` : `<div class="okbox">Seller: <b>${esc(data.settings.sellerName)}</b>
          <button type="button" class="btn" style="margin-top:6px" data-action="set-seller">Change</button></div>`}
      <div class="card">
        <h2>TODAY (SALES ONLY)</h2>
        <div class="grid2">
          <div class="stat"><div class="lbl">Orders open</div><div class="val">${open}</div></div>
          <div class="stat"><div class="lbl">Items sold today</div><div class="val">${t.items}</div></div>
        </div>
        <div class="small" style="margin-top:8px">Totals & profit are owner-only.</div>
      </div>
      <div class="card">
        <h2>STOCK ALERTS</h2>
        ${out.length ? out.map(i => `<div class="item"><span>${esc(i.name)}</span><span class="badge out">OUT</span></div>`).join('') : ''}
        ${low.length ? low.map(i => `<div class="item"><span>${esc(i.name)}</span><span class="badge low">LOW</span></div>`).join('') : ''}
        ${!out.length && !low.length ? '<div class="small">No low or out-of-stock alerts.</div>' : ''}
        <div class="small" style="margin-top:8px">Quantities and costs hidden in sales mode.</div>
      </div>
      <button type="button" class="btn primary" data-action="new-order" style="width:100%">+ New order</button>`;
    return;
  }

  // OWNER HOME
  const exp = expectedSalesForDate(iso());
  document.getElementById('home').innerHTML = `
    <div class="title">${esc(data.settings.cafe)}</div>
    <div class="card">
      <h2>TODAY</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Sales</div><div class="val green">${M(t.revenue)}</div></div>
        <div class="stat"><div class="lbl">Expected</div><div class="val accent">${M(exp)}</div></div>
        <div class="stat"><div class="lbl">Gross</div><div class="val">${M(t.gross)}</div></div>
        <div class="stat"><div class="lbl">Open orders</div><div class="val">${open}</div></div>
      </div>
    </div>
    <div class="card">
      <h2>STOCK</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Low</div><div class="val yellow">${low.length}</div></div>
        <div class="stat"><div class="lbl">Out</div><div class="val red">${out.length}</div></div>
      </div>
    </div>
    <div class="row">
      <button type="button" class="btn" data-go="twin">Digital Twin</button>
      <button type="button" class="btn primary" data-action="new-order">New order</button>
    </div>`;
}

function sales() {
  const open = (data.orders || []).filter(o => o.status !== 'completed' && o.status !== 'cancelled');
  const done = (data.orders || []).filter(o => o.status === 'completed').slice(0, 15);
  const tabs = ownerMode
    ? [['queue', 'Queue'], ['new', 'New'], ['history', 'History']]
    : [['queue', 'Queue'], ['new', 'New']];

  let body = '';
  if (salesTab === 'queue') {
    body = open.length ? open.map(o => `
      <div class="card">
        <div class="row" style="margin-bottom:6px">
          <b>#${o.number}</b>
          <span class="badge ${o.status === 'new' ? 'new' : o.status === 'preparing' ? 'prep' : 'ready'}">${(o.status || 'new').toUpperCase()}</span>
        </div>
        <div class="small">${esc(o.customer || 'Walk-in')} · ${esc(o.source || 'Counter')}${ownerMode ? ' · ' + M(o.total) : ''}
          ${o.seller ? ' · by ' + esc(o.seller) : ''}</div>
        ${(o.items || []).map(l => `
          <div class="item">
            <div><b>${l.qty} × ${esc(l.name)}</b>
              <div class="tagline">${customLabels(l.custom).map(t => `<span>${esc(t)}</span>`).join('')}</div>
            </div>
            ${ownerMode ? `<b>${M(l.lineTotal)}</b>` : ''}
          </div>`).join('')}
        <div class="row" style="margin-top:8px">
          ${o.status === 'new' ? `<button type="button" class="btn" data-action="order-status" data-id="${o.id}" data-st="preparing">Preparing</button>` : ''}
          ${o.status === 'preparing' ? `<button type="button" class="btn" data-action="order-status" data-id="${o.id}" data-st="ready">Ready</button>` : ''}
          <button type="button" class="btn primary" data-action="order-complete" data-id="${o.id}">Complete</button>
          <button type="button" class="btn danger" data-action="order-cancel" data-id="${o.id}">Cancel</button>
        </div>
      </div>`).join('') : '<div class="empty">No open orders.</div>';
  } else if (salesTab === 'new') {
    body = renderNewOrderPanel();
  } else if (ownerMode) {
    body = done.map(o => `
      <div class="item">
        <div><b>#${o.number}</b> · ${esc(o.customer || 'Walk-in')}
        <div class="small">${esc(o.completedDate || '')} · ${esc(o.completedBy || '')} · ${esc(o.payment || '')}</div></div>
        <b class="green">${M(o.total)}</b>
      </div>`).join('') || '<div class="empty">No history.</div>';
  }

  document.getElementById('sales').innerHTML = `
    <div class="title">Orders</div>
    <div class="chips">${tabs.map(([id, lab]) => `
      <button type="button" class="chip ${salesTab === id ? 'on' : ''}" data-action="sales-tab" data-t="${id}">${lab}</button>`).join('')}
    </div>
    ${salesTab !== 'new' ? `<button type="button" class="btn primary" data-action="new-order" style="margin-bottom:10px">+ New order</button>` : ''}
    ${body}`;
}

function ensureDraft() {
  if (!draftOrder) draftOrder = { customer: '', source: 'Counter', payment: 'Cash', items: [] };
  return draftOrder;
}

function renderNewOrderPanel() {
  const d = ensureDraft();
  const menu = menuProducts();
  // Flag products whose ingredients are out
  const total = d.items.reduce((s, l) => s + l.lineTotal, 0);
  const custOpts = (data.customers || []).map(c => `<option value="${esc(c.name)}">`).join('');
  return `
    <div class="card">
      <h2>HEADER</h2>
      <div class="form">
        <label class="small">Customer
          <input id="d_customer" list="custList" value="${esc(d.customer)}" placeholder="Walk-in or return customer">
          <datalist id="custList">${custOpts}</datalist>
        </label>
        <div class="row">
          <label class="small">Source<select id="d_source">${['Counter', 'WhatsApp', 'Phone', 'Other'].map(s => `<option ${d.source === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
          <label class="small">Payment<select id="d_pay">${['Cash', 'Card', 'EFT', 'Other'].map(s => `<option ${d.payment === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
        </div>
      </div>
    </div>
    <div class="card">
      <h2>ADD PRODUCT</h2>
      <div class="form">
        <select id="d_prod">${menu.map(i => {
          // soft warning if any recipe ingredient is out
          const lines = data.recipes[i.id] || [];
          const blocked = lines.some(l => {
            const ing = itemById(l.itemId);
            return ing && ing.stock <= 0;
          });
          return `<option value="${i.id}">${esc(i.name)} · ${M(i.sell)}${blocked ? ' ⚠' : ''}</option>`;
        }).join('')}</select>
        <div class="row">
          <input id="d_qty" type="number" min="1" value="1">
          <button type="button" class="btn" data-action="draft-add-normal">Normal</button>
          <button type="button" class="btn primary" data-action="draft-add-custom">Custom</button>
        </div>
        ${(data.templates || []).length ? `
          <div class="chips">${data.templates.map(t => `
            <button type="button" class="chip" data-action="draft-add-tpl" data-id="${t.id}">${esc(t.name)}</button>`).join('')}</div>` : ''}
      </div>
    </div>
    <div class="card">
      <h2>LINES · ${M(total)}</h2>
      ${d.items.length ? d.items.map((l, idx) => `
        <div class="item" style="flex-wrap:wrap">
          <div style="flex:1"><b>${l.qty} × ${esc(l.name)}</b>
            <div class="tagline">${customLabels(l.custom).map(t => `<span>${esc(t)}</span>`).join('') || '<span class="small">Normal</span>'}</div>
          </div>
          <b>${M(l.lineTotal)}</b>
          <div class="row" style="width:100%;margin-top:6px">
            <button type="button" class="btn" data-action="draft-edit" data-idx="${idx}">Edit</button>
            <button type="button" class="btn danger" data-action="draft-remove" data-idx="${idx}">Remove</button>
          </div>
        </div>`).join('') : '<div class="empty">No lines yet.</div>'}
      <div class="row" style="margin-top:10px">
        <button type="button" class="btn" data-action="draft-clear">Clear</button>
        <button type="button" class="btn primary" data-action="draft-submit">Place · ${M(total)}</button>
      </div>
    </div>`;
}

function syncDraftHeader() {
  if (!draftOrder) return;
  const c = document.getElementById('d_customer');
  const s = document.getElementById('d_source');
  const p = document.getElementById('d_pay');
  if (c) draftOrder.customer = c.value.trim();
  if (s) draftOrder.source = s.value;
  if (p) draftOrder.payment = p.value;
}

function openCustomizer(product, qty, existingCustom, onApply) {
  const opts = product.customOpts || defaultCustomOpts(product.name, product.cat);
  const c = existingCustom ? JSON.parse(JSON.stringify(existingCustom)) : emptyCustom();
  openModal(`Customize · ${product.name}`, `
    <div class="small">Qty ${qty} · Base ${M(product.sell)}</div>
    ${(opts.remove || []).length ? `<div class="small" style="margin-top:8px;font-weight:700">REMOVE</div>
      <div class="checkgrid">${opts.remove.map(r => `
        <label><input type="checkbox" data-rm="${esc(r)}" ${c.remove.includes(r) ? 'checked' : ''}> ${esc(r)}</label>`).join('')}</div>` : ''}
    ${opts.spice ? `<div class="small" style="margin-top:8px;font-weight:700">SPICE</div>
      <div class="radiogrid">${['None', 'Mild', 'Normal', 'Hot', 'Extra Hot'].map(s => `
        <label><input type="radio" name="spice" value="${s}" ${c.spice === s ? 'checked' : ''}> ${s}</label>`).join('')}</div>` : ''}
    ${opts.salt ? `<div class="small" style="margin-top:8px;font-weight:700">SALT</div>
      <div class="radiogrid">${['Normal', 'Less', 'None'].map(s => `
        <label><input type="radio" name="salt" value="${s}" ${c.salt === s ? 'checked' : ''}> ${s}</label>`).join('')}</div>` : ''}
    ${opts.vinegar ? `<div class="small" style="margin-top:8px;font-weight:700">VINEGAR</div>
      <div class="radiogrid">${['Normal', 'Less', 'None'].map(s => `
        <label><input type="radio" name="vinegar" value="${s}" ${c.vinegar === s ? 'checked' : ''}> ${s}</label>`).join('')}</div>` : ''}
    ${(opts.extras || []).length ? `<div class="small" style="margin-top:8px;font-weight:700">EXTRAS</div>
      <div class="checkgrid">${opts.extras.map(ex => `
        <label><input type="checkbox" data-ex="${esc(ex)}" ${(c.extras || []).includes(ex) ? 'checked' : ''}> ${esc(ex)}${EXTRA_PRICES[ex] ? ' +' + M(EXTRA_PRICES[ex]) : ''}</label>`).join('')}</div>` : ''}
    <label class="small">Note<textarea id="c_note">${esc(c.note || '')}</textarea></label>
  `, () => {
    const custom = emptyCustom();
    document.querySelectorAll('[data-rm]:checked').forEach(el => custom.remove.push(el.getAttribute('data-rm')));
    const spice = document.querySelector('input[name="spice"]:checked'); if (spice) custom.spice = spice.value;
    const salt = document.querySelector('input[name="salt"]:checked'); if (salt) custom.salt = salt.value;
    const vinegar = document.querySelector('input[name="vinegar"]:checked'); if (vinegar) custom.vinegar = vinegar.value;
    document.querySelectorAll('[data-ex]:checked').forEach(el => custom.extras.push(el.getAttribute('data-ex')));
    custom.note = (document.getElementById('c_note')?.value || '').trim();
    onApply(custom);
    return true;
  }, 'Apply');
}

function customers() {
  // Sales-friendly customer list — no money analytics
  document.getElementById('customers').innerHTML = `
    <div class="title">Customers</div>
    <div class="infobox">Save return customers and their usual preferences. No financial data here.</div>
    <button type="button" class="btn primary" data-action="cust-add-sales" style="margin-bottom:10px">+ Add customer</button>
    ${(data.customers || []).map(c => `
      <div class="item" style="flex-wrap:wrap">
        <div style="flex:1"><b>${esc(c.name)}</b>
          <div class="small">${(c.templates || []).map(t => t.name).join(' · ') || 'No saved usual yet'}</div>
        </div>
        <button type="button" class="btn" data-action="cust-use" data-name="${esc(c.name)}">Order</button>
      </div>`).join('') || '<div class="empty">No customers yet. They appear when you name an order.</div>'}`;
}

function stock() {
  if (!ownerMode) { show('home'); return; }
  const filters = ['ALL', 'Ingredients', 'Menu', 'Low', 'Out', 'Moves'];
  let list = activeItems();
  if (stockFilter === 'Ingredients') list = list.filter(i => i.type === 'Ingredient' || i.type === 'Packaging');
  else if (stockFilter === 'Menu') list = list.filter(i => i.type === 'Menu Product' || i.cat === 'Extras');
  else if (stockFilter === 'Low') list = lowStock();
  else if (stockFilter === 'Out') list = outStock();

  let body = '';
  if (stockFilter === 'Moves') {
    body = (data.movements || []).slice(0, 40).map(m => `
      <div class="item"><div><b>${esc(m.name)}</b><div class="small">${esc(m.reason)} · ${esc(m.date)}</div></div>
      <b class="${m.qty >= 0 ? 'green' : 'orange'}">${m.qty >= 0 ? '+' : ''}${m.qty}</b></div>`).join('') || '<div class="empty">None</div>';
  } else {
    body = list.map(i => {
      const isIng = i.type === 'Ingredient' || i.type === 'Packaging';
      let badge = '';
      if (isIng && i.stock <= 0) badge = '<span class="badge out">OUT</span>';
      else if (isIng && i.low > 0 && i.stock <= i.low) badge = '<span class="badge low">LOW</span>';
      return `<div class="item" style="flex-wrap:wrap">
        <div style="flex:1"><b>${esc(i.name)}</b> ${badge}
        <div class="small">${esc(i.cat)}${isIng ? ` · ${i.stock} ${esc(i.unit)}` : ''} · cost ${M(i.cost)}${i.sell ? ` · sell ${M(i.sell)}` : ''}</div></div>
        <div class="row" style="width:100%;margin-top:6px">
          <button type="button" class="btn" data-action="item-edit" data-id="${i.id}">Edit</button>
          ${isIng ? `<button type="button" class="btn" data-action="restock" data-id="${i.id}">Restock</button>` : ''}
          <button type="button" class="btn danger" data-action="item-archive" data-id="${i.id}">Archive</button>
        </div></div>`;
    }).join('') || '<div class="empty">Empty</div>';
  }
  document.getElementById('stock').innerHTML = `
    <div class="title">Stock · Owner</div>
    <div class="chips">${filters.map(f => `<button type="button" class="chip ${stockFilter === f ? 'on' : ''}" data-action="stock-filter" data-f="${f}">${f}</button>`).join('')}</div>
    <div class="row" style="margin-bottom:10px">
      <button type="button" class="btn primary" data-action="item-add">Add item</button>
      <button type="button" class="btn" data-action="stock-count">Count</button>
    </div>${body}`;
}

function twin() {
  if (!ownerMode) { show('home'); return; }
  const exp = expectedSalesForDate(iso());
  const t = dayTotals();
  const model = dailyRevenueByDow();
  const risks = stockRisks().slice(0, 6);
  const best = multiMonthForecast(3, 'best');
  const expM = multiMonthForecast(3, 'expected');
  const worst = multiMonthForecast(3, 'worst');
  const tabs = [['overview', 'Overview'], ['forecast', 'Forecast'], ['history', 'Past data']];

  let body = '';
  if (twinTab === 'overview') {
    body = `
      <div class="card"><h2>TODAY</h2>
        <div class="grid2">
          <div class="stat"><div class="lbl">Expected</div><div class="val accent">${M(exp)}</div></div>
          <div class="stat"><div class="lbl">Actual</div><div class="val green">${M(t.revenue)}</div></div>
        </div>
      </div>
      <div class="card"><h2>WEEKDAY MODEL</h2>
        ${model.map(x => `<div class="item"><span>${DOW_NAMES[x.dow].slice(0, 3)}</span><b>${M(x.expected)}</b></div>`).join('')}
      </div>
      <div class="card"><h2>STOCK RISKS</h2>
        ${risks.length ? risks.map(r => `
          <div class="item"><div><b>${esc(r.name)}</b><div class="small">${r.daysLeft.toFixed(1)}d · reorder ~${r.reorderQty} · stock ${r.stock}</div></div>
          <span class="badge ${r.risk === 'critical' ? 'out' : r.risk === 'warn' ? 'low' : 'ok'}">${r.risk}</span></div>`).join('') : '<div class="empty">Learning…</div>'}
      </div>
      <div class="card"><h2>TOP PRODUCTS</h2>
        ${productRanking().slice(0, 6).map((p, i) => `
          <div class="item"><div><b>${i + 1}. ${esc(p.name)}</b><div class="small">${p.qty} sold</div></div>
          <b class="green">${M(p.profit)}</b></div>`).join('') || '<div class="empty">Need sales</div>'}
      </div>`;
  } else if (twinTab === 'forecast') {
    body = `<div class="card"><h2>BEST / EXPECTED / WORST</h2>
      ${[0, 1, 2].map(i => `
        <div class="item" style="flex-wrap:wrap"><b style="width:100%">${esc(expM[i].label)}</b>
        <div class="grid3" style="width:100%;margin-top:6px">
          <div class="stat"><div class="lbl">Best</div><div class="val green">${M(best[i].profit)}</div></div>
          <div class="stat"><div class="lbl">Exp</div><div class="val accent">${M(expM[i].profit)}</div></div>
          <div class="stat"><div class="lbl">Worst</div><div class="val red">${M(worst[i].profit)}</div></div>
        </div></div>`).join('')}</div>`;
  } else {
    body = `<div class="card"><h2>IMPORT PAST BOOKS</h2>
      <button type="button" class="btn primary" data-action="history-sale">Past sales day</button>
      <button type="button" class="btn" data-action="history-bulk" style="margin-top:8px">Bulk daily totals</button>
    </div>`;
  }
  document.getElementById('twin').innerHTML = `
    <div class="title">Digital Twin · Owner</div>
    <div class="chips">${tabs.map(([id, lab]) => `
      <button type="button" class="chip ${twinTab === id ? 'on' : ''}" data-action="twin-tab" data-t="${id}">${lab}</button>`).join('')}
    </div>${body}`;
}

function book() {
  if (!ownerMode) { show('home'); return; }
  const month = iso().slice(0, 7);
  const monthSales = (data.sales || []).filter(s => s.date.startsWith(month) && s.status === 'confirmed')
    .reduce((s, x) => ({ rev: s.rev + x.revenue, cogs: s.cogs + x.cogs }), { rev: 0, cogs: 0 });
  const monthExp = (data.expenses || []).filter(e => e.date.startsWith(month)).reduce((s, e) => s + Number(e.amount), 0);
  document.getElementById('book').innerHTML = `
    <div class="title">Book · Owner</div>
    <div class="card"><h2>THIS MONTH</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Revenue</div><div class="val green">${M(monthSales.rev)}</div></div>
        <div class="stat"><div class="lbl">COGS</div><div class="val orange">${M(monthSales.cogs)}</div></div>
        <div class="stat"><div class="lbl">Gross</div><div class="val accent">${M(monthSales.rev - monthSales.cogs)}</div></div>
        <div class="stat"><div class="lbl">Expenses</div><div class="val">${M(monthExp)}</div></div>
      </div>
      <div class="med" style="margin-top:8px">Net ≈ ${M(monthSales.rev - monthSales.cogs - monthExp)}</div>
    </div>
    <div class="card"><h2>ADD EXPENSE</h2>
      <form class="form" id="expForm">
        <select id="exCat"><option>Rent</option><option>Electricity</option><option>Transport</option><option>Worker pay</option><option>Other</option></select>
        <input id="exAmt" type="number" min="0.01" step="0.01" placeholder="Amount" required>
        <input id="exNote" placeholder="Note">
        <button class="btn primary" type="submit">Save</button>
      </form>
    </div>
    <div class="card"><h2>LEDGER</h2>
      ${(data.book || []).slice(0, 25).map(b => `
        <div class="item"><div><b>${esc(b.category)}</b><div class="small">${esc(b.type)} · ${esc(b.date)}</div></div>
        <b class="${b.type === 'Income' ? 'green' : 'orange'}">${M(b.amount)}</b></div>`).join('') || '<div class="empty">Empty</div>'}
    </div>`;
  document.getElementById('expForm').onsubmit = e => {
    e.preventDefault();
    const amount = Number(document.getElementById('exAmt').value);
    const category = document.getElementById('exCat').value;
    const note = document.getElementById('exNote').value.trim();
    data.expenses.unshift({ id: uid('ex'), date: iso(), amount, category, note });
    bookEntry('Expense', category, amount, note);
    audit('expense_add', category + ' ' + M(amount));
    save(); toast('Saved'); book();
  };
}

function calendar() {
  if (!ownerMode) { show('home'); return; }
  const y = calMonth.getFullYear();
  const m = calMonth.getMonth();
  const first = new Date(y, m, 1);
  const startPad = first.getDay();
  const daysInMonth = new Date(y, m + 1, 0).getDate();
  const monthStr = y + '-' + String(m + 1).padStart(2, '0');
  const events = (data.calendar || []).filter(ev => (ev.date || '').startsWith(monthStr) || ev.recur === 'monthly');
  const byDay = {};
  events.forEach(ev => {
    let day = Number((ev.date || '').slice(8, 10));
    if (ev.recur === 'monthly') day = Number((ev.date || '01').slice(8, 10)) || 1;
    if (!byDay[day]) byDay[day] = [];
    byDay[day].push(ev);
  });
  let cells = '';
  for (let i = 0; i < startPad; i++) cells += '<div></div>';
  for (let d = 1; d <= daysInMonth; d++) {
    const isToday = iso() === monthStr + '-' + String(d).padStart(2, '0');
    const has = byDay[d]?.length;
    cells += `<div class="day${has ? ' has' : ''}${isToday ? ' today' : ''}" data-action="cal-day" data-d="${d}">
      <div>${d}</div>${has ? `<div class="small">${has}</div>` : ''}</div>`;
  }
  document.getElementById('calendar').innerHTML = `
    <div class="title">Calendar · Owner</div>
    <div class="row" style="margin-bottom:10px">
      <button type="button" class="btn" data-action="cal-prev">←</button>
      <div class="med" style="text-align:center">${calMonth.toLocaleString('en', { month: 'long', year: 'numeric' })}</div>
      <button type="button" class="btn" data-action="cal-next">→</button>
    </div>
    <div class="card">
      <div class="cal-grid">
        ${['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(h => `<div class="hd">${h}</div>`).join('')}
        ${cells}
      </div>
    </div>
    <div class="card">
      <h2>EVENTS THIS MONTH</h2>
      ${events.map(ev => `
        <div class="item"><div><b>${esc(ev.title)}</b><div class="small">${esc(ev.date)} · ${esc(ev.type || '')}${ev.recur ? ' · ' + ev.recur : ''}</div></div>
        <button type="button" class="btn danger" data-action="cal-del" data-id="${ev.id}">Del</button></div>`).join('') || '<div class="empty">No events</div>'}
      <button type="button" class="btn primary" data-action="cal-add" style="margin-top:8px">Add event</button>
    </div>`;
}

function more() {
  document.getElementById('more').innerHTML = `
    <div class="title">More</div>
    <div class="card">
      <h2>MODE</h2>
      ${ownerMode
        ? `<div class="okbox">Owner mode active</div>
           <button type="button" class="btn" data-action="owner-lock" style="margin-top:8px">Lock to Sales mode</button>`
        : `<div class="infobox">Sales mode: orders, customers, stock alerts only. Twin, books, full stock & calendar are owner-only.</div>
           <button type="button" class="btn primary" data-action="owner-unlock" style="margin-top:8px">Unlock Owner</button>`}
    </div>
    <div class="card">
      <h2>SELLER NAME (ANTI-THEFT)</h2>
      <div class="small">Every order is tagged with who served it.</div>
      <div class="med" style="margin:8px 0">${esc(data.settings.sellerName || 'Not set')}</div>
      <button type="button" class="btn" data-action="set-seller">Set / change name</button>
    </div>
    ${ownerMode ? `
      <div class="card">
        <h2>THEME</h2>
        <div class="chips">${THEMES.map(th => `
          <button type="button" class="chip ${(data.settings.theme || 'emerald') === th ? 'on' : ''}" data-action="theme" data-t="${th}">${th}</button>`).join('')}
        </div>
      </div>
      <div class="card">
        <h2>AUDIT LOG</h2>
        ${(data.audit || []).slice(0, 15).map(a => `
          <div class="item"><div><b>${esc(a.action)}</b><div class="small">${esc(a.date)} · ${esc(a.seller)} · ${esc(a.detail)}</div></div>
          <span class="badge ${a.mode === 'owner' ? 'ok' : 'low'}">${a.mode}</span></div>`).join('') || '<div class="empty">No events</div>'}
      </div>
      <div class="card">
        <h2>SETTINGS</h2>
        <form class="form" id="setForm">
          <label class="small">Café name<input id="setCafe" value="${esc(data.settings.cafe || '')}"></label>
          <label class="small">Daily target<input id="setTarget" type="number" value="${data.settings.dailyTarget || 1500}"></label>
          <label class="small">Fixed monthly costs<input id="setFixed" type="number" value="${data.settings.fixedMonthly || 5500}"></label>
          <button class="btn primary" type="submit">Save</button>
        </form>
      </div>
      <div class="card">
        <h2>BACKUP</h2>
        <div class="row">
          <button type="button" class="btn" data-action="export">Export JSON</button>
          <label class="btn">Import<input type="file" id="importFile" accept="application/json" hidden></label>
        </div>
        <button type="button" class="btn danger" style="margin-top:8px" data-action="reset">Reset demo</button>
      </div>` : `
      <div class="card">
        <h2>HELP</h2>
        <div class="small">Sales can: take orders, customize items, manage return customers, see LOW/OUT stock alerts.
        Sales cannot: see costs, profits, stock quantities, digital twin, books, or calendar.</div>
      </div>`}`;

  if (ownerMode) {
    const form = document.getElementById('setForm');
    if (form) form.onsubmit = e => {
      e.preventDefault();
      data.settings.cafe = document.getElementById('setCafe').value.trim() || 'ELITES CAFÉ';
      data.settings.dailyTarget = Number(document.getElementById('setTarget').value) || 1500;
      data.settings.fixedMonthly = Number(document.getElementById('setFixed').value) || 5500;
      audit('settings_save', 'Owner settings');
      save(); toast('Saved'); more();
    };
    const imp = document.getElementById('importFile');
    if (imp) imp.onchange = e => {
      const f = e.target.files?.[0]; if (!f) return;
      const r = new FileReader();
      r.onload = () => { try { data = JSON.parse(r.result); ownerMode = false; save(); location.reload(); } catch { toast('Invalid'); } };
      r.readAsText(f);
    };
  }
}

/* Item / history modals (owner) */
function openItemForm(existing) {
  if (!ownerMode) return;
  const it = existing || { id: '', name: '', cat: 'Ingredients', type: 'Ingredient', cost: 0, sell: 0, unit: 'unit', stock: 0, low: 5 };
  openModal(existing ? 'Edit item' : 'Add item', `
    <label class="small">Name<input id="i_name" required value="${esc(it.name)}"></label>
    <div class="row">
      <label class="small">Category<input id="i_cat" value="${esc(it.cat || '')}"></label>
      <label class="small">Type<select id="i_type">${['Ingredient', 'Menu Product', 'Drink', 'Packaging', 'Other'].map(t => `<option ${it.type === t ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
    </div>
    <div class="row">
      <label class="small">Cost<input id="i_cost" type="number" min="0" step="0.01" value="${it.cost || 0}"></label>
      <label class="small">Sell<input id="i_sell" type="number" min="0" step="0.01" value="${it.sell || 0}"></label>
    </div>
    <div class="row">
      <label class="small">Unit<input id="i_unit" value="${esc(it.unit || 'unit')}"></label>
      <label class="small">Stock<input id="i_stock" type="number" step="any" value="${it.stock || 0}"></label>
    </div>
    <label class="small">Low stock<input id="i_low" type="number" value="${it.low || 0}"></label>
  `, () => {
    const name = document.getElementById('i_name').value.trim();
    if (!name) return false;
    const cost = Number(document.getElementById('i_cost').value) || 0;
    const row = {
      id: it.id || uid('it'), name,
      cat: document.getElementById('i_cat').value.trim() || 'Other',
      type: document.getElementById('i_type').value,
      cost, sell: Number(document.getElementById('i_sell').value) || 0,
      unit: document.getElementById('i_unit').value.trim() || 'unit',
      stock: Number(document.getElementById('i_stock').value) || 0,
      low: Number(document.getElementById('i_low').value) || 0,
      archived: false, costHistory: it.costHistory || [{ date: iso(), cost }],
      customOpts: it.customOpts || defaultCustomOpts(name, document.getElementById('i_cat').value.trim())
    };
    const idx = data.items.findIndex(x => x.id === row.id);
    if (idx >= 0) data.items[idx] = { ...data.items[idx], ...row };
    else data.items.push(row);
    refreshMenuCosts();
    audit(existing ? 'item_edit' : 'item_add', name);
    save(); toast('Saved'); stock(); return true;
  });
}

function openRestock(id) {
  if (!ownerMode) return;
  const it = itemById(id); if (!it) return;
  openModal('Restock · ' + it.name, `
    <div class="small">Current: <b>${it.stock} ${esc(it.unit)}</b></div>
    <label class="small">Quantity<input id="r_qty" type="number" min="0.01" step="any" required></label>
    <label class="small">Cost / unit<input id="r_cost" type="number" min="0" step="0.01" value="${it.cost}"></label>
  `, () => {
    const qty = Number(document.getElementById('r_qty').value) || 0;
    const cost = Number(document.getElementById('r_cost').value) || 0;
    if (qty <= 0) return false;
    if (cost !== Number(it.cost)) { it.costHistory = [...(it.costHistory || []), { date: iso(), cost }]; it.cost = cost; }
    addMovement(it.id, qty, 'PURCHASE', { cost });
    bookEntry('Cost of sales', 'Inventory purchase', cost * qty, 'Restock ' + it.name);
    audit('restock', it.name + ' +' + qty);
    refreshMenuCosts(); save(); toast('Restocked'); stock(); return true;
  });
}

function openStockCount() {
  if (!ownerMode) return;
  const ings = activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging').slice(0, 30);
  openModal('Stock count', ings.map(i => `
    <div class="item"><div><b>${esc(i.name)}</b><div class="small">System ${i.stock}</div></div>
    <input data-count="${i.id}" type="number" step="any" value="${i.stock}" style="width:80px;text-align:center"></div>`).join(''), () => {
    document.querySelectorAll('[data-count]').forEach(inp => {
      const it = itemById(inp.dataset.count); if (!it) return;
      const physical = Number(inp.value); if (isNaN(physical)) return;
      const diff = physical - Number(it.stock);
      if (Math.abs(diff) < 1e-9) return;
      addMovement(it.id, diff, 'ADJUSTMENT', { note: 'Stock count' });
    });
    audit('stock_count', 'Physical count');
    save(); toast('Saved'); stock(); return true;
  });
}

function openHistorySale() {
  if (!ownerMode) return;
  const menu = menuProducts();
  openModal('Past sales day', `
    <div class="infobox">No live stock deduction.</div>
    <label class="small">Date<input id="h_date" type="date" value="${iso()}" required></label>
    <label class="small">Product<select id="h_item">${menu.map(i => `<option value="${i.id}">${esc(i.name)}</option>`).join('')}</select></label>
    <label class="small">Qty<input id="h_qty" type="number" min="1" value="1" required></label>
    <label class="small">Revenue override<input id="h_rev" type="number" min="0" step="0.01"></label>
  `, () => {
    const date = document.getElementById('h_date').value;
    const it = itemById(document.getElementById('h_item').value);
    const qty = Number(document.getElementById('h_qty').value) || 0;
    if (!it || !date || qty <= 0) return false;
    let revenue = Number(document.getElementById('h_rev').value);
    if (!revenue) revenue = Number(it.sell) * qty;
    const cogs = recipeCost(it.id) * qty;
    data.sales.unshift({
      id: uid('sl'), date, payment: 'Mixed', status: 'confirmed', historical: true,
      lines: [{ itemId: it.id, name: it.name, qty, sell: revenue / qty, cost: cogs / qty }],
      revenue, cogs, gross: revenue - cogs
    });
    bookEntry('Income', 'Sales', revenue, 'Historical', date);
    bookEntry('Cost of sales', 'COGS', cogs, 'Historical', date);
    data.forecasts.push({ date, expected: expectedSalesForDate(date), actual: revenue });
    audit('history_sale', date + ' ' + M(revenue));
    save(); toast('Saved'); twin(); return true;
  });
}

function openHistoryBulk() {
  if (!ownerMode) return;
  openModal('Bulk daily totals', `
    <div class="infobox">YYYY-MM-DD, revenue[, expenses]</div>
    <textarea id="bulk"></textarea>
  `, () => {
    const text = document.getElementById('bulk').value.trim();
    if (!text) return false;
    let n = 0;
    const m = margin();
    text.split(/\n+/).forEach(line => {
      const parts = line.split(/[,\t;]/).map(x => x.trim()).filter(Boolean);
      if (parts.length < 2) return;
      const date = parts[0], rev = Number(parts[1]), exp = parts[2] != null ? Number(parts[2]) : 0;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || isNaN(rev)) return;
      const cogs = rev * (1 - m);
      data.sales.unshift({
        id: uid('sl'), date, payment: 'Mixed', status: 'confirmed', historical: true, bulk: true,
        lines: [{ itemId: 'bulk', name: 'Bulk', qty: 1, sell: rev, cost: cogs }],
        revenue: rev, cogs, gross: rev - cogs
      });
      bookEntry('Income', 'Sales', rev, 'Bulk', date);
      bookEntry('Cost of sales', 'COGS', cogs, 'Bulk', date);
      if (exp > 0) {
        data.expenses.unshift({ id: uid('ex'), date, amount: exp, category: 'Other', note: 'Bulk' });
        bookEntry('Expense', 'Other', exp, 'Bulk', date);
      }
      data.forecasts.push({ date, expected: expectedSalesForDate(date), actual: rev });
      n++;
    });
    if (!n) { toast('No valid lines'); return false; }
    audit('history_bulk', n + ' days');
    save(); toast('Imported ' + n); twin(); return true;
  });
}

/* Events */
document.addEventListener('click', e => {
  const go = e.target.closest('[data-go]');
  if (go) { show(go.dataset.go); return; }
  const t = e.target.closest('[data-action]');
  if (!t) return;
  const a = t.dataset.action;

  if (a === 'sales-tab') { salesTab = t.dataset.t; if (salesTab === 'new') ensureDraft(); sales(); }
  else if (a === 'twin-tab') { twinTab = t.dataset.t; twin(); }
  else if (a === 'stock-filter') { stockFilter = t.dataset.f; stock(); }
  else if (a === 'set-seller') {
    openModal('Seller name', `
      <div class="infobox">Required for anti-theft. Orders are tagged with this name.</div>
      <label class="small">Your name<input id="seller_n" required value="${esc(data.settings.sellerName || '')}"></label>
    `, () => {
      const n = document.getElementById('seller_n').value.trim();
      if (!n) return false;
      data.settings.sellerName = n;
      audit('seller_set', n);
      save(); toast('Seller set'); home(); return true;
    });
  }
  else if (a === 'new-order') {
    if (!data.settings.sellerName) { toast('Set seller name first'); home(); return; }
    draftOrder = null; ensureDraft(); salesTab = 'new'; show('sales');
  }
  else if (a === 'draft-add-normal') {
    syncDraftHeader();
    const prod = itemById(document.getElementById('d_prod').value);
    const qty = Number(document.getElementById('d_qty').value) || 1;
    if (!prod) return;
    const custom = emptyCustom();
    const unitPrice = Number(prod.sell);
    draftOrder.items.push({ productId: prod.id, name: prod.name, qty, custom, unitPrice, lineTotal: unitPrice * qty });
    toast('Added'); sales();
  }
  else if (a === 'draft-add-custom') {
    syncDraftHeader();
    const prod = itemById(document.getElementById('d_prod').value);
    const qty = Number(document.getElementById('d_qty').value) || 1;
    if (!prod) return;
    openCustomizer(prod, qty, null, custom => {
      const unitPrice = Number(prod.sell) + customExtraCost(custom);
      draftOrder.items.push({ productId: prod.id, name: prod.name, qty, custom, unitPrice, lineTotal: unitPrice * qty });
      toast('Custom added'); sales();
    });
  }
  else if (a === 'draft-add-tpl') {
    syncDraftHeader();
    const tpl = (data.templates || []).find(x => x.id === t.dataset.id);
    const prod = itemById(document.getElementById('d_prod').value);
    const qty = Number(document.getElementById('d_qty').value) || 1;
    if (!tpl || !prod) return;
    const custom = JSON.parse(JSON.stringify(tpl.custom));
    const unitPrice = Number(prod.sell) + customExtraCost(custom);
    draftOrder.items.push({ productId: prod.id, name: prod.name, qty, custom, unitPrice, lineTotal: unitPrice * qty });
    toast('Template applied'); sales();
  }
  else if (a === 'draft-remove') {
    const idx = Number(t.dataset.idx);
    draftOrder?.items?.splice(idx, 1);
    toast('Removed'); sales();
  }
  else if (a === 'draft-edit') {
    const idx = Number(t.dataset.idx);
    const line = draftOrder?.items?.[idx];
    const prod = line && itemById(line.productId);
    if (!line || !prod) return;
    openCustomizer(prod, line.qty, line.custom, custom => {
      line.custom = custom;
      line.unitPrice = Number(prod.sell) + customExtraCost(custom);
      line.lineTotal = line.unitPrice * line.qty;
      sales();
    });
  }
  else if (a === 'draft-clear') { draftOrder = null; sales(); }
  else if (a === 'draft-submit') {
    syncDraftHeader();
    if (!data.settings.sellerName) { toast('Set seller name'); return; }
    if (!draftOrder?.items?.length) { toast('Add products'); return; }
    const total = draftOrder.items.reduce((s, l) => s + l.lineTotal, 0);
    const order = {
      id: uid('ord'), number: nextOrderNo(),
      customer: draftOrder.customer || 'Walk-in',
      source: draftOrder.source || 'Counter',
      payment: draftOrder.payment || 'Cash',
      status: 'new', items: draftOrder.items.slice(), total,
      createdAt: new Date().toISOString(), date: iso(),
      seller: data.settings.sellerName
    };
    if (draftOrder.customer) {
      let cust = data.customers.find(c => c.name.toLowerCase() === draftOrder.customer.toLowerCase());
      if (!cust) { cust = { id: uid('cu'), name: draftOrder.customer, templates: [] }; data.customers.push(cust); }
      const firstCustom = draftOrder.items.find(l => isCustomized(l.custom));
      if (firstCustom) {
        const exists = (cust.templates || []).find(x => x.name === 'Usual');
        if (exists) exists.custom = JSON.parse(JSON.stringify(firstCustom.custom));
        else { cust.templates = cust.templates || []; cust.templates.unshift({ name: 'Usual', custom: JSON.parse(JSON.stringify(firstCustom.custom)) }); }
      }
    }
    data.orders.unshift(order);
    audit('order_create', '#' + order.number + ' · ' + M(total));
    save();
    draftOrder = null; salesTab = 'queue';
    toast('Order #' + order.number); sales(); home();
  }
  else if (a === 'order-status') {
    const o = data.orders.find(x => x.id === t.dataset.id);
    if (!o || o.status === 'completed') return;
    o.status = t.dataset.st;
    audit('order_status', '#' + o.number + ' → ' + o.status);
    save(); sales();
  }
  else if (a === 'order-complete') {
    const o = data.orders.find(x => x.id === t.dataset.id);
    if (!o || o.status === 'completed') return;
    if (!confirm('Complete #' + o.number + '? Stock will update.')) return;
    completeOrder(o);
    toast('Completed #' + o.number);
    sales(); home();
  }
  else if (a === 'order-cancel') {
    const o = data.orders.find(x => x.id === t.dataset.id);
    if (!o || o.status === 'completed') return;
    if (!confirm('Cancel #' + o.number + '?')) return;
    o.status = 'cancelled';
    audit('order_cancel', '#' + o.number);
    save(); toast('Cancelled'); sales();
  }
  else if (a === 'cust-add-sales') {
    openModal('Add customer', `<label class="small">Name<input id="cu_name" required></label>`, () => {
      const name = document.getElementById('cu_name').value.trim();
      if (!name) return false;
      if (data.customers.some(c => c.name.toLowerCase() === name.toLowerCase())) { toast('Already exists'); return false; }
      data.customers.push({ id: uid('cu'), name, templates: [] });
      audit('customer_add', name);
      save(); toast('Added'); customers(); return true;
    });
  }
  else if (a === 'cust-use') {
    draftOrder = null; ensureDraft();
    draftOrder.customer = t.dataset.name;
    salesTab = 'new'; show('sales');
  }
  else if (a === 'item-add') requireOwner(() => openItemForm(null));
  else if (a === 'item-edit') requireOwner(() => openItemForm(itemById(t.dataset.id)));
  else if (a === 'item-archive') requireOwner(() => {
    const it = itemById(t.dataset.id); if (!it) return;
    if (!confirm('Archive ' + it.name + '?')) return;
    it.archived = true; audit('item_archive', it.name); save(); stock(); toast('Archived');
  });
  else if (a === 'restock') requireOwner(() => openRestock(t.dataset.id));
  else if (a === 'stock-count') requireOwner(() => openStockCount());
  else if (a === 'history-sale') requireOwner(() => openHistorySale());
  else if (a === 'history-bulk') requireOwner(() => openHistoryBulk());
  else if (a === 'owner-unlock') requireOwner(() => { buildNav(); show('home'); });
  else if (a === 'owner-lock') {
    ownerMode = false;
    audit('owner_lock', 'Back to sales');
    save(); buildNav(); show('home'); toast('Sales mode');
  }
  else if (a === 'theme') {
    if (!ownerMode) return;
    data.settings.theme = t.dataset.t;
    applyTheme(); save(); toast('Theme: ' + t.dataset.t); more();
  }
  else if (a === 'cal-prev') { calMonth.setMonth(calMonth.getMonth() - 1); calendar(); }
  else if (a === 'cal-next') { calMonth.setMonth(calMonth.getMonth() + 1); calendar(); }
  else if (a === 'cal-add') {
    requireOwner(() => {
      openModal('Add calendar event', `
        <label class="small">Title<input id="ev_title" required></label>
        <label class="small">Date<input id="ev_date" type="date" value="${iso()}" required></label>
        <label class="small">Type<select id="ev_type"><option>expense</option><option>stock</option><option>worker</option><option>supplier</option><option>other</option></select></label>
        <label class="small">Recur<select id="ev_recur"><option value="">Once</option><option value="monthly">Monthly</option></select></label>
      `, () => {
        data.calendar.push({
          id: uid('ev'),
          title: document.getElementById('ev_title').value.trim(),
          date: document.getElementById('ev_date').value,
          type: document.getElementById('ev_type').value,
          recur: document.getElementById('ev_recur').value || ''
        });
        save(); toast('Event added'); calendar(); return true;
      });
    });
  }
  else if (a === 'cal-del') {
    requireOwner(() => {
      data.calendar = data.calendar.filter(x => x.id !== t.dataset.id);
      save(); calendar();
    });
  }
  else if (a === 'export') {
    if (!ownerMode) return;
    const ael = document.createElement('a');
    ael.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    ael.download = 'stockly-v4-' + iso() + '.json'; ael.click();
  }
  else if (a === 'reset') {
    if (!ownerMode || !confirm('Reset all data?')) return;
    localStorage.removeItem(KEY);
    ['stockly_elites_v3', 'stockly_elites_v2', 'stockly_elites_v1'].forEach(k => localStorage.removeItem(k));
    location.reload();
  }
});

applyTheme();
buildNav();
document.getElementById('todayMeta').textContent = today().toLocaleDateString('en-ZA', {
  weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
});
document.getElementById('onlinePill').textContent = navigator.onLine ? 'ONLINE' : 'OFFLINE';
window.addEventListener('online', () => document.getElementById('onlinePill').textContent = 'ONLINE');
window.addEventListener('offline', () => document.getElementById('onlinePill').textContent = 'OFFLINE');
refreshMenuCosts();
home();
document.querySelector('#mainNav button[data-s="home"]')?.classList.add('active');
if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
