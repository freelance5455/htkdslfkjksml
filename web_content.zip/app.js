// --- INITIALISATION ---
window.onload = function() {
    if (!localStorage.getItem('pixel_guide')) {
        document.getElementById('onboarding').classList.remove('hidden');
    }
    const savedTheme = localStorage.getItem('pixel_theme') || 'dark';
    document.body.className = 'theme-' + savedTheme;
    
    // Activer le bon bouton de thème au démarrage
    document.querySelectorAll('.theme-btn').forEach(btn => {
        if(btn.getAttribute('onclick').includes(savedTheme)) btn.classList.add('active');
        else btn.classList.remove('active');
    });

    chargerNotes();
};

function fermerOnboarding() {
    document.getElementById('onboarding').classList.add('hidden');
    localStorage.setItem('pixel_guide', 'true');
}

// --- GESTION DES THÈMES ---
function changerTheme(theme, btn) {
    document.body.className = 'theme-' + theme;
    localStorage.setItem('pixel_theme', theme);
    document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));
    if(btn) btn.classList.add('active');
}

// --- MENU FLOTTANT ---
function toggleFab() {
    document.getElementById('fab-actions').classList.toggle('hidden');
}

// --- NAVIGATION ---
function changerOnglet(id, btn) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + id).classList.add('active');
    if (btn) btn.classList.add('active');
    document.getElementById('fab-actions').classList.add('hidden');
}

// --- GESTION DES NOTES (LocalStorage) ---
let notes = JSON.parse(localStorage.getItem('pixel_notes')) || [];
let noteEnCoursDeModif = null; // Pour savoir si on modifie ou on ajoute

function ouvrirFormulaire() {
    document.getElementById('modalForm').classList.remove('hidden');
    document.getElementById('fab-actions').classList.add('hidden');
    document.getElementById('modalTitle').textContent = "Nouvelle Note";
    document.getElementById('noteForm').reset();
    noteEnCoursDeModif = null;
}

function fermerFormulaire() {
    document.getElementById('modalForm').classList.add('hidden');
}

function chargerNotes() {
    const container = document.getElementById('notesContainer');
    container.innerHTML = '';
    document.getElementById('noteCount').textContent = `${notes.length} note(s) sauvegardée(s)`;

    if (notes.length === 0) {
        container.innerHTML = '<p class="empty-msg">Aucune note pour le moment. Clique sur ⚡ pour écrire !</p>';
        return;
    }

    // Afficher de la plus récente à la plus ancienne
    const notesTriees = [...notes].reverse();

    notesTriees.forEach(note => {
        container.innerHTML += `
            <div class="note-card glass">
                <h4>${note.titre}</h4>
                <span class="note-cat">${note.categorie}</span>
                <p>${note.contenu}</p>
                <div class="note-actions">
                    <button class="btn-edit" onclick="modifierNote(${note.id})">✏️ Modifier</button>
                    <button class="btn-supp" onclick="supprimerNote(${note.id})">🗑️ Suppr</button>
                </div>
            </div>
        `;
    });
}

document.getElementById('noteForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const titre = document.getElementById('noteTitre').value;
    const contenu = document.getElementById('noteContenu').value;
    const categorie = document.getElementById('noteCategorie').value;

    if (noteEnCoursDeModif) {
        // Mode Modification
        const index = notes.findIndex(n => n.id === noteEnCoursDeModif);
        if (index !== -1) {
            notes[index] = { id: noteEnCoursDeModif, titre, contenu, categorie, date: Date.now() };
        }
    } else {
        // Mode Ajout
        notes.push({ id: Date.now(), titre, contenu, categorie, date: Date.now() });
    }

    localStorage.setItem('pixel_notes', JSON.stringify(notes));
    fermerFormulaire();
    chargerNotes();
    rechercherNotes(); // Mettre à jour la recherche aussi
});

function modifierNote(id) {
    const note = notes.find(n => n.id === id);
    if (!note) return;

    noteEnCoursDeModif = id;
    document.getElementById('modalTitle').textContent = "Modifier la Note";
    document.getElementById('noteTitre').value = note.titre;
    document.getElementById('noteContenu').value = note.contenu;
    document.getElementById('noteCategorie').value = note.categorie;
    
    document.getElementById('modalForm').classList.remove('hidden');
}

function supprimerNote(id) {
    if (confirm("Supprimer cette note ?")) {
        notes = notes.filter(n => n.id !== id);
        localStorage.setItem('pixel_notes', JSON.stringify(notes));
        chargerNotes();
        rechercherNotes();
    }
}

function supprimerTout() {
    if (confirm("⚠️ Supprimer TOUTES les notes ? Action irréversible.")) {
        notes = [];
        localStorage.setItem('pixel_notes', JSON.stringify(notes));
        chargerNotes();
        rechercherNotes();
    }
}

// --- RECHERCHE ---
function rechercherNotes() {
    const query = document.getElementById('searchInput').value.toLowerCase().trim();
    const container = document.getElementById('resultatsRecherche');
    container.innerHTML = '';

    if (query === '') return;

    const resultats = notes.filter(n => 
        n.titre.toLowerCase().includes(query) || 
        n.contenu.toLowerCase().includes(query)
    );

    if (resultats.length === 0) {
        container.innerHTML = '<p class="empty-msg">Aucune note trouvée.</p>';
        return;
    }

    resultats.forEach(note => {
        container.innerHTML += `
            <div class="note-card glass">
                <h4>${note.titre}</h4>
                <span class="note-cat">${note.categorie}</span>
                <p>${note.contenu}</p>
            </div>
        `;
    });
}
