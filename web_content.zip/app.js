
const API='https://api.binance.com/api/v3/';
let symbols=['BTCUSDT','ETHUSDT','BNBUSDT','SOLUSDT','XRPUSDT','ADAUSDT','DOGEUSDT','AVAXUSDT','LINKUSDT','DOTUSDT','LTCUSDT','ATOMUSDT'];
const DEFAULT_SYMBOLS=[...symbols];
const BUILD_ID='v49-history-protection-config-capital-fix';
let symbolCursor=0, symbolsLoaded=false, symbolsLastLoaded=0;
let selectedHistoryOperation=null;
let historySimSymbol='BTCUSDT';
let historySimBars=72;
let historySimOpen=false;
let historyProtectionOpen=false;
const SYMBOL_BATCH_SIZE=80;
const PREVIOUS_BUILD=localStorage.getItem('ct_build_id')||'';
const BUILD_CHANGED=PREVIOUS_BUILD!==BUILD_ID;
if(BUILD_CHANGED) localStorage.setItem('ct_build_id',BUILD_ID);
const D={capital:1000,cash:1000,dip:2.5,target:3.5,alloc:12,maxExposure:60,reserve:20,fee:.1,slip:.05,
trailActivate:3,trailDrop:2,maxBuyUsd:150,maxPositions:6,maxPerAsset:15,minScore:62,
partialBuy:2,lookback:500,intervalMs:10000,priceHistoryMinutes:5,individualBearishPct:2.5,individualDropWindowSec:30,btcBearishPct:2,btcDropWindowSec:180,
marketProtectionEnabled:true,marketProtectionWindowSec:60,marketProtectionDownPct:65,marketProtectionAvg5m:-0.7,marketProtectionConfirm:2,marketProtectionIndividualDropPct:2.5,individualBearishPct:2.5,marketProtectionCooldownMin:15,marketRecoveryDownPct:50,marketRecoveryAvg5m:0.25,marketRecoveryConfirm:3,
marketProtectionActive:false,marketProtectionCount:0,marketRecoveryCount:0,marketProtectionUntil:0,marketProtectionActivations:0,marketProtectionDeactivations:0,individual30sHistory:{},positions:{},trades:[],events:[],equity:1000,last:null,auto:true,startupCycles:0,candidateStreaks:{},btcBearishPct:3,marketTrendSamples:[],firstRunObservationDone:false};
let S=(JSON.parse(localStorage.getItem('ct_v44_state')||'null') || JSON.parse(localStorage.getItem('ct_v3_state')||'null'))||D;
S={...D,...S,positions:S?.positions||{},trades:Array.isArray(S?.trades)?S.trades:[],events:Array.isArray(S?.events)?S.events:[],startupCycles:Number(S?.startupCycles||0),candidateStreaks:S?.candidateStreaks||{},btcBearishPct:Number(S?.btcBearishPct??2),btcDropWindowSec:Number(S?.btcDropWindowSec??180),priceHistoryMinutes:Number(S?.priceHistoryMinutes??5),individualDropWindowSec:Number(S?.individualDropWindowSec??30),intervalMs:Number(S?.intervalMs??10000),marketTrendSamples:Array.isArray(S?.marketTrendSamples)?S.marketTrendSamples:[],firstRunObservationDone:!!S?.firstRunObservationDone,marketProtectionEnabled:S?.marketProtectionEnabled!==false,marketProtectionWindowSec:Number(S?.marketProtectionWindowSec??60),marketProtectionDownPct:Number(S?.marketProtectionDownPct??70),marketProtectionAvg5m:Number(S?.marketProtectionAvg5m??-1),marketProtectionConfirm:Number(S?.marketProtectionConfirm??2),marketProtectionCooldownMin:Number(S?.marketProtectionCooldownMin??10),marketRecoveryDownPct:Number(S?.marketRecoveryDownPct??55),marketRecoveryAvg5m:Number(S?.marketRecoveryAvg5m??0),marketRecoveryConfirm:Number(S?.marketRecoveryConfirm??3),marketProtectionActive:!!S?.marketProtectionActive,marketProtectionCount:Number(S?.marketProtectionCount||0),marketRecoveryCount:Number(S?.marketRecoveryCount||0),marketProtectionUntil:Number(S?.marketProtectionUntil||0),marketProtectionActivations:Number(S?.marketProtectionActivations||0),marketProtectionDeactivations:Number(S?.marketProtectionDeactivations||0),individualBearishPct:Number(S?.individualBearishPct??2.5),individual30sHistory:S?.individual30sHistory&&typeof S.individual30sHistory==='object'?S.individual30sHistory:{}};
// Primeira abertura da app: começar sempre sem posições/compras anteriores.
// O saldo inicial da carteira deve ser SEMPRE o Capital configurado, e nunca um 1000 fixo.
const INITIAL_CLEAN_KEY='ct_v49_initial_clean_capital_done';
if(localStorage.getItem(INITIAL_CLEAN_KEY)!=='1'){
  S.positions={};
  S.trades=[];
  S.events=[];
  S.cash=Math.max(0,Number(S.capital)||0);
  S.equity=Math.max(0,Number(S.capital)||0);
  S.last=null;
  S.startupCycles=0;
  S.candidateStreaks={};
  S.firstRunObservationDone=false;
  S.marketTrendSamples=[];
  S.individual30sHistory={};
  localStorage.setItem(INITIAL_CLEAN_KEY,'1');
  save();
}
// Migração da correção: versões anteriores podiam deixar a carteira com 1000 fixos,
// ignorando o Capital definido pelo utilizador. Se ainda não existem operações/posições,
// sincronizamos o saldo com o Capital configurado sem mexer em carteiras já em uso.
const CAPITAL_SYNC_KEY='ct_v49_capital_sync_done';
if(localStorage.getItem(CAPITAL_SYNC_KEY)!=='1'){
  const cleanWallet=Object.keys(S.positions||{}).length===0 && (!Array.isArray(S.trades)||S.trades.length===0);
  if(cleanWallet){
    S.cash=Math.max(0,Number(S.capital)||0);
    S.equity=Math.max(0,Number(S.capital)||0);
    save();
  }
  localStorage.setItem(CAPITAL_SYNC_KEY,'1');
}
// Na primeira abertura desta versão começa também uma nova observação de 5 minutos.
if(BUILD_CHANGED){Object.assign(S,{maxExposure:60,reserve:20,maxPerAsset:15,minScore:62,marketProtectionWindowSec:60,marketProtectionDownPct:65,marketProtectionAvg5m:-0.7,marketProtectionConfirm:2,marketProtectionIndividualDropPct:2.5,marketProtectionCooldownMin:15,marketRecoveryDownPct:50,marketRecoveryAvg5m:0.25,marketRecoveryConfirm:3,btcBearishPct:2,btcDropWindowSec:180,priceHistoryMinutes:5,individualBearishPct:2.5,individualDropWindowSec:30,intervalMs:10000,trailActivate:3,trailDrop:2,firstRunObservationDone:false,marketTrendSamples:[],individual30sHistory:{}});Object.values(S.positions||{}).forEach(p=>{p.trailActivate=3;p.trailDrop=2;p.trailArmed=false;delete p.partial;delete p.downCount;delete p.protectionCount;delete p.reversalCount;delete p.reversalDrop;delete p.reversalConfirm;});save();}
let tab='dash', market={}, candles={}, chartCandles={}, chartTF='1h', selectedSymbol=null, selectedPosition=null, selectedAlert=null, marketSearch='', marketSearchOpen=false, chartViews={};
let dataStatus={}, lastDataUpdate=0;
try{const cached=JSON.parse(localStorage.getItem('ct_v44_candles')||'null');if(cached&&typeof cached==='object')candles=cached}catch(e){}
function saveCandles(){try{localStorage.setItem('ct_v44_candles',JSON.stringify(candles))}catch(e){}}
async function loadChartCandles(s,tf){
  if(!s||!['5m','15m','1h'].includes(tf))return;
  const key=s+'_'+tf;
  if(chartCandles[key]&&chartCandles[key].length>=2)return chartCandles[key];
  // Para 1h, usa imediatamente o histórico que a app já descarregou.
  if(tf==='1h'&&Array.isArray(candles[s])&&candles[s].length>=2){chartCandles[key]=candles[s];render();}
  try{
    const limits={'5m':288,'15m':192,'1h':72};
    const data=await jget(`klines?symbol=${s}&interval=${tf}&limit=${limits[tf]||72}`);
    if(Array.isArray(data)&&data.length>=2){chartCandles[key]=data;render();return data;}
  }catch(e){}
  return chartCandles[key]||candles[s]||[];
}
function dataAgeText(){if(!lastDataUpdate)return 'Ainda sem atualização';const sec=Math.max(0,Math.round((Date.now()-lastDataUpdate)/1000));return sec<60?sec+'s atrás':Math.floor(sec/60)+'min atrás';}

function save(){localStorage.setItem('ct_v44_state',JSON.stringify(S)); localStorage.setItem('ct_v3_state',JSON.stringify(S))}
function logEvent(type,symbol,reason,extra={}){
  const now=Date.now(), key=type+'|'+(symbol||'')+'|'+(reason||'');
  const last=(S.events||[])[0];
  if(last&&last.key===key&&now-last.time<5*60*1000)return;
  S.events=[{time:now,type,symbol:symbol||'',reason:reason||'',key,...extra},...(S.events||[])].slice(0,250);
}
function tradeStats(){
  const sells=(S.trades||[]).filter(t=>String(t.type).toUpperCase()==='SELL');
  const profits=sells.map(t=>Number(t.profit)||0);
  const wins=profits.filter(v=>v>0), losses=profits.filter(v=>v<0);
  const realized=profits.reduce((a,v)=>a+v,0);
  const grossWin=wins.reduce((a,v)=>a+v,0), grossLoss=Math.abs(losses.reduce((a,v)=>a+v,0));
  let curve=Number(S.capital)||100,peak=curve,maxDD=0;
  sells.slice().sort((a,b)=>a.time-b.time).forEach(t=>{curve+=Number(t.profit)||0;peak=Math.max(peak,curve);if(peak>0)maxDD=Math.max(maxDD,(peak-curve)/peak*100)});
  const avgHold=sells.length?sells.reduce((a,t)=>a+Number(t.holdMs||0),0)/sells.length:0;
  return {sells,wins,losses,realized,winRate:sells.length?wins.length/sells.length*100:0,avg:sells.length?realized/sells.length:0,profitFactor:grossLoss?grossWin/grossLoss:(grossWin?Infinity:0),best:wins.length?Math.max(...wins):0,worst:losses.length?Math.min(...losses):0,maxDD,avgHold};
}
function eventLabel(e){const sym=String(e.symbol||'').replace('USDT','');return e.type==='BLOCK'?`⛔ ${sym}: ${e.reason}`:e.type==='BUY'?`🟢 ${sym}: entrada`:e.type==='SELL'?`🔴 ${sym}: saída`:e.reason||e.type}
function pct(x){return (x*100).toFixed(2)+'%'}
function money(x){return Number(x||0).toLocaleString('pt-PT',{style:'currency',currency:'USD',maximumFractionDigits:2})}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function jget(path){let r=await fetch(API+path);if(!r.ok)throw Error(r.status);return r.json()}
async function loadBinanceSymbols(force=false){
  if(symbolsLoaded && !force && Date.now()-symbolsLastLoaded<6*60*60*1000)return;
  try{
    const info=await jget('exchangeInfo');
    const blockedBases=/^(USDT|USDC|FDUSD|TUSD|BUSD|DAI|USDP)$/;
    const leveraged=/(UP|DOWN|BULL|BEAR)$/;
    const discovered=(info.symbols||[])
      .filter(x=>x.status==='TRADING' && x.quoteAsset==='USDT' && x.isSpotTradingAllowed!==false)
      .map(x=>x.symbol)
      .filter(s=>{const base=s.replace(/USDT$/,'');return base&&!blockedBases.test(base)&&!leveraged.test(base)});
    symbols=Array.from(new Set(['BTCUSDT',...discovered])).sort((a,b)=>a==='BTCUSDT'?-1:b==='BTCUSDT'?1:a.localeCompare(b));
    symbolsLoaded=true;symbolsLastLoaded=Date.now();symbolCursor=0;
    try{localStorage.setItem('ct_v44_symbols',JSON.stringify(symbols));localStorage.setItem('ct_v44_symbols_time',String(symbolsLastLoaded))}catch(e){}
  }catch(e){
    try{const cached=JSON.parse(localStorage.getItem('ct_v44_symbols')||'null');if(Array.isArray(cached)&&cached.length){symbols=cached;symbolsLoaded=true;symbolsLastLoaded=Number(localStorage.getItem('ct_v44_symbols_time')||0)}}catch(_e){}
  }
}
function score(c){
  let rsi=calcRSI(c.map(x=>+x[4]).slice(-120)), closes=c.map(x=>+x[4]), ema20=ema(closes,20), ema50=ema(closes,50);
  let p=+c[c.length-1][4], hi=Math.max(...c.slice(-168).map(x=>+x[2])), lo=Math.min(...c.slice(-168).map(x=>+x[3]));
  let vol=c.slice(-24).reduce((a,x)=>a+ +x[5],0)/24, volNow=+c[c.length-1][5];
  let trend=ema20>ema50?22:0, rsiPts=(rsi>=42&&rsi<=65)?18:0, above= p>ema20?12:0;
  let dipPts=p<hi*(1-S.dip/100)?12:0, volPts=volNow>=vol*.9?10:0, reboundPts=p>lo*1.03?8:0;
  let penalty=rsi>72?-18:(rsi<30?-8:0);
  let s=trend+rsiPts+above+dipPts+volPts+reboundPts+penalty;
  return {score:Math.max(0,Math.min(100,s)),rsi,ema20,ema50,hi,lo,vol,volNow,p,parts:{trend,rsi:rsiPts,above,dip:dipPts,volume:volPts,rebound:reboundPts,penalty}};
}
function entryQuality(s,c){
  const extension=((c.p-c.ema20)/c.ema20)*100;
  if(extension>4.5)return {ok:false,why:'Preço demasiado esticado acima da EMA20'};
  if(c.rsi>72)return {ok:false,why:'RSI elevado — evitar comprar no topo'};
  const v=volatility(candles[s]);
  const calm=v<=1.2;
  if(calm && c.p>c.ema20 && c.ema20>=c.ema50 && c.volNow>=c.vol*.85)
    return {ok:true,level:'calma',why:'Entrada adaptada à baixa volatilidade'};
  return {ok:true,level:'normal',why:'Entrada validada pelo timeframe 1h'};
}
function opportunityProfile(s,c){
  const q=entryQuality(s,c);
  const v=volatility(candles[s]);
  let level='normal', min=60, need=2;
  if(q.level==='forte' && c.score>=68){ level='forte'; min=68; need=1; }
  else if(v<=1.2 && q.level==='calma' && c.score>=56){ level='calma'; min=56; need=2; }
  else if(c.score>=60){ level='normal'; min=60; need=2; }
  else return {level:'aguardar',min:60,need:2,ok:false,why:'Score abaixo do nível de oportunidade'};
  return {level,min,need,ok:c.score>=min,q,vol:v};
}

function ema(a,n){let k=2/(n+1),e=a[0];for(let i=1;i<a.length;i++)e=a[i]*k+e*(1-k);return e}
function calcRSI(a,n=14){if(a.length<=n)return 50;let g=0,l=0;for(let i=a.length-n;i<a.length;i++){let d=a[i]-a[i-1];if(d>0)g+=d;else l-=d}if(!l)return 100;return 100-100/(1+g/l)}
function posValue(){return Object.entries(S.positions).reduce((a,[s,p])=>a+p.qty*(market[s]?.last||p.entry),0)}
function equity(){return S.cash+posValue()}
function exposure(){return equity()?posValue()/equity()*100:0}
function volatility(c){
  if(!c||c.length<24)return 1.5;
  const a=c.slice(-24).map(x=>(+x[2]-+x[3])/(+x[4]||1)*100);
  return a.reduce((s,v)=>s+v,0)/a.length;
}
function trailSettings(){
  // Venda normal: trailing único e fixo, definido pelo utilizador na Configuração.
  const activate=Math.max(0.05,Math.min(100,Number(S.trailActivate)||3));
  const drop=Math.max(0.05,Math.min(50,Number(S.trailDrop)||2));
  return {activate,drop,vol:null,label:'personalizado'};
}

function btcMarketGate(){
  const b=market.BTCUSDT;
  if(!b||!b.dataOk)return {ok:false,reason:'A aguardar dados do BTC'};
  // Regra pedida: o BTC só confirma compras quando está a subir.
  // Se estiver a cair ou sem variação positiva, não comprar.
  const change3m=Number(b.change3m);
  const rising=Number.isFinite(change3m) && change3m>0;
  const falling=Number.isFinite(change3m) && change3m<0;
  const ok=rising;
  const windowMin=Math.round(Number(S.btcDropWindowSec??180)/60);
  return {
    ok,rising,falling,change3m,
    reason:ok
      ? `BTC a subir (${change3m.toFixed(2)}% nos últimos ${windowMin} min) — compra permitida`
      : falling
        ? `BTC em queda (${change3m.toFixed(2)}% nos últimos ${windowMin} min) — compra bloqueada`
        : `BTC sem subida confirmada (${Number.isFinite(change3m)?change3m.toFixed(2)+'%':'sem histórico'} nos últimos ${windowMin} min) — compra bloqueada`
  };
}
function updateMarketTrendObservation(){
  const prices={};
  let count=0;
  for(const s of symbols){
    const c=market[s];
    if(c&&c.dataOk&&Number.isFinite(Number(c.last))){prices[s]=Number(c.last);count++;}
  }
  if(count<5)return;
  const now=Date.now();
  const samples=Array.isArray(S.marketTrendSamples)?S.marketTrendSamples:[];
  samples.push({t:now,prices});
  S.marketTrendSamples=samples.filter(x=>x&&Number(x.t)>now-11*60*1000).slice(-60);
}
function marketTrendGate(){
  // A análise de 5 minutos acontece apenas na primeira utilização da app.
  // Depois de concluída, a app volta ao funcionamento normal e não repete esta espera.
  if(S.firstRunObservationDone)return {ok:true,ready:true,bearish:false,downPct:0,avg5m:0,reason:'Análise inicial concluída'};
  const samples=Array.isArray(S.marketTrendSamples)?S.marketTrendSamples:[];
  const now=Date.now(), target=now-5*60*1000;
  if(samples.length<2)return {ok:false,ready:false,reason:'A analisar tendência do mercado (5 min)'};
  let base=samples[0];
  for(const x of samples){if(Number(x.t)<=target)base=x;else break;}
  if(!base||now-Number(base.t)<5*60*1000)return {ok:false,ready:false,reason:'A analisar tendência do mercado (5 min)'};
  const changes=[];
  for(const s of symbols){
    const p0=Number(base.prices?.[s]), p1=Number(market[s]?.last);
    if(p0>0&&p1>0)changes.push((p1/p0-1)*100);
  }
  if(changes.length<5)return {ok:false,ready:false,reason:'A aguardar dados suficientes para a análise de 5 min'};
  const downPct=changes.filter(x=>x<0).length/changes.length*100;
  const avg5m=changes.reduce((a,v)=>a+v,0)/changes.length;
  return {ok:true,ready:true,bearish:downPct>=70&&avg5m<0,downPct,avg5m,reason:'Análise inicial de 5 min concluída'};
}
function marketRegime(){
  const vals=symbols.map(s=>market[s]).filter(c=>c&&c.dataOk);
  if(vals.length<5)return {bear:false,recovery:false,downPct:0,reason:'Dados de mercado insuficientes'};
  const down=vals.filter(c=>c.chg<0).length/vals.length*100;
  const avgScore=vals.reduce((a,c)=>a+c.score,0)/vals.length;
  const leaders=vals.filter(c=>(c.score>=S.minScore)&&c.p>c.ema20&&c.rsi>=40&&c.rsi<=68).length;
  const bear=down>=70 && avgScore<55;
  const recovery=!bear || leaders>=2;
  return {bear,recovery,downPct:down,avgScore,leaders,reason:bear&&!recovery?'Mercado geral em queda — a aguardar sinais de recuperação':''};
}
function marketProtectionStatus(){
  if(!S.marketProtectionEnabled)return {active:false,trigger:false,recovery:false,reason:'Proteção de mercado desativada'};
  const vals=symbols.map(s=>market[s]).filter(c=>c&&c.dataOk&&Number.isFinite(Number(c.chg)));
  if(vals.length<5)return {active:!!S.marketProtectionActive,trigger:false,recovery:false,reason:'A aguardar dados suficientes do mercado'};
  const downPct=vals.filter(c=>Number(c.chg)<0).length/vals.length*100;
  const avg24=vals.reduce((a,c)=>a+Number(c.chg||0),0)/vals.length;
  const samples=Array.isArray(S.marketTrendSamples)?S.marketTrendSamples:[];
  const windowSec=Math.max(30,Number(S.marketProtectionWindowSec??60));
  let avgWindow=null, breadthWindow=null;
  if(samples.length>=2){
    const target=Date.now()-windowSec*1000;
    let base=samples[0];
    for(const x of samples){if(Number(x.t)<=target)base=x;else break;}
    if(base&&Date.now()-Number(base.t)>=windowSec*1000){
      const changes=[];
      for(const s of symbols){const p0=Number(base.prices?.[s]),p1=Number(market[s]?.last);if(p0>0&&p1>0)changes.push((p1/p0-1)*100)}
      if(changes.length>=5){avgWindow=changes.reduce((a,v)=>a+v,0)/changes.length;breadthWindow=changes.filter(v=>v<0).length/changes.length*100}
    }
  }
  const broadTrigger=downPct>=Number(S.marketProtectionDownPct||70) && (avgWindow==null || avgWindow<=Number(S.marketProtectionAvg5m??-1));
  const individualThreshold=Math.max(0.5,Number(S.marketProtectionIndividualDropPct??4));
  const held=[];
  for(const s of Object.keys(S.positions||{})){
    const p0=Number(S.positions[s]?.entry), p1=Number(market[s]?.last);
    if(p0>0&&p1>0)held.push({s,drop:(p1/p0-1)*100});
  }
  const worstHeldDrop=held.length?Math.min(...held.map(x=>x.drop)):0;
  const individualTrigger=held.some(x=>x.drop<=-individualThreshold);
  const trigger=broadTrigger||individualTrigger;
  const recovery=downPct<=Number(S.marketRecoveryDownPct||55) && (avgWindow!=null && avgWindow>=Number(S.marketRecoveryAvg5m??0)) && worstHeldDrop>-individualThreshold;
  const reason=individualTrigger?'Queda forte numa posição — proteção antecipada':trigger?'Mercado geral em queda — proteção ativa':recovery?'Sinais de recuperação do mercado':'';
  return {active:!!S.marketProtectionActive,trigger,broadTrigger,individualTrigger,recovery,downPct,avg24,avg5m:avgWindow,breadth5m:breadthWindow,windowSec,individualThreshold,worstHeldDrop,reason};
}
function updateMarketProtection(){
  const g=marketProtectionStatus();
  if(!S.marketProtectionEnabled){S.marketProtectionActive=false;S.marketProtectionCount=0;S.marketRecoveryCount=0;return g;}
  if(!S.marketProtectionActive){
    if(g.trigger)S.marketProtectionCount=(S.marketProtectionCount||0)+1;else S.marketProtectionCount=0;
    if((S.marketProtectionCount||0)>=Math.max(1,Number(S.marketProtectionConfirm||2))){
      S.marketProtectionActive=true;S.marketProtectionActivations=(S.marketProtectionActivations||0)+1;S.marketProtectionCount=0;S.marketRecoveryCount=0;S.marketProtectionUntil=Date.now()+Math.max(0,Number(S.marketProtectionCooldownMin||10))*60000;
      for(const s of Object.keys(S.positions)){
        if(sellPart(s,1,'Proteção de mercado: queda generalizada',true)){}
      }
      logEvent('BLOCK','MARKET','Proteção de mercado ativada — posições fechadas');
    }
  }else{
    const now=Date.now();
    const minMs=Math.max(0,Number(S.marketProtectionCooldownMin||10))*60000;

    // Enquanto o mercado continuar em queda, a proteção NÃO expira.
    // O período mínimo de 10 min é apenas o tempo mínimo; uma nova janela
    // é prolongada automaticamente sempre que o sinal de queda continua.
    if(g.trigger){
      S.marketRecoveryCount=0;
      const extendedUntil=now+minMs;
      if(extendedUntil>Number(S.marketProtectionUntil||0)){
        S.marketProtectionUntil=extendedUntil;
      }
    }else{
      const cooldownDone=now>=Number(S.marketProtectionUntil||0);
      if(cooldownDone&&g.recovery)S.marketRecoveryCount=(S.marketRecoveryCount||0)+1;
      else if(!g.recovery)S.marketRecoveryCount=0;
      if(cooldownDone&&(S.marketRecoveryCount||0)>=Math.max(1,Number(S.marketRecoveryConfirm||3))){
        S.marketProtectionActive=false;S.marketProtectionDeactivations=(S.marketProtectionDeactivations||0)+1;S.marketRecoveryCount=0;S.marketProtectionUntil=0;
        logEvent('BLOCK','MARKET','Proteção de mercado desativada — recuperação confirmada');
      }
    }
  }
  return {...g,active:!!S.marketProtectionActive};
}
function netGainPct(p,price){return ((price*(1-S.slip/100)*(1-S.fee/100))/p.entry-1)*100}

function startupActive(){
  return !S.firstRunObservationDone;
}
function startupText(){
  if(!startupActive())return '';
  const samples=Array.isArray(S.marketTrendSamples)?S.marketTrendSamples:[];
  const first=Number(samples[0]?.t||Date.now());
  const elapsed=Math.max(0,Date.now()-first);
  const mins=Math.min(5,Math.floor(elapsed/60000));
  return `A analisar tendências antes da primeira compra • ${mins}/5 min`;
}
function confidenceReady(s,c){
  if(!c||!c.dataOk||startupActive())return false;
  // A procura de oportunidades continua a usar o score, mas deixa de exigir
  // confirmações/filtros adicionais antes da compra. A única proteção de mercado
  // na entrada é o estado do BTC.
  return !!opportunityProfile(s,c).ok;
}
function canBuy(s,c){
  if(!c||!c.dataOk)return {ok:false,why:'Dados históricos indisponíveis/desatualizados'};
  if(startupActive())return {ok:false,why:startupText()};
  // A proteção global de mercado continua a ser monitorizada e registada,
  // mas não bloqueia indefinidamente novas compras. A entrada usa BTC como
  // proteção global de mercado e mantém os filtros da própria moeda.
  const btc=btcMarketGate(false);
  // Regra global de entrada: só permite novas compras quando o BTC está a subir.
  // A confirmação do BTC não usa EMA, RSI, score ou um limiar de queda.
  if(!btc.ok)return {ok:false,why:'BTC: '+btc.reason};
  if(S.positions[s])return {ok:false,why:'Já existe posição'};
  if(Object.keys(S.positions).length>=S.maxPositions)return {ok:false,why:'Limite de posições'};
  if(exposure()>=S.maxExposure)return {ok:false,why:'Exposição máxima'};
  const op=opportunityProfile(s,c);
  if(!op.ok)return {ok:false,why:op.why||'Sem oportunidade suficiente'};
  let budget=Math.min(Number(S.maxBuyUsd)||150,S.capital*S.alloc/100,S.cash-S.capital*S.reserve/100,Math.max(0,S.capital*S.maxPerAsset/100));
  return budget>0?{ok:true,budget,level:op.level}:{ok:false,why:'Reserva/capital insuficiente'};
}
function buy(s,c,budget){
  budget=Math.min(Number(budget)||0,Math.max(0,Number(S.maxBuyUsd)||150));
  if(!(budget>0))return;
  let slip=c.p*(S.slip/100), price=c.p+slip, fee=budget*S.fee/100, spend=budget-fee, qty=spend/price;
  S.cash-=budget; const ts=trailSettings(candles[s]);
  const buyTime=Date.now(), buyId=`B${buyTime}_${s}`;
  S.positions[s]={qty,initialQty:qty,entry:price,avg:price,invested:budget,costBasisTotal:budget,boughtAt:buyTime,buyId,peak:price,peakProfit:0,trailArmed:false,score:c.score,trailActivate:ts.activate,trailDrop:ts.drop,volatility:ts.vol,
    entryReason:`Oportunidade ${opportunityProfile(s,c).level}; Score ${c.score}/100; RSI ${c.rsi.toFixed(1)}; tendência EMA20/EMA50`};
  S.trades.push({time:buyTime,type:'BUY',symbol:s,qty,price,fee,cost:budget,buyId,reason:S.positions[s].entryReason});
  logEvent('BUY',s,S.positions[s].entryReason,{score:c.score});
}
function sellPart(s,frac,reason,allowLoss=false){
  let p=S.positions[s],c=market[s];
  if(!p||!c||!c.dataOk)return false;
  const qtyBefore=p.qty;
  let qty=Math.min(qtyBefore,qtyBefore*frac),price=c.last*(1-S.slip/100),gross=qty*price,fee=gross*S.fee/100;
  const basisTotal=Number(p.costBasisTotal);
  const cost=Number.isFinite(basisTotal)&&basisTotal>0 ? basisTotal*(qty/qtyBefore) : qty*p.entry;
  const profit=gross-fee-cost;
  if(profit<=0&&!allowLoss)return false;
  S.cash+=gross-fee;p.qty-=qty;
  if(Number.isFinite(basisTotal)&&basisTotal>0)p.costBasisTotal=Math.max(0,basisTotal-cost);
  const sellTime=Date.now();
  S.trades.push({time:sellTime,type:'SELL',symbol:s,qty,price,fee,profit,cost,buyId:p.buyId||'',holdMs:Math.max(0,sellTime-Number(p.boughtAt||sellTime)),reason,peak:p.peak});
  logEvent('SELL',s,reason,{profit});
  if(p.qty<=1e-12)delete S.positions[s];
  return true;
}

function manage(s,c){
  const p=S.positions[s];
  if(!p||!c||!c.dataOk)return;

  // Venda normal: um único trailing baseado no máximo atingido desde a entrada.
  // Não existem vendas parciais, proteção progressiva ou reversão independente.
  if(c.last>p.peak){
    p.peak=c.last;
  }
  p.peakProfit=Math.max(Number(p.peakProfit||0),Number(p.initialQty||p.qty||0)*(p.peak-p.entry));

  const ta=Math.max(0.05,Math.min(100,Number(p.trailActivate??S.trailActivate)||3));
  const td=Math.max(0.05,Math.min(50,Number(p.trailDrop??S.trailDrop)||2));
  const gain=(c.last/p.entry-1)*100;

  if(gain>=ta)p.trailArmed=true;
  if(!p.trailArmed)return;

  const triggerPrice=p.peak*(1-td/100);
  if(c.last<=triggerPrice){
    const peakGain=(p.peak/p.entry-1)*100;
    sellPart(s,1,`Trailing: saída total após recuo de ${td.toFixed(2)}% desde o pico de +${peakGain.toFixed(2)}%`,true);
  }
}

let refreshInFlight=false;
const REFRESH_INTERVAL_DEFAULT=10000;
async function refresh(){
  if(refreshInFlight)return;
  refreshInFlight=true;
  try{
    await loadBinanceSymbols();
    // A Binance tem muitas pares USDT. Para não ultrapassar os limites públicos da API,
    // os candles de 1h são analisados em lotes rotativos; o ticker atualiza todos os pares.
    const arr=await jget('ticker/24hr');
    const ticker={};arr.forEach(x=>ticker[x.symbol]={last:+x.lastPrice,chg:+x.priceChangePercent,vol:+x.quoteVolume});
    const batch=[];
    for(let i=0;i<SYMBOL_BATCH_SIZE && symbols.length;i++){
      batch.push(symbols[(symbolCursor+i)%symbols.length]);
    }
    symbolCursor=(symbolCursor+SYMBOL_BATCH_SIZE)%Math.max(1,symbols.length);
    const priority=new Set(Object.keys(S.positions||{}));priority.add('BTCUSDT');
    for(const s of priority)if(!batch.includes(s))batch.push(s);
    const results=await Promise.all(batch.map(async s=>{
      try{
        const requests=[jget(`klines?symbol=${s}&interval=1h&limit=${S.lookback}`)];
        if(s==='BTCUSDT') requests.push(jget(`klines?symbol=${s}&interval=3m&limit=2`));
        const [c,c3]=await Promise.all(requests);
        if(!Array.isArray(c)||c.length<60)throw Error('Histórico insuficiente');
        const age=Math.max(0,Date.now()-Number(c[c.length-1][6]));
        return {s,c,c3,ok:age<=2*60*60*1000,age};
      }catch(e){return {s,c:null,ok:false,error:String(e)}}
    }));
    // Mantém os dados dos restantes pares enquanto o lote seguinte é analisado.
    for(const s of symbols){
      if(ticker[s] && !market[s])market[s]={...ticker[s],p:ticker[s].last,score:null,rsi:null,dataOk:false};
      else if(ticker[s]&&market[s])market[s]={...market[s],...ticker[s],p:ticker[s].last};
    }
    // Histórico rotativo de preços para a proteção de entrada de 30 s.
    // Guardamos cerca de 2 minutos (até 15 snapshots a cada ~10 s) para que
    // a medição exista mesmo antes de a moeda atingir o score mínimo.
    const now30=Date.now();
    const priceHistory=S.individual30sHistory&&typeof S.individual30sHistory==='object'?S.individual30sHistory:{};
    const historyMinutes=Math.max(1,Math.min(30,Number(S.priceHistoryMinutes??5)));
    const historyCutoff=now30-historyMinutes*60*1000;
    for(const s of symbols){
      const last=Number(ticker[s]?.last);
      if(!Number.isFinite(last)||last<=0)continue;
      const arr=Array.isArray(priceHistory[s])?priceHistory[s].filter(x=>Number(x?.t)>=historyCutoff&&Number.isFinite(Number(x?.p))):[];
      arr.push({t:now30,p:last});
      const maxPoints=Math.max(10,Math.ceil((historyMinutes*60*1000)/Math.max(5000,Number(S.intervalMs??10000)))+2);
      priceHistory[s]=arr.slice(-maxPoints);
    }
    S.individual30sHistory=priceHistory;
    for(const s of symbols){
      const hist=priceHistory[s], c=market[s];
      if(s==='BTCUSDT'||!c?.dataOk||!Array.isArray(hist)||hist.length<2)continue;
      const dropWindowMs=Math.max(15000,Math.min(180000,Number(S.individualDropWindowSec??30)*1000));
      const target=now30-dropWindowMs;
      let base=null;
      for(const x of hist){
        if(Number(x.t)<=target)base=x;
        else break;
      }
      const age=base?now30-Number(base.t):Infinity;
      c.change30s=(base&&age>=Math.max(10000,dropWindowMs-5000)&&age<=dropWindowMs+30000&&Number(base.p)>0) ? (Number(c.last)/Number(base.p)-1)*100 : null;
    }
    for(const r of results){
      const s=r.s,t=ticker[s];if(!t)continue;
      if(r.ok){
        candles[s]=r.c;dataStatus[s]={ok:true,age:r.age,error:''};
        const q=score(r.c);
        const btcWindowMs=Math.max(30000,Math.min(600000,Number(S.btcDropWindowSec??180)*1000));
        let change3m=null;
        if(s==='BTCUSDT'){
          const hist=Array.isArray(S.individual30sHistory?.BTCUSDT)?S.individual30sHistory.BTCUSDT:[];
          const target=Date.now()-btcWindowMs; let base=null;
          for(const x of hist){if(Number(x.t)<=target)base=x;else break;}
          if(base&&Number(base.p)>0)change3m=((t.last/Number(base.p)-1)*100);
          else if(Array.isArray(r.c3)&&r.c3.length>=1&&Number(r.c3[0][4])>0)change3m=((t.last/Number(r.c3[0][4])-1)*100);
        }
        market[s]={...t,...q,p:t.last,dataOk:true,dataAge:r.age,change3m};
      }else{
        dataStatus[s]={ok:false,age:r.age||Infinity,error:r.error||'Dados inválidos'};
        market[s]={...t,p:t.last,score:null,rsi:null,dataOk:false};
      }
    }
    lastDataUpdate=Date.now();saveCandles();
    // Atualiza a janela de observação inicial de 5 minutos antes de avaliar compras.
    updateMarketTrendObservation();
    const initialTrend=marketTrendGate();
    const marketProtection=updateMarketProtection();
    if(!S.firstRunObservationDone && initialTrend.ready){
      S.firstRunObservationDone=true;
      save();
    }
    // Avalia o filtro de segurança do BTC uma vez por ciclo.
    const btcGate=btcMarketGate();
    for(const s of symbols){
      const c=market[s];if(!c||!c.dataOk)continue;
      manage(s,c);
      const op=opportunityProfile(s,c);
      const baseOk=op.ok && !S.positions[s] && Object.keys(S.positions).length<S.maxPositions && exposure()<S.maxExposure;
      if(baseOk)S.candidateStreaks[s]=(S.candidateStreaks[s]||0)+1;
      else S.candidateStreaks[s]=0;
      const b=canBuy(s,c);
      if(!b.ok && !S.positions[s] && S.auto) logEvent('BLOCK',s,b.why);
      if(S.auto&&b.ok&&confidenceReady(s,c))buy(s,c,b.budget);
    }
    S.equity=equity();S.last=Date.now();S.lastError='';save();render();
  }catch(e){S.lastError=String(e);save();render()}finally{
    refreshInFlight=false;
    if(S.auto){const ms=Math.max(5000,Math.min(60000,Number(S.intervalMs??REFRESH_INTERVAL_DEFAULT)));setTimeout(()=>refresh(),ms);}
  }
}
function chartHTML(s){
 let c=market[s]||{}, p=S.positions[s], key=s+'_'+chartTF, arr=chartCandles[key]||candles[s]||[], q=c.parts||{};
 let v=chartViews[key]; if(!v)v=chartViews[key]={count:chartDefaultCount(chartTF),start:Math.max(0,arr.length-chartDefaultCount(chartTF)),cross:null};
 let status=p?(p.trailArmed?'Trailing armado':'A acompanhar'):'Sem posição';
 return `<tr class="chartRow"><td colspan="6"><div class="chartBox" data-chart-symbol="${s}" data-no-tab-swipe="1" data-disable-tab-swipe="1" data-swipe-threshold="0.60">
 <div class="chartHead"><div><b>${s.replace('USDT','')}/USDT</b> <span class="muted">${money(c.last||0)}</span></div><div class="tiny">${status}</div></div>
 <div class="chartTFs" role="group" aria-label="Intervalo das velas">${['5m','15m','1h'].map(tf=>`<button type="button" class="chartTF ${chartTF===tf?'active':''}" data-chart-tf="${tf}" data-chart-symbol="${s}">${tf}</button>`).join('')}<button type="button" class="chartTF" data-chart-reset="1" data-chart-symbol="${s}">24h</button><button type="button" class="chartTF" data-chart-zoom="out" data-chart-symbol="${s}" title="Afastar">−</button><button type="button" class="chartTF" data-chart-zoom="in" data-chart-symbol="${s}" title="Aproximar">+</button></div>
 <canvas class="chartCanvas" id="chart-${s}" data-chart-symbol="${s}" tabindex="0"></canvas>
 <div class="crosshairControl" aria-label="Controlar a barra de preço"><div class="crosshairControlTop"><span>☝️ Desliza para escolher o ponto</span><b class="crosshairReadout">${v.cross!=null&&arr.length?money(Number(arr[Math.max(0,Math.min(arr.length-1,v.start+v.cross))][4])):'Toque no gráfico'}</b></div><input class="crosshairRange" id="crosshair-${s}" data-chart-symbol="${s}" type="range" min="0" max="${Math.max(0,v.count-1)}" value="${v.cross==null?Math.max(0,v.count-1):Math.max(0,Math.min(v.count-1,v.cross))}" aria-label="Mover barra de preço para a esquerda ou direita"></div>
 <div class="scoreWhy"><span>Trend +${q.trend||0}</span><span>RSI +${q.rsi||0}</span><span>EMA +${q.above||0}</span><span>Dip +${q.dip||0}</span><span>Volume +${q.volume||0}</span><span>Rebound +${q.rebound||0}</span>${(q.penalty||0)?`<span>Penalty ${q.penalty}</span>`:''}</div>
 <div class="chartHint">24h inicial • arraste para navegar • roda/pinça para zoom • toque no gráfico para cruzeta e OHLC • ${arr.length} velas ${chartTF}</div>
 </div></td></tr>`;
}
function dashboardTopSymbols(){
 const fixed=['BTCUSDT','ETHUSDT','ADAUSDT'];
 const ranked=typeof topSymbols==='function'?topSymbols():symbols.slice();
 const result=[];
 for(const s of fixed){ if(symbols.includes(s) && !result.includes(s)) result.push(s); }
 for(const s of ranked){ if(!result.includes(s) && result.length<12) result.push(s); }
 return result.slice(0,12);
}
function tableMarket(limit=null){
 const q=String(marketSearch||'').trim().toUpperCase().replace(/\s+/g,'');
 const aliases={BITCOIN:'BTC',ETHEREUM:'ETH',BINANCECOIN:'BNB',SOLANA:'SOL',RIPPLE:'XRP',CARDANO:'ADA',DOGECOIN:'DOGE',AVALANCHE:'AVAX',CHAINLINK:'LINK',POLKADOT:'DOT',LITECOIN:'LTC',COSMOS:'ATOM'};
 const searchKey=aliases[q]||q;
 const allSymbols=symbols.slice(); const baseSymbols=limit===12?dashboardTopSymbols():allSymbols;
 let filtered=baseSymbols.slice();
 if(q){ const exact=filtered.filter(s=>s===searchKey+'USDT'||s.replace('USDT','')===searchKey); const matches=filtered.filter(s=>s!==searchKey+'USDT'&&s.replace('USDT','')!==searchKey && (s.replace('USDT','').includes(searchKey)||s.includes(searchKey))); const rest=filtered.filter(s=>!exact.includes(s)&&!matches.includes(s)); filtered=exact.concat(matches,rest); }
 const totalLabel=limit===12?`${filtered.length} principais de ${allSymbols.length} moedas`: `${filtered.length} de ${allSymbols.length} moedas`;
 return `<div class="card"><div class="marketToolbar"><div><b>${limit===12?'Top 12 moedas':'Mercado'}</b><div class="sub">${totalLabel}</div></div>${limit===12?'':'<button type="button" class="marketSearchBtn" id="marketSearchBtn" aria-label="Procurar moeda" title="Procurar moeda">⌕</button>'}</div>
 ${limit!==12 && (marketSearchOpen||q)?`<div class="marketSearchBox"><input id="marketSearchInput" type="search" inputmode="search" autocomplete="off" placeholder="Procurar moeda (ex.: BTC, ETH)" value="${esc(marketSearch)}" aria-label="Procurar moeda"><button type="button" id="marketSearchClear" aria-label="Limpar pesquisa">×</button></div>`:''}
 <div class="scroll"><table><tr><th>Cripto</th><th>Preço</th><th>24h</th><th>Score</th><th>RSI</th><th>Ação</th></tr>${filtered.map(s=>{let c=market[s];if(!c)return `<tr class="coinRow" data-symbol="${s}"><td class="coinTap">${s}</td><td colspan=5>...</td></tr>`;let b=canBuy(s,c);let ds=c.dataOk?'<span class="good">ATUAL</span>':'<span class="bad">DADOS DESATUALIZADOS</span>';let open=selectedSymbol===s;return `<tr class="coinRow ${open?'coinSelected':''}" data-symbol="${s}" aria-selected="${open?'true':'false'}"><td class="coinTap">${s.replace('USDT','')}</td><td>${money(c.last)}</td><td class="${c.chg>=0?'good':'bad'}">${c.chg.toFixed(2)}%</td><td>${c.score==null?'—':c.score}</td><td>${c.rsi==null?'—':c.rsi.toFixed(1)}</td><td>${ds}<br>${b.ok?'<span class="good">COMPRAR</span>':(startupActive()?'':'<span class="muted">'+esc(b.why)+'</span>')}${(S.candidateStreaks[s]||0)>0?`<br><span class="tiny">confirmação ${(S.candidateStreaks[s]||0)}/2</span>`:''}</td></tr>${open?chartHTML(s):''}`}).join('') || `<tr><td colspan="6" class="muted">Nenhuma moeda encontrada.</td></tr>`}</table></div></div>`;
}
function chartDefaultCount(tf){return tf==='5m'?288:tf==='15m'?96:24}
function chartViewFor(s){const key=s+'_'+chartTF,arr=chartCandles[key]||candles[s]||[],count=chartDefaultCount(chartTF);let v=chartViews[key];if(!v)v=chartViews[key]={count,start:Math.max(0,arr.length-count),cross:null};v.count=Math.max(12,Math.min(arr.length||count,v.count||count));v.start=Math.max(0,Math.min(Math.max(0,arr.length-v.count),v.start));return {key,arr,v}}
function drawChart(s){
 const canvas=document.getElementById('chart-'+s); const {key,arr,v}=chartViewFor(s); if(!canvas||arr.length<2)return;
 const visible=arr.slice(v.start,v.start+v.count); if(visible.length<2)return;
 const rect=canvas.getBoundingClientRect(),dpr=Math.max(1,window.devicePixelRatio||1);canvas.width=Math.max(1,Math.floor(rect.width*dpr));canvas.height=Math.max(1,Math.floor(rect.height*dpr));
 const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,rect.width,rect.height);
 const pad={l:8,r:62,t:10,b:30},volH=42,w=rect.width-pad.l-pad.r,h=rect.height-pad.t-pad.b-volH;
 const data=visible.map(k=>({t:+k[0],o:+k[1],hi:+k[2],lo:+k[3],c:+k[4],vol:+k[5]})),closes=data.map(x=>x.c),e20=emaSeries(closes,20),e50=emaSeries(closes,50);
 let all=[];data.forEach(k=>all.push(k.hi,k.lo));const p=S.positions[s];if(p)all.push(+p.entry,+p.peak);const min=Math.min(...all),max=Math.max(...all),span=max-min||1;
 const y=val=>pad.t+h-(val-min)/span*h,x=i=>pad.l+w*(data.length===1?0:i/(data.length-1));
 ctx.font='10px system-ui';ctx.textBaseline='middle';
 ctx.strokeStyle='#203044';ctx.lineWidth=1;for(let i=0;i<5;i++){let yy=pad.t+h*i/4;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(pad.l+w,yy);ctx.stroke();}
 const vmax=Math.max(...data.map(d=>d.vol||0),1);const step=Math.max(2,Math.min(16,w/data.length*.72));
 data.forEach((k,i)=>{const xx=x(i),yo=y(k.o),yc=y(k.c),yh=y(k.hi),yl=y(k.lo),up=k.c>=k.o;ctx.strokeStyle=up?'#43d17b':'#ff6875';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(xx,yh);ctx.lineTo(xx,yl);ctx.stroke();ctx.fillStyle=up?'#43d17b':'#ff6875';ctx.fillRect(xx-step/2,Math.min(yo,yc),step,Math.max(1,Math.abs(yc-yo)));let vh=volH*(k.vol||0)/vmax;ctx.globalAlpha=.28;ctx.fillRect(xx-step/2,pad.t+h+volH-vh,step,vh);ctx.globalAlpha=1;});
 function line(vals,stroke,width){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.beginPath();vals.forEach((val,i)=>{if(val==null)return;const xx=x(i),yy=y(val);i?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy)});ctx.stroke()}
 line(e20,'#43d17b',1.2);line(e50,'#ffb45c',1.2);
 ctx.setLineDash([5,4]);if(p){ctx.strokeStyle='#43d17b';ctx.beginPath();ctx.moveTo(pad.l,y(p.entry));ctx.lineTo(pad.l+w,y(p.entry));ctx.stroke();ctx.strokeStyle='#ff6875';ctx.beginPath();ctx.moveTo(pad.l,y(p.peak));ctx.lineTo(pad.l+w,y(p.peak));ctx.stroke();}ctx.setLineDash([]);
 ctx.fillStyle='#93a4b8';ctx.textAlign='left';ctx.fillText('VOL',pad.l,pad.t+h+volH/2);ctx.textAlign='right';for(let i=0;i<5;i++){const val=max-span*i/4;ctx.fillText(money(val),rect.width-5,pad.t+h*i/4);}
 const fmt=d=>d.toLocaleString([], {day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});ctx.textAlign='left';ctx.textBaseline='alphabetic';ctx.fillText(fmt(new Date(data[0].t)),pad.l,rect.height-5);ctx.textAlign='right';ctx.fillText(fmt(new Date(data[data.length-1].t)),rect.width-pad.r,rect.height-5);
 if(v.cross!=null){const ci=Math.max(0,Math.min(data.length-1,v.cross)),d=data[ci],xx=x(ci),yy=y(d.c);ctx.strokeStyle='#718096';ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(xx,pad.t);ctx.lineTo(xx,pad.t+h+volH);ctx.moveTo(pad.l,yy);ctx.lineTo(pad.l+w,yy);ctx.stroke();ctx.setLineDash([]);
   // Cruzeta: tooltip OHLC + etiqueta de preço no eixo direito.
   const boxX=Math.min(Math.max(xx-48,pad.l),pad.l+w-96);
   ctx.fillStyle='#dbe7f5';ctx.fillRect(boxX,pad.t,96,32);
   ctx.fillStyle='#07101d';ctx.textAlign='left';ctx.textBaseline='top';
   ctx.fillText(`O ${money(d.o)}  H ${money(d.hi)}`,boxX+4,pad.t+4);
   ctx.fillText(`L ${money(d.lo)}  C ${money(d.c)}`,boxX+4,pad.t+17);
   const priceText=money(d.c), tagW=Math.max(52,ctx.measureText(priceText).width+14);
   const tagY=Math.max(pad.t,Math.min(pad.t+h-16,yy-8));
   ctx.fillStyle='#6ea8fe';ctx.fillRect(rect.width-tagW,tagY,tagW,17);
   ctx.fillStyle='#07101d';ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='10px system-ui';
   ctx.fillText(priceText,rect.width-tagW/2,tagY+8.5);
   ctx.strokeStyle='#718096';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(pad.l+w,yy);ctx.stroke();}
 canvas.dataset.chartStart=v.start;canvas.dataset.chartCount=v.count;canvas.dataset.chartKey=key;
 const range=document.getElementById(`crosshair-${s}`);
 if(range){range.max=String(Math.max(0,v.count-1));range.value=String(v.cross==null?Math.max(0,v.count-1):Math.max(0,Math.min(v.count-1,v.cross)));const rr=canvas.parentElement.querySelector('.crosshairReadout');if(rr){const idx=Math.max(0,Math.min(data.length-1,v.cross==null?data.length-1:v.cross));rr.textContent=money(data[idx].c)}}
}
function emaSeries(a,n){if(!a.length)return[];const k=2/(n+1),out=[a[0]];for(let i=1;i<a.length;i++)out.push(a[i]*k+out[i-1]*(1-k));return out}
function bindCharts(){
 if(selectedSymbol)requestAnimationFrame(()=>drawChart(selectedSymbol));
 document.querySelectorAll('.coinRow').forEach(el=>el.onclick=()=>{let s=el.dataset.symbol;selectedSymbol=selectedSymbol===s?null:s;chartTF='1h';if(selectedSymbol){if(Array.isArray(candles[s])&&candles[s].length>=2){chartCandles[s+'_1h']=candles[s];render();}loadChartCandles(selectedSymbol,chartTF);}else render()});
 document.querySelectorAll('.chartTF').forEach(btn=>btn.onclick=async e=>{e.stopPropagation();const s=btn.dataset.chartSymbol;if(btn.dataset.chartReset){const {key,arr}=chartViewFor(s);chartViews[key]={count:chartDefaultCount(chartTF),start:Math.max(0,arr.length-chartDefaultCount(chartTF)),cross:null};render();return}if(btn.dataset.chartZoom){const {key,arr,v}=chartViewFor(s);const old=v.count,next=Math.max(12,Math.min(arr.length||old,Math.round(old*(btn.dataset.chartZoom==='in'?.72:1.4))));const ratio=.5,anchor=v.start+Math.round(old*ratio);v.count=next;v.start=Math.max(0,Math.min(Math.max(0,arr.length-next),anchor-Math.round(next*ratio)));drawChart(s);return}const tf=btn.dataset.chartTf;chartTF=tf;render();loadChartCandles(s,tf)});
 document.querySelectorAll('.crosshairRange').forEach(range=>{
   range.oninput=e=>{const s=range.dataset.chartSymbol;const {v}=chartViewFor(s);v.cross=Math.max(0,Math.min(v.count-1,Number(e.target.value)||0));requestAnimationFrame(()=>drawChart(s));};
   range.onpointerdown=e=>e.stopPropagation();
 });
 document.querySelectorAll('.chartCanvas').forEach(canvas=>{
   const s=canvas.dataset.chartSymbol;let drag=null,pointers=new Map(),pinch=null,touchStart=null;
   const redraw=()=>requestAnimationFrame(()=>drawChart(s));
   const setCrosshair=(clientX,clientY)=>{
     const {arr,v}=chartViewFor(s),r=canvas.getBoundingClientRect();
     const padL=8,padR=62,w=Math.max(1,r.width-padL-padR),h=Math.max(1,r.height-10-30-42);
     const px=Math.max(0,Math.min(w,clientX-r.left-padL));
     const py=Math.max(0,Math.min(h,clientY-r.top-10));
     v.cross=Math.max(0,Math.min(v.count-1,Math.round(px/w*(Math.max(1,v.count)-1))));
     // Mantém a barra horizontal no preço da vela tocada.
     redraw();
   };
   canvas.onpointerdown=e=>{
     canvas.setPointerCapture?.(e.pointerId);
     pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
     if(pointers.size===2){
       const a=[...pointers.values()];pinch={dist:Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),count:chartViewFor(s).v.count};drag=null;touchStart=null;return;
     }
     touchStart={id:e.pointerId,x:e.clientX,y:e.clientY,moved:false};
     drag={id:e.pointerId,x:e.clientX,start:chartViewFor(s).v.start};
     setCrosshair(e.clientX,e.clientY);
   };
   canvas.onpointermove=e=>{
     if(pointers.has(e.pointerId))pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
     const {arr,v}=chartViewFor(s);
     if(pointers.size===2&&pinch){
       const a=[...pointers.values()],dist=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);
       const next=Math.max(12,Math.min(arr.length||pinch.count,Math.round(pinch.count*pinch.dist/Math.max(1,dist))));
       const center=(a[0].x+a[1].x)/2,ratio=Math.max(0,Math.min(1,(center-canvas.getBoundingClientRect().left)/Math.max(1,canvas.clientWidth)));
       const anchor=v.start+Math.round(v.count*ratio);v.count=next;v.start=Math.max(0,Math.min(Math.max(0,arr.length-next),anchor-Math.round(next*ratio)));redraw();return;
     }
     if(drag&&drag.id===e.pointerId){
       const moved=Math.abs(e.clientX-drag.x)>6;
       if(moved&&touchStart)touchStart.moved=true;
       if(touchStart&&!touchStart.moved){
         setCrosshair(e.clientX,e.clientY);
         return;
       }
       const pxPerC=Math.max(2,canvas.clientWidth/Math.max(1,v.count));
       const delta=Math.round((drag.x-e.clientX)/pxPerC);
       v.start=Math.max(0,Math.min(Math.max(0,arr.length-v.count),drag.start+delta));
       redraw();return;
     }
     setCrosshair(e.clientX,e.clientY);
   };
   canvas.onpointerup=e=>{
     pointers.delete(e.pointerId);
     if(pointers.size<2)pinch=null;
     if(drag&&drag.id===e.pointerId)drag=null;
     if(touchStart&&touchStart.id===e.pointerId){
       if(!touchStart.moved)setCrosshair(e.clientX,e.clientY);
       touchStart=null;
     }
   };
   canvas.onpointercancel=e=>{
     pointers.delete(e.pointerId);if(pointers.size<2)pinch=null;
     if(drag&&drag.id===e.pointerId)drag=null;
     if(touchStart&&touchStart.id===e.pointerId)touchStart=null;
   };
   canvas.onwheel=e=>{e.preventDefault();const {arr,v}=chartViewFor(s);if(!arr.length)return;const old=v.count,next=Math.max(12,Math.min(arr.length,Math.round(old*(e.deltaY<0?.78:1.28))));const ratio=Math.max(0,Math.min(1,e.offsetX/Math.max(1,canvas.clientWidth-70)));const anchor=v.start+Math.round(old*ratio);v.count=next;v.start=Math.max(0,Math.min(Math.max(0,arr.length-next),anchor-Math.round(next*ratio)));redraw();};
   canvas.ondblclick=()=>{const {key,arr}=chartViewFor(s),count=chartDefaultCount(chartTF);chartViews[key]={count:Math.min(count,arr.length||count),start:Math.max(0,arr.length-count),cross:null};redraw();};
   canvas.onmouseleave=()=>{const {v}=chartViewFor(s);v.cross=null;redraw();};
 });
}

function openProfit(){
  return Object.entries(S.positions||{}).reduce((total,[symbol,p])=>{
    const price=Number(market[symbol]?.last||p.entry||0);
    const qty=Number(p.qty||0);
    const entry=Number(p.entry||0);
    return total + qty*(price-entry);
  },0);
}
function alertDetailHTML(s,type){
 const c=market[s]||{}, p=S.positions[s]||{};
 const q=c.parts||{};
 const op=c.dataOk?opportunityProfile(s,c):null;
 const btc=market.BTCUSDT||{};
 const btcGate=btcMarketGate();
 const btcOk=!!btcGate.ok;
 const regime=marketRegime();
 const reasons=[];
 if(type==='trail'){
   reasons.push(`O motor detetou uma posição aberta com trailing armado.`);
   if(Number.isFinite(p.peak)) reasons.push(`Pico registado: ${money(p.peak)}; preço atual: ${money(c.last||p.entry||0)}.`);
   if(Number.isFinite(p.trailDrop)) reasons.push(`O trailing está configurado para uma retração de ${Number(p.trailDrop).toFixed(2)}%.`);
   if(Number.isFinite(p.entry)) reasons.push(`Entrada: ${money(p.entry)}; lucro atual aproximado: ${money(Number(p.qty||0)*(Number(c.last||p.entry)-Number(p.entry)))}`);
 }else{
   reasons.push(`Score ${c.score??'—'}/100: o alerta aparece quando o score atual atinge o mínimo configurado (${S.minScore}).`);
   if(q.trend) reasons.push(`Tendência: EMA20 acima da EMA50 (+${q.trend}).`); else reasons.push('Tendência: EMA20 não está acima da EMA50, por isso não soma pontos.');
   reasons.push(`RSI ${Number.isFinite(c.rsi)?c.rsi.toFixed(1):'—'}: ${q.rsi?`dentro da faixa favorável (+${q.rsi})`:'fora da faixa que dá pontos'}.`);
   reasons.push(`Preço vs EMA20: ${q.above?`acima (+${q.above})`:'não acima, sem pontos'}.`);
   reasons.push(`Correção desde o máximo: ${q.dip?`detetada (+${q.dip})`:'não suficiente para somar pontos'}.`);
   reasons.push(`Volume: ${q.volume?`volume atual acompanha a média (+${q.volume})`:'volume abaixo do critério, sem pontos'}.`);
   reasons.push(`Recuperação: ${q.rebound?`preço recuperou desde o mínimo (+${q.rebound})`:'sem recuperação suficiente para pontuar'}.`);
   if(q.penalty) reasons.push(`Penalização aplicada: ${q.penalty} pontos.`);
 }
 const btcReasons=[];
 if(!btcOk) btcReasons.push(btcGate.reason);
 if(!btcOk) reasons.push(`BTC não confirma a compra: ${btcReasons.join('; ')}.`);
 return `<div class="alert-item-detail"><div class="alert-item-detail-title">${type==='trail'?'Por que este alerta está ativo':'Por que esta moeda está no alerta'}</div><div class="alert-item-reasons">${reasons.map((r,i)=>`<div class="alert-item-reason"><span>${i+1}</span><div>${esc(r)}</div></div>`).join('')}</div><div class="alert-item-checks"><div class="mini"><span class="muted">BTC</span><b class="${btcOk?'good':'bad'}">${btcOk?'Confirmado':'Não confirmado'}</b></div><div class="mini"><span class="muted">Mercado</span><b>${regime.bear&&!regime.recovery?'Bloqueado':'Sem bloqueio'}</b></div><div class="mini"><span class="muted">Qualidade</span><b>${op?esc(op.level):'—'}</b></div><div class="mini"><span class="muted">Confirmações</span><b>${S.candidateStreaks?.[s]||0}/${op?.need||2}</b></div></div></div>`;
}

function dashboard(){
 let ev=equity(), pl=openProfit(),good=Object.values(dataStatus).filter(x=>x.ok).length;
 let sells=S.trades.filter(t=>t.type==='SELL'), realized=sells.reduce((a,t)=>a+(t.profit||0),0), wins=sells.filter(t=>(t.profit||0)>0).length;
 let best=sells.reduce((m,t)=>Math.max(m,t.profit||0),0), open=Object.keys(S.positions).length;
 let alerts=[]; symbols.forEach(s=>{let c=market[s],p=S.positions[s];if(c?.dataOk&&c.score>=S.minScore&&!p)alerts.push({symbol:s,type:'signal'});if(p?.trailArmed)alerts.push({symbol:s,type:'trail'}) });
 const btc=market.BTCUSDT, btcGate=btcMarketGate(), regime=marketRegime();
 // O estado do BTC deve aparecer sempre nos Alertas do motor, não apenas quando bloqueia.
 // Assim o utilizador consegue ver a percentagem atual e o limite configurado.
 alerts.unshift({symbol:'BTCUSDT',type:btcGate?.ok?'btc_status':'btc_block'});
 return `${startupActive()?`<div class="card"><b>🔎 Preparação inicial</b><div class="sub">${startupText()}. A app ainda não compra; está a validar tendência, RSI, EMA, volume e recuperação.</div></div>`:''}
 <div class="grid">
 <div class="card"><div class="muted">Capital</div><div class="metric">${money(ev)}</div></div>
 <div class="card" id="dashboardResultCard" data-toggle-result-positions="1" style="cursor:pointer" title="Mostrar/ocultar moedas em posição"><div class="muted">Resultados</div><div class="metric ${pl>=0?'good':'bad'}">${money(pl)}</div></div>
 <div class="card"><div class="muted">Caixa</div><div class="metric">${money(S.cash)}</div></div>
 <div class="card"><div class="muted">Exposição</div><div class="metric">${exposure().toFixed(1)}%</div></div>
 </div>
 <div id="dashboardResultPositions" class="card v44-result-expanded" style="display:none;margin-top:10px">
 <div class="v44-result-title">📊 <b>Resultados</b></div>
 <div class="v44-coins-box">
   <div class="v44-coins-title">💰 <b>Lucro das posições abertas</b></div>
   <div class="v44-coins-head"><span>Moeda</span><span>Posição</span><span>Lucro atual</span></div>
   <div>${dashboardResultPositions()}</div>
 </div>
</div>
 <div class="card"><b>📊 Resumo das operações</b>
 <div class="miniGrid">
  <div class="mini" data-goto-positions="1" style="cursor:pointer" title="Ir para os detalhes das posições"><span class="muted">Posições</span><b>${open}</b></div>
  <div class="mini v44-sales-click" onclick="toggleV44SalesPanel()" style="cursor:pointer" title="Mostrar vendas"><span class="muted">Lucro realizado</span><b class="good">${money(realized)}</b></div>
  <div class="mini"><span class="muted">Taxa de acerto</span><b>${sells.length?((wins/sells.length)*100).toFixed(0):'0'}%</b></div>
  <div class="mini v44-sales-click" onclick="toggleV44SalesPanel()" style="cursor:pointer" title="Mostrar moedas vendidas"><span class="muted">Vendas</span><b>${sells.length}</b></div>
  <div class="mini v44-best-sale-click" onclick="toggleV44BestSalePanel()" style="cursor:pointer" title="Mostrar a moeda da melhor venda"><span class="muted">Melhor venda</span><b class="good">${money(best)}</b></div>
  <div class="mini"><span class="muted">Atualização</span><b>${S.last?new Date(S.last).toLocaleTimeString():'—'}</b></div>
 </div>
</div>
<div id="v44SalesPanel" class="card v44-sales-panel" style="display:none">
 <div class="v44-sales-title">💰 Vendas das últimas 24h</div>
 <div class="v44-sales-head"><span>Moeda</span><span>Hora</span><span>Máx. após compra</span><span>Lucro</span></div>
 <div id="v44SalesRows"></div>
</div>
<div id="v44BestSalePanel" class="card v44-best-sale-panel" style="display:none"></div>
 <div class="card"><b>🔔 Alertas do motor</b>${alerts.length?alerts.slice(0,6).map(a=>{const c=market[a.symbol]||{},p=S.positions[a.symbol]||{},open=selectedAlert===a.symbol+'|'+a.type;let label=a.type==='btc_block'?`🔴 BTC em queda — compra bloqueada (${Number.isFinite(btcGate.change3m)?btcGate.change3m.toFixed(2)+'%':'sem histórico'})`:a.type==='btc_status'?`🟢 BTC a subir — compra permitida (${Number.isFinite(btcGate.change3m)?'+'+btcGate.change3m.toFixed(2)+'%':'sem histórico'})`:a.type==='trail'?`🟠 ${a.symbol.replace('USDT','')} — trailing armado`:`🟢 ${a.symbol.replace('USDT','')} — score ${c.score??'—'}`;return `<div class="alert tiny alert-item-item ${open?'alert-item-open':''}" data-alert-symbol="${a.symbol}" data-alert-type="${a.type}" role="button" tabindex="0" aria-expanded="${open?'true':'false'}"><div><b>${label}</b></div>${a.type==='btc_block'||a.type==='btc_status'?`<div class="sub" style="margin-top:4px">${btcGate.reason}${btc?.dataOk?'':' • a aguardar dados'}</div>`:(open?alertDetailHTML(a.symbol,a.type):'')}</div>`}).join(''):'<div class="sub" style="margin-top:7px">Nenhum sinal destacado neste momento.</div>'}</div>
 <div class="card"><b>Motor</b><div class="sub">Automático: ${S.auto?'SIM':'NÃO'} • operações bloqueadas quando os dados estão desatualizados.</div>
 <div class="actions" style="margin-top:9px"><button class="primary" onclick="S.auto=!S.auto;save();render()">${S.auto?'Parar automação':'Ligar automação'}</button><button onclick="refresh()">Atualizar agora</button></div></div>
 <h2>Principais criptomoedas</h2>${tableMarket(12)}
 <h2 id="dashPositions">Posições abertas</h2>${positions(true)}
 <div class="alert tiny">Regra principal: compra apenas após análise inicial, BTC a subir, mercado sem bloqueio, tendência 1h e 2 confirmações consecutivas. Evita entradas demasiado esticadas. Venda normal: trailing único — retração configurada desde o máximo fecha 100% da posição.</div>`
}
function dashboardResultPositions(){
 let keys=Object.keys(S.positions||{});
 if(!keys.length)return '<div class="muted">Nenhuma posição aberta.</div>';
 let totalProfit=0;
 const rows=keys.map(s=>{
   const p=S.positions[s]||{};
   const price=Number(market[s]?.last||p.entry||0);
   const qty=Number(p.qty||0);
   const currentValue=qty*price;
   const profit=qty*(price-Number(p.entry||0));
   totalProfit+=profit;
   const cls=profit>=0?'good':'bad';
   const sign=profit>=0?'+':'';
   return `<div class="v44-result-row">
     <span class="v44-coin">${s.replace('USDT','')}</span>
     <span class="v44-buy">${money(currentValue)}</span>
     <span class="v44-pnl ${cls}">${sign}${money(profit)}</span>
   </div>`;
 }).join('');
 const totalCls=totalProfit>=0?'good':'bad', totalSign=totalProfit>=0?'+':'';
 return `${rows}<div class="v44-result-total"><span>Lucro atual total</span><b class="${totalCls}">${totalSign}${money(totalProfit)}</b></div>`;
}
function positions(protectSwipe=false){
 let keys=Object.keys(S.positions);if(!keys.length)return '<div class="card muted">Sem posições.</div>';
 const swipeAttr=(protectSwipe||tab==='positions')?' data-no-tab-swipe="1"':'';
 return `<div class="card"><div class="scroll positionsSwipeArea"${swipeAttr}><table><tr><th>Ativo</th><th>Entrada</th><th>Atual</th><th>Lucro</th><th>Pico</th><th>Trail</th></tr>${
 keys.map(s=>{let p=S.positions[s],c=market[s]||{last:p.entry},g=(c.last/p.entry-1)*100,inv=p.invested||p.qty*p.entry,open=selectedPosition===s;return `<tr class="posRow${open?' posSelected':''}" data-pos="${s}" style="cursor:pointer"><td><b>${s}</b>${open?' ▾':' ▸'}</td><td>${money(p.entry)}</td><td>${money(c.last)}</td><td class="${g>=0?'good':'bad'}">${g.toFixed(2)}%</td><td>${money(p.peak)}</td><td>${p.trailArmed?'armado · recuo -'+Number(p.trailDrop||S.trailDrop).toFixed(2)+'%':'aguarda +'+Number(p.trailActivate||S.trailActivate).toFixed(2)+'%'}</td></tr>${open?`<tr><td colspan="6"><div class="card" style="margin:6px 0"><b>💰 ${s}</b><div class="miniGrid"><div class="mini"><span class="muted">Dinheiro investido</span><b>${money(inv)}</b></div><div class="mini"><span class="muted">Quantidade</span><b>${p.qty.toFixed(8)}</b></div><div class="mini"><span class="muted">Valor atual</span><b>${money(p.qty*c.last)}</b></div><div class="mini"><span class="muted">Lucro atual</span><b class="${g>=0?'good':'bad'}">${money(p.qty*(c.last-p.entry))}</b></div><div class="mini"><span class="muted">Lucro máximo atingido</span><b class="${(p.peakProfit||0)>=0?'good':'bad'}">${(p.peakProfit||0)>=0?'+':''}${money(p.peakProfit||0)}</b></div></div><div class="tiny muted">Entrada: ${money(p.entry)} · Pico: ${money(p.peak)}</div></div></td></tr>`:''}`}).join('')
 }</table></div></div>`
}

function historyOperationDetail(st){
  if(selectedHistoryOperation!=='best' && selectedHistoryOperation!=='worst') return '';
  const sells=st.sells||[];
  if(!sells.length) return '<div class="sub" style="margin-top:10px">Ainda não existem operações fechadas.</div>';
  const candidates=selectedHistoryOperation==='best' ? sells.filter(t=>Number(t.profit||0)>0) : sells.filter(t=>Number(t.profit||0)<0);
  if(!candidates.length) return '<div class="alert" style="margin-top:10px">Não existe uma '+(selectedHistoryOperation==='best'?'melhor':'pior')+' operação registada.</div>';
  const trade=candidates.reduce((a,b)=>selectedHistoryOperation==='best' ? (Number(b.profit||0)>Number(a.profit||0)?b:a) : (Number(b.profit||0)<Number(a.profit||0)?b:a), candidates[0]);
  const d=new Date(trade.time), profit=Number(trade.profit||0), cls=profit>=0?'good':'bad', sign=profit>=0?'+':'';
  const qty=Number(trade.qty||0), price=Number(trade.price||0), fee=Number(trade.fee||0);
  return `<div class="card history-operation-detail" style="margin-top:10px"><b>${selectedHistoryOperation==='best'?'📈 Melhor operação':'📉 Pior operação'}</b><div class="miniGrid" style="margin-top:9px"><div class="mini"><span class="muted">Moeda</span><b>${esc(String(trade.symbol||'').replace('USDT',''))}</b></div><div class="mini"><span class="muted">Lucro</span><b class="${cls}">${sign}${money(profit)}</b></div><div class="mini"><span class="muted">Preço de venda</span><b>${money(price)}</b></div><div class="mini"><span class="muted">Quantidade</span><b>${qty.toFixed(8)}</b></div><div class="mini"><span class="muted">Taxa</span><b>${money(fee)}</b></div><div class="mini"><span class="muted">Data e hora</span><b>${d.toLocaleDateString('pt-PT')} ${d.toLocaleTimeString('pt-PT')}</b></div></div><div class="sub" style="margin-top:9px"><b>Motivo da venda:</b> ${esc(trade.reason||'—')}</div>${trade.peak!=null?`<div class="tiny muted" style="margin-top:6px">Pico registado: ${money(trade.peak)}</div>`:''}</div>`;
}


function historySimulationData(){
  const s=historySimSymbol||symbols[0]||'BTCUSDT';
  const raw=Array.isArray(candles[s])?candles[s]:[];
  if(raw.length<3)return {s,rows:[],settings:null};
  const rows=raw.slice(-Math.min(Number(historySimBars)||72,raw.length));
  const settings=trailSettings(raw);
  const entry=Number(rows[0][4]);
  const activationPrice=entry*(1+settings.activate/100);
  let peak=entry,armed=false,down=0,armedAt=-1,triggerAt=-1;
  const out=rows.map((r,i)=>{
    const price=Number(r[4]);
    if(price>peak)peak=price;
    const gain=(price/entry-1)*100;
    if(gain>=settings.activate) {
      if(!armed){armed=true;armedAt=i;}
    }
    const trailPrice=peak*(1-settings.drop/100);
    if(armed && price<=trailPrice)down++;
    else if(price>trailPrice)down=0;
    if(armed && price<=peak*(1-S.trailDrop/100) && triggerAt<0)triggerAt=i;
    return {t:Number(r[0]),price,gain,peakGain:(peak/entry-1)*100,activationGain:settings.activate,trailGain:(trailPrice/entry-1)*100,armed,down,trailPrice};
  });
  const minNet=Math.max(0.25,Number(S.trailActivate||settings.activate)-0.25);
  const thresholdPct=minNet+(Number(S.fee||0)*2+Number(S.slip||0)*2);
  return {s,rows:out,settings,entry,activationPrice,thresholdPct,armedAt,triggerAt};
}
function marketProtectionSimulationData(){
  const g=marketProtectionStatus();
  const downThreshold=Math.max(1,Number(S.marketProtectionDownPct||70));
  const avgThreshold=Number(S.marketProtectionAvg5m??-1);
  const avg=Number.isFinite(Number(g.avg5m))?Number(g.avg5m):null;
  const breadthProgress=Math.max(0,Math.min(100,(Number(g.downPct||0)/downThreshold)*100));
  let avgProgress=0;
  if(avg!=null){
    if(avgThreshold<0)avgProgress=Math.max(0,Math.min(100,(Math.max(0,-avg)/Math.abs(avgThreshold))*100));
    else avgProgress=avg<=avgThreshold?100:Math.max(0,Math.min(100,(Math.max(0,-avg)+avgThreshold)/Math.max(0.01,avgThreshold)*100));
  }
  const confirms=Math.max(0,Number(S.marketProtectionCount||0));
  const confirmNeed=Math.max(1,Number(S.marketProtectionConfirm||2));
  const activations=Math.max(0,Number(S.marketProtectionActivations||0));
  const deactivations=Math.max(0,Number(S.marketProtectionDeactivations||0));
  const individualThreshold=Math.max(0.5,Number(S.marketProtectionIndividualDropPct??4));
  const individualProgress=Math.max(0,Math.min(100,Math.max(0,-Number(g.worstHeldDrop||0))/individualThreshold*100));
  const readiness=g.individualTrigger?100:Math.max(Math.min(breadthProgress,avgProgress||breadthProgress),individualProgress);
  return {g,downThreshold,avgThreshold,avg,breadthProgress,avgProgress,individualProgress,readiness,confirms,confirmNeed,activations,deactivations,individualThreshold};
}
function historyProtectionSimulationCard(){
  const d=marketProtectionSimulationData();
  const state=d.g.active?'ATIVA':d.g.trigger?(d.confirms>0?'A CONFIRMAR':'PRONTA PARA ATIVAR'):(d.readiness>=75?'QUASE A ATIVAR':'AFASTADA DA ATIVAÇÃO');
  const stateCls=d.g.active||d.g.trigger?'bad':d.readiness>=75?'warn':'good';
  return `<div class="card history-sim-card">
    <button type="button" id="historyProtectionToggle" class="historySimToggle" aria-expanded="${historyProtectionOpen?'true':'false'}" aria-controls="historyProtectionBody">
      <span><b>🛡️ Simulação da aproximação à proteção de mercado</b><span class="historySimToggleSub">${historyProtectionOpen?'Toque para recolher':'Toque para ver se o mercado está perto de ativar a proteção'}</span></span>
      <span class="historySimChevron">${historyProtectionOpen?'⌃':'⌄'}</span>
    </button>
    ${historyProtectionOpen?`<div class="historySimBody" id="historyProtectionBody">
      <div class="sub" style="margin:5px 0 8px">Mostra em tempo real o quão perto o mercado está das condições que ativam a proteção.</div>
      <div class="historyProtectionGrid">
        <div class="mini"><span class="muted">Estado</span><b class="${stateCls}">${state}</b></div>
        <div class="mini"><span class="muted">Moedas em queda</span><b>${Number(d.g.downPct||0).toFixed(1)}% / ${d.downThreshold.toFixed(0)}%</b></div>
        <div class="mini"><span class="muted">Confirmações</span><b>${d.confirms}/${d.confirmNeed}</b></div>
        <div class="mini"><span class="muted">Maior queda numa posição</span><b>${Number(d.g.worstHeldDrop||0).toFixed(2)}% / -${d.individualThreshold.toFixed(2)}%</b></div>
        <div class="mini"><span class="muted">Ativações</span><b>${d.activations}</b></div>
        <div class="mini"><span class="muted">Desativações</span><b>${d.deactivations}</b></div>
      </div>
      <div class="historyProtectionCanvasWrap"><canvas id="historyProtectionCanvas" class="historyProtectionCanvas"></canvas></div>
      <div class="historyProtectionLegend"><span><i class="historyProtectionDot"></i>Moedas em queda</span><span><i class="historyProtectionDot"></i>Queda média</span><span><i class="historyProtectionDot"></i>Queda da posição</span><span><i class="historyProtectionDot"></i>Limiar</span></div>
      <div id="historyProtectionStatus" class="historyProtectionStatus sub"></div>
    </div>`:''}
  </div>`;
}
function drawHistoryProtectionSimulation(){
  const canvas=document.getElementById('historyProtectionCanvas');
  const status=document.getElementById('historyProtectionStatus');
  if(!canvas)return;
  const d=marketProtectionSimulationData();
  const rect=canvas.getBoundingClientRect(),ratio=Math.max(1,window.devicePixelRatio||1);
  const W=Math.max(320,Math.floor(rect.width)),H=Math.max(210,Math.floor(rect.height));
  canvas.width=Math.floor(W*ratio);canvas.height=Math.floor(H*ratio);
  const ctx=canvas.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,W,H);
  const pad={l:44,r:12,t:18,b:28},iw=W-pad.l-pad.r,ih=H-pad.t-pad.b;
  const vals=[Number(d.g.downPct||0),d.downThreshold,Math.abs(Number(d.avgThreshold||0)),d.avg==null?0:Math.abs(d.avg)];
  const hi=Math.max(100,...vals)*1.08,lo=0;
  const x=i=>pad.l+(iw*i);
  const y=v=>pad.t+(hi-v)/(hi-lo)*ih;
  ctx.font='10px system-ui,-apple-system,Segoe UI,sans-serif';ctx.lineWidth=1;ctx.strokeStyle='#203044';ctx.fillStyle='#93a4b8';
  for(let j=0;j<=4;j++){const v=hi*j/4,yy=y(v);ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(W-pad.r,yy);ctx.stroke();ctx.fillText(v.toFixed(0)+'%',5,yy+3)}
  const bar=(xx,val,label,threshold,fill)=>{const yy=y(val),base=H-pad.b;ctx.fillStyle=fill;ctx.globalAlpha=.9;ctx.fillRect(xx-24,yy,48,base-yy);ctx.globalAlpha=1;ctx.fillStyle='#93a4b8';ctx.textAlign='center';ctx.fillText(label,xx,base+15);ctx.fillText(val.toFixed(1)+'%',xx,Math.max(pad.t+11,yy-5));ctx.setLineDash([5,4]);ctx.strokeStyle='#ff6875';ctx.beginPath();ctx.moveTo(xx-34,y(threshold));ctx.lineTo(xx+34,y(threshold));ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#ff6875';ctx.font='9px system-ui,-apple-system,Segoe UI,sans-serif';ctx.fillText('limiar '+threshold.toFixed(1)+'%',xx,Math.max(pad.t+10,y(threshold)-4));ctx.textAlign='left';ctx.font='10px system-ui,-apple-system,Segoe UI,sans-serif';};
  bar(pad.l+iw*.28,Number(d.g.downPct||0),'Queda do mercado',d.downThreshold,'#6ea8fe');
  const avgVal=d.avg==null?0:Math.abs(d.avg), avgLim=Math.abs(d.avgThreshold);
  bar(pad.l+iw*.72,avgVal,'Queda média',avgLim,'#ffb454');
  if(status){
    const avgText=d.avg==null?'ainda sem janela completa':(d.avg.toFixed(2)+'%');
    const cond1=Number(d.g.downPct||0)>=d.downThreshold, cond2=d.avg!=null&&(d.avgThreshold<0?d.avg<=d.avgThreshold:d.avg>=d.avgThreshold);
    const progress=d.readiness.toFixed(0);
    status.innerHTML=`<b>Proximidade: ${progress}%</b> · Mercado: <b>${cond1?'atingido':'não atingido'}</b> · Queda média: <b>${cond2?'atingido':'não atingido'}</b> · Posição: <b>${d.g.individualTrigger?'limiar atingido':'abaixo do limiar'}</b> · Média atual: <b>${avgText}</b>${d.g.active?' · <span class="bad">proteção ativa</span>':d.g.trigger?' · <span class="bad">ativação antecipada disponível</span>':''}`;
  }
}

function historySimulationCard(){
  const d=historySimulationData();
  const opts=symbols.map(s=>`<option value="${s}" ${s===historySimSymbol?'selected':''}>${s}</option>`).join('');
  const st=d.settings;
  const body=historySimOpen?`<div class="historySimBody">
    <div class="sub" style="margin:5px 0 8px">Simulação visual sobre o histórico disponível, usando as mesmas regras de trailing aplicadas quando uma posição é criada.</div>
    <div class="historySimControls">
      <label>Ativo<select id="historySimSymbol" data-history-sim-symbol>${opts}</select></label>
      <label>Velas<select id="historySimBars" data-history-sim-bars>
        ${[48,72,120,200].map(n=>`<option value="${n}" ${Number(historySimBars)===n?'selected':''}>Últimas ${n}h</option>`).join('')}
      </select></label>
      <label>Ativação (%)<input id="historyTrailActivate" inputmode="decimal" type="number" min="0.05" max="100" step="0.05" value="${Number(S.trailActivate||st?.activate||3).toFixed(2)}" aria-label="Percentagem de ativação"></label>
      <label>Recuo (%)<input id="historyTrailDrop" inputmode="decimal" type="number" min="0.05" max="50" step="0.05" value="${Number(S.trailDrop||st?.drop||2).toFixed(2)}" aria-label="Percentagem de recuo"></label>
      <button type="button" id="applyHistoryTrailSettings" class="primary">Aplicar à app</button>
    </div>
    <div class="sub" style="margin:7px 0 8px">As percentagens acima controlam o trailing real. Depois de aplicar, novas posições e a lógica de venda usam estes valores.</div>
    ${st?`<div class="historySimMeta">
      <span class="pill">Ativação: <b>+${st.activate.toFixed(2)}%</b></span>
      <span class="pill">Recuo trailing: <b>${st.drop.toFixed(2)}%</b></span>
      <span class="pill">Modo: <b>personalizado</b></span>
      <span class="pill">Threshold líquido: <b>${d.thresholdPct.toFixed(2)}%</b></span>
    </div>`:''}
    <div class="historySimCanvasWrap"><canvas id="historySimCanvas" class="historySimCanvas"></canvas></div>
    <div class="historySimLegend">
      <span><i class="historySimDot"></i>Preço</span>
      <span><i class="historySimDot"></i>Ativação</span>
      <span><i class="historySimDot"></i>Trailing</span>
    </div>
    <div id="historySimStatus" class="sub" style="margin-top:8px"></div>
  </div>`:'';
  return `<div class="card history-sim-card">
    <button type="button" id="historySimToggle" class="historySimToggle" aria-expanded="${historySimOpen?'true':'false'}" aria-controls="historySimBody">
      <span><b>📊 Simulação da aproximação à ativação</b><span class="historySimToggleSub">${historySimOpen?'Toque para recolher':'Toque para abrir e ajustar os valores'}</span></span>
      <span class="historySimChevron">${historySimOpen?'⌃':'⌄'}</span>
    </button>
    ${historySimOpen?body.replace('class="historySimBody"','class="historySimBody" id="historySimBody"'):''}
  </div>`;
}
function drawHistorySimulation(){
  const canvas=document.getElementById('historySimCanvas');
  const status=document.getElementById('historySimStatus');
  if(!canvas)return;
  const d=historySimulationData();
  if(!d.rows.length){
    if(status)status.textContent='Sem histórico suficiente para simular este ativo.';
    return;
  }
  const rect=canvas.getBoundingClientRect(), ratio=Math.max(1,window.devicePixelRatio||1);
  const W=Math.max(320,Math.floor(rect.width)), H=Math.max(240,Math.floor(rect.height));
  canvas.width=Math.floor(W*ratio);canvas.height=Math.floor(H*ratio);
  const ctx=canvas.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);
  ctx.clearRect(0,0,W,H);
  const pad={l:44,r:12,t:16,b:28}, iw=W-pad.l-pad.r, ih=H-pad.t-pad.b;
  const vals=d.rows.flatMap(x=>[x.gain,x.activationGain,x.trailGain]);
  let lo=Math.min(...vals), hi=Math.max(...vals);
  const span=Math.max(1,hi-lo);lo-=span*.08;hi+=span*.08;
  const x=i=>pad.l+(d.rows.length<=1?0:i/(d.rows.length-1)*iw);
  const y=v=>pad.t+(hi-v)/(hi-lo)*ih;
  ctx.font='10px system-ui,-apple-system,Segoe UI,sans-serif';
  ctx.lineWidth=1;
  ctx.strokeStyle='#203044';ctx.fillStyle='#93a4b8';
  for(let j=0;j<=4;j++){
    const v=lo+(hi-lo)*j/4, yy=y(v);
    ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(W-pad.r,yy);ctx.stroke();
    ctx.fillText((v>=0?'+':'')+v.toFixed(1)+'%',4,yy+3);
  }
  const drawSeries=(arr,stroke,dash)=>{
    ctx.strokeStyle=stroke;ctx.setLineDash(dash||[]);ctx.lineWidth=2;ctx.beginPath();
    arr.forEach((v,i)=>{const xx=x(i),yy=y(v);i?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy);});ctx.stroke();ctx.setLineDash([]);
  };
  drawSeries(d.rows.map(r=>r.gain),'#6ea8fe');
  drawSeries(d.rows.map(r=>r.activationGain),'#43d17b',[6,5]);
  drawSeries(d.rows.map(r=>r.trailGain),'#ff6875',[4,4]);
  if(d.armedAt>=0){
    const xx=x(d.armedAt);ctx.strokeStyle='#43d17b';ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(xx,pad.t);ctx.lineTo(xx,H-pad.b);ctx.stroke();ctx.setLineDash([]);
    ctx.fillStyle='#43d17b';ctx.fillText('ativou',Math.min(xx+4,W-52),pad.t+11);
  }
  if(d.triggerAt>=0){
    const xx=x(d.triggerAt);ctx.strokeStyle='#ff6875';ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(xx,pad.t);ctx.lineTo(xx,H-pad.b);ctx.stroke();ctx.setLineDash([]);
    ctx.fillStyle='#ff6875';ctx.fillText('disparo',Math.min(xx+4,W-52),H-pad.b-6);
  }
  ctx.fillStyle='#93a4b8';
  ctx.fillText('Entrada 0%',pad.l,H-8);
  ctx.fillText('Última',Math.max(pad.l,W-pad.r-34),H-8);
  if(status){
    const last=d.rows.at(-1);
    const state=last.armed?'ARMADO':'a aguardar ativação';
    const dist=last.armed?last.gain-last.trailGain:last.activationGain-last.gain;
    status.innerHTML=`<b>${d.s}</b> · Estado: <b>${state}</b> · Preço simulado: <b>${last.gain>=0?'+':''}${last.gain.toFixed(2)}%</b> · ${last.armed?'margem até ao trailing':'falta para ativação'}: <b>${Math.abs(dist).toFixed(2)}%</b>${d.triggerAt>=0?' · <span class="bad">houve disparo no período</span>':''}`;
  }
}

function history(){
 const st=tradeStats();
 const allEvents=Array.isArray(S.events)?S.events:[];
 const events=allEvents.slice(0,80);
 const sells=st.sells.slice().reverse();
 const protectionOn=allEvents.filter(e=>String(e.reason||'').includes('Proteção de mercado ativada')).sort((a,b)=>a.time-b.time);
 const protectionOff=allEvents.filter(e=>String(e.reason||'').includes('Proteção de mercado desativada')).sort((a,b)=>a.time-b.time);
 const protectionTimes=protectionOn.map(e=>{const d=new Date(e.time);return `<tr><td>${d.toLocaleDateString('pt-PT')}</td><td><b>${d.toLocaleTimeString('pt-PT')}</b></td><td>${esc(e.reason||'')}</td></tr>`}).join('');
 const protectionLast=protectionOn.length?new Date(protectionOn[protectionOn.length-1].time).toLocaleString('pt-PT'):'—';
 return `${historySimulationCard()}${historyProtectionSimulationCard()}<div class="card"><b>📈 Estatísticas das operações</b><div class="miniGrid" style="margin-top:9px">
 <div class="mini"><span class="muted">Operações fechadas</span><b>${sells.length}</b></div>
 <div class="mini"><span class="muted">Taxa de acerto</span><b>${st.winRate.toFixed(1)}%</b></div>
 <div class="mini"><span class="muted">Profit factor</span><b>${Number.isFinite(st.profitFactor)?st.profitFactor.toFixed(2):'∞'}</b></div>
 <div class="mini"><span class="muted">Lucro médio</span><b class="${st.avg>=0?'good':'bad'}">${money(st.avg)}</b></div>
 <div class="mini historyOpCard" data-history-op="best" style="cursor:pointer"><span class="muted">Melhor operação</span><b class="good">${money(st.best)}</b></div>
 <div class="mini historyOpCard" data-history-op="worst" style="cursor:pointer"><span class="muted">Pior operação</span><b class="bad">${money(st.worst)}</b></div></div>${historyOperationDetail(st)}</div>
 <div class="card"><b>🛡️ Proteção do mercado</b><div class="miniGrid" style="margin-top:9px">
 <div class="mini"><span class="muted">Ativações</span><b>${Math.max(Number(S.marketProtectionActivations||0),protectionOn.length)}</b></div>
 <div class="mini"><span class="muted">Desativações</span><b>${Math.max(Number(S.marketProtectionDeactivations||0),protectionOff.length)}</b></div>
 <div class="mini"><span class="muted">Última ativação</span><b>${protectionLast}</b></div>
 <div class="mini"><span class="muted">Estado atual</span><b class="${S.marketProtectionActive?'bad':'good'}">${S.marketProtectionActive?'ATIVA':'inativa'}</b></div></div>
 ${protectionOn.length?`<div class="sub" style="margin:10px 0 7px">Cada ativação registada e a respetiva hora:</div><div class="scroll"><table><tr><th>Data</th><th>Hora</th><th>Motivo</th></tr>${protectionTimes}</table></div>`:'<div class="sub" style="margin-top:9px">Ainda não há ativações da proteção de mercado registadas.</div>'}</div>
 <div class="card"><b>🧾 Histórico de vendas</b><div class="sub" style="margin:5px 0 9px">Entradas, saídas e motivos ficam registados para perceber o comportamento da estratégia.</div>${sells.length?`<div class="scroll"><table><tr><th>Hora</th><th>Moeda</th><th>Preço</th><th>Lucro</th><th>Motivo</th></tr>${sells.map(t=>{const d=new Date(t.time);return `<tr><td>${d.toLocaleDateString('pt-PT')}<br><b>${d.toLocaleTimeString('pt-PT')}</b></td><td><b>${esc(String(t.symbol||'').replace('USDT',''))}</b></td><td>${money(t.price)}</td><td class="${(t.profit||0)>=0?'good':'bad'}">${t.profit==null?'—':money(t.profit)}</td><td>${esc(t.reason||'')}</td></tr>`}).join('')}</table></div>`:'<div class="sub">Ainda não existem vendas registadas.</div>'}</div>
 <div class="card"><b>🧠 Registo de decisões</b><div class="sub" style="margin:5px 0 9px">Últimas decisões da app, incluindo bloqueios de entrada.</div>${events.length?`<div class="scroll"><table><tr><th>Hora</th><th>Evento</th><th>Detalhe</th></tr>${events.map(e=>{const d=new Date(e.time);return `<tr><td>${d.toLocaleDateString('pt-PT')}<br><b>${d.toLocaleTimeString('pt-PT')}</b></td><td>${eventLabel(e)}</td><td>${esc(e.reason||'')}</td></tr>`}).join('')}</table></div>`:'<div class="sub">Ainda não há eventos.</div>'}</div>`;
}
function backtest(){
 return `<div class="card"><b>🧪 Backtest detalhado</b><p class="sub">Simula o histórico disponível com capital, máximo por compra, alocação, reserva, taxas, slippage, score e trailing configurados atualmente. O modo live usa as regras atuais de tendência 1h, filtro BTC e regime de mercado; o backtest apresenta estes componentes separadamente quando não é possível reproduzi-los exatamente no histórico local.</p>
 <label>Ativo</label><select id="bt">${symbols.map(s=>`<option>${s}</option>`).join('')}</select>
 <div class="actions" style="margin-top:8px"><button class="primary" onclick="runBT()">Executar</button><button onclick="runStress()">⚠️ Teste de stress</button></div><div id="btout"></div></div>`
}
function stressScenario(c,dropPct){
  const out=c.map(x=>x.slice());
  const start=Math.max(80,Math.floor(out.length*0.55));
  const shockBars=3, floorBars=10, recoveryBars=8;
  const base=+out[start-1][4];
  const target=base*(1-dropPct/100);
  for(let j=0;j<shockBars && start+j<out.length;j++){
    const k=(j+1)/shockBars, close=base+(target-base)*k;
    const row=out[start+j].slice(); row[1]=Math.min(+row[1],close*1.003); row[2]=Math.max(+row[2],close*1.004); row[3]=Math.min(+row[3],close*0.996); row[4]=close; out[start+j]=row;
  }
  const floorEnd=Math.min(out.length,start+shockBars+floorBars);
  for(let i=start+shockBars;i<floorEnd;i++){const row=out[i].slice();row[1]=target;row[2]=target*1.002;row[3]=target*0.998;row[4]=target;out[i]=row;}
  const recStart=floorEnd, recEnd=Math.min(out.length,recStart+recoveryBars);
  for(let i=recStart;i<recEnd;i++){const k=(i-recStart+1)/Math.max(1,recoveryBars),close=target+(base-target)*k;const row=out[i].slice();row[1]=close;row[2]=close*1.002;row[3]=close*0.998;row[4]=close;out[i]=row;}
  return {data:out,start,shockEnd:Math.min(out.length,start+shockBars+floorBars),recoveryEnd:recEnd,base,target};
}
function stressRunOne(c,dropPct){
  const sc=stressScenario(c,dropPct), data=sc.data;
  let cash=S.capital,pos=null,tr=[],wins=0,losses=0,fees=0,blocked=0,peakEq=S.capital,maxDD=0,protection=false,protectionBars=0,protectionStart=null,protectionEnd=null,recoveryCount=0,protectionCount=0,until=0;
  for(let i=80;i<data.length;i++){
    const slice=data.slice(0,i+1), q=score(slice), price=+data[i][4], t=+data[i][0];
    const inStress=i>=sc.start && i<sc.recoveryEnd;
    // Stress proxy: during the synthetic crash, breadth is treated as broadly bearish.
    const shockActive=i>=sc.start && i<sc.recoveryEnd;
    const recoveryPhase=i>=sc.shockEnd && i<sc.recoveryEnd;
    const trigger=shockActive && !recoveryPhase;
    const recovery=recoveryPhase;
    if(!protection){
      if(trigger)protectionCount++;else protectionCount=0;
      if(protectionCount>=Math.max(1,Number(S.marketProtectionConfirm||2))){
        protection=true;protectionBars=0;protectionStart=t;until=t+Math.max(0,Number(S.marketProtectionCooldownMin||10))*60000;protectionCount=0;recoveryCount=0;
        if(pos){const gross=pos.qty*price,fee=gross*S.fee/100,slip=gross*S.slip/100,net=gross-fee-slip,profit=net-pos.qty*pos.entry;cash+=net;fees+=fee+slip;tr.push(profit);profit>0?wins++:losses++;pos=null;}
      }
    }else{
      protectionBars++;
      if(trigger){recoveryCount=0;until=Math.max(until,t+Math.max(0,Number(S.marketProtectionCooldownMin||10))*60000);}
      else if(t>=until && recovery)recoveryCount++;else if(!recovery)recoveryCount=0;
      if(t>=until && recoveryCount>=Math.max(1,Number(S.marketRecoveryConfirm||3))){protection=false;protectionEnd=t;protectionBars=0;recoveryCount=0;}
    }
    if(!pos && !protection && q.score>=S.minScore){
      const budget=Math.min(Number(S.maxBuyUsd)||150,S.capital*S.alloc/100,cash-S.capital*S.reserve/100,S.capital*S.maxPerAsset/100);
      if(budget>0){const fee=budget*S.fee/100,slip=price*S.slip/100,entry=price+slip;cash-=budget;fees+=fee;pos={qty:(budget-fee)/entry,entry,peak:entry,armed:false,down:0};}
      else blocked++;
    }else if(!pos && protection){blocked++;}
    if(pos){
      if(price>pos.peak){pos.peak=price;pos.down=0}
      if((price/pos.entry-1)*100>=S.trailActivate)pos.armed=true;
      if(pos.armed&&price<=pos.peak*(1-S.trailDrop/100))pos.down++;else if(price>pos.peak*(1-S.trailDrop/100))pos.down=0;
      if(pos.armed&&price<=pos.peak*(1-S.trailDrop/100)){
        const gross=pos.qty*price,fee=gross*S.fee/100,slip=gross*S.slip/100,net=gross-fee-slip,profit=net-pos.qty*pos.entry;cash+=net;fees+=fee+slip;tr.push(profit);profit>0?wins++:losses++;pos=null;
      }
    }
    const eq=cash+(pos?pos.qty*price:0);peakEq=Math.max(peakEq,eq);maxDD=Math.max(maxDD,(peakEq-eq)/peakEq*100);
  }
  if(pos){const price=+data.at(-1)[4],gross=pos.qty*price,fee=gross*S.fee/100,slip=gross*S.slip/100,profit=(gross-fee-slip)-pos.qty*pos.entry;cash+=gross-fee-slip;fees+=fee+slip;tr.push(profit);profit>0?wins++:losses++;}
  const ret=(cash/S.capital-1)*100;
  return {drop:dropPct,ret,maxDD,ops:tr.length,wins,losses,fees,blocked,protectionTriggered:!!protectionStart,protectionStart,protectionEnd,protectedDuration:protectionStart?Math.max(0,((protectionEnd||+data.at(-1)[0])-protectionStart)/60000):0,final:cash};
}
async function runStress(){
 const s=document.getElementById('bt').value,out=document.getElementById('btout');out.innerHTML='<p class="muted">A executar teste de stress 5% / 10% / 20% / 30%...</p>';
 try{
  const c=candles[s]||await jget(`klines?symbol=${s}&interval=1h&limit=${Math.min(S.lookback,500)}`);
  if(!c||c.length<120)throw new Error('Dados históricos insuficientes para o teste de stress.');
  const rows=[5,10,20,30].map(d=>stressRunOne(c,d));
  out.innerHTML=`<div class="alert"><b>⚠️ Teste de stress do motor</b><div class="sub" style="margin-top:5px">${esc(s)} · choque sintético de mercado de 5%, 10%, 20% e 30%. O choque começa a meio/final do histórico e é seguido por uma fase de recuperação. A proteção usa as confirmações e o mínimo de ${Number(S.marketProtectionCooldownMin||10)} min configurados.</div>
  <div style="overflow:auto;margin-top:10px"><table><thead><tr><th>Queda</th><th>Retorno</th><th>Drawdown</th><th>Operações</th><th>Proteção</th><th>Tempo protegido</th><th>Entradas bloqueadas</th></tr></thead><tbody>${rows.map(r=>`<tr><td><b>-${r.drop}%</b></td><td class="${r.ret>=0?'good':'bad'}">${r.ret.toFixed(2)}%</td><td>${r.maxDD.toFixed(2)}%</td><td>${r.ops}</td><td>${r.protectionTriggered?'ATIVADA':'não ativada'}</td><td>${r.protectionTriggered?r.protectedDuration.toFixed(0)+' min':'—'}</td><td>${r.blocked}</td></tr>`).join('')}</tbody></table></div>
  <div class="card" style="margin-top:10px"><b>🛡️ Como ler o teste</b><div class="tiny muted" style="margin-top:6px">O cenário é sintético: não representa uma queda histórica específica. Serve para verificar o comportamento mecânico do motor perante choques de magnitude diferente. Durante a queda, o mercado é tratado como generalizadamente bearish para testar a proteção; na recuperação, são exigidas as confirmações configuradas antes de voltar a permitir entradas.</div></div></div>`;
 }catch(e){out.innerHTML='<div class="alert bad">'+esc(e.message)+'</div>'}
}

async function runBT(){
 let s=document.getElementById('bt').value,out=document.getElementById('btout');out.innerHTML='<p class="muted">A processar...</p>';
 try{
  let c=candles[s]||await jget(`klines?symbol=${s}&interval=1h&limit=${Math.min(S.lookback,500)}`);
  let btc=(s==='BTCUSDT'?c:(candles.BTCUSDT||await jget(`klines?symbol=BTCUSDT&interval=1h&limit=${Math.min(S.lookback,500)}`)));
  let cash=S.capital,pos=null,tr=[],equityCurve=[],peakEq=S.capital,maxDD=0,fees=0,blocked=0,wins=[],losses=[],holdStart=0,holdHours=[];
  for(let i=80;i<c.length;i++){
   let slice=c.slice(0,i+1), q=score(slice), price=+c[i][4];
   if(!pos){
    if(q.score>=S.minScore){
      let budget=Math.min(Number(S.maxBuyUsd)||150,S.capital*S.alloc/100,cash-S.capital*S.reserve/100,S.capital*S.maxPerAsset/100);
      if(budget>0){const fee=budget*S.fee/100,slip=price*S.slip/100,entry=price+slip;cash-=budget;fees+=fee;pos={qty:(budget-fee)/entry,entry,peak:entry,armed:false,down:0};holdStart=+c[i][0];}
      else blocked++;
    }else blocked++;
   }else{
    if(price>pos.peak){pos.peak=price;pos.down=0}
    if((price/pos.entry-1)*100>=S.trailActivate)pos.armed=true;
    if(pos.armed&&price<=pos.peak*(1-S.trailDrop/100))pos.down++;else if(price>pos.peak*(1-S.trailDrop/100))pos.down=0;
    if(pos.armed&&price<=pos.peak*(1-S.trailDrop/100)){
      let gross=pos.qty*price,fee=gross*S.fee/100,slip=gross*S.slip/100,net=gross-fee-slip,profit=net-pos.qty*pos.entry;cash+=net;fees+=fee+slip;tr.push(profit);profit>0?wins.push(profit):losses.push(profit);if(holdStart)holdHours.push((+c[i][0]-holdStart)/3600000);pos=null;holdStart=0;
    }
   }
   const eq=cash+(pos?pos.qty*price:0);equityCurve.push(eq);peakEq=Math.max(peakEq,eq);maxDD=Math.max(maxDD,(peakEq-eq)/peakEq*100);
  }
  if(pos){const price=+c.at(-1)[4],gross=pos.qty*price,fee=gross*S.fee/100,slip=gross*S.slip/100,profit=(gross-fee-slip)-pos.qty*pos.entry;cash+=gross-fee-slip;fees+=fee+slip;tr.push(profit);profit>0?wins.push(profit):losses.push(profit);if(holdStart)holdHours.push((+c.at(-1)[0]-holdStart)/3600000);pos=null;}
  let end=cash,realized=tr.reduce((a,v)=>a+v,0),grossWin=wins.reduce((a,v)=>a+v,0),grossLoss=Math.abs(losses.reduce((a,v)=>a+v,0)),pf=grossLoss?grossWin/grossLoss:(grossWin?Infinity:0);
  const avgWin=wins.length?grossWin/wins.length:0,avgLoss=losses.length?grossLoss/losses.length:0,avgTrade=tr.length?realized/tr.length:0;
  const firstPrice=+c[80][4],lastPrice=+c.at(-1)[4],buyHold=(lastPrice/firstPrice-1)*100;
  const btcStart=Math.min(80,Math.max(0,btc.length-2));
  const btcFirst=+btc[btcStart][4],btcLast=+btc.at(-1)[4],btcHold=(btcLast/btcFirst-1)*100;
  const strategyReturn=(end/S.capital-1)*100;
  const vsAsset=strategyReturn-buyHold,vsBtc=strategyReturn-btcHold;
  const periodHours=Math.max(1,(+c.at(-1)[0]-+c[80][0])/3600000);
  const annualized=Math.pow(Math.max(0.0001,end/S.capital),8760/periodHours)-1;
  const avgHold=holdHours.length?holdHours.reduce((a,v)=>a+v,0)/holdHours.length:0;
  const ddClass=maxDD<=10?'good':maxDD<=20?'':'bad';
  const retClass=strategyReturn>=0?'good':'bad';
  const cmpClass=vsBtc>=0?'good':'bad';
  out.innerHTML=`<div class="alert"><b>📊 Relatório do motor</b><div class="sub" style="margin-top:5px">${esc(s)} · ${c.length-80} períodos de 1h · regras e custos atuais da aplicação</div>
   <div class="miniGrid" style="margin-top:8px">
    <div class="mini"><span class="muted">Capital final</span><b>${money(end)}</b></div>
    <div class="mini"><span class="muted">Retorno do motor</span><b class="${retClass}">${strategyReturn.toFixed(2)}%</b></div>
    <div class="mini"><span class="muted">Drawdown máx.</span><b class="${ddClass}">${maxDD.toFixed(2)}%</b></div>
    <div class="mini"><span class="muted">Operações</span><b>${tr.length}</b></div>
    <div class="mini"><span class="muted">Win rate</span><b>${tr.length?(wins.length/tr.length*100).toFixed(1):'0'}%</b></div>
    <div class="mini"><span class="muted">Profit factor</span><b>${Number.isFinite(pf)?pf.toFixed(2):'∞'}</b></div>
    <div class="mini"><span class="muted">Lucro médio/op.</span><b>${money(avgTrade)}</b></div>
    <div class="mini"><span class="muted">Tempo médio</span><b>${avgHold?avgHold.toFixed(1)+'h':'—'}</b></div>
   </div>
   <div class="card" style="margin-top:10px"><b>📌 Comparações</b>
    <div class="miniGrid" style="margin-top:8px">
     <div class="mini"><span class="muted">Motor</span><b class="${retClass}">${strategyReturn.toFixed(2)}%</b></div>
     <div class="mini"><span class="muted">Buy & Hold ${esc(s.replace('USDT',''))}</span><b>${buyHold.toFixed(2)}%</b></div>
     <div class="mini"><span class="muted">Buy & Hold BTC</span><b>${btcHold.toFixed(2)}%</b></div>
     <div class="mini"><span class="muted">Diferença vs BTC</span><b class="${cmpClass}">${vsBtc>=0?'+':''}${vsBtc.toFixed(2)} pp</b></div>
    </div>
   </div>
   <div class="card" style="margin-top:10px"><b>💰 Qualidade das operações</b>
    <div class="miniGrid" style="margin-top:8px">
     <div class="mini"><span class="muted">Lucro bruto</span><b class="good">${money(grossWin)}</b></div>
     <div class="mini"><span class="muted">Perdas brutas</span><b class="bad">${money(-grossLoss)}</b></div>
     <div class="mini"><span class="muted">Ganho médio</span><b>${money(avgWin)}</b></div>
     <div class="mini"><span class="muted">Perda média</span><b>${money(-avgLoss)}</b></div>
    </div>
   </div>
   <div class="tiny muted" style="margin-top:8px">Lucro líquido: ${money(realized)} · Custos simulados: ${money(fees)} · Períodos sem entrada: ${blocked} · Retorno anualizado: ${(annualized*100).toFixed(2)}%* </div>
   <div class="tiny muted" style="margin-top:4px">* Anualização apenas matemática; não representa uma previsão. O Buy & Hold usa o mesmo intervalo temporal do backtest. O lucro das vendas inclui a taxa de compra alocada à quantidade vendida.</div>
  </div>`;
 }catch(e){out.innerHTML='<div class="alert bad">'+esc(e.message)+'</div>'}
}
function config(){
 const buyFields=[
  ['capital','Capital total ($)'],['maxBuyUsd','Máximo por compra ($)'],['alloc','Alocação por compra (%)'],
  ['maxPositions','Máx. posições abertas'],['maxPerAsset','Máx. por ativo (%)'],['maxExposure','Exposição máxima (%)'],
  ['reserve','Reserva mínima (%)'],['dip','Queda 24h mínima para pontuar (%)'],['minScore','Score mínimo'],['fee','Taxa (%)'],['slip','Slippage (%)']
 ];
 const marketFields=[
  ['marketProtectionDownPct','% de moedas em queda para ativar'],['marketProtectionAvg5m','Queda média no período para ativar (%)'],
  ['marketProtectionConfirm','Confirmações para ativar'],['marketProtectionIndividualDropPct','Queda de uma posição para proteção antecipada (%)'],
  ['marketProtectionCooldownMin','Tempo mínimo de proteção (min)'],['marketRecoveryDownPct','% de moedas em queda para recuperar'],
  ['marketRecoveryAvg5m','Subida média no período para recuperar (%)'],['marketRecoveryConfirm','Confirmações para voltar a comprar']
 ];
 return `<div class="card"><b>💰 Limites de compra e capital</b><div class="sub" style="margin:5px 0 9px">Estes limites são aplicados pelo motor em todas as compras. O <b>Máximo por compra</b> é um teto absoluto: nenhuma ordem pode ultrapassá-lo, mesmo que a alocação resulte num valor maior.</div>${buyFields.map(([k,l])=>`<label>${l}<input data-k="${k}" type="number" min="0" step="0.1" value="${Number(S[k]??0)}"></label>`).join('')}</div>
 <div class="card"><b>🛡️ Proteção de mercado</b><div class="sub" style="margin:5px 0 9px">Quando uma grande parte do mercado estiver a cair, a proteção pode fechar posições e bloquear novas compras. A regra do BTC é independente: para comprar, o BTC tem de estar a subir.</div><label><input data-k="marketProtectionEnabled" type="checkbox" ${S.marketProtectionEnabled?'checked':''}> Ativar proteção de mercado</label><label>Período de análise<select data-k="marketProtectionWindowSec"><option value="30" ${Number(S.marketProtectionWindowSec??60)===30?'selected':''}>30 segundos — reação rápida</option><option value="60" ${Number(S.marketProtectionWindowSec??60)===60?'selected':''}>1 minuto — recomendado</option><option value="120" ${Number(S.marketProtectionWindowSec??60)===120?'selected':''}>2 minutos</option><option value="300" ${Number(S.marketProtectionWindowSec??60)===300?'selected':''}>5 minutos</option></select></label>${marketFields.map(([k,l])=>`<label>${l}<input data-k="${k}" type="number" step="0.1" value="${Number(S[k]??0)}"></label>`).join('')}</div>
 <div class="card"><b>📉 Regras de queda e dados</b><div class="sub" style="margin:5px 0 9px">A definição de “queda do BTC para bloquear” foi removida porque a regra atual é simples: <b>BTC a subir = pode comprar; BTC a cair ou sem subida = não compra</b>. Não há um segundo limiar de BTC a competir com essa regra.</div><label>Histórico de preços (min)<input data-k="priceHistoryMinutes" type="number" min="1" max="30" step="1" value="${Number(S.priceHistoryMinutes??5)}"></label><label>Intervalo de atualização (segundos)<input data-k="intervalMs" type="number" min="5" max="60" step="1" value="${Math.round(Number(S.intervalMs??10000)/1000)}"></label><label>Janela da queda da moeda (segundos)<input data-k="individualDropWindowSec" type="number" min="15" max="180" step="5" value="${Number(S.individualDropWindowSec??30)}"></label><label>Janela da análise do BTC (segundos)<input data-k="btcDropWindowSec" type="number" min="30" max="600" step="15" value="${Number(S.btcDropWindowSec??180)}"></label><label>Velas históricas<input data-k="lookback" type="number" min="60" max="500" step="10" value="${Number(S.lookback??500)}"></label></div>
 <div class="card"><b>🎯 Venda normal — trailing único</b><div class="sub" style="margin:5px 0 9px">A posição é acompanhada pelo máximo atingido. Quando atingir a ativação, uma queda igual ao recuo definido desde o máximo vende 100% da posição.</div><label>Ativar trailing com lucro (%)<input data-k="trailActivate" type="number" min="0.05" max="100" step="0.05" value="${Number(S.trailActivate??3)}"></label><label>Recuo desde o máximo para vender tudo (%)<input data-k="trailDrop" type="number" min="0.05" max="50" step="0.05" value="${Number(S.trailDrop??2)}"></label></div>
 <div class="actions" style="margin-top:10px"><button class="primary" onclick="saveCfg()">Guardar configuração</button><button onclick="exportData()">Exportar memória</button><button onclick="resetAll()">Reset</button></div>`;
}
function saveCfg(){document.querySelectorAll('[data-k]').forEach(i=>{let k=i.dataset.k,v=i.type==='checkbox'?i.checked:+i.value;if(k==='maxBuyUsd')v=Math.max(1,Math.min(100000,v));if(k==='intervalMs')v=Math.max(5000,Math.min(60000,v*1000));if(k==='priceHistoryMinutes')v=Math.max(1,Math.min(30,v));if(k==='individualDropWindowSec')v=Math.max(15,Math.min(180,v));if(k==='btcDropWindowSec')v=Math.max(30,Math.min(600,v));if(k==='lookback')v=Math.max(60,Math.min(500,v));S[k]=v;});if(Number(S.priceHistoryMinutes)*60<Number(S.individualDropWindowSec))S.priceHistoryMinutes=Math.ceil(Number(S.individualDropWindowSec)/60)+1;if(Number(S.priceHistoryMinutes)*60<Number(S.btcDropWindowSec))S.priceHistoryMinutes=Math.ceil(Number(S.btcDropWindowSec)/60)+1;S.maxBuyUsd=Math.max(1,Number(S.maxBuyUsd)||150);save();render()}
function exportData(){let b=new Blob([JSON.stringify(S,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='cryptotrader-v4.9-memory.json';a.click()}
function resetAll(){if(confirm('Apagar posições, histórico e estado?')){localStorage.removeItem('ct_v3_state');location.reload()}}
let tabSwipeBound=false;
function bindTabSwipe(){
 if(tabSwipeBound)return;
 tabSwipeBound=true;
 let x0=0,y0=0,tracking=false,inPositionsScroll=false;
 const tabs=['dash','market','positions','history','backtest','config'];
 document.addEventListener('touchstart',e=>{
   if(!e.changedTouches.length)return;
   const t=e.changedTouches[0];
   x0=t.clientX;y0=t.clientY;
   inPositionsScroll=!!e.target.closest?.('[data-no-tab-swipe="1"]');
   tracking=true;
 },{passive:true});
 document.addEventListener('touchend',e=>{
   if(!tracking||!e.changedTouches.length)return;
   tracking=false;
   const t=e.changedTouches[0];
   const dx=t.clientX-x0,dy=t.clientY-y0;
   const horizontal=Math.abs(dx)>Math.abs(dy)*1.25;
   // Na área das moedas expostas da página Posições, a navegação entre páginas
   // só acontece com um gesto que percorra quase todo o ecrã. O scroll horizontal
   // da própria tabela continua disponível normalmente.
   const protectedArea=e.target.closest?.('[data-no-tab-swipe="1"]');
   if(e.target.closest?.('[data-disable-tab-swipe="1"]'))return;
   const threshold=protectedArea
     ? Math.max(0,window.innerWidth*(Number(protectedArea.dataset.swipeThreshold)||0.50))
     : 70;
   if(!horizontal || Math.abs(dx)<threshold)return;
   const i=tabs.indexOf(tab);
   // Navegação circular: ao chegar ao fim, continua no início, e vice-versa.
   const ni=dx<0?(i+1)%tabs.length:(i-1+tabs.length)%tabs.length;
   if(ni!==i){tab=tabs[ni];render();window.scrollTo({top:0,behavior:'smooth'});}
 });
}
function render(){
 let html=tab==='dash'?dashboard():tab==='market'?tableMarket():tab==='positions'?positions():tab==='history'?history():tab==='backtest'?backtest():config();
 document.getElementById('app').innerHTML=html;
 bindCharts();
 bindTabSwipe();
 const marketSearchBtn=document.getElementById('marketSearchBtn');
 if(marketSearchBtn){marketSearchBtn.onclick=()=>{
   marketSearchOpen=true;
   render();
   requestAnimationFrame(()=>{
     const input=document.getElementById('marketSearchInput');
     if(input){input.focus();input.select();}
   });
 };}
 const marketSearchInput=document.getElementById('marketSearchInput');
 if(marketSearchInput){
   marketSearchInput.oninput=()=>{marketSearch=marketSearchInput.value;render();requestAnimationFrame(()=>{const i=document.getElementById('marketSearchInput');if(i){i.focus();i.setSelectionRange(i.value.length,i.value.length);}});};
   marketSearchInput.onkeydown=(e)=>{if(e.key==='Escape'){marketSearch='';marketSearchOpen=false;render();}};
 }
 const marketSearchClear=document.getElementById('marketSearchClear');
 if(marketSearchClear){marketSearchClear.onclick=()=>{marketSearch='';marketSearchOpen=false;render();};}
 document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 document.querySelectorAll('[data-pos]').forEach(r=>r.onclick=()=>{selectedPosition=selectedPosition===r.dataset.pos?null:r.dataset.pos;render()});
 document.querySelectorAll('[data-history-op]').forEach(el=>el.onclick=()=>{const k=el.dataset.historyOp;selectedHistoryOperation=selectedHistoryOperation===k?null:k;render()});
 const historyProtectionToggle=document.getElementById('historyProtectionToggle');
 if(historyProtectionToggle)historyProtectionToggle.onclick=()=>{historyProtectionOpen=!historyProtectionOpen;render();};
 const historySimToggle=document.getElementById('historySimToggle');
 if(historySimToggle)historySimToggle.onclick=()=>{historySimOpen=!historySimOpen;render();};
 const historySimSymbolEl=document.getElementById('historySimSymbol');
 if(historySimSymbolEl)historySimSymbolEl.onchange=()=>{historySimSymbol=historySimSymbolEl.value;requestAnimationFrame(drawHistorySimulation)};
 const historySimBarsEl=document.getElementById('historySimBars');
 if(historySimBarsEl)historySimBarsEl.onchange=()=>{historySimBars=Number(historySimBarsEl.value)||72;requestAnimationFrame(drawHistorySimulation)};
 const applyHistoryTrailSettings=document.getElementById('applyHistoryTrailSettings');
 const applyHistoryTrailValues=()=>{
   const a=Math.max(0.05,Math.min(100,Number(document.getElementById('historyTrailActivate')?.value)||1.2));
   const d=Math.max(0.05,Math.min(50,Number(document.getElementById('historyTrailDrop')?.value)||0.55));
   S.trailActivate=a; S.trailDrop=d; S.trailCustomEnabled=true;
   Object.values(S.positions||{}).forEach(p=>{p.trailActivate=a;p.trailDrop=d;});
   save(); render();
 };
 if(applyHistoryTrailSettings)applyHistoryTrailSettings.onclick=applyHistoryTrailValues;
 document.querySelectorAll('#historyTrailActivate,#historyTrailDrop').forEach(el=>{el.addEventListener('input',()=>{requestAnimationFrame(drawHistorySimulation)});});
 if(tab==='history'){requestAnimationFrame(drawHistorySimulation);requestAnimationFrame(drawHistoryProtectionSimulation);}
 document.querySelectorAll('[data-goto-positions]').forEach(el=>el.onclick=()=>goToDashboardPositions());
 const resultCard=document.querySelector('[data-toggle-result-positions]');
 if(resultCard){
   resultCard.onclick=()=>{
     const box=document.getElementById('dashboardResultPositions');
     if(box)box.style.display=box.style.display==='none'?'block':'none';
   };
 }
 document.querySelectorAll('[data-alert-symbol]').forEach(el=>{
   const toggle=()=>{
     const key=el.dataset.alertSymbol+'|'+el.dataset.alertType;
     selectedAlert=selectedAlert===key?null:key;
     render();
     if(selectedAlert){requestAnimationFrame(()=>el.scrollIntoView({behavior:'smooth',block:'nearest'}));}
   };
   el.onclick=toggle;
   el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle();}};
 });
}
function goToDashboardPositions(){
 const target=document.getElementById('dashPositions');
 if(!target)return;
 const y=target.getBoundingClientRect().top+window.pageYOffset-92;
 window.scrollTo({top:Math.max(0,y),behavior:'smooth'});
}
document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;render()});
render();refresh();
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&S.auto)refresh()});
function updateNetworkStatus(){
 const el=document.getElementById('netStatus');
 if(!el)return;
 const online=navigator.onLine;
 el.classList.toggle('online',online);
 const txt=el.querySelector('.netText');
 if(txt)txt.textContent=online?'Internet':'Sem Internet';
 el.title=online?'Ligado à Internet':'Sem ligação à Internet';
}
window.addEventListener('online',updateNetworkStatus);
window.addEventListener('offline',updateNetworkStatus);
updateNetworkStatus();

let wakeLock=null;
async function requestWakeLock(){try{if('wakeLock'in navigator)wakeLock=await navigator.wakeLock.request('screen')}catch(e){}}
document.addEventListener('pointerdown',()=>requestWakeLock(),{once:true});



// Feedback táctil dos botões
(function(){
  function isButton(el){
    return el && el.closest && el.closest('button, .btn, [role="button"], input[type="button"], input[type="submit"]');
  }
  document.addEventListener('pointerdown', function(e){
    var b = isButton(e.target);
    if (!b) return;
    b.classList.add('btn-pressed');
  }, {passive:true});
  function release(e){
    var b = isButton(e.target);
    if (b) {
      b.classList.remove('btn-pressed');
      if (b.tagName === 'BUTTON' && /guardar|salvar|save/i.test((b.innerText || b.value || '').trim())) {
        b.classList.add('save-ok');
        setTimeout(function(){ b.classList.remove('save-ok'); }, 900);
        showToast('Guardado ✓');
      }
    }
  }
  document.addEventListener('pointerup', release, {passive:true});
  document.addEventListener('pointercancel', release, {passive:true});
  document.addEventListener('pointerleave', function(e){
    var b = isButton(e.target);
    if (b) b.classList.remove('btn-pressed');
  }, {passive:true});

  window.showToast = function(msg){
    var t = document.querySelector('.toast');
    if (!t) {
      t = document.createElement('div');
      t.className = 'toast';
      t.setAttribute('aria-live','polite');
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(function(){ t.classList.remove('show'); }, 1100);
  };
})();


function toggleV44SalesPanel(){
 const box=document.getElementById('v44SalesPanel');
 const rows=document.getElementById('v44SalesRows');
 if(!box||!rows)return;
 const open=box.style.display!=='none';
 if(open){box.style.display='none';return;}
 const now=Date.now();
 const cutoff=now-24*60*60*1000;
 const sells=(S.trades||[]).filter(t=>{
   const type=String(t.type||'').toUpperCase();
   if(!(type==='SELL' || type.includes('VENDA'))) return false;
   const raw=t.time||t.ts||t.date||t.timestamp||t.createdAt;
   const tm=typeof raw==='number' ? (raw<10000000000?raw*1000:raw) : Date.parse(raw||'');
   return Number.isFinite(tm) && tm>=cutoff && tm<=now;
 }).slice().reverse();
 if(!sells.length){
   rows.innerHTML='<div class="sub">Ainda não existem moedas vendidas.</div>';
 }else{
   rows.innerHTML=sells.map(t=>{
     const coin=String(t.symbol||'').replace('USDT','');
     const p=Number(t.profit||0);
     const cls=p>=0?'good':'bad', sign=p>=0?'+':'';
     const rawTime=t.time||t.ts||t.date||t.timestamp||t.createdAt;
     const saleMs=typeof rawTime==='number' ? (rawTime<10000000000?rawTime*1000:rawTime) : Date.parse(rawTime||'');
     const saleTime=Number.isFinite(saleMs)?new Date(saleMs).toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'}):'—';
     const rawMax=t.peak??t.maxAfterBuy??t.maxPriceAfterBuy??t.maxPrice??t.highAfterBuy??t.maxHigh??t.peakPrice??t.high??t.max;
     const maxNum=Number(rawMax);
     const maxPrice=Number.isFinite(maxNum)&&maxNum>0 ? money(maxNum) : '—';
     return '<div class="v44-sale-row"><b>'+esc(coin)+'</b><span class="v44-sale-time">'+saleTime+'</span><span class="v44-sale-max">'+maxPrice+'</span><span class="v44-sale-profit '+cls+'">'+sign+money(p)+'</span></div>';
   }).join('');
 }
 box.style.display='block';
 box.scrollIntoView({behavior:'smooth',block:'nearest'});
}


function toggleV44BestSalePanel(){
 const box=document.getElementById('v44BestSalePanel');
 if(!box)return;
 if(box.style.display!=='none'){box.style.display='none';return;}
 const sells=(S.trades||[]).filter(t=>{
   const type=String(t.type||'').toUpperCase();
   return type==='SELL' || type.includes('VENDA');
 });
 if(!sells.length){
   box.innerHTML='<div class="v44-best-sale-box"><div class="v44-best-sale-title">Melhor venda</div><div class="sub">Ainda não existem vendas.</div></div>';
 }else{
   const bestTrade=sells.reduce((best,t)=>Number(t.profit||0)>Number(best.profit||0)?t:best,sells[0]);
   const coin=String(bestTrade.symbol||'').replace('USDT','');
   const profit=Number(bestTrade.profit||0);
   const price=Number(bestTrade.price||0);
   const cls=profit>=0?'good':'bad';
   const sign=profit>=0?'+':'';
   box.innerHTML='<div class="v44-best-sale-box"><div class="v44-best-sale-title">Moeda da melhor venda</div><div class="v44-best-sale-coin">'+esc(coin||'—')+'</div><div class="v44-best-sale-meta">Lucro: <b class="'+cls+'">'+sign+money(profit)+'</b>'+(price?' · Preço: '+money(price):'')+'</div></div>';
 }
 box.style.display='block';
 box.scrollIntoView({behavior:'smooth',block:'nearest'});
}


(function(){
  if (window.__v44PullRefresh30) return;
  window.__v44PullRefresh30 = true;

  const PULL_TRIGGER = 0.30;
  let startY = 0, pulling = false, refreshing = false, indicator = null;

  function getIndicator(){
    if (indicator) return indicator;
    indicator = document.createElement('div');
    indicator.id = 'v44-pull-refresh';
    indicator.textContent = 'Puxa mais 30% para atualizar';
    Object.assign(indicator.style,{
      position:'fixed',top:'10px',left:'50%',transform:'translate(-50%,-140%)',
      zIndex:'99999',padding:'8px 14px',borderRadius:'999px',
      background:'var(--panel,#171a22)',color:'var(--text,#fff)',
      border:'1px solid var(--line,#333)',fontSize:'12px',
      pointerEvents:'none',transition:'transform .15s ease'
    });
    document.body.appendChild(indicator);
    return indicator;
  }

  function canPull(){
    return !refreshing && window.scrollY <= 2 &&
      !document.querySelector('input:focus,textarea:focus,select:focus');
  }

  function finish(){
    const el=getIndicator();
    el.textContent='A atualizar…';
    el.style.transform='translate(-50%,0)';
    refreshing=true;
    setTimeout(function(){
      location.reload();
    },150);
  }

  document.addEventListener('touchstart',function(e){
    if (!canPull() || !e.touches.length) return;
    startY=e.touches[0].clientY;
    pulling=false;
  },{passive:true});

  document.addEventListener('touchmove',function(e){
    if (refreshing || !e.touches.length || startY===0) return;
    if (!canPull()) { startY=0; return; }

    const dy=e.touches[0].clientY-startY;
    if (dy<=0) return;

    // The trigger distance is 30% of the viewport height.
    const trigger=Math.max(120,window.innerHeight*PULL_TRIGGER);
    const progress=Math.min(1,dy/trigger);
    const el=getIndicator();

    if (dy>12) {
      pulling=true;
      el.textContent=progress>=1 ? 'Solta para atualizar' : 'Puxa mais '+Math.ceil((1-progress)*30)+'%';
      el.style.transform='translate(-50%,'+(-140+140*progress)+'%)';
    }
  },{passive:true});

  document.addEventListener('touchend',function(){
    if (!pulling || refreshing) { startY=0; return; }
    const el=getIndicator();
    const dy=parseFloat(el.dataset.dy||'0');
    // Recalculate from current touch position is unavailable at touchend,
    // so use the visual state as the release threshold.
    const matrix=getComputedStyle(el).transform;
    const triggered=matrix!=='none' && matrix.indexOf(', 0)')!==-1;
    if (triggered) finish();
    else el.style.transform='translate(-50%,-140%)';
    startY=0; pulling=false;
  },{passive:true});

  // Track the last touch position so the release threshold is exact.
  document.addEventListener('touchmove',function(e){
    if(pulling && e.touches.length && startY){
      const dy=e.touches[0].clientY-startY;
      getIndicator().dataset.dy=String(dy);
    }
  },{passive:true});

  document.addEventListener('touchend',function(){
    if (!pulling || refreshing) return;
    const dy=Number(getIndicator().dataset.dy||0);
    const trigger=Math.max(120,window.innerHeight*PULL_TRIGGER);
    if(dy>=trigger) finish();
  },{passive:true});
})();
