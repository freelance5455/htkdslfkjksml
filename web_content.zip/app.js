const $=id=>document.getElementById(id);
const canvas=$("canvas"),ctx=canvas.getContext("2d",{willReadFrequently:true}),fileInput=$("fileInput");
let image=new Image(), loaded=false;
let state={brightness:0,contrast:0,saturation:0,sharpness:0,angle:0,flipH:1,flipV:1,filter:"none",text:""};
let history=[],future=[];
let cropMode=false,cropStart=null,cropRect=null;

function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1500)}
function snapshot(){return JSON.stringify(state)}
function pushHistory(){if(loaded){history.push(snapshot());if(history.length>30)history.shift();future=[]}}
function restore(s){state=JSON.parse(s);syncUI();draw()}
function syncUI(){["brightness","contrast","saturation","sharpness"].forEach(k=>{$(k).value=state[k];$(k+"Out").textContent=state[k]});$("textInput").value=state.text}
function resetState(){state={brightness:0,contrast:0,saturation:0,sharpness:0,angle:0,flipH:1,flipV:1,filter:"none",text:""};syncUI();draw()}

$("openBtn").onclick=()=>fileInput.click();
fileInput.onchange=e=>{
 const f=e.target.files[0]; if(!f)return;
 const reader=new FileReader();
 reader.onload=ev=>{image.onload=()=>{loaded=true;$("empty").style.display="none";canvas.style.display="block";history=[];future=[];resetState();toast("Photo loaded")};image.src=ev.target.result};
 reader.readAsDataURL(f);
};

function cssFilter(){
 const b=100+state.brightness;
 const c=(259*(state.contrast+255))/(255*(259-state.contrast));
 const s=100+state.saturation;
 let f=`brightness(${b}%) contrast(${c}%) saturate(${s}%)`;
 if(state.filter==="gray")f+=" grayscale(1)";
 if(state.filter==="warm")f+=" sepia(.25) saturate(1.25)";
 if(state.filter==="cool")f+=" hue-rotate(18deg) saturate(1.15)";
 if(state.filter==="vivid")f+=" saturate(1.45) contrast(1.05)";
 if(state.filter==="fade")f+=" brightness(1.08) saturate(.72) contrast(.88)";
 return f;
}
function draw(){
 if(!loaded)return;
 const w=image.naturalWidth,h=image.naturalHeight, a=((state.angle%360)+360)%360;
 const swap=a===90||a===270;
 canvas.width=swap?h:w;canvas.height=swap?w:h;
 ctx.save();ctx.translate(canvas.width/2,canvas.height/2);ctx.rotate(a*Math.PI/180);ctx.scale(state.flipH,state.flipV);
 ctx.filter=cssFilter();ctx.drawImage(image,-w/2,-h/2,w,h);ctx.restore();
 if(state.sharpness>0) applySharpness(state.sharpness);
 if(state.text){ctx.save();ctx.font=`800 ${Math.max(24,canvas.width*.055)}px system-ui`;ctx.textAlign="center";ctx.textBaseline="middle";ctx.lineWidth=6;ctx.strokeStyle="#000";ctx.fillStyle="#fff";ctx.strokeText(state.text,canvas.width/2,canvas.height*.88);ctx.fillText(state.text,canvas.width/2,canvas.height*.88);ctx.restore()}
 if(cropMode&&cropRect){ctx.save();ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.setLineDash([7,5]);ctx.strokeRect(cropRect.x,cropRect.y,cropRect.w,cropRect.h);ctx.restore()}
}
function applySharpness(amount){
 const w=canvas.width,h=canvas.height;if(w*h>5000000)return;
 const src=ctx.getImageData(0,0,w,h),out=ctx.createImageData(w,h),s=src.data,o=out.data;
 const a=amount/100*.7;
 for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){let i=(y*w+x)*4;
  for(let k=0;k<3;k++){let v=s[i+k]*(1+4*a)-a*(s[i-4+k]+s[i+4+k]+s[i-w*4+k]+s[i+w*4+k]);o[i+k]=Math.max(0,Math.min(255,v))}
  o[i+3]=s[i+3];
 }
 ctx.putImageData(out,0,0);
}

["brightness","contrast","saturation","sharpness"].forEach(k=>{
 $(k).oninput=e=>{if(!loaded)return;pushHistory();state[k]=+e.target.value;$(k+"Out").textContent=e.target.value;draw()}
});
$("rotateLeft").onclick=()=>{if(!loaded)return;pushHistory();state.angle=(state.angle+270)%360;draw()};
$("rotateRight").onclick=()=>{if(!loaded)return;pushHistory();state.angle=(state.angle+90)%360;draw()};
$("flipH").onclick=()=>{if(!loaded)return;pushHistory();state.flipH*=-1;draw()};
$("flipV").onclick=()=>{if(!loaded)return;pushHistory();state.flipV*=-1;draw()};
$("resetBtn").onclick=()=>{if(!loaded)return;pushHistory();resetState();toast("Reset")};
$("addText").onclick=()=>{if(!loaded)return;pushHistory();state.text=$("textInput").value.trim();draw()};
$("clearText").onclick=()=>{pushHistory();state.text="";$("textInput").value="";draw()};
document.querySelectorAll("[data-filter]").forEach(b=>b.onclick=()=>{if(!loaded)return;pushHistory();state.filter=b.dataset.filter;draw()});

$("undoBtn").onclick=()=>{if(!history.length||!loaded)return;future.push(snapshot());restore(history.pop());toast("Undo")};
$("redoBtn").onclick=()=>{if(!future.length||!loaded)return;history.push(snapshot());restore(future.pop());toast("Redo")};

document.querySelectorAll(".tab").forEach(tab=>tab.onclick=()=>{
 document.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));tab.classList.add("active");
 document.querySelectorAll(".panel").forEach(p=>p.classList.add("hidden"));$(tab.dataset.panel).classList.remove("hidden");
});

$("startCrop").onclick=()=>{if(!loaded)return;cropMode=true;cropRect=null;toast("Canvas पर drag करें");};
canvas.addEventListener("pointerdown",e=>{
 if(!cropMode)return;
 const r=canvas.getBoundingClientRect(),sx=canvas.width/r.width,sy=canvas.height/r.height;
 cropStart={x:(e.clientX-r.left)*sx,y:(e.clientY-r.top)*sy};cropRect={x:cropStart.x,y:cropStart.y,w:0,h:0};canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener("pointermove",e=>{
 if(!cropMode||!cropStart)return;
 const r=canvas.getBoundingClientRect(),sx=canvas.width/r.width,sy=canvas.height/r.height;
 const x=(e.clientX-r.left)*sx,y=(e.clientY-r.top)*sy;
 cropRect={x:Math.min(cropStart.x,x),y:Math.min(cropStart.y,y),w:Math.abs(x-cropStart.x),h:Math.abs(y-cropStart.y)};draw();
});
canvas.addEventListener("pointerup",()=>{cropStart=null});
$("applyCrop").onclick=()=>{
 if(!loaded||!cropRect||cropRect.w<5||cropRect.h<5)return;
 pushHistory();
 const r=cropRect, tmp=document.createElement("canvas");tmp.width=Math.round(r.w);tmp.height=Math.round(r.h);
 tmp.getContext("2d").drawImage(canvas,r.x,r.y,r.w,r.h,0,0,r.w,r.h);
 image=new Image();image.onload=()=>{state.angle=0;state.flipH=1;state.flipV=1;cropMode=false;cropRect=null;draw();toast("Crop applied")};image.src=tmp.toDataURL("image/jpeg",.95);
};

$("saveBtn").onclick=()=>{
 if(!loaded){toast("पहले photo खोलें");return}
 const a=document.createElement("a");a.download="LightEdit_"+Date.now()+".jpg";a.href=canvas.toDataURL("image/jpeg",.94);a.click();toast("Photo saved")
};
