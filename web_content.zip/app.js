const LETTERS="BCDFGHJKLMNPRSTVWXYZ".split("");
const TOTAL=8000;
const KEY="matricula_collector_v1";
let collected=new Set(JSON.parse(localStorage.getItem(KEY)||"[]"));

const $=id=>document.getElementById(id);
const fmt=n=>n.toLocaleString("es-ES");
function save(){localStorage.setItem(KEY,JSON.stringify([...collected]));}
function combo(a,b,c){return a+b+c}
function allFor(first){let out=[];for(const b of LETTERS)for(const c of LETTERS)out.push(combo(first,b,c));return out}
function validCode(s){return s.length===3 && [...s].every(x=>LETTERS.includes(x))}
function countFirst(l){let n=0;for(const c of collected)if(c[0]===l)n++;return n}
function percent(){return Math.floor(collected.size/TOTAL*1000)/10}

function updateHome(){
  const n=collected.size,p=percent();
  $("collectedCount").textContent=fmt(n);$("remainingCount").textContent=fmt(TOTAL-n)+" restantes";
  $("mainPercent").textContent=p+"%";$("percentBadge").textContent=p+"%";
  $("mainProgress").style.width=Math.min(100,p)+"%";
}
function updateStats(){
  const n=collected.size; $("statCollected").textContent=fmt(n);$("statRemaining").textContent=fmt(TOTAL-n);
  const counts=LETTERS.map(l=>[l,countFirst(l)]);
  const complete=counts.filter(x=>x[1]===400).length;
  const best=counts.reduce((a,b)=>b[1]>a[1]?b:a,[null,0]);
  $("statBlocks").textContent=complete+"/20";$("statBest").textContent=best[0]?best[0]+" ("+best[1]+")":"—";
  $("statsBars").innerHTML=counts.map(([l,n])=>`<div class="bar-row"><div class="bar-label"><span>${l}</span><span>${n}/400</span></div><div class="bar"><i style="width:${n/4}%"></i></div></div>`).join("");
}
function renderLetters(){
  $("letterList").innerHTML=LETTERS.map(l=>{
    const n=countFirst(l);
    return `<button class="letter-row" data-letter="${l}"><div class="letter-top"><b>${l}</b><span>${n}/400</span></div><div class="mini-progress"><i style="width:${n/4}%"></i></div></button>`;
  }).join("");
  document.querySelectorAll(".letter-row").forEach(b=>b.onclick=()=>openLetter(b.dataset.letter));
}
function openLetter(l){
  $("comboPanel").classList.remove("hidden");$("letterList").classList.add("hidden");
  $("comboTitle").textContent=l;
  const list=allFor(l);
  const n=list.filter(x=>collected.has(x)).length;
  $("comboProgress").textContent=n+"/400";
  $("comboGrid").innerHTML=list.map(c=>`<button class="combo ${collected.has(c)?"collected":""}" data-code="${c}">${collected.has(c)?"✓ ":"□ "}${c}</button>`).join("");
  document.querySelectorAll(".combo").forEach(b=>b.onclick=()=>toggleCombo(b.dataset.code,b));
}
function closeLetter(){
  $("comboPanel").classList.add("hidden");$("letterList").classList.remove("hidden");
}
function toggleCombo(code,btn){
  if(collected.has(code)) { collected.delete(code); btn.classList.remove("collected"); btn.textContent="□ "+code; }
  else { collected.add(code); btn.classList.add("collected"); btn.textContent="✓ "+code; }
  save(); updateAll(); openLetter(code[0]);
}
function register(){
  let s=$("plateInput").value.toUpperCase().replace(/[^A-Z]/g,"");
  $("plateInput").value=s;
  const m=$("registerMessage");m.className="message";
  if(!validCode(s)){m.classList.add("warn");m.textContent="Introduce exactamente 3 letras válidas. No se usan vocales, Ñ ni Q.";return}
  if(collected.has(s)){m.classList.add("warn");m.textContent="Ya tienes "+s+" en tu colección.";return}
  collected.add(s);save();updateAll();
  m.classList.add("ok");m.textContent="✓ "+s+" añadida a tu colección.";
  $("plateInput").value="";
  toast("¡"+s+" conseguida!");
}
function updateAll(){updateHome();updateStats();renderLetters()}
function showScreen(id){
  document.querySelectorAll(".screen").forEach(s=>s.classList.toggle("active",s.id===id));
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.go===id));
  if(id==="collection")closeLetter();
  window.scrollTo(0,0);
}
function toast(t){const x=$("toast");x.textContent=t;x.classList.add("show");clearTimeout(window.__toast);window.__toast=setTimeout(()=>x.classList.remove("show"),1800)}
document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>showScreen(b.dataset.go));
$("saveBtn").onclick=register;
$("plateInput").addEventListener("keydown",e=>{if(e.key==="Enter")register()});
$("closeCombo").onclick=closeLetter;
$("resetBtn").onclick=()=>{if(confirm("¿Seguro que quieres borrar las 8.000 combinaciones de tu colección? Esta acción no se puede deshacer.")){collected.clear();save();updateAll();toast("Colección borrada");}};
updateAll();
