/* OmniWeb Studio - interactive demo (vanilla JS, no dependencies) */
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var esc = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  /* ---------- icons (24x24 material-style paths) ---------- */
  var P = {
    back: 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
    add: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
    search: 'M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
    close: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
    more: 'M12 8a2 2 0 100-4 2 2 0 000 4zm0 2a2 2 0 100 4 2 2 0 000-4zm0 6a2 2 0 100 4 2 2 0 000-4z',
    grid: 'M3 3h8v8H3V3zm0 10h8v8H3v-8zM13 3h8v8h-8V3zm0 10h8v8h-8v-8z',
    list: 'M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z',
    folder: 'M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z',
    save: 'M17 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V7l-4-4zm-5 16a3 3 0 110-6 3 3 0 010 6zm3-10H5V5h10v4z',
    lock: 'M18 8h-1V6a5 5 0 00-10 0v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2zm-6 9a2 2 0 110-4 2 2 0 010 4zm3.1-9H8.9V6a3.1 3.1 0 016.2 0v2z',
    check: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
    refresh: 'M17.65 6.35A7.96 7.96 0 0012 4a8 8 0 100 16c3.73 0 6.84-2.55 7.73-6h-2.08A6 6 0 1112 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
    play: 'M8 5v14l11-7z',
    terminal: 'M20 4H4a2 2 0 00-2 2v12a2 2 0 002 2h16a2 2 0 002-2V6a2 2 0 00-2-2zm0 14H4V8h16v10zm-2-1h-6v-2h6v2zM7.5 17l-1.41-1.41L8.67 13l-2.59-2.59L7.5 9l4 4-4 4z',
    wifi: 'M1 9l2 2a14 14 0 0118 0l2-2A17 17 0 001 9zm8 8l3 3 3-3a4.2 4.2 0 00-6 0zm-4-4l2 2a7 7 0 0110 0l2-2a10 10 0 00-14 0z',
    wifiOff: 'M23.64 7A17 17 0 0012 3c-1.5 0-2.89.19-4.15.48L18.18 13.8 23.64 7zm-6.6 8.22L3.27 1.44 2 2.72l2.05 2.06C1.91 5.76.59 6.82.36 7L12 21.5l3.9-4.86 3.32 3.32 1.27-1.27-3.45-3.47z',
    full: 'M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z',
    star: 'M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z',
    edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 000-1.41l-2.34-2.34a1 1 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
    copy: 'M16 1H4a2 2 0 00-2 2v14h2V3h12V1zm3 4H8a2 2 0 00-2 2v14a2 2 0 002 2h11a2 2 0 002-2V7a2 2 0 00-2-2zm0 16H8V7h11v14z',
    trash: 'M6 19a2 2 0 002 2h8a2 2 0 002-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
    build: 'M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z',
    android: 'M6 18a1 1 0 001 1h1v3.5a1.5 1.5 0 003 0V19h2v3.5a1.5 1.5 0 003 0V19h1a1 1 0 001-1V8H6v10zM3.5 8A1.5 1.5 0 002 9.5v7a1.5 1.5 0 003 0v-7A1.5 1.5 0 003.5 8zm17 0A1.5 1.5 0 0019 9.5v7a1.5 1.5 0 003 0v-7A1.5 1.5 0 0020.5 8zM15.53 2.16l1.3-1.3a.5.5 0 00-.71-.71l-1.48 1.48A5.84 5.84 0 0012 1c-.96 0-1.86.23-2.66.63L7.85.15a.5.5 0 00-.71.71l1.31 1.31A6 6 0 006 7h12a6 6 0 00-2.47-4.84zM10 5H9V4h1v1zm5 0h-1V4h1v1z',
    archive: 'M20.54 5.23l-1.39-1.68A1.5 1.5 0 0018 3H6c-.47 0-.88.21-1.16.55L3.46 5.23C3.17 5.57 3 6.02 3 6.5V19a2 2 0 002 2h14a2 2 0 002-2V6.5c0-.48-.17-.93-.46-1.27zM12 17.5L6.5 12H10v-2h4v2h3.5L12 17.5zM5.12 5l.81-1h12l.94 1H5.12z',
    upload: 'M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z',
    code: 'M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z',
    globe: 'M12 2a10 10 0 100 20 10 10 0 000-20zm6.93 6h-2.95a15.65 15.65 0 00-1.38-3.56A8.03 8.03 0 0118.92 8zM12 4.04c.83 1.2 1.48 2.53 1.91 3.96h-3.82c.43-1.43 1.08-2.76 1.91-3.96zM4.26 14a8 8 0 010-4h3.38a16 16 0 000 4H4.26zm.82 2h2.95c.32 1.25.78 2.45 1.38 3.56A8 8 0 015.08 16zm2.95-8H5.08a8 8 0 014.33-3.56A15.65 15.65 0 008.03 8zM12 19.96c-.83-1.2-1.48-2.53-1.91-3.96h3.82c-.43 1.43-1.08 2.76-1.91 3.96zM14.34 14H9.66a14 14 0 010-4h4.68a14 14 0 010 4zm.25 5.56c.6-1.11 1.06-2.31 1.38-3.56h2.95a8 8 0 01-4.33 3.56zM16.36 14a16 16 0 000-4h3.38a8 8 0 010 4h-3.38z',
    file: 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
    palette: 'M12 3a9 9 0 000 18c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.3-.5-.8-.5-1.2 0-1.1.9-2 2-2h2.4A4.6 4.6 0 0022 10c0-3.9-4.5-7-10-7z',
    shield: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z',
    app: 'M17 1H7a2 2 0 00-2 2v18a2 2 0 002 2h10a2 2 0 002-2V3a2 2 0 00-2-2zm0 18H7V5h10v14z',
    video: 'M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4a2 2 0 00-2 2v12a2 2 0 002 2h16a2 2 0 002-2V4h-4z'
  };
  function ic(name, cls) {
    return '<svg class="' + (cls || 'ico') + '" viewBox="0 0 24 24" aria-hidden="true"><path d="' + P[name] + '"/></svg>';
  }
  function ib(action, icon, label, extra) {
    return '<button class="ib ' + (extra && extra.cls || '') + '" data-action="' + action + '"' +
      (extra && extra.id ? ' data-id="' + extra.id + '"' : '') + ' aria-label="' + label + '" title="' + label + '">' + ic(icon) + '</button>';
  }

  /* ---------- templates ---------- */
  var BLANK = {
    'index.html': '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>OmniWeb Project</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <div class="container">\n    <h1>Welcome to OmniWeb Studio</h1>\n    <p>Start building your web app by editing these files.</p>\n    <button id="mainButton" onclick="handleClick()">Click Me</button>\n  </div>\n  <script src="script.js"></script>\n</body>\n</html>\n',
    'style.css': '* { margin: 0; padding: 0; box-sizing: border-box; }\nbody {\n  font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif;\n  background: #0f172a;\n  color: #e2e8f0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-height: 100vh;\n}\n.container { text-align: center; padding: 24px; }\nh1 { font-size: 2rem; margin-bottom: 12px; color: #38bdf8; }\np { margin-bottom: 24px; color: #94a3b8; }\nbutton {\n  background: #38bdf8;\n  color: #0f172a;\n  border: none;\n  padding: 12px 28px;\n  border-radius: 8px;\n  font-size: 1rem;\n  font-weight: 600;\n  cursor: pointer;\n}\nbutton:hover { opacity: 0.85; }\n',
    'script.js': 'function handleClick() {\n  console.log(\'Button clicked at \' + new Date().toISOString());\n  alert(\'Hello from OmniWeb Studio!\');\n}\n'
  };
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function defaultConfig(name) {
    return { appName: name, pkg: 'com.omniweb.app', vName: '1.0.0', vCode: 1, color: '#38bdf8', dark: true, full: false, desktop: false, orient: 'auto', icon: false, perms: ['INTERNET'] };
  }

  var LANDING = {
    'index.html': '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>Bean There</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <header><h1>Bean There</h1><p>Small-batch coffee, roasted on Tuesdays.</p></header>\n  <main>\n    <section><h2>Today\'s roast</h2><p>Ethiopia Guji - blueberry, jasmine, honey.</p></section>\n    <section><h2>Visit us</h2><p>12 Market Lane, open 7am to 6pm.</p></section>\n  </main>\n</body>\n</html>\n',
    'style.css': 'body{margin:0;font-family:Georgia,serif;background:#fdf6ec;color:#3b2a20}\nheader{padding:48px 24px;background:#3b2a20;color:#fdf6ec;text-align:center}\nh1{font-size:2.2rem;margin:0 0 8px}\nmain{padding:24px;display:grid;gap:16px}\nsection{background:#fff;border-radius:12px;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,.08)}\n'
  };

  /* ---------- state ---------- */
  var FREE_LIMIT = 3;
  var uid = 3;
  var S = {
    route: { name: 'splash' },
    stack: [],
    view: 'grid',
    q: '',
    pro: false,
    proLabel: '',
    projects: [
      { id: 1, name: 'My Project', files: clone(BLANK), main: 'index.html', cfg: defaultConfig('My Project'), updated: Date.now() - 86400000 * 2 },
      { id: 2, name: 'Bean There', files: clone(LANDING), main: 'index.html', cfg: defaultConfig('Bean There'), updated: Date.now() - 3600000 * 5 }
    ]
  };
  var ED = { file: 'index.html', explorer: false, saveTimer: null, dirty: false };
  var PV = { device: 'auto', console: false, online: true, full: false, logs: [] };
  var EX = { running: false, done: false, lines: [], pct: 0, name: '', kind: '' };

  function proj(id) { return S.projects.filter(function (p) { return p.id === id; })[0]; }
  function cur() { return proj(S.route.id); }
  function bytes(p) { var n = 0; for (var k in p.files) n += new Blob([p.files[k]]).size; return n; }
  function fmt(n) { return n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB'; }
  function dateFmt(t) { return new Date(t).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); }
  function canCreate() { return S.pro || S.projects.length < FREE_LIMIT; }

  /* ---------- navigation ---------- */
  function nav(name, params) {
    S.stack.push(S.route);
    S.route = Object.assign({ name: name }, params || {});
    render();
  }
  function back() {
    S.route = S.stack.pop() || { name: 'dashboard' };
    render();
  }

  var app = $('#app');
  var splashTimer = null;
  function render() {
    var r = S.route.name;
    clearTimeout(splashTimer);
    if (r === 'splash') {
      app.innerHTML = '<div class="splash"><div class="logo">' + ic('code') + '</div><h1>OmniWeb Studio</h1><h2>APK Builder Pro</h2><div class="bar"><i></i></div><p>Loading workspace...</p></div>';
      splashTimer = setTimeout(function () { S.route = { name: 'dashboard' }; render(); }, 1800);
      return;
    }
    var views = { dashboard: vDashboard, editor: vEditor, preview: vPreview, builder: vBuilder, export: vExport, paywall: vPaywall };
    app.innerHTML = '<div class="screen">' + views[r]() + '</div>';
    if (r === 'editor') mountEditor();
    if (r === 'preview') mountPreview();
  }

  function bar(title, sub, actions, noBack) {
    return '<div class="appbar">' + (noBack ? '' : ib('back', 'back', 'Back')) +
      '<div class="title">' + esc(title) + (sub ? '<small id="bar-sub">' + esc(sub) + '</small>' : '') + '</div>' + (actions || '') + '</div>';
  }

  /* ---------- toast / sheet / dialog ---------- */
  var toastTimer;
  function toast(msg, kind) {
    var t = $('#toast');
    t.textContent = msg;
    t.className = 'toast show ' + (kind || '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = 'toast'; }, 2400);
  }
  function closeOverlay() { $('#overlay').innerHTML = ''; }
  function sheet(items, title) {
    var h = '<div class="scrim" data-action="scrim"><div class="sheet" role="dialog"><div class="grab"></div>' + (title || '') +
      items.map(function (it, i) {
        return '<button class="it ' + (it.danger ? 'danger' : '') + '" data-sheet="' + i + '">' +
          (it.sub ? '<span class="ti">' + ic(it.icon) + '</span><span>' + esc(it.label) + '<small>' + esc(it.sub) + '</small></span>' : ic(it.icon) + '<span>' + esc(it.label) + '</span>') + '</button>';
      }).join('') + '</div></div>';
    $('#overlay').innerHTML = h;
    $('#overlay').firstChild._items = items;
  }
  function dialog(o) {
    var h = '<div class="scrim mid" data-action="scrim"><div class="dlg" role="dialog"><h3>' + (o.icon ? ic(o.icon) : '') + esc(o.title) + '</h3>' +
      (o.text ? '<p>' + esc(o.text) + '</p>' : '') + (o.body || '') +
      '<div class="acts">' + o.actions.map(function (a, i) {
        return '<button class="btn ' + (a.primary ? 'sm' : 'text') + (a.danger ? ' danger' : '') + '" data-dlg="' + i + '">' + esc(a.label) + '</button>';
      }).join('') + '</div></div></div>';
    $('#overlay').innerHTML = h;
    $('#overlay').firstChild._acts = o.actions;
    var inp = $('#overlay input'); if (inp) { inp.focus(); inp.select(); }
  }
  function promptDlg(title, label, value, okLabel, cb) {
    dialog({
      title: title,
      body: '<input class="input" id="dlg-in" aria-label="' + esc(label) + '" placeholder="' + esc(label) + '" value="' + esc(value) + '">',
      actions: [{ label: 'Cancel' }, { label: okLabel, primary: true, run: function () { var v = $('#dlg-in').value.trim(); if (v) cb(v); } }]
    });
  }
  function upgradeDlg(msg) {
    dialog({
      title: 'Upgrade to Pro', icon: 'star', text: msg,
      actions: [{ label: 'Later' }, { label: 'Go Pro', primary: true, run: function () { nav('paywall'); } }]
    });
  }

  /* ---------- dashboard ---------- */
  function filtered() {
    var q = S.q.toLowerCase();
    return S.projects.filter(function (p) { return !q || p.name.toLowerCase().indexOf(q) >= 0; });
  }
  function vDashboard() {
    var banner = S.pro ? '' : '<div class="banner">' + ic('star') + '<div><b>Unlock Pro Features</b><span>Custom package ID, icons, advanced permissions & more.</span></div><button class="btn text sm" data-action="paywall">Go Pro</button></div>';
    return bar('OmniWeb Studio', '', ib('toggleView', S.view === 'grid' ? 'list' : 'grid', 'Switch view'), true) +
      '<div class="scroll" id="dash-scroll"><div class="pad"><label class="search">' + ic('search') + '<input id="q" placeholder="Search projects..." value="' + esc(S.q) + '" aria-label="Search projects"></label></div>' +
      '<div class="chips" id="stats"></div>' + banner + '<div id="plist"></div></div>' +
      '<button class="fab" data-action="create" aria-label="New project">' + ic('add') + '</button>';
  }
  function renderList() {
    var list = filtered(), files = 0, size = 0;
    S.projects.forEach(function (p) { files += Object.keys(p.files).length; size += bytes(p); });
    $('#stats').innerHTML = '<span class="stat">' + ic('folder') + S.projects.length + ' projects</span><span class="stat">' + ic('file') + files + ' files</span><span class="stat">' + ic('archive') + fmt(size) + '</span>';
    if (!list.length) {
      $('#plist').innerHTML = '<div class="empty">' + ic('globe') + '<h3>No projects yet</h3><p>' + (S.q ? 'No projects match "' + esc(S.q) + '"' : 'Create a blank project or import a ZIP archive') + '</p></div>';
      return;
    }
    if (S.view === 'grid') {
      $('#plist').innerHTML = '<div class="grid">' + list.map(function (p) {
        return '<div class="card pcard" role="button" tabindex="0" data-action="openEditor" data-id="' + p.id + '"><div class="thumb">' + ic('globe') + '</div><h3>' + esc(p.name) + '</h3><p>' + dateFmt(p.updated) + '</p><div class="foot"><p>' + Object.keys(p.files).length + ' files</p><button class="more" data-action="projMenu" data-id="' + p.id + '" aria-label="Project actions">' + ic('more', 'ico sm') + '</button></div></div>';
      }).join('') + '</div>';
    } else {
      $('#plist').innerHTML = list.map(function (p) {
        return '<div class="card lrow" role="button" tabindex="0" data-action="openEditor" data-id="' + p.id + '"><div class="thumb">' + ic('globe') + '</div><div class="meta"><h3>' + esc(p.name) + '</h3><p>' + Object.keys(p.files).length + ' files · ' + dateFmt(p.updated) + '</p></div><button class="ib" data-action="projMenu" data-id="' + p.id + '" aria-label="Project actions">' + ic('more') + '</button></div>';
      }).join('');
    }
  }
  function projMenu(p) {
    sheet([
      { icon: 'edit', label: 'Open Editor', run: function () { nav('editor', { id: p.id }); } },
      { icon: 'play', label: 'Live Preview', run: function () { nav('preview', { id: p.id }); } },
      { icon: 'build', label: 'Build / Export', run: function () { nav('builder', { id: p.id }); } },
      { icon: 'copy', label: 'Clone Project', run: function () { cloneProj(p); } },
      { icon: 'edit', label: 'Rename', run: function () { promptDlg('Rename Project', 'Project name', p.name, 'Rename', function (v) { p.name = v; p.updated = Date.now(); renderList(); }); } },
      { icon: 'trash', label: 'Delete', danger: true, run: function () {
        dialog({ title: 'Delete Project', text: 'Delete "' + p.name + '"? This cannot be undone.', actions: [{ label: 'Cancel' }, { label: 'Delete', danger: true, run: function () { S.projects = S.projects.filter(function (x) { return x !== p; }); renderList(); } }] });
      } }
    ]);
  }
  function cloneProj(p) {
    if (!canCreate()) { upgradeDlg('Free users are limited to ' + FREE_LIMIT + ' projects.'); return; }
    var c = clone(p); c.id = ++uid; c.name = p.name + ' (Copy)'; c.updated = Date.now();
    S.projects.push(c); renderList(); toast('Cloned "' + p.name + '"', 'ok');
  }
  function createMenu() {
    sheet([
      { icon: 'add', label: 'Create Blank Project', sub: 'Boilerplate HTML5 + CSS + JS template', run: function () {
        if (!canCreate()) { upgradeDlg('Free users are limited to ' + FREE_LIMIT + ' projects. Upgrade to Pro for unlimited projects.'); return; }
        promptDlg('New Blank Project', 'Project name', 'My Project', 'Create', function (v) {
          var p = { id: ++uid, name: v, files: clone(BLANK), main: 'index.html', cfg: defaultConfig(v), updated: Date.now() };
          S.projects.push(p); toast('Project "' + v + '" created', 'ok'); nav('editor', { id: p.id });
        });
      } },
      { icon: 'upload', label: 'Import ZIP Archive', sub: 'Demo: adds a sample imported site', run: function () {
        if (!canCreate()) { upgradeDlg('Free users are limited to ' + FREE_LIMIT + ' projects. Upgrade to Pro for unlimited projects.'); return; }
        var f = clone(LANDING); f['index.html'] = f['index.html'].replace('Bean There', 'Imported Site');
        S.projects.push({ id: ++uid, name: 'imported-site', files: f, main: 'index.html', cfg: defaultConfig('imported-site'), updated: Date.now() });
        renderList(); toast('Imported "imported-site" (2 files)', 'ok');
      } }
    ]);
  }

  /* ---------- editor ---------- */
  var SNIPS = [
    ['<!DOCTYPE>', '<!DOCTYPE html>\n'],
    ['<html>', '<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>App</title>\n</head>\n<body>\n\n</body>\n</html>'],
    ['<style>', '<style>\n\n</style>'], ['<script>', '<script>\n\n</script>'],
    ['<div>', '<div class="">\n\n</div>'], ['<a>', '<a href="">Link</a>'],
    ['<meta>', '<meta name="viewport" content="width=device-width, initial-scale=1.0">']
  ];
  function vEditor() {
    var p = cur();
    if (!p.files[ED.file]) ED.file = p.main;
    var files = Object.keys(p.files).sort();
    var explorer = ED.explorer ? '<aside class="explorer"><header>' + ic('folder') + '<span>Files</span><button class="ib" style="width:32px;height:32px" data-action="newFile" aria-label="New file">' + ic('add', 'ico sm') + '</button></header>' +
      files.map(function (n) {
        return '<div class="fitem' + (n === ED.file ? ' act' : '') + '" role="button" tabindex="0" data-action="openFile" data-name="' + esc(n) + '">' + ic('file', 'ico sm') + '<span>' + esc(n) + '</span>' + (n !== p.main ? '<button class="x ib" style="width:22px;height:22px" data-action="delFile" data-name="' + esc(n) + '" aria-label="Delete ' + esc(n) + '">' + ic('close', 'ico sm x') + '</button>' : '') + '</div>';
      }).join('') + '</aside>' : '';
    return bar(p.name, ED.file,
      ib('toggleExplorer', ED.explorer ? 'folder' : 'folder', 'File explorer', { cls: ED.explorer ? 'acc' : '' }) +
      ib('find', 'search', 'Find & replace') + ib('save', 'save', 'Save', { id: 'save-btn' }) + ib('edMenu', 'more', 'More')) +
      '<div class="ed-body">' + explorer + '<div class="ed-main"><div class="snips">' +
      SNIPS.map(function (s, i) { return '<button class="chip" data-action="snip" data-i="' + i + '">' + esc(s[0]) + '</button>'; }).join('') +
      '</div><div class="code"><div class="gutter" id="gut" aria-hidden="true"></div><textarea id="ta" spellcheck="false" wrap="off" autocapitalize="off" autocomplete="off" autocorrect="off" aria-label="Code editor"></textarea></div></div></div>';
  }
  function gutter() {
    var ta = $('#ta'), n = ta.value.split('\n').length, s = '';
    for (var i = 1; i <= n; i++) s += i + '\n';
    $('#gut').textContent = s;
    $('#gut').scrollTop = ta.scrollTop;
  }
  function setDirty(d) {
    ED.dirty = d;
    var sub = $('#bar-sub'); if (sub) sub.textContent = ED.file + (d ? ' •' : '');
    var sb = $('#save-btn'); if (sb) sb.className = 'ib' + (d ? ' acc' : '');
  }
  function mountEditor() {
    var p = cur(), ta = $('#ta');
    ta.value = p.files[ED.file] || '';
    gutter(); setDirty(false);
  }
  function saveNow(silent) {
    var p = cur(), ta = $('#ta'); if (!p || !ta) return;
    p.files[ED.file] = ta.value; p.updated = Date.now();
    clearTimeout(ED.saveTimer); setDirty(false);
    if (!silent) toast('Saved ' + ED.file, 'ok');
  }
  function insertAtCursor(text) {
    var ta = $('#ta'); ta.focus();
    ta.setRangeText(text, ta.selectionStart, ta.selectionEnd, 'end');
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  }
  function findDlg() {
    dialog({
      title: 'Find & Replace',
      body: '<input class="input" id="f-find" placeholder="Find" aria-label="Find"><input class="input" id="f-repl" placeholder="Replace with" aria-label="Replace with">',
      actions: [
        { label: 'Replace All', run: function () {
          var f = $('#f-find').value, r = $('#f-repl').value, ta = $('#ta'); if (!f) return;
          var n = ta.value.split(f).length - 1;
          if (!n) { toast('No matches for "' + f + '"', 'err'); return; }
          ta.value = ta.value.split(f).join(r); ta.dispatchEvent(new Event('input', { bubbles: true })); toast('Replaced ' + n + ' occurrence(s)', 'ok');
        } },
        { label: 'Find Next', primary: true, run: function () {
          var f = $('#f-find').value, ta = $('#ta'); if (!f) return;
          var from = ta.selectionEnd || 0, i = ta.value.indexOf(f, from); if (i < 0) i = ta.value.indexOf(f);
          if (i < 0) { toast('No matches for "' + f + '"', 'err'); return; }
          ta.focus(); ta.setSelectionRange(i, i + f.length);
        } }
      ]
    });
  }

  /* ---------- preview ---------- */
  function buildSrcdoc(p) {
    var html = p.files[p.main] || '<p style="font-family:sans-serif;padding:24px">Main file not found.</p>';
    html = html.replace(/<link[^>]*href=["']([^"']+\.css)["'][^>]*>/gi, function (m, f) { return p.files[f] != null ? '<style>' + p.files[f] + '</style>' : m; });
    html = html.replace(/<script[^>]*src=["']([^"']+\.js)["'][^>]*>\s*<\/script>/gi, function (m, f) { return p.files[f] != null ? '<script>' + p.files[f] + '<\/script>' : m; });
    var hook = '<script>(function(){function s(t,a){var m=Array.prototype.slice.call(a).map(function(x){try{return typeof x==="object"?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(" ");parent.postMessage({omni:1,t:t,m:m},"*")}["log","warn","error","info"].forEach(function(n){var o=console[n];console[n]=function(){s(n.toUpperCase(),arguments);if(o)o.apply(console,arguments)}});window.addEventListener("error",function(e){s("ERROR",[e.message])})})();<\/script>';
    return hook + html;
  }
  function devBtn(id, label) { return '<button class="chip dev' + (PV.device === id ? ' sel' : '') + '" data-action="device" data-id="' + id + '">' + label + '</button>'; }
  function vPreview() {
    var p = cur();
    return '<div class="' + (PV.full ? 'pv-full' : '') + '" style="display:flex;flex-direction:column;flex:1;min-height:0;position:relative">' +
      bar('Preview: ' + p.name, '', ib('net', PV.online ? 'wifi' : 'wifiOff', 'Toggle network (simulated)', { cls: PV.online ? '' : 'acc' }) + ib('console', 'terminal', 'Console')) +
      '<div class="pv-bar">' + ib('reload', 'refresh', 'Reload') + ib('full', 'full', 'Fullscreen') + '<span class="lab">Device:</span>' + devBtn('auto', 'Auto') + devBtn('phone', 'Phone') + devBtn('tablet', 'Tablet') + devBtn('desktop', 'Desktop') + '</div>' +
      (PV.online ? '' : '<div class="pv-off">Offline mode (simulated - page is hidden)</div>') +
      '<div class="pv-stage" id="pv-stage"><button class="pv-close" data-action="full" aria-label="Exit fullscreen">' + ic('close') + '</button>' +
      '<div class="pv-wrap" id="pv-wrap"><iframe id="pv-frame" title="Live preview" sandbox="allow-scripts allow-modals"></iframe>' +
      (PV.online ? '' : '<div class="pv-offline"><div>' + ic('wifiOff') + '<p>Network is offline</p></div></div>') + '</div></div>' +
      (PV.console ? '<div class="console"><header>' + ic('terminal', 'ico sm') + '<span>Console Output</span><button class="btn text sm" data-action="clearLogs">Clear</button></header><div class="lines" id="logs"></div></div>' : '') + '</div>';
  }
  function mountPreview() {
    var fr = $('#pv-frame'); if (!fr) return;
    fr.srcdoc = buildSrcdoc(cur());
    layoutPreview(); renderLogs();
  }
  function layoutPreview() {
    var st = $('#pv-stage'), wr = $('#pv-wrap'), fr = $('#pv-frame'); if (!st) return;
    if (PV.device === 'auto') {
      wr.className = 'pv-wrap'; wr.style.cssText = 'width:100%;height:100%';
      fr.style.cssText = 'width:100%;height:100%;transform:none'; return;
    }
    var size = { phone: [390, 844], tablet: [768, 1024], desktop: [1280, 800] }[PV.device];
    var sc = Math.min((st.clientWidth - 28) / size[0], (st.clientHeight - 28) / size[1], 1);
    wr.className = 'pv-wrap framed'; wr.style.cssText = 'width:' + (size[0] * sc + 8) + 'px;height:' + (size[1] * sc + 8) + 'px';
    fr.style.cssText = 'width:' + size[0] + 'px;height:' + size[1] + 'px;transform:scale(' + sc + ')';
  }
  function renderLogs() {
    var el = $('#logs'); if (!el) return;
    el.innerHTML = PV.logs.length ? PV.logs.map(function (l) {
      return '<div class="' + (l.indexOf('[ERROR]') === 0 ? 'e' : l.indexOf('[WARN]') === 0 ? 'w' : '') + '">' + esc(l) + '</div>';
    }).join('') : '<div class="none">No console output yet</div>';
    el.scrollTop = el.scrollHeight;
  }
  window.addEventListener('message', function (e) {
    var fr = $('#pv-frame');
    if (!fr || e.source !== fr.contentWindow || !e.data || !e.data.omni) return;
    PV.logs.push('[' + e.data.t + '] ' + e.data.m); if (PV.logs.length > 200) PV.logs.shift();
    renderLogs();
  });
  window.addEventListener('resize', layoutPreview);

  /* ---------- builder ---------- */
  var COLORS = ['#38bdf8', '#0ea5e9', '#6366f1', '#8b5cf6', '#ec4899', '#ef4444', '#f59e0b', '#10b981', '#14b8a6'];
  var PERMS = [
    ['INTERNET', 'Internet Access', 'Required for web content loading', true],
    ['ACCESS_FINE_LOCATION', 'Fine Location', 'Access GPS location'],
    ['CAMERA', 'Camera', 'Access device camera'],
    ['RECORD_AUDIO', 'Microphone', 'Record audio'],
    ['READ_EXTERNAL_STORAGE', 'Storage Read', 'Read external storage'],
    ['WRITE_EXTERNAL_STORAGE', 'Storage Write', 'Write external storage'],
    ['WAKE_LOCK', 'Wake Lock', 'Prevent screen from sleeping', true],
    ['ACCESS_NETWORK_STATE', 'Network State', 'Check connectivity', true],
    ['BLUETOOTH', 'Bluetooth', 'Bluetooth communication'],
    ['VIBRATE', 'Vibrate', 'Device vibration', true]
  ];
  function proLock(label, inner) {
    if (S.pro) return inner;
    return '<div class="prolock" role="button" tabindex="0" data-action="paywall"><div class="in" inert>' + inner + '</div><div class="cover"><span class="pill">' + ic('lock') + 'PRO · Tap to unlock ' + esc(label) + '</span></div></div>';
  }
  function toggle(key, label, sub, on, locked) {
    return '<button class="tog" role="switch" aria-checked="' + (on ? 'true' : 'false') + '" data-action="' + (locked ? 'paywall' : 'tog') + '" data-key="' + key + '"><span class="t"><b>' + esc(label) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (locked ? ic('lock', 'lk') : '') + '<span class="sw-track"></span></button>';
  }
  function vBuilder() {
    var c = cur().cfg;
    return bar('Build Configuration', '', ib('saveCfg', 'save', 'Save configuration') + ib('proceed', 'play', 'Proceed to export', { cls: 'acc' })) +
      '<div class="scroll"><div class="pad" style="padding-bottom:32px">' +
      '<div class="sec">' + ic('app') + 'App Details</div>' +
      '<label class="field"><span>App Name</span><input class="input" id="b-name" value="' + esc(c.appName) + '" placeholder="My Awesome App"></label>' +
      proLock('Custom Package Name', '<label class="field" style="margin:0"><span>Package Name</span><input class="input" id="b-pkg" value="' + esc(c.pkg) + '" placeholder="com.yourcompany.appname"><div class="helper">e.g., com.username.appname</div></label>') +
      '<div class="row"><label class="field"><span>Version Name</span><input class="input" id="b-vn" value="' + esc(c.vName) + '"></label><label class="field"><span>Version Code</span><input class="input" id="b-vc" inputmode="numeric" value="' + c.vCode + '"></label></div>' +
      '<div class="sec">' + ic('palette') + 'Visual Customization</div>' +
      '<div style="font-weight:500;margin-bottom:6px">Primary Theme Color</div><div class="swatches">' +
      COLORS.map(function (col) { return '<button class="sw' + (c.color === col ? ' sel' : '') + '" style="background:' + col + '" data-action="color" data-c="' + col + '" aria-label="Color ' + col + '">' + (c.color === col ? ic('check') : '') + '</button>'; }).join('') + '</div>' +
      toggle('dark', 'Dark Status Bar', '', c.dark) + toggle('full', 'Fullscreen Mode', '', c.full) + toggle('desktop', 'Desktop Mode', 'Render desktop version of websites', c.desktop) +
      '<div style="font-weight:500;margin:10px 0 8px">Screen Orientation</div><div class="seg">' +
      ['portrait', 'landscape', 'auto'].map(function (o) { return '<button class="' + (c.orient === o ? 'sel' : '') + '" data-action="orient" data-o="' + o + '">' + o.charAt(0).toUpperCase() + o.slice(1) + '</button>'; }).join('') + '</div>' +
      '<div style="height:16px"></div>' +
      proLock('Custom App Icon', '<button class="icon-row" data-action="icon"><span class="box">' + ic(c.icon ? 'check' : 'add') + '</span><span class="t">App Launcher Icon (PNG)<small>' + (c.icon ? 'Icon selected (demo)' : 'Tap to choose from gallery') + '</small></span></button>') +
      '<div class="sec">' + ic('shield') + 'Android Permissions</div>' +
      PERMS.map(function (pm) {
        var locked = !pm[3] && !S.pro;
        return toggle('perm:' + pm[0], pm[1], pm[2], c.perms.indexOf(pm[0]) >= 0, locked);
      }).join('') +
      '<div style="height:20px"></div><button class="btn block" data-action="proceed" style="padding:16px">' + ic('build') + 'Proceed to Export</button></div></div>';
  }
  function readCfg() {
    var c = cur().cfg;
    c.appName = ($('#b-name').value.trim() || c.appName);
    if (S.pro && $('#b-pkg')) c.pkg = ($('#b-pkg').value.trim() || c.pkg);
    c.vName = ($('#b-vn').value.trim() || c.vName);
    c.vCode = parseInt($('#b-vc').value, 10) || c.vCode;
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(c.pkg)) { toast('Invalid package name. Use lowercase letters, e.g. com.mycompany.myapp', 'err'); return false; }
    return true;
  }

  /* ---------- export ---------- */
  function vExport() {
    var p = cur(), c = p.cfg;
    var head = bar('Export & Build') + '<div class="scroll"><div class="pad" style="padding-bottom:28px"><div class="card sum"><h2>' + esc(p.name) + '</h2><p>' + esc(c.pkg) + ' · v' + esc(c.vName) + ' (' + c.vCode + ')</p><span class="stat">' + ic('file') + Object.keys(p.files).length + ' files</span> <span class="stat">' + ic('archive') + fmt(bytes(p)) + '</span></div>';
    if (!EX.running) {
      return head +
        '<button class="card opt" data-action="exportZip"><span class="ic" style="background:rgba(34,197,94,.15);color:var(--ok)">' + ic('archive') + '</span><span class="t"><b>Export Web ZIP Bundle</b><span class="badge" style="background:rgba(34,197,94,.2);color:var(--ok)">FREE</span><p>Package project for web hosting or manual compilation</p></span></button>' +
        '<button class="card opt" data-action="exportAndroid"><span class="ic" style="background:rgba(56,189,248,.15);color:var(--acc)">' + ic('android') + '</span><span class="t"><b>Export Android Project</b><span class="badge" style="background:rgba(56,189,248,.2);color:var(--acc)">PRO</span><p>Android Studio project (Kotlin + WebView) with your app settings, plus a GitHub Actions workflow that builds the APK.</p></span>' + (S.pro ? '' : ic('lock', 'ico')) + '</button>' +
        '</div></div>';
    }
    return head + '<div style="font-size:13px;font-weight:500;color:' + (EX.done ? 'var(--ok)' : 'var(--acc)') + ';margin-bottom:8px">' + (EX.done ? 'Export complete (demo)' : 'Exporting...') + '</div><div class="prog"><i style="width:' + EX.pct + '%"></i></div>' +
      '<div class="term" id="term">' + EX.lines.map(function (l) { return '<div class="' + (l.charAt(0) === '✅' ? 'ok' : '') + '">' + esc(l) + '</div>'; }).join('') + '</div>' +
      (EX.done ? '<div class="done"><b>Export successful!</b><code>' + esc(EX.name) + '</code><div class="row"><button class="btn sm" data-action="fakeShare">Share / Save</button><button class="btn ghost sm" data-action="newExport">New Export</button></div></div>' : '') +
      '</div></div>';
  }
  var exTimers = [];
  function runExport(kind) {
    var p = cur(), c = p.cfg, safe = function (s) { return s.trim().replace(/[^A-Za-z0-9._-]+/g, '_'); };
    EX = { running: true, done: false, lines: [], pct: 0, kind: kind, name: kind === 'zip' ? safe(p.name) + '_web.zip' : safe(c.appName) + '_android_project.zip' };
    var steps = kind === 'zip'
      ? ['📦 Packaging web project bundle...', '📂 Source: ' + Object.keys(p.files).length + ' files', '🗜️  Creating ZIP archive...']
      : ['🚀 Generating Android (Kotlin + WebView) project', '   App: ' + c.appName, '   Package: ' + c.pkg + '  v' + c.vName + ' (' + c.vCode + ')', '📝 Writing Gradle & manifest files...', '📂 Copying web files into app/src/main/assets/www ...', '🗜️  Creating ZIP archive...'];
    steps.push('✅ Done: ' + EX.name, 'ℹ️  Demo only - no file is created in this browser mock-up.');
    render();
    steps.forEach(function (line, i) {
      exTimers.push(setTimeout(function () {
        if (S.route.name !== 'export') return;
        EX.lines.push(line); EX.pct = Math.round(((i + 1) / steps.length) * 100);
        if (i === steps.length - 1) EX.done = true;
        render(); var t = $('#term'); if (t) t.scrollTop = t.scrollHeight;
      }, 450 * (i + 1)));
    });
  }

  /* ---------- paywall ---------- */
  function vPaywall() {
    if (S.pro) {
      return bar('OmniWeb Pro') + '<div class="proact"><div class="medal">' + ic('star') + '</div><h2>Pro Active!</h2><p>' + esc(S.proLabel) + '</p><div style="height:24px"></div><button class="btn ghost" data-action="resetPro">Reset Pro (demo)</button></div>';
    }
    var bens = [['app', 'Custom Package Name', 'Set your own com.yourname.app ID'], ['palette', 'Custom App Icons', 'Upload and inject launcher icons'], ['shield', 'Advanced Permissions', 'Camera, location, microphone, storage'], ['folder', 'Unlimited Projects', 'No project count restrictions'], ['android', 'Android Project Export', 'Buildable Android Studio project + APK workflow']];
    return bar('Upgrade to Pro') + '<div class="scroll"><div class="pad" style="padding:16px 20px 40px">' +
      '<div class="hero">' + ic('star') + '<h2>Unlock OmniWeb Pro</h2><p>Everything you need to build and publish professional Android apps from your web projects.</p></div>' +
      '<div class="h3">Pro Benefits</div>' + bens.map(function (b) { return '<div class="ben"><span class="bi">' + ic(b[0]) + '</span><div><b>' + b[1] + '</b><span>' + b[2] + '</span></div>' + ic('check', 'ico ck') + '</div>'; }).join('') +
      '<div class="h3">Choose Your Plan</div>' +
      '<button class="plan" data-action="buy" data-plan="month"><span class="t"><b>Monthly</b><small>/month</small></span><span class="pr">$4.99</span></button>' +
      '<button class="plan pop" data-action="buy" data-plan="life"><span class="t"><b>Lifetime<span class="tag">BEST VALUE</span></b><small>one-time</small></span><span class="pr">$19.99</span></button>' +
      '<div class="h3" style="font-size:14px;margin-top:20px">Have a Promo Code?</div><div class="row" style="align-items:center"><input class="input" id="promo" placeholder="Enter code (try DEMO)" style="text-transform:uppercase" aria-label="Promo code"><button class="btn" data-action="promo" style="flex:none">Apply</button></div>' +
      '<div class="adbox"><div class="ben" style="margin-bottom:12px"><span class="bi">' + ic('video') + '</span><div><b>Watch an Ad, Get Pro Free</b><span>Unlock all Pro features for 24 hours</span></div></div><button class="btn ghost block" data-action="ad">' + ic('play') + 'Watch Ad</button></div>' +
      '<div style="text-align:center;margin-top:16px"><button class="btn text" data-action="restore">Restore Purchases</button></div>' +
      '<p style="text-align:center;font-size:11px;color:var(--dim);margin-top:8px">Demo: no real payment happens here.</p></div></div>';
  }
  function setPro(label, msg) { S.pro = true; S.proLabel = label; closeOverlay(); render(); toast(msg, 'ok'); }

  /* ---------- events ---------- */
  document.addEventListener('click', function (e) {
    var sh = e.target.closest('[data-sheet]');
    if (sh) { var items = $('#overlay').firstChild._items; closeOverlay(); items[+sh.dataset.sheet].run(); return; }
    var dl = e.target.closest('[data-dlg]');
    if (dl) { var acts = $('#overlay').firstChild._acts, a = acts[+dl.dataset.dlg]; if (a.run) { a.run(); if ($('#overlay').firstChild && $('#overlay').firstChild._acts === acts) closeOverlay(); } else closeOverlay(); return; }
    var t = e.target.closest('[data-action]'); if (!t) return;
    var act = t.dataset.action, id = +t.dataset.id, p;
    if (act === 'scrim') { if (e.target === t) closeOverlay(); return; }
    var A = {
      toggleView: function () { S.view = S.view === 'grid' ? 'list' : 'grid'; render(); },
      create: createMenu,
      paywall: function () { nav('paywall'); },
      openEditor: function () { ED.file = proj(id).main; ED.explorer = false; nav('editor', { id: id }); },
      projMenu: function () { projMenu(proj(id)); },
      back: function () { if (S.route.name === 'editor') saveNow(true); exTimers.forEach(clearTimeout); EX = { running: false, lines: [] }; back(); },
      toggleExplorer: function () { saveNow(true); ED.explorer = !ED.explorer; render(); },
      find: findDlg,
      save: function () { saveNow(false); },
      edMenu: function () {
        saveNow(true); var pr = cur();
        sheet([{ icon: 'play', label: 'Live Preview', run: function () { nav('preview', { id: pr.id }); } }, { icon: 'build', label: 'Build / Export', run: function () { nav('builder', { id: pr.id }); } }]);
      },
      snip: function () { insertAtCursor(SNIPS[+t.dataset.i][1]); },
      openFile: function () { saveNow(true); ED.file = t.dataset.name; render(); },
      newFile: function () {
        promptDlg('New File', 'File name (e.g., about.html)', '', 'Create', function (v) {
          var pr = cur(); if (pr.files[v] != null) { toast(v + ' already exists', 'err'); return; }
          if (/[\\]|\.\./.test(v)) { toast('Invalid file name', 'err'); return; }
          saveNow(true); pr.files[v] = ''; ED.file = v; render(); toast('Created ' + v, 'ok');
        });
      },
      delFile: function () {
        var n = t.dataset.name; e.stopPropagation();
        dialog({ title: 'Delete File', text: 'Delete ' + n + '?', actions: [{ label: 'Cancel' }, { label: 'Delete', danger: true, run: function () { var pr = cur(); delete pr.files[n]; if (ED.file === n) ED.file = pr.main; render(); toast('File deleted', 'ok'); } }] });
      },
      device: function () { PV.device = t.dataset.id; render(); },
      net: function () { PV.online = !PV.online; render(); },
      console: function () { PV.console = !PV.console; render(); },
      reload: function () { PV.logs = []; render(); },
      full: function () { PV.full = !PV.full; render(); },
      clearLogs: function () { PV.logs = []; renderLogs(); },
      tog: function () {
        var c = cur().cfg, k = t.dataset.key;
        if (k.indexOf('perm:') === 0) { var n = k.slice(5), i = c.perms.indexOf(n); if (i >= 0) { if (n !== 'INTERNET') c.perms.splice(i, 1); } else c.perms.push(n); }
        else c[k] = !c[k];
        keepScroll(render);
      },
      color: function () { cur().cfg.color = t.dataset.c; keepScroll(render); },
      orient: function () { cur().cfg.orient = t.dataset.o; keepScroll(render); },
      icon: function () { cur().cfg.icon = !cur().cfg.icon; keepScroll(render); },
      saveCfg: function () { if (readCfg()) toast('Build configuration saved', 'ok'); },
      proceed: function () { if (readCfg()) { EX = { running: false, lines: [] }; nav('export', { id: S.route.id }); } },
      exportZip: function () { runExport('zip'); },
      exportAndroid: function () { if (!S.pro) nav('paywall'); else runExport('android'); },
      newExport: function () { EX = { running: false, lines: [] }; render(); },
      fakeShare: function () { toast('Demo only - the real app opens the share sheet here', ''); },
      buy: function () { var life = t.dataset.plan === 'life'; setPro(life ? 'You have lifetime access to all Pro features.' : 'Monthly plan active for 30 days.', life ? 'Pro unlocked permanently!' : 'Pro unlocked for 30 days!'); },
      promo: function () { var v = $('#promo').value.trim().toUpperCase(); if (v === 'DEMO') setPro('You have lifetime access to all Pro features.', 'Promo code accepted!'); else toast('Invalid promo code.', 'err'); },
      restore: function () { toast('No previous purchases found.', 'err'); },
      resetPro: function () { S.pro = false; render(); toast('Pro status reset (demo)', ''); },
      ad: function () {
        var left = 3;
        dialog({ title: 'Watching Ad...', body: '<p id="ad-t">Reward will be available in 3 seconds.</p>', actions: [{ label: 'Please wait...' }] });
        var iv = setInterval(function () {
          var el = $('#ad-t'); if (!el) { clearInterval(iv); return; }
          left--; if (left > 0) { el.textContent = 'Reward will be available in ' + left + ' seconds.'; return; }
          clearInterval(iv);
          dialog({ title: 'Ad Complete!', body: '<p>Tap below to unlock Pro features for 24 hours.</p>', actions: [{ label: 'Claim Reward', primary: true, run: function () { setPro('Temporary unlock - expires in 24h.', 'Pro features unlocked for 24 hours!'); } }] });
        }, 1000);
      }
    };
    if (A[act]) A[act]();
  });

  function keepScroll(fn) {
    var sc = $('.scroll'), y = sc ? sc.scrollTop : 0;
    fn(); sc = $('.scroll'); if (sc) sc.scrollTop = y;
  }

  document.addEventListener('keydown', function (e) {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[role=button][data-action]')) { e.preventDefault(); e.target.click(); }
    if (e.key === 'Escape') closeOverlay();
  });

  document.addEventListener('input', function (e) {
    if (e.target.id === 'q') {
      S.q = e.target.value; renderList();
    } else if (e.target.id === 'ta') {
      gutter(); setDirty(true);
      clearTimeout(ED.saveTimer);
      ED.saveTimer = setTimeout(function () { saveNow(true); }, 900);
    }
  });
  document.addEventListener('scroll', function (e) {
    if (e.target && e.target.id === 'ta') $('#gut').scrollTop = e.target.scrollTop;
  }, true);
  document.addEventListener('keydown', function (e) {
    if (e.target.id === 'ta' && e.key === 'Tab') { e.preventDefault(); insertAtCursor('  '); }
  });

  /* the dashboard needs its list drawn after render */
  var baseRender = render;
  render = function () { baseRender(); if (S.route.name === 'dashboard') renderList(); };

  render();
})();
