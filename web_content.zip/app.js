// Engineering Review Quiz v2.9.48 — Formula-to-Question Connections
// Custom questions can be added, edited, and deleted. Starter questions are protected.
// Add Question saves custom questions in localStorage on this device.

// Built-in Blue Book and IPE question bank; source status on each record controls scoring eligibility.
const starterQuestions = [
  {
    "id": "bluebook-001",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Ideal Gas Law / Gas Properties",
    "difficulty": "Intermediate",
    "prompt": "Find the work possess for a helium gas at 20°C.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 1",
    "options": [
      {
        "value": "A",
        "text": "609 kJ/kg"
      },
      {
        "value": "B",
        "text": "168 kJ/kg"
      },
      {
        "value": "C",
        "text": "229 kJ/kg"
      },
      {
        "value": "D",
        "text": "339 kJ/kg"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "R = 8.314/4 = 2.0785 kJ/(kg·K); T = 20 + 273 = 293 K"
    ],
    "formula": "w = RT",
    "substitution": "w = (2.0785 kJ/(kg·K))(293 K) = 609 kJ/kg",
    "calculation": [
      "w = RT = (2.0785 kJ/(kg·K))(293 K) = 609 kJ/kg"
    ],
    "finalAnswer": "A — 609 kJ/kg",
    "concept": "For an ideal gas, specific flow work is Pv = RT. Helium molecular weight is 4 kg/kmol.",
    "shortcutFormula": "w = (Ru/MW)T",
    "shortcut": "Convert Celsius to kelvin, then multiply by the specific gas constant.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: kJ/kg (specific energy/work per unit mass). Keep R in kJ/(kg·K) and temperature in K so the kelvin units cancel."
  },
  {
    "id": "bluebook-002",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Ideal Gas Law / Gas Properties",
    "difficulty": "Intermediate",
    "prompt": "Two kilogram of gas is confined in a 1 m3 tank at 200 kPa and 88°C. What type of gas is in the tank?",
    "source": "Blue Book With Solution VIP.pdf — PDF page 1",
    "options": [
      {
        "value": "A",
        "text": "Helium"
      },
      {
        "value": "B",
        "text": "Ethane"
      },
      {
        "value": "C",
        "text": "Methane"
      },
      {
        "value": "D",
        "text": "Ethene"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "P = 200 kPa; V = 1 m³; m = 2 kg; T = 88 + 273 = 361 K"
    ],
    "formula": "PV = m(Ru/MW)T",
    "substitution": "(200 kPa)(1 m³) = (2 kg)(8.314 kJ/(kmol·K)/MW)(361 K)",
    "calculation": [
      "MW = (2 kg)(8.314 kJ/(kmol·K))(361 K)/[(200 kPa)(1 m³)] ≈ 30 kg/kmol",
      "Molecular weight ≈ 30 kg/kmol corresponds to ethane, C₂H₆."
    ],
    "finalAnswer": "B — Ethane",
    "concept": "Rearrange the ideal-gas equation to find molecular weight, then match it to the gas.",
    "shortcutFormula": "MW = mRuT/(PV)",
    "shortcut": "Use kelvin and absolute pressure; compare the calculated molecular weight with known gas values.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "The calculated molecular weight has units kg/kmol. In PV = m(Ru/MW)T, keep pressure in kPa, volume in m³, mass in kg, temperature in K, and Ru in kJ/(kmol·K)."
  },
  {
    "id": "bluebook-003",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Ideal Gas Law / Gas Properties",
    "difficulty": "Intermediate",
    "prompt": "Find the enthalpy of Helium if its internal energy is 200 kJ/kg.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 1",
    "options": [
      {
        "value": "A",
        "text": "144 kJ/kg"
      },
      {
        "value": "B",
        "text": "223.42 kJ/kg"
      },
      {
        "value": "C",
        "text": "333.42 kJ/kg"
      },
      {
        "value": "D",
        "text": "168 kJ/kg"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "u = 200 kJ/kg; for helium, k = 1.667"
    ],
    "formula": "h/u = cp/cv = k",
    "substitution": "h = (1.667)(200 kJ/kg)",
    "calculation": [
      "h = (1.667)(200 kJ/kg) = 333.42 kJ/kg (Blue Book value)"
    ],
    "finalAnswer": "C — 333.42 kJ/kg",
    "concept": "For helium, the Blue Book uses the ratio of specific heats k = cp/cv = 1.667, so h/u = k.",
    "shortcutFormula": "h = ku",
    "shortcut": "When k and internal energy are given, multiply them directly.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: kJ/kg. The ratio k is dimensionless, so multiplying it by u in kJ/kg leaves h in kJ/kg."
  },
  {
    "id": "bluebook-004",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Ideal Gas Law / Gas Properties",
    "difficulty": "Intermediate",
    "prompt": "Compute the mass of a 2 m3 propane at 280 kPa and 40°C.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 1",
    "options": [
      {
        "value": "A",
        "text": "6.47 kg"
      },
      {
        "value": "B",
        "text": "5.1 kg"
      },
      {
        "value": "C",
        "text": "10.20 kg"
      },
      {
        "value": "D",
        "text": "9.47 kg"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "P = 280 kPa; V = 2 m³; T = 40 + 273 = 313 K; propane C₃H₈ has MW = 44 kg/kmol"
    ],
    "formula": "PV = m(Ru/MW)T",
    "substitution": "(280 kPa)(2 m³) = m(8.314 kJ/(kmol·K)/44 kg/kmol)(313 K)",
    "calculation": [
      "m = 9.47 kg"
    ],
    "finalAnswer": "D — 9.47 kg",
    "concept": "Use the ideal-gas equation and propane molecular weight, 3(12) + 8(1) = 44 kg/kmol.",
    "shortcutFormula": "m = PVMW/(RuT)",
    "shortcut": "Find molecular weight first, then solve for mass.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: kg. Check that kPa·m³ is consistent with kJ and that the specific gas constant uses kJ/(kg·K)."
  },
  {
    "sourceProblemNumber": 5,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Refrigerant Room Ventilation & Safety",
    "difficulty": "Intermediate",
    "prompt": "Compute the air flow in ft3/min of mechanical ventilation required to exhaust an accumulation of refrigerant due to leaks of the system capable of revolving air from the machinery for a mass of 4 lbs refrigerant.",
    "options": [
      {
        "value": "A",
        "text": "200"
      },
      {
        "value": "B",
        "text": "210"
      },
      {
        "value": "C",
        "text": "220"
      },
      {
        "value": "D",
        "text": "230"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Refrigerant mass G = 4 lb"
    ],
    "formula": "Q=100\\sqrt{G}",
    "formulaReason": "This problem is classified as Refrigerant Room Ventilation & Safety. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q = 100√4",
    "calculation": [
      "Q = 100√G = 100√4 = 200 ft³/min."
    ],
    "finalAnswer": "A — 200 ft³/min",
    "unitCheck": "Result is volumetric flow rate in ft³/min; use G in the unit required by the source relation.",
    "concept": "Ventilation flow for the stated refrigerant-leak method is related to the square root of the refrigerant quantity. The coefficient and units are method-specific.",
    "shortcutFormula": "Q=100\\sqrt{G}",
    "shortcut": "For this particular printed relation, take the square root of the refrigerant mass before multiplying by 100.",
    "commonMistakes": [
      "Do not treat the result as an aperture area.",
      "Do not use the coefficient with a different mass unit."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 5; original PDF page 1; extracted PDF page 7",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 1,
    "sourceExtractedPdfPage": 7,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=7",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q = 100 x VG, ft?/min Q = 100 x V4 = 200 ft? /min",
    "sourceChoicesOriginalOrder": [
      "A. 200",
      "B. 210",
      "C. 220",
      "D. 230"
    ],
    "id": "bluebook-005",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=7"
  },
  {
    "sourceProblemNumber": 6,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Refrigerant Room Ventilation & Safety",
    "difficulty": "Intermediate",
    "prompt": "Compute the free aperture cross section in m3 for the ventilation of a machinery room if the mass of refrigerant is 9 kg.",
    "options": [
      {
        "value": "A",
        "text": "0.314"
      },
      {
        "value": "B",
        "text": "0.414"
      },
      {
        "value": "C",
        "text": "0.514"
      },
      {
        "value": "D",
        "text": "0.614"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Refrigerant mass G = 9 kg"
    ],
    "formula": "F=0.138\\sqrt{G}",
    "formulaReason": "This problem is classified as Refrigerant Room Ventilation & Safety. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "F = 0.138√9",
    "calculation": [
      "F = 0.138√G = 0.138√9 = 0.414 m²."
    ],
    "finalAnswer": "B — 0.414 m²",
    "unitCheck": "The requested quantity is area, so the final unit should be m² (the question transcribed “m³,” which appears dimensionally inconsistent).",
    "concept": "The source uses a prescribed safety-ventilation relation to estimate the required free opening area from the refrigerant quantity.",
    "shortcutFormula": "F=0.138\\sqrt{G}",
    "shortcut": "Evaluate the square root first, then multiply by the source coefficient.",
    "commonMistakes": [
      "Do not confuse an area in m² with a volume in m³.",
      "Confirm the governing safety standard and coefficient before applying the relation outside this review problem."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 6; original PDF page 2; extracted PDF page 8",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 2,
    "sourceExtractedPdfPage": 8,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=8",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: F = 0.138G°5, m2 F = 0.138V9 = 0.414 m2",
    "sourceChoicesOriginalOrder": [
      "A. 0.314",
      "B. 0.414",
      "C. 0.514",
      "D. 0.614"
    ],
    "id": "bluebook-006",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=8"
  },
  {
    "sourceProblemNumber": 7,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Refrigerant Room Ventilation & Pressure Relief",
    "difficulty": "Intermediate",
    "prompt": "A 29.53” x 39.37” pressure vessel contains ammonia with f = 0.041. Compute the minimum required discharge capacity of the relief device in kg/hr.",
    "options": [
      {
        "value": "A",
        "text": "106.71 kg/hr"
      },
      {
        "value": "B",
        "text": "108.71 kg/hr"
      },
      {
        "value": "C",
        "text": "110.71 kg/hr"
      },
      {
        "value": "D",
        "text": "112.71 kg/hr"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Vessel dimensions: 29.53 in × 39.37 in ≈ 0.75 m × 1.00 m",
      "Ammonia factor f = 0.041"
    ],
    "formula": "C=3600fDL",
    "formulaReason": "This problem is classified as Refrigerant Room Ventilation & Pressure Relief. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "C = fDL = 0.041(0.75)(1.00) kg/s; convert kg/s to kg/hr.",
    "calculation": [
      "Convert 29.53 in to about 0.75 m and 39.37 in to about 1.00 m.",
      "C = 0.041(0.75)(1.00) = 0.03075 kg/s.",
      "C = 0.03075(3600) ≈ 110.7 kg/hr."
    ],
    "finalAnswer": "C — 110.71 kg/hr",
    "unitCheck": "The intermediate flow is kg/s; multiplying by 3600 s/hr gives kg/hr.",
    "concept": "The relief-device capacity correlation depends on the stated factor and vessel dimensions. The factor and exact code convention must match the source.",
    "shortcutFormula": "C=3600fDL",
    "shortcut": "Convert all dimensions to meters first; convert a kg/s result to kg/hr by multiplying by 3600.",
    "commonMistakes": [
      "Do not use inches directly in a coefficient that requires meters.",
      "Do not omit the seconds-to-hours conversion."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 7; original PDF page 2; extracted PDF page 9",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 2,
    "sourceExtractedPdfPage": 9,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=9",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: C = fDL,kg/s (D and Lare in meters) C= (22) (2) = 0.03705(3600) = 110.71 kg/hr",
    "sourceChoicesOriginalOrder": [
      "A. 106.71 kg/hr",
      "B. 108.71 kg/hr",
      "C. 110.71 kg/hr",
      "D. 112.71 kg/hr"
    ],
    "id": "bluebook-007",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=9"
  },
  {
    "sourceProblemNumber": 8,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Refrigerant Room Ventilation & Pressure Relief",
    "difficulty": "Intermediate",
    "prompt": "Compute the maximum length of the discharge pipe installed on an outlet of a pressure-relief device in feet for internal pipe diameter of 0.5 inch and rated discharge capacity is 8 lb/min of air. The rated pressure of relief valve is 10 psig.",
    "options": [
      {
        "value": "A",
        "text": "0.286 ft"
      },
      {
        "value": "B",
        "text": "0.386 ft"
      },
      {
        "value": "C",
        "text": "0.486 ft"
      },
      {
        "value": "D",
        "text": "0.586 ft"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Pipe inside diameter = 0.5 in",
      "Rated flow = 8 lb/min of air",
      "Rated valve pressure = 10 psig"
    ],
    "formula": "P_{abs}=P_{gage}+P_{atm}",
    "formulaReason": "This problem is classified as Refrigerant Room Ventilation & Pressure Relief. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "The printed solution OCR appears to use an absolute-pressure conversion but its intermediate pressure does not match the transcribed prompt.",
    "calculation": [
      "The source image transcription includes P_abs = P_gage + P_atm, followed by a discharge-pipe correlation.",
      "The intermediate pressure in the printed work appears inconsistent with the question text; do not score this item until the original source is checked."
    ],
    "finalAnswer": "Source-listed choice A — 0.286 ft (UNVERIFIED)",
    "unitCheck": "Pressure and flow must use the units required by the specific relief-device correlation.",
    "concept": "Pressure-relief discharge piping uses a prescribed correlation with the correct absolute pressure, pipe diameter, flow, and units.",
    "shortcutFormula": "P_{abs}=P_{gage}+P_{atm}",
    "shortcut": "First convert gauge pressure to absolute pressure, then apply the source-specific pipe-length equation.",
    "commonMistakes": [
      "Do not mix gauge and absolute pressure.",
      "Do not use a relief-piping correlation without checking its unit convention."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 8; original PDF page 2; extracted PDF page 10",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 2,
    "sourceExtractedPdfPage": 10,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=10",
    "sourceAnswerStatus": "Question/source solution mismatch: OCR of the printed intermediate pressure does not reconcile with the question statement.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Pays = Pyage + Pam = 16(1.1) + 14.7 = 32.3 psia 245 2 5 Lae _ 923) 05)\" _ 9.286 ft 16C2 16(8)",
    "sourceChoicesOriginalOrder": [
      "A. 0.286 ft",
      "B. 0.386 ft",
      "C. 0.486 ft",
      "D. 0.586 ft"
    ],
    "id": "bluebook-008",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=10"
  },
  {
    "id": "bluebook-009",
    "builtIn": true,
    "subject": "Power Plant Engineering",
    "category": "Thermal Efficiency",
    "difficulty": "Intermediate",
    "prompt": "A thermal power plant has the heat rate of 11,363 Btu/kW-hr. Find the thermal efficiency of the plant.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 2",
    "options": [
      {
        "value": "A",
        "text": "28%"
      },
      {
        "value": "B",
        "text": "30%"
      },
      {
        "value": "C",
        "text": "34%"
      },
      {
        "value": "D",
        "text": "40%"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Heat rate = 11,363 Btu/kW·h; useful energy = 3,412 Btu/kW·h"
    ],
    "formula": "η = 3412/heat rate × 100%",
    "substitution": "η = (3412 Btu/(kW·h))/(11,363 Btu/(kW·h)) × 100%",
    "calculation": [
      "η ≈ 30% (dimensionless ratio expressed as a percentage)"
    ],
    "finalAnswer": "B — 30%",
    "concept": "Thermal efficiency is the equivalent electrical energy output divided by heat supplied per kWh.",
    "shortcutFormula": "η = 3412/HR × 100%",
    "shortcut": "Remember 1 kW·h = 3412 Btu.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Efficiency is dimensionless and is reported as a percentage. Btu/(kW·h) cancels in the ratio of the heat-rate equivalent to the plant heat rate."
  },
  {
    "id": "bluebook-010",
    "builtIn": true,
    "subject": "Fluid Mechanics",
    "category": "Pipe Flow and Head Loss",
    "difficulty": "Intermediate",
    "prompt": "What is the hydraulic gradient of a 1 mile, 17 inches inside diameter pipe when 3300 gal/min of water flow with f = 0.03?",
    "source": "Blue Book With Solution VIP.pdf — PDF page 2",
    "options": [
      {
        "value": "A",
        "text": "0.00714"
      },
      {
        "value": "B",
        "text": "0.00614"
      },
      {
        "value": "C",
        "text": "0.00234"
      },
      {
        "value": "D",
        "text": "0.00187"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "L = 1 mile = 5280 ft; D = 17 in; Q = 3300 gal/min; f = 0.03"
    ],
    "formula": "V = Q/A; hf = f(L/D)(V²/2g) using the Blue Book convention",
    "substitution": "Convert Q to ft³/s and D to ft; V ≈ 6.66 ft/s",
    "calculation": [
      "hf ≈ 37.7 ft",
      "Hydraulic gradient = 37.7 ft / 5280 ft = 0.00714 ft/ft (dimensionless; Blue Book reports 0.00714)"
    ],
    "finalAnswer": "A — 0.00714",
    "concept": "The hydraulic gradient is head loss divided by pipe length. The source uses the stated friction-factor convention.",
    "shortcutFormula": "Hydraulic gradient = hf/L",
    "shortcut": "Calculate velocity, then friction head loss, then divide by pipe length.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "The head loss is in ft; dividing by pipe length in ft gives ft/ft, a dimensionless hydraulic gradient. Keep Q, D, L, and g in a consistent unit system."
  },
  {
    "id": "bluebook-011",
    "builtIn": true,
    "subject": "Fluid Mechanics",
    "category": "Pipe Flow and Head Loss",
    "difficulty": "Intermediate",
    "prompt": "Find the loss of head in the pipe entrance if speed of flow is 10 m/s.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 3",
    "options": [
      {
        "value": "A",
        "text": "5.10 m"
      },
      {
        "value": "B",
        "text": "10.2 m"
      },
      {
        "value": "C",
        "text": "17.4 m"
      },
      {
        "value": "D",
        "text": "2.55 m"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Flow speed v = 10 m/s; entrance-loss coefficient K = 0.5 in the source solution"
    ],
    "formula": "he = K v²/(2g)",
    "substitution": "he = 0.5(10 m/s)²/[2(9.81 m/s²)]",
    "calculation": [
      "he ≈ 2.55 m of head"
    ],
    "finalAnswer": "D — 2.55 m",
    "concept": "Entrance head loss is proportional to velocity head.",
    "shortcutFormula": "he = K v²/(2g)",
    "shortcut": "Square the velocity, multiply by K, then divide by 2g.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: m of head. Since v² has units m²/s² and g has units m/s², v²/g gives metres."
  },
  {
    "id": "bluebook-012",
    "builtIn": true,
    "subject": "Chemical Engineering",
    "category": "Drying Operations",
    "difficulty": "Intermediate",
    "prompt": "Wet material, containing 220% moisture (dry basis), is to be dried at a rate of 1.5 kg/s in a continuous dryer to give a product containing 10% (dry basis). Find the moisture removed in kg/hr.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 3",
    "options": [
      {
        "value": "A",
        "text": "3543.75 kg/hr"
      },
      {
        "value": "B",
        "text": "3513.75 kg/hr"
      },
      {
        "value": "C",
        "text": "3563.75 kg/hr"
      },
      {
        "value": "D",
        "text": "3593.75 kg/hr"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Feed = 1.5 kg/s; initial moisture = 220% dry basis; final moisture = 10% dry basis"
    ],
    "formula": "Dry solids = feed/(1 + initial dry-basis moisture); removed water = initial water − final water",
    "substitution": "Dry solids = (1.5 kg/s)/(1 + 2.2) = 0.46875 kg/s; final water = (0.10)(0.46875 kg/s) = 0.046875 kg/s",
    "calculation": [
      "Initial water = 1.5 kg/s − 0.46875 kg/s = 1.03125 kg/s",
      "Removed water = 1.03125 kg/s − 0.046875 kg/s = 0.984375 kg/s",
      "0.984375 kg/s × 3600 s/hr = 3543.75 kg/hr"
    ],
    "finalAnswer": "A — 3543.75 kg/hr",
    "concept": "Dry-basis moisture is water mass divided by dry-solid mass. Dry solids remain constant through drying.",
    "shortcutFormula": "Moisture removed = (initial water − final water) × 3600",
    "shortcut": "Find dry solids first; use that same dry-solid mass for the final moisture.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: kg/hr. First calculate removed water in kg/s, then multiply by 3600 s/hr."
  },
  {
    "id": "bluebook-013",
    "builtIn": true,
    "subject": "Chemical Engineering",
    "category": "Drying Operations",
    "difficulty": "Intermediate",
    "prompt": "Copra enters a dryer containing 70% moisture and leaves 7% moisture. Find the moisture removed on each pound of solid in the final product.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 3",
    "options": [
      {
        "value": "A",
        "text": "6.258 lbs"
      },
      {
        "value": "B",
        "text": "1.258 lbs"
      },
      {
        "value": "C",
        "text": "4.258 lbs"
      },
      {
        "value": "D",
        "text": "2.258 lbs"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Take 1 lb of final dry solid as the basis; initial moisture = 70%; final moisture = 7%"
    ],
    "formula": "Moisture on dry basis = x/(1−x)",
    "substitution": "Initial water per dry solid = 0.70/0.30 = 2.333 lb water/lb dry solid; final water = 0.07/0.93 = 0.07527 lb water/lb dry solid",
    "calculation": [
      "Water removed = 2.333 − 0.07527 = 2.258 lb water/lb dry solid"
    ],
    "finalAnswer": "D — 2.258 lb",
    "concept": "Convert wet-basis moisture percentages into water-to-dry-solid ratios, then subtract.",
    "shortcutFormula": "Xdb = Xwb/(1−Xwb)",
    "shortcut": "Use a 1 lb dry-solid basis to keep the calculation simple.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: lb water per lb dry solid. This is a mass ratio, so it is dimensionless when written as lb/lb, but retain the basis for clarity."
  },
  {
    "id": "bluebook-014",
    "builtIn": true,
    "subject": "Fluid Mechanics",
    "category": "Fluid Statics and Pressure",
    "difficulty": "Intermediate",
    "prompt": "A 1 m x 1.5 m cylindrical tank is full of oil with SG = 0.92. Find the force acting at the bottom of the tank in dynes.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 3",
    "options": [
      {
        "value": "A",
        "text": "106.33 x 10³ dynes"
      },
      {
        "value": "B",
        "text": "106.33 x 10⁴ dynes"
      },
      {
        "value": "C",
        "text": "106.33 x 10⁵ dynes"
      },
      {
        "value": "D",
        "text": "106.33 x 10⁶ dynes"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Tank diameter = 1 m; oil depth = 1.5 m; SG = 0.92"
    ],
    "formula": "p = ρgh; F = pA; A = πD²/4",
    "substitution": "ρ = 0.92(1000 kg/m³) = 920 kg/m³; p = (920 kg/m³)(9.81 m/s²)(1.5 m) = 13,537.8 Pa; A = π(1 m)²/4",
    "calculation": [
      "Using the listed pressure and tank base area gives F ≈ 10.63 kN ≈ 1.063 × 10⁹ dynes by direct unit conversion. The Blue Book-listed result is 106.33 × 10⁶ dynes; these differ by a factor of 10, so retain the printed answer separately from the dimensional check."
    ],
    "finalAnswer": "D — 106.33 × 10⁶ dynes",
    "concept": "Bottom force equals hydrostatic pressure at the bottom multiplied by the circular bottom area.",
    "shortcutFormula": "F = ρgh(πD²/4)",
    "shortcut": "Find bottom pressure first, then multiply by tank-bottom area; convert N to dynes using 1 N = 10⁵ dynes.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Force units: Pa × m² = N, and 1 N = 10⁵ dynes. The direct conversion from the shown pressure and area gives about 1.063 × 10⁹ dynes, whereas the Blue Book-listed result is 106.33 × 10⁶ dynes; this discrepancy is flagged rather than silently changing the source answer."
  },
  {
    "id": "bluebook-015",
    "builtIn": true,
    "subject": "Fluid Mechanics",
    "category": "Fluid Statics and Pressure",
    "difficulty": "Intermediate",
    "prompt": "Find the pressure at the 100 fathom depth of water in kPa.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 3",
    "options": [
      {
        "value": "A",
        "text": "1,793.96 kPa"
      },
      {
        "value": "B",
        "text": "1,893.96 kPa"
      },
      {
        "value": "C",
        "text": "1,993.96 kPa"
      },
      {
        "value": "D",
        "text": "1,693.96 kPa"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Depth = 100 fathoms; 1 fathom = 6 ft; water specific weight = 9.81 kN/m³"
    ],
    "formula": "p = ρgh = γh",
    "substitution": "h = 100 fathoms × 6 ft/fathom = 600 ft = 182.88 m; p = (9.81 kN/m³)(182.88 m)",
    "calculation": [
      "p = 1793.96 kN/m² = 1793.96 kPa gauge"
    ],
    "finalAnswer": "A — 1,793.96 kPa",
    "concept": "Hydrostatic gauge pressure equals specific weight multiplied by vertical depth.",
    "shortcutFormula": "p = γh",
    "shortcut": "Convert fathoms to metres before using SI specific weight.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: kPa gauge. γ in kN/m³ multiplied by depth in m gives kN/m² = kPa."
  },
  {
    "id": "bluebook-016",
    "builtIn": true,
    "subject": "Fluid Mechanics",
    "category": "Fluid Statics and Pressure",
    "difficulty": "Intermediate",
    "prompt": "Find the depth in furlong of the ocean (SG = 1.03) if the pressure at the sea bed is 2,032.56 kPa.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 4",
    "options": [
      {
        "value": "A",
        "text": "1"
      },
      {
        "value": "B",
        "text": "2"
      },
      {
        "value": "C",
        "text": "3"
      },
      {
        "value": "D",
        "text": "4"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Ocean SG = 1.03; seabed pressure = 2032.56 kPa; 1 furlong = 220 yd"
    ],
    "formula": "h = p/(SG·γwater)",
    "substitution": "h = (2032.56 kPa)/(1.03 × 9.81 kN/m³)",
    "calculation": [
      "h ≈ 201.15 m ≈ 220 yd = 1 furlong (Blue Book conversion)"
    ],
    "finalAnswer": "A — 1 furlong",
    "concept": "Use the ocean’s specific weight, SG times water’s specific weight, to calculate depth.",
    "shortcutFormula": "h = p/(SG·γwater)",
    "shortcut": "Calculate depth in metres, then convert to yards and furlongs.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: furlong. Convert the computed depth in metres to yards, then compare with 220 yd per furlong."
  },
  {
    "id": "bluebook-017",
    "builtIn": true,
    "subject": "Engineering Fundamentals",
    "category": "Units, Measurement and Mechanics",
    "difficulty": "Intermediate",
    "prompt": "Find the mass of 10 quartz of water.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 4",
    "options": [
      {
        "value": "A",
        "text": "10.46 kg"
      },
      {
        "value": "B",
        "text": "9.46 kg"
      },
      {
        "value": "C",
        "text": "11.46 kg"
      },
      {
        "value": "D",
        "text": "8.46 kg"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Water volume = 10 quarts"
    ],
    "formula": "m = ρV; 1 US quart ≈ 0.946 L",
    "substitution": "V = 10 qt × 0.946 L/qt = 9.46 L = 0.00946 m³; m = (1000 kg/m³)(0.00946 m³)",
    "calculation": [
      "m = 9.46 kg"
    ],
    "finalAnswer": "B — 9.46 kg",
    "concept": "For water, density is approximately 1 kg/L, so litres and kilograms have nearly the same numerical value.",
    "shortcutFormula": "m ≈ V in litres (for water)",
    "shortcut": "Convert quarts to litres, then use 1 kg/L.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: kg. Water density in kg/m³ multiplied by volume in m³ gives mass in kg."
  },
  {
    "id": "bluebook-018",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Ideal Gas Law / Gas Properties",
    "difficulty": "Intermediate",
    "prompt": "Find the mass of carbon dioxide having a pressure of 20 psia at 200°F with 10 ft 3 volume.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 4",
    "options": [
      {
        "value": "A",
        "text": "1.04 lbs"
      },
      {
        "value": "B",
        "text": "1.14 lbs"
      },
      {
        "value": "C",
        "text": "1.24 lbs"
      },
      {
        "value": "D",
        "text": "1.34 lbs"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "CO₂: P = 20 psia; T = 200°F; V = 10 ft³; MW = 44"
    ],
    "formula": "PV = m(Ru/MW)T",
    "substitution": "Use P = 20 psia, V = 10 ft³, T = 200°F + 459.67 = 659.67°R, and a consistent CO₂ gas constant in PV = mRT.",
    "calculation": [
      "m = 1.24 lb (Blue Book answer; preserve absolute pressure and temperature units)"
    ],
    "finalAnswer": "C — 1.24 lb",
    "concept": "Use the ideal-gas law with CO₂ molecular weight and absolute units.",
    "shortcutFormula": "m = PVMW/(RuT)",
    "shortcut": "Convert °F to °R by adding 460 and keep pressure in psia.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: lb. Use absolute pressure (psia), absolute temperature (°R), and a gas constant consistent with English units to obtain mass in lbm."
  },
  {
    "id": "bluebook-019",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Steam Properties",
    "difficulty": "Intermediate",
    "prompt": "Find the heat needed to raise the temperature of water from 30°C to 100°C with 60% quality. Consider an atmospheric pressure of 101.325 kPa. Use the approximate enthalpy formula of liquid.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 4",
    "options": [
      {
        "value": "A",
        "text": "293.09 kJ/kg"
      },
      {
        "value": "B",
        "text": "1,772.90 kJ/kg"
      },
      {
        "value": "C",
        "text": "1,547.90 kJ/kg"
      },
      {
        "value": "D",
        "text": "1,647.29 kJ/kg"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Water heated from 30°C to 100°C; final quality x = 0.60; atmospheric pressure"
    ],
    "formula": "Q = h₂ − h₁; h₁ ≈ cpT; h₂ = hf + xhfg",
    "substitution": "h₁ ≈ (4.187 kJ/(kg·K))(30 K) = 125.6 kJ/kg; h₂ = 418.7 kJ/kg + 0.60(2257 kJ/kg) = 1772.9 kJ/kg",
    "calculation": [
      "Q = h₂ − h₁ = 1772.9 kJ/kg − 125.6 kJ/kg = 1647.29 kJ/kg"
    ],
    "finalAnswer": "D — 1,647.29 kJ/kg",
    "concept": "Heat added equals final specific enthalpy minus initial specific enthalpy. The final state is a saturated mixture.",
    "shortcutFormula": "Q = (hf + xhfg) − h at 30°C",
    "shortcut": "Calculate final mixture enthalpy, then subtract the initial liquid enthalpy.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: kJ/kg. Both enthalpies are specific enthalpy values, so their difference is heat added per unit mass."
  },
  {
    "id": "bluebook-020",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Steam Properties",
    "difficulty": "Intermediate",
    "prompt": "Find the enthalpy of water at 212°F and 14.7 psi if the dryness factor is 30%. Use the approximate enthalpy formula of liquid.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 4",
    "options": [
      {
        "value": "A",
        "text": "461 Btu/lb"
      },
      {
        "value": "B",
        "text": "471 Btu/lb"
      },
      {
        "value": "C",
        "text": "481 Btu/lb"
      },
      {
        "value": "D",
        "text": "491 Btu/lb"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "T = 212°F; dryness fraction x = 0.30; use approximate liquid enthalpy formula"
    ],
    "formula": "hf ≈ T − 32 Btu/lb; h = hf + xhfg",
    "substitution": "hf = 212°F − 32 = 180 Btu/lb; hfg ≈ 970 Btu/lb",
    "calculation": [
      "h = 180 Btu/lb + 0.30(970 Btu/lb) = 471 Btu/lb"
    ],
    "finalAnswer": "B — 471 Btu/lb",
    "concept": "Mixture enthalpy equals saturated-liquid enthalpy plus quality times latent enthalpy.",
    "shortcutFormula": "h = hf + xhfg",
    "shortcut": "Quality is a mass fraction of vapor; multiply it by hfg.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: Btu/lb. The approximate liquid enthalpy and latent enthalpy are both specific enthalpies in Btu/lb."
  },
  {
    "id": "bluebook-021",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Compressor Performance",
    "difficulty": "Intermediate",
    "prompt": "An air compressor consumed 1200 kW-hr per day of energy. The electric motor driving the compressor has an efficiency of 80%. If indicated power of compressor is 34 kW, find the mechanical efficiency of the compressor.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 5",
    "options": [
      {
        "value": "A",
        "text": "117.65%"
      },
      {
        "value": "B",
        "text": "75%"
      },
      {
        "value": "C",
        "text": "85%"
      },
      {
        "value": "D",
        "text": "90%"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Energy use = 1200 kWh/day; motor efficiency = 80%; compressor indicated power = 34 kW"
    ],
    "formula": "Pinput = 1200/24; Pshaft = ηmotor Pinput; ηmech = Pindicated/Pshaft",
    "substitution": "Pinput = 1200 kWh/day ÷ 24 h/day = 50 kW; Pshaft = (0.80)(50 kW) = 40 kW; ηmech = 34 kW/40 kW",
    "calculation": [
      "ηmech = 0.85 = 85% (kW cancels in the ratio)"
    ],
    "finalAnswer": "C — 85%",
    "concept": "Convert daily energy to average power, account for motor efficiency, then compare indicated compressor power to shaft power.",
    "shortcutFormula": "ηmech = Pindicated/Pshaft",
    "shortcut": "kWh per day divided by 24 hours gives average kW.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Mechanical efficiency is dimensionless and is reported as %. kW divided by kW cancels; the final value is 0.85 × 100% = 85%."
  },
  {
    "sourceProblemNumber": 22,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Refrigeration Capacity & Performance",
    "difficulty": "Intermediate",
    "prompt": "A refrigeration system consumed 28,800 kW-hr per month of energy. There is 20% of energy lost due to the cooling system of the compressor and the motor efficiency is 90%. If the COP of the system is 6, find the mechanical efficiency of the compressor.",
    "options": [
      {
        "value": "A",
        "text": "43.15 TR"
      },
      {
        "value": "B",
        "text": "46.15 TR"
      },
      {
        "value": "C",
        "text": "49.15 TR"
      },
      {
        "value": "D",
        "text": "41.15 TR"
      }
    ],
    "answer": "C",
    "answerVerified": false,
    "given": [
      "Monthly energy consumption = 28,800 kWh/month",
      "Stated compressor/motor loss details: 20% and motor efficiency 90%",
      "COP = 6"
    ],
    "formula": "Q_L=COP\\,W_c;\\quad TR=Q_L/3.516",
    "formulaReason": "This problem is classified as Refrigeration Capacity & Performance. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Printed solution: 28,800 kWh/month ÷ (30×24 h) = 40 kW; 0.90(40)=36 kW; 36(1−0.20)=28.8 kW; Q_L=6(28.8)=172.8 kW.",
    "calculation": [
      "The source computes an input average of 40 kW, adjusts it to 28.8 kW, then calculates cooling as 6×28.8=172.8 kW.",
      "172.8/3.516 ≈ 49.15 TR, matching choice C.",
      "However, the question asks for mechanical efficiency while the options and solution give tons of refrigeration. The requested quantity and solution do not agree."
    ],
    "finalAnswer": "Source solution reports C — 49.15 TR (UNVERIFIED)",
    "unitCheck": "kW/TR is a capacity conversion; it cannot be a mechanical efficiency.",
    "concept": "COP is cooling effect divided by work input. Tons of refrigeration is a capacity unit, not a mechanical-efficiency percentage.",
    "shortcutFormula": "Q_L=COP\\,W_c;\\quad TR=Q_L/3.516",
    "shortcut": "Before calculating, check that the requested quantity and the answer-choice units agree.",
    "commonMistakes": [
      "Do not report capacity in TR as an efficiency.",
      "Distinguish motor efficiency, compressor mechanical efficiency, COP, and cooling capacity."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 22; original PDF page 5; extracted PDF page 11",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 5,
    "sourceExtractedPdfPage": 11,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=11",
    "sourceAnswerStatus": "Printed solution/result conflicts with the wording: asked for mechanical efficiency, but computed answer is TR.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: _ kW-hr ( 1mo 1day\\ _ Pin = 28,800 mo (5 7) C =) = 40 kw Pyrake = 0.9 (40) = 36 kW Weompressor = 36(1— 0.2) = 28.8 kw RE COP = Ww. RE = COP x Ww, = 6 (28.80 kW) = 172.8 kW = 49.15 TR",
    "sourceChoicesOriginalOrder": [
      "A. 43.15 TR",
      "B. 46.15 TR",
      "C. 49.15 TR",
      "D. 41.15 TR"
    ],
    "id": "bluebook-022",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=11"
  },
  {
    "sourceProblemNumber": 23,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Refrigeration Efficiency & EER",
    "difficulty": "Intermediate",
    "prompt": "A 23 ton refrigeration system has a heat rejected of 100 kW. Find the energy efficiency ratio of the system.",
    "options": [
      {
        "value": "A",
        "text": "13.42"
      },
      {
        "value": "B",
        "text": "14.42"
      },
      {
        "value": "C",
        "text": "15.42"
      },
      {
        "value": "D",
        "text": "16.42"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Refrigeration capacity = 23 TR",
      "Heat rejected = 100 kW"
    ],
    "formula": "Q_H=Q_L+W;\\quad COP=Q_L/W;\\quad EER=3.412\\,COP",
    "formulaReason": "This problem is classified as Refrigeration Efficiency & EER. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q_L = 23(3.516) = 80.868 kW; W = 100 − 80.868 = 19.132 kW.",
    "calculation": [
      "Q_L = 23 TR × 3.516 kW/TR ≈ 80.87 kW.",
      "W = Q_H − Q_L = 100 − 80.87 = 19.13 kW.",
      "COP = Q_L/W ≈ 4.23.",
      "EER = 3.412(COP) ≈ 14.42."
    ],
    "finalAnswer": "B — EER 14.42",
    "unitCheck": "Q and W are in kW; COP is dimensionless; EER uses Btu/h per watt convention.",
    "concept": "For a refrigerator, heat rejected equals heat removed from the cold space plus compressor work. EER is related to COP by the stated unit conversion.",
    "shortcutFormula": "Q_H=Q_L+W;\\quad COP=Q_L/W;\\quad EER=3.412\\,COP",
    "shortcut": "Find compressor power from Q_H−Q_L, then find COP, then multiply COP by 3.412 for EER.",
    "commonMistakes": [
      "Do not set heat rejected equal to cooling capacity.",
      "Do not report COP as EER without conversion."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 23; original PDF page 5; extracted PDF page 12",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 5,
    "sourceExtractedPdfPage": 12,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=12",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Qy = RE+W, 100 = 23(3.516) + W, W, = 19.132 kw cop = 2E = 8G516) _ 4 93 WwW, 19.132 EER = 3.412COP = 3.412(4.23) = 14.42",
    "sourceChoicesOriginalOrder": [
      "A. 13.42",
      "B. 14.42",
      "C. 15.42",
      "D. 16.42"
    ],
    "id": "bluebook-023",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=12"
  },
  {
    "id": "bluebook-024",
    "builtIn": true,
    "subject": "Power Plant Engineering",
    "category": "Diesel Engine Performance",
    "difficulty": "Intermediate",
    "prompt": "A 200 mm x 250 mm, 8-cylinder, 4-stroke diesel engine has a brake power of 150 kW. The mechanical efficiency is 80%. If two of the cylinders were accidentally cut off, what will be the new friction power?",
    "source": "Blue Book With Solution VIP.pdf — PDF page 5",
    "options": [
      {
        "value": "A",
        "text": "31.50 kW"
      },
      {
        "value": "B",
        "text": "33.50 kW"
      },
      {
        "value": "C",
        "text": "35.50 kW"
      },
      {
        "value": "D",
        "text": "37.50 kW"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Brake power = 150 kW; mechanical efficiency = 80%; 8 cylinders; 2 cylinders cut off"
    ],
    "formula": "ηm = BP/IP; FP = IP − BP",
    "substitution": "IP = 150 kW/0.80 = 187.5 kW; FP = 187.5 kW − 150 kW",
    "calculation": [
      "The Blue Book assumes friction power remains unchanged when two cylinders are cut off: FP = 37.50 kW."
    ],
    "finalAnswer": "D — 37.50 kW",
    "concept": "Mechanical efficiency relates brake power to indicated power. The printed solution assumes friction power does not change when cylinders are cut off.",
    "shortcutFormula": "FP = IP − BP",
    "shortcut": "Calculate indicated power first; friction power is the difference between indicated and brake power.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: kW (power). Indicated power, brake power, and friction power must all use the same power unit before subtracting."
  },
  {
    "sourceProblemNumber": 25,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Refrigeration Efficiency & EER",
    "difficulty": "Intermediate",
    "prompt": "If the energy efficiency ratio of the refrigeration system is 12.6, what is the COP of the system?",
    "options": [
      {
        "value": "A",
        "text": "3.69"
      },
      {
        "value": "B",
        "text": "4.23"
      },
      {
        "value": "C",
        "text": "5.92"
      },
      {
        "value": "D",
        "text": "6.83"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "EER = 12.6"
    ],
    "formula": "COP=EER/3.412",
    "formulaReason": "This problem is classified as Refrigeration Efficiency & EER. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "COP = 12.6/3.412",
    "calculation": [
      "COP = EER/3.412 = 12.6/3.412 ≈ 3.69."
    ],
    "finalAnswer": "A — COP ≈ 3.69",
    "unitCheck": "COP has no units.",
    "concept": "COP is dimensionless, while EER is based on cooling Btu/h per watt; the conversion factor is needed between them.",
    "shortcutFormula": "COP=EER/3.412",
    "shortcut": "For an EER given in Btu/h/W, divide by 3.412 to get COP.",
    "commonMistakes": [
      "Do not multiply EER by 3.412.",
      "Use the correct EER unit convention."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 25; original PDF page 6; extracted PDF page 13",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 6,
    "sourceExtractedPdfPage": 13,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=13",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: cop = FR = 8*§ ~ 3.69 3.412 3.412",
    "sourceChoicesOriginalOrder": [
      "A. 3.69",
      "B. 4.23",
      "C. 5.92",
      "D. 6.83"
    ],
    "id": "bluebook-025",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=13"
  },
  {
    "id": "bluebook-026",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Compressor Performance",
    "difficulty": "Intermediate",
    "prompt": "An air compressor has a power of 40 kW at 4% clearance. If the clearance will increase to 7%, what is the new power?",
    "source": "Blue Book With Solution VIP.pdf — PDF page 6",
    "options": [
      {
        "value": "A",
        "text": "70 kW"
      },
      {
        "value": "B",
        "text": "40 kW"
      },
      {
        "value": "C",
        "text": "53 kW"
      },
      {
        "value": "D",
        "text": "60 kW"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Compressor power = 40 kW; clearance changes from 4% to 7%"
    ],
    "formula": "Use the source’s stated assumption: power is unaffected by the clearance change",
    "substitution": "Under the Blue Book’s stated conclusion, no recalculation is applied to the given 40 kW.",
    "calculation": [
      "New power = 40 kW"
    ],
    "finalAnswer": "B — 40 kW",
    "concept": "The printed solution states that the power will not be affected by the change in clearance.",
    "shortcutFormula": "Pnew = Pold (per source solution)",
    "shortcut": "For this item, follow the book’s explicit conclusion rather than introducing additional operating assumptions.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: kW. Under the Blue Book’s stated conclusion, the new power remains equal to the given 40 kW; the question provides no further recalculation model."
  },
  {
    "id": "bluebook-027",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Steam Properties",
    "difficulty": "Intermediate",
    "prompt": "What is the approximate value of temperature of water having enthalpy of 208 Btu/lb?",
    "source": "Blue Book With Solution VIP.pdf — PDF page 6",
    "options": [
      {
        "value": "A",
        "text": "138.67°C"
      },
      {
        "value": "B",
        "text": "115.55°C"
      },
      {
        "value": "C",
        "text": "258.67°C"
      },
      {
        "value": "D",
        "text": "68.67°C"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Enthalpy value = 208 Btu/lb; approximate liquid enthalpy relation used by the Blue Book"
    ],
    "formula": "T(°F) = h + 32",
    "substitution": "T = 208 Btu/lb + 32°F (approximate relation as used in the Blue Book); °C = (240°F − 32) × 5/9",
    "calculation": [
      "T ≈ 115.55°C"
    ],
    "finalAnswer": "B — 115.55°C",
    "concept": "Apply the source’s approximate relation to convert the enthalpy value into Fahrenheit temperature, then convert to Celsius.",
    "shortcutFormula": "°C = (°F−32)×5/9",
    "shortcut": "Add 32 to the given value as shown in the source, then convert °F to °C.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: °C. Convert the approximate Fahrenheit temperature to Celsius using (°F − 32) × 5/9."
  },
  {
    "id": "bluebook-028",
    "builtIn": true,
    "subject": "Engineering Fundamentals",
    "category": "Units, Measurement and Mechanics",
    "difficulty": "Intermediate",
    "prompt": "Convert 750°R to K.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 6",
    "options": [
      {
        "value": "A",
        "text": "390.33 K"
      },
      {
        "value": "B",
        "text": "395.33 K"
      },
      {
        "value": "C",
        "text": "410.33 K"
      },
      {
        "value": "D",
        "text": "416.33 K"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "T = 750°R"
    ],
    "formula": "K = °R × 5/9",
    "substitution": "T = 750 °R × 5 K/(9 °R)",
    "calculation": [
      "T = 416.67 K; the Blue Book’s closest listed choice is D — 416.33 K."
    ],
    "finalAnswer": "D — 416.33 K (closest listed option; calculation gives 416.67 K)",
    "concept": "Rankine and kelvin have the same zero point; convert using the ratio 5/9. The source choice differs slightly from the exact conversion.",
    "shortcutFormula": "K = °R×5/9",
    "shortcut": "Multiply Rankine by 5/9; if using the multiple-choice answer, retain the Blue Book’s listed closest option.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Final unit: K. Rankine-to-kelvin conversion is a temperature-scale conversion; K = °R × 5/9."
  },
  {
    "id": "bluebook-029",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Air Standard Cycles",
    "difficulty": "Intermediate",
    "prompt": "An Otto cycle has a compression ratio of 8. Find the pressure during compression.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 6",
    "options": [
      {
        "value": "A",
        "text": "18.38"
      },
      {
        "value": "B",
        "text": "16.38"
      },
      {
        "value": "C",
        "text": "14.38"
      },
      {
        "value": "D",
        "text": "12.28"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Otto-cycle compression ratio r = 8; k = 1.4"
    ],
    "formula": "P₂/P₁ = rᵏ",
    "substitution": "P₂/P₁ = 8^1.4",
    "calculation": [
      "P₂/P₁ ≈ 18.38 (dimensionless pressure ratio)"
    ],
    "finalAnswer": "A — 18.38 (pressure ratio during compression)",
    "concept": "For isentropic compression of an ideal gas, pressure ratio equals compression ratio raised to k. The result is a ratio, not an absolute pressure.",
    "shortcutFormula": "P₂/P₁ = rᵏ",
    "shortcut": "Raise the compression ratio to 1.4; no initial pressure is given to calculate absolute pressure.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "P₂/P₁ is a pressure ratio and is dimensionless. This gives the ratio during compression, not an absolute pressure unless P₁ is also known."
  },
  {
    "id": "bluebook-030",
    "builtIn": true,
    "subject": "Thermodynamics",
    "category": "Air Standard Cycles",
    "difficulty": "Intermediate",
    "prompt": "A diesel cycle has a cut off ratio of 2.5 and expansion ratio of 4. Find the clearance of the cycle.",
    "source": "Blue Book With Solution VIP.pdf — PDF page 6",
    "options": [
      {
        "value": "A",
        "text": "9.11%"
      },
      {
        "value": "B",
        "text": "5.55%"
      },
      {
        "value": "C",
        "text": "11.11%"
      },
      {
        "value": "D",
        "text": "15.15%"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Cutoff ratio rc = 2.5; expansion ratio re = 4"
    ],
    "formula": "Compression ratio r = rc·re; clearance ratio C = 1/(r−1)",
    "substitution": "r = 2.5 × 4 = 10; C = 1/(10 − 1) = 0.1111",
    "calculation": [
      "C = 0.1111 × 100% = 11.11%"
    ],
    "finalAnswer": "C — 11.11%",
    "concept": "The source first calculates compression ratio from cutoff and expansion ratios, then computes clearance ratio.",
    "shortcutFormula": "C = 1/(r−1) × 100%",
    "shortcut": "Multiply the two given ratios, subtract 1, then take the reciprocal and convert to percent.",
    "sourceAnswerStatus": "Answer follows the Blue Book printed worked solution.",
    "sourceSolutionStatus": "Clean step-by-step explanation prepared from the Blue Book printed solution.",
    "independentSolutionStatus": "Any additional clarification is explanatory; the Blue Book answer is retained.",
    "unitCheck": "Clearance ratio is dimensionless and is reported as a percentage. Convert 0.1111 to 11.11%."
  },
  {
    "id": "ipe-aircon-001",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Psychrometrics - Specific Volume",
    "difficulty": "Intermediate",
    "prompt": "Calculate the specific volume of an air-vapor mixture in cubic meters per kilogram of dry air when t = 30°C, w = 0.015 kg/kg, and P = 90 kPa.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 1; PDF page(s) 1.",
    "options": [
      {
        "value": "A",
        "text": "0.99 m³/kg"
      },
      {
        "value": "B",
        "text": "0.89 m³/kg"
      },
      {
        "value": "C",
        "text": "0.79 m³/kg"
      },
      {
        "value": "D",
        "text": "0.69 m³/kg"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Dry-bulb temperature, T = 30°C = 303 K",
      "Humidity ratio, w = 0.015 kg water/kg dry air",
      "Total pressure, P = 90 kPa"
    ],
    "formula": "v = R_da T / (P - P_v);  w = 0.622 P_v/(P-P_v)",
    "formulaReason": "The humidity ratio gives the water-vapor partial pressure. The dry-air partial pressure is P-P_v, and the specific volume is expressed per kilogram of dry air.",
    "derivation": "Rearrange w = 0.622 P_v/(P-P_v): P_v = wP/(0.622+w). Then use the ideal-gas relation for dry air.",
    "substitution": "P_v = (0.015)(90)/(0.622+0.015) ≈ 2.12 kPa\nv = 0.287(303)/(90-2.12)",
    "calculation": [
      "v ≈ 0.990 m³/kg dry air"
    ],
    "finalAnswer": "0.99 m³/kg dry air (A).",
    "unitCheck": "R_da = 0.287 kPa·m³/(kg·K); kPa cancels, leaving m³/kg.",
    "concept": "The water vapor contributes to total pressure, so dry air occupies pressure P-P_v in this relation.",
    "shortcutFormula": "v = R_da T/(P-P_v)",
    "shortcut": "Find vapor partial pressure first, then use the dry-air partial pressure in the denominator.",
    "commonMistakes": [
      "Do not use total pressure in the ideal-gas denominator after separately accounting for water vapor.",
      "Convert Celsius to kelvin."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 1,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=1"
  },
  {
    "id": "ipe-aircon-002",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Psychrometrics - Humidity Ratio",
    "difficulty": "Intermediate",
    "prompt": "Compute the humidity ratio of air at 62 percent relative humidity and 34°C when barometric pressure is 101.325 kPa.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 2; PDF page(s) 1-2.",
    "options": [
      {
        "value": "A",
        "text": "0.021 kg vapor/kg dry air"
      },
      {
        "value": "B",
        "text": "0.031 kg vapor/kg dry air"
      },
      {
        "value": "C",
        "text": "0.041 kg vapor/kg dry air"
      },
      {
        "value": "D",
        "text": "0.051 kg vapor/kg dry air"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Relative humidity, φ = 0.62",
      "Dry-bulb temperature = 34°C",
      "Barometric pressure, P = 101.325 kPa",
      "Saturation vapor pressure at 34°C from the source solution: P_g ≈ 5.32 kPa"
    ],
    "formula": "w = 0.622 P_v/(P-P_v);  P_v = φ P_g",
    "formulaReason": "Relative humidity is the ratio of actual water-vapor partial pressure to saturation vapor pressure at the same temperature.",
    "derivation": "Calculate P_v = φP_g, then substitute into the humidity-ratio equation.",
    "substitution": "P_v = 0.62(5.32) = 3.30 kPa\nw = 0.622(3.30)/(101.325-3.30)",
    "calculation": [
      "w ≈ 0.0209 kg vapor/kg dry air"
    ],
    "finalAnswer": "0.021 kg vapor/kg dry air (A).",
    "unitCheck": "Humidity ratio is a mass ratio; it is not a percentage.",
    "concept": "At a given dry-bulb temperature, relative humidity determines vapor pressure when saturation pressure is known.",
    "shortcutFormula": "w = 0.622 φP_g/(P-φP_g)",
    "shortcut": "Multiply saturation pressure by RH first; then calculate the ratio.",
    "commonMistakes": [
      "Do not insert 62 rather than 0.62.",
      "Do not use saturation pressure as if it were actual vapor pressure."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 1,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=1"
  },
  {
    "id": "ipe-aircon-003",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Psychrometrics - Enthalpy / Wet-Bulb Temperature",
    "difficulty": "Intermediate",
    "prompt": "A sample of air has a dry-bulb temperature of 30°C and a wet-bulb temperature of 25°C. The barometric pressure is 101.325 kPa. Calculate the enthalpy of the air if it is adiabatically saturated.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 3; PDF page(s) 2.",
    "options": [
      {
        "value": "A",
        "text": "75.94 kJ/kg"
      },
      {
        "value": "B",
        "text": "70.94 kJ/kg"
      },
      {
        "value": "C",
        "text": "79.54 kJ/kg"
      },
      {
        "value": "D",
        "text": "74.09 kJ/kg"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Dry-bulb temperature = 30°C",
      "Wet-bulb temperature = 25°C",
      "P = 101.325 kPa",
      "At 25°C, source steam-table values: P_g = 3.17 kPa and h_g = 2547.2 kJ/kg"
    ],
    "formula": "h = c_pa t_wb + w_s h_g;  w_s = 0.622P_g/(P-P_g)",
    "formulaReason": "For the adiabatically saturated state, the source solution uses the saturated humidity ratio at the wet-bulb temperature and evaluates moist-air enthalpy at that state.",
    "derivation": "First calculate the saturation humidity ratio at 25°C. Then use h = c_pa t_wb + w_s h_g.",
    "substitution": "w_s = 0.622(3.17)/(101.325-3.17) ≈ 0.0201 kg/kg\nh ≈ 1.0(25) + 0.0201(2547.2)",
    "calculation": [
      "h ≈ 75.94 kJ/kg dry air"
    ],
    "finalAnswer": "75.94 kJ/kg dry air (A).",
    "unitCheck": "Enthalpy is expressed per kilogram of dry air in the usual psychrometric convention.",
    "concept": "The wet-bulb temperature is used for the saturated state in the source method; do not substitute the dry-bulb temperature into the first term.",
    "shortcutFormula": "h = c_pa t_wb + w_s h_g",
    "shortcut": "Use the wet-bulb temperature to obtain the saturation properties, then compute the enthalpy.",
    "commonMistakes": [
      "Do not mix saturation properties from different temperatures.",
      "Use the steam-table value supplied by the source, not an unrelated value."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 2,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=2"
  },
  {
    "id": "ipe-aircon-004",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Psychrometrics - Moist-Air Enthalpy",
    "difficulty": "Intermediate",
    "prompt": "An air-vapor mixture has a dry-bulb temperature of 30°C and a humidity ratio of 0.015. Calculate the enthalpy at a barometric pressure of 85 kPa.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 4; PDF page(s) 2-3.",
    "options": [
      {
        "value": "A",
        "text": "68.34 kJ/kg"
      },
      {
        "value": "B",
        "text": "54.35 kJ/kg"
      },
      {
        "value": "C",
        "text": "72.45 kJ/kg"
      },
      {
        "value": "D",
        "text": "67.45 kJ/kg"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "t = 30°C",
      "w = 0.015 kg/kg dry air",
      "P = 85 kPa",
      "Source steam-table value h_g at 30°C = 2556.3 kJ/kg"
    ],
    "formula": "h = c_pa t + w h_g",
    "formulaReason": "The question already supplies the humidity ratio, so pressure is not needed in the simple moist-air enthalpy expression used by the source.",
    "derivation": "Substitute the dry-air sensible enthalpy term and the water-vapor enthalpy term.",
    "substitution": "h = (1.0)(30) + (0.015)(2556.3)",
    "calculation": [
      "h = 68.3445 kJ/kg dry air"
    ],
    "finalAnswer": "68.34 kJ/kg dry air (A).",
    "unitCheck": "kJ/kg dry air.",
    "concept": "Moist-air enthalpy is approximately dry-air sensible enthalpy plus humidity ratio times water-vapor enthalpy.",
    "shortcutFormula": "h = c_pa t + w h_g",
    "shortcut": "When w is already known, no humidity-ratio calculation is needed.",
    "commonMistakes": [
      "Do not multiply h_g by relative humidity; use the stated humidity ratio.",
      "Keep the source's steam-table basis consistent."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 2,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=2"
  },
  {
    "id": "ipe-aircon-005",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Air Conditioning - Refrigerating Capacity",
    "difficulty": "Intermediate",
    "prompt": "In an air-conditioning unit, 3.5 m³/s of air at 27°C dry-bulb temperature, 50% relative humidity, and standard atmospheric pressure enters the unit. The leaving condition is 13°C dry-bulb temperature and 90% relative humidity. Using properties from the psychrometric chart, calculate the refrigerating capacity in kW.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 5; PDF page(s) 3.",
    "options": [
      {
        "value": "A",
        "text": "87.57 kW"
      },
      {
        "value": "B",
        "text": "77.57 kW"
      },
      {
        "value": "C",
        "text": "57.87 kW"
      },
      {
        "value": "D",
        "text": "58.77 kW"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Volume flow rate = 3.5 m³/s",
      "Inlet: 27°C DB, 50% RH; source chart h₁ = 55.3 kJ/kg, v₁ = 0.866 m³/kg",
      "Outlet: 13°C DB, 90% RH; source chart h₂ = 34.2 kJ/kg, v₂ = 0.822 m³/kg"
    ],
    "formula": "Q̇ = ṁ_da(h₁-h₂);  ṁ_da ≈ V̇/[(v₁+v₂)/2]",
    "formulaReason": "Cooling capacity is the dry-air mass flow multiplied by the moist-air enthalpy decrease across the unit. The source estimates mass flow using the average specific volume.",
    "derivation": "Average the inlet and outlet specific volumes to estimate dry-air mass flow, then multiply by enthalpy drop.",
    "substitution": "v_avg = (0.866+0.822)/2 = 0.844 m³/kg\nṁ = 3.5/0.844 ≈ 4.15 kg/s\nQ̇ = 4.15(55.3-34.2)",
    "calculation": [
      "Q̇ ≈ 87.57 kW"
    ],
    "finalAnswer": "87.57 kW (A).",
    "unitCheck": "kJ/s = kW.",
    "concept": "Total cooling capacity uses enthalpy difference, so it accounts for both sensible and latent cooling.",
    "shortcutFormula": "Q̇ = ṁ_da Δh",
    "shortcut": "Find air mass flow from volumetric flow and specific volume; then use the total enthalpy change.",
    "commonMistakes": [
      "Do not use only c_pΔT when moisture content changes.",
      "The psychrometric chart values are approximate; retain their stated precision."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 3,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=3"
  },
  {
    "id": "ipe-aircon-006",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Air Conditioning - Mixing / Energy Balance",
    "difficulty": "Intermediate",
    "prompt": "A stream of outdoor air is mixed with a stream of return air in an air-conditioning system operating at 101 kPa. The outdoor-air flow rate is 2 kg/s at 35°C dry-bulb temperature and 25°C wet-bulb temperature. The return-air flow rate is 3 kg/s at 24°C and 50% relative humidity. Determine the enthalpy of the mixture.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 6; PDF page(s) 4.",
    "options": [
      {
        "value": "A",
        "text": "91.56 kJ/kg"
      },
      {
        "value": "B",
        "text": "51.69 kJ/kg"
      },
      {
        "value": "C",
        "text": "69.15 kJ/kg"
      },
      {
        "value": "D",
        "text": "59.16 kJ/kg"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Outdoor air: ṁ₁ = 2 kg/s, source chart h₁ = 75.9 kJ/kg",
      "Return air: ṁ₂ = 3 kg/s, source chart h₂ = 48.0 kJ/kg"
    ],
    "formula": "h₃ = (ṁ₁h₁ + ṁ₂h₂)/(ṁ₁+ṁ₂)",
    "formulaReason": "For adiabatic mixing, total enthalpy flow in equals total enthalpy flow out. The mixture enthalpy is the mass-flow-weighted average.",
    "derivation": "Write an energy balance and divide by total dry-air mass flow.",
    "substitution": "h₃ = [2(75.9)+3(48.0)]/(2+3)",
    "calculation": [
      "h₃ = 59.16 kJ/kg"
    ],
    "finalAnswer": "59.16 kJ/kg dry air (D).",
    "unitCheck": "Enthalpy units remain kJ/kg dry air.",
    "concept": "A mixed-stream property is weighted by mass flow, not by a simple average unless both mass flows are equal.",
    "shortcutFormula": "h_mix = Σ(ṁh)/Σṁ",
    "shortcut": "Multiply each stream enthalpy by its flow rate before adding.",
    "commonMistakes": [
      "Do not reverse the 2 kg/s and 3 kg/s stream rates.",
      "Do not average temperatures instead of enthalpies."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 4,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=4"
  },
  {
    "id": "ipe-aircon-007",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Psychrometrics - Specific Volume",
    "difficulty": "Intermediate",
    "prompt": "What is the specific volume of an air-vapor mixture at 30°C and a relative humidity of 45% at 101.325 kPa?",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 7; PDF page(s) 4-5.",
    "options": [
      {
        "value": "A",
        "text": "0.578 m³/kg"
      },
      {
        "value": "B",
        "text": "0.785 m³/kg"
      },
      {
        "value": "C",
        "text": "0.875 m³/kg"
      },
      {
        "value": "D",
        "text": "0.758 m³/kg"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "T = 30°C = 303 K",
      "RH = 0.45",
      "P = 101.325 kPa",
      "Source saturation pressure at 30°C = 4.24 kPa"
    ],
    "formula": "v = R_da T/(P-P_v);  P_v = φP_g",
    "formulaReason": "Use relative humidity to find vapor partial pressure, then use dry-air partial pressure in the ideal-gas specific-volume relation.",
    "derivation": "Calculate P_v from RH and saturation pressure, then evaluate v.",
    "substitution": "P_v = 0.45(4.24) = 1.91 kPa\nv = 0.287(303)/(101.325-1.91)",
    "calculation": [
      "v ≈ 0.875 m³/kg dry air"
    ],
    "finalAnswer": "0.875 m³/kg dry air (C).",
    "unitCheck": "m³/kg dry air.",
    "concept": "Specific volume per kilogram of dry air uses P-P_v rather than total pressure.",
    "shortcutFormula": "v = R_da T/(P-φP_g)",
    "shortcut": "At moderate RH, calculate vapor pressure before calculating specific volume.",
    "commonMistakes": [
      "Do not leave temperature in Celsius.",
      "Do not use total pressure in place of dry-air partial pressure."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 4,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=4"
  },
  {
    "id": "ipe-aircon-008",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Psychrometrics - Relative Humidity / Dew Point",
    "difficulty": "Intermediate",
    "prompt": "A mixture of dry air and water vapor is at a temperature of 21°C under a pressure of 101 kPa. The dew-point temperature is 15°C. Calculate the relative humidity.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 8; PDF page(s) 5.",
    "options": [
      {
        "value": "A",
        "text": "68.56%"
      },
      {
        "value": "B",
        "text": "65.68%"
      },
      {
        "value": "C",
        "text": "56.68%"
      },
      {
        "value": "D",
        "text": "58.66%"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Dry-bulb temperature = 21°C",
      "Dew point = 15°C",
      "Source saturation pressures: P_g at 15°C = 1.7044 kPa; P_g at 21°C = 2.4861 kPa"
    ],
    "formula": "RH = P_v/P_g(T_db);  P_v = P_g(T_dp)",
    "formulaReason": "At the dew point, the actual vapor pressure equals the saturation vapor pressure at the dew-point temperature.",
    "derivation": "Divide saturation pressure at the dew point by saturation pressure at the dry-bulb temperature.",
    "substitution": "P_v = 1.7044 kPa\nRH = 1.7044/2.4861 = 0.6851",
    "calculation": [
      "RH ≈ 68.5%"
    ],
    "finalAnswer": "68.56% (A, using the source table values and rounding).",
    "unitCheck": "Relative humidity is dimensionless and usually reported as a percentage.",
    "concept": "The dew point gives actual vapor pressure directly; no humidity-ratio calculation is required.",
    "shortcutFormula": "RH = P_g(T_dp)/P_g(T_db)",
    "shortcut": "Use the two saturation-pressure values at their respective temperatures.",
    "commonMistakes": [
      "Do not divide by total atmospheric pressure.",
      "Do not interchange dew-point and dry-bulb saturation pressures."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 5,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=5"
  },
  {
    "id": "ipe-aircon-009",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Psychrometrics - Humidity Ratio from Density",
    "difficulty": "Intermediate",
    "prompt": "The density of air at 35°C and 101 kPa is 1.05 kg/m³. The humidity ratio is:",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 9; PDF page(s) 5. Review note: Unverified: the solution reports P_v=5.6286 kPa, which does not appear consistent with the stated ρ=1.05 kg/m³ at 35°C and 101 kPa.",
    "options": [
      {
        "value": "A",
        "text": "0.036 kg vapor/kg air"
      },
      {
        "value": "B",
        "text": "0.063 kg vapor/kg air"
      },
      {
        "value": "C",
        "text": "0.36 kg vapor/kg air"
      },
      {
        "value": "D",
        "text": "0.63 kg vapor/kg air"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "ρ = 1.05 kg/m³",
      "T = 35°C = 308 K",
      "P = 101 kPa"
    ],
    "formula": "w = 0.622 P_v/(P-P_v)",
    "formulaReason": "The humidity ratio requires the water-vapor partial pressure. The printed solution reports P_v = 5.6286 kPa, but that value appears inconsistent with the stated mixture density under the ideal-gas density relation.",
    "derivation": "The source computes w from its reported vapor pressure. Because the intermediate pressure is inconsistent with the stated density when independently checked, do not treat the source key as verified.",
    "substitution": "Printed source intermediate: P_v = 5.6286 kPa\nPrinted source calculation: w = 0.622(5.6286)/(101.325-5.6286)",
    "calculation": [
      "Printed source result: w ≈ 0.0366 kg/kg"
    ],
    "finalAnswer": "0.036 kg vapor/kg dry air (A, as printed; NOT VERIFIED).",
    "unitCheck": "Partial-pressure and density consistency needs rechecking before using this item for scored exams.",
    "concept": "This problem needs the moist-air density relation solved consistently for composition; a simple shortcut can give a conflicting result.",
    "shortcutFormula": "w = 0.622 P_v/(P-P_v)",
    "shortcut": "Check the intermediate vapor pressure against the stated density before accepting the answer.",
    "commonMistakes": [
      "Do not mark this answer as verified without recalculating the density equation.",
      "The scan's printed key is preserved, not silently corrected."
    ],
    "sourceAnswerStatus": "Printed answer retained; marked unverified pending source discrepancy review.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 5,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=5"
  },
  {
    "id": "ipe-aircon-010",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Air Conditioning - Sensible Heat Ratio",
    "difficulty": "Intermediate",
    "prompt": "If the sensible heat ratio is 0.80 and the cooling load is 100 kW, what is the amount of sensible heating?",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 10; PDF page(s) 6.",
    "options": [
      {
        "value": "A",
        "text": "80 kW"
      },
      {
        "value": "B",
        "text": "60 kW"
      },
      {
        "value": "C",
        "text": "126 kW"
      },
      {
        "value": "D",
        "text": "100 kW"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "SHR = 0.80",
      "Total cooling load = 100 kW"
    ],
    "formula": "SHR = Q̇_s/Q̇_total",
    "formulaReason": "The sensible heat ratio is sensible load divided by total load. Solve for sensible load by multiplying SHR by total load.",
    "derivation": "Rearrange SHR = Q̇_s/Q̇_total to Q̇_s = SHR·Q̇_total.",
    "substitution": "Q̇_s = 0.80(100 kW)",
    "calculation": [
      "Q̇_s = 80 kW"
    ],
    "finalAnswer": "80 kW (A).",
    "unitCheck": "Both loads are powers, so the result is in kW.",
    "concept": "SHR describes the fraction of total cooling load that is sensible rather than latent.",
    "shortcutFormula": "Q̇_s = SHR·Q̇_total",
    "shortcut": "Multiply the total cooling load by the sensible heat ratio.",
    "commonMistakes": [
      "Do not divide total load by SHR.",
      "The source says “sensible heating”; the calculation is for sensible heat load."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 6,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=6"
  },
  {
    "id": "ipe-aircon-011",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Psychrometrics - Mass of Water Vapor",
    "difficulty": "Intermediate",
    "prompt": "A 4 m × 4 m × 4 m room has a relative humidity of 80%. The pressure in the room is 120 kPa and the temperature is 35°C (P_g = 5.628 kPa). What is the mass of vapor in the room? Use R_vapor = 0.4615 kN·m/(kg·K).",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 11; PDF page(s) 6.",
    "options": [
      {
        "value": "A",
        "text": "2.03 kg"
      },
      {
        "value": "B",
        "text": "2.30 kg"
      },
      {
        "value": "C",
        "text": "4.03 kg"
      },
      {
        "value": "D",
        "text": "5.03 kg"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Room volume = 64 m³",
      "RH = 0.80",
      "T = 308 K",
      "P_g at 35°C = 5.628 kPa",
      "R_v = 0.4615 kPa·m³/(kg·K)"
    ],
    "formula": "P_v V = m_v R_v T;  P_v = RH·P_g",
    "formulaReason": "The vapor partial pressure is the relative humidity times saturation pressure. Treat the water vapor as an ideal gas.",
    "derivation": "Find P_v, then rearrange the vapor ideal-gas equation for mass.",
    "substitution": "P_v = 0.80(5.628) = 4.5024 kPa\nm_v = P_v V/(R_v T) = 4.5024(64)/[0.4615(308)]",
    "calculation": [
      "m_v ≈ 2.027 kg"
    ],
    "finalAnswer": "2.03 kg of water vapor (A).",
    "unitCheck": "kPa·m³ divided by kPa·m³/kg gives kg.",
    "concept": "Use the partial pressure of vapor, not the room's total pressure, in the vapor ideal-gas relation.",
    "shortcutFormula": "m_v = RH·P_g·V/(R_v T)",
    "shortcut": "Calculate vapor partial pressure first, then solve for mass.",
    "commonMistakes": [
      "Convert 35°C to 308 K.",
      "Use water-vapor gas constant, not the dry-air gas constant."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 6,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=6"
  },
  {
    "id": "ipe-aircon-012",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Air Conditioning - Coil Bypass Factor",
    "difficulty": "Intermediate",
    "prompt": "A coil has an inlet temperature of 60°F and an outlet of 90°F. If the mean temperature of the coil is 110°F, find the bypass factor of the coil.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 12; PDF page(s) 6-7.",
    "options": [
      {
        "value": "A",
        "text": "0.20"
      },
      {
        "value": "B",
        "text": "0.30"
      },
      {
        "value": "C",
        "text": "0.40"
      },
      {
        "value": "D",
        "text": "0.50"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Coil inlet air temperature = 60°F",
      "Coil outlet air temperature = 90°F",
      "Mean coil temperature = 110°F"
    ],
    "formula": "BF = (t_mean - t_out)/(t_mean - t_in)",
    "formulaReason": "The source defines the bypass factor as the remaining temperature difference between the mean coil surface and leaving air, relative to the inlet-to-coil temperature difference.",
    "derivation": "Substitute the three temperatures in the source equation; temperature intervals can be in °F because the units cancel.",
    "substitution": "BF = (110-90)/(110-60) = 20/50",
    "calculation": [
      "BF = 0.40"
    ],
    "finalAnswer": "0.40 (C).",
    "unitCheck": "Bypass factor is dimensionless.",
    "concept": "A lower bypass factor indicates the leaving air approaches the coil surface temperature more closely.",
    "shortcutFormula": "BF = (t_mean-t_out)/(t_mean-t_in)",
    "shortcut": "Use the same temperature scale for all three terms.",
    "commonMistakes": [
      "Do not switch the inlet and outlet temperatures.",
      "Do not report 20/50 as 40 without converting to a ratio."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 6,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=6"
  },
  {
    "id": "ipe-aircon-013",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Air Conditioning - Sensible Heat Ratio",
    "difficulty": "Intermediate",
    "prompt": "If the latent and sensible heat loads are 20 kW and 80 kW, respectively, what is the sensible heat ratio?",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 13; PDF page(s) 7.",
    "options": [
      {
        "value": "A",
        "text": "0.80"
      },
      {
        "value": "B",
        "text": "0.60"
      },
      {
        "value": "C",
        "text": "0.70"
      },
      {
        "value": "D",
        "text": "0.90"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Latent heat load = 20 kW",
      "Sensible heat load = 80 kW"
    ],
    "formula": "SHR = Q̇_s/(Q̇_s+Q̇_l)",
    "formulaReason": "Total load is the sum of sensible and latent loads. The ratio is sensible load divided by that total.",
    "derivation": "Add the two loads, then divide the sensible load by the total.",
    "substitution": "Q̇_total = 80+20 = 100 kW\nSHR = 80/100",
    "calculation": [
      "SHR = 0.80"
    ],
    "finalAnswer": "0.80 (A).",
    "unitCheck": "kW cancels, leaving a dimensionless ratio.",
    "concept": "Sensible heat changes dry-bulb temperature; latent heat is associated with moisture change.",
    "shortcutFormula": "SHR = Q̇_s/(Q̇_s+Q̇_l)",
    "shortcut": "Sensible load goes in the numerator; both loads go in the denominator.",
    "commonMistakes": [
      "Do not use latent load alone as the denominator.",
      "Do not swap sensible and latent values."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 7,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=7"
  },
  {
    "id": "ipe-aircon-014",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Air Conditioning - Sensible Cooling Load",
    "difficulty": "Intermediate",
    "prompt": "A room being air-conditioned is held at 25°C dry-bulb temperature and 50% relative humidity. A flow rate of 5 m³/s of supply air at 15°C dry-bulb temperature and 80% RH is delivered to maintain that steady condition at 100 kPa. What is the sensible heat absorbed from the room air in kW?",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 14; PDF page(s) 7.",
    "options": [
      {
        "value": "A",
        "text": "50.8 kW"
      },
      {
        "value": "B",
        "text": "60.8 kW"
      },
      {
        "value": "C",
        "text": "40.5 kW"
      },
      {
        "value": "D",
        "text": "70.9 kW"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Supply volume flow = 5 m³/s",
      "Supply temperature = 15°C = 288 K",
      "Room temperature = 25°C",
      "P = 100 kPa",
      "R_da = 0.287 kPa·m³/(kg·K); c_p ≈ 1.003 kJ/(kg·K)"
    ],
    "formula": "Q̇_s = ṁ c_p (t_room-t_supply);  ṁ ≈ PV̇/(R_da T_supply)",
    "formulaReason": "At steady room conditions, the sensible load is mass flow times specific heat times the room-to-supply dry-bulb temperature difference.",
    "derivation": "Estimate the mass flow from the supply-air ideal-gas relation and then apply the sensible heat equation.",
    "substitution": "ṁ = 100(5)/[0.287(288)] ≈ 6.049 kg/s\nQ̇_s = 6.049(1.003)(25-15)",
    "calculation": [
      "Q̇_s ≈ 60.7 kW, rounded by the source to 60.80 kW"
    ],
    "finalAnswer": "60.8 kW (B).",
    "unitCheck": "kg/s × kJ/(kg·K) × K = kJ/s = kW.",
    "concept": "Sensible load depends on dry-bulb temperature difference; RH affects the moist-air state but is not directly multiplied into this sensible-only equation.",
    "shortcutFormula": "Q̇_s = ṁ c_p ΔT",
    "shortcut": "Use the supply-air flow rate and the room-to-supply temperature difference.",
    "commonMistakes": [
      "Do not use 25-15 in reverse if reporting heat absorbed by the room.",
      "Do not confuse sensible load with total enthalpy load."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 7,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=7"
  },
  {
    "id": "ipe-aircon-015",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Duct Flow - Darcy-Weisbach Pressure Drop",
    "difficulty": "Intermediate",
    "prompt": "Compute the pressure drop of 30°C air flowing with a mean velocity of 8 m/s in a circular sheet-metal duct 300 mm in diameter and 15 m long. Use a friction factor f = 0.02 and air density ρ = 1.1644 kg/m³.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 15; PDF page(s) 8.",
    "options": [
      {
        "value": "A",
        "text": "37.26 Pa"
      },
      {
        "value": "B",
        "text": "25.27 Pa"
      },
      {
        "value": "C",
        "text": "29.34 Pa"
      },
      {
        "value": "D",
        "text": "30.52 Pa"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "f = 0.02",
      "L = 15 m",
      "V = 8 m/s",
      "D = 0.300 m",
      "ρ = 1.1644 kg/m³"
    ],
    "formula": "ΔP = f(L/D)(ρV²/2)",
    "formulaReason": "The Darcy-Weisbach relation expresses friction pressure loss along a straight duct.",
    "derivation": "Convert diameter to meters and substitute the length-to-diameter ratio and velocity pressure.",
    "substitution": "ΔP = 0.02(15/0.30)[1.1644(8²)/2]",
    "calculation": [
      "ΔP = 37.26 Pa"
    ],
    "finalAnswer": "37.26 Pa (A).",
    "unitCheck": "ρV² has units kg/(m·s²) = Pa.",
    "concept": "Pressure loss increases with duct length, friction factor, density, and velocity squared; it decreases as diameter increases.",
    "shortcutFormula": "ΔP = f(L/D)ρV²/2",
    "shortcut": "Compute L/D first, then the dynamic pressure ρV²/2.",
    "commonMistakes": [
      "Convert 300 mm to 0.300 m.",
      "Do not omit the factor of one-half."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 8,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=8"
  },
  {
    "id": "ipe-aircon-016",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Duct Flow - Solve Velocity from Pressure Drop",
    "difficulty": "Intermediate",
    "prompt": "A pressure difference of 350 Pa is available to force 20°C air through a circular sheet-metal duct 450 mm in diameter and 25 m long. At 20°C, ρ = 1.204 kg/m³ and friction factor f = 0.016. Determine the velocity.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 16; PDF page(s) 8.",
    "options": [
      {
        "value": "A",
        "text": "25.57 m/s"
      },
      {
        "value": "B",
        "text": "27.55 m/s"
      },
      {
        "value": "C",
        "text": "28.54 m/s"
      },
      {
        "value": "D",
        "text": "24.85 m/s"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "ΔP = 350 Pa",
      "D = 0.450 m",
      "L = 25 m",
      "ρ = 1.204 kg/m³",
      "f = 0.016"
    ],
    "formula": "ΔP = f(L/D)(ρV²/2);  V = √[2ΔP D/(fLρ)]",
    "formulaReason": "Solve Darcy-Weisbach for V by isolating the squared velocity and taking the square root.",
    "derivation": "Rearrange the pressure-loss equation, then substitute SI values.",
    "substitution": "V = √[2(350)(0.450)/(0.016·25·1.204)]",
    "calculation": [
      "V ≈ 25.57 m/s"
    ],
    "finalAnswer": "25.57 m/s (A).",
    "unitCheck": "The expression inside the square root has units m²/s², so the result is m/s.",
    "concept": "When pressure drop is specified, solve for velocity with the square-root form of Darcy-Weisbach.",
    "shortcutFormula": "V = √[2ΔP D/(fLρ)]",
    "shortcut": "Put all known quantities into the square-root expression before evaluating.",
    "commonMistakes": [
      "Use diameter in meters.",
      "Do not forget the square root."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 8,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=8"
  },
  {
    "id": "ipe-aircon-017",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Duct Flow - Elbow / Equivalent Diameter",
    "difficulty": "Intermediate",
    "prompt": "A duct 0.40 m high and 0.80 m wide is suspended from the ceiling in a corridor and makes a right-angle turn in the horizontal plane. The inner radius is 0.2 m and the outer radius is 1.0 m, measured from the same center. Air velocity is 10 m/s. Compute the pressure drop in the elbow, assuming f = 0.3, ρ = 1.204 kg/m³, and L = 10 m.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 17; PDF page(s) 8-9.",
    "options": [
      {
        "value": "A",
        "text": "341 Pa"
      },
      {
        "value": "B",
        "text": "441 Pa"
      },
      {
        "value": "C",
        "text": "143 Pa"
      },
      {
        "value": "D",
        "text": "144 Pa"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "a = 0.40 m",
      "b = 0.80 m",
      "V = 10 m/s",
      "f = 0.3",
      "ρ = 1.204 kg/m³",
      "L = 10 m"
    ],
    "formula": "D_e = 2ab/(a+b);  ΔP = fLρV²/(2D_e)",
    "formulaReason": "The source uses D_e = 2ab/(a+b) to represent the rectangular duct with an equivalent diameter, then applies the friction-loss equation.",
    "derivation": "Compute the source-defined equivalent diameter before calculating pressure loss.",
    "substitution": "D_e = 2(0.40)(0.80)/(0.40+0.80) = 0.533 m\nΔP = 0.3(10)(10²)(1.204)/[2(0.533)]",
    "calculation": [
      "ΔP ≈ 340.8 Pa"
    ],
    "finalAnswer": "341 Pa (A).",
    "unitCheck": "Pressure drop in pascals.",
    "concept": "Equivalent-diameter approximations depend on the method specified by the reference; use the method expected by this question.",
    "shortcutFormula": "D_e = 2ab/(a+b); ΔP = fLρV²/(2D_e)",
    "shortcut": "Reduce the rectangular dimensions to the source's equivalent diameter first.",
    "commonMistakes": [
      "Do not substitute the duct height or width alone for the equivalent diameter.",
      "This is a source-specific approximation; other duct-design references may use a different equivalent-diameter correlation."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 8,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=8"
  },
  {
    "id": "ipe-aircon-018",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Duct Flow - Rectangular Duct Equivalent Diameter",
    "difficulty": "Intermediate",
    "prompt": "A rectangular duct has dimensions of 0.25 m by 1 m. Determine the equivalent diameter of the duct.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 18; PDF page(s) 9.",
    "options": [
      {
        "value": "A",
        "text": "0.40 m"
      },
      {
        "value": "B",
        "text": "0.80 m"
      },
      {
        "value": "C",
        "text": "0.70 m"
      },
      {
        "value": "D",
        "text": "0.30 m"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "a = 0.25 m",
      "b = 1.00 m"
    ],
    "formula": "D_e = 2ab/(a+b)",
    "formulaReason": "Use the rectangular-duct equivalent-diameter equation provided in the source.",
    "derivation": "Substitute the two side dimensions.",
    "substitution": "D_e = 2(0.25)(1.00)/(0.25+1.00)",
    "calculation": [
      "D_e = 0.40 m"
    ],
    "finalAnswer": "0.40 m (A).",
    "unitCheck": "The result has units of meters.",
    "concept": "The source's equivalent-diameter expression is twice the product of the sides divided by their sum.",
    "shortcutFormula": "D_e = 2ab/(a+b)",
    "shortcut": "Multiply the two sides, double the product, then divide by their sum.",
    "commonMistakes": [
      "Do not use the arithmetic mean of the sides.",
      "Use the same diameter definition as the source when matching its answer key."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 9,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=9"
  },
  {
    "id": "ipe-aircon-019",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Duct Flow - Junction Pressure / Bernoulli Equation",
    "difficulty": "Intermediate",
    "prompt": "A 0.30 m × 0.40 m branch duct leaves a 0.30 m × 0.60 m main duct at an angle of 60°. The air temperature is 20°C. The main-duct flow rate is 2.7 m³/s upstream and the branch-duct flow rate is 1.3 m³/s. What is the pressure downstream in the main duct? The source gives ρ = 1.2041 kg/m³ and upstream main-duct pressure = 250 kPa.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 19; PDF page(s) 9-10. Review note: Unverified: scanned prompt appears to say 250 kPa, while the provided calculation and choices only make sense if upstream pressure is 250 Pa.",
    "options": [
      {
        "value": "A",
        "text": "346 Pa"
      },
      {
        "value": "B",
        "text": "436 Pa"
      },
      {
        "value": "C",
        "text": "634 Pa"
      },
      {
        "value": "D",
        "text": "643 Pa"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Main duct area = 0.30(0.60) = 0.18 m²",
      "Branch area = 0.30(0.40) = 0.12 m²",
      "Main upstream flow = 2.7 m³/s",
      "Branch flow = 1.3 m³/s",
      "ρ = 1.2041 kg/m³",
      "Source pressure is printed as 250 kPa"
    ],
    "formula": "Continuity: Q_up = Q_down + Q_branch; Bernoulli with junction loss",
    "formulaReason": "The main-duct downstream flow is found by mass/volume continuity, then the source applies Bernoulli with a junction loss. There is a unit discrepancy: the printed pressure appears as 250 kPa, while the solution and answer choices are consistent with 250 Pa.",
    "derivation": "Calculate Q_down = 2.7-1.3 = 1.4 m³/s; calculate upstream/downstream velocities from the unchanged main-duct area; account for the source's stated elbow/junction loss, then apply Bernoulli.",
    "substitution": "Q_down = 2.7-1.3 = 1.4 m³/s\nV_up = 2.7/0.18 = 15 m/s\nV_down = 1.4/0.18 ≈ 7.78 m/s\nSource calculates junction loss ≈ 3.38 Pa\nSource downstream pressure ≈ 345.64 Pa when upstream pressure is interpreted as 250 Pa",
    "calculation": [
      "Source answer ≈ 346 Pa; pressure-unit inconsistency remains unresolved"
    ],
    "finalAnswer": "346 Pa (A, as printed; NOT VERIFIED).",
    "unitCheck": "The output is in Pa in the options and solution, but the question line appears to state kPa for the upstream pressure.",
    "concept": "A decrease in main-duct flow reduces velocity and can raise static pressure, subject to junction losses.",
    "shortcutFormula": "Q_up = Q_down + Q_branch; Bernoulli with loss",
    "shortcut": "Use continuity first. Confirm pressure units before using the source's answer.",
    "commonMistakes": [
      "The stated “250 kPa” conflicts with an answer near 346 Pa; confirm the original print or instructor key before scoring.",
      "Do not silently replace kPa with Pa."
    ],
    "sourceAnswerStatus": "Printed answer retained; marked unverified pending source discrepancy review.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 9,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=9"
  },
  {
    "id": "ipe-aircon-020",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Duct Flow - Sudden Enlargement",
    "difficulty": "Intermediate",
    "prompt": "A sudden enlargement in a circular duct measures 0.20 m diameter upstream and 0.40 m downstream. The upstream pressure is 150 Pa and the downstream pressure is 200 Pa. What is the flow rate of 20°C air through the fitting? Use ρ = 1.2041 kg/m³.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 20; PDF page(s) 11.",
    "options": [
      {
        "value": "A",
        "text": "0.49 m³/s"
      },
      {
        "value": "B",
        "text": "0.83 m³/s"
      },
      {
        "value": "C",
        "text": "0.38 m³/s"
      },
      {
        "value": "D",
        "text": "0.94 m³/s"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "D₁ = 0.20 m",
      "D₂ = 0.40 m",
      "P₁ = 150 Pa",
      "P₂ = 200 Pa",
      "ρ = 1.2041 kg/m³"
    ],
    "formula": "Q = A₁V₁; for sudden enlargement, ΔP = (ρ/2)(V₁² - V₂²), with V₂ = V₁(A₁/A₂)",
    "formulaReason": "Continuity relates velocities to area; the sudden-enlargement pressure relation gives upstream velocity, from which flow rate follows.",
    "derivation": "Area ratio A₁/A₂ = (D₁/D₂)² = 0.25. Substitute into the pressure-change equation, solve for V₁, and multiply by the upstream area.",
    "substitution": "A₁/A₂ = (0.20/0.40)² = 0.25\n50 = [1.2041 V₁²/2](1-0.25²)\nV₁ ≈ 12.15 m/s\nQ = π(0.20²)/4 × 12.15",
    "calculation": [
      "Q ≈ 0.381 m³/s"
    ],
    "finalAnswer": "0.38 m³/s (C).",
    "unitCheck": "Cross-sectional area times velocity gives m³/s.",
    "concept": "For a sudden enlargement, static pressure can increase as velocity decreases, while mechanical energy is lost.",
    "shortcutFormula": "Q = (πD₁²/4)V₁",
    "shortcut": "Find the upstream velocity from the pressure difference and area ratio first.",
    "commonMistakes": [
      "Do not confuse flow velocity with volumetric flow rate.",
      "Use the diameter ratio squared for circular areas."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 11,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=11"
  },
  {
    "id": "ipe-aircon-021",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Cooling Towers - Pump Capacity / Tower Efficiency",
    "difficulty": "Intermediate",
    "prompt": "Water at 55°C is cooled in a cooling tower having an efficiency of 65%. The surrounding air is at 32°C dry-bulb temperature and 70% relative humidity. Heat dissipated from the condenser is 2,300,000 kJ/hr. Find the capacity in liters per second of the pump used in the cooling tower.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 21; PDF page(s) 11-12.",
    "options": [
      {
        "value": "A",
        "text": "8.50 L/s"
      },
      {
        "value": "B",
        "text": "6.80 L/s"
      },
      {
        "value": "C",
        "text": "7.60 L/s"
      },
      {
        "value": "D",
        "text": "6.70 L/s"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Water inlet temperature = 55°C",
      "Tower efficiency = 65%",
      "Air: 32°C DB, 70% RH; source psychrometric wet-bulb temperature ≈ 27.4°C",
      "Condenser heat rejection = 2,300,000 kJ/hr",
      "c_p,water = 4.187 kJ/(kg·K)"
    ],
    "formula": "η_tower = (T_hot,in - T_water,out)/(T_hot,in - T_wb); Q̇ = ṁ c_p ΔT",
    "formulaReason": "Tower efficiency relates the actual water-temperature drop to the maximum drop available toward the entering-air wet-bulb temperature. The heat balance gives water mass flow.",
    "derivation": "Calculate the leaving-water temperature from tower efficiency, then use the condenser heat balance and convert mass flow to volume flow.",
    "substitution": "T_water,out = 55 - 0.65(55-27.4) ≈ 37.06°C\nṁ = (2,300,000/3600)/[4.187(55-37.06)] ≈ 8.51 kg/s\nUsing v_water ≈ 1.0068 L/kg: V̇ ≈ 8.57 L/s",
    "calculation": [
      "Pump capacity ≈ 8.57 L/s"
    ],
    "finalAnswer": "8.57 L/s; closest listed option is A (8.50 L/s).",
    "unitCheck": "kg/s × L/kg = L/s.",
    "concept": "The entering wet-bulb temperature limits the cooling achievable in an evaporative cooling tower.",
    "shortcutFormula": "ṁ = Q̇/[c_p(T_in-T_out)]",
    "shortcut": "Find tower outlet temperature first; the heat balance needs the actual water temperature drop.",
    "commonMistakes": [
      "Do not use dry-bulb temperature in place of wet-bulb temperature for tower efficiency.",
      "Convert kJ/hr to kW (divide by 3600) before using kJ/(kg·K)."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 11,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=11"
  },
  {
    "id": "ipe-aircon-022",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Cooling Towers - Diesel-Generator Jacket Water",
    "difficulty": "Intermediate",
    "prompt": "An atmospheric cooling tower is to provide cooling for the jacket water of a four-stroke, 800 kW diesel generator. The cooling-tower efficiency is 60% at a temperature approach of 10°C. Ambient air has 70% relative humidity and a dry-bulb temperature of 32°C. The generator efficiency is 97%, useful work is 30%, and cooling loss is 25%. Determine the volume of cooling water supplied to the diesel engine in liters per hour if it enters the tower at 52.4°C.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 22; PDF page(s) 12-13. Review note: Unverified: the prompt appears to specify 60% tower efficiency and 52.4°C water inlet, while the worked solution uses 65% and 55°C. Answer A follows the worked solution's inputs, not clearly the prompt's inputs.",
    "options": [
      {
        "value": "A",
        "text": "39,800 L/hr"
      },
      {
        "value": "B",
        "text": "35,700 L/hr"
      },
      {
        "value": "C",
        "text": "45,700 L/hr"
      },
      {
        "value": "D",
        "text": "49,800 L/hr"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Generator output = 800 kW",
      "Generator efficiency = 97%",
      "Engine useful-work fraction = 30%",
      "Cooling-loss fraction = 25%",
      "Water inlet to tower = 52.4°C",
      "Air: 32°C DB, 70% RH; source wet-bulb temperature ≈ 27.45°C"
    ],
    "formula": "P_engine = P_generator/η_generator; Q̇_in = P_engine/η_thermal; Q̇_water = 0.25Q̇_in; Q̇_water = ṁc_pΔT",
    "formulaReason": "The source first estimates engine power and heat input from generator and engine efficiencies, then assigns 25% of engine heat input to cooling water. The worked solution uses a tower efficiency of 65% even though the scanned prompt appears to say 60%; it also uses a 55°C water inlet where the prompt appears to state 52.4°C.",
    "derivation": "The source solution uses 65% tower efficiency and 55°C inlet water to find tower outlet temperature, calculate heat carried by the water, and convert mass flow to volume flow. The problem statement appears to say 60% and 52.4°C.",
    "substitution": "P_engine = 800/0.97 = 824.74 kW\nQ̇_in = 824.74/0.30 = 2749.14 kW\nQ̇_water = 0.25(2749.14) = 687.285 kW\nUsing the solution’s η = 0.65: T_out ≈ 37.06°C; ṁ ≈ 10.98 kg/s\nV̇ ≈ 39,803.83 L/hr",
    "calculation": [
      "Using 65% gives about 39,800 L/hr; using 60% would lead to a different listed option."
    ],
    "finalAnswer": "39,800 L/hr (A, source solution; NOT VERIFIED until tower efficiency is confirmed).",
    "unitCheck": "Convert kg/s to kg/hr and then use specific volume in L/kg.",
    "concept": "The efficiency value directly changes the outlet-water temperature and the required flow. The printed prompt must be resolved before marking the key verified.",
    "shortcutFormula": "Q̇_water = ṁc_p(T_in-T_out)",
    "shortcut": "Read the tower efficiency carefully; the solution uses 65% although the scanned prompt is ambiguous.",
    "commonMistakes": [
      "Do not ignore the 97% generator efficiency.",
      "Do not treat the blurry 60%/65% value as certain."
    ],
    "sourceAnswerStatus": "Printed answer retained; marked unverified pending source discrepancy review.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 12,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=12"
  },
  {
    "id": "ipe-aircon-023",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Cooling Towers - Cooling Water Flow / Energy Balance",
    "difficulty": "Intermediate",
    "prompt": "Fifty gallons per minute of water enters a cooling tower at 46°C. Atmospheric air at 16°C dry-bulb temperature and 55% relative humidity enters the tower at 2.85 m/s and leaves at 32°C saturated. Determine the volume of water that leaves the tower.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 23; PDF page(s) 13-14.",
    "options": [
      {
        "value": "A",
        "text": "4.10 L/s"
      },
      {
        "value": "B",
        "text": "3.10 L/s"
      },
      {
        "value": "C",
        "text": "2.10 L/s"
      },
      {
        "value": "D",
        "text": "5.10 L/s"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Water in = 50 US gal/min at 46°C",
      "Air in = 16°C DB, 55% RH; flow speed = 2.85 m/s",
      "Air out = 32°C, saturated",
      "Source psychrometric/steam-table properties are used"
    ],
    "formula": "Mass balance on water vapor and dry air; energy balance: ṁ_w,in h_w,in - ṁ_w,out h_w,out = ṁ_da(h_air,out-h_air,in)",
    "formulaReason": "The outlet-water flow is not equal to the inlet flow because evaporation adds water vapor to the air. The source solves a water mass balance and an energy balance.",
    "derivation": "Convert the entering water flow to kg/s, find dry-air flow from inlet air velocity and specific volume, use humidity ratios for evaporation, then solve the energy balance for outlet liquid-water enthalpy and convert to L/s.",
    "substitution": "Source: ṁ_water,in ≈ 3.12 kg/s after unit conversion\nSource mass balance gives ṁ_water,out ≈ 3.09 kg/s\nAt outlet-water temperature, source v ≈ 1.0031 L/kg\nV̇_out = 3.09(1.0031)",
    "calculation": [
      "V̇_water,out ≈ 3.10 L/s"
    ],
    "finalAnswer": "3.10 L/s (B).",
    "unitCheck": "kg/s × L/kg = L/s.",
    "concept": "Evaporation lowers liquid-water flow while carrying away heat; both mass and energy balances are required.",
    "shortcutFormula": "Water out = water in - water evaporated",
    "shortcut": "Convert the inlet flow carefully, then account for moisture absorbed by the air.",
    "commonMistakes": [
      "Do not assume no evaporation.",
      "Keep humidity ratios on a per-kg-dry-air basis."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 13,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=13"
  },
  {
    "id": "ipe-aircon-024",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Cooling Towers - Make-Up Water",
    "difficulty": "Intermediate",
    "prompt": "250,000 kg/hr of water at 35°C enters a cooling tower to be cooled to 17.5°C. Energy is exchanged with atmospheric air entering at 15°C and leaving at 30°C. Air enters at 30% RH and leaves at 85% RH. Assuming atmospheric pressure throughout, determine the percentage of total water flow that is make-up water.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 24; PDF page(s) 15.",
    "options": [
      {
        "value": "A",
        "text": "2.22%"
      },
      {
        "value": "B",
        "text": "3.33%"
      },
      {
        "value": "C",
        "text": "4.44%"
      },
      {
        "value": "D",
        "text": "1.11%"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Water flow = 250,000 kg/hr",
      "Water cools from 35°C to 17.5°C",
      "Air in: 15°C, 30% RH; source h₁ = 23.02 kJ/kg, w₁ = 0.0033",
      "Air out: 30°C, 85% RH; source h₂ = 89.01 kJ/kg, w₂ = 0.0233",
      "c_p,water = 4.187 kJ/(kg·K)"
    ],
    "formula": "ṁ_da = ṁ_w c_p ΔT_w/(h₂-h₁); ṁ_makeup = ṁ_da(w₂-w₁); percent = 100 ṁ_makeup/ṁ_w",
    "formulaReason": "Heat lost by the cooling water equals heat gained by the air. The evaporated water is dry-air flow times humidity-ratio rise; make-up percentage is that loss divided by circulating-water flow.",
    "derivation": "Calculate dry-air flow by energy balance, calculate evaporation by moisture balance, and divide by water flow.",
    "substitution": "ṁ_da = 250000(4.187)(35-17.5)/(89.01-23.02) ≈ 277,589.41 kg/hr\nṁ_makeup = 277,589.41(0.0233-0.0033) ≈ 5,551.79 kg/hr\n% makeup = 100(5,551.79/250,000)",
    "calculation": [
      "% make-up water ≈ 2.22%"
    ],
    "finalAnswer": "2.22% (A).",
    "unitCheck": "The final result is a percentage of circulating-water mass flow.",
    "concept": "Make-up water compensates for evaporated water, approximated here from the humidity-ratio increase.",
    "shortcutFormula": "% makeup = 100 ṁ_da(w₂-w₁)/ṁ_w",
    "shortcut": "Find evaporation rate first; then divide by the circulating water flow, not by air flow.",
    "commonMistakes": [
      "Do not divide by dry-air flow when calculating the percentage.",
      "Use the difference in humidity ratio, not the final humidity ratio alone."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 15,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=15"
  },
  {
    "id": "ipe-aircon-025",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Refrigeration - Capacity from Psychrometric Properties",
    "difficulty": "Intermediate",
    "prompt": "How much refrigeration capacity is required to cool 56.67 m³ of air per minute from 29°C to 21°C? Assume that the cooled air is saturated.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 25; PDF page(s) 16. Review note: Unverified: the printed text associates h=70 kJ/kg with 21°C saturated air and h=61 with the 29°C line, which appears to mislabel the states; arithmetic uses 70-61.",
    "options": [
      {
        "value": "A",
        "text": "4.76 tons of refrigeration"
      },
      {
        "value": "B",
        "text": "1.76 tons of refrigeration"
      },
      {
        "value": "C",
        "text": "3.76 tons of refrigeration"
      },
      {
        "value": "D",
        "text": "2.76 tons of refrigeration"
      }
    ],
    "answer": "D",
    "answerVerified": false,
    "given": [
      "Volume flow rate = 56.67 m³/min",
      "Air cools from 29°C to 21°C",
      "Outlet is assumed saturated",
      "Source solution uses h_in = 70 kJ/kg, h_out = 61 kJ/kg, and v ≈ 0.875 m³/kg"
    ],
    "formula": "Q̇ = ṁ_da(h_in-h_out);  ṁ_da = V̇/v;  1 ton of refrigeration ≈ 3.517 kW",
    "formulaReason": "The source intends a constant-humidity-ratio cooling process ending at saturation. However, the printed temperature labels attached to h₁/h₂ appear reversed or mislabeled; the calculation uses an enthalpy drop of 70-61 kJ/kg.",
    "derivation": "Using the source values as used in its arithmetic, convert volumetric flow to dry-air mass flow, multiply by enthalpy drop, then convert kW to tons of refrigeration. Confirm property labels against the original chart before treating this as verified.",
    "substitution": "ṁ = 56.67/0.875 = 64.77 kg/min = 1.079 kg/s\nQ̇ = 1.079(70-61) = 9.711 kW\nTR = 9.711/3.517 ≈ 2.76",
    "calculation": [
      "2.76 tons of refrigeration (source calculation)"
    ],
    "finalAnswer": "2.76 TOR (D, as printed; NOT VERIFIED due to psychrometric label ambiguity).",
    "unitCheck": "kJ/s = kW; divide by approximately 3.517 kW per ton of refrigeration.",
    "concept": "Total refrigeration load is found from enthalpy difference, not only dry-bulb temperature difference. The source's state labels need confirmation.",
    "shortcutFormula": "Q̇ = ṁ_da Δh; TR = Q̇/3.517",
    "shortcut": "Check the inlet/outlet enthalpy labels first; cooling requires h_in > h_out.",
    "commonMistakes": [
      "Do not accept a cooling calculation if the enthalpy direction is reversed.",
      "The source's chart labels are uncertain in this scan."
    ],
    "sourceAnswerStatus": "Printed answer retained; marked unverified pending source discrepancy review.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 16,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=16"
  },
  {
    "id": "ipe-aircon-026",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Refrigeration - Capacity from Psychrometric Properties",
    "difficulty": "Intermediate",
    "prompt": "Find the refrigeration capacity required to cool 29 m³/min of outside air from 29°C to 18°C if the outside air has a relative humidity of 90%.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 26; PDF page(s) 16-17.",
    "options": [
      {
        "value": "A",
        "text": "2.9 tons of refrigeration"
      },
      {
        "value": "B",
        "text": "3.9 tons of refrigeration"
      },
      {
        "value": "C",
        "text": "4.9 tons of refrigeration"
      },
      {
        "value": "D",
        "text": "5.9 tons of refrigeration"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Volume flow = 29 m³/min",
      "Inlet = 29°C DB, 90% RH; source chart h₁ = 88.45 kJ/kg",
      "Outlet = 18°C DB, saturated; source chart h₂ = 50.45 kJ/kg and v₁ = 0.886 m³/kg"
    ],
    "formula": "Q̇ = ṁ_da(h₁-h₂);  ṁ_da = V̇/v;  TR = Q̇/3.517",
    "formulaReason": "Use the enthalpy difference because cooling may include latent as well as sensible heat removal.",
    "derivation": "Convert volumetric flow to mass flow, compute heat-removal rate, and divide by the kW-per-ton conversion.",
    "substitution": "ṁ = (29/0.886)/60 ≈ 0.546 kg/s\nQ̇ = 0.546(88.45-50.45) = 20.75 kW\nTR = 20.75/3.517 ≈ 5.90",
    "calculation": [
      "Q̇ ≈ 5.9 tons of refrigeration"
    ],
    "finalAnswer": "5.9 TOR (D).",
    "unitCheck": "Use kg/s times kJ/kg to obtain kW, then divide by 3.517 kW/TOR.",
    "concept": "High humidity increases the total enthalpy to be removed; a sensible-only c_pΔT estimate would miss latent load.",
    "shortcutFormula": "Q̇ = ṁ_daΔh; TR = Q̇/3.517",
    "shortcut": "Use inlet and outlet enthalpies from their correct psychrometric states.",
    "commonMistakes": [
      "Do not subtract outlet enthalpy from inlet in the wrong order.",
      "Convert kg/min to kg/s before reporting kW."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 16,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=16"
  },
  {
    "id": "ipe-aircon-027",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Drying - Fan Capacity / Moisture Balance",
    "difficulty": "Intermediate",
    "prompt": "The temperature of air in a dryer is maintained constant by steam coils. Product enters at 1 metric ton per hour. Initial moisture content is 3 kg moisture per kg dry solid and it is dried to 0.10 kg moisture per kg dry solid. Air enters with humidity ratio 0.016 kg moisture/kg dry air and leaves at 100% relative humidity while its temperature remains at 60°C. Total air pressure is 101.3 kPa. Determine the capacity of the forced-draft fan in m³/min.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 27; PDF page(s) 17-19.",
    "options": [
      {
        "value": "A",
        "text": "85.75 m³/min"
      },
      {
        "value": "B",
        "text": "87.55 m³/min"
      },
      {
        "value": "C",
        "text": "55.87 m³/min"
      },
      {
        "value": "D",
        "text": "58.75 m³/min"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Wet feed = 1000 kg/hr",
      "Initial moisture content = 3 kg water/kg dry solid",
      "Final moisture content = 0.10 kg water/kg dry solid",
      "Air inlet humidity ratio = 0.016 kg/kg dry air",
      "Outlet air = 60°C, 100% RH",
      "P = 101.3 kPa"
    ],
    "formula": "ṁ_da = water evaporated/(w_out-w_in);  V̇ = ṁ_da v_out",
    "formulaReason": "First use the dry-solid balance to find dry-solid and product rates, then calculate water evaporated. The air moisture balance gives dry-air flow; multiply by outlet specific volume for fan capacity.",
    "derivation": "Dry solid remains constant. For 1000 kg/hr feed at 3 kg water/kg dry solid, dry solid is 250 kg/hr; final product is 250(1+0.10)=275 kg/hr. Then use saturation humidity ratio at 60°C.",
    "substitution": "Water removed = 1000-275 = 725 kg/hr\nSource w_out at 60°C saturated = 0.1524 kg/kg; w_in = 0.016\nṁ_da = 725/(0.1524-0.016) ≈ 5315.25 kg/hr\nV̇ = 5315.25(0.968) ≈ 5145.16 m³/hr",
    "calculation": [
      "Fan capacity ≈ 85.75 m³/min"
    ],
    "finalAnswer": "85.75 m³/min (A).",
    "unitCheck": "m³/hr divided by 60 gives m³/min.",
    "concept": "The moisture balance uses humidity ratio change per kilogram of dry air. Dry solid is conserved through drying.",
    "shortcutFormula": " ṁ_da = ṁ_water removed/(w_out-w_in)",
    "shortcut": "Calculate dry-solid flow and product flow before calculating the evaporated moisture.",
    "commonMistakes": [
      "Do not treat 3 kg/kg dry solid as 3% moisture.",
      "Do not use the saturated humidity ratio at a temperature other than 60°C."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 17,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=17"
  },
  {
    "id": "ipe-aircon-028",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Drying - Moisture Removal / Air Requirement",
    "difficulty": "Intermediate",
    "prompt": "Wet material containing 215% moisture on a dry basis is dried at 1.5 kg/s in a continuous dryer to give a product containing 5% moisture on a wet basis. The drying medium is air heated to 373 K with water-vapor partial pressure 1.40 kPa. Air leaves the dryer at 310 K and 70% saturation. Calculate the mass flow rate of air required to remove the moisture.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 28; PDF page(s) 19-20.",
    "options": [
      {
        "value": "A",
        "text": "50 kg/s"
      },
      {
        "value": "B",
        "text": "55 kg/s"
      },
      {
        "value": "C",
        "text": "60 kg/s"
      },
      {
        "value": "D",
        "text": "65 kg/s"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Wet feed = 1.5 kg/s",
      "Initial moisture = 215% dry basis, X₁ = 2.15 kg water/kg dry solid",
      "Final product moisture = 5% wet basis",
      "Air inlet T = 373 K, P_v = 1.40 kPa",
      "Air outlet T = 310 K, 70% saturation"
    ],
    "formula": "ṁ_da = ṁ_water removed/(w₂-w₁)",
    "formulaReason": "Use a solids balance to calculate dry-solid rate and final product flow. Difference in feed and product flow is the water removed. Then the air humidity-ratio rise determines dry-air requirement.",
    "derivation": "Convert dry-basis and wet-basis moisture contents consistently, compute moisture removed, obtain inlet/outlet humidity ratios, and apply the moisture balance.",
    "substitution": "Final product flow = [1.5/(1+2.15)]/0.95 ≈ 0.501 kg/s\nWater removed = 1.5-0.501 = 0.999 kg/s\nw₁ = 0.622(1.40)/(101.325-1.40) ≈ 0.00871 kg/kg\nSource psychrometric chart gives w₂ = 0.0289 kg/kg\nṁ_da = 0.999/(0.0289-0.00871) ≈ 49.48 kg/s",
    "calculation": [
      "ṁ_da ≈ 49.48 kg/s; nearest option is 50 kg/s"
    ],
    "finalAnswer": "50 kg/s (A; calculated value ≈ 49.48 kg/s).",
    "unitCheck": "kg/s of dry air.",
    "concept": "Dry-basis moisture divides water mass by dry-solid mass; wet-basis moisture divides water mass by total wet-material mass.",
    "shortcutFormula": "ṁ_da = ṁ_water removed/Δw",
    "shortcut": "Normalize both moisture percentages to their stated bases before doing the solids balance.",
    "commonMistakes": [
      "Do not treat 215% dry basis as a wet-basis percentage.",
      "Do not use the outlet humidity ratio alone; use w₂-w₁."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 19,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=19"
  },
  {
    "id": "ipe-aircon-029",
    "builtIn": true,
    "subject": "Air Conditioning",
    "category": "Refrigeration - Sensible Cooling Capacity",
    "difficulty": "Intermediate",
    "prompt": "One hundred fifty cubic meters of air per minute at 35°C dry-bulb and 25°C wet-bulb temperature are to be cooled to 21°C. Determine the refrigeration capacity.",
    "source": "IPE Aircon 1-29(1).pdf; Chapter 05 - Air Conditioning; Problem 29; PDF page(s) 20.",
    "options": [
      {
        "value": "A",
        "text": "10 tons of refrigeration"
      },
      {
        "value": "B",
        "text": "11 tons of refrigeration"
      },
      {
        "value": "C",
        "text": "12 tons of refrigeration"
      },
      {
        "value": "D",
        "text": "13 tons of refrigeration"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "V̇ = 150 m³/min",
      "Initial air = 35°C DB, 25°C WB",
      "Final dry-bulb temperature = 21°C",
      "Source chart specific volume used for inlet = 0.892 m³/kg",
      "c_p ≈ 1 kJ/(kg·K)"
    ],
    "formula": "Q̇ = ṁ_da c_p (T₁-T₂);  ṁ_da = V̇/v₁",
    "formulaReason": "The printed solution treats this as sensible cooling and uses the specific heat relation rather than total enthalpy difference.",
    "derivation": "Convert inlet volumetric flow to dry-air mass flow, convert minutes to seconds, and multiply by c_p and the dry-bulb temperature drop.",
    "substitution": "ṁ = (150/0.892) kg/min = 168.16 kg/min = 2.803 kg/s\nQ̇ = 2.803(1)(35-21) = 39.24 kW\nTR = 39.24/3.517 ≈ 11.15",
    "calculation": [
      "Q̇ ≈ 11.15 tons of refrigeration"
    ],
    "finalAnswer": "11.15 TOR; nearest listed option is 11 TOR (B).",
    "unitCheck": "kg/s × kJ/(kg·K) × K = kW.",
    "concept": "This is a sensible-capacity calculation using c_pΔT. A total-load calculation would require consistent inlet and outlet enthalpies.",
    "shortcutFormula": "Q̇ = ṁ_da c_pΔT; TR = Q̇/3.517",
    "shortcut": "Compute mass flow from the inlet specific volume, then use the dry-bulb temperature change.",
    "commonMistakes": [
      "Do not confuse m³/min with m³/s.",
      "Confirm whether the problem intends sensible load or total enthalpy load."
    ],
    "sourceAnswerStatus": "Answer retained from the printed worked solution; not independently re-derived against every chart/table value.",
    "sourceSolutionStatus": "Expanded teaching explanation prepared from the supplied scanned PDF; check against the original page when values are ambiguous.",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE — Industrial Plant Engineering Reviewer",
    "sourcePage": 20,
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=20"
  },
  {
    "sourceProblemNumber": 48,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Sensible Cooling Capacity",
    "difficulty": "Intermediate",
    "prompt": "A refrigeration plant is rated at 15 tons capacity. How many pounds of air per hour will it cool from 70°F to 90°F at constant temperature?",
    "options": [
      {
        "value": "A",
        "text": "50,000 lb/hr"
      },
      {
        "value": "B",
        "text": "37,500 lb/hr"
      },
      {
        "value": "C",
        "text": "52,000 lb/hr"
      },
      {
        "value": "D",
        "text": "45,000 lb/hr"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Capacity = 15 TR",
      "Air temperature change = 70°F to 90°F",
      "Use c_p = 0.24 Btu/(lb·°F) as in the source solution"
    ],
    "formula": "\\dot Q=\\dot m c_p\\Delta T",
    "formulaReason": "This problem is classified as Sensible Cooling Capacity. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "15(12,000 Btu/hr) = ṁ(0.24)(90−70).",
    "calculation": [
      "Convert capacity: 15 TR × 12,000 = 180,000 Btu/hr.",
      "ṁ = 180,000/[0.24(20)] = 37,500 lb/hr."
    ],
    "finalAnswer": "B — 37,500 lb/hr",
    "unitCheck": "Btu/hr divided by Btu/lb gives lb/hr.",
    "concept": "Sensible heat transfer is proportional to mass-flow rate, specific heat, and temperature difference.",
    "shortcutFormula": "\\dot Q=\\dot m c_p\\Delta T",
    "shortcut": "Convert TR to Btu/hr, then divide by c_pΔT.",
    "commonMistakes": [
      "Use the temperature difference, not either absolute Fahrenheit temperature.",
      "Keep capacity and specific-heat units consistent."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 48; original PDF page 12; extracted PDF page 14",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 12,
    "sourceExtractedPdfPage": 14,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=14",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q= mC, AT BTU 15 TOR (1200025) = m(0.24)(90 — 70) m = 37,500 lb/hr",
    "sourceChoicesOriginalOrder": [
      "A. 50,000 lb/hr",
      "B. 37,500 lb/hr",
      "C. 52,000 lb/hr",
      "D. 45,000 lb/hr"
    ],
    "id": "bluebook-aircon-048",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=14"
  },
  {
    "sourceProblemNumber": 103,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Brine Cooler Refrigeration Load",
    "difficulty": "Intermediate",
    "prompt": "Brine enters a circulating brine cooler at the rate of 60 m3/hr at -8°C and leaves at -18°C. Specific heat of brine is 1.072 kJ/kg-K and a specific gravity of 1.12. Determine the tons of refrigeration.",
    "options": [
      {
        "value": "A",
        "text": "53.5 TR"
      },
      {
        "value": "B",
        "text": "65.3 TR"
      },
      {
        "value": "C",
        "text": "33.5 TR"
      },
      {
        "value": "D",
        "text": "56.9 TR"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Brine flow = 60 m³/hr",
      "Specific gravity = 1.12",
      "c_p = 1.072 kJ/(kg·K)",
      "Temperature decreases from −8°C to −18°C"
    ],
    "formula": "\\dot Q=\\dot m c_p\\Delta T;\\quad TR=\\dot Q/3.516",
    "formulaReason": "This problem is classified as Brine Cooler Refrigeration Load. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "ρ = 1.12(1000)=1120 kg/m³; ṁ=1120(60)/3600=18.67 kg/s.",
    "calculation": [
      "ṁ ≈ 18.67 kg/s.",
      "Q̇ = 18.67(1.072)[(−8)−(−18)] ≈ 200.1 kW.",
      "TR = 200.1/3.516 ≈ 56.9 TR."
    ],
    "finalAnswer": "D — 56.9 TR",
    "unitCheck": "kg/s × kJ/(kg·K) × K = kJ/s = kW.",
    "concept": "A liquid/brine cooler load is the rate of sensible heat removed from the flowing brine.",
    "shortcutFormula": "\\dot Q=\\dot m c_p\\Delta T;\\quad TR=\\dot Q/3.516",
    "shortcut": "Convert volumetric flow to kg/s with density, then use c_pΔT and convert kW to TR.",
    "commonMistakes": [
      "Use the magnitude of the temperature drop.",
      "Do not use m³/hr directly as kg/s."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 103; original PDF page 31; extracted PDF page 15",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 31,
    "sourceExtractedPdfPage": 15,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=15",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Density of brine = 1.12 (10002) = 1120 kg/m? + _ 1120(60) _ m =o) = 18.67 kg/s Q = thc, At = 18.67(1.072)(-8 + 18) = 200.11 kw TR = 1 56.9 TR 3.516",
    "sourceChoicesOriginalOrder": [
      "A. 53.5 TR",
      "B. 65.3 TR",
      "C. 33.5 TR",
      "D. 56.9 TR"
    ],
    "id": "bluebook-aircon-103",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=15"
  },
  {
    "sourceProblemNumber": 121,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Water Cooler & Ice Melt Energy Balance",
    "difficulty": "Intermediate",
    "prompt": "A water cooler uses 50 lb/hr of melting ice to cool running water from 80°F to 42°F. Based on the inside coil area, Ui = 110 Btu/hr-ft2-°F. Find the gpm of water cooled.",
    "options": [
      {
        "value": "A",
        "text": "0.10 GPM"
      },
      {
        "value": "B",
        "text": "0.21 GPM"
      },
      {
        "value": "C",
        "text": "0.38 GPM"
      },
      {
        "value": "D",
        "text": "0.45 GPM"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Ice melts at 50 lb/hr",
      "Water cooled from 80°F to 42°F",
      "c_p,water ≈ 1 Btu/(lb·°F)",
      "Latent heat of fusion ≈ 144 Btu/lb"
    ],
    "formula": "\\dot m_w c_p(T_1-T_2)=\\dot m_{ice}h_f",
    "formulaReason": "This problem is classified as Water Cooler & Ice Melt Energy Balance. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "50(144) = ṁ_water(1)(80−42).",
    "calculation": [
      "Heat absorbed by melting ice = 50(144)=7200 Btu/hr.",
      "ṁ_water=7200/38=189.47 lb/hr.",
      "Convert mass flow to volume flow using water density: ≈0.38 GPM."
    ],
    "finalAnswer": "C — 0.38 GPM",
    "unitCheck": "Both sides are Btu/hr; the final volume flow is gal/min.",
    "concept": "The heat removed from the water is balanced by the latent heat absorbed by melting ice, assuming the source model.",
    "shortcutFormula": "\\dot m_w c_p(T_1-T_2)=\\dot m_{ice}h_f",
    "shortcut": "Equate ṁc_pΔT for water to ṁ_ice h_f for melting ice.",
    "commonMistakes": [
      "Do not use the ice mass flow as the water flow.",
      "Remember to convert lb/hr to GPM."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 121; original PDF page 37; extracted PDF page 16",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 37,
    "sourceExtractedPdfPage": 16,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=16",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q=m,L,= thy Cp, (T; — T,) 50(144) = m,, (1) (80 — 42) My = 189.474 lb/hr y = 189.474 (28) — 0.38 GPM 62.4 60",
    "sourceChoicesOriginalOrder": [
      "A. 0.10 GPM",
      "B. 0.21 GPM",
      "C. 0.38 GPM",
      "D. 0.45 GPM"
    ],
    "id": "bluebook-aircon-121",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=16"
  },
  {
    "sourceProblemNumber": 124,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Auditorium Supply-Air Load",
    "difficulty": "Intermediate",
    "prompt": "An auditorium seating 1500 people is to be maintained at 80°F dry bulb and 60°F wet bulb temperature when outdoor air is at 91°F dry bulb and 75°F wet bulb. Solar heat load is 110,000 Btu/hr and supply air is at 60°F, determine the amount of supply air.",
    "options": [
      {
        "value": "A",
        "text": "93,229.17 lb/hr"
      },
      {
        "value": "B",
        "text": "83,229.17 lb/hr"
      },
      {
        "value": "C",
        "text": "73,229.17 lb/hr"
      },
      {
        "value": "D",
        "text": "63,229.17 lb/hr"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "1500 people",
      "Room: 80°F DB / 60°F WB",
      "Outdoor air: 91°F DB / 75°F WB",
      "Solar load = 110,000 Btu/hr",
      "Supply air = 60°F"
    ],
    "formula": "\\dot Q=\\dot m c_p(T_{room}-T_{supply})",
    "formulaReason": "This problem is classified as Auditorium Supply-Air Load. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇ = 225(1500)+110,000 = 447,500 Btu/hr; Q̇=ṁ(0.24)(80−60).",
    "calculation": [
      "Sensible people load = 225(1500)=337,500 Btu/hr.",
      "Total load = 337,500+110,000=447,500 Btu/hr.",
      "ṁ = 447,500/[0.24(20)] = 93,229.17 lb/hr."
    ],
    "finalAnswer": "A — 93,229.17 lb/hr",
    "unitCheck": "Btu/hr ÷ [Btu/(lb·°F) × °F] = lb/hr.",
    "concept": "Supply air must carry away the room sensible load; mass flow is found from the room-to-supply dry-bulb temperature difference.",
    "shortcutFormula": "\\dot Q=\\dot m c_p(T_{room}-T_{supply})",
    "shortcut": "Sum the sensible loads first, then divide by c_pΔT between room and supply air.",
    "commonMistakes": [
      "Do not use outdoor temperature in place of the stated room/supply temperatures.",
      "Check whether latent load is included; this source calculation is sensible-load based."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 124; original PDF page 38; extracted PDF page 17",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 38,
    "sourceExtractedPdfPage": 17,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=17",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Sensible heat per person = 225 Btu/hr Q, = 225(1500) + 110,000 = 447,500 Btu/hr Q, = the, (t, — t,) 447,500 = m(0.24)(80 — 60) m= 93,229.17 lb/hr",
    "sourceChoicesOriginalOrder": [
      "A. 93,229.17 lb/hr",
      "B. 83,229.17 lb/hr",
      "C. 73,229.17 lb/hr",
      "D. 63,229.17 lb/hr"
    ],
    "id": "bluebook-aircon-124",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=17"
  },
  {
    "sourceProblemNumber": 126,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Absorber Solution Concentration Balance",
    "difficulty": "Intermediate",
    "prompt": "A 35% solution leaves the absorber and 30% solution enters the absorber. The heat removed from the absorber by cooling water is 547.6 Btu and ammonia is superheated by 10°. Find the pound per pound of ammonia gas from the evaporating coils.",
    "options": [
      {
        "value": "A",
        "text": "11"
      },
      {
        "value": "B",
        "text": "12"
      },
      {
        "value": "C",
        "text": "13"
      },
      {
        "value": "D",
        "text": "14"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Solution concentration leaving absorber = 35%",
      "Solution concentration entering absorber = 30%",
      "Source reports heat removal = 547.6 Btu and ammonia superheat = 10°"
    ],
    "formula": "n=\\frac{1-x_2}{x_1-x_2}-1",
    "formulaReason": "This problem is classified as Absorber Solution Concentration Balance. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Using the source concentration balance: n = (1−0.30)/(0.35−0.30) − 1.",
    "calculation": [
      "n = 0.70/0.05 − 1 = 14−1 = 13."
    ],
    "finalAnswer": "C — 13 lb ammonia gas per lb from the coils",
    "unitCheck": "The result is a mass ratio, lb per lb.",
    "concept": "The source uses an absorber material balance based on the ammonia concentration change between weak and strong solutions.",
    "shortcutFormula": "n=\\frac{1-x_2}{x_1-x_2}-1",
    "shortcut": "Write the material-balance ratio using mass fractions (0.35 and 0.30), not percentages 35 and 30.",
    "commonMistakes": [
      "Convert percentages to fractions.",
      "Keep track of which concentration is entering and which is leaving."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 126; original PDF page 39; extracted PDF page 18",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 39,
    "sourceExtractedPdfPage": 18,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=18",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Ib . . 1-x, 1-03 n = — of ammonia gas from the coils = —* — 1 = ——-- 1=13 Ib Xy—Xp 0.35—-0.3",
    "sourceChoicesOriginalOrder": [
      "A. 11",
      "B. 12",
      "C. 13",
      "D. 14"
    ],
    "id": "bluebook-aircon-126",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=18"
  },
  {
    "sourceProblemNumber": 127,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Carnot Refrigerator Work per Ton",
    "difficulty": "Intermediate",
    "prompt": "A Carnot refrigeration system operates at Tmax/Tmin = 1.5. Find the kW per ton of refrigeration.",
    "options": [
      {
        "value": "A",
        "text": "1.91"
      },
      {
        "value": "B",
        "text": "2.15"
      },
      {
        "value": "C",
        "text": "1.76"
      },
      {
        "value": "D",
        "text": "1.55"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "T_max/T_min = 1.5"
    ],
    "formula": "COP_R=\\frac{T_L}{T_H-T_L};\\quad kW/TR=3.516/COP_R",
    "formulaReason": "This problem is classified as Carnot Refrigerator Work per Ton. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "COP_R = 1/(1.5−1)=2.0; kW/TR = 3.516/2.",
    "calculation": [
      "For a reversed Carnot refrigerator, COP_R = T_L/(T_H−T_L)=1/(T_H/T_L−1).",
      "COP_R = 1/(1.5−1)=2.",
      "Input per ton = 3.516/2 = 1.758 ≈ 1.76 kW/TR."
    ],
    "finalAnswer": "C — 1.76 kW/TR",
    "unitCheck": "COP is dimensionless; kW divided by TR gives kW/TR.",
    "concept": "Carnot refrigerator COP depends only on absolute reservoir temperatures; the ratio removes the need to know their actual values.",
    "shortcutFormula": "COP_R=\\frac{T_L}{T_H-T_L};\\quad kW/TR=3.516/COP_R",
    "shortcut": "From r=T_H/T_L, use COP_R=1/(r−1), then divide 3.516 kW/TR by COP.",
    "commonMistakes": [
      "Use absolute temperatures in Carnot formulas.",
      "Do not use T_H/T_L itself as COP."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 127; original PDF page 39; extracted PDF page 19",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 39,
    "sourceExtractedPdfPage": 19,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=19",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: W _ 3.516 3.516 Tmax—Tmin \\ _ Tmax _ me 7 cor = ta = 3.516 (Tmm—Tmin) — 3.516 (m= — 1) = 3.516(1.5 — 1) = 1.758 = 1.76 kW/TR",
    "sourceChoicesOriginalOrder": [
      "A. 1.91",
      "B. 2.15",
      "C. 1.76",
      "D. 1.55"
    ],
    "id": "bluebook-aircon-127",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=19"
  },
  {
    "sourceProblemNumber": 131,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Fan Static and Velocity Head",
    "difficulty": "Intermediate",
    "prompt": "The total head of fan is 187 m and has a static pressure of 210 mm of water gage, what is the velocity of air flowing if the density of air is 1.15 kg/m3?",
    "options": [
      {
        "value": "A",
        "text": "6.85 m/s"
      },
      {
        "value": "B",
        "text": "3.45 m/s"
      },
      {
        "value": "C",
        "text": "4.39 m/s"
      },
      {
        "value": "D",
        "text": "9.28 m/s"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Total head = 187 m of air head as printed",
      "Static pressure = 210 mm water gauge",
      "Air density = 1.15 kg/m³"
    ],
    "formula": "H=H_s+\\frac{V^2}{2g}",
    "formulaReason": "This problem is classified as Fan Static and Velocity Head. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "H_s ≈ 0.210(1000/1.15)=182.61 m; H_v=187−182.61=4.39 m.",
    "calculation": [
      "Convert static pressure to equivalent air head: H_s≈182.61 m.",
      "Velocity head H_v = 187−182.61=4.39 m.",
      "V = √(2gH_v)=√[2(9.81)(4.39)] ≈9.28 m/s."
    ],
    "finalAnswer": "D — 9.28 m/s",
    "unitCheck": "Head is in meters; √(m/s² × m) gives m/s.",
    "concept": "Fan total pressure/head is separated into static and velocity components; velocity follows from the velocity head.",
    "shortcutFormula": "H=H_s+\\frac{V^2}{2g}",
    "shortcut": "Subtract static head from total head, then use V=√(2gH_v).",
    "commonMistakes": [
      "Convert water pressure to equivalent head of air using the given density.",
      "Do not take the square root before multiplying by 2g."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 131; original PDF page 40; extracted PDF page 20",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 40,
    "sourceExtractedPdfPage": 20,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=20",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: 1000 hg = 0.21 (2) = 182.61 m 187 = 182.61+h, h, = 439m v2 4.39 = 2(9.81) V= 9.28 m/s",
    "sourceChoicesOriginalOrder": [
      "A. 6.85 m/s",
      "B. 3.45 m/s",
      "C. 4.39 m/s",
      "D. 9.28 m/s"
    ],
    "id": "bluebook-aircon-131",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=20"
  },
  {
    "sourceProblemNumber": 132,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Fan Laws & Pressure",
    "difficulty": "Intermediate",
    "prompt": "A fan delivers 5.7 m3/s at a static pressure of 5.08 cm of water when operating at a speed of 400 rpm. The power input required is 2.963 kW. If 7.05 m3/s are desired in the same fan and installation, find the pressure in cm of water.",
    "options": [
      {
        "value": "A",
        "text": "7.77"
      },
      {
        "value": "B",
        "text": "17.14"
      },
      {
        "value": "C",
        "text": "11.43"
      },
      {
        "value": "D",
        "text": "5.08"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Q₁=5.7 m³/s; p₁=5.08 cm water; N₁=400 rpm",
      "Target Q₂=7.05 m³/s"
    ],
    "formula": "Q\\propto N;\\quad p\\propto N^2",
    "formulaReason": "This problem is classified as Fan Laws & Pressure. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "N₂=N₁(Q₂/Q₁)=400(7.05/5.7)=494.74 rpm.",
    "calculation": [
      "Use Q∝N: N₂≈494.74 rpm.",
      "Use pressure∝N²: p₂=5.08(494.74/400)²≈7.77 cm water."
    ],
    "finalAnswer": "A — 7.77 cm water",
    "unitCheck": "The speed ratio is dimensionless, so pressure remains in cm of water.",
    "concept": "For the same fan and installation, flow is proportional to rotational speed and pressure is proportional to speed squared.",
    "shortcutFormula": "Q\\propto N;\\quad p\\propto N^2",
    "shortcut": "Find the new rpm from the flow ratio, then square the speed ratio for pressure.",
    "commonMistakes": [
      "Do not scale pressure linearly with flow.",
      "Fan laws assume the same fan and comparable operating conditions."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 132; original PDF page 40; extracted PDF page 21",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 40,
    "sourceExtractedPdfPage": 21,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=21",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q Nt Q Np 5.7 400 705 Ny N, = 494.74 rpm ma = ()’ hy Np 5.08 _ (202.)\" hy 494.74 h, = 7.77 cm of water",
    "sourceChoicesOriginalOrder": [
      "A. 7.77",
      "B. 17.14",
      "C. 11.43",
      "D. 5.08"
    ],
    "id": "bluebook-aircon-132",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=21"
  },
  {
    "sourceProblemNumber": 151,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Refrigerator Internal Heat Load & Energy Cost",
    "difficulty": "Intermediate",
    "prompt": "Consider a refrigerator whose 40 watts light bulb remains on continuously as a result of a malfunction of the switch. If the refrigerator has a COP of 1.3 and the cost of electricity is 8 cents per kW-hr, determine the increase in the energy consumption of the refrigerator and its cost per year if the switch is not fixed.",
    "options": [
      {
        "value": "A",
        "text": "P 49.59"
      },
      {
        "value": "B",
        "text": "P 47.59"
      },
      {
        "value": "C",
        "text": "P 45.59"
      },
      {
        "value": "D",
        "text": "P 43.59"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Light bulb load = 40 W, continuously",
      "COP = 1.3",
      "Electricity cost stated as 8 cents/kWh"
    ],
    "formula": "COP=\\frac{Q_L}{W};\\quad W=Q_L/COP",
    "formulaReason": "This problem is classified as Refrigerator Internal Heat Load & Energy Cost. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "W_ref = 40/1.3 = 30.77 W; total power counted by the source = 40+30.77 = 70.77 W.",
    "calculation": [
      "Compressor work associated with the 40 W heat load: 40/1.3≈30.77 W.",
      "Source total increment = 40+30.77=70.77 W = 0.07077 kW.",
      "Annual energy ≈ 0.07077(8760)=620 kWh; at 0.08 currency units/kWh, cost ≈49.59 currency units."
    ],
    "finalAnswer": "Source solution: A — P 49.59 (UNVERIFIED currency/wording)",
    "unitCheck": "kW × hours = kWh; multiplying by tariff gives currency per year.",
    "concept": "A light left on inside the refrigerated space adds a heat load; the refrigerator must remove that load using additional electrical work.",
    "shortcutFormula": "COP=\\frac{Q_L}{W};\\quad W=Q_L/COP",
    "shortcut": "Convert the internal heat load to required refrigerator work using COP, then annualize power in kWh.",
    "commonMistakes": [
      "The source prompt says “8 cents” but its solution labels the answer with P; currency should be reconciled.",
      "Distinguish the light’s electrical input from the additional compressor work."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 151; original PDF page 45; extracted PDF page 22",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 45,
    "sourceExtractedPdfPage": 22,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=22",
    "sourceAnswerStatus": "Source discrepancy or incomplete solution; not approved for scoring.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: = REL COP = Wee 40 Wret = 30,769 watts W = W, + Weer = 40 + 30.769 = 70.77 watts W = 0.07077 kw Cost = 0.07077(8760)(P 0.08) = P 49.59",
    "sourceChoicesOriginalOrder": [
      "A. P 49.59",
      "B. P 47.59",
      "C. P 45.59",
      "D. P 43.59"
    ],
    "id": "bluebook-aircon-151",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=22"
  },
  {
    "sourceProblemNumber": 152,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Motor Efficiency & Room Heat Gain",
    "difficulty": "Intermediate",
    "prompt": "A 75 hp motor that has an efficiency of 91% is worn out and is replaced by a high-efficiency motor that has an efficiency of 95.4%. Determine the reduction in heat gain of the room due to higher efficiency under full-load conditions.",
    "options": [
      {
        "value": "A",
        "text": "2.24 kW"
      },
      {
        "value": "B",
        "text": "2.44 kW"
      },
      {
        "value": "C",
        "text": "2.64 kW"
      },
      {
        "value": "D",
        "text": "2.84 kW"
      }
    ],
    "answer": "D",
    "answerVerified": false,
    "given": [
      "Motor rated output = 75 hp",
      "Old efficiency = 91%",
      "Replacement efficiency = 95.4%"
    ],
    "formula": "P_{in}=P_{out}/\\eta;\\quad Q_{loss}=P_{in}-P_{out}",
    "formulaReason": "This problem is classified as Motor Efficiency & Room Heat Gain. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "P_out=75(0.746)=55.95 kW; P_in,old=55.95/0.91; P_in,new=55.95/0.954.",
    "calculation": [
      "P_out = 75×0.746 = 55.95 kW.",
      "Old input ≈55.95/0.91=61.48 kW; new input ≈55.95/0.954=58.65 kW.",
      "Reduction in motor losses ≈61.48−58.65=2.84 kW (choice D).",
      "The reproduced source solution appears to multiply the rated output by the efficiencies and reports 2.44 kW (B); its arithmetic/method differs."
    ],
    "finalAnswer": "Independent calculation D — 2.84 kW; source reports B — 2.44 kW (UNVERIFIED)",
    "unitCheck": "hp×0.746 gives kW; the difference between input powers is kW.",
    "concept": "Motor losses appearing as room heat decrease when input power needed to deliver the same shaft output decreases.",
    "shortcutFormula": "P_{in}=P_{out}/\\eta;\\quad Q_{loss}=P_{in}-P_{out}",
    "shortcut": "For a fixed shaft output, calculate electrical input as output divided by efficiency—not multiplied by efficiency.",
    "commonMistakes": [
      "Do not multiply shaft output by efficiency when finding input power.",
      "Keep source answer and independently recalculated answer distinct."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 152; original PDF page 46; extracted PDF page 23",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 46,
    "sourceExtractedPdfPage": 23,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=23",
    "sourceAnswerStatus": "Independent calculation differs from the printed solution; left unverified until reviewed.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: P, = 75 x 0.746(0.91) = 50.91 kw P, = 75 x 0.746(0.954) = 53.376 kw Qreduced = 53-376 — 50.91 = 2.44 kw",
    "sourceChoicesOriginalOrder": [
      "A. 2.24 kW",
      "B. 2.44 kW",
      "C. 2.64 kW",
      "D. 2.84 kW"
    ],
    "id": "bluebook-aircon-152",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=23"
  },
  {
    "sourceProblemNumber": 153,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Refrigerator Cooling Time",
    "difficulty": "Intermediate",
    "prompt": "A household refrigerator that has a power input of 450 watts and a COP of 2.5 is to cool five large watermelons, 10 kg each, to 8°C. If the watermelons are initially at 20°C, determine how long it will take for the refrigerator to cool them. The watermelons can be treated as water whose specific heat is 4.2 kJ/kg-K.",
    "options": [
      {
        "value": "A",
        "text": "2220 seconds"
      },
      {
        "value": "B",
        "text": "2230 seconds"
      },
      {
        "value": "C",
        "text": "2240 seconds"
      },
      {
        "value": "D",
        "text": "2250 seconds"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Five watermelons × 10 kg = 50 kg",
      "20°C to 8°C",
      "c_p=4.2 kJ/(kg·K)",
      "Power input = 450 W; COP=2.5"
    ],
    "formula": "Q=m c_p\\Delta T;\\quad t=Q/\\dot Q_L",
    "formulaReason": "This problem is classified as Refrigerator Cooling Time. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇_L=COP·W=2.5(0.450)=1.125 kW; Q=50(4.2)(20−8).",
    "calculation": [
      "Cooling capacity Q̇_L=2.5(0.450)=1.125 kW = 1.125 kJ/s.",
      "Q=50(4.2)(12)=2520 kJ.",
      "t=2520/1.125=2240 s."
    ],
    "finalAnswer": "C — 2240 seconds",
    "unitCheck": "kJ divided by kJ/s gives seconds.",
    "concept": "The required cooling energy is sensible heat m c_p ΔT; time equals energy divided by cooling rate.",
    "shortcutFormula": "Q=m c_p\\Delta T;\\quad t=Q/\\dot Q_L",
    "shortcut": "Compute cooling capacity from COP×input power, then divide total sensible load by that capacity.",
    "commonMistakes": [
      "Convert W to kW (or kJ/s).",
      "Use the total mass of all five watermelons."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 153; original PDF page 46; extracted PDF page 24",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 46,
    "sourceExtractedPdfPage": 24,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=24",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: RE COP = W 25-22 450 RE = 1,125 watts = 1.125 kilowatts RE = mo, (T, — T,) 1.125t = 10 x 5(4.2)(20- 8) t = 2240 seconds",
    "sourceChoicesOriginalOrder": [
      "A. 2220 seconds",
      "B. 2230 seconds",
      "C. 2240 seconds",
      "D. 2250 seconds"
    ],
    "id": "bluebook-aircon-153",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=24"
  },
  {
    "sourceProblemNumber": 154,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Room Air Cooling & COP",
    "difficulty": "Intermediate",
    "prompt": "When a man returns to his wall-sealed house on a summer day, he finds that the house is at 32°C. He returns on the air conditioner which cools the entire house to 20°C in 15 minutes. If COP is 2.5, determine the power drawn by the air conditioner. Assume the entire mass within the house is 800 kg of air for which cv = 0.72 kJ/kg-K, cp = 1.0 kJ/kg-K.",
    "options": [
      {
        "value": "A",
        "text": "1.072 kW"
      },
      {
        "value": "B",
        "text": "2.072 kW"
      },
      {
        "value": "C",
        "text": "3.072 kW"
      },
      {
        "value": "D",
        "text": "4.072 kW"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Air mass = 800 kg",
      "32°C to 20°C in 15 min",
      "c_v=0.72 kJ/(kg·K)",
      "COP=2.5"
    ],
    "formula": "\\dot Q=\\frac{m c_v\\Delta T}{\\Delta t};\\quad W=\\dot Q/COP",
    "formulaReason": "This problem is classified as Room Air Cooling & COP. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇=800(0.72)(32−20)/(15×60)=7.68 kW.",
    "calculation": [
      "Heat removed per time: Q̇=800(0.72)(12)/900=7.68 kW.",
      "Input power = Q̇/COP=7.68/2.5=3.072 kW."
    ],
    "finalAnswer": "C — 3.072 kW",
    "unitCheck": "kJ/s = kW; input power is also kW.",
    "concept": "For a sealed room treated as a fixed mass of air, the internal-energy change is m c_v ΔT. COP relates cooling rate to input power.",
    "shortcutFormula": "\\dot Q=\\frac{m c_v\\Delta T}{\\Delta t};\\quad W=\\dot Q/COP",
    "shortcut": "Calculate heat removal in kW first, then divide by COP.",
    "commonMistakes": [
      "Use c_v for internal-energy change of a fixed-volume closed mass, as assumed by the source.",
      "Convert 15 minutes to seconds."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 154; original PDF page 46; extracted PDF page 25",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 46,
    "sourceExtractedPdfPage": 25,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=25",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: RE = the, (T, — T,) = (=) (0.72) (32 — 20) = 7.68 kW p=2£ 78 _3 972kw COP 2.5",
    "sourceChoicesOriginalOrder": [
      "A. 1.072 kW",
      "B. 2.072 kW",
      "C. 3.072 kW",
      "D. 4.072 kW"
    ],
    "id": "bluebook-aircon-154",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=25"
  },
  {
    "sourceProblemNumber": 171,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Human Heat Gain: Convection & Radiation",
    "difficulty": "Intermediate",
    "prompt": "Consider a person standing in a breezy room at 20°C. Determine the total rate of heat transfer from this person if the exposed surface area and the average outer surface temperature of the person are 1.6 m2 and 29°C, respectively, and the convection heat transfer coefficient is 6 W/m2 with emissivity factor of 0.95.",
    "options": [
      {
        "value": "A",
        "text": "86.40 watts"
      },
      {
        "value": "B",
        "text": "81.70 watts"
      },
      {
        "value": "C",
        "text": "198.1 watts"
      },
      {
        "value": "D",
        "text": "168.1 watts"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Area = 1.6 m²",
      "Surface = 29°C; room air = 20°C",
      "h = 6 W/(m²·K)",
      "Emissivity = 0.95"
    ],
    "formula": "\\dot Q=hA(T_s-T_\\infty)+\\epsilon\\sigma A(T_s^4-T_\\infty^4)",
    "formulaReason": "This problem is classified as Human Heat Gain: Convection & Radiation. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇_conv=6(1.6)(29−20)=86.4 W; evaluate radiation using absolute temperatures in kelvin.",
    "calculation": [
      "Convection: Q̇_conv=86.4 W.",
      "Radiation: Q̇_rad≈81.7 W using T_s=302 K, T_room=293 K.",
      "Total Q̇≈86.4+81.7=168.1 W."
    ],
    "finalAnswer": "D — 168.1 W",
    "unitCheck": "Both components are watts.",
    "concept": "A person loses heat by both convection to the air and thermal radiation to surrounding surfaces.",
    "shortcutFormula": "\\dot Q=hA(T_s-T_\\infty)+\\epsilon\\sigma A(T_s^4-T_\\infty^4)",
    "shortcut": "Compute convection and radiation separately, then add the heat-transfer rates.",
    "commonMistakes": [
      "Radiation temperatures must be in kelvin.",
      "Do not omit either the convective or radiative contribution."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 171; original PDF page 51; extracted PDF page 26",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 51,
    "sourceExtractedPdfPage": 26,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=26",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q, =hA(t, —t,) = 6(1.6)(29.20) = 86.40 watts Q, = 0.95 (5.67 x 10°) (1.6)[(29 + 273)4 — (20 + 273)4] = 81.7 watts Q=0,+ 0, = 86.404 817 = 168.1 watts",
    "sourceChoicesOriginalOrder": [
      "A. 86.40 watts",
      "B. 81.70 watts",
      "C. 198.1 watts",
      "D. 168.1 watts"
    ],
    "id": "bluebook-aircon-171",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=26"
  },
  {
    "sourceProblemNumber": 177,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Food Freezing Load",
    "difficulty": "Intermediate",
    "prompt": "A supply of 50 kg of chicken at 6°C contained in a box is to be frozen to -18°C in a freezer. Determine the amount of heat that needs to be removed. The latent heat of the chicken is 247 kJ/kg, and its specific heat is 3.32 kJ/kg-°C above freezing and 1.77 kJ/kg-°C below freezing. The container box is 1.5 kg, and the specific heat of the box material is 1.4 kJ/kg-°C. Also the freezing temperature of chicken is -2.8°C.",
    "options": [
      {
        "value": "A",
        "text": "15,206.4 kJ"
      },
      {
        "value": "B",
        "text": "50.4 kJ"
      },
      {
        "value": "C",
        "text": "15,156 kJ"
      },
      {
        "value": "D",
        "text": "1,863 kJ"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Chicken = 50 kg; 6°C to −18°C",
      "Freezing point = −2.8°C",
      "Latent heat = 247 kJ/kg",
      "c_p above = 3.32; below = 1.77 kJ/(kg·°C)",
      "Box = 1.5 kg; c_box=1.4 kJ/(kg·°C)"
    ],
    "formula": "Q=m[c_{p,+}(T_i-T_f)+h_f+c_{p,-}(T_f-T_o)]+m_b c_b(T_i-T_o)",
    "formulaReason": "This problem is classified as Food Freezing Load. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q_chicken=50[3.32(6+2.8)+247+1.77(−2.8+18)]; Q_box=1.5(1.4)(6+18).",
    "calculation": [
      "Chicken load = 50[3.32(8.8)+247+1.77(15.2)] = 15,156 kJ.",
      "Box sensible load = 1.5(1.4)(24)=50.4 kJ.",
      "Total Q=15,156+50.4=15,206.4 kJ."
    ],
    "finalAnswer": "A — 15,206.4 kJ",
    "unitCheck": "kg×kJ/kg= kJ.",
    "concept": "Food freezing requires sensible cooling above freezing, latent heat removal during phase change, and sensible cooling below freezing. The box also absorbs heat.",
    "shortcutFormula": "Q=m[c_{p,+}(T_i-T_f)+h_f+c_{p,-}(T_f-T_o)]+m_b c_b(T_i-T_o)",
    "shortcut": "Split the product load into pre-freezing sensible, latent, and post-freezing sensible parts; add container load.",
    "commonMistakes": [
      "Do not omit latent heat.",
      "Use the correct specific heat above and below the freezing point."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 177; original PDF page 52; extracted PDF page 27",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 52,
    "sourceExtractedPdfPage": 27,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=27",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Qchicken = 50[3.32(6 + 2.8) + 247 + 1.77(-2.8 + 18)] = 15,156 kj Qhox = 1.5(1.4) (6 + 18) = 50.4 kJ Q = 15,156 + 50.4 = 15,206.4 kj",
    "sourceChoicesOriginalOrder": [
      "A. 15,206.4 kJ",
      "B. 50.4 kJ",
      "C. 15,156 kJ",
      "D. 1,863 kJ"
    ],
    "id": "bluebook-aircon-177",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=27"
  },
  {
    "sourceProblemNumber": 179,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Room Cooling Load & Unit Count",
    "difficulty": "Intermediate",
    "prompt": "A classroom that normally contains 40 people is to be air-conditioned with window air- conditioning units of 5 kW cooling capacity. A person at rest may be assumed to dissipate heat at a rate about 360 kJ/hr. There are 10 light bulbs in the room, each with a rating of 100 watts. The rate of heat transfer to the classroom through the walls and the windows is estimated to be 15,000 kJ/hr. If the room is to be maintained at a constant temperature of 21°C, determine the number of window air-conditioning units required.",
    "options": [
      {
        "value": "A",
        "text": "1 units"
      },
      {
        "value": "B",
        "text": "2 units"
      },
      {
        "value": "C",
        "text": "3 units"
      },
      {
        "value": "D",
        "text": "4 units"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "40 people at 360 kJ/hr each",
      "10 lamps × 100 W",
      "Wall/window gain = 15,000 kJ/hr",
      "Each AC unit capacity = 5 kW"
    ],
    "formula": "\\dot Q_{total}=\\dot Q_{people}+\\dot Q_{lights}+\\dot Q_{envelope}",
    "formulaReason": "This problem is classified as Room Cooling Load & Unit Count. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q_people=40(360) kJ/hr; Q_lights=10(0.1) kW; Q_envelope=15,000 kJ/hr.",
    "calculation": [
      "People: 40(360)=14,400 kJ/hr = 4.0 kW.",
      "Lights: 10×100 W = 1.0 kW.",
      "Walls/windows: 15,000/3600=4.167 kW.",
      "Total ≈9.167 kW; N=9.167/5=1.833, so round up to 2 units."
    ],
    "finalAnswer": "B — 2 units",
    "unitCheck": "Every heat-load term must be converted to kW before summing.",
    "concept": "Sum the sensible loads and divide by the available capacity per unit. A fractional number of units must be rounded up.",
    "shortcutFormula": "\\dot Q_{total}=\\dot Q_{people}+\\dot Q_{lights}+\\dot Q_{envelope}",
    "shortcut": "Convert every load to kW, sum, then divide by 5 kW per unit and round up.",
    "commonMistakes": [
      "Do not add kJ/hr directly to kW.",
      "Always round the required number of units up to the next whole unit."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 179; original PDF page 53; extracted PDF page 28",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 53,
    "sourceExtractedPdfPage": 28,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=28",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q = total heat load = 40(360)(3600) + 10(0.100) + —_ = 9.167 kW No.of air — conditioning = —_ = 1.833 = 2 units",
    "sourceChoicesOriginalOrder": [
      "A. 1 units",
      "B. 2 units",
      "C. 3 units",
      "D. 4 units"
    ],
    "id": "bluebook-aircon-179",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=28"
  },
  {
    "sourceProblemNumber": 181,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Closed-Room Fan Heat & Air Temperature",
    "difficulty": "Intermediate",
    "prompt": "A student living in a 4 m x 6 m x 6 m dormitory room turns on her 150 watts fan before she leaves the room on a summer day, hoping that the room will be cooler when she comes back in the evening. Assuming all the doors and windows are tightly closed and disregarding any heat transfer through the walls and the windows, determine the temperature in the room when she comes back 10 hours later. Use specific heat values at room temperature, and assume the room to be at 100 kPa and 15°C in the morning when she leaves.",
    "options": [
      {
        "value": "A",
        "text": "28.13°C"
      },
      {
        "value": "B",
        "text": "38.13°C"
      },
      {
        "value": "C",
        "text": "48.13°C"
      },
      {
        "value": "D",
        "text": "58.13°C"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Room volume = 4×6×6 = 144 m³",
      "Fan power = 150 W",
      "Initial P=100 kPa and T=15°C",
      "Elapsed time = 10 hr"
    ],
    "formula": "P\\Delta t=m c_v(T_2-T_1)",
    "formulaReason": "This problem is classified as Closed-Room Fan Heat & Air Temperature. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "ρ=P/(RT)=100/[0.287(15+273)]≈1.2098 kg/m³; m=ρV≈174.2 kg.",
    "calculation": [
      "Air mass ≈1.2098(144)=174.2 kg.",
      "Fan energy =0.150 kW×10 hr =5400 kJ.",
      "5400=174.2(0.7186)(T₂−15); T₂≈58.1°C."
    ],
    "finalAnswer": "D — 58.13°C",
    "unitCheck": "kW·hr converted to kJ; kJ divided by kg·kJ/(kg·K) gives K.",
    "concept": "In a sealed room with wall heat transfer neglected, fan electrical energy ultimately becomes internal energy of the room air in the source model.",
    "shortcutFormula": "P\\Delta t=m c_v(T_2-T_1)",
    "shortcut": "Find air mass from ideal gas density, then use energy input = m c_v ΔT.",
    "commonMistakes": [
      "Convert fan watts to kW and hours to seconds or kJ consistently.",
      "Do not assume a fan cools a sealed room; the electrical input increases air energy under these assumptions."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 181; original PDF page 54; extracted PDF page 29",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 54,
    "sourceExtractedPdfPage": 29,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=29",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: P 100 m = 1.2098(4 x 6 x 6) = 174.216 kg Q=mc,(t, — t,) 0.15(10 x 3600) = 174.216(0.7186)(t, — 15) ty = 58.13°C",
    "sourceChoicesOriginalOrder": [
      "A. 28.13°C",
      "B. 38.13°C",
      "C. 48.13°C",
      "D. 58.13°C"
    ],
    "id": "bluebook-aircon-181",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=29"
  },
  {
    "sourceProblemNumber": 184,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Fan Power, Head & Velocity",
    "difficulty": "Intermediate",
    "prompt": "A fan is powered by 0.5 hp motor and delivers air at a rate of 85 m3/min. Determine the highest value for the average velocity of air mobilized by the fan. Take the density of air to be 1.18 kg/m3.",
    "options": [
      {
        "value": "A",
        "text": "18.23 m/s"
      },
      {
        "value": "B",
        "text": "21.12 m/s"
      },
      {
        "value": "C",
        "text": "25.34 m/s"
      },
      {
        "value": "D",
        "text": "32.23 m/s"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Motor power = 0.5 hp",
      "Flow = 85 m³/min",
      "Air density = 1.18 kg/m³"
    ],
    "formula": "P=\\rho g\\dot V H;\\quad V=\\sqrt{2gH}",
    "formulaReason": "This problem is classified as Fan Power, Head & Velocity. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "0.5(0.746)=1.18(0.00981)(85/60)H.",
    "calculation": [
      "Using fan power relation, H≈22.74 m.",
      "V=√[2(9.81)(22.74)]≈21.12 m/s."
    ],
    "finalAnswer": "B — 21.12 m/s",
    "unitCheck": "Convert m³/min to m³/s and hp to kW.",
    "concept": "Idealized fan power relates to volume flow, fluid density, gravity, and total head; velocity follows from head.",
    "shortcutFormula": "P=\\rho g\\dot V H;\\quad V=\\sqrt{2gH}",
    "shortcut": "Calculate head from power first, then compute V=√(2gH).",
    "commonMistakes": [
      "Convert flow per minute to flow per second.",
      "Do not use the 85 m³/min value directly as m³/s."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 184; original PDF page 55; extracted PDF page 30",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 55,
    "sourceExtractedPdfPage": 30,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=30",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: P =yQh 85 0.50(0.746) = 1.18 x 0.00981 (=)n h=22.74m V = /2(9.81)(22.74) = 21.12 m/s",
    "sourceChoicesOriginalOrder": [
      "A. 18.23 m/s",
      "B. 21.12 m/s",
      "C. 25.34 m/s",
      "D. 32.23 m/s"
    ],
    "id": "bluebook-aircon-184",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=30"
  },
  {
    "sourceProblemNumber": 195,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Room Ventilation Failure & Temperature Rise",
    "difficulty": "Intermediate",
    "prompt": "The rate of heat transfer to the surroundings from a person at rest is 400 kJ/hr. Suppose that the ventilation system fails in an auditorium containing 120 people and assuming that the energy goes into the air of volume 1500 m3 initially at 300 K and 101 kPa, calculate the rate in °C /min of air temperature change.",
    "options": [
      {
        "value": "A",
        "text": "0.81"
      },
      {
        "value": "B",
        "text": "0.53"
      },
      {
        "value": "C",
        "text": "0.63"
      },
      {
        "value": "D",
        "text": "1.0"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Heat output = 400 kJ/hr per person",
      "People = 120",
      "Room volume = 1500 m³",
      "Initial T=300 K, P=101 kPa"
    ],
    "formula": "\\dot Q=\\frac{m c_v\\Delta T}{\\Delta t};\\quad m=\\frac{PV}{RT}",
    "formulaReason": "This problem is classified as Room Ventilation Failure & Temperature Rise. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Use PV=mRT to find air mass; total heat input is 120(400 kJ/hr).",
    "calculation": [
      "Find air mass from m=PV/(R T), using consistent kPa·m³ and kJ units.",
      "Apply Q̇_total=m_people(400 kJ/hr) and divide by m_air c_v to find the temperature rise rate.",
      "Source result: ΔT/Δt≈0.63°C/min."
    ],
    "finalAnswer": "C — 0.63°C/min",
    "unitCheck": "Convert kJ/hr to kJ/min before calculating °C/min.",
    "concept": "With ventilation failed and all occupant heat added to the air, the air temperature rise rate is the heat-input rate divided by air thermal capacity.",
    "shortcutFormula": "\\dot Q=\\frac{m c_v\\Delta T}{\\Delta t};\\quad m=\\frac{PV}{RT}",
    "shortcut": "Compute air mass first, then use heat rate/(m c_v).",
    "commonMistakes": [
      "Use all 120 people in the heat input.",
      "Convert the hourly heat rate to the same time base as the final answer."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 195; original PDF page 58; extracted PDF page 31",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 58,
    "sourceExtractedPdfPage": 31,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=31",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q = mc, At PV = mnRT 101(1500) = m(0.287)(300) m = 1759.58 kg/min 120 (*2) = 1759.58(0.7186)At 60 At = 0.63°C/min",
    "sourceChoicesOriginalOrder": [
      "A. 0.81",
      "B. 0.53",
      "C. 0.63",
      "D. 1.0"
    ],
    "id": "bluebook-aircon-195",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=31"
  },
  {
    "sourceProblemNumber": 210,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Thermoelectric Refrigerator Power",
    "difficulty": "Intermediate",
    "prompt": "A thermoelectric refrigerator that resembles a small ice chest is powered by a car battery, and has a COP of 0.10. If the refrigerator cools a 0.350 L canned drink from 20°C to 4°C in 30 min, determine the average electric power consumed by the thermoelectric refrigerator.",
    "options": [
      {
        "value": "A",
        "text": "130 watts"
      },
      {
        "value": "B",
        "text": "110 watts"
      },
      {
        "value": "C",
        "text": "120 watts"
      },
      {
        "value": "D",
        "text": "140 watts"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Drink volume = 0.350 L ≈ 0.350 kg",
      "20°C to 4°C in 30 min",
      "COP=0.10",
      "c_p≈4.187 kJ/(kg·K)"
    ],
    "formula": "COP=\\dot Q_L/W;\\quad \\dot Q_L=mc_p\\Delta T/\\Delta t",
    "formulaReason": "This problem is classified as Thermoelectric Refrigerator Power. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇_L=0.350(4.187)(20−4)/(30×60)≈0.013 W? kJ/s; W=Q̇_L/COP.",
    "calculation": [
      "Cooling energy Q≈0.350(4.187)(16)=23.45 kJ.",
      "Cooling rate ≈23.45/(1800)=0.0130 kW=13.0 W.",
      "Electrical input =13.0/0.10≈130 W."
    ],
    "finalAnswer": "A — 130 W",
    "unitCheck": "kJ/s = kW; multiply by 1000 to express watts.",
    "concept": "A small COP means the device needs much more electrical power than the cooling rate it provides.",
    "shortcutFormula": "COP=\\dot Q_L/W;\\quad \\dot Q_L=mc_p\\Delta T/\\Delta t",
    "shortcut": "Calculate sensible cooling energy, divide by time, then divide the cooling rate by COP.",
    "commonMistakes": [
      "Convert 30 min to 1800 s.",
      "COP = cooling rate/input power, so input power is cooling rate divided by COP."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 210; original PDF page 62; extracted PDF page 32",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 62,
    "sourceExtractedPdfPage": 32,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=32",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q =the, (t, —t,) = Se; (4.187)(20— 4) = 13 watts = RE CoP = <= = +. = 130 watts",
    "sourceChoicesOriginalOrder": [
      "A. 130 watts",
      "B. 110 watts",
      "C. 120 watts",
      "D. 140 watts"
    ],
    "id": "bluebook-aircon-210",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=32"
  },
  {
    "sourceProblemNumber": 211,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Carnot Refrigerator Cooling Rate",
    "difficulty": "Intermediate",
    "prompt": "A Carnot refrigerator operates in a room in which the temperature is 25°C and consumes 2 kW of power when operating. If the food compartment of the refrigerator is to be maintained at 3°C, determine the rate of heat removal from the food compartment.",
    "options": [
      {
        "value": "A",
        "text": "1504.8 kJ/min"
      },
      {
        "value": "B",
        "text": "12.86 kJ/min"
      },
      {
        "value": "C",
        "text": "1625 kJ/min"
      },
      {
        "value": "D",
        "text": "9.57 kJ/min"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Room temperature = 25°C",
      "Cold space = 3°C",
      "Power = 2 kW"
    ],
    "formula": "COP_R=\\frac{T_L}{T_H-T_L};\\quad \\dot Q_L=COP_R W",
    "formulaReason": "This problem is classified as Carnot Refrigerator Cooling Rate. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "COP_R=(3+273)/[(25+273)−(3+273)]≈12.54.",
    "calculation": [
      "Convert temperatures to kelvin: T_H=298 K, T_L=276 K.",
      "COP_R=276/(298−276)≈12.55 (source uses about 12.54).",
      "Q̇_L=COP×2 kW; convert kJ/s to kJ/min: ≈1504.8 kJ/min."
    ],
    "finalAnswer": "A — 1504.8 kJ/min",
    "unitCheck": "kW = kJ/s; multiply by 60 to obtain kJ/min.",
    "concept": "The ideal Carnot refrigerator COP depends on the two absolute reservoir temperatures.",
    "shortcutFormula": "COP_R=\\frac{T_L}{T_H-T_L};\\quad \\dot Q_L=COP_R W",
    "shortcut": "Convert °C to K, compute Carnot COP, then multiply by input power.",
    "commonMistakes": [
      "Use kelvin in the Carnot ratio.",
      "Multiply COP by input power to get cooling rate."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 211; original PDF page 62; extracted PDF page 33",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 62,
    "sourceExtractedPdfPage": 33,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=33",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: _ th 34273 _ COP = Ty-T, (25+273)-(3+273) _ 12.54 Q, = COP x W = 12.54 x 2(60) = 1504.8 kJ/min",
    "sourceChoicesOriginalOrder": [
      "A. 1504.8 kJ/min",
      "B. 12.86 kJ/min",
      "C. 1625 kJ/min",
      "D. 9.57 kJ/min"
    ],
    "id": "bluebook-aircon-211",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=33"
  },
  {
    "sourceProblemNumber": 212,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Refrigerator Heat Rejection & EER",
    "difficulty": "Intermediate",
    "prompt": "A household refrigerator with EER 8.0 removes heat from the refrigerated space at a rate of 90 kJ/min. Determine the rate of heat transfer to the kitchen air.",
    "options": [
      {
        "value": "A",
        "text": "101.25 kJ/min"
      },
      {
        "value": "B",
        "text": "63.05 kJ/min"
      },
      {
        "value": "C",
        "text": "128.46 kJ/min"
      },
      {
        "value": "D",
        "text": "80 kJ/min"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "EER = 8.0",
      "Cooling rate = 90 kJ/min"
    ],
    "formula": "COP=EER/3.412;\\quad Q_H=Q_L+W",
    "formulaReason": "This problem is classified as Refrigerator Heat Rejection & EER. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "COP=8/3.412≈2.34; W=Q_L/COP; Q_H=Q_L+W.",
    "calculation": [
      "COP≈8/3.412=2.34.",
      "W≈90/2.34=38.46 kJ/min.",
      "Q_H=90+38.46≈128.46 kJ/min."
    ],
    "finalAnswer": "C — 128.46 kJ/min",
    "unitCheck": "All heat rates are kJ/min.",
    "concept": "Heat rejected at the condenser equals the cooling rate plus compressor work input.",
    "shortcutFormula": "COP=EER/3.412;\\quad Q_H=Q_L+W",
    "shortcut": "Convert EER to COP, calculate input work, and add it to the cooling rate.",
    "commonMistakes": [
      "Do not confuse heat rejected with cooling capacity.",
      "EER needs conversion to COP before using energy balance."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 212; original PDF page 62; extracted PDF page 34",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 62,
    "sourceExtractedPdfPage": 34,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=34",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: cop = FR = 8 =234 3.412 3.412 _— Oa __ 90 COP ~ Qu-Q. 2.34 Quy-90 Qy = 128.46 kJ/min",
    "sourceChoicesOriginalOrder": [
      "A. 101.25 kJ/min",
      "B. 63.05 kJ/min",
      "C. 128.46 kJ/min",
      "D. 80 kJ/min"
    ],
    "id": "bluebook-aircon-212",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=34"
  },
  {
    "sourceProblemNumber": 213,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Air-Conditioning Power & Carnot COP",
    "difficulty": "Intermediate",
    "prompt": "An air-conditioning system is used to maintain a house at 75°F when the temperature outside is 95°F. The house is gaining the heat through the walls and windows at a rate of 1250 Btu/min, and the heat generation rate within the house from people, lights, and appliances amounts to 350 Btu/min. Determine the minimum power input required for this air- conditioning system.",
    "options": [
      {
        "value": "A",
        "text": "10.06 hp"
      },
      {
        "value": "B",
        "text": "1.36 hp"
      },
      {
        "value": "C",
        "text": "1.41 hp"
      },
      {
        "value": "D",
        "text": "7.94 hp"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Indoor temperature = 75°F",
      "Outdoor temperature = 95°F",
      "Wall/window gain = 1250 Btu/min",
      "Internal gain = 350 Btu/min"
    ],
    "formula": "COP_R=\\frac{T_L}{T_H-T_L};\\quad W=\\dot Q_L/COP_R",
    "formulaReason": "This problem is classified as Air-Conditioning Power & Carnot COP. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇_L=1250+350=1600 Btu/min; COP_R=(75+460)/[(95+460)−(75+460)]≈26.75.",
    "calculation": [
      "Total load =1600 Btu/min.",
      "Carnot COP using absolute Fahrenheit scale (°R) ≈26.75.",
      "Input power ≈1600/26.75=59.8 Btu/min; divide by 42.4 Btu/min per hp ≈1.41 hp."
    ],
    "finalAnswer": "C — 1.41 hp",
    "unitCheck": "Convert temperature to °R for the Carnot equation and Btu/min to hp for the final answer.",
    "concept": "The required input power is cooling load divided by the ideal COP between the indoor and outdoor temperatures.",
    "shortcutFormula": "COP_R=\\frac{T_L}{T_H-T_L};\\quad W=\\dot Q_L/COP_R",
    "shortcut": "Add heat gains, calculate Carnot COP on an absolute scale, and divide load by COP.",
    "commonMistakes": [
      "Use °R, not °F, for the Carnot ratio.",
      "Sum both envelope and internal heat gains."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 213; original PDF page 63; extracted PDF page 35",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 63,
    "sourceExtractedPdfPage": 35,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=35",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q,, = 1250 + 350 = 1600 Btu/min cop == 75 +460 = 26.75 Ty-T, (954460) —(75+460) 4 1600 No— XL. — 26.75 — W= COP 42,4 1.41 hp",
    "sourceChoicesOriginalOrder": [
      "A. 10.06 hp",
      "B. 1.36 hp",
      "C. 1.41 hp",
      "D. 7.94 hp"
    ],
    "id": "bluebook-aircon-213",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=35"
  },
  {
    "sourceProblemNumber": 214,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Bread Cooling / Product Load",
    "difficulty": "Intermediate",
    "prompt": "A refrigeration system is to cool bread loaves with an average mass of 450 g from 22°C to - 10°C at a rate of 500 loaves per hour by refrigerated air. Taking the average specific and latent heats of bread to be 2.93 kJ/kg-°C and 109.3 kJ/kg, respectively, determine the product load.",
    "options": [
      {
        "value": "A",
        "text": "541.7 kJ/min"
      },
      {
        "value": "B",
        "text": "351.6 kJ/min"
      },
      {
        "value": "C",
        "text": "761.5 kJ/min"
      },
      {
        "value": "D",
        "text": "409.9 kJ/min"
      }
    ],
    "answer": "C",
    "answerVerified": false,
    "given": [
      "500 loaves/hr, 0.450 kg each",
      "22°C to −10°C",
      "c_p=2.93 kJ/(kg·°C)",
      "Latent heat =109.3 kJ/kg"
    ],
    "formula": "\\dot Q=\\dot m[c_p\\Delta T+h_f]",
    "formulaReason": "This problem is classified as Bread Cooling / Product Load. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "ṁ=500(0.45)=225 kg/hr; printed method uses 225[2.93(22−(−10))+109.3].",
    "calculation": [
      "Mass rate =225 kg/hr.",
      "Printed source calculation: Q≈225(2.93)(32)+225(109.3)=45,688.5 kJ/hr =761.5 kJ/min.",
      "The printed expression treats the entire 32°C span as sensible cooling and adds latent heat; the temperature of phase change and any below-freezing specific heat are not provided. Keep the source result unverified."
    ],
    "finalAnswer": "Source reports C — 761.5 kJ/min (UNVERIFIED: below-freezing sensible cooling appears omitted)",
    "unitCheck": "kg/hr × kJ/kg gives kJ/hr; divide by 60 for kJ/min.",
    "concept": "Product freezing loads normally include sensible cooling above the freezing point, latent heat during freezing, and sensible cooling below freezing when the needed properties are given.",
    "shortcutFormula": "\\dot Q=\\dot m[c_p\\Delta T+h_f]",
    "shortcut": "Separate cooling into temperature regions around the freezing point before adding latent heat.",
    "commonMistakes": [
      "Do not automatically use one c_p across a phase change.",
      "Do not invent missing freezing-point properties to force agreement with an option."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 214; original PDF page 63; extracted PDF page 36",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 63,
    "sourceExtractedPdfPage": 36,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=36",
    "sourceAnswerStatus": "Source discrepancy or incomplete solution; not approved for scoring.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: : _ breads kg = tihpreaa = 50074 (0.45 *8—) = 225 kg/h Qtotal = Qbread + Qhreezing = (inc, AT), aa + Ghhjztent) bread = 225(2.93)[22 — (-10)] + 225(109.3) = 45,688.5 kj/h = 761.5 kJ/min",
    "sourceChoicesOriginalOrder": [
      "A. 541.7 kJ/min",
      "B. 351.6 kJ/min",
      "C. 761.5 kJ/min",
      "D. 409.9 kJ/min"
    ],
    "id": "bluebook-aircon-214",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=36"
  },
  {
    "sourceProblemNumber": 215,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Heat Pump Performance Factor & Savings",
    "difficulty": "Intermediate",
    "prompt": "A house that was heated by electric resistance heaters consumed 1200 kWh of electric energy in a winter month. If this house were heated instead by a heat pump that has an average performance factor, PF of 2.4, determine how much money the homeowner would be saved that month. Assume a price of 0.085 $/kWh for electricity.",
    "options": [
      {
        "value": "A",
        "text": "$42.5"
      },
      {
        "value": "B",
        "text": "$59.50"
      },
      {
        "value": "C",
        "text": "$102"
      },
      {
        "value": "D",
        "text": "$97.75"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Resistance-heating use =1200 kWh/month",
      "Heat-pump PF =2.4",
      "Tariff = $0.085/kWh"
    ],
    "formula": "W_{HP}=Q_H/PF",
    "formulaReason": "This problem is classified as Heat Pump Performance Factor & Savings. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Heat-pump electricity =1200/2.4=500 kWh; savings=(1200−500)(0.085).",
    "calculation": [
      "Resistance electricity =1200 kWh.",
      "Heat-pump electricity for the same heat delivery =1200/2.4=500 kWh.",
      "Savings =700 kWh×$0.085/kWh=$59.50."
    ],
    "finalAnswer": "B — $59.50 saved",
    "unitCheck": "kWh × $/kWh = dollars.",
    "concept": "An electric resistance heater has a heating factor near 1, while a heat pump delivers several units of heat per unit of electricity.",
    "shortcutFormula": "W_{HP}=Q_H/PF",
    "shortcut": "Divide the heat delivered (represented by resistance-heater kWh) by PF to estimate heat-pump kWh, then multiply savings by tariff.",
    "commonMistakes": [
      "Multiply by performance factor only when solving for heat delivered from electricity.",
      "Compare systems delivering the same amount of heat."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 215; original PDF page 63; extracted PDF page 37",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 63,
    "sourceExtractedPdfPage": 37,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=37",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: W = 2 = 1200 Wh _ co Wh PF 2.4 $ savings per month = (1200-— 500)(0.085) = $59.50",
    "sourceChoicesOriginalOrder": [
      "A. $42.5",
      "B. $59.50",
      "C. $102",
      "D. $97.75"
    ],
    "id": "bluebook-aircon-215",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=37"
  },
  {
    "sourceProblemNumber": 216,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Ammonia Cycle Compressor Power",
    "difficulty": "Intermediate",
    "prompt": "An ammonia simple saturation cycle operates with a suction pressure of 291.6 kPa and a condenser pressure of 1204 kPa develops 15 tons of refrigeration. Determine the theoretical horsepower of the compressor. The following enthalpies have been found: condenser entrance = 1653 kJ/kg, exit = 346.6 kJ/kg; compressor entrance = 1450.2 kJ/kg, exit = 1653 kJ/kg.",
    "options": [
      {
        "value": "A",
        "text": "7.23 hp"
      },
      {
        "value": "B",
        "text": "13 hp"
      },
      {
        "value": "C",
        "text": "15 hp"
      },
      {
        "value": "D",
        "text": "8.23 hp"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Capacity =15 TR",
      "Suction pressure =291.6 kPa; condenser pressure =1204 kPa",
      "h₃=1653, h₄=346.6, h₁=1450.2 kJ/kg; compressor exit h₂=1653 kJ/kg"
    ],
    "formula": "\\dot m=\\dot Q_L/(h_1-h_4);\\quad W=\\dot m(h_2-h_1)",
    "formulaReason": "This problem is classified as Ammonia Cycle Compressor Power. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇_L=15(3.516)=52.74 kW; ṁ=52.74/(1450.2−346.6)≈0.0478 kg/s.",
    "calculation": [
      "Refrigerant mass flow ≈0.0478 kg/s.",
      "Compressor power ≈0.0478(1653−1450.2)=9.70 kW.",
      "hp≈9.70/0.746≈13 hp."
    ],
    "finalAnswer": "B — 13 hp",
    "unitCheck": "kW = kg/s × kJ/kg; convert kW to hp by dividing by 0.746.",
    "concept": "Refrigeration effect determines refrigerant mass flow; compressor enthalpy rise determines the required power.",
    "shortcutFormula": "\\dot m=\\dot Q_L/(h_1-h_4);\\quad W=\\dot m(h_2-h_1)",
    "shortcut": "Find ṁ from capacity/refrigeration effect, then use ṁΔh across the compressor.",
    "commonMistakes": [
      "Use evaporator enthalpy rise/drop for refrigeration effect, not compressor enthalpy rise.",
      "Keep state enthalpies paired with the correct points in the cycle."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 216; original PDF page 64; extracted PDF page 38",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 64,
    "sourceExtractedPdfPage": 38,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=38",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: =e 88 m= -h, 14502-3466 0.0478 kg/s N= nh = — 0.0478 (1653 -1450.2) _ W = th(h, — hy) = 0.746 = 13 hp",
    "sourceChoicesOriginalOrder": [
      "A. 7.23 hp",
      "B. 13 hp",
      "C. 15 hp",
      "D. 8.23 hp"
    ],
    "id": "bluebook-aircon-216",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=38"
  },
  {
    "sourceProblemNumber": 217,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Ice Production & Compressor Power",
    "difficulty": "Intermediate",
    "prompt": "An ammonia ice plant operates between a condenser temperature of 35°C and evaporator of -15°C. It produces 10 metric tons of ice per day from water at 30°C to ice at -5°C. Assuming simple saturation cycle, determine the horsepower of the motor if the adiabatic efficiency of the compressor nc = 0.85 and mechanical efficiency nm = 0.95. The specific heat of ice is 2.094 kJ/kg-°C and the latent heat is 335 kJ/kg. From the table for ammonia the following enthalpies are: condenser entrance = 1703 kJ/kg, exit = 366.1 kJ/kg; compressor entrance = 1443.9 kJ/kg, exit = 1703 kJ/kg.",
    "options": [
      {
        "value": "A",
        "text": "17.68 hp"
      },
      {
        "value": "B",
        "text": "18.61 hp"
      },
      {
        "value": "C",
        "text": "15.5 hp"
      },
      {
        "value": "D",
        "text": "21.9 hp"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Ice production =10 metric tons/day",
      "Water at 30°C to ice at −5°C",
      "Condenser 35°C, evaporator −15°C",
      "c_p,water=4.187; c_p,ice=2.094 kJ/(kg·K); h_f=335 kJ/kg",
      "Compressor adiabatic efficiency=0.85; mechanical efficiency=0.95"
    ],
    "formula": "Q=mc_p\\Delta T+mh_f;\\quad \\dot m=\\dot Q_L/(h_1-h_4)",
    "formulaReason": "This problem is classified as Ice Production & Compressor Power. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "q/kg=4.187(30)+335+2.094(5)=471.08 kJ/kg; Q̇≈54.52 kW.",
    "calculation": [
      "Product energy per kg =471.08 kJ/kg.",
      "Daily load rate ≈10,000(471.08)/(24×3600)=54.52 kW.",
      "Use source ammonia enthalpies to obtain ṁ≈0.0509 kg/s and compressor work ≈17.68 hp.",
      "Motor hp=17.68/[0.85(0.95)]≈21.9 hp."
    ],
    "finalAnswer": "D — 21.9 hp motor",
    "unitCheck": "kJ/day divided by 86400 s/day gives kW.",
    "concept": "Ice production includes cooling water to freezing, removing latent heat, and cooling ice below 0°C. Compressor and mechanical inefficiencies increase motor size.",
    "shortcutFormula": "Q=mc_p\\Delta T+mh_f;\\quad \\dot m=\\dot Q_L/(h_1-h_4)",
    "shortcut": "Compute product load first, then refrigerant flow, compressor power, and divide by both efficiencies.",
    "commonMistakes": [
      "Include both sensible and latent loads.",
      "Divide by efficiencies to obtain required input power."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 217; original PDF page 64; extracted PDF page 39",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 64,
    "sourceExtractedPdfPage": 39,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=39",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: q= Cp, (t. — te) + Matent + Cp, (te 7 ty) = 4.187(30 — 0) + 335 + 2.094/0 — (-5)| = 471.08 kJ/k g Q = RENO — 196,283.33 = 54.523 kj/s - Q_ 54.523 m= hy-h, | 1443.9-366.1 0.0509 kg/s , . 0.0509 (1703 -1443 9) W = tin(h, — h,) = SPORE = 17.68 hp , 17.68 Wnotor _ 0.85(0.95) =21.9 hp",
    "sourceChoicesOriginalOrder": [
      "A. 17.68 hp",
      "B. 18.61 hp",
      "C. 15.5 hp",
      "D. 21.9 hp"
    ],
    "id": "bluebook-aircon-217",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=39"
  },
  {
    "sourceProblemNumber": 218,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Refrigerant Flow & Cooling Capacity",
    "difficulty": "Intermediate",
    "prompt": "A Freon 22 air conditioning under standard operating conditions of 35°C condensing and 5°C evaporating temperatures. The volume flow rate entering the compressor is 23.72 L/s. Determine the refrigerating capacityif the refrigerating effect is 164 kJ/kg. From the table for R22 the specific volume at the compressor entrance is 40.46 L/kg.",
    "options": [
      {
        "value": "A",
        "text": "339.3 TR"
      },
      {
        "value": "B",
        "text": "79.3 TR"
      },
      {
        "value": "C",
        "text": "96.4 TR"
      },
      {
        "value": "D",
        "text": "27.4 TR"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "R-22: condensing 35°C, evaporating 5°C",
      "Compressor suction volume flow =23.72 L/s",
      "Suction specific volume =40.46 L/kg",
      "Refrigerating effect=164 kJ/kg"
    ],
    "formula": "\\dot m=\\dot V/v;\\quad \\dot Q_L=\\dot m q_L",
    "formulaReason": "This problem is classified as Refrigerant Flow & Cooling Capacity. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "ṁ=0.02372/0.04046≈0.586 kg/s.",
    "calculation": [
      "Convert volume rate: 23.72 L/s=0.02372 m³/s.",
      "ṁ=0.02372/0.04046≈0.586 kg/s.",
      "Q̇_L=0.586(164)≈96.1 kW; TR≈96.1/3.516≈27.4 TR."
    ],
    "finalAnswer": "D — 27.4 TR",
    "unitCheck": "m³/s ÷ m³/kg = kg/s; kg/s×kJ/kg = kW.",
    "concept": "Mass flow rate is suction volume flow divided by suction specific volume, and capacity is mass flow times refrigerating effect.",
    "shortcutFormula": "\\dot m=\\dot V/v;\\quad \\dot Q_L=\\dot m q_L",
    "shortcut": "Convert L/s to m³/s first, then divide by specific volume.",
    "commonMistakes": [
      "Do not confuse the specific volume (L/kg) with the volume flow rate (L/s).",
      "Convert kW to TR only at the final step."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 218; original PDF page 64; extracted PDF page 40",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 64,
    "sourceExtractedPdfPage": 40,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=40",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: m= S = 37 = 0.5877 kg/s Q, = mq, = ose ed = 27.4TR",
    "sourceChoicesOriginalOrder": [
      "A. 339.3 TR",
      "B. 79.3 TR",
      "C. 96.4 TR",
      "D. 27.4 TR"
    ],
    "id": "bluebook-aircon-218",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=40"
  },
  {
    "sourceProblemNumber": 219,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Compressor Volumetric Efficiency",
    "difficulty": "Intermediate",
    "prompt": "The refrigerant volume flow rate at the entrance of compressor were obtained from a test on a twin cylinder, single acting 15 cm x 20 cm, 320 rpm compressor ammonia refrigerating plant to be 33 L/s. Determine the volumetric efficiency of the compressor.",
    "options": [
      {
        "value": "A",
        "text": "77.65%"
      },
      {
        "value": "B",
        "text": "87.6%"
      },
      {
        "value": "C",
        "text": "97.6%"
      },
      {
        "value": "D",
        "text": "65.65%"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Twin cylinder, single acting compressor: 15 cm × 20 cm",
      "Speed =320 rpm",
      "Measured compressor inlet refrigerant flow =33 L/s"
    ],
    "formula": "\\eta_v=\\dot V_{actual}/\\dot V_{displacement}",
    "formulaReason": "This problem is classified as Compressor Volumetric Efficiency. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Compare measured suction-volume flow against the piston displacement volume rate for both cylinders.",
    "calculation": [
      "Piston displacement rate is based on cylinder swept volume × speed × number of acting cylinders.",
      "The source solution gives η_v≈0.876 =87.6%.",
      "Choose the option matching 87.6%."
    ],
    "finalAnswer": "B — 87.6%",
    "unitCheck": "The ratio is dimensionless; multiply by 100% for percent.",
    "concept": "Volumetric efficiency measures how much suction volume a compressor actually draws compared with its geometric piston displacement.",
    "shortcutFormula": "\\eta_v=\\dot V_{actual}/\\dot V_{displacement}",
    "shortcut": "Use actual suction volume divided by swept displacement volume, with compatible time units.",
    "commonMistakes": [
      "Use both cylinders and the stated single-acting configuration.",
      "Make sure L/s and m³/min use a common time unit."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 219; original PDF page 65; extracted PDF page 41",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 65,
    "sourceExtractedPdfPage": 41,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=41",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Vp = (ED°L)N = =(0.15)?(0.2)(320)(2) = 2.26 m/min V. 33 Ny = Vo 226) = 0.876 = 87.6% 60",
    "sourceChoicesOriginalOrder": [
      "A. 77.65%",
      "B. 87.6%",
      "C. 97.6%",
      "D. 65.65%"
    ],
    "id": "bluebook-aircon-219",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=41"
  },
  {
    "sourceProblemNumber": 220,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Ammonia Compressor Power & Displacement",
    "difficulty": "Intermediate",
    "prompt": "A twin cylinder ammonia compressor with volume displacement of 14,726 cm3 operates at 300 rpm. Condenser and evaporator pressure are 1200 kPa and 227 kPa respectively. Specific volume of refrigerant at the entrance of compressor is 528.26 L/kg. Compression process is polytropic with n = 1.20 and clearance factor of compressor is 2 percent. Determine the horsepower required.",
    "options": [
      {
        "value": "A",
        "text": "60 hp"
      },
      {
        "value": "B",
        "text": "70 hp"
      },
      {
        "value": "C",
        "text": "80 hp"
      },
      {
        "value": "D",
        "text": "90 hp"
      }
    ],
    "answer": "C",
    "answerVerified": false,
    "given": [
      "Twin-cylinder ammonia compressor; displacement stated as 14,726 cm³",
      "Speed =300 rpm",
      "Condenser pressure =1200 kPa; evaporator pressure =227 kPa",
      "Source uses η_v≈0.8725 and suction specific volume about 0.592 m³/kg"
    ],
    "formula": "\\dot V=\\eta_v V_p;\\quad W=\\dot m(h_2-h_1)",
    "formulaReason": "This problem is classified as Ammonia Compressor Power & Displacement. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Source calculation: V_p≈9.424 m³/min; actual suction volume≈0.8725(9.424)=8.222 m³/min.",
    "calculation": [
      "Actual intake volume in source working: ≈8.222 m³/min using 320 rpm.",
      "Use the ammonia property data and compression relation in the printed solution to obtain compressor work ≈3582 kJ/min.",
      "Power ≈3582/[60(0.746)]≈80 hp.",
      "The prompt transcription says 300 rpm while the source working appears to use 320 rpm; verify before scoring."
    ],
    "finalAnswer": "Source solution reports C — 80 hp (UNVERIFIED: speed mismatch)",
    "unitCheck": "kJ/min ÷ 60 = kW; kW/0.746 = hp.",
    "concept": "Compressor power depends on refrigerant mass flow and enthalpy rise; volumetric efficiency links geometric displacement to actual intake volume.",
    "shortcutFormula": "\\dot V=\\eta_v V_p;\\quad W=\\dot m(h_2-h_1)",
    "shortcut": "Find actual intake volume from displacement×volumetric efficiency, then mass flow and compression work.",
    "commonMistakes": [
      "Convert cm³ to m³ and minutes to seconds consistently.",
      "Do not use geometric displacement as actual suction flow without volumetric efficiency."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 220; original PDF page 65; extracted PDF page 42",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 65,
    "sourceExtractedPdfPage": 42,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=42",
    "sourceAnswerStatus": "Question transcribes 300 rpm but printed working appears to use 320 rpm; not scoreable until reconciled.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: 1 - (n= _ 32004? _ ny=1+tc c(#) =1+0.02 - 0.02 (2) “ =0.8725 Vp = (ED°L)N = 0.014726(320)(2) = 9.424 m3/min V, =NyVp = 0.8725(9.424) = 8.2224 m?/min n-1 1.2-1 ay — BP1Vi}(P2\\)n _ 4] _ 1.20(227)(8.2224)|(1200\\a2 | _ . We le) 7 ~ 11.20 ( 227 ) i = 3582 kjmin 3582 ~ 60(0.746) 80 hp",
    "sourceChoicesOriginalOrder": [
      "A. 60 hp",
      "B. 70 hp",
      "C. 80 hp",
      "D. 90 hp"
    ],
    "id": "bluebook-aircon-220",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=42"
  },
  {
    "sourceProblemNumber": 221,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Reversed Carnot COP Ratio",
    "difficulty": "Intermediate",
    "prompt": "A reversed Carnot has a refrigerating COP of 2.5. Determine the ratio TH/TL.",
    "options": [
      {
        "value": "A",
        "text": "1.4"
      },
      {
        "value": "B",
        "text": "1.5"
      },
      {
        "value": "C",
        "text": "1.25"
      },
      {
        "value": "D",
        "text": "1.2"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Refrigerating COP =2.5"
    ],
    "formula": "COP_R=\\frac{T_L}{T_H-T_L}",
    "formulaReason": "This problem is classified as Reversed Carnot COP Ratio. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "2.5=T_L/(T_H−T_L).",
    "calculation": [
      "Rearrange: 2.5(T_H−T_L)=T_L.",
      "T_H/T_L=1+1/2.5=1.4."
    ],
    "finalAnswer": "A — T_H/T_L = 1.4",
    "unitCheck": "Temperature ratio must use absolute temperature; the ratio is dimensionless.",
    "concept": "Carnot refrigerator COP fixes the ratio of the absolute hot and cold reservoir temperatures.",
    "shortcutFormula": "COP_R=\\frac{T_L}{T_H-T_L}",
    "shortcut": "T_H/T_L = 1 + 1/COP_R.",
    "commonMistakes": [
      "Do not use Celsius or Fahrenheit directly in the Carnot temperature ratio."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 221; original PDF page 65; extracted PDF page 43",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 65,
    "sourceExtractedPdfPage": 43,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=43",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: — TL cop = 2 = Ta-h = Ta_y cop. TT TT, TH — — te. felt gpalt+yQa14",
    "sourceChoicesOriginalOrder": [
      "A. 1.4",
      "B. 1.5",
      "C. 1.25",
      "D. 1.2"
    ],
    "id": "bluebook-aircon-221",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=43"
  },
  {
    "sourceProblemNumber": 222,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Air-Cooled Condenser Air Temperature Rise",
    "difficulty": "Intermediate",
    "prompt": "Three thousand cubic feet per minute of air are circulated over an air-cooled condenser. If the load on the condenser is 64,800 Btu/hr, compute the temperature rise of the air passing over the condenser. Specific volume of standard air (13.34 ft3/lb).",
    "options": [
      {
        "value": "A",
        "text": "10°F"
      },
      {
        "value": "B",
        "text": "15°F"
      },
      {
        "value": "C",
        "text": "20°F"
      },
      {
        "value": "D",
        "text": "25°F"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Air flow =3000 ft³/min",
      "Condenser load =64,800 Btu/hr"
    ],
    "formula": "\\dot Q=\\dot m c_p\\Delta T",
    "formulaReason": "This problem is classified as Air-Cooled Condenser Air Temperature Rise. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Use air density ≈0.075 lb/ft³: ṁ≈3000(60)(0.075)=13,500 lb/hr.",
    "calculation": [
      "ṁ_air≈13,500 lb/hr.",
      "ΔT=64,800/[13,500(0.24)]≈20°F."
    ],
    "finalAnswer": "C — 20°F rise",
    "unitCheck": "Btu/hr divided by Btu/(lb·°F)×lb/hr gives °F.",
    "concept": "The condenser heat rejected is picked up by the cooling air as a sensible temperature rise.",
    "shortcutFormula": "\\dot Q=\\dot m c_p\\Delta T",
    "shortcut": "Convert cfm to lb/hr using air density, then use ΔT=Q̇/(ṁc_p).",
    "commonMistakes": [
      "Convert cfm to an hourly mass flow.",
      "Use air c_p consistent with Btu/lb·°F."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 222; original PDF page 65; extracted PDF page 44",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 65,
    "sourceExtractedPdfPage": 44,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=44",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q = Mairp,,, Atair Atair =F a = ae (0.24) = 20°F Mair°pair = ggg 13.34",
    "sourceChoicesOriginalOrder": [
      "A. 10°F",
      "B. 15°F",
      "C. 20°F",
      "D. 25°F"
    ],
    "id": "bluebook-aircon-222",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=44"
  },
  {
    "sourceProblemNumber": 223,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Ammonia Cycle Energy Balance",
    "difficulty": "Intermediate",
    "prompt": "Saturated vapor ammonia at -16°C (hT = 1442.60 kJ/kg) leaves the evaporator and enters the compressor at -6°C (h1 = 1465 kJ/kg). The refrigerant leaves the condenser as saturated liquid at 40°C (h4 = 390.6 kJ/kg) and enters the expansion valve at 35°C (h5 = 366.1 kJ/kg). Heat rejected from the condenser amount to 50 kW. The work to compressor is 208 kJ/kg, while the heat loss from compressor is 33 kJ/kg. If 95 kJ/kg of heat are lost in the piping between the compressor discharge and condenser inlet, determine the refrigerating capacity of the system.",
    "options": [
      {
        "value": "A",
        "text": "49.5 TR"
      },
      {
        "value": "B",
        "text": "46.61 TR"
      },
      {
        "value": "C",
        "text": "12.88 TR"
      },
      {
        "value": "D",
        "text": "13.24 TR"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Ammonia evaporator outlet saturated vapor at −16°C, h≈1442.60 kJ/kg",
      "Compressor suction at −6°C, h≈1465 kJ/kg",
      "Condenser state enthalpies as listed in source"
    ],
    "formula": "\\dot Q_L=\\dot m(h_1-h_4);\\quad \\dot Q_H=\\dot m(h_2-h_3)",
    "formulaReason": "This problem is classified as Ammonia Cycle Energy Balance. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "The source energy balance gives ṁ≈0.0433 kg/s and refrigerating effect≈1076.5 kJ/kg.",
    "calculation": [
      "Use the condenser balance and the printed heat-rejection rate to obtain ṁ≈0.0433 kg/s.",
      "Evaporator refrigerating effect =1442.6−366.1≈1076.5 kJ/kg.",
      "Q̇_L≈0.0433(1076.5)≈46.6 kW; capacity≈46.6/3.516≈13.24 TR."
    ],
    "finalAnswer": "D — 13.24 TR",
    "unitCheck": "kg/s×kJ/kg=kW; kW/3.516=TR.",
    "concept": "An actual cycle is analyzed with energy balances on compressor, piping, condenser, and evaporator; enthalpy differences determine heat and work per kilogram.",
    "shortcutFormula": "\\dot Q_L=\\dot m(h_1-h_4);\\quad \\dot Q_H=\\dot m(h_2-h_3)",
    "shortcut": "Find refrigerant mass flow from a known component energy balance, then calculate evaporator load.",
    "commonMistakes": [
      "Keep the state numbers and enthalpies consistent with the source diagram.",
      "Do not confuse condenser load with evaporator cooling capacity."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 223; original PDF page 66; extracted PDF page 45",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 66,
    "sourceExtractedPdfPage": 45,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=45",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Solving for the enthalpy at the exit of compressor using energy balance about the compressor: h, =h, +w—q,,; = 1465 + 208 — 33 = 1640 kJ/kg Solving for the enthalpy at the entrance of condenser using energy balance about the piping from compressor exit to condenser entrance: hg = hy — q,., = 1640 — 95 = 1545 kJ/kg Solving for the heat rejected in the condenser using energy balance about the condenser: qd. = hg — hy = 1545 — 390.6 = 1154.4 kJ/kg m= < = —— = 0.0433 kg/s Solving for the refrigerating effect using energy balance about the evaporator: h, = h, = 366.1 kJ/kg qs = hy —h, = 1442.6 — 366.1 = 1076.5 kJ/kg -. the refrigerating capacity, Q, = tng, = 0.0433 (475) = 13.24 TR",
    "sourceChoicesOriginalOrder": [
      "A. 49.5 TR",
      "B. 46.61 TR",
      "C. 12.88 TR",
      "D. 13.24 TR"
    ],
    "id": "bluebook-aircon-223",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=45"
  },
  {
    "sourceProblemNumber": 224,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Actual Refrigeration COP",
    "difficulty": "Intermediate",
    "prompt": "In an actual refrigeration cycle using R12 as working fluid, the refrigerant flow rate is 0.05 kg/s. Vapor enters the expansion valve at 1.15 MPa, 40°C (h = 238.5 kJ/kg) and leaves the evaporator at 175 kPa, -15°C (h = 345 kJ/kg). The electric iput to motor driving the compressor is measured and found 3.0 kW. Motor efficiency at this load 92% and mechanical efficiency 82%. Determine the actual coefficient of performance for this cycle.",
    "options": [
      {
        "value": "A",
        "text": "1.58"
      },
      {
        "value": "B",
        "text": "2.36"
      },
      {
        "value": "C",
        "text": "1.78"
      },
      {
        "value": "D",
        "text": "1.34"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "R-12 flow =0.05 kg/s",
      "Refrigerant at expansion valve: h≈238.5 kJ/kg",
      "h at condenser/valve inlet ≈345 kJ/kg",
      "Motor/compressor efficiencies in source: 0.92 and 0.82"
    ],
    "formula": "COP_{actual}=\\dot Q_L/W_c",
    "formulaReason": "This problem is classified as Actual Refrigeration COP. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇_L=0.05(345−238.5)=5.325 kW.",
    "calculation": [
      "Cooling rate=0.05(345−238.5)=5.325 kW.",
      "Source input power after efficiencies =3(0.92)(0.82)≈2.26 kW.",
      "COP_actual=5.325/2.26≈2.36."
    ],
    "finalAnswer": "B — COP ≈ 2.36",
    "unitCheck": "kW/kW gives dimensionless COP.",
    "concept": "Actual COP is useful refrigeration effect divided by real input power; efficiency losses raise the required input.",
    "shortcutFormula": "COP_{actual}=\\dot Q_L/W_c",
    "shortcut": "Calculate evaporator capacity, calculate actual electrical input using the supplied efficiencies, then divide.",
    "commonMistakes": [
      "Do not use ideal cycle work when the question specifies actual efficiencies.",
      "Use the correct enthalpy drop across the expansion/evaporator path."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 224; original PDF page 66; extracted PDF page 46",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 66,
    "sourceExtractedPdfPage": 46,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=46",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q. = 0.05(345 — 238.5) = 5.325 kw W = 3(0.92)(0.82) = 2.26 kw 5.325 COPactual = 326 2.36",
    "sourceChoicesOriginalOrder": [
      "A. 1.58",
      "B. 2.36",
      "C. 1.78",
      "D. 1.34"
    ],
    "id": "bluebook-aircon-224",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=46"
  },
  {
    "sourceProblemNumber": 225,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Ammonia Wetness / Refrigerating Capacity",
    "difficulty": "Intermediate",
    "prompt": "In an ammonia refrigeration system, the temperature in the evaporator is -12°C and the ammonia at the evaporator entry 0.1511 dry while at exit is 0.95 dry. If the rate of ammonia circulation is 5.64 kg/min, determine the refrigerating capacity of the system. Enthalpy of saturated liquid and vapor at -12°C is 144.929 kJ/kg and 1447.74 kJ/kg respectively.",
    "options": [
      {
        "value": "A",
        "text": "17.82"
      },
      {
        "value": "B",
        "text": "34.82"
      },
      {
        "value": "C",
        "text": "27.82"
      },
      {
        "value": "D",
        "text": "4.82"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Evaporator temperature =−12°C",
      "Inlet quality =0.1511; outlet quality =0.95",
      "Use ammonia saturation properties from source tables"
    ],
    "formula": "h=h_f+xh_{fg};\\quad \\dot Q_L=\\dot m(h_1-h_4)",
    "formulaReason": "This problem is classified as Ammonia Wetness / Refrigerating Capacity. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "The source calculates inlet/outlet enthalpies from h=hf+x hfg and then applies ṁΔh.",
    "calculation": [
      "Compute each state enthalpy using h=hf+xhfg with the appropriate quality.",
      "Calculate the refrigeration effect from the relevant evaporator enthalpy difference.",
      "The source worked result is 27.82 TR (choice C)."
    ],
    "finalAnswer": "C — 27.82 TR",
    "unitCheck": "Enthalpy is kJ/kg; mass flow × enthalpy change gives kW.",
    "concept": "Quality x is the vapor mass fraction in a saturated liquid-vapor mixture; enthalpy is found by interpolation between saturated-liquid and saturated-vapor states.",
    "shortcutFormula": "h=h_f+xh_{fg};\\quad \\dot Q_L=\\dot m(h_1-h_4)",
    "shortcut": "Use h=hf+xhfg for each mixture state, then take the enthalpy difference across the evaporator.",
    "commonMistakes": [
      "Enter quality as a fraction (0.1511), not 15.11.",
      "Use properties at the stated evaporator temperature."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 225; original PDF page 67; extracted PDF page 47",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 67,
    "sourceExtractedPdfPage": 47,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=47",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: hy = hy, +x4(hy, — he) = 144.929 + 0.1511(1447.74 — 144.929) = 341.78 kJ/kg hy = hy +x, (hg, — hy) = 144.929 + 0.95(1447.74 — 144.929) = 1382.6 kJ/kg d. = m(h, _ h,) = sto ean) = 27.82TR",
    "sourceChoicesOriginalOrder": [
      "A. 17.82",
      "B. 34.82",
      "C. 27.82",
      "D. 4.82"
    ],
    "id": "bluebook-aircon-225",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=47"
  },
  {
    "sourceProblemNumber": 226,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Cascade Refrigeration Power / Performance",
    "difficulty": "Intermediate",
    "prompt": "A two stage cascade vapor compression refrigeration system uses ammonia in the low- temperature loop and R-12 in the high-temperature loop. The ammonia provides 15 tons of cooling. If the high-loop temperature requires 10.12 kW compressor power and low loop 15.93 kW, determine the COP of the system.",
    "options": [
      {
        "value": "A",
        "text": "2.027 TR"
      },
      {
        "value": "B",
        "text": "5.22 TR"
      },
      {
        "value": "C",
        "text": "3.314 TR"
      },
      {
        "value": "D",
        "text": "9.1 TR"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Two-stage cascade system, ammonia low-temperature loop and R-12 high-temperature loop",
      "Ammonia loop capacity =15 TR",
      "Source output gives W_total=10.12+15.93=26.05 kW"
    ],
    "formula": "W_{total}=W_{low}+W_{high}",
    "formulaReason": "This problem is classified as Cascade Refrigeration Power / Performance. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "W_total=10.12+15.93=26.05 kW per the printed solution.",
    "calculation": [
      "Total compressor power reported by source =10.12+15.93=26.05 kW.",
      "The OCR solution/answer-choice units do not reconcile clearly with the prompt; the source result is retained but not approved for scoring."
    ],
    "finalAnswer": "Source result/choice A — 2.027 TR (UNVERIFIED)",
    "unitCheck": "Compressor powers add in kW; a cooling capacity would need a separate kW-to-TR conversion.",
    "concept": "In a cascade system, separate low- and high-temperature loops are coupled through a cascade heat exchanger; total power is the sum of compressor inputs.",
    "shortcutFormula": "W_{total}=W_{low}+W_{high}",
    "shortcut": "Calculate each loop power independently, then add them. Confirm the requested output quantity and units before selecting the option.",
    "commonMistakes": [
      "Do not confuse total work with cooling capacity or COP.",
      "Check whether the final answer is supposed to be kW, TR, or dimensionless."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 226; original PDF page 67; extracted PDF page 48",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 67,
    "sourceExtractedPdfPage": 48,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=48",
    "sourceAnswerStatus": "The reproduced solution fragment and answer choices appear inconsistent; source review required.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Wrotal = 10.12 + 15.93 = 26.05 kw cop = “S52 — 2.027TR",
    "sourceChoicesOriginalOrder": [
      "A. 2.027 TR",
      "B. 5.22 TR",
      "C. 3.314 TR",
      "D. 9.1 TR"
    ],
    "id": "bluebook-aircon-226",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=48"
  },
  {
    "sourceProblemNumber": 227,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Air-Conditioner Input Power",
    "difficulty": "Intermediate",
    "prompt": "When a man returns to his well-sealed house on a summer day, he finds that the house is at 32°C. He turns on the air conditioner, which cools the entire house to 20°C in 15 min. If COP of the air conditioner system is 2.5, determine the power drawn by the air conditioners. Assume the entire mass within the house is equivalent to 800 kg of air for which c = 0.72 kJ/kg- °C.",
    "options": [
      {
        "value": "A",
        "text": "7.08 kW"
      },
      {
        "value": "B",
        "text": "3.07 kW"
      },
      {
        "value": "C",
        "text": "19.2 kW"
      },
      {
        "value": "D",
        "text": "12.08 kW"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Room air mass =800 kg",
      "32°C to 20°C in 15 minutes",
      "c_v=0.72 kJ/(kg·K)",
      "COP=2.5"
    ],
    "formula": "W=\\dot Q_L/COP",
    "formulaReason": "This problem is classified as Air-Conditioner Input Power. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇_L=800(0.72)(32−20)/(15×60)=7.68 kW.",
    "calculation": [
      "Heat removed per time: Q̇_L=800(0.72)(12)/900=7.68 kW.",
      "Input power=W=7.68/2.5≈3.07 kW."
    ],
    "finalAnswer": "B — 3.07 kW",
    "unitCheck": "kJ/s = kW.",
    "concept": "Room cooling power is found from the energy removed from the contained air divided by elapsed time and by COP.",
    "shortcutFormula": "W=\\dot Q_L/COP",
    "shortcut": "Use m c_v ΔT/time, then divide by COP.",
    "commonMistakes": [
      "Convert 15 minutes to seconds.",
      "Use the COP to divide cooling rate and obtain input power."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 227; original PDF page 67; extracted PDF page 49",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 67,
    "sourceExtractedPdfPage": 49,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=49",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: . mairC(ty—t,) _ 800(0.72) (32-20) _ Q.= hang 35(60) 7.68 kW ay — Qe _ 7.68 _ W= cop ast 3.07 kW",
    "sourceChoicesOriginalOrder": [
      "A. 7.08 kW",
      "B. 3.07 kW",
      "C. 19.2 kW",
      "D. 12.08 kW"
    ],
    "id": "bluebook-aircon-227",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=49"
  },
  {
    "sourceProblemNumber": 228,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Reversed Carnot COP Improvement",
    "difficulty": "Intermediate",
    "prompt": "It is desired to double the COP of a reversed Carnot engine for cooling from 5.0 by raising the temperature of heat addition while keeping the temperature of heat rejection constant. By what percentage must the temperature of heat addition be raised?",
    "options": [
      {
        "value": "A",
        "text": "10.1%"
      },
      {
        "value": "B",
        "text": "9.1%"
      },
      {
        "value": "C",
        "text": "8.1%"
      },
      {
        "value": "D",
        "text": "7.1%"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Initial reversed-Carnot COP =5.0",
      "Required COP is doubled while low temperature remains fixed"
    ],
    "formula": "COP_R=\\frac{T_L}{T_H-T_L}",
    "formulaReason": "This problem is classified as Reversed Carnot COP Improvement. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Solve the COP equation before and after doubling COP with fixed T_L; compare the required hot-reservoir temperature.",
    "calculation": [
      "Using COP_R=T_L/(T_H−T_L), relate T_H/T_L to each COP.",
      "The source algebra gives a required heat-addition temperature increase of about 9.1%."
    ],
    "finalAnswer": "B — approximately 9.1% increase",
    "unitCheck": "Temperature ratios are dimensionless; calculate percentage increase from the ratio change.",
    "concept": "Doubling a Carnot refrigerator COP does not mean doubling the absolute hot temperature; the relationship is nonlinear when the cold temperature is fixed.",
    "shortcutFormula": "COP_R=\\frac{T_L}{T_H-T_L}",
    "shortcut": "Express the two cases as dimensionless hot-to-cold absolute temperature ratios, then divide the ratios.",
    "commonMistakes": [
      "Do not compare temperature differences as if they were absolute temperatures.",
      "Keep the cold-reservoir temperature fixed as stated."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 228; original PDF page 68; extracted PDF page 50",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 68,
    "sourceExtractedPdfPage": 50,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=50",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Percent Increase of Temperature = “tL = a — 1 of heat addition L L Original COP: Doubling the COP: 5 = 10 =—*, Ty-TL Ty-TL 1_Ty-Ty 1 _ Ty-Th 5 TT, 10° «oT; 21TH _y +=™_1 5 Ty 10° «TL Ta — 42: TH 44: TZ 1.2; eq.1 7 1.1; eq. 2 Dividing eq.1 and eq. 2: TH Ty 12 =i. Ti iat 1.091 = Tr, TL Percent Increase of heat addition = 1.091 — 1 = 0.091 = 9.1%",
    "sourceChoicesOriginalOrder": [
      "A. 10.1%",
      "B. 9.1%",
      "C. 8.1%",
      "D. 7.1%"
    ],
    "id": "bluebook-aircon-228",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=50"
  },
  {
    "sourceProblemNumber": 229,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Ammonia Compressor Cylinder Bore",
    "difficulty": "Intermediate",
    "prompt": "An ammonia water-cooled compressor receives the refrigerant at specific volume 62 L/kg. It has a piston displacement rate of 5 m3/min. If a squirrel cage motor running at 1200 rpm drives the compressor and average piston speed is 490 m/min, calculate size of cylinder bore.",
    "options": [
      {
        "value": "A",
        "text": "20.4 cm"
      },
      {
        "value": "B",
        "text": "26.0 cm"
      },
      {
        "value": "C",
        "text": "16.13 cm"
      },
      {
        "value": "D",
        "text": "13.6 cm"
      }
    ],
    "answer": "C",
    "answerVerified": false,
    "given": [
      "Ammonia specific volume =62 L/kg",
      "Piston displacement rate =5 m³/min",
      "Motor speed stated as 1500 rpm",
      "Source solution OCR instead includes a 1200 rpm calculation"
    ],
    "formula": "V_p=\\frac{\\pi D^2}{4}LN;\\quad v_p=2LN",
    "formulaReason": "This problem is classified as Ammonia Compressor Cylinder Bore. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "The source transcription does not consistently match the prompt’s speed and displacement data.",
    "calculation": [
      "The OCR of the printed working derives a stroke of about 20.4 cm, then a bore of about 16.13 cm.",
      "Because the printed working appears to use 1200 rpm while the prompt says 1500 rpm, the result cannot be approved without checking the source page."
    ],
    "finalAnswer": "Source-listed choice C — 16.13 cm (UNVERIFIED)",
    "unitCheck": "Convert L to m³ and rpm to revolutions per minute consistently.",
    "concept": "Compressor cylinder bore is related to swept volume, bore/stroke ratio, cylinder count, and rotational speed.",
    "shortcutFormula": "V_p=\\frac{\\pi D^2}{4}LN;\\quad v_p=2LN",
    "shortcut": "Write the piston displacement equation with consistent per-revolution/per-minute units, then substitute L=D if bore equals stroke.",
    "commonMistakes": [
      "Do not mix compressor speed and piston speed.",
      "Verify whether displacement is total for both cylinders."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 229; original PDF page 68; extracted PDF page 51",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 68,
    "sourceExtractedPdfPage": 51,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=51",
    "sourceAnswerStatus": "The source solution OCR appears to use different speed/displacement data than the transcribed question.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Piston speed = 2LN 490 = 2L(1200) L = 0.204 m = 20.4 cm Vp = 7 D?LN = 7D? (0.204) (1200) =5 D = 0.1613 m= 16.13 cm",
    "sourceChoicesOriginalOrder": [
      "A. 20.4 cm",
      "B. 26.0 cm",
      "C. 16.13 cm",
      "D. 13.6 cm"
    ],
    "id": "bluebook-aircon-229",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=51"
  },
  {
    "sourceProblemNumber": 256,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Temperature-Difference Conversion",
    "difficulty": "Intermediate",
    "prompt": "A water temperature rise of 18°F in the water cooled condenser is equivalent to what in °C?",
    "options": [
      {
        "value": "A",
        "text": "7.78°C"
      },
      {
        "value": "B",
        "text": "10°C"
      },
      {
        "value": "C",
        "text": "263.56 K"
      },
      {
        "value": "D",
        "text": "-9.44°C"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Water temperature rise =18°F"
    ],
    "formula": "\\Delta T_{C}=\\frac{5}{9}\\Delta T_{F}",
    "formulaReason": "This problem is classified as Temperature-Difference Conversion. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "ΔT_C=(5/9)(18°F).",
    "calculation": [
      "For a temperature difference, no 32° offset is added.",
      "ΔT_C=18(5/9)=10°C."
    ],
    "finalAnswer": "B — 10°C",
    "unitCheck": "The output is a temperature difference in °C, not an absolute temperature.",
    "concept": "Temperature differences scale by 5/9 from Fahrenheit degrees to Celsius degrees; absolute-temperature conversions also require an offset.",
    "shortcutFormula": "\\Delta T_{C}=\\frac{5}{9}\\Delta T_{F}",
    "shortcut": "For Δ°F to Δ°C, multiply by 5/9.",
    "commonMistakes": [
      "Do not subtract 32 when converting a temperature rise."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 256; original PDF page 73; extracted PDF page 52",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 73,
    "sourceExtractedPdfPage": 52,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=52",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: _ °o 1°C — OF AT= 18 F(+5) = 10°C",
    "sourceChoicesOriginalOrder": [
      "A. 7.78°C",
      "B. 10°C",
      "C. 263.56 K",
      "D. -9.44°C"
    ],
    "id": "bluebook-aircon-256",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=52"
  },
  {
    "sourceProblemNumber": 273,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Fan Affinity Laws & Similar Fans",
    "difficulty": "Intermediate",
    "prompt": "A 15 in. diameter fan operates at 1600 rpm and develops a head of 6 in. of water and delivers 120 cfm. What volumetric capacity for geometrically similar fan will develop 6 in of water at 1300 rpm?",
    "options": [
      {
        "value": "A",
        "text": "147.7 cfm"
      },
      {
        "value": "B",
        "text": "181.8 cfm"
      },
      {
        "value": "C",
        "text": "97.5 cfm"
      },
      {
        "value": "D",
        "text": "79.2cfm"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "Original fan diameter =15 in; speed =1600 rpm",
      "Original head =6 in water; flow=120 cfm",
      "Use the similar-fan size and speed stated in the prompt"
    ],
    "formula": "Q\\propto ND^3",
    "formulaReason": "This problem is classified as Fan Affinity Laws & Similar Fans. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Apply volumetric-capacity affinity law: Q₂/Q₁=(N₂/N₁)(D₂/D₁)³.",
    "calculation": [
      "For geometrically similar fans, volumetric flow varies with rotational speed and diameter cubed.",
      "The source result is Q₂≈181.8 cfm (choice B)."
    ],
    "finalAnswer": "B — 181.8 cfm",
    "unitCheck": "Ratios are dimensionless; final flow remains cfm.",
    "concept": "Fan affinity laws relate capacity, pressure/head, and power to speed and size for geometrically similar operating conditions.",
    "shortcutFormula": "Q\\propto ND^3",
    "shortcut": "For flow, scale by speed ratio and diameter ratio cubed.",
    "commonMistakes": [
      "Use D³ for volumetric flow, D² for pressure/head, and D⁵ for power under similarity assumptions."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 273; original PDF page 77; extracted PDF page 53",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 77,
    "sourceExtractedPdfPage": 53,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=53",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Hy _ _Hy os Do _ Na NED? N2Dz For:H, = H, Dy Np Qa _# @&., _ (22) N,Dy Nabe? G2 = Qi yo} N3 N,)\\2 Qa =a (=) =Q (*) 2 Qo = 120 cfm (“°) = 181.8 cfm 1300",
    "sourceChoicesOriginalOrder": [
      "A. 147.7 cfm",
      "B. 181.8 cfm",
      "C. 97.5 cfm",
      "D. 79.2cfm"
    ],
    "id": "bluebook-aircon-273",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=53"
  },
  {
    "sourceProblemNumber": 289,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Moist-Air Specific Volume",
    "difficulty": "Intermediate",
    "prompt": "Compute the specific volume of an air-vapor mixture in cubic meter per kg of dry air when the following conditions prevail: t = 40°C, w = 0.015 kg/kg, and Pt = 90 kPa.",
    "options": [
      {
        "value": "A",
        "text": "0.99 m3/kg"
      },
      {
        "value": "B",
        "text": "0.89 m3/kg"
      },
      {
        "value": "C",
        "text": "0.79 m3/kg"
      },
      {
        "value": "D",
        "text": "0.69 m3/kg"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Dry-bulb temperature =40°C",
      "Humidity ratio =0.015 kg/kg dry air",
      "Total pressure =90 kPa"
    ],
    "formula": "v=\\frac{R_{da}T}{P-p_v}",
    "formulaReason": "This problem is classified as Moist-Air Specific Volume. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "The source obtains p_v≈2.12 kPa and uses v=0.287(40+273)/(90−2.12).",
    "calculation": [
      "Use absolute temperature T=313 K.",
      "v=0.287(313)/(90−2.12)≈1.02 m³/kg dry air using rounded inputs; the printed solution reports about 0.99 m³/kg.",
      "The source’s psychrometric intermediate values should be checked; selected key A is retained provisionally."
    ],
    "finalAnswer": "A — 0.99 m³/kg dry air",
    "unitCheck": "kPa·m³/kJ and kelvin must be consistent to yield m³/kg.",
    "concept": "Specific volume of moist air is expressed per kg dry air; the dry-air partial pressure is total pressure minus water-vapor partial pressure.",
    "shortcutFormula": "v=\\frac{R_{da}T}{P-p_v}",
    "shortcut": "Use the dry-air gas constant and dry-air partial pressure, not total pressure alone.",
    "commonMistakes": [
      "Use the vapor partial pressure derived from humidity ratio, not relative humidity alone.",
      "Check the source’s saturation pressure and rounding."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 289; original PDF page 81; extracted PDF page 54",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 81,
    "sourceExtractedPdfPage": 54,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=54",
    "sourceAnswerStatus": "Printed result differs modestly from recalculation based on the transcribed values; review before scoring.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: R,T v= Py-Py Solving for P,: 0.622 Py w= Py-Py 0.622P, P, = 2.12 kPa thus; y = 0287(404273) _ 4 99 ~ 9.99 m3/kg 90—2.12",
    "sourceChoicesOriginalOrder": [
      "A. 0.99 m3/kg",
      "B. 0.89 m3/kg",
      "C. 0.79 m3/kg",
      "D. 0.69 m3/kg"
    ],
    "id": "bluebook-aircon-289",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=54"
  },
  {
    "sourceProblemNumber": 290,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Cooling-Coil Bypass Factor",
    "difficulty": "Intermediate",
    "prompt": "A coil has an inlet temperature of 70°F and outlet of 80°F. If the mean temperature of the coil is 130°F, find the bypass factor of the coil.",
    "options": [
      {
        "value": "A",
        "text": "0.28"
      },
      {
        "value": "B",
        "text": "1.2"
      },
      {
        "value": "C",
        "text": "0.82"
      },
      {
        "value": "D",
        "text": "0.83"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Coil inlet =70°F; outlet =80°F",
      "Mean coil temperature =130°F as transcribed"
    ],
    "formula": "BF=\\frac{T_{coil}-T_{out}}{T_{coil}-T_{in}}",
    "formulaReason": "This problem is classified as Cooling-Coil Bypass Factor. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "The standard bypass-factor expression compares leaving air temperature with effective coil-surface temperature and entering-air temperature.",
    "calculation": [
      "BF=(T_coil−T_out)/(T_coil−T_in)=(130−80)/(130−70)=50/60≈0.833.",
      "Choose D — 0.83."
    ],
    "finalAnswer": "D — 0.83",
    "unitCheck": "The ratio is dimensionless.",
    "concept": "Bypass factor estimates the fraction of air that effectively avoids reaching the coil surface temperature.",
    "shortcutFormula": "BF=\\frac{T_{coil}-T_{out}}{T_{coil}-T_{in}}",
    "shortcut": "Use the exact inlet/outlet/coil temperatures specified by the source definition; do not swap the numerator and denominator.",
    "commonMistakes": [
      "The denominator must represent inlet-to-coil temperature difference.",
      "A bypass factor is usually between 0 and 1; a value outside that range signals inconsistent inputs or definition."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 290; original PDF page 82; extracted PDF page 55",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 82,
    "sourceExtractedPdfPage": 55,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=55",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Bypass factor = tmean —tdb of outlet air tmean —twb of inlet air BF = “°° _ 9.83 130-70",
    "sourceChoicesOriginalOrder": [
      "A. 0.28",
      "B. 1.2",
      "C. 0.82",
      "D. 0.83"
    ],
    "id": "bluebook-aircon-290",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=55"
  },
  {
    "sourceProblemNumber": 291,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Circular Duct Pressure Drop",
    "difficulty": "Intermediate",
    "prompt": "Compute the pressure drop of 35°C air flowing with a mean velocity of 5m/s in a circular sheet-metal duct 400mm in diameter and 25 m long. Use friction factor, f = 0.04, and ρair = 1.3799 kg/m3.",
    "options": [
      {
        "value": "A",
        "text": "431.22 Pa"
      },
      {
        "value": "B",
        "text": "221.34 Pa"
      },
      {
        "value": "C",
        "text": "312.24 Pa"
      },
      {
        "value": "D",
        "text": "422.31 Pa"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Air temperature =35°C",
      "Mean velocity =5 m/s",
      "Duct diameter =400 mm",
      "Length =25 m",
      "Printed friction factor f=0.02"
    ],
    "formula": "\\Delta P=f\\frac{L}{D}\\frac{\\rho V^2}{2}",
    "formulaReason": "This problem is classified as Circular Duct Pressure Drop. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "The usual Darcy-Weisbach-style equation is ΔP=f(L/D)(ρV²/2); source OCR’s numerical substitution does not agree with the stated data.",
    "calculation": [
      "Using the transcribed inputs and ρ≈1.145 kg/m³, the stated equation gives about 18 Pa if f=0.02.",
      "The choices are around 221–431 Pa, so at least one statement, factor convention, or source transcription differs.",
      "Keep the original answer unverified until the printed page is checked."
    ],
    "finalAnswer": "Source-listed nearest choice A — 431.22 Pa (UNVERIFIED)",
    "unitCheck": "ρV² has units Pa; multiplying by dimensionless fL/D retains Pa.",
    "concept": "Duct friction loss scales with friction factor, length/diameter ratio, and velocity squared.",
    "shortcutFormula": "\\Delta P=f\\frac{L}{D}\\frac{\\rho V^2}{2}",
    "shortcut": "Check the Darcy/Fanning friction-factor convention and units before substitution.",
    "commonMistakes": [
      "Darcy and Fanning friction factors differ by a factor of four.",
      "Do not silently change the printed friction factor to force a match."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 291; original PDF page 82; extracted PDF page 56",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 82,
    "sourceExtractedPdfPage": 56,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=56",
    "sourceAnswerStatus": "Question data and answer choices fail a basic calculation consistency check.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: 2 2 Ap = fi¥7p _ 0.04(25)(5)74.3799) _ 434 99 pa 2D 2(0.35)",
    "sourceChoicesOriginalOrder": [
      "A. 431.22 Pa",
      "B. 221.34 Pa",
      "C. 312.24 Pa",
      "D. 422.31 Pa"
    ],
    "id": "bluebook-aircon-291",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=56"
  },
  {
    "sourceProblemNumber": 292,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Circular Duct Velocity from Pressure Drop",
    "difficulty": "Intermediate",
    "prompt": "Pressure difference of 400 Pa is available to force 20°C air through a circular sheet-metal duct 450 mm in diameter and 25 m long. At 20°C, ρ = 1.204 kg/m3 and take friction factor, f = 0.016. Determine the velocity.",
    "options": [
      {
        "value": "A",
        "text": "27.34 ft/s"
      },
      {
        "value": "B",
        "text": "43.72ft/s"
      },
      {
        "value": "C",
        "text": "89.68 ft/s"
      },
      {
        "value": "D",
        "text": "86.98 ft/s"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Pressure difference =400 Pa",
      "D=450 mm; L=25 m",
      "Air density =1.204 kg/m³ at 20°C",
      "Friction factor=0.016"
    ],
    "formula": "V=\\sqrt{\\frac{2\\Delta P D}{fL\\rho}}",
    "formulaReason": "This problem is classified as Circular Duct Velocity from Pressure Drop. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "V=√[2(400)(0.450)/(0.016(25)(1.204))]≈27.34 m/s.",
    "calculation": [
      "V≈27.34 m/s from the stated data.",
      "Convert to ft/s: 27.34×3.28084≈89.68 ft/s, option C.",
      "The OCR transcription of the source solution appears to label 27.34 as ft/s, not m/s."
    ],
    "finalAnswer": "C — 89.68 ft/s (equivalent to 27.34 m/s)",
    "unitCheck": "The equation returns m/s with SI inputs; multiply by 3.28084 for ft/s.",
    "concept": "Solve the duct pressure-drop equation for velocity; the velocity appears squared, so take the square root after rearranging.",
    "shortcutFormula": "V=\\sqrt{\\frac{2\\Delta P D}{fL\\rho}}",
    "shortcut": "Rearrange first: V=√(2ΔP D/(fLρ)). Convert m/s to ft/s only at the end.",
    "commonMistakes": [
      "Check the output unit: the raw calculation is m/s, not ft/s.",
      "Do not square-root a quantity before isolating V²."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 292; original PDF page 82; extracted PDF page 57",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 82,
    "sourceExtractedPdfPage": 57,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=57",
    "sourceAnswerStatus": "Independent unit conversion corrects apparent source-solution unit label; this note is shown separately.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: 2 ap = \"Ve 2D 2 400 = 0.016 (25) V* (1.204) 2(0.450) V = 27.34 ft/s",
    "sourceChoicesOriginalOrder": [
      "A. 27.34 ft/s",
      "B. 43.72ft/s",
      "C. 89.68 ft/s",
      "D. 86.98 ft/s"
    ],
    "id": "bluebook-aircon-292",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=57"
  },
  {
    "sourceProblemNumber": 293,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Rectangular Duct Equivalent Diameter",
    "difficulty": "Intermediate",
    "prompt": "A rectangular duct has a dimension of 0.25 m by 2 m. Determine the equivalent diameter of the duct.",
    "options": [
      {
        "value": "A",
        "text": "0.50 m"
      },
      {
        "value": "B",
        "text": "0.60 m"
      },
      {
        "value": "C",
        "text": "0.70 m"
      },
      {
        "value": "D",
        "text": "0.40 m"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Rectangular duct dimensions a=0.25 m and b=2 m"
    ],
    "formula": "D_e=\\frac{2ab}{a+b}",
    "formulaReason": "This problem is classified as Rectangular Duct Equivalent Diameter. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "D_e=2(0.25)(2)/(0.25+2)=1/2.25≈0.444 m.",
    "calculation": [
      "Use the source correlation D_e=2ab/(a+b).",
      "D_e≈0.444 m; the closest listed choice rounded to one decimal place is 0.40 m (D)."
    ],
    "finalAnswer": "D — approximately 0.40 m to the nearest listed option",
    "unitCheck": "The numerator is m² and denominator is m, leaving meters.",
    "concept": "Equivalent diameter provides a representative diameter for rectangular duct calculations under a specified correlation.",
    "shortcutFormula": "D_e=\\frac{2ab}{a+b}",
    "shortcut": "Substitute both sides carefully and round only at the end.",
    "commonMistakes": [
      "Do not confuse equivalent diameter correlations; some references use hydraulic diameter 4A/P.",
      "The exact computed value is about 0.444 m, not exactly 0.400 m."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 293; original PDF page 82; extracted PDF page 58",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 82,
    "sourceExtractedPdfPage": 58,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=58",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: _2ab _ 2(0.25)(2) _ Deg = atb 0.25+2 0.40m",
    "sourceChoicesOriginalOrder": [
      "A. 0.50 m",
      "B. 0.60 m",
      "C. 0.70 m",
      "D. 0.40 m"
    ],
    "id": "bluebook-aircon-293",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=58"
  },
  {
    "sourceProblemNumber": 299,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Mixing Two Air Streams",
    "difficulty": "Intermediate",
    "prompt": "The mass of an outside air at 50°C in an air conditioning unit is 60 kg. Find the temperature after mixing if the outside air mixed with 40 kg with recirculated air at 35°C.",
    "options": [
      {
        "value": "A",
        "text": "44°C"
      },
      {
        "value": "B",
        "text": "39°C"
      },
      {
        "value": "C",
        "text": "52°C"
      },
      {
        "value": "D",
        "text": "47°C"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Outside air: 60 kg at 50°C",
      "Recirculated air: 40 kg at 35°C"
    ],
    "formula": "m_1T_1+m_2T_2=(m_1+m_2)T_3",
    "formulaReason": "This problem is classified as Mixing Two Air Streams. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "60(50)+40(35)=(60+40)T₃.",
    "calculation": [
      "T₃=[60(50)+40(35)]/100=44°C."
    ],
    "finalAnswer": "A — 44°C",
    "unitCheck": "Mass cancels; final temperature remains °C.",
    "concept": "For two streams of the same gas with similar specific heat and negligible heat exchange, the mixed temperature is the mass-weighted average.",
    "shortcutFormula": "m_1T_1+m_2T_2=(m_1+m_2)T_3",
    "shortcut": "Multiply each inlet temperature by its mass, add, and divide by total mass.",
    "commonMistakes": [
      "Do not take the simple average unless the two mass flow rates are equal.",
      "Use consistent mass-flow or mass bases for both streams."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 299; original PDF page 84; extracted PDF page 59",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 84,
    "sourceExtractedPdfPage": 59,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=59",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: m,t, +m,t, = m,t, 60(50) + 40(35) = (60 + 40)t, t, = 44°C",
    "sourceChoicesOriginalOrder": [
      "A. 44°C",
      "B. 39°C",
      "C. 52°C",
      "D. 47°C"
    ],
    "id": "bluebook-aircon-299",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=59"
  },
  {
    "sourceProblemNumber": 300,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Milk Cooling Refrigeration Capacity",
    "difficulty": "Intermediate",
    "prompt": "A creamery must cool 20,000 liters of milk received each day from an initial temperature of 29°C to a final temperature of 2°C in 5 hours. If refrigeration losses amount to 10 percent of the cooling load, what must be the capacity of their refrigerating machine? Note: specific heat of milk is 3.9 kJ/kg-K and SG = 1.05.",
    "options": [
      {
        "value": "A",
        "text": "38.5 TOR"
      },
      {
        "value": "B",
        "text": "36.5 TOR"
      },
      {
        "value": "C",
        "text": "37.5 TOR"
      },
      {
        "value": "D",
        "text": "39.5 TOR"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Milk amount =20,000 L/day",
      "29°C to 2°C in 5 hr",
      "Source appears to use c_p≈3.9 kJ/(kg·K)",
      "10% refrigeration losses"
    ],
    "formula": "\\dot Q=1.10\\dot m c_p\\Delta T;\\quad TR=\\dot Q/3.516",
    "formulaReason": "This problem is classified as Milk Cooling Refrigeration Capacity. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Use ṁ=total milk mass / cooling interval, then Q̇=1.10ṁc_pΔT.",
    "calculation": [
      "The source solution OCR reports Q̇≈135.52 kW and 38.5 TR.",
      "The transcribed amount/time and the OCR intermediate mass flow do not reconcile cleanly; verify whether the quantity was 20,000 L or a different figure in the original page."
    ],
    "finalAnswer": "Source reports A — 38.5 TR (UNVERIFIED)",
    "unitCheck": "kg/s×kJ/(kg·K)×K=kW; kW/3.516=TR.",
    "concept": "Milk-cooling load is the sensible heat removed from product, increased by the stated refrigeration-loss allowance.",
    "shortcutFormula": "\\dot Q=1.10\\dot m c_p\\Delta T;\\quad TR=\\dot Q/3.516",
    "shortcut": "Compute mass rate over the stated cooling time, multiply by c_pΔT, apply the loss factor, then convert to TR.",
    "commonMistakes": [
      "Check whether a daily milk volume is processed over 5 hours or over 24 hours.",
      "Apply the 10% loss factor once, not repeatedly."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 300; original PDF page 84; extracted PDF page 60",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 84,
    "sourceExtractedPdfPage": 60,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=60",
    "sourceAnswerStatus": "Source question and worked mass-flow value appear inconsistent; not scoreable until checked.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: The total Refrigeration Capacity with 10% refrigeration losses: Q = 1.10Q = 1.10mC, At where: = Ve = Sams (1) = 2417 ke/s then; Qy, = 1.10[1.17(3.9)(29 — 2)] = 135.52 kW = 38.5 TOR",
    "sourceChoicesOriginalOrder": [
      "A. 38.5 TOR",
      "B. 36.5 TOR",
      "C. 37.5 TOR",
      "D. 39.5 TOR"
    ],
    "id": "bluebook-aircon-300",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=60"
  },
  {
    "sourceProblemNumber": 301,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Ice Production Capacity",
    "difficulty": "Intermediate",
    "prompt": "How many tons of refrigeration is required to produce 10 metric tons of ice per day at - 10°C from raw water at 22°C if miscellaneous losses are 15% of the chilling and freezing load?",
    "options": [
      {
        "value": "A",
        "text": "17 TOR"
      },
      {
        "value": "B",
        "text": "20 TOR"
      },
      {
        "value": "C",
        "text": "15 TOR"
      },
      {
        "value": "D",
        "text": "24 TOR"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Ice production =10 metric tons/day",
      "Raw water at 22°C; ice to −10°C",
      "Miscellaneous losses =15%"
    ],
    "formula": "\\dot Q=\\frac{m}{\\Delta t}[c_{p,w}(T_i-0)+h_f+c_{p,i}(0-T_f)](1+L)",
    "formulaReason": "This problem is classified as Ice Production Capacity. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Add sensible cooling of water, latent heat of freezing, and sensible cooling of ice; multiply load by 1.15.",
    "calculation": [
      "Per kg: q≈4.187(22)+335+2.098(10) kJ/kg.",
      "Multiply by 10,000 kg/day and divide by 86,400 s/day to obtain kW.",
      "Apply 15% loss allowance; source result ≈17 TR."
    ],
    "finalAnswer": "A — 17 TR",
    "unitCheck": "kJ/day to kW requires division by 86,400; then divide by 3.516 for TR.",
    "concept": "Ice production requires three thermal stages: cool water to 0°C, freeze it, then cool the ice below 0°C.",
    "shortcutFormula": "\\dot Q=\\frac{m}{\\Delta t}[c_{p,w}(T_i-0)+h_f+c_{p,i}(0-T_f)](1+L)",
    "shortcut": "Draw a temperature path with liquid, phase change, then ice; sum the three energy parts.",
    "commonMistakes": [
      "Do not omit latent heat.",
      "Do not apply losses as a subtraction when the source defines them as an added load."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 301; original PDF page 84; extracted PDF page 61",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 84,
    "sourceExtractedPdfPage": 61,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=61",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Phase change of water transformed into ice: Qr = Q4+04+0;+O where: Qa = mh, C,,,At,, Ay 10,000kg KU _ or _ Q,= (oe) (4.187 =<) (22 — 0)°C = 10.66 kj/s ~ _ { 10,000kg WW) _ Q = (reco) (335) = 38.773 kW ~ _ { 10,000kg NO or _ Q; = (pore) (2.098) (0 + 10)°C = 2.428 kw Q. = 0.15(10.66 + 38.773 + 2.428) = 7.779 kW Qr = 10.66 + 38.773 + 2.428 + 7.779 = 59.64 kW = 17 TOR",
    "sourceChoicesOriginalOrder": [
      "A. 17 TOR",
      "B. 20 TOR",
      "C. 15 TOR",
      "D. 24 TOR"
    ],
    "id": "bluebook-aircon-301",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=61"
  },
  {
    "sourceProblemNumber": 302,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Poultry Freezing Load",
    "difficulty": "Intermediate",
    "prompt": "Five hundred kilograms of poultry enter a chiller at 8°C and are frozen and chilled to a final temperature of 18°C for storage in 15 hours. The specific heat above and below freezing are 3.18 kJ/kg-°C and 1.55 kJ/kg-°C respectively. The latent heat is 246 kJ/kg and the freezing temperature is -5°C. Compute the product load.",
    "options": [
      {
        "value": "A",
        "text": "2.75 kW"
      },
      {
        "value": "B",
        "text": "2.85 kW"
      },
      {
        "value": "C",
        "text": "2.95 kW"
      },
      {
        "value": "D",
        "text": "3.15 kW"
      }
    ],
    "answer": "B",
    "answerVerified": false,
    "given": [
      "Poultry mass =500 kg",
      "Initial temperature =8°C",
      "Prompt transcription says final 18°C (likely missing a minus sign in scan)",
      "Specific heats and latent heat as printed in source solution"
    ],
    "formula": "\\dot Q=(Q_{above}+Q_{latent}+Q_{below})/\\Delta t",
    "formulaReason": "This problem is classified as Poultry Freezing Load. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "The source calculation separates pre-freezing sensible load, latent freezing load, and post-freezing sensible load.",
    "calculation": [
      "The source OCR reports about 2.85 kW.",
      "The prompt as extracted lacks a negative sign for the final storage temperature, while the source working appears to cool below freezing.",
      "Verify the final temperature and specific-heat/latent-heat values before scoring."
    ],
    "finalAnswer": "Source result B — 2.85 kW (UNVERIFIED sign / property details)",
    "unitCheck": "Total kJ divided by the process time in seconds gives kW.",
    "concept": "Freezing loads must account for sensible heat above freezing, latent heat, and sensible heat below freezing.",
    "shortcutFormula": "\\dot Q=(Q_{above}+Q_{latent}+Q_{below})/\\Delta t",
    "shortcut": "Split the process at the freezing point and sum each energy term before dividing by elapsed time.",
    "commonMistakes": [
      "Do not overlook a minus sign in the storage temperature.",
      "Do not confuse kJ total with kW rate."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 302; original PDF page 85; extracted PDF page 62",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 85,
    "sourceExtractedPdfPage": 62,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=62",
    "sourceAnswerStatus": "Source question sign/details unclear in extracted transcription.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Qr = aX + Q + Q; _ (_500k; kj on Q= (eats) (3.185) (8 + 5)°C = 0.38 kW _ (_500kg Kl) _ & = (serseonys) (2465) = 2.28 kW _ (500k, KJ or Qs = (seas ;) (1.55) (5 + 18)°C = 0.19 kW Q, = 2.85 kW",
    "sourceChoicesOriginalOrder": [
      "A. 2.75 kW",
      "B. 2.85 kW",
      "C. 2.95 kW",
      "D. 3.15 kW"
    ],
    "id": "bluebook-aircon-302",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=62"
  },
  {
    "sourceProblemNumber": 303,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Fish Freezing & Cold-Storage Load",
    "difficulty": "Intermediate",
    "prompt": "Fish weighing 11,000 kg with a temperature of 20°C is brought to a cold storage and which shall be cooled to -10°C in 11 hours. Find the required plant refrigerating capacity in tons of refrigeration if the specific heat of fish is 0.7 kCal/kg-°C above freezing point and 0.30 kCal/kg- °C below freezing point. The freezing point is -3°C. The latent heat of freezing is 55.5 kCal/kg.",
    "options": [
      {
        "value": "A",
        "text": "25.26 TOR"
      },
      {
        "value": "B",
        "text": "15.26 TOR"
      },
      {
        "value": "C",
        "text": "14.38 TOR"
      },
      {
        "value": "D",
        "text": "24.38 TOR"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Fish mass =11,000 kg",
      "Initial =20°C; final =−10°C",
      "Time =11 hr"
    ],
    "formula": "\\dot Q=\\frac{m}{\\Delta t}(q_{above}+h_f+q_{below})",
    "formulaReason": "This problem is classified as Fish Freezing & Cold-Storage Load. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "The source splits the product load into sensible cooling, freezing latent heat, and post-freezing sensible cooling.",
    "calculation": [
      "Calculate sensible cooling to the freezing point, latent heat removal, and cooling of the frozen product to −10°C.",
      "Sum energy for 11,000 kg and divide by 11 hr to find the rate.",
      "Source result ≈85.71 kW =24.38 TR."
    ],
    "finalAnswer": "D — 24.38 TR",
    "unitCheck": "kW/3.516=TR.",
    "concept": "Product freezing combines sensible and latent loads; the refrigeration rate depends on both total energy and allowed time.",
    "shortcutFormula": "\\dot Q=\\frac{m}{\\Delta t}(q_{above}+h_f+q_{below})",
    "shortcut": "Separate the temperature ranges and phase change, then convert total energy to a rate.",
    "commonMistakes": [
      "Do not omit latent heat.",
      "Use the full 11-hour time interval and consistent units."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 303; original PDF page 85; extracted PDF page 63",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 85,
    "sourceExtractedPdfPage": 63,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=63",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Qr = QQ + Q, + Q; ~ _ (11,000kg Cal) or Q, = (4% ore) (07 os ~) (20 + 3)°C = 4.47 kCal/s ~» _ ( 11,000kg KW) _ Q = (oe) (55.5 2) = 15.24 kCal/s ~ _ { 11,000kg kcal) ¢_ or — Qs = (SACs) (0.34) (-3 + 10)°C = 0.58 kCal/s then; Qy = 20.475 = 85.71kW = 24.38 TOR",
    "sourceChoicesOriginalOrder": [
      "A. 25.26 TOR",
      "B. 15.26 TOR",
      "C. 14.38 TOR",
      "D. 24.38 TOR"
    ],
    "id": "bluebook-aircon-303",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=63"
  },
  {
    "sourceProblemNumber": 304,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Carnot Refrigerator Heat Rejection",
    "difficulty": "Intermediate",
    "prompt": "The power requirement of a Carnot refrigerator in maintaining a low temperature region at 300 K is 1.5 kW per ton. Find the heat rejected.",
    "options": [
      {
        "value": "A",
        "text": "4.02 kW"
      },
      {
        "value": "B",
        "text": "7.02 kW"
      },
      {
        "value": "C",
        "text": "5.02 kW"
      },
      {
        "value": "D",
        "text": "6.02 kW"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Low-side temperature =300 K",
      "Input power =1.5 kW per ton of refrigeration",
      "One ton =3.516 kW"
    ],
    "formula": "Q_H=Q_L+W;\\quad COP_R=Q_L/W",
    "formulaReason": "This problem is classified as Carnot Refrigerator Heat Rejection. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "COP_R=3.516/1.5≈2.344; Q_H=Q_L+W=3.516+1.5.",
    "calculation": [
      "Q_L=3.516 kW per ton.",
      "Input W=1.5 kW per ton.",
      "Q_H=3.516+1.5=5.016≈5.02 kW."
    ],
    "finalAnswer": "C — 5.02 kW",
    "unitCheck": "kW+kW=kW.",
    "concept": "For a refrigerator, heat rejected equals cooling heat plus work input.",
    "shortcutFormula": "Q_H=Q_L+W;\\quad COP_R=Q_L/W",
    "shortcut": "For a one-ton basis, directly add 3.516 kW of cooling to 1.5 kW input.",
    "commonMistakes": [
      "Do not confuse condenser heat rejection with evaporator capacity."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 304; original PDF page 85; extracted PDF page 64",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 85,
    "sourceExtractedPdfPage": 64,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=64",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Qp = T,As where: = JTL T, = cop + T, Solving for COP: — Qa _ 3.516 kW _ COP = Wo askw > 2.34 then; T, = +300 = 427.99 K 2.34 AS =—“c_ =— 15 = 9.91172 T,-T, | 427.99-300 K thus; Qp = 427.99(0.01172) = 5.02 kW",
    "sourceChoicesOriginalOrder": [
      "A. 4.02 kW",
      "B. 7.02 kW",
      "C. 5.02 kW",
      "D. 6.02 kW"
    ],
    "id": "bluebook-aircon-304",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=64"
  },
  {
    "sourceProblemNumber": 305,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Chilled-Water Flow from Condenser Load",
    "difficulty": "Intermediate",
    "prompt": "A vapor compression refrigeration system is designed to have a capacity of 150 tons of refrigeration. It produces chilled water from 22°C to 2°C. Its actual coefficient of performance is 5.86 and 35% of the power supplied to the compressor is lost in the form of friction and cylinder cooling losses. Determine the condenser cooling water required for a temperature rise of 10°C.",
    "options": [
      {
        "value": "A",
        "text": "14.75 kg/s"
      },
      {
        "value": "B",
        "text": "15.65 kg/s"
      },
      {
        "value": "C",
        "text": "18.65 kg/s"
      },
      {
        "value": "D",
        "text": "13.75 kg/s"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Capacity =150 TR",
      "Chilled water from 22°C to 2°C",
      "Actual COP =5.86 as inferred from source",
      "Cooling-water temperature rise =10°C"
    ],
    "formula": "\\dot Q_H=\\dot Q_L+W;\\quad \\dot m_w=\\dot Q_H/(c_p\\Delta T)",
    "formulaReason": "This problem is classified as Chilled-Water Flow from Condenser Load. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q̇_L=150(3.516)=527.4 kW; W≈527.4/5.86≈90 kW; Q̇_H≈617.4 kW.",
    "calculation": [
      "Refrigeration load =527.4 kW.",
      "Condenser heat rejection =527.4+90=617.4 kW.",
      "ṁ_water=617.4/[4.187(10)]≈14.75 kg/s."
    ],
    "finalAnswer": "A — 14.75 kg/s",
    "unitCheck": "kW = kg/s×kJ/(kg·K)×K.",
    "concept": "Water flow in a condenser follows from condenser heat rejection divided by water heat capacity and temperature rise.",
    "shortcutFormula": "\\dot Q_H=\\dot Q_L+W;\\quad \\dot m_w=\\dot Q_H/(c_p\\Delta T)",
    "shortcut": "Add compressor work to evaporator load to get condenser load, then apply ṁ=Q̇/(c_pΔT).",
    "commonMistakes": [
      "Condenser load is greater than evaporator load by compressor work.",
      "Use the condenser-water temperature rise, not the chilled-water temperature drop."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 305; original PDF page 86; extracted PDF page 65",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 86,
    "sourceExtractedPdfPage": 65,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=65",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: By Energy Balance: Qe = We + RE = thy, C,,,At,, where: RE = 150(3.516) = 527.4 kW from: RE COP = We 527.4 W. = 90 kw then: Qa = 527.4490 = 617.4 617.4 =m,,C,,At, = tm, (4.187) (10) thus; my = 14.75 kg/s",
    "sourceChoicesOriginalOrder": [
      "A. 14.75 kg/s",
      "B. 15.65 kg/s",
      "C. 18.65 kg/s",
      "D. 13.75 kg/s"
    ],
    "id": "bluebook-aircon-305",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=65"
  },
  {
    "sourceProblemNumber": 306,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Water Freezing to Ice at −10°C",
    "difficulty": "Intermediate",
    "prompt": "Determine the heat extracted from 2000 kg of water from 25°C to ice at -10°C.",
    "options": [
      {
        "value": "A",
        "text": "621,150 kJ"
      },
      {
        "value": "B",
        "text": "721,150 kJ"
      },
      {
        "value": "C",
        "text": "821,150 kJ"
      },
      {
        "value": "D",
        "text": "921,150 kJ"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Water mass =2000 kg",
      "Initial water temperature =25°C",
      "Final ice temperature =−10°C"
    ],
    "formula": "Q=m[c_{p,w}(25-0)+h_f+c_{p,i}(0-(-10))]",
    "formulaReason": "This problem is classified as Water Freezing to Ice at −10°C. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q=2000(4.187)(25)+2000(335)+2000(2.09)(10).",
    "calculation": [
      "Cool water from 25°C to 0°C: Q₁=209,350 kJ.",
      "Freeze water at 0°C: Q₂=670,000 kJ.",
      "Cool ice from 0°C to −10°C: Q₃=41,800 kJ.",
      "Q_total=921,150 kJ."
    ],
    "finalAnswer": "D — 921,150 kJ",
    "unitCheck": "Each term is kg×kJ/kg = kJ.",
    "concept": "Water freezing requires sensible cooling of liquid, latent heat of fusion, and sensible cooling of ice.",
    "shortcutFormula": "Q=m[c_{p,w}(25-0)+h_f+c_{p,i}(0-(-10))]",
    "shortcut": "Use a three-part heat balance and add the energies.",
    "commonMistakes": [
      "Do not use liquid-water c_p below 0°C.",
      "Do not omit latent heat of fusion."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 306; original PDF page 86; extracted PDF page 66",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 86,
    "sourceExtractedPdfPage": 66,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=66",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Qr = 214+ Q,4+ Q3 where: Q, = 2000(4.187)(25 — 0) = 209,350 kJ Q, = 2000(335) = 670,000 kj Q; = 2000(2.09)(0 + 10) = 41,800 thus; Qy = 209,350 + 670,000 + 41,800 = 921,150 kJ",
    "sourceChoicesOriginalOrder": [
      "A. 621,150 kJ",
      "B. 721,150 kJ",
      "C. 821,150 kJ",
      "D. 921,150 kJ"
    ],
    "id": "bluebook-aircon-306",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=66"
  },
  {
    "sourceProblemNumber": 307,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Ammonia Compressor Bore",
    "difficulty": "Intermediate",
    "prompt": "A single acting, twin cylinder, Ammonia compressor with bore equal to stroke is driven by an engine at 250 rpm. The machine is installed in a chilling plant to produce 700 kW of refrigeration at -18°C evaporating temperature. At this temperature the cooling effect per kg mass is 1160 kJ. The specific volume of vapor entering the compressor is 0.592 m3 per kilogram. Assume 85% volumetric efficiency, determine the bore in mm.",
    "options": [
      {
        "value": "A",
        "text": "400 mm"
      },
      {
        "value": "B",
        "text": "300 mm"
      },
      {
        "value": "C",
        "text": "450 mm"
      },
      {
        "value": "D",
        "text": "500 mm"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Cooling capacity =700 kW at −18°C",
      "Cooling effect =1160 kJ/kg",
      "Suction specific volume =0.592 m³/kg",
      "Twin cylinder, single acting, 250 rpm",
      "Volumetric efficiency =85%",
      "Bore = stroke"
    ],
    "formula": "V_p=\\frac{\\pi D^2}{4}LN\\times n_c;\\quad \\dot V_{actual}=\\eta_v V_p",
    "formulaReason": "This problem is classified as Ammonia Compressor Bore. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "ṁ=700/1160≈0.603 kg/s; actual suction volume =0.603(0.592)≈0.357 m³/s.",
    "calculation": [
      "Compute mass flow from cooling capacity/refrigerating effect.",
      "Convert to actual intake volume using suction specific volume; divide by volumetric efficiency for piston displacement.",
      "For two single-acting cylinders with stroke equal to bore, solve the swept-volume expression; source result D≈0.40 m."
    ],
    "finalAnswer": "A — 400 mm",
    "unitCheck": "Keep m³/s, seconds per revolution, and cylinder count consistent.",
    "concept": "Compressor bore is derived from required swept volume, which is larger than actual suction volume when volumetric efficiency is below 100%.",
    "shortcutFormula": "V_p=\\frac{\\pi D^2}{4}LN\\times n_c;\\quad \\dot V_{actual}=\\eta_v V_p",
    "shortcut": "Find mass flow, actual intake volume, piston displacement, then solve D using L=D.",
    "commonMistakes": [
      "Use actual volume flow divided by volumetric efficiency to find displacement.",
      "Count both cylinders and use the stated single-acting configuration."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 307; original PDF page 87; extracted PDF page 67",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 87,
    "sourceExtractedPdfPage": 67,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=67",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Vp = =\" LNC = =D (=) (2) = 6.545D3 Solving for the piston displacement, Vp: V= Ma _ mi _ m(0.592) DT ey, 0.85 0.85 from: Qa, = m(h, —h,) = m(1160) = 0.603 kg/s then; Vp = 0.42m3/s thus; 0.42 = 6.545D D = 0.40 m= 400 mm",
    "sourceChoicesOriginalOrder": [
      "A. 400 mm",
      "B. 300 mm",
      "C. 450 mm",
      "D. 500 mm"
    ],
    "id": "bluebook-aircon-307",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=67"
  },
  {
    "sourceProblemNumber": 340,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Horizontal Flash-Tank Disengagement Area",
    "difficulty": "Intermediate",
    "prompt": "A cylindrical flash tank mounted with its axis horizontal is used to separate liquid ammonia from ammonia vapor. The ammonia bubbles through the liquid with 70 m3/min leaving the disengaging surface. The disengaging rate is limited to 60 m/min and the liquid level is to operate with the liquid level one-third to the diameter from the top. Determine the diameter if the tank is 1.5 m long.",
    "options": [
      {
        "value": "A",
        "text": "830 mm"
      },
      {
        "value": "B",
        "text": "730 mm"
      },
      {
        "value": "C",
        "text": "860 mm"
      },
      {
        "value": "D",
        "text": "760 mm"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Vapor flow =70 m³/min",
      "Allowable disengaging rate =60 m/min",
      "Tank length =1.5 m",
      "Liquid level is one-third of diameter from the top"
    ],
    "formula": "\\dot V=A_{disengage}V_{allow}",
    "formulaReason": "This problem is classified as Horizontal Flash-Tank Disengagement Area. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Required disengagement area =70/60≈1.167 m².",
    "calculation": [
      "A_required=V̇/V_allow=70/60≈1.167 m².",
      "The tank’s horizontal segment area depends on the stated liquid-level chord and tank diameter.",
      "The source solution crop is incomplete in the supplied extraction; answer A is retained from the source set but not marked scoreable."
    ],
    "finalAnswer": "Source choice A — 830 mm diameter (UNVERIFIED)",
    "unitCheck": "m³/min divided by m/min gives m².",
    "concept": "A flash tank needs enough free cross-sectional area above the liquid for vapor to disengage without exceeding the permitted velocity.",
    "shortcutFormula": "\\dot V=A_{disengage}V_{allow}",
    "shortcut": "Calculate required free area first; then relate the circular-segment geometry to diameter.",
    "commonMistakes": [
      "Do not use total cylinder cross-section if part is occupied by liquid.",
      "The liquid-level position determines the vapor disengagement area."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 340; original PDF page 95; extracted PDF page 68",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 95,
    "sourceExtractedPdfPage": 68,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=68",
    "sourceAnswerStatus": "Original worked-solution crop/transcription is incomplete for final geometric calculation.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Let Q = rate of separation A = disengaging area D/3| V = disengaging rate DIE > 2D/3 then; Q = AV 70=60A A= 1.17 m? = 2bL from fig: 2— (2) _ (2) b’= () (<) pb=2p 3 =2(2 A=2(2D)L = 2(% 117 = 2(4 D) (2) thus; D=0.83 m= 830 mm",
    "sourceChoicesOriginalOrder": [
      "A. 830 mm",
      "B. 730 mm",
      "C. 860 mm",
      "D. 760 mm"
    ],
    "id": "bluebook-aircon-340",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=68"
  },
  {
    "sourceProblemNumber": 341,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Compressor Energy Balance",
    "difficulty": "Intermediate",
    "prompt": "A 150 Hp motor is used to drive the compressor. If the heat loss from the compressor is 25 kW and the mass flow rate of the refrigerant entering the compressor is 0.50 kg/s, determine the difference of the enthalpies between the inlet and outlet of the compressor.",
    "options": [
      {
        "value": "A",
        "text": "143.80 kJ/kg"
      },
      {
        "value": "B",
        "text": "153.80 kJ/kg"
      },
      {
        "value": "C",
        "text": "173.80 kJ/kg"
      },
      {
        "value": "D",
        "text": "183.80 kJ/kg"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Motor power =150 hp",
      "Compressor heat loss =25 kW",
      "Refrigerant mass flow =0.50 kg/s"
    ],
    "formula": "\\dot W_{in}-\\dot Q_{loss}=\\dot m(h_2-h_1)",
    "formulaReason": "This problem is classified as Compressor Energy Balance. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "W_in=150(0.746)=111.9 kW; net energy transfer to refrigerant=111.9−25=86.9 kW.",
    "calculation": [
      "Net energy to refrigerant =86.9 kW.",
      "Δh=86.9 kW/(0.50 kg/s)=173.8 kJ/kg."
    ],
    "finalAnswer": "C — 173.80 kJ/kg",
    "unitCheck": "kW/(kg/s)=kJ/kg.",
    "concept": "The steady-flow energy balance equates shaft input minus heat lost to the refrigerant enthalpy rise.",
    "shortcutFormula": "\\dot W_{in}-\\dot Q_{loss}=\\dot m(h_2-h_1)",
    "shortcut": "Convert hp to kW, subtract heat loss, then divide by mass flow.",
    "commonMistakes": [
      "Subtract compressor heat loss from shaft input as shown by the stated sign convention.",
      "Convert hp using 0.746 kW/hp."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 341; original PDF page 96; extracted PDF page 69",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 96,
    "sourceExtractedPdfPage": 69,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=69",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: We. = mAh where: We = Pmotor — Heat Loss = 150(0.746) — 25 = 86.9 kw then; 86.9 = 0.50(Ah) Ah = 173.80 kJ/kg",
    "sourceChoicesOriginalOrder": [
      "A. 143.80 kJ/kg",
      "B. 153.80 kJ/kg",
      "C. 173.80 kJ/kg",
      "D. 183.80 kJ/kg"
    ],
    "id": "bluebook-aircon-341",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=69"
  },
  {
    "sourceProblemNumber": 342,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Ice Melting Cooling Rate",
    "difficulty": "Intermediate",
    "prompt": "To cool farm products, 300 kg of ice at -4.4°C are placed in bunker. Twenty four hours later the ice has melted into water at 7.2°C. What is the average rate of cooling provided by the ice in kJ/hr?",
    "options": [
      {
        "value": "A",
        "text": "2679.28 kJ/hr"
      },
      {
        "value": "B",
        "text": "5679.28 kJ/hr"
      },
      {
        "value": "C",
        "text": "3679.28 kJ/hr"
      },
      {
        "value": "D",
        "text": "4679.28 kJ/hr"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "Ice =300 kg at −4.4°C",
      "Final liquid water =7.2°C",
      "Elapsed time =24 hr"
    ],
    "formula": "Q=m[c_{p,i}\\Delta T+h_f+c_{p,w}\\Delta T]/\\Delta t",
    "formulaReason": "This problem is classified as Ice Melting Cooling Rate. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q_total=300[2.09(4.4)+335+4.187(7.2)] kJ.",
    "calculation": [
      "Warm ice to 0°C, melt it, then warm water to 7.2°C.",
      "Q_total≈112,302.7 kJ.",
      "Average rate ≈112,302.7/24≈4679.3 kJ/hr."
    ],
    "finalAnswer": "D — 4679.28 kJ/hr",
    "unitCheck": "kJ divided by hr gives kJ/hr.",
    "concept": "Melting ice absorbs heat through warming of ice, latent fusion, and warming of the resulting water.",
    "shortcutFormula": "Q=m[c_{p,i}\\Delta T+h_f+c_{p,w}\\Delta T]/\\Delta t",
    "shortcut": "Add the three energy stages and divide by 24 hr.",
    "commonMistakes": [
      "Do not omit warming the ice below zero or warming the water above zero.",
      "Divide total energy by the full 24-hour interval."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 342; original PDF page 96; extracted PDF page 70",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 96,
    "sourceExtractedPdfPage": 70,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=70",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q = Qi + Q, + Q; ~ _ 300 kg _ KE Q= Sehr [2.09(0 + 4.4) + 335 + 4.187(7.2 — 0)] ie Q = 4679.28 kJ /hr",
    "sourceChoicesOriginalOrder": [
      "A. 2679.28 kJ/hr",
      "B. 5679.28 kJ/hr",
      "C. 3679.28 kJ/hr",
      "D. 4679.28 kJ/hr"
    ],
    "id": "bluebook-aircon-342",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=70"
  },
  {
    "sourceProblemNumber": 343,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Condenser Heat-Rejection Factor",
    "difficulty": "Intermediate",
    "prompt": "Determine the estimated condenser load for an open-type compressor having a cooling capacity of 16,500 Btu/hr and a heat rejection factor of 1.32.",
    "options": [
      {
        "value": "A",
        "text": "22,280 Btu/hr"
      },
      {
        "value": "B",
        "text": "20,780 Btu/hr"
      },
      {
        "value": "C",
        "text": "21,780 Btu/hr"
      },
      {
        "value": "D",
        "text": "19,780 Btu/hr"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Cooling capacity =16,500 Btu/hr",
      "Heat-rejection factor =1.32"
    ],
    "formula": "Q_H=Q_L\\times F_{rejection}",
    "formulaReason": "This problem is classified as Condenser Heat-Rejection Factor. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Q_H=16,500(1.32).",
    "calculation": [
      "Q_H=16,500×1.32=21,780 Btu/hr."
    ],
    "finalAnswer": "C — 21,780 Btu/hr",
    "unitCheck": "Btu/hr times a dimensionless factor remains Btu/hr.",
    "concept": "Condenser load exceeds evaporator cooling capacity because compressor work is also rejected as heat.",
    "shortcutFormula": "Q_H=Q_L\\times F_{rejection}",
    "shortcut": "Multiply the cooling capacity by the stated heat-rejection factor.",
    "commonMistakes": [
      "Do not add the factor to the load; multiply by it."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 343; original PDF page 96; extracted PDF page 71",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 96,
    "sourceExtractedPdfPage": 71,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=71",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Condenser Load = Compressor Capacity x heat rejection factor = 16,500(1.32) = 21,780 Btu/hr",
    "sourceChoicesOriginalOrder": [
      "A. 22,280 Btu/hr",
      "B. 20,780 Btu/hr",
      "C. 21,780 Btu/hr",
      "D. 19,780 Btu/hr"
    ],
    "id": "bluebook-aircon-343",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=71"
  },
  {
    "sourceProblemNumber": 344,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Condenser Cooling-Water Flow",
    "difficulty": "Intermediate",
    "prompt": "If the load on water-cooled condenser is 150,000 Btu/hr and the temperature rise of the water in the condenser is 10°F, what is the quantity of water circulated in gpm?",
    "options": [
      {
        "value": "A",
        "text": "30 GPM"
      },
      {
        "value": "B",
        "text": "40 GPM"
      },
      {
        "value": "C",
        "text": "20 GPM"
      },
      {
        "value": "D",
        "text": "50 GPM"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Condenser load =150,000 Btu/hr",
      "Water temperature rise =10°F"
    ],
    "formula": "\\dot Q=\\dot m c_p\\Delta T",
    "formulaReason": "This problem is classified as Condenser Cooling-Water Flow. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "ṁ=150,000/[1(10)]=15,000 lb/hr.",
    "calculation": [
      "Water mass flow =15,000 lb/hr using c_p≈1 Btu/(lb·°F).",
      "Convert to volume rate with 8.33 lb/gal: about 30 GPM."
    ],
    "finalAnswer": "A — 30 GPM",
    "unitCheck": "Btu/hr ÷ [Btu/(lb·°F)×°F] = lb/hr.",
    "concept": "Condenser heat rejection is absorbed by circulating water as a sensible temperature rise.",
    "shortcutFormula": "\\dot Q=\\dot m c_p\\Delta T",
    "shortcut": "Find lb/hr from Q̇/(c_pΔT), then convert lb/hr to gal/min.",
    "commonMistakes": [
      "Keep the water density conversion explicit.",
      "Do not confuse gpm with gal/hr."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 344; original PDF page 97; extracted PDF page 72",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 97,
    "sourceExtractedPdfPage": 72,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=72",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q=mC,t 150,000 = m(1)(10) m = 15,000 lb/hr Solving for V in gpm: Vets ae bia = 1800.72 gal/hr = 30 GPM",
    "sourceChoicesOriginalOrder": [
      "A. 30 GPM",
      "B. 40 GPM",
      "C. 20 GPM",
      "D. 50 GPM"
    ],
    "id": "bluebook-aircon-344",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=72"
  },
  {
    "sourceProblemNumber": 345,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Condenser Water Temperature Rise",
    "difficulty": "Intermediate",
    "prompt": "The load on a water-cooled condenser is 90,000 Btu/hr. if the quantity of water circulated through the condenser is 15 gpm, determine the temperature rise of the water in the condenser.",
    "options": [
      {
        "value": "A",
        "text": "12°F"
      },
      {
        "value": "B",
        "text": "14°F"
      },
      {
        "value": "C",
        "text": "16°F"
      },
      {
        "value": "D",
        "text": "18°F"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Condenser load =90,000 Btu/hr",
      "Water circulation =15 GPM"
    ],
    "formula": "\\Delta T=\\dot Q/(\\dot m c_p)",
    "formulaReason": "This problem is classified as Condenser Water Temperature Rise. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "ṁ≈15(8.33)(60)=7497 lb/hr.",
    "calculation": [
      "Water mass flow ≈7497 lb/hr.",
      "ΔT=90,000/[7497(1)]≈12°F."
    ],
    "finalAnswer": "A — 12°F",
    "unitCheck": "Btu/hr ÷ Btu/(hr·°F) = °F.",
    "concept": "The water temperature rise is proportional to condenser heat load and inversely proportional to water mass flow.",
    "shortcutFormula": "\\Delta T=\\dot Q/(\\dot m c_p)",
    "shortcut": "Convert GPM to lb/hr, then use ΔT=Q̇/(ṁc_p).",
    "commonMistakes": [
      "Use 60 min/hr when converting GPM to gal/hr.",
      "Check the approximate density of water in lb/gal."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 345; original PDF page 97; extracted PDF page 73",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 97,
    "sourceExtractedPdfPage": 73,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=73",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q = mC, At Btu . Btu 90,0005\" = tin (1 ox) (At) where: . Ib m= pV = 833 Gs Hem) = 7497 lb/hr thus; 90,000 = 7497(1)At At= 12°F",
    "sourceChoicesOriginalOrder": [
      "A. 12°F",
      "B. 14°F",
      "C. 16°F",
      "D. 18°F"
    ],
    "id": "bluebook-aircon-345",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=73"
  },
  {
    "sourceProblemNumber": 346,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Compressor Piston Displacement",
    "difficulty": "Intermediate",
    "prompt": "The weight of ammonia circulated in a machine is found to be 21.8 lb/hr. if the vapor enters the compressor with a specific volume of 9.6 ft3/lb, calculate the piston displacement, assuming 80% percent volume efficiency.",
    "options": [
      {
        "value": "A",
        "text": "261.6 ft3/hr"
      },
      {
        "value": "B",
        "text": "271.6 ft3/hr"
      },
      {
        "value": "C",
        "text": "281.8 ft3/hr"
      },
      {
        "value": "D",
        "text": "291.6 ft3/hr"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Ammonia flow =21.8 lb/hr",
      "Suction specific volume =9.6 ft³/lb",
      "Volumetric efficiency =80%"
    ],
    "formula": "\\dot V_p=\\dot m v/\\eta_v",
    "formulaReason": "This problem is classified as Compressor Piston Displacement. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "V̇_p=21.8(9.6)/0.80.",
    "calculation": [
      "Actual suction volume=21.8(9.6)=209.28 ft³/hr.",
      "Displacement=209.28/0.80=261.6 ft³/hr."
    ],
    "finalAnswer": "A — 261.6 ft³/hr",
    "unitCheck": "lb/hr×ft³/lb=ft³/hr.",
    "concept": "Actual refrigerant suction volume is less than geometric displacement when volumetric efficiency is below unity.",
    "shortcutFormula": "\\dot V_p=\\dot m v/\\eta_v",
    "shortcut": "Multiply mass flow by specific volume to get actual volumetric flow, then divide by volumetric efficiency.",
    "commonMistakes": [
      "Do not multiply the actual volume by efficiency; divide to get displacement."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 346; original PDF page 97; extracted PDF page 74",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 97,
    "sourceExtractedPdfPage": 74,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=74",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: . : Volume flow rate at suction Actual volumetric efficiency = —————W————_ Piston displacement V, _ 21.8(9.6) Ca == Vp Vp Vp = 261.6 ft?/hr",
    "sourceChoicesOriginalOrder": [
      "A. 261.6 ft3/hr",
      "B. 271.6 ft3/hr",
      "C. 281.8 ft3/hr",
      "D. 291.6 ft3/hr"
    ],
    "id": "bluebook-aircon-346",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=74"
  },
  {
    "sourceProblemNumber": 347,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Actual Ammonia Cycle COP",
    "difficulty": "Intermediate",
    "prompt": "A single-stage ammonia compressor is producing 10 tons of refrigeration and the power consumed is 15 Hp. Suction pressure is 25 psi, condensing pressure is 180 psi. Brine temperature is 20°F off brine cooler. Determine the actual coefficient of performance.",
    "options": [
      {
        "value": "A",
        "text": "10.14"
      },
      {
        "value": "B",
        "text": "11.14"
      },
      {
        "value": "C",
        "text": "12.14"
      },
      {
        "value": "D",
        "text": "13.14"
      }
    ],
    "answer": "D",
    "answerVerified": false,
    "given": [
      "Cooling capacity =10 TR",
      "Power input =15 hp",
      "Ammonia suction =25 psi; condensing =180 psi"
    ],
    "formula": "COP=Q_L/W_c",
    "formulaReason": "This problem is classified as Actual Ammonia Cycle COP. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "COP from stated cooling capacity and power is 10(3.516)/[15(0.746)]≈3.14.",
    "calculation": [
      "Cooling rate =10(3.516)=35.16 kW.",
      "Power input =15(0.746)=11.19 kW.",
      "COP≈35.16/11.19≈3.14, but no listed choice matches the value as transcribed."
    ],
    "finalAnswer": "Source OCR reports COP ≈3.14 but listed choices are 10.14–13.14; UNVERIFIED",
    "unitCheck": "kW/kW is dimensionless.",
    "concept": "COP is cooling capacity divided by compressor power input.",
    "shortcutFormula": "COP=Q_L/W_c",
    "shortcut": "Convert TR and hp to kW, then divide cooling rate by input power.",
    "commonMistakes": [
      "Check answer choices and source digits if no option matches a direct calculation.",
      "Do not force an inconsistent value to the nearest unrelated option."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 347; original PDF page 98; extracted PDF page 75",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 98,
    "sourceExtractedPdfPage": 75,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=75",
    "sourceAnswerStatus": "Computed COP does not match the transcribed choices; source answer is not scoreable.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: COP = refrigeration capacity = 10(3.516) = 3.14; ANS 13.14 compressor power 15(0.746)",
    "sourceChoicesOriginalOrder": [
      "A. 10.14",
      "B. 11.14",
      "C. 12.14",
      "D. 13.14"
    ],
    "id": "bluebook-aircon-347",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=75"
  },
  {
    "sourceProblemNumber": 348,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Carnot Refrigeration COP",
    "difficulty": "Intermediate",
    "prompt": "In an ammonia condensing machine (compressor plus condenser) the water used for condensing is 55°F and the evaporator is at 15°F. Calculate the ideal COP.",
    "options": [
      {
        "value": "A",
        "text": "11.875"
      },
      {
        "value": "B",
        "text": "12.875"
      },
      {
        "value": "C",
        "text": "10.875"
      },
      {
        "value": "D",
        "text": "13.875"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Condenser water =55°F",
      "Evaporator =15°F"
    ],
    "formula": "COP_R=\\frac{T_L}{T_H-T_L}",
    "formulaReason": "This problem is classified as Carnot Refrigeration COP. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "T_H=55+460=515°R; T_L=15+460=475°R.",
    "calculation": [
      "COP_R=475/(515−475)=475/40=11.875."
    ],
    "finalAnswer": "A — 11.875",
    "unitCheck": "The COP is dimensionless.",
    "concept": "Ideal Carnot COP depends on absolute temperatures of the hot and cold reservoirs.",
    "shortcutFormula": "COP_R=\\frac{T_L}{T_H-T_L}",
    "shortcut": "Convert °F to °R and use T_L/(T_H−T_L).",
    "commonMistakes": [
      "Use absolute temperatures, not Fahrenheit values directly."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 348; original PDF page 98; extracted PDF page 76",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 98,
    "sourceExtractedPdfPage": 76,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=76",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Ty COP = —— Tz -T, where: T, = 15+ 460 = 475°R T, =55 + 460 = 515°R then; cop = 8 _ = 11.875 515-475",
    "sourceChoicesOriginalOrder": [
      "A. 11.875",
      "B. 12.875",
      "C. 10.875",
      "D. 13.875"
    ],
    "id": "bluebook-aircon-348",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=76"
  },
  {
    "sourceProblemNumber": 349,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Sensible Cooling Capacity from CFM",
    "difficulty": "Intermediate",
    "prompt": "How much refrigeration capacity is required to cool 2000 cfm of air from 85°F to 70°F?",
    "options": [
      {
        "value": "A",
        "text": "2.7 TOR"
      },
      {
        "value": "B",
        "text": "3.7 TOR"
      },
      {
        "value": "C",
        "text": "1.7 TOR"
      },
      {
        "value": "D",
        "text": "4.7 TOR"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Air flow =2000 cfm",
      "Air temperature =85°F to 70°F"
    ],
    "formula": "\\dot Q=\\dot m c_p\\Delta T;\\quad TR=\\dot Q/12000\\text{ Btu/hr}",
    "formulaReason": "This problem is classified as Sensible Cooling Capacity from CFM. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "ṁ≈2000(0.075)(60)=9000 lb/hr.",
    "calculation": [
      "ṁ_air≈9000 lb/hr.",
      "Q̇=9000(0.24)(85−70)=32,400 Btu/hr.",
      "TR=32,400/12,000=2.7 TOR."
    ],
    "finalAnswer": "A — 2.7 TOR",
    "unitCheck": "Btu/hr divided by 12,000 Btu/hr per ton gives tons of refrigeration.",
    "concept": "Sensible cooling load of an air stream depends on mass flow, specific heat, and temperature reduction.",
    "shortcutFormula": "\\dot Q=\\dot m c_p\\Delta T;\\quad TR=\\dot Q/12000\\text{ Btu/hr}",
    "shortcut": "Use 1 cfm≈0.075 lb/min for standard air, then multiply by 60 to get lb/hr.",
    "commonMistakes": [
      "Use inlet minus outlet temperature for a cooling process.",
      "Keep cfm-to-lb/hr conversion consistent."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 349; original PDF page 98; extracted PDF page 77",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 98,
    "sourceExtractedPdfPage": 77,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=77",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Q = mC, At where: C, = 0.24 Btu/Ib-°R : ft? Ib min tn = 2000 (0.0752) (60) = 9000 Ib/hr then; “ Btu 1TOR Q = 9000(0.24)(85 — 70) = (32,400 5) (225s) = 2.7 TOR",
    "sourceChoicesOriginalOrder": [
      "A. 2.7 TOR",
      "B. 3.7 TOR",
      "C. 1.7 TOR",
      "D. 4.7 TOR"
    ],
    "id": "bluebook-aircon-349",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=77"
  },
  {
    "sourceProblemNumber": 350,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Cooling-Coil Face Area",
    "difficulty": "Intermediate",
    "prompt": "Determine the coil face area required to maintain a face velocity 400 ft/min if the air flow rate over the coil is 2100 ft3/min.",
    "options": [
      {
        "value": "A",
        "text": "3.25 ft2"
      },
      {
        "value": "B",
        "text": "4.25 ft2"
      },
      {
        "value": "C",
        "text": "5.25 ft2"
      },
      {
        "value": "D",
        "text": "6.25 ft2"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Air flow =2100 ft³/min",
      "Target face velocity =400 ft/min"
    ],
    "formula": "A=\\dot V/V_{face}",
    "formulaReason": "This problem is classified as Cooling-Coil Face Area. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "A=2100/400.",
    "calculation": [
      "Face area = volumetric flow rate / face velocity.",
      "A=2100/400=5.25 ft²."
    ],
    "finalAnswer": "C — 5.25 ft²",
    "unitCheck": "ft³/min ÷ ft/min = ft².",
    "concept": "Face velocity is volumetric flow divided by the frontal flow area.",
    "shortcutFormula": "A=\\dot V/V_{face}",
    "shortcut": "Divide CFM by face velocity in ft/min to obtain square feet.",
    "commonMistakes": [
      "Use the flow through the coil face, not air mass flow.",
      "Keep volume flow and velocity in matching time units."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 350; original PDF page 98; extracted PDF page 78",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 98,
    "sourceExtractedPdfPage": 78,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=78",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: + Air quanti Velocity = “7 aantly Face area 3 ft 2100 400— = —_ain. min Face area Face area = 5.25 ft?",
    "sourceChoicesOriginalOrder": [
      "A. 3.25 ft2",
      "B. 4.25 ft2",
      "C. 5.25 ft2",
      "D. 6.25 ft2"
    ],
    "id": "bluebook-aircon-350",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=78"
  },
  {
    "sourceProblemNumber": 354,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Composite Cold-Storage Wall",
    "difficulty": "Intermediate",
    "prompt": "One insulated wall of a cold-storage compartment is 8 m long by 2.5 m high and consists of an outer steel plate 18 mm thick. An inner wood wall is 22.5 m thick. The steel and wood are 90 mm apart to form a cavity which is filled with cork. If the temperature drop across the extreme faces of the composite wall is 15°C. Calculate the heat transfer per hour through the wall and the temperature drop across the thickness of the cork. Take the coefficients of thermal conductivity for steel, cork and wood as 45, 0.045, and 0.18 W/m-K respectively.",
    "options": [
      {
        "value": "A",
        "text": "408.24 kJ, 12.12°C"
      },
      {
        "value": "C",
        "text": "608.24 kJ, 13.12°C"
      },
      {
        "value": "B",
        "text": "708.24 kJ, 11.12°C"
      },
      {
        "value": "D",
        "text": "508.24 kJ, 14.12°C"
      }
    ],
    "answer": "D",
    "answerVerified": false,
    "given": [
      "Wall =8 m×2.5 m",
      "Steel thickness =18 mm; source transcription says wood =22.5 m (likely mm but requires checking)",
      "Cork cavity =90 mm",
      "Overall face temperature drop =15°C",
      "k: steel=45, cork=0.045, wood=0.18 W/(m·K)"
    ],
    "formula": "\\dot Q=\\frac{\\Delta T}{\\sum L_i/(k_iA)}",
    "formulaReason": "This problem is classified as Composite Cold-Storage Wall. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "For layers in series, total thermal resistance is Σ[L/(kA)] and Q̇=ΔT/R_total.",
    "calculation": [
      "The correct method is to calculate the resistance of steel, cork, and wood in series.",
      "If the wood thickness is 22.5 mm, an independent calculation gives approximately 508 kJ/hr and a cork drop near 14.1°C (choice D).",
      "The prompt transcription’s “22.5 m” thickness is implausible and must be verified before scoring."
    ],
    "finalAnswer": "Likely D — 508.24 kJ/hr and 14.12°C if wood thickness is 22.5 mm (UNVERIFIED)",
    "unitCheck": "K/W total resistance times W gives K temperature drop; W×3600/1000 gives kJ/hr.",
    "concept": "For steady one-dimensional conduction through composite layers in series, each layer carries the same heat rate and temperature drops divide in proportion to thermal resistance.",
    "shortcutFormula": "\\dot Q=\\frac{\\Delta T}{\\sum L_i/(k_iA)}",
    "shortcut": "Compute each layer resistance L/(kA), add the resistances, and use the cork resistance to find its temperature drop.",
    "commonMistakes": [
      "Do not add conductivities directly; thermal resistances add.",
      "Verify whether the source says 22.5 mm or 22.5 m."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 354; original PDF page 100; extracted PDF page 79",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 100,
    "sourceExtractedPdfPage": 79,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=79",
    "sourceAnswerStatus": "Question thickness unit appears incorrect or ambiguous; not scoreable until source review.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: AAt Qa where: — Xi 4 Xen y Kaa 0.018 | 0.09 | 0.0225 _ Rr = kip + Kyg + kag 45) 0045 + 0.18 2.125 then: Q = BGSIGD = 141.176 Wor]/s= 508.24 kj/hr thus; the heat transfer per hour is 508.24kJ Solving for the temperature drop across the Cork: AAt _ 20(At) Q = eB = 0 ko3 0.045, At= 14.12°C",
    "sourceChoicesOriginalOrder": [
      "A. 408.24 kJ, 12.12°C",
      "C. 608.24 kJ, 13.12°C",
      "B. 708.24 kJ, 11.12°C",
      "D. 508.24 kJ, 14.12°C"
    ],
    "id": "bluebook-aircon-354",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=79"
  },
  {
    "sourceProblemNumber": 356,
    "boardCategory": "PIPE",
    "subject": "Cold Storage & Product Cooling",
    "category": "Cold-Storage Insulation Heat Leak",
    "difficulty": "Intermediate",
    "prompt": "A cold storage compartment is 4.5 m long by 4 m wide by 2.5 m high. The four walls, ceiling and floor are covered to a thickness of 150 mm with insulating material which has a coefficient of thermal conductivity of 5.8x10-2W/m-K. Calculate the quantity of heat leaking through the insulation per hour when the outside and inside face temperature of the material is 15°C and -5°C respectively.",
    "options": [
      {
        "value": "A",
        "text": "2185.44 kJ"
      },
      {
        "value": "B",
        "text": "2285.44 kJ"
      },
      {
        "value": "C",
        "text": "3185.44 kJ"
      },
      {
        "value": "D",
        "text": "4185.44 kJ"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "Room =4.5 m×4 m×2.5 m",
      "Insulation thickness =0.15 m",
      "k=5.8×10⁻² W/(m·K)",
      "Face temperatures=15°C and −5°C"
    ],
    "formula": "\\dot Q=kA\\Delta T/L",
    "formulaReason": "This problem is classified as Cold-Storage Insulation Heat Leak. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "A=2[4.5(2.5)+4(2.5)+4.5(4)]=78.5 m²; ΔT=20 K.",
    "calculation": [
      "Q̇=kAΔT/L=0.058(78.5)(20)/0.15≈607.1 W.",
      "Per hour, Q≈0.6071 kJ/s×3600≈2185.5 kJ/hr."
    ],
    "finalAnswer": "A — 2185.44 kJ/hr",
    "unitCheck": "W×3600 s/hr÷1000 = kJ/hr.",
    "concept": "Steady conduction heat leak through insulation is proportional to conductivity, area, and temperature difference, and inversely proportional to thickness.",
    "shortcutFormula": "\\dot Q=kA\\Delta T/L",
    "shortcut": "Calculate all six face areas, then use Q̇=kAΔT/L.",
    "commonMistakes": [
      "Include the floor and ceiling as well as four walls.",
      "Use the insulation thickness in meters."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 356; original PDF page 101; extracted PDF page 80",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 101,
    "sourceExtractedPdfPage": 80,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=80",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: where: A= 2[4.5(2.5) + 4(2.5) + 4.5(4)] = 78.50 m2 then; . (5.8x10 2) (78.50) (15+5) J Q= oa 607.07 W ors= 2185.44 kJ/hr",
    "sourceChoicesOriginalOrder": [
      "A. 2185.44 kJ",
      "B. 2285.44 kJ",
      "C. 3185.44 kJ",
      "D. 4185.44 kJ"
    ],
    "id": "bluebook-aircon-356",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=80"
  },
  {
    "sourceProblemNumber": 366,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Reversed Carnot Heat Pump & Lake Temperature",
    "difficulty": "Intermediate",
    "prompt": "A reverse Carnot cycle requires 3 Hp and extracts energy from a lake to heat a house. If the house is kept at 70°F and requires 2000 Btu per minute, what is the temperature of the lake?",
    "options": [
      {
        "value": "A",
        "text": "35.29°F"
      },
      {
        "value": "B",
        "text": "36.29°F"
      },
      {
        "value": "C",
        "text": "39.29°F"
      },
      {
        "value": "D",
        "text": "40.29°F"
      }
    ],
    "answer": "B",
    "answerVerified": true,
    "given": [
      "House temperature =70°F",
      "Heating requirement =2000 Btu/min",
      "Input power =3 hp"
    ],
    "formula": "COP_H=\\frac{T_H}{T_H-T_L}=\\dot Q_H/W",
    "formulaReason": "This problem is classified as Reversed Carnot Heat Pump & Lake Temperature. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "W≈3(42.42)=127.3 Btu/min; COP_H=2000/127.3≈15.72.",
    "calculation": [
      "COP_H=Q̇_H/W≈2000/127.3≈15.72.",
      "T_H=70+460=530°R.",
      "For a Carnot heat pump, T_L=T_H(1−1/COP_H)≈496.3°R≈36.3°F."
    ],
    "finalAnswer": "B — 36.29°F",
    "unitCheck": "Convert 3 hp to Btu/min and use °R for temperatures.",
    "concept": "A reverse Carnot heat pump delivers heat to the warm reservoir; its heating COP is Q_H/W and depends on the absolute hot and cold temperatures.",
    "shortcutFormula": "COP_H=\\frac{T_H}{T_H-T_L}=\\dot Q_H/W",
    "shortcut": "Compute heating COP from Q_H/W, then rearrange COP_H=T_H/(T_H−T_L) for T_L.",
    "commonMistakes": [
      "Use the heating COP, not the refrigerator COP.",
      "Use absolute temperature for the Carnot relation."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 366; original PDF page 105; extracted PDF page 81",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 105,
    "sourceExtractedPdfPage": 81,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=81",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Qa = T,(S, — Sy) Solving for Q,: 3 2 W= Qe — Qa where: - W = 3 Hp= 127.20 Btu/min g Qe = 2000 Btu/min g a then; & 4 1 127.2 = 2000 —-Q, Entropy, 5 Q, = 1872.80 Btu/min Solving for S, — S,: Qa = T,(S, —S;) = T,(S, — S,) 2000 = (70 + 460)(S, — S,) S, — S4 = 3.77 from; Qa = T1(S; — $4) 1872.80 = T, (3.77) T, = 496.29°R = 36.29°F",
    "sourceChoicesOriginalOrder": [
      "A. 35.29°F",
      "B. 36.29°F",
      "C. 39.29°F",
      "D. 40.29°F"
    ],
    "id": "bluebook-aircon-366",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=81"
  },
  {
    "sourceProblemNumber": 439,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Moist-Air Enthalpy",
    "difficulty": "Intermediate",
    "prompt": "A room contains air at 20°C and 96 kPa at a relative humidity of 75%. Determine the enthalpy of moist air. where: (Psat @ 20°C = 2.339 kPa) (hg @ 20°C = 2538.1 kJ/kgda) Given: Unsaturated air (0% < Ø <100%) td = 20°C Pt = 96 kPa Ø = 75%",
    "options": [
      {
        "value": "A",
        "text": "45.919 kJ/kgda"
      },
      {
        "value": "B",
        "text": "45.515 kJ/kgda"
      },
      {
        "value": "C",
        "text": "49.515 kJ/kgda"
      },
      {
        "value": "D",
        "text": "41.815 kJ/kgda"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "T=20°C; P=96 kPa; RH=75%",
      "Psat at 20°C=2.339 kPa",
      "hg at 20°C=2538.1 kJ/kg"
    ],
    "formula": "w=0.622\\frac{p_v}{P-p_v};\\quad h=1.005T+w(2500+1.88T)",
    "formulaReason": "This problem is classified as Moist-Air Enthalpy. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "p_v=0.75(2.339)=1.754 kPa; w=0.622(1.754)/(96−1.754).",
    "calculation": [
      "Humidity ratio w≈0.01158 kg/kg dry air.",
      "h≈1.005(20)+w(2500+1.88(20))≈49.5 kJ/kg dry air.",
      "The closest listed/source result is option C."
    ],
    "finalAnswer": "C — about 49.515 kJ/kg dry air",
    "unitCheck": "h is kJ per kg dry air; w is kg vapor/kg dry air.",
    "concept": "Moist-air enthalpy includes dry-air sensible enthalpy plus water-vapor sensible and latent contributions; humidity ratio is based on vapor partial pressure.",
    "shortcutFormula": "w=0.622\\frac{p_v}{P-p_v};\\quad h=1.005T+w(2500+1.88T)",
    "shortcut": "Find vapor pressure from RH×saturation pressure, then humidity ratio, then enthalpy.",
    "commonMistakes": [
      "Use partial pressure of vapor, not total pressure, in the humidity-ratio equation.",
      "Keep RH as 0.75, not 75."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 439; original PDF page 134; extracted PDF page 82",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 134,
    "sourceExtractedPdfPage": 82,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=82",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: Pa = Prat @ 20¢ = 2.339 kPa P, = OP; = 0.75(2.339) = 1.7543 kPa P, = P, +P, P, = 96 — 1.7543 = 94.2457 W = 2 = 0.622 (F) = 0.622 (SE) = 0.01158 kgwv/kBaa h= 1.0062t, + W(h, or) = 1.0062(20) + 0.01158(2538.1) = 49.515 kJ/kg,,",
    "sourceChoicesOriginalOrder": [
      "A. 45.919 kJ/kgda",
      "B. 45.515 kJ/kgda",
      "C. 49.515 kJ/kgda",
      "D. 41.815 kJ/kgda"
    ],
    "id": "bluebook-aircon-439",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=82"
  },
  {
    "sourceProblemNumber": 442,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Water Vapor Mass in a Room",
    "difficulty": "Intermediate",
    "prompt": "Determine the mass of water vapor contained in a 150 m3 room at 100 kPa, 23°C and 40% relative humidity. From Steam Tables: Psat @ 23°C = 2.810 kPa.",
    "options": [
      {
        "value": "A",
        "text": "1.6342 kg"
      },
      {
        "value": "B",
        "text": "1.9342 kg"
      },
      {
        "value": "C",
        "text": "1.2342 kg"
      },
      {
        "value": "D",
        "text": "2.2342 kg"
      }
    ],
    "answer": "C",
    "answerVerified": true,
    "given": [
      "Room volume =150 m³; P=100 kPa",
      "T=23°C; RH=40%",
      "Psat at 23°C=2.810 kPa"
    ],
    "formula": "m_v=\\frac{p_vV}{R_vT};\\quad p_v=\\phi p_{sat}",
    "formulaReason": "This problem is classified as Water Vapor Mass in a Room. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "p_v=0.40(2.810)=1.124 kPa; T=296 K.",
    "calculation": [
      "m_v=p_vV/(R_vT)=1.124(150)/[0.4615(296)]≈1.234 kg."
    ],
    "finalAnswer": "C — 1.2342 kg",
    "unitCheck": "kPa·m³ and kJ/(kg·K) are consistent; result is kg.",
    "concept": "Water vapor obeys the ideal-gas relation using its partial pressure, not the total room pressure.",
    "shortcutFormula": "m_v=\\frac{p_vV}{R_vT};\\quad p_v=\\phi p_{sat}",
    "shortcut": "Calculate vapor partial pressure from RH, then use the water-vapor gas constant in PV=mRT.",
    "commonMistakes": [
      "Do not use total atmospheric pressure as vapor pressure.",
      "Convert 23°C to kelvin."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 442; original PDF page 135; extracted PDF page 83",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 135,
    "sourceExtractedPdfPage": 83,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=83",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: P, = OP, = 04 x 2.810 = 1.124 kPa PVs = M,R,T, _ P,V, _ 1.124(150) _ M, = R,T, 0.4615(296) 1.2342 kg",
    "sourceChoicesOriginalOrder": [
      "A. 1.6342 kg",
      "B. 1.9342 kg",
      "C. 1.2342 kg",
      "D. 2.2342 kg"
    ],
    "id": "bluebook-aircon-442",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=83"
  },
  {
    "sourceProblemNumber": 451,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Dry-Air Specific Volume",
    "difficulty": "Intermediate",
    "prompt": "Specific volume is the number of cubic meters of mixture per kilogram of dry air. If dry air has these following properties: Ra = 287 J/kg-K, T = 303 K, Pa = 99.604 kPa. Solve for the specific volume.",
    "options": [
      {
        "value": "A",
        "text": "0.873 m3/kg"
      },
      {
        "value": "B",
        "text": "0.853 m3/kg"
      },
      {
        "value": "C",
        "text": "0.953 m3/kg"
      },
      {
        "value": "D",
        "text": "0.783 m3/kg"
      }
    ],
    "answer": "A",
    "answerVerified": true,
    "given": [
      "R_a=287 J/(kg·K)",
      "T=303 K",
      "P_a=99.604 kPa"
    ],
    "formula": "v=R_aT/P_a",
    "formulaReason": "This problem is classified as Dry-Air Specific Volume. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "v=287(303)/(99.604×1000).",
    "calculation": [
      "v=R_aT/P_a=287(303)/99,604≈0.873 m³/kg dry air."
    ],
    "finalAnswer": "A — 0.873 m³/kg",
    "unitCheck": "J/kg divided by Pa = m³/kg.",
    "concept": "For ideal dry air, specific volume is gas constant times absolute temperature divided by absolute pressure.",
    "shortcutFormula": "v=R_aT/P_a",
    "shortcut": "Use pressure in Pa when R is in J/(kg·K).",
    "commonMistakes": [
      "Convert kPa to Pa if using R in J/(kg·K)."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 451; original PDF page 137; extracted PDF page 84",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 137,
    "sourceExtractedPdfPage": 84,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=84",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: specific volume = 22%? = 228709) _ 9 373 m3/kg Pa 99.604",
    "sourceChoicesOriginalOrder": [
      "A. 0.873 m3/kg",
      "B. 0.853 m3/kg",
      "C. 0.953 m3/kg",
      "D. 0.783 m3/kg"
    ],
    "id": "bluebook-aircon-451",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=84"
  },
  {
    "sourceProblemNumber": 452,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Reversed Carnot Refrigerator COP",
    "difficulty": "Intermediate",
    "prompt": "A refrigerating system operates on the reversed Carnot Cycle. The higher temperature of the refrigerant in the system is 120°F and the lower is 10°F. The capacity is 20 tons. Neglect losses. Determine the coefficient of performance.",
    "options": [
      {
        "value": "A",
        "text": "2.732"
      },
      {
        "value": "B",
        "text": "5.373"
      },
      {
        "value": "C",
        "text": "7.372"
      },
      {
        "value": "D",
        "text": "4.273"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "T_H=120°F; T_L=10°F",
      "Capacity =20 TR (not needed for COP)"
    ],
    "formula": "COP_R=\\frac{T_L}{T_H-T_L}",
    "formulaReason": "This problem is classified as Reversed Carnot Refrigerator COP. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "T_H=120+460=580°R; T_L=10+460=470°R.",
    "calculation": [
      "COP_R=470/(580−470)=470/110≈4.273."
    ],
    "finalAnswer": "D — COP ≈4.273",
    "unitCheck": "COP is dimensionless.",
    "concept": "Carnot COP depends only on the absolute temperatures, not on the refrigerator size.",
    "shortcutFormula": "COP_R=\\frac{T_L}{T_H-T_L}",
    "shortcut": "Convert both temperatures to °R, subtract, and divide T_L by the difference.",
    "commonMistakes": [
      "Do not use the 20 TR capacity when only COP is requested.",
      "Use absolute temperatures."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 452; original PDF page 137; extracted PDF page 85",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 137,
    "sourceExtractedPdfPage": 85,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=85",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: cop =—— =—_20+400_ 44 973 T,-T, (120 +460) +(104 460)",
    "sourceChoicesOriginalOrder": [
      "A. 2.732",
      "B. 5.373",
      "C. 7.372",
      "D. 4.273"
    ],
    "id": "bluebook-aircon-452",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=85"
  },
  {
    "sourceProblemNumber": 460,
    "boardCategory": "PIPE",
    "subject": "Air Conditioning",
    "category": "Humidity Ratio from Relative Humidity",
    "difficulty": "Intermediate",
    "prompt": "Compute the humidity ratio of air at 70% relative humidity and 25°C when the barometric pressure is 101.325 kPa. From the steam tables: Psat @ 34 °C = 3.169 kPa.",
    "options": [
      {
        "value": "A",
        "text": "0.014 kgwater vapor/kgdry air"
      },
      {
        "value": "C",
        "text": "1.4 kgwater vapor/kgdry air"
      },
      {
        "value": "B",
        "text": "0.14 kgwater vapor/kgdry air"
      },
      {
        "value": "D",
        "text": "0.0014 kgwater vapor/kgdry air"
      }
    ],
    "answer": "A",
    "answerVerified": false,
    "given": [
      "Relative humidity =70%",
      "Dry-bulb temperature =25°C",
      "Barometric pressure =101.325 kPa",
      "Printed Psat value =3.169 kPa, but source labels it “at 34°C”"
    ],
    "formula": "w=0.622\\frac{\\phi p_{sat}}{P-\\phi p_{sat}}",
    "formulaReason": "This problem is classified as Humidity Ratio from Relative Humidity. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "Using the supplied numerical Psat value: p_v=0.70(3.169)=2.218 kPa.",
    "calculation": [
      "w=0.622(2.218)/(101.325−2.218)≈0.0139 kg/kg dry air.",
      "This rounds to 0.014 (option A).",
      "The value 3.169 kPa corresponds to the stated 25°C data, but the transcribed source labels it 34°C; verify source label before scoring."
    ],
    "finalAnswer": "A — 0.014 kg vapor/kg dry air (UNVERIFIED source temperature label)",
    "unitCheck": "The ratio is kg vapor/kg dry air.",
    "concept": "Humidity ratio is the ratio of water-vapor mass to dry-air mass, derived from vapor partial pressure and total pressure.",
    "shortcutFormula": "w=0.622\\frac{\\phi p_{sat}}{P-\\phi p_{sat}}",
    "shortcut": "Calculate p_v=RH×p_sat, then substitute p_v into the humidity-ratio relation.",
    "commonMistakes": [
      "Use RH as a fraction.",
      "Check that the saturation-pressure temperature matches the dry-bulb temperature."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 460; original PDF page 140; extracted PDF page 86",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 140,
    "sourceExtractedPdfPage": 86,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=86",
    "sourceAnswerStatus": "Numeric saturation pressure fits 25°C, but extracted table-temperature label says 34°C.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: P, = saturation pressure at 34°C = 3.169 kPa P, = OP, = 0.70(3.169) = 2.2183 kPa 2.2183 W = 0.622 (=) = 0.014 K8water vapor /K8 ary air",
    "sourceChoicesOriginalOrder": [
      "A. 0.014 kgwater vapor/kgdry air",
      "C. 1.4 kgwater vapor/kgdry air",
      "B. 0.14 kgwater vapor/kgdry air",
      "D. 0.0014 kgwater vapor/kgdry air"
    ],
    "id": "bluebook-aircon-460",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=86"
  },
  {
    "sourceProblemNumber": 496,
    "boardCategory": "PIPE",
    "subject": "Refrigeration",
    "category": "Ton of Refrigeration Definition",
    "difficulty": "Intermediate",
    "prompt": "A refrigerating machine that is classified as a one-ton machine has the capacity to produce a cooling effect of?",
    "options": [
      {
        "value": "A",
        "text": "3.516 kW"
      },
      {
        "value": "B",
        "text": "12,000 Btu/hr"
      },
      {
        "value": "C",
        "text": "211 kJ/min"
      },
      {
        "value": "D",
        "text": "All of the above"
      }
    ],
    "answer": "D",
    "answerVerified": true,
    "given": [
      "One ton of refrigeration"
    ],
    "formula": "1\\ TR\\approx3.516\\ kW=12{,}000\\ Btu/hr\\approx211\\ kJ/min",
    "formulaReason": "This problem is classified as Ton of Refrigeration Definition. Use the governing relation stated in the worked solution; the equation and assumptions are listed separately so you can recognize why it applies.",
    "derivation": "Use the definition of the listed relation and rearrange algebraically for the requested unknown. Where the source relies on a property table or code-specific empirical relation, the formula is a correlation rather than a first-principles derivation.",
    "substitution": "1 TR ≈3.516 kW; 3.516 kJ/s×60≈211 kJ/min; 1 TR is defined as 12,000 Btu/hr.",
    "calculation": [
      "1 TR≈3.516 kW.",
      "3.516 kJ/s×60 s/min≈210.96 kJ/min.",
      "The traditional refrigeration ton is 12,000 Btu/hr; all listed equivalences agree within rounding."
    ],
    "finalAnswer": "D — All of the above",
    "unitCheck": "All values are cooling-rate units.",
    "concept": "A ton of refrigeration is a rate of heat removal, not a mass or a power input.",
    "shortcutFormula": "1\\ TR\\approx3.516\\ kW=12{,}000\\ Btu/hr\\approx211\\ kJ/min",
    "shortcut": "Memorize 1 TR≈3.516 kW≈12,000 Btu/hr≈211 kJ/min.",
    "commonMistakes": [
      "Do not confuse TR with compressor hp or energy consumed over time."
    ],
    "source": "Blue-Book-With-Solution-VIP.pdf — Problem 496; original PDF page 147; extracted PDF page 87",
    "sourceOrganization": "Blue-Book-With-Solution-VIP.pdf (extracted and organized in Aircon_Refrigeration_Problems_Extracted.pdf)",
    "sourcePage": 147,
    "sourceExtractedPdfPage": 87,
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=87",
    "sourceAnswerStatus": "Answer choice follows the reproduced printed solution; not all property-table inputs have been independently re-created.",
    "sourceSolutionStatus": "Structured teaching steps transcribed from the extracted PDF solution image where legible; mathematical OCR retained separately for traceability.",
    "independentSolutionStatus": "Explanatory normalization is separated from the source transcription; review flagged items against the scanned page.",
    "sourceSolutionTranscript": "Solution: 1 TOR = 3.516 kW = 12,000 = an -. All of the above",
    "sourceChoicesOriginalOrder": [
      "A. 3.516 kW",
      "B. 12,000 Btu/hr",
      "C. 211 kJ/min",
      "D. All of the above"
    ],
    "id": "bluebook-aircon-496",
    "builtIn": true,
    "sourceOriginalReference": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=87"
  }
];

const QUESTIONS_KEY = "engineeringReviewQuizCustomQuestionsV2CleanBank";
const LAST_QUESTION_KEY = "engineeringReviewQuizLastQuestionV1";
const PROGRESS_KEY = "engineeringReviewQuizProgressV5CleanBank";
const DAILY_ACTIVITY_KEY = "engineeringReviewQuizDailyActivityV2CleanBank";
const REVIEW_SCHEDULE_KEY = "engineeringReviewQuizSpacedReviewV1";
const MISTAKE_NOTEBOOK_KEY = "engineeringReviewQuizMistakeNotebookV1";
const EXAM_HISTORY_KEY = "engineeringReviewQuizExamHistoryV1";
const EXAM_HISTORY_LIMIT = 30;
const MISTAKE_CATEGORIES = [
  { value: "uncategorized", label: "Choose mistake type…" },
  { value: "formula", label: "Wrong formula or method" },
  { value: "units", label: "Unit conversion or units" },
  { value: "calculation", label: "Calculation or algebra" },
  { value: "concept", label: "Concept misunderstanding" },
  { value: "condition", label: "Missed condition or assumption" },
  { value: "reading", label: "Misread the question / careless error" },
  { value: "other", label: "Other" }
];
function makeMistakeSnapshot(q) {
  const asLines = value => Array.isArray(value) ? value.map(x => String(x ?? "")) : (value == null || value === "" ? [] : [String(value)]);
  return {
    id: String(q.id || ""), subject: String(q.subject || "Engineering"), category: String(q.category || "General"), boardCategory: String(q.boardCategory || ""), sourceOrganization: String(q.sourceOrganization || ""), sourceProblemNumber: Number(q.sourceProblemNumber || 0), sourcePage: Number(q.sourcePage || 0), sourceExtractedPdfPage: Number(q.sourceExtractedPdfPage || 0), sourceFile: String(q.sourceFile || ""), sourceOriginalReference: String(q.sourceOriginalReference || ""), sourceSolutionTranscript: String(q.sourceSolutionTranscript || ""),
    difficulty: String(q.difficulty || ""), prompt: String(q.prompt || ""), source: String(q.source || ""),
    options: Array.isArray(q.options) ? q.options.map(o => ({ value: String(o?.value || ""), text: String(o?.text || "") })) : [],
    answer: String(q.answer || ""), answerVerified: q.answerVerified !== false,
    given: asLines(q.given), formula: String(q.formula || ""), formulaReason: String(q.formulaReason || getFormulaReason(q)), derivation: String(q.derivation || getDerivationNote(q)), substitution: String(q.substitution || ""),
    calculation: asLines(q.calculation), finalAnswer: String(q.finalAnswer || ""), concept: String(q.concept || ""), unitCheck: String(q.unitCheck || ""),
    shortcutFormula: String(q.shortcutFormula || ""), shortcut: String(q.shortcut || ""), commonMistakes: asLines(q.commonMistakes).length ? asLines(q.commonMistakes) : getCommonExamTraps(q)
  };
}
function normalizeMistakeNotebook(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {};
  const normalized = {};
  for (const [key, item] of Object.entries(raw)) {
    if (!item || typeof item !== "object" || !item.snapshot || typeof item.snapshot.prompt !== "string") continue;
    const snap = item.snapshot;
    const snapshot = {
      id: String(snap.id || key), subject: String(snap.subject || "Engineering"), category: String(snap.category || "General"), boardCategory: String(snap.boardCategory || ""), sourceOrganization: String(snap.sourceOrganization || ""), sourceProblemNumber: Number(snap.sourceProblemNumber || 0), sourcePage: Number(snap.sourcePage || 0), sourceExtractedPdfPage: Number(snap.sourceExtractedPdfPage || 0), sourceFile: String(snap.sourceFile || ""), sourceOriginalReference: String(snap.sourceOriginalReference || ""), sourceSolutionTranscript: String(snap.sourceSolutionTranscript || ""),
      difficulty: String(snap.difficulty || ""), prompt: String(snap.prompt || ""), source: String(snap.source || ""),
      options: Array.isArray(snap.options) ? snap.options.map(o => ({ value: String(o?.value || ""), text: String(o?.text || "") })) : [],
      answer: String(snap.answer || ""), answerVerified: snap.answerVerified !== false,
      given: Array.isArray(snap.given) ? snap.given.map(String) : [], formula: String(snap.formula || ""), formulaReason: String(snap.formulaReason || getFormulaReason(snap)), derivation: String(snap.derivation || getDerivationNote(snap)),
      substitution: String(snap.substitution || ""), calculation: Array.isArray(snap.calculation) ? snap.calculation.map(String) : [],
      finalAnswer: String(snap.finalAnswer || ""), concept: String(snap.concept || ""), unitCheck: String(snap.unitCheck || ""),
      shortcutFormula: String(snap.shortcutFormula || ""), shortcut: String(snap.shortcut || ""), commonMistakes: Array.isArray(snap.commonMistakes) && snap.commonMistakes.length ? snap.commonMistakes.map(String) : getCommonExamTraps(snap)
    };
    const history = Array.isArray(item.history) ? item.history.filter(h => h && typeof h === "object").slice(-30).map(h => ({
      at: String(h.at || ""), selectedAnswer: String(h.selectedAnswer || ""), selectedText: String(h.selectedText || ""), source: String(h.source || "practice")
    })) : [];
    normalized[String(key)] = {
      questionId: String(item.questionId || key), snapshot,
      firstMissedAt: String(item.firstMissedAt || item.lastMissedAt || new Date().toISOString()),
      lastMissedAt: String(item.lastMissedAt || item.firstMissedAt || new Date().toISOString()),
      attemptCount: Math.max(1, Number(item.attemptCount) || history.length || 1),
      history, category: MISTAKE_CATEGORIES.some(c => c.value === item.category) ? item.category : "uncategorized",
      note: String(item.note || "").slice(0, 3000), status: item.status === "mastered" ? "mastered" : "open",
      masteredAt: item.status === "mastered" ? String(item.masteredAt || "") : ""
    };
  }
  return normalized;
}
function loadMistakeNotebook() {
  try { return normalizeMistakeNotebook(JSON.parse(localStorage.getItem(MISTAKE_NOTEBOOK_KEY) || "{}")); }
  catch { return {}; }
}
let mistakeNotebook = loadMistakeNotebook();
function normalizeExamHistory(raw) {
  if (!Array.isArray(raw)) return [];
  return raw.filter(item => item && typeof item === "object" && typeof item.id === "string" && typeof item.completedAt === "string")
    .map(item => ({
      id: String(item.id),
      completedAt: String(item.completedAt),
      timeLimitSeconds: Math.max(0, Number(item.timeLimitSeconds) || 0),
      timeUsedSeconds: Math.max(0, Number(item.timeUsedSeconds) || 0),
      timedOut: Boolean(item.timedOut),
      totalQuestions: Math.max(0, Number(item.totalQuestions) || 0),
      answered: Math.max(0, Number(item.answered) || 0),
      unanswered: Math.max(0, Number(item.unanswered) || 0),
      scoreable: Math.max(0, Number(item.scoreable) || 0),
      correct: Math.max(0, Number(item.correct) || 0),
      percent: item.percent !== null && item.percent !== undefined && item.percent !== "" && Number.isFinite(Number(item.percent)) ? Math.max(0, Math.min(100, Number(item.percent))) : null,
      breakdown: Array.isArray(item.breakdown) ? item.breakdown.slice(0, 150).map(row => ({
        main: String(row?.main || "Uncategorized").slice(0, 120),
        branch: String(row?.branch || "Uncategorized").slice(0, 120),
        totalQuestions: Math.max(0, Number(row?.totalQuestions) || 0),
        scoreable: Math.max(0, Number(row?.scoreable) || 0),
        correct: Math.max(0, Number(row?.correct) || 0),
        answered: Math.max(0, Number(row?.answered) || 0),
        unanswered: Math.max(0, Number(row?.unanswered) || 0)
      })) : [],
      questionResults: Array.isArray(item.questionResults) ? item.questionResults.slice(0, 100).map(row => ({
        questionId: String(row?.questionId || "").slice(0, 180),
        main: String(row?.main || "Uncategorized").slice(0, 120),
        branch: String(row?.branch || "Uncategorized").slice(0, 120),
        category: String(row?.category || "").slice(0, 180),
        prompt: String(row?.prompt || "").slice(0, 500),
        selectedAnswer: row?.selectedAnswer ? String(row.selectedAnswer).slice(0, 20) : "",
        selectedText: String(row?.selectedText || "").slice(0, 240),
        correctAnswer: row?.correctAnswer ? String(row.correctAnswer).slice(0, 20) : "",
        correctText: String(row?.correctText || "").slice(0, 240),
        scoreable: Boolean(row?.scoreable),
        correct: Boolean(row?.correct),
        answered: Boolean(row?.answered)
      })) : []
    }))
    .sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime())
    .slice(0, EXAM_HISTORY_LIMIT);
}
function loadExamHistory() {
  try { return normalizeExamHistory(JSON.parse(localStorage.getItem(EXAM_HISTORY_KEY) || "[]")); }
  catch { return []; }
}
let examHistory = loadExamHistory();
function saveExamHistory() {
  try { localStorage.setItem(EXAM_HISTORY_KEY, JSON.stringify(examHistory)); return true; }
  catch { return false; }
}
function saveMistakeNotebook() {
  try { localStorage.setItem(MISTAKE_NOTEBOOK_KEY, JSON.stringify(mistakeNotebook)); return true; }
  catch { return false; }
}
function loadReviewSchedule() {
  try { const saved = JSON.parse(localStorage.getItem(REVIEW_SCHEDULE_KEY) || "{}"); return saved && typeof saved === "object" && !Array.isArray(saved) ? saved : {}; }
  catch { return {}; }
}
let reviewSchedule = loadReviewSchedule();
function saveReviewSchedule() { try { localStorage.setItem(REVIEW_SCHEDULE_KEY, JSON.stringify(reviewSchedule)); } catch {} }
function scheduleQuestionReview(question, wasCorrect) {
  if (!question || question.answerVerified === false) return;
  const previous = reviewSchedule[question.id] || { intervalDays: 0, streak: 0, attempts: 0 };
  const streak = wasCorrect ? Math.max(0, Number(previous.streak) || 0) + 1 : 0;
  const intervalDays = wasCorrect ? (streak === 1 ? 3 : streak === 2 ? 7 : 14) : 1;
  const now = Date.now();
  reviewSchedule[question.id] = { dueAt: now + intervalDays * 86400000, lastReviewedAt: now, intervalDays, streak, attempts: (Number(previous.attempts) || 0) + 1, lastResult: Boolean(wasCorrect) };
  saveReviewSchedule();
  renderReviewTools();
}
function renderReviewTools() {
  const now = Date.now();
  const due = questions.filter(q => { const item = reviewSchedule[q.id]; return item && Number(item.dueAt) <= now; });
  const missed = questions.filter(q => progress.results && progress.results[q.id] === false);
  const dueCount = document.querySelector('#review-due-total');
  const missedCount = document.querySelector('#review-missed-total');
  const favoriteCount = document.querySelector('#review-favorite-total');
  const badge = document.querySelector('#review-due-count');
  if (dueCount) dueCount.textContent = String(due.length);
  if (missedCount) missedCount.textContent = String(missed.length);
  if (favoriteCount) favoriteCount.textContent = String(favoriteIds.length);
  if (badge) badge.textContent = `${due.length} due`;
  const dueButton = document.querySelector('#review-due-button');
  const missedButton = document.querySelector('#review-missed-button');
  const favoritesButton = document.querySelector('#review-favorites-button');
  if (dueButton) dueButton.disabled = due.length === 0;
  if (missedButton) missedButton.disabled = missed.length === 0;
  if (favoritesButton) favoritesButton.disabled = !questions.some(q => favoriteIds.includes(q.id));
  window.renderStudyDashboard?.();
}
let reviewQueue = null;
let reviewQueuePosition = 0;
function startReviewQueue(mode) {
  let selected = [];
  if (mode === 'due') selected = questions.filter(q => reviewSchedule[q.id] && Number(reviewSchedule[q.id].dueAt) <= Date.now());
  if (mode === 'missed') selected = questions.filter(q => progress.results && progress.results[q.id] === false);
  if (mode === 'favorites') selected = questions.filter(q => favoriteIds.includes(q.id));
  selected = selected.filter((q, index, all) => all.findIndex(other => other.id === q.id) === index);
  const status = document.querySelector('#review-status');
  if (!selected.length) { if (status) status.textContent = mode === 'due' ? 'Nothing is due yet. Answer some questions and come back when they are scheduled for review.' : mode === 'missed' ? 'No missed questions are recorded yet. Great—keep practicing!' : 'No favorites saved yet. Use the star beside a question to bookmark it.'; return; }
  reviewQueue = selected.map(q => q.id); reviewQueuePosition = 0;
  currentIndex = questions.findIndex(q => q.id === reviewQueue[0]);
  document.querySelector('.nav-button[data-view="practice"]')?.click();
  renderQuestion(); renderLibrary();
  if (status) status.textContent = `${selected.length} question(s) loaded into your ${mode === 'due' ? 'due review' : mode === 'missed' ? 'missed-question retry' : 'favorites'} session. Use Next question to continue through this session.`;
}
document.querySelector('#review-due-button')?.addEventListener('click', () => startReviewQueue('due'));
document.querySelector('#review-missed-button')?.addEventListener('click', () => startReviewQueue('missed'));
document.querySelector('#review-favorites-button')?.addEventListener('click', () => startReviewQueue('favorites'));
function recordDailyQuestionActivity(count = 1) {
  try {
    const now = new Date();
    const today = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}-${String(now.getDate()).padStart(2,"0")}`;
    const saved = JSON.parse(localStorage.getItem(DAILY_ACTIVITY_KEY) || "null");
    const activity = saved && saved.date === today ? saved : { date: today, count: 0 };
    activity.count = Math.max(0, Number(activity.count) || 0) + count;
    localStorage.setItem(DAILY_ACTIVITY_KEY, JSON.stringify(activity));
    window.renderStudyDashboard?.();
  } catch {}
}
let questions = loadQuestions();
function findSavedQuestionIndex() {
  try {
    const savedId = localStorage.getItem(LAST_QUESTION_KEY);
    const savedIndex = savedId ? questions.findIndex(q => q.id === savedId) : -1;
    if (savedIndex >= 0) return savedIndex;
    const savedProgress = JSON.parse(localStorage.getItem(PROGRESS_KEY) || "{}");
    const results = savedProgress && savedProgress.results && typeof savedProgress.results === "object" ? savedProgress.results : {};
    const unansweredIndex = questions.findIndex(q => !Object.prototype.hasOwnProperty.call(results, q.id));
    return unansweredIndex >= 0 ? unansweredIndex : 0;
  } catch { return 0; }
}
let currentIndex = findSavedQuestionIndex();
let initialQuestionRenderDone = false;
let selectedAnswer = "";
let submitted = false;
let progress = loadProgress();
let editingQuestionId = null;

const categoryEl = document.querySelector("#question-category");
const numberEl = document.querySelector("#question-number");
const difficultyEl = document.querySelector("#difficulty");
const questionEl = document.querySelector("#question-text");
const optionsEl = document.querySelector("#options");
const formEl = document.querySelector("#answer-form");
const checkButton = document.querySelector("#check-answer");
const nextButton = document.querySelector("#next-question");
const feedbackEl = document.querySelector("#feedback");
const progressFill = document.querySelector("#progress-fill");
const subjectFilter = document.querySelector("#subject-filter");
const librarySearch = document.querySelector("#library-search");
const difficultyFilter = document.querySelector("#difficulty-filter");
const favoritesOnly = document.querySelector("#favorites-only");
const librarySort = document.querySelector("#library-sort");
const answerStatusFilter = document.querySelector("#answer-status-filter");
const answerKeySummary = document.querySelector("#answer-key-summary");
const libraryResults = document.querySelector("#library-results");
const libraryList = document.querySelector("#library-list");
const FAVORITES_KEY = "engineeringReviewQuizFavoritesV2CleanBank";
function loadFavorites() { try { const v = JSON.parse(localStorage.getItem(FAVORITES_KEY)); return Array.isArray(v) ? v : []; } catch { return []; } }
let favoriteIds = loadFavorites();
function saveFavorites() { localStorage.setItem(FAVORITES_KEY, JSON.stringify(favoriteIds)); renderReviewTools?.(); }
function formatMistakeDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Unknown date" : date.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}
function mistakeAnswerText(snapshot, letter) {
  if (!letter) return "Not answered";
  const option = (snapshot.options || []).find(item => item.value === letter);
  return `${letter}${option?.text ? `. ${option.text}` : ""}`;
}
function appendMistakeDetail(parent, labelText, value) {
  const wrapper = document.createElement("div"); wrapper.className = "mistake-solution-field";
  const label = document.createElement("strong"); label.textContent = labelText;
  const text = document.createElement("p"); text.className = "math-line"; text.textContent = value || "Not provided in the saved solution.";
  wrapper.append(label, text); parent.append(wrapper);
}
function recordMistake(q, selected, source = "practice", persistNow = true) {
  if (!q || q.answerVerified === false || !selected || selected === q.answer) return false;
  const id = String(q.id);
  const now = new Date().toISOString();
  const snapshot = makeMistakeSnapshot(q);
  const entry = mistakeNotebook[id] || {
    questionId: id, snapshot, firstMissedAt: now, lastMissedAt: now, attemptCount: 0,
    history: [], category: "uncategorized", note: "", status: "open", masteredAt: ""
  };
  entry.snapshot = snapshot;
  entry.lastMissedAt = now;
  entry.attemptCount = (Number(entry.attemptCount) || 0) + 1;
  entry.status = "open";
  entry.masteredAt = "";
  const option = (q.options || []).find(item => item.value === selected);
  entry.history = [...(Array.isArray(entry.history) ? entry.history : []), {
    at: now, selectedAnswer: String(selected), selectedText: String(option?.text || ""), source
  }].slice(-30);
  mistakeNotebook[id] = entry;
  if (persistNow) {
    const saved = saveMistakeNotebook();
    renderMistakeNotebook();
    if (!saved) {
      const status = document.querySelector("#mistake-status");
      if (status) status.textContent = "The mistake was recorded in memory, but this browser could not save it. Check browser storage and try again.";
    }
  }
  return true;
}
function renderMistakeNotebook() {
  const list = document.querySelector("#mistake-list");
  if (!list) return;
  const all = Object.values(mistakeNotebook);
  const open = all.filter(item => item.status !== "mastered");
  const mastered = all.length - open.length;
  const attempts = all.reduce((sum, item) => sum + (Number(item.attemptCount) || 0), 0);
  const openCount = document.querySelector("#mistake-open-total");
  const masteredCount = document.querySelector("#mistake-mastered-total");
  const attemptCount = document.querySelector("#mistake-attempt-total");
  const navCount = document.querySelector("#mistake-nav-count");
  if (openCount) openCount.textContent = String(open.length);
  if (masteredCount) masteredCount.textContent = String(mastered);
  if (attemptCount) attemptCount.textContent = String(attempts);
  if (navCount) navCount.textContent = String(open.length);
  const clearMastered = document.querySelector("#mistake-clear-mastered");
  if (clearMastered) clearMastered.disabled = mastered === 0;
  const search = (document.querySelector("#mistake-search")?.value || "").trim().toLowerCase();
  const statusFilter = document.querySelector("#mistake-status-filter")?.value || "open";
  const visible = all.filter(entry => {
    if (statusFilter !== "all" && entry.status !== statusFilter) return false;
    const snap = entry.snapshot || {};
    const haystack = [snap.subject, snap.category, snap.prompt, entry.note, entry.category].join(" ").toLowerCase();
    return !search || haystack.includes(search);
  }).sort((a, b) => new Date(b.lastMissedAt).getTime() - new Date(a.lastMissedAt).getTime());
  list.replaceChildren();
  if (!all.length) {
    const empty = document.createElement("div"); empty.className = "mistake-empty";
    const title = document.createElement("h3"); title.textContent = "Your notebook is empty";
    const copy = document.createElement("p"); copy.className = "muted small"; copy.textContent = "When you miss a question with a verified answer key in Practice or an exam, it will be saved here with your selected answer and the worked solution.";
    empty.append(title, copy); list.append(empty); return;
  }
  if (!visible.length) {
    const empty = document.createElement("p"); empty.className = "muted small"; empty.textContent = "No notebook entries match these filters."; list.append(empty); return;
  }
  visible.forEach(entry => {
    const snap = entry.snapshot || {};
    const card = document.createElement("article"); card.className = "mistake-card"; card.dataset.mistakeId = entry.questionId;
    const headingRow = document.createElement("div"); headingRow.className = "mistake-card-heading";
    const heading = document.createElement("div");
    const eyebrow = document.createElement("p"); eyebrow.className = "eyebrow"; eyebrow.textContent = `${snap.subject || "Engineering"} · ${snap.category || "General"}`;
    const title = document.createElement("h3"); title.textContent = snap.prompt || "Saved question";
    heading.append(eyebrow, title);
    const badge = document.createElement("span"); badge.className = `mistake-status-pill ${entry.status === "mastered" ? "is-mastered" : "is-open"}`; badge.textContent = entry.status === "mastered" ? "Mastered" : "Needs review";
    headingRow.append(heading, badge);
    const meta = document.createElement("p"); meta.className = "muted tiny mistake-meta";
    meta.textContent = `Missed ${entry.attemptCount} time${entry.attemptCount === 1 ? "" : "s"} · First: ${formatMistakeDate(entry.firstMissedAt)} · Latest: ${formatMistakeDate(entry.lastMissedAt)}`;
    const answers = document.createElement("div"); answers.className = "mistake-answers";
    const yourBox = document.createElement("div"); yourBox.className = "mistake-answer mistake-answer-wrong";
    const yourLabel = document.createElement("span"); yourLabel.textContent = "Your latest answer";
    const yourValue = document.createElement("strong"); yourValue.textContent = mistakeAnswerText(snap, entry.history?.[entry.history.length - 1]?.selectedAnswer || "");
    yourBox.append(yourLabel, yourValue);
    const rightBox = document.createElement("div"); rightBox.className = "mistake-answer mistake-answer-right";
    const rightLabel = document.createElement("span"); rightLabel.textContent = "Correct answer";
    const rightValue = document.createElement("strong"); rightValue.textContent = mistakeAnswerText(snap, snap.answer);
    rightBox.append(rightLabel, rightValue); answers.append(yourBox, rightBox);
    const solutionDetails = document.createElement("details"); solutionDetails.className = "mistake-solution-details";
    const solutionSummary = document.createElement("summary"); solutionSummary.textContent = "View saved worked solution";
    const solutionGrid = document.createElement("div"); solutionGrid.className = "mistake-solution-grid";
    appendMistakeDetail(solutionGrid, "Given values", (snap.given || []).join("\n"));
    appendMistakeDetail(solutionGrid, "Formula", snap.formula);
    appendMistakeDetail(solutionGrid, "Why this formula applies", snap.formulaReason);
    appendMistakeDetail(solutionGrid, "Derivation / rearrangement", snap.derivation);
    appendMistakeDetail(solutionGrid, "Substitution", snap.substitution);
    appendMistakeDetail(solutionGrid, "Calculation", (snap.calculation || []).join("\n"));
    appendMistakeDetail(solutionGrid, "Final answer", snap.finalAnswer);
    appendMistakeDetail(solutionGrid, "Key concept", snap.concept);
    appendMistakeDetail(solutionGrid, "Unit check", snap.unitCheck);
    appendMistakeDetail(solutionGrid, "Exam shortcut", [snap.shortcutFormula, snap.shortcut].filter(Boolean).join("\n"));
    appendMistakeDetail(solutionGrid, "Common exam traps", (snap.commonMistakes || []).join("\n"));
    solutionDetails.append(solutionSummary, solutionGrid);
    const historyDetails = document.createElement("details"); historyDetails.className = "mistake-history-details";
    const historySummary = document.createElement("summary"); historySummary.textContent = `Incorrect-answer history (${entry.history?.length || 0} saved)`;
    const historyList = document.createElement("ul"); historyList.className = "mistake-history-list";
    (entry.history || []).slice().reverse().slice(0, 8).forEach(attempt => {
      const row = document.createElement("li");
      row.textContent = `${formatMistakeDate(attempt.at)} · ${attempt.source === "exam" ? "Exam" : "Practice"} · Chose ${mistakeAnswerText(snap, attempt.selectedAnswer)}`;
      historyList.append(row);
    });
    historyDetails.append(historySummary, historyList);
    const editor = document.createElement("div"); editor.className = "mistake-editor";
    const categoryLabel = document.createElement("label"); categoryLabel.className = "mistake-field-label"; categoryLabel.textContent = "What kind of mistake was it?";
    const categorySelect = document.createElement("select"); categorySelect.className = "filter-select mistake-category-select"; categorySelect.dataset.field = "category";
    MISTAKE_CATEGORIES.forEach(item => { const option = document.createElement("option"); option.value = item.value; option.textContent = item.label; option.selected = item.value === entry.category; categorySelect.append(option); });
    categoryLabel.append(categorySelect);
    const noteLabel = document.createElement("label"); noteLabel.className = "mistake-field-label"; noteLabel.textContent = "My note / how I will avoid this mistake";
    const note = document.createElement("textarea"); note.className = "mistake-note-input"; note.dataset.field = "note"; note.rows = 2; note.maxLength = 3000; note.placeholder = "Example: I used °C directly; convert to kelvin first."; note.value = entry.note || "";
    noteLabel.append(note); editor.append(categoryLabel, noteLabel);
    const actions = document.createElement("div"); actions.className = "mistake-card-actions";
    const saveButton = document.createElement("button"); saveButton.type = "button"; saveButton.className = "button button-secondary"; saveButton.dataset.action = "save"; saveButton.textContent = "Save note";
    const practiceButton = document.createElement("button"); practiceButton.type = "button"; practiceButton.className = "button button-primary"; practiceButton.dataset.action = "practice"; practiceButton.textContent = "Practice again";
    if (!questions.some(q => q.id === entry.questionId)) { practiceButton.disabled = true; practiceButton.title = "This question is no longer in the current question bank; its saved solution remains available."; }
    const statusButton = document.createElement("button"); statusButton.type = "button"; statusButton.className = "button button-secondary"; statusButton.dataset.action = "toggle-status"; statusButton.textContent = entry.status === "mastered" ? "Reopen for review" : "Mark mastered";
    const deleteButton = document.createElement("button"); deleteButton.type = "button"; deleteButton.className = "button button-quiet"; deleteButton.dataset.action = "delete"; deleteButton.textContent = "Remove entry";
    actions.append(saveButton, practiceButton, statusButton, deleteButton);
    card.append(headingRow, meta, answers, solutionDetails, historyDetails, editor, actions);
    if (snap.source) {
      const sourceText = document.createElement("p"); sourceText.className = "muted tiny mistake-source";
      if (/^https?:\/\//i.test(snap.source)) { const link = document.createElement("a"); link.href = snap.source; link.target = "_blank"; link.rel = "noopener noreferrer"; link.textContent = "Open original source"; sourceText.append(link); }
      else sourceText.textContent = `Source: ${snap.source}`;
      card.append(sourceText);
    }
    list.append(card);
  });
}
const mistakeListEl = document.querySelector("#mistake-list");
mistakeListEl?.addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const card = button.closest(".mistake-card");
  const id = card?.dataset.mistakeId;
  const entry = id ? mistakeNotebook[id] : null;
  if (!entry) return;
  if (button.dataset.action === "save") {
    entry.category = card.querySelector('[data-field="category"]')?.value || "uncategorized";
    entry.note = (card.querySelector('[data-field="note"]')?.value || "").slice(0, 3000);
    const saved = saveMistakeNotebook(); renderMistakeNotebook();
    const status = document.querySelector("#mistake-status");
    if (status) status.textContent = saved ? "Your mistake category and note have been saved on this device." : "The browser could not save your note. Check available browser storage.";
  } else if (button.dataset.action === "practice") {
    if (window.openEngineeringReviewQuestion(entry.questionId)) {
      document.querySelector('.nav-button[data-view="practice"]')?.click();
      document.querySelector(".quiz-panel")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  } else if (button.dataset.action === "toggle-status") {
    entry.status = entry.status === "mastered" ? "open" : "mastered";
    entry.masteredAt = entry.status === "mastered" ? new Date().toISOString() : "";
    const saved = saveMistakeNotebook(); renderMistakeNotebook();
    const status = document.querySelector("#mistake-status");
    if (status) status.textContent = saved ? (entry.status === "mastered" ? "Entry marked as mastered. It remains saved and can be reopened." : "Entry returned to your review list.") : "Could not save the status change in browser storage.";
  } else if (button.dataset.action === "delete") {
    if (!window.confirm("Remove this mistake entry, including its note and saved attempt history? The question bank itself will not be changed.")) return;
    delete mistakeNotebook[id]; const saved = saveMistakeNotebook(); renderMistakeNotebook();
    const status = document.querySelector("#mistake-status");
    if (status) status.textContent = saved ? "Mistake entry removed." : "The entry was removed in memory, but browser storage could not be updated.";
  }
});
document.querySelector("#mistake-search")?.addEventListener("input", renderMistakeNotebook);
document.querySelector("#mistake-status-filter")?.addEventListener("change", renderMistakeNotebook);
document.querySelector("#mistake-clear-mastered")?.addEventListener("click", () => {
  const ids = Object.entries(mistakeNotebook).filter(([, entry]) => entry.status === "mastered").map(([id]) => id);
  if (!ids.length) return;
  if (!window.confirm(`Remove ${ids.length} mastered mistake entr${ids.length === 1 ? "y" : "ies"}? Open mistakes will remain.`)) return;
  ids.forEach(id => delete mistakeNotebook[id]); const saved = saveMistakeNotebook(); renderMistakeNotebook();
  const status = document.querySelector("#mistake-status");
  if (status) status.textContent = saved ? `Removed ${ids.length} mastered entr${ids.length === 1 ? "y" : "ies"}.` : "Entries were removed in memory, but browser storage could not be updated.";
});
const dialog = document.querySelector("#add-question-dialog");
const addForm = document.querySelector("#add-question-form");
const formError = document.querySelector("#form-error");

function loadQuestions() {
  // Built-in source-verified records take precedence over exact-prompt copies in older local imports.
  // The saved custom storage is not modified merely by opening the app.
  const builtInPromptKeys = new Set(starterQuestions.map(q => String(q.prompt || '').normalize('NFKC').toLowerCase().replace(/\s+/g, ' ').trim()));
  try {
    const custom = JSON.parse(localStorage.getItem(QUESTIONS_KEY));
    if (Array.isArray(custom)) {
      const uniqueCustom = custom.filter(q => !builtInPromptKeys.has(String(q?.prompt || '').normalize('NFKC').toLowerCase().replace(/\s+/g, ' ').trim()));
      return [...starterQuestions, ...uniqueCustom];
    }
  } catch {}
  return [...starterQuestions];
}
function saveCustomQuestions() {
  const custom = questions.filter(q => !q.builtIn);
  localStorage.setItem(QUESTIONS_KEY, JSON.stringify(custom));
}
function loadProgress() {
  try { return JSON.parse(localStorage.getItem(PROGRESS_KEY)) || { answered: 0, correct: 0, results: {} }; }
  catch { return { answered: 0, correct: 0, results: {} }; }
}
function saveProgress() {
  localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
  updateStats();
  renderWeaknessTracker();
  window.renderStudyDashboard?.();
}
function updateStats() {
  // Legacy summary nodes were removed from the dashboard in v2.9.46.
  // Keep this updater safe for older or customized markup that still includes them.
  const answeredEl = document.querySelector("#stat-answered");
  const correctEl = document.querySelector("#stat-correct");
  const accuracyEl = document.querySelector("#stat-accuracy");
  if (answeredEl) answeredEl.textContent = progress.answered;
  if (correctEl) correctEl.textContent = progress.correct;
  if (accuracyEl) accuracyEl.textContent = progress.answered ? Math.round(progress.correct / progress.answered * 100) + "%" : "—";
}
function renderWeaknessTracker() {
  const summary=document.querySelector("#weakness-summary");
  const list=document.querySelector("#weakness-list");
  if(!summary || !list) return;
  summary.replaceChildren(); list.replaceChildren();
  const attempts=Object.entries(progress.results||{}).map(([id,result])=>({q:questions.find(item=>item.id===id),result}));
  const answered=attempts.filter(x=>x.q);
  const correct=answered.filter(x=>x.result===true).length;
  const accuracy=answered.length?Math.round(correct/answered.length*100):null;
  const metrics=[
    ["Questions answered",answered.length],
    ["Correct",correct],
    ["Overall accuracy",accuracy===null?"—":accuracy+"%"]
  ];
  metrics.forEach(([label,value])=>{const box=document.createElement("div");box.className="weakness-metric";const strong=document.createElement("strong");strong.textContent=value;const span=document.createElement("span");span.textContent=label;box.append(strong,span);summary.append(box);});
  const bySubject=new Map();
  answered.forEach(({q,result})=>{const topic=String(q.category||q.subject||"Other");if(!bySubject.has(topic))bySubject.set(topic,{total:0,correct:0,subject:q.subject});const item=bySubject.get(topic);item.total++;if(result)item.correct++;});
  const topics=[...bySubject.entries()].map(([topic,data])=>({topic,...data,accuracy:Math.round(data.correct/data.total*100)})).sort((a,b)=>a.accuracy-b.accuracy||b.total-a.total||a.topic.localeCompare(b.topic));
  if(!topics.length){const empty=document.createElement("div");empty.className="weakness-empty";empty.textContent="No answered questions yet. Complete a quiz question and check your answer to start building your topic report.";list.append(empty);}
  topics.forEach(item=>{const row=document.createElement("div");row.className="weakness-row"+(item.accuracy<60?" weak":"");const head=document.createElement("div");head.className="weakness-row-head";const name=document.createElement("strong");name.textContent=item.topic;const score=document.createElement("span");score.textContent=`${item.correct}/${item.total} correct · ${item.accuracy}%`;head.append(name,score);const track=document.createElement("div");track.className="weakness-track";track.setAttribute("role","progressbar");track.setAttribute("aria-valuemin","0");track.setAttribute("aria-valuemax","100");track.setAttribute("aria-valuenow",String(item.accuracy));track.setAttribute("aria-label",`${item.topic} accuracy`);const fill=document.createElement("div");fill.style.width=item.accuracy+"%";track.append(fill);row.append(head,track);list.append(row);});
  const status=document.querySelector("#weakness-status");
  if(status) status.textContent=topics.length?`Showing ${topics.length} topic(s), ordered from lowest to highest accuracy. Scores are based on your latest recorded result per question.`:"";
}
function addSolutionStep(container, number, label, content, isFinal = false) {
  const row = document.createElement("div");
  row.className = `solution-step${isFinal ? " final-step" : ""}`;
  const badge = document.createElement("div");
  badge.className = "step-number";
  badge.textContent = number;
  const body = document.createElement("div");
  const stepLabel = document.createElement("span");
  stepLabel.className = "step-label";
  stepLabel.textContent = label;
  const line = document.createElement("div");
  line.className = isFinal ? "final-answer" : "math-line";
  const parts = String(content ?? "").split(/\n+/).map(part => part.trim()).filter(Boolean);
  if (parts.length > 1) {
    parts.forEach((part, index) => {
      const item = document.createElement("div");
      item.className = "math-line-item";
      if (typeof window.renderMathInto === 'function') window.renderMathInto(item, part); else item.textContent = part;
      line.append(item);
    });
  } else {
    if (typeof window.renderMathInto === 'function') window.renderMathInto(line, content); else line.textContent = content;
  }
  body.append(stepLabel, line);
  row.append(badge, body);
  container.append(row);
}
function subjectTree(q) {
  // Board category, technical subject, and book/source are separate metadata.
  // The IPE Air Conditioning chapter is filed under PIPE > Air Conditioning;
  // the source remains the Industrial Plant Engineering Reviewer (IPE).
  if (String(q.boardCategory || "").toUpperCase() === "PIPE" || String(q.id || "").startsWith("ipe-aircon-")) {
    return {main: "PIPE", branch: String(q.subject || "Air Conditioning")};
  }
  const s = `${q.subject || ""} ${q.category || ""} ${q.prompt || ""} ${q.concept || ""}`.toLowerCase();
  const has = (...terms) => terms.some(t => s.includes(t));

  // Blue Book built-ins use the audited subject first, so unrelated words like “bearing” or “steam” cannot move a question into the wrong top-level tree.
  if (String(q.id || "").startsWith("bluebook-")) {
    const subject = String(q.subject || "");
    if (subject === "Thermodynamics") return {main:"Power Plant Engineering", branch:"Thermodynamics"};
    if (subject === "Fluid Mechanics") return {main:"Power Plant Engineering", branch:"Fluid Mechanics & Piping"};
    if (subject === "Heat Transfer") return {main:"Power Plant Engineering", branch:"Heat Transfer"};
    if (subject === "Refrigeration") return {main:"Power Plant Engineering", branch:"Refrigeration & Air Conditioning"};
    if (subject === "Engineering Materials") return {main:"Power Plant Engineering", branch:"Engineering Materials"};
    if (subject === "Chemical Engineering" || subject === "Drying Operations") return {main:"Power Plant Engineering", branch:"Drying & Chemical Processes"};
    if (subject === "Power Plant Engineering") {
      const branch = has("boiler", "steam generator", "steam turbine", "condenser", "feedwater", "superheater", "economizer", "throttling calorimeter") ? "Boilers & Steam Systems" : has("diesel", "combustion", "fuel", "coal", "heating value", "air-fuel", "exhaust gas", "hydroelectric", "hydro-electric", "net head", "plant output", "generator", "load factor", "auxiliar", "thermal efficiency", "heat rate") ? "Power Plant Systems & Operations" : "General Power Plant Engineering";
      return {main:"Power Plant Engineering", branch};
    }
    if (subject === "Engineering Fundamentals") {
      const branch = has("beam", "moment", "centroid", "truss", "ladder", "cable", "tension", "statics", "dynamics", "projectile", "velocity", "acceleration", "work-energy", "impulse", "stress", "strain", "friction", "torque", "shaft", "gearbox") ? "Applied Mechanics" : "General Engineering Fundamentals";
      return {main:"Power Plant Engineering", branch};
    }
  }

  // Keep the established top-level trees for non-Blue-Book/custom question types.
  if (has("machine design", "shaft design", "gear train", "gear design", "bearing", "key and spline", "spring design", "fatigue failure", "factor of safety", "belt drive", "chain drive", "clutch", "brake design", "flywheel design", "coupling")) {
    let branch = has("gear", "belt drive", "chain drive") ? "Power Transmission" : has("shaft", "bearing", "key", "spline", "coupling") ? "Shafts, Keys & Bearings" : has("spring") ? "Springs" : has("fatigue", "stress", "strain", "factor of safety") ? "Stress & Failure" : "Machine Components";
    return {main:"Machine Design", branch};
  }
  if (has("engineering economics", "present worth", "annuity", "future worth", "interest rate", "depreciation", "payback", "cost per", "production cost", "plant layout", "material handling", "industrial safety", "work study", "time study", "inventory", "maintenance management", "reliability", "ergonomics")) {
    let branch = has("present worth", "annuity", "future worth", "interest rate", "depreciation", "payback", "cost per") ? "Engineering Economics" : has("safety") ? "Industrial Safety" : has("layout", "material handling") ? "Plant Layout & Material Handling" : has("inventory", "maintenance", "reliability") ? "Maintenance & Operations" : "Industrial Engineering";
    return {main:"Industrial Plant Engineering", branch};
  }
  if (has("calculus", "algebra", "matrix", "ellipse", "derivative", "integral", "probability", "statistics", "gauss-seidel", "trigonometry", "logarithm", "geometry", "mathematics", "numerical method", "differential equation", "complex number", "vector", "linear equation")) {
    let branch = has("probability", "statistics") ? "Probability & Statistics" : has("matrix", "gauss-seidel", "numerical method", "linear equation") ? "Numerical Methods & Linear Algebra" : has("derivative", "integral", "calculus", "differential equation") ? "Calculus & Differential Equations" : has("ellipse", "geometry", "trigonometry", "vector") ? "Geometry, Trigonometry & Vectors" : "Algebra & General Mathematics";
    return {main:"Mathematics / MESL", branch};
  }

  // Blue Book branch uses the reviewed subject field first, not a loose keyword guess.
  const subject = String(q.subject || "");
  if (subject === "Thermodynamics") return {main:"Power Plant Engineering", branch:"Thermodynamics"};
  if (subject === "Fluid Mechanics") return {main:"Power Plant Engineering", branch:"Fluid Mechanics & Piping"};
  if (subject === "Heat Transfer") return {main:"Power Plant Engineering", branch:"Heat Transfer"};
  if (subject === "Refrigeration") return {main:"Power Plant Engineering", branch:"Refrigeration & Air Conditioning"};
  if (subject === "Engineering Materials") return {main:"Power Plant Engineering", branch:"Engineering Materials"};
  if (subject === "Chemical Engineering" || subject === "Drying Operations") return {main:"Power Plant Engineering", branch:"Drying & Chemical Processes"};
  if (subject === "Power Plant Engineering") {
    let branch = has("boiler", "steam generator", "steam turbine", "condenser", "feedwater", "superheater", "economizer", "throttling calorimeter") ? "Boilers & Steam Systems" : has("diesel", "combustion", "fuel", "coal", "heating value", "air-fuel", "exhaust gas", "hydroelectric", "hydro-electric", "net head", "plant output", "generator", "load factor", "auxiliar", "thermal efficiency", "heat rate") ? "Power Plant Systems & Operations" : "General Power Plant Engineering";
    return {main:"Power Plant Engineering", branch};
  }

  // Remaining general engineering items are assigned using explicit topic clues.
  let branch = "General Power Plant Engineering";
  if (has("pipe", "piping", "pipeline", "flow through", "head loss", "darcy", "hazen", "elbow", "friction factor", "bernoulli", "viscosity", "manometer", "buoyancy", "pitot", "velocity head")) branch = "Fluid Mechanics & Piping";
  else if (has("boiler", "steam", "condenser", "feedwater", "superheater", "economizer", "steam turbine")) branch = "Boilers & Steam Systems";
  else if (has("refrigeration", "refrigerant", "air conditioning", "cooling load", "cop", "heat pump", "humidity ratio", "moist air", "psychrometric")) branch = "Refrigeration & Air Conditioning";
  else if (has("heat transfer", "nusselt", "convection", "conduction", "radiation", "cooling time", "lumped capacitance", "heat exchanger", "insulation", "black body", "radiated heat")) branch = "Heat Transfer";
  else if (has("diesel", "combustion", "fuel consumption", "fuel rate", "heating value", "air-fuel", "chimney", "nuclear", "generator", "load factor", "capacity factor", "power plant", "hydroelectric", "turbine", "net head", "water power", "pump", "weir", "open channel")) branch = "Power Plant Systems & Operations";
  else if (has("thermodynamic", "entropy", "enthalpy", "rankine", "otto cycle", "diesel cycle", "specific heat", "superheat", "subcooled", "latent heat", "ideal gas", "gas law", "charles law")) branch = "Thermodynamics";
  else if (has("beam", "moment", "centroid", "truss", "ladder", "cable", "tension", "statics", "dynamics", "projectile", "velocity", "acceleration", "work-energy", "impulse", "stress", "strain", "friction")) branch = "Applied Mechanics";
  return {main:"Power Plant Engineering", branch};
}
function librarySubject(q) { return subjectTree(q).main; }
function populateSubjectFilter(keepSelection = true) {
  const previous = keepSelection ? subjectFilter.value : "all";
  const subjects = ["PIPE", "Power Plant Engineering", "Industrial Plant Engineering", "Mathematics / MESL", "Machine Design"];
  subjectFilter.replaceChildren();
  const all = document.createElement("option"); all.value = "all"; all.textContent = "All review subjects"; subjectFilter.append(all);
  subjects.forEach(subject => { const option = document.createElement("option"); option.value = subject; option.textContent = subject; subjectFilter.append(option); });
  subjectFilter.value = subjects.includes(previous) || previous === "all" ? previous : "all";
  document.querySelector("#library-count").textContent = `${questions.length} question${questions.length === 1 ? "" : "s"}`;
}
function setPracticeFavoriteButton(q) {
  const button = document.querySelector("#practice-favorite");
  if (!button || !q) return;
  const yes = favoriteIds.includes(q.id);
  button.textContent = yes ? "★ Saved to Favorites" : "☆ Add to Favorites";
  button.classList.toggle("is-favorite", yes);
  button.setAttribute("aria-pressed", String(yes));
  button.onclick = () => {
    favoriteIds = favoriteIds.includes(q.id) ? favoriteIds.filter(id => id !== q.id) : [...favoriteIds, q.id];
    saveFavorites(); setPracticeFavoriteButton(q); renderLibrary();
  };
}

function renderLibrary() {
  const selectedSubject = subjectFilter?.value || "all";
  const query = (librarySearch?.value || "").trim().toLowerCase();
  const selectedDifficulty = difficultyFilter?.value || "all";
  const onlyFavorites = Boolean(favoritesOnly?.checked);
  const selectedAnswerStatus = answerStatusFilter?.value || "all";
  const scoreableCount = questions.filter(q => q.answerVerified !== false).length;
  const unverifiedCount = questions.length - scoreableCount;
  if (answerKeySummary) answerKeySummary.textContent = `${scoreableCount} questions are eligible for scoring; ${unverifiedCount} are practice-only because their source answers or solutions need verification.`;
  let visible = questions.map((q,index)=>({q,index})).filter(({q})=>{
    if (selectedAnswerStatus === "scoreable" && q.answerVerified === false) return false;
    if (selectedAnswerStatus === "unverified" && q.answerVerified !== false) return false;
    if (selectedSubject !== "all" && librarySubject(q) !== selectedSubject) return false;
    if (selectedDifficulty !== "all" && q.difficulty !== selectedDifficulty) return false;
    if (onlyFavorites && !favoriteIds.includes(q.id)) return false;
    if (query) {
      const searchable = [q.subject,q.category,q.difficulty,q.prompt,q.formula,q.formulaReason,q.derivation,q.substitution,q.finalAnswer,q.unitCheck,q.concept,q.shortcutFormula,q.shortcut,...(Array.isArray(q.commonMistakes)?q.commonMistakes:[q.commonMistakes]),...(q.options||[]).map(o=>o.text),...(q.given||[]),...(q.calculation||[])].filter(Boolean).join(" ").toLowerCase();
      if (!searchable.includes(query)) return false;
    }
    return true;
  });
  const rank = {Beginner:1,Intermediate:2,Advanced:3};
  if (!librarySort || librarySort.value === "default") visible.sort((a,b)=>librarySubject(a.q).localeCompare(librarySubject(b.q)) || String(a.q.category).localeCompare(String(b.q.category)));
  if (librarySort?.value === "title") visible.sort((a,b)=>String(a.q.category).localeCompare(String(b.q.category)));
  else if (librarySort?.value === "difficulty") visible.sort((a,b)=>(rank[a.q.difficulty]||9)-(rank[b.q.difficulty]||9));
  else if (librarySort?.value === "custom-first") visible.sort((a,b)=>Number(Boolean(a.q.builtIn))-Number(Boolean(b.q.builtIn)));
  libraryList.replaceChildren();
  let lastGroup = "";
  let lastBranch = "";
  visible.forEach(({q,index})=>{
    const tree = subjectTree(q);
    const groupName = tree.main;
    const branchName = tree.branch;
    if (groupName !== lastGroup) {
      const heading = document.createElement("h3"); heading.className = "library-group-heading";
      heading.textContent = `${groupName} · ${visible.filter(item => subjectTree(item.q).main === groupName).length}`;
      libraryList.append(heading); lastGroup = groupName; lastBranch = "";
    }
    const branchKey = `${groupName}::${branchName}`;
    if (branchKey !== lastBranch) {
      const branchHeading = document.createElement("h4"); branchHeading.className = "library-branch-heading";
      branchHeading.textContent = `${branchName} · ${visible.filter(item => { const t = subjectTree(item.q); return t.main === groupName && t.branch === branchName; }).length}`;
      libraryList.append(branchHeading); lastBranch = branchKey;
    }
    const card=document.createElement("div"); card.className="library-card";
    const top=document.createElement("div"); top.className="library-card-top";
    const button=document.createElement("button"); button.type="button";
    button.className=`library-item${index===currentIndex?" active":""}`;
    button.setAttribute("aria-current",index===currentIndex?"true":"false");
    const title=document.createElement("strong"); title.textContent=q.category;
    const detail=document.createElement("span"); detail.textContent=`${q.subject} · ${q.boardCategory || librarySubject(q)} · ${q.difficulty}${q.sourceOrganization ? (String(q.sourceOrganization).toLowerCase().includes("blue-book") ? " · Source: Blue Book" : String(q.sourceOrganization).toLowerCase().includes("ipe") ? " · Source: IPE" : " · Source material") : ""}${q.builtIn?" · Starter question":" · Custom question"}`;
    const keyState=document.createElement("span");
    keyState.className=`library-key-state ${q.answerVerified === false ? "is-unverified" : "is-scoreable"}`;
    keyState.textContent=q.answerVerified === false ? "Unverified · practice only" : (String(q.id || "").startsWith("bluebook-") ? "Blue Book answer · scoreable" : "Answer set · scoreable");
    button.append(title,detail,keyState); button.addEventListener("click",()=>{currentIndex=index;renderQuestion();renderLibrary();});
    top.append(button);
    const fav=document.createElement("button"); fav.type="button";
    const yes=favoriteIds.includes(q.id); fav.className=`library-favorite${yes?" is-favorite":""}`;
    fav.textContent=yes?"★":"☆"; fav.title=yes?"Remove from favorites":"Add to favorites";
    fav.setAttribute("aria-label",`${yes?"Remove":"Add"} ${q.category} ${yes?"from":"to"} favorites`);
    fav.setAttribute("aria-pressed",String(yes));
    fav.addEventListener("click",()=>{favoriteIds=favoriteIds.includes(q.id)?favoriteIds.filter(id=>id!==q.id):[...favoriteIds,q.id];saveFavorites();renderLibrary();});
    top.append(fav); card.append(top);
    if (!q.builtIn) {
      const controls=document.createElement("div"); controls.className="library-management";
      const editButton=document.createElement("button"); editButton.type="button"; editButton.className="button button-secondary"; editButton.textContent="Edit";
      editButton.setAttribute("aria-label",`Edit ${q.category}`); editButton.addEventListener("click",()=>openEditQuestion(q.id));
      const deleteButton=document.createElement("button"); deleteButton.type="button"; deleteButton.className="button button-danger"; deleteButton.textContent="Delete";
      deleteButton.setAttribute("aria-label",`Delete ${q.category}`); deleteButton.addEventListener("click",()=>deleteQuestion(q.id));
      controls.append(editButton,deleteButton); card.append(controls);
    } else { const note=document.createElement("div"); note.className="library-built-in-note"; note.textContent="Starter question · protected"; card.append(note); }
    libraryList.append(card);
  });
  if(libraryResults) libraryResults.textContent=`Showing ${visible.length} of ${questions.length} questions${onlyFavorites?" · favorites only":""}.`;
  if(!visible.length){const empty=document.createElement("p");empty.className="library-results-empty";empty.textContent=questions.length===0?"The question bank is empty. Select ‘Add a question’ below to build a new bank from problems whose answer keys and worked solutions you have checked.":"No questions match these filters. Try another search or clear a filter.";libraryList.append(empty);}
}
function renderQuestion() {
  const q = questions[currentIndex];
  selectedAnswer = ""; submitted = false;
  if (q && initialQuestionRenderDone) { try { localStorage.setItem(LAST_QUESTION_KEY, String(q.id)); } catch {} }
  if (!q) {
    categoryEl.textContent = "EMPTY QUESTION BANK";
    numberEl.textContent = "No questions yet";
    difficultyEl.textContent = "Ready for verified questions";
    const keyStatusEl = document.querySelector("#answer-key-status");
    if (keyStatusEl) { keyStatusEl.className = "answer-key-status is-unverified"; keyStatusEl.textContent = "No questions are loaded. Add a question to build your bank."; }
    const favoriteButton = document.querySelector("#practice-favorite");
    if (favoriteButton) { favoriteButton.hidden = true; favoriteButton.disabled = true; }
    questionEl.textContent = "Your question bank is intentionally empty. Use ‘Add a question’ in the Question Library to add a problem after checking its source, answer, and worked solution.";
    progressFill.style.width = "0%";
    optionsEl.replaceChildren();
    checkButton.hidden = true; checkButton.disabled = true; nextButton.hidden = true;
    feedbackEl.hidden = true; feedbackEl.replaceChildren();
    return;
  }
  const favoriteButton = document.querySelector("#practice-favorite");
  if (favoriteButton) { favoriteButton.hidden = false; favoriteButton.disabled = false; }
  categoryEl.textContent = q.subject.toUpperCase();
  numberEl.textContent = `Question ${currentIndex+1} of ${questions.length}`;
  difficultyEl.textContent = q.difficulty;
  const keyStatusEl = document.querySelector("#answer-key-status");
  if (keyStatusEl) {
    const keyIsMarkedVerified = q.answerVerified !== false;
    keyStatusEl.className = `answer-key-status ${keyIsMarkedVerified ? "is-scoreable" : "is-unverified"}`;
    keyStatusEl.textContent = keyIsMarkedVerified
      ? (String(q.id || "").startsWith("bluebook-") ? "Scoring status: Blue Book printed answer used." : "Scoring status: answer set; included in scores.")
      : "The source answer or worked solution is not verified. Practice is available, but this question is excluded from scores.";
    keyStatusEl.setAttribute("aria-label", keyStatusEl.textContent);
  }
  setPracticeFavoriteButton(q);
  if (typeof window.renderMathInto === 'function') window.renderMathInto(questionEl, q.prompt); else questionEl.textContent = q.prompt;
  progressFill.style.width = `${((currentIndex+1)/questions.length)*100}%`;
  optionsEl.replaceChildren();
  q.options.forEach(option => {
    const label = document.createElement("label"); label.className = "option";
    const input = document.createElement("input"); input.type="radio"; input.name="answer"; input.value=option.value;
    input.addEventListener("change", () => { selectedAnswer=option.value; checkButton.disabled=false; });
    const text = document.createElement("span"); if (typeof window.renderMathInto === 'function') window.renderMathInto(text, `${option.value}. ${option.text}`); else text.textContent=`${option.value}. ${option.text}`;
    label.append(input,text); optionsEl.append(label);
  });
  checkButton.hidden=false; checkButton.disabled=true; nextButton.hidden=true;
  feedbackEl.hidden=true; feedbackEl.className="feedback";
}
async function copySolutionText(value, button) {
  const original = button.textContent;
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(String(value ?? ""));
    } else {
      const field = document.createElement("textarea"); field.value = String(value ?? ""); field.setAttribute("readonly", "");
      field.style.position = "fixed"; field.style.opacity = "0"; document.body.append(field); field.select();
      const copied = document.execCommand("copy"); field.remove(); if (!copied) throw new Error("Copy unavailable");
    }
    button.textContent = "Copied ✓";
    window.setTimeout(() => { if (button.isConnected) button.textContent = original; }, 1400);
  } catch {
    button.textContent = "Select and copy manually";
    window.setTimeout(() => { if (button.isConnected) button.textContent = original; }, 2200);
  }
}

function getFormulaReason(q) {
  if (String(q.formulaReason || "").trim()) return q.formulaReason.trim();
  const f = String(q.formula || "").toLowerCase();
  const c = String(q.category || "").toLowerCase();
  const t = `${q.prompt || ""} ${q.concept || ""}`.toLowerCase();
  if (f.includes("h/u = cp/cv") || f.includes("h = ku")) return "The saved relationship connects enthalpy h, internal energy u, and the specific-heat ratio k for the ideal-gas model used by the source. It is appropriate here because the problem gives internal energy and the helium heat-capacity ratio; note the model/reference assumptions stated in the derivation.";
  if (f.includes("w = rt") || f.includes("pv = rt")) return "The problem asks for ideal-gas specific flow work. For an ideal gas, Pv = RT, where v is specific volume and R is the specific gas constant. The temperature must be absolute, and R must be on a per-unit-mass basis.";
  if (f.includes("pv = m(ru/mw)") && /mass/i.test(q.prompt || "")) return "The problem asks for gas mass. Start from PV = nRuT, use n = m/MW, and rearrange to m = PVMW/(RuT). Use absolute pressure and temperature and keep Ru compatible with the chosen volume and pressure units.";
  if (f.includes("ru/mw") || f.includes("molecular weight") || c.includes("ideal gas")) {
    if (f.includes("mw")) return "Pressure, volume, mass, and absolute temperature are linked by the ideal-gas equation. Rearranging that relation lets you calculate molecular weight or identify the gas. Use absolute pressure and absolute temperature, and keep Ru and the chosen volume/pressure units compatible.";
    return "The ideal-gas equation links pressure, volume, mass, gas constant, and absolute temperature. Choose it when those state properties are given or one of them is unknown, and verify that the ideal-gas assumption is appropriate.";
  }
  if (c.includes("refrigeration safety")) return "This is a refrigeration safety/code-style relation rather than a general energy-balance equation. The question's requested safety quantity and the specified refrigerant/load determine which source relation to use. Treat the coefficient and units as a matched set; do not change units without checking the applicable standard.";
  if (c.includes("thermal efficiency")) return "Efficiency compares useful energy output with energy input. The heat-rate shortcut uses the energy equivalent of 1 kW·h (about 3412 Btu), so the heat-rate units must be Btu/kW·h before applying the shortcut.";
  if (c.includes("pipe flow")) return "The question asks about flow loss per pipe length. First obtain a consistent average velocity, use the specified head-loss relation and friction-factor convention, then divide head loss by the pipe length to obtain the hydraulic gradient.";
  if (c.includes("drying")) return "Drying calculations use a mass balance. The dry-solid mass remains constant, but wet-basis and dry-basis moisture percentages mean different things. Convert the moisture basis before comparing the initial and final material.";
  if (c.includes("fluid statics")) return (f.includes("f = p") || f.includes("πd") || /force acting/i.test(q.prompt || "")) ? "Hydrostatic pressure depends on vertical depth. For a force on a flat horizontal bottom, multiply the uniform bottom pressure by the bottom area; pressure and force are different quantities." : "For a fluid at rest, gauge pressure increases with vertical depth: p = γh = ρgh. Use vertical depth (not distance along a sloping path) and distinguish gauge pressure from absolute pressure.";
  if (c.includes("steam properties")) return "Steam/water properties depend on the thermodynamic state. Identify whether the water is compressed liquid, saturated mixture, or superheated before selecting table values. If quality x is given for a saturated mixture, use the mixture relation only within the saturation dome.";
  if (c.includes("compressor performance")) return "The question compares energy use and different compressor/motor power quantities. Convert energy over a time period into average power first, then apply the efficiencies in the order stated. Efficiency is a ratio of powers defined at specific locations in the system.";
  if (c.includes("refrigeration performance")) return "Refrigeration performance compares cooling effect with power input. Keep cooling rate and power in compatible units, apply COP/EER definitions as stated, and use 1 ton of refrigeration ≈ 3.516 kW only when converting capacity.";
  if (c.includes("diesel engine")) return "Mechanical efficiency relates brake power to indicated power. Use ηm = BP/IP and the power balance FP = IP − BP; first identify which engine power is given and which quantity is requested.";
  if (c.includes("air standard cycle")) return "The pressure ratio relation P₂/P₁ = rᵏ applies to the stated isentropic ideal-gas compression model. It gives a pressure ratio, not the absolute pressure P₂ unless P₁ is also known.";
  if (c.includes("units, measurement")) return "The main challenge is consistent units. Convert the given measurement into the unit system required by the answer before substituting, and check whether the quantity is mass, force, energy, or temperature.";
  return `The saved relation (${q.formula || "formula not recorded"}) should connect the information given to the requested quantity. The topic clue is “${q.category || q.subject || "this concept"}.” Check the model assumptions and variable definitions before substituting values.`;
}

function getDerivationNote(q) {
  if (String(q.derivation || "").trim()) return q.derivation.trim();
  const f = String(q.formula || "").toLowerCase().replace(/\s+/g, " ").trim();
  const c = String(q.category || "").toLowerCase();
  if (f.startsWith("w = rt") || f.startsWith("w=rt")) return "For an ideal gas, PV = mRT. Divide by mass m to write Pv = RT, where v = V/m. Specific flow work is Pv, so w = RT. The specific gas constant R must match the gas and the temperature must be absolute.";
  if (f.includes("pv = m(ru/mw)t")) return "Start with PV = nRuT and use n = m/MW. Substitution gives PV = (m/MW)RuT. Rearranging yields MW = mRuT/(PV) when molecular weight is the unknown, or m = PVMW/(RuT) when mass is the unknown.";
  if (f.includes("h/u = cp/cv")) return "Under the source's ideal-gas, constant-specific-heat model, h = cpT and u = cvT when the same temperature-based reference is used. Dividing gives h/u = cp/cv = k, hence h = ku. This relation depends on the source model and reference convention; it is not a universal identity for arbitrary tabulated h and u.";
  if (f.includes("100√w") || f.includes("0.138√w") || f.includes("relief-device capacity")) return "The recorded relation is an empirical/code-style formula. Its coefficient cannot be derived from dimensional algebra alone; use the prescribed source/standard and preserve the units and scope for which that coefficient was specified.";
  if (f.includes("pabs = pgage + patm") && c.includes("refrigeration safety")) return "Absolute pressure is measured from a perfect vacuum, while gauge pressure is measured relative to the local atmosphere, so Pabs = Pgage + Patm. The separate discharge-pipe length relation is source/standard-specific; apply it only with its stated assumptions and units.";
  if (f.includes("pabs = pgage + patm")) return "Absolute pressure is measured from a perfect vacuum; gauge pressure is measured relative to the local atmosphere. Therefore Pabs = Pgage + Patm. Use compatible pressure units and the appropriate local atmospheric pressure.";
  if (f.includes("3412/heat rate") || f.includes("3412/hr")) return "Heat rate is the heat input needed per kW·h of output. Since 1 kW·h ≈ 3412 Btu, efficiency = useful electrical energy equivalent / heat input = 3412/HR. Multiply by 100 to express it as a percent.";
  if (f.includes("hf = f(l/d)") || f.includes("hydraulic gradient")) return "The hydraulic gradient is defined as head loss per unit pipe length: i = hf/L. In the saved method, compute velocity and head loss first, then divide by L. Keep every length in the same unit and follow the source's friction-factor convention.";
  if (f.includes("he = k v²/(2g)")) return "The entrance-loss coefficient is defined by K = he/(v²/(2g)). Rearranging gives he = K v²/(2g). Because velocity is squared, doubling velocity makes this loss four times as large when K stays constant.";
  if (c.includes("drying")) return "Begin with the mass balance: dry solids in the feed equal dry solids in the product. For dry-basis moisture X, water mass = X × dry-solid mass. For wet-basis fraction x, x = water/(water + dry solids); rearranging gives X = x/(1 − x). Apply the correct basis before taking differences.";
  if ((f.includes("f = p") || f.includes("πd²/4")) && /force acting/i.test(q.prompt || "")) return "Hydrostatic pressure at a depth h is p = ρgh. On a horizontal flat bottom, that pressure is uniform, so resultant force F = pA. For a circular bottom, A = πD²/4; combine them to obtain F = ρgh(πD²/4).";
  if (f.includes("p = ρgh") || f.includes("p = γh") || f.includes("h = p/(sg")) return "For a stationary fluid, a small vertical slice balances pressure force against its weight, giving dp/dh = ρg = γ. Integrating from the free surface where gauge pressure is zero gives p = ρgh = γh. Rearranging gives h = p/γ when depth is unknown.";
  if (f.includes("hf + xhfg") || f.includes("hf + x hfg")) return "For a saturated liquid-vapor mixture, h = (1 − x)hf + xhg. Since hfg = hg − hf, simplify to h = hf + xhfg. Quality x is the vapor mass fraction and must lie from 0 to 1 for a saturated mixture.";
  if (f.includes("ηmech = pindicated/pshaft") || f.includes("ηm = bp/ip")) return "Efficiency is the useful output divided by the corresponding input. Use the definition stated in the problem: ηmech = Pindicated/Pshaft or ηm = BP/IP. Multiply by 100 for percent, and do not swap the numerator and denominator.";
  if (f.includes("tr = re/3.516") || f.includes("tr = cop·w/3.516")) return "Refrigeration capacity in kW is converted to tons of refrigeration by dividing by 3.516 kW/TR. The source's calculation also applies its stated COP, motor efficiency, and loss factor. Important: if the question wording requests a different quantity than TR, resolve that inconsistency before treating the printed result as correct.";
  if (f.includes("eer = qref") || f.includes("cop = eer/3.412")) return "EER and COP both compare cooling effect to power input, but EER conventionally uses Btu/h per watt while COP is dimensionless. The conversion factor 3.412 connects W and Btu/h: COP ≈ EER/3.412 under the stated units.";
  if (f.includes("pnew = pold") || c.includes("clearance") && /unaffected/i.test(q.formula || "")) return "The source explicitly assumes compressor power is unaffected by the clearance change. That is an imposed problem assumption, not a general derivation of real compressor behavior; use it only for this stated question and flag it for source verification if the assumption seems physically incomplete.";
  if (f.includes("p₂/p₁ = rᵏ") || f.includes("p2/p1 = r^k")) return "For isentropic compression of an ideal gas, P vᵏ is constant. Thus P₂/P₁ = (v₁/v₂)ᵏ. The compression ratio r = v₁/v₂, so P₂/P₁ = rᵏ.";
  if (f.includes("clearance ratio c = 1/(r−1)") || f.includes("1/(r-1)")) return "Compression ratio r = (Vs + Vc)/Vc = 1 + Vs/Vc. Rearranging gives Vc/Vs = 1/(r − 1). If clearance ratio is requested as a percent of swept volume, multiply that ratio by 100%.";
  if (f.includes("t(°f) = h + 32") || f.includes("°c = (°f−32)")) return "For temperature-scale conversion, the Fahrenheit and Celsius zero points differ by 32 degrees and each Celsius degree spans 9/5 Fahrenheit degrees. Therefore °C = (°F − 32) × 5/9. For the approximate enthalpy-temperature relation in the source, verify the stated liquid-water approximation before using it.";
  if (f.includes("k = °r × 5/9")) return "Rankine and Kelvin both start at absolute zero. Their degree sizes differ by a factor of 9/5, so T(K) = T(°R) × 5/9.";
  if (f.includes("m = ρv")) return "Density is mass per unit volume, ρ = m/V. Rearranging gives m = ρV. For water near ordinary conditions, density is approximately 1 kg/L, so the mass in kilograms is numerically close to volume in litres.";
  if (c.includes("thermal efficiency")) return "Efficiency is a ratio of useful output to input. Start with the definition, place both quantities on a consistent energy basis, then multiply by 100% if the answer is requested as a percentage.";
  if (c.includes("steam properties")) return "The source gives a direct property approximation/table relation rather than a full derivation. First identify the thermodynamic state, then use the matching property relation and verify whether the values are from a table or an approximation.";
  return "A question-specific derivation has not yet been recorded for this item. Start from the saved governing formula, define every symbol, and isolate the requested variable using the same algebraic operation on both sides. Do not assume a shortcut is equivalent unless it follows from that equation and its assumptions.";
}

function getCommonExamTraps(q) {
  const saved = Array.isArray(q.commonMistakes) ? q.commonMistakes.filter(Boolean) : String(q.commonMistakes || "").split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  if (saved.length) return saved;
  const text = `${q.subject || ""} ${q.category || ""} ${q.prompt || ""} ${q.formula || ""}`.toLowerCase();
  const traps = [];
  if (/ideal gas|ru|mw|pv =|gas properties/.test(text)) traps.push("Convert temperature to an absolute scale (K or °R) before using the ideal-gas equation.", "Use absolute pressure, not gauge pressure, when the equation requires absolute pressure.", "Match Ru, pressure, volume, and energy units; do not mix SI and English units silently.");
  else if (/drying|moisture|wet basis|dry basis/.test(text)) traps.push("Do not subtract wet-basis and dry-basis percentages directly.", "Dry-solid mass is conserved; calculate it first.", "State the moisture basis in the final answer.");
  else if (/fluid statics|pressure|depth|ρgh|γh/.test(text)) traps.push("Use vertical depth, not the distance along a surface.", "Do not confuse pressure (Pa) with force (N); force requires area.", "Check whether the requested pressure is gauge or absolute.");
  else if (/steam|enthalpy|quality|hf|hfg|saturated/.test(text)) traps.push("Confirm the state before using saturated-property values.", "Quality x is a fraction from 0 to 1, not a percent entered as 30 instead of 0.30.", "Keep specific enthalpy and heat units consistent; use tables appropriate to the stated pressure or temperature.");
  else if (/pipe flow|head loss|friction|hydraulic gradient/.test(text)) traps.push("Convert flow rate and diameter to consistent units before calculating velocity.", "Do not mix Darcy and Fanning friction-factor conventions.", "Hydraulic gradient is head loss divided by length, not the head loss alone.");
  else if (/refrigeration|cop|eer|ton of refrigeration|mechanical ventilation|relief/.test(text)) traps.push("Keep the source relation's prescribed units with its coefficient.", "Do not confuse cooling capacity, electrical power, energy, and efficiency.", "Check conversion factors such as 1 TR ≈ 3.516 kW and 1 kW·h ≈ 3412 Btu.");
  else if (/compression ratio|otto|diesel cycle|isentropic|clearance/.test(text)) traps.push("Use the compression ratio in the direction defined by the cycle, usually V₁/V₂.", "A pressure ratio is dimensionless; it is not the final pressure unless P₁ is known.", "Check whether the answer is a ratio or a percentage.");
  else if (/temperature|°f|°c|rankine|kelvin/.test(text)) traps.push("Temperature conversion may require an offset (°F ↔ °C) as well as a scale factor.", "Use absolute temperature for gas laws; use temperature differences only where the formula calls for ΔT.", "Report the requested temperature scale, not just a numerically equivalent value in another scale.");
  else traps.push("Write the required quantity before selecting the formula.", "Convert units before substitution and keep them visible through the calculation.", "Check the answer's sign, magnitude, and requested unit before selecting an option.");
  const check = String(q.unitCheck || "");
  if (/discrep|mismatch|flagged|does not match|source stem/i.test(check)) traps.unshift(`Source/reconciliation warning: ${check}`);
  return traps;
}

function recommendedPracticeQuestions(q) {
  const stop = new Set(["the","and","for","from","with","what","find","compute","calculate","determine","when","using","use","given","that","this","then","into","per","its","are","has","have","is","of","to","a","an","in","on","at","by","or","as","be","if"]);
  const words = value => new Set(String(value || "").toLowerCase().replace(/[^a-z0-9]+/g," ").split(/\s+/).filter(w => w.length > 2 && !stop.has(w)));
  const baseWords = words(`${q.category || ""} ${q.concept || ""} ${q.prompt || ""}`);
  return questions.filter(other => other && other.id !== q.id).map(other => {
    let score = 0;
    if (other.category && other.category === q.category) score += 12;
    if (other.subject && other.subject === q.subject) score += 5;
    const ta = subjectTree(q), tb = subjectTree(other);
    if (ta.main === tb.main && ta.branch === tb.branch) score += 3;
    if (q.formula && other.formula && q.formula.replace(/\s+/g,"").toLowerCase() === other.formula.replace(/\s+/g,"").toLowerCase()) score += 6;
    const ow = words(`${other.category || ""} ${other.concept || ""} ${other.prompt || ""}`);
    let overlap = 0; baseWords.forEach(w => { if (ow.has(w)) overlap++; });
    score += Math.min(6, overlap);
    return { question: other, score };
  }).sort((a,b) => b.score-a.score || String(a.question.category).localeCompare(String(b.question.category)) || String(a.question.id).localeCompare(String(b.question.id))).slice(0,3).map(x => x.question);
}

function findFormulaBookEntryForQuestion(q) {
  const entries = Array.isArray(window.FORMULA_BOOK) ? window.FORMULA_BOOK : (typeof FORMULA_BOOK !== 'undefined' ? FORMULA_BOOK : []);
  if (!entries.length || !q) return null;
  const norm = value => String(value || '').toLowerCase().replace(/\\[a-z]+\{([^}]*)\}/g, '$1').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');
  const qFormula = norm(`${q.formula || ''} ${q.shortcutFormula || ''}`);
  const qTerms = norm(`${q.category || ''} ${q.subject || ''} ${q.prompt || ''} ${q.concept || ''}`).split(' ').filter(w=>w.length>3);
  let best = null;
  for (const entry of entries) {
    const f = norm(entry.formula);
    const title = norm(`${entry.title || ''} ${entry.topic || ''} ${entry.category || ''} ${entry.subject || ''}`);
    let score = 0;
    if (qFormula && f && (qFormula.includes(f) || f.includes(qFormula)) && Math.min(qFormula.length,f.length)>8) score += 10;
    const overlap = qTerms.filter(word => title.split(' ').includes(word)).length;
    score += Math.min(overlap,5);
    if (norm(q.subject) && norm(entry.subject) === norm(q.subject)) score += 1;
    // Prefer exact formula matches. Otherwise require at least 2 meaningful topic/title clues.
    if (score >= 10 && (!best || score > best.score)) best = {entry, score};
    else if (overlap >= 2 && score >= 3 && (!best || score > best.score)) best = {entry, score};
  }
  return best?.entry || null;
}

function showFeedback(q) {
  const verified = q.answerVerified !== false;
  const isCorrect = selectedAnswer === q.answer;
  feedbackEl.hidden = false;
  feedbackEl.className = `feedback ${verified ? (isCorrect ? "correct" : "incorrect") : ""}`;

  const heading = document.createElement("h3");
  heading.textContent = verified ? (isCorrect ? "Correct — well done!" : "Not quite. Let's learn from it.") : "Practice question";
  const result = document.createElement("p");
  result.textContent = verified
    ? `Correct answer: ${q.options.find(o => o.value === q.answer)?.text || q.answer}`
    : "This question is included for practice, but the correct option has not been verified. Treat the answer as provisional and check the original source before relying on it.";

  const sourceReview = document.createElement("section");
  sourceReview.className = "note source-first-review";
  const sourceReviewTitle = document.createElement("h4");
  sourceReviewTitle.textContent = "Source and answer status";
  const sourceAnswer = document.createElement("p");
  sourceAnswer.textContent = `Source answer: ${q.sourceAnswerStatus || (verified ? "Answer set" : "Not verified")}`;
  const sourceSolution = document.createElement("p");
  sourceSolution.textContent = `Solution: ${q.sourceSolutionStatus || "Step-by-step explanation provided below."}`;
  const independent = document.createElement("p");
  independent.textContent = `Clarification: ${q.independentSolutionStatus || "Explanatory notes are provided below."}`;
  sourceReview.append(sourceReviewTitle, sourceAnswer, sourceSolution, independent);

  const title = document.createElement("div");
  title.className = "solution-title";
  title.textContent = !verified ? "Guided solution · answer not verified" : (String(q.id || "").startsWith("bluebook-") ? "Guided solution · Blue Book source" : "Guided solution · saved question bank");

  const solutionActions = document.createElement("div");
  solutionActions.className = "solution-actions";
  const copyFormulaButton = document.createElement("button");
  copyFormulaButton.type = "button";
  copyFormulaButton.className = "button button-secondary button-small";
  copyFormulaButton.textContent = "Copy formula";
  copyFormulaButton.addEventListener("click", () => copySolutionText(q.formula || "", copyFormulaButton));

  const fullSolutionText = [
    `Question: ${q.prompt}`,
    `Given:\n${(q.given || []).join("\n")}`,
    `Formula: ${q.formula || "Not provided"}`,
    `Why this formula applies: ${getFormulaReason(q)}`,
    `Derivation / rearrangement: ${getDerivationNote(q)}`,
    `Substitution: ${q.substitution || "Not provided"}`,
    `Calculation:\n${(q.calculation || []).join("\n")}`,
    `Final answer: ${q.finalAnswer || "Not provided"}`,
    `Units & dimensional check: ${q.unitCheck || "Carry units through each calculation and confirm the final unit matches the quantity requested."}`,
    `Key concept: ${q.concept || "Not provided"}`,
    `Exam shortcut: ${q.shortcutFormula || "Not provided"}\n${q.shortcut || "Not provided"}`,
    `Common exam traps:\n${getCommonExamTraps(q).join("\n")}`
  ].join("\n\n");
  const copySolutionButton = document.createElement("button");
  copySolutionButton.type = "button";
  copySolutionButton.className = "button button-secondary button-small";
  copySolutionButton.textContent = "Copy full solution";
  copySolutionButton.addEventListener("click", () => copySolutionText(fullSolutionText, copySolutionButton));
  solutionActions.append(copyFormulaButton, copySolutionButton);

  // Step 2: link a solution back to its best-matching Formula Book entry.
  const formulaEntry = findFormulaBookEntryForQuestion(q);
  if (formulaEntry) {
    const formulaLinkButton = document.createElement('button');
    formulaLinkButton.type = 'button';
    formulaLinkButton.className = 'button button-secondary button-small';
    formulaLinkButton.textContent = `Open formula: ${formulaEntry.title}`;
    formulaLinkButton.addEventListener('click', () => {
      document.querySelector('.nav-button[data-view="formulas"]')?.click();
      const search = document.querySelector('#formula-search');
      if (search) {
        search.value = formulaEntry.title;
        search.dispatchEvent(new Event('input', {bubbles:true}));
      }
      const panel = document.querySelector('#formula-book');
      panel?.scrollIntoView({behavior:'smooth', block:'start'});
    });
    solutionActions.append(formulaLinkButton);
  }

  // Guided steps use only saved question-bank fields. No AI or network call is needed.
  // Guided steps make the reasoning explicit while clearly marking absent source content.
  const stages = [
    {
      label: "Understand the problem",
      content: q.prompt || "Read the question carefully.",
      explanation: "Before choosing an equation, restate what the question asks you to find. Circle the clue words, conditions, and requested units. Do not start calculating before you know the target quantity."
    },
    {
      label: "Given values and units",
      content: (q.given || []).join("\n") || "No given values were saved for this question.",
      explanation: "Separate the known values from the unknown. Convert values to a consistent unit system and note any assumptions or constants."
    },
    {
      label: "Why this formula applies",
      content: `${q.formula || "No formula was saved."}\n\n${getFormulaReason(q)}`,
      explanation: "Formula recognition is a core exam skill. Match the requested quantity and available givens to a relationship whose assumptions fit this problem."
    },
    {
      label: "Derivation or rearrangement",
      content: getDerivationNote(q),
      explanation: "Follow how the working relation comes from the governing principle. If the source only provides an empirical/code relation, do not invent a derivation—keep its prescribed units and conditions."
    },
    {
      label: "Substitute values with units",
      content: q.substitution || "No substitution was saved for this question.",
      explanation: "Replace each symbol with the matching value, not merely a nearby number. Keep units attached so conversion and cancellation errors are visible."
    },
    {
      label: "Calculate step by step",
      content: (q.calculation || []).join("\n") || "No calculation steps were saved for this question.",
      explanation: "Simplify in the correct order. Preserve enough significant figures in intermediate steps and round only when reporting the final result."
    },
    {
      label: "Final answer",
      content: q.finalAnswer || "No final answer was saved for this question.",
      explanation: "Answer the quantity actually requested and include the required unit. A source answer may be preserved even when a separate note flags a discrepancy; read the warning carefully.",
      isFinal: true
    },
    {
      label: "Unit and reasonableness check",
      content: q.unitCheck || "Carry the units through the calculation and confirm that the final unit matches the requested quantity.",
      explanation: "Check dimensional consistency, sign, and order of magnitude. If the source method or answer appears inconsistent, investigate it instead of forcing the numbers to match."
    },
    {
      label: "Key concept",
      content: q.concept || "No key concept was saved for this question.",
      explanation: "Explain the engineering principle in your own words. Understanding what the equation represents helps you recognize the method when the values or wording change."
    },
    {
      label: "Exam shortcut",
      content: `${q.shortcutFormula || q.formula || "No shortcut formula was saved."}\n${q.shortcut || "No shortcut method was saved."}`,
      explanation: "Use the shortcut to save time only when its conditions match the problem. Confirm the result against the full method while learning it."
    },
    {
      label: "Common exam traps",
      content: getCommonExamTraps(q).map((item,index)=>`${index+1}. ${item}`).join("\n"),
      explanation: "Before you move on, name the mistake most likely to cost a point here—unit choice, assumptions, formula selection, or arithmetic."
    }
  ];

  const guided = document.createElement("section");
  guided.className = "guided-solution";
  guided.setAttribute("aria-label", "Guided worked solution");
  const intro = document.createElement("p");
  intro.className = "guided-intro muted small";
  intro.textContent = "Work through one step at a time. Before revealing each step, pause and try to predict what comes next. This feature works offline using the solution saved with the question.";
  const progressRow = document.createElement("div");
  progressRow.className = "guided-progress-row";
  const progressLabel = document.createElement("strong");
  progressLabel.className = "guided-progress-label";
  progressLabel.setAttribute("aria-live", "polite");
  const progressCount = document.createElement("span");
  progressCount.className = "muted small guided-progress-count";
  const progressTrack = document.createElement("div");
  progressTrack.className = "guided-progress-track";
  progressTrack.setAttribute("role", "progressbar");
  progressTrack.setAttribute("aria-valuemin", "0");
  progressTrack.setAttribute("aria-valuemax", String(stages.length));
  progressTrack.setAttribute("aria-valuenow", "1");
  progressTrack.setAttribute("aria-label", "Guided solution progress");
  const progressFill = document.createElement("div");
  progressFill.className = "guided-progress-fill";
  progressTrack.append(progressFill);
  progressRow.append(progressLabel, progressCount);
  const stageContent = document.createElement("div");
  stageContent.className = "guided-stage-content";
  stageContent.setAttribute("aria-live", "polite");
  const controls = document.createElement("div");
  controls.className = "guided-controls";
  const previousButton = document.createElement("button");
  previousButton.type = "button";
  previousButton.className = "button button-secondary";
  previousButton.textContent = "← Previous step";
  const nextStepButton = document.createElement("button");
  nextStepButton.type = "button";
  nextStepButton.className = "button button-primary";
  const toggleFullButton = document.createElement("button");
  toggleFullButton.type = "button";
  toggleFullButton.className = "button button-secondary button-small";
  let stageIndex = 0;
  let showingFullSolution = false;

  function appendStage(container, stage, index) {
    addSolutionStep(container, String(index + 1), stage.label, stage.content, Boolean(stage.isFinal));
    const explanation = document.createElement("p");
    explanation.className = "guided-step-explanation";
    const explanationLabel = document.createElement("strong");
    explanationLabel.textContent = "Why this step matters: ";
    explanation.append(explanationLabel, document.createTextNode(stage.explanation));
    container.append(explanation);
  }

  function renderGuidedStage() {
    stageContent.replaceChildren();
    if (showingFullSolution) {
      progressLabel.textContent = "Full solution";
      progressCount.textContent = `${stages.length} steps shown`;
      progressTrack.setAttribute("aria-valuenow", String(stages.length));
      progressFill.style.width = "100%";
      stages.forEach((stage, index) => appendStage(stageContent, stage, index));
      previousButton.hidden = true;
      nextStepButton.hidden = true;
      toggleFullButton.textContent = "Return to guided mode";
    } else {
      const stage = stages[stageIndex];
      progressLabel.textContent = `Step ${stageIndex + 1}: ${stage.label}`;
      progressCount.textContent = `${stageIndex + 1} of ${stages.length}`;
      progressTrack.setAttribute("aria-valuenow", String(stageIndex + 1));
      progressFill.style.width = `${((stageIndex + 1) / stages.length) * 100}%`;
      appendStage(stageContent, stage, stageIndex);
      previousButton.hidden = stageIndex === 0;
      nextStepButton.hidden = false;
      nextStepButton.textContent = stageIndex === stages.length - 1 ? "Start again ↺" : "Reveal next step →";
      toggleFullButton.textContent = "Show all steps";
    }
  }

  previousButton.addEventListener("click", () => {
    if (stageIndex > 0) stageIndex--;
    renderGuidedStage();
  });
  nextStepButton.addEventListener("click", () => {
    stageIndex = stageIndex >= stages.length - 1 ? 0 : stageIndex + 1;
    renderGuidedStage();
  });
  toggleFullButton.addEventListener("click", () => {
    showingFullSolution = !showingFullSolution;
    renderGuidedStage();
  });
  controls.append(previousButton, nextStepButton, toggleFullButton);
  guided.append(intro, progressRow, progressTrack, stageContent, controls);
  renderGuidedStage();

  const relatedQuestions = recommendedPracticeQuestions(q);
  const relatedSection = document.createElement("section");
  relatedSection.className = "related-practice-panel";
  const relatedHeading = document.createElement("h4");
  relatedHeading.textContent = "Practice the concept · 3 next questions";
  const relatedIntro = document.createElement("p");
  relatedIntro.className = "muted small";
  relatedIntro.textContent = "These are existing questions ranked by topic, formula, and concept similarity. No new answer keys were generated.";
  relatedSection.append(relatedHeading, relatedIntro);
  if (!relatedQuestions.length) {
    const empty = document.createElement("p"); empty.className = "muted small";
    empty.textContent = "Add more questions to your bank to unlock related practice."; relatedSection.append(empty);
  } else {
    const relatedList = document.createElement("div"); relatedList.className = "related-practice-list";
    relatedQuestions.forEach((related, index) => {
      const card = document.createElement("article"); card.className = "related-practice-card";
      const label = document.createElement("p"); label.className = "eyebrow"; label.textContent = `Practice ${index+1} · ${related.category || related.subject}`;
      const prompt = document.createElement("p"); prompt.className = "related-practice-prompt"; prompt.textContent = related.prompt;
      const button = document.createElement("button"); button.type = "button"; button.className = "button button-secondary button-small"; button.textContent = "Try this question →";
      button.addEventListener("click", () => {
        window.openEngineeringReviewQuestion?.(related.id);
        document.querySelector('.nav-button[data-view="practice"]')?.click();
        document.querySelector(".quiz-panel")?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
      card.append(label, prompt, button); relatedList.append(card);
    });
    relatedSection.append(relatedList);
  }

  const sourceLink = q.source ? document.createElement("p") : null;
  if (sourceLink) {
    sourceLink.className = "question-source small";
    sourceLink.append(document.createTextNode("Original source: "));
    if (/^https?:\/\//i.test(String(q.source))) {
      const link = document.createElement("a");
      link.href = q.source;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = q.source;
      sourceLink.append(link);
    } else {
      const citation = document.createElement("span"); citation.textContent = q.source; sourceLink.append(citation);
      if (q.sourceFile) {
        sourceLink.append(document.createTextNode(" "));
        const pdfLink = document.createElement("a"); pdfLink.href = q.sourceFile; pdfLink.target = "_blank"; pdfLink.rel = "noopener noreferrer";
        pdfLink.textContent = q.sourceExtractedPdfPage ? `Open extracted PDF at page ${q.sourceExtractedPdfPage} (original PDF page ${q.sourcePage || "not listed"})` : `Open source PDF${q.sourcePage ? ` at page ${q.sourcePage}` : ""}`; sourceLink.append(pdfLink);
      }
    }
  }

  feedbackEl.replaceChildren(heading, result, sourceReview, title, solutionActions, guided, relatedSection);
  if (sourceLink) feedbackEl.append(sourceLink);
  if (q.sourceSolutionTranscript) {
    const transcriptDetails = document.createElement("details");
    transcriptDetails.className = "source-transcript-details";
    const transcriptSummary = document.createElement("summary");
    transcriptSummary.textContent = "Source solution transcript (OCR reference; may contain scan errors)";
    const transcriptBody = document.createElement("p");
    transcriptBody.className = "source-transcript-text";
    transcriptBody.textContent = q.sourceSolutionTranscript;
    transcriptDetails.append(transcriptSummary, transcriptBody);
    feedbackEl.append(transcriptDetails);
  }
}

function field(formData,name) { return String(formData.get(name) || "").trim(); }
function showFormError(message) { formError.textContent=message; formError.hidden=false; }
function hideFormError() { formError.textContent=""; formError.hidden=true; }

function setFormValue(name, value) {
  const control = addForm.elements.namedItem(name);
  if (control) control.value = value == null ? "" : value;
}
function openAddQuestion() {
  editingQuestionId = null;
  hideFormError();
  addForm.reset();
  document.querySelector("#question-dialog-title").textContent = "Add a question";
  document.querySelector("#save-question-button").textContent = "Save question";
  dialog.showModal();
}
function openEditQuestion(id) {
  const q = questions.find(item => item.id === id);
  if (!q || q.builtIn) return;
  editingQuestionId = id;
  hideFormError();
  addForm.reset();
  document.querySelector("#question-dialog-title").textContent = "Edit question";
  document.querySelector("#save-question-button").textContent = "Save changes";
  setFormValue("subject", q.subject);
  setFormValue("category", q.category);
  setFormValue("difficulty", q.difficulty);
  setFormValue("prompt", q.prompt);
  setFormValue("source", q.source || "");
  q.options.forEach(option => setFormValue(`option${option.value}`, option.text));
  setFormValue("answer", q.answer);
  const verificationControl = addForm.elements.namedItem("answerVerified");
  if (verificationControl) verificationControl.checked = q.answerVerified !== false;
  setFormValue("given", q.given.join("\n"));
  setFormValue("formula", q.formula);
  setFormValue("formulaReason", q.formulaReason || "");
  setFormValue("derivation", q.derivation || "");
  setFormValue("commonMistakes", (q.commonMistakes || []).join("\n"));
  setFormValue("substitution", q.substitution);
  setFormValue("calculation", q.calculation.join("\n"));
  setFormValue("finalAnswer", q.finalAnswer);
  setFormValue("unitCheck", q.unitCheck || "");
  setFormValue("concept", q.concept);
  setFormValue("shortcutFormula", q.shortcutFormula);
  setFormValue("shortcut", q.shortcut);
  dialog.showModal();
}
function deleteQuestion(id) {
  const index = questions.findIndex(item => item.id === id);
  if (index < 0 || questions[index].builtIn) return;
  const q = questions[index];
  if (!window.confirm(`Delete "${q.category}"? This cannot be undone.`)) return;

  const oldQuestions = questions;
  const oldProgress = JSON.parse(JSON.stringify(progress));
  questions = questions.filter(item => item.id !== id);
  if (Object.prototype.hasOwnProperty.call(progress.results, id)) {
    if (progress.results[id] === true) progress.correct = Math.max(0, progress.correct - 1);
    progress.answered = Math.max(0, progress.answered - 1);
    delete progress.results[id];
  }
  try {
    saveCustomQuestions();
    saveProgress();
  } catch {
    questions = oldQuestions;
    progress = oldProgress;
    window.alert("The browser could not save this change. Your question was not deleted. Check that browser storage is enabled.");
    return;
  }

  if (index < currentIndex) currentIndex--;
  else if (index === currentIndex) currentIndex = Math.min(index, questions.length - 1);
  populateSubjectFilter(true);
  renderQuestion();
  renderLibrary();
  renderQuestionBankAudit?.();
}
document.querySelector("#open-add-question").addEventListener("click", openAddQuestion);
document.querySelector("#close-add-question").addEventListener("click", () => { dialog.close(); editingQuestionId = null; });
document.querySelector("#cancel-add-question").addEventListener("click", () => { dialog.close(); editingQuestionId = null; });
dialog.addEventListener("click", event => {
  if (event.target === dialog) { dialog.close(); editingQuestionId = null; }
});
addForm.addEventListener("submit", event => {
  event.preventDefault();
  hideFormError();
  const data = new FormData(addForm);
  const subject=field(data,"subject"), category=field(data,"category"), prompt=field(data,"prompt");
  const optionValues = ["A","B","C","D"];
  const options = optionValues.map(value => ({value,text:field(data,`option${value}`)}));
  const answer=field(data,"answer");
  const answerVerified=Boolean(addForm.elements.namedItem("answerVerified")?.checked);
  const given=field(data,"given").split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  const calculation=field(data,"calculation").split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  const formula=field(data,"formula"), formulaReason=field(data,"formulaReason"), derivation=field(data,"derivation"), substitution=field(data,"substitution");
  const finalAnswer=field(data,"finalAnswer"), unitCheck=field(data,"unitCheck"), concept=field(data,"concept");
  const shortcutFormula=field(data,"shortcutFormula"), shortcut=field(data,"shortcut");
  const commonMistakes=field(data,"commonMistakes").split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  if (!subject || !category || !prompt || options.some(o=>!o.text.trim()) || !["A","B","C","D"].includes(answer) || given.length===0 || !formula || !substitution || calculation.length===0 || !finalAnswer || !concept || !shortcutFormula || !shortcut) {
    showFormError("Question not saved. Complete all four answer choices, choose the verified correct answer, and fill in every worked-solution field. Given values and calculation steps need at least one line each.");
    return;
  }

  if (editingQuestionId) {
    const index = questions.findIndex(q => q.id === editingQuestionId);
    if (index < 0 || questions[index].builtIn) {
      showFormError("This question is no longer available to edit. Close this window and try again.");
      return;
    }
    const oldQuestion = questions[index];
    const updatedQuestion = {
      id: oldQuestion.id, builtIn: false, subject, category, difficulty:field(data,"difficulty"), prompt, source:field(data,"source"), options, answer, answerVerified,
      given, formula, formulaReason, derivation, substitution, calculation, finalAnswer, unitCheck, concept, shortcutFormula, shortcut, commonMistakes
    };
    questions[index] = updatedQuestion;
    try {
      saveCustomQuestions();
    } catch {
      questions[index] = oldQuestion;
      showFormError("The browser could not save your changes. Storage may be full or disabled. Your original question has been kept.");
      return;
    }
    currentIndex = index;
  } else {
    const newQuestion = {
      id: `custom-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
      builtIn: false, subject, category, difficulty:field(data,"difficulty"), prompt, source:field(data,"source"), options, answer, answerVerified,
      given, formula, formulaReason, derivation, substitution, calculation, finalAnswer, unitCheck, concept, shortcutFormula, shortcut, commonMistakes
    };
    questions.push(newQuestion);
    try {
      saveCustomQuestions();
    } catch {
      questions.pop();
      showFormError("The browser could not save this question. Storage may be full or disabled. Try removing large text or enabling site storage.");
      return;
    }
    currentIndex=questions.length-1;
  }

  populateSubjectFilter(true);
  renderQuestion();
  renderLibrary();
  renderQuestionBankAudit?.();
  dialog.close();
  editingQuestionId = null;
});
formEl.addEventListener("submit", event => {
  event.preventDefault();
  if (!selectedAnswer || submitted) return;
  const q=questions[currentIndex];
  if (!q) return;
  submitted=true;
  recordDailyQuestionActivity(1);
  const isCorrect=selectedAnswer===q.answer;
  if (q.answerVerified !== false) {
    const previous=progress.results[q.id];
    if (previous===undefined) { progress.answered++; if(isCorrect) progress.correct++; }
    else { if(previous===true && !isCorrect) progress.correct--; if(previous===false && isCorrect) progress.correct++; }
    progress.results[q.id]=isCorrect; saveProgress();
    scheduleQuestionReview(q, isCorrect);
    if (!isCorrect) recordMistake(q, selectedAnswer, "practice");
  }
  optionsEl.querySelectorAll("input").forEach(input=>{input.disabled=true;});
  optionsEl.querySelectorAll(".option").forEach(label=>label.classList.add("disabled"));
  checkButton.hidden=true; nextButton.hidden=false;
  nextButton.textContent=reviewQueue && reviewQueue.length ? (reviewQueuePosition===reviewQueue.length-1 ? "Finish review ✓" : "Next review question →") : (currentIndex===questions.length-1 ? "Restart quiz ↻" : "Next question →");
  showFeedback(q);
});
nextButton.addEventListener("click", () => {
  if (reviewQueue && reviewQueue.length) {
    reviewQueuePosition++;
    if (reviewQueuePosition >= reviewQueue.length) {
      reviewQueue = null; reviewQueuePosition = 0;
      const status = document.querySelector('#review-status');
      if (status) status.textContent = 'Review session complete. Your answers and next review dates have been saved.';
      currentIndex = currentIndex === questions.length - 1 ? 0 : currentIndex + 1;
    } else {
      currentIndex = questions.findIndex(q => q.id === reviewQueue[reviewQueuePosition]);
    }
  } else {
    currentIndex=currentIndex===questions.length-1 ? 0 : currentIndex+1;
  }
  renderQuestion(); renderLibrary();
});
subjectFilter.addEventListener("change",renderLibrary);
answerStatusFilter?.addEventListener("change",renderLibrary);
librarySearch?.addEventListener("input",renderLibrary);
difficultyFilter?.addEventListener("change",renderLibrary);
favoritesOnly?.addEventListener("change",renderLibrary);
librarySort?.addEventListener("change",renderLibrary);
document.querySelector("#reset-progress").addEventListener("click", () => {
  if(!window.confirm("Clear your saved quiz progress and spaced-review schedule? Your custom questions, Mistake Notebook, and separate Exam History archive will remain.")) return;
  progress={answered:0,correct:0,results:{}}; saveProgress(); reviewSchedule={}; saveReviewSchedule(); reviewQueue=null; reviewQueuePosition=0; currentIndex=0; renderQuestion(); renderLibrary(); renderReviewTools();
});

populateSubjectFilter(false);
updateStats();
renderQuestion();
initialQuestionRenderDone = true;
renderLibrary();
renderReviewTools();
renderMistakeNotebook();
renderExamHistory();


// Free web problem finder: opens search-engine results and helps prepare pasted problems.
const finderSubject = document.querySelector("#finder-subject");
const finderTopic = document.querySelector("#finder-topic");
const finderProblem = document.querySelector("#finder-problem");
const finderSource = document.querySelector("#finder-source");
const finderStatus = document.querySelector("#finder-status");
function finderQuery() {
  const subject = finderSubject.value.trim();
  const topic = finderTopic.value.trim();
  return [subject, topic, "engineering practice problem solution"].filter(Boolean).join(" ");
}
function openFinderSearch(engine) {
  if (!finderTopic.value.trim()) {
    finderStatus.textContent = "Enter a topic or keywords first, such as 'boiler efficiency solved problems'.";
    finderTopic.focus(); return;
  }
  const query = encodeURIComponent(finderQuery());
  const url = engine === "bing" ? `https://www.bing.com/search?q=${query}` : `https://www.google.com/search?q=${query}`;
  window.open(url, "_blank", "noopener,noreferrer");
  finderStatus.textContent = `Opened ${engine === "bing" ? "Bing" : "Google"} results in a new tab. Your quiz stays open here. Open a useful source, copy the problem text, then return here and paste it below.`;
}
document.querySelector("#finder-google").addEventListener("click", () => openFinderSearch("google"));
document.querySelector("#finder-bing").addEventListener("click", () => openFinderSearch("bing"));
document.querySelector("#finder-copy").addEventListener("click", async () => {
  const text = finderProblem.value.trim();
  if (!text) { finderStatus.textContent = "Paste a problem first."; finderProblem.focus(); return; }
  try {
    await navigator.clipboard.writeText(text);
    finderStatus.textContent = "Problem text copied to clipboard.";
  } catch {
    finderProblem.focus(); finderProblem.select();
    finderStatus.textContent = "Clipboard access was blocked. The problem text is selected; press Ctrl+C to copy it.";
  }
});
const inboxStorageKey = "engineeringReviewProblemInboxV1";
let problemInbox = [];
try { problemInbox = JSON.parse(localStorage.getItem(inboxStorageKey) || "[]"); if (!Array.isArray(problemInbox)) problemInbox = []; } catch { problemInbox = []; }
const inboxList = document.querySelector("#problem-inbox-list");
const inboxCount = document.querySelector("#inbox-count");
function saveInbox() { localStorage.setItem(inboxStorageKey, JSON.stringify(problemInbox)); renderInbox(); }
function suggestTopic(problem, fallback = "Web-sourced problem") {
  const text = (problem || "").toLowerCase();
  const rules = [
    [/boiler|steam generation|feedwater|fuel consumption|heating value/, "Boiler Efficiency"],
    [/hydroelectric|net head|tailwater|water turbine|hydraulic power/, "Hydraulic / Hydroelectric Power"],
    [/heat transfer|nusselt|convection|conduction|lumped capacitance|biot number/, "Heat Transfer"],
    [/refrigeration|cop|coefficient of performance|refrigerant/, "Refrigeration"],
    [/diesel engine|diesel power|fuel rate|brake power/, "Diesel Power Plant"],
    [/projectile|range of projectile|initial velocity/, "Projectile Motion"],
    [/friction|ladder|beam|reaction force|free-body/, "Engineering Mechanics"],
    [/present worth|annuity|effective interest|nominal rate/, "Engineering Economics"]
  ];
  return rules.find(([pattern]) => pattern.test(text))?.[1] || fallback;
}
function renderInbox() {
  inboxCount.textContent = `${problemInbox.length} saved`;
  inboxList.replaceChildren();
  if (!problemInbox.length) {
    const empty = document.createElement("p"); empty.className = "muted tiny"; empty.textContent = "Your inbox is empty. Search for a problem, paste it above, then click Save to Problem Inbox."; inboxList.append(empty); return;
  }
  problemInbox.forEach((item, index) => {
    const card = document.createElement("article"); card.className = "inbox-item";
    const main = document.createElement("div"); main.className = "inbox-item-main";
    const title = document.createElement("p"); title.className = "inbox-item-title"; title.textContent = `${item.subject || "Engineering"} · ${item.topic || "Saved problem"}`;
    const preview = document.createElement("p"); preview.className = "inbox-item-preview"; preview.textContent = item.problem.length > 240 ? item.problem.slice(0, 240) + "…" : item.problem;
    main.append(title, preview);
    if (item.source) { const link = document.createElement("a"); link.href = item.source; link.target = "_blank"; link.rel = "noopener noreferrer"; link.textContent = "Open original source ↗"; main.append(link); }
    const actions = document.createElement("div"); actions.className = "inbox-item-actions";
    const prepare = document.createElement("button"); prepare.type = "button"; prepare.className = "button button-primary"; prepare.textContent = "Prepare";
    prepare.addEventListener("click", () => {
      finderSubject.value = item.subject || "Engineering"; finderTopic.value = item.topic || ""; finderProblem.value = item.problem || ""; finderSource.value = item.source || "";
      openAddQuestion(); setFormValue("subject", finderSubject.value); setFormValue("category", finderTopic.value || suggestTopic(item.problem)); setFormValue("prompt", finderProblem.value); setFormValue("source", finderSource.value);
      finderStatus.textContent = "Inbox problem loaded into the question form. Complete the answer choices and worked solution before saving.";
    });
    const remove = document.createElement("button"); remove.type = "button"; remove.className = "button button-secondary"; remove.textContent = "Remove";
    remove.addEventListener("click", () => { problemInbox.splice(index, 1); saveInbox(); });
    actions.append(prepare, remove); card.append(main, actions); inboxList.append(card);
  });
}
document.querySelector("#finder-save-inbox").addEventListener("click", () => {
  const problem = finderProblem.value.trim();
  if (!problem) { finderStatus.textContent = "Paste a problem first, then save it to your inbox."; finderProblem.focus(); return; }
  problemInbox.unshift({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, subject: finderSubject.value.trim() || "Engineering", topic: finderTopic.value.trim() || suggestTopic(problem, "Saved problem"), problem, source: finderSource.value.trim(), savedAt: new Date().toISOString() });
  saveInbox(); finderStatus.textContent = "Problem saved to your Problem Inbox on this device. You can keep searching and save more.";
});
renderInbox();

document.querySelector("#finder-prepare").addEventListener("click", () => {
  const problem = finderProblem.value.trim();
  if (!problem) { finderStatus.textContent = "Paste the problem text first."; finderProblem.focus(); return; }
  openAddQuestion();
  setFormValue("subject", finderSubject.value.trim() || "Engineering");
  setFormValue("category", finderTopic.value.trim() || suggestTopic(problem));
  setFormValue("prompt", problem);
  setFormValue("source", finderSource.value.trim());
  finderStatus.textContent = "The problem was placed in the question form. Complete the answer choices, correct answer, and worked solution, then save it.";
});


// Backup and restore: exports/imports user data only; built-in starter questions stay in code.
const backupStatus = document.querySelector("#backup-status");
const backupFileInput = document.querySelector("#backup-file");
function currentBackupData() {
  const custom = questions.filter(q => !q.builtIn);
  return {
    app: "Engineering Review Quiz",
    formatVersion: 1,
    exportedAt: new Date().toISOString(),
    customQuestions: custom,
    progress,
    reviewSchedule,
    problemInbox,
    mistakeNotebook,
    examHistory
  };
}
document.querySelector("#export-backup").addEventListener("click", () => {
  try {
    const data = currentBackupData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const date = new Date().toISOString().slice(0, 10);
    link.href = url;
    link.download = `engineering-review-quiz-backup-${date}.json`;
    document.body.append(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    backupStatus.textContent = `Backup downloaded: ${data.customQuestions.length} custom question(s), quiz progress, review schedule, ${Object.keys(data.mistakeNotebook || {}).length} mistake-notebook entr${Object.keys(data.mistakeNotebook || {}).length === 1 ? "y" : "ies"}, ${Array.isArray(data.examHistory) ? data.examHistory.length : 0} exam-history attempt(s), and ${data.problemInbox.length} inbox item(s). Store the JSON file safely.`;
  } catch (error) {
    backupStatus.textContent = "Could not create the backup. Please try again.";
  }
});
document.querySelector("#choose-backup").addEventListener("click", () => backupFileInput.click());
backupFileInput.addEventListener("change", async () => {
  const file = backupFileInput.files && backupFileInput.files[0];
  if (!file) return;
  try {
    const imported = JSON.parse(await file.text());
    const validQuestion = q => q && typeof q === "object" && typeof q.id === "string" && typeof q.subject === "string" && typeof q.category === "string" && typeof q.prompt === "string" && Array.isArray(q.options) && q.options.length === 4 && ["A", "B", "C", "D"].includes(q.answer) && !q.builtIn;
    const validProgress = x => x && typeof x === "object" && Number.isFinite(x.answered) && Number.isFinite(x.correct) && x.answered >= 0 && x.correct >= 0 && x.correct <= x.answered && x.results && typeof x.results === "object";
    const validMistakeNotebook = !("mistakeNotebook" in (imported || {})) || (imported.mistakeNotebook && typeof imported.mistakeNotebook === "object" && !Array.isArray(imported.mistakeNotebook));
    const validExamHistory = !("examHistory" in (imported || {})) || Array.isArray(imported.examHistory);
    if (imported?.app !== "Engineering Review Quiz" || imported?.formatVersion !== 1 || !Array.isArray(imported.customQuestions) || !imported.customQuestions.every(validQuestion) || !validProgress(imported.progress) || !Array.isArray(imported.problemInbox) || !validMistakeNotebook || !validExamHistory) {
      throw new Error("This file does not look like a valid Engineering Review Quiz backup.");
    }
    if (!window.confirm(`Restore this backup from ${file.name}? This replaces the current custom questions, quiz progress, and Problem Inbox. If the backup contains a Mistake Notebook or Exam History, those will also be replaced; older backups without either field preserve the current saved data. Built-in questions remain unchanged.`)) return;
    localStorage.setItem(QUESTIONS_KEY, JSON.stringify(imported.customQuestions));
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(imported.progress));
    reviewSchedule = imported.reviewSchedule && typeof imported.reviewSchedule === "object" && !Array.isArray(imported.reviewSchedule) ? imported.reviewSchedule : {};
    saveReviewSchedule();
    localStorage.setItem(inboxStorageKey, JSON.stringify(imported.problemInbox));
    // Older v1 backups do not contain this field; preserve the current notebook when restoring them.
    if ("mistakeNotebook" in imported) { mistakeNotebook = normalizeMistakeNotebook(imported.mistakeNotebook); saveMistakeNotebook(); }
    if ("examHistory" in imported) { examHistory = normalizeExamHistory(imported.examHistory); saveExamHistory(); }
    questions = [...starterQuestions, ...imported.customQuestions];
    progress = imported.progress;
    problemInbox = imported.problemInbox;
    currentIndex = 0;
    selectedAnswer = "";
    submitted = false;
    populateSubjectFilter(false);
    renderLibrary();
    renderQuestion();
    renderReviewTools();
    renderMistakeNotebook();
    renderExamHistory();
    renderQuestionBankAudit?.();
    updateStats();
renderWeaknessTracker();
    renderInbox();
    backupStatus.textContent = `Restored successfully from ${file.name}: ${imported.customQuestions.length} custom question(s), ${imported.problemInbox.length} inbox item(s), and ${Object.keys(mistakeNotebook).length} mistake-notebook entr${Object.keys(mistakeNotebook).length === 1 ? "y" : "ies"}.`;
  } catch (error) {
    backupStatus.textContent = error instanceof SyntaxError ? "That file is not valid JSON. Choose a backup exported by this app." : (error.message || "Restore failed. Your current data has not been changed.");
  } finally {
    backupFileInput.value = "";
  }
});


document.querySelector("#practice-weakest")?.addEventListener("click",()=>{
  const attempts=Object.entries(progress.results||{}).map(([id,result])=>({q:questions.find(item=>item.id===id),result})).filter(x=>x.q);
  const groups=new Map();
  attempts.forEach(({q,result})=>{const topic=String(q.category||q.subject||"Other");if(!groups.has(topic))groups.set(topic,{total:0,correct:0,ids:[]});const g=groups.get(topic);g.total++;if(result)g.correct++;g.ids.push(q.id);});
  const weakest=[...groups.entries()].map(([topic,g])=>({topic,...g,accuracy:g.correct/g.total})).sort((a,b)=>a.accuracy-b.accuracy||b.total-a.total)[0];
  const status=document.querySelector("#weakness-status");
  if(!weakest){if(status)status.textContent="Answer at least one question first; then the tracker can identify a topic to practice.";return;}
  const target=questions.findIndex(q=>String(q.category||q.subject||"Other")===weakest.topic);
  if(target>=0){currentIndex=target;selectedAnswer="";submitted=false;renderQuestion();renderLibrary();const questionPanel=document.querySelector(".quiz-panel")||document.querySelector("#question-text");questionPanel?.scrollIntoView({behavior:"smooth",block:"start"});if(status)status.textContent=`Opened a question from your weakest topic: ${weakest.topic}. Scroll to the question and answer it below.`;}else if(status){status.textContent=`No available question was found for ${weakest.topic}. Check that your question bank still contains questions in this topic.`;}
});
document.querySelector("#reset-topic-stats")?.addEventListener("click",()=>{
  if(!window.confirm("Reset all quiz answer history and topic statistics? Your questions, Problem Inbox, and Mistake Notebook will remain.")) return;
  progress={answered:0,correct:0,results:{}};
  saveProgress();renderQuestion();renderWeaknessTracker();
  const status=document.querySelector("#weakness-status");if(status)status.textContent="Quiz history and topic statistics were reset.";
});

// v2.9.35 — Phase 3: Exam History & Performance Trends.
function formatHistoryDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Unknown date" : date.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}
function formatHistoryDuration(seconds) {
  const s = Math.max(0, Math.floor(Number(seconds) || 0));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}` : `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}
function historyScore(attempt) {
  return attempt && Number(attempt.scoreable) > 0 ? Math.round(Number(attempt.correct) / Number(attempt.scoreable) * 100) : null;
}
function makeHistoryElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}
function renderExamHistoryChart(scoredAttempts) {
  const host = document.querySelector("#exam-history-chart");
  if (!host) return;
  host.replaceChildren();
  const attempts = scoredAttempts.slice(0, 10).reverse();
  if (!attempts.length) {
    const empty = makeHistoryElement("p", "exam-history-empty-chart", "Complete a scored exam to see your score trend.");
    host.append(empty);
    return;
  }
  const ns = "http://www.w3.org/2000/svg";
  const width = 760, height = 242, left = 44, right = 16, top = 22, bottom = 40;
  const plotWidth = width - left - right, plotHeight = height - top - bottom;
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", "Scores for the latest ten scored exams, oldest to newest");
  const title = document.createElementNS(ns, "title"); title.textContent = "Latest exam score trend"; svg.append(title);
  const desc = document.createElementNS(ns, "desc"); desc.textContent = attempts.map((a, i) => `Attempt ${i + 1}: ${historyScore(a)} percent`).join("; "); svg.append(desc);
  [0, 50, 100].forEach(value => {
    const y = top + plotHeight * (1 - value / 100);
    const line = document.createElementNS(ns, "line");
    line.setAttribute("x1", left); line.setAttribute("x2", width - right); line.setAttribute("y1", y); line.setAttribute("y2", y);
    line.setAttribute("class", "history-grid-line"); svg.append(line);
    const label = document.createElementNS(ns, "text"); label.setAttribute("x", left - 9); label.setAttribute("y", y + 4); label.setAttribute("text-anchor", "end"); label.setAttribute("class", "history-axis-label"); label.textContent = `${value}%`; svg.append(label);
  });
  const step = plotWidth / attempts.length;
  const barWidth = Math.min(42, step * 0.62);
  attempts.forEach((attempt, index) => {
    const score = historyScore(attempt);
    const x = left + step * index + (step - barWidth) / 2;
    const bar = document.createElementNS(ns, "rect");
    const plotValue = score === null ? 0 : score;
    const barHeight = plotHeight * plotValue / 100;
    bar.setAttribute("x", x); bar.setAttribute("y", top + plotHeight - barHeight); bar.setAttribute("width", barWidth); bar.setAttribute("height", Math.max(score === null ? 2 : 1, barHeight));
    bar.setAttribute("rx", "5"); bar.setAttribute("class", score === null ? "history-bar history-bar-unscored" : "history-bar");
    const labelDate = new Date(attempt.completedAt);
    const datePart = Number.isNaN(labelDate.getTime()) ? "Unknown date" : labelDate.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    const barTitle = document.createElementNS(ns, "title"); barTitle.textContent = `${datePart}: ${score === null ? "No verified answers to score" : `${score}% (${attempt.correct}/${attempt.scoreable})`}`; bar.append(barTitle); svg.append(bar);
    const valueLabel = document.createElementNS(ns, "text"); valueLabel.setAttribute("x", x + barWidth / 2); valueLabel.setAttribute("y", score === null ? top + plotHeight - 8 : Math.max(top + 12, top + plotHeight - barHeight - 7)); valueLabel.setAttribute("text-anchor", "middle"); valueLabel.setAttribute("class", "history-value-label"); valueLabel.textContent = score === null ? "—" : `${score}`; svg.append(valueLabel);
    const dateLabel = document.createElementNS(ns, "text"); dateLabel.setAttribute("x", x + barWidth / 2); dateLabel.setAttribute("y", height - 14); dateLabel.setAttribute("text-anchor", "middle"); dateLabel.setAttribute("class", "history-axis-label"); dateLabel.textContent = `${index + 1}`; svg.append(dateLabel);
  });
  host.append(svg);
}
function renderExamHistory() {
  const list = document.querySelector("#exam-history-list");
  if (!list) return;
  const total = document.querySelector("#history-total-exams");
  const latest = document.querySelector("#history-latest-score");
  const latestMeta = document.querySelector("#history-latest-meta");
  const recentAverage = document.querySelector("#history-recent-average");
  const best = document.querySelector("#history-best-score");
  const countPill = document.querySelector("#exam-history-count-pill");
  const clearButton = document.querySelector("#exam-history-clear");
  const status = document.querySelector("#exam-history-status");
  const search = (document.querySelector("#exam-history-search")?.value || "").trim().toLowerCase();
  const scored = examHistory.filter(item => historyScore(item) !== null);
  const latestScored = scored[0];
  const latestScore = latestScored ? historyScore(latestScored) : null;
  const recentScores = scored.slice(0, 5).map(historyScore);
  const recentAvg = recentScores.length ? Math.round(recentScores.reduce((sum, value) => sum + value, 0) / recentScores.length) : null;
  const bestScore = scored.length ? Math.max(...scored.map(historyScore)) : null;
  if (total) total.textContent = String(examHistory.length);
  if (latest) latest.textContent = latestScore === null ? "—" : `${latestScore}%`;
  if (latestMeta) latestMeta.textContent = latestScored ? `${latestScored.correct}/${latestScored.scoreable} scored · ${formatHistoryDate(latestScored.completedAt)}` : "No scored exam yet";
  if (recentAverage) recentAverage.textContent = recentAvg === null ? "—" : `${recentAvg}%`;
  if (best) best.textContent = bestScore === null ? "—" : `${bestScore}%`;
  if (countPill) countPill.textContent = `${examHistory.length} saved exam${examHistory.length === 1 ? "" : "s"}`;
  if (clearButton) clearButton.disabled = !examHistory.length;
  const change = document.querySelector("#history-change-indicator");
  const caption = document.querySelector("#history-trend-caption");
  if (change) {
    const previousScored = scored[1];
    if (!latestScored) { change.textContent = "No scored attempts"; change.className = "exam-history-change"; }
    else if (!previousScored) { change.textContent = "First scored attempt"; change.className = "exam-history-change"; }
    else {
      const diff = historyScore(latestScored) - historyScore(previousScored);
      change.textContent = `${diff > 0 ? "+" : ""}${diff} percentage point${Math.abs(diff) === 1 ? "" : "s"} vs previous`;
      change.className = `exam-history-change ${diff > 0 ? "is-up" : diff < 0 ? "is-down" : "is-flat"}`;
    }
  }
  if (caption) caption.textContent = scored.length ? `Latest ${Math.min(10, scored.length)} scored attempt${scored.length === 1 ? "" : "s"}, oldest to newest. Labels on bars show the score percentage.` : "Your latest ten scored attempts will appear here.";
  renderExamHistoryChart(scored);
  list.replaceChildren();
  const visible = examHistory.filter(item => {
    if (!search) return true;
    const searchable = [item.completedAt, ...(item.breakdown || []).flatMap(row => [row.main, row.branch]), ...(item.questionResults || []).flatMap(row => [row.prompt, row.category, row.main, row.branch])].join(" ").toLowerCase();
    return searchable.includes(search);
  });
  if (!examHistory.length) {
    const empty = makeHistoryElement("div", "exam-history-empty");
    empty.append(makeHistoryElement("h3", "", "No exam attempts saved yet"));
    empty.append(makeHistoryElement("p", "", "Complete a timed exam in Progress → Exam Simulation. Your results will appear here so you can compare attempts over time."));
    list.append(empty);
    if (status) status.textContent = "Completed exams will be saved here automatically. The latest 30 attempts are retained.";
    return;
  }
  if (!visible.length) {
    list.append(makeHistoryElement("div", "exam-history-empty", "No saved exam attempts match that search."));
    if (status) status.textContent = `No results for “${search}”.`;
    return;
  }
  if (status) status.textContent = `Showing ${visible.length} of ${examHistory.length} saved exam attempt${examHistory.length === 1 ? "" : "s"}.`;
  visible.forEach((attempt, index) => {
    const article = makeHistoryElement("article", "exam-history-card");
    const heading = makeHistoryElement("div", "exam-history-card-heading");
    const headingCopy = makeHistoryElement("div", "exam-history-card-title");
    headingCopy.append(makeHistoryElement("h3", "", formatHistoryDate(attempt.completedAt)));
    headingCopy.append(makeHistoryElement("p", "muted small", `Attempt ${examHistory.indexOf(attempt) + 1} · ${attempt.timedOut ? "Automatically submitted (time expired)" : "Submitted by student"}`));
    const scoreTag = makeHistoryElement("div", `exam-history-score-tag${historyScore(attempt) === null ? " is-unscored" : ""}`, historyScore(attempt) === null ? "Unscored" : `${historyScore(attempt)}%`);
    heading.append(headingCopy, scoreTag);
    const scoreLine = historyScore(attempt) === null ? "No verified answers to score" : `Score: ${attempt.correct}/${attempt.scoreable} verified questions`;
    const metrics = makeHistoryElement("p", "exam-history-metrics", `${scoreLine} · Answered ${attempt.answered}/${attempt.totalQuestions} · Unanswered ${attempt.unanswered} · Time used ${formatHistoryDuration(attempt.timeUsedSeconds)} / ${formatHistoryDuration(attempt.timeLimitSeconds)}`);
    const details = makeHistoryElement("details", "exam-history-details");
    const summary = makeHistoryElement("summary", "", "View subject, topic, and question breakdown");
    details.append(summary);
    const breakdownHeading = makeHistoryElement("h4", "", "Subject and topic performance"); details.append(breakdownHeading);
    if (attempt.breakdown?.length) {
      const breakdownTable = makeHistoryElement("div", "exam-history-breakdown");
      attempt.breakdown.forEach(row => {
        const line = makeHistoryElement("div", "exam-history-breakdown-row");
        const label = makeHistoryElement("div", "exam-history-breakdown-label");
        label.append(makeHistoryElement("strong", "", row.branch || row.main));
        label.append(makeHistoryElement("small", "muted", row.main));
        const value = row.scoreable ? `${row.correct}/${row.scoreable} (${Math.round(row.correct / row.scoreable * 100)}%)` : `No verified answers · ${row.totalQuestions} question${row.totalQuestions === 1 ? "" : "s"}`;
        const right = makeHistoryElement("div", "exam-history-breakdown-value", value);
        const answerMeta = makeHistoryElement("small", "muted", `Answered ${row.answered}/${row.totalQuestions} · ${row.unanswered} unanswered`);
        right.append(answerMeta); line.append(label, right); breakdownTable.append(line);
      });
      details.append(breakdownTable);
    } else details.append(makeHistoryElement("p", "muted small", "No topic breakdown was saved for this attempt."));
    const qHeading = makeHistoryElement("h4", "", "Question-by-question results"); details.append(qHeading);
    const qResults = Array.isArray(attempt.questionResults) ? attempt.questionResults : [];
    if (qResults.length) {
      const qList = makeHistoryElement("ol", "exam-history-question-list");
      qResults.forEach((row, qIndex) => {
        const li = makeHistoryElement("li", row.scoreable ? (row.correct ? "history-question-correct" : "history-question-wrong") : "history-question-unscored");
        const state = row.scoreable ? (row.correct ? "Correct" : row.answered ? "Incorrect" : "Unanswered") : "Not scored";
        const title = makeHistoryElement("strong", "", `${qIndex + 1}. ${state} · ${row.branch || row.category || "Question"}`);
        li.append(title);
        if (row.prompt) li.append(makeHistoryElement("p", "", row.prompt));
        const answerLine = row.scoreable ? `Your answer: ${row.selectedAnswer || "No answer"}${row.selectedText ? ` — ${row.selectedText}` : ""} · Correct: ${row.correctAnswer}${row.correctText ? ` — ${row.correctText}` : ""}` : `Your answer: ${row.selectedAnswer || "No answer"} · This answer key was not verified and was excluded from scoring.`;
        li.append(makeHistoryElement("small", "", answerLine));
        qList.append(li);
      });
      details.append(qList);
    } else details.append(makeHistoryElement("p", "muted small", "This is a legacy attempt without question-level details."));
    article.append(heading, metrics, details);
    list.append(article);
  });
}
document.querySelector("#exam-history-search")?.addEventListener("input", renderExamHistory);
document.querySelector("#exam-history-clear")?.addEventListener("click", () => {
  if (!examHistory.length || !window.confirm("Delete all saved exam-history attempts? This does not change question-level progress or your Mistake Notebook.")) return;
  examHistory = [];
  const saved = saveExamHistory();
  renderExamHistory();
  const status = document.querySelector("#exam-history-status");
  if (status) status.textContent = saved ? "Exam history cleared. Your quiz progress and Mistake Notebook were not changed." : "History was cleared in memory, but browser storage could not be updated.";
});

// v2.7 Exam Simulation — results update the question-level history used by the Weakness Tracker.
const examSubjectOptions=document.querySelector("#exam-subject-options"), examCount=document.querySelector("#exam-count"), examMinutes=document.querySelector("#exam-minutes");
const startExamButton=document.querySelector("#start-exam"), submitExamButton=document.querySelector("#submit-exam"), examStatus=document.querySelector("#exam-status"), exitExamButton=document.querySelector("#exit-exam");
const examWorkspace=document.querySelector("#exam-workspace"), examClock=document.querySelector("#exam-clock"), examClockBox=examClock?.parentElement;
const examProgressFill=document.querySelector("#exam-progress-fill"), examQuestionsEl=document.querySelector("#exam-questions"), examResults=document.querySelector("#exam-results");
let examSession=null, examTimerId=null;
const EXAM_MAIN_SUBJECTS=["PIPE","Power Plant Engineering","Industrial Plant Engineering","Mathematics / MESL","Machine Design"];
function selectedExamSubjects(){return [...(examSubjectOptions?.querySelectorAll('input[data-kind="branch"]:checked')||[])].map(el=>({main:el.dataset.main,branch:el.value}));}
function syncExamParent(main){const parent=examSubjectOptions?.querySelector(`input[data-kind="main"][value="${CSS.escape(main)}"]`);const children=[...(examSubjectOptions?.querySelectorAll(`input[data-kind="branch"][data-main="${CSS.escape(main)}"]`)||[])];if(!parent||!children.length)return;const count=children.filter(x=>x.checked).length;parent.checked=count===children.length;parent.indeterminate=count>0&&count<children.length;}
function populateExamSubjects(){if(!examSubjectOptions)return;examSubjectOptions.replaceChildren();EXAM_MAIN_SUBJECTS.forEach((main,index)=>{const group=document.createElement("section");group.className="exam-tree-group";const heading=document.createElement("label");heading.className="exam-subject-option exam-main-option";const parent=document.createElement("input");parent.type="checkbox";parent.dataset.kind="main";parent.value=main;parent.checked=true;parent.id=`exam-subject-${index}`;const title=document.createElement("strong");title.textContent=main;heading.append(parent,title);group.append(heading);const branches=[...new Set(questions.filter(q=>subjectTree(q).main===main).map(q=>subjectTree(q).branch))].sort((a,b)=>a.localeCompare(b));const branchList=document.createElement("div");branchList.className="exam-branch-options";branches.forEach((branch,branchIndex)=>{const label=document.createElement("label");label.className="exam-subject-option exam-branch-option";const input=document.createElement("input");input.type="checkbox";input.dataset.kind="branch";input.dataset.main=main;input.value=branch;input.checked=true;input.id=`exam-branch-${index}-${branchIndex}`;const text=document.createElement("span");text.textContent=branch;label.append(input,text);branchList.append(label);});group.append(branchList);examSubjectOptions.append(group);parent.addEventListener("change",()=>{branchList.querySelectorAll('input[data-kind="branch"]').forEach(input=>input.checked=parent.checked);parent.indeterminate=false;});branchList.addEventListener("change",()=>syncExamParent(main));});}
document.querySelector("#exam-select-all-subjects")?.addEventListener("click",()=>{examSubjectOptions?.querySelectorAll("input[type=checkbox]").forEach(input=>{input.checked=true;input.indeterminate=false;});});
document.querySelector("#exam-clear-subjects")?.addEventListener("click",()=>{examSubjectOptions?.querySelectorAll("input[type=checkbox]").forEach(input=>{input.checked=false;input.indeterminate=false;});});
function formatExamTime(seconds){const s=Math.max(0,seconds|0);return `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;}
function stopExamTimer(){if(examTimerId!==null){clearInterval(examTimerId);examTimerId=null;}}
function updateExamClock(){if(!examSession||examSession.finished)return;const remaining=Math.max(0,Math.ceil((examSession.deadline-Date.now())/1000));examClock.textContent=formatExamTime(remaining);examClockBox?.classList.toggle("warning",remaining<=60);examProgressFill.style.width=`${Math.max(0,Math.min(100,(1-remaining/examSession.durationSeconds)*100))}%`;if(remaining<=0)finishExam(true);}
function startExam(){stopExamTimer();const chosenSubjects=selectedExamSubjects();if(!chosenSubjects.length){examStatus.textContent="Choose at least one subject before starting the exam.";return;}let pool=questions.filter(q=>chosenSubjects.some(selection=>selection.main===subjectTree(q).main&&selection.branch===subjectTree(q).branch));if(!pool.length){examStatus.textContent="No questions are currently assigned to the selected subjects.";return;}pool=pool.map(q=>({q,sort:Math.random()})).sort((a,b)=>a.sort-b.sort).map(x=>x.q);const requested=examCount.value==="all"?pool.length:Number(examCount.value);pool=pool.slice(0,Math.min(requested,pool.length));const durationSeconds=Number(examMinutes.value)*60;const startedAt = Date.now();examSession={items:pool,answers:{},durationSeconds,startedAt,deadline:startedAt+durationSeconds*1000,finished:false};document.body.classList.add("exam-focus");if(exitExamButton)exitExamButton.hidden=false;examResults.hidden=true;examWorkspace.hidden=false;submitExamButton.hidden=false;startExamButton.textContent="Restart exam";const verifiedCount=pool.filter(q=>q.answerVerified!==false).length;examStatus.textContent=`Exam in progress · ${pool.length} question(s) · Topics: ${chosenSubjects.map(selection=>`${selection.main} / ${selection.branch}`).join(", ")} · ${verifiedCount} scoreable · answers are hidden until submission.`;renderExamQuestions();updateExamClock();examTimerId=setInterval(updateExamClock,250);}
function renderExamQuestions(){examQuestionsEl.replaceChildren();examSession.items.forEach((q,index)=>{const card=document.createElement("section");card.className="exam-question";const title=document.createElement("h3");title.textContent=`Question ${index+1} · ${q.subject} · ${q.difficulty}`;const prompt=document.createElement("p");prompt.textContent=q.prompt;const opts=document.createElement("div");opts.className="exam-options";q.options.forEach(option=>{const label=document.createElement("label");label.className="exam-option";const input=document.createElement("input");input.type="radio";input.name=`exam-answer-${index}`;input.value=option.value;input.checked=examSession.answers[q.id]===option.value;input.addEventListener("change",()=>{examSession.answers[q.id]=option.value;});const text=document.createElement("span");text.textContent=`${option.value}. ${option.text}`;label.append(input,text);opts.append(label);});card.append(title,prompt,opts);examQuestionsEl.append(card);});}
function finishExam(timeExpired=false){if(!examSession||examSession.finished)return;examSession.finished=true;stopExamTimer();const items=examSession.items;let correct=0,answered=0,scoreable=0,unverified=0,notebookChanged=false;items.forEach(q=>{const answer=examSession.answers[q.id];if(answer)answered++;if(q.answerVerified===false){unverified++;return;}scoreable++;const isCorrect=answer===q.answer;if(isCorrect)correct++;else if(answer){recordMistake(q,answer,"exam",false);notebookChanged=true;}const previous=progress.results[q.id];if(previous===undefined){progress.answered++;if(isCorrect)progress.correct++;}else{if(previous===true&&!isCorrect)progress.correct--;if(previous===false&&isCorrect)progress.correct++;}progress.results[q.id]=isCorrect;});if(answered)recordDailyQuestionActivity(answered);saveProgress();if(notebookChanged){const notebookSaved=saveMistakeNotebook();renderMistakeNotebook();if(!notebookSaved){const status=document.querySelector("#mistake-status");if(status)status.textContent="Exam mistakes were detected, but the browser could not save the notebook. Check browser storage.";}}
  const finishedAt = Date.now();
  const timeUsedSeconds = Math.min(examSession.durationSeconds, Math.max(0, Math.floor((finishedAt - (examSession.startedAt || finishedAt)) / 1000)));
  const subjectTotals = new Map();
  const questionResults = items.map(q => {
    const selected = examSession.answers[q.id] || "";
    const verified = q.answerVerified !== false;
    const correctNow = verified && selected === q.answer;
    const tree = subjectTree(q);
    const main = tree.main || q.subject || "Uncategorized";
    const branch = tree.branch || q.category || "Uncategorized";
    const key = `${main}\u0000${branch}`;
    if (!subjectTotals.has(key)) subjectTotals.set(key, {main, branch, totalQuestions:0, scoreable:0, correct:0, answered:0, unanswered:0});
    const total = subjectTotals.get(key);
    total.totalQuestions++;
    if (verified) { total.scoreable++; if (correctNow) total.correct++; }
    if (selected) total.answered++; else total.unanswered++;
    const selectedOption = (q.options || []).find(option => option.value === selected);
    const correctOption = (q.options || []).find(option => option.value === q.answer);
    return {questionId:String(q.id), main, branch, category:String(q.category || ""), prompt:String(q.prompt || "").slice(0,300), selectedAnswer:selected, selectedText:String(selectedOption?.text || "").slice(0,160), correctAnswer:verified ? String(q.answer || "") : "", correctText:String(correctOption?.text || "").slice(0,160), scoreable:verified, correct:correctNow, answered:Boolean(selected)};
  });
  const historyEntry = {id:`exam-${finishedAt}-${Math.random().toString(36).slice(2,8)}`,completedAt:new Date(finishedAt).toISOString(),timeLimitSeconds:examSession.durationSeconds,timeUsedSeconds,timedOut:Boolean(timeExpired),totalQuestions:items.length,answered,unanswered:items.length-answered,scoreable,correct,percent:scoreable ? Math.round(correct/scoreable*100) : null,breakdown:[...subjectTotals.values()].sort((a,b)=>a.main.localeCompare(b.main)||a.branch.localeCompare(b.branch)),questionResults};
  examHistory = normalizeExamHistory([historyEntry, ...examHistory]);
  const historySaved = saveExamHistory();
  renderExamHistory();
  if (!historySaved) { const status = document.querySelector("#exam-history-status"); if (status) status.textContent = "This exam result is visible now but browser storage could not save it. Export a backup or check browser storage."; }
  if(typeof renderWeaknessTracker==="function")renderWeaknessTracker();renderReviewTools();examWorkspace.hidden=true;submitExamButton.hidden=true;examResults.hidden=false;examResults.replaceChildren();const heading=document.createElement("h3");heading.textContent=timeExpired?"Time is up — exam submitted":"Exam results";const score=document.createElement("div");score.className="exam-result-score";score.textContent=scoreable?`${correct} / ${scoreable} scored questions · ${Math.round(correct/scoreable*100)}%`:`No verified answers to score`;const detail=document.createElement("p");detail.className="muted small";detail.textContent=`Answered: ${answered}/${items.length} · Unanswered: ${items.length-answered}${timeExpired?" · Automatically submitted when time expired.":""}`;examResults.append(heading,score,detail);items.forEach((q,index)=>{const isVerified=q.answerVerified!==false;const selected=examSession.answers[q.id];const row=document.createElement("div");row.className="exam-review-item";const title=document.createElement("strong");title.textContent=isVerified?`${index+1}. ${q.category} — ${selected===q.answer?"Correct":selected?"Incorrect":"Not answered"}`:`${index+1}. ${q.category} — Not scored (answer unverified)`;const chosen=document.createElement("p");chosen.className=isVerified?(selected===q.answer?"right":"wrong"):"muted small";chosen.textContent=isVerified?`Your answer: ${selected||"No answer"} · Correct answer: ${q.answer}. ${q.options.find(o=>o.value===q.answer)?.text||""}`:`Your answer: ${selected||"No answer"}.`;const solution=document.createElement("p");solution.className="math-line";const solutionText=`Formula: ${q.formula}\nWhy this formula applies: ${getFormulaReason(q)}\nDerivation / rearrangement: ${getDerivationNote(q)}\nSubstitution: ${q.substitution}\nCalculation: ${(q.calculation||[]).join("\n")}\nFinal answer: ${q.finalAnswer}\nUnit check: ${q.unitCheck || "Check that units cancel and match the requested quantity."}\nKey concept: ${q.concept}\nExam shortcut: ${q.shortcutFormula || q.formula} — ${q.shortcut || "Not recorded."}\nCommon exam traps: ${getCommonExamTraps(q).join("\n")}`;if(typeof window.renderMathInto === "function")window.renderMathInto(solution,solutionText);else solution.textContent=solutionText;row.append(title,chosen,solution);if(q.sourceFile || q.source){const link=document.createElement("a");link.href=q.sourceFile || q.source;link.target="_blank";link.rel="noopener noreferrer";link.textContent=q.sourceExtractedPdfPage?`Open extracted source PDF (page ${q.sourceExtractedPdfPage})`:"Original source";row.append(link);}examResults.append(row);});examStatus.textContent="Exam completed. Questions with answer sets were scored.";}
function exitExam(){if(examSession&&!examSession.finished&&!window.confirm("Leave this exam? Your current attempt will be abandoned."))return;stopExamTimer();examSession=null;document.body.classList.remove("exam-focus");if(exitExamButton)exitExamButton.hidden=true;examWorkspace.hidden=true;examResults.hidden=true;submitExamButton.hidden=true;startExamButton.textContent="Start exam";examStatus.textContent="Choose your settings, then start a practice exam.";examQuestionsEl.replaceChildren();}
startExamButton?.addEventListener("click",startExam);exitExamButton?.addEventListener("click",exitExam);submitExamButton?.addEventListener("click",()=>{if(window.confirm("Submit your exam now and reveal answers and solutions?"))finishExam(false);});populateExamSubjects();


// Public, read-only hooks for the optional Study Dashboard.
window.getEngineeringReviewQuestions = () => questions;
// Bulk import hook used by bulk-import.js. Expects already-validated, normalized question objects.
window.importEngineeringReviewQuestions = (list) => {
  const stamp = Date.now();
  const added = list.map((d, i) => ({
    id: `import-${stamp}-${i}-${Math.random().toString(36).slice(2,6)}`,
    builtIn: false,
    subject: d.subject, category: d.category, difficulty: d.difficulty, prompt: d.prompt,
    source: d.source, options: d.options, answer: d.answer, answerVerified: d.answerVerified,
    given: d.given, formula: d.formula, formulaReason: d.formulaReason || "", derivation: d.derivation || "", substitution: d.substitution, calculation: d.calculation,
    finalAnswer: d.finalAnswer, concept: d.concept, shortcutFormula: d.shortcutFormula, shortcut: d.shortcut, commonMistakes: Array.isArray(d.commonMistakes) ? d.commonMistakes : []
  }));
  const before = questions.length;
  questions.push(...added);
  try { saveCustomQuestions(); }
  catch { questions.length = before; throw new Error("Browser storage is full or disabled, so nothing was imported."); }
  populateSubjectFilter(false); renderLibrary(); updateStats();
  try { renderReviewTools?.(); renderWeaknessTracker?.(); renderQuestionBankAudit?.(); } catch {}
  return added.length;
};

window.openEngineeringReviewQuestion = (id) => {
  const index = questions.findIndex(q => q.id === id);
  if (index < 0) return false;
  currentIndex = index; selectedAnswer = ""; submitted = false;
  renderQuestion(); renderLibrary();
  return true;
};

// v2.9.36 — Phase 4: local, non-destructive question bank quality audit.
const QUESTION_AUDIT_TYPES = {
  duplicate: "Duplicate prompts",
  answer: "Answer key / choices",
  solution: "Worked solution",
  units: "Units",
  source: "Source / verification",
  metadata: "Question details"
};
let latestQuestionBankAudit = { scannedAt: null, questionCount: 0, issues: [] };

function auditText(value) {
  if (Array.isArray(value)) return value.map(item => String(item ?? "")).join("\n").trim();
  return value == null ? "" : String(value).trim();
}
function auditNormalize(value) {
  return auditText(value).normalize("NFKC").toLowerCase()
    .replace(/[“”‘’]/g, "'")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim().replace(/\s+/g, " ");
}
function auditContainsPlaceholder(value) {
  const text = auditText(value);
  if (!text) return false;
  return /\b(?:todo|tbd|lorem ipsum|placeholder|not provided|not available|fill in|enter here|example value|replace this|your answer here)\b|^n\/?a\.?$/i.test(text);
}
function auditHasRecognizedUnit(value) {
  const text = auditText(value);
  if (!text) return false;
  // Multi-character units are checked as words; one-letter units are only recognized
  // when attached to a numeric value, so ordinary letters in prose do not count.
  const namedUnit = /(?:%|°\s*[CFR]|\b(?:kg|mg|lbm|lbf|slug|kN|MN|kPa|MPa|GPa|Pa|bar|psia|psig|psi|atm|mmHg|mbar|kJ|MJ|J|kW|MW|W|hp|BTU|Btu|kcal|cal|kmol|mol|moles?|rpm|Hz|kWh|kW-hr|Wb|tesla|henry|ohms?|volts?|amps?|degrees?|radians?|meters?|metres?|centimeters?|centimetres?|millimeters?|millimetres?|kilometers?|kilometres?|feet|foot|inches?|miles?|furlongs?|quarts?|gallons?|gals?|tons?|seconds?|secs?|minutes?|mins?|hours?|hrs?|kelvin|celsius|fahrenheit|liters?|litres?|milliliters?|millilitres?|dimensionless|unitless|m\/s|ft\/s|km\/h|mph|rad\/s|gal\/min|ft\s*\^?3\s*\/\s*min|m\s*\^?3\s*\/\s*min|kg\/m(?:\^?3|³)|g\/cm(?:\^?3|³)|kg\/kmol|g\/mol|kJ\/kg|kJ\/kmol|W\/m(?:·)?K|Pa·s|N·m|N-m|m(?:\^?2|²)|m(?:\^?3|³)|cm(?:\^?2|²)|cm(?:\^?3|³)|ft(?:\^?2|²)|ft(?:\^?3|³))\b)/i;
  const compactUnit = /\b\d+(?:\.\d+)?\s*(?:m|cm|mm|km|ft|in|s|sec|K|V|A|N|g|kg|J|W|C|F|L)\b/i;
  return namedUnit.test(text) || compactUnit.test(text);
}
function makeQuestionAuditIssue(q, severity, type, title, finding, recommendation, relatedQuestionId = "") {
  return {
    questionId: String(q?.id || ""), builtIn: Boolean(q?.builtIn),
    subject: auditText(q?.subject) || "Uncategorized", category: auditText(q?.category) || "Uncategorized",
    prompt: auditText(q?.prompt), severity, type, typeLabel: QUESTION_AUDIT_TYPES[type] || type,
    title, finding, recommendation, relatedQuestionId: String(relatedQuestionId || "")
  };
}
function analyzeQuestionBankQuality(questionList = questions) {
  const issues = [];
  const requiredSolutionFields = [
    ["given", "Given values and units"], ["formula", "Formula"], ["substitution", "Substitution"],
    ["calculation", "Calculation steps"], ["finalAnswer", "Final answer"], ["concept", "Key concept"],
    ["shortcutFormula", "Shortcut formula"], ["shortcut", "Shortcut method"]
  ];
  const dupes = new Map();
  (Array.isArray(questionList) ? questionList : []).forEach(q => {
    const normalizedPrompt = auditNormalize(q?.prompt);
    if (normalizedPrompt) {
      if (!dupes.has(normalizedPrompt)) dupes.set(normalizedPrompt, []);
      dupes.get(normalizedPrompt).push(q);
    }
  });

  (Array.isArray(questionList) ? questionList : []).forEach(q => {
    if (!q || typeof q !== "object") return;
    const questionName = auditText(q.prompt).slice(0, 180) || `Question ${q.id || "(missing ID)"}`;
    const add = (severity, type, title, finding, recommendation, relatedId = "") => issues.push(makeQuestionAuditIssue(q, severity, type, title, finding, recommendation, relatedId));
    const prompt = auditText(q.prompt);
    const subject = auditText(q.subject);
    const category = auditText(q.category);
    const options = Array.isArray(q.options) ? q.options : [];
    const optionLabels = options.map(o => auditText(o?.value).toUpperCase());
    const expectedLabels = ["A", "B", "C", "D"];
    const optionTexts = options.map(o => auditNormalize(o?.text));

    if (!auditText(q.id)) add("critical", "metadata", "Missing question ID", "This entry has no stable identifier.", "Assign a unique ID before relying on progress, notebook, or history links.");
    if (!prompt) add("critical", "metadata", "Missing question text", "The question prompt is empty.", "Add the complete problem statement, including important conditions and given values.");
    if (!subject) add("warning", "metadata", "Missing subject", "No subject is assigned to this question.", "Assign a subject so library filters and subject-level reports can classify it correctly.");
    if (!category) add("warning", "metadata", "Missing topic / category", "No topic is assigned to this question.", "Add a specific topic to improve filtering and performance analysis.");

    const duplicateGroup = prompt ? (dupes.get(auditNormalize(prompt)) || []) : [];
    if (duplicateGroup.length > 1) {
      const related = duplicateGroup.find(other => String(other?.id || "") !== String(q.id || ""));
      const relatedLabel = related ? `${auditText(related.subject) || "Uncategorized"} / ${auditText(related.category) || "Uncategorized"} (${related.id || "no ID"})` : "another bank entry";
      add("warning", "duplicate", "Duplicate question text", `This prompt matches ${duplicateGroup.length - 1} other question(s) after normalizing spaces, punctuation, and letter case. One matching entry: ${relatedLabel}.`, "Compare the questions and keep both only if they test meaningfully different methods or source contexts.", related?.id || "");
    }

    if (options.length !== 4 || expectedLabels.some(label => optionLabels.filter(value => value === label).length !== 1)) {
      add("critical", "answer", "Answer-choice structure is invalid", `Expected exactly one choice each for A, B, C, and D; found ${options.length} choice(s) with labels ${optionLabels.join(", ") || "(none)"}.`, "Ensure the question has four non-empty choices labeled A, B, C, and D exactly once.");
    }
    const blankOptionLabels = options.filter(o => !auditText(o?.text));
    if (blankOptionLabels.length) add("critical", "answer", "Blank answer choice", `${blankOptionLabels.length} answer choice(s) have no text.`, "Fill every answer choice with meaningful text before using the question in a quiz.");
    const repeatedOptionText = optionTexts.find((value, index) => value && optionTexts.indexOf(value) !== index);
    if (repeatedOptionText) add("warning", "answer", "Repeated answer choices", "At least two answer choices have the same normalized text.", "Check for an accidental duplicate option or a question that needs clearer choices.");
    const answer = auditText(q.answer).toUpperCase();
    if (!expectedLabels.includes(answer)) {
      add(q.answerVerified === false ? "warning" : "critical", "answer", "Correct-answer label is invalid", `The saved correct answer is “${auditText(q.answer) || "(empty)"}”, not A, B, C, or D.`, "Select the correct choice label and verify the key against the source before marking it verified.");
    } else if (!optionLabels.includes(answer)) {
      add(q.answerVerified === false ? "warning" : "critical", "answer", "Correct answer has no matching choice", `The answer key says ${answer}, but no choice is labeled ${answer}.`, "Fix the choice labels or the answer key, then re-check the source solution.");
    }
    if (q.answerVerified === false) {
      add("warning", "source", "Answer key not verified", "This question is marked practice-only and should not be treated as a confirmed answer in exam scoring.", "Verify the key against the source and/or a complete independent calculation before enabling scored use.");
    }

    const finalAnswer = auditText(q.finalAnswer);
    const finalAnswerLabel = finalAnswer.match(/^\s*([A-D])\s*(?=[—–:.)\-])/i)?.[1]?.toUpperCase();
    if (q.answerVerified !== false && expectedLabels.includes(answer) && finalAnswerLabel && finalAnswerLabel !== answer) {
      add("critical", "answer", "Answer key conflicts with final-answer field", `The saved answer key is ${answer}, but the worked solution's final-answer field starts with ${finalAnswerLabel}.`, "Reconcile the answer key and worked solution with the original source. Do not guess which field is correct.");
    }

    requiredSolutionFields.forEach(([field, label]) => {
      const value = auditText(q[field]);
      if (!value) {
        add("warning", "solution", `Missing ${label.toLowerCase()}`, `The ${label.toLowerCase()} field is empty.`, `Complete ${label.toLowerCase()} so learners can follow and check the method.`);
      } else if (auditContainsPlaceholder(value)) {
        add("warning", "solution", `Possible placeholder in ${label.toLowerCase()}`, `The ${label.toLowerCase()} field contains text commonly used as a placeholder.`, `Replace placeholder text with the checked values, derivation, units, or explanation before relying on this solution.`);
      }
    });
    if (!auditText(q.source)) {
      add("info", "source", "No source recorded", "No source citation or reference is saved with this question.", "Add the book title and page or a source URL when available so the problem and answer can be checked later.");
    }
    const dimensionlessContext = /\b(?:ratio|efficiency|cop|eer|coefficient|specific gravity|relative humidity|compression ratio|expansion ratio|hydraulic gradient|reynolds number|mach number|percentage|percent|fraction|dimensionless|unitless)\b/i.test(prompt);
    if (finalAnswer && /\d/.test(finalAnswer) && !auditHasRecognizedUnit(finalAnswer) && !dimensionlessContext) {
      add("info", "units", "Check the final-answer units", "The final answer contains a number but no recognizable engineering unit was detected. A dimensionless result may be correct.", "Confirm whether the result needs a unit; if it is a physical quantity, include the appropriate unit and make sure it matches the calculation.");
    }
    const given = auditText(q.given);
    if (given && /\d/.test(given) && !auditHasRecognizedUnit(given) && !dimensionlessContext) {
      add("info", "units", "Check units for given values", "The given-values field contains numbers but no recognizable engineering units were detected.", "Check the source problem and add units to dimensional quantities. Some values, such as counts or ratios, may be unitless.");
    }
    if (prompt && /\d/.test(prompt) && !auditHasRecognizedUnit(prompt) && !dimensionlessContext) {
      add("info", "units", "Check units in the question text", "The prompt contains numeric values but no recognizable engineering unit was detected.", "Check whether the stated values need units. This is a heuristic and may be valid for dimensionless or explicitly unitless questions.");
    }
  });

  const severityRank = { critical: 0, warning: 1, info: 2 };
  issues.sort((a, b) => severityRank[a.severity] - severityRank[b.severity] || a.subject.localeCompare(b.subject) || a.category.localeCompare(b.category) || a.title.localeCompare(b.title));
  return { scannedAt: new Date().toISOString(), questionCount: Array.isArray(questionList) ? questionList.length : 0, issues };
}
function auditElement(tag, className, text) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
}
function renderQuestionBankAudit() {
  const resultsHost = document.querySelector("#audit-results");
  if (!resultsHost) return;
  latestQuestionBankAudit = analyzeQuestionBankQuality(questions);
  const issues = latestQuestionBankAudit.issues;
  const critical = issues.filter(item => item.severity === "critical").length;
  const warnings = issues.filter(item => item.severity === "warning").length;
  const affected = new Set(issues.map(item => item.questionId || item.prompt)).size;
  const metrics = {
    "#audit-question-count-pill": `${latestQuestionBankAudit.questionCount} question${latestQuestionBankAudit.questionCount === 1 ? "" : "s"} scanned`,
    "#audit-total-questions": String(latestQuestionBankAudit.questionCount),
    "#audit-critical-count": String(critical), "#audit-warning-count": String(warnings),
    "#audit-affected-count": String(affected),
    "#audit-clean-count": `${Math.max(0, latestQuestionBankAudit.questionCount - affected)} with no flagged issue`
  };
  Object.entries(metrics).forEach(([selector, value]) => { const el = document.querySelector(selector); if (el) el.textContent = value; });
  const navCount = document.querySelector("#audit-nav-count");
  if (navCount) navCount.textContent = String(issues.length > 99 ? "99+" : issues.length);
  const exportButton = document.querySelector("#audit-export"); if (exportButton) exportButton.disabled = !issues.length;

  const search = auditNormalize(document.querySelector("#audit-search")?.value || "");
  const severityFilter = document.querySelector("#audit-severity-filter")?.value || "all";
  const typeFilter = document.querySelector("#audit-type-filter")?.value || "all";
  const filtered = issues.filter(item => {
    if (severityFilter !== "all" && item.severity !== severityFilter) return false;
    if (typeFilter !== "all" && item.type !== typeFilter) return false;
    if (search) {
      const haystack = auditNormalize([item.subject, item.category, item.prompt, item.title, item.finding, item.recommendation, item.questionId].join(" "));
      if (!haystack.includes(search)) return false;
    }
    return true;
  });
  const affectedFiltered = new Map();
  filtered.forEach(item => {
    const key = item.questionId || item.prompt || "unknown";
    if (!affectedFiltered.has(key)) affectedFiltered.set(key, []);
    affectedFiltered.get(key).push(item);
  });
  const countEl = document.querySelector("#audit-results-count");
  if (countEl) countEl.textContent = `Showing ${filtered.length} finding(s) across ${affectedFiltered.size} question(s). ${issues.length} total finding(s) in the current bank.`;
  const status = document.querySelector("#audit-status");
  if (status && !status.textContent.startsWith("Audit complete")) {
    status.textContent = `Audit complete: ${latestQuestionBankAudit.questionCount} question(s) scanned at ${new Date(latestQuestionBankAudit.scannedAt).toLocaleTimeString()}. Findings are suggestions for human review; no data was changed.`;
  }
  resultsHost.replaceChildren();
  if (!affectedFiltered.size) {
    const empty = auditElement("div", "audit-empty" + (issues.length === 0 ? " audit-no-findings" : ""));
    empty.append(auditElement("h3", "", issues.length === 0 ? "No issues detected by these checks" : "No findings match these filters"));
    empty.append(auditElement("p", "", issues.length === 0 ? "This does not prove every answer is mathematically correct. Source and calculation verification are still important." : "Change the search term or filters to see other findings."));
    resultsHost.append(empty);
    return;
  }
  affectedFiltered.forEach((items, id) => {
    const first = items[0];
    const q = questions.find(item => String(item.id || "") === String(id));
    const card = auditElement("article", "audit-question-card");
    const head = auditElement("div", "audit-question-head");
    const title = auditElement("div", "audit-question-title");
    title.append(auditElement("strong", "", `${first.subject} · ${first.category}`));
    title.append(auditElement("p", "", first.prompt || "(Question text is empty)"));
    const meta = auditElement("div", "audit-question-meta");
    meta.append(auditElement("span", "audit-source-kind", first.builtIn ? "Built-in question" : "Custom question"));
    meta.append(auditElement("span", "audit-findings-pill", `${items.length} finding${items.length === 1 ? "" : "s"}`));
    head.append(title, meta); card.append(head);
    const findingsList = auditElement("div", "audit-findings-list");
    items.forEach(item => {
      const issue = auditElement("div", `audit-finding audit-finding-${item.severity}`);
      issue.append(auditElement("span", "audit-severity", item.severity));
      const copy = auditElement("div", "audit-finding-copy");
      copy.append(auditElement("strong", "", item.title));
      copy.append(auditElement("p", "", item.finding));
      copy.append(auditElement("p", "", `Suggested action: ${item.recommendation}`));
      if (item.relatedQuestionId) copy.append(auditElement("p", "", `Related question ID: ${item.relatedQuestionId}`));
      issue.append(copy); findingsList.append(issue);
    });
    card.append(findingsList);
    const actions = auditElement("div", "audit-question-actions");
    if (q && !q.builtIn) {
      const edit = auditElement("button", "button button-secondary", "Edit custom question");
      edit.type = "button"; edit.addEventListener("click", () => openEditQuestion(q.id));
      actions.append(edit);
    }
    if (q) {
      const open = auditElement("button", "button button-secondary", first.builtIn ? "Open in library" : "Practice this question");
      open.type = "button"; open.addEventListener("click", () => {
        const index = questions.findIndex(item => String(item.id) === String(q.id));
        if (index >= 0) { currentIndex = index; selectedAnswer = ""; submitted = false; renderQuestion(); renderLibrary(); document.querySelector('[data-view="practice"]')?.click(); }
      });
      actions.append(open);
    }
    card.append(actions); resultsHost.append(card);
  });
}
function exportQuestionBankAuditCsv() {
  const report = latestQuestionBankAudit && Array.isArray(latestQuestionBankAudit.issues) ? latestQuestionBankAudit : analyzeQuestionBankQuality(questions);
  if (!report.issues.length) {
    const status = document.querySelector("#audit-status"); if (status) status.textContent = "No findings to export. The current audit checks did not flag any issues.";
    return;
  }
  const headers = ["Severity", "Issue type", "Issue", "Question ID", "Question kind", "Subject", "Topic", "Question text", "Finding", "Suggested action", "Related question ID"];
  const rows = report.issues.map(item => [item.severity, item.typeLabel, item.title, item.questionId, item.builtIn ? "Built-in" : "Custom", item.subject, item.category, item.prompt, item.finding, item.recommendation, item.relatedQuestionId]);
  const csvCell = value => `"${String(value ?? "").replace(/"/g, '""').replace(/\r?\n/g, " ")}"`;
  const csv = [headers, ...rows].map(row => row.map(csvCell).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `engineering-review-question-audit-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.append(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  const status = document.querySelector("#audit-status"); if (status) status.textContent = `Exported ${report.issues.length} audit finding(s) to CSV. No question data was changed.`;
}

// Live filters re-render the latest deterministic report. The Run button performs a fresh scan.
document.querySelector("#audit-run")?.addEventListener("click", () => {
  renderQuestionBankAudit();
  const status = document.querySelector("#audit-status");
  if (status) status.textContent = `Audit complete: ${latestQuestionBankAudit.questionCount} question(s) scanned at ${new Date(latestQuestionBankAudit.scannedAt).toLocaleTimeString()}. Findings are suggestions for human review; no data was changed.`;
});
document.querySelector("#audit-search")?.addEventListener("input", renderQuestionBankAudit);
document.querySelector("#audit-severity-filter")?.addEventListener("change", renderQuestionBankAudit);
document.querySelector("#audit-type-filter")?.addEventListener("change", renderQuestionBankAudit);
document.querySelector("#audit-export")?.addEventListener("click", exportQuestionBankAuditCsv);
// Public read-only API also allows tests and future local tools to inspect the report.
window.runEngineeringReviewQuestionAudit = () => analyzeQuestionBankQuality(questions);
renderQuestionBankAudit();


// Phase 5 — Offline Engineering Toolkit
(function setupEngineeringToolkit() {
  const $ = (selector) => document.querySelector(selector);
  const expression = $('#tool-calc-expression');
  const calcResult = $('#tool-calc-result');
  // Small recursive-descent parser: no eval/Function and no arbitrary JavaScript execution.
  function calculateExpression(input) {
    let source = String(input || '').replace(/×/g, '*').replace(/÷/g, '/').replace(/π/g, 'pi').replace(/−/g, '-');
    let pos = 0;
    const skip = () => { while (/\s/.test(source[pos] || '')) pos++; };
    const eat = (token) => { skip(); if (source.slice(pos, pos + token.length).toLowerCase() === token.toLowerCase()) { pos += token.length; return true; } return false; };
    function primary() {
      skip();
      if (eat('+')) return primary();
      if (eat('-')) return -primary();
      if (eat('(')) { const v = addSub(); if (!eat(')')) throw Error('Missing closing parenthesis.'); return v; }
      const start = pos;
      const num = source.slice(pos).match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
      if (num) { pos += num[0].length; return Number(num[0]); }
      const word = source.slice(pos).match(/^[a-z]+/i);
      if (word) {
        pos += word[0].length; const name = word[0].toLowerCase();
        if (name === 'pi') return Math.PI; if (name === 'e') return Math.E;
        if (!eat('(')) throw Error(`Use ${name}(...) for a function.`);
        const arg = addSub(); if (!eat(')')) throw Error('Missing closing parenthesis after function.');
        const funcs = {sqrt:Math.sqrt,abs:Math.abs,sin:Math.sin,cos:Math.cos,tan:Math.tan,asin:Math.asin,acos:Math.acos,atan:Math.atan,ln:Math.log,log:Math.log10,exp:Math.exp};
        if (!funcs[name]) throw Error(`Unknown function: ${name}`);
        if (['sqrt','ln','log'].includes(name) && arg < (name === 'sqrt' ? 0 : Number.MIN_VALUE)) throw Error(`${name} input is outside its valid domain.`);
        return funcs[name](arg);
      }
      throw Error(`Unexpected input at position ${start + 1}.`);
    }
    function power() { let v = primary(); if (eat('^')) v = Math.pow(v, power()); return v; }
    function mulDiv() { let v = power(); while (true) { if (eat('*')) v *= power(); else if (eat('/')) { const d = power(); if (d === 0) throw Error('Cannot divide by zero.'); v /= d; } else break; } return v; }
    function addSub() { let v = mulDiv(); while (true) { if (eat('+')) v += mulDiv(); else if (eat('-')) v -= mulDiv(); else break; } return v; }
    if (!source.trim()) throw Error('Enter an expression first.');
    const result = addSub(); skip(); if (pos !== source.length) throw Error(`Unexpected input at position ${pos + 1}.`);
    if (!Number.isFinite(result)) throw Error('Result is not a finite number.'); return result;
  }
  $('#tool-calc-keypad')?.addEventListener('click', (event) => { const button = event.target.closest('[data-calc]'); if (!button || !expression) return; const start = expression.selectionStart ?? expression.value.length; const end = expression.selectionEnd ?? start; const value = button.dataset.calc; expression.setRangeText(value, start, end, 'end'); expression.focus(); });
  $('#tool-calc-clear')?.addEventListener('click', () => { if (expression) expression.value = ''; if (calcResult) calcResult.textContent = 'Result will appear here.'; });
  $('#tool-calc-evaluate')?.addEventListener('click', () => { try { const result = calculateExpression(expression?.value); calcResult.textContent = `Result: ${Number(result.toPrecision(12)).toLocaleString(undefined,{maximumFractionDigits:10})}`; } catch (error) { calcResult.textContent = `Check expression: ${error.message}`; } });
  expression?.addEventListener('keydown', (event) => { if (event.key === 'Enter') $('#tool-calc-evaluate')?.click(); });

  const units = {
    pressure:{'Pa':1,'kPa':1e3,'MPa':1e6,'bar':1e5,'atm':101325,'psi':6894.757293,'mmHg':133.322387},
    temperature:{'°C':1,'°F':1,'K':1},
    length:{'m':1,'km':1e3,'cm':.01,'mm':.001,'ft':.3048,'in':.0254,'mi':1609.344},
    mass:{'kg':1,'g':.001,'mg':1e-6,'tonne':1000,'lbm':.45359237,'slug':14.59390294},
    force:{'N':1,'kN':1e3,'MN':1e6,'lbf':4.448221615,'kgf':9.80665},
    energy:{'J':1,'kJ':1e3,'MJ':1e6,'cal':4.184,'kcal':4184,'Wh':3600,'kWh':3.6e6,'BTU':1055.055852},
    power:{'W':1,'kW':1e3,'MW':1e6,'hp (mechanical)':745.699872,'BTU/h':.29307107},
    volume:{'m³':1,'L':.001,'mL':1e-6,'cm³':1e-6,'ft³':.0283168466,'US gal':.00378541178},
    speed:{'m/s':1,'km/h':1/3.6,'ft/s':.3048,'mph':.44704,'knot':.514444444},
    area:{'m²':1,'cm²':1e-4,'mm²':1e-6,'ft²':.09290304,'in²':.00064516,'hectare':1e4},
    flow:{'m³/s':1,'L/s':.001,'L/min':.001/60,'m³/h':1/3600,'ft³/s':.0283168466,'US gal/min':.00378541178/60}
  };
  const category = $('#tool-unit-category'), from = $('#tool-unit-from'), to = $('#tool-unit-to'), value = $('#tool-unit-value'), unitResult = $('#tool-unit-result');
  function updateUnitOptions() { if (!category || !from || !to) return; const options = Object.keys(units[category.value]); const oldFrom=from.value, oldTo=to.value; from.replaceChildren(); to.replaceChildren(); options.forEach(name=>{from.add(new Option(name,name));to.add(new Option(name,name));}); from.value=options.includes(oldFrom)?oldFrom:options[0]; to.value=options.includes(oldTo)?oldTo:options[Math.min(1,options.length-1)]; convertUnits(); }
  function convertUnits() { if (!category || !from || !to || !value || !unitResult) return; const n=Number(value.value); if (value.value.trim()==='' || !Number.isFinite(n)) {unitResult.textContent='Enter a valid numeric value.';return;} let converted; if(category.value==='temperature'){const toK=x=>from.value==='°C'?x+273.15:from.value==='°F'?(x+459.67)*5/9:x; const kelvin=toK(n); if(kelvin<0){unitResult.textContent='Temperature is below absolute zero. Check the value and unit.';return;} converted=to.value==='°C'?kelvin-273.15:to.value==='°F'?kelvin*9/5-459.67:kelvin;} else {converted=n*units[category.value][from.value]/units[category.value][to.value];} unitResult.textContent=`${n.toLocaleString()} ${from.value} = ${Number(converted.toPrecision(10)).toLocaleString(undefined,{maximumFractionDigits:8})} ${to.value}`; }
  category?.addEventListener('change',updateUnitOptions); from?.addEventListener('change',convertUnits); to?.addEventListener('change',convertUnits); value?.addEventListener('input',convertUnits); updateUnitOptions();

  const constants = [
    ['Standard gravity','g₀','9.80665 m/s²','Defined standard value'],['Universal gas constant','Rᵤ','8.314462618 kJ/(kmol·K)','Approximate; basis matters'],['Avogadro constant','Nₐ','6.02214076 × 10²³ mol⁻¹','Exact SI value'],['Boltzmann constant','kᵦ','1.380649 × 10⁻²³ J/K','Exact SI value'],['Speed of light in vacuum','c','299,792,458 m/s','Exact SI value'],['Standard atmospheric pressure','pₐₜₘ','101.325 kPa','Standard atmosphere'],['Water density','ρ','≈ 1000 kg/m³','Approximate near 4°C'],['Water specific heat','cₚ','≈ 4.18 kJ/(kg·K)','Liquid water; near room temperature'],['Water latent heat of vaporization','h_fg','≈ 2257 kJ/kg','Approximate at 100°C, 1 atm'],['Gravitational acceleration (problem-specific)','g','Use the value stated in the problem; standard gravity is 9.80665 m/s²','Do not confuse mass and weight']
  ];
  const constantList=$('#tool-constant-list'), constantSearch=$('#tool-constant-search');
  function renderConstants(){if(!constantList)return;const query=(constantSearch?.value||'').toLowerCase();constantList.replaceChildren();const matches=constants.filter(row=>row.join(' ').toLowerCase().includes(query));if(!matches.length){constantList.textContent='No matching constants.';return;}matches.forEach(row=>{const item=document.createElement('div');item.className='toolkit-constant';const title=document.createElement('strong');title.textContent=row[0];const symbol=document.createElement('span');symbol.className='toolkit-symbol';symbol.textContent=row[1];const val=document.createElement('div');val.textContent=row[2];const note=document.createElement('small');note.textContent=row[3];item.append(title,symbol,val,note);constantList.append(item);});}
  constantSearch?.addEventListener('input',renderConstants); renderConstants();

  const baseDimensions = {
    m:{L:1},cm:{L:1},mm:{L:1},km:{L:1},s:{T:1},min:{T:1},h:{T:1},kg:{M:1},g:{M:1},N:{M:1,L:1,T:-2},kN:{M:1,L:1,T:-2},Pa:{M:1,L:-1,T:-2},kPa:{M:1,L:-1,T:-2},MPa:{M:1,L:-1,T:-2},J:{M:1,L:2,T:-2},kJ:{M:1,L:2,T:-2},W:{M:1,L:2,T:-3},kW:{M:1,L:2,T:-3},L:{L:3}
  };
  const targetDimensions={force:{M:1,L:1,T:-2},pressure:{M:1,L:-1,T:-2},energy:{M:1,L:2,T:-2},power:{M:1,L:2,T:-3},velocity:{L:1,T:-1},acceleration:{L:1,T:-2},density:{M:1,L:-3},dimensionless:{}};
  function parseDimensions(raw){let text=raw.replace(/·/g,'*').replace(/²/g,'^2').replace(/³/g,'^3').replace(/\s+/g,'');if(!text)throw Error('Enter a unit expression.');const parts=text.split(/([*/])/);let op='*',dims={M:0,L:0,T:0};for(const part of parts){if(!part)continue;if(part==='*'||part==='/'){op=part;continue;}const match=part.match(/^([A-Za-z]+)(?:\^(-?\d+(?:\.\d+)?))?$/);if(!match)throw Error(`Could not parse unit token: ${part}`);const unit=match[1];const unitDims=baseDimensions[unit];if(!unitDims)throw Error(`Unsupported unit: ${unit}`);const exponent=(match[2]?Number(match[2]):1)*(op==='/'?-1:1);Object.entries(unitDims).forEach(([key,power])=>dims[key]=(dims[key]||0)+power*exponent);op='*';}return dims;}
  $('#tool-dim-check')?.addEventListener('click',()=>{const output=$('#tool-dim-result');try{const actual=parseDimensions($('#tool-dim-expression')?.value||'');const expected=targetDimensions[$('#tool-dim-target')?.value||'dimensionless'];const keys=['M','L','T'];const okay=keys.every(key=>Math.abs((actual[key]||0)-(expected[key]||0))<1e-9);output.textContent=okay?'Dimensions match the selected target. This does not prove the equation or numerical answer is correct.':`Mismatch. Parsed exponents: M=${actual.M||0}, L=${actual.L||0}, T=${actual.T||0}. Check the unit expression and expected quantity.`;output.classList.toggle('toolkit-result-good',okay);output.classList.toggle('toolkit-result-bad',!okay);}catch(error){output.textContent=error.message;output.classList.remove('toolkit-result-good');output.classList.add('toolkit-result-bad');}});
})();

// Clean navigation: keep every feature available, but show only the selected area.
(function setupMainNavigation(){
  const buttons = Array.from(document.querySelectorAll('.nav-button[data-view]'));
  const sections = Array.from(document.querySelectorAll('[data-section]'));
  if (!buttons.length || !sections.length) return;
  function showView(view) {
    document.body.dataset.currentView = view;
    sections.forEach(section => { section.hidden = section.dataset.section !== view; });
    buttons.forEach(button => {
      const active = button.dataset.view === view;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    if (view === 'dashboard') window.renderStudyDashboard?.();
    if (view === 'practice') {
      const quiz = document.querySelector('.quiz-panel');
      if (quiz && document.body.classList.contains('exam-focus')) return;
    }
    window.scrollTo({top: 0, behavior: 'smooth'});
  }
  buttons.forEach(button => button.addEventListener('click', () => showView(button.dataset.view)));
  showView('dashboard');
})();