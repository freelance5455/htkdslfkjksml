// --- SÉCURITÉ ANTI-PLANTAGE ---
const storage = (() => {
    try { localStorage.setItem('t', 't'); localStorage.removeItem('t'); return localStorage; } 
    catch (e) { return { getItem: () => null, setItem: () => {}, removeItem: () => {} }; }
})();

setTimeout(() => {
    const splash = document.getElementById('splash-screen');
    if(splash) { splash.style.opacity = '0'; setTimeout(() => splash.remove(), 500); }
}, 2000);

// --- BANQUE DE 50 IMAGES (Thèmes + Wallpapers) ---
const banqueImages = [
    "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1080", "https://images.unsplash.com/photo-1618336753974-aae8e04506aa?q=80&w=1080",
    "https://images.unsplash.com/photo-1560972550-aba3456b5564?q=80&w=1080", "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=1080",
    "https://images.unsplash.com/photo-1528360983277-13d401cdc186?q=80&w=1080", "https://images.unsplash.com/photo-1596727147705-61a532a659bd?q=80&w=1080",
    "https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=1080", "https://images.unsplash.com/photo-1553949345-eb786bb3f7ba?q=80&w=1080",
    "https://images.unsplash.com/photo-1512418490979-92798cec1380?q=80&w=1080", "https://images.unsplash.com/photo-1541562232579-512a21360020?q=80&w=1080",
    "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?q=80&w=1080", "https://images.unsplash.com/photo-1571757399543-51381b3a0904?q=80&w=1080",
    "https://images.unsplash.com/photo-1533073526757-2c8ca1df9f1c?q=80&w=1080", "https://images.unsplash.com/photo-1549481177-47f08881747b?q=80&w=1080",
    "https://images.unsplash.com/photo-1601850494422-3cf14624b0b3?q=80&w=1080", "https://images.unsplash.com/photo-1580477609630-83f2dc6fcbe1?q=80&w=1080",
    "https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=1080", "https://images.unsplash.com/photo-1506744626753-eda818c2e877?q=80&w=1080",
    "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=1080", "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?q=80&w=1080",
    "https://images.unsplash.com/photo-1518235506717-e1ed3306a89b?q=80&w=1080", "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?q=80&w=1080",
    "https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?q=80&w=1080", "https://images.unsplash.com/photo-1511497584788-876760111969?q=80&w=1080",
    "https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=1080", "https://images.unsplash.com/photo-1502082553048-f009c37129b9?q=80&w=1080",
    "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?q=80&w=1080", "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1080",
    "https://images.unsplash.com/photo-1469474968028-56623f02e42e?q=80&w=1080", "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?q=80&w=1080",
    "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?q=80&w=1080", "https://images.unsplash.com/photo-1426604966848-d7adac402bff?q=80&w=1080",
    "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1080", "https://images.unsplash.com/photo-1501854140801-50d01698950b?q=80&w=1080",
    "https://images.unsplash.com/photo-1518495973542-4542c06a5843?q=80&w=1080", "https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1080",
    "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?q=80&w=1080", "https://images.unsplash.com/photo-1490682143684-14369e18dce8?q=80&w=1080",
    "https://images.unsplash.com/photo-1523712999610-f77fbcfc3843?q=80&w=1080", "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1080",
    "https://images.unsplash.com/photo-1519046904884-53103b34b206?q=80&w=1080", "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?q=80&w=1080",
    "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=1080", "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1080",
    "https://images.unsplash.com/photo-1454496522488-7a8e488e8606?q=80&w=1080", "https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?q=80&w=1080",
    "https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=1080", "https://images.unsplash.com/photo-1518098268026-4e89f1a2cd8e?q=80&w=1080",
    "https://images.unsplash.com/photo-1520116468816-95b69f847357?q=80&w=1080", "https://images.unsplash.com/photo-1499781350541-7783f6c6a0c8?q=80&w=1080"
];

// --- GESTION DES THÈMES ---
function genererThemes() {
    const themeGrid = document.getElementById('themeGrid');
    themeGrid.innerHTML = `
        <button class="theme-btn" onclick="changerTheme('dark')">🌙 Sombre</button>
        <button class="theme-btn" onclick="changerTheme('light')">☀️ Clair</button>
        <button class="theme-btn" onclick="changerTheme('transparent')">🪟 Transparent</button>
    `;
    
    // Ajouter les 50 thèmes basés sur les images
    banqueImages.forEach((img, index) => {
        themeGrid.innerHTML += `<button class="theme-btn" onclick="changerTheme('img_${index}')">🌸 Thème ${index + 1}</button>`;
    });
}

function ouvrirTheme() { document.getElementById('modalTheme').classList.remove('hidden'); }
function fermerTheme() { document.getElementById('modalTheme').classList.add('hidden'); }

function changerTheme(theme) {
    document.body.className = ''; 
    const bgDiv = document.getElementById('bgImage');
    bgDiv.classList.remove('active');
    bgDiv.style.backgroundImage = 'none';

    if (theme === 'dark') {
        document.body.classList.add('theme-dark');
    } else if (theme === 'light') {
        document.body.classList.add('theme-light');
    } else if (theme === 'transparent') {
        document.body.classList.add('theme-dark', 'theme-transparent');
    } else if (theme.startsWith('img_')) {
        document.body.classList.add('theme-dark');
        const index = parseInt(theme.split('_')[1]);
        bgDiv.style.backgroundImage = `url('${banqueImages[index]}')`;
        bgDiv.classList.add('active');
    }
    storage.setItem('otakus_theme', theme);
    fermerTheme();
}
document.getElementById('themeBtn').addEventListener('click', ouvrirTheme);

// --- CHARGEMENT API (Mangas, Animes, Kotatsu) ---
async function chargerTendances() {
    // 1. Mangas Tendances
    try {
        const resManga = await fetch('https://kitsu.io/api/edge/manga?page[limit]=10&sort=-averageRating');
        const dataManga = await resManga.json();
        const contManga = document.getElementById('trendingMangas');
        contManga.innerHTML = ''; 
        dataManga.data.forEach(m => {
            const img = m.attributes.posterImage ? m.attributes.posterImage.medium : 'https://via.placeholder.com/110x160/333/fff?text=No+Img';
            contManga.innerHTML += `<div class="media-card"><img src="${img}" class="card-img" style="object-fit:cover;"><p>${m.attributes.canonicalTitle}</p></div>`;
        });
    } catch (e) { document.getElementById('trendingMangas').innerHTML = 'Erreur de connexion.'; }

    // 2. Animes Populaires
    try {
        const resAnime = await fetch('https://kitsu.io/api/edge/anime?page[limit]=10&sort=-averageRating');
        const dataAnime = await resAnime.json();
        const contAnime = document.getElementById('trendingAnimes');
        contAnime.innerHTML = ''; 
        dataAnime.data.forEach(a => {
            const img = a.attributes.posterImage ? a.attributes.posterImage.medium : 'https://via.placeholder.com/110x160/333/fff?text=No+Img';
            contAnime.innerHTML += `<div class="media-card"><img src="${img}" class="card-img" style="object-fit:cover;"><p>${a.attributes.canonicalTitle}</p></div>`;
        });
    } catch (e) { document.getElementById('trendingAnimes').innerHTML = 'Erreur de connexion.'; }
}

// --- MANGAS KOTATSU (Deep Link) ---
const kotatsuList = [
    { title: "Solo Leveling", img: "https://cdn.myanimelist.net/images/manga/3/222295l.jpg" },
    { title: "One Piece", img: "https://cdn.myanimelist.net/images/manga/2/253146l.jpg" },
    { title: "Jujutsu Kaisen", img: "https://cdn.myanimelist.net/images/manga/3/237438l.jpg" },
    { title: "Chainsaw Man", img: "https://cdn.myanimelist.net/images/manga/3/216464l.jpg" },
    { title: "Tower of God", img: "https://cdn.myanimelist.net/images/manga/3/192194l.jpg" },
    { title: "Berserk", img: "https://cdn.myanimelist.net/images/manga/1/157897l.jpg" }
];

function chargerKotatsu() {
    const container = document.getElementById('kotatsuMangas');
    kotatsuList.forEach(manga => {
        container.innerHTML += `
            <div class="media-card" onclick="ouvrirKotatsu('${manga.title}')">
                <img src="${manga.img}" class="card-img" style="object-fit:cover;">
                <p>${manga.title}</p>
            </div>
        `;
    });
}

function ouvrirKotatsu(titre) {
    // Tentative d'ouverture de l'application via Intent Android
    // L'ID du package Kotatsu est org.koitharu.kotatsu
    const intentUrl = `intent://#Intent;package=org.koitharu.kotatsu;S.browser_fallback_url=https://kotatsu.app;end`;
    
    // On crée un lien invisible pour déclencher l'intent
    const a = document.createElement('a');
    a.href = intentUrl;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    // Note: Android pourrait bloquer le deep-link spécifique au manga sans ID.
    // Cette méthode ouvre l'app Kotatsu en général.
}

// --- WALLPAPERS (50) ---
function afficherWallpapers() {
    const grid = document.getElementById('wallpaperGrid');
    grid.innerHTML = '';
    banqueImages.forEach((url, index) => {
        grid.innerHTML += `
            <div class="collection-item glass">
                <img src="${url}" loading="lazy" style="height:150px;">
                <h4>Wallpaper ${index + 1}</h4>
                <button onclick="telechargerImage('${url}', 'otakus_zone_wall_${index + 1}')" style="padding:8px; font-size:0.8rem; margin-top:8px; background:var(--accent); border-radius:8px; width:100%;">⬇️ Enregistrer</button>
            </div>
        `;
    });
}

function telechargerImage(url, nom) {
    const a = document.createElement('a');
    a.href = url;
    a.download = nom + '.jpg';
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

// --- NAVIGATION ---
function changerOnglet(idOnglet, bouton) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById('tab-' + idOnglet).classList.add('active');
    bouton.classList.add('active');
    const btnFlottant = document.querySelector('.btn-flottant');
    if (btnFlottant) btnFlottant.style.display = (idOnglet === 'collection') ? 'flex' : 'none';
}

// --- COLLECTION (Logique locale) ---
let maCollection = JSON.parse(storage.getItem('otakus_v7')) || [];
let filtreActuel = 'tout';
let rechercheActuelle = "";

function afficherCollection() {
    const grid = document.getElementById('maCollection');
    const homeRow = document.getElementById('homeCollection');
    grid.innerHTML = ''; homeRow.innerHTML = '';
    
    let items = maCollection;
    if (filtreActuel !== 'tout') items = items.filter(item => item.type === filtreActuel);
    if (rechercheActuelle !== "") items = items.filter(item => item.titre.toLowerCase().includes(rechercheActuelle.toLowerCase()));

    if (items.length === 0) {
        grid.innerHTML = '<p style="grid-column: 1/-1; text-align:center; color:var(--text-dim);">Aucun média trouvé.</p>';
    } else {
        items.forEach(item => {
            let visuel = item.type === 'image' && (item.data || item.url) 
                ? `<img src="${item.data || item.url}" onerror="this.src='https://via.placeholder.com/110x120/333/fff?text=Erreur'">` 
                : `<div class="card-img bg-1" style="height:100px;">🎥</div>`;
            grid.innerHTML += `<div class="collection-item glass" onclick="ouvrirDetails(${item.id})">${visuel}<h4>${item.titre}</h4></div>`;
        });
    }
}

function ouvrirDetails(id) {
    const item = maCollection.find(i => i.id === id);
    if(!item) return;
    let contenu = `<h2>${item.titre}</h2>`;
    if (item.type === 'image' && (item.data || item.url)) contenu += `<img src="${item.data || item.url}">`;
    contenu += `
        <div class="detail-btns">
            ${item.url ? `<a href="${item.url}" target="_blank" style="flex:1;"><button style="width:100%;">▶ Ouvrir</button></a>` : ''}
            <button class="btn-del-detail" onclick="supprimerItem(${item.id})">🗑️ Supprimer</button>
        </div>`;
    document.getElementById('detailsContent').innerHTML = contenu;
    document.getElementById('modalDetails').classList.remove('hidden');
}

function supprimerItem(id) {
    if(confirm("Supprimer définitivement ?")) {
        maCollection = maCollection.filter(i => i.id !== id);
        storage.setItem('otakus_v7', JSON.stringify(maCollection));
        afficherCollection(); fermerDetails();
    }
}

function fermerDetails() { document.getElementById('modalDetails').classList.add('hidden'); }

// --- FORMULAIRE ---
document.getElementById('mediaForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const titre = document.getElementById('titre').value;
    const type = document.getElementById('type').value;
    let nouvelItem = { id: Date.now(), titre, type, url: null, data: null };

    if (type === 'video') {
        nouvelItem.url = document.getElementById('mediaUrl').value;
        sauvegarderItem(nouvelItem);
    } else {
        const urlInput = document.getElementById('imageUrl').value;
        const file = document.getElementById('imageFile').files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (evt) => { nouvelItem.data = evt.target.result; sauvegarderItem(nouvelItem); };
            reader.readAsDataURL(file);
        } else if (urlInput) {
            nouvelItem.url = urlInput; sauvegarderItem(nouvelItem);
        }
    }
});

function sauvegarderItem(item) {
    maCollection.push(item);
    storage.setItem('otakus_v7', JSON.stringify(maCollection));
    afficherCollection(); fermerFormulaire();
}

function toggleChamps() {
    const type = document.getElementById('type').value;
    document.getElementById('champsVideo').style.display = (type === 'video') ? 'block' : 'none';
    document.getElementById('champsImage').style.display = (type === 'image') ? 'flex' : 'none';
}
function ouvrirFormulaire() { document.getElementById('modalForm').classList.remove('hidden'); toggleChamps(); }
function fermerFormulaire() { document.getElementById('modalForm').classList.add('hidden'); document.getElementById('mediaForm').reset(); }

// --- CHAT ---
function envoyerMessage() {
    const input = document.getElementById('chatMessage');
    const box = document.getElementById('chatBox');
    if(input.value.trim() !== "") {
        box.innerHTML += `<div style="background:var(--accent); color:white; padding:12px 15px; border-radius:15px 15px 0 15px; align-self:flex-end; max-width:80%;">${input.value}</div>`;
        input.value = ''; box.scrollTop = box.scrollHeight;
    }
}

// --- LANCEMENT ---
afficherCollection();
chargerTendances();
chargerKotatsu();
afficherWallpapers();
genererThemes();

// Restauration du thème
const themeSauvegarde = storage.getItem('otakus_theme') || 'dark';
changerTheme(themeSauvegarde);
