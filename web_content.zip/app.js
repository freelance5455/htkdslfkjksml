const DB_NAME="vijay-coaching-centre", DB_VERSION=1;
const MONTHS=["January","February","March","April","May","June","July","August","September","October","November","December"];
let db, deferredInstall=null;

const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const money=n=>"₹"+Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2});
const today=()=>new Date().toISOString().slice(0,10);
const uid=(p)=>p+"_"+Date.now()+"_"+crypto.randomUUID().slice(0,8);

function openDB(){
 return new Promise((resolve,reject)=>{
  const r=indexedDB.open(DB_NAME,DB_VERSION);
  r.onupgradeneeded=()=>{const d=r.result;
   if(!d.objectStoreNames.contains("students")) d.createObjectStore("students",{keyPath:"id"});
   if(!d.objectStoreNames.contains("teachers")) d.createObjectStore("teachers",{keyPath:"id"});
   if(!d.objectStoreNames.contains("studentPayments")){const s=d.createObjectStore("studentPayments",{keyPath:"id"});s.createIndex("studentId","studentId");s.createIndex("date","date");}
   if(!d.objectStoreNames.contains("teacherPayments")){const s=d.createObjectStore("teacherPayments",{keyPath:"id"});s.createIndex("teacherId","teacherId");s.createIndex("date","date");}
  };
  r.onsuccess=()=>{db=r.result;resolve(db)}; r.onerror=()=>reject(r.error);
 });
}
function req(store,mode="readonly"){return db.transaction(store,mode).objectStore(store)}
function get(store,id){return new Promise((res,rej)=>{const r=req(store).get(id);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
function all(store){return new Promise((res,rej)=>{const r=req(store).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})}
function put(store,obj){return new Promise((res,rej)=>{const r=req(store,"readwrite").put(obj);r.onsuccess=()=>res(obj);r.onerror=()=>rej(r.error)})}
function del(store,id){return new Promise((res,rej)=>{const r=req(store,"readwrite").delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function byIndex(store,index,value){return new Promise((res,rej)=>{const r=req(store).index(index).getAll(value);r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})}
function txDelete(store, ids){return Promise.all(ids.map(id=>del(store,id)))}

function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function route(name){history.pushState({name},"","#"+name);render(name)}
window.onpopstate=()=>render(location.hash.slice(1)||"home");
function openDrawer(){ $("#drawer").classList.add("open"); $("#scrim").classList.remove("hidden")}
function closeDrawer(){ $("#drawer").classList.remove("open"); $("#scrim").classList.add("hidden")}
$("#menuBtn")?.addEventListener("click",openDrawer); $("#scrim")?.addEventListener("click",closeDrawer); $("#homeBtn")?.addEventListener("click",()=>route("home"));
document.addEventListener("click",e=>{const b=e.target.closest("[data-route]");if(b){closeDrawer();route(b.dataset.route)}});

function home(){
 $("#view").innerHTML=`<section class="hero"><h1>Vijay Coaching Centre</h1><p>Offline Student, Teacher & Fee Management</p></section>
 <div class="grid">
  <div class="action-card" onclick="route('classes')"><div class="ico">👨‍🎓</div><h3>Add Student</h3><p>Class 9 से 12 तक student records और fees manage करें।</p></div>
  <div class="action-card" onclick="route('teachers')"><div class="ico">👨‍🏫</div><h3>Add Teacher</h3><p>Teacher details और monthly payments manage करें।</p></div>
  <div class="action-card" onclick="route('students')"><div class="ico">📋</div><h3>Student Details</h3><p>Search, edit, delete और fee status देखें।</p></div>
  <div class="action-card" onclick="route('reports')"><div class="ico">📊</div><h3>Reports</h3><p>सभी classes की live report print/PDF करें।</p></div>
 </div>`;
}

async function render(name){
 if(name==="home") return home();
 if(name==="classes") return renderClasses();
 if(name==="students") return renderStudents();
 if(name==="teachers") return renderTeachers();
 if(name==="reports") return renderReports();
 if(name.startsWith("class-")) return renderClass(name.split("-")[1]);
 if(name.startsWith("student-")) return renderStudent(name.slice(8));
 if(name.startsWith("teacher-")) return renderTeacher(name.slice(8));
 if(name.startsWith("receipt-")) return renderReceipt(name.slice(8));
 return home();
}

async function renderClasses(){
 const ss=await all("students"); const counts={9:0,10:0,11:0,12:0};ss.forEach(s=>counts[s.class]++);
 $("#view").innerHTML=`<div class="section-head"><h2>Students</h2><button class="btn secondary" onclick="route('students')">All Students</button></div>
 <div class="grid">${["9","10","11","12"].map(c=>`<div class="card class-card" onclick="route('class-${c}')"><strong>Class ${c}</strong><span class="badge">${counts[c]} Students</span></div>`).join("")}</div>`;
}
async function renderClass(c){
 const ss=(await all("students")).filter(s=>s.class===c);
 $("#view").innerHTML=`<div class="section-head"><h2>Class ${esc(c)}</h2><button class="btn" onclick="openStudentForm('${c}')">+ Add Student</button></div>
 <div class="card pad" style="margin-bottom:14px"><input class="search" id="classSearch" placeholder="Search name, father name or mobile..."></div>
 <div id="classList" class="list"></div>`;
 const draw=()=>{const q=($("#classSearch").value||"").toLowerCase();const a=ss.filter(s=>[s.name,s.fatherName,s.mobile].join(" ").toLowerCase().includes(q));$("#classList").innerHTML=a.length?a.map(studentItem).join(""):`<div class="empty">इस class में अभी कोई student नहीं है।</div>`};
 $("#classSearch").oninput=draw;draw();
}
function studentItem(s){return `<div class="list-item"><div onclick="route('student-${s.id}')" style="cursor:pointer;flex:1"><div class="name">${esc(s.name)}</div><div class="meta">Father: ${esc(s.fatherName)} · Mobile: ${esc(s.mobile)}</div></div><button class="btn small secondary" onclick="openStudentForm('${s.class}','${s.id}')">Edit</button></div>`}

async function renderStudents(){
 const ss=await all("students");
 $("#view").innerHTML=`<div class="section-head"><h2>Student Details</h2><button class="btn" onclick="route('classes')">+ Add Student</button></div>
 <div class="card pad" style="margin-bottom:14px"><input class="search" id="studentSearch" placeholder="Search student name, father name or mobile..."></div>
 <div id="studentList" class="list"></div>`;
 const draw=()=>{const q=($("#studentSearch").value||"").toLowerCase();const a=ss.filter(s=>[s.name,s.fatherName,s.mobile,s.class].join(" ").toLowerCase().includes(q));$("#studentList").innerHTML=a.length?a.map(s=>`<div class="list-item"><div onclick="route('student-${s.id}')" style="cursor:pointer;flex:1"><div class="name">${esc(s.name)} <span class="badge">Class ${esc(s.class)}</span></div><div class="meta">Father: ${esc(s.fatherName)} · ${esc(s.mobile)}</div></div><button class="btn small secondary" onclick="openStudentForm('${s.class}','${s.id}')">Edit</button></div>`).join(""):`<div class="empty">No students found.</div>`};
 $("#studentSearch").oninput=draw;draw();
}

function openStudentForm(c,id=null){
 (async()=>{
 const s=id?await get("students",id):null;
 $("#modal").classList.remove("hidden");
 $("#modalCard").innerHTML=`<h3>${id?"Edit Student":"Add Student — Class "+c}</h3>
 <form id="studentForm"><div class="form-grid">
 <div class="field"><label>Student Name *</label><input name="name" required value="${esc(s?.name)}"></div>
 <div class="field"><label>Father Name *</label><input name="fatherName" required value="${esc(s?.fatherName)}"></div>
 <div class="field"><label>Address</label><input name="address" value="${esc(s?.address)}"></div>
 <div class="field"><label>Mobile Number</label><input name="mobile" inputmode="tel" value="${esc(s?.mobile)}"></div>
 <div class="field"><label>Total Course / Annual Fee (₹)</label><input name="totalFee" type="number" min="0" step="0.01" value="${s?.totalFee??""}"></div>
 <div class="field"><label>Admission Date</label><input name="admissionDate" type="date" value="${s?.admissionDate||today()}"></div>
 <div class="field full"><label>Optional Remarks</label><textarea name="remarks">${esc(s?.remarks)}</textarea></div>
 </div><div class="modal-actions"><button type="button" class="btn secondary" onclick="closeModal()">Cancel</button><button class="btn">Save Student</button></div></form>`;
 $("#studentForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const obj={...(s||{}),id:id||uid("stu"),name:f.get("name").trim(),fatherName:f.get("fatherName").trim(),address:f.get("address").trim(),mobile:f.get("mobile").trim(),class:c,totalFee:Number(f.get("totalFee")||0),admissionDate:f.get("admissionDate"),remarks:f.get("remarks").trim(),createdAt:s?.createdAt||new Date().toISOString()};await put("students",obj);closeModal();toast("Student saved");route(id?`student-${id}`:`class-${c}`)};
 })();
}
function closeModal(){$("#modal").classList.add("hidden")}

async function studentTotals(id){const ps=await byIndex("studentPayments","studentId",id);const total=ps.reduce((a,p)=>a+Number(p.amount||0),0);const monthly=Object.fromEntries(MONTHS.map(m=>[m,0]));ps.forEach(p=>monthly[p.month]=(monthly[p.month]||0)+Number(p.amount||0));return {ps,total,monthly}}
async function renderStudent(id){
 const s=await get("students",id);if(!s)return route("students");const t=await studentTotals(id),due=Math.max(0,Number(s.totalFee||0)-t.total);
 $("#view").innerHTML=`<div class="section-head"><h2>Student Profile</h2><div><button class="btn secondary" onclick="openStudentForm('${s.class}','${s.id}')">Edit Student</button> <button class="btn danger" onclick="deleteStudent('${s.id}')">Delete</button></div></div>
 <div class="profile"><div class="card pad"><h2 style="margin-top:0">${esc(s.name)}</h2><p class="muted">Father: ${esc(s.fatherName)} · Class ${esc(s.class)}</p><p>📞 ${esc(s.mobile||"—")}</p><p>📍 ${esc(s.address||"—")}</p><div class="stat-grid"><div class="stat"><small>Total Fee</small><strong>${money(s.totalFee)}</strong></div><div class="stat"><small>Total Paid</small><strong class="success-text">${money(t.total)}</strong></div><div class="stat"><small>Total Due</small><strong class="danger-text">${money(due)}</strong></div></div><div class="modal-actions" style="justify-content:flex-start"><button class="btn" onclick="openPaymentForm('${s.id}')">+ Add Payment</button></div></div>
 <div class="card pad"><h3 style="margin-top:0">Monthly Fee Record</h3>${MONTHS.map(m=>`<div class="month-row"><span>${m}</span><span class="amount">${money(t.monthly[m])}</span><button class="btn small secondary" onclick="openPaymentForm('${s.id}','${m}')">Add</button></div>`).join("")}</div></div>
 <div class="card pad" style="margin-top:16px"><div class="section-head"><h3>Payment History</h3></div>${t.ps.sort((a,b)=>b.date.localeCompare(a.date)).map(p=>`<div class="list-item"><div><b>${esc(p.month)}</b><div class="meta">${esc(p.date)} · Receipt ${esc(p.receiptNo)}</div></div><div class="amount">${money(p.amount)}<div class="meta">Total paid ${money(p.runningTotal)} · Due ${money(Math.max(0,s.totalFee-p.runningTotal))}</div></div></div>`).join("")||`<div class="empty">No payment history yet.</div>`}</div>`;
}

function openPaymentForm(studentId,presetMonth=""){
 (async()=>{const s=await get("students",studentId);$("#modal").classList.remove("hidden");$("#modalCard").innerHTML=`<h3>Add Payment</h3><form id="paymentForm"><p class="muted"><b>${esc(s.name)}</b> · Father: ${esc(s.fatherName)} · Class ${esc(s.class)}</p><div class="form-grid"><div class="field"><label>Month</label><select name="month">${MONTHS.map(m=>`<option ${m===presetMonth?"selected":""}>${m}</option>`).join("")}</select></div><div class="field"><label>Amount (₹)</label><input name="amount" type="number" min="0.01" step="0.01" required autofocus></div></div><div class="modal-actions"><button type="button" class="btn secondary" onclick="closeModal()">Cancel</button><button class="btn success">Save Payment</button></div></form>`;
 $("#paymentForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target), amount=Number(f.get("amount"));if(amount<=0)return toast("Amount must be greater than 0");const existing=await studentTotals(studentId);const running=existing.total+amount;const p={id:uid("spay"),studentId,month:f.get("month"),amount,date:today(),createdAt:new Date().toISOString(),receiptNo:"VCC-"+Date.now(),runningTotal:running};await put("studentPayments",p);closeModal();toast("Payment saved");route("receipt-"+p.id)};
 })();
}

async function deleteStudent(id){if(!confirm("Are you sure you want to delete this student?"))return;const ps=await byIndex("studentPayments","studentId",id);await txDelete("studentPayments",ps.map(p=>p.id));await del("students",id);toast("Student deleted");route("students")}

async function renderReceipt(pid){
 const p=await get("studentPayments",pid),s=await get("students",p.studentId);if(!p||!s)return route("students");const due=Math.max(0,s.totalFee-p.runningTotal);
 $("#view").innerHTML=`<div class="section-head no-print"><h2>Fee Receipt</h2><div><button class="btn secondary" onclick="print()">🖨 Print Receipt</button><button class="btn success" onclick="shareReceipt('${pid}')">WhatsApp</button></div></div>
 <div class="receipt" id="receipt"><div class="receipt-head"><img src="assets/logo.svg"><h2>Vijay Coaching Centre</h2><div>Miya Ka Pura, Petrol Pump Ke Samane</div><h3>FEE RECEIPT</h3></div><table class="receipt-table"><tr><td>Receipt Number</td><td>${esc(p.receiptNo)}</td></tr><tr><td>Date</td><td>${esc(p.date)}</td></tr><tr><td>Student Name</td><td>${esc(s.name)}</td></tr><tr><td>Father Name</td><td>${esc(s.fatherName)}</td></tr><tr><td>Class</td><td>${esc(s.class)}</td></tr><tr><td>Mobile Number</td><td>${esc(s.mobile||"—")}</td></tr><tr><td>Payment Month</td><td>${esc(p.month)}</td></tr><tr><td>Amount Paid</td><td>${money(p.amount)}</td></tr><tr><td>Total Fee</td><td>${money(s.totalFee)}</td></tr><tr><td>Total Paid</td><td>${money(p.runningTotal)}</td></tr><tr><td>Remaining Due</td><td>${money(due)}</td></tr></table><div class="signature">Authorized Signature<br><br>____________________</div></div>`;
}
async function shareReceipt(pid){const p=await get("studentPayments",pid),s=await get("students",p.studentId),due=Math.max(0,s.totalFee-p.runningTotal);const msg=`Vijay Coaching Centre\nStudent: ${s.name}\nClass: ${s.class}\nMonth: ${p.month}\nAmount Paid: ${money(p.amount)}\nTotal Paid: ${money(p.runningTotal)}\nDue: ${money(due)}`;const wa="https://wa.me/?text="+encodeURIComponent(msg);window.location.href=wa}

async function renderTeachers(){
 const ts=await all("teachers");
 $("#view").innerHTML=`<div class="section-head"><h2>Teacher Details</h2><button class="btn" onclick="openTeacherForm()">+ Add Teacher</button></div><div id="teacherList" class="list">${ts.length?ts.map(t=>`<div class="list-item"><div onclick="route('teacher-${t.id}')" style="cursor:pointer;flex:1"><div class="name">${esc(t.name)}</div><div class="meta">${esc(t.subject||"")} · ${esc(t.mobile||"")}</div></div><button class="btn small secondary" onclick="openTeacherForm('${t.id}')">Edit</button></div>`).join(""):`<div class="empty">No teachers found.</div>`}</div>`;
}
function openTeacherForm(id=null){
 (async()=>{const t=id?await get("teachers",id):null;$("#modal").classList.remove("hidden");$("#modalCard").innerHTML=`<h3>${id?"Edit Teacher":"Add Teacher"}</h3><form id="teacherForm"><div class="form-grid">
 <div class="field"><label>Teacher Name *</label><input name="name" required value="${esc(t?.name)}"></div><div class="field"><label>Father Name</label><input name="fatherName" value="${esc(t?.fatherName)}"></div>
 <div class="field"><label>Mobile Number</label><input name="mobile" value="${esc(t?.mobile)}"></div><div class="field"><label>Subject</label><input name="subject" value="${esc(t?.subject)}"></div>
 <div class="field"><label>Monthly Salary / Payment (₹)</label><input name="salary" type="number" min="0" value="${t?.salary??""}"></div><div class="field full"><label>Address</label><input name="address" value="${esc(t?.address)}"></div>
 </div><div class="modal-actions"><button type="button" class="btn secondary" onclick="closeModal()">Cancel</button><button class="btn">Save Teacher</button></div></form>`;
 $("#teacherForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);await put("teachers",{...(t||{}),id:id||uid("tea"),name:f.get("name").trim(),fatherName:f.get("fatherName").trim(),mobile:f.get("mobile").trim(),subject:f.get("subject").trim(),salary:Number(f.get("salary")||0),address:f.get("address").trim(),createdAt:t?.createdAt||new Date().toISOString()});closeModal();toast("Teacher saved");route("teachers")};
 })();
}
async function teacherTotals(id){const ps=await byIndex("teacherPayments","teacherId",id);const total=ps.reduce((a,p)=>a+Number(p.amount||0),0);const monthly=Object.fromEntries(MONTHS.map(m=>[m,0]));ps.forEach(p=>monthly[p.month]=(monthly[p.month]||0)+Number(p.amount||0));return {ps,total,monthly}}
async function renderTeacher(id){
 const t=await get("teachers",id);if(!t)return route("teachers");const x=await teacherTotals(id);
 $("#view").innerHTML=`<div class="section-head"><h2>Teacher Profile</h2><button class="btn secondary" onclick="openTeacherForm('${id}')">Edit Teacher</button></div><div class="profile"><div class="card pad"><h2 style="margin-top:0">${esc(t.name)}</h2><p class="muted">${esc(t.subject||"")} · ${esc(t.mobile||"")}</p><p>Father: ${esc(t.fatherName||"—")}</p><p>Address: ${esc(t.address||"—")}</p><div class="stat-grid"><div class="stat"><small>Monthly Salary</small><strong>${money(t.salary)}</strong></div><div class="stat"><small>Total Paid</small><strong>${money(x.total)}</strong></div><div class="stat"><small>Transactions</small><strong>${x.ps.length}</strong></div></div><div class="modal-actions" style="justify-content:flex-start"><button class="btn" onclick="openTeacherPaymentForm('${id}')">+ Add Payment</button></div></div><div class="card pad"><h3 style="margin-top:0">Monthly Payments</h3>${MONTHS.map(m=>`<div class="month-row"><span>${m}</span><span class="amount">${money(x.monthly[m])}</span><button class="btn small secondary" onclick="openTeacherPaymentForm('${id}','${m}')">Add</button></div>`).join("")}</div></div><div class="card pad" style="margin-top:16px"><h3>Payment History</h3>${x.ps.sort((a,b)=>b.date.localeCompare(a.date)).map(p=>`<div class="list-item"><div><b>${esc(p.month)}</b><div class="meta">${esc(p.date)}</div></div><div class="amount">${money(p.amount)}</div></div>`).join("")||`<div class="empty">No payment history yet.</div>`}</div>`;
}
function openTeacherPaymentForm(id,preset=""){
 (async()=>{const t=await get("teachers",id);$("#modal").classList.remove("hidden");$("#modalCard").innerHTML=`<h3>Add Teacher Payment</h3><p class="muted"><b>${esc(t.name)}</b> · ${esc(t.subject||"")}</p><form id="tpForm"><div class="form-grid"><div class="field"><label>Month</label><select name="month">${MONTHS.map(m=>`<option ${m===preset?"selected":""}>${m}</option>`).join("")}</select></div><div class="field"><label>Amount (₹)</label><input name="amount" type="number" min="0.01" step="0.01" value="${t.salary||""}" required></div></div><div class="modal-actions"><button type="button" class="btn secondary" onclick="closeModal()">Cancel</button><button class="btn success">Save Payment</button></div></form>`;$("#tpForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target),amount=Number(f.get("amount"));const x=await teacherTotals(id);await put("teacherPayments",{id:uid("tpay"),teacherId:id,month:f.get("month"),amount,date:today(),createdAt:new Date().toISOString(),runningTotal:x.total+amount});closeModal();toast("Teacher payment saved");route("teacher-"+id)}})();
}

async function renderReports(){
 const ss=await all("students");const groups={9:[],10:[],11:[],12:[]};ss.forEach(s=>(groups[s.class]??=[]).push(s));
 let html=`<div class="section-head"><h2>Student Details Report</h2><div><button class="btn secondary" onclick="window.print()">🖨 Print Details / Save as PDF</button><button class="btn" onclick="downloadReportCSV()">⬇ Download CSV</button></div></div><div class="report-print-header"><h2>Vijay Coaching Centre</h2><p>Miya Ka Pura, Petrol Pump Ke Samane</p><h3>Student Details Report</h3></div>`;
 for(const c of ["9","10","11","12"]){html+=`<h3 class="class-title">CLASS ${c}</h3><div class="table-wrap"><table class="report-table"><thead><tr><th>Class</th><th>Student Name</th><th>Father Name</th><th>Mobile</th><th>Total Fee</th><th>Paid</th><th>Due</th></tr></thead><tbody>`;
 for(const s of groups[c]){const x=await studentTotals(s.id);html+=`<tr><td>${c}</td><td>${esc(s.name)}</td><td>${esc(s.fatherName)}</td><td>${esc(s.mobile)}</td><td>${money(s.totalFee)}</td><td>${money(x.total)}</td><td>${money(Math.max(0,s.totalFee-x.total))}</td></tr>`}
 html+=`</tbody></table></div>`}
 $("#view").innerHTML=html;
}
async function downloadReportCSV(){
 const ss=await all("students"), rows=[["Class","Student Name","Father Name","Mobile","Total Fee","Paid","Due"]];
 for(const s of ss){const x=await studentTotals(s.id);rows.push([s.class,s.name,s.fatherName,s.mobile,s.totalFee,x.total,Math.max(0,s.totalFee-x.total)])}
 const csv=rows.map(r=>r.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}));a.download=`VCC-Student-Report-${today()}.csv`;a.click();URL.revokeObjectURL(a.href);toast("Report downloaded")}
window.openStudentForm=openStudentForm;window.openTeacherForm=openTeacherForm;window.openPaymentForm=openPaymentForm;window.openTeacherPaymentForm=openTeacherPaymentForm;window.deleteStudent=deleteStudent;window.closeModal=closeModal;window.route=route;window.shareReceipt=shareReceipt;window.downloadReportCSV=downloadReportCSV;

window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("#installBtn")?.classList.remove("hidden")});
$("#installBtn")?.addEventListener("click",async()=>{if(!deferredInstall)return;deferredInstall.prompt();deferredInstall=null});

(async()=>{await openDB();setTimeout(()=>{$("#splash").classList.add("hidden");$("#app").classList.remove("hidden")},1200);route(location.hash.slice(1)||"home");if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});})();
