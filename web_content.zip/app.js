(() => {
"use strict";
const $app = document.getElementById("app");
const SUBJ = window.SUBJ, PAPERS = window.PAPERS, ALLQ = window.ALLQ, KB = window.KB || [];
const subById = id => SUBJ.find(s => s.id === id);
const BN = "০১২৩৪৫৬৭৮৯";
const bn = v => String(v).replace(/\d/g, d => BN[d]);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const tx = s => esc(s).replace(/\n/g, "<br>");
const today = () => new Date().toISOString().slice(0, 10);
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0; [a[i], a[j]] = [a[j], a[i]]; } return a; };
const LETTERS = ["ক", "খ", "গ", "ঘ"];
const UNIS = ["DU", "JU", "RU", "CU", "JnU", "KU", "CoU", "HSTU", "GST", "Agri"];
const UNI_NAME = { DU: "ঢাকা বিশ্ববিদ্যালয়", JU: "জাহাঙ্গীরনগর বিশ্ববিদ্যালয়", RU: "রাজশাহী বিশ্ববিদ্যালয়", CU: "চট্টগ্রাম বিশ্ববিদ্যালয়", GST: "GST গুচ্ছ", JnU: "জগন্নাথ বিশ্ববিদ্যালয়", KU: "খুলনা বিশ্ববিদ্যালয়", CoU: "কুমিল্লা বিশ্ববিদ্যালয়", HSTU: "হাজী দানেশ বিজ্ঞান ও প্রযুক্তি বিশ্ববিদ্যালয়", Agri: "কৃষি বিশ্ববিদ্যালয় (BAU/SAU/SBAU/KAU)" };
const AI = "Musfiq AI";

/* ---------- state (অ্যাপে ডিভাইসে সংরক্ষিত হয়) ---------- */
const defaults = { onboarded: false, user: null, users: {}, settings: { notif: true, ai: true, greet: true, dark: false, goal: 30 }, history: [], practice: {}, aiSeen: false, bookmarks: [] };
const S = JSON.parse(JSON.stringify(defaults));
try { const saved = window.PersistStore && window.PersistStore.load(); if (saved) { Object.assign(S, saved); S.settings = Object.assign({}, defaults.settings, saved.settings || {}); } } catch (e) {}
const save = () => { try { window.PersistStore && window.PersistStore.save(S); } catch (e) {} };

/* ---------- runtime ---------- */
let R = { screen: "splash", params: {}, stack: [] };
let examTimer = null, splashTimer = null;
let exam = null, lastResult = null;
let chatLog = [];
let greeted = false;
const ui = { subjQuery: "", progTab: "week", obStep: 0, showPass: false, chUni: "all", chYear: "all", chMode: "read", chLimit: 25, picked: {} };

function applyTheme() { document.documentElement.dataset.theme = S.settings.dark ? "dark" : "light"; }
applyTheme();

function go(screen, params = {}, opts = {}) {
  if (!opts.replace && R.screen && R.screen !== screen) R.stack.push({ screen: R.screen, params: R.params });
  if (opts.reset) R.stack = [];
  R.screen = screen; R.params = params;
  render();
}
function back() {
  if (R.screen === "exam") return confirmLeaveExam();
  const prev = R.stack.pop();
  if (prev) { R.screen = prev.screen; R.params = prev.params; render(); }
  else go("home", {}, { reset: true });
}
function toast(msg) {
  const t = document.getElementById("toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove("show"), 2200);
}
const icon = (n, cls = "") => `<i data-lucide="${n}" class="${cls}"></i>`;
const LOGO = `<svg viewBox="0 0 64 64" fill="none" aria-hidden="true"><path d="M8 20c8-3 16-2 23 3v28c-7-5-15-6-23-3z" fill="#fff"/><path d="M56 20c-8-3-16-2-23 3v28c7-5 15-6 23-3z" fill="#DBEAFE"/><path d="M12 25c5-1.5 10-1 15 2M12 31c5-1.5 10-1 15 2M37 27c5-3 10-3.5 15-2M37 33c5-3 10-3.5 15-2" stroke="#93C5FD" stroke-width="1.6" stroke-linecap="round"/><path d="M32 4l2.2 5.6L40 12l-5.8 2.4L32 20l-2.2-5.6L24 12l5.8-2.4z" fill="#FCD34D"/></svg>`;
const topbar = (title, right = "") => `<header class="top"><button class="iconbtn" data-a="back" aria-label="ফিরে যান">${icon("arrow-left")}</button><h1>${title}</h1>${right}</header>`;
const navbar = active => {
  const items = [["home", "house", "হোম"], ["subjects", "book-open", "প্রশ্নব্যাংক"], ["examhub", "clipboard-list", "পরীক্ষা"], ["progress", "chart-column", "অগ্রগতি"], ["settings", "user-round", "প্রোফাইল"]];
  return `<nav class="nav" aria-label="প্রধান মেনু">${items.map(([s, i, l]) => `<button class="${active === s ? "on" : ""}" data-a="nav" data-s="${s}">${icon(i)}<span>${l}</span></button>`).join("")}</nav>`;
};
const initials = n => (n || "অ").trim().charAt(0);
const greet = () => { const h = new Date().getHours(); return h < 12 ? "শুভ সকাল" : h < 17 ? "শুভ অপরাহ্ন" : h < 20 ? "শুভ সন্ধ্যা" : "শুভ রাত্রি"; };
const answeredToday = () => S.history.filter(h => h.date.slice(0, 10) === today()).reduce((a, h) => a + h.answered, 0) + (S.practice[today()] || 0);
const tagHtml = q => q.t && q.t.length ? `<span class="qtags">${q.t.map(t => `<span class="qtag u-${t.split("'")[0]}">[${esc(t)}]</span>`).join("")}</span>` : `<span class="qtags"><span class="qtag prac">অনুশীলনী</span></span>`;
const ansText = q => q.o[q.a];
const qExplain = q => `${q.e ? `<div class="exp-body"><b>ব্যাখ্যা:</b> ${md(q.e)}</div>` : ""}<span class="src">${icon("book-open-check")} সূত্র/উৎস: ${esc(q.src)}${q.kind === "pyq" && q.t.length ? ` • বিগত ভর্তি প্রশ্ন ${q.t.map(t => "[" + esc(t) + "]").join(" ")}` : ""}</span>`;
const kbFor = (pid, ci) => { const name = PAPERS[pid].chapters[ci].name; return KB.find(k => k.s === pid && k.t === name) || KB.find(k => k.s === pid && (k.t.includes(name) || name.includes(k.t))); };
const yearsOf = q => q.t.map(t => t.split("'")[1]).filter(Boolean);

/* ---------- screens ---------- */
const V = {};

V.splash = () => {
  clearTimeout(splashTimer);
  splashTimer = setTimeout(() => { if (R.screen !== "splash") return; go(!S.onboarded ? "ob" : S.user ? "home" : "signin", {}, { reset: true, replace: true }); }, 2400);
  const returning = S.onboarded && S.user;
  return `<section class="screen" data-light><div class="splash" style="background-image:url(img/splash.webp)">
    <div class="logo-tile">${LOGO}</div>
    <div class="brand">অধ্যয়ন</div>
    <div class="tag">স্বপ্নের পথে,<br>প্রস্তুতির প্রযুক্তি পাশে</div>
    <div class="bottom"><div style="font-size:14px;opacity:.95">${returning ? "আপনার স্বপ্ন পূরণে আমরা আছি পাশে" : "আপনার প্রস্তুতি শুরু হচ্ছে..."}</div><div class="loadbar"><span></span></div></div>
  </div></section>`;
};

const OB = [
  ["img/ob1.webp", "সঠিক প্রস্তুতি<br>সফলতার চাবিকাঠি", "বিভিন্ন বিষয়ের MCQ, অধ্যায়ভিত্তিক প্রশ্ন এবং বিস্তারিত ব্যাখ্যা নিয়ে প্রস্তুতি নিন সহজে।"],
  ["img/ob2.webp", "পরীক্ষা দাও,<br>নিজেকে যাচাই করো", "টাইমারসহ মডেল টেস্ট দিন, সাথে সাথে ফলাফল দেখুন এবং দুর্বলতা খুঁজে নিন।"],
  ["img/ob3.webp", "তোমার লক্ষ্য<br>আমাদের লক্ষ্য", "তোমার স্বপ্নের ক্যারিয়ার গড়তে অধ্যয়ন আছে সবসময় তোমার পাশে।"]
];
V.ob = () => {
  const i = ui.obStep, [img, h, p] = OB[i];
  return `<section class="screen obs"><button class="skip" data-a="obskip">এড়িয়ে যান</button><div class="ob">
    <div class="art"><img src="${img}" alt="" width="320" height="280"></div>
    <h2>${h}</h2><p>${p}</p>
    <div class="dots" aria-label="ধাপ ${bn(i + 1)}/৩">${OB.map((_, k) => `<i class="${k === i ? "on" : ""}"></i>`).join("")}</div>
    <button class="btn" data-a="obnext">${i < 2 ? "পরবর্তী" : "শুরু করি"} ${icon("arrow-right")}</button>
  </div></section>`;
};

V.signin = () => `<section class="screen"><div class="scroll"><div class="auth">
  <div class="head"><div class="logo-tile">${LOGO}</div><h2>অধ্যয়ন</h2><p>লগইন করুন</p></div>
  <form data-f="signin" novalidate>
    <div class="field">${icon("user-round")}<input name="id" placeholder="ইমেইল / মোবাইল নম্বর" autocomplete="username" required></div>
    <div class="field">${icon("lock")}<input name="pass" type="${ui.showPass ? "text" : "password"}" placeholder="পাসওয়ার্ড" autocomplete="current-password" required><button type="button" class="eye" data-a="eye" aria-label="পাসওয়ার্ড দেখুন">${icon(ui.showPass ? "eye-off" : "eye")}</button></div>
    <div class="forgot"><button type="button" class="link" data-a="forgot">পাসওয়ার্ড ভুলে গেছেন?</button></div>
    <div class="err" id="err"></div>
    <button class="btn" type="submit">লগইন</button>
  </form>
  <div class="or">অথবা</div>
  <button class="gbtn" data-a="google"><svg width="20" height="20" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.3-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.2-.1-2.3-.4-3.5z"/></svg>Google দিয়ে লগইন</button>
  <p class="alt">নতুন অ্যাকাউন্ট? <button class="link" data-a="to" data-s="register">রেজিস্টার করুন</button></p>
</div></div></section>`;

V.register = () => `<section class="screen">${topbar("নতুন অ্যাকাউন্ট তৈরি করুন")}<div class="scroll"><div class="auth" style="padding-top:6px">
  <p style="color:var(--muted);margin:0 0 18px 4px">সহজ এবং দ্রুত রেজিস্ট্রেশন</p>
  <form data-f="register" novalidate>
    <div class="field">${icon("user-round")}<input name="name" placeholder="নাম" autocomplete="name" required></div>
    <div class="field">${icon("mail")}<input name="id" placeholder="ইমেইল / মোবাইল নম্বর" autocomplete="username" required></div>
    <div class="field">${icon("lock")}<input name="pass" type="${ui.showPass ? "text" : "password"}" placeholder="পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)" autocomplete="new-password" required><button type="button" class="eye" data-a="eye" aria-label="পাসওয়ার্ড দেখুন">${icon(ui.showPass ? "eye-off" : "eye")}</button></div>
    <div class="field">${icon("lock-keyhole")}<input name="pass2" type="${ui.showPass ? "text" : "password"}" placeholder="পাসওয়ার্ড নিশ্চিত করুন" autocomplete="new-password" required></div>
    <div class="err" id="err"></div>
    <button class="btn" type="submit">রেজিস্টার</button>
  </form>
  <p class="alt">আগে থেকে অ্যাকাউন্ট আছে? <button class="link" data-a="to" data-s="signin">লগইন করুন</button></p>
</div></div></section>`;

V.home = () => {
  const u = S.user, done = answeredToday(), goal = S.settings.goal, pct = Math.min(100, Math.round(done / goal * 100));
  const totalPyq = ALLQ.filter(q => q.kind === "pyq").length;
  return `<section class="screen">
  <div class="hello"><button class="avatar" data-a="drawer" aria-label="মেনু খুলুন">${esc(initials(u.name))}</button>
    <div class="who"><small>${greet()},</small><b>${esc(u.name)}</b></div>
    <button class="iconbtn" data-a="drawer" aria-label="মেনু">${icon("menu")}</button>
    <button class="iconbtn" data-a="notifs" aria-label="নোটিফিকেশন">${icon("bell")}${S.settings.notif ? '<span class="dot-badge"></span>' : ""}</button></div>
  <div class="scroll">
    <div class="goal"><div class="ic">${icon("target")}</div><div style="flex:1;position:relative;z-index:1"><small>আজকের লক্ষ্য</small><b>${bn(goal)}টি MCQ অনুশীলন করুন</b><div class="bar"><span style="width:${pct}%"></span></div><small>${bn(Math.min(done, goal))}/${bn(goal)} সম্পন্ন${pct >= 100 ? " — দারুণ!" : ""}</small></div></div>
    <div class="unit-banner">${icon("graduation-cap")}<div><b>ভার্সিটি “ক/A” ইউনিট ভর্তি প্রস্তুতি</b><small>DU • JU • RU • CU • JnU • KU • CoU • HSTU • GST • Agri — ২০১৫-১৬ থেকে ${bn(totalPyq)}টি আসল প্রশ্ন, অধ্যায়ভিত্তিক</small></div></div>
    <div class="sec-title">বিষয়সমূহ <button data-a="nav" data-s="subjects">সব দেখুন</button></div>
    <div class="grid2">${SUBJ.map(s => `<button class="tile" data-a="subj" data-id="${s.id}"><span class="ic" style="background:${s.bg};color:${s.color}">${icon(s.icon)}</span>${s.name}<small class="tile-sub">১ম ও ২য় পত্র • ${bn(s.total)} প্রশ্ন</small></button>`).join("")}</div>
    <div class="sec-title">দ্রুত কাজ</div>
    <div class="quick">
      <button data-a="mixexam"><span class="ic">${icon("shuffle")}</span>মিশ্র পরীক্ষা</button>
      <button data-a="to" data-s="formulas"><span class="ic">${icon("sigma")}</span>সূত্র ও তথ্য</button>
      <button data-a="ai"><span class="ic">${icon("calculator")}</span>অঙ্ক সমাধান</button>
    </div>
  </div>${S.settings.ai ? peekBot() : ""}${navbar("home")}</section>`;
};
let peekShown = false;
function peekBot() {
  const first = !peekShown; peekShown = true;
  const wave = S.settings.greet !== false;
  return `<button class="peek ${first ? "intro" : ""} ${wave ? "waving" : ""}" data-a="ai" aria-label="${AI} — হাত নেড়ে Hi বলছে, চ্যাট খুলতে চাপো"><span class="peek-bot"><span class="peek-fig"><img src="img/robot_body.webp" alt="" width="240" height="360"><img class="peek-hand" src="img/robot_hand.webp" alt="" width="240" height="360"></span></span></button>`;
}

const paperStats = pid => { const h = S.history.filter(x => x.pid === pid); const t = h.reduce((a, x) => a + x.total, 0), c = h.reduce((a, x) => a + x.correct, 0); return { n: h.length, acc: t ? Math.round(c / t * 100) : 0 }; };

V.subjects = () => {
  const q = ui.subjQuery.trim();
  const chapHits = q ? Object.values(PAPERS).flatMap(p => p.chapters.map((c, i) => ({ p, c, i })).filter(x => x.c.name.includes(q))) : [];
  return `<section class="screen">${topbar("প্রশ্নব্যাংক")}<div class="scroll">
    <div class="search">${icon("search")}<input id="sq" placeholder="অধ্যায় খুঁজুন... (যেমন: ভেক্টর)" value="${esc(ui.subjQuery)}" aria-label="অধ্যায় খুঁজুন"></div>
    <div id="slist">${q ? (chapHits.length ? chapHits.map(({ p, c, i }) => `<button class="row" data-a="chapter" data-p="${p.id}" data-i="${i}"><span class="ic" style="background:var(--mist);color:var(--primary)">${icon("book-marked")}</span><span class="t"><b>${c.name}</b><small>${p.short} • অধ্যায় ${bn(i + 1)} • ${bn(c.qs.length)} প্রশ্ন</small></span>${icon("chevron-right", "chev")}</button>`).join("") : `<div class="empty">${icon("search-x")}<b>কোনো অধ্যায় পাওয়া যায়নি</b>অন্য নাম লিখে চেষ্টা করুন</div>`)
    : SUBJ.map(s => `<div class="subj-block"><div class="subj-h"><span class="ic" style="background:${s.bg};color:${s.color}">${icon(s.icon)}</span><b>${s.name}</b></div>${s.papers.map(pid => { const p = PAPERS[pid]; return `<button class="row" data-a="paper" data-p="${pid}"><span class="ic paper-ic" style="background:${s.bg};color:${s.color}">${pid.endsWith("1") ? "১ম" : "২য়"}</span><span class="t"><b>${p.name}</b><small>${bn(p.chapters.length)}টি অধ্যায় • ${bn(p.total)}টি প্রশ্ন</small></span>${icon("chevron-right", "chev")}</button>`; }).join("")}</div>`).join("")}</div>
  </div>${navbar("subjects")}</section>`;
};

V.subj = () => {
  const s = subById(R.params.id);
  return `<section class="screen">${topbar(s.name)}<div class="scroll">
    ${s.papers.map(pid => { const p = PAPERS[pid]; return `<button class="row" data-a="paper" data-p="${pid}"><span class="ic paper-ic" style="background:${s.bg};color:${s.color}">${pid.endsWith("1") ? "১ম" : "২য়"}</span><span class="t"><b>${p.name}</b><small>${bn(p.chapters.length)}টি অধ্যায় • ${bn(p.total)}টি প্রশ্ন</small></span>${icon("chevron-right", "chev")}</button>`; }).join("")}
  </div></section>`;
};

V.paper = () => {
  const p = PAPERS[R.params.p], s = subById(p.sub), st = paperStats(p.id);
  return `<section class="screen">${topbar(p.short)}<div class="scroll">
    <div class="subhead"><span class="ic" style="background:${s.bg};color:${s.color}">${icon(s.icon)}</span><div><b style="font-size:17px">${p.name}</b><br><small>${bn(p.chapters.length)}টি অধ্যায় • ${bn(p.total)}টি প্রশ্ন${st.n ? ` • সঠিকতা ${bn(st.acc)}%` : ""}</small></div></div>
    ${p.chapters.map((c, i) => `<button class="row" data-a="chapter" data-p="${p.id}" data-i="${i}"><span class="ic chno">${bn(i + 1)}</span><span class="t"><b>${c.name}</b><small>${bn(c.pyq)}টি ভর্তি প্রশ্ন${c.qs.length - c.pyq ? ` • ${bn(c.qs.length - c.pyq)}টি অনুশীলনী` : ""}</small></span>${icon("chevron-right", "chev")}</button>`).join("")}
  </div>
  <div class="footer-cta"><button class="btn sm" data-a="paperexam" data-p="${p.id}">${icon("play")} পুরো পত্রের পরীক্ষা (৫০টি)</button></div></section>`;
};

const chapterList = (p, ci) => {
  const c = PAPERS[p].chapters[ci];
  return c.qs.filter(q => (ui.chUni === "all" || (ui.chUni === "prac" ? q.kind === "prac" : q.t.some(t => t.startsWith(ui.chUni + "'")))) && (ui.chYear === "all" || yearsOf(q).includes(ui.chYear)));
};
const YEARS = ["25-26", "24-25", "23-24", "22-23", "21-22", "20-21", "19-20", "18-19", "17-18", "16-17", "15-16"];
V.chapter = () => {
  window.__loadExp && window.__loadExp(R.params.p);
  const { p, i } = R.params, P = PAPERS[p], c = P.chapters[i], list = chapterList(p, i), shown = list.slice(0, ui.chLimit), kb = kbFor(p, i);
  const cnt = u => c.qs.filter(q => u === "prac" ? q.kind === "prac" : q.t.some(t => t.startsWith(u + "'"))).length;
  const card = (q, n) => {
    const pk = ui.picked[q.id], reveal = ui.chMode === "read" || pk != null;
    return `<div class="qcard pq"><div class="qhead"><span class="qno">${bn(n + 1)}.</span>${tagHtml(q)}</div>
      <div class="qtext">${tx(q.q)}</div>${q.img ? `<img class="qimg" src="${esc(q.img)}" alt="প্রশ্নের চিত্র" loading="lazy">` : ""}
      <div class="opts2">${q.o.map((o, k) => `<button class="opt ${reveal ? (k === q.a ? "right" : k === pk ? "wrong" : "") : ""}" data-a="cpick" data-id="${q.id}" data-k="${k}" ${reveal ? "disabled" : ""}><span class="k">${LETTERS[k]}</span><span>${tx(o)}</span></button>`).join("")}</div>
      ${reveal ? `<div class="exp">${icon("lightbulb")} সঠিক উত্তর: <b>(${LETTERS[q.a]}) <span>${tx(ansText(q))}</span></b><br>${qExplain(q)}<button class="ask-ai" data-a="askai" data-id="${q.id}">${icon("sparkles")} ${AI}-কে জিজ্ঞেস করো</button></div>` : ""}</div>`;
  };
  return `<section class="screen">${topbar(`অধ্যায় ${bn(+i + 1)}`, kb ? `<button class="iconbtn" data-a="kb" data-p="${p}" data-i="${i}" aria-label="সূত্র ও তথ্য">${icon("sigma")}</button>` : "")}<div class="scroll">
    <div class="chap-h"><small>${P.name}</small><b>${c.name}</b><span>${bn(c.pyq)}টি বিগত ভর্তি প্রশ্ন (২০১৫-১৬ থেকে) • ${bn(c.qs.length - c.pyq)}টি অনুশীলনী</span></div>
    ${kb ? `<button class="kb-mini" data-a="kb" data-p="${p}" data-i="${i}">${icon("sigma")} এই অধ্যায়ের গুরুত্বপূর্ণ সূত্র ও তথ্য ${icon("chevron-right")}</button>` : ""}
    <div class="chips">${[["all", "সব"], ...UNIS.map(u => [u, u]), ["prac", "অনুশীলনী"]].map(([k, l]) => `<button class="chip ${ui.chUni === k ? "on" : ""}" data-a="chuni" data-k="${k}">${l}${k === "all" ? "" : ` (${bn(cnt(k))})`}</button>`).join("")}</div>
    <div class="chips yr">${[["all", "সব সাল"], ...YEARS.map(y => [y, "'" + y])].map(([k, l]) => `<button class="chip sm ${ui.chYear === k ? "on" : ""}" data-a="chyear" data-k="${k}">${bn(l)}</button>`).join("")}</div>
    <div class="tabs"><button class="${ui.chMode === "read" ? "on" : ""}" data-a="chmode" data-k="read">${icon("book-open")} পড়ার মোড</button><button class="${ui.chMode === "quiz" ? "on" : ""}" data-a="chmode" data-k="quiz">${icon("pointer")} অনুশীলন মোড</button></div>
    <div class="list-meta">${bn(list.length)}টি প্রশ্ন দেখানো হচ্ছে</div>
    ${shown.length ? shown.map(card).join("") : `<div class="empty">${icon("filter-x")}<b>এই ফিল্টারে কোনো প্রশ্ন নেই</b>অন্য বিশ্ববিদ্যালয় বা সাল বেছে নিন</div>`}
    ${list.length > shown.length ? `<button class="btn ghost" data-a="more">আরও ${bn(Math.min(25, list.length - shown.length))}টি দেখুন (বাকি ${bn(list.length - shown.length)})</button>` : ""}
  </div>
  <div class="footer-cta"><button class="btn sm" data-a="chexam" data-p="${p}" data-i="${i}" ${list.length ? "" : "disabled"}>${icon("play")} অধ্যায় পরীক্ষা (${bn(Math.min(25, list.length))}টি প্রশ্ন)</button></div></section>`;
};

V.formulas = () => `<section class="screen">${topbar("সূত্র ও গুরুত্বপূর্ণ তথ্য")}<div class="scroll">
  ${SUBJ.map(s => `<div class="subj-block"><div class="subj-h"><span class="ic" style="background:${s.bg};color:${s.color}">${icon(s.icon)}</span><b>${s.name}</b></div>${s.papers.map(pid => PAPERS[pid].chapters.map((c, i) => kbFor(pid, i) ? `<button class="row slim" data-a="kb" data-p="${pid}" data-i="${i}"><span class="t"><b>${c.name}</b><small>${PAPERS[pid].short}</small></span>${icon("chevron-right", "chev")}</button>` : "").join("")).join("")}</div>`).join("")}
  ${KB.filter(k => k.s === "gen").map(k => `<button class="row slim" data-a="kbg" data-t="${esc(k.t)}"><span class="t"><b>${k.t}</b><small>সাধারণ</small></span>${icon("chevron-right", "chev")}</button>`).join("")}
</div></section>`;
function showKB(k) {
  if (!k) return;
  sheet(k.t, `<ul class="kb-list">${k.b.map(l => `<li>${tx(l)}</li>`).join("")}</ul><div class="src">${icon("book-open-check")} উৎস: HSC NCTB পাঠ্যবই ও ভর্তি সহায়িকা</div>`, null, null, "বন্ধ করুন");
  typeset(document.getElementById("ov"));
}

V.examhub = () => `<section class="screen">${topbar("পরীক্ষা ও টাইমার")}<div class="scroll">
  <button class="goal" data-a="mixexam" style="width:100%;text-align:left;margin-bottom:6px"><div class="ic">${icon("shuffle")}</div><div style="flex:1;position:relative;z-index:1"><small>মডেল টেস্ট</small><b>“ক/A” ইউনিট মিশ্র পরীক্ষা — ৪০টি</b><small>সময়: ৪০ মিনিট • ৪ বিষয়ের ৮ পত্র থেকে আসল ভর্তি প্রশ্ন</small></div>${icon("chevron-right")}</button>
  <div class="sec-title">বিশ্ববিদ্যালয়ভিত্তিক পরীক্ষা</div>
  <div class="chips" style="flex-wrap:wrap">${UNIS.map(u => `<button class="chip" data-a="uniexam" data-u="${u}">${u} প্রশ্ন (৪০টি)</button>`).join("")}</div>
  <div class="sec-title">পত্রভিত্তিক পরীক্ষা</div>
  ${Object.values(PAPERS).map(p => { const s = subById(p.sub), st = paperStats(p.id); return `<button class="row" data-a="paperexam" data-p="${p.id}"><span class="ic" style="background:${s.bg};color:${s.color}">${icon(s.icon)}</span><span class="t"><b>${p.name}</b><small>৫০টি প্রশ্ন • ৫০ মিনিট${st.n ? ` • সেরা ${bn(bestOf(p.id))}%` : ""}</small></span><span class="dl">${icon("play")}</span></button>`; }).join("")}
</div>${navbar("examhub")}</section>`;
const bestOf = pid => Math.max(...S.history.filter(h => h.pid === pid).map(h => Math.round(h.correct / h.total * 100)));

function startExam(title, pool, n, pid = null) {
  const qs = shuffle(pool).slice(0, n);
  if (!qs.length) return toast("এই অংশে কোনো প্রশ্ন নেই");
  exam = { title, pid, qs, ans: Array(qs.length).fill(null), cur: 0, total: qs.length * 60, left: qs.length * 60, again: { title, pool, n, pid } };
  go("exam");
  clearInterval(examTimer);
  examTimer = setInterval(() => {
    if (!exam) return clearInterval(examTimer);
    exam.left--;
    const el = document.getElementById("tm");
    if (el) { el.textContent = fmt(exam.left); el.parentElement.classList.toggle("warn", exam.left <= 60); }
    if (exam.left <= 0) { toast("সময় শেষ! উত্তরপত্র জমা হয়েছে"); finishExam(); }
  }, 1000);
}
const pyqOnly = arr => { const p = arr.filter(q => q.kind === "pyq"); return p.length >= 10 ? p : arr; };
const fmt = s => bn([Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60].map(x => String(x).padStart(2, "0")).join(":"));

V.exam = () => {
  const e = exam, q = e.qs[e.cur], answered = e.ans.filter(a => a !== null).length;
  return `<section class="screen">${topbar(esc(e.title), `<button class="iconbtn" data-a="submitask" aria-label="জমা দিন">${icon("send")}</button>`)}<div class="scroll">
    <div class="timer-card"><div class="timer ${e.left <= 60 ? "warn" : ""}">${icon("alarm-clock")}<span id="tm">${fmt(e.left)}</span></div>
      <div class="timer-meta"><span>উত্তর দেওয়া: <b>${bn(answered)}</b></span><span>বাকি: <b>${bn(e.qs.length - answered)}</b></span></div>
      <div class="qprog"><span style="width:${(e.cur + 1) / e.qs.length * 100}%"></span></div></div>
    <div class="qcard"><div class="qn">প্রশ্ন ${bn(e.cur + 1)}/${bn(e.qs.length)} • ${PAPERS[q.pid].short} ${tagHtml(q)}</div><h3>${tx(q.q)}</h3>${q.img ? `<img class="qimg" src="${esc(q.img)}" alt="প্রশ্নের চিত্র">` : ""}
      ${q.o.map((o, k) => `<button class="opt ${e.ans[e.cur] === k ? "sel" : ""}" data-a="pick" data-k="${k}"><span class="k">${LETTERS[k]}</span><span>${tx(o)}</span></button>`).join("")}
    </div>
    <div class="qdots" aria-label="প্রশ্ন তালিকা">${e.qs.map((_, i) => `<button class="${e.ans[i] !== null ? "a" : ""} ${i === e.cur ? "cur" : ""}" data-a="jump" data-i="${i}">${bn(i + 1)}</button>`).join("")}</div>
  </div>
  <div class="exam-foot"><button class="btn ghost sm" data-a="prev" ${e.cur === 0 ? "disabled" : ""}>${icon("chevron-left")} পূর্ববর্তী</button>
  ${e.cur < e.qs.length - 1 ? `<button class="btn sm" data-a="next">পরবর্তী ${icon("chevron-right")}</button>` : `<button class="btn green sm" data-a="submitask">জমা দিন ${icon("check")}</button>`}</div></section>`;
};

function finishExam() {
  clearInterval(examTimer);
  const e = exam; if (!e) return;
  let correct = 0, wrong = 0, skipped = 0;
  e.qs.forEach((q, i) => { const a = e.ans[i]; if (a === null) skipped++; else if (a === q.a) correct++; else wrong++; });
  const rec = { title: e.title, pid: e.pid, total: e.qs.length, correct, wrong, skipped, answered: correct + wrong, time: e.total - e.left, date: new Date().toISOString() };
  S.history.push(rec); save();
  lastResult = { ...rec, qs: e.qs, ans: e.ans, again: e.again };
  exam = null;
  R.stack = R.stack.filter(x => x.screen !== "exam");
  go("result", {}, { replace: true });
}
function confirmLeaveExam() {
  sheet("পরীক্ষা ছেড়ে যাবেন?", "এখন বের হলে এই পরীক্ষার উত্তরগুলো সংরক্ষিত হবে না।", "বের হন", () => { clearInterval(examTimer); exam = null; const p = R.stack.pop(); if (p) { R.screen = p.screen; R.params = p.params; render(); } else go("home", {}, { reset: true }); }, "পরীক্ষা চালিয়ে যান");
}

V.result = () => {
  const r = lastResult; if (!r) return V.home();
  const pct = Math.round(r.correct / r.total * 100);
  const msg = pct >= 80 ? "অসাধারণ! চমৎকার প্রস্তুতি" : pct >= 60 ? "ভালো করেছেন! আরও একটু চর্চা" : pct >= 40 ? "চলনসই — দুর্বল অধ্যায়গুলো দেখুন" : "হাল ছাড়বেন না, আবার চেষ্টা করুন";
  return `<section class="screen">${topbar("পরীক্ষার ফলাফল")}<div class="scroll">
    <div class="hero-res"><div class="mtn"></div><img src="img/trophy.webp" alt="ট্রফি" width="120" height="120">
      <div class="score-box"><small>মোট স্কোর</small><b>${bn(r.correct)}<span>/${bn(r.total)}</span></b><em>${bn(pct)}%</em></div>
      <p style="position:relative;margin-top:10px;font-weight:700;color:var(--navy)">${msg}</p></div>
    <div class="statlist">
      <div><i style="background:var(--green)"></i>সঠিক<b style="color:var(--green-d)">${bn(r.correct)}</b></div>
      <div><i style="background:var(--red)"></i>ভুল<b style="color:var(--red)">${bn(r.wrong)}</b></div>
      <div><i style="background:var(--primary-2)"></i>উত্তরহীন<b>${bn(r.skipped)}</b></div>
      <div><i style="background:var(--amber)"></i>সময় লেগেছে<b>${bn(Math.floor(r.time / 60))} মি ${bn(r.time % 60)} সে</b></div>
    </div>
    <button class="btn" data-a="to" data-s="review">${icon("list-checks")} বিস্তারিত দেখুন</button>
    <div style="height:10px"></div>
    <button class="btn green" data-a="retry">${icon("rotate-ccw")} আবার চেষ্টা করুন</button>
  </div></section>`;
};

V.review = () => {
  const r = lastResult;
  return `<section class="screen">${topbar("উত্তর পর্যালোচনা")}<div class="scroll">
  ${r.qs.map((q, i) => { const a = r.ans[i]; return `<div class="qcard pq"><div class="qhead"><span class="qno">${bn(i + 1)}.</span>${tagHtml(q)}<span class="res-st ${a === null ? "" : a === q.a ? "ok" : "bad"}">${a === null ? "উত্তরহীন" : a === q.a ? "সঠিক" : "ভুল"}</span></div><div class="qtext">${tx(q.q)}</div>${q.img ? `<img class="qimg" src="${esc(q.img)}" alt="প্রশ্নের চিত্র">` : ""}
    ${q.o.map((o, k) => `<div class="opt ${k === q.a ? "right" : k === a ? "wrong" : ""}" style="cursor:default"><span class="k">${LETTERS[k]}</span><span>${tx(o)}</span></div>`).join("")}<div class="exp">${icon("lightbulb")} সঠিক উত্তর: <b>(${LETTERS[q.a]}) <span>${tx(ansText(q))}</span></b><br>${qExplain(q)}</div></div>`; }).join("")}
  </div></section>`;
};

V.progress = () => {
  const tab = ui.progTab, now = Date.now(), win = tab === "week" ? 7 : tab === "month" ? 30 : 1e5;
  const H = S.history.filter(h => now - new Date(h.date) < win * 864e5);
  const total = H.reduce((a, h) => a + h.total, 0), correct = H.reduce((a, h) => a + h.correct, 0), answered = H.reduce((a, h) => a + h.answered, 0);
  const acc = total ? Math.round(correct / total * 100) : 0, ansAcc = answered ? Math.round(correct / answered * 100) : 0;
  const mins = Math.round(H.reduce((a, h) => a + h.time, 0) / 60);
  const C = 2 * Math.PI * 70, off = C * (1 - acc / 100);
  const byP = Object.values(PAPERS).map(p => { const h = H.filter(x => x.pid === p.id); const t = h.reduce((a, x) => a + x.total, 0); return { p, s: subById(p.sub), v: t ? Math.round(h.reduce((a, x) => a + x.correct, 0) / t * 100) : null }; }).filter(x => x.v !== null);
  return `<section class="screen">${topbar("আমার অগ্রগতি")}<div class="scroll">
    <div class="tabs"><button class="${tab === "week" ? "on" : ""}" data-a="ptab" data-t="week">সাপ্তাহিক</button><button class="${tab === "month" ? "on" : ""}" data-a="ptab" data-t="month">মাসিক</button><button class="${tab === "all" ? "on" : ""}" data-a="ptab" data-t="all">সর্বমোট</button></div>
    ${H.length ? `
    <div class="ring-wrap"><div class="ring"><svg viewBox="0 0 160 160"><circle cx="80" cy="80" r="70" stroke="var(--surface-2)" stroke-width="14" fill="none"/><circle cx="80" cy="80" r="70" stroke="#15803D" stroke-width="14" fill="none" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${off}" style="transition:stroke-dashoffset .8s"/></svg><div class="c"><div><b>${bn(acc)}%</b><br><small>গড় স্কোর</small></div></div></div></div>
    <div class="stats">
      <div class="stat"><small>মোট প্রশ্ন</small><b>${bn(total)}</b></div>
      <div class="stat"><small>সঠিকতার হার</small><b>${bn(ansAcc)}%</b></div>
      <div class="stat"><small>মোট পরীক্ষা</small><b>${bn(H.length)}টি</b></div>
      <div class="stat"><small>অধ্যয়নের সময়</small><b>${bn(mins)} মিনিট</b></div>
    </div>
    ${byP.length ? `<div class="sec-title">পত্রভিত্তিক ফলাফল</div><div class="bars">${byP.map(({ p, s, v }) => `<div class="barrow"><span>${p.short.replace("উচ্চতর ", "")}</span><span class="tr"><span style="width:${v}%;background:${s.color}"></span></span><b>${bn(v)}%</b></div>`).join("")}</div>` : ""}
    <div class="sec-title">সাম্প্রতিক পরীক্ষা</div>
    ${H.slice().reverse().slice(0, 8).map(h => `<div class="row"><span class="ic" style="background:var(--mist);color:var(--primary)">${icon("clipboard-check")}</span><span class="t"><b>${esc(h.title)}</b><small>${bn(new Date(h.date).toLocaleDateString("bn-BD"))}</small></span><b>${bn(h.correct)}/${bn(h.total)}</b></div>`).join("")}
    ` : `<div class="empty" style="margin-top:20px">${icon("chart-no-axes-column")}<b>এখনও কোনো পরীক্ষা নেই</b>প্রথম পরীক্ষা দিলেই এখানে আপনার অগ্রগতি দেখা যাবে।<div style="height:14px"></div><button class="btn sm" data-a="nav" data-s="examhub">পরীক্ষা শুরু করুন</button></div>`}
  </div>${navbar("progress")}</section>`;
};

/* ---------- Musfiq AI (সম্পূর্ণ ফ্রি, ডিভাইসেই চলে) ---------- */
const STOP = new Set("কোনটি কোন কত কি কী এর এবং হলে হয় হবে নিচের নিম্নের একটি থেকে জন্য সাথে করে করা দিয়ে আছে ছিল তার যদি তবে বা ও the of and is a an to in what which".split(" "));
const clean = s => String(s).replace(/\\(mathrm|text|mathbf|left|right|frac|times|cdot|quad|hat|vec|overrightarrow|sqrt|rm)/g, " ").replace(/[{}$\\^_~,;:()\[\]|?।!"'“”‘’\-–—=+*/<>.]/g, " ").toLowerCase();
const toks = s => clean(s).split(/\s+/).filter(w => w && (w.length > 1 || /\d/.test(w)) && !STOP.has(w));
let QIDX = null;
const qIndex = () => QIDX || (QIDX = ALLQ.map(q => ({ q, set: new Set(toks(q.q + " " + q.o.join(" "))), qs: new Set(toks(q.q)) })));
function findQuestion(text) {
  const T = [...new Set(toks(text))]; if (T.length < 2) return null;
  let best = null, bs = 0;
  for (const it of qIndex()) {
    let hit = 0; for (const w of T) if (it.set.has(w)) hit++;
    if (!hit) continue;
    const sc = hit / Math.sqrt(T.length * Math.max(it.set.size, 1));
    if (sc > bs) { bs = sc; best = it.q; }
  }
  return best ? { q: best, score: bs } : null;
}
function findKB(text) {
  const KSTOP = /^(সূত্র|সূত্রগুলো|সূত্রসমূহ|ফর্মুলা|formula|তথ্য|গুরুত্বপূর্ণ|দাও|বলো|চাই|অধ্যায়|অধ্যায়ের|পত্র|পত্রের|১ম|২য়|কর|করো|লিখ|দেখাও)$/;
  const T = toks(text).filter(w => !KSTOP.test(w)); if (!T.length) return [];
  return KB.map(k => { const hay = clean(k.t + " " + k.k + " " + k.b.join(" ")), title = clean(k.t + " " + k.k); let sc = 0; T.forEach(w => { if (title.includes(w)) sc += 3; else if (hay.includes(w)) sc += 1; }); if (text.includes(k.t)) sc += 8; return { k, sc }; }).filter(x => x.sc >= 3).sort((a, b) => b.sc - a.sc).filter((x, i, arr) => i === 0 || (i === 1 && x.sc >= arr[0].sc * 0.75)).slice(0, 2).map(x => x.k);
}
const PAPER_ALIAS = [["phy1", /পদার্থ.*(১ম|1)|physics.*1/], ["phy2", /পদার্থ.*(২য়|2)|physics.*2/], ["chem1", /রসায়ন.*(১ম|1)|chem.*1/], ["chem2", /রসায়ন.*(২য়|2)|chem.*2/], ["math1", /গণিত.*(১ম|1)|math.*1/], ["math2", /গণিত.*(২য়|2)|math.*2/], ["bio1", /(জীব|উদ্ভিদ).*(১ম|1)|bio.*1|উদ্ভিদবিজ্ঞান/], ["bio2", /(জীব|প্রাণি).*(২য়|2)|bio.*2|প্রাণিবিজ্ঞান/]];
const SUB_ALIAS = [["phy", /পদার্থ|physics/], ["chem", /রসায়ন|chem/], ["math", /গণিত|math/], ["bio", /জীব|bio/]];
const kbHtml = k => `<b>${esc(k.t)}</b> — গুরুত্বপূর্ণ সূত্র/তথ্য:\n${k.b.map(l => "• " + esc(l)).join("\n")}\n<span class="src">উৎস: HSC NCTB পাঠ্যবই${k.s !== "gen" ? ` (${PAPERS[k.s].short})` : ""} ও ভর্তি সহায়িকা</span>`;
const ansHtml = (q, lead) => `${lead}\n\n<b>${tx(q.q)}</b>\n${q.o.map((o, k) => `${k === q.a ? "✅" : "▫️"} (${LETTERS[k]}) ${tx(o)}`).join("\n")}\n\n<b>সঠিক উত্তর: (${LETTERS[q.a]}) ${tx(ansText(q))}</b>${q.t.length ? `\n${tagHtml(q)}` : ""}${q.e ? `\n<b>ব্যাখ্যা:</b> ${md(q.e)}` : ""}\n<span class="src">সূত্র/উৎস: ${esc(q.src)}</span>`;
const isMathy = q => /^(phy|chem|math)/.test(q.pid);
function aiReply(text) {
  const t = text.toLowerCase();
  const pid = (PAPER_ALIAS.find(([, r]) => r.test(t)) || [])[0];
  const sid = (SUB_ALIAS.find(([, r]) => r.test(t)) || [])[0];
  if (/^(hi|hello|hey|হাই|হ্যালো|সালাম|আসসালামু)/.test(t.trim())) return { html: `Hi! 👋 আমি ${AI}। HSC ও ভার্সিটি “ক” ইউনিট ভর্তির জন্য সূত্র, তথ্য, বিগত প্রশ্নের উত্তর — সব বলতে পারি। যেকোনো প্রশ্ন করো — ব্যাখ্যাসহ উত্তর দেব, অঙ্ক হলে ধাপে ধাপে সমাধান করে দেখাব।`, sugg: ["পদার্থ ১ম পত্রের সূত্র", "একটা ভর্তি প্রশ্ন দাও", "পরীক্ষার টিপস"] };
  if (/ধন্যবাদ|thanks|thank/.test(t)) return { html: "তোমাকেও ধন্যবাদ! পড়াশোনা চালিয়ে যাও, আমি পাশে আছি 💙" };
  if (/প্রশ্ন দাও|কুইজ|quiz|প্রশ্ন চাই|আরেকটা|আরও প্রশ্ন/.test(t)) {
    let pool = ALLQ.filter(q => q.kind === "pyq");
    if (pid) pool = pool.filter(q => q.pid === pid); else if (sid) pool = pool.filter(q => PAPERS[q.pid].sub === sid);
    const u = UNIS.find(u => t.includes(u.toLowerCase())); if (u) pool = pool.filter(q => q.t.some(x => x.startsWith(u + "'")));
    const q = pool[Math.random() * pool.length | 0] || ALLQ[0];
    return { html: `<b>${PAPERS[q.pid].short}</b> — ${PAPERS[q.pid].chapters[q.ci].name} ${tagHtml(q)}\n${tx(q.q)}`, quiz: { q, picked: null }, sugg: ["আরেকটা প্রশ্ন দাও"] };
  }
  if (/টিপস|tips|কৌশল|কিভাবে পড়|কীভাবে পড়|রুটিন/.test(t)) { const k = KB.find(k => k.s === "gen" && /টিপস|কৌশল/.test(k.t)); return { html: k ? kbHtml(k) : "প্রতিদিন অধ্যায়ভিত্তিক বিগত প্রশ্ন অনুশীলন করো, ভুলগুলো নোট করো, সপ্তাহে একটি পূর্ণ মডেল টেস্ট দাও।", sugg: ["মিশ্র পরীক্ষা দিতে চাই", "একটা ভর্তি প্রশ্ন দাও"] }; }
  if (/মিশ্র|মডেল টেস্ট/.test(t)) return { html: "দারুণ! “ক” ইউনিট মিশ্র পরীক্ষায় ৮ পত্র থেকে ৪০টি আসল ভর্তি প্রশ্ন থাকবে, সময় ৪০ মিনিট।", action: "mix" };
  if (/অগ্রগতি|রেজাল্ট|ফলাফল|স্কোর/.test(t)) { const h = S.history; if (!h.length) return { html: "তুমি এখনও কোনো পরীক্ষা দাওনি। একটি পরীক্ষা দিলেই আমি তোমার অগ্রগতি বিশ্লেষণ করে দেব।", action: "mix" }; const tot = h.reduce((a, x) => a + x.total, 0), c = h.reduce((a, x) => a + x.correct, 0); const weak = Object.keys(PAPERS).map(p => ({ p, ...paperStats(p) })).filter(x => x.n).sort((a, b) => a.acc - b.acc)[0]; return { html: `এ পর্যন্ত ${bn(h.length)}টি পরীক্ষায় ${bn(tot)}টির মধ্যে ${bn(c)}টি সঠিক (${bn(Math.round(c / tot * 100))}%)।${weak ? `\n\n${PAPERS[weak.p].name}-এ সঠিকতা তুলনামূলক কম (${bn(weak.acc)}%) — এই পত্রে আরও চর্চা করো।` : ""}` }; }
  const wantsFormula = /সূত্র|ফর্মুলা|formula|তথ্য|মান কত|ধ্রুবক|একক|মাত্রা/.test(t);
  if (wantsFormula && pid && !findKB(text.replace(/সূত্র|ফর্মুলা|তথ্য|পত্রের|পত্র|১ম|২য়|পদার্থ|রসায়ন|গণিত|জীববিজ্ঞান/g, "")).length) {
    return { html: `${PAPERS[pid].name}-এর কোন অধ্যায়ের সূত্র/তথ্য চাও?`, sugg: PAPERS[pid].chapters.filter((_, i) => kbFor(pid, i)).map(c => `${c.name} এর সূত্র`) };
  }
  const kb = findKB(text);
  const m = findQuestion(text);
  const shortQ = toks(text).length < 4;
  if (m && m.score > 0.42 && !((wantsFormula || shortQ) && kb.length)) return { html: ansHtml(m.q, "প্রশ্নব্যাংকে এই প্রশ্নটি পেয়েছি:"), sugg: kb.length ? [`${kb[0].t} এর সূত্র`] : null };
  if (kb.length) return { html: kb.map(kbHtml).join("\n\n"), sugg: ["একটা ভর্তি প্রশ্ন দাও"] };
  if (m && m.score > 0.25) return { html: ansHtml(m.q, "হুবহু মিল পাইনি, তবে সবচেয়ে কাছাকাছি প্রশ্নটি:") };
  if (wantsFormula || sid) { const s = sid ? subById(sid) : null; return { html: `কোন পত্র/অধ্যায়ের সূত্র চাও? ${s ? s.name + "-এর পত্র বেছে নাও:" : "নিচ থেকে বেছে নাও:"}`, sugg: (s ? s.papers : Object.keys(PAPERS)).map(p => `${PAPERS[p].short} এর সূত্র`) }; }
  return { html: `দুঃখিত, এ বিষয়ে আমার কাছে এখনও নিশ্চিত তথ্য নেই — ভুল উত্তর দিতে চাই না।\nপ্রশ্নটি হুবহু লিখে দেখো, অথবা অধ্যায়ের নাম লিখে “সূত্র” লেখো (যেমন: “ভেক্টর এর সূত্র”)।`, sugg: ["পদার্থ ১ম পত্রের সূত্র", "একটা ভর্তি প্রশ্ন দাও", "আমার অগ্রগতি কেমন?"] };
}
/* ---------- Markdown + গণিত রেন্ডার (নিরাপদ) ---------- */
function md(src) {
  let s = String(src ?? "").replace(/\r/g, "");
  const M = [];
  s = s.replace(/\$\$[\s\S]+?\$\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\)|\$[^$\n]+?\$/g, m => { M.push(m); return `\u0000${M.length - 1}\u0000`; });
  const inline = t => esc(t).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/__(.+?)__/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>").replace(/(^|[\s(])\*(?!\s)([^*]+?)\*(?=[\s).,।:]|$)/g, "$1$2");
  const lines = s.split("\n"), out = [];
  for (let i = 0; i < lines.length; i++) {
    const L = lines[i], t = L.trim();
    if (/^\|.*\|$/.test(t)) {
      const rows = [];
      while (i < lines.length && /^\|.*\|$/.test(lines[i].trim())) { const r = lines[i].trim(); if (!/^\|[\s:|-]+\|$/.test(r)) rows.push(r.slice(1, -1).split("|").map(c => inline(c.trim()))); i++; }
      i--;
      out.push(`<div class="md-tbl"><table>${rows.map((r, k) => `<tr>${r.map(c => k ? `<td>${c}</td>` : `<th>${c}</th>`).join("")}</tr>`).join("")}</table></div>`);
      continue;
    }
    if (!t) { out.push('<span class="md-gap"></span>'); continue; }
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(t)) { out.push("<hr>"); continue; }
    let m;
    if ((m = t.match(/^#{1,6}\s+(.*)$/))) { out.push(`<span class="md-h">${inline(m[1].replace(/\*\*/g, ""))}</span>`); continue; }
    if ((m = t.match(/^[-*•]\s+(.*)$/))) { out.push(`<span class="md-li">${inline(m[1])}</span>`); continue; }
    if ((m = t.match(/^(\d+|[১-৯০]+)[.)]\s+(.*)$/))) { out.push(`<span class="md-li num"><b>${m[1]}.</b> ${inline(m[2])}</span>`); continue; }
    if ((m = t.match(/^>\s?(.*)$/))) { out.push(`<span class="md-q">${inline(m[1])}</span>`); continue; }
    out.push(`<span class="md-p">${inline(L)}</span>`);
  }
  return out.join("").replace(/(<span class="md-gap"><\/span>)+/g, '<span class="md-gap"></span>').replace(/^<span class="md-gap"><\/span>|<span class="md-gap"><\/span>$/g, "").replace(/\u0000(\d+)\u0000/g, (_, i) => esc(M[+i]));
}

/* ---------- Musfiq AI অনলাইন (ফ্রি — Pollinations, কোনো key/ক্রেডিট লাগে না) ---------- */
const AI_SYS = `তুমি "${AI}" — বাংলাদেশের HSC (বিজ্ঞান বিভাগ) ও বিশ্ববিদ্যালয় ভর্তি (ক/A ইউনিট: DU, JU, RU, CU, JnU, KU, CoU, HSTU, GST, কৃষি গুচ্ছ) পরীক্ষার্থীদের জন্য একজন বন্ধুসুলভ, অভিজ্ঞ শিক্ষক। তোমাকে বানিয়েছে মুসফিক (Musfiq)।
নিয়ম:
১. সবসময় সহজ, সুন্দর বাংলায় উত্তর দেবে (ইংরেজি পরিভাষা প্রয়োজনে বন্ধনীতে)।
২. প্রতিটি উত্তর সুন্দর ব্যাখ্যাসহ দেবে: আগে মূল উত্তর/ধারণা, তারপর "কেন" — ধাপে ধাপে বুঝিয়ে, শেষে ছোট একটা "মনে রাখার টিপস" বা "ভর্তি পরীক্ষায় যা আসে"।
৩. পদার্থবিজ্ঞান, রসায়ন, উচ্চতর গণিতের অঙ্ক/সংখ্যাগত সমস্যা হলে অবশ্যই পুরোটা সমাধান করবে: "দেওয়া আছে" (প্রদত্ত রাশি ও একক), "নির্ণেয়", প্রয়োজনীয় সূত্র, মান বসিয়ে প্রতিটি ধাপের হিসাব, এবং শেষে "∴ উত্তর: ..." (এককসহ)। নিজে হিসাব দুবার যাচাই করবে। MCQ হলে কোন অপশন সঠিক তা স্পষ্ট বলবে। শর্টকাট টেকনিক থাকলে সেটাও দেখাবে।
৪. সব গাণিতিক রাশি/সূত্র LaTeX-এ লিখবে: লাইনের মধ্যে $...$ আর আলাদা লাইনে $$...$$। রাসায়নিক সংকেত/বিক্রিয়াও $...$ এ লিখবে (যেমন $\\mathrm{H_2SO_4}$)।
৫. হেডিং (###), **বোল্ড**, তালিকা (-) ব্যবহার করে সাজিয়ে লিখবে। খুব লম্বা না, কিন্তু পূর্ণাঙ্গ।
৬. তথ্য HSC NCTB পাঠ্যবই ও ভর্তি সহায়িকা অনুযায়ী দেবে। শেষ লাইনে লিখবে: "📚 উৎস: HSC <বিষয় ও পত্র> পাঠ্যবই — <অধ্যায়ের নাম>" (প্রযোজ্য হলে "ও ভর্তি সহায়িকা")।
৭. নিশ্চিত না হলে বানিয়ে বলবে না — সেটা সৎভাবে জানাবে। পড়াশোনার বাইরের প্রশ্নেও ভদ্রভাবে সংক্ষেপে উত্তর দিয়ে পড়ার দিকে উৎসাহ দেবে।`;
let lastAI = 0;
const sleep = ms => new Promise(r => setTimeout(r, ms));
function setTyping(msg) { const t = chatLog[chatLog.length - 1]; if (t && t.typing) { t.status = msg; const el = document.querySelector(".typing-st"); if (el) el.textContent = msg; } }
async function waitTurn() {
  let left = Math.ceil((lastAI + 31000 - Date.now()) / 1000);
  while (left > 0) { setTyping(`ফ্রি সার্ভিসে ৩০ সেকেন্ডে ১টি উত্তর — ${bn(left)} সেকেন্ড অপেক্ষা...`); await sleep(1000); left--; }
  setTyping(`${AI} ভাবছে...`);
}
async function callAI(messages) {
  for (let attempt = 0; attempt < 3; attempt++) {
    await waitTurn();
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 90000);
    try {
      lastAI = Date.now();
      const r = await fetch("https://text.pollinations.ai/openai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model: "openai", messages, private: true, referrer: "odhyayon-musfiq-ai" }), signal: ctl.signal });
      const raw = await r.text();
      clearTimeout(to);
      let txt = ""; try { const j = JSON.parse(raw); txt = j.choices?.[0]?.message?.content || ""; } catch (e) { txt = ""; }
      const lim = raw.match(/limit reached[\s\S]*?wait (\d+) second/i) || raw.match(/"retryAfter(?:Seconds)?"\s*:\s*(\d+)/i);
      if (r.status === 429 || (lim && !txt)) { lastAI = Date.now() - 31000 + ((lim ? +lim[1] : 30) + 1) * 1000; continue; }
      txt = txt.trim();
      if (!r.ok || !txt) throw new Error("bad " + r.status);
      return txt.replace(/\n*-{3,}\s*\n*\*\*Support Pollinations[\s\S]*$/i, "").replace(/\n*🌸[\s\S]*Pollinations[\s\S]*$/i, "");
    } catch (e) { clearTimeout(to); if (attempt === 2 || !navigator.onLine) throw e; await sleep(1500); }
  }
  throw new Error("limit");
}
function ctxFor(text) {
  const kb = findKB(text), m = findQuestion(text);
  let c = "";
  if (kb.length) c += "\n\nপ্রাসঙ্গিক সূত্র/তথ্য (অ্যাপের নোট):\n" + kb.map(k => `${k.t}: ${k.b.join("; ")}`).join("\n");
  if (m && m.score > 0.3) { const q = m.q; c += `\n\nপ্রশ্নব্যাংকে কাছাকাছি একটি প্রশ্ন (${PAPERS[q.pid].name} — ${PAPERS[q.pid].chapters[q.ci].name}${q.t.length ? ", " + q.t.join(", ") : ""}):\n${q.q}\nঅপশন: ${q.o.map((o, k) => LETTERS[k] + ") " + o).join(" | ")}\nউত্তর কী অনুযায়ী সঠিক: ${LETTERS[q.a]}) ${q.o[q.a]}`; }
  return c;
}
function chatHist() {
  const H = [];
  chatLog.slice(-9, -1).forEach(m => { if (m.who === "me" && m.text) H.push({ role: "user", content: m.text }); else if (m.who === "bot" && m.raw) H.push({ role: "assistant", content: m.raw.slice(0, 1500) }); });
  return H.slice(-6);
}
async function askOnline(text, display) {
  const ctx = ctxFor(text);
  const messages = [{ role: "system", content: AI_SYS + (ctx ? "\n\n(নিচের তথ্য সহায়ক হিসেবে ব্যবহার করতে পারো, প্রশ্নের সাথে মিললে তবেই)" + ctx : "") }, ...chatHist(), { role: "user", content: text }];
  try {
    const ans = await callAI(messages);
    chatLog.pop(); chatLog.push({ who: "bot", md: true, raw: ans, html: md(ans), badge: `${icon("sparkles")} ${AI} • AI উত্তর ভুলও হতে পারে, পাঠ্যবই মিলিয়ে নিও`, sugg: ["আরও সহজ করে বুঝাও", "এরকম একটা ভর্তি প্রশ্ন দাও"] });
  } catch (e) {
    const off = aiReply(display || text);
    chatLog.pop(); chatLog.push({ who: "bot", ...off, html: `<span class="offline-note">${icon("wifi-off")} ইন্টারনেট না থাকায় অফলাইন মোডে উত্তর দিচ্ছি (বিস্তারিত ব্যাখ্যা ও অঙ্ক সমাধানের জন্য ইন্টারনেট চালু করো)</span>\n` + off.html });
  }
  if (R.screen === "chat") render();
}
function askDeep(q) {
  const prompt = `এই ভর্তি পরীক্ষার MCQ-টি ধাপে ধাপে বিস্তারিত ব্যাখ্যা করো${isMathy(q) ? " (অঙ্ক হলে পূর্ণ সমাধান দেখাও)" : ""}, প্রতিটি অপশন কেন সঠিক/ভুল তাও বলো:\n\n${q.q}\nক) ${q.o[0]}\nখ) ${q.o[1]}\nগ) ${q.o[2]}\nঘ) ${q.o[3]}\n\n(উত্তর কী: ${LETTERS[q.a]}) ${q.o[q.a]}; ${PAPERS[q.pid].name} — ${PAPERS[q.pid].chapters[q.ci].name})`;
  chatLog.forEach(m => delete m.sugg);
  chatLog.push({ who: "me", text: "এই প্রশ্নটি আরও বিস্তারিত বুঝিয়ে দাও" }, { who: "bot", typing: true, status: `${AI} ভাবছে...` });
  if (R.screen === "chat") render(); else go("chat");
  askOnline(prompt, q.q);
}
function localIntent(t) {
  return /^(hi|hello|hey|হাই|হ্যালো|সালাম|আসসালামু)\b/.test(t.trim()) && t.trim().split(/\s+/).length <= 3
    || /^(ধন্যবাদ|thanks|thank you)/.test(t.trim())
    || /প্রশ্ন দাও|কুইজ|quiz|প্রশ্ন চাই|আরেকটা প্রশ্ন|আরও প্রশ্ন/.test(t)
    || /মিশ্র পরীক্ষা|মডেল টেস্ট দিতে/.test(t)
    || /অগ্রগতি|আমার রেজাল্ট|আমার ফলাফল|আমার স্কোর/.test(t);
}
function sendChat(text) {
  text = text.trim(); if (!text) return;
  chatLog.forEach(m => delete m.sugg);
  chatLog.push({ who: "me", text }, { who: "bot", typing: true, status: `${AI} ভাবছে...` });
  render();
  const t = text.toLowerCase();
  // ১) দ্রুত লোকাল উত্তর (কুইজ, অগ্রগতি, শুভেচ্ছা)
  if (localIntent(t)) { setTimeout(() => { chatLog.pop(); chatLog.push({ who: "bot", ...aiReply(text) }); if (R.screen === "chat") render(); }, 400); return; }
  // ২) প্রশ্নব্যাংকের প্রশ্ন — সাথে সাথে সঠিক উত্তর + ব্যাখ্যা (অফলাইনেও)
  const m = findQuestion(text);
  if (m && m.score > 0.5 && toks(text).length >= 3) {
    setTimeout(() => { chatLog.pop(); chatLog.push({ who: "bot", html: ansHtml(m.q, "প্রশ্নব্যাংকে এই প্রশ্নটি পেয়েছি ✅"), deep: m.q }); if (R.screen === "chat") render(); }, 350);
    return;
  }
  // ৩) বাকি সব — অনলাইন AI (ব্যাখ্যা + অঙ্ক সমাধান), না পারলে অফলাইন
  askOnline(text);
}

V.chat = () => {
  if (!chatLog.length) chatLog.push({ who: "bot", html: `Hi ${esc(S.user.name.split(" ")[0])}! 👋\nআমি ${AI} — তোমার HSC ও ভর্তি প্রস্তুতির সহায়ক।\n• যেকোনো অধ্যায়ের সূত্র ও তথ্য\n• বিগত ভর্তি প্রশ্নের উত্তর + উৎস\n• যেকোনো প্রশ্নের সুন্দর ব্যাখ্যাসহ উত্তর\n• ফিজিক্স, কেমিস্ট্রি, ম্যাথের অঙ্ক ধাপে ধাপে সমাধান\n• প্রশ্নব্যাংকের যেকোনো প্রশ্নের সঠিক উত্তর + উৎস`, sugg: ["পদার্থ ১ম পত্রের সূত্র", "একটা ভর্তি প্রশ্ন দাও", "পরীক্ষার টিপস"] });
  return `<section class="screen">${topbar(`${AI}`, `<button class="iconbtn" data-a="clearchat" aria-label="নতুন চ্যাট">${icon("square-pen")}</button>`)}
  <div class="chat" id="chat">${chatLog.map(renderMsg).join("")}</div>
  <form class="composer" data-f="chat"><input id="ci" placeholder="প্রশ্ন বা অঙ্ক লেখো..." autocomplete="off" aria-label="প্রশ্ন লিখুন"><button type="submit" aria-label="পাঠান">${icon("send-horizontal")}</button></form></section>`;
};
function renderMsg(m, idx) {
  if (m.who === "me") return `<div class="msg me">${esc(m.text)}</div>`;
  if (m.typing) return `<div class="bot-head"><img src="img/robot.webp" alt=""><div class="msg bot typing"><span></span><span></span><span></span><em class="typing-st">${esc(m.status || "")}</em></div></div>`;
  let extra = "";
  if (m.quiz) { const q = m.quiz; extra = `<div class="mini-q">${q.q.o.map((o, k) => `<button data-a="cq" data-m="${idx}" data-k="${k}" class="${q.picked == null ? "" : k === q.q.a ? "right" : k === q.picked ? "wrong" : ""}" ${q.picked != null ? "disabled" : ""}>${LETTERS[k]}) ${tx(o)}</button>`).join("")}${q.picked != null ? `<div class="exp" style="margin-top:8px">${q.picked === q.q.a ? "✅ সঠিক! " : `❌ সঠিক উত্তর: (${LETTERS[q.q.a]}) ${tx(ansText(q.q))}। `}<br>${qExplain(q.q)}</div>` : ""}</div>`; }
  if (m.action) extra += `<button class="btn sm" style="margin-top:10px" data-a="mixexam">${icon("play")} পরীক্ষা শুরু করুন</button>`;
  return `<div class="bot-head"><img src="img/robot.webp" alt=""><div class="msg bot ${m.md ? "md" : ""}">${m.html}${extra}${m.deep ? `<button class="btn ghost sm deep" data-a="deep" data-m="${idx}">${icon("sparkles")} আরও বিস্তারিত বুঝিয়ে দাও</button>` : ""}${m.badge ? `<div class="ai-badge">${m.badge}</div>` : ""}</div></div>${m.sugg ? `<div class="sugg">${m.sugg.map(s => `<button data-a="sugg" data-t="${esc(s)}">${esc(s)}</button>`).join("")}</div>` : ""}`;
}

V.aiintro = () => `<section class="screen" data-light><div class="nora-intro"><h2>${AI}</h2><p>তোমার পাশে<br>সবসময়</p><div class="robo-big wavebot"><img src="img/robot_body.webp" alt="Musfiq AI রোবট" width="200" height="300"><img class="peek-hand" src="img/robot_hand.webp" alt="" width="200" height="300"></div><button class="btn" style="max-width:240px" data-a="aiok">চলো শুরু করি ${icon("arrow-right")}</button></div></section>`;

V.settings = () => {
  const s = S.settings, u = S.user;
  const sw = (k, g) => `<span class="sw ${s[k] ? "on" : ""} ${g ? "g" : ""}" role="switch" aria-checked="${!!s[k]}"></span>`;
  return `<section class="screen">${topbar("সেটিংস")}<div class="scroll">
    <div class="row" style="margin-bottom:16px"><span class="avatar">${esc(initials(u.name))}</span><span class="t"><b>${esc(u.name)}</b><small>${esc(u.id)}</small></span><button class="iconbtn" data-a="editname" aria-label="নাম পরিবর্তন">${icon("pencil")}</button></div>
    <div class="set-label">${AI}</div>
    <div class="set">
      <button class="it" data-a="tog" data-k="ai"><span class="ic">${icon("bot")}</span><span>হোম স্ক্রিনে ${AI}<br><small>বাম পাশে উঁকি দেবে</small></span>${sw("ai")}</button>
      <button class="it" data-a="tog" data-k="greet"><span class="ic">${icon("hand")}</span><span>হাত নেড়ে “Hi”<br><small>হোমের বাম পাশ থেকে উঁকি দিয়ে হাত নাড়বে</small></span>${sw("greet")}</button>
    </div>
    <div class="set-label">সাধারণ</div>
    <div class="set">
      <button class="it" data-a="tog" data-k="notif"><span class="ic">${icon("bell")}</span><span>নোটিফিকেশন</span>${sw("notif")}</button>
      <button class="it" data-a="tog" data-k="dark"><span class="ic">${icon("moon")}</span><span>ডার্ক মোড</span>${sw("dark")}</button>
      <button class="it" data-a="goal"><span class="ic">${icon("target")}</span><span>দৈনিক লক্ষ্য</span><small>${bn(s.goal)}টি MCQ</small>${icon("chevron-right", "chev")}</button>
      <button class="it" data-a="reset"><span class="ic" style="color:var(--red)">${icon("trash-2")}</span><span>অগ্রগতি মুছে ফেলুন</span></button>
    </div>
    <div class="set-label">অন্যান্য</div>
    <div class="set">
      <button class="it" data-a="about"><span class="ic">${icon("info")}</span><span>অ্যাপ সম্পর্কে ও উৎস</span><small>ভার্সন ৩.১.০</small></button>
      <button class="it" data-a="logout"><span class="ic" style="color:var(--red)">${icon("log-out")}</span><span style="color:var(--red)">লগআউট</span></button>
    </div>
  </div>${navbar("settings")}</section>`;
};

/* ---------- overlays ---------- */
function overlay(html) { closeOverlay(); const d = document.createElement("div"); d.id = "ov"; d.innerHTML = html; document.getElementById("phone").appendChild(d); lucide.createIcons(); }
function closeOverlay() { document.getElementById("ov")?.remove(); }
let sheetCb = null;
function sheet(title, text, okLabel, cb, cancelLabel = "বাতিল", extra = "") {
  sheetCb = cb;
  overlay(`<div class="modal-bg" data-a="closeov"><div class="sheet" role="dialog" aria-label="${esc(title)}"><h3>${title}</h3><div class="sheet-body">${text}</div>${extra}<div class="btns">${cancelLabel ? `<button class="btn ghost sm" data-a="closeov">${cancelLabel}</button>` : ""}${okLabel ? `<button class="btn sm" data-a="sheetok">${okLabel}</button>` : ""}</div></div></div>`);
}
function greetPopup() {
  overlay(`<div class="modal-bg greet-bg" data-a="closeov"><div class="greet-card" role="dialog" aria-label="${AI} স্বাগতম"><div class="robo-big"><img src="img/robot.webp" alt="Musfiq AI রোবট" width="150" height="220"><span class="hi-bubble big">Hi! <span class="wave">👋</span></span></div><h3>Hi ${esc(S.user.name.split(" ")[0])}! আমি ${AI}</h3><p>আজ কোন অধ্যায় পড়বে? যেকোনো প্রশ্ন বা অঙ্ক — ব্যাখ্যাসহ বুঝিয়ে দেব।</p><div class="btns"><button class="btn ghost sm" data-a="closeov">পরে</button><button class="btn sm" data-a="greetchat">কথা বলি ${icon("message-circle")}</button></div></div></div>`);
}
function drawer() {
  const u = S.user;
  const items = [["house", "হোম", "home"], ["book-open", "প্রশ্নব্যাংক", "subjects"], ["sigma", "সূত্র ও তথ্য", "formulas"], ["clipboard-list", "পরীক্ষা", "examhub"], ["trending-up", "অগ্রগতি", "progress"], ...(S.settings.ai ? [["bot", AI, "chat"]] : []), ["settings", "সেটিংস", "settings"]];
  overlay(`<div class="drawer-bg" data-a="closeov"></div><aside class="drawer" aria-label="মেনু"><div class="me"><span class="avatar">${esc(initials(u.name))}</span><div><b>${esc(u.name)}</b><small>${esc(u.id)}</small></div></div>
  <nav>${items.map(([i, l, s]) => `<button data-a="dnav" data-s="${s}">${icon(i)}${l}</button>`).join("")}<button data-a="logout">${icon("log-out")}লগআউট</button></nav><div class="ver">অধ্যয়ন • ভার্সন ৩.১.০</div></aside>`);
}

/* ---------- render ---------- */
function typeset(root) {
  if (!root || !window.renderMathInElement) return;
  try { renderMathInElement(root, { delimiters: [{ left: "$$", right: "$$", display: true }, { left: "\\[", right: "\\]", display: true }, { left: "\\(", right: "\\)", display: false }, { left: "$", right: "$", display: false }], throwOnError: false, strict: "ignore", ignoredClasses: ["ocr"] }); } catch (e) {}
}
function render() {
  const fn = V[R.screen] || V.home;
  const changed = render._last !== R.screen; render._last = R.screen;
  const sc = !changed && $app.querySelector(".scroll") ? $app.querySelector(".scroll").scrollTop : 0;
  $app.innerHTML = fn();
  if (changed) $app.firstElementChild?.classList.add("anim");
  else { const s = $app.querySelector(".scroll"); if (s) s.scrollTop = sc; }
  document.querySelector(".statusbar").classList.toggle("light", !!$app.querySelector("[data-light]"));
  lucide.createIcons();
  typeset($app);
  const c = document.getElementById("chat"); if (c) c.scrollTop = c.scrollHeight;
  if (R.screen === "home" && !greeted && S.user) { greeted = true;  }
}

/* ---------- events ---------- */
document.addEventListener("click", e => {
  const b = e.target.closest("[data-a]"); if (!b) return;
  const a = b.dataset.a, d = b.dataset;
  if (a === "closeov") { if (e.target === b || b.tagName === "BUTTON") closeOverlay(); return; }
  switch (a) {
    case "back": back(); break;
    case "to": closeOverlay(); go(d.s); break;
    case "nav": closeOverlay(); go(d.s, {}, { reset: true }); break;
    case "dnav": closeOverlay(); if (d.s === "chat") return openAI(); go(d.s, {}, { reset: d.s === "home" }); break;
    case "obnext": if (ui.obStep < 2) { ui.obStep++; render(); } else { S.onboarded = true; save(); go("signin", {}, { reset: true }); } break;
    case "obskip": S.onboarded = true; save(); go("signin", {}, { reset: true }); break;
    case "eye": { ui.showPass = !ui.showPass; const vals = [...$app.querySelectorAll("input")].map(i => i.value); render(); $app.querySelectorAll("input").forEach((i, k) => i.value = vals[k] || ""); break; }
    case "forgot": sheet("পাসওয়ার্ড পুনরুদ্ধার", "এই অ্যাপের অ্যাকাউন্ট শুধু তোমার ফোনেই সংরক্ষিত থাকে। পাসওয়ার্ড ভুলে গেলে নতুন করে রেজিস্টার করো।", null, null, "ঠিক আছে"); break;
    case "google": login({ name: "শিক্ষার্থী", id: "student@gmail.com" }); toast("লগইন সফল — সেটিংস থেকে নাম বদলাতে পারবে"); break;
    case "drawer": drawer(); break;
    case "notifs": sheet("নোটিফিকেশন", S.settings.notif ? `• আজকের লক্ষ্য: ${bn(S.settings.goal)}টি MCQ — এখন পর্যন্ত ${bn(answeredToday())}টি সম্পন্ন<br>• ৮টি পত্রের প্রতিটি অধ্যায়ে বিগত ভর্তি প্রশ্ন যোগ হয়েছে<br>• ${AI} এখন ব্যাখ্যাসহ উত্তর দেয় ও অঙ্ক ধাপে ধাপে সমাধান করে<br>• নতুন: JnU, KU, CoU, HSTU ও কৃষি বিশ্ববিদ্যালয়ের প্রশ্ন যোগ হয়েছে` : "নোটিফিকেশন বন্ধ আছে। সেটিংস থেকে চালু করুন।", null, null, "ঠিক আছে"); break;
    case "ai": openAI(); break;
    case "greetchat": closeOverlay(); openAI(); break;
    case "aiok": S.aiSeen = true; save(); go("chat", {}, { replace: true }); break;
    case "subj": go("subj", { id: d.id }); break;
    case "paper": go("paper", { p: d.p }); break;
    case "chapter": ui.chUni = "all"; ui.chYear = "all"; ui.chLimit = 25; go("chapter", { p: d.p, i: +d.i }); break;
    case "chuni": ui.chUni = d.k; ui.chLimit = 25; render(); break;
    case "chyear": ui.chYear = d.k; ui.chLimit = 25; render(); break;
    case "chmode": ui.chMode = d.k; render(); break;
    case "more": ui.chLimit += 25; render(); break;
    case "cpick": { if (ui.picked[d.id] == null) { ui.picked[d.id] = +d.k; S.practice[today()] = (S.practice[today()] || 0) + 1; save(); render(); } break; }
    case "kb": showKB(kbFor(d.p, +d.i)); break;
    case "kbg": showKB(KB.find(k => k.t === d.t)); break;
    case "chexam": { const P = PAPERS[d.p]; startExam(`${P.chapters[+d.i].name}`, chapterList(d.p, +d.i), 25, d.p); break; }
    case "paperexam": { const P = PAPERS[d.p]; startExam(P.short, pyqOnly(P.chapters.flatMap(c => c.qs)), 50, d.p); break; }
    case "mixexam": closeOverlay(); startExam("“ক” ইউনিট মিশ্র পরীক্ষা", pyqOnly(ALLQ), 40); break;
    case "uniexam": startExam(`${d.u} ভর্তি প্রশ্ন`, ALLQ.filter(q => q.t.some(t => t.startsWith(d.u + "'"))), 40); break;
    case "pick": exam.ans[exam.cur] = +d.k; render(); break;
    case "next": exam.cur++; render(); break;
    case "prev": exam.cur--; render(); break;
    case "jump": exam.cur = +d.i; render(); break;
    case "submitask": { const left = exam.ans.filter(x => x === null).length; sheet("উত্তরপত্র জমা দেবেন?", left ? `এখনও ${bn(left)}টি প্রশ্নের উত্তর দেওয়া হয়নি।` : "সবগুলো প্রশ্নের উত্তর দেওয়া হয়েছে।", "জমা দিন", finishExam); break; }
    case "retry": { const g = lastResult.again; R.stack = R.stack.filter(x => x.screen !== "result"); R.screen = R.stack.length ? R.stack.pop().screen : "home"; startExam(g.title, g.pool, g.n, g.pid); break; }
    case "sugg": sendChat(d.t); break;
    case "deep": { const m = chatLog[+d.m]; if (m && m.deep) { const q = m.deep; delete m.deep; askDeep(q); } break; }
    case "askai": { const q = ALLQ.find(x => x.id === d.id); if (q) askDeep(q); break; }
    case "cq": { const m = chatLog[+d.m]; if (m && m.quiz && m.quiz.picked == null) { m.quiz.picked = +d.k; S.practice[today()] = (S.practice[today()] || 0) + 1; save(); render(); } break; }
    case "clearchat": chatLog = []; render(); break;
    case "tog": S.settings[d.k] = !S.settings[d.k]; save(); if (d.k === "dark") applyTheme(); render(); toast(`${{ notif: "নোটিফিকেশন", ai: "হোমে " + AI, greet: "স্বাগত “Hi”", dark: "ডার্ক মোড" }[d.k]} ${S.settings[d.k] ? "চালু" : "বন্ধ"} করা হয়েছে`); break;
    case "goal": sheet("দৈনিক লক্ষ্য নির্ধারণ", "প্রতিদিন কতটি MCQ অনুশীলন করতে চান?", null, null, "বন্ধ করুন", `<div class="chips" style="flex-wrap:wrap">${[10, 20, 30, 50, 100].map(n => `<button class="chip ${S.settings.goal === n ? "on" : ""}" data-a="setgoal" data-n="${n}">${bn(n)}টি</button>`).join("")}</div>`); break;
    case "setgoal": S.settings.goal = +d.n; save(); closeOverlay(); render(); toast(`দৈনিক লক্ষ্য: ${bn(d.n)}টি MCQ`); break;
    case "editname": sheet("নাম পরিবর্তন", "আপনার নতুন নাম লিখুন", "সংরক্ষণ", vals => saveName(vals.nn), "বাতিল", `<div class="field">${icon("user-round")}<input id="nn" maxlength="40" value="${esc(S.user.name)}"></div>`); setTimeout(() => { const i = document.getElementById("nn"); if (i) { i.focus(); i.select(); } }, 60); break;
    case "reset": sheet("অগ্রগতি মুছবেন?", "সব পরীক্ষার ইতিহাস ও অনুশীলনের হিসাব মুছে যাবে। এটি ফেরানো যাবে না।", "মুছে ফেলুন", () => { S.history = []; S.practice = {}; ui.picked = {}; save(); render(); toast("অগ্রগতি মুছে ফেলা হয়েছে"); }); break;
    case "about": sheet("অধ্যয়ন সম্পর্কে", `ভার্সিটি “ক/A” ইউনিট ভর্তি প্রস্তুতির অ্যাপ। ৮টি পত্রের প্রতিটি অধ্যায়ে DU, JU, RU, CU, JnU, KU, CoU, HSTU, GST ও কৃষি (BAU/SAU/SBAU/KAU)-এর বিগত (২০১৫-১৬ থেকে) ভর্তি প্রশ্ন, প্রতিটির পাশে বিশ্ববিদ্যালয় ও সাল ট্যাগ।<br><br>প্রশ্নের উৎস: বিগত ভর্তি পরীক্ষার প্রশ্ন (avijatra.com প্রশ্নব্যাংক থেকে সংকলিত); অধ্যায় বিন্যাস ও সূত্র: HSC NCTB পাঠ্যবই।<br><br>প্রতিটি প্রশ্নের ব্যাখ্যা AI দিয়ে তৈরি — কোথাও ভুল মনে হলে পাঠ্যবই মিলিয়ে নিও।<br><br>${AI} সম্পূর্ণ ফ্রি — কোনো ক্রেডিট লাগে না। প্রশ্নব্যাংক, ব্যাখ্যা ও সূত্র অফলাইনে চলে; নতুন প্রশ্নের বিস্তারিত উত্তর ও অঙ্ক সমাধানের জন্য ইন্টারনেট লাগে (ফ্রি AI সার্ভিস Pollinations)।<br><br>ভার্সন ৩.১.০`, null, null, "ঠিক আছে"); break;
    case "logout": closeOverlay(); sheet("লগআউট করবেন?", "আপনার অগ্রগতি এই ডিভাইসে সংরক্ষিত থাকবে।", "লগআউট", () => { S.user = null; save(); chatLog = []; go("signin", {}, { reset: true }); }); break;
    case "sheetok": { const cb = sheetCb, vals = {}; document.querySelectorAll("#ov input").forEach(i => { vals[i.id || i.name] = i.value; }); closeOverlay(); cb && cb(vals); break; }
  }
});
function saveName(v) {
  v = (v || "").trim();
  if (!v) return toast("নাম খালি রাখা যাবে না");
  S.user.name = v; if (S.users[S.user.id]) S.users[S.user.id].name = v; save(); render(); toast("নাম আপডেট হয়েছে");
}
function openAI() { if (!S.settings.ai) return toast(`সেটিংস থেকে ${AI} চালু করুন`); go(S.aiSeen ? "chat" : "aiintro"); }
function login(u) { S.user = u; S.users[u.id] = S.users[u.id] || { name: u.name, pass: null }; S.user.name = S.users[u.id].name || u.name; save(); ui.showPass = false; greeted = false; go("home", {}, { reset: true }); }

document.addEventListener("submit", e => {
  const f = e.target.closest("[data-f]"); if (!f) return; e.preventDefault();
  const v = Object.fromEntries(new FormData(f)), err = document.getElementById("err"), fail = m => { if (err) err.textContent = m; };
  if (f.dataset.f === "chat") { const i = document.getElementById("ci"); sendChat(i.value); return; }
  const id = (v.id || "").trim().toLowerCase();
  const validId = /^\S+@\S+\.\S+$/.test(id) || /^(\+?88)?01\d{9}$/.test(id.replace(/[০-৯]/g, c => BN.indexOf(c)));
  if (f.dataset.f === "signin") {
    if (!id || !v.pass) return fail("ইমেইল/মোবাইল ও পাসওয়ার্ড দিন");
    const u = S.users[id];
    if (!u) return fail("এই অ্যাকাউন্ট পাওয়া যায়নি — আগে রেজিস্টার করুন");
    if (u.pass && u.pass !== v.pass) return fail("পাসওয়ার্ড সঠিক নয়");
    login({ name: u.name, id }); toast("স্বাগতম, " + u.name);
  } else {
    if (!v.name.trim()) return fail("আপনার নাম লিখুন");
    if (!validId) return fail("সঠিক ইমেইল বা ০১ দিয়ে শুরু ১১ সংখ্যার মোবাইল নম্বর দিন");
    if ((v.pass || "").length < 6) return fail("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে");
    if (v.pass !== v.pass2) return fail("দুটি পাসওয়ার্ড মিলছে না");
    if (S.users[id] && S.users[id].pass) return fail("এই অ্যাকাউন্ট আগে থেকেই আছে — লগইন করুন");
    S.users[id] = { name: v.name.trim(), pass: v.pass };
    login({ name: v.name.trim(), id }); toast("অ্যাকাউন্ট তৈরি হয়েছে — স্বাগতম");
  }
});
document.addEventListener("input", e => {
  if (e.target.id === "sq") { ui.subjQuery = e.target.value; const pos = e.target.selectionStart; render(); const i = document.getElementById("sq"); i.focus(); i.setSelectionRange(pos, pos); }
});
document.addEventListener("keydown", e => {
  if (e.key === "Escape" && document.getElementById("ov")) closeOverlay();
  if (e.key === "Enter" && e.target.id === "nn") { e.preventDefault(); document.querySelector('#ov [data-a="sheetok"]')?.click(); }
});

function tick() { const d = new Date(); document.getElementById("clock").textContent = bn(`${d.getHours() % 12 || 12}:${String(d.getMinutes()).padStart(2, "0")}`); }
tick(); setInterval(tick, 30000);
window.addEventListener("load", () => typeset($app));
render();
/* প্রশ্নের ব্যাখ্যা (exp/*.js) — আলাদা ফাইলে, ব্যাকগ্রাউন্ডে লোড হয় */
const loadScript = src => new Promise((ok, no) => { const s = document.createElement("script"); s.src = src; s.onload = ok; s.onerror = no; document.head.appendChild(s); });
let QBYID = null; const EXPL = {};
function applyExp(p) { QBYID = QBYID || Object.fromEntries(ALLQ.map(q => [q.id, q])); (window.EXP?.[p] || []).forEach((L, ci) => L.forEach((e, k) => { const q = QBYID[`${p}-${ci}-p${k}`]; if (q && e) q.e = e; })); }
function loadExp(p) { return EXPL[p] || (EXPL[p] = loadScript(`exp/${p}.js`).then(() => { applyExp(p); if (["chapter", "review"].includes(R.screen) && !document.getElementById("ov")) render(); }).catch(() => { delete EXPL[p]; })); }
window.__loadExp = loadExp;
setTimeout(async () => { for (const p of Object.keys(PAPERS)) { await loadExp(p); await new Promise(r => setTimeout(r, 150)); } }, 1200);
})();
