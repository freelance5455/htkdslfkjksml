(function(){
"use strict";
var pin="", DEFAULT_PIN="1234";
var state={files:[],notes:"",pin:DEFAULT_PIN};

function load(){
 try{
  var saved=JSON.parse(localStorage.getItem("safe_app_data"));
  if(saved){state.files=Array.isArray(saved.files)?saved.files:[];state.notes=saved.notes||"";state.pin=saved.pin||DEFAULT_PIN;}
 }catch(e){}
}
function save(){try{localStorage.setItem("safe_app_data",JSON.stringify(state));}catch(e){}}
function qs(s){return document.querySelector(s)}
function qsa(s){return Array.prototype.slice.call(document.querySelectorAll(s))}
function show(id){
 qsa(".screen").forEach(function(x){x.classList.remove("active")});
 var el=qs("#"+id); if(el) el.classList.add("active");
}
function toast(msg){
 var t=qs("#toast");t.textContent=msg;t.classList.add("show");
 clearTimeout(toast.timer);toast.timer=setTimeout(function(){t.classList.remove("show")},2400);
}
function updateStats(){
 qs("#statFiles").textContent=state.files.length;
 qs("#statNotes").textContent=state.notes.trim()?1:0;
}
function updateDots(){
 qsa("#pinDots i").forEach(function(dot,i){dot.classList.toggle("filled",i<pin.length)});
}
function openPin(){pin="";updateDots();qs("#pinMessage").textContent="Барои идома рамзи худро ворид кунед";show("pin")}
function addPin(n){
 if(pin.length>=4)return;
 pin+=n;updateDots();
 if(pin.length===4)setTimeout(checkPin,160);
}
function checkPin(){
 if(pin===state.pin){show("home");updateStats();toast("Сейф кушода шуд")}
 else{pin="";updateDots();qs("#pinMessage").textContent="Рамз нодуруст аст. Боз кӯшиш кунед.";if(navigator.vibrate)navigator.vibrate(100)}
}
function changePin(){
 openModal('<h3>Иваз кардани рамз</h3><p>Рамзи нави 4-рақамаро ворид кунед.</p><input id="newPinInput" inputmode="numeric" maxlength="4" placeholder="0000"><div class="modal-actions"><button data-modal-close>Бекор</button><button class="confirm" data-modal-save-pin>Захира</button></div>');
}
function openModal(html){qs("#modalBox").innerHTML=html;qs("#modal").classList.remove("hidden")}
function closeModal(){qs("#modal").classList.add("hidden")}
function saveNewPin(){
 var v=qs("#newPinInput").value.replace(/\D/g,"");
 if(v.length!==4){toast("4 рақам ворид кунед");return}
 state.pin=v;save();closeModal();toast("Рамз иваз шуд");
}
function typeLabel(type){
 if(type.indexOf("image/")===0)return "Акс";
 if(type.indexOf("audio/")===0)return "Мусиқӣ";
 if(type.indexOf("video/")===0)return "Видео";
 return "Ҳуҷҷат";
}
function addFiles(fileList){
 var arr=Array.prototype.slice.call(fileList||[]);
 if(!arr.length)return;
 arr.forEach(function(f){
  state.files.push({name:f.name,type:f.type||"",size:Math.max(0,Math.round(f.size/1024/1024*100)/100),date:new Date().toLocaleDateString()});
 });
 save();updateStats();toast(arr.length+" файл илова шуд");
 qs("#fileInput").value="";
}
function removeFile(index){
 state.files.splice(index,1);save();updateStats();openPage(currentPage);
 toast("Файл хориҷ шуд");
}
var currentPage="";
function escapeHTML(v){return String(v).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function fileList(filter){
 var items=state.files.filter(filter);
 if(!items.length)return '<div class="empty">Ҳоло ягон файл вуҷуд надорад.<br>Бо тугмаи + файл илова кунед.</div>';
 return '<div class="file-list">'+items.map(function(f){
  var idx=state.files.indexOf(f);
  return '<div class="file-item"><span class="file-symbol"></span><div class="file-info"><b>'+escapeHTML(f.name)+'</b><small>'+typeLabel(f.type)+' · '+f.size+' MB · '+f.date+'</small></div><button class="remove-file" data-remove="'+idx+'" aria-label="remove"></button></div>';
 }).join("")+"</div>";
}
function openPage(page){
 currentPage=page;
 show("page");
 var title=qs("#pageTitle"), content=qs("#pageContent");
 if(page==="photos"){
  title.textContent="Аксҳои махфӣ";
  var photos=state.files.filter(function(f){return f.type.indexOf("image/")===0});
  content.innerHTML='<div class="section-head"><b>Галерея</b><small>'+photos.length+' файл</small></div><div class="gallery-grid">'+Array.from({length:Math.max(6,photos.length)},function(){return '<div class="gallery-cell"></div>'}).join("")+'</div><div class="section-head"><b>Файлҳои иловашуда</b></div>'+fileList(function(f){return f.type.indexOf("image/")===0});
 } else if(page==="music"){
  title.textContent="Мусиқии махфӣ";
  content.innerHTML='<div class="player"><div class="disc"></div><h3>SAFE Player</h3><p>Плеери дохилии махфӣ</p><div class="progress"><i></i></div><div class="player-controls"><button class="control prev" data-action="player-prev"></button><button class="play-control" data-action="player-play"></button><button class="control next" data-action="player-next"></button></div></div><div class="section-head"><b>Мусиқӣ</b></div>'+fileList(function(f){return f.type.indexOf("audio/")===0});
 } else if(page==="videos"){
  title.textContent="Видеоҳои махфӣ";content.innerHTML=fileList(function(f){return f.type.indexOf("video/")===0});
 } else if(page==="documents"){
  title.textContent="Ҳуҷҷатҳои махфӣ";content.innerHTML=fileList(function(f){return f.type.indexOf("image/")!==0&&f.type.indexOf("audio/")!==0&&f.type.indexOf("video/")!==0});
 } else if(page==="notes"){
  title.textContent="Эзоҳҳои махфӣ";content.innerHTML='<textarea id="noteArea" class="note-area" placeholder="Эзоҳи махфии худро нависед...">'+escapeHTML(state.notes)+'</textarea><button class="primary-btn wide-action" data-action="save-notes">Захира кардани эзоҳ</button>';
 } else if(page==="browser"){
  title.textContent="Ҷустуҷӯи хусусӣ";content.innerHTML='<div class="browser-panel"><div class="browser-mark"></div><h2>Ҷустуҷӯи хусусӣ</h2><p>Ин бахш барои ҷустуҷӯи дохилӣ пешбинӣ шудааст.</p><label class="search-box"><span class="search-icon"></span><input id="privateSearch" placeholder="Матни ҷустуҷӯ..."></label><button class="primary-btn wide-action" data-action="private-search">Ҷустуҷӯ</button></div>';
 } else if(page==="search"){
  title.textContent="Ҷустуҷӯи файл";content.innerHTML='<label class="search-box"><span class="search-icon"></span><input id="fileSearch" placeholder="Номи файл..." autocomplete="off"></label><div id="searchResults"></div>';setTimeout(renderSearch,0);
 } else if(page==="backup"){
  title.textContent="Нусхаи эҳтиётӣ";content.innerHTML='<div class="backup-panel"><div class="cloud-mark"></div><h2>Нусхаи маҳаллӣ</h2><p>Маълумоти SAFE дар local storage нигоҳ дошта мешавад.</p><button class="primary-btn wide-action" data-action="backup">Эҷод кардани нусха</button><button class="text-btn" data-action="restore">Барқарорсозӣ</button></div>';
 } else if(page==="settings"){
  title.textContent="Танзимот";content.innerHTML='<div class="settings-list"><button class="setting-item" data-action="change-pin"><span>Тағйири рамз</span></button><button class="setting-item" data-page="backup"><span>Нусхаи эҳтиётӣ</span></button><button class="setting-item" data-action="toggle-protection"><span>Ҳифзи иловагӣ</span><i class="toggle"></i></button><button class="setting-item" data-action="clear-files"><span>Тоза кардани рӯйхати файлҳо</span></button><button class="setting-item" data-action="about"><span>Дар бораи барнома</span><small>SAFE</small></button></div>';
 }
}
function renderSearch(){
 var input=qs("#fileSearch"), out=qs("#searchResults");
 if(!input||!out)return;
 var q=input.value.toLowerCase();
 var result=state.files.filter(function(f){return f.name.toLowerCase().indexOf(q)!==-1});
 out.innerHTML=result.length?'<div class="file-list">'+result.map(function(f){return '<div class="file-item"><span class="file-symbol"></span><div class="file-info"><b>'+escapeHTML(f.name)+'</b><small>'+typeLabel(f.type)+' · '+f.size+' MB</small></div></div>'}).join("")+'</div>':'<div class="empty">Файл ёфт нашуд</div>';
}
function saveNotes(){var area=qs("#noteArea");if(area){state.notes=area.value;save();updateStats();toast("Эзоҳ захира шуд")}}
function backup(){localStorage.setItem("safe_app_backup",JSON.stringify(state));toast("Нусхаи эҳтиётӣ сохта шуд")}
function restore(){try{var d=JSON.parse(localStorage.getItem("safe_app_backup"));if(!d){toast("Нусха ёфт нашуд");return}state=d;save();updateStats();toast("Маълумот барқарор шуд")}catch(e){toast("Хатои барқарорсозӣ")}}
function clearFiles(){openModal('<h3>Тоза кардани файлҳо</h3><p>Рӯйхати файлҳои дохили SAFE тоза мешавад.</p><div class="modal-actions"><button data-modal-close>Бекор</button><button class="confirm" data-confirm-clear>Тоза кардан</button></div>')}
function about(){openModal('<h3>SAFE</h3><p>Purple Storyboard Edition</p><p>Дизайни Glassmorphism, интерфейси маҳаллӣ ва функсияҳои SAFE.</p><div class="modal-actions"><button class="confirm" data-modal-close>Фаҳмо</button></div>')}
document.addEventListener("click",function(e){
 var pinBtn=e.target.closest("[data-pin]");if(pinBtn){addPin(pinBtn.getAttribute("data-pin"));return}
 var pageBtn=e.target.closest("[data-page]");if(pageBtn){openPage(pageBtn.getAttribute("data-page"));return}
 var action=e.target.closest("[data-action]");
 if(action){
  var a=action.getAttribute("data-action");
  if(a==="open-pin")openPin();
  else if(a==="show-welcome")show("welcome");
  else if(a==="go-home"){show("home");updateStats()}
  else if(a==="quick-open"){show("home");updateStats();toast("Сейф кушода шуд")}
  else if(a==="delete-pin"){pin=pin.slice(0,-1);updateDots()}
  else if(a==="change-pin")changePin()
  else if(a==="pick-files")qs("#fileInput").click()
  else if(a==="save-notes")saveNotes()
  else if(a==="private-search"){var v=qs("#privateSearch");toast(v&&v.value.trim()?"Ҷустуҷӯ: "+v.value.trim():"Матни ҷустуҷӯро ворид кунед")}
  else if(a==="backup")backup()
  else if(a==="restore")restore()
  else if(a==="toggle-protection")toast("Ҳифзи иловагӣ фаъол аст")
  else if(a==="clear-files")clearFiles()
  else if(a==="about")about()
  else if(a==="player-play")toast("Плеер фаъол шуд")
  else if(a==="player-prev"||a==="player-next")toast("Идоракунии плеер")
  else if(a==="page-action")toast("Менюи иловагӣ")
  return;
 }
 if(e.target.closest("[data-modal-close]")){closeModal();return}
 if(e.target.closest("[data-modal-save-pin]")){saveNewPin();return}
 if(e.target.closest("[data-confirm-clear]")){state.files=[];save();updateStats();closeModal();toast("Рӯйхат тоза шуд");if(currentPage)openPage(currentPage);return}
 var remove=e.target.closest("[data-remove]");if(remove){removeFile(parseInt(remove.getAttribute("data-remove"),10));return}
});
qs("#fileInput").addEventListener("change",function(){addFiles(this.files)});
qs("#homeSearch").addEventListener("input",function(){
 var q=this.value.toLowerCase();
 qsa(".feature-card").forEach(function(card){card.style.display=card.textContent.toLowerCase().indexOf(q)!==-1?"block":"none"});
});
document.addEventListener("input",function(e){if(e.target&&e.target.id==="fileSearch")renderSearch()});
load();updateStats();
})();