const $=s=>document.querySelector(s);
function openTool(id){
  const map={calc:["🧮 Kalkulator Ilmiah",calc],chem:["⚗️ Kimia + Tabel Periodik",chem],notes:["📝 Catatan",notes],eco:["💰 Ekonomi",eco],convert:["📏 Konversi Satuan",convert]};
  document.querySelector("#home").classList.remove("active");document.querySelector("#tool").classList.add("active");
  document.querySelector("#title").textContent=map[id][0];document.querySelector("#body").innerHTML=map[id][1]();
}
function goHome(){document.querySelector("#tool").classList.remove("active");document.querySelector("#home").classList.add("active")}

/* KALKULATOR */
let expr="";
function calc(){return `<div class=panel><input id=calcDisplay class="input display" readonly placeholder="0"><div class=calc>${["sin","cos","tan","√","7","8","9","÷","4","5","6","×","1","2","3","−","0",".","π","+","(",")","⌫","C","=","^"].map(x=>`<button class="${"÷×−+".includes(x)?"op":x==="="?"eq":x==="C"?"clear":""}" onclick="pressCalc('${x}')">${x}</button>`).join("")}</div></div><div class=panel><div class=muted>sin, cos, tan memakai derajat. Contoh: sin(30), √(25), 2^3.</div></div>`}
function pressCalc(x){
 if(x==="C")expr=""; else if(x==="⌫")expr=expr.slice(0,-1);
 else if(x==="="){try{expr=String(calcEval(expr))}catch(e){expr="Error"}}
 else if(x==="√")expr+="sqrt("; else if(x==="π")expr+="pi"; else if(x==="÷")expr+="/"; else if(x==="×")expr+="*"; else if(x==="−")expr+="-";
 else if(["sin","cos","tan"].includes(x))expr+=x+"("; else expr+=x;
 document.querySelector("#calcDisplay").value=expr;
}
function calcEval(s){
 s=s.replaceAll("pi","Math.PI").replaceAll("^","**").replaceAll("sqrt","Math.sqrt");
 s=s.replace(/sin\(/g,"Math.sin(Math.PI/180*").replace(/cos\(/g,"Math.cos(Math.PI/180*").replace(/tan\(/g,"Math.tan(Math.PI/180*");
 if(!/^[0-9+\-*/()., *MathsincotPIrqu]+$/.test(s))throw Error();
 return Function("return "+s)();
}

/* KIMIA */
const elements=[
["H","Hidrogen",1,1.008],["He","Helium",2,4.003],["Li","Litium",3,6.94],["Be","Berilium",4,9.012],["B","Boron",5,10.81],["C","Karbon",6,12.011],["N","Nitrogen",7,14.007],["O","Oksigen",8,15.999],["F","Fluor",9,18.998],["Ne","Neon",10,20.180],
["Na","Natrium",11,22.990],["Mg","Magnesium",12,24.305],["Al","Aluminium",13,26.982],["Si","Silikon",14,28.085],["P","Fosfor",15,30.974],["S","Sulfur",16,32.06],["Cl","Klor",17,35.45],["Ar","Argon",18,39.948],["K","Kalium",19,39.098],["Ca","Kalsium",20,40.078],
["Sc","Skandium",21,44.956],["Ti","Titanium",22,47.867],["V","Vanadium",23,50.942],["Cr","Krom",24,51.996],["Mn","Mangan",25,54.938],["Fe","Besi",26,55.845],["Co","Kobalt",27,58.933],["Ni","Nikel",28,58.693],["Cu","Tembaga",29,63.546],["Zn","Seng",30,65.38],
["Ga","Galium",31,69.723],["Ge","Germanium",32,72.630],["As","Arsen",33,74.922],["Se","Selenium",34,78.971],["Br","Brom",35,79.904],["Kr","Kripton",36,83.798],["Rb","Rubidium",37,85.468],["Sr","Stronsium",38,87.62],["Y","Itrium",39,88.906],["Zr","Zirkonium",40,91.224],
["Nb","Niobium",41,92.906],["Mo","Molibdenum",42,95.95],["Tc","Teknesium",43,98],["Ru","Rutenium",44,101.07],["Rh","Rodium",45,102.906],["Pd","Paladium",46,106.42],["Ag","Perak",47,107.868],["Cd","Kadmium",48,112.414],["In","Indium",49,114.818],["Sn","Timah",50,118.710],
["Sb","Antimon",51,121.760],["Te","Telurium",52,127.60],["I","Iodin",53,126.904],["Xe","Xenon",54,131.293],["Cs","Sesium",55,132.905],["Ba","Barium",56,137.327],["La","Lantanum",57,138.905],["Ce","Serium",58,140.116],["Pr","Praseodimium",59,140.908],["Nd","Neodimium",60,144.242],
["Eu","Europium",63,151.964],["Gd","Gadolinium",64,157.25],["Yb","Iterbium",70,173.045],["Lu","Lutetium",71,174.967],["Hf","Hafnium",72,178.49],["Ta","Tantalum",73,180.948],["W","Wolfram",74,183.84],["Re","Renium",75,186.207],["Os","Osmium",76,190.23],["Ir","Iridium",77,192.217],["Pt","Platina",78,195.084],["Au","Emas",79,196.967],["Hg","Raksa",80,200.592],["Tl","Talium",81,204.38],["Pb","Timbal",82,207.2],["Bi","Bismut",83,208.980]
];
const AW=Object.fromEntries(elements.map(e=>[e[0],e[3]]));

function chem(){
 return `<div class=tabs>
 <button class=active onclick="chemTab('balance',this)">Setarakan</button>
 <button onclick="chemTab('molar',this)">Massa Molar</button>
 <button onclick="chemTab('mol',this)">Mol ↔ Massa</button>
 <button onclick="chemTab('stoich',this)">Stoikiometri</button>
 <button onclick="chemTab('combine',this)">Gabung Reaksi</button>
 <button onclick="chemTab('periodic',this)">Tabel Unsur</button>
 </div><div id=chemPanel></div>`;
}
function chemTab(t,btn){
 document.querySelectorAll(".tabs button").forEach(x=>x.classList.remove("active"));if(btn)btn.classList.add("active");
 const h={
 balance:`<div class=panel><h3>Penyetaraan Reaksi Otomatis</h3><input id=rx class=input placeholder="Contoh: H2 + O2 -> H2O"><button class=btn onclick=balanceReaction()>Setarakan</button><div id=rxout class=out>Masukkan reaksi.</div><div class=hint>Gunakan + untuk memisahkan zat dan -> atau → sebagai tanda reaksi.</div></div>`,
 molar:`<div class=panel><h3>Hitung Massa Molar</h3><input id=formula class=input placeholder="Contoh: H2O atau Ca(OH)2"><button class=btn onclick=calcMolar()>Hitung</button><div id=molarOut class=out>Contoh H2O ≈ 18,015 g/mol.</div></div>`,
 mol:`<div class=panel><h3>Mol ↔ Massa</h3><input id=mf class=input placeholder="Rumus senyawa, mis. H2O"><input id=mass class=input type=number placeholder="Massa (gram)"><button class=btn onclick=calcMol()>Hitung</button><div id=molOut class=out>Masukkan rumus dan massa.</div><hr><input id=molAmount class=input type=number placeholder="Jumlah mol"><button class=btn onclick=calcMassFromMol()>Hitung massa</button><div id=massOut class=out>Masukkan jumlah mol.</div></div>`,
 stoich:`<div class=panel><h3>Stoikiometri Sederhana</h3><input id=stoichRx class=input placeholder="Reaksi setara: 2H2 + O2 -> 2H2O"><input id=knownMol class=input type=number placeholder="Mol zat yang diketahui"><input id=knownIndex class=input type=number min=1 placeholder="Nomor zat di sisi reaktan/produk (1,2,...)"><input id=targetIndex class=input type=number min=1 placeholder="Nomor zat target"><button class=btn onclick=stoichCalc()>Hitung perbandingan mol</button><div id=stOut class=out>Masukkan reaksi setara dan nomor zat.</div><div class=hint>Nomor zat dihitung dari kiri ke kanan: contoh 2H2 + O2 berarti H2=1, O2=2; H2O=3.</div></div>`,
 combine:`<div class=panel><h3>Gabungkan / Analisis Reaksi</h3><textarea id=combineRx class=input rows=6 placeholder="Satu reaksi per baris, misalnya:\nH2 + Cl2 -> 2HCl\n2HCl -> H2 + Cl2"></textarea><button class=btn onclick=combineReactions()>Analisis</button><div id=combineOut class=out>Masukkan beberapa reaksi untuk melihat analisis zat di kedua sisi.</div><div class=hint>Fitur ini menjumlahkan zat kiri/kanan setelah penyederhanaan koefisien bilangan bulat. Untuk reaksi multi-langkah yang memerlukan pembalikan/penskalaan otomatis, gunakan hasil analisis sebagai panduan.</div></div>`,
 periodic:`<div class=panel><input class=input placeholder="Cari unsur..." oninput=filterElements(this.value)></div><div id=periodicGrid class=elements>${elements.map((e,i)=>`<button class=el data-name="${e[1].toLowerCase()}" onclick=elementInfo(${i})><b>${e[0]}</b><span>${e[2]}</span></button>`).join("")}</div><div id=elInfo class=panel><b>Pilih unsur</b><p class=muted>Nomor atom dan massa atom relatif akan ditampilkan.</p></div>`
 }[t];
 document.querySelector("#chemPanel").innerHTML=h;
}
function parseFormula(f){
 f=f.replace(/\s/g,"");let pos=0;
 function group(){
  let out={};
  while(pos<f.length){
   if(f[pos]==")"){pos++;break}
   if(f[pos]=="("){pos++;let sub=group(),num=readNum();for(let e in sub)out[e]=(out[e]||0)+sub[e]*num;continue}
   let m=f.slice(pos).match(/^([A-Z][a-z]?)/);if(!m)throw Error("Rumus tidak valid");
   let el=m[1];if(!AW[el])throw Error("Unsur "+el+" belum tersedia");pos+=el.length;let n=readNum();out[el]=(out[el]||0)+n;
  }return out;
 }
 function readNum(){let m=f.slice(pos).match(/^\d+/);if(!m)return 1;pos+=m[0].length;return +m[0]}
 let result=group();if(pos!==f.length)throw Error("Rumus tidak valid");return result;
}
function formulaMass(f){let p=parseFormula(f);return Object.entries(p).reduce((s,[e,n])=>s+AW[e]*n,0)}
function calcMolar(){try{let f=$("#formula").value,m=formulaMass(f);$("#molarOut").innerHTML=`<span class=formula>${f}</span><br>Massa molar = <b>${m.toFixed(3)} g/mol</b>`}catch(e){$("#molarOut").textContent=e.message||"Rumus tidak valid."}}
function calcMol(){try{let f=$("#mf").value,m=formulaMass(f),g=+$("#mass").value;$("#molOut").innerHTML=`Massa molar ${m.toFixed(3)} g/mol<br>Jumlah mol = <b>${(g/m).toFixed(6)} mol</b>`}catch(e){$("#molOut").textContent=e.message||"Data tidak valid."}}
function calcMassFromMol(){try{let f=$("#mf").value,m=formulaMass(f),n=+$("#molAmount").value;$("#massOut").innerHTML=`Massa molar ${m.toFixed(3)} g/mol<br>Massa = <b>${(n*m).toFixed(3)} gram</b>`}catch(e){$("#massOut").textContent=e.message||"Data tidak valid."}}
function equationParts(s){let p=s.replaceAll("→","->").split("->");if(p.length!==2)throw Error("Gunakan ->");return [p[0].split("+").map(x=>x.trim()).filter(Boolean),p[1].split("+").map(x=>x.trim()).filter(Boolean)]}
function rrefNull(A){
 let m=A.length,n=A[0].length,M=A.map(r=>r.slice()),row=0,piv=[];
 for(let c=0;c<n&&row<m;c++){let k=row;for(let i=row+1;i<m;i++)if(Math.abs(M[i][c])>Math.abs(M[k][c]))k=i;if(Math.abs(M[k][c])<1e-10)continue;[M[row],M[k]]=[M[k],M[row]];let q=M[row][c];for(let j=c;j<n;j++)M[row][j]/=q;for(let i=0;i<m;i++)if(i!==row){q=M[i][c];for(let j=c;j<n;j++)M[i][j]-=q*M[row][j]}piv.push(c);row++}
 let free=[];for(let c=0;c<n;c++)if(!piv.includes(c))free.push(c);if(!free.length)return null;
 let v=Array(n).fill(0);v[free[0]]=1;
 for(let i=piv.length-1;i>=0;i--){let c=piv[i],sum=0;for(let j=c+1;j<n;j++)sum+=M[i][j]*v[j];v[c]=-sum}
 let scale=1;v.forEach(x=>{let d=String(Math.abs(x)).split(".")[1];if(d)scale=Math.min(1000000,Math.max(scale,10**d.length))});
 let a=v.map(x=>Math.round(x*scale));let g=0;a.forEach(x=>g=gcd(g,Math.abs(x)));if(!g)return null;a=a.map(x=>x/g);if(a.some(x=>x<0))a=a.map(x=>-x);return a;
}
function gcd(a,b){while(b){let t=a%b;a=b;b=t}return Math.abs(a)}
function balanceReaction(){
 try{
  let [L,R]=equationParts($("#rx").value),all=[...L,...R],names=[...new Set(all.flatMap(f=>Object.keys(parseFormula(f))))];
  let A=names.map(e=>all.map((f,i)=>(parseFormula(f)[e]||0)*(i<L.length?1:-1)));
  let c=rrefNull(A);if(!c)throw Error("Tidak ada koefisien");
  let left=L.map((f,i)=>(c[i]===1?"":c[i])+f).join(" + "),right=R.map((f,i)=>(c[L.length+i]===1?"":c[L.length+i])+f).join(" + ");
  $("#rxout").innerHTML=`<span class=formula>${left} → ${right}</span>`;
 }catch(e){$("#rxout").textContent=e.message||"Reaksi tidak dapat disetarakan."}
}
function stoichCalc(){
 try{
  let [L,R]=equationParts($("#stoichRx").value),all=[...L,...R],a=+$("#knownIndex").value-1,b=+$("#targetIndex").value-1,n=+$("#knownMol").value;
  if(a<0||b<0||a>=all.length||b>=all.length)throw Error("Nomor zat tidak sesuai");
  let coeff=[...L,...R].map(x=>leadingCoeff(x));if(coeff.some(x=>!x))throw Error("Gunakan koefisien di awal rumus, mis. 2H2O");
  $("#stOut").innerHTML=`${all[a]} : ${n} mol<br>${all[b]} : <b>${(n*coeff[b]/coeff[a]).toFixed(6)} mol</b><br><span class=muted>Rasio dihitung dari koefisien reaksi yang Anda masukkan.</span>`;
 }catch(e){$("#stOut").textContent=e.message||"Data tidak valid."}
}
function leadingCoeff(f){let m=f.match(/^(\d+)\s*/);return m?+m[1]:1}
function combineReactions(){
 try{
  let lines=$("#combineRx").value.split(/\n/).map(x=>x.trim()).filter(Boolean),net={};
  lines.forEach(line=>{let [L,R]=equationParts(line);L.forEach(f=>{let c=leadingCoeff(f);let q=f.replace(/^\d+\s*/,"");net[q]=(net[q]||0)+c});R.forEach(f=>{let c=leadingCoeff(f);let q=f.replace(/^\d+\s*/,"");net[q]=(net[q]||0)-c})});
  let pos=[],neg=[];Object.entries(net).forEach(([f,c])=>{if(c>0)pos.push((c===1?"":c)+f);if(c<0)neg.push((Math.abs(c)===1?"":Math.abs(c))+f)});
  $("#combineOut").innerHTML=pos.length||neg.length?`Netto (arah kiri → kanan):<br><span class=formula>${pos.join(" + ")||"0"} → ${neg.join(" + ")||"0"}</span>`:"Semua zat saling habis.";
 }catch(e){$("#combineOut").textContent=e.message||"Format reaksi tidak valid."}
}
function filterElements(q){document.querySelectorAll(".el").forEach(b=>b.style.display=b.dataset.name.includes(q.toLowerCase())?"block":"none")}
function elementInfo(i){let e=elements[i];$("#elInfo").innerHTML=`<h3>${e[0]} — ${e[1]}</h3><p class=muted>Nomor atom: ${e[2]}<br>Massa atom relatif: ${e[3]} u<br>Simbol: ${e[0]}</p>`}

/* CATATAN */
function notes(){let n=JSON.parse(localStorage.getItem("rezaNotes")||"[]");return `<div class=panel><input id=nt class=input placeholder="Judul catatan"><textarea id=nc class=input rows=7 placeholder="Tulis catatan belajar..."></textarea><button class=btn onclick=saveNote()>Simpan</button></div><div id=noteList>${n.map((x,i)=>`<div class=note><button class=del onclick="deleteNote(${i})">Hapus</button><b>${esc(x.t)}</b><p>${esc(x.c).replaceAll("\n","<br>")}</p><small>${x.d}</small></div>`).join("")||"<p class=muted>Belum ada catatan.</p>"}</div>`}
function saveNote(){let c=$("#nc").value.trim();if(!c)return;let n=JSON.parse(localStorage.getItem("rezaNotes")||"[]");n.unshift({t:$("#nt").value.trim()||"Tanpa Judul",c,d:new Date().toLocaleString("id-ID")});localStorage.setItem("rezaNotes",JSON.stringify(n));openTool("notes")}
function deleteNote(i){let n=JSON.parse(localStorage.getItem("rezaNotes")||"[]");n.splice(i,1);localStorage.setItem("rezaNotes",JSON.stringify(n));openTool("notes")}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

/* EKONOMI */
function eco(){return `<div class=tabs><button class=active onclick=ecoTab('tax',this)>Pajak</button><button onclick=ecoTab('disc',this)>Diskon</button><button onclick=ecoTab('profit',this)>Untung/Rugi</button><button onclick=ecoTab('markup',this)>Markup</button></div><div id=ecoPanel></div>`}
function ecoTab(t,b){document.querySelectorAll(".tabs button").forEach(x=>x.classList.remove("active"));b.classList.add("active");let cfg={
 tax:{a:"Nilai dasar",b:"Pajak (%)",title:"Menghitung pajak",ex:"Pajak dihitung dari nilai dasar. Contoh: Rp100.000 dengan pajak 11% berarti pajaknya Rp11.000, sehingga totalnya Rp111.000.",formula:"Pajak = nilai dasar × persentase ÷ 100; Total = nilai dasar + pajak"},
 disc:{a:"Harga awal",b:"Diskon (%)",title:"Menghitung diskon",ex:"Diskon mengurangi harga awal. Contoh: Rp100.000 mendapat diskon 20% berarti potongannya Rp20.000 dan harga akhirnya Rp80.000.",formula:"Potongan = harga awal × persentase ÷ 100; Harga akhir = harga awal − potongan"},
 profit:{a:"Harga beli",b:"Harga jual",title:"Menghitung untung atau rugi",ex:"Harga jual dibandingkan dengan harga beli. Jika harga jual lebih tinggi, hasilnya untung; jika lebih rendah, hasilnya rugi.",formula:"Selisih = harga jual − harga beli; Persentase = |selisih| ÷ harga beli × 100%"},
 markup:{a:"Harga modal",b:"Markup (%)",title:"Menghitung markup",ex:"Markup adalah tambahan persentase di atas harga modal untuk menentukan harga jual. Contoh: modal Rp100.000 dan markup 25% menghasilkan tambahan Rp25.000.",formula:"Markup = modal × persentase ÷ 100; Harga jual = modal + markup"}
}[t];const moneyInput=(t==="tax"||t==="disc"||t==="profit"||t==="markup");document.querySelector("#ecoPanel").innerHTML=`<div class=panel><h3>${cfg.title}</h3><p class=muted>${cfg.ex}</p><div class=hint><b>Rumus:</b> ${cfg.formula}</div><input id=e1 class=input type="${moneyInput?"text":"number"}" inputmode="decimal" placeholder="${cfg.a}"><input id=e2 class=input type="${t==="profit"?"text":"number"}" inputmode="decimal" placeholder="${cfg.b}"><button class=btn onclick="ecoCalc('${t}')">Hitung</button><div id=ecoOut class=out>Masukkan data untuk melihat hasil dan penjelasannya.</div></div>`}
function parseEcoNumber(v){v=String(v).trim().replace(/\s/g,"");if(!v)return NaN;if(v.includes(".")&&v.includes(",")){if(v.lastIndexOf(",")>v.lastIndexOf("."))v=v.replace(/\./g,"").replace(",",".");else v=v.replace(/,/g,"")}else if(v.includes(".")){let parts=v.split(".");if(parts.length>1&&parts.slice(1).every(x=>/^\d{3}$/.test(x)))v=parts.join("");}else if(v.includes(",")){let parts=v.split(",");if(parts.length>1&&parts.slice(1).every(x=>/^\d{3}$/.test(x)))v=parts.join("");else v=v.replace(",",".")}return Number(v)}
function ecoCalc(t){let a=parseEcoNumber($("#e1").value),b=parseEcoNumber($("#e2").value),o="";if(!Number.isFinite(a)||!Number.isFinite(b)||a<0||b<0||(t==="profit"&&a===0)){$("#ecoOut").innerHTML="Masukkan angka yang valid. Harga beli/nilai dasar harus lebih dari 0 untuk menghitung persentase.";return}if(t==="tax"){let x=a*b/100;o=`Pajak: <b>${idr(x)}</b><br>Total setelah pajak: <b>${idr(a+x)}</b><br><span class=muted>Artinya, ${b}% dari ${idr(a)} adalah ${idr(x)}, lalu ditambahkan ke harga awal.</span>`}if(t==="disc"){let x=a*b/100;o=`Potongan: <b>${idr(x)}</b><br>Harga setelah diskon: <b>${idr(a-x)}</b><br><span class=muted>Artinya, ${b}% dari harga awal dikurangi dari harga sebelum diskon.</span>`}if(t==="profit"){let d=b-a;o=(d>=0?`Untung: <b>${idr(d)}</b>`:`Rugi: <b>${idr(-d)}</b>`)+`<br>Persentase terhadap harga beli: <b>${(Math.abs(d)/a*100).toFixed(2)}%</b><br><span class=muted>${d>=0?"Harga jual lebih tinggi daripada harga beli.":"Harga jual lebih rendah daripada harga beli."}</span>`}if(t==="markup"){let x=a*b/100;o=`Tambahan markup: <b>${idr(x)}</b><br>Harga jual: <b>${idr(a+x)}</b><br><span class=muted>Artinya, harga modal ditambah ${b}% sebagai markup.</span>`}$("#ecoOut").innerHTML=o}
function idr(x){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(x)}

/* KONVERSI */
const units={length:{Meter:1,"Kilometer":1000,"Centimeter":.01,"Milimeter":.001,"Kaki":.3048},mass:{Kilogram:1,Gram:.001,Ton:1000,Pound:.453592},area:{"m²":1,"km²":1e6,"cm²":1e-4,Hektar:1e4},volume:{Liter:1,"m³":1000,Mililiter:.001,"cm³":.001}};
function convert(){return `<div class=panel><select id=kind class=input onchange=initConv()><option value=length>Panjang</option><option value=mass>Massa</option><option value=area>Luas</option><option value=volume>Volume</option><option value=temp>Suhu</option></select><input id=cvVal class=input type=number placeholder="Nilai" oninput=doConv()><select id=from class=input onchange=doConv()></select><select id=to class=input onchange=doConv()></select><div id=cvOut class=out>Masukkan nilai.</div></div>`}
function initConv(){let k=$("#kind").value,u=k==="temp"?["C","F","K"]:Object.keys(units[k]);$("#from").innerHTML=u.map(x=>`<option>${x}</option>`).join("");$("#to").innerHTML=u.map(x=>`<option>${x}</option>`).join("");doConv()}
function doConv(){if(!$("#cvVal"))return;let k=$("#kind").value,v=+$("#cvVal").value,a=$("#from").value,b=$("#to").value;if(isNaN(v))return $("#cvOut").textContent="Masukkan nilai.";let z;if(k==="temp"){let c=a==="C"?v:a==="F"?(v-32)*5/9:v-273.15;z=b==="C"?c:b==="F"?c*9/5+32:c+273.15}else z=v*units[k][a]/units[k][b];$("#cvOut").innerHTML=`Hasil: <b>${z.toLocaleString("id-ID",{maximumFractionDigits:8})} ${b}</b>`}

openTool("calc");goHome();