
const money = n => 'R' + Number(n).toLocaleString('en-ZA',{maximumFractionDigits:0});
const toast = msg => { let t=document.getElementById('toast'); if(!t){t=document.createElement('div');t.id='toast';t.style='position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#17191c;color:white;padding:12px 16px;border-radius:12px;z-index:99;font-weight:700;box-shadow:0 8px 25px #0004';document.body.appendChild(t)} t.textContent=msg;t.style.display='block';clearTimeout(window.__t);window.__t=setTimeout(()=>t.style.display='none',2200)}
document.addEventListener('click',e=>{const b=e.target.closest('[data-toast]');if(b)toast(b.dataset.toast)});

if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');