const settingsDialog = document.getElementById('settingsDialog');
document.getElementById('settingsBtn').addEventListener('click', () => settingsDialog.showModal());
document.getElementById('closeSettings').addEventListener('click', () => settingsDialog.close());

const fileInput = document.getElementById('fileInput');
const fileList = document.getElementById('fileList');
const openPicker = () => fileInput.click();
document.getElementById('attachBtn').addEventListener('click', openPicker);
document.getElementById('attachBtnBottom').addEventListener('click', openPicker);

fileInput.addEventListener('change', () => {
  fileList.replaceChildren();
  [...fileInput.files].forEach(file => {
    const chip = document.createElement('span');
    chip.className = 'file-chip';
    chip.textContent = `${file.name} · ${Math.max(1, Math.round(file.size / 1024))} KB`;
    chip.title = file.name;
    fileList.appendChild(chip);
  });
});

document.getElementById('micBtn').addEventListener('click', () => {
  const status = document.getElementById('statusText');
  status.textContent = 'VOICE SETUP REQUIRED';
  window.setTimeout(() => status.textContent = 'READY TO CONNECT', 2200);
});
