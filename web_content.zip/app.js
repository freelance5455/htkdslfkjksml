const KEY='artiman_planner_v2';
const START_DATE_ISO='2026-09-26'; // شنبه ۴ مهر ۱۴۰۵
const START_DATE_FA='شنبه ۴ مهر ۱۴۰۵';

const DAYS=[
  {id:'sat',label:'شنبه',short:'ش',fixed:[['07:00','15:00','مدرسه','fixed'],['19:00','22:00','باشگاه','gym']]},
  {id:'sun',label:'یکشنبه',short:'ی',fixed:[['07:00','15:00','مدرسه','fixed'],['16:00','21:00','زبان','fixed']]},
  {id:'mon',label:'دوشنبه',short:'د',fixed:[['07:00','15:00','مدرسه','fixed'],['19:00','22:00','باشگاه','gym']]},
  {id:'tue',label:'سه‌شنبه',short:'س',fixed:[['07:00','15:00','مدرسه','fixed'],['16:00','21:00','زبان','fixed']]},
  {id:'wed',label:'چهارشنبه',short:'چ',fixed:[['07:00','15:00','مدرسه','fixed'],['19:00','22:00','باشگاه','gym']]},
  {id:'thu',label:'پنجشنبه',short:'پ',fixed:[['16:00','21:00','زبان','fixed']]},
  {id:'fri',label:'جمعه',short:'ج',fixed:[]}
];

const AREAS=[
  {id:'study',name:'مطالعه',icon:'📚'},
  {id:'guitar',name:'گیتار',icon:'🎸'},
  {id:'gym',name:'باشگاه',icon:'🏋️'},
  {id:'tiktok',name:'TikTok',icon:'🎬'}
];

const quotes=[
  'قرار نیست کامل باشی؛ فقط امروز یک قدم جلوتر باش.',
  'تمرکز روی قدم بعدی، نه کل مسیر.',
  'اول مهم‌ترین کار؛ بعد بقیه.',
  'پیشرفت کوچک هم پیشرفت است.',
  'کم، منظم و پیوسته؛ همین فرمول برنده است.'
];

function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function pad(n){return String(n).padStart(2,'0')}
function localKey(d){
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
}
function localDate(iso){
  const [y,m,d]=iso.split('-').map(Number);
  return new Date(y,m-1,d,0,0,0,0);
}
function todayId(){
  const map=['sun','mon','tue','wed','thu','fri','sat'];
  return map[new Date().getDay()];
}
function effectiveDay(){
  return isBeforeStart()? 'sat' : todayId();
}
function isBeforeStart(){
  const d=new Date(); d.setHours(0,0,0,0);
  return d < localDate(START_DATE_ISO);
}
function daysUntilStart(){
  const a=new Date(); a.setHours(0,0,0,0);
  const b=localDate(START_DATE_ISO);
  return Math.max(0,Math.round((b-a)/86400000));
}
function weekKeyFor(d){
  const x=new Date(d); x.setHours(0,0,0,0);
  const diff=(x.getDay()+1)%7; // Saturday = 0
  x.setDate(x.getDate()-diff);
  const key=localKey(x);
  return key<START_DATE_ISO?START_DATE_ISO:key;
}
function currentWeekKey(){
  return weekKeyFor(new Date());
}
function fmtDate(){
  return new Intl.DateTimeFormat('fa-IR',{weekday:'long',day:'numeric',month:'long'}).format(new Date());
}
function mins(a,b){
  const [ah,am]=a.split(':').map(Number),[bh,bm]=b.split(':').map(Number);
  return (bh*60+bm)-(ah*60+am);
}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function percent(done,total){return total?Math.round(done/total*100):0}
function areaName(id){return AREAS.find(a=>a.id===id)?.name||'آزاد'}

function defaultFlexible(){
  const tasks=[];
  DAYS.forEach(d=>{
    tasks.push({id:uid(),day:d.id,title:'TikTok / کار روی پیج',area:'tiktok',duration:45,time:'',completed:false});
  });
  const studyTimes={sat:'15:30',sun:'10:30',mon:'15:30',tue:'10:30',wed:'15:30',thu:'10:30'};
  const guitarTimes={sat:'17:00',sun:'09:30',mon:'17:00',tue:'09:30',wed:'17:00',thu:'09:30'};
  ['sat','sun','mon','tue','wed','thu'].forEach(day=>{
    tasks.push({id:uid(),day,title:'مطالعه',area:'study',duration:45,time:studyTimes[day],completed:false});
    tasks.push({id:uid(),day,title:'گیتار',area:'guitar',duration:45,time:guitarTimes[day],completed:false});
  });
  tasks.push({id:uid(),day:'fri',title:'مرور هفتگی و برنامه‌ریزی',area:'study',duration:30,time:'11:00',completed:false});
  tasks.push({id:uid(),day:'fri',title:'گیتار آزاد / آهنگ',area:'guitar',duration:45,time:'17:00',completed:false});
  return tasks;
}

function load(){
  try{
    const raw=localStorage.getItem(KEY);
    if(raw) return JSON.parse(raw);
  }catch(e){}
  return {
    week:currentWeekKey(),
    name:'آرتیمان',
    theme:'dark',
    reminders:true,
    selectedDay:effectiveDay(),
    tasks:defaultFlexible(),
    fixedDone:{},
    notes:''
  };
}
let state=load();

function migrate(){
  state.week=state.week||currentWeekKey();
  state.name=state.name||'آرتیمان';
  state.theme=state.theme||'dark';
  state.reminders=state.reminders!==false;
  state.selectedDay=state.selectedDay||effectiveDay();
  state.tasks=Array.isArray(state.tasks)?state.tasks:[];
  state.fixedDone=state.fixedDone||{};
  if(!Array.isArray(state.tasks)||state.tasks.length===0) state.tasks=defaultFlexible();
}
migrate();

function maybeRollWeek(){
  const wk=currentWeekKey();
  if(state.week!==wk){
    state.week=wk;
    state.tasks=defaultFlexible();
    state.fixedDone={};
    state.selectedDay=effectiveDay();
    save();
  }
}
maybeRollWeek();

function fixedTasks(day){
  const d=DAYS.find(x=>x.id===day);
  return (d?.fixed||[]).map((f,i)=>{
    const id=`fixed-${day}-${i}`;
    return {
      id,day,title:f[2],area:f[3],duration:mins(f[0],f[1]),
      time:f[0],end:f[1],completed:!!state.fixedDone[id],fixed:true
    };
  });
}
function dayTasks(day){return state.tasks.filter(t=>t.day===day)}
function allDayTasks(day){
  return [...fixedTasks(day),...dayTasks(day)].sort((a,b)=>(a.time||'99:99').localeCompare(b.time||'99:99'));
}
function allTrackedTasks(){
  const arr=[...state.tasks];
  DAYS.forEach(d=>fixedTasks(d).forEach(x=>{if(x.area==='gym')arr.push(x)}));
  return arr;
}
function todayTaskData(){
  const items=allDayTasks(effectiveDay());
  const total=items.length;
  const done=items.filter(t=>t.completed).length;
  const flex=items.filter(t=>!t.fixed);
  return {items,total,done,flex,flexDone:flex.filter(t=>t.completed).length,fixed:items.filter(t=>t.fixed)};
}
function tasksTotal(){return allTrackedTasks().length}
function tasksDone(){return allTrackedTasks().filter(t=>t.completed).length}
function areaStats(){
  return AREAS.map(a=>{
    let arr=state.tasks.filter(t=>t.area===a.id);
    if(a.id==='gym') DAYS.forEach(d=>{arr=[...arr,...fixedTasks(d).filter(t=>t.area==='gym')]});
    return {...a,total:arr.length,done:arr.filter(t=>t.completed).length};
  });
}
function setRing(v){document.querySelector('.hero-ring')?.style.setProperty('--p',v)}
function statusText(){
  if(isBeforeStart()) return `<span class="dot"></span><div><strong>شروع برنامه: ${START_DATE_FA}</strong><br><span class="muted">${daysUntilStart()} روز تا شروع؛ برنامه برای هفته اول آماده است.</span></div>`;
  const d=DAYS.find(x=>x.id===todayId());
  return `<span class="dot"></span><div><strong>برنامه فعاله</strong><br><span class="muted">امروز ${d.label} است.</span></div>`;
}

function renderHome(){
  document.getElementById('hello').textContent=`سلام ${state.name||'آرتیمان'} 👋`;
  document.getElementById('heroDate').textContent=fmtDate();
  document.getElementById('programStatus').innerHTML=statusText();
  document.getElementById('dailyQuote').textContent=quotes[new Date().getDate()%quotes.length];

  const td=todayTaskData();
  const p=percent(td.done,td.total);
  document.getElementById('todayPct').textContent=p+'%';
  setRing(p);

  const stats=[
    ['✅',td.done, 'انجام‌شده امروز'],
    ['⏳',Math.max(0,td.total-td.done),'باقی‌مانده'],
    ['📌',td.fixed.length,'بلاک ثابت']
  ];
  document.getElementById('todayStats').innerHTML=stats.map(s=>`<div class="stat"><div class="icon">${s[0]}</div><strong>${s[1]}</strong><span>${s[2]}</span></div>`).join('');

  document.getElementById('todayTaskCount').textContent=`${td.total} مورد`;
  document.getElementById('focusCards').innerHTML=areaStats().map(a=>{
    const q=percent(a.done,a.total);
    return `<div class="focus-card"><div class="focus-top"><span class="focus-name">${a.icon} ${a.name}</span><span class="muted">${q}%</span></div><div class="focus-meta">${a.done} از ${a.total} انجام شد</div><div class="mini-bar"><i style="width:${q}%"></i></div></div>`;
  }).join('');

  const items=td.items.slice(0,8);
  document.getElementById('todayPreview').innerHTML=items.length?items.map(taskHTML).join(''):`<div class="task-item"><div class="task-main"><div class="task-title">امروز سبک و آزاد است 🌿</div><div class="task-meta">یک کار کوچک انتخاب کن و شروع کن.</div></div></div>`;
}

function taskHTML(t){
  const done=!!t.completed;
  const cls=`task-item ${t.fixed?'fixed ':''}${t.area||''} ${done?'done':''}`;
  const checkAttr=t.fixed?`data-fixed-check="${t.id}"`:`data-check="${t.id}"`;
  return `<div class="${cls}">
    <button class="check ${done?'done':''}" ${checkAttr}></button>
    <div class="task-main"><div class="task-title">${esc(t.title)}</div>
    <div class="task-meta"><span>${t.time? t.time+' · ':''}${t.duration} دقیقه</span><span class="badge">${areaName(t.area)}</span>${t.fixed?'<span class="badge">ثابت</span>':''}</div></div>
    ${t.fixed?'':'<button class="delete-btn" data-delete="'+t.id+'" aria-label="حذف">⋯</button>'}
  </div>`;
}

function renderPlan(){
  const sel=state.selectedDay||effectiveDay();
  state.selectedDay=sel;
  document.getElementById('weekStrip').innerHTML=DAYS.map(d=>{
    const active=d.id===sel?'active':'';
    const count=allDayTasks(d.id).length;
    const done=allDayTasks(d.id).filter(x=>x.completed).length;
    return `<button class="day-chip ${active}" data-day="${d.id}"><span>${d.short}</span><strong>${d.label.slice(0,2)}</strong><span>${done}/${count}</span></button>`;
  }).join('');

  const meta=DAYS.find(d=>d.id===sel);
  const arr=allDayTasks(sel);
  const done=arr.filter(x=>x.completed).length;
  const fixedCount=arr.filter(x=>x.fixed).length;
  document.getElementById('daySummary').innerHTML=`<span>${meta.label} ${sel==='sat'&&isBeforeStart()?' · شروع برنامه':''}</span><strong>${done}/${arr.length} انجام شد · ${fixedCount} ثابت</strong>`;
  document.getElementById('planList').innerHTML=arr.length?arr.map(taskHTML).join(''):`<div class="task-item"><div class="task-main"><div class="task-title">هیچ کاری برای این روز ثبت نشده.</div></div></div>`;
}

function renderProgress(){
  const total=tasksTotal(),done=tasksDone(),p=percent(done,total);
  document.getElementById('weekPercent').textContent=p+'%';
  document.getElementById('weekProgressText').textContent=`${done} از ${total} مورد انجام شده`;
  document.getElementById('areaProgress').innerHTML=areaStats().map(a=>{
    const q=percent(a.done,a.total);
    return `<div class="progress-row"><div><strong>${a.icon} ${a.name}</strong><small>${a.done}/${a.total}</small></div><div class="bar"><i style="width:${q}%"></i></div></div>`;
  }).join('');
  document.getElementById('streakValue').textContent=streakDays()+' روز';
}

function streakDays(){
  if(isBeforeStart()) return 0;
  const todayIndex=DAYS.findIndex(d=>d.id===todayId());
  let n=0;
  for(let i=todayIndex;i>=0;i--){
    const d=DAYS[i];
    const arr=allDayTasks(d);
    if(!arr.length || !arr.every(t=>t.completed)) break;
    n++;
  }
  return n;
}

function renderNotes(){document.getElementById('notes').value=state.notes||''}
function applyTheme(){
  document.body.dataset.theme=state.theme==='light'?'light':'dark';
}
function renderSettings(){
  applyTheme();
  document.getElementById('themeToggle').checked=state.theme==='dark';
  document.getElementById('reminderToggle').checked=state.reminders!==false;
  document.getElementById('nameSummary').textContent=state.name||'آرتیمان';
}
function render(){maybeRollWeek();renderHome();renderPlan();renderProgress();renderNotes();renderSettings()}
function switchScreen(name){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById('screen-'+name)?.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.screen===name));
  window.scrollTo({top:0,behavior:'smooth'});
}
function openModal(){
  const sel=document.getElementById('taskDay');
  sel.innerHTML=DAYS.map(d=>`<option value="${d.id}">${d.label}</option>`).join('');
  sel.value=state.selectedDay||effectiveDay();
  document.getElementById('taskArea').innerHTML=AREAS.map(a=>`<option value="${a.id}">${a.icon} ${a.name}</option>`).join('');
  document.getElementById('modalBackdrop').classList.remove('hidden');
}
function closeModal(){
  document.getElementById('modalBackdrop').classList.add('hidden');
  document.getElementById('taskForm').reset();
}
function showToast(msg){
  const el=document.getElementById('toast');
  el.textContent=msg;el.classList.remove('hidden');
  clearTimeout(window.__toast);
  window.__toast=setTimeout(()=>el.classList.add('hidden'),2200);
}
function download(name,text,type='application/json'){
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([text],{type}));
  a.download=name;a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),500);
}

document.addEventListener('click',e=>{
  const nav=e.target.closest('.nav-item');
  if(nav){switchScreen(nav.dataset.screen);return}

  const day=e.target.closest('.day-chip');
  if(day){state.selectedDay=day.dataset.day;save();renderPlan();return}

  const check=e.target.closest('[data-check]');
  if(check){
    const t=state.tasks.find(x=>x.id===check.dataset.check);
    if(t){t.completed=!t.completed;save();render();showToast(t.completed?'انجام شد ✅':'علامت برداشته شد');}
    return;
  }

  const fixedCheck=e.target.closest('[data-fixed-check]');
  if(fixedCheck){
    const id=fixedCheck.dataset.fixedCheck;
    state.fixedDone[id]=!state.fixedDone[id];
    save();render();showToast(state.fixedDone[id]?'بلاک انجام شد ✅':'علامت برداشته شد');
    return;
  }

  const del=e.target.closest('[data-delete]');
  if(del){
    state.tasks=state.tasks.filter(x=>x.id!==del.dataset.delete);
    save();render();showToast('کار حذف شد');
  }
});

document.getElementById('addTaskBtn').onclick=openModal;
document.getElementById('quickAddTop').onclick=openModal;
document.getElementById('modalClose').onclick=closeModal;
document.getElementById('cancelModal').onclick=closeModal;
document.getElementById('modalBackdrop').addEventListener('click',e=>{if(e.target.id==='modalBackdrop')closeModal()});

document.getElementById('taskForm').addEventListener('submit',e=>{
  e.preventDefault();
  const title=document.getElementById('taskTitle').value.trim();
  if(!title)return;
  const t={
    id:uid(),
    day:document.getElementById('taskDay').value,
    title,area:document.getElementById('taskArea').value,
    duration:Number(document.getElementById('taskDuration').value)||45,
    time:document.getElementById('taskTime').value,
    completed:false
  };
  state.tasks.push(t);
  state.selectedDay=t.day;
  save();closeModal();render();switchScreen('plan');showToast('کار جدید اضافه شد ✨');
});

document.getElementById('openToday').onclick=()=>{
  state.selectedDay=effectiveDay();save();renderPlan();switchScreen('plan');
};
document.getElementById('manageAreas').onclick=()=>switchScreen('plan');

document.getElementById('saveNote').onclick=()=>{
  state.notes=document.getElementById('notes').value;
  save();showToast('یادداشت ذخیره شد 💾');
};

document.getElementById('themeToggle').onchange=e=>{
  state.theme=e.target.checked?'dark':'light';save();applyTheme();showToast('تم ذخیره شد');
};
document.getElementById('reminderToggle').onchange=e=>{
  state.reminders=e.target.checked;save();showToast('تنظیمات ذخیره شد');
};
document.getElementById('editName').onclick=()=>{
  const n=prompt('اسم شما:',state.name||'آرتیمان');
  if(n!==null){state.name=n.trim()||'آرتیمان';save();render();}
};
document.getElementById('exportData').onclick=()=>{
  download('artiman-planner-backup.json',JSON.stringify(state,null,2));
};
document.getElementById('clearData').onclick=()=>{
  if(confirm('همه داده‌های پلنر پاک شود؟')){localStorage.removeItem(KEY);location.reload();}
};
document.getElementById('resetWeek').onclick=()=>{
  if(confirm('کارهای این هفته و تیک‌های بلاک‌های ثابت ریست شوند؟')){
    state.week=currentWeekKey();state.tasks=defaultFlexible();state.fixedDone={};state.selectedDay=effectiveDay();save();render();showToast('هفته ریست شد 🔄');
  }
};

render();
if('serviceWorker' in navigator){
  window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
}
