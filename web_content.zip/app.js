const $ = (id) => document.getElementById(id);
const ui = {
  welcome: $('welcome'), quiz: $('quiz'), results: $('results'), sectionSelect: $('sectionSelect'),
  savedSession: $('savedSession'), savedSummary: $('savedSummary'),
  studyKey: $('studyKey'), studyKeyContent: $('studyKeyContent'), studySearch: $('studySearch'), studyCount: $('studyCount'),
  sectionName: $('sectionName'), progressLabel: $('progressLabel'), progressBar: $('progressBar'),
  questionIndex: $('questionIndex'), answeredCount: $('answeredCount'), visualWrap: $('visualWrap'),
  questionVisual: $('questionVisual'), prompt: $('prompt'), options: $('options'), feedback: $('feedback'),
  prevBtn: $('prevBtn'), checkBtn: $('checkBtn'), nextBtn: $('nextBtn'), finishBtn: $('finishBtn')
};
let allQuestions = [];
let sessionQuestions = [];
let current = 0;
let responses = [];
let studyKeyBuilt = false;
const SAVE_KEY = 'evolve-practice-session-v1';

function init() {
  allQuestions = QUESTION_BANK;
  $('startBtn').addEventListener('click', startTest);
  $('resumeBtn').addEventListener('click', resumeTest);
  $('discardBtn').addEventListener('click', startOver);
  $('exitBtn').addEventListener('click', returnHome);
  ui.prevBtn.addEventListener('click', () => move(-1));
  ui.nextBtn.addEventListener('click', () => move(1));
  ui.checkBtn.addEventListener('click', checkAnswer);
  ui.finishBtn.addEventListener('click', finishTest);
  ui.options.addEventListener('keydown', (event) => {
    if (!['ArrowDown', 'ArrowRight', 'ArrowUp', 'ArrowLeft', 'Home', 'End'].includes(event.key) || responses[current]?.checked) return;
    const buttons = [...ui.options.querySelectorAll('.option:not(:disabled)')];
    const active = buttons.indexOf(document.activeElement);
    if (active < 0 || buttons.length < 2) return;
    event.preventDefault();
    const next = event.key === 'Home' ? 0
      : event.key === 'End' ? buttons.length - 1
      : (active + (['ArrowDown', 'ArrowRight'].includes(event.key) ? 1 : -1) + buttons.length) % buttons.length;
    selectOption(buttons[next].dataset.label, true);
  });
  ui.studyKey.addEventListener('toggle', () => {
    if (!ui.studyKey.open || studyKeyBuilt) return;
    ui.studyKeyContent.innerHTML = `<ol class="answer-key-list">${renderAnswerKey(allQuestions)}</ol>`;
    studyKeyBuilt = true;
    filterStudyKey();
  });
  ui.studySearch.addEventListener('input', filterStudyKey);
  updateSavedSession();
}

function startTest() {
  const section = ui.sectionSelect.value;
  sessionQuestions = allQuestions.filter(q => section === 'all' || q.section === section);
  current = 0;
  responses = sessionQuestions.map(() => ({ selected: null, checked: false }));
  saveSession();
  ui.welcome.classList.add('hidden');
  ui.results.classList.add('hidden');
  ui.quiz.classList.remove('hidden');
  renderQuestion();
}

function renderQuestion() {
  const q = sessionQuestions[current];
  const response = responses[current];
  const total = sessionQuestions.length;
  ui.sectionName.textContent = q.section;
  ui.progressLabel.textContent = `${current + 1} / ${total}`;
  ui.progressBar.style.width = `${((current + 1) / total) * 100}%`;
  ui.progressBar.parentElement.setAttribute('aria-valuemax', total);
  ui.progressBar.parentElement.setAttribute('aria-valuenow', current + 1);
  ui.progressBar.parentElement.setAttribute('aria-valuetext', `Question ${current + 1} of ${total}`);
  ui.questionIndex.textContent = `QUESTION ${q.number}`;
  ui.answeredCount.textContent = `${responses.filter(r => r.checked).length} answered`;
  ui.prompt.textContent = q.prompt;
  if (q.visual) {
    ui.questionVisual.src = q.visual;
    ui.questionVisual.alt = `Illustration for question ${q.number}: ${q.prompt.replace(/\s+/g, ' ').slice(0, 140)}`;
    ui.visualWrap.classList.remove('hidden');
  } else {
    ui.questionVisual.removeAttribute('src');
    ui.visualWrap.classList.add('hidden');
  }
  ui.options.replaceChildren();
  for (const option of q.options) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'option';
    button.setAttribute('role', 'radio');
    button.setAttribute('aria-checked', String(response.selected === option.label));
    button.dataset.label = option.label;
    if (response.selected === option.label) button.classList.add('selected');
    if (response.checked && option.label === q.answer) button.classList.add('correct');
    if (response.checked && option.label === response.selected && response.selected !== q.answer) button.classList.add('incorrect');
    button.disabled = response.checked;
    const key = document.createElement('span');
    key.className = 'option-key';
    key.textContent = option.label;
    const text = document.createElement('span');
    text.textContent = option.text;
    button.append(key, text);
    button.addEventListener('click', () => selectOption(option.label));
    ui.options.append(button);
  }
  ui.prevBtn.disabled = current === 0;
  ui.checkBtn.classList.toggle('hidden', response.checked);
  ui.checkBtn.disabled = !response.selected;
  ui.nextBtn.classList.toggle('hidden', !response.checked);
  ui.nextBtn.innerHTML = current === total - 1 ? 'See results <span aria-hidden="true">→</span>' : 'Next question <span aria-hidden="true">→</span>';
  ui.feedback.classList.toggle('hidden', !response.checked);
  ui.feedback.classList.toggle('wrong', response.checked && response.selected !== q.answer);
  if (response.checked) {
    const correct = q.options.find(option => option.label === q.answer);
    ui.feedback.innerHTML = response.selected === q.answer
      ? '<strong>Correct!</strong>Keep going - you have this.'
      : `<strong>Not quite.</strong>The correct answer is <b>${escapeHtml(correct.label)}. ${escapeHtml(correct.text)}</b>`;
  } else {
    ui.feedback.textContent = '';
  }
}

function selectOption(label, restoreFocus = false) {
  if (responses[current].checked) return;
  responses[current].selected = label;
  saveSession();
  ui.checkBtn.disabled = false;
  renderQuestion();
  if (restoreFocus) ui.options.querySelector(`.option[data-label="${label}"]`)?.focus();
}

function checkAnswer() {
  if (!responses[current].selected) return;
  responses[current].checked = true;
  saveSession();
  renderQuestion();
}

function move(direction) {
  const next = current + direction;
  if (next < 0) return;
  if (next >= sessionQuestions.length) return showResults();
  current = next;
  saveSession();
  renderQuestion();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function finishTest() {
  const unanswered = responses.filter(r => !r.checked).length;
  if (unanswered && !window.confirm(`You still have ${unanswered} unanswered question${unanswered === 1 ? '' : 's'}. Finish and see your score?`)) return;
  showResults();
}

function showResults() {
  clearSavedSession();
  updateSavedSession();
  ui.quiz.classList.add('hidden');
  ui.results.classList.remove('hidden');
  const score = responses.reduce((sum, response, index) => sum + (response.checked && response.selected === sessionQuestions[index].answer ? 1 : 0), 0);
  const checked = responses.filter(r => r.checked).length;
  const total = sessionQuestions.length;
  const percent = Math.round(score / total * 100);
  const review = sessionQuestions.map((q, i) => ({ q, response: responses[i] }));
  ui.results.innerHTML = `
    <div class="result-hero panel">
      <div class="score-ring"><span class="score-number">${score}/${total}</span><span class="score-caption">correct</span></div>
      <h1>${percent >= 80 ? 'Great work.' : 'Good practice.'}</h1>
      <p>You answered ${checked} of ${total} questions. ${score} were correct${checked < total ? `; ${total - checked} were left unanswered` : ''}.</p>
      <div class="result-actions"><button class="button primary" id="reviewBtn">Review my answers</button><button class="button secondary" id="answerKeyBtn">Full answer key</button><button class="button secondary" id="againBtn">Try again</button></div>
    </div>
    <div class="panel" style="margin-top:16px"><div class="review-head">Answer review</div><ul class="review-list">${review.map(({q,response}) => {
      const correct = response.checked && response.selected === q.answer;
      const right = q.options.find(o => o.label === q.answer);
      const chosen = response.selected ? q.options.find(o => o.label === response.selected) : null;
      return `<li class="review-item"><span class="review-state ${correct ? 'good' : 'bad'}">${correct ? '✓' : '×'}</span><div><div class="review-question"><b>Q${q.number}.</b> ${escapeHtml(q.prompt.replace(/\n/g, ' '))}</div><div class="review-answer">${chosen ? `Your answer: ${escapeHtml(chosen.label)}. ${escapeHtml(chosen.text)}<br>` : 'Not answered<br>'}Correct: ${escapeHtml(right.label)}. ${escapeHtml(right.text)}</div></div></li>`;
    }).join('')}</ul></div>
    <div class="panel answer-key-panel"><div class="review-head answer-key-head">Full answer key <span>✓ marks the correct answer</span></div><ol class="answer-key-list">${renderAnswerKey(sessionQuestions)}</ol></div>`;
  $('reviewBtn').addEventListener('click', () => document.querySelector('.review-head').scrollIntoView({ behavior: 'smooth' }));
  $('answerKeyBtn').addEventListener('click', () => document.querySelector('.answer-key-head').scrollIntoView({ behavior: 'smooth' }));
  $('againBtn').addEventListener('click', returnHome);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderAnswerKey(questions) {
  return questions.map(q => {
    const searchText = escapeHtml([`Q${q.number}`, q.number, q.prompt, ...q.options.map(option => option.text)].join(' ').replace(/\s+/g, ' '));
    return `<li class="answer-key-item" data-search="${searchText}"><div class="answer-key-question"><b>Q${q.number}.</b> ${escapeHtml(q.prompt.replace(/\n/g, ' '))}</div>${q.visual ? `<img class="answer-key-visual" src="${escapeHtml(q.visual)}" alt="Illustration for question ${q.number}" loading="lazy" decoding="async">` : ''}<ul class="answer-key-options">${q.options.map(option => `<li class="answer-key-option ${option.label === q.answer ? 'is-correct' : ''}"><span class="answer-key-mark" aria-hidden="true">${option.label === q.answer ? '✓' : ''}</span><span><b>${escapeHtml(option.label)}.</b> ${escapeHtml(option.text)}</span></li>`).join('')}</ul></li>`;
  }).join('');
}

function filterStudyKey() {
  if (!studyKeyBuilt) return;
  const query = ui.studySearch.value.trim().toLocaleLowerCase();
  const items = [...ui.studyKeyContent.querySelectorAll('.answer-key-item')];
  let visible = 0;
  for (const item of items) {
    const matches = !query || item.dataset.search.toLocaleLowerCase().includes(query);
    item.classList.toggle('study-filtered-out', !matches);
    if (matches) visible++;
  }
  ui.studyCount.textContent = query ? `${visible} of ${items.length} questions` : `${items.length} questions`;
}

function returnHome() {
  ui.quiz.classList.add('hidden');
  ui.results.classList.add('hidden');
  ui.welcome.classList.remove('hidden');
  updateSavedSession();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function saveSession() {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify({
      section: ui.sectionSelect.value,
      questionNumbers: sessionQuestions.map(q => q.number),
      current,
      responses
    }));
  } catch { /* Storage may be disabled; practice still works for this page visit. */ }
  updateSavedSession();
}

function readSavedSession() {
  try {
    const saved = JSON.parse(localStorage.getItem(SAVE_KEY));
    if (!saved || !Array.isArray(saved.questionNumbers) || !Array.isArray(saved.responses)) return null;
    const questions = allQuestions.filter(q => saved.questionNumbers.includes(q.number));
    if (!questions.length || questions.length !== saved.questionNumbers.length || saved.responses.length !== questions.length) return null;
    const responses = saved.responses.map((response, index) => {
      const labels = questions[index].options.map(option => option.label);
      return {
        selected: labels.includes(response.selected) ? response.selected : null,
        checked: Boolean(response.checked && labels.includes(response.selected))
      };
    });
    const section = ['Light motor vehicle', 'Heavy motor vehicle'].includes(saved.section)
      ? 'Code 8 & Code 10'
      : saved.section;
    return { ...saved, section, questions, responses };
  } catch { return null; }
}

function updateSavedSession() {
  const saved = readSavedSession();
  ui.savedSession.classList.toggle('hidden', !saved);
  if (!saved) return;
  const answered = saved.responses.filter(response => response.checked).length;
  const sectionLabel = saved.section === 'all' ? 'Full practice test' : saved.section;
  ui.savedSummary.textContent = `${sectionLabel} · ${answered} of ${saved.questions.length} answered`;
}

function resumeTest() {
  const saved = readSavedSession();
  if (!saved) { updateSavedSession(); return; }
  sessionQuestions = saved.questions;
  responses = saved.responses;
  current = Math.min(Math.max(0, Number(saved.current) || 0), sessionQuestions.length - 1);
  ui.sectionSelect.value = saved.section;
  ui.welcome.classList.add('hidden');
  ui.results.classList.add('hidden');
  ui.quiz.classList.remove('hidden');
  renderQuestion();
}

function startOver() {
  const saved = readSavedSession();
  if (!saved) { updateSavedSession(); return; }
  ui.sectionSelect.value = saved.section;
  clearSavedSession();
  startTest();
}

function clearSavedSession() {
  try { localStorage.removeItem(SAVE_KEY); } catch { /* Ignore unavailable storage. */ }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}

init();

