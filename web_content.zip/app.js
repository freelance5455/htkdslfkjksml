let billItems = [];

const SHOP_NAME = "Hassan Electric Trader";
const SHOP_PHONE = "03006980431";
function getNextBillNumber() {
    let number =
        Number(localStorage.getItem("lastBillNumber")) || 0;

    number++;

    localStorage.setItem(
        "lastBillNumber",
        number
    );

    return number;
}
document.addEventListener("DOMContentLoaded", function () {
    addInventoryButton();
    addHistoryButton();
    updateDashboard();
});

function updateDashboard() {

    const bills =
        JSON.parse(localStorage.getItem("bills")) || [];

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    let todaySales = 0;

    const today =
        new Date().toLocaleDateString();

    bills.forEach(function (bill) {

        const billDate =
            new Date(bill.date).toLocaleDateString();

        if (billDate === today) {
            todaySales += Number(bill.total) || 0;
        }
    });

    const todaySalesElement =
        document.getElementById("todaySales");

    const totalBillsElement =
        document.getElementById("totalBills");

    const totalProductsElement =
        document.getElementById("totalProducts");

    if (todaySalesElement) {
        todaySalesElement.textContent =
            "Rs. " + todaySales;
    }

    if (totalBillsElement) {
        totalBillsElement.textContent =
            bills.length;
    }

    if (totalProductsElement) {
        totalProductsElement.textContent =
            products.length;
    }
}

function addInventoryButton() {
    const card = document.querySelector(".welcome-card");

    if (!card || document.getElementById("inventoryButton")) return;

    const button = document.createElement("button");
    button.id = "inventoryButton";
    button.textContent = "📦 Inventory";

    button.onclick = openInventory;

    card.appendChild(button);
}

function addHistoryButton() {

    const card = document.querySelector(".welcome-card");

    if (!card) return;

    if (document.getElementById("historyButton")) return;

    const button = document.createElement("button");

    button.id = "historyButton";
    button.textContent = "📋 Bill History";

    button.onclick = showBillHistory;

    card.appendChild(button);
}

function showBillHistory() {

    document.querySelector(".welcome-card").style.display = "none";
    document.querySelector(".dashboard").style.display = "none";

    document.querySelector(".container").innerHTML = `
        <section class="bill-card">

            <h2>📋 Bill History</h2>
<input
    id="billSearch"
    type="text"
    placeholder="Search Bill No. ya Customer Name"
    oninput="loadBillHistory()"
>
            <div id="billHistoryList"></div>

            <button onclick="goHome()">
                Back
            </button>

        </section>
    `;

    loadBillHistory();
}

function loadBillHistory() {

    const bills =
        JSON.parse(localStorage.getItem("bills")) || [];
const searchInput = document.getElementById("billSearch");

const search =
    searchInput
        ? searchInput.value.trim().toLowerCase()
        : "";

const filteredBills = bills.filter(function (bill) {

    const billNumber =
        String(bill.billNumber || "").toLowerCase();

    const customer =
        String(bill.customer || "").toLowerCase();

    return (
        billNumber.includes(search) ||
        customer.includes(search)
    );
});
    const list =
        document.getElementById("billHistoryList");

    if (!list) return;

    if (bills.length === 0) {

        list.innerHTML =
            "<p>Abhi koi bill save nahi hua.</p>";

        return;
    }

    list.innerHTML = "";

    const historyBills =
    filteredBills
        .map(function (bill) {
            return {
                bill: bill,
                index: bills.indexOf(bill)
            };
        })
        .reverse();

historyBills.forEach(function (item) {

    const bill = item.bill;
    const index = item.index;

    const date =
        new Date(bill.date);

    list.innerHTML += `
        <div class="history-item">

            <h3>
                Bill No. ${bill.billNumber || "-"}
            </h3>

            <p>
                <strong>Date:</strong>
                ${date.toLocaleDateString()}
            </p>

            <p>
                <strong>Time:</strong>
                ${date.toLocaleTimeString()}
            </p>

            <p>
                <strong>Customer:</strong>
                ${bill.customer || "Walk-in Customer"}
            </p>

            <p>
                <strong>Phone:</strong>
                ${bill.customerPhone || "-"}
            </p>

            <p>
                <strong>Total:</strong>
                Rs. ${bill.total}
            </p>

            <div>
                <strong>Products:</strong>

                ${bill.items.map(function (item) {
                    return `
                        <p>
                            ${item.name}
                            — ${item.quantity} × Rs. ${item.price}
                            = Rs. ${item.total}
                        </p>
                    `;
                }).join("")}
            </div>

            <button onclick="viewBill(${index})">
                👁️ View Bill
            </button>

            <button onclick="deleteBill(${index})">
                🗑️ Delete Bill
            </button>

        </div>
    `;
});
}        
   function deleteBill(index) {

    const confirmDelete =
        confirm("Kya aap ye bill delete karna chahte hain?");

    if (!confirmDelete) return;

    const bills =
        JSON.parse(localStorage.getItem("bills")) || [];

    if (!bills[index]) {
        alert("Bill not found.");
        return;
    }

    bills.splice(index, 1);

    localStorage.setItem(
        "bills",
        JSON.stringify(bills)
    );

    alert("Bill deleted successfully!");

    loadBillHistory();
}
    
function viewBill(index) {

    const bills =
        JSON.parse(localStorage.getItem("bills")) || [];

    const bill = bills[index];

    if (!bill) {
        alert("Bill not found.");
        return;
    }

    const date = new Date(bill.date);

    document.querySelector(".container").innerHTML = `
        <section class="receipt">

            <div class="receipt-header">
                <h1>${SHOP_NAME}</h1>
                <p>Shop No: ${SHOP_PHONE}</p>

                <hr>

                <p>
                    <strong>Bill No:</strong>
                    ${bill.billNumber || "-"}
                </p>

                <p>
                    <strong>Date:</strong>
                    ${date.toLocaleDateString()}
                </p>

                <p>
                    <strong>Time:</strong>
                    ${date.toLocaleTimeString()}
                </p>

                <p>
                    <strong>Customer:</strong>
                    ${bill.customer || "Walk-in Customer"}
                </p>

                <p>
                    <strong>Mobile:</strong>
                    ${bill.customerPhone || "-"}
                </p>
            </div>

            <hr>

            <div>
                ${bill.items.map(function (item) {
                    return `
                        <div class="receipt-item">
                            <div>
                                <strong>${item.name}</strong>
                                <br>
                                ${item.quantity} × Rs. ${item.price}
                            </div>

                            <div>
                                Rs. ${item.total}
                            </div>
                        </div>
                    `;
                }).join("")}
            </div>

            <div class="receipt-total">
                <strong>Grand Total</strong>
                <strong>Rs. ${bill.total}</strong>
            </div>

            <div class="receipt-footer">
                Thanks for visiting our shop!
            </div>

            <button class="no-print" onclick="window.print()">
    🖨️ Print / Save PDF
</button>

<button class="no-print" onclick="location.reload()">
    Back to History
</button>
<button
    class="no-print"
    onclick="printBluetoothReceipt()"
>
    🖨️ Bluetooth Print
</button>
        </section>
    `;
}
function createNewBill() {

    const container =
        document.querySelector(".container");

    if (!container) return;

    document.querySelectorAll(
        ".welcome-card, .dashboard"
    ).forEach(function (element) {
        element.style.display = "none";
    });

    container.innerHTML = `
        <section class="bill-card">

            <h2>🧾 New Bill</h2>

            <div class="bill-info">
                <p>
                    <strong>Hassan Electric Trader</strong>
                </p>
                <p>
                    Shop No: 03006980431
                </p>
            </div>

            <label>Customer Name</label>

            <input
                type="text"
                id="newBillCustomerName"
                placeholder="Customer name"
            >

            <label>Customer Phone</label>

            <input
                type="tel"
                id="newBillCustomerPhone"
                placeholder="0300..."
            >

            <hr>

            <h3>Add Product</h3>

            <label>Search Product</label>

            <input
                type="text"
                id="discountBillProductSearch"
                placeholder="Product search..."
                oninput="discountBillSearchProducts()"
            >

            <div id="discountBillProductResults"></div>

            <label>Selected Product</label>

            <input
                type="text"
                id="discountBillSelectedProduct"
                readonly
                placeholder="Product select karein"
            >

            <input
                type="hidden"
                id="discountBillSelectedProductId"
            >

            <label>Quantity</label>

            <input
                type="number"
                id="discountBillQuantity"
                value="1"
                min="1"
            >

            <label>Sale Price</label>

            <input
                type="number"
                id="discountBillPrice"
                readonly
                placeholder="Product select karne par price ayegi"
            >

            <button
                type="button"
                onclick="discountBillAddProduct()"
            >
                + Add Product
            </button>

            <hr>

            <h3>Bill Items</h3>

            <div id="discountBillItems">
                <p>No products added.</p>
            </div>

            <label>Discount Type</label>

            <select
                id="newBillDiscountType"
                onchange="discountBillCalculate()"
            >
                <option value="amount">
                    Fixed Rs. Discount
                </option>

                <option value="percent">
                    Percentage % Discount
                </option>
            </select>

            <label>Discount</label>

            <input
                type="number"
                id="newBillDiscountValue"
                value="0"
                min="0"
                oninput="discountBillCalculate()"
                placeholder="0"
            >

            <div
                id="discountBillTotal"
                class="bill-total"
            >
                Subtotal: Rs. 0
                <br>
                Discount: Rs. 0
                <br>
                <strong>
                    Final Total: Rs. 0
                </strong>
            </div>

            <button
                type="button"
                onclick="saveDiscountBill()"
            >
                💾 Save Bill
            </button>

            <button
                type="button"
                onclick="goHome()"
            >
                🏠 Back to Home
            </button>

        </section>
    `;

    discountBillItems = [];

    discountBillCalculate();
}
function searchCustomers() {

    const search =
        document.getElementById("customerName")
            .value
            .trim()
            .toLowerCase();

    const suggestions =
        document.getElementById("customerSuggestions");

    if (!suggestions) return;

    if (!search) {
        suggestions.innerHTML = "";
        return;
    }

    const bills =
        JSON.parse(localStorage.getItem("bills")) || [];

    const customers = [];

    bills.forEach(function (bill) {

        if (
            bill.customer &&
            bill.customer.toLowerCase().includes(search)
        ) {

            const alreadyExists =
                customers.some(function (customer) {
                    return customer.name === bill.customer;
                });

            if (!alreadyExists) {
                customers.push({
                    name: bill.customer,
                    phone: bill.customerPhone || ""
                });
            }
        }
    });

    suggestions.innerHTML = "";

    customers.slice(0, 5).forEach(function (customer) {

        const button =
            document.createElement("button");

        button.textContent =
            customer.name +
            (customer.phone
                ? " - " + customer.phone
                : "");

        button.type = "button";

        button.onclick = function () {

            document.getElementById("customerName").value =
                customer.name;

            document.getElementById("customerPhone").value =
                customer.phone;

            suggestions.innerHTML = "";
        };

        suggestions.appendChild(button);
    });
}
            

function loadProductsIntoBill() {
    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    const select = document.getElementById("productSelect");

    if (!select) return;

        select.innerHTML =
        '<option value="">-- Pehle product search karein --</option>';
}

function searchProducts() {

    const search =
        document.getElementById("productSearch")
            .value
            .trim()
            .toLowerCase();

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    const select =
        document.getElementById("productSelect");

    if (!select) return;

    select.innerHTML =
        '<option value="">-- Select Product --</option>';

    products
        .filter(function (product) {
            return product.name
                .toLowerCase()
                .includes(search);
        })
        .forEach(function (product) {

            select.innerHTML += `
                <option value="${product.id}">
                    ${product.name} - Rs. ${product.price}
                    - Stock: ${product.stock}
                </option>
            `;
        });
}
function productSelected() {
    const id = document.getElementById("productSelect").value;

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    const product = products.find(function (p) {
        return p.id == id;
    });

    document.getElementById("price").value =
        product ? product.price : "";
}

function addProduct() {
    const id = document.getElementById("productSelect").value;
    const quantity =
        Number(document.getElementById("quantity").value);

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    const product = products.find(function (p) {
        return p.id == id;
    });

    if (!product) {
        alert("Please select a product.");
        return;
    }

    if (quantity <= 0) {
        alert("Please enter a valid quantity.");
        return;
    }

    if (quantity > product.stock) {
        alert("Not enough stock. Stock: " + product.stock);
        return;
    }

    const existing = billItems.find(function (item) {
        return item.id == product.id;
    });

    if (existing) {
        existing.quantity += quantity;
        existing.total =
            existing.quantity * existing.price;
    } else {
        billItems.push({
            id: product.id,
            name: product.name,
            quantity: quantity,
            price: product.price,
            total: quantity * product.price
        });
    }

    document.getElementById("quantity").value = 1;

    showProducts();
}

function showProducts() {
    const list = document.getElementById("productList");

    if (!list) return;

    list.innerHTML = "";

    let total = 0;

    billItems.forEach(function (item, index) {
        total += item.total;

        list.innerHTML += `
            <div class="product-row">
                <div>
                    <strong>${item.name}</strong>
                    <br>
                    ${item.quantity} × Rs. ${item.price}
                </div>

                <div>
                    Rs. ${item.total}
                    <br>
                    <button onclick="removeProduct(${index})">
                        Remove
                    </button>
                </div>
            </div>
        `;
    });

    document.getElementById("billTotal").textContent = total;
}

function removeProduct(index) {
    billItems.splice(index, 1);
    showProducts();
}

function saveBill() {
    const customer =
        document.getElementById("customerName").value.trim();

    const customerPhone =
        document.getElementById("customerPhone").value.trim();

    if (billItems.length === 0) {
        alert("Please add at least one product.");
        return;
    }

    let total = 0;

    billItems.forEach(function (item) {
        total += item.total;
    });

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    billItems.forEach(function (item) {
        const product = products.find(function (p) {
            return p.id == item.id;
        });

        if (product) {
            product.stock -= item.quantity;
        }
    });

    localStorage.setItem(
        "products",
        JSON.stringify(products)
    );

    const bills =
        JSON.parse(localStorage.getItem("bills")) || [];

    bills.push({
    billNumber: getNextBillNumber(),
        shopName: SHOP_NAME,
        shopPhone: SHOP_PHONE,
        customer: customer,
        customerPhone: customerPhone,
        items: billItems,
        total: total,
        date: new Date().toISOString()
    });

    localStorage.setItem(
        "bills",
        JSON.stringify(bills)
    );

    alert("Bill saved successfully!");
  const savedBills =
    JSON.parse(localStorage.getItem("bills")) || [];

const lastBillIndex = savedBills.length - 1;

viewBill(lastBillIndex);
}

function openInventory() {
    document.querySelector(".welcome-card").style.display = "none";
    document.querySelector(".dashboard").style.display = "none";

    document.querySelector(".container").innerHTML = `
        <section class="bill-card">

            <h2>📦 Inventory</h2>

            <h3>Add New Product</h3>

            <label>Product Name</label>
            <input id="newProductName"
                type="text"
                placeholder="Example: LED Bulb 12W">

            <label>Sale Price</label>
            <input id="newProductPrice"
                type="number"
                placeholder="Example: 250">

            <label>Stock Quantity</label>
            <input id="newProductStock"
                type="number"
                placeholder="Example: 50">

            <button onclick="addInventoryProduct()">
                Add Product
            </button>

            <hr>

            <h3>Current Inventory</h3>
<input
    id="inventorySearch"
    type="text"
    placeholder="Search product..."
    oninput="showInventory()"
>
            <div id="inventoryList"></div>

            <button onclick="goHome()">Back</button>

        </section>
    `;

    showInventory();
}

function addInventoryProduct() {
    const name =
        document.getElementById("newProductName").value.trim();

    const price =
        Number(document.getElementById("newProductPrice").value);

    const stock =
        Number(document.getElementById("newProductStock").value);

    if (!name || price < 0 || stock < 0) {
        alert("Please enter valid product information.");
        return;
    }

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    products.push({
        id: Date.now(),
        name: name,
        price: price,
        stock: stock
    });

    localStorage.setItem(
        "products",
        JSON.stringify(products)
    );

    alert("Product added successfully!");

    showInventory();
}

 
                    function showInventory() {

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    const list =
        document.getElementById("inventoryList");

    const searchInput =
        document.getElementById("inventorySearch");

    const search =
        searchInput
            ? searchInput.value.trim().toLowerCase()
            : "";

    if (!list) return;

    list.innerHTML = "";

    if (products.length === 0) {
        list.innerHTML =
            "<p>No products added yet.</p>";
        return;
    }

    products
        .filter(function (product) {
            return product.name
                .toLowerCase()
                .includes(search);
        })
        .forEach(function (product) {

            const warning =
                product.stock <= 5
                    ? "<strong>⚠️ Low Stock</strong>"
                    : "";

            list.innerHTML += `
                <div class="product-row">

                    <div>

                        <strong>${product.name}</strong>

                        <br>

                        Sale Price:
                        Rs. ${product.price}

                        <br>

                        Stock:
                        ${product.stock}

                        <br>

                        ${warning}

                        <br>

                        <button
                            onclick="editInventoryProduct(${product.id})"
                        >
                            ✏️ Edit Product
                        </button>
<button
    onclick="addStock(${product.id})"
>
    ➕ Add Stock
</button>
                        <button
                            onclick="deleteInventoryProduct(${product.id})"
                        >
                            🗑️ Delete Product
                        </button>

                    </div>

                </div>
            `;
        });
}


function deleteInventoryProduct(id) {

    const confirmDelete =
        confirm("Delete this product?");

    if (!confirmDelete) return;

    let products =
        JSON.parse(localStorage.getItem("products")) || [];

    products = products.filter(function (product) {
        return product.id != id;
    });

    localStorage.setItem(
        "products",
        JSON.stringify(products)
    );

    alert("Product deleted successfully!");

    showInventory();
}
function editInventoryProduct(id) {

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    const product = products.find(function (p) {
        return p.id == id;
    });

    if (!product) {
        alert("Product not found.");
        return;
    }

    const newName =
        prompt("Product Name:", product.name);

    if (newName === null) return;

    const newPrice =
        prompt("Sale Price:", product.price);

    if (newPrice === null) return;

    const newStock =
        prompt("Stock Quantity:", product.stock);

    if (newStock === null) return;

    if (
        !newName.trim() ||
        Number(newPrice) < 0 ||
        Number(newStock) < 0
    ) {
        alert("Please enter valid information.");
        return;
    }

    product.name = newName.trim();
    product.price = Number(newPrice);
    product.stock = Number(newStock);

    localStorage.setItem(
        "products",
        JSON.stringify(products)
    );

    alert("Product updated successfully!");

    showInventory();}
function goHome() {
    location.reload();
}
function addStock(id) {

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    const product =
        products.find(function (p) {
            return p.id == id;
        });

    if (!product) {
        alert("Product not found.");
        return;
    }

    const quantity =
        prompt(
            "Kitna stock add karna hai?\nCurrent Stock: " +
            product.stock
        );

    if (quantity === null) return;

    const addQuantity = Number(quantity);

    if (
        !Number.isInteger(addQuantity) ||
        addQuantity <= 0
    ) {
        alert("Please enter a valid quantity.");
        return;
    }

    product.stock += addQuantity;

    localStorage.setItem(
        "products",
        JSON.stringify(products)
    );

    alert(
        addQuantity +
        " stock added successfully!\nNew Stock: " +
        product.stock
    );

    showInventory();
}
function printBluetoothReceipt() {

    const bills =
        JSON.parse(localStorage.getItem("bills")) || [];

    if (!bills.length) {
        alert("Koi saved bill nahi mila.");
        return;
    }

    const bill = bills[bills.length - 1];

    let receiptText = "";

    receiptText += "HASSAN ELECTRIC TRADER\n";
    receiptText += "Shop No: 03006980431\n";
    receiptText += "--------------------------------\n";
    receiptText += "Bill No: " + bill.billNumber + "\n";
    receiptText += "Customer: " + (bill.customerName || "Walk-in") + "\n";
    receiptText += "Phone: " + (bill.customerPhone || "-") + "\n";
    receiptText += "Date: " + (bill.date || "") + "\n";
    receiptText += "--------------------------------\n";

    (bill.items || []).forEach(function (item) {

        receiptText += item.name + "\n";
        receiptText +=
            "Qty: " + item.quantity +
            "  Rs." + item.price +
            "  = Rs." + item.total + "\n";
    });

    receiptText += "--------------------------------\n";
    receiptText += "TOTAL: Rs. " + bill.total + "\n";
    receiptText += "--------------------------------\n";
    receiptText += "\nThanks for visiting our shop!\n";
    receiptText += "\n\n\n";

    if (
        typeof Android !== "undefined" &&
        Android.printBluetooth
    ) {
        Android.printBluetooth(receiptText);
    } else {
        alert(
            "Bluetooth printer feature APK version mein available hogi."
        );
    }
}
/* =========================================================
   SEPARATE UDHAAR / CUSTOMER LEDGER SYSTEM
   This section is independent from New Bill and Inventory.
   ========================================================= */

(function () {

    function udhaarGetRecords() {
        return JSON.parse(
            localStorage.getItem("udhaarRecords")
        ) || [];
    }

    function udhaarSaveRecords(records) {
        localStorage.setItem(
            "udhaarRecords",
            JSON.stringify(records)
        );
    }

    function udhaarMoney(value) {
        return Number(value || 0).toFixed(2);
    }

    function udhaarAddButton() {

        const welcome =
            document.querySelector(".welcome-card");

        if (!welcome) return;

        if (document.getElementById("udhaarMainButton")) {
            return;
        }

        const button = document.createElement("button");

        button.id = "udhaarMainButton";
        button.innerHTML =
            "💰 Udhaar / Customer Ledger";

        button.onclick = function () {
            udhaarOpenLedger();
        };

        welcome.appendChild(button);
    }


    function udhaarOpenLedger() {

        const container =
            document.querySelector(".container");

        if (!container) return;

        document.querySelectorAll(
            ".welcome-card, .dashboard"
        ).forEach(function (element) {
            element.style.display = "none";
        });

        let oldLedger =
            document.getElementById("udhaarLedger");

        if (oldLedger) {
            oldLedger.remove();
        }

        const ledger =
            document.createElement("section");

        ledger.id = "udhaarLedger";
        ledger.className = "bill-card";

        ledger.innerHTML = `
            <h2>💰 Udhaar / Customer Ledger</h2>

            <p>
                Customer ka udhaar, payment,
                discount aur remaining amount yahan
                alag manage hoga.
            </p>

            <button
                type="button"
                onclick="udhaarNewCustomer()"
            >
                + New Udhaar Customer
            </button>

            <button
                type="button"
                onclick="udhaarLoadRecords()"
            >
                🔄 Refresh Records
            </button>

            <label>Customer Search</label>

            <input
                type="text"
                id="udhaarSearch"
                placeholder="Customer name ya phone..."
                oninput="udhaarLoadRecords()"
            >

            <div id="udhaarFormArea"></div>

            <hr>

            <h3>Customer Udhaar Records</h3>

            <div id="udhaarRecordsList"></div>

            <button
                type="button"
                onclick="goHome()"
            >
                🏠 Back to Home
            </button>
        `;

        container.appendChild(ledger);

        udhaarLoadRecords();
    }


    window.udhaarNewCustomer = function () {

        const area =
            document.getElementById("udhaarFormArea");

        if (!area) return;

        area.innerHTML = `
            <div class="bill-card">

                <h3>➕ New Udhaar Entry</h3>

                <label>Customer Name</label>

                <input
                    type="text"
                    id="udhaarCustomerName"
                    placeholder="Customer name"
                >

                <label>Phone Number</label>

                <input
                    type="tel"
                    id="udhaarCustomerPhone"
                    placeholder="0300..."
                >

                <hr>

                <h3>Items</h3>

                <div id="udhaarItemsArea"></div>

                <button
                    type="button"
                    onclick="udhaarAddItem()"
                >
                    + Add Item
                </button>

                <label>Total Discount</label>

                <input
                    type="number"
                    id="udhaarDiscount"
                    value="0"
                    min="0"
                    oninput="udhaarCalculateTotal()"
                >

                <label>Paid Amount</label>

                <input
                    type="number"
                    id="udhaarPaid"
                    value="0"
                    min="0"
                    oninput="udhaarCalculateTotal()"
                >

                <div
                    id="udhaarTotalBox"
                    class="bill-total"
                >
                    Total: Rs. 0<br>
                    Paid: Rs. 0<br>
                    Remaining: Rs. 0
                </div>

                <button
                    type="button"
                    onclick="udhaarSaveNewRecord()"
                >
                    💾 Save Udhaar
                </button>

                <button
                    type="button"
                    onclick="udhaarCancelForm()"
                >
                    Cancel
                </button>

            </div>
        `;

        udhaarAddItem();
    };


    window.udhaarAddItem = function () {

        const area =
            document.getElementById("udhaarItemsArea");

        if (!area) return;

        const row =
            document.createElement("div");

        row.className = "history-item";

        row.innerHTML = `
            <label>Item Name</label>

            <input
                type="text"
                class="udhaar-item-name"
                placeholder="Item name"
            >

            <label>Quantity</label>

            <input
                type="number"
                class="udhaar-item-qty"
                value="1"
                min="1"
                oninput="udhaarCalculateTotal()"
            >

            <label>Price per Item</label>

            <input
                type="number"
                class="udhaar-item-price"
                value="0"
                min="0"
                oninput="udhaarCalculateTotal()"
            >

            <div>
                Item Total:
                Rs.
                <span class="udhaar-item-total">
                    0
                </span>
            </div>

            <button
                type="button"
                onclick="this.parentElement.remove(); udhaarCalculateTotal();"
            >
                🗑️ Remove Item
            </button>
        `;

        area.appendChild(row);

        udhaarCalculateTotal();
    };


    window.udhaarCalculateTotal = function () {

        const qtyInputs =
            document.querySelectorAll(
                ".udhaar-item-qty"
            );

        const priceInputs =
            document.querySelectorAll(
                ".udhaar-item-price"
            );

        const totalLabels =
            document.querySelectorAll(
                ".udhaar-item-total"
            );

        let subtotal = 0;

        for (
            let i = 0;
            i < qtyInputs.length;
            i++
        ) {

            const qty =
                Number(qtyInputs[i].value) || 0;

            const price =
                Number(priceInputs[i].value) || 0;

            const itemTotal =
                qty * price;

            subtotal += itemTotal;

            if (totalLabels[i]) {
                totalLabels[i].textContent =
                    udhaarMoney(itemTotal);
            }
        }

        const discount =
            Number(
                document.getElementById(
                    "udhaarDiscount"
                )?.value
            ) || 0;

        const paid =
            Number(
                document.getElementById(
                    "udhaarPaid"
                )?.value
            ) || 0;

        const finalTotal =
            Math.max(0, subtotal - discount);

        const remaining =
            Math.max(0, finalTotal - paid);

        const box =
            document.getElementById(
                "udhaarTotalBox"
            );

        if (box) {
            box.innerHTML = `
                Subtotal: Rs. ${udhaarMoney(subtotal)}
                <br>
                Discount: Rs. ${udhaarMoney(discount)}
                <br>
                <strong>
                    Total: Rs. ${udhaarMoney(finalTotal)}
                </strong>
                <br>
                Paid: Rs. ${udhaarMoney(paid)}
                <br>
                <strong>
                    Remaining: Rs. ${udhaarMoney(remaining)}
                </strong>
            `;
        }

        return {
            subtotal: subtotal,
            discount: discount,
            total: finalTotal,
            paid: paid,
           remaining: remaining
        };
    };


    window.udhaarSaveNewRecord = function () {

        const name =
            document.getElementById(
                "udhaarCustomerName"
            )?.value.trim();

        const phone =
            document.getElementById(
                "udhaarCustomerPhone"
            )?.value.trim();

        if (!name) {
            alert("Customer name enter karein.");
            return;
        }

        const itemNames =
            document.querySelectorAll(
                ".udhaar-item-name"
            );

        const itemQtys =
            document.querySelectorAll(
                ".udhaar-item-qty"
            );

        const itemPrices =
            document.querySelectorAll(
                ".udhaar-item-price"
            );

        const items = [];

        for (
            let i = 0;
            i < itemNames.length;
            i++
        ) {

            const itemName =
                itemNames[i].value.trim();

            const quantity =
                Number(itemQtys[i].value) || 0;

            const price =
                Number(itemPrices[i].value) || 0;

            if (!itemName) {
                continue;
            }

            if (
                quantity <= 0 ||
                price < 0
            ) {
                alert(
                    "Item ki quantity aur price check karein."
                );
                return;
            }

            items.push({
                name: itemName,
                quantity: quantity,
                price: price,
                total: quantity * price
            });
        }
      if (items.length === 0) {
            alert("Kam az kam 1 item add karein.");
            return;
        }

        const calculation =
            udhaarCalculateTotal();

        const record = {

            id: Date.now(),

            customerName: name,

            customerPhone: phone,

            items: items,

            subtotal: calculation.subtotal,

            discount: calculation.discount,

            total: calculation.total,

            paid: calculation.paid,

            remaining: calculation.remaining,

            date: new Date().toLocaleString(),

            paymentHistory: calculation.paid > 0
                ? [
                    {
                        amount: calculation.paid,
                        date: new Date().toLocaleString()
                    }
                ]
                : []
        };

        const records =
            udhaarGetRecords();

        records.push(record);

        udhaarSaveRecords(records);

        alert(
            "Udhaar record successfully save ho gaya."
        );

        document.getElementById(
            "udhaarFormArea"
        ).innerHTML = "";

        udhaarLoadRecords();
    };


    window.udhaarLoadRecords = function () {

        const list =
            document.getElementById(
                "udhaarRecordsList"
            );

        if (!list) return;

        const search =
            document.getElementById(
                "udhaarSearch"
            )?.value
                .trim()
                .toLowerCase() || "";

        const records =
            udhaarGetRecords();

        const filtered =
            records.filter(function (record) {

                return (
                    record.customerName
                        .toLowerCase()
                        .includes(search)
                    ||
                    (record.customerPhone || "")
                        .toLowerCase()
                        .includes(search)
                );
            });

        list.innerHTML = "";

        if (filtered.length === 0) {

            list.innerHTML =
                "<p>No udhaar records found.</p>";

            return;
        }

        filtered
            .slice()
            .reverse()
            .forEach(function (record) {

                const itemText =
                    (record.items || [])
                    .map(function (item) {

                        return `
                            <div>
                                ${item.name}
                                × ${item.quantity}
                                @ Rs. ${udhaarMoney(item.price)}
                                =
                                Rs. ${udhaarMoney(item.total)}
                            </div>
                        `;

                    })
                    .join("");

                const paymentText =
                    (record.paymentHistory || [])
                    .map(function (payment) {
                        return `
                            <div>
                                Rs. ${udhaarMoney(payment.amount)}
                                — ${payment.date}
                            </div>
                        `;
                    })
                    .join("");

                const card =
                    document.createElement("div");

                card.className =
                    "history-item";

                card.innerHTML = `
                    <h3>
                        👤 ${record.customerName}
                    </h3>

                    <p>
                        📞 ${record.customerPhone || "-"}
                    </p>

                    <p>
                        📅 ${record.date}
                    </p>

                    <hr>

                    <strong>Items:</strong>

                    ${itemText}
                    
                    <hr>

                    <p>
                        Subtotal:
                        Rs. ${udhaarMoney(record.subtotal)}
                    </p>

                    <p>
                        Discount:
                        Rs. ${udhaarMoney(record.discount)}
                    </p>

                    <p>
                        <strong>
                            Total:
                            Rs. ${udhaarMoney(record.total)}
                        </strong>
                    </p>

                    <p>
                        Paid:
                        Rs. ${udhaarMoney(record.paid)}
                    </p>

                    <p>
                        <strong>
                            Remaining:
                            Rs. ${udhaarMoney(record.remaining)}
                        </strong>
                    </p>

                    ${
                        paymentText
                        ? `
                            <hr>
                            <strong>
                                Payment History
                            </strong>
                            ${paymentText}
                        `
                        : ""
                    }

                    <button
                        type="button"
                        onclick="udhaarAddPayment(${record.id})"
                    >
                        💵 Add Payment
                    </button>

                    <button
                        type="button"
                        onclick="udhaarEditRecord(${record.id})"
                    >
                        ✏️ Edit
                    </button>

                    <button
                        type="button"
                        onclick="udhaarDeleteRecord(${record.id})"
                    >
                        🗑️ Delete
                    </button>
                `;

                list.appendChild(card);
            });
    };


    window.udhaarAddPayment = function (id) {

        const records =
            udhaarGetRecords();

        const record =
            records.find(function (item) {
                return item.id == id;
            });

        if (!record) {
            alert("Record not found.");
            return;
        }

        if (record.remaining <= 0) {
            alert("Is customer ka udhaar already clear hai.");
            return;
        }

        const value =
            prompt(
                "Customer ne ab kitna payment diya?\n" +
                "Remaining: Rs. " +
                udhaarMoney(record.remaining)
            );

        if (value === null) return;

        const amount =
            Number(value);

        if (
            !Number.isFinite(amount) ||
            amount <= 0
        ) {
            alert("Valid payment amount enter karein.");
            return;
        }

        if (amount > record.remaining) {
            alert(
                "Payment remaining amount se zyada nahi ho sakti."
            );
            return;
        }

        record.paid += amount;

        record.remaining =
            Math.max(
                0,
                record.total - record.paid
            );

        if (!record.paymentHistory) {
            record.paymentHistory = [];
        }

        record.paymentHistory.push({
            amount: amount,
            date: new Date().toLocaleString()
        });

        udhaarSaveRecords(records);

        alert(
            "Payment add ho gayi.\n" +
            "Remaining: Rs. " +
            udhaarMoney(record.remaining)
        );

        udhaarLoadRecords();
    };


    window.udhaarEditRecord = function (id) {

        const records =
            udhaarGetRecords();

        const record =
            records.find(function (item) {
                return item.id == id;
            });

        if (!record) {
            alert("Record not found.");
            return;
        }

        const newName =
            prompt(
                "Customer name:",
                record.customerName
            );

        if (newName === null) return;

        const newPhone =
            prompt(
                "Phone number:",
                record.customerPhone || ""
            );

        if (newPhone === null) return;

        const newDiscount =
            prompt(
                "Discount:",
                record.discount
            );

        if (newDiscount === null) return;

        const discount =
            Number(newDiscount);

        if (
            !Number.isFinite(discount) ||
            discount < 0
        ) {
            alert("Invalid discount.");
            return;
        }

        record.customerName =
            newName.trim() || record.customerName;

        record.customerPhone =
            newPhone.trim();

        record.discount =
            discount;

        record.total =
            Math.max(
                0,
                record.subtotal - record.discount
            );

        record.remaining =
            Math.max(
                0,
                record.total - record.paid
            );

        udhaarSaveRecords(records);

        alert("Udhaar record updated.");

        udhaarLoadRecords();
    };


    window.udhaarDeleteRecord = function (id) {

        const confirmDelete =
            confirm(
                "Kya aap ye Udhaar record delete karna chahte hain?"
            );

        if (!confirmDelete) return;

        const records =
            udhaarGetRecords();

        const updated =
            records.filter(function (record) {
                return record.id != id;
            });

        udhaarSaveRecords(updated);

        alert("Udhaar record delete ho gaya.");

        udhaarLoadRecords();
    };


    window.udhaarCancelForm = function () {

        const area =
            document.getElementById(
                "udhaarFormArea"
            );

        if (area) {
            area.innerHTML = "";
        }
    };


    document.addEventListener(
        "DOMContentLoaded",
        function () {
            udhaarAddButton();
        }
    );

})();
/* =========================================================
   NEW BILL DISCOUNT SYSTEM - SAFE HELPERS
   ========================================================= */

function calculateBillDiscount(subtotal, discountType, discountValue) {

    subtotal = Number(subtotal) || 0;
    discountValue = Number(discountValue) || 0;

    if (subtotal < 0) {
        subtotal = 0;
    }

    if (discountValue < 0) {
        discountValue = 0;
    }

    let discountAmount = 0;

    if (discountType === "percent") {

        discountAmount =
            subtotal * (discountValue / 100);

        if (discountAmount > subtotal) {
            discountAmount = subtotal;
        }

    } else {

        discountAmount = discountValue;

        if (discountAmount > subtotal) {
            discountAmount = subtotal;
        }
    }

    const finalTotal =
        subtotal - discountAmount;

    return {
        subtotal: subtotal,
        discountType: discountType,
        discountValue: discountValue,
        discountAmount: discountAmount,
        total: finalTotal
    };
}


/* Make discount information available anywhere in the app */

window.getBillDiscountSummary =
    function (subtotal, discountType, discountValue) {

        return calculateBillDiscount(
            subtotal,
            discountType,
            discountValue
        );
    };
    /* =========================================================
   FIX: INVENTORY SEARCH + SELECT DROPDOWN
   Works with the current Discount New Bill system
   ========================================================= */

function discountBillSearchProducts() {

    const input =
        document.getElementById(
            "discountBillProductSearch"
        );

    const results =
        document.getElementById(
            "discountBillProductResults"
        );

    if (!input || !results) return;

    const search =
        input.value.trim().toLowerCase();

    const products =
        JSON.parse(
            localStorage.getItem("products")
        ) || [];

    results.innerHTML = "";

    if (!search) {
        return;
    }

    const matches =
        products.filter(function (product) {

            return String(product.name || "")
                .toLowerCase()
                .includes(search);
        });

    if (matches.length === 0) {

        results.innerHTML =
            "<p>No product found in Inventory.</p>";

        return;
    }

    const select =
        document.createElement("select");

    select.id =
        "discountBillInventorySelect";

    const first =
        document.createElement("option");

    first.value = "";
    first.textContent =
        "-- Select Product --";

    select.appendChild(first);

    matches.forEach(function (product) {

        const option =
            document.createElement("option");

        option.value = product.id;

        option.textContent =
            product.name +
            " - Rs. " +
            product.price +
            " - Stock: " +
            product.stock;

        select.appendChild(option);
    });

    select.onchange = function () {

        const productId =
            this.value;

        const product =
            products.find(function (item) {
                return item.id == productId;
            });

        if (!product) return;

        document.getElementById(
            "discountBillSelectedProduct"
        ).value =
            product.name;

        document.getElementById(
            "discountBillSelectedProductId"
        ).value =
            product.id;

        document.getElementById(
            "discountBillPrice"
        ).value =
            product.price;
    };

    results.appendChild(select);
}


/* Add selected Inventory product to the bill */

function discountBillAddProduct() {

    const productId =
        document.getElementById(
            "discountBillSelectedProductId"
        )?.value;

    const quantity =
        Number(
            document.getElementById(
                "discountBillQuantity"
            )?.value
        );

    const products =
        JSON.parse(
            localStorage.getItem("products")
        ) || [];

    const product =
        products.find(function (item) {
            return item.id == productId;
        });

    if (!product) {

        alert(
            "Pehle Inventory se product select karein."
        );

        return;
    }

    if (
        !Number.isInteger(quantity) ||
        quantity <= 0
    ) {

        alert(
            "Valid quantity enter karein."
        );

        return;
    }

    if (quantity > product.stock) {

        alert(
            "Not enough stock.\n" +
            "Available Stock: " +
            product.stock
        );

        return;
    }

    if (
        typeof discountBillItems ===
        "undefined"
    ) {
        discountBillItems = [];
    }

    const existing =
        discountBillItems.find(function (item) {
            return item.productId == product.id;
        });

    if (existing) {

        if (
            existing.quantity + quantity >
            product.stock
        ) {

            alert(
                "Available stock se zyada quantity hai."
            );

            return;
        }

        existing.quantity += quantity;

        existing.total =
            existing.quantity *
            existing.price;

    } else {

        discountBillItems.push({

            productId:
                product.id,

            name:
                product.name,

            price:
                Number(product.price),

            quantity:
                quantity,

            total:
                Number(product.price) *
                quantity
        });
    }

    /* Clear selection */

    document.getElementById(
        "discountBillSelectedProduct"
    ).value = "";

    document.getElementById(
        "discountBillSelectedProductId"
    ).value = "";

    document.getElementById(
        "discountBillPrice"
    ).value = "";

    document.getElementById(
        "discountBillQuantity"
    ).value = 1;

    const search =
        document.getElementById(
            "discountBillProductSearch"
        );

    if (search) {
        search.value = "";
    }

    const results =
        document.getElementById(
            "discountBillProductResults"
        );

    if (results) {
        results.innerHTML = "";
    }

    discountBillShowItems();
}
/* =========================================================
   FINAL FIX - NEW BILL ADD PRODUCT BUTTON
   ========================================================= */

window.discountBillAddProduct = function () {

    const productId =
        document.getElementById(
            "discountBillSelectedProductId"
        )?.value;

    const quantityInput =
        document.getElementById(
            "discountBillQuantity"
        );

    const quantity =
        Number(quantityInput?.value);

    if (!productId) {
        alert(
            "Pehle Inventory se product select karein."
        );
        return;
    }

    if (
        !Number.isInteger(quantity) ||
        quantity <= 0
    ) {
        alert(
            "Valid quantity enter karein."
        );
        return;
    }

    const products =
        JSON.parse(
            localStorage.getItem("products")
        ) || [];

    const product =
        products.find(function (p) {
            return String(p.id) === String(productId);
        });

    if (!product) {
        alert(
            "Product Inventory mein nahi mila."
        );
        return;
    }

    if (quantity > Number(product.stock)) {
        alert(
            "Itna stock available nahi hai.\n" +
            "Available Stock: " +
            product.stock
        );
        return;
    }

    /* Make sure the bill array exists */
    if (
        !Array.isArray(
            window.discountBillItems
        )
    ) {
        window.discountBillItems = [];
    }

    /*
       Use the existing array if it was created
       with let discountBillItems.
    */
    if (
        typeof discountBillItems !== "undefined" &&
        Array.isArray(discountBillItems)
    ) {
        window.discountBillItems =
            discountBillItems;
    }

    const items =
        window.discountBillItems;

    const existing =
        items.find(function (item) {
            return String(item.productId) ===
                String(product.id);
        });

    if (existing) {

        const newQuantity =
            Number(existing.quantity) +
            quantity;

        if (
            newQuantity >
            Number(product.stock)
        ) {
            alert(
                "Available stock se zyada quantity hai."
            );
            return;
        }

        existing.quantity =
            newQuantity;

        existing.total =
            Number(existing.price) *
            newQuantity;

    } else {

        items.push({

            productId:
                product.id,

            name:
                product.name,

            price:
                Number(product.price),

            quantity:
                quantity,

            total:
                Number(product.price) *
                quantity
        });
    }

    /*
       Keep the original variable synchronized.
    */
    if (
        typeof discountBillItems !== "undefined"
    ) {
        discountBillItems =
            items;
    }

    /* Clear selected product */
    const selected =
        document.getElementById(
            "discountBillSelectedProduct"
        );

    if (selected) {
        selected.value = "";
    }

    const selectedId =
        document.getElementById(
            "discountBillSelectedProductId"
        );

    if (selectedId) {
        selectedId.value = "";
    }

    const price =
        document.getElementById(
            "discountBillPrice"
        );

    if (price) {
        price.value = "";
    }

    const quantityField =
        document.getElementById(
            "discountBillQuantity"
        );

    if (quantityField) {
        quantityField.value = 1;
    }

    const search =
        document.getElementById(
            "discountBillProductSearch"
        );

    if (search) {
        search.value = "";
    }

    const results =
        document.getElementById(
            "discountBillProductResults"
        );

    if (results) {
        results.innerHTML = "";
    }

    /*
       Show the item immediately in New Bill.
    */
    if (
        typeof discountBillShowItems ===
        "function"
    ) {
        discountBillShowItems();
    } else {

        const itemsArea =
            document.getElementById(
                "discountBillItems"
            );

        if (itemsArea) {

            itemsArea.innerHTML =
                items.map(function (item, index) {

                    return `
                        <div class="product-row">

                            <div>
                                <strong>
                                    ${item.name}
                                </strong>

                                <br>

                                Qty:
                                ${item.quantity}

                                <br>

                                Price:
                                Rs. ${item.price}

                                <br>

                                Total:
                                Rs. ${item.total}
                            </div>

                            <button
                                type="button"
                                onclick="discountBillRemoveProduct(${index})"
                            >
                                Remove
                            </button>

                        </div>
                    `;

                }).join("");
        }

        if (
            typeof discountBillCalculate ===
            "function"
        ) {
            discountBillCalculate();
        }
    }
};
/* =========================================================
   FIX - NEW BILL SUBTOTAL / DISCOUNT / FINAL TOTAL
   ========================================================= */

window.discountBillCalculate = function () {

    let subtotal = 0;

    if (
        typeof discountBillItems !== "undefined" &&
        Array.isArray(discountBillItems)
    ) {
        discountBillItems.forEach(function (item) {

            const quantity =
                Number(item.quantity) || 0;

            const price =
                Number(item.price) || 0;

            item.total =
                quantity * price;

            subtotal += item.total;
        });
    }

    const discountType =
        document.getElementById(
            "newBillDiscountType"
        )?.value || "amount";

    const discountValue =
        Number(
            document.getElementById(
                "newBillDiscountValue"
            )?.value
        ) || 0;

    let discount = 0;

    if (discountType === "percent") {

        discount =
            subtotal *
            (discountValue / 100);

    } else {

        discount =
            discountValue;
    }

    /* Discount total se zyada nahi ho sakta */

    if (discount > subtotal) {
        discount = subtotal;
    }

    if (discount < 0) {
        discount = 0;
    }

    const finalTotal =
        subtotal - discount;

    const totalBox =
        document.getElementById(
            "discountBillTotal"
        );

    if (totalBox) {

        totalBox.innerHTML = `
            <div>
                Subtotal:
                Rs. ${subtotal.toFixed(2)}
            </div>

            <div>
                Discount:
                Rs. ${discount.toFixed(2)}
            </div>

            <div
                style="
                    margin-top:10px;
                    font-size:22px;
                    font-weight:bold;
                "
            >
                Bill Total:
                Rs. ${finalTotal.toFixed(2)}
            </div>
        `;
    }

    return {
        subtotal: subtotal,
        discountType: discountType,
        discountValue: discountValue,
        discount: discount,
        total: finalTotal
    };
};
/* =========================================================
   HASSAN ELECTRIC TRADER - FIREBASE LOGIN SYSTEM
   ========================================================= */

(function () {

    function cloudLoginScreen() {

        let oldBox =
            document.getElementById("cloudLoginBox");

        if (oldBox) return;

        const box = document.createElement("div");

        box.id = "cloudLoginBox";

        box.style.cssText = `
            max-width: 450px;
            margin: 30px auto;
            padding: 25px;
            background: white;
            border-radius: 18px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            text-align: center;
        `;

        box.innerHTML = `
            <h2>☁️ Hassan Electric Trader</h2>

            <p>
                Apne shop account mein login karein
            </p>

            <input
                type="email"
                id="cloudEmail"
                placeholder="Email"
                style="
                    width:100%;
                    box-sizing:border-box;
                    padding:12px;
                    margin:8px 0;
                    border-radius:8px;
                    border:1px solid #ccc;
                "
            >

            <input
                type="password"
                id="cloudPassword"
                placeholder="Password"
                style="
                    width:100%;
                    box-sizing:border-box;
                    padding:12px;
                    margin:8px 0;
                    border-radius:8px;
                    border:1px solid #ccc;
                "
            >

            <button
                type="button"
                onclick="cloudLogin()"
                style="width:100%; margin-top:10px;"
            >
                🔐 Login
            </button>

            <button
                type="button"
                onclick="cloudCreateAccount()"
                style="width:100%; margin-top:10px;"
            >
                ➕ Create New Account
            </button>

            <button
                type="button"
                onclick="cloudResetPassword()"
                style="
                    width:100%;
                    margin-top:10px;
                    background:#777;
                "
            >
                🔑 Forgot Password
            </button>

            <p
                id="cloudLoginMessage"
                style="margin-top:15px;"
            ></p>
        `;

        const container =
            document.querySelector(".container");

        if (container) {
            container.parentNode.insertBefore(
                box,
                container
            );

            container.style.display = "none";
        }
    }


    window.cloudLogin = function () {

        const email =
            document.getElementById("cloudEmail")
                ?.value.trim();

        const password =
            document.getElementById("cloudPassword")
                ?.value;

        const message =
            document.getElementById(
                "cloudLoginMessage"
            );

        if (!email || !password) {
            message.textContent =
                "Email aur password dono likhein.";
            return;
        }

        message.textContent =
            "Login ho raha hai...";

        firebase.auth()
            .signInWithEmailAndPassword(
                email,
                password
            )
            .then(function () {

                message.textContent =
                    "Login successful!";

            })
            .catch(function (error) {

                message.textContent =
                    "Login failed: " +
                    error.message;

            });
    };


    window.cloudCreateAccount = function () {

        const email =
            document.getElementById("cloudEmail")
                ?.value.trim();

        const password =
            document.getElementById("cloudPassword")
                ?.value;

        const message =
            document.getElementById(
                "cloudLoginMessage"
            );

        if (!email || !password) {
            message.textContent =
                "Pehle email aur password likhein.";
            return;
        }

        if (password.length < 6) {
            message.textContent =
                "Password kam az kam 6 characters ka hona chahiye.";
            return;
        }

        message.textContent =
            "Account ban raha hai...";

        firebase.auth()
            .createUserWithEmailAndPassword(
                email,
                password
            )
            .then(function () {

                message.textContent =
                    "Account successfully create ho gaya!";

            })
            .catch(function (error) {

                message.textContent =
                    "Account create nahi hua: " +
                    error.message;

            });
    };


    window.cloudResetPassword = function () {

        const email =
            document.getElementById("cloudEmail")
                ?.value.trim();

        const message =
            document.getElementById(
                "cloudLoginMessage"
            );

        if (!email) {
            message.textContent =
                "Pehle apna email likhein.";
            return;
        }

        firebase.auth()
            .sendPasswordResetEmail(email)
            .then(function () {

                message.textContent =
                    "Password reset email bhej di gayi hai.";

            })
            .catch(function (error) {

                message.textContent =
                    "Reset failed: " +
                    error.message;

            });
    };


    function cloudShowApp(user) {

        const box =
            document.getElementById(
                "cloudLoginBox"
            );

        const container =
            document.querySelector(".container");

        if (box) {
            box.remove();
        }

        if (container) {
            container.style.display = "";
        }

        console.log(
            "Cloud user logged in:",
            user.email
        );
    }


    function cloudShowLogin() {

        const container =
            document.querySelector(".container");

        if (container) {
            container.style.display = "none";
        }

        cloudLoginScreen();
    }


    if (
        typeof firebase !== "undefined" &&
        firebase.auth
    ) {

        cloudShowLogin();

        firebase.auth()
            .onAuthStateChanged(function (user) {

                if (user) {
                    cloudShowApp(user);
                } else {
                    cloudShowLogin();
                }

            });

    } else {

        console.error(
            "Firebase Auth SDK load nahi hua."
        );

    }

})();
/* =========================================================
   CLOUD SYNC - INVENTORY / PRODUCTS
   ========================================================= */

(function () {

    let cloudSyncReady = false;
    let cloudUpdatingLocal = false;

    function getProductsFromLocal() {
        return JSON.parse(
            localStorage.getItem("products")
        ) || [];
    }

    function getCloudProductsRef() {

        const user =
            firebase.auth().currentUser;

        if (!user) return null;

        return firebase.database()
            .ref("shops/" + user.uid + "/products");
    }


    function saveCloudProducts(products) {

        const ref = getCloudProductsRef();

        if (!ref) return;

        return ref.set(products);
    }


    function loadProductsFromCloud() {

        const ref = getCloudProductsRef();

        if (!ref) return;

        ref.once("value")
            .then(function (snapshot) {

                const cloudProducts =
                    snapshot.val();

                const localProducts =
                    getProductsFromLocal();

                /*
                 Cloud empty + local data exists:
                 first device ka existing inventory
                 cloud mein upload hoga.
                */

                if (
                    (!cloudProducts ||
                    !Array.isArray(cloudProducts)) &&
                    localProducts.length > 0
                ) {

                    return saveCloudProducts(
                        localProducts
                    );
                }

                /*
                 Cloud mein data already hai:
                 cloud data ko local inventory mein
                 load karo.
                */

                if (Array.isArray(cloudProducts)) {

                    cloudUpdatingLocal = true;

                    localStorage.setItem(
                        "products",
                        JSON.stringify(
                            cloudProducts
                        )
                    );

                    cloudUpdatingLocal = false;

                    if (
                        typeof showInventory ===
                        "function"
                    ) {
                        showInventory();
                    }
                }

            })
            .catch(function (error) {

                console.error(
                    "Cloud inventory load error:",
                    error
                );

            });
    }


    function startProductsRealtimeSync() {

        const ref =
            getCloudProductsRef();

        if (!ref) return;

        ref.on("value", function (snapshot) {

            const cloudProducts =
                snapshot.val();

            if (
                !Array.isArray(cloudProducts)
            ) {
                return;
            }

            cloudUpdatingLocal = true;

            localStorage.setItem(
                "products",
                JSON.stringify(
                    cloudProducts
                )
            );

            cloudUpdatingLocal = false;

            if (
                typeof showInventory ===
                "function"
            ) {
                showInventory();
            }

        });

        cloudSyncReady = true;
    }


    /*
     Existing app jab products ko
     localStorage mein save karegi,
     us waqt automatically cloud mein bhi
     save karne ki koshish hogi.
    */

    const originalSetItem =
        localStorage.setItem.bind(
            localStorage
        );

    localStorage.setItem = function (
        key,
        value
    ) {

        originalSetItem(key, value);

        if (
            key === "products" &&
            !cloudUpdatingLocal &&
            cloudSyncReady
        ) {

            try {

                const products =
                    JSON.parse(value);

                if (
                    Array.isArray(products)
                ) {

                    saveCloudProducts(
                        products
                    ).catch(function (error) {

                        console.error(
                            "Cloud inventory save error:",
                            error
                        );

                    });

                }

            } catch (error) {

                console.error(
                    "Product cloud sync error:",
                    error
                );

            }
        }
    };


    /*
     Login ke baad inventory sync start.
    */

    if (
        typeof firebase !== "undefined" &&
        firebase.auth
    ) {

        firebase.auth()
            .onAuthStateChanged(
                function (user) {

                    if (!user) {

                        cloudSyncReady = false;
                        return;

                    }

                    loadProductsFromCloud();

                    startProductsRealtimeSync();

                }
            );

    }

})();
/* =========================================================
   CLOUD SYNC - BILLS + BILL HISTORY
   ========================================================= */

(function () {

    let cloudBillsSyncReady = false;
    let cloudUpdatingBills = false;

    function getLocalBills() {
        return JSON.parse(
            localStorage.getItem("bills")
        ) || [];
    }

    function getBillsRef() {

        const user =
            firebase.auth().currentUser;

        if (!user) return null;

        return firebase.database()
            .ref("shops/" + user.uid + "/bills");
    }

    function saveBillsToCloud(bills) {

        const ref = getBillsRef();

        if (!ref) return;

        return ref.set(bills);
    }

    function loadBillsFromCloud() {

        const ref = getBillsRef();

        if (!ref) return;

        ref.once("value")
            .then(function (snapshot) {

                const cloudBills =
                    snapshot.val();

                const localBills =
                    getLocalBills();

                /*
                 First device:
                 agar cloud empty hai aur
                 local bills hain to cloud mein
                 existing history upload karo.
                */

                if (
                    (!cloudBills ||
                    !Array.isArray(cloudBills)) &&
                    localBills.length > 0
                ) {

                    return saveBillsToCloud(
                        localBills
                    );
                }

                /*
                 Cloud mein bills already hain:
                 cloud history ko local app mein lao.
                */

                if (Array.isArray(cloudBills)) {

                    cloudUpdatingBills = true;

                    localStorage.setItem(
                        "bills",
                        JSON.stringify(
                            cloudBills
                        )
                    );

                    cloudUpdatingBills = false;

                    if (
                        typeof loadBillHistory ===
                        "function"
                    ) {
                        loadBillHistory();
                    }

                    if (
                        typeof updateDashboard ===
                        "function"
                    ) {
                        updateDashboard();
                    }
                }

            })
            .catch(function (error) {

                console.error(
                    "Cloud bills load error:",
                    error
                );

            });
    }

    function startBillsRealtimeSync() {

        const ref = getBillsRef();

        if (!ref) return;

        ref.on("value", function (snapshot) {

            const cloudBills =
                snapshot.val();

            if (
                !Array.isArray(cloudBills)
            ) {
                return;
            }

            cloudUpdatingBills = true;

            localStorage.setItem(
                "bills",
                JSON.stringify(
                    cloudBills
                )
            );

            cloudUpdatingBills = false;

            if (
                typeof loadBillHistory ===
                "function"
            ) {
                loadBillHistory();
            }

            if (
                typeof updateDashboard ===
                "function"
            ) {
                updateDashboard();
            }

        });

        cloudBillsSyncReady = true;
    }

    /*
     Existing app jab bills ko localStorage
     mein save karegi, cloud mein bhi save hoga.
    */

    const originalSetItem =
        localStorage.setItem.bind(
            localStorage
        );

    localStorage.setItem = function (
        key,
        value
    ) {

        originalSetItem(key, value);

        if (
            key === "bills" &&
            !cloudUpdatingBills &&
            cloudBillsSyncReady
        ) {

            try {

                const bills =
                    JSON.parse(value);

                if (
                    Array.isArray(bills)
                ) {

                    saveBillsToCloud(
                        bills
                    ).catch(function (error) {

                        console.error(
                            "Cloud bills save error:",
                            error
                        );

                    });

                }

            } catch (error) {

                console.error(
                    "Bills cloud sync error:",
                    error
                );

            }
        }
    };

    /*
     Login ke baad bills sync start.
    */

    if (
        typeof firebase !== "undefined" &&
        firebase.auth
    ) {

        firebase.auth()
            .onAuthStateChanged(
                function (user) {

                    if (!user) {

                        cloudBillsSyncReady =
                            false;

                        return;
                    }

                    loadBillsFromCloud();

                    startBillsRealtimeSync();

                }
            );

    }

})();
/* =========================================================
   CLOUD SYNC - UDHAAR / CUSTOMER LEDGER
   ========================================================= */

(function () {

    let cloudUdhaarSyncReady = false;
    let cloudUpdatingUdhaar = false;

    function getLocalUdhaar() {
        return JSON.parse(
            localStorage.getItem("udhaarRecords")
        ) || [];
    }

    function getUdhaarRef() {

        const user =
            firebase.auth().currentUser;

        if (!user) return null;

        return firebase.database()
            .ref("shops/" + user.uid + "/udhaar");
    }

    function saveUdhaarToCloud(records) {

        const ref = getUdhaarRef();

        if (!ref) return;

        return ref.set(records);
    }

    function loadUdhaarFromCloud() {

        const ref = getUdhaarRef();

        if (!ref) return;

        ref.once("value")
            .then(function (snapshot) {

                const cloudRecords =
                    snapshot.val();

                const localRecords =
                    getLocalUdhaar();

                /*
                 First device:
                 agar cloud empty hai aur
                 local Udhaar records hain,
                 unhein cloud mein upload karo.
                */

                if (
                    (!cloudRecords ||
                    !Array.isArray(cloudRecords)) &&
                    localRecords.length > 0
                ) {

                    return saveUdhaarToCloud(
                        localRecords
                    );
                }

                /*
                 Cloud mein records already hain:
                 cloud data ko local Udhaar mein lao.
                */

                if (Array.isArray(cloudRecords)) {

                    cloudUpdatingUdhaar = true;

                    localStorage.setItem(
                        "udhaarRecords",
                        JSON.stringify(
                            cloudRecords
                        )
                    );

                    cloudUpdatingUdhaar = false;

                    if (
                        typeof udhaarLoadRecords ===
                        "function"
                    ) {
                        udhaarLoadRecords();
                    }
                }

            })
            .catch(function (error) {

                console.error(
                    "Cloud Udhaar load error:",
                    error
                );

            });
    }

    function startUdhaarRealtimeSync() {

        const ref = getUdhaarRef();

        if (!ref) return;

        ref.on("value", function (snapshot) {

            const cloudRecords =
                snapshot.val();

            if (
                !Array.isArray(cloudRecords)
            ) {
                return;
            }

            cloudUpdatingUdhaar = true;

            localStorage.setItem(
                "udhaarRecords",
                JSON.stringify(
                    cloudRecords
                )
            );

            cloudUpdatingUdhaar = false;

            if (
                typeof udhaarLoadRecords ===
                "function"
            ) {
                udhaarLoadRecords();
            }

        });

        cloudUdhaarSyncReady = true;
    }

    /*
     Existing Udhaar app jab records ko
     localStorage mein save karegi,
     cloud mein bhi save honge.
    */

    const originalSetItem =
        localStorage.setItem.bind(
            localStorage
        );

    localStorage.setItem = function (
        key,
        value
    ) {

        originalSetItem(key, value);

        if (
            key === "udhaarRecords" &&
            !cloudUpdatingUdhaar &&
            cloudUdhaarSyncReady
        ) {

            try {

                const records =
                    JSON.parse(value);

                if (
                    Array.isArray(records)
                ) {

                    saveUdhaarToCloud(
                        records
                    ).catch(function (error) {

                        console.error(
                            "Cloud Udhaar save error:",
                            error
                        );

                    });

                }

            } catch (error) {

                console.error(
                    "Udhaar cloud sync error:",
                    error
                );

            }
        }
    };

    /*
     Login ke baad Udhaar sync start.
    */

    if (
        typeof firebase !== "undefined" &&
        firebase.auth
    ) {

        firebase.auth()
            .onAuthStateChanged(
                function (user) {

                    if (!user) {

                        cloudUdhaarSyncReady =
                            false;

                        return;
                    }

                    loadUdhaarFromCloud();

                    startUdhaarRealtimeSync();

                }
            );

    }

})();
function printBluetoothReceipt() {

    const bills =
        JSON.parse(localStorage.getItem("bills")) || [];

    if (!bills.length) {
        alert("Koi saved bill nahi mila.");
        return;
    }

    const bill = bills[bills.length - 1];

    let receiptText = "";

    receiptText += "      HASSAN ELECTRIC TRADER\n";
    receiptText += "       Shop No: 03006980431\n";
    receiptText += "--------------------------------\n";

    receiptText +=
        "Bill No: " + (bill.billNumber || "-") + "\n";

    receiptText +=
        "Customer: " + (bill.customerName || "Walk-in") + "\n";

    receiptText +=
        "Phone: " + (bill.customerPhone || "-") + "\n";

    receiptText +=
        "Date: " + (bill.date || "-") + "\n";

    receiptText += "--------------------------------\n";

    (bill.items || []).forEach(function (item) {

        receiptText +=
            String(item.name || "") + "\n";

        receiptText +=
            "Qty: " +
            Number(item.quantity || 0) +
            " x Rs." +
            Number(item.price || 0) +
            " = Rs." +
            Number(item.total || 0) +
            "\n";
    });

    receiptText += "--------------------------------\n";

    receiptText +=
        "Subtotal: Rs. " +
        Number(bill.subtotal || 0) +
        "\n";

    receiptText +=
        "Discount: Rs. " +
        Number(bill.discount || 0) +
        "\n";

    receiptText +=
        "TOTAL: Rs. " +
        Number(bill.total || 0) +
        "\n";

    receiptText += "--------------------------------\n";
    receiptText += "\nThanks for visiting our shop!\n";
    receiptText += "\n\n\n";

    if (
        typeof Android !== "undefined" &&
        typeof Android.printBluetooth === "function"
    ) {

        Android.printBluetooth(receiptText);

    } else {

        alert(
            "Bluetooth printing final APK ke native printer system se connect hogi."
        );
    }
}
// ===============================
// FIX: NEW BILL REMOVE PRODUCT
// ===============================

window.discountBillRemoveProduct = function (index) {

    if (
        typeof discountBillItems === "undefined" ||
        !Array.isArray(discountBillItems)
    ) {
        return;
    }

    if (index < 0 || index >= discountBillItems.length) {
        return;
    }

    discountBillItems.splice(index, 1);

    if (typeof discountBillRenderItems === "function") {
        discountBillRenderItems();
    }

    if (typeof discountBillCalculate === "function") {
        discountBillCalculate();
    }
};


// ===============================
// FIX: NEW BILL SAVE BILL
// ===============================

window.saveDiscountBill = function () {

    if (
        typeof discountBillItems === "undefined" ||
        !Array.isArray(discountBillItems) ||
        discountBillItems.length === 0
    ) {
        alert("Pehle kam az kam 1 product add karein.");
        return;
    }

    const customerName =
        document.getElementById("newBillCustomerName")?.value.trim() || "";

    const customerPhone =
        document.getElementById("newBillCustomerPhone")?.value.trim() || "";

    const discountType =
        document.getElementById("newBillDiscountType")?.value || "amount";

    const discountValue =
        Number(
            document.getElementById("newBillDiscountValue")?.value
        ) || 0;

    let subtotal = 0;

    discountBillItems.forEach(function (item) {

        const quantity = Number(item.quantity) || 0;
        const price = Number(item.price) || 0;

        item.total = quantity * price;
        subtotal += item.total;
    });

    let discount = 0;

    if (discountType === "percent") {
        discount = subtotal * (discountValue / 100);
    } else {
        discount = discountValue;
    }

    if (discount < 0) {
        discount = 0;
    }

    if (discount > subtotal) {
        discount = subtotal;
    }

    const total = subtotal - discount;

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    // Stock check
    for (const item of discountBillItems) {

        const product = products.find(function (p) {
            return p.id == item.productId;
        });

        if (!product) {
            alert("Product nahi mila: " + item.name);
            return;
        }

        if (
            Number(product.stock) <
            Number(item.quantity)
        ) {
            alert(
                "Stock kam hai: " +
                item.name +
                "\nAvailable: " +
                product.stock +
                "\nRequired: " +
                item.quantity
            );
            return;
        }
    }

    // Stock decrease
    discountBillItems.forEach(function (item) {

        const product = products.find(function (p) {
            return p.id == item.productId;
        });

        if (product) {
            product.stock =
                Number(product.stock) -
                Number(item.quantity);
        }
    });

    localStorage.setItem(
        "products",
        JSON.stringify(products)
    );

    const bills =
        JSON.parse(localStorage.getItem("bills")) || [];

    let nextBillNumber = 1;

    if (bills.length > 0) {

        const numbers = bills
            .map(function (bill) {
                return Number(bill.billNumber) || 0;
            });

        nextBillNumber =
            Math.max(...numbers) + 1;
    }

    const bill = {

        id: Date.now(),

        billNumber: nextBillNumber,

        customerName: customerName,

        customerPhone: customerPhone,

        items: discountBillItems.map(function (item) {
            return {
                productId: item.productId,
                name: item.name,
                quantity: Number(item.quantity),
                price: Number(item.price),
                total: Number(item.total)
            };
        }),

        subtotal: subtotal,

        discountType: discountType,

        discountValue: discountValue,

        discount: discount,

        total: total,

        date: new Date().toLocaleString()

    };

    bills.push(bill);

    localStorage.setItem(
        "bills",
        JSON.stringify(bills)
    );

    alert(
        "Bill successfully save ho gaya!\n\n" +
        "Bill No: " +
        nextBillNumber +
        "\n" +
        "Total: Rs. " +
        total.toFixed(2)
    );

    discountBillItems = [];

    if (typeof updateDashboard === "function") {
        updateDashboard();
    }

    if (typeof loadBillHistory === "function") {
        loadBillHistory();
    }

    goHome();
};


// ===============================
// FIX: SHOW REMOVE BUTTON
// ===============================

window.discountBillRenderItems = function () {

    const box =
        document.getElementById("discountBillItems");

    if (!box) return;

    if (
        typeof discountBillItems === "undefined" ||
        !Array.isArray(discountBillItems) ||
        discountBillItems.length === 0
    ) {
        box.innerHTML =
            "<p>No products added.</p>";
      return;
    }

    box.innerHTML = "";

    discountBillItems.forEach(function (item, index) {

        const row =
            document.createElement("div");

        row.className = "product-row";

        row.innerHTML = `
            <div>
                <strong>${item.name}</strong>
                <br>
                Qty: ${item.quantity}
                <br>
                Price: Rs. ${Number(item.price).toFixed(2)}
                <br>
                Total: Rs. ${Number(item.total).toFixed(2)}
                <br><br>
                <button
                    type="button"
                    onclick="discountBillRemoveProduct(${index})"
                >
                    🗑️ Remove
                </button>
            </div>
        `;

        box.appendChild(row);
    });
};
// ==========================================
// FINAL FIX: CUSTOMER NAME + SAVE BILL RECEIPT
// ==========================================

window.saveDiscountBill = function () {

    if (
        typeof discountBillItems === "undefined" ||
        !Array.isArray(discountBillItems) ||
        discountBillItems.length === 0
    ) {
        alert("Pehle kam az kam 1 product add karein.");
        return;
    }

    // Customer information
    const customerName =
        document.getElementById("newBillCustomerName")
            ?.value
            .trim() || "";

    const customerPhone =
        document.getElementById("newBillCustomerPhone")
            ?.value
            .trim() || "";

    // Discount
    const discountType =
        document.getElementById("newBillDiscountType")
            ?.value || "amount";

    const discountValue =
        Number(
            document.getElementById("newBillDiscountValue")
                ?.value
        ) || 0;

    // Calculate subtotal
    let subtotal = 0;

    discountBillItems.forEach(function (item) {

        item.quantity =
            Number(item.quantity) || 0;

        item.price =
            Number(item.price) || 0;

        item.total =
            item.quantity * item.price;

        subtotal += item.total;
    });

    // Calculate discount
    let discount = 0;

    if (discountType === "percent") {

        discount =
            subtotal * (discountValue / 100);

    } else {

        discount =
            discountValue;
    }

    if (discount < 0) {
        discount = 0;
    }

    if (discount > subtotal) {
        discount = subtotal;
    }

    const total =
        subtotal - discount;

    // Products / Stock
    const products =
        JSON.parse(
            localStorage.getItem("products")
        ) || [];

    // Check stock first
    for (const item of discountBillItems) {

        const product =
            products.find(function (p) {
                return String(p.id) ===
                    String(item.productId);
            });

        if (!product) {

            alert(
                "Product nahi mila: " +
                item.name
            );

            return;
        }

        if (
            Number(product.stock) <
            Number(item.quantity)
        ) {

            alert(
                "Stock kam hai: " +
                item.name +
                "\nAvailable: " +
                product.stock +
                "\nRequired: " +
                item.quantity
            );

            return;
        }
    }

    // Decrease stock
    discountBillItems.forEach(function (item) {

        const product =
            products.find(function (p) {
                return String(p.id) ===
                    String(item.productId);
            });

        if (product) {

            product.stock =
                Number(product.stock) -
                Number(item.quantity);
        }
    });

    localStorage.setItem(
        "products",
        JSON.stringify(products)
    );

    // Existing bills
    const bills =
        JSON.parse(
            localStorage.getItem("bills")
        ) || [];

    // Bill number
    let billNumber = 1;

    if (
        typeof getNextBillNumber ===
        "function"
    ) {

        billNumber =
            getNextBillNumber();

    } else if (bills.length > 0) {

        const numbers =
            bills.map(function (bill) {
                return Number(
                    bill.billNumber
                ) || 0;
            });

        billNumber =
            Math.max(...numbers) + 1;
    }

    // Create bill
    const newBill = {

        billNumber: billNumber,

        shopName: SHOP_NAME,

        shopPhone: SHOP_PHONE,

        // IMPORTANT:
        // Receipt old code "customer" use karta hai
        customer: customerName,

        // New code bhi customerName rakhta hai
        customerName: customerName,

        customerPhone: customerPhone,

        items:
            discountBillItems.map(
                function (item) {

                    return {

                        productId:
                            item.productId,

                        name:
                            item.name,

                        quantity:
                            Number(item.quantity),

                        price:
                            Number(item.price),

                        total:
                            Number(item.total)
                    };
                }
            ),

        subtotal: subtotal,

        discountType:
            discountType,

        discountValue:
            discountValue,

        discount:
            discount,

        total:
            total,

        date:
            new Date().toISOString()
    };

    // Save bill
    bills.push(newBill);

    localStorage.setItem(
        "bills",
        JSON.stringify(bills)
    );

    // Clear current bill
    discountBillItems = [];

    if (
        typeof updateDashboard ===
        "function"
    ) {
        updateDashboard();
    }

    // Directly open saved receipt
    const savedBills =
        JSON.parse(
            localStorage.getItem("bills")
        ) || [];

    const lastBillIndex =
        savedBills.length - 1;

    if (
        typeof viewBill ===
        "function"
    ) {

        viewBill(lastBillIndex);

    } else {

        alert(
            "Bill save ho gaya, lekin receipt function nahi mila."
        );
    }
};
// ==========================================
// INVENTORY: CHANGE SALE PRICE
// ==========================================

window.changeSalePrice = function (id) {

    const products =
        JSON.parse(localStorage.getItem("products")) || [];

    const product =
        products.find(function (p) {
            return String(p.id) === String(id);
        });

    if (!product) {
        alert("Product nahi mila.");
        return;
    }

    const newPrice =
        prompt(
            "Sale Price change karein:\n\n" +
            "Product: " +
            product.name +
            "\nCurrent Sale Price: Rs. " +
            product.price +
            "\n\nNew Sale Price:"
        );

    if (newPrice === null) {
        return;
    }

    const price =
        Number(newPrice);

    if (
        !Number.isFinite(price) ||
        price < 0
    ) {
        alert("Please valid Sale Price enter karein.");
        return;
    }

    product.price = price;

    localStorage.setItem(
        "products",
        JSON.stringify(products)
    );

    alert(
        "Sale Price successfully update ho gayi!\n\n" +
        product.name +
        "\nNew Price: Rs. " +
        price
    );

    if (
        typeof showInventory ===
        "function"
    ) {
        showInventory();
    }
};
// ==========================================
// INVENTORY: SHOW CHANGE SALE PRICE BUTTON
// ==========================================

(function () {

    const originalShowInventory =
        window.showInventory;

    if (typeof originalShowInventory !== "function") {
        return;
    }

    window.showInventory = function () {

        originalShowInventory();

        const rows =
            document.querySelectorAll(".product-row");

        rows.forEach(function (row) {

            if (
                row.querySelector(
                    ".change-sale-price-btn"
                )
            ) {
                return;
            }

            const buttons =
                row.querySelectorAll("button");

            if (!buttons.length) {
                return;
            }

            const editButton =
                buttons[0];

            const onclickText =
                editButton.getAttribute("onclick") || "";

            const match =
                onclickText.match(
                    /editInventoryProduct\(([^)]+)\)/
                );

            if (!match) {
                return;
            }

            const productId =
                match[1];

            const button =
                document.createElement("button");

            button.type = "button";

            button.className =
                "change-sale-price-btn";

            button.textContent =
                "💰 Change Sale Price";

            button.onclick = function () {
                changeSalePrice(productId);
            };

            row.appendChild(button);
        });
    };

})();