(() => {
'use strict';
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const todayISO = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const addDays = (date, n) => { const d = new Date(date); d.setDate(d.getDate()+n); return d; };
const startOfWeek = d => { const x = new Date(d); x.setHours(0,0,0,0); x.setDate(x.getDate()-((x.getDay()+6)%7)); return x; };
const fmtDate = (iso, opts={month:'short',day:'numeric'}) => new Date(iso+'T12:00:00').toLocaleDateString(undefined,opts);
const fmtTime = t => { if(!t) return ''; const [h,m]=t.split(':').map(Number); const d=new Date(); d.setHours(h,m); return d.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'}); };
const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2,7)}`;
const palette = [
 {color:'#8b7cff',bg:'#8b7cff20',symbol:'∑'},
 {color:'#48d6a0',bg:'#48d6a01b',symbol:'A'},
 {color:'#ffb86b',bg:'#ffb86b1b',symbol:'⚛'},
 {color:'#65b8ff',bg:'#65b8ff1b',symbol:'⌘'},
 {color:'#ff7eaa',bg:'#ff7eaa1b',symbol:'✎'},
 {color:'#e4d76b',bg:'#e4d76b1b',symbol:'✦'}
];
const initial = () => {
 const today=todayISO();
 const subjects=[
  {id:'math',name:'Mathematics',goal:'Practice problem-solving',color:palette[0].color,symbol:'∑'},
  {id:'english',name:'English',goal:'Reading and vocabulary',color:palette[1].color,symbol:'A'},
  {id:'science',name:'Science',goal:'Understand key concepts',color:palette[2].color,symbol:'⚛'},
  {id:'coding',name:'Computer Science',goal:'Build practical skills',color:palette[3].color,symbol:'⌘'}
 ];
 const tasks=[
  {id:uid(),title:'Revise algebra formulas',subject:'math',date:today,start:'16:00',duration:45,notes:'Review the key formulas and solve five questions.',done:false,created:Date.now()},
  {id:uid(),title:'English reading practice',subject:'english',date:today,start:'17:00',duration:30,notes:'Read one passage and write down new words.',done:false,created:Date.now()},
  {id:uid(),title:'Review science notes',subject:'science',date:today,start:'18:00',duration:45,notes:'Summarize the main ideas in your own words.',done:false,created:Date.now()},
  {id:uid(),title:'Practice coding',subject:'coding',date:today,start:'19:00',duration:60,notes:'Work on one small feature.',done:false,created:Date.now()}
 ];
 return {profile:'Kito',weeklyTarget:12,subjects,tasks,focusMinutes:0,completedSessions:0};
};
let data;
try { data=JSON.parse(localStorage.getItem('kitoStudyData')) || initial(); } catch { data=initial(); }
if(!data.subjects || !data.tasks) data=initial();
let activeView='dashboard', taskFilter='all', weekOffset=0, toastTimer, editingSubject=null;
const save=()=>localStorage.setItem('kitoStudyData',JSON.stringify(data));
const subject=id=>data.subjects.find(s=>s.id===id)||{name:'General',color:palette[0].color,bg:palette[0].bg,symbol:'✦'};
const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2500);}
function showView(view){
 activeView=view; $$('.view').forEach(v=>v.classList.toggle('active',v.id===`view-${view}`));
 $$('.nav-item[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 $('#pageName').textContent=({dashboard:'Overview',schedule:'Weekly schedule',tasks:'Study tasks',subjects:'Subjects',focus:'Focus timer'})[view]||'Overview';
 $('#sidebar').classList.remove('open'); render();
}
function goto(view){showView(view);window.scrollTo({top:0,behavior:'smooth'});}
function subjectOptions(selected=''){
 return `<option value="">General study</option>`+data.subjects.map(s=>`<option value="${escapeHTML(s.id)}" ${s.id===selected?'selected':''}>${escapeHTML(s.name)}</option>`).join('');
}
function render(){
 $('#todayLabel').textContent=new Date().toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'});
 $('#greeting').innerHTML=`${new Date().getHours()<12?'Good morning':new Date().getHours()<18?'Good afternoon':'Good evening'}, ${escapeHTML(data.profile||'Student')}<span class="purple-dot">.</span>`;
 $('#weeklyTargetText').textContent=`${data.weeklyTarget} hours`;
 renderDashboard(); renderTasks(); renderSubjects(); renderSchedule();
 $('#taskSubjectFilter').innerHTML='<option value="all">All subjects</option>'+data.subjects.map(s=>`<option value="${escapeHTML(s.id)}">${escapeHTML(s.name)}</option>`).join('');
}
function tasksForDate(date){return data.tasks.filter(t=>t.date===date).sort((a,b)=>(a.start||'').localeCompare(b.start||''));}
function renderDashboard(){
 const completed=data.tasks.filter(t=>t.done).length, total=data.tasks.length;
 $('#statCompleted').innerHTML=`${completed} <small>tasks</small>`;
 $('#completionRate').textContent=`${total?Math.round(completed/total*100):0}%`;
 $('#completionBar').style.width=`${total?completed/total*100:0}%`;
 const weekStart=startOfWeek(new Date()), weekEnd=addDays(weekStart,7);
 const mins=data.tasks.filter(t=>{const d=new Date(t.date+'T12:00:00');return d>=weekStart&&d<weekEnd&&t.done;}).reduce((a,t)=>a+(+t.duration||0),0)+(+data.focusMinutes||0);
 const hours=mins/60; $('#statHours').innerHTML=`${hours.toFixed(1)} <small>hrs</small>`;
 $('#hoursBar').style.width=`${Math.min(100,hours/Math.max(1,data.weeklyTarget)*100)}%`;
 const daysWithStudy=new Set(data.tasks.filter(t=>t.done).map(t=>t.date));
 let streak=0; const d=new Date(); if(!daysWithStudy.has(todayISO(d)))d.setDate(d.getDate()-1);
 while(daysWithStudy.has(todayISO(d))&&streak<365){streak++;d.setDate(d.getDate()-1);}
 $('#statStreak').innerHTML=`${streak} <small>days</small>`;
 $$('#streakDots i').forEach((e,i)=>e.classList.toggle('on',i<Math.min(7,streak)));
 const today=tasksForDate(todayISO());
 $('#todaySub').textContent=`${today.length} session${today.length===1?'':'s'} planned for ${new Date().toLocaleDateString(undefined,{weekday:'long',month:'short',day:'numeric'})}`;
 $('#todayList').innerHTML=today.map(t=>{const s=subject(t.subject);return `<div class="today-item"><div class="item-color" style="background:${s.color}"></div><div class="item-main"><strong>${escapeHTML(t.title)}</strong><span>${escapeHTML(s.name)} · ${fmtTime(t.start)}${t.notes?` · ${escapeHTML(t.notes)}`:''}</span></div><div class="item-right"><span class="duration">${t.duration}m</span><button class="done-btn ${t.done?'done':''}" data-done="${t.id}" title="${t.done?'Mark incomplete':'Mark complete'}">${t.done?'✓':'○'}</button></div></div>`}).join('');
 $('#todayEmpty').classList.toggle('hidden',today.length>0); $('#todayList').classList.toggle('hidden',today.length===0);
 $('#subjectCards').innerHTML=data.subjects.slice(0,4).map(s=>{
  const related=data.tasks.filter(t=>t.subject===s.id), done=related.filter(t=>t.done).length, percent=related.length?Math.round(done/related.length*100):0;
  return `<article class="subject-card"><div class="subject-card-top"><span class="subject-symbol" style="color:${s.color};background:${s.color}22">${escapeHTML(s.symbol||'✦')}</span><span style="font-size:10px;color:var(--muted)">${related.length} tasks</span></div><h3>${escapeHTML(s.name)}</h3><p>${escapeHTML(s.goal||'Keep learning')}</p><div class="subject-progress"><span style="width:${percent}%;background:${s.color}"></span></div><div class="subject-bottom"><span>${done}/${related.length} complete</span><span>${percent}%</span></div></article>`;
 }).join('')||'<p class="muted small">Add a subject to start organizing your learning.</p>';
 const chart=$('#weekChart'); const max= Math.max(2,...Array.from({length:7},(_,i)=>{const date=todayISO(addDays(weekStart,i));return data.tasks.filter(t=>t.date===date).reduce((n,t)=>n+t.duration/60,0)}));
 chart.innerHTML=Array.from({length:7},(_,i)=>{const d=addDays(weekStart,i),iso=todayISO(d),dayTasks=data.tasks.filter(t=>t.date===iso),planned=dayTasks.reduce((n,t)=>n+t.duration/60,0),done=dayTasks.filter(t=>t.done).reduce((n,t)=>n+t.duration/60,0);return `<div class="chart-day ${iso===todayISO()?'today':''}"><div class="bar-pair"><div class="bar planned" style="height:${Math.max(planned?4:0,planned/max*100)}%" title="${planned.toFixed(1)} planned hours"></div><div class="bar completed" style="height:${Math.max(done?4:0,done/max*100)}%" title="${done.toFixed(1)} completed hours"></div></div><label>${d.toLocaleDateString(undefined,{weekday:'short'}).slice(0,2)}</label></div>`}).join('');
 $('#weekRange').textContent=`${fmtDate(todayISO(weekStart),{month:'short',day:'numeric'})} – ${fmtDate(todayISO(addDays(weekStart,6)),{month:'short',day:'numeric'})}`;
}
function renderTasks(){
 const subFilter=$('#taskSubjectFilter').value||'all';
 let list=data.tasks.filter(t=>taskFilter==='all'||(taskFilter==='open'&&!t.done)||(taskFilter==='done'&&t.done)).filter(t=>subFilter==='all'||t.subject===subFilter).sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start));
 $('#taskList').innerHTML=list.map(t=>{const s=subject(t.subject);return `<div class="task-row"><input class="task-check" type="checkbox" data-done="${t.id}" ${t.done?'checked':''} aria-label="Complete ${escapeHTML(t.title)}"><div><div class="task-title ${t.done?'is-done':''}">${escapeHTML(t.title)}</div><div class="task-meta">${fmtDate(t.date,{weekday:'short',month:'short',day:'numeric'})} · ${fmtTime(t.start)} · ${t.duration} min${t.notes?` · ${escapeHTML(t.notes)}`:''}</div></div><span class="task-tag" style="background:${s.color}22;color:${s.color}">${escapeHTML(s.name)}</span><div class="task-actions"><button class="small-action" data-edit="${t.id}">Edit</button><button class="small-action" data-delete="${t.id}">Delete</button></div></div>`}).join('');
 $('#tasksEmpty').classList.toggle('hidden',list.length>0);
}
function renderSubjects(){
 $('#subjectManagement').innerHTML=data.subjects.map(s=>{const related=data.tasks.filter(t=>t.subject===s.id),done=related.filter(t=>t.done).length,pct=related.length?Math.round(done/related.length*100):0;return `<article class="managed-subject"><div class="subject-symbol" style="color:${s.color};background:${s.color}22">${escapeHTML(s.symbol||'✦')}</div><h3>${escapeHTML(s.name)}</h3><p>${escapeHTML(s.goal||'A subject to keep progressing in.')}</p><div class="subject-bottom"><span>${related.length} tasks</span><span>${pct}% complete</span></div><div class="subject-progress"><span style="width:${pct}%;background:${s.color}"></span></div><div class="managed-actions"><button class="secondary-btn" data-edit-subject="${s.id}">Edit</button><button class="secondary-btn" data-delete-subject="${s.id}">Delete</button></div></article>`}).join('');
 $('#entrySubject').innerHTML=subjectOptions($('#entrySubject').value);
}
function renderSchedule(){
 const monday=startOfWeek(addDays(new Date(),weekOffset*7)); const days=Array.from({length:7},(_,i)=>addDays(monday,i));
 $('#scheduleWeekLabel').textContent=`${fmtDate(todayISO(days[0]),{month:'short',day:'numeric'})} – ${fmtDate(todayISO(days[6]),{month:'short',day:'numeric',year:'numeric'})}`;
 const times=Array.from({length:15},(_,i)=>i+7);
 let html='<div class="cal-head"></div>';
 days.forEach(d=>html+=`<div class="cal-head ${todayISO(d)===todayISO()?'today':''}">${d.toLocaleDateString(undefined,{weekday:'short'}).toUpperCase()}<strong>${d.getDate()}</strong></div>`);
 times.forEach(h=>{
  html+=`<div class="time-label">${String(h%12||12)} ${h<12?'AM':'PM'}</div>`;
  days.forEach(d=>{
   const iso=todayISO(d), hourTasks=data.tasks.filter(t=>t.date===iso&&Number((t.start||'00:00').split(':')[0])===h);
   html+=`<div class="cal-cell" data-cell-date="${iso}" data-cell-hour="${h}">${hourTasks.map(t=>{const s=subject(t.subject);return `<button class="cal-event" data-edit="${t.id}" style="background:${s.color}33;border-left:2px solid ${s.color};color:#f4f3ff"><strong>${escapeHTML(t.title)}</strong><span>${fmtTime(t.start)} · ${t.duration}m</span></button>`}).join('')}</div>`;
  });
 });
 $('#calendar').innerHTML=html;
}
function openTaskModal(task=null,date=todayISO(),start='16:00'){
 $('#entryForm').reset(); $('#entryId').value=task?.id||''; $('#entryTitle').value=task?.title||''; $('#entrySubject').innerHTML=subjectOptions(task?.subject||''); $('#entryDate').value=task?.date||date; $('#entryStart').value=task?.start||start; $('#entryDuration').value=String(task?.duration||60); $('#entryNotes').value=task?.notes||'';
 $('#modalTitle').textContent=task?'Edit study task':'Add study task'; $('#modalEyebrow').textContent=task?'UPDATE YOUR PLAN':'MAKE A PLAN'; $('#modalBackdrop').classList.remove('hidden'); setTimeout(()=>$('#entryTitle').focus(),80);
}
function closeModal(){$('#modalBackdrop').classList.add('hidden');}
function toggleDone(id,checked){const t=data.tasks.find(x=>x.id===id);if(!t)return;t.done=checked;save();render();toast(checked?'Task completed. Nice work!':'Task marked as not done.');}
function addTask(e){e.preventDefault();const id=$('#entryId').value;const task={id:id||uid(),title:$('#entryTitle').value.trim(),subject:$('#entrySubject').value,date:$('#entryDate').value,start:$('#entryStart').value,duration:+$('#entryDuration').value,notes:$('#entryNotes').value.trim(),done:false,created:Date.now()};if(!task.title||!task.date)return;if(id){const old=data.tasks.find(t=>t.id===id);task.done=old?.done||false;task.created=old?.created||Date.now();data.tasks=data.tasks.map(t=>t.id===id?task:t);toast('Task updated.');}else{data.tasks.push(task);toast('Task added to your plan.');}save();closeModal();render();}
function deleteTask(id){const t=data.tasks.find(x=>x.id===id);if(!t)return;if(confirm(`Delete "${t.title}"?`)){data.tasks=data.tasks.filter(x=>x.id!==id);save();render();toast('Task deleted.');}}
function openSubjectModal(s=null){
 const name=prompt(s?'Edit subject name:':'Subject name: ',s?.name||'');if(name===null)return;const clean=name.trim();if(!clean)return toast('Please enter a subject name.');
 const goal=prompt('What is your goal for this subject?',s?.goal||'Build confidence and practice regularly');if(goal===null)return;
 if(s){s.name=clean;s.goal=goal.trim();toast('Subject updated.');}
 else{const p=palette[data.subjects.length%palette.length];data.subjects.push({id:uid(),name:clean,goal:goal.trim(),color:p.color,symbol:p.symbol});toast('Subject added.');}
 save();render();
}
function deleteSubject(id){const s=subject(id);if(!confirm(`Delete subject "${s.name}"? Its tasks will be kept as General study.`))return;data.subjects=data.subjects.filter(x=>x.id!==id);data.tasks.forEach(t=>{if(t.subject===id)t.subject='';});save();render();toast('Subject deleted.');}
function exportData(){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='kito-study-backup.json';a.click();URL.revokeObjectURL(url);toast('Your backup has been exported.');}
function resetData(){if(!confirm('Reset the planner to its original demo data? This replaces the current data on this device.'))return;data=initial();save();render();toast('Demo data restored.');}
function setProfile(){const name=prompt('What should we call you?',data.profile||'Student');if(name===null)return;data.profile=name.trim()||'Student';save();render();toast('Profile updated.');}
document.addEventListener('click',e=>{
 const nav=e.target.closest('[data-view]');if(nav){showView(nav.dataset.view);return;}
 const gotoBtn=e.target.closest('[data-goto]');if(gotoBtn){goto(gotoBtn.dataset.goto);return;}
 const done=e.target.closest('[data-done]');if(done){const id=done.dataset.done;const task=data.tasks.find(t=>t.id===id);toggleDone(id,done.type==='checkbox'?done.checked:!task?.done);return;}
 const edit=e.target.closest('[data-edit]');if(edit){const t=data.tasks.find(x=>x.id===edit.dataset.edit);if(t)openTaskModal(t);return;}
 const del=e.target.closest('[data-delete]');if(del){deleteTask(del.dataset.delete);return;}
 const editSub=e.target.closest('[data-edit-subject]');if(editSub){openSubjectModal(data.subjects.find(s=>s.id===editSub.dataset.editSubject));return;}
 const delSub=e.target.closest('[data-delete-subject]');if(delSub){deleteSubject(delSub.dataset.deleteSubject);return;}
 const cell=e.target.closest('[data-cell-date]');if(cell&&!e.target.closest('.cal-event')){openTaskModal(null,cell.dataset.cellDate,`${String(+cell.dataset.cellHour).padStart(2,'0')}:00`);return;}
});
$('#quickAddBtn').onclick=()=>openTaskModal();$('#tasksAddBtn').onclick=()=>openTaskModal();$('#scheduleAddBtn').onclick=()=>openTaskModal();$('#subjectAddBtn').onclick=()=>openSubjectModal();$('#emptyAddBtn').onclick=()=>openTaskModal();
$('#modalClose').onclick=closeModal;$('#modalCancel').onclick=closeModal;$('#modalBackdrop').addEventListener('click',e=>{if(e.target===$('#modalBackdrop'))closeModal();});$('#entryForm').addEventListener('submit',addTask);
$('#taskFilters').addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;taskFilter=b.dataset.filter;$$('#taskFilters button').forEach(x=>x.classList.toggle('selected',x===b));renderTasks();});
$('#taskSubjectFilter').addEventListener('change',renderTasks);
$('#prevWeek').onclick=()=>{weekOffset--;renderSchedule();};$('#nextWeek').onclick=()=>{weekOffset++;renderSchedule();};$('#todayWeekBtn').onclick=()=>{weekOffset=0;renderSchedule();};
$('#exportBtn').onclick=exportData;$('#resetBtn').onclick=resetData;$('#profileBtn').onclick=setProfile;$('#menuBtn').onclick=()=>$('#sidebar').classList.toggle('open');
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();$('#sidebar').classList.remove('open');}});
/* Focus timer */
let timerDuration=25*60,timerRemaining=25*60,timerInterval=null,timerRunning=false,isBreak=false;
function drawTimer(){const mins=Math.floor(timerRemaining/60),secs=timerRemaining%60;$('#timerDisplay').textContent=`${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;const progress=timerDuration?1-timerRemaining/timerDuration:0;$('#timerRing').style.background=`conic-gradient(var(--purple) ${progress*360}deg,#2b2f4b 0deg)`;$('#timerHint').textContent=timerRunning?'Stay with this one thing':timerRemaining===0?'Session complete!': 'Ready when you are';$('#timerStart').textContent=timerRunning?'Ⅱ Pause focus':'▶ Start focus';}
function setTimer(minutes,breakMode=false){clearInterval(timerInterval);timerInterval=null;timerRunning=false;isBreak=breakMode;timerDuration=minutes*60;timerRemaining=timerDuration;$('#timerMode').textContent=breakMode?'Break time':'Focus time';$$('.timer-presets button').forEach(b=>b.classList.toggle('selected',+b.dataset.minutes===minutes&&!!b.dataset.break===breakMode));drawTimer();}
function finishTimer(){clearInterval(timerInterval);timerInterval=null;timerRunning=false;timerRemaining=0;drawTimer();if(!isBreak){data.focusMinutes=(+data.focusMinutes||0)+Math.round(timerDuration/60);data.completedSessions=(+data.completedSessions||0)+1;save();renderDashboard();toast('Focus session complete! Take a well-earned break.');}else toast('Break finished. Ready for another round?');}
$('#timerStart').onclick=()=>{if(timerRunning){clearInterval(timerInterval);timerInterval=null;timerRunning=false;drawTimer();return;}if(timerRemaining<=0)timerRemaining=timerDuration;timerRunning=true;drawTimer();timerInterval=setInterval(()=>{timerRemaining--;if(timerRemaining<=0)finishTimer();else drawTimer();},1000);};
$('#timerReset').onclick=()=>setTimer(timerDuration/60,isBreak);
$$('.timer-presets button').forEach(b=>b.onclick=()=>setTimer(+b.dataset.minutes,!!b.dataset.break));
/* Start in a friendly default view. */
$('#entryDate').value=todayISO();render();
})();