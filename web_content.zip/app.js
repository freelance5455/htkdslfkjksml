
const seedMembers=[
{name:"Rahul Kumar",id:"DKG-1024",phone:"+9198XXXXXX21",plan:"Premium 3 Months",status:"Active",expiry:"31 Dec 2026",paid:4000,due:2000},
{name:"Aman Singh",id:"DKG-1025",phone:"+9197XXXXXX12",plan:"Elite 6 Months",status:"Active",expiry:"18 Feb 2027",paid:6000,due:0},
{name:"Mohit Sharma",id:"DKG-1026",phone:"+9196XXXXXX44",plan:"Premium 6 Months",status:"Pending",expiry:"12 Mar 2027",paid:3000,due:1500},
{name:"Neha Verma",id:"DKG-1027",phone:"+9195XXXXXX76",plan:"Signature 12 Months",status:"Active",expiry:"01 Oct 2027",paid:9000,due:0},
{name:"Vikram Singh",id:"DKG-1028",phone:"+9194XXXXXX88",plan:"Basic 1 Month",status:"Expired",expiry:"28 Sep 2026",paid:999,due:0},
{name:"Arjun Mehta",id:"DKG-1029",phone:"+9193XXXXXX31",plan:"Premium 3 Months",status:"Pending",expiry:"08 Oct 2026",paid:2000,due:1000}
];
const seedPayments=[
{member:"Rahul Kumar",amount:2000,days:8,plan:"Premium 3 Months"},
{member:"Mohit Sharma",amount:1500,days:5,plan:"Premium 6 Months"},
{member:"Arjun Mehta",amount:1000,days:2,plan:"Premium 3 Months"}
];
const trainers=[["Arjun Mehta","Strength Coach","42 Members"],["Priya Sharma","Fitness & Mobility","31 Members"],["Karan Singh","Performance Coach","38 Members"]];
const products=[["Whey Protein",3,"12%"],["DK Shaker",27,"68%"],["Gym Gloves",8,"31%"],["Creatine",15,"55%"],["DK T-Shirt",21,"74%"],["Resistance Band",6,"25%"]];

const DB={
 get(k,f){try{return JSON.parse(localStorage.getItem("dk_"+k))??f}catch{return f}},
 set(k,v){localStorage.setItem("dk_"+k,JSON.stringify(v))}
};
if(!localStorage.getItem("dk_members")) DB.set("members",seedMembers);
if(!localStorage.getItem("dk_payments")) DB.set("payments",seedPayments);
if(!localStorage.getItem("dk_attendance")) DB.set("attendance",[]);
let members=DB.get("members",seedMembers), payments=DB.get("payments",seedPayments), attendance=DB.get("attendance",[]);

function money(n){return "₹"+Number(n||0).toLocaleString("en-IN")}
function renderMembers(list=members){
 const el=document.getElementById("memberRows"); if(!el)return;
 el.innerHTML=list.map(m=>`<tr><td><b>${m.name}</b><small>${m.id} • ${m.phone}</small></td><td>${m.plan}</td><td><span class="status ${m.status==="Pending"?"pending":m.status==="Expired"?"expired":""}">${m.status}</span></td><td>${m.expiry}</td><td><b>${m.due?"PENDING":"PAID"}</b><small>Paid ${money(m.paid)}${m.due?" • Due "+money(m.due):""}</small></td><td><button class="link" onclick="viewMember('${m.id}')">View</button></td></tr>`).join("");
}
function renderPayments(){
 const el=document.getElementById("paymentRows"); if(!el)return;
 el.innerHTML=payments.map(m=>`<tr><td><b>${m.member}</b></td><td><b class="danger">${money(m.amount)}</b></td><td>${m.days} days</td><td>${m.plan}</td><td><button class="link" onclick="sendWhatsApp('${m.member}',${m.amount})">WhatsApp</button> <button class="premium" onclick="collectPayment('${m.member}')">Collect</button></td></tr>`).join("");
}
function renderTrainers(){const el=document.getElementById("trainerGrid");if(!el)return;el.innerHTML=trainers.map(t=>`<div class="trainer card"><div class="avatar">${t[0].split(" ").map(x=>x[0]).join("")}</div><h3>${t[0]}</h3><p>${t[1]}</p><span class="pill">${t[2]}</span></div>`).join("")}
function renderProducts(){const el=document.getElementById("inventoryGrid");if(!el)return;el.innerHTML=products.map(p=>`<div class="product card"><span class="eyebrow">DK STORE</span><h3>${p[0]}</h3><small>${p[1]} left</small><div class="stock"><i style="width:${p[2]}"></i></div><button class="link" onclick="toast('${p[0]} inventory opened')">Manage stock →</button></div>`).join("")}
function renderCheckins(){
 const names=attendance.length?attendance.slice().reverse():["Rahul Kumar","Aman Singh","Neha Verma","Mohit Sharma","Arjun Mehta","Riya Patel","Karan Singh","Sahil Khan"];
 const el=document.getElementById("checkins");if(!el)return;
 el.innerHTML=names.map(x=>{let n=typeof x==="string"?x:x.name;let tm=typeof x==="string"?"07:12 AM":x.time;return `<div class="check"><b>${n}</b><small>Check-in ${tm} • verified</small></div>`}).join("");
}
function refresh(){members=DB.get("members",seedMembers);payments=DB.get("payments",seedPayments);attendance=DB.get("attendance",[]);renderMembers();renderPayments();renderTrainers();renderProducts();renderCheckins();updateDashboard();}
function updateDashboard(){
 const pending=members.reduce((a,m)=>a+Number(m.due||0),0);
 const cards=document.querySelectorAll("#dashboard .stat b"); if(cards.length>=4){cards[0].textContent=members.filter(m=>m.status!=="Expired").length;cards[3].textContent=money(pending)}
}
function go(page){document.querySelectorAll(".nav").forEach(n=>n.classList.toggle("active",n.dataset.page===page));document.querySelectorAll(".page").forEach(p=>p.classList.remove("active-page"));document.getElementById(page)?.classList.add("active-page");document.getElementById("pageTitle").innerHTML=page==="dashboard"?"Good Morning, Owner <span>✦</span>":page==="ai"?"DK AI Assistant":page[0].toUpperCase()+page.slice(1);window.scrollTo(0,0)}
document.querySelectorAll(".nav").forEach(n=>n.addEventListener("click",()=>go(n.dataset.page)));
function filterMembers(){const q=(document.getElementById("memberSearch")?.value||"").toLowerCase();renderMembers(members.filter(m=>(m.name+m.id+m.phone).toLowerCase().includes(q)))}
function viewMember(id){const m=members.find(x=>x.id===id);if(!m)return;document.getElementById("modalTitle").textContent="Member Profile — "+m.name;document.querySelector(".formgrid").innerHTML=`<div class="profilebox"><span class="eyebrow">MEMBER ID</span><b>${m.id}</b></div><div class="profilebox"><span class="eyebrow">STATUS</span><b>${m.status}</b></div><div class="profilebox"><span class="eyebrow">PLAN</span><b>${m.plan}</b></div><div class="profilebox"><span class="eyebrow">EXPIRY</span><b>${m.expiry}</b></div><div class="profilebox"><span class="eyebrow">PAID</span><b>${money(m.paid)}</b></div><div class="profilebox"><span class="eyebrow">PENDING</span><b>${money(m.due)}</b></div>`;document.querySelector(".modalbox .full").textContent="Close Profile";document.querySelector(".modalbox .full").onclick=closeModal;document.getElementById("modal").classList.add("show")}
function openModal(title){document.getElementById("modalTitle").textContent=title;document.querySelector(".formgrid").innerHTML=`<label>Full Name<input id="fName" placeholder="Rahul Kumar"></label><label>Mobile Number<input id="fPhone" placeholder="+9198..."></label><label>Membership Plan<select id="fPlan"><option>Premium 3 Months</option><option>Elite 6 Months</option><option>Signature 12 Months</option></select></label><label>Total Fee<input id="fTotal" type="number" placeholder="5000"></label><label>Paid Amount<input id="fPaid" type="number" placeholder="3000"></label><label>Expiry Date<input id="fExpiry" type="date"></label>`;document.querySelector(".modalbox .full").textContent="Save & Continue";document.querySelector(".modalbox .full").onclick=saveModal;document.getElementById("modal").classList.add("show")}
function closeModal(){document.getElementById("modal").classList.remove("show")}
function saveModal(){const n=document.getElementById("fName")?.value.trim();if(!n){toast("Enter member name");return}const total=Number(document.getElementById("fTotal").value||0),paid=Number(document.getElementById("fPaid").value||0);const id="DKG-"+Math.floor(1000+Math.random()*8999);members.push({name:n,id,phone:document.getElementById("fPhone").value||"",plan:document.getElementById("fPlan").value,status:paid>=total?"Active":"Pending",expiry:document.getElementById("fExpiry").value||"Not set",paid,due:Math.max(0,total-paid)});DB.set("members",members);closeModal();refresh();toast("Member saved locally")}
function collectPayment(name){const m=members.find(x=>x.name===name);if(!m)return;const amt=Number(prompt("Enter payment amount",m.due)||0);if(!amt)return;m.paid+=amt;m.due=Math.max(0,m.due-amt);if(m.due===0)m.status="Active";DB.set("members",members);payments=payments.filter(p=>p.member!==name||m.due>0);if(m.due>0)payments.push({member:name,amount:m.due,days:0,plan:m.plan});DB.set("payments",payments);refresh();toast("Payment recorded locally")}
function sendWhatsApp(name,amount){const m=members.find(x=>x.name===name);const phone=(m?.phone||"").replace(/\D/g,"");const msg=encodeURIComponent(`DK GYM payment reminder: ${name}, pending amount ${money(amount)}. Please contact DK GYM for payment details.`);if(phone.length>=10)window.open(`https://wa.me/${phone}?text=${msg}`,"_blank");else toast("Valid mobile number needed for WhatsApp")}
function markAttendance(){
 const n=prompt("Member name / ID for check-in");if(!n)return;
 const m=members.find(x=>x.name.toLowerCase()===n.toLowerCase()||x.id.toLowerCase()===n.toLowerCase());
 if(!m){toast("Member not found");return}
 const now=new Date();const time=now.toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"});
 attendance.push({name:m.name,time});DB.set("attendance",attendance);renderCheckins();toast(m.name+" checked in")}
function scanQR(){
 if("BarcodeDetector" in window){toast("Camera QR scanner can be connected to BarcodeDetector on supported browsers; select camera permission next.")}
 else toast("This browser does not support native QR scanning. Manual Member ID check-in is available.");
}
function resetDemo(){if(confirm("Reset all local DK GYM demo data?")){localStorage.clear();location.reload()}}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");clearTimeout(window.tt);window.tt=setTimeout(()=>t.classList.remove("show"),2600)}
function ask(q){if(!q)return;const chat=document.getElementById("chat");chat.innerHTML+=`<div class="bubble user">${q}</div>`;let a="";const s=q.toLowerCase();if(s.includes("pending")){const p=members.filter(m=>m.due>0);a=`${p.length} members have pending payments. Total: ${money(p.reduce((x,m)=>x+m.due,0))}.`;}else if(s.includes("expire"))a="14 memberships are shown as expiring soon in the demo dashboard.";else if(s.includes("collection")||s.includes("revenue"))a="This demo records payments locally in your browser. Current seeded collection: ₹1,84,500.";else if(s.includes("inactive"))a="The demo can track check-ins locally. Members without recent check-ins can be identified after attendance data is entered.";else a="Try: pending payments, expiry in 7 days, collection, or inactive members.";chat.innerHTML+=`<div class="bubble ai">${a}</div>`;chat.scrollTop=chat.scrollHeight;document.getElementById("aiInput").value=""}
renderMembers();renderPayments();renderTrainers();renderProducts();renderCheckins();updateDashboard();
