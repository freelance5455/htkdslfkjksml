const DUSHANBE=[38.5598,68.7870];
const map=L.map('map',{zoomControl:true}).setView(DUSHANBE,13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
  maxZoom:19, attribution:'© OpenStreetMap contributors'
}).addTo(map);

let userMarker=null, accuracyCircle=null;
const menu=document.getElementById('sideMenu');
const toast=document.getElementById('toast');

function showToast(msg){
  toast.textContent=msg; toast.style.display='block';
  clearTimeout(window.toastTimer); window.toastTimer=setTimeout(()=>toast.style.display='none',2800);
}
document.getElementById('menuBtn').onclick=()=>menu.classList.toggle('open');
document.getElementById('centerBtn').onclick=()=>{map.setView(DUSHANBE,13);menu.classList.remove('open')};
document.getElementById('themeBtn').onclick=()=>{document.body.classList.toggle('alt');showToast('Purple mode фаъол аст');};

function onLocation(pos){
  const {latitude,longitude,accuracy}=pos.coords;
  if(userMarker) map.removeLayer(userMarker);
  if(accuracyCircle) map.removeLayer(accuracyCircle);
  userMarker=L.marker([latitude,longitude]).addTo(map).bindPopup('📍 Шумо дар ин ҷо ҳастед').openPopup();
  accuracyCircle=L.circle([latitude,longitude],{radius:accuracy,weight:1,fillOpacity:.10}).addTo(map);
  map.setView([latitude,longitude],16);
  document.getElementById('locationTitle').textContent='Ҷойгиршавии шумо';
  document.getElementById('locationText').textContent=`±${Math.round(accuracy)} м • GPS`;
  menu.classList.remove('open');
  showToast('Ҷойгиршавӣ ёфт шуд ✓');
}
function onLocationError(err){
  const msg=err.code===1?'Иҷозаи Location рад шуд. Дар танзимоти браузер иҷозат диҳед.':'Location дастрас нашуд.';
  showToast(msg);
}
document.getElementById('locBtn').onclick=()=>{
  if(!navigator.geolocation){showToast('Браузер Location-ро дастгирӣ намекунад');return}
  showToast('Дархости иҷозаи Location...');
  navigator.geolocation.getCurrentPosition(onLocation,onLocationError,{enableHighAccuracy:true,timeout:10000,maximumAge:0});
};

let searchTimer;
document.getElementById('searchInput').addEventListener('input',e=>{
  clearTimeout(searchTimer); const q=e.target.value.trim(); if(q.length<3)return;
  searchTimer=setTimeout(async()=>{
    try{
      const url='https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=tj&q='+encodeURIComponent(q+' Dushanbe');
      const r=await fetch(url,{headers:{'Accept-Language':'tg'}});
      const data=await r.json();
      if(!data.length){showToast('Ҷой ёфт нашуд');return}
      const p=data[0], lat=+p.lat, lon=+p.lon;
      map.setView([lat,lon],16);
      L.marker([lat,lon]).addTo(map).bindPopup(p.display_name).openPopup();
    }catch(e){showToast('Ҷустуҷӯ дастрас нест')}
  },500);
});
