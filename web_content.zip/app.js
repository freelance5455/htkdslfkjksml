const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const DBKEY='gemo_tools_v1', LANGKEY='gemo_tools_lang';
let db={workers:[],tools:[],events:[]};
let lang=localStorage.getItem(LANGKEY)||'de';

const I={
de:{
tools:'Werkzeuge',heroSub:'Schnelle Ausgabe, Rückgabe und vollständige Historie.',issue:'Ausgeben',return:'Zurücknehmen',transfer:'Übergeben',
recentActions:'Letzte Aktionen',workers:'Mitarbeiter',workersSub:'Wer hat aktuell welches Werkzeug?',add:'+ Hinzufügen',toolsSub:'Frei, ausgegeben, beschädigt oder in Reparatur',
searchTool:'Werkzeug suchen…',history:'Historie',historySub:'Alle Ausgaben, Rückgaben und Übergaben',backup:'Austausch & Sicherung',backupSub:'Daten zwischen mehreren Telefonen zusammenführen',
createBackup:'Sicherung erstellen',backupDesc:'Speichert Mitarbeiter, Werkzeuge, Historie, Fotos und Unterschriften.',createShareFile:'Datei zum Teilen erstellen',
importMerge:'Importieren & zusammenführen',mergeDesc:'Neue Daten werden ergänzt, vorhandene Einträge nicht dupliziert.',chooseFile:'Datei auswählen',home:'Start',exchange:'Austausch',
totalTools:'Werkzeuge gesamt',issuedNow:'Aktuell ausgegeben',available:'Frei',brokenRepair:'Defekt / Reparatur',noneWorkers:'Noch keine Mitarbeiter.',currentlyHas:'Aktuell beim Mitarbeiter',
noneTools:'Noch keine Werkzeuge vorhanden.',noNumber:'Ohne Nummer',atWorker:'bei',open:'Öffnen',statusBroken:'Defekt',statusRepair:'In Reparatur',statusIssued:'Ausgegeben',statusFree:'Frei',
evIssue:'Ausgegeben',evReturn:'Zurückgegeben',evTransfer:'Übergeben',completeOk:'Vollständigkeit bestätigt',completeBad:'Unvollständig',missingProblem:'Fehlt / Problem',
comment:'Kommentar',signatureSaved:'Unterschrift gespeichert',noneHistory:'Noch keine Historie.',noneActions:'Noch keine Aktionen.',
newWorker:'Neuer Mitarbeiter',fullName:'Vor- und Nachname',nameExample:'z. B. Michael Mustermann',save:'Speichern',enterName:'Bitte Namen eingeben',workerAdded:'Mitarbeiter hinzugefügt',
newTool:'Neues Werkzeug',name:'Bezeichnung',toolExample:'Bosch Bohrhammer',inventoryNo:'Inventarnummer',setIssue:'Lieferumfang bei Ausgabe',setExample:'Koffer, Ladegerät, Akku',
toolPhotos:'Werkzeugfotos',camera:'Kamera',gallery:'Galerie',saveTool:'Werkzeug speichern',enterToolName:'Bitte Bezeichnung eingeben',toolAdded:'Werkzeug hinzugefügt',
locUnavailable:'Nicht verfügbar',locUnknown:'Nicht bestimmt',addWorkerFirst:'Bitte zuerst Mitarbeiter hinzufügen',addToolFirst:'Bitte zuerst Werkzeug hinzufügen',
noFreeTools:'Keine freien Werkzeuge',noIssuedTools:'Keine ausgegebenen Werkzeuge',giveTo:'Ausgeben an',transferTo:'Übergeben an',tool:'Werkzeug',
returnedComplete:'Vollständig wie ausgegeben zurückgegeben',leaveChecked:'Wenn alles vollständig ist, Haken stehen lassen',whatMissing:'Was fehlt / was stimmt nicht?',missingExample:'z. B. Ladegerät fehlt',
condition:'Zustand',condOk:'In Ordnung',condDamaged:'Beschädigt',condBroken:'Defekt',photos:'Fotos',commentOptional:'Kommentar (optional)',commentPlaceholder:'Beliebiger Kommentar…',
signatureOptional:'Unterschrift des Mitarbeiters (optional)',clear:'Löschen',withoutSignature:'Ohne Unterschrift',okSave:'OK — speichern',issueTool:'Werkzeug ausgeben',returnTool:'Werkzeug zurücknehmen',
transferTool:'An anderen Mitarbeiter übergeben',chooseOtherWorker:'Bitte anderen Mitarbeiter auswählen',signatureSkipped:'Unterschrift übersprungen',actionSaved:'Aktion gespeichert',
set:'Lieferumfang',pdfFullHistory:'PDF — vollständige Historie',importDone:'Import abgeschlossen',newWorkers:'Neue Mitarbeiter',newTools:'Neue Werkzeuge',newEvents:'Neue Aktionen',updated:'Aktualisiert',
merged:'Datenbanken zusammengeführt',importFail:'Sicherung konnte nicht gelesen werden'
},
ru:{
tools:'Инструменты',heroSub:'Быстрая выдача, возврат и полная история.',issue:'Выдать',return:'Принять',transfer:'Передать',
recentActions:'Последние действия',workers:'Работники',workersSub:'Кому и что сейчас выдано',add:'+ Добавить',toolsSub:'Свободные, выданные, сломанные и в ремонте',
searchTool:'Поиск инструмента…',history:'История',historySub:'Все выдачи, возвраты и передачи',backup:'Обмен и резервная копия',backupSub:'Объединение данных между телефонами',
createBackup:'Создать копию',backupDesc:'Сохраняет работников, инструменты, историю, фотографии и подписи.',createShareFile:'Создать файл для отправки',
importMerge:'Импортировать и объединить',mergeDesc:'Новые данные добавятся, существующие не будут дублироваться.',chooseFile:'Выбрать файл',home:'Главная',exchange:'Обмен',
totalTools:'Всего инструментов',issuedNow:'Сейчас выдано',available:'Свободно',brokenRepair:'Сломано / ремонт',noneWorkers:'Работников пока нет.',currentlyHas:'Сейчас у работника',
noneTools:'Инструменты пока не добавлены.',noNumber:'Без номера',atWorker:'у',open:'Открыть',statusBroken:'Сломан',statusRepair:'В ремонте',statusIssued:'Выдан',statusFree:'Свободен',
evIssue:'Выдан',evReturn:'Возвращён',evTransfer:'Передан',completeOk:'Комплектность подтверждена',completeBad:'Комплект неполный',missingProblem:'Не хватает / проблема',
comment:'Комментарий',signatureSaved:'Подпись работника сохранена',noneHistory:'История пока пустая.',noneActions:'Действий пока нет.',
newWorker:'Новый работник',fullName:'Имя и фамилия',nameExample:'Например, Михаил Мустерман',save:'Сохранить',enterName:'Введите имя',workerAdded:'Работник добавлен',
newTool:'Новый инструмент',name:'Название',toolExample:'Bosch Перфоратор',inventoryNo:'Инвентарный номер',setIssue:'Комплект при выдаче',setExample:'Кейс, зарядка, аккумулятор',
toolPhotos:'Фотографии инструмента',camera:'Камера',gallery:'Галерея',saveTool:'Сохранить инструмент',enterToolName:'Введите название',toolAdded:'Инструмент добавлен',
locUnavailable:'Недоступно',locUnknown:'Не определено',addWorkerFirst:'Сначала добавьте работника',addToolFirst:'Сначала добавьте инструмент',
noFreeTools:'Нет свободных инструментов',noIssuedTools:'Нет выданных инструментов',giveTo:'Кому выдать',transferTo:'Передать кому',tool:'Инструмент',
returnedComplete:'Вернул полностью как получил',leaveChecked:'Если всё на месте — оставьте галочку',whatMissing:'Чего не хватает / что не так',missingExample:'Например: нет зарядки',
condition:'Состояние',condOk:'Нормальное',condDamaged:'Повреждено',condBroken:'Сломано',photos:'Фотографии',commentOptional:'Комментарий (необязательно)',commentPlaceholder:'Любой комментарий…',
signatureOptional:'Подпись работника (необязательно)',clear:'Очистить',withoutSignature:'Без подписи',okSave:'OK — сохранить',issueTool:'Выдать инструмент',returnTool:'Принять обратно',
transferTool:'Передать другому',chooseOtherWorker:'Выберите другого работника',signatureSkipped:'Подпись пропущена',actionSaved:'Действие сохранено',
set:'Комплект',pdfFullHistory:'PDF — вся история',importDone:'Импорт завершён',newWorkers:'Новые работники',newTools:'Новые инструменты',newEvents:'Новые события',updated:'Обновлено',
merged:'Базы объединены',importFail:'Не удалось прочитать копию'
},
ro:{
tools:'Unelte',heroSub:'Predare, returnare și istoric complet, rapid.',issue:'Predă',return:'Primește',transfer:'Transferă',
recentActions:'Ultimele acțiuni',workers:'Angajați',workersSub:'Cine are acum fiecare unealtă',add:'+ Adaugă',toolsSub:'Libere, predate, defecte sau în reparație',
searchTool:'Caută unealta…',history:'Istoric',historySub:'Toate predările, returnările și transferurile',backup:'Schimb & copie de rezervă',backupSub:'Combinarea datelor între mai multe telefoane',
createBackup:'Creează copie',backupDesc:'Salvează angajați, unelte, istoric, fotografii și semnături.',createShareFile:'Creează fișier pentru trimitere',
importMerge:'Importă și combină',mergeDesc:'Datele noi se adaugă, cele existente nu se dublează.',chooseFile:'Alege fișier',home:'Acasă',exchange:'Schimb',
totalTools:'Total unelte',issuedNow:'Predate acum',available:'Libere',brokenRepair:'Defecte / reparație',noneWorkers:'Nu există încă angajați.',currentlyHas:'Acum la angajat',
noneTools:'Nu există încă unelte.',noNumber:'Fără număr',atWorker:'la',open:'Deschide',statusBroken:'Defectă',statusRepair:'În reparație',statusIssued:'Predată',statusFree:'Liberă',
evIssue:'Predată',evReturn:'Returnată',evTransfer:'Transferată',completeOk:'Completitudinea confirmată',completeBad:'Set incomplet',missingProblem:'Lipsește / problemă',
comment:'Comentariu',signatureSaved:'Semnătura angajatului salvată',noneHistory:'Istoricul este gol.',noneActions:'Nu există încă acțiuni.',
newWorker:'Angajat nou',fullName:'Nume și prenume',nameExample:'De ex. Mihai Mustermann',save:'Salvează',enterName:'Introduceți numele',workerAdded:'Angajat adăugat',
newTool:'Unealtă nouă',name:'Denumire',toolExample:'Bosch ciocan rotopercutor',inventoryNo:'Număr inventar',setIssue:'Set la predare',setExample:'Cutie, încărcător, acumulator',
toolPhotos:'Fotografii unealtă',camera:'Cameră',gallery:'Galerie',saveTool:'Salvează unealta',enterToolName:'Introduceți denumirea',toolAdded:'Unealtă adăugată',
locUnavailable:'Indisponibil',locUnknown:'Nedeterminat',addWorkerFirst:'Adăugați mai întâi un angajat',addToolFirst:'Adăugați mai întâi o unealtă',
noFreeTools:'Nu există unelte libere',noIssuedTools:'Nu există unelte predate',giveTo:'Predă către',transferTo:'Transferă către',tool:'Unealtă',
returnedComplete:'Returnat complet, exact cum a fost predat',leaveChecked:'Dacă totul este complet, lăsați bifa',whatMissing:'Ce lipsește / ce nu este în regulă',missingExample:'De ex. lipsește încărcătorul',
condition:'Stare',condOk:'Bună',condDamaged:'Deteriorată',condBroken:'Defectă',photos:'Fotografii',commentOptional:'Comentariu (opțional)',commentPlaceholder:'Orice comentariu…',
signatureOptional:'Semnătura angajatului (opțional)',clear:'Șterge',withoutSignature:'Fără semnătură',okSave:'OK — salvează',issueTool:'Predă unealta',returnTool:'Primește înapoi',
transferTool:'Transferă altui angajat',chooseOtherWorker:'Alegeți alt angajat',signatureSkipped:'Semnătura a fost omisă',actionSaved:'Acțiune salvată',
set:'Set',pdfFullHistory:'PDF — istoric complet',importDone:'Import finalizat',newWorkers:'Angajați noi',newTools:'Unelte noi',newEvents:'Acțiuni noi',updated:'Actualizate',
merged:'Bazele de date au fost combinate',importFail:'Copia nu a putut fi citită'
}};
const t=k=>I[lang]?.[k]||I.de[k]||k;
const uid=()=>crypto.randomUUID?crypto.randomUUID():'id-'+Date.now()+'-'+Math.random().toString(36).slice(2);
const now=()=>new Date().toISOString();
function locale(){return lang==='ru'?'ru-RU':lang==='ro'?'ro-RO':'de-DE'}
function fmt(d){return new Date(d).toLocaleString(locale(),{dateStyle:'short',timeStyle:'short'})}
function esc(s=''){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function applyLanguage(){
 document.documentElement.lang=lang; $('#langSelect').value=lang;
 $$('[data-i18n]').forEach(el=>el.textContent=t(el.dataset.i18n));
 $$('[data-i18n-placeholder]').forEach(el=>el.placeholder=t(el.dataset.i18nPlaceholder));
 renderAll();
}
$('#langSelect').addEventListener('change',e=>{lang=e.target.value;localStorage.setItem(LANGKEY,lang);applyLanguage()});
function load(){try{db=JSON.parse(localStorage.getItem(DBKEY))||db}catch(e){} applyLanguage()}
function save(){localStorage.setItem(DBKEY,JSON.stringify(db));renderAll()}
function toast(x){let el=$('#toast');el.textContent=x;el.style.display='block';setTimeout(()=>el.style.display='none',2200)}
function page(name){$$('.page').forEach(p=>p.classList.toggle('active',p.dataset.page===name));$$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.pageGo===name));window.scrollTo(0,0)}
function openModal(html){$('#sheet').innerHTML=html;$('#modal').classList.add('open')}
function closeModal(){$('#modal').classList.remove('open')}
$('#modal').addEventListener('click',e=>{if(e.target===$('#modal'))closeModal()});
document.addEventListener('click',e=>{let p=e.target.closest('[data-page-go]');if(p)page(p.dataset.pageGo);let a=e.target.closest('[data-act]');if(a)actionModal(a.dataset.act)});
$('#quickAction').onclick=()=>actionModal('issue');

function toolStatus(x){if(x.status==='broken')return [t('statusBroken'),'red'];if(x.status==='repair')return [t('statusRepair'),'amber'];if(x.holderId)return [t('statusIssued'),'amber'];return [t('statusFree'),'green']}
function workerName(id){return db.workers.find(x=>x.id===id)?.name||'—'}
function toolName(id){return db.tools.find(x=>x.id===id)?.name||'—'}
function renderAll(){
 let issued=db.tools.filter(x=>x.holderId).length, broken=db.tools.filter(x=>x.status==='broken'||x.status==='repair').length;
 $('#stats').innerHTML=`<div class=stat><b>${db.tools.length}</b><span>${t('totalTools')}</span></div><div class=stat><b>${issued}</b><span>${t('issuedNow')}</span></div><div class=stat><b>${Math.max(0,db.tools.length-issued-broken)}</b><span>${t('available')}</span></div><div class=stat><b>${broken}</b><span>${t('brokenRepair')}</span></div>`;
 renderWorkers();renderTools();renderHistory();renderRecent();
}
function renderWorkers(){let el=$('#workersList');if(!db.workers.length){el.innerHTML=`<div class="card pad muted">${t('noneWorkers')}</div>`;return}
 el.innerHTML=db.workers.map(w=>{let ts=db.tools.filter(x=>x.holderId===w.id);return `<div class="card row"><div class=thumb>👷</div><div class=grow><div class=name>${esc(w.name)}</div><div class=meta>${t('currentlyHas')}: ${ts.length}</div>${ts.length?`<div class=meta>${ts.map(x=>esc(x.name)).join(' • ')}</div>`:''}</div><button class=smallbtn onclick="workerHistory('${w.id}')">${t('history')}</button></div>`}).join('');
}
function renderTools(){let q=($('#toolSearch')?.value||'').toLowerCase();let arr=db.tools.filter(x=>x.name.toLowerCase().includes(q)||String(x.number||'').toLowerCase().includes(q));let el=$('#toolsList');if(!arr.length){el.innerHTML=`<div class="card pad muted">${t('noneTools')}</div>`;return}
 el.innerHTML=arr.map(x=>{let [s,c]=toolStatus(x),pic=x.photos?.[0];return `<div class="card row"><div class=thumb>${pic?`<img src="${pic}" style="width:100%;height:100%;object-fit:cover;border-radius:13px">`:'🧰'}</div><div class=grow><div class=name>${esc(x.name)}</div><div class=meta>${esc(x.number||t('noNumber'))}${x.holderId?' • '+t('atWorker')+' '+esc(workerName(x.holderId)):''}</div><span class="badge ${c}">${s}</span></div><button class=smallbtn onclick="toolDetails('${x.id}')">${t('open')}</button></div>`}).join('');
}
$('#toolSearch').addEventListener('input',renderTools);
function eventTitle(type){return type==='issue'?t('evIssue'):type==='return'?t('evReturn'):type==='transfer'?t('evTransfer'):type}
function eventCard(e){let good=e.complete===true?'good':e.complete===false?'bad':'', title=eventTitle(e.type);return `<div class="card pad event ${good}"><div class=name>${title}: ${esc(toolName(e.toolId))}</div><div class=meta>${fmt(e.createdAt)} • ${esc(workerName(e.workerId))}${e.toWorkerId?' → '+esc(workerName(e.toWorkerId)):''}</div>${e.location?`<div class=meta>📍 ${esc(e.location)}</div>`:''}${e.complete===true?`<span class="badge green">${t('completeOk')}</span>`:e.complete===false?`<span class="badge red">${t('completeBad')}</span>`:''}${e.missing?`<div class=meta>${t('missingProblem')}: ${esc(e.missing)}</div>`:''}${e.comment?`<div class=meta>${t('comment')}: ${esc(e.comment)}</div>`:''}${e.photos?.length?`<div class=photos>${e.photos.map(p=>`<img src="${p}">`).join('')}</div>`:''}${e.signature?`<div class=meta>✍ ${t('signatureSaved')}</div>`:''}</div>`}
function renderHistory(){let arr=[...db.events].sort((a,b)=>b.createdAt.localeCompare(a.createdAt));$('#historyList').innerHTML=arr.length?arr.map(eventCard).join(''):`<div class="card pad muted">${t('noneHistory')}</div>`}
function renderRecent(){let arr=[...db.events].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,5);$('#recent').innerHTML=arr.length?arr.map(eventCard).join(''):`<div class="card pad muted">${t('noneActions')}</div>`}

$('#addWorker').onclick=()=>openModal(`<div class=sheethead><h3>${t('newWorker')}</h3><button class=close onclick="closeModal()">×</button></div><div class=field><label>${t('fullName')}</label><input class=input id=wname placeholder="${t('nameExample')}"></div><button class="wide primary" onclick="addWorkerNow()">${t('save')}</button>`);
function addWorkerNow(){let name=$('#wname').value.trim();if(!name)return toast(t('enterName'));db.workers.push({id:uid(),name,createdAt:now(),updatedAt:now()});save();closeModal();toast(t('workerAdded'))}

$('#addTool').onclick=()=>toolModal();
function toolModal(){openModal(`<div class=sheethead><h3>${t('newTool')}</h3><button class=close onclick="closeModal()">×</button></div><div class=field><label>${t('name')}</label><input class=input id=tname placeholder="${t('toolExample')}"></div><div class=field><label>${t('inventoryNo')}</label><input class=input id=tnum placeholder="WZ-0001"></div><div class=field><label>${t('setIssue')}</label><input class=input id=tacc placeholder="${t('setExample')}"></div><div class=field><label>${t('toolPhotos')}</label><div id=toolPhotos class=photo-grid></div><div class=photo-actions><button class=wide onclick="$('#toolCamera').click()">📷 ${t('camera')}</button><button class=wide onclick="$('#toolGallery').click()">🖼 ${t('gallery')}</button></div><input id=toolCamera type=file accept="image/*" capture="environment" hidden><input id=toolGallery type=file accept="image/*" multiple hidden></div><button class="wide primary" onclick="addToolNow()">${t('saveTool')}</button>`);
 window.tmpToolPhotos=[];bindPhotoInputs('toolCamera','toolGallery','toolPhotos','tmpToolPhotos')
}
function addToolNow(){let name=$('#tname').value.trim();if(!name)return toast(t('enterToolName'));db.tools.push({id:uid(),name,number:$('#tnum').value.trim(),accessories:$('#tacc').value.split(',').map(x=>x.trim()).filter(Boolean),photos:window.tmpToolPhotos||[],status:'available',holderId:null,createdAt:now(),updatedAt:now()});save();closeModal();toast(t('toolAdded'))}
function readImgs(files,target,renderId){[...files].forEach(f=>{let r=new FileReader();r.onload=()=>{window[target].push(r.result);renderPhotoTmp(renderId,target)};r.readAsDataURL(f)})}
function bindPhotoInputs(cam,gal,renderId,target){$('#'+cam).onchange=e=>readImgs(e.target.files,target,renderId);$('#'+gal).onchange=e=>readImgs(e.target.files,target,renderId)}
function renderPhotoTmp(renderId,target){$('#'+renderId).innerHTML=(window[target]||[]).map((p,i)=>`<div class=photo><img src="${p}"><button onclick="removeTmpPhoto('${target}',${i},'${renderId}')">×</button></div>`).join('')}
function removeTmpPhoto(target,i,renderId){window[target].splice(i,1);renderPhotoTmp(renderId,target)}

async function getLocation(){return new Promise(res=>{if(!navigator.geolocation)return res(t('locUnavailable'));navigator.geolocation.getCurrentPosition(p=>res(`${p.coords.latitude.toFixed(6)}, ${p.coords.longitude.toFixed(6)}`),()=>res(t('locUnknown')),{enableHighAccuracy:true,timeout:5000})})}
function opts(arr,sel=''){return arr.map(x=>`<option value="${x.id}" ${x.id===sel?'selected':''}>${esc(x.name)}</option>`).join('')}
function actionModal(type){
 if(!db.workers.length)return toast(t('addWorkerFirst')); if(!db.tools.length)return toast(t('addToolFirst'));
 let available=db.tools.filter(x=>!x.holderId&&x.status!=='broken'&&x.status!=='repair'), issued=db.tools.filter(x=>x.holderId), list=type==='issue'?available:issued;
 if(!list.length)return toast(type==='issue'?t('noFreeTools'):t('noIssuedTools'));
 let workerField=type==='issue'?`<div class=field><label>${t('giveTo')}</label><select id=worker>${opts(db.workers)}</select></div>`:'';
 let toField=type==='transfer'?`<div class=field><label>${t('transferTo')}</label><select id=toWorker>${opts(db.workers)}</select></div>`:'';
 let comp=type==='return'?`<div class=field><label class=checkline><input type=checkbox id=complete checked onchange="toggleMissing()"><span><b>${t('returnedComplete')}</b><br><span class=meta>${t('leaveChecked')}</span></span></label></div><div class=field id=missingWrap style="display:none"><label>${t('whatMissing')}</label><textarea id=missing rows=2 placeholder="${t('missingExample')}"></textarea></div><div class=field><label>${t('condition')}</label><select id=condition><option value=ok>${t('condOk')}</option><option value=damaged>${t('condDamaged')}</option><option value=broken>${t('condBroken')}</option></select></div>`:'';
 let ttl=type==='issue'?t('issueTool'):type==='return'?t('returnTool'):t('transferTool');
 openModal(`<div class=sheethead><h3>${ttl}</h3><button class=close onclick="closeModal()">×</button></div><div class=field><label>${t('tool')}</label><select id=toolSel onchange="syncActionWorker('${type}')">${list.map(x=>`<option value="${x.id}">${esc(x.name)}${x.holderId?' — '+esc(workerName(x.holderId)):''}</option>`).join('')}</select></div>${workerField}${toField}${comp}<div class=field><label>${t('photos')}</label><div id=actionPhotos class=photo-grid></div><div class=photo-actions><button class=wide onclick="$('#actionCamera').click()">📷 ${t('camera')}</button><button class=wide onclick="$('#actionGallery').click()">🖼 ${t('gallery')}</button></div><input id=actionCamera type=file accept="image/*" capture="environment" hidden><input id=actionGallery type=file accept="image/*" multiple hidden></div><div class=field><label>${t('commentOptional')}</label><textarea id=comment rows=2 placeholder="${t('commentPlaceholder')}"></textarea></div><div class=field><label>${t('signatureOptional')}</label><canvas id=sig class=signature></canvas><div class=photo-actions><button class=wide onclick="clearSig()">${t('clear')}</button><button class=wide onclick="skipSig()">${t('withoutSignature')}</button></div></div><button class="wide primary" onclick="saveAction('${type}')">${t('okSave')}</button>`);
 window.tmpActionPhotos=[];window.signatureSkipped=false;bindPhotoInputs('actionCamera','actionGallery','actionPhotos','tmpActionPhotos');initSignature();syncActionWorker(type)
}
function toggleMissing(){$('#missingWrap').style.display=$('#complete').checked?'none':'block'}
function syncActionWorker(type){let x=db.tools.find(v=>v.id===$('#toolSel').value);if(type==='transfer'&&x){[...$('#toWorker').options].forEach(o=>o.disabled=o.value===x.holderId)}}
function initSignature(){let c=$('#sig'),ctx=c.getContext('2d');c.width=c.clientWidth*devicePixelRatio;c.height=c.clientHeight*devicePixelRatio;ctx.scale(devicePixelRatio,devicePixelRatio);ctx.lineWidth=2;ctx.lineCap='round';ctx.strokeStyle='#111';let draw=false,last=null;const pt=e=>{let r=c.getBoundingClientRect();return [e.clientX-r.left,e.clientY-r.top]};c.onpointerdown=e=>{draw=true;last=pt(e);c.setPointerCapture?.(e.pointerId)};c.onpointermove=e=>{if(!draw)return;let p=pt(e);ctx.beginPath();ctx.moveTo(...last);ctx.lineTo(...p);ctx.stroke();last=p;window.signatureSkipped=false};c.onpointerup=()=>draw=false;c.onpointerleave=()=>draw=false}
function clearSig(){let c=$('#sig');c.getContext('2d').clearRect(0,0,c.width,c.height);window.signatureSkipped=false}
function skipSig(){clearSig();window.signatureSkipped=true;toast(t('signatureSkipped'))}
function signatureData(){let c=$('#sig');try{return window.signatureSkipped?null:c.toDataURL('image/png')}catch(e){return null}}
async function saveAction(type){let x=db.tools.find(v=>v.id===$('#toolSel').value);if(!x)return;let workerId=type==='issue'?$('#worker').value:x.holderId,toWorkerId=type==='transfer'?$('#toWorker').value:null;if(type==='transfer'&&toWorkerId===workerId)return toast(t('chooseOtherWorker'));let complete=type==='return'?$('#complete').checked:null,condition=type==='return'?$('#condition').value:null,location=await getLocation();let e={id:uid(),type,toolId:x.id,workerId,toWorkerId,complete,missing:type==='return'&&!complete?$('#missing').value.trim():'',condition,comment:$('#comment').value.trim(),photos:window.tmpActionPhotos||[],signature:signatureData(),location,createdAt:now(),updatedAt:now()};db.events.push(e);if(type==='issue')x.holderId=workerId;if(type==='return'){x.holderId=null;if(condition==='broken')x.status='broken';else if(x.status!=='repair')x.status='available'}if(type==='transfer')x.holderId=toWorkerId;x.updatedAt=now();save();closeModal();toast(t('actionSaved'))}

function toolDetails(id){let x=db.tools.find(v=>v.id===id),ev=db.events.filter(e=>e.toolId===id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)),[s,c]=toolStatus(x);openModal(`<div class=sheethead><h3>${esc(x.name)}</h3><button class=close onclick="closeModal()">×</button></div><div class=meta>${esc(x.number||t('noNumber'))}</div><p><span class="badge ${c}">${s}</span></p>${x.accessories?.length?`<div class=field><label>${t('set')}</label><div>${x.accessories.map(esc).join(' • ')}</div></div>`:''}${x.photos?.length?`<div class=photo-grid>${x.photos.map(p=>`<div class=photo><img src="${p}"></div>`).join('')}</div>`:''}<div class=sep></div><button class=wide onclick="printFiltered('tool','${x.id}')">${t('pdfFullHistory')}</button><div class=section-title>${t('history')}</div>${ev.length?ev.map(eventCard).join(''):`<div class=muted>${t('noneHistory')}</div>`}`)}
function workerHistory(id){let w=db.workers.find(x=>x.id===id),ev=db.events.filter(e=>e.workerId===id||e.toWorkerId===id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));openModal(`<div class=sheethead><h3>${esc(w.name)}</h3><button class=close onclick="closeModal()">×</button></div><button class=wide onclick="printFiltered('worker','${w.id}')">${t('pdfFullHistory')}</button><div class=section-title>${t('history')}</div>${ev.length?ev.map(eventCard).join(''):`<div class=muted>${t('noneHistory')}</div>`}`)}
$('#printHistory').onclick=()=>window.print();
function printFiltered(kind,id){let original=$('#historyList').innerHTML,arr=db.events.filter(e=>kind==='tool'?e.toolId===id:(e.workerId===id||e.toWorkerId===id)).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));$('#historyList').innerHTML=arr.map(eventCard).join('');closeModal();page('history');setTimeout(()=>{window.print();$('#historyList').innerHTML=original},250)}

$('#exportBackup').onclick=async()=>{let payload={format:'GEMOTOOLS-1',exportedAt:now(),db};let blob=new Blob([JSON.stringify(payload)],{type:'application/json'});let file=new File([blob],`Gemo_Werkzeuge_${new Date().toISOString().slice(0,10)}.gemotools`,{type:'application/json'});if(navigator.share&&navigator.canShare?.({files:[file]})){try{await navigator.share({files:[file],title:'Gemo Werkzeuge'});return}catch(e){}}let a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=file.name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};
$('#importBackupBtn').onclick=()=>$('#importBackup').click();
$('#importBackup').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let p=JSON.parse(r.result),incoming=p.db||p;if(!incoming.workers||!incoming.tools||!incoming.events)throw 0;let rep={workers:0,tools:0,events:0,updated:0};['workers','tools','events'].forEach(k=>{incoming[k].forEach(n=>{let i=db[k].findIndex(x=>x.id===n.id);if(i<0){db[k].push(n);rep[k]++}else if((n.updatedAt||n.createdAt)>(db[k][i].updatedAt||db[k][i].createdAt)){db[k][i]=n;rep.updated++}})});save();$('#importReport').innerHTML=`<div class="card pad" style="margin-top:12px"><b>${t('importDone')}</b><div class=meta>${t('newWorkers')}: ${rep.workers}<br>${t('newTools')}: ${rep.tools}<br>${t('newEvents')}: ${rep.events}<br>${t('updated')}: ${rep.updated}</div></div>`;toast(t('merged'))}catch(err){toast(t('importFail'))};};r.readAsText(f);e.target.value=''};

/* ===== CRUD extension: open / edit / delete for all created records ===== */
Object.assign(I.de,{
 edit:'Bearbeiten',delete:'Löschen',cancel:'Abbrechen',confirmDelete:'Wirklich löschen?',workerDetails:'Mitarbeiter',
 toolDetailsLabel:'Werkzeug',eventDetails:'Aktion',editWorker:'Mitarbeiter bearbeiten',editTool:'Werkzeug bearbeiten',
 editEvent:'Aktion bearbeiten',deleted:'Gelöscht',updatedOk:'Gespeichert',deleteWorkerWarn:'Dieser Mitarbeiter hat aktuell Werkzeuge. Beim Löschen werden sie als frei markiert.',
 deleteToolWarn:'Dieses Werkzeug ist aktuell ausgegeben. Die Historie bleibt erhalten.',deleteEventWarn:'Diese Aktion wird aus der Historie entfernt.',
 noWorker:'Gelöschter Mitarbeiter',noTool:'Gelöschtes Werkzeug',open:'Öffnen',saveChanges:'Änderungen speichern'
});
Object.assign(I.ru,{
 edit:'Редактировать',delete:'Удалить',cancel:'Отмена',confirmDelete:'Точно удалить?',workerDetails:'Работник',
 toolDetailsLabel:'Инструмент',eventDetails:'Действие',editWorker:'Редактировать работника',editTool:'Редактировать инструмент',
 editEvent:'Редактировать действие',deleted:'Удалено',updatedOk:'Сохранено',deleteWorkerWarn:'У этого работника сейчас есть инструменты. При удалении они будут отмечены как свободные.',
 deleteToolWarn:'Этот инструмент сейчас выдан. История останется сохранённой.',deleteEventWarn:'Это действие будет удалено из истории.',
 noWorker:'Удалённый работник',noTool:'Удалённый инструмент',open:'Открыть',saveChanges:'Сохранить изменения'
});
Object.assign(I.ro,{
 edit:'Editează',delete:'Șterge',cancel:'Anulează',confirmDelete:'Sigur doriți să ștergeți?',workerDetails:'Angajat',
 toolDetailsLabel:'Unealtă',eventDetails:'Acțiune',editWorker:'Editează angajatul',editTool:'Editează unealta',
 editEvent:'Editează acțiunea',deleted:'Șters',updatedOk:'Salvat',deleteWorkerWarn:'Acest angajat are unelte în prezent. La ștergere, ele vor fi marcate ca libere.',
 deleteToolWarn:'Această unealtă este predată acum. Istoricul va rămâne păstrat.',deleteEventWarn:'Această acțiune va fi ștearsă din istoric.',
 noWorker:'Angajat șters',noTool:'Unealtă ștearsă',open:'Deschide',saveChanges:'Salvează modificările'
});

function workerName(id,e=null){
  return db.workers.find(x=>x.id===id)?.name || e?.workerNameSnapshot || e?.toWorkerNameSnapshot || t('noWorker');
}
function toolName(id,e=null){
  return db.tools.find(x=>x.id===id)?.name || e?.toolNameSnapshot || t('noTool');
}

function renderWorkers(){
 let el=$('#workersList');
 if(!db.workers.length){el.innerHTML=`<div class="card pad muted">${t('noneWorkers')}</div>`;return}
 el.innerHTML=db.workers.map(w=>{
   let ts=db.tools.filter(x=>x.holderId===w.id);
   return `<div class="card row"><div class=thumb>👷</div><div class=grow><div class=name>${esc(w.name)}</div><div class=meta>${t('currentlyHas')}: ${ts.length}</div>${ts.length?`<div class=meta>${ts.map(x=>esc(x.name)).join(' • ')}</div>`:''}</div><button class=smallbtn onclick="workerDetails('${w.id}')">${t('open')}</button></div>`;
 }).join('');
}

function renderTools(){
 let q=($('#toolSearch')?.value||'').toLowerCase();
 let arr=db.tools.filter(x=>x.name.toLowerCase().includes(q)||String(x.number||'').toLowerCase().includes(q));
 let el=$('#toolsList');
 if(!arr.length){el.innerHTML=`<div class="card pad muted">${t('noneTools')}</div>`;return}
 el.innerHTML=arr.map(x=>{
   let [s,c]=toolStatus(x),pic=x.photos?.[0];
   return `<div class="card row"><div class=thumb>${pic?`<img src="${pic}" style="width:100%;height:100%;object-fit:cover;border-radius:13px">`:'🧰'}</div><div class=grow><div class=name>${esc(x.name)}</div><div class=meta>${esc(x.number||t('noNumber'))}${x.holderId?' • '+t('atWorker')+' '+esc(workerName(x.holderId)):''}</div><span class="badge ${c}">${s}</span></div><button class=smallbtn onclick="toolDetails('${x.id}')">${t('open')}</button></div>`;
 }).join('');
}

function eventCard(e){
 let good=e.complete===true?'good':e.complete===false?'bad':'', title=eventTitle(e.type);
 let wname=db.workers.find(x=>x.id===e.workerId)?.name || e.workerNameSnapshot || t('noWorker');
 let toname=e.toWorkerId?(db.workers.find(x=>x.id===e.toWorkerId)?.name || e.toWorkerNameSnapshot || t('noWorker')):'';
 let tn=db.tools.find(x=>x.id===e.toolId)?.name || e.toolNameSnapshot || t('noTool');
 return `<div class="card pad event ${good}"><div class=name>${title}: ${esc(tn)}</div><div class=meta>${fmt(e.createdAt)} • ${esc(wname)}${e.toWorkerId?' → '+esc(toname):''}</div>${e.location?`<div class=meta>📍 ${esc(e.location)}</div>`:''}${e.complete===true?`<span class="badge green">${t('completeOk')}</span>`:e.complete===false?`<span class="badge red">${t('completeBad')}</span>`:''}${e.missing?`<div class=meta>${t('missingProblem')}: ${esc(e.missing)}</div>`:''}${e.comment?`<div class=meta>${t('comment')}: ${esc(e.comment)}</div>`:''}${e.photos?.length?`<div class=photos>${e.photos.map(p=>`<img src="${p}">`).join('')}</div>`:''}${e.signature?`<div class=meta>✍ ${t('signatureSaved')}</div>`:''}<button class=smallbtn style="margin-top:10px" onclick="eventDetails('${e.id}')">${t('open')}</button></div>`;
}

function workerDetails(id){
 let w=db.workers.find(x=>x.id===id); if(!w)return;
 let ev=db.events.filter(e=>e.workerId===id||e.toWorkerId===id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
 let ts=db.tools.filter(x=>x.holderId===id);
 openModal(`<div class=sheethead><h3>${esc(w.name)}</h3><button class=close onclick="closeModal()">×</button></div>
 ${ts.length?`<div class="card pad"><div class=meta>${t('currentlyHas')}</div><div>${ts.map(x=>esc(x.name)).join(' • ')}</div></div>`:''}
 <div class=photo-actions><button class=wide onclick="editWorker('${id}')">✏️ ${t('edit')}</button><button class="wide danger" onclick="deleteWorker('${id}')">🗑 ${t('delete')}</button></div>
 <button class=wide onclick="printFiltered('worker','${id}')">${t('pdfFullHistory')}</button>
 <div class=section-title>${t('history')}</div>${ev.length?ev.map(eventCard).join(''):`<div class=muted>${t('noneHistory')}</div>`}`);
}
function workerHistory(id){workerDetails(id)}

function editWorker(id){
 let w=db.workers.find(x=>x.id===id); if(!w)return;
 openModal(`<div class=sheethead><h3>${t('editWorker')}</h3><button class=close onclick="closeModal()">×</button></div>
 <div class=field><label>${t('fullName')}</label><input class=input id=editWName value="${esc(w.name)}"></div>
 <button class="wide primary" onclick="saveWorkerEdit('${id}')">${t('saveChanges')}</button>`);
}
function saveWorkerEdit(id){
 let w=db.workers.find(x=>x.id===id),name=$('#editWName').value.trim(); if(!w||!name)return toast(t('enterName'));
 w.name=name;w.updatedAt=now();save();closeModal();toast(t('updatedOk'));
}
function deleteWorker(id){
 let w=db.workers.find(x=>x.id===id); if(!w)return;
 let held=db.tools.filter(x=>x.holderId===id);
 let msg=t('confirmDelete')+(held.length?'\n\n'+t('deleteWorkerWarn'):'');
 if(!confirm(msg))return;
 db.events.forEach(e=>{
   if(e.workerId===id&&!e.workerNameSnapshot)e.workerNameSnapshot=w.name;
   if(e.toWorkerId===id&&!e.toWorkerNameSnapshot)e.toWorkerNameSnapshot=w.name;
 });
 held.forEach(x=>{x.holderId=null;x.updatedAt=now()});
 db.workers=db.workers.filter(x=>x.id!==id);
 save();closeModal();toast(t('deleted'));
}

function toolDetails(id){
 let x=db.tools.find(v=>v.id===id);if(!x)return;
 let ev=db.events.filter(e=>e.toolId===id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)),[s,c]=toolStatus(x);
 openModal(`<div class=sheethead><h3>${esc(x.name)}</h3><button class=close onclick="closeModal()">×</button></div>
 <div class=meta>${esc(x.number||t('noNumber'))}</div><p><span class="badge ${c}">${s}</span></p>
 ${x.accessories?.length?`<div class=field><label>${t('set')}</label><div>${x.accessories.map(esc).join(' • ')}</div></div>`:''}
 ${x.photos?.length?`<div class=photo-grid>${x.photos.map(p=>`<div class=photo><img src="${p}"></div>`).join('')}</div>`:''}
 <div class=photo-actions><button class=wide onclick="editTool('${id}')">✏️ ${t('edit')}</button><button class="wide danger" onclick="deleteTool('${id}')">🗑 ${t('delete')}</button></div>
 <button class=wide onclick="printFiltered('tool','${id}')">${t('pdfFullHistory')}</button>
 <div class=section-title>${t('history')}</div>${ev.length?ev.map(eventCard).join(''):`<div class=muted>${t('noneHistory')}</div>`}`);
}
function editTool(id){
 let x=db.tools.find(v=>v.id===id);if(!x)return;
 window.tmpEditToolPhotos=[...(x.photos||[])];
 openModal(`<div class=sheethead><h3>${t('editTool')}</h3><button class=close onclick="closeModal()">×</button></div>
 <div class=field><label>${t('name')}</label><input class=input id=editTName value="${esc(x.name)}"></div>
 <div class=field><label>${t('inventoryNo')}</label><input class=input id=editTNum value="${esc(x.number||'')}"></div>
 <div class=field><label>${t('setIssue')}</label><input class=input id=editTAcc value="${esc((x.accessories||[]).join(', '))}"></div>
 <div class=field><label>${t('toolPhotos')}</label><div id=editToolPhotos class=photo-grid></div>
 <div class=photo-actions><button class=wide onclick="$('#editToolCamera').click()">📷 ${t('camera')}</button><button class=wide onclick="$('#editToolGallery').click()">🖼 ${t('gallery')}</button></div>
 <input id=editToolCamera type=file accept="image/*" capture="environment" hidden><input id=editToolGallery type=file accept="image/*" multiple hidden></div>
 <button class="wide primary" onclick="saveToolEdit('${id}')">${t('saveChanges')}</button>`);
 renderPhotoTmp('editToolPhotos','tmpEditToolPhotos');bindPhotoInputs('editToolCamera','editToolGallery','editToolPhotos','tmpEditToolPhotos');
}
function saveToolEdit(id){
 let x=db.tools.find(v=>v.id===id),name=$('#editTName').value.trim();if(!x||!name)return toast(t('enterToolName'));
 x.name=name;x.number=$('#editTNum').value.trim();x.accessories=$('#editTAcc').value.split(',').map(v=>v.trim()).filter(Boolean);x.photos=window.tmpEditToolPhotos||[];x.updatedAt=now();
 save();closeModal();toast(t('updatedOk'));
}
function deleteTool(id){
 let x=db.tools.find(v=>v.id===id);if(!x)return;
 let msg=t('confirmDelete')+(x.holderId?'\n\n'+t('deleteToolWarn'):'');
 if(!confirm(msg))return;
 db.events.forEach(e=>{if(e.toolId===id&&!e.toolNameSnapshot)e.toolNameSnapshot=x.name});
 db.tools=db.tools.filter(v=>v.id!==id);
 save();closeModal();toast(t('deleted'));
}

function eventDetails(id){
 let e=db.events.find(v=>v.id===id);if(!e)return;
 let tn=db.tools.find(x=>x.id===e.toolId)?.name || e.toolNameSnapshot || t('noTool');
 let wn=db.workers.find(x=>x.id===e.workerId)?.name || e.workerNameSnapshot || t('noWorker');
 openModal(`<div class=sheethead><h3>${t('eventDetails')}</h3><button class=close onclick="closeModal()">×</button></div>
 <div class="card pad"><div class=name>${eventTitle(e.type)}: ${esc(tn)}</div><div class=meta>${fmt(e.createdAt)} • ${esc(wn)}</div>${e.comment?`<div class=meta>${t('comment')}: ${esc(e.comment)}</div>`:''}</div>
 <div class=photo-actions><button class=wide onclick="editEvent('${id}')">✏️ ${t('edit')}</button><button class="wide danger" onclick="deleteEvent('${id}')">🗑 ${t('delete')}</button></div>`);
}
function editEvent(id){
 let e=db.events.find(v=>v.id===id);if(!e)return;
 window.tmpEditEventPhotos=[...(e.photos||[])];
 openModal(`<div class=sheethead><h3>${t('editEvent')}</h3><button class=close onclick="closeModal()">×</button></div>
 ${e.type==='return'?`<div class=field><label class=checkline><input type=checkbox id=editComplete ${e.complete?'checked':''} onchange="$('#editMissingWrap').style.display=this.checked?'none':'block'"><span><b>${t('returnedComplete')}</b></span></label></div>
 <div class=field id=editMissingWrap style="${e.complete?'display:none':''}"><label>${t('whatMissing')}</label><textarea id=editMissing rows=2>${esc(e.missing||'')}</textarea></div>
 <div class=field><label>${t('condition')}</label><select id=editCondition><option value=ok ${e.condition==='ok'?'selected':''}>${t('condOk')}</option><option value=damaged ${e.condition==='damaged'?'selected':''}>${t('condDamaged')}</option><option value=broken ${e.condition==='broken'?'selected':''}>${t('condBroken')}</option></select></div>`:''}
 <div class=field><label>${t('photos')}</label><div id=editEventPhotos class=photo-grid></div><div class=photo-actions><button class=wide onclick="$('#editEventCamera').click()">📷 ${t('camera')}</button><button class=wide onclick="$('#editEventGallery').click()">🖼 ${t('gallery')}</button></div><input id=editEventCamera type=file accept="image/*" capture="environment" hidden><input id=editEventGallery type=file accept="image/*" multiple hidden></div>
 <div class=field><label>${t('commentOptional')}</label><textarea id=editComment rows=3>${esc(e.comment||'')}</textarea></div>
 <button class="wide primary" onclick="saveEventEdit('${id}')">${t('saveChanges')}</button>`);
 renderPhotoTmp('editEventPhotos','tmpEditEventPhotos');bindPhotoInputs('editEventCamera','editEventGallery','editEventPhotos','tmpEditEventPhotos');
}
function saveEventEdit(id){
 let e=db.events.find(v=>v.id===id);if(!e)return;
 e.comment=$('#editComment').value.trim();e.photos=window.tmpEditEventPhotos||[];
 if(e.type==='return'){e.complete=$('#editComplete').checked;e.missing=e.complete?'':$('#editMissing').value.trim();e.condition=$('#editCondition').value;}
 e.updatedAt=now();save();closeModal();toast(t('updatedOk'));
}
function deleteEvent(id){
 let e=db.events.find(v=>v.id===id);if(!e)return;
 if(!confirm(t('confirmDelete')+'\n\n'+t('deleteEventWarn')))return;
 db.events=db.events.filter(v=>v.id!==id);save();closeModal();toast(t('deleted'));
}

load();
