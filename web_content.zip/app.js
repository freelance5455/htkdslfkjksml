(() => {
  'use strict';

  const standardFields = [
    { id: 'firstName', label: 'First Name', placeholder: 'Enter first name' },
    { id: 'surname', label: 'Surname', placeholder: 'Enter surname' },
    { id: 'dateOfBirth', label: 'Date of Birth', type: 'date' },
    { id: 'phoneNumber', label: 'Phone Number', placeholder: 'Enter phone number', inputmode: 'tel' },
    { id: 'districtId', label: 'District ID Number', placeholder: 'Enter district ID' },
    { id: 'receiptNumber', label: 'Receipt Number', placeholder: 'Enter receipt number' }
  ];
  const advancedFields = [
    { id: 'fatherName', label: "Father's Name", placeholder: "Enter father's name" },
    { id: 'motherName', label: "Mother's Name", placeholder: "Enter mother's name" },
    { id: 'parentId', label: 'Parent ID Number', placeholder: 'Enter parent ID' },
    { id: 'registrationLocation', label: 'Registration Location', placeholder: 'Enter registration location' },
    { id: 'registrationDate', label: 'Registration Date', type: 'date' }
  ];
  const sampleRecords = [
    { id: 'NRB-••••-2048', firstName: 'Amina', surname: 'Hassan', dob: '1989-04-17', phoneNumber: '+000 555 0101', districtId: 'D-04271', receiptNumber: 'R-804216', fatherName: 'Yusuf Hassan', motherName: 'Salma Hassan', parentId: 'P-31084', registrationLocation: 'Central District', registrationDate: '2011-06-21', status: 'Verified', token: 'VT-8F3A-21C9', updated: '2025-02-14 09:42' },
    { id: 'NRB-••••-7316', firstName: 'Daniel', surname: 'Okafor', dob: '1993-11-02', phoneNumber: '+000 555 0102', districtId: 'D-03108', receiptNumber: 'R-593028', fatherName: 'Chidi Okafor', motherName: 'Ngozi Okafor', parentId: 'P-42719', registrationLocation: 'North District', registrationDate: '2012-03-08', status: 'Verified', token: 'VT-2C7D-90B4', updated: '2025-02-13 16:08' },
    { id: 'NRB-••••-5902', firstName: 'Leila', surname: 'Mensah', dob: '1978-07-29', phoneNumber: '+000 555 0103', districtId: 'D-05842', receiptNumber: 'R-172406', fatherName: 'Kojo Mensah', motherName: 'Abena Mensah', parentId: 'P-19863', registrationLocation: 'West District', registrationDate: '2004-10-15', status: 'Pending', token: 'VT-5A1E-63D2', updated: '2025-02-12 11:26' }
  ];

  const fieldGrid = document.getElementById('fieldGrid');
  const advancedToggle = document.getElementById('advancedToggle');
  const searchButton = document.getElementById('searchButton');
  const recordsBody = document.getElementById('recordsBody');
  let advanced = false;
  let toastTimer;

  function renderFields() {
    fieldGrid.replaceChildren();
    for (const definition of advanced ? advancedFields : standardFields) {
      const wrapper = document.createElement('div');
      wrapper.className = 'field';
      const label = document.createElement('label');
      label.htmlFor = definition.id;
      label.textContent = definition.label;
      const input = document.createElement('input');
      input.id = definition.id;
      input.name = definition.id;
      input.type = definition.type || 'text';
      input.placeholder = definition.placeholder || '';
      input.autocomplete = 'off';
      if (definition.inputmode) input.inputMode = definition.inputmode;
      wrapper.append(label, input);
      fieldGrid.append(wrapper);
    }
  }

  function renderRecords(records) {
    recordsBody.replaceChildren();
    for (const record of records) {
      const row = document.createElement('tr');
      const personCell = document.createElement('td');
      const person = document.createElement('div');
      person.className = 'person';
      const avatar = document.createElement('span');
      avatar.className = 'avatar';
      avatar.textContent = `${record.firstName[0]}${record.surname[0]}`;
      const identity = document.createElement('span');
      const name = document.createElement('span');
      name.className = 'person-name';
      name.textContent = `${record.firstName} ${record.surname}`;
      const id = document.createElement('span');
      id.className = 'sub-id';
      id.textContent = record.id;
      identity.append(name, document.createElement('br'), id);
      person.append(avatar, identity);
      personCell.append(person);
      const cells = [personCell, document.createElement('td'), document.createElement('td'), document.createElement('td'), document.createElement('td'), document.createElement('td')];
      cells[1].textContent = formatDate(record.dob);
      cells[2].textContent = record.districtId;
      const status = document.createElement('span');
      status.className = 'status';
      status.textContent = record.status;
      cells[3].append(status);
      const token = document.createElement('span');
      token.className = 'token';
      token.textContent = record.token;
      cells[4].append(token);
      const updated = document.createElement('span');
      updated.className = 'record-time';
      updated.textContent = record.updated;
      cells[5].append(updated);
      row.append(...cells);
      recordsBody.append(row);
    }
  }

  function formatDate(value) {
    const date = new Date(`${value}T12:00:00`);
    return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat('en', { day: '2-digit', month: 'short', year: 'numeric' }).format(date);
  }

  function currentCriteria() {
    const definitions = [...standardFields, ...advancedFields];
    return Object.fromEntries(definitions.flatMap(({ id }) => {
      const input = document.getElementById(id);
      return input && input.value.trim() ? [[id, input.value.trim()]] : [];
    }));
  }

  function matches(record, criteria) {
    const searchable = {
      firstName: 'firstName', surname: 'surname', dateOfBirth: 'dob', phoneNumber: 'phoneNumber',
      districtId: 'districtId', receiptNumber: 'receiptNumber', fatherName: 'fatherName',
      motherName: 'motherName', parentId: 'parentId', registrationLocation: 'registrationLocation',
      registrationDate: 'registrationDate'
    };
    return Object.entries(criteria).every(([key, query]) =>
      String(record[searchable[key]] ?? '').toLocaleLowerCase().includes(query.toLocaleLowerCase()));
  }

  function notify(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
  }

  function renderEmptyState() {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 6;
    const message = document.createElement('div');
    message.className = 'empty-state';
    const title = document.createElement('strong');
    title.textContent = 'No matching sample records';
    message.append(title, document.createTextNode('Try different criteria. This demonstration index contains only illustrative entries.'));
    cell.append(message);
    row.append(cell);
    recordsBody.append(row);
  }

  advancedToggle.addEventListener('click', () => {
    advanced = !advanced;
    advancedToggle.setAttribute('aria-expanded', String(advanced));
    document.getElementById('advancedLabel').textContent = advanced ? 'Basic Search' : 'Advanced Search';
    document.querySelector('.advanced-icon').textContent = advanced ? '−' : '＋';
    document.getElementById('searchHeading').textContent = advanced ? 'Extended identification' : 'Citizen identification';
    renderFields();
  });

  document.getElementById('modeToggle').addEventListener('click', (event) => {
    const toggle = event.currentTarget;
    const enabled = toggle.getAttribute('aria-pressed') !== 'true';
    toggle.setAttribute('aria-pressed', String(enabled));
    toggle.classList.toggle('off', !enabled);
    document.getElementById('modeName').textContent = enabled ? 'Dual Sync' : 'Local Demo';
    document.getElementById('centralStatus').textContent = enabled ? 'CENTRAL SERVICE · NOT CONNECTED' : 'CENTRAL SERVICE · DISABLED';
    notify(enabled ? 'Dual Sync selected · demonstration sources only' : 'Local Demo selected · no central query will run');
  });

  searchButton.addEventListener('click', () => {
    const criteria = currentCriteria();
    if (Object.keys(criteria).length === 0) {
      notify('Enter at least one search parameter to continue.');
      fieldGrid.querySelector('input')?.focus();
      return;
    }
    searchButton.disabled = true;
    searchButton.innerHTML = '<span class="search-icon" aria-hidden="true">◌</span> Searching sample index…';
    document.getElementById('resultsTitle').textContent = 'Searching records';
    document.getElementById('resultCount').textContent = 'SEARCHING';
    document.getElementById('updatedAt').textContent = 'DEMONSTRATION MODE';
    recordsBody.replaceChildren();
    for (let i = 0; i < 3; i++) {
      const row = document.createElement('tr');
      const cell = document.createElement('td');
      cell.colSpan = 6;
      const skeleton = document.createElement('div');
      skeleton.className = 'skeleton';
      cell.append(skeleton);
      row.append(cell);
      recordsBody.append(row);
    }
    setTimeout(() => {
      const results = sampleRecords.filter(record => matches(record, criteria));
      renderRecords(results);
      document.getElementById('resultsTitle').textContent = 'Search results';
      document.getElementById('resultCount').textContent = `${results.length} ${results.length === 1 ? 'RECORD' : 'RECORDS'}`;
      document.getElementById('updatedAt').textContent = new Intl.DateTimeFormat('en', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date()).toUpperCase();
      if (results.length === 0) renderEmptyState();
      searchButton.disabled = false;
      searchButton.innerHTML = '<span class="search-icon" aria-hidden="true">⌕</span> Execute National Search <span class="button-arrow" aria-hidden="true">→</span>';
    }, 700);
  });

  renderFields();
  renderRecords(sampleRecords);
})();
