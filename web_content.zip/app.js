/**
 * ============================================================================
 * Sadad (سداد) - Digital P2P Wallet & Real-Time Payment Platform
 * Client-Side Business Logic, State Management & Cloud Integration
 * ============================================================================
 */

'use strict';

/* ============================================================================
   1. FIREBASE CONFIGURATION & INITIALIZATION
   ============================================================================
   Replace the placeholder values below with your Firebase Project credentials.
   To find these credentials:
     1. Go to https://console.firebase.google.com/
     2. Open your project > Project Settings > General
     3. Scroll to "Your apps" > Web App > Firebase SDK snippet > Config
   ============================================================================ */
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Global Application State
const AppState = {
  isFirebaseActive: false,
  currentUser: null,       // { phoneNumber, balance, pinCode, createdAt }
  isBalanceHidden: false,
  currentFilter: 'all',    // 'all' | 'received' | 'sent'
  searchQuery: '',
  transactions: [],
  unsubscribeUser: null,
  unsubscribeTx: null,
  currentLanguage: 'ar',   // 'ar' | 'en'
  currentTheme: 'dark'     // 'dark' | 'light'
};

// Database Reference
let db = null;

// Multi-Tab Synchronization Channel
const localSyncChannel = typeof BroadcastChannel !== 'undefined' 
  ? new BroadcastChannel('sadad_wallet_sync') 
  : null;

/* ============================================================================
   2. TRANSLATIONS & LOCALIZATION (i18n)
   ============================================================================ */
const i18n = {
  ar: {
    brandName: "سداد",
    brandTagline: "التحويل اللحظي الآمن",
    authTitle: "مرحباً بك في سداد",
    authSubtitle: "محفظتك الرقمية لإرسال واستقبال الأموال لحظياً",
    tabLogin: "تسجيل الدخول",
    tabRegister: "حساب جديد",
    phoneLabel: "رقم الهاتف المحمول",
    phoneHelp: "يجب أن يبدأ بـ 010، 011، 012، أو 015 وبطول 11 رقماً",
    pinLabel: "الرمز السري (4 أرقام)",
    pinHelp: "الرمز المشفر المخصص لتأكيد عملياتك ومعاملاتك",
    bonusNotice: "رصيد ترحيبي 1,000 ج.م متاح فور إنشاء الحساب!",
    btnLogin: "دخول إلى المحفظة",
    btnRegister: "إنشاء حساب وبدء الاستخدام",
    securityNotice: "تشفير وحماية العمليات بتقنية SHA-256",
    currentBalance: "الرصيد المتاح",
    egpCurrency: "ج.م",
    walletAccount: "رقم المحفظة",
    quickActionsTitle: "العمليات السريعة",
    instantLabel: "فوري",
    sendMoneyBtn: "إرسال أموال",
    requestMoneyBtn: "طلب أموال",
    totalReceived: "الوارد",
    totalSent: "الصادر",
    ledgerHeading: "سجل المعاملات",
    ledgerSubtitle: "تحديث فوري لجميع التحويلات والمدفوعات",
    tabAll: "الكل",
    tabReceived: "وارد (+)",
    tabSent: "صادر (-)",
    searchPlaceholder: "بحث برقم الهاتف أو المعاملة...",
    noTransactionsTitle: "لا توجد معاملات بعد",
    noTransactionsDesc: "ابدأ أول تحويل مالي لك إلى أي رقم مصري مسجل بنقرة واحدة",
    transferModalTitle: "تحويل أموال فوري",
    recipientLabel: "رقم محفظة المستلم",
    amountLabel: "المبلغ المراد تحويله (ج.م)",
    noteLabel: "ملاحظة أو سبب التحويل (اختياري)",
    confirmPinLabel: "تأكيد العملية برمزك السري",
    transferFee: "رسوم التحويل الفوري",
    freeFee: "مجاناً (0.00 ج.م)",
    totalDeduction: "إجمالي الخصم",
    confirmTransferBtn: "تأكيد وإرسال التحويل",
    requestModalTitle: "طلب تحويل مالي",
    requestInstructions: "شارك رقم محفظتك مع الشخص المراد استلام الأموال منه:",
    shareLinkBtn: "مشاركة رابط التحويل السريع",
    receiptModalTitle: "إيصال تحويل إلكتروني",
    transferSuccessLabel: "تم التحويل بنجاح",
    refNumber: "رقم العملية (Ref ID)",
    senderPhone: "المرسل",
    receiverPhone: "المستلم",
    txDateLabel: "التاريخ والوقت",
    txStatusLabel: "الحالة",
    printReceiptBtn: "طباعة الإيصال",
    closeReceiptBtn: "تم",
    topUpBtn: "شحن رصيد",
    rechargeModalTitle: "شحن الرصيد",
    rechargeAmountLabel: "مبلغ الشحن المطلوب",
    badgeInstantRecharge: "",
    instantRechargeNotice: "يضاف الرصيد فوراً في نفس اللحظة وبدون أي رسوم",
    rechargeSpeed: "",
    instantSpeedLabel: "",
    paymentMethodLabel: "وسيلة الدفع والشحن",
    methodCard: "بطاقة بنكية / ميزة",
    methodInstapay: "إنستاباي / فوري",
    bankCardOnly: "بطاقة بنكية فقط",
    bankCardOptionTitle: "بطاقة بنكية / ميزة",
    bankCardOptionDesc: "خصم مباشر فوري بدون أي رسوم إضافية",
    cardNumberLabel: "رقم البطاقة البنكية (16 رقماً)",
    cardExpiryLabel: "تاريخ الانتهاء",
    cardCvvLabel: "رمز الأمان (CVV)",
    cardHolderLabel: "اسم صاحب البطاقة",
    confirmCardRechargeBtn: "شحن فوري مباشر",
    confirmInstantRechargeBtn: "شحن فوري مباشر (+500.00)",
    confirmInstantDirectBtn: "تأكيد الشحن الفوري الآن (+500.00)",
    directRechargeTitle: "شحن فوري مباشر بدون بطاقة",
    directRechargeSubtitle: "إيداع رصيد تلقائي وفوري في محفظتك بنقرة واحدة وبدون أي بطاقات",
    deleteTransactionBtn: "حذف المعاملة",
    deleteModalTitle: "تأكيد حذف المعاملة",
    deleteConfirmPrompt: "هل أنت متأكد من رغبتك في حذف هذا السجل؟",
    deleteConfirmDesc: "سيتم إزالة المعاملة نهائياً من سجل المعاملات وقاعدة البيانات.",
    confirmDeleteBtn: "تأكيد الحذف",
    cancelBtn: "إلغاء",
    msgTxDeleted: "تم حذف المعاملة بنجاح!",
    rechargeFee: "رسوم الشحن",
    totalAddition: "إجمالي الإضافة",
    confirmRechargeBtn: "شحن فوري بالبطاقة البنكية",
    msgRechargeSuccess: "تم شحن الرصيد فورياً بنجاح!",
    // Toast & Error Messages
    errInvalidPhone: "رقم الهاتف غير صالح. يجب إدخال رقم مصري صحيح (11 رقماً يبدأ بـ 010, 011, 012, 015).",
    errInvalidPin: "يرجى إدخال الرمز السري كاملاً المكون من 4 أرقام.",
    errUserNotFound: "رقم الهاتف غير مسجل. يرجى إنشاء حساب أولاً.",
    errWrongPin: "الرمز السري غير صحيح. يرجى التحقق وإعادة المحاولة.",
    errUserExists: "رقم الهاتف مسجل بالفعل. يرجى تسجيل الدخول.",
    errSamePhone: "لا يمكنك إرسال الأموال إلى رقمك الشخصي.",
    errRecipientNotFound: "رقم المستلم غير مسجل في خدمة سداد.",
    errInsufficientFunds: "عفواً، رصيدك الحالي غير كافٍ لإتمام هذه المعاملة.",
    errInvalidAmount: "يرجى تحديد مبلغ صالح للتحويل (أكبر من 0 ج.م).",
    msgLoginSuccess: "تم تسجيل الدخول بنجاح! مرحباً بك في سداد.",
    msgRegisterSuccess: "تم إنشاء حسابك بنجاح مع رصيد 1,000 ج.م!",
    msgTransferSuccess: "تم التحويل بنجاح!",
    msgCopied: "تم النسخ إلى الحافظة بنجاح!",
    langBtnLabel: "English"
  },
  en: {
    brandName: "Sadad",
    brandTagline: "Instant Secure Payments",
    authTitle: "Welcome to Sadad",
    authSubtitle: "Your digital wallet to send & receive funds in real-time",
    tabLogin: "Sign In",
    tabRegister: "Create Account",
    phoneLabel: "Mobile Phone Number",
    phoneHelp: "Must start with 010, 011, 012, or 015 (11 digits total)",
    pinLabel: "Security PIN (4 Digits)",
    pinHelp: "Encrypted PIN used to authorize transactions",
    bonusNotice: "1,000 EGP welcome balance ready upon registration!",
    btnLogin: "Enter Wallet",
    btnRegister: "Register & Get Started",
    securityNotice: "Protected with SHA-256 cryptographic security",
    currentBalance: "Available Balance",
    egpCurrency: "EGP",
    walletAccount: "Wallet Account",
    quickActionsTitle: "Quick Actions",
    instantLabel: "Instant",
    sendMoneyBtn: "Send Money",
    requestMoneyBtn: "Request Money",
    totalReceived: "Received",
    totalSent: "Sent",
    ledgerHeading: "Transaction Ledger",
    ledgerSubtitle: "Real-time updates of all transfers and payments",
    tabAll: "All",
    tabReceived: "Received (+)",
    tabSent: "Sent (-)",
    searchPlaceholder: "Search by phone number or reference...",
    noTransactionsTitle: "No Transactions Yet",
    noTransactionsDesc: "Start your first transfer to any registered Egyptian number in one click",
    transferModalTitle: "Instant Money Transfer",
    recipientLabel: "Recipient Phone Number",
    amountLabel: "Transfer Amount (EGP)",
    noteLabel: "Transfer Note / Reason (Optional)",
    confirmPinLabel: "Authorize with your 4-digit PIN",
    transferFee: "Transfer Fee",
    freeFee: "Free (0.00 EGP)",
    totalDeduction: "Total Deduction",
    confirmTransferBtn: "Confirm & Send Transfer",
    requestModalTitle: "Request Money",
    requestInstructions: "Share your wallet phone number with the sender:",
    shareLinkBtn: "Share Payment Link",
    receiptModalTitle: "Electronic Transfer Receipt",
    transferSuccessLabel: "Transfer Completed Successfully",
    refNumber: "Transaction Ref ID",
    senderPhone: "Sender",
    receiverPhone: "Recipient",
    txDateLabel: "Date & Time",
    txStatusLabel: "Status",
    printReceiptBtn: "Print Receipt",
    closeReceiptBtn: "Done",
    topUpBtn: "Top Up",
    rechargeModalTitle: "Top-Up Balance",
    rechargeAmountLabel: "Top-Up Amount Required",
    badgeInstantRecharge: "",
    instantRechargeNotice: "Funds are credited instantly in real-time with 0% fees",
    rechargeSpeed: "",
    instantSpeedLabel: "",
    paymentMethodLabel: "Payment Method",
    methodCard: "Bank Card / Meeza",
    methodInstapay: "InstaPay / Fawry",
    bankCardOnly: "Bank Card Only",
    bankCardOptionTitle: "Bank Card / Meeza",
    bankCardOptionDesc: "Direct debit instant funding with 0% extra fees",
    cardNumberLabel: "Card Number (16 digits)",
    cardExpiryLabel: "Expiry Date",
    cardCvvLabel: "Security Code (CVV)",
    cardHolderLabel: "Cardholder Name",
    confirmCardRechargeBtn: "Confirm Instant Top-Up",
    confirmInstantRechargeBtn: "Confirm Instant Top-Up (+500.00)",
    confirmInstantDirectBtn: "Confirm Instant Top-Up Now (+500.00)",
    directRechargeTitle: "Instant Direct Top-Up (No Card Required)",
    directRechargeSubtitle: "Automated instant funds deposit to your wallet in one click without any cards",
    deleteTransactionBtn: "Delete Transaction",
    deleteModalTitle: "Confirm Deletion",
    deleteConfirmPrompt: "Are you sure you want to delete this transaction?",
    deleteConfirmDesc: "This record will be permanently removed from your transaction history.",
    confirmDeleteBtn: "Confirm Delete",
    cancelBtn: "Cancel",
    msgTxDeleted: "Transaction deleted successfully!",
    rechargeFee: "Service Fee",
    totalAddition: "Total Added",
    confirmRechargeBtn: "Confirm Instant Top-Up Now",
    msgRechargeSuccess: "Balance topped up instantly!",
    // Toast & Error Messages
    errInvalidPhone: "Invalid phone number. Must be a valid Egyptian mobile number (11 digits starting with 010, 011, 012, 015).",
    errInvalidPin: "Please enter your complete 4-digit security PIN.",
    errUserNotFound: "Phone number not registered. Please create an account first.",
    errWrongPin: "Incorrect PIN code. Please check and try again.",
    errUserExists: "This phone number is already registered. Please sign in.",
    errSamePhone: "You cannot transfer funds to your own wallet.",
    errRecipientNotFound: "Recipient phone number is not registered in Sadad.",
    errInsufficientFunds: "Insufficient funds to complete this transfer.",
    errInvalidAmount: "Please enter a valid amount greater than 0 EGP.",
    msgLoginSuccess: "Welcome back to Sadad!",
    msgRegisterSuccess: "Account created with 1,000 EGP starting balance!",
    msgTransferSuccess: "Transfer completed successfully!",
    msgCopied: "Copied to clipboard!",
    langBtnLabel: "عربي"
  }
};

/* ============================================================================
   3. CRYPTOGRAPHIC SECURITY (SHA-256 PIN Hashing via Web Crypto API)
   ============================================================================ */
/**
 * Hashes a 4-digit PIN with a dedicated salt using browser's native Web Crypto.
 * This guarantees the raw PIN is never stored or transmitted in plaintext.
 */
async function hashPin(pin, salt = "sadad_secure_salt_eg_2026") {
  const enc = new TextEncoder();
  const data = enc.encode(`${salt}_${pin.trim()}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ============================================================================
   4. EGYPTIAN PHONE VALIDATION & FORMATTING
   ============================================================================ */
function isValidEgyptianPhone(phone) {
  if (!phone) return false;
  const clean = phone.replace(/[\s\-()]/g, '');
  return /^01[0125][0-9]{8}$/.test(clean);
}

function formatEgyptianPhone(phone) {
  if (!phone || phone.length !== 11) return phone || '';
  return `${phone.slice(0, 3)} ${phone.slice(3, 7)} ${phone.slice(7)}`;
}

function formatCurrency(amount) {
  const num = Number(amount) || 0;
  return num.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function formatTxDate(timestamp) {
  let date;
  if (!timestamp) {
    date = new Date();
  } else if (timestamp.toDate && typeof timestamp.toDate === 'function') {
    date = timestamp.toDate();
  } else if (timestamp.seconds) {
    date = new Date(timestamp.seconds * 1000);
  } else {
    date = new Date(timestamp);
  }

  const isAr = AppState.currentLanguage === 'ar';
  return date.toLocaleString(isAr ? 'ar-EG' : 'en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
}

/* ============================================================================
   5. BACKEND INITIALIZATION (FIREBASE & FALLBACK ENGINE)
   ============================================================================ */
function isConfiguredFirebase(config) {
  return config &&
    config.apiKey &&
    config.apiKey !== "YOUR_API_KEY" &&
    config.projectId &&
    config.projectId !== "YOUR_PROJECT_ID";
}

function initBackend() {
  if (typeof firebase !== 'undefined' && isConfiguredFirebase(firebaseConfig)) {
    try {
      if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
      }
      db = firebase.firestore();
      AppState.isFirebaseActive = true;
      console.log('⚡ Firebase Cloud Firestore connected.');
      return;
    } catch (err) {
      console.warn('Firebase init error:', err);
    }
  }

  // Graceful offline fallback store (without any test store badges)
  AppState.isFirebaseActive = false;
  initFallbackStore();
}

function initFallbackStore() {
  if (!localStorage.getItem('sadad_app_users')) {
    hashPin('1234').then(hashedPin => {
      const initialUsers = {
        "01062855520": {
          phoneNumber: "01062855520",
          balance: 1000.00,
          pinCode: hashedPin,
          createdAt: new Date().toISOString()
        },
        "01002009472": {
          phoneNumber: "01002009472",
          balance: 1000.00,
          pinCode: hashedPin,
          createdAt: new Date().toISOString()
        }
      };
      localStorage.setItem('sadad_app_users', JSON.stringify(initialUsers));
    });
  }

  if (!localStorage.getItem('sadad_app_transactions')) {
    localStorage.setItem('sadad_app_transactions', JSON.stringify([]));
  }
}

/* ============================================================================
   6. ATOMIC STORAGE ENGINE
   ============================================================================ */
const FallbackStorage = {
  getUsers() {
    return JSON.parse(localStorage.getItem('sadad_app_users') || '{}');
  },
  saveUsers(users) {
    localStorage.setItem('sadad_app_users', JSON.stringify(users));
  },
  getTransactions() {
    return JSON.parse(localStorage.getItem('sadad_app_transactions') || '[]');
  },
  saveTransactions(txs) {
    localStorage.setItem('sadad_app_transactions', JSON.stringify(txs));
  },

  async getUser(phoneNumber) {
    const users = this.getUsers();
    return users[phoneNumber] || null;
  },

  async createUser(phoneNumber, hashedPin, balance = 1000) {
    const users = this.getUsers();
    if (users[phoneNumber]) {
      throw new Error(i18n[AppState.currentLanguage].errUserExists);
    }
    const newUser = {
      phoneNumber,
      balance: Number(balance),
      pinCode: hashedPin,
      createdAt: new Date().toISOString()
    };
    users[phoneNumber] = newUser;
    this.saveUsers(users);
    this.broadcast('USER_CREATED', { phoneNumber });
    return newUser;
  },

  async runAtomicTransfer(senderPhone, receiverPhone, amount, note = '') {
    const users = this.getUsers();
    const sender = users[senderPhone];
    const receiver = users[receiverPhone];

    if (!sender) throw new Error(i18n[AppState.currentLanguage].errUserNotFound);
    if (!receiver) throw new Error(i18n[AppState.currentLanguage].errRecipientNotFound);
    if (sender.balance < amount) throw new Error(i18n[AppState.currentLanguage].errInsufficientFunds);

    sender.balance = Number((sender.balance - amount).toFixed(2));
    receiver.balance = Number((receiver.balance + amount).toFixed(2));
    this.saveUsers(users);

    const txs = this.getTransactions();
    const newTx = {
      id: `TX-${Date.now().toString().slice(-6)}`,
      senderPhone,
      receiverPhone,
      amount: Number(amount),
      note: note || '',
      status: 'completed',
      timestamp: new Date().toISOString()
    };
    txs.unshift(newTx);
    this.saveTransactions(txs);

    this.broadcast('TRANSFER_COMPLETED', { newTx, senderPhone, receiverPhone });
    return newTx;
  },

  async rechargeFunds(phoneNumber, amount) {
    const users = this.getUsers();
    const user = users[phoneNumber];
    if (!user) throw new Error(i18n[AppState.currentLanguage].errUserNotFound);

    user.balance = Number((user.balance + amount).toFixed(2));
    this.saveUsers(users);

    const txs = this.getTransactions();
    const newTx = {
      id: `TOP-${Date.now().toString().slice(-6)}`,
      senderPhone: 'Sadad Payment Gateway',
      receiverPhone: phoneNumber,
      amount: Number(amount),
      note: '',
      status: 'completed',
      timestamp: new Date().toISOString()
    };
    txs.unshift(newTx);
    this.saveTransactions(txs);

    this.broadcast('TRANSFER_COMPLETED', { newTx, phoneNumber });
    return newTx;
  },

  async deleteTransaction(txId) {
    let txs = this.getTransactions();
    txs = txs.filter(t => t.id !== txId);
    this.saveTransactions(txs);
    this.broadcast('TRANSACTION_DELETED', { txId });
    return true;
  },

  broadcast(type, payload) {
    if (localSyncChannel) {
      localSyncChannel.postMessage({ type, payload });
    }
  }
};

/* ============================================================================
   7. PEER-TO-PEER TRANSFER ENGINE (FIRESTORE ATOMIC TRANSACTIONS)
   ============================================================================ */
async function executeFirestoreTransfer(senderPhone, receiverPhone, amount, note = '') {
  const senderRef = db.collection('users').doc(senderPhone);
  const receiverRef = db.collection('users').doc(receiverPhone);
  const txCollectionRef = db.collection('transactions');

  return await db.runTransaction(async (transaction) => {
    const senderDoc = await transaction.get(senderRef);
    if (!senderDoc.exists) {
      throw new Error(i18n[AppState.currentLanguage].errUserNotFound);
    }

    const receiverDoc = await transaction.get(receiverRef);
    if (!receiverDoc.exists) {
      throw new Error(i18n[AppState.currentLanguage].errRecipientNotFound);
    }

    const senderData = senderDoc.data();
    const receiverData = receiverDoc.data();

    if (senderData.balance < amount) {
      throw new Error(i18n[AppState.currentLanguage].errInsufficientFunds);
    }

    const newSenderBalance = Number((senderData.balance - amount).toFixed(2));
    const newReceiverBalance = Number((receiverData.balance + amount).toFixed(2));

    transaction.update(senderRef, { balance: newSenderBalance });
    transaction.update(receiverRef, { balance: newReceiverBalance });

    const newTxRef = txCollectionRef.doc();
    const txData = {
      senderPhone,
      receiverPhone,
      amount: Number(amount),
      note: note || '',
      status: 'completed',
      timestamp: firebase.firestore.FieldValue.serverTimestamp()
    };
    transaction.set(newTxRef, txData);

    return { id: newTxRef.id, ...txData };
  });
}

/**
 * Top-Up funds into Firestore account
 */
async function executeFirestoreRecharge(phoneNumber, amount) {
  const userRef = db.collection('users').doc(phoneNumber);
  const txCollectionRef = db.collection('transactions');

  return await db.runTransaction(async (transaction) => {
    const userDoc = await transaction.get(userRef);
    if (!userDoc.exists) {
      throw new Error(i18n[AppState.currentLanguage].errUserNotFound);
    }
    const currentBalance = userDoc.data().balance || 0;
    const newBalance = Number((currentBalance + amount).toFixed(2));

    transaction.update(userRef, { balance: newBalance });

    const newTxRef = txCollectionRef.doc();
    const txData = {
      senderPhone: 'Sadad Payment Gateway',
      receiverPhone: phoneNumber,
      amount: Number(amount),
      note: '',
      status: 'completed',
      timestamp: firebase.firestore.FieldValue.serverTimestamp()
    };
    transaction.set(newTxRef, txData);

    return { id: newTxRef.id, ...txData };
  });
}

/* ============================================================================
   8. REAL-TIME SNAPSHOT LISTENERS (onSnapshot)
   ============================================================================ */
function listenToUser(phoneNumber) {
  if (AppState.unsubscribeUser) {
    AppState.unsubscribeUser();
    AppState.unsubscribeUser = null;
  }

  if (AppState.isFirebaseActive && db) {
    AppState.unsubscribeUser = db.collection('users').doc(phoneNumber)
      .onSnapshot((doc) => {
        if (doc.exists) {
          const data = doc.data();
          AppState.currentUser.balance = data.balance;
          updateBalanceUI();
        }
      }, (error) => {
        console.error("User snapshot listener error:", error);
      });
  } else {
    const handleStorage = () => {
      const users = FallbackStorage.getUsers();
      if (users[phoneNumber]) {
        AppState.currentUser.balance = users[phoneNumber].balance;
        updateBalanceUI();
      }
    };
    window.addEventListener('storage', handleStorage);
    AppState.unsubscribeUser = () => window.removeEventListener('storage', handleStorage);
  }
}

function listenToTransactions(phoneNumber) {
  if (AppState.unsubscribeTx) {
    AppState.unsubscribeTx();
    AppState.unsubscribeTx = null;
  }

  if (AppState.isFirebaseActive && db) {
    const sentQuery = db.collection('transactions').where('senderPhone', '==', phoneNumber);
    const recvQuery = db.collection('transactions').where('receiverPhone', '==', phoneNumber);

    let sentTxs = [];
    let recvTxs = [];

    const mergeAndRender = () => {
      const combinedMap = new Map();
      [...sentTxs, ...recvTxs].forEach(tx => combinedMap.set(tx.id, tx));
      AppState.transactions = Array.from(combinedMap.values()).sort((a, b) => {
        const timeA = a.timestamp?.toMillis ? a.timestamp.toMillis() : new Date(a.timestamp).getTime();
        const timeB = b.timestamp?.toMillis ? b.timestamp.toMillis() : new Date(b.timestamp).getTime();
        return timeB - timeA;
      });
      renderTransactionLedger();
      updateFinancialStats();
    };

    const unsubSent = sentQuery.onSnapshot(snapshot => {
      sentTxs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      mergeAndRender();
    });

    const unsubRecv = recvQuery.onSnapshot(snapshot => {
      recvTxs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      mergeAndRender();
    });

    AppState.unsubscribeTx = () => {
      unsubSent();
      unsubRecv();
    };
  } else {
    const refreshTxs = () => {
      const allTxs = FallbackStorage.getTransactions();
      AppState.transactions = allTxs.filter(
        tx => tx.senderPhone === phoneNumber || tx.receiverPhone === phoneNumber
      );
      renderTransactionLedger();
      updateFinancialStats();
    };

    refreshTxs();

    const handleSync = (event) => {
      if (event.data?.type) {
        refreshTxs();
        const users = FallbackStorage.getUsers();
        if (users[phoneNumber]) {
          AppState.currentUser.balance = users[phoneNumber].balance;
          updateBalanceUI();
        }
      }
    };

    if (localSyncChannel) {
      localSyncChannel.addEventListener('message', handleSync);
    }
    window.addEventListener('storage', refreshTxs);

    AppState.unsubscribeTx = () => {
      if (localSyncChannel) localSyncChannel.removeEventListener('message', handleSync);
      window.removeEventListener('storage', refreshTxs);
    };
  }
}

/* ============================================================================
   9. AUTHENTICATION (Register & Login)
   ============================================================================ */
async function registerUser(phone, pin) {
  const hashedPin = await hashPin(pin);

  if (AppState.isFirebaseActive && db) {
    const userDocRef = db.collection('users').doc(phone);
    const existing = await userDocRef.get();
    if (existing.exists) {
      throw new Error(i18n[AppState.currentLanguage].errUserExists);
    }

    const newUser = {
      phoneNumber: phone,
      balance: 1000.00,
      pinCode: hashedPin,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    };
    await userDocRef.set(newUser);
    return newUser;
  } else {
    return await FallbackStorage.createUser(phone, hashedPin, 1000.00);
  }
}

async function loginUser(phone, pin) {
  const hashedPin = await hashPin(pin);

  let userData = null;
  if (AppState.isFirebaseActive && db) {
    const userDocRef = db.collection('users').doc(phone);
    const snapshot = await userDocRef.get();
    if (!snapshot.exists) {
      throw new Error(i18n[AppState.currentLanguage].errUserNotFound);
    }
    userData = snapshot.data();
  } else {
    userData = await FallbackStorage.getUser(phone);
    if (!userData) {
      throw new Error(i18n[AppState.currentLanguage].errUserNotFound);
    }
  }

  if (userData.pinCode !== hashedPin) {
    throw new Error(i18n[AppState.currentLanguage].errWrongPin);
  }

  return userData;
}

function setAuthenticatedSession(user) {
  AppState.currentUser = user;
  sessionStorage.setItem('sadad_session_phone', user.phoneNumber);
  sessionStorage.setItem('sadad_session_user', JSON.stringify(user));
  document.documentElement.classList.add('auth-session-active');

  document.getElementById('authSection').style.display = 'none';
  document.getElementById('dashboardSection').style.display = 'grid';
  document.getElementById('logoutBtn').style.display = 'inline-flex';

  document.getElementById('cardPhoneNumber').innerHTML = `<span class="num-font" dir="ltr">${formatEgyptianPhone(user.phoneNumber)}</span>`;
  document.getElementById('requestModalPhone').innerHTML = `<span class="num-font" dir="ltr">${formatEgyptianPhone(user.phoneNumber)}</span>`;
  updateBalanceUI();

  listenToUser(user.phoneNumber);
  listenToTransactions(user.phoneNumber);
}

function logoutUser() {
  if (AppState.unsubscribeUser) AppState.unsubscribeUser();
  if (AppState.unsubscribeTx) AppState.unsubscribeTx();

  AppState.currentUser = null;
  AppState.transactions = [];
  sessionStorage.removeItem('sadad_session_phone');
  sessionStorage.removeItem('sadad_session_user');
  document.documentElement.classList.remove('auth-session-active');

  document.getElementById('dashboardSection').style.display = 'none';
  document.getElementById('authSection').style.display = 'flex';
  document.getElementById('logoutBtn').style.display = 'none';

  clearPinInputs('authPinGroup');
}

/* ============================================================================
   10. UI UPDATES & RENDERING
   ============================================================================ */
function updateBalanceUI() {
  const balanceValueEl = document.getElementById('balanceValue');
  const modalBalanceHint = document.getElementById('modalMaxBalanceHint');
  const currentLang = AppState.currentLanguage;
  const balance = AppState.currentUser?.balance ?? 0;

  if (AppState.isBalanceHidden) {
    balanceValueEl.textContent = '••••••';
  } else {
    balanceValueEl.textContent = formatCurrency(balance);
  }

  if (modalBalanceHint) {
    const label = currentLang === 'ar' ? 'الرصيد:' : 'Balance:';
    const curr = i18n[currentLang].egpCurrency;
    modalBalanceHint.innerHTML = `${label} <span class="num-font" dir="ltr">${formatCurrency(balance)}</span> <span class="currency-tag">${curr}</span>`;
  }
}

function updateFinancialStats() {
  const currentPhone = AppState.currentUser?.phoneNumber;
  if (!currentPhone) return;

  let incomingTotal = 0;
  let outgoingTotal = 0;

  AppState.transactions.forEach(tx => {
    if (tx.receiverPhone === currentPhone) {
      incomingTotal += Number(tx.amount) || 0;
    } else if (tx.senderPhone === currentPhone) {
      outgoingTotal += Number(tx.amount) || 0;
    }
  });

  const curr = i18n[AppState.currentLanguage].egpCurrency;
  document.getElementById('totalIncomingDisplay').innerHTML = `
    <span class="num-font" dir="ltr">+${formatCurrency(incomingTotal)}</span>
    <span class="currency-tag">${curr}</span>
  `;
  document.getElementById('totalOutgoingDisplay').innerHTML = `
    <span class="num-font" dir="ltr">-${formatCurrency(outgoingTotal)}</span>
    <span class="currency-tag">${curr}</span>
  `;
}

function renderTransactionLedger() {
  const container = document.getElementById('txListContainer');
  const currentPhone = AppState.currentUser?.phoneNumber;
  const currentLang = AppState.currentLanguage;
  const t = i18n[currentLang];

  let filtered = AppState.transactions.filter(tx => {
    const isIncoming = tx.receiverPhone === currentPhone;
    const isOutgoing = tx.senderPhone === currentPhone;

    if (AppState.currentFilter === 'received' && !isIncoming) return false;
    if (AppState.currentFilter === 'sent' && !isOutgoing) return false;

    if (AppState.searchQuery) {
      const q = AppState.searchQuery.toLowerCase();
      const phoneMatch = (tx.senderPhone || '').includes(q) || (tx.receiverPhone || '').includes(q);
      const noteMatch = (tx.note || '').toLowerCase().includes(q);
      const idMatch = (tx.id || '').toLowerCase().includes(q);
      if (!phoneMatch && !noteMatch && !idMatch) return false;
    }

    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-ledger">
        <div class="empty-icon"><i class="fa-regular fa-folder-open"></i></div>
        <h3 style="font-size: 1.1rem; font-weight: 700;">${t.noTransactionsTitle}</h3>
        <p style="font-size: 0.85rem; max-width: 280px;">${t.noTransactionsDesc}</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(tx => {
    const isIncoming = tx.receiverPhone === currentPhone;
    const otherParty = isIncoming ? formatEgyptianPhone(tx.senderPhone) : formatEgyptianPhone(tx.receiverPhone);
    const prefix = isIncoming ? '+' : '-';
    const signClass = isIncoming ? 'incoming' : 'outgoing';
    const iconClass = isIncoming ? 'fa-arrow-down-left' : 'fa-arrow-up-right';
    const statusText = currentLang === 'ar' ? 'مكتمل' : 'Completed';

    return `
      <div class="transaction-card" data-tx-id="${tx.id}">
        <div class="tx-left">
          <div class="tx-icon-badge ${signClass}">
            <i class="fa-solid ${iconClass}"></i>
          </div>
          <div class="tx-details">
            <span class="tx-person bidi-phone" dir="ltr">${otherParty}</span>
            <span class="tx-date">${formatTxDate(tx.timestamp)}</span>
          </div>
        </div>
        <div class="tx-right">
          <span class="tx-amount ${signClass}">
            <span class="num-font" dir="ltr">${prefix}${formatCurrency(tx.amount)}</span>
            <span class="currency-tag">${t.egpCurrency}</span>
          </span>
          <div class="tx-actions-row">
            <span class="tx-status-badge">${statusText}</span>
            <button type="button" class="btn-tx-delete" data-delete-id="${tx.id}" title="${currentLang === 'ar' ? 'حذف المعاملة' : 'Delete Transaction'}" aria-label="Delete">
              <i class="fa-regular fa-trash-can"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  container.querySelectorAll('.btn-tx-delete').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const deleteId = btn.getAttribute('data-delete-id');
      promptDeleteTransaction(deleteId);
    });
  });

  container.querySelectorAll('.transaction-card').forEach(card => {
    card.addEventListener('click', () => {
      const txId = card.getAttribute('data-tx-id');
      const tx = AppState.transactions.find(t => t.id === txId);
      if (tx) showReceiptModal(tx);
    });
  });
}

function promptDeleteTransaction(txId) {
  const tx = AppState.transactions.find(t => t.id === txId);
  if (!tx) return;

  AppState.pendingDeleteTxId = txId;
  const isAr = AppState.currentLanguage === 'ar';
  const infoEl = document.getElementById('deleteModalTxInfo');
  if (infoEl) {
    infoEl.innerHTML = `
      <div style="display: flex; justify-content: space-between; margin-bottom: 0.35rem;">
        <span>${isAr ? 'رقم العملية:' : 'Ref ID:'}</span>
        <strong class="num-font" dir="ltr">#${tx.id}</strong>
      </div>
      <div style="display: flex; justify-content: space-between; margin-bottom: 0.35rem;">
        <span>${isAr ? 'المبلغ:' : 'Amount:'}</span>
        <strong class="num-font" style="color: var(--primary);" dir="ltr">${formatCurrency(tx.amount)} ${i18n[AppState.currentLanguage].egpCurrency}</strong>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <span>${isAr ? 'التاريخ:' : 'Date:'}</span>
        <span>${formatTxDate(tx.timestamp)}</span>
      </div>
    `;
  }
  openModal('deleteConfirmModal');
}

async function executeDeleteTransaction(txId) {
  const confirmBtn = document.getElementById('confirmDeleteTxBtn');
  try {
    if (confirmBtn) {
      confirmBtn.disabled = true;
      confirmBtn.innerHTML = `<div class="spinner"></div>`;
    }

    if (AppState.isFirebaseActive && db) {
      await db.collection('transactions').doc(txId).delete();
    } else {
      await FallbackStorage.deleteTransaction(txId);
    }

    AppState.transactions = AppState.transactions.filter(t => t.id !== txId);
    renderTransactionLedger();
    updateFinancialStats();
    closeModal('deleteConfirmModal');
    closeModal('receiptModal');
    showToast(i18n[AppState.currentLanguage].msgTxDeleted, 'success');
  } catch (err) {
    showToast(err.message || 'Failed to delete transaction', 'error');
  } finally {
    if (confirmBtn) {
      confirmBtn.disabled = false;
      confirmBtn.innerHTML = `
        <i class="fa-solid fa-trash-can"></i>
        <span>${i18n[AppState.currentLanguage].confirmDeleteBtn}</span>
      `;
    }
  }
}

function showReceiptModal(tx) {
  const currentLang = AppState.currentLanguage;

  document.getElementById('receiptRefId').textContent = `#${tx.id || 'TX-GEN'}`;
  document.getElementById('receiptSender').innerHTML = `<span class="num-font" dir="ltr">${formatEgyptianPhone(tx.senderPhone)}</span>`;
  document.getElementById('receiptReceiver').innerHTML = `<span class="num-font" dir="ltr">${formatEgyptianPhone(tx.receiverPhone)}</span>`;
  document.getElementById('receiptAmount').innerHTML = `
    <span class="num-font" dir="ltr">${formatCurrency(tx.amount)}</span>
    <span class="currency-tag">${i18n[currentLang].egpCurrency}</span>
  `;
  document.getElementById('receiptDate').textContent = formatTxDate(tx.timestamp);

  const noteRow = document.getElementById('receiptNoteRow');
  if (tx.note) {
    noteRow.style.display = 'flex';
    document.getElementById('receiptNote').textContent = tx.note;
  } else {
    noteRow.style.display = 'none';
  }

  openModal('receiptModal');
}

/* ============================================================================
   11. NOTIFICATIONS & TOASTS
   ============================================================================ */
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const icons = {
    success: 'fa-circle-check',
    error: 'fa-circle-exclamation',
    warning: 'fa-triangle-exclamation',
    info: 'fa-circle-info'
  };

  toast.innerHTML = `
    <i class="fa-solid ${icons[type] || 'fa-circle-info'} toast-icon"></i>
    <span class="toast-message">${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

/* ============================================================================
   12. MODAL & PIN UX
   ============================================================================ */
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
    const firstInput = modal.querySelector('input:not([type="hidden"])');
    if (firstInput) setTimeout(() => firstInput.focus(), 150);
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
    const form = modal.querySelector('form');
    if (form) form.reset();
    const pinGroup = modal.querySelector('.pin-input-group');
    if (pinGroup) clearPinInputs(pinGroup.id);
  }
}

function setupPinInputs(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const boxes = container.querySelectorAll('.pin-digit-box');

  boxes.forEach((box, index) => {
    box.addEventListener('input', (e) => {
      const val = e.target.value;
      if (val.length >= 1) {
        box.value = val.slice(-1);
        box.classList.add('filled');
        if (index < boxes.length - 1) {
          boxes[index + 1].focus();
        }
      } else {
        box.classList.remove('filled');
      }
    });

    box.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !box.value && index > 0) {
        boxes[index - 1].focus();
        boxes[index - 1].value = '';
        boxes[index - 1].classList.remove('filled');
      }
    });

    box.addEventListener('paste', (e) => {
      e.preventDefault();
      const pasted = (e.clipboardData || window.clipboardData).getData('text').trim();
      if (/^\d{4}$/.test(pasted)) {
        pasted.split('').forEach((digit, i) => {
          if (boxes[i]) {
            boxes[i].value = digit;
            boxes[i].classList.add('filled');
          }
        });
        boxes[3].focus();
      }
    });
  });
}

function getPinValue(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return '';
  const boxes = container.querySelectorAll('.pin-digit-box');
  return Array.from(boxes).map(b => b.value).join('');
}

function clearPinInputs(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.querySelectorAll('.pin-digit-box').forEach(b => {
    b.value = '';
    b.classList.remove('filled');
  });
}

function shakePinContainer(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.classList.remove('shake-animation');
  void container.offsetWidth;
  container.classList.add('shake-animation');
  clearPinInputs(containerId);
  const first = container.querySelector('.pin-digit-box');
  if (first) first.focus();
}

/* ============================================================================
   13. THEME & LANGUAGE SWITCHING
   ============================================================================ */
function toggleTheme() {
  const html = document.documentElement;
  const currentTheme = html.getAttribute('data-theme') || 'dark';
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', newTheme);
  AppState.currentTheme = newTheme;

  const icon = document.getElementById('themeIcon');
  if (icon) {
    icon.className = newTheme === 'dark' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
  }
}

function toggleLanguage() {
  const newLang = AppState.currentLanguage === 'ar' ? 'en' : 'ar';
  AppState.currentLanguage = newLang;

  const html = document.documentElement;
  html.setAttribute('lang', newLang);
  html.setAttribute('dir', newLang === 'ar' ? 'rtl' : 'ltr');

  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (i18n[newLang][key]) {
      el.textContent = i18n[newLang][key];
    }
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (i18n[newLang][key]) {
      el.placeholder = i18n[newLang][key];
    }
  });

  const langBtnText = document.getElementById('langBtnText');
  if (langBtnText) {
    langBtnText.textContent = i18n[newLang].langBtnLabel;
  }

  updateBalanceUI();
  updateFinancialStats();
  renderTransactionLedger();
}

/* ============================================================================
   14. INITIALIZATION & EVENT ATTACHMENTS
   ============================================================================ */
document.addEventListener('DOMContentLoaded', () => {

  initBackend();

  setupPinInputs('authPinGroup');
  setupPinInputs('transferPinGroup');

  // Instant synchronous session restoration (eliminates login flash / FOUC)
  const cachedUserStr = sessionStorage.getItem('sadad_session_user');
  if (cachedUserStr) {
    try {
      const cachedUser = JSON.parse(cachedUserStr);
      if (cachedUser && cachedUser.phoneNumber) {
        setAuthenticatedSession(cachedUser);
      }
    } catch (e) {
      console.warn('Failed to parse cached session user:', e);
    }
  }

  const storedPhone = sessionStorage.getItem('sadad_session_phone');
  if (storedPhone) {
    if (AppState.isFirebaseActive && db) {
      db.collection('users').doc(storedPhone).get().then(doc => {
        if (doc.exists) setAuthenticatedSession(doc.data());
      });
    } else {
      FallbackStorage.getUser(storedPhone).then(user => {
        if (user) setAuthenticatedSession(user);
      });
    }
  }

  document.getElementById('langToggleBtn')?.addEventListener('click', toggleLanguage);
  document.getElementById('themeToggleBtn')?.addEventListener('click', toggleTheme);
  document.getElementById('logoutBtn')?.addEventListener('click', logoutUser);

  const tabLogin = document.getElementById('tabLogin');
  const tabRegister = document.getElementById('tabRegister');
  const authBtnText = document.getElementById('authBtnText');
  const bonusNotice = document.getElementById('registerBonusNotice');
  let authMode = 'login';

  tabLogin?.addEventListener('click', () => {
    authMode = 'login';
    tabLogin.classList.add('active');
    tabRegister.classList.remove('active');
    authBtnText.textContent = i18n[AppState.currentLanguage].btnLogin;
    bonusNotice.style.display = 'none';
  });

  tabRegister?.addEventListener('click', () => {
    authMode = 'register';
    tabRegister.classList.add('active');
    tabLogin.classList.remove('active');
    authBtnText.textContent = i18n[AppState.currentLanguage].btnRegister;
    bonusNotice.style.display = 'block';
  });

  let isPinMasked = true;
  document.getElementById('togglePinMaskBtn')?.addEventListener('click', () => {
    isPinMasked = !isPinMasked;
    const boxes = document.querySelectorAll('#authPinGroup .pin-digit-box');
    boxes.forEach(b => b.type = isPinMasked ? 'password' : 'text');
    const maskIcon = document.getElementById('pinMaskIcon');
    if (maskIcon) {
      maskIcon.className = isPinMasked ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
    }
  });

  const authForm = document.getElementById('authForm');
  authForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const phoneInput = document.getElementById('authPhone');
    const phone = phoneInput.value.trim();
    const pin = getPinValue('authPinGroup');
    const submitBtn = document.getElementById('authSubmitBtn');

    if (!isValidEgyptianPhone(phone)) {
      showToast(i18n[AppState.currentLanguage].errInvalidPhone, 'error');
      phoneInput.focus();
      return;
    }

    if (pin.length !== 4) {
      showToast(i18n[AppState.currentLanguage].errInvalidPin, 'error');
      shakePinContainer('authPinGroup');
      return;
    }

    try {
      submitBtn.disabled = true;
      submitBtn.innerHTML = `<div class="spinner"></div>`;

      if (authMode === 'register') {
        const user = await registerUser(phone, pin);
        showToast(i18n[AppState.currentLanguage].msgRegisterSuccess, 'success');
        setAuthenticatedSession(user);
      } else {
        const user = await loginUser(phone, pin);
        showToast(i18n[AppState.currentLanguage].msgLoginSuccess, 'success');
        setAuthenticatedSession(user);
      }
    } catch (err) {
      showToast(err.message || 'Error occurred', 'error');
      shakePinContainer('authPinGroup');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = `
        <span id="authBtnText">${authMode === 'register' ? i18n[AppState.currentLanguage].btnRegister : i18n[AppState.currentLanguage].btnLogin}</span>
        <i class="fa-solid fa-arrow-left"></i>
      `;
    }
  });

  document.getElementById('balanceToggleBtn')?.addEventListener('click', () => {
    AppState.isBalanceHidden = !AppState.isBalanceHidden;
    const icon = document.getElementById('balanceEyeIcon');
    if (icon) {
      icon.className = AppState.isBalanceHidden ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
    }
    updateBalanceUI();
  });

  document.getElementById('copyPhoneBtn')?.addEventListener('click', () => {
    if (AppState.currentUser?.phoneNumber) {
      navigator.clipboard.writeText(AppState.currentUser.phoneNumber);
      showToast(i18n[AppState.currentLanguage].msgCopied, 'success');
    }
  });

  document.getElementById('copyRequestPhoneBtn')?.addEventListener('click', () => {
    if (AppState.currentUser?.phoneNumber) {
      navigator.clipboard.writeText(AppState.currentUser.phoneNumber);
      showToast(i18n[AppState.currentLanguage].msgCopied, 'success');
    }
  });

  document.getElementById('openSendModalBtn')?.addEventListener('click', () => {
    openModal('sendModal');
  });

  document.getElementById('openRechargeModalBtn')?.addEventListener('click', () => {
    openModal('rechargeModal');
    const amountInput = document.getElementById('rechargeAmount');
    if (amountInput) {
      amountInput.value = '500';
    }
    document.querySelectorAll('.quick-amount-row .recharge-pill').forEach(p => {
      if (p.getAttribute('data-amount') === '500') {
        p.classList.add('selected');
      } else {
        p.classList.remove('selected');
      }
    });
    updateRechargeSummary();
  });

  document.getElementById('openRequestModalBtn')?.addEventListener('click', () => {
    openModal('requestModal');
  });

  document.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-close-modal');
      closeModal(targetId);
    });
  });

  document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal(modal.id);
    });
  });

  document.querySelectorAll('.quick-amount-row .amount-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const val = pill.getAttribute('data-amount');
      const amountInput = document.getElementById('transferAmount');
      amountInput.value = val;
      updateTransferSummary();
      document.querySelectorAll('.quick-amount-row .amount-pill').forEach(p => p.classList.remove('selected'));
      pill.classList.add('selected');
    });
  });

  const transferAmountInput = document.getElementById('transferAmount');
  if (transferAmountInput) {
    transferAmountInput.addEventListener('input', updateTransferSummary);
  }

  function updateTransferSummary() {
    const val = Number(document.getElementById('transferAmount').value) || 0;
    const curr = i18n[AppState.currentLanguage].egpCurrency;
    document.getElementById('summaryTotalDeduction').innerHTML = `
      <span class="num-font" dir="ltr">${formatCurrency(val)}</span>
      <span class="currency-tag">${curr}</span>
    `;
  }

  const transferForm = document.getElementById('transferForm');
  transferForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const recipientInput = document.getElementById('transferRecipientPhone');
    const recipientPhone = recipientInput.value.trim();
    const amount = Number(document.getElementById('transferAmount').value);
    const note = document.getElementById('transferNote').value.trim();
    const pin = getPinValue('transferPinGroup');
    const confirmBtn = document.getElementById('confirmTransferBtn');
    const senderPhone = AppState.currentUser?.phoneNumber;

    if (!isValidEgyptianPhone(recipientPhone)) {
      showToast(i18n[AppState.currentLanguage].errInvalidPhone, 'error');
      recipientInput.focus();
      return;
    }

    if (recipientPhone === senderPhone) {
      showToast(i18n[AppState.currentLanguage].errSamePhone, 'error');
      return;
    }

    if (!amount || amount <= 0) {
      showToast(i18n[AppState.currentLanguage].errInvalidAmount, 'error');
      return;
    }

    if (amount > (AppState.currentUser?.balance || 0)) {
      showToast(i18n[AppState.currentLanguage].errInsufficientFunds, 'error');
      return;
    }

    if (pin.length !== 4) {
      showToast(i18n[AppState.currentLanguage].errInvalidPin, 'error');
      shakePinContainer('transferPinGroup');
      return;
    }

    const hashedEnteredPin = await hashPin(pin);
    if (hashedEnteredPin !== AppState.currentUser.pinCode) {
      showToast(i18n[AppState.currentLanguage].errWrongPin, 'error');
      shakePinContainer('transferPinGroup');
      return;
    }

    try {
      confirmBtn.disabled = true;
      confirmBtn.innerHTML = `<div class="spinner"></div>`;

      let txResult;
      if (AppState.isFirebaseActive && db) {
        txResult = await executeFirestoreTransfer(senderPhone, recipientPhone, amount, note);
      } else {
        txResult = await FallbackStorage.runAtomicTransfer(senderPhone, recipientPhone, amount, note);
      }

      closeModal('sendModal');
      showToast(i18n[AppState.currentLanguage].msgTransferSuccess, 'success');

      showReceiptModal({
        id: txResult.id,
        senderPhone,
        receiverPhone: recipientPhone,
        amount,
        note,
        status: 'completed',
        timestamp: new Date()
      });

    } catch (err) {
      showToast(err.message || 'Transfer failed', 'error');
    } finally {
      confirmBtn.disabled = false;
      confirmBtn.innerHTML = `
        <span id="transferBtnText">${i18n[AppState.currentLanguage].confirmTransferBtn}</span>
        <i class="fa-solid fa-check"></i>
      `;
    }
  });

  document.getElementById('printReceiptBtn')?.addEventListener('click', () => {
    window.print();
  });

  document.getElementById('sharePaymentLinkBtn')?.addEventListener('click', () => {
    const url = `${window.location.origin}${window.location.pathname}?payto=${AppState.currentUser?.phoneNumber}`;
    if (navigator.share) {
      navigator.share({
        title: 'سداد - Sadad',
        text: `تحويل أموال فوري إلى محفظة سداد رقم: ${AppState.currentUser?.phoneNumber}`,
        url
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(url);
      showToast(i18n[AppState.currentLanguage].msgCopied, 'success');
    }
  });

  const urlParams = new URLSearchParams(window.location.search);
  const payTo = urlParams.get('payto');
  if (payTo && isValidEgyptianPhone(payTo)) {
    const recipientInput = document.getElementById('transferRecipientPhone');
    if (recipientInput) recipientInput.value = payTo;
  }

  // Recharge Quick Amount Chips
  document.querySelectorAll('.quick-amount-row .recharge-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const val = pill.getAttribute('data-amount');
      const amountInput = document.getElementById('rechargeAmount');
      if (amountInput) {
        amountInput.value = val;
        updateRechargeSummary();
      }
      document.querySelectorAll('.quick-amount-row .recharge-pill').forEach(p => p.classList.remove('selected'));
      pill.classList.add('selected');
    });
  });

  const rechargeAmountInput = document.getElementById('rechargeAmount');
  if (rechargeAmountInput) {
    rechargeAmountInput.addEventListener('input', updateRechargeSummary);
  }

  function updateRechargeSummary() {
    const val = Number(document.getElementById('rechargeAmount')?.value) || 0;
    const isAr = AppState.currentLanguage === 'ar';
    const summaryEl = document.getElementById('summaryTotalRecharge');
    if (summaryEl) {
      summaryEl.innerHTML = `
        <span class="num-font" dir="ltr">+${formatCurrency(val)}</span>
      `;
    }

    const rechargeBtnText = document.getElementById('rechargeBtnText');
    if (rechargeBtnText) {
      if (val > 0) {
        rechargeBtnText.textContent = isAr 
          ? `تأكيد الشحن الفوري الآن (+${formatCurrency(val)})` 
          : `Confirm Instant Top-Up Now (+${formatCurrency(val)})`;
      } else {
        rechargeBtnText.textContent = isAr ? 'تأكيد الشحن الفوري الآن' : 'Confirm Instant Top-Up Now';
      }
    }

    document.querySelectorAll('.quick-amount-row .recharge-pill').forEach(p => {
      if (Number(p.getAttribute('data-amount')) === val) {
        p.classList.add('selected');
      } else {
        p.classList.remove('selected');
      }
    });
  }

  // Recharge Form Submission (Instant 1-Click Top-Up - No Card Required)
  const rechargeForm = document.getElementById('rechargeForm');
  rechargeForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const amount = Number(document.getElementById('rechargeAmount')?.value);
    const phone = AppState.currentUser?.phoneNumber;
    const confirmBtn = document.getElementById('confirmRechargeBtn');

    if (!amount || amount < 10) {
      showToast(i18n[AppState.currentLanguage].errInvalidAmount, 'error');
      return;
    }

    try {
      confirmBtn.disabled = true;
      confirmBtn.innerHTML = `<div class="spinner"></div>`;

      let txResult;
      if (AppState.isFirebaseActive && db) {
        txResult = await executeFirestoreRecharge(phone, amount);
      } else {
        txResult = await FallbackStorage.rechargeFunds(phone, amount);
      }

      closeModal('rechargeModal');
      showToast(i18n[AppState.currentLanguage].msgRechargeSuccess, 'success');

      // Present Receipt Modal for recharge (without note row)
      showReceiptModal({
        id: txResult.id,
        senderPhone: 'Sadad Direct Gateway',
        receiverPhone: phone,
        amount,
        note: '',
        status: 'completed',
        timestamp: new Date()
      });

    } catch (err) {
      showToast(err.message || 'Recharge failed', 'error');
    } finally {
      confirmBtn.disabled = false;
      const currentVal = Number(document.getElementById('rechargeAmount')?.value) || 500;
      const isAr = AppState.currentLanguage === 'ar';
      confirmBtn.innerHTML = `
        <span id="rechargeBtnText">${isAr ? `تأكيد الشحن الفوري الآن (+${formatCurrency(currentVal)})` : `Confirm Instant Top-Up Now (+${formatCurrency(currentVal)})`}</span>
        <i class="fa-solid fa-bolt"></i>
      `;
    }
  });

  // Card Number Auto-formatting (XXXX XXXX XXXX XXXX)
  const cardNumInput = document.getElementById('rechargeCardNumber');
  if (cardNumInput) {
    cardNumInput.addEventListener('input', (e) => {
      let val = e.target.value.replace(/\D/g, '').slice(0, 16);
      let formatted = val.match(/.{1,4}/g)?.join(' ') || val;
      e.target.value = formatted;
    });
  }

  // Card Expiry Auto-formatting (MM/YY)
  const cardExpInput = document.getElementById('rechargeCardExpiry');
  if (cardExpInput) {
    cardExpInput.addEventListener('input', (e) => {
      let val = e.target.value.replace(/\D/g, '').slice(0, 4);
      if (val.length >= 3) {
        e.target.value = `${val.slice(0, 2)}/${val.slice(2)}`;
      } else {
        e.target.value = val;
      }
    });
  }

  // Card CVV numeric only
  const cardCvvInput = document.getElementById('rechargeCardCvv');
  if (cardCvvInput) {
    cardCvvInput.addEventListener('input', (e) => {
      e.target.value = e.target.value.replace(/\D/g, '').slice(0, 4);
    });
  }

  // Receipt Modal Delete Button
  document.getElementById('receiptDeleteBtn')?.addEventListener('click', () => {
    const refIdText = document.getElementById('receiptRefId')?.textContent || '';
    const txId = refIdText.replace(/^#/, '').trim();
    if (txId) {
      promptDeleteTransaction(txId);
    }
  });

  // Delete Confirmation Modal Confirm Button
  document.getElementById('confirmDeleteTxBtn')?.addEventListener('click', () => {
    if (AppState.pendingDeleteTxId) {
      executeDeleteTransaction(AppState.pendingDeleteTxId);
    }
  });

  document.querySelectorAll('.ledger-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.ledger-tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      AppState.currentFilter = btn.getAttribute('data-filter');
      renderTransactionLedger();
    });
  });

  const searchInput = document.getElementById('txSearchInput');
  searchInput?.addEventListener('input', (e) => {
    AppState.searchQuery = e.target.value.trim();
    renderTransactionLedger();
  });

});
