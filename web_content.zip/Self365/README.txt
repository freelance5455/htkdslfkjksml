HOW TO BUILD THE APK (Android Studio, on a computer)
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > choose this Self365 folder. Wait for Gradle sync (needs internet).
   If it asks about Gradle, choose Android Studio's default Gradle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup: app-debug.apk is in app/build/outputs/apk/debug/
5. Send the APK to your phone and install it (allow "install unknown apps").

To change the app later, edit app/src/main/assets/index.html and rebuild.
