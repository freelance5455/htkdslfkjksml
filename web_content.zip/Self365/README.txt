Self365 – 365 Days Self-Improvement Android App
Premium Artistic Edition – Version 2.0

Features:
- Amharic-first 365-day habit tracker
- Daily notes, streaks, progress statistics and calendar
- Monthly income and expense tracking
- Password lock, themes and custom wallpaper
- Premium visual refresh with subtle animations and responsive cards
- JSON backup and restore for personal data

Build with Android Studio using the included Gradle project.
Minimum Android version: Android 7.0 (API 24).
Note: User data is stored locally on the device. Export backups regularly.
