# v1.62.20 — Correção do Mercado / LaLiga

- Corrigida a lista de destinos para manter os 20 clubes da LaLiga depois de confirmar “ESCOLHER CLUBE”.
- Corrigida a validação de clubes permitidos na negociação: os clubes espanhóis agora passam pela validação do Mercado.
- O fluxo continua: escolher clube → iniciar negociação → receber proposta → abrir proposta → aceitar → confirmar transferência.
- Nenhum calendário, elenco, escudo ou save foi apagado por esta alteração.
