# Desejos PT — mapa vivo de descobertas

## Produto

O site conecta desejos de brasileiros em Portugal a locais onde produtos e serviços podem ser encontrados. A experiência usa uma lista pesquisável e um mapa de Portugal como superfícies complementares. O MVP funciona com dados de demonstração, recebe novos desejos por formulário e transmite atualizações por Server-Sent Events (SSE), sem recarregar a página.

A privacidade é parte do produto: participantes aparecem anonimizados, desejos mostram apenas cidade/zona aproximada e os marcadores do mapa representam estabelecimentos ou áreas, nunca o endereço pessoal de uma pessoa.

## Design

### Direções exploradas

- **Atlântico Cívico** (0,06): console de descoberta com mapa escuro, coral de ação e sinais de atualização ao vivo.
- **Guia de Bairro** (0,04): catálogo editorial quente, com papel claro e navegação por bairros.
- **Radar Urbano** (0,02): painel de operações com alto contraste e linguagem técnica.

Escolhida: **Atlântico Cívico**.

- **Movimento:** mapas comunitários e dashboards de dados públicos, com precisão operacional sem parecer frio.
- **Princípios:** mapa como espaço compartilhado; informação escaneável; confiança e consentimento visíveis; ação rápida.
- **Filosofia de cor:** azul-marinho atlântico cria profundidade e foco; coral marca ações humanas; lima indica disponibilidade e vida; azul-claro organiza informação.
- **Paradigma de layout:** navegação lateral fixa, lista como feed vivo e mapa ocupando o palco principal; no celular, a lista vira uma gaveta inferior.
- **Elementos assinatura:** pulso “ao vivo”, pins em forma de gota com halo e cartões com faixa de “encontrado em”.
- **Interação:** selecionar um item ilumina seu pin; filtros reorganizam a lista; novos desejos entram no topo com uma animação curta e uma notificação discreta.
- **Animação:** pulsação de 2s nos sinais live; entrada de cards em 180ms; pins com halo suave; sem movimento essencial para concluir tarefas.
- **Tipografia:** sistema sans-serif para alta legibilidade; títulos em peso 800, labels em caixa alta com tracking; corpo confortável em 15–17px.
- **Essência de marca:** “o mapa comunitário que transforma vontade em caminho” para brasileiros em Portugal. Personalidade: atento, prático, acolhedor.
- **Voz:** direta, humana e útil. Exemplos: “Veja onde a comunidade encontrou” e “Seu desejo pode virar pista para outra pessoa”.
- **Marca:** wordmark “Desejos PT” acompanhado de um pin formado por duas vírgulas/ondas atlânticas.
- **Cor proprietária:** Coral Caminho `#FF765F`.

## Estrutura

- `server.mjs`: servidor HTTP, API de desejos, SSE e modo demo de eventos.
- `public/index.html`: shell semântico, formulário, mapa e áreas de estado.
- `public/styles.css`: sistema visual responsivo.
- `public/app.js`: estado da interface, filtros, pins, formulário e conexão live.
- `public/manus-routes.json`: manifesto de rotas.
