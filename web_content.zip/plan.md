# BarrelCount Peshawar — plan

## Product scope

BarrelCount Peshawar is a phone-friendly internal shop ledger for a hard-chrome barrel shop. Staff can maintain customer records, record daily barrel receipts, correct mistakes, filter activity by a selected date range, and see customer-wise barrel totals for payment collection.

## Implementation approach

- Use the initialized React/Express/tRPC/Drizzle web stack with the managed MySQL database.
- Add `customers` and `barrel_receipts` tables. Each receipt stores a customer, receipt date, barrel quantity, optional note, and creation timestamp.
- Expose public tRPC procedures for customer CRUD, receipt CRUD, and filtered receipt listing. The shop is a single shared workspace, so the first version does not add sign-in friction.
- Calculate the selected-period payment summary from filtered receipt data in the client so the totals update immediately when the date range changes.
- Keep the interface on one responsive home route: date filter and headline totals, receipt entry, customer management, payment summary, and daily activity.
- Provide a print-friendly payment summary action using the browser print dialog.

## Project structure

- `drizzle/schema.ts`: persistent `customers` and `barrel_receipts` tables alongside the starter user table.
- `server/db.ts`: customer and receipt queries, validation of deletions, and filtered reads.
- `server/routers.ts`: public tRPC API for shop operations.
- `client/src/pages/Home.tsx`: the complete shop workflow and responsive interaction state.
- `client/src/index.css`: industrial ledger visual system, responsive layout, and print rules.
- `public/manus-routes.json`: route declaration for the single-page app.

## Design direction

Three possible directions were considered:

- **Industrial ledger** — a workshop-inspired utility with paper tones, ink green, and a burnt-orange action color. Probability 0.07.
- **Clean government form** — neutral blue-gray forms and strict data-table hierarchy. Probability 0.05.
- **Bold market board** — high-contrast black, cream, and red with large numeric totals. Probability 0.08.

Chosen direction: **Industrial ledger**.

### Design Movement

A modern workshop ledger: tactile paper-like surfaces, narrow rules, strong numerals, and small signal colors that make the app feel dependable in a busy shop rather than like a generic SaaS dashboard.

### Core Principles

1. Record-first: the receipt form is the visual anchor and has the fewest decisions possible.
2. Totals before detail: the selected-period amount is always visible before the activity list.
3. Calm density: compact rows and clear separators support many daily entries without feeling crowded.
4. Safe correction: edit and delete actions stay close to each activity item, with confirmation before destructive changes.

### Color Philosophy

Use warm paper and parchment neutrals as the working surface, deep ink green for trust and stable labels, and burnt orange only for actions and attention. The palette should feel like a durable shop register, with enough contrast for daylight phone use.

### Layout Paradigm

A vertical workbench rather than a centered marketing grid: a slim masthead, a wide summary band, then the receipt station and ledger lanes. On mobile each lane becomes a single clear work surface; on larger screens the receipt station and customer list sit beside one another.

### Signature Elements

- A dark ink-green masthead with a small barrel-mark motif and “SHOP LEDGER” eyebrow.
- Orange quantity chips and large tabular numerals for totals.
- Thin ledger rules and lightly offset cards that echo a paper register.

### Interaction Philosophy

Every primary task should be achievable with one thumb: native select/date/number controls, obvious full-width save buttons on narrow screens, and no hidden navigation. Date filters update the summary and activity together so staff always know what period they are looking at.

### Animation

Use only quick, purposeful transitions: card hover lift on desktop, a 150ms fade/slide for the customer dialog, and no looping motion. Totals may softly fade when the date range changes.

### Typography System

Use a sturdy sans serif system stack for legibility, with uppercase eyebrow labels and tabular numerals for counts. Headlines are compact and slightly letter-spaced; table and form text is plain and high-contrast.

### Brand Essence

A reliable daily barrel register for hard-chrome shops: simple, accountable, ready at the counter. Personality: dependable, direct, practical.

### Brand Voice

Headlines are short and grounded: “Every barrel accounted for.” Buttons use direct verbs: “Save receipt”, “Add customer”, and “Print summary”.

### Wordmark & Logo

The wordmark is a compact “BarrelCount” lockup paired with a small outlined barrel icon, separated from the shop descriptor by a vertical rule.

### Signature Brand Color

Ink green `#173C35`, used for the masthead, labels, and stable data signals.
