# PC Builder — Implementation Plan

## Product
A mobile-first, offline-friendly PC building simulator that runs from static HTML, CSS, and JavaScript and can later be wrapped as an Android APK.

## Implementation
- `index.html`: single-page shell, page regions, dialogs, and bottom navigation.
- `style.css`: dark futuristic visual system, responsive phone-first layout, touch targets, restrained transitions.
- `data.js`: editable local example-price database for all requested component categories.
- `app.js`: state, rendering, compatibility rules, estimates, budget math, localStorage persistence, navigation, saved builds, settings.
- `manus-routes.json`: route declaration for the SPA root.

No backend, framework, external assets, or paid APIs are required. The app is served as static files and also works when opened locally through a simple static server.

## Design direction
- **Design movement:** mobile cyber-deck / cockpit UI, softened for everyday usability.
- **Core principles:** fast scanning, tactile controls, honest estimates, progressive disclosure.
- **Color philosophy:** near-black graphite provides focus and low-light comfort; electric cyan signals active data; violet gives the product a memorable gaming identity; amber/red are reserved for actionable warnings.
- **Layout paradigm:** a vertical command deck with a sticky build telemetry header, horizontally scrollable filter chips, and stacked glass panels rather than a dense desktop grid.
- **Signature elements:** cyan edge glow on active controls, monospaced numeric telemetry, component glyph placeholders with category color bands.
- **Interaction philosophy:** every selection produces visible feedback immediately; no hidden or dead controls; destructive reset/delete actions ask for confirmation.
- **Animation:** 160–220ms opacity/translate transitions, progress bar easing, and a small selection pulse; no continuous background motion.
- **Typography system:** system sans for readability with `Roboto Mono`-style monospace fallback for figures and labels.
- **Brand essence:** “A calm, practical cockpit for planning a better PC.” Personality: precise, energetic, trustworthy.
- **Brand voice:** direct and encouraging. Examples: “Tune the build, not the guesswork.” and “Compatibility checked before you buy.”
- **Wordmark/logo:** a bracketed circuit-chip mark paired with a compact uppercase wordmark.
- **Signature brand color:** Electric cyan `#65f5ff`.

## Project structure
Static root only; no server/database capability is needed. The browser is the runtime and localStorage is the persistence layer.
