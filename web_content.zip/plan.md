# Plan de implementación — VIP Like Generator

## Alcance
Construir una aplicación web responsive para Android, iOS y PC con un dashboard gaming premium, generador de solicitudes de likes para Free Fire conectado al backend Render indicado, historial local y persistente cuando sea posible, temas visuales, configuración y panel administrativo protegido con la autenticación real del starter.

## Enfoque técnico
- Frontend: React + TypeScript + Vite, navegación por estado de pestaña y componentes accesibles.
- Backend: Express, endpoints de salud e integración server-side con `https://vip-like-api-ehd8.onrender.com` mediante Fetch/axios sin inventar endpoints.
- Persistencia: Drizzle/MySQL para solicitudes e historial general, con fallback controlado del lado cliente únicamente para mantener la UX cuando la base no esté disponible.
- Administración: Manus OAuth del starter y `adminProcedure`; no se implementarán contraseñas ni secretos en el navegador.
- Seguridad: validación estricta de IDs, límites de tamaño, errores HTTP explícitos y no se mostrará una entrega confirmada salvo que el proveedor lo confirme.
- Publicación: servidor Express en el puerto configurado, health check en `/api/health`, manifiesto de rutas en `public/manus-routes.json`.

## Diseño
### Estilos considerados
1. **Neon Command Center** — 0.07: panel oscuro de control con neón cian/violeta y lectura operativa.
2. **Cyber Lounge** — 0.05: glassmorphism más suave, brillos ambientales y tarjetas flotantes.
3. **Arcade Terminal** — 0.03: alto contraste, tipografía monoespaciada y ritmo más técnico.

Se elige **Neon Command Center**.

- **Movimiento:** dashboard cyberpunk editorial con superficies de vidrio y señalética de consola.
- **Principios:** jerarquía operativa clara; contraste profundo con acentos eléctricos; feedback visible en cada acción; densidad adaptable a móvil.
- **Color:** negro carbón como base estable; cian para disponibilidad y acción; violeta para identidad VIP; ámbar/rojo solo para advertencias.
- **Layout:** navegación lateral persistente en escritorio y drawer compacto en móvil; columna principal de solicitud y rail secundario de estado/historial.
- **Firmas visuales:** wordmark con símbolo de rayo; línea de escaneo sobre la tarjeta principal; chips de estado con halo.
- **Interacción:** botones con respuesta física breve, estados de carga visibles, toast de resultado y confirmaciones no ambiguas.
- **Animación:** entrada escalonada de paneles, pulso sutil en salud del servidor, barra de progreso durante una solicitud; respetar `prefers-reduced-motion`.
- **Tipografía:** Space Grotesk para títulos y UI; IBM Plex Mono para IDs, métricas y estados técnicos.
- **Esencia:** centro operativo VIP para gestionar solicitudes de likes con transparencia de estado; preciso, intenso, confiable.
- **Voz:** titulares directos y técnicos. Ejemplos: “Listo para procesar tu ID” y “Solicitud registrada; el proveedor aún no confirma la entrega”.
- **Wordmark:** “VIP” en bloque geométrico con rayo integrado y “LIKE GENERATOR” en tracking amplio.
- **Color propio:** cian eléctrico `#56e0ff` combinado con violeta `#8b5cf6` sobre carbón `#080b12`.

## Estructura
- `client/src/pages/Home.tsx`: dashboard, pestañas, solicitud, historial, temas, configuración y administración.
- `client/src/index.css`: sistema visual, temas CSS, responsive y estados.
- `server/_core/index.ts`: health, proxy seguro y serving.
- `server/routers.ts`: procedimientos tRPC públicos y administrativos.
- `drizzle/schema.ts`, `server/db.ts`: modelo y consultas de solicitudes.
- `public/manus-routes.json`: rutas declaradas.
- `README.md`: instalación, Render, variables y pruebas.

## Criterios de comportamiento
La cantidad visible será fija en 200, pero el estado dependerá de la respuesta real del backend. La aplicación diferenciará “solicitado”, “pendiente de proveedor”, “confirmado” y “error”; jamás convertirá una respuesta pendiente en entrega confirmada. El panel administrativo permanecerá bloqueado para usuarios no autenticados/no administradores.
