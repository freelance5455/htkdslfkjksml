# TO‘LOVCHI — existing repository expansion plan

## Scope and preservation

The owner approved extending this existing repository to include the customer-facing TO‘LOVCHI finance app while retaining the already-built Super Admin Dashboard. Do not initialize another Manus project, replace the repository, rewrite the root application, or remove any completed dashboard screens, authentication, migrations or tests.

The repository currently has a working React/Vite web owner console and an Express/tRPC/Drizzle/MySQL backend. Its current operational, revenue and growth metrics are explicitly synthetic demonstrations; store, advertising, analytics, crash, support and cloud-cost sources are not connected. The root dashboard remains at `/` and its backend continues on port 3000. Add a distinct Expo / React Native app under `mobile/`, with separate source/configuration and independent commands in this same repository.

## Customer-data and service boundaries

- Keep personal finance local-first. Income, expenses, debts, repayments, bills, budgets, Zakat inputs and reports belong only in the mobile app's on-device database. Never add these records, individual details or decrypted backups to the admin schema, dashboard APIs, support queue, audit log, crash logs or analytics.
- Use SQLCipher-backed Expo SQLite for Android and iOS. Store its randomly generated database key with Expo SecureStore backed by Android Keystore / iOS Keychain. During database initialization require `PRAGMA cipher_version` to be present before any sensitive table is written, set the key, then run additive local migrations. Expo Go cannot test SQLCipher or the native billing/ad libraries; use a development build.
- Provide an app lock with device biometric or a separately configured app PIN, with lockout and recovery behavior. Biometrics are a local gate, not a backup method. Never claim encryption unless the built native binary actually includes SQLCipher and its cipher check passed.
- Keep amounts decimal-safe as integer minor-unit strings plus an explicit currency code and precision. Preserve original amounts; do not add unlike currencies without an explicit target, manual rate, effective date, conversion direction and rounding. Due dates and transaction dates use local calendar-day values; event scheduling derives local instants and reschedules when date/time-zone settings change.
- Keep administrator authentication and its database-backed admin records separate from any future customer account. The customer finance app must work without network access. Cloud backup and family sharing remain unavailable until a customer-specific backend, end-to-end encryption, consent, authorization, key recovery, retention and restore behavior are implemented and verified.
- Local notifications handle bills, debts, budget thresholds and Zakat dates only after permission. Permission denial must not block offline finance features; notification copy is private/minimal and delivery is never promised.
- Do not fake Premium entitlements, purchases, production ads, analytics or a store release. Configure store billing, AdMob and live dashboard telemetry only when the owner supplies the required owner-controlled provider accounts, product/ad IDs, disclosures, signing and service access.

## Implementation approach

1. Preserve the current root console and establish an additive workspace/build setup. Implement the customer app in a separate `mobile/` Expo Router workspace, not by changing the root Vite entry point. Reuse the existing TO‘LOVCHI monogram, emerald brand color and repository package-manager setup.
2. Establish shared mobile foundations: device-locale detection with Uzbek default and Uzbek/Russian/English catalogs; theme, preferred currency and reminder preferences; onboarding and beginner-friendly settings; a bottom-navigation shell designed for portrait/one-handed Android use; SQLCipher database/key initialization; app lock; local repositories; and privacy-safe error handling.
3. Implement local domain functions first, using fixed-precision money and explicit date/rate semantics. Add customer screens and persistence for income/expense transactions, categories, search/filters/monthly summaries, bills/recurrence/mark-paid, debts/partial repayments/history, budgets, financial calendar, Zakat estimate, manual multi-currency display/conversion and saved settings. Keep derived charts and reports reconciled to source records.
4. Add local date notifications with permission-aware idempotent scheduling/cancellation and reschedule after edits, completion, time-zone changes or permission changes. Add user-initiated, local CSV/PDF reports and data export/delete. Any future backup is disabled until client-side encryption and its owner-controlled storage backend are complete.
5. Add a subscription/ad integration boundary and non-entitled/free experience without pretending a purchase succeeded. Use Google Play Billing for Android digital subscriptions and the StoreKit-equivalent path for iOS when configured. Use non-personalized/test ads only during a correctly configured native test build. Never send finance records or sensitive identifiers to ad or analytics providers. Product purchases, cloud backup and family sharing stay gated until their credentials/services exist.
6. Prepare EAS build profiles in `mobile/eas.json`: an internal signed installable APK and a Play-upload AAB. The owner will have to use an Expo/EAS account and owner-controlled Google Play Console app record, stable package ID, signing and store credentials; no such account or identifiers were supplied. Keep this repository as the sole project source and give phone-friendly build/download instructions. Do not claim a real APK/AAB until a build result exists.
7. Preserve separate mobile and web deployment/build scripts. Add database-free mobile domain tests and Expo type/config checks while keeping root admin test/build behavior unchanged. The root MySQL service remains admin-only; migrations for it must not introduce customer financial tables.

## Project structure

- `client/`, `server/`, `drizzle/`, `shared/`, `docs/OWNER-MANUAL-ANDROID.md`, `docs/DEPLOYMENT.md`, `Dockerfile`, `compose.yaml`: existing owner dashboard, administrator-only services, migrations and deployment guidance. Keep customer records out of these admin APIs and tables.
- `mobile/app/`: Expo Router entry, navigation and customer-facing screens.
- `mobile/src/features/`: customer domain features for dashboard, transactions/categories, bills/reminders, debts/repayments, budgets, calendar, Zakat, reports/exports, settings and gated Premium/ads.
- `mobile/src/db/`: SQLCipher initialization, schema versioning, typed local repositories and transactional persistence.
- `mobile/src/security/`: SecureStore-backed database key, app-lock/PIN/biometric behavior and privacy boundary.
- `mobile/src/i18n/`, `mobile/src/theme/`, `mobile/src/shared/`: locale catalogs, color/type/layout tokens, currencies, decimal-safe money, dates, reusable states and validators.
- `mobile/src/integrations/`: local-notification adapter and separately gated store/ad/backup boundaries; unavailable integrations fail closed and are labeled.
- `mobile/eas.json`, `mobile/assets/`, `mobile/app.config.ts`: native identity, configuration, build profiles and reusable native assets.
- `docs/OWNER-MANUAL-ANDROID.md`: retain the current admin usage guide and extend it with end-user APK installation and the owner-controlled EAS / Play release workflow.
- `docs/MOBILE-INTEGRATION-RESEARCH.md`: sourced native SDK and store constraints.

## Customer-app design direction

Three distinct directions considered: (1) Quiet emerald finance ledger with restrained Uzbek heritage cues, probability 0.07; (2) Soft ivory with geometric fabric-like dividers, probability 0.04; (3) High-contrast midnight budgeting console, probability 0.02. **Selected: quiet emerald finance ledger.**

- **Design Movement:** Contemporary editorial fintech, anchored in the clarity of a paper ledger and a subtle Central Asian sense of craft.
- **Core Principles:** readable at a glance; private by default; calm about money; one-handed tasks should be direct and reversible.
- **Color Philosophy:** warm white and deep ink make long financial lists easy to read; the existing TO‘LOVCHI emerald signals saved/positive states; navy provides calm structure; amber and red appear only for due items, limits and errors. Dark mode uses deep ink surfaces with measured contrast.
- **Layout Paradigm:** portrait-first vertical flows and persistent bottom tabs; the main dashboard is a concise scroll, while forms expand only when the user adds detail. Avoid dashboard grids that become crowded on small screens.
- **Signature Elements:** a slim emerald ledger rule; short date ribbons on lists; quiet rounded amount cards with aligned tabular figures. Reuse `client/public/brand-mark.svg` rather than inventing a second identity.
- **Interaction Philosophy:** save locally immediately and show the saved state; make destructive actions confirmable and recoverable; use clear empty/offline/permission states rather than false success.
- **Animation:** restrained transitions under 180 ms for navigation and save feedback; no decorative loops; respect reduced-motion preferences and avoid motion during sensitive calculations.
- **Typography System:** platform-native sans for Uzbek, Russian and English; tabular numerals for totals; clear 24/18/16/14-point hierarchy with compact date/meta labels.
- **Brand Essence:** a steady private ledger for everyday life, designed for clarity and peace of mind — calm, useful, discreet.
- **Brand Voice:** plain, reassuring and non-judgmental. Example lines: “Your records stay on this device unless you choose otherwise.” “This is an estimate. Review the assumptions before relying on it.”
- **Wordmark & Logo:** carry the existing custom emerald T ledger-monogram into native app icon/splash files, without baked-in rounded mask corners.
- **Signature Brand Color:** deep ledger emerald `#14836d`.

## Account, release and external constraints

The owner has configured stronger dashboard bootstrap and TOTP-encryption secrets through the secure settings flow; the local dashboard server must be restarted before its status is considered current. Production use still requires an owner-controlled database, domain, source-code repository and backups.

The project has no Expo account/build identity, Google Play Console record, signing key, AdMob publisher/app IDs, store product IDs, mobile analytics/crash/support provider, or cloud backup account connected. The app source and release profiles can be prepared without them, but live purchases, production ad serving, live operational dashboard metrics, customer cloud backup/family sharing, store submission and signed release binaries cannot be claimed complete until owner configuration and end-to-end verification are supplied. Google Play digital features use store billing, not direct card checkout. The Android package identifier is a pre-release placeholder until the owner approves it for the Play listing.
