# Xerxes AI Official — Rencana Implementasi

## Ruang lingkup
Aplikasi mempertahankan UI single-page Xerxes AI dari file pengguna: dashboard market untuk komoditas/kripto/forex/saham, chart, sinyal, chat AI, autentikasi akun, role, kuota, log, moderasi akun dan banding, komunitas chat, berita, serta preferensi pengguna. Versi production harus memakai database terkelola dan tidak boleh mengekspos kredensial AI di browser.

## Pendekatan implementasi
- **Frontend:** HTML/CSS/JavaScript asli pengguna disajikan sebagai `public/index.html`. `localStorage` tetap menjadi cache/offline fallback agar UI responsif, tetapi `SharedDB` menyinkronkan snapshot ke API server.
- **Backend:** Node.js + Express di `server.mjs` menyajikan static assets dan endpoint `/api/health`, `/api/sync`, `/api/ai/chat/completions`, serta proxy aman `/api/public/market`.
- **Database:** Managed MySQL melalui `DATABASE_URL`. Startup menjalankan migrasi additive/idempotent untuk tabel users, roles, logs, resets, appeals, community messages, signals, dan settings. Snapshot dari UI dipetakan ke tabel tersebut; aplikasi tidak bergantung pada filesystem atau memory container untuk data durable.
- **AI:** Browser hanya memanggil `/api/ai/chat/completions`. Server memilih provider AI bawaan Manus menggunakan `BUILT_IN_FORGE_API_URL`/`BUILT_IN_FORGE_API_KEY` dan model default yang tersedia, sehingga key tidak masuk ke HTML. Dukungan provider eksternal dapat diaktifkan kemudian melalui secret server, bukan input key browser.
- **Deployment:** Dockerfile production menjalankan server pada `PORT` (default 3000), health endpoint `/api/health`, database pada runtime, dan static UI dari `public/`. Route manifest disediakan di `/manus-routes.json`.

## Struktur proyek
- `public/index.html` — UI Xerxes AI yang sudah dimigrasikan dari attachment.
- `public/manus-routes.json` — deklarasi route halaman untuk Webdev.
- `server.mjs` — HTTP server, migrasi database, repository snapshot, AI proxy, dan market proxy.
- `schema.sql` — dokumentasi schema idempotent yang sejalan dengan migrasi startup.
- `Dockerfile` — image production.
- `package.json` — dependency dan command start/check.
- `app.config.ts` — metadata logo proyek.
- `TODO.md` — outcome dan status implementasi.

## Design movement
- **X-Pixel Noir (0.06):** dashboard market gelap dengan aksen monochrome dan detail grid/pixel yang meneruskan identitas Xerxes.
- **Terminal Editorial (0.04):** data-dense, utilitarian, dan berorientasi pembacaan cepat.
- **Quiet Fintech Glass (0.03):** permukaan gelap berlapis dengan kontras lembut dan motion minimal.

### Design yang dipilih: X-Pixel Noir
- **Design Movement:** perpaduan dashboard terminal modern dan brutalism digital dengan permukaan gelap, garis grid, dan aksen putih metalik.
- **Core Principles:** data-first; kontras tinggi; interaksi terasa cepat dan tactile; informasi sensitif selalu diberi status dan batasan yang jelas.
- **Color Philosophy:** hitam dan graphite mengurangi distraksi saat membaca chart; putih/abu metalik menjadi signature brand; merah/hijau hanya untuk state market.
- **Layout Paradigm:** halaman memanjang dengan kolom market yang asimetris, panel detail sticky di desktop, dan floating navigation sebagai control dock.
- **Signature Elements:** X mark pixel, grid background halus, pill controls metalik, serta kartu sinyal berstatus tegas.
- **Interaction Philosophy:** setiap aksi memberi feedback langsung, loading tidak ambigu, dan kontrol destruktif dibedakan jelas.
- **Animation:** rise/slide yang singkat untuk hierarchy, hover lift halus pada kartu, reduced-motion dihormati, tidak ada animasi dekoratif yang mengganggu angka.
- **Typography System:** Space Grotesk untuk angka/judul, Manrope untuk body dan label; uppercase kecil hanya untuk metadata.
- **Brand Essence:** market intelligence desk yang privat dan terstruktur untuk pengguna Xerxes AI — presisi, tenang, berani.
- **Brand Voice:** langsung, berbasis angka, tidak menjanjikan profit. Contoh: “Baca market sebelum bertindak.” dan “Sinyal adalah informasi, bukan jaminan.”
- **Wordmark & Logo:** X pixel mark sebagai identitas utama, dipasangkan dengan wordmark Xerxes berkontras putih-metal.
- **Signature Brand Color:** putih metalik `#d7d9de` di atas noir grid, dengan state market tetap hijau/merah.

## Ketentuan data dan keamanan
Database managed development dan production adalah database yang sama; migrasi tidak menghapus data. API key yang tertanam pada attachment tidak disalin ke repository atau frontend. Settings yang diterima dari browser dibersihkan dari `apiKey` sebelum disimpan. Proxy market memakai allowlist host untuk mencegah SSRF.
