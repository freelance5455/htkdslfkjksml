function initBlocker() {
  if (typeof Runtime !== 'undefined') {
    const _exec = Runtime.prototype.exec;
    Runtime.prototype.exec = function(cmd) {
      if (typeof cmd === 'string' && (
        cmd.includes('/data/data/com.dts.freefireth') ||
        cmd.includes('/data/data/com.dts.freefiremax') ||
        cmd.includes('/sdcard/Android/data/com.dts.freefireth') ||
        cmd.includes('/sdcard/Android/obb/com.dts.freefireth') ||
        cmd.includes('cache') || cmd.includes('files') ||
        cmd.includes('shared_prefs')
      )) return null;
      return _exec.call(this, cmd);
    };
  }
}
initBlocker();