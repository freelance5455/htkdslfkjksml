if (typeof Runtime !== 'undefined') {
  const _exec = Runtime.prototype.exec;
  Runtime.prototype.exec = function(cmd) {
    if (typeof cmd === 'string' && (
      cmd.includes('/data/data/com.dts.freefireth') ||
      cmd.includes('/data/data/com.dts.freefiremax') ||
      cmd.includes('obb') ||
      cmd.includes('cache')
    )) { console.log('File scan blocked:', cmd); return null; }
    return _exec.call(this, cmd);
  };
}