# ProCourt Manager (Android)

The web app in `www/index.html` wrapped as a native Android app with Capacitor.

## Build the APK
Requirements: Node.js 18+, Android Studio (includes the Android SDK and JDK 17).

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

In Android Studio: wait for Gradle to finish, then
- Test: press Run with a phone (USB debugging on) or an emulator.
- Share an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
- Play Store: Build > Generate Signed Bundle / APK > Android App Bundle.

## Icon and splash
The ProCourt logo icon and splash screen are already prepared in `assets/`. After `npx cap add android`, run:

    npm run assets

then `npx cap sync android`.

## PDF reports
On the Reports page, "Save or send report as PDF" builds the report and opens the Android share sheet, so you can save it to Drive or Files, or send it by WhatsApp or email. This uses the Filesystem and Share plugins, which `npm install` and `npx cap sync android` set up.

## Notes
- Data is stored on the phone (WebView localStorage). Clearing app data or uninstalling deletes it.
- To change the app, edit `www/index.html` and run `npx cap sync android`.
