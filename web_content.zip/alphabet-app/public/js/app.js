/* معهد الفابت — واجهة التطبيق (تعمل مع الخادم عبر /api) */
'use strict';

/* ===================== الأدوات الأساسية ===================== */
var db = null, ui = { page: 'dash', v: 0 }, tempImgs = [], pollTimer = null;
var $ = function (id) { return document.getElementById(id); };

function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]; }); }
function today() { var d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function fmt(d) { if (!d) return '—'; var x = new Date(d); if (isNaN(x)) return d; return String(x.getDate()).padStart(2, '0') + '/' + String(x.getMonth() + 1).padStart(2, '0') + '/' + x.getFullYear(); }
function fmtTime(d) { var x = new Date(d); if (isNaN(x)) return ''; var h = x.getHours(), m = x.getMinutes(), ap = h >= 12 ? 'م' : 'ص'; h = h % 12 || 12; return h + ':' + String(m).padStart(2, '0') + ' ' + ap; }
function fmtDT(d) { return fmt(d) + ' ' + fmtTime(d); }
function money(n) { return Number(n || 0).toLocaleString('en-US') + ' ' + ((db && db.set.currency) || 'ل.س'); }
function pct(a, b) { return b > 0 ? Math.round((a / b) * 100) : 0; }
function lastDays(n) {
  var arr = [], d = new Date(), guard = 0;
  while (arr.length < n && guard++ < 200) {
    if (d.getDay() !== 5) arr.push(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'));
    d.setDate(d.getDate() - 1);
  }
  return arr.reverse();
}
function toast(m, t) {
  var el = document.createElement('div'); el.className = 'tt'; el.textContent = m;
  if (t === 'err') el.style.borderRightColor = '#e05252'; if (t === 'warn') el.style.borderRightColor = '#e8a33d';
  $('toasts').appendChild(el);
  setTimeout(function () { el.style.opacity = '0'; el.style.transition = '.3s'; setTimeout(function () { el.remove(); }, 320); }, t === 'err' ? 4200 : 2600);
}

/* ---------- الاتصال بالخادم ---------- */
function api(method, url, body) {
  var opt = { method: method, credentials: 'same-origin', headers: {} };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  return fetch(url, opt).then(function (r) {
    setOffline(false);
    var ct = r.headers.get('content-type') || '';
    return (ct.indexOf('json') > -1 ? r.json() : r.text()).then(function (data) {
      if (r.ok) return data;
      var err = new Error((data && data.error) || 'حدث خطأ'); err.status = r.status; err.code = data && data.code;
      if (r.status === 401 && err.code === 'AUTH' && db) { sessionLost(); }
      if (r.status === 403 && err.code === 'MUST_CHANGE') { forcePasswordChange(); }
      throw err;
    });
  }, function () { setOffline(true); var e = new Error('تعذر الاتصال بالخادم'); e.network = true; throw e; });
}
function setOffline(on) { $('offline').className = on ? 'on' : ''; }
function sessionLost() { db = null; stopPoll(); toast('انتهت الجلسة، سجّل الدخول من جديد', 'warn'); showLogin(); }

/* تنفيذ إجراء: يعطّل الزر، يعرض الخطأ، ثم يحدّث البيانات */
function act(fn, okMsg, keepModal) {
  return Promise.resolve().then(fn).then(function (res) {
    return refresh().then(function () { if (okMsg) toast(okMsg); return res; });
  }).catch(function (e) { toast(e.message || 'فشل التنفيذ', 'err'); return Promise.reject(e); });
}
function submitForm(form, fn, okMsg) {
  var btns = document.querySelectorAll('.md .mf .btn, form button[type=submit]');
  btns.forEach(function (b) { b.disabled = true; });
  return act(fn, okMsg).then(function (r) { return r; }, function () { }).finally(function () { btns.forEach(function (b) { b.disabled = false; }); });
}

/* ===================== البيانات والتحميل ===================== */
function refresh() {
  return api('GET', '/api/bootstrap').then(function (d) { db = d; ui.v = d.v; render(); });
}
function me() { return db ? db.me : null; }
function sBy(id) { return db.students.find(function (x) { return x.id === id; }); }
function tBy(id) { return db.teachers.find(function (x) { return x.id === id; }); }
function pBy(id) { return db.parents.find(function (x) { return x.id === id; }); }
function cBy(id) { return db.classes.find(function (x) { return x.id === id; }); }
function subBy(id) { return db.subjects.find(function (x) { return x.id === id; }); }
function eBy(id) { return db.exams.find(function (x) { return x.id === id; }); }
function kidsOf(p) { return p ? db.students.filter(function (s) { return s.parentId === p.id; }) : []; }
function attStats(sid) {
  var o = db.attStats[sid] || { present: 0, late: 0, absent: 0, excused: 0, total: 0 };
  return { present: o.present, late: o.late, absent: o.absent, excused: o.excused, total: o.total, rate: o.total ? Math.round((o.present + o.late) / o.total * 100) : 0 };
}
function gradesOf(sid) {
  return db.grades.filter(function (g) { return g.studentId === sid; }).map(function (g) {
    var ex = eBy(g.examId); return { g: g, exam: ex, pct: ex ? Math.round(g.score / ex.max * 100) : 0 };
  });
}
function avgOf(sid) { var g = gradesOf(sid); if (!g.length) return null; return Math.round(g.reduce(function (s, x) { return s + x.pct; }, 0) / g.length); }
function paidOf(sid) { return db.pays.filter(function (p) { return p.studentId === sid; }).reduce(function (s, p) { return s + Number(p.amount); }, 0); }
function balOf(sid) { var st = sBy(sid); if (!st) return 0; return Math.max(0, Number(st.fee || 0) - paidOf(sid)); }
function accountOf(role, refId) { return (db.accounts || []).find(function (a) { return a.role === role && a.refId === refId; }); }
function adminUnreadCount() { return db.tickets.filter(function (t) { return t.adminUnread; }).length; }
function userUnreadCount() { return db.tickets.filter(function (t) { return t.userUnread; }).length; }
function adminUnreadByRole(role) { return db.tickets.filter(function (t) { return t.adminUnread && t.userRole === role; }).length; }

var NAV = {
  admin: [['dash', 'لوحة التحكم', '📊'], ['students', 'الطلاب', '🎓'], ['parents', 'أولياء الأمور', '👪'], ['teachers', 'المعلمون', '👨‍🏫'], ['classes', 'الصفوف والمواد', '🏫'], ['att', 'الحضور والغياب', '✅'], ['exams', 'الامتحانات والدرجات', '📝'], ['evals', 'تقييمات الطلاب', '⭐'], ['fin', 'الأقساط والمدفوعات', '💳'], ['notes', 'الإعلانات', '📢'], ['events', 'الفعاليات والمنشورات', '🎉'], ['support', 'خدمة العملاء', '💬'], ['accounts', 'الحسابات', '🔐'], ['audit', 'سجل النشاط', '🕵️'], ['set', 'الإعدادات', '⚙️']],
  teacher: [['dash', 'لوحة التحكم', '📊'], ['myclasses', 'صفوفي وطلابي', '🏫'], ['att', 'تسجيل الحضور', '✅'], ['grades', 'الامتحانات والدرجات', '📝'], ['evals', 'تقييم الطلاب', '⭐'], ['notes', 'الإعلانات', '📢'], ['events', 'الفعاليات', '🎉'], ['support', 'الدعم الفني', '💬']],
  student: [['dash', 'لوحتي', '📊'], ['profile', 'ملفي', '👤'], ['att', 'سجل الحضور', '✅'], ['grades', 'درجاتي', '📝'], ['evals', 'تقييماتي', '⭐'], ['fin', 'أقساطي', '💳'], ['notes', 'الإعلانات', '📢'], ['events', 'الفعاليات', '🎉'], ['support', 'الدعم الفني', '💬']],
  parent: [['dash', 'لوحة التحكم', '📊'], ['att', 'حضور الأبناء', '✅'], ['grades', 'الدرجات', '📝'], ['evals', 'التقييمات', '⭐'], ['fin', 'الأقساط والمدفوعات', '💳'], ['notes', 'الإعلانات', '📢'], ['events', 'الفعاليات', '🎉'], ['support', 'الدعم الفني', '💬']]
};
var ROLE = { admin: 'مدير المعهد', teacher: 'معلم', student: 'طالب', parent: 'ولي أمر' };
var AUD = { all: 'الجميع', students: 'الطلاب', parents: 'أولياء الأمور', teachers: 'المعلمون' };
var EVT_TYPES = {
  event: { label: 'فعالية / حفل', color: '#12c2b5', icon: '🎉' }, exam: { label: 'موعد امتحان', color: '#e6b962', icon: '📝' },
  study: { label: 'وقت مذاكرة', color: '#16375f', icon: '📚' }, holiday: { label: 'عطلة', color: '#1fb47a', icon: '🏖️' },
  announcement: { label: 'إعلان عام', color: '#0ea79b', icon: '📢' }
};
var TK_TYPES = {
  inquiry: { label: 'استفسار', icon: '📋', tag: 'tag-inquiry' }, absence: { label: 'إذن غياب', icon: '📅', tag: 'tag-absence' }, general: { label: 'عام', icon: '✉️', tag: 'tag-general' }
};

/* ===================== التشغيل ===================== */
function boot() {
  api('GET', '/api/me').then(function (r) {
    if (r.user.mustChange) { db = { me: r.user, set: r.set, subjects: [], classes: [], tickets: [], students: [], teachers: [], parents: [], att: [], attStats: {}, exams: [], grades: [], evals: [], pays: [], notes: [], events: [], broadcasts: [] }; hideBoot(); forcePasswordChange(); return; }
    return refresh().then(function () { hideBoot(); startPoll(); });
  }).catch(function (e) {
    hideBoot();
    if (e.network) { showLogin(); toast('تعذر الاتصال بالخادم', 'err'); } else showLogin();
  });
}
function hideBoot() { var b = $('boot'); if (b) b.remove(); }

function startPoll() {
  stopPoll();
  pollTimer = setInterval(function () {
    if (!db || document.hidden) return;
    api('GET', '/api/poll').then(function (p) {
      if (p.v !== ui.v) {
        var ae = document.activeElement, typing = ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName) && ae.value;
        if ($('modal').innerHTML || typing) return;
        return refresh();
      }
    }).catch(function () { });
  }, 15000);
}
function stopPoll() { if (pollTimer) clearInterval(pollTimer); pollTimer = null; }
document.addEventListener('visibilitychange', function () { if (!document.hidden && db) api('GET', '/api/poll').then(function (p) { if (p.v !== ui.v && !$('modal').innerHTML) refresh(); }).catch(function () { }); });

/* ===================== الرسم ===================== */
function render() {
  if (!db || !me()) { showLogin(); return; }
  if (me().mustChange) { forcePasswordChange(); return; }
  var u = me();
  if (!NAV[u.role].some(function (n) { return n[0] === ui.page; }) && ui.page !== 'studentProfile') ui.page = NAV[u.role][0][0];
  if (ui.tkSel && !db.tickets.some(function (t) { return t.id === ui.tkSel; })) ui.tkSel = null;
  /* حفظ ما كتبه المستخدم في الحقول قبل إعادة الرسم */
  var keep = {}, ae = document.activeElement, aeId = ae && ae.id, ss = ae && ae.selectionStart;
  document.querySelectorAll('#content input[id],#content textarea[id]').forEach(function (el) { if (el.value) keep[el.id] = el.value; });
  $('login').style.display = 'none'; $('shell').style.display = '';
  renderShell(u); renderPage(u);
  Object.keys(keep).forEach(function (id) { var el = $(id); if (el && !el.value) el.value = keep[id]; });
  if (aeId && $(aeId)) { try { $(aeId).focus(); if (ss != null) $(aeId).setSelectionRange(ss, ss); } catch (_) { } }
  document.querySelectorAll('.chat-body').forEach(function (b) { b.scrollTop = b.scrollHeight; });
}
function rerender() { render(); }
function go(p, extra) { closeModal(); ui.page = p; if (extra) for (var k in extra) ui[k] = extra[k]; render(); window.scrollTo({ top: 0, behavior: 'smooth' }); }

/* ===================== الدخول ===================== */
function showLogin() {
  $('shell').style.display = 'none'; $('login').style.display = ''; closeModal();
  var inst = 'معهد الفابت التعليمي', mgr = '';
  function draw() {
    $('login').innerHTML = '<div class="box"><div class="logo">A</div><h1>ALPHABET</h1><p>' + esc(inst) + (mgr ? ' — بإدارة ' + esc(mgr) : '') + '</p>' +
      '<form id="lf" onsubmit="doLogin(event)"><label>اسم المستخدم</label><input id="lu" autocomplete="username" autocapitalize="off" required>' +
      '<label>كلمة المرور</label><input id="lp" type="password" autocomplete="current-password" required>' +
      '<button type="submit" id="lbtn">دخول</button></form>' +
      '<div class="demos" style="text-align:center;color:#6b7c93">حسابك يُنشأ من إدارة المعهد. إن نسيت كلمة المرور راجع الإدارة.</div></div>';
    if ($('lu')) $('lu').focus();
  }
  draw();
  api('GET', '/api/public').then(function (r) { inst = r.inst; mgr = r.mgr; draw(); }).catch(function () { });
}
function doLogin(e) {
  e.preventDefault();
  var b = $('lbtn'); b.disabled = true; b.textContent = '…';
  api('POST', '/api/login', { username: $('lu').value.trim(), password: $('lp').value }).then(function (r) {
    ui.page = NAV[r.user.role][0][0]; ui.tkSel = null; ui.tkFilter = 'all'; ui.tkRole = 'all';
    if (r.user.mustChange) { db = { me: r.user, set: r.set, subjects: [], classes: [], tickets: [], students: [], teachers: [], parents: [], att: [], attStats: {}, exams: [], grades: [], evals: [], pays: [], notes: [], events: [], broadcasts: [] }; $('login').style.display = 'none'; forcePasswordChange(); return; }
    return refresh().then(function () { startPoll(); toast('مرحباً ' + r.user.name); });
  }).catch(function (err) { toast(err.message, 'err'); b.disabled = false; b.textContent = 'دخول'; });
}
function logout() {
  api('POST', '/api/logout', {}).catch(function () { }).then(function () { db = null; stopPoll(); ui.tkSel = null; showLogin(); });
}

/* تغيير كلمة المرور (إجباري عند أول دخول أو اختياري) */
function forcePasswordChange() { passwordModal(true); }
function passwordModal(forced) {
  $('shell').style.display = 'none';
  var body = (forced ? '<div class="note-warn">🔐 لأمان حسابك، يجب اختيار كلمة مرور جديدة قبل المتابعة.</div>' : '') +
    '<form id="pwf" onsubmit="savePassword(event,' + (forced ? 'true' : 'false') + ')">' +
    '<div class="fld"><label>كلمة المرور الحالية</label><input type="password" name="cur" autocomplete="current-password" required></div>' +
    '<div class="fld"><label>كلمة المرور الجديدة (8 أحرف على الأقل، أحرف وأرقام)</label><input type="password" name="nw" autocomplete="new-password" required minlength="8"></div>' +
    '<div class="fld"><label>تأكيد كلمة المرور الجديدة</label><input type="password" name="nw2" autocomplete="new-password" required></div></form>';
  var foot = '<button class="btn bp" onclick="$(\'pwf\').requestSubmit()">حفظ</button>' + (forced ? ' <button class="btn bg2" onclick="logout()">خروج</button>' : ' <button class="btn bg2" onclick="closeModal()">إلغاء</button>');
  openModal('تغيير كلمة المرور', body, foot, forced);
  if (forced) $('shell').style.display = 'none';
}
function savePassword(e, forced) {
  e.preventDefault(); var f = e.target;
  if (f.nw.value !== f.nw2.value) { toast('كلمتا المرور غير متطابقتين', 'err'); return; }
  api('POST', '/api/password', { current: f.cur.value, next: f.nw.value }).then(function () {
    closeModal(); toast('تم تغيير كلمة المرور');
    if (forced) { db.me.mustChange = false; return refresh().then(startPoll); }
  }).catch(function (err) { toast(err.message, 'err'); });
}

/* ===================== الهيكل العام ===================== */
function renderShell(u) {
  var items = NAV[u.role].map(function (n) {
    var badge = '';
    if (n[0] === 'support') { var cnt = u.role === 'admin' ? adminUnreadCount() : userUnreadCount(); if (cnt > 0) badge = '<span class="badge-nav">' + cnt + '</span>'; }
    return '<button class="' + (ui.page === n[0] ? 'on' : '') + '" onclick="go(\'' + n[0] + '\')"><span>' + n[2] + '</span> ' + n[1] + badge + '</button>';
  }).join('');
  $('shell').innerHTML =
    '<aside class="side"><div class="brand"><div class="l">A</div><div><b>ALPHABET</b><small>' + esc(db.set.inst) + '</small></div></div><nav>' + items + '</nav><div class="foot">' + esc(db.set.inst) + '<br><b>بإدارة ' + esc(db.set.mgr) + '</b></div></aside>' +
    '<main class="main"><header class="top"><h2 id="ptitle">—<small>' + esc(db.set.year) + '</small></h2><div class="who"><div class="av">' + esc(u.name.replace('أ. ', '').charAt(0)) + '</div><div><b>' + esc(u.name) + '</b><small>' + ROLE[u.role] + '</small></div>' +
    '<button class="btn bg2 sm" title="تغيير كلمة المرور" onclick="passwordModal(false)">🔑</button><button class="logout" onclick="logout()">خروج</button></div></header><div class="content" id="content"></div></main>';
}
function openModal(title, body, footer, locked) {
  $('modal').innerHTML = '<div class="ov" ' + (locked ? '' : 'onclick="if(event.target===this)closeModal()"') + '><div class="md"><div class="mh"><h3>' + title + '</h3>' + (locked ? '' : '<button onclick="closeModal()">✕</button>') + '</div><div class="mb">' + body + '</div>' + (footer ? '<div class="mf">' + footer + '</div>' : '') + '</div></div>';
  var f = document.querySelector('#modal input:not([type=hidden]):not([type=file]),#modal textarea'); if (f) setTimeout(function () { try { f.focus(); } catch (_) { } }, 30);
}
function closeModal() { $('modal').innerHTML = ''; }
function sc(label, val, icon, acc) { return '<div class="stat ' + acc + '"><div class="ic">' + icon + '</div><div class="lbl">' + label + '</div><div class="val">' + val + '</div></div>'; }
function empty(t, ic) { return '<div class="empty"><span class="b">' + (ic || '📭') + '</span>' + t + '</div>'; }
function tbl(head, rows, colspan) { return '<div class="tw"><table><thead><tr>' + head.map(function (h) { return '<th>' + h + '</th>'; }).join('') + '</tr></thead><tbody>' + (rows.length ? rows.join('') : '<tr><td colspan="' + (colspan || head.length) + '">' + empty('لا بيانات') + '</td></tr>') + '</tbody></table></div>'; }
function opts(list, sel, labelFn) { return list.map(function (x) { return '<option value="' + x.id + '" ' + (sel === x.id ? 'selected' : '') + '>' + esc(labelFn ? labelFn(x) : x.name) + '</option>'; }).join(''); }
function saveBtn(formId, label) { return '<button class="btn bp" onclick="$(\'' + formId + '\').requestSubmit()">' + (label || 'حفظ') + '</button> <button class="btn bg2" onclick="closeModal()">إلغاء</button>'; }
function badgeAtt(s) { return s === 'present' ? '<span class="bdg b-ok">حاضر</span>' : s === 'absent' ? '<span class="bdg b-d">غائب</span>' : s === 'late' ? '<span class="bdg b-w">متأخر</span>' : '<span class="bdg b-i">بعذر</span>'; }
function rateBdg(r) { return '<span class="bdg ' + (r >= 85 ? 'b-ok' : r >= 70 ? 'b-w' : 'b-d') + '">' + r + '%</span>'; }

/* عرض بيانات الدخول مرة واحدة */
function showCredentials(title, cred) {
  openModal(title, '<div class="note-warn">⚠️ هذه البيانات تظهر <b>مرة واحدة فقط</b>. سلّمها لصاحب الحساب؛ سيُطلب منه تغيير كلمة المرور عند أول دخول.</div>' +
    '<div class="cred">اسم المستخدم: <code>' + esc(cred.username) + '</code><br>كلمة المرور المؤقتة: <code>' + esc(cred.password) + '</code></div>',
    '<button class="btn bp" onclick="copyText(\'اسم المستخدم: ' + esc(cred.username) + '\\nكلمة المرور: ' + esc(cred.password) + '\')">📋 نسخ</button> <button class="btn bg2" onclick="closeModal()">تم</button>');
}
function copyText(t) {
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function () { toast('تم النسخ'); }, function () { toast('تعذر النسخ', 'err'); });
  else { var a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); toast('تم النسخ'); } catch (_) { } a.remove(); }
}

/* ===================== الرسم البياني ===================== */
function barChart(id, labels, data, color) {
  var cvs = $(id); if (!cvs) return;
  var w = Math.max(cvs.parentNode.clientWidth - 32, 240), h = 190, dpr = window.devicePixelRatio || 1;
  cvs.width = w * dpr; cvs.height = h * dpr; cvs.style.height = h + 'px'; cvs.style.width = '100%';
  var ctx = cvs.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
  var max = Math.max.apply(null, data.concat([1]));
  var padL = 35, padB = 26, padT = 12, padR = 8, plotW = w - padL - padR, plotH = h - padT - padB;
  ctx.strokeStyle = '#e8eff7'; ctx.lineWidth = 1; ctx.font = '10px sans-serif'; ctx.textAlign = 'right';
  for (var i = 0; i <= 4; i++) { var y = padT + plotH * i / 4; ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke(); ctx.fillStyle = '#93a4b8'; ctx.fillText(max >= 1000 ? Math.round(max * (4 - i) / 4 / 1000) + 'k' : Math.round(max * (4 - i) / 4), padL - 5, y + 4); }
  var bw = plotW / Math.max(data.length, 1);
  data.forEach(function (v, i) {
    var bh = Math.max(plotH * (v / max), v > 0 ? 3 : 0), x = padL + bw * i + bw * 0.22, y = padT + plotH - bh;
    var g = ctx.createLinearGradient(0, y, 0, y + bh); g.addColorStop(0, color); g.addColorStop(1, color + '99');
    ctx.fillStyle = g; ctx.beginPath(); var r = 5, bwid = bw * 0.56;
    ctx.moveTo(x + r, y); ctx.lineTo(x + bwid - r, y); ctx.quadraticCurveTo(x + bwid, y, x + bwid, y + r);
    ctx.lineTo(x + bwid, y + bh); ctx.lineTo(x, y + bh); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.fill();
    if (v > 0 && data.length <= 12) { ctx.fillStyle = '#41586f'; ctx.font = 'bold 10px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(v >= 1000 ? Math.round(v / 1000) + 'k' : v, x + bwid / 2, y - 4); }
    ctx.fillStyle = '#7b8da1'; ctx.font = '10px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(labels[i], padL + bw * i + bw * 0.5, h - 8);
  });
}
var rzT; window.addEventListener('resize', function () { clearTimeout(rzT); rzT = setTimeout(function () { if (db && me() && !me().mustChange && ui.page === 'dash') render(); }, 250); });

/* ===================== التوجيه ===================== */
function renderPage(u) {
  var c = $('content');
  var item = NAV[u.role].find(function (n) { return n[0] === ui.page; });
  $('ptitle').innerHTML = (item ? item[1] : (ui.page === 'studentProfile' ? 'ملف الطالب' : '')) + '<small>' + esc(db.set.inst) + ' — ' + esc(db.set.year) + '</small>';
  if (u.role === 'admin') return adminPage(c);
  if (u.role === 'teacher') return teacherPage(c, u);
  if (u.role === 'student') return studentPage(c, u);
  return parentPage(c, u);
}

/* ===================== المدير ===================== */
function adminPage(c) {
  switch (ui.page) {
    case 'dash': return aDash(c); case 'students': return aStudents(c); case 'studentProfile': return aProfile(c);
    case 'parents': return aParents(c); case 'teachers': return aTeachers(c); case 'classes': return aClasses(c);
    case 'att': return aAtt(c); case 'exams': return aExams(c); case 'evals': return aEvals(c); case 'fin': return aFin(c);
    case 'notes': return aNotes(c); case 'events': return aEvents(c); case 'support': return aSupport(c);
    case 'accounts': return aAccounts(c); case 'audit': return aAudit(c); case 'set': return aSet(c); default: return aDash(c);
  }
}
function aDash(c) {
  var t = today();
  var active = db.students.filter(function (s) { return s.status === 'active'; });
  var tAtt = db.att.filter(function (a) { return a.date === t; });
  var pres = tAtt.filter(function (a) { return a.status === 'present'; }).length;
  var abs = tAtt.filter(function (a) { return a.status === 'absent'; }).length;
  var late = tAtt.filter(function (a) { return a.status === 'late'; }).length;
  var expect = active.reduce(function (s, x) { return s + Number(x.fee || 0); }, 0);
  var collect = db.pays.reduce(function (s, p) { return s + Number(p.amount); }, 0);
  var remain = Math.max(0, expect - collect);
  var now = new Date(), mk = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
  var mRev = db.pays.filter(function (p) { return (p.date || '').indexOf(mk) === 0; }).reduce(function (s, p) { return s + Number(p.amount); }, 0);
  var openTickets = db.tickets.filter(function (t) { return t.status === 'open'; }).length;
  var days = lastDays(7);
  var attLabels = days.map(function (d) { return d.slice(5).replace('-', '/'); });
  var attData = days.map(function (d) { return db.att.filter(function (a) { return a.date === d && (a.status === 'present' || a.status === 'late'); }).length; });
  var months = []; for (var i = 5; i >= 0; i--) { var d2 = new Date(now.getFullYear(), now.getMonth() - i, 1); months.push(d2.getFullYear() + '-' + String(d2.getMonth() + 1).padStart(2, '0')); }
  var mLabels = months.map(function (m) { return m.slice(5) + '/' + m.slice(2, 4); });
  var mData = months.map(function (m) { return db.pays.filter(function (p) { return (p.date || '').indexOf(m) === 0; }).reduce(function (s, p) { return s + Number(p.amount); }, 0); });
  var cLabels = db.classes.map(function (x) { return x.name; });
  var cData = db.classes.map(function (cl) { return active.filter(function (s) { return s.classId === cl.id; }).length; });
  c.innerHTML =
    '<div class="grid stats" style="margin-bottom:16px">' + sc('إجمالي الطلاب', active.length, '🎓', 'acc-t') + sc('المعلمون', db.teachers.filter(function (x) { return x.status === 'active'; }).length, '👨‍🏫', 'acc-n') + sc('أولياء الأمور', db.parents.length, '👪', 'acc-g') + sc('تذاكر مفتوحة', openTickets, '💬', 'acc-w') + '</div>' +
    '<div class="grid stats" style="margin-bottom:16px">' + sc('حاضرون اليوم', pres, '✅', 'acc-o') + sc('غائبون اليوم', abs, '❌', 'acc-d') + sc('متأخرون', late, '⏰', 'acc-w') + sc('إيرادات الشهر', money(mRev), '💰', 'acc-t') + '</div>' +
    '<div class="grid grid2" style="margin-bottom:16px"><div class="card"><h3>الحضور — آخر 7 أيام</h3><canvas id="ch1"></canvas></div><div class="card"><h3>التحصيل المالي (6 أشهر)</h3><canvas id="ch2"></canvas></div></div>' +
    '<div class="grid grid2" style="margin-bottom:16px"><div class="card"><h3>توزيع الطلاب</h3><canvas id="ch3"></canvas></div><div class="card"><h3>الوضع المالي</h3>' +
    '<div class="row"><span>إجمالي الأقساط</span><b>' + money(expect) + '</b></div><div class="row"><span>المحصّل</span><b style="color:#12855c">' + money(collect) + '</b></div><div class="row"><span>المتبقي</span><b style="color:#c23b3b">' + money(remain) + '</b></div>' +
    '<div style="margin-top:12px"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:5px"><span class="muted">نسبة التحصيل</span><b>' + pct(collect, expect) + '%</b></div><div class="prog"><i style="width:' + pct(collect, expect) + '%"></i></div></div></div></div>' +
    '<div class="card"><h3>أحدث المنشورات</h3>' + (db.events.length ? '<div class="posts-feed">' + db.events.slice(-2).reverse().map(function (e) { return postCard(e, false); }).join('') + '</div>' : empty('لا منشورات')) + '</div>';
  setTimeout(function () { barChart('ch1', attLabels, attData, '#12c2b5'); barChart('ch2', mLabels, mData, '#e6b962'); barChart('ch3', cLabels, cData, '#16375f'); }, 30);
}

/* ----- الطلاب ----- */
function aStudents(c) {
  var q = (ui.q || '').toLowerCase(); var list = db.students.slice();
  if (ui.fc) list = list.filter(function (s) { return s.classId === ui.fc; });
  if (q) list = list.filter(function (s) { return (s.name + ' ' + s.code).toLowerCase().indexOf(q) > -1; });
  c.innerHTML = '<div class="card"><div class="toolbar"><input id="qsearch" placeholder="🔍 بحث بالاسم أو الرقم..." value="' + esc(ui.q || '') + '" oninput="ui.q=this.value;rerender()"><select onchange="ui.fc=this.value;rerender()"><option value="">كل الصفوف</option>' + opts(db.classes, ui.fc) + '</select><div class="sp"></div><button class="btn bp" onclick="formStudent()">＋ إضافة طالب</button></div>' +
    tbl(['الرقم', 'الاسم', 'الصف', 'الحضور', 'المعدل', 'المتبقي', 'الحالة', 'إجراءات'], list.map(function (s) {
      var st = attStats(s.id), av = avgOf(s.id);
      return '<tr><td style="font-size:11px;color:#6b7c93">' + esc(s.code) + '</td><td><b>' + esc(s.name) + '</b></td><td>' + esc((cBy(s.classId) || {}).name || '—') + '</td><td>' + (st.total ? rateBdg(st.rate) : '—') + '</td><td>' + (av === null ? '—' : av + '%') + '</td><td style="font-size:11.5px">' + money(balOf(s.id)) + '</td><td><span class="bdg ' + (s.status === 'active' ? 'b-ok' : 'b-n') + '">' + (s.status === 'active' ? 'نشط' : 'موقوف') + '</span></td><td style="white-space:nowrap"><button class="btn bg2 sm" onclick="go(\'studentProfile\',{sid:\'' + s.id + '\'})">ملف</button> <button class="btn bg2 sm" onclick="formStudent(\'' + s.id + '\')">تعديل</button></td></tr>';
    }), 8) + '</div>';
}
function formStudent(id) {
  var s = id ? sBy(id) : null;
  if (!db.classes.length) { toast('أضف صفاً دراسياً أولاً من صفحة «الصفوف والمواد»', 'warn'); return; }
  openModal(s ? 'تعديل طالب' : 'إضافة طالب', '<form id="sf" onsubmit="saveStudent(event)"><input type="hidden" name="id" value="' + (s ? s.id : '') + '"><div class="fg">' +
    '<div class="fld"><label>الاسم *</label><input name="name" required maxlength="100" value="' + (s ? esc(s.name) : '') + '"></div>' +
    '<div class="fld"><label>تاريخ الميلاد</label><input type="date" name="birth" value="' + (s ? esc(s.birth) : '') + '"></div>' +
    '<div class="fld"><label>الصف *</label><select name="classId" required>' + opts(db.classes, s && s.classId) + '</select></div>' +
    '<div class="fld"><label>الجنس</label><select name="gender"><option value="">—</option><option ' + (s && s.gender === 'ذكر' ? 'selected' : '') + '>ذكر</option><option ' + (s && s.gender === 'أنثى' ? 'selected' : '') + '>أنثى</option></select></div>' +
    '<div class="fld"><label>ولي الأمر</label><select name="parentId"><option value="">—</option>' + opts(db.parents, s && s.parentId) + '</select></div>' +
    '<div class="fld"><label>القسط السنوي (' + esc(db.set.currency) + ')</label><input type="number" name="fee" min="0" step="1" value="' + (s ? s.fee : 0) + '"></div>' +
    '<div class="fld"><label>الهاتف</label><input name="phone" maxlength="30" value="' + (s ? esc(s.phone) : '') + '"></div>' +
    '<div class="fld"><label>العنوان</label><input name="addr" maxlength="200" value="' + (s ? esc(s.addr) : '') + '"></div>' +
    (s ? '<div class="fld"><label>الحالة</label><select name="status"><option value="active" ' + (s.status === 'active' ? 'selected' : '') + '>نشط</option><option value="inactive" ' + (s.status !== 'active' ? 'selected' : '') + '>موقوف</option></select></div>' : '') +
    '<div class="fld full"><label>ملاحظات داخلية (للإدارة فقط)</label><textarea name="notes" rows="2" maxlength="1000">' + (s ? esc(s.notes) : '') + '</textarea></div></div></form>' +
    (!db.parents.length ? '<div class="note-warn">لا يوجد أولياء أمور بعد؛ يمكنك إضافتهم من صفحة «أولياء الأمور» ثم ربطهم بالطالب.</div>' : ''),
    saveBtn('sf') + (s ? ' <button class="btn bd" style="margin-inline-start:auto" onclick="delStudent(\'' + s.id + '\')">حذف</button>' : ''));
}
function saveStudent(e) {
  e.preventDefault(); var f = e.target, id = f.id.value;
  var data = { name: f.name.value, birth: f.birth.value, classId: f.classId.value, gender: f.gender.value, parentId: f.parentId.value || null, fee: Number(f.fee.value) || 0, phone: f.phone.value, addr: f.addr.value, notes: f.notes.value };
  if (f.status) data.status = f.status.value;
  submitForm(f, function () { return id ? api('PUT', '/api/students/' + id, data) : api('POST', '/api/students', data); }, id ? 'تم تحديث الطالب' : null).then(function (r) {
    if (id) { closeModal(); return; }
    if (r && r.credentials) showCredentials('تم إنشاء الطالب ' + esc(data.name) + ' — ' + esc(r.code), r.credentials);
  });
}
function delStudent(id) {
  var s = sBy(id); if (!confirm('حذف الطالب «' + s.name + '» نهائياً مع حضوره ودرجاته؟\nيُفضّل إيقاف الطالب بدل الحذف.')) return;
  act(function () { return api('DELETE', '/api/students/' + id); }, 'تم الحذف').then(function () { closeModal(); go('students'); }, function () { });
}
function aProfile(c) {
  var s = sBy(ui.sid); if (!s) { c.innerHTML = empty('الطالب غير موجود'); return; }
  var st = attStats(s.id), av = avgOf(s.id), paid = paidOf(s.id), bal = balOf(s.id);
  var gr = gradesOf(s.id), pays = db.pays.filter(function (x) { return x.studentId === s.id; }); var acc = accountOf('student', s.id);
  c.innerHTML = '<div class="toolbar"><button class="btn bg2" onclick="go(\'students\')">→ رجوع</button><div class="sp"></div><button class="btn bg2" onclick="formStudent(\'' + s.id + '\')">✏️ تعديل</button></div>' +
    '<div class="grid stats" style="margin-bottom:14px">' + sc('الحضور', st.total ? st.rate + '%' : '—', '✅', 'acc-o') + sc('المعدل', av === null ? '—' : av + '%', '📈', 'acc-t') + sc('المدفوع', money(paid), '💰', 'acc-g') + sc('المتبقي', money(bal), '⚠️', bal > 0 ? 'acc-d' : 'acc-o') + '</div>' +
    '<div class="card"><h3>معلومات</h3><div class="row"><span>الاسم</span><b>' + esc(s.name) + '</b></div><div class="row"><span>الرقم</span><b>' + esc(s.code) + '</b></div><div class="row"><span>الصف</span><b>' + esc((cBy(s.classId) || {}).name || '—') + '</b></div><div class="row"><span>ولي الأمر</span><b>' + esc((pBy(s.parentId) || {}).name || '—') + '</b></div><div class="row"><span>الميلاد</span><b>' + fmt(s.birth) + '</b></div><div class="row"><span>الهاتف</span><b>' + esc(s.phone || '—') + '</b></div>' +
    (acc ? '<div class="row"><span>اسم المستخدم</span><b style="direction:ltr">' + esc(acc.username) + '</b></div><div class="row"><span>آخر دخول</span><b>' + (acc.lastLogin ? fmtDT(acc.lastLogin) : 'لم يدخل بعد') + '</b></div><div style="margin-top:10px"><button class="btn bg2 sm" onclick="resetPw(\'' + acc.id + '\')">🔑 إعادة تعيين كلمة المرور</button></div>' : '') + '</div>' +
    '<div class="card" style="margin-top:14px"><h3>الدرجات</h3>' + (gr.length ? tbl(['الامتحان', 'المادة', 'الدرجة', 'النسبة'], gr.map(function (g) { return '<tr><td>' + esc(g.exam ? g.exam.title : '—') + '</td><td>' + esc((subBy(g.exam ? g.exam.subjectId : '') || {}).name || '—') + '</td><td><b>' + g.g.score + '/' + (g.exam ? g.exam.max : '—') + '</b></td><td><span class="bdg ' + (g.pct >= 75 ? 'b-ok' : g.pct >= 50 ? 'b-w' : 'b-d') + '">' + g.pct + '%</span></td></tr>'; })) : empty('لا درجات')) + '</div>' +
    '<div class="card" style="margin-top:14px"><h3>المدفوعات</h3>' + (pays.length ? tbl(['المرجع', 'المبلغ', 'التاريخ', ''], pays.map(function (p) { return '<tr><td style="font-size:11px">' + esc(p.ref) + '</td><td><b>' + money(p.amount) + '</b></td><td>' + fmt(p.date) + '</td><td><button class="btn bg2 sm" onclick="printReceipt(\'' + p.id + '\')">إيصال</button></td></tr>'; })) : empty('لا مدفوعات')) + '</div>';
}
function resetPw(accId) {
  var a = db.accounts.find(function (x) { return x.id === accId; });
  if (!confirm('إعادة تعيين كلمة مرور «' + a.username + '»؟ سيتم إنهاء جلساته الحالية.')) return;
  api('POST', '/api/users/' + accId + '/reset-password', {}).then(function (r) { showCredentials('كلمة مرور جديدة', r); refresh(); }).catch(function (e) { toast(e.message, 'err'); });
}

/* ----- أولياء الأمور ----- */
function aParents(c) {
  var q = (ui.q || '').toLowerCase();
  var list = db.parents.filter(function (p) { return !q || p.name.toLowerCase().indexOf(q) > -1; });
  c.innerHTML = '<div class="card"><div class="toolbar"><input id="qsearch" placeholder="🔍 بحث..." value="' + esc(ui.q || '') + '" oninput="ui.q=this.value;rerender()"><div class="sp"></div><button class="btn bp" onclick="formParent()">＋ إضافة ولي أمر</button></div>' +
    tbl(['الاسم', 'الهاتف', 'الأبناء', 'اسم المستخدم', ''], list.map(function (p) {
      var kids = kidsOf(p);
      return '<tr><td><b>' + esc(p.name) + '</b></td><td>' + esc(p.phone || '—') + '</td><td style="font-size:11.5px">' + (kids.map(function (k) { return esc(k.name); }).join('، ') || '—') + '</td><td style="direction:ltr;font-size:12px">' + esc(p.user || '') + '</td><td style="white-space:nowrap"><button class="btn bg2 sm" onclick="formParent(\'' + p.id + '\')">تعديل</button></td></tr>';
    })) + '</div>';
}
function formParent(id) {
  var p = id ? pBy(id) : null;
  openModal(p ? 'تعديل ولي أمر' : 'إضافة ولي أمر', '<form id="pf2" onsubmit="saveParent(event)"><input type="hidden" name="id" value="' + (p ? p.id : '') + '"><div class="fg"><div class="fld full"><label>الاسم *</label><input name="name" required maxlength="100" value="' + (p ? esc(p.name) : '') + '"></div><div class="fld"><label>الهاتف</label><input name="phone" maxlength="30" value="' + (p ? esc(p.phone) : '') + '"></div><div class="fld"><label>البريد</label><input name="email" type="email" maxlength="120" value="' + (p ? esc(p.email) : '') + '"></div></div></form>',
    saveBtn('pf2') + (p ? ' <button class="btn bd" style="margin-inline-start:auto" onclick="delParent(\'' + p.id + '\')">حذف</button>' : ''));
}
function saveParent(e) {
  e.preventDefault(); var f = e.target, id = f.id.value, data = { name: f.name.value, phone: f.phone.value, email: f.email.value };
  submitForm(f, function () { return id ? api('PUT', '/api/parents/' + id, data) : api('POST', '/api/parents', data); }, id ? 'تم التحديث' : null).then(function (r) {
    if (id) { closeModal(); return; } if (r && r.credentials) showCredentials('تم إنشاء حساب ولي الأمر ' + esc(data.name), r.credentials);
  });
}
function delParent(id) {
  if (!confirm('حذف ولي الأمر وحسابه؟')) return;
  act(function () { return api('DELETE', '/api/parents/' + id); }, 'تم الحذف').then(function () { closeModal(); }, function () { });
}

/* ----- المعلمون ----- */
function aTeachers(c) {
  c.innerHTML = '<div class="card"><div class="toolbar"><h3 style="font-size:14px;margin:0">المعلمون</h3><div class="sp"></div><button class="btn bp" onclick="formTeacher()">＋ إضافة</button></div>' +
    tbl(['الاسم', 'التخصص', 'المواد', 'الصفوف', 'اسم المستخدم', 'الحالة', ''], db.teachers.map(function (t) {
      return '<tr><td><b>' + esc(t.name) + '</b></td><td>' + esc(t.spec || '—') + '</td><td style="font-size:11.5px">' + (t.subs.map(function (s) { return esc((subBy(s) || {}).name || ''); }).join('، ') || '—') + '</td><td style="font-size:11.5px">' + (t.classes.map(function (s) { return esc((cBy(s) || {}).name || ''); }).join('، ') || '—') + '</td><td style="direction:ltr;font-size:12px">' + esc(t.user) + '</td><td><span class="bdg ' + (t.status === 'active' ? 'b-ok' : 'b-n') + '">' + (t.status === 'active' ? 'نشط' : 'موقوف') + '</span></td><td><button class="btn bg2 sm" onclick="formTeacher(\'' + t.id + '\')">تعديل</button></td></tr>';
    })) + '</div>';
}
function formTeacher(id) {
  var t = id ? tBy(id) : null;
  var chk = function (name, list, sel) { return '<div class="check-list">' + (list.length ? list.map(function (x) { return '<label><input type="checkbox" name="' + name + '" value="' + x.id + '" ' + (sel && sel.indexOf(x.id) > -1 ? 'checked' : '') + '> ' + esc(x.name) + '</label>'; }).join('') : '<span class="muted" style="font-size:12px">لا يوجد — أضف من «الصفوف والمواد»</span>') + '</div>'; };
  openModal(t ? 'تعديل معلم' : 'إضافة معلم', '<form id="tf" onsubmit="saveTeacher(event)"><input type="hidden" name="id" value="' + (t ? t.id : '') + '"><div class="fg">' +
    '<div class="fld"><label>الاسم *</label><input name="name" required maxlength="100" value="' + (t ? esc(t.name) : '') + '"></div><div class="fld"><label>التخصص</label><input name="spec" maxlength="80" value="' + (t ? esc(t.spec) : '') + '"></div>' +
    '<div class="fld"><label>الهاتف</label><input name="phone" maxlength="30" value="' + (t ? esc(t.phone) : '') + '"></div><div class="fld"><label>البريد</label><input name="email" type="email" value="' + (t ? esc(t.email) : '') + '"></div>' +
    '<div class="fld"><label>اسم المستخدم * (إنجليزي)</label><input name="user" required pattern="[A-Za-z0-9_.\\-]{3,40}" style="direction:ltr" value="' + (t ? esc(t.user) : '') + '"></div>' +
    (t ? '<div class="fld"><label>الحالة</label><select name="status"><option value="active" ' + (t.status === 'active' ? 'selected' : '') + '>نشط</option><option value="inactive" ' + (t.status !== 'active' ? 'selected' : '') + '>موقوف</option></select></div>' : '<div class="fld"><label class="acct-hint">تُولَّد كلمة مرور مؤقتة تلقائياً وتظهر لك بعد الحفظ.</label></div>') +
    '<div class="fld full"><label>المواد التي يدرّسها</label>' + chk('subs', db.subjects, t && t.subs) + '</div><div class="fld full"><label>الصفوف المُسندة إليه</label>' + chk('classes', db.classes, t && t.classes) + '</div></div></form>',
    saveBtn('tf') + (t ? ' <button class="btn bd" style="margin-inline-start:auto" onclick="delTeacher(\'' + t.id + '\')">حذف</button>' : ''));
}
function saveTeacher(e) {
  e.preventDefault(); var f = e.target, id = f.id.value;
  var vals = function (n) { return Array.prototype.map.call(f.querySelectorAll('input[name=' + n + ']:checked'), function (i) { return i.value; }); };
  var data = { name: f.name.value, spec: f.spec.value, phone: f.phone.value, email: f.email.value, user: f.user.value.trim(), subs: vals('subs'), classes: vals('classes') };
  if (f.status) data.status = f.status.value;
  submitForm(f, function () { return id ? api('PUT', '/api/teachers/' + id, data) : api('POST', '/api/teachers', data); }, id ? 'تم تحديث المعلم' : null).then(function (r) {
    if (id) { closeModal(); return; } if (r && r.credentials) showCredentials('تم إنشاء حساب المعلم ' + esc(data.name), r.credentials);
  });
}
function delTeacher(id) {
  if (!confirm('حذف المعلم وحسابه؟ (تبقى امتحاناته وتقييماته في النظام)')) return;
  act(function () { return api('DELETE', '/api/teachers/' + id); }, 'تم الحذف').then(function () { closeModal(); }, function () { });
}

/* ----- الصفوف والمواد ----- */
function aClasses(c) {
  c.innerHTML = '<div class="card" style="margin-bottom:14px"><div class="toolbar"><h3 style="margin:0">الصفوف</h3><div class="sp"></div><button class="btn bp sm" onclick="formClass()">＋ صف</button></div><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">' +
    (db.classes.map(function (cl) { var cnt = db.students.filter(function (s) { return s.classId === cl.id && s.status === 'active'; }).length; return '<div style="border:1px solid #e2eaf3;border-radius:12px;padding:12px;background:#fbfdff"><b>' + esc(cl.name) + '</b><div style="font-size:11.5px;color:#6b7c93;margin:4px 0 8px">' + cnt + ' طالب</div><button class="btn bg2 sm" onclick="formClass(\'' + cl.id + '\')">تعديل</button> <button class="btn bd sm" onclick="delClass(\'' + cl.id + '\')">حذف</button></div>'; }).join('') || empty('لا صفوف — ابدأ بإضافة صف', '🏫')) + '</div></div>' +
    '<div class="card"><div class="toolbar"><h3 style="margin:0">المواد</h3><div class="sp"></div><button class="btn bp sm" onclick="formSubject()">＋ مادة</button></div>' +
    tbl(['المادة', ''], db.subjects.map(function (s) { return '<tr><td>' + esc(s.name) + '</td><td><button class="btn bd sm" onclick="delSub(\'' + s.id + '\')">حذف</button></td></tr>'; })) + '</div>';
}
function formClass(id) {
  var cl = id ? cBy(id) : null;
  openModal(cl ? 'تعديل صف' : 'صف جديد', '<form id="cf" onsubmit="saveClass(event)"><input type="hidden" name="id" value="' + (cl ? cl.id : '') + '"><div class="fld"><label>الاسم *</label><input name="name" required maxlength="60" value="' + (cl ? esc(cl.name) : '') + '"></div><div class="fld"><label>المرحلة</label><input name="grade" maxlength="60" value="' + (cl ? esc(cl.grade) : '') + '"></div></form>', saveBtn('cf'));
}
function saveClass(e) { e.preventDefault(); var f = e.target, id = f.id.value, d = { name: f.name.value, grade: f.grade.value }; submitForm(f, function () { return id ? api('PUT', '/api/classes/' + id, d) : api('POST', '/api/classes', d); }, 'تم').then(closeModal); }
function delClass(id) { if (!confirm('حذف الصف؟')) return; act(function () { return api('DELETE', '/api/classes/' + id); }, 'تم الحذف').catch(function () { }); }
function formSubject() { openModal('مادة جديدة', '<form id="sf2" onsubmit="saveSubject(event)"><div class="fld"><label>الاسم *</label><input name="name" required maxlength="60"></div></form>', saveBtn('sf2')); }
function saveSubject(e) { e.preventDefault(); var f = e.target; submitForm(f, function () { return api('POST', '/api/subjects', { name: f.name.value }); }, 'تم').then(closeModal); }
function delSub(id) { if (!confirm('حذف المادة؟')) return; act(function () { return api('DELETE', '/api/subjects/' + id); }, 'تم الحذف').catch(function () { }); }

/* ----- الحضور (المدير) ----- */
function ensureAttRange(date) {
  if (date >= db.attFrom) return Promise.resolve();
  if (ui.attLoaded && ui.attLoaded[date]) return Promise.resolve();
  return api('GET', '/api/attendance?from=' + date + '&to=' + date).then(function (r) {
    db.att = db.att.filter(function (a) { return a.date !== date; }).concat(r.att);
    ui.attLoaded = ui.attLoaded || {}; ui.attLoaded[date] = true;
  });
}
function setAttDate(key, v) { ui[key] = v; ensureAttRange(v).then(rerender).catch(function (e) { toast(e.message, 'err'); }); }
function aAtt(c) {
  var date = ui.attDate || today(); var cls = ui.attClass || '';
  var recs = db.att.filter(function (a) { return a.date === date; });
  if (cls) recs = recs.filter(function (a) { return a.classId === cls; });
  c.innerHTML = '<div class="card"><div class="toolbar"><input type="date" value="' + date + '" onchange="setAttDate(\'attDate\',this.value)"><select onchange="ui.attClass=this.value;rerender()"><option value="">كل الصفوف</option>' + opts(db.classes, cls) + '</select><div class="sp"></div><span class="muted" style="font-size:12px">يسجّل المعلمون الحضور من حساباتهم</span></div>' +
    tbl(['الطالب', 'الصف', 'المادة', 'الحالة'], recs.map(function (r) { return '<tr><td><b>' + esc((sBy(r.studentId) || {}).name || '—') + '</b></td><td>' + esc((cBy(r.classId) || {}).name || '—') + '</td><td>' + esc((subBy(r.subjectId) || {}).name || 'يوم كامل') + '</td><td>' + badgeAtt(r.status) + '</td></tr>'; })) + '</div>';
}

/* ----- الامتحانات ----- */
function aExams(c) {
  c.innerHTML = '<div class="card"><div class="toolbar"><h3 style="font-size:14px;margin:0">الامتحانات</h3><div class="sp"></div><button class="btn bp" onclick="formExam()">＋ امتحان</button></div>' +
    tbl(['العنوان', 'الصف', 'المادة', 'المعلم', 'التاريخ', 'القصوى', ''], db.exams.slice().reverse().map(function (e) {
      return '<tr><td><b>' + esc(e.title) + '</b></td><td>' + esc((cBy(e.classId) || {}).name || '—') + '</td><td>' + esc((subBy(e.subjectId) || {}).name || '—') + '</td><td style="font-size:11.5px">' + esc((tBy(e.teacherId) || {}).name || '—') + '</td><td>' + fmt(e.date) + '</td><td>' + e.max + '</td><td style="white-space:nowrap"><button class="btn bp sm" onclick="formGrades(\'' + e.id + '\')">درجات</button> <button class="btn bd sm" onclick="delExam(\'' + e.id + '\')">حذف</button></td></tr>';
    })) + '</div>';
}
function formExam(tid) {
  var t = tid ? tBy(tid) : null;
  var cls = t ? db.classes.filter(function (c) { return t.classes.indexOf(c.id) > -1; }) : db.classes;
  var subs = t ? db.subjects.filter(function (s) { return t.subs.indexOf(s.id) > -1; }) : db.subjects;
  if (!cls.length || !subs.length) { toast(t ? 'لم تُسند إليك صفوف أو مواد بعد، راجع الإدارة' : 'أضف الصفوف والمواد أولاً', 'warn'); return; }
  openModal('امتحان جديد', '<form id="ef" onsubmit="saveExam(event)"><div class="fld"><label>العنوان *</label><input name="title" required maxlength="120"></div><div class="fg">' +
    '<div class="fld"><label>الصف</label><select name="classId">' + opts(cls) + '</select></div><div class="fld"><label>المادة</label><select name="subjectId">' + opts(subs) + '</select></div>' +
    (t ? '' : '<div class="fld"><label>المعلم</label><select name="teacherId"><option value="">—</option>' + opts(db.teachers) + '</select></div>') +
    '<div class="fld"><label>التاريخ</label><input type="date" name="date" value="' + today() + '" required></div><div class="fld"><label>الدرجة القصوى</label><input type="number" name="max" value="100" min="1" max="1000"></div><div class="fld"><label>درجة النجاح</label><input type="number" name="pass" value="50" min="0" max="1000"></div></div></form>', saveBtn('ef'));
}
function saveExam(e) {
  e.preventDefault(); var f = e.target;
  var d = { title: f.title.value, classId: f.classId.value, subjectId: f.subjectId.value, date: f.date.value, max: Number(f.max.value) || 100, pass: Number(f.pass.value) };
  if (f.teacherId) d.teacherId = f.teacherId.value || null;
  submitForm(f, function () { return api('POST', '/api/exams', d); }, 'تمت إضافة الامتحان').then(closeModal);
}
function delExam(id) { if (!confirm('حذف الامتحان وجميع درجاته؟')) return; act(function () { return api('DELETE', '/api/exams/' + id); }, 'تم الحذف').catch(function () { }); }
function formGrades(eid) {
  var ex = eBy(eid), students = db.students.filter(function (s) { return s.classId === ex.classId && s.status === 'active'; });
  openModal('درجات — ' + esc(ex.title), '<form id="gf" onsubmit="saveGrades(event,\'' + eid + '\')"><div style="margin-bottom:10px;font-size:12px;color:#6b7c93">الدرجة القصوى: <b>' + ex.max + '</b> — اترك الحقل فارغاً لحذف الدرجة</div>' +
    (students.length ? '<div class="tw"><table><thead><tr><th>الطالب</th><th>الدرجة</th></tr></thead><tbody>' + students.map(function (s) { var g = db.grades.find(function (x) { return x.examId === eid && x.studentId === s.id; }); return '<tr><td>' + esc(s.name) + '</td><td><input type="number" step="0.5" data-sid="' + s.id + '" min="0" max="' + ex.max + '" value="' + (g ? g.score : '') + '" style="width:90px;padding:6px;border:1px solid #e2eaf3;border-radius:6px"></td></tr>'; }).join('') + '</tbody></table></div>' : empty('لا طلاب في هذا الصف')) + '</form>', saveBtn('gf'));
}
function saveGrades(e, eid) {
  e.preventDefault(); var g = {};
  e.target.querySelectorAll('input[data-sid]').forEach(function (i) { g[i.getAttribute('data-sid')] = i.value === '' ? null : Number(i.value); });
  submitForm(e.target, function () { return api('PUT', '/api/exams/' + eid + '/grades', { grades: g }); }, 'تم حفظ الدرجات').then(closeModal);
}

/* ----- التقييمات ----- */
function aEvals(c) {
  c.innerHTML = '<div class="card"><h3>التقييمات</h3>' + tbl(['الطالب', 'المادة', 'المعلم', 'التاريخ', 'التقدير والتعليق', ''], db.evals.slice().reverse().map(function (e) {
    return '<tr><td><b>' + esc((sBy(e.studentId) || {}).name || '—') + '</b></td><td>' + esc((subBy(e.subjectId) || {}).name || '—') + '</td><td style="font-size:11.5px">' + esc((tBy(e.teacherId) || {}).name || '—') + '</td><td>' + fmt(e.date) + '</td><td style="font-size:11.5px">' + (e.rating ? '<span class="bdg b-t">' + esc(e.rating) + '</span> ' : '') + esc(e.comment) + '</td><td><button class="btn bd sm" onclick="delEval(\'' + e.id + '\')">حذف</button></td></tr>';
  })) + '</div>';
}
function delEval(id) { if (!confirm('حذف التقييم؟')) return; act(function () { return api('DELETE', '/api/evaluations/' + id); }, 'تم الحذف').catch(function () { }); }

/* ----- المالية ----- */
function aFin(c) {
  var active = db.students.filter(function (s) { return s.status === 'active'; });
  var total = db.pays.reduce(function (s, p) { return s + Number(p.amount); }, 0);
  var expect = active.reduce(function (s, x) { return s + Number(x.fee || 0); }, 0);
  var q = (ui.q || '').toLowerCase();
  var debtors = active.filter(function (s) { return balOf(s.id) > 0; }).length;
  var pays = db.pays.slice().reverse().filter(function (p) { var s = sBy(p.studentId); return !q || (s && s.name.toLowerCase().indexOf(q) > -1) || p.ref.toLowerCase().indexOf(q) > -1; });
  c.innerHTML = '<div class="grid stats" style="margin-bottom:14px">' + sc('إجمالي الأقساط', money(expect), '💵', 'acc-n') + sc('المحصّل', money(total), '💰', 'acc-o') + sc('المتبقي', money(Math.max(0, expect - total)), '⚠️', 'acc-d') + sc('طلاب عليهم رصيد', debtors, '👥', 'acc-w') + '</div>' +
    '<div class="card"><div class="toolbar"><input id="qsearch" placeholder="🔍 اسم الطالب أو رقم الإيصال" value="' + esc(ui.q || '') + '" oninput="ui.q=this.value;rerender()"><div class="sp"></div><button class="btn bp" onclick="formPay()">＋ دفعة</button></div>' +
    tbl(['المرجع', 'الطالب', 'المبلغ', 'التاريخ', 'المحصّل', ''], pays.map(function (p) { return '<tr><td style="font-size:11px">' + esc(p.ref) + '</td><td><b>' + esc((sBy(p.studentId) || {}).name || '—') + '</b></td><td><b>' + money(p.amount) + '</b></td><td>' + fmt(p.date) + '</td><td style="font-size:11.5px">' + esc(p.by) + '</td><td style="white-space:nowrap"><button class="btn bg2 sm" onclick="printReceipt(\'' + p.id + '\')">إيصال</button> <button class="btn bd sm" onclick="delPay(\'' + p.id + '\')">حذف</button></td></tr>'; })) + '</div>';
}
function formPay(sid) {
  var list = db.students.filter(function (s) { return s.status === 'active'; });
  if (!list.length) { toast('لا يوجد طلاب نشطون', 'warn'); return; }
  openModal('تسجيل دفعة', '<form id="pf" onsubmit="savePay(event)"><div class="fld"><label>الطالب *</label><select name="studentId" required onchange="payHint(this.value)">' + list.map(function (s) { return '<option value="' + s.id + '" ' + (sid === s.id ? 'selected' : '') + '>' + esc(s.name) + ' (' + esc(s.code) + ')</option>'; }).join('') + '</select><div id="payHint" class="acct-hint" style="margin-top:5px"></div></div><div class="fg"><div class="fld"><label>المبلغ *</label><input type="number" name="amount" required min="1" step="1"></div><div class="fld"><label>التاريخ</label><input type="date" name="date" value="' + today() + '"></div><div class="fld full"><label>ملاحظة</label><input name="note" maxlength="200" placeholder="قسط شهري…"></div></div></form>', saveBtn('pf', 'حفظ وطباعة الإيصال'));
  payHint(sid || list[0].id);
}
function payHint(sid) { var el = $('payHint'); if (el && sBy(sid)) el.textContent = 'المتبقي على الطالب: ' + money(balOf(sid)); }
function savePay(e) {
  e.preventDefault(); var f = e.target, amount = Number(f.amount.value);
  if (!amount || amount <= 0) { toast('مبلغ غير صحيح', 'err'); return; }
  submitForm(f, function () { return api('POST', '/api/payments', { studentId: f.studentId.value, amount: amount, date: f.date.value, note: f.note.value }); }, 'تم تسجيل الدفعة').then(function (r) { if (r && r.id) { closeModal(); showReceipt(r.id); } });
}
function delPay(id) { var p = db.pays.find(function (x) { return x.id === id; }); if (!confirm('حذف الدفعة ' + p.ref + ' بقيمة ' + money(p.amount) + '؟')) return; act(function () { return api('DELETE', '/api/payments/' + id); }, 'تم الحذف').catch(function () { }); }

/* ----- الإعلانات (المدير) ----- */
function aNotes(c) {
  c.innerHTML = '<div class="card"><div class="toolbar"><h3 style="font-size:14px;margin:0">الإعلانات</h3><div class="sp"></div><button class="btn bp" onclick="formNote()">＋ إعلان</button></div>' + notesList(true) + '</div>';
}
function notesList(admin) {
  return db.notes.length ? db.notes.slice().reverse().map(function (n) {
    return '<div style="padding:12px 0;border-bottom:1px dashed #eef3f9"><div style="display:flex;justify-content:space-between;gap:8px"><b>' + esc(n.title) + (admin ? ' <span class="bdg b-n">' + AUD[n.audience] + '</span>' : '') + '</b><span style="font-size:11px;color:#6b7c93;white-space:nowrap">' + fmt(n.date) + '</span></div><div style="font-size:12.5px;color:#4b6279;margin-top:5px;white-space:pre-wrap">' + esc(n.body) + '</div>' + (admin ? '<div style="margin-top:6px"><button class="btn bd sm" onclick="delNote(\'' + n.id + '\')">حذف</button></div>' : '') + '</div>';
  }).join('') : empty('لا إعلانات', '📢');
}
function formNote() {
  openModal('إعلان جديد', '<form id="nf" onsubmit="saveNote(event)"><div class="fld"><label>العنوان *</label><input name="title" required maxlength="150"></div><div class="fld"><label>الجمهور</label><select name="audience">' + Object.keys(AUD).map(function (k) { return '<option value="' + k + '">' + AUD[k] + '</option>'; }).join('') + '</select></div><div class="fld"><label>المحتوى *</label><textarea name="body" rows="5" required maxlength="4000"></textarea></div></form>', saveBtn('nf', 'نشر'));
}
function saveNote(e) { e.preventDefault(); var f = e.target; submitForm(f, function () { return api('POST', '/api/announcements', { title: f.title.value, body: f.body.value, audience: f.audience.value, date: today() }); }, 'تم النشر').then(closeModal); }
function delNote(id) { if (!confirm('حذف الإعلان؟')) return; act(function () { return api('DELETE', '/api/announcements/' + id); }, 'تم الحذف').catch(function () { }); }

/* ===================== المنشورات والتفاعل ===================== */
function postCard(p, adminMode) {
  var u = me(), uid2 = u ? u.id : null; var t = EVT_TYPES[p.type] || EVT_TYPES.event;
  var imgs = p.images || [], likes = p.likes || [], comments = p.comments || [];
  var liked = uid2 && likes.some(function (l) { return l.userId === uid2; });
  var authorName = p.author || db.set.mgr, imgsHtml = '';
  if (imgs.length > 0) {
    var g = imgs.length === 1 ? 'g1' : imgs.length === 2 ? 'g2' : imgs.length === 3 ? 'g3' : 'g4';
    imgsHtml = '<div class="post-imgs ' + g + '">';
    var shown = g === 'g4' ? imgs.slice(0, 4) : imgs;
    shown.forEach(function (src, i) { var ov = (g === 'g4' && i === 3 && imgs.length > 4) ? '<div class="overlay">+' + (imgs.length - 3) + '</div>' : ''; imgsHtml += '<div class="iw" onclick="viewImage(\'' + p.id + '\',' + i + ')"><img loading="lazy" alt="" src="' + esc(src) + '">' + ov + '</div>'; });
    imgsHtml += '</div>';
  }
  var metaHtml = '';
  if (likes.length || comments.length) metaHtml = '<div class="post-meta">' + (likes.length ? '<div class="likes" onclick="showLikes(\'' + p.id + '\')">❤️ ' + likes.length + ' إعجاب</div>' : '') + (comments.length ? '<div>💬 ' + comments.length + ' تعليق</div>' : '') + '</div>';
  var actionHtml = '<div class="post-actions"><button class="' + (liked ? 'liked' : '') + '" onclick="toggleLike(\'' + p.id + '\')"><span>' + (liked ? '❤️' : '🤍') + '</span> أعجبني</button><button onclick="focusComment(\'' + p.id + '\')"><span>💬</span> تعليق</button>' + (adminMode ? '<button class="del-btn" onclick="delPost(\'' + p.id + '\')"><span>🗑️</span> حذف</button>' : '') + '</div>';
  var cmHtml = '<div class="post-comments">';
  comments.forEach(function (c) { cmHtml += '<div class="cm"><div class="av">' + esc(c.name.replace('أ. ', '').charAt(0)) + '</div><div class="cc"><b>' + esc(c.name) + '</b><span>' + esc(c.text) + '</span><span class="time">' + fmtTime(c.date) + (u && (u.role === 'admin' || c.userId === u.id) ? ' · <a href="#" style="color:#c23b3b" onclick="delComment(\'' + c.id + '\');return false">حذف</a>' : '') + '</span></div></div>'; });
  cmHtml += '<div class="cm-form"><input id="cm_' + p.id + '" maxlength="1000" placeholder="اكتب تعليقاً..." onkeydown="if(event.key===\'Enter\'){event.preventDefault();addComment(\'' + p.id + '\')}"><button onclick="addComment(\'' + p.id + '\')">إرسال</button></div></div>';
  return '<div class="post"><div class="post-head"><div class="av">' + esc(authorName.replace('أ. ', '').charAt(0)) + '</div><div class="info"><b>' + esc(authorName) + '</b><small>' + fmt(p.date) + (p.time ? ' · ' + esc(p.time) : '') + (p.location ? ' · 📍 ' + esc(p.location) : '') + (adminMode ? ' · ' + AUD[p.audience] : '') + '</small></div><span class="type-badge" style="background:' + t.color + '">' + t.icon + ' ' + t.label + '</span></div><div class="post-body"><h3>' + esc(p.title) + '</h3><p>' + esc(p.body) + '</p></div>' + imgsHtml + metaHtml + actionHtml + cmHtml + '</div>';
}
function findPost(pid) { return db.events.find(function (x) { return x.id === pid; }); }
function viewImage(pid, idx) {
  var p = findPost(pid); if (!p || !p.images || !p.images[idx]) return; var imgs = p.images;
  var body = '<div style="text-align:center"><img alt="" src="' + esc(imgs[idx]) + '" style="max-width:100%;max-height:70vh;border-radius:12px;display:block;margin:0 auto">';
  if (imgs.length > 1) { body += '<div style="margin-top:12px;display:flex;gap:6px;justify-content:center;flex-wrap:wrap">'; imgs.forEach(function (src, i) { body += '<img alt="" src="' + esc(src) + '" onclick="closeModal();viewImage(\'' + pid + '\',' + i + ')" style="width:60px;height:60px;object-fit:cover;border-radius:8px;cursor:pointer;border:2px solid ' + (i === idx ? '#12c2b5' : 'transparent') + '">'; }); body += '</div>'; }
  body += '<div style="margin-top:10px;font-size:12px;color:#6b7c93">' + (idx + 1) + ' من ' + imgs.length + '</div></div>';
  openModal(esc(p.title), body, '<button class="btn bg2" onclick="closeModal()">إغلاق</button>');
}
function showLikes(pid) {
  var p = findPost(pid); if (!p || !p.likes.length) return;
  openModal('الإعجابات (' + p.likes.length + ')', p.likes.map(function (l) { return '<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px dashed #eef3f9"><div style="width:36px;height:36px;border-radius:50%;background:#e0f7f5;color:#0b8f86;display:grid;place-items:center;font-weight:800">' + esc(l.name.replace('أ. ', '').charAt(0)) + '</div><b style="font-size:13px">' + esc(l.name) + '</b></div>'; }).join(''), '<button class="btn bg2" onclick="closeModal()">إغلاق</button>');
}
function toggleLike(pid) {
  var p = findPost(pid), u = me(); if (!p) return;
  var i = p.likes.findIndex(function (l) { return l.userId === u.id; });
  if (i > -1) p.likes.splice(i, 1); else p.likes.push({ userId: u.id, name: u.name, date: new Date().toISOString() });
  render();
  api('POST', '/api/posts/' + pid + '/like', {}).catch(function (e) { toast(e.message, 'err'); refresh(); });
}
function focusComment(pid) { var i = $('cm_' + pid); if (i) i.focus(); }
function addComment(pid) {
  var input = $('cm_' + pid); if (!input) return; var text = input.value.trim(); if (!text) { toast('اكتب تعليقاً', 'err'); return; }
  input.disabled = true;
  api('POST', '/api/posts/' + pid + '/comments', { text: text }).then(function () { input.value = ''; return refresh(); }).then(function () { var n = $('cm_' + pid); if (n) n.focus(); }).catch(function (e) { toast(e.message, 'err'); input.disabled = false; });
}
function delComment(id) { if (!confirm('حذف التعليق؟')) return; act(function () { return api('DELETE', '/api/comments/' + id); }, 'تم الحذف').catch(function () { }); }
function eventsFeed(c, title, admin) {
  var events = db.events.slice().reverse();
  c.innerHTML = '<div class="card" style="margin-bottom:14px"><div class="toolbar"><h3 style="font-size:14px;margin:0">' + title + '</h3><div class="sp"></div>' + (admin ? '<button class="btn bp" onclick="formPost()">＋ منشور</button>' : '') + '</div>' +
    (!admin ? '<div style="font-size:12.5px;color:#6b7c93;margin-bottom:12px">تفاعل مع المنشورات: أعجب ❤️ أو اكتب تعليقاً 💬</div>' : '') +
    (events.length ? '<div class="posts-feed">' + events.map(function (e) { return postCard(e, admin); }).join('') + '</div>' : empty('لا منشورات', '🎉')) + '</div>';
}
function aEvents(c) { eventsFeed(c, '🎉 الفعاليات والمنشورات', true); }
function formPost() {
  tempImgs = [];
  openModal('منشور جديد', '<form id="postf" onsubmit="savePost(event)"><div class="fld"><label>العنوان *</label><input name="title" required maxlength="150"></div><div class="fg">' +
    '<div class="fld"><label>النوع</label><select name="type">' + Object.keys(EVT_TYPES).map(function (k) { return '<option value="' + k + '">' + EVT_TYPES[k].icon + ' ' + EVT_TYPES[k].label + '</option>'; }).join('') + '</select></div>' +
    '<div class="fld"><label>الجمهور</label><select name="audience">' + Object.keys(AUD).map(function (k) { return '<option value="' + k + '">' + AUD[k] + '</option>'; }).join('') + '</select></div>' +
    '<div class="fld"><label>التاريخ</label><input type="date" name="date" value="' + today() + '" required></div><div class="fld"><label>الوقت</label><input name="time" maxlength="40"></div><div class="fld full"><label>المكان</label><input name="location" maxlength="120"></div>' +
    '<div class="fld full"><label>التفاصيل *</label><textarea name="body" rows="4" required maxlength="5000"></textarea></div>' +
    '<div class="fld full"><label>الصور (حتى 10 — تُضغط تلقائياً)</label><input type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple id="postImgFile" onchange="handleImgPick(this)" style="padding:7px;border:1.5px dashed #c7d6e6;border-radius:9px;background:#f9fbfe;width:100%"><div id="postImgsPreview" style="margin-top:8px"></div></div></div></form>', saveBtn('postf', 'نشر'));
  renderImgPreview();
}
function compressImage(file) {
  return new Promise(function (resolve, reject) {
    if (file.type === 'image/gif' && file.size < 1.5 * 1024 * 1024) { var r0 = new FileReader(); r0.onload = function (e) { resolve(e.target.result); }; r0.onerror = reject; r0.readAsDataURL(file); return; }
    var url = URL.createObjectURL(file), img = new Image();
    img.onload = function () {
      var max = 1600, w = img.width, h = img.height, k = Math.min(1, max / Math.max(w, h));
      var cv = document.createElement('canvas'); cv.width = Math.round(w * k); cv.height = Math.round(h * k);
      var ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height); ctx.drawImage(img, 0, 0, cv.width, cv.height);
      URL.revokeObjectURL(url); resolve(cv.toDataURL('image/jpeg', 0.82));
    };
    img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('تعذرت قراءة الصورة')); };
    img.src = url;
  });
}
function handleImgPick(input) {
  var files = Array.prototype.slice.call(input.files || []); if (!files.length) return;
  var chain = Promise.resolve();
  files.forEach(function (f) {
    chain = chain.then(function () {
      if (tempImgs.length >= 10) { toast('الحد الأقصى 10 صور', 'warn'); return; }
      return compressImage(f).then(function (d) { tempImgs.push(d); renderImgPreview(); }).catch(function (e) { toast(e.message, 'err'); });
    });
  });
  chain.then(function () { input.value = ''; });
}
function renderImgPreview() {
  var el = $('postImgsPreview'); if (!el) return;
  if (!tempImgs.length) { el.innerHTML = '<div style="font-size:11.5px;color:#93a4b8">لا صور</div>'; return; }
  el.innerHTML = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:6px">' + tempImgs.map(function (src, i) { return '<div style="position:relative"><img alt="" src="' + src + '" style="width:100%;height:80px;object-fit:cover;border-radius:8px"><button type="button" onclick="removeImg(' + i + ')" style="position:absolute;top:2px;right:2px;width:20px;height:20px;border-radius:50%;background:rgba(0,0,0,.75);color:#fff;font-size:12px;font-weight:800">×</button></div>'; }).join('') + '</div><div style="margin-top:5px;font-size:11px;color:#6b7c93">' + tempImgs.length + ' صورة</div>';
}
function removeImg(i) { tempImgs.splice(i, 1); renderImgPreview(); }
function savePost(e) {
  e.preventDefault(); var f = e.target;
  submitForm(f, function () { return api('POST', '/api/posts', { title: f.title.value, body: f.body.value, type: f.type.value, audience: f.audience.value, date: f.date.value, time: f.time.value, location: f.location.value, images: tempImgs.slice() }); }, 'تم النشر').then(function () { tempImgs = []; closeModal(); });
}
function delPost(id) { if (!confirm('حذف المنشور؟')) return; act(function () { return api('DELETE', '/api/posts/' + id); }, 'تم الحذف').catch(function () { }); }

/* ===================== الدعم الفني ===================== */
function aSupport(c) {
  var roleFilter = ui.tkRole || 'all', f = ui.tkFilter || 'all';
  var tickets = db.tickets.slice().reverse();
  if (roleFilter !== 'all') tickets = tickets.filter(function (t) { return t.userRole === roleFilter; });
  if (f === 'open') tickets = tickets.filter(function (t) { return t.status === 'open'; });
  if (f === 'absence') tickets = tickets.filter(function (t) { return t.type === 'absence'; });
  if (f === 'inquiry') tickets = tickets.filter(function (t) { return t.type === 'inquiry'; });
  var sel = ui.tkSel ? db.tickets.find(function (t) { return t.id === ui.tkSel; }) : null;
  var selId = sel ? sel.id : null;
  var openCount = db.tickets.filter(function (t) { return t.status === 'open'; }).length, absCount = db.tickets.filter(function (t) { return t.type === 'absence' && t.status === 'open'; }).length;
  function cnt(r) { return db.tickets.filter(function (t) { return t.userRole === r; }).length; }
  function tab(role, label) { var un = role === 'all' ? adminUnreadCount() : adminUnreadByRole(role); return '<button class="pill ' + (roleFilter === role ? 'on' : '') + '" onclick="ui.tkRole=\'' + role + '\';ui.tkSel=null;rerender()">' + label + ' (' + (role === 'all' ? db.tickets.length : cnt(role)) + ')' + (un ? '<span class="ub">' + un + '</span>' : '') + '</button>'; }
  c.innerHTML = '<div class="grid stats" style="margin-bottom:14px">' + sc('إجمالي التذاكر', db.tickets.length, '💬', 'acc-t') + sc('مفتوحة', openCount, '📬', 'acc-w') + sc('طلبات إذن معلقة', absCount, '📅', 'acc-d') + sc('رسائل جماعية', db.broadcasts.length, '📢', 'acc-o') + '</div>' +
    '<div class="card" style="margin-bottom:14px"><div style="background:linear-gradient(135deg,#e0f7f5,#d4f2ef);border:1px solid #a9e3c9;border-radius:10px;padding:10px 12px;font-size:11.5px;color:#0b8f86;margin-bottom:14px;line-height:1.6">🔒 <b>خصوصية مطبقة من الخادم</b> · كل تذكرة خاصة بصاحبها ولا يراها غيره · النقطة الحمراء تعني رسالة جديدة</div>' +
    '<div style="display:flex;gap:6px;margin-bottom:12px;flex-wrap:wrap">' + tab('all', '📬 الكل') + tab('student', '🎓 الطلاب') + tab('parent', '👪 أولياء الأمور') + tab('teacher', '👨‍🏫 المعلمون') + '</div>' +
    '<div class="toolbar" style="margin-bottom:0"><select onchange="ui.tkFilter=this.value;ui.tkSel=null;rerender()" style="min-width:170px"><option value="all">كل التذاكر</option><option value="open" ' + (f === 'open' ? 'selected' : '') + '>المفتوحة فقط (' + openCount + ')</option><option value="absence" ' + (f === 'absence' ? 'selected' : '') + '>طلبات الإذن</option><option value="inquiry" ' + (f === 'inquiry' ? 'selected' : '') + '>الاستفسارات</option></select><div class="sp"></div><button class="btn bp" onclick="formBroadcast()">📢 رسالة جماعية</button></div></div>' +
    '<div class="grid support-grid" style="gap:14px"><div class="card" style="padding:12px"><div class="chat-list">' + (tickets.length ? tickets.map(function (t) { return tkRow(t, selId, true); }).join('') : empty('لا تذاكر في هذا القسم', '💬')) + '</div></div>' +
    '<div>' + (sel ? chatView(sel, true) : '<div class="card">' + empty('اختر تذكرة من القائمة', '💬') + '</div>') + bcastList() + '</div></div>';
}
function tkRow(t, selId, adminView) {
  var tt = TK_TYPES[t.type] || TK_TYPES.general, un = adminView ? t.adminUnread : t.userUnread;
  var last = t.messages.length ? t.messages[t.messages.length - 1].text : '';
  return '<div class="tk-item ' + (t.id === selId ? 'active ' : '') + (un ? 'unread' : '') + '" onclick="selectTicket(\'' + t.id + '\')"><div class="av">' + (adminView ? esc(t.userName.replace('أ. ', '').charAt(0)) : tt.icon) + (un ? '<span class="dot"></span>' : '') + '</div>' +
    '<div class="info"><b>' + esc(adminView ? t.userName : t.subject) + (adminView ? ' <span class="type-tag ' + tt.tag + '">' + tt.icon + ' ' + tt.label + '</span>' : '') + '</b><small>' + esc(adminView ? t.subject : last.slice(0, 50)) + '</small></div>' +
    '<div class="meta"><div class="time">' + fmtTime(t.createdAt) + '</div><div class="bdg ' + (t.status === 'open' ? 'b-w' : t.status === 'resolved' ? 'b-ok' : 'b-n') + '" style="margin-top:4px">' + (t.status === 'open' ? 'مفتوح' : t.status === 'resolved' ? 'تم' : 'مغلق') + '</div></div></div>';
}
function selectTicket(id) {
  ui.tkSel = id; var t = db.tickets.find(function (x) { return x.id === id; }), admin = me().role === 'admin';
  if (t && (admin ? t.adminUnread : t.userUnread)) { if (admin) t.adminUnread = false; else t.userUnread = false; api('POST', '/api/tickets/' + id + '/read', {}).catch(function () { }); }
  render();
}
function chatView(t, adminView) {
  var myId = me().id, tt = TK_TYPES[t.type] || TK_TYPES.general;
  var msgs = t.messages.map(function (m) { var isMe = m.senderId === myId; return '<div class="msg ' + (isMe ? 'me' : 'them') + '"><div>' + esc(m.text) + '</div><span class="meta">' + esc(isMe ? 'أنت' : m.senderName) + ' · ' + fmtTime(m.date) + '</span></div>'; }).join('');
  var btns = '';
  if (adminView) {
    if (t.type === 'absence' && t.status === 'open') btns += '<button class="btn bp sm" onclick="approveAbsence(\'' + t.id + '\')">✅ اعتماد الإذن</button> ';
    if (t.status === 'open') btns += '<button class="btn bg2 sm" onclick="closeTicket(\'' + t.id + '\')">🔒 إغلاق</button>'; else if (t.status !== 'resolved') btns += '<button class="btn bg2 sm" onclick="reopenTicket(\'' + t.id + '\')">🔓 إعادة فتح</button>';
  }
  var absInfo = t.type === 'absence' ? '<div class="abs-info"><b>📅 تاريخ الغياب:</b> ' + fmt(t.absenceDate) + ' · <b>السبب:</b> ' + esc(t.reason) + (t.relatedStudentId ? ' · <b>الطالب:</b> ' + esc((sBy(t.relatedStudentId) || {}).name || '') : '') + '</div>' : '';
  var closedTxt = t.status === 'resolved' ? '✅ تم الاعتماد — مغلقة' : '🔒 مغلقة';
  return '<div class="card" style="padding:0;overflow:hidden;margin-bottom:14px"><div class="chat-head"><div><b style="font-size:14px">' + esc(t.subject) + '</b> <span class="type-tag ' + tt.tag + '">' + tt.icon + ' ' + tt.label + '</span><div style="font-size:11px;color:#0b8f86;margin-top:3px;font-weight:600">🔒 ' + (adminView ? 'خاص — ' + esc(t.userName) + ' · ' + (ROLE[t.userRole] || '') : 'خاصة بك — لا يراها غيرك وغير الإدارة') + '</div></div><div style="display:flex;gap:6px;flex-wrap:wrap">' + btns + '</div></div>' +
    '<div class="chat">' + absInfo + '<div class="chat-body" id="chatBody_' + t.id + '">' + msgs + '</div>' +
    (t.status === 'open' ? '<div class="chat-foot"><input id="reply_' + t.id + '" maxlength="4000" placeholder="اكتب رسالتك..." onkeydown="if(event.key===\'Enter\')sendReply(\'' + t.id + '\')"><button onclick="sendReply(\'' + t.id + '\')">إرسال</button></div>' : '<div style="padding:10px;text-align:center;background:#fff;font-size:12px;color:#6b7c93;border-top:1px solid #eef3f9">' + closedTxt + '</div>') + '</div></div>';
}
function sendReply(id) {
  var input = $('reply_' + id); if (!input) return; var text = input.value.trim(); if (!text) return; input.disabled = true;
  api('POST', '/api/tickets/' + id + '/messages', { text: text }).then(function () { input.value = ''; return refresh(); }).then(function () { var n = $('reply_' + id); if (n) n.focus(); }).catch(function (e) { toast(e.message, 'err'); input.disabled = false; });
}
function closeTicket(id) { act(function () { return api('POST', '/api/tickets/' + id + '/close', {}); }, 'أُغلقت').catch(function () { }); }
function reopenTicket(id) { act(function () { return api('POST', '/api/tickets/' + id + '/reopen', {}); }, 'أُعيد فتحها').catch(function () { }); }
function approveAbsence(id) { if (!confirm('اعتماد الإذن وتسجيل الغياب «بعذر» لذلك اليوم؟')) return; act(function () { return api('POST', '/api/tickets/' + id + '/approve', {}); }, 'تم الاعتماد').catch(function () { }); }
function bcastList() {
  if (!db.broadcasts.length) return '';
  return '<div class="card"><h3>📢 الرسائل الجماعية المرسلة</h3>' + db.broadcasts.slice().reverse().map(function (b) { return '<div class="bcast-card"><h4>' + esc(b.title) + '</h4><div class="meta">' + fmt(b.createdAt) + ' · ' + AUD[b.audience] + '</div><p>' + esc(b.body) + '</p>' + (me().role === 'admin' ? '<div class="actions"><button class="btn bd sm" onclick="delBroadcast(\'' + b.id + '\')">حذف</button></div>' : '') + '</div>'; }).join('') + '</div>';
}
function delBroadcast(id) { if (!confirm('حذف الرسالة؟')) return; act(function () { return api('DELETE', '/api/broadcasts/' + id); }, 'تم الحذف').catch(function () { }); }
function formBroadcast() {
  openModal('رسالة جماعية', '<form id="bcf" onsubmit="saveBroadcast(event)"><div class="fld"><label>العنوان *</label><input name="title" required maxlength="150"></div><div class="fld"><label>الجمهور *</label><select name="audience">' + Object.keys(AUD).map(function (k) { return '<option value="' + k + '">' + AUD[k] + '</option>'; }).join('') + '</select></div><div class="fld"><label>الرسالة *</label><textarea name="body" rows="4" required maxlength="4000"></textarea></div></form>', saveBtn('bcf', 'إرسال'));
}
function saveBroadcast(e) { e.preventDefault(); var f = e.target; submitForm(f, function () { return api('POST', '/api/broadcasts', { title: f.title.value, body: f.body.value, audience: f.audience.value }); }, 'تم الإرسال').then(closeModal); }

/* واجهة الدعم للمعلم/الطالب/ولي الأمر */
function uSupport(c, user, role) {
  var myTickets = db.tickets.slice().reverse();
  var sel = ui.tkSel ? db.tickets.find(function (t) { return t.id === ui.tkSel; }) : null;
  var bcs = db.broadcasts.slice().reverse();
  c.innerHTML = '<div class="grid support-grid" style="gap:14px"><div class="card" style="padding:12px">' +
    '<div style="background:linear-gradient(135deg,#e0f7f5,#d4f2ef);border:1px solid #a9e3c9;border-radius:10px;padding:10px 12px;font-size:11.5px;color:#0b8f86;margin-bottom:14px;line-height:1.6">🔒 <b>خصوصية تامة</b><br>رسائلك لا يراها إلا أنت وإدارة المعهد. النقطة الحمراء = رسالة جديدة من الإدارة.</div>' +
    '<button class="btn bp blk" style="margin-bottom:14px" onclick="formTicket(\'' + role + '\')">＋ تذكرة جديدة</button>' +
    '<h3 style="font-size:13px;margin-bottom:8px">📨 رسائل الإدارة (' + bcs.length + ')</h3><div style="max-height:200px;overflow-y:auto;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid #eef3f9">' +
    (bcs.length ? bcs.map(function (b) { return '<div style="padding:8px;background:#f9fbfe;border-radius:8px;margin-bottom:6px;cursor:pointer;border:1px solid #eef3f9" onclick="viewBroadcast(\'' + b.id + '\')"><b style="font-size:12.5px;display:block">' + esc(b.title) + '</b><div style="font-size:11px;color:#6b7c93;margin-top:2px">' + fmt(b.createdAt) + '</div></div>'; }).join('') : '<div style="font-size:11.5px;color:#93a4b8;padding:6px">لا رسائل</div>') + '</div>' +
    '<h3 style="font-size:13px;margin-bottom:8px">🎫 تذاكري (' + myTickets.length + ')</h3><div style="max-height:300px;overflow-y:auto">' + (myTickets.length ? myTickets.map(function (t) { return tkRow(t, ui.tkSel, false); }).join('') : empty('لا تذاكر — اضغط «تذكرة جديدة»', '🎫')) + '</div></div>' +
    '<div>' + (sel ? chatView(sel, false) : '<div class="card">' + empty('اختر تذكرة أو أنشئ واحدة جديدة<br><small style="display:block;margin-top:8px;font-size:11.5px;color:#93a4b8">تواصل مباشر وسري مع إدارة المعهد</small>', '🔒') + '</div>') + '</div></div>';
}
function viewBroadcast(id) { var b = db.broadcasts.find(function (x) { return x.id === id; }); if (!b) return; openModal('📢 ' + esc(b.title), '<div style="font-size:11.5px;color:#6b7c93;margin-bottom:12px">' + fmt(b.createdAt) + ' · ' + esc(b.author) + '</div><div style="font-size:13.5px;line-height:1.7;white-space:pre-wrap;color:#2a3f56">' + esc(b.body) + '</div>', '<button class="btn bg2" onclick="closeModal()">إغلاق</button>'); }
function formTicket(role) {
  var kidsHtml = '';
  if (role === 'parent') { var kids = kidsOf(pBy(me().refId)); kidsHtml = '<div class="fld"><label>الطالب *</label><select name="studentId">' + opts(kids) + '</select></div>'; }
  var absOpt = role === 'teacher' ? '' : '<option value="absence">📅 طلب إذن غياب</option>';
  openModal('تذكرة جديدة', '<form id="tkf" onsubmit="saveTicket(event,\'' + role + '\')"><div class="fld"><label>نوع التذكرة</label><select name="type" onchange="toggleAbsFields(this.value)"><option value="inquiry">📋 استفسار</option>' + absOpt + '<option value="general">✉️ استفسار عام</option></select></div><div class="fld"><label>الموضوع *</label><input name="subject" required maxlength="150" placeholder="مثال: طلب إذن غياب لمرض"></div>' +
    '<div id="absFields" style="display:none">' + kidsHtml + '<div class="fg"><div class="fld"><label>تاريخ الغياب *</label><input type="date" name="absenceDate" value="' + today() + '"></div><div class="fld"><label>السبب *</label><select name="reason"><option>مرض</option><option>ظرف عائلي</option><option>سفر</option><option>أخرى</option></select></div></div></div>' +
    '<div class="fld"><label>الرسالة *</label><textarea name="body" rows="4" required maxlength="4000" placeholder="اكتب تفاصيل استفسارك..."></textarea></div></form>', saveBtn('tkf', 'إرسال'));
}
function toggleAbsFields(v) { var el = $('absFields'); if (el) el.style.display = v === 'absence' ? '' : 'none'; }
function saveTicket(e, role) {
  e.preventDefault(); var f = e.target;
  var d = { type: f.type.value, subject: f.subject.value, body: f.body.value };
  if (d.type === 'absence') { d.absenceDate = f.absenceDate.value; d.reason = f.reason.value; if (role === 'parent') d.studentId = f.studentId.value; }
  submitForm(f, function () { return api('POST', '/api/tickets', d); }, 'تم الإرسال للإدارة ✅').then(function (r) { if (r && r.id) { closeModal(); ui.tkSel = r.id; render(); } });
}

/* ===================== الحسابات / السجل / الإعدادات ===================== */
function aAccounts(c) {
  var q = (ui.q || '').toLowerCase(), rf = ui.accRole || '';
  var list = db.accounts.filter(function (a) { return (!rf || a.role === rf) && (!q || (a.name + ' ' + a.username).toLowerCase().indexOf(q) > -1); });
  c.innerHTML = '<div class="card"><div class="toolbar"><input id="qsearch" placeholder="🔍 بحث بالاسم أو اسم المستخدم" value="' + esc(ui.q || '') + '" oninput="ui.q=this.value;rerender()"><select onchange="ui.accRole=this.value;rerender()"><option value="">كل الأدوار</option>' + Object.keys(ROLE).map(function (k) { return '<option value="' + k + '" ' + (rf === k ? 'selected' : '') + '>' + ROLE[k] + '</option>'; }).join('') + '</select></div>' +
    '<div class="note-warn">كلمات المرور مخزنة مُشفّرة ولا يمكن لأحد (حتى المدير) معرفتها. عند النسيان استخدم «إعادة تعيين» لتوليد كلمة مؤقتة.</div>' +
    tbl(['الاسم', 'الدور', 'اسم المستخدم', 'آخر دخول', 'الحالة', ''], list.map(function (a) {
      var self = a.id === me().id;
      return '<tr><td><b>' + esc(a.name) + '</b></td><td>' + ROLE[a.role] + '</td><td style="direction:ltr;font-size:12px">' + esc(a.username) + '</td><td style="font-size:11.5px">' + (a.lastLogin ? fmtDT(a.lastLogin) : '—') + '</td><td><span class="bdg ' + (a.active ? 'b-ok' : 'b-d') + '">' + (a.active ? 'مفعّل' : 'موقوف') + '</span>' + (a.mustChange ? ' <span class="bdg b-w">لم يغيّر كلمته</span>' : '') + '</td><td style="white-space:nowrap"><button class="btn bg2 sm" onclick="resetPw(\'' + a.id + '\')">🔑 إعادة تعيين</button>' + (self ? '' : ' <button class="btn ' + (a.active ? 'bd' : 'bg2') + ' sm" onclick="toggleActive(\'' + a.id + '\',' + (a.active ? 'false' : 'true') + ')">' + (a.active ? 'إيقاف' : 'تفعيل') + '</button>') + '</td></tr>';
    })) + '</div>';
}
function toggleActive(id, on) { act(function () { return api('PUT', '/api/users/' + id + '/active', { active: on }); }, on ? 'تم التفعيل' : 'تم الإيقاف').catch(function () { }); }
function aAudit(c) {
  c.innerHTML = '<div class="card"><h3>سجل النشاط (آخر 300 عملية)</h3>' + tbl(['المستخدم', 'الدور', 'الإجراء', 'الوقت'], db.audit.map(function (a) { return '<tr><td><b>' + esc(a.name) + '</b></td><td style="font-size:11.5px">' + (ROLE[a.role] || esc(a.role)) + '</td><td style="font-size:12px">' + esc(a.action) + '</td><td style="font-size:11px;color:#6b7c93;white-space:nowrap">' + fmtDT(a.date) + '</td></tr>'; })) + '</div>';
}
function aSet(c) {
  c.innerHTML = '<div class="card"><h3>إعدادات المعهد</h3><form id="setf" onsubmit="saveSet(event)"><div class="fg"><div class="fld"><label>اسم المعهد</label><input name="inst" required maxlength="120" value="' + esc(db.set.inst) + '"></div><div class="fld"><label>المدير</label><input name="mgr" maxlength="120" value="' + esc(db.set.mgr) + '"></div><div class="fld"><label>السنة الدراسية</label><input name="year" maxlength="40" value="' + esc(db.set.year) + '"></div><div class="fld"><label>العملة</label><input name="currency" required maxlength="20" value="' + esc(db.set.currency) + '"></div><div class="fld"><label>الهاتف</label><input name="phone" maxlength="40" value="' + esc(db.set.phone) + '"></div><div class="fld"><label>العنوان</label><input name="addr" maxlength="120" value="' + esc(db.set.addr) + '"></div></div><button class="btn bp" type="submit" style="margin-top:12px">حفظ</button></form></div>' +
    '<div class="card" style="margin-top:14px"><h3>النسخ الاحتياطي</h3><p style="font-size:12.5px;color:#4b6279;line-height:1.8;margin-bottom:10px">نزّل نسخة كاملة من قاعدة البيانات واحتفظ بها في مكان آمن خارج الخادم. يُنصح بنسخة أسبوعية على الأقل. (صور المنشورات تُحفظ في مجلد data/uploads على الخادم.)</p><a class="btn bp" href="/api/backup" download>⬇️ تنزيل نسخة احتياطية</a></div>' +
    '<div class="card" style="margin-top:14px"><h3>حسابي</h3><button class="btn bg2" onclick="passwordModal(false)">🔑 تغيير كلمة المرور</button></div>';
}
function saveSet(e) { e.preventDefault(); var f = e.target; submitForm(f, function () { return api('PUT', '/api/settings', { inst: f.inst.value, mgr: f.mgr.value, year: f.year.value, currency: f.currency.value, phone: f.phone.value, addr: f.addr.value }); }, 'تم حفظ الإعدادات'); }

/* ===================== المعلم ===================== */
function teacherPage(c, u) {
  var t = tBy(u.refId); if (!t) { c.innerHTML = empty('لم يُربط حسابك بملف معلم، راجع الإدارة'); return; }
  switch (ui.page) {
    case 'dash': return tDash(c, t); case 'myclasses': return tClasses(c, t); case 'att': return tAtt(c, t);
    case 'grades': return tGrades(c, t); case 'evals': return tEvals(c, t); case 'notes': return notesPage(c);
    case 'events': return eventsFeed(c, '🎉 الفعاليات والمنشورات', false); case 'support': return uSupport(c, u, 'teacher'); default: return tDash(c, t);
  }
}
function tDash(c, t) {
  var ms = db.students.filter(function (s) { return t.classes.indexOf(s.classId) > -1 && s.status === 'active'; });
  var noAssign = !t.classes.length || !t.subs.length;
  c.innerHTML = (noAssign ? '<div class="note-warn">لم تُسند إليك صفوف أو مواد بعد. راجع إدارة المعهد ليتمكنوا من إسنادها لك.</div>' : '') +
    '<div class="grid stats" style="margin-bottom:14px">' + sc('طلابي', ms.length, '🎓', 'acc-t') + sc('صفوفي', t.classes.length, '🏫', 'acc-n') + sc('امتحاناتي', db.exams.filter(function (e) { return e.teacherId === t.id; }).length, '📝', 'acc-g') + sc('تذاكري', db.tickets.length, '💬', 'acc-w') + '</div>' +
    '<div class="card"><h3>صفوفي</h3><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">' + (t.classes.map(function (cid) { var cl = cBy(cid); if (!cl) return ''; return '<div style="border:1px solid #e2eaf3;border-radius:12px;padding:12px;background:#fbfdff"><b>' + esc(cl.name) + '</b><div style="font-size:11.5px;color:#6b7c93;margin-top:4px">' + ms.filter(function (s) { return s.classId === cid; }).length + ' طالب</div></div>'; }).join('') || empty('لا صفوف مُسندة', '🏫')) + '</div></div>';
}
function tClasses(c, t) {
  var my = db.students.filter(function (s) { return t.classes.indexOf(s.classId) > -1 && s.status === 'active'; });
  c.innerHTML = '<div class="card"><h3>طلابي</h3>' + tbl(['الاسم', 'الصف', 'الحضور', 'المعدل', ''], my.map(function (s) { var st = attStats(s.id), av = avgOf(s.id); return '<tr><td><b>' + esc(s.name) + '</b></td><td>' + esc((cBy(s.classId) || {}).name || '—') + '</td><td>' + (st.total ? rateBdg(st.rate) : '—') + '</td><td>' + (av === null ? '—' : av + '%') + '</td><td><button class="btn bg2 sm" onclick="quickEval(\'' + s.id + '\')">تقييم</button></td></tr>'; })) + '</div>';
}
function tAtt(c, t) {
  if (!t.classes.length || !t.subs.length) { c.innerHTML = '<div class="card">' + empty('لم تُسند إليك صفوف أو مواد بعد. راجع الإدارة.', '🏫') + '</div>'; return; }
  var date = ui.tAttDate || today(), cls = ui.tAttClass && t.classes.indexOf(ui.tAttClass) > -1 ? ui.tAttClass : t.classes[0], sub = ui.tAttSub && t.subs.indexOf(ui.tAttSub) > -1 ? ui.tAttSub : t.subs[0];
  var students = db.students.filter(function (s) { return s.classId === cls && s.status === 'active'; });
  var existing = {}; db.att.filter(function (a) { return a.date === date && a.classId === cls && a.subjectId === sub; }).forEach(function (a) { existing[a.studentId] = a; });
  var radios = function (s, cur, val, cl, label) { return '<td><label class="attopt ' + (cur === val ? cl : '') + '"><input type="radio" ' + (cur === val ? 'checked' : '') + ' onchange="setAtt(\'' + s.id + '\',\'' + cls + '\',\'' + sub + '\',\'' + date + '\',\'' + val + '\')"> ' + label + '</label></td>'; };
  c.innerHTML = '<div class="card"><div class="toolbar"><input type="date" value="' + date + '" onchange="setAttDate(\'tAttDate\',this.value)"><select onchange="ui.tAttClass=this.value;rerender()">' + t.classes.map(function (cid) { return '<option value="' + cid + '" ' + (cls === cid ? 'selected' : '') + '>' + esc((cBy(cid) || {}).name || '') + '</option>'; }).join('') + '</select><select onchange="ui.tAttSub=this.value;rerender()">' + t.subs.map(function (sid) { return '<option value="' + sid + '" ' + (sub === sid ? 'selected' : '') + '>' + esc((subBy(sid) || {}).name || '') + '</option>'; }).join('') + '</select><div class="sp"></div><button class="btn bg2" onclick="markAllPresent(\'' + cls + '\',\'' + sub + '\',\'' + date + '\')">✅ الكل حاضر</button></div>' +
    (students.length ? '<div class="tw"><table><thead><tr><th>الطالب</th><th>حاضر</th><th>غائب</th><th>متأخر</th><th>بعذر</th></tr></thead><tbody>' + students.map(function (s) { var cur = existing[s.id] ? existing[s.id].status : ''; return '<tr><td><b>' + esc(s.name) + '</b>' + (cur ? '' : ' <span class="bdg b-n">لم يُسجَّل</span>') + '</td>' + radios(s, cur, 'present', 'on-p', 'حاضر') + radios(s, cur, 'absent', 'on-a', 'غائب') + radios(s, cur, 'late', 'on-l', 'متأخر') + radios(s, cur, 'excused', 'on-e', 'بعذر') + '</tr>'; }).join('') + '</tbody></table></div>' : empty('لا طلاب في هذا الصف')) + '</div>';
}
function localAtt(sid, cid, sub, date, status) {
  var ex = db.att.find(function (a) { return a.studentId === sid && a.date === date && a.subjectId === sub; });
  var st = db.attStats[sid] = db.attStats[sid] || { present: 0, late: 0, absent: 0, excused: 0, total: 0 };
  if (ex) { st[ex.status] = Math.max(0, st[ex.status] - 1); ex.status = status; st[status]++; }
  else { db.att.push({ id: 'tmp_' + Math.random(), studentId: sid, classId: cid, subjectId: sub, date: date, status: status }); st[status]++; st.total++; }
}
function setAtt(sid, cid, sub, date, status) {
  localAtt(sid, cid, sub, date, status); render();
  api('PUT', '/api/attendance', { studentId: sid, classId: cid, subjectId: sub, date: date, status: status }).catch(function (e) { toast(e.message, 'err'); refresh(); });
}
function markAllPresent(cid, sub, date) {
  if (!confirm('تسجيل جميع طلاب الصف «حاضر» لهذا اليوم؟ (يُستبدل ما سُجّل مسبقاً)')) return;
  act(function () { return api('POST', '/api/attendance/bulk', { classId: cid, subjectId: sub, date: date, status: 'present' }); }, 'تم تسجيل الحضور للجميع').catch(function () { });
}
function tGrades(c, t) {
  var mine = db.exams.filter(function (e) { return e.teacherId === t.id; });
  c.innerHTML = '<div class="card"><div class="toolbar"><h3 style="font-size:14px;margin:0">امتحاناتي</h3><div class="sp"></div><button class="btn bp" onclick="formExam(\'' + t.id + '\')">＋ امتحان</button></div>' +
    tbl(['العنوان', 'الصف', 'المادة', 'التاريخ', ''], mine.slice().reverse().map(function (e) { return '<tr><td><b>' + esc(e.title) + '</b></td><td>' + esc((cBy(e.classId) || {}).name || '—') + '</td><td>' + esc((subBy(e.subjectId) || {}).name || '—') + '</td><td>' + fmt(e.date) + '</td><td style="white-space:nowrap"><button class="btn bp sm" onclick="formGrades(\'' + e.id + '\')">درجات</button> <button class="btn bd sm" onclick="delExam(\'' + e.id + '\')">حذف</button></td></tr>'; })) + '</div>';
}
function tEvals(c, t) {
  c.innerHTML = '<div class="card"><h3>تقييماتي</h3>' + tbl(['الطالب', 'المادة', 'التاريخ', 'التقدير والتعليق', ''], db.evals.slice().reverse().map(function (e) { return '<tr><td><b>' + esc((sBy(e.studentId) || {}).name || '—') + '</b></td><td>' + esc((subBy(e.subjectId) || {}).name || '—') + '</td><td>' + fmt(e.date) + '</td><td style="font-size:11.5px">' + (e.rating ? '<span class="bdg b-t">' + esc(e.rating) + '</span> ' : '') + esc(e.comment) + '</td><td><button class="btn bd sm" onclick="delEval(\'' + e.id + '\')">حذف</button></td></tr>'; })) + '</div>';
}
function quickEval(sid) {
  var t = tBy(me().refId), s = sBy(sid);
  var subs = db.subjects.filter(function (x) { return t.subs.indexOf(x.id) > -1; });
  if (!subs.length) { toast('لم تُسند إليك مواد', 'warn'); return; }
  openModal('تقييم — ' + esc(s.name), '<form id="evf" onsubmit="saveEval(event,\'' + sid + '\')"><div class="fld"><label>المادة</label><select name="subjectId">' + opts(subs) + '</select></div><div class="fld"><label>التقدير</label><select name="rating"><option>ممتاز</option><option>جيد جداً</option><option>جيد</option><option>يحتاج تحسين</option></select></div><div class="fld"><label>التعليق</label><textarea name="comment" rows="3" maxlength="1000"></textarea></div></form>', saveBtn('evf'));
}
function saveEval(e, sid) { e.preventDefault(); var f = e.target; submitForm(f, function () { return api('POST', '/api/evaluations', { studentId: sid, subjectId: f.subjectId.value, rating: f.rating.value, comment: f.comment.value, date: today() }); }, 'تم حفظ التقييم').then(closeModal); }
function notesPage(c) { c.innerHTML = '<div class="card"><h3>الإعلانات</h3>' + notesList(false) + '</div>'; }

/* ===================== الطالب ===================== */
function studentPage(c, u) {
  var s = sBy(u.refId); if (!s) { c.innerHTML = empty('لم يُربط حسابك بملف طالب، راجع الإدارة'); return; }
  switch (ui.page) {
    case 'dash': return sDash(c, s); case 'profile': return sProfile(c, s); case 'att': return attTable(c, s, false); case 'grades': return gradesCard(c, s, false);
    case 'evals': return evalsCard(c, s, false); case 'fin': return finView(c, s, false); case 'notes': return notesPage(c);
    case 'events': return eventsFeed(c, '🎉 الفعاليات والمنشورات', false); case 'support': return uSupport(c, u, 'student'); default: return sDash(c, s);
  }
}
function sDash(c, s) {
  var st = attStats(s.id), av = avgOf(s.id), evs = db.events.slice(-2).reverse();
  c.innerHTML = '<div class="grid stats" style="margin-bottom:14px">' + sc('الحضور', st.total ? st.rate + '%' : '—', '✅', 'acc-o') + sc('المعدل', av === null ? '—' : av + '%', '📈', 'acc-t') + sc('الغياب', st.absent, '❌', 'acc-d') + sc('المتبقي', money(balOf(s.id)), '💳', balOf(s.id) > 0 ? 'acc-w' : 'acc-o') + '</div>' +
    '<div class="card"><h3>بياناتي</h3><div class="row"><span>الاسم</span><b>' + esc(s.name) + '</b></div><div class="row"><span>الرقم</span><b>' + esc(s.code) + '</b></div><div class="row"><span>الصف</span><b>' + esc((cBy(s.classId) || {}).name || '—') + '</b></div></div>' +
    '<div class="card" style="margin-top:14px"><h3>🎉 أحدث المنشورات</h3>' + (evs.length ? '<div class="posts-feed">' + evs.map(function (e) { return postCard(e, false); }).join('') + '</div>' : empty('لا منشورات')) + '</div>';
}
function sProfile(c, s) {
  c.innerHTML = '<div class="card"><h3>ملفي</h3><div class="row"><span>الاسم</span><b>' + esc(s.name) + '</b></div><div class="row"><span>الرقم</span><b>' + esc(s.code) + '</b></div><div class="row"><span>الصف</span><b>' + esc((cBy(s.classId) || {}).name || '—') + '</b></div><div class="row"><span>الميلاد</span><b>' + fmt(s.birth) + '</b></div><div class="row"><span>ولي الأمر</span><b>' + esc((pBy(s.parentId) || {}).name || '—') + '</b></div><div class="row"><span>اسم المستخدم</span><b style="direction:ltr">' + esc(me().username) + '</b></div><div style="margin-top:12px"><button class="btn bg2" onclick="passwordModal(false)">🔑 تغيير كلمة المرور</button></div></div>';
}
function attTable(c, s, parent) {
  var recs = db.att.filter(function (a) { return a.studentId === s.id; }), st = attStats(s.id);
  c.innerHTML = (parent ? pKidsTabs(parent, s.id) : '') + '<div class="grid stats" style="margin-bottom:14px">' + sc('نسبة الحضور', st.total ? st.rate + '%' : '—', '✅', 'acc-o') + sc('حاضر', st.present, '🟢', 'acc-t') + sc('غائب', st.absent, '❌', 'acc-d') + sc('متأخر', st.late, '⏰', 'acc-w') + '</div>' +
    '<div class="card"><h3>سجل الحضور — ' + esc(s.name) + ' <small class="muted" style="font-weight:500">(آخر 60 يوماً)</small></h3>' + tbl(['التاريخ', 'المادة', 'الحالة'], recs.slice().reverse().slice(0, 80).map(function (r) { return '<tr><td>' + fmt(r.date) + '</td><td>' + esc((subBy(r.subjectId) || {}).name || 'يوم كامل') + '</td><td>' + badgeAtt(r.status) + '</td></tr>'; })) + '</div>';
}
function gradesCard(c, s, parent) {
  var gr = gradesOf(s.id);
  c.innerHTML = (parent ? pKidsTabs(parent, s.id) : '') + '<div class="card"><h3>درجات ' + esc(s.name) + '</h3>' + (gr.length ? tbl(['الامتحان', 'المادة', 'التاريخ', 'الدرجة', 'النسبة'], gr.map(function (g) { return '<tr><td>' + esc(g.exam ? g.exam.title : '—') + '</td><td>' + esc((subBy(g.exam ? g.exam.subjectId : '') || {}).name || '—') + '</td><td>' + fmt(g.exam && g.exam.date) + '</td><td><b>' + g.g.score + '/' + (g.exam ? g.exam.max : '—') + '</b></td><td><span class="bdg ' + (g.pct >= 75 ? 'b-ok' : g.pct >= 50 ? 'b-w' : 'b-d') + '">' + g.pct + '%</span></td></tr>'; })) : empty('لا درجات')) + '</div>';
}
function evalsCard(c, s, parent) {
  var evs = db.evals.filter(function (e) { return e.studentId === s.id; });
  c.innerHTML = (parent ? pKidsTabs(parent, s.id) : '') + '<div class="card"><h3>تقييمات ' + esc(s.name) + '</h3>' + (evs.length ? evs.slice().reverse().map(function (e) { return '<div style="padding:10px 0;border-bottom:1px dashed #eef3f9"><div style="display:flex;justify-content:space-between"><b style="font-size:12.5px">' + esc((subBy(e.subjectId) || {}).name || '') + (e.rating ? ' <span class="bdg b-t">' + esc(e.rating) + '</span>' : '') + '</b><span style="font-size:11px;color:#6b7c93">' + fmt(e.date) + '</span></div><div style="font-size:11.5px;color:#6b7c93;margin-top:3px">' + esc(e.comment) + '</div></div>'; }).join('') : empty('لا تقييمات')) + '</div>';
}
function finView(c, s, parent) {
  var paid = paidOf(s.id), bal = balOf(s.id), pays = db.pays.filter(function (p) { return p.studentId === s.id; });
  c.innerHTML = (parent ? pKidsTabs(parent, s.id) : '') + '<div class="grid stats" style="margin-bottom:14px">' + sc('القسط', money(s.fee), '💵', 'acc-n') + sc('المدفوع', money(paid), '💰', 'acc-o') + sc('المتبقي', money(bal), '⚠️', bal > 0 ? 'acc-w' : 'acc-o') + '</div>' +
    '<div class="card"><h3>مدفوعات ' + esc(s.name) + '</h3>' + (pays.length ? tbl(['المرجع', 'المبلغ', 'التاريخ', ''], pays.slice().reverse().map(function (p) { return '<tr><td style="font-size:11px">' + esc(p.ref) + '</td><td><b>' + money(p.amount) + '</b></td><td>' + fmt(p.date) + '</td><td><button class="btn bg2 sm" onclick="printReceipt(\'' + p.id + '\')">إيصال</button></td></tr>'; })) : empty('لا مدفوعات')) + '</div>';
}

/* ===================== ولي الأمر ===================== */
function parentPage(c, u) {
  var p = pBy(u.refId); if (!p) { c.innerHTML = empty('لم يُربط حسابك بملف ولي أمر، راجع الإدارة'); return; }
  var kids = kidsOf(p);
  if (['notes', 'events', 'support'].indexOf(ui.page) === -1 && !kids.length) { c.innerHTML = '<div class="card">' + empty('لا يوجد أبناء مرتبطون بحسابك بعد. راجع الإدارة.', '👪') + '</div>'; return; }
  var s = kids.length ? (sBy(ui.kid) && sBy(ui.kid).parentId === p.id ? sBy(ui.kid) : kids[0]) : null;
  switch (ui.page) {
    case 'dash': return pDash(c, s, kids); case 'att': return attTable(c, s, kids); case 'grades': return gradesCard(c, s, kids);
    case 'evals': return evalsCard(c, s, kids); case 'fin': return finView(c, s, kids); case 'notes': return notesPage(c);
    case 'events': return eventsFeed(c, '🎉 الفعاليات والمنشورات', false); case 'support': return uSupport(c, u, 'parent'); default: return pDash(c, s, kids);
  }
}
function pKidsTabs(kids, activeId) { if (!kids || kids.length < 2) return ''; return '<div style="margin-bottom:14px">' + kids.map(function (s) { return '<button class="pill ' + (activeId === s.id ? 'on' : '') + '" onclick="ui.kid=\'' + s.id + '\';rerender()">' + esc(s.name) + '</button>'; }).join('') + '</div>'; }
function pDash(c, s, kids) {
  var st = attStats(s.id), av = avgOf(s.id), evs = db.events.slice(-2).reverse();
  c.innerHTML = pKidsTabs(kids, s.id) + '<div class="grid stats" style="margin-bottom:14px">' + sc('الحضور', st.total ? st.rate + '%' : '—', '✅', 'acc-o') + sc('المعدل', av === null ? '—' : av + '%', '📈', 'acc-t') + sc('الغياب', st.absent, '❌', 'acc-d') + sc('المتبقي', money(balOf(s.id)), '💳', balOf(s.id) > 0 ? 'acc-w' : 'acc-o') + '</div>' +
    '<div class="card"><h3>معلومات ' + esc(s.name) + '</h3><div class="row"><span>الصف</span><b>' + esc((cBy(s.classId) || {}).name || '—') + '</b></div><div class="row"><span>الرقم</span><b>' + esc(s.code) + '</b></div></div>' +
    '<div class="card" style="margin-top:14px"><h3>🎉 أحدث المنشورات</h3>' + (evs.length ? '<div class="posts-feed">' + evs.map(function (e) { return postCard(e, false); }).join('') + '</div>' : empty('لا منشورات')) + '</div>';
}

/* ===================== الإيصال (طباعة داخل الصفحة بلا نوافذ منبثقة) ===================== */
function receiptHtml(p) {
  var s = sBy(p.studentId) || { name: '—', code: '' };
  return '<div class="rcpt"><div class="head"><h1>' + esc(db.set.inst) + '</h1><div>بإدارة ' + esc(db.set.mgr) + (db.set.phone ? ' — ' + esc(db.set.phone) : '') + '</div></div><h2 style="text-align:center">إيصال قبض</h2><div class="big">' + money(p.amount) + '</div>' +
    '<table style="width:100%;border-collapse:collapse"><tr><td>رقم الإيصال</td><td><b>' + esc(p.ref) + '</b></td></tr><tr><td>الطالب</td><td><b>' + esc(s.name) + '</b> (' + esc(s.code) + ')</td></tr><tr><td>التاريخ</td><td>' + fmt(p.date) + '</td></tr>' + (p.note ? '<tr><td>ملاحظة</td><td>' + esc(p.note) + '</td></tr>' : '') + '<tr><td>المحصّل</td><td>' + esc(p.by) + '</td></tr></table><div class="foot">شكراً لكم — ' + esc(db.set.inst) + '</div></div>';
}
function showReceipt(pid) {
  var p = db.pays.find(function (x) { return x.id === pid; }); if (!p) return;
  openModal('إيصال ' + esc(p.ref), receiptHtml(p), '<button class="btn bp" onclick="printReceipt(\'' + pid + '\',true)">🖨️ طباعة</button> <button class="btn bg2" onclick="closeModal()">إغلاق</button>');
}
function printReceipt(pid, direct) {
  var p = db.pays.find(function (x) { return x.id === pid; }); if (!p) return;
  if (!direct) { showReceipt(pid); return; }
  $('receipt').innerHTML = receiptHtml(p); window.print();
}
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !(db && me() && me().mustChange)) closeModal(); });

/* ===================== PWA ===================== */
if ('serviceWorker' in navigator) window.addEventListener('load', function () { navigator.serviceWorker.register('/sw.js').catch(function () { }); });

boot();
