/* Service worker: يخزّن واجهة التطبيق فقط، ولا يخزّن أي بيانات API أبداً */
const CACHE = 'alphabet-shell-v1';
const SHELL = ['/', '/css/app.css', '/js/app.js', '/manifest.webmanifest', '/icons/icon.svg', '/icons/icon-192.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/') || u.pathname === '/healthz') return;
  // الشبكة أولاً (لتصلك التحديثات)، والكاش عند انقطاع الاتصال
  e.respondWith(fetch(r).then(res => {
    if (res.ok && (SHELL.includes(u.pathname) || u.pathname.startsWith('/uploads/'))) { const c = res.clone(); caches.open(CACHE).then(ca => ca.put(r, c)); }
    return res;
  }).catch(() => caches.match(r).then(m => m || (r.mode === 'navigate' ? caches.match('/') : Response.error()))));
});
