'use strict';
/* نسخة احتياطية متسقة (حتى أثناء عمل الخادم):  npm run backup  [مجلد الوجهة]
   تحتفظ بآخر 14 نسخة. تشمل قاعدة البيانات + صور المنشورات. */
const fs = require('node:fs'), path = require('node:path');
const { open, DATA_DIR } = require('../server/db');
const dest = path.resolve(process.argv[2] || path.join(DATA_DIR, 'backups'));
fs.mkdirSync(dest, { recursive: true });
const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
const file = path.join(dest, `alphabet-${stamp}.db`);
const db = open();
db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
db.close();
const up = path.join(DATA_DIR, 'uploads');
if (fs.existsSync(up)) fs.cpSync(up, path.join(dest, `uploads-${stamp}`), { recursive: true });
const old = fs.readdirSync(dest).filter(f => /^alphabet-.*\.db$/.test(f)).sort();
old.slice(0, Math.max(0, old.length - 14)).forEach(f => {
  fs.unlinkSync(path.join(dest, f));
  fs.rmSync(path.join(dest, f.replace('alphabet-', 'uploads-').replace('.db', '')), { recursive: true, force: true });
});
console.log('✅ تم إنشاء النسخة:', file);
