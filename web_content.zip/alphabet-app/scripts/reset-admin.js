'use strict';
/* استعادة الدخول عند نسيان كلمة مرور المدير:  npm run reset-admin [اسم_المستخدم] */
const sec = require('../server/security');
const { open, nowIso, newId } = require('../server/db');
const db = open();
const name = process.argv[2] || 'admin';
const pw = sec.tempPassword(12);
const u = db.prepare("SELECT id FROM users WHERE username=? AND role='admin'").get(name);
if (u) {
  db.prepare('UPDATE users SET password_hash=?,must_change=1,active=1 WHERE id=?').run(sec.hashPassword(pw), u.id);
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
} else {
  const mgr = db.prepare("SELECT value FROM settings WHERE key='mgr'").get().value;
  db.prepare('INSERT INTO users(id,username,password_hash,role,name,ref_id,active,must_change,created_at) VALUES(?,?,?,?,?,?,1,1,?)').run(newId('u'), name, sec.hashPassword(pw), 'admin', mgr, 'admin', nowIso());
}
console.log(`✅ حساب المدير: ${name}\n   كلمة المرور المؤقتة: ${pw}\n   (ستُطلب منك تغييرها عند الدخول)`);
