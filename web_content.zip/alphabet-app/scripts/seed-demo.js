'use strict';
/**
 * بيانات تجريبية (اختيارية) — للتجربة فقط، لا تشغّله على نظام حقيقي.
 *   node scripts/seed-demo.js
 * كل الحسابات التجريبية كلمة مرورها:  Demo@12345
 */
const sec = require('../server/security');
const { open, tx, newId, nowIso } = require('../server/db');

const db = open();
if (db.prepare('SELECT COUNT(*) c FROM students').get().c > 0 || db.prepare('SELECT COUNT(*) c FROM classes').get().c > 0) {
  console.error('قاعدة البيانات تحتوي بيانات مسبقاً. لن يتم إضافة بيانات تجريبية.');
  process.exit(1);
}
const PW = 'Demo@12345', HASH = sec.hashPassword(PW);
const run = (sql, ...a) => db.prepare(sql).run(...a);
const user = (role, name, ref, username) =>
  run('INSERT INTO users(id,username,password_hash,role,name,ref_id,active,must_change,created_at) VALUES(?,?,?,?,?,?,1,0,?)', newId('u'), username, HASH, role, name, ref, nowIso());
const iso = n => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);

tx(db, () => {
  if (!db.prepare("SELECT 1 FROM users WHERE role='admin'").get()) user('admin', 'أ. ميرزان حنو', 'admin', 'admin');
  const subs = [['s1', 'الرياضيات'], ['s2', 'اللغة العربية'], ['s3', 'اللغة الإنجليزية'], ['s4', 'العلوم'], ['s5', 'الحاسوب'], ['s6', 'الاجتماعيات']];
  subs.forEach(s => run('INSERT INTO subjects(id,name) VALUES(?,?)', ...s));
  const cls = [['c1', 'السابع - أ', 'الصف السابع'], ['c2', 'السابع - ب', 'الصف السابع'], ['c3', 'الثامن - أ', 'الصف الثامن'], ['c4', 'التاسع - أ', 'الصف التاسع'], ['c5', 'الأول الثانوي', 'الأول الثانوي']];
  cls.forEach(c => run('INSERT INTO classes(id,name,grade) VALUES(?,?,?)', ...c));

  const teachers = [
    ['t1', 'أ. سارة يوسف', 'sara', 'الرياضيات', ['s1'], ['c1', 'c3']], ['t2', 'أ. كريم منصور', 'karim', 'اللغة العربية', ['s2'], ['c1', 'c2']],
    ['t3', 'أ. لينا حنا', 'lina', 'الإنجليزية', ['s3'], ['c4', 'c5']], ['t4', 'أ. يوسف سمعان', 'yousef', 'العلوم', ['s4', 's5'], ['c2', 'c3']]
  ];
  teachers.forEach(t => {
    run('INSERT INTO teachers(id,name,spec,phone,email,status) VALUES(?,?,?,?,?,?)', t[0], t[1], t[3], '', '', 'active');
    t[4].forEach(s => run('INSERT INTO teacher_subjects VALUES(?,?)', t[0], s));
    t[5].forEach(c => run('INSERT INTO teacher_classes VALUES(?,?)', t[0], c));
    user('teacher', t[1], t[0], t[2]);
  });

  const parents = [['p1', 'خالد يوسف'], ['p2', 'سامر حنا'], ['p3', 'ناصر عيسى'], ['p4', 'فؤاد مراد'], ['p5', 'علي حسن'], ['p6', 'جورج كرم']];
  parents.forEach((p, i) => { run('INSERT INTO parents(id,name,phone,email) VALUES(?,?,?,?)', p[0], p[1], '', ''); user('parent', p[1], p[0], 'parent' + (i + 1)); });

  const st = [
    ['أحمد خالد', 'c1', 'p1', '2012-03-14', 'ذكر'], ['مريم خالد', 'c1', 'p1', '2012-07-22', 'أنثى'], ['يوسف سامر', 'c1', 'p2', '2012-01-09', 'ذكر'],
    ['لينا سامر', 'c2', 'p2', '2011-11-30', 'أنثى'], ['عمر ناصر', 'c2', 'p3', '2011-05-18', 'ذكر'], ['سارة ناصر', 'c3', 'p3', '2010-09-05', 'أنثى'],
    ['جورج فؤاد', 'c3', 'p4', '2010-12-12', 'ذكر'], ['رنا فؤاد', 'c1', 'p4', '2012-06-01', 'أنثى'], ['محمد علي', 'c4', 'p5', '2009-02-20', 'ذكر'],
    ['هبة علي', 'c4', 'p5', '2009-08-08', 'أنثى'], ['كرم جورج', 'c5', 'p6', '2008-04-16', 'ذكر'], ['نور جورج', 'c5', 'p6', '2008-10-27', 'أنثى']
  ];
  st.forEach((s, i) => {
    const id = 'st' + (i + 1), code = 'ALP-' + (1001 + i);
    run('INSERT INTO students(id,code,name,class_id,parent_id,birth,gender,phone,addr,enroll,status,fee,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
      id, code, s[0], s[1], s[2], s[3], s[4], '', 'دمشق', '2025-09-01', 'active', 1200000, '');
    user('student', s[0], id, 'student' + (i + 1));
  });

  /* حضور آخر 12 يوم دراسة */
  const days = []; for (let n = 0, d = 0; days.length < 12 && d < 40; d++) { const dt = new Date(Date.now() - d * 864e5); if (dt.getDay() !== 5 && dt.getDay() !== 6) days.push(iso(d)); }
  const cmap = { c1: ['s1', 't1'], c2: ['s2', 't2'], c3: ['s1', 't1'], c4: ['s3', 't3'], c5: ['s3', 't3'] };
  let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  days.forEach(date => st.forEach((s, i) => {
    const m = cmap[s[1]], r = rnd(); let status = 'present';
    if (r > 0.93) status = 'absent'; else if (r > 0.86) status = 'late'; else if (r > 0.82) status = 'excused';
    run('INSERT INTO attendance(id,student_id,class_id,subject_id,teacher_id,date,status,note,created_at) VALUES(?,?,?,?,?,?,?,?,?)', newId('a'), 'st' + (i + 1), s[1], m[0], m[1], date, status, '', nowIso());
  }));

  const exams = [['e1', 'اختبار الرياضيات الشهري', 'c1', 's1', 't1', days[9]], ['e2', 'اختبار العربية الشهري', 'c1', 's2', 't2', days[10]], ['e3', 'اختبار الرياضيات — الثامن', 'c3', 's1', 't1', days[10]]];
  exams.forEach(e => {
    run('INSERT INTO exams(id,title,class_id,subject_id,teacher_id,date,max,pass,type) VALUES(?,?,?,?,?,?,?,?,?)', ...e, 100, 50, 'شهري');
    st.forEach((s, i) => { if (s[1] === e[2]) run('INSERT INTO grades(id,exam_id,student_id,score,created_at) VALUES(?,?,?,?,?)', newId('g'), e[0], 'st' + (i + 1), Math.round(55 + rnd() * 45), nowIso()); });
  });
  run('INSERT INTO evaluations(id,student_id,subject_id,teacher_id,date,rating,comment) VALUES(?,?,?,?,?,?,?)', newId('ev'), 'st1', 's1', 't1', days[1], 'جيد جداً', 'الطالب يُظهر تقدماً جيداً ويشارك بفعالية.');

  [500000, 300000, 700000, 250000, 400000, 600000, 350000, 200000, 800000, 450000, 300000, 150000].forEach((amt, i) =>
    run('INSERT INTO payments(id,student_id,amount,date,method,ref,note,by_name,created_at) VALUES(?,?,?,?,?,?,?,?,?)', newId('p'), 'st' + (i + 1), amt, days[Math.min(i, 11)], 'cash', 'RC-' + (100001 + i), 'قسط', 'أ. ميرزان حنو', nowIso()));

  run('INSERT INTO announcements(id,title,body,audience,date,author) VALUES(?,?,?,?,?,?)', newId('n'), 'بدء الامتحانات الشهرية', 'تبدأ الامتحانات الشهرية الأحد القادم لجميع الصفوف.', 'all', iso(3), 'أ. ميرزان حنو');
  run('INSERT INTO posts(id,title,body,type,audience,date,time,location,author,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)', newId('evt'), 'حفل تكريم الطلاب المتفوقين', 'يسر إدارة المعهد دعوة الطلاب المتفوقين وأولياء أمورهم لحضور حفل التكريم السنوي. 🌟', 'event', 'all', iso(2), '10:00 صباحاً', 'قاعة المعهد الرئيسية', 'أ. ميرزان حنو', nowIso());
  run('INSERT INTO posts(id,title,body,type,audience,date,time,location,author,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)', newId('evt'), 'جدول امتحانات الفصل الأول', 'نشر جدول امتحانات الفصل الأول. يرجى الاستعداد الجيد. بالتوفيق 📚', 'exam', 'all', iso(1), '', '', 'أ. ميرزان حنو', nowIso());
  run('INSERT INTO broadcasts(id,title,body,audience,author,created_at) VALUES(?,?,?,?,?,?)', newId('bc'), 'أهلاً بكم في خدمة الدعم الفني', 'يمكنكم الآن التواصل المباشر مع إدارة المعهد لأي استفسار أو طلب إذن غياب.', 'all', 'أ. ميرزان حنو', nowIso());
});
console.log('✅ تمت إضافة البيانات التجريبية. كلمة مرور الحسابات التجريبية:', PW);
console.log('   مدير: admin | معلمة: sara | طالب: student1 | ولي أمر: parent1');
