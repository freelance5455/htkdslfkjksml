'use strict';
const crypto = require('node:crypto');

/* ---------- كلمات المرور: scrypt مع ملح عشوائي ---------- */
const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64 };

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const dk = crypto.scryptSync(pw, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${dk.toString('base64')}`;
}

function verifyPassword(pw, stored) {
  try {
    const [alg, N, r, p, saltB64, hashB64] = String(stored).split('$');
    if (alg !== 'scrypt') return false;
    const expected = Buffer.from(hashB64, 'base64');
    const dk = crypto.scryptSync(pw, Buffer.from(saltB64, 'base64'), expected.length, { N: +N, r: +r, p: +p });
    return crypto.timingSafeEqual(dk, expected);
  } catch { return false; }
}

// تجزئة وهمية لتثبيت زمن الاستجابة عند اسم مستخدم غير موجود
const DUMMY_HASH = hashPassword('dummy-password-for-timing');

/* ---------- الجلسات ---------- */
const newToken = () => crypto.randomBytes(32).toString('base64url');
const hashToken = t => crypto.createHash('sha256').update(t).digest('hex');

/* ---------- كلمة مرور مؤقتة مقروءة (بدون أحرف ملتبسة) ---------- */
function tempPassword(len = 9) {
  const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i = 0; i < len; i++) s += chars[crypto.randomInt(chars.length)];
  return s;
}

function checkPasswordPolicy(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'كلمة المرور يجب ألا تقل عن 8 أحرف';
  if (pw.length > 128) return 'كلمة المرور طويلة جداً';
  if (!/[A-Za-z؀-ۿ]/.test(pw) || !/\d/.test(pw)) return 'يجب أن تحتوي كلمة المرور على أحرف وأرقام';
  return null;
}

/* ---------- تحديد محاولات الدخول (في الذاكرة) ---------- */
class RateLimiter {
  constructor(max, windowMs) { this.max = max; this.win = windowMs; this.m = new Map(); }
  _clean(k, now) {
    const a = (this.m.get(k) || []).filter(t => now - t < this.win);
    if (a.length) this.m.set(k, a); else this.m.delete(k);
    return a;
  }
  blocked(k) { return this._clean(k, Date.now()).length >= this.max; }
  retryAfterSec(k) {
    const a = this._clean(k, Date.now());
    return a.length ? Math.ceil((a[0] + this.win - Date.now()) / 1000) : 0;
  }
  hit(k) { const now = Date.now(); const a = this._clean(k, now); a.push(now); this.m.set(k, a); }
  reset(k) { this.m.delete(k); }
}

module.exports = {
  hashPassword, verifyPassword, DUMMY_HASH, newToken, hashToken,
  tempPassword, checkPasswordPolicy, RateLimiter
};
