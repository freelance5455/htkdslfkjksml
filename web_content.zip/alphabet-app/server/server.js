'use strict';
/**
 * معهد الفابت — خادم التطبيق
 * تشغيل:  node server/server.js     (المنفذ الافتراضي 3000)
 */
const http = require('node:http');
const path = require('node:path');
const sec = require('./security');
const dbmod = require('./db');
const createApi = require('./api');
const { serveFile, sendJson } = require('./http');

const PUBLIC_DIR = path.resolve(__dirname, '..', 'public');

const CSP = [
  "default-src 'self'", "img-src 'self' data: blob:", "style-src 'self' 'unsafe-inline'",
  "script-src 'self' 'unsafe-inline'", "connect-src 'self'", "manifest-src 'self'", "worker-src 'self'",
  "frame-ancestors 'none'", "base-uri 'none'", "form-action 'self'", "object-src 'none'"
].join('; ');

function ensureFirstAdmin(db) {
  const n = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  if (n > 0) return null;
  const username = process.env.ADMIN_USERNAME || 'admin';
  const given = process.env.ADMIN_PASSWORD;
  const pw = given || sec.tempPassword(12);
  db.prepare('INSERT INTO users(id,username,password_hash,role,name,ref_id,active,must_change,created_at) VALUES(?,?,?,?,?,?,1,1,?)')
    .run(dbmod.newId('u'), username, sec.hashPassword(pw), 'admin', db.prepare("SELECT value FROM settings WHERE key='mgr'").get().value, 'admin', dbmod.nowIso());
  return { username, password: given ? null : pw };
}

function createServer(opts) {
  opts = opts || {};
  const db = opts.db || dbmod.open();
  const config = {
    trustProxy: opts.trustProxy !== undefined ? opts.trustProxy : process.env.TRUST_PROXY === '1',
    secureCookies: opts.secureCookies !== undefined ? opts.secureCookies : process.env.COOKIE_SECURE === '1',
    logRequests: process.env.LOG_REQUESTS === '1'
  };
  const first = ensureFirstAdmin(db);
  const api = createApi(db, config);

  const server = http.createServer((req, res) => {
    const t0 = Date.now();
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    res.setHeader('Content-Security-Policy', CSP);
    if (config.secureCookies || (config.trustProxy && req.headers['x-forwarded-proto'] === 'https'))
      res.setHeader('Strict-Transport-Security', 'max-age=31536000');
    if (config.logRequests) res.on('finish', () => console.log(`${req.method} ${req.url} ${res.statusCode} ${Date.now() - t0}ms`));

    let url;
    try { url = new URL(req.url, 'http://localhost'); } catch { return sendJson(res, 400, { error: 'طلب غير صالح' }); }
    const p = url.pathname;

    if (p === '/healthz') return sendJson(res, 200, { ok: true });
    if (p.startsWith('/api/')) return api.handle(req, res, url);

    if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, { error: 'الطريقة غير مسموحة' });

    if (p.startsWith('/uploads/')) {
      if (!/^\/uploads\/[a-f0-9]{24}\.(jpg|png|webp|gif)$/.test(p)) return sendJson(res, 404, { error: 'غير موجود' });
      if (serveFile(req, res, path.join(dbmod.DATA_DIR, 'uploads'), p.slice('/uploads/'.length), { immutable: true })) return;
      return sendJson(res, 404, { error: 'غير موجود' });
    }
    if (p === '/sw.js') { res.setHeader('Service-Worker-Allowed', '/'); }
    const rel = p === '/' ? 'index.html' : p.slice(1);
    if (serveFile(req, res, PUBLIC_DIR, rel)) return;
    if (!path.extname(p)) { if (serveFile(req, res, PUBLIC_DIR, 'index.html')) return; }
    sendJson(res, 404, { error: 'غير موجود' });
  });
  server.requestTimeout = 60e3;
  server.headersTimeout = 20e3;
  return { server, db, first, api };
}

if (require.main === module) {
  const port = Number(process.env.PORT || 3000);
  const host = process.env.HOST || '0.0.0.0';
  const { server, db, first } = createServer();
  server.listen(port, host, () => {
    console.log(`\n✅ معهد الفابت يعمل على: http://localhost:${port}`);
    if (first) {
      console.log('────────────────────────────────────────────');
      console.log(' أول تشغيل — تم إنشاء حساب المدير:');
      console.log('   اسم المستخدم :', first.username);
      if (first.password) console.log('   كلمة المرور  :', first.password, '  (احفظها الآن، ستُطلب منك تغييرها عند الدخول)');
      else console.log('   كلمة المرور  : (من متغير ADMIN_PASSWORD) — ستُطلب منك تغييرها عند الدخول');
      console.log('────────────────────────────────────────────\n');
    }
  });
  const shutdown = sig => {
    console.log(`\n${sig}: إيقاف الخادم...`);
    server.close(() => { try { db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); db.close(); } catch (_) {} process.exit(0); });
    setTimeout(() => process.exit(1), 8000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

module.exports = { createServer };
