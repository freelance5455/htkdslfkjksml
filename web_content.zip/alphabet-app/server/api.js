'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const sec = require('./security');
const { tx, newId, nowIso, DATA_DIR } = require('./db');
const { HttpError, bad, readJson, parseCookies, sendJson, Router } = require('./http');

const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const SESSION_DAYS = 14;
const ATT_WINDOW_DAYS = 60;
const REASONS = ['مرض', 'ظرف عائلي', 'سفر', 'أخرى'];
const EVT_TYPES = ['event', 'exam', 'study', 'holiday', 'announcement'];
const ATT_STATUS = ['present', 'absent', 'late', 'excused'];
const SETTINGS_KEYS = ['inst', 'mgr', 'year', 'currency', 'phone', 'addr'];

/* ---------- التحقق من المدخلات ---------- */
const V = {
  str(x, name, o) {
    o = o || {};
    if (x === undefined || x === null || x === '') { if (o.required) throw bad(name + ' مطلوب'); return ''; }
    if (typeof x !== 'string') throw bad(name + ' غير صالح');
    const s = x.trim();
    if (o.required && !s) throw bad(name + ' مطلوب');
    if (s.length > (o.max || 200)) throw bad(name + ' طويل جداً');
    return s;
  },
  int(x, name, o) {
    o = o || {};
    if (x === undefined || x === null || x === '') { if (o.required) throw bad(name + ' مطلوب'); return o.def === undefined ? 0 : o.def; }
    const n = Number(x);
    if (!Number.isFinite(n) || !Number.isInteger(n)) throw bad(name + ' يجب أن يكون رقماً صحيحاً');
    if (o.min !== undefined && n < o.min) throw bad(name + ' أقل من الحد المسموح');
    if (o.max !== undefined && n > o.max) throw bad(name + ' أكبر من الحد المسموح');
    return n;
  },
  num(x, name, o) {
    o = o || {};
    const n = Number(x);
    if (x === '' || x === null || x === undefined || !Number.isFinite(n)) throw bad(name + ' غير صالح');
    if (o.min !== undefined && n < o.min) throw bad(name + ' أقل من الحد المسموح');
    if (o.max !== undefined && n > o.max) throw bad(name + ' أكبر من الحد المسموح');
    return n;
  },
  date(x, name, required) {
    if (x === undefined || x === null || x === '') { if (required) throw bad(name + ' مطلوب'); return ''; }
    if (typeof x !== 'string' || !DATE_RE.test(x) || isNaN(Date.parse(x + 'T00:00:00Z'))) throw bad(name + ' غير صالح');
    return x;
  },
  one(x, name, list, def) {
    if ((x === undefined || x === null || x === '') && def !== undefined) return def;
    if (!list.includes(x)) throw bad(name + ' غير صالح');
    return x;
  },
  id(x, name, required) {
    if (x === undefined || x === null || x === '') { if (required) throw bad(name + ' مطلوب'); return null; }
    if (typeof x !== 'string' || !ID_RE.test(x)) throw bad(name + ' غير صالح');
    return x;
  },
  ids(x, name) {
    if (x === undefined || x === null) return [];
    if (!Array.isArray(x) || x.length > 200) throw bad(name + ' غير صالح');
    return [...new Set(x.map(i => V.id(i, name, true)))];
  }
};
const ph = arr => arr.map(() => '?').join(',');
const isoDaysAgo = n => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);

/* ---------- صور المنشورات ---------- */
const IMG_TYPES = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' };
function sniffImage(buf) {
  if (buf.length > 12 && buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF) return 'image/jpeg';
  if (buf.length > 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]))) return 'image/png';
  if (buf.length > 12 && buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  if (buf.length > 6 && /^GIF8[79]a$/.test(buf.subarray(0, 6).toString('latin1'))) return 'image/gif';
  return null;
}
function decodeImage(dataUrl) {
  const m = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl));
  if (!m) throw bad('صيغة الصورة غير مدعومة');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 3 * 1024 * 1024) throw bad('الصورة أكبر من 3 ميغابايت');
  const real = sniffImage(buf);
  if (!real || real !== m[1]) throw bad('ملف الصورة غير صالح');
  return { buf, ext: IMG_TYPES[real] };
}

module.exports = function createApi(db, config) {
  const router = new Router();
  const loginByIp = new sec.RateLimiter(40, 15 * 60e3);
  const loginByUser = new sec.RateLimiter(6, 15 * 60e3);
  const apiByIp = new sec.RateLimiter(600, 60e3);
  let version = 1;
  const q = sql => db.prepare(sql);

  /* ======================== أدوات مساعدة ======================== */
  function audit(ctx, action) {
    q('INSERT INTO audit_log(user_id,name,role,action,ip,created_at) VALUES(?,?,?,?,?,?)')
      .run(ctx.user ? ctx.user.id : null, ctx.user ? ctx.user.name : 'نظام', ctx.user ? ctx.user.role : '-', action, ctx.ip || '', nowIso());
  }
  function getSettings() {
    const o = {};
    q('SELECT key,value FROM settings').all().forEach(r => { o[r.key] = r.value; });
    return o;
  }
  function publicUser(u) {
    return { id: u.id, username: u.username, role: u.role, name: u.name, refId: u.ref_id, mustChange: !!u.must_change };
  }
  const teacherClassIds = tid => q('SELECT class_id c FROM teacher_classes WHERE teacher_id=?').all(tid).map(r => r.c);
  const teacherSubjectIds = tid => q('SELECT subject_id s FROM teacher_subjects WHERE teacher_id=?').all(tid).map(r => r.s);
  function need(ctx, ...roles) { if (!roles.includes(ctx.user.role)) throw new HttpError(403, 'غير مصرح لك بهذا الإجراء'); }
  const notFound = what => new HttpError(404, (what || 'العنصر') + ' غير موجود');
  function mustExist(table, id, what) {
    if (!id) return;
    if (!q(`SELECT 1 FROM ${table} WHERE id=?`).get(id)) throw bad((what || 'العنصر') + ' غير موجود');
  }

  function nextStudentCode() {
    const r = q("SELECT MAX(CAST(SUBSTR(code,5) AS INTEGER)) m FROM students WHERE code LIKE 'ALP-%'").get();
    return 'ALP-' + String(Math.max(1000, r.m || 1000) + 1);
  }
  function uniqueUsername(base) {
    let u = base, i = 1;
    while (q('SELECT 1 FROM users WHERE username=?').get(u)) u = base + (++i);
    return u;
  }
  function createUser(role, name, refId, username, password) {
    const temp = password || sec.tempPassword();
    const id = newId('u');
    q('INSERT INTO users(id,username,password_hash,role,name,ref_id,active,must_change,created_at) VALUES(?,?,?,?,?,?,1,1,?)')
      .run(id, username, sec.hashPassword(temp), role, name, refId, nowIso());
    return { id, username, password: temp };
  }

  /* ---------- نطاق ما يراه كل دور ---------- */
  function scopeOf(user) {
    if (user.role === 'admin') return { all: true, sids: null, cids: null };
    if (user.role === 'teacher') {
      const cids = teacherClassIds(user.ref_id);
      const sids = cids.length ? q(`SELECT id FROM students WHERE class_id IN (${ph(cids)})`).all(...cids).map(r => r.id) : [];
      return { all: false, sids, cids, subs: teacherSubjectIds(user.ref_id) };
    }
    if (user.role === 'student') {
      const s = q('SELECT id,class_id FROM students WHERE id=?').get(user.ref_id);
      return { all: false, sids: s ? [s.id] : [], cids: s && s.class_id ? [s.class_id] : [] };
    }
    const kids = q('SELECT id,class_id FROM students WHERE parent_id=?').all(user.ref_id);
    return { all: false, sids: kids.map(k => k.id), cids: [...new Set(kids.map(k => k.class_id).filter(Boolean))] };
  }
  const audiencesFor = role => role === 'admin' ? null : ['all', role + 's'];

  /* ======================== بناء البيانات حسب الدور ======================== */
  function attendanceRows(user, sc, from, to) {
    if (!sc.all && !sc.sids.length) return [];
    let sql = 'SELECT id,student_id,class_id,subject_id,teacher_id,date,status,note,created_at FROM attendance WHERE date>=? AND date<=?';
    const args = [from, to];
    if (!sc.all) { sql += ` AND student_id IN (${ph(sc.sids)})`; args.push(...sc.sids); }
    sql += ' ORDER BY date,created_at';
    return q(sql).all(...args).map(r => ({
      id: r.id, studentId: r.student_id, classId: r.class_id, subjectId: r.subject_id, teacherId: r.teacher_id,
      date: r.date, status: r.status, note: r.note, created: r.created_at
    }));
  }

  function buildBootstrap(user) {
    const sc = scopeOf(user);
    const role = user.role;
    const out = { v: version, set: getSettings(), me: publicUser(user) };

    out.subjects = q('SELECT id,name FROM subjects ORDER BY name').all();
    out.classes = q('SELECT id,name,grade FROM classes ORDER BY name').all();

    /* المعلمون */
    let trows = [];
    if (role === 'admin') trows = q('SELECT * FROM teachers ORDER BY name').all();
    else if (role === 'teacher') trows = q('SELECT * FROM teachers WHERE id=?').all(user.ref_id);
    const tsub = {}, tcls = {};
    q('SELECT teacher_id t,subject_id s FROM teacher_subjects').all().forEach(r => (tsub[r.t] = tsub[r.t] || []).push(r.s));
    q('SELECT teacher_id t,class_id c FROM teacher_classes').all().forEach(r => (tcls[r.t] = tcls[r.t] || []).push(r.c));
    const tuser = {};
    if (role === 'admin') q("SELECT id,username,ref_id FROM users WHERE role='teacher'").all().forEach(u => { tuser[u.ref_id] = u.username; });
    out.teachers = trows.map(t => ({
      id: t.id, name: t.name, spec: t.spec, phone: role === 'admin' ? t.phone : '', email: role === 'admin' ? t.email : '',
      status: t.status, subs: tsub[t.id] || [], classes: tcls[t.id] || [], user: tuser[t.id] || ''
    }));

    /* الطلاب */
    let srows;
    if (sc.all) srows = q('SELECT * FROM students ORDER BY code').all();
    else if (!sc.sids.length) srows = [];
    else srows = q(`SELECT * FROM students WHERE id IN (${ph(sc.sids)}) ORDER BY code`).all(...sc.sids);
    out.students = srows.map(s => {
      const base = {
        id: s.id, code: s.code, name: s.name, classId: s.class_id, parentId: s.parent_id, birth: s.birth,
        gender: s.gender, status: s.status
      };
      if (role === 'teacher') { base.parentId = null; return base; }
      return Object.assign(base, { phone: s.phone, addr: s.addr, enroll: s.enroll, fee: s.fee, notes: role === 'admin' ? s.notes : '' });
    });

    /* أولياء الأمور */
    let prow = [];
    if (role === 'admin') prow = q('SELECT * FROM parents ORDER BY name').all();
    else if (role === 'parent') prow = q('SELECT * FROM parents WHERE id=?').all(user.ref_id);
    else if (role === 'student') prow = q('SELECT p.* FROM parents p JOIN students s ON s.parent_id=p.id WHERE s.id=?').all(user.ref_id);
    const puser = {};
    if (role === 'admin') q("SELECT username,ref_id FROM users WHERE role='parent'").all().forEach(u => { puser[u.ref_id] = u.username; });
    out.parents = prow.map(p => ({
      id: p.id, name: p.name, phone: role === 'student' ? '' : p.phone, email: role === 'student' ? '' : p.email, user: puser[p.id] || ''
    }));

    /* الحضور (نافذة زمنية) + إحصاءات كاملة */
    const from = isoDaysAgo(ATT_WINDOW_DAYS), to = isoDaysAgo(-1);
    out.attFrom = from;
    out.att = attendanceRows(user, sc, from, to);
    const stat = {};
    if (sc.all || sc.sids.length) {
      let sql = 'SELECT student_id s,status st,COUNT(*) c FROM attendance';
      const args = [];
      if (!sc.all) { sql += ` WHERE student_id IN (${ph(sc.sids)})`; args.push(...sc.sids); }
      sql += ' GROUP BY student_id,status';
      q(sql).all(...args).forEach(r => {
        const o = stat[r.s] = stat[r.s] || { present: 0, late: 0, absent: 0, excused: 0, total: 0 };
        o[r.st] = r.c; o.total += r.c;
      });
    }
    out.attStats = stat;

    /* الامتحانات والدرجات */
    let erows;
    if (sc.all) erows = q('SELECT * FROM exams ORDER BY date,title').all();
    else if (role === 'teacher') {
      const subs = sc.subs;
      const conds = ['teacher_id=?'], args = [user.ref_id];
      if (sc.cids.length && subs.length) { conds.push(`(class_id IN (${ph(sc.cids)}) AND subject_id IN (${ph(subs)}))`); args.push(...sc.cids, ...subs); }
      erows = q(`SELECT * FROM exams WHERE ${conds.join(' OR ')} ORDER BY date,title`).all(...args);
    } else erows = sc.cids.length ? q(`SELECT * FROM exams WHERE class_id IN (${ph(sc.cids)}) ORDER BY date,title`).all(...sc.cids) : [];
    out.exams = erows.map(e => ({
      id: e.id, title: e.title, classId: e.class_id, subjectId: e.subject_id, teacherId: e.teacher_id,
      date: e.date, max: e.max, pass: e.pass, type: e.type
    }));
    const eids = erows.map(e => e.id);
    let grows = [];
    if (eids.length) {
      let sql = `SELECT * FROM grades WHERE exam_id IN (${ph(eids)})`;
      const args = [...eids];
      if (!sc.all) { if (!sc.sids.length) sql += ' AND 0'; else { sql += ` AND student_id IN (${ph(sc.sids)})`; args.push(...sc.sids); } }
      grows = q(sql).all(...args);
    }
    out.grades = grows.map(g => ({ id: g.id, examId: g.exam_id, studentId: g.student_id, score: g.score, created: g.created_at }));

    /* التقييمات */
    let evrows;
    if (sc.all) evrows = q('SELECT * FROM evaluations ORDER BY date,rowid').all();
    else if (role === 'teacher') evrows = q('SELECT * FROM evaluations WHERE teacher_id=? ORDER BY date,rowid').all(user.ref_id);
    else evrows = sc.sids.length ? q(`SELECT * FROM evaluations WHERE student_id IN (${ph(sc.sids)}) ORDER BY date,rowid`).all(...sc.sids) : [];
    out.evals = evrows.map(e => ({
      id: e.id, studentId: e.student_id, subjectId: e.subject_id, teacherId: e.teacher_id,
      date: e.date, rating: e.rating, comment: e.comment
    }));

    /* المدفوعات */
    let prows = [];
    if (role === 'admin') prows = q('SELECT * FROM payments ORDER BY created_at').all();
    else if (role === 'student' || role === 'parent') prows = sc.sids.length ? q(`SELECT * FROM payments WHERE student_id IN (${ph(sc.sids)}) ORDER BY created_at`).all(...sc.sids) : [];
    out.pays = prows.map(p => ({
      id: p.id, studentId: p.student_id, amount: p.amount, date: p.date, method: p.method,
      ref: p.ref, note: p.note, by: p.by_name, created: p.created_at
    }));

    /* الإعلانات */
    const aud = audiencesFor(role);
    out.notes = (aud ? q(`SELECT * FROM announcements WHERE audience IN (${ph(aud)}) ORDER BY date,rowid`).all(...aud)
      : q('SELECT * FROM announcements ORDER BY date,rowid').all())
      .map(n => ({ id: n.id, title: n.title, body: n.body, audience: n.audience, date: n.date, author: n.author }));

    /* المنشورات */
    const posts = (aud
      ? q(`SELECT * FROM posts WHERE audience IN (${ph(aud)}) ORDER BY date DESC,created_at DESC LIMIT 60`).all(...aud)
      : q('SELECT * FROM posts ORDER BY date DESC,created_at DESC LIMIT 60').all()).reverse();
    const pids = posts.map(p => p.id);
    const imgs = {}, likes = {}, cms = {};
    if (pids.length) {
      q(`SELECT post_id,file FROM post_images WHERE post_id IN (${ph(pids)}) ORDER BY position`).all(...pids)
        .forEach(r => (imgs[r.post_id] = imgs[r.post_id] || []).push('/uploads/' + r.file));
      q(`SELECT post_id,user_id,name,created_at FROM post_likes WHERE post_id IN (${ph(pids)}) ORDER BY created_at`).all(...pids)
        .forEach(r => (likes[r.post_id] = likes[r.post_id] || []).push({ userId: r.user_id, name: r.name, date: r.created_at }));
      q(`SELECT id,post_id,user_id,name,text,created_at FROM post_comments WHERE post_id IN (${ph(pids)}) ORDER BY created_at`).all(...pids)
        .forEach(r => (cms[r.post_id] = cms[r.post_id] || []).push({ id: r.id, userId: r.user_id, name: r.name, text: r.text, date: r.created_at }));
    }
    out.events = posts.map(p => ({
      id: p.id, title: p.title, body: p.body, type: p.type, audience: p.audience, date: p.date, time: p.time,
      location: p.location, author: p.author, images: imgs[p.id] || [], likes: likes[p.id] || [], comments: cms[p.id] || []
    }));

    /* التذاكر */
    let trs;
    if (role === 'admin') trs = q('SELECT * FROM (SELECT * FROM tickets ORDER BY created_at DESC LIMIT 300) ORDER BY created_at').all();
    else trs = q('SELECT * FROM tickets WHERE user_id=? ORDER BY created_at').all(user.id);
    const tids = trs.map(t => t.id), msgs = {};
    if (tids.length) {
      q(`SELECT * FROM ticket_messages WHERE ticket_id IN (${ph(tids)}) ORDER BY created_at,rowid`).all(...tids)
        .forEach(m => (msgs[m.ticket_id] = msgs[m.ticket_id] || []).push({
          id: m.id, senderId: m.sender_id, senderName: m.sender_name, senderRole: m.sender_role, text: m.text, date: m.created_at
        }));
    }
    out.tickets = trs.map(t => ({
      id: t.id, userId: t.user_id, userName: t.user_name, userRole: t.user_role, type: t.type, subject: t.subject,
      status: t.status, createdAt: t.created_at, relatedStudentId: t.related_student_id, absenceDate: t.absence_date,
      reason: t.reason, adminUnread: !!t.admin_unread, userUnread: !!t.user_unread, messages: msgs[t.id] || []
    }));

    /* الرسائل الجماعية */
    out.broadcasts = (aud ? q(`SELECT * FROM broadcasts WHERE audience IN (${ph(aud)}) ORDER BY created_at`).all(...aud)
      : q('SELECT * FROM broadcasts ORDER BY created_at').all())
      .map(b => ({ id: b.id, title: b.title, body: b.body, audience: b.audience, author: b.author, createdAt: b.created_at }));

    /* للمدير فقط: الحسابات وسجل النشاط */
    if (role === 'admin') {
      out.accounts = q('SELECT id,username,role,name,ref_id,active,must_change,last_login FROM users ORDER BY role,name').all()
        .map(u => ({ id: u.id, username: u.username, role: u.role, name: u.name, refId: u.ref_id, active: !!u.active, mustChange: !!u.must_change, lastLogin: u.last_login }));
      out.audit = q('SELECT user_id,name,role,action,created_at FROM audit_log ORDER BY id DESC LIMIT 300').all()
        .map(a => ({ userId: a.user_id, name: a.name, role: a.role, action: a.action, date: a.created_at }));
    }
    return out;
  }

  /* ======================== تعريف المسارات ======================== */
  const R = (method, p, handler, opts) => router.add(method, p, handler, opts);

  /* ---------- الدخول والجلسات ---------- */
  R('GET', '/api/public', ctx => {
    const s = getSettings();
    sendJson(ctx.res, 200, { inst: s.inst, mgr: s.mgr });
  }, { auth: false });

  R('POST', '/api/login', async ctx => {
    const b = ctx.body;
    const username = V.str(b.username, 'اسم المستخدم', { required: true, max: 64 });
    const password = V.str(b.password === undefined ? '' : String(b.password), 'كلمة المرور', { max: 200 }) || '';
    const kIp = ctx.ip, kUser = ctx.ip + '|' + username.toLowerCase();
    if (loginByIp.blocked(kIp) || loginByUser.blocked(kUser)) {
      const s = Math.max(loginByIp.retryAfterSec(kIp), loginByUser.retryAfterSec(kUser));
      throw new HttpError(429, `محاولات كثيرة. حاول بعد ${Math.ceil(s / 60)} دقيقة`);
    }
    const u = q('SELECT * FROM users WHERE username=?').get(username);
    const ok = sec.verifyPassword(password, u ? u.password_hash : sec.DUMMY_HASH);
    if (!u || !ok || !u.active) {
      loginByIp.hit(kIp); loginByUser.hit(kUser);
      ctx.user = u || null;
      audit({ user: u || null, ip: ctx.ip }, 'فشل تسجيل دخول: ' + username.slice(0, 40));
      throw new HttpError(401, u && ok && !u.active ? 'الحساب موقوف، راجع إدارة المعهد' : 'بيانات الدخول غير صحيحة');
    }
    loginByUser.reset(kUser);
    const token = sec.newToken();
    const exp = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
    q('DELETE FROM sessions WHERE expires_at<?').run(nowIso());
    q('INSERT INTO sessions(id,user_id,created_at,expires_at,ip,ua) VALUES(?,?,?,?,?,?)')
      .run(sec.hashToken(token), u.id, nowIso(), exp, ctx.ip, String(ctx.req.headers['user-agent'] || '').slice(0, 200));
    q('UPDATE users SET last_login=? WHERE id=?').run(nowIso(), u.id);
    audit({ user: u, ip: ctx.ip }, 'تسجيل دخول');
    sendJson(ctx.res, 200, { user: publicUser(u), set: getSettings() }, {
      'Set-Cookie': `sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_DAYS * 86400}${ctx.secure ? '; Secure' : ''}`
    });
  }, { auth: false, limit: 4096 });

  R('POST', '/api/logout', ctx => {
    q('DELETE FROM sessions WHERE id=?').run(ctx.sessionId);
    audit(ctx, 'تسجيل خروج');
    sendJson(ctx.res, 200, { ok: true }, { 'Set-Cookie': `sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${ctx.secure ? '; Secure' : ''}` });
  });

  R('GET', '/api/me', ctx => sendJson(ctx.res, 200, { user: publicUser(ctx.user), set: getSettings() }));

  R('POST', '/api/password', ctx => {
    const cur = String(ctx.body.current || ''), next = String(ctx.body.next || '');
    if (!sec.verifyPassword(cur, ctx.user.password_hash)) throw new HttpError(400, 'كلمة المرور الحالية غير صحيحة');
    const err = sec.checkPasswordPolicy(next);
    if (err) throw bad(err);
    if (next === cur) throw bad('كلمة المرور الجديدة يجب أن تختلف عن الحالية');
    tx(db, () => {
      q('UPDATE users SET password_hash=?,must_change=0 WHERE id=?').run(sec.hashPassword(next), ctx.user.id);
      q('DELETE FROM sessions WHERE user_id=? AND id<>?').run(ctx.user.id, ctx.sessionId);
      audit(ctx, 'تغيير كلمة المرور');
    });
    sendJson(ctx.res, 200, { ok: true });
  }, { limit: 4096 });

  R('GET', '/api/bootstrap', ctx => sendJson(ctx.res, 200, buildBootstrap(ctx.user)));

  R('GET', '/api/poll', ctx => {
    const u = ctx.user;
    const n = u.role === 'admin' ? q('SELECT COUNT(*) c FROM tickets WHERE admin_unread=1').get().c
      : q('SELECT COUNT(*) c FROM tickets WHERE user_id=? AND user_unread=1').get(u.id).c;
    sendJson(ctx.res, 200, { v: version, unread: n });
  });

  R('GET', '/api/attendance', ctx => {
    const u = ctx.user, sc = scopeOf(u);
    const from = V.date(ctx.query.get('from'), 'من', true), to = V.date(ctx.query.get('to') || from, 'إلى', true);
    if (Date.parse(to) - Date.parse(from) > 100 * 864e5 || to < from) throw bad('المدى الزمني غير صالح');
    sendJson(ctx.res, 200, { att: attendanceRows(u, sc, from, to) });
  });

  /* ---------- الإعدادات ---------- */
  R('PUT', '/api/settings', ctx => {
    need(ctx, 'admin');
    const b = ctx.body, up = q('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
    tx(db, () => {
      for (const k of SETTINGS_KEYS) if (b[k] !== undefined) up.run(k, V.str(b[k], k, { max: 120, required: k === 'inst' || k === 'currency' }));
      audit(ctx, 'تعديل إعدادات المعهد');
    });
    sendJson(ctx.res, 200, { ok: true });
  }, { limit: 8192 });

  /* ---------- الصفوف والمواد ---------- */
  R('POST', '/api/classes', ctx => {
    need(ctx, 'admin');
    const name = V.str(ctx.body.name, 'اسم الصف', { required: true, max: 60 });
    if (q('SELECT 1 FROM classes WHERE name=?').get(name)) throw bad('يوجد صف بنفس الاسم');
    const id = newId('c');
    q('INSERT INTO classes(id,name,grade) VALUES(?,?,?)').run(id, name, V.str(ctx.body.grade, 'المرحلة', { max: 60 }));
    audit(ctx, 'إضافة صف: ' + name);
    sendJson(ctx.res, 201, { id });
  });
  R('PUT', '/api/classes/:id', ctx => {
    need(ctx, 'admin');
    const name = V.str(ctx.body.name, 'اسم الصف', { required: true, max: 60 });
    if (q('SELECT 1 FROM classes WHERE name=? AND id<>?').get(name, ctx.params.id)) throw bad('يوجد صف بنفس الاسم');
    const r = q('UPDATE classes SET name=?,grade=? WHERE id=?').run(name, V.str(ctx.body.grade, 'المرحلة', { max: 60 }), ctx.params.id);
    if (!r.changes) throw notFound('الصف');
    audit(ctx, 'تعديل صف: ' + name);
    sendJson(ctx.res, 200, { ok: true });
  });
  R('DELETE', '/api/classes/:id', ctx => {
    need(ctx, 'admin');
    const c = q('SELECT name FROM classes WHERE id=?').get(ctx.params.id);
    if (!c) throw notFound('الصف');
    if (q('SELECT 1 FROM students WHERE class_id=?').get(ctx.params.id)) throw new HttpError(409, 'لا يمكن حذف صف فيه طلاب. انقل الطلاب أولاً');
    if (q('SELECT 1 FROM exams WHERE class_id=?').get(ctx.params.id)) throw new HttpError(409, 'لا يمكن حذف صف له امتحانات');
    if (q('SELECT 1 FROM teacher_classes WHERE class_id=?').get(ctx.params.id)) throw new HttpError(409, 'الصف مُسند لمعلم. أزل الإسناد أولاً');
    q('DELETE FROM classes WHERE id=?').run(ctx.params.id);
    audit(ctx, 'حذف صف: ' + c.name);
    sendJson(ctx.res, 200, { ok: true });
  });
  R('POST', '/api/subjects', ctx => {
    need(ctx, 'admin');
    const name = V.str(ctx.body.name, 'اسم المادة', { required: true, max: 60 });
    if (q('SELECT 1 FROM subjects WHERE name=?').get(name)) throw bad('توجد مادة بنفس الاسم');
    const id = newId('s');
    q('INSERT INTO subjects(id,name) VALUES(?,?)').run(id, name);
    audit(ctx, 'إضافة مادة: ' + name);
    sendJson(ctx.res, 201, { id });
  });
  R('DELETE', '/api/subjects/:id', ctx => {
    need(ctx, 'admin');
    const s = q('SELECT name FROM subjects WHERE id=?').get(ctx.params.id);
    if (!s) throw notFound('المادة');
    if (q('SELECT 1 FROM exams WHERE subject_id=?').get(ctx.params.id)) throw new HttpError(409, 'لا يمكن حذف مادة لها امتحانات');
    if (q('SELECT 1 FROM teacher_subjects WHERE subject_id=?').get(ctx.params.id)) throw new HttpError(409, 'المادة مُسندة لمعلم. أزل الإسناد أولاً');
    q('DELETE FROM subjects WHERE id=?').run(ctx.params.id);
    audit(ctx, 'حذف مادة: ' + s.name);
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- الطلاب ---------- */
  function studentFields(b, partial) {
    const f = {
      name: V.str(b.name, 'اسم الطالب', { required: !partial, max: 100 }),
      classId: V.id(b.classId, 'الصف'), parentId: V.id(b.parentId, 'ولي الأمر'),
      birth: V.date(b.birth, 'تاريخ الميلاد'), gender: V.one(b.gender, 'الجنس', ['ذكر', 'أنثى', ''], ''),
      phone: V.str(b.phone, 'الهاتف', { max: 30 }), addr: V.str(b.addr, 'العنوان', { max: 200 }),
      fee: V.int(b.fee, 'القسط', { min: 0, max: 1e12 }), notes: V.str(b.notes, 'الملاحظات', { max: 1000 }),
      status: V.one(b.status, 'الحالة', ['active', 'inactive'], 'active')
    };
    mustExist('classes', f.classId, 'الصف'); mustExist('parents', f.parentId, 'ولي الأمر');
    return f;
  }
  R('POST', '/api/students', ctx => {
    need(ctx, 'admin');
    const f = studentFields(ctx.body);
    if (!f.classId) throw bad('الصف مطلوب');
    const res = tx(db, () => {
      const id = newId('st'), code = nextStudentCode();
      q('INSERT INTO students(id,code,name,class_id,parent_id,birth,gender,phone,addr,enroll,status,fee,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, code, f.name, f.classId, f.parentId, f.birth, f.gender, f.phone, f.addr, V.date(ctx.body.enroll, 'تاريخ التسجيل') || isoDaysAgo(0), 'active', f.fee, f.notes);
      const acc = createUser('student', f.name, id, uniqueUsername(code.toLowerCase()));
      audit(ctx, `إضافة طالب: ${f.name} (${code})`);
      return { id, code, credentials: { username: acc.username, password: acc.password } };
    });
    sendJson(ctx.res, 201, res);
  });
  R('PUT', '/api/students/:id', ctx => {
    need(ctx, 'admin');
    const cur = q('SELECT * FROM students WHERE id=?').get(ctx.params.id);
    if (!cur) throw notFound('الطالب');
    const f = studentFields(ctx.body);
    if (!f.classId) throw bad('الصف مطلوب');
    tx(db, () => {
      q('UPDATE students SET name=?,class_id=?,parent_id=?,birth=?,gender=?,phone=?,addr=?,fee=?,notes=?,status=? WHERE id=?')
        .run(f.name, f.classId, f.parentId, f.birth, f.gender, f.phone, f.addr, f.fee, f.notes, f.status, cur.id);
      q("UPDATE users SET name=?,active=? WHERE role='student' AND ref_id=?").run(f.name, f.status === 'active' ? 1 : 0, cur.id);
      if (f.status !== 'active') q("DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE role='student' AND ref_id=?)").run(cur.id);
      audit(ctx, `تعديل طالب: ${f.name} (${cur.code})`);
    });
    sendJson(ctx.res, 200, { ok: true });
  });
  R('DELETE', '/api/students/:id', ctx => {
    need(ctx, 'admin');
    const s = q('SELECT * FROM students WHERE id=?').get(ctx.params.id);
    if (!s) throw notFound('الطالب');
    if (q('SELECT 1 FROM payments WHERE student_id=?').get(s.id)) throw new HttpError(409, 'للطالب مدفوعات مسجلة ولا يمكن حذفه. أوقف حسابه بدلاً من ذلك');
    tx(db, () => {
      q("DELETE FROM users WHERE role='student' AND ref_id=?").run(s.id);
      q('DELETE FROM students WHERE id=?').run(s.id);
      audit(ctx, `حذف طالب: ${s.name} (${s.code})`);
    });
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- أولياء الأمور ---------- */
  function parentFields(b) {
    return {
      name: V.str(b.name, 'اسم ولي الأمر', { required: true, max: 100 }),
      phone: V.str(b.phone, 'الهاتف', { max: 30 }), email: V.str(b.email, 'البريد', { max: 120 })
    };
  }
  R('POST', '/api/parents', ctx => {
    need(ctx, 'admin');
    const f = parentFields(ctx.body);
    const res = tx(db, () => {
      const id = newId('p');
      q('INSERT INTO parents(id,name,phone,email) VALUES(?,?,?,?)').run(id, f.name, f.phone, f.email);
      const n = q("SELECT COUNT(*) c FROM users WHERE role='parent'").get().c;
      const acc = createUser('parent', f.name, id, uniqueUsername('parent' + (n + 1)));
      audit(ctx, 'إضافة ولي أمر: ' + f.name);
      return { id, credentials: { username: acc.username, password: acc.password } };
    });
    sendJson(ctx.res, 201, res);
  });
  R('PUT', '/api/parents/:id', ctx => {
    need(ctx, 'admin');
    const f = parentFields(ctx.body);
    tx(db, () => {
      const r = q('UPDATE parents SET name=?,phone=?,email=? WHERE id=?').run(f.name, f.phone, f.email, ctx.params.id);
      if (!r.changes) throw notFound('ولي الأمر');
      q("UPDATE users SET name=? WHERE role='parent' AND ref_id=?").run(f.name, ctx.params.id);
      audit(ctx, 'تعديل ولي أمر: ' + f.name);
    });
    sendJson(ctx.res, 200, { ok: true });
  });
  R('DELETE', '/api/parents/:id', ctx => {
    need(ctx, 'admin');
    const p = q('SELECT name FROM parents WHERE id=?').get(ctx.params.id);
    if (!p) throw notFound('ولي الأمر');
    if (q('SELECT 1 FROM students WHERE parent_id=?').get(ctx.params.id)) throw new HttpError(409, 'ولي الأمر مرتبط بطلاب. فك الارتباط أولاً');
    tx(db, () => {
      q("DELETE FROM users WHERE role='parent' AND ref_id=?").run(ctx.params.id);
      q('DELETE FROM parents WHERE id=?').run(ctx.params.id);
      audit(ctx, 'حذف ولي أمر: ' + p.name);
    });
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- المعلمون ---------- */
  function teacherFields(b) {
    const f = {
      name: V.str(b.name, 'اسم المعلم', { required: true, max: 100 }), spec: V.str(b.spec, 'التخصص', { max: 80 }),
      phone: V.str(b.phone, 'الهاتف', { max: 30 }), email: V.str(b.email, 'البريد', { max: 120 }),
      status: V.one(b.status, 'الحالة', ['active', 'inactive'], 'active'),
      subs: V.ids(b.subs, 'المواد'), classes: V.ids(b.classes, 'الصفوف')
    };
    f.subs.forEach(s => mustExist('subjects', s, 'المادة'));
    f.classes.forEach(c => mustExist('classes', c, 'الصف'));
    return f;
  }
  function setTeacherLinks(tid, f) {
    q('DELETE FROM teacher_subjects WHERE teacher_id=?').run(tid);
    q('DELETE FROM teacher_classes WHERE teacher_id=?').run(tid);
    f.subs.forEach(s => q('INSERT INTO teacher_subjects(teacher_id,subject_id) VALUES(?,?)').run(tid, s));
    f.classes.forEach(c => q('INSERT INTO teacher_classes(teacher_id,class_id) VALUES(?,?)').run(tid, c));
  }
  R('POST', '/api/teachers', ctx => {
    need(ctx, 'admin');
    const f = teacherFields(ctx.body);
    const username = V.str(ctx.body.user, 'اسم المستخدم', { required: true, max: 40 });
    if (!/^[A-Za-z0-9._-]{3,40}$/.test(username)) throw bad('اسم المستخدم: أحرف إنجليزية وأرقام فقط (3 أحرف على الأقل)');
    if (q('SELECT 1 FROM users WHERE username=?').get(username)) throw bad('اسم المستخدم مستخدم مسبقاً');
    let pw = '';
    if (ctx.body.pass) { pw = String(ctx.body.pass); const e = sec.checkPasswordPolicy(pw); if (e) throw bad(e); }
    const res = tx(db, () => {
      const id = newId('t');
      q('INSERT INTO teachers(id,name,spec,phone,email,status) VALUES(?,?,?,?,?,?)').run(id, f.name, f.spec, f.phone, f.email, f.status);
      setTeacherLinks(id, f);
      const acc = createUser('teacher', f.name, id, username, pw || null);
      audit(ctx, 'إضافة معلم: ' + f.name);
      return { id, credentials: { username: acc.username, password: acc.password } };
    });
    sendJson(ctx.res, 201, res);
  });
  R('PUT', '/api/teachers/:id', ctx => {
    need(ctx, 'admin');
    const t = q('SELECT * FROM teachers WHERE id=?').get(ctx.params.id);
    if (!t) throw notFound('المعلم');
    const f = teacherFields(ctx.body);
    const u = q("SELECT * FROM users WHERE role='teacher' AND ref_id=?").get(t.id);
    let username = u ? u.username : null;
    if (ctx.body.user && u && ctx.body.user !== u.username) {
      username = V.str(ctx.body.user, 'اسم المستخدم', { max: 40 });
      if (!/^[A-Za-z0-9._-]{3,40}$/.test(username)) throw bad('اسم المستخدم: أحرف إنجليزية وأرقام فقط');
      if (q('SELECT 1 FROM users WHERE username=? AND id<>?').get(username, u.id)) throw bad('اسم المستخدم مستخدم مسبقاً');
    }
    tx(db, () => {
      q('UPDATE teachers SET name=?,spec=?,phone=?,email=?,status=? WHERE id=?').run(f.name, f.spec, f.phone, f.email, f.status, t.id);
      setTeacherLinks(t.id, f);
      if (u) {
        q('UPDATE users SET name=?,username=?,active=? WHERE id=?').run(f.name, username, f.status === 'active' ? 1 : 0, u.id);
        if (f.status !== 'active') q('DELETE FROM sessions WHERE user_id=?').run(u.id);
      }
      audit(ctx, 'تعديل معلم: ' + f.name);
    });
    sendJson(ctx.res, 200, { ok: true });
  });
  R('DELETE', '/api/teachers/:id', ctx => {
    need(ctx, 'admin');
    const t = q('SELECT name FROM teachers WHERE id=?').get(ctx.params.id);
    if (!t) throw notFound('المعلم');
    tx(db, () => {
      q("DELETE FROM users WHERE role='teacher' AND ref_id=?").run(ctx.params.id);
      q('DELETE FROM teachers WHERE id=?').run(ctx.params.id);
      audit(ctx, 'حذف معلم: ' + t.name);
    });
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- حسابات المستخدمين (للمدير) ---------- */
  R('POST', '/api/users/:id/reset-password', ctx => {
    need(ctx, 'admin');
    const u = q('SELECT * FROM users WHERE id=?').get(ctx.params.id);
    if (!u) throw notFound('الحساب');
    const temp = sec.tempPassword();
    tx(db, () => {
      q('UPDATE users SET password_hash=?,must_change=1 WHERE id=?').run(sec.hashPassword(temp), u.id);
      q('DELETE FROM sessions WHERE user_id=?').run(u.id);
      audit(ctx, 'إعادة تعيين كلمة مرور: ' + u.username);
    });
    sendJson(ctx.res, 200, { username: u.username, password: temp });
  });
  R('PUT', '/api/users/:id/active', ctx => {
    need(ctx, 'admin');
    const u = q('SELECT * FROM users WHERE id=?').get(ctx.params.id);
    if (!u) throw notFound('الحساب');
    if (u.id === ctx.user.id) throw bad('لا يمكنك إيقاف حسابك');
    const active = ctx.body.active ? 1 : 0;
    tx(db, () => {
      q('UPDATE users SET active=? WHERE id=?').run(active, u.id);
      if (!active) q('DELETE FROM sessions WHERE user_id=?').run(u.id);
      audit(ctx, (active ? 'تفعيل' : 'إيقاف') + ' حساب: ' + u.username);
    });
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- الحضور ---------- */
  function checkTeacherCanTeach(ctx, classId, subjectId) {
    if (ctx.user.role === 'admin') return;
    if (!teacherClassIds(ctx.user.ref_id).includes(classId)) throw new HttpError(403, 'هذا الصف ليس ضمن صفوفك');
    if (subjectId && !teacherSubjectIds(ctx.user.ref_id).includes(subjectId)) throw new HttpError(403, 'هذه المادة ليست ضمن موادك');
  }
  function upsertAttendance(ctx, studentId, classId, subjectId, date, status) {
    const ex = q("SELECT id FROM attendance WHERE student_id=? AND date=? AND COALESCE(subject_id,'')=?").get(studentId, date, subjectId || '');
    const tid = ctx.user.role === 'teacher' ? ctx.user.ref_id : null;
    if (ex) q('UPDATE attendance SET status=?,class_id=?,teacher_id=COALESCE(?,teacher_id) WHERE id=?').run(status, classId, tid, ex.id);
    else q('INSERT INTO attendance(id,student_id,class_id,subject_id,teacher_id,date,status,note,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
      .run(newId('a'), studentId, classId, subjectId || null, tid, date, status, '', nowIso());
  }
  R('PUT', '/api/attendance', ctx => {
    need(ctx, 'admin', 'teacher');
    const b = ctx.body;
    const studentId = V.id(b.studentId, 'الطالب', true), classId = V.id(b.classId, 'الصف', true), subjectId = V.id(b.subjectId, 'المادة');
    const date = V.date(b.date, 'التاريخ', true), status = V.one(b.status, 'الحالة', ATT_STATUS);
    mustExist('subjects', subjectId, 'المادة');
    const st = q('SELECT class_id FROM students WHERE id=?').get(studentId);
    if (!st) throw bad('الطالب غير موجود');
    if (st.class_id !== classId) throw bad('الطالب ليس في هذا الصف');
    checkTeacherCanTeach(ctx, classId, subjectId);
    upsertAttendance(ctx, studentId, classId, subjectId, date, status);
    sendJson(ctx.res, 200, { ok: true });
  });
  R('POST', '/api/attendance/bulk', ctx => {
    need(ctx, 'admin', 'teacher');
    const b = ctx.body;
    const classId = V.id(b.classId, 'الصف', true), subjectId = V.id(b.subjectId, 'المادة'), date = V.date(b.date, 'التاريخ', true);
    const status = V.one(b.status, 'الحالة', ATT_STATUS, 'present');
    mustExist('classes', classId, 'الصف'); mustExist('subjects', subjectId, 'المادة');
    checkTeacherCanTeach(ctx, classId, subjectId);
    const n = tx(db, () => {
      const st = q("SELECT id FROM students WHERE class_id=? AND status='active'").all(classId);
      st.forEach(s => upsertAttendance(ctx, s.id, classId, subjectId, date, status));
      audit(ctx, `تسجيل حضور جماعي (${st.length}) بتاريخ ${date}`);
      return st.length;
    });
    sendJson(ctx.res, 200, { count: n });
  });

  /* ---------- الامتحانات والدرجات ---------- */
  R('POST', '/api/exams', ctx => {
    need(ctx, 'admin', 'teacher');
    const b = ctx.body;
    const f = {
      title: V.str(b.title, 'عنوان الامتحان', { required: true, max: 120 }), classId: V.id(b.classId, 'الصف', true),
      subjectId: V.id(b.subjectId, 'المادة', true), date: V.date(b.date, 'التاريخ', true),
      max: V.int(b.max, 'الدرجة القصوى', { min: 1, max: 1000, def: 100 }), pass: V.int(b.pass, 'درجة النجاح', { min: 0, max: 1000, def: 50 }),
      type: V.str(b.type, 'النوع', { max: 30 }) || 'شهري'
    };
    if (f.pass > f.max) throw bad('درجة النجاح أكبر من القصوى');
    mustExist('classes', f.classId, 'الصف'); mustExist('subjects', f.subjectId, 'المادة');
    let tid = null;
    if (ctx.user.role === 'teacher') { checkTeacherCanTeach(ctx, f.classId, f.subjectId); tid = ctx.user.ref_id; }
    else { tid = V.id(b.teacherId, 'المعلم'); mustExist('teachers', tid, 'المعلم'); }
    const id = newId('e');
    q('INSERT INTO exams(id,title,class_id,subject_id,teacher_id,date,max,pass,type) VALUES(?,?,?,?,?,?,?,?,?)')
      .run(id, f.title, f.classId, f.subjectId, tid, f.date, f.max, f.pass, f.type);
    audit(ctx, 'إضافة امتحان: ' + f.title);
    sendJson(ctx.res, 201, { id });
  });
  function examForUser(ctx, id) {
    const e = q('SELECT * FROM exams WHERE id=?').get(id);
    if (!e) throw notFound('الامتحان');
    if (ctx.user.role === 'teacher' && e.teacher_id !== ctx.user.ref_id) throw new HttpError(403, 'هذا الامتحان ليس من امتحاناتك');
    return e;
  }
  R('DELETE', '/api/exams/:id', ctx => {
    need(ctx, 'admin', 'teacher');
    const e = examForUser(ctx, ctx.params.id);
    q('DELETE FROM exams WHERE id=?').run(e.id);
    audit(ctx, 'حذف امتحان: ' + e.title);
    sendJson(ctx.res, 200, { ok: true });
  });
  R('PUT', '/api/exams/:id/grades', ctx => {
    need(ctx, 'admin', 'teacher');
    const e = examForUser(ctx, ctx.params.id);
    const g = ctx.body.grades;
    if (!g || typeof g !== 'object' || Array.isArray(g)) throw bad('الدرجات غير صالحة');
    const entries = Object.entries(g);
    if (entries.length > 500) throw bad('عدد كبير من الدرجات');
    const inClass = new Set(q('SELECT id FROM students WHERE class_id=?').all(e.class_id).map(r => r.id));
    tx(db, () => {
      for (const [sid, raw] of entries) {
        V.id(sid, 'الطالب', true);
        if (!inClass.has(sid)) throw bad('طالب ليس في صف الامتحان');
        if (raw === null || raw === '') { q('DELETE FROM grades WHERE exam_id=? AND student_id=?').run(e.id, sid); continue; }
        const score = V.num(raw, 'الدرجة', { min: 0, max: e.max });
        q('INSERT INTO grades(id,exam_id,student_id,score,created_at) VALUES(?,?,?,?,?) ON CONFLICT(exam_id,student_id) DO UPDATE SET score=excluded.score')
          .run(newId('g'), e.id, sid, score, nowIso());
      }
      audit(ctx, 'رصد درجات: ' + e.title);
    });
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- التقييمات ---------- */
  R('POST', '/api/evaluations', ctx => {
    need(ctx, 'admin', 'teacher');
    const b = ctx.body;
    const studentId = V.id(b.studentId, 'الطالب', true), subjectId = V.id(b.subjectId, 'المادة', true);
    const rating = V.one(b.rating, 'التقدير', ['ممتاز', 'جيد جداً', 'جيد', 'يحتاج تحسين'], '');
    const comment = V.str(b.comment, 'التعليق', { max: 1000 });
    if (!rating && !comment) throw bad('أدخل تقديراً أو تعليقاً');
    const st = q('SELECT class_id FROM students WHERE id=?').get(studentId);
    if (!st) throw bad('الطالب غير موجود');
    mustExist('subjects', subjectId, 'المادة');
    let tid = null;
    if (ctx.user.role === 'teacher') { checkTeacherCanTeach(ctx, st.class_id, subjectId); tid = ctx.user.ref_id; }
    q('INSERT INTO evaluations(id,student_id,subject_id,teacher_id,date,rating,comment) VALUES(?,?,?,?,?,?,?)')
      .run(newId('ev'), studentId, subjectId, tid, V.date(b.date, 'التاريخ') || isoDaysAgo(0), rating, comment);
    audit(ctx, 'إضافة تقييم طالب');
    sendJson(ctx.res, 201, { ok: true });
  });
  R('DELETE', '/api/evaluations/:id', ctx => {
    need(ctx, 'admin', 'teacher');
    const e = q('SELECT * FROM evaluations WHERE id=?').get(ctx.params.id);
    if (!e) throw notFound('التقييم');
    if (ctx.user.role === 'teacher' && e.teacher_id !== ctx.user.ref_id) throw new HttpError(403, 'غير مصرح');
    q('DELETE FROM evaluations WHERE id=?').run(e.id);
    audit(ctx, 'حذف تقييم');
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- المدفوعات ---------- */
  R('POST', '/api/payments', ctx => {
    need(ctx, 'admin');
    const b = ctx.body;
    const studentId = V.id(b.studentId, 'الطالب', true);
    const st = q('SELECT name FROM students WHERE id=?').get(studentId);
    if (!st) throw bad('الطالب غير موجود');
    const amount = V.int(b.amount, 'المبلغ', { required: true, min: 1, max: 1e12 });
    const date = V.date(b.date, 'التاريخ') || isoDaysAgo(0);
    const note = V.str(b.note, 'ملاحظة', { max: 200 });
    const res = tx(db, () => {
      const n = (q('SELECT COUNT(*) c FROM payments').get().c) + 1;
      let ref = 'RC-' + String(100000 + n);
      while (q('SELECT 1 FROM payments WHERE ref=?').get(ref)) ref = 'RC-' + crypto.randomBytes(3).toString('hex').toUpperCase();
      const id = newId('p');
      q('INSERT INTO payments(id,student_id,amount,date,method,ref,note,by_name,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
        .run(id, studentId, amount, date, 'cash', ref, note, ctx.user.name, nowIso());
      audit(ctx, `دفعة ${amount} للطالب ${st.name} (${ref})`);
      return { id, ref };
    });
    sendJson(ctx.res, 201, res);
  });
  R('DELETE', '/api/payments/:id', ctx => {
    need(ctx, 'admin');
    const p = q('SELECT * FROM payments WHERE id=?').get(ctx.params.id);
    if (!p) throw notFound('الدفعة');
    q('DELETE FROM payments WHERE id=?').run(p.id);
    audit(ctx, `حذف دفعة ${p.ref} بقيمة ${p.amount}`);
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- الإعلانات والرسائل الجماعية ---------- */
  const AUD = ['all', 'students', 'parents', 'teachers'];
  R('POST', '/api/announcements', ctx => {
    need(ctx, 'admin');
    const b = ctx.body;
    q('INSERT INTO announcements(id,title,body,audience,date,author) VALUES(?,?,?,?,?,?)').run(
      newId('n'), V.str(b.title, 'العنوان', { required: true, max: 150 }), V.str(b.body, 'المحتوى', { required: true, max: 4000 }),
      V.one(b.audience, 'الجمهور', AUD, 'all'), V.date(b.date, 'التاريخ') || isoDaysAgo(0), ctx.user.name);
    audit(ctx, 'نشر إعلان: ' + V.str(b.title, '', { max: 60 }));
    sendJson(ctx.res, 201, { ok: true });
  });
  R('DELETE', '/api/announcements/:id', ctx => {
    need(ctx, 'admin');
    if (!q('DELETE FROM announcements WHERE id=?').run(ctx.params.id).changes) throw notFound('الإعلان');
    audit(ctx, 'حذف إعلان');
    sendJson(ctx.res, 200, { ok: true });
  });
  R('POST', '/api/broadcasts', ctx => {
    need(ctx, 'admin');
    const b = ctx.body;
    const title = V.str(b.title, 'العنوان', { required: true, max: 150 });
    q('INSERT INTO broadcasts(id,title,body,audience,author,created_at) VALUES(?,?,?,?,?,?)').run(
      newId('bc'), title, V.str(b.body, 'الرسالة', { required: true, max: 4000 }), V.one(b.audience, 'الجمهور', AUD, 'all'), ctx.user.name, nowIso());
    audit(ctx, 'رسالة جماعية: ' + title);
    sendJson(ctx.res, 201, { ok: true });
  });
  R('DELETE', '/api/broadcasts/:id', ctx => {
    need(ctx, 'admin');
    if (!q('DELETE FROM broadcasts WHERE id=?').run(ctx.params.id).changes) throw notFound('الرسالة');
    audit(ctx, 'حذف رسالة جماعية');
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- المنشورات والتفاعل ---------- */
  function visiblePost(ctx, id) {
    const p = q('SELECT * FROM posts WHERE id=?').get(id);
    if (!p) throw notFound('المنشور');
    if (ctx.user.role !== 'admin' && p.audience !== 'all' && p.audience !== ctx.user.role + 's') throw notFound('المنشور');
    return p;
  }
  R('POST', '/api/posts', ctx => {
    need(ctx, 'admin');
    const b = ctx.body;
    const images = Array.isArray(b.images) ? b.images : [];
    if (images.length > 10) throw bad('الحد الأقصى 10 صور');
    const decoded = images.map(decodeImage);
    const id = newId('evt'), saved = [];
    try {
      tx(db, () => {
        q('INSERT INTO posts(id,title,body,type,audience,date,time,location,author,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(
          id, V.str(b.title, 'العنوان', { required: true, max: 150 }), V.str(b.body, 'التفاصيل', { required: true, max: 5000 }),
          V.one(b.type, 'النوع', EVT_TYPES, 'event'), V.one(b.audience, 'الجمهور', AUD, 'all'),
          V.date(b.date, 'التاريخ') || isoDaysAgo(0), V.str(b.time, 'الوقت', { max: 40 }), V.str(b.location, 'المكان', { max: 120 }),
          ctx.user.name, nowIso());
        decoded.forEach((d, i) => {
          const file = crypto.randomBytes(12).toString('hex') + '.' + d.ext;
          fs.writeFileSync(path.join(DATA_DIR, 'uploads', file), d.buf);
          saved.push(file);
          q('INSERT INTO post_images(id,post_id,file,position) VALUES(?,?,?,?)').run(newId('im'), id, file, i);
        });
        audit(ctx, 'نشر منشور: ' + V.str(b.title, '', { max: 60 }));
      });
    } catch (e) {
      saved.forEach(f => { try { fs.unlinkSync(path.join(DATA_DIR, 'uploads', f)); } catch (_) {} });
      throw e;
    }
    sendJson(ctx.res, 201, { id });
  }, { limit: 16 * 1024 * 1024 });
  R('DELETE', '/api/posts/:id', ctx => {
    need(ctx, 'admin');
    const p = q('SELECT title FROM posts WHERE id=?').get(ctx.params.id);
    if (!p) throw notFound('المنشور');
    const files = q('SELECT file FROM post_images WHERE post_id=?').all(ctx.params.id).map(r => r.file);
    q('DELETE FROM posts WHERE id=?').run(ctx.params.id);
    files.forEach(f => { try { fs.unlinkSync(path.join(DATA_DIR, 'uploads', f)); } catch (_) {} });
    audit(ctx, 'حذف منشور: ' + p.title);
    sendJson(ctx.res, 200, { ok: true });
  });
  R('POST', '/api/posts/:id/like', ctx => {
    const p = visiblePost(ctx, ctx.params.id);
    const ex = q('SELECT 1 FROM post_likes WHERE post_id=? AND user_id=?').get(p.id, ctx.user.id);
    if (ex) q('DELETE FROM post_likes WHERE post_id=? AND user_id=?').run(p.id, ctx.user.id);
    else q('INSERT INTO post_likes(post_id,user_id,name,created_at) VALUES(?,?,?,?)').run(p.id, ctx.user.id, ctx.user.name, nowIso());
    sendJson(ctx.res, 200, { liked: !ex });
  }, { limit: 1024 });
  R('POST', '/api/posts/:id/comments', ctx => {
    const p = visiblePost(ctx, ctx.params.id);
    const text = V.str(ctx.body.text, 'التعليق', { required: true, max: 1000 });
    q('INSERT INTO post_comments(id,post_id,user_id,name,text,created_at) VALUES(?,?,?,?,?,?)').run(newId('cm'), p.id, ctx.user.id, ctx.user.name, text, nowIso());
    sendJson(ctx.res, 201, { ok: true });
  }, { limit: 4096 });
  R('DELETE', '/api/comments/:id', ctx => {
    const c = q('SELECT * FROM post_comments WHERE id=?').get(ctx.params.id);
    if (!c) throw notFound('التعليق');
    if (ctx.user.role !== 'admin' && c.user_id !== ctx.user.id) throw new HttpError(403, 'غير مصرح');
    q('DELETE FROM post_comments WHERE id=?').run(c.id);
    sendJson(ctx.res, 200, { ok: true });
  });

  /* ---------- الدعم الفني (تذاكر خاصة) ---------- */
  function ticketFor(ctx, id) {
    const t = q('SELECT * FROM tickets WHERE id=?').get(id);
    if (!t || (ctx.user.role !== 'admin' && t.user_id !== ctx.user.id)) throw notFound('التذكرة');
    return t;
  }
  const msgLimiter = new sec.RateLimiter(30, 60e3);
  R('POST', '/api/tickets', ctx => {
    need(ctx, 'teacher', 'student', 'parent');
    if (msgLimiter.blocked(ctx.user.id)) throw new HttpError(429, 'أرسلت رسائل كثيرة، انتظر قليلاً');
    msgLimiter.hit(ctx.user.id);
    const b = ctx.body, role = ctx.user.role;
    const type = V.one(b.type, 'نوع التذكرة', ['inquiry', 'absence', 'general']);
    const subject = V.str(b.subject, 'الموضوع', { required: true, max: 150 }), body = V.str(b.body, 'الرسالة', { required: true, max: 4000 });
    let related = null, absenceDate = null, reason = null;
    if (type === 'absence') {
      if (role === 'teacher') throw bad('طلبات الإذن للطلاب وأولياء الأمور فقط');
      absenceDate = V.date(b.absenceDate, 'تاريخ الغياب', true);
      reason = V.one(b.reason, 'السبب', REASONS);
      if (role === 'student') related = ctx.user.ref_id;
      else {
        related = V.id(b.studentId, 'الطالب', true);
        if (!q('SELECT 1 FROM students WHERE id=? AND parent_id=?').get(related, ctx.user.ref_id)) throw new HttpError(403, 'هذا الطالب ليس من أبنائك');
      }
    }
    const id = newId('tk'), now = nowIso();
    tx(db, () => {
      q('INSERT INTO tickets(id,user_id,user_name,user_role,type,subject,status,created_at,related_student_id,absence_date,reason,admin_unread,user_unread) VALUES(?,?,?,?,?,?,?,?,?,?,?,1,0)')
        .run(id, ctx.user.id, ctx.user.name, role, type, subject, 'open', now, related, absenceDate, reason);
      q('INSERT INTO ticket_messages(id,ticket_id,sender_id,sender_name,sender_role,text,created_at) VALUES(?,?,?,?,?,?,?)')
        .run(newId('m'), id, ctx.user.id, ctx.user.name, role, body, now);
      audit(ctx, 'تذكرة جديدة: ' + subject.slice(0, 60));
    });
    sendJson(ctx.res, 201, { id });
  });
  R('POST', '/api/tickets/:id/messages', ctx => {
    const t = ticketFor(ctx, ctx.params.id);
    if (t.status !== 'open') throw new HttpError(409, 'التذكرة مغلقة');
    if (msgLimiter.blocked(ctx.user.id)) throw new HttpError(429, 'أرسلت رسائل كثيرة، انتظر قليلاً');
    msgLimiter.hit(ctx.user.id);
    const text = V.str(ctx.body.text, 'الرسالة', { required: true, max: 4000 });
    tx(db, () => {
      q('INSERT INTO ticket_messages(id,ticket_id,sender_id,sender_name,sender_role,text,created_at) VALUES(?,?,?,?,?,?,?)')
        .run(newId('m'), t.id, ctx.user.id, ctx.user.name, ctx.user.role, text, nowIso());
      if (ctx.user.role === 'admin') q('UPDATE tickets SET user_unread=1 WHERE id=?').run(t.id);
      else q('UPDATE tickets SET admin_unread=1 WHERE id=?').run(t.id);
    });
    sendJson(ctx.res, 201, { ok: true });
  }, { limit: 8192 });
  R('POST', '/api/tickets/:id/read', ctx => {
    const t = ticketFor(ctx, ctx.params.id);
    if (ctx.user.role === 'admin') q('UPDATE tickets SET admin_unread=0 WHERE id=?').run(t.id);
    else q('UPDATE tickets SET user_unread=0 WHERE id=?').run(t.id);
    sendJson(ctx.res, 200, { ok: true });
  }, { limit: 1024 });
  R('POST', '/api/tickets/:id/close', ctx => {
    need(ctx, 'admin');
    const t = ticketFor(ctx, ctx.params.id);
    q("UPDATE tickets SET status='closed' WHERE id=?").run(t.id);
    audit(ctx, 'إغلاق تذكرة: ' + t.subject.slice(0, 60));
    sendJson(ctx.res, 200, { ok: true });
  }, { limit: 1024 });
  R('POST', '/api/tickets/:id/reopen', ctx => {
    need(ctx, 'admin');
    const t = ticketFor(ctx, ctx.params.id);
    if (t.status === 'resolved') throw new HttpError(409, 'تذكرة معتمدة ولا يمكن إعادة فتحها');
    q("UPDATE tickets SET status='open' WHERE id=?").run(t.id);
    audit(ctx, 'إعادة فتح تذكرة: ' + t.subject.slice(0, 60));
    sendJson(ctx.res, 200, { ok: true });
  }, { limit: 1024 });
  R('POST', '/api/tickets/:id/approve', ctx => {
    need(ctx, 'admin');
    const t = ticketFor(ctx, ctx.params.id);
    if (t.type !== 'absence' || t.status !== 'open') throw new HttpError(409, 'لا يمكن اعتماد هذه التذكرة');
    const st = q('SELECT id,class_id FROM students WHERE id=?').get(t.related_student_id);
    if (!st) throw bad('الطالب المرتبط غير موجود');
    tx(db, () => {
      const r = q("UPDATE attendance SET status='excused',note='إذن معتمد' WHERE student_id=? AND date=?").run(st.id, t.absence_date);
      if (!r.changes) q('INSERT INTO attendance(id,student_id,class_id,subject_id,teacher_id,date,status,note,created_at) VALUES(?,?,?,NULL,NULL,?,?,?,?)')
        .run(newId('a'), st.id, st.class_id, t.absence_date, 'excused', 'إذن معتمد', nowIso());
      q("UPDATE tickets SET status='resolved',user_unread=1 WHERE id=?").run(t.id);
      q('INSERT INTO ticket_messages(id,ticket_id,sender_id,sender_name,sender_role,text,created_at) VALUES(?,?,?,?,?,?,?)')
        .run(newId('m'), t.id, ctx.user.id, ctx.user.name, 'admin', '✅ تم اعتماد طلب الإذن وتسجيل الغياب كغياب بعذر.', nowIso());
      audit(ctx, 'اعتماد إذن غياب: ' + t.subject.slice(0, 60));
    });
    sendJson(ctx.res, 200, { ok: true });
  }, { limit: 1024 });

  /* ---------- نسخة احتياطية (للمدير) ---------- */
  R('GET', '/api/backup', ctx => {
    need(ctx, 'admin');
    const tmp = path.join(DATA_DIR, `backup-${Date.now()}-${crypto.randomBytes(4).toString('hex')}.db`);
    db.exec(`VACUUM INTO '${tmp.replace(/'/g, "''")}'`);
    audit(ctx, 'تنزيل نسخة احتياطية');
    const stamp = new Date().toISOString().slice(0, 10);
    const st = fs.statSync(tmp);
    ctx.res.writeHead(200, {
      'Content-Type': 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-store',
      'Content-Disposition': `attachment; filename="alphabet-backup-${stamp}.db"`
    });
    const rs = fs.createReadStream(tmp);
    rs.pipe(ctx.res);
    const done = () => fs.unlink(tmp, () => {});
    rs.on('close', done); ctx.res.on('close', done);
  });

  /* ======================== المُرسِل الرئيسي ======================== */
  async function handle(req, res, url) {
    const ip = config.trustProxy && req.headers['x-forwarded-for']
      ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : (req.socket.remoteAddress || '');
    const secure = !!req.socket.encrypted || (config.trustProxy && req.headers['x-forwarded-proto'] === 'https') || config.secureCookies;
    const ctx = { req, res, ip, secure, query: url.searchParams, params: {}, body: {}, user: null };
    try {
      if (apiByIp.blocked(ip)) throw new HttpError(429, 'طلبات كثيرة، حاول لاحقاً');
      apiByIp.hit(ip);
      const { route, params, pathMatched } = router.match(req.method, url.pathname);
      if (!route) throw new HttpError(pathMatched ? 405 : 404, pathMatched ? 'الطريقة غير مسموحة' : 'غير موجود');
      ctx.params = params;
      const opts = route.opts, mutating = req.method !== 'GET' && req.method !== 'HEAD';

      /* حماية CSRF: يجب أن يتطابق Origin مع المضيف عند وجوده */
      if (mutating) {
        const origin = req.headers.origin;
        if (origin) {
          let oh = ''; try { oh = new URL(origin).host; } catch (_) {}
          const host = (config.trustProxy && req.headers['x-forwarded-host']) || req.headers.host;
          if (oh !== host) throw new HttpError(403, 'طلب مرفوض (مصدر غير موثوق)');
        }
      }

      if (opts.auth !== false) {
        const sid = parseCookies(req.headers.cookie).sid;
        if (!sid) throw new HttpError(401, 'يرجى تسجيل الدخول', 'AUTH');
        const row = q(`SELECT s.id sid, s.expires_at, u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=?`).get(sec.hashToken(sid));
        if (!row || row.expires_at < nowIso() || !row.active) throw new HttpError(401, 'انتهت الجلسة، سجّل الدخول من جديد', 'AUTH');
        ctx.sessionId = row.sid;
        ctx.user = row;
        const allowedWhileMust = ['/api/me', '/api/logout', '/api/password'];
        if (row.must_change && !allowedWhileMust.includes(url.pathname)) throw new HttpError(403, 'يجب تغيير كلمة المرور أولاً', 'MUST_CHANGE');
      }
      if (mutating) ctx.body = await readJson(req, opts.limit || 200 * 1024);
      await route.handler(ctx);
      if (mutating && opts.auth !== false && url.pathname !== '/api/logout' && !url.pathname.endsWith('/read')) version++;
    } catch (e) {
      if (res.headersSent) { try { res.end(); } catch (_) {} return; }
      if (e instanceof HttpError) return sendJson(res, e.status, { error: e.message, code: e.code });
      if (e && /UNIQUE constraint/.test(String(e.message))) return sendJson(res, 409, { error: 'القيمة مكررة، تحقق من البيانات' });
      if (e && /FOREIGN KEY constraint/.test(String(e.message))) return sendJson(res, 409, { error: 'العملية مرتبطة ببيانات أخرى' });
      console.error('[خطأ]', req.method, url.pathname, e);
      sendJson(res, 500, { error: 'حدث خطأ في الخادم' });
    }
  }

  return { handle, buildBootstrap, bump: () => { version++; } };
};
