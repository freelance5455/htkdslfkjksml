'use strict';
/**
 * قاعدة بيانات SQLite الخاصة بالتطبيق (ملف واحد: data/alphabet.db)
 * تستخدم الوحدة المدمجة node:sqlite — لا تحتاج أي حزم خارجية.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(path.join(DATA_DIR, 'uploads'), { recursive: true });

const SCHEMA_V1 = `
CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE users(
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN('admin','teacher','student','parent')),
  name TEXT NOT NULL,
  ref_id TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  must_change INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  last_login TEXT
);
CREATE INDEX idx_users_ref ON users(role, ref_id);

CREATE TABLE sessions(
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  ip TEXT, ua TEXT
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE subjects(id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE classes(id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, grade TEXT NOT NULL DEFAULT '');

CREATE TABLE teachers(
  id TEXT PRIMARY KEY, name TEXT NOT NULL, spec TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN('active','inactive'))
);
CREATE TABLE teacher_subjects(
  teacher_id TEXT NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE RESTRICT,
  PRIMARY KEY(teacher_id, subject_id)
);
CREATE TABLE teacher_classes(
  teacher_id TEXT NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  class_id TEXT NOT NULL REFERENCES classes(id) ON DELETE RESTRICT,
  PRIMARY KEY(teacher_id, class_id)
);

CREATE TABLE parents(
  id TEXT PRIMARY KEY, name TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT ''
);

CREATE TABLE students(
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  class_id TEXT REFERENCES classes(id) ON DELETE SET NULL,
  parent_id TEXT REFERENCES parents(id) ON DELETE SET NULL,
  birth TEXT NOT NULL DEFAULT '',
  gender TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  addr TEXT NOT NULL DEFAULT '',
  enroll TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN('active','inactive')),
  fee INTEGER NOT NULL DEFAULT 0,
  notes TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_students_class ON students(class_id);
CREATE INDEX idx_students_parent ON students(parent_id);

CREATE TABLE attendance(
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  class_id TEXT REFERENCES classes(id) ON DELETE SET NULL,
  subject_id TEXT REFERENCES subjects(id) ON DELETE SET NULL,
  teacher_id TEXT REFERENCES teachers(id) ON DELETE SET NULL,
  date TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN('present','absent','late','excused')),
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX uq_att ON attendance(student_id, date, COALESCE(subject_id,''));
CREATE INDEX idx_att_date ON attendance(date);

CREATE TABLE exams(
  id TEXT PRIMARY KEY, title TEXT NOT NULL,
  class_id TEXT NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE RESTRICT,
  teacher_id TEXT REFERENCES teachers(id) ON DELETE SET NULL,
  date TEXT NOT NULL, max INTEGER NOT NULL DEFAULT 100, pass INTEGER NOT NULL DEFAULT 50,
  type TEXT NOT NULL DEFAULT 'شهري'
);
CREATE TABLE grades(
  id TEXT PRIMARY KEY,
  exam_id TEXT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  score REAL NOT NULL, created_at TEXT NOT NULL,
  UNIQUE(exam_id, student_id)
);
CREATE TABLE evaluations(
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id TEXT REFERENCES subjects(id) ON DELETE SET NULL,
  teacher_id TEXT REFERENCES teachers(id) ON DELETE SET NULL,
  date TEXT NOT NULL, rating TEXT NOT NULL DEFAULT '', comment TEXT NOT NULL DEFAULT ''
);

CREATE TABLE payments(
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL CHECK(amount > 0),
  date TEXT NOT NULL, method TEXT NOT NULL DEFAULT 'cash',
  ref TEXT NOT NULL UNIQUE, note TEXT NOT NULL DEFAULT '',
  by_name TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE announcements(
  id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL,
  audience TEXT NOT NULL DEFAULT 'all', date TEXT NOT NULL, author TEXT NOT NULL DEFAULT ''
);

CREATE TABLE posts(
  id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'event', audience TEXT NOT NULL DEFAULT 'all',
  date TEXT NOT NULL, time TEXT NOT NULL DEFAULT '', location TEXT NOT NULL DEFAULT '',
  author TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE post_images(
  id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  file TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE post_likes(
  post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, created_at TEXT NOT NULL,
  PRIMARY KEY(post_id, user_id)
);
CREATE TABLE post_comments(
  id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, text TEXT NOT NULL, created_at TEXT NOT NULL
);

CREATE TABLE tickets(
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_name TEXT NOT NULL, user_role TEXT NOT NULL,
  type TEXT NOT NULL CHECK(type IN('inquiry','absence','general')),
  subject TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN('open','closed','resolved')),
  created_at TEXT NOT NULL,
  related_student_id TEXT REFERENCES students(id) ON DELETE SET NULL,
  absence_date TEXT, reason TEXT,
  admin_unread INTEGER NOT NULL DEFAULT 0, user_unread INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_tickets_user ON tickets(user_id);
CREATE TABLE ticket_messages(
  id TEXT PRIMARY KEY,
  ticket_id TEXT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  sender_id TEXT NOT NULL, sender_name TEXT NOT NULL, sender_role TEXT NOT NULL,
  text TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX idx_tmsg_ticket ON ticket_messages(ticket_id);

CREATE TABLE broadcasts(
  id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL,
  audience TEXT NOT NULL DEFAULT 'all', author TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT, name TEXT, role TEXT, action TEXT NOT NULL, ip TEXT, created_at TEXT NOT NULL
);
`;

function open(file) {
  const db = new DatabaseSync(file || path.join(DATA_DIR, 'alphabet.db'));
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');
  const v = db.prepare('PRAGMA user_version').get().user_version;
  if (v < 1) {
    db.exec('BEGIN');
    try {
      db.exec(SCHEMA_V1);
      const ins = db.prepare('INSERT INTO settings(key,value) VALUES(?,?)');
      const defaults = {
        inst: 'معهد الفابت التعليمي', mgr: 'أ. ميرزان حنو', currency: 'ل.س',
        year: '2025/2026', phone: '', addr: ''
      };
      for (const [k, val] of Object.entries(defaults)) ins.run(k, val);
      db.exec('PRAGMA user_version = 1');
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
  }
  return db;
}

/** تنفيذ مجموعة عمليات داخل معاملة واحدة (كلها أو لا شيء) */
function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { try { db.exec('ROLLBACK'); } catch (_) {} throw e; }
}

function newId(prefix) { return prefix + '_' + crypto.randomBytes(6).toString('hex'); }
const nowIso = () => new Date().toISOString();

module.exports = { open, tx, newId, nowIso, DATA_DIR };
