'use strict';
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'alp-test-'));

const test = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../server/server');

let base, srv;
const known = {};
const ORIGIN_OK = () => base;

/* عميل بسيط يحتفظ بالكوكي */
function client() {
  let cookie = '';
  async function call(method, url, body, extra) {
    const headers = Object.assign({}, extra || {});
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (cookie) headers.Cookie = cookie;
    const r = await fetch(base + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0].replace(/^sid=$/, '');
    let data = null; const t = await r.text(); try { data = JSON.parse(t); } catch { data = t; }
    return { status: r.status, data, headers: r.headers };
  }
    return {
    get: (u, h) => call('GET', u, undefined, h), post: (u, b, h) => call('POST', u, b === undefined ? {} : b, h),
    put: (u, b) => call('PUT', u, b), del: (u) => call('DELETE', u),
    async login(username, password, newPw) {
      const pw = known[username] || password;
      const r = await call('POST', '/api/login', { username, password: pw });
      assert.equal(r.status, 200, 'login ' + username + ' ' + JSON.stringify(r.data));
      if (r.data.user.mustChange) {
        const c = await call('POST', '/api/password', { current: pw, next: newPw || 'Newpass2026' });
        assert.equal(c.status, 200, JSON.stringify(c.data));
        known[username] = newPw || 'Newpass2026';
      }
      return r.data.user;
    }
  };
}

const admin = client(); const ids = {};

test.before(async () => {
  process.env.ADMIN_PASSWORD = 'Admin12345';
  const { server } = createServer({ trustProxy: false });
  srv = server;
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
});
test.after(() => srv.close());

test('الدخول الأول يفرض تغيير كلمة المرور ولا يسمح بغيره قبلها', async () => {
  const c = client();
  const r = await c.post('/api/login', { username: 'admin', password: 'Admin12345' });
  assert.equal(r.status, 200); assert.equal(r.data.user.mustChange, true);
  assert.equal((await c.get('/api/bootstrap')).status, 403);
  assert.equal((await c.post('/api/password', { current: 'Admin12345', next: 'short' })).status, 400);
  assert.equal((await c.post('/api/password', { current: 'Admin12345', next: 'Admin12345' })).status, 400);
  assert.equal((await c.post('/api/password', { current: 'Admin12345', next: 'Strong2026pw' })).status, 200);
  assert.equal((await c.get('/api/bootstrap')).status, 200);
  await admin.login('admin', 'Strong2026pw');
});

test('بدون جلسة: كل الواجهة الخلفية مرفوضة', async () => {
  const c = client();
  for (const u of ['/api/bootstrap', '/api/me', '/api/poll', '/api/backup']) assert.equal((await c.get(u)).status, 401, u);
  assert.equal((await c.post('/api/students', {})).status, 401);
});

test('المدير ينشئ الصفوف والمواد والمعلم وولي الأمر والطلاب', async () => {
  ids.c1 = (await admin.post('/api/classes', { name: 'السابع - أ' })).data.id;
  ids.c2 = (await admin.post('/api/classes', { name: 'الثامن - أ' })).data.id;
  assert.equal((await admin.post('/api/classes', { name: 'السابع - أ' })).status, 400);
  ids.s1 = (await admin.post('/api/subjects', { name: 'الرياضيات' })).data.id;
  ids.s2 = (await admin.post('/api/subjects', { name: 'العلوم' })).data.id;
  const t = await admin.post('/api/teachers', { name: 'أ. سارة', user: 'sara', subs: [ids.s1], classes: [ids.c1] });
  assert.equal(t.status, 201); ids.t1 = t.data.id; ids.tCred = t.data.credentials;
  assert.equal(ids.tCred.username, 'sara'); assert.ok(ids.tCred.password.length >= 8);
  const p = await admin.post('/api/parents', { name: 'ولي أمر 1' }); ids.p1 = p.data.id; ids.pCred = p.data.credentials;
  const p2 = await admin.post('/api/parents', { name: 'ولي أمر 2' }); ids.p2 = p2.data.id; ids.p2Cred = p2.data.credentials;
  const s1 = await admin.post('/api/students', { name: 'طالب أ', classId: ids.c1, parentId: ids.p1, fee: 1000000 });
  assert.equal(s1.status, 201); ids.st1 = s1.data.id; ids.st1Cred = s1.data.credentials; assert.match(s1.data.code, /^ALP-\d+$/);
  const s2 = await admin.post('/api/students', { name: 'طالب ب', classId: ids.c2, parentId: ids.p2, fee: 500000 });
  ids.st2 = s2.data.id; ids.st2Cred = s2.data.credentials;
  assert.notEqual(s1.data.code, s2.data.code);
  assert.equal((await admin.post('/api/students', { name: '', classId: ids.c1 })).status, 400);
  assert.equal((await admin.post('/api/students', { name: 'x', classId: 'nope_class' })).status, 400);
});

test('تعديل المعلم لا يمسح صفوفه ومواده (خطأ كان في النسخة القديمة)', async () => {
  const r = await admin.put('/api/teachers/' + ids.t1, { name: 'أ. سارة يوسف', spec: 'رياضيات', user: 'sara', subs: [ids.s1], classes: [ids.c1] });
  assert.equal(r.status, 200);
  const b = (await admin.get('/api/bootstrap')).data;
  const t = b.teachers.find(x => x.id === ids.t1);
  assert.deepEqual(t.subs, [ids.s1]); assert.deepEqual(t.classes, [ids.c1]); assert.equal(t.name, 'أ. سارة يوسف');
});

test('الطالب: يرى بياناته فقط ولا يستطيع الإدارة', async () => {
  const st = client(); await st.login(ids.st1Cred.username, ids.st1Cred.password);
  const b = (await st.get('/api/bootstrap')).data;
  assert.equal(b.students.length, 1); assert.equal(b.students[0].id, ids.st1);
  assert.equal(b.pays.length, 0); assert.equal(b.accounts, undefined); assert.equal(b.audit, undefined);
  assert.equal(b.students[0].notes, '');
  assert.equal((await st.post('/api/students', { name: 'x', classId: ids.c1 })).status, 403);
  assert.equal((await st.post('/api/payments', { studentId: ids.st1, amount: 5 })).status, 403);
  assert.equal((await st.get('/api/backup')).status, 403);
  assert.equal((await st.put('/api/settings', { inst: 'hack' })).status, 403);
});

test('المعلم: حضور في صفوفه فقط، ولا يرى المالية ولا بيانات الأقساط', async () => {
  const t = client(); await t.login(ids.tCred.username, ids.tCred.password);
  const b = (await t.get('/api/bootstrap')).data;
  assert.equal(b.students.length, 1); assert.equal(b.students[0].fee, undefined); assert.equal(b.pays.length, 0);
  const d = new Date().toISOString().slice(0, 10);
  assert.equal((await t.put('/api/attendance', { studentId: ids.st1, classId: ids.c1, subjectId: ids.s1, date: d, status: 'absent' })).status, 200);
  assert.equal((await t.put('/api/attendance', { studentId: ids.st1, classId: ids.c1, subjectId: ids.s1, date: d, status: 'late' })).status, 200);
  const att = (await t.get('/api/bootstrap')).data.att.filter(a => a.studentId === ids.st1 && a.date === d);
  assert.equal(att.length, 1, 'تحديث لا تكرار'); assert.equal(att[0].status, 'late');
  assert.equal((await t.put('/api/attendance', { studentId: ids.st2, classId: ids.c2, subjectId: ids.s1, date: d, status: 'absent' })).status, 403, 'صف غير مسند');
  assert.equal((await t.put('/api/attendance', { studentId: ids.st1, classId: ids.c1, subjectId: ids.s2, date: d, status: 'absent' })).status, 403, 'مادة غير مسندة');
  assert.equal((await t.put('/api/attendance', { studentId: ids.st1, classId: ids.c1, subjectId: ids.s1, date: d, status: 'bogus' })).status, 400);
  assert.equal((await t.post('/api/payments', { studentId: ids.st1, amount: 100 })).status, 403);
  assert.equal((await t.post('/api/announcements', { title: 'a', body: 'b' })).status, 403);
});

test('الامتحانات والدرجات: صلاحيات المعلم وحدود الدرجة', async () => {
  const t = client(); await t.login(ids.tCred.username, ids.tCred.password);
  assert.equal((await t.post('/api/exams', { title: 'x', classId: ids.c2, subjectId: ids.s1, date: '2026-01-01' })).status, 403);
  const e = await t.post('/api/exams', { title: 'امتحان 1', classId: ids.c1, subjectId: ids.s1, date: '2026-01-01', max: 50, pass: 25 });
  assert.equal(e.status, 201); ids.e1 = e.data.id;
  assert.equal((await t.put(`/api/exams/${ids.e1}/grades`, { grades: { [ids.st1]: 51 } })).status, 400, 'أكبر من القصوى');
  assert.equal((await t.put(`/api/exams/${ids.e1}/grades`, { grades: { [ids.st2]: 10 } })).status, 400, 'طالب من صف آخر');
  assert.equal((await t.put(`/api/exams/${ids.e1}/grades`, { grades: { [ids.st1]: 44 } })).status, 200);
  const adminExam = (await admin.post('/api/exams', { title: 'امتحان المدير', classId: ids.c1, subjectId: ids.s1, date: '2026-01-02', teacherId: null })).data.id;
  assert.equal((await t.put(`/api/exams/${adminExam}/grades`, { grades: {} })).status, 403, 'ليس امتحانه');
  const st = client(); await st.login(ids.st1Cred.username, ids.st1Cred.password);
  const g = (await st.get('/api/bootstrap')).data.grades;
  assert.equal(g.length, 1); assert.equal(g[0].score, 44);
});

test('الأقساط: إيصالات متسلسلة، حذف الطالب ذي المدفوعات مرفوض', async () => {
  const a = await admin.post('/api/payments', { studentId: ids.st1, amount: 300000 });
  const b = await admin.post('/api/payments', { studentId: ids.st1, amount: 200000 });
  assert.equal(a.status, 201); assert.notEqual(a.data.ref, b.data.ref);
  assert.equal((await admin.post('/api/payments', { studentId: ids.st1, amount: -5 })).status, 400);
  assert.equal((await admin.post('/api/payments', { studentId: ids.st1, amount: 1.5 })).status, 400);
  assert.equal((await admin.del('/api/students/' + ids.st1)).status, 409);
  const st = client(); await st.login(ids.st1Cred.username, 'Newpass2026');
  assert.equal((await st.get('/api/bootstrap')).data.pays.length, 2);
  const par2 = client(); await par2.login(ids.p2Cred.username, ids.p2Cred.password);
  assert.equal((await par2.get('/api/bootstrap')).data.pays.length, 0, 'ولي الأمر الآخر لا يرى مدفوعات غير أبنائه');
});

test('التذاكر خاصة: لا يراها إلا صاحبها والمدير', async () => {
  const par = client(); await par.login(ids.pCred.username, ids.pCred.password);
  const par2 = client(); await par2.login(ids.p2Cred.username, 'Newpass2026');
  const d = '2026-02-02';
  assert.equal((await par.post('/api/tickets', { type: 'absence', subject: 'غياب', body: 'مرض', absenceDate: d, reason: 'مرض', studentId: ids.st2 })).status, 403, 'ليس ابنه');
  const t = await par.post('/api/tickets', { type: 'absence', subject: 'إذن غياب', body: 'ابني مريض', absenceDate: d, reason: 'مرض', studentId: ids.st1 });
  assert.equal(t.status, 201); ids.tk = t.data.id;
  const b2 = (await par2.get('/api/bootstrap')).data;
  assert.equal(b2.tickets.length, 0);
  assert.equal((await par2.post(`/api/tickets/${ids.tk}/messages`, { text: 'تطفل' })).status, 404);
  assert.equal((await par2.post(`/api/tickets/${ids.tk}/read`)).status, 404);
  assert.equal((await par.post(`/api/tickets/${ids.tk}/approve`)).status, 403, 'ولي الأمر لا يعتمد');
  const ab = (await admin.get('/api/bootstrap')).data;
  assert.equal(ab.tickets.find(x => x.id === ids.tk).adminUnread, true);
  assert.equal((await admin.post(`/api/tickets/${ids.tk}/messages`, { text: 'ألف سلامة' })).status, 201);
  assert.equal((await par.get('/api/poll')).data.unread, 1);
  assert.equal((await admin.post(`/api/tickets/${ids.tk}/approve`)).status, 200);
  const att = (await admin.get(`/api/attendance?from=${d}&to=${d}`)).data.att.filter(a => a.studentId === ids.st1);
  assert.ok(att.length === 1 && att[0].status === 'excused', 'تسجيل غياب بعذر حتى بدون سجل سابق (تاريخ خارج النافذة)');
  assert.equal((await admin.get('/api/attendance?from=2020-01-01&to=2026-01-01')).status, 400, 'مدى كبير مرفوض');
  assert.equal((await par.post(`/api/tickets/${ids.tk}/messages`, { text: 'شكراً' })).status, 409, 'مغلقة بعد الاعتماد');
});

test('حماية: CSRF، نوع المحتوى، تجاوز المسارات، رؤوس الأمان', async () => {
  const r1 = await fetch(base + '/api/logout', { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'http://evil.example' }, body: '{}' });
  assert.equal(r1.status, 403);
  const c = client(); await c.login('admin', 'Strong2026pw');
  const r2 = await c.post('/api/classes', { name: 'خارجي' }, { Origin: 'http://evil.example' });
  assert.equal(r2.status, 403);
  const r3 = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'x' });
  assert.equal(r3.status, 415);
  for (const p of ['/..%2f..%2f..%2fetc%2fpasswd', '/%2e%2e/server/db.js', '/uploads/../alphabet.db', '/uploads/zzzz.jpg', '/server/server.js']) {
    const r = await fetch(base + p);
    const t = await r.text();
    assert.ok(!/root:|DatabaseSync|SQLite format/.test(t), 'تسريب عبر ' + p);
  }
  const h = (await fetch(base + '/api/public')).headers;
  assert.match(h.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.equal(h.get('x-content-type-options'), 'nosniff');
});

test('تحديد محاولات الدخول الخاطئة', async () => {
  const c = client(); let last;
  for (let i = 0; i < 8; i++) last = await c.post('/api/login', { username: 'sara', password: 'wrong' + i });
  assert.equal(last.status, 429);
  const ok = await c.post('/api/login', { username: 'sara', password: ids.tCred.password });
  assert.equal(ok.status, 429, 'حتى كلمة المرور الصحيحة محجوبة أثناء الحظر');
  const other = client();
  assert.equal((await other.post('/api/login', { username: 'nobody', password: 'x' })).status, 401);
});

test('المنشورات: رفع صور آمن فقط (لا SVG ولا ملفات مزيفة)', async () => {
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const good = 'data:image/png;base64,' + png.toString('base64');
  const r = await admin.post('/api/posts', { title: 'حفل', body: 'تفاصيل', type: 'event', audience: 'all', images: [good] });
  assert.equal(r.status, 201);
  const b = (await admin.get('/api/bootstrap')).data;
  const p = b.events.find(e => e.id === r.data.id); assert.equal(p.images.length, 1);
  const img = await fetch(base + p.images[0]); assert.equal(img.status, 200); assert.equal(img.headers.get('content-type'), 'image/png');
  const svg = 'data:image/svg+xml;base64,' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>').toString('base64');
  assert.equal((await admin.post('/api/posts', { title: 'x', body: 'y', images: [svg] })).status, 400);
  const fake = 'data:image/png;base64,' + Buffer.from('<html>not an image</html>').toString('base64');
  assert.equal((await admin.post('/api/posts', { title: 'x', body: 'y', images: [fake] })).status, 400);
  const st = client(); await st.login(ids.st1Cred.username, 'Newpass2026');
  assert.equal((await st.post(`/api/posts/${r.data.id}/like`)).data.liked, true);
  assert.equal((await st.post(`/api/posts/${r.data.id}/comments`, { text: '<img src=x onerror=alert(1)>' })).status, 201);
  assert.equal((await st.del('/api/posts/' + r.data.id)).status, 403);
  assert.equal((await admin.del('/api/posts/' + r.data.id)).status, 200);
  assert.equal((await fetch(base + p.images[0])).status, 404, 'حذف الملف عند حذف المنشور');
});

test('إعادة تعيين كلمة المرور وإيقاف الحساب', async () => {
  const acc = (await admin.get('/api/bootstrap')).data.accounts.find(a => a.username === ids.p2Cred.username);
  const r = await admin.post(`/api/users/${acc.id}/reset-password`);
  assert.equal(r.status, 200);
  const par2 = client();
  assert.equal((await par2.post('/api/login', { username: ids.p2Cred.username, password: 'Newpass2026' })).status, 401, 'القديمة لا تعمل');
  const l = await par2.post('/api/login', { username: ids.p2Cred.username, password: r.data.password });
  assert.equal(l.data.user.mustChange, true);
  assert.equal((await admin.put(`/api/users/${acc.id}/active`, { active: false })).status, 200);
  assert.equal((await par2.get('/api/me')).status, 401, 'الجلسة تُنهى فور الإيقاف');
});

test('النسخة الاحتياطية ملف SQLite صالح، والتدقيق يسجل العمليات', async () => {
  assert.equal((await fetch(base + '/api/backup')).status, 401);
  const a2 = client(); await a2.login('admin', 'Strong2026pw');
  const res = await a2.get('/api/backup');
  assert.equal(res.status, 200);
  assert.ok(String(res.data).startsWith('SQLite format 3'), 'ملف SQLite');
  const audit = (await a2.get('/api/bootstrap')).data.audit;
  assert.ok(audit.some(x => /إضافة طالب/.test(x.action)) && audit.some(x => /فشل تسجيل دخول/.test(x.action)));
});
