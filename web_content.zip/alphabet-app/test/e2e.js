'use strict';
/* اختبار شامل في متصفح حقيقي: node test/e2e.js  (يتطلب playwright + chrome) */
const os = require('os'), fs = require('fs'), path = require('path'), { execSync, spawn } = require('child_process');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'alp-e2e-'));
const env = Object.assign({}, process.env, { DATA_DIR: dir, PORT: '3222' });
execSync('node --no-warnings scripts/seed-demo.js', { env, stdio: 'ignore' });
const srv = spawn('node', ['--no-warnings', 'server/server.js'], { env, stdio: 'ignore' });
const { chromium } = require(process.env.PW_PATH || '/opt/npm-tools/node_modules/playwright');
const B = 'http://127.0.0.1:3222', PW = 'Demo@12345';
const errors = [];
(async () => {
  await new Promise(r => setTimeout(r, 1500));
  const br = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const mk = async (name) => {
    const ctx = await br.newContext({ viewport: { width: 1280, height: 900 }, locale: 'ar' });
    const page = await ctx.newPage();
    page.on('pageerror', e => errors.push(name + ' pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error' && !/401|403|409|400/.test(m.text())) errors.push(name + ' console: ' + m.text()); });
    page.on('dialog', d => d.accept());
    await page.goto(B); return page;
  };
  const login = async (p, u, pw) => { await p.fill('#lu', u); await p.fill('#lp', pw); await p.click('#lbtn'); await p.waitForSelector('#shell .side', { timeout: 8000 }); };
  const text = async p => (await p.textContent('#content')) || '';
  const ok = (c, m) => { console.log((c ? '✅ ' : '❌ ') + m); if (!c) errors.push('FAIL: ' + m); };

  // --- المدير
  const a = await mk('admin'); await a.waitForSelector('#lu');
  await a.fill('#lu', 'admin'); await a.fill('#lp', 'wrong'); await a.click('#lbtn');
  await a.waitForSelector('.tt'); ok(/غير صحيحة/.test(await a.textContent('#toasts')), 'رفض كلمة مرور خاطئة');
  await login(a, 'admin', PW);
  ok(/12/.test(await text(a)), 'لوحة المدير تعرض 12 طالباً');
  await a.screenshot({ path: '/tmp/shot-admin-dash.png', fullPage: true });
  await a.click('text=الطلاب'); await a.waitForSelector('table');
  await a.fill('#qsearch', 'أحمد'); await a.waitForTimeout(150);
  ok(await a.evaluate(() => document.activeElement.id) === 'qsearch', 'البحث لا يفقد التركيز أثناء الكتابة');
  ok((await a.$$('tbody tr')).length === 1, 'فلترة الطلاب بالاسم');
  await a.fill('#qsearch', '');
  // إضافة طالب
  await a.click('text=＋ إضافة طالب'); await a.fill('#sf [name=name]', 'طالب جديد <b>x</b>'); await a.click('.md .mf .bp');
  await a.waitForSelector('.cred code'); const user = await a.textContent('.cred code'); const pass = await a.textContent('.cred code >> nth=1');
  ok(/^alp-\d+$/.test(user) && pass.length >= 8, 'إنشاء طالب مع حساب دخول: ' + user);
  await a.click('.md .mf .bg2'); 
  await a.fill('#qsearch','جديد'); ok((await a.textContent('#content')).includes('<b>x</b>') && !(await a.$('#content b:text-is("x")')), 'لا تنفيذ HTML في اسم الطالب (XSS)'); await a.fill('#qsearch','');
  // معلم جديد مع إسناد
  await a.click('.side >> text=المعلمون'); await a.click('text=＋ إضافة');
  await a.fill('#tf [name=name]', 'أ. تجربة'); await a.fill('#tf [name=user]', 'tester');
  await a.check('#tf input[name=subs] >> nth=0'); await a.check('#tf input[name=classes] >> nth=0'); await a.click('.md .mf .bp');
  await a.waitForSelector('.cred code'); const tpass = await a.textContent('.cred code >> nth=1'); await a.click('.md .mf .bg2');
  // دفعة + إيصال
  await a.click('.side >> text=الأقساط'); await a.click('text=＋ دفعة'); await a.fill('#pf [name=amount]', '100000'); await a.click('.md .mf .bp');
  await a.waitForSelector('.rcpt'); ok(/100,000/.test(await a.textContent('.rcpt')), 'إيصال القبض يظهر داخل الصفحة'); await a.click('.md .mf .bg2');
  // منشور مع صورة
  await a.click('.side >> text=الفعاليات'); await a.click('text=＋ منشور'); await a.fill('#postf [name=title]', 'منشور اختبار'); await a.fill('#postf [name=body]', 'نص');
  await a.setInputFiles('#postImgFile', '/home/claude/alphabet-app/public/icons/icon-192.png'); await a.waitForSelector('#postImgsPreview img');
  await a.click('.md .mf .bp'); await a.waitForSelector('.post-imgs img'); ok(true, 'نشر منشور مع صورة مضغوطة');
  await a.click('.side >> text=الحسابات'); ok(/student1/.test(await text(a)), 'صفحة الحسابات');
  await a.click('.side >> text=سجل النشاط'); ok(/إضافة طالب/.test(await text(a)), 'سجل النشاط يسجل العمليات');

  // --- المعلم الجديد: تغيير كلمة المرور الإجباري
  const t = await mk('newteacher'); await t.waitForSelector('#lu'); await login0(t, 'tester', tpass);
  async function login0(p, u, pw) { await p.fill('#lu', u); await p.fill('#lp', pw); await p.click('#lbtn'); await p.waitForSelector('#pwf'); }
  ok(!(await t.$('#shell .side:visible')), 'لا وصول للواجهة قبل تغيير كلمة المرور');
  await t.fill('#pwf [name=cur]', tpass); await t.fill('#pwf [name=nw]', 'Tester2026x'); await t.fill('#pwf [name=nw2]', 'Tester2026x'); await t.click('.md .mf .bp');
  await t.waitForSelector('#shell .side'); ok(true, 'تغيير كلمة المرور الإجباري ثم الدخول');

  // --- المعلمة سارة: الحضور
  const s = await mk('sara'); await login(s, 'sara', PW);
  await s.click('.side >> text=تسجيل الحضور'); await s.waitForSelector('.attopt');
  await s.click('text=✅ الكل حاضر'); await s.waitForTimeout(600);
  await s.locator('label.attopt:has-text("غائب")').first().click(); await s.waitForTimeout(400);
  ok(await s.locator('.attopt.on-a').count() === 1, 'تسجيل غياب طالب');
  ok(!/المالية|الأقساط/.test(await s.textContent('.side')), 'المعلم لا يرى الأقساط');
  await s.screenshot({ path: '/tmp/shot-teacher-att.png', fullPage: true });

  // --- الطالب وولي الأمر
  const st = await mk('student'); await login(st, 'student1', PW);
  ok(/أحمد خالد/.test(await text(st)), 'الطالب يرى بياناته');
  await st.click('.side >> text=الدعم الفني'); await st.click('text=＋ تذكرة جديدة');
  await st.selectOption('#tkf [name=type]', 'absence'); await st.fill('#tkf [name=subject]', 'إذن غياب'); await st.fill('#tkf [name=body]', 'مريض'); await st.click('.md .mf .bp');
  await st.waitForSelector('.chat-body'); ok(true, 'الطالب يرسل طلب إذن غياب');
  const pa = await mk('parent'); await login(pa, 'parent1', PW);
  await pa.click('.side >> text=حضور الأبناء'); ok(/مريم خالد|أحمد خالد/.test(await text(pa)), 'ولي الأمر يرى أبناءه');
  await pa.click('.side >> text=الأقساط'); ok(!/سامر/.test(await text(pa)), 'لا يرى بيانات أبناء غيره');
  // المدير يعتمد الإذن (يظهر عبر polling/تحديث)
  await a.click('.side >> text=خدمة العملاء'); await a.waitForSelector('.tk-item');
  await a.locator('.tk-item:has-text("إذن غياب")').first().click(); await a.click('text=✅ اعتماد الإذن');
  await a.waitForSelector('text=تم اعتماد طلب الإذن'); ok(true, 'اعتماد إذن الغياب');
  await a.screenshot({ path: '/tmp/shot-admin-support.png', fullPage: true });

  // --- جوال
  const m = await br.newContext({ viewport: { width: 390, height: 800 }, isMobile: true }); const mp = await m.newPage(); await mp.goto(B);
  await login(mp, 'student1', PW); await mp.screenshot({ path: '/tmp/shot-mobile.png' });
  const overflow = await mp.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
  ok(!overflow, 'لا تمرير أفقي على الجوال');
  // PWA
  const mf = await (await fetch(B + '/manifest.webmanifest')).json(); ok(mf.icons.length === 3, 'manifest صالح');
  await br.close(); srv.kill();
  console.log(errors.length ? '\nأخطاء:\n' + errors.join('\n') : '\nكل الاختبارات نجحت'); process.exit(errors.length ? 1 : 0);
})().catch(e => { console.error(e); srv.kill(); process.exit(1); });
