#!/bin/sh
# 빌드 전에 꼭 필요한 파일이 있는지 확인합니다.
ok=1
for f in www/index.html capacitor.config.json package.json android/gradlew android/app/src/main/AndroidManifest.xml; do
  [ -f "$f" ] || { echo "없음: $f  <- 폴더를 통째로 올렸는지 확인하세요"; ok=0; }
done
[ $ok = 1 ] && echo "파일 확인 완료" || exit 1
