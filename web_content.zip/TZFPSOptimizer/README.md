# TZ FPS Optimizer

Projeto Android em Java com interface web responsiva, baseada na referência enviada, e identificação do canal **TZ FPS / toxzinfps**. A tela principal é `app/src/main/assets/index.html`, carregada pelo app em uma WebView e conectada às ações nativas do Shizuku. O avatar do canal está incluído nos assets; tocar no bloco do canal abre o YouTube.

## Abrir e compilar

1. Abra a pasta `TZFPSOptimizer` no Android Studio (JDK 17 recomendado).
2. Aguarde a sincronização do Gradle e instale o SDK Android 35 caso o Android Studio solicite.
3. Execute em um aparelho Android. Para gerar APK: **Build → Build APK(s)**.
4. Instale e abra o Shizuku; inicie o serviço seguindo as instruções exibidas pelo próprio Shizuku. Em Android 11 ou superior, normalmente é possível iniciar pela Depuração sem fio.
5. Volte ao app, toque em **CONECTAR** e autorize o acesso do TZ FPS Optimizer no Shizuku.

## O que os controles fazem

- **Desempenho / taxa de tela:** tenta ajustar a taxa máxima para o maior modo de tela informado pelo aparelho; a fabricante pode ignorar ou limitar a configuração. Não altera CPU/GPU nem garante mais FPS.
- **Toque mais rápido:** reduz as três escalas de animação do Android para 0,5 e restaura os valores anteriores ao desligar. Não muda a sensibilidade do Free Fire nem a taxa física de amostragem do toque.
- **RAM boost & limpeza:** executa `am kill-all`, pedindo ao Android para encerrar processos em segundo plano. O Android continua gerenciando a memória e pode reabrir apps.
- **Economia de bateria:** tenta ativar/desativar o modo de economia de energia via shell; depende da versão e do fabricante. Não resfria o aparelho.
- **Carregamento rápido:** informativo. Não há comando Android universal para aumentar a potência de carga.
- **Otimizar internet:** abre as configurações de rede; não promete reduzir ping.

Os três primeiros controles que aplicam configurações do sistema e o modo de bateria precisam do Shizuku ativo e da autorização concedida. O código trata configurações não suportadas com uma mensagem, sem afirmar que foram aplicadas.
