package com.toxzinfps.optimizer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Locale;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 4107;
    private static final String CHANNEL = "https://youtube.com/@toxzin_fps?si=cqiGpGb1rGM0Sh5w";
    private WebView webView;
    private SharedPreferences prefs;

    private final Shizuku.OnRequestPermissionResultListener permissionResultListener =
            (requestCode, grantResult) -> runOnUiThread(() -> {
                if (requestCode == REQUEST_CODE) {
                    String message = grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED
                            ? "Shizuku autorizado. Agora você já pode usar as opções compatíveis."
                            : "A permissão do Shizuku não foi concedida.";
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                    updateStatus();
                }
            });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tzfps_settings", MODE_PRIVATE);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 20, 19));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 20, 19));

        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 20, 19));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(false);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setAllowFileAccessFromFileURLs(false);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return false;
                openExternal(uri.toString());
                return true;
            }
            @SuppressWarnings("deprecation")
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("file:")) return false;
                openExternal(url);
                return true;
            }
        });
        webView.addJavascriptInterface(new AppBridge(), "TZFps");
        setContentView(webView);
        Shizuku.addRequestPermissionResultListener(permissionResultListener);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onResume() {
        super.onResume();
        updateStatus();
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionResultListener);
        if (webView != null) {
            webView.removeJavascriptInterface("TZFps");
            webView.destroy();
        }
        super.onDestroy();
    }

    private final class AppBridge {
        @JavascriptInterface public String getState() {
            JSONObject state = new JSONObject();
            try {
                state.put("peak", prefs.getBoolean("enabled_peak", false));
                state.put("animations", prefs.getBoolean("enabled_animations", false));
                state.put("battery", prefs.getBoolean("enabled_battery", false));
                state.put("status", statusText());
                return state.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface public void connectShizuku() {
            runOnUiThread(() -> connectShizukuMain());
        }

        @JavascriptInterface public void toggleFeature(String key, boolean enabled) {
            runOnUiThread(() -> {
                if (!isAuthorized()) {
                    callJsResult(key, false, "Ative o Shizuku e conceda a permissão para usar esse ajuste.");
                    connectShizukuMain();
                    return;
                }
                if (!(key.equals("peak") || key.equals("animations") || key.equals("battery"))) {
                    callJsResult(key, false, "Opção desconhecida.");
                    return;
                }
                new Thread(() -> applyToggle(key, enabled)).start();
            });
        }

        @JavascriptInterface public void cleanRam() {
            runOnUiThread(() -> {
                if (!isAuthorized()) {
                    showInfo("Shizuku necessário", "Inicie o Shizuku e autorize o TZ FPS Optimizer para executar esta ação.");
                    connectShizukuMain();
                    return;
                }
                new Thread(() -> {
                    try {
                        runShell("am kill-all");
                        runOnUiThread(() -> showInfo("Pedido enviado", "O Android recebeu o pedido para encerrar processos em segundo plano. O próprio sistema continua gerenciando a memória."));
                    } catch (Exception e) { runOnUiThread(() -> showInfo("Limpeza não concluída", safeMessage(e))); }
                }).start();
            });
        }

        @JavascriptInterface public void openNetwork() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); }
                catch (Exception e) { showInfo("Rede", "Abra as configurações de Wi-Fi e rede do aparelho."); }
            });
        }

        @JavascriptInterface public void openChannel() {
            runOnUiThread(() -> openExternal(CHANNEL));
        }

        @JavascriptInterface public void showInfo(String title, String message) {
            runOnUiThread(() -> MainActivity.this.showInfo(title, message));
        }
    }

    private void applyToggle(String key, boolean enabled) {
        try {
            if (key.equals("peak")) setPeakRefresh(enabled);
            else if (key.equals("animations")) setAnimations(enabled);
            else if (key.equals("battery")) {
                String result = runShell("cmd power set-mode " + (enabled ? "1" : "0"));
                String lower = result.toLowerCase(Locale.ROOT);
                if (lower.contains("unknown") || lower.contains("error") || lower.contains("exception"))
                    throw new RuntimeException("O modo não é compatível com este aparelho.");
            }
            prefs.edit().putBoolean("enabled_" + key, enabled).apply();
            callJsResult(key, true, enabled ? "Ajuste aplicado, se suportado pelo aparelho." : "Ajuste desativado/restaurado.");
        } catch (Exception e) {
            prefs.edit().putBoolean("enabled_" + key, false).apply();
            callJsResult(key, false, "Não foi possível aplicar: " + safeMessage(e));
        }
    }

    private void setPeakRefresh(boolean enabled) throws Exception {
        String setting = "peak_refresh_rate";
        if (enabled) {
            if (!prefs.contains("old_peak")) prefs.edit().putString("old_peak", runShell("settings get system " + setting).trim()).apply();
            float max = 60f;
            for (android.view.Display.Mode mode : getWindowManager().getDefaultDisplay().getSupportedModes()) max = Math.max(max, mode.getRefreshRate());
            runShell("settings put system " + setting + " " + String.format(Locale.US, "%.2f", max));
        } else if (prefs.contains("old_peak")) {
            restoreSetting("system", setting, "old_peak");
        }
    }

    private void setAnimations(boolean enabled) throws Exception {
        String[] keys = {"window_animation_scale", "transition_animation_scale", "animator_duration_scale"};
        for (String key : keys) {
            String prefKey = "old_anim_" + key;
            if (enabled) {
                if (!prefs.contains(prefKey)) prefs.edit().putString(prefKey, runShell("settings get global " + key).trim()).apply();
                runShell("settings put global " + key + " 0.5");
            } else if (prefs.contains(prefKey)) restoreSetting("global", key, prefKey);
        }
    }

    private void restoreSetting(String namespace, String setting, String prefKey) throws Exception {
        String old = prefs.getString(prefKey, "null");
        if (old == null || old.equals("null") || old.isEmpty()) runShell("settings delete " + namespace + " " + setting);
        else runShell("settings put " + namespace + " " + setting + " '" + old.replace("'", "") + "'");
        prefs.edit().remove(prefKey).apply();
    }

    private String runShell(String command) throws Exception {
        Process process = Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line; while ((line = reader.readLine()) != null) output.append(line).append('\n');
        }
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
            String line; while ((line = reader.readLine()) != null) output.append(line).append('\n');
        }
        int code = process.waitFor();
        if (code != 0) throw new RuntimeException(output.length() == 0 ? "Comando não aceito pelo sistema." : output.toString().trim());
        return output.toString();
    }

    private boolean isAuthorized() {
        return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    private void connectShizukuMain() {
        if (!Shizuku.pingBinder()) {
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) startActivity(launch);
                else showInfo("Instale o Shizuku", "Instale o Shizuku pela fonte oficial, inicie o serviço e volte ao TZ FPS Optimizer.");
            } catch (Exception e) { showInfo("Shizuku", "Abra o Shizuku, inicie o serviço e volte para este app."); }
            updateStatus();
            return;
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Shizuku já está autorizado.", Toast.LENGTH_SHORT).show();
        } else {
            Shizuku.requestPermission(REQUEST_CODE);
        }
        updateStatus();
    }

    private String statusText() {
        boolean alive = Shizuku.pingBinder();
        boolean granted = alive && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
        return granted ? "Shizuku: conectado e autorizado" : (alive ? "Shizuku: aguardando autorização" : "Shizuku: não iniciado");
    }

    private void updateStatus() {
        if (webView != null) {
            String status = JSONObject.quote(statusText());
            webView.post(() -> webView.evaluateJavascript("setStatus(" + status + ");applyState(" + JSONObject.quote(new AppBridge().getState()) + ")", null));
        }
    }

    private void callJsResult(String key, boolean success, String message) {
        String js = "onNativeResult(" + JSONObject.quote(key) + "," + success + "," + JSONObject.quote(message) + ");setStatus(" + JSONObject.quote(statusText()) + ")";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
            if (success) Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        });
    }

    private void openExternal(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { showInfo("Não foi possível abrir", "Verifique se há um navegador ou o YouTube instalado."); }
    }

    private void showInfo(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? "Este ajuste pode não ser suportado neste modelo." : message;
    }
}
