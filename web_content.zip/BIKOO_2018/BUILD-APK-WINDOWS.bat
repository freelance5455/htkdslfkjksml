@echo off
cd /d %~dp0
npm install
npm run build
if not exist android npx cap add android
npx cap sync android
npx cap open android
pause
