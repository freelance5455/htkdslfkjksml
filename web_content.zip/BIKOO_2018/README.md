# BIKOO 2018 — Android app source project

This ZIP contains the source code and Capacitor configuration for the BIKOO 2018 notes app.

## Features in this starter release
- Create, read, edit and delete notes
- Reading mode opens by default; tap **Edit** to change a note
- Auto-save to local device storage
- 16 page background colors
- Increase/decrease reading text size with A− / A+
- Bold, italic, underline, bullet and numbered lists
- Search and categories
- Copy and system Share
- TXT export from the note menu
- Keep-awake request while the app is open (phone power button still turns screen off)
- Offline-first local storage; no account or internet required

## Build an APK (requires a Windows/Mac/Linux computer)
Install Node.js LTS and Android Studio with Android SDK. Extract this ZIP, open a terminal in this folder, then run:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

**Important:** This is the complete source project, not a compiled APK. The APK build needs Android Studio/Android SDK on a computer. Notes are stored locally on the device; export important notes for backup. Cloud sync and native DOCX/PDF export are not included in this starter version. Rich-text paste depends on the Android clipboard; long-press in the editor and choose Paste if needed.

- Full-screen mode: expands the editor for distraction-free reading and editing; use the same button to exit.
