import './style.css';
import { KeepAwake } from '@capacitor/keep-awake';
import { Share } from '@capacitor/share';
const $=id=>document.getElementById(id), KEY='bikoo2018_notes_v1';
const COLORS=[['Snow','#ffffff','#172033'],['Midnight','#172033','#f4f7ff'],['Sky Blue','#eaf3ff','#173b70'],['Mint','#e8fff4','#14533a'],['Cream','#fff8e8','#60451d'],['Lavender','#f2edff','#45336f'],['Rose','#fff0f3','#6d263b'],['Peach','#fff0e6','#713c20'],['Aqua','#e7fbff','#164b5b'],['Sage','#edf5e9','#344b2e'],['Slate','#e9eef5','#29384d'],['Sand','#f2eadc','#51412d'],['Charcoal','#252b36','#f4f6fa'],['Deep Blue','#102b55','#f3f7ff'],['Soft Pink','#fce7f3','#70264d'],['Pale Green','#effce8','#31512b']];
let notes=[];try{notes=JSON.parse(localStorage.getItem(KEY)||'[]')}catch{} let id=null,mode='read',font=19,cat='All',color=COLORS[0],timer;
const save=()=>{localStorage.setItem(KEY,JSON.stringify(notes));$('status').textContent='● Saved'};
const toast=s=>{let t=$('toast');t.textContent=s;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1900)};
const current=()=>notes.find(n=>n.id===id);const date=s=>new Date(s).toLocaleDateString();
function show(which){$('home').classList.toggle('hide',which!=='home');$('editor').classList.toggle('hide',which!=='editor')}
function render(){let q=$('search').value.toLowerCase(),arr=notes.filter(n=>(cat==='All'||n.category===cat)&&(`${n.title} ${n.body.replace(/<[^>]*>/g,' ')} ${n.category}`).toLowerCase().includes(q)).sort((a,b)=>b.updated-a);$('count').textContent=arr.length+' notes';$('cards').innerHTML=arr.map(n=>`<div class="card" data-id="${n.id}"><div class="tag">${n.category}</div><h3>${esc(n.title||'Untitled note')}</h3><p>${esc(n.body.replace(/<[^>]*>/g,' ').slice(0,125)||'No text yet')}</p><small>${date(n.updated)}　${n.favorite?'★':''}</small></div>`).join('');$('empty').classList.toggle('hide',arr.length>0);$('cards').classList.toggle('hide',!arr.length)}
function esc(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function newNote(){let n={id:crypto.randomUUID(),title:'',body:'',category:'General',color:'#ffffff',textColor:'#172033',updated:Date.now(),favorite:false};notes.push(n);save();open(n.id,'edit')}
function open(x,m='read'){id=x;let n=current();$('title').value=n.title;$('body').innerHTML=n.body;$('category').value=n.category;$('date').textContent='Updated '+date(n.updated);color=COLORS.find(c=>c[1]===n.color)||COLORS[0];applyColor();setMode(m);show('editor')}
function setMode(m){mode=m;let e=m==='edit';$('title').readOnly=!e;$('category').disabled=!e;$('body').contentEditable=e?'true':'false';$('readbar').classList.toggle('hide',e);$('editbar').classList.toggle('hide',!e)}
function queueSave(){if(mode!=='edit')return;$('status').textContent='● Saving…';clearTimeout(timer);timer=setTimeout(()=>{let n=current();if(!n)return;n.title=$('title').value;n.body=$('body').innerHTML;n.category=$('category').value;n.color=color[1];n.textColor=color[2];n.updated=Date.now();save();$('date').textContent='Updated '+date(n.updated)},300)}
function applyColor(){$('page').style.background=color[1];$('page').style.color=color[2];$('title').style.color=color[2];$('body').style.color=color[2]}
function palette(){$('palette').classList.remove('hide')}
function size(d){font=Math.max(12,Math.min(48,font+d));$('body').style.fontSize=font+'px';$('title').style.fontSize=Math.max(25,font+9)+'px'}
function plain(){return $('title').value+'\n\n'+$('body').innerText}
async function copy(){try{await navigator.clipboard.writeText(plain());toast('Copied')}catch{toast('Select text and choose Copy')}}
$('new').onclick=$('new2').onclick=newNote;$('back').onclick=()=>{queueSave();show('home');render()};$('edit').onclick=()=>setMode('edit');$('done').onclick=()=>{queueSave();setTimeout(()=>{setMode('read');toast('Saved automatically')},350)};
$('title').oninput=queueSave;$('body').oninput=queueSave;$('category').onchange=queueSave;$('search').oninput=render;
$('filters').onclick=e=>{let b=e.target.closest('[data-cat]');if(!b)return;cat=b.dataset.cat;document.querySelectorAll('#filters button').forEach(x=>x.classList.toggle('active',x===b));render()};
$('cards').onclick=e=>{let c=e.target.closest('[data-id]');if(c)open(c.dataset.id,'read')};
$('smaller').onclick=$('esmall').onclick=()=>size(-2);$('bigger').onclick=$('ebig').onclick=()=>size(2);$('copy').onclick=copy;$('share').onclick=async()=>{try{await Share.share({title:$('title').value||'BIKOO note',text:plain()})}catch{copy()}};
$('colors').onclick=$('ecolors').onclick=palette;$('closepal').onclick=()=>$('palette').classList.add('hide');
$('swatches').innerHTML=COLORS.map((c,i)=>`<button data-i="${i}" style="background:${c[1]};color:${c[2]}">Ag<small>${c[0]}</small></button>`).join('');$('swatches').onclick=e=>{let b=e.target.closest('[data-i]');if(!b)return;color=COLORS[+b.dataset.i];applyColor();let n=current();if(n){n.color=color[1];n.textColor=color[2];save()}$('palette').classList.add('hide')};
document.querySelectorAll('[data-cmd]').forEach(b=>b.onclick=()=>{$('body').focus();document.execCommand(b.dataset.cmd,false,null);queueSave()});
$('more').onclick=()=>{let choice=prompt('Enter: favorite, export, delete');let n=current();if(!n)return;if(choice==='favorite'){n.favorite=!n.favorite;save();toast('Favorite updated')}else if(choice==='export'){let a=document.createElement('a'),blob=new Blob([plain()],{type:'text/plain'});a.href=URL.createObjectURL(blob);a.download='BIKOO-note.txt';a.click();URL.revokeObjectURL(a.href)}else if(choice==='delete'&&confirm('Delete this note?')){notes=notes.filter(v=>v.id!==id);save();show('home');render()}};
$('awake').onclick=async()=>{try{await KeepAwake.keepAwake();toast('Screen stays awake while app is open')}catch{toast('Screen-awake works in the Android app')}};
try{await KeepAwake.keepAwake()}catch{}render();
