plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "br.com.brasilrp.game"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.com.brasilrp.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "0.3"
    }
}
