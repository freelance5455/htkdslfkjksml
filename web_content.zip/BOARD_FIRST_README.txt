SOUNDS LIKE IT! — Board-first automatic scrolling

After PLAY SOUNDS LIKE IT!, the digital board is displayed first with every player at START. After approximately 3 seconds the page scrolls to category selection. Player-count setup, Captain Sound auto-start, all 30 sounds and other rules are retained. Test this flow on your Android phone; previous working ZIP remains unchanged.
