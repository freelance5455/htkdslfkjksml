COMPILAR APK NA NUVEM PELO CELULAR

Este projeto inclui um workflow GitHub Actions que compila o APK sem Android Studio local.

PASSOS:
1. No Chrome do celular, entre em https://github.com e crie/acesse sua conta.
2. Crie um repositório novo (New repository), por exemplo: Precificacao3D. Pode ser Private.
3. Para enviar o projeto, será necessário extrair este ZIP e enviar os arquivos/pastas do projeto para o repositório mantendo a estrutura. Não envie apenas o ZIP.
4. Depois de enviar, abra a aba Actions do repositório.
5. Se aparecer uma confirmação para habilitar Actions, habilite.
6. Execute o workflow "Build Android APK" com Run workflow (ou faça um commit na branch main para disparar automaticamente).
7. Quando terminar com status verde, abra a execução e baixe o artifact "Precificacao3D-APK".
8. O download é um ZIP; extraia no Android e toque em app-debug.apk para instalar.
9. Se o Android bloquear, permita "Instalar apps desconhecidos" para o navegador/gerenciador de arquivos que abriu o APK.

NOTAS:
- APK debug é instalável para uso pessoal, mas não é adequado para publicação na Play Store.
- Este workflow não publica seu código nem o APK publicamente se o repositório for privado.
- Não compartilhe senhas, tokens ou chaves de assinatura.
- A compilação só começa após o projeto ser enviado ao GitHub e o workflow ser executado.
