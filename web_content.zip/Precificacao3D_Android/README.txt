PRECIFICAÇÃO 3D — PROJETO ANDROID APK

Este é o projeto-fonte Android Studio que empacota a calculadora em um aplicativo Android nativo (WebView local). A calculadora fica dentro do APK e funciona sem internet.

COMO GERAR O APK
1. Instale Android Studio no computador: https://developer.android.com/studio
2. Extraia este ZIP.
3. No Android Studio, escolha Open e selecione a pasta Precificacao3D.
4. Aguarde a sincronização do Gradle. Instale o Android SDK 35 se o Android Studio solicitar.
5. Para gerar um APK de teste: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK será criado em app/build/outputs/apk/debug/app-debug.apk.
7. Transfira o APK para o Android e abra-o para instalar. Se solicitado, autorize a instalação de apps desta origem.

PARA APK DE DISTRIBUIÇÃO
Use Build > Generate Signed Bundle / APK e crie/guarde uma chave de assinatura (keystore). Não perca essa chave, pois ela será necessária para atualizar o mesmo app futuramente.

OBSERVAÇÕES
- Aplicativo: Precificação 3D
- Pacote: br.com.precificacao3d.app
- Versão: 1.0
- Requer Android 6.0 (API 23) ou superior.
- O cálculo roda localmente; não precisa de conexão depois de instalado.
- Este ZIP contém o projeto-fonte, não um APK compilado. O ambiente de criação não dispõe do Android SDK/Gradle necessários para compilar e validar um APK instalável.
