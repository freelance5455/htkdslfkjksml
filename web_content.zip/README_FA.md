# پروژه Android Studio — آگاهی حقوقی با اکبر امیری

این پروژه، فایل HTML اصلی `agahi-hoqoqii-.html` را به‌صورت WebView داخل یک اپلیکیشن اندروید قرار می‌دهد. محتوای HTML بدون بازنویسی محاسبات و طراحی اصلی در `app/src/main/assets/index.html` قرار گرفته است.

## ساخت APK

1. Android Studio را باز کنید.
2. گزینه **Open** را بزنید و پوشه `AgahiHoqoqiAndroid` را انتخاب کنید.
3. اجازه دهید Gradle Sync انجام شود.
4. برای APK آزمایشی از منوی **Build → Build APK(s)** استفاده کنید.
5. برای نسخه نهایی از **Build → Generate Signed App Bundle / APK** استفاده کنید.

## مشخصات

- نام برنامه: آگاهی حقوقی با اکبر امیری
- Package: `com.agahihoqoqi.akbaramiri`
- Min SDK: 23
- Target/Compile SDK: 35
- Java: 17
- محتوای برنامه: HTML محلی + JavaScript + CSS
- اتصال اینترنت فقط برای مواردی مثل فونت آنلاین و لینک‌های شبکه‌های اجتماعی لازم است.

نکته: در محیط فعلی امکان دانلود Android SDK/Gradle و کامپایل واقعی APK وجود نداشت؛ بنابراین این بسته، پروژه کامل و آماده باز شدن در Android Studio و ساخت APK است، نه خود فایل APK کامپایل‌شده.
