export const TYPES = {
  book:{label:"كتاب", icon:"📖", title:"كتاب جديد"},
  magazine:{label:"مجلة", icon:"📰", title:"مجلة جديدة"},
  report:{label:"تقرير", icon:"📑", title:"تقرير جديد"},
  research:{label:"بحث", icon:"🎓", title:"بحث جديد"},
  portfolio:{label:"Portfolio", icon:"🖼️", title:"Portfolio جديد"},
  blank:{label:"فارغ", icon:"✦", title:"مستند فارغ"}
};

export const THEMES = {
  classic:{label:"كلاسيكي",accent:"#5b4636",bg:"#f7f2ea",text:"#241d18",cover:"#33271f",swatches:["#33271f","#5b4636"]},
  elegant:{label:"فاخر",accent:"#6d4aff",bg:"#ffffff",text:"#201b27",cover:"#191621",swatches:["#191621","#6d4aff"]},
  midnight:{label:"غامض",accent:"#7d67ff",bg:"#f6f5fa",text:"#25212e",cover:"#17151f",swatches:["#17151f","#7d67ff"]},
  soft:{label:"ناعم",accent:"#b46aa8",bg:"#fff9fd",text:"#352735",cover:"#76506e",swatches:["#76506e","#b46aa8"]},
  editorial:{label:"تحريري",accent:"#1e1e1e",bg:"#ffffff",text:"#1d1d1d",cover:"#eeeeea",swatches:["#111","#eee"]},
  academic:{label:"أكاديمي",accent:"#234f76",bg:"#ffffff",text:"#20242a",cover:"#243b53",swatches:["#243b53","#234f76"]},
  modern:{label:"حديث",accent:"#ff5b7f",bg:"#ffffff",text:"#222",cover:"#171717",swatches:["#171717","#ff5b7f"]}
};

export function defaultProject(type="book",theme="elegant"){
  const t=TYPES[type]||TYPES.book;
  return {
    version:1,
    name:t.title,
    type,
    theme,
    settings:{pageSize:"A4",margin:82,baseFont:17,lineHeight:2,direction:"rtl",showPageNumbers:true},
    cover:{title:type==="magazine"?"اسم المجلة":type==="report"?"عنوان التقرير":"عنوان الكتاب",subtitle:"العنوان الفرعي",author:"اسم المؤلف",backgroundImage:null},
    blocks:[
      {id:uid(),kind:"chapter",title:"الفصل الأول",text:"اكتبي نصك هنا..."},
      {id:uid(),kind:"chapter",title:"الفصل الثاني",text:"أضيفي بقية المحتوى هنا..."}
    ],
    updatedAt:Date.now()
  };
}
export function uid(){return Math.random().toString(36).slice(2,10)+Date.now().toString(36).slice(-4)}
