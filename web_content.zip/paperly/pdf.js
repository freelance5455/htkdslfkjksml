export function printToPDF(){
  const oldTitle=document.title;
  document.title=document.querySelector("#projectName")?.value||"Paperly Document";
  window.print();
  setTimeout(()=>document.title=oldTitle,1000);
}
