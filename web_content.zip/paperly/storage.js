const KEY="paperly.projects.v1";
export function loadProjects(){
  try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return[]}
}
export function saveProject(project){
  const all=loadProjects();
  const idx=all.findIndex(x=>x.id===project.id);
  if(idx>=0)all[idx]=project;else all.unshift(project);
  localStorage.setItem(KEY,JSON.stringify(all.slice(0,30)));
}
export function deleteProject(id){
  localStorage.setItem(KEY,JSON.stringify(loadProjects().filter(x=>x.id!==id)));
}
export function makeId(){return crypto.randomUUID?.()||("p_"+Date.now()+"_"+Math.random().toString(16).slice(2))}
