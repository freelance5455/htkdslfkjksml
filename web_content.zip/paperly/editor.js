import {uid} from "./templates.js";

export function blockLabel(block){
  return ({chapter:"فصل",heading:"عنوان",text:"نص",quote:"اقتباس",image:"صورة",pagebreak:"فاصل صفحة"})[block.kind]||"عنصر";
}
export function addBlock(project,kind){
  const base={
    id:uid(),kind,
    title:kind==="chapter"?"فصل جديد":kind==="heading"?"عنوان جديد":"",
    text:kind==="text"?"اكتبي النص هنا...":kind==="quote"?"اكتبي الاقتباس هنا...":"",
    caption:"",
    src:""
  };
  project.blocks.push(base); return base;
}
export function moveBlock(project,index,delta){
  const to=index+delta;if(to<0||to>=project.blocks.length)return;
  [project.blocks[index],project.blocks[to]]=[project.blocks[to],project.blocks[index]];
}
