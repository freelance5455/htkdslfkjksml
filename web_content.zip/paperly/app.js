import {TYPES,THEMES,defaultProject,uid} from "./templates.js";
import {saveProject,loadProjects,makeId} from "./storage.js";
import {addBlock,moveBlock,blockLabel} from "./editor.js";
import {printToPDF} from "./pdf.js";

let project={...defaultProject()};
project.id=makeId();
let selectedBlockId=null, zoom=1, pendingImageBlock=null, autosaveTimer=null;

const $=s=>document.querySelector(s);
const canvas=$("#documentCanvas"), inspector=$("#inspectorBody");

function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function currentTheme(){return THEMES[project.theme]||THEMES.elegant}
function touch(){project.updatedAt=Date.now();$("#saveState").textContent="جاري الحفظ…";clearTimeout(autosaveTimer);autosaveTimer=setTimeout(()=>{saveProject(project);$("#saveState").textContent="محفوظ تلقائيًا ✓"},350)}
function renderTypes(){
  $("#typeGrid").innerHTML=Object.entries(TYPES).map(([k,v])=>`<button class="choice ${project.type===k?"active":""}" data-type="${k}">${v.icon}<br>${v.label}</button>`).join("");
  $("#typeGrid").querySelectorAll("[data-type]").forEach(b=>b.onclick=()=>{project.type=b.dataset.type;project.name=TYPES[project.type].title;$("#projectName").value=project.name;$("#docTypeLabel").textContent=TYPES[project.type].label;$("#workspaceTitle").textContent=project.name;touch();render()});
}
function renderThemes(){
  $("#themeGrid").innerHTML=Object.entries(THEMES).map(([k,v])=>`<button class="theme ${project.theme===k?"active":""}" data-theme="${k}"><span class="swatches">${v.swatches.map(c=>`<i class="swatch" style="background:${c}"></i>`).join("")}</span>${v.label}</button>`).join("");
  $("#themeGrid").querySelectorAll("[data-theme]").forEach(b=>b.onclick=()=>{project.theme=b.dataset.theme;touch();render()});
}
function coverHTML(){
  const th=currentTheme();
  const bg=project.cover.backgroundImage?`background-image:url("${project.cover.backgroundImage}");background-size:cover;background-position:center;`:`background:${th.cover};`;
  return `<section class="paper-page cover-page" style="${bg};--cover-text:${th.bg};--accent:${th.accent}">
    <div class="cover-inner">
      <h1 class="cover-title">${esc(project.cover.title)}</h1>
      <div class="cover-subtitle">${esc(project.cover.subtitle)}</div>
      <div class="cover-author">${esc(project.cover.author)}</div>
    </div>
  </section>`;
}
function tocHTML(){
  const items=project.blocks.filter(b=>["chapter","heading"].includes(b.kind));
  if(!items.length)return "";
  return `<section class="paper-page content-page toc-page"><div class="page-inner"><h2>المحتويات</h2>${items.map((b,i)=>`<div class="toc-item"><span>${esc(b.title||"بدون عنوان")}</span><span>${i+3}</span></div>`).join("")}</div></section>`;
}
function blockHTML(b){
  if(b.kind==="pagebreak")return `<div class="pagebreak"></div>`;
  if(b.kind==="image")return `<div class="image-block">${b.src?`<img src="${b.src}" alt="">`:`<div style="padding:70px;text-align:center;background:#f3f0f7;border-radius:10px">أضيفي صورة من لوحة الخصائص</div>`}${b.caption?`<div class="image-caption">${esc(b.caption)}</div>`:""}</div>`;
  if(b.kind==="quote")return `<div class="quote">${esc(b.text)}</div>`;
  if(b.kind==="chapter")return `<div class="chapter"><h2>${esc(b.title)}</h2><p>${esc(b.text)}</p></div>`;
  if(b.kind==="heading")return `<div><h3>${esc(b.title)}</h3>${b.text?`<p>${esc(b.text)}</p>`:""}</div>`;
  return `<p>${esc(b.text)}</p>`;
}
function renderDocument(){
  const th=currentTheme();
  document.documentElement.style.setProperty("--accent",th.accent);
  document.documentElement.style.setProperty("--paper-bg",th.bg);
  let pages=coverHTML();
  if(["book","magazine","report","research"].includes(project.type))pages+=tocHTML();
  let chunks=[],cur="";
  for(const b of project.blocks){
    if(b.kind==="pagebreak"){if(cur)chunks.push(cur);cur="";continue}
    const html=blockHTML(b);
    cur+=html;
    if(b.kind==="chapter"&&cur.length>1900){chunks.push(cur);cur=""}
  }
  if(cur)chunks.push(cur);
  pages+=chunks.map((chunk,i)=>`<section class="paper-page content-page" style="background:${th.bg};color:${th.text}"><div class="page-inner" style="padding:${project.settings.margin}px;font-size:${project.settings.baseFont}px;line-height:${project.settings.lineHeight}">${chunk}</div></section>`).join("");
  canvas.innerHTML=pages||`<section class="paper-page"><div class="page-inner"><p>ابدئي بإضافة محتوى.</p></div></section>`;
  canvas.style.transform=`scale(${zoom})`;
}
function renderInspector(){
  const b=project.blocks.find(x=>x.id===selectedBlockId);
  if(!b){inspector.innerHTML=`
    <div class="panel-section"><h3>الغلاف</h3>
      ${field("العنوان","cover.title",project.cover.title)}
      ${field("العنوان الفرعي","cover.subtitle",project.cover.subtitle)}
      ${field("المؤلف / الجهة","cover.author",project.cover.author)}
      <button id="coverImageBtn" class="btn-full">إضافة صورة للغلاف</button>
    </div>
    <div class="panel-section"><h3>إعدادات الصفحة</h3>
      ${field("الهامش (px)","settings.margin",project.settings.margin,"number")}
      ${field("حجم الخط","settings.baseFont",project.settings.baseFont,"number")}
      ${field("تباعد الأسطر","settings.lineHeight",project.settings.lineHeight,"number")}
      <label class="field"><input id="pageNumbers" type="checkbox" ${project.settings.showPageNumbers?"checked":""}> إظهار أرقام الصفحات</label>
    </div>
    <div class="panel-section"><h3>إضافة عنصر</h3>
      ${["chapter","heading","text","quote","image","pagebreak"].map(k=>`<button class="btn-full add-block" data-kind="${k}" style="margin-bottom:6px">${blockLabel({kind:k})}</button>`).join("")}
    </div>`;bindInspector();return}
  inspector.innerHTML=`<div class="panel-section"><h3>${blockLabel(b)}</h3>
    ${b.kind!=="pagebreak"&&b.kind!=="image"?field("العنوان","title",b.title):""}
    ${["chapter","heading","text","quote"].includes(b.kind)?`<div class="field"><label>المحتوى</label><textarea id="blockText" rows="10">${esc(b.text)}</textarea></div>`:""}
    ${b.kind==="image"?`<button id="chooseImage" class="btn-full primary">اختيار صورة</button>${b.src?`<img src="${b.src}" style="width:100%;margin-top:10px;border-radius:8px">`:""}${field("تعليق الصورة","caption",b.caption)}:`"}
    <button id="deleteBlock" class="btn-full" style="margin-top:8px">حذف العنصر</button>
  </div>`;
  bindInspector();
}
function field(label,path,value,type="text"){
  const id="f_"+path.replace(".","_");
  return `<div class="field"><label>${label}<input id="${id}" type="${type}" value="${esc(value)}"></label></div>`;
}
function bindInspector(){
  $("#coverImageBtn")?.addEventListener("click",()=>{pendingImageBlock="cover";$("#imageInput").click()});
  $("#pageNumbers")?.addEventListener("change",e=>{project.settings.showPageNumbers=e.target.checked;touch();render()});
  document.querySelectorAll(".add-block").forEach(b=>b.onclick=()=>{const x=addBlock(project,b.dataset.kind);selectedBlockId=x.id;touch();render()});
  $("#chooseImage")?.addEventListener("click",()=>{pendingImageBlock=selectedBlockId;$("#imageInput").click()});
  $("#deleteBlock")?.addEventListener("click",()=>{project.blocks=project.blocks.filter(x=>x.id!==selectedBlockId);selectedBlockId=null;touch();render()});
  const bind=(id,fn)=>$("#"+id)?.addEventListener("input",fn);
  bind("f_cover_title",e=>{project.cover.title=e.target.value;touch();renderDocument()});
  bind("f_cover_subtitle",e=>{project.cover.subtitle=e.target.value;touch();renderDocument()});
  bind("f_cover_author",e=>{project.cover.author=e.target.value;touch();renderDocument()});
  bind("f_settings_margin",e=>{project.settings.margin=+e.target.value||60;touch();renderDocument()});
  bind("f_settings_baseFont",e=>{project.settings.baseFont=+e.target.value||17;touch();renderDocument()});
  bind("f_settings_lineHeight",e=>{project.settings.lineHeight=+e.target.value||2;touch();renderDocument()});
  if(selectedBlockId){
    const b=project.blocks.find(x=>x.id===selectedBlockId);
    bind("f_title",e=>{b.title=e.target.value;touch();render()});
    bind("blockText",e=>{b.text=e.target.value;touch();renderDocument()});
    bind("f_caption",e=>{b.caption=e.target.value;touch();renderDocument()});
  }
}
function renderBlocksList(){
  const area=inspector.querySelector(".panel-section:last-child");
  if(!area)return;
}
function render(){
  renderTypes();renderThemes();
  $("#projectName").value=project.name;
  $("#docTypeLabel").textContent=TYPES[project.type].label;
  $("#workspaceTitle").textContent=project.name;
  renderDocument();renderInspector();
}
$("#projectName").addEventListener("input",e=>{project.name=e.target.value;$("#workspaceTitle").textContent=project.name;touch()});
document.querySelectorAll("[data-tool]").forEach(b=>b.onclick=()=>{if(b.dataset.tool==="blocks"){inspector.innerHTML=`<div class="panel-section"><h3>ترتيب المحتوى</h3>${project.blocks.map((x,i)=>`<div class="block-card"><div class="block-row"><span class="drag">☷</span><strong>${esc(x.title||blockLabel(x))}</strong><div class="block-actions"><button class="mini-btn" data-up="${i}">↑</button><button class="mini-btn" data-down="${i}">↓</button><button class="mini-btn" data-select="${x.id}">✎</button></div></div></div>`).join("")}</div>`;inspector.querySelectorAll("[data-up]").forEach(x=>x.onclick=()=>{moveBlock(project,+x.dataset.up,-1);touch();render()});inspector.querySelectorAll("[data-down]").forEach(x=>x.onclick=()=>{moveBlock(project,+x.dataset.down,1);touch();render()});inspector.querySelectorAll("[data-select]").forEach(x=>x.onclick=()=>{selectedBlockId=x.dataset.select;renderInspector()})}});
$("#exportPdfBtn").onclick=()=>printToPDF();
$("#exportProjectBtn").onclick=()=>{const blob=new Blob([JSON.stringify(project,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=(project.name||"paperly-project")+".json";a.click();URL.revokeObjectURL(a.href)};
$("#importBtn").onclick=()=>$("#projectInput").click();
$("#projectInput").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{project=JSON.parse(r.result);project.id=project.id||makeId();selectedBlockId=null;render();touch();toast("تم استيراد المشروع")}catch{toast("ملف المشروع غير صالح")}};r.readAsText(f)};
$("#newProjectBtn").onclick=()=>{if(confirm("إنشاء مشروع جديد؟")){project={...defaultProject("book","elegant"),id:makeId()};selectedBlockId=null;render();touch()}};
$("#helpBtn").onclick=()=>$("#helpDialog").showModal();
document.querySelector("[data-close-dialog]").onclick=()=>$("#helpDialog").close();
$("#zoomIn").onclick=()=>{zoom=Math.min(1.35,zoom+.1);$("#zoomLabel").textContent=Math.round(zoom*100)+"%";renderDocument()};
$("#zoomOut").onclick=()=>{zoom=Math.max(.55,zoom-.1);$("#zoomLabel").textContent=Math.round(zoom*100)+"%";renderDocument()};
$("#imageInput").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{if(pendingImageBlock==="cover")project.cover.backgroundImage=r.result;else{const b=project.blocks.find(x=>x.id===pendingImageBlock);if(b)b.src=r.result}pendingImageBlock=null;touch();render()};r.readAsDataURL(f)};
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}
const existing=loadProjects()[0];if(existing){project=existing}else{touch()}render();
