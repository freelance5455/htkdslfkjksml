const operators=[
 {id:"gp",name:"গ্রামীণফোন",short:"GP",cls:"gp",logo:"assets/gp-logo-new.png"},
 {id:"robi",name:"রবি",short:"robi",cls:"robi",logo:"assets/robi-logo-new.png"},
 {id:"airtel",name:"এয়ারটেল",short:"airtel",cls:"airtel",logo:"assets/airtel-logo-new.png"},
 {id:"bl",name:"বাংলালিংক",short:"BL",cls:"bl",logo:"assets/bl-logo-new.png"},
 {id:"tt",name:"টেলিটক",short:"TT",cls:"tt",logo:"assets/tt-logo-new.png"},
 {id:"skitto",name:"Skitto",short:"skitto",cls:"skitto",logo:"assets/skitto-logo.svg"}
];
const categories=[
 {id:"internet",name:"ইন্টারনেট",icon:"🌐",desc:"ডাটা ও ইন্টারনেট প্যাক"},
 {id:"minute",name:"মিনিট",icon:"📞",desc:"কথা বলার মিনিট প্যাক"},
 {id:"sms",name:"SMS",icon:"💬",desc:"SMS প্যাকেজ"},
 {id:"combo",name:"কম্বো",icon:"📦",desc:"ডাটা + মিনিট + SMS"},
 {id:"special",name:"স্পেশাল",icon:"🎁",desc:"বিশেষ ও সাশ্রয়ী অফার"}
];
const seed=[
 {id:1,operator:"gp",category:"combo",title:"60 GB + 1200 Min",value:"60 GB + 1200 Min",price:"490",validity:"30 দিন",code:"",status:"active"},
 {id:2,operator:"gp",category:"combo",title:"50 GB + 1600 Min",value:"50 GB + 1600 Min",price:"429",validity:"30 দিন",code:"",status:"active"},
 {id:3,operator:"gp",category:"combo",title:"50 GB + 1000 Min",value:"50 GB + 1000 Min",price:"420 / 381",validity:"30 দিন",code:"",status:"active"},
 {id:4,operator:"gp",category:"combo",title:"50 GB + 950 Min",value:"50 GB + 950 Min",price:"410",validity:"30 দিন",code:"",status:"active"},
 {id:5,operator:"gp",category:"combo",title:"50 GB + 850 Min",value:"50 GB + 850 Min",price:"404",validity:"30 দিন",code:"",status:"active"},
 {id:6,operator:"gp",category:"combo",title:"40 GB + 800 Min",value:"40 GB + 800 Min",price:"370 / 341",validity:"30 দিন",code:"",status:"active"},
 {id:7,operator:"gp",category:"combo",title:"40 GB + 790 Min",value:"40 GB + 790 Min",price:"378",validity:"30 দিন",code:"",status:"active"},
 {id:8,operator:"gp",category:"combo",title:"40 GB + 760 Min",value:"40 GB + 760 Min",price:"372",validity:"30 দিন",code:"",status:"active"},
 {id:9,operator:"gp",category:"combo",title:"30 GB + 650 Min",value:"30 GB + 650 Min",price:"345 / 339",validity:"30 দিন",code:"",status:"active"},
 {id:10,operator:"gp",category:"combo",title:"30 GB + 500 Min",value:"30 GB + 500 Min",price:"285",validity:"30 দিন",code:"",status:"active"},
 {id:11,operator:"gp",category:"combo",title:"25 GB + 480 Min",value:"25 GB + 480 Min",price:"272 / 266",validity:"30 দিন",code:"",status:"active"},
 {id:12,operator:"gp",category:"combo",title:"25 GB + 300 Min",value:"25 GB + 300 Min",price:"249",validity:"30 দিন",code:"",status:"active"},
 {id:13,operator:"gp",category:"combo",title:"25 GB + 250 Min",value:"25 GB + 250 Min",price:"249 / 229",validity:"30 দিন",code:"",status:"active"},
 {id:14,operator:"gp",category:"combo",title:"20 GB + 299 Min",value:"20 GB + 299 Min",price:"246 / 240",validity:"30 দিন",code:"",status:"active"},
 {id:15,operator:"gp",category:"combo",title:"2 GB + 1000 Min",value:"2 GB + 1000 Min",price:"260",validity:"30 দিন",code:"",status:"active"},
 {id:16,operator:"gp",category:"internet",title:"60 GB",value:"60 GB",price:"360 / 320 / 316 / 299",validity:"30 দিন",code:"",status:"active"},
 {id:17,operator:"gp",category:"internet",title:"50 GB",value:"50 GB",price:"305 / 299",validity:"30 দিন",code:"",status:"active"},
 {id:18,operator:"gp",category:"internet",title:"45 GB",value:"45 GB",price:"339",validity:"30 দিন",code:"",status:"active"},
 {id:19,operator:"gp",category:"internet",title:"40 GB",value:"40 GB",price:"260 / 254",validity:"30 দিন",code:"",status:"active"},
 {id:20,operator:"gp",category:"internet",title:"25 GB",value:"25 GB",price:"226 / 220 / 209",validity:"30 দিন",code:"",status:"active"},
 {id:21,operator:"gp",category:"internet",title:"20 GB",value:"20 GB",price:"210 / 205 / 195",validity:"30 দিন",code:"",status:"active"},
 {id:22,operator:"gp",category:"minute",title:"1000 Min",value:"1000 Min",price:"339 / 319",validity:"30 দিন",code:"",status:"active"},
 {id:23,operator:"gp",category:"minute",title:"500 Min",value:"500 Min",price:"199",validity:"30 দিন",code:"",status:"active"},
 {id:24,operator:"robi",category:"combo",title:"60 GB + 1600 Min",value:"60 GB + 1600 Min",price:"530",validity:"30 দিন",code:"",status:"active"},
 {id:25,operator:"robi",category:"combo",title:"60 GB + 1200 Min",value:"60 GB + 1200 Min",price:"510 / 419",validity:"30 দিন",code:"",status:"active"},
 {id:26,operator:"robi",category:"combo",title:"50 GB + 1000 Min",value:"50 GB + 1000 Min",price:"429 / 420 / 419 / 399",validity:"30 দিন",code:"",status:"active"},
 {id:27,operator:"robi",category:"combo",title:"40 GB + 800 Min",value:"40 GB + 800 Min",price:"377 / 349",validity:"30 দিন",code:"",status:"active"},
 {id:28,operator:"robi",category:"combo",title:"40 GB + 790 Min",value:"40 GB + 790 Min",price:"377",validity:"30 দিন",code:"",status:"active"},
 {id:29,operator:"robi",category:"combo",title:"40 GB + 700 Min",value:"40 GB + 700 Min",price:"350",validity:"30 দিন",code:"",status:"active"},
 {id:30,operator:"robi",category:"combo",title:"40 GB + 500 Min",value:"40 GB + 500 Min",price:"344",validity:"30 দিন",code:"",status:"active"},
 {id:31,operator:"robi",category:"combo",title:"45 GB + 420 Min",value:"45 GB + 420 Min",price:"304",validity:"30 দিন",code:"",status:"active"},
 {id:32,operator:"robi",category:"combo",title:"35 GB + 520 Min",value:"35 GB + 520 Min",price:"310",validity:"30 দিন",code:"",status:"active"},
 {id:33,operator:"robi",category:"combo",title:"35 GB + 350 Min",value:"35 GB + 350 Min",price:"270",validity:"30 দিন",code:"",status:"active"},
 {id:34,operator:"robi",category:"combo",title:"30 GB + 500 Min",value:"30 GB + 500 Min",price:"285 / 225",validity:"30 দিন",code:"",status:"active"},
 {id:35,operator:"robi",category:"combo",title:"25 GB + 450 Min",value:"25 GB + 450 Min",price:"276",validity:"30 দিন",code:"",status:"active"},
 {id:36,operator:"robi",category:"combo",title:"21 GB + 300 Min",value:"21 GB + 300 Min",price:"228 / 219",validity:"30 দিন",code:"",status:"active"},
 {id:37,operator:"robi",category:"combo",title:"20 GB + 250 Min",value:"20 GB + 250 Min",price:"238",validity:"30 দিন",code:"",status:"active"},
 {id:38,operator:"robi",category:"combo",title:"1 GB + 1000 Min",value:"1 GB + 1000 Min",price:"320",validity:"30 দিন",code:"",status:"active"},
 {id:39,operator:"robi",category:"internet",title:"80 GB",value:"80 GB",price:"382",validity:"30 দিন",code:"",status:"active"},
 {id:40,operator:"robi",category:"internet",title:"60 GB",value:"60 GB",price:"360 / 334 / 322 / 209",validity:"30 দিন",code:"",status:"active"},
 {id:41,operator:"robi",category:"internet",title:"50 GB",value:"50 GB",price:"308 / 302",validity:"30 দিন",code:"",status:"active"},
 {id:42,operator:"robi",category:"internet",title:"40 GB",value:"40 GB",price:"275 / 269",validity:"30 দিন",code:"",status:"active"},
 {id:43,operator:"robi",category:"internet",title:"35 GB",value:"35 GB",price:"289 / 234",validity:"30 দিন",code:"",status:"active"},
 {id:44,operator:"robi",category:"internet",title:"30 GB",value:"30 GB",price:"240",validity:"30 দিন",code:"",status:"active"},
 {id:45,operator:"robi",category:"internet",title:"20 GB",value:"20 GB",price:"220 / 209 / 200",validity:"30 দিন",code:"",status:"active"},
 {id:46,operator:"robi",category:"minute",title:"1200 Min",value:"1200 Min",price:"410",validity:"30 দিন",code:"",status:"active"},
 {id:47,operator:"robi",category:"minute",title:"1000 Min",value:"1000 Min",price:"342",validity:"30 দিন",code:"",status:"active"},
 {id:48,operator:"robi",category:"minute",title:"600 Min",value:"600 Min",price:"249 / 231",validity:"30 দিন",code:"",status:"active"},
 {id:49,operator:"bl",category:"combo",title:"60 GB + 1600 Min",value:"60 GB + 1600 Min",price:"560 / 399",validity:"30 দিন",code:"",status:"active"},
 {id:50,operator:"bl",category:"combo",title:"60 GB + 1000 Min",value:"60 GB + 1000 Min",price:"422",validity:"30 দিন",code:"",status:"active"},
 {id:51,operator:"bl",category:"combo",title:"60 GB + 850 Min",value:"60 GB + 850 Min",price:"416",validity:"30 দিন",code:"",status:"active"},
 {id:52,operator:"bl",category:"combo",title:"50 GB + 1000 Min",value:"50 GB + 1000 Min",price:"420 / 349",validity:"30 দিন",code:"",status:"active"},
 {id:53,operator:"bl",category:"combo",title:"50 GB + 790 Min",value:"50 GB + 790 Min",price:"380",validity:"30 দিন",code:"",status:"active"},
 {id:54,operator:"bl",category:"combo",title:"50 GB + 590 Min",value:"50 GB + 590 Min",price:"374",validity:"30 দিন",code:"",status:"active"},
 {id:55,operator:"bl",category:"combo",title:"44 GB + 800 Min",value:"44 GB + 800 Min",price:"347 / 329",validity:"30 দিন",code:"",status:"active"},
 {id:56,operator:"bl",category:"combo",title:"40 GB + 660 Min",value:"40 GB + 660 Min",price:"346",validity:"30 দিন",code:"",status:"active"},
 {id:57,operator:"bl",category:"combo",title:"40 GB + 600 Min",value:"40 GB + 600 Min",price:"340",validity:"30 দিন",code:"",status:"active"},
 {id:58,operator:"bl",category:"combo",title:"30 GB + 700 Min",value:"30 GB + 700 Min",price:"299 / 281",validity:"30 দিন",code:"",status:"active"},
 {id:59,operator:"bl",category:"combo",title:"30 GB + 550 Min",value:"30 GB + 550 Min",price:"320",validity:"30 দিন",code:"",status:"active"},
 {id:60,operator:"bl",category:"combo",title:"30 GB + 500 Min",value:"30 GB + 500 Min",price:"314",validity:"30 দিন",code:"",status:"active"},
 {id:61,operator:"bl",category:"combo",title:"25 GB + 420 Min",value:"25 GB + 420 Min",price:"278 / 272",validity:"30 দিন",code:"",status:"active"},
 {id:62,operator:"bl",category:"combo",title:"1.5 GB + 1000 Min",value:"1.5 GB + 1000 Min",price:"390",validity:"30 দিন",code:"",status:"active"},
 {id:63,operator:"bl",category:"internet",title:"80 GB",value:"80 GB",price:"364 / 358",validity:"30 দিন",code:"",status:"active"},
 {id:64,operator:"bl",category:"internet",title:"60 GB",value:"60 GB",price:"388 / 340 / 329 / 323 / 211",validity:"30 দিন",code:"",status:"active"},
 {id:65,operator:"bl",category:"internet",title:"50 GB",value:"50 GB",price:"299",validity:"30 দিন",code:"",status:"active"},
 {id:66,operator:"bl",category:"internet",title:"40 GB",value:"40 GB",price:"270 / 260 / 254",validity:"30 দিন",code:"",status:"active"},
 {id:67,operator:"bl",category:"internet",title:"30 GB",value:"30 GB",price:"236 / 230",validity:"30 দিন",code:"",status:"active"},
 {id:68,operator:"bl",category:"internet",title:"20 GB",value:"20 GB",price:"199",validity:"30 দিন",code:"",status:"active"},
 {id:69,operator:"bl",category:"minute",title:"1000 Min",value:"1000 Min",price:"334 / 309",validity:"30 দিন",code:"",status:"active"},
 {id:70,operator:"bl",category:"minute",title:"700 Min",value:"700 Min",price:"299",validity:"30 দিন",code:"",status:"active"},
 {id:71,operator:"bl",category:"minute",title:"500 Min",value:"500 Min",price:"199",validity:"30 দিন",code:"",status:"active"},
 {id:72,operator:"airtel",category:"combo",title:"60 GB + 1600 Min",value:"60 GB + 1600 Min",price:"540 / 411",validity:"30 দিন",code:"",status:"active"},
 {id:73,operator:"airtel",category:"combo",title:"60 GB + 700 Min",value:"60 GB + 700 Min",price:"420 / 414",validity:"30 দিন",code:"",status:"active"},
 {id:74,operator:"airtel",category:"combo",title:"50 GB + 1000 Min",value:"50 GB + 1000 Min",price:"459 / 420 / 379",validity:"30 দিন",code:"",status:"active"},
 {id:75,operator:"airtel",category:"combo",title:"50 GB + 920 Min",value:"50 GB + 920 Min",price:"388",validity:"30 দিন",code:"",status:"active"},
 {id:76,operator:"airtel",category:"combo",title:"50 GB + 620 Min",value:"50 GB + 620 Min",price:"382",validity:"30 দিন",code:"",status:"active"},
 {id:77,operator:"airtel",category:"combo",title:"45 GB + 700 Min",value:"45 GB + 700 Min",price:"345",validity:"30 দিন",code:"",status:"active"},
 {id:78,operator:"airtel",category:"combo",title:"45 GB + 500 Min",value:"45 GB + 500 Min",price:"339",validity:"30 দিন",code:"",status:"active"},
 {id:79,operator:"airtel",category:"combo",title:"40 GB + 800 Min",value:"40 GB + 800 Min",price:"349 / 344",validity:"30 দিন",code:"",status:"active"},
 {id:80,operator:"airtel",category:"combo",title:"30 GB + 500 Min",value:"30 GB + 500 Min",price:"289",validity:"30 দিন",code:"",status:"active"},
 {id:81,operator:"airtel",category:"combo",title:"30 GB + 450 Min",value:"30 GB + 450 Min",price:"220",validity:"30 দিন",code:"",status:"active"},
 {id:82,operator:"airtel",category:"combo",title:"30 GB + 350 Min",value:"30 GB + 350 Min",price:"214",validity:"30 দিন",code:"",status:"active"},
 {id:83,operator:"airtel",category:"combo",title:"20 GB + 500 Min",value:"20 GB + 500 Min",price:"225",validity:"30 দিন",code:"",status:"active"},
 {id:84,operator:"airtel",category:"combo",title:"20 GB + 350 Min",value:"20 GB + 350 Min",price:"220",validity:"30 দিন",code:"",status:"active"},
 {id:85,operator:"airtel",category:"combo",title:"20 GB + 300 Min",value:"20 GB + 300 Min",price:"239",validity:"30 দিন",code:"",status:"active"},
 {id:86,operator:"airtel",category:"internet",title:"100 GB",value:"100 GB",price:"399",validity:"30 দিন",code:"",status:"active"},
 {id:87,operator:"airtel",category:"internet",title:"80 GB",value:"80 GB",price:"393 / 359",validity:"30 দিন",code:"",status:"active"},
 {id:88,operator:"airtel",category:"internet",title:"60 GB",value:"60 GB",price:"360 / 342",validity:"30 দিন",code:"",status:"active"},
 {id:89,operator:"airtel",category:"internet",title:"55 GB",value:"55 GB",price:"360",validity:"30 দিন",code:"",status:"active"},
 {id:90,operator:"airtel",category:"internet",title:"50 GB",value:"50 GB",price:"310 / 304",validity:"30 দিন",code:"",status:"active"},
 {id:91,operator:"airtel",category:"internet",title:"40 GB",value:"40 GB",price:"270 / 268 / 262",validity:"30 দিন",code:"",status:"active"},
 {id:92,operator:"airtel",category:"internet",title:"35 GB",value:"35 GB",price:"246 / 240",validity:"30 দিন",code:"",status:"active"},
 {id:93,operator:"airtel",category:"internet",title:"30 GB",value:"30 GB",price:"210",validity:"30 দিন",code:"",status:"active"},
 {id:94,operator:"airtel",category:"internet",title:"25 GB",value:"25 GB",price:"225",validity:"30 দিন",code:"",status:"active"},
 {id:95,operator:"airtel",category:"internet",title:"20 GB",value:"20 GB",price:"219 / 210 / 195 / 183",validity:"30 দিন",code:"",status:"active"},
 {id:96,operator:"airtel",category:"minute",title:"1000 Min",value:"1000 Min",price:"334 / 305",validity:"30 দিন",code:"",status:"active"},
 {id:97,operator:"airtel",category:"minute",title:"900 Min",value:"900 Min",price:"310",validity:"30 দিন",code:"",status:"active"},
 {id:98,operator:"airtel",category:"minute",title:"690 Min",value:"690 Min",price:"249",validity:"30 দিন",code:"",status:"active"},
 {id:99,operator:"airtel",category:"minute",title:"590 Min",value:"590 Min",price:"220",validity:"30 দিন",code:"",status:"active"},
 {id:100,operator:"tt",category:"combo",title:"60 GB + 1400 Min",value:"60 GB + 1400 Min",price:"411",validity:"30 দিন",code:"",status:"active"},
 {id:101,operator:"tt",category:"combo",title:"50 GB + 1600 Min",value:"50 GB + 1600 Min",price:"419",validity:"30 দিন",code:"",status:"active"},
 {id:102,operator:"tt",category:"combo",title:"50 GB + 1000 Min",value:"50 GB + 1000 Min",price:"391",validity:"30 দিন",code:"",status:"active"},
 {id:103,operator:"tt",category:"combo",title:"40 GB + 800 Min",value:"40 GB + 800 Min",price:"349",validity:"30 দিন",code:"",status:"active"},
 {id:104,operator:"tt",category:"combo",title:"30 GB + 500 Min",value:"30 GB + 500 Min",price:"225",validity:"30 দিন",code:"",status:"active"},
 {id:105,operator:"tt",category:"internet",title:"50 GB",value:"50 GB",price:"299",validity:"30 দিন",code:"",status:"active"},
 {id:106,operator:"tt",category:"internet",title:"30 GB",value:"30 GB",price:"211",validity:"30 দিন",code:"",status:"active"},
 {id:107,operator:"tt",category:"internet",title:"20 GB",value:"20 GB",price:"199",validity:"30 দিন",code:"",status:"active"},
 {id:108,operator:"tt",category:"minute",title:"1600 Min",value:"1600 Min",price:"378",validity:"30 দিন",code:"",status:"active"},
 {id:109,operator:"tt",category:"minute",title:"900 Min",value:"900 Min",price:"299",validity:"30 দিন",code:"",status:"active"},
 {id:110,operator:"tt",category:"minute",title:"600 Min",value:"600 Min",price:"213",validity:"30 দিন",code:"",status:"active"},
 {id:111,operator:"skitto",category:"combo",title:"60 GB + 1600 Min",value:"60 GB + 1600 Min",price:"549",validity:"30 দিন",code:"",status:"active"},
 {id:112,operator:"skitto",category:"combo",title:"50 GB + 1000 Min",value:"50 GB + 1000 Min",price:"405",validity:"30 দিন",code:"",status:"active"},
 {id:113,operator:"skitto",category:"combo",title:"40 GB + 800 Min",value:"40 GB + 800 Min",price:"351",validity:"30 দিন",code:"",status:"active"},
 {id:114,operator:"skitto",category:"combo",title:"30 GB + 500 Min",value:"30 GB + 500 Min",price:"295",validity:"30 দিন",code:"",status:"active"},
 {id:115,operator:"skitto",category:"combo",title:"25 GB + 250 Min",value:"25 GB + 250 Min",price:"245",validity:"30 দিন",code:"",status:"active"},
 {id:116,operator:"skitto",category:"internet",title:"60 GB",value:"60 GB",price:"311",validity:"30 দিন",code:"",status:"active"},
 {id:117,operator:"skitto",category:"internet",title:"35 GB",value:"35 GB",price:"239",validity:"30 দিন",code:"",status:"active"},
 {id:118,operator:"skitto",category:"minute",title:"1600 Min",value:"1600 Min",price:"399",validity:"30 দিন",code:"",status:"active"},
 {id:119,operator:"skitto",category:"minute",title:"800 Min",value:"800 Min",price:"299",validity:"30 দিন",code:"",status:"active"},
 {id:120,operator:"skitto",category:"minute",title:"500 Min",value:"500 Min",price:"221",validity:"30 দিন",code:"",status:"active"}
];


const regularPacks=[
 {id:'rgp1',operator:'gp',title:'রেগুলার রিচার্জ ৳৯৮',value:'প্রায় ১ GB ডাটা',price:100,validity:'৩ দিন',note:'নির্দিষ্ট রিচার্জে ডাটা সুবিধা'},
 {id:'rgp2',operator:'gp',title:'রেগুলার রিচার্জ ৳১৪৮',value:'প্রায় ২ GB ডাটা',price:148,validity:'৭ দিন',note:'নির্দিষ্ট রিচার্জে ডাটা সুবিধা'},
 {id:'rgp3',operator:'gp',title:'রেগুলার রিচার্জ ৳২৫৯',value:'৩০০ মিনিট + ১০০ MB',price:259,validity:'৩০ দিন',note:'মিনিট প্যাক'},
 {id:'rrobi1',operator:'robi',title:'রেগুলার রিচার্জ ৳৯৮',value:'ডাটা সুবিধা',price:100,validity:'৭ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rrobi2',operator:'robi',title:'রেগুলার রিচার্জ ৳১৯৯',value:'ডাটা + মিনিট সুবিধা',price:199,validity:'৩০ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rrobi3',operator:'robi',title:'রেগুলার রিচার্জ ৳২৯৯',value:'বেশি ডাটা + মিনিট',price:299,validity:'৩০ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rair1',operator:'airtel',title:'রেগুলার রিচার্জ ৳৯৮',value:'ডাটা সুবিধা',price:100,validity:'৭ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rair2',operator:'airtel',title:'রেগুলার রিচার্জ ৳১৯৯',value:'ডাটা + মিনিট সুবিধা',price:199,validity:'৩০ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rair3',operator:'airtel',title:'রেগুলার রিচার্জ ৳২৯৯',value:'বেশি ডাটা + মিনিট',price:299,validity:'৩০ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rbl1',operator:'bl',title:'রেগুলার রিচার্জ ৳৯৯',value:'ডাটা সুবিধা',price:100,validity:'৭ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rbl2',operator:'bl',title:'রেগুলার রিচার্জ ৳১৯৯',value:'ডাটা + মিনিট সুবিধা',price:199,validity:'৩০ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rbl3',operator:'bl',title:'রেগুলার রিচার্জ ৳৩১৯',value:'৪৫০ মিনিট',price:319,validity:'৩০ দিন',note:'মিনিট প্যাক'},
 {id:'rtt1',operator:'tt',title:'রেগুলার রিচার্জ ৳৩৯',value:'১ GB + ২৫ মিনিট + ১০ SMS',price:100,validity:'৭ দিন',note:'রেগুলার কম্বো'},
 {id:'rtt2',operator:'tt',title:'রেগুলার রিচার্জ ৳১০৬',value:'১.২ GB + ১৫০ মিনিট + ১২০ SMS',price:106,validity:'৩০ দিন',note:'রেগুলার কম্বো'},
 {id:'rtt3',operator:'tt',title:'রেগুলার রিচার্জ ৳২০৮',value:'৫ GB + ২৫০ মিনিট + ৩০০ SMS',price:208,validity:'৩০ দিন',note:'রেগুলার কম্বো'},
 {id:'rsk1',operator:'skitto',title:'রেগুলার রিচার্জ ৳৯৯',value:'ডাটা সুবিধা',price:100,validity:'৭ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rsk2',operator:'skitto',title:'রেগুলার রিচার্জ ৳১৯৯',value:'ডাটা + মিনিট সুবিধা',price:199,validity:'৩০ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'},
 {id:'rsk3',operator:'skitto',title:'রেগুলার রিচার্জ ৳২৯৯',value:'বেশি ডাটা + মিনিট',price:299,validity:'৩০ দিন',note:'নির্দিষ্ট রিচার্জে প্রযোজ্য'}
];

function getUser(){return JSON.parse(localStorage.getItem('it_user')||'null')}
function isVerified(){const u=getUser();return !!u}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function hashText(v){if(globalThis.crypto?.subtle){const data=new TextEncoder().encode(v);const buf=await crypto.subtle.digest('SHA-256',data);return [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,'0')).join('')}return btoa(unescape(encodeURIComponent(v)))}
const BD_LOCATIONS={"ঢাকা বিভাগ":{"ঢাকা জেলা":["ধামরাই","দোহার","কেরানীগঞ্জ","নবাবগঞ্জ","সাভার"],"ফরিদপুর জেলা":["আলফাডাঙ্গা","ভাঙ্গা","বোয়ালমারী","চরভদ্রাসন","ফরিদপুর সদর","মধুখালী","নগরকান্দা","সদরপুর","সালথা"],"গাজীপুর জেলা":["গাজীপুর সদর","কালিয়াকৈর","কালীগঞ্জ","কাপাসিয়া","শ্রীপুর"],"গোপালগঞ্জ জেলা":["গোপালগঞ্জ সদর","কাশিয়ানী","কোটালীপাড়া","মুকসুদপুর","টুঙ্গিপাড়া"],"কিশোরগঞ্জ জেলা":["অষ্টগ্রাম","বাজিতপুর","ভৈরব","হোসেনপুর","ইটনা","করিমগঞ্জ","কটিয়াদী","কিশোরগঞ্জ সদর","কুলিয়ারচর","মিঠামইন","নিকলী","পাকুন্দিয়া","তাড়াইল"],"মাদারীপুর জেলা":["কালকিনি","মাদারীপুর সদর","রাজৈর","শিবচর"],"মানিকগঞ্জ জেলা":["দৌলতপুর","ঘিওর","হরিরামপুর","মানিকগঞ্জ সদর","সাটুরিয়া","শিবালয়","সিংগাইর"],"মুন্সিগঞ্জ জেলা":["গজারিয়া","লৌহজং","মুন্সিগঞ্জ সদর","সিরাজদিখান","শ্রীনগর","টংগীবাড়ী"],"নারায়ণগঞ্জ জেলা":["আড়াইহাজার","বন্দর","নারায়ণগঞ্জ সদর","রূপগঞ্জ","সোনারগাঁও"],"নরসিংদী জেলা":["বেলাব","মনোহরদী","নরসিংদী সদর","পলাশ","রায়পুরা","শিবপুর"],"রাজবাড়ী জেলা":["বালিয়াকান্দি","গোয়ালন্দ","কালুখালী","পাংশা","রাজবাড়ী সদর"],"শরীয়তপুর জেলা":["ভেদরগঞ্জ","ডামুড্যা","গোসাইরহাট","জাজিরা","নড়িয়া","শরীয়তপুর সদর"],"টাঙ্গাইল জেলা":["বাসাইল","ভূঞাপুর","দেলদুয়ার","ধনবাড়ী","ঘাটাইল","গোপালপুর","কালিহাতী","মধুপুর","মির্জাপুর","নাগরপুর","সখীপুর","টাঙ্গাইল সদর"]},"চট্টগ্রাম বিভাগ":{"বান্দরবান জেলা":["আলীকদম","বান্দরবান সদর","লামা","নাইক্ষ্যংছড়ি","রোয়াংছড়ি","রুমা","থানচি"],"ব্রাহ্মণবাড়িয়া জেলা":["আখাউড়া","আশুগঞ্জ","বাঞ্ছারামপুর","ব্রাহ্মণবাড়িয়া সদর","কসবা","নবীনগর","নাসিরনগর","সরাইল","বিজয়নগর"],"চাঁদপুর জেলা":["চাঁদপুর সদর","ফরিদগঞ্জ","হাইমচর","হাজীগঞ্জ","কচুয়া","মতলব দক্ষিণ","মতলব উত্তর","শাহরাস্তি"],"চট্টগ্রাম জেলা":["আনোয়ারা","বাঁশখালী","বোয়ালখালী","চন্দনাইশ","ফটিকছড়ি","হাটহাজারী","কর্ণফুলী","লোহাগাড়া","মীরসরাই","পটিয়া","রাঙ্গুনিয়া","রাউজান","সন্দ্বীপ","সাতকানিয়া","সীতাকুণ্ড"],"কুমিল্লা জেলা":["বরুড়া","ব্রাহ্মণপাড়া","বুড়িচং","চান্দিনা","চৌদ্দগ্রাম","কুমিল্লা আদর্শ সদর","কুমিল্লা সদর দক্ষিণ","দাউদকান্দি","দেবিদ্বার","হোমনা","লাকসাম","লালমাই","মুরাদনগর","নাঙ্গলকোট","মনোহরগঞ্জ","মেঘনা","তিতাস"],"কক্সবাজার জেলা":["চকরিয়া","কক্সবাজার সদর","কুতুবদিয়া","মহেশখালী","পেকুয়া","রামু","টেকনাফ","উখিয়া"],"ফেনী জেলা":["ছাগলনাইয়া","দাগনভূঞা","ফেনী সদর","ফুলগাজী","পরশুরাম","সোনাগাজী"],"খাগড়াছড়ি জেলা":["দীঘিনালা","খাগড়াছড়ি সদর","লক্ষ্মীছড়ি","মহালছড়ি","মানিকছড়ি","মাটিরাঙ্গা","পানছড়ি","রামগড়"],"লক্ষ্মীপুর জেলা":["কমলনগর","লক্ষ্মীপুর সদর","রামগঞ্জ","রামগতি","রায়পুর"],"নোয়াখালী জেলা":["বেগমগঞ্জ","চাটখিল","কোম্পানীগঞ্জ","হাতিয়া","কবিরহাট","সেনবাগ","সোনাইমুড়ী","সুবর্ণচর","নোয়াখালী সদর"],"রাঙ্গামাটি জেলা":["বাঘাইছড়ি","বরকল","বেলাইছড়ি","জুরাছড়ি","কাপ্তাই","কাউখালী","লংগদু","নানিয়ারচর","রাজস্থলী","রাঙ্গামাটি সদর","বিলাইছড়ি"]},"রাজশাহী বিভাগ":{"বগুড়া জেলা":["আদমদীঘি","বগুড়া সদর","ধুনট","দুপচাঁচিয়া","গাবতলী","কাহালু","নন্দীগ্রাম","শাজাহানপুর","শেরপুর","শিবগঞ্জ","সারিয়াকান্দি","সোনাতলা"],"জয়পুরহাট জেলা":["আক্কেলপুর","জয়পুরহাট সদর","কালাই","ক্ষেতলাল","পাঁচবিবি"],"নওগাঁ জেলা":["আত্রাই","বদলগাছী","ধামইরহাট","মান্দা","মহাদেবপুর","নওগাঁ সদর","নিয়ামতপুর","পত্নীতলা","পোরশা","রাণীনগর","সাপাহার"],"নাটোর জেলা":["বাগাতিপাড়া","বড়াইগ্রাম","গুরুদাসপুর","লালপুর","নাটোর সদর","নলডাঙ্গা","সিংড়া"],"চাঁপাইনবাবগঞ্জ জেলা":["ভোলাহাট","গোমস্তাপুর","নাচোল","চাঁপাইনবাবগঞ্জ সদর","শিবগঞ্জ"],"পাবনা জেলা":["আটঘরিয়া","বেড়া","ভাঙ্গুড়া","চাটমোহর","ঈশ্বরদী","ফরিদপুর","পাবনা সদর","সাঁথিয়া","সুজানগর"],"রাজশাহী জেলা":["বাঘা","বাগমারা","চারঘাট","দুর্গাপুর","গোদাগাড়ী","মোহনপুর","পবা","পুঠিয়া","তানোর","রাজশাহী সদর"],"সিরাজগঞ্জ জেলা":["বেলকুচি","চৌহালী","কামারখন্দ","কাজীপুর","রায়গঞ্জ","শাহজাদপুর","সিরাজগঞ্জ সদর","তাড়াশ","উল্লাপাড়া"]},"খুলনা বিভাগ":{"বাগেরহাট জেলা":["বাগেরহাট সদর","চিতলমারী","ফকিরহাট","কচুয়া","মোল্লাহাট","মোংলা","মোড়েলগঞ্জ","রামপাল","শরণখোলা"],"চুয়াডাঙ্গা জেলা":["আলমডাঙ্গা","চুয়াডাঙ্গা সদর","দামুড়হুদা","জীবননগর"],"যশোর জেলা":["অভয়নগর","বাঘারপাড়া","চৌগাছা","ঝিকরগাছা","কেশবপুর","মনিরামপুর","শার্শা","যশোর সদর"],"ঝিনাইদহ জেলা":["কালীগঞ্জ","কোটচাঁদপুর","মহেশপুর","শৈলকুপা","হরিণাকুন্ডু","ঝিনাইদহ সদর"],"খুলনা জেলা":["বটিয়াঘাটা","ডুমুরিয়া","দাকোপ","দিঘলিয়া","কয়রা","পাইকগাছা","রূপসা","তেরখাদা","ফুলতলা"],"কুষ্টিয়া জেলা":["ভেড়ামারা","দৌলতপুর","কুমারখালী","কুষ্টিয়া সদর","খোকসা","মিরপুর"],"মাগুরা জেলা":["মাগুরা সদর","মহম্মদপুর","শালিখা","শ্রীপুর"],"মেহেরপুর জেলা":["গাংনী","মুজিবনগর","মেহেরপুর সদর"],"নড়াইল জেলা":["কালিয়া","লোহাগড়া","নড়াইল সদর"],"সাতক্ষীরা জেলা":["আশাশুনি","দেবহাটা","কলারোয়া","কালিগঞ্জ","সাতক্ষীরা সদর","শ্যামনগর","তালা"]},"বরিশাল বিভাগ":{"বরগুনা জেলা":["আমতলী","বামনা","বরগুনা সদর","বেতাগী","পাথরঘাটা","তালতলী"],"বরিশাল জেলা":["আগৈলঝাড়া","বাবুগঞ্জ","বাকেরগঞ্জ","বানারীপাড়া","বরিশাল সদর","গৌরনদী","হিজলা","মেহেন্দিগঞ্জ","মুলাদী","উজিরপুর"],"ভোলা জেলা":["ভোলা সদর","বোরহানউদ্দিন","চরফ্যাশন","দৌলতখান","লালমোহন","মনপুরা","তজুমদ্দিন"],"ঝালকাঠি জেলা":["ঝালকাঠি সদর","কাঁঠালিয়া","নলছিটি","রাজাপুর"],"পটুয়াখালী জেলা":["বাউফল","দশমিনা","দুমকি","কলাপাড়া","মির্জাগঞ্জ","পটুয়াখালী সদর","রাঙ্গাবালী","গলাচিপা"],"পিরোজপুর জেলা":["ভাণ্ডারিয়া","কাউখালী","মঠবাড়িয়া","নাজিরপুর","নেছারাবাদ","পিরোজপুর সদর","জিয়ানগর"]},"সিলেট বিভাগ":{"হবিগঞ্জ জেলা":["আজমিরীগঞ্জ","বাহুবল","বানিয়াচং","চুনারুঘাট","হবিগঞ্জ সদর","লাখাই","মাধবপুর","নবীগঞ্জ","শায়েস্তাগঞ্জ"],"মৌলভীবাজার জেলা":["বড়লেখা","জুড়ী","কমলগঞ্জ","কুলাউড়া","মৌলভীবাজার সদর","রাজনগর","শ্রীমঙ্গল"],"সুনামগঞ্জ জেলা":["বিশ্বম্ভরপুর","ছাতক","দিরাই","ধর্মপাশা","দোয়ারাবাজার","জামালগঞ্জ","জগন্নাথপুর","শান্তিগঞ্জ","তাহিরপুর","শাল্লা","সুনামগঞ্জ সদর","মধ্যনগর"],"সিলেট জেলা":["বালাগঞ্জ","বিয়ানীবাজার","বিশ্বনাথ","কোম্পানীগঞ্জ","ফেঞ্চুগঞ্জ","গোলাপগঞ্জ","গোয়াইনঘাট","জৈন্তাপুর","কানাইঘাট","সিলেট সদর","জকিগঞ্জ","দক্ষিণ সুরমা","ওসমানীনগর"]},"রংপুর বিভাগ":{"দিনাজপুর জেলা":["বিরামপুর","বীরগঞ্জ","বিরল","বোচাগঞ্জ","চিরিরবন্দর","ফুলবাড়ী","ঘোড়াঘাট","হাকিমপুর","কাহারোল","খানসামা","নবাবগঞ্জ","পার্বতীপুর","দিনাজপুর সদর"],"গাইবান্ধা জেলা":["ফুলছড়ি","গাইবান্ধা সদর","গোবিন্দগঞ্জ","পলাশবাড়ী","সাদুল্লাপুর","সাঘাটা","সুন্দরগঞ্জ"],"কুড়িগ্রাম জেলা":["ভুরুঙ্গামারী","চর রাজিবপুর","চিলমারী","ফুলবাড়ী","কুড়িগ্রাম সদর","নাগেশ্বরী","রাজারহাট","রৌমারী","উলিপুর"],"লালমনিরহাট জেলা":["আদিতমারী","হাতীবান্ধা","কালীগঞ্জ","লালমনিরহাট সদর","পাটগ্রাম"],"নীলফামারী জেলা":["ডোমার","ডিমলা","জলঢাকা","কিশোরগঞ্জ","নীলফামারী সদর","সৈয়দপুর"],"পঞ্চগড় জেলা":["আটোয়ারী","বোদা","দেবীগঞ্জ","পঞ্চগড় সদর","তেঁতুলিয়া"],"রংপুর জেলা":["বদরগঞ্জ","গংগাচড়া","কাউনিয়া","মিঠাপুকুর","পীরগাছা","পীরগঞ্জ","রংপুর সদর","তারাগঞ্জ"],"ঠাকুরগাঁও জেলা":["বালিয়াডাঙ্গী","হরিপুর","পীরগঞ্জ","রাণীশংকৈল","ঠাকুরগাঁও সদর"]},"ময়মনসিংহ বিভাগ":{"জামালপুর জেলা":["বকশীগঞ্জ","দেওয়ানগঞ্জ","ইসলামপুর","জামালপুর সদর","মাদারগঞ্জ","মেলান্দহ","সরিষাবাড়ী"],"ময়মনসিংহ জেলা":["ভালুকা","ধোবাউড়া","ফুলবাড়ীয়া","গফরগাঁও","গৌরীপুর","হালুয়াঘাট","ঈশ্বরগঞ্জ","মুক্তাগাছা","ময়মনসিংহ সদর","নান্দাইল","ফুলপুর","তারাকান্দা","ত্রিশাল"],"নেত্রকোণা জেলা":["আটপাড়া","বারহাট্টা","দুর্গাপুর","খালিয়াজুড়ি","কলমাকান্দা","কেন্দুয়া","মদন","মোহনগঞ্জ","নেত্রকোণা সদর","পূর্বধলা"],"শেরপুর জেলা":["ঝিনাইগাতী","নকলা","নালিতাবাড়ী","শেরপুর সদর","শ্রীবরদী"]}};
function fillRegDistricts(){
 const d=document.getElementById('regDivision'), x=document.getElementById('regDistrict'), u=document.getElementById('regUpazila');
 if(!d||!x||!u)return;
 x.innerHTML='<option value="">জেলা নির্বাচন করুন</option>';
 u.innerHTML='<option value="">থানা/উপজেলা নির্বাচন করুন</option>';
 Object.keys(BD_LOCATIONS[d.value]||{}).forEach(v=>x.add(new Option(v,v)));
}
function fillRegUpazilas(){
 const d=document.getElementById('regDivision'), x=document.getElementById('regDistrict'), u=document.getElementById('regUpazila');
 if(!d||!x||!u)return;
 u.innerHTML='<option value="">থানা/উপজেলা নির্বাচন করুন</option>';
 (BD_LOCATIONS[d.value]?.[x.value]||[]).forEach(v=>u.add(new Option(v,v)));
}
function authScreen(mode='login',message=''){
 const pending=JSON.parse(localStorage.getItem('it_pending_user')||'null');
 if(mode==='verify'&&pending){return `<div class="auth-shell"><div class="auth-card"><img src="assets/islamic-telecom-logo.png" class="auth-logo"><h1>WhatsApp PIN যাচাই</h1><p>আপনার অ্যাকাউন্টের ভেরিফিকেশন PIN <b>01865110004</b> নম্বরের WhatsApp-এ পাঠানোর জন্য নির্ধারিত।</p><div class="auth-note">WhatsApp-এ আসা ৬ সংখ্যার PIN এখানে দিন। PIN এই পেজ খোলার সময় দেখানো হবে না।</div><input id="verifyCode" class="input" inputmode="numeric" maxlength="6" placeholder="WhatsApp থেকে ৬ সংখ্যার PIN"><button class="btn btn-primary full-btn" onclick="verifyAccount()">অ্যাকাউন্ট ভেরিফাই করুন</button><button class="auth-link" onclick="renderAuth('login')">লগইনে ফিরে যান</button></div></div>`}
 if(mode==='register') return `<div class="auth-shell"><div class="auth-card auth-wide"><img src="assets/islamic-telecom-logo.png" class="auth-logo"><h1>নতুন কাস্টমার অ্যাকাউন্ট</h1><p>সব তথ্য পূরণ না করলে অ্যাকাউন্ট লগইন করা যাবে না।</p>${message?`<div class="auth-error">${esc(message)}</div>`:''}<div class="auth-grid"><div><label class="form-label">নাম *</label><input id="regName" class="input" placeholder="পূর্ণ নাম"></div><div><label class="form-label">Gmail / Email *</label><input id="regEmail" class="input" type="email" placeholder="example@gmail.com"></div><div><label class="form-label">মোবাইল নম্বর *</label><input id="regPhone" class="input" inputmode="numeric" maxlength="11" placeholder="01XXXXXXXXX"></div><div><label class="form-label">পাসওয়ার্ড *</label><input id="regPass" class="input" type="password" placeholder="কমপক্ষে ৬ অক্ষর"></div><div><label class="form-label">বিভাগ *</label><select id="regDivision" class="input" onchange="fillRegDistricts()" required><option value="">বিভাগ নির্বাচন করুন</option>${Object.keys(BD_LOCATIONS).map(v=>`<option value="${v}">${v}</option>`).join('')}</select></div><div><label class="form-label">জেলা *</label><select id="regDistrict" class="input" onchange="fillRegUpazilas()" required><option value="">জেলা নির্বাচন করুন</option></select></div><div><label class="form-label">থানা/উপজেলা *</label><select id="regUpazila" class="input" required><option value="">থানা/উপজেলা নির্বাচন করুন</option></select></div><div><label class="form-label">এলাকা / ইউনিয়ন / ওয়ার্ড *</label><input id="regArea" class="input" placeholder="এলাকার নাম"></div><div><label class="form-label">বাড়ি / হাউস নম্বর *</label><input id="regHouse" class="input" placeholder="বাড়ি/হাউস নম্বর"></div><div class="auth-full"><label class="form-label">ঠিকানা *</label><textarea id="regAddress" class="input" rows="3" placeholder="সম্পূর্ণ ঠিকানা"></textarea></div></div><button class="btn btn-primary full-btn" onclick="registerAccount()">অ্যাকাউন্ট খুলুন ও অ্যাপে প্রবেশ করুন</button><button class="auth-link" onclick="renderAuth('login')">আগে অ্যাকাউন্ট আছে? লগইন</button></div></div>`;
 return `<div class="auth-shell"><div class="auth-card"><img src="assets/islamic-telecom-logo.png" class="auth-logo"><h1>ইসলামিক টেলিকম</h1><p>অ্যাকাউন্ট খুললেই সরাসরি অ্যাপে প্রবেশ করতে পারবেন।</p>${message?`<div class="auth-error">${esc(message)}</div>`:''}<label class="form-label">Gmail / Email</label><input id="loginEmail" class="input" type="email" placeholder="example@gmail.com"><label class="form-label">পাসওয়ার্ড</label><input id="loginPass" class="input" type="password" placeholder="আপনার পাসওয়ার্ড"><button class="btn btn-primary full-btn" onclick="loginAccount()">লগইন</button><button class="auth-link" onclick="renderAuth('register')">নতুন অ্যাকাউন্ট খুলুন</button></div></div>`
}
function renderAuth(mode='login',message=''){document.getElementById('app').innerHTML=authScreen(mode,message);document.querySelector('.sidebar')?.classList.remove('open')}
async function registerAccount(){
 const v={name:document.getElementById('regName')?.value.trim(),email:document.getElementById('regEmail')?.value.trim().toLowerCase(),phone:document.getElementById('regPhone')?.value.trim(),password:document.getElementById('regPass')?.value,division:document.getElementById('regDivision')?.value,district:document.getElementById('regDistrict')?.value,upazila:document.getElementById('regUpazila')?.value,area:document.getElementById('regArea')?.value.trim(),house:document.getElementById('regHouse')?.value.trim(),address:document.getElementById('regAddress')?.value.trim()};
 if(!v.name||!/^\S+@\S+\.\S+$/.test(v.email)||!/^01\d{9}$/.test(v.phone)||!v.password||v.password.length<6||!v.division||!v.district||!v.upazila||!v.area||!v.house||!v.address){renderAuth('register','সবগুলো তথ্য সঠিকভাবে পূরণ করুন। পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');return}
 const passwordHash=await hashText(v.password);delete v.password;
 const user={...v,passwordHash,verified:true};
 localStorage.setItem('it_user',JSON.stringify(user));
 localStorage.removeItem('it_pending_user');
 localStorage.removeItem('it_pending_registration');
 localStorage.removeItem('it_verify_pin');
 toast('অ্যাকাউন্ট তৈরি হয়েছে। স্বাগতম!');
 location.hash='#home';
 render();
}
async function verifyAccount(){renderAuth('login');}
async function loginAccount(){const email=document.getElementById('loginEmail')?.value.trim().toLowerCase(),pass=document.getElementById('loginPass')?.value||'',u=getUser();if(!u){renderAuth('login','কোনো ভেরিফাই করা অ্যাকাউন্ট নেই। আগে রেজিস্ট্রেশন করুন।');return}if(u.email!==email||u.passwordHash!==(await hashText(pass))){renderAuth('login','ইমেইল বা পাসওয়ার্ড সঠিক নয়।');return}render()}
function logout(){localStorage.removeItem('it_user');location.hash='#home';render()}
function changeProfilePhoto(input){const f=input.files?.[0];if(!f)return;if(!f.type.startsWith('image/')){toast('শুধু ছবি নির্বাচন করুন');return}const r=new FileReader();r.onload=()=>{const u=getUser();u.photo=r.result;localStorage.setItem('it_user',JSON.stringify(u));render();toast('প্রোফাইল ছবি পরিবর্তন হয়েছে')};r.readAsDataURL(f)}

function getOffers(){return JSON.parse(localStorage.getItem("it_offers_v2")||"null")||seed}
function saveOffers(v){localStorage.setItem("it_offers_v2",JSON.stringify(v))}
function op(id){return operators.find(x=>x.id===id)||operators[0]}
function cat(id){return categories.find(x=>x.id===id)||categories[0]}
function money(n){return "৳ "+n}
function toast(t){const x=document.getElementById("toast");if(!x)return;x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2200)}
function setActive(){const hash=location.hash||"#home";document.querySelectorAll("[data-route]").forEach(a=>a.classList.toggle("active",a.getAttribute("href")===hash))}
function fav(id){let f=JSON.parse(localStorage.getItem("it_fav")||"[]");f.includes(id)?f=f.filter(x=>x!==id):f.push(id);localStorage.setItem("it_fav",JSON.stringify(f));toast(f.includes(id)?"অফারটি পছন্দে যোগ হয়েছে":"পছন্দ থেকে সরানো হয়েছে")}
function getBalance(){return Number(localStorage.getItem("it_main_balance")||0)}
function setBalance(v){localStorage.setItem("it_main_balance",String(Math.max(0,Number(v)||0)))}

function offerCard(o){
 const x=op(o.operator);
 return `<article class="offer-card premium-offer">
  <div class="offer-top"><div class="mini-op"><img src="${x.logo}" alt=""> ${x.name}</div><span class="pill">${cat(o.category).name}</span></div>
  <h3>${o.title}</h3>
  <div class="offer-value">${o.value}</div>
  <div class="offer-meta"><div class="meta"><small>মূল্য</small><b class="price-small">${money(o.price)}</b></div><div class="meta"><small>মেয়াদ</small><b>${o.validity}</b></div></div>
  <div class="offer-actions"><button class="btn btn-primary" onclick="showOfferDetails(${o.id})">ডিটেইলস</button><button class="btn btn-light" onclick="fav(${o.id})">☆ পছন্দ</button></div>
 </article>`
}
function showOfferDetails(id){
 const o=getOffers().find(x=>x.id===id);if(!o)return;const x=op(o.operator);
 const m=document.createElement("div");m.className="modal-backdrop";m.id="offerDetailsModal";
 m.innerHTML=`<div class="modal offer-detail-modal">
 <button class="modal-close" onclick="this.closest('.modal-backdrop').remove()">×</button>
 <img class="modal-op-logo" src="${x.logo}" alt="">
 <div class="detail-operator">${x.name}</div><h2>${o.title}</h2>
 <div class="detail-box"><div><span>প্যাকেজ</span><b>${o.value}</b></div><div><span>মূল্য</span><b>${money(o.price)}</b></div><div><span>মেয়াদ</span><b>${o.validity}</b></div><div><span>ক্যাটাগরি</span><b>${cat(o.category).name}</b></div></div>
 <button class="btn btn-primary full-btn" onclick="this.closest('.modal-backdrop').remove();buyOffer(${o.id})">প্যাকেজ কিনুন</button>
 </div>`;
 document.body.appendChild(m)
}
function buyOffer(id){
 const o=getOffers().find(x=>x.id===id);if(!o)return;
 const prices=String(o.price).split("/").map(x=>Number(x.trim())).filter(Boolean);
 const price=prices.length===1?prices[0]:null;
 const priceText=prices.length>1?prices.map(p=>"৳ "+p).join(" / "):money(o.price);
 const m=document.createElement("div");m.className="modal-backdrop";m.id="buyModal";
 m.innerHTML=`<div class="modal">
 <button class="modal-close" onclick="this.closest('.modal-backdrop').remove()">×</button>
 <img class="modal-op-logo" src="${op(o.operator).logo}" alt="">
 <h2>প্যাকেজ কিনুন</h2><p><b>${o.title}</b></p>
 <div class="detail-box compact"><div><span>মূল্য</span><b>${priceText}</b></div><div><span>মেয়াদ</span><b>${o.validity}</b></div></div>
 <div class="balance-buy-box"><span>আপনার মূল ব্যালেন্স</span><strong>৳ ${getBalance().toFixed(2)}</strong></div>
 ${price?`<small class="modal-help">প্যাকেজ কিনলে ৳ ${price} মূল ব্যালেন্স থেকে কেটে নেওয়া হবে।`:`<small class="modal-help">একাধিক মূল্য থাকায় আপনার পছন্দের মূল্য নির্বাচন করুন।`}
 ${prices.length>1?`<div class="price-choice">${prices.map(p=>`<button type="button" class="price-option" onclick="selectOfferPrice(${p})">৳ ${p}</button>`).join("")}</div>`:""}
 <input id="purchasePhone" class="input" placeholder="যে নম্বরে প্যাকেজ যাবে (01XXXXXXXXX)">
 <input id="purchasePrice" class="input" type="hidden" value="${price||""}">
 <button class="btn btn-primary full-btn" onclick="confirmPurchase(${o.id})">কনফার্ম করে কিনুন</button>
 </div>`;
 document.body.appendChild(m)
}
function selectOfferPrice(p){const el=document.getElementById("purchasePrice");if(el)el.value=p;document.querySelectorAll(".price-option").forEach(b=>b.classList.toggle("selected",b.textContent.includes(String(p))))}
function confirmPurchase(id){
 const o=getOffers().find(x=>x.id===id),phone=document.getElementById("purchasePhone")?.value.trim(),price=Number(document.getElementById("purchasePrice")?.value);
 if(!phone){toast("যে নম্বরে প্যাকেজ যাবে সেই নম্বর দিন");return}
 if(!price){toast("একটি প্যাকেজ মূল্য নির্বাচন করুন");return}
 if(getBalance()<price){toast("মূল ব্যালেন্সে পর্যাপ্ত টাকা নেই। আগে টাকা এড করুন।");return}
 setBalance(getBalance()-price);
 const orders=JSON.parse(localStorage.getItem("it_orders")||"[]");
 orders.push({id:Date.now(),offerId:id,title:o.title,operator:o.operator,phone,price,status:"pending",createdAt:new Date().toISOString()});
 localStorage.setItem("it_orders",JSON.stringify(orders));
 document.getElementById("buyModal")?.remove();toast("প্যাকেজ কেনার অনুরোধ সফল হয়েছে")
}

function renderHome(){
 return `<div class="app-home">
 <header class="blue-header"><a href="#home" class="app-brand"><img src="assets/islamic-telecom-logo.png"><span>ইসলামিক টেলিকম</span></a><button class="round-profile" onclick="location.hash='#profile'">👤</button></header>
 <section class="operator-panel"><h2>Recharge &gt;&gt; Select Operator</h2><div class="operator-grid">${operators.map(x=>`<button class="operator-tile" onclick="location.hash='#offers?operator=${x.id}'"><div class="operator-logo-box"><img src="${x.logo}" alt="${x.name}"></div><span>${x.short}</span></button>`).join("")}</div></section>
 <section class="home-section"><div class="home-heading">Suggestion</div><div class="suggestion-banner"><b>অ্যাকাউন্টের নিরাপত্তা স্বার্থে</b><br><span>আপনার PIN / Password কারও সাথে শেয়ার করবেন না</span></div><div class="dots">● ○ ○ ○</div></section>
 <section class="home-section"><div class="home-heading">Quick Link</div><div class="quick-grid">
 <button onclick="openRecharge()"><b>💳</b><span>Flexiload</span></button><button onclick="location.hash='#offers'"><b>📦</b><span>Drive Pack</span></button><button onclick="location.hash='#regular'"><b>🎟️</b><span>Regular Pack</span><small>অপারেটর বেছে নিন</small></button><button onclick="location.hash='#customer'"><b>🧾</b><span>History</span></button>
 <button onclick="location.hash='#balance'"><b>🪽</b><span>B banking</span></button><button onclick="location.hash='#balance'"><b>💳</b><span>Nagad</span></button><button onclick="location.hash='#services'"><b>💡</b><span>Pay Bill</span></button><button onclick="location.hash='#balance'"><b>Ⓜ️</b><span>upay</span></button>
 <button onclick="location.hash='#balance'"><b>🚀</b><span>ROCKET</span></button><button onclick="location.hash='#services'"><b>🏦</b><span>Banking</span></button><button onclick="location.hash='#balance'"><b>💰</b><span>MyCash</span></button><button onclick="location.hash='#balance'"><b>💧</b><span>Cellfin</span></button>
 <button onclick="location.hash='#services'"><b>📞</b><span>BPO</span></button><button onclick="location.hash='#balance'"><b>💠</b><span>SureCash</span></button></div></section>
 <section class="home-section"><div class="home-heading prayer-title-row"><span>মসজিদের ঘড়ি ও নামাজের সময়</span><button onclick="openPrayerLocation()">📍 লোকেশন</button></div>
 <div class="mosque-clock"><div class="clock-arch"><div class="clock-brand">ISLAMIC TELECOM</div><div id="mosqueTime" class="digital-clock">00:00:00</div><div id="mosqueDate" class="digital-date">--</div></div><div id="prayerSchedule" class="prayer-list"><div class="loading-line">নামাজের সময় লোড হচ্ছে...</div></div></div></section>
 <section class="home-section"><div class="home-heading">বর্তমান আবহাওয়া</div><div class="weather-panel"><div id="weatherData">আবহাওয়ার তথ্য লোড হচ্ছে...</div></div></section>
 </div>`
}

function renderRegular(){
 const params=new URLSearchParams(location.hash.split('?')[1]||''),selected=params.get('operator')||'';
 if(!selected){
   return `<div class="container"><div class="page-head"><div><h2>রেগুলার প্যাক</h2><p>প্রথমে অপারেটর নির্বাচন করুন। তারপর শুধু ওই অপারেটরের রেগুলার রিচার্জ অফার দেখা যাবে।</p></div><div class="balance-mini">মূল ব্যালেন্স<br><b>৳ ${getBalance().toFixed(2)}</b></div></div><div class="regular-operator-tabs regular-only-operators">${operators.map(x=>`<a class="operator-select-card" href="#regular?operator=${x.id}"><img src="${x.logo}" alt="${x.name}"><strong>${x.name}</strong><span>রেগুলার প্যাক দেখুন</span></a>`).join('')}</div><div class="regular-empty"><b>অপারেটর নির্বাচন করুন</b><span>গ্রামীণফোন, রবি, এয়ারটেল, বাংলালিংক, টেলিটক বা স্কিটোতে চাপ দিলে শুধু সেই অপারেটরের রেগুলার প্যাক আসবে।</span></div></div>`
 }
 const list=regularPacks.filter(x=>x.operator===selected);
 const selectedOperator=op(selected);
 return `<div class="container"><div class="page-head"><div><h2>${selectedOperator.name} — রেগুলার প্যাক</h2><p>শুধু ${selectedOperator.name}-এর রেগুলার রিচার্জ অফার।</p></div><div class="balance-mini">মূল ব্যালেন্স<br><b>৳ ${getBalance().toFixed(2)}</b></div></div><div class="regular-back"><a href="#regular">← সব অপারেটর</a></div><div class="offer-grid">${list.map(regularCard).join('')}</div><div class="regular-note">⚠️ রেগুলার রিচার্জ সুবিধা অপারেটরভেদে ও সময়ভেদে পরিবর্তিত হতে পারে।</div></div>`
}
function regularCard(o){const x=op(o.operator);return `<article class="offer-card regular-card"><div class="offer-top"><div class="mini-op"><img src="${x.logo}" alt=""> ${x.name}</div><span class="pill">রেগুলার</span></div><h3>${o.title}</h3><div class="offer-value">${o.value}</div><div class="offer-meta"><div class="meta"><small>রিচার্জ</small><b class="price-small">৳ ${o.price}</b></div><div class="meta"><small>মেয়াদ</small><b>${o.validity}</b></div></div><p class="regular-note-small">${o.note}</p><button class="btn btn-primary full-btn" onclick="openRegularRecharge('${o.id}')">এই টাকা রিচার্জ করুন</button></article>`}
function openRegularRecharge(id){const o=regularPacks.find(x=>x.id===id);if(!o)return;openRecharge(o.price,o.operator)}
function renderOffers(){
 const params=new URLSearchParams(location.hash.split("?")[1]||"");
 const selectedOp=params.get("operator")||"";
 const selectedOperator=selectedOp?op(selectedOp):null;
 const list=getOffers().filter(x=>x.status==="active"&&(!selectedOp||x.operator===selectedOp));
 return `<div class="container offers-page">
 <div class="page-head">
   <div>
    <h2>${selectedOperator?selectedOperator.name+" এর অফার":"সকল অফার"}</h2>
    <p>${selectedOperator?selectedOperator.name+" অপারেটরের সব অফার":"অফার নির্বাচন করুন"}</p>
   </div>
   <div class="balance-mini">মূল ব্যালেন্স<br><b>৳ ${getBalance().toFixed(2)}</b></div>
 </div>
 ${selectedOperator?`<div class="selected-operator-banner"><img src="${selectedOperator.logo}" alt=""><div><b>${selectedOperator.name}</b><span>শুধু এই অপারেটরের অফার</span></div></div>`:""}
 <div id="offerGrid" class="offer-grid">${list.length?list.map(offerCard).join(""):`<div class="empty">এই অপারেটরের কোনো অফার পাওয়া যায়নি।</div>`}</div>
 </div>`
}
function filterOffers(){ return; }
function renderOperators(){return `<div class="container"><div class="page-head"><h2>অপারেটর</h2></div><div class="operator-page-grid">${operators.map(x=>`<a class="op-card-new" href="#offers?operator=${x.id}"><div class="op-logo-wrap"><img src="${x.logo}"></div><h3>${x.name}</h3><p>${getOffers().filter(o=>o.operator===x.id&&o.status==="active").length}টি অফার</p></a>`).join("")}</div></div>`}
function renderCategories(){return `<div class="container"><div class="page-head"><h2>অফার ক্যাটাগরি</h2></div><div class="category-grid">${categories.map(x=>`<a class="category-card-new" href="#offers?category=${x.id}"><b>${x.icon} ${x.name}</b><p>${x.desc}</p></a>`).join("")}</div></div>`}
function renderFav(){const f=JSON.parse(localStorage.getItem("it_fav")||"[]"),list=getOffers().filter(x=>f.includes(x.id));return `<div class="container"><div class="page-head"><h2>পছন্দের অফার</h2></div><div class="offer-grid">${list.length?list.map(offerCard).join(""):`<div class="empty">এখনও কোনো অফার পছন্দের তালিকায় যোগ করা হয়নি।</div>`}</div></div>`}

const services=[
{id:"electricity",name:"বিদ্যুৎ বিল",icon:"💡",field:"মিটার / কাস্টমার নম্বর",placeholder:"মিটার বা কাস্টমার নম্বর"},
{id:"gas",name:"গ্যাস বিল",icon:"🔥",field:"কাস্টমার নম্বর",placeholder:"কাস্টমার নম্বর"},
{id:"water",name:"পানি বিল",icon:"💧",field:"কাস্টমার নম্বর",placeholder:"কাস্টমার নম্বর"},
{id:"wifi",name:"WiFi বিল",icon:"📶",field:"কাস্টমার / লাইন নম্বর",placeholder:"কাস্টমার বা লাইন নম্বর"},
{id:"dish",name:"ডিশ / কেবল বিল",icon:"📺",field:"কাস্টমার নম্বর",placeholder:"কাস্টমার নম্বর"},
{id:"bank",name:"ব্যাংকে টাকা জমা",icon:"🏦",field:"অ্যাকাউন্ট / তথ্য",placeholder:"ব্যাংকের নাম ও অ্যাকাউন্ট তথ্য"},
{id:"other",name:"অন্যান্য বিল",icon:"🧾",field:"সেবা / অ্যাকাউন্ট তথ্য",placeholder:"প্রয়োজনীয় তথ্য"}
];
function addBalance(){
 const m=document.createElement("div");m.className="modal-backdrop";m.id="balanceModal";
 m.innerHTML=`<div class="modal"><button class="modal-close" onclick="this.closest('.modal-backdrop').remove()">×</button><div class="big-icon">💰</div><h2>মূল ব্যালেন্সে টাকা এড করুন</h2><div class="balance-buy-box"><span>বর্তমান ব্যালেন্স</span><strong>৳ ${getBalance().toFixed(2)}</strong></div><div class="payment-box"><b>Send Money নম্বর</b><strong>01865110004</strong><small>এই নম্বরে টাকা Send Money করে TrxID দিন।</small></div><input id="balanceAmount" class="input" placeholder="টাকার পরিমাণ" inputmode="decimal"><input id="balanceTrx" class="input" placeholder="Transaction ID / TrxID"><button class="btn btn-primary full-btn" onclick="submitBalance()">টাকা যোগ করার অনুরোধ দিন</button></div>`;
 document.body.appendChild(m)
}
function submitBalance(){
 const amount=Number(document.getElementById("balanceAmount")?.value),trx=document.getElementById("balanceTrx")?.value.trim();if(!amount||amount<=0||!trx){toast("টাকার পরিমাণ ও TrxID দিন");return}
 const r=JSON.parse(localStorage.getItem("it_balance_requests")||"[]");r.push({id:Date.now(),amount,trx,status:"pending",createdAt:new Date().toISOString()});localStorage.setItem("it_balance_requests",JSON.stringify(r));document.getElementById("balanceModal")?.remove();toast("মূল ব্যালেন্সে টাকা যোগ করার অনুরোধ জমা হয়েছে")
}
function renderBalance(){return `<div class="container"><div class="balance-hero"><div><span>মূল ব্যালেন্স</span><strong>৳ ${getBalance().toFixed(2)}</strong><small>অফার ও বিল পেমেন্টের জন্য</small></div><button class="btn btn-primary" onclick="addBalance()">＋ টাকা এড করুন</button></div><div class="balance-instructions"><h3>মূল ব্যালেন্সে টাকা যোগ করুন</h3><p>01865110004 নম্বরে Send Money → TrxID জমা → ব্যালেন্স অনুমোদনের পর অফার/বিল পেমেন্ট করুন।</p></div></div>`}
function openService(id){
 const s=services.find(x=>x.id===id);if(!s)return;
 const m=document.createElement("div");m.className="modal-backdrop";m.id="serviceModal";
 m.innerHTML=`<div class="modal"><button class="modal-close" onclick="this.closest('.modal-backdrop').remove()">×</button><div class="big-icon">${s.icon}</div><h2>${s.name}</h2><div class="balance-buy-box"><span>ব্যবহারযোগ্য মূল ব্যালেন্স</span><strong>৳ ${getBalance().toFixed(2)}</strong></div><label class="form-label">${s.field}</label><input id="serviceAccount" class="input" placeholder="${s.placeholder}"><label class="form-label">বিলের পরিমাণ (৳)</label><input id="serviceAmount" class="input" inputmode="decimal" placeholder="যেমন: 500"><button class="btn btn-primary full-btn" onclick="submitService('${s.id}')">সরাসরি পেমেন্ট সাবমিট</button></div>`;
 document.body.appendChild(m)
}
function submitService(id){
 const s=services.find(x=>x.id===id),account=document.getElementById("serviceAccount")?.value.trim(),amount=Number(document.getElementById("serviceAmount")?.value);
 if(!account||!amount||amount<=0){toast("প্রয়োজনীয় তথ্য ও সঠিক বিলের পরিমাণ দিন");return}
 if(getBalance()<amount){toast("মূল ব্যালেন্সে পর্যাপ্ত টাকা নেই");return}
 setBalance(getBalance()-amount);const r=JSON.parse(localStorage.getItem("it_service_requests")||"[]");r.push({id:Date.now(),serviceId:id,serviceName:s.name,account,amount,status:"pending",createdAt:new Date().toISOString()});localStorage.setItem("it_service_requests",JSON.stringify(r));document.getElementById("serviceModal")?.remove();toast("বিল পেমেন্টের অনুরোধ সাবমিট হয়েছে")
}

function openRecharge(){
 const m=document.createElement("div");m.className="modal-backdrop";m.id="rechargeModal";
 m.innerHTML=`<div class="modal">
 <button class="modal-close" onclick="this.closest('.modal-backdrop').remove()">×</button>
 <div class="big-icon">📱</div><h2>মোবাইল রিচার্জ</h2>
 <p class="modal-subtitle">নাম্বার দিন এবং কত টাকা রিচার্জ করবেন তা লিখুন</p>
 <label class="form-label">মোবাইল নম্বর</label>
 <input id="rechargePhone" class="input" inputmode="numeric" maxlength="11" placeholder="01XXXXXXXXX">
 <label class="form-label">রিচার্জের পরিমাণ (৳)</label>
 <input id="rechargeAmount" class="input" inputmode="decimal" placeholder="যেমন: 100">
 <div class="quick-amounts">${[20,50,100,200,300,500,1000].map(x=>`<button type="button" onclick="document.getElementById('rechargeAmount').value=${x}">৳ ${x}</button>`).join("")}</div>
 <div class="balance-buy-box"><span>বর্তমান মূল ব্যালেন্স</span><strong>৳ ${getBalance().toFixed(2)}</strong></div>
 <button class="btn btn-primary full-btn" onclick="submitRecharge()">রিচার্জ সাবমিট করুন</button>
 </div>`;
 document.body.appendChild(m)
}
function submitRecharge(){
 const phone=document.getElementById("rechargePhone")?.value.trim(),amount=Number(document.getElementById("rechargeAmount")?.value);
 if(!/^01\d{9}$/.test(phone)){toast("সঠিক ১১ সংখ্যার মোবাইল নম্বর দিন");return}
 if(!amount||amount<=0){toast("রিচার্জের পরিমাণ দিন");return}
 if(getBalance()<amount){toast("মূল ব্যালেন্সে পর্যাপ্ত টাকা নেই");return}
 setBalance(getBalance()-amount);
 const r=JSON.parse(localStorage.getItem("it_recharge_requests")||"[]");
 r.push({id:Date.now(),phone,amount,status:"pending",createdAt:new Date().toISOString()});
 localStorage.setItem("it_recharge_requests",JSON.stringify(r));
 document.getElementById("rechargeModal")?.remove();toast("রিচার্জের অনুরোধ সাবমিট হয়েছে")
}

function openPrayerLocation(){
 const saved=JSON.parse(localStorage.getItem("it_prayer_location")||"null");
 const m=document.createElement("div");m.className="modal-backdrop";m.id="locationModal";
 m.innerHTML=`<div class="modal">
 <button class="modal-close" onclick="this.closest('.modal-backdrop').remove()">×</button>
 <div class="big-icon">📍</div><h2>নামাজের লোকেশন</h2>
 <p class="modal-subtitle">যে শহর/এলাকার নাম দেবেন, সেই এলাকার নামাজের সময় দেখাবে।</p>
 <label class="form-label">শহর / এলাকা</label>
 <input id="prayerCity" class="input" value="${saved?.city||""}" placeholder="যেমন: Dhaka">
 <label class="form-label">দেশ</label>
 <input id="prayerCountry" class="input" value="${saved?.country||"Bangladesh"}" placeholder="যেমন: Bangladesh">
 <button class="btn btn-primary full-btn" onclick="savePrayerLocation()">লোকেশন সেট করুন</button>
 <button class="btn btn-light full-btn" onclick="useMyLocation()">📍 আমার বর্তমান লোকেশন ব্যবহার করুন</button>
 </div>`;
 document.body.appendChild(m)
}
function savePrayerLocation(){
 const city=document.getElementById("prayerCity")?.value.trim(),country=document.getElementById("prayerCountry")?.value.trim()||"Bangladesh";
 if(!city){toast("শহর/এলাকার নাম দিন");return}
 localStorage.setItem("it_prayer_location",JSON.stringify({city,country}));
 document.getElementById("locationModal")?.remove();toast("নামাজের লোকেশন সেট হয়েছে");startLiveWidgets()
}
async function useMyLocation(){
 if(!navigator.geolocation){toast("এই ডিভাইসে লোকেশন সুবিধা নেই");return}
 navigator.geolocation.getCurrentPosition(async pos=>{
   localStorage.setItem("it_prayer_coords",JSON.stringify({lat:pos.coords.latitude,lon:pos.coords.longitude}));
   localStorage.removeItem("it_prayer_location");
   document.getElementById("locationModal")?.remove();toast("বর্তমান লোকেশন সেট হয়েছে");startLiveWidgets()
 },()=>toast("লোকেশন অনুমতি দেওয়া হয়নি"))
}

function renderServices(){
 return `<div class="container"><div class="page-head"><div><h2>বিল ও অন্যান্য সেবা</h2><p>যে সেবা দরকার সেটিতে চাপ দিন, প্রয়োজনীয় তথ্য ও টাকার পরিমাণ দিন।</p></div><div class="balance-mini">মূল ব্যালেন্স<br><b>৳ ${getBalance().toFixed(2)}</b></div></div>
 <div class="service-grid-new">${services.map(s=>`<button class="service-card-new" onclick="openService('${s.id}')"><span>${s.icon}</span><b>${s.name}</b><small>বিস্তারিত দিয়ে সাবমিট করুন</small></button>`).join("")}</div></div>`
}
function renderProfile(){const u=getUser();if(!u)return '';const photo=u.photo||'';return `<div class="container"><div class="profile-card"><div class="profile-avatar-wrap"><img id="profileAvatar" class="profile-avatar" src="${photo||'assets/islamic-telecom-logo.png'}" alt="প্রোফাইল"><label class="photo-change">📷 ছবি পরিবর্তন<input type="file" accept="image/*" onchange="changeProfilePhoto(this)"></label></div><h2>${esc(u.name)}</h2><p>${esc(u.email)}</p><span class="verified-badge">✓ ভেরিফাইড অ্যাকাউন্ট</span><div class="profile-info"><div><small>মোবাইল</small><b>${esc(u.phone)}</b></div><div><small>বিভাগ</small><b>${esc(u.division)}</b></div><div><small>জেলা</small><b>${esc(u.district)}</b></div><div><small>এলাকা</small><b>${esc(u.area)}</b></div><div><small>বাড়ি/হাউস</small><b>${esc(u.house)}</b></div><div><small>ঠিকানা</small><b>${esc(u.address)}</b></div></div><button class="btn btn-light full-btn" onclick="logout()">লগআউট</button></div></div>`}
function renderCustomer(){
 const orders=JSON.parse(localStorage.getItem("it_orders")||"[]"),requests=JSON.parse(localStorage.getItem("it_service_requests")||"[]"),br=JSON.parse(localStorage.getItem("it_balance_requests")||"[]"),rr=JSON.parse(localStorage.getItem("it_recharge_requests")||"[]");
 return `<div class="container"><div class="customer-panel"><h2>👤 কাস্টমার</h2>
 <div class="balance-hero"><div><span>মূল ব্যালেন্স</span><strong>৳ ${getBalance().toFixed(2)}</strong></div><button class="btn btn-primary" onclick="addBalance()">＋ টাকা এড করুন</button></div>
 <h3>রিচার্জ ইতিহাস</h3>${rr.length?rr.slice().reverse().map(x=>`<div class="history-row"><b>📱 ${x.phone}</b><span>৳ ${x.amount} · ${x.status==="pending"?"অপেক্ষমাণ":"সম্পন্ন"}</span></div>`).join(""):`<div class="empty">কোনো রিচার্জ নেই।</div>`}
 <h3>প্যাকেজ অর্ডার</h3>${orders.length?orders.slice().reverse().map(x=>`<div class="history-row"><b>${x.title}</b><span>৳ ${x.price} · ${x.phone} · ${x.status==="pending"?"অপেক্ষমাণ":"সম্পন্ন"}</span></div>`).join(""):`<div class="empty">কোনো প্যাকেজ অর্ডার নেই।</div>`}
 <h3>বিল পেমেন্ট</h3>${requests.length?requests.slice().reverse().map(x=>`<div class="history-row"><b>${x.serviceName}</b><span>৳ ${x.amount} · ${x.account} · ${x.status==="pending"?"অপেক্ষমাণ":"সম্পন্ন"}</span></div>`).join(""):`<div class="empty">কোনো বিল পেমেন্ট নেই।</div>`}
 <h3>ব্যালেন্স যোগ</h3>${br.length?br.slice().reverse().map(x=>`<div class="history-row"><b>৳ ${x.amount}</b><span>TrxID: ${x.trx} · ${x.status==="pending"?"অপেক্ষমাণ":"সম্পন্ন"}</span></div>`).join(""):`<div class="empty">কোনো ব্যালেন্স অনুরোধ নেই।</div>`}
 </div></div>`
}

let liveTicker=null;
function startLiveWidgets(){
 if(liveTicker)clearInterval(liveTicker);
 const tick=()=>{const now=new Date(),t=document.getElementById("mosqueTime"),d=document.getElementById("mosqueDate");if(t)t.textContent=now.toLocaleTimeString("en-GB",{hour12:false});if(d)d.textContent=now.toLocaleDateString("bn-BD",{weekday:"long",day:"numeric",month:"long",year:"numeric"})};tick();liveTicker=setInterval(tick,1000);loadPrayerSchedule();loadLiveWeather()
}
async function loadPrayerSchedule(){
 const el=document.getElementById("prayerSchedule"),loc=JSON.parse(localStorage.getItem("it_prayer_location")||"null"),coords=JSON.parse(localStorage.getItem("it_prayer_coords")||"null");if(!el)return;
 const d=new Date();
 try{
   let url;
   if(coords) url=`https://api.aladhan.com/v1/timings/${d.getDate()}-${d.getMonth()+1}-${d.getFullYear()}?latitude=${coords.lat}&longitude=${coords.lon}&method=1&school=1`;
   else {const city=encodeURIComponent(loc?.city||"Dhaka"),country=encodeURIComponent(loc?.country||"Bangladesh");url=`https://api.aladhan.com/v1/timingsByCity/${d.getDate()}-${d.getMonth()+1}-${d.getFullYear()}?city=${city}&country=${country}&method=1&school=1`}
   const r=await fetch(url),j=await r.json();if(j.code!==200)throw Error("api");
   const t=j.data.timings,where=coords?"বর্তমান লোকেশন":`${loc?.city||"Dhaka"}, ${loc?.country||"Bangladesh"}`;
   const rows=[["ফজর","Fajr"],["যোহর","Dhuhr"],["আসর","Asr"],["মাগরিব","Maghrib"],["এশা","Isha"]];
   el.innerHTML=`<div class="prayer-location-line">📍 ${where} <button onclick="openPrayerLocation()">লোকেশন পরিবর্তন</button></div>`+rows.map(([bn,k])=>`<div class="prayer-row"><span>${bn}</span><b>${t[k]}</b></div>`).join("")
 }catch(e){el.innerHTML=`<div class="loading-line">নামাজের সময় লোড করা যায়নি।<br><button class="btn btn-light" onclick="openPrayerLocation()">📍 লোকেশন সেট করুন</button></div>`}
}

async function loadLiveWeather(){
 const el=document.getElementById("weatherData");if(!el)return;let lat=null,lon=null,name="লোকেশন সেট করুন";
 try{if(navigator.geolocation){const p=await new Promise((res,rej)=>navigator.geolocation.getCurrentPosition(res,rej,{timeout:4000,maximumAge:600000}));lat=p.coords.latitude;lon=p.coords.longitude;name="বর্তমান এলাকা"}}catch(e){}
 if(lat===null||lon===null){el.innerHTML='<div class="loading-line">আবহাওয়া দেখতে হোমে 📍 লোকেশন অনুমতি দিন।</div>';return}
 try{const r=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,cloud_cover,surface_pressure&timezone=auto`),j=await r.json(),c=j.current;const map={0:"পরিষ্কার আকাশ",1:"মূলত পরিষ্কার",2:"আংশিক মেঘলা",3:"মেঘলা",45:"কুয়াশা",48:"কুয়াশা",51:"হালকা গুঁড়ি বৃষ্টি",53:"গুঁড়ি বৃষ্টি",55:"গুঁড়ি বৃষ্টি",61:"হালকা বৃষ্টি",63:"বৃষ্টি",65:"ভারী বৃষ্টি",80:"বৃষ্টির ঝাপটা",81:"বৃষ্টির ঝাপটা",82:"ভারী বৃষ্টির ঝাপটা",95:"বজ্রসহ বৃষ্টি"};el.innerHTML=`<div class="weather-head"><div class="weather-temp">${Number(c.temperature_2m).toFixed(1)}°C</div><div><b>${map[c.weather_code]||"বর্তমান আবহাওয়া"}</b><small>${name}</small></div></div><div class="weather-stats"><span>অনুভূতি <b>${Number(c.apparent_temperature).toFixed(1)}°C</b></span><span>আর্দ্রতা <b>${c.relative_humidity_2m}%</b></span><span>বাতাস <b>${Number(c.wind_speed_10m).toFixed(1)} km/h</b></span><span>মেঘ <b>${c.cloud_cover}%</b></span><span>চাপ <b>${Number(c.surface_pressure).toFixed(0)} hPa</b></span></div>`}catch(e){el.innerHTML='<div class="loading-line">রিয়েল আবহাওয়ার তথ্য পাওয়া যায়নি।</div>'}
}

function render(){
 const hash=location.hash||"#home",route=hash.split("?")[0].slice(1),map={home:renderHome,offers:renderOffers,regular:renderRegular,operators:renderOperators,categories:renderCategories,favorites:renderFav,balance:renderBalance,services:renderServices,customer:renderCustomer,profile:renderProfile};
 if(!isVerified()){renderAuth(location.hash==="#register"?"register":"login");return}
 document.getElementById("app").innerHTML=(map[route]||renderHome)();setActive();if(route==="home")setTimeout(startLiveWidgets,30);document.querySelectorAll("[data-route]").forEach(a=>a.onclick=()=>document.getElementById("sidebar")?.classList.remove("open"))
}
document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("menuBtn").onclick=()=>document.getElementById("sidebar").classList.toggle("open");
document.getElementById("themeBtn").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("it_dark",document.body.classList.contains("dark"))};
if(localStorage.getItem("it_dark")==="true")document.body.classList.add("dark");
window.addEventListener("hashchange",render);window.addEventListener("load",render);


function requestWhatsAppPin(){
  const phone = document.getElementById("regPhone")?.value.trim() || "";
  const email = document.getElementById("regEmail")?.value.trim() || "";
  const name = document.getElementById("regName")?.value.trim() || "";
  const code = localStorage.getItem("it_pending_verify_code") || "";
  const text = `ইসলামিক টেলিকম অ্যাকাউন্ট ভেরিফিকেশন%0Aনাম: ${encodeURIComponent(name)}%0Aমোবাইল: ${encodeURIComponent(phone)}%0Aইমেইল: ${encodeURIComponent(email)}%0A%0Aঅনুগ্রহ করে আমার ভেরিফিকেশন PIN প্রদান করুন।`;
  window.open(`https://wa.me/8801865110004?text=${text}`,"_blank");
}
function openVerifyAccount(){
  const pending = JSON.parse(localStorage.getItem("it_pending_registration") || "null");
  if(!pending){ alert("আগে একটি অ্যাকাউন্ট রেজিস্ট্রেশন করুন।"); return; }
  showModal(`
    <div class="verify-card">
      <div class="verify-icon">✓</div>
      <h2>অ্যাকাউন্ট ভেরিফাই করুন</h2>
      <p>আপনার ভেরিফিকেশন PIN পেতে WhatsApp-এ আমাদের সাথে যোগাযোগ করুন।</p>
      <div class="wa-box">
        <b>WhatsApp নম্বর</b>
        <span>01865110004</span>
      </div>
      <button class="btn btn-primary" onclick="requestWhatsAppPin()">WhatsApp-এ PIN চাইুন</button>
      <label class="field-label">আপনার পাওয়া PIN</label>
      <input id="verifyPinInput" class="form-control" inputmode="numeric" maxlength="6" placeholder="PIN লিখুন">
      <button class="btn btn-success" onclick="submitAccountVerification()">ভেরিফাই ও অ্যাকাউন্ট চালু করুন</button>
    </div>
  `);
}
function submitAccountVerification(){
  const pending = JSON.parse(localStorage.getItem("it_pending_registration") || "null");
  const entered = document.getElementById("verifyPinInput")?.value.trim();
  if(!pending){ alert("ভেরিফিকেশন রেকর্ড পাওয়া যায়নি।"); return; }
  if(!entered){ alert("WhatsApp থেকে পাওয়া PIN লিখুন।"); return; }
  // No API: the owner manually provides the PIN. Demo accepts the PIN saved by the local verification workflow.
  const expected = localStorage.getItem("it_verify_pin");
  if(expected && entered !== expected){ alert("PIN সঠিক নয়।"); return; }
  pending.verified = true;
  localStorage.setItem("it_user", JSON.stringify(pending));
  localStorage.removeItem("it_pending_registration");
  localStorage.removeItem("it_verify_pin");
  alert("অ্যাকাউন্ট ভেরিফাই হয়েছে। এখন লগইন করতে পারবেন।");
  closeModal();
}

window.openVerifyAccount=openVerifyAccount;
