import { auth, database } from './firebase.js';
import { signInAnonymously, onAuthStateChanged, setPersistence, browserLocalPersistence } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js';
import { ref, get, set, update, push, onValue, runTransaction } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js';

const PHONE_RE = /^01\d{9}$/;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let currentMember = null, notificationUnsub = null, broadcastUnsub = null;
const $ = id => document.getElementById(id);
const redirectParams = new URLSearchParams(location.search);
const requestedReturn = ['quiz.html','activity.html'].includes(redirectParams.get('returnTo')) ? redirectParams.get('returnTo') : '';
if(redirectParams.get('authRequired')==='1' && requestedReturn) sessionStorage.setItem('df_post_login_return', requestedReturn);
function finishLoginRedirect(){const target=sessionStorage.getItem('df_post_login_return');if(target){sessionStorage.removeItem('df_post_login_return');location.replace(target);return true;}return false;}

function injectUI(){
 const isMainPage = location.pathname.endsWith('/') || /(?:^|\/)index\.html$/i.test(location.pathname);
 if(!isMainPage) return;
 if(document.getElementById('memberSystemRoot')) return;
 const root=document.createElement('div'); root.id='memberSystemRoot'; root.innerHTML=`
 <button id="memberLoginButton" class="ms-login-fab" type="button" aria-haspopup="dialog">♙ <span>লগইন</span></button>
 <aside id="memberNotificationPanel" class="ms-notice-panel" aria-live="polite" hidden><div class="ms-panel-head"><strong>🔔 নোটিফিকেশন</strong><button id="msNoticeClose" type="button" aria-label="বন্ধ করুন">×</button></div><div id="msMemberGreeting" class="ms-greeting"></div><div id="msNotificationList"></div></aside>
 <div id="memberLoginModal" class="ms-modal" hidden><section class="ms-modal-card" role="dialog" aria-modal="true" aria-labelledby="msLoginTitle"><button id="msModalClose" class="ms-close" type="button" aria-label="বন্ধ করুন">×</button><div class="ms-icon">♙</div><h2 id="msLoginTitle">সদস্য লগইন</h2><div id="msAuthRequiredNotice" class="ms-auth-required" hidden>🔐 এই সেকশনটি ব্যবহার করতে আপনাকে প্রথমে লগইন করতে হবে। অনুগ্রহ করে আপনার অ্যাকাউন্টে লগইন করুন। লগইন করার পর আপনি কুইজ ও দৈনন্দিন আমল সেকশন ব্যবহার করতে পারবেন।</div><p>নাম ও বাংলাদেশি মোবাইল নম্বর দিয়ে একবার নিবন্ধন করুন। এই ব্রাউজারে লগইন সংরক্ষিত থাকবে।</p><form id="msLoginForm"><label>আপনার নাম<input id="msName" name="name" maxlength="80" required autocomplete="name" placeholder="পূর্ণ নাম"></label><label>মোবাইল নম্বর<input id="msPhone" name="phone" required inputmode="numeric" autocomplete="tel-national" maxlength="11" placeholder="01XXXXXXXXX"></label><p class="ms-privacy">শুধু আপনার নিজের নম্বর দিন। এই সহজ লগইন OTP দিয়ে নম্বরের মালিকানা যাচাই করে না।</p><button id="msLoginSubmit" type="submit">লগইন / নিবন্ধন</button><p id="msLoginStatus" role="status"></p></form></section></div>`;
 document.body.appendChild(root);
 const style=document.createElement('style'); style.textContent=`
 .ms-login-fab{position:fixed;z-index:9000;right:18px;top:16px;border:0;border-radius:999px;padding:6px 10px;min-height:32px;font-size:11px;background:linear-gradient(135deg,#0e7a58,#13a37a);color:white;font:700 12px system-ui;box-shadow:0 8px 22px #08745130;cursor:pointer}.ms-login-fab.ms-logged{background:linear-gradient(135deg,#173b32,#0e7a58)}
 .ms-modal[hidden],.ms-notice-panel[hidden],.ms-auth-required[hidden]{display:none!important}.ms-auth-required{margin:14px 0;padding:13px 14px;border:1px solid #b9e5d0;border-radius:14px;background:linear-gradient(135deg,#effcf5,#fff9e9);color:#14583f;font-size:13px;line-height:1.7;font-weight:650}.ms-modal{position:fixed;inset:0;z-index:10000;background:#071b16a8;backdrop-filter:blur(7px);display:grid;place-items:center;padding:18px}.ms-modal-card{position:relative;width:min(100%,430px);padding:28px;border-radius:24px;background:#fff;color:#17342c;box-shadow:0 30px 90px #001d1670;font-family:system-ui,sans-serif}.ms-modal-card h2{margin:8px 0;font-size:25px}.ms-modal-card>p{line-height:1.65;color:#5e706a;font-size:14px}.ms-icon{width:48px;height:48px;display:grid;place-items:center;border-radius:15px;background:#e5f7ef;font-size:26px}.ms-close,.ms-panel-head button{position:absolute;right:15px;top:13px;border:0;background:#eef4f1;border-radius:50%;width:32px;height:32px;font-size:22px;cursor:pointer}.ms-modal-card label{display:block;margin:14px 0;font-size:13px;font-weight:700}.ms-modal-card input{box-sizing:border-box;display:block;width:100%;margin-top:7px;border:1px solid #d6e3dd;border-radius:12px;padding:13px;font:inherit;outline-color:#13a37a}.ms-modal-card form>button{width:100%;padding:13px;border:0;border-radius:12px;background:#0e7a58;color:#fff;font-weight:800;cursor:pointer}.ms-privacy{font-size:12px!important;color:#8a5b21!important;background:#fff7e8;padding:10px;border-radius:10px}.ms-greeting{padding:12px 14px;background:#eaf8f1;border-radius:12px;margin:12px 0;color:#155b43}.ms-notice-panel{position:fixed;z-index:9500;right:16px;top:66px;width:min(370px,calc(100vw - 32px));max-height:min(72vh,620px);overflow:auto;background:#fff;color:#18362c;border:1px solid #dbe9e1;border-radius:18px;box-shadow:0 18px 60px #092b1e35;padding:14px;font-family:system-ui,sans-serif}.ms-panel-head{position:relative;padding:5px 36px 12px 2px;border-bottom:1px solid #e7efeb}.ms-panel-head button{top:0;right:0}.ms-notice-item{padding:13px 3px;border-bottom:1px solid #edf2ef}.ms-notice-item:last-child{border-bottom:0}.ms-notice-item strong{display:block;margin-bottom:5px}.ms-notice-item p{margin:0;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.55;font-size:14px}.ms-notice-item small{display:block;color:#7a8982;margin-top:7px}.ms-empty{color:#75847d;padding:16px 4px;font-size:14px}#msLoginStatus{font-size:13px;color:#b42318;margin-bottom:0}
 @media(max-width:600px){.ms-login-fab{right:10px;top:10px;min-height:30px;padding:6px 9px;font-size:11px}.ms-modal-card{padding:23px}.ms-notice-panel{right:10px;top:58px}}
 `; document.head.appendChild(style);
 $('memberLoginButton').addEventListener('click',()=>{ if(currentMember){const p=$('memberNotificationPanel');p.hidden=!p.hidden;}else $('memberLoginModal').hidden=false; });
 $('msModalClose').addEventListener('click',()=> $('memberLoginModal').hidden=true);
 $('msNoticeClose').addEventListener('click',()=> $('memberNotificationPanel').hidden=true);
 $('memberLoginModal').addEventListener('click',e=>{if(e.target.id==='memberLoginModal')e.currentTarget.hidden=true;});
 $('msLoginForm').addEventListener('submit',registerMember);
}
async function registerMember(e){
 e.preventDefault(); const name=$('msName').value.trim(), phone=$('msPhone').value.replace(/[\s-]/g,''); const status=$('msLoginStatus'), btn=$('msLoginSubmit');
 if(name.length<2){status.textContent='কমপক্ষে ২ অক্ষরের নাম লিখুন।';return;}
 if(!PHONE_RE.test(phone)){status.textContent='বাংলাদেশি ১১ সংখ্যার মোবাইল নম্বর লিখুন (01XXXXXXXXX)।';return;}
 btn.disabled=true;status.style.color='#53665e';status.textContent='নিবন্ধন হচ্ছে…';
 try{
   await setPersistence(auth,browserLocalPersistence);
   const credential=auth.currentUser?{user:auth.currentUser}:await signInAnonymously(auth);
   const user=credential.user; const phoneKey=phone;
   // A transaction prevents two simultaneous browsers from claiming the same number.
   const claim=await runTransaction(ref(database,'memberPhoneIndex/'+phoneKey),old=>old===null?{uid:user.uid,createdAt:Date.now()}:old);
   if(!claim.committed || claim.snapshot.val()?.uid!==user.uid){status.style.color='#b42318';status.textContent='এই নম্বরটি আগে থেকেই নিবন্ধিত। অ্যাডমিনের সঙ্গে যোগাযোগ করুন।';return;}
   const existing=(await get(ref(database,'memberUsers/'+user.uid))).val()||{};
   await set(ref(database,'memberUsers/'+user.uid),{name,phone,createdAt:existing.createdAt||Date.now(),lastSeenAt:Date.now(),status:'active',...(existing.createdAt?{registeredAt:existing.registeredAt||Date.now()}:{registeredAt:Date.now()})});
   currentMember={uid:user.uid,name,phone}; localStorage.setItem('df_global_member',JSON.stringify(currentMember)); window.dispatchEvent(new CustomEvent('df-member-login',{detail:currentMember})); if($('memberLoginModal'))$('memberLoginModal').hidden=true; if($('memberLoginButton')){$('memberLoginButton').innerHTML='🔔 <span>নোটিফিকেশন</span>'; $('memberLoginButton').classList.add('ms-logged');}
   startNotifications(user.uid); status.textContent=''; if(finishLoginRedirect())return;
 }catch(err){console.error('Member registration error',err);status.style.color='#b42318';status.textContent='নিবন্ধন হয়নি। Firebase Rules ও ইন্টারনেট সংযোগ পরীক্ষা করুন।';}
 finally{btn.disabled=false;}
}
function renderNotifications(items){const box=$('msNotificationList'); if(!box)return; if(!items.length){box.innerHTML='<div class="ms-empty">এখনো কোনো নোটিফিকেশন নেই। নতুন নোটিশ এলে এখানে দেখা যাবে।</div>';return;} box.innerHTML=items.sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).map(n=>`<article class="ms-notice-item"><strong>${esc(n.title||'ধন্যবাদ ফাউন্ডেশন')}</strong><p>${esc(n.message||'')}</p><small>${n.createdAt?esc(new Date(n.createdAt).toLocaleString('bn-BD')):''}</small></article>`).join('');}
function startNotifications(uid){if(notificationUnsub)notificationUnsub();if(broadcastUnsub)broadcastUnsub();$('msMemberGreeting').textContent=`স্বাগতম, ${currentMember?.name||'সদস্য'}!`;
 let personal=[],broadcast=[];const refresh=()=>renderNotifications([...personal,...broadcast]);
 notificationUnsub=onValue(ref(database,'memberNotifications/'+uid),s=>{personal=[];if(s.exists())s.forEach(c=>personal.push({id:c.key,...(c.val()||{})}));refresh();},()=>{});
 broadcastUnsub=onValue(ref(database,'memberBroadcasts'),s=>{broadcast=[];if(s.exists())s.forEach(c=>broadcast.push({id:c.key,...(c.val()||{})}));refresh();},()=>{});
 $('memberLoginButton').title='নোটিফিকেশন দেখতে ক্লিক করুন';
}
injectUI();
// Protected-section redirects return to the homepage and open the existing login modal.
if(redirectParams.get('authRequired')==='1' && requestedReturn && !localStorage.getItem('df_global_member')) {
 const notice=$('msAuthRequiredNotice'), modal=$('memberLoginModal');
 if(notice) notice.hidden=false;
 if(modal) modal.hidden=false;
}
onAuthStateChanged(auth,async user=>{
 if(!user)return;
 try{const snap=await get(ref(database,'memberUsers/'+user.uid));if(!snap.exists())return;const d=snap.val()||{};if(d.status==='deleted'||!d.phone)return;currentMember={uid:user.uid,name:d.name||'সদস্য',phone:d.phone};localStorage.setItem('df_global_member',JSON.stringify(currentMember));window.dispatchEvent(new CustomEvent('df-member-login',{detail:currentMember}));if($('memberLoginButton')){$('memberLoginButton').innerHTML='🔔 <span>নোটিফিকেশন</span>';$('memberLoginButton').classList.add('ms-logged');startNotifications(user.uid);} if(redirectParams.get('authRequired')==='1')finishLoginRedirect();}
 catch(e){console.warn('Could not restore member session',e);}
});
