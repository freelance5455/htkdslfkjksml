# CPLS V2 Stage 1115

- Futures persistent feed hardened with multi-host fallback and 10s market-list cache.
- Futures page retries native snapshot immediately after navigation and uses browser contract market-data fallback if native cache is not yet warm.
- Trade K-Line now falls back to the Android native LBank K-Line bridge instead of waiting for a second browser connection.
- WebView HTTP cache is no longer cleared at startup; shared live state remains warm across internal pages.
- Version 11.4.0 / versionCode 112.
