# TOK TIK — mradi wa Android

Jina la app: **TOK TIK**  
Package ID: `com.toktik.app`

## Kilichomo
- Mradi wa Android wenye WebView unaofungua mfano wa TOK TIK ndani ya app.
- Skrini za mfano: video za demo, Like, maoni, search, habari, wasifu na kuchagua video ya ndani kwa majaribio.
- Faili ya app ipo `app/src/main/assets/index.html`.

## Muhimu
Huu ni **msimbo wa mradi**, si APK iliyokwisha jengwa. Hakuna huduma ya seva iliyounganishwa; kwa hiyo akaunti halisi, kupakia video kwa watumiaji wengine, kufuatana, ujumbe, moderering na habari za moja kwa moja bado hazipo. Video za demo na maoni ni vya ndani ya kifaa/mfano.

## Jinsi ya kujenga APK
1. Fungua mradi huu katika Android Studio kwenye kompyuta.
2. Ruhusu Gradle kupakua Android Gradle Plugin na SDK zinazohitajika.
3. Chagua **Build > Build APK(s)**.
4. APK ya majaribio itapatikana kwa kawaida ndani ya `app/build/outputs/apk/debug/`.

Kama unatumia simu pekee, unaweza kujaribu kufungua mradi kwa Android IDE inayoweza kujenga Gradle projects, lakini ujenzi unaweza kuhitaji kupakua SDK/Gradle na nafasi kubwa. Usisakinishe APK kutoka tovuti usiyoamini.

## Hatua zinazohitajika kwa toleo la mtandaoni
Ili TOK TIK iwe kama TikTok halisi, inahitaji backend salama na database, akaunti, hifadhi ya video, feed, maoni/likes zinazoshirikishwa, ripoti na udhibiti wa maudhui, pamoja na chanzo cha habari kinachoaminika.
