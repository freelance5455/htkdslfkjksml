// ===== مصر شات - النسخة الويب =====

// بيانات تجريبية
const demoUsers = [
  { id: 1, name: 'أحمد المصري', phone: '01012345678', last: 'عامل إيه يا نجم؟', time: '10:30', online: true },
  { id: 2, name: 'محمد علي', phone: '01123456789', last: 'ابعت الفويس', time: 'أمس', online: false },
  { id: 3, name: 'سارة حسن', phone: '01234567890', last: '📷 صورة', time: 'أمس', online: true },
  { id: 4, name: 'كريم', phone: '01555555555', last: 'يلا نتكلم', time: 'الأحد', online: false },
  { id: 5, name: 'نور', phone: '01098765432', last: 'وصلت يا معلم 😂', time: 'السبت', online: true },
];

let currentUser = null;
let currentChat = null;
let messages = {};

// ===== تهيئة =====
document.addEventListener('DOMContentLoaded', () => {
  // OTP inputs auto-focus
  const digits = document.querySelectorAll('.otp-digit');
  digits.forEach((input, i) => {
    input.addEventListener('input', () => {
      if (input.value && i < digits.length - 1) digits[i + 1].focus();
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !input.value && i > 0) digits[i - 1].focus();
    });
  });

  // تحقق لو مسجل قبل كده
  const saved = localStorage.getItem('masrchat_user');
  if (saved) {
    currentUser = JSON.parse(saved);
    setTimeout(() => showScreen('home'), 800);
  } else {
    setTimeout(() => showScreen('login'), 1500);
  }

  updateGreeting();
  renderChats();
});

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function updateGreeting() {
  const hour = new Date().getHours();
  let g = 'مساء النور';
  if (hour < 12) g = 'صباح الفل';
  else if (hour < 17) g = 'مساء الخير';
  const name = currentUser?.name || 'نجم';
  document.getElementById('greeting').textContent = `${g} يا ${name} ☀️`;
}

// ===== تسجيل =====
function sendOtp() {
  const phone = document.getElementById('phone').value.trim();
  if (phone.length < 10) {
    alert('اكتب رقم الموبايل صح يا نجم');
    return;
  }
  showScreen('otp');
}

function verifyOtp() {
  const digits = [...document.querySelectorAll('.otp-digit')].map(i => i.value).join('');
  const name = document.getElementById('displayName').value.trim();

  if (digits.length < 6) {
    alert('اكتب الكود كامل');
    return;
  }
  if (!name) {
    alert('الاسم مطلوب يا نجم');
    return;
  }

  currentUser = {
    name: name,
    phone: '+20' + document.getElementById('phone').value.trim()
  };
  localStorage.setItem('masrchat_user', JSON.stringify(currentUser));

  updateGreeting();
  document.getElementById('settings-name').textContent = name;
  document.getElementById('settings-phone').textContent = currentUser.phone;
  document.getElementById('settings-avatar').textContent = name[0];

  showScreen('home');
}

function logout() {
  localStorage.removeItem('masrchat_user');
  currentUser = null;
  showScreen('login');
}

// ===== التبويبات =====
function switchTab(tab) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
  document.getElementById('tab-' + tab).classList.add('active');
}

// ===== المحادثات =====
function renderChats() {
  const list = document.getElementById('chats-list');
  list.innerHTML = demoUsers.map(u => `
    <div class="chat-item" onclick="openChat(${u.id})">
      <div class="avatar">${u.name[0]}</div>
      <div class="info">
        <strong>${u.name}</strong>
        <p>${u.last}</p>
      </div>
      <div class="time">${u.time}</div>
      ${u.online ? '<div class="online-dot"></div>' : ''}
    </div>
  `).join('');
}

function openChat(id) {
  const user = demoUsers.find(u => u.id === id);
  if (!user) return;
  currentChat = user;

  document.getElementById('chat-name').textContent = user.name;
  document.getElementById('chat-avatar').textContent = user.name[0];
  document.getElementById('chat-status').textContent = user.online ? 'أونلاين' : 'آخر ظهور قريب';

  if (!messages[id]) {
    messages[id] = [
      { text: 'السلام عليكم', me: false, time: '10:28' },
      { text: 'وعليكم السلام يا نجم', me: true, time: '10:29', status: 'read' },
      { text: user.last, me: false, time: user.time },
    ];
  }

  renderMessages(id);
  showScreen('chat');
}

function renderMessages(chatId) {
  const box = document.getElementById('messages');
  const msgs = messages[chatId] || [];
  box.innerHTML = msgs.map(m => `
    <div class="bubble ${m.me ? 'me' : 'other'}">
      ${m.text}
      <div class="meta">
        ${m.time}
        ${m.me ? (m.status === 'read' ? ' ✓✓' : ' ✓') : ''}
      </div>
    </div>
  `).join('');
  box.scrollTop = box.scrollHeight;
}

function sendMsg() {
  const input = document.getElementById('msg-input');
  const text = input.value.trim();
  if (!text || !currentChat) return;

  if (!messages[currentChat.id]) messages[currentChat.id] = [];
  const now = new Date();
  const time = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0');

  messages[currentChat.id].push({ text, me: true, time, status: 'sent' });
  input.value = '';
  renderMessages(currentChat.id);

  // رد تلقائي بعد ثانية
  setTimeout(() => {
    const replies = [
      'وصلت يا معلم 😂',
      'تمام يا نجم',
      'ابعت فويس',
      'عامل إيه؟',
      'يلا نتكلم',
      'هكلمك دلوقتي',
    ];
    const reply = replies[Math.floor(Math.random() * replies.length)];
    messages[currentChat.id].push({
      text: reply,
      me: false,
      time: new Date().getHours().toString().padStart(2,'0') + ':' +
            new Date().getMinutes().toString().padStart(2,'0')
    });
    // تحديث حالة الرسالة
    const lastMe = messages[currentChat.id].filter(m => m.me).pop();
    if (lastMe) lastMe.status = 'read';
    renderMessages(currentChat.id);
  }, 1200);
}

function goHome() {
  showScreen('home');
  renderChats();
}

// ===== البحث =====
function showSearch() {
  document.getElementById('search-input').value = '';
  document.getElementById('search-results').innerHTML = `
    <div class="empty" style="padding-top:60px">
      <p>اكتب اسم أو رقم</p>
      <small>دور على صحابك</small>
    </div>`;
  showScreen('search');
  document.getElementById('search-input').focus();
}

function doSearch() {
  const q = document.getElementById('search-input').value.trim().toLowerCase();
  const results = document.getElementById('search-results');
  if (!q) {
    results.innerHTML = `<div class="empty" style="padding-top:60px"><p>اكتب اسم أو رقم</p></div>`;
    return;
  }
  const found = demoUsers.filter(u =>
    u.name.toLowerCase().includes(q) || u.phone.includes(q)
  );
  if (found.length === 0) {
    results.innerHTML = `<div class="empty" style="padding-top:60px"><p>مفيش نتائج</p><small>جرب اسم تاني</small></div>`;
    return;
  }
  results.innerHTML = found.map(u => `
    <div class="search-item" onclick="openChat(${u.id})">
      <div class="avatar">${u.name[0]}</div>
      <div class="info">
        <strong>${u.name}</strong>
        <p>${u.phone}</p>
      </div>
      ${u.online ? '<div class="online-dot"></div>' : ''}
    </div>
  `).join('');
}

// ===== الإعدادات =====
function showSettings() {
  if (currentUser) {
    document.getElementById('settings-name').textContent = currentUser.name;
    document.getElementById('settings-phone').textContent = currentUser.phone;
    document.getElementById('settings-avatar').textContent = currentUser.name[0];
  }
  showScreen('settings');
}

function toggleDark() {
  document.body.classList.toggle('dark', document.getElementById('dark-toggle').checked);
}

function toggleEmoji() {
  const input = document.getElementById('msg-input');
  const emojis = ['😊','😂','❤️','🔥','👍','🙏','✨','🇪🇬','💪','🎉'];
  input.value += emojis[Math.floor(Math.random() * emojis.length)];
  input.focus();
}
