package com.eray.launcher;
import android.app.*; import android.os.*; import android.graphics.Color; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b);
  LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(40,60,40,40); l.setBackgroundColor(Color.rgb(13,15,20));
  TextView t=new TextView(this); t.setText("⛏️ ErayLauncher\n\nMinecraft Launcher"); t.setTextColor(Color.WHITE); t.setTextSize(28); l.addView(t);
  Spinner s=new Spinner(this); String[] v={"1.21.11","1.21.8","1.20.1"}; s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,v)); l.addView(s);
  Button p=new Button(this); p.setText("OYNA"); l.addView(p);
  TextView info=new TextView(this); info.setText("\nHazır — Android launcher arayüzü."); info.setTextColor(Color.LTGRAY); l.addView(info); setContentView(l);
 }
}
