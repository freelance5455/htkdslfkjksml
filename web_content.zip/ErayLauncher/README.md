# ErayLauncher
Windows + Android için Minecraft launcher başlangıç projesi.

## Windows
`windows/index.html` arayüz prototipidir. Gerçek Windows `.exe` üretmek için Node.js + Electron gerekir:
1. Node.js LTS kur.
2. `cd windows`
3. `npm install`
4. `npm run build`

## Android
`android` klasörü Android Studio/Gradle ile gerçek APK'ya dönüştürülebilecek başlangıç yapısını içerir.

> Not: Minecraft'ın resmi hesap doğrulaması, oyun dosyalarının lisanslı edinimi ve gerçek oyun başlatma kodu ayrıca entegre edilmelidir. Bu proje korsan/hesap atlatma işlevi içermez.
