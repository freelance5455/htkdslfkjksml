Dokan Billing Android App

Open this folder in Android Studio and build the debug APK:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

The app is a local/offline WebView app. Customer and bill data are stored locally in the app/browser storage.
The current first version includes customer save/search, new bill, bill history, paid/due and sales total.
