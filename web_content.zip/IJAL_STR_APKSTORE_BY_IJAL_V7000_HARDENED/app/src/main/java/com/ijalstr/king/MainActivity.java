package com.ijalstr.king;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 7001;
    private static final int CAMERA_PERMISSION = 7002;
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private Uri cameraUri;
    private WebChromeClient.FileChooserParams pendingParams;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
        });
        webView.setWebChromeClient(new PickerChromeClient());
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, "Tidak ada aplikasi untuk membuka file.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private class PickerChromeClient extends WebChromeClient {
        @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (uploadCallback != null) uploadCallback.onReceiveValue(null);
            uploadCallback = callback;
            pendingParams = params;

            // <input type="file" capture> dari halaman Profil: buka kamera Android langsung.
            if (params != null && params.isCaptureEnabled() && wantsImage(params)) {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
                } else {
                    openCamera();
                }
                return true;
            }
            openDocumentChooser(params);
            return true;
        }
    }

    private boolean wantsImage(WebChromeClient.FileChooserParams p) {
        String[] types = p == null ? null : p.getAcceptTypes();
        if (types == null || types.length == 0) return true;
        for (String raw : types) {
            if (raw == null || raw.trim().isEmpty() || raw.trim().equals("*/*")) return true;
            for (String t : raw.split(",")) {
                String x = t.trim().toLowerCase(Locale.US);
                if (x.startsWith("image/")) return true;
            }
        }
        return false;
    }

    private String[] pickMimeTypes(WebChromeClient.FileChooserParams params) {
        ArrayList<String> out = new ArrayList<>();
        String[] types = params == null ? null : params.getAcceptTypes();
        if (types != null) {
            for (String raw : types) {
                if (raw == null) continue;
                for (String t : raw.split(",")) {
                    String x = t.trim();
                    if (x.isEmpty() || x.equals("*/*")) continue;
                    if (x.startsWith(".")) continue;
                    if (x.contains("/")) out.add(x);
                }
            }
        }
        if (out.isEmpty()) return new String[]{"*/*"};
        return out.toArray(new String[0]);
    }

    private String pickMime(WebChromeClient.FileChooserParams params) {
        String[] mimes = pickMimeTypes(params);
        return mimes.length == 0 ? "*/*" : mimes[0];
    }

    private boolean wantsMultiple(WebChromeClient.FileChooserParams params) {
        return params != null && params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE;
    }

    private void openDocumentChooser(WebChromeClient.FileChooserParams params) {
        final String mime = pickMime(params);
        final String[] mimes = pickMimeTypes(params);
        final boolean multiple = wantsMultiple(params);

        // Android SAF: ACTION_OPEN_DOCUMENT is the primary route because it exposes the
        // real Files/Downloads/Gallery providers and can retain read permission.
        try {
            Intent open = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            open.addCategory(Intent.CATEGORY_OPENABLE);
            open.setType(mime);
            if (mimes.length > 1) open.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
            open.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
            open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(Intent.createChooser(open, "PILIH FILE DARI HP"), FILE_CHOOSER);
            return;
        } catch (ActivityNotFoundException | SecurityException ignored) { }

        // Vendor fallback (some older file managers prefer GET_CONTENT).
        try {
            Intent get = new Intent(Intent.ACTION_GET_CONTENT);
            get.addCategory(Intent.CATEGORY_OPENABLE);
            get.setType(mime);
            if (mimes.length > 1) get.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
            get.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
            startActivityForResult(Intent.createChooser(get, "PILIH FILE DARI HP"), FILE_CHOOSER);
            return;
        } catch (Exception ex) {
            finishUpload(null);
            Toast.makeText(this, "File Manager Android tidak tersedia.", Toast.LENGTH_SHORT).show();
        }
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            finishUpload(null);
            Toast.makeText(this, "Kamera tidak tersedia.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "camera");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("mkdir");
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File photo = new File(dir, "IJAL_" + stamp + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, "com.ijalstr.king.fileprovider", photo);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, FILE_CHOOSER);
        } catch (Exception e) {
            Toast.makeText(this, "Kamera gagal dibuka. Memakai File Manager.", Toast.LENGTH_SHORT).show();
            cameraUri = null;
            openDocumentChooser(pendingParams);
        }
    }

    private void finishUpload(Uri uri) {
        if (uploadCallback == null) return;
        uploadCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
        uploadCallback = null;
        cameraUri = null;
        pendingParams = null;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                openDocumentChooser(pendingParams);
                Toast.makeText(this, "Izin kamera ditolak, membuka File Manager.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER) return;
        if (resultCode != RESULT_OK) { finishUpload(null); return; }

        if (cameraUri != null) { finishUpload(cameraUri); return; }
        if (data == null) { finishUpload(null); return; }

        ArrayList<Uri> results = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) { persistReadPermission(u); results.add(u); }
            }
        } else if (data.getData() != null) {
            Uri u = data.getData();
            persistReadPermission(u);
            results.add(u);
        }

        if (results.isEmpty()) { finishUpload(null); return; }
        uploadCallback.onReceiveValue(results.toArray(new Uri[0]));
        uploadCallback = null;
        cameraUri = null;
        pendingParams = null;
    }

    private void persistReadPermission(Uri uri) {
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
    }

    @Override protected void onDestroy() {
        if (uploadCallback != null) { uploadCallback.onReceiveValue(null); uploadCallback = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
