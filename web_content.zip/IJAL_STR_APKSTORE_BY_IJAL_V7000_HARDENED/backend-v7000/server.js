const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {WebSocketServer}=require('ws');
const PORT=Number(process.env.PORT||3000);
const HOST=process.env.HOST||'0.0.0.0';
const UPLOAD_DIR=path.join(__dirname,'uploads');
fs.mkdirSync(UPLOAD_DIR,{recursive:true});
const peers=new Set();
const transfers=new Map();
const MAX_FILE=25*1024*1024;
function cleanName(name){return String(name||'file').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,140)||'file';}
function send(sock,obj){if(sock.readyState===1)sock.send(JSON.stringify(obj));}
function broadcast(obj,except){const s=JSON.stringify(obj);for(const p of peers){if(p!==except&&p.readyState===1)p.send(s);}}
function httpServer(){return http.createServer((req,res)=>{
  if(req.url==='/'||req.url==='/status'){res.writeHead(200,{'Content-Type':'application/json; charset=utf-8'});return res.end(JSON.stringify({ok:true,name:'APKStore by ijal V7000 Bridge',version:'V7000',port:PORT}));}
  if(req.url.startsWith('/uploads/')){const n=path.basename(decodeURIComponent(req.url.slice('/uploads/'.length)));const f=path.join(UPLOAD_DIR,n);if(!f.startsWith(UPLOAD_DIR+path.sep)||!fs.existsSync(f)){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Disposition':'attachment; filename="'+n.replace(/"/g,'')+'"'});return fs.createReadStream(f).pipe(res);}
  res.writeHead(404,{'Content-Type':'text/plain'});res.end('Not found');
});}
const server=httpServer();
const wss=new WebSocketServer({server});
wss.on('connection',socket=>{peers.add(socket);send(socket,{type:'hello',version:'V7000'});broadcast({type:'online',count:peers.size});
 socket.on('message',raw=>{let m;try{m=JSON.parse(raw.toString())}catch{return;}
  if(m.type==='hello'){socket.uid=String(m.uid||'');socket.name=String(m.name||'User').slice(0,80);return;}
  if(m.type==='chat'){broadcast(m);return;}
  if(m.type==='file-start'){const size=Number(m.size||0);if(!m.fileId||!Number.isFinite(size)||size<0||size>MAX_FILE){send(socket,{type:'file-error',fileId:m.fileId||'',message:'File melebihi batas 25 MB atau metadata tidak valid.'});return;}transfers.set(String(m.fileId),{uid:String(m.uid||socket.uid||''),name:String(m.name||socket.name||'User'),fileName:cleanName(m.name),size,chunks:[],mime:String(m.mime||'application/octet-stream'),socket});return;}
  if(m.type==='file-chunk'){const t=transfers.get(String(m.fileId));if(!t)return;const b=Buffer.from(String(m.data||''),'base64');const current=t.chunks.reduce((n,x)=>n+x.length,0);if(current+b.length>MAX_FILE){transfers.delete(String(m.fileId));send(socket,{type:'file-error',fileId:m.fileId,message:'Ukuran file melampaui batas server.'});return;}t.chunks.push(b);return;}
  if(m.type==='file-end'){const t=transfers.get(String(m.fileId));if(!t)return;const data=Buffer.concat(t.chunks);if(data.length!==t.size){send(socket,{type:'file-error',fileId:m.fileId,message:'Transfer tidak lengkap.'});transfers.delete(String(m.fileId));return;}const stored=String(m.fileId)+'-'+Date.now()+'-'+t.fileName;const out=path.join(UPLOAD_DIR,stored);fs.writeFileSync(out,data);transfers.delete(String(m.fileId));const packet={type:'chat-file',kind:'file',uid:t.uid,name:t.name,text:'📎 '+t.fileName,time:new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}),fileId:String(m.fileId),fileName:t.fileName,fileSize:data.length,fileType:t.mime,path:'/uploads/'+stored};broadcast(packet);send(socket,{type:'file-ready',fileId:String(m.fileId),path:'/uploads/'+stored});return;}
 });
 socket.on('close',()=>{peers.delete(socket);for(const [id,t] of transfers){if(t.socket===socket)transfers.delete(id)}broadcast({type:'online',count:peers.size});});
});
server.listen(PORT,HOST,()=>console.log('APKStore by ijal V7000 Bridge: ws://'+HOST+':'+PORT));