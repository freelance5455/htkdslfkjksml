APKStore by ijal V7000 Bridge

1. npm install
2. npm start

WebSocket: ws://0.0.0.0:3000 (gunakan IP LAN perangkat yang menjalankan server dari HP lain)
HTTP status: http://HOST:3000/status
File upload/download: http://HOST:3000/uploads/<nama-file>

Batas file transfer: 25 MB per file.
Protocol: file-start -> file-chunk* -> file-end.
