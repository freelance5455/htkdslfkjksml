# Micon Android + AI Wish Estimator

Starter project using Kotlin, Jetpack Compose, Firebase Authentication, Cloud Firestore, Firebase callable Cloud Functions, and Gemini API.

## What it does
- Native Android profile setup (name, age, location)
- Email/password sign-up and sign-in via Firebase Authentication
- Wishes stored under `users/{uid}/wishes/{wishId}`
- A callable Cloud Function verifies authentication and checks that a wish belongs to the caller
- AI returns `likely`, `uncertain`, or `unlikely`, plus assessment confidence and a short rationale
- AI estimate stored in `aiEstimate`; actual wish `status` remains `Pending`
- Firestore client rules block client writes to AI estimates and status updates

## 1. Firebase project setup
1. Install Android Studio, Node.js 22, and Firebase CLI.
2. Create a Firebase project at https://console.firebase.google.com/
3. Add Android app package `com.micon.app`; download `google-services.json` to `app/google-services.json`.
4. Enable Authentication > Sign-in method > Email/Password.
5. Create a Cloud Firestore database.
6. Install Firebase CLI and sign in: `npm install -g firebase-tools` then `firebase login`.
7. From this project folder, select your project: `firebase use --add`.
8. Configure billing as required for Cloud Functions deployment in your Firebase project.
9. Add the Gemini API key as a server secret:
   `firebase functions:secrets:set GEMINI_API_KEY`
   Paste the key when prompted. Never commit it to source control or put it in Android resources.
10. Deploy rules and function:
    `firebase deploy --only firestore:rules,functions`
11. Open the project in Android Studio, sync Gradle, then run on an emulator/device.

## 2. Data model
Profile: `users/{uid}` -> `{ name, age, location, createdAt }`
Wish: `users/{uid}/wishes/{wishId}` -> `{ title, details, status, createdAt, aiEstimate }`

Example `aiEstimate`:
- `outcome`: `likely | uncertain | unlikely`
- `confidence`: integer 0–100 describing the model's confidence in its assessment, NOT the probability the wish will come true
- `rationale`: short explanation
- `model`, `estimatedAt`, `disclaimer`

## 3. Important semantics
AI estimates feasibility from the wish text. They do not prove that the wish has come true. The actual wish status is intentionally separate and stays `Pending` until a separately designed trusted fulfillment process is implemented. The AI output is fallible and may be biased; avoid using it for high-stakes decisions.

## 4. Security notes
- Firebase Authentication handles password storage; app code does not save passwords.
- The callable function requires a signed-in Firebase user and only reads wishes from that user's UID path.
- The model receives only wish title/details, not profile name, age, location, email, or UID.
- Client Firestore rules deny all wish updates/deletes, so the client cannot forge the AI estimate. Cloud Functions use Admin SDK and bypass Firestore rules, so keep the function's validation and authorization checks.
- Add App Check enforcement, email verification, password reset, abuse/rate limiting, budget alerts, privacy policy, account deletion, and automated rules/function tests before public release.
- The project hasn't been built against your Firebase project because `google-services.json`, Firebase project ID, and Gemini key must come from you.

## 5. Test
1. Register two different accounts.
2. Create one wish in each account.
3. Tap “Estimate with AI” for a wish.
4. Confirm that the estimate appears only for the owner.
5. Try calling the function with another user's wish ID; it should return not-found.
6. Confirm client writes to `aiEstimate` or `status` are denied by Firestore rules.
