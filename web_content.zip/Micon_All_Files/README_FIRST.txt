MICON — ALL PROJECT FILES

Contents
--------
1. micon_wish_app.html
   Original standalone web prototype. Open it in a browser to try the HTML app.

2. MiconAIAndroid/
   Native Android starter source:
   - Kotlin + Jetpack Compose UI
   - Firebase Authentication sign-up/sign-in
   - Cloud Firestore wish storage
   - Cloud Function AI estimator (Gemini API)
   - Firestore security rules
   - Setup and deployment instructions in MiconAIAndroid/README.md

3. MiconAIAndroid.zip
   ZIP copy of the Android + Firebase AI estimator project.

4. MiconAndroidStarter.zip
   Earlier Android starter archive, included as a reference.

IMPORTANT SETUP NOTES
---------------------
- The HTML prototype works locally in a browser, but its demo profile is not secure production authentication.
- The Android app requires your own Firebase project and app/google-services.json.
- The AI backend requires deployment and a server-side GEMINI_API_KEY secret.
- Never put API keys or real passwords in source code.
- AI outcomes are estimates, not confirmation that a wish came true.
- These source files have not been configured with your private Firebase project or tested on your device.

Start here:
1. Open micon_wish_app.html for the browser prototype.
2. For Android, read MiconAIAndroid/README.md and follow its Firebase setup instructions.
