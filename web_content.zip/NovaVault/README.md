# NOVA VAULT

Offline private gallery for Android. Package `com.novavault.app`.

Open this folder in Android Studio (AGP 8.2 / Gradle 8.2). Let Studio install SDK platform 34. `minSdk` and `targetSdk` are 30, aimed at Android 11 devices such as the OnePlus 6.

## What it does

- Empty vault. A single MediaStore grid lists photos and videos together. Only the rows you select are imported.
- Storage mode is either a **private copy** in app-internal storage (default) or a **content URI reference**. Remove from vault never deletes the original.
- Unlimited security questions. Each one stores PBKDF2-HMAC-SHA256 (80k) and a unique salt. Plaintext answers are not kept.
- Per question: optional in-app face shortcut, optional fingerprint shortcut (`BiometricPrompt`, fresh prompt every time).
- If both shortcuts are on, the policy is face alone, fingerprint alone, or both. The typed answer always works.
- Leaving the app (when the lock is on) returns the sequence to question 1.
- English and Persian, with RTL when Persian is selected.
- `android:allowBackup="false"`. No `INTERNET` permission.

## Face recognition

Enrollment and verify run inside the app through CameraX. They do **not** call Android Face Unlock. The current embedder is a lightweight on-device geometric template (24×24 normalized face crop, cosine + mean absolute distance), encrypted with an Android Keystore AES-GCM key. Replace `FaceGeometry.embed` with a bundled TFLite model later; the template file already stores the vector length.

## Audio

`app/src/main/res/raw/` contains real WAV assets:

- `sfx_correct.wav`
- `sfx_incorrect.wav`
- `sfx_success.wav`
- `music_suspense.wav` (looped score on the access sequence)

Toggle them in Settings.

## Build

```
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest
```
