# Release minify is off so a first Android Studio build does not depend on keep rules.
# If you enable R8 later, Room/KSP generated code is kept by the default Android rules.
