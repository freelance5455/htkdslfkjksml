package com.novavault.app.domain.face

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FaceGeometryTest {
    @Test
    fun flatFrameIsRejected() {
        val n = 80 * 80
        val luma = IntArray(n) { 40 }
        val cb = IntArray(n) { 128 }
        val cr = IntArray(n) { 128 }
        assertNull(FaceGeometry.embed(luma, cb, cr, 80, 80))
    }

    @Test
    fun skinRegionWithFeaturesEmbeds() {
        val w = 80
        val h = 100
        val luma = IntArray(w * h) { 30 }
        val cb = IntArray(w * h) { 128 }
        val cr = IntArray(w * h) { 128 }
        for (y in 20 until 80) {
            for (x in 18 until 62) {
                val i = y * w + x
                luma[i] = 170
                cb[i] = 105
                cr[i] = 155
            }
        }
        // Dark eyes so the crop is not a flat wall.
        for (y in 36 until 42) {
            for (x in 28 until 34) luma[y * w + x] = 25
            for (x in 46 until 52) luma[y * w + x] = 22
        }
        for (y in 58 until 64) {
            for (x in 34 until 48) luma[y * w + x] = 70
        }
        val embedding = FaceGeometry.embed(luma, cb, cr, w, h)
        assertNotNull(embedding)
        assertEqualsSize(FaceGeometry.SIZE * FaceGeometry.SIZE, embedding!!.size)
        assertTrue(FaceGeometry.cosine(embedding, embedding) > 0.99f)
        assertTrue(FaceGeometry.matches(embedding, embedding))
    }

    @Test
    fun differentTemplatesDoNotMatchNoise() {
        val a = FloatArray(FaceGeometry.SIZE * FaceGeometry.SIZE) { i -> (i % 7) / 7f }
        val b = FloatArray(a.size) { i -> ((i * 3) % 11) / 11f }
        assertTrue(FaceGeometry.cosine(a, b) < FaceGeometry.MATCH_COSINE || FaceGeometry.meanAbs(a, b) > FaceGeometry.MATCH_MAD)
    }

    private fun assertEqualsSize(expected: Int, actual: Int) {
        org.junit.Assert.assertEquals(expected, actual)
    }
}
