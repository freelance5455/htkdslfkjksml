package com.novavault.app.domain.auth

import com.novavault.app.domain.model.BiometricPolicy
import com.novavault.app.domain.model.SecurityQuestion
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BiometricGateTest {
    @Test
    fun textOnlyNeverPassesViaShortcut() {
        val question = sample(face = false, finger = false, BiometricPolicy.BOTH_REQUIRED)
        assertFalse(BiometricGate.shortcutGranted(question, faceOk = true, fingerOk = true))
    }

    @Test
    fun faceAlone() {
        val question = sample(face = true, finger = true, BiometricPolicy.FACE_ALONE)
        assertTrue(BiometricGate.shortcutGranted(question, faceOk = true, fingerOk = false))
        assertFalse(BiometricGate.shortcutGranted(question, faceOk = false, fingerOk = true))
    }

    @Test
    fun fingerprintAlone() {
        val question = sample(face = true, finger = true, BiometricPolicy.FINGERPRINT_ALONE)
        assertTrue(BiometricGate.shortcutGranted(question, faceOk = false, fingerOk = true))
        assertFalse(BiometricGate.shortcutGranted(question, faceOk = true, fingerOk = false))
    }

    @Test
    fun bothRequired() {
        val question = sample(face = true, finger = true, BiometricPolicy.BOTH_REQUIRED)
        assertFalse(BiometricGate.shortcutGranted(question, faceOk = true, fingerOk = false))
        assertFalse(BiometricGate.shortcutGranted(question, faceOk = false, fingerOk = true))
        assertTrue(BiometricGate.shortcutGranted(question, faceOk = true, fingerOk = true))
    }

    @Test
    fun singleFactorIgnoresPolicy() {
        val face = sample(face = true, finger = false, BiometricPolicy.BOTH_REQUIRED)
        assertTrue(BiometricGate.shortcutGranted(face, faceOk = true, fingerOk = false))
        val finger = sample(face = false, finger = true, BiometricPolicy.FACE_ALONE)
        assertTrue(BiometricGate.shortcutGranted(finger, faceOk = false, fingerOk = true))
    }

    private fun sample(face: Boolean, finger: Boolean, policy: BiometricPolicy) = SecurityQuestion(
        id = 1,
        prompt = "q",
        answerHash = "",
        salt = "",
        iterations = 1,
        faceEnabled = face,
        fingerprintEnabled = finger,
        policy = policy,
        sortOrder = 0,
    )
}
