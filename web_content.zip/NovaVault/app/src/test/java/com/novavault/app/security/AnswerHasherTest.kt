package com.novavault.app.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnswerHasherTest {
    @Test
    fun sameAnswerVerifies() {
        val salt = AnswerHasher.newSalt()
        val hash = AnswerHasher.hash("Tehran Noon", salt)
        assertTrue(AnswerHasher.verify("  tehran   noon ", salt, hash, AnswerHasher.ITERATIONS))
    }

    @Test
    fun wrongAnswerFails() {
        val salt = AnswerHasher.newSalt()
        val hash = AnswerHasher.hash("orbit", salt)
        assertFalse(AnswerHasher.verify("orchid", salt, hash, AnswerHasher.ITERATIONS))
    }

    @Test
    fun saltsDiffer() {
        val a = AnswerHasher.encode(AnswerHasher.newSalt())
        val b = AnswerHasher.encode(AnswerHasher.newSalt())
        assertNotEquals(a, b)
    }

    @Test
    fun normalizeCollapsesWhitespace() {
        assertEquals("nova vault", AnswerHasher.normalize("  Nova   VAULT \n"))
    }
}
