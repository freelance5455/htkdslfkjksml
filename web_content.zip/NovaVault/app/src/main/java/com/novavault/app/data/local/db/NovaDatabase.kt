package com.novavault.app.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [QuestionEntity::class, MediaItemEntity::class, SettingsEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class NovaDatabase : RoomDatabase() {
    abstract fun questions(): QuestionDao
    abstract fun media(): MediaDao
    abstract fun settings(): SettingsDao

    companion object {
        fun create(context: Context): NovaDatabase {
            return Room.databaseBuilder(context, NovaDatabase::class.java, "nova_vault.db")
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        db.execSQL(
                            """
                            INSERT INTO settings (
                                id, storageMode, audioEnabled, language, appLockEnabled, setupComplete, faceEnrolled
                            ) VALUES (1, 'PRIVATE_COPY', 1, 'en', 1, 0, 0)
                            """.trimIndent(),
                        )
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}
