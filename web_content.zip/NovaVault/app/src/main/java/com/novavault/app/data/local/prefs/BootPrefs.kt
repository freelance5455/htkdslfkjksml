package com.novavault.app.data.local.prefs

import android.content.Context

/** Synchronous locale cache so [android.app.Activity.attachBaseContext] does not wait on DataStore. */
object BootPrefs {
    private const val NAME = "nova_boot"

    fun language(context: Context): String {
        return context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(KEY_LANGUAGE, "en") ?: "en"
    }

    fun setLanguage(context: Context, code: String) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANGUAGE, code)
            .commit()
    }

    fun appLock(context: Context): Boolean {
        return context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_LOCK, true)
    }

    fun setAppLock(context: Context, enabled: Boolean) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LOCK, enabled)
            .commit()
    }

    private const val KEY_LANGUAGE = "language"
    private const val KEY_LOCK = "app_lock"
}
