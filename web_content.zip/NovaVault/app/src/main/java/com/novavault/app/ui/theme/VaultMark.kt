package com.novavault.app.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.min

@Composable
fun VaultMark(modifier: Modifier, color: Color = Accent) {
    val direction = LocalLayoutDirection.current
    Canvas(modifier) {
        val s = min(size.width, size.height)
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = s * 0.42f
        fun point(angleDeg: Float): Offset {
            val rad = Math.toRadians(angleDeg.toDouble())
            return Offset(cx + r * kotlin.math.cos(rad).toFloat(), cy + r * kotlin.math.sin(rad).toFloat())
        }
        val hex = Path()
        val start = -90f
        val first = point(start)
        hex.moveTo(first.x, first.y)
        for (i in 1..5) hex.lineTo(point(start + i * 60f).x, point(start + i * 60f).y)
        hex.close()
        drawPath(hex, color = color, style = Stroke(width = s * 0.045f))
        val inner = s * 0.16f
        drawCircle(color = color, radius = inner, center = Offset(cx, cy))
        val notch = if (direction == LayoutDirection.Rtl) -1f else 1f
        drawLine(
            color = NavyDeep,
            start = Offset(cx - inner * 0.28f * notch, cy - inner * 0.15f),
            end = Offset(cx - inner * 0.28f * notch, cy + inner * 0.45f),
            strokeWidth = s * 0.035f,
        )
    }
}
