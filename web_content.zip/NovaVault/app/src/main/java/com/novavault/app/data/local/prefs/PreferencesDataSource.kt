package com.novavault.app.data.local.prefs

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.novavault.app.domain.model.AppLanguage
import com.novavault.app.domain.model.StorageMode
import com.novavault.app.domain.model.VaultPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.novaDataStore by preferencesDataStore(name = "nova_vault_prefs")

/**
 * DataStore mirror of vault preferences. Room remains the source of truth;
 * this store is written on every settings change so preferences survive as a
 * second offline copy and can be read without opening the database.
 */
class PreferencesDataSource(private val context: Context) {
    private val storageMode = stringPreferencesKey("storage_mode")
    private val audio = booleanPreferencesKey("audio_enabled")
    private val language = stringPreferencesKey("language")
    private val appLock = booleanPreferencesKey("app_lock")
    private val setup = booleanPreferencesKey("setup_complete")
    private val face = booleanPreferencesKey("face_enrolled")

    val flow: Flow<VaultPreferences> = context.novaDataStore.data.map { prefs -> prefs.toModel() }

    suspend fun write(preferences: VaultPreferences) {
        context.novaDataStore.edit { prefs ->
            prefs[storageMode] = preferences.storageMode.name
            prefs[audio] = preferences.audioEnabled
            prefs[language] = preferences.language.code
            prefs[appLock] = preferences.appLockEnabled
            prefs[setup] = preferences.setupComplete
            prefs[face] = preferences.faceEnrolled
        }
    }

    private fun Preferences.toModel(): VaultPreferences {
        val mode = this[storageMode]?.let { runCatching { StorageMode.valueOf(it) }.getOrNull() }
            ?: StorageMode.PRIVATE_COPY
        return VaultPreferences(
            storageMode = mode,
            audioEnabled = this[audio] ?: true,
            language = AppLanguage.from(this[language]),
            appLockEnabled = this[appLock] ?: true,
            setupComplete = this[setup] ?: false,
            faceEnrolled = this[face] ?: false,
        )
    }
}
