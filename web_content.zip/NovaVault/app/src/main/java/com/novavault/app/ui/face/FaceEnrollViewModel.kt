package com.novavault.app.ui.face

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novavault.app.data.face.FaceTemplateStore
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.face.FaceGeometry
import com.novavault.app.domain.face.FaceTemplate
import com.novavault.app.domain.repository.SettingsRepository
import com.novavault.app.ui.auth.FaceHint
import com.novavault.app.ui.gallery.simpleFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class EnrollUi(
    val samples: Int = 0,
    val hint: FaceHint = FaceHint.SEARCHING,
    val saved: Boolean = false,
    val failed: Boolean = false,
)

class FaceEnrollViewModel(
    private val faceStore: FaceTemplateStore,
    private val settings: SettingsRepository,
) : ViewModel() {
    private val _ui = MutableStateFlow(EnrollUi())
    val ui: StateFlow<EnrollUi> = _ui.asStateFlow()
    private val samples = ArrayList<FloatArray>()
    private var last: FloatArray? = null
    private var stable = 0
    private var lastAt = 0L
    private var cooldownUntil = 0L

    fun reset() {
        samples.clear()
        last = null
        stable = 0
        cooldownUntil = 0L
        _ui.value = EnrollUi()
    }

    fun onFrame(embedding: FloatArray?) {
        val state = _ui.value
        if (state.saved) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now < cooldownUntil || now - lastAt < 160L) return
        lastAt = now
        if (embedding == null) {
            stable = 0
            _ui.update { it.copy(hint = FaceHint.NO_FACE, failed = false) }
            return
        }
        val previous = last
        last = embedding
        stable = if (previous != null && FaceGeometry.cosine(previous, embedding) >= 0.93f) stable + 1 else 0
        if (stable < 2) {
            _ui.update { it.copy(hint = FaceHint.HOLD) }
            return
        }
        if (samples.size >= 3) return
        samples += embedding.copyOf()
        stable = 0
        last = null
        cooldownUntil = now + 800L
        val count = samples.size
        _ui.update { it.copy(samples = count, hint = FaceHint.MATCH, failed = false) }
        if (count == 3) save()
    }

    private fun save() {
        val vector = FaceGeometry.average(samples.toList())
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    faceStore.save(FaceTemplate(FaceGeometry.SIZE, FaceGeometry.SIZE, samples.size, vector))
                }
                settings.update { it.copy(faceEnrolled = true) }
                _ui.update { it.copy(saved = true, hint = FaceHint.MATCH) }
            } catch (_: Exception) {
                samples.clear()
                _ui.update { it.copy(samples = 0, failed = true, hint = FaceHint.NO_FACE) }
            }
        }
    }

    companion object {
        fun factory(container: AppContainer) = simpleFactory {
            FaceEnrollViewModel(container.faceStore, container.settings)
        }
    }
}
