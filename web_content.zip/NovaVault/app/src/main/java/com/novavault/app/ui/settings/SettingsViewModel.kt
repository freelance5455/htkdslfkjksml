package com.novavault.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novavault.app.data.face.FaceTemplateStore
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.AppLanguage
import com.novavault.app.domain.model.SecurityQuestion
import com.novavault.app.domain.model.StorageMode
import com.novavault.app.domain.model.VaultPreferences
import com.novavault.app.domain.repository.MediaRepository
import com.novavault.app.domain.repository.QuestionRepository
import com.novavault.app.domain.repository.SettingsRepository
import com.novavault.app.ui.gallery.simpleFactory
import com.novavault.app.ui.session.VaultAudio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settings: SettingsRepository,
    private val questions: QuestionRepository,
    private val media: MediaRepository,
    private val faceStore: FaceTemplateStore,
    private val audio: VaultAudio,
) : ViewModel() {
    val prefs: StateFlow<VaultPreferences> = settings.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultPreferences())

    val sequence: StateFlow<List<SecurityQuestion>> = questions.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setStorage(mode: StorageMode) = edit { it.copy(storageMode = mode) }

    fun setAudio(enabled: Boolean) {
        audio.enabled = enabled
        if (!enabled) audio.stopAmbience()
        edit { it.copy(audioEnabled = enabled) }
    }

    fun setLanguage(language: AppLanguage, onApplied: () -> Unit) {
        viewModelScope.launch {
            settings.update { it.copy(language = language) }
            onApplied()
        }
    }

    fun setLock(enabled: Boolean) = edit { it.copy(appLockEnabled = enabled) }

    fun move(id: Long, delta: Int) {
        viewModelScope.launch { questions.move(id, delta) }
    }

    fun deleteQuestion(id: Long) {
        viewModelScope.launch { questions.delete(id) }
    }

    fun clearGallery() {
        viewModelScope.launch { media.clear() }
    }

    fun clearFace() {
        viewModelScope.launch(Dispatchers.IO) {
            faceStore.clear()
            settings.update { it.copy(faceEnrolled = false) }
        }
    }

    private fun edit(block: (VaultPreferences) -> VaultPreferences) {
        viewModelScope.launch { settings.update(block) }
    }

    companion object {
        fun factory(container: AppContainer) = simpleFactory {
            SettingsViewModel(
                settings = container.settings,
                questions = container.questions,
                media = container.media,
                faceStore = container.faceStore,
                audio = container.audio,
            )
        }
    }
}
