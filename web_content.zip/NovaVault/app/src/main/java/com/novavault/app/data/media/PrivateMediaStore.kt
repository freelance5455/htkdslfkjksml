package com.novavault.app.data.media

import android.content.ContentResolver
import android.net.Uri
import java.io.File
import java.util.UUID

/** App-private copies. Other apps cannot read [filesDir]/vault_media. */
class PrivateMediaStore(filesDir: File) {
    private val dir = File(filesDir, "vault_media").apply { mkdirs() }

    fun import(resolver: ContentResolver, uri: Uri, displayName: String): File {
        val ext = displayName.substringAfterLast('.', "")
            .lowercase()
            .filter { it.isLetterOrDigit() }
            .take(5)
            .ifBlank { "bin" }
        val file = File(dir, "${UUID.randomUUID()}.$ext")
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "unreadable" }
            file.outputStream().use { output -> input.copyTo(output) }
        }
        if (file.length() <= 0L) {
            file.delete()
            error("empty copy")
        }
        return file
    }

    fun resolve(name: String): File = File(dir, name)

    fun delete(name: String) {
        if (name.isBlank() || name.contains('/') || name.contains('\\')) return
        File(dir, name).delete()
    }
}
