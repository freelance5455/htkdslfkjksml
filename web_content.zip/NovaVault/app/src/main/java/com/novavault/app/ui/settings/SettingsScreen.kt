package com.novavault.app.ui.settings

import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novavault.app.R
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.AppLanguage
import com.novavault.app.domain.model.StorageMode
import com.novavault.app.ui.common.VaultTopBar
import com.novavault.app.ui.theme.Ink
import com.novavault.app.ui.theme.Mist

@Composable
fun SettingsScreen(
    container: AppContainer,
    activity: AppCompatActivity,
    onBack: () -> Unit,
    onEditQuestion: (Long) -> Unit,
    onAddQuestion: () -> Unit,
    onEnrollFace: () -> Unit,
) {
    val vm: SettingsViewModel = viewModel(
        viewModelStoreOwner = activity,
        factory = SettingsViewModel.factory(container),
    )
    val prefs by vm.prefs.collectAsState()
    val questions by vm.sequence.collectAsState()
    var clearGallery by rememberSaveable { mutableStateOf(false) }
    var clearFace by rememberSaveable { mutableStateOf(false) }
    var deleteId by rememberSaveable { mutableStateOf<Long?>(null) }
    var blocked by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        containerColor = Mist,
        topBar = { VaultTopBar(title = stringResource(R.string.settings), onBack = onBack) },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 28.dp),
        ) {
            Section(stringResource(R.string.security_section))
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(stringResource(R.string.app_lock), color = Ink, style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.app_lock_desc), color = Ink.copy(alpha = 0.7f))
                }
                Switch(checked = prefs.appLockEnabled, onCheckedChange = vm::setLock)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.question_count, questions.size),
                    modifier = Modifier.weight(1f),
                    color = Ink,
                )
                TextButton(onClick = onAddQuestion) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Text(stringResource(R.string.add_question))
                }
            }
            if (questions.isEmpty()) {
                Text(
                    stringResource(R.string.no_questions),
                    modifier = Modifier.padding(horizontal = 20.dp),
                    color = Ink.copy(alpha = 0.7f),
                )
            }
            questions.forEachIndexed { index, question ->
                Column(Modifier.fillMaxWidth().clickable { onEditQuestion(question.id) }.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    Text(question.prompt, color = Ink, style = MaterialTheme.typography.titleMedium)
                    Text(shortcutLine(question.faceEnabled, question.fingerprintEnabled), color = Ink.copy(alpha = 0.65f))
                    Row {
                        IconButton(onClick = { vm.move(question.id, -1) }, enabled = index > 0) {
                            Icon(Icons.Filled.ArrowUpward, contentDescription = stringResource(R.string.move_up))
                        }
                        IconButton(onClick = { vm.move(question.id, 1) }, enabled = index < questions.lastIndex) {
                            Icon(Icons.Filled.ArrowDownward, contentDescription = stringResource(R.string.move_down))
                        }
                        IconButton(onClick = {
                            if (prefs.appLockEnabled && questions.size <= 1) blocked = true else deleteId = question.id
                        }) {
                            Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete_question))
                        }
                    }
                }
                HorizontalDivider()
            }
            Section(stringResource(R.string.face_enrollment))
            Text(
                stringResource(if (prefs.faceEnrolled) R.string.face_enrolled else R.string.face_not_enrolled),
                modifier = Modifier.padding(horizontal = 20.dp),
                color = Ink,
            )
            Row(Modifier.padding(horizontal = 12.dp)) {
                TextButton(onClick = onEnrollFace) { Text(stringResource(R.string.enroll_face)) }
                TextButton(onClick = { clearFace = true }, enabled = prefs.faceEnrolled) {
                    Text(stringResource(R.string.clear_face))
                }
            }
            Section(stringResource(R.string.preferences_section))
            Text(stringResource(R.string.storage_mode), modifier = Modifier.padding(horizontal = 20.dp), color = Ink, style = MaterialTheme.typography.titleMedium)
            StorageChoice(stringResource(R.string.storage_private), stringResource(R.string.storage_private_desc), prefs.storageMode == StorageMode.PRIVATE_COPY) {
                vm.setStorage(StorageMode.PRIVATE_COPY)
            }
            StorageChoice(stringResource(R.string.storage_reference), stringResource(R.string.storage_reference_desc), prefs.storageMode == StorageMode.REFERENCE) {
                vm.setStorage(StorageMode.REFERENCE)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(stringResource(R.string.audio), color = Ink, style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.audio_on), color = Ink.copy(alpha = 0.7f))
                }
                Switch(checked = prefs.audioEnabled, onCheckedChange = vm::setAudio)
            }
            Text(stringResource(R.string.language), modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = Ink, style = MaterialTheme.typography.titleMedium)
            StorageChoice(stringResource(R.string.english), null, prefs.language == AppLanguage.EN) {
                vm.setLanguage(AppLanguage.EN) { activity.recreate() }
            }
            StorageChoice(stringResource(R.string.persian), null, prefs.language == AppLanguage.FA) {
                vm.setLanguage(AppLanguage.FA) { activity.recreate() }
            }
            Section(stringResource(R.string.library_section))
            TextButton(onClick = { clearGallery = true }, modifier = Modifier.padding(horizontal = 12.dp)) {
                Text(stringResource(R.string.clear_gallery), color = MaterialTheme.colorScheme.error)
            }
            Text(
                stringResource(R.string.setup_questions_hint),
                modifier = Modifier.padding(horizontal = 20.dp),
                color = Ink.copy(alpha = 0.65f),
            )
        }
    }

    if (clearGallery) {
        Confirm(R.string.clear_gallery, R.string.clear_gallery_confirm, { vm.clearGallery(); clearGallery = false }, { clearGallery = false })
    }
    if (clearFace) {
        Confirm(R.string.clear_face, R.string.clear_face_confirm, { vm.clearFace(); clearFace = false }, { clearFace = false })
    }
    deleteId?.let { id ->
        Confirm(R.string.delete_question, R.string.delete_question_confirm, { vm.deleteQuestion(id); deleteId = null }, { deleteId = null })
    }
    if (blocked) {
        AlertDialog(
            onDismissRequest = { blocked = false },
            title = { Text(stringResource(R.string.delete_question)) },
            text = { Text(stringResource(R.string.arm_requires_question)) },
            confirmButton = { TextButton(onClick = { blocked = false }) { Text(stringResource(R.string.close)) } },
        )
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(16.dp))
    Text(
        text = title,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
        color = Ink,
        style = MaterialTheme.typography.labelLarge,
    )
}

@Composable
private fun StorageChoice(title: String, body: String?, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column {
            Text(title, color = Ink)
            if (body != null) Text(body, color = Ink.copy(alpha = 0.68f), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun Confirm(title: Int, body: Int, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        title = { Text(stringResource(title)) },
        text = { Text(stringResource(body)) },
        confirmButton = { TextButton(onClick = onYes) { Text(stringResource(R.string.remove)) } },
        dismissButton = { TextButton(onClick = onNo) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun shortcutLine(face: Boolean, finger: Boolean): String {
    val text = stringResource(R.string.answer_hint)
    val faceLabel = stringResource(R.string.face_shortcut)
    val fingerLabel = stringResource(R.string.fingerprint_shortcut)
    return listOfNotNull(
        text,
        faceLabel.takeIf { face },
        fingerLabel.takeIf { finger },
    ).joinToString(" · ")
}
