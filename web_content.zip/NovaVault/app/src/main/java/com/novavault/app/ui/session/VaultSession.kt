package com.novavault.app.ui.session

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * In-memory unlock flag. Leaving the app calls [lock], which also bumps [epoch]
 * so the access sequence always restarts at question 1.
 */
class VaultSession {
    private val _locked = MutableStateFlow(true)
    val locked: StateFlow<Boolean> = _locked.asStateFlow()

    private val _epoch = MutableStateFlow(0)
    val epoch: StateFlow<Int> = _epoch.asStateFlow()

    private val _explicit = MutableStateFlow(false)
    val explicit: StateFlow<Boolean> = _explicit.asStateFlow()

    fun lock(explicitly: Boolean = false) {
        if (explicitly) _explicit.value = true
        _locked.value = true
        _epoch.value = _epoch.value + 1
    }

    fun unlock() {
        _locked.value = false
        _explicit.value = false
    }
}
