package com.novavault.app.ui.gallery

import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.novavault.app.R
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.MediaEntry
import com.novavault.app.domain.model.MediaFilter
import com.novavault.app.domain.model.MediaKind
import com.novavault.app.ui.common.VaultTopBar
import com.novavault.app.ui.theme.NavyDeep

@Composable
fun ViewerScreen(
    container: AppContainer,
    activity: AppCompatActivity,
    mediaId: Long,
    filter: MediaFilter,
    onBack: () -> Unit,
) {
    val vm: GalleryViewModel = viewModel(
        viewModelStoreOwner = activity,
        factory = GalleryViewModel.factory(container),
    )
    val items by vm.items.collectAsState()
    val visible = vm.visible(filter, items)
    var confirm by remember { mutableStateOf(false) }
    val start = visible.indexOfFirst { it.id == mediaId }.let { if (it < 0) 0 else it }
    if (visible.isEmpty()) {
        Box(Modifier.fillMaxSize().background(NavyDeep)) {
            VaultTopBar(title = stringResource(R.string.app_name), onBack = onBack)
            Text(
                stringResource(R.string.missing_media),
                color = Color.White,
                modifier = Modifier.padding(top = 80.dp, start = 24.dp),
            )
        }
        return
    }
    val pager = rememberPagerState(initialPage = start, pageCount = { visible.size })
    val current = visible[pager.currentPage.coerceIn(0, visible.lastIndex)]
    Box(Modifier.fillMaxSize().background(NavyDeep)) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            val item = visible[page]
            val uri = playbackUri(container, item)
            if (uri == null) {
                Text(
                    stringResource(R.string.missing_media),
                    color = Color.White,
                    modifier = Modifier.padding(24.dp),
                )
            } else if (item.kind == MediaKind.VIDEO) {
                VaultVideo(uri = uri, play = page == pager.currentPage)
            } else {
                AsyncImage(
                    model = uri,
                    contentDescription = item.displayName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit,
                )
            }
        }
        VaultTopBar(
            title = current.displayName,
            onBack = onBack,
            actions = {
                IconButton(onClick = { confirm = true }) {
                    Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.remove_from_vault))
                }
            },
        )
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(stringResource(R.string.remove_from_vault)) },
            text = { Text(stringResource(R.string.remove_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    vm.remove(current.id)
                    confirm = false
                    if (visible.size <= 1) onBack()
                }) { Text(stringResource(R.string.remove)) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun VaultVideo(uri: Uri, play: Boolean) {
    val context = LocalContext.current
    var error by remember(uri) { mutableStateOf(false) }
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = play
        }
    }
    DisposableEffect(player) {
        val watching = object : Player.Listener {
            override fun onPlayerError(playbackError: PlaybackException) {
                error = true
            }
        }
        player.addListener(watching)
        onDispose {
            player.removeListener(watching)
            player.release()
        }
    }
    DisposableEffect(play) {
        player.playWhenReady = play
        onDispose { }
    }
    if (error) {
        Text(stringResource(R.string.playback_error), color = Color.White, modifier = Modifier.padding(24.dp))
    } else {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = true
                    setShowNextButton(false)
                    setShowPreviousButton(false)
                }
            },
            modifier = Modifier.fillMaxSize(),
        )
    }
}
