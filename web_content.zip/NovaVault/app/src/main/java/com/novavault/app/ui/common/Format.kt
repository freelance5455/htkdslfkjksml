package com.novavault.app.ui.common

import android.content.Context
import android.content.ContextWrapper
import androidx.appcompat.app.AppCompatActivity

fun pad2(value: Int): String = value.coerceAtLeast(0).toString().padStart(2, '0')

fun formatDuration(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    val minutes = total / 60L
    val seconds = total % 60L
    return "%d:%02d".format(minutes, seconds)
}

fun Context.findActivity(): AppCompatActivity {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is AppCompatActivity) return current
        current = current.baseContext
    }
    error("AppCompatActivity was not found")
}
