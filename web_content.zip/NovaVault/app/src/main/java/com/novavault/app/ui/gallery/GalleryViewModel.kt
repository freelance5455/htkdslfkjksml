package com.novavault.app.ui.gallery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.MediaEntry
import com.novavault.app.domain.model.MediaFilter
import com.novavault.app.domain.repository.MediaRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GalleryViewModel(
    private val media: MediaRepository,
) : ViewModel() {
    val items: StateFlow<List<MediaEntry>> = media.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun remove(id: Long) {
        viewModelScope.launch { media.remove(id) }
    }

    fun visible(filter: MediaFilter, source: List<MediaEntry> = items.value): List<MediaEntry> {
        return when (filter) {
            MediaFilter.ALL -> source
            MediaFilter.PHOTOS -> source.filter { it.kind.name == "PHOTO" }
            MediaFilter.VIDEOS -> source.filter { it.kind.name == "VIDEO" }
        }
    }

    companion object {
        fun factory(container: AppContainer) = simpleFactory { GalleryViewModel(container.media) }
    }
}

inline fun <reified T : ViewModel> simpleFactory(crossinline create: () -> T): ViewModelProvider.Factory {
    return object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <VM : ViewModel> create(modelClass: Class<VM>): VM = create() as VM
    }
}
