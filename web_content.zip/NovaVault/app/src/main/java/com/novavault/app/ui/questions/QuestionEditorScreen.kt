package com.novavault.app.ui.questions

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novavault.app.R
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.BiometricPolicy
import com.novavault.app.ui.common.VaultTopBar
import com.novavault.app.ui.theme.Accent
import com.novavault.app.ui.theme.Ink
import com.novavault.app.ui.theme.Mist
import com.novavault.app.ui.theme.NavyDeep

@Composable
fun QuestionEditorScreen(container: AppContainer, questionId: Long, onDone: () -> Unit) {
    val vm: QuestionEditorViewModel = viewModel(
        key = "question-$questionId",
        factory = QuestionEditorViewModel.factory(container, questionId),
    )
    val ui by vm.ui.collectAsState()
    LaunchedEffect(ui.saved) {
        if (ui.saved) onDone()
    }
    Scaffold(
        containerColor = Mist,
        topBar = {
            VaultTopBar(
                title = stringResource(if (questionId > 0) R.string.edit_question else R.string.add_question),
                onBack = onDone,
            )
        },
    ) { padding ->
        if (ui.loading) {
            CircularProgressIndicator(Modifier.padding(padding).padding(24.dp), color = Accent)
            return@Scaffold
        }
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
        ) {
            OutlinedTextField(
                value = ui.prompt,
                onValueChange = vm::setPrompt,
                label = { Text(stringResource(R.string.prompt)) },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = ui.answer,
                onValueChange = vm::setAnswer,
                label = { Text(stringResource(R.string.secret_answer)) },
                modifier = Modifier.fillMaxWidth(),
                supportingText = {
                    if (ui.exists) Text(stringResource(R.string.edit_answer_hint))
                },
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = ui.confirm,
                onValueChange = vm::setConfirm,
                label = { Text(stringResource(R.string.confirm_answer)) },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            LabeledSwitch(stringResource(R.string.face_for_question), ui.face, vm::setFace)
            LabeledSwitch(stringResource(R.string.finger_for_question), ui.fingerprint, vm::setFingerprint)
            if (ui.face && ui.fingerprint) {
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.policy), style = MaterialTheme.typography.titleMedium, color = Ink)
                PolicyRow(stringResource(R.string.policy_face), ui.policy == BiometricPolicy.FACE_ALONE) {
                    vm.setPolicy(BiometricPolicy.FACE_ALONE)
                }
                PolicyRow(stringResource(R.string.policy_finger), ui.policy == BiometricPolicy.FINGERPRINT_ALONE) {
                    vm.setPolicy(BiometricPolicy.FINGERPRINT_ALONE)
                }
                PolicyRow(stringResource(R.string.policy_both), ui.policy == BiometricPolicy.BOTH_REQUIRED) {
                    vm.setPolicy(BiometricPolicy.BOTH_REQUIRED)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.policy_hint), color = Ink.copy(alpha = 0.72f))
            ui.errorRes?.let {
                Spacer(Modifier.height(8.dp))
                Text(stringResource(it), color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = vm::save,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = NavyDeep),
            ) { Text(stringResource(R.string.save)) }
        }
    }
}

@Composable
private fun LabeledSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, modifier = Modifier.weight(1f), color = Ink)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PolicyRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, color = Ink)
    }
}
