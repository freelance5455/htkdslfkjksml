package com.novavault.app.data.local.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface QuestionDao {
    @Query("SELECT * FROM questions ORDER BY sortOrder ASC, id ASC")
    fun observe(): Flow<List<QuestionEntity>>

    @Query("SELECT * FROM questions ORDER BY sortOrder ASC, id ASC")
    suspend fun list(): List<QuestionEntity>

    @Query("SELECT * FROM questions WHERE id = :id")
    suspend fun get(id: Long): QuestionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: QuestionEntity): Long

    @Query("DELETE FROM questions WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE questions SET sortOrder = :order WHERE id = :id")
    suspend fun updateOrder(id: Long, order: Int)

    @Query("SELECT COALESCE(MAX(sortOrder), -1) FROM questions")
    suspend fun maxOrder(): Int
}

@Dao
interface MediaDao {
    @Query("SELECT * FROM media_items ORDER BY addedAt DESC")
    fun observe(): Flow<List<MediaItemEntity>>

    @Query("SELECT * FROM media_items WHERE id = :id")
    suspend fun get(id: Long): MediaItemEntity?

    @Query("SELECT location FROM media_items")
    suspend fun locations(): List<String>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: MediaItemEntity): Long

    @Query("DELETE FROM media_items WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM media_items")
    suspend fun clear()

    @Query("SELECT COUNT(*) FROM media_items")
    suspend fun count(): Int

    @Query("SELECT * FROM media_items")
    suspend fun all(): List<MediaItemEntity>
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings WHERE id = 1")
    fun observe(): Flow<SettingsEntity?>

    @Query("SELECT * FROM settings WHERE id = 1")
    suspend fun get(): SettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SettingsEntity)
}
