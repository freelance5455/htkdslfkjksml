package com.novavault.app.di

import android.content.Context
import com.novavault.app.data.face.FaceTemplateStore
import com.novavault.app.data.local.db.NovaDatabase
import com.novavault.app.data.local.prefs.PreferencesDataSource
import com.novavault.app.data.media.MediaStoreDataSource
import com.novavault.app.data.media.PrivateMediaStore
import com.novavault.app.data.media.Thumbnailer
import com.novavault.app.data.repository.MediaRepositoryImpl
import com.novavault.app.data.repository.QuestionRepositoryImpl
import com.novavault.app.data.repository.SettingsRepositoryImpl
import com.novavault.app.domain.repository.MediaRepository
import com.novavault.app.domain.repository.QuestionRepository
import com.novavault.app.domain.repository.SettingsRepository
import com.novavault.app.security.VaultCrypto
import com.novavault.app.ui.session.VaultAudio
import com.novavault.app.ui.session.VaultSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val database = NovaDatabase.create(appContext)
    private val dataStore = PreferencesDataSource(appContext)
    val crypto = VaultCrypto()
    val faceStore = FaceTemplateStore(appContext.filesDir, crypto)
    val deviceMedia = MediaStoreDataSource(appContext)
    private val privateMedia = PrivateMediaStore(appContext.filesDir)
    val thumbs = Thumbnailer(appContext)

    val questions: QuestionRepository = QuestionRepositoryImpl(database.questions())
    val media: MediaRepository = MediaRepositoryImpl(
        dao = database.media(),
        resolver = appContext.contentResolver,
        privateStore = privateMedia,
        thumbnailer = thumbs,
    )
    val settings: SettingsRepository = SettingsRepositoryImpl(appContext, database.settings(), dataStore)
    val session = VaultSession()
    val audio = VaultAudio(appContext)

    fun thumbFile(name: String) = thumbs.file(name)
    fun privateFile(name: String) = privateMedia.resolve(name)
}
