package com.novavault.app.data.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import com.novavault.app.domain.model.MediaKind
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class Thumbnailer(private val context: Context) {
    private val dir = File(context.filesDir, "vault_thumbs").apply { mkdirs() }

    fun create(source: Uri, kind: MediaKind, privateFile: File?): String? {
        val bitmap = when (kind) {
            MediaKind.VIDEO -> videoFrame(privateFile, source)
            MediaKind.PHOTO -> imageThumb(privateFile, source)
        } ?: return null
        val name = "t_${UUID.randomUUID()}.jpg"
        val out = File(dir, name)
        return try {
            FileOutputStream(out).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            name
        } catch (_: Exception) {
            out.delete()
            null
        } finally {
            bitmap.recycle()
        }
    }

    fun file(name: String): File = File(dir, name)

    fun delete(name: String?) {
        if (name.isNullOrBlank()) return
        File(dir, name).delete()
    }

    private fun imageThumb(privateFile: File?, source: Uri): Bitmap? {
        privateFile?.let { decodeSampled(it) }?.let { return it }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(source, Size(480, 480), null)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun videoFrame(privateFile: File?, source: Uri): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            if (privateFile != null && privateFile.exists()) {
                retriever.setDataSource(privateFile.absolutePath)
            } else {
                retriever.setDataSource(context, source)
            }
            retriever.getFrameAtTime(400_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun decodeSampled(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 720 && bounds.outHeight / sample > 720) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }
}
