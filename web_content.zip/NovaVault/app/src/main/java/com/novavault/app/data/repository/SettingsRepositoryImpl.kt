package com.novavault.app.data.repository

import android.content.Context
import com.novavault.app.data.local.db.SettingsDao
import com.novavault.app.data.local.db.SettingsEntity
import com.novavault.app.data.local.db.toEntity
import com.novavault.app.data.local.db.toModel
import com.novavault.app.data.local.prefs.BootPrefs
import com.novavault.app.data.local.prefs.PreferencesDataSource
import com.novavault.app.domain.model.VaultPreferences
import com.novavault.app.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SettingsRepositoryImpl(
    private val context: Context,
    private val dao: SettingsDao,
    private val dataStore: PreferencesDataSource,
) : SettingsRepository {
    override fun observe(): Flow<VaultPreferences> = dao.observe().map { it?.toModel() ?: VaultPreferences() }

    override suspend fun current(): VaultPreferences = ensure()

    override suspend fun update(block: (VaultPreferences) -> VaultPreferences): VaultPreferences {
        val next = block(ensure())
        dao.upsert(next.toEntity())
        dataStore.write(next)
        BootPrefs.setLanguage(context, next.language.code)
        BootPrefs.setAppLock(context, next.appLockEnabled)
        return next
    }

    override suspend fun hydrate() {
        val prefs = ensure()
        dataStore.write(prefs)
        BootPrefs.setLanguage(context, prefs.language.code)
        BootPrefs.setAppLock(context, prefs.appLockEnabled)
    }

    private suspend fun ensure(): VaultPreferences {
        val row = dao.get()
        if (row != null) return row.toModel()
        val fresh = SettingsEntity.defaults()
        dao.upsert(fresh)
        return fresh.toModel()
    }
}
