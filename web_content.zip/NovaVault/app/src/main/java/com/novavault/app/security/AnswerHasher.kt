package com.novavault.app.security

import java.security.MessageDigest
import java.security.SecureRandom
import java.text.Normalizer
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Answers are never stored. Each question gets a unique salt and a
 * PBKDF2-HMAC-SHA256 digest. Comparison is constant-time.
 */
object AnswerHasher {
    const val ITERATIONS = 80_000
    const val KEY_BITS = 256
    private const val SALT_BYTES = 16

    fun newSalt(): ByteArray {
        val salt = ByteArray(SALT_BYTES)
        SecureRandom().nextBytes(salt)
        return salt
    }

    fun normalize(answer: String): String {
        val nfc = Normalizer.normalize(answer, Normalizer.Form.NFC)
        return nfc.trim().replace(Regex("\\s+"), " ").lowercase()
    }

    fun hash(answer: String, salt: ByteArray, iterations: Int = ITERATIONS): ByteArray {
        val spec = PBEKeySpec(normalize(answer).toCharArray(), salt, iterations, KEY_BITS)
        try {
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            return factory.generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun verify(answer: String, salt: ByteArray, expected: ByteArray, iterations: Int): Boolean {
        val actual = hash(answer, salt, iterations)
        return MessageDigest.isEqual(actual, expected)
    }

    fun encode(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)

    fun decode(text: String): ByteArray = Base64.getDecoder().decode(text)
}
