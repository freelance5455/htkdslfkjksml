package com.novavault.app.domain.auth

import com.novavault.app.domain.model.BiometricPolicy
import com.novavault.app.domain.model.SecurityQuestion

/**
 * Biometric shortcuts never replace the text answer.
 * They only decide whether face / fingerprint alone can pass the current question.
 */
object BiometricGate {
    fun shortcutGranted(
        question: SecurityQuestion,
        faceOk: Boolean,
        fingerOk: Boolean,
    ): Boolean {
        val face = question.faceEnabled
        val finger = question.fingerprintEnabled
        if (face && !finger) return faceOk
        if (!face && finger) return fingerOk
        if (!face && !finger) return false
        return when (question.policy) {
            BiometricPolicy.FACE_ALONE -> faceOk
            BiometricPolicy.FINGERPRINT_ALONE -> fingerOk
            BiometricPolicy.BOTH_REQUIRED -> faceOk && fingerOk
        }
    }
}
