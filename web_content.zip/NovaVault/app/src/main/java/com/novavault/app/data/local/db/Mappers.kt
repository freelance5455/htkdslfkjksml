package com.novavault.app.data.local.db

import com.novavault.app.domain.model.AppLanguage
import com.novavault.app.domain.model.BiometricPolicy
import com.novavault.app.domain.model.MediaEntry
import com.novavault.app.domain.model.MediaKind
import com.novavault.app.domain.model.SecurityQuestion
import com.novavault.app.domain.model.StorageMode
import com.novavault.app.domain.model.VaultPreferences

fun QuestionEntity.toModel() = SecurityQuestion(
    id = id,
    prompt = prompt,
    answerHash = answerHash,
    salt = salt,
    iterations = iterations,
    faceEnabled = faceEnabled,
    fingerprintEnabled = fingerprintEnabled,
    policy = runCatching { BiometricPolicy.valueOf(policy) }.getOrDefault(BiometricPolicy.BOTH_REQUIRED),
    sortOrder = sortOrder,
)

fun MediaItemEntity.toModel() = MediaEntry(
    id = id,
    displayName = displayName,
    mimeType = mimeType,
    kind = runCatching { MediaKind.valueOf(kind) }.getOrDefault(MediaKind.PHOTO),
    storageMode = runCatching { StorageMode.valueOf(storageMode) }.getOrDefault(StorageMode.PRIVATE_COPY),
    location = location,
    thumbnail = thumbnail,
    sizeBytes = sizeBytes,
    durationMs = durationMs,
    addedAt = addedAt,
)

fun SettingsEntity.toModel() = VaultPreferences(
    storageMode = runCatching { StorageMode.valueOf(storageMode) }.getOrDefault(StorageMode.PRIVATE_COPY),
    audioEnabled = audioEnabled,
    language = AppLanguage.from(language),
    appLockEnabled = appLockEnabled,
    setupComplete = setupComplete,
    faceEnrolled = faceEnrolled,
)

fun VaultPreferences.toEntity() = SettingsEntity(
    storageMode = storageMode.name,
    audioEnabled = audioEnabled,
    language = language.code,
    appLockEnabled = appLockEnabled,
    setupComplete = setupComplete,
    faceEnrolled = faceEnrolled,
)
