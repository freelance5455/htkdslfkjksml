package com.novavault.app.ui.navigation

import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.MediaFilter
import com.novavault.app.ui.auth.AuthScreen
import com.novavault.app.ui.face.FaceEnrollScreen
import com.novavault.app.ui.gallery.GalleryScreen
import com.novavault.app.ui.gallery.ViewerScreen
import com.novavault.app.ui.picker.PickerScreen
import com.novavault.app.ui.questions.QuestionEditorScreen
import com.novavault.app.ui.settings.SettingsScreen
import com.novavault.app.ui.setup.SetupScreen
import com.novavault.app.ui.theme.Accent
import com.novavault.app.ui.theme.NavyDeep

@Composable
fun NovaRoot(container: AppContainer, activity: AppCompatActivity) {
    val prefs by container.settings.observe().collectAsState(initial = null)
    val locked by container.session.locked.collectAsState()
    val explicit by container.session.explicit.collectAsState()
    val current = prefs
    when {
        current == null -> {
            Box(Modifier.fillMaxSize().background(NavyDeep), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Accent)
            }
        }
        !current.setupComplete -> SetupHost(container, activity)
        (current.appLockEnabled && locked) || explicit -> AuthScreen(container, activity)
        else -> MainHost(container, activity)
    }
}

@Composable
private fun SetupHost(container: AppContainer, activity: AppCompatActivity) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "setup") {
        composable("setup") {
            SetupScreen(
                container = container,
                activity = activity,
                onAddQuestion = { nav.navigate("question/0") },
                onEnroll = { nav.navigate("face") },
            )
        }
        composable(
            route = "question/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType }),
        ) { entry ->
            val id = entry.arguments?.getLong("id") ?: 0L
            QuestionEditorScreen(container, id) { nav.popBackStack() }
        }
        composable("face") {
            FaceEnrollScreen(container) { nav.popBackStack() }
        }
    }
}

@Composable
private fun MainHost(container: AppContainer, activity: AppCompatActivity) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "gallery") {
        composable("gallery") {
            GalleryScreen(
                container = container,
                activity = activity,
                onImport = { nav.navigate("picker") },
                onOpen = { id, filter -> nav.navigate("viewer/$id/${filter.name}") },
                onSettings = { nav.navigate("settings") },
            )
        }
        composable("picker") {
            PickerScreen(
                container = container,
                onBack = { nav.popBackStack() },
                onImported = {
                    nav.popBackStack()
                },
            )
        }
        composable(
            route = "viewer/{id}/{filter}",
            arguments = listOf(
                navArgument("id") { type = NavType.LongType },
                navArgument("filter") { type = NavType.StringType },
            ),
        ) { entry ->
            val id = entry.arguments?.getLong("id") ?: return@composable
            val filter = runCatching {
                MediaFilter.valueOf(entry.arguments?.getString("filter") ?: MediaFilter.ALL.name)
            }.getOrDefault(MediaFilter.ALL)
            ViewerScreen(container, activity, id, filter) { nav.popBackStack() }
        }
        composable("settings") {
            SettingsScreen(
                container = container,
                activity = activity,
                onBack = { nav.popBackStack() },
                onEditQuestion = { id -> nav.navigate("question/$id") },
                onAddQuestion = { nav.navigate("question/0") },
                onEnrollFace = { nav.navigate("face") },
            )
        }
        composable(
            route = "question/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType }),
        ) { entry ->
            val id = entry.arguments?.getLong("id") ?: 0L
            QuestionEditorScreen(container, id) { nav.popBackStack() }
        }
        composable("face") {
            FaceEnrollScreen(container) { nav.popBackStack() }
        }
    }
}
