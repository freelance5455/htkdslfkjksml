package com.novavault.app.data.local.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "questions")
data class QuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val prompt: String,
    val answerHash: String,
    val salt: String,
    val iterations: Int,
    val faceEnabled: Boolean,
    val fingerprintEnabled: Boolean,
    val policy: String,
    val sortOrder: Int,
    val createdAt: Long,
)

@Entity(tableName = "media_items")
data class MediaItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    val mimeType: String,
    val kind: String,
    val storageMode: String,
    val location: String,
    val thumbnail: String?,
    val sizeBytes: Long,
    val durationMs: Long,
    val addedAt: Long,
)

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = SINGLETON_ID,
    val storageMode: String,
    val audioEnabled: Boolean,
    val language: String,
    val appLockEnabled: Boolean,
    val setupComplete: Boolean,
    val faceEnrolled: Boolean,
) {
    companion object {
        const val SINGLETON_ID = 1

        fun defaults() = SettingsEntity(
            id = SINGLETON_ID,
            storageMode = "PRIVATE_COPY",
            audioEnabled = true,
            language = "en",
            appLockEnabled = true,
            setupComplete = false,
            faceEnrolled = false,
        )
    }
}
