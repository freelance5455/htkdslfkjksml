package com.novavault.app.data.repository

import android.content.ContentResolver
import android.net.Uri
import com.novavault.app.data.local.db.MediaDao
import com.novavault.app.data.local.db.MediaItemEntity
import com.novavault.app.data.local.db.toModel
import com.novavault.app.data.media.PrivateMediaStore
import com.novavault.app.data.media.Thumbnailer
import com.novavault.app.domain.model.ImportResult
import com.novavault.app.domain.model.ImportSource
import com.novavault.app.domain.model.MediaEntry
import com.novavault.app.domain.model.StorageMode
import com.novavault.app.domain.repository.MediaRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MediaRepositoryImpl(
    private val dao: MediaDao,
    private val resolver: ContentResolver,
    private val privateStore: PrivateMediaStore,
    private val thumbnailer: Thumbnailer,
) : MediaRepository {
    override fun observe(): Flow<List<MediaEntry>> = dao.observe().map { rows -> rows.map { it.toModel() } }

    override suspend fun import(
        items: List<ImportSource>,
        mode: StorageMode,
        onProgress: (done: Int, total: Int) -> Unit,
    ): ImportResult {
        val known = dao.locations().toMutableSet()
        var imported = 0
        var failed = 0
        items.forEachIndexed { index, item ->
            onProgress(index, items.size)
            var created: String? = null
            try {
                val uri = Uri.parse(item.uriString)
                if (mode == StorageMode.REFERENCE && !known.add(item.uriString)) {
                    failed++
                    return@forEachIndexed
                }
                val location = when (mode) {
                    StorageMode.REFERENCE -> item.uriString
                    StorageMode.PRIVATE_COPY -> {
                        val name = privateStore.import(resolver, uri, item.displayName).name
                        created = name
                        name
                    }
                }
                val privateFile = if (mode == StorageMode.PRIVATE_COPY) privateStore.resolve(location) else null
                val thumb = runCatching { thumbnailer.create(uri, item.kind, privateFile) }.getOrNull()
                dao.insert(
                    MediaItemEntity(
                        displayName = item.displayName,
                        mimeType = item.mimeType,
                        kind = item.kind.name,
                        storageMode = mode.name,
                        location = location,
                        thumbnail = thumb,
                        sizeBytes = item.sizeBytes,
                        durationMs = item.durationMs,
                        addedAt = System.currentTimeMillis(),
                    ),
                )
                imported++
            } catch (_: Exception) {
                created?.let { privateStore.delete(it) }
                if (mode == StorageMode.REFERENCE) known.remove(item.uriString)
                failed++
            }
        }
        onProgress(items.size, items.size)
        return ImportResult(imported, failed)
    }

    override suspend fun remove(id: Long) {
        val row = dao.get(id) ?: return
        eraseFiles(row)
        dao.delete(id)
    }

    override suspend fun clear() {
        dao.all().forEach { eraseFiles(it) }
        dao.clear()
    }

    override suspend fun count(): Int = dao.count()

    private fun eraseFiles(row: MediaItemEntity) {
        if (row.storageMode == StorageMode.PRIVATE_COPY.name) {
            privateStore.delete(row.location)
        }
        thumbnailer.delete(row.thumbnail)
    }
}
