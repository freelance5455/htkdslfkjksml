package com.novavault.app.ui.picker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.novavault.app.R
import com.novavault.app.data.media.DeviceMedia
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.MediaFilter
import com.novavault.app.domain.model.MediaKind
import com.novavault.app.domain.model.StorageMode
import com.novavault.app.ui.common.VaultTopBar
import com.novavault.app.ui.common.formatDuration
import com.novavault.app.ui.theme.Accent
import com.novavault.app.ui.theme.Ink
import com.novavault.app.ui.theme.Mist
import com.novavault.app.ui.theme.Navy
import com.novavault.app.ui.theme.NavyDeep

@Composable
fun PickerScreen(container: AppContainer, onBack: () -> Unit, onImported: () -> Unit) {
    val vm: PickerViewModel = viewModel(factory = PickerViewModel.factory(container))
    val ui by vm.ui.collectAsState()
    val context = LocalContext.current
    var denied by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            denied = false
            vm.load()
        } else {
            denied = true
        }
    }
    LaunchedEffect(Unit) {
        val ok = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED
        if (ok) vm.load() else launcher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    LaunchedEffect(ui.done) {
        val done = ui.done ?: return@LaunchedEffect
        if (done.imported > 0) onImported()
        vm.consumeDone()
    }
    val visible = when (ui.filter) {
        MediaFilter.ALL -> ui.items
        MediaFilter.PHOTOS -> ui.items.filter { it.kind == MediaKind.PHOTO }
        MediaFilter.VIDEOS -> ui.items.filter { it.kind == MediaKind.VIDEO }
    }
    Scaffold(
        containerColor = Mist,
        topBar = { VaultTopBar(title = stringResource(R.string.picker_title), onBack = onBack) },
        bottomBar = {
            if (!denied && ui.selected.isNotEmpty()) {
                Button(
                    onClick = vm::importSelected,
                    enabled = !ui.importing,
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = NavyDeep),
                ) {
                    Text(
                        if (ui.importing) {
                            stringResource(if (ui.mode == StorageMode.PRIVATE_COPY) R.string.copying else R.string.linking)
                        } else {
                            stringResource(R.string.import_count, ui.selected.size)
                        },
                    )
                }
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Text(
                text = stringResource(
                    R.string.storage_mode_now,
                    stringResource(if (ui.mode == StorageMode.PRIVATE_COPY) R.string.mode_private_short else R.string.mode_reference_short),
                ),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                color = Ink,
            )
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniFilter(stringResource(R.string.filter_all), ui.filter == MediaFilter.ALL) { vm.setFilter(MediaFilter.ALL) }
                MiniFilter(stringResource(R.string.filter_photos), ui.filter == MediaFilter.PHOTOS) { vm.setFilter(MediaFilter.PHOTOS) }
                MiniFilter(stringResource(R.string.filter_videos), ui.filter == MediaFilter.VIDEOS) { vm.setFilter(MediaFilter.VIDEOS) }
            }
            when {
                denied -> PermissionBlock(
                    onGrant = { launcher.launch(Manifest.permission.READ_EXTERNAL_STORAGE) },
                    onSettings = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    },
                )
                ui.loading || ui.importing && visible.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Navy)
                }
                visible.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.picker_empty), color = Ink)
                }
                else -> LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(visible, key = { it.uri.toString() }) { item ->
                        PickCell(
                            item = item,
                            selected = ui.selected.contains(item.uri.toString()),
                            onClick = { vm.toggle(item.uri.toString()) },
                        )
                    }
                }
            }
            if (ui.failed) {
                Text(
                    stringResource(R.string.import_failed),
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp),
                )
            }
        }
    }
}

@Composable
private fun MiniFilter(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text = label,
        color = if (selected) NavyDeep else Ink,
        modifier = Modifier
            .clip(RoundedCornerShape(99.dp))
            .background(if (selected) Accent else Color.White)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

@Composable
private fun PermissionBlock(onGrant: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(stringResource(R.string.permission_needed), style = MaterialTheme.typography.titleMedium, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.permission_denied_settings), color = Ink.copy(alpha = 0.75f))
        Spacer(Modifier.height(16.dp))
        Button(onClick = onGrant, colors = ButtonDefaults.buttonColors(containerColor = Navy, contentColor = Color.White)) {
            Text(stringResource(R.string.grant_permission))
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onSettings, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = NavyDeep)) {
            Text(stringResource(R.string.open_settings))
        }
    }
}

@Composable
private fun PickCell(item: DeviceMedia, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(Navy.copy(alpha = 0.08f))
            .border(if (selected) 3.dp else 0.dp, Accent, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
    ) {
        AsyncImage(
            model = item.uri,
            contentDescription = item.displayName,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
        if (item.kind == MediaKind.VIDEO) {
            Row(
                Modifier.align(Alignment.BottomStart).padding(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                if (item.durationMs > 0) Text(formatDuration(item.durationMs), color = Color.White)
            }
        }
        if (selected) {
            Icon(
                Icons.Filled.Check,
                contentDescription = null,
                tint = NavyDeep,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(22.dp)
                    .background(Accent, RoundedCornerShape(99.dp))
                    .padding(2.dp),
            )
        }
    }
}
