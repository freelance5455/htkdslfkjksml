package com.novavault.app.ui.questions

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novavault.app.R
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.BiometricPolicy
import com.novavault.app.domain.model.QuestionDraft
import com.novavault.app.domain.repository.QuestionRepository
import com.novavault.app.security.AnswerHasher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EditorUi(
    val loading: Boolean = true,
    val exists: Boolean = false,
    val prompt: String = "",
    val answer: String = "",
    val confirm: String = "",
    val face: Boolean = false,
    val fingerprint: Boolean = false,
    val policy: BiometricPolicy = BiometricPolicy.BOTH_REQUIRED,
    @StringRes val errorRes: Int? = null,
    val saved: Boolean = false,
)

class QuestionEditorViewModel(
    private val questions: QuestionRepository,
    private val questionId: Long,
) : ViewModel() {
    private val _ui = MutableStateFlow(EditorUi(exists = questionId > 0L))
    val ui: StateFlow<EditorUi> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            if (questionId <= 0L) {
                _ui.update { it.copy(loading = false, exists = false) }
                return@launch
            }
            val current = questions.get(questionId)
            if (current == null) {
                _ui.update { it.copy(loading = false, exists = false) }
            } else {
                _ui.update {
                    it.copy(
                        loading = false,
                        exists = true,
                        prompt = current.prompt,
                        face = current.faceEnabled,
                        fingerprint = current.fingerprintEnabled,
                        policy = current.policy,
                    )
                }
            }
        }
    }

    fun setPrompt(value: String) = _ui.update { it.copy(prompt = value, errorRes = null) }
    fun setAnswer(value: String) = _ui.update { it.copy(answer = value, errorRes = null) }
    fun setConfirm(value: String) = _ui.update { it.copy(confirm = value, errorRes = null) }
    fun setFace(value: Boolean) = _ui.update { it.copy(face = value) }
    fun setFingerprint(value: Boolean) = _ui.update { it.copy(fingerprint = value) }
    fun setPolicy(value: BiometricPolicy) = _ui.update { it.copy(policy = value) }

    fun save() {
        val state = _ui.value
        val prompt = state.prompt.trim()
        if (prompt.isEmpty()) {
            _ui.update { it.copy(errorRes = R.string.question_required) }
            return
        }
        val answer = state.answer
        val confirm = state.confirm
        val providing = answer.isNotBlank() || confirm.isNotBlank()
        if (!state.exists && !providing) {
            _ui.update { it.copy(errorRes = R.string.answer_required) }
            return
        }
        if (providing) {
            if (AnswerHasher.normalize(answer).length < 2) {
                _ui.update { it.copy(errorRes = R.string.answer_short) }
                return
            }
            if (answer.trim() != confirm.trim()) {
                _ui.update { it.copy(errorRes = R.string.answer_mismatch) }
                return
            }
        }
        viewModelScope.launch {
            questions.save(
                QuestionDraft(
                    id = questionId.takeIf { it > 0L },
                    prompt = prompt,
                    answer = if (providing) answer else null,
                    faceEnabled = state.face,
                    fingerprintEnabled = state.fingerprint,
                    policy = state.policy,
                ),
            )
            _ui.update { it.copy(saved = true) }
        }
    }

    companion object {
        fun factory(container: AppContainer, questionId: Long): ViewModelProvider.Factory {
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return QuestionEditorViewModel(container.questions, questionId) as T
                }
            }
        }
    }
}
