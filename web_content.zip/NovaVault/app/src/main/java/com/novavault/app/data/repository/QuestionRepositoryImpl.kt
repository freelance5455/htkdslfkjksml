package com.novavault.app.data.repository

import com.novavault.app.data.local.db.QuestionDao
import com.novavault.app.data.local.db.QuestionEntity
import com.novavault.app.data.local.db.toModel
import com.novavault.app.domain.model.QuestionDraft
import com.novavault.app.domain.model.SecurityQuestion
import com.novavault.app.domain.repository.QuestionRepository
import com.novavault.app.security.AnswerHasher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class QuestionRepositoryImpl(
    private val dao: QuestionDao,
) : QuestionRepository {
    override fun observe(): Flow<List<SecurityQuestion>> = dao.observe().map { rows -> rows.map { it.toModel() } }

    override suspend fun get(id: Long): SecurityQuestion? = dao.get(id)?.toModel()

    override suspend fun save(draft: QuestionDraft) {
        val prompt = draft.prompt.trim()
        require(prompt.isNotEmpty())
        val existing = draft.id?.let { dao.get(it) }
        val normalizedAnswer = draft.answer?.let { AnswerHasher.normalize(it) }.orEmpty()
        val (hash, salt, iterations) = if (normalizedAnswer.isNotEmpty()) {
            require(normalizedAnswer.length >= 2)
            val freshSalt = AnswerHasher.newSalt()
            Triple(
                AnswerHasher.encode(AnswerHasher.hash(normalizedAnswer, freshSalt)),
                AnswerHasher.encode(freshSalt),
                AnswerHasher.ITERATIONS,
            )
        } else {
            requireNotNull(existing) { "answer required" }
            Triple(existing.answerHash, existing.salt, existing.iterations)
        }
        val order = existing?.sortOrder ?: (dao.maxOrder() + 1)
        dao.upsert(
            QuestionEntity(
                id = existing?.id ?: 0,
                prompt = prompt,
                answerHash = hash,
                salt = salt,
                iterations = iterations,
                faceEnabled = draft.faceEnabled,
                fingerprintEnabled = draft.fingerprintEnabled,
                policy = draft.policy.name,
                sortOrder = order,
                createdAt = existing?.createdAt ?: System.currentTimeMillis(),
            ),
        )
    }

    override suspend fun delete(id: Long) {
        dao.delete(id)
    }

    override suspend fun move(id: Long, delta: Int) {
        if (delta == 0) return
        val items = dao.list()
        val index = items.indexOfFirst { it.id == id }
        val target = index + delta
        if (index < 0 || target !in items.indices) return
        val a = items[index]
        val b = items[target]
        dao.updateOrder(a.id, b.sortOrder)
        dao.updateOrder(b.id, a.sortOrder)
        if (a.sortOrder == b.sortOrder) {
            dao.updateOrder(a.id, target)
            dao.updateOrder(b.id, index)
        }
    }

    override suspend fun verify(question: SecurityQuestion, answer: String): Boolean {
        return try {
            AnswerHasher.verify(
                answer = answer,
                salt = AnswerHasher.decode(question.salt),
                expected = AnswerHasher.decode(question.answerHash),
                iterations = question.iterations,
            )
        } catch (_: Exception) {
            false
        }
    }
}
