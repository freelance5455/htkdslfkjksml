package com.novavault.app.ui.setup

import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novavault.app.R
import com.novavault.app.di.AppContainer
import com.novavault.app.ui.common.VaultTopBar
import com.novavault.app.ui.settings.SettingsViewModel
import com.novavault.app.ui.theme.Accent
import com.novavault.app.ui.theme.Ink
import com.novavault.app.ui.theme.Mist
import com.novavault.app.ui.theme.NavyDeep
import com.novavault.app.ui.theme.VaultMark
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Alignment
import kotlinx.coroutines.launch

@Composable
fun SetupScreen(
    container: AppContainer,
    activity: AppCompatActivity,
    onAddQuestion: () -> Unit,
    onEnroll: () -> Unit,
) {
    val vm: SettingsViewModel = viewModel(
        viewModelStoreOwner = activity,
        key = "setup-settings",
        factory = SettingsViewModel.factory(container),
    )
    val prefs by vm.prefs.collectAsState()
    val questions by vm.sequence.collectAsState()
    var error by rememberSaveable { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(containerColor = Mist, topBar = { VaultTopBar(title = stringResource(R.string.app_name)) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.Start,
        ) {
            VaultMark(Modifier.size(56.dp).align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.setup_title), style = MaterialTheme.typography.headlineMedium, color = Ink)
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.setup_body), color = Ink.copy(alpha = 0.78f))
            Spacer(Modifier.height(18.dp))
            Text(stringResource(R.string.question_count, questions.size), color = Ink)
            TextButton(onClick = onAddQuestion) { Text(stringResource(R.string.add_question)) }
            questions.forEach { question ->
                Text("• ${question.prompt}", color = Ink, modifier = Modifier.padding(vertical = 4.dp))
            }
            TextButton(onClick = onEnroll) { Text(stringResource(R.string.enroll_face)) }
            Text(
                stringResource(if (prefs.faceEnrolled) R.string.face_enrolled else R.string.face_not_enrolled),
                color = Ink.copy(alpha = 0.7f),
            )
            Spacer(Modifier.height(12.dp))
            if (error) {
                Text(stringResource(R.string.need_question), color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(8.dp))
            }
            Button(
                onClick = {
                    if (prefs.appLockEnabled && questions.isEmpty()) {
                        error = true
                    } else {
                        error = false
                        scope.launch {
                            container.settings.update { it.copy(setupComplete = true) }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = NavyDeep),
            ) { Text(stringResource(R.string.enter_vault)) }
        }
    }
}
