package com.novavault.app.domain.face

/**
 * On-device face template. [vector] length is defined by the active embedder
 * (geometric 24×24 today). A future TFLite embedder can replace the producer
 * as long as enrollment and verify use the same length.
 */
class FaceTemplate(
    val width: Int,
    val height: Int,
    val samples: Int,
    val vector: FloatArray,
)
