package com.novavault.app.domain.repository

import com.novavault.app.domain.model.ImportResult
import com.novavault.app.domain.model.ImportSource
import com.novavault.app.domain.model.MediaEntry
import com.novavault.app.domain.model.QuestionDraft
import com.novavault.app.domain.model.SecurityQuestion
import com.novavault.app.domain.model.StorageMode
import com.novavault.app.domain.model.VaultPreferences
import kotlinx.coroutines.flow.Flow

interface QuestionRepository {
    fun observe(): Flow<List<SecurityQuestion>>
    suspend fun get(id: Long): SecurityQuestion?
    suspend fun save(draft: QuestionDraft)
    suspend fun delete(id: Long)
    suspend fun move(id: Long, delta: Int)
    suspend fun verify(question: SecurityQuestion, answer: String): Boolean
}

interface MediaRepository {
    fun observe(): Flow<List<MediaEntry>>
    suspend fun import(
        items: List<ImportSource>,
        mode: StorageMode,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> },
    ): ImportResult
    suspend fun remove(id: Long)
    suspend fun clear()
    suspend fun count(): Int
}

interface SettingsRepository {
    fun observe(): Flow<VaultPreferences>
    suspend fun current(): VaultPreferences
    suspend fun update(block: (VaultPreferences) -> VaultPreferences): VaultPreferences
    suspend fun hydrate()
}
