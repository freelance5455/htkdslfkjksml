package com.novavault.app.ui.session

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import com.novavault.app.R

class VaultAudio(context: Context) {
    private val app = context.applicationContext
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()
    private val pool = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(attrs).build()
    private val correct = pool.load(app, R.raw.sfx_correct, 1)
    private val incorrect = pool.load(app, R.raw.sfx_incorrect, 1)
    private val success = pool.load(app, R.raw.sfx_success, 1)
    private var music: MediaPlayer? = null

    @Volatile
    var enabled: Boolean = true

    fun playCorrect() = play(correct)

    fun playIncorrect() = play(incorrect)

    fun playSuccess() = play(success)

    fun startAmbience() {
        if (!enabled) return
        val player = music ?: MediaPlayer.create(app, R.raw.music_suspense)?.also {
            it.isLooping = true
            it.setVolume(0.28f, 0.28f)
            music = it
        } ?: return
        if (!player.isPlaying) player.start()
    }

    fun stopAmbience() {
        music?.let {
            if (it.isPlaying) it.pause()
            it.seekTo(0)
        }
    }

    private fun play(id: Int) {
        if (!enabled || id == 0) return
        pool.play(id, 1f, 1f, 1, 0, 1f)
    }
}
