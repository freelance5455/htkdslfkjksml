package com.novavault.app.data.face

import com.novavault.app.domain.face.FaceTemplate
import com.novavault.app.security.VaultCrypto
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File

class FaceTemplateStore(
    filesDir: File,
    private val crypto: VaultCrypto,
) {
    private val file = File(filesDir, "face/template.bin")

    fun hasTemplate(): Boolean = file.exists() && file.length() > 0L

    fun save(template: FaceTemplate) {
        file.parentFile?.mkdirs()
        file.writeBytes(crypto.encrypt(serialize(template)))
    }

    fun load(): FaceTemplate? {
        if (!file.exists()) return null
        return try {
            deserialize(crypto.decrypt(file.readBytes()))
        } catch (_: Exception) {
            null
        }
    }

    fun clear() {
        file.delete()
    }

    private fun serialize(template: FaceTemplate): ByteArray {
        val bos = ByteArrayOutputStream()
        DataOutputStream(bos).use { out ->
            out.writeInt(MAGIC)
            out.writeInt(VERSION)
            out.writeInt(template.width)
            out.writeInt(template.height)
            out.writeInt(template.samples)
            out.writeInt(template.vector.size)
            template.vector.forEach { out.writeFloat(it) }
        }
        return bos.toByteArray()
    }

    private fun deserialize(bytes: ByteArray): FaceTemplate? {
        DataInputStream(ByteArrayInputStream(bytes)).use { input ->
            if (input.readInt() != MAGIC) return null
            if (input.readInt() != VERSION) return null
            val width = input.readInt()
            val height = input.readInt()
            val samples = input.readInt()
            val len = input.readInt()
            if (len <= 0 || len > 8192) return null
            val vector = FloatArray(len) { input.readFloat() }
            return FaceTemplate(width, height, samples, vector)
        }
    }

    companion object {
        private const val MAGIC = 0x4E564654
        private const val VERSION = 1
    }
}
