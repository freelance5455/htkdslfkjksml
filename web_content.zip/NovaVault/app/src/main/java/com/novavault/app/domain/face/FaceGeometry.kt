package com.novavault.app.domain.face

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Lightweight offline face template. Not Android Face Unlock and not a neural
 * network: a skin-region crop is normalized to 24×24 luminance and compared
 * with cosine similarity plus mean absolute distance.
 *
 * Swap [embed] for a bundled TFLite model later without touching enrollment UI.
 * This will confuse similar lighting and close relatives more often than a real
 * embedding model. It is intentionally on-device and dependency-free.
 */
object FaceGeometry {
    const val SIZE = 24
    const val MATCH_COSINE = 0.90f
    const val MATCH_MAD = 0.18f

    fun cosine(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size || a.isEmpty()) return 0f
        var dot = 0.0
        var na = 0.0
        var nb = 0.0
        for (i in a.indices) {
            val av = a[i].toDouble()
            val bv = b[i].toDouble()
            dot += av * bv
            na += av * av
            nb += bv * bv
        }
        if (na <= 1e-8 || nb <= 1e-8) return 0f
        return (dot / (sqrt(na) * sqrt(nb))).toFloat()
    }

    fun meanAbs(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size || a.isEmpty()) return 1f
        var sum = 0.0
        for (i in a.indices) sum += kotlin.math.abs(a[i] - b[i])
        return (sum / a.size).toFloat()
    }

    fun matches(probe: FloatArray, enrolled: FloatArray): Boolean {
        return cosine(probe, enrolled) >= MATCH_COSINE && meanAbs(probe, enrolled) <= MATCH_MAD
    }

    fun average(vectors: List<FloatArray>): FloatArray {
        require(vectors.isNotEmpty())
        val n = vectors.first().size
        val out = FloatArray(n)
        for (v in vectors) {
            require(v.size == n)
            for (i in 0 until n) out[i] += v[i]
        }
        val count = vectors.size.toFloat()
        for (i in out.indices) out[i] /= count
        return out
    }

    fun isSkin(y: Int, cb: Int, cr: Int): Boolean {
        return y in 48..240 && cb in 77..135 && cr in 133..173
    }

    fun embed(luma: IntArray, cb: IntArray, cr: IntArray, width: Int, height: Int): FloatArray? {
        if (width < 16 || height < 16) return null
        val need = width * height
        if (luma.size < need || cb.size < need || cr.size < need) return null

        val step = max(1, min(width, height) / 80)
        var minX = width
        var minY = height
        var maxX = -1
        var maxY = -1
        var skin = 0
        var seen = 0
        var y = 0
        while (y < height) {
            var x = 0
            while (x < width) {
                val i = y * width + x
                seen++
                if (isSkin(luma[i], cb[i], cr[i])) {
                    skin++
                    if (x < minX) minX = x
                    if (y < minY) minY = y
                    if (x > maxX) maxX = x
                    if (y > maxY) maxY = y
                }
                x += step
            }
            y += step
        }
        if (seen == 0 || maxX < minX) return null
        val fraction = skin.toFloat() / seen.toFloat()
        if (fraction < 0.08f || fraction > 0.70f) return null

        val boxW = (maxX - minX + step).coerceAtLeast(1)
        val boxH = (maxY - minY + step).coerceAtLeast(1)
        if (boxW < width * 0.12f || boxH < height * 0.12f) return null
        val aspect = boxW.toFloat() / boxH.toFloat()
        if (aspect < 0.55f || aspect > 1.85f) return null

        val cx = (minX + maxX) / 2
        val cy = (minY + maxY) / 2
        val side = (max(boxW, boxH) * 1.12f).toInt().coerceAtLeast(8)
        var left = cx - side / 2
        var top = cy - side / 2
        if (left < 0) left = 0
        if (top < 0) top = 0
        if (left + side > width) left = max(0, width - side)
        if (top + side > height) top = max(0, height - side)
        val right = min(width, left + side)
        val bottom = min(height, top + side)
        val cropW = right - left
        val cropH = bottom - top
        if (cropW < 8 || cropH < 8) return null

        val samples = IntArray(SIZE * SIZE)
        val hist = IntArray(256)
        for (gy in 0 until SIZE) {
            val y0 = top + gy * cropH / SIZE
            var y1 = top + (gy + 1) * cropH / SIZE
            if (y1 <= y0) y1 = y0 + 1
            for (gx in 0 until SIZE) {
                val x0 = left + gx * cropW / SIZE
                var x1 = left + (gx + 1) * cropW / SIZE
                if (x1 <= x0) x1 = x0 + 1
                var sum = 0
                var count = 0
                var yy = y0
                while (yy < y1 && yy < height) {
                    val row = yy * width
                    var xx = x0
                    while (xx < x1 && xx < width) {
                        sum += luma[row + xx]
                        count++
                        xx++
                    }
                    yy++
                }
                val value = if (count == 0) 0 else (sum / count).coerceIn(0, 255)
                val index = gy * SIZE + gx
                samples[index] = value
                hist[value]++
            }
        }

        val cdf = IntArray(256)
        var acc = 0
        for (i in 0..255) {
            acc += hist[i]
            cdf[i] = acc
        }
        val total = SIZE * SIZE
        var cdfMin = 0
        for (i in 0..255) {
            if (cdf[i] != 0) {
                cdfMin = cdf[i]
                break
            }
        }
        val denom = (total - cdfMin).coerceAtLeast(1)
        val out = FloatArray(total)
        var mean = 0.0
        for (i in samples.indices) {
            val eq = ((cdf[samples[i]] - cdfMin).toFloat() / denom.toFloat()).coerceIn(0f, 1f)
            out[i] = eq
            mean += eq
        }
        mean /= total
        var variance = 0.0
        for (v in out) {
            val d = v - mean
            variance += d * d
        }
        variance /= total
        if (variance < 0.008) return null
        return out
    }
}
