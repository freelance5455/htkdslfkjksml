package com.novavault.app.ui.picker

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novavault.app.data.media.DeviceMedia
import com.novavault.app.data.media.MediaStoreDataSource
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.ImportResult
import com.novavault.app.domain.model.ImportSource
import com.novavault.app.domain.model.MediaFilter
import com.novavault.app.domain.model.StorageMode
import com.novavault.app.domain.repository.MediaRepository
import com.novavault.app.domain.repository.SettingsRepository
import com.novavault.app.ui.gallery.simpleFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PickerUi(
    val loading: Boolean = true,
    val importing: Boolean = false,
    val items: List<DeviceMedia> = emptyList(),
    val selected: Set<String> = emptySet(),
    val filter: MediaFilter = MediaFilter.ALL,
    val mode: StorageMode = StorageMode.PRIVATE_COPY,
    val done: ImportResult? = null,
    val failed: Boolean = false,
)

class PickerViewModel(
    private val deviceMedia: MediaStoreDataSource,
    private val media: MediaRepository,
    private val settings: SettingsRepository,
) : ViewModel() {
    private val _ui = MutableStateFlow(PickerUi())
    val ui: StateFlow<PickerUi> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            val mode = settings.current().storageMode
            _ui.update { it.copy(mode = mode) }
        }
    }

    fun load() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, failed = false) }
            val items = withContext(Dispatchers.IO) { runCatching { deviceMedia.query() }.getOrDefault(emptyList()) }
            _ui.update { it.copy(loading = false, items = items) }
        }
    }

    fun setFilter(filter: MediaFilter) {
        _ui.update { it.copy(filter = filter) }
    }

    fun toggle(uri: String) {
        _ui.update { state ->
            val next = state.selected.toMutableSet()
            if (!next.add(uri)) next.remove(uri)
            state.copy(selected = next)
        }
    }

    fun importSelected() {
        val state = _ui.value
        if (state.importing) return
        val chosen = state.items.filter { state.selected.contains(it.uri.toString()) }
        if (chosen.isEmpty()) return
        viewModelScope.launch {
            _ui.update { it.copy(importing = true, failed = false) }
            val mode = settings.current().storageMode
            val result = withContext(Dispatchers.IO) {
                media.import(
                    items = chosen.map {
                        ImportSource(
                            uriString = it.uri.toString(),
                            displayName = it.displayName,
                            mimeType = it.mimeType,
                            kind = it.kind,
                            sizeBytes = it.sizeBytes,
                            durationMs = it.durationMs,
                        )
                    },
                    mode = mode,
                )
            }
            _ui.update { it.copy(importing = false, done = result, failed = result.failed > 0 && result.imported == 0) }
        }
    }

    fun consumeDone() {
        _ui.update { it.copy(done = null) }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = simpleFactory {
            PickerViewModel(container.deviceMedia, container.media, container.settings)
        }
    }
}
