package com.novavault.app.ui.face

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novavault.app.R
import com.novavault.app.di.AppContainer
import com.novavault.app.ui.auth.FaceHint
import com.novavault.app.ui.common.VaultTopBar
import com.novavault.app.ui.theme.Accent
import com.novavault.app.ui.theme.Navy
import com.novavault.app.ui.theme.NavyDeep

@Composable
fun FaceEnrollScreen(container: AppContainer, onDone: () -> Unit) {
    val vm: FaceEnrollViewModel = viewModel(factory = FaceEnrollViewModel.factory(container))
    val ui by vm.ui.collectAsState()
    val context = LocalContext.current
    var allowed by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED,
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { allowed = it }
    LaunchedEffect(ui.saved) {
        if (ui.saved) onDone()
    }
    Box(Modifier.fillMaxSize().background(NavyDeep)) {
        if (allowed && !ui.saved) {
            CameraPreview(Modifier.fillMaxSize()) { vm.onFrame(it.embedding) }
        }
        Column(Modifier.fillMaxSize()) {
            VaultTopBar(title = stringResource(R.string.enroll_face), onBack = onDone)
            Text(
                text = stringResource(R.string.enroll_instructions),
                color = Color.White,
                modifier = Modifier.padding(20.dp),
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = stringResource(R.string.capture_progress, ui.samples, 3),
                color = Accent,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(
                    when {
                        ui.failed -> R.string.face_failed
                        ui.hint == FaceHint.HOLD -> R.string.hold_still
                        ui.hint == FaceHint.NO_FACE -> R.string.no_face
                        ui.hint == FaceHint.MATCH -> R.string.face_saved
                        else -> R.string.searching_face
                    },
                ),
                color = Color.White,
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
                    .background(Navy.copy(alpha = 0.86f), RoundedCornerShape(12.dp))
                    .padding(16.dp),
                textAlign = TextAlign.Center,
            )
            if (!allowed) {
                Button(
                    onClick = { launcher.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = NavyDeep),
                ) { Text(stringResource(R.string.grant_camera)) }
                Text(
                    stringResource(R.string.camera_permission),
                    color = Color.White.copy(alpha = 0.75f),
                    modifier = Modifier.padding(20.dp),
                )
            }
            TextButton(onClick = vm::reset, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.start_over), color = Accent)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}
