package com.novavault.app.data.media

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.novavault.app.domain.model.MediaKind

data class DeviceMedia(
    val uri: Uri,
    val displayName: String,
    val mimeType: String,
    val kind: MediaKind,
    val sizeBytes: Long,
    val durationMs: Long,
    val dateModified: Long,
)

/** Unified photo + video listing through MediaStore. No separate pickers. */
class MediaStoreDataSource(private val context: Context) {
    fun query(): List<DeviceMedia> {
        return try {
            queryWith(includeDuration = true)
        } catch (_: Exception) {
            queryWith(includeDuration = false)
        }
    }

    private fun queryWith(includeDuration: Boolean): List<DeviceMedia> {
        val collection = MediaStore.Files.getContentUri("external")
        val projection = mutableListOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
        )
        if (includeDuration) projection += MediaStore.Files.FileColumns.DURATION

        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?"
        val args = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString(),
        )
        val sort = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
        val found = ArrayList<DeviceMedia>()
        context.contentResolver.query(collection, projection.toTypedArray(), selection, args, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            val typeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
            val durationCol = if (includeDuration) cursor.getColumnIndex(MediaStore.Files.FileColumns.DURATION) else -1
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val type = cursor.getInt(typeCol)
                val kind = if (type == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO) MediaKind.VIDEO else MediaKind.PHOTO
                val mime = cursor.getString(mimeCol) ?: if (kind == MediaKind.VIDEO) "video/*" else "image/*"
                val name = cursor.getString(nameCol) ?: "media"
                val size = if (cursor.isNull(sizeCol)) 0L else cursor.getLong(sizeCol)
                val modified = if (cursor.isNull(dateCol)) 0L else cursor.getLong(dateCol)
                val duration = if (durationCol >= 0 && !cursor.isNull(durationCol)) cursor.getLong(durationCol) else 0L
                val uri = ContentUris.withAppendedId(collection, id)
                found += DeviceMedia(
                    uri = uri,
                    displayName = name,
                    mimeType = mime,
                    kind = kind,
                    sizeBytes = size,
                    durationMs = duration,
                    dateModified = modified,
                )
            }
        }
        return found
    }
}
