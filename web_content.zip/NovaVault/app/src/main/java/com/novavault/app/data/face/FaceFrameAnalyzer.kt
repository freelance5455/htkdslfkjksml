package com.novavault.app.data.face

import android.graphics.ImageFormat
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.novavault.app.domain.face.FaceGeometry
import kotlin.math.max
import kotlin.math.min

data class FaceFrame(
    val embedding: FloatArray?,
)

/**
 * CameraX analyzer. Converts YUV_420_888, rotates to display orientation,
 * then asks [FaceGeometry] for a template. Frames are closed by the caller
 * contract inside [analyze].
 */
class FaceFrameAnalyzer(
    private val onFrame: (FaceFrame) -> Unit,
) : ImageAnalysis.Analyzer {
    override fun analyze(image: ImageProxy) {
        try {
            if (image.format != ImageFormat.YUV_420_888 || image.planes.size < 3) {
                onFrame(FaceFrame(null))
                return
            }
            val small = decodeSmall(image, 160)
            val upright = small?.let { rotate(it, image.imageInfo.rotationDegrees) }
            val embedding = if (upright == null) {
                null
            } else {
                FaceGeometry.embed(upright.luma, upright.cb, upright.cr, upright.width, upright.height)
            }
            onFrame(FaceFrame(embedding))
        } catch (_: Exception) {
            onFrame(FaceFrame(null))
        } finally {
            image.close()
        }
    }
}

private class SmallFrame(
    val luma: IntArray,
    val cb: IntArray,
    val cr: IntArray,
    val width: Int,
    val height: Int,
)

private fun decodeSmall(image: ImageProxy, maxWidth: Int): SmallFrame? {
    val srcW = image.width
    val srcH = image.height
    if (srcW < 16 || srcH < 16) return null
    val scale = max(1, srcW / maxWidth)
    val dstW = srcW / scale
    val dstH = srcH / scale
    if (dstW < 16 || dstH < 16) return null
    val yPlane = image.planes[0]
    val uPlane = image.planes[1]
    val vPlane = image.planes[2]
    val yBuf = yPlane.buffer
    val uBuf = uPlane.buffer
    val vBuf = vPlane.buffer
    val luma = IntArray(dstW * dstH)
    val cb = IntArray(dstW * dstH)
    val cr = IntArray(dstW * dstH)
    for (dy in 0 until dstH) {
        val sy = min(srcH - 1, dy * scale)
        for (dx in 0 until dstW) {
            val sx = min(srcW - 1, dx * scale)
            val yIndex = sy * yPlane.rowStride + sx * yPlane.pixelStride
            val uvx = sx / 2
            val uvy = sy / 2
            val uIndex = uvy * uPlane.rowStride + uvx * uPlane.pixelStride
            val vIndex = uvy * vPlane.rowStride + uvx * vPlane.pixelStride
            val i = dy * dstW + dx
            if (yIndex < 0 || uIndex < 0 || vIndex < 0) continue
            if (yIndex >= yBuf.limit() || uIndex >= uBuf.limit() || vIndex >= vBuf.limit()) continue
            luma[i] = yBuf.get(yIndex).toInt() and 0xFF
            cb[i] = uBuf.get(uIndex).toInt() and 0xFF
            cr[i] = vBuf.get(vIndex).toInt() and 0xFF
        }
    }
    return SmallFrame(luma, cb, cr, dstW, dstH)
}

private fun rotate(frame: SmallFrame, degrees: Int): SmallFrame {
    val d = ((degrees % 360) + 360) % 360
    if (d == 0) return frame
    val w = frame.width
    val h = frame.height
    val nw = if (d == 90 || d == 270) h else w
    val nh = if (d == 90 || d == 270) w else h
    val luma = IntArray(nw * nh)
    val cb = IntArray(nw * nh)
    val cr = IntArray(nw * nh)
    for (y in 0 until h) {
        for (x in 0 until w) {
            val src = y * w + x
            val (nx, ny) = when (d) {
                90 -> h - 1 - y to x
                180 -> w - 1 - x to h - 1 - y
                270 -> y to w - 1 - x
                else -> x to y
            }
            val dst = ny * nw + nx
            luma[dst] = frame.luma[src]
            cb[dst] = frame.cb[src]
            cr[dst] = frame.cr[src]
        }
    }
    return SmallFrame(luma, cb, cr, nw, nh)
}
