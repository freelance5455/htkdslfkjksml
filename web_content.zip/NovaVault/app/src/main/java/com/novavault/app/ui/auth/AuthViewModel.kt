package com.novavault.app.ui.auth

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novavault.app.R
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.auth.BiometricGate
import com.novavault.app.domain.face.FaceGeometry
import com.novavault.app.domain.face.FaceTemplate
import com.novavault.app.domain.model.SecurityQuestion
import com.novavault.app.domain.repository.QuestionRepository
import com.novavault.app.domain.repository.SettingsRepository
import com.novavault.app.data.face.FaceTemplateStore
import com.novavault.app.ui.session.VaultAudio
import com.novavault.app.ui.session.VaultSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class FaceHint { SEARCHING, HOLD, MATCH, NO_FACE, NOT_ENROLLED }

data class AuthUi(
    val loading: Boolean = true,
    val questions: List<SecurityQuestion> = emptyList(),
    val index: Int = 0,
    val answer: String = "",
    @StringRes val errorRes: Int? = null,
    val errorText: String? = null,
    val faceOk: Boolean = false,
    val fingerOk: Boolean = false,
    val faceOpen: Boolean = false,
    val busy: Boolean = false,
    val granted: Boolean = false,
    val shake: Int = 0,
    val faceHint: FaceHint = FaceHint.SEARCHING,
)

class AuthViewModel(
    private val questions: QuestionRepository,
    private val settings: SettingsRepository,
    private val faceStore: FaceTemplateStore,
    private val session: VaultSession,
    private val audio: VaultAudio,
) : ViewModel() {
    private val _ui = MutableStateFlow(AuthUi())
    val ui: StateFlow<AuthUi> = _ui.asStateFlow()

    private var template: FaceTemplate? = null
    private var lastEmbed: FloatArray? = null
    private var stable = 0
    private var lastFrameAt = 0L
    private var advancing = false
    private var missAnnounced = false

    init {
        viewModelScope.launch {
            val prefs = settings.current()
            audio.enabled = prefs.audioEnabled
            template = if (prefs.faceEnrolled) withContext(Dispatchers.IO) { faceStore.load() } else null
            if (prefs.audioEnabled) audio.startAmbience()
            questions.observe().collect { list ->
                _ui.update { it.copy(loading = false, questions = list) }
            }
        }
    }

    fun onAnswer(value: String) {
        _ui.update { it.copy(answer = value, errorRes = null, errorText = null) }
    }

    fun submitText() {
        val state = _ui.value
        val question = state.questions.getOrNull(state.index) ?: return
        if (state.busy || state.granted || state.answer.isBlank()) return
        viewModelScope.launch {
            _ui.update { it.copy(busy = true, errorRes = null, errorText = null) }
            val ok = withContext(Dispatchers.Default) { questions.verify(question, state.answer) }
            if (ok) {
                advance()
            } else {
                audio.playIncorrect()
                _ui.update {
                    it.copy(
                        busy = false,
                        answer = "",
                        errorRes = R.string.incorrect,
                        shake = it.shake + 1,
                    )
                }
            }
        }
    }

    fun openFace() {
        val question = _ui.value.questions.getOrNull(_ui.value.index) ?: return
        if (!question.faceEnabled || _ui.value.granted) return
        missAnnounced = false
        stable = 0
        lastEmbed = null
        if (template == null) {
            _ui.update { it.copy(errorRes = R.string.face_not_set, faceHint = FaceHint.NOT_ENROLLED) }
            audio.playIncorrect()
            return
        }
        _ui.update { it.copy(faceOpen = true, faceHint = FaceHint.SEARCHING, errorRes = null, errorText = null) }
    }

    fun closeFace() {
        _ui.update { it.copy(faceOpen = false) }
    }

    fun onFaceFrame(embedding: FloatArray?) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastFrameAt < 160L) return
        lastFrameAt = now
        val state = _ui.value
        if (!state.faceOpen || state.granted || state.faceOk) return
        val question = state.questions.getOrNull(state.index) ?: return
        if (!question.faceEnabled) return
        val enrolled = template
        if (enrolled == null) {
            _ui.update { it.copy(faceHint = FaceHint.NOT_ENROLLED, errorRes = R.string.face_not_set) }
            return
        }
        if (embedding == null) {
            stable = 0
            missAnnounced = false
            _ui.update { it.copy(faceHint = FaceHint.NO_FACE) }
            return
        }
        val previous = lastEmbed
        lastEmbed = embedding
        stable = if (previous != null && FaceGeometry.cosine(previous, embedding) >= 0.94f) stable + 1 else 0
        if (stable < 2) {
            _ui.update { it.copy(faceHint = FaceHint.HOLD, errorRes = null) }
            return
        }
        if (FaceGeometry.matches(embedding, enrolled.vector)) {
            onFaceAccepted()
        } else if (!missAnnounced) {
            missAnnounced = true
            stable = 0
            audio.playIncorrect()
            _ui.update { it.copy(faceHint = FaceHint.NO_FACE, errorRes = R.string.face_mismatch, shake = it.shake + 1) }
        }
    }

    fun onFingerprintSuccess() {
        val state = _ui.value
        val question = state.questions.getOrNull(state.index) ?: return
        if (!question.fingerprintEnabled || state.granted) return
        _ui.update { it.copy(fingerOk = true, errorRes = null, errorText = null) }
        if (BiometricGate.shortcutGranted(question, state.faceOk, fingerOk = true)) advance()
    }

    fun onFingerprintError(message: String) {
        audio.playIncorrect()
        _ui.update { it.copy(errorText = message, errorRes = null, shake = it.shake + 1) }
    }

    fun finishUnlock() {
        session.unlock()
    }

    private fun onFaceAccepted() {
        val state = _ui.value
        val question = state.questions.getOrNull(state.index) ?: return
        _ui.update { it.copy(faceOk = true, faceOpen = false, faceHint = FaceHint.MATCH, errorRes = null) }
        if (BiometricGate.shortcutGranted(question, faceOk = true, fingerOk = state.fingerOk)) advance()
    }

    private fun advance() {
        if (advancing) return
        val state = _ui.value
        val next = state.index + 1
        if (next >= state.questions.size) {
            advancing = true
            audio.stopAmbience()
            audio.playSuccess()
            _ui.update {
                it.copy(busy = false, granted = true, faceOpen = false, errorRes = null, errorText = null)
            }
            return
        }
        audio.playCorrect()
        stable = 0
        missAnnounced = false
        lastEmbed = null
        _ui.update {
            it.copy(
                index = next,
                answer = "",
                busy = false,
                faceOk = false,
                fingerOk = false,
                faceOpen = false,
                errorRes = null,
                errorText = null,
            )
        }
    }

    override fun onCleared() {
        audio.stopAmbience()
        super.onCleared()
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory {
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return AuthViewModel(
                        questions = container.questions,
                        settings = container.settings,
                        faceStore = container.faceStore,
                        session = container.session,
                        audio = container.audio,
                    ) as T
                }
            }
        }
    }
}
