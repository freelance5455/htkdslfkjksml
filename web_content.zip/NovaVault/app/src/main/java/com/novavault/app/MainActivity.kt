package com.novavault.app

import android.content.Context
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import com.novavault.app.data.local.prefs.BootPrefs
import com.novavault.app.ui.navigation.NovaRoot
import com.novavault.app.ui.theme.NovaVaultTheme
import com.novavault.app.util.LocaleHelper

class MainActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase, BootPrefs.language(newBase)))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as NovaVaultApp).container
        setContent {
            NovaVaultTheme {
                NovaRoot(container = container, activity = this)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (isChangingConfigurations) return
        val container = (application as NovaVaultApp).container
        container.audio.stopAmbience()
        if (BootPrefs.appLock(this)) {
            container.session.lock()
        }
    }
}
