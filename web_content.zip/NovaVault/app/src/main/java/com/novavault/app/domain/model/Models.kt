package com.novavault.app.domain.model

enum class MediaKind { PHOTO, VIDEO }

enum class StorageMode { REFERENCE, PRIVATE_COPY }

enum class BiometricPolicy {
    FACE_ALONE,
    FINGERPRINT_ALONE,
    BOTH_REQUIRED,
}

enum class AppLanguage(val code: String) {
    EN("en"),
    FA("fa");

    companion object {
        fun from(code: String?): AppLanguage = if (code == FA.code) FA else EN
    }
}

enum class MediaFilter { ALL, PHOTOS, VIDEOS }

data class SecurityQuestion(
    val id: Long,
    val prompt: String,
    val answerHash: String,
    val salt: String,
    val iterations: Int,
    val faceEnabled: Boolean,
    val fingerprintEnabled: Boolean,
    val policy: BiometricPolicy,
    val sortOrder: Int,
)

data class QuestionDraft(
    val id: Long?,
    val prompt: String,
    val answer: String?,
    val faceEnabled: Boolean,
    val fingerprintEnabled: Boolean,
    val policy: BiometricPolicy,
)

data class MediaEntry(
    val id: Long,
    val displayName: String,
    val mimeType: String,
    val kind: MediaKind,
    val storageMode: StorageMode,
    val location: String,
    val thumbnail: String?,
    val sizeBytes: Long,
    val durationMs: Long,
    val addedAt: Long,
)

data class ImportSource(
    val uriString: String,
    val displayName: String,
    val mimeType: String,
    val kind: MediaKind,
    val sizeBytes: Long,
    val durationMs: Long,
)

data class ImportResult(
    val imported: Int,
    val failed: Int,
)

data class VaultPreferences(
    val storageMode: StorageMode = StorageMode.PRIVATE_COPY,
    val audioEnabled: Boolean = true,
    val language: AppLanguage = AppLanguage.EN,
    val appLockEnabled: Boolean = true,
    val setupComplete: Boolean = false,
    val faceEnrolled: Boolean = false,
)
