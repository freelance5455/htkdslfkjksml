package com.novavault.app.ui.auth

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novavault.app.R
import com.novavault.app.biometric.FingerprintAuthenticator
import com.novavault.app.di.AppContainer
import com.novavault.app.ui.common.pad2
import com.novavault.app.ui.face.CameraPreview
import com.novavault.app.ui.theme.Accent
import com.novavault.app.ui.theme.Navy
import com.novavault.app.ui.theme.NavyDeep
import com.novavault.app.ui.theme.NovaVaultTheme
import com.novavault.app.ui.theme.VaultMark
import kotlinx.coroutines.delay

@Composable
fun AuthScreen(container: AppContainer, activity: AppCompatActivity) {
    val epoch by container.session.epoch.collectAsState()
    val vm: AuthViewModel = viewModel(
        viewModelStoreOwner = activity,
        key = "auth-$epoch",
        factory = AuthViewModel.factory(container),
    )
    val ui by vm.ui.collectAsState()
    val fingerprint = remember(activity) { FingerprintAuthenticator(activity) }
    val shake = remember { Animatable(0f) }

    LaunchedEffect(ui.shake) {
        if (ui.shake == 0) return@LaunchedEffect
        repeat(4) {
            shake.animateTo(8f, tween(40))
            shake.animateTo(-8f, tween(40))
        }
        shake.animateTo(0f, tween(40))
    }
    LaunchedEffect(ui.granted) {
        if (ui.granted) {
            delay(1200)
            vm.finishUnlock()
        }
    }

    NovaVaultTheme(dark = true) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NavyDeep),
        ) {
            ScanLine()
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 18.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    VaultMark(Modifier.size(36.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 2.sp,
                        )
                        Text(
                            text = stringResource(R.string.splash_tag),
                            color = Accent,
                            style = MaterialTheme.typography.labelLarge,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                        )
                    }
                }
                Spacer(Modifier.height(28.dp))
                when {
                    ui.loading -> {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Accent)
                        }
                    }
                    ui.granted -> Granted()
                    ui.questions.isEmpty() -> {
                        Text(
                            text = stringResource(R.string.no_questions),
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                    else -> {
                        val question = ui.questions[ui.index.coerceIn(0, ui.questions.lastIndex)]
                        val total = ui.questions.size
                        val label = stringResource(
                            R.string.access_sequence,
                            pad2(ui.index + 1),
                            pad2(total),
                        )
                        Text(
                            text = label,
                            color = Accent,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 1.5.sp,
                        )
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { (ui.index + 1f) / total.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = Accent,
                            trackColor = Navy,
                        )
                        Spacer(Modifier.height(28.dp))
                        BracketFrame(
                            modifier = Modifier
                                .fillMaxWidth()
                                .graphicsLayer { translationX = shake.value },
                        ) {
                            Text(
                                text = question.prompt,
                                color = Color.White,
                                style = MaterialTheme.typography.headlineMedium,
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = stringResource(R.string.text_always),
                                color = Color.White.copy(alpha = 0.62f),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            if (question.faceEnabled || question.fingerprintEnabled) {
                                Spacer(Modifier.height(14.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (question.faceEnabled) {
                                        StatusPill(
                                            text = stringResource(if (ui.faceOk) R.string.face_ok else R.string.face_pending),
                                            on = ui.faceOk,
                                        )
                                    }
                                    if (question.fingerprintEnabled) {
                                        StatusPill(
                                            text = stringResource(if (ui.fingerOk) R.string.finger_ok else R.string.finger_pending),
                                            on = ui.fingerOk,
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(18.dp))
                            OutlinedTextField(
                                value = ui.answer,
                                onValueChange = vm::onAnswer,
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text(stringResource(R.string.answer_hint)) },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { vm.submitText() }),
                                colors = fieldColors(),
                            )
                            val message = ui.errorText ?: ui.errorRes?.let { stringResource(it) }
                            if (message != null) {
                                Spacer(Modifier.height(8.dp))
                                Text(text = message, color = MaterialTheme.colorScheme.error)
                            }
                            Spacer(Modifier.height(16.dp))
                            Button(
                                onClick = vm::submitText,
                                enabled = !ui.busy && ui.answer.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = NavyDeep),
                            ) {
                                Text(stringResource(R.string.verify))
                            }
                            if (question.faceEnabled || question.fingerprintEnabled) {
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    if (question.faceEnabled) {
                                        OutlinedButton(
                                            onClick = vm::openFace,
                                            modifier = Modifier.weight(1f).height(48.dp),
                                        ) {
                                            Icon(Icons.Filled.Face, contentDescription = null)
                                            Spacer(Modifier.width(6.dp))
                                            Text(stringResource(R.string.face_shortcut))
                                        }
                                    }
                                    if (question.fingerprintEnabled) {
                                        OutlinedButton(
                                            onClick = {
                                                fingerprint.authenticate(
                                                    onSuccess = vm::onFingerprintSuccess,
                                                    onError = vm::onFingerprintError,
                                                )
                                            },
                                            modifier = Modifier.weight(1f).height(48.dp),
                                        ) {
                                            Icon(Icons.Filled.Fingerprint, contentDescription = null)
                                            Spacer(Modifier.width(6.dp))
                                            Text(stringResource(R.string.fingerprint_shortcut))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (ui.faceOpen) {
                FaceOverlay(
                    hint = ui.faceHint,
                    onFrame = { vm.onFaceFrame(it.embedding) },
                    onClose = vm::closeFace,
                )
            }
        }
    }
}

@Composable
private fun Granted() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        VaultMark(Modifier.size(84.dp))
        Spacer(Modifier.height(18.dp))
        Text(
            text = stringResource(R.string.granted),
            color = Accent,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 2.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = stringResource(R.string.granted_sub),
            color = Color.White.copy(alpha = 0.75f),
        )
    }
}

@Composable
private fun FaceOverlay(
    hint: FaceHint,
    onFrame: (com.novavault.app.data.face.FaceFrame) -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    var allowed by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED,
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { allowed = it }
    Box(Modifier.fillMaxSize().background(NavyDeep)) {
        if (allowed) {
            CameraPreview(Modifier.fillMaxSize(), onFrame)
        }
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.face_check),
                    color = Color.White,
                    modifier = Modifier.weight(1f),
                    fontFamily = FontFamily.Monospace,
                )
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.close), tint = Color.White)
                }
            }
            Spacer(Modifier.weight(1f))
            if (!allowed) {
                Button(
                    onClick = { launcher.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = NavyDeep),
                ) { Text(stringResource(R.string.grant_camera)) }
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.camera_permission), color = Color.White.copy(alpha = 0.8f))
            }
            Text(
                text = stringResource(
                    when (hint) {
                        FaceHint.HOLD -> R.string.hold_still
                        FaceHint.MATCH -> R.string.face_ok
                        FaceHint.NO_FACE -> R.string.no_face
                        FaceHint.NOT_ENROLLED -> R.string.face_not_set
                        FaceHint.SEARCHING -> R.string.searching_face
                    },
                ),
                color = Accent,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Navy.copy(alpha = 0.82f), RoundedCornerShape(12.dp))
                    .padding(16.dp),
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun StatusPill(text: String, on: Boolean) {
    Text(
        text = text,
        color = if (on) NavyDeep else Color.White,
        modifier = Modifier
            .background(if (on) Accent else Navy, RoundedCornerShape(99.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        style = MaterialTheme.typography.labelLarge,
    )
}

@Composable
private fun BracketFrame(modifier: Modifier, content: @Composable () -> Unit) {
    Column(
        modifier = modifier
            .border(1.dp, Accent.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
            .padding(18.dp),
    ) {
        content()
    }
}

@Composable
private fun ScanLine() {
    val transition = rememberInfiniteTransition(label = "scan")
    val y by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
        label = "scan-y",
    )
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(2.dp)
                .graphicsLayer { translationY = y * 900f }
                .background(Accent.copy(alpha = 0.35f)),
        )
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    cursorColor = Accent,
    focusedBorderColor = Accent,
    unfocusedBorderColor = Color.White.copy(alpha = 0.35f),
    focusedLabelColor = Accent,
    unfocusedLabelColor = Color.White.copy(alpha = 0.7f),
    focusedContainerColor = Color.Transparent,
    unfocusedContainerColor = Color.Transparent,
)
