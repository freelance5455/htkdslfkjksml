package com.novavault.app.ui.gallery

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.novavault.app.R
import com.novavault.app.di.AppContainer
import com.novavault.app.domain.model.MediaEntry
import com.novavault.app.domain.model.MediaFilter
import com.novavault.app.domain.model.MediaKind
import com.novavault.app.domain.model.StorageMode
import com.novavault.app.ui.common.VaultTopBar
import com.novavault.app.ui.common.formatDuration
import com.novavault.app.ui.theme.Accent
import com.novavault.app.ui.theme.Ink
import com.novavault.app.ui.theme.Mist
import com.novavault.app.ui.theme.Navy
import com.novavault.app.ui.theme.NavyDeep
import java.io.File

@Composable
fun GalleryScreen(
    container: AppContainer,
    activity: AppCompatActivity,
    onImport: () -> Unit,
    onOpen: (Long, MediaFilter) -> Unit,
    onSettings: () -> Unit,
) {
    val vm: GalleryViewModel = viewModel(
        viewModelStoreOwner = activity,
        factory = GalleryViewModel.factory(container),
    )
    val items by vm.items.collectAsState()
    var filter by rememberSaveable { mutableStateOf(MediaFilter.ALL) }
    var pendingRemove by rememberSaveable { mutableStateOf<Long?>(null) }
    val visible = vm.visible(filter, items)

    Scaffold(
        containerColor = Mist,
        topBar = {
            VaultTopBar(
                title = stringResource(R.string.app_name),
                actions = {
                    IconButton(onClick = { container.session.lock(explicitly = true) }) {
                        Icon(Icons.Filled.Lock, contentDescription = stringResource(R.string.lock))
                    }
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings))
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onImport, containerColor = Accent, contentColor = NavyDeep) {
                Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.import_media))
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            FilterRow(filter = filter, onFilter = { filter = it })
            Text(
                text = stringResource(R.string.items_count, visible.size),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                color = Ink.copy(alpha = 0.7f),
                style = MaterialTheme.typography.bodyMedium,
            )
            if (visible.isEmpty()) {
                EmptyVault(Modifier.fillMaxSize().padding(32.dp))
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(visible, key = { it.id }) { item ->
                        MediaCell(
                            item = item,
                            model = thumbModel(container, item),
                            onClick = { onOpen(item.id, filter) },
                            onLongClick = { pendingRemove = item.id },
                        )
                    }
                }
            }
        }
    }

    pendingRemove?.let { id ->
        AlertDialog(
            onDismissRequest = { pendingRemove = null },
            title = { Text(stringResource(R.string.remove_from_vault)) },
            text = { Text(stringResource(R.string.remove_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    vm.remove(id)
                    pendingRemove = null
                }) { Text(stringResource(R.string.remove)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingRemove = null }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun FilterRow(filter: MediaFilter, onFilter: (MediaFilter) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        FilterChip(stringResource(R.string.filter_all), filter == MediaFilter.ALL) { onFilter(MediaFilter.ALL) }
        FilterChip(stringResource(R.string.filter_photos), filter == MediaFilter.PHOTOS) { onFilter(MediaFilter.PHOTOS) }
        FilterChip(stringResource(R.string.filter_videos), filter == MediaFilter.VIDEOS) { onFilter(MediaFilter.VIDEOS) }
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text = label,
        color = if (selected) NavyDeep else Ink,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(RoundedCornerShape(99.dp))
            .background(if (selected) Accent else ColorSurface())
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

@Composable
private fun ColorSurface() = MaterialTheme.colorScheme.surface

@Composable
private fun EmptyVault(modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(stringResource(R.string.gallery_empty_title), style = MaterialTheme.typography.titleLarge, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.gallery_empty_body),
            style = MaterialTheme.typography.bodyLarge,
            color = Ink.copy(alpha = 0.75f),
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MediaCell(item: MediaEntry, model: Any, onClick: () -> Unit, onLongClick: () -> Unit) {
    Box(
        Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(Navy.copy(alpha = 0.08f))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        AsyncImage(
            model = model,
            contentDescription = item.displayName,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
        if (item.kind == MediaKind.VIDEO) {
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .background(NavyDeep.copy(alpha = 0.72f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Filled.PlayArrow,
                    contentDescription = stringResource(R.string.cd_play),
                    tint = Accent,
                    modifier = Modifier.size(14.dp),
                )
                if (item.durationMs > 0) {
                    Text(formatDuration(item.durationMs), color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

internal fun thumbModel(container: AppContainer, item: MediaEntry): Any {
    val thumb = item.thumbnail
    if (!thumb.isNullOrBlank()) {
        val file = container.thumbFile(thumb)
        if (file.exists()) return file
    }
    return playbackUri(container, item) ?: File("")
}

internal fun playbackUri(container: AppContainer, item: MediaEntry): Uri? {
    return when (item.storageMode) {
        StorageMode.REFERENCE -> Uri.parse(item.location)
        StorageMode.PRIVATE_COPY -> {
            val file = container.privateFile(item.location)
            if (file.exists()) Uri.fromFile(file) else null
        }
    }
}
