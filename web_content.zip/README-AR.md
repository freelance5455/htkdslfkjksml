# Fideo — Professional Android v1

نسخة Android جديدة ونظيفة لتطبيق Fideo، مبنية على Supabase الحقيقي.

## ما تم تغييره
- لا توجد فيديوهات تجريبية أو روابط فيديو خارجية.
- الخلاصة تقرأ فقط من `public.videos` بحالة `published`.
- اختيار الفيديو يستخدم Android `ACTION_OPEN_DOCUMENT` ويقبل فيديو واحدًا.
- رفع الفيديو إلى Storage bucket `videos` ثم إنشاء سجل في `public.videos`.
- التعليقات تستخدم العمود الصحيح `content`.
- الصور الشخصية تُرفع إلى bucket `avatars`.
- تسجيل الدخول/التسجيل والحسابات والمتابعة والإعجاب والمشاركة والتعليقات والبحث مرتبطة بـ Supabase.
- لا توجد لوحة Admin داخل تطبيق المستخدم.
- LIVE لا يعرض غرفًا وهمية؛ يوضح أن مزود بث حقيقي + token server مطلوبان قبل تفعيل LIVE.

## التشغيل
المشروع Android Gradle Project. يلزم Android SDK/Gradle أو GitHub Actions لبناء APK.
