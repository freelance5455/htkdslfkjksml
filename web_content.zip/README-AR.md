# تحويل التطبيق إلى APK

هذا المجلد يحتوي تطبيقك كـ **PWA** جاهز: `index.html` في الجذر + `manifest.json` + `sw.js` + أيقونات.
كل شيء محلي (بدون إنترنت ولا CDN)، والبيانات تُحفظ في `localStorage` فتبقى بعد التثبيت.

## الطريقة 1 — محوّل مجاني على الإنترنت (الأسهل، 3 دقائق)
1. حمّل ملف `DJEBAILI-CALCULATEUR-APK.zip` وفكّ ضغطه.
2. اضغط المجلد كاملًا مرة أخرى بصيغة ZIP (بدون مجلد إضافي داخل الأرشيف — `index.html` لازم يكون في الجذر).
3. اذهب إلى **WebIntoApp** (webintoapp.com) أو **AppsGeyser** أو **Median.co** → اختر "HTML / Website to APK" → ارفع ملف ZIP.
4. املأ: اسم التطبيق `DJEBAILI Calculateur`، معرّف الحزمة `dj.djebaili.calculateur`، الأيقونة = `icons/icon-512.png`.
5. اختر **Offline / local files** (مهم جدًا، وليس URL) ثم Download APK.
6. على الهاتف: فعّل "تثبيت من مصادر غير معروفة" ثم ثبّت الملف.

## الطريقة 2 — Capacitor + Android Studio (احترافية، APK بتوقيعك)
```bash
npm install -g @capacitor/cli
npm init -y
npm i @capacitor/core @capacitor/android
mkdir www && cp -r index.html manifest.json sw.js icons www/
npx cap init "DJEBAILI Calculateur" dj.djebaili.calculateur --web-dir=www
npx cap add android
npx cap sync
npx cap open android
```
ثم في Android Studio: **Build > Build Bundle(s)/APK(s) > Build APK(s)**.
ملف `capacitor.config.json` المرفق جاهز للاستخدام.

## الطريقة 3 — Cordova
```bash
cordova create djeb dj.djebaili.calculateur "DJEBAILI Calculateur"
# انسخ index.html و manifest.json و sw.js و icons إلى مجلد www/
cordova platform add android
cordova build android
```

## ملاحظات
- شهادة HTTPS غير مطلوبة داخل WebView؛ عامل الخدمة (offline) يعمل فقط عند الفتح عبر http/https، والتطبيق يعمل بدونه أيضًا.
- لتغيير الأيقونة بعد التوليد: استبدل `icons/icon-512.png` قبل الرفع.
- الإصدار: 3.0 — يحتوي «سنوات معلّقة»، «استرجاع مضاف»، تنقّل تفاعلي، وحساب مباشر.
