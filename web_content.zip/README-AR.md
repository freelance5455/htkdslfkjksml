# تطبيق فيديو — منصة فيديو اجتماعية

نسخة Android جاهزة للربط بخادم Supabase، مع واجهة فيديو عمودية، حسابات، رفع فيديو، إعجابات، لوحة إدارة، وتهيئة LIVE.

## التشغيل الحقيقي
1. أنشئ مشروع Supabase.
2. نفّذ `supabase/schema.sql` كاملًا في SQL Editor.
3. أنشئ حساب مستخدم من التطبيق ثم امنحه دور `admin` عبر SQL.
4. ضع Project URL وAnon Key في `app/src/main/assets/config.js` و`admin/config.js`.
5. استضف مجلد `admin/` على HTTPS.
6. لبث LIVE الحقيقي اربط LiveKit/Agora من خلال خادم أو Edge Function؛ لا تضع مفاتيح سرية داخل APK.

## ملاحظات
- لا تضع Service Role Key داخل التطبيق.
- Storage مهيأ لرفع الفيديوهات والصور.
- التطبيق يعمل بوضع تجريبي محلي إذا لم يتم ضبط Supabase.
