// Example secure proxy (Cloudflare Worker). Deploy this on YOUR server,
// set the secret OPENAI_API_KEY in the Worker settings (never in this file),
// then put the Worker URL in DRIP AI → Settings → Secure server proxy.
//
// Set ALLOWED_ORIGIN to the URL where you host DRIP AI.
const ALLOWED_ORIGIN = "https://your-drip-ai-site.example.com";
const UPSTREAM = "https://api.openai.com/v1/chat/completions";

export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return new Response("Method not allowed", { status: 405, headers: cors });
    const body = await request.text();
    const upstream = await fetch(UPSTREAM, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + env.OPENAI_API_KEY },
      body,
    });
    return new Response(upstream.body, {
      status: upstream.status,
      headers: { ...cors, "Content-Type": upstream.headers.get("Content-Type") || "application/json" },
    });
  },
};
