# Navi AI – Tu asistente personal estilo Grok

## 1. Obtén tu API Key de xAI

1. Entra a → https://console.x.ai
2. Crea una cuenta (o inicia sesión)
3. Añade créditos (no hay plan gratuito para la API)
4. Ve a **API Keys** → Create API Key
5. Copia la clave (solo se muestra una vez)

## 2. Instala y corre el backend

```bash
# En la carpeta de Navi
npm install

# Crea el archivo .env
cp .env.example .env
# Edita .env y pega tu XAI_API_KEY

# Arranca el servidor
npm start
```

Verás algo como:
```
🚀 Navi AI corriendo en http://localhost:3000
```

## 3. Úsala en el celular

### Opción A – Misma red WiFi (más fácil)
1. En tu computadora anota la IP local (ej: 192.168.1.45)
2. En `config.js` cambia:
   ```js
   API_URL: "http://192.168.1.45:3000/chat"
   ```
3. En el celular abre el navegador y ve a `http://192.168.1.45:3000`

### Opción B – App Android (recomendado para voz)
- Usa un WebView que cargue tu servidor
- Implementa `window.NaviNative.listen()` y `window.NaviNative.speak()`
  (ya está preparado en el código)

### Opción C – Desplegar en internet (gratis/barato)
- Railway, Render, Fly.io o Vercel
- Sube la carpeta, pon la variable de entorno `XAI_API_KEY`
- Cambia `API_URL` en `config.js` a tu URL pública

## 4. Personalidad

El system prompt ya tiene la personalidad **Grok original**:
- Directa e ingeniosa
- Humor seco
- Truth-seeking
- Responde en español

Puedes editarlo en `server.js` (constante `SYSTEM_PROMPT`).

## 5. Modelos disponibles (elige en server.js)

- `grok-4` o `grok-4.7` → más potente
- `grok-4-1-fast-reasoning` → más rápido y barato
- Revisa precios en https://docs.x.ai

## Seguridad

- **Nunca** pongas la API key en el frontend (config.js o index.html)
- Solo el backend (`server.js`) debe tener la clave
- No compartas tu `.env`
