# Meme Filter — phone prototype

This is a starter web app, not yet a packaged APK.

## Try it on Android
1. Put `index.html` on a static HTTPS host (for example, a simple web IDE/hosting service).
2. Open its HTTPS URL in Chrome on Android.
3. Allow camera and microphone permissions.
4. Choose a filter image with **Choose filter image**.
5. Tap the red circle for a photo; hold it to record, then release.
6. Use **Save photo** or **Save video**.

## Current limitations
- The filter image is currently drawn as a centered overlay, not face-tracked.
- The hair/background buttons are interface placeholders. Real hide/show requires image segmentation and separate transparent layers.
- Video saves as WebM in supported browsers; compatibility varies.
- To make an APK, wrap this web app with an Android WebView/Capacitor project and build/sign it in an Android build environment.
