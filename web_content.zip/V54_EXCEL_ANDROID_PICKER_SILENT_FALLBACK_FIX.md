# V54 — Excel Android Picker Silent-Failure Fix

Built from V53.

- Fixes the Android Excel picker case where DocumentsUI accepts an intent but does not visibly open, so V53 never reaches its exception-based fallback.
- Choose File now tries the standard Android content picker, then an explicit DocumentsUI package when available, then a final OPEN_DOCUMENT fallback.
- Each picker attempt uses a separate result request code, while the existing native XLSX/CSV parsing and preview/import flow remain unchanged.
- Download Excel template, Supabase logic, login, balance, banked entries and other app features are preserved.
- Android versionCode 26 / versionName 2.22.
