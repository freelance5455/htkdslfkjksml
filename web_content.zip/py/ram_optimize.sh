# Called by the bundled Android sh interpreter.
# Best-effort memory trim requests only; never force-stop applications.
GAME="$1"
HOME_PKG="$(cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | tail -n 1 | cut -d/ -f1)"
TRIMMED=0
for P in $(pm list packages -3 2>/dev/null | sed 's/^package://'); do
  [ -n "$P" ] || continue
  [ "$P" = "$GAME" ] && continue
  [ "$P" = "$HOME_PKG" ] && continue
  case "$P" in
    *whatsapp*|*telegram*|*messenger*|*signal*|*discord*|*wechat*|*viber*|*line*|*kakaotalk*|*com.google.android.gms*|*com.google.android.gsf*) continue ;;
  esac
  PIDS="$(pidof "$P" 2>/dev/null)"
  for PID in $PIDS; do
    case "$PID" in ''|*[!0-9]*) continue ;; esac
    am send-trim-memory "$PID" MODERATE >/dev/null 2>&1 && TRIMMED=$((TRIMMED+1))
  done
done
printf 'trim_requests=%s game=%s\n' "$TRIMMED" "$GAME"
