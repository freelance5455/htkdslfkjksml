#!/system/bin/sh
# Shelby Thermal Auto - preserve original thermal property behavior; optional per-game profiles.
MODDIR=${0%/*}
BASE=/data/adb/shelby_thermal_auto
CONFIG="$BASE/games.list"
ENABLED="$BASE/auto_enabled"
INTERVAL="$BASE/interval"
PROP="persist.sys.shelby.thermal_disabled"
PROFILES="$BASE/profiles"
STATE="$BASE/runtime_state"
LOG="$BASE/service.log"
mkdir -p "$BASE" "$PROFILES"
log(){ printf '[%s] %s\n' "$(date '+%F %T' 2>/dev/null)" "$*" >> "$LOG"; [ -f "$LOG" ] && [ "$(wc -c < "$LOG" 2>/dev/null)" -gt 262144 ] && tail -n 800 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"; }
[ -f "$CONFIG" ] || : > "$CONFIG"
[ -f "$ENABLED" ] || echo 1 > "$ENABLED"
[ -f "$INTERVAL" ] || echo 3 > "$INTERVAL"
LAST_THERMAL=""
ACTIVE=""
BG_LAST=0
KILL_LAST=0
setval(){ [ "$1" = "$LAST_THERMAL" ] || { setprop "$PROP" "$1"; LAST_THERMAL="$1"; }; }
readcfg(){ CFG_PKG="$1"; CFG_GOV_ENTER=""; CFG_GOV_EXIT=""; CFG_BG=0; CFG_KILL=0; CFG_CE=0; CFG_CX=0; CFG_CELMIN=""; CFG_CELMAX=""; CFG_CEBMIN=""; CFG_CEBMAX=""; CFG_CXLMIN=""; CFG_CXLMAX=""; CFG_CXBMIN=""; CFG_CXBMAX=""; OLD_GOV=""; OLD_GOVON=0; F="$PROFILES/$CFG_PKG.conf"; [ -f "$F" ] || return 0; while IFS='=' read -r K V; do case "$K" in govEnter) CFG_GOV_ENTER="$V";; govExit) CFG_GOV_EXIT="$V";; gov) OLD_GOV="$V";; govOn) OLD_GOVON="$V";; bg|ramOptimize) CFG_BG="$V";; killBackground) CFG_KILL="$V";;
clusterEnterOn) CFG_CE="$V";; clusterExitOn) CFG_CX="$V";;
clusterEnterLittleMin) CFG_CELMIN="$V";; clusterEnterLittleMax) CFG_CELMAX="$V";;
clusterEnterBigMin) CFG_CEBMIN="$V";; clusterEnterBigMax) CFG_CEBMAX="$V";;
clusterExitLittleMin) CFG_CXLMIN="$V";; clusterExitLittleMax) CFG_CXLMAX="$V";;
clusterExitBigMin) CFG_CXBMIN="$V";; clusterExitBigMax) CFG_CXBMAX="$V";; esac; done < "$F"; if [ -z "$CFG_GOV_ENTER" ] && [ "${OLD_GOVON:-0}" = 1 ]; then CFG_GOV_ENTER="${OLD_GOV:-}"; fi; }
write_governor(){ TARGET_GOV="$1"; TARGET_PKG="$2"; [ -n "$TARGET_GOV" ] || { log "Governor unchanged for ${TARGET_PKG:-no active game}"; return 0; }; GOV_OK=0; GOV_FAIL=0; for F in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do [ -r "$F" ] || continue; if [ -w "$F" ] && echo "$TARGET_GOV" > "$F" 2>/dev/null; then GOV_OK=$((GOV_OK+1)); else GOV_FAIL=$((GOV_FAIL+1)); fi; done; log "Governor $TARGET_GOV for ${TARGET_PKG:-no active game} (written=$GOV_OK failed=$GOV_FAIL)"; }
# Map the lowest-maximum-frequency policy to Little and highest to Big.
policy_for_cluster(){ WANT="$1"; DATA=""; for P in /sys/devices/system/cpu/cpufreq/policy[0-9]*; do [ -d "$P" ] || continue; MX="$(cat "$P/cpuinfo_max_freq" 2>/dev/null)"; case "$MX" in ''|*[!0-9]*) continue;; esac; DATA="${DATA}${MX} ${P}\n"; done; [ -n "$DATA" ] || return 1; SORTED="$(printf '%b' "$DATA" | sort -n)"; case "$WANT" in little) printf '%s\n' "$SORTED" | head -n 1 | awk '{print $2}';; big) printf '%s\n' "$SORTED" | tail -n 1 | awk '{print $2}';; esac; }
write_cluster_one(){ CL="$1"; WANT_MIN="$2"; WANT_MAX="$3"; PKG="$4"; case "$WANT_MIN:$WANT_MAX" in *[!0-9:]*|:*) log "Cluster $CL skipped for $PKG: invalid frequency"; return;; esac; [ "$WANT_MIN" -le "$WANT_MAX" ] || { log "Cluster $CL skipped for $PKG: min exceeds max"; return; }; P="$(policy_for_cluster "$CL")"; [ -n "$P" ] || { log "Cluster $CL skipped for $PKG: policy unavailable"; return; }; LO="$(cat "$P/cpuinfo_min_freq" 2>/dev/null)"; HI="$(cat "$P/cpuinfo_max_freq" 2>/dev/null)"; case "$LO:$HI" in *[!0-9:]*|:*) log "Cluster $CL skipped for $PKG: kernel bounds unavailable"; return;; esac; [ "$WANT_MIN" -ge "$LO" ] || WANT_MIN="$LO"; [ "$WANT_MAX" -le "$HI" ] || WANT_MAX="$HI"; [ "$WANT_MIN" -le "$WANT_MAX" ] || { log "Cluster $CL skipped for $PKG: outside kernel bounds"; return; }; CURMIN="$(cat "$P/scaling_min_freq" 2>/dev/null)"; CURMAX="$(cat "$P/scaling_max_freq" 2>/dev/null)"; OK=0; if [ -n "$CURMIN" ] && [ "$WANT_MAX" -lt "$CURMIN" ]; then echo "$WANT_MIN" > "$P/scaling_min_freq" 2>/dev/null && echo "$WANT_MAX" > "$P/scaling_max_freq" 2>/dev/null && OK=1; else echo "$WANT_MAX" > "$P/scaling_max_freq" 2>/dev/null && echo "$WANT_MIN" > "$P/scaling_min_freq" 2>/dev/null && OK=1; fi; log "Cluster $CL $P for $PKG min=$WANT_MIN max=$WANT_MAX ok=$OK"; }
apply_cluster(){ MODE="$1"; PKG="$2"; if [ "$MODE" = enter ]; then ON="$CFG_CE"; LMIN="$CFG_CELMIN"; LMAX="$CFG_CELMAX"; BMIN="$CFG_CEBMIN"; BMAX="$CFG_CEBMAX"; else ON="$CFG_CX"; LMIN="$CFG_CXLMIN"; LMAX="$CFG_CXLMAX"; BMIN="$CFG_CXBMIN"; BMAX="$CFG_CXBMAX"; fi; [ "$ON" = 1 ] || { log "CPU Cluster $MODE OFF for $PKG; no frequency write"; return 0; }; LP="$(policy_for_cluster little)"; BP="$(policy_for_cluster big)"; [ -n "$LP" ] && [ -n "$BP" ] && [ "$LP" != "$BP" ] || { log "CPU Cluster $MODE skipped for $PKG: two distinct CPU policies unavailable"; return 0; }; write_cluster_one little "$LMIN" "$LMAX" "$PKG ($MODE)"; write_cluster_one big "$BMIN" "$BMAX" "$PKG ($MODE)"; }

restore(){
  [ -n "$ACTIVE" ] || return
  PREVIOUS="$ACTIVE"; readcfg "$PREVIOUS"; write_governor "$CFG_GOV_EXIT" "$PREVIOUS (exit)"; apply_cluster exit "$PREVIOUS"
  rm -rf "$STATE"; ACTIVE=""; BG_LAST=0; KILL_LAST=0
}
apply(){
  PKG="$1"; [ -n "$PKG" ] || return
  mkdir -p "$STATE"; readcfg "$PKG"
  write_governor "$CFG_GOV_ENTER" "$PKG (enter)"; apply_cluster enter "$PKG"
  ACTIVE="$PKG"; BG_LAST=0; KILL_LAST=0
  log "Applied profile for $PKG (enter_gov=${CFG_GOV_ENTER:-unchanged}, exit_gov=${CFG_GOV_EXIT:-unchanged}, cluster_enter=$CFG_CE, cluster_exit=$CFG_CX, ram=$CFG_BG)"
}
log "Service started; preserving Shelby thermal property behavior"
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
while true; do
  AUTO="$(cat "$ENABLED" 2>/dev/null)"
  TOP="$(dumpsys activity activities 2>/dev/null | grep -E 'mResumedActivity|topResumedActivity|mFocusedActivity' | head -n 8)"
  [ -n "$TOP" ] || TOP="$(dumpsys window 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | head -n 3)"
  GAME=""
  if [ "$AUTO" = 1 ]; then while IFS= read -r PKG; do case "$PKG" in ""|\#*) continue;; esac; echo "$TOP" | grep -Fq "$PKG" && { GAME="$PKG"; break; }; done < "$CONFIG"; fi
  if [ -n "$GAME" ]; then setval 1; else setval 0; fi
  if [ "$GAME" != "$ACTIVE" ]; then
    [ -n "$ACTIVE" ] && log "Foreground game changed: $ACTIVE -> ${GAME:-none}"
    restore
    [ -n "$GAME" ] && apply "$GAME"
  fi
  if [ -n "$GAME" ] && [ "$GAME" = "$ACTIVE" ]; then
    readcfg "$GAME"
    if [ "$CFG_BG" = 1 ]; then NOW="$(date +%s)"; if [ "$BG_LAST" = 0 ] || [ $((NOW-BG_LAST)) -ge 300 ]; then
      # Use the provided Android sh binary as interpreter for the RAM trim helper.
      # Helper sends best-effort trim requests to app PIDs; it never force-stops apps.
      RAM_RESULT="$("$MODDIR/bin/sh" "$MODDIR/ram_optimize.sh" "$GAME" 2>&1)"
      RAM_RC=$?
      log "RAM optimize pass for $GAME (rc=$RAM_RC): $RAM_RESULT"
      BG_LAST="$NOW"
    fi; fi
    if [ "$CFG_KILL" = 1 ]; then NOW="$(date +%s)"; if [ "$KILL_LAST" = 0 ] || [ $((NOW-KILL_LAST)) -ge 300 ]; then
      # Ask Android to kill only background processes it considers safe to kill.
      # Scope is limited to third-party packages; never target the active game.
      KILL_COUNT=0; KILL_FAIL=0
      while IFS= read -r LINE; do
        PKG="${LINE#package:}"
        case "$PKG" in ""|"$GAME") continue;; esac
        case "$PKG" in *.*) ;; *) continue;; esac
        if am kill "$PKG" >/dev/null 2>&1; then KILL_COUNT=$((KILL_COUNT+1)); else KILL_FAIL=$((KILL_FAIL+1)); fi
      done <<EOF
$(pm list packages -3 2>/dev/null)
EOF
      log "Kill background pass for $GAME (requested=$KILL_COUNT skipped_or_failed=$KILL_FAIL)"
      KILL_LAST="$NOW"
    fi; fi
  fi
  S="$(cat "$INTERVAL" 2>/dev/null)"; case "$S" in 2|3|5) ;; *) S=3;; esac; sleep "$S"
done
