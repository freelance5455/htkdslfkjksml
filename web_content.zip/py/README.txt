Shelby Thermal Auto KSUNext V2.6.2 — User Apps + Optimize RAM via bundled sh (No DND, No Internet Speed; per-APK governor on game enter/exit + Kill Background)

Changes in V2.6:
- Removed the Kecepatan Internet tab and all internet speed-test code.

Changes carried forward from V2.5:
- Tweak page scans third-party/user-installed packages only; system packages are hidden.
- Tap an app row to open its per-APK profile.
- Replaced background-app closing with an independent Optimize RAM toggle per APK. New profiles default to OFF.
- When enabled for a selected game, the service runs the bundled Android ARM64 `bin/sh` interpreter every 5 minutes to execute `ram_optimize.sh`. The helper attempts moderate trim-memory requests for running third-party app PIDs, excluding the selected game, launcher, messaging, and common push packages. It never uses force-stop.
- Removed Do Not Disturb controls and all DND-changing/restoring behavior from the WebUI and service.
- Each APK profile has independent Governor saat masuk game and Governor saat keluar game selections. Empty selections leave the current governor unchanged.
- On game exit or direct switch to another game, the previous APK exit governor is applied before the next APK enter governor. There is no hard-coded schedutil reset.
- Governor writes are best-effort; the selected governor must be exposed and permitted by the kernel on the relevant CPU policy nodes.

Notes:
- App labels/icons are not exposed by the shell-only WebUI API in a portable way, so the list displays a package-derived name and initial badge; package names are exact.
- The bundled `bin/sh` is an Android ARM64 executable linked against `/system/bin/linker64`; it is used as a shell interpreter, not as a standalone RAM-cleaning algorithm. Android/kernel behavior varies. `am send-trim-memory` may be unavailable or ignored on some builds; failures are non-fatal. This is best-effort and does not guarantee more free RAM or higher FPS.
- No app is force-stopped by Optimize RAM. The ZIP has not been tested on the user's physical device. Keep a backup and verify behavior after installing.

V2.6.2 test build: includes the user-provided `sh` binary and invokes it only when the per-game Optimize RAM profile is ON. Verify logs at /data/adb/shelby_thermal_auto/service.log.


V2.6.3 additions:
- Added an independent ON/OFF switch named “Kill Background” in each APK profile.
- When enabled for the active selected game, every 5 minutes the service runs `am kill` against third-party packages (`pm list packages -3`), excluding the active game. Android only kills processes it considers safe to kill; this is not `force-stop` and may leave protected/foreground processes running.
- Kill Background is separate from Optimize RAM and defaults to OFF for profiles without the setting.
- The ZIP has not been tested on the user's physical device. Verify on one game first.


V2.6.4 additions — Per-App CPU Cluster:
- Added separate “CPU Cluster saat masuk game” and “CPU Cluster saat keluar game” sections in each APK profile.
- Each section has its own ON/OFF toggle. OFF locks its Little/Big controls and the service performs no CPU-frequency writes for that condition.
- Each Little and Big cluster has minimum and maximum frequency sliders, with MHz labels. The UI reads the kernel cpuinfo_min_freq/cpuinfo_max_freq limits from cpufreq policies and keeps sliders within those bounds; it does not offer overclock values beyond the kernel-reported limits.
- The service maps the lowest-maximum-frequency policy to Little and highest-maximum-frequency policy to Big. It applies the selected min/max limits on game enter and on game exit only when the matching toggle is ON. If two distinct policies or valid kernel bounds are unavailable, the cluster write is skipped and logged.
- Cluster values are saved in the existing per-APK profile file. Existing Governor, Optimize RAM, Kill Background, game detection, and Shelby thermal-property behavior are retained.
- Important: CPU frequency controls can affect heat, battery use, stability, and performance. Start with conservative values inside the displayed kernel range and test one app at a time. This build has syntax-checked scripts but has not been physically tested on the Infinix device.
