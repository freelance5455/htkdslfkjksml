#!/system/bin/sh
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true

ui_print "*******************************"
ui_print "* SOREN ENGINE 3.1            *"
ui_print "* GD Pro Edition              *"
ui_print "* 1000hz - 8000hz Feel        *"
ui_print "*******************************"
ui_print "- Checking Shizuku Next version"
if [ "$(getprop ro.build.version.sdk)" -lt 33 ]; then
  ui_print "! Android 13+ required"
  abort
fi
ui_print "- Setting permissions"
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/action.sh 0 0 0755
ui_print "- Installing Enhanced Tweaks"
mkdir -p /data/local/tmp/soren_31
echo "3.1" > /data/local/tmp/soren_31/version
ui_print "- Done. Enable in Shizuku Next > Modules"
ui_print "- GD will feel lighter after reboot"