#!/system/bin/sh
MODDIR=${0%/*}
SOREN_DIR="/data/local/tmp/soren_31"
LOG="$SOREN_DIR/service.log"
mkdir -p $SOREN_DIR
echo "[SOREN 3.1] service.sh boot" > $LOG

run() { echo "RUN: $1" >> $LOG; sh -c "$1" 2>>$LOG; }

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 1; done
sleep 2

# --- DISPLAY 60hz -> 1000-8000 feel ---
run "settings put system peak_refresh_rate 120"
run "settings put system min_refresh_rate 60"
run "settings put system user_refresh_rate 60"
run "settings put secure refresh_rate_mode 0"
run "settings put system display_tune 1"
run "cmd display set-match-content-frame-rate 0"
run "settings put global vsync_offsets 0"
run "settings put secure touch_blocking_period 0.0"

# --- TOUCH ENHANCED 3.1 ---
run "settings put system pointer_speed 7"
run "settings put secure long_press_timeout 110"
run "settings put secure multi_press_timeout 100"
run "settings put secure tap_gesture_enabled 0"
run "settings put secure block_untrusted_touches 0"
run "settings put secure swipe_bottom_to_notification_enabled 0"
run "settings put secure double_tap_to_wake 0"
run "settings put system double_tap_to_sleep 0"
run "settings put system touch_sensitivity_mode 1"
run "settings put system game_touch_sensitivity 2"
run "settings put system touch_response 0"
run "settings put system swipe_touch_slop 4"

run "device_config put input_native_boot use_touch_resampling true"
run "device_config put input_native_boot use_touch_velocity_control false"
run "device_config put input_native_boot use_filtering false"
run "device_config put input_native_boot use_velocity_tracker false"
run "device_config put input_native_boot touch_slop 1.5"
run "device_config put input_native_boot tap_slop 1.5"
run "device_config put input_native_boot double_tap_slop 35.0"
run "device_config put input_native_boot double_tap_touch_slop 8.0"
run "device_config put input_native_boot double_tap_min_time 0"
run "device_config put input_native_boot enable_palm_rejection false"
run "device_config put input_native_boot enable_stylus_palm_rejection false"
run "device_config put input_native_boot long_press_timeout 140"
run "device_config put input_native_boot tap_timeout 70"
run "device_config put input_native_boot drag_min_switch_speed 0"
run "device_config put input_native_boot swipe_touch_slop 4.5"
run "device_config put input_native_boot touch_pressure_scale 0.55"
run "device_config put input_native_boot maximum_obscuring_opacity_for_touch 1.0"

run "cmd input set-report-rate 8000 2>/dev/null || true"
run "cmd input set-report-rate 1000 2>/dev/null || true"
run "cmd input set-motion-predictor-disabled 1 2>/dev/null || true"

# --- PERFORMANCE / ANTI-STUTTER ---
run "cmd power set-adaptive-power-saver-enabled false"
run "cmd power set-mode 0"
run "cmd power set-fixed-performance-mode-enabled true"
run "settings put global adaptive_battery_management_enabled 0"
run "settings put global app_standby_enabled 0"
run "settings put global background_activity_starts 1"
run "settings put global animator_duration_scale 0.3"
run "settings put global window_animation_scale 0.2"
run "settings put global transition_animation_scale 0.3"
run "device_config put activity_manager_native_boot use_freezer false"
run "device_config put activity_manager_native_boot enable_automatic_system_server_jank 0"
run "device_config put game_overlay use_angle true"
run "device_config put game_overlay enable_perf_hint true"
run "device_config put power_manager_native_boot no_cached true"

# --- THERMAL SAFE BYPASS ---
run "cmd thermalservice override-status 0"
run "cmd thermalservice reset 2>/dev/null || true"
run "device_config put thermal mitigation_enabled false"
run "settings put global thermal_throttling_enabled 0"

# --- UNIVERSAL GAME BOOST ---
for pkg in com.roblox.client com.roblox.client.vng com.Mojang.MinecraftPE com.activision.callofduty.shooter com.mobile.legends com.garena.game.codm com.dts.freefireth com.EToH.Game com.supercell.clashofclans com.robtopx.geometryjump com.geode.launcher; do
  run "cmd game set --perf true $pkg"
  run "cmd game set --fps 60 $pkg"
  run "cmd game set --no-battery true $pkg"
done

# --- GD SPECIAL 3.1 - GOD MODE ---
for GD in com.robtopx.geometryjump com.robtopx.geometryjumplite com.robtopx.geometryjumpworld com.geode.launcher; do
  run "cmd game set --perf true $GD"
  run "cmd game set --fps 60 $GD"
  run "cmd game set --no-battery true $GD"
  run "cmd appops set $GD RUN_IN_BACKGROUND allow"
  run "cmd game set --downscale 0 $GD"
done

echo "[SOREN 3.1] ACTIVE - 1000-8000hz FEEL | GD Pro MODE" >> $LOG