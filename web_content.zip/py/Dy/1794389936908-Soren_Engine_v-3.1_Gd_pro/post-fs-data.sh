#!/system/bin/sh
MODDIR=${0%/*}
SOREN_LOG="/data/local/tmp/soren_31/boot.log"
mkdir -p /data/local/tmp/soren_31
echo "[SOREN 3.1] post-fs-data start" > $SOREN_LOG

# Early props - must be set before surfaceflinger starts
setprop debug.sf.disable_hwc_overlays 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.high_fps_early_phase_offset_ns 0
setprop debug.sf.high_fps_late_phase_offset_ns 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.early_gl_phase_offset_ns 0
setprop debug.sf.early_app_phase_offset_ns 0
setprop debug.sf.early_sf_phase_offset_ns 0
setprop debug.sf.show_updates 0

# Early touch props for 1000hz-8000hz feel
setprop ro.vendor.touch.sampling_rate 8000
setprop ro.vendor.perf.touch_wakeup 1
setprop persist.vendor.input.report_rate 8000
setprop vendor.touch.report_rate 8000
setprop vendor.input.report_rate 8000
setprop persist.vendor.touch.report_rate 8000
setprop ro.vendor.touch.pressure.scale 0.55
setprop debug.hwui.renderer skiavk
setprop debug.renderengine.backend skiavkthreaded
setprop persist.sys.use_experimental_render_engine true
setprop debug.hwui.disable_vsync true
setprop persist.sys.sf.stc_uid 0
setprop vendor.thermal.config 0
setprop sys.thermal.enable false

echo "[SOREN 3.1] post-fs-data done" >> $SOREN_LOG