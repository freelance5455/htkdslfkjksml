#!/system/bin/sh
MODDIR=${0%/*}
SOREN_DIR="/data/local/tmp/soren_31"
LOG="$SOREN_DIR/action.log"
mkdir -p $SOREN_DIR

run() { echo "RUN: $1" >> $LOG; sh -c "$1" 2>>$LOG; }

echo "[SOREN 3.1] Action triggered" > $LOG

# Quick re-apply without reboot - premium on-demand
run "settings put system pointer_speed 7"
run "device_config put input_native_boot touch_slop 1.5"
run "device_config put input_native_boot tap_slop 1.5"
run "device_config put input_native_boot enable_palm_rejection false"
run "device_config put input_native_boot long_press_timeout 90"
run "device_config put input_native_boot drag_min_switch_speed 0"
run "device_config put input_native_boot touch_pressure_scale 0.55"

run "cmd power set-adaptive-power-saver-enabled false"
run "cmd power set-mode 0"
run "cmd power set-fixed-performance-mode-enabled true"
run "cmd thermalservice override-status 0"

run "cmd input set-report-rate 8000 2>/dev/null || true"
run "cmd input set-report-rate 1000 2>/dev/null || true"
run "setprop ro.vendor.touch.sampling_rate 8000"

# GD instant boost
for GD in com.robtopx.geometryjump com.geode.launcher; do
  run "cmd game set --perf true $GD"
done

# Vibrations for feedback that it worked
run "cmd vibrator vibrate 50 2>/dev/null || true"

echo "SOREN 3.1 RE-APPLIED - CHECK GAME NOW" >> $LOG

# Show toast if possible
run "cmd notification post -S bigtext -t 'Soren Engine 3.1' 'Tag' 'GD premium Mode re-applied - 8000hz feel active' 2>/dev/null || true"