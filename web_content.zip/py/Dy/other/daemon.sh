#!/system/bin/sh
#
# Daemon FluoriteTweaks
# Tugasnya cuma satu: memastikan setingan yang user nyalakan TETAP aktif,
# apa pun app yang sedang terbuka (termasuk saat keluar dari root manager),
# sampai user sendiri yang mematikannya.

MODDIR="/data/adb/modules/fluorite_tweaks"
LOG="/data/local/tmp/fluorite_daemon.log"

CURRENT_PID=$$
for pid in $(pgrep -f "other/daemon.sh" 2>/dev/null); do
    [ "$pid" -ne "$CURRENT_PID" ] && kill -9 "$pid" 2>/dev/null
done

sleep 1
echo "[$(date +%H:%M:%S)] Daemon started (PID: $CURRENT_PID)" > "$LOG"

while true; do
    sh "$MODDIR/other/iykyk.sh" sync
    sleep 2
done
