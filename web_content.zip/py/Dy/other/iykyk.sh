#!/system/bin/sh

ACTION="$1"
MODDIR="/data/adb/modules/fluorite_tweaks"
CONFDIR="$MODDIR/config"
STATE_FILE="$CONFDIR/tweaks_state"      # saklar global manual (1 = paksa ON untuk semua app)
APPLIED_FILE="$CONFDIR/applied"         # status yang benar-benar sedang diterapkan
ORIG="$CONFDIR/orig"                    # backup governor asli

mkdir -p "$CONFDIR" "$ORIG" 2>/dev/null

# ---------------------------------------------------------------- helpers

# Tentukan governor untuk performance mode
# Pakai "turbo" kalau kernel support, kalau tidak "performance"
get_perf_governor() {
    AVAIL=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors 2>/dev/null)
    case "$AVAIL" in
        *turbo*) echo "turbo" ;;
        *)       echo "performance" ;;
    esac
}

# Governor cadangan kalau backup asli tidak ada
get_fallback_governor() {
    AVAIL=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors 2>/dev/null)
    for g in schedutil walt interactive ondemand; do
        case " $AVAIL " in
            *" $g "*) echo "$g"; return ;;
        esac
    done
    echo "schedutil"
}

set_gov() {
    for dir in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
        [ -d "$dir" ] || continue
        [ -f "$dir/scaling_governor" ] || continue
        # tidak ditulis ulang kalau sudah sama
        [ "$(cat "$dir/scaling_governor" 2>/dev/null)" = "$1" ] && continue
        chmod 644 "$dir/scaling_governor" 2>/dev/null
        echo "$1" > "$dir/scaling_governor" 2>/dev/null
    done
}

save_orig_gov() {
    mkdir -p "$ORIG"
    for dir in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
        [ -f "$dir/scaling_governor" ] || continue
        N=$(basename "$(dirname "$dir")")
        cat "$dir/scaling_governor" > "$ORIG/gov_$N" 2>/dev/null
    done
}

restore_gov() {
    FB=$(get_fallback_governor)
    PERF=$(get_perf_governor)
    for dir in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
        [ -f "$dir/scaling_governor" ] || continue
        N=$(basename "$(dirname "$dir")")
        # balik ke schedutil (kalau kernel tidak punya, pakai governor asli / cadangan)
        G="$FB"
        case " $(cat "$dir/scaling_available_governors" 2>/dev/null) " in
            *" schedutil "*) G="schedutil" ;;
            *)
                O=$(cat "$ORIG/gov_$N" 2>/dev/null)
                [ -n "$O" ] && [ "$O" != "$PERF" ] && [ "$O" != "performance" ] && G="$O"
                ;;
        esac
        chmod 644 "$dir/scaling_governor" 2>/dev/null
        echo "$G" > "$dir/scaling_governor" 2>/dev/null
    done
}

lock_cpu() {
    for dir in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
        [ -d "$dir" ] || continue
        [ -f "$dir/cpuinfo_max_freq" ] || continue
        MAX=$(cat "$dir/cpuinfo_max_freq" 2>/dev/null)
        [ -n "$MAX" ] || continue
        chmod 644 "$dir/scaling_max_freq" 2>/dev/null
        echo "$MAX" > "$dir/scaling_max_freq" 2>/dev/null
    done
}

unlock_cpu() {
    for dir in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
        [ -d "$dir" ] || continue
        [ -f "$dir/cpuinfo_max_freq" ] || continue
        MAX=$(cat "$dir/cpuinfo_max_freq" 2>/dev/null)
        [ -n "$MAX" ] || continue
        chmod 644 "$dir/scaling_max_freq" 2>/dev/null
        echo "$MAX" > "$dir/scaling_max_freq" 2>/dev/null
    done
}

gpu_max_val() {
    for p in \
        /sys/class/kgsl/kgsl-3d0/devfreq/max_freq \
        /sys/class/kgsl/kgsl-3d0/max_gpuclk \
        /sys/class/devfreq/gpufreq/max_freq \
        /sys/kernel/gpu/gpu_max_clock
    do
        if [ -f "$p" ]; then
            cat "$p" 2>/dev/null
            return
        fi
    done

    if [ -f /proc/gpufreq/gpufreq_opp_dump ]; then
        grep -oE '[0-9]+' /proc/gpufreq/gpufreq_opp_dump 2>/dev/null | sort -n | tail -1
        return
    fi

    if [ -f /proc/gpufreqv2/gpu_working_opp_table ]; then
        grep -oE 'freq: [0-9]+' /proc/gpufreqv2/gpu_working_opp_table 2>/dev/null | grep -oE '[0-9]+' | sort -n | tail -1
        return
    fi
}

lock_gpu() {
    if [ -f /proc/gpufreq/gpufreq_opp_freq ]; then
        V=$(gpu_max_val)
        [ -n "$V" ] && echo "$V" > /proc/gpufreq/gpufreq_opp_freq 2>/dev/null
    fi

    if [ -f /proc/gpufreqv2/fix_target_opp_index ]; then
        echo "-1" > /proc/gpufreqv2/fix_target_opp_index 2>/dev/null
    fi

    for p in \
        /sys/class/kgsl/kgsl-3d0/devfreq/max_freq \
        /sys/class/kgsl/kgsl-3d0/max_gpuclk \
        /sys/class/devfreq/gpufreq/max_freq
    do
        if [ -f "$p" ]; then
            V=$(cat "$p" 2>/dev/null)
            [ -n "$V" ] && echo "$V" > "$p" 2>/dev/null
        fi
    done

    if [ -f /sys/kernel/gpu/gpu_max_clock ]; then
        echo "1" > /sys/kernel/gpu/gpu_max_clock 2>/dev/null
    fi

    if [ -f /sys/kernel/ged/hal/gpu_boost_level ]; then
        echo "1" > /sys/kernel/ged/hal/gpu_boost_level 2>/dev/null
    fi
}

unlock_gpu() {
    if [ -f /proc/gpufreq/gpufreq_opp_freq ]; then
        echo "0" > /proc/gpufreq/gpufreq_opp_freq 2>/dev/null
    fi

    if [ -f /proc/gpufreqv2/fix_target_opp_index ]; then
        echo "-1" > /proc/gpufreqv2/fix_target_opp_index 2>/dev/null
    fi

    for p in \
        /sys/class/kgsl/kgsl-3d0/devfreq/max_freq \
        /sys/class/kgsl/kgsl-3d0/max_gpuclk \
        /sys/class/devfreq/gpufreq/max_freq
    do
        if [ -f "$p" ]; then
            V=$(cat "$p" 2>/dev/null)
            [ -n "$V" ] && echo "$V" > "$p" 2>/dev/null
        fi
    done

    if [ -f /sys/kernel/gpu/gpu_max_clock ]; then
        echo "0" > /sys/kernel/gpu/gpu_max_clock 2>/dev/null
    fi

    if [ -f /sys/kernel/ged/hal/gpu_boost_level ]; then
        echo "0" > /sys/kernel/ged/hal/gpu_boost_level 2>/dev/null
    fi
}

set_conf() {
    CONF="$1"
    KEY="$2"
    VAL="$3"
    mkdir -p "$(dirname "$CONF")"
    if [ -f "$CONF" ]; then
        grep -v "^$KEY=" "$CONF" > "${CONF}.tmp" 2>/dev/null
        mv "${CONF}.tmp" "$CONF" 2>/dev/null
    fi
    echo "$KEY=$VAL" >> "$CONF"
}

# Nama di UI -> nilai asli debug.hwui.renderer
set_renderer() {
    case "$1" in
        ""|Default|default) setprop debug.hwui.renderer "" ;;
        SkiaVK*|skiavk*|Vulkan|vulkan) setprop debug.hwui.renderer skiavk ;;
        SkiaGL*|skiagl*) setprop debug.hwui.renderer skiagl ;;
        OpenGL*|opengl*) setprop debug.hwui.renderer opengl ;;
    esac
}

# Terapkan ulang renderer dari semua app yang aktif (dipakai saat boot,
# karena setprop hilang setelah reboot)
apply_props() {
    for c in "$CONFDIR"/apps/*.conf; do
        [ -f "$c" ] || continue
        grep -q '^enabled=1$' "$c" 2>/dev/null || continue
        R=$(grep '^renderer=' "$c" 2>/dev/null | cut -d= -f2-)
        [ -n "$R" ] && set_renderer "$R"
    done
}

# ---------------------------------------------------------------- inti: performance mode GLOBAL
#
# Performance mode MENYALA (governor performance) kalau:
#   - saklar global (tweaks_state) = 1, ATAU
#   - app yang sedang di depan punya enabled=1 dan perfmode=1
# Pindah ke app lain / keluar dari app itu -> governor langsung balik ke asli (schedutil).
# Setingan per-app tersimpan permanen sampai user sendiri mengubahnya.

get_fg() {
    FG=$(dumpsys activity activities 2>/dev/null | grep -m1 "mResumedActivity" | grep -oE '[a-zA-Z0-9._]+/' | cut -d/ -f1)
    [ -z "$FG" ] && FG=$(dumpsys window 2>/dev/null | grep -m1 "mCurrentFocus" | grep -oE '[a-zA-Z0-9._]+/' | cut -d/ -f1)
    echo "$FG"
}

# return 0 = nyalakan, 1 = matikan, 2 = tidak tahu (pertahankan kondisi sekarang)
want_perf() {
    [ "$(cat "$STATE_FILE" 2>/dev/null)" = "1" ] && return 0
    FG=$(get_fg)
    [ -z "$FG" ] && return 2
    C="$CONFDIR/apps/$FG.conf"
    [ -f "$C" ] || return 1
    if grep -q '^enabled=1$' "$C" 2>/dev/null && grep -q '^perfmode=1$' "$C" 2>/dev/null; then
        return 0
    fi
    return 1
}

apply_perf() {
    [ "$(cat "$APPLIED_FILE" 2>/dev/null)" = "1" ] || save_orig_gov
    set_gov "$(get_perf_governor)"
    lock_cpu
    lock_gpu
    echo "1" > "$APPLIED_FILE"
}

restore_perf() {
    restore_gov
    unlock_cpu
    unlock_gpu
    echo "0" > "$APPLIED_FILE"
}

# Idempotent: dipanggil daemon tiap beberapa detik DAN setiap UI mengubah sesuatu.
sync_perf() {
    want_perf
    case $? in
        0) apply_perf ;;      # diterapkan ulang terus supaya tidak direset sistem/thermal
        1) [ "$(cat "$APPLIED_FILE" 2>/dev/null)" = "1" ] && restore_perf ;;
    esac
}

# Pastikan daemon hidup. Dijalankan lewat setsid supaya TIDAK ikut mati
# saat root manager (yang memanggil script ini) ditutup.
ensure_daemon() {
    pgrep -f "other/daemon.sh" >/dev/null 2>&1 && return
    if command -v setsid >/dev/null 2>&1; then
        setsid nohup sh "$MODDIR/other/daemon.sh" </dev/null >/dev/null 2>&1 &
    else
        nohup sh "$MODDIR/other/daemon.sh" </dev/null >/dev/null 2>&1 &
    fi
}

# ---------------------------------------------------------------- dispatcher

case "$ACTION" in
    on)
        echo "1" > "$STATE_FILE" 2>/dev/null
        sync_perf
        ensure_daemon
        ;;

    off)
        echo "0" > "$STATE_FILE" 2>/dev/null
        sync_perf
        ;;

    sync)
        sync_perf
        ;;

    boot)
        echo "0" > "$APPLIED_FILE" 2>/dev/null
        apply_props
        sync_perf
        ;;

    restore)
        # dipakai saat uninstall: paksa balik ke default
        echo "0" > "$STATE_FILE" 2>/dev/null
        restore_perf
        wm size reset 2>/dev/null
        setprop debug.hwui.renderer "" 2>/dev/null
        ;;

    status)
        cat "$APPLIED_FILE" 2>/dev/null || echo "0"
        ;;

    renderer)
        set_renderer "$2"
        ;;

    preload)
        echo "$2" > "$CONFDIR/preload"
        ;;

    dnd)
        echo "$2" > "$CONFDIR/dnd"
        ;;

    gov)
        case "$2" in
            cpu_default)
                for d in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
                    [ -w "$d/scaling_governor" ] && echo "$3" > "$d/scaling_governor"
                done
                ;;
            cpu_perf)
                echo "$3" > "$CONFDIR/gov_perf"
                ;;
            cpu_powersave)
                echo "$3" > "$CONFDIR/gov_powersave"
                ;;
            io_balanced)
                for d in /sys/block/*/queue; do
                    [ -w "$d/scheduler" ] && echo "$3" > "$d/scheduler"
                done
                ;;
            io_perf)
                echo "$3" > "$CONFDIR/io_perf"
                ;;
            gpu_balanced|gpu_perf)
                echo "$3" > "$CONFDIR/$2"
                ;;
        esac
        ;;

    app)
        PKG="$2"
        KEY="$3"
        VAL="$4"
        DIR="$CONFDIR/apps"
        CONF="$DIR/$PKG.conf"
        mkdir -p "$DIR"

        set_conf "$CONF" "$KEY" "$VAL"

        case "$KEY" in
            enabled)
                if [ "$VAL" != "1" ]; then
                    set_conf "$CONF" "perfmode" "0"
                fi
                sync_perf
                ;;

            perfmode)
                sync_perf
                ;;

            renderer)
                set_renderer "$VAL"
                ;;

            downscale)
                case "$VAL" in
                    Default|100%)
                        wm size reset 2>/dev/null
                        ;;
                    *)
                        PERCENT=${VAL%\%}
                        ORIG_RES=$(wm size 2>/dev/null | grep -oE '[0-9]+x[0-9]+' | head -1)
                        if [ -n "$ORIG_RES" ]; then
                            W=$(echo "$ORIG_RES" | cut -dx -f1)
                            H=$(echo "$ORIG_RES" | cut -dx -f2)
                            NEW_W=$((W * PERCENT / 100))
                            NEW_H=$((H * PERCENT / 100))
                            wm size "${NEW_W}x${NEW_H}" 2>/dev/null
                        fi
                        ;;
                esac
                ;;

            fps)
                case "$VAL" in
                    30fps)  setprop debug.hwui.fps 30 2>/dev/null ;;
                    45fps)  setprop debug.hwui.fps 45 2>/dev/null ;;
                    60fps)  setprop debug.hwui.fps 60 2>/dev/null ;;
                    90fps)  setprop debug.hwui.fps 90 2>/dev/null ;;
                    120fps) setprop debug.hwui.fps 120 2>/dev/null ;;
                esac
                ;;

            preload)
                if [ "$VAL" = "on" ]; then
                    echo "1" > "$CONFDIR/apps/$PKG.preload"
                else
                    echo "0" > "$CONFDIR/apps/$PKG.preload"
                fi
                ;;

            dnd)
                if [ "$VAL" = "on" ]; then
                    settings put global zen_mode 1 2>/dev/null
                else
                    settings put global zen_mode 0 2>/dev/null
                fi
                ;;
        esac

        # daemon harus selalu hidup selama ada setingan aktif
        ensure_daemon
        ;;

    *)
        echo "Usage: $0 {on|off|sync|boot|restore|status|renderer|preload|dnd|gov|app}"
        ;;
esac
