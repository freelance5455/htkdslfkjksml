#!/system/bin/sh

MODDIR="${0%/*}"

# matikan daemon lalu kembalikan semua ke default
for pid in $(pgrep -f "other/daemon.sh" 2>/dev/null); do
    kill -9 "$pid" 2>/dev/null
done

sh "$MODDIR/other/iykyk.sh" restore

rm -f /data/local/tmp/fluorite_daemon.log
