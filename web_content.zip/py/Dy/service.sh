#!/system/bin/sh

MODDIR="${0%/*}"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done

sleep 5

mkdir -p "$MODDIR/config"

# Terapkan ulang setingan tersimpan setelah reboot (renderer, performance mode)
sh "$MODDIR/other/iykyk.sh" boot

# Jalankan daemon (terpisah dari proses lain supaya tidak ikut mati)
if ! pgrep -f "other/daemon.sh" > /dev/null 2>&1; then
    if command -v setsid > /dev/null 2>&1; then
        setsid nohup sh "$MODDIR/other/daemon.sh" < /dev/null > /dev/null 2>&1 &
    else
        nohup sh "$MODDIR/other/daemon.sh" < /dev/null > /dev/null 2>&1 &
    fi
fi
