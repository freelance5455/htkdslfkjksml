SKIPUNZIP=0

if [ "$BOOTMODE" != true ]; then
  abort "! Install via Magisk/KernelSU Manager"
fi

# Base permission
set_perm_recursive $MODPATH 0 0 0755 0644

# Executable di root module
[ -f "$MODPATH/service.sh" ] && set_perm $MODPATH/service.sh 0 0 0755
[ -f "$MODPATH/action.sh" ] && set_perm $MODPATH/action.sh 0 0 0755
[ -f "$MODPATH/uninstall.sh" ] && set_perm $MODPATH/uninstall.sh 0 0 0755

# Executable di folder other/
[ -d "$MODPATH/other" ] && set_perm_recursive $MODPATH/other 0 0 0755 0755

# Binary di libs/
[ -d "$MODPATH/libs" ] && set_perm_recursive $MODPATH/libs 0 0 0755 0755

# Config folder - setingan lama dipertahankan saat update module
mkdir -p "$MODPATH/config"
OLD=/data/adb/modules/fluorite_tweaks/config
if [ -d "$OLD" ]; then
  cp -af "$OLD/." "$MODPATH/config/" 2>/dev/null
  rm -f "$MODPATH/config/applied"
fi
[ -f "$MODPATH/config/tweaks_state" ] || echo "0" > "$MODPATH/config/tweaks_state"

# Gamelist
[ ! -f "$MODPATH/gamelist.txt" ] && touch "$MODPATH/gamelist.txt"

ui_print " FluoriteTweaks installed"