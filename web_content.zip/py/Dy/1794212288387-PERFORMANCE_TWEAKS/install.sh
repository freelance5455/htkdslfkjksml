#!/system/bin/sh
# =========================================================
#  🔥 INFINIX NOTE 7 GAMING TWEAKS ENGINE v2.0 🔥
#  By: jaloyd bacor
#  Status: INSTALLING CORE PERFORMANCE SETTINGS
# =========================================================

echo "================================================="
echo "       INITIALIZING GAMING OPTIMIZATION          "
echo "   Engine Script Created By: jaloyd bacor        "
echo "================================================="
echo "[+] Checking Device Permissions..."
pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS 2>/dev/null
sleep 1.0

echo "[+] Injecting Core Global Performance Profiles..."
settings put global performance_mode 1
settings put global power_mode performance
settings put global force_high_performance 1
echo "    -> [OK] Power & Performance Governors Overridden"
sleep 1.0

echo "[+] Optimizing Graphics & Media Rendering Engine..."
settings put global game_driver_power_saving_mode 0
settings put global game_driver_gpu_mode 1
settings put global debug.hwui.renderer skiavk
echo "    -> [OK] Vulkan HW Acceleration Forced"
sleep 1.0

echo "[+] Tweaking Hardware Input & System Polling..."
settings put global cached_apps_freezer enabled
settings put global windowsmgr.max_events_per_sec 150
settings put global multicore_packet_scheduler 1
settings put global thermal_limit_refresh_rate 0
echo "    -> [OK] 150Hz Touch Polling & Network Packet Scheduler Set"
sleep 1.0

echo "[+] Hardcoding Secure Game Mode Flag..."
settings put secure game_mode 1
echo "    -> [OK] Android Gaming Profile Hooked"
sleep 1.0

echo "================================================="
echo "   🚀 INSTALLATION COMPLETE: ENGINE RUNNING 🚀   "
echo "   Device Status: PURE PERFORMANCE MODE ACTIVATED "
echo "   By: jaloyd bacor                              "
echo "================================================="
