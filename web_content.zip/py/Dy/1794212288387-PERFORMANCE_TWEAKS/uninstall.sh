#!/system/bin/sh
# =========================================================
#  🧹 INFINIX NOTE 7 REVERT ENGINE v2.0 🧹
#  By: jaloyd bacor
#  Status: UNINSTALLING PERFORMANCE SETTINGS
# =========================================================

echo "================================================="
echo "       REVERTING SYSTEM TO STOCK DEFAULTS        "
echo "   Engine Script Created By: jaloyd bacor        "
echo "================================================="
echo "[+] Wiping Custom Global Configurations..."
settings put global performance_mode 0
settings put global power_mode normal
settings put global force_high_performance 0
echo "    -> [CLEANED] Power Profiles Restored to Battery Saving"
sleep 1.0

echo "[+] Cleaning Graphic Driver States..."
settings put global game_driver_power_saving_mode 1
settings put global game_driver_gpu_mode 0
settings delete global debug.hwui.renderer
echo "    -> [CLEANED] OpenGL Default Renderer Re-mapped"
sleep 1.0

echo "[+] Resetting Hardware Limits & Memory Constraints..."
settings put global cached_apps_freezer default
settings put global windowsmgr.max_events_per_sec 60
settings put global multicore_packet_scheduler 0
settings delete global thermal_limit_refresh_rate
echo "    -> [CLEANED] 60Hz Touch Polling & Throttling Re-enabled"
sleep 1.0

echo "[+] Detaching Secure Game Flag..."
settings put secure game_mode 0
echo "    -> [CLEANED] System-level Game Mode Terminated"
sleep 1.0

echo "================================================="
echo "   🛑 CLEANUP COMPLETE: STOCK MODE RESTORED 🛑   "
echo "   Device Status: SAFE & COOL TEMPERATURE REGIME   "
echo "   By: jaloyd bacor                              "
echo "================================================="
