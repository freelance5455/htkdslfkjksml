#!/system/bin/sh
# 90Hz Stable Lock - service.sh
MODDIR=${0%/*}

# Tunggu sistem siap
sleep 15

# Fungsi set 90Hz
set_90hz() {
    # Metode umum (banyak device)
    settings put system peak_refresh_rate 90.0 2>/dev/null
    settings put system min_refresh_rate 90.0 2>/dev/null
    settings put secure peak_refresh_rate 90.0 2>/dev/null
    settings put secure min_refresh_rate 90.0 2>/dev/null

    # Beberapa OEM / SurfaceFlinger
    service call SurfaceFlinger 1035 i32 1 2>/dev/null   # force high refresh (jika didukung)
    
    # Alternatif mode (coba jika di atas kurang efektif)
    # settings put system user_refresh_rate 90 2>/dev/null
}

# Set pertama kali
set_90hz

# Loop jaga biar tetap stabil (setiap 30 detik)
while true; do
    set_90hz
    sleep 30
done