#!/system/bin/sh
settings delete system peak_refresh_rate 2>/dev/null
settings delete system min_refresh_rate 2>/dev/null
settings delete secure peak_refresh_rate 2>/dev/null
settings delete secure min_refresh_rate 2>/dev/null
echo "90Hz lock removed"