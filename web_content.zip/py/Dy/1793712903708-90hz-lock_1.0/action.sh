#!/system/bin/sh
MODDIR=${0%/*}

settings put system peak_refresh_rate 90.0
settings put system min_refresh_rate 90.0
settings put secure peak_refresh_rate 90.0
settings put secure min_refresh_rate 90.0

echo "90Hz Applied!"