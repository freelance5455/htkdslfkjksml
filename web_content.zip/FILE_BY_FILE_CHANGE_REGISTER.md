# ANONYMOUX STUDIO 2.3.2 — File-by-File Change Register

The change register compares the submitted 2.3.1 ZIP with this 2.3.2 package. Files not listed below remain byte-for-byte unchanged from the source ZIP unless otherwise called out in the separate source audit.

## Modified existing files

| File | Change |
|---|---|
| `admin.php` | Added the Resources tab and dispatches the resource-specific admin handler while retaining existing admin sections. |
| `api/image-generate.php` | Checks remaining account storage before retaining a completed PNG; records a failed job and releases uploaded source/reference files when the output cannot be retained. |
| `api/reference.php` | Enforces the shared account storage quota on reference replacement, excluding the old reference being replaced from the size calculation. |
| `api/video-jobs.php` | Checks storage capacity before persisting a completed provider video; marks the job failed if storage cannot accept the output. |
| `app/auth.php` | Adds a genuine successful-sign-in security notification after login; failures in optional notification setup do not block login. |
| `app/platform.php` | Adds consistent stored-byte accounting for outputs, job source/reference files, reference uploads and voice audio; enforces cumulative quota on image/video upload. |
| `app/platform_footer.php` | Loads the progressive resource-admin Markdown helper script. |
| `app/platform_header.php` | Consolidates Tools and Tutorials navigation into one resource-centre item; loads new dashboard/resource styles; records genuine recent workspace access. |
| `app/voice.php` | Applies cumulative account storage quota before saving a generated voice audio file. |
| `dashboard.php` | Rebuilt as the authenticated creator dashboard with real metrics, wallet, recent creations, filters, quick create, recent access, saved prompts, reference uploads, storage and notifications. |
| `tests/smoke.php` | Includes resource-centre and dashboard tables in required-table checks. |
| `tools.php` | Legacy route redirects to the Creative Tools tab in the unified resource centre. |
| `tutorials.php` | Legacy route redirects to the Tutorials & Learning tab in the unified resource centre. |
| `SECURITY_VERIFICATION_REPORT.md` | Replaced old milestone notes with 2.3.2 control/verification report and explicit limitations. |
| `TEST_RESULTS.md` | Records full source lint, JS syntax, SQLite migration and runtime driver limitations. |

## New PHP application files

| File | Purpose |
|---|---|
| `app/dashboard_data.php` | Account-scoped data queries and storage breakdown for dashboard. |
| `app/resources.php` | Resource schema/seeding, catalogue helpers, safe Markdown/link handling, upload storage, activity tracking and notification helpers. |
| `app/resource_admin.php` | Server-side administrator CRUD, validation, media handling and audit logging. |
| `api/notifications.php` | User-scoped notification list/read/read-all JSON endpoint. |
| `resources.php` | Unified searchable Tools & Tutorials page with two tabs. |
| `tutorial.php` | Full tutorial details, ordered steps, uploaded media, supported embedded video and related resources. |
| `resource-media.php` | Authenticated and publication-aware private resource-media delivery. |
| `admin_resources_view.php` | Administrator UI for tools, tutorials, media and category management. |

## New frontend assets

| File | Purpose |
|---|---|
| `assets/dashboard.css` | Responsive creator-dashboard visual styling. |
| `assets/resources.css` | Resource directory, tutorial detail and admin editor styling. |
| `assets/resources.js` | Safe editor toolbar insertion helper. |

## New migrations and tests

| File | Purpose |
|---|---|
| `migrations/002_resources_centre_sqlite.sql` | Additive SQLite migration. |
| `migrations/002_resources_centre_mysql.sql` | Additive MySQL migration. |
| `migrations/README.md` | Migration and backup instructions. |
| `tests/resource_migration_check.py` | Python SQLite migration idempotency and constraint test. |

## New reports and deployment docs

- `SOURCE_AUDIT_FILE_BY_FILE.md` — baseline source findings plus file-by-file findings/status register.
- `DASHBOARD_IMPLEMENTATION_REPORT.md` — dashboard feature map and limitations.
- `TOOLS_TUTORIALS_IMPLEMENTATION_REPORT.md` — catalogue/tutorial/admin implementation and limitations.
- `SECURITY_VERIFICATION_REPORT.md` — retained and added security controls, unverified areas.
- `TEST_RESULTS.md` — actual build validation results.
- `DEPLOYMENT_GUIDE_2.3.2.md` — backup, upload, migration, administrator and post-deployment acceptance instructions.
- `BUILD-REPORT-2.3.2.md` — release summary.

## Preserved, not replaced

All original non-listed Image Studio, Video Studio, Realtime Studio, Voice Studio/Fish Audio, Decart API routes, authentication pages, wallet code, user/project/assets/history pages, provider code and existing assets are retained. No existing database was reset. No live `config.local.php` was supplied in the source archive, and no server-side credentials were fabricated or added to the ZIP.
