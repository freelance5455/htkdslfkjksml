/* Bulk question import (CSV / JSON). Works fully offline; nothing leaves the browser. */
(() => {
  const fileInput = document.querySelector('#import-file');
  const chooseBtn = document.querySelector('#import-choose');
  const pasteBox = document.querySelector('#import-paste');
  const previewBtn = document.querySelector('#import-preview');
  const resultBox = document.querySelector('#import-result');
  if (!fileInput || !resultBox) return;

  const COLUMNS = ['subject','category','difficulty','prompt','optionA','optionB','optionC','optionD','answer','given','formula','formulaReason','derivation','substitution','calculation','finalAnswer','unitCheck','concept','shortcutFormula','shortcut','commonMistakes','source','answerVerified'];
  const PLACEHOLDER = 'Not provided in import';
  const MAX_ERRORS_SHOWN = 15;
  let pending = null; // { valid: [...] }

  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; };
  const norm = s => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();

  // ---------- CSV parser (RFC 4180: quotes, escaped quotes, newlines in cells, BOM, comma/tab/semicolon) ----------
  function parseCSV(text) {
    text = text.replace(/^\uFEFF/, '');
    const firstLine = text.split(/\r?\n/, 1)[0] || '';
    const counts = { ',': 0, '\t': 0, ';': 0 };
    let inQ = false;
    for (const ch of firstLine) { if (ch === '"') inQ = !inQ; else if (!inQ && ch in counts) counts[ch]++; }
    const delim = Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (q) {
        if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; }
        else cell += ch;
      } else if (ch === '"') q = true;
      else if (ch === delim) { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') {
        if (ch === '\r' && text[i + 1] === '\n') i++;
        row.push(cell); cell = '';
        if (row.some(c => c.trim() !== '')) rows.push(row);
        row = [];
      } else cell += ch;
    }
    row.push(cell);
    if (row.some(c => c.trim() !== '')) rows.push(row);
    if (q) throw new Error('A quoted cell is never closed (missing ending quote).');
    return rows;
  }

  function csvToObjects(text) {
    const rows = parseCSV(text);
    if (rows.length < 2) throw new Error('The CSV needs a header row and at least one question row.');
    const canon = Object.fromEntries(COLUMNS.map(c => [c.toLowerCase().replace(/[^a-z]/g, ''), c]));
    const header = rows[0].map(h => canon[h.toLowerCase().replace(/[^a-z]/g, '')] || null);
    const missing = ['subject', 'category', 'prompt', 'optionA', 'optionB', 'optionC', 'optionD', 'answer'].filter(c => !header.includes(c));
    if (missing.length) throw new Error(`Missing required column(s): ${missing.join(', ')}. Download the CSV template to see the expected headers.`);
    return rows.slice(1).map((r, idx) => {
      const o = { __row: idx + 2 };
      header.forEach((h, i) => { if (h) o[h] = (r[i] ?? '').trim(); });
      return o;
    });
  }

  function jsonToObjects(text) {
    let data = JSON.parse(text);
    if (data && !Array.isArray(data) && Array.isArray(data.questions)) data = data.questions;
    if (!Array.isArray(data)) throw new Error('JSON must be an array of questions, or an object with a "questions" array.');
    return data.map((q, idx) => {
      const o = { __row: idx + 1, ...q };
      if (Array.isArray(q.options)) {
        q.options.forEach((opt, i) => {
          const letter = typeof opt === 'object' && opt?.value ? String(opt.value).toUpperCase() : 'ABCD'[i];
          o[`option${letter}`] = typeof opt === 'object' ? opt?.text : opt;
        });
      }
      return o;
    });
  }

  // ---------- normalize + validate one question ----------
  const toLines = v => Array.isArray(v) ? v.map(s => String(s).trim()).filter(Boolean) : String(v || '').split(/\r?\n|\s\|\s/).map(s => s.trim()).filter(Boolean);
  const normDifficulty = v => {
    const s = norm(v);
    if (['beginner', 'easy'].includes(s)) return 'Beginner';
    if (['advanced', 'hard', 'difficult'].includes(s)) return 'Advanced';
    return 'Intermediate';
  };
  const truthy = v => v === true || ['true', 'yes', 'y', '1', 'verified'].includes(norm(v));

  function normalizeQuestion(o) {
    const problems = [];
    const text = k => String(o[k] ?? '').trim();
    const subject = text('subject').slice(0, 100), category = text('category').slice(0, 80), prompt = text('prompt');
    if (!subject) problems.push('missing subject');
    if (!category) problems.push('missing category');
    if (!prompt) problems.push('missing question text');
    const options = ['A', 'B', 'C', 'D'].map(value => ({ value, text: text(`option${value}`) }));
    const emptyOpts = options.filter(x => !x.text).map(x => x.value);
    if (emptyOpts.length) problems.push(`empty choice(s): ${emptyOpts.join(', ')}`);
    const answer = text('answer').toUpperCase().replace(/^OPTION\s*/, '').charAt(0);
    if (!['A', 'B', 'C', 'D'].includes(answer)) problems.push('answer must be A, B, C or D');
    if (problems.length) return { problems };
    const given = toLines(o.given), calculation = toLines(o.calculation);
    return {
      question: {
        subject, category, difficulty: normDifficulty(o.difficulty), prompt, options, answer,
        source: text('source') || 'Bulk import',
        answerVerified: truthy(o.answerVerified),
        given: given.length ? given : [PLACEHOLDER],
        formula: text('formula') || PLACEHOLDER,
        formulaReason: text('formulaReason'), derivation: text('derivation'),
        substitution: text('substitution') || PLACEHOLDER,
        calculation: calculation.length ? calculation : [PLACEHOLDER],
        finalAnswer: text('finalAnswer') || PLACEHOLDER, unitCheck: text('unitCheck'),
        concept: text('concept') || PLACEHOLDER,
        shortcutFormula: text('shortcutFormula') || PLACEHOLDER,
        shortcut: text('shortcut') || PLACEHOLDER,
        commonMistakes: toLines(o.commonMistakes)
      }
    };
  }

  // ---------- preview + import ----------
  function showMessage(message, kind) {
    pending = null;
    resultBox.replaceChildren(el('p', `import-msg ${kind || ''}`.trim(), message));
  }

  function analyze(text) {
    text = text.trim();
    if (!text) return showMessage('Choose a file or paste some CSV/JSON first.', 'err');
    let objects;
    try { objects = /^[\[{]/.test(text) ? jsonToObjects(text) : csvToObjects(text); }
    catch (e) { return showMessage(`Could not read that data: ${e.message}`, 'err'); }
    if (!objects.length) return showMessage('No questions were found.', 'err');
    if (objects.length > 2000) return showMessage('That is more than 2,000 questions. Split it into smaller files.', 'err');

    const existing = new Set((window.getEngineeringReviewQuestions?.() || []).map(q => norm(q.prompt)));
    const valid = [], errors = []; let dupes = 0;
    objects.forEach(o => {
      const { question, problems } = normalizeQuestion(o);
      if (problems) { errors.push(`Row ${o.__row}: ${problems.join('; ')}`); return; }
      const key = norm(question.prompt);
      if (existing.has(key)) { dupes++; return; }
      existing.add(key); valid.push(question);
    });
    pending = { valid };

    const summary = el('div', 'import-summary');
    summary.append(el('span', 'import-chip ok', `${valid.length} ready to import`));
    if (dupes) summary.append(el('span', 'import-chip dup', `${dupes} duplicate(s) skipped`));
    if (errors.length) summary.append(el('span', 'import-chip bad', `${errors.length} row(s) with problems`));
    const nodes = [summary];
    if (valid.length) {
      const unverified = valid.filter(q => !q.answerVerified).length;
      nodes.push(el('p', 'muted small', `${unverified} of these will be marked answer not verified. Subjects: ${[...new Set(valid.map(q => q.subject))].join(', ')}.`));
    }
    if (errors.length) {
      const list = el('ul', 'import-errors');
      errors.slice(0, MAX_ERRORS_SHOWN).forEach(e => list.append(el('li', '', e)));
      if (errors.length > MAX_ERRORS_SHOWN) list.append(el('li', '', `…and ${errors.length - MAX_ERRORS_SHOWN} more.`));
      nodes.push(list);
    }
    if (valid.length) {
      const go = el('button', 'button button-primary', `Import ${valid.length} question${valid.length === 1 ? '' : 's'}`);
      go.type = 'button';
      go.addEventListener('click', () => {
        try {
          const n = window.importEngineeringReviewQuestions(pending.valid);
          pasteBox.value = ''; fileInput.value = '';
          showMessage(`Imported ${n} question${n === 1 ? '' : 's'}. Find them in Practice and the question library. Download a backup to keep them safe.`, 'ok');
        } catch (e) { showMessage(e.message, 'err'); }
      });
      nodes.push(go);
    } else nodes.push(el('p', 'import-msg err', 'Nothing valid to import. Fix the problems above and preview again.'));
    resultBox.replaceChildren(...nodes);
  }

  chooseBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files?.[0]; if (!file) return;
    if (file.size > 5 * 1024 * 1024) return showMessage('That file is over 5 MB. Split it into smaller files.', 'err');
    try { const text = await file.text(); pasteBox.value = ''; analyze(text); }
    catch { showMessage('Could not read that file.', 'err'); }
  });
  previewBtn.addEventListener('click', () => analyze(pasteBox.value));

  // ---------- templates ----------
  const download = (name, content, type) => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([content], { type }));
    a.download = name; a.click(); URL.revokeObjectURL(a.href);
  };
  const example = {
    subject: 'Thermodynamics', category: 'Sensible Heat', difficulty: 'Intermediate',
    prompt: 'How much heat is needed to raise 5 kg of water from 20°C to 80°C? (cp = 4.187 kJ/kg·K)',
    optionA: '1,256 kJ', optionB: '1,046 kJ', optionC: '837 kJ', optionD: '628 kJ', answer: 'A',
    given: 'm = 5 kg | cp = 4.187 kJ/kg·K | ΔT = 60 K', formula: 'Q = m·cp·ΔT',
    substitution: 'Q = 5 × 4.187 × 60', calculation: 'Q = 5 × 4.187 × 60 | Q = 1,256.1 kJ',
    finalAnswer: '1,256 kJ', concept: 'Sensible heat changes temperature without a phase change.',
    shortcutFormula: 'Q = m·cp·ΔT', shortcut: 'Multiply mass, specific heat, and temperature change.',
    source: 'My own practice set', answerVerified: 'true'
  };
  const csvCell = v => /[",\n\r]/.test(v) ? `"${String(v).replace(/"/g, '""')}"` : String(v);
  document.querySelector('#import-template-csv').addEventListener('click', () => {
    const csv = '\uFEFF' + COLUMNS.join(',') + '\r\n' + COLUMNS.map(c => csvCell(example[c] ?? '')).join(',') + '\r\n';
    download('question-import-template.csv', csv, 'text/csv');
  });
  document.querySelector('#import-template-json').addEventListener('click', () => {
    const q = { ...example, answerVerified: true };
    download('question-import-example.json', JSON.stringify({ questions: [q] }, null, 2), 'application/json');
  });
})();
