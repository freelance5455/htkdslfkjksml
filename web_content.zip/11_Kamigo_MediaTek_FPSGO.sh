#!/bin/bash
# Kamigo MediaTek FPSGO v2.0 - Comandos limpos com 2>/dev/null || true
echo "Aplicando Kamigo MediaTek FPSGO..."

# FPSGO é específico de MediaTek - comandos genéricos de FPS + performance
settings put system peak_refresh_rate 120 2>/dev/null || true
settings put system min_refresh_rate 120 2>/dev/null || true
setprop debug.performance.tuning 1 2>/dev/null || true
setprop persist.sys.ui.hw 1 2>/dev/null || true
setprop debug.sf.hw 1 2>/dev/null || true
setprop debug.egl.hw 1 2>/dev/null || true
# Tenta ativar FPSGO se o caminho existir (MediaTek)
echo 1 > /sys/module/mtk_fpsgo/parameters/perfservice_enable 2>/dev/null || true
echo 1 > /sys/kernel/fpsgo/common/fpsgo_enable 2>/dev/null || true

echo "Kamigo MediaTek FPSGO aplicado!"
echo "Nota: Funciona melhor em dispositivos MediaTek."
