# ANONYMOUX STUDIO 2.5.9 — Build & Verification Report

## Delivered

- Removed Explore from the authenticated sidebar and shared access tracking; the old community URL redirects to Dashboard.
- Added explicit handling for Decart SDK `sessionEnded` lifecycle events.
- Increased the scoped client-token rate allowance to accommodate SDK reconnect/retry behavior while retaining the short-lived token, model scope and same-origin checks.
- Added realtime provider-rate disclosure to the workspace and admin pricing panel.
- Updated the pricing plan to reflect active default credit-package seeding and the official Decart realtime rates checked 2026-11-15.
- Added `REALTIME-PRICING-AND-AUDIT-2.5.9.md` and a focused source regression test.

## Verification performed

- PHP syntax checks across all PHP files.
- JavaScript syntax checks across top-level asset JavaScript files.
- Realtime / Explore / pricing source regression check.
- Admin bootstrap security regression check.
- Billing source contract regression check.
- Fish Audio Agent source contract regression check.

## Important limitations

- This is static/source verification. The current environment does not provide the deployed Decart credentials, HTTPS origin, browser camera permission or provider network needed to execute a real realtime session.
- Realtime wallet deductions are not implemented. The default SDK-direct transport does not write trusted provider usage to the ANONYMOUX billing ledger. The displayed provider rates are Decart costs, not customer ANONYMOUX credit rates.
- Existing image/video billing remains separate and unchanged.
- Validate live camera, WebRTC/LiveKit output, prompt updates, model switching, pause/resume, provider-side session termination, manual stop and page navigation on the deployed site before production sign-off.
