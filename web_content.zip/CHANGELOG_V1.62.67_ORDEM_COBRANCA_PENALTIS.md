# Carreira de Craque v1.62.67 — Ordem de Cobrança dos Pênaltis

- Antes de iniciar uma disputa oficial de pênaltis, o jogador pode escolher em qual posição (1ª a 5ª cobrança) seu atleta vai bater.
- Os companheiros cobram automaticamente nas outras posições; o atleta controlado pelo usuário entra exatamente na posição escolhida.
- A escolha aparece somente quando o atleta está apto a participar da disputa, respeitando os critérios existentes de confiança do treinador, precisão, participação na partida e ausência de expulsão/lesão.
- A ordem alternada entre as equipes, a resolução realista das cobranças e a morte súbita foram preservadas.
