# FLOW OS — Android Home Launcher

FLOW OS is an Android launcher app: it provides an alternative home screen while Android remains the underlying operating system.

## Included in this project
- Registers as a selectable Android Home app.
- Live clock and date on the home screen.
- Reads installed launcher apps and displays their real app icons.
- Opens installed apps using Android's normal app-launch mechanism.
- Searchable App Library.
- Favourite apps: press and hold an app icon to add/remove it from the home-screen favourites (up to four). The selection is saved on the device.
- Five selectable colour themes saved between launches.
- Control Center shortcuts that open Android's real Internet, Bluetooth, Airplane mode, Display, Sound, Battery, Notifications, and general Settings screens.
- Responsive Compose layout for different screen sizes.

## Build the APK
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Extract this ZIP file.
3. In Android Studio choose **Open** and select the extracted `FLOW_OS_Launcher` folder.
4. Allow Gradle to sync. The first sync needs an internet connection to download Android build dependencies.
5. Connect an Android phone/tablet with USB debugging enabled, or select an emulator.
6. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show a notification with a link to the APK. The usual debug APK path is `app/build/outputs/apk/debug/app-debug.apk`.

## Set FLOW OS as the default Home app
1. Install the APK on your Android device.
2. Press the device's Home button.
3. Select **FLOW OS** when Android asks which Home app to use.
4. Choose **Always** to make it the default. You can change this later in Android Settings > Apps > Default apps > Home app.

## Important limits
This is a launcher, not a replacement Android operating system or custom ROM. Android still controls the secure lock screen, cellular calls, SMS delivery, camera hardware, notifications, and protected quick settings. FLOW OS opens the apps and settings screens that Android and the device manufacturer provide; it does not bypass their permissions. Some settings destinations vary by Android version and manufacturer.

## Project details
- Application ID: `com.flowos.system`
- Minimum Android version: Android 10 (API 29)
- Compile/target SDK: 35
- Kotlin + Jetpack Compose

The source has been prepared in this environment, but it has not been compiled or device-tested here. Build it in Android Studio to produce the installable APK.
