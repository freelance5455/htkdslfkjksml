package com.flowos.system

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Accent = Color(0xFF9BE2F0)
private val palettes = listOf(
    listOf(Color(0xFF14243B), Color(0xFF315477), Color(0xFF101827)),
    listOf(Color(0xFF301C45), Color(0xFF664B83), Color(0xFF171326)),
    listOf(Color(0xFF123B38), Color(0xFF36766B), Color(0xFF101F25)),
    listOf(Color(0xFF493021), Color(0xFF936746), Color(0xFF1D1715)),
    listOf(Color(0xFF24272E), Color(0xFF59616D), Color(0xFF101216))
)

data class LaunchableApp(val label: String, val packageName: String, val info: ResolveInfo)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FlowLauncher() }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FlowLauncher() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("flow_os", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("home") }
    var search by remember { mutableStateOf("") }
    var clock by remember { mutableStateOf(now("HH:mm")) }
    var date by remember { mutableStateOf(now("EEEE, d MMMM")) }
    var paletteIndex by remember { mutableIntStateOf(prefs.getInt("palette", 0).coerceIn(palettes.indices)) }
    var favouritePackages by remember {
        mutableStateOf(prefs.getStringSet("favourites", emptySet())?.toSet() ?: emptySet())
    }
    var statusMessage by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            clock = now("HH:mm")
            date = now("EEEE, d MMMM")
            delay(1000)
        }
    }

    val apps = remember {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        context.packageManager.queryIntentActivities(intent, 0)
            .map { LaunchableApp(it.loadLabel(context.packageManager).toString(), it.activityInfo.packageName, it) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }
    val filtered = apps.filter { it.label.contains(search, ignoreCase = true) }
    val favourites = favouritePackages.mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } }.take(4)
    val displayedFavourites = if (favourites.isNotEmpty()) favourites else apps.filter { app ->
        listOf("phone", "message", "chrome", "camera", "browser").any { app.label.contains(it, true) }
    }.take(4).ifEmpty { apps.take(4) }

    Box(Modifier.fillMaxSize().background(Brush.linearGradient(palettes[paletteIndex]))) {
        when (page) {
            "home" -> Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("FLOW OS", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp,
                        modifier = Modifier.weight(1f))
                    Text(clock, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    IconButton(onClick = { page = "control" }) {
                        Icon(Icons.Default.Tune, contentDescription = "Control Center", tint = Color.White)
                    }
                    IconButton(onClick = { page = "settings" }) {
                        Icon(Icons.Default.Settings, contentDescription = "FLOW OS Settings", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(42.dp))
                Text(date, color = Color.White.copy(alpha = .75f), fontSize = 14.sp)
                Text("Welcome home.", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    HomeTile("Calendar", "Open your calendar", "▦", Modifier.weight(1f)) {
                        openSystem(context, Intent.ACTION_MAIN, "com.google.android.calendar")
                    }
                    HomeTile("Settings", "Device preferences", "⚙", Modifier.weight(1f)) {
                        context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                    }
                }
                Spacer(Modifier.height(26.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Favourites", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { page = "apps" }) { Text("All apps", color = Accent) }
                }
                if (displayedFavourites.isEmpty()) {
                    Text("No launchable apps were found.", color = Color.White.copy(alpha = .7f))
                } else {
                    LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.heightIn(max = 190.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(displayedFavourites, key = { it.packageName }) { app ->
                            AppIcon(app, onClick = { launchApp(context, app) }, onLongClick = {
                                val updated = favouritePackages.toMutableSet().apply {
                                    if (contains(app.packageName)) remove(app.packageName) else if (size < 4) add(app.packageName)
                                }
                                favouritePackages = updated
                                prefs.edit().putStringSet("favourites", updated).apply()
                                statusMessage = if (app.packageName in updated) "${app.label} added to favourites" else "${app.label} removed from favourites"
                            })
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("Tip: press and hold an app to add or remove it from Favourites.",
                    color = Color.White.copy(alpha = .65f), fontSize = 11.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color.White.copy(alpha = .15f)).padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    displayedFavourites.take(4).forEach { app ->
                        AppIcon(app, compact = true, onClick = { launchApp(context, app) }, onLongClick = {
                            val updated = favouritePackages.toMutableSet().apply { remove(app.packageName) }
                            favouritePackages = updated
                            prefs.edit().putStringSet("favourites", updated).apply()
                        })
                    }
                    IconButton(onClick = { page = "apps" }) {
                        Icon(Icons.Default.Apps, contentDescription = "App Library", tint = Color.White)
                    }
                }
            }
            "apps" -> Column(Modifier.fillMaxSize().padding(20.dp)) {
                PageHeader("App Library", onBack = { page = "home" })
                OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true, placeholder = { Text("Search installed apps") }, leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null)
                    })
                Spacer(Modifier.height(14.dp))
                Text("${filtered.size} apps", color = Color.White.copy(alpha = .65f), fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered, key = { it.packageName }) { app -> AppIcon(app, onClick = { launchApp(context, app) }, onLongClick = {
                        val updated = favouritePackages.toMutableSet().apply {
                            if (contains(app.packageName)) remove(app.packageName) else if (size < 4) add(app.packageName)
                        }
                        favouritePackages = updated
                        prefs.edit().putStringSet("favourites", updated).apply()
                        statusMessage = if (app.packageName in updated) "${app.label} added to favourites" else "${app.label} removed from favourites"
                    }) }
                }
            }
            "control" -> Column(Modifier.fillMaxSize().padding(22.dp)) {
                PageHeader("Control Center", onBack = { page = "home" })
                Text("Quick access to your Android device settings", color = Color.White.copy(alpha = .7f), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), onClick = { page = "settings" },
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .18f))) {
                    Text("FLOW OS appearance & about", Modifier.padding(17.dp), color = Color.White, fontSize = 15.sp)
                }
                Spacer(Modifier.height(8.dp))
                val controls = listOf(
                    "Internet" to android.provider.Settings.Panel.ACTION_INTERNET_CONNECTIVITY,
                    "Bluetooth" to android.provider.Settings.ACTION_BLUETOOTH_SETTINGS,
                    "Airplane mode" to android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS,
                    "Display & brightness" to android.provider.Settings.ACTION_DISPLAY_SETTINGS,
                    "Sound & vibration" to android.provider.Settings.ACTION_SOUND_SETTINGS,
                    "Battery" to android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS,
                    "Notifications" to android.provider.Settings.ACTION_NOTIFICATION_SETTINGS,
                    "All device settings" to android.provider.Settings.ACTION_SETTINGS
                )
                controls.forEach { (label, action) ->
                    Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).combinedClickable(onClick = {
                        try { context.startActivity(Intent(action)) } catch (_: Exception) { statusMessage = "That settings screen is not available on this device." }
                    }), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .13f))) {
                        Text(label, Modifier.padding(17.dp), color = Color.White, fontSize = 15.sp)
                    }
                }
            }
            "settings" -> Column(Modifier.fillMaxSize().padding(22.dp)) {
                PageHeader("FLOW OS Settings", onBack = { page = "home" })
                Text("Appearance", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("Choose a home-screen colour theme", color = Color.White.copy(alpha = .7f), fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                palettes.forEachIndexed { index, colors ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .12f))
                        .combinedClickable(onClick = {
                            paletteIndex = index
                            prefs.edit().putInt("palette", index).apply()
                        }).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(colors)))
                        Text(listOf("Ocean", "Violet", "Forest", "Sunset", "Graphite")[index],
                            color = Color.White, modifier = Modifier.weight(1f).padding(start = 14.dp))
                        if (paletteIndex == index) Text("Selected", color = Accent, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(9.dp))
                }
                Spacer(Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .12f))) {
                    Column(Modifier.padding(16.dp)) {
                        Text("About FLOW OS", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("FLOW OS is a home-screen launcher for Android. Your existing Android apps and system services remain in control.",
                            color = Color.White.copy(alpha = .75f), fontSize = 12.sp)
                        Text("Version 1.1", color = Accent, fontSize = 11.sp)
                    }
                }
            }
        }

        if (statusMessage.isNotBlank()) {
            Surface(Modifier.align(Alignment.BottomCenter).padding(18.dp), color = Color(0xEE182536), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(statusMessage, color = Color.White, fontSize = 12.sp)
                    Spacer(Modifier.width(10.dp))
                    TextButton(onClick = { statusMessage = "" }) { Text("OK", color = Accent) }
                }
            }
        }
        if (page != "home") {
            // Back navigation remains visible on every secondary screen.
        }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        IconButton(onClick = onBack) { Icon(Icons.Default.Close, contentDescription = "Back", tint = Color.White) }
    }
}

@Composable
private fun HomeTile(title: String, subtitle: String, symbol: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.fillMaxWidth(), onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .88f)),
        shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(symbol, fontSize = 25.sp, color = Color(0xFF14243B))
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color(0xFF14243B), fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color(0xFF14243B).copy(alpha = .7f), fontSize = 11.sp)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppIcon(app: LaunchableApp, compact: Boolean = false, onClick: () -> Unit, onLongClick: () -> Unit) {
    val context = LocalContext.current
    Column(horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(2.dp)) {
        Surface(shape = RoundedCornerShape(if (compact) 14.dp else 17.dp), color = Color.White.copy(alpha = .17f),
            modifier = Modifier.size(if (compact) 46.dp else 58.dp)) {
            Box(contentAlignment = Alignment.Center) {
                val drawable = remember(app.packageName) { app.info.loadIcon(context.packageManager) }
                androidx.compose.ui.viewinterop.AndroidView(factory = {
                    android.widget.ImageView(it).apply {
                        setImageDrawable(drawable)
                        scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                        setPadding(8, 8, 8, 8)
                    }
                })
            }
        }
        if (!compact) {
            Spacer(Modifier.height(5.dp))
            Text(app.label, color = Color.White, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center)
        }
    }
}

private fun launchApp(context: Context, app: LaunchableApp) {
    val intent = context.packageManager.getLaunchIntentForPackage(app.packageName) ?: return
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { context.startActivity(intent) } catch (_: Exception) { }
}

private fun openSystem(context: Context, action: String, fallbackPackage: String) {
    try { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) {
        try { context.startActivity(context.packageManager.getLaunchIntentForPackage(fallbackPackage)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { }
    }
}

private fun now(pattern: String): String = SimpleDateFormat(pattern, Locale.getDefault()).format(Date())
