MCQ Practice Hub — Android Project

এই ZIP-এ আপনার MCQ HTML অ্যাপটি Android WebView অ্যাপ হিসেবে প্যাকেজ করা আছে। এটি APK ফাইল নয়; এই পরিবেশে Android SDK/Gradle build tool পাওয়া যায়নি, তাই ইনস্টলযোগ্য APK তৈরি করা সম্ভব হয়নি।

APK তৈরির ধাপ:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP ফাইলটি Extract করুন।
3. Android Studio > Open > Extract করা MCQPracticeHub ফোল্ডারটি নির্বাচন করুন।
4. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন। SDK 35 ও JDK 17 বা উপযুক্ত JDK ইনস্টল করতে বললে ইনস্টল করুন।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
6. Build সফল হলে app/build/outputs/apk/debug/app-debug.apk ফাইলটি পাবেন।
7. APK ফোনে কপি করে খুলুন। Android চাইলে “Install unknown apps” অনুমতি দিন।

নোট:
- অ্যাপটি HTML ফাইলকে লোকালভাবে চালায়; মূল কুইজ ব্যবহারে ইন্টারনেট পারমিশন যোগ করা হয়নি।
- প্রশ্ন শোনার কণ্ঠ/অ্যাকসেন্ট Android ফোনে ইনস্টল করা Text-to-Speech voice-এর ওপর নির্ভর করে।
- APK build হওয়ার পর বাস্তব ফোনে পরীক্ষা করে দেখা উচিত।
