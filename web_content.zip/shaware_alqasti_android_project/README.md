# شوارع القاصطي 3D

ملف اللعبة `app/src/main/assets/index.html` يدمج المشهد الافتتاحي الأصلي مع نسخة العالم المفتوح التجريبية. هذا مشروع Android Studio المصدر، وليس APK جاهزًا. افتحه في Android Studio وابنِ APK من قائمة Build.
