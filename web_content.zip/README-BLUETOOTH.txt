POS Móvil - versión corregida para Bluetooth

Esta versión agrega un puente Android real para Bluetooth Classic / ESC-POS.

Uso:
1. Compila este proyecto como APK.
2. Instala la APK.
3. En Ajustes > Bluetooth, vincula la impresora térmica.
4. Dentro del POS, usa la opción de impresora Bluetooth.
5. Selecciona la impresora vinculada.
6. La selección queda guardada localmente.

Importante:
- Esta implementación está pensada para impresoras térmicas Bluetooth Classic con ESC/POS (SPP).
- No garantiza compatibilidad con impresoras que solamente usan BLE, Wi-Fi o un protocolo propietario.
- Para Android 12+ se solicitan BLUETOOTH_SCAN y BLUETOOTH_CONNECT.
- La impresión envía texto UTF-8 y comandos ESC/POS básicos. Algunas impresoras requieren una codificación específica para acentos/ñ.
