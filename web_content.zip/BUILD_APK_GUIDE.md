# MT Doreen-14 Tank Dip Calculator — APK Build Guide

## Option 1: Build Android APK with Capacitor (Recommended)
Prerequisites: Node.js (v18+) and Android Studio installed on your PC.

1. Extract this ZIP folder and open a terminal inside it.
2. Install dependencies and build the web bundle:
   npm install
   npm run build
3. Add Capacitor and Android platform:
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap add android
   npx cap sync android
4. Open in Android Studio and build APK:
   npx cap open android
   In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

## Option 2: Offline Single HTML File
Open `standalone/MT_Doreen14_Tank_Dip_Calculator.html` directly in any mobile or desktop browser—no internet required.
