'use strict';

/* =========================================================
   SUPER CLOCK — app logic
   Vanilla JS, no dependencies. Organized into small modules:
   Storage, Sound, Toast, Navigation, Clock, Alarms,
   Stopwatch, Timer, Theme/Settings, then init() wires it up.
   ========================================================= */

/* ---------- Storage helper (resilient to private-mode errors) ---------- */
const Store = {
  get(key, fallback) {
    try {
      const v = localStorage.getItem(key);
      return v === null ? fallback : JSON.parse(v);
    } catch (e) {
      return fallback;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      /* storage unavailable (private mode / quota) — app still works, just won't persist */
    }
  }
};

/* ---------- App state ---------- */
const state = {
  format24: Store.get('sc_format24', true),
  msMode: Store.get('sc_msMode', false),
  theme: Store.get('sc_theme', 'dark'),
  accent: Store.get('sc_accent', '#ff1744'),
  sound: Store.get('sc_sound', {
    tick: false, ui: false, ambience: false,
    tickVol: 50, uiVol: 50, ambienceVol: 30,
    master: true
  }),
  alarms: Store.get('sc_alarms', [])
};

/* =========================================================
   SOUND STUDIO — Web Audio API, synthesized tones only.
   Audio never starts until the user taps "Enable Sound".
   ========================================================= */
let audioCtx = null;
let masterGain, tickGain, uiGain, ambienceGain;
let ambienceNodes = null;
let alarmInterval = null;

function ensureAudio() {
  if (audioCtx) return true;
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    audioCtx = new Ctx();

    masterGain = audioCtx.createGain();
    masterGain.gain.value = state.sound.master ? 1 : 0;
    masterGain.connect(audioCtx.destination);

    tickGain = audioCtx.createGain();
    tickGain.gain.value = state.sound.tickVol / 100;
    tickGain.connect(masterGain);

    uiGain = audioCtx.createGain();
    uiGain.gain.value = state.sound.uiVol / 100;
    uiGain.connect(masterGain);

    ambienceGain = audioCtx.createGain();
    ambienceGain.gain.value = state.sound.ambienceVol / 100;
    ambienceGain.connect(masterGain);

    return true;
  } catch (e) {
    showToast('Web Audio is not supported on this device.');
    return false;
  }
}

function playStartupSound() {
  if (!audioCtx) return;
  const t0 = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(220, t0);
  osc.frequency.exponentialRampToValueAtTime(880, t0 + 0.35);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(0.25, t0 + 0.05);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.4);
  osc.connect(g); g.connect(masterGain);
  osc.start(t0); osc.stop(t0 + 0.45);
}

function playTick() {
  if (!audioCtx || !state.sound.tick) return;
  const t0 = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  osc.type = 'square';
  osc.frequency.value = 1800;
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(0.6, t0 + 0.002);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.04);
  osc.connect(g); g.connect(tickGain);
  osc.start(t0); osc.stop(t0 + 0.05);
}

function playUiClick() {
  if (!audioCtx || !state.sound.ui) return;
  const t0 = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(900, t0);
  osc.frequency.exponentialRampToValueAtTime(500, t0 + 0.08);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(0.4, t0 + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.1);
  osc.connect(g); g.connect(uiGain);
  osc.start(t0); osc.stop(t0 + 0.12);
}

function playAlertBeep() {
  if (!audioCtx) return;
  [0, 0.2, 0.4].forEach((delay) => {
    const t0 = audioCtx.currentTime + delay;
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = 'square';
    osc.frequency.value = 1200;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(0.5, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.15);
    osc.connect(g); g.connect(masterGain);
    osc.start(t0); osc.stop(t0 + 0.16);
  });
}

function playAlarmSound() {
  if (!audioCtx) return;
  stopAlarmSound();
  playAlertBeep();
  alarmInterval = setInterval(playAlertBeep, 600);
}
function stopAlarmSound() {
  if (alarmInterval) {
    clearInterval(alarmInterval);
    alarmInterval = null;
  }
}

function startAmbience() {
  if (!audioCtx || ambienceNodes) return;
  const osc1 = audioCtx.createOscillator();
  const osc2 = audioCtx.createOscillator();
  osc1.type = 'sine'; osc1.frequency.value = 60;
  osc2.type = 'sine'; osc2.frequency.value = 90.5; // slight detune → slow drone beat

  const lfo = audioCtx.createOscillator();
  const lfoGain = audioCtx.createGain();
  lfo.frequency.value = 0.08;
  lfoGain.gain.value = 0.03;
  lfo.connect(lfoGain);

  const g = audioCtx.createGain();
  g.gain.value = 0.2;
  lfoGain.connect(g.gain);

  osc1.connect(g); osc2.connect(g); g.connect(ambienceGain);
  osc1.start(); osc2.start(); lfo.start();
  ambienceNodes = { osc1, osc2, lfo };
}
function stopAmbience() {
  if (!ambienceNodes) return;
  const { osc1, osc2, lfo } = ambienceNodes;
  try { osc1.stop(); osc2.stop(); lfo.stop(); } catch (e) { /* already stopped */ }
  ambienceNodes = null;
}

function updateSoundStatus() {
  const dot = document.getElementById('soundStatus');
  dot.classList.toggle('on', !!audioCtx && state.sound.master);
}

/* Pause/resume the whole audio graph when the tab/app is backgrounded. */
function wireVisibilityAudioSuspend() {
  document.addEventListener('visibilitychange', () => {
    if (!audioCtx) return;
    if (document.hidden) audioCtx.suspend();
    else audioCtx.resume();
  });
}

/* =========================================================
   TOAST — small in-app notification banner
   ========================================================= */
let toastTimeout;
function showToast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => el.classList.remove('show'), 3000);
}

/* =========================================================
   NAVIGATION
   ========================================================= */
function switchView(view) {
  document.querySelectorAll('.view').forEach((s) => s.classList.remove('active'));
  document.getElementById('view-' + view).classList.add('active');
  document.querySelectorAll('.nav-btn').forEach((b) => {
    const active = b.dataset.view === view;
    b.classList.toggle('active', active);
    b.setAttribute('aria-selected', String(active));
  });
  playUiClick();
}

/* =========================================================
   CLOCK
   ========================================================= */
let lastSecondKey = null;

function applyFormatUI() {
  const label = state.format24 ? '24H' : '12H';
  document.getElementById('toggleFormatBtn').textContent = label;
  document.getElementById('settingsFormatBtn').textContent = label;
  document.getElementById('ampm').classList.toggle('hidden', state.format24);
}

function renderClockFace(now) {
  let h = now.getHours();
  const ampm = h >= 12 ? 'PM' : 'AM';
  if (!state.format24) {
    h = h % 12;
    if (h === 0) h = 12;
  }
  document.getElementById('hours').textContent = String(h).padStart(2, '0');
  document.getElementById('minutes').textContent = String(now.getMinutes()).padStart(2, '0');
  document.getElementById('seconds').textContent = String(now.getSeconds()).padStart(2, '0');
  if (!state.format24) document.getElementById('ampm').textContent = ampm;
  document.getElementById('dateDisplay').textContent = now.toLocaleDateString(undefined, {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });
}

function flashSeconds() {
  const el = document.getElementById('seconds');
  el.classList.remove('flash');
  void el.offsetWidth; // restart the CSS animation
  el.classList.add('flash');
}

function tickClock() {
  const now = new Date();
  const key = now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
  if (key !== lastSecondKey) {
    lastSecondKey = key;
    renderClockFace(now);
    flashSeconds();
    if (state.sound.tick) playTick();
    checkAlarms(now);
  }
  if (state.msMode) {
    document.getElementById('ms').textContent = '.' + String(now.getMilliseconds()).padStart(3, '0');
  }
}

function clockLoop() {
  tickClock();
  requestAnimationFrame(clockLoop);
}

/* =========================================================
   ALARMS
   ========================================================= */
function saveAlarms() { Store.set('sc_alarms', state.alarms); }

function formatAlarmTime(hhmm) {
  if (state.format24) return hhmm;
  const [h, m] = hhmm.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  let hr = h % 12;
  if (hr === 0) hr = 12;
  return `${hr}:${String(m).padStart(2, '0')} ${period}`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function checkAlarms(now) {
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  const current = `${hh}:${mm}`;
  let changed = false;
  state.alarms.forEach((alarm) => {
    if (!alarm.enabled || alarm.time !== current) return;
    const todayKey = now.toDateString() + ' ' + current;
    if (alarm.lastRing !== todayKey) {
      alarm.lastRing = todayKey;
      changed = true;
      ringAlarm(alarm);
    }
  });
  if (changed) saveAlarms();
}

function ringAlarm(alarm) {
  document.getElementById('alarmOverlayText').textContent = '⏰ ' + (alarm.label || 'Alarm');
  document.getElementById('alarmOverlay').classList.remove('hidden');
  playAlarmSound();
  if (navigator.vibrate) navigator.vibrate([400, 200, 400, 200, 400]);
  showToast('Alarm: ' + (alarm.label || alarm.time));
}

function renderAlarms() {
  const list = document.getElementById('alarmList');
  list.innerHTML = '';
  if (state.alarms.length === 0) {
    const li = document.createElement('li');
    li.className = 'empty';
    li.textContent = 'No alarms yet.';
    list.appendChild(li);
    return;
  }
  state.alarms
    .slice()
    .sort((a, b) => a.time.localeCompare(b.time))
    .forEach((alarm) => {
      const li = document.createElement('li');
      li.className = 'alarm-item' + (alarm.enabled ? '' : ' disabled');
      li.innerHTML = `
        <span class="alarm-time">${formatAlarmTime(alarm.time)}</span>
        <span class="alarm-label">${escapeHtml(alarm.label || '')}</span>
        <button class="icon-btn toggle" type="button" aria-label="${alarm.enabled ? 'Disable' : 'Enable'} alarm">${alarm.enabled ? '🔔' : '🔕'}</button>
        <button class="icon-btn delete" type="button" aria-label="Delete alarm">🗑️</button>
      `;
      li.querySelector('.toggle').addEventListener('click', () => {
        alarm.enabled = !alarm.enabled;
        saveAlarms();
        renderAlarms();
        playUiClick();
      });
      li.querySelector('.delete').addEventListener('click', () => {
        state.alarms = state.alarms.filter((a) => a.id !== alarm.id);
        saveAlarms();
        renderAlarms();
        playUiClick();
      });
      list.appendChild(li);
    });
}

/* =========================================================
   STOPWATCH
   ========================================================= */
const sw = { running: false, startTime: 0, elapsed: 0, laps: [], raf: null };

function swFormat(ms) {
  const totalMs = Math.max(0, Math.floor(ms));
  const m = Math.floor(totalMs / 60000);
  const s = Math.floor((totalMs % 60000) / 1000);
  const cs = Math.floor((totalMs % 1000) / 10);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
}

function swTick() {
  const now = performance.now();
  document.getElementById('swDisplay').textContent = swFormat(sw.elapsed + (now - sw.startTime));
  sw.raf = requestAnimationFrame(swTick);
}

function swStartPause() {
  playUiClick();
  if (!sw.running) {
    sw.running = true;
    sw.startTime = performance.now();
    swTick();
    document.getElementById('swStartPause').textContent = 'Pause';
    document.getElementById('swLap').disabled = false;
  } else {
    sw.running = false;
    sw.elapsed += performance.now() - sw.startTime;
    cancelAnimationFrame(sw.raf);
    document.getElementById('swStartPause').textContent = 'Resume';
  }
}

function swReset() {
  playUiClick();
  sw.running = false;
  cancelAnimationFrame(sw.raf);
  sw.elapsed = 0;
  sw.laps = [];
  document.getElementById('swDisplay').textContent = '00:00.00';
  document.getElementById('swStartPause').textContent = 'Start';
  document.getElementById('swLap').disabled = true;
  renderLaps();
}

function swLap() {
  playUiClick();
  const now = performance.now();
  const total = sw.elapsed + (sw.running ? now - sw.startTime : 0);
  sw.laps.unshift(total);
  renderLaps();
}

function renderLaps() {
  const list = document.getElementById('lapList');
  list.innerHTML = '';
  sw.laps.forEach((t, i) => {
    const li = document.createElement('li');
    li.textContent = `Lap ${sw.laps.length - i}: ${swFormat(t)}`;
    list.appendChild(li);
  });
}

/* =========================================================
   TIMER (countdown)
   ========================================================= */
const timer = { remaining: 0, running: false, raf: null, lastTick: 0 };

function timerFormat(totalSeconds) {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.floor(totalSeconds % 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function timerStartPause() {
  playUiClick();
  const errEl = document.getElementById('timerError');
  errEl.textContent = '';

  if (!timer.running) {
    if (timer.remaining <= 0) {
      const h = parseInt(document.getElementById('timerH').value, 10) || 0;
      const m = parseInt(document.getElementById('timerM').value, 10) || 0;
      const s = parseInt(document.getElementById('timerS').value, 10) || 0;
      const total = Math.max(0, h) * 3600 + Math.max(0, Math.min(59, m)) * 60 + Math.max(0, Math.min(59, s));
      if (total <= 0) {
        errEl.textContent = 'Set a time greater than zero.';
        return;
      }
      timer.remaining = total;
    }
    timer.running = true;
    timer.lastTick = performance.now();
    document.getElementById('timerStartPause').textContent = 'Pause';
    document.getElementById('timerInputs').classList.add('disabled');
    timerLoop();
  } else {
    timer.running = false;
    cancelAnimationFrame(timer.raf);
    document.getElementById('timerStartPause').textContent = 'Resume';
  }
}

function timerLoop() {
  const now = performance.now();
  // Catch up in one pass if the tab was throttled/backgrounded, instead of
  // draining one second per frame.
  while (now - timer.lastTick >= 1000 && timer.remaining > 0) {
    timer.lastTick += 1000;
    timer.remaining -= 1;
  }
  if (timer.remaining <= 0) {
    timer.remaining = 0;
    document.getElementById('timerDisplay').textContent = timerFormat(0);
    finishTimer();
    return;
  }
  document.getElementById('timerDisplay').textContent = timerFormat(timer.remaining);
  timer.raf = requestAnimationFrame(timerLoop);
}

function finishTimer() {
  timer.running = false;
  document.getElementById('timerStartPause').textContent = 'Start';
  document.getElementById('timerInputs').classList.remove('disabled');
  showToast('⏲️ Timer finished');
  playAlertBeep();
  if (navigator.vibrate) navigator.vibrate([300, 100, 300]);
}

function timerReset() {
  playUiClick();
  timer.running = false;
  cancelAnimationFrame(timer.raf);
  timer.remaining = 0;
  document.getElementById('timerDisplay').textContent = '00:00:00';
  document.getElementById('timerStartPause').textContent = 'Start';
  document.getElementById('timerInputs').classList.remove('disabled');
  document.getElementById('timerError').textContent = '';
}

/* =========================================================
   THEME / ACCENT
   ========================================================= */
function applyTheme() {
  document.documentElement.setAttribute('data-theme', state.theme);
  document.getElementById('themeToggleBtn').textContent = state.theme === 'dark' ? 'Dark Neon' : 'Light';
}
function applyAccent() {
  document.documentElement.style.setProperty('--accent', state.accent);
}

/* =========================================================
   BACKGROUND PARTICLES (decorative, cheap CSS animation)
   ========================================================= */
function spawnParticles() {
  const container = document.querySelector('.bg-fx');
  const colors = ['var(--accent)', 'var(--accent2)', 'var(--accent3)', 'var(--accent4)'];
  const frag = document.createDocumentFragment();
  for (let i = 0; i < 22; i++) {
    const p = document.createElement('span');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + '%';
    p.style.top = Math.random() * 100 + '%';
    p.style.animationDelay = (Math.random() * 8).toFixed(2) + 's';
    p.style.animationDuration = (6 + Math.random() * 8).toFixed(2) + 's';
    p.style.color = colors[i % colors.length];
    p.style.background = colors[i % colors.length];
    frag.appendChild(p);
  }
  container.appendChild(frag);
}

/* =========================================================
   SERVICE WORKER
   ========================================================= */
function registerSW() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('service-worker.js').catch(() => {
        // Offline caching unavailable here (e.g. opened via file://).
        // The app still works normally while online.
      });
    });
  }
}

/* =========================================================
   Sound toggle + volume wiring (shared by tick / ui / ambience)
   ========================================================= */
function wireSoundToggle(toggleId, volId, key) {
  const toggle = document.getElementById(toggleId);
  const vol = document.getElementById(volId);
  toggle.checked = !!state.sound[key];
  vol.value = state.sound[key + 'Vol'];

  toggle.addEventListener('change', () => {
    state.sound[key] = toggle.checked;
    Store.set('sc_sound', state.sound);
    if (key === 'ambience') {
      if (toggle.checked && audioCtx) startAmbience();
      else stopAmbience();
    }
    playUiClick();
  });

  vol.addEventListener('input', () => {
    state.sound[key + 'Vol'] = Number(vol.value);
    Store.set('sc_sound', state.sound);
    const node = key === 'tick' ? tickGain : key === 'ui' ? uiGain : ambienceGain;
    if (node) node.gain.value = Number(vol.value) / 100;
  });
}

/* =========================================================
   INIT — wire up all UI and start the clock
   ========================================================= */
function init() {
  // Navigation
  document.querySelectorAll('.nav-btn').forEach((btn) => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });

  // Clock format + ms mode
  applyFormatUI();
  [document.getElementById('toggleFormatBtn'), document.getElementById('settingsFormatBtn')].forEach((btn) => {
    btn.addEventListener('click', () => {
      state.format24 = !state.format24;
      Store.set('sc_format24', state.format24);
      applyFormatUI();
      renderAlarms();
      playUiClick();
    });
  });
  document.getElementById('toggleMsBtn').textContent = state.msMode ? 'MS: On' : 'MS: Off';
  document.getElementById('ms').classList.toggle('hidden', !state.msMode);
  document.getElementById('toggleMsBtn').addEventListener('click', () => {
    state.msMode = !state.msMode;
    Store.set('sc_msMode', state.msMode);
    document.getElementById('toggleMsBtn').textContent = state.msMode ? 'MS: On' : 'MS: Off';
    document.getElementById('ms').classList.toggle('hidden', !state.msMode);
    playUiClick();
  });

  // Theme + accent
  applyTheme();
  applyAccent();
  document.getElementById('themeToggleBtn').addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    Store.set('sc_theme', state.theme);
    applyTheme();
    playUiClick();
  });
  document.querySelectorAll('.swatch').forEach((swatch) => {
    swatch.addEventListener('click', () => {
      state.accent = swatch.dataset.color;
      Store.set('sc_accent', state.accent);
      applyAccent();
      playUiClick();
    });
  });

  // Stopwatch
  document.getElementById('swStartPause').addEventListener('click', swStartPause);
  document.getElementById('swLap').addEventListener('click', swLap);
  document.getElementById('swReset').addEventListener('click', swReset);
  renderLaps();

  // Timer
  document.getElementById('timerStartPause').addEventListener('click', timerStartPause);
  document.getElementById('timerReset').addEventListener('click', timerReset);

  // Alarms
  renderAlarms();
  document.getElementById('alarmForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const time = document.getElementById('alarmTime').value;
    if (!time) return;
    const label = document.getElementById('alarmLabel').value.trim().slice(0, 30);
    state.alarms.push({
      id: Date.now() + '-' + Math.random().toString(16).slice(2),
      time, label, enabled: true, lastRing: null
    });
    saveAlarms();
    renderAlarms();
    e.target.reset();
    playUiClick();
    showToast('Alarm added for ' + formatAlarmTime(time));
  });
  document.getElementById('alarmDismissBtn').addEventListener('click', () => {
    document.getElementById('alarmOverlay').classList.add('hidden');
    stopAlarmSound();
    playUiClick();
  });

  // Sound Studio
  document.getElementById('enableSoundBtn').addEventListener('click', () => {
    if (!ensureAudio()) return;
    if (audioCtx.state === 'suspended') audioCtx.resume();
    playStartupSound();
    document.getElementById('soundStatusText').textContent = 'Sound enabled — adjust channels below.';
    document.getElementById('enableSoundBtn').textContent = 'Sound Enabled ✓';
    document.getElementById('enableSoundBtn').disabled = true;
    if (state.sound.ambience) startAmbience();
    updateSoundStatus();
  });
  wireSoundToggle('tickToggle', 'tickVol', 'tick');
  wireSoundToggle('uiToggle', 'uiVol', 'ui');
  wireSoundToggle('ambienceToggle', 'ambienceVol', 'ambience');

  document.getElementById('masterMuteBtn').textContent = state.sound.master ? 'Master Mute' : 'Unmute';
  document.getElementById('masterMuteBtn').addEventListener('click', () => {
    state.sound.master = !state.sound.master;
    Store.set('sc_sound', state.sound);
    if (masterGain) masterGain.gain.value = state.sound.master ? 1 : 0;
    document.getElementById('masterMuteBtn').textContent = state.sound.master ? 'Master Mute' : 'Unmute';
    updateSoundStatus();
  });
  wireVisibilityAudioSuspend();

  // Decorative background + offline support
  spawnParticles();
  registerSW();

  // Start the live clock
  requestAnimationFrame(clockLoop);
}

init();
