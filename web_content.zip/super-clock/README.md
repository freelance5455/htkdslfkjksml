# SUPER CLOCK 🕷️ — Setup & Deployment Guide

A cinematic neon, spider-hacking-themed clock, stopwatch, timer and alarm PWA. Plain HTML/CSS/JS — no frameworks, no backend, no paid services.

## Project structure

```
super-clock/
├── index.html
├── style.css
├── script.js
├── manifest.json
├── service-worker.js
└── icon.svg
```

All six files must stay in the same folder with these exact names — `index.html` links to `style.css`/`script.js` by filename, and the manifest/service worker reference `icon.svg` the same way.

## 1. Set up on Android

1. Install a code editor app — e.g. **Acode** or **Termux** (both free, from the Play Store / F-Droid).
2. Create a folder named `super-clock`.
3. Create the six files above inside it and paste in the matching code.
4. Keep the filenames exactly as shown.

## 2. Test it locally

- Easiest: Acode has a built-in "Run"/live-server preview button.
- Or install a small local-server app (e.g. "Simple HTTP Server") pointed at the folder, then open `http://localhost:PORT` in Chrome.
- Opening `index.html` directly (`file://…`) runs the clock fine, but the service worker and "Add to Home screen" prompt need a real server — see below.

## 3. Publish it for free

Upload the six files to a free static host, for example:
- **GitHub Pages** (via the GitHub app or mobile site → "Add file")
- **Netlify Drop** or **Vercel** (mobile-friendly drag-and-drop uploaders)
- **Cloudflare Pages**

All of these serve over HTTPS, which browsers require for service workers and installability — `file://` and plain `http://` won't work, only HTTPS or `localhost`.

## 4. Install as a PWA

1. Open your hosted URL in Chrome for Android.
2. Tap the **⋮** menu → **Add to Home screen** / **Install app**.
3. Launch SUPER CLOCK from your home screen — it runs full-screen, and works offline once it's been opened one time while online (the service worker caches the app files after that).

## 5. Optional: package it as an APK

A PWA is not an `.apk` by itself. If you want a true installable Android package:
- **PWABuilder** (pwabuilder.com) — paste your hosted URL and it packages the PWA into an Android App Bundle/APK you can side-load or submit to Google Play.
- **Trusted Web Activity via Android Studio** — full control, but needs a desktop/laptop with Android Studio, not just a phone.

Either route needs the PWA hosted at a real HTTPS URL first (step 3).

---

## Testing checklist

- [ ] Clock updates every second and matches your phone's clock
- [ ] 12/24-hour toggle changes the display; AM/PM shows only in 12-hour mode
- [ ] Date, weekday, month and year are correct
- [ ] Millisecond mode toggles on/off without breaking the layout
- [ ] Accent-colour swatches change the glow colour app-wide
- [ ] Light/Dark toggle switches themes
- [ ] Stopwatch start/pause/reset/lap all work and laps list correctly
- [ ] Timer rejects 00:00:00, counts down accurately, and shows a finished toast + beep + vibration (where supported)
- [ ] Alarms can be added with/without a label, toggled, deleted, and ring at the right time while the app is open
- [ ] No audio plays before you tap **Enable Sound**
- [ ] Tick / UI / Ambience sounds toggle and volume-slide independently once enabled
- [ ] Master Mute silences everything immediately
- [ ] Bottom nav switches sections with no horizontal overflow on a small screen
- [ ] After hosting over HTTPS: the "Add to Home screen" prompt appears and the app opens full-screen
- [ ] After one online visit, turning on Airplane Mode and reopening the installed app still loads the UI (service-worker cache)

## Known browser limitations

- **Alarms and the timer only fire while the app is open and in the foreground.** Mobile browsers aggressively suspend background tabs/pages, so a browser-based alarm can't reliably wake your phone the way a native alarm app does. A guaranteed wake-you-up alarm needs a native Android app built with `AlarmManager` — that's outside what a PWA can do.
- Background ambience audio pauses automatically when you switch away from the app, per mobile browser power-saving policy.
- "Add to Home screen" / install prompts only appear over HTTPS or `localhost`, never over `file://` or plain HTTP.
- The SVG manifest icon works on most current Chrome versions, but a few older Android WebViews expect PNG icons. If the install prompt never appears, export `icon.svg` as 192×192 and 512×512 PNGs and point `manifest.json` at those instead.
- `navigator.vibrate` (used for alarm/timer buzz) works on most Android Chrome but not on iOS Safari.

## Troubleshooting

**No sound at all**
- Confirm you tapped **Enable Sound** in the Sound Studio tab — audio can never start on its own.
- Check the individual Tick / UI / Ambience toggles and the Master Mute button.
- Some phones mute web audio entirely when the hardware mute switch/silent mode is on.

**"Add to Home screen" never appears**
- Confirm the site is served over HTTPS, not `file://` and not plain `http://`.
- Confirm `manifest.json` and `service-worker.js` sit in the same folder as `index.html`.

**App doesn't work offline**
- You must open the app once while online so the service worker can cache it.
- If you edit a file, clear the site's storage and reload once online, or the old cached version keeps being served.

**Alarms or timer stayed silent**
- The tab/installed window must stay open and in the foreground — see Known Limitations above.
