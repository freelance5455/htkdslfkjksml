BOOKKEEPER VOUCHER MANAGER

Files:
- index.html: the app. Open in Chrome/Edge.
- The Chart of Accounts from chart of accpounts.xlsx is embedded in the app.

Features:
- Expense, Income, Contra and Journal vouchers.
- Uses the BookKeeper import template column names and YYYY-MM-DD dates.
- Separate Excel exports and one combined workbook with separate sheets.
- Search, date filters, edit/delete, JSON backup/restore.
- Local browser storage only.

Important:
- Internet is required at export time to load SheetJS from jsdelivr.net.
- Import each workbook into the correct company in BookKeeper.
- The chart is a shared list; choose the appropriate company-specific ledger when entering.
- Test with one or two sample vouchers in a backup/copy of your BookKeeper company before importing a large batch.
- No opening balances or existing BookKeeper transactions are imported.
