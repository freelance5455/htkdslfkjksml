# ANONYMOUX STUDIO 2.5.2 — Security verification checklist

This is a source-review checklist, not a penetration-test certificate. Items marked **not verified** require execution on the target deployment.

## Source checks completed

- [x] ZIP paths checked for absolute paths, `..` traversal entries and duplicate filenames.
- [x] No `config.local.php`, `.env`, production SQLite database or uploaded user media was present in the source archive.
- [x] Existing private storage `.htaccess` blocks direct access on Apache-compatible hosts.
- [x] SQLite bootstrap checks `pdo_sqlite` before constructing the PDO connection.
- [x] Prepared statements are used in the reviewed authentication, wallet, media, payment and generation paths.
- [x] Mutating API endpoints reviewed use `api_guard()` and session CSRF token checks.
- [x] User media retrieval checks the authenticated owner/job association.
- [x] Provider permanent keys remain in backend configuration/key-vault code, not browser source.
- [x] First-admin registration uses a SQLite write transaction and a bootstrap lock row.
- [x] Image and Video billing reservations use a unique job identifier and atomic conditional wallet debit.
- [x] Refunds are limited to operations still in `reserved` state.
- [x] Image/video uncertain provider outcomes retain reservations instead of allowing immediate duplicate submissions.
- [x] HTTPS redirect no longer uses arbitrary `HTTP_HOST`; forwarded-protocol headers are trusted only for configured proxy IPs.
- [x] Flutterwave redirect URL no longer uses arbitrary incoming `HTTP_HOST`.

## Not verified / still required

- [ ] Full source-level review of every endpoint for IDOR and ownership enforcement.
- [ ] Full Agent knowledge-source privacy and file-ingestion review.
- [ ] Penetration tests for XSS, CSRF, SSRF, open redirects, host-header abuse, path traversal and privilege escalation.
- [ ] PHP PDO SQLite transaction concurrency tests on the actual PHP version used in production.
- [ ] Review of all admin actions and audit log completeness.
- [ ] Review of webhook replay protection and live Flutterwave signature handling using provider test events.
- [ ] Review of Fish Audio, Magic Hour and agent provider billing for centralized idempotency.
- [ ] Verification that all storage directories are outside the web root or denied by the deployed web server.
- [ ] Verification of `.htaccess` behavior on the actual host.
- [ ] HTTPS, HSTS and secure-cookie verification behind the actual hosting/proxy configuration.
- [ ] Secret rotation and encrypted-key recovery drill.
- [ ] Automated orphan-file dry-run and deletion review.
- [ ] Live Decart/Fish Audio/Magic Hour/Flutterwave integration tests with test credentials.
- [ ] Android and iOS browser session, camera, upload and download tests.

Do not treat unchecked items as passed.
