
package com.dani.headshot

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout

class FloatingService : Service() {

    private lateinit var manager: WindowManager
    private var floatingView: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        manager = getSystemService(WINDOW_SERVICE)
                as WindowManager

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(10, 10, 10, 10)

        val main = Button(this)
        main.text = "🔥 DANI"

        val menu = LinearLayout(this)
        menu.orientation = LinearLayout.VERTICAL
        menu.visibility = android.view.View.GONE

        val aim = Button(this)
        aim.text = "🎯 Aim Practice"

        val sensitivity = Button(this)
        sensitivity.text = "⚙️ Sensitivity"

        val close = Button(this)
        close.text = "❌ Close"

        menu.addView(aim)
        menu.addView(sensitivity)
        menu.addView(close)

        layout.addView(main)
        layout.addView(menu)

        main.setOnClickListener {
            menu.visibility =
                if (menu.visibility == android.view.View.VISIBLE)
                    android.view.View.GONE
                else
                    android.view.View.VISIBLE
        }

        aim.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }

        sensitivity.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }

        close.setOnClickListener {
            stopSelf()
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        params.x = 20

        manager.addView(layout, params)
        floatingView = layout
    }

    override fun onDestroy() {
        floatingView?.let {
            manager.removeView(it)
        }
        floatingView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
