
package com.dani.headshot

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(30, 50, 30, 30)

        val title = TextView(this)
        title.text = "🔥 DANI HEADSHOT"
        title.textSize = 28f

        val permission = Button(this)
        permission.text = "GRANT OVERLAY PERMISSION"

        val start = Button(this)
        start.text = "START FLOATING BUTTON"

        val stop = Button(this)
        stop.text = "STOP FLOATING BUTTON"

        layout.addView(title)
        layout.addView(permission)
        layout.addView(start)
        layout.addView(stop)

        setContentView(layout)

        permission.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        start.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startService(
                    Intent(this, FloatingService::class.java)
                )
            }
        }

        stop.setOnClickListener {
            stopService(
                Intent(this, FloatingService::class.java)
            )
        }
    }
}
