package com.zebra.etiket

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.*
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

@SuppressLint("MissingPermission", "SetJavaScriptEnabled")
class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val adapter: BluetoothAdapter? by lazy { (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter }
    private var sock: BluetoothSocket? = null
    private var out: OutputStream? = null
    private var gatt: BluetoothGatt? = null
    @Volatile private var wch: BluetoothGattCharacteristic? = null
    @Volatile private var chunk = 20
    private val sem = Semaphore(0)
    private val SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val ZSVC = UUID.fromString("38eb4a80-c570-11e3-9507-0002a5d5c51b")
    private val ZWR = UUID.fromString("38eb4a82-c570-11e3-9507-0002a5d5c51b")

    private fun ev(t: String, d: String) = runOnUiThread {
        web.evaluateJavascript("window.btEvent&&window.btEvent(${JSONObject.quote(t)},${JSONObject.quote(d)})", null)
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == BluetoothDevice.ACTION_FOUND) {
                val d = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
                val r = i.getShortExtra(BluetoothDevice.EXTRA_RSSI, 0).toInt()
                val n = d.name ?: i.getStringExtra(BluetoothDevice.EXTRA_NAME) ?: ""
                ev("found", JSONObject().put("n", n).put("a", d.address).put("r", r).toString())
            } else if (i.action == BluetoothAdapter.ACTION_DISCOVERY_FINISHED) ev("scandone", "")
        }
    }

    private fun closeAll() {
        try { sock?.close() } catch (e: Exception) {}
        try { gatt?.close() } catch (e: Exception) {}
        sock = null; out = null; gatt = null; wch = null
    }

    inner class Bridge {
        @JavascriptInterface fun bonded(): String {
            val a = JSONArray()
            try { adapter?.bondedDevices?.forEach { a.put(JSONObject().put("n", it.name ?: "").put("a", it.address)) } } catch (e: Exception) {}
            return a.toString()
        }
        @JavascriptInterface fun scan() {
            try { adapter?.cancelDiscovery(); if (adapter?.startDiscovery() != true) ev("scandone", "") } catch (e: Exception) { ev("scandone", "") }
        }
        @JavascriptInterface fun stop() { try { adapter?.cancelDiscovery() } catch (e: Exception) {} }
        @JavascriptInterface fun disconnect() { closeAll() }

        @JavascriptInterface fun connect(addr: String) {
            Thread {
                try {
                    adapter?.cancelDiscovery(); closeAll()
                    val d = adapter!!.getRemoteDevice(addr)
                    if (d.type != BluetoothDevice.DEVICE_TYPE_LE) {
                        try {
                            val s = d.createRfcommSocketToServiceRecord(SPP)
                            s.connect(); sock = s; out = s.outputStream
                            Thread {
                                val b = ByteArray(512)
                                try { while (true) { val n = s.inputStream.read(b); if (n < 0) break; ev("data", String(b, 0, n)) } } catch (e: Exception) {}
                                ev("closed", "")
                            }.start()
                            ev("connected", "SPP"); return@Thread
                        } catch (e: Exception) {
                            try { sock?.close() } catch (x: Exception) {}
                            sock = null; out = null
                            if (d.type == BluetoothDevice.DEVICE_TYPE_CLASSIC) throw e
                        }
                    }
                    connectBle(d)
                } catch (e: Exception) { ev("error", e.message ?: "bağlanamadı") }
            }.start()
        }

        @JavascriptInterface fun write(b64: String): Boolean {
            return try {
                val b = Base64.decode(b64, Base64.DEFAULT)
                val o = out
                if (o != null) { o.write(b); o.flush(); true }
                else {
                    val g = gatt; val c = wch
                    if (g == null || c == null) false
                    else {
                        c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                        var i = 0
                        while (i < b.size) {
                            val e = minOf(i + chunk, b.size)
                            sem.drainPermits()
                            c.value = b.copyOfRange(i, e)
                            if (!g.writeCharacteristic(c)) return false
                            if (!sem.tryAcquire(3, TimeUnit.SECONDS)) return false
                            i = e
                        }
                        true
                    }
                }
            } catch (e: Exception) { false }
        }
    }

    private fun connectBle(d: BluetoothDevice) {
        val done = CountDownLatch(1)
        var err: String? = null
        val cb = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, s: Int, n: Int) {
                if (n == BluetoothProfile.STATE_CONNECTED) g.requestMtu(185)
                else if (wch == null) { err = "BLE bağlantı hatası ($s)"; done.countDown() }
                else ev("closed", "")
            }
            override fun onMtuChanged(g: BluetoothGatt, mtu: Int, s: Int) {
                chunk = if (s == BluetoothGatt.GATT_SUCCESS) mtu - 3 else 20
                g.discoverServices()
            }
            override fun onServicesDiscovered(g: BluetoothGatt, s: Int) {
                wch = g.getService(ZSVC)?.getCharacteristic(ZWR)
                if (wch == null) err = "Zebra BLE servisi bulunamadı (yazıcı Zebra BLE değil mi?)"
                done.countDown()
            }
            override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, s: Int) { sem.release() }
        }
        gatt = d.connectGatt(this, false, cb, BluetoothDevice.TRANSPORT_LE)
        if (!done.await(15, TimeUnit.SECONDS)) err = "Zaman aşımı"
        if (err != null) { try { gatt?.close() } catch (e: Exception) {}; gatt = null; wch = null; throw Exception(err) }
        ev("connected", "BLE")
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        web = WebView(this); setContentView(web)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = true }
        web.addJavascriptInterface(Bridge(), "AndroidBT")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { startActivityForResult(p.createIntent(), 7); true } catch (e: Exception) { fileCb = null; false }
            }
        }
        registerReceiver(rcv, IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND); addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        })
        val p = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        requestPermissions(p, 1)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 7) { fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); fileCb = null }
        else super.onActivityResult(req, res, data)
    }

    override fun onDestroy() { try { unregisterReceiver(rcv) } catch (e: Exception) {}; closeAll(); super.onDestroy() }
}
