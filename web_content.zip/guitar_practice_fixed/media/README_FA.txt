برای افزودن فیلم‌های آموزشی آفلاین، فایل‌های MP4 مجاز را در این پوشه قرار دهید.
نام‌های پیشنهادی: lesson-posture.mp4، lesson-strings.mp4، lesson-right-hand.mp4، lesson-chords.mp4، lesson-reading.mp4
در حال حاضر ویدئوی واقعی در این پوشه نیست.
