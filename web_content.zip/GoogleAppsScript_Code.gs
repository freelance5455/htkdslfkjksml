/**
 * ALPHA LOAN TRACKER — Google Drive backup receiver
 *
 * SETUP:
 * 1. Visit https://script.google.com and create a new project.
 * 2. Replace Code.gs contents with this file's contents.
 * 3. Deploy > New deployment > Web app.
 * 4. Execute as: Me
 * 5. Who has access: Anyone (or the narrowest option that works for your use).
 * 6. Authorize Drive access and copy the Web app URL ending in /exec.
 * 7. Paste that URL into ALPHA LOAN TRACKER > Backup > Google Drive Backup.
 *
 * Security: Anyone with the deployed URL may submit backups to your Drive.
 * Do not share the URL publicly. For stronger security, add a private token
 * and require it in both this script and the app before using real data.
 */
function doPost(e) {
  try {
    var raw = (e && e.postData && e.postData.contents) || '';
    if (!raw) throw new Error('Empty request');
    var payload = JSON.parse(raw);
    if (payload.app !== 'ALPHA LOAN TRACKER' || !payload.data ||
        !Array.isArray(payload.data.people) ||
        !Array.isArray(payload.data.loans) ||
        !Array.isArray(payload.data.payments)) {
      throw new Error('Invalid backup payload');
    }
    var folderName = 'ALPHA_LOAN_TRACKER_Backups';
    var folders = DriveApp.getFoldersByName(folderName);
    var folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(folderName);
    var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd_HHmmss');
    var fileName = 'ALPHA_LOAN_TRACKER_Backup_' + stamp + '.json';
    var file = folder.createFile(fileName, JSON.stringify(payload, null, 2), MimeType.PLAIN_TEXT);
    return ContentService.createTextOutput(JSON.stringify({
      ok: true, fileId: file.getId(), fileName: fileName
    })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false, error: String(err)
    })).setMimeType(ContentService.MimeType.JSON);
  }
}
