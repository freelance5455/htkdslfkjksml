/**
 * برنامج توزيع الطحين — مزامنة Google Sheets
 * انشر هذا المشروع كتطبيق ويب: التنفيذ بصفة مالك البرنامج، وإمكانية الوصول: أي شخص.
 */
const معرف_جدول_البيانات = '1Wr0xceo7nXFaWYN-liBI6pT4PM49NyBa3XIL6Id61TA';
const ورقة_العوائل = 'العوائل';
const ورقة_التوزيع = 'التوزيع';
const ورقة_المتغيرات = 'المتغيرات';
const ورقة_الإعدادات = 'الإعدادات';
const ورقة_النسخة_الكاملة = 'نسخة كاملة';

function doGet(e) {
  const action=(e&&e.parameter&&e.parameter.action)||'';
  const callback=(e&&e.parameter&&e.parameter.callback)||'';
  if(action!=='restore')return ContentService.createTextOutput('خدمة مزامنة برنامج توزيع الطحين جاهزة.');
  let result;
  try {
    const sh=ورقة(ورقة_النسخة_الكاملة);
    if(sh.getLastRow()<4)throw new Error('لا توجد نسخة محفوظة بعد. نفذ المزامنة من التطبيق أولاً.');
    const rows=sh.getRange(4,2,sh.getLastRow()-3,1).getDisplayValues();
    const raw=rows.map(r=>r[0]).join('');
    if(!raw)throw new Error('ورقة النسخة الكاملة فارغة.');
    result={نجاح:true,رسالة:'تم العثور على النسخة',البيانات:JSON.parse(raw)};
  } catch(err) { result={نجاح:false,رسالة:String(err&&err.message||err)}; }
  const json=JSON.stringify(result).replace(/</g,'\\u003c').replace(/>/g,'\\u003e');
  if(callback&&/^[A-Za-z_$][0-9A-Za-z_$]*$/.test(callback))
    return ContentService.createTextOutput(callback+'('+json+');').setMimeType(ContentService.MimeType.JAVASCRIPT);
  return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(ContentService.MimeType.JSON);
}
function doPost(e) {
  try {
    if(!e||!e.parameter||e.parameter.action!=='sync')throw new Error('نوع الطلب غير معروف.');
    const payload=JSON.parse(e.parameter.payload||'{}');
    if(payload.نوع_الطلب!=='مزامنة'||!payload.البيانات||!payload.البيانات.بيانات_التطبيق)throw new Error('صيغة النسخة غير صحيحة.');
    حفظ_النسخة_الكاملة(payload);تحديث_العوائل(payload);تحديث_التوزيع(payload);تحديث_المتغيرات(payload);تحديث_الإعدادات();
    return ContentService.createTextOutput('تم حفظ النسخة بنجاح');
  } catch(err) { return ContentService.createTextOutput('تعذر الحفظ: '+String(err&&err.message||err)); }
}
function جدول(){return SpreadsheetApp.openById(معرف_جدول_البيانات);}
function ورقة(name){return جدول().getSheetByName(name)||جدول().insertSheet(name);}
function كتابة_الورقة(name,rows){
  const sh=ورقة(name);sh.clearContents();
  const width=Math.max(1,...rows.map(r=>r.length));
  const data=rows.map(r=>{const a=r.slice();while(a.length<width)a.push('');return a;});
  sh.getRange(1,1,data.length,width).setValues(data);sh.setFrozenRows(1);sh.getDataRange().setWrap(true);
  sh.autoResizeColumns(1,Math.min(width,13));return sh;
}
function حفظ_النسخة_الكاملة(payload){
  const json=JSON.stringify(payload.البيانات);
  const chunkSize=35000, chunks=[];
  for(let i=0;i<json.length;i+=chunkSize)chunks.push(json.slice(i,i+chunkSize));
  const rows=[['البيان','القيمة'],['نوع النسخة','نسخة كاملة من بيانات برنامج توزيع الطحين'],['وقت آخر مزامنة',new Date().toLocaleString('ar-IQ')]];
  chunks.forEach((chunk,i)=>rows.push(['جزء النسخة '+(i+1),chunk]));
  const sh=كتابة_الورقة(ورقة_النسخة_الكاملة,rows);sh.setColumnWidth(1,180);sh.setColumnWidth(2,520);sh.getRange(4,2,Math.max(1,chunks.length),1).setWrap(true);
}
function تحديث_العوائل(payload){
  const d=payload.البيانات.بيانات_التطبيق||{},families=d['العوائل']||[];
  const rows=[['المعرف السحابي','اسم رب الأسرة','عدد أفراد الأسرة','الملاحظات','الحالة','تاريخ الإضافة','العوائل المرتبطة']];
  families.forEach(f=>rows.push([f['المعرف']||'',f['اسم رب الأسرة']||'',Number(f['عدد الأفراد']||0),f['الملاحظات']||'',f['فعال']===false?'غير فعال':'فعال',f['تاريخ الإضافة']||'',(f['معرفات العوائل المرتبطة']||[]).join('، ')]));
  كتابة_الورقة(ورقة_العوائل,rows);
}
function تحديث_التوزيع(payload){
  const d=payload.البيانات.بيانات_التطبيق||{},months=d['التوزيعات']||{},families=d['العوائل']||[],familyMap={};
  families.forEach(f=>familyMap[f['المعرف']]=f);
  const rows=[['الشهر والسنة','اسم الموزع','التاريخ','الوقت','معرف العائلة','اسم رب الأسرة','عدد الأفراد','الحصة المقررة بالكغم','الكمية المستلمة بالكغم','المبلغ المستلم بالدينار','حالة الاستلام','تاريخ التسليم','وقت التسليم']];
  Object.keys(months).sort().forEach(month=>{const x=months[month]||{},records=x['سجلات العوائل']||{};
    Object.keys(records).forEach(id=>{const r=records[id]||{},f=familyMap[id]||{},people=Number(f['عدد الأفراد']||0),quota=people*9;
      const got=Number(r['الكمية المستلمة']||((r['استلم الأكياس']?Math.floor(quota/50)*50:0)+(r['استلم الكمية المتبقية']?quota%50:0)));
      rows.push([month,x['اسم الموزع']||'',x['التاريخ']||'',x['الوقت']||'',id,f['اسم رب الأسرة']||'',people,quota,got,Number(r['المبلغ المستلم']||0),r['حالة الاستلام']||(r['تم التسليم']?'تم التسليم':'غير مستلم'),r['تاريخ التسليم']||'',r['وقت التسليم']||'']);
    });
  });
  كتابة_الورقة(ورقة_التوزيع,rows);
}
function تحديث_المتغيرات(payload){
  const vars=(payload.البيانات.بيانات_التطبيق||{})['المتغيرات']||[];
  const rows=[['معرف العملية','معرف العائلة','نوع العملية','العدد','العدد السابق','العدد اللاحق','التاريخ']];
  vars.forEach(v=>rows.push([v['المعرف']||'',v['معرف العائلة']||'',v['نوع العملية']||'',Number(v['العدد']||0),Number(v['العدد السابق']||0),Number(v['العدد اللاحق']||0),v['التاريخ']||'']));
  كتابة_الورقة(ورقة_المتغيرات,rows);
}
function تحديث_الإعدادات(){
  كتابة_الورقة(ورقة_الإعدادات,[['البيان','القيمة'],['اسم البرنامج','برنامج توزيع الطحين'],['حصة الفرد بالكغم',9],['المبلغ المقرر للفرد بالدينار العراقي',250],['وزن كيس الطحين بالكغم',50],['وقت آخر مزامنة',new Date().toLocaleString('ar-IQ')],['ملاحظة','النسخة الكاملة تشمل العوائل والتوزيعات والمتغيرات والبيانات اللازمة للاستعادة.']]);
}
