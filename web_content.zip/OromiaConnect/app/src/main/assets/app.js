const services=[
 {e:'🔧',om:'Meeshaan & suphaa',en:'Repair & Maintenance',n:'12'},
 {e:'💻',om:'Teknoolojii',en:'Technology',n:'24'},
 {e:'🎨',om:'Design',en:'Design',n:'18'},
 {e:'📚',om:'Barsiisaa',en:'Tutoring',n:'31'},
 {e:'🚗',om:'Geejjiba',en:'Transport',n:'9'},
 {e:'🏠',om:'Mana & ijaarsa',en:'Home & Building',n:'16'}
];
const jobs=[
 {t:'Graphic Designer barbaada',d:'Businessii keenyaaf logo fi poster hojjechuuf nama barbaanna.',p:'Waliigaltee irratti',l:'Finfinnee'},
 {t:'English Tutor',d:'Barataa tokkoof English dubbachuu fi barreessuu barsiisi.',p:'ETB 300/sa’aatii',l:'Online'},
 {t:'Mobile App Developer',d:'Prototype Android tokko xumuruuf developer barbaada.',p:'ETB 8,000+',l:'Remote'}
];
let lang='om';
const tx={
 om:{tag:'Namoota, ogummaa fi carraa walitti fidu',welcome:'Baga nagaan dhuftan!',hero:'Ogummaa kee agarsiisi, tajaajila barbaadi, hojii argadhu.',search:'Tajaajila ykn ogummaa barbaadi...',popular:'Tajaajiloota beekamoo',seeall:'Hunda ilaali',jobs:'Hojiiwwan haaraa',services:'Tajaajila & Ogummaa',postjob:'Hojii maxxansi',chat:'Ergaa',profile:'Profile',home:'Mana',mySkills:'Ogummaa koo',edit:'Profile sirreessi'},
 en:{tag:'Connecting people, skills and opportunities',welcome:'Welcome!',hero:'Show your skills, find services and discover jobs.',search:'Search for a service or skill...',popular:'Popular services',seeall:'See all',jobs:'New jobs',services:'Services & Skills',postjob:'Post a job',chat:'Messages',profile:'Profile',home:'Home',mySkills:'My skills',edit:'Edit profile'}
};
function render(){
 const grid=document.getElementById('serviceGrid'), all=document.getElementById('allServices');
 [grid,all].forEach((el)=>el.innerHTML=services.map(s=>`<div class="service"><div class="emoji">${s.e}</div><b>${lang==='om'?s.om:s.en}</b><small>${s.n} providers</small></div>`).join(''));
 const html=jobs.map(j=>`<div class="job"><h3>${j.t}</h3><p>${j.d}</p><div class="meta">💰 ${j.p} &nbsp; 📍 ${j.l}</div></div>`).join('');
 document.getElementById('jobList').innerHTML=html; document.getElementById('allJobs').innerHTML=html;
 document.querySelectorAll('[data-i18n]').forEach(x=>x.textContent=tx[lang][x.dataset.i18n]);
 document.querySelectorAll('[data-i18n-placeholder]').forEach(x=>x.placeholder=tx[lang][x.dataset.i18nPlaceholder]);
}
function showPage(id){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===id));document.querySelectorAll('.bottom button').forEach(b=>b.classList.toggle('active',b.dataset.page===id));window.scrollTo(0,0)}
document.querySelectorAll('.bottom button').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
document.getElementById('theme').onclick=()=>document.body.classList.toggle('dark');
document.getElementById('search').oninput=e=>{const q=e.target.value.toLowerCase();document.getElementById('serviceGrid').innerHTML=services.filter(s=>(s.om+s.en).toLowerCase().includes(q)).map(s=>`<div class="service"><div class="emoji">${s.e}</div><b>${lang==='om'?s.om:s.en}</b><small>${s.n} providers</small></div>`).join('')};
render();
