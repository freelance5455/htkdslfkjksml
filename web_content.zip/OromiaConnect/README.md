# Oromia Connect
A lightweight Afaan Oromoo / English community services app prototype.

## Run
Open `app/src/main/assets/index.html` in a browser to preview.
For Android, create/open an Android Studio project with a WebView pointing to this asset.

## Included
- Home dashboard
- Search
- Services / skills
- Jobs
- Chat mockup
- Profile
- Afaan Oromoo / English toggle
- Dark/light theme
- Local demo data
- Responsive mobile UI

This is a front-end prototype. Real authentication, chat backend, payments and location services require a server/API.
