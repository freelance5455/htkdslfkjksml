import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const client = apiKey ? new OpenAI({ apiKey }) : null;

app.disable("x-powered-by");
app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(client), model: client ? model : null });
});

app.post("/api/tutor", async (req, res) => {
  const question = typeof req.body?.question === "string" ? req.body.question.trim() : "";
  const level = typeof req.body?.level === "string" ? req.body.level.slice(0, 40) : "ESO básico";
  if (!question) return res.status(400).json({ error: "Escribe una pregunta." });
  if (question.length > 4000) return res.status(413).json({ error: "La pregunta es demasiado larga (máximo 4000 caracteres)." });
  if (!client) return res.json({ mode: "local", answer: null, message: "OPENAI_API_KEY no está configurada." });

  try {
    const response = await client.responses.create({
      model,
      instructions: [
        "Eres el tutor matemático y científico de BLACKWING CALC.",
        "Responde en español salvo que el usuario pida otro idioma.",
        `Adapta la explicación al nivel indicado: ${level}.`,
        "En ejercicios, explica el razonamiento paso a paso, muestra las operaciones y verifica el resultado.",
        "Si falta información, pregunta de forma concreta. No inventes datos ni afirmes haber calculado algo que no hayas calculado.",
        "Favorece el aprendizaje: incluye una pista o comprobación cuando sea útil. Sé claro, paciente y preciso."
      ].join(" "),
      input: question,
      max_output_tokens: 900
    });
    const answer = (response.output_text || "").trim();
    if (!answer) return res.status(502).json({ error: "El modelo devolvió una respuesta vacía." });
    res.json({ mode: "ai", answer });
  } catch (err) {
    console.error("Tutor API error:", err?.status || "", err?.message || err);
    res.status(502).json({ error: "No se pudo obtener respuesta del servicio de IA. Revisa la conexión y la configuración del servidor." });
  }
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(port, () => {
  console.log(`BLACKWING CALC V5 disponible en http://localhost:${port}`);
  console.log(client ? `Tutor IA activo con modelo ${model}` : "Tutor IA no configurado: define OPENAI_API_KEY para activarlo.");
});
