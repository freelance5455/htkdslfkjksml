# BLACKWING CALC V5 · OBSIDIAN ENGINE

Proyecto web adaptable a móviles con calculadora científica, historial/favoritos, Academy con XP, gráficas 2D/3D, tutor matemático, fracciones exactas, simulador de proyectiles, sandbox JavaScript, análisis estadístico, finanzas, matrices, conversor de temperatura, Arena, ajustes persistentes e importación/exportación JSON.

## Estructura

```text
blackwing_calc_v5/
├── package.json
├── server.js
├── README.md
└── public/
    └── index.html
```

## Requisitos

- Node.js 20 o posterior recomendado.
- Conexión a Internet para las bibliotecas CDN y para el tutor IA.
- Una clave de API de OpenAI para activar el tutor generativo real.

## Ejecutar en ordenador

1. Instala Node.js desde la web oficial.
2. Abre una terminal dentro de esta carpeta.
3. Ejecuta `npm install`.
4. Configura la clave de API como variable de entorno. No la escribas en `public/index.html` ni la compartas.

Linux/macOS:
```bash
export OPENAI_API_KEY="TU_CLAVE_DE_API"
npm start
```

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="TU_CLAVE_DE_API"
npm start
```

Opcionalmente, elige un modelo compatible:
```bash
export OPENAI_MODEL="gpt-4.1-mini"
```

Abre `http://localhost:3000`.

## Tutor IA: qué funciona y qué necesita

- El frontend envía la pregunta a `/api/tutor`.
- `server.js` llama a la API de OpenAI desde el servidor. La clave nunca se expone en el navegador.
- Si falta la clave o el servidor no está disponible, el navegador intenta dar ayuda local para operaciones, algunas fracciones y ecuaciones lineales sencillas. Esa ayuda local no es un modelo de IA generativa.
- La API de OpenAI puede tener coste y requiere una cuenta con acceso y facturación configurada. Consulta los precios y condiciones vigentes antes de usarla.
- Para desplegar el tutor online, publica el proyecto en un servidor Node compatible y añade `OPENAI_API_KEY` como variable secreta del entorno de despliegue. No subas `.env` ni claves a un repositorio público.

## Abrir solo el HTML

Puedes abrir `public/index.html` directamente para probar algunas funciones del navegador. Sin embargo, el tutor generativo necesita ejecutar `server.js`; si abres el HTML como `file://`, la ruta `/api/tutor` no tendrá un servidor detrás. Las bibliotecas externas también requieren conexión.

## Notas

- El progreso se guarda en `localStorage` del navegador/dispositivo.
- Usa Ajustes → Exportar datos JSON para hacer una copia.
- El CodeLab ejecuta el código introducido en un iframe aislado con sandbox, pero no ejecutes código que no entiendas.
- Las gráficas, la física y las estadísticas son herramientas educativas; revisa las condiciones del modelo usado cuando se necesite precisión científica.
