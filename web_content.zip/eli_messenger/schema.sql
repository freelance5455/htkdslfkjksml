-- Eli Messenger schema for Supabase
-- Run this whole file in Supabase Dashboard > SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (username ~ '^[a-z0-9_]{3,20}$'),
  display_name text not null default 'کاربر',
  created_at timestamptz not null default now()
);
create table if not exists public.messages (
  id bigint generated always as identity primary key,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now(),
  constraint no_self_message check (sender_id <> recipient_id)
);
create index if not exists messages_sender_created_idx on public.messages(sender_id, created_at desc);
create index if not exists messages_recipient_created_idx on public.messages(recipient_id, created_at desc);
create index if not exists profiles_username_idx on public.profiles(username);

alter table public.profiles enable row level security;
alter table public.messages enable row level security;

drop policy if exists "Profiles can be searched by signed-in users" on public.profiles;
create policy "Profiles can be searched by signed-in users" on public.profiles
for select to authenticated using (true);

drop policy if exists "Users can create their own profile" on public.profiles;
create policy "Users can create their own profile" on public.profiles
for insert to authenticated with check (auth.uid() = id);

drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile" on public.profiles
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Participants can read their messages" on public.messages;
create policy "Participants can read their messages" on public.messages
for select to authenticated using (auth.uid() = sender_id or auth.uid() = recipient_id);

drop policy if exists "Users can send as themselves" on public.messages;
create policy "Users can send as themselves" on public.messages
for insert to authenticated with check (auth.uid() = sender_id and sender_id <> recipient_id);

-- Enable Realtime events for messages. If this errors because it is already added, ignore it.
do $$
begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
end $$;
