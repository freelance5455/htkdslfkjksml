// برای فعال‌سازی پیام‌رسان، مقادیر پروژه Supabase خود را اینجا قرار بده.
window.ELI_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_ANON_KEY_HERE"
};