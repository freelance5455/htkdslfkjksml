(() => {
const $ = id => document.getElementById(id);
const cfg = window.ELI_CONFIG || {};
const configured = cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
 !cfg.SUPABASE_URL.includes("PASTE_") && !cfg.SUPABASE_ANON_KEY.includes("PASTE_");
let sb = null, user = null, profile = null, mode = "login", activePeer = null, activeChannel = null;
let profiles = {}, conversations = [], messageChannel = null, toastTimer = null;
const faNum = n => String(n).replace(/\d/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]);
const initials = name => (name || "ا").trim().slice(0,1);
const escapeHtml = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),3200)}
function showAuthMessage(msg){$("authMessage").textContent=msg}
function setMode(next){mode=next;document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.mode===mode));$("nameLabel").classList.toggle("hidden",mode!=="signup");$("usernameLabel").classList.toggle("hidden",mode!=="signup");$("authSubmit").innerHTML=mode==="login"?'ورود به اِلی <span>←</span>':'ساخت حساب اِلی <span>←</span>';showAuthMessage("")}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>setMode(b.dataset.mode)));
function showSetupNotice(){ $("authView").classList.remove("hidden"); $("authForm").addEventListener("submit",e=>{e.preventDefault();showAuthMessage("برای فعال شدن ارتباط واقعی، ابتدا مراحل فایل README را انجام بده و config.js را تنظیم کن.")}); }
async function start(){
 if(!configured || !window.supabase){showSetupNotice();return}
 sb=window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY,{auth:{persistSession:true,autoRefreshToken:true}});
 const {data:{session}}=await sb.auth.getSession();
 if(session) await enterApp(session.user);
 sb.auth.onAuthStateChange((event,session)=>{if(event==="SIGNED_OUT"){user=null;profile=null;$("chatView").classList.add("hidden");$("authView").classList.remove("hidden")}});
}
$("authForm").addEventListener("submit",async e=>{
 e.preventDefault();if(!sb){showAuthMessage("ابتدا تنظیمات اتصال را کامل کن.");return}
 const email=$("email").value.trim(), password=$("password").value;
 $("authSubmit").disabled=true;showAuthMessage("در حال اتصال…");
 try{
  if(mode==="login"){
   const {data,error}=await sb.auth.signInWithPassword({email,password});if(error)throw error;await enterApp(data.user);
  }else{
   const username=$("username").value.trim().toLowerCase(), display_name=$("displayName").value.trim()||username;
   if(!/^[a-z0-9_]{3,20}$/.test(username))throw new Error("شناسه باید ۳ تا ۲۰ حرف انگلیسی، عدد یا زیرخط باشد.");
   const {data,error}=await sb.auth.signUp({email,password,options:{data:{display_name,username}}});if(error)throw error;
   if(!data.user)throw new Error("حساب ساخته نشد؛ دوباره تلاش کن.");
   if(!data.session){showAuthMessage("حساب ساخته شد. ایمیلت را تأیید کن، سپس وارد شو.");return}
   const {error:pe}=await sb.from("profiles").upsert({id:data.user.id,username,display_name});if(pe)throw pe;
   await enterApp(data.user);
  }
 }catch(err){showAuthMessage(err.message||"خطایی رخ داد.")}finally{$("authSubmit").disabled=false}
});
async function enterApp(authUser){
 user=authUser;
 let {data:p,error}=await sb.from("profiles").select("*").eq("id",user.id).maybeSingle();
 if(error)throw error;
 if(!p){
  const meta=user.user_metadata||{}, uname=(meta.username||user.email.split("@")[0].replace(/[^a-zA-Z0-9_]/g,"").toLowerCase().slice(0,18)||"eliuser")+Math.random().toString(36).slice(2,5);
  const {data:np,error:ne}=await sb.from("profiles").insert({id:user.id,username:uname,display_name:meta.display_name||uname}).select().single();
  if(ne)throw ne;p=np;
 }
 profile=p;$("authView").classList.add("hidden");$("chatView").classList.remove("hidden");
 $("myName").textContent=p.display_name;$("myHandle").textContent="@"+p.username;$("myAvatar").textContent=initials(p.display_name);
 await loadConversations();subscribeInbox();
}
async function loadConversations(){
 const {data,error}=await sb.from("messages").select("id,sender_id,recipient_id,body,created_at").or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`).order("created_at",{ascending:false}).limit(500);
 if(error){toast("گرفتن پیام‌ها ناموفق بود: "+error.message);return}
 const latest=new Map();
 for(const m of data||[]){const peer=m.sender_id===user.id?m.recipient_id:m.sender_id;if(!latest.has(peer))latest.set(peer,m)}
 const ids=[...latest.keys()];
 profiles={};
 if(ids.length){const {data:ps}=await sb.from("profiles").select("id,username,display_name").in("id",ids);(ps||[]).forEach(p=>profiles[p.id]=p)}
 conversations=ids.map(id=>({peer:profiles[id]||{id,username:"کاربر",display_name:"کاربر"},last:latest.get(id)}));
 renderConversations();
}
function renderConversations(){
 const q=$("chatSearch").value.toLowerCase();const list=$("conversationList");list.innerHTML="";
 const filtered=conversations.filter(c=>(c.peer.display_name+" "+c.peer.username+" "+(c.last.body||"")).toLowerCase().includes(q));
 $("chatCount").textContent=faNum(filtered.length);
 if(!filtered.length){list.innerHTML='<div class="empty-list">گفت‌وگویی پیدا نشد.<br>از ＋ یک نفر را پیدا کن.</div>';return}
 filtered.forEach(c=>{
  const el=document.createElement("div");el.className="conversation-item"+(activePeer?.id===c.peer.id?" active":"");
  const date=new Date(c.last.created_at);const time=date.toLocaleTimeString("fa-IR",{hour:"2-digit",minute:"2-digit"});
  el.innerHTML=`<div class="avatar">${escapeHtml(initials(c.peer.display_name))}</div><div class="conv-meta"><div class="conv-top"><b>${escapeHtml(c.peer.display_name)}</b><time>${time}</time></div><div class="conv-last">${escapeHtml(c.last.body||"پیام")}</div></div>`;
  el.addEventListener("click",()=>openThread(c.peer));list.appendChild(el);
 });
}
$("chatSearch").addEventListener("input",renderConversations);
function subscribeInbox(){
 sb.channel("eli-inbox-"+user.id).on("postgres_changes",{event:"INSERT",schema:"public",table:"messages",filter:`recipient_id=eq.${user.id}`},payload=>{
  loadConversations();
  if(activePeer?.id===payload.new.sender_id) appendMessage(payload.new);
  else toast("پیام جدید داری.");
 }).subscribe();
}
async function openThread(peer){
 activePeer=peer;$("chatView").classList.add("thread-open");$("welcomePane").classList.add("hidden");$("threadPane").classList.remove("hidden");
 $("peerName").textContent=peer.display_name;$("peerHandle").textContent="@"+peer.username;$("peerAvatar").textContent=initials(peer.display_name);
 $("messageList").innerHTML='<div class="day-pill">گفت‌وگو</div>';
 if(messageChannel){await sb.removeChannel(messageChannel);messageChannel=null}
 const {data,error}=await sb.from("messages").select("*").or(`and(sender_id.eq.${user.id},recipient_id.eq.${peer.id}),and(sender_id.eq.${peer.id},recipient_id.eq.${user.id})`).order("created_at",{ascending:true}).limit(500);
 if(error){toast("بارگذاری پیام‌ها ناموفق بود: "+error.message);return}
 (data||[]).forEach(appendMessage);scrollMessages();
 messageChannel=sb.channel("eli-thread-"+[user.id,peer.id].sort().join("-")).on("postgres_changes",{event:"INSERT",schema:"public",table:"messages"},payload=>{
  const m=payload.new;if((m.sender_id===user.id&&m.recipient_id===peer.id)||(m.sender_id===peer.id&&m.recipient_id===user.id))appendMessage(m);
 }).subscribe();
 renderConversations();
}
function appendMessage(m){
 if(!activePeer)return;
 if($("messageList").querySelector(`[data-id="${m.id}"]`))return;
 const div=document.createElement("div");div.className="message "+(m.sender_id===user.id?"mine":"theirs");div.dataset.id=m.id;
 const time=new Date(m.created_at).toLocaleTimeString("fa-IR",{hour:"2-digit",minute:"2-digit"});
 div.innerHTML=`${escapeHtml(m.body)}<div class="message-meta"><time>${time}</time>${m.sender_id===user.id?"<span>✓</span>":""}</div>`;
 $("messageList").appendChild(div);scrollMessages();
}
function scrollMessages(){$("messageList").scrollTop=$("messageList").scrollHeight}
$("messageForm").addEventListener("submit",async e=>{
 e.preventDefault();if(!activePeer)return;const body=$("messageInput").value.trim();if(!body)return;
 $("messageInput").value="";$("messageInput").style.height="auto";
 const {data,error}=await sb.from("messages").insert({sender_id:user.id,recipient_id:activePeer.id,body}).select().single();
 if(error){toast("ارسال نشد: "+error.message);$("messageInput").value=body;return}
 appendMessage(data);loadConversations();
});
$("messageInput").addEventListener("input",e=>{e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,130)+"px"});
$("emojiBtn").addEventListener("click",()=>{$("messageInput").value+=" 😊";$("messageInput").focus()});
function openModal(){$("modalBackdrop").classList.remove("hidden");$("findResult").innerHTML="";$("findUsername").value="";setTimeout(()=>$("findUsername").focus(),50)}
function closeModal(){$("modalBackdrop").classList.add("hidden")}
$("newChatBtn").addEventListener("click",openModal);$("welcomeNewChat").addEventListener("click",openModal);$("modalClose").addEventListener("click",closeModal);
$("modalBackdrop").addEventListener("click",e=>{if(e.target===$("modalBackdrop"))closeModal()});
$("findUserForm").addEventListener("submit",async e=>{
 e.preventDefault();const name=$("findUsername").value.trim().replace(/^@/,"").toLowerCase();$("findResult").textContent="در حال جست‌وجو…";
 const {data,error}=await sb.from("profiles").select("id,username,display_name").eq("username",name).maybeSingle();
 if(error){$("findResult").textContent="خطا در جست‌وجو: "+error.message;return}
 if(!data||data.id===user.id){$("findResult").textContent=data?"این شناسه متعلق به خودت است.":"کاربری با این شناسه پیدا نشد.";return}
 $("findResult").innerHTML=`<div class="found-user"><div class="avatar">${escapeHtml(initials(data.display_name))}</div><div><b>${escapeHtml(data.display_name)}</b><small dir="ltr">@${escapeHtml(data.username)}</small></div><button id="startFoundChat" class="primary">پیام بده</button></div>`;
 $("startFoundChat").addEventListener("click",()=>{closeModal();const existing=conversations.find(c=>c.peer.id===data.id);if(!existing){conversations.unshift({peer:data,last:{body:"شروع گفت‌وگو",created_at:new Date().toISOString()}});renderConversations()}openThread(data)});
});
$("logoutBtn").addEventListener("click",async()=>{if(sb)await sb.auth.signOut();});
$("settingsBtn").addEventListener("click",()=>toast("شناسه‌ی تو: @"+(profile?.username||"")));
$("peerInfoBtn").addEventListener("click",()=>activePeer&&toast(activePeer.display_name+" · @"+activePeer.username));
$("mobileBack").addEventListener("click",()=>{$("chatView").classList.remove("thread-open");activePeer=null;if(messageChannel){sb.removeChannel(messageChannel);messageChannel=null}});
start().catch(e=>showAuthMessage(e.message||"خطا در راه‌اندازی برنامه"));
})();