var WPN_NAMES=new Array("Base","Plasma Felino","Tri-Laser","Supernova");
var BG_COLS=new Array("#e58e26","#d35400","#8e44ad","#2c3e50","#16a085");
var lvl=1,M=1500,p={x:750,y:750,hp:3500,mhp:3500,am:3,rt:0,sp:0,cb:0,a:0,b:0,fu:0,spd:4.1,col:"#f39c12",helm:"#27ae60",acc:"#fff",dmg:500,rel:55,type:0,wpn:1},over=0,run=0,paused=0;
var bul=[],wal=[],bus=[],box=[],cub=[],fish=[],bot=[],met=[],pup=[],st={x:750,y:750,r:750};

var peer=null,conn=null,isOnline=0,isHost=0,p2=null;
function setStat(t){document.getElementById("mpStat").innerText=t}
function hostRoom(){
  if(!unlocked.at(curCat)){setStat("Seleziona un gatto sbloccato!");return}
  if(typeof Peer==="undefined"){setStat("Errore rete PeerJS");return}
  var code=Math.random().toString(36).substring(2,6).toUpperCase();
  setStat("Creazione stanza "+code+"...");
  peer=new Peer("BRAWLGATTI-"+code);
  peer.on("open",function(){setStat("CODICE STANZA: "+code+" (In attesa amico...)")});
  peer.on("connection",function(c){conn=c;isOnline=1;isHost=1;setupConn();conn.on("open",function(){startGame(1);conn.send({t:"map",M:M,wal:wal,bus:bus,box:box,bot:bot,lvl:lvl})})});
  peer.on("error",function(e){setStat("Errore: "+e.type)});
}
function joinRoom(){
  if(!unlocked.at(curCat)){setStat("Seleziona un gatto sbloccato!");return}
  if(typeof Peer==="undefined"){setStat("Errore rete PeerJS");return}
  var code=document.getElementById("roomIn").value.trim().toUpperCase();
  if(code.length<4){setStat("Inserisci il codice di 4 caratteri!");return}
  setStat("Connessione a "+code+"...");
  peer=new Peer();
  peer.on("open",function(){conn=peer.connect("BRAWLGATTI-"+code);conn.on("open",function(){isOnline=1;isHost=0;setupConn();setStat("Connesso! Avvio...")})});
  peer.on("error",function(){setStat("Stanza non trovata!")});
}
function setupConn(){
  conn.on("data",function(d){
    if(d.t==="map"){M=d.M;wal=d.wal;bus=d.bus;box=d.box;bot=d.bot;lvl=d.lvl;startGame(2)}
    else if(d.t==="p"){p2=d.p;if(!isHost&&d.bot){bot=d.bot;box=d.box;cub=d.cub;fish=d.fish;met=d.met||[];pup=d.pup||[];st.r=d.sr}}
    else if(d.t==="bul"){d.b.forEach(function(x){bul.push(x)})}
  });
  conn.on("close",function(){if(run&&!over){alert("L'amico si è disconnesso!");location.reload()}});
}
function fp(r){
  var x,y,ok,t=0;
  do{ok=1;x=Math.random()*(M-240)+120;y=Math.random()*(M-240)+120;if(Math.hypot(x-M/2,y-M/2)<r+110)ok=0;wal.forEach(function(w){if(Math.hypot(x-w.x-35,y-w.y-35)<r+115)ok=0});box.forEach(function(b){if(Math.hypot(x-b.x-20,y-b.y-20)<r+55)ok=0});bus.forEach(function(b){if(Math.hypot(x-b.x,y-b.y)<r+55)ok=0});bot.forEach(function(b){if(Math.hypot(x-b.x,y-b.y)<r+65)ok=0});t++}while(!ok&&t<150);
  return{x:x,y:y};
}
function buildLevel(skipGen){
  if(!skipGen){
    M=1400+Math.min(1200,lvl*150);bul=[];wal=[];bus=[];box=[];cub=[];fish=[];bot=[];met=[];pup=[];st={x:M/2,y:M/2,r:M/2};
    var nWal=12+lvl*3,nBox=12+lvl*2,nBus=18+lvl*3,nBot=isOnline?(4+Math.floor(lvl/2)):(5+lvl);
    for(var i=0;i<nWal;i++){var q=fp(55);wal.push({x:q.x-35,y:q.y-35})}
    for(var i=0;i<nBox;i++){var q=fp(35);box.push({x:q.x-20,y:q.y-20,hp:1000+lvl*380})}
    for(var i=0;i<nBus;i++){var q=fp(50);bus.push({x:q.x,y:q.y})}
    for(var i=0;i<nBot;i++){var q=fp(40);var bhp=2400+lvl*1100+(lvl*lvl*120);var bt=i%5;var bSkin=CATS.at(bt).skins.at(0);bot.push({x:q.x,y:q.y,hp:bhp,mhp:bhp,cb:Math.floor(lvl*1.5),a:0,ls:0,mt:0,stf:Math.random()<.5?1:-1,boss:0,cType:bt,col:bSkin.col,helm:"#2c3e50"})}
    if(lvl>=2){var nBoss=lvl>=5?2:1;for(var b=0;b<nBoss;b++){var qb=fp(65);var mhp=11000+lvl*5500+(lvl*lvl*300);bot.push({x:qb.x,y:qb.y,hp:mhp,mhp:mhp,cb:lvl*2,a:0,ls:0,mt:0,stf:1,boss:1,cType:2,col:"#8e44ad",helm:"#fbc531"})}}
  }else{bul=[];cub=[];fish=[];met=[];pup=[];st={x:M/2,y:M/2,r:M/2}}
  p.x=isOnline?(isHost?M/2-80:M/2+80):M/2;p.y=M/2;p.hp=p.mhp;p.am=3;p.rt=0;bgmStep=0;
  document.getElementById("lv").innerText=lvl;document.getElementById("wp").innerText=WPN_NAMES.at(Math.min(3,p.wpn-1))+" Lv."+p.wpn;
  document.getElementById("bossHud").style.display=bot.some(function(b){return b.boss})?"flex":"none";
}
function startGame(mode){
  initAudio();
  var s=CATS.at(curCat),sk=s.skins.at(eqSkins.at(curCat));
  p.hp=p.mhp=s.hp;p.spd=s.spd;
  p.col=sk.col;p.helm=sk.helm;p.acc=sk.acc;
  p.dmg=s.dmg;p.rel=s.rel;p.type=s.type;
  p.wpn=eqWpn;p.cb=0;
  if(mode!=2)lvl=1;
  buildLevel(mode==2);
  document.getElementById("scrStart").style.display="none";
  run=1;sfx(300,600,.2,"sine",.15);
}
function nextLvl(){lvl++;p.wpn++;p.mhp+=400;p.hp=p.mhp;buildLevel(0);if(isOnline&&isHost&&conn)conn.send({t:"map",M:M,wal:wal,bus:bus,box:box,bot:bot,lvl:lvl});document.getElementById("scrNext").style.display="none";run=1;sfx(400,800,.25,"sine",.18)}
function togPausa(){if(!run||over)return;paused=!paused;document.getElementById("scrPause").style.display=paused?"flex":"none"}

