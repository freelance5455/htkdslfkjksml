import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { resolve, relative } from 'node:path';

const root = process.cwd();
const app = resolve(root, 'android/app');
const checks = [];
function check(label, ok, detail = '') { checks.push({ label, ok, detail }); }
function read(path) { return existsSync(path) ? readFileSync(path, 'utf8') : ''; }

const manifestPath = resolve(app, 'src/main/AndroidManifest.xml');
const manifest = read(manifestPath);
check('Android project and manifest exist', !!manifest);
check('Single-prayer widget receiver registered', manifest.includes('com.sanastudio.waitingforprayer.AWPSinglePrayerWidgetProvider') && manifest.includes('@xml/awp_widget_info_single'));
check('All-prayers widget receiver registered', manifest.includes('com.sanastudio.waitingforprayer.AWPAllPrayersWidgetProvider') && manifest.includes('@xml/awp_widget_info_all'));
check('Widget receivers are exported', (manifest.match(/android:exported="true"/g) || []).length >= 2);
check('Prayer deep link registered', manifest.includes('android:scheme="awaitingprayer"') && manifest.includes('android:host="prayer"'));
check('Notification permission merged', manifest.includes('android.permission.POST_NOTIFICATIONS'));
check('Exact alarm permission merged', manifest.includes('android.permission.SCHEDULE_EXACT_ALARM'));
check('20-minute transition receiver registered', manifest.includes('AWPWidgetRefreshReceiver') && manifest.includes('WIDGET_REFRESH'));
check('Widget boundary alarms restored after reboot', manifest.includes('android.permission.RECEIVE_BOOT_COMPLETED') && manifest.includes('android.intent.action.BOOT_COMPLETED'));

const mainFiles = [];
// MainActivity is generated under the application's Java source package.
function findFiles(dir, name, out = []) {
  if (!existsSync(dir)) return out;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = resolve(dir, entry.name);
    if (entry.isDirectory()) findFiles(path, name, out);
    else if (entry.name === name) out.push(path);
  }
  return out;
}
mainFiles.push(...findFiles(resolve(app, 'src/main/java'), 'MainActivity.java'));
check('Exactly one MainActivity.java found', mainFiles.length === 1, `${mainFiles.length} found`);
const main = mainFiles.length === 1 ? read(mainFiles[0]) : '';
check('Capacitor plugin explicitly registered', main.includes('registerPlugin(AWPWidgetPlugin.class)'));
const dataSource = read(resolve(app, 'src/main/java/com/sanastudio/waitingforprayer/AWPWidgetData.java'));
check('20-minute active window recalculated natively', dataSource.includes('PRAYER_WINDOW_MS') && dataSource.includes('scheduleNextBoundary'));
check('Widget transition alarm refreshes at the boundary', dataSource.includes('setAndAllowWhileIdle') && dataSource.includes('WIDGET_REFRESH'));

const required = [
  'src/main/java/com/sanastudio/waitingforprayer/AWPWidgetPlugin.java',
  'src/main/java/com/sanastudio/waitingforprayer/AWPWidgetData.java',
  'src/main/java/com/sanastudio/waitingforprayer/AWPWidgetRefreshReceiver.java',
  'src/main/java/com/sanastudio/waitingforprayer/AWPSinglePrayerWidgetProvider.java',
  'src/main/java/com/sanastudio/waitingforprayer/AWPAllPrayersWidgetProvider.java',
  'src/main/res/layout/awp_widget_single.xml',
  'src/main/res/layout/awp_widget_all.xml',
  'src/main/res/xml/awp_widget_info_single.xml',
  'src/main/res/xml/awp_widget_info_all.xml',
  ...['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].map(k => `src/main/res/drawable-nodpi/awp_prayer_${k}.jpg`),
];
for (const item of required) check(`Resource: ${item}`, existsSync(resolve(app, item)));

for (const result of checks) console.log(`${result.ok ? 'PASS' : 'FAIL'}  ${result.label}${result.detail ? ` (${result.detail})` : ''}`);
const failed = checks.filter(x => !x.ok);
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed.`);
if (failed.length) process.exit(1);
console.log('Both widgets are wired into the generated Android project. APK compilation and launcher visibility still require an Android SDK build and a device/launcher test.');
