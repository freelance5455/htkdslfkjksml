# I’m Waiting for Prayer — v36

## v36 — 20-minute prayer focus window

- When a prayer time begins, the app keeps that same prayer selected for 20 minutes from its scheduled timestamp. The prayer scene remains the active MP4 scene in the app during that window.
- The app’s prayer selector, countdown, status rows and widget payload now share the same active/upcoming state. After the 20-minute focus window, the next prayer is selected automatically.
- The Android widget providers recalculate the active window from absolute timestamps and schedule a refresh at the next prayer/window boundary. A boot receiver restores the boundary alarm after restart. If Android does not grant exact-alarm access, the system may defer the inexact idle-allowed refresh.
- The iOS WidgetKit timeline now creates a transition entry at the prayer start or at the end of the 20-minute window. WidgetKit still controls the actual refresh schedule.
- System widgets show a still image from the relevant prayer scene plus a live system countdown. Android AppWidget and iOS WidgetKit do not host continuous MP4 playback; the full MP4 remains in the app.
- The 20-minute countdown is an app convenience/focus timer only. It does **not** define the end of the prayer’s valid time under Islamic jurisprudence.
- Run `npm run test:prayer-window` for deterministic checks of before-prayer, active-window, expiry and previous-Isha-after-midnight behavior.

### Android setup

Run `npm install`, then `npm run android:prepare`, then `npm run open:android`. Build and install the APK from Android Studio. Open the app once, choose a location and allow any relevant alarm/notification access. Add **I’m Waiting for Prayer** from the launcher’s Widgets picker.

### iOS setup

The supplied `native/ios/Widget/PrayerWidget.swift` is the Widget Extension source. Add it and its asset catalog to the `AWPPrayerWidget` extension target, add `native/ios/App/AWPWidgetPlugin.swift` to the app target, and configure the shared App Group as detailed in the existing setup notes below.

No APK/IPA build or physical-device/launcher test is claimed in this source release.

---

# I’m Waiting for Prayer — v34

This build restores the exact Sana Studio splash/logo CSS and markup from the earlier v27 build. The newer splash redesign and duplicate independent exit controller have been removed. The rest of the v30 Capacitor project is retained.

The original splash boot preparation is restored with its image-load fallback; the app still prepares its video index and topic content as in the known-good earlier build.

# v29 — Startup repair

- Restored a lightweight startup sequence independent from lazy topic rendering and external services.
- Keeps the Sana Studio pixel logo visible first, then reveals a transparent Pixel progress strip.
- Builds the lightweight video lookup only; topic pages remain lazy-loaded.
- Startup splash has a bounded fallback and cannot wait indefinitely for optional work.
- Native Android/iOS assets are retained from the complete v29 project.

Build with `npm install` then `npm run sync` (Android/iOS native projects must be added/opened with the Capacitor CLI as appropriate).

No APK/IPA build or on-device test is claimed.

--- Previous project notes ---

# أنتظر صلاة — I’m Waiting for Prayer (v27)

Capacitor 6 project — package version 2.4.0. This release adds Sunrise playback, scene-matched native widget previews and prayer-specific deep links, expanded sourced learning guides, and the animated Sana Studio startup.

This project wraps the responsive HTML app using Vite + Capacitor 6 and imports `@capacitor/local-notifications` explicitly in `src/main.js`.

## v24 — Original MP4 display restored
- Restores the original v21 prayer-scene renderer and usage pattern: each prayer scene uses its original MP4/image layer rather than still-only rows or a featured-only video.
- Restores the original v21 intrinsic video-ratio CSS and metadata-fitting script.
- Removes the later featured-video blur/fallback presentation and its playback guard.
- Keeps the current app settings, prayer library, widgets, typography, and color palette unchanged.
- This is a source-project update; no APK/IPA build or physical-device playback test is claimed.

## Notification repairs
- Explicit Android notification channels use unique v3 IDs and a bundled soft chime (`awp_notification.wav`). New channel IDs are necessary because Android preserves user settings for previously created channels.
- Scheduled notifications include the same WAV for iOS and Android 7.x; Android 8+ uses the sound attached to each channel.
- Android notifications use a small monochrome app icon and a green accent color.
- Prayer-time alerts and Mizan follow-ups are grouped separately; the OS still controls the final banner/card layout.
- Reminder copy is localized (Arabic, English, Turkish and French), short, calm and deterministic for each reminder occurrence.
- Mizan pause/exception and quiet-hour settings do not suppress actual prayer-time alerts.
- Isha follow-ups end at next Fajr when the next day's prayer data is available.
- Permissions are requested only after the user chooses to enable/test notifications.
- Scheduling cancels only this app's stored/legacy notification IDs, not every pending notification from the app.
- Schedule is refreshed on resume and app state changes; past/invalid times are filtered and duplicate IDs are avoided.
- Exact-alarm access is checked separately on Android; if unavailable, Android may delay exact delivery depending on OS settings.


## v35 — Android widget installation hardening

This update fixes the packaging/setup gap that can make the widgets invisible in the Android launcher. The Java/XML widget sources were already bundled under `native/android/`, but a plain HTML-to-APK wrapper does not compile or register those native Android components.

The delivered source ZIP intentionally keeps the generated `android/` Gradle platform out of the archive; Capacitor generates it for the target machine/SDK. Use the one-command setup below before opening Android Studio. The presence of files under `native/android/` alone does not mean they are installed in an APK.

### Recommended Android setup (one command)

On a computer with Node.js 18+, Android Studio and the Android SDK installed:

```bash
npm install
npm run android:prepare
npm run open:android
```

`android:prepare` builds the web app, creates the Capacitor Android project if it does not exist, synchronizes Capacitor, copies the native widget providers/layouts/poster images, merges the notification permissions, registers both widget receivers in `AndroidManifest.xml`, registers `AWPWidgetPlugin` in `MainActivity`, adds the `awaitingprayer://prayer` deep link, and runs a verification checklist. It stops with an error if a required registration is missing.

Then, in Android Studio, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Install the generated APK. Open the app once, choose your region and wait for prayer times to load. Then long-press an empty area of the home screen → **Widgets** → **أنتظر صلاة** and add either **Next prayer** or **All five prayers**. Some launchers do not support the in-app pin shortcut; the system widget picker remains the fallback.

**Important:** importing only `index.html` into an HTML-to-APK converter will not install these widgets. The converter must explicitly support Capacitor native Android plugins and `AppWidgetProvider` receivers; otherwise use this project's Capacitor/Android Studio workflow. A widget preview drawn inside the app is not the same thing as a system home-screen widget.

The widget tile shows the matching still frame from each prayer's MP4, the prayer name/time, and the next-prayer countdown. Standard Android `RemoteViews` widgets do not play a continuous MP4 stream. Tapping a prayer row opens the corresponding scene inside the app.

Run `npm run android:verify` at any time after setup to check the Android manifest, plugin registration and required resources.

## Build prerequisites
- Node.js 18+ and npm
- Android: Android Studio + Android SDK
- iOS: macOS + Xcode (an iOS build cannot be produced on Windows/Linux)

## Setup
```bash
npm install
npm run build
npx cap add android
npx cap add ios
```

## Add the bundled native resources after creating platforms

### Android
The prepared resources are staged in the starter project. The recommended path is `npm run android:prepare`, which creates/synchronizes the Android platform and installs all widget resources and registrations. For an already generated Android project, `npm run native:resources` can reinstall the resources and registrations. The destinations are:
```text
native/android/app/src/main/res/raw/awp_notification.wav
  -> android/app/src/main/res/raw/awp_notification.wav
native/android/app/src/main/res/drawable/ic_stat_prayer.xml
  -> android/app/src/main/res/drawable/ic_stat_prayer.xml
```
Merge the permissions from `native/AndroidManifest.permissions.xml` into `android/app/src/main/AndroidManifest.xml`, then run:
```bash
npx cap sync android
npx cap open android
```
Build the APK from Android Studio. If you had installed an earlier build, the v3 channels appear as new channels. Users can still mute or modify each channel in Android settings.

### iOS
Add `native/ios/App/awp_notification.wav` to the Xcode App target (ensure **Copy Bundle Resources** is checked), then run:
```bash
npx cap sync ios
npx cap open ios
```
Set a signing team in Xcode and test permission prompts and scheduled delivery on a physical iPhone/iPad.

## Important platform behavior
- Android 8+ sound is channel-controlled; the custom WAV must be present under `android/app/src/main/res/raw` at build time. Android channel settings are user-controlled and existing channel sound behavior is not overwritten, which is why v3 channel IDs are used.
- iOS requires the WAV to be inside the signed app bundle. Focus modes, mute settings and user notification preferences may silence or defer alerts.
- Capacitor Local Notifications on Android requires POST_NOTIFICATIONS on Android 13+ and exact-alarm permission/settings may be required for precise delivery on Android 12+.
- `allowWhileIdle` is used sparingly: Android documents a per-app limit of one such alarm per nine minutes. Do not mark every reminder as allow-while-idle.
- App-generated web HTML can be checked here, but native timing, sound, reboot recovery, Doze, Focus, permission revocation, daylight-saving and channel preferences require real-device testing before release.
- v20 includes a native Android home-screen widget (AppWidgetProvider), a Capacitor bridge plugin, and an iOS WidgetKit/Capacitor source scaffold.
- Android widget setup is automated by `npm run native:resources` after `npx cap add android`.
- iOS widgets require an Xcode Widget Extension target and an App Group entitlement; source files and precise setup steps are included under `native/ios/Widget/` and below. iOS does not permit apps to pin a widget programmatically.


## Home-screen widget — Android (v20)

After `npx cap add android`, run:

```bash
npm run native:resources
npx cap sync android
npx cap open android
```

The resource script copies the widget provider, plugin, layouts and metadata, adds the widget receiver to `AndroidManifest.xml`, and registers `AWPWidgetPlugin` in the generated `MainActivity`. Inspect the diff if you have customized those files. Build and install the app. Then add the widget from the Android home-screen Widgets picker, or use the in-app Add button on Android 8+ when the launcher supports pin requests. The widget reads the next prayer from app data, shows its time and uses Android's system Chronometer for a live countdown on Android 7.0+ (older versions show the last remaining-time snapshot). It schedules a refresh at the next known prayer; Android may defer background work under power-saving policies.

## Home-screen widget — iOS (WidgetKit source scaffold)

1. In Xcode, create a Widget Extension target named `AWPPrayerWidget` (minimum iOS 14).
2. Add `native/ios/Widget/PrayerWidget.swift` to that extension target.
3. Add `native/ios/App/AWPWidgetPlugin.swift` to the main App target and register it in `BridgeViewController.swift` using `bridge?.registerPluginInstance(AWPWidgetPlugin())` inside `capacitorDidLoad()`.
4. Enable the same App Group, `group.com.sanastudio.waitingforprayer`, for both the App and Widget Extension targets. Add the supplied entitlement file to both targets (merge with existing entitlements rather than replacing them).
5. Build both targets in Xcode. The widget appears in the iOS widget gallery; users add it manually. iOS controls widget refresh timing, so countdown updates are not guaranteed to run every second.

The iOS widget uses SwiftUI's date timer for a system-rendered countdown; WidgetKit still controls timeline refresh and may delay changes to the next prayer while the app is inactive. The iOS extension target and signing cannot be generated or tested in this Linux Capacitor bundle. Test on a signed physical iPhone/iPad before release.


## Home-screen widgets — v21: two types and prayer-scene previews

The app now supplies two independent native widgets on both platforms:

- **Single prayer:** the next upcoming prayer, its time, countdown and a preview frame taken from that prayer's own bundled MP4 (or the existing Isha still image).
- **All prayers:** Fajr, Dhuhr, Asr, Maghrib and Isha together, with matching miniature scene previews and the next prayer highlighted.

The five scene-preview images are generated from the matching embedded media without changing their aspect ratios. Fajr's source is portrait (450×510); in the horizontal single-prayer widget it is rendered with `fitCenter` / `scaledToFit`, so the complete vertical frame remains visible with dark/blurred side fill. It is not cropped or stretched.

**Important media limitation:** standard Android home-screen widgets use `RemoteViews`, which only supports a restricted set of system views, and Apple WidgetKit renders snapshots in a separate process instead of running a continuously active app view. Therefore these widgets show a full-frame still extracted from the same prayer video; they do not play MP4 inside the home-screen tile. Tapping a widget opens the app; open the Prayer Times screen there to play the original MP4. Android widget refreshes are event/system controlled; WidgetKit schedules timeline refreshes within Apple's budget. See the platform documentation: [Android App Widgets](https://developer.android.com/develop/ui/views/appwidgets) and [Keeping a widget up to date](https://developer.apple.com/documentation/widgetkit/keeping-a-widget-up-to-date).

### Android v21 setup

Run `npm run android:prepare` (recommended). It performs the platform generation/synchronization, resource installation and widget registration in the correct order. The installer registers `AWPSinglePrayerWidgetProvider` and `AWPAllPrayersWidgetProvider`, copies five source-matched preview frames, and registers the Capacitor bridge. Build/install the app, then add either widget from the launcher. The single widget requests the next upcoming prayer; the all-prayers widget shows all five times. The old v20 `AWPWidgetProvider` source remains only as a compatibility alias; the v21 installer registers the two new providers.

### iOS v21 setup

Create/keep a Widget Extension target named `AWPPrayerWidget` with minimum iOS 14. Add `native/ios/Widget/PrayerWidget.swift` to the extension target and add the entire `native/ios/Widget/Assets.xcassets` folder (including five `Prayer_*.imageset` entries) to that target. Keep the existing App Group `group.com.sanastudio.waitingforprayer` enabled for both app and extension, and include `native/ios/App/AWPWidgetPlugin.swift` in the app target. Merge `native/ios/App/AWPWidgetURLTypes.plist.fragment` into the App target Info.plist so the widget URL opens the app. Add both widgets from the iOS widget gallery. WidgetKit decides the actual refresh schedule; the displayed timer is system-rendered but is not an MP4 player.

### In-app video display

In the prayer-times screen, each `.pr` or `.nx` media panel now derives its aspect ratio from the decoded video/image dimensions and uses `object-fit: contain`. The portrait Fajr and Sunrise clips retain their full source frame; landscape Dhuhr/Asr and square Maghrib retain their own ratios. No common square/landscape crop is imposed.


## v23 interface and media changes

- The next-prayer card is the only large video card. The five timetable rows are compact and use still previews to avoid decoding five MP4 files at once.
- The upcoming scene uses a full-frame `contain` foreground with a softened background fill, so portrait Fajr and square Maghrib scenes remain uncropped and undistorted.
- Maghrib is re-encoded as H.264 Baseline / yuv420p with fast-start metadata for broader WebView compatibility.
- Video playback starts only in the featured card, with `canplay` retry and an image fallback if playback fails or autoplay is restricted.
- The video library includes individual clips, full YouTube playlists and official course archives. Playlist cards open as YouTube series in the in-app player; official archives open their source page.
- Settings are grouped into collapsible sections (display/language, sound, prayer calculation, permissions/backup, widgets and about). Fine-grained prayer adjustments are nested in a separate disclosure.
- The all-five Android widget has a larger minimum height so all rows fit. The iOS all-five widget is offered in the large family to keep every row legible.

The app interface itself is Arabic/English; the native widget text retains Arabic, English, Turkish and French labels. YouTube playback requires an internet connection and may be restricted by a video owner.


## v23 curated learning sources

The in-app library distinguishes single YouTube videos, YouTube playlists, and external indexed archives. Newly linked collections include:

- Othman Al-Khamees official Seerah archive: https://othmanalkamees.com/lesson/318 (93 titled clips).
- Ragheb Al-Sergani, Rashidun Caliphate archive: https://baheth.ieasybooks.com/ar/playlists/%D9%82%D8%B5%D8%A9-%D8%A7%D9%84%D8%AE%D9%84%D8%A7%D9%81%D8%A9-%D8%A7%D9%84%D8%B1%D8%A7%D8%B4%D8%AF%D8%A9 (97 entries).
- Salih al-Fawzan official fiqh archive: https://dralfawzann.com/section/90/ (indexed lessons in purification, prayer, fasting, Hajj and legal hadith).
- Muhammad bin Shams al-Din official study portal: https://www.mshmsdin.com/ (lessons and book commentary).
- Dr Haitham Talaat official portal: https://www.drhaithamtalaat.com/ (articles and video channels).
- Ibn Uthaymeen lesson playlists and Abd al-Razzaq al-Badr Riyad al-Salihin playlist are linked from the cards and open as YouTube series.

Playlist sizes can change as channels edit them. The app labels the counts as source-reported when known and does not imply that every playlist is a single video.


## v23 curated learning sources

The in-app library distinguishes single YouTube videos, YouTube playlists, and external indexed archives. Newly linked collections include:

- Othman Al-Khamees official Seerah archive: https://othmanalkamees.com/lesson/318 (93 titled clips).
- Ragheb Al-Sergani, Rashidun Caliphate archive: https://baheth.ieasybooks.com/ar/playlists/%D9%82%D8%B5%D8%A9_%D8%A7%D9%84%D8%AE%D9%84%D8%A7%D9%81%D8%A9_%D8%A7%D9%84%D8%B1%D8%A7%D8%B4%D8%AF%D8%A9 (97 entries).
- Salih al-Fawzan official fiqh archive: https://dralfawzann.com/section/90/ (indexed lessons in purification, prayer, fasting, Hajj and legal hadith).
- Muhammad bin Shams al-Din official study portal: https://www.mshmsdin.com/ (lessons and book commentary).
- Dr Haitham Talaat official portal: https://www.drhaithamtalaat.com/ (articles and video channels).
- Ibn Uthaymeen lesson playlists and Abd al-Razzaq al-Badr Riyad al-Salihin playlist are linked from the cards and open as YouTube series.

Playlist sizes can change as channels edit them. The app labels the counts as source-reported when known and does not imply that every playlist is a single video.


## v23 library size and source notes

The in-app catalogue contains 106 navigable entries: 93 individual video cards, 7 YouTube playlist cards and 6 official/educational archive cards. The 93 individual cards include 60 individually indexed clips from the official 93-part Seerah archive, plus videos from other teachers and channels. The full Seerah archive remains linked as a separate source card.

The six Ibn Uthaymeen playlist counts displayed in their cards are source-reported counts (554, 346, 47, 42, 240 and 471); playlist contents may change. A seventh playlist links Abd al-Razzaq al-Badr’s Riyad al-Salihin lessons. These playlist cards are lesson collections, not individual videos.

Official/indexed sources used:
- Othman Al-Khamees, 93-part Seerah archive: https://othmanalkhamees.com/lesson/318
- Ragheb Al-Sergani, 97-entry Rashidun history archive: https://baheth.ieasybooks.com/ar/playlists/%D9%82%D8%B5%D8%A9_%D8%A7%D9%84%D8%AE%D9%84%D8%A7%D9%81%D8%A9_%D8%A7%D9%84%D8%B1%D8%A7%D8%B4%D8%AF%D8%A9
- Salih al-Fawzan, indexed Fiqh archive: https://dralfawzann.com/section/90/
- Muhammad bin Shams al-Din, official study portal: https://www.mshmsdin.com/
- Dr Haitham Talaat, official portal: https://www.drhaithamtalaat.com/
- Ibn Uthaymeen playlist source: https://t.me/s/binothaimeen

## v23 final interface notes

- Only the upcoming prayer panel is large. The timetable rows are compact and use still frames rather than simultaneously decoding every prayer MP4.
- The upcoming panel uses a full-frame video foreground with a subdued blurred fill behind it.
- Maghrib is re-encoded as H.264 Constrained Baseline, yuv420p, level 3.0, fast-start MP4. Playback is limited to the featured card and has a still-image fallback if WebView rejects playback.
- Settings remain in six collapsible groups. Timer and tone controls remain with sound settings; permissions and widget controls stay inside their own groups.
- The all-five Android widget uses tighter row sizing and an increased minimum height. The all-five iOS widget is restricted to the large family so its rows remain legible.
- Home-screen widgets show the matching full-frame still preview; tapping opens the app for the MP4 because standard Android App Widgets and WidgetKit do not host continuous MP4 playback.


## v23 visual update
- Restored the familiar upcoming-prayer MP4 card with one real video layer, native aspect-ratio sizing, and no blurred duplicate poster layers. The video is contained without stretching or cropping; its stage is capped responsively on short screens.
- Compact timetable rows remain at their normal height and use poster stills to avoid decoding several MP4 streams at once.
- Countdown and timetable numerals now use the clearer Handjet numeric face; the remaining interface retains its Pixelify Sans / Handjet pixel-art typography.
- Added persistent app color presets (Sunset, Ocean, Forest, Rose, Amber) and a custom accent-color picker in Settings > Display & language.


## v25 — Split prayer display

- The “Next Prayer” feature card retains the original full-motion MP4/image scene renderer.
- The remaining prayer-time rows use the simple early list presentation: text, status, progress indicator, and time only. They no longer create individual video/image background layers.
- No other app features, prayer calculations, widget configuration, or settings were intentionally changed in this pass.


## v26 — Prayer drawers, relationship guides, and Mizan

- Preserved the separate large upcoming-prayer card and its intrinsic MP4 ratio handling.
- Added each prayer's own local media layer inside its compact prayer row; row size is fixed to the drawer dimensions. The Isha animated GIF source was converted to H.264 MP4 for consistent media handling.
- Added 30 individually identified video entries with source notes. Some re-uploads are explicitly labeled as non-official; playlist and archive entries are not counted as individual videos. The library now contains 123 individual video entries, plus 7 playlists and 6 external resource pages (134 records total). The requested 100 *additional* individual videos are not all present in this build; this revision adds 30 verified, distinct video IDs.
- Expanded Men from Mars / Women from Venus with reciprocal communication, conflict-resolution, boundaries, shared responsibility, and individual-differences guidance.
- Redesigned Mizan progress summaries, weekly views, prayer status rows, commitment progress and quick-add controls. Existing storage keys and event action names were retained.

Validation in this delivery: JavaScript syntax, archive integrity, and media-source type checks. Actual Android/iOS runtime testing and APK/IPA building have not been performed.


## v27 update — sunrise playback, prayer-specific widget links, learning guides and Sana Studio splash

- Fixed the sunrise row: it now uses its own MP4 scene and the same media treatment as the other timing rows. The sunrise MP4 is re-encoded as H.264 Constrained Baseline, `yuv420p`, Level 3.0, with fast-start metadata for broader Android playback compatibility.
- Added and enlarged still previews extracted from the matching five prayer MP4 files in Android and iOS widget assets. Native home-screen widgets do not continuously play MP4 video; each preview is a still from the correct scene. Tapping a row opens that exact prayer scene in the app using `awaitingprayer://prayer?key=...`.
- Added the Capacitor App plugin bridge and an Android MainActivity intent-filter patch to enable widget deep links. For iOS, merge `native/ios/App/AWPWidgetURLTypes.plist.fragment` into the app target Info.plist and keep the App Group entitlement configured for both app and widget extension.
- Added sourced guides for tayammum, wiping over socks, zakat, voluntary/ongoing charity, and circumcision. The guides distinguish juristic differences and flag that female genital mutilation is not treated as a religious ritual and is prohibited by the Egyptian Dar al-Ifta fatwa cited in the app.
- Expanded the Mars/Venus section with communication drills, weekly check-ins, fair division of household responsibilities, repair after conflict, and a clear note that the book’s gender metaphor is not a universal scientific rule.
- Added a simplified inheritance flow and an explicitly limited worked example. Real estate distribution must be computed only after identifying every heir and settling applicable estate obligations.
- Rebuilt the Sana Studio loading screen with an original pixel-art sunrise mark, staged wordmark reveal, animated progress bar, and pre-indexing of video categories and topic pages. The visual approach uses broad retro pixel-game language; it does not copy Sui Arts’ logo.

### Widget playback limitation
Android RemoteViews widgets and iOS WidgetKit timelines display the scene image preview, not a continuously playing MP4. Per-prayer row taps open the matching animated scene inside the app.

### Build notes
Run `npm install` to install the added `@capacitor/app` dependency, then `npm run sync` and `npm run native:resources`. Ensure Android `MainActivity` is generated before running the installer so its prayer deep-link filter can be added. On iOS, add `PrayerWidget.swift` and its asset catalog to the Widget Extension target, merge the URL types fragment, and enable the matching App Group on both targets.


## Release readiness and limitations

- The six embedded MP4 assets (Fajr, Dhuhr, Asr, Maghrib, Isha and Sunrise) were inspected with `ffprobe` and decoded with `ffmpeg`; Sunrise is H.264 Constrained Baseline, `yuv420p`, level 3.0, and fast-start metadata.
- The app uses a compact MP4 scene layer within each timetable row, including Sunrise. If a device blocks autoplay, the row exposes native video controls.
- Android and iOS widget image previews are exact still frames from the corresponding prayer scenes. Tapping a row opens its matching in-app MP4 through `awaitingprayer://prayer?key=...`; continuous MP4 playback inside the native home-screen widget itself is not supported by standard RemoteViews/WidgetKit.
- The bundled Android Java/XML resources and five poster assets must be copied after `npx cap add android` by running `npm run native:resources`. For iOS, add `native/ios/Widget/PrayerWidget.swift` and the complete asset catalog to the Widget Extension target, merge the URL-types plist fragment into the app Info.plist, and enable the shared App Group for both targets.
- The in-app fiqh guides are educational summaries with links to referenced fatwas and hadith. They flag recognized differences (such as thin socks, some zakat details and male circumcision rulings) and do not replace an individual fatwa. The circumcision page explicitly distinguishes male circumcision from female genital mutilation and does not provide procedural guidance.
- No APK or IPA has been built, and runtime testing on a physical Android/iOS device has not been performed.


## v30 — إصلاح انتقال شاشة Sana Studio

- أضيف متحكم مستقل لشاشة الشعار يعمل بعد سكربتات التطبيق ولا يعتمد على `AWH.D` أو فهارس المحتوى.
- يعرض الشعار أولاً، ثم شريط Pixel، ثم يغلق الشاشة تلقائياً خلال مدة قصيرة.
- يوجد حد زمني احتياطي مستقل يمنع بقاء شاشة الشعار معلقة إذا تعطل قسم اختياري مثل مكتبة الموضوعات.
- لم تُغيّر ملفات الفيديو أو بيانات المحتوى أو منطق الويدجت في هذا الإصدار.
- لم يُبنَ APK/IPA ولم يُختبر على هاتف فعلي؛ اختبار العرض على WebView فعلي ما زال مطلوباً.


## v34 update
- Added a persistent on-device tasbih counter with increase, decrease and reset controls.
- Embedded the supplied animated GIF as the tasbih panel artwork.
- Restyled the Qibla compass as a matte, handcrafted instrument; sensor and bearing logic remain in place.
- Retained the modestly enlarged prayer rows and sunrise sizing from v33.
- Corrected legacy helper-scope errors affecting lesson pages, topic cards and language refresh.

### v35 validation notes

- All 15 inline JavaScript blocks in `index.html` passed `node --check`.
- The installer, Android setup script, and widget verifier passed Node syntax checks.
- All 16 bundled Android XML resources parsed successfully.
- The installer and verifier were exercised against a generated-manifest/MainActivity test fixture; all 22 registration/resource checks passed. This is an integration-script test, not a compiled APK test.
- This environment has no configured Android SDK/Gradle installation, so no APK was compiled and no physical launcher test was performed.
