plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.creamburg.inventory"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.creamburg.inventory"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
