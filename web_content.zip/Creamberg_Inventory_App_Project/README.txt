CREAMBERG INVENTORY MANAGER — SOURCE PROJECT
=============================================

CONTENTS
--------
1. web-app/
   - index.html: full inventory app source
   - manifest.json: installable web app metadata
   - service-worker.js: basic offline cache for hosted web app

2. android-app/
   - Android Studio project source for an Android WebView app
   - app/src/main/assets/index.html: bundled inventory app
   - Kotlin MainActivity and Gradle build files

FEATURES IN THIS SOURCE
-----------------------
- Inventory item master list and categories
- Stock-in entry with date, quantity, unit, supplier and notes
- Monthly report with opening, stock-in, available, closing and used stock
- Closing stock carry-forward into next month's opening
- Units: KG, G, L, ML, PC, PKT, BOX
- CSV export compatible with Excel / Google Sheets
- Print dialog for saving a report as PDF
- JSON backup and restore
- Basic multiple user accounts stored locally in this browser/device

IMPORTANT LIMITATIONS
---------------------
- This is a starter/source project, not a signed APK.
- User accounts and inventory records are stored locally on the device/browser.
  Multiple users can have separate logins on the same browser, but records do NOT
  synchronize across different phones. Real multi-device use needs a secure backend,
  cloud database, and server-side authentication.
- Local demo login: username admin / password Creamberg@123.
  Change this default credential before real use; this prototype currently does
  not include a password-change screen and is not production-secure.
- Back up data regularly using the app's JSON backup feature.
- Quantity is tracked in each item's assigned unit. Do not combine totals across
  different units (for example KG and PC) as a single physical total.

BUILD AND RUN ANDROID PROJECT
-----------------------------
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Open the android-app folder in Android Studio.
4. Allow Gradle sync and install any requested Android SDK components.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press Run to install the app.
7. To make an APK: Android Studio > Build > Build APK(s).
   The debug APK is usually under app/build/outputs/apk/debug/app-debug.apk.

WEB APP
-------
Open web-app/index.html in a browser for basic testing. For full PWA install/offline
support, host the web-app folder on HTTPS; browsers usually do not enable service
workers for a local file:// URL.

EXCEL AND PDF
-------------
- CSV exports open in Microsoft Excel or Google Sheets.
- PDF: open Monthly Report > Print / Save PDF, then select Save as PDF in the
  Android print dialog where available.

This ZIP contains source files; it does not include a cloud backend or a ready-made APK.
