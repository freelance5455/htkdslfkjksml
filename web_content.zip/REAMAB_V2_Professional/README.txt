REAMAB V2 Professional

This package preserves the existing REAMAB V2 budget, salary, expenses, fixed expenses, goals, analytics, themes, languages, notes, plans, reports, PDF and JSON backup features.

Professional additions in this revision:
- Full interface scaling from Settings: Large / Medium / Small.
- Expense entry date for normal expenses.
- Fixed-expense entry date.
- Calendar showing days that contain recorded entries.
- History screen with day filtering, all-history view, monthly navigation and totals.
- Entry dates are saved locally with each new expense/fixed expense.
- Older records without a stored date remain preserved and appear as "Date not recorded" rather than being assigned an invented date.
- Local app password protection using a salted PBKDF2-SHA-256 password hash; the password itself is never stored as plain text.
- Password lock screen on app startup, with enable/remove controls in Settings.
- Arabic, English, French, Swahili and Spanish labels for the new features.
- Existing fixed expenses remain included in total spent, remaining balance and analytics.

Notes:
- Password protection is device/app-level access protection. It does not encrypt the localStorage database itself.
- Web/Capacitor source is included. APK compilation still requires the Android/Capacitor build environment.
