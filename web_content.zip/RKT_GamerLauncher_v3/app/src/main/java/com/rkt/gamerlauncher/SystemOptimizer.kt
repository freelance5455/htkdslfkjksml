package com.rkt.gamerlauncher

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator

object SystemOptimizer {

    fun enableHighRefreshRate(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val display = activity.display ?: return
            val highestMode = display.supportedModes.maxByOrNull { it.refreshRate }
            highestMode?.let { mode ->
                val params = activity.window.attributes
                params.preferredDisplayModeId = mode.modeId
                activity.window.attributes = params
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val wm = activity.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            val highestMode = wm.defaultDisplay.supportedModes.maxByOrNull { it.refreshRate }
            highestMode?.let { mode ->
                val params = activity.window.attributes
                params.preferredDisplayModeId = mode.modeId
                activity.window.attributes = params
            }
        }
    }

    fun startTurboFanAnimation(view: View, durationMs: Long = 900L): ObjectAnimator {
        return ObjectAnimator.ofFloat(view, "rotation", 0f, 360f).apply {
            duration = durationMs
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }
    }

    fun boostMemory(context: Context): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val beforeMem = getAvailableMemoryMB(context)

        val pm = context.packageManager
        val packages = pm.getInstalledApplications(0)
        for (app in packages) {
            if (app.packageName != context.packageName) {
                am.killBackgroundProcesses(app.packageName)
            }
        }
        System.gc()
        val afterMem = getAvailableMemoryMB(context)
        return (afterMem - beforeMem).coerceAtLeast(0L)
    }

    fun getAvailableMemoryMB(context: Context): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        return memInfo.availMem / (1024 * 1024)
    }

    fun getMemoryUsagePercent(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val used = memInfo.totalMem - memInfo.availMem
        return ((used.toDouble() / memInfo.totalMem.toDouble()) * 100).toInt()
    }
}
