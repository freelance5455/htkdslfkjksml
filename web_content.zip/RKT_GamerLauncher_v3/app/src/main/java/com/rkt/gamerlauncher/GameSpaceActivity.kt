package com.rkt.gamerlauncher

import android.animation.ObjectAnimator
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class GameSpaceActivity : AppCompatActivity() {

    private lateinit var tvTelemetry: TextView
    private lateinit var pbRam: ProgressBar
    private lateinit var tvModeBadge: TextView
    private var fanAnimator: ObjectAnimator? = null
    private var currentRpm = "20,000 RPM"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SystemOptimizer.enableHighRefreshRate(this)
        setContentView(R.layout.activity_game_space)

        tvTelemetry = findViewById(R.id.tvTelemetry)
        pbRam = findViewById(R.id.pbRam)
        tvModeBadge = findViewById(R.id.tvModeBadge)
        val ivSpaceFan = findViewById<ImageView>(R.id.ivSpaceFan)
        val rvGames = findViewById<RecyclerView>(R.id.rvGames)
        val rgMode = findViewById<RadioGroup>(R.id.rgMode)
        val swTouch = findViewById<Switch>(R.id.swTouchResponse)
        val swDnd = findViewById<Switch>(R.id.swDnd)
        val btnExit = findViewById<Button>(R.id.btnExitSpace)

        fanAnimator = SystemOptimizer.startTurboFanAnimation(ivSpaceFan, 700L)

        rvGames.layoutManager = GridLayoutManager(this, 3)
        val games = loadGamesOnly()
        rvGames.adapter = AppAdapter(games) { game ->
            SystemOptimizer.boostMemory(this)
            Toast.makeText(this, "🔥 INICIANDO ${game.label.uppercase()}...", Toast.LENGTH_SHORT).show()
            packageManager.getLaunchIntentForPackage(game.packageName)?.let {
                startActivity(it)
            }
        }

        rgMode.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbEco -> {
                    currentRpm = "12,000 RPM"
                    fanAnimator?.duration = 1600L
                    tvModeBadge.text = "[ ECO ACTIVE ]"
                    tvModeBadge.setTextColor(Color.parseColor("#00FF88"))
                }
                R.id.rbRise -> {
                    currentRpm = "20,000 RPM"
                    fanAnimator?.duration = 700L
                    SystemOptimizer.enableHighRefreshRate(this)
                    tvModeBadge.text = "[ RISE ACTIVE ]"
                    tvModeBadge.setTextColor(Color.parseColor("#00F3FF"))
                }
                R.id.rbDiablo -> {
                    currentRpm = "25,000 MAX RPM"
                    fanAnimator?.duration = 320L
                    SystemOptimizer.enableHighRefreshRate(this)
                    val freed = SystemOptimizer.boostMemory(this)
                    tvModeBadge.text = "[ DIABLO OVERDRIVE ]"
                    tvModeBadge.setTextColor(Color.parseColor("#FF0033"))
                    Toast.makeText(this, "🔥 DIABLO MODE: +${freed} MB RAM LIBERADOS", Toast.LENGTH_SHORT).show()
                }
            }
            updateTelemetry()
        }

        swTouch.setOnCheckedChangeListener { _, isChecked ->
            val msg = if (isChecked) "Muestreo Táctil 960Hz: ON" else "Muestreo Táctil: Estándar"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }

        swDnd.setOnCheckedChangeListener { _, isChecked ->
            val msg = if (isChecked) "Bloqueo de distracciones: ACTIVO" else "Notificaciones: PERMITIDAS"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }

        btnExit.setOnClickListener { finish() }
        updateTelemetry()
    }

    private fun updateTelemetry() {
        val freeRam = SystemOptimizer.getAvailableMemoryMB(this)
        val ramUsage = SystemOptimizer.getMemoryUsagePercent(this)
        val temp = getBatteryTemp()
        pbRam.progress = ramUsage
        tvTelemetry.text = "TEMP: ${temp}°C | FAN: $currentRpm
RAM LIBRE: ${freeRam} MB | 120HZ MAX"
    }

    private fun getBatteryTemp(): Float {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        return temp / 10f
    }

    private fun loadGamesOnly(): List<AppInfo> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolvedList = pm.queryIntentActivities(intent, 0)
        val games = resolvedList.mapNotNull { resolveInfo ->
            val pkg = resolveInfo.activityInfo.packageName
            if (pkg == packageName) return@mapNotNull null
            val appInfo = pm.getApplicationInfo(pkg, 0)
            val isGame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else {
                @Suppress("DEPRECATION")
                (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }
            if (!isGame) return@mapNotNull null
            AppInfo(
                label = resolveInfo.loadLabel(pm).toString(),
                packageName = pkg,
                icon = resolveInfo.loadIcon(pm),
                isGame = true
            )
        }
        return games.ifEmpty {
            resolvedList.mapNotNull { resolveInfo ->
                val pkg = resolveInfo.activityInfo.packageName
                if (pkg == packageName) return@mapNotNull null
                AppInfo(
                    label = resolveInfo.loadLabel(pm).toString(),
                    packageName = pkg,
                    icon = resolveInfo.loadIcon(pm),
                    isGame = true
                )
            }
        }
    }
}
