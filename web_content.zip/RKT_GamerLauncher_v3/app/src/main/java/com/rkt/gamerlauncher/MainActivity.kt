package com.rkt.gamerlauncher

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var allApps: List<AppInfo>
    private lateinit var adapter: AppAdapter
    private lateinit var tvStats: TextView
    private lateinit var tvClock: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SystemOptimizer.enableHighRefreshRate(this)
        setContentView(R.layout.activity_main)

        tvStats = findViewById(R.id.tvStats)
        tvClock = findViewById(R.id.tvClock)
        val ivFan = findViewById<ImageView>(R.id.ivFan)
        val rvApps = findViewById<RecyclerView>(R.id.rvApps)
        val etSearch = findViewById<EditText>(R.id.etSearch)
        val btnBoost = findViewById<Button>(R.id.btnBoost)
        val btnGameSpace = findViewById<Button>(R.id.btnGameSpace)
        val btnWebDash = findViewById<Button>(R.id.btnWebDash)

        SystemOptimizer.startTurboFanAnimation(ivFan, 1200L)

        rvApps.setHasFixedSize(true)
        rvApps.setItemViewCacheSize(32)
        rvApps.layoutManager = GridLayoutManager(this, 4)

        allApps = loadInstalledApps()
        adapter = AppAdapter(allApps) { app ->
            launchAppOptimized(app)
        }
        rvApps.adapter = adapter

        updateHud()

        btnBoost.setOnClickListener {
            val freed = SystemOptimizer.boostMemory(this)
            updateHud()
            Toast.makeText(this, "⚡ TURBO BOOST: +${freed} MB LIBERADOS", Toast.LENGTH_SHORT).show()
        }

        btnGameSpace.setOnClickListener {
            startActivity(Intent(this, GameSpaceActivity::class.java))
        }

        btnWebDash.setOnClickListener {
            startActivity(Intent(this, WebDashboardActivity::class.java))
        }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().trim().lowercase()
                val filtered = if (q.isEmpty()) allApps else allApps.filter {
                    it.label.lowercase().contains(q)
                }
                adapter.updateList(filtered)
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    override fun onResume() {
        super.onResume()
        SystemOptimizer.enableHighRefreshRate(this)
        updateHud()
    }

    private fun updateHud() {
        val ramPercent = SystemOptimizer.getMemoryUsagePercent(this)
        tvStats.text = "RAM: $ramPercent% | 120HZ LOCKED | TOUCH: ULTRA"
        tvClock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }

    private fun launchAppOptimized(app: AppInfo) {
        if (app.isGame) {
            SystemOptimizer.boostMemory(this)
        }
        val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName)
        launchIntent?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    private fun loadInstalledApps(): List<AppInfo> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolvedList = pm.queryIntentActivities(intent, 0)
        return resolvedList.mapNotNull { resolveInfo ->
            val pkg = resolveInfo.activityInfo.packageName
            if (pkg == packageName) return@mapNotNull null
            val appInfo = pm.getApplicationInfo(pkg, 0)
            val isGame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else {
                @Suppress("DEPRECATION")
                (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }
            AppInfo(
                label = resolveInfo.loadLabel(pm).toString(),
                packageName = pkg,
                icon = resolveInfo.loadIcon(pm),
                isGame = isGame
            )
        }.sortedBy { it.label.lowercase() }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}
}
