# Vida em Fases — protótipo Android-friendly

Este protótipo é um simulador de vida em português, baseado em texto e otimizado para celular.

## Como jogar agora
1. Abra `index.html` no navegador do celular ou computador.
2. Crie uma personagem.
3. Conheça pessoas, desenvolva amizades/romances, escolha carreira, estude e avance os anos.
4. Use a aba **Modo Deus** para ajustar dinheiro, idade, saúde e felicidade.
5. O progresso é salvo no armazenamento local do navegador. Use **Exportar save** para guardar uma cópia.

## Limitações honestas desta versão
- É um protótipo local/offline. Não há servidor nem multiplayer real; recursos online exigiriam backend, contas, sincronização e moderação.
- Para obter um APK nativo, o HTML precisa ser empacotado em um app Android (por exemplo, com uma casca WebView/Capacitor e compilação Android). Este ambiente não tem Android SDK/Gradle configurado, então não consigo afirmar que um APK compilado foi gerado.
- O save fica no navegador em que você joga; exporte o JSON antes de limpar os dados do navegador.

## Próximos passos possíveis
- Mais eventos, escolhas com consequências e finais.
- Mais empregos, promoções, estudo, gastos, moradia e envelhecimento.
- Famílias, amizades, colegas, separações, reconciliações e diferentes orientações/identidades.
- Modo online com contas e saves sincronizados (requer backend).
