Bluetooth Mic Speaker — HTML prototype

Files:
- index.html: a simple live microphone monitoring page with Start/Stop and microphone selection.

How to try:
1. Unzip the file.
2. Open index.html in a modern browser that supports microphone access. Browsers commonly require HTTPS or localhost for microphone access; opening a local file may not work.
3. Allow microphone permission.
4. Connect the Bluetooth headset before starting.
5. Choose the headset microphone if it appears, then tap START LISTENING.

Important limitations:
- This is a prototype, not a guaranteed working Bluetooth audio-routing app.
- Android/browser audio routing varies by device. The browser may use the phone microphone rather than the Bluetooth headset microphone, and playback may use the headset rather than the phone speaker.
- A generic HTML-to-APK converter may wrap the page in a WebView that lacks microphone permissions or audio-routing controls.
- Reliable selection of Bluetooth headset microphone and forced playback through the phone speaker may require a native Android app with Android audio APIs, not just HTML.
- This app only monitors the microphone after the user explicitly presses Start and grants permission.
