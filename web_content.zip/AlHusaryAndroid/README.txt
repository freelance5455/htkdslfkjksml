Al-Husary Recitation Android project
====================================

This project wraps the provided HTML recitation player in an Android WebView.
Surah Ad-Duha is embedded in the original HTML and should play offline.
Other surahs require an internet connection, as in the original HTML.

Build an APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open and select the extracted AlHusaryAndroid folder.
4. Allow Gradle sync and install the Android SDK platform requested by the project.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show a link to the generated APK, usually under app/build/outputs/apk/debug/app-debug.apk.

Note: This ZIP is Android Studio project source, not a compiled APK. This environment does not have the Android SDK/Gradle build tools installed, so it cannot compile/sign an APK here.
