package com.jeyan.whoop

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val requestCode = 410
    private val heartService = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb")
    private val heartMeasurement = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb")
    private val batteryService = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb")
    private val batteryLevel = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb")
    private val cccd = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private var gatt: BluetoothGatt? = null
    private val found = linkedSetOf<String>()

    private val manager by lazy { getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager }
    private val adapter: BluetoothAdapter? get() = manager.adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBLE")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun hasBlePermissions(): Boolean {
        if (Build.VERSION.SDK_INT < 31) {
            return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    private fun askPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        ActivityCompat.requestPermissions(this, permissions, requestCode)
    }

    inner class Bridge {
        @JavascriptInterface fun scan() {
            runOnUiThread {
                if (!hasBlePermissions()) { askPermissions(); return@runOnUiThread }
                startScan()
            }
        }
        @JavascriptInterface fun connect(address: String) {
            runOnUiThread {
                if (!hasBlePermissions()) { askPermissions(); return@runOnUiThread }
                try {
                    val device = adapter?.getRemoteDevice(address)
                    if (device != null) {
                        gatt?.close()
                        emit("onBleStatus", "Connecting…")
                        gatt = if (Build.VERSION.SDK_INT >= 23)
                            device.connectGatt(this@MainActivity, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
                        else device.connectGatt(this@MainActivity, false, gattCallback)
                    }
                } catch (e: Exception) { emit("onBleStatus", "Connection failed: ${e.message}") }
            }
        }
        @JavascriptInterface fun disconnect() {
            runOnUiThread {
                try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
                gatt = null
                emit("onBleStatus", "Disconnected")
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        val scanner = adapter?.bluetoothLeScanner
        if (scanner == null) { emit("onBleStatus", "Bluetooth is unavailable or switched off"); return }
        found.clear()
        emit("onBleStatus", "Scanning nearby BLE devices…")
        try {
            scanner.startScan(scanCallback)
            web.postDelayed({
                try { scanner.stopScan(scanCallback) } catch (_: Exception) {}
                emit("onBleStatus", if (found.isEmpty()) "No BLE devices found. Keep the band awake and scan again." else "Scan complete")
            }, 12000)
        } catch (e: Exception) { emit("onBleStatus", "Scan error: ${e.message}") }
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val address = device.address ?: return
            if (!found.add(address)) return
            val name = try { device.name ?: result.scanRecord?.deviceName ?: "Unknown BLE device" } catch (_: SecurityException) { "BLE device" }
            val safeName = name.replace("'", "\\'")
            web.post { web.evaluateJavascript("window.onDeviceFound && window.onDeviceFound('$safeName','$address',${result.rssi})", null) }
        }
        override fun onScanFailed(errorCode: Int) { emit("onBleStatus", "Scan failed ($errorCode)") }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                emit("onBleStatus", "Connected — discovering supported services…")
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                emit("onBleStatus", "Disconnected")
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val heart = g.getService(heartService)?.getCharacteristic(heartMeasurement)
            val battery = g.getService(batteryService)?.getCharacteristic(batteryLevel)
            if (heart != null) {
                g.setCharacteristicNotification(heart, true)
                heart.getDescriptor(cccd)?.let {
                    it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    g.writeDescriptor(it)
                }
            }
            if (battery != null) g.readCharacteristic(battery)
            val supports = buildList {
                if (heart != null) add("heart rate")
                if (battery != null) add("battery")
            }
            emit("onBleStatus", if (supports.isEmpty())
                "Connected, but no standard Heart Rate or Battery service was found. This band may use a proprietary protocol."
                else "Connected • Standard services: ${supports.joinToString()}")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (c.uuid == heartMeasurement) parseHeartRate(c.value)
        }
        @SuppressLint("MissingPermission")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            if (c.uuid == heartMeasurement) parseHeartRate(value)
        }
        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && c.uuid == batteryLevel && c.value.isNotEmpty()) {
                emit("onBattery", (c.value[0].toInt() and 0xff).toString())
            }
        }
        private fun parseHeartRate(data: ByteArray) {
            if (data.isEmpty()) return
            val flags = data[0].toInt() and 0xff
            val bpm = if ((flags and 0x01) == 0) {
                if (data.size > 1) data[1].toInt() and 0xff else return
            } else {
                if (data.size > 2) ((data[2].toInt() and 0xff) shl 8) or (data[1].toInt() and 0xff) else return
            }
            emit("onHeartRate", bpm.toString())
        }
    }

    private fun emit(function: String, value: String) {
        val escaped = value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
        runOnUiThread { web.evaluateJavascript("window.$function && window.$function('$escaped')", null) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startScan()
            else emit("onBleStatus", "Bluetooth permissions are required to scan and connect.")
        }
    }

    @SuppressLint("MissingPermission")
    override fun onDestroy() {
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
