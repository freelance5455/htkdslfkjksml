VOLA RAPIDA — PROJET ANDROID (VERSION SOURCE 1.0)
================================================

Ity dia SOURCE PROJECT azo sokafana amin'ny Android Studio. Tsy APK efa vita izy ity.
Nohavaozina ny torolalana mba hanavahana ny fanamboarana APK sy ny fampandehanana ny asa tena izy.

EFA AO ANATY:
- Interface Android/WebView ho an'ny VOLA RAPIDA
- Pejy inscription/connexion (interface ihany amin'ity version ity)
- Pejy coins/bonus sy vidéo (tsy mbola misy ad provider mifandray)
- Pejy retrait Orange Money (interface ihany; tsy mandefa vola)
- Pejy parrainage sy dashboard ADMIN (interface ihany; tsy misy database tena izy)

ZAVA-DEHIBE — NY TENA ZAVA-MISY:
- Tsy mbola mamorona kaonty tena izy ny inscription amin'ity source version ity.
- Tsy mbola misy coins tena voamarina na bonus avy amin'ny publicité.
- Tsy mbola misy payout Orange Money mandeha ho azy.
- Tsy mbola misy dashboard admin mifandray amin'ny mpikambana tena izy.
- Tsy misy fomba ara-dalàna hiantohana vola miditra raha tsy misy mpamatsy vola, publicité, backend ary fifanarahana ilaina.
- Aza asiana PIN Orange Money na mot de passe tena izy amin'ny demo.

FOMBA A: MANAMBOATRA APK AMIN'NY ORDINATEUR (ANDROID STUDIO)
1. Adikao/extract-o ity ZIP ity.
2. Sokafy Android Studio.
3. Safidio Open ary fidio ilay dossier VOLA_RAPIDA_Android_Project (dossier misy settings.gradle).
4. Avelao hamita ny Gradle Sync sy ny download ilaina.
5. Raha mangataka Android SDK, apetraho ny SDK takian'ny projet (compileSdk 35).
6. Safidio Build > Build APK(s).
7. Rehefa vita, tsindrio Locate ao amin'ny notification; ny APK debug dia matetika ao app/build/outputs/apk/debug/app-debug.apk.
8. Alefaso any amin'ny finday ilay APK ary apetraho rehefa manaiky ny Android.

FOMBA B: AMIN'NY FINDAY ANDROID
- Mila Android IDE afaka manokatra Android Gradle project ianao. Tsy mitovy ny fahafahan'ny IDE tsirairay, ary mety tsy hahomby amin'ny finday sasany ny Gradle/SDK download.
- Extract-o aloha ilay ZIP, sokafy amin'ilay IDE ny dossier misy settings.gradle, avelao hisintona ny Gradle/SDK dependencies, dia Build APK.
- Raha miseho ny error dia alefaso ny sary feno amin'ilay error; aza mamafa rakitra kisendrasendra.

FIREBASE: INONA NO ASANY?
Firebase dia tsy fitaovana manova ZIP ho APK. Izy no azo ampiasaina amin'ny Authentication (kaonty), database, sns. Ny fanamboarana APK dia atao amin'ny Android Studio na IDE mifanaraka.
Alohan'ny hampiasana tena izy dia mila:
1. Mamorona Firebase project.
2. Mametraka Email/Password auth sy Google sign-in araka ny configuration ofisialy.
3. Mampifandray Firestore/serveur sy Security Rules.
4. Mametraka ADMIN role amin'ny server-side, fa tsy amin'ny bokotra ao amin'ny app.
5. Mamorona backend azo antoka hanisa coins sy hanamarina parrainage, video rewards ary retrait.
6. Mifandray amin'ny mpamatsy publicité sy Orange Money/payment provider ofisialy ary manaraka ny fepetra ara-dalàna.
7. Mitsapa fiarovana sy transaction rehetra alohan'ny famoahana.

TAHAN'NY COINS NIFANARAHANA HO AN'NY DESIGN:
100 coins = 1 000 Ar
1 000 coins parrainage = 10 000 Ar
Ireo dia fitsipika kendrena amin'ny interface, fa tsy porofo fa misy vola voafatsy na azo alaina amin'izao.
