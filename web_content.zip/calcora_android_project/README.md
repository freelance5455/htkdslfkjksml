# Calcora Android App

This is the Android wrapper project for the current Calcora web app.

- App name: Calcora
- Package: com.calcora.app
- Version: 1.0 (versionCode 1)
- Launcher icon: the supplied Calcora black/blue icon
- Web app is bundled locally, so Calcora can run offline.

## Build
Open this folder in Android Studio and choose **Build > Build APK(s)**.
The generated APK will be under `app/build/outputs/apk/`.

Future Calcora updates can be made to `app/src/main/assets/index.html`, then a new APK can be built with an incremented versionCode/versionName.
