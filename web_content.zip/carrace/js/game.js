/* Night Stage — a small 2D top-down car race.
   Plain canvas, no dependencies. All art and audio live in ../assets. */
(function () {
  'use strict';

  // ---------------------------------------------------------------- constants
  var W = 480, H = 720;
  var ROAD_L = 64, ROAD_R = 416;
  var ROAD_W = ROAD_R - ROAD_L;
  var LANES = 4;
  var LANE_W = ROAD_W / LANES;

  var PLAYER = { w: 46, h: 86, y: 560 };
  var START_SPEED = 260;      // px per second of road scroll
  var MAX_SPEED = 760;
  var ACCEL = 26;             // passive speed gain per second
  var THROTTLE = 190;         // extra gain while holding up
  var BRAKE = 320;
  var STEER = 430;            // px per second sideways
  var FUEL_DRAIN = 3.1;       // percent per second at base speed
  var FUEL_PER_CAN = 26;

  // ------------------------------------------------------------------- assets
  var IMAGES = {
    player: 'assets/car-player.png',
    rival1: 'assets/car-rival-01.png',
    rival2: 'assets/car-rival-02.png',
    rival3: 'assets/car-rival-03.png',
    asphalt: 'assets/asphalt.png',
    cone: 'assets/cone.png',
    fuel: 'assets/fuel.png'
  };
  var SOUNDS = {
    crash: 'assets/sfx/crash.wav',
    pickup: 'assets/sfx/pickup.wav',
    start: 'assets/sfx/start.wav'
  };

  var img = {}, snd = {}, muted = false;

  function loadImages(done) {
    var keys = Object.keys(IMAGES), left = keys.length;
    if (!left) return done();
    keys.forEach(function (k) {
      var i = new Image();
      i.onload = i.onerror = function () { if (--left === 0) done(); };
      i.src = IMAGES[k];
      img[k] = i;
    });
  }
  function loadSounds() {
    Object.keys(SOUNDS).forEach(function (k) {
      var a = new Audio(SOUNDS[k]);
      a.preload = 'auto';
      snd[k] = a;
    });
  }
  function play(name) {
    if (muted || !snd[name]) return;
    try {
      var a = snd[name].cloneNode();
      a.volume = name === 'crash' ? 0.55 : 0.4;
      a.play().catch(function () {});
    } catch (e) { /* audio is optional */ }
  }

  // -------------------------------------------------------------------- state
  var canvas = document.getElementById('game');
  var ctx = canvas.getContext('2d');
  var el = {
    overlay: document.getElementById('overlay'),
    eyebrow: document.getElementById('overlayEyebrow'),
    title: document.getElementById('overlayTitle'),
    text: document.getElementById('overlayText'),
    startBtn: document.getElementById('startBtn'),
    pauseBtn: document.getElementById('pauseBtn'),
    muteBtn: document.getElementById('muteBtn'),
    distance: document.getElementById('distance'),
    speed: document.getElementById('speed'),
    passes: document.getElementById('passes'),
    best: document.getElementById('best'),
    fuelFill: document.getElementById('fuelFill'),
    fuelPct: document.getElementById('fuelPct'),
    status: document.getElementById('status')
  };

  var mode = 'ready';               // ready | running | paused | over
  var keys = {};
  var game = null;
  var roadOffset = 0;
  var last = 0;
  var best = readBest();

  function readBest() {
    try { return parseInt(localStorage.getItem('nightstage.best'), 10) || 0; }
    catch (e) { return 0; }
  }
  function writeBest(v) {
    try { localStorage.setItem('nightstage.best', String(v)); } catch (e) {}
  }

  function newGame() {
    return {
      x: W / 2,
      speed: START_SPEED,
      distance: 0,
      fuel: 100,
      passes: 0,
      entities: [],
      spawnIn: 0.8,
      shake: 0,
      tilt: 0
    };
  }

  // ------------------------------------------------------------------ spawning
  function laneCenter(i) { return ROAD_L + LANE_W * (i + 0.5); }

  function spawn() {
    var lane = Math.floor(Math.random() * LANES);
    var roll = Math.random();
    var difficulty = (game.speed - START_SPEED) / (MAX_SPEED - START_SPEED);

    if (roll < 0.14 || game.fuel < 35 && roll < 0.3) {
      game.entities.push({
        type: 'fuel', x: laneCenter(lane), y: -60,
        w: 30, h: 34, speed: 0, img: img.fuel
      });
    } else if (roll < 0.3) {
      game.entities.push({
        type: 'cone', x: laneCenter(lane) + (Math.random() * 40 - 20), y: -60,
        w: 30, h: 30, speed: 0, img: img.cone
      });
    } else {
      var sprites = [img.rival1, img.rival2, img.rival3];
      game.entities.push({
        type: 'rival', x: laneCenter(lane), y: -130,
        w: 46, h: 86,
        speed: 90 + Math.random() * (120 + difficulty * 130),  // their own pace
        drift: (Math.random() < 0.25 ? (Math.random() < 0.5 ? -1 : 1) * 22 : 0),
        img: sprites[Math.floor(Math.random() * sprites.length)],
        counted: false
      });
    }
    // spawn gap tightens as the run speeds up
    game.spawnIn = Math.max(0.28, 0.95 - difficulty * 0.55) * (0.7 + Math.random() * 0.7);
  }

  // ------------------------------------------------------------------- update
  function update(dt) {
    var g = game;

    // steering
    var dir = 0;
    if (keys.left) dir -= 1;
    if (keys.right) dir += 1;
    g.x += dir * STEER * dt;
    g.tilt += ((dir * 0.14) - g.tilt) * Math.min(1, dt * 10);

    var half = PLAYER.w / 2;
    if (g.x < ROAD_L + half - 10) g.x = ROAD_L + half - 10;
    if (g.x > ROAD_R - half + 10) g.x = ROAD_R - half + 10;

    // throttle
    if (keys.up) g.speed += THROTTLE * dt;
    else if (keys.down) g.speed -= BRAKE * dt;
    else g.speed += ACCEL * dt;
    g.speed = Math.max(170, Math.min(MAX_SPEED, g.speed));

    g.distance += g.speed * dt * 0.1;
    roadOffset = (roadOffset + g.speed * dt) % 256;

    // fuel burns faster the harder you push
    g.fuel -= FUEL_DRAIN * dt * (0.55 + g.speed / START_SPEED * 0.45);
    if (g.fuel <= 0) { g.fuel = 0; return end('dry'); }

    // entities
    g.spawnIn -= dt;
    if (g.spawnIn <= 0) spawn();

    for (var i = g.entities.length - 1; i >= 0; i--) {
      var e = g.entities[i];
      e.y += (g.speed - e.speed) * dt;
      if (e.drift) {
        e.x += e.drift * dt;
        if (e.x < ROAD_L + 26 || e.x > ROAD_R - 26) e.drift *= -1;
      }
      if (e.type === 'rival' && !e.counted && e.y > PLAYER.y + 40) {
        e.counted = true;
        g.passes++;
      }
      if (e.y > H + 140) { g.entities.splice(i, 1); continue; }

      if (hits(e, g.x)) {
        if (e.type === 'fuel') {
          g.entities.splice(i, 1);
          g.fuel = Math.min(100, g.fuel + FUEL_PER_CAN);
          play('pickup');
          flash('Topped up. Keep it pinned.');
        } else {
          return end(e.type);
        }
      }
    }
  }

  function hits(e, px) {
    var pad = e.type === 'fuel' ? 6 : 8;   // forgiving hitboxes
    return Math.abs(e.x - px) * 2 < (e.w + PLAYER.w - pad * 2) &&
           Math.abs(e.y - PLAYER.y) * 2 < (e.h + PLAYER.h - pad * 2);
  }

  // ---------------------------------------------------------------- rendering
  var asphaltPattern = null;

  function drawRoad() {
    // verge
    ctx.fillStyle = '#161c17';
    ctx.fillRect(0, 0, W, H);
    for (var s = 0; s < 26; s++) {                       // roadside posts
      var y = ((s * 90) + roadOffset * 0.9) % (H + 90) - 45;
      ctx.fillStyle = '#2a3329';
      ctx.fillRect(24, y, 10, 34);
      ctx.fillRect(W - 34, y, 10, 34);
      ctx.fillStyle = 'rgba(240,168,46,.55)';
      ctx.fillRect(24, y, 10, 7);
      ctx.fillRect(W - 34, y, 10, 7);
    }

    // tarmac
    if (asphaltPattern) {
      ctx.save();
      ctx.translate(0, roadOffset % 256);
      ctx.fillStyle = asphaltPattern;
      ctx.fillRect(ROAD_L, -256, ROAD_W, H + 512);
      ctx.restore();
    } else {
      ctx.fillStyle = '#252831';
      ctx.fillRect(ROAD_L, 0, ROAD_W, H);
    }

    // edge lines
    ctx.fillStyle = 'rgba(232,230,225,.8)';
    ctx.fillRect(ROAD_L + 5, 0, 4, H);
    ctx.fillRect(ROAD_R - 9, 0, 4, H);

    // lane dashes
    ctx.fillStyle = 'rgba(232,230,225,.45)';
    for (var l = 1; l < LANES; l++) {
      var x = ROAD_L + LANE_W * l - 2;
      for (var d = -1; d < H / 60 + 1; d++) {
        ctx.fillRect(x, d * 60 + (roadOffset % 60), 4, 30);
      }
    }
  }

  function drawSprite(image, x, y, w, h, rot) {
    if (!image || !image.width) {
      ctx.fillStyle = '#f0a82e';
      ctx.fillRect(x - w / 2, y - h / 2, w, h);
      return;
    }
    ctx.save();
    ctx.translate(x, y);
    if (rot) ctx.rotate(rot);
    ctx.drawImage(image, -w / 2, -h / 2, w, h);
    ctx.restore();
  }

  function render() {
    ctx.clearRect(0, 0, W, H);
    ctx.save();
    if (game && game.shake > 0) {
      ctx.translate((Math.random() - 0.5) * game.shake, (Math.random() - 0.5) * game.shake);
    }

    drawRoad();

    if (game) {
      // headlight wash ahead of the player
      var grad = ctx.createLinearGradient(0, PLAYER.y - 340, 0, PLAYER.y);
      grad.addColorStop(0, 'rgba(246,199,110,0)');
      grad.addColorStop(1, 'rgba(246,199,110,.14)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(game.x - 20, PLAYER.y - 20);
      ctx.lineTo(game.x - 150, PLAYER.y - 340);
      ctx.lineTo(game.x + 150, PLAYER.y - 340);
      ctx.lineTo(game.x + 20, PLAYER.y - 20);
      ctx.closePath();
      ctx.fill();

      game.entities.forEach(function (e) {
        ctx.globalAlpha = 0.35;
        ctx.fillStyle = '#000';
        ctx.fillRect(e.x - e.w / 2 + 5, e.y - e.h / 2 + 8, e.w, e.h);
        ctx.globalAlpha = 1;
        drawSprite(e.img, e.x, e.y, e.w, e.h, 0);
      });

      ctx.globalAlpha = 0.4;
      ctx.fillStyle = '#000';
      ctx.fillRect(game.x - PLAYER.w / 2 + 5, PLAYER.y - PLAYER.h / 2 + 8, PLAYER.w, PLAYER.h);
      ctx.globalAlpha = 1;
      drawSprite(img.player, game.x, PLAYER.y, PLAYER.w, PLAYER.h, game.tilt);
    }

    ctx.restore();

    // vignette
    var v = ctx.createRadialGradient(W / 2, H / 2, H * 0.32, W / 2, H / 2, H * 0.78);
    v.addColorStop(0, 'rgba(0,0,0,0)');
    v.addColorStop(1, 'rgba(0,0,0,.55)');
    ctx.fillStyle = v;
    ctx.fillRect(0, 0, W, H);

    if (mode === 'paused') {
      ctx.fillStyle = 'rgba(9,12,17,.72)';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#e8e6e1';
      ctx.textAlign = 'center';
      ctx.font = '600 46px "Arial Narrow", Impact, sans-serif';
      ctx.fillText('PAUSED', W / 2, H / 2);
      ctx.font = '13px ui-monospace, Menlo, monospace';
      ctx.fillStyle = '#8d97a6';
      ctx.fillText('press P to roll again', W / 2, H / 2 + 26);
    }
  }

  // ----------------------------------------------------------------- HUD text
  var statusTimer = 0;
  function flash(msg) { el.status.textContent = msg; statusTimer = 2.2; }

  function syncHUD(dt) {
    if (!game) return;
    el.distance.textContent = Math.floor(game.distance);
    el.speed.textContent = Math.round(game.speed * 0.42);
    el.passes.textContent = game.passes;
    el.best.textContent = best;
    var f = Math.max(0, Math.round(game.fuel));
    el.fuelFill.style.width = f + '%';
    el.fuelFill.classList.toggle('is-low', f < 25);
    el.fuelPct.textContent = f + '%';
    if (statusTimer > 0) {
      statusTimer -= dt;
    } else if (mode === 'running') {
      el.status.textContent = f < 25 ? 'Fuel low — find a can.' : 'Clean run. Hold your line.';
    }
  }

  // --------------------------------------------------------------- game flow
  function start() {
    game = newGame();
    mode = 'running';
    statusTimer = 0;
    el.overlay.hidden = true;
    el.pauseBtn.textContent = 'Pause';
    flash('Green light. Go.');
    play('start');
    canvas.focus();
  }

  function end(cause) {
    mode = 'over';
    game.shake = 14;
    play('crash');
    var dist = Math.floor(game.distance);
    if (dist > best) { best = dist; writeBest(best); }

    var lines = {
      rival: 'You clipped a rival at speed.',
      cone: 'Cone. The stage marshals are not amused.',
      dry: 'Tank ran dry and the engine died.'
    };
    el.eyebrow.textContent = 'Run ended';
    el.title.textContent = dist + 'm';
    el.text.textContent = lines[cause] + ' Overtakes: ' + game.passes +
      '. Best run so far: ' + best + 'm.';
    el.startBtn.textContent = 'Run it again';
    el.overlay.hidden = false;
    el.status.textContent = lines[cause];
    el.startBtn.focus();
  }

  function togglePause(force) {
    if (mode === 'running') {
      mode = 'paused';
      el.pauseBtn.textContent = 'Resume';
      el.status.textContent = 'Paused at the side of the road.';
    } else if (mode === 'paused' && !force) {
      mode = 'running';
      el.pauseBtn.textContent = 'Pause';
      statusTimer = 0;
    }
  }

  // -------------------------------------------------------------------- loop
  function frame(ts) {
    var dt = Math.min(0.05, (ts - last) / 1000 || 0);
    last = ts;
    if (mode === 'running') update(dt);
    if (game && game.shake > 0) game.shake = Math.max(0, game.shake - dt * 30);
    syncHUD(dt);
    render();
    requestAnimationFrame(frame);
  }

  // ------------------------------------------------------------------ inputs
  var KEYMAP = {
    ArrowLeft: 'left', a: 'left', A: 'left',
    ArrowRight: 'right', d: 'right', D: 'right',
    ArrowUp: 'up', w: 'up', W: 'up',
    ArrowDown: 'down', s: 'down', S: 'down'
  };

  document.addEventListener('keydown', function (ev) {
    var k = KEYMAP[ev.key];
    if (k) { keys[k] = true; ev.preventDefault(); return; }
    if (ev.key === 'p' || ev.key === 'P') togglePause();
    if (ev.key === 'm' || ev.key === 'M') toggleMute();
    if (ev.key === 'r' || ev.key === 'R') start();
    if (ev.key === ' ' && mode !== 'running') { ev.preventDefault(); start(); }
  });
  document.addEventListener('keyup', function (ev) {
    var k = KEYMAP[ev.key];
    if (k) keys[k] = false;
  });

  // pointer / touch: drag anywhere on the canvas to steer
  var dragging = false;
  function pointerX(ev) {
    var r = canvas.getBoundingClientRect();
    return (ev.clientX - r.left) * (W / r.width);
  }
  canvas.addEventListener('pointerdown', function (ev) {
    if (mode !== 'running') return;
    dragging = true;
    canvas.setPointerCapture(ev.pointerId);
    game.x = pointerX(ev);
  });
  canvas.addEventListener('pointermove', function (ev) {
    if (dragging && mode === 'running') game.x = pointerX(ev);
  });
  ['pointerup', 'pointercancel'].forEach(function (t) {
    canvas.addEventListener(t, function () { dragging = false; });
  });

  el.startBtn.addEventListener('click', start);
  el.pauseBtn.addEventListener('click', function () { togglePause(); });
  el.muteBtn.addEventListener('click', toggleMute);

  function toggleMute() {
    muted = !muted;
    el.muteBtn.textContent = muted ? 'Sound off' : 'Sound on';
    el.muteBtn.setAttribute('aria-pressed', String(muted));
  }

  document.addEventListener('visibilitychange', function () {
    if (document.hidden) togglePause(true);
  });
  window.addEventListener('blur', function () { togglePause(true); keys = {}; });

  // ------------------------------------------------------------------- boot
  el.startBtn.disabled = true;
  el.startBtn.textContent = 'Loading…';
  loadSounds();
  loadImages(function () {
    if (img.asphalt.width) asphaltPattern = ctx.createPattern(img.asphalt, 'repeat');
    el.startBtn.disabled = false;
    el.startBtn.textContent = 'Start the run';
    el.best.textContent = best;
    requestAnimationFrame(function (t) { last = t; frame(t); });
  });
})();
