# ShizuTune

**Free, open-source, rootless Android system tweaks via Shizuku**

Open `index.html` in a browser for a full landing page, or keep reading.

## Features (v1.1)

| Feature | Description |
|---------|-------------|
| **Refresh rate** | Force 60 / 90 / 120 Hz + reset |
| **Safe resolution** | Width × Height + DPI with **6-second auto-revert** |
| **Animation scale** | 0.5× / Off / 1× |
| **Private DNS** | Cloudflare, AdGuard, Off |
| **Window blurs** | Disable (Android 12+) to free GPU |
| **Heads-up notifications** | Off for gaming focus / On |
| **Long-press timeout** | Faster (200 ms) or stock |
| **Clear caches** | `pm trim-caches` |
| **Shell Execute** | Run any command with live output + quick chips |
| **Device Info** | Model, Android version, current display & settings |
| **One-tap reset** | Revert everything ShizuTune touched |

No premium, no accounts, no anti-tamper, no closed-source APK.

## Requirements

1. Android 8.0+ (API 26+)
2. [Shizuku](https://shizuku.rikka.app/) installed and **running**
   - Easiest: Wireless Debugging (Android 11+)
3. Grant Shizuku permission when the app asks

## Build

```bash
# Open in Android Studio, or:
./gradlew assembleDebug
# APK → app/build/outputs/apk/debug/app-debug.apk
```

## Project structure

```
app/src/main/java/com/shizutune/app/
├── shizuku/ShizukuHelper.kt   # Official Shizuku newProcess wrapper
├── tweaks/TweakManager.kt     # All reversible shell tweaks
└── ui/
    ├── MainActivity.kt        # Main dashboard
    └── ShellActivity.kt       # Shell execute screen
```

## Safety notes

- Resolution changes start a 6-second countdown; do nothing → auto-revert.
- Extreme values can cause temporary UI glitches. Keep the reset button handy.
- Shell Execute runs with shell privileges — only run commands you trust.
- Use at your own risk.

## License

MIT
