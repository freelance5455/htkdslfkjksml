package com.shizutune.app.tweaks

import com.shizutune.app.shizuku.ShizukuHelper
import kotlinx.coroutines.delay

/**
 * Safe, reversible tweaks only.
 * All commands use public ADB/shell settings that Shizuku can execute.
 */
object TweakManager {

    // ---------- Refresh Rate ----------
    suspend fun setRefreshRate(minHz: Float, peakHz: Float): ShizukuHelper.CommandResult {
        val r1 = ShizukuHelper.exec("settings put system min_refresh_rate $minHz")
        if (!r1.isSuccess) return r1
        return ShizukuHelper.exec("settings put system peak_refresh_rate $peakHz")
    }

    suspend fun getRefreshRate(): Pair<String, String> {
        val min = ShizukuHelper.exec("settings get system min_refresh_rate")
        val peak = ShizukuHelper.exec("settings get system peak_refresh_rate")
        return (min.stdout.ifBlank { "null" }) to (peak.stdout.ifBlank { "null" })
    }

    suspend fun resetRefreshRate(): ShizukuHelper.CommandResult {
        ShizukuHelper.exec("settings delete system min_refresh_rate")
        return ShizukuHelper.exec("settings delete system peak_refresh_rate")
    }

    // ---------- Resolution (with safe-revert support) ----------
    suspend fun setResolution(width: Int, height: Int, density: Int? = null): ShizukuHelper.CommandResult {
        val sizeResult = ShizukuHelper.exec("wm size ${width}x${height}")
        if (!sizeResult.isSuccess) return sizeResult
        if (density != null) {
            return ShizukuHelper.exec("wm density $density")
        }
        return sizeResult
    }

    suspend fun resetResolution(): ShizukuHelper.CommandResult {
        ShizukuHelper.exec("wm size reset")
        return ShizukuHelper.exec("wm density reset")
    }

    suspend fun getResolution(): String {
        val size = ShizukuHelper.exec("wm size")
        val density = ShizukuHelper.exec("wm density")
        return "${size.stdout}\n${density.stdout}"
    }

    /**
     * Apply resolution and auto-revert after [timeoutSeconds] if caller doesn't cancel.
     */
    suspend fun applyResolutionWithSafeRevert(
        width: Int,
        height: Int,
        density: Int?,
        timeoutSeconds: Int = 6,
        onTick: (remaining: Int) -> Unit = {},
        onReverted: () -> Unit = {}
    ): ShizukuHelper.CommandResult {
        val result = setResolution(width, height, density)
        if (!result.isSuccess) return result

        for (i in timeoutSeconds downTo 1) {
            onTick(i)
            delay(1000)
        }
        resetResolution()
        onReverted()
        return result
    }

    // ---------- Animation Speed ----------
    suspend fun setAnimationScale(scale: Float): ShizukuHelper.CommandResult {
        val cmds = listOf(
            "settings put global window_animation_scale $scale",
            "settings put global transition_animation_scale $scale",
            "settings put global animator_duration_scale $scale"
        )
        var last = ShizukuHelper.CommandResult(0, "", "")
        for (cmd in cmds) {
            last = ShizukuHelper.exec(cmd)
            if (!last.isSuccess) return last
        }
        return last
    }

    suspend fun resetAnimationScale(): ShizukuHelper.CommandResult {
        return setAnimationScale(1.0f)
    }

    // ---------- Private DNS ----------
    suspend fun setPrivateDns(hostname: String?): ShizukuHelper.CommandResult {
        return if (hostname.isNullOrBlank()) {
            ShizukuHelper.exec("settings put global private_dns_mode off")
        } else {
            val mode = ShizukuHelper.exec("settings put global private_dns_mode hostname")
            if (!mode.isSuccess) return mode
            ShizukuHelper.exec("settings put global private_dns_specifier $hostname")
        }
    }

    suspend fun getPrivateDns(): String {
        val mode = ShizukuHelper.exec("settings get global private_dns_mode")
        val specifier = ShizukuHelper.exec("settings get global private_dns_specifier")
        return "mode=${mode.stdout}, host=${specifier.stdout}"
    }

    // ---------- Cache clearing ----------
    suspend fun clearAllAppCaches(): ShizukuHelper.CommandResult {
        return ShizukuHelper.exec("pm trim-caches 999G")
    }

    // ---------- Disable Window Blurs (Android 12+) ----------
    suspend fun setWindowBlurs(disabled: Boolean): ShizukuHelper.CommandResult {
        val value = if (disabled) "1" else "0"
        return ShizukuHelper.exec("settings put global disable_window_blurs $value")
    }

    // ---------- Developer Options visibility ----------
    suspend fun setDeveloperOptions(enabled: Boolean): ShizukuHelper.CommandResult {
        val value = if (enabled) "1" else "0"
        return ShizukuHelper.exec("settings put global development_settings_enabled $value")
    }

    // ---------- Force Peak Refresh (aggressive) ----------
    suspend fun forcePeakRefresh(enabled: Boolean): ShizukuHelper.CommandResult {
        // Some OEMs respect this global key
        val value = if (enabled) "1" else "0"
        return ShizukuHelper.exec("settings put global force_peak_refresh_rate $value")
    }

    // ---------- Pointer / Touch related ----------
    suspend fun setLongPressTimeout(ms: Int): ShizukuHelper.CommandResult {
        return ShizukuHelper.exec("settings put secure long_press_timeout $ms")
    }

    suspend fun resetLongPressTimeout(): ShizukuHelper.CommandResult {
        // Default is usually 400-500ms
        return ShizukuHelper.exec("settings put secure long_press_timeout 400")
    }

    // ---------- Immersive / Heads-up notifications (Gaming Focus lite) ----------
    suspend fun setHeadsUpNotifications(enabled: Boolean): ShizukuHelper.CommandResult {
        val value = if (enabled) "1" else "0"
        return ShizukuHelper.exec("settings put global heads_up_notifications_enabled $value")
    }

    // ---------- Shell execute (user-provided, with safety note) ----------
    suspend fun runShell(command: String): ShizukuHelper.CommandResult {
        return ShizukuHelper.exec(command)
    }

    // ---------- Device info helpers ----------
    suspend fun getDeviceInfo(): String {
        val props = listOf(
            "getprop ro.product.model",
            "getprop ro.build.version.release",
            "getprop ro.build.version.sdk",
            "wm size",
            "wm density",
            "settings get system peak_refresh_rate",
            "settings get system min_refresh_rate",
            "settings get global private_dns_mode",
            "settings get global private_dns_specifier",
            "settings get global window_animation_scale"
        )
        val sb = StringBuilder()
        for (cmd in props) {
            val r = ShizukuHelper.exec(cmd)
            sb.appendLine("$cmd → ${r.stdout.ifBlank { r.stderr.ifBlank { "(empty)" } }}")
        }
        return sb.toString()
    }

    // ---------- One-tap full reset ----------
    suspend fun resetAll(): List<ShizukuHelper.CommandResult> {
        return listOf(
            resetRefreshRate(),
            resetResolution(),
            resetAnimationScale(),
            setPrivateDns(null),
            setWindowBlurs(false),
            setHeadsUpNotifications(true),
            resetLongPressTimeout(),
            forcePeakRefresh(false)
        )
    }
}
