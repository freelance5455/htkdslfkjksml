package com.shizutune.app.shizuku

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuHelper {

    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Exception) {
        false
    }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Exception) {
        false
    }

    fun requestPermission(requestCode: Int = 1001) {
        if (!hasPermission()) {
            Shizuku.requestPermission(requestCode)
        }
    }

    /**
     * Execute a shell command via Shizuku and return stdout + stderr + exit code.
     * Must be called off the main thread.
     */
    suspend fun exec(command: String): CommandResult = withContext(Dispatchers.IO) {
        if (!isAvailable()) {
            return@withContext CommandResult(-1, "", "Shizuku is not running")
        }
        if (!hasPermission()) {
            return@withContext CommandResult(-1, "", "Shizuku permission not granted")
        }

        try {
            // Use the public newProcess API
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                ?: return@withContext CommandResult(-1, "", "Failed to create process")

            val stdout = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
            val code = process.waitFor()

            CommandResult(code, stdout.trim(), stderr.trim())
        } catch (e: Exception) {
            CommandResult(-1, "", e.message ?: "Unknown error")
        }
    }

    data class CommandResult(
        val exitCode: Int,
        val stdout: String,
        val stderr: String
    ) {
        val isSuccess: Boolean get() = exitCode == 0
        val output: String
            get() = when {
                stdout.isNotBlank() && stderr.isNotBlank() -> "$stdout\n$stderr"
                stdout.isNotBlank() -> stdout
                else -> stderr
            }
    }
}
