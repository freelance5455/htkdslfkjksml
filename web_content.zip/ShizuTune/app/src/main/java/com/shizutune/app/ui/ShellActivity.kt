package com.shizutune.app.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.shizutune.app.databinding.ActivityShellBinding
import com.shizutune.app.shizuku.ShizukuHelper
import com.shizutune.app.tweaks.TweakManager
import kotlinx.coroutines.launch

class ShellActivity : AppCompatActivity() {

    private lateinit var binding: ActivityShellBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShellBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.btnRun.setOnClickListener {
            val cmd = binding.etCommand.text?.toString()?.trim().orEmpty()
            if (cmd.isBlank()) {
                Toast.makeText(this, "Enter a command", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!ShizukuHelper.isAvailable() || !ShizukuHelper.hasPermission()) {
                Toast.makeText(this, "Shizuku not ready", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                binding.progress.visibility = View.VISIBLE
                binding.tvOutput.text = "Running…"
                val result = TweakManager.runShell(cmd)
                binding.progress.visibility = View.GONE
                binding.tvOutput.text = buildString {
                    appendLine("Exit code: ${result.exitCode}")
                    appendLine()
                    if (result.stdout.isNotBlank()) {
                        appendLine("STDOUT:")
                        appendLine(result.stdout)
                    }
                    if (result.stderr.isNotBlank()) {
                        appendLine("STDERR:")
                        appendLine(result.stderr)
                    }
                    if (result.stdout.isBlank() && result.stderr.isBlank()) {
                        appendLine("(no output)")
                    }
                }
            }
        }

        binding.btnClear.setOnClickListener {
            binding.tvOutput.text = ""
            binding.etCommand.setText("")
        }

        // Quick examples
        binding.chipWhoami.setOnClickListener { binding.etCommand.setText("whoami") }
        binding.chipId.setOnClickListener { binding.etCommand.setText("id") }
        binding.chipWmSize.setOnClickListener { binding.etCommand.setText("wm size") }
        binding.chipGetprop.setOnClickListener { binding.etCommand.setText("getprop ro.product.model") }
        binding.chipPmList.setOnClickListener { binding.etCommand.setText("pm list packages -3 | head -20") }
    }
}
