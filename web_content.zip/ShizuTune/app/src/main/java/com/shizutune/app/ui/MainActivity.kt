package com.shizutune.app.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.shizutune.app.R
import com.shizutune.app.databinding.ActivityMainBinding
import com.shizutune.app.shizuku.ShizukuHelper
import com.shizutune.app.tweaks.TweakManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var safeRevertJob: Job? = null

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        updateShizukuStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        updateShizukuStatus()
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                updateShizukuStatus()
                toast("Shizuku permission granted")
            } else {
                toast(getString(R.string.shizuku_permission_denied))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)

        setupUi()
        updateShizukuStatus()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_shell -> {
                startActivity(Intent(this, ShellActivity::class.java))
                true
            }
            R.id.action_about -> {
                MaterialAlertDialogBuilder(this)
                    .setTitle("ShizuTune")
                    .setMessage(
                        "Free & open-source system tweaks via Shizuku.\n\n" +
                        "No premium, no accounts, no closed-source APK.\n\n" +
                        "Version 1.1.0"
                    )
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        safeRevertJob?.cancel()
    }

    private fun setupUi() {
        binding.btnRequestShizuku.setOnClickListener {
            if (!ShizukuHelper.isAvailable()) {
                toast(getString(R.string.shizuku_not_running))
                return@setOnClickListener
            }
            ShizukuHelper.requestPermission()
        }

        // Refresh Rate
        binding.btnRr60.setOnClickListener { applyRefreshRate(60f, 60f) }
        binding.btnRr90.setOnClickListener { applyRefreshRate(90f, 90f) }
        binding.btnRr120.setOnClickListener { applyRefreshRate(120f, 120f) }
        binding.btnRrReset.setOnClickListener {
            runTweak("Reset refresh rate") { TweakManager.resetRefreshRate() }
        }

        // Resolution
        binding.btnResApply.setOnClickListener { showResolutionDialog() }
        binding.btnResReset.setOnClickListener {
            safeRevertJob?.cancel()
            runTweak("Reset resolution") { TweakManager.resetResolution() }
        }

        // Animation
        binding.btnAnim05.setOnClickListener {
            runTweak("Animation 0.5x") { TweakManager.setAnimationScale(0.5f) }
        }
        binding.btnAnim0.setOnClickListener {
            runTweak("Animation off") { TweakManager.setAnimationScale(0f) }
        }
        binding.btnAnimReset.setOnClickListener {
            runTweak("Animation 1x") { TweakManager.resetAnimationScale() }
        }

        // DNS
        binding.btnDnsCloudflare.setOnClickListener {
            runTweak("DNS Cloudflare") { TweakManager.setPrivateDns("one.one.one.one") }
        }
        binding.btnDnsAdguard.setOnClickListener {
            runTweak("DNS AdGuard") { TweakManager.setPrivateDns("dns.adguard.com") }
        }
        binding.btnDnsOff.setOnClickListener {
            runTweak("DNS Off") { TweakManager.setPrivateDns(null) }
        }

        // Extra tweaks
        binding.btnBlurOff.setOnClickListener {
            runTweak("Window blurs off") { TweakManager.setWindowBlurs(true) }
        }
        binding.btnBlurOn.setOnClickListener {
            runTweak("Window blurs on") { TweakManager.setWindowBlurs(false) }
        }
        binding.btnHeadsUpOff.setOnClickListener {
            runTweak("Heads-up off") { TweakManager.setHeadsUpNotifications(false) }
        }
        binding.btnHeadsUpOn.setOnClickListener {
            runTweak("Heads-up on") { TweakManager.setHeadsUpNotifications(true) }
        }
        binding.btnTouchFast.setOnClickListener {
            runTweak("Long-press 200ms") { TweakManager.setLongPressTimeout(200) }
        }
        binding.btnTouchReset.setOnClickListener {
            runTweak("Long-press reset") { TweakManager.resetLongPressTimeout() }
        }

        // Cache / Shell / Info / Reset
        binding.btnClearCache.setOnClickListener {
            runTweak("Clear caches") { TweakManager.clearAllAppCaches() }
        }
        binding.btnShell.setOnClickListener {
            startActivity(Intent(this, ShellActivity::class.java))
        }
        binding.btnDeviceInfo.setOnClickListener {
            if (!ensureShizuku()) return@setOnClickListener
            lifecycleScope.launch {
                binding.progress.visibility = View.VISIBLE
                val info = TweakManager.getDeviceInfo()
                binding.progress.visibility = View.GONE
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Device Info")
                    .setMessage(info)
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
            }
        }
        binding.btnResetAll.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Reset all tweaks")
                .setMessage(R.string.confirm_reset)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    lifecycleScope.launch {
                        safeRevertJob?.cancel()
                        val results = TweakManager.resetAll()
                        val ok = results.all { it.isSuccess }
                        snack(if (ok) "All tweaks reset" else "Some resets failed")
                    }
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    private fun applyRefreshRate(min: Float, peak: Float) {
        runTweak("Refresh rate ${peak.toInt()} Hz") {
            TweakManager.setRefreshRate(min, peak)
        }
    }

    private fun showResolutionDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_resolution, null)
        val etWidth = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etWidth)
        val etHeight = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etHeight)
        val etDpi = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etDpi)

        MaterialAlertDialogBuilder(this)
            .setTitle("Safe Resolution Change")
            .setMessage("A 6-second auto-revert timer will start after applying. Tap Confirm before it ends.")
            .setView(view)
            .setPositiveButton("Apply with timer") { _, _ ->
                val w = etWidth.text?.toString()?.toIntOrNull()
                val h = etHeight.text?.toString()?.toIntOrNull()
                val d = etDpi.text?.toString()?.toIntOrNull()
                if (w == null || h == null || w < 320 || h < 480) {
                    toast("Invalid width/height")
                    return@setPositiveButton
                }
                startSafeResolution(w, h, d)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun startSafeResolution(width: Int, height: Int, density: Int?) {
        safeRevertJob?.cancel()
        safeRevertJob = lifecycleScope.launch {
            binding.safeRevertBanner.visibility = View.VISIBLE
            val result = TweakManager.applyResolutionWithSafeRevert(
                width = width,
                height = height,
                density = density,
                timeoutSeconds = 6,
                onTick = { remaining ->
                    binding.tvSafeRevert.text =
                        getString(R.string.safe_revert_msg, remaining)
                },
                onReverted = {
                    binding.safeRevertBanner.visibility = View.GONE
                    snack("Resolution auto-reverted to stock")
                }
            )
            if (!result.isSuccess) {
                binding.safeRevertBanner.visibility = View.GONE
                snack("Failed: ${result.output}")
            } else {
                binding.btnConfirmRes.setOnClickListener {
                    safeRevertJob?.cancel()
                    binding.safeRevertBanner.visibility = View.GONE
                    snack("Resolution kept")
                }
            }
        }
    }

    private fun runTweak(label: String, block: suspend () -> ShizukuHelper.CommandResult) {
        if (!ensureShizuku()) return
        lifecycleScope.launch {
            binding.progress.visibility = View.VISIBLE
            val result = block()
            binding.progress.visibility = View.GONE
            if (result.isSuccess) {
                snack("$label ✓")
            } else {
                snack("$label failed: ${result.output}")
            }
        }
    }

    private fun ensureShizuku(): Boolean {
        if (!ShizukuHelper.isAvailable()) {
            toast(getString(R.string.shizuku_not_running))
            return false
        }
        if (!ShizukuHelper.hasPermission()) {
            ShizukuHelper.requestPermission()
            toast("Please grant Shizuku permission")
            return false
        }
        return true
    }

    private fun updateShizukuStatus() {
        val available = ShizukuHelper.isAvailable()
        val granted = ShizukuHelper.hasPermission()
        binding.tvShizukuStatus.text = when {
            !available -> "Shizuku: Not running"
            !granted -> "Shizuku: Running (permission needed)"
            else -> "Shizuku: Connected ✓"
        }
        binding.btnRequestShizuku.isEnabled = available && !granted
        binding.statusDot.setBackgroundResource(
            if (available && granted) R.drawable.dot_green else R.drawable.dot_red
        )
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun snack(msg: String) =
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_LONG).show()
}
