---
name: Pro Gaming Utility
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#bcc9cd'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#869397'
  outline-variant: '#3d494c'
  surface-tint: '#4cd7f6'
  primary: '#4cd7f6'
  on-primary: '#003640'
  primary-container: '#06b6d4'
  on-primary-container: '#00424f'
  inverse-primary: '#00687a'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#bec6e0'
  on-tertiary: '#283044'
  tertiary-container: '#9ea6bf'
  on-tertiary-container: '#343c50'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#acedff'
  primary-fixed-dim: '#4cd7f6'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5c'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  headline-xl:
    fontFamily: Orbitron
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: 0.05em
  headline-lg:
    fontFamily: Orbitron
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0.03em
  headline-md:
    fontFamily: Orbitron
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.05em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-performance gaming aesthetic tailored for an advanced touch mapping and game management mobile app. The brand personality is precise, immersive, and uncompromisingly modern. 

The design style merges **Glassmorphism** and **High-Contrast / Bold** aesthetics. It utilizes deep slate and charcoal surfaces layered with frosted translucency, cutting-edge neon accents, and glowing status indicators to evoke a professional-grade gaming hardware feel. The interface prioritizes instant visual feedback, high scannability in low-light environments, and an immersive, futuristic atmosphere.

## Colors

The color palette is built on deep, light-absorbing darks paired with hyper-vibrant neon accents to establish absolute contrast and hierarchy.

- **Primary (`#06b6d4` - Electric Cyan):** Used for primary interactive states, active touch-mapping nodes, and high-priority action cues.
- **Secondary (`#8b5cf6` - Neon Violet):** Applied to secondary highlights, game profile tags, and energetic gradient transitions.
- **Tertiary (`#0f172a` & `#1e293b` - Deep Slate / Charcoal):** Form the foundational surface layers and elevated card containers.
- **Neutrals (`#94a3b8` to `#f8fafc`):** Ranging from cool grays for secondary text to crisp white for primary headers, ensuring maximum legibility.

## Typography

The typography system pairs geometric, futuristic display headlines with ultra-clean sans-serif body copy and technical monospaced labels. This combination reinforces the gaming hardware narrative while maintaining pristine legibility for dense configuration menus and touch-mapping coordinates.

Sizes exceeding 32px adapt dynamically on mobile viewports to prevent overflow within compact device frames.

## Layout & Spacing

The layout relies on a responsive fluid grid optimized for mobile game management interfaces, utilizing a 12-column structure with 16px gutters and 16px outer canvas margins. 

Component density is tuned for touch accuracy. Spacing scale tokens (`space-xs` through `space-xl`) maintain strict proportional rhythms between mapping nodes, toolbars, and card layouts across all mobile form factors.

## Elevation & Depth

Depth is communicated through a fusion of frosted glassmorphism, low-opacity backdrop blurs, and chromatic ambient shadows. 

Surfaces utilize translucent slate fills (`#1e293b` at 70% opacity) combined with 12px backdrop blurs and subtle 1px "ghost borders" tinted in electric cyan or neon violet. Elevated interactive elements cast diffused, low-opacity colored glows rather than harsh black drop shadows, reinforcing the high-performance gaming atmosphere.

## Shapes

The shape language employs a precise, engineered aesthetic (`1` - Soft, leaning toward technical chamfers). 

UI elements feature restrained corner radii (0.25rem for micro-components, 0.5rem for standard cards, and 0.75rem for primary containers). This subtle softening prevents the interface from feeling overly sharp while maintaining the geometric precision required for tactile mapping grids and HUD overlays.

## Components

- **Buttons:** High-impact components featuring solid electric cyan or neon violet backgrounds with subtle outer glows, or ghost variants with crisp 1px borders. Active states trigger an immediate scale-down and intensified glow.
- **Chips:** Compact, pill-shaped or softly rounded tags used for game profiles and mapping presets, featuring monospaced text and low-opacity accent backgrounds.
- **Lists:** Structured rows featuring frosted glass backgrounds, high-contrast primary text, and trailing status indicators or toggle switches.
- **Checkboxes & Radio Buttons:** Custom geometric indicators with glowing accent fills and precise inner check/dot markers for active configurations.
- **Input Fields:** Dark slate containers with 1px translucent borders that shift to electric cyan on focus, paired with monospaced text for coordinate and macro inputs.
- **Cards:** Frosted glass containers (`#1e293b`/70% opacity) featuring subtle 1px gradient borders, housing game management modules, profile switchers, and touch-mapping HUD previews.
- **Status Indicators:** Pulsing glowing dots (cyan for online/active, violet for syncing, red/amber for latency alerts) providing real-time telemetry.
- **Joystick / Touch Mapping Nodes:** Circular, semi-transparent draggable targets with crosshair markers and active perimeter glows for precision touch emulation.