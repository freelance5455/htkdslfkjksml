FRONTLINE: Phoenix Island  -  Release v1.0
==========================================
3D battle royale (100 players) + zombie survival. Runs in the browser, no install needed.

HOW TO RUN
1. Unzip this folder.
2. Open index.html in Chrome / Edge / Safari (double-click).
   Internet is required the first time (three.js and fonts load from CDN).
3. Android / iPhone: host the folder on any static web server (or GitHub Pages),
   open it in the browser and choose "Add to Home screen" to install it as an app.
4. Rotate the phone to landscape.

CONTROLS (touch)
  Left half  = move (floating joystick)     Right half = look
  FIRE / JUMP / CROUCH / RELOAD / AIM / GRENADE / SMOKE / USE (pick up, enter vehicle)
  VIEW = first/third person     BAG = backpack (equip, use, drop)
  Tap the weapon name = switch weapon     II = pause (language, leave match)
Keyboard: WASD, Space, C, R, G, F, Q

FILES
  index.html            the game
  manifest.webmanifest  PWA manifest (installable app)
  sw.js                 offline cache
  icon.svg              app icon
  cover-art.svg         key art

Languages: English / Persian / Arabic (LANGUAGE button in lobby and pause menu).
