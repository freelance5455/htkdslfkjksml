package com.altaris.audio;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONObject;
import org.json.JSONArray;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Altaris Audio Android: native audio, private offline library, lightweight NAS API client. */
public class MainActivity extends Activity {
    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Object indexLock = new Object();
    private SharedPreferences prefs;
    private MediaPlayer player;
    private String playingKey = "";
    private boolean prepared = false;
    private String base = "", cookie = "";
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            try {
                if (player != null && prepared) {
                    JSONObject event = new JSONObject();
                    event.put("type", "position");
                    event.put("position", player.getCurrentPosition() / 1000.0);
                    event.put("duration", player.getDuration() / 1000.0);
                    event.put("playing", player.isPlaying());
                    fire(event);
                }
            } catch (Exception ignored) {}
            ui.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(17, 18, 22));
        getWindow().setNavigationBarColor(Color.rgb(17, 18, 22));
        prefs = getSharedPreferences("altaris", Context.MODE_PRIVATE);
        base = prefs.getString("server", "");
        cookie = prefs.getString("cookie", "");
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(17, 18, 22));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Never expose native bridge to a remote web page.
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
        });
        web.addJavascriptInterface(new Api(), "Altaris");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        ui.postDelayed(ticker, 1000);
    }

    private String str(JSONObject o, String k) {return o.optString(k, "");}
    private void fire(JSONObject event) {
        String js = "window.altarisEvent(" + event.toString() + ")";
        ui.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }
    private void success(String type, Object result) {
        try {
            JSONObject e = new JSONObject();
            e.put("type", type);e.put("data", result);fire(e);
        } catch (Exception ignored) {}
    }
    private void failure(String operation, Exception e) {
        try {
            JSONObject x = new JSONObject();x.put("type", "error");x.put("operation", operation);
            x.put("message", e.getMessage() == null ? "No disponible" : e.getMessage());fire(x);
        } catch (Exception ignored) {}
    }
    private void work(String op, Runnable body) {io.execute(() -> {
        try { body.run(); } catch (RuntimeException err) { failure(op, err); }
    });}
    private String esc(String s) {try {return URLEncoder.encode(s, "UTF-8");}catch(Exception e){return "";}}

    private String safeServer(String raw) {
        String text = raw.trim().replaceAll("/+$", "");
        if (!text.matches("https?://[A-Za-z0-9.:-]+(:[0-9]{1,5})?"))
            throw new IllegalArgumentException("Introduce una URL como http://192.168.1.50:8765");
        try {
            URL url = new URL(text);
            if (url.getHost().isEmpty() || (url.getPort() > 65535))
                throw new IllegalArgumentException("Dirección inválida");
        } catch (Exception ex) {throw new IllegalArgumentException("Dirección del servidor inválida");}
        return text;
    }
    private HttpURLConnection open(String route, String method) throws IOException {
        if (base.isEmpty()) throw new IOException("Configura el servidor o abre Descargas sin conexión");
        HttpURLConnection c = (HttpURLConnection) new URL(base + route).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(6000);c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(false);
        if (!cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
        c.setRequestProperty("Accept", "application/json");
        return c;
    }
    private String readText(InputStream input) throws IOException {
        try (InputStream in=input; ByteArrayOutputStream buf=new ByteArrayOutputStream()) {
            byte[] b=new byte[4096];int n;
            while((n=in.read(b))!=-1) {
                buf.write(b,0,n);
                if(buf.size()>5_000_000) throw new IOException("Respuesta demasiado grande");
            }
            return buf.toString("UTF-8");
        }
    }
    private String response(HttpURLConnection c) throws IOException {
        try {
            int status = c.getResponseCode();
            String body = readText(status < 400 ? c.getInputStream() : c.getErrorStream());
            if (status >= 400) {
                String message = "Servidor: error " + status;
                try { message = new JSONObject(body).optString("error",message); }catch(Exception ignored){}
                throw new IOException(message);
            }
            return body;
        } finally {c.disconnect();}
    }
    private String get(String path) throws IOException {return response(open(path,"GET"));}
    private String currentPlaylistKey(int id) {return Integer.toHexString(base.hashCode())+"_playlist_"+id;}
    private String post(String path, JSONObject params) throws IOException {
        HttpURLConnection c=open(path,"POST");
        c.setDoOutput(true);c.setRequestProperty("Content-Type", "application/json");
        byte[] data = params.toString().getBytes(StandardCharsets.UTF_8);
        try(OutputStream out = c.getOutputStream()) {out.write(data);}
        return response(c);
    }
    private File indexFile() {return new File(getFilesDir(), "offline-index.json");}
    private JSONArray offlineIndex() {
        synchronized(indexLock) {
            File f = indexFile(); if(!f.isFile()) return new JSONArray();
            try {return new JSONArray(readText(new FileInputStream(f)));}
            catch (Exception e) {return new JSONArray();}
        }
    }
    private void saveIndex(JSONArray data) throws IOException {
        synchronized(indexLock) {
            File tmp=new File(getFilesDir(),"offline-index.tmp");
            try(FileOutputStream out=new FileOutputStream(tmp)) {out.write(data.toString().getBytes(StandardCharsets.UTF_8));out.getFD().sync();}
            File out=indexFile();
            if (!tmp.renameTo(out)) throw new IOException("No se pudo guardar el índice offline");
        }
    }
    private String key(long id) {return Integer.toHexString(base.hashCode())+"_"+id;}
    private JSONObject findOffline(String k) {
        JSONArray arr=offlineIndex();
        for(int i=0;i<arr.length();i++) {JSONObject o=arr.optJSONObject(i);if(o!=null&&k.equals(o.optString("key")))return o;}
        return null;
    }
    private void recordOffline(JSONObject item) throws IOException {
        JSONArray arr=offlineIndex(); JSONArray next=new JSONArray();
        for(int i=0;i<arr.length();i++) {
            JSONObject o=arr.optJSONObject(i);
            if(o!=null&&!item.optString("key").equals(o.optString("key")))next.put(o);
        }
        next.put(item);saveIndex(next);
    }
    private void download(long id, String title, String artist) throws Exception {
        String k=key(id);
        HttpURLConnection c=open("/media?id="+id,"GET");
        File dir=new File(getFilesDir(),"offline-music");
        if(!dir.exists()&&!dir.mkdirs())throw new IOException("No se pudo crear almacenamiento");
        File tmp=new File(dir,k+".tmp"); File saved;
        int count=0;long total=0;
        try {
            int status=c.getResponseCode();if(status!=200)throw new IOException("Descarga fallida: " + status);
            total=c.getContentLengthLong();
            String mime=c.getContentType();if(mime==null)mime="";
            String ext=".audio";
            if(mime.startsWith("audio/mpeg"))ext=".mp3";
            else if(mime.startsWith("audio/flac"))ext=".flac";
            else if(mime.startsWith("audio/mp4"))ext=".m4a";
            else if(mime.startsWith("audio/ogg"))ext=".ogg";
            else if(mime.startsWith("audio/wav")||mime.startsWith("audio/x-wav"))ext=".wav";
            else if(mime.startsWith("audio/aac"))ext=".aac";
            saved=new File(dir,k+ext);
            try (InputStream in=c.getInputStream();FileOutputStream out=new FileOutputStream(tmp)) {
                byte[] buffer=new byte[32768];int n;
                while((n=in.read(buffer))!=-1) {
                    count+=n;
                    if(count>400_000_000)throw new IOException("Archivo demasiado grande");
                    out.write(buffer,0,n);
                }
                out.getFD().sync();
            }
            if(total>0&&count!=total)throw new IOException("Descarga incompleta");
            if(!tmp.renameTo(saved))throw new IOException("No se pudo guardar el archivo");
            JSONObject item=new JSONObject();item.put("key",k);item.put("id",id);
            item.put("title",title);item.put("artist",artist);item.put("file",saved.getAbsolutePath());
            item.put("bytes",count);item.put("server",base);
            try {item.put("lyrics",new JSONObject(get("/lyrics?id="+id)));}catch(Exception ignored){}
            recordOffline(item);success("downloaded",item);
        } finally {c.disconnect();tmp.delete();}
    }

    private void downloadPlaylist(int id) throws Exception {
        int offset=0, count=0;
        while (count < 1000) {
            JSONArray tracks=new JSONArray(get("/playlist?id="+id+"&offset="+offset));
            if(tracks.length()==0) break;
            for (int i=0;i<tracks.length();i++) {
                JSONObject row=tracks.getJSONObject(i);
                download(row.getLong("id"),row.optString("title"),row.optString("artist"));
                count++;
            }
            offset+=tracks.length();
            if(tracks.length()<30) break;
        }
        JSONObject report=new JSONObject();report.put("count",count);
        success("playlistDownloaded",report);
    }
    private void playOffline(String k) {
        JSONObject record=findOffline(k);
        if(record==null)throw new IllegalArgumentException("La canción no está descargada");
        File f=new File(record.optString("file"));
        if(!f.isFile())throw new IllegalArgumentException("No se encuentra el archivo offline");
        playSource(f.getAbsolutePath(),null,record);
    }
    private void playRemote(long id, String title, String artist) {
        if(base.isEmpty()||cookie.isEmpty())throw new IllegalArgumentException("Inicia sesión en el servidor");
        JSONObject item=new JSONObject();
        try {item.put("key",key(id));item.put("id",id);item.put("title",title);item.put("artist",artist);}
        catch(Exception ignored){}
        HashMap<String,String> headers=new HashMap<>(); headers.put("Cookie",cookie);
        playSource(base+"/media?id="+id,headers,item);
    }
    private void playSource(String source, Map<String,String> headers, JSONObject item) {
        ui.post(() -> {
            try {
                if(player!=null) {player.release();player=null;}
                prepared=false;
                player=new MediaPlayer();
                player.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
                player.setOnPreparedListener(m -> {
                    prepared=true; m.start();success("playing",item);
                });
                player.setOnCompletionListener(m -> {success("completed",item);});
                player.setOnErrorListener((m,what,extra)->{
                    failure("play",new Exception("No se pudo reproducir el formato o la conexión se interrumpió"));return true;
                });
                if(headers!=null)player.setDataSource(MainActivity.this, Uri.parse(source), headers);
                else player.setDataSource(source);
                playingKey=item.optString("key");
                player.prepareAsync();
            } catch(Exception e) {failure("play",e);}
        });
    }
    private void pauseOrResume() {
        ui.post(() -> {
            try {if(player!=null&&prepared){if(player.isPlaying())player.pause();else player.start();}}
            catch(Exception e){failure("toggle",e);}
        });
    }
    private void seek(int seconds) {
        ui.post(() -> {try {if(player!=null&&prepared)player.seekTo(seconds*1000);}catch(Exception ignored){}});
    }
    private void remove(String k) throws IOException {
        JSONArray arr=offlineIndex();JSONArray next=new JSONArray();
        for(int i=0;i<arr.length();i++) {
            JSONObject item=arr.optJSONObject(i);
            if(item!=null&&k.equals(item.optString("key"))) {
                new File(item.optString("file")).delete();
            } else if(item!=null)next.put(item);
        }
        saveIndex(next);
    }
    private JSONObject args(String s) {try{return new JSONObject(s);}catch(Exception e){return new JSONObject();}}

    public class Api {
        @JavascriptInterface public String snapshot() {
            JSONObject obj=new JSONObject();
            try {obj.put("server",base);obj.put("offline",offlineIndex());obj.put("hasSession",!cookie.isEmpty());
                obj.put("cachedPlaylists",new JSONArray(prefs.getString("cachedPlaylists", "[]")));}
            catch(Exception ignored){}
            return obj.toString();
        }
        @JavascriptInterface public void connect(String address,String username,String password) {
            work("connect",()->{
                try {
                    String next=safeServer(address);
                    base=next;
                    JSONObject payload=new JSONObject();payload.put("username",username);payload.put("password",password);
                    HttpURLConnection c=open("/login","POST");
                    c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);
                    try(OutputStream out=c.getOutputStream()){out.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
                    int status=c.getResponseCode();
                    if(status!=200) {String body=readText(c.getErrorStream());c.disconnect();
                        throw new IOException(new JSONObject(body).optString("error","No se pudo iniciar sesión"));}
                    String header=c.getHeaderField("Set-Cookie");c.disconnect();
                    if(header==null||!header.contains("altaris_session="))throw new IOException("El servidor no devolvió una sesión");
                    cookie=header.substring(0,header.indexOf(';'));
                    prefs.edit().putString("server",base).putString("cookie",cookie).apply();
                    success("connected",new JSONObject(get("/health")));
                }catch(Exception e){failure("connect",e);}
            });
        }
        @JavascriptInterface public void restore() {
            work("restore",()->{try{success("connected",new JSONObject(get("/state")));}
                catch(Exception e){failure("restore",e);}});
        }
        @JavascriptInterface public void listAlbum(String album,String artist,int offset) {
            work("list",()->{try{
                success("list",new JSONArray(get("/tracks?album="+esc(album)+"&artist="+esc(artist)+"&offset="+Math.max(0,offset))));
            }catch(Exception e){failure("list",e);}});
        }
        @JavascriptInterface public void lyrics(long id) {
            work("lyrics",()->{try{success("lyrics",new JSONObject(get("/lyrics?id="+id)));}
                catch(Exception e){failure("lyrics",e);}});
        }
        @JavascriptInterface public void pcStatus() {
            work("pcStatus",()->{try{success("pcStatus",new JSONObject(get("/pc-status")));}
                catch(Exception e){failure("pcStatus",e);}});
        }
        @JavascriptInterface public void list(String mode,String query,int offset) {
            work("list",()->{
                try{
                    String path=("albums".equals(mode)?"/albums":"/tracks")+"?q="+esc(query)+"&offset="+Math.max(0,offset);
                    success("list",new JSONArray(get(path)));
                }catch(Exception e){failure("list",e);}
            });
        }
        @JavascriptInterface public void playlists() {
            work("playlists",()->{try{String response=get("/playlists");prefs.edit().putString("cachedPlaylists",response).apply();success("playlists",new JSONArray(response));}catch(Exception e){failure("playlists",e);}});
        }
        @JavascriptInterface public void playlist(int id,int offset) {
            work("playlist",()->{try{
                JSONObject x=new JSONObject();x.put("id",id);String rows=get("/playlist?id="+id+"&offset="+Math.max(0,offset));
                if(offset==0)prefs.edit().putString(currentPlaylistKey(id),rows).apply();
                x.put("rows",new JSONArray(rows));
                success("playlist",x);
            }catch(Exception e){failure("playlist",e);}});
        }
        @JavascriptInterface public void cachedPlaylist(int id) {
            try {JSONObject x=new JSONObject();x.put("id",id);
                x.put("rows",new JSONArray(prefs.getString(currentPlaylistKey(id),"[]")));
                success("playlist",x);
            }catch(Exception e){failure("cachedPlaylist",e);}
        }
        @JavascriptInterface public void downloadPlaylist(int id) {
            work("downloadPlaylist",()->{try{MainActivity.this.downloadPlaylist(id);}
                catch(Exception e){failure("downloadPlaylist",e);}});
        }
        @JavascriptInterface public void action(String action,String dataJson) {
            work("action",()->{try {
                JSONObject p=new JSONObject();p.put("action",action);p.put("value",args(dataJson).opt("value"));
                success("action",new JSONObject(post("/action",p)));
            }catch(Exception e){failure("action",e);}});
        }
        @JavascriptInterface public void download(long id,String title,String artist) {
            work("download",()->{try{MainActivity.this.download(id,title,artist);}catch(Exception e){failure("download",e);}});
        }
        @JavascriptInterface public void offline() {success("offline",offlineIndex());}
        @JavascriptInterface public void remove(String key) {
            work("remove",()->{try {MainActivity.this.remove(key);success("offline",offlineIndex());}
                catch(Exception e){failure("remove",e);}});
        }
        @JavascriptInterface public void playLocal(String key) {work("play",()->{try{playOffline(key);}catch(Exception e){failure("play",e);}});}
        @JavascriptInterface public void playServer(long id,String title,String artist) {
            work("play",()->{try{playRemote(id,title,artist);}catch(Exception e){failure("play",e);}});
        }
        @JavascriptInterface public void toggle() {pauseOrResume();}
        @JavascriptInterface public void seek(int seconds) {MainActivity.this.seek(seconds);}
        @JavascriptInterface public void stop() {ui.post(()->{if(player!=null){player.release();player=null;prepared=false;}});}
    }
    @Override protected void onDestroy(){
        ui.removeCallbacks(ticker);
        io.shutdownNow();
        if(player!=null){player.release();player=null;}
        if(web!=null){web.removeJavascriptInterface("Altaris");web.destroy();web=null;}
        super.onDestroy();
    }
}
