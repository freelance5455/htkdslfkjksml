# Altaris Audio Android — proyecto APK nativo (prototipo 1.0)

Cliente Android para **Altaris Audio NAS 3.7.1** instalado en Q4OS/Debian.

## Funciones implementadas en el proyecto
- La app abre desde archivos incluidos en el APK, **sin conectarse primero a una IP**.
- Conexión a Altaris Server por dirección HTTP(S), usuario y contraseña. Conserva la sesión del servidor (no la contraseña).
- Navegación de canciones, búsqueda, álbumes y playlists.
- Reproducción en el teléfono mediante `android.media.MediaPlayer`.
- Descarga completa de música a **almacenamiento privado de Android** e índice offline persistente.
- Reproducción de canciones descargadas sin Wi-Fi, datos móviles, NAS ni inicio de sesión.
- Descarga de playlists (máximo 1000 canciones por operación).
- Letras guardadas con cada descarga, cuando el NAS dispone de ellas.
- Control opcional de Q4OS (si Altaris Desktop está abierto) a través de Altaris Server 3.7.1.

## Estado
El código Java supera una **verificación de compilación con clases Android simuladas** y el JavaScript supera el análisis de sintaxis. **No se ha producido ni probado una APK real**, porque este entorno no dispone de SDK/Build Tools ni acceso a sus descargas. Se requiere compilación real con Android Studio o GitHub Actions, e instalación de prueba en Android. No atribuir las pruebas anteriores a un emulador o dispositivo real.

## Generar APK instalable

### Android Studio (Windows, Linux, macOS)
1. Instala Android Studio y el SDK de Android 35.
2. Abre la carpeta del proyecto `altaris-audio-android`.
3. Deja sincronizar Gradle (JDK 17 y conexión a internet).
4. Menú **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. El instalador de prueba aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

### Sin Android Studio: GitHub Actions
1. Sube el contenido de la carpeta del proyecto a un repositorio GitHub.
2. Abre **Actions → Crear APK Altaris Audio → Run workflow**.
3. Descarga el artefacto `Altaris-Audio-Android-APK`. Contiene la APK de prueba.

### Línea de comandos con SDK ya instalado
`bash COMPILAR-APK.sh`

## Preparar el servidor Q4OS
- Debe tener Altaris Audio 3.7.1 instalado y activo: `systemctl --user status altaris-audio-server.service`.
- Comprueba en Q4OS: `curl http://127.0.0.1:8765/health`.
- En el teléfono, escribe una URL como `http://192.168.1.50:8765` (usa **la IP real del NAS**, no 127.0.0.1).
- Introduce el usuario y contraseña de Altaris Audio, no la contraseña de Q4OS.
- Pulsa ↓ junto a una canción para descargarla. Los archivos se guardan en el teléfono.
- Prueba activando modo avión y abriendo **Altaris Audio → Offline**.
- Los archivos offline son privados de esta app; desinstalarla los elimina. Para conservarlos fuera de la app, descarga también una copia normal del archivo musical.

## Advertencias importantes
- La conexión HTTP local no cifra las credenciales ni los archivos. Utiliza solamente redes de confianza o configura HTTPS antes de acceso externo. **No abras el puerto del NAS directamente en Internet.**
- La reproducción con pantalla apagada puede depender de la gestión de batería de Android. La versión actual aún no integra un servicio de reproducción en primer plano con notificación multimedia.
- El motor nativo admite los códecs que soporte el dispositivo; algunos FLAC/Opus pueden necesitar comprobación.
- La vista de playlists offline usa una copia de las listas consultadas anteriormente; no sincroniza nuevas ediciones realizadas sin conexión.
- Es un prototipo: antes de distribuirlo a terceros, verifica el inicio de sesión, descarga, reproducción offline, espacio disponible, batería y seguridad en un Android real.

## Tecnología
Java 17, SDK 35, Android 8+ (API 26), WebView local para la interfaz, MediaPlayer nativo, HTTP(S) directo desde Java y ficheros privados. No requiere Google Play ni aplicaciones externas para reproducir música descargada.
