#!/bin/sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo 'Necesitas Gradle 8.9 y el SDK de Android (compileSdk 35).'
  echo 'Alternativa: abre este proyecto en Android Studio y utiliza Build > Build APK(s).'
  exit 1
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  echo 'Configura ANDROID_HOME con la ruta del SDK de Android.'
  exit 1
fi
cd "$(dirname "$0")"
gradle --no-daemon :app:assembleDebug
printf '\nAPK generado: %s\n' "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
