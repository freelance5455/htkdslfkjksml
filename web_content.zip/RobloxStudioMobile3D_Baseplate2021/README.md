# Studio Mobile 3D — Baseplate 2021

Projeto inicial Android Studio (Kotlin + WebView + HTML/Three.js) com o modelo `photo-model-8426bf.glb` incluído em `app/src/main/assets/models/`.

## Recursos
- Interface vertical para celular.
- Baseplate verde quadriculada estilo sandbox.
- Carregamento do modelo GLB local.
- Adição de blocos, esferas e árvores.
- Rotação por toque, zoom e centralização da câmera.
- Cena executada dentro de um WebView Android.

## Abrir e gerar APK
1. Extraia o ZIP.
2. Abra a pasta `RobloxStudioMobile3D_Baseplate2021` no Android Studio.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35, se solicitado.
4. Para testar: **Run** no Android Studio.
5. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração normalmente ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Requisito de rede
O modelo GLB está no pacote e é carregado localmente. A biblioteca Three.js é carregada por CDN; a primeira execução requer internet. Para distribuição offline, baixe os módulos Three.js e coloque-os em `app/src/main/assets/vendor/`, atualizando o import map em `index.html`.

## Observação
Este é um projeto independente de criação 3D, inspirado em interfaces de editores sandbox. Não é um produto oficial nem afiliado à Roblox Corporation. Não contém os serviços, scripts ou funcionalidades oficiais do Roblox Studio.
