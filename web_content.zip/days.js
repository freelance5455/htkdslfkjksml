const PLACE_NPC = {
  library:'shen',student:'shen',litclub:'su',music:'su',
  gym:'lu',field:'lu',shop:'lu',
  cafe:'lin',clothes:'lin',bookstore:'su',lake:'su',hotpot:'lu',bball:'lu',
  rooftop:'rand',sakura:'rand',shrine:'rand'
};
const PLACE_FLAVOR = {
  classroom:{t:'教室里几个同学在收拾东西。张晓棠趴在桌上补作业。',s:{social:1}},
  rooftop:{t:'天台上风很大，樱花瓣吹得漫天飞。',s:{courage:1}},
  library:{t:'图书馆很安静，只有翻书声。',s:{study:2}},
  student:{t:'学生会室的门锁着。',s:{social:1}},
  litclub:{t:'文学社教室空荡荡的。',s:{study:1}},
  music:{t:'音乐教室门虚掩着，琴声停了。',s:{charm:1}},
  gym:{t:'体育馆里只有篮球撞地的回声。',s:{sport:1}},
  field:{t:'操场上有人在慢跑。',s:{sport:1}},
  shop:{t:'小卖部前挤满人。',s:{social:1}},
  canteen:{t:'食堂阿姨多给你一勺小菜。',s:{social:1}},
  cafe:{t:'咖啡店飘着烘焙香气。',s:{charm:1}},
  bookstore:{t:'书店里人不多。',s:{study:1}},
  clothes:{t:'服装店换了新一季橱窗。',s:{charm:2}},
  store:{t:'便利店关东煮冒着热气。',s:{social:1}},
  sakura:{t:'樱花步道落满花瓣。',s:{courage:1}},
  lake:{t:'湖边很安静。',s:{charm:1}},
  bball:{t:'篮球场球鞋摩擦地面。',s:{sport:2}},
  shrine:{t:'神社石阶上落了几片花瓣。',s:{courage:1}},
  hotpot:{t:'火锅店门口排着队。',s:{social:1}},
  ramen:{t:'拉面店的热气糊在玻璃上。',s:{social:1}},
  post:{t:'邮局门口有几只鸽子。',s:{courage:1}}
};

/* ---------- 主流程 ---------- */
function nextDateDay(fromDay){
  for(let d = fromDay + 1; d <= TOTAL; d++){
    if((d-1)%7 === 5) return d;   // 下一个周六
  }
  return null;
}

function dateScene(npcId){
  const n = NPC[npcId];
  const stage = favStage(G.fav[npcId]).idx;
  G.lastVisit[npcId] = G.day;

  /* 每个角色专属的场景 + 选项 */
  const DATA = {
    shen: {
      loc:'图书馆靠窗的座位',
      line:'他提前十分钟就到了。桌上摊着两本书，一本明显替你准备。',
      follow:'他讲题时偶尔停下来，看你有没有跟上。',
      choices:[
        {label:'认真听他讲完，一页不落', fav:6, tense:-3,
         memo:'周末在图书馆，他给你讲了一下午。',
         res:'讲到日落，他合上书：「……下次还有不会的，可以来问。」'},
        {label:'「其实我更喜欢你不当会长的时候」', fav:5, tense:-2,
         memo:'你说过：更喜欢他不当会长的时候。',
         res:'他沉默很久：「……我也不知道哪个才是我。」'},
        {label:'提议去别的地方走走', fav:1, tense:3,
         res:'他愣了一下：「图书馆……不是挺好的吗。」'}
      ]
    },
    lu: {
      loc:'操场边的长椅',
      line:'他刚打完球，满头是汗，冲你挥手：「来啦！陪你坐会儿。」',
      follow:'他把球抱在腿上，讲着讲着就笑起来，眼睛弯成一道。',
      choices:[
        {label:'「我陪你打两球。」', fav:6, tense:-2, stat:{sport:1},
         memo:'周末陪他打了半场球。',
         res:'他眼睛一下亮了：「真的？来！输了请喝水！」'},
        {label:'安静听他说篮球的事', fav:6, tense:-3,
         memo:'周末听他讲了很多篮球的事。',
         res:'他说到他爸不让他打球，突然安静下来。过了一会儿：「……谢谢你听我说。」'},
        {label:'「其实我觉得你不打篮球也挺好的」', fav:-1, tense:5,
         res:'他脸上的笑僵了一下：「……你也不懂。」'}
      ]
    },
    su: {
      loc:'湖边的石阶',
      line:'她抱着速写本坐在石阶上，看见你来，笑了笑，往旁边挪了一点。',
      follow:'她偶尔抬头看你一眼，然后又低头。',
      choices:[
        {label:'安静陪她坐着', fav:6, tense:-3,
         memo:'周末在湖边安静地陪了她一下午。',
         res:'临走时她把速写本合上：「……今天什么都没画。但没关系。」'},
        {label:'「你写了新的东西吗？」', fav:5, tense:-2,
         memo:'周末问过她最近写了什么。',
         res:'她犹豫了一下，翻开一页念给你听。念完耳朵红了：「……不许笑。」'},
        {label:'「其实你可以不写那些东西的」', fav:0, tense:4,
         res:'她低下头：「……可那是我唯一能留下的东西。」'}
      ]
    },
    lin: {
      loc:'咖啡店角落那张桌',
      line:'她把菜单推给你：「别点太贵的，我请。」然后自己先点了一杯美式。',
      follow:'她一边说话，一边把杯子转来转去。',
      choices:[
        {label:'让她帮你挑一杯', fav:6, tense:-3,
         memo:'周末让她帮你挑了一杯咖啡。',
         res:'她愣了半秒，然后认真地看了好久菜单：「这个。……不好喝我负责。」'},
        {label:'「你今天穿得挺好看。」', fav:5, tense:-2,
         memo:'周末夸过她今天的穿着。',
         res:'她别过脸：「……穿给你看的。」然后立刻补：「我随口说的，别当真。」'},
        {label:'一直看手机', fav:0, tense:4,
         res:'她安静下来。过了一会儿：「……是不是很无聊。」'}
      ]
    }
  };

  const d = DATA[npcId];
  choiceScene({
    icon:'💗', title:`周末 · 与 ${n.name} 的约定`, meta:d.loc,
    html:`<p class="say">${OPENING[npcId][stage]}</p>
          <p class="nar">${d.line}</p>
          <p class="nar">${d.follow}</p>`,
    choices: d.choices.map(c=>({
      label: c.label,
      fav: {[npcId]: c.fav},
      tense: c.tense ? {[npcId]: c.tense} : undefined,
      stat: c.stat,
      memo: c.memo ? {[npcId]: c.memo} : undefined,
      res: c.res
    }))
  });
}
function startGame(){ newGame(); prologue(); }
function gotoPhase(p){
  /* 进入夜晚前，若有预约且是今天，先走约会 */
  if(p === 'night' && G.flags['_date_day'] === G.day && G.flags['_date_npc']){
    const npcId = G.flags['_date_npc'];
    delete G.flags['_date_day'];
    delete G.flags['_date_npc'];
    G.phase = 'after'; renderHUD();
    dateScene(npcId);
    return;
      }
  G.phase=p; renderHUD();
  if(p==='class') classPhase();
  else if(p==='noon') noonPhase();
  else if(p==='after') afterPhase();
  else if(p==='night') nightPhase();
  else morningPhase();
}
function startDay(){
  if(!G) return;
  Object.keys(G.rival).forEach(k=>{ G.rival[k]=clamp(G.rival[k]-3,0,100); });
  Object.keys(NPC).forEach(k=>{
    if(G.snub[k] < 2 && G.fav[k] >= 60 && G.day - G.lastVisit[k] >= 2){
      G.snub[k]++;
    }
  });
  G.weather = Math.random()<0.6?'晴':(Math.random()<0.72?'阴':'雨');
  G.phase='morning'; renderHUD();
  /* BP-4 护栏：C 线 fav_shen 维持 ≤22（表3-2） */
  if(G.story && G.story.route === 'C') G.fav.shen = Math.min(G.fav.shen, 22);
  /* C 线专属日程优先（文档 5.6） */
  if(G.story && G.story.route === 'C' && cLineDay(G.day)) return;
  const special = DAY_SCRIPT[G.day];
  if(special){ special(); return; }
  morningPhase();
}
function morningPhase(){
  const w=G.weather;
  const desc = w==='晴'?'窗外樱丘市的天空泛着淡淡的光。':w==='阴'?'天色灰蒙蒙的，樱花瓣在风里打着转。':'雨点敲着窗玻璃。';
  const snubNotes = [];
  Object.keys(NPC).forEach(k=>{
    if(G.fav[k]>=60 && G.day - G.lastVisit[k] >= 2 && G.snub[k]===1){
      snubNotes.push(`<p class="nar" style="color:#c97a30;font-size:13px">· ${NPC[k].name} 最近好像有点在意你没来。</p>`);
    }
  });
  showScene({icon:'🌅',title:`第${G.day}天 · 早晨`,meta:`${weekdayOf(G.day)} · ${w} · 交换期第 ${G.day}/${TOTAL} 天`,
    html:`<p class="nar">${desc}你背上书包，站在玄关。</p><p class="nar">今天要怎么过？</p>${snubNotes.join('')}`,
    choices:[
      {label:'🎒 正常去上学',run:()=> gotoPhase('class')},
      {label:'🏃 翘课',hint:'30% 被发现：学习 -3',run: doSkip},
      {label:'📝 请假',hint:G.leave[weekIdx(G.day)]?'本周已经请过假了':'每 7 天限 1 次',run: doLeave}
    ]});
}
function doSkip(){
  if(Math.random()<0.3){
    addStat({study:-3}); renderHUD();
    showScene({icon:'😰',title:'被发现了！',
      html:`<p class="nar">王老师：「同学，现在是上课时间吧？」</p><p class="bad">学习 -3</p>`+deltas({},{study:-3}),
      choices:[{label:'回教室 ▶',run:()=> gotoPhase('class')}]});
  }else{
    showScene({icon:'🕊️',title:'难得的自由',
      html:`<p class="nar">一整个上午都没人管你。</p>`,
      choices:[
        {label:'去公园散步',hint:'勇气 +2',run:()=>{addStat({courage:2});G.selfCount++;gotoPhase('noon');}},
        {label:'去咖啡店坐坐',hint:'魅力 +2',run:()=>{addStat({charm:2});G.selfCount++;gotoPhase('noon');}}
      ]});
  }
}
function doLeave(){
  if(G.leave[weekIdx(G.day)]){
    showScene({icon:'📋',title:'请假失败',html:`<p class="nar">王老师：「这周已经请过一次假了。」</p>`,
      choices:[{label:'好吧',run:()=> gotoPhase('class')}]});
    return;
  }
  G.leave[weekIdx(G.day)]=true;
  addStat({study:2,courage:1}); G.selfCount++; renderHUD();
  showScene({icon:'🏠',title:'请假在家',
    html:`<p class="nar">你窝在家里，翻了翻课本，又睡了一觉。</p>`+deltas({},{study:2,courage:1}),
    choices:[{label:'天黑了 ▶',run:()=> gotoPhase('night')}]});
}
function classPhase(){
  const ev = pick(CLASSROOM_LINES);
  if(ev.fav) addFav(ev.fav);
  addStat(ev.s); renderHUD();
  showScene({icon:'✏️',title:'上午 · 上课',meta:`${weekdayOf(G.day)} · ${G.weather}`,
    html:`<p class="nar">${ev.t}</p>`+deltas(ev.fav||{},ev.s),
    choices:[{label:'下课铃响了 ▶',run:()=> gotoPhase('noon')}]});
}
function noonPhase(){
  openMap(a=> visitPlace(a, ()=> gotoPhase('after')), ['樱丘高中'], ()=> gotoPhase('after'));
}

  function afterPhase(){
  
  if(isWeekend(G.day)){
    openMap(a=> visitPlace(a, ()=> gotoPhase('night')),
      ['商业街','樱丘公园','校外','樱丘高中'], ()=> gotoPhase('night'));
    return;
  }
  showScene({icon:'🌆',title:'放学后',meta:`${weekdayOf(G.day)} · ${G.weather}`,
    html:`<p class="nar">放学铃响了。要留校，还是出去走走？</p>`,
    choices:[
      {label:'🏫 留在学校',run:()=> openMap(a=> visitPlace(a, ()=> gotoPhase('night')), ['樱丘高中'], ()=> gotoPhase('night'))},
      {label:'🌆 出校逛逛',run:()=> openMap(a=> visitPlace(a, ()=> gotoPhase('night')),
        ['商业街','樱丘公园','校外'], ()=> gotoPhase('night'))},
      {label:'🏠 直接回家',hint:'一个人 +1',run:()=>{
        G.selfCount++; addStat({courage:1}); renderHUD();
        showScene({icon:'🏠',title:'直接回家',html:`<p class="nar">公交车上人很少，你靠着窗坐了一路。</p>`+deltas({},{courage:1}),
          choices:[{label:'到家了 ▶',run:()=> gotoPhase('night')}]});
      }}
    ]});
}
function visitPlace(pid,onDone){
  const outdoor = ['rooftop','field','sakura','lake','bball','shrine'];
  if(G.weather==='雨' && outdoor.includes(pid)){
    showScene({icon:'🌧️',title:'下雨了',html:`<p class="nar">雨下得太大，你只好折返回室内。</p>`,
      choices:[{label:'回去 ▶',run:onDone}]});
    return;
  }
  let npc = PLACE_NPC[pid];
  if(npc==='rand'){
    const cands = Object.keys(NPC).filter(k=> getUnusedNpcEvent(k));
    npc = cands.length ? pick(cands) : null;
  }
  const chance = G.weather==='雨' ? 0.95 : 0.88;
  if(npc && Math.random()<chance){
    G.lastVisit[npc] = G.day;
    npcScene(npc,onDone);
  }else{
    const f = PLACE_FLAVOR[pid] || {t:'你在这儿待了一会儿。',s:{}};
    addStat(f.s); renderHUD();
    showScene({icon:'🌸',title:'此处',html:`<p class="nar">${f.t}</p>`+deltas({},f.s),
      choices:[{label:'离开 ▶',run:onDone}]});
  }
}
function npcScene(npcId,onDone){
  const s = getUnusedNpcEvent(npcId);
  if(!s){ onDone(); return; }
  G.flags[s.eventId]=true;
  const n = NPC[npcId];
  const stage = favStage(G.fav[npcId]).idx;
  G.flags['_present_npcs'] = [npcId];
  showScene({icon:n.emoji,title:`💗 遇见 ${n.name}`,
    meta:`${weekdayOf(G.day)} · ${G.weather} · ${n.tag}`,
    html:`<p class="say">${OPENING[npcId][stage]}</p><p class="nar">${s.text}</p>`,
    choices: s.choices.map(c=>({
      label:c.label,
      run:()=>{
        const r = favWithBonus(npcId, c.fav);
        addStat(c.stat);
        if(c.tense) addTense(c.tense);
        const mem=[];
        if(c.memo){ remember(npcId,c.memo); mem.push(c.memo); }
        renderHUD();
        const jeal = checkJealous(npcId, r.total);
        showScene({icon:n.emoji,title:n.name,
          html:`<p class="nar">${c.res}</p>` + (jeal?`<p class="jealous">${jeal}</p>`:'') + deltas({[npcId]:r.total}, c.stat, c.tense, mem),
          choices:[{label:'继续 ▶',run:onDone}]});
      }
    }))});
}
function nightPhase(){
  G.phase='night'; renderHUD();
  const top = topFav();
  const choices = [
    {label:'📖 复习功课',hint:'学习 +2',run:()=>{
      addStat({study:2}); renderHUD();
      showScene({icon:'📖',title:`第${G.day}天 · 夜晚`,html:`<p class="nar">台灯亮到很晚。</p>`+deltas({},{study:2}),
        choices:[{label:'睡觉 ▶',run: endDay}]});
    }},
    {label:'😴 早点休息',hint:'勇气 +1',run:()=>{
      addStat({courage:1}); renderHUD();
      showScene({icon:'😴',title:`第${G.day}天 · 夜晚`,html:`<p class="nar">你很快睡着了。</p>`+deltas({},{courage:1}),
        choices:[{label:'第二天 ▶',run: endDay}]});
    }}
  ];
  if(G.inviteCount < 8){
    choices.push({label:'📱 发消息约周末见面',hint:`剩 ${8-G.inviteCount} 次`,
      run:()=>{
        showScene({icon:'📱',title:'发消息',meta:'夜晚',
          html:`<p class="nar">要约谁？</p>`,
          choices: Object.keys(NPC).map(k=>({
            label:`给 ${NPC[k].name} 发消息`,
            run:()=>{
              if(G.tense[k]>=40){
                toast('对方没有回复','📱');
                showScene({icon:'📱',title:'发消息',html:`<p class="nar">消息发出去很久，没有回复。</p>`,
                  choices:[{label:'睡觉 ▶',run: endDay}]});
                return;
              }
              const dd = nextDateDay(G.day);
              if(!dd){
                showScene({icon:'📱',title:'发消息',html:`<p class="nar">对方回：「这周太忙了，下次吧。」</p>`,
                  choices:[{label:'睡觉 ▶',run: endDay}]});
                return;
              }
              G.inviteCount++;
              addFav({[k]:3}); addTense({[k]:-3});
              G.flags['_date_day'] = dd;
              G.flags['_date_npc'] = k;
              remember(k,`第${G.day}天，你约了${NPC[k].name}周末见面。`);
              renderHUD();
              showScene({icon:'📱',title:'发消息',
                html:`<p class="nar">对方很快回了：「好啊。那就第 ${dd} 天。」</p>` +
                     deltas({[k]:3},{},{[k]:-3},[`你约了${NPC[k].name}周末见面。`]),
                choices:[{label:'睡觉 ▶',run: endDay}]});
            }
          }))});
      }});
  }
  if(!G.apologyUsed){
    choices.push({label:'💬 发消息道歉',hint:'任意一人张力 -3',
      run:()=>{
        showScene({icon:'💬',title:'发消息',html:`<p class="nar">你打开聊天框，想了很久。</p>`,
          choices: Object.keys(NPC).map(k=>({
            label:`发给 ${NPC[k].name}`,
            run:()=>{
              G.apologyUsed=true; addTense({[k]:-3}); renderHUD();
              showScene({icon:'💬',title:'发消息',html:`<p class="nar">对方过了一会儿才回：「……嗯。」</p>`+deltas({},{},{[k]:-3}),
                choices:[{label:'睡觉 ▶',run: endDay}]});
            }
          }))});
      }});
  }
  showScene({icon:'🌙',title:`第${G.day}天 · 夜晚`,meta:`${weekdayOf(G.day)} · 日记`,
    html:`<p class="nar">回到家，你把今天的事记在日记本上。</p>
          <p class="nar">笔尖停顿了一下——脑海里浮现出${NPC[top].name}的脸。</p>`,
    choices});
}
function endDay(){
  G.day++;
  checkAch();
  if(G.day>TOTAL){ showEnding(); return; }
  startDay();
}

/* ---------- 通用选项场景 ---------- */
function choiceScene(cfg){
  showScene({icon:cfg.icon||'🌸',title:cfg.title,meta:cfg.meta,html:cfg.html,
    choices: cfg.choices.map(c=>({
      label:c.label, hint:c.hint,
      run:()=>{
        const favObj={}, memList=[];
        let bonusNote='';
        if(c.fav) Object.keys(c.fav).forEach(k=>{
          const r = favWithBonus(k, c.fav[k]);
          favObj[k]=r.total;
          if(r.bonus) bonusNote += `※ ${NPC[k].name} 属性加成 +${r.bonus}　`;
        });
        addStat(c.stat);
        if(c.tense) addTense(c.tense);
        if(c.memo) Object.keys(c.memo).forEach(k=>{ remember(k,c.memo[k]); memList.push(c.memo[k]); });
        if(c.secret) G.secret[c.secret]=true;
        if(c.flag) G.flags[c.flag]=true;
        if(c.self) G.selfCount++;
        renderHUD();
        if(c.after){ c.after(); return; }
        const jeal = checkJealous(Object.keys(c.fav||{})[0], Object.values(c.fav||{})[0]||0);
        showScene({icon:cfg.icon||'🌸',title:cfg.title,
          html:`<p class="nar">${c.res||'……'}</p>` +
               (bonusNote?`<p class="good">${bonusNote}</p>`:'') +
               (c.secret?`<p class="good">◆ 你看见了${NPC[c.secret].name}的「${NPC[c.secret].secretName}」。</p>`:'') +
               (jeal?`<p class="jealous">${jeal}</p>`:'') +
               deltas(favObj,c.stat,c.tense,memList),
          choices:[{label:'继续 ▶',run: c.next || (()=> gotoPhase('night'))}]});
      }
    }))});
}

/* ---------- 序幕 ---------- */
function prologue(){
  G.day=0; renderHUD();
  showScene({icon:'📦',title:'序幕 · 转校前一天',meta:'主角家 · 卧室',
    html:`<p class="nar">你坐在搬家纸箱上，窗外是樱丘市染成橘色的黄昏。</p>
          <p class="nar">你是短期交换生。${TOTAL}天后，你要回原校。</p>
          <p class="nar">桌上摊着一封没寄出去的信，是给旧朋友的。你写到一半停笔，把信纸折成飞机扔出窗外。</p>
          <p class="say">六十天，很短的。短到不需要舍不得任何人。</p>`,
    choices:[{label:'🌸 开始第1天',run:()=>{ G.day=1; renderHUD(); startDay(); }}]});
}

/* ==========================================================
   DAY_SCRIPT：60 天特殊演出
   ========================================================== */
const DAY_SCRIPT = {};

/* ==========================================================
   文档 5.6 · 隔阂线（C）专属日程
   与 A/B 共用日期的那些天，改由本表接管，保证语气是“职业礼貌”
   ========================================================== */
const C_LINE = {
  21: ()=> showScene({icon:'📖',title:'第21天 · 书店（C）',meta:'书店 · C-D21',
    html:`<p class="nar">周末在书店撞见苏念秋，她捏着征文海报犹豫，你陪她聊了很久，鼓励她报名。</p>
          <p class="nar">你没注意到，沈逸舟站在书架另一边，手里拿着一本《概率论》，看了你们一眼，转身走了。</p>`,
    choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]}),

  27: ()=> showScene({icon:'🎎',title:'第27天 · 联席会议（C）',meta:'会议室 · C-D27',
    html:`<p class="nar">文化祭排练时间谈判。会议室里沈逸舟坐主位，陆鸣撸起袖子，苏念秋捧笔记本，林小满咬着吸管。</p>
          ${castLine('shen','文化祭排练不占自习时间。这是上次定好的。','CH_SHEN')}
          ${castLine('lu','不排练怎么练？你上台替我们跳？','CH_LU')}
          <p class="nar">你坐在角落打圆场：「要不然，挪到周末？」</p>
          ${castLine('shen','时间有限，我们继续讨论排练时间表。私人情况不作为社团安排的参考。','CH_SHEN')}
          <p class="nar">他翻开下一页文件，不再看你。</p>
          <p class="bad">隔阂 +5</p>`,
    choices:[{label:'继续 ▶',run:()=>{ storyTense(5); renderHUD(); gotoPhase('night'); }}]}),

  30: ()=> showScene({icon:'📘',title:'第30天 · 走廊擦肩（C）',meta:'走廊 · C-D30',
    html:`<p class="nar">走廊上，沈逸舟和一个穿深色西装的男人擦肩而过。男人拍了拍他的肩，说了句什么，他把背挺得很直，头都没低。</p>
          <p class="nar">直到男人拐过楼梯口，他才扶着墙，闭了一下眼睛。你正好路过，和他对视。</p>
          <p class="nar">他睁开眼，瞬间恢复学生会长的标准表情。</p>
          ${castLine('shen','同学，请不要在此处逗留。','CH_SHEN')}
          <p class="nar">他从你身边走过，没有停。</p>
          <p class="bad">隔阂 +5</p>`,
    choices:[{label:'继续 ▶',run:()=>{ storyTense(5); renderHUD(); gotoPhase('night'); }}]}),

  33: ()=> showScene({icon:'📘',title:'第33天 · 学生会室（C）',meta:'学生会室 · C-D33',
    html:`<p class="nar">放学后路过学生会室，灯亮着，你想进去借支笔。</p>
          <p class="nar">推开门，沈逸舟正处理文件，头也没抬。</p>
          ${castLine('shen','学生会室仅限工作人员进入。需要物资请前往传达室。','CH_SHEN')}
          <p class="nar">他顺手把桌上一沓纸翻过去，抽屉「咔哒」锁上。你退出去，门在身后关上。</p>
          <p class="bad">隔阂 +6</p>`,
    choices:[{label:'继续 ▶',run:()=>{ storyTense(6); renderHUD(); gotoPhase('night'); }}]}),

  37: ()=> showScene({icon:'⚡',title:'第37天 · 白若曦（C）',meta:'走廊 · C-D37',
    html:`${castLine('bai','听说你最近和沈逸舟走得很近？我们以前一起补过课。你是交换生吧。六十天，够干什么？','CH_BAI')}
          <p class="nar">你抬头，看见沈逸舟抱着一摞文件站在走廊远处。他看了一眼这边，转身从另一条走廊绕走了。</p>
          <p class="nar">白若曦笑了一声，走了。你站在原地，脸一阵发烫。</p>
          <p class="bad">隔阂 +10</p>`,
    choices:[{label:'继续 ▶',run:()=>{ storyTense(10); renderHUD(); gotoPhase('night'); }}]}),

  41: ()=> showScene({icon:'🎆',title:'第41天 · 烟花大会（C）',meta:'神社 · C-D41',
    html:`<p class="nar">神社烟花大会，你和陆鸣、林小满挤在一起看烟花。</p>
          <p class="nar">烟花最响的一瞬，陆鸣凑到你耳边说了句什么，被爆炸声盖住，你笑着捶他。</p>
          <p class="nar">你没有在人群里找沈逸舟，也不知道他那天在不在神社。</p>`,
    choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]}),

  50: ()=> showScene({icon:'🌸',title:'第50天 · 第一片花瓣（C）',meta:'走廊 · C-D50',
    html:`<p class="nar">走出教学楼，低头——地上落了第一片樱花花瓣。</p>
          <p class="hud-warn" style="text-align:center">🌸 樱花开始凋零 · 剩 10 天</p>
          <p class="nar">你站在原地，抬头看见沈逸舟从走廊另一头走来。他看见你，点头算是打招呼，然后走了。</p>`,
    choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]}),

  56: ()=> showScene({icon:'💬',title:'第56天 · 最后周末（C）',meta:'拉面馆 · C-D56',
    html:`<p class="nar">陆鸣带你去了拉面馆，苏念秋给你看最后一章手稿，林小满帮你整理领口。</p>
          <p class="nar">每个人结束时都说「明天见」。</p>
          <p class="nar">你没有去学生会室，也没有想到要去。</p>`,
    choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]}),

  58: ()=> showScene({icon:'📖',title:'第58天 · 同学录（C）',meta:'教室 · C-D58',
    html:`<p class="nar">全班传同学录，你翻到沈逸舟那一页。留言字迹工整克制：</p>
          <p class="say">「祝交换生同学学业顺利，前程似锦。——沈逸舟」</p>
          <p class="nar">没有多余的话，没有画樱花。你后来知道，他给很多同学都写过几乎一样的话。</p>`,
    choices:[{label:'收好 ▶',run:()=>{ remember('shen','第五十八天，他的留言是一句标准祝福。'); renderHUD(); gotoPhase('night'); }}]}),

  59: ()=> showScene({icon:'💧',title:'第59天 · 天台（C）',meta:'天台 · C-D59',
    html:`<p class="nar">你在天台坐着，沈逸舟路过看见你，没有停，也没有放下任何东西，径直走了。</p>`,
    choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]})
};
function cLineDay(d){
  const fn = C_LINE[d];
  if(!fn) return false;
  fn();
  return true;
}

/* ---------- 第一周 · 适应期 D1–D7 ---------- */
DAY_SCRIPT[1] = ()=> choiceScene({
  icon:'🎒',title:'第1天 · 开学典礼',meta:'体育馆 → 教室',
  html:`<p class="nar">四月的樱花开得像要把整个体育馆埋掉。你站在交换生队伍最后面，听台上的学生会长念完致辞。</p>
        <p class="npcLine"><span class="npcAvatar" style="background:${NPC.shen.color}">📘</span>
          <span class="npcText"><b style="color:${NPC.shen.color}">沈逸舟</b>（台上，合上稿子）「……希望各位同学——度过一个不留遗憾的春天。」</span></p>
        <p class="nar">散场人潮里，你被人从侧面撞了一下，作业本撒了一地。</p>
        <p class="nar">你蹲下去捡，余光里看见一双白色皮鞋停在你面前半步。你抬头——是沈逸舟。他看着你怀里乱七八糟的本子，面无表情，停了大概两秒。然后他没有弯腰，也没有说话，只是把一支滚到他脚边的笔用脚尖轻轻推到你够得到的地方，转身走了。</p>
        <p class="nar"><b style="color:${NPC.lu.color}">陆鸣</b>从旁边跑过来帮你捡，<b style="color:${NPC.su.color}">苏念秋</b>蹲下来把折角的纸一页页抚平。</p>
        <p class="npcLine"><span class="npcAvatar" style="background:${NPC.lin.color}">💄</span>
          <span class="npcText"><b style="color:${NPC.lin.color}">林小满</b>（抱着胳膊站在你旁边，上下打量你两秒，伸手把你头顶一片樱花瓣弹掉）「新面孔啊。哪个学校来的？」</span></p>`,
  choices:[
    {label:'A 把笔捡起来，记住那只白色皮鞋', fav:{shen:6}, stat:{study:1}, flag:'f_met_shen',
     memo:{shen:'第一天，你捡起了他推给你的那支笔。'},
     res:'他停下脚步，看了一眼你手里那支笔，又看了你一眼：「教务处。三楼左转。」顿了顿，「……先把东西整理好。」'},
    {label:'B 塞回笔袋，抱本子回教室', fav:{lu:2}, stat:{sport:1}, flag:'f_met_lu',
     memo:{lu:'第一天，你接过他帮你捡的本子。'},
     res:'陆鸣咧嘴笑：「小事！你是新来的吧？」——你没有追上去，他只是开学典礼上一个声音好听的陌生人。'},
    {label:'把捡好的本子递给苏念秋',fav:{su:2},stat:{social:1},flag:'f_met_su',
     memo:{su:'第一天，你把本子递给了她。'},res:'她笑得眼睛弯弯：「折角我帮你抚平了。」'},
    {label:'夸林小满的口红色号',fav:{lin:2},stat:{charm:1},flag:'f_met_lin',
     memo:{lin:'第一天，你夸了她的口红。'},res:'她一愣：「算你有眼光。……这颜色很老了，买不到第二支了。」'},
    {label:'低头不说话，自己先捡完',self:true,stat:{social:2},
     memo:{shen:'第一天，你先自己把东西收拾干净。'},res:'等本子整理好，人已经散了。'}
  ]
});

DAY_SCRIPT[2] = ()=> choiceScene({
  icon:'💬',title:'第2天 · 张晓棠情报局',meta:'教室',
  html:`<p class="npcLine"><span class="npcAvatar" style="background:#c78ba1">💬</span>
          <span class="npcText"><b style="color:#c78ba1">张晓棠</b>「沈逸舟——给晕倒学妹贴膏药时手都在抖。陆鸣——初中有一年没来学校，护腕不离手。苏念秋——抽屉里全是稿纸。林小满——我怀疑她在网上写东西。」</span></p>`,
  choices:[
    {label:'分别记下四个人',stat:{social:1},
     after:()=>{
       ['shen','lu','su','lin'].forEach(k=> G.flags['f_hint_'+k]=true);
       renderHUD();
       showScene({icon:'💬',title:'情报',html:`<p class="nar">四个名字，四道藏在表面之下的裂缝。</p><p class="good">◆ 获得四人的违和感线索。</p>`,
         choices:[{label:'继续 ▶',run:()=> gotoPhase('class')}]});
     }},
    {label:'「你怎么知道这么多？」',stat:{social:2},flag:'tc_gossip',
     memo:{shen:'你问张晓棠：你怎么知道这么多。'},res:'她愣了一下：「因为没人跟我说。」'}
  ]
});

DAY_SCRIPT[3] = ()=> choiceScene({
  icon:'🌤️',title:'第3天 · 天台初遇',meta:'天台',
  html:`<p class="nar">周三午休，你鬼使神差推开了那扇一直锁着的天台铁门。"吱呀"一声，在空荡的天台上格外响。</p>
        <p class="nar">沈逸舟一个人站在栏杆边，背对着你，手里捧着一本书。</p>
        <p class="say">「这里不是谁都能来的。」他没回头。</p>
        <p class="nar">你站在门口，进也不是，退也不是。风把他手里那页书吹得哗哗响。沉默了大概三秒——那三秒长得像一个学期。</p>
        <p class="nar">他终于回头。看见是你，他顿了顿，语气淡下来。</p>
        <p class="say">「……是你。既然已经来了，就别大声说话。」</p>
        <p class="nar">他转回去继续背书。你瞥见他摊开的书里夹着一张被撕掉一半的纸，只看得见"……退会申请书"四个字。</p>`,
  choices:[
    {label:'A 道歉离开',fav:{shen:0},tense:{shen:4},res:'他没有拦你。但你走后，那页书他很久没翻过去。'},
    {label:'B 道歉后仍留在两步外，不出声',fav:{shen:7},stat:{courage:8},tense:{shen:-4},
     flag:'shen_rooftop_silent',memo:{shen:'第三天，你陪他在天台上站过。'},
     res:'风把他的制服衣角吹起来，他攥着书的手指节有点发白。那之后的十分钟，他背书的语速，慢了一半。<br><br>他忽然说：「这里人少，安静。」——这是他第一次允许别人，待在他的天台。'},
    {label:'「你书里夹的是什么？」',fav:{shen:3},tense:{shen:3},
     res:'他飞快合上书：「没什么。」<br><br>但他没有立刻走。他站了两秒，然后说：「……你问这个干嘛。」'}
  ]
});

DAY_SCRIPT[4] = ()=> {
  const opts = [
    {label:'📋 学生会室（沈逸舟）',fav:{shen:2},stat:{study:2},flag:'f_club_student',
     res:'沈逸舟：「欢迎。填个表就行，别多问。」顿了顿，「……你字写得比开学那天好看。」'},
    {label:'🏀 体育馆（陆鸣）',fav:{lu:4},stat:{sport:2},flag:'f_club_gym',
     res:'陆鸣：「来打两球？输了请喝水！」'},
    {label:'📖 文学社（苏念秋）',fav:{su:4},stat:{charm:1},flag:'f_club_lit',
     res:'苏念秋念："樱花落尽之前，我想把名字写进某个人的春天里——"'},
    {label:'☕ 咖啡店（林小满）',fav:{lin:4},stat:{social:1},flag:'f_club_cafe',
     res:'林小满挑眉：「点单吗？……不过你要是想坐，也行。我请。」'},
    {label:'🌤️ 去天台一个人待着',self:true,stat:{courage:3},res:'天台上只有你一个人。'}
  ];
  showScene({icon:'🏫',title:'第4天 · 社团体验',meta:'放学后',
    html:`<p class="nar">四扇门，四种声音。你只能选一个。</p>`,
    choices: opts.map(c=>({
      label:c.label,
      run:()=>{
        const favObj={};
        if(c.fav) Object.keys(c.fav).forEach(k=>{
          const r = favWithBonus(k, c.fav[k]); favObj[k]=r.total;
        });
        addStat(c.stat);
        if(c.flag) G.flags[c.flag]=true;
        if(c.self) G.selfCount++;
        renderHUD();
        showScene({icon:'🏫',title:'第4天 · 社团体验',
          html:`<p class="nar">${c.res}</p>`+deltas(favObj,c.stat),
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }
    }))});
};

DAY_SCRIPT[5] = ()=> choiceScene({
  icon:'📝',title:'第5天 · 第一周总结',meta:'食堂',
  html:`<p class="say">「一周了。四个人里，谁最有意思？只能说一个。」</p>`,
  choices:[
    {label:'写「沈逸舟」',fav:{shen:2},flag:'f_first_like',memo:{shen:'第一周你写了沈逸舟。'},res:'张晓棠挑眉。'},
    {label:'写「陆鸣」',fav:{lu:5},flag:'f_first_like',memo:{lu:'第一周你写了陆鸣。'},res:'张晓棠笑得一脸了然。'},
    {label:'写「苏念秋」',fav:{su:0},flag:'f_first_like',memo:{su:'第一周你写了苏念秋。'},res:'张晓棠歪头。'},
    {label:'写「林小满」',fav:{lin:0},flag:'f_first_like',memo:{lin:'第一周你写了林小满。'},res:'张晓棠瞪大眼。'},
    {label:'还没想好',stat:{social:3},self:true,res:'「慢慢来。六十天呢。」'}
  ]
});

DAY_SCRIPT[6] = ()=> showScene({
  icon:'🏪',title:'第6天 · 便利店偶遇',meta:'周六',
  html:`<p class="nar">陆鸣一个人站在冷柜前买可乐。他左手腕缠着磨得发白的旧护腕，右手却空空的。</p>
        <p class="nar">他盯着可乐罐子看了两秒，轻轻用左手捏了捏手腕。</p>
        <p class="nar">林小满在另一边挑针管笔，没化妆，压得很低的帽檐。</p>`,
  choices:[{label:'记下（记忆：护腕）',run:()=>{
    remember('lu','第六天，你看见他捏了捏左手腕上的旧护腕。');
    remember('lin','第六天，你在便利店看见她没化妆的样子。');
    renderHUD(); gotoPhase('night');
  }}]
});

DAY_SCRIPT[7] = ()=>{
  const id = topFav();
  const n = NPC[id];
  const texts = {
    shen:{scene:'书店',t:'沈逸舟：「你也喜欢这本书？……很少有人翻到这一本。」'},
    lu:{scene:'操场边',t:'陆鸣：「你真来看我打球？行，今天我给你投十个三分。」'},
    su:{scene:'湖边长椅',t:'苏念秋：「风很好。你愿意陪我坐一会儿吗？」'},
    lin:{scene:'咖啡店',t:'林小满：「坐吧，别点太贵的，我请。」'}
  };
  const d = texts[id];
  choiceScene({
    icon:n.emoji,title:'第7天 · 第一次校外相处',meta:d.scene,
    html:`<p class="nar">${d.t}</p>`,
    choices:[
      {label:'认真陪 / 认真听',fav:{[id]:8},memo:{[id]:`第七天，你认真陪了${n.name}。`},
       res:'时间过得很快。你们谁都没提回去。'},
      {label:'心不在焉看手机',tense:{[id]:5},res:'对方忽然安静下来。你抬起头。'},
      {label:'临时说「我有事」要走',tense:{[id]:5},flag:'f_flake',
       memo:{[id]:`第七天，你临时放了他/她的鸽子。`},res:'他/她愣了一下：「哦。……好。」'}
    ]
  });
};

/* ---------- 第二周 · 靠近 D8–D14 ---------- */
DAY_SCRIPT[8] = ()=> choiceScene({
  icon:'📝',title:'第8天 · 粉色便利贴（CM-D08）',meta:'教室',
  html:`<p class="nar">周一早读，你在座位上发现一张粉色便利贴，压在铅笔盒底下，极工整克制的字迹写着：</p>
        <p class="say">「我不想当会长了。」</p>
        <p class="nar">那字迹和沈逸舟黑板上的板书，一笔一画都一样。</p>`,
  choices:[
    {label:'A 折好收进笔袋最里层', fav:{shen:5}, flag:'shen_letter_seen',
     memo:{shen:'第八天，你把那张便利贴折好收进了笔袋。'},
     res:'你把便利贴折好，收进笔袋最里层，然后环顾教室。他坐在靠窗的位置低头翻课本，像什么都不知道。'},
    {label:'B 觉得是别人的私事，随手夹进课本', fav:{shen:-2},
     res:'你觉得这是别人的私事，随手夹进课本，再没拿出来。'}
  ]
});

DAY_SCRIPT[9] = ()=> showScene({
  icon:'💄',title:'第9天 · 咖啡店锁屏',meta:'放学后',
  html:`<p class="nar">林小满看见你立刻锁屏，耳朵红了。</p><p class="say">「看什么看，工作消息。」</p>`,
  choices:[{label:'心里记下（记忆：博客后台）',run:()=>{
    remember('lin','第九天，你看见她在敲一个排版页面。');
    renderHUD(); gotoPhase('night');
  }}]
});

DAY_SCRIPT[10] = ()=> showScene({
  icon:'📖',title:'第10天 · 烧稿纸',meta:'文学社门口',
  html:`<p class="nar">苏念秋蹲在地上烧一小片纸，看见你慌忙踩灭。</p>
        <p class="say">「烧错了一页。写坏了的东西，留着也没用。」</p>`,
  choices:[{label:'记下（记忆：烧稿纸）',run:()=>{
    remember('su','第十天，你看见她在走廊烧了一小片纸。');
    renderHUD(); gotoPhase('night');
  }}]
});

DAY_SCRIPT[11] = ()=> choiceScene({
  icon:'💄',title:'第11天 · 包散落·旧口红',meta:'教室',
  html:`<p class="nar">林小满的包被椅子挂倒，东西散了一地。她扑过去抢，先把一本手绘花卉封面的小笔记本压住了。</p>
        <p class="nar">你捡起最后一件——一支膏体只剩短短一截、壳子磨得发亮的旧口红。</p>
        <p class="say">「……给我。我妈给我的。不是新的。是她的。」</p>`,
  choices:[
    {label:'轻轻递给她',fav:{lin:6},tense:{lin:-4},memo:{lin:'第十一天，你捡到了她妈妈的那支口红。'},res:'她把口红放回包里，位置很小心。'},
    {label:'「很好看。」',fav:{lin:5},memo:{lin:'第十一天，你说那支口红很好看。'},res:'她愣了一下，然后说：「……行了。别一副要哭的样子。」'},
    {label:'想打开看看',fav:{lin:-2},tense:{lin:6},res:'她一把抢过去：「别动。」'}
  ]
});

DAY_SCRIPT[12] = ()=>{
  G.flags['_present_npcs'] = ['shen','lu'];
  choiceScene({
    icon:'⚡',title:'第12天 · 天台撞见',meta:'天台',
    html:`<p class="nar">你推开门，沈逸舟和陆鸣正僵着。</p>
          <p class="npcLine"><span class="npcAvatar" style="background:${NPC.lu.color}">🏀</span>
            <span class="npcText"><b style="color:${NPC.lu.color}">陆鸣</b>「你凭什么？学生会室是你一个人的？」</span></p>
          <p class="npcLine"><span class="npcAvatar" style="background:${NPC.shen.color}">📘</span>
            <span class="npcText"><b style="color:${NPC.shen.color}">沈逸舟</b>「排练占了自习时间。这是规矩。」</span></p>
          <p class="nar">林小满坐在角落，戴着耳机，但线没插——她在听。</p>`,
    choices:[
      {label:'A 站沈逸舟：先把时间安排谈清楚',fav:{shen:6},stat:{courage:10},tense:{shen:-2},
       memo:{shen:'第十二天，你当众站在他这边。',lu:'第十二天，你站到了他对面。'},
       res:'陆鸣："行吧，反正你永远站他那边。"'},
      {label:'C 站陆鸣：排练也是活动需要',fav:{shen:-3,lu:4},tense:{shen:6},
       memo:{lu:'第十二天，你当众站在他这边。',shen:'第十二天，你站到了他对面。'},
       res:'沈逸舟沉默："我明白了，你的判断优先于规则。"'},
      {label:'B 中立劝和，让两人坐下来谈',fav:{shen:3},stat:{courage:12,social:1},res:'两人对视一眼。'},
      {label:'D 沉默，带上门退出',fav:{shen:-4},tense:{shen:8},self:true,stat:{courage:0},res:'你默默关上门。'}
    ]
  });
};

DAY_SCRIPT[13] = ()=> showScene({
  icon:'🏀',title:'第13天 · 操场加练/商场',meta:'操场 · 傍晚',
  html:`<p class="nar">陆鸣一个人在罚球线反复投篮。他忽然冲你藏身方向喊：「别躲了！都看我投了二十分钟了！上来，我教你罚球。」</p>`,
  choices:[{label:'走过去',run:()=>{
    addFav({lu:5}); addStat({sport:2});
    G.lastVisit['lu']=G.day;
    remember('lu','第十三天，他在操场教你罚球。');
    renderHUD(); gotoPhase('night');
  }}]
});

/* ===== D14 · BP-1 分线判定（文档 CM-D14）===== */
DAY_SCRIPT[14] = ()=> {
  const dual = (G.fav.shen >= DUAL_AFFINITY && G.fav.lu >= DUAL_AFFINITY);
  showScene({
    icon:'📝',title:'第14天 · 两周总结与分线判定',meta:'食堂 · BP-1',
    html:(dual?castLine('zhang','你两边都靠近了。想清楚再来写，别到最后两个人都得罪。'):'') +
      `<p class="nar">食堂里，张晓棠把四张空白纸条推到你面前。</p>
       <p class="say">「两周了。你心里有个数吗？想清楚再选。」</p>
       <p class="nar">你握着笔想了想。这一笔决定接下来四十六天走哪条路。</p>
       <p class="nar"><em>沈逸舟 ${G.fav.shen}　·　分线门槛 ${FAV_SPLIT}　·　陆鸣 ${G.fav.lu}　·　勇气 ${G.story.courage}</em></p>`,
    choices:[
      {label:'写「沈逸舟」', hint:`沈 ${G.fav.shen} / 门槛 ${FAV_SPLIT}`, run:()=>{
        storyFav('shen',4);
        const to = bp1('SHEN');
        renderHUD();
        const ok = (to === 'HB');
        showScene({icon:'📝',title: ok?'分线 · 好感线（P2）':'分线 · 隔阂线（P6）',
          html:(ok
            ? `<p class="nar">你在纸条上写下「沈逸舟」三个字。</p>
               <p class="good">◆ BP-1 成立：phase = P2，fav_shen 保留 ${G.fav.shen}</p>
               <p class="nar">张晓棠看了一眼，把纸条收走了。</p>`
            : `<p class="nar">你在纸条上写下「沈逸舟」三个字。</p>
               <p class="bad">◆ BP-1 未达 ${FAV_SPLIT}：落入隔阂线，fav_shen 钳制 22、tense 置 62</p>
               <p class="nar">张晓棠看了一眼，没有多问，把纸条折好收了。</p>`),
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }},
      {label:'写「陆鸣」', hint:'直接进入隔阂线（P6）', run:()=>{
        storyFav('lu',4);
        bp1('LU');
        renderHUD();
        showScene({icon:'📝',title:'分线 · 隔阂线（P6）',
          html:`<p class="nar">你写下「陆鸣」。张晓棠看着你，欲言又止，最后叹了一口气。</p>
                <p class="bad">◆ BP-1：隔阂线　fav_shen 钳制 22 · tense 62 · secret_shen = false</p>`,
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }}
    ]});
};

/* ---------- 第三周 · 深入 D15–D21 ---------- */
DAY_SCRIPT[15] = ()=>{
  /* C 线走流程性拒绝（C-D15），好感线才走讲题版（HB-D15） */
  if(G.story.route === 'C' || G.fav.shen < FAV_SPLIT){
    showScene({icon:'📚',title:'第15天 · 图书馆（流程性拒绝）',meta:'图书馆 · C-D15',
      html:`<p class="nar">你对着一道辅助线题皱了十分钟眉。沈逸舟坐在斜前方两排，你犹豫着走过去想请教。</p>
            <p class="nar">刚到桌边，他就合上书起身。</p>
            ${castLine('shen','不好意思，我要去学生会室处理公务。学习委员在三楼自习室，你可以向她求助。','CH_SHEN')}
            <p class="nar">他点头道别，没有看你手里的草稿纸，也没有停顿——只是学生会长对不熟同学的标准答复。</p>`,
      choices:[{label:'回座位 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  const choices = [
    {label:'追上去道谢',fav:{shen:6},flag:'shen_apology_crossed',
     memo:{shen:'第十五天，那页被划掉的“对不起”。'},
     res:'他脚步没停：「不用。」但走远了之后，脚步慢了。'},
    {label:'「你其实人挺好」',fav:{shen:4},res:'他脚步顿了一下，没回头。但你看见他耳朵尖红了。'},
    {label:'「下次还能问吗」',fav:{shen:6},tense:{shen:-3},
     memo:{shen:'第十五天，你问他能不能再教你。'},res:'「……随你。」'}
  ];
  if(G.story.courage>=20){
    choices.push({label:'「你为什么不拒绝别人？」',fav:{shen:7},tense:{shen:4},
      flag:'shen_why_no_refuse',memo:{shen:'第十五天，你问他：你为什么不拒绝别人。'},
      res:'他沉默很久，粉笔停在半空。<br><br>"因为拒绝了……我就不知道自己还剩什么了。"'});
  }
  choiceScene({icon:'📚',title:'第15天 · 图书馆讲题（HB-D15）',meta:'图书馆',
    html:`<p class="nar">周一午休，你对着一道辅助线题皱了十分钟眉。身边忽然投下一片影子。沈逸舟不知什么时候蹲到你桌边。</p>
          <p class="nar">五分钟，粉笔在你草稿纸上"唰唰"画出三条线，答案就出来了。</p>
          <p class="say">「不是我特意教你，是你吵到我了。」</p>
          <p class="nar">他把写满笔记的那页纸撕下来留给你，自己先一步走了。</p>
          <p class="nar">你低头看——笔记最后一行原本写着"对不起"三个字，又被人用笔重重划掉了，墨团把纸都戳破了。你捏着那页纸，在图书馆坐了很久。</p>`,
    choices});
};

DAY_SCRIPT[16] = ()=> showScene({
  icon:'💄',title:'第16天 · 天台补妆',meta:'天台',
  html:`<p class="nar">林小满对着小镜子补眼线。你一推门，她吓得镜子差点掉了。</p>
        <p class="say">「我不是在哭，我是在补眼线！眼线！……风太大，吹的。不许笑。」</p>`,
  choices:[{label:'什么都没问',run:()=>{
    addFav({lin:3}); addTense({lin:-3});
    G.lastVisit['lin']=G.day;
    remember('lin','第十六天，你在天台上撞见她补眼线。');
    renderHUD(); gotoPhase('night');
  }}]
});

DAY_SCRIPT[17] = ()=>{
  /* HB-D17 摇摆事件：fav_lu ≥ 15 且 fav_shen ≥ 15 才触发 */
  if(!(G.fav.lu >= DUAL_AFFINITY && G.fav.shen >= DUAL_AFFINITY)){
    showScene({icon:'🏆',title:'第17天 · 运动会',meta:'操场',
      html:`<p class="nar">全校运动会。操场很热闹，你站在人群外看完了比赛。</p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  G.flags['_present_npcs'] = ['shen','lu','su','lin'];
  choiceScene({
    icon:'🏆',title:'第17天 · 运动会',meta:'操场',
    html:`<p class="nar">全校运动会。</p>
          <p class="npcLine"><span class="npcAvatar" style="background:${NPC.lu.color}">🏀</span>
            <span class="npcText"><b style="color:${NPC.lu.color}">陆鸣</b>「喂，看到没！我刚才是不是超帅！」</span></p>
          <p class="npcLine"><span class="npcAvatar" style="background:${NPC.lin.color}">💄</span>
            <span class="npcText"><b style="color:${NPC.lin.color}">林小满</b>（手抖把水洒了自己一身）「谁、谁让他跑这么快的！」</span></p>
          <p class="npcLine"><span class="npcAvatar" style="background:${NPC.su.color}">📖</span>
            <span class="npcText"><b style="color:${NPC.su.color}">苏念秋</b>（广播里念错一句诗）「……抱歉，下一则。」</span></p>
          <p class="nar">纪律组老师想记陆鸣，沈逸舟不动声色往前半步，挡了老师一眼。</p>`,
    choices:[
      {label:'终点给陆加油',fav:{lu:3},stat:{sport:2},tense:{lu:-5},memo:{lu:'第十七天，你在终点给他递毛巾。'},res:'他接过毛巾，笑得眼睛都弯了。'},
      {label:'啦啦队帮林',fav:{lin:8},stat:{charm:2},tense:{lin:-5},memo:{lin:'第十七天，你帮她举了花球。'},res:'她别过脸：「……手别抖。」'},
      {label:'广播站找苏',fav:{su:8},stat:{study:2},tense:{su:-5},memo:{su:'第十七天，你去了广播站。'},res:'她把稿子分你一半："一起念吧。"'},
      {label:'纪律组帮沈',fav:{shen:3},stat:{social:3},tense:{shen:-5},memo:{shen:'第十七天，你帮他扶了纪律旗。'},res:'他低声说了句"辛苦"。'},
      {label:'都想去哪边都没赶上',fav:{shen:2,lu:2,su:2,lin:2},stat:{social:2},res:'第二天上课你睡了一节。'}
    ]
  });
};

DAY_SCRIPT[18] = ()=> showScene({
  icon:'🎹',title:'第18天 · 音乐教室',meta:'放学后',
  html:`<p class="nar">苏念秋坐在钢琴前，手指停在琴键上。</p>
        <p class="say">「自己随便写的。别录。……你觉得，写到一半的东西，该写完吗？」</p>`,
  choices:[{label:'记下她的问题',run:()=>{
    remember('su','第十八天，她问你：写到一半的东西，该写完吗。');
    addFav({su:4}); G.lastVisit['su']=G.day; renderHUD(); gotoPhase('night');
  }}]
});

DAY_SCRIPT[19] = ()=>{
  G.flags['_present_npcs'] = ['shen'];
  showScene({icon:'📘',title:'第19天 · 楼梯拐角',meta:'楼梯口',
    html:`<p class="nar">周四放学，你上楼，看见沈逸舟站在你教室门口，背对着你，像在犹豫要不要敲门。听见你的脚步声，他猛地转身走掉了，连一句"路过"都没解释。</p>
          <p class="nar">你站在楼梯口，看见他走掉的那个方向，是学生会室。</p>`,
    choices:[
      {label:'追过去', run:()=>{
        addFav({shen:5}); addTense({shen:-3}); addStat({courage:3});
        remember('shen','第十九天，你在楼梯口追上了他。');
        G.lastVisit['shen']=G.day; renderHUD();
        showScene({icon:'📘',title:'学生会室门口',
          html:`<p class="nar">他站在学生会室门口，手握着门把，却没有推开。听到你的脚步，他侧过身，没有让开，也没有关上门。</p>
                <p class="say">「……你怎么在这里。」</p>
                <p class="nar">你看出来：他等的不是门，是某个敢敲它的人。</p>` +
               deltas({shen:6},{courage:1},{shen:-3},['第十九天，你在楼梯口追上了他。']),
          choices:[
            {label:'「我陪你进去。」', run:()=>{
              addFav({shen:5}); addTense({shen:-4}); remember('shen','第十九天，你陪他推开了学生会室的门。'); renderHUD();
              showScene({icon:'📘',title:'推开那扇门',
                html:`<p class="nar">他愣了一下，然后很轻地推开了门。「进来吧。」</p>` +
                     deltas({shen:5},{},{shen:-4}),
                choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
            }},
            {label:'「我路过而已。」', run:()=>{ renderHUD(); gotoPhase('night'); }}
          ]});
      }},
      {label:'看着他的背影', run:()=>{
        remember('shen','第十九天，你看见他在你教室门口犹豫。');
        addFav({shen:3}); G.lastVisit['shen']=G.day; renderHUD();
        showScene({icon:'📘',title:'楼梯口',
          html:`<p class="nar">他走了几步，忽然停下，回头看了你一眼。那一眼很轻，但你知道——他记住了你看见过他的犹豫。</p>` +
               deltas({shen:3},{}),
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }}
    ]});
};

DAY_SCRIPT[20] = ()=>{
  /* C 线走流程分组版（C-D20），好感线走高好感吃醋版（HB-D20） */
  const cLine = castLine('shen','我建议把交换生和陆鸣分到一组，苏念秋和林小满一组。这样效率最高。','CH_SHEN');
  if(G.story.route === 'C' || G.fav.shen < FAV_SPLIT){
    showScene({icon:'🎎',title:'第20天 · 文化祭分组（流程版）',meta:'班会 · C-D20',
      html:`<p class="nar">班会上王老师让自由分组，沈逸舟举手。</p>${cLine}
            <p class="nar">他说话时目光落在教案上，没看你。你觉得安排合理，甚至有点感谢他——不然你还不知道该跟谁一组。</p>`,
      choices:[{label:'接受分组 ▶',run:()=>{ G.flags['f_festival_group']=true; renderHUD(); gotoPhase('night'); }}]});
    return;
  }
  choiceScene({
    icon:'🎎',title:'第20天 · 文化祭分组（吃醋版）',meta:'班会 · HB-D20',
    html:`${cLine}
          <p class="nar">他说话时目光落在教案上，没看你。你当时没明白，直到后排林小满扔来一个纸团，上面写着：</p>
          <p class="say">「这家伙吃醋了都不知道。」</p>`,
    choices:[
      {label:'接受分组',flag:'f_festival_group',res:'教室里安静了一下。'},
      {label:'主动提出和沈一组',fav:{shen:5},tense:{shen:-3},flag:'f_festival_group',memo:{shen:'第二十天，你主动提出和他一组。'},res:'他愣了一下。'},
      {label:'主动提出和林一组',fav:{lin:5},flag:'f_festival_group',memo:{lin:'第二十天，你主动提出和她一组。'},res:'她愣了一下，随即别过脸：「……随便你。」'},
      {label:'主动提出和陆一组',fav:{lu:5},flag:'f_festival_group',memo:{lu:'第二十天，你主动提出和他一组。'},res:'他咧嘴笑：「好！那我们组肯定第一！」'},
      {label:'主动提出和苏一组',fav:{su:5},flag:'f_festival_group',memo:{su:'第二十天，你主动提出和她一组。'},res:'她温温地笑：「那，请多指教。」'}
    ]
  });
};

DAY_SCRIPT[21] = ()=> choiceScene({
  icon:'📖',title:'第21天 · 书店征文海报',meta:'书店',
  html:`<p class="nar">书店门口贴着一张征文海报。苏念秋站在海报前，手里攥着一份稿子。</p>
        <p class="say">「……我投了。」</p>`,
  choices:[
    {label:'「你一定可以的」',fav:{su:5},flag:'su_poster_brave',memo:{su:'第二十一天，你说她一定可以。'},res:'她眼睛亮了一下：「……谢谢。」'},
    {label:'「不想投也没关系」',fav:{su:3},flag:'su_poster_soft',tense:{su:-3},res:'她低头笑：「你总是很温柔。」'},
    {label:'只是站着陪她',fav:{su:4},res:'她攥稿子的手松了一点。'}
  ]
});

/* ---------- 第四周 · 裂缝 D22–D30 ---------- */
DAY_SCRIPT[22] = ()=> choiceScene({
  icon:'🍲',title:'第22天 · 火锅店门口',meta:'火锅店',
  html:`<p class="nar">陆鸣从店里探出头：「进来吃啊！我妈今天做了特别多。」</p>
        <p class="nar">林小满从另一头路过，脚步慢了一下。</p>`,
  choices:[
    {label:'进去吃',fav:{lu:5},stat:{social:1},memo:{lu:'第二十二天，你去他家火锅店吃了饭。'},res:'陆妈妈笑眯眯地多给你盛了一碗。'},
    {label:'叫住林小满一起',fav:{lin:4},tense:{lu:-2},res:'她犹豫了一下，还是走进来了。'},
    {label:'谁也不打扰，走开',self:true,stat:{courage:1},res:'你悄悄走了。'}
  ]
});

DAY_SCRIPT[23] = ()=>{
  const th = 30;
  if(G.fav.lin < th){
    showScene({icon:'☕',title:'第23天 · 咖啡店',meta:'咖啡店',
      html:`<p class="nar">林小满看见你，起身换了个座位。</p><p class="nar"><em>（好感 ≥30 解锁）</em></p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  choiceScene({
    icon:'☕',title:'第23天 · 咖啡店博客后台',meta:'咖啡店',
    html:`<p class="nar">林小满去后厨了，手机屏幕亮着。是一个粉丝数过万的穿搭博客后台——没有一张露脸的照片。</p>
          <p class="say">「你、你在看什么！」</p>`,
    choices:[
      {label:'「我什么都没看见」',fav:{lin:6},tense:{lin:-5},secret:'lin',flag:'lin_cafe_trust',memo:{lin:'第二十三天，你看见了她的博客。'},res:'她松了口气，又有点别扭：「……谢了。」'},
      {label:'「你的照片很好看」',fav:{lin:8},tense:{lin:-3},secret:'lin',flag:'lin_cafe_show',memo:{lin:'第二十三天，你说她博客照片好看。'},res:'她愣住了，耳朵红了：「你、你别乱说。」'},
      {label:'「为什么从来不露脸？」',fav:{lin:2},tense:{lin:8},secret:'lin',flag:'lin_cafe_out',memo:{lin:'第二十三天，你问了为什么从不露脸。'},res:'她脸一下白了：「关你什么事。」'}
    ]
  });
};

DAY_SCRIPT[24] = ()=> choiceScene({
  icon:'🍱',title:'第24天 · 那份没动过的便当',meta:'学生会室',
  html:`<p class="nar">周三放学后，你路过学生会室，灯亮着。沈逸舟趴在桌上睡着了，手边一摞待批的文件。</p>
        <p class="nar">桌上摆着两份便当，都没动过。</p>
        <p class="nar">你看出来了——其中一份是多买的。他中午在食堂多打了一份，没好意思给你。</p>`,
  choices:[
    {label:'把外套轻轻披在他肩上，退出去',fav:{shen:6},stat:{courage:1},tense:{shen:-4},
     memo:{shen:'第二十四天，你把外套披在他肩上。'},
     res:'他在睡梦里动了一下，没醒。<br><br>第二天，他在你桌上放了一张便签："外套谢谢。下次别这样。"——便签背面还有一行被划掉的字，你辨认了很久，是"下次会还你"。'},
    {label:'B 把便当热好，留一张纸条放在旁边',fav:{shen:4},stat:{social:1},
     memo:{shen:'第二十四天，你叫醒他一起吃便当。'},
     res:'他抬头看你，愣了一下，然后说："……都凉了。"但他还是吃完了，吃完之后说了一句："下次，我早一点买。"'},
    {label:'C 装作没看见，转身离开',fav:{shen:-2},tense:{shen:5},
     memo:{shen:'第二十四天，你看见他多买了一份便当。'},
     res:'你没打扰他。但第二天你桌上多了一盒完全一样的便当。'}
  ]
});

DAY_SCRIPT[25] = ()=>{
  G.flags['_present_npcs'] = ['lu','lin'];
  const locked = G.fav.lu < 30;
  choiceScene({
    icon:'🍲',title:'第25天 · 陆家火锅店',meta:'火锅店',
    html:`<p class="nar">陆鸣拉你来家里火锅店帮忙。陆妈妈一边笑一边说：「这孩子手受过伤，做不了重活。」</p>
          <p class="nar">陆父从后厨走出来，看了眼陆鸣：「打球能打出什么名堂。」</p>
          ${locked?'<p class="nar" style="color:#a0838f">（陆鸣看了你一眼，没多说什么。）</p>':''}`,
    choices:[
      {label:'帮忙收拾碗筷',fav:{lu:5},stat:{social:1},res:'陆妈妈笑着：「这孩子懂事。」'},
      ...(locked?[]:[
        {label:'「手是怎么伤的？」',fav:{lu:7},tense:{lu:-6},secret:'lu',flag:'lu_hand_asked',memo:{lu:'第二十五天，你问过他手是怎么伤的。'},res:'他沉默了很久：「……初中的时候。」'}
      ]),
      {label:'默默在旁边陪他',fav:{lu:3},res:'他干活的速度慢了一点。'}
    ]
  });
};

DAY_SCRIPT[26] = ()=> choiceScene({
  icon:'💄',title:'第26天 · 林妈妈电话',meta:'教室',
  html:`<p class="nar">林小满的手机响了，屏幕上写着"妈妈"。她按掉了。手指的指节有点白。</p>`,
  choices:[
    {label:'假装没看见',fav:{lin:4},tense:{lin:-4},memo:{lin:'第二十六天，你看见她按掉了妈妈的电话。'},res:'她松了口气。'},
    {label:'「要不要接？」',fav:{lin:2},tense:{lin:6},res:'「不想接。」她声音很硬。'},
    {label:'递给她一瓶水',fav:{lin:6},res:'她接过水，没说话。'}
  ]
});

DAY_SCRIPT[27] = ()=>{
  G.flags['_present_npcs'] = ['shen','lu','lin','su'];
  const shenAfterword = ()=>{ 
    showScene({icon:'📘',title:'散会之后',
      html:`<p class="nar">散会时，沈逸舟走在你后面，很轻地说了一句：</p>
            <p class="say">「……她倒是提醒了我。」</p>`,
      choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
  };
  const choices = [
    {label:'支持沈逸舟的规矩',fav:{shen:6,lu:-3},stat:{courage:2},tense:{lu:3},
     memo:{shen:'第二十七天，你在会上支持了他。'},
     res:'陆鸣："行吧，你永远站他那边。"（摔门走）<br><br>沈逸舟看了你一眼。那一眼很复杂。'},
    {label:'支持陆鸣的排练',fav:{lu:5,shen:-3},tense:{shen:3},
     memo:{lu:'第二十七天，你在会上支持了他。'},
     res:'沈逸舟沉默地合上文件夹。'},
    {label:'「苏学姐说得对，挪周末」',fav:{su:5,shen:1,lu:1,lin:1},stat:{social:2},
     memo:{su:'第二十七天，你替她说了话。'},
     res:'苏念秋抬头看你，眼睛里有一点光。'},
    {label:'转头问林小满"你怎么看"',fav:{lin:5},stat:{courage:1},tense:{lin:-6},
     memo:{lin:'第二十七天，你问了她。'},
     res:'她一愣，别过脸："我随便说的。"'}
  ];
  if(G.stats.social>=30){
    choices.push({label:'「都别吵了，我来排折中表」',fav:{shen:3,lu:3,su:3,lin:3},stat:{social:3},
      tense:{shen:-4,lu:-4},flag:'f_peacemaker',memo:{shen:'第二十七天，你提了个折中方案。'},
      res:'四个人都看了你一眼。沈逸舟先开口："……可以试试。"'});
  }
  choiceScene({icon:'🎎',title:'第27天 · 文化祭联席会议',meta:'会议室',
    html:`<p class="nar">文化祭排练时间谈判。沈逸舟坐主位，陆鸣把校服袖子撸到胳膊肘，苏念秋捧着笔记本，林小满咬着吸管。</p>
          <p class="npcLine"><span class="npcAvatar" style="background:${NPC.lin.color}">💄</span>
            <span class="npcText"><b style="color:${NPC.lin.color}">林小满</b>（一直没说话，忽然把吸管一咬）「你们想过没有——她下周就要走了。六十天，你们还在争自习时间。」</span></p>
          <p class="nar">所有人都愣住。她说的是你。会议室里安静得能听见空调声。</p>`,
    choices});
};


/* ===== D28 · BP-1.5 高亲密意向选择（文档 HB-D28）===== */
DAY_SCRIPT[28] = ()=>{
  if(G.story.route === 'C'){
    showScene({icon:'💬',title:'第28天 · 走廊',meta:'C 线',
      html:`<p class="nar">你和沈逸舟在走廊上错身。他点头，算是打过招呼。</p>
            <p class="nar">第四周要结束了，没有人来问你的意向。</p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  const canLu = G.fav.lu >= LU_AFFINITY_VISIBLE;
  showScene({
    icon:'📝',title:'第28天 · 高亲密意向选择',meta:'食堂 · BP-1.5',
    html:`<p class="nar">联席会议散场后的第二天，张晓棠在食堂把纸条再推到你面前。</p>
          <p class="nar">两周相处下来，你心里清楚谁离你更近——这一笔要在进入心动分支之前定下意向。</p>
          <p class="say">「想清楚再写。六十天很快，别到最后两边都落空。」</p>
          <p class="nar"><em>沈逸舟 ${G.fav.shen}　·　陆鸣 ${G.fav.lu}（可见门槛 ${LU_AFFINITY_VISIBLE}）　·　勇气 ${G.story.courage}</em></p>`,
    choices:[
      {label:'A 明确倾向沈逸舟', hint:'intent = SHEN，保留 P2', run:()=>{
        storyFav('shen',4); bp15('SHEN'); renderHUD();
        showScene({icon:'📝',title:'意向 · 沈逸舟',
          html:`<p class="nar">你在纸条上写下沈逸舟的名字。张晓棠看了一眼，收走了。</p>
                <p class="good">◆ BP-1.5：intent = SHEN　phase 保留 P2，进入 D29 勇气判定</p>`,
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }},
      ...(canLu ? [{label:'B 倾向陆鸣', hint:`需 陆鸣好感 ≥ ${LU_AFFINITY_VISIBLE}`, run:()=>{
        storyFav('lu',6); const to = bp15('LU'); renderHUD();
        showScene({icon:'📝',title:'意向 · 陆鸣',
          html:`<p class="nar">你写下陆鸣的名字。她没有多劝，只在名册上记了一笔。</p>
                <p class="bad">◆ BP-1.5 成立：route = B（遗憾分支）　跳过 D29 共伞</p>`,
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }}] : []),
      {label:'C 暂时都不确定', hint:'保持现状，D29 按勇气判定', run:()=>{
        bp15('UNSET'); renderHUD();
        showScene({icon:'📝',title:'意向 · 暂不确定',
          html:`<p class="nar">你把纸条推回去，说再想想。她点点头，没有催你。</p>
                <p class="good">◆ BP-1.5：intent = UNSET　phase 保留 P2</p>`,
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }}
    ]});
};

/* ===== D29 · BP-2 勇气分支点（文档 5.3：A-D29 / B-D29 / C-D29）===== */
DAY_SCRIPT[29] = ()=>{
  const s = G.story;

  /* C 线：未借伞，淋雨感冒，学习 −1 */
  if(s.route === 'C'){
    showScene({icon:'🌧️',title:'第29天 · 雨天',meta:'校门 · C-D29',
      html:`<p class="nar">放学忽然下起暴雨，你没带伞，站在校门口发呆。</p>
            <p class="nar">沈逸舟撑着一把黑伞走出教学楼，视线扫过你，脚步没停，径直走进雨里，没有回头。</p>
            <p class="nar">你抱着书包冒雨冲回家。第二天感冒了。</p>
            <p class="bad">学习 ${SICK_PENALTY}　隔阂 +6</p>`,
      choices:[{label:'回家 ▶',run:()=>{ storyTense(6); storyStudy(SICK_PENALTY); renderHUD(); gotoPhase('night'); }}]});
    return;
  }

  /* B 线（D28 已选陆鸣）：本日不触发共伞 */
  if(s.route === 'B'){
    showScene({icon:'🌧️',title:'第29天 · 雨天',meta:'校门 · 跳过共伞',
      html:`<p class="nar">雨下得很大。你在校门口没有停留，直接走了。</p>
            <p class="nar">那把伞，今天没有递过来。</p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }

  const ok = (s.courage >= COURAGE_SPLIT);
  showScene({
    icon:'🌧️',title:'第29天 · 雨天共伞',meta:'校门 · BP-2',
    html:`<p class="nar">周一放学忽然下起暴雨，你没带伞，站在教学楼门口发呆。一把伞从后面递过来——沈逸舟站在你身后，半边肩膀已经淋湿。</p>
          ${castLine('shen','我顺路。你拿着。','CH_SHEN')}
          <p class="nar">你撑开伞。伞面有一道旧划痕，像被指甲掐过。</p>
          ${castLine('shen','这把伞我也有过一把，后来弄丢了。弄丢的时候，我以为没什么。','CH_SHEN')}
          <p class="nar">雨越下越大。</p>
          <p class="nar"><em>勇气 ${s.courage} / 共伞阈值 ${COURAGE_SPLIT}</em></p>`,
    choices:[
      ...(ok ? [{label:'「我陪你走回家。」', hint:'勇气 ≥ 30 → 心动分支 A', run:()=>{
        storyFav('shen',10); storyFlag('shen_umbrella_shared'); bp2(); renderHUD();
        showScene({icon:'💗',title:'A-D29 · 同行',
          html:`<p class="nar">你把伞往他那边倾了倾：「我陪你走回家吧。」</p>
                <p class="nar">他愣了一下，没有拒绝。伞很小，两人并肩走，肩膀贴在一起。整条樱花道只有雨声，和他渐渐慢下来的脚步声。</p>
                <p class="nar">走到他家路口，他把伞接过去，低声说：「……明天，我还来。」</p>
                <p class="good">◆ BP-2 成立：route = A　phase = P4（心动分支）</p>`,
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }}] : []),
      {label: ok ? '只说「谢谢。」' : '「……谢谢。」',
        hint: ok ? '放弃同行（降级 B）' : '勇气不足，仅能道谢',
        run:()=>{
          storyFav('shen',9); storyFlag('shen_umbrella_shared'); bp2(); renderHUD();
          showScene({icon:'🌧️',title:'B-D29 · 未同行',
            html:`<p class="nar">你把伞接过来，说了句「谢谢」。</p>
                  <p class="nar">沈逸舟点头，转身跑进雨里，心跳声比雨声还大。那晚他第一次在日记里写下你的名字，随后把那页纸撕了。</p>
                  <p class="bad">◆ BP-2 未成立：route = B　phase = P5（遗憾分支）</p>`,
            choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
        }}
    ]});
};

DAY_SCRIPT[30] = ()=> choiceScene({
  icon:'📘',title:'第30天 · 沈父走廊擦肩',meta:'走廊',
  html:`<p class="nar">走廊那头走来一个穿西装的男人，和沈逸舟有七分像。</p>
        <p class="nar">沈逸舟的背挺得笔直。等男人走远，他才轻轻松了一下肩。</p>`,
  choices:[
    {label:'走过去，什么也不说',fav:{shen:6},tense:{shen:-4},memo:{shen:'第三十天，你看见他和父亲擦肩。'},res:'他侧头看了你一眼。'},
    {label:'「那是你父亲？」',fav:{shen:2},tense:{shen:6},res:'「……嗯。」'},
    {label:'叫住他，递一颗糖',fav:{shen:5},res:'他看着那颗糖，很久才接过去。'}
  ]
});

/* ---------- 第五周 · 秘密 D31–D37 ---------- */
DAY_SCRIPT[31] = ()=>{
  if(G.fav.su < 30){
    showScene({icon:'📖',title:'第31天 · 文学社',meta:'文学社',
      html:`<p class="nar">文学社里空无一人。</p><p class="nar"><em>（好感 ≥30 解锁）</em></p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  choiceScene({
    icon:'📖',title:'第31天 · 苏念秋手稿',meta:'文学社',
    html:`<p class="nar">苏念秋把一叠稿纸推过来。</p>
          <p class="say">「《樱花落尽之前》，写了两年的最后一句——"如果有人愿意等我——"」</p>
          <p class="nar">她的指尖停在那个破折号上。</p>`,
    choices:[
      {label:'「我读完了。」',fav:{su:6},secret:'su',flag:'su_read_detail',memo:{su:'第三十一天，你读完了她的手稿。'},res:'她轻声说：「谢谢。」'},
      {label:'「最后一句还没写吗？」',fav:{su:8},tense:{su:-5},secret:'su',flag:'su_last_chapter_ask',memo:{su:'第三十一天，你问她最后一句还没写吗。'},res:'她低着头：「写不出来了。」'},
      {label:'「会有人愿意等的。」',fav:{su:5},secret:'su',res:'她抬头看你，很久。'}
    ]
  });
};

DAY_SCRIPT[32] = ()=> choiceScene({
  icon:'💬',title:'第32天 · 张晓棠双线警告',meta:'食堂',
  html:`<p class="say">「你最近是不是在同时靠近两个人？别让她俩都知道。」</p>`,
  choices:[
    {label:'「我没有。」',stat:{social:1},res:'张晓棠眯眼：「哦？是吗。」'},
    {label:'「……我知道。」',stat:{courage:2},res:'她叹气：「好吧。你小心点。」'}
  ]
});

DAY_SCRIPT[33] = ()=>{
  if(G.stats.study < 25){
    showScene({icon:'📘',title:'第33天 · 学生会室',meta:'学生会室',
      html:`<p class="nar">门锁着。</p><p class="nar"><em>（学习 ≥25 解锁）</em></p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  if(G.fav.shen < 30){
    showScene({icon:'📘',title:'第33天 · 学生会室',meta:'学生会室',
      html:`<p class="nar">沈逸舟看见你："没你的事。"</p><p class="nar"><em>（好感 ≥30 解锁）</em></p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  choiceScene({
    icon:'📘',title:'第33天 · 沈逸舟的疲惫',meta:'学生会室',
    html:`<p class="nar">周五放学后，你推开学生会室的门。沈逸舟趴在桌上睡着了，手边一摞文件。</p>
          <p class="nar">你走过去，想给他披外套——他迷迷糊糊睁开眼。</p>
          <p class="say">「让我再坐一分钟。就一分钟。」（声音哑得不像他）</p>
          <p class="nar">你眼角余光瞥见他没关严的抽屉——那封 D8 便利贴的完整版。标题写着"退会申请书"，日期那一栏，他誊写了三次，划掉三次。</p>`,
    choices:[
      {label:'「你不用什么都自己扛。」',fav:{shen:10},stat:{courage:2},tense:{shen:-8},
       secret:'shen',flag:'shen_letter_seen',memo:{shen:'第三十三天，你对他说：你不用什么都自己扛。'},
       after:()=>{
         showScene({icon:'📘',title:'他说',
           html:`<p class="nar">他猛地抬头看你。你第一次在他眼睛里，看见红意。</p>
                 <p class="nar">他张了张嘴，最后什么都没说，只是把那沓文件，慢慢推到了你面前。</p>
                 <p class="say">「……你问吧。」</p>`,
           choices:[
             {label:'「那沓纸，是什么？」', run:()=>{
               remember('shen','第三十三天，你问他那沓纸是什么。');
               addFav({shen:4}); renderHUD();
               showScene({icon:'📘',title:'回答',
                 html:`<p class="nar">他沉默了很久，久到你以为他不会回答。然后他说：</p>
                       <p class="say">「我在想，为自己活一次。」</p>
                       <p class="nar">他的手指还在抖。但他把那份退会申请书，从抽屉里拿了出来，第一次摆到了明处。</p>`,
                 choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
             }},
             {label:'什么都不问，陪他坐着', run:()=>{
               addFav({shen:3}); renderHUD();
               showScene({icon:'📘',title:'沉默',
                 html:`<p class="nar">你什么都没问。你们在学生会室的灯下，坐了很久。</p>`,
                 choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
             }}
           ]});
       }},
      {label:'安静地把抽屉关严',fav:{shen:6},tense:{shen:-4},secret:'shen',flag:'shen_letter_seen',
       memo:{shen:'第三十三天，你看见了他的退会申请书。'},
       res:'他看着你关上抽屉，什么都没说。但你知道，他松了口气。'},
      {label:'「早点回家睡吧」',fav:{shen:4},res:'他点点头。'}
    ]
  });
};


DAY_SCRIPT[35] = ()=>{
  if(!G.flags['su_poster_brave']){
    showScene({icon:'🌊',title:'第35天 · 湖边',meta:'湖边',
      html:`<p class="nar">湖面很安静。</p><p class="nar"><em>（需 D21 鼓励过苏念秋）</em></p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  choiceScene({
    icon:'💌',title:'第35天 · 湖边投稿',meta:'湖边 → 邮局',
    html:`<p class="nar">苏念秋攥着一个信封，站在邮筒前。</p>
          <p class="say">「如果投出去……也许会被人读到。」</p>`,
    choices:[
      {label:'「投吧。」',fav:{su:8},tense:{su:-5},flag:'su_post_office',memo:{su:'第三十五天，她投出了那封信。'},res:'信封递出去的手在抖。她回头看你的那一眼，亮得像樱花。'},
      {label:'「我陪你投。」',fav:{su:7},flag:'su_post_office',res:'你们一起把信封投进去。'},
      {label:'「再想想。」',fav:{su:-2},tense:{su:5},res:'她把信封收回去。'}
    ]
  });
};

DAY_SCRIPT[36] = ()=>{
  G.flags['_present_npcs'] = ['lin','lu'];
  choiceScene({
    icon:'🎨',title:'第36天 · 定制海报',meta:'咖啡店',
    html:`<p class="nar">陆鸣悄悄掏钱找林小满挑礼物。林小满全程把你当旁观者。</p>`,
    choices:[
      {label:'安静站在一边',fav:{lin:3},res:'她偶尔抬眼看你一下。'},
      {label:'帮陆鸣挑礼物',fav:{lu:5},tense:{lin:3},flag:'lin_buy_service',res:'林小满「啧」了一声。'},
      {label:'帮林小满拉客户',fav:{lin:6},flag:'lin_promote',res:'她别过脸：「……不用你帮。」'}
    ]
  });
};

DAY_SCRIPT[37] = ()=>{
  G.flags['_present_npcs'] = ['shen','lu','lin','su'];
  choiceScene({
    icon:'⚡',title:'第37天 · 白若曦挑衅',meta:'走廊',
    html:`<p class="nar">白若曦拦在走廊中间。</p>
          <p class="say">「六十天，够干什么？」</p>
          <p class="nar">四个人都停下了。每个人反应不一样。</p>`,
    choices:[
      {label:'不理她，继续走',fav:{shen:2,lu:2,lin:2,su:2},stat:{courage:2},res:'白若曦被你无视了。'},
      {label:'「够我认识这四个人。」',fav:{shen:3,lu:3,lin:3,su:3},stat:{social:3},res:'四个人都看向你。'},
      {label:'「六十天也够我记住你。」',fav:{shen:-2,lu:-2,lin:-2,su:-2},tense:{shen:5,lu:5,lin:5,su:5},stat:{courage:3},res:'白若曦冷笑。'}
    ]
  });
};

/* ---------- 第六周 · 文化祭 D38–D45 ---------- */
DAY_SCRIPT[38] = ()=> choiceScene({
  icon:'🌤️',title:'第38天 · 天台说累',meta:'天台',
  html:`<p class="nar">周三午休，你又推开天台门。沈逸舟今天没背书包，一个人坐在栏杆台阶上。你走过去，在他旁边坐下。</p>
        <p class="nar">很久，他才开口，声音轻得像自言自语：</p>
        <p class="say">「我今天，不想回学生会室。」</p>
        <p class="nar">他顿了顿，像在和什么东西搏斗。</p>
        <p class="say">「……以前，我从来不会说这种话。」</p>`,
  choices:[
    {label:'把一瓶水递给他',fav:{shen:7},tense:{shen:-5},
     memo:{shen:'第三十八天，你递给他一瓶水，手指碰到了一起。'},
     res:'他接过去，手指碰到你的手指，没有缩回去。<br><br>那瓶水他一直没喝，只是握着。'},
    {label:'「那就别回去。」',fav:{shen:6},tense:{shen:-4},
     res:'他笑了一下，很轻："……不行。我是会长。"<br><br>但他说这句话的时候，语气里没有以前的硬。'},
    {label:'「你还好吗？」',fav:{shen:5},res:'「……不好。」<br><br>他说完这两个字，自己都愣了一下，像是第一次承认。'},
    {label:'什么都不说，陪他坐到铃响',fav:{shen:6},tense:{shen:-6},
     memo:{shen:'第三十八天，你陪他坐到铃响。'},
     res:'铃响的时候，他站起来，低声说了一句："……下次，还能来吗。"——不是问天台，是问你。'}
  ]
});

DAY_SCRIPT[39] = ()=>{
  G.flags['_present_npcs'] = ['shen','lu','lin','su'];
  choiceScene({
    icon:'🎀',title:'第39天 · 文化祭前夜布置',meta:'学校各处',
    html:`<p class="nar">布置到很晚。林小满把纸花环戴到你头上。</p>
          <p class="say">「今天你是吉祥物。」</p>`,
    choices:[
      {label:'戴着',fav:{lin:6},flag:'lin_eve',memo:{lin:'第三十九天，她给你戴了花环。'},res:'她笑了。'},
      {label:'「太幼稚了。」',fav:{lin:-2},tense:{lin:4},res:'她愣了一下，转身走了。'},
      {label:'「你自己也戴一个。」',fav:{lin:5},flag:'lin_wreath_self',res:'她愣了一下，然后笑了。'}
    ]
  });
};

DAY_SCRIPT[40] = ()=>{
  G.flags['_present_npcs'] = ['shen','lu','lin','su'];
  choiceScene({
    icon:'🎎',title:'第40天 · 文化祭第一天',meta:'各摊位',
    html:`<p class="nar">只能去一个摊位。</p>
          <p class="nar">苏念秋在台上忘词三秒，声音在话筒里抖了一下。</p>`,
    choices:[
      {label:'去沈逸舟的图书摊',fav:{shen:6},flag:'f_festival_visit',res:'他抬头看你，眼神很轻。'},
      {label:'去陆鸣的运动摊',fav:{lu:6},flag:'f_festival_visit',res:'他跑过来：「你来啦！」'},
      {label:'去林小满的咖啡摊',fav:{lin:6},flag:'f_festival_visit',res:'她头也不抬：「要喝什么。」'},
      {label:'去苏念秋的朗读摊',fav:{su:6},flag:'f_festival_visit',res:'她念完最后一句，眼睛在找你。'}
    ]
  });
};

DAY_SCRIPT[41] = ()=>{
  G.flags['_present_npcs'] = ['shen','lu','lin','su'];
  const high = Object.keys(NPC).filter(k=> G.fav[k]>=60);
  if(high.length >= 2) addRival(pairOf(high[0],high[1]) || 'shen_lu', 10);
  choiceScene({
    icon:'🎆',title:'第41天 · 神社烟花大会',meta:'神社',
    html:`<p class="nar">烟花升起来。</p>
          <p class="nar">${high.length?'有人的声音在耳边轻轻响起。':'四个人站在不同方向。'}</p>`,
    choices:[
      {label:'看向沈逸舟',fav:{shen:6},flag:'f_firework_truth',res:'他侧过脸，在烟花的余光里。'},
      {label:'看向陆鸣',fav:{lu:6},flag:'f_firework_truth',res:'他咧嘴笑。'},
      {label:'看向苏念秋',fav:{su:6},flag:'f_firework_truth',res:'她抬头看烟花。'},
      {label:'看向林小满',fav:{lin:6},flag:'f_firework_truth',res:'她没看你，耳朵却红了。'},
      {label:'「明年再说。」',stat:{courage:2},res:'烟花散尽了。'}
    ]
  });
};

DAY_SCRIPT[42] = ()=> choiceScene({
  icon:'💬',title:'第42天 · 张晓棠倒计时',meta:'食堂',
  html:`<p class="say">「距离结业式还有 18 天。」</p>`,
  choices:[{label:'「……我知道。」',stat:{courage:2},res:'张晓棠看了你很久。'}]
});

DAY_SCRIPT[43] = ()=>{
  G.flags['_present_npcs'] = ['lu','lin'];
  choiceScene({
    icon:'🎪',title:'第43天 · 文化祭第二天收摊',meta:'后台',
    html:`<p class="nar">陆鸣塞给你一张纸条。林小满塞给你一张手绘。只能收一个。</p>`,
    choices:[
      {label:'收下陆鸣的纸条',fav:{lu:7},flag:'lu_note',memo:{lu:'第四十三天，你收下了他的纸条。'},res:'他挠头：「……别当着面拆。」'},
      {label:'收下林小满的手绘',fav:{lin:7},flag:'lin_note',memo:{lin:'第四十三天，你收下了她的手绘。'},res:'她别过脸：「……随便画的。」'}
    ]
  });
};

DAY_SCRIPT[44] = ()=>{
  const hasLu = G.flags['lu_note'], hasLin = G.flags['lin_note'];
  showScene({icon:'✉️',title:'第44天 · 拆纸条',meta:'家',
    html:`<p class="nar">${hasLu?'陆鸣的纸条：「第二次来的时候我看见了。」':hasLin?'林小满的手绘：一套搭配好的衣服，旁边写着"适合你"。':'桌角空空的。'}</p>`,
    choices:[{label:'收进抽屉 ▶',run:()=> gotoPhase('night')}]});
};

DAY_SCRIPT[45] = ()=> showScene({
  icon:'📱',title:'第45天 · 朋友圈合照',meta:'家',
  html:`<p class="nar">四个人各自发了圈，配文不同。</p>
        <p class="nar">沈逸舟：「规则之外。」<br>陆鸣：「今天超开心！」<br>苏念秋：「晚风。」<br>林小满：「有些人。」</p>`,
  choices:[{label:'合上手机 ▶',run:()=> gotoPhase('night')}]}
);

/* ---------- 第七周 · 秘密后日谈 D46–D50 ---------- */
/* ===== D46 · BP-3 父亲的电话（文档 5.4 A-D46 / 5.5 B-D46 / 5.6 C-D46）===== */
DAY_SCRIPT[46] = ()=>{
  const s = G.story;

  /* ---- C 线：被请出去 ---- */
  if(s.route === 'C'){
    showScene({icon:'📞',title:'第46天 · 家庭电话',meta:'学生会室门外 · C-D46',
      html:`<p class="nar">放学后路过学生会室，门虚掩着，你听见里面有声音。</p>
            ${castLine('father','你写退会申请？你知不知道我托了多少人情？','电话音')}
            ${castLine('shen','……我知道。','CH_SHEN')}
            <p class="nar">你犹豫了一下推门。他挂掉电话，抬头看你，表情平静。</p>
            ${castLine('shen','请你出去。这是私人事务。','CH_SHEN')}
            <p class="nar">你退出去，门在身后关上。</p>
            <p class="bad">隔阂 +8</p>`,
      choices:[{label:'退出去 ▶',run:()=>{ storyTense(8); renderHUD(); gotoPhase('night'); }}]});
    return;
  }

  /* ---- B 线：信没有交出去 ---- */
  if(s.route === 'B'){
    showScene({icon:'📞',title:'第46天 · 那封没有交出去的信',meta:'学生会室 · B-D46',
      html:`<p class="nar">电话响了，备注「父亲」。他接起，按了免提又立刻按掉，改成贴在耳边。</p>
            ${castLine('father','你写退会申请？你知不知道我托了多少人情把你送进这个学生会？你知不知道你那个位置，多少人盯着？','电话音')}
            ${castLine('shen','……我知道。','CH_SHEN')}
            <p class="nar">电话挂了。他坐在那里很久没动。桌上摊着那封退会申请书，已经誊写第四次，这一次他没有划掉日期。</p>
            <p class="nar">你轻声说：「交上去。我陪你。」</p>
            <p class="nar">他的手放在信上。三秒。他把信折起，塞回抽屉。</p>
            ${castLine('shen','……我暂时先留在学生会。很多事情，我还需要再等等。','CH_SHEN')}
            <p class="nar">他看见你眼睛暗了一下，没有勇气再看你的眼睛。</p>`,
      choices:[{label:'沉默 ▶',run:()=>{
        bp3(false); renderHUD();
        showScene({icon:'📞',title:'B-D46 · 信留在抽屉',
          html:`<p class="bad">◆ BP-3：shen_against_family = false　结局降级为 END_B</p>`,
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }}]});
    return;
  }

  /* ---- A / P2 线：交信判定 ---- */
  const can = (s.courage >= COURAGE_LETTER);
  showScene({
    icon:'📞',title:'第46天 · 父亲的电话',meta:'学生会室 · BP-3',
    html:`<p class="nar">周四放学后，学生会室。电话响了，备注「父亲」。他接起，按了免提又立刻按掉，改成贴在耳边。</p>
          ${castLine('father','你写退会申请？你知不知道我托了多少人情把你送进这个学生会？','电话音')}
          <p class="nar">沈逸舟握着听筒，指节发白，沉默很久，久到电话那头以为断了。</p>
          ${castLine('shen','……我知道。','CH_SHEN')}
          <p class="nar">他挂掉电话，手在抖。他从抽屉拿出那封誊写三次的退会申请书，这一次没有划掉日期。他把信推到你面前。</p>
          ${castLine('shen','我该交吗？','CH_SHEN')}
          <p class="nar">那是他第一次把自己的人生选择题交给另一个人。</p>
          <p class="nar"><em>勇气 ${s.courage} / “交”选项门槛 ${COURAGE_LETTER}</em></p>`,
    choices:[
      ...(can ? [{label:'「交。我陪你。」', hint:'shen_against_family = true → 走向 END_A', run:()=>{
        storyFav('shen',10); storyCourage(3); storyFlag('shen_against_family'); G.story.secretShen = true;
        bp3(true); renderHUD();
        showScene({icon:'📞',title:'A-D46 · 交',
          html:`<p class="nar">他看了你很久，然后笑了——不是平时克制礼貌的笑，是一种你从没见过、几乎有点狼狈的笑。</p>
                ${castLine('shen','……好。','CH_SHEN')}
                <p class="good">◆ BP-3 成立：shen_against_family = true → END_A</p>`,
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }}] : []),
      {label: can ? '沉默，把信留在桌上' : '「……你自己决定。」',
        hint:'shen_against_family = false → 降级 END_B', run:()=>{
        storyFlag('shen_against_family', false); G.story.secretShen = true;
        bp3(false); renderHUD();
        showScene({icon:'📞',title:'B-D46 · 信没有交',
          html:`<p class="nar">你没有开口。他把信收进抽屉，很轻地说了一句：「……再等等。」</p>
                <p class="bad">◆ BP-3 未成立：shen_against_family = false → END_B</p>`,
          choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
      }}
    ]});
};

DAY_SCRIPT[47] = ()=>{
  if(G.fav.lu < 30){
    showScene({icon:'🏪',title:'第47天 · 便利店',meta:'便利店',
      html:`<p class="nar">便利店门口没有人。</p><p class="nar"><em>（好感 ≥30 解锁）</em></p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  choiceScene({
    icon:'🏀',title:'第47天 · 陈放道歉',meta:'便利店',
    html:`<p class="nar">陈放站在便利店门口，看见陆鸣就低下头。</p>
          <p class="say">「……鸣哥。当年是我。」</p>
          <p class="nar">陆鸣的左手腕在袖子里，护腕露出一角。</p>`,
    choices:[
      {label:'陪他一起去',fav:{lu:8},tense:{lu:-6},secret:'lu',flag:'lu_reconcile_yes',memo:{lu:'第四十七天，你陪他去见陈放。'},res:'他推了陈放一把，然后笑了。'},
      {label:'让他自己去',fav:{lu:5},secret:'lu',flag:'lu_reconcile_half',res:'他一个人走过去。'},
      {label:'「别去了。」',fav:{lu:-2},tense:{lu:5},secret:'lu',flag:'lu_avoid',res:'他摇头：「不。我要去。」'}
    ]
  });
};

DAY_SCRIPT[48] = ()=>{
  if(G.fav.su < 30){
    showScene({icon:'📖',title:'第48天 · 苏家',meta:'苏家',
      html:`<p class="nar">苏家大门紧闭。</p><p class="nar"><em>（好感 ≥30 解锁）</em></p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  choiceScene({
    icon:'📖',title:'第48天 · 苏母撕信',meta:'苏家',
    html:`<p class="nar">苏母把一沓信撕成两半。苏念秋蹲在地上，一张一张地捡。</p>`,
    choices:[
      {label:'据理力争',fav:{su:8},tense:{su:-5},secret:'su',flag:'su_mom_stand',memo:{su:'第四十八天，你和她母亲据理力争。'},res:'苏念秋拉住你的袖子。'},
      {label:'陪她一起拼信',fav:{su:7},secret:'su',flag:'su_mom_quiet',memo:{su:'第四十八天，你陪她拼那封信。'},res:'她一张一张地拼，拼到天亮。'},
      {label:'劝她顺从',fav:{su:-2},tense:{su:8},secret:'su',flag:'su_mom_obey',res:'她低着头，没再说话。'}
    ]
  });
};

DAY_SCRIPT[49] = ()=>{
  if(G.fav.lin < 30){
    showScene({icon:'☕',title:'第49天 · 咖啡店',meta:'咖啡店',
      html:`<p class="nar">咖啡店关门了。</p><p class="nar"><em>（好感 ≥30 解锁）</em></p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  choiceScene({
    icon:'☕',title:'第49天 · 林小满生活费危机',meta:'咖啡店',
    html:`<p class="nar">林小满坐在咖啡店后厨，账本摊在桌上。</p>
          <p class="say">「我不要人给钱，我要人给时间。」</p>`,
    choices:[
      {label:'帮她一起想方案',fav:{lin:8},tense:{lin:-6},secret:'lin',flag:'lin_money_help',memo:{lin:'第四十九天，你帮她一起想方案。'},res:'她愣了一下，然后鼻子红了。'},
      {label:'直接给她钱',fav:{lin:2},tense:{lin:8},secret:'lin',flag:'lin_money_give',res:'她把钱推回来：「我说了不要钱。」'},
      {label:'劝她关博客',fav:{lin:-3},tense:{lin:10},secret:'lin',flag:'lin_money_quit',res:'她沉默了很久：「……你走吧。」'}
    ]
  });
};

DAY_SCRIPT[50] = ()=>{
  G.flags['_present_npcs'] = ['shen','lu','lin','su'];
  showScene({icon:'🌸',title:'第50天 · 第一片花瓣',meta:'校门口',
    html:`<p class="nar">樱花开始凋零。</p>
          <p class="hud-warn" style="text-align:center">🌸 樱花开始凋零 · 剩 10 天</p>
          <p class="nar">陆鸣骑车经过，林小满塞给你一个纸袋。</p>`,
    choices:[{label:'收下纸袋 ▶',run:()=>{
      addFav({lin:3,lu:2});
      remember('lin','第五十天，她给了你一个纸袋。');
      renderHUD(); gotoPhase('night');
    }}]});
};

/* ---------- 第八周 · 剩下的九天 D51–D60 ---------- */
DAY_SCRIPT[51] = ()=>{
  /* C 线（文档 C-D51）：好感最高的陆鸣来邀约，沈逸舟不出现 */
  if(G.story.route === 'C'){
    showScene({icon:'🍜',title:'第51天 · 告白邀约（陆鸣）',meta:'拉面馆 · C-D51',
      html:`<p class="nar">按规则，好感最高的人会来邀约你。你好感最高的是陆鸣——那天在拉面馆，他给你夹了个溏心蛋，说「以后每场球，我都想让你在看台」。</p>
            <p class="nar">沈逸舟没有来。</p>`,
      choices:[{label:'继续 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  /* B 线（文档 B-D51）：告白未成立 */
  if(G.story.route === 'B'){
    showScene({icon:'🌸',title:'第51天 · 告白邀约（未成立）',meta:'樱花道 · B-D51',
      html:`<p class="nar">他约你在樱花道见面。花瓣开始落了，他站在那里，手插口袋，那封折好的退会申请书带在身上。</p>
            ${castLine('shen','六十天，原来这么快。','CH_SHEN')}
            ${castLine('shen','我暂时先留在学生会。很多事情，我还需要再等等。对不起。','CH_SHEN')}
            <p class="nar">你沉默很久，最后轻声说：「……我也是。谢谢这六十天。」</p>
            <p class="nar">他知道你在说谎，也知道自己同样在说谎。</p>
            <p class="bad">告白未成立　隔阂 +10</p>`,
      choices:[{label:'继续 ▶',run:()=> { storyTense(10); renderHUD(); gotoPhase('night'); }}]});
    return;
  }
  const id = topFav();
  const n = NPC[id];
  /* —— 沈逸舟专属告白 —— */
  if(id === 'shen' && G.fav.shen >= 60 && !G.flags['f_refuse_confirm']){
    const pk = CONFLICTS.find(c => c.a === 'shen' || c.b === 'shen');
    const tension = pk ? G.rival[pk.pair] : 0;
    if(tension >= 60){
      showScene({icon:'💔',title:'第51天 · 沈逸舟',meta:'樱花道',
        html:`<p class="nar">他在樱花道等了你很久。看见你时，低下头。</p>
              <p class="say">「……算了，有些话不说比较好。」</p>`,
        choices:[{label:'目送他离开 ▶',run:()=>{ addTense({shen:8}); renderHUD(); gotoPhase('night'); }}]});
      return;
    }
    choiceScene({
      icon:'💌',title:'第51天 · 樱花道告白',meta:'樱花道',
      html:`<p class="nar">周二，D51。樱花已经开始落了。他约你在樱花道见面。</p>
            <p class="nar">他站在花瓣里，穿着那件你看了两个月的制服。他没有拿教案，也没有拿那封信——信已经交上去了。</p>
            <p class="say">「六十天，」他说，「原来这么快。」</p>
            <p class="nar">他看着你，声音很稳，但你听得出来那稳是绷出来的：</p>
            <p class="say">「我已经打算下周把退会申请交上去。我想为自己选一次。」</p>
            <p class="nar">他停了一下。</p>
            <p class="say">「……第一个想选的，是你。」</p>`,
      choices:[
        {label:'「我六十天后就要走了。你确定吗？」',fav:{shen:10},tense:{shen:-6},
         flag:'f_honest_love',memo:{shen:'第五十一天，你对他说：我六十天后就要走了。'},
         res:'他愣了一下。然后他点头，没有犹豫："我知道。"'},
        {label:'「……好。」',fav:{shen:8},memo:{shen:'第五十一天，你回应了他的告白。'},
         res:'他笑了。很轻，但是真的笑。'},
        {label:'「对不起。」',fav:{shen:-3},tense:{shen:8},flag:'f_refuse_confirm',
         res:'他笑了一下：「……我知道了。」'}
      ]
    });
    return;
  }
  /* —— 其他角色通用告白 —— */
  const pk = CONFLICTS.find(c => c.a === id || c.b === id);
  const tension = pk ? G.rival[pk.pair] : 0;
  if(tension >= 60){
    showScene({icon:'💔',title:'第51天 · 告白邀约',meta:'约定地点',
      html:`<p class="nar">${n.name}等了很久。看见你时，低下头。</p>
            <p class="say">「……算了，有些话不说比较好。」</p>`,
      choices:[{label:'目送她/他离开 ▶',run:()=>{ addTense({[id]:8}); renderHUD(); gotoPhase('night'); }}]});
    return;
  }
  choiceScene({
    icon:'💌',title:'第51天 · 告白邀约',meta:'约定地点',
    html:`<p class="nar">${n.name}约你在放学后见面。</p>
          <p class="say">「有些话……想跟你说。」</p>`,
    choices:[
      {label:'「我也是。」',fav:{[id]:10},tense:{[id]:-6},flag:'f_honest_love',
       memo:{[id]:'第五十一天，你回应了告白。'},res:'她/他抬起头，眼睛里有光。'},
      {label:'「对不起。」',fav:{[id]:-3},tense:{[id]:8},flag:'f_refuse_confirm',
       res:'她/他笑了一下：「……我知道了。」'}
    ]
  });
};
DAY_SCRIPT[52] = ()=> showScene({
  icon:'💬',title:'第52天 · 张晓棠纸条',meta:'食堂',
  html:`<p class="say">「你这六十天，比我一年都精彩。」</p>`,
  choices:[{label:'折好纸条 ▶',run:()=> gotoPhase('night')}]}
);

DAY_SCRIPT[53] = ()=>{
  if(!(G.fav.lu>=45 && G.flags['lu_hand_asked'])){
    showScene({icon:'🏀',title:'第53天 · 校门口',meta:'校门口',
      html:`<p class="nar">校门口很安静。</p><p class="nar"><em>（需好感 ≥45 且已问过护腕）</em></p>`,
      choices:[{label:'回家 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  choiceScene({
    icon:'🏀',title:'第53天 · 陈放和解',meta:'校门口',
    html:`<p class="nar">陈放又来了。陆鸣站在他面前。</p>`,
    choices:[
      {label:'让陆鸣自己解决',fav:{lu:7},tense:{lu:-5},flag:'lu_old_teammate',memo:{lu:'第五十三天，你让他自己解决。'},res:'他走过去，说了很久。回来时笑了。'},
      {label:'替他说话',fav:{lu:2},tense:{lu:5},res:'他拉住你：「不。我自己来。」'},
      {label:'拉走他',fav:{lu:-2},tense:{lu:6},res:'他甩开你的手。'}
    ]
  });
};

DAY_SCRIPT[54] = ()=>{
  if(G.fav.lin < 60){
    showScene({icon:'☕',title:'第54天',meta:'家',
      html:`<p class="nar">今天很安静。</p><p class="nar"><em>（需林小满好感 ≥60）</em></p>`,
      choices:[{label:'睡觉 ▶',run:()=> gotoPhase('night')}]});
    return;
  }
  choiceScene({
    icon:'💄',title:'第54天 · 林小满博客曝光',meta:'家 / 手机',
    html:`<p class="nar">林小满的博客被人扒了出来。评论区恶评如潮。</p>
          <p class="say">（她的消息）「你在吗。」</p>`,
    choices:[
      {label:'公开维护她',fav:{lin:10},tense:{lin:-8},flag:'f_lin_public',memo:{lin:'第五十四天，你公开维护她。'},res:'她打电话来，哭了：「……你为什么这么好骗。」'},
      {label:'私下安慰她',fav:{lin:7},tense:{lin:-5},res:'她回了一个"嗯"。'},
      {label:'建议她删号',fav:{lin:2},tense:{lin:6},flag:'lin_deleted',res:'很久之后她才回：「……好。」'},
      {label:'装作不知道',fav:{lin:-3},tense:{lin:5},res:'她没有再发消息。'}
    ]
  });
};

DAY_SCRIPT[55] = ()=> choiceScene({
  icon:'🌸',title:'第55天 · 樱花落三成',meta:'自由',
  html:`<p class="nar">樱花落了三分之一。最后一次邀约窗口。</p>
        <p class="nar">林小满编辑好消息，又删掉了。</p>`,
  choices:[
    {label:'主动约一个人',run:()=>{
      showScene({icon:'📱',title:'最后邀约',html:`<p class="nar">要约谁？</p>`,
        choices: Object.keys(NPC).map(k=>({
          label:`约 ${NPC[k].name}`,
          run:()=>{
            addFav({[k]:3});
            remember(k,'第五十五天，你主动约了对方。');
            renderHUD(); gotoPhase('night');
          }
        }))});
    }},
    {label:'一个人待着',self:true,stat:{courage:2},res:'你一个人在樱花树下坐了很久。',run:()=>{
      addStat({courage:2}); G.selfCount++; renderHUD(); gotoPhase('night');
    }}
  ]
});

DAY_SCRIPT[56] = ()=>{
  const id = topFav();
  const texts = {
    shen:{t:'沈逸舟递过来一封信：「这封信你替我决定。」'},
    lu:{t:'陆鸣低声说：「其实那天不是我自己摔的。」'},
    su:{t:'苏念秋：「最后九天，你在这儿。」'},
    lin:{t:'林小满穿了一条很少穿的裙子：「因为有人在等我。」'}
  };
  choiceScene({
    icon:'💌',title:'第56天 · 最后周末',meta:'约定地点',
    html:`<p class="nar">${texts[id].t}</p>`,
    choices:[
      {label:'认真回应',fav:{[id]:10},tense:{[id]:-6},flag:'lin_last_honest',memo:{[id]:`第五十六天，你们说了很多话。`},res:'时间停了一下。'},
      {label:'「我需要想想。」',fav:{[id]:3},tense:{[id]:3},res:'她/他笑了一下："嗯。"'}
    ]
  });
};

DAY_SCRIPT[57] = ()=> showScene({
  icon:'🌸',title:'第57天 · 樱花步道独处',meta:'樱花步道',
  html:`<p class="nar">你一个人走在樱花步道上。樱花落得很快。</p>
        <p class="nar">日记里你写：「明天就是最后一周了。」</p>`,
  choices:[{label:'回家 ▶',run:()=>{ G.selfCount++; addStat({courage:1}); renderHUD(); gotoPhase('night'); }}]}
);

DAY_SCRIPT[58] = ()=>{
  G.flags['_present_npcs'] = ['shen','lu','lin','su'];
  showScene({icon:'📖',title:'第58天 · 全班传同学录',meta:'教室',
    html:`<p class="nar">同学录传到你手里。四个人留言按档位不同。</p>`,
    choices:[{label:'收好 ▶',run:()=>{
      Object.keys(NPC).forEach(k=>{
        const v = G.fav[k];
        let msg;
        if(v<=19) msg = '「保重。」';
        else if(v<=39) msg = '「有空回来看看。」';
        else if(v<=59) msg = '「别忘了我。」';
        else if(v<=79) msg = '「有些话没说。」';
        else msg = '「等你回来。」';
        remember(k, `第五十八天，${NPC[k].name}的留言：${msg}`);
      });
      renderHUD(); gotoPhase('night');
    }}]});
};

DAY_SCRIPT[59] = ()=> choiceScene({
  icon:'💧',title:'第59天 · 最后一瓶水',meta:'天台 / 体育馆',
  html:`<p class="nar">沈逸舟放下一瓶水就走。陆鸣在体育馆最后练球。林小满把速写放在窗边，没道别。</p>`,
  choices:[
    {label:'拿起那瓶水',fav:{shen:4},res:'瓶身还带着他的温度。'},
    {label:'看陆鸣练完最后一球',fav:{lu:4},res:'球进网的瞬间，他回头找你。'},
    {label:'把速写收好',fav:{lin:4},res:'画的是你。'}
  ]
});

DAY_SCRIPT[60] = ()=> showEnding();

/* ==========================================================
   结局
   ========================================================== */
function showEnding(){
  G.ended = true;
  const e = judgeEnding();
  G.story.lastEnding = e;
  const s = G.story;
  const base = `已解锁成就：${G.achievements.length?G.achievements.join(' · '):'无'}`;
  const again = [
    {label:'🔄 重新开始', run:()=>{ newGame(); prologue(); }},
    {label:'📂 读档重来', run:()=>{ loadGame(); }}
  ];

  /* ===== END_A · 圆满双人 · 樱花回信 ===== */
  if(e === 'END_A'){
    showScene({
      icon:'🌸', title:'D60 · 结业式 · 樱花回信', meta:'校门 · END_A',
      html:`<div class="ending-card">
        <div class="badge rare">🌸 END_A 圆满双人 · 樱花回信</div>
        <div class="who">沈逸舟</div>
        <div class="lv">route A · fav_shen ${G.fav.shen}/100 · 勇气 ${s.courage}</div>
        <div class="txt">
          周四，樱花全部落尽。结业式结束，你走出校门。<br><br>
          他站在学生会室那扇窗下面，没有穿制服，穿的是一件你没见过的、他自己选的白衬衫。<br><br>
          他没有过来拦你，只是站在那里，等你走过去。你走到他面前，他从口袋里拿出一个信封递给你：<br>
          「到了那边再拆。」<br><br>
          风把最后一片樱花吹起来，落在你俩之间。他说：<br>
          「六十天之后，你会像没来过一样走掉，对吧？」<br><br>
          你说是。他点头，没有哭，也没有拦你，只很轻地说：<br>
          「那我就，等你下一次，愿意来的春天。」<br><br>
          <em>——飞机上你拆开信封。里面是一张纸，和一枚盖了章的退会申请书复印件。纸上是他那笔工整克制的字：<br>
          「这是我第一次为自己做的决定。下一次，我想选在你在的城市见你。」<br>
          窗外，樱花开得和你第一天来的时候一样。</em>
        </div>
      </div>
      <p class="nar" style="color:#c78ba1">判定依据　route=A ✔　fav_shen≥${END_A_MIN} ✔（${G.fav.shen}）　f_honest_love ✔　shen_against_family ✔</p>
      <p class="nar" style="color:#b79aa6;font-size:12px;text-align:center">${base}</p>`,
      choices: again
    });
    return;
  }

  /* ===== END_B · 遗憾 · 樱花道上空无一人（含 B-E01 尾声）===== */
  if(e === 'END_B'){
    showScene({
      icon:'🌸', title:'D60 · 结业式 · 樱花道上空无一人', meta:'校门 · END_B',
      html:`<div class="ending-card">
        <div class="badge warn">END_B 遗憾 · 樱花道上空无一人</div>
        <div class="who">沈逸舟</div>
        <div class="lv">route ${s.route||'B'} · fav_shen ${G.fav.shen}/100 · 隔阂 ${s.tense}</div>
        <div class="txt">
          樱花全部落尽。结业式结束，你走出校门。<br><br>
          他站在学生会室窗口，看着那个背影。陆鸣在篮球架下，苏念秋在文学社门口，林小满在咖啡店门口，都在等那个人走过去。<br><br>
          他在窗口，没有下来。<br><br>
          你在校门口回头看了一眼樱花道——道上一个人都没有，花瓣还在飘。你朝他这个方向挥了挥手。<br><br>
          他抬起手想回挥，举到一半停住了。<br><br>
          他想起自己是沈逸舟，学生会长，年级第一，沈教授的儿子；想起自己不是那个可以为一个人跳下樱花道的人。<br><br>
          他的手最终只是朝你方向轻轻鞠了一躬，像对待任何一个同学。你也对他鞠了一躬，然后转身走了。<br><br>
          樱花道上空无一人。
        </div>
      </div>
      <p class="nar" style="color:#c78ba1">判定依据　route∈{A,B} ✔　fav_shen≥55 ${G.fav.shen>=55?'✔':'✘'}（${G.fav.shen}）　shen_against_family=false ✔</p>
      <p class="nar" style="color:#b79aa6">尾声 · B-E01 · 一年后（北京会场）</p>
      <p class="nar">一年后，他在北京的一场会议上遇见父亲。父亲拍了拍他的肩，说了句什么。他把背挺得很直，头都没低。散场后他一个人在宾馆拆开那封始终没交出去的信，看了一遍，折好，放回口袋——他终究没有寄出去。</p>
      <p class="nar" style="color:#b79aa6;font-size:12px;text-align:center">${base}</p>`,
      choices: again
    });
    return;
  }

  /* ===== END_C · 擦肩而过的春天 ===== */
  showScene({
    icon:'🌸', title:'D60 · 结业式 · 擦肩而过的春天', meta:'操场 · END_C',
    html:`<div class="ending-card">
      <div class="badge">END_C 擦肩而过的春天</div>
      <div class="who">沈逸舟 / 你</div>
      <div class="lv">route C · fav_shen ${G.fav.shen}/100 · 隔阂 ${s.tense} · secret ${s.secretShen?'true':'false'}</div>
      <div class="txt">
        樱花全部落尽，操场上举行结业式。<br><br>
        沈逸舟作为学生会长站在主席台致辞，笔挺制服，声音平稳，和 D1 开学典礼那天几乎一样：<br>
        「……希望各位同学，度过了一个不留遗憾的春天。」<br><br>
        念到这里，他的目光扫过台下人群，没有在你身上停留。<br><br>
        结业式结束，你走出校门。陆鸣在篮球架下冲你挥手，苏念秋在文学社门口对你笑，林小满在咖啡店门口比了个心。<br><br>
        沈逸舟被老师和学生会成员围住处理收尾，没有向你的方向望过来。
      </div>
    </div>
    <p class="nar" style="color:#c78ba1">判定依据　route=C ✔　fav_shen≤22 ✔（${G.fav.shen}）　secret_shen=false ${s.secretShen?'✘':'✔'}</p>
    <p class="nar" style="color:#b79aa6;font-size:12px;text-align:center">${base}</p>`,
    choices: again
  });
}
//（注：内容由AI生成）
