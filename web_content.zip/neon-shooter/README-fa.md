# راهنمای ساخت APK مبارز نئونی

## نیازها (یک‌بار نصب کن)
1. Node.js (نسخه ۱۸ یا بالاتر): nodejs.org
2. Android Studio: developer.android.com/studio

## مرحله ۱: فایل Three.js
این فایل رو دانلود کن و با همین اسم داخل پوشه‌ی www بذار:
https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
(ذخیره به‌صورت www/three.min.js)

## مرحله ۲: نام پکیج
فایل capacitor.config.json رو باز کن و appId رو به چیزی یکتا تغییر بده، مثلاً com.ali.neonshooter

## مرحله ۳: دستورات (داخل همین پوشه)
npm install
npx cap add android

## مرحله ۴: قفل landscape
فایل android/app/src/main/AndroidManifest.xml رو باز کن. داخل تگ <activity ... به آخر مشخصاتش این رو اضافه کن:
android:screenOrientation="landscape"

## مرحله ۵: ساخت APK
npx cap sync
npx cap open android
در Android Studio: Build > Generate Signed App Bundle / APK > APK
یک Keystore جدید بساز و حتماً فایل و رمزش رو نگه دار (برای آپدیت‌های بعدی لازمه).
نوع Release رو انتخاب کن. فایل app-release.apk خروجی‌ات هست.

## مرحله ۶: مایکت
در پنل توسعه‌دهنده‌ی مایکت بازی جدید بساز، APK رو آپلود کن، و از پوشه‌ی store این‌ها رو استفاده کن:
- icon-512.png (آیکون)
- feature-1024x500.png (تصویر شاخص)
- listing-fa.txt (متن معرفی)
اسکرین‌شات هم از خود بازی روی گوشی بگیر (حداقل ۳ تا).
