QUIZ DA ELSA — PACOTE PARA CONVERTER EM APK

Conteúdo:
- index.html: jogo quiz completo, adaptado para telemóvel.
- README.txt: estas instruções.

Como usar:
1. Extrai este ficheiro ZIP.
2. Abre a aplicação "ZIP to APK" ou o conversor que costumas usar.
3. Escolhe criar um APK a partir de um site/HTML ou WebView.
4. Seleciona a pasta extraída e indica o ficheiro inicial: index.html.
5. Define o nome da aplicação como "Quiz da Elsa" e escolhe um ícone, se o conversor permitir.
6. Gera o APK e instala-o no teu telemóvel seguindo as instruções do conversor.

Nota:
- O quiz tem 15 perguntas de escolha múltipla.
- Funciona sem internet depois de empacotado.
- O ZIP contém os ficheiros-fonte; não é um APK já compilado.
- Os nomes e detalhes pessoais aparecem porque foram fornecidos para criar este jogo. Partilha o APK apenas com pessoas com quem te sintas confortável.
