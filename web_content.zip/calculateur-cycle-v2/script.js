function calculer() {
  
  var date_regles = document.getElementById("date_regles").value;
  var duree_cycle = parseInt(document.getElementById("duree_cycle").value);
  var duree_regles = parseInt(document.getElementById("duree_regles").value);

  if (date_regles == "") {
    alert("Merci de choisir une date !");
    return;
  }


  var debut_regles = new Date(date_regles);

  var prochaines_regles = new Date(debut_regles);

  prochaines_regles.setDate(debut_regles.getDate() + duree_cycle);

  var date_ovulation = new Date(prochaines_regles);

  date_ovulation.setDate(prochaines_regles.getDate() - 14);


  var debut_fertile = new Date(date_ovulation);

  debut_fertile.setDate(date_ovulation.getDate() - 5);

  var fin_fertile = new Date(date_ovulation);

  fin_fertile.setDate(date_ovulation.getDate() + 1);


  var resultat = document.getElementById("resultat");

  resultat.classList.remove("resultat_anime");

  resultat.innerHTML =
    "<p><strong>Prochaines règles :</strong> " + formater_date(prochaines_regles) + "</p>" +
    "<p><strong>Ovulation estimée :</strong> " + formater_date(date_ovulation) + "</p>" +
    "<p><strong>Période fertile :</strong> du " + formater_date(debut_fertile) + " au " + formater_date(fin_fertile) + "</p>";


  void resultat.offsetWidth;
  resultat.classList.add("resultat_anime");


  afficher_calendrier(debut_regles, duree_regles, debut_fertile, fin_fertile, date_ovulation);
}


function formater_date(date) {
  var jour = String(date.getDate()).padStart(2, "0");

  var mois = String(date.getMonth() + 1).padStart(2, "0");

  var annee = date.getFullYear();

  return jour + "/" + mois + "/" + annee;
}


function afficher_calendrier(debut_regles, duree_regles, debut_fertile, fin_fertile, date_ovulation) {
  var calendrier = document.getElementById("calendrier");

  calendrier.innerHTML = "";

  var annee = debut_regles.getFullYear();

  var mois = debut_regles.getMonth();


  var nombre_jours = new Date(annee, mois + 1, 0).getDate();


  var fin_regles = new Date(debut_regles);

  fin_regles.setDate(debut_regles.getDate() + duree_regles - 1);

  for (var i = 1; i <= nombre_jours; i++) {
    var jour_actuel = new Date(annee, mois, i);

    var case_jour = document.createElement("div");

    case_jour.classList.add("jour");

    case_jour.textContent = i;



    case_jour.style.animationDelay = (i * 0.02) + "s";

    if (jour_actuel >= debut_regles && jour_actuel <= fin_regles) {
      case_jour.classList.add("jour_regles");

    } else if (jour_actuel.toDateString() == date_ovulation.toDateString()) {
      case_jour.classList.add("jour_ovulation");

    } else if (jour_actuel >= debut_fertile && jour_actuel <= fin_fertile) {
      case_jour.classList.add("jour_fertile");
    }

    calendrier.appendChild(case_jour);
  }
}
