# BarOS

Sistema de gestão para bares, cafés e restaurantes, desenvolvido em HTML/CSS/JavaScript puro e pronto para publicação em GitHub Pages.

## Visão geral

O projeto foi organizado em múltiplos ficheiros para manter a lógica separada em módulos e facilitar a manutenção. Mantém o uso do localStorage como base de dados local por defeito e prepara uma integração com Supabase para sincronização multi-dispositivo.

## Screenshot

![BarOS placeholder](assets/img/logo.svg)

## Estrutura do projeto

```text
baros/
├── index.html
├── pages/
│   ├── setup.html
│   ├── login.html
│   ├── dashboard.html
│   ├── pos.html
│   ├── tables.html
│   ├── stock.html
│   ├── cash.html
│   ├── clients.html
│   ├── reports.html
│   ├── company.html
│   ├── users.html
│   └── logs.html
├── assets/
│   ├── css/
│   ├── js/
│   └── img/
├── supabase/
│   ├── schema.sql
│   └── seed.sql
├── .gitignore
├── CHANGELOG.md
├── README.md
└── index.html
```

## Como correr localmente

### Opção 1 — servidor Python

```bash
cd baros
python -m http.server 8000
```

Depois abra:

```text
http://localhost:8000/
```

### Opção 2 — Live Server no VS Code

- Abra a pasta do projeto no VS Code.
- Instale a extensão Live Server.
- Clique com o botão direito em qualquer ficheiro HTML.
- Escolha "Open with Live Server".

## Opção A — localStorage (sem backend)

Esta é a opção mais simples para testes e demonstração em um único dispositivo.

Vantagens:

- Sem configuração extra
- Funciona em GitHub Pages
- Boa para protótipo e testes locais

Limitações:

- Os dados permanecem apenas no navegador do dispositivo
- Não há sincronização entre telemóveis

## Opção B — Supabase (recomendada)

Esta opção permite guardar os dados num servidor compartilhado e acedê-los em vários dispositivos.

### 1. Criar conta no Supabase

1. Aceda a https://supabase.com
2. Crie uma conta gratuita
3. Crie um novo projeto
4. Anote a URL e a anon key

### 2. Preparar o SQL

1. Abra o painel SQL Editor no Supabase
2. Cole o conteúdo de [supabase/schema.sql](supabase/schema.sql)
3. Execute o script
4. Opcionalmente, corra [supabase/seed.sql](supabase/seed.sql) para popular dados de exemplo

### 3. Configurar o front-end

1. Copie [assets/js/config.example.js](assets/js/config.example.js) para [assets/js/config.js](assets/js/config.js)
2. Preencha com os dados do seu projeto:

```js
export const APP_CONFIG = {
  name: 'BarOS',
  storagePrefix: 'baros',
  supabase: {
    url: 'https://SEU-PROJETO.supabase.co',
    anonKey: 'SUA_ANON_KEY',
  },
  defaultRoute: 'dashboard.html',
  currency: 'AOA',
  locale: 'pt-AO',
};
```

## Publicar no GitHub Pages

### Método automático (recomendado)

O projeto já inclui um workflow em [./.github/workflows/pages.yml](.github/workflows/pages.yml) para publicar automaticamente ao fazer `push` para `main`.

1. Crie um repositório no GitHub
2. Faça upload do projeto
3. No GitHub, aceda a:
   - Settings
   - Pages
   - Source: `GitHub Actions`
4. Faça `push` para `main`
5. Aguarde a publicação e abra a URL:

```text
https://<user>.github.io/baros/
```

### Método manual

1. Criar um repositório público chamado `baros`
2. Na pasta do projeto, executar:

```bash
git init
git add .
git commit -m "first commit"
git remote add origin https://github.com/<user>/baros.git
git push -u origin main
```

3. No GitHub:
   - Settings
   - Pages
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/ (root)`
   - Save

4. Aguarde 1 a 2 minutos
5. Abra a URL:

```text
https://<user>.github.io/baros/
```

## Testar no telemóvel

1. Publique o projeto no GitHub Pages e abra a URL `https://<user>.github.io/baros/` no Chrome do Android.
2. No menu do Chrome, escolha **Instalar app** ou **Adicionar ao ecrã inicial**.
3. Abra o BarOS pelo ícone criado. O POS adapta-se ao ecrã pequeno; os dados ficam guardados no navegador desse Android.

É necessária ligação à Internet para abrir o site. Como a aplicação usa `localStorage`, os dados não são partilhados automaticamente com outros dispositivos nem com outros navegadores.

Na página **Empresa**, pode escolher uma pasta para manter uma cópia automática `baros-backup.json`, se o navegador suportar acesso a pastas. A cópia inicial mantém os dados já existentes no app. Em navegadores sem essa função, use **Exportar cópia** e **Importar cópia**. O ficheiro contém dados sensíveis e palavras-passe sem encriptação; guarde-o num local privado. A pasta é escolhida pelo utilizador no seletor do navegador; o site não pode criar pastas no dispositivo sem essa autorização.

## HTTPS e APIs

Algumas APIs e funcionalidades de segurança exigem HTTPS. Portanto, quando publicares em GitHub Pages, assegura-te de que o projeto é servido com HTTPS, e que o teu ambiente de produção não usa recursos inseguros.

## Nota importante sobre caminhos

Todos os ficheiros referenciam caminhos relativos, por exemplo:

```html
<link rel="stylesheet" href="./assets/css/base.css" />
<a href="./pages/stock.html">Estoque</a>
```

Isto é necessário porque o GitHub Pages serve a aplicação num subdiretório, como `/baros/`.

## Licença

Projeto para uso interno/educativo. Ajusta conforme o teu caso de uso real.
