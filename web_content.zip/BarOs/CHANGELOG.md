# Changelog

## [Unreleased]

- Estrutura do projeto reorganizada em múltiplos ficheiros.
- Criação da base CSS central e estilos de autenticação.
- Sistema de autenticação e sessão em localStorage.
- Layout dinâmico com sidebar e topbar.
- Implementação do padrão de páginas com módulos ES.
- Definição da base para suporte a Supabase.
- Preparação para publicação em GitHub Pages.
- Inclusão de documentação de setup e deploy.
