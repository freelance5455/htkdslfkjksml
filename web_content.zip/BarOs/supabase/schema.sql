-- Schema base para BarOS com Supabase
-- Atenção: este ficheiro assume que está a utilizar as APIs do Supabase com anon key para prototipagem.
-- Ajuste as políticas RLS conforme o teu nível de segurança real.

create extension if not exists pgcrypto;

create table if not exists public.company (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  trade_name text,
  owner text,
  nif text,
  registry text,
  address text,
  city text,
  province text,
  phone text,
  whatsapp text,
  email text,
  website text,
  logo text,
  slogan text,
  currency text default 'EUR',
  tax_name text default 'IVA',
  tax_rate numeric(5,2) default 23,
  invoice_series text default 'B',
  invoice_start integer default 1,
  low_stock_alert integer default 10,
  expiry_alert integer default 30,
  autolock_min integer default 10,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  "user" text not null unique,
  pass text,
  role text not null check (role in ('admin', 'gerente', 'caixa', 'estoquista')) default 'caixa',
  active boolean default true,
  created timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  code text unique,
  barcode text,
  name text not null,
  category text,
  brand text,
  unit text,
  qty numeric(12,2) default 0,
  min_qty numeric(12,2) default 0,
  cost numeric(12,2) default 0,
  price numeric(12,2) default 0,
  supplier text,
  entry_date timestamptz,
  expiry_date timestamptz,
  location text,
  image text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.movements (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references public.products(id) on delete set null,
  product_name text,
  type text not null check (type in ('entrada', 'saida', 'ajuste', 'venda', 'perda')),
  qty numeric(12,2) not null default 0,
  before_qty numeric(12,2),
  after_qty numeric(12,2),
  date timestamptz default now(),
  "user" text,
  note text,
  created_at timestamptz default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  nif text,
  phone text,
  email text,
  address text,
  credit numeric(12,2) default 0,
  created timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  number text unique not null,
  date timestamptz default now(),
  subtotal numeric(12,2) default 0,
  discount numeric(12,2) default 0,
  total numeric(12,2) default 0,
  iva_rate numeric(5,2) default 23,
  customer_id uuid references public.customers(id) on delete set null,
  customer_name text,
  operator text,
  operator_id uuid references public.users(id) on delete set null,
  table_name text,
  status text default 'paid' check (status in ('paid', 'pending', 'cancelled', 'open')),
  channel text default 'counter' check (channel in ('counter', 'table', 'delivery', 'online')),
  created_at timestamptz default now()
);

create table if not exists public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  name text not null,
  qty numeric(12,2) not null default 1,
  price numeric(12,2) not null default 0,
  cost numeric(12,2) default 0,
  created_at timestamptz default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  method text not null check (method in ('cash', 'card', 'mbway', 'transfer', 'credit')),
  amount numeric(12,2) not null default 0,
  created_at timestamptz default now()
);

create table if not exists public.cash_sessions (
  id uuid primary key default gen_random_uuid(),
  opened_at timestamptz default now(),
  closed_at timestamptz,
  initial_amount numeric(12,2) default 0,
  expected_amount numeric(12,2) default 0,
  real_amount numeric(12,2) default 0,
  diff_amount numeric(12,2) default 0,
  "user" text,
  user_id uuid references public.users(id) on delete set null,
  closed boolean default false,
  close_note text,
  closed_by text,
  created_at timestamptz default now()
);

create table if not exists public.cash_movements (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references public.cash_sessions(id) on delete cascade,
  type text not null check (type in ('opening', 'sale', 'refund', 'sangria', 'reforco', 'close')),
  amount numeric(12,2) default 0,
  note text,
  date timestamptz default now(),
  "user" text,
  sale_id uuid references public.sales(id) on delete set null,
  created_at timestamptz default now()
);

create table if not exists public.logs (
  id uuid primary key default gen_random_uuid(),
  date timestamptz default now(),
  "user" text,
  action text not null,
  level text default 'info' check (level in ('info', 'warn', 'error', 'success')),
  message text,
  created_at timestamptz default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  msg text,
  type text default 'info' check (type in ('info', 'success', 'warn', 'error')),
  date timestamptz default now(),
  read boolean default false,
  created_at timestamptz default now()
);

create table if not exists public.tables (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  status text default 'free' check (status in ('free', 'occupied', 'reserved')),
  seats integer default 4,
  location text,
  created_at timestamptz default now()
);

create table if not exists public.carts (
  id uuid primary key default gen_random_uuid(),
  table_name text,
  status text default 'open' check (status in ('open', 'closed')),
  customer_id uuid references public.customers(id) on delete set null,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.cart_items (
  id uuid primary key default gen_random_uuid(),
  cart_id uuid not null references public.carts(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  name text not null,
  qty numeric(12,2) not null default 1,
  price numeric(12,2) not null default 0,
  created_at timestamptz default now()
);

create index if not exists idx_products_code on public.products(code);
create index if not exists idx_products_category on public.products(category);
create index if not exists idx_products_name on public.products(name);
create index if not exists idx_sales_date on public.sales(date);
create index if not exists idx_sale_items_sale_id on public.sale_items(sale_id);
create index if not exists idx_cash_movements_session_id on public.cash_movements(session_id);
create index if not exists idx_notifications_read on public.notifications(read);
create index if not exists idx_logs_date on public.logs(date);
create index if not exists idx_table_status on public.tables(status);

alter table public.company enable row level security;
alter table public.users enable row level security;
alter table public.products enable row level security;
alter table public.movements enable row level security;
alter table public.customers enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.payments enable row level security;
alter table public.cash_sessions enable row level security;
alter table public.cash_movements enable row level security;
alter table public.logs enable row level security;
alter table public.notifications enable row level security;
alter table public.tables enable row level security;
alter table public.carts enable row level security;
alter table public.cart_items enable row level security;

create policy "company_is_public_read" on public.company
 for select using (true);

create policy "company_authenticated_write" on public.company
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "users_public_read" on public.users
 for select using (true);

create policy "users_authenticated_write" on public.users
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "products_public_read" on public.products
 for select using (true);

create policy "products_authenticated_write" on public.products
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "movements_public_read" on public.movements
 for select using (true);

create policy "movements_authenticated_write" on public.movements
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "customers_public_read" on public.customers
 for select using (true);

create policy "customers_authenticated_write" on public.customers
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "sales_public_read" on public.sales
 for select using (true);

create policy "sales_authenticated_write" on public.sales
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "sale_items_public_read" on public.sale_items
 for select using (true);

create policy "sale_items_authenticated_write" on public.sale_items
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "payments_public_read" on public.payments
 for select using (true);

create policy "payments_authenticated_write" on public.payments
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "cash_sessions_public_read" on public.cash_sessions
 for select using (true);

create policy "cash_sessions_authenticated_write" on public.cash_sessions
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "cash_movements_public_read" on public.cash_movements
 for select using (true);

create policy "cash_movements_authenticated_write" on public.cash_movements
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "logs_public_read" on public.logs
 for select using (true);

create policy "logs_authenticated_write" on public.logs
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "notifications_public_read" on public.notifications
 for select using (true);

create policy "notifications_authenticated_write" on public.notifications
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "tables_public_read" on public.tables
 for select using (true);

create policy "tables_authenticated_write" on public.tables
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "carts_public_read" on public.carts
 for select using (true);

create policy "carts_authenticated_write" on public.carts
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "cart_items_public_read" on public.cart_items
 for select using (true);

create policy "cart_items_authenticated_write" on public.cart_items
 for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
