-- Dados de exemplo para o BarOS

insert into public.company (
  name, trade_name, owner, nif, registry, address, city, province,
  phone, whatsapp, email, website, logo, slogan, currency,
  tax_name, tax_rate, invoice_series, invoice_start,
  low_stock_alert, expiry_alert, autolock_min
) values (
  'BarOS', 'BarOS', 'João Silva', '123456789', 'A12345', 'Rua da Praça 101',
  'Lisboa', 'Lisboa', '212345678', '912345678', 'hello@baros.pt', 'https://baros.pt',
  '', 'Casa de snacks e bebidas', 'EUR', 'IVA', 23, 'B', 1, 10, 30, 10
) on conflict do nothing;

insert into public.users (name, "user", pass, role, active)
values
  ('Administrador', 'admin', 'admin123', 'admin', true),
  ('Gerente', 'gerente', 'gerente123', 'gerente', true),
  ('Caixa', 'caixa', 'caixa123', 'caixa', true),
  ('Estoquista', 'estoquista', 'estoquista123', 'estoquista', true)
on conflict ("user") do nothing;

insert into public.products (
  code, barcode, name, category, brand, unit, qty, min_qty, cost, price, supplier,
  entry_date, expiry_date, location, image
) values
  ('P001', '5601234567890', 'Cerveja Artesanal', 'Bebidas', 'Local', 'un', 42, 10, 1.2, 2.5, 'Fornecedor A', now(), now() + interval '90 days', 'Geladeira 1', ''),
  ('P002', '5601234567891', 'Refrigerante Cola', 'Bebidas', 'Marca X', 'un', 18, 8, 0.9, 2.2, 'Fornecedor B', now(), now() + interval '180 days', 'Geladeira 2', ''),
  ('P003', '5601234567892', 'Batata Frita', 'Snack', 'BarOS', 'kg', 7, 6, 3.4, 5.5, 'Fornecedor C', now(), now() + interval '45 days', 'Armazém', ''),
  ('P004', '5601234567893', 'Hambúrguer', 'Food', 'BarOS', 'un', 14, 8, 4.2, 8.9, 'Fornecedor C', now(), now() + interval '30 days', 'Congelador', '')
on conflict (code) do nothing;

insert into public.customers (name, nif, phone, email, address, credit)
values
  ('Ana Costa', '249999999', '912345678', 'ana@teste.pt', 'Rua do Sol 12', 25.50),
  ('Tiago Silva', '284444444', '919876543', 'tiago@teste.pt', 'Avenida Azul 88', 75.00),
  ('Maria Almeida', '150000000', '913456789', 'maria@teste.pt', 'Praça 9 34', 0)
on conflict do nothing;

insert into public.tables (name, status, seats, location)
values
  ('Mesa 1', 'free', 2, 'Sala central'),
  ('Mesa 2', 'occupied', 4, 'Sala central'),
  ('Mesa 3', 'reserved', 6, 'Terraço'),
  ('Mesa 4', 'free', 2, 'Bar')
on conflict do nothing;

insert into public.notifications (title, msg, type, date, read)
values
  ('Estoque baixo', 'Existem produtos abaixo do mínimo.', 'warn', now(), false),
  ('Venda concluída', 'Venda nº 1001 foi processada com sucesso.', 'success', now(), false),
  ('Atenção', 'O turno de caixa foi fechado com diferença de 12.50€.', 'info', now(), false)
on conflict do nothing;
