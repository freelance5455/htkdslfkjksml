import { createClient } from 'https://esm.sh/@supabase/supabase-js';

const defaultConfig = {
  enabled: false,
  url: '',
  anonKey: '',
};

export function initSupabaseClient(config = defaultConfig) {
  if (!config || config.enabled === false || !config.url || !config.anonKey) {
    return null;
  }

  return createClient(config.url, config.anonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });
}

export async function getProducts(supabase) {
  if (!supabase) return [];
  const { data, error } = await supabase.from('products').select('*');
  if (error) throw error;
  return data || [];
}

export async function addProduct(supabase, product) {
  if (!supabase) return null;
  const { data, error } = await supabase.from('products').insert(product).select().single();
  if (error) throw error;
  return data;
}

export async function getUsers(supabase) {
  if (!supabase) return [];
  const { data, error } = await supabase.from('users').select('*');
  if (error) throw error;
  return data || [];
}

export async function createSale(supabase, payload) {
  if (!supabase) return null;
  const { data, error } = await supabase.from('sales').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function createNotification(supabase, notification) {
  if (!supabase) return null;
  const { data, error } = await supabase.from('notifications').insert(notification).select().single();
  if (error) throw error;
  return data;
}

export default initSupabaseClient;
