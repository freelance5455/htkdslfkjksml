import { safeStorage } from './storage.js';

const STORAGE_KEY = 'baros:notifications';

export function getDefaultNotifications() {
  return [
    {
      id: crypto.randomUUID(),
      title: 'Turno em andamento',
      msg: 'O piso de serviço está estável e o caixa principal está ativo.',
      type: 'info',
      read: false,
      date: new Date().toISOString(),
    },
    {
      id: crypto.randomUUID(),
      title: 'Estoque crítico',
      msg: 'Há 9 itens abaixo do mínimo recomendado para hoje.',
      type: 'warn',
      read: false,
      date: new Date(Date.now() - 1000 * 60 * 22).toISOString(),
    },
    {
      id: crypto.randomUUID(),
      title: 'Venda registrada',
      msg: 'Uma venda foi concluída com sucesso no balcão principal.',
      type: 'success',
      read: true,
      date: new Date(Date.now() - 1000 * 60 * 58).toISOString(),
    },
  ];
}

export class NotificationCenter {
  constructor(storageKey = STORAGE_KEY) {
    this.storageKey = storageKey;
    this.items = this.load();
  }

  load() {
    try {
      const key = this.storageKey.replace(/^baros:/, '');
      const notifications = safeStorage.get(key, null);
      if (!notifications) {
        const seed = getDefaultNotifications();
        safeStorage.set(key, seed);
        return seed;
      }

      return Array.isArray(notifications) && notifications.length ? notifications : getDefaultNotifications();
    } catch (error) {
      console.warn('notificationCenter.load() falhou:', error);
      return getDefaultNotifications();
    }
  }

  save() {
    try {
      const key = this.storageKey.replace(/^baros:/, '');
      return safeStorage.set(key, this.items);
    } catch (error) {
      console.warn('notificationCenter.save() falhou:', error);
      return false;
    }
  }

  add(title, msg, type = 'info') {
    const item = {
      id: crypto.randomUUID(),
      title,
      msg,
      type,
      date: new Date().toISOString(),
      read: false,
    };

    this.items = [item, ...this.items].slice(0, 12);
    this.save();
    return item;
  }

  list() {
    return [...this.items];
  }

  unreadCount() {
    return this.items.filter((item) => !item.read).length;
  }
}

export const notificationCenter = new NotificationCenter();

export function renderNotifications(items = notificationCenter.list()) {
  if (!items.length) {
    return `
      <div class="notif-empty">
        <strong>Sem notificações</strong>
        <span>Não há alertas pendentes no momento.</span>
      </div>
    `;
  }

  return items
    .map((item) => `
      <div class="notif-item">
        <div class="ico ${item.type === 'warn' ? 'tag-warn' : item.type === 'success' ? 'tag-ok' : 'tag-info'}">${item.type === 'warn' ? '⚠' : item.type === 'success' ? '✓' : 'ℹ'}</div>
        <div class="txt">
          <strong>${item.title}</strong>
          <span>${item.msg}</span>
        </div>
      </div>
    `)
    .join('');
}

export function toggleNotificationsPanel() {
  const existing = document.getElementById('baros-notifications');
  if (existing) {
    existing.remove();
    return;
  }

  const panel = document.createElement('div');
  panel.id = 'baros-notifications';
  panel.className = 'notif-panel';
  panel.innerHTML = `
    <div class="notif-head">
      <strong>Notificações</strong>
      <span>${notificationCenter.unreadCount()} pendentes</span>
    </div>
    <div class="notif-list">
      ${renderNotifications()}
    </div>
    <div class="notif-foot">
      <button type="button" class="btn btn-ghost btn-sm" data-notif-close>Fechar</button>
    </div>
  `;

  document.body.appendChild(panel);

  panel.querySelector('[data-notif-close]')?.addEventListener('click', () => panel.remove());
}
