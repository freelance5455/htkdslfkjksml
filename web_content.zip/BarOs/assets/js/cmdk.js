import { NAV_ITEMS } from './config.js';

const paletteId = 'baros-cmdk';

function getPaletteItems() {
  return [
    ...NAV_ITEMS.map((item) => ({
      id: item.key,
      label: item.label,
      page: item.page,
      icon: item.icon,
      type: 'Página',
      keywords: [item.label, item.page, item.key],
    })),
    {
      id: 'dashboard-home',
      label: 'Resumo geral',
      page: 'dashboard.html',
      icon: '⌂',
      type: 'Dashboard',
      keywords: ['dashboard', 'resumo', 'inicio', 'home'],
    },
    {
      id: 'pos-shortcut',
      label: 'Abrir POS',
      page: 'pos.html',
      icon: '◫',
      type: 'Operação',
      keywords: ['pos', 'venda', 'caixa', 'pedido'],
    },
    {
      id: 'stock-shortcut',
      label: 'Estoque',
      page: 'stock.html',
      icon: '▤',
      type: 'Operação',
      keywords: ['estoque', 'stock', 'produtos', 'mercadoria'],
    },
  ];
}

export function openCommandPalette() {
  const overlay = document.getElementById(paletteId);
  if (!overlay) return;

  overlay.classList.remove('hidden');
  const input = overlay.querySelector('input');
  if (input) {
    input.value = '';
    input.focus();
    const list = overlay.querySelector('.cmdk-list');
    if (list) {
      list.innerHTML = renderCommandItems('');
    }
  }
}

export function closeCommandPalette() {
  const overlay = document.getElementById(paletteId);
  if (!overlay) return;
  overlay.classList.add('hidden');
}

function renderCommandItems(query = '') {
  const cleanQuery = query.trim().toLowerCase();
  const entries = getPaletteItems().filter((item) => {
    if (!cleanQuery) return true;
    const haystack = `${item.label} ${item.type} ${item.keywords.join(' ')}`.toLowerCase();
    return haystack.includes(cleanQuery);
  });

  if (!entries.length) {
    return '<div class="cmdk-empty">Nenhum resultado encontrado.</div>';
  }

  return entries.map((item, index) => `
    <div class="cmdk-item ${index === 0 ? 'sel' : ''}" data-page="${item.page}">
      <div class="ico">${item.icon}</div>
      <div>
        <div>${item.label}</div>
        <small style="color:var(--muted);">${item.type}</small>
      </div>
      <span class="kbd">↵</span>
    </div>
  `).join('');
}

export function initCommandPalette() {
  if (document.getElementById(paletteId) || window.__barosCommandPaletteReady) return;
  window.__barosCommandPaletteReady = true;

  const overlay = document.createElement('div');
  overlay.id = paletteId;
  overlay.className = 'cmdk-overlay hidden';

  overlay.innerHTML = `
    <div class="cmdk" role="dialog" aria-modal="true" aria-label="Paleta de comandos">
      <div class="cmdk-input">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
          <path d="M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Zm0 0 9 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <input type="text" aria-label="Pesquisar comandos" placeholder="Procure páginas, vendas ou produtos..." />
      </div>
      <div class="cmdk-list">${renderCommandItems('')}</div>
    </div>
  `;

  document.body.appendChild(overlay);

  const input = overlay.querySelector('input');
  const list = overlay.querySelector('.cmdk-list');

  input?.addEventListener('input', (event) => {
    list.innerHTML = renderCommandItems(event.target.value);
    const first = list.querySelector('.cmdk-item');
    if (first) {
      first.classList.add('sel');
    }
  });

  overlay.addEventListener('click', (event) => {
    const target = event.target;
    if (target === overlay) {
      closeCommandPalette();
      return;
    }

    const item = event.target.closest('.cmdk-item');
    if (item) {
      const page = item.dataset.page;
      if (page) {
        closeCommandPalette();
        window.location.href = `./${page}`;
      }
    }
  });

  input?.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeCommandPalette();
      return;
    }

    if (event.key === 'Enter') {
      const selected = list.querySelector('.cmdk-item.sel') || list.querySelector('.cmdk-item');
      const page = selected?.dataset.page;
      if (page) {
        closeCommandPalette();
        window.location.href = `./${page}`;
      }
    }
  });

  document.addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      if (overlay.classList.contains('hidden')) {
        openCommandPalette();
      } else {
        closeCommandPalette();
      }
    }
  });
}
