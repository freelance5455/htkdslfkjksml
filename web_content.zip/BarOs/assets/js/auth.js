import { APP_CONFIG } from './config.js';
import { safeStorage } from './storage.js';
import { loginUser, getUsers, logEvent } from './db.js';
import { showToast } from './ui.js';

function normalizeUserIdentifier(value = '') {
  return String(value ?? '').trim().toLowerCase();
}

export function getSession() {
  return safeStorage.get('session', null);
}

export function setSession(user) {
  const session = {
    userId: user.id,
    user: user.user,
    name: user.name,
    role: user.role,
    active: user.active,
    loginAt: new Date().toISOString(),
  };

  safeStorage.set('session', session);
  return session;
}

export function clearSession() {
  safeStorage.remove('session');
}

export function isAuthenticated() {
  return !!getSession();
}

export function requireAuth(redirectPage = './login.html') {
  const session = getSession();
  if (!session) {
    window.location.href = redirectPage;
    return false;
  }
  return session;
}

export function requireRole(allowedRoles = []) {
  const session = getSession();
  if (!session) return false;
  if (!allowedRoles.length) return true;
  return allowedRoles.includes(session.role);
}

export function tryLogin(formData) {
  const result = loginUser(formData);
  if (!result.ok) {
    showToast(result.message, 'error');
    return false;
  }

  setSession(result.user);
  logEvent({
    user: result.user.user,
    action: 'login',
    level: 'info',
    message: `Login do utilizador ${result.user.name}`,
  });

  showToast('Login efetuado com sucesso.', 'success');
  return true;
}

export function logoutUser() {
  const session = getSession();
  if (session) {
    logEvent({
      user: session.user,
      action: 'logout',
      level: 'info',
      message: `Logout do utilizador ${session.name}`,
    });
  }

  clearSession();
  window.location.href = './login.html';
}

export function getCurrentUser() {
  return getSession();
}

export function ensureInitialSetup() {
  const users = getUsers();
  return users.some((user) => user.role === 'admin' && user.active);
}

export function createUserAccount(payload = {}) {
  const name = String(payload.name || '').trim();
  const rawUser = String(payload.user || '').trim();
  const pass = String(payload.pass || '').trim();
  const role = String(payload.role || 'estoquista').trim();
  const user = normalizeUserIdentifier(rawUser);

  if (!name || !user || !pass) {
    return { ok: false, message: 'Preencha nome, utilizador e palavra-passe.' };
  }

  if (pass.length < 4) {
    return { ok: false, message: 'A palavra-passe deve ter pelo menos 4 caracteres.' };
  }

  const safeRole = ['admin', 'gerente', 'caixa', 'estoquista'].includes(role) ? role : 'estoquista';

  const db = safeStorage.get('db', {});
  const target = db && Array.isArray(db.users) ? db : { users: [] };
  const exists = target.users.some((item) => normalizeUserIdentifier(item.user) === user);

  if (exists) {
    return { ok: false, message: 'Este utilizador já existe.' };
  }

  const nextUser = {
    id: crypto.randomUUID(),
    name,
    user,
    pass,
    role: safeRole,
    active: true,
    created: new Date().toISOString(),
  };

  target.users = [nextUser, ...target.users];
  safeStorage.set('db', target);

  logEvent({
    user: 'Sistema',
    action: 'create_user',
    level: 'info',
    message: `Utilizador ${user} criado com perfil ${safeRole}`,
  });

  return { ok: true, user: nextUser };
}

export function setupInitialAdmin(payload) {
  const rawUser = String(payload.user || '').trim();
  const pass = String(payload.pass || '').trim();
  const name = String(payload.name || '').trim();
  const user = normalizeUserIdentifier(rawUser);

  if (!name || !user || !pass) {
    return { ok: false, message: 'Preencha todos os campos para criar o administrador.' };
  }

  if (pass.length < 4) {
    return { ok: false, message: 'A palavra-passe deve ter pelo menos 4 caracteres.' };
  }

  const users = getUsers();
  const exists = users.some((item) => normalizeUserIdentifier(item.user) === user);
  if (exists) {
    return { ok: false, message: 'Este utilizador já existe.' };
  }

  const admin = {
    id: crypto.randomUUID(),
    name,
    user,
    pass,
    role: 'admin',
    active: true,
    created: new Date().toISOString(),
  };

  const freshDb = {
    company: {
      name: 'BarOS',
      tradeName: 'BarOS',
      owner: name,
      nif: '',
      registry: '',
      address: '',
      city: '',
      province: '',
      phone: '',
      whatsapp: '',
      email: '',
      website: '',
      logo: '',
      slogan: 'Gestão simples do bar.',
      currency: 'AOA',
      taxName: 'IVA',
      taxRate: 0,
      invoiceSeries: 'B',
      invoiceStart: 1,
      lowStockAlert: 10,
      expiryAlert: 30,
      autolockMin: 10,
    },
    users: [admin],
    products: [],
    movements: [],
    sales: [],
    saleItems: [],
    customers: [],
    cashSessions: [],
    cashMovements: [],
    logs: [{ id: crypto.randomUUID(), date: new Date().toISOString(), user: user, action: 'setup', level: 'info', message: 'Sistema iniciado do zero.' }],
    notifications: [],
    tables: [],
    carts: [],
    cartItems: [],
  };

  safeStorage.set('db', freshDb);
  safeStorage.remove('session');
  return { ok: true, user: admin };
}

export function applyTheme(theme = 'light') {
  document.documentElement.setAttribute('data-theme', theme);
  safeStorage.set('theme', theme);
}

export function loadTheme() {
  const theme = safeStorage.get('theme', 'light');
  applyTheme(theme);
  return theme;
}
