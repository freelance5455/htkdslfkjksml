import { getCurrentUser } from '../auth.js';
import { getDatabase } from '../db.js';
import { money } from '../ui.js';

function getRows() {
  const db = getDatabase();
  if (!db.customers || !db.customers.length) return [];
  return db.customers;
}

function renderClients() {
  const view = document.getElementById('view');
  if (!view) return;

  const rows = getRows();
  const user = getCurrentUser();
  const tableHtml = rows.length
    ? `
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Nome</th><th>NIF</th><th>Telefone</th><th>Crédito</th></tr>
          </thead>
          <tbody>
            ${rows.map((row) => `
              <tr>
                <td>${row.name}</td>
                <td>${row.nif}</td>
                <td>${row.phone}</td>
                <td><strong>${money(row.credit || 0)}</strong></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `
    : `
      <div class="empty-state">
        <p>Ainda não há clientes registados. O sistema começa do zero.</p>
      </div>
    `;

  view.innerHTML = `
    <div class="card">
      <div class="card-head">
        <h3>Clientes</h3>
        <div class="right">
          <button type="button" class="btn btn-primary btn-sm">Novo cliente</button>
          <span class="tag tag-info">${user?.role || 'caixa'}</span>
        </div>
      </div>
      <div class="card-body">
        <div class="grid kpis" style="margin-bottom:16px;">
          <article class="kpi"><div class="k-label">Total</div><div class="k-value">${rows.length}</div></article>
          <article class="kpi"><div class="k-label">Crédito</div><div class="k-value">${money(rows.reduce((sum, row) => sum + Number(row.credit || 0), 0))}</div></article>
        </div>

        ${tableHtml}
      </div>
    </div>
  `;
}

window.addEventListener('DOMContentLoaded', renderClients);
