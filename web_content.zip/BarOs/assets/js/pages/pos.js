import { getCurrentUser } from '../auth.js';
import { getDatabase } from '../db.js';
import { safeStorage } from '../storage.js';
import { money } from '../ui.js';

const CART_KEY = 'pos-cart';

function getProducts() {
  const db = getDatabase();
  return (db.products && db.products.length ? db.products : []);
}

function buildCart() {
  const cart = safeStorage.get(CART_KEY, []);
  return Array.isArray(cart) ? cart : [];
}

function renderPos() {
  const view = document.getElementById('view');
  if (!view) return;

  const user = getCurrentUser();
  const products = getProducts();
  const cart = buildCart();
  const subtotal = cart.reduce((sum, item) => sum + item.qty * item.price, 0);

  const productHtml = products.length
    ? products.map((product) => `
        <div class="prod-card" data-id="${product.id}" style="--cat-color:#f59e0b">
          <div class="pcat">${product.category || 'Geral'}</div>
          <div class="pname">${product.name}</div>
          <div class="pprice">${money(product.price)}</div>
          <div class="pstock">Estoque: ${product.stock ?? 0}</div>
          <button type="button" class="btn btn-primary btn-sm" data-add="${product.id}">Adicionar</button>
        </div>
      `).join('')
    : `<div class="empty-state"><p>Sem produtos em stock. Comece por preencher o inventário.</p></div>`;

  const cartHtml = cart.length
    ? cart.map((item) => `
        <div class="cart-line">
          <div class="ci-info">
            <div class="ci-name">${item.name}</div>
            <div class="ci-price">${money(item.price)}</div>
          </div>
          <div class="qty">
            <button type="button" data-action="decrease" data-id="${item.id}">-</button>
            <span>${item.qty}</span>
            <button type="button" data-action="increase" data-id="${item.id}">+</button>
          </div>
          <div class="ci-total">${money(item.qty * item.price)}</div>
        </div>
      `).join('')
    : `<div class="empty-state"><p>O carrinho está vazio.</p></div>`;

  view.innerHTML = `
    <div class="card">
      <div class="card-head">
        <h3>Ponto de venda</h3>
        <div class="right">
          <button type="button" class="btn btn-primary btn-sm">Nova venda</button>
          <span class="tag tag-info">${user?.role || 'caixa'}</span>
        </div>
      </div>
      <div class="card-body">
        <div class="pos">
          <div>
            <div class="toolbar">
              <div class="search">
                <input class="input" type="text" placeholder="Pesquisar produto..." />
              </div>
            </div>
            <div class="prod-grid">
              ${productHtml}
            </div>
          </div>

          <aside class="cart">
            <div class="cart-head">
              <h3>Carrinho</h3>
              <button type="button" class="btn btn-ghost btn-sm">Mesa 3</button>
            </div>
            <div class="cart-items">
              ${cartHtml}
            </div>
            <div class="cart-foot">
              <div class="sum-row"><span>Subtotal</span><strong>${money(subtotal)}</strong></div>
              <div class="sum-row"><span>Desconto</span><strong>${money(0)}</strong></div>
              <div class="sum-row total"><span>Total</span><strong>${money(subtotal)}</strong></div>
              <div style="display:flex;gap:8px;margin-top:12px;">
                <button type="button" class="btn btn-ghost btn-block">Guardar</button>
                <button type="button" class="btn btn-primary btn-block">Pagar</button>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  `;

  view.querySelectorAll('[data-add]').forEach((button) => {
    button.addEventListener('click', () => {
      const productId = button.dataset.add;
      const product = products.find((item) => item.id === productId);
      if (!product) return;
      const existing = cart.find((item) => item.id === productId);
      if (existing) existing.qty += 1;
      else cart.push({ id: product.id, name: product.name, qty: 1, price: Number(product.price) || 0 });
      safeStorage.set(CART_KEY, cart);
      renderPos();
    });
  });

  view.querySelectorAll('[data-action]').forEach((button) => {
    button.addEventListener('click', () => {
      const productId = button.dataset.id;
      const item = cart.find((entry) => entry.id === productId);
      if (!item) return;

      if (button.dataset.action === 'increase') item.qty += 1;
      if (button.dataset.action === 'decrease') item.qty = Math.max(0, item.qty - 1);

      if (item.qty === 0) {
        const index = cart.findIndex((entry) => entry.id === productId);
        if (index >= 0) cart.splice(index, 1);
      }

      safeStorage.set(CART_KEY, cart);
      renderPos();
    });
  });
}

window.addEventListener('DOMContentLoaded', renderPos);
