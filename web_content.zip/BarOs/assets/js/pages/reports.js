import { getCurrentUser } from '../auth.js';
import { money } from '../ui.js';

async function renderReports() {
  const view = document.getElementById('view');
  if (!view) return;

  const user = getCurrentUser();

  view.innerHTML = `
    <div class="grid g2">
      <div class="card">
        <div class="card-head">
          <h3>Relatórios</h3>
          <div class="right"><span class="tag tag-info">${user?.role || 'gerente'}</span></div>
        </div>
        <div class="card-body">
          <div class="grid kpis">
            <article class="kpi"><div class="k-label">Diário</div><div class="k-value">${money(1200)}</div></article>
            <article class="kpi"><div class="k-label">Mensal</div><div class="k-value">${money(32000)}</div></article>
            <article class="kpi"><div class="k-label">Lucro</div><div class="k-value">${money(7000)}</div></article>
            <article class="kpi"><div class="k-label">Taxas</div><div class="k-value">${money(2300)}</div></article>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>Faturamento</h3></div>
        <div class="card-body">
          <div class="chart-box">
            <canvas id="report-chart" width="600" height="250"></canvas>
          </div>
        </div>
      </div>
    </div>
  `;

  const canvas = document.getElementById('report-chart');
  if (canvas) {
    const { renderTrendChart } = await import('../charts.js');
    renderTrendChart(canvas, ['Jan', 'Fev', 'Mar', 'Abr', 'Mai'], [420, 510, 480, 700, 890]);
  }
}

window.addEventListener('DOMContentLoaded', async () => {
  await renderReports();
});
