import { getCurrentUser } from '../auth.js';
import { getDatabase, saveDatabase } from '../db.js';
import { showToast } from '../ui.js';
import {
  chooseBackupFolder,
  downloadBackup,
  getBackupStatus,
  restoreBackupFile,
} from '../backup.js';

function backupStatusMessage(status) {
  if (status.state === 'connected') return 'A cópia na pasta está ativa.';
  if (status.state === 'permission-required') return 'Toque em “Escolher pasta” para voltar a permitir o acesso.';
  if (status.state === 'unsupported') return 'Este navegador não permite escolher pastas. Use exportar/importar cópia.';
  if (status.state === 'error') return `Erro na cópia: ${status.error}`;
  if (status.state === 'checking') return 'A verificar a cópia de segurança...';
  return 'Sem pasta escolhida. Os dados continuam guardados neste dispositivo.';
}

function renderCompany() {
  const view = document.getElementById('view');
  if (!view) return;

  const user = getCurrentUser();
  const company = getDatabase().company || {};

  view.innerHTML = `
    <div class="card">
      <div class="card-head">
        <h3>Configuração da empresa</h3>
        <div class="right"><span class="tag tag-info">${user?.role || 'gerente'}</span></div>
      </div>
      <div class="card-body">
        <section class="backup-settings" aria-labelledby="backup-title">
          <h3 id="backup-title">Dados neste dispositivo</h3>
          <p>O BarOS guarda os dados neste navegador. Pode também manter uma cópia JSON numa pasta escolhida; essa cópia inclui os dados e utilizadores do sistema.</p>
          <p id="backup-status" role="status">${backupStatusMessage(getBackupStatus())}</p>
          <div class="backup-actions">
            <button type="button" class="btn btn-ghost" id="backup-folder">Escolher pasta</button>
            <button type="button" class="btn btn-ghost" id="backup-download">Exportar cópia</button>
            <button type="button" class="btn btn-ghost" id="backup-restore">Importar cópia</button>
            <input type="file" id="backup-file" accept="application/json,.json" hidden />
          </div>
          <p class="backup-warning">A cópia contém dados e palavras-passe de utilizadores sem encriptação. Guarde-a numa pasta privada e não a partilhe.</p>
        </section>
        <form id="company-form">
          <div class="form-grid">
            <div class="field"><label>Nome</label><input class="input" name="name" value="${company.name || 'BarOS'}" /></div>
            <div class="field"><label>Trade name</label><input class="input" name="tradeName" value="${company.tradeName || 'BarOS'}" /></div>
            <div class="field"><label>Telefone</label><input class="input" name="phone" value="${company.phone || '912345678'}" /></div>
            <div class="field"><label>Email</label><input class="input" name="email" value="${company.email || 'hello@baros.pt'}" /></div>
            <div class="field full"><label>Morada</label><input class="input" name="address" value="${company.address || 'Rua da Praça, 12'}" /></div>
          </div>
          <div style="margin-top:16px; display:flex; justify-content:flex-end;">
            <button type="submit" class="btn btn-primary">Guardar alterações</button>
          </div>
        </form>
      </div>
    </div>
  `;

  const form = document.getElementById('company-form');
  const backupStatus = document.getElementById('backup-status');
  const updateBackupStatus = (status) => {
    if (backupStatus) backupStatus.textContent = backupStatusMessage(status);
  };

  window.addEventListener('baros:backup-status', (event) => updateBackupStatus(event.detail));

  document.getElementById('backup-folder')?.addEventListener('click', async () => {
    const result = await chooseBackupFolder();
    if (result.ok) {
      showToast('Cópia de segurança criada na pasta escolhida.', 'success');
    } else if (result.message) {
      showToast(result.message, 'error');
    }
  });

  document.getElementById('backup-download')?.addEventListener('click', () => {
    downloadBackup();
    showToast('Cópia de segurança exportada.', 'success');
  });

  const backupFile = document.getElementById('backup-file');
  document.getElementById('backup-restore')?.addEventListener('click', () => backupFile?.click());
  backupFile?.addEventListener('change', async () => {
    const file = backupFile.files?.[0];
    if (!file) return;
    if (!window.confirm('Importar esta cópia irá substituir os dados BarOS guardados neste navegador. Continuar?')) {
      backupFile.value = '';
      return;
    }

    try {
      await restoreBackupFile(file);
      showToast('Cópia importada. A atualizar o BarOS...', 'success');
      window.setTimeout(() => window.location.reload(), 400);
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'Não foi possível importar a cópia.', 'error');
    } finally {
      backupFile.value = '';
    }
  });

  form?.addEventListener('submit', (event) => {
    event.preventDefault();
    const formData = new FormData(form);
    const db = getDatabase();
    db.company = {
      ...db.company,
      name: formData.get('name') || 'BarOS',
      tradeName: formData.get('tradeName') || 'BarOS',
      phone: formData.get('phone') || '',
      email: formData.get('email') || '',
      address: formData.get('address') || '',
    };

    saveDatabase(db);
    showToast('Dados da empresa guardados.', 'success');
  });
}

window.addEventListener('DOMContentLoaded', renderCompany);
