import { getCurrentUser } from '../auth.js';
import { getDatabase } from '../db.js';
import { money } from '../ui.js';

const badges = {
  admin: 'Administrador',
  gerente: 'Gerente',
  caixa: 'Caixa',
  estoquista: 'Estoquista',
};

const quickActionsByRole = {
  admin: [
    { label: 'Abrir caixa', href: 'cash.html', icon: '◭' },
    { label: 'Ver estoque', href: 'stock.html', icon: '▤' },
    { label: 'Relatórios', href: 'reports.html', icon: '▥' },
  ],
  gerente: [
    { label: 'POS', href: 'pos.html', icon: '◫' },
    { label: 'Mesas', href: 'tables.html', icon: '▣' },
    { label: 'Clientes', href: 'clients.html', icon: '◎' },
  ],
  caixa: [
    { label: 'Nova venda', href: 'pos.html', icon: '◫' },
    { label: 'Fechar caixa', href: 'cash.html', icon: '◭' },
    { label: 'Clientes', href: 'clients.html', icon: '◎' },
  ],
  estoquista: [
    { label: 'Estoque', href: 'stock.html', icon: '▤' },
    { label: 'Produtos', href: 'stock.html', icon: '▥' },
    { label: 'Relatório', href: 'reports.html', icon: '☰' },
  ],
};

function getActivityFeed(role, db) {
  const salesCount = Array.isArray(db.sales) ? db.sales.length : 0;
  const lowStockCount = Array.isArray(db.products)
    ? db.products.filter((product) => Number(product.qty ?? product.stock ?? 0) < 10).length
    : 0;

  const base = [
    {
      icon: '✓',
      tone: 'tag-ok',
      text: salesCount ? 'A primeira venda ainda está por registar.' : 'Ainda não existem vendas registadas.',
      detail: salesCount ? `há ${salesCount} venda(s) no sistema` : 'comece por preencher o stock',
    },
    {
      icon: '▤',
      tone: 'tag-info',
      text: lowStockCount ? `${lowStockCount} itens abaixo do mínimo` : 'Nenhum item em alerta de stock',
      detail: lowStockCount ? 'revise o inventário' : 'o stock pode começar do zero',
    },
  ];

  if (role === 'caixa') {
    return [
      { icon: '◭', tone: 'tag-ok', text: 'Caixa pronta para começar o turno', detail: 'abertura manual' },
      { icon: '◎', tone: 'tag-info', text: 'Sem clientes registados ainda', detail: 'adicione clientes' },
    ];
  }

  if (role === 'estoquista') {
    return [
      { icon: '▤', tone: 'tag-warn', text: 'Inventário ainda em branco', detail: 'adicione produtos' },
      { icon: '☰', tone: 'tag-info', text: 'Sistema preparado para o primeiro stock', detail: 'comece do zero' },
    ];
  }

  return base;
}

function renderDashboard() {
  const currentUser = getCurrentUser();
  const view = document.getElementById('view');

  if (!view) return;

  const db = getDatabase();
  const role = currentUser?.role || 'admin';
  const isAdmin = role === 'admin';
  const salesTotal = Array.isArray(db.sales) ? db.sales.length : 0;
  const revenueTotal = Array.isArray(db.sales)
    ? db.sales.reduce((sum, sale) => sum + Number(sale.total || 0), 0)
    : 0;
  const clientCount = Array.isArray(db.customers) ? db.customers.length : 0;
  const lowStockCount = Array.isArray(db.products)
    ? db.products.filter((product) => Number(product.qty ?? product.stock ?? 0) < 10).length
    : 0;

  const cards = [
    { label: 'Receitas hoje', value: money(revenueTotal), delta: salesTotal ? '+100%' : '0%', tone: 'bg-brand' },
    { label: 'Vendas', value: String(salesTotal), delta: salesTotal ? '+100%' : '0%', tone: 'bg-accent' },
    { label: 'Clientes', value: String(clientCount), delta: clientCount ? '+100%' : '0%', tone: 'bg-ok' },
    { label: 'Estoque baixo', value: String(lowStockCount), delta: lowStockCount ? '-3.2%' : '0%', tone: 'bg-danger' },
  ];

  const itemsHtml = cards.map((card) => `
    <article class="kpi">
      <div class="k-top">
        <div class="k-label">${card.label}</div>
        <div class="k-ico ${card.tone}">★</div>
      </div>
      <div class="k-value">${card.value}</div>
      <div class="k-delta ${card.delta.startsWith('-') ? 'down' : 'up'}">${card.delta}</div>
    </article>
  `).join('');

  const actions = (quickActionsByRole[role] || quickActionsByRole.admin)
    .map((action) => `
      <a class="btn btn-ghost" href="${action.href}">
        <span>${action.icon}</span>
        <span>${action.label}</span>
      </a>
    `)
    .join('');

  const feedHtml = getActivityFeed(role, db)
    .map((item) => `
      <div class="feed-item">
        <div class="ico ${item.tone}">${item.icon}</div>
        <div class="txt">
          <strong>${item.text}</strong>
          <span>${item.detail}</span>
        </div>
      </div>
    `)
    .join('');

  const rolePanel = isAdmin
    ? `
      <div class="card">
        <div class="card-head">
          <h3>Resumo administrativo</h3>
        </div>
        <div class="card-body">
          <div class="grid kpis">
            ${itemsHtml}
          </div>
        </div>
      </div>
    `
    : `
      <div class="card">
        <div class="card-head">
          <h3>Resumo do perfil</h3>
        </div>
        <div class="card-body">
          <p>Bem-vindo, <strong>${currentUser?.name || 'Utilizador'}</strong>.</p>
          <p>Perfil atual: <span class="tag tag-info">${badges[role] || role}</span></p>
          <div class="stack" style="margin-top:16px;">${actions}</div>
        </div>
      </div>
    `;

  view.innerHTML = `
    <div class="grid two-col">
      <div class="card">
        <div class="card-head">
          <h3>Dashboard</h3>
          <div class="right">
            <span class="tag tag-info">${badges[role] || role}</span>
          </div>
        </div>
        <div class="card-body">
          <p>Olá, ${currentUser?.name || 'Utilizador'}.</p>
          <p>Hoje é ${new Date().toLocaleDateString('pt-PT', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}.</p>
          <div class="stack" style="margin-top:16px;">${actions}</div>
        </div>
      </div>

      ${rolePanel}
    </div>

    <div class="grid two-col" style="margin-top:18px;">
      <div class="card">
        <div class="card-head">
          <h3>Atividade recente</h3>
        </div>
        <div class="card-body">
          <div class="feed">${feedHtml}</div>
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <h3>Próximo foco</h3>
        </div>
        <div class="card-body">
          <ul class="stack checklist" style="list-style:none;">
            <li><span class="tag tag-ok">1</span> Confirmar pedidos pendentes das mesas 4 e 7.</li>
            <li><span class="tag tag-warn">2</span> Repor stock de cerveja e lanches.</li>
            <li><span class="tag tag-info">3</span> Revisar contas de clientes com atraso.</li>
          </ul>
        </div>
      </div>
    </div>
  `;
}

window.addEventListener('DOMContentLoaded', () => {
  renderDashboard();
});
