import { getCurrentUser } from '../auth.js';
import { getDatabase } from '../db.js';

const fallbackTables = [
  { id: 1, name: 'Mesa 1', status: 'livre', clients: 2 },
  { id: 2, name: 'Mesa 2', status: 'ocupada', clients: 4 },
  { id: 3, name: 'Mesa 3', status: 'ocupada', clients: 3 },
  { id: 4, name: 'Mesa 4', status: 'livre', clients: 2 },
  { id: 5, name: 'Mesa 5', status: 'ocupada', clients: 5 },
  { id: 6, name: 'Mesa 6', status: 'livre', clients: 2 },
];

function getTables() {
  const db = getDatabase();
  return (db.tables && db.tables.length ? db.tables : fallbackTables);
}

function renderTables() {
  const view = document.getElementById('view');
  if (!view) return;

  const user = getCurrentUser();
  const tables = getTables();

  view.innerHTML = `
    <div class="card">
      <div class="card-head">
        <h3>Gestão de mesas</h3>
        <div class="right"><span class="tag tag-info">${user?.role || 'gerente'}</span></div>
      </div>
      <div class="card-body">
        <div class="grid g3">
          ${tables.map((table) => `
            <div class="card">
              <div class="card-head">
                <h3>${table.name || `Mesa ${table.id}`}</h3>
                <span class="tag ${table.status === 'livre' ? 'tag-ok' : 'tag-warn'}">${table.status === 'livre' ? 'Livre' : 'Ocupada'}</span>
              </div>
              <div class="card-body">
                <p>Clientes: ${table.clients || 0}</p>
                <p>Estado: ${table.status === 'livre' ? 'Disponível' : 'Em serviço'}</p>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

window.addEventListener('DOMContentLoaded', renderTables);
