import { getCurrentUser } from '../auth.js';
import { money } from '../ui.js';

function renderCash() {
  const view = document.getElementById('view');
  if (!view) return;

  const user = getCurrentUser();

  const metrics = [
    { label: 'Abertura', value: 150 },
    { label: 'Receita', value: 845.6 },
    { label: 'Sangria', value: 60 },
    { label: 'Fecho', value: 935.6 },
  ];

  const movements = [
    { type: 'Reforço', value: 50, note: 'Entrada de início de turno' },
    { type: 'Venda', value: 320, note: 'Pedido 140' },
    { type: 'Sangria', value: 25, note: 'Retirada' },
    { type: 'Pagamento', value: 58.4, note: 'Mesa 5' },
  ];

  view.innerHTML = `
    <div class="grid g2">
      <div class="card">
        <div class="card-head">
          <h3>Controle de caixa</h3>
          <div class="right"><span class="tag tag-info">${user?.role || 'caixa'}</span></div>
        </div>
        <div class="card-body">
          <div class="grid kpis">
            ${metrics.map((metric) => `
              <article class="kpi"><div class="k-label">${metric.label}</div><div class="k-value">${money(metric.value)}</div></article>
            `).join('')}
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <h3>Movimentos</h3>
        </div>
        <div class="card-body">
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Tipo</th><th>Valor</th><th>Nota</th></tr>
              </thead>
              <tbody>
                ${movements.map((movement) => `
                  <tr>
                    <td>${movement.type}</td>
                    <td>${money(movement.value)}</td>
                    <td>${movement.note}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `;
}

window.addEventListener('DOMContentLoaded', renderCash);
