import { createUserAccount, getCurrentUser } from '../auth.js';
import { getDatabase } from '../db.js';
import { showToast } from '../ui.js';

const fallbackRows = [
  { name: 'Administrador', user: 'admin', role: 'admin', active: true },
  { name: 'João', user: 'gerente', role: 'gerente', active: true },
  { name: 'Maria', user: 'caixa', role: 'caixa', active: true },
  { name: 'Pedro', user: 'estoquista', role: 'estoquista', active: true },
];

function escapeHtml(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function getRows() {
  const db = getDatabase();
  if (db.users && db.users.length) return db.users;
  return fallbackRows;
}

function bindCreateUserForm() {
  const form = document.getElementById('user-create-form');
  if (!form) return;

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    const payload = {
      name: document.getElementById('create-user-name')?.value || '',
      user: document.getElementById('create-user-user')?.value || '',
      pass: document.getElementById('create-user-pass')?.value || '',
      role: document.getElementById('create-user-role')?.value || 'estoquista',
    };

    const result = createUserAccount(payload);
    if (!result.ok) {
      showToast(result.message, 'error');
      return;
    }

    form.reset();
    showToast('Utilizador criado com sucesso.', 'success');
    renderUsers();
  });
}

function renderUsers() {
  const view = document.getElementById('view');
  if (!view) return;

  const rows = getRows();
  const user = getCurrentUser();
  const isAdmin = user?.role === 'admin';

  view.innerHTML = `
    <div class="card">
      <div class="card-head">
        <h3>Utilizadores</h3>
        <div class="right">
          <button type="button" class="btn btn-primary btn-sm" id="new-user-button" ${isAdmin ? '' : 'disabled'}>
            Novo utilizador
          </button>
          <span class="tag tag-info">${escapeHtml(user?.role || 'admin')}</span>
        </div>
      </div>
      <div class="card-body">
        ${isAdmin ? `
          <form id="user-create-form" class="stack" style="margin-bottom: 1rem; display: none;">
            <div class="form-grid">
              <div class="field">
                <label for="create-user-name">Nome completo</label>
                <input id="create-user-name" class="input" type="text" placeholder="Ex.: Ana Pereira" required />
              </div>
              <div class="field">
                <label for="create-user-user">Utilizador</label>
                <input id="create-user-user" class="input" type="text" placeholder="Ex.: ana.pereira" required />
              </div>
              <div class="field">
                <label for="create-user-pass">Palavra-passe</label>
                <input id="create-user-pass" class="input" type="password" placeholder="Crie uma palavra-passe" required />
              </div>
              <div class="field">
                <label for="create-user-role">Perfil</label>
                <select id="create-user-role" class="input">
                  <option value="admin">Administrador</option>
                  <option value="gerente">Gerente</option>
                  <option value="caixa">Caixa</option>
                  <option value="estoquista">Estoquista</option>
                </select>
              </div>
            </div>
            <div class="right">
              <button type="submit" class="btn btn-primary">Guardar utilizador</button>
            </div>
          </form>
        ` : ''}

        <div class="table-wrap">
          <table>
            <thead><tr><th>Nome</th><th>Utilizador</th><th>Perfil</th><th>Estado</th></tr></thead>
            <tbody>
              ${rows.map((row) => `
                <tr>
                  <td>${escapeHtml(row.name)}</td>
                  <td>${escapeHtml(row.user)}</td>
                  <td>${escapeHtml(row.role)}</td>
                  <td><span class="tag ${row.active ? 'tag-ok' : 'tag-danger'}">${row.active ? 'Ativo' : 'Inativo'}</span></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;

  if (isAdmin) {
    const button = document.getElementById('new-user-button');
    const form = document.getElementById('user-create-form');
    button?.addEventListener('click', () => {
      if (!form) return;
      const isHidden = form.style.display === 'none';
      form.style.display = isHidden ? 'block' : 'none';
    });
    bindCreateUserForm();
  }
}

window.addEventListener('DOMContentLoaded', renderUsers);
