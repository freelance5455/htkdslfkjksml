import { getCurrentUser } from '../auth.js';
import { getDatabase } from '../db.js';
import { money } from '../ui.js';

function getRows() {
  const db = getDatabase();
  if (!db.products || !db.products.length) return [];

  return db.products.map((product) => ({
    id: product.id,
    code: product.code || product.id.slice(0, 4).toUpperCase(),
    name: product.name,
    qty: Number(product.qty ?? product.stock ?? 0),
    price: Number(product.price ?? 0),
  }));
}

function renderStock() {
  const view = document.getElementById('view');
  if (!view) return;

  const user = getCurrentUser();
  const rows = getRows();

  const tableHtml = rows.length
    ? `
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Código</th>
              <th>Produto</th>
              <th>Qtd.</th>
              <th>Preço</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${rows.map((row) => `
              <tr>
                <td>${row.code}</td>
                <td>${row.name}</td>
                <td>${row.qty}</td>
                <td>${money(row.price)}</td>
                <td><span class="tag ${row.qty < 10 ? 'tag-warn' : 'tag-ok'}">${row.qty < 10 ? 'Baixo' : 'OK'}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `
    : `
      <div class="empty-state">
        <p>O stock está vazio. Comece por adicionar os primeiros produtos para faturar.</p>
      </div>
    `;

  view.innerHTML = `
    <div class="card">
      <div class="card-head">
        <h3>Estoque</h3>
        <div class="right">
          <button type="button" class="btn btn-primary btn-sm">Adicionar produto</button>
          <span class="tag tag-info">${user?.role || 'estoquista'}</span>
        </div>
      </div>
      <div class="card-body">
        <div class="grid kpis" style="margin-bottom:16px;">
          <article class="kpi"><div class="k-label">Produtos</div><div class="k-value">${rows.length}</div></article>
          <article class="kpi"><div class="k-label">Unidades</div><div class="k-value">${rows.reduce((sum, row) => sum + Number(row.qty || 0), 0)}</div></article>
          <article class="kpi"><div class="k-label">Valor</div><div class="k-value">${money(rows.reduce((sum, row) => sum + Number(row.qty || 0) * Number(row.price || 0), 0))}</div></article>
        </div>

        ${tableHtml}
      </div>
    </div>
  `;
}

window.addEventListener('DOMContentLoaded', renderStock);
