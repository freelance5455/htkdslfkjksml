import { getCurrentUser } from '../auth.js';
import { getDatabase } from '../db.js';

function getRows() {
  const db = getDatabase();
  if (!db.logs || !db.logs.length) return [];
  return db.logs;
}

function renderLogs() {
  const view = document.getElementById('view');
  if (!view) return;

  const rows = getRows();
  const user = getCurrentUser();
  const tableHtml = rows.length
    ? `
      <div class="table-wrap">
        <table>
          <thead><tr><th>Data</th><th>Utilizador</th><th>Ação</th><th>Nível</th></tr></thead>
          <tbody>
            ${rows.map((row) => {
              const level = String(row.level || 'info');
              const badgeClass = level === 'ok' ? 'tag-ok' : level === 'warn' ? 'tag-warn' : 'tag-info';
              return `
                <tr>
                  <td>${row.date || new Date().toLocaleDateString('pt-PT')}</td>
                  <td>${row.user || 'Sistema'}</td>
                  <td>${row.action || row.message || 'Evento'}</td>
                  <td><span class="tag ${badgeClass}">${level}</span></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `
    : `
      <div class="empty-state">
        <p>Não há eventos no sistema ainda. Tudo começa do zero.</p>
      </div>
    `;

  view.innerHTML = `
    <div class="card">
      <div class="card-head">
        <h3>Auditoria</h3>
        <div class="right"><span class="tag tag-info">${user?.role || 'gerente'}</span></div>
      </div>
      <div class="card-body">
        ${tableHtml}
      </div>
    </div>
  `;
}

window.addEventListener('DOMContentLoaded', renderLogs);
