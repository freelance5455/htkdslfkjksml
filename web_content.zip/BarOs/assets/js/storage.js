import { APP_CONFIG } from './config.js';
import { backupReady, scheduleFolderBackup } from './backup.js';

void backupReady;

export const safeStorage = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(`${APP_CONFIG.storagePrefix}:${key}`);
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch (error) {
      console.warn(`safeStorage.get(${key}) falhou:`, error);
      return fallback;
    }
  },

  set(key, value) {
    try {
      localStorage.setItem(`${APP_CONFIG.storagePrefix}:${key}`, JSON.stringify(value));
      scheduleFolderBackup();
      return true;
    } catch (error) {
      console.warn(`safeStorage.set(${key}) falhou:`, error);
      return false;
    }
  },

  remove(key) {
    try {
      localStorage.removeItem(`${APP_CONFIG.storagePrefix}:${key}`);
      scheduleFolderBackup();
      return true;
    } catch (error) {
      console.warn(`safeStorage.remove(${key}) falhou:`, error);
      return false;
    }
  },
};

export function readJson(key, fallback = null) {
  return safeStorage.get(key, fallback);
}

export function writeJson(key, value) {
  return safeStorage.set(key, value);
}
