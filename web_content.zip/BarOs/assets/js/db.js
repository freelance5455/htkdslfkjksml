import { APP_CONFIG } from './config.js';
import { safeStorage } from './storage.js';
import { initSupabaseClient } from './supabase.js';

const STORAGE_KEY = 'db';
const MODE_KEY = 'mode';

export function getSelectedMode() {
  const storedMode = safeStorage.get(MODE_KEY, 'local');
  return storedMode === 'supabase' && hasSupabaseConfig() ? 'supabase' : 'local';
}

export function setSelectedMode(mode = 'local') {
  const nextMode = mode === 'supabase' && hasSupabaseConfig() ? 'supabase' : 'local';
  safeStorage.set(MODE_KEY, nextMode);
  return nextMode;
}

export function hasSupabaseConfig() {
  return Boolean(APP_CONFIG.supabase?.url && APP_CONFIG.supabase?.anonKey);
}

export function connectSupabase() {
  if (!hasSupabaseConfig()) {
    return { ok: false, message: 'Configuração do Supabase em falta. Edite assets/js/config.js com url e anonKey válidas.' };
  }

  const client = initSupabaseClient(APP_CONFIG.supabase);
  if (!client) {
    return { ok: false, message: 'Não foi possível inicializar o cliente do Supabase.' };
  }

  return { ok: true, client };
}

function createEmptyDatabase() {
  const now = new Date().toISOString();

  return {
    company: {
      name: 'BarOS',
      tradeName: 'BarOS',
      owner: '',
      nif: '',
      registry: '',
      address: '',
      city: '',
      province: '',
      phone: '',
      whatsapp: '',
      email: '',
      website: '',
      logo: '',
      slogan: 'Gestão simples do bar.',
      currency: 'AOA',
      taxName: 'IVA',
      taxRate: 0,
      invoiceSeries: 'B',
      invoiceStart: 1,
      lowStockAlert: 10,
      expiryAlert: 30,
      autolockMin: 10,
    },
    users: [],
    products: [],
    movements: [],
    sales: [],
    saleItems: [],
    customers: [],
    cashSessions: [],
    cashMovements: [],
    logs: [
      { id: crypto.randomUUID(), date: now, user: 'Sistema', action: 'setup', level: 'info', message: 'Sistema iniciado do zero.' },
    ],
    notifications: [],
    tables: [],
    carts: [],
    cartItems: [],
  };
}

export function ensureDatabase() {
  const existing = safeStorage.get(STORAGE_KEY, null);

  if (!existing) {
    const seed = createEmptyDatabase();
    safeStorage.set(STORAGE_KEY, seed);
    return seed;
  }

  const base = createEmptyDatabase();
  const merged = {
    ...base,
    ...existing,
    company: { ...base.company, ...(existing.company || {}) },
    users: Array.isArray(existing.users) && existing.users.length ? existing.users : base.users,
    products: Array.isArray(existing.products) && existing.products.length ? existing.products : base.products,
    movements: Array.isArray(existing.movements) ? existing.movements : base.movements,
    sales: Array.isArray(existing.sales) ? existing.sales : base.sales,
    saleItems: Array.isArray(existing.saleItems) ? existing.saleItems : base.saleItems,
    customers: Array.isArray(existing.customers) && existing.customers.length ? existing.customers : base.customers,
    cashSessions: Array.isArray(existing.cashSessions) ? existing.cashSessions : base.cashSessions,
    cashMovements: Array.isArray(existing.cashMovements) ? existing.cashMovements : base.cashMovements,
    logs: Array.isArray(existing.logs) && existing.logs.length ? existing.logs : base.logs,
    notifications: Array.isArray(existing.notifications) && existing.notifications.length ? existing.notifications : base.notifications,
    tables: Array.isArray(existing.tables) && existing.tables.length ? existing.tables : base.tables,
    carts: Array.isArray(existing.carts) ? existing.carts : base.carts,
    cartItems: Array.isArray(existing.cartItems) ? existing.cartItems : base.cartItems,
  };

  safeStorage.set(STORAGE_KEY, merged);
  return merged;
}

export function getDatabase() {
  return ensureDatabase();
}

export function saveDatabase(data) {
  return safeStorage.set(STORAGE_KEY, data);
}

export function getUsers() {
  return getDatabase().users || [];
}

export function getProducts() {
  return getDatabase().products || [];
}

export function addProduct(product) {
  const db = getDatabase();
  const nextProduct = {
    id: product.id || crypto.randomUUID(),
    ...product,
    qty: Number(product.qty || 0),
    price: Number(product.price || 0),
    cost: Number(product.cost || 0),
  };
  db.products.push(nextProduct);
  saveDatabase(db);
  return nextProduct;
}

export function getCompany() {
  return getDatabase().company;
}

export function createSale(payload) {
  const db = getDatabase();
  const sale = {
    id: payload.id || crypto.randomUUID(),
    number: payload.number || `SV-${Date.now()}`,
    date: payload.date || new Date().toISOString(),
    subtotal: Number(payload.subtotal || 0),
    discount: Number(payload.discount || 0),
    total: Number(payload.total || 0),
    ivaRate: Number(payload.ivaRate || 0),
    customerId: payload.customerId || null,
    customerName: payload.customerName || 'Consumidor',
    operator: payload.operator || 'Sistema',
    operatorId: payload.operatorId || null,
    table: payload.table || null,
    status: payload.status || 'paid',
    channel: payload.channel || 'counter',
    items: payload.items || [],
  };

  db.sales.push(sale);
  saveDatabase(db);
  return sale;
}

function normalizeUserIdentifier(value = '') {
  return String(value ?? '').trim().toLowerCase();
}

export function loginUser({ user, pass }) {
  const users = getUsers();
  const normalizedUser = normalizeUserIdentifier(user);
  const normalizedPass = String(pass ?? '').trim();

  const match = users.find((item) => {
    const storedUser = normalizeUserIdentifier(item.user);
    const storedPass = String(item.pass ?? '').trim();
    return storedUser === normalizedUser && storedPass === normalizedPass;
  });

  if (!match) {
    return { ok: false, message: 'Credenciais inválidas.' };
  }

  if (!match.active) {
    return { ok: false, message: 'Utilizador inativo.' };
  }

  return { ok: true, user: { ...match, pass: undefined } };
}

export function logEvent({ user, action, level = 'info', message }) {
  const db = getDatabase();
  db.logs.push({
    id: crypto.randomUUID(),
    date: new Date().toISOString(),
    user: user || 'Sistema',
    action,
    level,
    message: message || action,
  });
  saveDatabase(db);
}

export const db = {
  mode: 'local',
  getProducts,
  addProduct,
  getUsers,
  getCompany,
  createSale,
  loginUser,
  logEvent,
};

export const supabaseDb = {
  mode: 'supabase',
  async connect() {
    return connectSupabase();
  },
  async getProducts() {
    return getProducts();
  },
  async addProduct(product) {
    return addProduct(product);
  },
  async getUsers() {
    return getUsers();
  },
  async createSale(payload) {
    return createSale(payload);
  },
};

if (!window.__barosDbSeeded) {
  window.__barosDbSeeded = true;
}

export const APP_MODE = getSelectedMode();
export const MODE_OPTIONS = {
  local: 'localStorage',
  supabase: 'Supabase',
};
