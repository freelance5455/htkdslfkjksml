import { APP_CONFIG } from './config.js';

const BACKUP_FILE = 'baros-backup.json';
const HANDLE_DB = 'baros-folder-backup';
const HANDLE_STORE = 'directories';
const HANDLE_KEY = 'data-folder';

let directoryHandle = null;
let backupState = 'checking';
let backupError = '';
let writeQueue = Promise.resolve();
let writeTimer = null;

function notifyStatus() {
  window.dispatchEvent(new CustomEvent('baros:backup-status', {
    detail: getBackupStatus(),
  }));
}

function setBackupState(state, error = '') {
  backupState = state;
  backupError = error;
  notifyStatus();
}

function openHandleDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(HANDLE_DB, 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore(HANDLE_STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Não foi possível guardar a pasta selecionada.'));
  });
}

async function storeDirectoryHandle(handle) {
  const database = await openHandleDatabase();
  await new Promise((resolve, reject) => {
    const transaction = database.transaction(HANDLE_STORE, 'readwrite');
    transaction.objectStore(HANDLE_STORE).put(handle, HANDLE_KEY);
    transaction.oncomplete = resolve;
    transaction.onerror = () => reject(transaction.error || new Error('Não foi possível guardar a pasta selecionada.'));
    transaction.onabort = () => reject(transaction.error || new Error('A gravação da pasta selecionada foi cancelada.'));
  });
  database.close();
}

async function readDirectoryHandle() {
  const database = await openHandleDatabase();
  const handle = await new Promise((resolve, reject) => {
    const request = database.transaction(HANDLE_STORE, 'readonly')
      .objectStore(HANDLE_STORE)
      .get(HANDLE_KEY);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error || new Error('Não foi possível ler a pasta guardada.'));
  });
  database.close();
  return handle;
}

function getSnapshot() {
  const prefix = `${APP_CONFIG.storagePrefix}:`;
  const entries = [];

  for (let index = 0; index < localStorage.length; index += 1) {
    const key = localStorage.key(index);
    if (key && key.startsWith(prefix)) {
      entries.push({ key, value: localStorage.getItem(key) });
    }
  }

  return {
    format: 'baros-backup',
    version: 1,
    savedAt: new Date().toISOString(),
    storagePrefix: APP_CONFIG.storagePrefix,
    entries,
  };
}

async function writeFolderSnapshot() {
  if (!directoryHandle) return false;

  try {
    const permission = await directoryHandle.queryPermission({ mode: 'readwrite' });
    if (permission !== 'granted') {
      setBackupState('permission-required');
      return false;
    }

    const fileHandle = await directoryHandle.getFileHandle(BACKUP_FILE, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(JSON.stringify(getSnapshot(), null, 2));
    await writable.close();
    setBackupState('connected');
    return true;
  } catch (error) {
    setBackupState('error', error instanceof Error ? error.message : 'Falha ao atualizar a cópia na pasta.');
    return false;
  }
}

export const backupReady = (async () => {
  if (!('showDirectoryPicker' in window) || !('indexedDB' in window)) {
    setBackupState('unsupported');
    return;
  }

  try {
    directoryHandle = await readDirectoryHandle();
    if (!directoryHandle) {
      setBackupState('not-configured');
      return;
    }

    const permission = await directoryHandle.queryPermission({ mode: 'readwrite' });
    setBackupState(permission === 'granted' ? 'connected' : 'permission-required');
  } catch (error) {
    setBackupState('error', error instanceof Error ? error.message : 'Não foi possível verificar a pasta de cópia.');
  }
})();

export function getBackupStatus() {
  return {
    state: backupState,
    error: backupError,
    supportsFolder: 'showDirectoryPicker' in window && 'indexedDB' in window,
  };
}

export async function chooseBackupFolder() {
  if (!('showDirectoryPicker' in window) || !('indexedDB' in window)) {
    setBackupState('unsupported');
    return { ok: false, unsupported: true };
  }

  try {
    await backupReady;
    const handle = await window.showDirectoryPicker({ mode: 'readwrite' });
    const permission = await handle.requestPermission({ mode: 'readwrite' });
    if (permission !== 'granted') {
      setBackupState('permission-required');
      return { ok: false, message: 'Permita o acesso de leitura e escrita à pasta para guardar a cópia.' };
    }

    directoryHandle = handle;
    await storeDirectoryHandle(handle);
    const saved = await writeFolderSnapshot();
    return saved
      ? { ok: true }
      : { ok: false, message: backupError || 'Não foi possível guardar a cópia na pasta.' };
  } catch (error) {
    if (error?.name === 'AbortError') return { ok: false, cancelled: true };
    setBackupState('error', error instanceof Error ? error.message : 'Não foi possível selecionar a pasta.');
    return { ok: false, message: backupError };
  }
}

export function scheduleFolderBackup() {
  if (backupState === 'unsupported' || backupState === 'not-configured') return;

  clearTimeout(writeTimer);
  writeTimer = setTimeout(() => {
    writeQueue = writeQueue.then(async () => {
      await backupReady;
      await writeFolderSnapshot();
    }).catch((error) => {
      setBackupState('error', error instanceof Error ? error.message : 'Falha ao atualizar a cópia.');
    });
  }, 250);
}

export function downloadBackup() {
  const file = new Blob([JSON.stringify(getSnapshot(), null, 2)], {
    type: 'application/json',
  });
  const url = URL.createObjectURL(file);
  const link = document.createElement('a');
  link.href = url;
  link.download = BACKUP_FILE;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function restoreBackupFile(file) {
  const backup = JSON.parse(await file.text());
  const prefix = `${APP_CONFIG.storagePrefix}:`;

  if (
    backup?.format !== 'baros-backup'
    || backup.version !== 1
    || backup.storagePrefix !== APP_CONFIG.storagePrefix
    || !Array.isArray(backup.entries)
    || backup.entries.some((entry) => (
      !entry
      || typeof entry.key !== 'string'
      || !entry.key.startsWith(prefix)
      || typeof entry.value !== 'string'
    ))
  ) {
    throw new Error('O ficheiro não é uma cópia BarOS válida para esta aplicação.');
  }

  const existingKeys = [];
  for (let index = 0; index < localStorage.length; index += 1) {
    const key = localStorage.key(index);
    if (key && key.startsWith(prefix)) existingKeys.push(key);
  }

  existingKeys.forEach((key) => localStorage.removeItem(key));
  backup.entries.forEach(({ key, value }) => localStorage.setItem(key, value));
  scheduleFolderBackup();
}
