export function money(value = 0, currency = 'AOA') {
  const numericValue = Number(value) || 0;
  return new Intl.NumberFormat('pt-AO', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
  }).format(numericValue);
}

export function escapeHtml(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function showToast(message, type = 'info') {
  const stack = document.querySelector('.toast-stack') || (() => {
    const node = document.createElement('div');
    node.className = 'toast-stack';
    document.body.appendChild(node);
    return node;
  })();

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  stack.appendChild(toast);

  window.setTimeout(() => {
    toast.remove();
  }, 2800);
}

export function confirmDialog(message, onConfirm) {
  const confirmed = window.confirm(message);
  if (confirmed && typeof onConfirm === 'function') {
    onConfirm();
  }
  return confirmed;
}

export function renderEmptyState(title = 'Sem dados', subtitle = 'Ainda não há informação para mostrar.') {
  return `
    <div class="empty">
      <div class="big">—</div>
      <h3>${escapeHtml(title)}</h3>
      <p>${escapeHtml(subtitle)}</p>
    </div>
  `;
}
