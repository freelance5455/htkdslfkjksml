export const APP_CONFIG = {
  name: 'BarOS',
  shortName: 'BarOS',
  storagePrefix: 'baros',
  themeKey: 'baros-theme',
  sessionKey: 'baros-session',
  defaultRoute: 'dashboard.html',
  currency: 'AOA',
  locale: 'pt-AO',
  roles: ['admin', 'gerente', 'caixa', 'estoquista'],
  supabase: {
    enabled: false,
    url: '',
    anonKey: '',
  },
};

export const ROLE_LABELS = {
  admin: 'Administrador',
  gerente: 'Gerente',
  caixa: 'Caixa',
  estoquista: 'Estoquista',
};

export const NAV_ITEMS = [
  { key: 'dashboard', label: 'Dashboard', page: 'dashboard.html', icon: '⌂', roles: ['admin', 'gerente', 'caixa', 'estoquista'] },
  { key: 'pos', label: 'POS', page: 'pos.html', icon: '◫', roles: ['admin', 'gerente', 'caixa'] },
  { key: 'tables', label: 'Mesas', page: 'tables.html', icon: '▣', roles: ['admin', 'gerente', 'caixa'] },
  { key: 'stock', label: 'Estoque', page: 'stock.html', icon: '▤', roles: ['admin', 'gerente', 'estoquista'] },
  { key: 'cash', label: 'Caixa', page: 'cash.html', icon: '◭', roles: ['admin', 'gerente', 'caixa'] },
  { key: 'clients', label: 'Clientes', page: 'clients.html', icon: '◎', roles: ['admin', 'gerente', 'caixa'] },
  { key: 'reports', label: 'Relatórios', page: 'reports.html', icon: '▥', roles: ['admin', 'gerente', 'caixa'] },
  { key: 'company', label: 'Empresa', page: 'company.html', icon: '⚙', roles: ['admin', 'gerente'] },
  { key: 'users', label: 'Utilizadores', page: 'users.html', icon: '◍', roles: ['admin'] },
  { key: 'logs', label: 'Auditoria', page: 'logs.html', icon: '☰', roles: ['admin', 'gerente'] },
];

export const THEME_ICONS = {
  light: '☀️',
  dark: '🌙',
};
