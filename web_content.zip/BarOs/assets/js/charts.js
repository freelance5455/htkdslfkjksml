export function renderTrendChart(canvas, labels, values) {
  const ctx = canvas.getContext('2d');
  const width = canvas.width || 500;
  const height = canvas.height || 220;

  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;

  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);

  values.forEach((_, index) => {
    const x = (index / Math.max(values.length - 1, 1)) * (width - 30) + 15;
    const y = height - 22 - (((values[index] - min) / Math.max(max - min, 1)) * (height - 52));
    ctx.beginPath();
    ctx.arc(x, y, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#f59e0b';
    ctx.fill();
  });

  ctx.beginPath();
  values.forEach((value, index) => {
    const x = (index / Math.max(values.length - 1, 1)) * (width - 30) + 15;
    const y = height - 22 - (((value - min) / Math.max(max - min, 1)) * (height - 52));
    if (index === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = '#f59e0b';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  labels.forEach((label, index) => {
    const x = (index / Math.max(labels.length - 1, 1)) * (width - 30) + 15;
    ctx.fillStyle = '#64748b';
    ctx.font = '11px sans-serif';
    ctx.fillText(label, x - 8, height - 6);
  });
}
