export const APP_CONFIG = {
  name: 'BarOS',
  storagePrefix: 'baros',
  supabase: {
    enabled: false,
    url: 'https://SEU-PROJETO.supabase.co',
    anonKey: 'SUA_ANON_KEY_AQUI',
  },
  defaultRoute: 'dashboard.html',
  currency: 'AOA',
  locale: 'pt-AO',
};

export default APP_CONFIG;
