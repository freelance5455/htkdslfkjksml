import { NAV_ITEMS, APP_CONFIG } from './config.js';
import { getCurrentUser, loadTheme, logoutUser, requireAuth } from './auth.js';
import { safeStorage } from './storage.js';
import { initCommandPalette, openCommandPalette } from './cmdk.js';
import { toggleNotificationsPanel, notificationCenter } from './notifications.js';

function pageNameFromPath() {
  const path = window.location.pathname.split('/').pop() || 'dashboard.html';
  return path;
}

function activeNavFromPath() {
  const current = pageNameFromPath();
  return NAV_ITEMS.find((item) => item.page === current);
}

function updateThemeButton() {
  const button = document.getElementById('theme-toggle');
  if (!button) return;

  const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
  button.textContent = currentTheme === 'dark' ? '☀️' : '🌙';
  button.title = currentTheme === 'dark' ? 'Ativar modo claro' : 'Ativar modo escuro';
}

function injectBrandingAssets() {
  const isPagesFolder = window.location.pathname.includes('/pages/');
  const basePath = isPagesFolder ? '..' : '.';

  if (!document.querySelector('link[rel="icon"]')) {
    const iconLink = document.createElement('link');
    iconLink.rel = 'icon';
    iconLink.type = 'image/svg+xml';
    iconLink.href = `${basePath}/assets/img/logo.svg`;
    document.head.appendChild(iconLink);
  }

  if (!document.querySelector('link[rel="manifest"]')) {
    const manifestLink = document.createElement('link');
    manifestLink.rel = 'manifest';
    manifestLink.href = `${basePath}/manifest.webmanifest`;
    document.head.appendChild(manifestLink);
  }

  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (!metaTheme) {
    const themeMeta = document.createElement('meta');
    themeMeta.name = 'theme-color';
    themeMeta.content = '#0f172a';
    document.head.appendChild(themeMeta);
  }
}

function injectSidebar() {
  const shell = document.querySelector('#app-shell');
  if (!shell) return;

  const user = getCurrentUser();
  const navHtml = NAV_ITEMS.filter((item) => !user || item.roles.includes(user.role))
    .map((item) => {
      const isActive = pageNameFromPath() === item.page ? 'active' : '';
      return `
        <a class="nav-item ${isActive}" href="${item.page}">
          <span>${item.icon}</span>
          <span>${item.label}</span>
        </a>
      `;
    })
    .join('');

  shell.innerHTML = `
    <aside class="sidebar">
      <div class="sidebar-head">
        <div class="logo-mark">B</div>
        <div class="logo-txt">
          <strong>${APP_CONFIG.name}</strong>
          <span>POS & gestão</span>
        </div>
      </div>
      <nav class="nav">
        ${navHtml}
      </nav>
      <div class="sidebar-foot">
        <div class="user-chip">
          <div class="avatar">${(user?.name || 'U').charAt(0).toUpperCase()}</div>
          <div class="meta">
            <strong>${user?.name || 'Utilizador'}</strong>
            <span>${user?.role || 'sem perfil'}</span>
          </div>
          <button type="button" id="logout-button" aria-label="Sair">⇥</button>
        </div>
      </div>
    </aside>
    <main class="page-shell">
      <header class="topbar">
        <button class="btn btn-ghost btn-sm" id="sidebar-toggle" type="button">☰</button>
        <h2>${activeNavFromPath()?.label || 'BarOS'}</h2>
        <div class="topbar-actions">
          <div class="clock" id="clock-display">--:--</div>
          <button type="button" class="btn btn-ghost btn-sm" id="notifications-toggle" aria-label="Notificações">
            🔔 <span class="badge">${notificationCenter.unreadCount()}</span>
          </button>
          <button type="button" class="btn btn-ghost btn-sm" id="theme-toggle">☀️</button>
          <button type="button" class="btn btn-ghost btn-sm" id="cmdk-toggle">⌘K</button>
        </div>
      </header>
      <div class="content" id="view"></div>
    </main>
  `;

  document.getElementById('logout-button')?.addEventListener('click', logoutUser);
  document.getElementById('theme-toggle')?.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    safeStorage.set('theme', next);
    updateThemeButton();
  });

  document.getElementById('cmdk-toggle')?.addEventListener('click', () => {
    initCommandPalette();
    openCommandPalette();
  });

  document.getElementById('notifications-toggle')?.addEventListener('click', () => {
    toggleNotificationsPanel();
  });

  const sidebarToggle = document.getElementById('sidebar-toggle');
  const sidebar = document.querySelector('.sidebar');
  sidebarToggle?.addEventListener('click', () => {
    sidebar?.classList.toggle('is-open');
  });

  initCommandPalette();
  updateThemeButton();
  updateClock();
}

export function updateClock() {
  const clock = document.getElementById('clock-display');
  if (!clock) return;

  const now = new Date();
  clock.textContent = now.toLocaleTimeString('pt-PT', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function initLayout() {
  injectBrandingAssets();
  loadTheme();
  const current = pageNameFromPath();
  const session = requireAuth();

  if (!session && current !== 'login.html' && current !== 'setup.html') {
    window.location.href = './login.html';
    return;
  }

  if (document.querySelector('#app-shell')) {
    injectSidebar();
  }
}

window.addEventListener('DOMContentLoaded', () => {
  initLayout();
});
