export function printReceiptText(text, options = {}) {
  const safeText = String(text || '');
  const printWindow = window.open('', '_blank', 'width=360,height=760');

  if (!printWindow) {
    return false;
  }

  printWindow.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8" /><title>Recibo</title></head><body style="font-family:monospace; font-size:12px; white-space:pre-wrap; padding:18px;">${safeText}</body></html>`);
  printWindow.document.close();
  printWindow.focus();

  if (options.autoPrint !== false) {
    printWindow.print();
  }

  return true;
}

export function shareViaWhatsApp(message) {
  const encoded = encodeURIComponent(message);
  window.open(`https://wa.me/?text=${encoded}`, '_blank');
}

export function copyToClipboard(text) {
  return navigator.clipboard.writeText(String(text || ''));
}
