BOTANİK BAHÇEM - APK PROJESİ

Bu klasör Android Studio ile açılabilir.

APK oluşturma:
1. Android Studio > Open > bu klasörü seçin.
2. Gradle senkronizasyonunun tamamlanmasını bekleyin.
3. Build > Generate App Bundles or APKs > Generate APKs.
4. APK: app/build/outputs/apk/debug/app-debug.apk

Not: HTML içindeki Leaflet CSS SRI hash hatası düzeltilmiştir. Uygulama kamera, konum ve galeri için Android izinlerini ister.
