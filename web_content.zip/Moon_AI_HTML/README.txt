MOON AI — HTML + Grok API

Included:
- public/index.html: responsive Bengali chat interface
- server/server.js: Node.js backend calling xAI/Grok
- Mic speech input (browser SpeechRecognition, Bengali India)
- Spoken replies (browser SpeechSynthesis, Bengali if installed)

Run locally:
1. Install Node.js 20+.
2. Open terminal in the server folder.
3. Run: npm install
4. Set your xAI API key as an environment variable:
   Windows PowerShell: $env:XAI_API_KEY="YOUR_KEY"
   macOS/Linux: export XAI_API_KEY="YOUR_KEY"
5. Optional model override:
   Windows: $env:XAI_MODEL="grok-4.1-fast"
   macOS/Linux: export XAI_MODEL="grok-4.1-fast"
6. Run: npm start
7. Open http://localhost:3000 in Chrome.

To use on your Android phone, deploy the server folder + public folder to an HTTPS Node host, then open the HTTPS site in Chrome. Do not open index.html as a file:// URL; it needs the backend.

Security:
Never put the xAI API key in index.html or client-side JavaScript. Keep it only as a server environment variable. For a public production deployment, add login/authentication and rate limiting.
Voice:
Browser voice recognition and Bengali text-to-speech support vary by Android/Chrome version and installed speech services. Grant microphone permission and install Bengali voice data if needed.
