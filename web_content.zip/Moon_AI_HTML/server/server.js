import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

if (!process.env.XAI_API_KEY) throw new Error("Set XAI_API_KEY in the server environment.");
const app = express();
const client = new OpenAI({ apiKey: process.env.XAI_API_KEY, baseURL: "https://api.x.ai/v1" });
app.use(express.json({ limit: "1mb" }));
const here = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(here, "../public")));

app.post("/v1/chat", async (req, res) => {
  try {
    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const input = messages.filter(m => ["user","assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-24).map(m => ({ role: m.role, content: m.content }));
    const response = await client.responses.create({
      model: process.env.XAI_MODEL || "grok-4.1-fast",
      instructions: "তোমার নাম Moon। তুমি বন্ধুসুলভ বাংলা AI সহকারী। ব্যবহারকারী অন্য ভাষা চাইলে সেই ভাষায় উত্তর দেবে; অন্যথায় সহজ, পরিষ্কার বাংলায় উত্তর দেবে।",
      input,
      store: false
    });
    res.json({ reply: response.output_text || "দুঃখিত, এবার উত্তর তৈরি করতে পারলাম না।" });
  } catch (err) {
    console.error("xAI error:", err?.message || err);
    res.status(502).json({ error: "AI service request failed." });
  }
});
app.listen(process.env.PORT || 3000, () => console.log("Moon AI running on port " + (process.env.PORT || 3000)));
