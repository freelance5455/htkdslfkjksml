-- Madar Halaqat: Multi-teacher migration V23
-- Run once in Supabase SQL Editor before using V23.
create table if not exists public.teacher_profiles (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid not null references auth.users(id) on delete cascade,
  teacher_name text not null,
  teacher_code text not null unique,
  created_at timestamptz not null default now()
);

alter table public.circles add column if not exists teacher_profile_id uuid references public.teacher_profiles(id) on delete cascade;
alter table public.daily_reports add column if not exists teacher_profile_id uuid references public.teacher_profiles(id) on delete cascade;
alter table public.daily_reports add column if not exists teacher_name text;
alter table public.daily_reports add column if not exists report_date date;

create index if not exists idx_teacher_profiles_auth on public.teacher_profiles(auth_user_id);
create index if not exists idx_circles_teacher_profile on public.circles(teacher_profile_id);
create index if not exists idx_reports_teacher_profile on public.daily_reports(teacher_profile_id);

-- Keep the existing daily uniqueness, while allowing the app to update an existing report.
-- No existing rows are deleted.

alter table public.teacher_profiles enable row level security;

drop policy if exists "teacher_profiles_select_own" on public.teacher_profiles;
drop policy if exists "teacher_profiles_insert_own" on public.teacher_profiles;
drop policy if exists "teacher_profiles_update_own" on public.teacher_profiles;
create policy "teacher_profiles_select_own" on public.teacher_profiles for select to authenticated using (auth_user_id = auth.uid());
create policy "teacher_profiles_insert_own" on public.teacher_profiles for insert to authenticated with check (auth_user_id = auth.uid());
create policy "teacher_profiles_update_own" on public.teacher_profiles for update to authenticated using (auth_user_id = auth.uid()) with check (auth_user_id = auth.uid());

grant select,insert,update on public.teacher_profiles to authenticated;

-- Allow the manager app to read the teacher identity table.
drop policy if exists "manager_read_teacher_profiles" on public.teacher_profiles;
create policy "manager_read_teacher_profiles" on public.teacher_profiles for select to authenticated using (public.is_manager());

NOTIFY pgrst, 'reload schema';

-- V24: allow the teacher to edit/delete only recitations belonging to their own students.
-- Run once in Supabase SQL Editor. This fixes delete buttons that appear to work but do not remove rows under RLS.
alter table public.recitations enable row level security;

drop policy if exists "teacher_recitations_update_own" on public.recitations;
create policy "teacher_recitations_update_own" on public.recitations
for update to authenticated
using (
  exists (
    select 1 from public.students s
    join public.circles c on c.id = s.circle_id
    where s.id = recitations.student_id and c.teacher_id = auth.uid()
  )
)
with check (
  exists (
    select 1 from public.students s
    join public.circles c on c.id = s.circle_id
    where s.id = recitations.student_id and c.teacher_id = auth.uid()
  )
);

drop policy if exists "teacher_recitations_delete_own" on public.recitations;
create policy "teacher_recitations_delete_own" on public.recitations
for delete to authenticated
using (
  exists (
    select 1 from public.students s
    join public.circles c on c.id = s.circle_id
    where s.id = recitations.student_id and c.teacher_id = auth.uid()
  )
);

grant update,delete on public.recitations to authenticated;

NOTIFY pgrst, 'reload schema';

-- V25: DELETE needs SELECT visibility too when the app confirms/refreshes the record.
alter table public.recitations enable row level security;
drop policy if exists "teacher_recitations_select_own" on public.recitations;
create policy "teacher_recitations_select_own" on public.recitations
for select to authenticated
using (
  exists (
    select 1 from public.students s
    join public.circles c on c.id = s.circle_id
    where s.id = recitations.student_id and c.teacher_id = auth.uid()
  )
);
grant select on public.recitations to authenticated;

NOTIFY pgrst, 'reload schema';


-- V26 STABLE: daily report notes + teacher-owned report/attendance access.
-- Safe to run once; IF NOT EXISTS / DROP POLICY make this migration repeatable.
alter table public.daily_reports add column if not exists notes text;
alter table public.daily_reports add column if not exists teacher_profile_id uuid references public.teacher_profiles(id) on delete cascade;
alter table public.daily_reports add column if not exists teacher_name text;
alter table public.daily_reports add column if not exists report_date date;

create index if not exists idx_daily_reports_teacher_date
  on public.daily_reports(teacher_profile_id, report_date);

alter table public.daily_reports enable row level security;

drop policy if exists "teacher_daily_reports_select_own" on public.daily_reports;
create policy "teacher_daily_reports_select_own"
on public.daily_reports for select to authenticated
using (
  teacher_id = auth.uid()
  and (teacher_profile_id is null or teacher_profile_id = (
    select tp.id from public.teacher_profiles tp
    where tp.auth_user_id = auth.uid()
    order by tp.created_at desc limit 1
  ))
);

drop policy if exists "teacher_daily_reports_insert_own" on public.daily_reports;
create policy "teacher_daily_reports_insert_own"
on public.daily_reports for insert to authenticated
with check (teacher_id = auth.uid());

drop policy if exists "teacher_daily_reports_update_own" on public.daily_reports;
create policy "teacher_daily_reports_update_own"
on public.daily_reports for update to authenticated
using (teacher_id = auth.uid())
with check (teacher_id = auth.uid());

grant select, insert, update on public.daily_reports to authenticated;

alter table public.attendance enable row level security;

drop policy if exists "teacher_attendance_select_own" on public.attendance;
create policy "teacher_attendance_select_own"
on public.attendance for select to authenticated
using (teacher_id = auth.uid());

drop policy if exists "teacher_attendance_insert_own" on public.attendance;
create policy "teacher_attendance_insert_own"
on public.attendance for insert to authenticated
with check (teacher_id = auth.uid());

grant select, insert on public.attendance to authenticated;

NOTIFY pgrst, 'reload schema';
