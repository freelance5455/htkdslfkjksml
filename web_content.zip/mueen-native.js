/* =========================================================
   MUEEN | NATIVE + UI BRIDGE
   طبقة توافق واحدة لنسخة الويب ونسخة Android APK
========================================================= */
"use strict";

(function () {
    const bridge = window.AndroidMueen || null;
    const pending = new Map();
    let callbackCounter = 0;

    function nextCallbackId(prefix = "native") {
        callbackCounter += 1;
        return `mueen-${prefix}-${Date.now()}-${callbackCounter}`;
    }

    window.__mueenNativeResolve = function (callbackId, ok, value) {
        const item = pending.get(String(callbackId));
        if (!item) return;
        pending.delete(String(callbackId));
        clearTimeout(item.timer);
        if (ok) item.resolve(value);
        else item.reject(new Error(String(value || "تعذر تنفيذ العملية.")));
    };

    function safeCall(name, ...args) {
        try {
            if (bridge && typeof bridge[name] === "function") {
                return bridge[name](...args);
            }
        } catch (error) {
            console.warn("MUEEN native bridge:", name, error);
        }
        return null;
    }

    function callAsync(name, args = [], timeoutMs = 120000) {
        if (!bridge || typeof bridge[name] !== "function") {
            return Promise.reject(new Error("الجسر الأصلي غير متاح."));
        }

        const callbackId = nextCallbackId(name);

        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                pending.delete(callbackId);
                reject(new Error("انتهت مهلة الاستجابة من Android."));
            }, timeoutMs);

            pending.set(callbackId, { resolve, reject, timer });

            try {
                bridge[name](...args, callbackId);
            } catch (error) {
                clearTimeout(timer);
                pending.delete(callbackId);
                reject(error);
            }
        });
    }

    window.MueenNative = {
        available: !!bridge,

        notify(title, body, id, whenMs) {
            return safeCall(
                "scheduleNotification",
                String(title || "مُعين"),
                String(body || ""),
                String(id || Date.now()),
                Number(whenMs || Date.now())
            );
        },

        cancelNotification(id) {
            return safeCall("cancelScheduledNotification", String(id || ""));
        },

        cancelAllNotifications() {
            return safeCall("cancelAllScheduledNotifications");
        },

        notificationPermission() {
            const value = safeCall("notificationPermission");
            return value || "default";
        },

        requestNotificationPermission() {
            return callAsync("requestNotificationPermission");
        },

        chooseGoogleAccount() {
            return callAsync("chooseGoogleAccount");
        },

        backupToDrive(json, filename) {
            return callAsync("backupToDrive", [
                String(json || ""),
                String(filename || "MUEEN-Backup.json")
            ]);
        },

        restoreFromDrive() {
            return callAsync("restoreFromDrive");
        },

        ocrArabic(dataUrl) {
            return callAsync("ocrArabic", [String(dataUrl || "")], 180000);
        },

        saveFileBase64(base64, filename, mime) {
            return callAsync("saveFile", [
                String(base64 || ""),
                String(filename || "MUEEN-file"),
                String(mime || "application/octet-stream")
            ]);
        },

        printHtml(html, title) {
            return safeCall(
                "printHtml",
                String(html || ""),
                String(title || "مُعين")
            );
        }
    };

    function ensureUI() {
        if (document.getElementById("mueenGlobalDialog")) return;

        const style = document.createElement("style");
        style.id = "mueenGlobalUiStyle";
        style.textContent = `
            #mueenGlobalDialog{
                position:fixed; inset:0; z-index:99999;
                display:none; align-items:flex-end; justify-content:center;
                padding:16px 14px calc(16px + env(safe-area-inset-bottom));
                background:rgba(5,46,55,.34);
                backdrop-filter:blur(5px);
                -webkit-backdrop-filter:blur(5px);
            }
            #mueenGlobalDialog.open{display:flex}
            #mueenGlobalDialog .mueen-dialog-card{
                width:min(100%,430px); background:#fff; color:#18343A;
                border:1px solid #E3E9E7; border-radius:24px;
                box-shadow:0 22px 60px rgba(5,46,55,.22);
                padding:22px; text-align:right;
                direction:rtl; animation:mueenDialogIn .22s ease-out;
            }
            #mueenGlobalDialog .mueen-dialog-mark{
                width:44px;height:44px;border-radius:14px;
                display:grid;place-items:center;margin-bottom:12px;
                background:#EDF5F5;color:#073B46;font-size:21px;font-weight:800;
            }
            #mueenGlobalDialog h3{margin:0 0 8px;font-size:18px;color:#073B46}
            #mueenGlobalDialog p{margin:0;line-height:1.8;font-size:14px;color:#687B80;white-space:pre-line}
            #mueenGlobalDialog .mueen-dialog-actions{
                display:flex;gap:10px;margin-top:18px
            }
            #mueenGlobalDialog button{
                flex:1;border:0;border-radius:14px;padding:13px 12px;
                font:inherit;font-weight:700;cursor:pointer
            }
            #mueenGlobalDialog .primary{background:#073B46;color:#fff}
            #mueenGlobalDialog .secondary{background:#F5F7F6;color:#18343A}
            #mueenGlobalToast{
                position:fixed;left:14px;right:14px;bottom:calc(84px + env(safe-area-inset-bottom));
                z-index:99998;display:none;justify-content:center;pointer-events:none;
            }
            #mueenGlobalToast.open{display:flex}
            #mueenGlobalToast .toast-inner{
                max-width:440px;width:100%;background:#073B46;color:#fff;
                border-radius:16px;padding:13px 16px;box-shadow:0 14px 35px rgba(5,46,55,.22);
                font-size:14px;line-height:1.6;text-align:center
            }
            @keyframes mueenDialogIn{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}
        `;
        document.head.appendChild(style);

        const dialog = document.createElement("div");
        dialog.id = "mueenGlobalDialog";
        dialog.innerHTML = `
            <div class="mueen-dialog-card" role="dialog" aria-modal="true">
                <div class="mueen-dialog-mark">م</div>
                <h3 id="mueenDialogTitle">مُعين</h3>
                <p id="mueenDialogMessage"></p>
                <div class="mueen-dialog-actions">
                    <button type="button" class="secondary" id="mueenDialogCancel">إلغاء</button>
                    <button type="button" class="primary" id="mueenDialogOk">حسنًا</button>
                </div>
            </div>`;
        document.body.appendChild(dialog);

        const toast = document.createElement("div");
        toast.id = "mueenGlobalToast";
        toast.innerHTML = `<div class="toast-inner" id="mueenToastMessage"></div>`;
        document.body.appendChild(toast);

        dialog.addEventListener("click", e => {
            if (e.target === dialog) closeDialog(false);
        });

        function closeDialog(value) {
            dialog.classList.remove("open");
            const resolver = dialog._resolver;
            dialog._resolver = null;
            if (resolver) resolver(value);
        }

        window.MueenUI = {
            alert(message, title = "مُعين") {
                ensureUI();
                return new Promise(resolve => {
                    document.getElementById("mueenDialogTitle").textContent = title;
                    document.getElementById("mueenDialogMessage").textContent = String(message ?? "");
                    document.getElementById("mueenDialogCancel").style.display = "none";
                    document.getElementById("mueenDialogOk").textContent = "حسنًا";
                    dialog._resolver = resolve;
                    dialog.classList.add("open");
                    document.getElementById("mueenDialogOk").onclick = () => closeDialog(true);
                });
            },

            confirm(message, title = "تأكيد الإجراء", okText = "متابعة") {
                ensureUI();
                return new Promise(resolve => {
                    document.getElementById("mueenDialogTitle").textContent = title;
                    document.getElementById("mueenDialogMessage").textContent = String(message ?? "");
                    document.getElementById("mueenDialogCancel").style.display = "";
                    document.getElementById("mueenDialogOk").textContent = okText;
                    dialog._resolver = resolve;
                    dialog.classList.add("open");
                    document.getElementById("mueenDialogOk").onclick = () => closeDialog(true);
                    document.getElementById("mueenDialogCancel").onclick = () => closeDialog(false);
                });
            },

            toast(message, type = "info") {
                ensureUI();
                const box = document.getElementById("mueenGlobalToast");
                const text = document.getElementById("mueenToastMessage");
                text.textContent = String(message ?? "");
                box.querySelector(".toast-inner").style.background =
                    type === "error" ? "#7B4A4A" :
                    type === "success" ? "#315E58" : "#073B46";
                box.classList.add("open");
                clearTimeout(window.__mueenToastTimer);
                window.__mueenToastTimer = setTimeout(() => box.classList.remove("open"), 2800);
            }
        };

        // استبدال alert القديم بصندوق مُعين الاحترافي.
        window.alert = function (message) {
            return window.MueenUI.alert(message);
        };
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", ensureUI, { once: true });
    } else {
        ensureUI();
    }
})();
