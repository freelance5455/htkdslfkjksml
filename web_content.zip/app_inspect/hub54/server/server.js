
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 8080);
const DATA_FILE = path.join(__dirname, 'keys.json');
const SESSION_FILE = path.join(__dirname, 'sessions.json');
const PACK_FILE = process.env.TEXTURE_PACK_FILE || path.join(__dirname, 'protected', 'texture-pack.zip');
const PUBLIC_ORIGIN = process.env.PUBLIC_ORIGIN || '';

function load(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function save(file, data) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, file);
}
if (!fs.existsSync(DATA_FILE)) save(DATA_FILE, {version:1, keys:[]});
if (!fs.existsSync(SESSION_FILE)) save(SESSION_FILE, {sessions:[]});

let queue = Promise.resolve();
function serial(fn) {
  const run = queue.then(fn, fn);
  queue = run.catch(()=>{});
  return run;
}
function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':PUBLIC_ORIGIN || '*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});
  res.end(body);
}
function hashKey(key) { return crypto.createHash('sha256').update(key, 'utf8').digest('hex'); }
function token() { return crypto.randomBytes(32).toString('hex'); }
function cleanToken(t) { return typeof t === 'string' && /^[a-f0-9]{64}$/.test(t); }

const server=http.createServer((req,res)=>{
  if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':PUBLIC_ORIGIN||'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});return res.end();}
  const u=new URL(req.url, `http://${req.headers.host}`);
  if(req.method==='POST' && u.pathname==='/api/redeem'){
    let raw=''; req.on('data',c=>{raw+=c; if(raw.length>4096) req.destroy();});
    req.on('end',()=>serial(()=>{
      let body; try{body=JSON.parse(raw||'{}')}catch{return send(res,400,{ok:false,message:'Некорректный запрос.'});}
      const key=String(body.key||'').trim().toUpperCase();
      if(key!=='__SECRET_KEY_HASH__') return send(res,401,{ok:false,message:'Ключ недействителен.'});
      const db=load(DATA_FILE,{version:1,keys:[]}); const h=hashKey(key);
      const item=db.keys.find(x=>x.hash===h);
      if(!item) return send(res,401,{ok:false,message:'Ключ недействителен.'});
      if(!item.permanent && item.used) return send(res,409,{ok:false,message:'Ключ уже использован.'});
      if(!item.permanent){ item.used=true; item.usedAt=new Date().toISOString(); }
      const t=token(); item.tokenHash=hashKey(t);
      const sessions=load(SESSION_FILE,{sessions:[]});
      sessions.sessions.push({tokenHash:item.tokenHash,createdAt:new Date().toISOString()});
      save(DATA_FILE,db); save(SESSION_FILE,sessions);
      return send(res,200,{ok:true,token:t});
    }));
    return;
  }
  if(req.method==='GET' && u.pathname==='/api/session'){
    const t=u.searchParams.get('token')||'';
    if(!cleanToken(t)) return send(res,401,{ok:false});
    const db=load(SESSION_FILE,{sessions:[]}); const h=hashKey(t);
    return send(res,200,{ok:db.sessions.some(s=>s.tokenHash===h)});
  }
  if(req.method==='GET' && u.pathname==='/api/download'){
    const t=u.searchParams.get('token')||'';
    if(!cleanToken(t)) return send(res,401,{ok:false,message:'Требуется активный доступ.'});
    const db=load(SESSION_FILE,{sessions:[]}); const h=hashKey(t);
    if(!db.sessions.some(s=>s.tokenHash===h)) return send(res,403,{ok:false,message:'Доступ запрещён.'});
    if(!fs.existsSync(PACK_FILE)) return send(res,503,{ok:false,message:'Файл текстур пака не настроен на сервере.'});
    const stat=fs.statSync(PACK_FILE);
    res.writeHead(200,{'Content-Type':'application/zip','Content-Length':stat.size,'Content-Disposition':'attachment; filename="texture-pack.zip"','Cache-Control':'private, no-store'});
    fs.createReadStream(PACK_FILE).pipe(res); return;
  }
  send(res,404,{ok:false,message:'Not found'});
});
server.listen(PORT,()=>console.log(`Satoriuou key server listening on :${PORT}`));
