# WebView fix

Исправлена загрузка `https://appassets.androidplatform.net/web/index.html`.
Теперь используется `androidx.webkit.WebViewAssetLoader`, который официально предназначен для загрузки локальных HTML/CSS/JS/изображений через `appassets.androidplatform.net`.

Причина исходной ошибки: приложение вручную перехватывало `/web/` через `shouldInterceptRequest`, но сам `WebView` не был настроен через `WebViewAssetLoader`. На части версий WebView это приводило к `net::ERR_HTTP_RESPONSE_CODE_FAILURE` уже на стартовой странице.

Добавлена зависимость `androidx.webkit:webkit:1.15.0`.
