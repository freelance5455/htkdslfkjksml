

// v24: swipe between the four main sections.
(function(){
  const tabs=['scripts','packs','guides','cheats'];
  let startX=0,startY=0,startT=0,tracking=false;
  const root=document.querySelector('.screen')||document.body;
  function current(){
    const active=document.querySelector('.tab.active');
    return active ? tabs.indexOf(active.dataset.tab) : 0;
  }
  function go(i){
    if(i<0||i>=tabs.length)return;
    switchTab(tabs[i]);
    const b=document.querySelector('.tab[data-tab="'+tabs[i]+'"]');
    if(b)b.scrollIntoView({behavior:'smooth',block:'nearest',inline:'center'});
  }
  root.addEventListener('touchstart',e=>{
    if(!e.touches||e.touches.length!==1)return;
    startX=e.touches[0].clientX; startY=e.touches[0].clientY; startT=Date.now(); tracking=true;
  },{passive:true});
  root.addEventListener('touchend',e=>{
    if(!tracking||!e.changedTouches||!e.changedTouches.length)return;
    tracking=false;
    const dx=e.changedTouches[0].clientX-startX;
    const dy=e.changedTouches[0].clientY-startY;
    const dt=Date.now()-startT;
    if(dt<700 && Math.abs(dx)>65 && Math.abs(dx)>Math.abs(dy)*1.25){
      go(current()+(dx<0?1:-1));
    }
  },{passive:true});
  const strip=document.querySelector('.tabs');
  if(strip){
    strip.addEventListener('wheel',e=>{
      if(Math.abs(e.deltaY)>Math.abs(e.deltaX)){
        strip.scrollLeft+=e.deltaY;
      }
    },{passive:true});
  }
})();


// v25: never lock vertical scrolling when switching tabs/modals.
(function(){
  function unlockScroll(){
    document.documentElement.style.overflowX='hidden';
    document.documentElement.style.overflowY='auto';
    document.body.style.overflowX='hidden';
    document.body.style.overflowY='auto';
    document.body.style.touchAction='pan-y';
  }
  unlockScroll();
  document.addEventListener('click', function(){ setTimeout(unlockScroll, 0); }, true);
  document.addEventListener('touchend', function(){ setTimeout(unlockScroll, 0); }, {passive:true});
})();



const KEY='satoriuou_hub_v9';
const defaults={nick:'',accent:'#2f8cff,#1762cf',radius:'24',music:true,effects:true,frame:true,badge:true,avatar:'',textureUnlocked:false,accessToken:'',offlineAccess:false,cheatUnlocked:false,cheatAccessToken:'',blackUnlocked:false,blackAccessToken:'',trainersUnlocked:false,trainersAccessToken:'',bmgoUnlocked:false,bmgoAccessToken:'',cartoonUnlocked:false,cartoonAccessToken:'',cs2Unlocked:false,cs2AccessToken:''};
let state={...defaults};
try{state={...defaults,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch(_){localStorage.removeItem(KEY)}
const $=id=>document.getElementById(id);function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function hexRgb(hex){const h=hex.replace('#','');const n=parseInt(h,16);return [(n>>16)&255,(n>>8)&255,n&255].join(',')}
function updateProfile(){
 if($('topName'))$('topName').textContent=state.nick||'—';
 if($('avatarTop'))$('avatarTop').src=state.avatar||'assets/logo.webp';
 if($('avatarFrame'))$('avatarFrame').classList.toggle('hidden',!(state.textureUnlocked&&state.frame));
 if($('v1Badge'))$('v1Badge').classList.toggle('hidden',!(state.textureUnlocked&&state.badge));
 if($('profileTop'))$('profileTop').classList.toggle('hidden',!state.nick);
}
function apply(){
 const[a,b]=state.accent.split(',');
 document.documentElement.style.setProperty('--accent',a);
 document.documentElement.style.setProperty('--accent2',b);
 document.documentElement.style.setProperty('--accent-rgb',hexRgb(a));
 document.documentElement.style.setProperty('--radius',state.radius+'px');
 document.documentElement.classList.toggle('effects-off',!state.effects);
 if($('radius'))$('radius').value=state.radius;
 document.querySelectorAll('.swatch').forEach(x=>x.classList.toggle('active',x.dataset.accent===state.accent));
 if($('musicToggle'))$('musicToggle').textContent=state.music?'Выкл.':'Вкл.';
 if($('effectsToggle'))$('effectsToggle').textContent=state.effects?'Выкл.':'Вкл.';
 if($('frameToggle'))$('frameToggle').textContent=state.frame?'Выкл.':'Вкл.';
 if($('badgeToggle'))$('badgeToggle').textContent=state.badge?'Выкл.':'Вкл.';
 updateProfile();
}
function startMusic(){const a=$('bgMusic');a.loop=true;a.volume=.30;if(!state.music){a.pause();return}const p=a.play();if(p&&p.catch)p.catch(()=>{})}
function enter(nick){
 nick=(nick||'').trim().slice(0,24); if(!nick)return;
 state.nick=nick; save(); updateProfile();
 document.body.classList.remove('login-mode');
 $('login').classList.add('hidden'); $('hub').classList.remove('hidden'); startMusic();
}
function openSettings(){$('modalWrap').classList.remove('hidden')}
function closeSettings(){$('modalWrap').classList.add('hidden')}
function openAvatarPicker(){$('avatarInput').click()}
function setAvatar(file){
 if(!file||!file.type.startsWith('image/'))return;
 const reader=new FileReader();
 reader.onload=()=>{
   const img=new Image();
   img.onload=()=>{
     const s=128,c=document.createElement('canvas');c.width=s;c.height=s;
     const ctx=c.getContext('2d'),scale=Math.max(s/img.width,s/img.height);
     const w=img.width*scale,h=img.height*scale;
     ctx.drawImage(img,(s-w)/2,(s-h)/2,w,h);
     state.avatar=c.toDataURL('image/webp',.62);save();updateProfile();
   };
   img.src=reader.result;
 };
 reader.readAsDataURL(file);
}
function showPackModal(){
  document.body.classList.add('modal-open');
  if(state.textureUnlocked && state.accessToken==='ETERNAL_ACCESS_V2') renderUnlocked(false);
  else showKeyEntry();
}
async function sha256Hex(value){
  if(window.crypto && crypto.subtle){
    const data=new TextEncoder().encode(value);
    const digest=await crypto.subtle.digest('SHA-256',data);
    return Array.from(new Uint8Array(digest)).map(b=>b.toString(16).padStart(2,'0')).join('');
  }
  throw new Error('Криптография недоступна');
}
async function redeemKey(){
  const input=($('packKey')?.value||'').replace(/\s+/g,'').trim();
  const status=$('keyStatus');
  const btn=$('redeem');
  if(status){status.className='status';status.textContent='';}
  if(!input){
    if(status){status.className='status err';status.textContent='Введи ключ.'}
    return;
  }
  if(btn){btn.disabled=true;btn.textContent='ПРОВЕРКА...';}
  try{
    const hash=await sha256Hex(input);
    const validHash='8cb88b44227d4f0edfb85a51c4f1ab4daf4c84dfc03483cd0e82c1eb0536c169';
    if(hash!==validHash){
      if(status){status.className='status err';status.textContent='Неверный ключ.'}
      return;
    }
    state.textureUnlocked=true;
    state.accessToken='ETERNAL_ACCESS_V2';
    state.offlineAccess=true;
    save();
    renderUnlocked(true);
  }catch(e){
    if(status){status.className='status err';status.textContent='Не удалось проверить ключ. Попробуй ещё раз.'}
  }finally{
    if(btn){btn.disabled=false;btn.textContent='АКТИВИРОВАТЬ';}
  }
}
function firework(){
  const c=document.createElement('canvas');
  c.className='fireworks-layer';
  document.body.appendChild(c);
  const ctx=c.getContext('2d');
  const dpr=Math.min(window.devicePixelRatio||1,2);
  const resize=()=>{c.width=innerWidth*dpr;c.height=innerHeight*dpr;c.style.width=innerWidth+'px';c.style.height=innerHeight+'px';ctx.setTransform(dpr,0,0,dpr,0,0)};
  resize();
  const particles=[];
  for(let burst=0;burst<5;burst++){
    const x=innerWidth*(.2+Math.random()*.6), y=innerHeight*(.18+Math.random()*.38);
    const hue=Math.floor(Math.random()*360);
    for(let i=0;i<32;i++){
      const a=Math.PI*2*i/32, speed=1.5+Math.random()*3.5;
      particles.push({x,y,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,life:55+Math.random()*25,hue});
    }
  }
  let frame=0;
  const tick=()=>{
    ctx.clearRect(0,0,innerWidth,innerHeight);
    particles.forEach(p=>{
      if(p.life<=0)return;
      p.x+=p.vx;p.y+=p.vy;p.vy+=.035;p.vx*=.992;p.vy*=.992;p.life--;
      ctx.globalAlpha=Math.max(0,p.life/75);
      ctx.fillStyle='hsl('+p.hue+' 100% 65%)';
      ctx.beginPath();ctx.arc(p.x,p.y,2.2,0,Math.PI*2);ctx.fill();
    });
    ctx.globalAlpha=1;
    frame++;
    if(frame<85) requestAnimationFrame(tick); else c.remove();
  };
  requestAnimationFrame(tick);
}
function showCheatModal(){
  document.body.classList.add('modal-open');
  if(state.cheatUnlocked && state.cheatAccessToken==='CHEAT_ACCESS_V2') renderCheatUnlocked(false);
  else showCheatKeyEntry();
}
async function redeemCheatKey(){
  const input=($('cheatKey')?.value||'').replace(/\s+/g,'').trim();
  const status=$('cheatStatus'), btn=$('redeemCheat');
  if(status){status.className='status';status.textContent='';}
  if(!input){if(status){status.className='status err';status.textContent='Введи ключ.'}return;}
  if(btn){btn.disabled=true;btn.textContent='ПРОВЕРКА...';}
  try{
    const hash=await sha256Hex(input);
    const validHash='943eca304705021a4dacc0df57775f90f66ac1c92461946546c4a00fdcc3f175';
    if(hash!==validHash){if(status){status.className='status err';status.textContent='Неверный ключ.'}return;}
    state.cheatUnlocked=true;
    state.cheatAccessToken='CHEAT_ACCESS_V2';
    save();
    renderCheatUnlocked(true);
  }catch(e){if(status){status.className='status err';status.textContent='Не удалось проверить ключ. Попробуй ещё раз.'}}
  finally{if(btn){btn.disabled=false;btn.textContent='АКТИВИРОВАТЬ';}}
}
function renderCheatUnlocked(withFirework=false){
  state.cheatUnlocked=true;
  state.cheatAccessToken='CHEAT_ACCESS_V2';
  save();
  const url=(window.CHEAT_URL||'').trim();
  $('cheatContent').innerHTML='<div class="success purchase-success"><div class="success-icon">✓</div><h3>Спасибо за покупку!</h3><p>Вот твой чит-пак</p></div><div class="pack-actions copy-only-actions"><button class="btn copy-link-btn" id="copyCheatLink" type="button"><span>Скопируйте ссылку<br>вставьте в гугл<br>И далее следуйте гайду</span></button></div><div id="cheatPackStatus" class="status"></div>';
  $('copyCheatLink').onclick=async()=>{try{if(window.AndroidBridge&&AndroidBridge.copyText){AndroidBridge.copyText(url)}else if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(url)}else{const ta=document.createElement('textarea');ta.value=url;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove()}$('cheatPackStatus').className='status ok';$('cheatPackStatus').textContent='Ссылка скопирована.'}catch(e){$('cheatPackStatus').className='status err';$('cheatPackStatus').textContent='Не удалось скопировать ссылку.'}};
  $('cheatModal').classList.remove('hidden');
}
function showCheatKeyEntry(){
  $('cheatContent').innerHTML='<div class="key-box"><b>Введи ключ</b><input id="cheatKey" maxlength="5" inputmode="text" autocapitalize="characters" placeholder="Введи ключ доступа" autocomplete="off"><div class="key-actions"><button class="btn" id="redeemCheat" type="button">АКТИВИРОВАТЬ</button><button class="btn secondary" id="closeCheat2" type="button">ОТМЕНА</button></div><div id="cheatStatus" class="status"></div></div><p class="notice">После успешной проверки доступ к чит-паку сохранится на этом устройстве.</p>';
  $('cheatModal').classList.remove('hidden');
  $('redeemCheat').onclick=redeemCheatKey;
  $('closeCheat2').onclick=closeCheatModal;
  $('cheatKey').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();redeemCheatKey()}});
  setTimeout(()=>$('cheatKey')?.focus(),80);
}
function closeCheatModal(){ $('cheatModal').classList.add('hidden'); document.body.classList.remove('modal-open'); }
function renderUnlocked(withFirework=false){
  state.textureUnlocked=true;
  state.accessToken='ETERNAL_ACCESS_V2';
  state.offlineAccess=true;
  save();
  updateProfile();
  const url=(window.PACK_URL||'').trim();
  $('keyContent').innerHTML=
    '<div class="success purchase-success"><div class="success-icon">✓</div><h3>Спасибо за покупку!</h3><p>Вот твой пак</p></div>'+
    '<div class="pack-actions copy-only-actions">'+
    '<button class="btn copy-link-btn" id="copyPackLink" type="button"><span>Скопируйте ссылку<br>вставьте в гугл<br>И далее следуйте гайду</span></button>'+
    '</div><div id="packStatus" class="status"></div>';
  $('copyPackLink').onclick=async()=>{
    try{
      if(window.AndroidBridge&&AndroidBridge.copyText){AndroidBridge.copyText(url)}
      else if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(url)}
      else{const ta=document.createElement('textarea');ta.value=url;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove()}
      $('packStatus').className='status ok';$('packStatus').textContent='Ссылка скопирована.';
    }catch(e){$('packStatus').className='status err';$('packStatus').textContent='Не удалось скопировать ссылку.'}
  };
  $('keyModal').classList.remove('hidden');
  if(withFirework) setTimeout(firework,80);
}
function showKeyEntry(){
  document.body.classList.add('modal-open');
  $('keyContent').innerHTML='<div class="key-box"><b>Введи ключ</b><input id="packKey" maxlength="5" inputmode="text" placeholder="Введи ключ доступа" autocomplete="off" autocapitalize="characters" spellcheck="false"><div class="key-actions"><button class="btn" id="redeem" type="button">АКТИВИРОВАТЬ</button><button class="btn secondary" id="closeKey2" type="button">ОТМЕНА</button></div><div id="keyStatus" class="status"></div></div><p class="notice">После успешной проверки доступ к текстур-паку сохранится на этом устройстве.</p>';
  $('keyModal').classList.remove('hidden');
  $('redeem').onclick=redeemKey;
  $('closeKey2').onclick=closeKeyModal;
  $('packKey').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();redeemKey()}});
  setTimeout(()=>$('packKey')?.focus(),80);
}
function closeKeyModal(){ $('keyModal').classList.add('hidden'); document.body.classList.remove('modal-open'); }
const API_BASE=(window.API_BASE||'').replace(/\/$/,'');
function apiReady(){return /^https:\/\//i.test(API_BASE)}

async function verifyStoredAccess(){return !!(state.textureUnlocked&&state.accessToken==='ETERNAL_ACCESS_V2');}
$('loginForm').addEventListener('submit',e=>{e.preventDefault();enter($('nick').value)});
$('settingsBtn').onclick=openSettings;
$('closeSettings').onclick=closeSettings;
$('modalWrap').addEventListener('click',e=>{if(e.target===$('modalWrap'))closeSettings()});

$('changeAvatar').onclick=openAvatarPicker;
$('avatarInput').addEventListener('change',e=>setAvatar(e.target.files[0]));
$('musicToggle').onclick=()=>{state.music=!state.music;save();if(state.music)startMusic();else $('bgMusic').pause();apply()};
$('effectsToggle').onclick=()=>{state.effects=!state.effects;save();apply()};
$('frameToggle').onclick=()=>{state.frame=!state.frame;save();apply()};
$('badgeToggle').onclick=()=>{state.badge=!state.badge;save();apply()};
$('resetAll').onclick=()=>{localStorage.removeItem(KEY);location.reload()};$('radius').onchange=e=>{state.radius=e.target.value;save();apply()};document.querySelectorAll('.swatch').forEach(x=>x.onclick=()=>{state.accent=x.dataset.accent;save();apply()});const BLACK_PACK_URL='https://www.mediafire.com/file/vlznf6z8g2tx0sb/g20151633%25282%2529.zip/file';
function showBlackPackModal(){ document.body.classList.add('modal-open'); $('blackPackModal').classList.remove('hidden'); if(state.blackUnlocked&&state.blackAccessToken==='BLACK_ACCESS_V2'){renderBlackSuccess(false);} else {showBlackKeyEntry();} }
function closeBlackPackModal(){ $('blackPackModal').classList.add('hidden'); document.body.classList.remove('modal-open'); }
function openImageViewer(src){ const v=$('imageViewer'),i=$('imageViewerImg'); if(!v||!i)return; i.src=src; v.classList.remove('hidden'); document.body.classList.add('modal-open'); }
function closeImageViewer(){ const v=$('imageViewer'),i=$('imageViewerImg'); if(v)v.classList.add('hidden'); if(i)i.src=''; document.body.classList.remove('modal-open'); }
function showBlackKeyEntry(){
  $('blackPackContent').innerHTML='<div class="key-box"><b>Введи ключ</b><input id="blackPackKey" maxlength="5" inputmode="text" autocapitalize="characters" placeholder="Введи ключ доступа" autocomplete="off"><div class="key-actions"><button class="btn" id="redeemBlackPack" type="button">АКТИВИРОВАТЬ</button><button class="btn secondary" id="closeBlackPack2" type="button">ОТМЕНА</button></div><div id="blackPackStatus" class="status"></div></div><p class="notice">После успешной активации доступ к пакету сохранится на этом устройстве.</p>';
  $('redeemBlackPack').onclick=redeemBlackPack;
  $('closeBlackPack2').onclick=closeBlackPackModal;
  $('blackPackKey').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();redeemBlackPack()}});
  setTimeout(()=>$('blackPackKey')?.focus(),80);
}
function renderBlackSuccess(withFirework=true){
  state.blackUnlocked=true; state.blackAccessToken='BLACK_ACCESS_V2'; save();
  $('blackPackContent').innerHTML='<div class="purchase-success"><div class="success-icon">✓</div><h3>Спасибо за покупку!</h3><p>Вот твой пак</p></div><div class="pack-actions copy-only-actions"><button class="btn copy-link-btn" id="blackCopy" type="button"><span>Скопируйте ссылку<br>вставьте в гугл<br>И далее следуйте гайду</span></button><div id="blackCopyStatus" class="status"></div></div>';
  $('blackCopy').onclick=async()=>{try{if(window.AndroidBridge&&AndroidBridge.copyText)AndroidBridge.copyText(BLACK_PACK_URL);else if(navigator.clipboard&&navigator.clipboard.writeText)await navigator.clipboard.writeText(BLACK_PACK_URL);else{const t=document.createElement('textarea');t.value=BLACK_PACK_URL;document.body.appendChild(t);t.select();document.execCommand('copy');t.remove()}$('blackCopyStatus').className='status ok';$('blackCopyStatus').textContent='Ссылка скопирована.'}catch(e){$('blackCopyStatus').className='status err';$('blackCopyStatus').textContent='Не удалось скопировать ссылку.'}};
  if(withFirework) firework();
}
async function redeemBlackPack(){ const input=($('blackPackKey')?.value||'').replace(/\s+/g,'').trim(); const status=$('blackPackStatus'); if(status){status.className='status';status.textContent=''}; if(!input){status.className='status err';status.textContent='Введи ключ.';return;} try{ const hash=await sha256Hex(input); const validHash='eecb7a5f05bbe455fa22670d053c7f59a9deedd8a0e47e18583236816ea88391'; if(hash!==validHash){status.className='status err';status.textContent='Неверный ключ.';return;} renderBlackSuccess(true); }catch(e){status.className='status err';status.textContent='Не удалось проверить ключ.';} }

const TRAINERS_URL='https://www.mediafire.com/file/8v5uds18j5nnotf/g2038.zip/file';
function showTrainersModal(){
  document.body.classList.add('modal-open');
  $('trainersModal').classList.remove('hidden');
  if(state.trainersUnlocked&&state.trainersAccessToken==='TRAINERS_ACCESS_V2'){renderTrainersSuccess(false);return;}
  $('trainersContent').innerHTML='<div class="key-box"><b>Введи ключ</b><input id="trainersKey" maxlength="5" inputmode="text" autocapitalize="characters" placeholder="Введи ключ доступа" autocomplete="off"><div class="key-actions"><button class="btn" id="redeemTrainers" type="button">АКТИВИРОВАТЬ</button><button class="btn secondary" id="closeTrainers2" type="button">ОТМЕНА</button></div><div id="trainersStatus" class="status"></div></div><p class="notice">Введите ключ доступа для получения чита.</p>';
  $('redeemTrainers').onclick=redeemTrainersKey;
  $('closeTrainers2').onclick=closeTrainersModal;
  $('trainersKey').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();redeemTrainersKey()}});
  setTimeout(()=>$('trainersKey')?.focus(),80);
}
function closeTrainersModal(){ $('trainersModal').classList.add('hidden'); document.body.classList.remove('modal-open'); }
async function redeemTrainersKey(){
  const input=($('trainersKey').value||'').replace(/\s+/g,'').trim();
  const status=$('trainersStatus');
  if(!input){status.className='status err';status.textContent='Введи ключ.';return;}
  try{
    const hash=await sha256Hex(input);
    const validHash='87d5af5075ad00262a175e36262a0ae32286a1ceb29194dbfdfda75d78588e46';
    if(hash!==validHash){status.className='status err';status.textContent='Неверный ключ.';return;}
    state.trainersUnlocked=true; state.trainersAccessToken='TRAINERS_ACCESS_V2'; save();
    renderTrainersSuccess(true);
  }catch(e){status.className='status err';status.textContent='Не удалось проверить ключ. Попробуй ещё раз.';}
}
function renderTrainersSuccess(withFirework=true){
  state.trainersUnlocked=true; state.trainersAccessToken='TRAINERS_ACCESS_V2'; save();
  $('trainersContent').innerHTML='<div class="purchase-success"><div class="success-icon">✓</div><h3>Спасибо за покупку!</h3><p>Вот твой чит</p></div><div class="pack-actions copy-only-actions"><button class="btn copy-link-btn" id="copyTrainers" type="button"><span>Скопируйте ссылку<br>вставьте в гугл<br>И далее следуйте гайду</span></button><div id="trainersCopyStatus" class="status"></div></div>';
  $('copyTrainers').onclick=async()=>{
    try{
      if(window.AndroidBridge&&AndroidBridge.copyText)AndroidBridge.copyText(TRAINERS_URL);
      else if(navigator.clipboard&&navigator.clipboard.writeText)await navigator.clipboard.writeText(TRAINERS_URL);
      else{const ta=document.createElement('textarea');ta.value=TRAINERS_URL;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();}
      $('trainersCopyStatus').className='status ok';$('trainersCopyStatus').textContent='Ссылка скопирована.';
    }catch(e){$('trainersCopyStatus').className='status err';$('trainersCopyStatus').textContent='Не удалось скопировать ссылку.'}
  };
  if(withFirework) firework();
}
const BMGO_URL='https://www.mediafire.com/file/ga43rce7r005dgl/g20151633%25283%2529.zip/file';
const CARTOON_URL='https://www.mediafire.com/file/n58bt0p6xw2sxf9/g20151633%25284%2529.zip/file';
const CS2_URL='https://www.mediafire.com/file/z66d46h1zr802pu/g20151633.zip/file';
const BMGO_HASH='90268954284cb5dc36fee162c2c4049290bed9ba19dc149aaee33efffcad7ab0';
const CARTOON_HASH='055ea0d86874c4ec5ef484e4d7b16102dfd663b2b20cba310e2b953df7b93ddc';
const CS2_HASH='7235519ba428b27d29b3fdbd01b2b7a1d014aa86b425a00843cf2f3ecc43475b';
function newTexturePackModal(cfg){
 const m=$(cfg.modal), content=$(cfg.content); document.body.classList.add('modal-open'); m.classList.remove('hidden');
 if(state[cfg.unlocked]&&state[cfg.token]===cfg.accessToken){renderNewTextureSuccess(cfg,false);return;}
 content.innerHTML='<div class="key-box"><b>Введи ключ</b><input id="'+cfg.input+'" maxlength="5" inputmode="text" autocapitalize="characters" placeholder="Введи ключ доступа" autocomplete="off"><div class="key-actions"><button class="btn" id="'+cfg.redeem+'" type="button">АКТИВИРОВАТЬ</button><button class="btn secondary" id="'+cfg.cancel+'" type="button">ОТМЕНА</button></div><div id="'+cfg.status+'" class="status"></div></div><p class="notice">После успешной активации доступ к пакету сохранится на этом устройстве.</p>';
 $(cfg.redeem).onclick=()=>redeemNewTexture(cfg); $(cfg.cancel).onclick=()=>closeNewTexture(cfg); $(cfg.input).addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();redeemNewTexture(cfg)}}); setTimeout(()=>$(cfg.input)?.focus(),60);
}
async function redeemNewTexture(cfg){
 const input=($(cfg.input)?.value||'').replace(/\s+/g,'').trim().toUpperCase(), status=$(cfg.status), btn=$(cfg.redeem); if(!input){status.className='status err';status.textContent='Введи ключ.';return;} btn.disabled=true;btn.textContent='ПРОВЕРКА...';
 try{const hash=await sha256Hex(input);if(hash!==cfg.hash){status.className='status err';status.textContent='Неверный ключ.';return;}state[cfg.unlocked]=true;state[cfg.token]=cfg.accessToken;save();renderNewTextureSuccess(cfg,true)}catch(e){status.className='status err';status.textContent='Не удалось проверить ключ.'}finally{btn.disabled=false;btn.textContent='АКТИВИРОВАТЬ'}
}
function renderNewTextureSuccess(cfg,withFirework){state[cfg.unlocked]=true;state[cfg.token]=cfg.accessToken;save();$(cfg.content).innerHTML='<div class="purchase-success"><div class="success-icon">✓</div><h3>Доступ активирован</h3><p>Ссылка на текстур пак готова.</p></div><div class="pack-actions copy-only-actions"><button class="btn copy-link-btn" id="'+cfg.copy+'" type="button"><span>СКОПИРОВАТЬ ССЫЛКУ</span></button><div id="'+cfg.copyStatus+'" class="status"></div></div>';$(cfg.copy).onclick=()=>copyNewCheatLink(cfg.url,cfg.copyStatus);if(withFirework)firework()}
function closeNewTexture(cfg){$(cfg.modal).classList.add('hidden');document.body.classList.remove('modal-open')}
const BMGO_CFG={modal:'bmgoPackModal',content:'bmgoPackContent',input:'bmgoPackKey',redeem:'redeemBmgoPack',cancel:'closeBmgoPack',status:'bmgoPackStatus',copy:'copyBmgoPack',copyStatus:'bmgoCopyStatus',url:BMGO_URL,hash:BMGO_HASH,unlocked:'bmgoUnlocked',token:'bmgoAccessToken',accessToken:'BMGO_ACCESS_V1'};
const CARTOON_CFG={modal:'cartoonPackModal',content:'cartoonPackContent',input:'cartoonPackKey',redeem:'redeemCartoonPack',cancel:'closeCartoonPack',status:'cartoonPackStatus',copy:'copyCartoonPack',copyStatus:'cartoonCopyStatus',url:CARTOON_URL,hash:CARTOON_HASH,unlocked:'cartoonUnlocked',token:'cartoonAccessToken',accessToken:'CARTOON_ACCESS_V1'};
const CS2_CFG={modal:'cs2PackModal',content:'cs2PackContent',input:'cs2PackKey',redeem:'redeemCs2Pack',cancel:'closeCs2Pack',status:'cs2PackStatus',copy:'copyCs2Pack',copyStatus:'cs2CopyStatus',url:CS2_URL,hash:CS2_HASH,unlocked:'cs2Unlocked',token:'cs2AccessToken',accessToken:'CS2_ACCESS_V1'};
function showBmgoPackModal(){newTexturePackModal(BMGO_CFG)} function closeBmgoPackModal(){closeNewTexture(BMGO_CFG)}
function showCartoonPackModal(){newTexturePackModal(CARTOON_CFG)} function closeCartoonPackModal(){closeNewTexture(CARTOON_CFG)}
function showCs2PackModal(){newTexturePackModal(CS2_CFG)} function closeCs2PackModal(){closeNewTexture(CS2_CFG)}
const ANIME_BREAKDOWN_URL='https://www.mediafire.com/file/yrxu1xh9g88xr1m/g2069.zip/file';
const ANIME_FIGHTING_URL='https://www.mediafire.com/file/d1cobqeq9qc3oux/g2033.zip/file';
const ANIME_BREAKDOWN_HASH='dff797831feb81a1ad96171decd53b19f6e3c5b80ad324ce83cdf5d309bedf5f';
const ANIME_FIGHTING_HASH='b373d92bbcc07fddaa780ef6ab644ea655f33b2f003048b568c366174f83d618';
function showAnimeBreakdownModal(){document.body.classList.add('modal-open');$('animeBreakdownModal').classList.remove('hidden');if(state.animeBreakdownUnlocked&&state.animeBreakdownAccessToken==='ANIME_BREAKDOWN_ACCESS_V1')renderAnimeBreakdownSuccess(false);else showAnimeBreakdownKeyEntry()}
function closeAnimeBreakdownModal(){$('animeBreakdownModal').classList.add('hidden');document.body.classList.remove('modal-open')}
function showAnimeBreakdownKeyEntry(){$('animeBreakdownContent').innerHTML='<div class="key-box"><b>Введи ключ</b><input id="animeBreakdownKey" maxlength="5" inputmode="text" autocapitalize="characters" placeholder="Введи ключ доступа" autocomplete="off"><div class="key-actions"><button class="btn" id="redeemAnimeBreakdown" type="button">АКТИВИРОВАТЬ</button><button class="btn secondary" type="button" onclick="closeAnimeBreakdownModal()">ОТМЕНА</button></div><div id="animeBreakdownStatus" class="status"></div></div><p class="notice">После успешной активации доступ к ссылке сохранится на этом устройстве.</p>';$('redeemAnimeBreakdown').onclick=redeemAnimeBreakdownKey;$('animeBreakdownKey').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();redeemAnimeBreakdownKey()}});setTimeout(()=>$('animeBreakdownKey')?.focus(),80)}
async function redeemAnimeBreakdownKey(){const input=($('animeBreakdownKey')?.value||'').replace(/\s+/g,'').trim().toUpperCase();const status=$('animeBreakdownStatus');if(!input){status.className='status err';status.textContent='Введи ключ.';return}try{const hash=await sha256Hex(input);if(hash!==ANIME_BREAKDOWN_HASH){status.className='status err';status.textContent='Неверный ключ.';return}state.animeBreakdownUnlocked=true;state.animeBreakdownAccessToken='ANIME_BREAKDOWN_ACCESS_V1';save();renderAnimeBreakdownSuccess(true)}catch(e){status.className='status err';status.textContent='Не удалось проверить ключ.'}}
function renderAnimeBreakdownSuccess(withFirework=true){state.animeBreakdownUnlocked=true;state.animeBreakdownAccessToken='ANIME_BREAKDOWN_ACCESS_V1';save();$('animeBreakdownContent').innerHTML='<div class="purchase-success"><div class="success-icon">✓</div><h3>Доступ активирован</h3><p>Ссылка на чит готова.</p></div><div class="pack-actions copy-only-actions"><button class="btn copy-link-btn" id="copyAnimeBreakdown" type="button"><span>СКОПИРОВАТЬ ССЫЛКУ</span></button><div id="animeBreakdownCopyStatus" class="status"></div></div>';$('copyAnimeBreakdown').onclick=async()=>copyNewCheatLink(ANIME_BREAKDOWN_URL,'animeBreakdownCopyStatus');if(withFirework)firework()}
function showAnimeFightingModal(){document.body.classList.add('modal-open');$('animeFightingModal').classList.remove('hidden');if(state.animeFightingUnlocked&&state.animeFightingAccessToken==='ANIME_FIGHTING_ACCESS_V1')renderAnimeFightingSuccess(false);else showAnimeFightingKeyEntry()}
function closeAnimeFightingModal(){$('animeFightingModal').classList.add('hidden');document.body.classList.remove('modal-open')}
function showAnimeFightingKeyEntry(){$('animeFightingContent').innerHTML='<div class="key-box"><b>Введи ключ</b><input id="animeFightingKey" maxlength="5" inputmode="text" autocapitalize="characters" placeholder="Введи ключ доступа" autocomplete="off"><div class="key-actions"><button class="btn" id="redeemAnimeFighting" type="button">АКТИВИРОВАТЬ</button><button class="btn secondary" type="button" onclick="closeAnimeFightingModal()">ОТМЕНА</button></div><div id="animeFightingStatus" class="status"></div></div><p class="notice">После успешной активации доступ к ссылке сохранится на этом устройстве.</p>';$('redeemAnimeFighting').onclick=redeemAnimeFightingKey;$('animeFightingKey').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();redeemAnimeFightingKey()}});setTimeout(()=>$('animeFightingKey')?.focus(),80)}
async function redeemAnimeFightingKey(){const input=($('animeFightingKey')?.value||'').replace(/\s+/g,'').trim().toUpperCase();const status=$('animeFightingStatus');if(!input){status.className='status err';status.textContent='Введи ключ.';return}try{const hash=await sha256Hex(input);if(hash!==ANIME_FIGHTING_HASH){status.className='status err';status.textContent='Неверный ключ.';return}state.animeFightingUnlocked=true;state.animeFightingAccessToken='ANIME_FIGHTING_ACCESS_V1';save();renderAnimeFightingSuccess(true)}catch(e){status.className='status err';status.textContent='Не удалось проверить ключ.'}}
function renderAnimeFightingSuccess(withFirework=true){state.animeFightingUnlocked=true;state.animeFightingAccessToken='ANIME_FIGHTING_ACCESS_V1';save();$('animeFightingContent').innerHTML='<div class="purchase-success"><div class="success-icon">✓</div><h3>Доступ активирован</h3><p>Ссылка на чит готова.</p></div><div class="pack-actions copy-only-actions"><button class="btn copy-link-btn" id="copyAnimeFighting" type="button"><span>СКОПИРОВАТЬ ССЫЛКУ</span></button><div id="animeFightingCopyStatus" class="status"></div></div>';$('copyAnimeFighting').onclick=async()=>copyNewCheatLink(ANIME_FIGHTING_URL,'animeFightingCopyStatus');if(withFirework)firework()}
async function copyNewCheatLink(url,statusId){try{if(window.AndroidBridge&&AndroidBridge.copyText)AndroidBridge.copyText(url);else if(navigator.clipboard&&navigator.clipboard.writeText)await navigator.clipboard.writeText(url);else{const ta=document.createElement('textarea');ta.value=url;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove()}$(statusId).className='status ok';$(statusId).textContent='Ссылка скопирована.'}catch(e){$(statusId).className='status err';$(statusId).textContent='Не удалось скопировать ссылку.'}}
function openTextureGuide(){const m=$('textureGuideModal');if(m){m.classList.remove('hidden');document.body.classList.add('modal-open')}}
function closeTextureGuide(){const m=$('textureGuideModal');if(m){m.classList.add('hidden');document.body.classList.remove('modal-open')}}
function showSoonNotice(){const n=$('iosSoonNotice');if(!n)return;clearTimeout(window.__soonTimer);requestAnimationFrame(()=>{n.classList.remove('hidden');});window.__soonTimer=setTimeout(()=>{requestAnimationFrame(()=>n.classList.add('hidden'));},2400)}
function switchTab(tab){
  const sections = window.__hubSections || (window.__hubSections = {
    scripts: document.getElementById('scripts'),
    packs: document.getElementById('packs'),
    guides: document.getElementById('guides'),
    cheats: document.getElementById('cheats')
  });
  const tabs = window.__hubTabs || (window.__hubTabs = Array.from(document.querySelectorAll('.tabs .tab')));
  if(!sections[tab]) return;
  for(let i=0;i<tabs.length;i++){
    const b=tabs[i];
    const active=b.dataset.tab===tab;
    if(b.classList.contains('active')!==active) b.classList.toggle('active',active);
  }
  const keys=['scripts','packs','guides','cheats'];
  for(let i=0;i<keys.length;i++){
    const id=keys[i], el=sections[id];
    if(el){
      const hidden=id!==tab;
      if(el.classList.contains('hidden')!==hidden) el.classList.toggle('hidden',hidden);
    }
  }
}
window.switchTab=switchTab;

(function(){
  const strip=document.querySelector('.tabs');
  if(!strip) return;
  strip.addEventListener('pointerup', function(e){
    const tab=e.target.closest && e.target.closest('.tab');
    if(!tab || !strip.contains(tab)) return;
    e.preventDefault();
    const name=tab.dataset.tab;
    if(name) switchTab(name);
  }, {passive:false});
})();
// The tab buttons already use onclick="switchTab(...)" in the markup.
// Do not attach a second listener: duplicate dispatch was causing extra work on every tap.
$('bmgoPackModal').addEventListener('click',e=>{if(e.target===$('bmgoPackModal'))closeBmgoPackModal()});$('cartoonPackModal').addEventListener('click',e=>{if(e.target===$('cartoonPackModal'))closeCartoonPackModal()});$('cs2PackModal').addEventListener('click',e=>{if(e.target===$('cs2PackModal'))closeCs2PackModal()});$('openPack').onclick=showPackModal;$('blackPackModal').addEventListener('click',e=>{if(e.target===$('blackPackModal'))closeBlackPackModal()});document.querySelectorAll('.cheat-pack-preview').forEach(img=>img.onclick=()=>openImageViewer(img.src));document.querySelectorAll('.pack-preview').forEach(img=>{img.onclick=()=>openImageViewer(img.src)});if($('imageViewer'))$('imageViewer').addEventListener('click',e=>{if(e.target===$('imageViewer'))closeImageViewer()});
$('closeCheat').onclick=closeCheatModal;$('cheatModal').addEventListener('click',e=>{if(e.target===$('cheatModal'))closeCheatModal()});$('closeTrainers').onclick=closeTrainersModal;$('trainersModal').addEventListener('click',e=>{if(e.target===$('trainersModal'))closeTrainersModal()});$('trainersPreview').onclick=()=>openImageViewer($('trainersPreview').src);$('closeKey').onclick=closeKeyModal;$('keyModal').addEventListener('click',e=>{if(e.target===$('keyModal'))closeKeyModal()});$('packPreview').onclick=()=>$('previewModal').classList.remove('hidden');$('closePreview').onclick=()=>$('previewModal').classList.add('hidden');$('previewModal').addEventListener('click',e=>{if(e.target===$('previewModal'))$('previewModal').classList.add('hidden')});const GUIDE_URL='https://youtube.com/shorts/2Im7xlMIg9Q?si=8jdMCKCy3Ysg1qcv';
const GUIDE_OPEN_URL=GUIDE_URL;
function openExternal(url){
  url=String(url);
  try{if(window.AndroidBridge&&typeof AndroidBridge.openUrl==='function'){AndroidBridge.openUrl(url);return true}}catch(e){}
  try{window.location.href=url;return true}catch(e){}
  return false;
}
function openGuide(){ return openExternal(GUIDE_OPEN_URL); }
function copyGuideLink(){
  const status=$('guideCopyStatus');
  try{
    if(window.AndroidBridge&&typeof AndroidBridge.copyText==='function'){
      AndroidBridge.copyText(GUIDE_URL);
      status.className='status ok'; status.textContent='Ссылка скопирована.'; return;
    }
  }catch(e){}
  try{
    const ta=document.createElement('textarea');
    ta.value=GUIDE_URL; ta.readOnly=true; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.focus(); ta.select();
    const ok=document.execCommand('copy'); ta.remove();
    if(ok){status.className='status ok'; status.textContent='Ссылка скопирована.'; return;}
  }catch(e){}
  status.className='status err'; status.textContent='Зажмите ссылку выше и выберите «Копировать».';
}
function copyGuideVideoLink(){
  const url=GUIDE_URL, status=$('guideVideoCopyStatus');
  try{
    if(window.AndroidBridge&&typeof AndroidBridge.copyText==='function'){
      AndroidBridge.copyText(url);
      if(status){status.className='status ok';status.textContent='Ссылка скопирована.';} return;
    }
  }catch(e){}
  try{
    const ta=document.createElement('textarea'); ta.value=url; ta.readOnly=true; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.focus(); ta.select();
    const ok=document.execCommand('copy'); ta.remove();
    if(status){status.className=ok?'status ok':'status err';status.textContent=ok?'Ссылка скопирована.':'Зажмите ссылку и выберите «Копировать».';}
  }catch(e){if(status){status.className='status err';status.textContent='Зажмите ссылку и выберите «Копировать».';}}
}
document.addEventListener('pointerdown',()=>startMusic(),{once:true});try{apply();if(state.nick)enter(state.nick);else setTimeout(()=>$('nick')?.focus(),250);}catch(e){console.error('Satoriuou Hub boot error',e);document.body.classList.remove('login-mode');$('login')?.classList.add('hidden');$('hub')?.classList.remove('hidden');}


(function(){
  function wakeMusic(){
    try{
      const a=document.getElementById('bgMusic');
      if(!a || !window.state || !state.music)return;
      a.loop=true;a.volume=.30;
      const p=a.play(); if(p&&p.catch)p.catch(function(){});
    }catch(e){}
  }
  ['pointerdown','touchstart','click','keydown'].forEach(function(ev){document.addEventListener(ev,wakeMusic,{passive:true,once:false});});
  document.addEventListener('visibilitychange',function(){if(!document.hidden)wakeMusic();});
})();
