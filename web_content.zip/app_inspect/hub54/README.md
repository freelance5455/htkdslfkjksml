# Satoriuou Hub v18 — first-entry nick + one-time keys + looped music

## Что изменено
- Окно погоняла показывается только при первом запуске; ник сохраняется в localStorage.
- При следующих запусках окно погоняла не показывается.
- Фоновая музыка заменена на присланный трек, зациклена, громкость 30% от исходной (уменьшение на 70%).
- Анимированный фон полностью отключён.
- 100 ключей остаются одноразовыми и расходуются сервером.
- После успешной активации ключ навсегда становится использованным, в том числе для других устройств.
- Список ключей и секрет удалены из клиентских assets.
- Скачивание текстур-пака выполняется только через серверный `/api/download?token=...`.

## Важно: причина `Failed to fetch`
Приложение не может само по себе быть сервером, который хранит состояние 100 ключей между телефонами. Поэтому `API_BASE` должен указывать на реально запущенный HTTPS-сервер из папки `server`.

Открой:
`app/src/main/assets/web/api-config.js`

и укажи, например:
`window.API_BASE='https://твой-домен.example';`

Пока этот адрес пустой, приложение специально показывает понятную ошибку о ненастроенном сервере вместо `Failed to fetch`.

## Запуск сервера
Требуется Node.js 18+:
1. `cd server`
2. положить настоящий `texture-pack.zip` в `server/protected/`
3. `node server.js`
4. опубликовать сервер по HTTPS и указать его URL в `api-config.js`.

Для продакшена используй HTTPS/reverse proxy и `PUBLIC_ORIGIN`.
Не размещай `keys.json` или секреты в Android assets.


## v19
Permanent local key: `[secret]`. The app no longer requires a key server for activation. `PACK_URL` in `api-config.js` can be set later if a real download URL is available.


## v23
Updated black texture pack key verification and added Trainers Arena cheat pack with uploaded preview, fullscreen viewer, activation, download and copy-link actions.


## v24
Main tabs are horizontally scrollable/swipeable on mobile; added swipe navigation between sections and a lighter blue UI polish with animated section transitions.


## v25
Fixed vertical scrolling inside sections. Added lightweight animated ambient background, floating particles, glow, and visual polish while keeping the project small.
