Put branding images here:
slide1.jpg
slide2.jpg
slide3.jpg
Recommended size: 1200 x 150 pixels (or wider), JPG/PNG.
The slideshow HTML is one folder above this photos folder.
