# V37 — Excel Item Import

Dashboard now has **Import Excel** for bulk item creation.

Accepted files:
- `.xlsx`
- `.xls`
- `.csv` / `.txt`

Required column:
- `Name`

Optional columns:
- `Number`
- `Float Target`
- `Location`
- `Personal Number`
- `Details`

The importer reads the first worksheet, automatically matches common column-name variations, validates rows, shows a preview, then creates the items in batches under the currently signed-in user. Imported items start with no visit history.

For `.xlsx` and `.xls`, the app lazy-loads SheetJS CE 0.20.3 only when the importer is used. The official SheetJS CDN is attempted first, followed by jsDelivr. CSV files use the app's built-in parser.
