SaveMate – Daily Savings Tracker

HOW TO OPEN ON ANDROID
1. Download SaveMate_App.zip.
2. Open your Files app and extract the ZIP.
3. Open the extracted SaveMate_App folder.
4. Tap index.html and open it with Chrome.
5. Enter an amount, select a date, then tap Save Amount.

FEATURES
- Dashboard with TOTAL AMOUNT (no “your savings are growing” line)
- Today's Saving and This Month totals
- Add entries with amount, date, optional note
- Quick-add buttons for ₹50, ₹100 and ₹200
- Recent activity
- Full saving history with exact-date and date-range filters
- Per-entry delete option
- Savings goal with progress bar
- Export history as CSV
- Download and restore a JSON backup

DATA / LIMITATIONS
- Data is stored locally in this browser on this device.
- Keep backups using Settings > Download Backup.
- Clearing browser data may erase savings entries.
- This is a working web app, not an Android APK. Opening index.html in Chrome is required.
- Example amounts shown in design previews are illustrative; the app starts at ₹0.
