import "dotenv/config";
import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "32kb" }));

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) {
  console.error("Missing OPENAI_API_KEY. Add it to backend/.env");
  process.exit(1);
}

const openai = new OpenAI({ apiKey });
const model = process.env.OPENAI_MODEL;
if (!model) {
  console.error("Missing OPENAI_MODEL. Set it to a model ID available to your API account in backend/.env");
  process.exit(1);
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "ANU AI backend" }));

app.post("/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    const previousResponseId =
      typeof req.body?.previousResponseId === "string" ? req.body.previousResponseId : undefined;

    if (!message) return res.status(400).json({ error: "Message is required." });
    if (message.length > 8000) return res.status(413).json({ error: "Message is too long." });

    const response = await openai.responses.create({
      model,
      instructions:
        "You are ANU AI, a friendly, capable personal assistant. Be accurate, useful, and concise. " +
        "Understand and respond in the language the user uses, including English, Hindi, and Nepali. " +
        "Do not claim to control the phone or perform actions unless an actual tool has done so. " +
        "Ask for confirmation before consequential actions.",
      input: message,
      ...(previousResponseId ? { previous_response_id: previousResponseId } : {})
    });

    res.json({
      answer: response.output_text || extractOutputText(response),
      responseId: response.id
    });
  } catch (error) {
    console.error("Chat request failed:", error?.status || "", error?.message || error);
    res.status(500).json({ error: "AI request failed. Check backend logs and API configuration." });
  }
});

function extractOutputText(response) {
  const parts = [];
  for (const item of response.output || []) {
    if (item.type === "message") {
      for (const content of item.content || []) {
        if (content.type === "output_text" && content.text) parts.push(content.text);
      }
    }
  }
  return parts.join("\n").trim();
}

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => {
  console.log(`ANU AI backend listening on http://0.0.0.0:${port}`);
});
