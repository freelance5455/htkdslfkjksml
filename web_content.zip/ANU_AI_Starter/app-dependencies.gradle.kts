// Merge these lines into the dependencies { } block of app/build.gradle.kts.
// Keep the Compose dependencies created by Android Studio's Empty Activity template.
implementation("com.squareup.okhttp3:okhttp:4.12.0")
implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
