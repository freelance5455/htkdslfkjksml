# ANU AI — Android Voice + Text Starter

This is a starter pack for an Android Studio **Empty Activity (Jetpack Compose)** project plus a small Node.js backend.

## What works in this MVP
- Text chat with an AI model through the OpenAI Responses API
- Speech input using Android's system speech-recognition UI
- Spoken replies using Android TextToSpeech
- A simple chat screen with a dark ANU AI theme
- Conversation continuity during the current app session
- Screen locking after the user explicitly enables ANU AI as a Device Administrator
- Screen wake when ANU AI's activity is brought to the foreground (Android restricts waking from the background)

## Architecture

Android app -> your Node.js backend -> OpenAI Responses API

**Never put your OpenAI API key in the Android app.** Keep it in the backend `.env` file.

## Part A — Create the Android project

1. Install Android Studio on a computer.
2. Choose **New Project → Empty Activity**.
3. Set:
   - Name: `ANU AI`
   - Package: `com.example.anuai`
   - Language: Kotlin
   - Minimum SDK: API 26 or higher
   - Use Jetpack Compose: enabled
4. Let Android Studio create and sync the project.
5. Replace `app/src/main/java/com/example/anuai/MainActivity.kt` with the file in this pack.
6. Merge the permissions, `<queries>`, and device-admin receiver entries from `AndroidManifest.xml` into your app manifest. Keep the existing `<application>` element and set its label to `ANU AI`.
7. Copy `app/src/main/res/xml/device_admin.xml` into the same resource path in your Android project (create the `xml` folder if needed).
8. Add the dependencies shown in `app-dependencies.gradle.kts` to your app-level `build.gradle.kts` dependencies block.
9. Sync Gradle.

If your package name differs, change the `package` line in `MainActivity.kt` to match it.

## Part B — Start the backend

Install Node.js 20 or newer.

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env` and set your OpenAI API key. Do not share this file or commit it to Git.

Start the server:

```bash
npm start
```

The server listens on port 3000 by default.

### Make your backend reachable from the phone

- **Phone and computer on same Wi-Fi:** find your computer's LAN IP (for example `192.168.1.20`) and set `BASE_URL` in `MainActivity.kt` to `http://192.168.1.20:3000/`.
- Allow inbound TCP port 3000 in your computer firewall.
- Android blocks cleartext HTTP for many app configurations. For local development only, the supplied manifest includes `android:usesCleartextTraffic="true"`. Do not use plain HTTP on a public network. Deploy the backend behind HTTPS before real use.

If using the Android emulator, use `http://10.0.2.2:3000/` instead of `localhost`.

## Part C — Run ANU AI

1. Connect your Android phone with USB debugging enabled, or start an emulator.
2. In Android Studio, select your device and press **Run ▶**.
3. Type a message and tap Send.
4. Tap the microphone button and speak. Android's speech UI will return recognized text.
5. ANU AI reads the answer aloud. Use the speaker toggle to mute/unmute.

## Part D — Important configuration

In `MainActivity.kt`:
- Change `BASE_URL` to your backend address.
- Set `OPENAI_MODEL` in backend `.env` to a model ID enabled for your API account.

## Troubleshooting

- **Network error:** check the server is running, phone and computer share Wi-Fi, IP is correct, and firewall allows port 3000.
- **401 from backend:** check `OPENAI_API_KEY` in backend `.env`.
- **Model error:** set `OPENAI_MODEL` to a model available to your API account.
- **No speech result:** check that a speech recognition service is available and that microphone access is enabled for the system speech app.
- **No sound:** check phone media volume and Android TTS language availability.

## Security and production notes

This is a learning MVP, not a production deployment. Before public release:
- Deploy backend over HTTPS.
- Add user authentication and rate limiting.
- Add per-user quotas and request-size limits.
- Avoid logging private prompts or API credentials.
- Add privacy disclosures before recording or sending user content.
- Store conversation history deliberately, with deletion controls.
- Ask for confirmation before sending messages, making purchases, or performing sensitive device actions.

The app does not have a hidden always-listening wake word. Voice input starts only when the user taps the microphone.


## Screen lock / wake feature

The updated starter adds a **Lock screen** control and recognizes simple lock phrases typed or dictated into the chat. Android requires the user to explicitly activate ANU AI as a Device Administrator before `lockNow()` can lock the device. The app opens the system authorization screen; the user must review and approve it.

This starter intentionally does **not** claim to support always-listening "Hey ANU" while the phone is locked. Android background microphone and background activity-launch restrictions vary by OS version and manufacturer. The current safe implementation can lock on a user-initiated command while the app is open; waking the screen is supported when ANU AI's activity is brought to the foreground. A tap on the app or notification may be needed to bring it forward. It does not bypass PIN, fingerprint, or lock-screen security.


## ANU AI red-orb home interface

The app home header features a custom animated red energy orb with a soft glow, pulsing core, and rotating ring accents. The orb is drawn natively with Jetpack Compose Canvas, so it does not need an image asset or network connection.

## HTML home interface (`root.html`)

The Android app now loads `app/src/main/assets/root.html` as its home screen in an Android WebView. The red orb, chat composer, voice toggle, microphone action, and screen-lock control are defined in this HTML file. Android bridges the HTML interface to the existing backend, system speech recognition, TextToSpeech, and the user-authorized Device Administrator screen-lock feature. Edit `root.html` to customize the interface; keep the Android bridge function names intact unless you also update `MainActivity.kt`.

This is still a starter project and has not been compiled or tested on a device in this environment. The backend URL and Android manifest setup must be configured as described above.
