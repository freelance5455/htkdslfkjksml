package com.example.anuai

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale

private const val BASE_URL = "http://10.0.2.2:3000/" // Emulator; replace with your computer LAN IP for a real phone.
private val http = OkHttpClient()

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var voiceEnabled = true
    private var previousResponseId: String? = null
    private var pendingSpeech = false
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = android.speech.tts.TextToSpeech(this) { status ->
            ttsReady = status == android.speech.tts.TextToSpeech.SUCCESS
        }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(AnuBridge(), "AnuBridge")
            loadUrl("file:///android_asset/root.html")
        }
        setContentView(webView)
    }

    inner class AnuBridge {
        @JavascriptInterface fun setVoice(enabled: Boolean) {
            runOnUiThread { voiceEnabled = enabled }
        }
        @JavascriptInterface fun startVoice() {
            runOnUiThread {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ANU AI")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                }
                try { startActivityForResult(intent, 4102) }
                catch (_: Exception) { Toast.makeText(this@MainActivity, "Speech recognition is unavailable", Toast.LENGTH_SHORT).show() }
            }
        }
        @JavascriptInterface fun lockScreen() {
            runOnUiThread {
                val manager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                val component = ComponentName(this@MainActivity, AnuDeviceAdminReceiver::class.java)
                if (manager.isAdminActive(component)) manager.lockNow() else {
                    val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
                        putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allow ANU AI to lock the screen when you ask it to.")
                    }
                    startActivity(intent)
                }
            }
        }
        @JavascriptInterface fun sendMessage(message: String) {
            val clean = message.trim()
            if (clean.isEmpty()) return
            val normalized = clean.lowercase(Locale.ROOT)
            if (listOf("turn off screen", "lock my phone", "lock the phone", "lock screen").any { normalized.contains(it) }) {
                lockScreen()
                showReply("If this is your first time, approve ANU AI's screen-lock permission in Android Settings.")
                return
            }
            if (listOf("turn on screen", "wake up screen", "wake my phone").any { normalized.contains(it) }) {
                showReply("Open ANU AI from its app icon or notification to wake the display. Android restricts background wake-ups.")
                return
            }
            runOnUiThread { webView.evaluateJavascript("setStatus('ANU IS THINKING')", null) }
            lifecycleScope.launch {
                try {
                    val result = withContext(Dispatchers.IO) { askAnu(clean, previousResponseId) }
                    previousResponseId = result.responseId
                    showReply(result.answer)
                    if (voiceEnabled && ttsReady) tts?.speak(result.answer, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "anu_reply")
                } catch (e: Exception) {
                    showReply("I couldn't reach my AI service. Check your backend connection and settings.")
                }
            }
        }
    }

    @Deprecated("Android speech recognizer result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4102 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            val encoded = org.json.JSONObject.quote(spoken)
            webView.evaluateJavascript("setRecognized($encoded)", null)
        }
    }

    private fun showReply(message: String) {
        val encoded = org.json.JSONObject.quote(message)
        runOnUiThread { webView.evaluateJavascript("reply($encoded)", null) }
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown(); tts = null
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}

private data class AnuResult(val answer: String, val responseId: String?)

private fun askAnu(message: String, previousId: String?): AnuResult {
    val json = JSONObject().put("message", message)
    if (previousId != null) json.put("previousResponseId", previousId)
    val request = Request.Builder().url("${BASE_URL}chat")
        .post(json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
    http.newCall(request).execute().use { response ->
        val body = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("Server ${response.code}")
        val obj = JSONObject(body)
        return AnuResult(obj.optString("answer", "I didn't receive a text response."),
            obj.optString("responseId").takeIf { it.isNotBlank() && it != "null" })
    }
}
