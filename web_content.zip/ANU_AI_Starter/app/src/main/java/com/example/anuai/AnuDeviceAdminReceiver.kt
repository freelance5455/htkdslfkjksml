package com.example.anuai

import android.app.admin.DeviceAdminReceiver

/**
 * Receives explicit Device Administrator enable/disable events.
 * The user remains in control and can revoke this permission in Android Settings.
 */
class AnuDeviceAdminReceiver : DeviceAdminReceiver()
