const productsEl = document.getElementById('products');
productsEl.innerHTML = products.map((p, i) => `
  <article class="product">
    <a href="${p.link}" target="_blank" rel="noopener sponsored">
      <img src="${p.image}" alt="${p.name}" loading="lazy">
    </a>
    <div class="product-body">
      <div class="badge">TEAMPAWER PICK</div>
      <h3>${p.name}</h3>
      <div class="meta">${p.meta}</div>
      <div class="price">${p.price}</div>
      <a class="buy" href="${p.link}" target="_blank" rel="noopener sponsored">🛒 BUY ON SHOPEE</a>
    </div>
  </article>
`).join('');

const installBtn = document.getElementById('installBtn');
let deferredPrompt;
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault(); deferredPrompt = e; installBtn.hidden = false;
});
installBtn?.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt(); await deferredPrompt.userChoice;
  deferredPrompt = null; installBtn.hidden = true;
});
