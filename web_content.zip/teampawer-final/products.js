// TeamPawer Shopee affiliate deals.
const products = [
  {
    name: '700CC Road Bike for Adult 26 inches',
    price: '₱5,248',
    meta: '4.6 ★ · 564 sold',
    image: 'assets/products/road-bike.jpg',
    link: 'https://s.shopee.ph/7AdWXm0SXq'
  },
  {
    name: 'Q8 Electric Bike E-Bike for Adult 48V12Ah',
    price: '₱15,935',
    meta: '4.8 ★ · 2K+ sold',
    image: 'assets/products/electric-bike.jpg',
    link: 'https://s.shopee.ph/3g3e14vLk3'
  },
  {
    name: '3/5/8 Person Automatic Waterproof Camping Tent',
    price: '₱1,109',
    meta: '5.0 ★ · 132 sold',
    image: 'assets/products/camping-tent.jpg',
    link: 'https://s.shopee.ph/4LJJIUX8Oz'
  },
  {
    name: 'GoldStar Electric Rice Cooker 2L/3L/4L/6L',
    price: '₱669',
    meta: '4.6 ★ · 10K+ sold',
    image: 'assets/products/rice-cooker.jpg',
    link: 'https://s.shopee.ph/4fw9eOoMxt'
  }
];
