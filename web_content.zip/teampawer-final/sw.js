const CACHE='teampawer-v1';
const ASSETS=['./','./index.html','./styles.css','./app.js','./products.js','./manifest.json','./assets/teampawer-logo.png','./assets/teampawer-banner.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
