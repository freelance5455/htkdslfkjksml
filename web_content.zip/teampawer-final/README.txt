TEAMPAWER APP

This is a mobile-friendly Progressive Web App (PWA) for the TeamPawer YouTube channel and Shopee affiliate deals.

Included:
- TeamPawer branding/logo/banner
- YouTube channel link: https://youtube.com/@teampawer
- 4 Shopee affiliate product cards with the supplied screenshots
- Buy buttons linked to the supplied Shopee affiliate URLs
- Installable PWA support

Product links:
1. https://s.shopee.ph/7AdWXm0SXq
2. https://s.shopee.ph/3g3e14vLk3
3. https://s.shopee.ph/4LJJIUX8Oz
4. https://s.shopee.ph/4fw9eOoMxt

To publish as a real Android app, this web app can next be wrapped with Capacitor and built as an Android App Bundle (AAB) for Google Play.
