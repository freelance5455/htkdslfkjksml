#!/bin/bash
# Void RAM Optimizer v5.7.2 - Comandos limpos com 2>/dev/null || true
echo "Aplicando Void RAM Optimizer..."

pm trim-caches 999G 2>/dev/null || true
am kill-all 2>/dev/null || true
settings put global cached_apps_freezer enabled 2>/dev/null || true
settings put global app_standby_enabled 0 2>/dev/null || true
setprop persist.sys.purgeable_assets 1 2>/dev/null || true
setprop ro.config.low_ram false 2>/dev/null || true

echo "Void RAM Optimizer aplicado!"
