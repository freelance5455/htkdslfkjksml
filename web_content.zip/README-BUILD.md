# بنفسج — حزمة بناء APK (أندرويد أصلي)

هذه الحزمة تحتوي الملفات اللازمة للبناء فقط. التطبيق نفسه داخل `android-native/app/src/main/assets/index.html` (واجهة + مكتبة 3,604 عناصر في ملف واحد، بلا إنترنت وبلا أي خدمة خارجية)، وملفات المحتوى الأصلية في `data/`.

> هذا مشروع **أندرويد أصلي** (Gradle). لا يُرفع إلى مواقع تحويل HTML إلى APK؛ لهذه المواقع استخدم الحزمة الأخرى `binafsaj-web-converter.zip`.

## الطريقة 1 — بناء في السحابة (دون تثبيت شيء)
1. أنشئ مستودعًا جديدًا على GitHub (فارغًا) وارفع محتويات هذه الحزمة بعد فك الضغط.
2. المجلد `.github` مخفي وقد لا يُرفع بالسحب والإفلات: افتح **Add file ← Create new file**، اكتب المسار `.github/workflows/build-apk.yml` والصق محتوى الملف `ci/build-apk.yml`.
3. من تبويب **Actions** ← **Build APK** ← **Run workflow**.
4. بعد دقائق نزّل `binafsaj-apk` من أسفل صفحة التشغيل (يحتوي `app-debug.apk`).

## الطريقة 2 — Android Studio
افتح المجلد `android-native` (وليس مجلدًا آخر) ← انتظر Gradle Sync ← **Build ← Build APK(s)**.
الناتج: `android-native/app/build/outputs/apk/debug/app-debug.apk`

## التثبيت
انقل الملف إلى الهاتف وافتحه (فعّل التثبيت من مصادر غير معروفة). قد يعرض Play Protect تحذيرًا لأن النسخة موقّعة بمفتاح التطوير.

## تعديل التطبيق
عدّل `app/src/main/assets/index.html` ثم أعد البناء. معرّف التطبيق `app.binafsaj.words` (غيّره في `app/build.gradle` وفي مسار `java/app/binafsaj/words` قبل النشر على Google Play). التطبيق لا يطلب أي صلاحية.

## ما لم يُتحقق منه
لم يُبنَ APK ولم يُجرَّب على جهاز أندرويد. فُحصت ملفات XML ومراجع الموارد، وتُرجمت `MainActivity.java` مقابل نماذج محاكاة لفئات أندرويد، واختُبرت الواجهة في Chromium بما فيه ظروف WebView قاسية. إن ظهر خطأ في Gradle فأرسل نصّه.
