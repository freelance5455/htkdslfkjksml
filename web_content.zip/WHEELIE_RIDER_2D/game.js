(() => {
'use strict';

const $ = (s, root=document) => root.querySelector(s);
const app = $('#app');
const MAPS = [
  {id:'city',name:'CITY STREET',desc:'Jalan kota, lampu, gedung, dan lalu lintas dekoratif.',emoji:'🏙️',bg1:'#6ca8c7',bg2:'#d7e7e9',ground:'#444e59',accent:'#f2c44e',amp:10,freq:.012,diff:1.0,price:0},
  {id:'desert',name:'DESERT RUN',desc:'Bukit pasir, batu, kaktus, dan udara gurun.',emoji:'🌵',bg1:'#e9ad6a',bg2:'#ffe1a2',ground:'#bd8850',accent:'#f5dc78',amp:18,freq:.009,diff:1.15,price:0},
  {id:'forest',name:'GREEN FOREST',desc:'Hutan hijau, semak, jalur tanah, dan bukit.',emoji:'🌲',bg1:'#8bc8bb',bg2:'#d6e5a5',ground:'#4f7650',accent:'#a1d77a',amp:15,freq:.011,diff:1.1,price:0},
  {id:'mountain',name:'MOUNTAIN PASS',desc:'Tanjakan tajam, turunan panjang, dan bebatuan.',emoji:'⛰️',bg1:'#8eabc2',bg2:'#d6dbe0',ground:'#69747b',accent:'#d6e3ed',amp:25,freq:.008,diff:1.45,price:0},
  {id:'night',name:'NIGHT HIGHWAY',desc:'Langit malam, cahaya kota, dan marka bercahaya.',emoji:'🌙',bg1:'#101b42',bg2:'#384d7e',ground:'#222936',accent:'#6be7ff',amp:12,freq:.01,diff:1.2,price:0},
  {id:'industrial',name:'INDUSTRIAL ZONE',desc:'Gudang, pipa, kontainer, dan jalan bergelombang.',emoji:'🏭',bg1:'#7c8e9d',bg2:'#c5c5b3',ground:'#515b60',accent:'#e2a848',amp:20,freq:.014,diff:1.3,price:0},
  {id:'extreme',name:'EXTREME TRACK',desc:'Trek latihan, gundukan rapat, dan lompatan kecil.',emoji:'🚩',bg1:'#b1a1d0',bg2:'#f0c4a1',ground:'#745c67',accent:'#ffb52e',amp:28,freq:.018,diff:1.65,price:0}
];
const CLASSES = [
  {name:'Bebek',prefix:'Swift',kind:'underbone',wheel:21,weight:1.0,accel:1.02,speed:1.0,stability:1.06,susp:0.84,brake:1.0,shape:0},
  {name:'Skuter',prefix:'Scoot',kind:'scooter',wheel:24,weight:1.12,accel:.92,speed:.91,stability:1.12,susp:1.0,brake:1.03,shape:1},
  {name:'Sport',prefix:'Vortex',kind:'sport',wheel:18,weight:.88,accel:1.18,speed:1.21,stability:.88,susp:.9,brake:1.17,shape:2},
  {name:'Naked',prefix:'Rogue',kind:'naked',wheel:21,weight:1.03,accel:1.08,speed:1.04,stability:1.03,susp:1.03,brake:1.05,shape:3},
  {name:'Trail',prefix:'Terra',kind:'trail',wheel:27,weight:1.06,accel:1.01,speed:.98,stability:1.1,susp:1.42,brake:.98,shape:4},
  {name:'Klasik',prefix:'Heritage',kind:'classic',wheel:24,weight:1.18,accel:.88,speed:.9,stability:1.17,susp:.94,brake:.93,shape:5},
  {name:'Futuristik',prefix:'Nova',kind:'future',wheel:20,weight:.95,accel:1.14,speed:1.16,stability:1.01,susp:1.12,brake:1.1,shape:6}
];
const SUFFIX = ['Satu','Pulse','Rift','Comet','Bolt','Echo','Drift','Blaze','Orbit','Titan'];
const COLORS = ['#ff6347','#32c4a0','#50a0ff','#ffcc45','#bd80ff','#f4f5f7','#f18ab8','#c2e86b','#ff8c42','#5f6fff','#ff4d8d','#8ad8ed'];
const RIMS = ['#eef3f7','#ffb52e','#52d9c0','#ff6262','#8f9fff','#252a32','#d8a1ff'];
const ACCENTS = ['#f5f6f7','#ffb52e','#161b22','#3be3bd','#ff647c','#79bfff','#d5e46b'];
const BIKES = [];
CLASSES.forEach((cls, ci) => {
  for (let n=0;n<10;n++) {
    const id = `bike-${String(ci*10+n+1).padStart(2,'0')}`;
    BIKES.push({id,name:`${cls.prefix} ${SUFFIX[n]}`,className:cls.name,kind:cls.kind,classIndex:ci,number:ci*10+n+1,
      color:COLORS[(ci*2+n)%COLORS.length],rim:RIMS[(ci+n)%RIMS.length],accent:ACCENTS[(n+ci*3)%ACCENTS.length],
      handling:clamp(42 + ((n*7+ci*5)%43),35,92),accel:round((3.3+((n*3+ci*5)%7)*.55)*cls.accel,1),
      speed:round((3.7+((n*5+ci*2)%7)*.55)*cls.speed,1),weight:round((3.2+((n*2+ci*4)%6)*.65)*cls.weight,1),
      stability:clamp(Math.round((43+((n*9+ci*7)%48))*cls.stability),30,98),brake:round((3+((n*4+ci)%7)*.5)*cls.brake,1),
      suspension:clamp(Math.round((35+((n*6+ci*8)%55))*cls.susp),25,99),
      price: n===0&&ci===0?0:Math.round(220+(ci*10+n)*38+ci*70),
      wheelRadius: cls.wheel + ((n%3)-1)*1.5, wheelbase: 58+ci*1.4+(n%5)*2.6,
      bodyLength: .8+(n%4)*.11+(ci%3)*.06, bodyHeight: .7+(n%3)*.12,
      seatHeight: 15+(n%4)*2+(ci===4?5:0), visualVariant:n%5, ownedByDefault:ci===0&&n===0
    });
  }
});
const MISSIONS = [
  {id:'m1',name:'Pemanasan',desc:'Selesaikan 1 perjalanan.',goal:1,stat:'runs',reward:100,emoji:'🏁'},
  {id:'m2',name:'Jarak Pendek',desc:'Capai jarak 100 m dalam satu perjalanan.',goal:100,stat:'runDistance',reward:120,emoji:'📏'},
  {id:'m3',name:'Raja Wheelie',desc:'Kumpulkan 5 detik wheelie dalam satu run.',goal:5,stat:'runWheelie',reward:150,emoji:'🛞'},
  {id:'m4',name:'Jelajah Kota',desc:'Mainkan map City Street.',goal:1,stat:'cityRuns',reward:100,emoji:'🏙️'},
  {id:'m5',name:'Ganti Suasana',desc:'Coba 3 map berbeda.',goal:3,stat:'mapCount',reward:180,emoji:'🗺️'},
  {id:'m6',name:'Kolektor',desc:'Miliki 3 motor.',goal:3,stat:'bikeCount',reward:220,emoji:'🏍️'},
  {id:'m7',name:'Teknisi',desc:'Beli satu upgrade.',goal:1,stat:'upgradeCount',reward:140,emoji:'🔧'},
  {id:'m8',name:'Penjelajah',desc:'Kumpulkan jarak total 500 m.',goal:500,stat:'totalDistance',reward:220,emoji:'🧭'},
  {id:'m9',name:'Tabungan',desc:'Kumpulkan total 500 koin dari perjalanan.',goal:500,stat:'totalCoinsEarned',reward:200,emoji:'🪙'},
  {id:'m10',name:'Lintas Kelas',desc:'Gunakan 3 kelas motor berbeda.',goal:3,stat:'classCount',reward:250,emoji:'🏆'}
];
const DEFAULT_SAVE = {
  version:1,coins:450,selectedBike:'bike-01',ownedBikes:['bike-01'],selectedMap:'city',unlockedMaps:MAPS.map(m=>m.id),
  highScore:0,totalDistance:0,runs:0,totalWheelieTime:0,totalCoinsEarned:0,lastRunDistance:0,lastRunWheelie:0,mapVisits:{},classUsed:[],upgrades:{},paint:{},
  missionsClaimed:[],dailyClaimDate:'',settings:{mute:false,quality:'normal',vibration:true}
};
let save = loadSave();
let screen='home', collectionFilter='Semua', collectionSearch='', selectedBikeId=save.selectedBike, modal=null;
let game=null, raf=0, lastFrame=0, audioContext=null;
const COLORS_BY_PAINT = k => k==='body'?COLORS:k==='rim'?RIMS:ACCENTS;
function clone(obj){return JSON.parse(JSON.stringify(obj));}
function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
function round(v,n=0){const p=10**n;return Math.round(v*p)/p;}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function bikeById(id){return BIKES.find(b=>b.id===id)||BIKES[0];}
function mapById(id){return MAPS.find(m=>m.id===id)||MAPS[0];}
function loadSave(){
  try {
    const raw=localStorage.getItem('wheelieRider2DSave');
    if(!raw)return clone(DEFAULT_SAVE);
    const parsed=JSON.parse(raw);
    const s={...clone(DEFAULT_SAVE),...parsed};
    s.settings={...DEFAULT_SAVE.settings,...(parsed.settings||{})};
    s.ownedBikes=Array.isArray(s.ownedBikes)?s.ownedBikes.filter(id=>BIKES.some(b=>b.id===id)):['bike-01'];
    if(!s.ownedBikes.includes('bike-01'))s.ownedBikes.unshift('bike-01');
    if(!BIKES.some(b=>b.id===s.selectedBike)||!s.ownedBikes.includes(s.selectedBike))s.selectedBike=s.ownedBikes[0];
    if(!MAPS.some(m=>m.id===s.selectedMap))s.selectedMap='city';
    s.unlockedMaps=Array.isArray(s.unlockedMaps)?s.unlockedMaps.filter(id=>MAPS.some(m=>m.id===id)):MAPS.map(m=>m.id);
    MAPS.forEach(m=>{if(!s.unlockedMaps.includes(m.id))s.unlockedMaps.push(m.id);});
    ['coins','highScore','totalDistance','runs','totalWheelieTime','totalCoinsEarned','lastRunDistance','lastRunWheelie'].forEach(k=>s[k]=Number.isFinite(Number(s[k]))?Math.max(0,Number(s[k])):0);
    ['mapVisits','upgrades','paint'].forEach(k=>{if(!s[k]||typeof s[k]!=='object'||Array.isArray(s[k]))s[k]={};});
    if(!Array.isArray(s.classUsed))s.classUsed=[];
    if(!Array.isArray(s.missionsClaimed))s.missionsClaimed=[];
    return s;
  } catch(e){ return clone(DEFAULT_SAVE); }
}
function saveGame(){try{localStorage.setItem('wheelieRider2DSave',JSON.stringify(save));}catch(e){console.warn('Penyimpanan lokal tidak tersedia:',e);}}
function getPaint(id=save.selectedBike){const b=bikeById(id);return {...{body:b.color,rim:b.rim,accent:b.accent,number:String(b.number).slice(-2),sticker:'stripe'},...(save.paint[id]||{})};}
function getUpgrades(id=save.selectedBike){return {...{engine:0,tires:0,suspension:0,brakes:0,stability:0},...(save.upgrades[id]||{})};}
function currentBike(){return bikeById(save.selectedBike);}
function effectiveStats(bike=currentBike()){
  const u=getUpgrades(bike.id), level=x=>Math.max(0,Number(u[x])||0);
  return {handling:clamp(bike.handling+level('stability')*5,1,100),accel:bike.accel*(1+level('engine')*.11),speed:bike.speed*(1+level('engine')*.075),weight:bike.weight,
    stability:clamp(bike.stability+level('stability')*7,1,115),brake:bike.brake*(1+level('brakes')*.12),suspension:clamp(bike.suspension+level('suspension')*8,1,120),traction:1+level('tires')*.1};
}
function beep(freq=440,duration=.07,type='sine'){
  if(save.settings.mute)return;
  try{audioContext ||= new (window.AudioContext||window.webkitAudioContext)();if(audioContext.state==='suspended')audioContext.resume();const osc=audioContext.createOscillator(),gain=audioContext.createGain();osc.type=type;osc.frequency.value=freq;gain.gain.setValueAtTime(.035,audioContext.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+duration);osc.connect(gain);gain.connect(audioContext.destination);osc.start();osc.stop(audioContext.currentTime+duration);}catch(e){}
}
function topbar(){return `<div class="topbar"><div class="brand">WHEELIE <span>RIDER 2D</span></div><div class="coin-pill">🪙 ${Math.floor(save.coins).toLocaleString('id-ID')}</div></div>`;}
function pageTitle(title,desc,back='home'){return `<div class="page-title"><button class="small subtle" data-action="nav" data-to="${back}">← Kembali</button><div><h1>${title}</h1><p>${desc}</p></div></div>`;}
function statBox(value,label){return `<div class="stat"><strong>${value}</strong><span>${label}</span></div>`;}
function renderHome(){
  screen='home';modal=null;
  const bike=currentBike();const progressLevel=1+Math.floor(save.totalDistance/250);
  app.innerHTML=`${topbar()}<section class="hero"><h1>KUASAI<br><em>WHEELIE.</em></h1><p>Seimbangkan motor, jelajahi 7 map, kumpulkan koin, dan rakit motor andalanmu. Semua bisa dimainkan offline.</p><div class="hero-actions"><button class="primary" data-action="play">▶ MAIN SEKARANG</button><button data-action="nav" data-to="garage">🔧 GARASI</button><button class="subtle" data-action="daily">🎁 BONUS HARIAN</button></div></section>
  <div class="stats-grid">${statBox(`Lv. ${progressLevel}`,'LEVEL PEMAIN')}${statBox(`${Math.floor(save.totalDistance)} m`,'TOTAL JARAK')}${statBox(`${Math.floor(save.highScore)} m`,'REKOR TERBAIK')}</div>
  <div class="section-head"><h2>Menu Utama</h2><span class="muted">Profil lokal • Offline</span></div>
  <div class="menu-grid"><button class="menu-card" data-action="nav" data-to="garage"><span class="ico">🔧</span><b>GARASI</b><small>Pilih & modifikasi motor</small></button><button class="menu-card" data-action="nav" data-to="maps"><span class="ico">🗺️</span><b>MAP</b><small>7 arena berbeda</small></button><button class="menu-card" data-action="nav" data-to="collection"><span class="ico">🏍️</span><b>KOLEKSI</b><small>${save.ownedBikes.length}/70 motor</small></button><button class="menu-card" data-action="nav" data-to="missions"><span class="ico">🎯</span><b>MISI</b><small>${MISSIONS.filter(m=>missionProgress(m)>=m.goal&&!save.missionsClaimed.includes(m.id)).length} siap diklaim</small></button><button class="menu-card" data-action="nav" data-to="settings"><span class="ico">⚙️</span><b>PENGATURAN</b><small>Audio & data</small></button><button class="menu-card" data-action="nav" data-to="profile"><span class="ico">👤</span><b>PROFIL</b><small>Statistik pemain</small></button></div>
  <div class="section-head"><h2>Motor Aktif</h2><button class="small subtle" data-action="nav" data-to="garage">Atur motor →</button></div><div class="panel" style="display:flex;align-items:center;gap:14px"><canvas class="bike-preview" data-preview="${bike.id}" width="280" height="100" style="width:128px;height:80px;flex:none;margin:0"></canvas><div style="min-width:0;flex:1"><strong>${esc(bike.name)}</strong><div class="muted" style="font-size:.82rem">${bike.className} • ${effectiveStats(bike).speed.toFixed(1)} SPD</div><div class="badge-row"><span class="pill">${mapById(save.selectedMap).emoji} ${mapById(save.selectedMap).name}</span></div></div></div>
  <p class="footer-note">Versi offline • Progres disimpan di perangkat ini dengan localStorage.</p>`;
  drawAllPreviews();
}
function drawStatsBars(bike){const st=effectiveStats(bike);return `<div class="bars">${[['Kecepatan',st.speed,9],['Akselerasi',st.accel,7.5],['Stabilitas',st.stability,100],['Rem',st.brake,6.5],['Suspensi',st.suspension,100]].map(([n,v,m])=>`<div class="barline"><span>${n}</span><div class="bar"><i style="width:${clamp(v/m*100,3,100)}%"></i></div><b>${Math.round(v)}</b></div>`).join('')}</div>`;}
function renderBikeCard(b,mode='collection'){
  const owned=save.ownedBikes.includes(b.id),selected=save.selectedBike===b.id;
  const btn=mode==='garage'?(owned?`<button class="${selected?'good':'primary'}" data-action="select-bike" data-id="${b.id}">${selected?'✓ DIPAKAI':'PILIH MOTOR'}</button>`:`<button class="primary" data-action="buy-bike" data-id="${b.id}">🪙 ${b.price}</button>`): (owned?`<button class="${selected?'good':'subtle'}" data-action="select-bike" data-id="${b.id}">${selected?'✓ AKTIF':'PAKAI'}</button>`:`<button class="primary" data-action="buy-bike" data-id="${b.id}">🪙 ${b.price}</button>`);
  return `<article class="bike-card ${selected?'selected':''}"><canvas class="bike-preview" data-preview="${b.id}" width="320" height="105"></canvas><div class="bike-title"><strong>${esc(b.name)}</strong><span class="tag">${esc(b.className)}</span></div><p>${owned?'Dimiliki':'Terkunci'} • Handling ${b.handling} • Bobot ${b.weight.toFixed(1)}</p>${drawStatsBars(b)}<div class="bike-actions">${btn}</div></article>`;
}
function renderGarage(){
  screen='garage';modal=null;const bike=currentBike(),paint=getPaint(),u=getUpgrades();
  app.innerHTML=`${topbar()}${pageTitle('GARASI','Pilih motor, ubah tampilan, dan tingkatkan performa.')}<div class="page-content"><div class="panel"><div class="split-heading"><div><h2 style="margin:0">${esc(bike.name)}</h2><p class="muted" style="margin:4px 0">${bike.className} • ID ${bike.id.toUpperCase()}</p></div><span class="pill">${save.ownedBikes.length}/70 dimiliki</span></div><canvas class="bike-preview" data-preview="${bike.id}" width="720" height="200" style="height:180px;margin-top:12px"></canvas><div class="two-col"><div><label class="field">Warna bodi<div class="swatches">${COLORS.map(c=>`<button aria-label="Warna bodi" class="swatch ${paint.body===c?'active':''}" style="background:${c}" data-action="paint" data-kind="body" data-value="${c}"></button>`).join('')}</div></label><label class="field">Warna pelek<div class="swatches">${RIMS.map(c=>`<button aria-label="Warna pelek" class="swatch ${paint.rim===c?'active':''}" style="background:${c}" data-action="paint" data-kind="rim" data-value="${c}"></button>`).join('')}</div></label></div><div><label class="field">Warna aksen<div class="swatches">${ACCENTS.map(c=>`<button aria-label="Warna aksen" class="swatch ${paint.accent===c?'active':''}" style="background:${c}" data-action="paint" data-kind="accent" data-value="${c}"></button>`).join('')}</div></label><label class="field">Nomor balap<input id="bike-number" type="number" min="0" max="99" value="${esc(paint.number)}" inputmode="numeric"></label></div></div><div class="field">Stiker geometris<select id="bike-sticker"><option value="stripe" ${paint.sticker==='stripe'?'selected':''}>Garis cepat</option><option value="block" ${paint.sticker==='block'?'selected':''}>Blok geometris</option><option value="bolt" ${paint.sticker==='bolt'?'selected':''}>Petir</option><option value="none" ${paint.sticker==='none'?'selected':''}>Tanpa stiker</option></select></div><button class="good" data-action="save-paint">SIMPAN TAMPILAN</button></div>
  <div class="section-head"><h2>Upgrade Performa</h2><span class="coin-pill">🪙 ${Math.floor(save.coins)}</span></div><div class="panel">${[['engine','Mesin','Akselerasi dan kecepatan maksimum'],['tires','Ban & Traksi','Cengkeraman saat berakselerasi'],['suspension','Suspensi','Redam guncangan lintasan'],['brakes','Rem','Perlambatan lebih kuat'],['stability','Stabilitas','Bantu menjaga sudut wheelie']].map(([key,name,desc])=>{const lv=u[key]||0;const cost=upgradeCost(lv);return `<div class="upgrade-row"><div><strong>${name} <span class="muted">Lv.${lv}/5</span></strong><p>${desc}</p><div class="progress"><i style="width:${lv*20}%"></i></div></div><button class="primary" data-action="upgrade" data-part="${key}" ${lv>=5?'disabled':''}>${lv>=5?'MAKS':`🪙 ${cost}`}</button></div>`}).join('')}</div>
  <div class="section-head"><h2>Pilih Motor</h2><button class="small subtle" data-action="nav" data-to="collection">Semua 70 motor →</button></div><div class="cards">${BIKES.filter(b=>save.ownedBikes.includes(b.id)).slice(0,6).map(b=>renderBikeCard(b,'garage')).join('')}</div></div>`;
  drawAllPreviews();
}
function upgradeCost(level){return 180+level*145;}
function renderMaps(){screen='maps';modal=null;app.innerHTML=`${topbar()}${pageTitle('PILIH MAP','Tujuh arena orisinal, masing-masing punya karakter lintasan.')}<div class="page-content"><div class="cards">${MAPS.map(m=>`<article class="map-card ${save.selectedMap===m.id?'selected':''}"><div class="map-art" style="--mapbg:linear-gradient(160deg,${m.bg1},${m.bg2})"><span style="left:12%">${m.emoji}</span><span style="right:12%;bottom:46px;font-size:1.7rem;opacity:.75">${m.id==='city'?'🏢':m.id==='desert'?'🪨':m.id==='forest'?'🌳':m.id==='mountain'?'🗻':m.id==='night'?'✨':m.id==='industrial'?'📦':'🚩'}</span></div><div class="bike-title"><strong>${m.name}</strong><span class="tag">Kesulitan ${'★'.repeat(Math.round(m.diff))}</span></div><p>${m.desc}</p><div class="bike-actions"><button class="${save.selectedMap===m.id?'good':'primary'}" data-action="select-map" data-id="${m.id}">${save.selectedMap===m.id?'✓ MAP AKTIF':'PILIH MAP'}</button></div></article>`).join('')}</div></div>`;}
function renderCollection(){screen='collection';modal=null;const shown=BIKES.filter(b=>(collectionFilter==='Semua'||b.className===collectionFilter)&&b.name.toLowerCase().includes(collectionSearch.toLowerCase()));app.innerHTML=`${topbar()}${pageTitle('KOLEKSI MOTOR','Tepat 70 motor fiktif dari 7 kelas. Setiap motor punya statistik berbeda.')}<div class="page-content"><div class="toolbar"><input id="bike-search" placeholder="Cari nama motor..." value="${esc(collectionSearch)}"><select id="class-filter">${['Semua',...CLASSES.map(c=>c.name)].map(c=>`<option ${collectionFilter===c?'selected':''}>${c}</option>`).join('')}</select><span class="pill">${save.ownedBikes.length}/70 dimiliki</span></div><div class="cards">${shown.map(b=>renderBikeCard(b)).join('')||'<div class="empty">Motor tidak ditemukan.</div>'}</div><p class="footer-note">Motor yang dibeli tersimpan permanen pada perangkat ini. Harga memakai koin dalam game.</p></div>`;drawAllPreviews();}
function missionProgress(m){switch(m.stat){case'runs':return save.runs;case'runDistance':return save.lastRunDistance||0;case'runWheelie':return save.lastRunWheelie||0;case'cityRuns':return save.mapVisits.city||0;case'mapCount':return Object.values(save.mapVisits).filter(v=>v>0).length;case'bikeCount':return save.ownedBikes.length;case'upgradeCount':return Object.values(save.upgrades).reduce((a,u)=>a+Object.values(u||{}).reduce((x,y)=>x+(Number(y)||0),0),0);case'totalDistance':return save.totalDistance;case'totalCoinsEarned':return save.totalCoinsEarned;case'classCount':return new Set(save.classUsed).size;default:return 0;}}
function renderMissions(){screen='missions';modal=null;app.innerHTML=`${topbar()}${pageTitle('MISI','Selesaikan target untuk mendapatkan koin bonus.')}<div class="page-content"><div class="panel" style="margin-bottom:12px"><strong>Tips:</strong><span class="muted"> Hadiah tiap misi hanya bisa diklaim satu kali. Misi perjalanan diperbarui saat run selesai.</span></div><div style="display:grid;gap:9px">${MISSIONS.map(m=>{const p=missionProgress(m),done=p>=m.goal,claimed=save.missionsClaimed.includes(m.id);return `<article class="mission-card"><div class="mission-icon">${m.emoji}</div><div class="mission-body"><div class="split-heading"><strong>${m.name}</strong><span class="tag">🪙 ${m.reward}</span></div><p>${m.desc}</p><div class="progress"><i style="width:${clamp(p/m.goal*100,0,100)}%"></i></div><small class="muted">${typeof p==='number'?round(p,1):p} / ${m.goal} ${claimed?'• Selesai diklaim':''}</small></div><button class="${done&&!claimed?'primary':'subtle'} small" data-action="claim-mission" data-id="${m.id}" ${!done||claimed?'disabled':''}>${claimed?'✓':'KLAIM'}</button></article>`}).join('')}</div></div>`;}
function renderSettings(){screen='settings';modal=null;app.innerHTML=`${topbar()}${pageTitle('PENGATURAN','Pengaturan lokal game dan data tersimpan.')}<div class="page-content"><div class="panel"><div class="setting-row"><div><strong>Suara</strong><small>Efek sederhana dari audio perangkat.</small></div><button data-action="toggle-mute" class="${save.settings.mute?'subtle':'good'}">${save.settings.mute?'🔇 MATI':'🔊 AKTIF'}</button></div><div class="setting-row"><div><strong>Kualitas visual</strong><small>Rendah lebih ringan untuk HP lama.</small></div><select id="quality-select"><option value="low" ${save.settings.quality==='low'?'selected':''}>Rendah</option><option value="normal" ${save.settings.quality==='normal'?'selected':''}>Normal</option><option value="high" ${save.settings.quality==='high'?'selected':''}>Tinggi</option></select></div><div class="setting-row"><div><strong>Getaran</strong><small>Getaran singkat saat jatuh (jika didukung).</small></div><button data-action="toggle-vibration" class="${save.settings.vibration?'good':'subtle'}">${save.settings.vibration?'AKTIF':'MATI'}</button></div></div><div class="section-head"><h2>Data Game</h2></div><div class="panel"><p class="muted">Reset akan menghapus koin, motor yang dibeli, upgrade, rekor, dan progres misi di perangkat ini.</p><button class="danger" data-action="confirm-reset">RESET SEMUA DATA</button></div><p class="footer-note">Game tidak mengirim data ke server. Seluruh penyimpanan dilakukan melalui localStorage browser.</p></div>`;}
function renderProfile(){screen='profile';modal=null;const level=1+Math.floor(save.totalDistance/250),next=250-(save.totalDistance%250);app.innerHTML=`${topbar()}${pageTitle('PROFIL PEMAIN','Ringkasan perjalanan pada perangkat ini.')}<div class="page-content"><div class="hero" style="min-height:160px"><h1 style="font-size:2.4rem">RIDER <em>LV.${level}</em></h1><p>Pengendara lokal • tidak membutuhkan akun atau internet.</p></div><div class="stats-grid">${statBox(save.runs,'RUN SELESAI')}${statBox(`${Math.floor(save.totalDistance)} m`,'TOTAL JARAK')}${statBox(`${Math.floor(save.totalWheelieTime)} dtk`,'WAKTU WHEELIE')}${statBox(`${Math.floor(save.highScore)} m`,'REKOR RUN')}${statBox(save.ownedBikes.length,'MOTOR DIMILIKI')}${statBox(Math.floor(save.totalCoinsEarned),'KOIN DIDAPAT')}</div><div class="panel"><strong>Level berikutnya</strong><p class="muted">Butuh ${Math.ceil(next)} meter jarak total lagi.</p><div class="progress"><i style="width:${save.totalDistance%250/250*100}%"></i></div><button class="primary" data-action="play">▶ LANJUT BERKENDARA</button></div></div>`;}
function renderPage(to){switch(to){case'garage':renderGarage();break;case'maps':renderMaps();break;case'collection':renderCollection();break;case'missions':renderMissions();break;case'settings':renderSettings();break;case'profile':renderProfile();break;default:renderHome();}}

function drawBike(ctx,x,y,angle,bike,scale=1,paint=getPaint(bike.id),small=false){
  const w=bike.wheelbase*scale, r=bike.wheelRadius*scale;
  ctx.save();ctx.translate(x,y);ctx.rotate(-angle);ctx.scale(scale,scale);
  const body=paint.body||bike.color,rim=paint.rim||bike.rim,accent=paint.accent||bike.accent;
  // wheel shadows, tires, hubs and spokes
  for(const wx of [0,bike.wheelbase]){
    ctx.beginPath();ctx.ellipse(wx,2,r*1.15,r*.38,0,0,Math.PI*2);ctx.fillStyle='#0005';ctx.fill();
    ctx.beginPath();ctx.arc(wx,0,r,0,Math.PI*2);ctx.fillStyle='#15191e';ctx.fill();
    ctx.beginPath();ctx.arc(wx,0,r*.72,0,Math.PI*2);ctx.fillStyle=rim;ctx.fill();
    ctx.beginPath();ctx.arc(wx,0,r*.55,0,Math.PI*2);ctx.fillStyle='#313c48';ctx.fill();
    ctx.strokeStyle='#d7dce355';ctx.lineWidth=1.1;for(let i=0;i<8;i++){const a=i*Math.PI/4;ctx.beginPath();ctx.moveTo(wx,0);ctx.lineTo(wx+Math.cos(a)*r*.63,Math.sin(a)*r*.63);ctx.stroke();}
    ctx.beginPath();ctx.arc(wx,0,r*.17,0,Math.PI*2);ctx.fillStyle='#e1e6eb';ctx.fill();
  }
  const v=bike.visualVariant, L=bike.wheelbase, seatY=-bike.seatHeight;
  ctx.lineCap='round';ctx.lineJoin='round';
  // frame / swing arm
  ctx.strokeStyle='#b9c4ce';ctx.lineWidth=3.2;ctx.beginPath();ctx.moveTo(5,-4);ctx.lineTo(L*.48,-bike.seatHeight*.28);ctx.lineTo(L*.82,-7);ctx.moveTo(L*.48,-bike.seatHeight*.28);ctx.lineTo(L*.66,-bike.seatHeight*.62);ctx.stroke();
  // forks
  ctx.strokeStyle='#dbe2e9';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(L*.82,-7);ctx.lineTo(L*.98,-r*.68);ctx.stroke();
  // class-specific body silhouette
  ctx.fillStyle=body;ctx.strokeStyle='#111a24';ctx.lineWidth=1.6;
  ctx.beginPath();
  switch(bike.kind){
    case'underbone':ctx.moveTo(L*.13,-r*.45);ctx.lineTo(L*.25,-bike.seatHeight*.7);ctx.lineTo(L*.57,-bike.seatHeight*.72);ctx.lineTo(L*.67,-bike.seatHeight*.33);ctx.lineTo(L*.48,-bike.seatHeight*.18);ctx.lineTo(L*.27,-r*.3);break;
    case'scooter':ctx.moveTo(L*.13,-r*.45);ctx.lineTo(L*.22,-bike.seatHeight*.98);ctx.quadraticCurveTo(L*.44,-bike.seatHeight*1.1,L*.62,-bike.seatHeight*.74);ctx.lineTo(L*.72,-bike.seatHeight*.24);ctx.lineTo(L*.43,-bike.seatHeight*.18);ctx.lineTo(L*.28,-r*.3);break;
    case'sport':ctx.moveTo(L*.12,-r*.5);ctx.lineTo(L*.27,-bike.seatHeight*.5);ctx.lineTo(L*.45,-bike.seatHeight*.9);ctx.lineTo(L*.79,-bike.seatHeight*.54);ctx.lineTo(L*.9,-bike.seatHeight*.25);ctx.lineTo(L*.61,-bike.seatHeight*.2);ctx.lineTo(L*.4,-r*.35);break;
    case'naked':ctx.moveTo(L*.14,-r*.4);ctx.lineTo(L*.25,-bike.seatHeight*.72);ctx.lineTo(L*.48,-bike.seatHeight*.83);ctx.lineTo(L*.68,-bike.seatHeight*.5);ctx.lineTo(L*.79,-bike.seatHeight*.28);ctx.lineTo(L*.5,-bike.seatHeight*.16);ctx.lineTo(L*.31,-r*.3);break;
    case'trail':ctx.moveTo(L*.12,-r*.46);ctx.lineTo(L*.3,-bike.seatHeight*1.12);ctx.lineTo(L*.55,-bike.seatHeight*.94);ctx.lineTo(L*.74,-bike.seatHeight*.4);ctx.lineTo(L*.65,-bike.seatHeight*.18);ctx.lineTo(L*.38,-bike.seatHeight*.2);break;
    case'classic':ctx.moveTo(L*.1,-r*.5);ctx.lineTo(L*.26,-bike.seatHeight*.73);ctx.quadraticCurveTo(L*.5,-bike.seatHeight*1.02,L*.7,-bike.seatHeight*.62);ctx.lineTo(L*.77,-bike.seatHeight*.2);ctx.lineTo(L*.48,-bike.seatHeight*.18);ctx.lineTo(L*.29,-r*.3);break;
    default:ctx.moveTo(L*.12,-r*.5);ctx.lineTo(L*.26,-bike.seatHeight*.62);ctx.lineTo(L*.46,-bike.seatHeight*.98);ctx.lineTo(L*.75,-bike.seatHeight*.65);ctx.lineTo(L*.92,-bike.seatHeight*.23);ctx.lineTo(L*.55,-bike.seatHeight*.18);ctx.closePath();break;
  }
  ctx.closePath();ctx.fill();ctx.stroke();
  // decals
  if(paint.sticker!=='none'){
    ctx.fillStyle=accent;
    if(paint.sticker==='stripe'){ctx.beginPath();ctx.moveTo(L*.28,-bike.seatHeight*.59);ctx.lineTo(L*.6,-bike.seatHeight*.53);ctx.lineTo(L*.71,-bike.seatHeight*.42);ctx.lineTo(L*.4,-bike.seatHeight*.47);ctx.closePath();ctx.fill();}
    else if(paint.sticker==='block'){ctx.fillRect(L*.42,-bike.seatHeight*.67,L*.12,4);ctx.fillRect(L*.57,-bike.seatHeight*.55,L*.11,3);}
    else {ctx.beginPath();ctx.moveTo(L*.45,-bike.seatHeight*.75);ctx.lineTo(L*.58,-bike.seatHeight*.58);ctx.lineTo(L*.52,-bike.seatHeight*.58);ctx.lineTo(L*.63,-bike.seatHeight*.38);ctx.lineTo(L*.42,-bike.seatHeight*.57);ctx.lineTo(L*.49,-bike.seatHeight*.57);ctx.closePath();ctx.fill();}
  }
  // tank / seat / engine, all silhouettes visibly varied
  ctx.fillStyle=body;
  ctx.beginPath();ctx.moveTo(L*.32,-bike.seatHeight*.68);ctx.quadraticCurveTo(L*.43,-bike.seatHeight*(.88+(v%2)*.1),L*.57,-bike.seatHeight*.67);ctx.lineTo(L*.62,-bike.seatHeight*.43);ctx.lineTo(L*.4,-bike.seatHeight*.4);ctx.closePath();ctx.fill();
  ctx.fillStyle='#17202a';ctx.beginPath();ctx.moveTo(L*.22,seatY+2);ctx.lineTo(L*.48,seatY-2);ctx.lineTo(L*.58,seatY+2);ctx.lineTo(L*.3,seatY+5);ctx.closePath();ctx.fill();
  ctx.fillStyle='#8d9ca9';ctx.beginPath();ctx.roundRect(L*.39,-r*.32,L*.21,r*.7,3);ctx.fill();
  // handlebar and lamp
  ctx.strokeStyle='#e2e8ed';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(L*.76,-bike.seatHeight*.48);ctx.lineTo(L*.87,-bike.seatHeight*.68);ctx.lineTo(L*.98,-bike.seatHeight*.66);ctx.stroke();
  ctx.fillStyle=bike.kind==='future'?accent:'#f7e7a4';ctx.beginPath();ctx.ellipse(L*.96,-bike.seatHeight*.32,3.8,3,0,0,Math.PI*2);ctx.fill();
  // exhaust
  ctx.strokeStyle='#a8b4bf';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(L*.25,-r*.15);ctx.lineTo(L*.46,-r*.05);ctx.lineTo(L*.55,-r*.05);ctx.stroke();
  // race number
  if(paint.number!=='') {ctx.fillStyle='#fff';ctx.font='bold 7px system-ui';ctx.textAlign='center';ctx.fillText(String(paint.number).slice(0,2),L*.53,-bike.seatHeight*.52);}
  ctx.restore();
}
function drawAllPreviews(){document.querySelectorAll('canvas[data-preview]').forEach(c=>{const b=bikeById(c.dataset.preview),ctx=c.getContext('2d');if(!ctx)return;const w=c.width,h=c.height;ctx.clearRect(0,0,w,h);const gr=ctx.createLinearGradient(0,0,0,h);gr.addColorStop(0,'#2a4152');gr.addColorStop(1,'#111923');ctx.fillStyle=gr;ctx.fillRect(0,0,w,h);ctx.fillStyle='#10151d';ctx.fillRect(0,h*.78,w,h*.22);ctx.strokeStyle='#f1c750';ctx.lineWidth=2;ctx.setLineDash([10,8]);ctx.beginPath();ctx.moveTo(0,h*.88);ctx.lineTo(w,h*.88);ctx.stroke();ctx.setLineDash([]);const sc=Math.min(w/(b.wheelbase+60),h/120);drawBike(ctx,(w-b.wheelbase*sc)/2-5,h*.76,0,b,sc,getPaint(b.id),true);});}

function playGame(){
  requestLandscape();
  beep(600,.08);screen='game';modal=null;const bike=currentBike(),st=effectiveStats(bike),map=mapById(save.selectedMap);
  game={bikeId:bike.id,mapId:map.id,stats:st,x:0,startX:0,vx:0,angle:0,angVel:0,crashTimer:0,frontCrashTimer:0,elapsed:0,wheelie:0,bestWheelie:0,score:0,paused:false,done:false,rewarded:false,controls:{gas:false,brake:false,back:false,forward:false},lastResult:null,shake:0};
  renderGameShell(); resizeGameCanvas();lastFrame=performance.now();cancelAnimationFrame(raf);raf=requestAnimationFrame(gameFrame);
}
function renderGameShell(){
 const b=currentBike(),m=mapById(save.selectedMap);
 app.innerHTML=`<section class="game-shell"><div class="game-top"><button class="small subtle" data-action="game-menu">← MENU</button><div class="hud"><span>📍 <b id="hud-distance">0</b> m</span><span>🛞 <b id="hud-wheelie">0.0</b>s</span><span>🏁 <b id="hud-score">0</b></span></div><button class="small subtle" data-action="pause">Ⅱ</button></div><div class="game-canvas-wrap"><canvas id="game-canvas" class="game-canvas"></canvas><div class="overlay-hint" id="game-hint">${esc(m.name)} • GAS + TARIK UNTUK WHEELIE</div></div><div class="game-bottom"><div class="control-stack"><button class="control lean" data-control="back"><strong>↶ TARIK</strong><span>LEAN BACK</span></button><button class="control lean" data-control="forward"><strong>↷ DORONG</strong><span>LEAN FORWARD</span></button></div><div class="game-mid"><button class="subtle" data-action="pause">Ⅱ PAUSE</button><button class="subtle" data-action="restart">↻ ULANG</button></div><div class="control-stack"><button class="control gas" data-control="gas"><strong>▲ GAS</strong><span>AKSELERASI</span></button><button class="control rem" data-control="brake"><strong>▼ REM</strong><span>PERLAMBAT</span></button></div></div></section>`;
 bindGameControls();
}
function resizeGameCanvas(){const c=$('#game-canvas');if(!c)return;const r=c.getBoundingClientRect();const quality=save.settings.quality;const dpr=Math.min(window.devicePixelRatio||1,quality==='low'?1:quality==='normal'?1.5:2);c.width=Math.max(1,Math.floor(r.width*dpr));c.height=Math.max(1,Math.floor(r.height*dpr));const ctx=c.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);game.canvas={c,ctx,w:r.width,h:r.height,dpr};}
function bindGameControls(){document.querySelectorAll('[data-control]').forEach(el=>{const key=el.dataset.control;const start=e=>{e.preventDefault();if(!game||game.paused||game.done)return;game.controls[key]=true;el.classList.add('active');try{el.setPointerCapture(e.pointerId);}catch(err){}};const end=e=>{e.preventDefault();if(game)game.controls[key]=false;el.classList.remove('active');};el.addEventListener('pointerdown',start);el.addEventListener('pointerup',end);el.addEventListener('pointercancel',end);el.addEventListener('lostpointercapture',end);});}
function gameGroundY(worldX){const map=mapById(game?.mapId||save.selectedMap),h=game?.canvas?.h||320;const amp=map.amp*(save.settings.quality==='low'?.72:1);const x=worldX;return h*.69+Math.sin(x*map.freq)*amp+Math.sin(x*map.freq*.43+1.7)*amp*.46+Math.sin(x*map.freq*1.97)*amp*.17;}
function gameFrame(now){raf=requestAnimationFrame(gameFrame);if(screen!=='game'||!game)return;const dt=clamp((now-lastFrame)/1000,0,.04);lastFrame=now;if(!game.paused&&!game.done)updatePhysics(dt);renderWorld();updateHud();}
function updatePhysics(dt){
 const g=game,st=g.stats,ctrl=g.controls,map=mapById(g.mapId);g.elapsed+=dt;
 const accel=st.accel*11;if(ctrl.gas)g.vx+=accel*dt;else g.vx-=Math.max(2,g.vx*.05)*dt;
 if(ctrl.brake)g.vx-=st.brake*18*dt;g.vx=clamp(g.vx,0,st.speed*25);g.x+=g.vx*dt;
 const slope=gameGroundY(g.x+22)-gameGroundY(g.x-22);
 const controlMoment=(ctrl.back?3.35:0)-(ctrl.forward?4.1:0);
 const throttleMoment=ctrl.gas?.5:0;
 const balance=-g.angle*(1.15+st.stability*.009)-g.angVel*2.15;
 const slopeMoment=clamp(slope*.045,-.5,.5);
 g.angVel+= (controlMoment+throttleMoment+balance+slopeMoment)*dt;
 g.angle+=g.angVel*dt;
 // Stability and braking affect the handling feel, but the player remains in control.
 const rearGround=gameGroundY(g.x),wheelR=g.bikeId?bikeById(g.bikeId).wheelRadius:21;
 const wb=bikeById(g.bikeId).wheelbase,frontX=g.x+wb,frontGround=gameGroundY(frontX);
 const rearY=rearGround-wheelR,frontY=rearY-Math.sin(g.angle)*wb;
 const frontLift=frontGround-(frontY+wheelR);
 const isWheelie=g.angle>.13&&frontLift>5&&g.vx>30;
 if(isWheelie){g.wheelie+=dt;g.bestWheelie=Math.max(g.bestWheelie,g.wheelie);g.score+=dt*(8+g.vx*.035);}else g.wheelie=Math.max(0,g.wheelie-dt*.7);
 if(g.angle>1.03){g.crashTimer+=dt;}else g.crashTimer=Math.max(0,g.crashTimer-dt*2.0);
 if(g.angle<-.43){g.frontCrashTimer+=dt;}else g.frontCrashTimer=Math.max(0,g.frontCrashTimer-dt*1.6);
 if(g.crashTimer>.25||g.frontCrashTimer>.35||(!ctrl.gas&&!ctrl.brake&&g.vx<5&&g.elapsed>4)){finishRun(g.crashTimer>.25?'Motor terangkat terlalu tinggi.':g.frontCrashTimer>.35?'Bagian depan menyentuh lintasan.':'Kehilangan momentum.');return;}
 g.distance=(g.x-g.startX)/10;g.score+=dt*g.vx*.018;
}
function drawBackground(ctx,w,h,cam,map){
 const grad=ctx.createLinearGradient(0,0,0,h);grad.addColorStop(0,map.bg1);grad.addColorStop(1,map.bg2);ctx.fillStyle=grad;ctx.fillRect(0,0,w,h);
 if(map.id==='night'){ctx.fillStyle='#fff9c9';for(let i=0;i<55;i++){const x=((i*71-cam*.06)%(w+30)+w+30)%(w+30),y=(i*37)%Math.max(45,h*.52);ctx.globalAlpha=.35+(i%4)*.15;ctx.fillRect(x,y,1.4,1.4);}ctx.globalAlpha=1;ctx.beginPath();ctx.arc(w*.78,h*.19,Math.min(22,h*.08),0,Math.PI*2);ctx.fillStyle='#edf0cc';ctx.fill();ctx.beginPath();ctx.arc(w*.80,h*.16,Math.min(20,h*.075),0,Math.PI*2);ctx.fillStyle=map.bg1;ctx.fill();}
 if(map.id==='city'||map.id==='night'){
  for(let i=0;i<14;i++){const bw=25+(i*17)%44,bh=h*(.15+((i*13)%31)/100),x=((i*81-cam*.18)%(w+90)+w+90)%(w+90)-30;ctx.fillStyle=map.id==='night'?'#18264b':'#7896a5';ctx.globalAlpha=map.id==='night'?.95:.75;ctx.fillRect(x,h*.6-bh,bw,bh);if(map.id==='night'){ctx.fillStyle='#f7d878';for(let yy=h*.6-bh+8;yy<h*.6-5;yy+=12)for(let xx=x+5;xx<x+bw-5;xx+=11)if((Math.floor(xx+yy+i)%3)!==0)ctx.fillRect(xx,yy,3,4);}else{ctx.fillStyle='#d5e0df';for(let yy=h*.6-bh+6;yy<h*.6-5;yy+=10)for(let xx=x+5;xx<x+bw-4;xx+=10)ctx.fillRect(xx,yy,4,5);}}
  ctx.globalAlpha=1;
 } else if(map.id==='desert'){
  for(let i=0;i<5;i++){ctx.beginPath();const y=h*(.46+i*.055),shift=((i*90-cam*.12)%(w+120)+w+120)%(w+120)-60;ctx.moveTo(shift,y);ctx.quadraticCurveTo(shift+w*.3,y-35-i*5,shift+w*.57,y+7);ctx.quadraticCurveTo(shift+w*.82,y+32,shift+w+160,y-5);ctx.lineTo(shift+w+160,h);ctx.lineTo(shift,h);ctx.closePath();ctx.fillStyle=i%2?'#d69b60':'#e5b878';ctx.globalAlpha=.55;ctx.fill();}ctx.globalAlpha=1;
 } else if(map.id==='forest'){
  for(let i=0;i<18;i++){const x=((i*65-cam*.15)%(w+70)+w+70)%(w+70)-30,y=h*.55-(i%4)*8;ctx.fillStyle='#526f4e';ctx.fillRect(x+10,y,5,24);ctx.fillStyle=i%2?'#4e8d68':'#6ba27a';ctx.beginPath();ctx.moveTo(x-8,y+7);ctx.lineTo(x+12,y-30-(i%3)*5);ctx.lineTo(x+31,y+7);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(x-5,y-3);ctx.lineTo(x+12,y-24);ctx.lineTo(x+28,y-3);ctx.closePath();ctx.fill();}
 } else if(map.id==='mountain'){
  for(let i=0;i<7;i++){const x=((i*130-cam*.1)%(w+200)+w+200)%(w+200)-100,y=h*.58;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+65,y-h*(.24+(i%3)*.06));ctx.lineTo(x+138,y);ctx.closePath();ctx.fillStyle=i%2?'#8397a5':'#a0b1bd';ctx.fill();ctx.fillStyle='#e1e5e7';ctx.beginPath();ctx.moveTo(x+47,y-h*.22);ctx.lineTo(x+65,y-h*(.24+(i%3)*.06));ctx.lineTo(x+84,y-h*.2);ctx.closePath();ctx.fill();}
 } else if(map.id==='industrial'){
  for(let i=0;i<9;i++){const x=((i*100-cam*.16)%(w+110)+w+110)%(w+110)-40,y=h*.48,bw=55+(i%3)*13,bh=30+(i%4)*9;ctx.fillStyle=i%2?'#7c8c91':'#9fa8a5';ctx.fillRect(x,y-bh,bw,bh);ctx.fillStyle='#4e6068';ctx.fillRect(x+6,y-bh+8,bw-12,bh-12);ctx.strokeStyle='#c0c4b9';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x+bw*.5,y-bh);ctx.lineTo(x+bw*.5,y);ctx.stroke();}
 } else if(map.id==='extreme'){
  for(let i=0;i<8;i++){const x=((i*120-cam*.12)%(w+140)+w+140)%(w+140)-30,y=h*.58;ctx.fillStyle=i%2?'#745d66':'#92717b';ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+25,y-18-(i%3)*10);ctx.lineTo(x+60,y);ctx.closePath();ctx.fill();ctx.fillStyle='#f6e4a7';ctx.fillRect(x+26,y-14,5,4);}
 }
}
function renderWorld(){
 const g=game;if(!g?.canvas)return;const {ctx,w,h}=g.canvas;ctx.clearRect(0,0,w,h);const map=mapById(g.mapId);const cam=g.x-w*.22;drawBackground(ctx,w,h,cam,map);
 // Track profile
 ctx.beginPath();ctx.moveTo(0,h);const step=8;for(let sx=0;sx<=w+step;sx+=step){const gy=gameGroundY(cam+sx);ctx.lineTo(sx,gy);}ctx.lineTo(w,h);ctx.closePath();ctx.fillStyle=map.ground;ctx.fill();
 ctx.beginPath();for(let sx=0;sx<=w+step;sx+=step){const gy=gameGroundY(cam+sx);if(sx===0)ctx.moveTo(sx,gy);else ctx.lineTo(sx,gy);}ctx.strokeStyle=map.accent;ctx.lineWidth=3;ctx.stroke();
 // road markings and decorative roadside features
 for(let wx=Math.floor(cam/130)*130;wx<cam+w+150;wx+=130){const sx=wx-cam,gy=gameGroundY(wx);if(map.id==='city'||map.id==='night'){ctx.fillStyle=map.id==='night'?'#6be7ff':'#29323a';ctx.fillRect(sx,gy-42,4,42);ctx.beginPath();ctx.moveTo(sx+2,gy-42);ctx.lineTo(sx+22,gy-38);ctx.strokeStyle=map.accent;ctx.lineWidth=3;ctx.stroke();}else if(map.id==='desert'){ctx.fillStyle='#3f8550';ctx.fillRect(sx,gy-18,5,20);ctx.fillRect(sx-5,gy-12,6,3);ctx.fillRect(sx+4,gy-8,6,3);}else if(map.id==='forest'){ctx.fillStyle='#5b4435';ctx.fillRect(sx,gy-28,5,30);ctx.fillStyle='#2b6d49';ctx.beginPath();ctx.arc(sx+2,gy-31,14,0,Math.PI*2);ctx.fill();}else if(map.id==='industrial'){ctx.fillStyle='#bd6f32';ctx.fillRect(sx,gy-20,22,19);ctx.strokeStyle='#eab95c';ctx.strokeRect(sx,gy-20,22,19);}else if(map.id==='extreme'){ctx.fillStyle='#ffcf54';ctx.fillRect(sx,gy-33,3,33);ctx.fillStyle='#e9574e';ctx.fillRect(sx+3,gy-31,15,10);}else if(map.id==='mountain'){ctx.fillStyle='#8d989d';ctx.beginPath();ctx.moveTo(sx,gy);ctx.lineTo(sx+12,gy-13);ctx.lineTo(sx+25,gy);ctx.fill();}}
 // Main bike follows rear wheel contact; camera makes it remain left of center.
 const bike=bikeById(g.bikeId),paint=getPaint(g.bikeId),r=bike.wheelRadius;
 const bx=Math.min(w*.28,g.x-cam),by=gameGroundY(g.x)-r;
 ctx.save();ctx.translate(0,0);drawBike(ctx,bx,by,g.angle,bike,1,paint);ctx.restore();
 // Light speed lines at high speed
 if(g.vx>120){ctx.strokeStyle='#ffffff33';ctx.lineWidth=1;for(let i=0;i<5;i++){const yy=h*.42+i*12;ctx.beginPath();ctx.moveTo(8,yy);ctx.lineTo(8+(g.vx-120)*.12,yy);ctx.stroke();}}
 if(g.paused||g.done){ctx.fillStyle='#07101b77';ctx.fillRect(0,0,w,h);}
}
function updateHud(){if(!game)return;const d=Math.floor(game.distance||0);const a=$('#hud-distance'),b=$('#hud-wheelie'),c=$('#hud-score');if(a)a.textContent=d;if(b)b.textContent=(game.wheelie||0).toFixed(1);if(c)c.textContent=Math.floor(game.score||0);const hint=$('#game-hint');if(hint&&game.elapsed>5)hint.textContent=game.vx<15?'TAP GAS UNTUK MELAJU':'JAGA SUDUT • TARIK / DORONG';}
function finishRun(reason){
 const g=game;if(!g||g.rewarded)return;g.done=true;g.rewarded=true;g.controls={gas:false,brake:false,back:false,forward:false};
 const distance=Math.max(0,Math.floor((g.x-g.startX)/10)),wheelie=round(g.bestWheelie,1),score=Math.floor(g.score+distance*1.7+wheelie*10);
 const coins=Math.max(5,Math.floor(distance*.23+wheelie*7+score*.025));
 save.coins+=coins;save.totalCoinsEarned+=coins;save.totalDistance+=distance;save.totalWheelieTime+=wheelie;save.lastRunDistance=distance;save.lastRunWheelie=wheelie;save.runs++;save.highScore=Math.max(save.highScore,distance);save.mapVisits[g.mapId]=(save.mapVisits[g.mapId]||0)+1;
 const cls=bikeById(g.bikeId).className;if(!save.classUsed.includes(cls))save.classUsed.push(cls);
 g.lastResult={distance,wheelie,score,coins,reason};saveGame();beep(180,.18,'triangle');if(save.settings.vibration&&navigator.vibrate)navigator.vibrate([80,40,100]);showGameModal('result',g.lastResult);
}
function showGameModal(type,result){
 let html='';if(type==='pause'){html=`<div class="modal-backdrop"><div class="modal"><h2>⏸️ Dijeda</h2><p>Permainan sedang dijeda. Siap lanjut menjaga keseimbangan?</p><div class="modal-actions"><button class="primary" data-action="resume">▶ LANJUT</button><button data-action="restart">↻ ULANG</button><button class="subtle" data-action="game-menu">MENU UTAMA</button></div></div></div>`;}
 else if(type==='result'){html=`<div class="modal-backdrop"><div class="modal"><div class="muted">PERJALANAN SELESAI</div><h2>💥 Coba lagi, Rider!</h2><p>${esc(result.reason||'Roda kehilangan keseimbangan.')}</p><div class="stats-grid" style="grid-template-columns:repeat(2,minmax(0,1fr))">${statBox(`${result.distance} m`,'JARAK')}${statBox(`${result.wheelie} dtk`,'DURASI WHEELIE')}${statBox(result.score,'SKOR')}${statBox(`+${result.coins} 🪙`,'KOIN DIDAPAT')}</div><div class="modal-actions"><button class="primary" data-action="restart">↻ COBA LAGI</button><button data-action="game-menu">MENU UTAMA</button><button class="subtle" data-action="nav-missions">LIHAT MISI</button></div></div></div>`;}
 const old=$('.modal-backdrop');if(old)old.remove();$('.game-shell')?.insertAdjacentHTML('beforeend',html);
}
function openModal(title,body,actions){modal={title,body,actions};const existing=$('.modal-backdrop');if(existing)existing.remove();app.insertAdjacentHTML('beforeend',`<div class="modal-backdrop"><div class="modal"><h2>${title}</h2>${body}<div class="modal-actions">${actions}</div></div></div>`);}
function closeModal(){modal=null;$('.modal-backdrop')?.remove();}
function claimDaily(){const today=new Date();const date=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;if(save.dailyClaimDate===date){openModal('Bonus Harian',`<p>Bonus hari ini sudah diambil. Coba kembali besok!</p>`,`<button class="primary" data-action="close-modal">OKE</button>`);return;}save.dailyClaimDate=date;save.coins+=150;save.totalCoinsEarned+=150;saveGame();beep(740,.1);renderHome();openModal('Bonus Harian',`<p>🎁 Kamu mendapatkan <strong class="accent">150 koin</strong> untuk hari ini.</p>`,`<button class="primary" data-action="close-modal">MANTAP</button>`);}
function doBuyBike(id){const b=bikeById(id);if(save.ownedBikes.includes(id)){save.selectedBike=id;selectedBikeId=id;saveGame();beep(550,.05);renderPage(screen==='garage'?'garage':'collection');return;}if(save.coins<b.price){openModal('Koin Belum Cukup',`<p>${esc(b.name)} berharga ${b.price} koin, sedangkan kamu punya ${Math.floor(save.coins)} koin.</p>`,`<button class="primary" data-action="close-modal">MENGERTI</button>`);return;}save.coins-=b.price;save.ownedBikes.push(id);save.selectedBike=id;selectedBikeId=id;saveGame();beep(680,.09);renderPage(screen==='garage'?'garage':'collection');}
function savePaint(){const id=save.selectedBike;save.paint[id]={...getPaint(id),number:String(clamp(Number($('#bike-number')?.value||0),0,99)),sticker:$('#bike-sticker')?.value||'stripe'};saveGame();beep(580,.06);renderGarage();}
function applyUpgrade(part){const id=save.selectedBike,u=getUpgrades(id),lv=u[part]||0,cost=upgradeCost(lv);if(lv>=5)return;if(save.coins<cost){openModal('Koin Belum Cukup',`<p>Upgrade ini membutuhkan ${cost} koin. Kumpulkan koin dengan berkendara atau menyelesaikan misi.</p>`,`<button class="primary" data-action="close-modal">OKE</button>`);return;}save.coins-=cost;save.upgrades[id]={...u,[part]:lv+1};saveGame();beep(640,.08);renderGarage();}
function claimMission(id){const m=MISSIONS.find(x=>x.id===id);if(!m||save.missionsClaimed.includes(id)||missionProgress(m)<m.goal)return;save.missionsClaimed.push(id);save.coins+=m.reward;save.totalCoinsEarned+=m.reward;saveGame();beep(800,.1);renderMissions();}
function confirmReset(){openModal('Reset Semua Data?',`<p>Semua progres lokal akan dihapus dan tidak bisa dikembalikan. Yakin ingin mulai dari awal?</p>`,`<button class="danger" data-action="reset-data">YA, RESET</button><button class="subtle" data-action="close-modal">BATAL</button>`);}
function resetData(){try{localStorage.removeItem('wheelieRider2DSave');}catch(e){}save=clone(DEFAULT_SAVE);saveGame();closeModal();renderHome();}
function nav(to){if(screen==='game'){cancelAnimationFrame(raf);game=null;}renderPage(to);}

app.addEventListener('click',e=>{
 const btn=e.target.closest('[data-action]');if(!btn)return;const a=btn.dataset.action;
 switch(a){
  case'play':playGame();break;
  case'nav':nav(btn.dataset.to);break;
  case'select-bike':doBuyBike(btn.dataset.id);break;
  case'buy-bike':doBuyBike(btn.dataset.id);break;
  case'select-map':save.selectedMap=btn.dataset.id;saveGame();beep(520,.05);renderMaps();break;
  case'paint':{const id=save.selectedBike,kind=btn.dataset.kind,val=btn.dataset.value;save.paint[id]={...getPaint(id),[kind]:val};saveGame();renderGarage();break;}
  case'save-paint':savePaint();break;
  case'upgrade':applyUpgrade(btn.dataset.part);break;
  case'claim-mission':claimMission(btn.dataset.id);break;
  case'toggle-mute':save.settings.mute=!save.settings.mute;saveGame();renderSettings();break;
  case'toggle-vibration':save.settings.vibration=!save.settings.vibration;saveGame();renderSettings();break;
  case'confirm-reset':confirmReset();break;
  case'reset-data':resetData();break;
  case'close-modal':closeModal();break;
  case'daily':claimDaily();break;
  case'pause':if(game&&!game.done){game.paused=true;showGameModal('pause');}break;
  case'resume':if(game){game.paused=false;closeModal();lastFrame=performance.now();}break;
  case'restart':if(game){const map=game.mapId;playGame();}break;
  case'game-menu':cancelAnimationFrame(raf);game=null;renderHome();break;
  case'nav-missions':cancelAnimationFrame(raf);game=null;renderMissions();break;
 }
});
app.addEventListener('change',e=>{if(e.target.id==='bike-number'||e.target.id==='bike-sticker')return;if(e.target.id==='quality-select'){save.settings.quality=e.target.value;saveGame();renderSettings();}if(e.target.id==='class-filter'){collectionFilter=e.target.value;renderCollection();} });
app.addEventListener('input',e=>{if(e.target.id==='bike-search'){collectionSearch=e.target.value;const pos=e.target.selectionStart;renderCollection();const next=$('#bike-search');next?.focus();next?.setSelectionRange(pos,pos);}});
$('#app').addEventListener('keydown',e=>{if(e.target.matches('input,select'))return;if(screen!=='game'||!game)return;const c=game.controls;const k=e.key.toLowerCase();if(['arrowup','w'].includes(k))c.gas=true;if(['arrowdown','s'].includes(k))c.brake=true;if(['arrowleft','a'].includes(k))c.back=true;if(['arrowright','d'].includes(k))c.forward=true;if(k==='escape'||k==='p'){game.paused=!game.paused;if(game.paused)showGameModal('pause');else closeModal();}if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k))e.preventDefault();});
window.addEventListener('keydown',e=>{if(screen!=='game'||!game)return;const k=e.key.toLowerCase(),c=game.controls;if(['arrowup','w'].includes(k))c.gas=true;if(['arrowdown','s'].includes(k))c.brake=true;if(['arrowleft','a'].includes(k))c.back=true;if(['arrowright','d'].includes(k))c.forward=true;});
window.addEventListener('keyup',e=>{if(!game)return;const k=e.key.toLowerCase(),c=game.controls;if(['arrowup','w'].includes(k))c.gas=false;if(['arrowdown','s'].includes(k))c.brake=false;if(['arrowleft','a'].includes(k))c.back=false;if(['arrowright','d'].includes(k))c.forward=false;});
window.addEventListener('resize',()=>{if(screen==='game'&&game)resizeGameCanvas();});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&screen==='game'&&game&&!game.paused&&!game.done){game.paused=true;showGameModal('pause');}});

// Small utility check exposed to local testing and developer console.
window.WheelieRider2D={bikeCount:BIKES.length,mapCount:MAPS.length,getSave:()=>clone(save),getBikeIds:()=>BIKES.map(b=>b.id)};
renderHome();

// Browsers only permit orientation locking in supported contexts, commonly after a user gesture.
function requestLandscape(){
  try {
    if(window.screen && window.screen.orientation && typeof window.screen.orientation.lock==='function'){
      const result=window.screen.orientation.lock('landscape');
      if(result && typeof result.catch==='function') result.catch(()=>{});
    }
  } catch(e) {}
}
function showSplash(){
  const splash=document.createElement('div');
  splash.id='splash-screen';
  splash.innerHTML='<img class="splash-art" src="assets/splash.png" alt="Wheelie Rider splash screen"><div class="splash-loading"><div class="splash-title">WHEELIE RIDER 2D</div><div class="splash-track"><div class="splash-progress" id="splash-progress"></div></div><div class="splash-status" id="splash-status">MEMUAT GAME... 0%</div></div>';
  document.body.appendChild(splash);
  let progress=0,finished=false;
  const bar=splash.querySelector('#splash-progress'),status=splash.querySelector('#splash-status');
  const tick=()=>{progress=Math.min(100,progress+Math.max(2,Math.ceil((100-progress)*.12)));bar.style.width=progress+'%';status.textContent=progress>=100?'SIAP DIMAINKAN!':'MEMUAT GAME... '+progress+'%';if(progress>=100&&!finished){finished=true;setTimeout(()=>{splash.classList.add('hide');setTimeout(()=>splash.remove(),500);},450);}else if(!finished)setTimeout(tick,110);};
  splash.addEventListener('pointerdown',requestLandscape,{once:true});
  // Try on load as well; if the browser requires a gesture, play/splash interaction retries it.
  requestLandscape();setTimeout(tick,180);
}
showSplash();
})();
