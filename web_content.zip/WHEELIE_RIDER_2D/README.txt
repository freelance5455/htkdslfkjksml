WHEELIE RIDER 2D
================
Game HTML5 offline tentang menjaga keseimbangan motor dan mempertahankan wheelie.

CARA MEMAINKAN DI ANDROID
1. Ekstrak WHEELIE_RIDER_2D.zip menggunakan aplikasi File Manager/ZIP.
2. Buka folder WHEELIE_RIDER_2D.
3. Buka index.html di browser Android yang mendukung HTML5 dan JavaScript.
4. Untuk pengalaman terbaik, pilih landscape. Game juga menata ulang UI untuk portrait.
5. Tidak perlu koneksi internet. Jangan pindahkan/hapus file game saat dimainkan.

KONTROL
- GAS: tambah kecepatan.
- REM: memperlambat motor.
- TARIK / Lean Back: mengangkat bagian depan motor.
- DORONG / Lean Forward: menurunkan bagian depan motor.
- PAUSE: jeda; ULANG: memulai run baru.
- Desktop: W/Atas = gas, S/Bawah = rem, A/Kiri = tarik, D/Kanan = dorong, P/Esc = pause.

FITUR
- Gameplay Canvas 2D dengan akselerasi, drag, sudut bodi, gravitasi rotasi, lintasan naik-turun, wheelie dan kondisi jatuh.
- 7 map: City Street, Desert Run, Green Forest, Mountain Pass, Night Highway, Industrial Zone, dan Extreme Track.
- Tepat 70 motor fiktif: 7 kelas x 10 motor; setiap motor memiliki ID dan statistik.
- Garasi, pembelian motor, cat bodi/pelek/aksen, nomor balap, stiker geometris, dan lima kategori upgrade.
- Koin, rekor, profil lokal, 10 misi, bonus harian, pengaturan suara/kualitas/getaran.
- Progres disimpan di localStorage browser pada perangkat ini.

STRUKTUR FILE
- index.html : halaman dan pemuatan berkas lokal.
- style.css  : gaya UI responsif dan kontrol sentuh.
- game.js    : katalog motor/map, gameplay, rendering, input, progres, audio, dan localStorage.

MENGUBAH MENJADI APK (OPSIONAL)
1. Gunakan pembungkus HTML-to-APK/WebView yang mendukung aset lokal.
2. Impor folder hasil ekstrak, bukan hanya index.html, agar style.css dan game.js ikut tersedia.
3. Pastikan entry point adalah index.html dan aset dibundel di dalam APK (asset lokal), bukan URL web.
4. Aktifkan JavaScript pada WebView; gunakan orientasi landscape jika tersedia, tetapi jangan paksa layar bila wrapper tidak mendukungnya.
5. Build APK dan uji mode pesawat. Jika wrapper tidak dapat mengakses file lokal atau localStorage, gunakan pembungkus lain yang mendukung HTML5 offline.

CATATAN
- Proyek dibuat tanpa CDN, library eksternal, font eksternal, atau panggilan jaringan.
- Penyimpanan localStorage dapat dihapus jika data browser dihapus. Gunakan fungsi Reset hanya bila memang ingin menghapus progres.
- Fisika adalah simulasi ringan untuk game arcade, bukan simulasi kendaraan nyata.


UPDATE SPLASH SCREEN DAN LANDSCAPE
- Splash screen menggunakan gambar lokal assets/splash.png dan menampilkan loading otomatis.
- Game mencoba mengunci orientasi landscape melalui Screen Orientation API saat dibuka dan saat pemain menyentuh splash screen/mulai permainan.
- Catatan: browser Android tidak selalu mengizinkan penguncian orientasi dari halaman HTML biasa. Untuk orientasi landscape yang benar-benar otomatis dan konsisten sebagai APK, atur Activity pada pembungkus Android/WebView ke requestedOrientation="landscape" atau konfigurasi orientasi landscape pada aplikasi HTML-to-APK yang digunakan.
- Pastikan folder assets ikut disertakan saat mengekstrak ZIP; jangan memindahkan splash.png keluar dari folder tersebut.
