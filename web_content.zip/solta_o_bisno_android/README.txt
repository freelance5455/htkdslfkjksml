SOLTA O BISNO - Android MVP

Este projeto empacota o protótipo atual em um aplicativo Android WebView.

Para gerar o APK: abrir a pasta no Android Studio e executar Build > Build APK(s).
O APK de debug ficará em app/build/outputs/apk/debug/app-debug.apk.

Nota: esta versão é um protótipo local. Ainda não possui servidor, GPS em tempo real,
contas reais, pagamentos automáticos, notificações push ou sincronização entre cliente e motorista.
