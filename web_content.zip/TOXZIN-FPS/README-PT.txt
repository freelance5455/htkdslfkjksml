TOXZIN FPS — projeto com painel flutuante Android

O que vem no pacote:
- index.html: interface web completa.
- android-app/: projeto Android nativo que carrega esse index.html e ativa o painel real sobre outros apps.

Para testar o HTML:
1. Extraia o ZIP.
2. Abra index.html no navegador. O painel funciona dentro da página; o navegador não pode desenhar sobre outros aplicativos.

Para criar e instalar o app Android:
1. Instale o Android Studio.
2. No Android Studio, escolha Open e selecione a pasta android-app extraída.
3. Aguarde a sincronização do Gradle e conecte um aparelho Android.
4. Execute o projeto no aparelho.
5. No app, toque em Ativar painel flutuante. O Android abrirá diretamente a tela de permissão; habilite “Permitir exibição sobre outros apps” para TOXZIN FPS.
6. Volte ao app. O painel pode ser arrastado e continua visível ao abrir outros apps. Na aba Otimização, ative e marque as opções sem reabrir a tela principal. Para encerrar o painel, use o X.

O painel nativo fornece atalhos e ajuste de referência de mira. A otimização apresenta recomendações: Android não permite que este HTML limpe RAM nem acelere diretamente a GPU. O Android Studio compila o APK localmente; este pacote contém o projeto-fonte, não um APK já assinado.
