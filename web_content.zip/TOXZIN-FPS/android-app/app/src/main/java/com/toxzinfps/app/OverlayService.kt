package com.toxzinfps.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private lateinit var body: LinearLayout
    private var activeTab = "aim"
    private var optimizationEnabled = false
    private val optimizationChecks = mutableMapOf<String, Boolean>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (panel == null) showPanel()
        isRunning = true
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "toxzinfps_overlay"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Painel flutuante", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("TOXZIN FPS está ativo")
                .setContentText("Toque para abrir o painel de mira e otimização")
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("TOXZIN FPS está ativo")
                .setContentText("Painel flutuante ativado")
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(41, notification)
        }
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded("#101824", 18, "#86B840")
            clipToOutline = true
            elevation = dp(12).toFloat()
        }
        panel = root

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(8), dp(10))
            background = rounded("#192638", 16)
        }
        val title = TextView(this).apply {
            text = "TOXZIN  ·  PAINEL RÁPIDO"
            textSize = 12f
            setTextColor(Color.parseColor("#C6FF52"))
            setTypeface(null, 1)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(34), 1f))
        val close = TextView(this).apply {
            text = "×"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(10), 0, dp(8), 0)
            setOnClickListener { stopSelf() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(42), dp(34)))
        root.addView(header)
        attachDrag(header)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(9), dp(8), dp(9), dp(3))
        }
        val aimTab = miniButton("CALIBRAR MIRA") { activeTab = "aim"; renderBody() }
        val optTab = miniButton("OTIMIZAÇÃO") { activeTab = "opt"; renderBody() }
        tabs.addView(aimTab, LinearLayout.LayoutParams(0, dp(37), 1f).apply { marginEnd = dp(5) })
        tabs.addView(optTab, LinearLayout.LayoutParams(0, dp(37), 1f).apply { marginStart = dp(5) })
        root.addView(tabs)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(7), dp(13), dp(13))
        }
        root.addView(body)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            dp(296), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(110)
        }
        windowManager.addView(root, params)
        renderBody()
    }

    private fun renderBody() {
        if (!::body.isInitialized) return
        body.removeAllViews()
        if (activeTab == "aim") {
            body.addView(label("Ajuste rápido de sensibilidade", 12, "#AAB6C7"))
            val value = label("50", 15, "#C6FF52").apply { gravity = Gravity.END; setTypeface(null, 1) }
            body.addView(value)
            val slider = SeekBar(this).apply {
                max = 99
                progress = 49
                progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#C6FF52"))
                thumbTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#C6FF52"))
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        value.text = (progress + 1).toString()
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            body.addView(slider)
            body.addView(label("Use como referência e refine no treino.", 10, "#91A0B4"))
            body.addView(miniButton("ABRIR CALIBRAÇÃO COMPLETA") { openApp("aim") }, marginTop = 10)
        } else {
            body.addView(label("Ative e marque as opções aqui, sem voltar ao app.", 11, "#AAB6C7"))
            val mode = miniButton(if (optimizationEnabled) "OTIMIZAÇÃO ATIVA ✓" else "ATIVAR OTIMIZAÇÃO") {
                optimizationEnabled = !optimizationEnabled
                renderBody()
                Toast.makeText(this, if (optimizationEnabled) "Checklist de otimização ativado" else "Checklist desativado", Toast.LENGTH_SHORT).show()
            }
            body.addView(mode, marginTop = 9)
            body.addView(optimizationOption("Preparar memória RAM", "Lembrete: fechar apps recentes"), marginTop = 7)
            body.addView(optimizationOption("Perfil gráfico leve", "Lembrete: ajustar no jogo"), marginTop = 5)
            body.addView(optimizationOption("Conferir temperatura e rede", "Lembrete antes da partida"), marginTop = 5)
            body.addView(label("São opções de checklist: Android não permite que este painel limpe RAM ou force a GPU.", 10, "#D7BD83"), marginTop = 8)
        }
    }

    private fun optimizationOption(title: String, subtitle: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(5), dp(4), dp(5))
            background = rounded("#0C131E", 9, "#263548")
        }
        val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        text.addView(label(title, 11, "#E8EDF5"))
        text.addView(label(subtitle, 9, "#91A0B4"))
        row.addView(text, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val checked = optimizationChecks[title] == true
        val action = miniButton(if (checked) "FEITO ✓" else "MARCAR") {
            optimizationChecks[title] = optimizationChecks[title] != true
            renderBody()
        }
        row.addView(action, LinearLayout.LayoutParams(dp(82), dp(34)).apply { marginStart = dp(6) })
        return row
    }

    private fun openApp(section: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("section", section)
        }
        startActivity(intent)
    }

    private fun attachDrag(view: View) {
        var startX = 0f
        var startY = 0f
        var initialX = 0
        var initialY = 0
        view.setOnTouchListener { _, event ->
            val lp = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = lp.x; initialY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = initialX - (event.rawX - startX).toInt()
                    lp.y = initialY + (event.rawY - startY).toInt()
                    try { windowManager.updateViewLayout(panel, lp) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    private fun miniButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 10f
        isAllCaps = false
        setTextColor(Color.parseColor("#C6FF52"))
        background = rounded("#1B2A3B", 10, "#33475D")
        setPadding(dp(5), 0, dp(5), 0)
        setOnClickListener { action() }
    }

    private fun label(text: String, size: Int, color: String): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(Color.parseColor(color))
    }

    private fun LinearLayout.addView(view: View, marginTop: Int) {
        addView(view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(marginTop)
        })
    }

    private fun rounded(fill: String, radius: Int, stroke: String? = null) = GradientDrawable().apply {
        setColor(Color.parseColor(fill))
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), Color.parseColor(stroke))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panel?.let { view -> try { windowManager.removeView(view) } catch (_: Exception) {} }
        panel = null
        isRunning = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else stopForeground(true)
        super.onDestroy()
    }

    companion object {
        @Volatile var isRunning: Boolean = false
            private set
    }
}
