package com.toxzinfps.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var waitingForOverlaySettings = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                syncPanelState()
                openRequestedSection(intent)
            }
        }
        webView.addJavascriptInterface(OverlayBridge(this), "AndroidOverlay")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (waitingForOverlaySettings) {
            waitingForOverlaySettings = false
            if (Settings.canDrawOverlays(this)) {
                launchOverlay()
                notifyPage("window.onOverlayPermissionResult(true,true)")
            } else {
                notifyPage("window.onOverlayPermissionResult(false,false)")
            }
        } else if (::webView.isInitialized) {
            syncPanelState()
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            openRequestedSection(intent)
        }
    }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            launchOverlay()
            notifyPage("window.onOverlayPermissionResult(true,true)")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Permitir painel flutuante")
            .setMessage("Para mostrar o painel por cima de jogos e outros aplicativos, o Android precisa permitir que TOXZIN FPS seja exibido sobre outros apps. Na tela seguinte, ative a permissão para TOXZIN FPS.")
            .setNegativeButton("Agora não") { _, _ ->
                notifyPage("window.onOverlayPermissionResult(false,false)")
            }
            .setPositiveButton("Continuar") { _, _ ->
                waitingForOverlaySettings = true
                val settingsIntent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(settingsIntent)
            }
            .show()
    }

    private fun launchOverlay() {
        val serviceIntent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
        else startService(serviceIntent)
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
        notifyPage("window.onNativeOverlayState(false)")
    }

    private fun syncPanelState() {
        if (::webView.isInitialized) {
            val running = OverlayService.isRunning
            notifyPage("window.onNativeOverlayState($running)")
        }
    }

    private fun notifyPage(script: String) {
        if (::webView.isInitialized) webView.post { webView.evaluateJavascript(script, null) }
    }

    private fun openRequestedSection(intent: Intent?) {
        val section = intent?.getStringExtra("section") ?: return
        if (section == "aim" || section == "opt") {
            webView.postDelayed({ notifyPage("show('$section')") }, 250)
            intent?.removeExtra("section")
        }
    }

    inner class OverlayBridge(private val context: Context) {
        @JavascriptInterface
        fun requestOverlayPermission() {
            runOnUiThread { requestOverlay() }
        }

        @JavascriptInterface
        fun stopOverlay() {
            runOnUiThread { this@MainActivity.stopOverlay() }
        }

        @JavascriptInterface
        fun isOverlayRunning(): Boolean = OverlayService.isRunning

        @JavascriptInterface
        fun openSection(section: String) {
            runOnUiThread {
                this@MainActivity.moveTaskToBack(false)
                webView.postDelayed({ notifyPage("show('$section')") }, 250)
            }
        }
    }
}
