Bio Rankers - Android WebView-Ready Version
This folder is ready to load inside an Android WebView or package using a WebView wrapper app.
Open index.html as the local start page.
No login/logout. Chapter and chapter-dependent exercise selection included.
Note: This ZIP is not a compiled APK.
