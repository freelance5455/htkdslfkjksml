// Change this before building your APK. This password is stored in the app and can be extracted.
window.SINERU_ADMIN_PASSWORD = 'SineruadminAnuradhapura100';
