SINERU ENTERPRISES - APK Maker web app package

Contains index.html, style.css, app.js and config.js. Upload the ZIP only to a builder that explicitly accepts HTML/CSS/JavaScript website projects.

BEFORE BUILDING: edit config.js and replace CHANGE_THIS_PASSWORD with your own password. Do not share that password.

Features: offline-first catalog using IndexedDB, six categories, no demo products, add/edit/delete products, local photo storage. Data stays on the device/browser profile; uninstalling/clearing app data can erase it.

Important: this is a web-app source ZIP, NOT an APK. A website-to-APK builder must support local/offline HTML assets, JavaScript, IndexedDB, dialogs and image file selection. The admin password is client-side and is not secure against reverse engineering.
