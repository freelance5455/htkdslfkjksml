DUNIA PERMAINAN PINTAR — ANDROID PROJECT

Kandungan:
- www/index.html: permainan asal, dibungkus untuk aplikasi Android.
- Butang Backup dan Restore ditambah pada skrin utama.
- Permainan berfungsi secara offline selepas dipasang.

PENTING TENTANG SIMPANAN:
Progress disimpan pada peranti menggunakan localStorage. Backup JSON boleh dieksport melalui butang Backup dan dipulihkan melalui Restore. Minta pemain simpan fail backup di tempat selamat sebelum uninstall/tukar telefon. Uninstall boleh memadam data aplikasi. Tiada cloud sync.

CARA BINA APK (Windows):
1. Pasang Node.js LTS dan Android Studio.
2. Extract folder projek ini.
3. Buka Command Prompt dalam folder projek.
4. Jalankan:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
5. Dalam Android Studio, tunggu Gradle sync selesai.
6. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK debug biasanya berada di android/app/build/outputs/apk/debug/app-debug.apk

Untuk APK release yang boleh diedarkan secara lebih rasmi, gunakan Build > Generate Signed Bundle / APK dan simpan signing key dengan selamat. Jangan hilangkan signing key.

Keperluan binaan: sambungan internet diperlukan untuk pemasangan dependencies/Android SDK pada kali pertama. Aplikasi yang telah dipasang boleh dimainkan tanpa internet.
