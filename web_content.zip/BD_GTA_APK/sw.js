// Offline cache: the game shell is cached on first visit; three.js (CDN) is cached as it loads,
// so after one online start the game also runs without internet.
const CACHE = "bd-gta-v12";
const SHELL = ["./", "./index.html", "./manifest.webmanifest", "./icons/icon-192.png", "./icons/icon-512.png"];
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  const remember = (res) => { if (res && (res.ok || res.type === "opaque")) caches.open(CACHE).then((c) => c.put(req, res.clone())); return res; };
  if (url.origin === self.location.origin) {
    e.respondWith(caches.match(req).then((hit) => hit || fetch(req).then(remember)));
  } else {
    e.respondWith(fetch(req).then(remember).catch(() => caches.match(req)));
  }
});
