import React, { useState, useEffect, useMemo } from 'react';
import {
  Menu, Search, Calendar as CalendarIcon, Plus, ChevronLeft, ChevronRight,
  ChevronDown, ChevronUp, Check, X, RefreshCw, Sparkles, Flame, Shield,
  Brain, Bookmark, BookOpen, BarChart3, Dumbbell, Clock, User, Users,
  Download, Upload, Trash2, AlertTriangle, CheckCircle2, Lock, Unlock,
  Sliders, Sun, Moon, Smartphone, Maximize2, Info,
  Play, Pause, RotateCcw, Star, Award, TrendingUp, Activity, Layers,
  ExternalLink, HelpCircle, Zap, Target, ListChecks, CheckSquare, AlertCircle,
  FileText, PenTool, ArrowRight
} from 'lucide-react';

// ============================================================================
// 1. NEURO-BUCKET CLASSIFICATION & 26-SUBJECT (19 + 7 INTEGRATED) DATABASE
//    WITH PAST 5–7 YEAR INI-CET WEIGHTAGE & PYQ FREQUENCY METADATA
// ============================================================================
const BUCKET_CONFIG = {
  A: {
    id: 'A',
    name: 'Bucket A — Volatile / Shallow Semantic Trace',
    shortName: 'Bucket A (Volatile)',
    intervals: [1, 3, 7, 16, 35],
    targetRevisionsByMay20: 5,
    color: '#F43F5E',
    bgLight: 'bg-rose-500/12 text-rose-600 dark:bg-rose-500/20 dark:text-rose-300',
    barClass: 'bg-rose-500 text-white',
    dotClass: 'bg-rose-500',
    borderClass: 'border-rose-500/30',
    description: 'High-volatility isolated facts, enzymes, culture media & tables (5 Revisions Target: 1 → 3 → 7 → 16 → 35d)'
  },
  B: {
    id: 'B',
    name: 'Bucket B — Deep Pathophysiological Schema',
    shortName: 'Bucket B (Conceptual)',
    intervals: [1, 7, 21, 45],
    targetRevisionsByMay20: 4,
    color: '#4F46E5',
    bgLight: 'bg-indigo-500/12 text-indigo-600 dark:bg-indigo-500/20 dark:text-indigo-300',
    barClass: 'bg-indigo-500 text-white',
    dotClass: 'bg-indigo-500',
    borderClass: 'border-indigo-500/30',
    description: 'Cause-and-effect clinical networks & 7 Integrated Systems (4 Revisions Target, or 5 if Weak: 1 → 7 → 21 → 45d)'
  },
  C: {
    id: 'C',
    name: 'Bucket C — Visual Pattern & IBQ Recognition',
    shortName: 'Bucket C (Visual/IBQ)',
    intervals: [1, 5, 15, 30],
    targetRevisionsByMay20: 4,
    color: '#10B981',
    bgLight: 'bg-emerald-500/12 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-300',
    barClass: 'bg-emerald-500 text-white',
    dotClass: 'bg-emerald-500',
    borderClass: 'border-emerald-500/30',
    description: 'Occipital-parietal spot recognition, CT/X-ray signs & IBQs (4 Revisions Target, or 5 if Weak: 1 → 5 → 15 → 30d)'
  }
};

const ORGAN_SYSTEMS = {
  cvs: 'Cardiovascular (CVS)',
  renal: 'Renal & Electrolytes',
  endo: 'Endocrinology & Metabolism',
  resp: 'Respiratory System',
  cns: 'Central Nervous System (CNS)',
  heme: 'Hematology & Oncology',
  rheum: 'Rheumatology & Immunology',
  gi: 'Hepatobiliary & GI',
  id: 'Infectious Diseases',
  msk: 'Musculoskeletal & Ortho',
  repro: 'Reproductive & OBGYN',
  head_neck: 'Head, Neck, Eye & ENT',
  gen: 'General / Multisystem'
};

// Macro Runway Phases leading up to May 20, 2027 INI-CET Exam
const MACRO_RUNWAY_PHASES = [
  {
    id: 'phase1',
    title: 'Phase 1: Core 1st-Read Sprint + Rolling Rev 1 & 2',
    range: 'Nov 9 – Dec 31, 2026 (53 Days)',
    startDate: '2026-11-09',
    endDate: '2026-12-31',
    badge: '1st Read Core',
    color: 'indigo',
    detail: '10:15 AM (Session 1) + 6:00 PM (Session 2) complete primary 1st read. 2:30 PM Split MCQ block handles Day-1 revision of yesterday’s evening topic + today’s morning MCQs.'
  },
  {
    id: 'buffer',
    title: 'Phase 1 Buffer: Spillover 1st-Read & 20th NB Curation',
    range: 'Jan 1 – Jan 15, 2027 (15 Days)',
    startDate: '2027-01-01',
    endDate: '2027-01-15',
    badge: 'Jan 15 Buffer',
    color: 'amber',
    detail: 'Absorbs any remaining 1st-read subtopics, zeroes out December backlogs, and finalizes Physical 20th Notebook entries for any subtopic/bookmark/pearl with low retention at Rev 2.'
  },
  {
    id: 'phase2',
    title: 'Phase 2: Full-Day Revisions 2, 3, 4 (+ Weak 5th Rev) & Daily 30m Physical 20th NB',
    range: 'Jan 16 – Apr 25, 2027 (100 Days)',
    startDate: '2027-01-16',
    endDate: '2027-04-25',
    badge: '4–5 Revisions + 30m 20th NB',
    color: 'emerald',
    detail: '10:15 AM & 6:00 PM blocks unlock for high-speed Spaced Revisions 2, 3, 4 (and 5th Revision for Weak <68% GT / <75% Rev-2 topics). Starts mandatory 30-min daily Physical 20th Notebook active recall.'
  },
  {
    id: 'phase3',
    title: 'Phase 3: Terminal 25-Day Rapid Consolidation (Physical 20th NB + IBQs)',
    range: 'Apr 26 – May 20, 2027 (25 Days)',
    startDate: '2027-04-26',
    endDate: '2027-05-20',
    badge: 'Exam Peak (May 20)',
    color: 'rose',
    detail: 'Full-speed terminal pass of Physical 20th Notebook clinical pearls, twice-missed bookmarks, Bucket A volatile tables, and Bucket C visual IBQs.'
  }
];

// Adaptive MCQ Review Time-Pacing & Capacity Calibrator (For Days 1-25 Routine vs Post-Routine Speed)
const PACING_MODES = {
  deep: {
    id: 'deep',
    name: 'Mode 1: Deep Explanation Review (Days 1–25 Routine Builder)',
    shortBadge: '2 Topics/AM • 50 Split MCQs',
    morningTopicCap: 2,
    minsPerMorningTopic: 45,
    mcqsPerMorningTopic: 15,
    partAYesterdayQs: 20,
    partBTodayQs: 30,
    reviewTimePerWrongSec: 120,
    reviewTimePerCorrectSec: 15,
    description: 'Ideal when MCQ explanation review takes longer: caps 08:30 AM at 2 topics (45 mins each = 15m solve + 30m deep explanation review) and trims 02:30 PM to 50 total MCQs (20 Yesterday PM + 30 Today AM).'
  },
  balanced: {
    id: 'balanced',
    name: 'Mode 2: Balanced Triage Pace (Days 25+ Settled Routine)',
    shortBadge: '3 Topics/AM • 80 Split MCQs',
    morningTopicCap: 3,
    minsPerMorningTopic: 30,
    mcqsPerMorningTopic: 20,
    partAYesterdayQs: 35,
    partBTodayQs: 45,
    reviewTimePerWrongSec: 90,
    reviewTimePerCorrectSec: 10,
    description: 'Uses 3-Tier Explanation Triage (skip reading explanations for confident corrects; spend 90s only on wrong/50:50 guesses): fits 3 topics at 08:30 AM (30m each) and 80 MCQs at 02:30 PM.'
  },
  sprint: {
    id: 'sprint',
    name: 'Mode 3: Post-Jan 15 Full-Day Revision Sprint (Phase 2)',
    shortBadge: '6 Topics/Day • 110 MCQs',
    morningTopicCap: 6,
    minsPerMorningTopic: 25,
    mcqsPerMorningTopic: 25,
    partAYesterdayQs: 50,
    partBTodayQs: 60,
    reviewTimePerWrongSec: 60,
    reviewTimePerCorrectSec: 5,
    description: 'Unlocks after Jan 15 when 1st read finishes: 10:15 AM and 06:00 PM blocks join 08:30 AM for pure spaced revisions (up to 6 topics/day).'
  }
};

const SUBJECTS_DB = [
  // 7 Separate Integrated Clinical Systems
  {
    name: 'Integrated CVS', bucket: 'B', isIntegrated: true, defaultSys: 'cvs',
    pyqWeightage: 9.5, avgQuestions: '16–20 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.82,
    subheadings: [
      { title: 'Valvular Heart Disease & Murmur Hemodynamic Maneuvers', sys: 'cvs' },
      { title: 'STEMI / NSTEMI ECG Localization & Reperfusion Protocol', sys: 'cvs' },
      { title: 'Heart Failure (HFrEF vs HFpEF) & 4-Pillar GDMT', sys: 'cvs' },
      { title: 'Arrhythmias, Channelopathies & JVP Waveform Analysis', sys: 'cvs' },
      { title: 'Cardiomyopathies (HCM, DCM, Restrictive) & Constrictive Pericarditis', sys: 'cvs' }
    ]
  },
  {
    name: 'Integrated Renal', bucket: 'B', isIntegrated: true, defaultSys: 'renal',
    pyqWeightage: 7.5, avgQuestions: '13–16 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.85,
    subheadings: [
      { title: 'Glomerulonephritis (Nephritic vs Nephrotic EM/IF Deposits)', sys: 'renal' },
      { title: 'RTA Types 1, 2, 4 & Winter Formula Acid-Base ABG', sys: 'renal' },
      { title: 'Tubular Channelopathies (Bartter, Gitelman, Liddle, Fanconi)', sys: 'renal' },
      { title: 'AKI Staging, FeNa & Refractory Dialysis Indications', sys: 'renal' }
    ]
  },
  {
    name: 'Integrated Endocrine', bucket: 'B', isIntegrated: true, defaultSys: 'endo',
    pyqWeightage: 7.0, avgQuestions: '12–15 Qs', tier: 'High Yield', weightageMultiplier: 0.86,
    subheadings: [
      { title: 'DKA vs HHS Protocol & SGLT2i Euglycemic DKA Mechanics', sys: 'endo' },
      { title: 'Cushing Syndrome Workup & Dexamethasone Suppression Algorithms', sys: 'endo' },
      { title: 'MEN Syndromes (1, 2A, 2B) & Pheochromocytoma Rule of 10s', sys: 'endo' },
      { title: 'Thyroid Storm, Myxedema Coma & Parathyroid Ca2+ Axis', sys: 'endo' }
    ]
  },
  {
    name: 'Integrated Respiratory', bucket: 'B', isIntegrated: true, defaultSys: 'resp',
    pyqWeightage: 6.5, avgQuestions: '11–14 Qs', tier: 'High Yield', weightageMultiplier: 0.88,
    subheadings: [
      { title: 'PFT Flow-Volume Loops & DLCO Differential Diagnosis', sys: 'resp' },
      { title: 'ARDS Berlin Criteria, Low-Tidal Ventilation & V/Q Mismatch', sys: 'resp' },
      { title: 'ILD High-Res CT Patterns (UIP vs NSIP vs Sarcoidosis)', sys: 'resp' },
      { title: 'Pleural Effusion Light Criteria & Pulmonary Embolism Wells', sys: 'resp' }
    ]
  },
  {
    name: 'Integrated CNS', bucket: 'B', isIntegrated: true, defaultSys: 'cns',
    pyqWeightage: 8.5, avgQuestions: '15–18 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.83,
    subheadings: [
      { title: 'Brainstem Stroke Syndromes (Wallenberg, Weber, Millard-Gubler)', sys: 'cns' },
      { title: 'Spinal Cord Tracts, Brown-Sequard & Conus vs Cauda Equina', sys: 'cns' },
      { title: 'Demyelinating Disorders (MS McDonald, NMOSD Aquaporin-4, GBS)', sys: 'cns' },
      { title: 'Status Epilepticus Ladder & Autoimmune Limbic Encephalitis', sys: 'cns' }
    ]
  },
  {
    name: 'Integrated Hematology', bucket: 'B', isIntegrated: true, defaultSys: 'heme',
    pyqWeightage: 7.5, avgQuestions: '13–16 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.85,
    subheadings: [
      { title: 'Microcytic & Hemolytic Anemias (PNH CD55/59, G6PD, AIHA)', sys: 'heme' },
      { title: 'Acute Leukemias (AML t(15;17), ALL Prognostics & TLS)', sys: 'heme' },
      { title: 'Coagulation Cascade, DIC vs TTP vs HUS & Mixing Studies', sys: 'heme' },
      { title: 'Multiple Myeloma CRAB/SLiM & Hodgkin vs Non-Hodgkin', sys: 'heme' }
    ]
  },
  {
    name: 'Integrated Rheumatology', bucket: 'B', isIntegrated: true, defaultSys: 'rheum',
    pyqWeightage: 6.0, avgQuestions: '10–13 Qs', tier: 'High Yield', weightageMultiplier: 0.89,
    subheadings: [
      { title: 'SLE Autoantibodies, Lupus Nephritis Classes I-VI & APLA', sys: 'rheum' },
      { title: 'Vasculitis Classification (ANCA GPA/EGPA/MPA & Large Vessel)', sys: 'rheum' },
      { title: 'Seronegative Spondyloarthropathies & Crystal Arthropathies', sys: 'rheum' },
      { title: 'Scleroderma (CREST vs Diffuse), Sjogren & Dermatomyositis', sys: 'rheum' }
    ]
  },
  // Bucket A — 6 Volatile Subjects
  {
    name: 'Anatomy', bucket: 'A', isIntegrated: false, defaultSys: 'cns',
    pyqWeightage: 6.5, avgQuestions: '12–14 Qs', tier: 'High Yield', weightageMultiplier: 0.88,
    subheadings: [
      { title: 'Skull Base Foramina & Cranial Nerve Exit Pathways', sys: 'cns' },
      { title: 'Brachial Plexus Cords, Root Values & Upper Limb Nerve Injuries', sys: 'msk' },
      { title: 'Pharyngeal Arch, Pouch & Cleft Embryology Derivatives', sys: 'head_neck' },
      { title: 'Coronary Dominance, Sinus Venosus & Fetal Shunt Remnants', sys: 'cvs' },
      { title: 'Retroperitoneal Relations, Inguinal Canal & Perineal Pouches', sys: 'gi' }
    ]
  },
  {
    name: 'Biochemistry', bucket: 'A', isIntegrated: false, defaultSys: 'endo',
    pyqWeightage: 6.5, avgQuestions: '12–14 Qs', tier: 'High Yield', weightageMultiplier: 0.88,
    subheadings: [
      { title: 'Glycogen Storage (Von Gierke, Pompe, McArdle) & Lysosomal Storage', sys: 'endo' },
      { title: 'Rate-Limiting Enzymes of Glycolysis, TCA, Urea & Heme Synthesis', sys: 'gi' },
      { title: 'Vitamin Cofactors, Trace Elements & Lipoprotein Apo-Markers', sys: 'cvs' },
      { title: 'DNA Repair Defects (Lynch, Xeroderma) & CrispR/PCR Techniques', sys: 'heme' }
    ]
  },
  {
    name: 'Microbiology', bucket: 'A', isIntegrated: false, defaultSys: 'id',
    pyqWeightage: 8.0, avgQuestions: '15–18 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.84,
    subheadings: [
      { title: 'Selective & Differential Culture Media + Acid-Fast / Special Stains', sys: 'id' },
      { title: 'Bacterial Exotoxins/Endotoxins & Meningitis CSF Profiles', sys: 'cns' },
      { title: 'Dimorphic Fungi, Opportunistic Mycoses & Parasitic Egg IBQs', sys: 'resp' },
      { title: 'Arboviruses, HIV Window Period Assays & Hepatitis B/C Serology', sys: 'gi' }
    ]
  },
  {
    name: 'Pharmacology', bucket: 'A', isIntegrated: false, defaultSys: 'cvs',
    pyqWeightage: 8.5, avgQuestions: '16–19 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.83,
    subheadings: [
      { title: 'Antiarrhythmics (Vaughan-Williams), Antihypertensives & Heart Failure Drugs', sys: 'cvs' },
      { title: 'Diuretics Nephron Site of Action & Nephrotoxic Drug Antidotes', sys: 'renal' },
      { title: 'Antiepileptics, Antipsychotics & Autonomic Cholinergic/Adrenergic', sys: 'cns' },
      { title: 'Monoclonal Antibodies (-mab Nomenclature) & Chemo Toxicity Rescue', sys: 'heme' },
      { title: 'DMARDs, Biologics & Gout Uricosuric Pharmacokinetics', sys: 'rheum' }
    ]
  },
  {
    name: 'Community Medicine (PSM)', bucket: 'A', isIntegrated: false, defaultSys: 'gen',
    pyqWeightage: 7.0, avgQuestions: '13–15 Qs', tier: 'High Yield', weightageMultiplier: 0.87,
    subheadings: [
      { title: 'Epidemiological Study Designs, Odds Ratio, RR & Screening Bias', sys: 'gen' },
      { title: 'Biostatistics Tests (Parametric vs Non-Parametric, Sensitivity/PPV)', sys: 'gen' },
      { title: 'National Health Programs (NTEP TB, NVBDCP, Universal Immunization)', sys: 'id' },
      { title: 'Biomedical Waste Categories (Yellow/Red/White/Blue) & Cold Chain', sys: 'gen' }
    ]
  },
  {
    name: 'Forensic Medicine (FMT)', bucket: 'A', isIntegrated: false, defaultSys: 'gen',
    pyqWeightage: 4.5, avgQuestions: '8–10 Qs', tier: 'Core Yield', weightageMultiplier: 0.94,
    subheadings: [
      { title: 'BNS / IPC Legal Sections, Inquest Types & Medical Negligence', sys: 'gen' },
      { title: 'Toxicology Antidotes, Chelating Agents & Agricultural Poisons', sys: 'cns' },
      { title: 'Postmortem Changes (Algor, Rigor, Livor) & Ballistics Entry/Exit', sys: 'gen' },
      { title: 'Mechanical Asphyxia (Hanging vs Strangulation) & Diatom Test', sys: 'resp' }
    ]
  },
  // Bucket B — 6 Core Conceptual Subjects
  {
    name: 'Physiology', bucket: 'B', isIntegrated: false, defaultSys: 'cvs',
    pyqWeightage: 6.5, avgQuestions: '12–14 Qs', tier: 'High Yield', weightageMultiplier: 0.88,
    subheadings: [
      { title: 'Cardiac Cycle Pressure-Volume Loops & Frank-Starling Curve', sys: 'cvs' },
      { title: 'Glomerular Filtration Starling Forces & Countercurrent Multiplier', sys: 'renal' },
      { title: 'Oxygen-Hemoglobin Dissociation Curve & Alveolar-Arterial Gradient', sys: 'resp' },
      { title: 'Action Potential Ion Channels, Sarcomere & Spindle Reflexes', sys: 'cns' }
    ]
  },
  {
    name: 'Pathology', bucket: 'B', isIntegrated: false, defaultSys: 'heme',
    pyqWeightage: 9.0, avgQuestions: '17–20 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.82,
    subheadings: [
      { title: 'Cell Injury, Apoptosis Pathways (Intrinsic/Extrinsic) & Necrosis Types', sys: 'gen' },
      { title: 'Hypersensitivity Types I-IV, Transplant Rejection & Amyloidosis', sys: 'rheum' },
      { title: 'Neoplasia Hallmarks, Tumor Suppressors (p53, RB) & Paraneoplastic', sys: 'heme' },
      { title: 'Renal Biopsy Electron Microscopy Spikes/Domes & Thyroid Histopathology', sys: 'renal' }
    ]
  },
  {
    name: 'General Medicine', bucket: 'B', isIntegrated: false, defaultSys: 'cvs',
    pyqWeightage: 11.0, avgQuestions: '20–24 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.80,
    subheadings: [
      { title: 'Harrison Internal Medicine Tables: Toxidromes & Emergency Protocols', sys: 'cns' },
      { title: 'Cirrhosis Portal Hypertension, Child-Pugh, MELD & Hepatic Encephalopathy', sys: 'gi' },
      { title: 'Infective Endocarditis Modified Duke Criteria & Rheumatic Fever', sys: 'cvs' },
      { title: 'Electrolyte Emergencies (Hyperkalemia ECG, Hyponatremia ODS Prevention)', sys: 'renal' }
    ]
  },
  {
    name: 'General Surgery', bucket: 'B', isIntegrated: false, defaultSys: 'gi',
    pyqWeightage: 9.5, avgQuestions: '18–21 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.82,
    subheadings: [
      { title: 'ATLS Trauma Primary Survey, Glasgow Coma Scale & FAST Scan', sys: 'gen' },
      { title: 'Hepatobiliary (Calot Triangle, Strasberg Injury, Whipple Procedure)', sys: 'gi' },
      { title: 'Breast Carcinoma Staging, Sentinel Node & Thyroidectomy Complications', sys: 'endo' },
      { title: 'Intestinal Obstruction, Appendicitis Scores & Hernia Mesh Planes', sys: 'gi' }
    ]
  },
  {
    name: 'OBGYN', bucket: 'B', isIntegrated: false, defaultSys: 'repro',
    pyqWeightage: 9.5, avgQuestions: '18–21 Qs', tier: 'Ultra-High Yield', weightageMultiplier: 0.82,
    subheadings: [
      { title: 'Partograph, Active Management of Labor & PPH Escalation Bundle', sys: 'repro' },
      { title: 'Preeclampsia MgSO4 Toxicity, Antepartum Hemorrhage & Ectopic', sys: 'repro' },
      { title: 'PCOS Rotterdam Criteria, Primary Amenorrhea Mullerian Workup', sys: 'endo' },
      { title: 'Cervical FIGO Staging, Endometrial Hyperplasia & Ovarian Markers', sys: 'repro' }
    ]
  },
  {
    name: 'Pediatrics', bucket: 'B', isIntegrated: false, defaultSys: 'gen',
    pyqWeightage: 5.5, avgQuestions: '10–12 Qs', tier: 'High Yield', weightageMultiplier: 0.90,
    subheadings: [
      { title: 'Neonatal Resuscitation (NRP Algorithm), Jaundice & Respiratory Distress', sys: 'resp' },
      { title: 'Congenital Heart Disease (Cyanotic vs Acyanotic, Tetralogy Spells)', sys: 'cvs' },
      { title: 'Developmental Milestones (Gross/Fine/Social) & SAM Management', sys: 'cns' },
      { title: 'Pediatric Nephrotic Syndrome, Kawasaki Criteria & Inborn Errors', sys: 'renal' }
    ]
  },
  // Bucket C — 7 Visual / IBQ Subjects
  {
    name: 'Dermatology', bucket: 'C', isIntegrated: false, defaultSys: 'rheum',
    pyqWeightage: 3.5, avgQuestions: '6–8 Qs', tier: 'IBQ High Yield', weightageMultiplier: 0.92,
    subheadings: [
      { title: 'Vesiculobullous Disorders (Pemphigus Vulgaris vs Bullous Pemphigoid IF)', sys: 'rheum' },
      { title: 'Psoriasis Auspitz Sign, Lichen Planus Wickham Striae & Pityriasis', sys: 'rheum' },
      { title: 'Hansen Disease Ridley-Jopling Spectrum & STI Syndromic Kits', sys: 'id' }
    ]
  },
  {
    name: 'Ophthalmology', bucket: 'C', isIntegrated: false, defaultSys: 'head_neck',
    pyqWeightage: 4.0, avgQuestions: '7–9 Qs', tier: 'IBQ High Yield', weightageMultiplier: 0.92,
    subheadings: [
      { title: 'Visual Field Defects Along Optic Pathway & Pupil Marcus-Gunn RAPD', sys: 'cns' },
      { title: 'Fundus IBQs (Cherry Red Spot, Diabetic/Hypertensive Retinopathy, CRVO)', sys: 'head_neck' },
      { title: 'Acute Angle-Closure Glaucoma, Uveitis Keratic Precipitates & Cataract', sys: 'head_neck' }
    ]
  },
  {
    name: 'ENT', bucket: 'C', isIntegrated: false, defaultSys: 'head_neck',
    pyqWeightage: 3.5, avgQuestions: '6–8 Qs', tier: 'IBQ Core Yield', weightageMultiplier: 0.94,
    subheadings: [
      { title: 'Tuning Fork Tests (Rinne, Weber, ABC) & Pure Tone Audiometry Curves', sys: 'head_neck' },
      { title: 'Cholesteatoma Unsafe CSOM Complications & Facial Nerve Topodiagnosis', sys: 'cns' },
      { title: 'Laryngeal Palsies, Juvenile Nasopharyngeal Angiofibroma & Tracheostomy', sys: 'resp' }
    ]
  },
  {
    name: 'Psychiatry', bucket: 'C', isIntegrated: false, defaultSys: 'cns',
    pyqWeightage: 3.5, avgQuestions: '6–8 Qs', tier: 'Core Yield', weightageMultiplier: 0.94,
    subheadings: [
      { title: 'Schizophrenia First-Rank Symptoms, Clozapine Agranulocytosis & NMS', sys: 'cns' },
      { title: 'Mood Disorders, Lithium Therapeutic Index Monitoring & ECT', sys: 'renal' },
      { title: 'Substance Withdrawal Timelines (Delirium Tremens, Wernicke-Korsakoff)', sys: 'cns' }
    ]
  },
  {
    name: 'Radiology', bucket: 'C', isIntegrated: false, defaultSys: 'resp',
    pyqWeightage: 4.5, avgQuestions: '8–10 Qs', tier: 'IBQ Ultra-Yield', weightageMultiplier: 0.88,
    subheadings: [
      { title: 'Chest X-Ray Signs (Silhouette, Air Bronchogram, Golden S, Batwing)', sys: 'resp' },
      { title: 'Neuro-CT/MRI Classics (Epidural Biconvex vs Subdural Crescent, Ring Lesions)', sys: 'cns' },
      { title: 'Barium GI Appearances (Bird-Beak, Apple-Core, String Sign) & Bone Tumors', sys: 'gi' }
    ]
  },
  {
    name: 'Anesthesia', bucket: 'C', isIntegrated: false, defaultSys: 'resp',
    pyqWeightage: 3.5, avgQuestions: '6–8 Qs', tier: 'IBQ High Yield', weightageMultiplier: 0.92,
    subheadings: [
      { title: 'Capnography EtCO2 Waveforms (Shark-Fin, Curare Cleft, Esophageal)', sys: 'resp' },
      { title: 'Airway Mallampati, Cormack-Lehane, LMA & Mapleson Breathing Circuits', sys: 'resp' },
      { title: 'Neuromuscular Blockers, Malignant Hyperthermia Dantrolene & Local Toxicity', sys: 'cvs' }
    ]
  },
  {
    name: 'Orthopedics', bucket: 'C', isIntegrated: false, defaultSys: 'msk',
    pyqWeightage: 4.0, avgQuestions: '7–9 Qs', tier: 'IBQ High Yield', weightageMultiplier: 0.91,
    subheadings: [
      { title: 'Upper Limb Nerve Injury Splints (Cock-Up, Knuckle-Bender, Aeroplane)', sys: 'msk' },
      { title: 'Bone Tumor X-Ray Patterns (Codman Triangle, Sunburst, Onion-Peel, Soap-Bubble)', sys: 'msk' },
      { title: 'Named Fractures (Colles, Monteggia, Galeazzi), Compartment Syndrome & Fat Embolism', sys: 'msk' }
    ]
  }
];

const ALL_TWENTY_SIX_NAMES = SUBJECTS_DB.map(s => s.name);

const PHYSIO_CHECKLIST_STEPS = [
  { id: 'p1', time: '07:30 AM', title: 'Sunlight / ipRGCs & Adenosine Clearance', detail: '10m outdoor light → SCN melatonin clearance; delay caffeine 60m' },
  { id: 'p2', time: '08:00 AM', title: 'Omega-3 (DHA/EPA) + Vitamin D3/K2 Priming', detail: 'High-protein/healthy-fat breakfast for tyrosine & membrane fluidity' },
  { id: 'p3', time: '08:30 AM', title: 'Peak Prefrontal Recall (Revisions 2, 3, 4 & 5 Only)', detail: 'Blind custom Q-bank test of up to 3 due topics (18m test + 12m retrograde note patch)' },
  { id: 'p4', time: '10:15 AM', title: 'Ultradian 90m Deep Encoding (Session 1 1st-Read)', detail: '2 × 85m Bucket B / Integrated sprints; no Reels/Shorts in 15m break' },
  { id: 'p5', time: '01:15 PM', title: 'Moderate-GI Lunch + 20m NSDR & Caffeine Cutoff', detail: '20m Non-Sleep Deep Rest clears hippocampal buffer; strict 1:30 PM cutoff' },
  { id: 'p6', time: '02:30 PM', title: 'Split MCQ Block: Yesterday PM (Rev 1) + Today AM MCQs', detail: '2:30–3:15 PM: Yesterday’s 6PM topic MCQs (= Rev 1!) • 3:15–4:15 PM: Today’s 10:15 AM MCQs' },
  { id: 'p7', time: '04:30 PM', title: 'van Dongen 4-Hr Post-Learning Gym BDNF Window', detail: 'Banana + salt pre-workout; <=45m machine lifting @ 1–2 RIR' },
  { id: 'p8', time: '05:30 PM', title: '30g Whey + 5g Creatine Monohydrate', detail: 'Replenishes prefrontal cortex & myofibrillar phosphocreatine ATP' },
  { id: 'p9', time: '06:00 PM', title: 'Post-Gym Neuroplastic Window (Session 2 + 15m Anchor)', detail: '6:00–8:10 PM Bucket A/C 1st-read + 8:10–8:30 PM 15-MCQ rapid anchor' },
  { id: 'p10', time: '09:00 PM', title: 'Pre-Sleep Synaptic Tagging + 30m Physical 20th NB', detail: 'Cooled Bookmarks, Spaced Pearls & 30-min Physical 20th Notebook active recall' },
  { id: 'p11', time: '10:15 PM', title: 'Mg-Bisglycinate & Biphasic 8h Sleep', detail: '11PM–3AM N3 Slow-Wave replays Bucket A; 3AM–7:30AM REM integrates Bucket B' }
];

const GYM_SPLITS = [
  {
    id: 'split1',
    name: 'Split 1: Upper A (V-Taper Chest + Width + Side Delts)',
    short: 'Upper A',
    options: [
      { id: 's1_o1', num: 1, name: 'Incline Converging Chest Press Machine', muscle: 'Upper Pecs', cue: 'Seated press with handles angled slightly upward', how: 'Set seat so handles align with upper collarbone. Keep scapulae retracted against pad; stop 1-2 reps before failure to zero out CNS axial fatigue.', target: '3 × 8–10 (1–2 RIR)' },
      { id: 's1_o2', num: 2, name: 'Wide-Grip Lat Pulldown (Neutral/Pronated)', muscle: 'Lat Width', cue: 'Overhead cable bar with thigh Stabilization pad', how: 'Drive elbows down toward hips rather than pulling with biceps. Externally stabilized thigh pad prevents lower back shear.', target: '3 × 10–12 (1–2 RIR)' },
      { id: 's1_o3', num: 3, name: 'Seated Cable / Machine Lateral Raise', muscle: 'Side Delts', cue: 'Shoulder abduction machine with padded elbow rests', how: 'Raise elbows to shoulder height in the scapular plane (30° forward). Gives V-taper shoulder width with zero spinal loading.', target: '3 × 12–15 (1–2 RIR)' },
      { id: 's1_o4', num: 4, name: 'Chest-Supported Machine Row', muscle: 'Mid-Back', cue: 'Rowing machine with a padded chest cushion in front', how: 'Bracing your chest against the pad eliminates lower-back erector fatigue so evening 6:00 PM study stays crisp.', target: '3 × 8–10 (1–2 RIR)' },
      { id: 's1_o5', num: 5, name: 'Pec Deck / Seated Machine Fly', muscle: 'Inner/Mid Chest', cue: 'Seated arm-hug machine with vertical handles', how: 'Keep a slight bend in elbows; squeeze smoothly for 1s and control the stretch without overextending shoulders.', target: '2 × 12–15 (1–2 RIR)' },
      { id: 's1_o6', num: 6, name: 'Overhead Cable Tricep Rope Extension', muscle: 'Triceps Long Head', cue: 'High/mid cable pulley with braided rope attachment', how: 'Face away from stack, lock elbows by ears, and extend overhead to stretch the long head.', target: '2 × 12–15 (1–2 RIR)' },
      { id: 's1_o7', num: 7, name: 'Preacher Curl Machine', muscle: 'Biceps Short Head', cue: 'Seated arm pad angled at 45° with rotating handles', how: 'Triceps stay glued to pad, preventing momentum and isolating elbow flexion cleanly.', target: '2 × 10–12 (1–2 RIR)' },
      { id: 's1_o8', num: 8, name: 'Face Pulls (High Pulley Rope)', muscle: 'Rear Delts & Posture', cue: 'Eye-level cable rope pulled toward forehead', how: 'Reverses medical-study desk posture and external-rotates the rotator cuff.', target: '2 × 15 (2 RIR)' }
    ]
  },
  {
    id: 'split2',
    name: 'Split 2: Lower + Abs (Zero-Spine-Fatigue Leg Press & Curls)',
    short: 'Lower + Abs',
    options: [
      { id: 's2_o1', num: 1, name: '45° Seated / Sled Leg Press', muscle: 'Quads & Glutes', cue: 'Angled sled footplate with padded back support', how: 'Replaces heavy barbell squats. Place feet shoulder-width; keep lower back flat against pad to avoid IL-6 cortisol spikes.', target: '3 × 10–12 (2 RIR)' },
      { id: 's2_o2', num: 2, name: 'Seated Leg Curl Machine', muscle: 'Hamstrings', cue: 'Seated machine where ankles tuck *over* a padded roller', how: 'Seated hip flexion pre-stretches the hamstrings for 1.4x hypertrophy vs lying curls with zero spinal compression.', target: '3 × 10–12 (1–2 RIR)' },
      { id: 's2_o3', num: 3, name: 'Seated Leg Extension Machine', muscle: 'Rectus Femoris / Quads', cue: 'Seated machine where shins push *against* lower roller', how: 'Pause 1 second at full knee extension. Pure quad isolation with minimal systemic fatigue.', target: '3 × 12–15 (1–2 RIR)' },
      { id: 's2_o4', num: 4, name: 'Standing / Leg-Press Calf Raise', muscle: 'Gastrocnemius', cue: 'Padded shoulder calf block or toe-press on leg press sled', how: 'Pause 2 seconds at the bottom stretch to eliminate Achilles elastic bounce.', target: '3 × 12–15 (1–2 RIR)' },
      { id: 's2_o5', num: 5, name: 'Seated Hip Adductor / Abductor Machine', muscle: 'Glute Medius & Inner Thigh', cue: 'Seated knee-pad machine that opens or closes legs', how: 'Stabilizes pelvis during long study hours.', target: '2 × 12–15 (2 RIR)' },
      { id: 's2_o6', num: 6, name: 'Cable Kneeling / Machine Ab Crunch', muscle: 'Rectus Abdominis', cue: 'Seated ab crunch machine or high cable rope', how: 'Flex the thoracic spine (ribs toward pelvis) rather than hinging at hips.', target: '3 × 12–15 (1–2 RIR)' },
      { id: 's2_o7', num: 7, name: 'Captain Chair Padded Leg / Knee Raise', muscle: 'Lower Abs', cue: 'Vertical forearm-supported stand with backrest', how: 'Curl pelvis upward at the top to engage lower rectus abdominis.', target: '2 × 12–15 (2 RIR)' },
      { id: 's2_o8', num: 8, name: '45° Back Extension (Bodyweight / Light Plate)', muscle: 'Erector Spinae Mobility', cue: 'Angled hip pad bench for gentle lower-back decompression', how: 'Smooth controlled tempo to restore lumbar blood flow after 6 hours of sitting.', target: '2 × 12 (3 RIR)' }
    ]
  },
  {
    id: 'split3',
    name: 'Split 3: Upper B (3D Shoulders + Arms + Back Thickness)',
    short: 'Upper B',
    options: [
      { id: 's3_o1', num: 1, name: 'Seated Shoulder Press Machine', muscle: 'Anterior/Medial Delts', cue: 'Overhead press machine with high padded backrest', how: 'Back support eliminates core bracing fatigue while building overhead pressing strength.', target: '3 × 8–10 (1–2 RIR)' },
      { id: 's3_o2', num: 2, name: 'Seated Neutral-Grip Cable Row', muscle: 'Lats & Rhomboids', cue: 'Low pulley bench with V-bar or wide neutral handle', how: 'Keep torso upright; pull handle to lower sternum and let scapulae protract slightly on return.', target: '3 × 10–12 (1–2 RIR)' },
      { id: 's3_o3', num: 3, name: 'Incline Dumbbell / Cable Bayesian Curl', muscle: 'Biceps Long Head', cue: '45° bench or low cable with arm trailing behind torso', how: 'Shoulder extension places maximal stretch on the biceps peak.', target: '3 × 10–12 (1–2 RIR)' },
      { id: 's3_o4', num: 4, name: 'Cable V-Bar Tricep Pushdown', muscle: 'Triceps Lateral Head', cue: 'High pulley angled bar pushed down to thighs', how: 'Pin elbows to ribs; only forearms move.', target: '3 × 10–12 (1–2 RIR)' },
      { id: 's3_o5', num: 5, name: 'Reverse Pec Deck (Rear Delt Fly)', muscle: 'Posterior Delts', cue: 'Face the pec-deck pad and sweep arms backward', how: 'Essential counter-posture for tablet/book reading.', target: '3 × 12–15 (1–2 RIR)' },
      { id: 's3_o6', num: 6, name: 'Flat Converging Machine Chest Press', muscle: 'Mid Pecs', cue: 'Horizontal seated press machine', how: 'Controlled 2-second eccentric without bouncing at bottom.', target: '2 × 10–12 (2 RIR)' },
      { id: 's3_o7', num: 7, name: 'Dumbbell / Cable Hammer Curl', muscle: 'Brachialis & Forearms', cue: 'Neutral thumbs-up grip curl', how: 'Thickens upper arm appearance from the front.', target: '2 × 12 (1–2 RIR)' },
      { id: 's3_o8', num: 8, name: 'Assisted Dip / Chin-Up Machine', muscle: 'Upper Body Compound', cue: 'Kneeling counter-weighted platform machine', how: 'Counterweight keeps you strictly in the 1–2 RIR zero-brain-fog zone.', target: '2 × 10 (2 RIR)' }
    ]
  },
  {
    id: 'split4',
    name: 'Split 4: BDNF Zone-2 Cardio + Core (Active Neuro-Recovery)',
    short: 'Zone-2 BDNF',
    options: [
      { id: 's4_o1', num: 1, name: 'Incline Treadmill Brisk Walk (10–12% Incline, 4.8 km/h)', muscle: 'Hippocampal BDNF', cue: 'Treadmill set to steep walk where nasal breathing is still possible', how: 'Maximizes van Dongen 4-hr post-learning BDNF release with zero eccentric muscle damage.', target: '25 mins @ 130–140 BPM' },
      { id: 's4_o2', num: 2, name: 'Recumbent / Upright Stationary Bike (Zone 2)', muscle: 'Aerobic Perfusion', cue: 'Stationary cycle at steady cadence (75–85 RPM)', how: 'Increases cerebral blood flow velocity ahead of 6:00 PM Bucket A/C block.', target: '20 mins steady' },
      { id: 's4_o3', num: 3, name: 'Elliptical Cross-Trainer (Low Impact)', muscle: 'Full Body Blood Flow', cue: 'Zero-impact gliding stride machine', how: 'Flushes lactate and reduces afternoon drowsiness.', target: '20 mins steady' },
      { id: 's4_o4', num: 4, name: 'Thoracic Foam Rolling & Dead-Hang Decompression', muscle: 'Spine Mobility', cue: 'Pull-up bar passive hang + upper-back roller', how: '30-second passive hangs decompress intervertebral discs after morning study.', target: '3 × 30s hang' },
      { id: 's4_o5', num: 5, name: 'Pallof Cable Anti-Rotation Press', muscle: 'Deep Core Obliques', cue: 'Chest-height cable held straight out resisting rotation', how: 'Builds isometric spinal stability.', target: '3 × 12 each side' },
      { id: 's4_o6', num: 6, name: 'McGill Big-3 Core Stability Circuit', muscle: 'Lumbar Shield', cue: 'Modified curl-up, side plank, and bird-dog on mat', how: 'Stuart McGill clinical spine-sparing endurance protocol.', target: '2 rounds' },
      { id: 's4_o7', num: 7, name: 'Face Pull + External Shoulder Rotation', muscle: 'Cervical Posture', cue: 'Light cable band work for neck/shoulder relief', how: 'Eliminates tension headaches during GT prep.', target: '2 × 15' },
      { id: 's4_o8', num: 8, name: 'Box Breathing (4-4-4-4 Parasympathetic Reset)', muscle: 'Vagal Tone', cue: 'Seated post-cardio nasal breathing cooldown', how: 'Transitions nervous system from sympathetic exercise to calm focused alpha waves.', target: '5 mins' }
    ]
  }
];

// ============================================================================
// 2. DATE, 4-VS-5 REVISION TRACKER & PHYSICAL 20TH NOTEBOOK ELIGIBILITY ENGINE
// ============================================================================
const TODAY_DEFAULT = '2026-11-09';
const EXAM_DATE = '2027-05-20';

function parseDateStr(str) {
  const [y, m, d] = (str || TODAY_DEFAULT).split('-').map(Number);
  return new Date(y, m - 1, d, 12, 0, 0);
}

function formatDateStr(dateObj) {
  const y = dateObj.getFullYear();
  const m = String(dateObj.getMonth() + 1).padStart(2, '0');
  const d = String(dateObj.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function addDaysStr(dateStr, days) {
  const d = parseDateStr(dateStr);
  d.setDate(d.getDate() + days);
  return formatDateStr(d);
}

function isSundayStr(dateStr) {
  return parseDateStr(dateStr).getDay() === 0;
}

function addDaysSkippingSundays(dateStr, daysToAdd) {
  let curr = parseDateStr(dateStr);
  let remaining = Math.max(1, Math.round(daysToAdd));
  while (remaining > 0) {
    curr.setDate(curr.getDate() + 1);
    if (curr.getDay() !== 0) {
      remaining--;
    }
  }
  return formatDateStr(curr);
}

function diffDays(dateStr1, dateStr2) {
  const d1 = parseDateStr(dateStr1);
  const d2 = parseDateStr(dateStr2);
  return Math.round((d2 - d1) / (1000 * 60 * 60 * 24));
}

function formatHumanDate(dateStr, opts = { weekday: 'short', month: 'short', day: 'numeric' }) {
  return parseDateStr(dateStr).toLocaleDateString('en-US', opts);
}

// Determine whether a topic requires 4 Revisions (Normal) or 5 Revisions (Weak / Bucket A Volatile) by May 20, 2027
function getTopicRevisionTarget(topic, subjectStatsMap) {
  const subjStat = subjectStatsMap?.[topic.subject];
  const isSubjectWeakGT = subjStat && subjStat.gtAccuracy < 68;
  const isTopicLowAccuracy = topic.lastAccuracy !== null && topic.lastAccuracy < 75;
  const isLowConfidence = (topic.confidenceRating || 4) <= 2;
  const isBucketA = topic.bucket === 'A';

  const requiresFiveRevisions = isBucketA || isSubjectWeakGT || isTopicLowAccuracy || isLowConfidence;
  // Flag for Physical 20th Notebook if by 2nd revision (stageIndex >= 1) accuracy < 75% or confidence <= 2 or flagged manually
  const eligibleForPhysical20th =
    topic.inPhysical20th ||
    ((topic.stageIndex || 0) >= 1 && (isTopicLowAccuracy || isLowConfidence)) ||
    (topic.lastAccuracy !== null && topic.lastAccuracy < 68);

  return {
    targetRevisions: requiresFiveRevisions ? 5 : 4,
    completedRevisions: Math.min(requiresFiveRevisions ? 5 : 4, (topic.stageIndex || 0) + (topic.lastAccuracy !== null ? 1 : 0)),
    requiresFiveRevisions,
    eligibleForPhysical20th,
    reason: isTopicLowAccuracy
      ? `Low Rev Accuracy (${topic.lastAccuracy}%)`
      : isLowConfidence
      ? `Low Recall Confidence (${topic.confidenceRating}★)`
      : isSubjectWeakGT
      ? `Weak Subject GT (<68%)`
      : isBucketA
      ? 'Bucket A Volatile (5-Rev Track)'
      : '4-Rev Mastery Track'
  };
}

// 3-Factor Adaptive Spaced Repetition Calculator
function computeThreeFactorInterval({
  subjectObj,
  currentStageIndex,
  accuracyPct,
  confidenceRating = 4,
  avgSecPerMcq = 42,
  subjectStatsMap = {},
  itemType = 'topic',
  gotCorrect = true
}) {
  const bucketIntervals = BUCKET_CONFIG[subjectObj.bucket]?.intervals || [1, 7, 21, 45];
  const maxStage = bucketIntervals.length - 1;

  let nextStage = currentStageIndex;
  let baseDays = bucketIntervals[currentStageIndex] || 3;
  let reasonTags = [`Bucket ${subjectObj.bucket}`];

  if (itemType === 'bookmark' || itemType === 'pearl') {
    const bmIntervals = subjectObj.bucket === 'A'
      ? [2, 5, 11, 22, 40]
      : subjectObj.bucket === 'C'
      ? [2, 6, 14, 28, 45]
      : [3, 7, 16, 32, 50];

    if (!gotCorrect) {
      nextStage = 0;
      baseDays = bmIntervals[0];
      reasonTags.push('Missed → Re-Consolidation Loop');
    } else {
      nextStage = Math.min(bmIntervals.length - 1, currentStageIndex + 1);
      baseDays = bmIntervals[nextStage];
      reasonTags.push(`Stage ${nextStage + 1} Advance`);
    }
  } else {
    if (accuracyPct < 65) {
      nextStage = 1;
      baseDays = bucketIntervals[1] || 3;
      reasonTags.push('<65% Reset');
    } else if (accuracyPct <= 74) {
      nextStage = currentStageIndex;
      baseDays = bucketIntervals[nextStage] || 3;
      reasonTags.push('65–74% Hold Stage');
    } else if (accuracyPct <= 84) {
      nextStage = Math.min(maxStage, currentStageIndex + 1);
      baseDays = bucketIntervals[nextStage];
      reasonTags.push('75–84% Target Advance');
    } else {
      nextStage = Math.min(maxStage, currentStageIndex + 1);
      baseDays = bucketIntervals[nextStage] * 1.15;
      reasonTags.push('≥85% AIIMS Mastery (1.15×)');
    }
  }

  const weightMult = subjectObj.weightageMultiplier || 0.90;
  if (accuracyPct < 82 || !gotCorrect) {
    baseDays = baseDays * weightMult;
    reasonTags.push(`PYQ Weight (${subjectObj.pyqWeightage}% → ${weightMult}×)`);
  }

  const subjStat = subjectStatsMap?.[subjectObj.name];
  if (subjStat && subjStat.gtAccuracy < 68) {
    baseDays = baseDays * 0.8;
    reasonTags.push('⚡0.8× GT Weak-Subj');
  }
  if (confidenceRating <= 2) {
    baseDays = baseDays * 0.75;
    reasonTags.push('Low Confidence (0.75×)');
  } else if (confidenceRating === 5 && gotCorrect && accuracyPct >= 85) {
    baseDays = baseDays * 1.08;
  }
  if (avgSecPerMcq > 65) {
    baseDays = baseDays * 0.88;
    reasonTags.push('Slow Speed >65s (0.88×)');
  }

  const finalDays = Math.max(1, Math.round(baseDays));
  return {
    nextStage,
    intervalDays: finalDays,
    formulaSummary: reasonTags.join(' • ')
  };
}

function scheduleOptimalDate(targetDateStr, minDateStr, existingTopics, excludeTopicId = null, maxCapPerDay = 3) {
  const offsets = [0, 1, -1, 2, -2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
  const minBound = addDaysStr(minDateStr, 1);

  const countOnDate = (dStr) =>
    existingTopics.filter(t => t.id !== excludeTopicId && t.status !== 'completed' && t.nextReviewDate === dStr).length;

  for (const offset of offsets) {
    const candidate = addDaysStr(targetDateStr, offset);
    if (candidate < minBound) continue;
    if (isSundayStr(candidate)) continue;
    const load = countOnDate(candidate);
    if (load < maxCapPerDay) {
      let note = '';
      if (offset === 0) {
        note = 'Exact target interval';
      } else if (isSundayStr(targetDateStr)) {
        note = `Skipped Sunday GT (${offset > 0 ? `+${offset}d` : `${offset}d`})`;
      } else {
        note = `Load-Balanced (${offset > 0 ? `+${offset}d` : `${offset}d`}) to fit daily MCQ review cap`;
      }
      return { date: candidate, note, shifted: offset !== 0 };
    }
  }
  let fallback = addDaysStr(targetDateStr, 1);
  while (isSundayStr(fallback) || fallback < minBound) {
    fallback = addDaysStr(fallback, 1);
  }
  return { date: fallback, note: 'Overflow routed to next weekday', shifted: true };
}

// ============================================================================
// 3. DEFAULT ZERO-STATE & RICH SAMPLE DATA GENERATOR
// ============================================================================
function buildInitialSubjectStats() {
  const stats = {};
  SUBJECTS_DB.forEach(s => {
    stats[s.name] = {
      gtAccuracy: 74,
      moduleAvg: 82,
      pyqStrikeRate: 78,
      avgTimeSec: 44
    };
  });
  return stats;
}

function buildZeroState() {
  return {
    topics: [],
    bookmarks: [],
    notebookPearls: [],
    gtList: [],
    physioLogs: {},
    customSubheadings: {},
    subjectStats: buildInitialSubjectStats(),
    gymLogs: [],
    bodyWeightLogs: [],
    targetBodyWeight: 74,
    freehandScheduleBlocks: [],
    splitMcqBlocks: {}, // Keyed by dateStr: { partAYesterdayPmTopic, partADone, partAQCount, partAAccuracy, partBTodayAmTopic, partBDone, partBQCount, partBAccuracy }
    physical20thStartDate: '2027-01-01',
    physical20thDailyLogs: {},
    pacingMode: 'balanced', // 'deep' (2 topics/AM, 50 PM Qs) | 'balanced' (3 topics/AM, 80 PM Qs) | 'sprint' (6 topics/day)
    customSolveSecPerMcq: 45,
    customReviewSecPerWrong: 120,
    customExpectedAccuracyPct: 75
  };
}

function buildSampleData() {
  const baseStats = buildInitialSubjectStats();
  baseStats['Biochemistry'] = { gtAccuracy: 61, moduleAvg: 78, pyqStrikeRate: 68, avgTimeSec: 52 };
  baseStats['Pharmacology'] = { gtAccuracy: 64, moduleAvg: 79, pyqStrikeRate: 71, avgTimeSec: 49 };
  baseStats['Anatomy'] = { gtAccuracy: 65, moduleAvg: 76, pyqStrikeRate: 66, avgTimeSec: 58 };
  baseStats['Microbiology'] = { gtAccuracy: 66, moduleAvg: 80, pyqStrikeRate: 72, avgTimeSec: 46 };
  baseStats['Integrated CVS'] = { gtAccuracy: 84, moduleAvg: 89, pyqStrikeRate: 88, avgTimeSec: 38 };
  baseStats['General Medicine'] = { gtAccuracy: 81, moduleAvg: 87, pyqStrikeRate: 85, avgTimeSec: 41 };
  baseStats['Integrated Renal'] = { gtAccuracy: 79, moduleAvg: 85, pyqStrikeRate: 83, avgTimeSec: 42 };
  baseStats['Radiology'] = { gtAccuracy: 77, moduleAvg: 84, pyqStrikeRate: 81, avgTimeSec: 36 };

  const sampleTopics = [
    // Overdue Backlog + Low Retention by 2nd Revision (Auto-flagged for Physical 20th Notebook!)
    {
      id: 'top_backlog_1',
      subject: 'Biochemistry',
      subheading: 'Rate-Limiting Enzymes of Glycolysis, TCA, Urea & Heme Synthesis',
      bucket: 'A',
      organSystem: 'gi',
      studyDate: '2026-10-28',
      nextReviewDate: '2026-11-06',
      stageIndex: 2, // Reached 2nd revision
      intervalDays: 3,
      lastAccuracy: 62, // Low accuracy at 2nd revision -> Auto-flagged for Physical 20th Notebook!
      confidenceRating: 2,
      avgSecPerMcq: 56,
      pyqWeightage: 6.5,
      inPhysical20th: true,
      writtenInPhysicalCopy: false,
      schedulerNote: 'Rev 2 Low Accuracy (62%) → Flagged for Physical 20th Notebook + 5-Rev Track',
      history: [
        { date: '2026-10-29', accuracy: 74, note: 'Rev 1 (2:30 PM Split Block)' },
        { date: '2026-11-02', accuracy: 62, note: 'Rev 2 Concept Leak → Physical 20th NB' }
      ]
    },
    {
      id: 'top_backlog_2',
      subject: 'Integrated Renal',
      subheading: 'RTA Types 1, 2, 4 & Winter Formula Acid-Base ABG',
      bucket: 'B',
      organSystem: 'renal',
      studyDate: '2026-10-30',
      nextReviewDate: '2026-11-07',
      stageIndex: 1,
      intervalDays: 7,
      lastAccuracy: 71, // <75% at Rev 2 -> Flagged for Physical 20th Notebook
      confidenceRating: 2,
      avgSecPerMcq: 48,
      pyqWeightage: 7.5,
      inPhysical20th: true,
      writtenInPhysicalCopy: true,
      schedulerNote: 'Overdue Backlog • Integrated System • Written in Physical 20th NB ✓',
      history: []
    },
    // Today's Scheduled Topics (2026-11-09)
    {
      id: 'top_1',
      subject: 'Integrated CVS',
      subheading: 'Valvular Heart Disease & Murmur Hemodynamic Maneuvers',
      bucket: 'B',
      organSystem: 'cvs',
      studyDate: '2026-11-01',
      nextReviewDate: '2026-11-09',
      stageIndex: 2,
      intervalDays: 7,
      lastAccuracy: 88,
      confidenceRating: 5,
      avgSecPerMcq: 38,
      pyqWeightage: 9.5,
      inPhysical20th: false,
      writtenInPhysicalCopy: false,
      schedulerNote: 'Bucket B (4-Rev Track) • ≥85% AIIMS Mastery • PYQ 9.5%',
      history: [{ date: '2026-11-02', accuracy: 88, note: 'AIIMS Mastery (1.15x)' }]
    },
    {
      id: 'top_2',
      subject: 'Pharmacology',
      subheading: 'Antiarrhythmics (Vaughan-Williams), Antihypertensives & Heart Failure Drugs',
      bucket: 'A',
      organSystem: 'cvs',
      studyDate: '2026-11-05',
      nextReviewDate: '2026-11-09',
      stageIndex: 1,
      intervalDays: 3,
      lastAccuracy: 69,
      confidenceRating: 2,
      avgSecPerMcq: 49,
      pyqWeightage: 8.5,
      inPhysical20th: true,
      writtenInPhysicalCopy: false,
      schedulerNote: 'Bucket A (5-Rev Weak Track) • Low Recall at Rev 2 → Add to Physical 20th NB',
      history: [{ date: '2026-11-06', accuracy: 69, note: 'Concept Leak at Rev 2' }]
    },
    {
      id: 'top_3',
      subject: 'Radiology',
      subheading: 'Chest X-Ray Signs (Silhouette, Air Bronchogram, Golden S, Batwing)',
      bucket: 'C',
      organSystem: 'resp',
      studyDate: '2026-11-03',
      nextReviewDate: '2026-11-09',
      stageIndex: 1,
      intervalDays: 5,
      lastAccuracy: 84,
      confidenceRating: 4,
      avgSecPerMcq: 35,
      pyqWeightage: 4.5,
      inPhysical20th: false,
      writtenInPhysicalCopy: false,
      schedulerNote: 'Bucket C (4-Rev Track) • IBQ Ultra-Yield (4.5%)',
      history: []
    },
    // Upcoming Days
    {
      id: 'top_4',
      subject: 'Biochemistry',
      subheading: 'Glycogen Storage (Von Gierke, Pompe, McArdle) & Lysosomal Storage',
      bucket: 'A',
      organSystem: 'endo',
      studyDate: '2026-11-03',
      nextReviewDate: '2026-11-10',
      stageIndex: 2,
      intervalDays: 6,
      lastAccuracy: 76,
      confidenceRating: 3,
      avgSecPerMcq: 50,
      pyqWeightage: 6.5,
      inPhysical20th: false,
      writtenInPhysicalCopy: false,
      schedulerNote: 'Load-Balanced (+1d) • ⚡0.8× Weak-Subj (5-Rev Track)',
      history: []
    },
    {
      id: 'top_5',
      subject: 'Integrated CNS',
      subheading: 'Brainstem Stroke Syndromes (Wallenberg, Weber, Millard-Gubler)',
      bucket: 'B',
      organSystem: 'cns',
      studyDate: '2026-11-03',
      nextReviewDate: '2026-11-10',
      stageIndex: 1,
      intervalDays: 7,
      lastAccuracy: 91,
      confidenceRating: 5,
      avgSecPerMcq: 39,
      pyqWeightage: 8.5,
      inPhysical20th: false,
      writtenInPhysicalCopy: false,
      schedulerNote: 'Integrated System (4-Rev Track) • PYQ 8.5%',
      history: []
    }
  ];

  const sampleBookmarks = [
    {
      id: 'bm_backlog_1',
      mcqId: 'INI-BIO-2023',
      subject: 'Biochemistry',
      bucket: 'A',
      pyqWeightage: 6.5,
      rule: '2-Strike',
      stageIndex: 0,
      intervalDays: 4,
      strikes: 0,
      missCount: 2, // Missed twice -> Auto-flagged for Physical 20th Notebook!
      writtenInPhysicalCopy: false,
      pearl: 'CPS-I deficiency presents with hyperammonemia WITHOUT elevated urinary orotic acid (distinguishes it from OTC deficiency).',
      addedDate: '2026-11-02',
      dueDate: '2026-11-07',
      status: 'active',
      lastResult: 'Missed 2× by Rev 2 → Transcribe to Physical 20th Notebook!'
    },
    {
      id: 'bm_1',
      mcqId: 'MRW-MED-4821',
      subject: 'Integrated CVS',
      bucket: 'B',
      pyqWeightage: 9.5,
      rule: '1-Strike',
      stageIndex: 0,
      intervalDays: 4,
      strikes: 0,
      missCount: 1,
      writtenInPhysicalCopy: true,
      pearl: 'Hypertrophic Cardiomyopathy (HCM) murmur decreases with squatting/handgrip (increased afterload/preload) and increases with Valsalva.',
      addedDate: '2026-11-04',
      dueDate: '2026-11-09',
      status: 'active',
      lastResult: 'Unlocked after 4-day cool-down • Written in Physical 20th NB ✓'
    },
    {
      id: 'bm_2',
      mcqId: 'INI-PHM-1904',
      subject: 'Pharmacology',
      bucket: 'A',
      pyqWeightage: 8.5,
      rule: '2-Strike',
      stageIndex: 1,
      intervalDays: 5,
      strikes: 1,
      missCount: 0,
      writtenInPhysicalCopy: false,
      pearl: 'Eplerenone is a selective aldosterone receptor antagonist devoid of gynecomastia side effect seen with Spironolactone.',
      addedDate: '2026-11-04',
      dueDate: '2026-11-09',
      status: 'active',
      lastResult: 'Solved 4th Day ✓ → In Spaced Verification'
    }
  ];

  const samplePearls = [
    {
      id: 'prl_1',
      pearlCode: 'PEARL-BIO-102',
      linkedMcqIds: ['MRW-BIO-1029', 'INICET-2024-Q14', 'AIIMS-2022-Q88'],
      mcqPrompt: 'A 4-month-old infant presents with severe hypotonia, macroglossia, and massive cardiomegaly on CXR. Muscle biopsy shows PAS-positive lysosomal glycogen accumulation. Which enzyme is deficient?',
      mcqAnswer: 'Alpha-1,4-glucosidase (Acid Maltase — Pompe Disease / GSD Type II)',
      subject: 'Biochemistry',
      bucket: 'A',
      pyqWeightage: 6.5,
      pyqAskCount5Yr: 6,
      pearl: 'Pompe Disease (GSD Type II) is the ONLY lysosomal glycogen storage disease (Alpha-1,4-glucosidase / acid maltase deficiency) causing massive cardiomegaly.',
      stageIndex: 1,
      maxStage: 4,
      missCount: 1, // Poorly retained at Rev 2 -> Flagged for Physical 20th NB
      writtenInPhysicalCopy: false,
      intervalDays: 3,
      addedDate: '2026-11-04',
      dueDate: '2026-11-07',
      status: 'active',
      lastReviewed: '2026-11-04'
    },
    {
      id: 'prl_2',
      pearlCode: 'PEARL-REN-408',
      linkedMcqIds: ['INI-REN-8821', 'INICET-2025-Q42'],
      mcqPrompt: 'A 58-year-old diabetic patient has serum K+ 5.9 mEq/L, HCO3- 17 mEq/L, Cl- 112 mEq/L, and urine pH 5.1. What is the primary tubular defect?',
      mcqAnswer: 'Type 4 RTA (Hyporeninemic Hypoaldosteronism in Diabetic Nephropathy)',
      subject: 'Integrated Renal',
      bucket: 'B',
      pyqWeightage: 7.5,
      pyqAskCount5Yr: 5,
      pearl: 'Type 4 RTA presents with hyperkalemic normal-anion-gap metabolic acidosis and aciduria (Urine pH < 5.5) due to aldosterone resistance/deficiency.',
      stageIndex: 1,
      maxStage: 4,
      missCount: 1,
      writtenInPhysicalCopy: true,
      intervalDays: 5,
      addedDate: '2026-11-04',
      dueDate: '2026-11-09',
      status: 'active',
      lastReviewed: '2026-11-04'
    },
    {
      id: 'prl_3',
      pearlCode: 'PEARL-CVS-901',
      linkedMcqIds: ['INICET-2023-Q09', 'MRW-CVS-3312'],
      mcqPrompt: 'A patient with constrictive pericarditis vs restrictive cardiomyopathy undergoes cardiac catheterization. Which sign specifically favors constrictive pericarditis?',
      mcqAnswer: 'Ventricular interdependence (discordant RV and LV systolic pressure peaks during respiration) + rapid y-descent (Friedreich sign)',
      subject: 'Integrated CVS',
      bucket: 'B',
      pyqWeightage: 9.5,
      pyqAskCount5Yr: 7,
      pearl: 'Ventricular interdependence on catheterization is the gold-standard discriminator for Constrictive Pericarditis over Restrictive Cardiomyopathy.',
      stageIndex: 2,
      maxStage: 4,
      missCount: 0,
      writtenInPhysicalCopy: false,
      intervalDays: 12,
      addedDate: '2026-11-02',
      dueDate: '2026-11-14',
      status: 'active',
      lastReviewed: '2026-11-02'
    }
  ];

  const sampleGTs = [
    { id: 'gt_1', name: 'INI-CET Mock GT #1', date: '2026-10-11', correct: 132, wrong: 45, unattempted: 23, bleed: 15.0, netScore: 117.0, percentage: 58.5, firstPassAcc: 78, fiftyFiftyConversion: 52, sillyMistakes: 14, conceptGaps: 19, factDecayErrors: 12, avgSecPerMcq: 51 },
    { id: 'gt_2', name: 'INI-CET Mock GT #2', date: '2026-10-18', correct: 141, wrong: 39, unattempted: 20, bleed: 13.0, netScore: 128.0, percentage: 64.0, firstPassAcc: 81, fiftyFiftyConversion: 58, sillyMistakes: 11, conceptGaps: 16, factDecayErrors: 12, avgSecPerMcq: 48 },
    { id: 'gt_3', name: 'INI-CET Mock GT #3', date: '2026-10-25', correct: 149, wrong: 33, unattempted: 18, bleed: 11.0, netScore: 138.0, percentage: 69.0, firstPassAcc: 84, fiftyFiftyConversion: 63, sillyMistakes: 9, conceptGaps: 14, factDecayErrors: 10, avgSecPerMcq: 45 },
    { id: 'gt_4', name: 'INI-CET Mock GT #4', date: '2026-11-01', correct: 156, wrong: 27, unattempted: 17, bleed: 9.0, netScore: 147.0, percentage: 73.5, firstPassAcc: 87, fiftyFiftyConversion: 68, sillyMistakes: 7, conceptGaps: 11, factDecayErrors: 9, avgSecPerMcq: 43 },
    { id: 'gt_5', name: 'INI-CET Nov 8 Sunday GT', date: '2026-11-08', correct: 162, wrong: 24, unattempted: 14, bleed: 8.0, netScore: 154.0, percentage: 77.0, firstPassAcc: 90, fiftyFiftyConversion: 74, sillyMistakes: 5, conceptGaps: 10, factDecayErrors: 9, avgSecPerMcq: 40 }
  ];

  const sampleSplitMcq = {
    '2026-11-09': {
      partAYesterdayPmSubject: 'Anatomy',
      partAYesterdayPmTopic: 'Skull Base Foramina & Cranial Nerve Exit Pathways',
      partADone: false,
      partAQCount: 35,
      partAAccuracy: 80,
      partBTodayAmSubject: 'Integrated CVS',
      partBTodayAmTopic: 'Valvular Heart Disease & Murmur Hemodynamic Maneuvers',
      partBDone: false,
      partBQCount: 45,
      partBAccuracy: 86
    }
  };

  return {
    topics: sampleTopics,
    bookmarks: sampleBookmarks,
    notebookPearls: samplePearls,
    gtList: sampleGTs,
    physioLogs: {
      '2026-11-08': ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10', 'p11'],
      '2026-11-09': ['p1', 'p2', 'p3', 'p4', 'p5']
    },
    customSubheadings: {},
    subjectStats: baseStats,
    gymLogs: [
      {
        id: 'gym_1',
        date: '2026-11-06',
        arrivalTime: '16:30',
        durationMins: 44,
        travelMins: 15,
        bodyWeight: 69.8,
        splitId: 'split1',
        splitName: 'Upper A',
        focusStars: 5,
        checklist: { carbSalt: true, rirStop: true, creatineWhey: true },
        exercises: [
          { optionId: 's1_o1', name: 'Incline Converging Chest Press Machine', topWeight: 62.5, topReps: 10, volume: 1875 }
        ]
      }
    ],
    bodyWeightLogs: [
      { date: '2026-10-25', weight: 68.5 },
      { date: '2026-11-06', weight: 69.8 }
    ],
    targetBodyWeight: 74,
    freehandScheduleBlocks: [],
    splitMcqBlocks: sampleSplitMcq,
    physical20thStartDate: '2027-01-01',
    physical20thDailyLogs: {},
    pacingMode: 'balanced',
    customSolveSecPerMcq: 45,
    customReviewSecPerWrong: 120,
    customExpectedAccuracyPct: 75
  };
}

// ============================================================================
// 4. MAIN SAMSUNG ONE UI ANDROID APPLICATION
// ============================================================================
export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [mobileFrame, setMobileFrame] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('calendar'); // 'calendar' | 'pairing' | 'bookmarks' | 'backlogs' | 'analytics' | 'gym'
  const [toast, setToast] = useState(null);

  // Samsung Calendar Specific State
  const [calViewMode, setCalViewMode] = useState('split'); // 'month' | 'split' | 'week' | 'schedule'
  const [selectedDate, setSelectedDate] = useState(TODAY_DEFAULT);
  const [currentMonthDate, setCurrentMonthDate] = useState(parseDateStr(TODAY_DEFAULT));
  const [bucketFilter, setBucketFilter] = useState({ A: true, B: true, C: true, bookmarks: true, pearls: true });
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [quickAddTitle, setQuickAddTitle] = useState('');

  // Modals
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [addEventSheetOpen, setAddEventSheetOpen] = useState(false);
  const [graderTopic, setGraderTopic] = useState(null);
  const [graderAccuracy, setGraderAccuracy] = useState(82);
  const [graderConfidence, setGraderConfidence] = useState(4);
  const [graderSpeedSec, setGraderSpeedSec] = useState(42);
  const [graderMistakeType, setGraderMistakeType] = useState('none');
  const [customIndexModalOpen, setCustomIndexModalOpen] = useState(false);
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const [monthPickerOpen, setMonthPickerOpen] = useState(false);
  const [pacingModalOpen, setPacingModalOpen] = useState(false);
  const [backupModalOpen, setBackupModalOpen] = useState(false);
  const [restoreJsonInput, setRestoreJsonInput] = useState('');

  // Multi-User Email Isolation
  const [activeEmail, setActiveEmail] = useState('abay@inicet.aiims');
  const [customEmailInput, setCustomEmailInput] = useState('');
  const [savedProfiles, setSavedProfiles] = useState(['abay@inicet.aiims', 'friend@inicet.aiims']);

  // Core Persisted App Data
  const [appData, setAppData] = useState(() => buildZeroState());

  // Tab 1 Quick-Schedule Form State
  const [schedSubject, setSchedSubject] = useState('Integrated CVS');
  const [schedSubheading, setSchedSubheading] = useState('Valvular Heart Disease & Murmur Hemodynamic Maneuvers');
  const [schedCustomText, setSchedCustomText] = useState('');
  const [schedStudyDate, setSchedStudyDate] = useState(TODAY_DEFAULT);
  const [schedCustomOrganSys, setSchedCustomOrganSys] = useState('cvs');

  // Tab 2 Free-Hand Session Builder & 2:30 PM Split MCQ State
  const [s1Filter, setS1Filter] = useState('ALL');
  const [s1Subject, setS1Subject] = useState('Integrated CVS');
  const [s1Subheading, setS1Subheading] = useState('Valvular Heart Disease & Murmur Hemodynamic Maneuvers');
  const [s1FreehandInput, setS1FreehandInput] = useState('');
  const [s1StartTime, setS1StartTime] = useState('10:15');
  const [s1EndTime, setS1EndTime] = useState('13:15');

  const [s2Filter, setS2Filter] = useState('ALL');
  const [s2Subject, setS2Subject] = useState('Pharmacology');
  const [s2Subheading, setS2Subheading] = useState('Antiarrhythmics (Vaughan-Williams), Antihypertensives & Heart Failure Drugs');
  const [s2FreehandInput, setS2FreehandInput] = useState('');
  const [s2StartTime, setS2StartTime] = useState('18:00');
  const [s2EndTime, setS2EndTime] = useState('20:15');

  const [bulkSubject, setBulkSubject] = useState('General Medicine');
  const [bulkSysTag, setBulkSysTag] = useState('cvs');
  const [bulkText, setBulkText] = useState('');
  const [activeExplorerBucket, setActiveExplorerBucket] = useState('INTEGRATED');

  // Tab 3 Cooled Bookmarks, Spaced Pearls & Physical 20th Notebook Sub-View
  const [bmSubView, setBmSubView] = useState('both'); // 'both' | 'bookmarks' | 'pearls' | 'physical20th'
  const [bmMcqId, setBmMcqId] = useState('');
  const [bmSubject, setBmSubject] = useState('Integrated CVS');
  const [bmRule, setBmRule] = useState('2-Strike');
  const [bmPearl, setBmPearl] = useState('');

  // Pearl & Linked MCQ Creator State
  const [pearlSubject, setPearlSubject] = useState('Integrated Renal');
  const [pearlLinkedMcqs, setPearlLinkedMcqs] = useState('');
  const [pearlMcqQuestion, setPearlMcqQuestion] = useState('');
  const [pearlText, setPearlText] = useState('');
  const [pearlPyqFreq, setPearlPyqFreq] = useState(5);
  const [expandedPearlMcq, setExpandedPearlMcq] = useState({});

  // Tab 4 Dynamic Backlogs Filter State
  const [backlogBucketFilter, setBacklogBucketFilter] = useState('ALL');

  // Tab 5 Multi-Parameter GT Logger State
  const [gtName, setGtName] = useState('');
  const [gtDate, setGtDate] = useState('2026-11-08');
  const [gtCorrect, setGtCorrect] = useState(162);
  const [gtWrong, setGtWrong] = useState(24);
  const [gtFirstPassAcc, setGtFirstPassAcc] = useState(90);
  const [gtFiftyFiftyConv, setGtFiftyFiftyConv] = useState(74);
  const [gtSillyMistakes, setGtSillyMistakes] = useState(5);
  const [gtConceptGaps, setGtConceptGaps] = useState(10);
  const [gtAvgSec, setGtAvgSec] = useState(40);

  // Tab 6 Companion Gym Tracker State
  const [gymSubTab, setGymSubTab] = useState('floor');
  const [gymTimerSec, setGymTimerSec] = useState(0);
  const [gymTimerRunning, setGymTimerRunning] = useState(false);
  const [gymDate, setGymDate] = useState(TODAY_DEFAULT);
  const [gymArrival, setGymArrival] = useState('16:30');
  const [gymDurationInput, setGymDurationInput] = useState(42);
  const [gymTravelInput, setGymTravelInput] = useState(15);
  const [gymBodyWeightInput, setGymBodyWeightInput] = useState(70.2);
  const [activeSplitId, setActiveSplitId] = useState('split1');
  const [expandedOptions, setExpandedOptions] = useState({ s1_o1: true, s1_o2: true });
  const [howExpanded, setHowExpanded] = useState({});
  const [optionSets, setOptionSets] = useState({
    s1_o1: [{ weight: 62.5, reps: 10 }, { weight: 62.5, reps: 10 }, { weight: 60, reps: 10 }],
    s1_o2: [{ weight: 57.5, reps: 11 }, { weight: 57.5, reps: 10 }, { weight: 55, reps: 10 }]
  });
  const [gymChecklist, setGymChecklist] = useState({ carbSalt: true, rirStop: true, creatineWhey: true });
  const [gymFocusStars, setGymFocusStars] = useState(5);
  const [selectedOverloadOption, setSelectedOverloadOption] = useState('s1_o1');

  const showToast = (msg, type = 'info') => {
    setToast({ msg, type });
  };

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3500);
    return () => clearTimeout(t);
  }, [toast]);

  const storageKey = useMemo(() => {
    const clean = activeEmail.trim().toLowerCase().replace(/[^a-z0-9]/g, '_');
    return `inicet_2027_samsung_v3_${clean}`;
  }, [activeEmail]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        setAppData({ ...buildZeroState(), ...parsed });
      } else {
        setAppData(buildZeroState());
      }
    } catch (e) {
      setAppData(buildZeroState());
    }
  }, [storageKey]);

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(appData));
    } catch (e) {
      // Sandbox safe
    }
  }, [appData, storageKey]);

  useEffect(() => {
    if (!gymTimerRunning) return;
    const iv = setInterval(() => {
      setGymTimerSec(prev => {
        const next = prev + 1;
        setGymDurationInput(Math.max(1, Math.round(next / 60)));
        return next;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [gymTimerRunning]);

  const activePacingConfig = useMemo(() => {
    return PACING_MODES[appData.pacingMode || 'balanced'] || PACING_MODES.balanced;
  }, [appData.pacingMode]);

  // 1-Click Re-Balance Calendar when switching from 3 topics/day down to 2 topics/day (Deep Explanation Review Mode)
  const handleApplyPacingModeAndRebalance = (newModeId) => {
    const modeConf = PACING_MODES[newModeId] || PACING_MODES.balanced;
    const cap = modeConf.morningTopicCap;

    setAppData(prev => {
      const sorted = [...prev.topics].sort((a, b) => a.nextReviewDate.localeCompare(b.nextReviewDate));
      const placed = [];
      sorted.forEach(topic => {
        if (topic.nextReviewDate < selectedDate) {
          // Keep overdue backlogs in Backlog Index unless user pulls them
          placed.push(topic);
        } else {
          const countOnDay = placed.filter(t => t.nextReviewDate === topic.nextReviewDate).length;
          if (countOnDay < cap && !isSundayStr(topic.nextReviewDate)) {
            placed.push(topic);
          } else {
            const res = scheduleOptimalDate(topic.nextReviewDate, addDaysStr(topic.nextReviewDate, -1), placed, topic.id, cap);
            placed.push({
              ...topic,
              nextReviewDate: res.date,
              schedulerNote: `Re-balanced for ${modeConf.shortBadge} (${res.note})`
            });
          }
        }
      });

      return {
        ...prev,
        pacingMode: newModeId,
        topics: placed
      };
    });

    showToast(`Switched to ${modeConf.name} & auto-rebalanced calendar to max ${cap} morning topics/day!`, 'success');
  };

  const getSubjectObj = (subjName) => SUBJECTS_DB.find(s => s.name === subjName) || SUBJECTS_DB[0];

  const getSubheadingsForSubject = (subjName) => {
    const base = getSubjectObj(subjName).subheadings || [];
    const custom = appData.customSubheadings?.[subjName] || [];
    return [...base, ...custom];
  };

  useEffect(() => {
    const subj = getSubjectObj(schedSubject);
    setSchedCustomOrganSys(subj.defaultSys || 'gen');
    const list = getSubheadingsForSubject(schedSubject);
    if (list.length > 0 && !list.some(item => item.title === schedSubheading)) {
      setSchedSubheading(list[0].title);
    }
  }, [schedSubject, appData.customSubheadings]);

  useEffect(() => {
    const list = getSubheadingsForSubject(s1Subject);
    if (list.length > 0 && !list.some(item => item.title === s1Subheading)) {
      setS1Subheading(list[0].title);
    }
  }, [s1Subject, appData.customSubheadings]);

  useEffect(() => {
    const list = getSubheadingsForSubject(s2Subject);
    if (list.length > 0 && !list.some(item => item.title === s2Subheading)) {
      setS2Subheading(list[0].title);
    }
  }, [s2Subject, appData.customSubheadings]);

  // ============================================================================
  // 5. CORE ACTIONS: 2:30 PM SPLIT MCQ WORKFLOW, 4-VS-5 REVISIONS & PHYSICAL 20TH NB
  // ============================================================================
  const handleLoadSample = () => {
    setAppData(buildSampleData());
    setSelectedDate('2026-11-09');
    setCurrentMonthDate(parseDateStr('2026-11-09'));
    showToast('Loaded Sample Schedule: 2:30 PM Split MCQs, Phase 1 (Dec 31) / Buffer (Jan 15) Runway & Physical 20th NB Curator!', 'success');
  };

  // Zero-Data-Loss Progress Backup & Restore (Guarantees 0% data loss across future upgrades or device changes)
  const handleExportProgressBackup = () => {
    const payload = {
      version: 'INICET_2027_SAMSUNG_V3',
      exportedAt: new Date().toISOString(),
      profileEmail: activeEmail,
      appData
    };
    const jsonStr = JSON.stringify(payload, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `INICET_May2027_Progress_Backup_${activeEmail.split('@')[0]}_${selectedDate}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Downloaded full Progress Backup (.JSON)! Keep this file safe for future upgrades.', 'success');
  };

  const handleImportProgressFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const parsed = JSON.parse(evt.target.result);
        const restoredData = parsed.appData ? parsed.appData : parsed;
        setAppData(prev => ({ ...buildZeroState(), ...prev, ...restoredData }));
        setBackupModalOpen(false);
        showToast('100% Progress Restored from Backup File without losing a single entry!', 'success');
      } catch (err) {
        showToast('Invalid backup JSON file. Please check the file and try again.', 'info');
      }
    };
    reader.readAsText(file);
  };

  const handleRestoreFromText = (e) => {
    e.preventDefault();
    if (!restoreJsonInput.trim()) return;
    try {
      const parsed = JSON.parse(restoreJsonInput.trim());
      const restoredData = parsed.appData ? parsed.appData : parsed;
      setAppData(prev => ({ ...buildZeroState(), ...prev, ...restoredData }));
      setRestoreJsonInput('');
      setBackupModalOpen(false);
      showToast('100% Progress Restored from pasted backup code!', 'success');
    } catch (err) {
      showToast('Invalid JSON format. Please paste the exact backup JSON.', 'info');
    }
  };

  const handleCopyBackupClipboard = () => {
    const payload = JSON.stringify({ version: 'INICET_2027_SAMSUNG_V3', profileEmail: activeEmail, appData });
    try {
      navigator.clipboard.writeText(payload);
      showToast('Copied full progress code to clipboard!', 'success');
    } catch (e) {
      const ta = document.createElement('textarea');
      ta.value = payload;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      showToast('Copied full progress code to clipboard!', 'success');
    }
  };

  const handleResetToZero = () => {
    setAppData(buildZeroState());
    setResetConfirmOpen(false);
    showToast('Reset to clean Zero-State (0 topics, 0 bookmarks, 0 pearls, 0 GTs).', 'info');
  };

  // Schedule Topic into Spaced Repetition
  // NOTE: Because Revision 1 (24-hr check) is now handled inside the 2:30 PM Split MCQ block,
  // newly studied 1st-read topics can jump directly to Stage 1 (Day 3 / Day 5 / Day 7) for their 08:30 AM slot!
  const scheduleTopicEntry = (subjectName, subheadingTitle, studyDateStr, customOrganSys = null, skipDay1ToSplitBlock = false) => {
    const subjObj = getSubjectObj(subjectName);
    const bucket = subjObj.bucket;
    const subList = getSubheadingsForSubject(subjectName);
    const matchedSub = subList.find(s => s.title === subheadingTitle);
    const organSystem = customOrganSys || matchedSub?.sys || subjObj.defaultSys || 'gen';

    const initialStageIndex = skipDay1ToSplitBlock ? 1 : 0;
    const baseGap = BUCKET_CONFIG[bucket].intervals[initialStageIndex] || 3;
    const rawTarget = addDaysStr(studyDateStr, baseGap);
    const scheduled = scheduleOptimalDate(rawTarget, studyDateStr, appData.topics, null, activePacingConfig.morningTopicCap);

    const newTopic = {
      id: 'top_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      subject: subjectName,
      subheading: subheadingTitle,
      bucket,
      organSystem,
      studyDate: studyDateStr,
      nextReviewDate: scheduled.date,
      stageIndex: initialStageIndex,
      intervalDays: baseGap,
      lastAccuracy: skipDay1ToSplitBlock ? 80 : null,
      confidenceRating: 4,
      avgSecPerMcq: 42,
      pyqWeightage: subjObj.pyqWeightage,
      inPhysical20th: false,
      writtenInPhysicalCopy: false,
      schedulerNote: skipDay1ToSplitBlock
        ? `Rev 1 done via 2:30 PM Split MCQs → Scheduled Rev 2 (+${baseGap}d)`
        : `Bucket ${bucket} • PYQ ${subjObj.pyqWeightage}% • ${scheduled.note}`,
      history: skipDay1ToSplitBlock
        ? [{ date: studyDateStr, accuracy: 80, note: 'Rev 1 completed in 2:30 PM Split MCQ Block' }]
        : []
    };

    setAppData(prev => ({
      ...prev,
      topics: [...prev.topics, newTopic]
    }));

    return { newTopic, scheduled };
  };

  const handleQuickScheduleSubmit = (e) => {
    if (e) e.preventDefault();
    const finalSubheading = schedCustomText.trim() || schedSubheading;
    if (!finalSubheading) return;

    const { scheduled } = scheduleTopicEntry(schedSubject, finalSubheading, schedStudyDate, schedCustomOrganSys);
    setSchedCustomText('');
    setAddEventSheetOpen(false);
    setSelectedDate(scheduled.date);
    setCurrentMonthDate(parseDateStr(scheduled.date));
    showToast(`Scheduled "${finalSubheading}" (${schedSubject}) for ${formatHumanDate(scheduled.date)}`, 'success');
  };

  const handleBottomQuickAdd = (e) => {
    e.preventDefault();
    if (!quickAddTitle.trim()) return;
    const targetDay = isSundayStr(selectedDate) ? addDaysStr(selectedDate, 1) : selectedDate;
    const scheduled = scheduleOptimalDate(targetDay, addDaysStr(targetDay, -1), appData.topics);
    const subjObj = getSubjectObj(schedSubject);
    const newTopic = {
      id: 'top_' + Date.now(),
      subject: schedSubject,
      subheading: quickAddTitle.trim(),
      bucket: subjObj.bucket,
      organSystem: subjObj.defaultSys,
      studyDate: selectedDate,
      nextReviewDate: scheduled.date,
      stageIndex: 0,
      intervalDays: 1,
      lastAccuracy: null,
      confidenceRating: 4,
      avgSecPerMcq: 42,
      pyqWeightage: subjObj.pyqWeightage,
      inPhysical20th: false,
      writtenInPhysicalCopy: false,
      schedulerNote: `Free-Hand Quick Add • PYQ ${subjObj.pyqWeightage}%`,
      history: []
    };
    setAppData(prev => ({ ...prev, topics: [...prev.topics, newTopic] }));
    setQuickAddTitle('');
    showToast(`Added "${newTopic.subheading}" on ${formatHumanDate(scheduled.date)}`, 'success');
  };

  const handleDominoShift = () => {
    setAppData(prev => {
      const shiftedTopics = prev.topics.map(t => {
        if (t.status === 'completed') return t;
        return {
          ...t,
          nextReviewDate: addDaysSkippingSundays(t.nextReviewDate, 1),
          schedulerNote: 'Domino Shifted (+1d, Sunday-safe)'
        };
      });
      const shiftedBookmarks = prev.bookmarks.map(b => {
        if (b.status !== 'active') return b;
        return {
          ...b,
          dueDate: addDaysSkippingSundays(b.dueDate, 1)
        };
      });
      const shiftedPearls = prev.notebookPearls.map(p => {
        if (p.status === 'mastered') return p;
        return {
          ...p,
          dueDate: addDaysSkippingSundays(p.dueDate || selectedDate, 1)
        };
      });
      return {
        ...prev,
        topics: shiftedTopics,
        bookmarks: shiftedBookmarks,
        notebookPearls: shiftedPearls
      };
    });
    showToast('1-Click Domino Shift: All topics, bookmarks & pearls shifted +1 day (skipping Sunday)!', 'success');
  };

  // Multi-Parameter Grader with Auto-Detection for Physical 20th Notebook at 2nd Revision!
  const handleGradeSubmit = () => {
    if (!graderTopic) return;
    const acc = Number(graderAccuracy);
    const subjObj = getSubjectObj(graderTopic.subject);

    const calc = computeThreeFactorInterval({
      subjectObj: subjObj,
      currentStageIndex: graderTopic.stageIndex,
      accuracyPct: acc,
      confidenceRating: graderConfidence,
      avgSecPerMcq: graderSpeedSec,
      subjectStatsMap: appData.subjectStats,
      itemType: 'topic',
      gotCorrect: acc >= 65
    });

    // Check if by 2nd Revision (stageIndex >= 1) accuracy is <75% or confidence <= 2 -> Auto-add to Physical 20th Notebook!
    const isSecondRevOrLater = (graderTopic.stageIndex || 0) >= 1;
    const isPoorlyRetained = acc < 75 || graderConfidence <= 2;
    const shouldFlagFor20th = graderTopic.inPhysical20th || (isSecondRevOrLater && isPoorlyRetained) || acc < 65;

    const targetDate = addDaysStr(selectedDate, calc.intervalDays);
    const scheduled = scheduleOptimalDate(targetDate, selectedDate, appData.topics, graderTopic.id, activePacingConfig.morningTopicCap);

    setAppData(prev => ({
      ...prev,
      topics: prev.topics.map(t => {
        if (t.id !== graderTopic.id) return t;
        return {
          ...t,
          stageIndex: calc.nextStage,
          intervalDays: calc.intervalDays,
          lastAccuracy: acc,
          confidenceRating: graderConfidence,
          avgSecPerMcq: graderSpeedSec,
          lastMistakeType: graderMistakeType,
          inPhysical20th: shouldFlagFor20th,
          nextReviewDate: scheduled.date,
          schedulerNote: `${calc.formulaSummary}${shouldFlagFor20th ? ' • 📓 Added to Physical 20th NB' : ''} • ${scheduled.note}`,
          history: [
            ...(t.history || []),
            {
              date: selectedDate,
              accuracy: acc,
              confidence: graderConfidence,
              speedSec: graderSpeedSec,
              nextDate: scheduled.date,
              note: calc.formulaSummary
            }
          ]
        };
      })
    }));

    setGraderTopic(null);
    if (shouldFlagFor20th) {
      showToast(`Graded ${acc}% → Flagged for Physical 20th Notebook (low retention by Rev 2) & switched to 5-Revision Track!`, 'info');
    } else {
      showToast(`Graded ${acc}% (${graderSpeedSec}s/Q, ${graderConfidence}★) → Next review on ${formatHumanDate(scheduled.date)} (${calc.intervalDays}d gap)`, 'success');
    }
  };

  const handleDeleteTopic = (topicId) => {
    setAppData(prev => ({
      ...prev,
      topics: prev.topics.filter(t => t.id !== topicId)
    }));
    showToast('Removed topic from calendar.', 'info');
  };

  // Toggle "Written in Physical 20th Notebook Copy" status across Topics, Bookmarks & Pearls
  const toggleWrittenInPhysical20th = (kind, id) => {
    setAppData(prev => {
      if (kind === 'topic') {
        return {
          ...prev,
          topics: prev.topics.map(t =>
            t.id === id ? { ...t, inPhysical20th: true, writtenInPhysicalCopy: !t.writtenInPhysicalCopy } : t
          )
        };
      }
      if (kind === 'bookmark') {
        return {
          ...prev,
          bookmarks: prev.bookmarks.map(b =>
            b.id === id ? { ...b, writtenInPhysicalCopy: !b.writtenInPhysicalCopy } : b
          )
        };
      }
      return {
        ...prev,
        notebookPearls: prev.notebookPearls.map(p =>
          p.id === id ? { ...p, writtenInPhysicalCopy: !p.writtenInPhysicalCopy } : p
        )
      };
    });
    showToast('Updated Physical 20th Notebook transcription status!', 'success');
  };

  // Complete 2:30 PM Split MCQ Block Part A (Yesterday's Evening Topic = Rev 1!) or Part B (Today's Morning Topic)
  const currentSplitMcq = useMemo(() => {
    const saved = appData.splitMcqBlocks?.[selectedDate];
    if (saved) return saved;
    return {
      partAYesterdayPmSubject: s2Subject,
      partAYesterdayPmTopic: s2FreehandInput.trim() || s2Subheading,
      partADone: false,
      partAQCount: activePacingConfig.partAYesterdayQs,
      partAAccuracy: 80,
      partBTodayAmSubject: s1Subject,
      partBTodayAmTopic: s1FreehandInput.trim() || s1Subheading,
      partBDone: false,
      partBQCount: activePacingConfig.partBTodayQs,
      partBAccuracy: 84
    };
  }, [appData.splitMcqBlocks, selectedDate, s1Subject, s1Subheading, s1FreehandInput, s2Subject, s2Subheading, s2FreehandInput]);

  const handleCompleteSplitMcqHalf = (half) => {
    const block = currentSplitMcq;
    if (half === 'partA') {
      // Completing Part A (2:30 - 3:15 PM Yesterday's Evening Topic MCQs) automatically logs Revision 1 and schedules Revision 2 in the 08:30 AM Calendar!
      const { scheduled } = scheduleTopicEntry(
        block.partAYesterdayPmSubject,
        block.partAYesterdayPmTopic,
        selectedDate,
        null,
        true // skipDay1ToSplitBlock = true (jumps straight to Rev 2!)
      );
      setAppData(prev => ({
        ...prev,
        splitMcqBlocks: {
          ...(prev.splitMcqBlocks || {}),
          [selectedDate]: { ...block, partADone: true }
        }
      }));
      showToast(`2:30 PM Part A Complete! Yesterday's PM topic (${block.partAYesterdayPmSubject}) finished Rev 1 & scheduled Rev 2 on ${formatHumanDate(scheduled.date)}!`, 'success');
    } else {
      // Completing Part B (3:15 - 4:15 PM Today's Morning Topic MCQs) logs Rev 1 for Today's Morning Topic and schedules Rev 2!
      const { scheduled } = scheduleTopicEntry(
        block.partBTodayAmSubject,
        block.partBTodayAmTopic,
        selectedDate,
        null,
        true
      );
      setAppData(prev => ({
        ...prev,
        splitMcqBlocks: {
          ...(prev.splitMcqBlocks || {}),
          [selectedDate]: { ...block, partBDone: true }
        }
      }));
      showToast(`3:15 PM Part B Complete! Today's AM topic (${block.partBTodayAmSubject}) MCQs solved & scheduled Rev 2 on ${formatHumanDate(scheduled.date)}!`, 'success');
    }
  };

  // ============================================================================
  // 6. TAB 2: FREE-HAND SESSION BUILDER & MEMORY-PHYSIOLOGY PAIRING ADVISOR
  // ============================================================================
  const getFilterPool = (filterCode) => {
    if (filterCode === 'ALL') return SUBJECTS_DB;
    if (filterCode === 'INTEGRATED') return SUBJECTS_DB.filter(s => s.isIntegrated);
    return SUBJECTS_DB.filter(s => s.bucket === filterCode);
  };

  const neuroCompatibility = useMemo(() => {
    const s1Obj = getSubjectObj(s1Subject);
    const s2Obj = getSubjectObj(s2Subject);
    const s1List = getSubheadingsForSubject(s1Subject);
    const s2List = getSubheadingsForSubject(s2Subject);
    const finalS1Sub = s1FreehandInput.trim() || s1Subheading;
    const finalS2Sub = s2FreehandInput.trim() || s2Subheading;
    const sub1 = s1List.find(s => s.title === finalS1Sub);
    const sub2 = s2List.find(s => s.title === finalS2Sub);

    const sys1 = sub1?.sys || s1Obj.defaultSys;
    const sys2 = sub2?.sys || s2Obj.defaultSys;
    const b1 = s1Obj.bucket;
    const b2 = s2Obj.bucket;
    const combinedPyqWeight = Number((s1Obj.pyqWeightage + s2Obj.pyqWeightage).toFixed(1));

    let score = 74;
    let badge = 'Compatible Custom Pairing';
    let tone = 'indigo';
    let isWrongPairing = false;
    let message = `Combined 5–7 Yr INI-CET Weightage: ${combinedPyqWeight}% of exam paper.`;

    if (b1 === 'B' && (b2 === 'A' || b2 === 'C') && sys1 === sys2) {
      score = 98;
      badge = 'Peak Synaptic Co-Activation: 98%';
      tone = 'emerald';
      message = `Optimal Memory Physiology! Morning Conceptual (${s1Subject}) + Evening ${b2 === 'A' ? 'Volatile Fact' : 'Visual IBQ'} (${s2Subject}) co-activates the ${ORGAN_SYSTEMS[sys1]} hippocampal schema from two angles, cutting Day-7 revision effort by ~35%.`;
    } else if ((b1 === 'A' || b1 === 'C') && b2 === 'B' && sys1 === sys2) {
      score = 89;
      badge = 'Same-System Synergy: 89%';
      tone = 'emerald';
      message = `Strong organ-system match (${ORGAN_SYSTEMS[sys1]}). Tip: Swapping ${s2Subject} (Bucket B) to 10:15 AM and ${s1Subject} (Bucket ${b1}) to 6:00 PM raises synergy to 98%.`;
    } else if (b1 === 'B' && b2 === 'B' && sys1 !== sys2) {
      score = 41;
      badge = '⚠️ Wrong Pairing Alert: Prefrontal Overload (41%)';
      tone = 'rose';
      isWrongPairing = true;
      message = `Memory Physiology Warning: Pairing two heavy Bucket B conceptual subjects from unrelated systems (${ORGAN_SYSTEMS[sys1]} + ${ORGAN_SYSTEMS[sys2]}) causes severe prefrontal working-memory saturation. Pick one of the 1-Click Recommended Bucket A/C counterparts below!`;
    } else if (b1 === 'A' && b2 === 'A') {
      score = 45;
      badge = '⚠️ Wrong Pairing Alert: Proactive Interference (45%)';
      tone = 'rose';
      isWrongPairing = true;
      message = `Memory Physiology Warning: Studying two dense rote Bucket A subjects (${s1Subject} + ${s2Subject}) on the same day causes severe associative table interference during Stage N3 slow-wave sleep replay.`;
    } else if (b1 === 'C' && b2 === 'C' && sys1 !== sys2) {
      score = 54;
      badge = '⚠️ Visual Habituation Risk (54%)';
      tone = 'amber';
      isWrongPairing = true;
      message = `Occipital-parietal visual fatigue warning: Pairing two unrelated IBQ subjects back-to-back blurs visual pattern discrimination.`;
    } else if (sys1 === sys2) {
      score = 87;
      badge = 'Shared Organ-System Network: 87%';
      tone = 'emerald';
      message = `Both sessions target ${ORGAN_SYSTEMS[sys1]}, reinforcing shared clinical pathways (Combined INI-CET Weightage: ${combinedPyqWeight}%).`;
    }

    const targetBuckets = b1 === 'B' ? ['A', 'C'] : ['B'];
    const recommendations = [];
    SUBJECTS_DB.forEach(subj => {
      if (targetBuckets.includes(subj.bucket) && subj.name !== s1Subject) {
        const subs = getSubheadingsForSubject(subj.name);
        subs.forEach(sh => {
          if (sh.sys === sys1) {
            recommendations.push({
              subject: subj.name,
              bucket: subj.bucket,
              isIntegrated: subj.isIntegrated,
              pyqWeightage: subj.pyqWeightage,
              subheading: sh.title,
              sys: sh.sys
            });
          }
        });
      }
    });

    recommendations.sort((a, b) => b.pyqWeightage - a.pyqWeightage);

    return {
      score,
      badge,
      tone,
      isWrongPairing,
      message,
      sys1,
      sys2,
      combinedPyqWeight,
      recommendations: recommendations.slice(0, 4)
    };
  }, [s1Subject, s1Subheading, s1FreehandInput, s2Subject, s2Subheading, s2FreehandInput, appData.customSubheadings]);

  const handleScheduleDualPair = () => {
    const finalS1 = s1FreehandInput.trim() || s1Subheading;
    const finalS2 = s2FreehandInput.trim() || s2Subheading;
    if (!finalS1 || !finalS2) return;

    const tomorrowStr = addDaysSkippingSundays(selectedDate, 1);

    setAppData(prev => {
      const updatedCustom = { ...(prev.customSubheadings || {}) };
      if (s1FreehandInput.trim()) {
        const list1 = updatedCustom[s1Subject] || [];
        if (!list1.some(x => x.title === s1FreehandInput.trim())) {
          updatedCustom[s1Subject] = [...list1, { title: s1FreehandInput.trim(), sys: neuroCompatibility.sys1 }];
        }
      }
      if (s2FreehandInput.trim()) {
        const list2 = updatedCustom[s2Subject] || [];
        if (!list2.some(x => x.title === s2FreehandInput.trim())) {
          updatedCustom[s2Subject] = [...list2, { title: s2FreehandInput.trim(), sys: neuroCompatibility.sys2 }];
        }
      }

      // Wire Today's 2:30 PM Part B = Today's Morning Session 1 MCQs
      // Wire Tomorrow's 2:30 PM Part A = Today's Evening Session 2 MCQs (Overnight-Consolidated Day-1 Revision!)
      const todaySplit = prev.splitMcqBlocks?.[selectedDate] || {
        partAYesterdayPmSubject: 'Previous Evening Topic',
        partAYesterdayPmTopic: 'Overnight Consolidated MCQs (35 Qs)',
        partADone: false,
        partAQCount: 35,
        partAAccuracy: 80
      };
      const tomorrowSplit = prev.splitMcqBlocks?.[tomorrowStr] || {
        partBTodayAmSubject: s1Subject,
        partBTodayAmTopic: 'Tomorrow Morning Session 1 MCQs (45 Qs)',
        partBDone: false,
        partBQCount: 45,
        partBAccuracy: 82
      };

      return {
        ...prev,
        customSubheadings: updatedCustom,
        splitMcqBlocks: {
          ...(prev.splitMcqBlocks || {}),
          [selectedDate]: {
            ...todaySplit,
            partBTodayAmSubject: s1Subject,
            partBTodayAmTopic: finalS1,
            partBDone: false,
            partBQCount: 45,
            partBAccuracy: 84
          },
          [tomorrowStr]: {
            ...tomorrowSplit,
            partAYesterdayPmSubject: s2Subject,
            partAYesterdayPmTopic: finalS2,
            partADone: false,
            partAQCount: 35,
            partAAccuracy: 80
          }
        }
      };
    });

    scheduleTopicEntry(s1Subject, finalS1, selectedDate, neuroCompatibility.sys1, true);
    scheduleTopicEntry(s2Subject, finalS2, selectedDate, neuroCompatibility.sys2, true);

    setS1FreehandInput('');
    setS2FreehandInput('');
    showToast(`Scheduled Pair! Today's AM MCQs set for 3:15 PM today, and Tonight's PM MCQs routed to 2:30 PM tomorrow (${formatHumanDate(tomorrowStr)})!`, 'success');
  };

  const handleBulkSubheadingsAdd = (e) => {
    e.preventDefault();
    const lines = bulkText.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length === 0) return;

    const newItems = lines.map(title => ({ title, sys: bulkSysTag }));
    setAppData(prev => ({
      ...prev,
      customSubheadings: {
        ...(prev.customSubheadings || {}),
        [bulkSubject]: [...(prev.customSubheadings?.[bulkSubject] || []), ...newItems]
      }
    }));
    setBulkText('');
    setCustomIndexModalOpen(false);
    showToast(`Added ${lines.length} custom subtopics to ${bulkSubject}!`, 'success');
  };

  const togglePhysioStep = (stepId) => {
    setAppData(prev => {
      const current = prev.physioLogs?.[selectedDate] || [];
      const exists = current.includes(stepId);
      const updated = exists ? current.filter(id => id !== stepId) : [...current, stepId];
      return {
        ...prev,
        physioLogs: {
          ...(prev.physioLogs || {}),
          [selectedDate]: updated
        }
      };
    });
  };

  // ============================================================================
  // 7. TAB 3: BOOKMARKS, PEARLS & PHYSICAL 20TH NOTEBOOK CURATOR
  // ============================================================================
  const handleAddBookmark = (e) => {
    e.preventDefault();
    if (!bmMcqId.trim() || !bmPearl.trim()) return;
    const subjObj = getSubjectObj(bmSubject);
    const dueDate = addDaysSkippingSundays(selectedDate, 4);
    const newBm = {
      id: 'bm_' + Date.now(),
      mcqId: bmMcqId.trim().toUpperCase(),
      subject: bmSubject,
      bucket: subjObj.bucket,
      pyqWeightage: subjObj.pyqWeightage,
      rule: bmRule,
      stageIndex: 0,
      intervalDays: 4,
      strikes: 0,
      missCount: 0,
      writtenInPhysicalCopy: false,
      pearl: bmPearl.trim(),
      addedDate: selectedDate,
      dueDate,
      status: 'active',
      lastResult: 'Locked for 4-Day Episodic Cool-Down'
    };
    setAppData(prev => ({
      ...prev,
      bookmarks: [newBm, ...prev.bookmarks]
    }));
    setBmMcqId('');
    setBmPearl('');
    showToast(`Bookmark ${newBm.mcqId} locked for 4-day cool-down until ${formatHumanDate(dueDate)}`, 'success');
  };

  const handleBookmarkReviewOutcome = (bm, gotCorrect) => {
    const subjObj = getSubjectObj(bm.subject);
    const calc = computeThreeFactorInterval({
      subjectObj: subjObj,
      currentStageIndex: bm.stageIndex || 0,
      accuracyPct: gotCorrect ? 85 : 55,
      confidenceRating: gotCorrect ? 4 : 2,
      avgSecPerMcq: 42,
      subjectStatsMap: appData.subjectStats,
      itemType: 'bookmark',
      gotCorrect
    });

    if (gotCorrect) {
      const nextStrikes = (bm.strikes || 0) + 1;
      const requiredStrikes = bm.rule === '1-Strike' ? 2 : 3;

      if (nextStrikes >= requiredStrikes) {
        setAppData(prev => ({
          ...prev,
          bookmarks: prev.bookmarks.map(item =>
            item.id === bm.id
              ? { ...item, status: 'cleared', strikes: nextStrikes, clearedDate: selectedDate, lastResult: 'Mastered & Cleared ✓' }
              : item
          )
        }));
        showToast(`Mastered & Cleared Bookmark ${bm.mcqId} after ${nextStrikes} spaced verifications!`, 'success');
      } else {
        const nextDue = addDaysSkippingSundays(selectedDate, calc.intervalDays);
        setAppData(prev => ({
          ...prev,
          bookmarks: prev.bookmarks.map(item =>
            item.id === bm.id
              ? {
                  ...item,
                  strikes: nextStrikes,
                  stageIndex: calc.nextStage,
                  intervalDays: calc.intervalDays,
                  dueDate: nextDue,
                  lastResult: `Solved ✓ (Strike ${nextStrikes}/${requiredStrikes}) → +${calc.intervalDays}d (${calc.formulaSummary})`
                }
              : item
          )
        }));
        showToast(`Solved ${bm.mcqId} ✓! Next spaced check in +${calc.intervalDays}d (${formatHumanDate(nextDue)})`, 'success');
      }
    } else {
      const nextDue = addDaysSkippingSundays(selectedDate, calc.intervalDays);
      const newMissCount = (bm.missCount || 0) + 1;

      const autoPearl = {
        id: 'prl_from_' + bm.id + '_' + Date.now(),
        pearlCode: `PEARL-${bm.mcqId}`,
        linkedMcqIds: [bm.mcqId],
        mcqPrompt: `Clinical discriminator test from missed bookmark ${bm.mcqId} (${bm.subject})`,
        mcqAnswer: bm.pearl,
        subject: bm.subject,
        bucket: subjObj.bucket,
        pyqWeightage: subjObj.pyqWeightage,
        pyqAskCount5Yr: Math.max(3, Math.round(subjObj.pyqWeightage * 0.7)),
        pearl: bm.pearl,
        stageIndex: 0,
        maxStage: 4,
        missCount: 1,
        writtenInPhysicalCopy: false,
        intervalDays: calc.intervalDays,
        addedDate: selectedDate,
        dueDate: nextDue,
        status: 'active',
        lastReviewed: selectedDate
      };

      const targetCalDate = addDaysStr(selectedDate, 1);
      const scheduled = scheduleOptimalDate(targetCalDate, selectedDate, appData.topics);
      const injectedTopic = {
        id: 'top_bm_' + Date.now(),
        subject: bm.subject,
        subheading: `[20th NB • Missed ${bm.mcqId}] ${bm.pearl.slice(0, 52)}...`,
        bucket: subjObj.bucket,
        organSystem: subjObj.defaultSys,
        studyDate: selectedDate,
        nextReviewDate: scheduled.date,
        stageIndex: 1,
        intervalDays: calc.intervalDays,
        lastAccuracy: 55,
        confidenceRating: 2,
        avgSecPerMcq: 55,
        pyqWeightage: subjObj.pyqWeightage,
        inPhysical20th: true,
        writtenInPhysicalCopy: false,
        schedulerNote: `Missed Bookmark Loop (#${newMissCount}) → Flagged for Physical 20th Notebook!`,
        history: []
      };

      setAppData(prev => ({
        ...prev,
        bookmarks: prev.bookmarks.map(item =>
          item.id === bm.id
            ? {
                ...item,
                strikes: 0,
                stageIndex: 0,
                missCount: newMissCount,
                intervalDays: calc.intervalDays,
                dueDate: nextDue,
                lastResult: `Missed (#${newMissCount}) → Added to Physical 20th Notebook Write-Queue & +${calc.intervalDays}d Spaced Loop`
              }
            : item
        ),
        notebookPearls: [autoPearl, ...prev.notebookPearls],
        topics: [...prev.topics, injectedTopic]
      }));

      showToast(`Missed ${bm.mcqId}: Flagged for Physical 20th Notebook, added to Pearls Track & re-queued in +${calc.intervalDays}d!`, 'info');
    }
  };

  const handleUnlockBookmarkEarly = (bmId) => {
    setAppData(prev => ({
      ...prev,
      bookmarks: prev.bookmarks.map(item =>
        item.id === bmId ? { ...item, dueDate: selectedDate, lastResult: 'Unlocked early for tonight' } : item
      )
    }));
    showToast('Unlocked bookmark for Tonight review queue.', 'info');
  };

  const handleAddSpacedPearl = (e) => {
    e.preventDefault();
    if (!pearlText.trim()) return;
    const subjObj = getSubjectObj(pearlSubject);
    const mcqList = pearlLinkedMcqs
      .split(',')
      .map(s => s.trim().toUpperCase())
      .filter(Boolean);

    const initialGap = Number(pearlPyqFreq) >= 5 ? 2 : 3;
    const nextDue = addDaysSkippingSundays(selectedDate, initialGap);

    const newPearl = {
      id: 'prl_' + Date.now(),
      pearlCode: `PEARL-${subjObj.name.slice(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 899)}`,
      linkedMcqIds: mcqList.length > 0 ? mcqList : [`INICET-PYQ-${Math.floor(1000 + Math.random() * 8999)}`],
      mcqPrompt: pearlMcqQuestion.trim() || `High-yield INI-CET clinical vignette testing ${subjObj.name} pearl discriminator`,
      mcqAnswer: pearlText.trim(),
      subject: pearlSubject,
      bucket: subjObj.bucket,
      pyqWeightage: subjObj.pyqWeightage,
      pyqAskCount5Yr: Number(pearlPyqFreq) || 4,
      pearl: pearlText.trim(),
      stageIndex: 0,
      maxStage: 4,
      missCount: 0,
      writtenInPhysicalCopy: false,
      intervalDays: initialGap,
      addedDate: selectedDate,
      dueDate: nextDue,
      status: 'active',
      lastReviewed: selectedDate
    };

    setAppData(prev => ({
      ...prev,
      notebookPearls: [newPearl, ...prev.notebookPearls]
    }));

    setPearlText('');
    setPearlLinkedMcqs('');
    setPearlMcqQuestion('');
    showToast(`Added ${newPearl.pearlCode} with ${newPearl.linkedMcqIds.length} linked MCQs → Next review ${formatHumanDate(nextDue)}`, 'success');
  };

  const handlePearlReviewOutcome = (pearlObj, solvedMcqCorrectly) => {
    const subjObj = getSubjectObj(pearlObj.subject);
    const calc = computeThreeFactorInterval({
      subjectObj: subjObj,
      currentStageIndex: pearlObj.stageIndex || 0,
      accuracyPct: solvedMcqCorrectly ? 88 : 55,
      confidenceRating: solvedMcqCorrectly ? 5 : 2,
      avgSecPerMcq: 38,
      subjectStatsMap: appData.subjectStats,
      itemType: 'pearl',
      gotCorrect: solvedMcqCorrectly
    });

    const freqCompress = (pearlObj.pyqAskCount5Yr || 4) >= 5 ? 0.85 : 1.0;
    const adjustedDays = Math.max(1, Math.round(calc.intervalDays * freqCompress));
    const nextDue = addDaysSkippingSundays(selectedDate, adjustedDays);

    const nextStage = solvedMcqCorrectly ? (pearlObj.stageIndex || 0) + 1 : 0;
    const isNowMastered = solvedMcqCorrectly && nextStage >= (pearlObj.maxStage || 4);
    const nextMissCount = solvedMcqCorrectly ? (pearlObj.missCount || 0) : (pearlObj.missCount || 0) + 1;

    setAppData(prev => ({
      ...prev,
      notebookPearls: prev.notebookPearls.map(p => {
        if (p.id !== pearlObj.id) return p;
        return {
          ...p,
          stageIndex: isNowMastered ? p.maxStage : nextStage,
          missCount: nextMissCount,
          intervalDays: adjustedDays,
          dueDate: nextDue,
          status: isNowMastered ? 'mastered' : 'active',
          lastReviewed: selectedDate
        };
      })
    }));

    if (isNowMastered) {
      showToast(`Mastered Pearl ${pearlObj.pearlCode} across all 4 Spaced Repetition stages!`, 'success');
    } else if (solvedMcqCorrectly) {
      showToast(`Pearl & Linked MCQ Solved ✓ (Stage ${nextStage + 1}/4) → Next review in +${adjustedDays}d (${formatHumanDate(nextDue)})`, 'success');
    } else {
      showToast(`Pearl MCQ Missed → Flagged for Physical 20th Notebook & reset to Stage 1 (+${adjustedDays}d)!`, 'info');
    }
  };

  // Curated List of Items Eligible for the Physical 20th Notebook
  // (Every subtopic, bookmark, and pearl with low accuracy / poor retention by 2nd revision)
  const physical20thCuratedList = useMemo(() => {
    const lowRetentionTopics = appData.topics.filter(t => {
      const info = getTopicRevisionTarget(t, appData.subjectStats);
      return info.eligibleForPhysical20th;
    });

    const lowRetentionBookmarks = appData.bookmarks.filter(
      b => (b.missCount || 0) >= 1 || b.writtenInPhysicalCopy
    );

    const lowRetentionPearls = appData.notebookPearls.filter(
      p => (p.missCount || 0) >= 1 || ((p.stageIndex || 0) <= 1 && (p.pyqAskCount5Yr || 4) >= 5) || p.writtenInPhysicalCopy
    );

    return {
      topics: lowRetentionTopics,
      bookmarks: lowRetentionBookmarks,
      pearls: lowRetentionPearls,
      totalEligible: lowRetentionTopics.length + lowRetentionBookmarks.length + lowRetentionPearls.length,
      totalWritten:
        lowRetentionTopics.filter(t => t.writtenInPhysicalCopy).length +
        lowRetentionBookmarks.filter(b => b.writtenInPhysicalCopy).length +
        lowRetentionPearls.filter(p => p.writtenInPhysicalCopy).length
    };
  }, [appData.topics, appData.bookmarks, appData.notebookPearls, appData.subjectStats]);

  // ============================================================================
  // 8. DYNAMIC BACKLOGS ENGINE
  // ============================================================================
  const dynamicBacklogs = useMemo(() => {
    const overdueTopics = appData.topics.filter(
      t => t.status !== 'completed' && t.nextReviewDate < selectedDate
    );
    const overdueBookmarks = appData.bookmarks.filter(
      b => b.status === 'active' && b.dueDate < selectedDate
    );
    const overduePearls = appData.notebookPearls.filter(
      p => p.status !== 'mastered' && (p.dueDate || selectedDate) < selectedDate
    );

    const missedSundays = [];
    for (let i = 1; i <= 21; i++) {
      const dStr = addDaysStr(selectedDate, -i);
      if (isSundayStr(dStr)) {
        const hasGt = appData.gtList.some(g => g.date === dStr);
        if (!hasGt) {
          missedSundays.push({ id: `missed_gt_${dStr}`, date: dStr, title: `Unlogged Sunday GT (${formatHumanDate(dStr)})` });
        }
      }
    }

    return {
      overdueTopics,
      overdueBookmarks,
      overduePearls,
      missedSundays,
      totalCount: overdueTopics.length + overdueBookmarks.length + overduePearls.length + missedSundays.length
    };
  }, [appData.topics, appData.bookmarks, appData.notebookPearls, appData.gtList, selectedDate]);

  const handleCompleteBacklogItem = (type, item) => {
    if (type === 'topic') {
      const subjObj = getSubjectObj(item.subject);
      const calc = computeThreeFactorInterval({
        subjectObj: subjObj,
        currentStageIndex: item.stageIndex || 0,
        accuracyPct: 82,
        confidenceRating: 4,
        avgSecPerMcq: 42,
        subjectStatsMap: appData.subjectStats,
        itemType: 'topic',
        gotCorrect: true
      });
      const targetDate = addDaysStr(selectedDate, calc.intervalDays);
      const scheduled = scheduleOptimalDate(targetDate, selectedDate, appData.topics, item.id);

      setAppData(prev => ({
        ...prev,
        topics: prev.topics.map(t =>
          t.id === item.id
            ? {
                ...t,
                stageIndex: calc.nextStage,
                intervalDays: calc.intervalDays,
                lastAccuracy: 82,
                nextReviewDate: scheduled.date,
                schedulerNote: `Cleared from Backlog ✓ • ${calc.formulaSummary}`
              }
            : t
        )
      }));
      showToast(`Completed Backlog "${item.subheading}"! Removed from Backlogs Index & scheduled next review on ${formatHumanDate(scheduled.date)}.`, 'success');
    } else if (type === 'bookmark') {
      handleBookmarkReviewOutcome(item, true);
    } else if (type === 'pearl') {
      handlePearlReviewOutcome(item, true);
    } else if (type === 'gt') {
      setGtDate(item.date);
      setActiveTab('analytics');
    }
  };

  const handlePullBacklogToToday = (type, item) => {
    if (type === 'topic') {
      setAppData(prev => ({
        ...prev,
        topics: prev.topics.map(t =>
          t.id === item.id ? { ...t, nextReviewDate: selectedDate, schedulerNote: 'Pulled from Backlog into Today Queue' } : t
        )
      }));
      showToast(`Pulled "${item.subheading}" into Today's Queue (${formatHumanDate(selectedDate)})!`, 'info');
    } else if (type === 'bookmark') {
      setAppData(prev => ({
        ...prev,
        bookmarks: prev.bookmarks.map(b =>
          b.id === item.id ? { ...b, dueDate: selectedDate } : b
        )
      }));
      showToast(`Pulled Bookmark ${item.mcqId} into Today's Queue!`, 'info');
    } else if (type === 'pearl') {
      setAppData(prev => ({
        ...prev,
        notebookPearls: prev.notebookPearls.map(p =>
          p.id === item.id ? { ...p, dueDate: selectedDate } : p
        )
      }));
      showToast(`Pulled Pearl ${item.pearlCode} into Today's Queue!`, 'info');
    }
  };

  // ============================================================================
  // 9. TAB 5: MULTI-PARAMETER SUNDAY GT LOGGER & ICS EXPORT
  // ============================================================================
  const handleLogGT = (e) => {
    e.preventDefault();
    const c = Math.min(200, Math.max(0, Number(gtCorrect)));
    const w = Math.min(200 - c, Math.max(0, Number(gtWrong)));
    const unattempted = 200 - c - w;
    const bleed = Number((w / 3).toFixed(2));
    const netScore = Number((c - w / 3).toFixed(2));
    const percentage = Number(((netScore / 200) * 100).toFixed(1));

    const newGt = {
      id: 'gt_' + Date.now(),
      name: gtName.trim() || `Sunday Grand Test (${formatHumanDate(gtDate)})`,
      date: gtDate,
      correct: c,
      wrong: w,
      unattempted,
      bleed,
      netScore,
      percentage,
      firstPassAcc: Number(gtFirstPassAcc) || 85,
      fiftyFiftyConversion: Number(gtFiftyFiftyConv) || 65,
      sillyMistakes: Number(gtSillyMistakes) || 5,
      conceptGaps: Number(gtConceptGaps) || 10,
      avgSecPerMcq: Number(gtAvgSec) || 42
    };

    setAppData(prev => ({
      ...prev,
      gtList: [...prev.gtList.filter(g => g.date !== gtDate), newGt].sort((a, b) => a.date.localeCompare(b.date))
    }));
    setGtName('');
    showToast(`Logged ${newGt.name}: ${netScore}/200 (${percentage}%) | Bleed: -${bleed}`, 'success');
  };

  const updateSubjectStatField = (subjName, field, val) => {
    setAppData(prev => ({
      ...prev,
      subjectStats: {
        ...(prev.subjectStats || {}),
        [subjName]: {
          ...(prev.subjectStats?.[subjName] || { gtAccuracy: 74, moduleAvg: 82, pyqStrikeRate: 78, avgTimeSec: 44 }),
          [field]: Number(val)
        }
      }
    }));
  };

  const openGoogleCalendarBlock = (slotType) => {
    const dClean = selectedDate.replace(/-/g, '');
    const dueTopics = appData.topics.filter(t => t.nextReviewDate === selectedDate);
    const dueBms = appData.bookmarks.filter(b => b.status === 'active' && b.dueDate <= selectedDate);
    const duePearls = appData.notebookPearls.filter(p => p.status !== 'mastered' && (p.dueDate || selectedDate) <= selectedDate);

    let title = '';
    let details = '';
    let startEnd = '';

    if (slotType === 'morning') {
      title = `INI-CET 08:30 AM Active Recall (${dueTopics.length}/3 Topics)`;
      details = dueTopics.length > 0
        ? dueTopics.map((t, i) => `${i + 1}. [${t.subject} • PYQ ${t.pyqWeightage || 7}%] ${t.subheading} (Bucket ${t.bucket})`).join('\n')
        : 'Peak Prefrontal Executive Recall Block (Custom Q-Bank Modules)';
      startEnd = `${dClean}T083000/${dClean}T100000`;
    } else {
      title = `INI-CET 09:00 PM Bookmarks (${dueBms.length}), Pearls (${duePearls.length}) & 30m Physical 20th NB`;
      details = [
        ...dueBms.map(b => `• [MCQ ${b.mcqId}] (${b.subject}): ${b.pearl}`),
        ...duePearls.map(p => `• [${p.pearlCode}] (${p.subject}): ${p.pearl}`)
      ].join('\n') || 'Pre-Sleep Synaptic Tagging: Cooled Bookmarks, Spaced Pearls & 30m Physical 20th Notebook';
      startEnd = `${dClean}T210000/${dClean}T221500`;
    }

    const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${startEnd}&details=${encodeURIComponent(details)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleExportICS = () => {
    const lines = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//INI-CET May 2027 Samsung Neuro Calendar//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH'
    ];

    const groupedByDate = {};
    appData.topics.forEach(t => {
      if (!groupedByDate[t.nextReviewDate]) groupedByDate[t.nextReviewDate] = [];
      groupedByDate[t.nextReviewDate].push(t);
    });

    Object.entries(groupedByDate).forEach(([dStr, list]) => {
      const dClean = dStr.replace(/-/g, '');
      const summary = `INI-CET Morning Recall (${list.length}/3): ${list.map(x => x.subject).join(', ')}`;
      const desc = list.map(x => `[Bucket ${x.bucket}] ${x.subject} - ${x.subheading}`).join('\\n');
      lines.push(
        'BEGIN:VEVENT',
        `UID:inicet-am-${dClean}@aiims.edu`,
        `DTSTART:${dClean}T083000`,
        `DTEND:${dClean}T100000`,
        `SUMMARY:${summary}`,
        `DESCRIPTION:${desc}`,
        'END:VEVENT'
      );
    });

    lines.push('END:VCALENDAR');
    const blob = new Blob([lines.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `INICET_May2027_Samsung_Calendar_${selectedDate}.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported .ICS Calendar file for Samsung Calendar / Google Calendar!', 'success');
  };

  // ============================================================================
  // 10. TAB 6: COMPANION GYM TRACKER ACTIONS
  // ============================================================================
  const activeSplitObj = useMemo(
    () => GYM_SPLITS.find(s => s.id === activeSplitId) || GYM_SPLITS[0],
    [activeSplitId]
  );

  const toggleGymOption = (optId) => {
    setExpandedOptions(prev => ({ ...prev, [optId]: !prev[optId] }));
    if (!optionSets[optId]) {
      setOptionSets(prev => ({
        ...prev,
        [optId]: [{ weight: 40, reps: 10 }, { weight: 40, reps: 10 }]
      }));
    }
  };

  const updateSetField = (optId, idx, field, val) => {
    setOptionSets(prev => {
      const list = [...(prev[optId] || [])];
      list[idx] = { ...list[idx], [field]: Number(val) };
      return { ...prev, [optId]: list };
    });
  };

  const addGymSet = (optId) => {
    setOptionSets(prev => {
      const list = prev[optId] || [];
      const last = list[list.length - 1] || { weight: 40, reps: 10 };
      return { ...prev, [optId]: [...list, { ...last }] };
    });
  };

  const removeGymSet = (optId, idx) => {
    setOptionSets(prev => {
      const list = (prev[optId] || []).filter((_, i) => i !== idx);
      return { ...prev, [optId]: list };
    });
  };

  const handleSaveGymSession = () => {
    const loggedExercises = [];
    activeSplitObj.options.forEach(opt => {
      if (expandedOptions[opt.id] && optionSets[opt.id]?.length > 0) {
        const sets = optionSets[opt.id];
        const topWeight = Math.max(...sets.map(s => Number(s.weight) || 0));
        const topReps = Math.max(...sets.map(s => Number(s.reps) || 0));
        const volume = sets.reduce((acc, s) => acc + (Number(s.weight) || 0) * (Number(s.reps) || 0), 0);
        loggedExercises.push({
          optionId: opt.id,
          name: opt.name,
          topWeight,
          topReps,
          volume,
          sets
        });
      }
    });

    const newSession = {
      id: 'gym_' + Date.now(),
      date: gymDate,
      arrivalTime: gymArrival,
      durationMins: Number(gymDurationInput) || 42,
      travelMins: Number(gymTravelInput) || 15,
      bodyWeight: Number(gymBodyWeightInput) || 70,
      splitId: activeSplitObj.id,
      splitName: activeSplitObj.short,
      focusStars: gymFocusStars,
      checklist: { ...gymChecklist },
      exercises: loggedExercises
    };

    setAppData(prev => {
      const filteredWeights = (prev.bodyWeightLogs || []).filter(w => w.date !== gymDate);
      return {
        ...prev,
        gymLogs: [newSession, ...(prev.gymLogs || [])],
        bodyWeightLogs: [...filteredWeights, { date: gymDate, weight: Number(gymBodyWeightInput) || 70 }].sort((a, b) => a.date.localeCompare(b.date))
      };
    });

    setGymTimerRunning(false);
    showToast(`Saved ${activeSplitObj.short} session (${gymDurationInput}m) & ${gymBodyWeightInput} kg body weight!`, 'success');
  };

  // ============================================================================
  // 11. SAMSUNG CALENDAR MONTH & WEEK GRID COMPUTATIONS
  // ============================================================================
  const calendarMonthCells = useMemo(() => {
    const year = currentMonthDate.getFullYear();
    const month = currentMonthDate.getMonth();
    const firstDayOfMonth = new Date(year, month, 1);
    const startDayOfWeek = firstDayOfMonth.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevMonthDays = new Date(year, month, 0).getDate();

    const cells = [];
    for (let i = startDayOfWeek - 1; i >= 0; i--) {
      const d = new Date(year, month - 1, prevMonthDays - i, 12, 0, 0);
      cells.push({ dateStr: formatDateStr(d), dayNum: d.getDate(), inCurrentMonth: false, dayOfWeek: d.getDay() });
    }
    for (let dNum = 1; dNum <= daysInMonth; dNum++) {
      const d = new Date(year, month, dNum, 12, 0, 0);
      cells.push({ dateStr: formatDateStr(d), dayNum: dNum, inCurrentMonth: true, dayOfWeek: d.getDay() });
    }
    const totalNeeded = cells.length > 35 ? 42 : 35;
    let nextMonthDay = 1;
    while (cells.length < totalNeeded) {
      const d = new Date(year, month + 1, nextMonthDay++, 12, 0, 0);
      cells.push({ dateStr: formatDateStr(d), dayNum: d.getDate(), inCurrentMonth: false, dayOfWeek: d.getDay() });
    }
    return cells;
  }, [currentMonthDate]);

  const calendarWeekCells = useMemo(() => {
    const sel = parseDateStr(selectedDate);
    const dow = sel.getDay();
    const sunday = new Date(sel);
    sunday.setDate(sel.getDate() - dow);

    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(sunday);
      d.setDate(sunday.getDate() + i);
      return {
        dateStr: formatDateStr(d),
        dayNum: d.getDate(),
        dayOfWeek: d.getDay(),
        shortDay: d.toLocaleDateString('en-US', { weekday: 'short' })
      };
    });
  }, [selectedDate]);

  const navigateMonth = (delta) => {
    const next = new Date(currentMonthDate.getFullYear(), currentMonthDate.getMonth() + delta, 1, 12, 0, 0);
    setCurrentMonthDate(next);
  };

  const jumpToToday = () => {
    setSelectedDate(TODAY_DEFAULT);
    setCurrentMonthDate(parseDateStr(TODAY_DEFAULT));
    showToast('Jumped to Today (Nov 9, 2026)', 'info');
  };

  const selectedDayTopics = useMemo(
    () => appData.topics.filter(t => t.nextReviewDate === selectedDate && bucketFilter[t.bucket]),
    [appData.topics, selectedDate, bucketFilter]
  );

  const selectedDayBookmarks = useMemo(
    () => bucketFilter.bookmarks
      ? appData.bookmarks.filter(b => b.status === 'active' && b.dueDate === selectedDate)
      : [],
    [appData.bookmarks, selectedDate, bucketFilter.bookmarks]
  );

  const selectedDayPearls = useMemo(
    () => bucketFilter.pearls
      ? appData.notebookPearls.filter(p => p.status !== 'mastered' && (p.dueDate || selectedDate) === selectedDate)
      : [],
    [appData.notebookPearls, selectedDate, bucketFilter.pearls]
  );

  const selectedDayGT = useMemo(
    () => appData.gtList.find(g => g.date === selectedDate),
    [appData.gtList, selectedDate]
  );

  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return appData.topics.filter(
      t => t.subject.toLowerCase().includes(q) || t.subheading.toLowerCase().includes(q)
    );
  }, [appData.topics, searchQuery]);

  const todayPhysioCompleted = appData.physioLogs?.[selectedDate] || [];
  const physioReadinessPct = Math.round((todayPhysioCompleted.length / PHYSIO_CHECKLIST_STEPS.length) * 100);

  const dueTonightBookmarks = useMemo(
    () => appData.bookmarks.filter(b => b.status === 'active' && b.dueDate <= selectedDate),
    [appData.bookmarks, selectedDate]
  );
  const coolingBookmarks = useMemo(
    () => appData.bookmarks.filter(b => b.status === 'active' && b.dueDate > selectedDate),
    [appData.bookmarks, selectedDate]
  );

  const dueTonightPearls = useMemo(
    () => appData.notebookPearls.filter(p => p.status !== 'mastered' && (p.dueDate || selectedDate) <= selectedDate),
    [appData.notebookPearls, selectedDate]
  );
  const scheduledFuturePearls = useMemo(
    () => appData.notebookPearls.filter(p => p.status !== 'mastered' && (p.dueDate || selectedDate) > selectedDate),
    [appData.notebookPearls, selectedDate]
  );

  const weakSubjectsList = useMemo(
    () => ALL_TWENTY_SIX_NAMES.filter(name => (appData.subjectStats?.[name]?.gtAccuracy ?? 75) < 68),
    [appData.subjectStats]
  );

  // Active Macro Phase for selectedDate
  const activeMacroPhase = useMemo(() => {
    return (
      MACRO_RUNWAY_PHASES.find(p => selectedDate >= p.startDate && selectedDate <= p.endDate) ||
      MACRO_RUNWAY_PHASES[0]
    );
  }, [selectedDate]);

  // ============================================================================
  // 12. RENDER SAMSUNG ONE UI ANDROID SHELL
  // ============================================================================
  return (
    <div className={`${darkMode ? 'dark bg-[#000000] text-[#F4F4F6]' : 'bg-[#F2F2F7] text-[#1C1C1E]'} min-h-screen font-sans antialiased selection:bg-indigo-500 selection:text-white transition-colors duration-200`}>
      <div className={mobileFrame ? 'max-w-[440px] mx-auto my-2 sm:my-6 rounded-[42px] border-[8px] border-neutral-800 dark:border-neutral-700 shadow-2xl overflow-hidden bg-[#F2F2F7] dark:bg-[#000000] min-h-[92vh] flex flex-col relative' : 'max-w-[1440px] mx-auto min-h-screen flex flex-col relative'}>

        {/* Android Status Strip */}
        <div className="px-5 pt-2 pb-1 flex items-center justify-between text-[11px] font-medium text-neutral-500 dark:text-neutral-400 select-none">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-neutral-800 dark:text-neutral-200">08:30</span>
            <span className="hidden sm:inline text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-semibold">
              {activeMacroPhase.badge} • {diffDays(selectedDate, EXAM_DATE)}d to May 20 INI-CET
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setBackupModalOpen(true)}
              className="px-2.5 py-0.5 rounded-full bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-500/25 font-semibold transition flex items-center gap-1"
              title="Backup / Restore Progress Data & Install App Guide"
            >
              <Download className="w-3 h-3" /> Backup & Install
            </button>
            <button
              onClick={handleLoadSample}
              className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/25 font-semibold transition"
            >
              Load Sample
            </button>
            <button
              onClick={() => setResetConfirmOpen(true)}
              className="px-2.5 py-0.5 rounded-full bg-rose-500/12 text-rose-600 dark:text-rose-400 hover:bg-rose-500/25 font-semibold transition"
            >
              Reset to Zero
            </button>
            <button
              onClick={() => setMobileFrame(!mobileFrame)}
              className="p-1 rounded-full hover:bg-neutral-200/70 dark:hover:bg-neutral-800 transition"
              title={mobileFrame ? 'Expand to Spacious Full Layout' : 'Preview Compact Android Phone Frame'}
            >
              {mobileFrame ? <Maximize2 className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-1 rounded-full hover:bg-neutral-200/70 dark:hover:bg-neutral-800 transition"
              title="Toggle Light / True-Black AMOLED Dark Mode"
            >
              {darkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* ====================================================================
            SAMSUNG CALENDAR TOP APP BAR
           ==================================================================== */}
        <header className="px-4 sm:px-6 py-3 flex items-center justify-between gap-2 sticky top-0 z-20 bg-[#F2F2F7]/90 dark:bg-[#000000]/90 backdrop-blur-md">
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={() => setDrawerOpen(true)}
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-neutral-200/70 dark:hover:bg-neutral-800/80 active:scale-95 transition"
              aria-label="Open Samsung Calendar Menu"
            >
              <Menu className="w-5 h-5 text-neutral-800 dark:text-neutral-100" />
            </button>

            {activeTab === 'calendar' ? (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setMonthPickerOpen(!monthPickerOpen)}
                  className="flex items-center gap-1.5 px-2 py-1 rounded-2xl hover:bg-neutral-200/60 dark:hover:bg-neutral-800/70 transition"
                >
                  <span className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
                    {currentMonthDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                  </span>
                  <ChevronDown className="w-4 h-4 text-neutral-500" />
                </button>
                <div className="flex items-center gap-0.5 ml-1">
                  <button
                    onClick={() => navigateMonth(-1)}
                    className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-neutral-200/70 dark:hover:bg-neutral-800 transition"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => navigateMonth(1)}
                    className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-neutral-200/70 dark:hover:bg-neutral-800 transition"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <h1 className="text-lg sm:text-xl font-bold tracking-tight text-neutral-900 dark:text-white">
                  {activeTab === 'pairing' && 'Free-Hand Sessions & 2:30 PM Split MCQs'}
                  {activeTab === 'bookmarks' && 'Bookmarks, Pearls & Physical 20th Notebook'}
                  {activeTab === 'backlogs' && 'Dynamic Backlogs & 4-vs-5 Revision Runway'}
                  {activeTab === 'analytics' && 'Multi-Parameter GT & 26-Subject Analytics'}
                  {activeTab === 'gym' && 'Cortisol-Shield Gym Tracker'}
                </h1>
              </div>
            )}
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => setPacingModalOpen(true)}
              className="px-2.5 py-1.5 rounded-full bg-indigo-500/12 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-300 hover:bg-indigo-500/25 text-xs font-semibold flex items-center gap-1 transition active:scale-95"
              title="Adaptive 8:30 AM & 2:30 PM MCQ Review Time-Pacing Calibrator"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{activePacingConfig.morningTopicCap}/AM Cap • Pacing</span>
            </button>

            <button
              onClick={handleDominoShift}
              className="px-2.5 py-1.5 rounded-full bg-amber-500/12 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300 hover:bg-amber-500/25 text-xs font-semibold flex items-center gap-1 transition active:scale-95"
              title="1-Click Domino Shift: Push all pending topics, bookmarks & pearls forward by +1 day (skipping Sunday)"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">+1d Domino</span>
            </button>

            {activeTab === 'calendar' && (
              <>
                <button
                  onClick={() => setSearchOpen(!searchOpen)}
                  className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-neutral-200/70 dark:hover:bg-neutral-800 transition"
                  title="Search scheduled topics"
                >
                  <Search className="w-4 h-4" />
                </button>

                <button
                  onClick={jumpToToday}
                  className="h-8 px-2.5 rounded-[10px] border-[1.5px] border-neutral-800 dark:border-neutral-200 text-xs font-bold text-neutral-900 dark:text-white hover:bg-neutral-900 hover:text-white dark:hover:bg-white dark:hover:text-black transition active:scale-95"
                  title="Jump to Today"
                >
                  {parseDateStr(TODAY_DEFAULT).getDate()}
                </button>

                <button
                  onClick={() => setAddEventSheetOpen(true)}
                  className="w-9 h-9 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-sm hover:bg-indigo-500 active:scale-95 transition"
                  title="Schedule New Revision Topic"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </>
            )}

            <button
              onClick={() => setProfileModalOpen(true)}
              className="h-9 px-3 rounded-full bg-white dark:bg-[#17171C] border border-neutral-200/80 dark:border-neutral-800 text-xs font-medium flex items-center gap-1.5 shadow-sm hover:border-indigo-500/40 transition"
            >
              <User className="w-3.5 h-3.5 text-indigo-500" />
              <span className="max-w-[90px] sm:max-w-[130px] truncate">{activeEmail.split('@')[0]}</span>
            </button>
          </div>
        </header>

        {/* Expandable Search Bar */}
        {searchOpen && activeTab === 'calendar' && (
          <div className="px-4 sm:px-6 pb-3">
            <div className="bg-white dark:bg-[#17171C] rounded-[22px] p-3 border border-neutral-200/70 dark:border-neutral-800 shadow-sm">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-neutral-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search across 19 Subjects + 7 Integrated Systems..."
                  className="w-full bg-transparent text-sm focus:outline-none"
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="text-neutral-400 hover:text-neutral-600">
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              {searchQuery && (
                <div className="mt-2 pt-2 border-t border-neutral-100 dark:border-neutral-800 max-h-48 overflow-y-auto space-y-1.5">
                  {searchResults.length === 0 ? (
                    <p className="text-xs text-neutral-400 py-2 text-center">No matching scheduled topics.</p>
                  ) : (
                    searchResults.map(item => (
                      <button
                        key={item.id}
                        onClick={() => {
                          setSelectedDate(item.nextReviewDate);
                          setCurrentMonthDate(parseDateStr(item.nextReviewDate));
                          setSearchOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-800/60 flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-semibold text-neutral-900 dark:text-white">{item.subject}</span>
                          <span className="text-neutral-500 dark:text-neutral-400 ml-1.5">{item.subheading}</span>
                        </div>
                        <span className="font-medium text-indigo-500">{formatHumanDate(item.nextReviewDate)}</span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Quick Month Picker Popover */}
        {monthPickerOpen && activeTab === 'calendar' && (
          <div className="px-4 sm:px-6 pb-3 z-30">
            <div className="bg-white dark:bg-[#17171C] rounded-[26px] p-4 border border-neutral-200/80 dark:border-neutral-800 shadow-lg max-w-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">Jump to Month (Dec 31 / Jan 15 / May 20 Runway)</span>
                <button onClick={() => setMonthPickerOpen(false)} className="p-1 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: 'Oct 2026', y: 2026, m: 9 },
                  { label: 'Nov 2026 (P1)', y: 2026, m: 10 },
                  { label: 'Dec 2026 (P1 End)', y: 2026, m: 11 },
                  { label: 'Jan 2027 (Buffer)', y: 2027, m: 0 },
                  { label: 'Feb 2027 (Rev 2-3)', y: 2027, m: 1 },
                  { label: 'Mar 2027 (Rev 3-4)', y: 2027, m: 2 },
                  { label: 'Apr 2027 (Rev 4-5)', y: 2027, m: 3 },
                  { label: 'May 2027 (Exam)', y: 2027, m: 4 }
                ].map(item => {
                  const isActive = currentMonthDate.getFullYear() === item.y && currentMonthDate.getMonth() === item.m;
                  return (
                    <button
                      key={item.label}
                      onClick={() => {
                        setCurrentMonthDate(new Date(item.y, item.m, 1, 12, 0, 0));
                        setMonthPickerOpen(false);
                      }}
                      className={`py-2 px-2.5 rounded-2xl text-xs font-semibold transition ${
                        isActive
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-neutral-100 dark:bg-neutral-800/70 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200'
                      }`}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ====================================================================
            MAIN VIEWPORT CONTENT
           ==================================================================== */}
        <main className="flex-1 px-3 sm:px-6 pb-24 flex flex-col gap-4">

          {/* ==================================================================
              TAB 1: SAMSUNG CALENDAR (WITH 2:30 PM SPLIT MCQ & 4-VS-5 REV BADGES)
             ================================================================== */}
          {activeTab === 'calendar' && (
            <div className="flex flex-col gap-4">
              {/* View Switcher + Filter Chips + Physical 20th NB & Backlog Pills */}
              <div className="flex flex-wrap items-center justify-between gap-2 px-1">
                <div className="inline-flex p-1 rounded-full bg-neutral-200/75 dark:bg-[#17171C] border border-neutral-300/40 dark:border-neutral-800">
                  {[
                    { id: 'split', label: 'Split View' },
                    { id: 'month', label: 'Month' },
                    { id: 'week', label: '7-Day Week' },
                    { id: 'schedule', label: '4-vs-5 Rev Schedule' }
                  ].map(v => (
                    <button
                      key={v.id}
                      onClick={() => setCalViewMode(v.id)}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition ${
                        calViewMode === v.id
                          ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-sm'
                          : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                      }`}
                    >
                      {v.label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
                  {physical20thCuratedList.totalEligible > 0 && (
                    <button
                      onClick={() => {
                        setActiveTab('bookmarks');
                        setBmSubView('physical20th');
                      }}
                      className="px-3 py-1 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30 flex items-center gap-1"
                    >
                      <PenTool className="w-3 h-3" />
                      <span>📓 {physical20thCuratedList.totalEligible} for Physical 20th NB</span>
                    </button>
                  )}
                  {dynamicBacklogs.totalCount > 0 && (
                    <button
                      onClick={() => setActiveTab('backlogs')}
                      className="px-3 py-1 rounded-full text-[11px] font-bold bg-rose-500 text-white flex items-center gap-1 shadow-xs"
                    >
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{dynamicBacklogs.totalCount} Backlogs →</span>
                    </button>
                  )}
                  {Object.values(BUCKET_CONFIG).map(b => (
                    <button
                      key={b.id}
                      onClick={() => setBucketFilter(prev => ({ ...prev, [b.id]: !prev[b.id] }))}
                      className={`px-2.5 py-1 rounded-full text-[11px] font-semibold flex items-center gap-1.5 border transition ${
                        bucketFilter[b.id]
                          ? `${b.bgLight} ${b.borderClass}`
                          : 'bg-neutral-100 dark:bg-neutral-900 text-neutral-400 border-transparent opacity-60'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${b.dotClass}`} />
                      <span>{b.shortName}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* SAMSUNG CALENDAR GRID + INSPECTOR LAYOUT */}
              <div className={`grid gap-4 ${
                !mobileFrame && calViewMode === 'split'
                  ? 'lg:grid-cols-12 items-start'
                  : 'grid-cols-1'
              }`}>

                {/* SAMSUNG MONTH / SPLIT GRID */}
                {(calViewMode === 'month' || calViewMode === 'split') && (
                  <div className={`${!mobileFrame && calViewMode === 'split' ? 'lg:col-span-7 xl:col-span-8' : ''} bg-white dark:bg-[#121216] rounded-[30px] p-3 sm:p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800/80 transition-all`}>
                    <div className="grid grid-cols-7 mb-2 text-center select-none">
                      {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, idx) => (
                        <div
                          key={idx}
                          className={`py-1.5 text-[11px] font-bold tracking-wider ${
                            idx === 0 ? 'text-[#FF3B30]' : idx === 6 ? 'text-[#007AFF]' : 'text-neutral-500 dark:text-neutral-400'
                          }`}
                        >
                          {d}
                        </div>
                      ))}
                    </div>

                    <div className="grid grid-cols-7 border-t border-neutral-100 dark:border-neutral-800/70">
                      {calendarMonthCells.map((cell) => {
                        const isSelected = cell.dateStr === selectedDate;
                        const isToday = cell.dateStr === TODAY_DEFAULT;
                        const isSunday = cell.dayOfWeek === 0;
                        const isSaturday = cell.dayOfWeek === 6;

                        const dayTopics = appData.topics.filter(
                          t => t.nextReviewDate === cell.dateStr && bucketFilter[t.bucket]
                        );
                        const dayBookmarks = bucketFilter.bookmarks
                          ? appData.bookmarks.filter(b => b.status === 'active' && b.dueDate === cell.dateStr)
                          : [];
                        const dayPearls = bucketFilter.pearls
                          ? appData.notebookPearls.filter(p => p.status !== 'mastered' && p.dueDate === cell.dateStr)
                          : [];
                        const dayGT = appData.gtList.find(g => g.date === cell.dateStr);
                        const isPastBacklogDay = cell.dateStr < selectedDate && (dayTopics.length > 0 || dayBookmarks.length > 0 || dayPearls.length > 0);
                        const isMilestoneDec31 = cell.dateStr === '2026-12-31';
                        const isMilestoneJan15 = cell.dateStr === '2027-01-15';
                        const isMilestoneMay20 = cell.dateStr === '2027-05-20';

                        return (
                          <div
                            key={cell.dateStr}
                            onClick={() => setSelectedDate(cell.dateStr)}
                            className={`
                              ${calViewMode === 'month' ? 'min-h-[96px] sm:min-h-[118px]' : 'min-h-[78px] sm:min-h-[94px]'}
                              p-1 sm:p-1.5 border-b border-r last:border-r-0 border-neutral-100/90 dark:border-neutral-800/50
                              cursor-pointer flex flex-col justify-between transition-all relative
                              ${!cell.inCurrentMonth ? 'opacity-35' : ''}
                              ${isSelected ? 'bg-indigo-500/[0.06] dark:bg-indigo-500/[0.12] rounded-2xl ring-1.5 ring-indigo-500/60 z-10' : 'hover:bg-neutral-50/80 dark:hover:bg-neutral-900/40'}
                            `}
                          >
                            <div className="flex items-center justify-between px-0.5">
                              <span
                                className={`
                                  w-6 h-6 sm:w-7 sm:h-7 rounded-full flex items-center justify-center text-xs sm:text-[13px] font-bold transition
                                  ${isToday
                                    ? 'bg-neutral-900 text-white dark:bg-white dark:text-black shadow-sm'
                                    : isSelected
                                    ? 'bg-indigo-600 text-white'
                                    : isSunday
                                    ? 'text-[#FF3B30]'
                                    : isSaturday
                                    ? 'text-[#007AFF]'
                                    : 'text-neutral-800 dark:text-neutral-200'}
                                `}
                              >
                                {cell.dayNum}
                              </span>

                              {isMilestoneDec31 && (
                                <span className="text-[8px] font-extrabold px-1.5 py-0.2 rounded-full bg-indigo-600 text-white">
                                  P1 End
                                </span>
                              )}
                              {isMilestoneJan15 && (
                                <span className="text-[8px] font-extrabold px-1.5 py-0.2 rounded-full bg-amber-500 text-white">
                                  Buffer End
                                </span>
                              )}
                              {isMilestoneMay20 && (
                                <span className="text-[8px] font-extrabold px-1.5 py-0.2 rounded-full bg-rose-600 text-white">
                                  INI-CET!
                                </span>
                              )}
                              {!isMilestoneDec31 && !isMilestoneJan15 && !isMilestoneMay20 && isPastBacklogDay ? (
                                <span className="text-[8px] font-extrabold px-1.5 py-0.2 rounded-full bg-rose-500 text-white">
                                  Backlog
                                </span>
                              ) : !isSunday && dayTopics.length > 0 ? (
                                <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${
                                  dayTopics.length >= 3
                                    ? 'bg-rose-500/15 text-rose-600 dark:text-rose-300'
                                    : 'bg-neutral-200/80 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
                                }`}>
                                  {dayTopics.length}/3
                                </span>
                              ) : null}
                            </div>

                            <div className="mt-1 space-y-1 flex-1 overflow-hidden">
                              {isSunday ? (
                                <div className="px-1.5 py-0.5 rounded-[5px] bg-amber-500/15 text-amber-700 dark:bg-amber-500/25 dark:text-amber-300 text-[9px] sm:text-[10px] font-semibold truncate flex items-center gap-1">
                                  <Lock className="w-2.5 h-2.5 shrink-0" />
                                  <span className="truncate">{dayGT ? `${dayGT.netScore}/200` : 'GT Lock'}</span>
                                </div>
                              ) : (
                                <>
                                  {dayTopics.slice(0, 2).map(t => (
                                    <div
                                      key={t.id}
                                      className={`px-1.5 py-[2px] rounded-[5px] text-[9px] sm:text-[10px] font-semibold truncate leading-tight ${BUCKET_CONFIG[t.bucket].barClass}`}
                                      title={`${t.subject}: ${t.subheading}`}
                                    >
                                      {t.subject}
                                    </div>
                                  ))}
                                  {dayTopics.length > 2 && (
                                    <div className="text-[9px] font-bold text-neutral-400 px-1">
                                      +{dayTopics.length - 2} more
                                    </div>
                                  )}
                                </>
                              )}

                              {(dayBookmarks.length > 0 || dayPearls.length > 0) && (
                                <div className="px-1.5 py-[1.5px] rounded-[5px] bg-violet-500/20 text-violet-700 dark:text-violet-300 text-[9px] font-semibold truncate flex items-center gap-1">
                                  <Bookmark className="w-2.5 h-2.5 shrink-0" />
                                  <span className="truncate">
                                    {dayBookmarks.length > 0 ? `${dayBookmarks.length} BM` : ''}
                                    {dayBookmarks.length > 0 && dayPearls.length > 0 ? ' • ' : ''}
                                    {dayPearls.length > 0 ? `${dayPearls.length} Pearl` : ''}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* SAMSUNG 7-DAY WEEK VIEW (With 2:30 PM Split MCQ Block!) */}
                {calViewMode === 'week' && (
                  <div className="bg-white dark:bg-[#121216] rounded-[30px] p-4 sm:p-6 shadow-sm border border-neutral-200/60 dark:border-neutral-800/80">
                    <div className="grid grid-cols-7 gap-1 sm:gap-2 pb-4 border-b border-neutral-100 dark:border-neutral-800">
                      {calendarWeekCells.map(w => {
                        const isSel = w.dateStr === selectedDate;
                        const isTod = w.dateStr === TODAY_DEFAULT;
                        const isSun = w.dayOfWeek === 0;
                        const isSat = w.dayOfWeek === 6;
                        const count = appData.topics.filter(t => t.nextReviewDate === w.dateStr).length;
                        return (
                          <button
                            key={w.dateStr}
                            onClick={() => setSelectedDate(w.dateStr)}
                            className={`py-2.5 px-1 rounded-2xl flex flex-col items-center gap-1 transition ${
                              isSel ? 'bg-indigo-600 text-white shadow-sm' : 'hover:bg-neutral-100 dark:hover:bg-neutral-800/60'
                            }`}
                          >
                            <span className={`text-[10px] font-bold uppercase ${
                              isSel ? 'text-indigo-100' : isSun ? 'text-[#FF3B30]' : isSat ? 'text-[#007AFF]' : 'text-neutral-400'
                            }`}>
                              {w.shortDay}
                            </span>
                            <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                              isTod && !isSel ? 'bg-neutral-900 text-white dark:bg-white dark:text-black' : ''
                            }`}>
                              {w.dayNum}
                            </span>
                            <span className={`text-[10px] font-semibold ${isSel ? 'text-indigo-100' : 'text-neutral-400'}`}>
                              {isSun ? '🔒 GT' : `${count}/3`}
                            </span>
                          </button>
                        );
                      })}
                    </div>

                    <div className="mt-4 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200">
                          Full-Day Neuro-Circadian Timeline — {formatHumanDate(selectedDate, { weekday: 'long', month: 'short', day: 'numeric' })}
                        </h3>
                        <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                          {activeMacroPhase.title}
                        </span>
                      </div>

                      {isSundayStr(selectedDate) ? (
                        <div className="p-5 rounded-3xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <div className="space-y-1">
                            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-700 dark:text-amber-300">
                              <Lock className="w-4 h-4" /> STRICT SUNDAY GT BLACKOUT (0 Revision Capacity)
                            </div>
                            <p className="text-xs text-neutral-600 dark:text-neutral-300">
                              Sundays are reserved for full-length 200-MCQ Grand Tests under -1/3 negative marking.
                            </p>
                          </div>
                          <button
                            onClick={() => setActiveTab('analytics')}
                            className="px-4 py-2.5 rounded-2xl bg-amber-500 text-white text-xs font-bold shrink-0 hover:bg-amber-600 transition"
                          >
                            Log Sunday GT Score →
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {[
                            {
                              time: '08:30 AM – 10:00 AM',
                              title: `Peak Prefrontal Recall: Revisions 2, 3, 4 & 5 Only (${selectedDayTopics.length}/3 Topics)`,
                              subtitle: selectedDayTopics.length > 0
                                ? selectedDayTopics.map(t => `${t.subject}: ${t.subheading}`).join(' • ')
                                : '18m Blind Custom Q-Bank Test + 12m Retrograde Note Patching per topic',
                              accent: 'border-l-4 border-indigo-500 bg-indigo-500/[0.06]'
                            },
                            {
                              time: `${s1StartTime} – ${s1EndTime}`,
                              title: `Session 1 Morning 1st-Read (${s1Subject})`,
                              subtitle: s1FreehandInput.trim() || s1Subheading,
                              accent: 'border-l-4 border-sky-500 bg-sky-500/[0.06]'
                            },
                            {
                              time: '02:30 PM – 03:15 PM (Split Part A • 45 mins)',
                              title: `Yesterday's Evening Topic MCQs = Day-1 Spaced Revision (${currentSplitMcq.partAYesterdayPmSubject})`,
                              subtitle: `${currentSplitMcq.partAYesterdayPmTopic} (35–40 Timed MCQs after overnight sleep consolidation)`,
                              accent: 'border-l-4 border-emerald-500 bg-emerald-500/[0.08]'
                            },
                            {
                              time: '03:15 PM – 04:15 PM (Split Part B • 60 mins)',
                              title: `Today's Morning Session 1 MCQs (${currentSplitMcq.partBTodayAmSubject})`,
                              subtitle: `${currentSplitMcq.partBTodayAmTopic} (45–50 Timed MCQs 4 hours post-encoding)`,
                              accent: 'border-l-4 border-teal-500 bg-teal-500/[0.08]'
                            },
                            {
                              time: '04:30 PM – 05:30 PM',
                              title: 'van Dongen 4-Hour Post-Learning Gym BDNF Window',
                              subtitle: '45m externally stabilized machine hypertrophy @ 1–2 RIR + 5g Creatine',
                              accent: 'border-l-4 border-amber-500 bg-amber-500/[0.06]'
                            },
                            {
                              time: `${s2StartTime} – 08:30 PM`,
                              title: `Session 2 Post-Gym 1st-Read + 15m Micro-Anchor (${s2Subject})`,
                              subtitle: `${s2FreehandInput.trim() || s2Subheading} (Main 40-MCQ block automatically routed to tomorrow 2:30 PM!)`,
                              accent: 'border-l-4 border-rose-500 bg-rose-500/[0.06]'
                            },
                            {
                              time: '09:00 PM – 10:15 PM',
                              title: `Pre-Sleep Synaptic Tagging + 30-Min Physical 20th Notebook (${selectedDayBookmarks.length} BM, ${selectedDayPearls.length} Pearls)`,
                              subtitle: 'Cooled Bookmarks + Spaced Pearls + 30m Physical 20th Notebook active recall before sleep spindles',
                              accent: 'border-l-4 border-violet-500 bg-violet-500/[0.06]'
                            }
                          ].map((slot, i) => (
                            <div key={i} className={`p-3.5 rounded-2xl ${slot.accent} flex flex-col sm:flex-row sm:items-center justify-between gap-2`}>
                              <div>
                                <span className="text-[11px] font-bold text-neutral-500 dark:text-neutral-400">{slot.time}</span>
                                <h4 className="text-xs sm:text-sm font-bold text-neutral-900 dark:text-white">{slot.title}</h4>
                                <p className="text-xs text-neutral-600 dark:text-neutral-300 mt-0.5">{slot.subtitle}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* SAMSUNG 4-VS-5 REVISION SCHEDULE LIST VIEW */}
                {calViewMode === 'schedule' && (
                  <div className="bg-white dark:bg-[#121216] rounded-[30px] p-4 sm:p-6 shadow-sm border border-neutral-200/60 dark:border-neutral-800/80 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h3 className="text-base font-bold">4-Revision (Normal) vs. 5-Revision (Weak/Volatile) Schedule Before May 20</h3>
                        <p className="text-xs text-neutral-500">
                          Phase 1 ends Dec 31 • Buffer ends Jan 15 • Any topic with &lt;75% at Rev 2 automatically enters the 5-Revision Track & Physical 20th Notebook!
                        </p>
                      </div>
                      <button
                        onClick={() => setAddEventSheetOpen(true)}
                        className="px-3.5 py-2 rounded-full bg-indigo-600 text-white text-xs font-semibold flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4" /> Free-Hand Topic
                      </button>
                    </div>

                    {appData.topics.length === 0 ? (
                      <div className="py-12 text-center space-y-3">
                        <CalendarIcon className="w-10 h-10 text-neutral-300 dark:text-neutral-700 mx-auto" />
                        <p className="text-sm font-medium text-neutral-500">Your schedule is at Zero-State (0 topics).</p>
                        <button onClick={handleLoadSample} className="px-4 py-2 rounded-full bg-indigo-600 text-white text-xs font-semibold">
                          Load Sample Schedule
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {Array.from(new Set(appData.topics.map(t => t.nextReviewDate))).sort().map(dStr => {
                          const list = appData.topics.filter(t => t.nextReviewDate === dStr);
                          const isOverdue = dStr < TODAY_DEFAULT;
                          return (
                            <div key={dStr} className={`p-3.5 rounded-2xl border ${
                              isOverdue
                                ? 'bg-rose-500/[0.05] border-rose-500/30'
                                : 'bg-neutral-50 dark:bg-[#17171C] border-neutral-200/60 dark:border-neutral-800'
                            }`}>
                              <div className="flex items-center justify-between mb-2">
                                <span className={`text-xs font-bold ${isOverdue ? 'text-rose-600' : 'text-indigo-600 dark:text-indigo-400'}`}>
                                  {formatHumanDate(dStr, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
                                  {isOverdue ? ' • OVERDUE BACKLOG' : ''}
                                </span>
                                <span className="text-[11px] font-semibold text-neutral-400">{list.length}/3 Load</span>
                              </div>
                              <div className="space-y-2">
                                {list.map(item => {
                                  const revInfo = getTopicRevisionTarget(item, appData.subjectStats);
                                  return (
                                    <div key={item.id} className="flex items-center justify-between gap-2 bg-white dark:bg-[#121216] p-2.5 rounded-xl border border-neutral-100 dark:border-neutral-800">
                                      <div className="flex items-center gap-2.5 min-w-0">
                                        <span className={`w-2.5 h-10 rounded-full shrink-0 ${BUCKET_CONFIG[item.bucket].dotClass}`} />
                                        <div className="min-w-0">
                                          <div className="flex flex-wrap items-center gap-1.5">
                                            <span className="text-xs font-bold">{item.subject}</span>
                                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                                              revInfo.requiresFiveRevisions
                                                ? 'bg-rose-500/15 text-rose-600 dark:text-rose-300'
                                                : 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                                            }`}>
                                              Rev {revInfo.completedRevisions}/{revInfo.targetRevisions} by May 20
                                            </span>
                                            {revInfo.eligibleForPhysical20th && (
                                              <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-700 dark:text-amber-300 text-[10px] font-bold">
                                                📓 20th NB
                                              </span>
                                            )}
                                          </div>
                                          <p className="text-xs text-neutral-600 dark:text-neutral-300 truncate">{item.subheading}</p>
                                        </div>
                                      </div>
                                      <button
                                        onClick={() => {
                                          setSelectedDate(dStr);
                                          setGraderTopic(item);
                                          setGraderAccuracy(item.lastAccuracy || 82);
                                          setGraderConfidence(item.confidenceRating || 4);
                                          setGraderSpeedSec(item.avgSecPerMcq || 42);
                                        }}
                                        className="px-3 py-1.5 rounded-full bg-indigo-500/12 text-indigo-600 dark:text-indigo-300 text-xs font-bold shrink-0 hover:bg-indigo-500/20"
                                      >
                                        Grade %
                                      </button>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}

                {/* RIGHT / BOTTOM: SAMSUNG SELECTED DATE INSPECTOR + 2:30 PM SPLIT MCQ WIDGET */}
                <div className={`${!mobileFrame && calViewMode === 'split' ? 'lg:col-span-5 xl:col-span-4' : ''} bg-white dark:bg-[#121216] rounded-[30px] p-4 sm:p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800/80 flex flex-col justify-between gap-4`}>
                  <div>
                    <div className="w-10 h-1 rounded-full bg-neutral-200 dark:bg-neutral-800 mx-auto mb-3 lg:hidden" />

                    <div className="flex items-center justify-between gap-2 pb-3 border-b border-neutral-100 dark:border-neutral-800">
                      <div>
                        <div className="flex items-center gap-2">
                          <h2 className="text-lg font-bold text-neutral-900 dark:text-white">
                            {formatHumanDate(selectedDate, { weekday: 'short', month: 'short', day: 'numeric' })}
                          </h2>
                          {isSundayStr(selectedDate) ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-700 dark:text-amber-300 text-[11px] font-bold">
                              🔒 Sunday GT Lockout
                            </span>
                          ) : (
                            <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                              selectedDayTopics.length >= 3
                                ? 'bg-rose-500/15 text-rose-600 dark:text-rose-300'
                                : 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                            }`}>
                              {selectedDayTopics.length}/{activePacingConfig.morningTopicCap} Morning Cap
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                          08:30 AM Spaced Queue (Revs 2–5) + 02:30 PM Split MCQ Block
                        </p>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => openGoogleCalendarBlock('morning')}
                          className="p-2 rounded-full bg-neutral-100 dark:bg-neutral-800 hover:bg-indigo-500/15 hover:text-indigo-600 transition"
                          title="Push 8:30 AM Block to Google Calendar"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setSchedStudyDate(selectedDate);
                            setAddEventSheetOpen(true);
                          }}
                          className="px-3 py-1.5 rounded-full bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-500 transition flex items-center gap-1"
                        >
                          <Plus className="w-3.5 h-3.5" /> Add
                        </button>
                      </div>
                    </div>

                    {/* 02:30 PM – 04:15 PM SPLIT MCQ WORKFLOW CARD (Directly on Selected Date Inspector!) */}
                    {!isSundayStr(selectedDate) && (
                      <div className="mt-3 p-3.5 rounded-2xl bg-gradient-to-br from-emerald-500/10 via-teal-500/5 to-indigo-500/10 border border-emerald-500/25 space-y-2.5">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-[11px] font-extrabold uppercase tracking-wide text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                            <Zap className="w-3.5 h-3.5" /> 02:30 PM Split MCQ ({activePacingConfig.partAYesterdayQs + activePacingConfig.partBTodayQs} Qs)
                          </span>
                          <button
                            onClick={() => setPacingModalOpen(true)}
                            className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                          >
                            <Sliders className="w-3 h-3" /> Adjust Review Pace
                          </button>
                        </div>

                        {/* Part A: 02:30 - 03:15 PM Yesterday's Evening Topic MCQs (= Rev 1!) */}
                        <div className="p-2.5 rounded-xl bg-white/90 dark:bg-[#15151B] border border-neutral-200/60 dark:border-neutral-800 flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 block">
                              Part A (02:30–03:15 PM • {activePacingConfig.partAYesterdayQs} Qs): Yesterday's 6PM Topic = Day-1 Rev
                            </span>
                            <p className="text-xs font-bold truncate">
                              {currentSplitMcq.partAYesterdayPmSubject}: {currentSplitMcq.partAYesterdayPmTopic}
                            </p>
                          </div>
                          <button
                            onClick={() => handleCompleteSplitMcqHalf('partA')}
                            disabled={currentSplitMcq.partADone}
                            className={`px-2.5 py-1.5 rounded-xl text-[10px] font-extrabold shrink-0 transition ${
                              currentSplitMcq.partADone
                                ? 'bg-emerald-500 text-white'
                                : 'bg-emerald-500/15 hover:bg-emerald-600 hover:text-white text-emerald-700 dark:text-emerald-300'
                            }`}
                          >
                            {currentSplitMcq.partADone ? 'Rev 1 Logged ✓' : 'Done → Queue Rev 2'}
                          </button>
                        </div>

                        {/* Part B: 03:15 - 04:15 PM Today's Morning Topic MCQs */}
                        <div className="p-2.5 rounded-xl bg-white/90 dark:bg-[#15151B] border border-neutral-200/60 dark:border-neutral-800 flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 block">
                              Part B (03:15–04:15 PM • {activePacingConfig.partBTodayQs} Qs): Today's 10:15 AM Topic MCQs
                            </span>
                            <p className="text-xs font-bold truncate">
                              {currentSplitMcq.partBTodayAmSubject}: {currentSplitMcq.partBTodayAmTopic}
                            </p>
                          </div>
                          <button
                            onClick={() => handleCompleteSplitMcqHalf('partB')}
                            disabled={currentSplitMcq.partBDone}
                            className={`px-2.5 py-1.5 rounded-xl text-[10px] font-extrabold shrink-0 transition ${
                              currentSplitMcq.partBDone
                                ? 'bg-indigo-600 text-white'
                                : 'bg-indigo-500/15 hover:bg-indigo-600 hover:text-white text-indigo-700 dark:text-indigo-300'
                            }`}
                          >
                            {currentSplitMcq.partBDone ? 'MCQs Logged ✓' : 'Done → Queue Rev 2'}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* 08:30 AM Spaced Recall Queue List */}
                    <div className="mt-3 space-y-2.5 max-h-[340px] overflow-y-auto pr-0.5">
                      {isSundayStr(selectedDate) ? (
                        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 space-y-3">
                          <span className="text-xs font-bold text-amber-700 dark:text-amber-300 flex items-center gap-1.5">
                            <Lock className="w-3.5 h-3.5" /> Sunday Grand Test Blackout
                          </span>
                          <p className="text-xs text-neutral-600 dark:text-neutral-300">
                            Zero morning revisions are scheduled on Sundays. Any review landing here automatically routes to Saturday or Monday.
                          </p>
                          <button
                            onClick={() => {
                              setGtDate(selectedDate);
                              setActiveTab('analytics');
                            }}
                            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition"
                          >
                            {selectedDayGT ? 'View Multi-Parameter GT Analytics' : '+ Log This Sunday’s Grand Test'}
                          </button>
                        </div>
                      ) : selectedDayTopics.length === 0 && selectedDayBookmarks.length === 0 && selectedDayPearls.length === 0 ? (
                        <div className="py-6 text-center space-y-2">
                          <p className="text-xs font-medium text-neutral-500">No 08:30 AM Spaced Revisions due on this date.</p>
                          <p className="text-[11px] text-neutral-400">Type a subtopic below or tap "Load Sample" in the top bar.</p>
                        </div>
                      ) : (
                        <>
                          {selectedDayTopics.map(topic => {
                            const subjObj = getSubjectObj(topic.subject);
                            const bConf = BUCKET_CONFIG[topic.bucket];
                            const revInfo = getTopicRevisionTarget(topic, appData.subjectStats);
                            return (
                              <div
                                key={topic.id}
                                className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/70 dark:border-neutral-800 hover:border-indigo-500/40 transition"
                              >
                                <div className="flex items-start justify-between gap-2">
                                  <div className="flex items-start gap-2.5 min-w-0">
                                    <span className={`w-1.5 h-12 rounded-full mt-0.5 shrink-0 ${bConf.dotClass}`} />
                                    <div className="min-w-0">
                                      <div className="flex flex-wrap items-center gap-1">
                                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${bConf.bgLight}`}>
                                          Bucket {topic.bucket} • {topic.intervalDays}d gap
                                        </span>
                                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                                          revInfo.requiresFiveRevisions
                                            ? 'bg-rose-500/15 text-rose-600 dark:text-rose-300'
                                            : 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                                        }`}>
                                          Rev {revInfo.completedRevisions}/{revInfo.targetRevisions} Track
                                        </span>
                                        {revInfo.eligibleForPhysical20th && (
                                          <span className="px-1.5 py-0.5 rounded-md bg-amber-500/20 text-amber-700 dark:text-amber-300 text-[10px] font-bold">
                                            📓 20th NB
                                          </span>
                                        )}
                                      </div>
                                      <h4 className="text-xs sm:text-sm font-bold text-neutral-900 dark:text-white mt-1">
                                        {topic.subject} {subjObj.isIntegrated ? ' (Integrated)' : ''}
                                      </h4>
                                      <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-snug">
                                        {topic.subheading}
                                      </p>
                                      {topic.schedulerNote && (
                                        <p className="text-[10px] text-neutral-400 mt-1">
                                          {topic.schedulerNote}
                                        </p>
                                      )}
                                    </div>
                                  </div>

                                  <button
                                    onClick={() => handleDeleteTopic(topic.id)}
                                    className="opacity-60 hover:opacity-100 p-1 text-neutral-400 hover:text-rose-500 transition"
                                    title="Delete Topic"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>

                                <div className="mt-3 pt-2.5 border-t border-neutral-200/60 dark:border-neutral-800/80 flex items-center justify-between gap-2">
                                  <span className="text-[11px] text-neutral-500">
                                    {topic.lastAccuracy
                                      ? `Last: ${topic.lastAccuracy}% • ${topic.avgSecPerMcq || 42}s/Q • ${topic.confidenceRating || 4}★`
                                      : '18m Blind Test + 12m Note Patch'}
                                  </span>
                                  <button
                                    onClick={() => {
                                      setGraderTopic(topic);
                                      setGraderAccuracy(topic.lastAccuracy || 82);
                                      setGraderConfidence(topic.confidenceRating || 4);
                                      setGraderSpeedSec(topic.avgSecPerMcq || 42);
                                    }}
                                    className="px-3 py-1.5 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition flex items-center gap-1 shadow-sm"
                                  >
                                    <Award className="w-3.5 h-3.5" />
                                    Grade Rev
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </>
                      )}
                    </div>
                  </div>

                  {/* Samsung Calendar Bottom Free-Hand Quick-Add Bar */}
                  <form onSubmit={handleBottomQuickAdd} className="pt-2 border-t border-neutral-100 dark:border-neutral-800">
                    <div className="flex items-center gap-1.5">
                      <select
                        value={schedSubject}
                        onChange={e => setSchedSubject(e.target.value)}
                        className="h-9 px-2.5 rounded-full bg-[#F2F2F7] dark:bg-[#1C1C24] text-[11px] font-bold max-w-[145px] truncate"
                      >
                        <optgroup label="7 Integrated Clinical Systems">
                          {SUBJECTS_DB.filter(s => s.isIntegrated).map(s => (
                            <option key={s.name} value={s.name}>{s.name}</option>
                          ))}
                        </optgroup>
                        <optgroup label="19 Classic INI-CET Subjects">
                          {SUBJECTS_DB.filter(s => !s.isIntegrated).map(s => (
                            <option key={s.name} value={s.name}>[Bkt {s.bucket}] {s.name}</option>
                          ))}
                        </optgroup>
                      </select>
                      <input
                        type="text"
                        value={quickAddTitle}
                        onChange={e => setQuickAddTitle(e.target.value)}
                        placeholder={`Type any subtopic for ${formatHumanDate(selectedDate, { month: 'short', day: 'numeric' })}...`}
                        className="flex-1 h-9 px-3.5 rounded-full bg-[#F2F2F7] dark:bg-[#1C1C24] text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                      />
                      <button
                        type="submit"
                        className="w-9 h-9 rounded-full bg-indigo-600 text-white flex items-center justify-center shrink-0 hover:bg-indigo-500 active:scale-95 transition"
                        title="Quick Add Free-Hand Subtopic"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================================
              TAB 2: FREE-HAND SESSION BUILDER + 02:30 PM SPLIT MCQ WORKFLOW
             ================================================================== */}
          {activeTab === 'pairing' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              <div className="lg:col-span-7 space-y-4">
                <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h2 className="text-base sm:text-lg font-bold">Free-Hand Dual-Session Builder & 2:30 PM Split MCQ Planner</h2>
                      <p className="text-xs text-neutral-500">
                        Scheduling your AM + PM pair automatically places Today's AM MCQs at 3:15 PM today, and routes Tonight's 6:00 PM topic MCQs to 2:30 PM tomorrow (as your Day-1 Spaced Revision!).
                      </p>
                    </div>
                    <button
                      onClick={() => setCustomIndexModalOpen(true)}
                      className="px-3 py-1.5 rounded-full bg-indigo-500/12 text-indigo-600 dark:text-indigo-300 text-xs font-bold hover:bg-indigo-500/20 transition"
                    >
                      + Bulk Paste Subtopics
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {/* Session 1 */}
                    <div className="p-4 rounded-3xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/70 dark:border-neutral-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                          Session 1 (Morning 1st-Read)
                        </span>
                        <div className="flex items-center gap-1 text-[10px] font-bold">
                          <input
                            type="time"
                            value={s1StartTime}
                            onChange={e => setS1StartTime(e.target.value)}
                            className="bg-white dark:bg-neutral-800 px-1.5 py-0.5 rounded-md"
                          />
                          <span>–</span>
                          <input
                            type="time"
                            value={s1EndTime}
                            onChange={e => setS1EndTime(e.target.value)}
                            className="bg-white dark:bg-neutral-800 px-1.5 py-0.5 rounded-md"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-5 gap-1">
                        {[
                          { code: 'ALL', label: 'All' },
                          { code: 'INTEGRATED', label: '7 Int.' },
                          { code: 'B', label: 'Bkt B' },
                          { code: 'A', label: 'Bkt A' },
                          { code: 'C', label: 'Bkt C' }
                        ].map(f => (
                          <button
                            key={f.code}
                            onClick={() => {
                              setS1Filter(f.code);
                              const pool = getFilterPool(f.code);
                              if (pool.length > 0) setS1Subject(pool[0].name);
                            }}
                            className={`py-1 rounded-xl text-[10px] font-bold transition ${
                              s1Filter === f.code
                                ? 'bg-indigo-600 text-white'
                                : 'bg-white dark:bg-neutral-800 text-neutral-500'
                            }`}
                          >
                            {f.label}
                          </button>
                        ))}
                      </div>

                      <div className="space-y-2">
                        <label className="block text-[11px] font-semibold text-neutral-500">Choose Subject</label>
                        <select
                          value={s1Subject}
                          onChange={e => setS1Subject(e.target.value)}
                          className="w-full h-10 px-3 rounded-2xl bg-white dark:bg-[#121216] border border-neutral-200 dark:border-neutral-700 text-xs font-semibold"
                        >
                          {getFilterPool(s1Filter).map(s => (
                            <option key={s.name} value={s.name}>
                              {s.isIntegrated ? `[Integrated • ${s.pyqWeightage}% PYQ] ` : `[Bucket ${s.bucket} • ${s.pyqWeightage}% PYQ] `}
                              {s.name}
                            </option>
                          ))}
                        </select>

                        <label className="block text-[11px] font-semibold text-neutral-500">Select Saved Subtopic</label>
                        <select
                          value={s1Subheading}
                          onChange={e => setS1Subheading(e.target.value)}
                          className="w-full h-10 px-3 rounded-2xl bg-white dark:bg-[#121216] border border-neutral-200 dark:border-neutral-700 text-xs"
                        >
                          {getSubheadingsForSubject(s1Subject).map(sh => (
                            <option key={sh.title} value={sh.title}>
                              {sh.title} ({ORGAN_SYSTEMS[sh.sys] || sh.sys})
                            </option>
                          ))}
                        </select>

                        <label className="block text-[11px] font-semibold text-indigo-600 dark:text-indigo-400">
                          Or Type Free-Hand Subtopic
                        </label>
                        <input
                          type="text"
                          value={s1FreehandInput}
                          onChange={e => setS1FreehandInput(e.target.value)}
                          placeholder={`Type custom ${s1Subject} subtopic...`}
                          className="w-full h-10 px-3 rounded-2xl bg-white dark:bg-[#121216] border border-indigo-500/30 text-xs focus:outline-none"
                        />
                        <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                          → Solved Today at 03:15 PM – 04:15 PM (45 MCQs)
                        </p>
                      </div>
                    </div>

                    {/* Session 2 */}
                    <div className="p-4 rounded-3xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/70 dark:border-neutral-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">
                          Session 2 (6:00 PM Post-Gym)
                        </span>
                        <div className="flex items-center gap-1 text-[10px] font-bold">
                          <input
                            type="time"
                            value={s2StartTime}
                            onChange={e => setS2StartTime(e.target.value)}
                            className="bg-white dark:bg-neutral-800 px-1.5 py-0.5 rounded-md"
                          />
                          <span>–</span>
                          <input
                            type="time"
                            value={s2EndTime}
                            onChange={e => setS2EndTime(e.target.value)}
                            className="bg-white dark:bg-neutral-800 px-1.5 py-0.5 rounded-md"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-5 gap-1">
                        {[
                          { code: 'ALL', label: 'All' },
                          { code: 'INTEGRATED', label: '7 Int.' },
                          { code: 'A', label: 'Bkt A' },
                          { code: 'C', label: 'Bkt C' },
                          { code: 'B', label: 'Bkt B' }
                        ].map(f => (
                          <button
                            key={f.code}
                            onClick={() => {
                              setS2Filter(f.code);
                              const pool = getFilterPool(f.code);
                              if (pool.length > 0) setS2Subject(pool[0].name);
                            }}
                            className={`py-1 rounded-xl text-[10px] font-bold transition ${
                              s2Filter === f.code
                                ? 'bg-rose-600 text-white'
                                : 'bg-white dark:bg-neutral-800 text-neutral-500'
                            }`}
                          >
                            {f.label}
                          </button>
                        ))}
                      </div>

                      <div className="space-y-2">
                        <label className="block text-[11px] font-semibold text-neutral-500">Choose Counterpart Subject</label>
                        <select
                          value={s2Subject}
                          onChange={e => setS2Subject(e.target.value)}
                          className="w-full h-10 px-3 rounded-2xl bg-white dark:bg-[#121216] border border-neutral-200 dark:border-neutral-700 text-xs font-semibold"
                        >
                          {getFilterPool(s2Filter).map(s => (
                            <option key={s.name} value={s.name}>
                              {s.isIntegrated ? `[Integrated • ${s.pyqWeightage}% PYQ] ` : `[Bucket ${s.bucket} • ${s.pyqWeightage}% PYQ] `}
                              {s.name}
                            </option>
                          ))}
                        </select>

                        <label className="block text-[11px] font-semibold text-neutral-500">Select Saved Subtopic</label>
                        <select
                          value={s2Subheading}
                          onChange={e => setS2Subheading(e.target.value)}
                          className="w-full h-10 px-3 rounded-2xl bg-white dark:bg-[#121216] border border-neutral-200 dark:border-neutral-700 text-xs"
                        >
                          {getSubheadingsForSubject(s2Subject).map(sh => (
                            <option key={sh.title} value={sh.title}>
                              {sh.title} ({ORGAN_SYSTEMS[sh.sys] || sh.sys})
                            </option>
                          ))}
                        </select>

                        <label className="block text-[11px] font-semibold text-rose-600 dark:text-rose-400">
                          Or Type Free-Hand Subtopic
                        </label>
                        <input
                          type="text"
                          value={s2FreehandInput}
                          onChange={e => setS2FreehandInput(e.target.value)}
                          placeholder={`Type custom ${s2Subject} subtopic...`}
                          className="w-full h-10 px-3 rounded-2xl bg-white dark:bg-[#121216] border border-rose-500/30 text-xs focus:outline-none"
                        />
                        <p className="text-[10px] text-rose-600 dark:text-rose-400 font-semibold">
                          → 15m anchor at 8:10 PM + 35 MCQs Tomorrow 2:30 PM (= Rev 1!)
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Live Memory-Physiology Pairing Verdict */}
                  <div className={`p-4 rounded-3xl border ${
                    neuroCompatibility.tone === 'emerald'
                      ? 'bg-emerald-500/10 border-emerald-500/30'
                      : neuroCompatibility.tone === 'rose'
                      ? 'bg-rose-500/12 border-rose-500/40'
                      : neuroCompatibility.tone === 'amber'
                      ? 'bg-amber-500/12 border-amber-500/40'
                      : 'bg-indigo-500/10 border-indigo-500/30'
                  } space-y-3`}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold uppercase tracking-wide flex items-center gap-1.5">
                        <Brain className="w-4 h-4" />
                        {neuroCompatibility.badge}
                      </span>
                      <span className="text-lg font-black">{neuroCompatibility.score}% Synergy</span>
                    </div>
                    <p className="text-xs text-neutral-700 dark:text-neutral-200 leading-relaxed">
                      {neuroCompatibility.message}
                    </p>

                    {neuroCompatibility.recommendations.length > 0 && (
                      <div className="pt-1 space-y-1.5">
                        <p className="text-[11px] font-bold text-neutral-600 dark:text-neutral-300">
                          {neuroCompatibility.isWrongPairing
                            ? '⚡ Fix Wrong Pairing — Tap a Scientifically Matched Counterpart for Session 2:'
                            : `Recommended High-Yield Counterparts Matching ${ORGAN_SYSTEMS[neuroCompatibility.sys1]}:`}
                        </p>
                        <div className="grid grid-cols-1 gap-1.5">
                          {neuroCompatibility.recommendations.map((rec, idx) => (
                            <button
                              key={idx}
                              onClick={() => {
                                setS2Filter('ALL');
                                setS2Subject(rec.subject);
                                setS2Subheading(rec.subheading);
                                setS2FreehandInput('');
                              }}
                              className="text-left px-3 py-2 rounded-2xl bg-white/95 dark:bg-[#121216]/95 hover:bg-white border border-neutral-200/70 dark:border-neutral-800 text-xs flex items-center justify-between gap-2 transition"
                            >
                              <span className="truncate">
                                <strong className="text-indigo-600 dark:text-indigo-400">
                                  [{rec.isIntegrated ? 'Integrated' : `Bucket ${rec.bucket}`} • {rec.subject} • PYQ {rec.pyqWeightage}%]
                                </strong>{' '}
                                {rec.subheading}
                              </span>
                              <span className="text-[10px] font-bold text-emerald-600 shrink-0">Pair Now →</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <button
                      onClick={handleScheduleDualPair}
                      className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-sm transition"
                    >
                      + Schedule AM + PM Pair & Wire 2:30 PM Split MCQ Blocks
                    </button>
                  </div>
                </div>

                {/* Bucket-Wise 19 Subjects + 7 Integrated Clinical Systems Directory */}
                <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-4">
                  <h3 className="text-sm sm:text-base font-bold">
                    Bucket-Wise 19 Subjects + 7 Separate Integrated Systems Directory
                  </h3>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { id: 'INTEGRATED', label: '7 Integrated Clinical Systems' },
                      { id: 'A', label: 'Bucket A: 6 Volatile Subjects (5-Rev Track)' },
                      { id: 'B', label: 'Bucket B: 6 Conceptual Subjects (4-Rev Track)' },
                      { id: 'C', label: 'Bucket C: 7 Visual / IBQ Subjects (4-Rev Track)' }
                    ].map(tab => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveExplorerBucket(tab.id)}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold transition ${
                          activeExplorerBucket === tab.id
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {(activeExplorerBucket === 'INTEGRATED'
                      ? SUBJECTS_DB.filter(s => s.isIntegrated)
                      : SUBJECTS_DB.filter(s => !s.isIntegrated && s.bucket === activeExplorerBucket)
                    ).map(subj => {
                      const subs = getSubheadingsForSubject(subj.name);
                      return (
                        <div
                          key={subj.name}
                          className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/60 dark:border-neutral-800 flex flex-col justify-between gap-2.5"
                        >
                          <div>
                            <div className="flex items-center justify-between gap-1">
                              <span className="text-xs font-extrabold text-neutral-900 dark:text-white">{subj.name}</span>
                              <span className="px-2 py-0.5 rounded-full bg-indigo-500/12 text-indigo-600 dark:text-indigo-300 text-[10px] font-bold">
                                {subj.avgQuestions} ({subj.pyqWeightage}%)
                              </span>
                            </div>
                            <p className="text-[10px] text-neutral-400 mt-0.5">
                              {subj.tier} • {subs.length} Subtopics
                            </p>
                          </div>

                          <div className="flex gap-1.5 pt-1">
                            <button
                              onClick={() => {
                                setS1Filter('ALL');
                                setS1Subject(subj.name);
                                showToast(`Loaded ${subj.name} into Session 1 (AM)`, 'info');
                              }}
                              className="flex-1 py-1.5 rounded-xl bg-indigo-500/12 hover:bg-indigo-600 hover:text-white text-indigo-600 dark:text-indigo-300 text-[11px] font-bold transition"
                            >
                              Session 1
                            </button>
                            <button
                              onClick={() => {
                                setS2Filter('ALL');
                                setS2Subject(subj.name);
                                showToast(`Loaded ${subj.name} into Session 2 (PM)`, 'info');
                              }}
                              className="flex-1 py-1.5 rounded-xl bg-rose-500/12 hover:bg-rose-600 hover:text-white text-rose-600 dark:text-rose-300 text-[11px] font-bold transition"
                            >
                              Session 2
                            </button>
                            <button
                              onClick={() => {
                                setSchedSubject(subj.name);
                                setSchedStudyDate(selectedDate);
                                setAddEventSheetOpen(true);
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-900 hover:text-white text-[11px] font-bold transition"
                            >
                              + Study
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Right 5 Cols: 11-Step Daily Physiological Checklist */}
              <div className="lg:col-span-5 space-y-4">
                <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-bold">11-Step Circadian & Split-MCQ Checklist</h3>
                      <p className="text-xs text-neutral-500">Date: {formatHumanDate(selectedDate)}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xl font-black text-emerald-600 dark:text-emerald-400">{physioReadinessPct}%</span>
                      <p className="text-[10px] text-neutral-400 uppercase font-bold">Readiness</p>
                    </div>
                  </div>

                  <div className="w-full h-2.5 rounded-full bg-neutral-100 dark:bg-neutral-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 transition-all duration-300"
                      style={{ width: `${physioReadinessPct}%` }}
                    />
                  </div>

                  <div className="space-y-2">
                    {PHYSIO_CHECKLIST_STEPS.map(step => {
                      const checked = todayPhysioCompleted.includes(step.id);
                      return (
                        <button
                          key={step.id}
                          onClick={() => togglePhysioStep(step.id)}
                          className={`w-full text-left p-3 rounded-2xl border transition flex items-start gap-3 ${
                            checked
                              ? 'bg-emerald-500/[0.08] border-emerald-500/30'
                              : 'bg-[#F8F8FA] dark:bg-[#18181F] border-neutral-200/60 dark:border-neutral-800 hover:border-indigo-500/30'
                          }`}
                        >
                          <div className={`w-5 h-5 rounded-lg flex items-center justify-center mt-0.5 shrink-0 ${
                            checked ? 'bg-emerald-500 text-white' : 'border-2 border-neutral-300 dark:border-neutral-600'
                          }`}>
                            {checked && <Check className="w-3.5 h-3.5" />}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-200/70 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300">
                                {step.time}
                              </span>
                              <span className={`text-xs font-bold ${checked ? 'line-through text-neutral-400' : ''}`}>
                                {step.title}
                              </span>
                            </div>
                            <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-0.5">
                              {step.detail}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================================
              TAB 3: BOOKMARKS, PEARLS & PHYSICAL 20TH NOTEBOOK AUTO-CURATOR
             ================================================================== */}
          {activeTab === 'bookmarks' && (
            <div className="space-y-4">
              {/* Sub-View Switcher including Physical 20th Notebook Write-Queue */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="inline-flex flex-wrap p-1 rounded-2xl bg-neutral-200/75 dark:bg-[#17171C]">
                  {[
                    { id: 'both', label: 'All Tracks' },
                    { id: 'physical20th', label: `📓 Physical 20th Notebook Curator (${physical20thCuratedList.totalEligible})` },
                    { id: 'bookmarks', label: `Bookmark MCQs (${dueTonightBookmarks.length} Due)` },
                    { id: 'pearls', label: `Pearls & Linked MCQs (${dueTonightPearls.length} Due)` }
                  ].map(v => (
                    <button
                      key={v.id}
                      onClick={() => setBmSubView(v.id)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
                        bmSubView === v.id
                          ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-sm'
                          : 'text-neutral-600 dark:text-neutral-400'
                      }`}
                    >
                      {v.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* ==============================================================
                  PHYSICAL 20TH NOTEBOOK AUTO-CURATOR & 30-MIN DAILY PROTOCOL
                  (Flags every Subtopic, Bookmark & Pearl with low accuracy/retention by 2nd revision!)
                 ============================================================== */}
              {(bmSubView === 'both' || bmSubView === 'physical20th') && (
                <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border-2 border-amber-500/35 space-y-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-700 dark:text-amber-300 text-[11px] font-extrabold">
                        <PenTool className="w-3.5 h-3.5" /> PHYSICAL 20TH NOTEBOOK CURATOR (LOW RETENTION BY 2ND REVISION)
                      </div>
                      <h3 className="text-base sm:text-lg font-bold">
                        What to Write in Your Physical 20th Notebook & Optimal Daily 30-Min Start Date
                      </h3>
                      <p className="text-xs text-neutral-600 dark:text-neutral-300 max-w-3xl leading-relaxed">
                        <strong>Scientifically Optimal Start Date:</strong> Start writing low-accuracy items into your Physical 20th Notebook during <strong>December</strong> as your 2nd revisions happen, and begin your <strong>mandatory 30-minute daily Physical 20th Notebook revision on January 1, 2027</strong> (right as Phase 1 ends and the Jan 1–15 Buffer begins)—or <strong>January 16, 2027</strong> once 100% of your 1st read + buffer is complete.
                      </p>
                    </div>

                    {/* Daily 30-Min Physical 20th NB Completion Button */}
                    <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex flex-col items-end gap-1.5 shrink-0">
                      <span className="text-[10px] font-bold uppercase text-amber-700 dark:text-amber-300">
                        Transcribed to Physical Copy: {physical20thCuratedList.totalWritten} / {physical20thCuratedList.totalEligible}
                      </span>
                      <button
                        onClick={() => {
                          setAppData(prev => ({
                            ...prev,
                            physical20thDailyLogs: {
                              ...(prev.physical20thDailyLogs || {}),
                              [selectedDate]: {
                                completed30Min: !prev.physical20thDailyLogs?.[selectedDate]?.completed30Min
                              }
                            }
                          }));
                          showToast('Logged 30-Minute Physical 20th Notebook Active Recall for today!', 'success');
                        }}
                        className={`px-3.5 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ${
                          appData.physical20thDailyLogs?.[selectedDate]?.completed30Min
                            ? 'bg-emerald-600 text-white'
                            : 'bg-amber-500 hover:bg-amber-600 text-white'
                        }`}
                      >
                        <Check className="w-4 h-4" />
                        {appData.physical20thDailyLogs?.[selectedDate]?.completed30Min
                          ? '30-Min Physical 20th NB Done Today ✓'
                          : 'Mark Today’s 30-Min Physical 20th NB Done'}
                      </button>
                    </div>
                  </div>

                  {/* 3-Column Breakdown of Items Flagged for Physical 20th Notebook */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
                    {/* Column 1: Subtopics with <75% Accuracy or <=2★ Confidence by Rev 2 */}
                    <div className="p-4 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/70 dark:border-neutral-800 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-rose-600 dark:text-rose-400">
                          1. Low-Retention Subtopics ({physical20thCuratedList.topics.length})
                        </span>
                        <span className="text-[10px] text-neutral-400">&lt;75% at Rev 2</span>
                      </div>
                      {physical20thCuratedList.topics.length === 0 ? (
                        <p className="text-xs text-neutral-400 py-4 text-center">No subtopics flagged yet.</p>
                      ) : (
                        <div className="space-y-2">
                          {physical20thCuratedList.topics.map(t => (
                            <div key={t.id} className="p-2.5 rounded-xl bg-white dark:bg-[#121216] border border-neutral-200/60 dark:border-neutral-800 space-y-1.5">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">{t.subject}</span>
                                <span className="text-[10px] font-bold text-rose-500">
                                  {t.lastAccuracy ? `${t.lastAccuracy}% Acc` : 'Weak Recall'} • {t.confidenceRating || 2}★
                                </span>
                              </div>
                              <p className="text-xs font-semibold leading-snug">{t.subheading}</p>
                              <button
                                onClick={() => toggleWrittenInPhysical20th('topic', t.id)}
                                className={`w-full py-1.5 rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1 ${
                                  t.writtenInPhysicalCopy
                                    ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                                    : 'bg-amber-500/15 text-amber-700 dark:text-amber-300 hover:bg-amber-500 hover:text-white'
                                }`}
                              >
                                {t.writtenInPhysicalCopy ? '✓ Written in Physical 20th NB' : '📓 Mark Written in Physical Copy'}
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Column 2: Bookmarks Missed After 4th-Day Cool-Down */}
                    <div className="p-4 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/70 dark:border-neutral-800 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-violet-600 dark:text-violet-400">
                          2. Missed Bookmark MCQs ({physical20thCuratedList.bookmarks.length})
                        </span>
                        <span className="text-[10px] text-neutral-400">Missed ≥1× post-cooldown</span>
                      </div>
                      {physical20thCuratedList.bookmarks.length === 0 ? (
                        <p className="text-xs text-neutral-400 py-4 text-center">No missed bookmarks flagged yet.</p>
                      ) : (
                        <div className="space-y-2">
                          {physical20thCuratedList.bookmarks.map(bm => (
                            <div key={bm.id} className="p-2.5 rounded-xl bg-white dark:bg-[#121216] border border-neutral-200/60 dark:border-neutral-800 space-y-1.5">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-violet-600 dark:text-violet-400">{bm.mcqId} ({bm.subject})</span>
                                <span className="text-[10px] font-bold text-rose-500">Missed {bm.missCount || 1}×</span>
                              </div>
                              <p className="text-xs text-neutral-700 dark:text-neutral-200 leading-snug">{bm.pearl}</p>
                              <button
                                onClick={() => toggleWrittenInPhysical20th('bookmark', bm.id)}
                                className={`w-full py-1.5 rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1 ${
                                  bm.writtenInPhysicalCopy
                                    ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                                    : 'bg-amber-500/15 text-amber-700 dark:text-amber-300 hover:bg-amber-500 hover:text-white'
                                }`}
                              >
                                {bm.writtenInPhysicalCopy ? '✓ Written in Physical 20th NB' : '📓 Mark Written in Physical Copy'}
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Column 3: Clinical Pearls Poorly Retained / High 5-Yr PYQ Frequency */}
                    <div className="p-4 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/70 dark:border-neutral-800 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
                          3. High-Yield / Missed Pearls ({physical20thCuratedList.pearls.length})
                        </span>
                        <span className="text-[10px] text-neutral-400">5-Yr PYQ + Low Retention</span>
                      </div>
                      {physical20thCuratedList.pearls.length === 0 ? (
                        <p className="text-xs text-neutral-400 py-4 text-center">No pearls flagged yet.</p>
                      ) : (
                        <div className="space-y-2">
                          {physical20thCuratedList.pearls.map(p => (
                            <div key={p.id} className="p-2.5 rounded-xl bg-white dark:bg-[#121216] border border-neutral-200/60 dark:border-neutral-800 space-y-1.5">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">{p.pearlCode} ({p.subject})</span>
                                <span className="text-[10px] font-bold text-amber-600">Asked {p.pyqAskCount5Yr}× in 5Yrs</span>
                              </div>
                              <p className="text-xs text-neutral-700 dark:text-neutral-200 leading-snug">{p.pearl}</p>
                              <button
                                onClick={() => toggleWrittenInPhysical20th('pearl', p.id)}
                                className={`w-full py-1.5 rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1 ${
                                  p.writtenInPhysicalCopy
                                    ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                                    : 'bg-amber-500/15 text-amber-700 dark:text-amber-300 hover:bg-amber-500 hover:text-white'
                                }`}
                              >
                                {p.writtenInPhysicalCopy ? '✓ Written in Physical 20th NB' : '📓 Mark Written in Physical Copy'}
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Quick-Add Forms for Bookmarks & Pearls */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {(bmSubView === 'both' || bmSubView === 'bookmarks') && (
                  <form
                    onSubmit={handleAddBookmark}
                    className="bg-white dark:bg-[#121216] rounded-[30px] p-4 sm:p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <h2 className="text-sm sm:text-base font-bold flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400">
                        <Bookmark className="w-4 h-4" /> Log Bookmark MCQ (4-Day Cool-Down + Spaced Loop)
                      </h2>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        value={bmMcqId}
                        onChange={e => setBmMcqId(e.target.value)}
                        placeholder="MCQ ID (e.g. MRW-MED-4821)"
                        className="h-10 px-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-semibold focus:outline-none"
                        required
                      />
                      <select
                        value={bmSubject}
                        onChange={e => setBmSubject(e.target.value)}
                        className="h-10 px-3 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-semibold"
                      >
                        {SUBJECTS_DB.map(s => (
                          <option key={s.name} value={s.name}>
                            {s.name} ({s.pyqWeightage}% PYQ)
                          </option>
                        ))}
                      </select>
                      <select
                        value={bmRule}
                        onChange={e => setBmRule(e.target.value)}
                        className="h-10 px-3 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-semibold"
                      >
                        <option value="1-Strike">Concept Gap (2-Stage Spaced)</option>
                        <option value="2-Strike">Volatile / IBQ (3-Stage Spaced)</option>
                      </select>
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={bmPearl}
                        onChange={e => setBmPearl(e.target.value)}
                        placeholder="1-Line discriminator / why option tricked you..."
                        className="flex-1 h-10 px-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs focus:outline-none"
                        required
                      />
                      <button
                        type="submit"
                        className="px-4 h-10 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shrink-0 transition"
                      >
                        + Lock 4d
                      </button>
                    </div>
                  </form>
                )}

                {(bmSubView === 'both' || bmSubView === 'pearls') && (
                  <form
                    onSubmit={handleAddSpacedPearl}
                    className="bg-white dark:bg-[#121216] rounded-[30px] p-4 sm:p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <h2 className="text-sm sm:text-base font-bold flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                        <BookOpen className="w-4 h-4" /> Log Clinical Pearl + Pearl-Linked MCQs Track
                      </h2>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <select
                        value={pearlSubject}
                        onChange={e => setPearlSubject(e.target.value)}
                        className="h-10 px-3 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-semibold"
                      >
                        {SUBJECTS_DB.map(s => (
                          <option key={s.name} value={s.name}>
                            {s.name} ({s.pyqWeightage}% PYQ)
                          </option>
                        ))}
                      </select>
                      <input
                        type="text"
                        value={pearlLinkedMcqs}
                        onChange={e => setPearlLinkedMcqs(e.target.value)}
                        placeholder="Linked MCQ IDs (e.g. INI-24-Q12)"
                        className="h-10 px-3 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-semibold focus:outline-none"
                      />
                      <select
                        value={pearlPyqFreq}
                        onChange={e => setPearlPyqFreq(e.target.value)}
                        className="h-10 px-3 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-semibold"
                      >
                        <option value={7}>Asked 7+ times in 5 Yrs (Ultra)</option>
                        <option value={5}>Asked 5–6 times in 5 Yrs (High)</option>
                        <option value={3}>Asked 3–4 times in 5 Yrs (Core)</option>
                      </select>
                    </div>

                    <input
                      type="text"
                      value={pearlMcqQuestion}
                      onChange={e => setPearlMcqQuestion(e.target.value)}
                      placeholder="Optional Pearl-Related MCQ stem / clinical vignette..."
                      className="w-full h-9 px-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs focus:outline-none"
                    />

                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={pearlText}
                        onChange={e => setPearlText(e.target.value)}
                        placeholder="High-yield Clinical Pearl statement / answer..."
                        className="flex-1 h-10 px-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs focus:outline-none"
                        required
                      />
                      <button
                        type="submit"
                        className="px-4 h-10 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shrink-0 transition"
                      >
                        + Track Pearl
                      </button>
                    </div>
                  </form>
                )}
              </div>

              {/* Bookmark Spaced Track */}
              {(bmSubView === 'both' || bmSubView === 'bookmarks') && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400">
                        <Unlock className="w-4 h-4" /> Bookmark MCQs Due for Spaced Recall ({dueTonightBookmarks.length})
                      </h3>
                    </div>

                    {dueTonightBookmarks.length === 0 ? (
                      <p className="text-xs text-neutral-400 py-8 text-center">No bookmark MCQs due for {formatHumanDate(selectedDate)}.</p>
                    ) : (
                      <div className="space-y-3">
                        {dueTonightBookmarks.map(bm => {
                          const subjObj = getSubjectObj(bm.subject);
                          const reqStrikes = bm.rule === '1-Strike' ? 2 : 3;
                          return (
                            <div key={bm.id} className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/70 dark:border-neutral-800 space-y-2.5">
                              <div className="flex flex-wrap items-center justify-between gap-1">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-xs font-extrabold text-indigo-600 dark:text-indigo-400">{bm.mcqId}</span>
                                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${BUCKET_CONFIG[subjObj.bucket].bgLight}`}>
                                    Bucket {subjObj.bucket} • {bm.subject}
                                  </span>
                                  {bm.writtenInPhysicalCopy && (
                                    <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-700 text-[10px] font-bold">
                                      📓 In Physical 20th NB
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] font-bold text-neutral-400">
                                  Streak: {bm.strikes || 0}/{reqStrikes} • Misses: {bm.missCount || 0}
                                </span>
                              </div>

                              <p className="text-xs text-neutral-800 dark:text-neutral-200 leading-relaxed">{bm.pearl}</p>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                                <button
                                  onClick={() => handleBookmarkReviewOutcome(bm, true)}
                                  className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition"
                                >
                                  ✓ Solved Correct After Day 4
                                </button>
                                <button
                                  onClick={() => handleBookmarkReviewOutcome(bm, false)}
                                  className="py-2 px-3 rounded-xl bg-rose-500/15 hover:bg-rose-600 hover:text-white text-rose-600 dark:text-rose-300 text-xs font-bold transition"
                                >
                                  ✗ Did Wrong → Spaced Loop & 20th NB
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
                        <Lock className="w-4 h-4" /> In 4-Day Cool-Down & Future Spaced Queue ({coolingBookmarks.length})
                      </h3>
                    </div>

                    {coolingBookmarks.length === 0 ? (
                      <p className="text-xs text-neutral-400 py-8 text-center">No bookmarks in future cool-down lock.</p>
                    ) : (
                      <div className="space-y-2.5">
                        {coolingBookmarks.map(bm => {
                          const rem = Math.max(1, diffDays(selectedDate, bm.dueDate));
                          return (
                            <div key={bm.id} className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/60 dark:border-neutral-800 space-y-1.5">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold">{bm.mcqId} • {bm.subject}</span>
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600">
                                  Due in {rem}d ({formatHumanDate(bm.dueDate)})
                                </span>
                              </div>
                              <p className="text-xs text-neutral-500 dark:text-neutral-400">{bm.pearl}</p>
                              <div className="flex items-center justify-between pt-1">
                                <span className="text-[10px] text-neutral-400">{bm.lastResult}</span>
                                <button
                                  onClick={() => handleUnlockBookmarkEarly(bm.id)}
                                  className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                                >
                                  Test Tonight →
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Clinical Pearls & Linked MCQs Spaced Track */}
              {(bmSubView === 'both' || bmSubView === 'pearls') && (
                <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="text-base font-bold flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
                      <Sparkles className="w-4 h-4" /> Clinical Pearls & Pearl-Linked MCQs Spaced Track
                    </h3>
                    <span className="px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-600 text-xs font-bold">
                      {dueTonightPearls.length} Due Now • {scheduledFuturePearls.length} Upcoming
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {appData.notebookPearls.map(prl => {
                      const isDue = prl.status !== 'mastered' && (prl.dueDate || selectedDate) <= selectedDate;
                      const isMastered = prl.status === 'mastered';
                      const showMcq = !!expandedPearlMcq[prl.id];

                      return (
                        <div
                          key={prl.id}
                          className={`p-4 rounded-3xl border transition flex flex-col justify-between gap-3 ${
                            isMastered
                              ? 'bg-emerald-500/[0.04] border-emerald-500/20 opacity-75'
                              : isDue
                              ? 'bg-[#F8F8FA] dark:bg-[#18181F] border-emerald-500/40 shadow-xs'
                              : 'bg-[#F8F8FA] dark:bg-[#18181F] border-neutral-200/60 dark:border-neutral-800'
                          }`}
                        >
                          <div className="space-y-2">
                            <div className="flex flex-wrap items-center justify-between gap-1">
                              <div className="flex items-center gap-1.5">
                                <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-black">
                                  {prl.pearlCode || 'PEARL'}
                                </span>
                                <span className="text-xs font-bold">{prl.subject}</span>
                                <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-700 dark:text-amber-300 text-[10px] font-bold">
                                  Asked {prl.pyqAskCount5Yr || 5}× in 5 Yrs
                                </span>
                              </div>
                              <span className="text-[10px] font-extrabold text-indigo-600 dark:text-indigo-400">
                                {isMastered ? '★ MASTERED' : `Stage ${(prl.stageIndex || 0) + 1}/${prl.maxStage || 4}`}
                              </span>
                            </div>

                            <div className="flex items-center gap-1">
                              {Array.from({ length: prl.maxStage || 4 }, (_, idx) => (
                                <div
                                  key={idx}
                                  className={`h-1.5 flex-1 rounded-full ${
                                    idx <= (prl.stageIndex || 0) ? 'bg-emerald-500' : 'bg-neutral-200 dark:bg-neutral-700'
                                  }`}
                                />
                              ))}
                            </div>

                            <p className="text-xs text-neutral-800 dark:text-neutral-200 font-medium leading-relaxed">
                              {prl.pearl}
                            </p>

                            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                              <div className="flex flex-wrap gap-1">
                                {(prl.linkedMcqIds || ['INI-PYQ']).map((idStr, idx) => (
                                  <span
                                    key={idx}
                                    className="px-2 py-0.5 rounded-md bg-violet-500/12 text-violet-700 dark:text-violet-300 text-[10px] font-bold"
                                  >
                                    🔗 MCQ: {idStr}
                                  </span>
                                ))}
                              </div>
                              <button
                                onClick={() => setExpandedPearlMcq(prev => ({ ...prev, [prl.id]: !prev[prl.id] }))}
                                className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                              >
                                {showMcq ? 'Hide Linked MCQ ▲' : 'Test Linked Pearl MCQ ▼'}
                              </button>
                            </div>

                            {showMcq && (
                              <div className="p-3 rounded-2xl bg-white dark:bg-[#121216] border border-indigo-500/25 space-y-1.5 text-xs">
                                <p className="font-semibold text-neutral-700 dark:text-neutral-200">
                                  <strong>Pearl MCQ Stem:</strong> {prl.mcqPrompt}
                                </p>
                                <p className="text-emerald-600 dark:text-emerald-400 font-bold">
                                  <strong>Target Answer:</strong> {prl.mcqAnswer || prl.pearl}
                                </p>
                              </div>
                            )}
                          </div>

                          {!isMastered && (
                            <div className="pt-2 border-t border-neutral-200/60 dark:border-neutral-800 flex items-center justify-between gap-2">
                              <span className="text-[10px] font-semibold text-neutral-400">
                                Due: {formatHumanDate(prl.dueDate || selectedDate)}
                              </span>
                              <div className="flex gap-1.5">
                                <button
                                  onClick={() => handlePearlReviewOutcome(prl, true)}
                                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition"
                                >
                                  ✓ Revised & Solved MCQ
                                </button>
                                <button
                                  onClick={() => handlePearlReviewOutcome(prl, false)}
                                  className="px-2.5 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-600 hover:text-white text-rose-600 dark:text-rose-300 text-[11px] font-bold transition"
                                >
                                  ✗ Repeat & 20th NB
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ==================================================================
              TAB 4: DYNAMIC BACKLOGS INDEX & 4-VS-5 REVISION RUNWAY TO MAY 20
             ================================================================== */}
          {activeTab === 'backlogs' && (
            <div className="space-y-4">
              {/* Macro Runway Roadmap Card (Phase 1 Dec 31 -> Buffer Jan 15 -> Phase 2 -> May 20 Exam) */}
              <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-3.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h2 className="text-base sm:text-lg font-bold">
                      4-vs-5 Revision Runway Architecture (Phase 1 Ends Dec 31 • Buffer Ends Jan 15 • Exam May 20)
                    </h2>
                    <p className="text-xs text-neutral-500">
                      Normal conceptual/visual topics complete 4 spaced revisions; Weak (&lt;68% GT or &lt;75% at Rev 2) and Volatile Bucket A topics complete 5 spaced revisions + daily 30-min Physical 20th Notebook review.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {MACRO_RUNWAY_PHASES.map(phase => {
                    const isCurrent = activeMacroPhase.id === phase.id;
                    return (
                      <div
                        key={phase.id}
                        className={`p-3.5 rounded-2xl border transition flex flex-col justify-between gap-2 ${
                          isCurrent
                            ? 'bg-indigo-600/10 border-indigo-500 shadow-xs'
                            : 'bg-[#F8F8FA] dark:bg-[#18181F] border-neutral-200/60 dark:border-neutral-800'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-600 dark:text-indigo-300">
                              {phase.badge}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-bold text-emerald-600">● Active Phase</span>
                            )}
                          </div>
                          <h4 className="text-xs font-bold mt-1">{phase.title}</h4>
                          <p className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400">{phase.range}</p>
                          <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-snug">{phase.detail}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 4-Pillar Daily & Cumulative Completion KPIs */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                {[
                  {
                    title: '1. Subjects & Subtopics',
                    completed: appData.topics.filter(t => t.lastAccuracy !== null && t.nextReviewDate > selectedDate).length,
                    pendingToday: selectedDayTopics.length,
                    backlogs: dynamicBacklogs.overdueTopics.length,
                    color: 'text-indigo-600 dark:text-indigo-400'
                  },
                  {
                    title: '2. Bookmark MCQs',
                    completed: appData.bookmarks.filter(b => b.status === 'cleared' || b.strikes > 0).length,
                    pendingToday: selectedDayBookmarks.length,
                    backlogs: dynamicBacklogs.overdueBookmarks.length,
                    color: 'text-violet-600 dark:text-violet-400'
                  },
                  {
                    title: '3. Clinical Pearls & MCQs',
                    completed: appData.notebookPearls.filter(p => p.status === 'mastered' || (p.stageIndex || 0) > 0).length,
                    pendingToday: selectedDayPearls.length,
                    backlogs: dynamicBacklogs.overduePearls.length,
                    color: 'text-emerald-600 dark:text-emerald-400'
                  },
                  {
                    title: '4. Physical 20th Notebook',
                    completed: physical20thCuratedList.totalWritten,
                    pendingToday: physical20thCuratedList.totalEligible - physical20thCuratedList.totalWritten,
                    backlogs: 0,
                    color: 'text-amber-600 dark:text-amber-400'
                  }
                ].map((card, i) => (
                  <div key={i} className="bg-white dark:bg-[#121216] rounded-[28px] p-4 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-2">
                    <span className="text-xs font-bold text-neutral-500">{card.title}</span>
                    <div className="flex items-baseline justify-between">
                      <div>
                        <span className={`text-2xl font-black ${card.color}`}>{card.completed}</span>
                        <span className="text-[11px] text-neutral-400 ml-1">completed</span>
                      </div>
                      {card.backlogs > 0 ? (
                        <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold">
                          {card.backlogs} Backlog
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 text-[10px] font-bold">
                          0 Backlog ✓
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-400">
                      Pending Action Today: <strong>{card.pendingToday}</strong>
                    </p>
                  </div>
                ))}
              </div>

              {/* Dynamic Bucket-Wise Backlogs Index */}
              <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h2 className="text-base sm:text-lg font-bold">
                      Dynamic Bucket-Wise Backlogs Index ({dynamicBacklogs.totalCount} Active Backlogs)
                    </h2>
                    <p className="text-xs text-neutral-500">
                      Select any backlog below to complete it now or pull it into Today's Active Queue. Once completed, it automatically disappears from this index!
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {[
                      { id: 'ALL', label: `All (${dynamicBacklogs.totalCount})` },
                      { id: 'INTEGRATED', label: '7 Integrated' },
                      { id: 'A', label: 'Bucket A' },
                      { id: 'B', label: 'Bucket B' },
                      { id: 'C', label: 'Bucket C' },
                      { id: 'BOOKMARKS', label: `Bookmarks (${dynamicBacklogs.overdueBookmarks.length})` },
                      { id: 'PEARLS', label: `Pearls (${dynamicBacklogs.overduePearls.length})` }
                    ].map(f => (
                      <button
                        key={f.id}
                        onClick={() => setBacklogBucketFilter(f.id)}
                        className={`px-3 py-1 rounded-full text-xs font-bold transition ${
                          backlogBucketFilter === f.id
                            ? 'bg-indigo-600 text-white'
                            : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-500'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                </div>

                {dynamicBacklogs.totalCount === 0 ? (
                  <div className="py-12 text-center space-y-2">
                    <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
                    <h3 className="text-sm font-bold">Zero Backlogs Pending!</h3>
                    <p className="text-xs text-neutral-400">
                      All past subjects, bookmarks, clinical pearls, and Sunday GTs up to {formatHumanDate(selectedDate)} are 100% completed.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {dynamicBacklogs.overdueTopics
                      .filter(t => {
                        if (backlogBucketFilter === 'ALL') return true;
                        if (backlogBucketFilter === 'INTEGRATED') return getSubjectObj(t.subject).isIntegrated;
                        return t.bucket === backlogBucketFilter;
                      })
                      .map(item => {
                        const overdueDays = diffDays(item.nextReviewDate, selectedDate);
                        const subjObj = getSubjectObj(item.subject);
                        const revInfo = getTopicRevisionTarget(item, appData.subjectStats);
                        return (
                          <div
                            key={item.id}
                            className="p-4 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-rose-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                          >
                            <div className="space-y-1">
                              <div className="flex flex-wrap items-center gap-1.5">
                                <span className="px-2 py-0.5 rounded-md bg-rose-500 text-white text-[10px] font-extrabold">
                                  TOPIC BACKLOG • {overdueDays}d Overdue
                                </span>
                                <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${BUCKET_CONFIG[item.bucket].bgLight}`}>
                                  {subjObj.isIntegrated ? 'Integrated System' : `Bucket ${item.bucket}`} • {item.subject}
                                </span>
                                <span className="px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-600 text-[10px] font-bold">
                                  Rev {revInfo.completedRevisions}/{revInfo.targetRevisions} Track
                                </span>
                              </div>
                              <h4 className="text-sm font-bold">{item.subheading}</h4>
                              <p className="text-[11px] text-neutral-500">
                                Was due on {formatHumanDate(item.nextReviewDate)} • Stage {item.stageIndex + 1}
                              </p>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                onClick={() => handlePullBacklogToToday('topic', item)}
                                className="px-3 py-2 rounded-xl bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 text-xs font-bold transition"
                              >
                                Pull to Today
                              </button>
                              <button
                                onClick={() => handleCompleteBacklogItem('topic', item)}
                                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1"
                              >
                                <Check className="w-3.5 h-3.5" /> Complete & Advance
                              </button>
                            </div>
                          </div>
                        );
                      })}

                    {(backlogBucketFilter === 'ALL' || backlogBucketFilter === 'BOOKMARKS') &&
                      dynamicBacklogs.overdueBookmarks.map(bm => {
                        const overdueDays = diffDays(bm.dueDate, selectedDate);
                        return (
                          <div
                            key={bm.id}
                            className="p-4 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-violet-500/35 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                          >
                            <div className="space-y-1">
                              <div className="flex items-center gap-1.5">
                                <span className="px-2 py-0.5 rounded-md bg-violet-600 text-white text-[10px] font-extrabold">
                                  BOOKMARK BACKLOG • {overdueDays}d Overdue
                                </span>
                                <span className="text-xs font-bold">{bm.mcqId} ({bm.subject})</span>
                              </div>
                              <p className="text-xs text-neutral-700 dark:text-neutral-200">{bm.pearl}</p>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                onClick={() => handlePullBacklogToToday('bookmark', bm)}
                                className="px-3 py-2 rounded-xl bg-neutral-200 dark:bg-neutral-800 text-xs font-bold"
                              >
                                Pull to Today
                              </button>
                              <button
                                onClick={() => handleCompleteBacklogItem('bookmark', bm)}
                                className="px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold"
                              >
                                ✓ Solved Correct
                              </button>
                            </div>
                          </div>
                        );
                      })}

                    {(backlogBucketFilter === 'ALL' || backlogBucketFilter === 'PEARLS') &&
                      dynamicBacklogs.overduePearls.map(prl => {
                        const overdueDays = diffDays(prl.dueDate, selectedDate);
                        return (
                          <div
                            key={prl.id}
                            className="p-4 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-emerald-500/35 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                          >
                            <div className="space-y-1">
                              <div className="flex items-center gap-1.5">
                                <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-extrabold">
                                  PEARL BACKLOG • {overdueDays}d Overdue
                                </span>
                                <span className="text-xs font-bold">{prl.pearlCode} ({prl.subject})</span>
                              </div>
                              <p className="text-xs text-neutral-700 dark:text-neutral-200">{prl.pearl}</p>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                onClick={() => handlePullBacklogToToday('pearl', prl)}
                                className="px-3 py-2 rounded-xl bg-neutral-200 dark:bg-neutral-800 text-xs font-bold"
                              >
                                Pull to Today
                              </button>
                              <button
                                onClick={() => handleCompleteBacklogItem('pearl', prl)}
                                className="px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold"
                              >
                                ✓ Revised Pearl & MCQ
                              </button>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ==================================================================
              TAB 5: MULTI-PARAMETER GT ANALYTICS & 26-SUBJECT (19+7) MATRIX
             ================================================================== */}
          {activeTab === 'analytics' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                {(() => {
                  const latestGt = appData.gtList[appData.gtList.length - 1];
                  return [
                    { label: 'Latest Net Score', val: latestGt ? `${latestGt.netScore}/200` : '0/200', sub: 'Target: ≥150 (75%)', color: 'text-indigo-600' },
                    { label: 'Negative Bleed', val: latestGt ? `-${latestGt.bleed}m` : '0m', sub: 'Target: <7.0 marks', color: 'text-rose-500' },
                    { label: '1st-Pass Accuracy', val: latestGt ? `${latestGt.firstPassAcc || 88}%` : '—', sub: 'Target: ≥90%', color: 'text-emerald-600' },
                    { label: '50:50 Option Conv.', val: latestGt ? `${latestGt.fiftyFiftyConversion || 72}%` : '—', sub: '2-Option Ruled Out', color: 'text-violet-600' },
                    { label: 'Avg Pacing / MCQ', val: latestGt ? `${latestGt.avgSecPerMcq || 41}s` : '—', sub: 'Target: ≤42s/MCQ', color: 'text-sky-600' },
                    { label: 'Weak Subj (<68%)', val: `${weakSubjectsList.length} / 26`, sub: '⚡ 0.8× + 5-Rev Track', color: 'text-amber-500' }
                  ].map((kpi, idx) => (
                    <div key={idx} className="bg-white dark:bg-[#121216] rounded-2xl p-3.5 border border-neutral-200/60 dark:border-neutral-800">
                      <span className="text-[10px] font-bold uppercase text-neutral-400">{kpi.label}</span>
                      <p className={`text-lg font-black mt-0.5 ${kpi.color}`}>{kpi.val}</p>
                      <p className="text-[10px] text-neutral-500">{kpi.sub}</p>
                    </div>
                  ));
                })()}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                <div className="lg:col-span-5 space-y-4">
                  <form
                    onSubmit={handleLogGT}
                    className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-3"
                  >
                    <h2 className="text-base font-bold">Multi-Parameter Sunday GT Logger (-1/3 Engine)</h2>
                    <div className="grid grid-cols-2 gap-2.5">
                      <div className="col-span-2">
                        <label className="text-[11px] font-semibold text-neutral-500">GT Name</label>
                        <input
                          type="text"
                          value={gtName}
                          onChange={e => setGtName(e.target.value)}
                          placeholder="e.g. INI-CET National Mock #6"
                          className="w-full h-9 px-3 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-neutral-500">Date</label>
                        <input
                          type="date"
                          value={gtDate}
                          onChange={e => setGtDate(e.target.value)}
                          className="w-full h-9 px-3 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-neutral-500">Avg Sec / MCQ</label>
                        <input
                          type="number"
                          value={gtAvgSec}
                          onChange={e => setGtAvgSec(e.target.value)}
                          className="w-full h-9 px-3 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-emerald-600">Correct (/200)</label>
                        <input
                          type="number"
                          min="0"
                          max="200"
                          value={gtCorrect}
                          onChange={e => setGtCorrect(e.target.value)}
                          className="w-full h-9 px-3 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-rose-600">Wrong (-1/3 Bleed)</label>
                        <input
                          type="number"
                          min="0"
                          max="200"
                          value={gtWrong}
                          onChange={e => setGtWrong(e.target.value)}
                          className="w-full h-9 px-3 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-indigo-600">1st-Pass Acc (%)</label>
                        <input
                          type="number"
                          value={gtFirstPassAcc}
                          onChange={e => setGtFirstPassAcc(e.target.value)}
                          className="w-full h-9 px-3 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-violet-600">50:50 Guess Conv (%)</label>
                        <input
                          type="number"
                          value={gtFiftyFiftyConv}
                          onChange={e => setGtFiftyFiftyConv(e.target.value)}
                          className="w-full h-9 px-3 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold mt-0.5"
                        />
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-neutral-500 block">Computed Net Score</span>
                        <strong className="text-base text-indigo-600 dark:text-indigo-400">
                          {(Number(gtCorrect) - Number(gtWrong) / 3).toFixed(1)} / 200 ({(((Number(gtCorrect) - Number(gtWrong) / 3) / 200) * 100).toFixed(1)}%)
                        </strong>
                      </div>
                      <div className="text-right">
                        <span className="text-neutral-500 block">Negative Bleed</span>
                        <strong className="text-base text-rose-500">-{(Number(gtWrong) / 3).toFixed(1)} marks</strong>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition"
                    >
                      + Save Multi-Parameter Sunday GT
                    </button>
                  </form>

                  <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-2.5">
                    <h3 className="text-sm font-bold">Samsung / Google Calendar Sync</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => openGoogleCalendarBlock('morning')}
                        className="py-2 px-3 rounded-2xl bg-indigo-500/12 text-indigo-600 dark:text-indigo-300 text-xs font-bold"
                      >
                        Push 08:30 AM Block
                      </button>
                      <button
                        onClick={() => openGoogleCalendarBlock('evening')}
                        className="py-2 px-3 rounded-2xl bg-violet-500/12 text-violet-600 dark:text-violet-300 text-xs font-bold"
                      >
                        Push 09:00 PM Block
                      </button>
                    </div>
                    <button
                      onClick={handleExportICS}
                      className="w-full py-2.5 rounded-2xl bg-neutral-900 dark:bg-white text-white dark:text-black text-xs font-bold flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4" /> Download .ICS Calendar File
                    </button>
                  </div>
                </div>

                <div className="lg:col-span-7 bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 flex flex-col justify-between">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                    <div>
                      <h3 className="text-base font-bold">GT Net Score Trajectory vs. 150/200 (75% AIIMS New Delhi Cutoff)</h3>
                      <p className="text-xs text-neutral-500">Indigo curve = Net Score (/200) • Red bottom bars = Negative Marking Bleed</p>
                    </div>
                    <span className="px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-600 text-xs font-bold">
                      Target: ≥150 / 200
                    </span>
                  </div>

                  {appData.gtList.length === 0 ? (
                    <div className="h-64 flex flex-col items-center justify-center text-center space-y-2">
                      <BarChart3 className="w-10 h-10 text-neutral-300" />
                      <p className="text-xs text-neutral-400">No Grand Tests logged yet. Log a GT on the left or click "Load Sample".</p>
                    </div>
                  ) : (
                    <div className="relative h-72 w-full">
                      <svg viewBox="0 0 600 240" className="w-full h-full overflow-visible">
                        {[50, 100, 150, 200].map(val => {
                          const y = 200 - (val / 200) * 170;
                          return (
                            <g key={val}>
                              <line
                                x1="40"
                                y1={y}
                                x2="570"
                                y2={y}
                                stroke={val === 150 ? '#10B981' : '#9CA3AF'}
                                strokeOpacity={val === 150 ? '0.8' : '0.2'}
                                strokeDasharray={val === 150 ? '6 4' : ''}
                                strokeWidth={val === 150 ? '2' : '1'}
                              />
                              <text x="8" y={y + 4} className="fill-neutral-400 text-[10px] font-bold">
                                {val}
                              </text>
                            </g>
                          );
                        })}
                        <text x="435" y={200 - (150 / 200) * 170 - 6} className="fill-emerald-500 text-[10px] font-bold">
                          AIIMS Delhi Target (150/200)
                        </text>

                        {(() => {
                          const pts = appData.gtList.map((g, idx) => {
                            const x = appData.gtList.length === 1
                              ? 300
                              : 65 + (idx / (appData.gtList.length - 1)) * 480;
                            const y = 200 - (Math.max(0, g.netScore) / 200) * 170;
                            const bleedH = Math.min(50, g.bleed * 1.8);
                            return { ...g, x, y, bleedH };
                          });
                          const polyPoints = pts.map(p => `${p.x},${p.y}`).join(' ');

                          return (
                            <>
                              {pts.length > 1 && (
                                <polyline
                                  fill="none"
                                  stroke="#4F46E5"
                                  strokeWidth="3.5"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  points={polyPoints}
                                />
                              )}
                              {pts.map((p) => (
                                <g key={p.id}>
                                  <rect
                                    x={p.x - 12}
                                    y={205 - p.bleedH}
                                    width="24"
                                    height={p.bleedH}
                                    rx="4"
                                    fill="#F43F5E"
                                    fillOpacity="0.35"
                                  />
                                  <text x={p.x} y="218" textAnchor="middle" className="fill-rose-500 text-[9px] font-bold">
                                    -{p.bleed}
                                  </text>
                                  <text x={p.x} y="232" textAnchor="middle" className="fill-neutral-400 text-[9px]">
                                    {p.date.slice(5)}
                                  </text>
                                  <circle cx={p.x} cy={p.y} r="6" className="fill-indigo-600 stroke-white dark:stroke-black stroke-2" />
                                  <text x={p.x} y={p.y - 10} textAnchor="middle" className="fill-neutral-800 dark:fill-white text-[10px] font-extrabold">
                                    {p.netScore}
                                  </text>
                                </g>
                              ))}
                            </>
                          );
                        })()}
                      </svg>
                    </div>
                  )}
                </div>
              </div>

              {/* 26-Subject Multi-Parameter Accuracy Matrix */}
              <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-base font-bold">
                      26-Subject Multi-Parameter Accuracy Matrix (7 Integrated Systems + 19 Subjects)
                    </h3>
                    <p className="text-xs text-neutral-500">
                      Any subject below 68% GT accuracy automatically activates 0.8× interval compression AND switches all its topics to the 5-Revision Track before May 20.
                    </p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-rose-500/15 text-rose-600 dark:text-rose-300 text-xs font-bold">
                    ⚡ {weakSubjectsList.length} Subjects in 0.8× / 5-Rev Mode
                  </span>
                </div>

                <div className="space-y-2">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                    Part A: 7 Separate Integrated Clinical Systems
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {SUBJECTS_DB.filter(s => s.isIntegrated).map(subj => {
                      const stat = appData.subjectStats?.[subj.name] || { gtAccuracy: 78, moduleAvg: 85 };
                      const isRedZone = stat.gtAccuracy < 68;
                      const pressureGap = stat.moduleAvg - stat.gtAccuracy;

                      return (
                        <div
                          key={subj.name}
                          className={`p-3.5 rounded-2xl border transition ${
                            isRedZone
                              ? 'bg-rose-500/[0.07] border-rose-500/35'
                              : 'bg-indigo-500/[0.04] dark:bg-[#18181F] border-indigo-500/20'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1 mb-1">
                            <span className="text-xs font-extrabold truncate">{subj.name}</span>
                            {isRedZone ? (
                              <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold shrink-0">
                                ⚡ 5-Rev ({stat.gtAccuracy}%)
                              </span>
                            ) : (
                              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                                4-Rev ({stat.gtAccuracy}%)
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] font-semibold text-indigo-600 dark:text-indigo-300 mb-1.5">
                            5–7Yr INI-CET Wt: {subj.pyqWeightage}% ({subj.avgQuestions})
                          </div>
                          <input
                            type="range"
                            min="35"
                            max="98"
                            value={stat.gtAccuracy}
                            onChange={e => updateSubjectStatField(subj.name, 'gtAccuracy', e.target.value)}
                            className="w-full accent-indigo-600 cursor-pointer"
                          />
                          <div className="flex items-center justify-between text-[10px] text-neutral-500 mt-1">
                            <span>Untimed: {stat.moduleAvg}%</span>
                            <span>Gap: {pressureGap > 0 ? `+${pressureGap}%` : `${pressureGap}%`}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-neutral-500">
                    Part B: 19 Classic INI-CET Subjects (Bucket A, B & C)
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {SUBJECTS_DB.filter(s => !s.isIntegrated).map(subj => {
                      const stat = appData.subjectStats?.[subj.name] || { gtAccuracy: 74, moduleAvg: 82 };
                      const isRedZone = stat.gtAccuracy < 68;
                      const isFiveRev = isRedZone || subj.bucket === 'A';
                      const pressureGap = stat.moduleAvg - stat.gtAccuracy;

                      return (
                        <div
                          key={subj.name}
                          className={`p-3.5 rounded-2xl border transition ${
                            isRedZone
                              ? 'bg-rose-500/[0.07] border-rose-500/35'
                              : 'bg-[#F8F8FA] dark:bg-[#18181F] border-neutral-200/60 dark:border-neutral-800'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1 mb-1">
                            <span className="text-xs font-bold truncate">
                              [Bkt {subj.bucket}] {subj.name}
                            </span>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0 ${
                              isFiveRev ? 'bg-rose-500 text-white' : 'bg-emerald-500/15 text-emerald-600'
                            }`}>
                              {isFiveRev ? `5-Rev (${stat.gtAccuracy}%)` : `4-Rev (${stat.gtAccuracy}%)`}
                            </span>
                          </div>
                          <div className="text-[10px] text-neutral-400 mb-1">
                            5–7Yr INI-CET Weight: <strong>{subj.pyqWeightage}% ({subj.avgQuestions})</strong>
                          </div>
                          <input
                            type="range"
                            min="35"
                            max="98"
                            value={stat.gtAccuracy}
                            onChange={e => updateSubjectStatField(subj.name, 'gtAccuracy', e.target.value)}
                            className="w-full accent-indigo-600 cursor-pointer"
                          />
                          <div className="flex items-center justify-between text-[10px] text-neutral-500 mt-1">
                            <span>Untimed Q-Bank: {stat.moduleAvg}%</span>
                            <span>Pressure Gap: {pressureGap > 0 ? `+${pressureGap}%` : `${pressureGap}%`}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================================
              TAB 6: COMPANION NEURO-HYPERTROPHY & CORTISOL-SHIELD GYM TRACKER
             ================================================================== */}
          {activeTab === 'gym' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="inline-flex p-1 rounded-full bg-neutral-200/75 dark:bg-[#17171C]">
                  {[
                    { id: 'floor', label: '1. Main Gym Floor' },
                    { id: 'overload', label: '2. Progressive Overload' },
                    { id: 'weight', label: '3. Body Weight & Time' },
                    { id: 'history', label: '4. Session Log' }
                  ].map(t => (
                    <button
                      key={t.id}
                      onClick={() => setGymSubTab(t.id)}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition ${
                        gymSubTab === t.id
                          ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-sm'
                          : 'text-neutral-600 dark:text-neutral-400'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                <div className={`px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                  gymDurationInput <= 45
                    ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                    : gymDurationInput <= 55
                    ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
                    : 'bg-rose-500/15 text-rose-600 dark:text-rose-300'
                }`}>
                  <Shield className="w-4 h-4" />
                  {gymDurationInput <= 45 && `<=45m BDNF & Testosterone Sweet Spot (${gymDurationInput}m)`}
                  {gymDurationInput > 45 && gymDurationInput <= 55 && `46–55m Wrap-Up Zone (${gymDurationInput}m)`}
                  {gymDurationInput > 55 && `>55m Cortisol Crossover Alert: Risk of 6PM Brain Fog!`}
                </div>
              </div>

              {gymSubTab === 'floor' && (
                <div className="space-y-4">
                  <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
                    <div className="lg:col-span-5 flex items-center gap-4">
                      <div className="px-4 py-3 rounded-2xl bg-neutral-900 dark:bg-white text-white dark:text-black font-mono text-2xl font-black tracking-wider">
                        {String(Math.floor(gymTimerSec / 60)).padStart(2, '0')}:{String(gymTimerSec % 60).padStart(2, '0')}
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setGymTimerRunning(!gymTimerRunning)}
                          className={`px-4 py-2.5 rounded-2xl text-xs font-bold text-white flex items-center gap-1.5 ${
                            gymTimerRunning ? 'bg-amber-500' : 'bg-emerald-600'
                          }`}
                        >
                          {gymTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                          {gymTimerRunning ? 'Pause' : 'Start Lift'}
                        </button>
                        <button
                          onClick={() => {
                            setGymTimerRunning(false);
                            setGymTimerSec(0);
                          }}
                          className="p-2.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                      <div>
                        <label className="text-[10px] font-bold uppercase text-neutral-400">Arrival Time</label>
                        <input
                          type="time"
                          value={gymArrival}
                          onChange={e => setGymArrival(e.target.value)}
                          className="w-full h-9 px-2.5 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold uppercase text-neutral-400">Lift (Mins)</label>
                        <input
                          type="number"
                          value={gymDurationInput}
                          onChange={e => setGymDurationInput(e.target.value)}
                          className="w-full h-9 px-2.5 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold uppercase text-neutral-400">Travel (Mins)</label>
                        <input
                          type="number"
                          value={gymTravelInput}
                          onChange={e => setGymTravelInput(e.target.value)}
                          className="w-full h-9 px-2.5 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold uppercase text-neutral-400">Weight (kg)</label>
                        <input
                          type="number"
                          step="0.1"
                          value={gymBodyWeightInput}
                          onChange={e => setGymBodyWeightInput(e.target.value)}
                          className="w-full h-9 px-2.5 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold mt-0.5"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
                    {GYM_SPLITS.map(sp => (
                      <button
                        key={sp.id}
                        onClick={() => setActiveSplitId(sp.id)}
                        className={`p-3.5 rounded-2xl text-left border transition ${
                          activeSplitId === sp.id
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                            : 'bg-white dark:bg-[#121216] border-neutral-200/60 dark:border-neutral-800 hover:border-indigo-500/40'
                        }`}
                      >
                        <p className="text-xs font-extrabold">{sp.short}</p>
                        <p className={`text-[11px] mt-0.5 line-clamp-1 ${activeSplitId === sp.id ? 'text-indigo-100' : 'text-neutral-500'}`}>
                          {sp.name}
                        </p>
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {activeSplitObj.options.map(opt => {
                      const isSelected = !!expandedOptions[opt.id];
                      const sets = optionSets[opt.id] || [];
                      return (
                        <div
                          key={opt.id}
                          className={`p-4 rounded-[26px] border transition ${
                            isSelected
                              ? 'bg-white dark:bg-[#121216] border-indigo-500/50 shadow-sm'
                              : 'bg-white/70 dark:bg-[#121216]/70 border-neutral-200/60 dark:border-neutral-800'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="px-2.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-black">
                                  OPTION #{opt.num}
                                </span>
                                <span className="px-2 py-0.5 rounded-full bg-emerald-500/12 text-emerald-600 dark:text-emerald-300 text-[10px] font-bold">
                                  {opt.muscle}
                                </span>
                                <span className="text-[10px] font-semibold text-neutral-400">{opt.target}</span>
                              </div>
                              <h4 className="text-sm font-bold">{opt.name}</h4>
                              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                                <strong>Look for:</strong> {opt.cue}
                              </p>
                            </div>

                            <button
                              onClick={() => toggleGymOption(opt.id)}
                              className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition ${
                                isSelected
                                  ? 'bg-indigo-600 text-white'
                                  : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300'
                              }`}
                            >
                              {isSelected ? 'Selected ✓' : 'Select'}
                            </button>
                          </div>

                          <div className="mt-2">
                            <button
                              onClick={() => setHowExpanded(prev => ({ ...prev, [opt.id]: !prev[opt.id] }))}
                              className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1"
                            >
                              <HelpCircle className="w-3.5 h-3.5" />
                              How & Why It Protects Spine/CNS?
                            </button>
                            {howExpanded[opt.id] && (
                              <p className="mt-1.5 p-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-900 text-xs text-neutral-600 dark:text-neutral-300">
                                {opt.how}
                              </p>
                            )}
                          </div>

                          {isSelected && (
                            <div className="mt-3 pt-3 border-t border-neutral-100 dark:border-neutral-800 space-y-2">
                              {sets.map((s, idx) => (
                                <div key={idx} className="flex items-center gap-2 text-xs">
                                  <span className="w-12 font-bold text-neutral-400">Set #{idx + 1}</span>
                                  <input
                                    type="number"
                                    value={s.weight}
                                    onChange={e => updateSetField(opt.id, idx, 'weight', e.target.value)}
                                    className="w-20 h-8 px-2 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] font-bold text-center"
                                  />
                                  <span className="text-neutral-400">kg ×</span>
                                  <input
                                    type="number"
                                    value={s.reps}
                                    onChange={e => updateSetField(opt.id, idx, 'reps', e.target.value)}
                                    className="w-16 h-8 px-2 rounded-xl bg-[#F2F2F7] dark:bg-[#18181F] font-bold text-center"
                                  />
                                  <span className="text-neutral-400">reps</span>
                                  <button
                                    onClick={() => removeGymSet(opt.id, idx)}
                                    className="ml-auto text-neutral-400 hover:text-rose-500"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>
                              ))}
                              <button
                                onClick={() => addGymSet(opt.id)}
                                className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                              >
                                + Add Set
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-2">
                      <span className="text-xs font-bold uppercase text-neutral-400">Zero-Brain-Fog Cortisol Shield Checklist</span>
                      <div className="flex flex-wrap gap-3">
                        {[
                          { key: 'carbSalt', label: 'Pre-Gym Fast Carb (Banana) + Salt' },
                          { key: 'rirStop', label: 'Stopped every set at 1–2 RIR' },
                          { key: 'creatineWhey', label: 'Post-Gym 5g Creatine + 30g Whey' }
                        ].map(item => (
                          <button
                            key={item.key}
                            onClick={() => setGymChecklist(prev => ({ ...prev, [item.key]: !prev[item.key] }))}
                            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border flex items-center gap-1.5 ${
                              gymChecklist[item.key]
                                ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
                                : 'bg-neutral-100 dark:bg-neutral-800 border-transparent text-neutral-500'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5" /> {item.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map(st => (
                          <button
                            key={st}
                            onClick={() => setGymFocusStars(st)}
                            className={`p-1 ${st <= gymFocusStars ? 'text-amber-400' : 'text-neutral-300 dark:text-neutral-700'}`}
                          >
                            <Star className="w-4 h-4 fill-current" />
                          </button>
                        ))}
                      </div>
                      <button
                        onClick={handleSaveGymSession}
                        className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shrink-0 shadow-sm"
                      >
                        Save Today’s Gym Session & Weight
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {gymSubTab === 'overload' && (
                <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h3 className="text-base font-bold">Strength & Progressive Overload Tracker</h3>
                      <p className="text-xs text-neutral-500">Next session target: Add +2.5 kg or +1 clean rep @ 1–2 RIR</p>
                    </div>
                    <select
                      value={selectedOverloadOption}
                      onChange={e => setSelectedOverloadOption(e.target.value)}
                      className="h-10 px-3 rounded-2xl bg-[#F2F2F7] dark:bg-[#18181F] text-xs font-bold"
                    >
                      {GYM_SPLITS.flatMap(sp => sp.options).map(o => (
                        <option key={o.id} value={o.id}>Option #{o.num}: {o.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {appData.gymLogs.flatMap(g => g.exercises.map(ex => ({ ...ex, date: g.date }))).slice(0, 6).map((item, i) => (
                      <div key={i} className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] border border-neutral-200/60 dark:border-neutral-800">
                        <span className="text-[10px] font-bold text-indigo-500">{formatHumanDate(item.date)}</span>
                        <p className="text-xs font-bold truncate mt-0.5">{item.name}</p>
                        <p className="text-sm font-black text-emerald-600 mt-1">
                          PR: {item.topWeight} kg × {item.topReps} reps
                        </p>
                        <p className="text-[10px] text-neutral-400">Next Target: {item.topWeight + 2.5} kg or {item.topReps + 1} reps</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {gymSubTab === 'weight' && (
                <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-4">
                  <h3 className="text-base font-bold">Body Weight Progression & Lifting vs. Travel Time</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F]">
                      <span className="text-[11px] text-neutral-500">Current Weight</span>
                      <p className="text-lg font-black">{gymBodyWeightInput} kg</p>
                    </div>
                    <div className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F]">
                      <span className="text-[11px] text-neutral-500">Target Weight</span>
                      <p className="text-lg font-black text-indigo-600">{appData.targetBodyWeight} kg</p>
                    </div>
                    <div className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F]">
                      <span className="text-[11px] text-neutral-500">Sessions Logged</span>
                      <p className="text-lg font-black text-emerald-600">{appData.gymLogs.length}</p>
                    </div>
                    <div className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F]">
                      <span className="text-[11px] text-neutral-500">Avg Brain Freshness</span>
                      <p className="text-lg font-black text-amber-500">4.9 ★</p>
                    </div>
                  </div>
                </div>
              )}

              {gymSubTab === 'history' && (
                <div className="bg-white dark:bg-[#121216] rounded-[30px] p-5 shadow-sm border border-neutral-200/60 dark:border-neutral-800 space-y-3">
                  <h3 className="text-base font-bold">Chronological Workout Log</h3>
                  {appData.gymLogs.length === 0 ? (
                    <p className="text-xs text-neutral-400 py-6 text-center">No workouts logged yet.</p>
                  ) : (
                    <div className="space-y-2">
                      {appData.gymLogs.map(log => (
                        <div key={log.id} className="p-3.5 rounded-2xl bg-[#F8F8FA] dark:bg-[#18181F] flex items-center justify-between">
                          <div>
                            <p className="text-xs font-bold">{formatHumanDate(log.date)} • {log.splitName} ({log.durationMins}m lift / {log.travelMins}m travel)</p>
                            <p className="text-[11px] text-neutral-500">Body Weight: {log.bodyWeight} kg • Brain Focus: {log.focusStars}★</p>
                          </div>
                          <button
                            onClick={() => setAppData(prev => ({ ...prev, gymLogs: prev.gymLogs.filter(g => g.id !== log.id) }))}
                            className="p-1.5 text-neutral-400 hover:text-rose-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </main>

        {/* ====================================================================
            SAMSUNG ONE UI 6-TAB BOTTOM NAVIGATION BAR
           ==================================================================== */}
        <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-[#0B0B0E]/95 backdrop-blur-lg border-t border-neutral-200/70 dark:border-neutral-800/80 px-2 py-1.5">
          <div className="max-w-2xl mx-auto grid grid-cols-6 gap-1">
            {[
              { id: 'calendar', label: 'Calendar', icon: CalendarIcon, badge: appData.topics.filter(t => t.nextReviewDate === selectedDate).length },
              { id: 'pairing', label: 'Free-Hand', icon: Brain, badge: `${neuroCompatibility.score}%` },
              { id: 'bookmarks', label: '20th NB & BM', icon: Bookmark, badge: physical20thCuratedList.totalEligible },
              { id: 'backlogs', label: 'Backlogs', icon: ListChecks, badge: dynamicBacklogs.totalCount > 0 ? dynamicBacklogs.totalCount : null },
              { id: 'analytics', label: 'GT & 26-Subj', icon: BarChart3, badge: weakSubjectsList.length > 0 ? `${weakSubjectsList.length}⚡` : null },
              { id: 'gym', label: 'BDNF Gym', icon: Dumbbell, badge: null }
            ].map(tab => {
              const IconComponent = tab.icon;
              const isAct = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className="flex flex-col items-center justify-center py-1 rounded-2xl relative group transition"
                >
                  <div className={`px-3 sm:px-4 py-1 rounded-full flex items-center justify-center transition-all ${
                    isAct
                      ? 'bg-indigo-600/15 dark:bg-indigo-500/25 text-indigo-600 dark:text-indigo-300'
                      : 'text-neutral-500 dark:text-neutral-400 group-hover:text-neutral-800 dark:group-hover:text-neutral-200'
                  }`}>
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <span className={`text-[10px] mt-0.5 font-bold truncate max-w-full ${
                    isAct ? 'text-indigo-600 dark:text-indigo-300' : 'text-neutral-500 dark:text-neutral-400'
                  }`}>
                    {tab.label}
                  </span>
                  {tab.badge ? (
                    <span className={`absolute top-0.5 right-1 sm:right-2.5 px-1.5 py-0.2 rounded-full text-white text-[9px] font-extrabold ${
                      tab.id === 'backlogs' ? 'bg-rose-600 animate-pulse' : 'bg-indigo-600'
                    }`}>
                      {tab.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>
        </nav>

        {/* ====================================================================
            SAMSUNG CALENDAR SLIDE-OVER LEFT NAVIGATION DRAWER
           ==================================================================== */}
        {drawerOpen && (
          <div className="fixed inset-0 z-50 flex">
            <div className="fixed inset-0 bg-black/50 backdrop-blur-xs" onClick={() => setDrawerOpen(false)} />
            <div className="relative w-80 max-w-[85vw] bg-white dark:bg-[#121216] h-full p-5 flex flex-col justify-between overflow-y-auto z-10 rounded-r-[32px] shadow-2xl">
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-sm">
                      INI
                    </div>
                    <div>
                      <h3 className="text-sm font-bold">Samsung Neuro Calendar</h3>
                      <p className="text-[11px] text-neutral-400">Phase 1 Dec 31 • Buffer Jan 15</p>
                    </div>
                  </div>
                  <button onClick={() => setDrawerOpen(false)} className="p-1.5 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 px-2">Calendar Views</p>
                  {[
                    { id: 'split', label: 'Split View (Month + Split MCQ)' },
                    { id: 'month', label: 'Full Month Grid View' },
                    { id: 'week', label: '7-Day Circadian & Split MCQ View' },
                    { id: 'schedule', label: '4-vs-5 Revision Schedule List' }
                  ].map(v => (
                    <button
                      key={v.id}
                      onClick={() => {
                        setActiveTab('calendar');
                        setCalViewMode(v.id);
                        setDrawerOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 rounded-2xl text-xs font-semibold flex items-center justify-between ${
                        activeTab === 'calendar' && calViewMode === v.id
                          ? 'bg-indigo-600/12 text-indigo-600 dark:text-indigo-300 font-bold'
                          : 'hover:bg-neutral-100 dark:hover:bg-neutral-800'
                      }`}
                    >
                      <span>{v.label}</span>
                      {activeTab === 'calendar' && calViewMode === v.id && <Check className="w-4 h-4" />}
                    </button>
                  ))}
                </div>

                <div className="space-y-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 px-2">Memory Decay Calendars</p>
                  {Object.values(BUCKET_CONFIG).map(b => (
                    <button
                      key={b.id}
                      onClick={() => setBucketFilter(prev => ({ ...prev, [b.id]: !prev[b.id] }))}
                      className="w-full px-3 py-2 rounded-2xl hover:bg-neutral-100 dark:hover:bg-neutral-800 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className={`w-3.5 h-3.5 rounded-md ${b.dotClass}`} />
                        <div className="text-left">
                          <p className="font-bold">{b.shortName}</p>
                          <p className="text-[10px] text-neutral-400">{b.intervals.join(' → ')}d ({b.targetRevisionsByMay20} Revs)</p>
                        </div>
                      </div>
                      <input type="checkbox" checked={bucketFilter[b.id]} readOnly className="accent-indigo-600" />
                    </button>
                  ))}
                </div>

                <div className="space-y-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                  <button
                    onClick={() => {
                      handleLoadSample();
                      setDrawerOpen(false);
                    }}
                    className="w-full py-2.5 px-3 rounded-2xl bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-xs font-bold text-left flex items-center gap-2"
                  >
                    <Sparkles className="w-4 h-4" /> Load Sample Preview Data
                  </button>
                  <button
                    onClick={() => {
                      setDrawerOpen(false);
                      setProfileModalOpen(true);
                    }}
                    className="w-full py-2.5 px-3 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-xs font-bold text-left flex items-center gap-2"
                  >
                    <Users className="w-4 h-4" /> Switch User Email Profile
                  </button>
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 text-[11px] text-neutral-400">
                Active Profile: <strong className="text-neutral-700 dark:text-neutral-200">{activeEmail}</strong>
              </div>
            </div>
          </div>
        )}

        {/* ====================================================================
            MODAL 1: FREE-HAND TOPIC QUICK-SCHEDULE SHEET
           ==================================================================== */}
        {addEventSheetOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4">
            <form
              onSubmit={handleQuickScheduleSubmit}
              className="w-full max-w-lg bg-white dark:bg-[#17171C] rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl space-y-4 border border-neutral-200/60 dark:border-neutral-800"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold">Free-Hand Topic Scheduler (19 Subj + 7 Integrated)</h3>
                  <p className="text-xs text-neutral-500">Auto-assigns 4-Rev (Normal) vs 5-Rev (Weak/Bucket A) Track to May 20</p>
                </div>
                <button type="button" onClick={() => setAddEventSheetOpen(false)} className="p-1 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-neutral-500">1. Choose Subject or Separate Integrated System</label>
                  <select
                    value={schedSubject}
                    onChange={e => setSchedSubject(e.target.value)}
                    className="w-full h-11 px-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#121216] text-xs font-bold mt-1"
                  >
                    <optgroup label="7 Separate Integrated Clinical Systems">
                      {SUBJECTS_DB.filter(s => s.isIntegrated).map(s => (
                        <option key={s.name} value={s.name}>
                          [Integrated • {s.pyqWeightage}% PYQ • {BUCKET_CONFIG[s.bucket].intervals.join('/')}d] {s.name}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="19 Classic INI-CET Subjects (Bucket A, B, C)">
                      {SUBJECTS_DB.filter(s => !s.isIntegrated).map(s => (
                        <option key={s.name} value={s.name}>
                          [Bucket {s.bucket} • {s.pyqWeightage}% PYQ • {BUCKET_CONFIG[s.bucket].intervals.join('/')}d] {s.name}
                        </option>
                      ))}
                    </optgroup>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-neutral-500">2. Pick Saved Chapter Subtopic</label>
                  <select
                    value={schedSubheading}
                    onChange={e => setSchedSubheading(e.target.value)}
                    className="w-full h-11 px-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#121216] text-xs mt-1"
                  >
                    {getSubheadingsForSubject(schedSubject).map(sh => (
                      <option key={sh.title} value={sh.title}>{sh.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                    Or Enter Any Custom Free-Hand Subtopic
                  </label>
                  <input
                    type="text"
                    value={schedCustomText}
                    onChange={e => setSchedCustomText(e.target.value)}
                    placeholder="Type your exact custom subtopic to study..."
                    className="w-full h-11 px-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#121216] text-xs mt-1"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-xs font-semibold text-neutral-500">3. Study Date (Day 0)</label>
                    <input
                      type="date"
                      value={schedStudyDate}
                      onChange={e => setSchedStudyDate(e.target.value)}
                      className="w-full h-11 px-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#121216] text-xs font-bold mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-neutral-500">4. Organ-System Network</label>
                    <select
                      value={schedCustomOrganSys}
                      onChange={e => setSchedCustomOrganSys(e.target.value)}
                      className="w-full h-11 px-3 rounded-2xl bg-[#F2F2F7] dark:bg-[#121216] text-xs font-bold mt-1"
                    >
                      {Object.entries(ORGAN_SYSTEMS).map(([k, v]) => (
                        <option key={k} value={k}>{v}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAddEventSheetOpen(false)}
                  className="flex-1 py-3 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-2xl bg-indigo-600 text-white text-xs font-bold shadow-sm"
                >
                  + Schedule into Calendar
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ====================================================================
            MODAL 2: MULTI-PARAMETER 3-FACTOR AIIMS GRADER (WITH 20TH NB DETECTOR)
           ==================================================================== */}
        {graderTopic && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4">
            <div className="w-full max-w-md bg-white dark:bg-[#17171C] rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl space-y-4 border border-neutral-200/60 dark:border-neutral-800">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase text-indigo-500">
                    3-Factor Adaptive Grader • Stage {(graderTopic.stageIndex || 0) + 1}
                  </span>
                  <h3 className="text-base font-bold mt-0.5">{graderTopic.subject}</h3>
                  <p className="text-xs text-neutral-500">{graderTopic.subheading}</p>
                </div>
                <button onClick={() => setGraderTopic(null)} className="p-1 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-[#F8F8FA] dark:bg-[#121216] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-neutral-500">1. Q-Bank Module Accuracy (%)</span>
                  <span className={`text-2xl font-black ${
                    graderAccuracy >= 85 ? 'text-emerald-600' : graderAccuracy >= 75 ? 'text-indigo-600' : graderAccuracy >= 65 ? 'text-amber-500' : 'text-rose-600'
                  }`}>
                    {graderAccuracy}%
                  </span>
                </div>
                <input
                  type="range"
                  min="25"
                  max="100"
                  value={graderAccuracy}
                  onChange={e => setGraderAccuracy(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />

                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs font-semibold text-neutral-500">2. Blind Recall Confidence (1–5★)</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map(st => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setGraderConfidence(st)}
                        className={`px-2 py-0.5 rounded-lg text-xs font-bold ${
                          st <= graderConfidence ? 'bg-amber-400 text-black' : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-400'
                        }`}
                      >
                        {st}★
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <label className="text-[10px] font-bold text-neutral-400">3. Speed (Sec / MCQ)</label>
                    <input
                      type="number"
                      value={graderSpeedSec}
                      onChange={e => setGraderSpeedSec(Number(e.target.value))}
                      className="w-full h-9 px-2.5 rounded-xl bg-white dark:bg-[#18181F] text-xs font-bold mt-0.5"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-neutral-400">4. Primary Error Type</label>
                    <select
                      value={graderMistakeType}
                      onChange={e => setGraderMistakeType(e.target.value)}
                      className="w-full h-9 px-2 rounded-xl bg-white dark:bg-[#18181F] text-xs font-bold mt-0.5"
                    >
                      <option value="none">Clean Recall</option>
                      <option value="silly">Silly / Reading Rush</option>
                      <option value="concept">Concept Schema Gap</option>
                      <option value="volatile">Volatile Fact Decay</option>
                    </select>
                  </div>
                </div>

                {/* Live Alert if low accuracy at Rev 2 triggers Physical 20th Notebook + 5-Revision Track */}
                {(graderAccuracy < 75 || graderConfidence <= 2) && (
                  <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-[11px] text-amber-800 dark:text-amber-300 font-semibold">
                    📓 Low Retention Detected (&lt;75% or ≤2★): This subtopic will automatically be added to your <strong>Physical 20th Notebook Write-Queue</strong> and upgraded to the <strong>5-Revision Track</strong> before May 20!
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setGraderTopic(null)}
                  className="flex-1 py-3 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleGradeSubmit}
                  className="flex-1 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-sm"
                >
                  Upgrade Schedule & Save
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ====================================================================
            MODAL 3: MULTI-USER EMAIL PROFILE SWITCHER
           ==================================================================== */}
        {profileModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
            <div className="w-full max-w-md bg-white dark:bg-[#17171C] rounded-[32px] p-6 shadow-2xl space-y-4 border border-neutral-200/60 dark:border-neutral-800">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold">Multi-User Email Profile Switcher</h3>
                  <p className="text-xs text-neutral-500">100% isolated storage so you and your study partner never mix data</p>
                </div>
                <button onClick={() => setProfileModalOpen(false)} className="p-1 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-2">
                {savedProfiles.map(email => (
                  <button
                    key={email}
                    onClick={() => {
                      setActiveEmail(email);
                      setProfileModalOpen(false);
                      showToast(`Switched profile to ${email}`, 'success');
                    }}
                    className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between transition ${
                      activeEmail === email
                        ? 'bg-indigo-600/12 border-indigo-500 text-indigo-600 dark:text-indigo-300 font-bold'
                        : 'bg-[#F8F8FA] dark:bg-[#121216] border-neutral-200/60 dark:border-neutral-800'
                    }`}
                  >
                    <span className="text-xs">{email}</span>
                    {activeEmail === email && <Check className="w-4 h-4" />}
                  </button>
                ))}
              </div>

              <form
                onSubmit={e => {
                  e.preventDefault();
                  const clean = customEmailInput.trim().toLowerCase();
                  if (!clean) return;
                  if (!savedProfiles.includes(clean)) {
                    setSavedProfiles(prev => [...prev, clean]);
                  }
                  setActiveEmail(clean);
                  setCustomEmailInput('');
                  setProfileModalOpen(false);
                  showToast(`Switched to profile ${clean}`, 'success');
                }}
                className="flex gap-2"
              >
                <input
                  type="email"
                  value={customEmailInput}
                  onChange={e => setCustomEmailInput(e.target.value)}
                  placeholder="Add friend email (e.g. partner@inicet.aiims)"
                  className="flex-1 h-10 px-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#121216] text-xs"
                />
                <button type="submit" className="px-4 h-10 rounded-2xl bg-indigo-600 text-white text-xs font-bold">
                  Switch
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ====================================================================
            MODAL 4: + BULK PASTE SUBTOPICS INTO ANY OF THE 26 SUBJECTS
           ==================================================================== */}
        {customIndexModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
            <form
              onSubmit={handleBulkSubheadingsAdd}
              className="w-full max-w-lg bg-white dark:bg-[#17171C] rounded-[32px] p-6 shadow-2xl space-y-4 border border-neutral-200/60 dark:border-neutral-800"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold">+ Bulk Paste Custom Subtopics (19 Subj + 7 Integrated)</h3>
                <button type="button" onClick={() => setCustomIndexModalOpen(false)} className="p-1 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500">Subject / Integrated System</label>
                  <select
                    value={bulkSubject}
                    onChange={e => setBulkSubject(e.target.value)}
                    className="w-full h-10 px-3 rounded-2xl bg-[#F2F2F7] dark:bg-[#121216] text-xs font-bold mt-1"
                  >
                    {SUBJECTS_DB.map(s => (
                      <option key={s.name} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500">Organ-System Tag</label>
                  <select
                    value={bulkSysTag}
                    onChange={e => setBulkSysTag(e.target.value)}
                    className="w-full h-10 px-3 rounded-2xl bg-[#F2F2F7] dark:bg-[#121216] text-xs font-bold mt-1"
                  >
                    {Object.entries(ORGAN_SYSTEMS).map(([k, v]) => (
                      <option key={k} value={k}>{v}</option>
                    ))}
                  </select>
                </div>
              </div>
              <textarea
                rows={5}
                value={bulkText}
                onChange={e => setBulkText(e.target.value)}
                placeholder="Paste one chapter subtopic per line..."
                className="w-full p-3.5 rounded-2xl bg-[#F2F2F7] dark:bg-[#121216] text-xs focus:outline-none"
                required
              />
              <div className="flex gap-2">
                <button type="button" onClick={() => setCustomIndexModalOpen(false)} className="flex-1 py-2.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-xs font-bold">
                  Cancel
                </button>
                <button type="submit" className="flex-1 py-2.5 rounded-2xl bg-indigo-600 text-white text-xs font-bold">
                  Merge into Dropdowns
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ====================================================================
            MODAL 5: RESET TO ZERO CONFIRMATION
           ==================================================================== */}
        {resetConfirmOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
            <div className="w-full max-w-sm bg-white dark:bg-[#17171C] rounded-[32px] p-6 shadow-2xl space-y-4 text-center">
              <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto" />
              <h3 className="text-base font-bold">Reset Profile to Zero-State?</h3>
              <p className="text-xs text-neutral-500">
                This clears all scheduled topics, bookmarks, pearls, GTs, and gym sessions for <strong>{activeEmail}</strong> back to 0.
              </p>
              <div className="flex gap-2">
                <button onClick={() => setResetConfirmOpen(false)} className="flex-1 py-2.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-xs font-bold">
                  Cancel
                </button>
                <button onClick={handleResetToZero} className="flex-1 py-2.5 rounded-2xl bg-rose-600 text-white text-xs font-bold">
                  Reset to Zero
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ====================================================================
            MODAL 6: ADAPTIVE 8:30 AM & 2:30 PM MCQ REVIEW TIME-PACING CALIBRATOR
           ==================================================================== */}
        {pacingModalOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4">
            <div className="w-full max-w-2xl bg-white dark:bg-[#17171C] rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl space-y-4 border border-neutral-200/60 dark:border-neutral-800 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                    20–25 Day Routine Adjuster • Time-Budget Calibrator
                  </span>
                  <h3 className="text-base sm:text-lg font-bold mt-0.5">
                    08:30 AM & 02:30 PM MCQ Explanation Review Time Calibrator
                  </h3>
                </div>
                <button onClick={() => setPacingModalOpen(false)} className="p-1.5 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* 1. Choose Your Current Routine Pacing Mode (Auto-Rebalances Calendar!) */}
              <div className="space-y-2">
                <p className="text-xs font-bold text-neutral-500">
                  1. Select Your Current MCQ Review Speed Mode (One-Click Calendar Re-Balancer):
                </p>
                <div className="grid grid-cols-1 gap-2.5">
                  {Object.values(PACING_MODES).map(m => {
                    const isAct = (appData.pacingMode || 'balanced') === m.id;
                    return (
                      <button
                        key={m.id}
                        onClick={() => handleApplyPacingModeAndRebalance(m.id)}
                        className={`p-3.5 rounded-2xl border text-left transition flex flex-col gap-1 ${
                          isAct
                            ? 'bg-indigo-600/10 border-indigo-500 shadow-xs'
                            : 'bg-[#F8F8FA] dark:bg-[#121216] border-neutral-200/60 dark:border-neutral-800 hover:border-indigo-500/40'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-extrabold text-neutral-900 dark:text-white">{m.name}</span>
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                            isAct ? 'bg-indigo-600 text-white' : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300'
                          }`}>
                            {m.shortBadge}
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-600 dark:text-neutral-300 leading-relaxed">
                          {m.description}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Interactive Time-Per-MCQ Calculator */}
              <div className="p-4 rounded-2xl bg-[#F8F8FA] dark:bg-[#121216] border border-neutral-200/60 dark:border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-indigo-600 dark:text-indigo-400">
                    2. Interactive MCQ Solve + Explanation Review Time Calculator
                  </span>
                  <span className="text-[11px] font-bold text-neutral-400">Find your exact 105-min afternoon fit</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-neutral-500 block">
                      Solve Speed: {appData.customSolveSecPerMcq || 45}s / MCQ
                    </label>
                    <input
                      type="range"
                      min="25"
                      max="75"
                      value={appData.customSolveSecPerMcq || 45}
                      onChange={e => setAppData(prev => ({ ...prev, customSolveSecPerMcq: Number(e.target.value) }))}
                      className="w-full accent-indigo-600 cursor-pointer mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-neutral-500 block">
                      Review Time / Wrong Q: {appData.customReviewSecPerWrong || 120}s
                    </label>
                    <input
                      type="range"
                      min="45"
                      max="240"
                      step="15"
                      value={appData.customReviewSecPerWrong || 120}
                      onChange={e => setAppData(prev => ({ ...prev, customReviewSecPerWrong: Number(e.target.value) }))}
                      className="w-full accent-rose-600 cursor-pointer mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-neutral-500 block">
                      Avg Accuracy: {appData.customExpectedAccuracyPct || 75}%
                    </label>
                    <input
                      type="range"
                      min="50"
                      max="95"
                      value={appData.customExpectedAccuracyPct || 75}
                      onChange={e => setAppData(prev => ({ ...prev, customExpectedAccuracyPct: Number(e.target.value) }))}
                      className="w-full accent-emerald-600 cursor-pointer mt-1"
                    />
                  </div>
                </div>

                {(() => {
                  const totalAfternoonQs = activePacingConfig.partAYesterdayQs + activePacingConfig.partBTodayQs;
                  const solveSec = appData.customSolveSecPerMcq || 45;
                  const wrongReviewSec = appData.customReviewSecPerWrong || 120;
                  const acc = (appData.customExpectedAccuracyPct || 75) / 100;
                  const wrongCount = Math.round(totalAfternoonQs * (1 - acc));
                  const correctCount = totalAfternoonQs - wrongCount;

                  const totalSolveMins = Math.round((totalAfternoonQs * solveSec) / 60);
                  // With 3-Tier Triage: only wrong/guessed questions get full review; confident corrects take 10s
                  const triageReviewMins = Math.round((wrongCount * wrongReviewSec + correctCount * 10) / 60);
                  // Without Triage (reading every explanation for 2 mins):
                  const naiveReviewMins = Math.round((totalAfternoonQs * wrongReviewSec) / 60);
                  const totalWithTriage = totalSolveMins + triageReviewMins;

                  return (
                    <div className="p-3 rounded-xl bg-white dark:bg-[#17171C] border border-neutral-200/60 dark:border-neutral-800 space-y-1.5 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span>
                          For <strong>{totalAfternoonQs} Afternoon MCQs</strong> ({correctCount} Correct / {wrongCount} Wrong):
                        </span>
                        <span className={`font-extrabold ${totalWithTriage <= 105 ? 'text-emerald-600' : 'text-amber-500'}`}>
                          With 3-Tier Triage: {totalSolveMins}m solve + {triageReviewMins}m review = {totalWithTriage} mins (Fits 105m window!)
                        </span>
                      </div>
                      <p className="text-[11px] text-rose-500">
                        Without Triage (reading all {totalAfternoonQs} explanations): {totalSolveMins + naiveReviewMins} mins (Overflows by {Math.max(0, totalSolveMins + naiveReviewMins - 105)} mins!)
                      </p>
                    </div>
                  );
                })()}
              </div>

              {/* 3. The 3-Tier MCQ Explanation Triage Protocol */}
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 space-y-2">
                <h4 className="text-xs font-extrabold uppercase text-emerald-700 dark:text-emerald-300">
                  3. The 3-Tier Explanation Triage Rule (How to Cut Review Time by 60%)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-white/90 dark:bg-[#121216] border border-emerald-500/20">
                    <span className="font-extrabold text-emerald-600 block">Tier 1: Correct & Sure (~65% of Qs)</span>
                    <p className="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5">
                      <strong>Spend 5–10 seconds MAX.</strong> Read only the bottom 1-line Pearl summary. Never read a 4-paragraph explanation for a concept you already know cold!
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/90 dark:bg-[#121216] border border-amber-500/20">
                    <span className="font-extrabold text-amber-600 block">Tier 2: Correct by 50:50 Guess (~15% of Qs)</span>
                    <p className="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5">
                      <strong>Spend 45 seconds.</strong> Read only the table/line that differentiates the 2 options you were confused between, and log as a 1-Strike Bookmark.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/90 dark:bg-[#121216] border border-rose-500/20">
                    <span className="font-extrabold text-rose-600 block">Tier 3: Got Wrong (~20% of Qs)</span>
                    <p className="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5">
                      <strong>Spend 90–120 seconds.</strong> Read the core explanation + retrograde-check that subheading in your notes + lock into the 4-Day Bookmark Conveyor.
                    </p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setPacingModalOpen(false)}
                className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition"
              >
                Done & Return to Calendar
              </button>
            </div>
          </div>
        )}

        {/* ====================================================================
            MODAL 7: ZERO-DATA-LOSS PROGRESS BACKUP, RESTORE & ANDROID INSTALL HUB
           ==================================================================== */}
        {backupModalOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4">
            <div className="w-full max-w-xl bg-white dark:bg-[#17171C] rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl space-y-4 border border-neutral-200/60 dark:border-neutral-800 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                    Zero-Data-Loss Protection • Offline & Upgrade Safe
                  </span>
                  <h3 className="text-base sm:text-lg font-bold mt-0.5">
                    Backup / Restore Progress & Install on Android
                  </h3>
                </div>
                <button onClick={() => setBackupModalOpen(false)} className="p-1.5 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Part 1: Export & Import Progress JSON */}
              <div className="p-4 rounded-2xl bg-[#F8F8FA] dark:bg-[#121216] border border-neutral-200/60 dark:border-neutral-800 space-y-3">
                <h4 className="text-xs font-extrabold uppercase text-indigo-600 dark:text-indigo-400">
                  1. Protect Your Progress Before Any Future App Edit / Upgrade
                </h4>
                <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  Whenever you come back to this chat to add a new feature or fix a problem, click <strong>Download Progress Backup (.JSON)</strong> or <strong>Copy Backup Code</strong> first. After I update the app, click <strong>Restore Backup</strong> and 100% of your topics, bookmarks, pearls, GTs, and gym logs will be restored instantly!
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={handleExportProgressBackup}
                    className="py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition"
                  >
                    <Download className="w-4 h-4" /> Download .JSON Backup
                  </button>

                  <button
                    type="button"
                    onClick={handleCopyBackupClipboard}
                    className="py-2.5 px-3 rounded-xl bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 text-xs font-bold flex items-center justify-center gap-1.5 transition"
                  >
                    Copy Backup Code
                  </button>

                  <label className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs transition">
                    <Upload className="w-4 h-4" /> Upload .JSON Backup
                    <input
                      type="file"
                      accept=".json,application/json"
                      onChange={handleImportProgressFile}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Paste JSON Code Restore */}
                <form onSubmit={handleRestoreFromText} className="pt-2 border-t border-neutral-200/60 dark:border-neutral-800 flex gap-2">
                  <input
                    type="text"
                    value={restoreJsonInput}
                    onChange={e => setRestoreJsonInput(e.target.value)}
                    placeholder="Or paste your copied Backup JSON code here to restore..."
                    className="flex-1 h-9 px-3 rounded-xl bg-white dark:bg-[#17171C] border border-neutral-200 dark:border-neutral-700 text-xs focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="px-3.5 h-9 rounded-xl bg-emerald-600 text-white text-xs font-bold shrink-0"
                  >
                    Restore Code
                  </button>
                </form>
              </div>

              {/* Part 2: How to Use Standalone Offline HTML on Your Samsung / Android Phone */}
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 space-y-2 text-xs">
                <h4 className="font-extrabold uppercase text-emerald-700 dark:text-emerald-300">
                  2. How to Run Standalone on Your Android Phone (100% Offline)
                </h4>
                <ul className="space-y-1.5 text-neutral-700 dark:text-neutral-200 list-disc pl-4">
                  <li>
                    <strong>Option A (Download Standalone HTML File):</strong> Download the <code>INICET_May2027_Samsung_Calendar_App.html</code> file provided in the chat, open it in <strong>Samsung Internet</strong> or <strong>Chrome</strong> on your phone, tap the menu (<code>⋮</code>) and tap <strong>"Add page to" → "Home screen"</strong>.
                  </li>
                  <li>
                    <strong>Option B (Persist Across Upgrades):</strong> All data auto-saves to your browser's <code>localStorage</code> under your email profile (<code>{activeEmail}</code>) AND can be exported/restored anytime via the <strong>.JSON Backup</strong> button above.
                  </li>
                </ul>
              </div>

              <button
                onClick={() => setBackupModalOpen(false)}
                className="w-full py-3 rounded-2xl bg-neutral-900 dark:bg-white text-white dark:text-black text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        )}

        {/* Floating Toast */}
        {toast && (
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-full bg-neutral-900/95 dark:bg-white/95 text-white dark:text-black text-xs font-semibold shadow-xl flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-emerald-600 shrink-0" />
            <span>{toast.msg}</span>
          </div>
        )}
      </div>
    </div>
  );
}
