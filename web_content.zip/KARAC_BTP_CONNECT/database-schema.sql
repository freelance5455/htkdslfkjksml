-- Schéma PostgreSQL de départ pour KARAC BTP CONNECT.
-- À exécuter uniquement après création d'un projet Supabase/PostgreSQL.
create extension if not exists pgcrypto;
create table if not exists companies (
 id uuid primary key default gen_random_uuid(),
 name text not null, city text default 'Ouagadougou', category text,
 phone text, email text, website text, source_url text, notes text,
 created_at timestamptz default now()
);
create table if not exists opportunities (
 id uuid primary key default gen_random_uuid(),
 title text not null, company_id uuid references companies(id) on delete set null,
 domain text, city text default 'Ouagadougou', deadline date, source_url text,
 status text not null default 'À étudier',
 estimated_budget numeric(16,2), description text,
 created_at timestamptz default now()
);
create table if not exists followups (
 id uuid primary key default gen_random_uuid(),
 company_id uuid references companies(id) on delete cascade,
 opportunity_id uuid references opportunities(id) on delete cascade,
 due_at timestamptz, action text not null, completed boolean default false,
 created_at timestamptz default now()
);
create table if not exists contact_logs (
 id uuid primary key default gen_random_uuid(),
 company_id uuid references companies(id) on delete cascade,
 opportunity_id uuid references opportunities(id) on delete set null,
 channel text, direction text, subject text, body text,
 sent_at timestamptz, delivery_status text default 'draft',
 created_at timestamptz default now()
);
-- Production: activer RLS et créer des politiques basées sur auth.uid().
-- Ne jamais placer une clé secrète/service-role dans le code du navigateur.
