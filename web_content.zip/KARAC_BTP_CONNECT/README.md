# KARAC BTP CONNECT — version initiale

## Contenu
- `index.html` : interface web adaptative avec entreprises, opportunités, relances et génération de message.
- `manifest.webmanifest` + `sw.js` : base PWA installable depuis un hébergement HTTPS.
- `database-schema.sql` : schéma PostgreSQL de départ pour la future synchronisation multi-appareils.

## Lancer
Ouvrir `index.html` dans un navigateur pour tester l'interface. Les données sont stockées localement dans le navigateur de l'appareil.

## Installer sur Android
1. Héberger le dossier sur un site HTTPS.
2. Ouvrir l'adresse dans Chrome Android.
3. Menu ⋮ > Installer l'application / Ajouter à l'écran d'accueil.

## Limites actuelles
Cette version ne collecte pas encore automatiquement des données sur Internet, n'envoie pas de WhatsApp/email et ne synchronise pas plusieurs appareils. Ces fonctions nécessitent des sources publiques ou API autorisées, un backend sécurisé, une authentification et les comptes des services concernés. Les messages sont préparés comme brouillons et doivent être vérifiés avant envoi.

## Étapes de production
1. Déployer le frontend sur un hébergement HTTPS.
2. Créer la base PostgreSQL et activer l'authentification + Row Level Security.
3. Ajouter un service de veille sur les sources autorisées (appels d'offres, pages officielles, annonces).
4. Ajouter validation humaine avant tout envoi de prospection.
5. Configurer notifications, sauvegardes et tests Android.

## Compilation APK via GitHub Actions
Le fichier `.github/workflows/android-apk.yml` prépare un projet Android Capacitor et compile un APK debug automatiquement après push sur `main` ou `principal`, ou depuis l'onglet Actions > Build Android APK > Run workflow. Le fichier APK apparaît ensuite dans les Artifacts du workflow. La compilation doit être exécutée sur GitHub; aucun APK n'est généré dans ce ZIP.
