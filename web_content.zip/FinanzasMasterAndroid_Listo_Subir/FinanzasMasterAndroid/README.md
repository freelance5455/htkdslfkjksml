# Finanzas Master 2026 – Android Edition

Proyecto Android Studio (Java + WebView) creado a partir de `Super App Financiera Anual 2026.html`.

## Qué conserva
- Los 12 períodos desde noviembre de 2026 hasta octubre de 2027.
- Los compromisos, montos, categorías, vencimientos y estados precargados definidos en el HTML original.
- La lógica de cálculos, registro diario, gastos/ingresos sorpresa, gráficos, filtros y resumen anual.
- La misma clave de almacenamiento local (`finanzas_master_anual_2026_v1`) dentro del WebView.

## Mejoras Android
- Interfaz visual renovada y optimizada para pantallas táctiles.
- WebView a pantalla completa, almacenamiento DOM habilitado y navegación Android.
- Exportación CSV y respaldo JSON a `Descargas/FinanzasMaster`.
- Selector de archivos Android para restaurar respaldos JSON.

## Abrir y compilar
1. Instalar Android Studio (Hedgehog o posterior) con Android SDK 35 y JDK 17.
2. Abrir esta carpeta como proyecto existente.
3. Esperar la sincronización de Gradle.
4. Elegir `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. Android Studio generará el APK de depuración en `app/build/outputs/apk/debug/app-debug.apk`.

## Nota sobre conexión
El HTML original utiliza Tailwind Play CDN, Chart.js y Lucide desde CDN. Se mantuvieron las dependencias originales para no alterar el comportamiento; por eso la primera carga visual y los gráficos/iconos necesitan conexión a Internet. Los datos y movimientos se guardan localmente en el dispositivo. No se añadió ningún servidor financiero externo.

## Identificador
`com.finanzasmaster.app` – versión 1.0.0 – Android 10 (API 29) o superior.
