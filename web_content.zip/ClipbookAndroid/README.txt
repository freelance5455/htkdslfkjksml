CLIPBOOK v0.2 - Android
=======================

Proyecto Android nativo con el prototipo HTML de Clipbook dentro de un WebView.

Permiso:
- Android 13+: READ_MEDIA_VIDEO
- Android 12 o anterior: READ_EXTERNAL_STORAGE

En AIDE:
1. Importa/abre esta carpeta como proyecto Gradle.
2. Espera a que sincronice Gradle.
3. Ejecuta la app.
4. Pulsa + y luego "Elegir vídeo de la galería".
5. Android mostrará el permiso de vídeos.

Nota: el proyecto usa un WebView y el HTML funciona localmente, sin servidor.
