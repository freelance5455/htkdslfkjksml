# Stage 1186 — WebView Bridge Repair

Root cause: Settings could execute while `window.CryptoPulseNative` was absent.

Fixes:
- Enable JavaScript before installing the interface.
- Install `CryptoPulseNative` before first load.
- Re-install the bridge on `onPageStarted` and `onPageFinished` for every document.
- Settings diagnostic bumped to 12.3.6.

No market-data behavior or synthetic data was added.
