دفتر حسابات Whish — مشروع Android Studio

هذا مجلد مشروع Android جاهز للبناء، وليس APK مجمّعاً.
لإنشاء APK:
1) افتح Android Studio على كمبيوتر.
2) اختر Open وافتح مجلد WhishProfitAndroid بعد فك ضغط الملف.
3) انتظر Gradle Sync ثم من القائمة Build > Build APK(s).
4) ستجد APK عادةً داخل app/build/outputs/apk/debug/app-debug.apk.

نسخة HTML مستقلة متوفرة أيضاً.
البيانات تحفظ محلياً على نفس المتصفح/التطبيق. خذ نسخة احتياطية JSON دورياً.
لا تدخل كلمات مرور أو رموز تحقق أو معلومات سرية.
