/**
 * QuickVal Local Storage & Persistence Service
 * Manages Market Profiles, Saved Estimates, and User Settings with JSON export/import.
 */

import { MarketProfile, SavedEstimate } from './types';
import { SAMPLE_RUSAPE_PRESET, createEmptyProfile } from './engine';

const PROFILES_KEY = 'quickval_profiles_v1';
const ESTIMATES_KEY = 'quickval_estimates_v1';
const SETTINGS_KEY = 'quickval_settings_v1';
const ACTIVE_PROFILE_KEY = 'quickval_active_profile_id_v1';

export interface AppSettings {
  defaultProfileId: string;
  overpricedThresholdPercent: number; // default 15
  autoSaveEstimates: boolean;
  enableVibration: boolean;
}

const DEFAULT_SETTINGS: AppSettings = {
  defaultProfileId: SAMPLE_RUSAPE_PRESET.id,
  overpricedThresholdPercent: 15,
  autoSaveEstimates: false,
  enableVibration: true,
};

export const MANDATORY_DISCLAIMER =
  'This is a rough, automated estimate for personal guidance only. It is not a valuation by a registered valuer and is not accepted by banks or lenders for collateral or loan purposes. Actual values depend on inspection, title, condition, and market evidence, and may differ significantly. Get a registered valuer for any loan, sale or legal use.';

/**
 * Get all stored market profiles.
 * Initializes with the empty template and optional sample preset on first load.
 */
export function getStoredProfiles(): MarketProfile[] {
  try {
    const raw = localStorage.getItem(PROFILES_KEY);
    if (!raw) {
      const initial = [SAMPLE_RUSAPE_PRESET, createEmptyProfile('Custom Market')];
      saveProfiles(initial);
      return initial;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      const initial = [SAMPLE_RUSAPE_PRESET, createEmptyProfile('Custom Market')];
      saveProfiles(initial);
      return initial;
    }
    return parsed;
  } catch (e) {
    console.error('Error loading profiles from localStorage:', e);
    return [SAMPLE_RUSAPE_PRESET];
  }
}

/**
 * Persist profiles list
 */
export function saveProfiles(profiles: MarketProfile[]): void {
  try {
    localStorage.setItem(PROFILES_KEY, JSON.stringify(profiles));
  } catch (e) {
    console.error('Error saving profiles:', e);
  }
}

/**
 * Get active profile ID
 */
export function getActiveProfileId(availableProfiles: MarketProfile[]): string {
  try {
    const stored = localStorage.getItem(ACTIVE_PROFILE_KEY);
    if (stored && availableProfiles.some((p) => p.id === stored)) {
      return stored;
    }
  } catch {}
  return availableProfiles[0]?.id || SAMPLE_RUSAPE_PRESET.id;
}

/**
 * Set active profile ID
 */
export function setActiveProfileId(id: string): void {
  try {
    localStorage.setItem(ACTIVE_PROFILE_KEY, id);
  } catch {}
}

/**
 * Get saved estimates list
 */
export function getStoredEstimates(): SavedEstimate[] {
  try {
    const raw = localStorage.getItem(ESTIMATES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.error('Error loading saved estimates:', e);
    return [];
  }
}

/**
 * Save an estimate
 */
export function saveEstimate(estimate: SavedEstimate): void {
  try {
    const existing = getStoredEstimates();
    const index = existing.findIndex((e) => e.id === estimate.id);
    let updated: SavedEstimate[];
    if (index >= 0) {
      updated = [...existing];
      updated[index] = estimate;
    } else {
      updated = [estimate, ...existing];
    }
    localStorage.setItem(ESTIMATES_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving estimate:', e);
  }
}

/**
 * Delete a saved estimate
 */
export function deleteEstimate(id: string): void {
  try {
    const existing = getStoredEstimates();
    const updated = existing.filter((e) => e.id !== id);
    localStorage.setItem(ESTIMATES_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Error deleting estimate:', e);
  }
}

/**
 * Get app settings
 */
export function getStoredSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
}

/**
 * Save app settings
 */
export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Error saving settings:', e);
  }
}

/**
 * Export all QuickVal profiles and estimates as formatted JSON string
 */
export function exportAllData(): string {
  const data = {
    app: 'QuickVal',
    version: '1.0',
    exportedAt: new Date().toISOString(),
    profiles: getStoredProfiles(),
    estimates: getStoredEstimates(),
    settings: getStoredSettings(),
  };
  return JSON.stringify(data, null, 2);
}

/**
 * Import QuickVal JSON backup
 */
export function importAllData(jsonStr: string): { success: boolean; message: string } {
  try {
    const parsed = JSON.parse(jsonStr);
    if (!parsed || (!parsed.profiles && !parsed.estimates)) {
      return { success: false, message: 'Invalid QuickVal backup format.' };
    }

    if (Array.isArray(parsed.profiles) && parsed.profiles.length > 0) {
      saveProfiles(parsed.profiles);
    }
    if (Array.isArray(parsed.estimates)) {
      localStorage.setItem(ESTIMATES_KEY, JSON.stringify(parsed.estimates));
    }
    if (parsed.settings) {
      saveSettings({ ...DEFAULT_SETTINGS, ...parsed.settings });
    }

    return {
      success: true,
      message: `Imported ${(parsed.profiles || []).length} profiles and ${(parsed.estimates || []).length} saved estimates.`,
    };
  } catch (e: any) {
    return { success: false, message: e.message || 'Failed to parse JSON backup.' };
  }
}

/**
 * Reset application data to defaults
 */
export function resetAppData(): void {
  localStorage.removeItem(PROFILES_KEY);
  localStorage.removeItem(ESTIMATES_KEY);
  localStorage.removeItem(SETTINGS_KEY);
  localStorage.removeItem(ACTIVE_PROFILE_KEY);
}
