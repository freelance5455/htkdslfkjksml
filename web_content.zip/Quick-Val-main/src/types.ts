/**
 * QuickVal Core Type Definitions
 * Pure data models for market profiles, parameters, calculations, and comparables.
 */

export type AreaUnit = 'sqm' | 'sqft';

export type ParameterInputType = 'number' | 'dropdown' | 'toggle' | 'slider';

export type ParameterEffectType =
  | 'land_multiplier'
  | 'building_multiplier'
  | 'total_percentage'
  | 'fixed_amount'
  | 'building_percentage'
  | 'replacement_multiplier'
  | 'building_and_replacement_multiplier';

export interface DropdownOption {
  id: string;
  label: string;
  value: number; // e.g. 1.05 for multiplier or 0.05 for percentage
}

export interface ParameterConfig {
  id: string;
  label: string;
  description?: string;
  inputType: ParameterInputType;
  effectType: ParameterEffectType;
  defaultValue: number;
  // For dropdowns
  options?: DropdownOption[];
  // For toggles
  valueWhenOn?: number;
  valueWhenOff?: number;
  labelOn?: string;
  labelOff?: string;
  // For sliders or numbers
  min?: number;
  max?: number;
  step?: number;
  unitSuffix?: string; // e.g. "%" or "$"
  // Property type scoping (if empty or undefined, applies to all)
  applicablePropertyTypeIds?: string[];
}

export interface PropertyTypeConfig {
  id: string;
  name: string;
  description?: string;
  requiresLandArea: boolean; // false for sectional title / apartment
  rateOverrides?: {
    landRate?: number;
    buildingRate?: number;
    replacementRate?: number;
  };
  enabledParameterIds?: string[]; // If defined, only these parameters apply
}

export interface ComparableSale {
  id: string;
  description: string;
  price: number;
  date: string;
  landArea?: number;
  buildingArea?: number;
  sourceNote?: string;
  verified?: boolean;
}

export interface MarketProfile {
  id: string;
  name: string;
  description?: string;
  currency: string; // e.g. "US$", "ZAR", "GBP", "EUR", "$"
  areaUnit: AreaUnit;
  isPreset?: boolean;
  baseRates: {
    landRate: number; // per area unit
    buildingRate: number; // per area unit
    replacementRate: number; // per area unit
  };
  outputSettings: {
    forcedSalePercent: number; // default 75 (means 75%)
    rangeWidthPercent: number; // default 10 (means +/- 10%)
    roundingStep: number; // default 500
  };
  propertyTypes: PropertyTypeConfig[];
  parameters: ParameterConfig[];
  comparables: ComparableSale[];
  updatedAt?: string;
}

export interface BuildingStructure {
  id: string;
  name: string;
  area: number;
  rateOverride?: number;
  replacementRateOverride?: number;
}

export interface EstimateInputs {
  propertyTitle?: string;
  profileId: string;
  propertyTypeId: string;
  landArea: number;
  buildings: BuildingStructure[];
  parameterValues: Record<string, number>; // paramId -> numeric value
  askingPrice?: number;
  notes?: string;
}

export interface CalculationStep {
  key: string;
  title: string;
  formula: string;
  math: string;
  value: number;
  formattedValue: string;
  notes?: string;
}

export interface CalculationResult {
  unrounded: {
    landValue: number;
    buildingValue: number;
    additionsValue: number;
    subtotal: number;
    marketValue: number;
    forcedSaleValue: number;
    replacementCost: number;
    rangeLow: number;
    rangeHigh: number;
  };
  landValue: number;
  buildingValue: number;
  additionsValue: number;
  subtotal: number;
  marketValue: number;
  forcedSaleValue: number;
  replacementCost: number;
  rangeLow: number;
  rangeHigh: number;
  // Asking price comparison
  askingPrice?: number;
  askingPriceGapPercent?: number; // e.g. +18.5%
  isOverpriced?: boolean;
  // Detailed step-by-step breakdown
  steps: CalculationStep[];
  // Parameter contributions breakdown for user inspection
  parameterBreakdowns: {
    parameterId: string;
    label: string;
    effectType: ParameterEffectType;
    value: number;
    displayValue: string;
    impactAmount: number;
    description: string;
  }[];
}

export interface SavedEstimate {
  id: string;
  title: string;
  createdAt: string;
  inputs: EstimateInputs;
  result: CalculationResult;
  profileSnapshot: MarketProfile; // frozen snapshot so profile changes don't corrupt history
}

export interface ComparableCrossCheckResult {
  comparableCount: number;
  medianRatePerBuildingUnit: number | null;
  medianRatePerLandUnit: number | null;
  impliedValue: number | null;
  gapPercent: number | null;
  hasLargeGap: boolean; // > 15%
  analysisMessage: string;
}

export interface CalibrationTarget {
  id: string;
  title: string;
  inputs: EstimateInputs;
  knownMarketValue: number;
  knownLandValue?: number;
  knownForcedSaleValue?: number;
  knownReplacementCost?: number;
}

export interface CalibrationResult {
  suggestedLandRate: number;
  suggestedBuildingRate: number;
  suggestedReplacementRate: number;
  suggestedForcedSalePercent: number;
  currentRates: {
    landRate: number;
    buildingRate: number;
    replacementRate: number;
    forcedSalePercent: number;
  };
  sampleCount: number;
  explanation: string;
}

export interface ExtractedValuationReport {
  propertyTitle?: string;
  location?: string;
  propertyType?: string;
  landArea?: number;
  buildings?: { name: string; area: number }[];
  condition?: string;
  finishes?: string;
  titleType?: string;
  statedMarketValue?: number;
  statedLandValue?: number;
  statedForcedSaleValue?: number;
  statedReplacementCost?: number;
  otherNotableFactors?: { label: string; observedValue: string; suggestedEffect?: string }[];
  rawNotes?: string;
}

export interface SuggestedParameterProposal {
  label: string;
  description: string;
  inputType: ParameterInputType;
  effectType: ParameterEffectType;
  defaultValue: number;
  options?: { label: string; value: number }[];
  valueWhenOn?: number;
  valueWhenOff?: number;
  labelOn?: string;
  labelOff?: string;
  min?: number;
  max?: number;
  step?: number;
  unitSuffix?: string;
  justification: string;
}
