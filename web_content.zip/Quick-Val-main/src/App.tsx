/**
 * QuickVal - Universal Mobile-First Property Valuation Tool
 * Pure-engine valuation calculator with custom market profiles and Gemini report parsing.
 */

import React, { useState } from 'react';
import { TabId, TabBar } from './components/TabBar';
import { Navbar } from './components/Navbar';
import { EstimateTab } from './components/EstimateTab';
import { SavedTab } from './components/SavedTab';
import { ProfilesTab } from './components/ProfilesTab';
import { SettingsTab } from './components/SettingsTab';
import { UserManualModal } from './components/UserManualModal';
import {
  EstimateInputs,
  MarketProfile,
  SavedEstimate,
} from './types';
import {
  getStoredProfiles,
  saveProfiles,
  getActiveProfileId,
  setActiveProfileId,
  getStoredEstimates,
  saveEstimate,
  deleteEstimate,
  getStoredSettings,
  saveSettings,
  exportAllData,
  importAllData,
  resetAppData,
} from './storage';
import { SAMPLE_RUSAPE_PRESET } from './engine';

export default function App() {
  const [profiles, setProfiles] = useState<MarketProfile[]>(() => getStoredProfiles());
  const [activeProfileId, setActiveProfileIdState] = useState<string>(() =>
    getActiveProfileId(getStoredProfiles())
  );
  const [savedEstimates, setSavedEstimates] = useState<SavedEstimate[]>(() =>
    getStoredEstimates()
  );
  const [settings, setSettings] = useState(() => getStoredSettings());
  const [activeTab, setActiveTab] = useState<TabId>('estimate');
  const [showUserManualModal, setShowUserManualModal] = useState(false);

  // Active profile object
  const activeProfile =
    profiles.find((p) => p.id === activeProfileId) || profiles[0] || SAMPLE_RUSAPE_PRESET;

  // Initialize inputs for estimate form with active profile defaults
  const createDefaultInputs = (prof: MarketProfile): EstimateInputs => {
    const initialParams: Record<string, number> = {};
    for (const param of prof.parameters) {
      initialParams[param.id] = param.defaultValue ?? 0;
    }

    return {
      propertyTitle: prof.id === SAMPLE_RUSAPE_PRESET.id ? 'Rusape Residential Property' : 'Property Valuation',
      profileId: prof.id,
      propertyTypeId: prof.propertyTypes[0]?.id || 'pt-residential',
      landArea: prof.id === SAMPLE_RUSAPE_PRESET.id ? 1887 : 1000,
      buildings:
        prof.id === SAMPLE_RUSAPE_PRESET.id
          ? [
              { id: 'b1', name: 'Main House', area: 126.97 },
              { id: 'b2', name: 'Garage / Store', area: 62.17 },
            ]
          : [{ id: 'b1', name: 'Main Building', area: 150 }],
      parameterValues: initialParams,
      askingPrice: undefined,
      notes: '',
    };
  };

  const [currentInputs, setCurrentInputs] = useState<EstimateInputs>(() =>
    createDefaultInputs(activeProfile)
  );

  // Profile switch handler
  const handleSelectProfile = (id: string) => {
    setActiveProfileIdState(id);
    setActiveProfileId(id);
    const newProfile = profiles.find((p) => p.id === id);
    if (newProfile) {
      setCurrentInputs(createDefaultInputs(newProfile));
    }
  };

  // Update profiles handler
  const handleUpdateProfiles = (updatedProfiles: MarketProfile[]) => {
    setProfiles(updatedProfiles);
    saveProfiles(updatedProfiles);
  };

  // Save estimate handler
  const handleSaveEstimate = (estimate: SavedEstimate) => {
    saveEstimate(estimate);
    setSavedEstimates(getStoredEstimates());
  };

  // Delete estimate handler
  const handleDeleteEstimate = (id: string) => {
    deleteEstimate(id);
    setSavedEstimates(getStoredEstimates());
  };

  // Load saved estimate into active form
  const handleLoadEstimate = (est: SavedEstimate) => {
    // If the estimate's profile exists, switch to it, otherwise add or use current
    const matchingProfile = profiles.find((p) => p.id === est.inputs.profileId);
    if (matchingProfile) {
      setActiveProfileIdState(matchingProfile.id);
      setActiveProfileId(matchingProfile.id);
    }
    setCurrentInputs({
      ...est.inputs,
      propertyTitle: est.title,
    });
    setActiveTab('estimate');
  };

  // Reset to new estimate
  const handleNewEstimate = () => {
    setCurrentInputs(createDefaultInputs(activeProfile));
  };

  // Full backup & restore handlers
  const handleExportAll = () => {
    const jsonStr = exportAllData();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(jsonStr);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `quickval_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportAll = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e: any) => {
      const file = e.target?.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        const res = importAllData(content);
        if (res.success) {
          setProfiles(getStoredProfiles());
          setSavedEstimates(getStoredEstimates());
          setSettings(getStoredSettings());
          alert(res.message);
        } else {
          alert(`Import failed: ${res.message}`);
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const handleResetAllData = () => {
    resetAppData();
    const refreshedProfiles = getStoredProfiles();
    setProfiles(refreshedProfiles);
    setActiveProfileIdState(refreshedProfiles[0]?.id || SAMPLE_RUSAPE_PRESET.id);
    setSavedEstimates([]);
    setSettings(getStoredSettings());
    setCurrentInputs(createDefaultInputs(refreshedProfiles[0] || SAMPLE_RUSAPE_PRESET));
    setActiveTab('estimate');
  };

  return (
    <div className="min-h-screen bg-neutral-100/60 text-neutral-900 font-sans flex flex-col selection:bg-emerald-200">
      {/* Top Navbar */}
      <Navbar
        profiles={profiles}
        activeProfile={activeProfile}
        onSelectProfile={handleSelectProfile}
        onOpenUserManual={() => setShowUserManualModal(true)}
        onNewEstimate={handleNewEstimate}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full">
        {activeTab === 'estimate' && (
          <EstimateTab
            profile={activeProfile}
            inputs={currentInputs}
            onUpdateInputs={setCurrentInputs}
            onResetEstimate={handleNewEstimate}
            overpricedThresholdPercent={settings.overpricedThresholdPercent}
          />
        )}

        {activeTab === 'saved' && (
          <SavedTab
            estimates={savedEstimates}
            onDeleteEstimate={handleDeleteEstimate}
            onLoadEstimate={handleLoadEstimate}
            onExportJson={handleExportAll}
            onImportJson={handleImportAll}
          />
        )}

        {activeTab === 'profiles' && (
          <ProfilesTab
            profiles={profiles}
            activeProfileId={activeProfileId}
            onSelectActiveProfile={handleSelectProfile}
            onUpdateProfiles={handleUpdateProfiles}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsTab
            settings={settings}
            profiles={profiles}
            onUpdateSettings={(newSettings) => {
              setSettings(newSettings);
              saveSettings(newSettings);
            }}
            onResetAllData={handleResetAllData}
            onExportAll={handleExportAll}
            onImportAll={handleImportAll}
          />
        )}
      </main>

      {/* Bottom Sticky Tab Bar */}
      <TabBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        savedCount={savedEstimates.length}
        profilesCount={profiles.length}
      />

      {/* User Manual & PDF Generator Modal */}
      <UserManualModal
        isOpen={showUserManualModal}
        onClose={() => setShowUserManualModal(false)}
      />
    </div>
  );
}
