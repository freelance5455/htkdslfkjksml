/**
 * QuickVal Valuation Engine
 *
 * PURE, DETERMINISTIC VALUATION FUNCTIONS
 * All calculation logic lives exclusively in this file and is 100% driven by JSON configuration.
 * Adding new parameters, property types, or custom adjustment types never requires altering calculation code.
 */

import {
  CalculationResult,
  CalculationStep,
  CalibrationResult,
  CalibrationTarget,
  ComparableCrossCheckResult,
  ComparableSale,
  EstimateInputs,
  MarketProfile,
  ParameterConfig,
  PropertyTypeConfig,
} from './types';

/**
 * Rounds a number to the nearest step (e.g., 500, 1000, 100).
 * If step is <= 0, returns the unrounded value.
 */
export function roundToStep(value: number, step: number): number {
  if (isNaN(value) || !isFinite(value)) return 0;
  if (!step || step <= 0) return Math.round(value);
  return Math.round(value / step) * step;
}

/**
 * Format currency with thousands separators and optional decimals
 */
export function formatCurrency(
  amount: number,
  currency: string = '$',
  decimals: number = 0
): string {
  if (isNaN(amount) || !isFinite(amount)) return `${currency} 0`;
  const formatted = Math.abs(amount).toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  const sign = amount < 0 ? '-' : '';
  return `${sign}${currency} ${formatted}`;
}

/**
 * Format area with unit
 */
export function formatArea(area: number, unit: string = 'sqm'): string {
  const formatted = (area || 0).toLocaleString('en-US', {
    maximumFractionDigits: 2,
  });
  return `${formatted} ${unit}`;
}

/**
 * Filter parameters applicable to a specific property type.
 * If applicablePropertyTypeIds is omitted or empty, the parameter applies to all property types.
 */
export function getApplicableParameters(
  parameters: ParameterConfig[],
  propertyTypeId: string
): ParameterConfig[] {
  return parameters.filter((param) => {
    if (
      !param.applicablePropertyTypeIds ||
      param.applicablePropertyTypeIds.length === 0
    ) {
      return true;
    }
    return param.applicablePropertyTypeIds.includes(propertyTypeId);
  });
}

/**
 * Resolve effective base rates, taking into account any property type overrides.
 */
export function getEffectiveBaseRates(
  profile: MarketProfile,
  propertyType?: PropertyTypeConfig
) {
  const base = profile.baseRates;
  const overrides = propertyType?.rateOverrides;
  return {
    landRate: overrides?.landRate ?? base.landRate,
    buildingRate: overrides?.buildingRate ?? base.buildingRate,
    replacementRate: overrides?.replacementRate ?? base.replacementRate,
  };
}

/**
 * CORE VALUATION PIPELINE
 *
 * Steps:
 * 1. Land Value = land area x land rate x product of all "land multiplier" parameters
 * 2. Building Value = sum(building area x building rate) x product of all "building multiplier" parameters
 * 3. Additions to building value (e.g. external works) = building value x sum of "percentage of building value" parameters
 * 4. Subtotal = Land + Building + Additions
 * 5. Market Value = Subtotal x (1 + sum of "% on total" adjustments) + sum of fixed amounts
 * 6. Forced Sale Value = Market Value x (forced sale % / 100)
 * 7. Gross Replacement Cost = sum(building area x replacement rate) x product of "replacement multiplier" parameters
 * 8. Range = Market Value x (1 - range %) to Market Value x (1 + range %)
 * 9. Round all outputs to the profile's rounding step.
 */
export function calculateValuation(
  inputs: EstimateInputs,
  profile: MarketProfile,
  options?: { overpricedThresholdPercent?: number }
): CalculationResult {
  const roundingStep = profile.outputSettings.roundingStep || 500;
  const forcedSaleRatio = (profile.outputSettings.forcedSalePercent ?? 75) / 100;
  const rangeWidthRatio = (profile.outputSettings.rangeWidthPercent ?? 10) / 100;
  const currency = profile.currency || '$';
  const unit = profile.areaUnit || 'sqm';
  const overpricedThreshold = options?.overpricedThresholdPercent ?? 15;

  const propertyType = profile.propertyTypes.find(
    (pt) => pt.id === inputs.propertyTypeId
  );
  const effectiveRates = getEffectiveBaseRates(profile, propertyType);
  const activeParams = getApplicableParameters(
    profile.parameters,
    inputs.propertyTypeId
  );

  const steps: CalculationStep[] = [];
  const parameterBreakdowns: CalculationResult['parameterBreakdowns'] = [];

  // --------------------------------------------------------------------------
  // STEP 1: Land Value
  // --------------------------------------------------------------------------
  const landArea = propertyType && !propertyType.requiresLandArea ? 0 : Math.max(0, inputs.landArea || 0);
  const landRate = effectiveRates.landRate;
  const rawLandBase = landArea * landRate;

  // Filter land multipliers
  const landMultiplierParams = activeParams.filter(
    (p) => p.effectType === 'land_multiplier'
  );
  let landMultiplierProduct = 1.0;
  const landMultiplierDetails: string[] = [];

  for (const param of landMultiplierParams) {
    const val = inputs.parameterValues[param.id] ?? param.defaultValue ?? 1.0;
    landMultiplierProduct *= val;
    landMultiplierDetails.push(`${param.label} (x${val.toFixed(2)})`);

    parameterBreakdowns.push({
      parameterId: param.id,
      label: param.label,
      effectType: param.effectType,
      value: val,
      displayValue: `x${val.toFixed(2)}`,
      impactAmount: rawLandBase * (val - 1),
      description: `Multiplier on land base (${val > 1 ? '+' : ''}${Math.round((val - 1) * 100)}%)`,
    });
  }

  const rawLandValue = rawLandBase * landMultiplierProduct;

  steps.push({
    key: 'land_value',
    title: '1. Land Value',
    formula: 'Land Area × Land Rate × Product of Land Multipliers',
    math: `${formatArea(landArea, unit)} × ${formatCurrency(landRate, currency)}/unit ${
      landMultiplierDetails.length > 0 ? `× [${landMultiplierDetails.join(' × ')}]` : ''
    } = ${formatCurrency(rawLandValue, currency, 2)}`,
    value: rawLandValue,
    formattedValue: formatCurrency(roundToStep(rawLandValue, roundingStep), currency),
    notes: landMultiplierParams.length > 0
      ? `Base land: ${formatCurrency(rawLandBase, currency, 2)} with combined multiplier of x${landMultiplierProduct.toFixed(3)}.`
      : `Base land calculated with no additional multipliers.`,
  });

  // --------------------------------------------------------------------------
  // STEP 2: Building Value
  // --------------------------------------------------------------------------
  let rawBuildingBase = 0;
  const buildingBreakdownParts: string[] = [];
  const buildings = inputs.buildings || [];

  for (const b of buildings) {
    const bArea = Math.max(0, b.area || 0);
    const bRate = b.rateOverride !== undefined && b.rateOverride !== null
      ? b.rateOverride
      : effectiveRates.buildingRate;
    const bCost = bArea * bRate;
    rawBuildingBase += bCost;
    buildingBreakdownParts.push(
      `${b.name || 'Building'}: ${formatArea(bArea, unit)} @ ${formatCurrency(bRate, currency)}/unit = ${formatCurrency(bCost, currency, 2)}`
    );
  }

  // Building multipliers (and hybrid building_and_replacement_multiplier)
  const buildingMultiplierParams = activeParams.filter(
    (p) =>
      p.effectType === 'building_multiplier' ||
      p.effectType === 'building_and_replacement_multiplier'
  );

  let buildingMultiplierProduct = 1.0;
  const buildingMultiplierDetails: string[] = [];

  for (const param of buildingMultiplierParams) {
    const val = inputs.parameterValues[param.id] ?? param.defaultValue ?? 1.0;
    buildingMultiplierProduct *= val;
    buildingMultiplierDetails.push(`${param.label} (x${val.toFixed(2)})`);

    parameterBreakdowns.push({
      parameterId: param.id,
      label: param.label,
      effectType: param.effectType,
      value: val,
      displayValue: `x${val.toFixed(2)}`,
      impactAmount: rawBuildingBase * (val - 1),
      description: `Multiplier on building value (${val > 1 ? '+' : ''}${Math.round((val - 1) * 100)}%)`,
    });
  }

  const rawBuildingValue = rawBuildingBase * buildingMultiplierProduct;

  steps.push({
    key: 'building_value',
    title: '2. Building Value',
    formula: 'Sum(Building Area × Rate) × Product of Building Multipliers',
    math: `${formatCurrency(rawBuildingBase, currency, 2)} ${
      buildingMultiplierDetails.length > 0 ? `× [${buildingMultiplierDetails.join(' × ')}]` : ''
    } = ${formatCurrency(rawBuildingValue, currency, 2)}`,
    value: rawBuildingValue,
    formattedValue: formatCurrency(roundToStep(rawBuildingValue, roundingStep), currency),
    notes: buildingBreakdownParts.length > 0
      ? `Structures: ${buildingBreakdownParts.join(', ')}.`
      : `No structures entered.`,
  });

  // --------------------------------------------------------------------------
  // STEP 3: Additions to building value (e.g. external works)
  // --------------------------------------------------------------------------
  const buildingPercentageParams = activeParams.filter(
    (p) => p.effectType === 'building_percentage'
  );
  let totalBuildingPercentageSum = 0;
  const additionDetails: string[] = [];

  for (const param of buildingPercentageParams) {
    const val = inputs.parameterValues[param.id] ?? param.defaultValue ?? 0;
    totalBuildingPercentageSum += val;
    const itemAmount = rawBuildingValue * val;
    additionDetails.push(`${param.label} (${(val * 100).toFixed(1)}% = ${formatCurrency(itemAmount, currency, 2)})`);

    parameterBreakdowns.push({
      parameterId: param.id,
      label: param.label,
      effectType: param.effectType,
      value: val,
      displayValue: `${(val * 100).toFixed(1)}%`,
      impactAmount: itemAmount,
      description: `Addition as % of building value`,
    });
  }

  const rawAdditionsValue = rawBuildingValue * totalBuildingPercentageSum;

  steps.push({
    key: 'additions_value',
    title: '3. Additions to Building Value (e.g. External Works)',
    formula: 'Building Value × Sum of Building Percentage Parameters',
    math: `${formatCurrency(rawBuildingValue, currency, 2)} × ${(totalBuildingPercentageSum * 100).toFixed(1)}% = ${formatCurrency(rawAdditionsValue, currency, 2)}`,
    value: rawAdditionsValue,
    formattedValue: formatCurrency(roundToStep(rawAdditionsValue, roundingStep), currency),
    notes: additionDetails.length > 0
      ? additionDetails.join('; ')
      : 'No building addition parameters active.',
  });

  // --------------------------------------------------------------------------
  // STEP 4: Subtotal
  // --------------------------------------------------------------------------
  const rawSubtotal = rawLandValue + rawBuildingValue + rawAdditionsValue;

  steps.push({
    key: 'subtotal',
    title: '4. Subtotal',
    formula: 'Land Value + Building Value + Additions',
    math: `${formatCurrency(rawLandValue, currency, 2)} + ${formatCurrency(rawBuildingValue, currency, 2)} + ${formatCurrency(rawAdditionsValue, currency, 2)} = ${formatCurrency(rawSubtotal, currency, 2)}`,
    value: rawSubtotal,
    formattedValue: formatCurrency(roundToStep(rawSubtotal, roundingStep), currency),
    notes: 'Combined physical property asset base before market and overall adjustments.',
  });

  // --------------------------------------------------------------------------
  // STEP 5: Market Value
  // --------------------------------------------------------------------------
  // Total % adjustments
  const totalPercentageParams = activeParams.filter(
    (p) => p.effectType === 'total_percentage'
  );
  let sumOfTotalPercentages = 0;
  const totalPercentageDetails: string[] = [];

  for (const param of totalPercentageParams) {
    const val = inputs.parameterValues[param.id] ?? param.defaultValue ?? 0;
    sumOfTotalPercentages += val;
    const impact = rawSubtotal * val;
    totalPercentageDetails.push(`${param.label} (${val >= 0 ? '+' : ''}${(val * 100).toFixed(1)}%)`);

    parameterBreakdowns.push({
      parameterId: param.id,
      label: param.label,
      effectType: param.effectType,
      value: val,
      displayValue: `${val >= 0 ? '+' : ''}${(val * 100).toFixed(1)}%`,
      impactAmount: impact,
      description: `Adjustment on subtotal`,
    });
  }

  // Fixed amounts
  const fixedAmountParams = activeParams.filter(
    (p) => p.effectType === 'fixed_amount'
  );
  let sumOfFixedAmounts = 0;
  const fixedAmountDetails: string[] = [];

  for (const param of fixedAmountParams) {
    const val = inputs.parameterValues[param.id] ?? param.defaultValue ?? 0;
    sumOfFixedAmounts += val;
    fixedAmountDetails.push(`${param.label} (${formatCurrency(val, currency)})`);

    parameterBreakdowns.push({
      parameterId: param.id,
      label: param.label,
      effectType: param.effectType,
      value: val,
      displayValue: formatCurrency(val, currency),
      impactAmount: val,
      description: `Fixed sum adjustment`,
    });
  }

  const rawMarketValue =
    rawSubtotal * (1 + sumOfTotalPercentages) + sumOfFixedAmounts;

  const marketValueMathParts = [`${formatCurrency(rawSubtotal, currency, 2)} × (1 + ${(sumOfTotalPercentages * 100).toFixed(1)}%)`];
  if (sumOfFixedAmounts !== 0) {
    marketValueMathParts.push(`${sumOfFixedAmounts >= 0 ? '+' : '-'} ${formatCurrency(Math.abs(sumOfFixedAmounts), currency)}`);
  }

  steps.push({
    key: 'market_value',
    title: '5. Market Value (Unrounded)',
    formula: 'Subtotal × (1 + Sum of % Adjustments) + Sum of Fixed Amounts',
    math: `${marketValueMathParts.join(' ')} = ${formatCurrency(rawMarketValue, currency, 2)}`,
    value: rawMarketValue,
    formattedValue: formatCurrency(roundToStep(rawMarketValue, roundingStep), currency),
    notes: [
      totalPercentageDetails.length > 0 ? `Total % adjustments: ${totalPercentageDetails.join(', ')}.` : null,
      fixedAmountDetails.length > 0 ? `Fixed amounts: ${fixedAmountDetails.join(', ')}.` : null,
    ].filter(Boolean).join(' ') || 'No secondary total adjustments applied.',
  });

  // --------------------------------------------------------------------------
  // STEP 6: Forced Sale Value
  // --------------------------------------------------------------------------
  const rawForcedSaleValue = rawMarketValue * forcedSaleRatio;

  steps.push({
    key: 'forced_sale_value',
    title: '6. Forced Sale Value (Liquidation Estimate)',
    formula: `Market Value × Forced Sale % (${(forcedSaleRatio * 100).toFixed(0)}%)`,
    math: `${formatCurrency(rawMarketValue, currency, 2)} × ${(forcedSaleRatio * 100).toFixed(1)}% = ${formatCurrency(rawForcedSaleValue, currency, 2)}`,
    value: rawForcedSaleValue,
    formattedValue: formatCurrency(roundToStep(rawForcedSaleValue, roundingStep), currency),
    notes: `Represents expected realization in rapid, distressed, or bank-mandated sale circumstances.`,
  });

  // --------------------------------------------------------------------------
  // STEP 7: Gross Replacement Cost
  // --------------------------------------------------------------------------
  let rawReplacementBase = 0;
  for (const b of buildings) {
    const bArea = Math.max(0, b.area || 0);
    const repRate = b.replacementRateOverride !== undefined && b.replacementRateOverride !== null
      ? b.replacementRateOverride
      : effectiveRates.replacementRate;
    rawReplacementBase += bArea * repRate;
  }

  const replacementMultiplierParams = activeParams.filter(
    (p) =>
      p.effectType === 'replacement_multiplier' ||
      p.effectType === 'building_and_replacement_multiplier'
  );
  let replacementMultiplierProduct = 1.0;
  const replacementMultiplierDetails: string[] = [];

  for (const param of replacementMultiplierParams) {
    const val = inputs.parameterValues[param.id] ?? param.defaultValue ?? 1.0;
    replacementMultiplierProduct *= val;
    replacementMultiplierDetails.push(`${param.label} (x${val.toFixed(2)})`);
  }

  const rawReplacementCost = rawReplacementBase * replacementMultiplierProduct;

  steps.push({
    key: 'replacement_cost',
    title: '7. Gross Replacement Cost',
    formula: 'Sum(Building Area × Replacement Rate) × Product of Replacement Multipliers',
    math: `${formatCurrency(rawReplacementBase, currency, 2)} ${
      replacementMultiplierDetails.length > 0 ? `× [${replacementMultiplierDetails.join(' × ')}]` : ''
    } = ${formatCurrency(rawReplacementCost, currency, 2)}`,
    value: rawReplacementCost,
    formattedValue: formatCurrency(roundToStep(rawReplacementCost, roundingStep), currency),
    notes: `Estimated current cost to reconstruct all existing structures like-for-like as new.`,
  });

  // --------------------------------------------------------------------------
  // STEP 8: Valuation Range
  // --------------------------------------------------------------------------
  const rawRangeLow = rawMarketValue * (1 - rangeWidthRatio);
  const rawRangeHigh = rawMarketValue * (1 + rangeWidthRatio);

  steps.push({
    key: 'valuation_range',
    title: '8. Estimated Value Range',
    formula: `Market Value ± Range Width (${(rangeWidthRatio * 100).toFixed(0)}%)`,
    math: `${formatCurrency(rawRangeLow, currency, 2)} – ${formatCurrency(rawRangeHigh, currency, 2)}`,
    value: rawMarketValue,
    formattedValue: `${formatCurrency(roundToStep(rawRangeLow, roundingStep), currency)} – ${formatCurrency(roundToStep(rawRangeHigh, roundingStep), currency)}`,
    notes: `Reflects normal market negotiation variance and statistical dispersion.`,
  });

  // --------------------------------------------------------------------------
  // STEP 9: Rounding
  // --------------------------------------------------------------------------
  const roundedLandValue = roundToStep(rawLandValue, roundingStep);
  const roundedBuildingValue = roundToStep(rawBuildingValue, roundingStep);
  const roundedAdditionsValue = roundToStep(rawAdditionsValue, roundingStep);
  const roundedSubtotal = roundToStep(rawSubtotal, roundingStep);
  const roundedMarketValue = roundToStep(rawMarketValue, roundingStep);
  const roundedForcedSaleValue = roundToStep(rawForcedSaleValue, roundingStep);
  const roundedReplacementCost = roundToStep(rawReplacementCost, roundingStep);
  const roundedRangeLow = roundToStep(rawRangeLow, roundingStep);
  const roundedRangeHigh = roundToStep(rawRangeHigh, roundingStep);

  steps.push({
    key: 'rounding_step',
    title: '9. Output Rounding',
    formula: `Round all final outputs to nearest step (${formatCurrency(roundingStep, currency)})`,
    math: `Market: ${formatCurrency(roundedMarketValue, currency)} | Forced Sale: ${formatCurrency(roundedForcedSaleValue, currency)} | Replacement: ${formatCurrency(roundedReplacementCost, currency)}`,
    value: roundedMarketValue,
    formattedValue: formatCurrency(roundedMarketValue, currency),
    notes: `Applied profile rounding step of ${formatCurrency(roundingStep, currency)} to avoid false precision.`,
  });

  // --------------------------------------------------------------------------
  // Asking Price Analysis (if entered)
  // --------------------------------------------------------------------------
  let askingPriceGapPercent: number | undefined;
  let isOverpriced: boolean | undefined;

  if (inputs.askingPrice && inputs.askingPrice > 0 && roundedMarketValue > 0) {
    askingPriceGapPercent =
      ((inputs.askingPrice - roundedMarketValue) / roundedMarketValue) * 100;
    isOverpriced = askingPriceGapPercent > overpricedThreshold;
  }

  return {
    unrounded: {
      landValue: rawLandValue,
      buildingValue: rawBuildingValue,
      additionsValue: rawAdditionsValue,
      subtotal: rawSubtotal,
      marketValue: rawMarketValue,
      forcedSaleValue: rawForcedSaleValue,
      replacementCost: rawReplacementCost,
      rangeLow: rawRangeLow,
      rangeHigh: rawRangeHigh,
    },
    landValue: roundedLandValue,
    buildingValue: roundedBuildingValue,
    additionsValue: roundedAdditionsValue,
    subtotal: roundedSubtotal,
    marketValue: roundedMarketValue,
    forcedSaleValue: roundedForcedSaleValue,
    replacementCost: roundedReplacementCost,
    rangeLow: roundedRangeLow,
    rangeHigh: roundedRangeHigh,
    askingPrice: inputs.askingPrice,
    askingPriceGapPercent,
    isOverpriced,
    steps,
    parameterBreakdowns,
  };
}

/**
 * COMPARABLES CROSS-CHECK
 * Calculates median price per area unit and implied value for the subject property.
 */
export function calculateComparableCrossCheck(
  comparables: ComparableSale[],
  subjectInputs: EstimateInputs,
  subjectMarketValue: number,
  profile: MarketProfile
): ComparableCrossCheckResult {
  const validComparables = comparables.filter(
    (c) => c.price > 0 && ((c.buildingArea && c.buildingArea > 0) || (c.landArea && c.landArea > 0))
  );

  if (validComparables.length < 2) {
    return {
      comparableCount: validComparables.length,
      medianRatePerBuildingUnit: null,
      medianRatePerLandUnit: null,
      impliedValue: null,
      gapPercent: null,
      hasLargeGap: false,
      analysisMessage: 'Need at least 2 comparable sales with area data to calculate benchmark cross-check.',
    };
  }

  // Calculate building rates for comparables that have building area
  const buildingRates: number[] = [];
  const landRates: number[] = [];

  for (const c of validComparables) {
    if (c.buildingArea && c.buildingArea > 0) {
      buildingRates.push(c.price / c.buildingArea);
    }
    if (c.landArea && c.landArea > 0) {
      landRates.push(c.price / c.landArea);
    }
  }

  const getMedian = (nums: number[]): number | null => {
    if (nums.length === 0) return null;
    const sorted = [...nums].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 !== 0
      ? sorted[mid]
      : (sorted[mid - 1] + sorted[mid]) / 2;
  };

  const medianBuildingRate = getMedian(buildingRates);
  const medianLandRate = getMedian(landRates);

  // Subject areas
  const totalSubjectBuildingArea = (subjectInputs.buildings || []).reduce(
    (sum, b) => sum + (b.area || 0),
    0
  );
  const subjectLandArea = subjectInputs.landArea || 0;

  let impliedValue: number | null = null;

  if (medianBuildingRate && totalSubjectBuildingArea > 0) {
    // Primary check: based on total building area
    impliedValue = roundToStep(
      totalSubjectBuildingArea * medianBuildingRate,
      profile.outputSettings.roundingStep || 500
    );
  } else if (medianLandRate && subjectLandArea > 0) {
    // Secondary check: based on land area
    impliedValue = roundToStep(
      subjectLandArea * medianLandRate,
      profile.outputSettings.roundingStep || 500
    );
  }

  let gapPercent: number | null = null;
  let hasLargeGap = false;

  if (impliedValue !== null && impliedValue > 0 && subjectMarketValue > 0) {
    gapPercent = ((subjectMarketValue - impliedValue) / impliedValue) * 100;
    hasLargeGap = Math.abs(gapPercent) > 15;
  }

  let analysisMessage = '';
  if (hasLargeGap) {
    analysisMessage = `Notice: ${Math.abs(gapPercent!).toFixed(1)}% gap between calculated estimate and comparables median. Check your rates or comparable adjustments.`;
  } else if (gapPercent !== null) {
    analysisMessage = `Consistent: Calculated estimate aligns within ${Math.abs(gapPercent).toFixed(1)}% of comparable market evidence.`;
  } else {
    analysisMessage = 'Comparables analyzed; insufficient subject area data to derive direct implied value.';
  }

  return {
    comparableCount: validComparables.length,
    medianRatePerBuildingUnit: medianBuildingRate,
    medianRatePerLandUnit: medianLandRate,
    impliedValue,
    gapPercent,
    hasLargeGap,
    analysisMessage,
  };
}

/**
 * CALIBRATION ENGINE
 * Solves for suggested base rates from one or more known property valuations.
 */
export function calibrateProfileRates(
  targets: CalibrationTarget[],
  profile: MarketProfile
): CalibrationResult {
  const validTargets = targets.filter(
    (t) => t.knownMarketValue > 0 && (t.inputs.landArea > 0 || (t.inputs.buildings && t.inputs.buildings.length > 0))
  );

  if (validTargets.length === 0) {
    return {
      suggestedLandRate: profile.baseRates.landRate,
      suggestedBuildingRate: profile.baseRates.buildingRate,
      suggestedReplacementRate: profile.baseRates.replacementRate,
      suggestedForcedSalePercent: profile.outputSettings.forcedSalePercent,
      currentRates: {
        landRate: profile.baseRates.landRate,
        buildingRate: profile.baseRates.buildingRate,
        replacementRate: profile.baseRates.replacementRate,
        forcedSalePercent: profile.outputSettings.forcedSalePercent,
      },
      sampleCount: 0,
      explanation: 'No valid calibration targets with positive valuation figures provided.',
    };
  }

  const suggestedLandRates: number[] = [];
  const suggestedBuildingRates: number[] = [];
  const suggestedReplacementRates: number[] = [];
  const suggestedForcedSalePercents: number[] = [];

  for (const target of validTargets) {
    const inputs = target.inputs;
    const activeParams = getApplicableParameters(profile.parameters, inputs.propertyTypeId);

    // Multipliers
    let landMult = 1.0;
    for (const p of activeParams.filter((x) => x.effectType === 'land_multiplier')) {
      landMult *= inputs.parameterValues[p.id] ?? p.defaultValue ?? 1.0;
    }

    let bldMult = 1.0;
    for (const p of activeParams.filter(
      (x) => x.effectType === 'building_multiplier' || x.effectType === 'building_and_replacement_multiplier'
    )) {
      bldMult *= inputs.parameterValues[p.id] ?? p.defaultValue ?? 1.0;
    }

    let bldAddPct = 0;
    for (const p of activeParams.filter((x) => x.effectType === 'building_percentage')) {
      bldAddPct += inputs.parameterValues[p.id] ?? p.defaultValue ?? 0;
    }

    let totalPct = 0;
    for (const p of activeParams.filter((x) => x.effectType === 'total_percentage')) {
      totalPct += inputs.parameterValues[p.id] ?? p.defaultValue ?? 0;
    }

    let fixedSum = 0;
    for (const p of activeParams.filter((x) => x.effectType === 'fixed_amount')) {
      fixedSum += inputs.parameterValues[p.id] ?? p.defaultValue ?? 0;
    }

    let repMult = 1.0;
    for (const p of activeParams.filter(
      (x) => x.effectType === 'replacement_multiplier' || x.effectType === 'building_and_replacement_multiplier'
    )) {
      repMult *= inputs.parameterValues[p.id] ?? p.defaultValue ?? 1.0;
    }

    const totalBldArea = (inputs.buildings || []).reduce((s, b) => s + (b.area || 0), 0);
    const landArea = inputs.landArea || 0;

    // 1. Solve land rate if land value is provided
    let targetLandValue: number;
    if (target.knownLandValue && target.knownLandValue > 0 && landArea > 0) {
      targetLandValue = target.knownLandValue;
      const solvedLandRate = targetLandValue / (landArea * landMult);
      if (solvedLandRate > 0) suggestedLandRates.push(solvedLandRate);
    } else {
      // Default to current land rate estimate
      targetLandValue = landArea * profile.baseRates.landRate * landMult;
    }

    // 2. Solve building rate from remaining Market Value
    // targetSubtotal = (knownMarketValue - fixedSum) / (1 + totalPct)
    // buildingPortionWithAdditions = targetSubtotal - targetLandValue
    // buildingValue = buildingPortionWithAdditions / (1 + bldAddPct)
    // buildingRate = buildingValue / (totalBldArea * bldMult)
    if (target.knownMarketValue > 0 && totalBldArea > 0) {
      const targetSubtotal = (target.knownMarketValue - fixedSum) / (1 + totalPct);
      const buildingPortionWithAdditions = Math.max(0, targetSubtotal - targetLandValue);
      const targetBuildingValue = buildingPortionWithAdditions / (1 + bldAddPct);
      const solvedBuildingRate = targetBuildingValue / (totalBldArea * bldMult);
      if (solvedBuildingRate > 0 && isFinite(solvedBuildingRate)) {
        suggestedBuildingRates.push(solvedBuildingRate);
      }
    }

    // 3. Solve replacement rate if known
    if (target.knownReplacementCost && target.knownReplacementCost > 0 && totalBldArea > 0) {
      const solvedRepRate = target.knownReplacementCost / (totalBldArea * repMult);
      if (solvedRepRate > 0 && isFinite(solvedRepRate)) {
        suggestedReplacementRates.push(solvedRepRate);
      }
    }

    // 4. Solve forced sale % if known
    if (target.knownForcedSaleValue && target.knownForcedSaleValue > 0 && target.knownMarketValue > 0) {
      const solvedFS = (target.knownForcedSaleValue / target.knownMarketValue) * 100;
      if (solvedFS > 0 && solvedFS <= 100) {
        suggestedForcedSalePercents.push(solvedFS);
      }
    }
  }

  const average = (arr: number[], fallback: number): number => {
    if (arr.length === 0) return fallback;
    return arr.reduce((a, b) => a + b, 0) / arr.length;
  };

  const finalLandRate = Math.round(average(suggestedLandRates, profile.baseRates.landRate) * 10) / 10;
  const finalBuildingRate = Math.round(average(suggestedBuildingRates, profile.baseRates.buildingRate) * 10) / 10;
  const finalReplacementRate = Math.round(average(suggestedReplacementRates, profile.baseRates.replacementRate) * 10) / 10;
  const finalForcedSalePercent = Math.round(average(suggestedForcedSalePercents, profile.outputSettings.forcedSalePercent));

  return {
    suggestedLandRate: finalLandRate,
    suggestedBuildingRate: finalBuildingRate,
    suggestedReplacementRate: finalReplacementRate,
    suggestedForcedSalePercent: finalForcedSalePercent,
    currentRates: {
      landRate: profile.baseRates.landRate,
      buildingRate: profile.baseRates.buildingRate,
      replacementRate: profile.baseRates.replacementRate,
      forcedSalePercent: profile.outputSettings.forcedSalePercent,
    },
    sampleCount: validTargets.length,
    explanation: `Calculated from ${validTargets.length} sample property valuation(s). Rates averaged and calibrated against current adjustment parameter factors.`,
  };
}

/**
 * DEFAULT SAMPLE PRESET
 * Rusape, Zimbabwe (US$)
 */
export const SAMPLE_RUSAPE_PRESET: MarketProfile = {
  id: 'preset-rusape-zw',
  name: 'Sample: Rusape, Zimbabwe (US$)',
  description: 'Verified residential benchmark for town and peri-urban properties in Rusape, Zimbabwe.',
  currency: 'US$',
  areaUnit: 'sqm',
  isPreset: true,
  baseRates: {
    landRate: 24.9,
    buildingRate: 215,
    replacementRate: 820,
  },
  outputSettings: {
    forcedSalePercent: 75,
    rangeWidthPercent: 10,
    roundingStep: 500,
  },
  propertyTypes: [
    {
      id: 'pt-residential',
      name: 'Residential',
      description: 'Single family detached houses and stands',
      requiresLandArea: true,
    },
    {
      id: 'pt-commercial',
      name: 'Commercial',
      description: 'Shops, offices, and retail premises',
      requiresLandArea: true,
    },
    {
      id: 'pt-vacant-land',
      name: 'Vacant land',
      description: 'Undeveloped residential/commercial stands',
      requiresLandArea: true,
    },
    {
      id: 'pt-industrial',
      name: 'Industrial',
      description: 'Workshops, warehouses, and light manufacturing',
      requiresLandArea: true,
    },
  ],
  parameters: [
    {
      id: 'param-location-zone',
      label: 'Location zone',
      description: 'Neighborhood or zone multiplier on land value',
      inputType: 'dropdown',
      effectType: 'land_multiplier',
      defaultValue: 1.0,
      options: [
        { id: 'cb', label: 'Castle Base (1.00x)', value: 1.0 },
        { id: 'jac', label: 'Jacaranda (1.05x)', value: 1.05 },
        { id: 'cbd', label: 'CBD area (1.10x)', value: 1.1 },
        { id: 'oth', label: 'Other (0.90x)', value: 0.9 },
      ],
    },
    {
      id: 'param-finish-quality',
      label: 'Finish quality',
      description: 'Overall standard of fixtures and interior/exterior finishes',
      inputType: 'dropdown',
      effectType: 'building_and_replacement_multiplier',
      defaultValue: 1.0,
      options: [
        { id: 'basic', label: 'Basic (0.75x)', value: 0.75 },
        { id: 'standard', label: 'Standard (0.90x)', value: 0.9 },
        { id: 'good', label: 'Good (1.00x)', value: 1.0 },
      ],
    },
    {
      id: 'param-condition',
      label: 'Condition',
      description: 'Maintenance state and physical wear & tear',
      inputType: 'dropdown',
      effectType: 'building_multiplier',
      defaultValue: 1.0,
      options: [
        { id: 'poor', label: 'Poor (0.70x)', value: 0.7 },
        { id: 'fair', label: 'Fair (0.85x)', value: 0.85 },
        { id: 'good', label: 'Good (1.00x)', value: 1.0 },
      ],
    },
    {
      id: 'param-external-works',
      label: 'External works',
      description: 'Paving, perimeter boundary walls, gates, and driveways (+20% of building value)',
      inputType: 'toggle',
      effectType: 'building_percentage',
      defaultValue: 0.2,
      valueWhenOn: 0.2,
      valueWhenOff: 0.0,
      labelOn: 'Yes (20%)',
      labelOff: 'None (0%)',
    },
    {
      id: 'param-ensuite',
      label: 'En-suite bedroom present',
      description: 'Master bedroom with dedicated bathroom suite (+2% on total market value)',
      inputType: 'toggle',
      effectType: 'total_percentage',
      defaultValue: 0.0,
      valueWhenOn: 0.02,
      valueWhenOff: 0.0,
      labelOn: 'Present (+2%)',
      labelOff: 'Standard (0%)',
    },
    {
      id: 'param-title-type',
      label: 'Non-freehold title',
      description: 'Cession or leasehold tenure discount (-15% on total market value)',
      inputType: 'toggle',
      effectType: 'total_percentage',
      defaultValue: 0.0,
      valueWhenOn: -0.15,
      valueWhenOff: 0.0,
      labelOn: 'Non-Freehold (-15%)',
      labelOff: 'Freehold Title (0%)',
    },
  ],
  comparables: [
    {
      id: 'comp-1',
      description: '3-bed house, Castle Base, good finish',
      price: 98000,
      date: '2026-06-15',
      buildingArea: 195,
      landArea: 1900,
      sourceNote: 'Deeds Office registered transfer',
    },
    {
      id: 'comp-2',
      description: '4-bed home with cottage, Jacaranda',
      price: 115000,
      date: '2026-07-20',
      buildingArea: 220,
      landArea: 2100,
      sourceNote: 'Estate agent recorded sale',
    },
    {
      id: 'comp-3',
      description: 'Standard 3-bed home, Castle Base',
      price: 92000,
      date: '2026-08-05',
      buildingArea: 180,
      landArea: 1850,
      sourceNote: 'Recent private sale',
    },
  ],
};

/**
 * UNIT TEST / VERIFICATION FOR SAMPLE PRESET
 * Validates the exact sample test case specified in the brief:
 * Land: 1,887 sqm
 * Buildings: 126.97 sqm (house) and 62.17 sqm (garage/store)
 * Parameters: Castle Base (1.00), Good finish (1.00), Good condition (1.00), External works on (20%)
 * Expected output:
 * - Land: ~US$47,000
 * - Market: ~US$96,000
 * - Forced Sale: ~US$72,000
 * - Gross Replacement Cost: ~US$155,000
 */
export function verifySamplePreset(): {
  success: boolean;
  actual: {
    land: number;
    market: number;
    forcedSale: number;
    replacement: number;
  };
  expected: {
    land: number;
    market: number;
    forcedSale: number;
    replacement: number;
  };
  details: string;
} {
  const sampleInputs: EstimateInputs = {
    profileId: SAMPLE_RUSAPE_PRESET.id,
    propertyTypeId: 'pt-residential',
    landArea: 1887,
    buildings: [
      { id: 'b1', name: 'Main House', area: 126.97 },
      { id: 'b2', name: 'Garage/Store', area: 62.17 },
    ],
    parameterValues: {
      'param-location-zone': 1.0, // Castle Base
      'param-finish-quality': 1.0, // Good
      'param-condition': 1.0, // Good
      'param-external-works': 0.2, // On (20%)
      'param-ensuite': 0.0, // Off
      'param-title-type': 0.0, // Freehold (Off)
    },
  };

  const result = calculateValuation(sampleInputs, SAMPLE_RUSAPE_PRESET);

  const expected = {
    land: 47000,
    market: 96000,
    forcedSale: 72000,
    replacement: 155000,
  };

  const actual = {
    land: result.landValue,
    market: result.marketValue,
    forcedSale: result.forcedSaleValue,
    replacement: result.replacementCost,
  };

  const success =
    actual.land === expected.land &&
    actual.market === expected.market &&
    actual.forcedSale === expected.forcedSale &&
    actual.replacement === expected.replacement;

  const details = `Land: US$${actual.land.toLocaleString()} (Expected US$${expected.land.toLocaleString()}) | Market: US$${actual.market.toLocaleString()} (Expected US$${expected.market.toLocaleString()}) | Forced Sale: US$${actual.forcedSale.toLocaleString()} (Expected US$${expected.forcedSale.toLocaleString()}) | Replacement: US$${actual.replacement.toLocaleString()} (Expected US$${expected.replacement.toLocaleString()})`;

  return { success, actual, expected, details };
}

/**
 * Creates a clean, empty profile template for the user.
 */
export function createEmptyProfile(name: string = 'New Market Profile'): MarketProfile {
  return {
    id: `profile-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    name,
    description: 'Custom valuation profile with user-configured rates and factors.',
    currency: 'US$',
    areaUnit: 'sqm',
    baseRates: {
      landRate: 50,
      buildingRate: 500,
      replacementRate: 900,
    },
    outputSettings: {
      forcedSalePercent: 75,
      rangeWidthPercent: 10,
      roundingStep: 500,
    },
    propertyTypes: [
      { id: 'pt-residential', name: 'Residential', requiresLandArea: true },
      { id: 'pt-commercial', name: 'Commercial', requiresLandArea: true },
      { id: 'pt-vacant', name: 'Vacant land', requiresLandArea: true },
      { id: 'pt-sectional', name: 'Sectional title / Apartment', requiresLandArea: false },
    ],
    parameters: [
      {
        id: 'param-loc',
        label: 'Location grade',
        description: 'Zone multiplier on land',
        inputType: 'dropdown',
        effectType: 'land_multiplier',
        defaultValue: 1.0,
        options: [
          { id: 'prime', label: 'Prime (1.20x)', value: 1.2 },
          { id: 'standard', label: 'Standard (1.00x)', value: 1.0 },
          { id: 'secondary', label: 'Secondary (0.85x)', value: 0.85 },
        ],
      },
      {
        id: 'param-cond',
        label: 'Building condition',
        description: 'Physical state of structures',
        inputType: 'dropdown',
        effectType: 'building_multiplier',
        defaultValue: 1.0,
        options: [
          { id: 'excellent', label: 'Excellent (1.10x)', value: 1.1 },
          { id: 'good', label: 'Good (1.00x)', value: 1.0 },
          { id: 'fair', label: 'Fair (0.85x)', value: 0.85 },
          { id: 'poor', label: 'Poor (0.70x)', value: 0.7 },
        ],
      },
      {
        id: 'param-ext',
        label: 'External improvements',
        description: 'Paving, security walls, gates (% of building value)',
        inputType: 'slider',
        effectType: 'building_percentage',
        defaultValue: 0.15,
        min: 0,
        max: 0.5,
        step: 0.05,
        unitSuffix: '%',
      },
    ],
    comparables: [],
  };
}
