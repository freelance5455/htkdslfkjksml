import React from 'react';
import { Calculator, Bookmark, Layers, Settings } from 'lucide-react';

export type TabId = 'estimate' | 'saved' | 'profiles' | 'settings';

interface TabBarProps {
  activeTab: TabId;
  onSelectTab: (tab: TabId) => void;
  savedCount: number;
  profilesCount: number;
}

export const TabBar: React.FC<TabBarProps> = ({
  activeTab,
  onSelectTab,
  savedCount,
  profilesCount,
}) => {
  const tabs = [
    {
      id: 'estimate' as TabId,
      label: 'Estimate',
      icon: Calculator,
      badge: null,
    },
    {
      id: 'saved' as TabId,
      label: 'Saved',
      icon: Bookmark,
      badge: savedCount > 0 ? savedCount : null,
    },
    {
      id: 'profiles' as TabId,
      label: 'Profiles',
      icon: Layers,
      badge: profilesCount > 0 ? profilesCount : null,
    },
    {
      id: 'settings' as TabId,
      label: 'Settings',
      icon: Settings,
      badge: null,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200/90 shadow-lg">
      <div className="max-w-2xl mx-auto flex items-center justify-around h-16 px-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex-1 py-1 flex flex-col items-center justify-center relative transition-colors ${
                isActive
                  ? 'text-emerald-700 font-bold'
                  : 'text-neutral-500 hover:text-neutral-900 font-medium'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                {tab.badge !== null && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-4 h-4 px-1 rounded-full bg-emerald-600 text-white text-[10px] font-mono font-bold flex items-center justify-center">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] mt-1 tracking-tight">{tab.label}</span>
              {isActive && (
                <span className="absolute bottom-0 w-8 h-0.5 bg-emerald-600 rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
