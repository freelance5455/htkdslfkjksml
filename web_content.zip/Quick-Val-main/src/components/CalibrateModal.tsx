import React, { useState } from 'react';
import {
  SlidersHorizontal,
  X,
  Check,
  Plus,
  Trash2,
  ArrowRight,
  Sparkles,
  Info,
} from 'lucide-react';
import { CalibrationResult, CalibrationTarget, MarketProfile } from '../types';
import { calibrateProfileRates, formatCurrency } from '../engine';

interface CalibrateModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: MarketProfile;
  onApplyCalibration: (newRates: {
    landRate: number;
    buildingRate: number;
    replacementRate: number;
    forcedSalePercent: number;
  }) => void;
}

export const CalibrateModal: React.FC<CalibrateModalProps> = ({
  isOpen,
  onClose,
  profile,
  onApplyCalibration,
}) => {
  const [targets, setTargets] = useState<CalibrationTarget[]>([
    {
      id: 'target-1',
      title: 'Known Valuation Property 1',
      inputs: {
        profileId: profile.id,
        propertyTypeId: profile.propertyTypes[0]?.id || 'pt-residential',
        landArea: 1887,
        buildings: [{ id: 'b1', name: 'Main House', area: 189 }],
        parameterValues: {},
      },
      knownMarketValue: 96000,
      knownLandValue: 47000,
      knownForcedSaleValue: 72000,
      knownReplacementCost: 155000,
    },
  ]);

  const [activeTab, setActiveTab] = useState<'targets' | 'preview'>('targets');

  if (!isOpen) return null;

  const handleAddTarget = () => {
    setTargets([
      ...targets,
      {
        id: `target-${Date.now()}`,
        title: `Known Valuation Property ${targets.length + 1}`,
        inputs: {
          profileId: profile.id,
          propertyTypeId: profile.propertyTypes[0]?.id || 'pt-residential',
          landArea: 1500,
          buildings: [{ id: `b-${Date.now()}`, name: 'Main Building', area: 150 }],
          parameterValues: {},
        },
        knownMarketValue: 100000,
      },
    ]);
  };

  const handleRemoveTarget = (id: string) => {
    if (targets.length <= 1) return;
    setTargets(targets.filter((t) => t.id !== id));
  };

  const updateTarget = (index: number, updates: Partial<CalibrationTarget>) => {
    const updated = [...targets];
    updated[index] = { ...updated[index], ...updates };
    setTargets(updated);
  };

  const calibrationResult: CalibrationResult = calibrateProfileRates(targets, profile);

  const hasLandRateChanged =
    calibrationResult.suggestedLandRate !== profile.baseRates.landRate;
  const hasBuildingRateChanged =
    calibrationResult.suggestedBuildingRate !== profile.baseRates.buildingRate;
  const hasReplacementRateChanged =
    calibrationResult.suggestedReplacementRate !== profile.baseRates.replacementRate;
  const hasForcedSaleChanged =
    calibrationResult.suggestedForcedSalePercent !== profile.outputSettings.forcedSalePercent;

  const handleApply = () => {
    onApplyCalibration({
      landRate: calibrationResult.suggestedLandRate,
      buildingRate: calibrationResult.suggestedBuildingRate,
      replacementRate: calibrationResult.suggestedReplacementRate,
      forcedSalePercent: calibrationResult.suggestedForcedSalePercent,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/80">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <SlidersHorizontal className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-neutral-900 text-sm sm:text-base">
                Calibrate Profile to Known Valuations
              </h3>
              <p className="text-xs text-neutral-500">
                Reverse-engineer base rates from verified appraisal reports
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4">
          <div className="bg-emerald-50/80 p-3 rounded-xl border border-emerald-200/80 text-xs text-emerald-950 flex items-start gap-2">
            <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>
              Enter property specs and professional valuer numbers. QuickVal mathematically isolates the
              land rate from the land portion, then solves the building base rate from the remainder.
            </span>
          </div>

          {/* Targets List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-neutral-800">
                Known Valuations ({targets.length})
              </span>
              <button
                type="button"
                onClick={handleAddTarget}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Another Property</span>
              </button>
            </div>

            {targets.map((target, idx) => (
              <div
                key={target.id}
                className="p-3.5 rounded-xl border border-neutral-200 bg-neutral-50/60 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <input
                    type="text"
                    value={target.title}
                    onChange={(e) => updateTarget(idx, { title: e.target.value })}
                    className="font-semibold text-xs text-neutral-800 bg-transparent border-b border-dashed border-neutral-300 focus:outline-none focus:border-emerald-600"
                  />
                  {targets.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveTarget(target.id)}
                      className="text-neutral-400 hover:text-red-600 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="text-[11px] text-neutral-500 block mb-0.5">
                      Land Area ({profile.areaUnit})
                    </label>
                    <input
                      type="number"
                      value={target.inputs.landArea || ''}
                      onChange={(e) =>
                        updateTarget(idx, {
                          inputs: {
                            ...target.inputs,
                            landArea: Math.max(0, parseFloat(e.target.value) || 0),
                          },
                        })
                      }
                      className="w-full p-2 bg-white rounded-lg border border-neutral-200 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-neutral-500 block mb-0.5">
                      Total Building Area ({profile.areaUnit})
                    </label>
                    <input
                      type="number"
                      value={target.inputs.buildings[0]?.area || ''}
                      onChange={(e) =>
                        updateTarget(idx, {
                          inputs: {
                            ...target.inputs,
                            buildings: [
                              {
                                id: 'b1',
                                name: 'Building',
                                area: Math.max(0, parseFloat(e.target.value) || 0),
                              },
                            ],
                          },
                        })
                      }
                      className="w-full p-2 bg-white rounded-lg border border-neutral-200 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-emerald-800 font-medium block mb-0.5">
                      * Known Market Value ({profile.currency})
                    </label>
                    <input
                      type="number"
                      value={target.knownMarketValue || ''}
                      onChange={(e) =>
                        updateTarget(idx, {
                          knownMarketValue: Math.max(0, parseFloat(e.target.value) || 0),
                        })
                      }
                      className="w-full p-2 bg-white rounded-lg border border-emerald-300 text-xs font-bold font-mono text-emerald-900"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-neutral-500 block mb-0.5">
                      Known Land Value (optional)
                    </label>
                    <input
                      type="number"
                      value={target.knownLandValue || ''}
                      placeholder="e.g. 47000"
                      onChange={(e) =>
                        updateTarget(idx, {
                          knownLandValue: parseFloat(e.target.value) || undefined,
                        })
                      }
                      className="w-full p-2 bg-white rounded-lg border border-neutral-200 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-neutral-500 block mb-0.5">
                      Forced Sale Value (optional)
                    </label>
                    <input
                      type="number"
                      value={target.knownForcedSaleValue || ''}
                      placeholder="e.g. 72000"
                      onChange={(e) =>
                        updateTarget(idx, {
                          knownForcedSaleValue: parseFloat(e.target.value) || undefined,
                        })
                      }
                      className="w-full p-2 bg-white rounded-lg border border-neutral-200 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-neutral-500 block mb-0.5">
                      Replacement Cost (optional)
                    </label>
                    <input
                      type="number"
                      value={target.knownReplacementCost || ''}
                      placeholder="e.g. 155000"
                      onChange={(e) =>
                        updateTarget(idx, {
                          knownReplacementCost: parseFloat(e.target.value) || undefined,
                        })
                      }
                      className="w-full p-2 bg-white rounded-lg border border-neutral-200 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Suggested Rate Comparison */}
          <div className="border border-neutral-200 rounded-xl p-3.5 bg-neutral-50 space-y-2.5">
            <div className="flex items-center justify-between text-xs font-semibold text-neutral-800">
              <span>Suggested Profile Adjustments</span>
              <span className="text-[11px] font-normal text-neutral-500">
                Averaged across {calibrationResult.sampleCount} property sample(s)
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 bg-white rounded-lg border border-neutral-200">
                <span className="text-[11px] text-neutral-500 block">Base Land Rate</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-neutral-400 line-through">
                    {profile.baseRates.landRate}
                  </span>
                  <ArrowRight className="w-3 h-3 text-neutral-400" />
                  <span className={`font-bold font-mono ${hasLandRateChanged ? 'text-emerald-700' : 'text-neutral-700'}`}>
                    {calibrationResult.suggestedLandRate} {profile.currency}/{profile.areaUnit}
                  </span>
                </div>
              </div>

              <div className="p-2.5 bg-white rounded-lg border border-neutral-200">
                <span className="text-[11px] text-neutral-500 block">Base Building Rate</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-neutral-400 line-through">
                    {profile.baseRates.buildingRate}
                  </span>
                  <ArrowRight className="w-3 h-3 text-neutral-400" />
                  <span className={`font-bold font-mono ${hasBuildingRateChanged ? 'text-emerald-700' : 'text-neutral-700'}`}>
                    {calibrationResult.suggestedBuildingRate} {profile.currency}/{profile.areaUnit}
                  </span>
                </div>
              </div>

              <div className="p-2.5 bg-white rounded-lg border border-neutral-200">
                <span className="text-[11px] text-neutral-500 block">Replacement Rate</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-neutral-400 line-through">
                    {profile.baseRates.replacementRate}
                  </span>
                  <ArrowRight className="w-3 h-3 text-neutral-400" />
                  <span className={`font-bold font-mono ${hasReplacementRateChanged ? 'text-emerald-700' : 'text-neutral-700'}`}>
                    {calibrationResult.suggestedReplacementRate} {profile.currency}/{profile.areaUnit}
                  </span>
                </div>
              </div>

              <div className="p-2.5 bg-white rounded-lg border border-neutral-200">
                <span className="text-[11px] text-neutral-500 block">Forced Sale %</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-neutral-400 line-through">
                    {profile.outputSettings.forcedSalePercent}%
                  </span>
                  <ArrowRight className="w-3 h-3 text-neutral-400" />
                  <span className={`font-bold font-mono ${hasForcedSaleChanged ? 'text-emerald-700' : 'text-neutral-700'}`}>
                    {calibrationResult.suggestedForcedSalePercent}%
                  </span>
                </div>
              </div>
            </div>

            <p className="text-[11px] text-neutral-500 italic">
              {calibrationResult.explanation}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 bg-neutral-50 flex items-center justify-end gap-2.5">
          <button
            onClick={onClose}
            type="button"
            className="px-4 py-2 text-xs font-medium text-neutral-600 hover:text-neutral-900 rounded-lg hover:bg-neutral-200/60 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleApply}
            type="button"
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Check className="w-4 h-4" />
            <span>Apply Rates to Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
};
