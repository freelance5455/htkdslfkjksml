import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Calculator, Info, CheckCircle2 } from 'lucide-react';
import { CalculationResult, MarketProfile } from '../types';
import { formatCurrency } from '../engine';

interface ResultsBreakdownProps {
  result: CalculationResult;
  profile: MarketProfile;
}

export const ResultsBreakdown: React.FC<ResultsBreakdownProps> = ({
  result,
  profile,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-white rounded-xl border border-neutral-200/90 shadow-xs overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full px-4 py-3.5 flex items-center justify-between bg-neutral-50 hover:bg-neutral-100/80 transition-colors text-left"
        type="button"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
            <Calculator className="w-4 h-4" />
          </div>
          <div>
            <div className="text-sm font-semibold text-neutral-800 flex items-center gap-1.5">
              <span>How We Got This</span>
              <span className="text-[11px] font-normal px-1.5 py-0.5 rounded-sm bg-neutral-200/70 text-neutral-600">
                {result.steps.length} Steps
              </span>
            </div>
            <p className="text-xs text-neutral-500">
              Line-by-line transparent mathematical calculation log
            </p>
          </div>
        </div>
        <div className="text-neutral-400 p-1">
          {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </div>
      </button>

      {isExpanded && (
        <div className="p-4 space-y-4 border-t border-neutral-200 bg-white">
          <div className="text-xs text-neutral-500 bg-emerald-50/70 text-emerald-950 p-2.5 rounded-lg border border-emerald-200/70 flex items-start gap-2">
            <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>
              All valuation formulas in QuickVal are 100% deterministic and driven by your profile settings.
              Adjustments apply strictly in sequence.
            </span>
          </div>

          <div className="divide-y divide-neutral-100">
            {result.steps.map((step, idx) => (
              <div key={step.key} className="py-3 first:pt-0 last:pb-0 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-neutral-800 flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-full bg-neutral-200 text-neutral-700 text-[10px] flex items-center justify-center font-mono">
                      {idx + 1}
                    </span>
                    {step.title.replace(/^\d+\.\s*/, '')}
                  </span>
                  <span className="font-mono font-bold text-neutral-900 bg-neutral-100 px-2 py-0.5 rounded text-[11px]">
                    {step.formattedValue}
                  </span>
                </div>

                <div className="text-[11px] text-neutral-500 font-mono bg-neutral-50 px-2.5 py-1.5 rounded border border-neutral-200/60 overflow-x-auto">
                  <div className="text-neutral-400 text-[10px] font-sans font-medium uppercase tracking-wider mb-0.5">
                    Formula: {step.formula}
                  </div>
                  <div className="text-neutral-700 whitespace-nowrap">{step.math}</div>
                </div>

                {step.notes && (
                  <p className="text-[11px] text-neutral-500 pl-6 leading-relaxed italic">
                    {step.notes}
                  </p>
                )}
              </div>
            ))}
          </div>

          {result.parameterBreakdowns && result.parameterBreakdowns.length > 0 && (
            <div className="pt-3 border-t border-neutral-100">
              <h4 className="text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-2">
                Active Parameter Adjustments
              </h4>
              <div className="space-y-1.5">
                {result.parameterBreakdowns.map((p) => (
                  <div
                    key={p.parameterId}
                    className="flex items-center justify-between text-xs p-2 rounded-lg bg-neutral-50 border border-neutral-200/60"
                  >
                    <div>
                      <div className="font-medium text-neutral-800">{p.label}</div>
                      <div className="text-[10px] text-neutral-500">{p.description}</div>
                    </div>
                    <div className="text-right font-mono">
                      <span className="inline-block px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 font-semibold text-[11px]">
                        {p.displayValue}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="pt-2 flex items-center justify-between text-[11px] text-neutral-400">
            <span>Profile: {profile.name}</span>
            <span>Rounding Step: {formatCurrency(profile.outputSettings.roundingStep, profile.currency)}</span>
          </div>
        </div>
      )}
    </div>
  );
};
