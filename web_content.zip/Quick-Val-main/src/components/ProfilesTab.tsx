import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Copy,
  Trash2,
  Edit3,
  FileDown,
  FileUp,
  RotateCcw,
  Check,
  CheckCircle2,
  Sparkles,
  SlidersHorizontal,
  BookmarkCheck,
} from 'lucide-react';
import { MarketProfile } from '../types';
import { SAMPLE_RUSAPE_PRESET, createEmptyProfile, formatCurrency } from '../engine';
import { ProfileEditorModal } from './ProfileEditorModal';

interface ProfilesTabProps {
  profiles: MarketProfile[];
  activeProfileId: string;
  onSelectActiveProfile: (id: string) => void;
  onUpdateProfiles: (profiles: MarketProfile[]) => void;
}

export const ProfilesTab: React.FC<ProfilesTabProps> = ({
  profiles,
  activeProfileId,
  onSelectActiveProfile,
  onUpdateProfiles,
}) => {
  const [editingProfile, setEditingProfile] = useState<MarketProfile | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  const handleCreateProfile = () => {
    const newP = createEmptyProfile(`Market Profile ${profiles.length + 1}`);
    const updated = [...profiles, newP];
    onUpdateProfiles(updated);
    setEditingProfile(newP);
    showToast('New profile created');
  };

  const handleDuplicateProfile = (profile: MarketProfile) => {
    const duplicated: MarketProfile = {
      ...JSON.parse(JSON.stringify(profile)),
      id: `profile-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      name: `${profile.name} (Copy)`,
      isPreset: false,
    };
    onUpdateProfiles([...profiles, duplicated]);
    showToast(`Duplicated ${profile.name}`);
  };

  const handleDeleteProfile = (id: string) => {
    if (profiles.length <= 1) {
      showToast('Cannot delete the only market profile.');
      return;
    }
    const updated = profiles.filter((p) => p.id !== id);
    onUpdateProfiles(updated);
    if (activeProfileId === id) {
      onSelectActiveProfile(updated[0].id);
    }
    showToast('Profile deleted');
  };

  const handleLoadSamplePreset = () => {
    const existingIndex = profiles.findIndex((p) => p.id === SAMPLE_RUSAPE_PRESET.id);
    if (existingIndex >= 0) {
      const updated = [...profiles];
      updated[existingIndex] = JSON.parse(JSON.stringify(SAMPLE_RUSAPE_PRESET));
      onUpdateProfiles(updated);
      onSelectActiveProfile(SAMPLE_RUSAPE_PRESET.id);
      showToast('Reloaded Rusape preset to defaults');
    } else {
      const updated = [SAMPLE_RUSAPE_PRESET, ...profiles];
      onUpdateProfiles(updated);
      onSelectActiveProfile(SAMPLE_RUSAPE_PRESET.id);
      showToast('Added Sample: Rusape, Zimbabwe preset');
    }
  };

  const handleExportProfileJson = (profile: MarketProfile) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(profile, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${profile.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_profile.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast(`Exported ${profile.name}`);
  };

  const handleImportProfileJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (!parsed.name || !parsed.baseRates) {
          throw new Error('Invalid profile schema');
        }
        const importedProfile: MarketProfile = {
          ...parsed,
          id: `profile-${Date.now()}`,
          name: `${parsed.name} (Imported)`,
        };
        onUpdateProfiles([...profiles, importedProfile]);
        onSelectActiveProfile(importedProfile.id);
        showToast(`Imported ${importedProfile.name}`);
      } catch (err: any) {
        showToast('Failed to import profile: invalid format');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-4 pb-20 max-w-2xl mx-auto px-3 sm:px-4 pt-3">
      {/* Header card */}
      <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-neutral-900">Market Profiles</h2>
            <p className="text-xs text-neutral-500">
              Saved assumption sets for distinct towns, zones, and property segments
            </p>
          </div>

          <div className="flex items-center gap-1.5">
            <label className="p-2 text-neutral-600 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer" title="Import Profile JSON">
              <FileUp className="w-4 h-4" />
              <input type="file" accept=".json" onChange={handleImportProfileJson} className="hidden" />
            </label>

            <button
              onClick={handleCreateProfile}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-xs transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Profile</span>
            </button>
          </div>
        </div>

        {/* Preset reload banner */}
        <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center justify-between text-xs">
          <div>
            <span className="font-semibold text-neutral-800 block">Sample Preset Available</span>
            <span className="text-[11px] text-neutral-500">
              Rusape, Zimbabwe (US$) verified benchmark
            </span>
          </div>
          <button
            type="button"
            onClick={handleLoadSamplePreset}
            className="px-3 py-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 text-neutral-800 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5 text-emerald-700" />
            <span>Load / Reset Sample</span>
          </button>
        </div>
      </div>

      {/* Profile list */}
      <div className="space-y-3">
        {profiles.map((profile) => {
          const isActive = profile.id === activeProfileId;

          return (
            <div
              key={profile.id}
              className={`bg-white rounded-2xl border p-4 shadow-xs transition-all space-y-3 ${
                isActive
                  ? 'border-emerald-600 ring-2 ring-emerald-500/20'
                  : 'border-neutral-200/90'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-neutral-900 text-sm">
                      {profile.name}
                    </h3>
                    {isActive && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        Active Profile
                      </span>
                    )}
                    {profile.isPreset && (
                      <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded-full bg-neutral-100 text-neutral-600">
                        Preset
                      </span>
                    )}
                  </div>

                  {profile.description && (
                    <p className="text-xs text-neutral-500 line-clamp-1">
                      {profile.description}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-neutral-600 pt-1 font-mono">
                    <span>
                      Currency: <strong>{profile.currency}</strong>
                    </span>
                    <span>•</span>
                    <span>
                      Unit: <strong>{profile.areaUnit}</strong>
                    </span>
                    <span>•</span>
                    <span>
                      Land: <strong>{formatCurrency(profile.baseRates.landRate, profile.currency)}/{profile.areaUnit}</strong>
                    </span>
                    <span>•</span>
                    <span>
                      Building: <strong>{formatCurrency(profile.baseRates.buildingRate, profile.currency)}/{profile.areaUnit}</strong>
                    </span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-semibold px-2 py-1 rounded-lg bg-neutral-100 text-neutral-700 font-mono block">
                    {profile.parameters.length} params
                  </span>
                  <span className="text-[10px] text-neutral-400 mt-1 block">
                    {(profile.comparables || []).length} comps
                  </span>
                </div>
              </div>

              {/* Actions row */}
              <div className="flex items-center justify-between pt-2 border-t border-neutral-100 text-xs">
                {!isActive ? (
                  <button
                    onClick={() => {
                      onSelectActiveProfile(profile.id);
                      showToast(`Set ${profile.name} as active`);
                    }}
                    className="text-xs font-semibold text-emerald-700 hover:text-emerald-800"
                  >
                    Select as Active
                  </button>
                ) : (
                  <span className="text-[11px] font-semibold text-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>In Use</span>
                  </span>
                )}

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setEditingProfile(profile)}
                    className="px-2.5 py-1.5 rounded-lg bg-neutral-100 hover:bg-neutral-200/80 text-neutral-800 font-semibold text-xs flex items-center gap-1 transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-neutral-600" />
                    <span>Edit</span>
                  </button>

                  <button
                    onClick={() => handleDuplicateProfile(profile)}
                    className="p-1.5 rounded-lg text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100 transition-colors"
                    title="Duplicate Profile"
                  >
                    <Copy className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleExportProfileJson(profile)}
                    className="p-1.5 rounded-lg text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100 transition-colors"
                    title="Export JSON"
                  >
                    <FileDown className="w-4 h-4" />
                  </button>

                  {profiles.length > 1 && (
                    <button
                      onClick={() => handleDeleteProfile(profile.id)}
                      className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                      title="Delete Profile"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Toast */}
      {toast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 text-white text-xs px-4 py-2 rounded-full shadow-lg font-medium animate-fade-in flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toast}</span>
        </div>
      )}

      {/* Profile Editor Modal */}
      {editingProfile && (
        <ProfileEditorModal
          isOpen={Boolean(editingProfile)}
          onClose={() => setEditingProfile(null)}
          profile={editingProfile}
          onSave={(updatedProfile) => {
            const updatedList = profiles.map((p) =>
              p.id === updatedProfile.id ? updatedProfile : p
            );
            onUpdateProfiles(updatedList);
            showToast(`Saved changes to ${updatedProfile.name}`);
          }}
        />
      )}
    </div>
  );
};
