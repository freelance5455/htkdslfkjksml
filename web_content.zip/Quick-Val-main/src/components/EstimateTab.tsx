import React, { useState } from 'react';
import {
  Building,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  CalculationResult,
  ComparableCrossCheckResult,
  EstimateInputs,
  MarketProfile,
} from '../types';
import {
  calculateValuation,
  calculateComparableCrossCheck,
  formatCurrency,
  formatArea,
  getApplicableParameters,
} from '../engine';
import { MANDATORY_DISCLAIMER } from '../storage';
import { ValuationChart } from './ValuationChart';
import { ResultsBreakdown } from './ResultsBreakdown';

interface EstimateTabProps {
  profile: MarketProfile;
  inputs: EstimateInputs;
  onUpdateInputs: (updated: EstimateInputs) => void;
  onResetEstimate: () => void;
  overpricedThresholdPercent: number;
}

export const EstimateTab: React.FC<EstimateTabProps> = ({
  profile,
  inputs,
  onUpdateInputs,
  onResetEstimate,
  overpricedThresholdPercent,
}) => {
  const [expandedBuildingRates, setExpandedBuildingRates] = useState<Record<string, boolean>>({});

  // Calculation
  const result: CalculationResult = calculateValuation(inputs, profile, {
    overpricedThresholdPercent,
  });

  // Comparables check
  const comparablesCheck: ComparableCrossCheckResult = calculateComparableCrossCheck(
    profile.comparables || [],
    inputs,
    result.marketValue,
    profile
  );

  const currentPropertyType =
    profile.propertyTypes.find((pt) => pt.id === inputs.propertyTypeId) ||
    profile.propertyTypes[0];

  const requiresLand = currentPropertyType ? currentPropertyType.requiresLandArea : true;
  const activeParams = getApplicableParameters(profile.parameters, inputs.propertyTypeId);

  // Handlers for structures
  const handleAddStructure = (defaultName = 'Outbuilding') => {
    const newStructure = {
      id: `bld-${Date.now()}`,
      name: defaultName,
      area: 50,
    };
    onUpdateInputs({
      ...inputs,
      buildings: [...inputs.buildings, newStructure],
    });
  };

  const handleUpdateStructure = (
    id: string,
    updates: Partial<{ name: string; area: number; rateOverride?: number }>
  ) => {
    onUpdateInputs({
      ...inputs,
      buildings: inputs.buildings.map((b) =>
        b.id === id ? { ...b, ...updates } : b
      ),
    });
  };

  const handleRemoveStructure = (id: string) => {
    if (inputs.buildings.length <= 1) return;
    onUpdateInputs({
      ...inputs,
      buildings: inputs.buildings.filter((b) => b.id !== id),
    });
  };

  // Handlers for dynamic parameters
  const handleParameterChange = (paramId: string, value: number) => {
    onUpdateInputs({
      ...inputs,
      parameterValues: {
        ...inputs.parameterValues,
        [paramId]: value,
      },
    });
  };

  const totalBuildingArea = (inputs.buildings || []).reduce(
    (sum, b) => sum + (b.area || 0),
    0
  );

  return (
    <div className="space-y-4 pb-20 max-w-2xl mx-auto px-3 sm:px-4 pt-3">
      {/* Property Title & Type Selection */}
      <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-3">
        <div>
          <label className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wider block mb-1">
            Property Designation / Address
          </label>
          <input
            type="text"
            value={inputs.propertyTitle || ''}
            onChange={(e) =>
              onUpdateInputs({ ...inputs, propertyTitle: e.target.value })
            }
            placeholder="e.g. 14 Jacaranda Crescent, Rusape"
            className="w-full text-sm font-semibold text-neutral-900 placeholder:text-neutral-400 p-2.5 bg-neutral-50/70 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
          />
        </div>

        {/* Property Type Segmented Selector */}
        <div>
          <label className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wider block mb-1.5">
            Property Type
          </label>
          <div className="flex flex-wrap gap-1.5">
            {profile.propertyTypes.map((pt) => {
              const isSelected = pt.id === inputs.propertyTypeId;
              return (
                <button
                  key={pt.id}
                  type="button"
                  onClick={() => onUpdateInputs({ ...inputs, propertyTypeId: pt.id })}
                  className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all ${
                    isSelected
                      ? 'bg-emerald-700 text-white shadow-xs font-semibold'
                      : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200/70'
                  }`}
                >
                  {pt.name}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Primary Physical Specs: Land & Buildings */}
      <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-4">
        {/* Land Area Input */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1">
              <span>Land / Stand Area</span>
              {!requiresLand && (
                <span className="text-[10px] text-neutral-400 font-normal">
                  (Sectional Title / Optional)
                </span>
              )}
            </label>
            <span className="text-xs font-mono text-neutral-500">
              Base: {formatCurrency(profile.baseRates.landRate, profile.currency)}/{profile.areaUnit}
            </span>
          </div>

          <div className="relative">
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.landArea || ''}
              onChange={(e) =>
                onUpdateInputs({
                  ...inputs,
                  landArea: Math.max(0, parseFloat(e.target.value) || 0),
                })
              }
              placeholder="e.g. 1887"
              className="w-full text-base font-bold font-mono text-neutral-900 p-2.5 pl-3 pr-14 bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <span className="absolute right-3 top-3 text-xs font-semibold text-neutral-400 font-mono">
              {profile.areaUnit}
            </span>
          </div>
        </div>

        {/* Repeatable Buildings / Structures List */}
        <div className="space-y-2 pt-2 border-t border-neutral-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Building className="w-4 h-4 text-emerald-700" />
              <label className="text-xs font-semibold text-neutral-800">
                Structures & Buildings
              </label>
            </div>
            <span className="text-[11px] font-mono text-emerald-800 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              Total: {formatArea(totalBuildingArea, profile.areaUnit)}
            </span>
          </div>

          <div className="space-y-2.5">
            {inputs.buildings.map((structure, idx) => {
              const hasOverride = structure.rateOverride !== undefined && structure.rateOverride !== null;
              const isOverrideOpen = expandedBuildingRates[structure.id];

              return (
                <div
                  key={structure.id}
                  className="p-3 bg-neutral-50/80 rounded-xl border border-neutral-200/90 space-y-2"
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={structure.name}
                      onChange={(e) =>
                        handleUpdateStructure(structure.id, { name: e.target.value })
                      }
                      placeholder="Structure name"
                      className="flex-1 text-xs font-semibold text-neutral-800 p-2 bg-white rounded-lg border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />

                    <div className="relative w-32 shrink-0">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={structure.area || ''}
                        onChange={(e) =>
                          handleUpdateStructure(structure.id, {
                            area: Math.max(0, parseFloat(e.target.value) || 0),
                          })
                        }
                        placeholder="Area"
                        className="w-full text-xs font-mono font-bold text-neutral-900 p-2 pr-10 bg-white rounded-lg border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      />
                      <span className="absolute right-2 top-2 text-[10px] text-neutral-400 font-mono">
                        {profile.areaUnit}
                      </span>
                    </div>

                    {inputs.buildings.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveStructure(structure.id)}
                        className="p-2 text-neutral-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                        title="Remove structure"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {/* Rate override accordion toggle */}
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-neutral-200/60">
                    <button
                      type="button"
                      onClick={() =>
                        setExpandedBuildingRates((prev) => ({
                          ...prev,
                          [structure.id]: !prev[structure.id],
                        }))
                      }
                      className="text-neutral-500 hover:text-neutral-800 flex items-center gap-1 font-medium"
                    >
                      <span>
                        Rate:{' '}
                        {hasOverride
                          ? `${formatCurrency(structure.rateOverride!, profile.currency)}/${profile.areaUnit} (Custom)`
                          : `${formatCurrency(profile.baseRates.buildingRate, profile.currency)}/${profile.areaUnit} (Default)`}
                      </span>
                      {isOverrideOpen ? (
                        <ChevronUp className="w-3 h-3" />
                      ) : (
                        <ChevronDown className="w-3 h-3" />
                      )}
                    </button>
                  </div>

                  {isOverrideOpen && (
                    <div className="p-2 bg-white rounded-lg border border-neutral-200 flex items-center justify-between gap-2 text-xs">
                      <span className="text-[11px] text-neutral-500">
                        Custom Rate Override ({profile.currency}/{profile.areaUnit}):
                      </span>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          placeholder={String(profile.baseRates.buildingRate)}
                          value={structure.rateOverride ?? ''}
                          onChange={(e) =>
                            handleUpdateStructure(structure.id, {
                              rateOverride: e.target.value ? parseFloat(e.target.value) : undefined,
                            })
                          }
                          className="w-24 p-1 text-xs border rounded font-mono"
                        />
                        {hasOverride && (
                          <button
                            type="button"
                            onClick={() =>
                              handleUpdateStructure(structure.id, { rateOverride: undefined })
                            }
                            className="text-[10px] text-red-600 hover:underline"
                          >
                            Reset
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => handleAddStructure('Cottage')}
              className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Structure</span>
            </button>
          </div>
        </div>
      </div>

      {/* Dynamic Adjustment Parameters */}
      {activeParams.length > 0 && (
        <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold text-neutral-800 uppercase tracking-wider">
              Market Adjustments & Factors ({activeParams.length})
            </h3>
            <span className="text-[10px] text-neutral-400">Profile Defined</span>
          </div>

          <div className="space-y-3 divide-y divide-neutral-100">
            {activeParams.map((param) => {
              const currentValue =
                inputs.parameterValues[param.id] ?? param.defaultValue ?? 0;

              return (
                <div key={param.id} className="pt-2.5 first:pt-0 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold text-neutral-800 block">
                        {param.label}
                      </span>
                      {param.description && (
                        <span className="text-[11px] text-neutral-500 block leading-tight">
                          {param.description}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Input Rendering based on inputType */}
                  {param.inputType === 'dropdown' && param.options && (
                    <div className="relative">
                      <select
                        value={currentValue}
                        onChange={(e) =>
                          handleParameterChange(param.id, parseFloat(e.target.value))
                        }
                        className="w-full text-xs font-medium p-2 bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-neutral-900"
                      >
                        {param.options.map((opt) => (
                          <option key={opt.id} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {param.inputType === 'toggle' && (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const valOn = param.valueWhenOn ?? 1.0;
                          const valOff = param.valueWhenOff ?? 0.0;
                          const isCurrentlyOn = currentValue === valOn;
                          handleParameterChange(param.id, isCurrentlyOn ? valOff : valOn);
                        }}
                        className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          currentValue === (param.valueWhenOn ?? 1.0)
                            ? 'bg-emerald-600'
                            : 'bg-neutral-300'
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                            currentValue === (param.valueWhenOn ?? 1.0)
                              ? 'translate-x-5'
                              : 'translate-x-0'
                          }`}
                        />
                      </button>
                      <span className="text-xs font-medium text-neutral-700">
                        {currentValue === (param.valueWhenOn ?? 1.0)
                          ? param.labelOn || 'Yes'
                          : param.labelOff || 'No'}
                      </span>
                    </div>
                  )}

                  {param.inputType === 'slider' && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-mono text-neutral-700">
                        <span>{((param.min ?? 0) * 100).toFixed(0)}%</span>
                        <span className="font-bold text-emerald-800">
                          {(currentValue * 100).toFixed(1)}%
                        </span>
                        <span>{((param.max ?? 0.5) * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min={param.min ?? 0}
                        max={param.max ?? 0.5}
                        step={param.step ?? 0.05}
                        value={currentValue}
                        onChange={(e) =>
                          handleParameterChange(param.id, parseFloat(e.target.value))
                        }
                        className="w-full accent-emerald-600 cursor-pointer"
                      />
                    </div>
                  )}

                  {param.inputType === 'number' && (
                    <input
                      type="number"
                      value={currentValue}
                      onChange={(e) =>
                        handleParameterChange(param.id, parseFloat(e.target.value) || 0)
                      }
                      className="w-full text-xs font-mono p-2 bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white"
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Optional Observed Asking Price */}
      <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-neutral-800">
            Observed Asking Price (Optional)
          </label>
          <span className="text-[10px] text-neutral-400">Market benchmark</span>
        </div>

        <div className="relative">
          <input
            type="number"
            min="0"
            step="100"
            value={inputs.askingPrice || ''}
            onChange={(e) =>
              onUpdateInputs({
                ...inputs,
                askingPrice: e.target.value ? parseFloat(e.target.value) : undefined,
              })
            }
            placeholder="e.g. 115000"
            className="w-full text-sm font-bold font-mono text-neutral-900 p-2.5 pl-3 pr-14 bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <span className="absolute right-3 top-3 text-xs font-semibold text-neutral-400 font-mono">
            {profile.currency}
          </span>
        </div>

        {result.isOverpriced !== undefined && (
          <div
            className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
              result.isOverpriced
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-emerald-50 border-emerald-200 text-emerald-900'
            }`}
          >
            {result.isOverpriced ? (
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            )}
            <div>
              <span className="font-semibold block">
                {result.isOverpriced
                  ? `Possibly Overpriced (+${result.askingPriceGapPercent?.toFixed(1)}% above estimate)`
                  : `Within Fair Market Range (${result.askingPriceGapPercent && result.askingPriceGapPercent > 0 ? '+' : ''}${result.askingPriceGapPercent?.toFixed(1)}% vs estimate)`}
              </span>
              <span className="text-[11px] opacity-80">
                {result.isOverpriced
                  ? `Asking price exceeds QuickVal estimate by more than the ${overpricedThresholdPercent}% threshold.`
                  : `Asking price aligns closely with mathematical valuation expectations.`}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* ------------------------------------------------------------------ */}
      {/* RESULTS DISPLAY PANEL */}
      {/* ------------------------------------------------------------------ */}
      <div className="space-y-3 pt-2">
        {/* Hero Card: Market Value */}
        <div className="bg-gradient-to-br from-emerald-800 via-emerald-900 to-neutral-950 text-white rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
          <div className="absolute right-0 top-0 w-44 h-44 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex items-center justify-between text-xs text-emerald-200/90 uppercase tracking-widest font-semibold mb-1">
            <span>Estimated Market Value</span>
            <span className="text-[11px] bg-white/10 px-2.5 py-0.5 rounded-full font-mono font-medium backdrop-blur-xs">
              {profile.currency}
            </span>
          </div>

          <div className="text-3xl sm:text-4xl font-extrabold tracking-tight font-mono text-white mb-2">
            {formatCurrency(result.marketValue, profile.currency)}
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-100 text-xs font-medium border border-emerald-400/20 backdrop-blur-xs">
            <span className="text-emerald-300">Value Range (±{profile.outputSettings.rangeWidthPercent}%):</span>
            <span className="font-bold font-mono">
              {formatCurrency(result.rangeLow, profile.currency)} – {formatCurrency(result.rangeHigh, profile.currency)}
            </span>
          </div>
        </div>

        {/* Quick KPI Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          <div className="bg-white rounded-2xl border border-neutral-200/90 p-3.5 shadow-xs">
            <span className="text-[11px] text-neutral-500 font-medium block">
              Forced Sale Value ({profile.outputSettings.forcedSalePercent}%)
            </span>
            <span className="text-base font-bold font-mono text-neutral-900 block mt-0.5">
              {formatCurrency(result.forcedSaleValue, profile.currency)}
            </span>
            <span className="text-[10px] text-neutral-400 block mt-0.5">Liquidation value</span>
          </div>

          <div className="bg-white rounded-2xl border border-neutral-200/90 p-3.5 shadow-xs">
            <span className="text-[11px] text-neutral-500 font-medium block">
              Gross Replacement Cost
            </span>
            <span className="text-base font-bold font-mono text-neutral-900 block mt-0.5">
              {formatCurrency(result.replacementCost, profile.currency)}
            </span>
            <span className="text-[10px] text-neutral-400 block mt-0.5">Insurance as new</span>
          </div>

          <div className="bg-white rounded-2xl border border-neutral-200/90 p-3.5 shadow-xs col-span-2 sm:col-span-1">
            <span className="text-[11px] text-neutral-500 font-medium block">
              Land Component
            </span>
            <span className="text-base font-bold font-mono text-neutral-900 block mt-0.5">
              {formatCurrency(result.landValue, profile.currency)}
            </span>
            <span className="text-[10px] text-neutral-400 block mt-0.5">
              {formatArea(inputs.landArea, profile.areaUnit)}
            </span>
          </div>
        </div>

        {/* Comparables Cross-Check Badge (if comparables present in profile) */}
        {comparablesCheck.comparableCount >= 2 && (
          <div
            className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 ${
              comparablesCheck.hasLargeGap
                ? 'bg-amber-50/80 border-amber-300 text-amber-950'
                : 'bg-emerald-50/80 border-emerald-300 text-emerald-950'
            }`}
          >
            <ShieldAlert
              className={`w-4 h-4 shrink-0 mt-0.5 ${
                comparablesCheck.hasLargeGap ? 'text-amber-600' : 'text-emerald-600'
              }`}
            />
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between font-semibold">
                <span>Market Comparables Cross-Check ({comparablesCheck.comparableCount} sales)</span>
                {comparablesCheck.impliedValue && (
                  <span className="font-mono font-bold">
                    Implied: {formatCurrency(comparablesCheck.impliedValue, profile.currency)}
                  </span>
                )}
              </div>
              <p className="text-[11px] leading-relaxed opacity-90">
                {comparablesCheck.analysisMessage}
              </p>
            </div>
          </div>
        )}

        {/* Visual Composition Chart */}
        <ValuationChart
          landValue={result.landValue}
          buildingValue={result.buildingValue}
          additionsValue={result.additionsValue}
          currency={profile.currency}
        />

        {/* Expandable "How We Got This" Breakdown */}
        <ResultsBreakdown result={result} profile={profile} />

        {/* Mandatory Valuation Disclaimer Card */}
        <div className="p-3.5 bg-neutral-100/90 rounded-2xl border border-neutral-200 text-[11px] text-neutral-600 space-y-1">
          <span className="font-bold text-neutral-800 uppercase tracking-wider text-[10px] block">
            Mandatory Disclaimer
          </span>
          <p className="leading-relaxed">{MANDATORY_DISCLAIMER}</p>
        </div>
      </div>
    </div>
  );
};
