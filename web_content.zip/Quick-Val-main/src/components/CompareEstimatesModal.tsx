import React from 'react';
import { X, ArrowRight, Scale, CheckCircle2 } from 'lucide-react';
import { SavedEstimate } from '../types';
import { formatCurrency, formatArea } from '../engine';

interface CompareEstimatesModalProps {
  isOpen: boolean;
  onClose: () => void;
  estimateA: SavedEstimate;
  estimateB: SavedEstimate;
}

export const CompareEstimatesModal: React.FC<CompareEstimatesModalProps> = ({
  isOpen,
  onClose,
  estimateA,
  estimateB,
}) => {
  if (!isOpen) return null;

  const totalBldA = (estimateA.inputs.buildings || []).reduce((s, b) => s + (b.area || 0), 0);
  const totalBldB = (estimateB.inputs.buildings || []).reduce((s, b) => s + (b.area || 0), 0);

  const diffMarketValue = estimateB.result.marketValue - estimateA.result.marketValue;
  const pctDiffMarket =
    estimateA.result.marketValue > 0
      ? (diffMarketValue / estimateA.result.marketValue) * 100
      : 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/80">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Scale className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-neutral-900 text-sm sm:text-base">
                Side-by-Side Property Comparison
              </h3>
              <p className="text-xs text-neutral-500">
                Comparing two saved valuations and their underlying drivers
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4">
          {/* Top comparison card */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
              <span className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">
                Property A
              </span>
              <h4 className="font-bold text-neutral-900 text-sm truncate">
                {estimateA.title}
              </h4>
              <p className="text-[11px] text-neutral-500">
                {new Date(estimateA.createdAt).toLocaleDateString()} • {estimateA.profileSnapshot.name}
              </p>
              <div className="pt-2">
                <span className="text-lg font-bold font-mono text-emerald-800">
                  {formatCurrency(estimateA.result.marketValue, estimateA.profileSnapshot.currency)}
                </span>
                <div className="text-[10px] text-neutral-500">
                  Range: {formatCurrency(estimateA.result.rangeLow, estimateA.profileSnapshot.currency)} – {formatCurrency(estimateA.result.rangeHigh, estimateA.profileSnapshot.currency)}
                </div>
              </div>
            </div>

            <div className="p-3.5 bg-emerald-50/50 rounded-xl border border-emerald-200 space-y-1">
              <span className="text-[10px] font-semibold text-emerald-600 uppercase tracking-wider">
                Property B
              </span>
              <h4 className="font-bold text-neutral-900 text-sm truncate">
                {estimateB.title}
              </h4>
              <p className="text-[11px] text-neutral-500">
                {new Date(estimateB.createdAt).toLocaleDateString()} • {estimateB.profileSnapshot.name}
              </p>
              <div className="pt-2">
                <span className="text-lg font-bold font-mono text-emerald-800">
                  {formatCurrency(estimateB.result.marketValue, estimateB.profileSnapshot.currency)}
                </span>
                <div className="text-[10px] text-neutral-500">
                  Range: {formatCurrency(estimateB.result.rangeLow, estimateB.profileSnapshot.currency)} – {formatCurrency(estimateB.result.rangeHigh, estimateB.profileSnapshot.currency)}
                </div>
              </div>
            </div>
          </div>

          {/* Variance Banner */}
          <div className="p-2.5 bg-neutral-100 rounded-lg text-center text-xs text-neutral-700 font-medium">
            Property B is {diffMarketValue >= 0 ? '+' : ''}
            {formatCurrency(diffMarketValue, estimateB.profileSnapshot.currency)} ({pctDiffMarket >= 0 ? '+' : ''}
            {pctDiffMarket.toFixed(1)}%) compared to Property A.
          </div>

          {/* Detailed Metric Rows */}
          <div className="border border-neutral-200 rounded-xl overflow-hidden divide-y divide-neutral-100 text-xs">
            <div className="grid grid-cols-3 p-2.5 bg-neutral-50 font-semibold text-neutral-600">
              <span>Metric</span>
              <span className="text-center">Property A</span>
              <span className="text-center">Property B</span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-neutral-600 font-medium">Land Area</span>
              <span className="text-center font-mono font-medium">
                {formatArea(estimateA.inputs.landArea, estimateA.profileSnapshot.areaUnit)}
              </span>
              <span className="text-center font-mono font-medium">
                {formatArea(estimateB.inputs.landArea, estimateB.profileSnapshot.areaUnit)}
              </span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-neutral-600 font-medium">Total Buildings Area</span>
              <span className="text-center font-mono font-medium">
                {formatArea(totalBldA, estimateA.profileSnapshot.areaUnit)}
              </span>
              <span className="text-center font-mono font-medium">
                {formatArea(totalBldB, estimateB.profileSnapshot.areaUnit)}
              </span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-neutral-600 font-medium">Land Value</span>
              <span className="text-center font-mono">
                {formatCurrency(estimateA.result.landValue, estimateA.profileSnapshot.currency)}
              </span>
              <span className="text-center font-mono">
                {formatCurrency(estimateB.result.landValue, estimateB.profileSnapshot.currency)}
              </span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-neutral-600 font-medium">Building Value</span>
              <span className="text-center font-mono">
                {formatCurrency(estimateA.result.buildingValue, estimateA.profileSnapshot.currency)}
              </span>
              <span className="text-center font-mono">
                {formatCurrency(estimateB.result.buildingValue, estimateB.profileSnapshot.currency)}
              </span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-neutral-600 font-medium">Additions / External</span>
              <span className="text-center font-mono">
                {formatCurrency(estimateA.result.additionsValue, estimateA.profileSnapshot.currency)}
              </span>
              <span className="text-center font-mono">
                {formatCurrency(estimateB.result.additionsValue, estimateB.profileSnapshot.currency)}
              </span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-neutral-600 font-medium">Forced Sale Value</span>
              <span className="text-center font-mono">
                {formatCurrency(estimateA.result.forcedSaleValue, estimateA.profileSnapshot.currency)}
              </span>
              <span className="text-center font-mono">
                {formatCurrency(estimateB.result.forcedSaleValue, estimateB.profileSnapshot.currency)}
              </span>
            </div>

            <div className="grid grid-cols-3 p-2.5 items-center">
              <span className="text-neutral-600 font-medium">Gross Replacement</span>
              <span className="text-center font-mono">
                {formatCurrency(estimateA.result.replacementCost, estimateA.profileSnapshot.currency)}
              </span>
              <span className="text-center font-mono">
                {formatCurrency(estimateB.result.replacementCost, estimateB.profileSnapshot.currency)}
              </span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 bg-neutral-50 flex items-center justify-end">
          <button
            onClick={onClose}
            type="button"
            className="px-5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            Close Comparison
          </button>
        </div>
      </div>
    </div>
  );
};
