import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { formatCurrency } from '../engine';

interface ValuationChartProps {
  landValue: number;
  buildingValue: number;
  additionsValue: number;
  currency: string;
}

export const ValuationChart: React.FC<ValuationChartProps> = ({
  landValue,
  buildingValue,
  additionsValue,
  currency,
}) => {
  const data = [
    { name: 'Land Value', value: Math.max(0, landValue), color: '#059669' }, // emerald-600
    { name: 'Buildings', value: Math.max(0, buildingValue), color: '#2563eb' }, // blue-600
    { name: 'Additions / Works', value: Math.max(0, additionsValue), color: '#d97706' }, // amber-600
  ].filter((item) => item.value > 0);

  const total = data.reduce((sum, item) => sum + item.value, 0);

  if (total <= 0) {
    return (
      <div className="flex items-center justify-center h-44 bg-neutral-50 rounded-xl border border-dashed border-neutral-200 text-xs text-neutral-400">
        Enter land or building areas to view composition
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-neutral-200/80 p-3 shadow-xs">
      <div className="text-xs font-semibold text-neutral-600 uppercase tracking-wider mb-2 flex items-center justify-between">
        <span>Asset Composition</span>
        <span className="text-neutral-400 font-normal">Subtotal: {formatCurrency(total, currency)}</span>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="w-full sm:w-1/2 h-36 relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={36}
                outerRadius={56}
                paddingAngle={3}
                dataKey="value"
                stroke="#ffffff"
                strokeWidth={2}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(val: any) => [formatCurrency(Number(val) || 0, currency), 'Value']}
                contentStyle={{
                  borderRadius: '8px',
                  border: '1px solid #e5e7eb',
                  fontSize: '12px',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-[10px] text-neutral-400 font-medium">Split</span>
          </div>
        </div>

        <div className="w-full sm:w-1/2 flex flex-col gap-1.5">
          {data.map((item) => {
            const pct = Math.round((item.value / total) * 100);
            return (
              <div key={item.name} className="flex items-center justify-between text-xs py-0.5 border-b border-neutral-100 last:border-none">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-xs shrink-0"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-neutral-700 font-medium truncate">{item.name}</span>
                </div>
                <div className="text-right">
                  <span className="font-semibold text-neutral-800">{formatCurrency(item.value, currency)}</span>
                  <span className="text-neutral-400 ml-1">({pct}%)</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
