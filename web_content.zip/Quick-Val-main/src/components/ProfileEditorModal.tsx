import React, { useState } from 'react';
import {
  X,
  Check,
  Plus,
  Trash2,
  ChevronUp,
  ChevronDown,
  Sparkles,
  SlidersHorizontal,
  Building2,
  Layers,
  Settings2,
  DollarSign,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import {
  MarketProfile,
  ParameterConfig,
  ParameterEffectType,
  ParameterInputType,
  PropertyTypeConfig,
  ComparableSale,
} from '../types';
import { CalibrateModal } from './CalibrateModal';

interface ProfileEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: MarketProfile;
  onSave: (updatedProfile: MarketProfile) => void;
}

export const ProfileEditorModal: React.FC<ProfileEditorModalProps> = ({
  isOpen,
  onClose,
  profile,
  onSave,
}) => {
  const [edited, setEdited] = useState<MarketProfile>({ ...profile });
  const [activeTab, setActiveTab] = useState<'general' | 'rates' | 'params' | 'types' | 'comps'>('general');

  // Modals inside editor
  const [showCalibrateModal, setShowCalibrateModal] = useState(false);

  // New parameter state
  const [showNewParamForm, setShowNewParamForm] = useState(false);
  const [newParam, setNewParam] = useState<Partial<ParameterConfig>>({
    label: '',
    description: '',
    inputType: 'dropdown',
    effectType: 'land_multiplier',
    defaultValue: 1.0,
    options: [
      { id: 'opt-1', label: 'Prime (1.10x)', value: 1.1 },
      { id: 'opt-2', label: 'Standard (1.00x)', value: 1.0 },
      { id: 'opt-3', label: 'Secondary (0.90x)', value: 0.9 },
    ],
  });

  // New property type state
  const [showNewTypeForm, setShowNewTypeForm] = useState(false);
  const [newTypeName, setNewTypeName] = useState('');
  const [newTypeRequiresLand, setNewTypeRequiresLand] = useState(true);

  // New comparable state
  const [showNewCompForm, setShowNewCompForm] = useState(false);
  const [newComp, setNewComp] = useState<Partial<ComparableSale>>({
    description: '',
    price: 100000,
    date: new Date().toISOString().split('T')[0],
    buildingArea: 150,
    landArea: 1500,
    sourceNote: '',
  });

  if (!isOpen) return null;

  const handleMoveParam = (index: number, direction: 'up' | 'down') => {
    const newParams = [...edited.parameters];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newParams.length) return;
    const temp = newParams[index];
    newParams[index] = newParams[targetIndex];
    newParams[targetIndex] = temp;
    setEdited({ ...edited, parameters: newParams });
  };

  const handleDeleteParam = (id: string) => {
    setEdited({
      ...edited,
      parameters: edited.parameters.filter((p) => p.id !== id),
    });
  };

  const handleAddParameter = () => {
    if (!newParam.label) return;
    const paramId = `param-${Date.now()}`;
    const constructedParam: ParameterConfig = {
      id: paramId,
      label: newParam.label,
      description: newParam.description || '',
      inputType: newParam.inputType || 'number',
      effectType: newParam.effectType || 'land_multiplier',
      defaultValue: newParam.defaultValue ?? 1.0,
      options: newParam.options,
      valueWhenOn: newParam.valueWhenOn,
      valueWhenOff: newParam.valueWhenOff,
      labelOn: newParam.labelOn,
      labelOff: newParam.labelOff,
      min: newParam.min,
      max: newParam.max,
      step: newParam.step,
      unitSuffix: newParam.unitSuffix,
    };

    setEdited({
      ...edited,
      parameters: [...edited.parameters, constructedParam],
    });

    setShowNewParamForm(false);
    setNewParam({
      label: '',
      description: '',
      inputType: 'dropdown',
      effectType: 'land_multiplier',
      defaultValue: 1.0,
      options: [
        { id: 'opt-1', label: 'Prime (1.10x)', value: 1.1 },
        { id: 'opt-2', label: 'Standard (1.00x)', value: 1.0 },
      ],
    });
  };

  const handleAddPropertyType = () => {
    if (!newTypeName.trim()) return;
    const typeId = `pt-${Date.now()}`;
    const newPt: PropertyTypeConfig = {
      id: typeId,
      name: newTypeName.trim(),
      requiresLandArea: newTypeRequiresLand,
    };
    setEdited({
      ...edited,
      propertyTypes: [...edited.propertyTypes, newPt],
    });
    setNewTypeName('');
    setShowNewTypeForm(false);
  };

  const handleDeletePropertyType = (id: string) => {
    if (edited.propertyTypes.length <= 1) return;
    setEdited({
      ...edited,
      propertyTypes: edited.propertyTypes.filter((pt) => pt.id !== id),
    });
  };

  const handleAddComparable = () => {
    if (!newComp.description || !newComp.price) return;
    const compId = `comp-${Date.now()}`;
    const item: ComparableSale = {
      id: compId,
      description: newComp.description,
      price: Number(newComp.price),
      date: newComp.date || new Date().toISOString().split('T')[0],
      buildingArea: newComp.buildingArea ? Number(newComp.buildingArea) : undefined,
      landArea: newComp.landArea ? Number(newComp.landArea) : undefined,
      sourceNote: newComp.sourceNote,
    };
    setEdited({
      ...edited,
      comparables: [...(edited.comparables || []), item],
    });
    setShowNewCompForm(false);
    setNewComp({
      description: '',
      price: 100000,
      date: new Date().toISOString().split('T')[0],
      buildingArea: 150,
      landArea: 1500,
      sourceNote: '',
    });
  };

  const handleDeleteComparable = (id: string) => {
    setEdited({
      ...edited,
      comparables: (edited.comparables || []).filter((c) => c.id !== id),
    });
  };

  const handleSave = () => {
    onSave({
      ...edited,
      updatedAt: new Date().toISOString(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[94vh] flex flex-col shadow-2xl overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/80">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Settings2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-neutral-900 text-sm sm:text-base">
                Edit Market Profile: {edited.name}
              </h3>
              <p className="text-xs text-neutral-500">
                Configure base rates, output thresholds, property types & parameters
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-Navigation Tabs */}
        <div className="flex border-b border-neutral-200 bg-neutral-100/70 px-4 overflow-x-auto gap-1 text-xs font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('general')}
            className={`py-2.5 px-3 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'general'
                ? 'border-emerald-600 text-emerald-800 font-semibold'
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            General & Output
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('rates')}
            className={`py-2.5 px-3 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'rates'
                ? 'border-emerald-600 text-emerald-800 font-semibold'
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Base Rates
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('params')}
            className={`py-2.5 px-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1 ${
              activeTab === 'params'
                ? 'border-emerald-600 text-emerald-800 font-semibold'
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <span>Parameters</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-neutral-200 text-neutral-700">
              {edited.parameters.length}
            </span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('types')}
            className={`py-2.5 px-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1 ${
              activeTab === 'types'
                ? 'border-emerald-600 text-emerald-800 font-semibold'
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <span>Property Types</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-neutral-200 text-neutral-700">
              {edited.propertyTypes.length}
            </span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('comps')}
            className={`py-2.5 px-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1 ${
              activeTab === 'comps'
                ? 'border-emerald-600 text-emerald-800 font-semibold'
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <span>Comparables</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-neutral-200 text-neutral-700">
              {(edited.comparables || []).length}
            </span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: GENERAL & OUTPUT */}
          {activeTab === 'general' && (
            <div className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-semibold text-neutral-700">Profile Name</label>
                <input
                  type="text"
                  value={edited.name}
                  onChange={(e) => setEdited({ ...edited, name: e.target.value })}
                  placeholder="e.g. Harare North, Lusaka Residential"
                  className="w-full p-2.5 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-neutral-700">Description / Market Notes</label>
                <textarea
                  rows={2}
                  value={edited.description || ''}
                  onChange={(e) => setEdited({ ...edited, description: e.target.value })}
                  placeholder="e.g. Middle-to-high density residential stands with standard municipal servicing"
                  className="w-full p-2.5 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-neutral-700">Currency Code / Symbol</label>
                  <input
                    type="text"
                    value={edited.currency}
                    onChange={(e) => setEdited({ ...edited, currency: e.target.value })}
                    placeholder="e.g. US$, ZAR, GBP, EUR, $"
                    className="w-full p-2.5 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-neutral-700">Area Measurement Unit</label>
                  <select
                    value={edited.areaUnit}
                    onChange={(e) =>
                      setEdited({ ...edited, areaUnit: e.target.value as 'sqm' | 'sqft' })
                    }
                    className="w-full p-2.5 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono"
                  >
                    <option value="sqm">Square Meters (sqm)</option>
                    <option value="sqft">Square Feet (sqft)</option>
                  </select>
                </div>
              </div>

              <div className="border-t border-neutral-200 pt-3 space-y-3">
                <h4 className="font-semibold text-neutral-800 uppercase tracking-wider text-[11px]">
                  Output & Valuation Settings
                </h4>

                <div className="grid grid-cols-3 gap-2.5">
                  <div className="space-y-1">
                    <label className="text-neutral-600 block">Forced Sale %</label>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        value={edited.outputSettings.forcedSalePercent}
                        onChange={(e) =>
                          setEdited({
                            ...edited,
                            outputSettings: {
                              ...edited.outputSettings,
                              forcedSalePercent: parseFloat(e.target.value) || 75,
                            },
                          })
                        }
                        className="w-full p-2 rounded-lg border border-neutral-300 font-mono"
                      />
                      <span className="text-neutral-500 font-mono">%</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-neutral-600 block">Range Width (±%)</label>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        value={edited.outputSettings.rangeWidthPercent}
                        onChange={(e) =>
                          setEdited({
                            ...edited,
                            outputSettings: {
                              ...edited.outputSettings,
                              rangeWidthPercent: parseFloat(e.target.value) || 10,
                            },
                          })
                        }
                        className="w-full p-2 rounded-lg border border-neutral-300 font-mono"
                      />
                      <span className="text-neutral-500 font-mono">%</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-neutral-600 block">Rounding Step</label>
                    <input
                      type="number"
                      value={edited.outputSettings.roundingStep}
                      onChange={(e) =>
                        setEdited({
                          ...edited,
                          outputSettings: {
                            ...edited.outputSettings,
                            roundingStep: parseFloat(e.target.value) || 500,
                          },
                        })
                      }
                      className="w-full p-2 rounded-lg border border-neutral-300 font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: BASE RATES */}
          {activeTab === 'rates' && (
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                <div>
                  <span className="font-semibold text-emerald-900 block">
                    Base Market Unit Rates
                  </span>
                  <span className="text-[11px] text-emerald-700">
                    Values are per {edited.areaUnit} in {edited.currency}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowCalibrateModal(true)}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>Calibrate from Report</span>
                </button>
              </div>

              <div className="space-y-3">
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-neutral-800">
                      Land Rate (per {edited.areaUnit})
                    </label>
                    <span className="font-mono text-neutral-500">{edited.currency}/{edited.areaUnit}</span>
                  </div>
                  <input
                    type="number"
                    step="0.1"
                    value={edited.baseRates.landRate}
                    onChange={(e) =>
                      setEdited({
                        ...edited,
                        baseRates: {
                          ...edited.baseRates,
                          landRate: parseFloat(e.target.value) || 0,
                        },
                      })
                    }
                    className="w-full p-2.5 bg-white rounded-lg border border-neutral-300 font-mono text-sm font-semibold text-neutral-900"
                  />
                  <p className="text-[11px] text-neutral-500">
                    Starting raw land base rate before applying location, topography, or zoning multipliers.
                  </p>
                </div>

                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-neutral-800">
                      Building Rate (per {edited.areaUnit})
                    </label>
                    <span className="font-mono text-neutral-500">{edited.currency}/{edited.areaUnit}</span>
                  </div>
                  <input
                    type="number"
                    step="1"
                    value={edited.baseRates.buildingRate}
                    onChange={(e) =>
                      setEdited({
                        ...edited,
                        baseRates: {
                          ...edited.baseRates,
                          buildingRate: parseFloat(e.target.value) || 0,
                        },
                      })
                    }
                    className="w-full p-2.5 bg-white rounded-lg border border-neutral-300 font-mono text-sm font-semibold text-neutral-900"
                  />
                  <p className="text-[11px] text-neutral-500">
                    Depreciated / market building rate applied to gross structural areas.
                  </p>
                </div>

                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-neutral-800">
                      Replacement Cost Rate (per {edited.areaUnit})
                    </label>
                    <span className="font-mono text-neutral-500">{edited.currency}/{edited.areaUnit}</span>
                  </div>
                  <input
                    type="number"
                    step="1"
                    value={edited.baseRates.replacementRate}
                    onChange={(e) =>
                      setEdited({
                        ...edited,
                        baseRates: {
                          ...edited.baseRates,
                          replacementRate: parseFloat(e.target.value) || 0,
                        },
                      })
                    }
                    className="w-full p-2.5 bg-white rounded-lg border border-neutral-300 font-mono text-sm font-semibold text-neutral-900"
                  />
                  <p className="text-[11px] text-neutral-500">
                    Estimated contractor cost to rebuild as new for insurance/replacement purposes.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PARAMETERS */}
          {activeTab === 'params' && (
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-semibold text-neutral-800 text-sm block">
                    Adjustment Parameters ({edited.parameters.length})
                  </span>
                  <span className="text-[11px] text-neutral-500">
                    Applied sequentially to Land, Building, or Total Subtotal
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setShowNewParamForm(true)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-xs transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Parameter</span>
                  </button>
                </div>
              </div>

              {/* Form to add custom parameter */}
              {showNewParamForm && (
                <div className="p-3.5 bg-emerald-50/50 rounded-xl border border-emerald-300 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-emerald-900 text-xs">
                      New Adjustment Parameter
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowNewParamForm(false)}
                      className="text-neutral-400 hover:text-neutral-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="col-span-2 space-y-0.5">
                      <label className="text-[11px] font-semibold text-neutral-700">Label</label>
                      <input
                        type="text"
                        value={newParam.label}
                        onChange={(e) => setNewParam({ ...newParam, label: e.target.value })}
                        placeholder="e.g. Borehole, Solar Backup, Ocean View"
                        className="w-full p-2 bg-white rounded-lg border border-neutral-300"
                      />
                    </div>

                    <div className="space-y-0.5">
                      <label className="text-[11px] font-semibold text-neutral-700">Input Type</label>
                      <select
                        value={newParam.inputType}
                        onChange={(e) =>
                          setNewParam({
                            ...newParam,
                            inputType: e.target.value as ParameterInputType,
                          })
                        }
                        className="w-full p-2 bg-white rounded-lg border border-neutral-300"
                      >
                        <option value="dropdown">Dropdown (options list)</option>
                        <option value="toggle">Toggle (Yes / No)</option>
                        <option value="slider">Percentage Slider</option>
                        <option value="number">Numeric Stepper</option>
                      </select>
                    </div>

                    <div className="space-y-0.5">
                      <label className="text-[11px] font-semibold text-neutral-700">Effect on Value</label>
                      <select
                        value={newParam.effectType}
                        onChange={(e) =>
                          setNewParam({
                            ...newParam,
                            effectType: e.target.value as ParameterEffectType,
                          })
                        }
                        className="w-full p-2 bg-white rounded-lg border border-neutral-300"
                      >
                        <option value="land_multiplier">1. Multiplier on Land Value</option>
                        <option value="building_multiplier">2. Multiplier on Building Value</option>
                        <option value="total_percentage">3. Percentage on Total Value (±%)</option>
                        <option value="fixed_amount">4. Fixed Sum (+/- in currency)</option>
                        <option value="building_percentage">5. % of Building (e.g. Works)</option>
                        <option value="replacement_multiplier">6. Multiplier on Replacement</option>
                        <option value="building_and_replacement_multiplier">
                          7. Multiplier on Both Building & Replacement
                        </option>
                      </select>
                    </div>
                  </div>

                  {newParam.inputType === 'toggle' && (
                    <div className="grid grid-cols-2 gap-2 p-2 bg-white rounded-lg border border-neutral-200">
                      <div>
                        <label className="text-[10px] text-neutral-500 block">Value When ON</label>
                        <input
                          type="number"
                          step="0.01"
                          placeholder="e.g. 0.05 for +5% or 10000"
                          value={newParam.valueWhenOn ?? 0.05}
                          onChange={(e) =>
                            setNewParam({ ...newParam, valueWhenOn: parseFloat(e.target.value) || 0 })
                          }
                          className="w-full p-1.5 border rounded text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-neutral-500 block">Value When OFF</label>
                        <input
                          type="number"
                          step="0.01"
                          placeholder="0"
                          value={newParam.valueWhenOff ?? 0}
                          onChange={(e) =>
                            setNewParam({ ...newParam, valueWhenOff: parseFloat(e.target.value) || 0 })
                          }
                          className="w-full p-1.5 border rounded text-xs font-mono"
                        />
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowNewParamForm(false)}
                      className="px-3 py-1.5 text-xs text-neutral-600 hover:text-neutral-900"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleAddParameter}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-xs shadow-xs"
                    >
                      Save Parameter
                    </button>
                  </div>
                </div>
              )}

              {/* Parameters List with reordering */}
              <div className="space-y-2">
                {edited.parameters.map((param, idx) => (
                  <div
                    key={param.id}
                    className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2">
                      <div className="flex flex-col gap-0.5">
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => handleMoveParam(idx, 'up')}
                          className="p-0.5 text-neutral-400 hover:text-neutral-800 disabled:opacity-20"
                        >
                          <ChevronUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === edited.parameters.length - 1}
                          onClick={() => handleMoveParam(idx, 'down')}
                          className="p-0.5 text-neutral-400 hover:text-neutral-800 disabled:opacity-20"
                        >
                          <ChevronDown className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div>
                        <div className="font-semibold text-neutral-900 text-xs flex items-center gap-1.5">
                          <span>{param.label}</span>
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-200/80 text-neutral-700">
                            {param.inputType}
                          </span>
                        </div>
                        <div className="text-[11px] text-neutral-500">
                          Effect: <span className="font-medium text-neutral-700">{param.effectType.replace(/_/g, ' ')}</span>
                          {param.description ? ` • ${param.description}` : ''}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteParam(param.id)}
                      className="text-neutral-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: PROPERTY TYPES */}
          {activeTab === 'types' && (
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-semibold text-neutral-800 text-sm block">
                    Property Types ({edited.propertyTypes.length})
                  </span>
                  <span className="text-[11px] text-neutral-500">
                    Define whether land area is required or base rates differ
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowNewTypeForm(true)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Property Type</span>
                </button>
              </div>

              {showNewTypeForm && (
                <div className="p-3 bg-neutral-100 rounded-xl border border-neutral-300 space-y-2">
                  <div className="space-y-1">
                    <label className="font-semibold text-neutral-700">Property Type Name</label>
                    <input
                      type="text"
                      value={newTypeName}
                      onChange={(e) => setNewTypeName(e.target.value)}
                      placeholder="e.g. Agricultural / Smallholding"
                      className="w-full p-2 bg-white rounded-lg border border-neutral-300"
                    />
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer pt-1">
                    <input
                      type="checkbox"
                      checked={newTypeRequiresLand}
                      onChange={(e) => setNewTypeRequiresLand(e.target.checked)}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="text-neutral-700">Requires Land Area (uncheck for Sectional Title / Flats)</span>
                  </label>
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowNewTypeForm(false)}
                      className="px-3 py-1 text-xs text-neutral-600"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleAddPropertyType}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold"
                    >
                      Save Type
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                {edited.propertyTypes.map((pt) => (
                  <div
                    key={pt.id}
                    className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-semibold text-neutral-900 text-xs">
                        {pt.name}
                      </div>
                      <div className="text-[11px] text-neutral-500">
                        {pt.requiresLandArea ? 'Land area mandatory' : 'Sectional title / Land area optional'}
                      </div>
                    </div>
                    {edited.propertyTypes.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleDeletePropertyType(pt.id)}
                        className="text-neutral-400 hover:text-red-600 p-1.5"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: COMPARABLES */}
          {activeTab === 'comps' && (
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-semibold text-neutral-800 text-sm block">
                    Comparable Evidence ({(edited.comparables || []).length})
                  </span>
                  <span className="text-[11px] text-neutral-500">
                    Provides live cross-check median rates on calculated estimates
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowNewCompForm(true)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Comparable</span>
                </button>
              </div>

              {showNewCompForm && (
                <div className="p-3.5 bg-neutral-100 rounded-xl border border-neutral-300 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-800">Add Comparable Sale</span>
                    <button
                      type="button"
                      onClick={() => setShowNewCompForm(false)}
                      className="text-neutral-400 hover:text-neutral-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <input
                    type="text"
                    value={newComp.description}
                    onChange={(e) => setNewComp({ ...newComp, description: e.target.value })}
                    placeholder="Description (e.g. 4-bed house, Jacaranda)"
                    className="w-full p-2 bg-white rounded-lg border border-neutral-300"
                  />

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[10px] text-neutral-500 block">Price ({edited.currency})</label>
                      <input
                        type="number"
                        value={newComp.price || ''}
                        onChange={(e) => setNewComp({ ...newComp, price: parseFloat(e.target.value) || 0 })}
                        className="w-full p-1.5 bg-white rounded-lg border border-neutral-300 font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-neutral-500 block">Building Area ({edited.areaUnit})</label>
                      <input
                        type="number"
                        value={newComp.buildingArea || ''}
                        onChange={(e) =>
                          setNewComp({ ...newComp, buildingArea: parseFloat(e.target.value) || undefined })
                        }
                        className="w-full p-1.5 bg-white rounded-lg border border-neutral-300 font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-neutral-500 block">Land Area ({edited.areaUnit})</label>
                      <input
                        type="number"
                        value={newComp.landArea || ''}
                        onChange={(e) =>
                          setNewComp({ ...newComp, landArea: parseFloat(e.target.value) || undefined })
                        }
                        className="w-full p-1.5 bg-white rounded-lg border border-neutral-300 font-mono"
                      />
                    </div>
                  </div>

                  <input
                    type="text"
                    value={newComp.sourceNote || ''}
                    onChange={(e) => setNewComp({ ...newComp, sourceNote: e.target.value })}
                    placeholder="Source note (e.g. Registered deeds transfer)"
                    className="w-full p-2 bg-white rounded-lg border border-neutral-300"
                  />

                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowNewCompForm(false)}
                      className="px-3 py-1.5 text-xs text-neutral-600"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleAddComparable}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-xs shadow-xs"
                    >
                      Save Comparable
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                {(edited.comparables || []).map((c) => (
                  <div
                    key={c.id}
                    className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-semibold text-neutral-900 text-xs">
                        {c.description}
                      </div>
                      <div className="text-[11px] text-neutral-500">
                        {edited.currency} {c.price.toLocaleString()} • {c.buildingArea ? `${c.buildingArea} ${edited.areaUnit} bld` : ''} • {c.date}
                        {c.sourceNote ? ` (${c.sourceNote})` : ''}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteComparable(c.id)}
                      className="text-neutral-400 hover:text-red-600 p-1.5"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 bg-neutral-50 flex items-center justify-end gap-2.5">
          <button
            onClick={onClose}
            type="button"
            className="px-4 py-2 text-xs font-medium text-neutral-600 hover:text-neutral-900 rounded-lg hover:bg-neutral-200/60 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            type="button"
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Check className="w-4 h-4" />
            <span>Save Profile Changes</span>
          </button>
        </div>
      </div>

      {/* Sub-Modals */}
      <CalibrateModal
        isOpen={showCalibrateModal}
        onClose={() => setShowCalibrateModal(false)}
        profile={edited}
        onApplyCalibration={(newRates) => {
          setEdited({
            ...edited,
            baseRates: {
              landRate: newRates.landRate,
              buildingRate: newRates.buildingRate,
              replacementRate: newRates.replacementRate,
            },
            outputSettings: {
              ...edited.outputSettings,
              forcedSalePercent: newRates.forcedSalePercent,
            },
          });
        }}
      />
    </div>
  );
};
