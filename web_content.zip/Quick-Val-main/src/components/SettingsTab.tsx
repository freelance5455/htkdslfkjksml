import React, { useState } from 'react';
import {
  Settings,
  Shield,
  RotateCcw,
  Download,
  Upload,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Play,
  Info,
} from 'lucide-react';
import { MarketProfile } from '../types';
import { AppSettings, MANDATORY_DISCLAIMER } from '../storage';
import { verifySamplePreset, formatCurrency } from '../engine';

interface SettingsTabProps {
  settings: AppSettings;
  profiles: MarketProfile[];
  onUpdateSettings: (newSettings: AppSettings) => void;
  onResetAllData: () => void;
  onExportAll: () => void;
  onImportAll: () => void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  settings,
  profiles,
  onUpdateSettings,
  onResetAllData,
  onExportAll,
  onImportAll,
}) => {
  const [verificationResult, setVerificationResult] = useState<ReturnType<
    typeof verifySamplePreset
  > | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleRunVerification = () => {
    const result = verifySamplePreset();
    setVerificationResult(result);
  };

  return (
    <div className="space-y-4 pb-20 max-w-2xl mx-auto px-3 sm:px-4 pt-3">
      {/* General Preferences */}
      <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-bold text-neutral-900">Application Settings</h2>
          <p className="text-xs text-neutral-500">
            Valuation defaults and operational preferences
          </p>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <label className="font-semibold text-neutral-700 block mb-1">
              Default Market Profile on Launch
            </label>
            <select
              value={settings.defaultProfileId}
              onChange={(e) =>
                onUpdateSettings({ ...settings, defaultProfileId: e.target.value })
              }
              className="w-full p-2.5 bg-neutral-50 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {profiles.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.currency})
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-semibold text-neutral-700">
                Overpriced Warning Threshold (% above estimate)
              </label>
              <span className="font-mono font-bold text-emerald-800">
                {settings.overpricedThresholdPercent}%
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="35"
              step="1"
              value={settings.overpricedThresholdPercent}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  overpricedThresholdPercent: parseInt(e.target.value) || 15,
                })
              }
              className="w-full accent-emerald-600 cursor-pointer"
            />
            <p className="text-[11px] text-neutral-500 mt-0.5">
              Flags an observed asking price as potentially overpriced when it exceeds the QuickVal estimate by more than this percentage.
            </p>
          </div>
        </div>
      </div>

      {/* Sample Preset Verification Runner */}
      <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold text-neutral-800 uppercase tracking-wider">
              Sample Preset Verification (Unit Test)
            </h3>
            <p className="text-xs text-neutral-500">
              Dev-test to verify mathematical accuracy against the Rusape specification
            </p>
          </div>
          <button
            type="button"
            onClick={handleRunVerification}
            className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Verify Sample</span>
          </button>
        </div>

        {verificationResult && (
          <div
            className={`p-3.5 rounded-xl border text-xs space-y-2 ${
              verificationResult.success
                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                : 'bg-red-50 border-red-300 text-red-950'
            }`}
          >
            <div className="flex items-center gap-2 font-bold">
              {verificationResult.success ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Verification Passed (100% Exact Match)</span>
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-red-600" />
                  <span>Verification Mismatch</span>
                </>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
              <div className="p-2 bg-white/70 rounded-lg">
                <span className="text-neutral-500 block">Land Value:</span>
                <strong>US${verificationResult.actual.land.toLocaleString()}</strong> (Target: US${verificationResult.expected.land.toLocaleString()})
              </div>
              <div className="p-2 bg-white/70 rounded-lg">
                <span className="text-neutral-500 block">Market Value:</span>
                <strong>US${verificationResult.actual.market.toLocaleString()}</strong> (Target: US${verificationResult.expected.market.toLocaleString()})
              </div>
              <div className="p-2 bg-white/70 rounded-lg">
                <span className="text-neutral-500 block">Forced Sale Value:</span>
                <strong>US${verificationResult.actual.forcedSale.toLocaleString()}</strong> (Target: US${verificationResult.expected.forcedSale.toLocaleString()})
              </div>
              <div className="p-2 bg-white/70 rounded-lg">
                <span className="text-neutral-500 block">Replacement Cost:</span>
                <strong>US${verificationResult.actual.replacement.toLocaleString()}</strong> (Target: US${verificationResult.expected.replacement.toLocaleString()})
              </div>
            </div>

            <p className="text-[10px] opacity-80 italic">
              Checked 1,887 sqm land + 189.14 sqm buildings with Castle Base, Good finish, Good condition & 20% external works.
            </p>
          </div>
        )}
      </div>

      {/* Mandatory Disclaimer Display */}
      <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Shield className="w-4 h-4 text-emerald-700" />
            <h3 className="text-xs font-semibold text-neutral-800 uppercase tracking-wider">
              Mandatory Legal Disclaimer
            </h3>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-600">
            Cannot Be Disabled
          </span>
        </div>
        <p className="text-xs text-neutral-600 bg-neutral-50 p-3 rounded-xl border border-neutral-200 leading-relaxed italic">
          "{MANDATORY_DISCLAIMER}"
        </p>
        <p className="text-[10px] text-neutral-400">
          This disclaimer is automatically appended to the results view, PDF/image exports, and shared clipboard summaries.
        </p>
      </div>

      {/* Backup and Data Management */}
      <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-3">
        <h3 className="text-xs font-semibold text-neutral-800 uppercase tracking-wider">
          Backup & Data Management
        </h3>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <button
            type="button"
            onClick={onExportAll}
            className="p-3 bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 rounded-xl font-semibold text-neutral-800 flex items-center justify-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4 text-neutral-600" />
            <span>Export Backup (JSON)</span>
          </button>

          <button
            type="button"
            onClick={onImportAll}
            className="p-3 bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 rounded-xl font-semibold text-neutral-800 flex items-center justify-center gap-2 transition-colors"
          >
            <Upload className="w-4 h-4 text-neutral-600" />
            <span>Import Backup (JSON)</span>
          </button>
        </div>

        <div className="pt-2 border-t border-neutral-100">
          <button
            type="button"
            onClick={() => setShowResetConfirm(true)}
            className="w-full py-2.5 text-xs text-red-600 hover:text-red-700 hover:bg-red-50 font-semibold rounded-xl border border-red-200 transition-colors flex items-center justify-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Application Data</span>
          </button>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-3 border border-neutral-200">
            <div className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" />
              <h3 className="text-sm font-bold text-neutral-900">Reset App Data?</h3>
            </div>
            <p className="text-xs text-neutral-600 leading-relaxed">
              This will erase all custom market profiles, saved valuations, and restore the factory sample presets.
              This action cannot be undone.
            </p>
            <div className="flex justify-end gap-2 pt-2 text-xs">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 font-medium text-neutral-600 hover:text-neutral-900"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onResetAllData();
                  setShowResetConfirm(false);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold shadow-xs"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
