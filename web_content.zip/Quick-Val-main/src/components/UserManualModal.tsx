import React, { useState } from 'react';
import {
  BookOpen,
  Download,
  X,
  Check,
  Calculator,
  Layers,
  Shield,
  Sliders,
  Scale,
  ListOrdered,
} from 'lucide-react';
import { generateUserManualPdf } from '../utils/generateUserManualPdf';
import { MANDATORY_DISCLAIMER } from '../storage';

interface UserManualModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserManualModal: React.FC<UserManualModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [activeSection, setActiveSection] = useState('steps');

  if (!isOpen) return null;

  const handleDownloadPdf = () => {
    setDownloading(true);
    try {
      generateUserManualPdf();
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to generate PDF:', err);
    } finally {
      setDownloading(false);
    }
  };

  const sections = [
    { id: 'steps', title: '1. Step-by-Step Value Guide', icon: ListOrdered },
    { id: 'overview', title: '2. Overview & Philosophy', icon: BookOpen },
    { id: 'profiles', title: '3. Market Profiles', icon: Layers },
    { id: 'pipeline', title: '4. 9-Stage Valuation Engine', icon: Calculator },
    { id: 'params', title: '5. Parameters & Effects', icon: Sliders },
    { id: 'comps', title: '6. Comparables & Calibration', icon: Scale },
    { id: 'sample', title: '7. Verified Benchmark Sample', icon: Check },
    { id: 'disclaimer', title: '8. Legal Disclaimer', icon: Shield },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-neutral-900 text-sm sm:text-base">
                QuickVal User Manual & Engine Specification
              </h3>
              <p className="text-xs text-neutral-500">
                Official guide and reference documentation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadPdf}
              disabled={downloading}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
              title="Download formatted PDF Manual"
            >
              {downloadSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Downloaded PDF!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>Download PDF Manual</span>
                </>
              )}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content body with responsive layout */}
        <div className="flex-1 overflow-y-auto flex flex-col md:flex-row">
          {/* Sidebar Navigation */}
          <div className="w-full md:w-56 p-3 bg-neutral-50/70 border-b md:border-b-0 md:border-r border-neutral-200 flex md:flex-col gap-1 overflow-x-auto shrink-0 text-xs">
            <span className="hidden md:block text-[10px] font-semibold text-neutral-400 uppercase tracking-wider px-2 py-1">
              Table of Contents
            </span>
            {sections.map((s) => {
              const Icon = s.icon;
              const isActive = activeSection === s.id;
              return (
                <button
                  key={s.id}
                  onClick={() => {
                    setActiveSection(s.id);
                    document.getElementById(`manual-${s.id}`)?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`text-left px-2.5 py-1.5 rounded-lg font-medium flex items-center gap-2 whitespace-nowrap md:whitespace-normal transition-colors ${
                    isActive
                      ? 'bg-emerald-100/70 text-emerald-900 font-semibold'
                      : 'text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                  <span className="truncate">{s.title}</span>
                </button>
              );
            })}
          </div>

          {/* Main Manual Body */}
          <div className="flex-1 p-5 overflow-y-auto space-y-6 text-xs text-neutral-700 leading-relaxed print:p-0">
            {/* 1. Step-by-Step Value Calculation Guide */}
            <section id="manual-steps" className="space-y-3">
              <div className="flex items-center justify-between border-b pb-1">
                <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5">
                  <ListOrdered className="w-4 h-4 text-emerald-600" />
                  <span>Simple Step-by-Step Value Calculation Guide</span>
                </h4>
                <span className="text-[10px] uppercase tracking-wider font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  Quick Start
                </span>
              </div>
              <p className="text-neutral-600">
                Follow these 5 straightforward steps to calculate an accurate, defensible valuation estimate for any property:
              </p>

              <div className="space-y-2.5 pt-1">
                {/* Step 1 */}
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">
                      1
                    </span>
                    <strong className="text-neutral-900 text-xs">Choose or Create your Market Profile</strong>
                  </div>
                  <p className="text-[11px] text-neutral-600 pl-7">
                    Select your active location profile from the top dropdown (e.g. <em>"Sample: Rusape, Zimbabwe"</em> or your custom area). This loads the correct currency (US$, ZAR, GBP, etc.) and regional baseline rates (land rate, building rate, replacement cost rate).
                  </p>
                </div>

                {/* Step 2 */}
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">
                      2
                    </span>
                    <strong className="text-neutral-900 text-xs">Select Property Type & Enter Land Area</strong>
                  </div>
                  <p className="text-[11px] text-neutral-600 pl-7">
                    Tap the appropriate Property Type tab (<strong>Residential</strong>, <strong>Commercial</strong>, <strong>Industrial</strong>, or <strong>Vacant Land</strong>). Type the stand size in square meters (<code className="font-mono">sqm</code>) or square feet (<code className="font-mono">sqft</code>). For sectional title / apartments, land area is optional and defaults to 0.
                  </p>
                </div>

                {/* Step 3 */}
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">
                      3
                    </span>
                    <strong className="text-neutral-900 text-xs">Enter Structures & Measured Floor Areas</strong>
                  </div>
                  <p className="text-[11px] text-neutral-600 pl-7">
                    List each building on the property (e.g. <em>Main House: 126.97 sqm</em>, <em>Garage/Store: 62.17 sqm</em>). Tap <strong>"+ Add Structure"</strong> to add cottages, workshops, or staff quarters. You can optionally tap "Rate Override" to set a custom rate if a structure differs in quality.
                  </p>
                </div>

                {/* Step 4 */}
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">
                      4
                    </span>
                    <strong className="text-neutral-900 text-xs">Adjust Specific Market Factors & Multipliers</strong>
                  </div>
                  <p className="text-[11px] text-neutral-600 pl-7">
                    Fine-tune your property's specific physical and location attributes:
                    select the <strong>Location Zone</strong> (e.g. Castle Base vs. CBD), <strong>Finish Quality</strong> (Good vs. Basic), <strong>Maintenance Condition</strong>, and toggles (e.g. <em>External Works 20%</em>, <em>En-suite +2%</em>, <em>Non-freehold title -15%</em>).
                  </p>
                </div>

                {/* Step 5 */}
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">
                      5
                    </span>
                    <strong className="text-neutral-900 text-xs">Read Calculated Values & Math Breakdown</strong>
                  </div>
                  <p className="text-[11px] text-neutral-600 pl-7">
                    QuickVal computes live results as you type:
                    <br />
                    • <strong>Estimated Market Value:</strong> Primary realistic fair value with expected negotiation range (±10%).
                    <br />
                    • <strong>Forced Sale Value:</strong> Bank liquidation or distressed realization estimate (e.g. 75%).
                    <br />
                    • <strong>Gross Replacement Cost:</strong> Contractor reinstatement cost for insurance purposes.
                    <br />
                    • <strong>How We Got This:</strong> Expand the accordion at any time to verify the exact mathematical formulas and substitutions.
                  </p>
                </div>
              </div>

              {/* Exact Arithmetic Formula Reference */}
              <div className="mt-3 p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-200 space-y-2">
                <span className="font-bold text-emerald-950 text-xs block uppercase tracking-wider">
                  The Exact Mathematical Valuation Formulas
                </span>
                <div className="space-y-1.5 font-mono text-[11px] text-emerald-950">
                  <div className="p-1.5 bg-white rounded-lg border border-emerald-200">
                    <span className="text-emerald-700 font-semibold block text-[10px]">1. Land Value</span>
                    Land Area × Land Rate × ∏(Land Multipliers)
                  </div>
                  <div className="p-1.5 bg-white rounded-lg border border-emerald-200">
                    <span className="text-emerald-700 font-semibold block text-[10px]">2. Building Value</span>
                    ∑(Building Area × Building Rate) × ∏(Building Multipliers)
                  </div>
                  <div className="p-1.5 bg-white rounded-lg border border-emerald-200">
                    <span className="text-emerald-700 font-semibold block text-[10px]">3. Additions / External Works</span>
                    Building Value × ∑(Percentage Additions)
                  </div>
                  <div className="p-1.5 bg-white rounded-lg border border-emerald-200">
                    <span className="text-emerald-700 font-semibold block text-[10px]">4. Subtotal</span>
                    Land Value + Building Value + Additions
                  </div>
                  <div className="p-1.5 bg-white rounded-lg border border-emerald-200">
                    <span className="text-emerald-700 font-semibold block text-[10px]">5. Market Value</span>
                    [Subtotal × (1 + ∑Total % Adjustments)] + ∑Fixed Lump Sums → Round to Step
                  </div>
                  <div className="p-1.5 bg-white rounded-lg border border-emerald-200">
                    <span className="text-emerald-700 font-semibold block text-[10px]">6. Forced Sale Value</span>
                    Market Value × Forced Sale % (e.g. 75%) → Round to Step
                  </div>
                  <div className="p-1.5 bg-white rounded-lg border border-emerald-200">
                    <span className="text-emerald-700 font-semibold block text-[10px]">7. Gross Replacement Cost</span>
                    ∑(Building Area × Replacement Rate) × ∏(Replacement Multipliers) → Round to Step
                  </div>
                </div>
              </div>

              {/* Concrete Worked Walkthrough Example */}
              <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
                <span className="font-bold text-neutral-900 text-xs block">
                  Worked Calculation Example (Step-by-Step)
                </span>
                <p className="text-[11px] text-neutral-600">
                  Using a 1,887 sqm stand with 189.14 sqm buildings at $24.90/sqm land rate and $215/sqm building rate with 20% external works:
                </p>
                <div className="space-y-1 font-mono text-[11px] text-neutral-800 bg-white p-2.5 rounded-lg border border-neutral-200">
                  <div>• Land: 1,887 sqm × $24.90 × 1.00 = <strong>$46,986.30</strong> (rounds to <strong>$47,000</strong>)</div>
                  <div>• Buildings: (126.97 + 62.17) sqm × $215 × 1.00 = <strong>$40,665.10</strong></div>
                  <div>• External Works (20%): $40,665.10 × 0.20 = <strong>$8,133.02</strong></div>
                  <div>• Subtotal: $46,986.30 + $40,665.10 + $8,133.02 = <strong>$95,784.42</strong></div>
                  <div>• Market Value: $95,784.42 rounded to nearest 500 = <strong>$96,000</strong></div>
                  <div>• Forced Sale (75%): $96,000 × 0.75 = <strong>$72,000</strong></div>
                  <div>• Replacement: 189.14 sqm × $820 = $155,094.80 rounded to 500 = <strong>$155,000</strong></div>
                </div>
              </div>
            </section>

            {/* 2. Overview */}
            <section id="manual-overview" className="space-y-2">
              <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5 border-b pb-1">
                <BookOpen className="w-4 h-4 text-emerald-600" />
                <span>2. Overview & System Philosophy</span>
              </h4>
              <p>
                <strong>QuickVal</strong> is an agile, pocket property valuation estimation tool ("guesstimate") designed to work in <strong>any real estate market worldwide</strong>.
              </p>
              <p>
                Unlike rigid local apps, QuickVal holds no hardcoded assumptions about land values, construction costs, or regional terminology. All valuation formulas reside in a pure, deterministic engine (<code className="bg-neutral-100 px-1 py-0.5 rounded font-mono text-[11px]">src/engine.ts</code>) driven 100% by user-configurable JSON profiles.
              </p>
            </section>

            {/* 3. Market Profiles */}
            <section id="manual-profiles" className="space-y-2">
              <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5 border-b pb-1">
                <Layers className="w-4 h-4 text-emerald-600" />
                <span>3. Market Profiles</span>
              </h4>
              <p>
                A <strong>Market Profile</strong> encapsulates all assumptions for a specific town, suburb, or asset segment. Each profile stores:
              </p>
              <ul className="list-disc pl-5 space-y-1">
                <li><strong>Currency & Area Unit:</strong> User-defined currency code (US$, ZAR, GBP, EUR, $, etc.) and area metric (<code className="font-mono">sqm</code> or <code className="font-mono">sqft</code>).</li>
                <li><strong>Base Land Rate:</strong> Starting rate per area unit for undeveloped land.</li>
                <li><strong>Base Building Rate:</strong> Average rate per area unit applied to main dwelling structures.</li>
                <li><strong>Replacement Cost Rate:</strong> Insurance contractor rate to construct like-for-like as new.</li>
                <li><strong>Output Settings:</strong> Forced Sale % (default 75%), Value Range Width (default ±10%), and Rounding Step (default 500).</li>
                <li><strong>Parameters & Comparables:</strong> Dynamic factors and recent evidence sales.</li>
              </ul>
              <p>
                Profiles can be created, edited, duplicated, deleted, exported, and imported as standard JSON files under the <strong>Profiles</strong> tab.
              </p>
            </section>

            {/* 4. 9-Stage Valuation Engine */}
            <section id="manual-pipeline" className="space-y-3">
              <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5 border-b pb-1">
                <Calculator className="w-4 h-4 text-emerald-600" />
                <span>4. The 9-Stage Valuation Pipeline</span>
              </h4>
              <p>
                Calculations execute in an exact, deterministic pipeline. Every step is logged line-by-line in the "How We Got This" breakdown:
              </p>

              <div className="space-y-2">
                <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="font-semibold text-emerald-800 text-[11px]">1. Land Value</div>
                  <div className="font-mono text-[11px] text-neutral-800">
                    Land Area × Land Rate × ∏(Land Multipliers)
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="font-semibold text-emerald-800 text-[11px]">2. Building Value</div>
                  <div className="font-mono text-[11px] text-neutral-800">
                    ∑(Building Area × Building Rate) × ∏(Building Multipliers)
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="font-semibold text-emerald-800 text-[11px]">3. Additions to Building Value (External Works)</div>
                  <div className="font-mono text-[11px] text-neutral-800">
                    Building Value × ∑(Building % Parameters)
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="font-semibold text-emerald-800 text-[11px]">4. Subtotal</div>
                  <div className="font-mono text-[11px] text-neutral-800">
                    Land Value + Building Value + Additions
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="font-semibold text-emerald-800 text-[11px]">5. Market Value (Unrounded)</div>
                  <div className="font-mono text-[11px] text-neutral-800">
                    Subtotal × (1 + ∑Total % Adjustments) + ∑Fixed Amounts
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="font-semibold text-emerald-800 text-[11px]">6. Forced Sale Value</div>
                  <div className="font-mono text-[11px] text-neutral-800">
                    Market Value × Forced Sale % (e.g. 75%)
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="font-semibold text-emerald-800 text-[11px]">7. Gross Replacement Cost</div>
                  <div className="font-mono text-[11px] text-neutral-800">
                    ∑(Building Area × Replacement Rate) × ∏(Replacement Multipliers)
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="font-semibold text-emerald-800 text-[11px]">8. Estimated Range</div>
                  <div className="font-mono text-[11px] text-neutral-800">
                    Market Value × (1 - Range %) to Market Value × (1 + Range %)
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="font-semibold text-emerald-800 text-[11px]">9. Output Rounding</div>
                  <div className="font-mono text-[11px] text-neutral-800">
                    Round to nearest step (e.g. 500)
                  </div>
                </div>
              </div>
            </section>

            {/* 5. Parameters */}
            <section id="manual-params" className="space-y-2">
              <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5 border-b pb-1">
                <Sliders className="w-4 h-4 text-emerald-600" />
                <span>5. Parameter Types & Effects</span>
              </h4>
              <p>
                Parameters enable custom property adjustments without coding.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <div className="p-2 bg-neutral-50 rounded-lg border">
                  <strong>Input Types:</strong>
                  <ul className="list-disc pl-4 mt-0.5 space-y-0.5 text-[11px]">
                    <li>Dropdown (choice options)</li>
                    <li>Toggle (Yes/No with on/off values)</li>
                    <li>Percentage Slider</li>
                    <li>Numeric Stepper</li>
                  </ul>
                </div>

                <div className="p-2 bg-neutral-50 rounded-lg border">
                  <strong>Effect Types:</strong>
                  <ul className="list-disc pl-4 mt-0.5 space-y-0.5 text-[11px]">
                    <li>Land Multiplier</li>
                    <li>Building Multiplier</li>
                    <li>Total Percentage (±%)</li>
                    <li>Fixed Amount (+$5,000)</li>
                    <li>Building % (External works)</li>
                    <li>Replacement Multiplier</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* 6. Comparables & Calibration */}
            <section id="manual-comps" className="space-y-2">
              <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5 border-b pb-1">
                <Scale className="w-4 h-4 text-emerald-600" />
                <span>6. Comparables & Calibration Tools</span>
              </h4>
              <p>
                <strong>Comparables Evidence:</strong> Add verified past sales (price, building area, land area, date). With 2+ sales, QuickVal calculates the median unit rate and an implied subject value. Deviations &gt; 15% are flagged automatically.
              </p>
              <p>
                <strong>Calibration Engine:</strong> Enter property specs and a known valuation. QuickVal isolates the land rate, solves the implied building base rate from the remainder, and lets you update your profile with 1 click.
              </p>
            </section>

            {/* 7. Verified Rusape Benchmark */}
            <section id="manual-sample" className="space-y-2">
              <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5 border-b pb-1">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>7. Verified Sample Benchmark: Rusape, Zimbabwe</span>
              </h4>
              <div className="p-3 bg-neutral-50 rounded-xl border font-mono text-[11px] space-y-1">
                <div>Land Area: <strong>1,887 sqm</strong> @ $24.9/sqm</div>
                <div>Buildings: <strong>126.97 sqm</strong> (house) + <strong>62.17 sqm</strong> (garage) = <strong>189.14 sqm</strong> @ $215/sqm</div>
                <div>Factors: Castle Base (1.00x), Good Finish (1.00x), Good Condition (1.00x), External Works (20%)</div>
                <div className="pt-1 border-t text-emerald-800 font-bold">
                  Outputs: Land: US$47,000 | Market: US$96,000 | Forced Sale: US$72,000 | Replacement: US$155,000
                </div>
              </div>
            </section>

            {/* 8. Disclaimer */}
            <section id="manual-disclaimer" className="space-y-2">
              <h4 className="text-sm font-bold text-red-700 flex items-center gap-1.5 border-b pb-1">
                <Shield className="w-4 h-4 text-red-600" />
                <span>8. Statutory Legal Disclaimer</span>
              </h4>
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-[11px] text-red-900 italic leading-relaxed">
                "{MANDATORY_DISCLAIMER}"
              </div>
            </section>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 bg-neutral-50 flex items-center justify-between">
          <span className="text-[11px] text-neutral-500">
            QuickVal Reference Manual v1.0
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadPdf}
              disabled={downloading}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF Manual</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-600 hover:text-neutral-900 rounded-lg hover:bg-neutral-200/60"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
