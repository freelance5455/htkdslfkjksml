import React, { useState } from 'react';
import {
  Bookmark,
  Search,
  Trash2,
  Scale,
  Calendar,
  Share2,
  FileDown,
  FileUp,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { SavedEstimate } from '../types';
import { formatCurrency, formatArea } from '../engine';
import { CompareEstimatesModal } from './CompareEstimatesModal';

interface SavedTabProps {
  estimates: SavedEstimate[];
  onDeleteEstimate: (id: string) => void;
  onLoadEstimate: (estimate: SavedEstimate) => void;
  onExportJson: () => void;
  onImportJson: () => void;
}

export const SavedTab: React.FC<SavedTabProps> = ({
  estimates,
  onDeleteEstimate,
  onLoadEstimate,
  onExportJson,
  onImportJson,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedForComparison, setSelectedForComparison] = useState<string[]>([]);
  const [compareModalOpen, setCompareModalOpen] = useState(false);

  const filteredEstimates = estimates.filter((est) => {
    const q = searchQuery.toLowerCase();
    const titleMatch = est.title.toLowerCase().includes(q);
    const profileMatch = est.profileSnapshot.name.toLowerCase().includes(q);
    const notesMatch = est.inputs.notes?.toLowerCase().includes(q);
    return titleMatch || profileMatch || notesMatch;
  });

  const toggleSelectForCompare = (id: string) => {
    if (selectedForComparison.includes(id)) {
      setSelectedForComparison(selectedForComparison.filter((item) => item !== id));
    } else {
      if (selectedForComparison.length >= 2) {
        // Replace second selection
        setSelectedForComparison([selectedForComparison[0], id]);
      } else {
        setSelectedForComparison([...selectedForComparison, id]);
      }
    }
  };

  const selectedEstimateA = estimates.find((e) => e.id === selectedForComparison[0]);
  const selectedEstimateB = estimates.find((e) => e.id === selectedForComparison[1]);

  return (
    <div className="space-y-4 pb-20 max-w-2xl mx-auto px-3 sm:px-4 pt-3">
      {/* Header and Search */}
      <div className="bg-white rounded-2xl border border-neutral-200/90 p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-neutral-900">Saved Valuations</h2>
            <p className="text-xs text-neutral-500">
              Historical estimates with frozen profile rate snapshots
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={onExportJson}
              className="p-2 text-neutral-600 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors"
              title="Export saved estimates JSON"
            >
              <FileDown className="w-4 h-4" />
            </button>
            <button
              onClick={onImportJson}
              className="p-2 text-neutral-600 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors"
              title="Import estimates JSON"
            >
              <FileUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search bar */}
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, location, profile, or notes..."
            className="w-full text-xs p-2.5 pl-9 bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-3 pointer-events-none" />
        </div>
      </div>

      {/* Comparison floating banner when 2 selected */}
      {selectedForComparison.length === 2 && selectedEstimateA && selectedEstimateB && (
        <div className="bg-emerald-900 text-white rounded-2xl p-3.5 shadow-lg flex items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="text-xs">
              <span className="font-semibold block">2 Estimates Ready to Compare</span>
              <span className="text-[11px] text-emerald-200 truncate max-w-[200px] block">
                {selectedEstimateA.title} vs {selectedEstimateB.title}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedForComparison([])}
              className="px-2 py-1 text-xs text-emerald-300 hover:text-white"
            >
              Clear
            </button>
            <button
              onClick={() => setCompareModalOpen(true)}
              className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1"
            >
              <span>Compare</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* List */}
      {filteredEstimates.length === 0 ? (
        <div className="bg-white rounded-2xl border border-neutral-200/90 p-8 text-center space-y-3 shadow-xs">
          <div className="w-12 h-12 rounded-full bg-neutral-100 text-neutral-400 flex items-center justify-center mx-auto">
            <Bookmark className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-semibold text-neutral-800">No saved estimates found</h3>
            <p className="text-xs text-neutral-500 max-w-xs mx-auto">
              Run an estimate on the first tab and tap "Save" to build your portfolio of saved property valuations.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredEstimates.map((estimate) => {
            const isSelected = selectedForComparison.includes(estimate.id);
            const totalBldArea = (estimate.inputs.buildings || []).reduce(
              (sum, b) => sum + (b.area || 0),
              0
            );

            return (
              <div
                key={estimate.id}
                className={`bg-white rounded-2xl border p-4 shadow-xs transition-all space-y-3 ${
                  isSelected ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-neutral-200/90'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-0.5 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-neutral-900 text-sm">
                        {estimate.title}
                      </h3>
                      <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-neutral-100 text-neutral-600 font-mono">
                        {estimate.profileSnapshot.name}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-neutral-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(estimate.createdAt).toLocaleDateString()}
                      </span>
                      <span>•</span>
                      <span>
                        {formatArea(estimate.inputs.landArea, estimate.profileSnapshot.areaUnit)} land
                      </span>
                      <span>•</span>
                      <span>
                        {formatArea(totalBldArea, estimate.profileSnapshot.areaUnit)} bld
                      </span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-base font-extrabold font-mono text-emerald-800 block">
                      {formatCurrency(
                        estimate.result.marketValue,
                        estimate.profileSnapshot.currency
                      )}
                    </span>
                    <span className="text-[10px] text-neutral-500 font-mono">
                      Range: {formatCurrency(estimate.result.rangeLow, estimate.profileSnapshot.currency)} – {formatCurrency(estimate.result.rangeHigh, estimate.profileSnapshot.currency)}
                    </span>
                  </div>
                </div>

                {estimate.inputs.notes && (
                  <p className="text-xs text-neutral-600 bg-neutral-50 p-2.5 rounded-xl border border-neutral-100 italic">
                    "{estimate.inputs.notes}"
                  </p>
                )}

                {/* Card actions */}
                <div className="flex items-center justify-between pt-2 border-t border-neutral-100 text-xs">
                  <label className="flex items-center gap-1.5 text-neutral-600 cursor-pointer hover:text-neutral-900 select-none">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleSelectForCompare(estimate.id)}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="text-[11px] font-medium">Select to Compare</span>
                  </label>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onLoadEstimate(estimate)}
                      className="px-3 py-1.5 rounded-lg bg-neutral-100 hover:bg-emerald-50 text-neutral-700 hover:text-emerald-800 font-semibold text-xs transition-colors"
                    >
                      Load into Form
                    </button>
                    <button
                      onClick={() => onDeleteEstimate(estimate.id)}
                      className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                      title="Delete estimate"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Comparison Modal */}
      {selectedEstimateA && selectedEstimateB && (
        <CompareEstimatesModal
          isOpen={compareModalOpen}
          onClose={() => setCompareModalOpen(false)}
          estimateA={selectedEstimateA}
          estimateB={selectedEstimateB}
        />
      )}
    </div>
  );
};
