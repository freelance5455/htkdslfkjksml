import React from 'react';
import { Home, Plus, ChevronDown, BookOpen } from 'lucide-react';
import { MarketProfile } from '../types';

interface NavbarProps {
  profiles: MarketProfile[];
  activeProfile: MarketProfile;
  onSelectProfile: (id: string) => void;
  onOpenUserManual: () => void;
  onNewEstimate: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  profiles,
  activeProfile,
  onSelectProfile,
  onOpenUserManual,
  onNewEstimate,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200/80 shadow-2xs">
      <div className="max-w-2xl mx-auto px-4 h-14 flex items-center justify-between gap-2">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-700 to-emerald-500 text-white flex items-center justify-center shadow-xs">
            <Home className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-base tracking-tight text-neutral-900 block leading-tight">
              QuickVal
            </span>
            <span className="text-[10px] text-emerald-700 font-semibold tracking-wide uppercase block -mt-0.5">
              Pocket Calculator
            </span>
          </div>
        </div>

        {/* Profile Selector & Actions */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <select
              value={activeProfile.id}
              onChange={(e) => onSelectProfile(e.target.value)}
              className="appearance-none bg-neutral-100 hover:bg-neutral-200/80 border border-neutral-200 text-neutral-800 text-xs font-semibold py-1.5 pl-2.5 pr-7 rounded-lg cursor-pointer transition-colors max-w-[140px] sm:max-w-[200px] truncate"
              title="Active Market Profile"
            >
              {profiles.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-neutral-500 absolute right-2 top-2.5 pointer-events-none" />
          </div>

          <button
            onClick={onOpenUserManual}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100/80 text-emerald-900 rounded-lg text-xs font-semibold border border-emerald-300 transition-colors shadow-2xs"
            title="Open User Manual & Value Calculation Guide"
          >
            <BookOpen className="w-3.5 h-3.5 text-emerald-700" />
            <span>Manual & Guide</span>
          </button>

          <button
            onClick={onNewEstimate}
            className="p-1.5 rounded-lg text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 transition-colors"
            title="Reset to New Estimate"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
