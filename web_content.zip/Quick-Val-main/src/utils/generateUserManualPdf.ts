/**
 * QuickVal PDF User Manual Generator
 * Generates a clean, multi-page, formatted PDF manual using jsPDF.
 */

import { jsPDF } from 'jspdf';
import { MANDATORY_DISCLAIMER } from '../storage';

export function generateUserManualPdf(): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 18;
  const contentWidth = pageWidth - margin * 2;
  let y = margin;

  // Colors
  const primaryColor = [5, 150, 105]; // #059669 Emerald
  const darkColor = [24, 24, 27]; // #18181b Dark Slate
  const grayColor = [113, 113, 122]; // #71717a Muted Gray
  const lightBg = [244, 244, 245]; // #f4f4f5

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - margin - 12) {
      addFooter();
      doc.addPage();
      y = margin + 8;
      addHeader();
    }
  };

  const addHeader = () => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(grayColor[0], grayColor[1], grayColor[2]);
    doc.text('QuickVal™ — Official User Manual & Valuation Engine Guide', margin, margin);
    doc.setDrawColor(229, 231, 235);
    doc.line(margin, margin + 2, pageWidth - margin, margin + 2);
    y = margin + 8;
  };

  const addFooter = () => {
    const pageNum = doc.getNumberOfPages();
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(grayColor[0], grayColor[1], grayColor[2]);
    doc.setDrawColor(229, 231, 235);
    doc.line(margin, pageHeight - margin + 2, pageWidth - margin, pageHeight - margin + 2);
    doc.text('QuickVal Automated Property Valuation System', margin, pageHeight - margin + 7);
    doc.text(`Page ${pageNum}`, pageWidth - margin, pageHeight - margin + 7, { align: 'right' });
  };

  // --------------------------------------------------------------------------
  // COVER / TITLE SECTION
  // --------------------------------------------------------------------------
  // Emerald top banner
  doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.rect(0, 0, pageWidth, 42, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(24);
  doc.setTextColor(255, 255, 255);
  doc.text('QuickVal', margin, 20);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(209, 250, 229);
  doc.text('Comprehensive How-To-Use Manual & Valuation Engine Specification', margin, 28);
  doc.setFontSize(8);
  doc.text('Universal Multi-Market Real Estate Estimator | Reference Manual v1.0', margin, 34);

  y = 52;

  // Overview box
  doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
  doc.roundedRect(margin, y, contentWidth, 22, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('EXECUTIVE OVERVIEW', margin + 4, y + 6);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
  doc.text(
    'QuickVal is a fast, transparent property valuation "guesstimate" tool built to adapt to ANY global real estate market. Driven 100% by pure JSON configurations (engine.ts), users can define base land/building rates, custom adjustment parameters, multi-building structures, and cross-check against sales evidence.',
    margin + 4,
    y + 11,
    { maxWidth: contentWidth - 8, lineHeightFactor: 1.3 }
  );

  y += 28;

  // --------------------------------------------------------------------------
  // SIMPLE STEP-BY-STEP CALCULATION GUIDE
  // --------------------------------------------------------------------------
  doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
  doc.roundedRect(margin, y, contentWidth, 8, 1.5, 1.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('QUICK START: 5-STEP VALUE CALCULATION GUIDE', margin + 3, y + 5.5);
  y += 12;

  const addStepCard = (num: string, stepTitle: string, action: string, proTip: string) => {
    checkPageBreak(17);
    doc.setFillColor(255, 255, 255);
    doc.setDrawColor(209, 213, 219);
    doc.setLineWidth(0.3);
    doc.roundedRect(margin, y, contentWidth, 15, 1.5, 1.5, 'FD');

    // Number badge
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.roundedRect(margin + 2.5, y + 2.5, 6, 6, 1, 1, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text(num, margin + 4.5, y + 6.8, { align: 'center' });

    // Step Title & Action
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
    doc.text(stepTitle, margin + 11, y + 5.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(grayColor[0], grayColor[1], grayColor[2]);
    doc.text(action, margin + 11, y + 9.5, { maxWidth: contentWidth - 14 });

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(`Tip: ${proTip}`, margin + 11, y + 13, { maxWidth: contentWidth - 14 });

    y += 17.5;
  };

  addStepCard(
    '1',
    'Choose or Create Market Profile',
    'Select the target market from the top bar (e.g. "Sample: Rusape, Zimbabwe" or custom profile) to load base rates and currency.',
    'You can edit base rates or create new profiles in the "Profiles" tab anytime.'
  );

  addStepCard(
    '2',
    'Select Property Type & Enter Land Size',
    'Select Residential, Commercial, Vacant Land, or Sectional Title, then enter the stand area in square meters or square feet.',
    'For Sectional Title flats/apartments, land area is optional and defaults to 0.'
  );

  addStepCard(
    '3',
    'List Buildings & Floor Dimensions',
    'Enter each structure on the stand (e.g. Main House: 126.97 sqm, Garage/Store: 62.17 sqm). Tap "+ Add Structure" for more.',
    'Individual buildings can have custom rate overrides if construction quality differs.'
  );

  addStepCard(
    '4',
    'Set Property Factors & Adjustments',
    'Adjust location zone, finish quality, physical condition, and toggles (e.g. external works 20%, en-suite +2%, non-freehold -15%).',
    'These parameters apply sequentially in list order to land, buildings, or total value.'
  );

  addStepCard(
    '5',
    'Read Live Values & Calculation Breakdown',
    'Immediately view Estimated Market Value, Range (±10%), Forced Sale Value, and Gross Replacement Cost.',
    'Tap "How We Got This" to inspect the line-by-line mathematical substitution log.'
  );

  y += 4;

  // Helper for Section Titles
  const addSectionTitle = (title: string, subtitle?: string) => {
    checkPageBreak(16);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(title, margin, y);
    y += 5;
    if (subtitle) {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8.5);
      doc.setTextColor(grayColor[0], grayColor[1], grayColor[2]);
      doc.text(subtitle, margin, y);
      y += 5;
    }
    doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setLineWidth(0.5);
    doc.line(margin, y, margin + 35, y);
    y += 4;
  };

  const addParagraph = (text: string, spaceAfter = 3) => {
    checkPageBreak(12);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
    const lines = doc.splitTextToSize(text, contentWidth);
    doc.text(lines, margin, y);
    y += lines.length * 4.2 + spaceAfter;
  };

  const addBullet = (title: string, desc: string) => {
    checkPageBreak(10);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
    doc.text(`• ${title}:`, margin + 2, y);
    const titleWidth = doc.getTextWidth(`• ${title}: `);
    doc.setFont('helvetica', 'normal');
    const remainingWidth = contentWidth - titleWidth - 2;
    const descLines = doc.splitTextToSize(desc, remainingWidth);
    doc.text(descLines, margin + 2 + titleWidth, y);
    y += descLines.length * 4 + 2;
  };

  const addFormulaBox = (stepNum: string, title: string, formula: string, explanation: string) => {
    checkPageBreak(20);
    doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
    doc.setDrawColor(229, 231, 235);
    doc.roundedRect(margin, y, contentWidth, 18, 1.5, 1.5, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(`${stepNum}. ${title}`, margin + 3, y + 4.5);

    doc.setFont('courier', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
    doc.text(formula, margin + 3, y + 9.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(grayColor[0], grayColor[1], grayColor[2]);
    doc.text(explanation, margin + 3, y + 14.5, { maxWidth: contentWidth - 6 });

    y += 21;
  };

  // --------------------------------------------------------------------------
  // SECTION 1: CORE CONCEPTS & MARKET PROFILES
  // --------------------------------------------------------------------------
  addSectionTitle('1. Market Profiles & Core Assumptions', 'Configurable assumption sets for distinct towns and sub-markets');

  addParagraph(
    'A Market Profile represents the valuation baseline for a specific geographical area or property segment (e.g., "Harare North", "Lusaka Residential", "Cape Town Sectional Title"). Profiles are completely decoupled from code.'
  );

  addBullet('Currency & Area Unit', 'Choose any currency symbol (US$, ZAR, GBP, EUR, etc.) and measurement unit (sqm or sqft).');
  addBullet('Base Land Rate', 'The baseline rate per area unit for undeveloped land in an average location.');
  addBullet('Base Building Rate', 'The average market rate per area unit applied to main dwelling structures.');
  addBullet('Replacement Cost Rate', 'The gross contractor cost per area unit to rebuild structures as new for insurance/replacement purposes.');
  addBullet('Output Settings', 'Forced Sale % (default 75%), Valuation Range Width ±% (default 10%), and Rounding Step (e.g. 500).');
  addBullet('Profile Management', 'Create, edit, duplicate, delete, and import/export profiles via JSON files under the "Profiles" tab.');

  // --------------------------------------------------------------------------
  // SECTION 2: THE 9-STAGE CALCULATION PIPELINE
  // --------------------------------------------------------------------------
  addSectionTitle('2. The 9-Stage Valuation Pipeline (engine.ts)', 'Sequential, deterministic mathematical calculation log');

  addParagraph(
    'QuickVal executes calculations in a strictly ordered 9-stage sequence. All steps are logged transparently and viewable inside the expandable "How We Got This" calculation drawer:'
  );

  addFormulaBox(
    'Step 1',
    'Land Value',
    'Land Area × Land Rate × ∏(Land Multipliers)',
    'Calculates physical land value based on land area and neighborhood/zoning multipliers.'
  );

  addFormulaBox(
    'Step 2',
    'Building Value',
    '∑(Building Area × Building Rate) × ∏(Building Multipliers)',
    'Sums all structures (house, cottage, garage) and applies condition or finish multipliers.'
  );

  addFormulaBox(
    'Step 3',
    'Additions to Building Value',
    'Building Value × ∑(Building % Parameters)',
    'Calculates external works, driveways, perimeter walls, and outdoor improvements.'
  );

  addFormulaBox(
    'Step 4',
    'Subtotal',
    'Land Value + Building Value + Additions',
    'Combined physical property asset base before overall market adjustments.'
  );

  addFormulaBox(
    'Step 5',
    'Market Value (Unrounded)',
    'Subtotal × (1 + ∑Total % Adjustments) + ∑Fixed Amounts',
    'Applies global factors (e.g. +2% for en-suite, -15% for non-freehold title, or fixed sums).'
  );

  addFormulaBox(
    'Step 6',
    'Forced Sale Value',
    'Market Value × Forced Sale % (e.g. 75%)',
    'Liquidation estimate in rapid, bank-mandated, or distressed market situations.'
  );

  addFormulaBox(
    'Step 7',
    'Gross Replacement Cost',
    '∑(Building Area × Replacement Rate) × ∏(Replacement Multipliers)',
    'Estimated total insurance reinstatement cost to construct like-for-like as new.'
  );

  addFormulaBox(
    'Step 8',
    'Valuation Range',
    'Market Value × (1 - Range %) to Market Value × (1 + Range %)',
    'Reflects realistic market negotiation bounds and statistical variation (default ±10%).'
  );

  addFormulaBox(
    'Step 9',
    'Output Rounding',
    'Math.round(Value / RoundingStep) × RoundingStep',
    'Rounds all final figures to the profile rounding step (default 500) to prevent false precision.'
  );

  // --------------------------------------------------------------------------
  // SECTION 3: PARAMETERS & ADJUSTMENTS
  // --------------------------------------------------------------------------
  addSectionTitle('3. Parameter Builder & Adjustment Types', 'Custom factor adjustments created without code changes');

  addParagraph(
    'Users can add unlimited custom parameters to any profile. Each parameter has an input type and an effect type:'
  );

  addBullet('Dropdown', 'User selects from a list of options (e.g. Castle Base 1.00x, Jacaranda 1.05x, CBD 1.10x).');
  addBullet('Toggle', 'Binary switch with custom values for ON and OFF (e.g. En-suite present +2%, Non-freehold -15%).');
  addBullet('Slider', 'Continuous range slider (e.g. External works from 0% to 50% of building value).');
  addBullet('Number', 'Positive numeric stepper for counts or ratings.');

  y += 2;
  addParagraph('Supported Effect Types:');
  addBullet('Land Multiplier', 'Scales the land value directly (e.g. location zone or corner stand advantage).');
  addBullet('Building Multiplier', 'Scales building values (e.g. condition: Poor 0.70x, Standard 0.90x, Good 1.00x).');
  addBullet('Total Percentage (±%)', 'Percentage adjustment applied to the entire subtotal.');
  addBullet('Fixed Amount', 'Lump sum added or subtracted in the profile currency (e.g. +$5,000 for borehole).');
  addBullet('Building % (Additions)', 'Percentage of building value added as improvements (e.g. 20% external works).');
  addBullet('Replacement Multiplier', 'Multiplier on replacement cost only.');
  addBullet('Building & Replacement', 'Simultaneously affects both building value and replacement cost.');

  // --------------------------------------------------------------------------
  // SECTION 4: COMPARABLES & CALIBRATION TOOLS
  // --------------------------------------------------------------------------
  addSectionTitle('4. Comparables Evidence & Calibration Tool', 'Validating rates against market sales and professional valuations');

  addBullet(
    'Comparables Cross-Check',
    'Record recent market sales (price, building area, land area, date). When at least 2 sales exist, QuickVal computes the median price per area unit and derives an implied subject value. Deviations greater than 15% are flagged automatically.'
  );

  addBullet(
    'Calibrate to Known Value',
    'Enter a property’s specifications alongside its known professional valuation. QuickVal mathematically isolates the land rate from the land value, then reverse-engineers the implied building rate and forced sale ratio. Supports multi-property sample averaging with one-click rate application.'
  );

  // --------------------------------------------------------------------------
  // SECTION 5: MATHEMATICAL FORMULAS & WORKED WALKTHROUGH
  // --------------------------------------------------------------------------
  addSectionTitle('5. Mathematical Formulas & Worked Calculation Walkthrough', 'Line-by-line arithmetic engine verification');

  addBullet(
    'Land Value Formula',
    'Land Area × Land Rate × Product of Land Multipliers. Example: 1,887 sqm × $24.90/sqm × 1.00 = $46,986.30 (rounds to $47,000).'
  );

  addBullet(
    'Building Value Formula',
    'Sum of (Each Building Area × Building Rate) × Product of Building Multipliers. Example: (126.97 + 62.17) sqm × $215/sqm × 1.00 = $40,665.10.'
  );

  addBullet(
    'External Works / Additions',
    'Building Value × Sum of % Additions. Example: $40,665.10 × 20% = $8,133.02.'
  );

  addBullet(
    'Subtotal & Final Market Value',
    'Subtotal = Land + Building + Additions = $95,784.42. Market Value applies % adjustments and lump sums, rounded to step (500) = $96,000.'
  );

  addBullet(
    'Forced Sale & Replacement Cost',
    'Forced Sale = Market Value × 75% = $72,000. Replacement Cost = Total Building Area × Replacement Rate ($820) = $155,094.80 (rounds to $155,000).'
  );

  // --------------------------------------------------------------------------
  // SECTION 6: SAMPLE PRESET VERIFICATION BENCHMARK
  // --------------------------------------------------------------------------
  addSectionTitle('6. Verified Sample Benchmark: Rusape, Zimbabwe', 'Built-in unit test verification');

  addParagraph(
    'QuickVal ships with an optional, verified reference profile: "Sample: Rusape, Zimbabwe (US$)".'
  );
  addBullet('Rates', 'Land Rate: $24.9/sqm | Building Rate: $215/sqm | Replacement: $820/sqm | Forced Sale: 75% | Rounding: 500.');
  addBullet('Sample Property', 'Land: 1,887 sqm | Main House: 126.97 sqm | Garage/Store: 62.17 sqm (Total: 189.14 sqm).');
  addBullet('Parameters', 'Castle Base (1.00x), Good Finish (1.00x), Good Condition (1.00x), External Works (20%).');
  addBullet('Verified Outputs', 'Land: US$47,000 | Market Value: US$96,000 | Forced Sale: US$72,000 | Replacement Cost: US$155,000.');
  addParagraph('Run the automated unit test anytime via the "Verify Sample" button in Settings.');

  // --------------------------------------------------------------------------
  // SECTION 7: STATUTORY DISCLAIMER
  // --------------------------------------------------------------------------
  checkPageBreak(30);
  doc.setFillColor(254, 242, 242); // Red/amber light
  doc.setDrawColor(252, 165, 165);
  doc.roundedRect(margin, y, contentWidth, 26, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(185, 28, 28);
  doc.text('MANDATORY STATUTORY DISCLAIMER (NON-NEGOTIABLE)', margin + 3, y + 5);

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.setTextColor(127, 29, 29);
  doc.text(
    `"${MANDATORY_DISCLAIMER}"`,
    margin + 3,
    y + 10,
    { maxWidth: contentWidth - 6, lineHeightFactor: 1.3 }
  );

  addFooter();

  // Save the PDF
  doc.save('QuickVal_User_Manual.pdf');
}
