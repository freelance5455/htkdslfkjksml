/**
 * QuickVal Backend Express Server
 * Serves Vite middleware in development or static assets in production.
 * Handles server-side Gemini API calls via @google/genai SDK with model gemini-2.5-flash.
 */

import express, { Request, Response } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Allow base64 payload up to 25MB for document/photo uploads
app.use(express.json({ limit: '25mb' }));

// Initialize GoogleGenAI SDK on server side
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

/**
 * Health check endpoint
 */
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    model: 'gemini-2.5-flash',
  });
});

/**
 * Feature A: Fill from Valuation Report
 * Parses uploaded PDF or photo of valuation report using Gemini 2.5 Flash
 */
app.post('/api/gemini/parse-report', async (req: Request, res: Response) => {
  try {
    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API key is not configured in the server environment.',
      });
    }

    const { fileBase64, mimeType, currentProfile } = req.body;

    if (!fileBase64 || !mimeType) {
      return res.status(400).json({ error: 'fileBase64 and mimeType are required' });
    }

    const promptText = `
You are an expert real estate valuer assistant. Analyze this uploaded property valuation report or inspection document.
Extract all explicit factual parameters accurately.
CRITICAL INSTRUCTION:
- Extract ONLY what is explicitly stated in the document.
- Leave numeric fields as 0 or null if NOT explicitly stated in the report. NEVER guess, estimate, or hallucinate missing figures.
- Extract any notable property factors (e.g. solar backup, borehole, security wall, pool, title type, zoning, finish condition) that could serve as valuation parameters in QuickVal.
- Current active profile currency is: ${currentProfile?.currency || 'US$'}.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              inlineData: {
                mimeType,
                data: fileBase64,
              },
            },
            {
              text: promptText,
            },
          ],
        },
      ],
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            propertyTitle: { type: Type.STRING, description: 'Address or property designation' },
            location: { type: Type.STRING, description: 'Suburb, city, or district' },
            propertyType: { type: Type.STRING, description: 'Residential, Commercial, Industrial, etc.' },
            landArea: { type: Type.NUMBER, description: 'Land or stand area in square meters or feet' },
            buildings: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: 'Structure name e.g. Main House, Cottage, Garage' },
                  area: { type: Type.NUMBER, description: 'Gross external or internal building area' },
                },
                required: ['name', 'area'],
              },
            },
            condition: { type: Type.STRING, description: 'Observed maintenance condition (e.g. Good, Fair, Poor)' },
            finishes: { type: Type.STRING, description: 'Quality of finishes (e.g. Standard, Luxury, Basic)' },
            titleType: { type: Type.STRING, description: 'Title deed, cession, leasehold, sectional title' },
            statedMarketValue: { type: Type.NUMBER, description: 'Stated open market valuation' },
            statedLandValue: { type: Type.NUMBER, description: 'Stated land value component if specified' },
            statedForcedSaleValue: { type: Type.NUMBER, description: 'Stated forced sale or liquidation value' },
            statedReplacementCost: { type: Type.NUMBER, description: 'Stated gross replacement/insurance cost' },
            otherNotableFactors: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  label: { type: Type.STRING, description: 'Feature name e.g. Borehole, Solar System, Electric Gate' },
                  observedValue: { type: Type.STRING, description: 'Details or condition mentioned' },
                  suggestedEffect: { type: Type.STRING, description: 'Suggested QuickVal adjustment type' },
                },
                required: ['label', 'observedValue'],
              },
            },
            rawNotes: { type: Type.STRING, description: 'Brief factual summary of key valuer comments' },
          },
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ data: parsed });
  } catch (err: any) {
    console.error('Error in /api/gemini/parse-report:', err);
    return res.status(500).json({
      error: err.message || 'Failed to extract valuation report data with Gemini.',
    });
  }
});

/**
 * Feature B: Suggest Parameters
 * User describes a market or property type; Gemini proposes sensible parameters.
 */
app.post('/api/gemini/suggest-parameters', async (req: Request, res: Response) => {
  try {
    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API key is not configured in the server environment.',
      });
    }

    const { marketDescription, propertyType, currency } = req.body;

    if (!marketDescription) {
      return res.status(400).json({ error: 'marketDescription is required' });
    }

    const promptText = `
You are a senior real estate appraisal consultant configuring adjustment parameters for a valuation engine called QuickVal.
The user describes this market context:
"${marketDescription}"
Target Property Type: "${propertyType || 'All'}"
Currency: "${currency || 'US$'}"

Propose 4 to 6 sensible, realistic parameters that are most impactful for this specific market.
Rules:
- Supported inputType values: "dropdown", "toggle", "slider", "number".
- Supported effectType values:
  - "land_multiplier" (e.g. 0.9 to 1.3 multiplier on land)
  - "building_multiplier" (e.g. 0.7 to 1.15 multiplier on building)
  - "total_percentage" (e.g. +0.05 for +5% or -0.15 for -15% on total value)
  - "fixed_amount" (fixed value addition/subtraction in local currency)
  - "building_percentage" (e.g. 0.15 for 15% of building value for external works/paving)
  - "replacement_multiplier" (multiplier on replacement cost)
  - "building_and_replacement_multiplier" (affects both building value and replacement cost)
- Always provide clear labels, starting default values, and sensible options/ranges.
- All numbers must be sensible realistic defaults.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              label: { type: Type.STRING, description: 'Parameter display label' },
              description: { type: Type.STRING, description: 'Why this factor matters in this market' },
              inputType: {
                type: Type.STRING,
                description: 'dropdown | toggle | slider | number',
              },
              effectType: {
                type: Type.STRING,
                description: 'land_multiplier | building_multiplier | total_percentage | fixed_amount | building_percentage | replacement_multiplier | building_and_replacement_multiplier',
              },
              defaultValue: { type: Type.NUMBER, description: 'Starting default value' },
              options: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    label: { type: Type.STRING },
                    value: { type: Type.NUMBER },
                  },
                  required: ['label', 'value'],
                },
              },
              valueWhenOn: { type: Type.NUMBER },
              valueWhenOff: { type: Type.NUMBER },
              labelOn: { type: Type.STRING },
              labelOff: { type: Type.STRING },
              min: { type: Type.NUMBER },
              max: { type: Type.NUMBER },
              step: { type: Type.NUMBER },
              unitSuffix: { type: Type.STRING },
              justification: { type: Type.STRING, description: 'Brief appraisal reasoning for these rates' },
            },
            required: ['label', 'description', 'inputType', 'effectType', 'defaultValue', 'justification'],
          },
        },
      },
    });

    const suggestions = JSON.parse(response.text || '[]');
    return res.json({ suggestions });
  } catch (err: any) {
    console.error('Error in /api/gemini/suggest-parameters:', err);
    return res.status(500).json({
      error: err.message || 'Failed to generate parameter suggestions with Gemini.',
    });
  }
});

/**
 * Feature C: Explain This Estimate
 * Explains the engine's calculation in plain English (< 120 words) with key drivers and upside/downside factors.
 * STRICT RULE: Gemini explains ONLY the numbers the engine calculated; it must never produce its own valuation figure.
 */
app.post('/api/gemini/explain-estimate', async (req: Request, res: Response) => {
  try {
    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API key is not configured in the server environment.',
      });
    }

    const { inputs, calculationResult, profile } = req.body;

    if (!inputs || !calculationResult || !profile) {
      return res.status(400).json({ error: 'inputs, calculationResult, and profile are required' });
    }

    const promptText = `
You are a valuation analyst writing a concise explanation for a property appraisal report generated by QuickVal.
STRICT MANDATE:
1. Explain ONLY the numbers the QuickVal engine calculated below.
2. DO NOT produce or invent your own alternative valuation figure.
3. Keep the total explanation under 120 words.
4. State what primarily drives the estimated market value (e.g. land size vs. building footprint vs. specific condition or location multipliers).
5. List 2-3 specific real-world factors that could push the value higher or lower upon physical inspection.

CALCULATED NUMBERS (DO NOT DEVIATE):
- Market Profile: ${profile.name} (${profile.currency})
- Land Value: ${profile.currency} ${calculationResult.landValue.toLocaleString()} (${inputs.landArea} ${profile.areaUnit} @ base ${profile.baseRates.landRate})
- Building Value: ${profile.currency} ${calculationResult.buildingValue.toLocaleString()}
- Additions / External Works: ${profile.currency} ${calculationResult.additionsValue.toLocaleString()}
- Market Value: ${profile.currency} ${calculationResult.marketValue.toLocaleString()}
- Range: ${profile.currency} ${calculationResult.rangeLow.toLocaleString()} – ${profile.currency} ${calculationResult.rangeHigh.toLocaleString()}
- Forced Sale Value: ${profile.currency} ${calculationResult.forcedSaleValue.toLocaleString()}
- Gross Replacement Cost: ${profile.currency} ${calculationResult.replacementCost.toLocaleString()}
- Active parameters used: ${JSON.stringify(
      calculationResult.parameterBreakdowns?.map((p: any) => `${p.label}: ${p.displayValue}`) || []
    )}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: promptText,
      config: {
        systemInstruction:
          'You are a disciplined property valuation assistant. Never invent numbers. Keep explanations under 120 words. Focus strictly on explaining the engine mathematical results.',
      },
    });

    const explanation = response.text?.trim() || 'Valuation explained based on engine parameters.';
    return res.json({ explanation });
  } catch (err: any) {
    console.error('Error in /api/gemini/explain-estimate:', err);
    return res.status(500).json({
      error: err.message || 'Failed to explain valuation with Gemini.',
    });
  }
});

/**
 * Serve frontend: Vite middlewares in development, static in production
 */
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`QuickVal server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
