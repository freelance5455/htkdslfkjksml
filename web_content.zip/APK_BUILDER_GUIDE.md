# Mayonin Chronicles — No-Termux Android Package

This project is prepared for a no-Termux Android wrapper/build workflow.

## App identity
- Name: Mayonin Chronicles
- Package ID: com.mayonin.chronicles
- Orientation: Landscape
- Web build output: dist

## Recommended workflow
1. Upload this project ZIP to a web-based Android wrapper/builder that accepts Vite/React projects or a built web directory.
2. Build the web project using the normal `npm run build` step offered by the service.
3. Package the resulting `dist` directory as an Android app using the service's WebView/Capacitor option.
4. Use:
   - App name: Mayonin Chronicles
   - Package/application ID: com.mayonin.chronicles
   - Orientation: Landscape
   - Fullscreen/immersive: enabled if the builder offers it.
5. Build the APK/AAB.

## Important
This ZIP is source-ready for a Capacitor-style wrapper. It does not contain a prebuilt APK, Android SDK, Gradle cache, or node_modules.
