XINGCHI AI ANDROID - SOURCE PROJECT
Bản Android thử nghiệm giao diện Chat, Tạo ảnh, Cài đặt API.

LƯU Ý:
- Đây là source Android Studio, chưa phải APK đã biên dịch.
- Chat gọi endpoint OpenAI-compatible: /v1/chat/completions.
- Model ID mặc định gợi ý gpt-6-astra và gpt-6.1-sol; cần thay bằng ID chính xác trả về từ GET /v1/models nếu khác.
- Tạo ảnh dùng /v1/images/generations và cần model tạo ảnh riêng được XingchiAPI hỗ trợ. Chưa xác minh endpoint/model trên tài khoản.
- API key lưu cục bộ bằng localStorage của WebView; chỉ dùng khóa thử nghiệm, không chia sẻ thiết bị.

BUILD APK:
Cách 1: Mở thư mục này bằng Android Studio, chờ Gradle Sync, chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
Cách 2: Đưa project lên GitHub, vào Actions > Build Android APK > Run workflow. Tải artifact XingchiAI-debug-apk sau khi workflow hoàn tất.

APK debug cài thử có thể yêu cầu cho phép cài ứng dụng không rõ nguồn trên Android.
