# Shadow Executor (safe Android Luau editor)

An Android WebView app containing a dark purple Luau text editor, locally saved scripts, and a preview console. It does **not** execute Luau, inject code into Roblox, or connect to Roblox. The Preview output helper only displays literal `print("text")` / `print('text')` matches.

## Build an APK

### On a computer with Android Studio
1. Install Android Studio and a compatible JDK (Android Studio's bundled JDK is fine).
2. Open this `ShadowExecutor` folder as an existing project.
3. Let Gradle sync. If prompted, install Android SDK Platform 35 and the Android Gradle plugin dependencies.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show a link to the generated debug APK. Copy it to your Android device and install it. If Android blocks installation, allow installs for the file manager/browser you used to open the APK, then disable that permission afterward if desired.

### Android-only note
This folder is source code, not a prebuilt APK. Android Studio is the straightforward supported way to compile it; this project cannot generate an APK merely by opening the files in a text editor on the phone.

## Features
- Responsive dark purple UI
- Editor with filename field and basic Tab indentation
- Save/overwrite, open, delete, and create scripts
- Local storage in the app's WebView
- Console with simple print-call preview

## Privacy and limitations
- No Internet permission is requested by the app.
- Saved scripts are local to the app and may be lost if app data is cleared or the app is uninstalled.
- This is a script editor and preview utility, not a Luau interpreter or Roblox exploit executor.
