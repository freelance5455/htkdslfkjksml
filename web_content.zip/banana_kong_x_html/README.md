# Banana Kong X — UI HTML

Esta versão usa HTML, CSS e JavaScript para a interface, carregada localmente em uma Android WebView.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `banana_kong_x_html` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Conecte um Android com depuração USB e pressione Run.

## Interface
- `app/src/main/assets/index.html`: estrutura da interface.
- `app/src/main/assets/style.css`: aparência preto/vermelho e layout responsivo.
- `app/src/main/assets/app.js`: interações demonstrativas.
- `MainActivity.kt`: abre o HTML na WebView e faz a ponte para abrir as configurações de sobreposição.

## Limitações
A simulação de rota usa resultados fictícios. Não há captura MediaProjection, análise de imagem, detecção real de obstáculos, overlay flutuante funcional nem integração com Banana Kong. A permissão de sobreposição apenas abre as configurações do Android; não cria uma janela flutuante.
