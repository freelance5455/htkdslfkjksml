plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.bananakongx"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.bananakongx"
        minSdk = 23
        targetSdk = 28
        versionCode = 2
        versionName = "0.2-html"
    }
}
