const analyze = document.getElementById('analyzeBtn');
const risk = document.getElementById('riskValue');
const route = document.getElementById('routeValue');
const status = document.getElementById('analysisStatus');

analyze.addEventListener('click', () => {
  const options = [
    {risk:'Baixo*', route:'Desvio superior'},
    {risk:'Médio*', route:'Salto antecipado'},
    {risk:'Alto*', route:'Aguardar leitura'}
  ];
  const result = options[Math.floor(Math.random() * options.length)];
  risk.textContent = result.risk;
  route.textContent = result.route;
  status.textContent = '*Resultado aleatório de demonstração, não baseado na tela do jogo.';
  analyze.textContent = 'SIMULAR NOVAMENTE ↗';
});

document.getElementById('overlayBtn').addEventListener('click', () => {
  if (window.Android && Android.requestOverlayPermission) {
    Android.requestOverlayPermission();
  } else {
    alert('Abra esta interface dentro do aplicativo Android para configurar a permissão.');
  }
});
