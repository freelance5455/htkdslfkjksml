# Build Aster APK on GitHub Actions (phone-friendly)

This ZIP is the Android source repository root. Upload/extract these files directly into a GitHub repository so `.github/workflows/build-android-apk.yml` is at the repository root.

## Build
1. Create a GitHub repository and upload the **contents of this ZIP** (not the ZIP's parent folder).
2. Open **Actions** and select **Build Aster Android APK**.
3. Tap **Run workflow** and wait for the run to finish.
4. Open the successful run and download the `aster-debug-apk` artifact. Extract it to get `app-debug.apk`.
5. Install only after checking the workflow succeeded and the artifact is present.

The workflow builds a debug APK. It does not guarantee a 30 MB file size, production signing, or that all ten agents are fully implemented. This source currently represents a starter app; check the app and test AI/API settings before relying on it.

## Security
Do not commit API keys or passwords to the repository. Do not put a private provider key into a public Android app. Use a secure backend for production credentials.
