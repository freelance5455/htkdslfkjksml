# Smart 11.0 — Build on GitHub

This project is prepared as a native Android Gradle project. The repository workflow builds an installable debug APK using GitHub Actions.

## Build
1. Create a GitHub repository and upload the contents of this ZIP to the repository root.
2. Open the repository's **Actions** tab.
3. Select **Build Smart APK**.
4. Choose **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run and download the artifact named **Smart-11.0-debug-APK**.
7. Extract the downloaded artifact and install `app-debug.apk` on Android.

## Important
- This is a native Android project, not an HTML-to-APK wrapper.
- Some Smart capabilities require the user to grant Android permissions manually, especially Accessibility, notification access, microphone, and overlay access.
- Open-ended AI chat requires a real backend/API URL. `SmartAiClient.kt` intentionally contains a placeholder until a backend is configured.
- Android security restrictions still apply; Smart cannot bypass protected system screens or permissions.
