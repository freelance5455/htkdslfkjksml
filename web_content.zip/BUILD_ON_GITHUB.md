# Smart 11.0 — Build on GitHub

## What this project is
This is the native Android Smart project. It is **not** an HTML-to-APK project.

- App name: Smart
- Version name: 11.0
- Version code: 11
- Package: `com.app.smarty`
- Target/compile SDK: 35

## Build
The repository contains `.github/workflows/android-build.yml`. GitHub Actions installs Java 17, Android SDK 35 and Gradle 8.9, then builds:

`app/build/outputs/apk/debug/app-debug.apk`

The APK is uploaded as the workflow artifact **Smart-11.0-debug-APK**.

## Important
Upload the **contents of this ZIP** into the root of a GitHub repository (not the ZIP file itself). Then open **Actions → Build Smart APK → Run workflow**.

After the workflow finishes: open the successful run → Artifacts → download **Smart-11.0-debug-APK** → unzip it → install `app-debug.apk`.

## Android permissions
Smart may ask for microphone, phone, contacts, SMS, camera and notification permissions. Accessibility access and notification-listener access must be enabled by the user in Android Settings for those features. Overlay permission is needed for the floating Smart button.

## Product limitations
A real always-on wake word and unrestricted system control are limited by Android security and device policies. The included voice service uses Android speech recognition and foreground-service rules; it is not a dedicated offline wake-word engine. Open-ended AI chat also requires a configured AI backend/API.
