RABBIT FF PANEL - โปรเจกต์ Android สำหรับสร้าง APK

ข้อกำหนด:
- Android Studio รุ่นที่รองรับ Android Gradle Plugin 8.7.3
- Android SDK Platform 35
- อินเทอร์เน็ตสำหรับดาวน์โหลด Gradle/Android Gradle Plugin ครั้งแรก

วิธีสร้าง APK:
1. แตกไฟล์ ZIP
2. เปิด Android Studio > Open
3. เลือกโฟลเดอร์ RabbitFFPanel ที่แตกไฟล์แล้ว
4. รอ Gradle Sync และติดตั้ง Android SDK Platform 35 หากระบบแจ้ง
5. เลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
6. เมื่อเสร็จ กด locate จากแถบแจ้งเตือนเพื่อหาไฟล์ app-debug.apk

การเปิดเกม:
- แอปจะเรียกหน้าเปิดแอปของ Free Fire หรือ Free Fire MAX ที่ติดตั้งอยู่ในเครื่อง
- ถ้าไม่มีเกมนั้นติดตั้ง ปุ่มจะไม่สามารถเปิดเกมได้

ข้อจำกัด:
- เป็นแผงฝึกซ้อม/เดโม ไม่ได้แก้ไขเกมหรือให้ aimbot
- ไม่มีระบบกันแบน กันติดดำ หรือรับประกันผลในเกม
