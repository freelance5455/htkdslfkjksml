// Главный файл: меню, цикл игры, камера, рисование, переходы между картами
var Game = (function () {
  var canvas = document.getElementById('game'), ctx = canvas.getContext('2d');
  var low = mkCanvas(10, 10), lx = low.getContext('2d');
  var $ = function (id) { return document.getElementById(id); };
  var S = { mode: 'loading', world: null, worlds: {}, player: null, comps: [], enemies: [], team: [], cam: { x: 0, y: 0 },
            time: 0, fx: [], parts: [], shaking: [], inv: { weapons: [], wood: 0 }, scale: 1, lw: 1, lh: 1, fade: 0, fadeDir: 0, fadeCb: null, hintT: 0, nearComp: null, shake: 0, menuT: 0 };

  function resize() {
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var W = Math.max(2, Math.round(window.innerWidth * dpr)), H = Math.max(2, Math.round(window.innerHeight * dpr));
    canvas.width = W; canvas.height = H;
    Input.W = W; Input.H = H;
    S.scale = Math.max(1, Math.round(H / CFG.VIEW_H));
    S.lw = Math.ceil(W / S.scale); S.lh = Math.ceil(H / S.scale);
    low.width = S.lw; low.height = S.lh;
    lx = low.getContext('2d'); lx.imageSmoothingEnabled = false; ctx.imageSmoothingEnabled = false;
  }

  // ---------- запуск карты ----------
  function enterWorld(name, keepTeam) {
    var w = S.worlds[name] || (S.worlds[name] = (name === 'forest' ? buildForest() : buildCity()));
    S.world = w;
    var sp = w.spawn;
    if (!S.player) S.player = new Player(sp.x, sp.y); else { S.player.x = sp.x; S.player.y = sp.y; }
    var p = w.freeNear(sp.x, sp.y, 5); S.player.x = p.x; S.player.y = p.y;
    S.player.trail = []; S.player.dir = name === 'forest' ? 'right' : 'right'; S.player.invul = 1;
    if (!keepTeam) { S.team = []; }
    if (!w.runtime) {
      w.runtime = {
        comps: w.companions.map(function (c) { return new Companion(c.type, c.x, c.y); }),
        enemies: w.enemies.map(function (e) { return new Enemy(e.type, e.x, e.y, e.terr); })
      };
    }
    S.comps = w.runtime.comps; S.enemies = w.runtime.enemies;
    // напарники переходят вместе с игроком
    S.team.forEach(function (c, i) { var q = w.freeNear(sp.x - 14 * (i + 1), sp.y, 5); c.x = q.x; c.y = q.y; });
    S.cam.x = S.player.x - S.lw / 2; S.cam.y = S.player.y - S.lh / 2;
    S.hintT = 6;
  }
  function startGame() {
    S.worlds = {}; S.player = null; S.team = []; S.inv = { weapons: [], wood: 0 }; S.parts = []; S.shaking = [];
    enterWorld('forest', false);
    S.mode = 'play'; S.fx = []; $('menu').classList.add('hidden'); $('overlay').classList.add('hidden');
    S.player.hearts = CFG.HEARTS_START;
  }
  function showMenu() {
    S.mode = 'menu'; $('menu').classList.remove('hidden'); $('btnJoin').classList.add('hidden'); $('btnHit').classList.add('hidden'); $('btnInv').classList.add('hidden'); $('inv').classList.add('hidden'); $('overlay').classList.add('hidden');
    if (!S.worlds.forest) { S.worlds.forest = buildForest(); }
    S.world = S.worlds.forest; S.comps = []; S.enemies = []; S.menuT = 0;
  }
  function overlay(title, text, btn, cb) {
    $('ovTitle').textContent = title; $('ovText').innerHTML = text; $('ovBtn').textContent = btn;
    $('overlay').classList.remove('hidden'); $('ovBtn').onclick = function () { $('overlay').classList.add('hidden'); cb(); };
  }
  function maxHearts() { return CFG.HEARTS_START + S.team.length; }

  // ---------- события ----------
  function hitPlayer(enemy) {
    var p = S.player;
    p.hearts--; p.invul = 1.6; p.stun = 0.35; S.shake = 0.25;
    var dx = p.x - enemy.x, dy = p.y - enemy.y, d = Math.hypot(dx, dy) || 1;
    for (var i = 0; i < 8; i++) p.tryMove(S.world, dx / d * 2.5, dy / d * 2.5);
    if (p.hearts <= 0) {
      S.mode = 'dead';
      overlay('Тебя поймали!', 'Попробуй пройти осторожнее.', 'Ещё раз', function () {
        var w = S.world, sp = w.spawn, q = w.freeNear(sp.x, sp.y, 5);
        p.x = q.x; p.y = q.y; p.hearts = maxHearts(); p.invul = 2; p.trail = [];
        S.team.forEach(function (c, i) { var r = w.freeNear(sp.x - 14 * (i + 1), sp.y, 5); c.x = r.x; c.y = r.y; });
        S.enemies.forEach(function (e) { e.x = e.hx; e.y = e.hy; e.state = 'idle'; });
        S.mode = 'play';
      });
    }
  }
  var DIRV = { right: [1, 0], left: [-1, 0], down: [0, 1], up: [0, -1] };
  var DIRA = { right: 0, down: Math.PI / 2, left: Math.PI, up: -Math.PI / 2 };
  // общий удар: attacker бьёт перед собой, всех врагов в дуге задевает
  function swing(att, dmg, reach, kind) {
    var v = DIRV[att.dir] || [0, 1], hit = 0;
    S.enemies.forEach(function (e) {
      if (e.dead) return;
      var dx = e.x - att.x, dy = e.y - att.y, d = Math.hypot(dx, dy);
      if (d < reach + 5 && (dx * v[0] + dy * v[1]) > -3) { e.hurt(dmg, att.x, att.y, S.world); hit++; }
    });
    if (att === S.player) {                              // игрок может рубить деревья
      var best = null, bd = 1e9;
      S.world.breakables.forEach(function (b) {
        if (b.broken) return;
        var dx = b.c.x - att.x, dy = b.c.y - att.y, d = Math.hypot(dx, dy);
        if (d < reach + b.c.r + 3 && (dx * v[0] + dy * v[1]) > 0 && d < bd) { bd = d; best = b; }
      });
      if (best) { hit++; chopTree(best, dmg); }
    }
    S.fx.push({ x: att.x, y: att.y, dir: att.dir, t: 0, life: 0.2, kind: kind, reach: reach, hit: hit });
    return hit;
  }
  function leaves(x, y, n) {
    for (var i = 0; i < n; i++) S.parts.push({ x: x + (Math.random() - 0.5) * 10, y: y - 14 - Math.random() * 12, vx: (Math.random() - 0.5) * 30, vy: -10 + Math.random() * 20, t: 0, life: 0.5 + Math.random() * 0.4, c: Math.random() < 0.5 ? '#52ad55' : '#2f7a3a' });
  }
  function chopTree(b, dmg) {
    b.hp -= dmg; b.d.shakeT = 0.25; if (S.shaking.indexOf(b.d) < 0) S.shaking.push(b.d);
    leaves(b.x, b.y, 4);
    if (b.hp <= 0) {
      S.world.breakTree(b); leaves(b.x, b.y, 14);
      var n = b.max >= 8 ? 4 : b.max >= 5 ? 3 : 2; S.inv.wood += n;
      S.popup = { t: 2, text: 'Дерево срублено! +' + n + ' дерева' };
    }
  }
  function playerAttack() {
    var p = S.player;
    if (S.mode !== 'play' || !p || p.atkCd > 0 || p.stun > 0 || S.fadeDir) return;
    var wp = CFG.WEAPONS[p.weapon] || CFG.WEAPONS.fist;
    p.atkCd = wp.cd; swing(p, wp.dmg, wp.reach, p.weapon);
  }
  function pickups(w, p) {
    w.items.forEach(function (it) {
      if (it.taken || dist(p.x, p.y, it.x, it.y) > 12) return;
      var cur = CFG.WEAPONS[p.weapon], nw = CFG.WEAPONS[it.name];
      if (S.inv.weapons.indexOf(it.name) >= 0) return;            // такое уже есть
      it.taken = true; it.d.hidden = true; S.inv.weapons.push(it.name);
      var better = nw.dmg > cur.dmg; if (better) p.weapon = it.name;
      S.popup = { t: 2.4, text: 'В сумку: ' + nw.label.toLowerCase() + (better ? ' (взял в руку)' : '') };
    });
  }
  // ---------- инвентарь ----------
  function slotIcon(name, scale) {
    var im = Assets.get(name), c = document.createElement('canvas'); c.width = im.width * scale; c.height = im.height * scale;
    var x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(im, 0, 0, c.width, c.height); return c;
  }
  function renderInv() {
    var grid = $('invGrid'), p = S.player, slots = [];
    grid.innerHTML = '';
    slots.push({ id: 'fist', label: 'Кулаки', icon: null });
    S.inv.weapons.forEach(function (n) { slots.push({ id: n, label: CFG.WEAPONS[n].label, icon: 'item_' + n }); });
    if (S.inv.wood > 0) slots.push({ id: 'wood', label: 'Дерево', icon: 'item_wood', count: S.inv.wood });
    while (slots.length < 8) slots.push(null);
    var info = $('invInfo'); info.textContent = 'Нажми на оружие, чтобы взять его в руку.';
    slots.forEach(function (sl) {
      var d = document.createElement('div'); d.className = 'slot';
      if (sl) {
        if (sl.icon) d.appendChild(slotIcon(sl.icon, 3)); else { var f = document.createElement('div'); f.className = 'fist'; f.textContent = '✊'; d.appendChild(f); }
        var lb = document.createElement('div'); lb.className = 'lb'; lb.textContent = sl.label; d.appendChild(lb);
        if (sl.count) { var ct = document.createElement('div'); ct.className = 'ct'; ct.textContent = 'x' + sl.count; d.appendChild(ct); }
        if (sl.id === p.weapon) { d.classList.add('eq'); var eq = document.createElement('div'); eq.className = 'eqt'; eq.textContent = 'в руке'; d.appendChild(eq); }
        d.addEventListener('click', function () {
          if (sl.id === 'wood') { info.textContent = 'Дерево: ' + S.inv.wood + ' шт. Пока просто копится — пригодится позже.'; return; }
          p.weapon = sl.id; renderInv(); var w = CFG.WEAPONS[sl.id];
          $('invInfo').textContent = w.label + ': урон ' + w.dmg + ', дальность ' + w.reach + '.';
        });
      }
      grid.appendChild(d);
    });
  }
  function openInv() { if (S.mode !== 'play') return; S.mode = 'inv'; Input.joy.active = false; renderInv(); $('inv').classList.remove('hidden'); $('btnJoin').classList.add('hidden'); }
  function closeInv() { if (S.mode !== 'inv') return; $('inv').classList.add('hidden'); S.mode = 'play'; }

  function joinNearest() {
    var c = S.nearComp; if (!c || c.joined || S.mode !== 'play' || c.refuseT > 0) return;
    var nm = ({ green: 'Зелёный', yellow: 'Жёлтый', blue: 'Синий' })[c.type];
    if (Math.random() >= CFG.JOIN_CHANCE) {                       // не согласился — можно попробовать позже
      c.refuseT = CFG.JOIN_RETRY; S.nearComp = null; $('btnJoin').classList.add('hidden');
      S.popup = { t: 2.2, text: nm + ' человечек пока не хочет… Попробуй ещё раз!', bad: true };
      return;
    }
    c.joined = true; c.index = S.team.length; S.team.push(c); S.nearComp = null;
    S.player.hearts = Math.min(maxHearts(), S.player.hearts + 1);
    $('btnJoin').classList.add('hidden'); S.popup = { t: 1.6, text: 'К команде присоединился ' + ({ green: 'зелёный', yellow: 'жёлтый', blue: 'синий' })[c.type] + ' человечек!' };
  }
  function goTo(name) {
    if (S.fadeDir) return;
    S.fadeDir = 1; S.fade = 0; S.fadeCb = function () { enterWorld(name, true); };
  }

  // ---------- обновление ----------
  function update(dt) {
    S.time += dt;
    if (S.mode === 'menu') { S.menuT += dt; var w = S.world; S.cam.x = clamp(w.pw / 2 + Math.sin(S.menuT * 0.12) * 300 - S.lw / 2, 0, w.pw - S.lw); S.cam.y = clamp(w.ph / 2 + Math.cos(S.menuT * 0.09) * 150 - S.lh / 2, 0, w.ph - S.lh); return; }
    if (S.fadeDir) {
      S.fade += S.fadeDir * dt * 2.2;
      if (S.fadeDir > 0 && S.fade >= 1) { S.fade = 1; S.fadeDir = -1; if (S.fadeCb) S.fadeCb(); S.fadeCb = null; }
      else if (S.fadeDir < 0 && S.fade <= 0) { S.fade = 0; S.fadeDir = 0; }
    }
    if (S.mode !== 'play') { $('btnHit').classList.add('hidden'); $('btnInv').classList.add('hidden'); $('btnJoin').classList.add('hidden'); return; }
    $('btnHit').classList.remove('hidden'); $('btnInv').classList.remove('hidden');
    var w = S.world, p = S.player;
    var G = { enemies: S.enemies, team: S.team, swing: swing, hitPlayer: hitPlayer };
    p.update(dt, w, S.fadeDir > 0 ? { x: 0, y: 0 } : Input.vec());
    S.comps.forEach(function (c) { c.update(dt, w, p, S.team, G); });
    S.enemies.forEach(function (e) { e.update(dt, w, p, G); });
    pickups(w, p);
    S.parts.forEach(function (q) { q.t += dt; q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 60 * dt; }); S.parts = S.parts.filter(function (q) { return q.t < q.life; });
    S.shaking = S.shaking.filter(function (d) { d.shakeT -= dt; return d.shakeT > 0; });
    S.fx.forEach(function (f) { f.t += dt; }); S.fx = S.fx.filter(function (f) { return f.t < f.life; });
    if (Input.keys.Space || Input.keys.KeyF) playerAttack();
    // враги не должны накладываться друг на друга
    for (var i = 0; i < S.enemies.length; i++) for (var j = i + 1; j < S.enemies.length; j++) {
      var a = S.enemies[i], b = S.enemies[j]; if (a.dead || b.dead) continue; var dx = a.x - b.x, dy = a.y - b.y, d = Math.hypot(dx, dy);
      if (d < 10 && d > 0.01) { a.tryMove(w, dx / d * 0.4, dy / d * 0.4); b.tryMove(w, -dx / d * 0.4, -dy / d * 0.4); }
    }
    // кнопка «Объединиться»
    var best = null, bd = CFG.JOIN_DISTANCE;
    S.comps.forEach(function (c) { if (!c.joined && c.refuseT <= 0) { var d = dist(c.x, c.y, p.x, p.y); if (d < bd) { bd = d; best = c; } } });
    S.nearComp = best; $('btnJoin').classList.toggle('hidden', !best);
    // дома: прозрачность
    var inside = w.houseAt(p.x, p.y);
    w.houses.forEach(function (h) {
      var tr = h === inside ? 0.22 : 1, tw = h === inside ? 0.55 : 1;
      h.ra += (tr - h.ra) * Math.min(1, dt * 8); h.wa += (tw - h.wa) * Math.min(1, dt * 8);
    });
    // выход / цель
    if (w.exit && p.y < w.exit.y && p.x > w.exit.x0 && p.x < w.exit.x1) goTo(w.exit.to);
    if (w.goal && dist(p.x, p.y, w.goal.x, w.goal.y) < w.goal.r && S.mode === 'play') {
      S.mode = 'win'; $('btnJoin').classList.add('hidden');
      overlay('Победа!', w.goal.text + '<br>Друзей в команде: ' + S.team.length + ' из 3', 'В главное меню', showMenu);
    }
    if (S.shake > 0) S.shake -= dt; if (S.hintT > 0) S.hintT -= dt; if (S.popup) { S.popup.t -= dt; if (S.popup.t <= 0) S.popup = null; }
    // камера
    var tx = p.x - S.lw / 2, ty = p.y - S.lh / 2 - 6;
    S.cam.x += (tx - S.cam.x) * Math.min(1, dt * 9); S.cam.y += (ty - S.cam.y) * Math.min(1, dt * 9);
  }

  // ---------- рисование ----------
  function drawWorld() {
    var w = S.world, cam = S.cam, c = lx;
    var cx, cy, W = S.lw, H = S.lh;
    if (w.pw <= W) cam.x = (w.pw - W) / 2; else cam.x = clamp(cam.x, 0, w.pw - W);
    if (w.ph <= H) cam.y = (w.ph - H) / 2; else cam.y = clamp(cam.y, 0, w.ph - H);
    cx = Math.round(cam.x); cy = Math.round(cam.y);
    var shx = S.shake > 0 ? (Math.random() * 2 - 1) * 2 : 0, shy = S.shake > 0 ? (Math.random() * 2 - 1) * 2 : 0;
    c.fillStyle = '#10261a'; c.fillRect(0, 0, W, H);
    var frame = Math.floor(S.time * 2) % 2;
    c.drawImage(w.cv[frame], cx, cy, W, H, shx, shy, W, H);
    // стены домиков
    w.houses.forEach(function (h) {
      var X = h.x0 * T - cx + shx, Y = h.y0 * T - cy + shy;
      if (X > W || Y > H || X + h.w * T < 0 || Y + h.h * T < 0) return;
      c.globalAlpha = h.wa; c.drawImage(h.wallCv, X, Y); c.globalAlpha = 1;
    });
    // объекты и персонажи, отсортированные по Y
    var ents = [];
    if (S.player && S.mode !== 'menu') ents.push(S.player);
    S.comps.forEach(function (e) { ents.push(e); }); S.enemies.forEach(function (e) { if (!(e.dead && e.fade <= 0)) ents.push(e); });
    ents.sort(function (a, b) { return a.y - b.y; });
    var st = w.statics, ei = 0, i;
    function drawStatic(s) {
      if (s.hidden) return;
      if (s.roof) {
        var h = s.roof, X = h.x0 * T - cx + shx, Y = h.y0 * T - cy + shy;
        if (X > W || Y > H || X + h.w * T < 0 || Y + h.h * T < 0) return;
        c.globalAlpha = h.ra; c.drawImage(h.roofCv, X, Y); c.globalAlpha = 1; return;
      }
      var X = s.x - cx + shx + (s.shakeT > 0 ? Math.sin(S.time * 70) * 1.3 : 0), Y = s.top - cy + shy;
      if (X > W || Y > H || X + s.w < 0 || Y + s.h < 0) return;
      c.drawImage(s.img, Math.round(X), Math.round(Y));
    }
    function drawEnt(e) {
      var cam2 = { x: cx - shx, y: cy - shy }, a = 1;
      if (e === S.player && e.invul > 0 && Math.floor(S.time * 14) % 2) a = 0.4;
      if (e instanceof Enemy) { if (e.dead) a = Math.max(0, e.fade); else if (e.flash > 0 && Math.floor(S.time * 24) % 2) a = 0.35; }
      e.draw(c, cam2, a);
      if (e instanceof Companion && !e.joined) {                // зелёная полупрозрачная точка
        var bx = Math.round(e.x - cam2.x), by = Math.round(e.y - cam2.y - 36 + Math.sin(S.time * 4 + e.t) * 1.5);
        c.fillStyle = e.refuseT > 0 ? 'rgba(235,150,40,0.6)' : 'rgba(60,220,90,0.55)'; c.beginPath(); c.arc(bx, by, 3.5, 0, 6.3); c.fill();
        c.fillStyle = 'rgba(190,255,200,0.7)'; c.fillRect(bx - 1, by - 2, 1, 1);
        c.strokeStyle = 'rgba(40,160,70,0.6)'; c.lineWidth = 0.8; c.beginPath(); c.arc(bx, by, 3.5, 0, 6.3); c.stroke();
      }
      if (e instanceof Enemy && e.alert > 0) {                    // «!»
        var bx2 = Math.round(e.x - cam2.x), by2 = Math.round(e.y - cam2.y - 37);
        c.fillStyle = '#ff4040'; c.fillRect(bx2 - 1, by2 - 5, 2, 5); c.fillRect(bx2 - 1, by2 + 1, 2, 2);
      } else if (e instanceof Enemy && e.state === 'search' && !e.dead) {            // «?» — ищет
        var bx3 = Math.round(e.x - cam2.x), by3 = Math.round(e.y - cam2.y - 33);
        c.fillStyle = '#ffd84a'; c.font = 'bold 9px monospace'; c.textAlign = 'center'; c.fillText('?', bx3, by3);
      }
    }
    for (i = 0; i < st.length; i++) {
      var s = st[i];
      while (ei < ents.length && ents[ei].y <= s.y) drawEnt(ents[ei++]);
      drawStatic(s);
    }
    while (ei < ents.length) drawEnt(ents[ei++]);
    S.parts.forEach(function (q) { c.fillStyle = q.c; c.fillRect(Math.round(q.x - cx), Math.round(q.y - cy), 2, 2); });
    // блеск над оружием, которое можно взять
    w.items.forEach(function (it) {
      if (it.taken) return;
      var sx = Math.round(it.x - cx), sy = Math.round(it.y - cy - 9 + Math.sin(S.time * 4 + it.x) * 1.5);
      if (sx > -10 && sx < W + 10 && sy > -10 && sy < H + 10) c.drawImage(Assets.get('sparkle'), sx - 4, sy - 4);
    });
    // эффекты ударов: оружие описывает дугу + белые полоски
    S.fx.forEach(function (f) {
      var pr = f.t / f.life, a = DIRA[f.dir] || 0, sx = f.x - cx, sy = f.y - cy - 10, ang = a + (pr - 0.5) * 2.0;
      if (f.kind !== 'fist' && f.kind !== 'punch') {
        var im = Assets.get('item_' + f.kind);
        c.save(); c.translate(sx, sy); c.rotate(ang); c.drawImage(im, 5, -Math.round(im.height / 2)); c.restore();
      }
      c.strokeStyle = 'rgba(255,255,255,' + (0.85 - pr * 0.7) + ')'; c.lineWidth = 1.5;
      c.beginPath(); c.arc(sx, sy, f.reach * 0.8, a - 0.9, a - 0.9 + 1.8 * Math.min(1, pr * 1.6)); c.stroke();
      if (f.hit && pr < 0.5) {
        c.fillStyle = '#ffe27a';
        for (var k = 0; k < 3; k++) { var aa = a + (k - 1) * 0.6; c.fillRect(Math.round(sx + Math.cos(aa) * (f.reach + 3)), Math.round(sy + Math.sin(aa) * (f.reach + 3)), 2, 2); }
      }
    });
    // цель в городе — мерцающий круг
    if (w.goal) {
      c.strokeStyle = 'rgba(255,230,110,' + (0.45 + 0.3 * Math.sin(S.time * 4)) + ')'; c.lineWidth = 2;
      c.beginPath(); c.ellipse(w.goal.x - cx, w.goal.y - cy, w.goal.r * 0.8, w.goal.r * 0.45, 0, 0, 6.3); c.stroke();
    }
    ctx.drawImage(low, 0, 0, W, H, 0, 0, W * S.scale, H * S.scale);
  }

  function drawHUD() {
    var W = canvas.width, H = canvas.height, u = H / 100, p = S.player;
    ctx.save(); ctx.textBaseline = 'top';
    function text(t, x, y, size, col, align) {
      ctx.font = 'bold ' + Math.round(size) + 'px "Courier New", monospace'; ctx.textAlign = align || 'left';
      ctx.fillStyle = '#000'; ctx.fillText(t, x + size / 8, y + size / 8); ctx.fillStyle = col || '#fff'; ctx.fillText(t, x, y);
    }
    if (S.mode !== 'menu') {
      var hs = Math.max(2, Math.round(u * 0.5)), hx = u * 2.5, hy = u * 2.5;
      for (var i = 0; i < maxHearts(); i++) {
        var im = Assets.get(i < p.hearts ? 'heart_full' : 'heart_empty');
        ctx.drawImage(im, hx + i * (11 * hs + 3), hy, im.width * hs, im.height * hs);
      }
      // команда
      var ty = hy + 10 * hs + u * 2;
      ['green', 'yellow', 'blue'].forEach(function (t, i) {
        var has = S.team.some(function (c) { return c.type === t; });
        ctx.beginPath(); ctx.arc(hx + 6 * hs + i * 16 * hs, ty + 5 * hs, 5 * hs, 0, 6.3);
        ctx.fillStyle = has ? CFG.COMPANION_COLORS[t] : 'rgba(0,0,0,0.35)'; ctx.fill();
        ctx.lineWidth = Math.max(1, hs * 0.7); ctx.strokeStyle = '#12301d'; ctx.stroke();
      });
      var wp = CFG.WEAPONS[p.weapon] || CFG.WEAPONS.fist, wy = ty + 12 * hs + u * 1.5;
      if (p.weapon !== 'fist') { var wi = Assets.get('item_' + p.weapon); ctx.drawImage(wi, hx, wy, wi.width * hs * 0.9, wi.height * hs * 0.9); }
      text(wp.label, hx + (p.weapon !== 'fist' ? 20 * hs : 0), wy - u * 0.4, u * 3.4, '#ffe27a');
      if (S.inv.wood > 0) { var wd = Assets.get('item_wood'); ctx.drawImage(wd, hx, wy + u * 4.2, wd.width * hs * 0.9, wd.height * hs * 0.9); text('x' + S.inv.wood, hx + 20 * hs, wy + u * 3.9, u * 3.4, '#e6c28a'); }
      if (S.hintT > 0 && S.world.hudHint) { ctx.globalAlpha = Math.min(1, S.hintT); text(S.world.hudHint, W / 2, u * 3, u * 4.2, '#ffe27a', 'center'); ctx.globalAlpha = 1; }
      if (S.popup) { ctx.globalAlpha = Math.min(1, S.popup.t * 2); text(S.popup.text, W / 2, u * 14, u * 4.2, S.popup.bad ? '#ffb070' : '#9dff9d', 'center'); ctx.globalAlpha = 1; }
      if (p.hurtFlash > 0) { }
      // джойстик
      var j = Input.joy, b = j.active ? { x: j.bx, y: j.by } : Input.defaultBase(), R = j.R, k = j.active ? { x: j.kx, y: j.ky } : b;
      var m = Math.hypot(k.x - b.x, k.y - b.y); if (m > R) { k = { x: b.x + (k.x - b.x) / m * R, y: b.y + (k.y - b.y) / m * R }; }
      ctx.globalAlpha = j.active ? 0.55 : 0.28;
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(b.x, b.y, R, 0, 6.3); ctx.fill();
      ctx.fillStyle = '#12301d'; ctx.beginPath(); ctx.arc(b.x, b.y, R - Math.max(3, u * 0.6), 0, 6.3); ctx.fill();
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(k.x, k.y, R * 0.42, 0, 6.3); ctx.fill();
      ctx.globalAlpha = 1;
    }
    if (S.fade > 0) { ctx.fillStyle = 'rgba(0,0,0,' + clamp(S.fade, 0, 1) + ')'; ctx.fillRect(0, 0, W, H); }
    ctx.restore();
  }

  var last = 0;
  function frame(t) {
    var dt = Math.min(0.05, (t - last) / 1000 || 0); last = t;
    try { update(dt); if (S.world) { drawWorld(); drawHUD(); } } catch (e) { $('err').textContent += e.stack + '\n'; }
    requestAnimationFrame(frame);
  }

  function init() {
    window.addEventListener('error', function (e) { $('err').textContent += e.message + ' (' + (e.filename || '').split('/').pop() + ':' + e.lineno + ')\n'; });
    resize(); window.addEventListener('resize', resize); window.addEventListener('orientationchange', function () { setTimeout(resize, 200); });
    Input.init(canvas); Input.onInteract = joinNearest; Input.onAttack = playerAttack;
    $('btnHit').addEventListener('pointerdown', function (e) { e.preventDefault(); playerAttack(); });
    $('btnInv').addEventListener('click', openInv); $('invClose').addEventListener('click', closeInv);
    window.addEventListener('keydown', function (e) { if (e.code === 'KeyI' || e.code === 'Tab') { e.preventDefault(); S.mode === 'inv' ? closeInv() : openInv(); } });
    $('btnPlay').addEventListener('click', startGame);
    $('btnJoin').addEventListener('click', joinNearest);
    $('btnJoin').addEventListener('touchstart', function (e) { e.preventDefault(); joinNearest(); }, { passive: false });
    document.addEventListener('visibilitychange', function () { last = performance.now(); });
    Assets.load(function (p) { $('loading').textContent = 'Загрузка… ' + Math.round(p * 100) + '%'; }, function (failed) {
      if (failed.length) $('err').textContent = 'Нет картинок: ' + failed.join(', ');
      setTimeout(function () { showMenu(); $('loading').classList.add('hidden'); requestAnimationFrame(frame); }, 30);
    });
  }
  window.addEventListener('load', init);
  return { S: S, start: startGame, goTo: goTo };
})();
