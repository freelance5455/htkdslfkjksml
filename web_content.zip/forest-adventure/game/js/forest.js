// Генерация карты ЛЕСА (один и тот же результат каждый раз — зерно генератора фиксировано)
var K = { GRASS: 0, DIRT: 1, WATER: 2, BRIDGE: 3, SAND: 4, FLOOR: 5 };

function catmull(pts, step) {
  var out = [];
  for (var i = 0; i < pts.length - 1; i++) {
    var p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
    var n = Math.max(1, Math.ceil(dist(p1[0], p1[1], p2[0], p2[1]) / step));
    for (var s = 0; s < n; s++) {
      var t = s / n, t2 = t * t, t3 = t2 * t;
      out.push([0, 1].map(function (k) {
        return 0.5 * ((2 * p1[k]) + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3);
      }));
    }
  }
  out.push(pts[pts.length - 1]);
  return out;
}

function buildForest() {
  var WW = 120, HH = 84, rnd = mulberry32(2024);
  var w = new World('forest', WW, HH);
  w.hudHint = 'Найди дорогу в город. Собирай друзей!';
  var kind = w.kind;

  // ---------- озёра ----------
  function wob(x, y) { return 1 + 0.12 * Math.sin(y * 0.7) + 0.08 * Math.sin(x * 1.3 + y * 0.3); }
  function lake(cx, cy, rx, ry) {
    for (var y = 0; y < HH; y++) for (var x = 0; x < WW; x++) {
      var dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
      if (dx * dx + dy * dy < wob(x, y)) kind[y * WW + x] = K.WATER;
    }
  }
  lake(66, 46, 5.5, 15); lake(28, 28, 4.5, 3.8); lake(96, 62, 3.6, 3);

  // ---------- извилистая тропа ----------
  var way = [[3, 71], [10, 69], [18, 67], [26, 71], [34, 65], [42, 57], [48, 50], [54, 46.5], [60, 46.5], [72, 46.5], [78, 46.5],
             [84, 44], [89, 38], [94, 31], [100, 26], [107, 22], [112, 18], [115.5, 13], [115.5, 8], [115.5, 2]];
  var pathPts = catmull(way, 0.4);
  function stamp(px, py, rad, bridgeOK) {
    for (var ty = Math.floor(py - rad); ty <= Math.ceil(py + rad); ty++)
      for (var tx = Math.floor(px - rad); tx <= Math.ceil(px + rad); tx++) {
        if (!w.inMap(tx, ty) || Math.hypot(tx + 0.5 - px, ty + 0.5 - py) > rad) continue;
        var i = ty * WW + tx;
        if (kind[i] === K.WATER) kind[i] = K.BRIDGE; else if (kind[i] !== K.BRIDGE) kind[i] = K.DIRT;
      }
  }
  pathPts.forEach(function (p, i) { stamp(p[0], p[1], 1.55 + 0.25 * Math.sin(i * 0.05)); });

  // ---------- домики ----------
  var HOUSES = [
    { x: 20, y: 56, w: 10, h: 8, door: [4, 2], windows: [2, 7],
      furniture: [['bed', 1, 1, true], ['shelf', 4, 1, true], ['crate', 7.3, 1.1, true], ['barrel', 7.5, 2.8, true], ['table', 3.4, 3, true], ['chair', 2.5, 3.4, false], ['chair', 5.9, 3.4, false]], rug: [2.9, 2.6] },
    { x: 34, y: 42, w: 10, h: 8, door: [4, 2], windows: [3, 6],
      furniture: [['shelf', 1.3, 1, true], ['bed', 7.3, 1.2, true], ['table', 3.3, 3.1, true], ['crate', 1.4, 3.8, true], ['barrel', 7.6, 3.6, true], ['chair', 5.7, 3.5, false]], rug: [2.6, 2.5] },
    { x: 80, y: 28, w: 9, h: 7, door: [3, 2], windows: [2, 6],
      furniture: [['bed', 1.2, 1.2, true], ['table', 3.6, 2, true], ['crate', 6.3, 1.2, true], ['barrel', 6.5, 2.9, true], ['chair', 3, 2.8, false]], rug: [3, 1.9] }
  ];
  // дорожки от дверей к тропе
  HOUSES.forEach(function (h) {
    var mx = h.x + h.door[0] + h.door[1] / 2, my = h.y + h.h + 0.3, best = null, bd = 1e9;
    pathPts.forEach(function (p) { var d = dist(mx, my, p[0], p[1]); if (d < bd) { bd = d; best = p; } });
    var n = Math.ceil(bd / 0.4);
    for (var i = 0; i <= n; i++) stamp(lerp(mx, best[0], i / n), lerp(my, best[1], i / n), 1.05);
  });
  HOUSES.forEach(function (h) {
    for (var ty = h.y; ty < h.y + h.h; ty++) for (var tx = h.x; tx < h.x + h.w; tx++) {
      var onDoor = ty === h.y + h.h - 1 && tx >= h.x + h.door[0] && tx < h.x + h.door[0] + h.door[1];
      kind[ty * WW + tx] = K.FLOOR;
    }
  });

  // песок у воды
  for (var ty = 0; ty < HH; ty++) for (var tx = 0; tx < WW; tx++) {
    if (kind[ty * WW + tx] !== K.GRASS) continue;
    if (w.kindAt(tx + 1, ty) === K.WATER || w.kindAt(tx - 1, ty) === K.WATER || w.kindAt(tx, ty + 1) === K.WATER || w.kindAt(tx, ty - 1) === K.WATER) kind[ty * WW + tx] = K.SAND;
  }
  for (var i = 0; i < WW * HH; i++) if (kind[i] === K.WATER) w.solid[i] = 1;

  // ---------- рисуем землю ----------
  for (var ty = 0; ty < HH; ty++) for (var tx = 0; tx < WW; tx++) {
    var k = kind[ty * WW + tx], nm;
    if (k === K.WATER) nm = 'water';
    else if (k === K.BRIDGE) nm = 'bridge';
    else if (k === K.DIRT) nm = 'dirt' + Math.floor(rnd() * 3);
    else if (k === K.SAND) nm = 'sand' + (rnd() < 0.5 ? 0 : 1);
    else if (k === K.FLOOR) nm = 'floor0';
    else nm = rnd() < 0.06 ? 'flower' + Math.floor(rnd() * 3) : 'grass' + Math.floor(rnd() * 4);
    w.tile(nm, tx, ty);
  }
  // перила мостика
  for (var ty = 0; ty < HH; ty++) for (var tx = 0; tx < WW; tx++) {
    if (kind[ty * WW + tx] !== K.BRIDGE) continue;
    if (w.kindAt(tx, ty - 1) === K.WATER) w.tile('rail_top', tx, ty);
    if (w.kindAt(tx, ty + 1) === K.WATER) w.tile('rail_bottom', tx, ty);
  }
  // мягкие края тропы
  var GC = ['#3c9444', '#2f7a3a', '#52ad55'], DC = ['#a67c4a', '#8a6338', '#bd9660'];
  for (var ty = 0; ty < HH; ty++) for (var tx = 0; tx < WW; tx++) {
    if (kind[ty * WW + tx] !== K.DIRT) continue;
    [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (o) {
      if (w.kindAt(tx + o[0], ty + o[1]) !== K.GRASS) return;
      for (var j = 0; j < 7; j++) {
        var a = Math.floor(rnd() * 16), b = Math.floor(rnd() * 3);
        var gx = o[0] ? (o[0] > 0 ? 15 - b : b) : a, gy = o[1] ? (o[1] > 0 ? 15 - b : b) : a;
        w.rect(tx * T + gx, ty * T + gy, 1, 1, GC[Math.floor(rnd() * 3)]);
        var nx = o[0] ? (o[0] > 0 ? T + (b % 2) : -1 - (b % 2)) : a, ny = o[1] ? (o[1] > 0 ? T + (b % 2) : -1 - (b % 2)) : a;
        if (rnd() < 0.6) w.rect(tx * T + nx, ty * T + ny, 1, 1, DC[Math.floor(rnd() * 3)]);
      }
    });
  }

  // ---------- домики (стены, крыша, мебель) ----------
  HOUSES.forEach(function (h) { w.house(h, rnd); });

  // ---------- оружие в домиках ----------
  function item(name, h, ox, oy) {
    var x = (h.x + ox) * T, y = (h.y + oy) * T;
    var d = w.sprite('item_' + name, x, y);
    w.items.push({ name: name, x: x, y: y - 3, d: d });
  }
  item('stick', HOUSES[0], 6.6, 5.6);
  item('pan', HOUSES[1], 2.2, 5.8);
  item('bat', HOUSES[2], 5.2, 5.2);
  item('stick', HOUSES[1], 7.4, 5.9);

  // ---------- деревья и всё остальное ----------
  var dp = distanceField(w, function (k) { return k === K.DIRT || k === K.BRIDGE; });
  var spawnPt = pathPts[Math.floor(pathPts.length * 0.03)];
  w.spawn = { x: spawnPt[0] * T, y: spawnPt[1] * T };
  var exclude = [];   // прямоугольники (в клетках), где ничего не растёт
  HOUSES.forEach(function (h) { exclude.push([h.x - 2, h.y - 2, h.x + h.w + 2, h.y + h.h + 3]); });
  exclude.push([spawnPt[0] - 5, spawnPt[1] - 5, spawnPt[0] + 5, spawnPt[1] + 5]);
  exclude.push([108, 0, 120, 13]);
  function excluded(tx, ty) { for (var i = 0; i < exclude.length; i++) { var e = exclude[i]; if (tx >= e[0] && tx < e[2] && ty >= e[1] && ty < e[3]) return true; } return false; }
  var clearings = HOUSES.map(function (h) { return [h.x + h.w / 2, h.y + h.h / 2, 11]; })
    .concat([[18, 40, 7], [100, 52, 8], [56, 70, 8], [76, 12, 8]]);
  function density(tx, ty) {
    var f = 0;
    clearings.forEach(function (c) { f = Math.max(f, clamp(1 - dist(tx, ty, c[0], c[1]) / c[2], 0, 1)); });
    return 1 - 0.9 * f;
  }
  var grid = {};
  function free(x, y, minD) {
    var gx = Math.floor(x / 32), gy = Math.floor(y / 32);
    for (var j = gy - 1; j <= gy + 1; j++) for (var i = gx - 1; i <= gx + 1; i++) {
      var l = grid[i + j * 512]; if (!l) continue;
      for (var q = 0; q < l.length; q++) if (dist(x, y, l[q][0], l[q][1]) < Math.max(minD, l[q][2])) return false;
    }
    return true;
  }
  function reg(x, y, minD) { var gx = Math.floor(x / 32), gy = Math.floor(y / 32); (grid[gx + gy * 512] || (grid[gx + gy * 512] = [])).push([x, y, minD]); }
  var TYPES = [
    { n: 'tree_s', p: 0.20, r: 3.6, sp: 14, mp: 2 }, { n: 'tree_m', p: 0.20, r: 4, sp: 18, mp: 3 }, { n: 'tree_m2', p: 0.12, r: 4, sp: 18, mp: 3 },
    { n: 'tree_l', p: 0.14, r: 5, sp: 23, mp: 4 }, { n: 'pine_s', p: 0.10, r: 3.2, sp: 13, mp: 2 }, { n: 'pine_m', p: 0.14, r: 3.8, sp: 16, mp: 3 }, { n: 'pine_l', p: 0.10, r: 4.6, sp: 21, mp: 4 }
  ];
  function pick() { var r = rnd(), s = 0; for (var i = 0; i < TYPES.length; i++) { s += TYPES[i].p; if (r < s) return TYPES[i]; } return TYPES[0]; }
  function plantTree(x, y, t) {
    var d = w.sprite(t.n, x, y), c = w.addCircle(x, y - 2, t.r); reg(x, y, t.sp);
    var hp = CFG.TREE_HP[t.n] || 4; w.breakables.push({ d: d, c: c, x: x, y: y, hp: hp, max: hp, broken: false });
  }
  // опушка по краю карты
  function edgeTree(x, y) {
    var tx = Math.floor(x / T), ty = Math.floor(y / T);
    if (kind[ty * WW + tx] !== K.GRASS && kind[ty * WW + tx] !== K.SAND) return;
    if (x > 107 * T && y < 14 * T) return;
    var t = TYPES[3]; if (!free(x, y, 14)) return;
    plantTree(x, y, rnd() < 0.5 ? t : TYPES[6]);
  }
  for (var x = 6; x < w.pw; x += 12 + rnd() * 6) { edgeTree(x, 12 + rnd() * 8); edgeTree(x, w.ph - 4 - rnd() * 8); }
  for (var y = 12; y < w.ph; y += 12 + rnd() * 6) { edgeTree(6 + rnd() * 6, y); edgeTree(w.pw - 6 - rnd() * 6, y); }
  for (var n = 0; n < 16000; n++) {
    var x = 8 + rnd() * (w.pw - 16), y = 20 + rnd() * (w.ph - 24), tx = Math.floor(x / T), ty = Math.floor(y / T);
    if (kind[ty * WW + tx] !== K.GRASS || excluded(tx, ty)) continue;
    if (rnd() > density(tx, ty)) continue;
    var t = pick(), dd = dp[ty * WW + tx];
    if (dd < t.mp || !free(x, y, t.sp)) continue;
    plantTree(x, y, t);
  }
  // кусты, камни, пеньки, грибы, папоротник
  function scatter(count, minPath, fn) {
    for (var n = 0, got = 0; n < count * 8 && got < count; n++) {
      var x = 6 + rnd() * (w.pw - 12), y = 12 + rnd() * (w.ph - 16), tx = Math.floor(x / T), ty = Math.floor(y / T);
      var k = kind[ty * WW + tx];
      if ((k !== K.GRASS && k !== K.SAND) || excluded(tx, ty) || dp[ty * WW + tx] < minPath || w.blocked(x, y, 4)) continue;
      fn(x, y); got++;
    }
  }
  scatter(320, 2, function (x, y) { w.sprite('bush' + Math.floor(rnd() * 3), x, y); });
  scatter(90, 1, function (x, y) { w.sprite('fern', x, y); });
  scatter(40, 2, function (x, y) { var s = rnd() < 0.5 ? 'rock0' : 'rock1'; w.sprite(s, x, y); w.addCircle(x, y - 3, 5); });
  scatter(14, 3, function (x, y) { w.sprite('stump', x, y); w.addCircle(x, y - 2, 3.5); });
  scatter(36, 2, function (x, y) { w.sprite('mushroom', x, y); });
  scatter(10, 3, function (x, y) { w.sprite('log', x, y); });
  // старые сухие деревья возле домиков
  HOUSES.forEach(function (h, i) {
    [[-3, 2], [h.w + 2, 4], [h.w + 3, h.h - 1], [-2, h.h + 1]].forEach(function (o) {
      var x = (h.x + o[0]) * T + 8, y = (h.y + o[1]) * T + 14;
      if (!w.blocked(x, y, 5) && dp[Math.floor(y / T) * WW + Math.floor(x / T)] >= 2) {
        var dd = w.sprite('dead_tree', x, y), cc = w.addCircle(x, y - 2, 3);
        w.breakables.push({ d: dd, c: cc, x: x, y: y, hp: 2, max: 2, broken: false });
      }
    });
    // хлам у стены
    w.sprite('crate', (h.x - 1) * T + 6, (h.y + h.h) * T - 2); w.addRect((h.x - 1) * T, (h.y + h.h) * T - 12, (h.x - 1) * T + 12, (h.y + h.h) * T - 2);
    w.sprite('barrel', (h.x + h.w) * T + 8, (h.y + 3) * T); w.addRect((h.x + h.w) * T + 2, (h.y + 3) * T - 14, (h.x + h.w) * T + 14, (h.y + 3) * T);
  });

  // ---------- указатель и ворота в город ----------
  w.sprite('sign_arrow', spawnPt[0] * T + 28, spawnPt[1] * T - 18);
  var gx0 = 114 * T, gBase = 11 * T;
  w.sprite('town_gate', gx0 + 32, gBase);
  w.addRect(gx0, gBase - 10, gx0 + 12, gBase); w.addRect(gx0 + 52, gBase - 10, gx0 + 64, gBase);
  for (var i = 0; i < 4; i++) {
    var hx = gx0 - 8 - i * 18; w.sprite('hedge', hx, gBase + 2); w.addRect(hx - 9, gBase - 8, hx + 9, gBase + 2);
    hx = gx0 + 72 + i * 18; w.sprite('hedge', hx, gBase + 2); w.addRect(hx - 9, gBase - 8, hx + 9, gBase + 2);
  }
  w.exit = { x0: 108 * T, x1: 120 * T, y: 9.2 * T, to: 'city' };

  // ---------- друзья и враги ----------
  function at(tx, ty) { return w.freeNear(tx * T, ty * T, 5); }
  w.companions = [
    Object.assign({ type: 'green' }, at(22, 68.2)),
    Object.assign({ type: 'yellow' }, at(24.8, 60.3)),
    Object.assign({ type: 'blue' }, at(75.5, 49.8))
  ];
  w.enemies = [
    Object.assign({ type: 'black', terr: 70 }, at(33, 62)), Object.assign({ type: 'orange', terr: 60 }, at(47, 53)),
    Object.assign({ type: 'black', terr: 70 }, at(57, 43)), Object.assign({ type: 'orange', terr: 60 }, at(77, 41)),
    Object.assign({ type: 'black', terr: 70 }, at(91, 36)), Object.assign({ type: 'orange', terr: 60 }, at(100, 29)),
    Object.assign({ type: 'black', terr: 70 }, at(106, 20)), Object.assign({ type: 'orange', terr: 60 }, at(60, 62))
  ];
  w.vignette();
  w.finish();
  return w;
}
