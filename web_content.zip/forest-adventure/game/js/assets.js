// Загрузка картинок из папки assets/ (или из встроенных данных в одно-файловой сборке)
var Assets = (function () {
  var imgs = {};
  function placeholder() {
    var c = mkCanvas(16, 16), x = c.getContext('2d');
    x.fillStyle = '#ff00ff'; x.fillRect(0, 0, 16, 16);
    return c;
  }
  function load(onProgress, done) {
    var names = ASSET_MANIFEST, left = names.length, failed = [];
    function step() { left--; if (onProgress) onProgress(1 - left / names.length); if (left === 0) done(failed); }
    names.forEach(function (n) {
      var im = new Image();
      var key = n.split('/').pop();
      im.onload = function () { imgs[key] = im; step(); };
      im.onerror = function () { failed.push(n); imgs[key] = placeholder(); step(); };
      im.src = (typeof ASSET_DATA !== 'undefined' && ASSET_DATA[n]) ? ASSET_DATA[n] : 'assets/' + n + '.png';
    });
  }
  function get(n) {
    var i = imgs[n];
    if (!i) { console.warn('нет картинки', n); return imgs.__ph || (imgs.__ph = placeholder()); }
    return i;
  }
  function rotated(n, quarter) {            // поворот картинки на 90° * quarter
    var key = n + '#r' + quarter;
    if (imgs[key]) return imgs[key];
    var s = get(n), c = mkCanvas(s.height, s.width), x = c.getContext('2d');
    x.translate(c.width / 2, c.height / 2); x.rotate(Math.PI / 2 * quarter);
    x.drawImage(s, -s.width / 2, -s.height / 2);
    return imgs[key] = c;
  }
  return { load: load, get: get, rotated: rotated };
})();
