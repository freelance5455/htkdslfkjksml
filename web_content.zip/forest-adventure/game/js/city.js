// Генерация карты ГОРОДА (отдельная карта)
var CK = { PLAZA: 10, ASPHALT: 11, SIDEWALK: 12, COBBLE: 13, GRASS: 0, BLD: 20 };

function buildCity() {
  var WW = 100, HH = 70, rnd = mulberry32(777);
  var w = new World('city', WW, HH);
  w.hudHint = 'Ты в городе! Найди фонтан на площади.';
  var kind = w.kind;
  kind.fill(CK.GRASS);

  // дороги: горизонтальные и вертикальные полосы (по 4 клетки), с тротуаром по 2 клетки
  var HR = [14, 40, 62], VR = [14, 48, 82];
  function inRoad(tx, ty) {
    for (var i = 0; i < HR.length; i++) if (ty >= HR[i] - 2 && ty < HR[i] + 2) return true;
    for (var i = 0; i < VR.length; i++) if (tx >= VR[i] - 2 && tx < VR[i] + 2) return true;
    return false;
  }
  function inWalk(tx, ty) {
    for (var i = 0; i < HR.length; i++) if (ty >= HR[i] - 4 && ty < HR[i] + 4) return true;
    for (var i = 0; i < VR.length; i++) if (tx >= VR[i] - 4 && tx < VR[i] + 4) return true;
    return false;
  }
  for (var ty = 0; ty < HH; ty++) for (var tx = 0; tx < WW; tx++)
    kind[ty * WW + tx] = inRoad(tx, ty) ? CK.ASPHALT : inWalk(tx, ty) ? CK.SIDEWALK : CK.GRASS;
  // площадь с фонтаном
  var PL = { x0: 40, y0: 32, x1: 56, y1: 48 };
  for (var ty = PL.y0; ty < PL.y1; ty++) for (var tx = PL.x0; tx < PL.x1; tx++) kind[ty * WW + tx] = CK.PLAZA;

  // ---------- рисуем землю ----------
  for (var ty = 0; ty < HH; ty++) for (var tx = 0; tx < WW; tx++) {
    var k = kind[ty * WW + tx], nm;
    if (k === CK.ASPHALT) nm = 'asphalt' + (rnd() < 0.5 ? 0 : 1);
    else if (k === CK.SIDEWALK) nm = 'sidewalk' + (rnd() < 0.5 ? 0 : 1);
    else if (k === CK.PLAZA) nm = 'plaza';
    else nm = rnd() < 0.05 ? 'flower' + Math.floor(rnd() * 3) : 'grass' + Math.floor(rnd() * 4);
    w.tile(nm, tx, ty);
  }
  // разметка дорог
  HR.forEach(function (r) { for (var x = 0; x < w.pw; x += 24) { var tx = Math.floor(x / T); if (!inRoadV(tx)) w.rect(x, r * T - 1, 12, 2, '#d8d8c8'); } });
  VR.forEach(function (c) { for (var y = 0; y < w.ph; y += 24) { var ty = Math.floor(y / T); if (!inRoadH(ty)) w.rect(c * T - 1, y, 2, 12, '#d8d8c8'); } });
  function inRoadV(tx) { for (var i = 0; i < VR.length; i++) if (tx >= VR[i] - 2 && tx < VR[i] + 2) return true; return false; }
  function inRoadH(ty) { for (var i = 0; i < HR.length; i++) if (ty >= HR[i] - 2 && ty < HR[i] + 2) return true; return false; }
  // зебры на перекрёстках
  HR.forEach(function (r) { VR.forEach(function (c) {
    for (var i = 0; i < 8; i++) {
      w.rect((c - 2) * T + i * 8, (r - 4) * T + 6, 4, 14, '#e8e8dc'); w.rect((c - 2) * T + i * 8, (r + 2) * T + 4, 4, 14, '#e8e8dc');
      w.rect((c - 4) * T + 6, (r - 2) * T + i * 8, 14, 4, '#e8e8dc'); w.rect((c + 2) * T + 4, (r - 2) * T + i * 8, 14, 4, '#e8e8dc');
    }
  }); });

  // площадь поверх разметки
  for (var ty = PL.y0; ty < PL.y1; ty++) for (var tx = PL.x0; tx < PL.x1; tx++) w.tile('plaza', tx, ty);

  // ---------- здания ----------
  var STY = ['brick', 'concrete', 'beige', 'glass', 'green'];
  var blocks = [];                       // «кварталы» между дорогами
  var xs = [0].concat(VR.map(function (c) { return c + 4; }));
  var xe = VR.map(function (c) { return c - 4; }).concat([WW]);
  var ys = [0].concat(HR.map(function (c) { return c + 4; }));
  var ye = HR.map(function (c) { return c - 4; }).concat([HH]);
  for (var j = 0; j < ys.length; j++) for (var i = 0; i < xs.length; i++) blocks.push({ x0: xs[i], x1: xe[i], y0: ys[j], y1: ye[j] });
  var buildings = [];
  function building(tx, ty, bw, bh, floors, style, doorSide) {
    // стена-фасад: floors рядов; сверху крыша
    var s = style;
    var faceH = floors;                   // высота фасада в клетках
    var cvW = mkCanvas(bw * T, (bh + faceH) * T), cx = cvW.getContext('2d');
    // здание «вертикально» занимает bh клеток крыши + faceH клеток фасада
    var topY = ty;                        // крыша: клетки ty .. ty+bh-1 ; фасад: ty+bh .. ty+bh+faceH-1
    var roofCv = mkCanvas(bw * T, bh * T), rc = roofCv.getContext('2d');
    for (var yy = 0; yy < bh; yy++) for (var xx = 0; xx < bw; xx++) {
      var edge = (yy === 0 || xx === 0 || xx === bw - 1);
      rc.drawImage(Assets.get('bld_' + s + (edge ? '_edge' : '_roof')), xx * T, yy * T);
    }
    // вентиляция / надстройка
    rc.fillStyle = 'rgba(0,0,0,0.22)'; rc.fillRect(T * 1.5, T * 1.5, T * 1.5, T); rc.fillStyle = 'rgba(255,255,255,0.12)'; rc.fillRect(T * 1.5, T * 1.5, T * 1.5, 3);
    var wallCv = mkCanvas(bw * T, faceH * T), wc = wallCv.getContext('2d');
    var doorX = Math.floor(bw / 2) - 0;
    for (var yy = 0; yy < faceH; yy++) for (var xx = 0; xx < bw; xx++) {
      var nm;
      if (yy === faceH - 1 && xx === doorX) nm = '_door';
      else if (yy === faceH - 1 && faceH >= 2 && rnd() < 0.35) nm = '_shop';
      else nm = '_wall' + (rnd() < 0.3 ? 1 : 0);
      wc.drawImage(Assets.get('bld_' + s + nm), xx * T, yy * T);
    }
    // карниз
    wc.fillStyle = 'rgba(0,0,0,0.25)'; wc.fillRect(0, faceH * T - 2, bw * T, 2);
    var b = { x0: tx, y0: ty, bw: bw, bh: bh, faceH: faceH };
    w.img(roofCv, tx * T, ty * T); w.img(wallCv, tx * T, (ty + bh) * T);
    // тень от здания
    w.rect((tx + bw) * T, (ty + 1) * T, 5, (bh + faceH) * T, '#000', 0.18);
    w.rect(tx * T, (ty + bh + faceH) * T, bw * T, 5, '#000', 0.2);
    // непроходимо всё здание (кроме двери: вход — декоративный, внутрь заходить не нужно)
    for (var yy = 0; yy < bh + faceH; yy++) for (var xx = 0; xx < bw; xx++) { w.solid[(ty + yy) * WW + tx + xx] = 1; w.opaque[(ty + yy) * WW + tx + xx] = 1; }
    buildings.push(b);
  }
  var blockRects = [];
  blocks.forEach(function (bl, bi) {
    var W = bl.x1 - bl.x0, H = bl.y1 - bl.y0;
    if (W < 7 || H < 7) return;
    if (bl.x0 <= PL.x0 + 1 && bl.x1 >= PL.x1 - 1 && bl.y0 <= PL.y0 + 1 && bl.y1 >= PL.y1 - 1) return;
    // делим квартал на 1-3 здания по ширине
    var parts = W > 36 ? 3 : W > 22 ? 2 : 1, pw = Math.floor(W / parts);
    for (var p = 0; p < parts; p++) {
      var px0 = bl.x0 + p * pw + 1, bw = pw - 2 - (p === parts - 1 ? W - pw * parts : 0) + (p === parts - 1 ? 0 : 0);
      bw = Math.max(5, bw);
      var tall = rnd() < 0.5;
      var floors = tall ? 5 + Math.floor(rnd() * 5) : 2 + Math.floor(rnd() * 2);
      var bh = clamp(H - 2 - floors - (tall ? 0 : 1), 4, 10);
      if (px0 + bw > bl.x1 - 1) bw = bl.x1 - 1 - px0;
      if (bw < 5) continue;
      var ty0 = bl.y0 + 1 + Math.floor(rnd() * 2);
      // не вылезать за карту и в тротуар
      var maxFloors = Math.max(2, bl.y1 - 1 - (ty0 + bh));
      floors = Math.min(floors, maxFloors);
      if (ty0 + bh + floors > bl.y1 - 1) continue;
      var style = STY[Math.floor(rnd() * STY.length)];
      building(px0, ty0, bw, bh, floors, style);
      blockRects.push({ x0: px0, y0: ty0, x1: px0 + bw, y1: ty0 + bh + floors });
    }
  });
  // дворы: у каждого здания — деревья/кусты/скамейки на траве
  var dy = mulberry32(5);
  for (var ty = 0; ty < HH; ty++) for (var tx = 0; tx < WW; tx++) {
    if (kind[ty * WW + tx] !== CK.GRASS || w.solid[ty * WW + tx]) continue;
    var r = dy();
    var x = tx * T + 8, y = ty * T + 14;
    if (r < 0.05 && tx > 1 && ty > 1) { w.sprite('tree_city', x, y); w.addCircle(x, y - 2, 4); }
    else if (r < 0.1) w.sprite('bush' + Math.floor(dy() * 3), x, y);
    else if (r < 0.115) { w.sprite('hedge', x, y); w.addRect(x - 8, y - 6, x + 8, y); }
  }
  // фонарики и скамейки вдоль тротуаров
  for (var tx = 3; tx < WW - 2; tx += 8) HR.forEach(function (r) {
    if (!inRoadV(tx) && !inRoadV(tx + 1)) { w.sprite('lamp', tx * T + 8, (r - 3) * T + 12); w.addRect(tx * T + 6, (r - 3) * T + 6, tx * T + 10, (r - 3) * T + 12); }
  });
  for (var ty = 3; ty < HH - 2; ty += 8) VR.forEach(function (c) {
    if (!inRoadH(ty) && !inRoadH(ty + 1)) { w.sprite('lamp', (c + 3) * T + 8, ty * T + 12); w.addRect((c + 3) * T + 6, ty * T + 6, (c + 3) * T + 10, ty * T + 12); }
  });
  // машины на дорогах (стоят)
  [[6, 14], [30, 14], [66, 14], [90, 14], [24, 40], [74, 40], [10, 62], [60, 62], [95, 62]].forEach(function (p, i) {
    var names = ['car_red', 'car_blue', 'car_white'], x = p[0] * T, y = p[1] * T + 6 + (i % 2 ? 12 : -16);
    w.sprite(names[i % 3], x, y + 8); w.addRect(x - 16, y - 2, x + 16, y + 8);
  });
  [[48, 6], [48, 26], [82, 52], [14, 52], [14, 26]].forEach(function (p, i) {
    var x = p[0] * T - 6 + (i % 2 ? 14 : 0), y = p[1] * T; w.sprite(['car_white', 'car_red', 'car_blue'][i % 3], x, y + 8);
    w.addRect(x - 16, y - 2, x + 16, y + 8);
  });
  // фонтан на площади
  var fx = (PL.x0 + PL.x1) / 2 * T, fy = (PL.y0 + PL.y1) / 2 * T + 18;
  w.sprite('fountain', fx, fy); w.addCircle(fx, fy - 8, 22);
  [[PL.x0 + 1, PL.y0 + 1], [PL.x1 - 2, PL.y0 + 1], [PL.x0 + 1, PL.y1 - 1], [PL.x1 - 2, PL.y1 - 1]].forEach(function (p) {
    w.sprite('tree_city', p[0] * T + 8, p[1] * T + 14); w.addCircle(p[0] * T + 8, p[1] * T + 12, 4);
  });
  [[PL.x0 + 5, PL.y1 - 1], [PL.x1 - 6, PL.y1 - 1]].forEach(function (p) { w.sprite('bench', p[0] * T + 8, p[1] * T + 10); w.addRect(p[0] * T - 2, p[1] * T, p[0] * T + 18, p[1] * T + 10); });

  // ---------- вход в город, враги, цель ----------
  w.spawn = { x: 6 * T, y: 62 * T };
  w.goal = { x: fx, y: fy + 12, r: 34, text: 'Ты добрался до города!' };
  function at(tx, ty) { return w.freeNear(tx * T, ty * T, 5); }
  w.enemies = [
    Object.assign({ type: 'black', terr: 80 }, at(22, 62)), Object.assign({ type: 'orange', terr: 70 }, at(36, 40)),
    Object.assign({ type: 'black', terr: 80 }, at(66, 40)), Object.assign({ type: 'orange', terr: 70 }, at(48, 22)),
    Object.assign({ type: 'black', terr: 80 }, at(14, 28)), Object.assign({ type: 'orange', terr: 70 }, at(82, 28)),
    Object.assign({ type: 'black', terr: 80 }, at(62, 62)), Object.assign({ type: 'orange', terr: 70 }, at(88, 52))
  ];
  w.companions = [];
  w.vignette();
  w.finish();
  return w;
}
