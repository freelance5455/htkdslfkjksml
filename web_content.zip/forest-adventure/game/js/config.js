// Все основные настройки игры в одном месте
var CFG = {
  TILE: 16,                 // размер клетки в «игровых» пикселях
  VIEW_H: 170,              // сколько игровых пикселей видно по высоте экрана
  PLAYER_SPEED: 64,         // скорость игрока (px/сек)
  HEARTS_START: 3,          // стартовое число сердец
  JOIN_DISTANCE: 28,
  JOIN_CHANCE: 0.5,         // шанс, что напарник согласится объединиться (0.5 = 50%)
  JOIN_RETRY: 2.5,          // через сколько секунд можно пробовать снова
  TREE_HP: { tree_s: 3, tree_m: 5, tree_m2: 5, tree_l: 8, pine_s: 3, pine_m: 5, pine_l: 8, dead_tree: 2 },        // на каком расстоянии появляется кнопка «Объединиться»
  FOLLOW_GAP: 9,            // «шагов следа» между игроком и напарниками
  ENEMY: {
    // sight — дальность зрения, враг видит только в конусе перед собой (≈120°) и не видит сквозь стены/деревья
    black:  { sight: 85, wander: 20, chase: 50, hp: 5, name: 'чёрный' },
    orange: { sight: 65, wander: 24, chase: 58, hp: 4, name: 'оранжевый' }
  },
  // оружие: урон, дальность удара, пауза между ударами (сек)
  WEAPONS: {
    fist:  { label: 'Кулаки',    dmg: 1, reach: 15, cd: 0.40 },
    stick: { label: 'Палка',     dmg: 2, reach: 20, cd: 0.45 },
    pan:   { label: 'Сковорода', dmg: 2, reach: 17, cd: 0.50 },
    bat:   { label: 'Бита',      dmg: 3, reach: 22, cd: 0.55 }
  },
  COMPANION_ATTACK: { dmg: 1, cd: 0.75, reach: 14, speed: 52, helpRadius: 85 },
  COMPANION_COLORS: { green: '#6fd35f', yellow: '#ffe14a', blue: '#4aa3ff' }
};
