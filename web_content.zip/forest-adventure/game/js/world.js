// Игровой мир: земля (две картинки для анимации воды), столкновения, объекты, домики
var T = CFG.TILE;

function World(name, w, h) {
  this.name = name; this.w = w; this.h = h; this.pw = w * T; this.ph = h * T;
  this.kind = new Uint8Array(w * h);      // тип земли (для генерации)
  this.solid = new Uint8Array(w * h);     // 1 = клетка непроходима
  this.opaque = new Uint8Array(w * h);    // 1 = клетка закрывает обзор (стены домов, здания)
  this.breakables = [];                   // деревья, которые можно срубить
  this.cv = [mkCanvas(this.pw, this.ph), mkCanvas(this.pw, this.ph)];
  this.cx = [this.cv[0].getContext('2d'), this.cv[1].getContext('2d')];
  this.cx[0].imageSmoothingEnabled = false; this.cx[1].imageSmoothingEnabled = false;
  this.statics = [];        // объекты, которые сортируются по Y вместе с персонажами
  this.circles = []; this.rects = []; this.hash = {};
  this.houses = []; this.items = [];
  this.companions = []; this.enemies = [];
  this.spawn = { x: 40, y: 40 };
  this.exit = null; this.goal = null;
  this.hudHint = '';
}

World.prototype = {
  // ---------- рисование земли ----------
  tile: function (name, tx, ty, fx, fy) {
    for (var f = 0; f < 2; f++) {
      var n = name === 'water' ? 'water' + f : name;
      this._stamp(this.cx[f], Assets.get(n), tx * T, ty * T, fx, fy);
    }
  },
  img: function (name, x, y, fx, fy) {          // произвольная картинка в пикселях
    var im = typeof name === 'string' ? Assets.get(name) : name;
    for (var f = 0; f < 2; f++) this._stamp(this.cx[f], im, x, y, fx, fy);
  },
  _stamp: function (ctx, im, x, y, fx, fy) {
    if (!fx && !fy) { ctx.drawImage(im, x, y); return; }
    ctx.save(); ctx.translate(x + (fx ? im.width : 0), y + (fy ? im.height : 0));
    ctx.scale(fx ? -1 : 1, fy ? -1 : 1); ctx.drawImage(im, 0, 0); ctx.restore();
  },
  rect: function (x, y, w, h, color, alpha) {
    for (var f = 0; f < 2; f++) {
      var c = this.cx[f]; c.globalAlpha = alpha == null ? 1 : alpha; c.fillStyle = color; c.fillRect(x, y, w, h); c.globalAlpha = 1;
    }
  },
  idx: function (tx, ty) { return ty * this.w + tx; },
  inMap: function (tx, ty) { return tx >= 0 && ty >= 0 && tx < this.w && ty < this.h; },
  kindAt: function (tx, ty) { return this.inMap(tx, ty) ? this.kind[ty * this.w + tx] : 255; },

  // ---------- столкновения ----------
  _cell: 48,
  _insert: function (obj, x0, y0, x1, y1) {
    var c = this._cell;
    for (var cy = Math.floor(y0 / c); cy <= Math.floor(y1 / c); cy++)
      for (var cx = Math.floor(x0 / c); cx <= Math.floor(x1 / c); cx++) {
        var k = cx + cy * 4096; (this.hash[k] || (this.hash[k] = [])).push(obj);
      }
  },
  addCircle: function (x, y, r) { var o = { t: 0, x: x, y: y, r: r, off: false }; this.circles.push(o); this._insert(o, x - r, y - r, x + r, y + r); return o; },
  addRect: function (x0, y0, x1, y1) { var o = { t: 1, x0: x0, y0: y0, x1: x1, y1: y1 }; this.rects.push(o); this._insert(o, x0, y0, x1, y1); },
  tileSolid: function (px, py) {
    var tx = Math.floor(px / T), ty = Math.floor(py / T);
    if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h) return true;
    return this.solid[ty * this.w + tx] === 1;
  },
  blocked: function (x, y, r) {
    if (this.tileSolid(x - r, y - r) || this.tileSolid(x + r, y - r) || this.tileSolid(x - r, y + r) || this.tileSolid(x + r, y + r)) return true;
    var c = this._cell;
    for (var cy = Math.floor((y - r) / c); cy <= Math.floor((y + r) / c); cy++)
      for (var cx = Math.floor((x - r) / c); cx <= Math.floor((x + r) / c); cx++) {
        var list = this.hash[cx + cy * 4096]; if (!list) continue;
        for (var i = 0; i < list.length; i++) {
          var o = list[i];
          if (o.off) continue;
          if (o.t === 0) { var dx = x - o.x, dy = y - o.y, rr = r + o.r; if (dx * dx + dy * dy < rr * rr) return true; }
          else {
            var qx = clamp(x, o.x0, o.x1), qy = clamp(y, o.y0, o.y1), ex = x - qx, ey = y - qy;
            if (ex * ex + ey * ey < r * r) return true;
          }
        }
      }
    return false;
  },
  // видно ли точку (x1,y1) из (x0,y0): стены, здания и деревья закрывают обзор
  losClear: function (x0, y0, x1, y1) {
    var dx = x1 - x0, dy = y1 - y0, d = Math.hypot(dx, dy), n = Math.ceil(d / 3), c = this._cell;
    for (var i = 1; i < n; i++) {
      var px = x0 + dx * i / n, py = y0 + dy * i / n, tx = Math.floor(px / T), ty = Math.floor(py / T);
      if (tx >= 0 && ty >= 0 && tx < this.w && ty < this.h && this.opaque[ty * this.w + tx]) return false;
      if (i * 3 < 7 || d - i * 3 < 7) continue;               // у самих краёв деревья не мешают
      var list = this.hash[Math.floor(px / c) + Math.floor(py / c) * 4096];
      if (!list) continue;
      for (var k = 0; k < list.length; k++) {
        var o = list[k];
        if (o.t === 0 && !o.off && o.r >= 3.4) { var ex = px - o.x, ey = py - o.y, rr = o.r * 0.75; if (ex * ex + ey * ey < rr * rr) return false; }
      }
    }
    return true;
  },
  // срубить дерево: убираем картинку и препятствие, ставим пенёк
  breakTree: function (b) {
    b.broken = true; b.d.hidden = true; b.c.off = true;
    this.sprite('stump', b.x, b.y); this.finish();
  },
  // ближайшая свободная точка (для расстановки персонажей)
  freeNear: function (x, y, r) {
    r = r || 4;
    if (!this.blocked(x, y, r)) return { x: x, y: y };
    for (var d = 4; d < 140; d += 4)
      for (var a = 0; a < 6.28; a += 0.5) {
        var nx = x + Math.cos(a) * d, ny = y + Math.sin(a) * d;
        if (!this.blocked(nx, ny, r)) return { x: nx, y: ny };
      }
    return { x: x, y: y };
  },

  // ---------- объекты ----------
  // картинка, якорь — низ по центру
  sprite: function (name, x, y, solid) {
    var im = typeof name === 'string' ? Assets.get(name) : name;
    var d = { y: y, x: x - im.width / 2, top: y - im.height, w: im.width, h: im.height, img: im };
    this.statics.push(d);
    return d;
  },
  finish: function () { this.statics.sort(function (a, b) { return a.y - b.y; }); },

  // ---------- домик ----------
  // s: {x,y,w,h (клетки), door:[tx,tw], windows:[...], furniture:[[имя,tx,ty,solid],...], rug:[tx,ty]}
  house: function (s, rnd) {
    var W = this, x0 = s.x, y0 = s.y, w = s.w, h = s.h;
    var wallCv = mkCanvas(w * T, h * T), roofCv = mkCanvas(w * T, h * T);
    var wc = wallCv.getContext('2d'), rc = roofCv.getContext('2d');
    function put(ctx, name, tx, ty, fx, fy) { W._stamp(ctx, Assets.get(name), tx * T, ty * T, fx, fy); }
    var doorA = s.door[0], doorB = s.door[0] + s.door[1] - 1;
    // пол
    for (var ty = 1; ty < h - 1; ty++) for (var tx = 1; tx < w - 1; tx++) W.tile('floor' + (rnd() < 0.5 ? 0 : 1), x0 + tx, y0 + ty);
    for (var d = doorA; d <= doorB; d++) W.tile('doorstep', x0 + d, y0 + h - 1);
    if (s.rug) W.img('rug', (x0 + s.rug[0]) * T, (y0 + s.rug[1]) * T);
    // паутина в углах (на полу)
    W.tile('web_tl', x0 + 1, y0 + 1); W.tile('web_tr', x0 + w - 2, y0 + 1);
    W.tile('web_bl', x0 + 1, y0 + h - 2); W.tile('web_br', x0 + w - 2, y0 + h - 2);
    // стены
    var winH = s.windows || [];
    for (var tx = 0; tx < w; tx++) {
      var corner = (tx === 0 || tx === w - 1);
      var nm = corner ? 'wall_h_corner' : (winH.indexOf(tx) >= 0 ? 'window_h' : (rnd() < 0.18 ? 'wall_h_hole' : 'wall_h' + (rnd() < 0.3 ? 1 : 0)));
      put(wc, nm, tx, 0, tx === w - 1, false);
      if (!(tx >= doorA && tx <= doorB)) put(wc, corner ? 'wall_h_corner' : 'wall_h' + (rnd() < 0.3 ? 1 : 0), tx, h - 1, tx === w - 1, true);
      W.solid[(y0) * W.w + x0 + tx] = 1; W.opaque[(y0) * W.w + x0 + tx] = 1;
      if (!(tx >= doorA && tx <= doorB)) { W.solid[(y0 + h - 1) * W.w + x0 + tx] = 1; W.opaque[(y0 + h - 1) * W.w + x0 + tx] = 1; }
    }
    var midY = Math.floor(h / 2);
    for (var ty = 1; ty < h - 1; ty++) {
      var nmW = ty === midY ? 'window_v' : (rnd() < 0.2 ? 'wall_v_hole' : 'wall_v' + (rnd() < 0.3 ? 1 : 0));
      var nmE = ty === midY - 1 || ty === midY + 1 && h > 7 ? 'window_v' : (rnd() < 0.2 ? 'wall_v_hole' : 'wall_v' + (rnd() < 0.3 ? 1 : 0));
      put(wc, nmW, 0, ty, false, false); put(wc, nmE, w - 1, ty, true, false);
      W.solid[(y0 + ty) * W.w + x0] = 1; W.solid[(y0 + ty) * W.w + x0 + w - 1] = 1;
      W.opaque[(y0 + ty) * W.w + x0] = 1; W.opaque[(y0 + ty) * W.w + x0 + w - 1] = 1;
    }
    // паутина на внешних углах
    put(wc, 'web_br', 0, 0); put(wc, 'web_bl', w - 1, 0);
    // крыша
    for (var ty = 1; ty < h - 1; ty++) for (var tx = 1; tx < w - 1; tx++) {
      var r = rnd(); put(rc, 'roof' + (r < 0.05 ? 2 : r < 0.4 ? 1 : 0), tx, ty);
    }
    // мебель
    (s.furniture || []).forEach(function (f) {
      var im = Assets.get(f[0]);
      var ax = (x0 + f[1]) * T + im.width / 2, ay = (y0 + f[2]) * T + im.height;
      W.sprite(f[0], ax, ay);
      if (f[3]) W.addRect(ax - im.width / 2 + 1, ay - im.height + 2, ax + im.width / 2 - 1, ay);
    });
    var hs = {
      x0: x0, y0: y0, w: w, h: h, wallCv: wallCv, roofCv: roofCv, ra: 1, wa: 1,
      ix0: (x0 + 1) * T, ix1: (x0 + w - 1) * T, iy0: (y0 + 1) * T, iy1: (y0 + h - 1) * T + 8,
      bottom: (y0 + h) * T
    };
    this.houses.push(hs);
    this.statics.push({ y: hs.bottom, roof: hs, x: x0 * T, top: y0 * T, w: w * T, h: h * T });
    return hs;
  },
  houseAt: function (x, y) {
    for (var i = 0; i < this.houses.length; i++) {
      var h = this.houses[i];
      if (x >= h.ix0 && x < h.ix1 && y >= h.iy0 && y < h.iy1) return h;
    }
    return null;
  },
  // тень по краю карты, чтобы граница выглядела естественнее
  vignette: function () {
    var e = 10;
    this.rect(0, 0, this.pw, e, '#0a1a10', 0.35); this.rect(0, this.ph - e, this.pw, e, '#0a1a10', 0.35);
    this.rect(0, 0, e, this.ph, '#0a1a10', 0.35); this.rect(this.pw - e, 0, e, this.ph, '#0a1a10', 0.35);
  }
};

// расстановка: расстояние от «дороги» (многоисточниковый поиск в ширину)
function distanceField(world, isSource) {
  var w = world.w, h = world.h, d = new Int16Array(w * h).fill(999), q = [];
  for (var i = 0; i < w * h; i++) if (isSource(world.kind[i])) { d[i] = 0; q.push(i); }
  for (var qi = 0; qi < q.length; qi++) {
    var i = q[qi], x = i % w, y = (i / w) | 0;
    [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (o) {
      var nx = x + o[0], ny = y + o[1];
      if (nx < 0 || ny < 0 || nx >= w || ny >= h) return;
      var j = ny * w + nx;
      if (d[j] > d[i] + 1) { d[j] = d[i] + 1; q.push(j); }
    });
  }
  return d;
}
