// Персонажи: игрок, напарники, враги
var PLAYER_R = 5;

function Character(type, x, y) {
  this.type = type; this.x = x; this.y = y; this.dir = 'down'; this.anim = 0; this.moving = false; this.r = PLAYER_R;
}
Character.prototype.frame = function () {
  var d = this.dir, base = this.type;
  var step = this.moving ? (Math.floor(this.anim / 4) % 2 === 0 ? 1 : 2) : 0;
  var flip = false, key;
  if (d === 'left' || d === 'right') { key = base + '_side' + (step ? '_w' + step : ''); flip = (d === 'left'); }
  else {
    key = base + '_' + d + (step ? '_w' + step : '');
  }
  return { img: Assets.get(key), flip: flip };
};
Character.prototype.draw = function (ctx, cam, alpha) {
  var f = this.frame(), im = f.img;
  var ph = this.anim / 4, bob = this.moving ? -Math.abs(Math.sin(ph * 1.5707)) * 2 : 0;
  var sway = this.moving ? Math.sin(ph * 1.5707) * 0.09 : 0;
  var fx = Math.round(this.x - cam.x), fy = Math.round(this.y - cam.y);
  // тень
  ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.ellipse(fx, fy + 1, 8, 3, 0, 0, 6.3); ctx.fill();
  ctx.save();
  if (alpha != null && alpha < 1) ctx.globalAlpha = alpha;
  ctx.translate(fx, fy + 3 + Math.round(bob));      // начало координат — «ступни»
  ctx.rotate(sway);
  if (f.flip) ctx.scale(-1, 1);
  ctx.drawImage(im, -Math.round(im.width / 2), -im.height);
  ctx.restore();
};
Character.prototype.tryMove = function (world, dx, dy) {
  var moved = false;
  if (dx && !world.blocked(this.x + dx, this.y, this.r)) { this.x += dx; moved = true; }
  if (dy && !world.blocked(this.x, this.y + dy, this.r)) { this.y += dy; moved = true; }
  this.x = clamp(this.x, this.r + 1, world.pw - this.r - 1); this.y = clamp(this.y, this.r + 1, world.ph - this.r - 1);
  return moved;
};
Character.prototype.face = function (dx, dy) {
  if (Math.abs(dx) > Math.abs(dy)) this.dir = dx > 0 ? 'right' : 'left'; else if (dy) this.dir = dy > 0 ? 'down' : 'up';
};

// ---------- Игрок ----------
function Player(x, y) {
  Character.call(this, 'hero', x, y);
  this.trail = []; this.hearts = CFG.HEARTS_START; this.invul = 0; this.stun = 0; this.hurtFlash = 0;
  this.weapon = 'fist'; this.atkCd = 0;
}
Player.prototype = Object.create(Character.prototype);
Player.prototype.update = function (dt, world, vec) {
  var sp = CFG.PLAYER_SPEED, mx = vec.x * sp * dt, my = vec.y * sp * dt;
  this.moving = false;
  if (this.stun > 0) { this.stun -= dt; mx = my = 0; }
  if (mx || my) {
    this.face(vec.x, vec.y);
    // разбиваем на мелкие шаги, чтобы не пролетать сквозь объекты
    var n = Math.ceil(Math.max(Math.abs(mx), Math.abs(my)) / 1.5), ok = false;
    for (var i = 0; i < n; i++) ok = this.tryMove(world, mx / n, my / n) || ok;
    this.moving = ok; if (ok) this.anim += dt * 60 * Math.hypot(vec.x, vec.y);
  }
  if (this.invul > 0) this.invul -= dt;
  if (this.atkCd > 0) this.atkCd -= dt;
  // «след» для напарников
  var last = this.trail[0];
  if (!last || dist(last.x, last.y, this.x, this.y) > 2.2) { this.trail.unshift({ x: this.x, y: this.y }); if (this.trail.length > 400) this.trail.length = 400; }
};

// ---------- Напарник ----------
function Companion(type, x, y) {
  Character.call(this, type, x, y);
  this.joined = false; this.index = 0; this.t = Math.random() * 6; this.stun = 0; this.cool = 0; this.refuseT = 0;
}
Companion.prototype = Object.create(Character.prototype);
Companion.prototype.update = function (dt, world, player, team, game) {
  this.t += dt;
  this.moving = false;
  if (this.refuseT > 0) this.refuseT -= dt;
  if (!this.joined) return;                       // ждёт, пока его позовут
  if (this.cool > 0) this.cool -= dt;
  if (this.stun > 0) { this.stun -= dt; return; } // оглушён врагом
  var CA = CFG.COMPANION_ATTACK;

  // --- драка: ищем ближайшего врага рядом с игроком ---
  var foe = null, bd = 1e9;
  game.enemies.forEach(function (e) {
    if (e.dead) return;
    var dp = dist(e.x, e.y, player.x, player.y), dm = dist(e.x, e.y, this.x, this.y);
    if (dp < CA.helpRadius && dm < bd) { bd = dm; foe = e; }
  }, this);
  if (foe) {
    var fdx = foe.x - this.x, fdy = foe.y - this.y, fd = Math.hypot(fdx, fdy) || 1;
    this.face(fdx, fdy);
    if (fd > CA.reach - 3) {
      var sp = CA.speed * dt, vx = fdx / fd * sp, vy = fdy / fd * sp;
      var m = this.tryMove(world, vx, vy) || this.tryMove(world, -vy, vx) || this.tryMove(world, vy, -vx);
      this.moving = m; if (m) this.anim += dt * 60;
    } else if (this.cool <= 0) {
      this.cool = CA.cd;
      game.swing(this, CA.dmg, CA.reach, 'punch');
    }
    return;
  }

  // --- обычное следование за игроком ---
  var gap = CFG.FOLLOW_GAP * (this.index + 1);
  var target = player.trail[Math.min(gap, player.trail.length - 1)] || player;
  var dx = target.x - this.x, dy = target.y - this.y, d = Math.hypot(dx, dy);
  if (d > 1.2) {
    var speed = Math.min(CFG.PLAYER_SPEED * 1.25, 30 + d * 4) * dt;
    var vx = dx / d * Math.min(speed, d), vy = dy / d * Math.min(speed, d);
    for (var i = 0; i < team.length; i++) {
      var o = team[i]; if (o === this) continue;
      var ox = this.x - o.x, oy = this.y - o.y, od = Math.hypot(ox, oy);
      if (od < 12 && od > 0.01) { vx += ox / od * (12 - od) * 0.12; vy += oy / od * (12 - od) * 0.12; }
    }
    var pdx = this.x - player.x, pdy = this.y - player.y, pd = Math.hypot(pdx, pdy);
    if (pd < 11 && pd > 0.01) { vx += pdx / pd * (11 - pd) * 0.15; vy += pdy / pd * (11 - pd) * 0.15; }
    var m2 = this.tryMove(world, vx, vy);
    if (!m2) m2 = this.tryMove(world, -vy, vx) || this.tryMove(world, vy, -vx);
    this.moving = m2;
    this.face(vx, vy); if (m2) this.anim += dt * 60;
    if (d > 150) { var p = world.freeNear(target.x, target.y, 5); this.x = p.x; this.y = p.y; }
  } else { this.face(player.x - this.x, player.y - this.y); }
};

// ---------- Враг ----------
var DV = { right: [1, 0], left: [-1, 0], down: [0, 1], up: [0, -1] };
var DIR_LIST = ['down', 'up', 'left', 'right'];

function Enemy(type, x, y, terr) {
  Character.call(this, type, x, y);
  this.hx = x; this.hy = y; this.terr = terr || 70;
  this.state = 'idle'; this.t = Math.random() * 3; this.tx = x; this.ty = y; this.cool = 0; this.alert = 0;
  this.cfg = CFG.ENEMY[type]; this.hp = this.cfg.hp; this.flash = 0; this.dead = false; this.fade = 1;
  this.dir = DIR_LIST[Math.floor(Math.random() * 4)];
  this.lookT = 1 + Math.random() * 2;      // когда повернуть голову
  this.seeT = 0; this.seen = null;         // кого видит сейчас
  this.memory = 0; this.lx = x; this.ly = y; this.target = null;   // куда бежать, если потерял из виду
  this.searchT = 0; this.stuckT = 0; this.walk = false;
}
Enemy.prototype = Object.create(Character.prototype);

// Может ли враг увидеть цель t? Нужно: рядом ИЛИ в конусе обзора, в пределах дальности и без стен/деревьев между ними.
Enemy.prototype.canSee = function (world, t, chasing) {
  var dx = t.x - this.x, dy = t.y - this.y, d = Math.hypot(dx, dy);
  var range = this.cfg.sight * (chasing ? 1.4 : 1);
  if (d > range) return false;
  if (!chasing && d >= 10) {
    var v = DV[this.dir];
    if ((dx * v[0] + dy * v[1]) / d < 0.5) return false;       // вне конуса ≈120°
  }
  return world.losClear(this.x, this.y, t.x, t.y);
};
Enemy.prototype.hurt = function (dmg, fromX, fromY, world) {
  if (this.dead) return;
  this.hp -= dmg; this.flash = 0.25;
  var dx = this.x - fromX, dy = this.y - fromY, d = Math.hypot(dx, dy) || 1;
  for (var i = 0; i < 5; i++) this.tryMove(world, dx / d * 1.6, dy / d * 1.6);   // отталкивание
  this.memory = 3; this.lx = fromX; this.ly = fromY;                              // знает, откуда ударили
  this.face(-dx, -dy);
  if (this.hp <= 0) { this.dead = true; this.fade = 1; }
  else { this.state = 'stunned'; this.t = 0.4; }
};
Enemy.prototype.update = function (dt, world, player, game) {
  var cfg = this.cfg;
  if (this.flash > 0) this.flash -= dt;
  if (this.dead) { this.fade -= dt * 1.4; this.moving = false; return; }
  this.moving = false;
  if (this.cool > 0) this.cool -= dt;
  if (this.state === 'stunned') { this.t -= dt; if (this.t <= 0) this.state = this.memory > 0 ? 'chase' : 'idle'; return; }

  // --- зрение (проверяем несколько раз в секунду) ---
  this.seeT -= dt;
  if (this.seeT <= 0) {
    this.seeT = 0.12;
    var chasing = this.state === 'chase', cands = [player].concat(game.team), best = null, bd = 1e9;
    for (var i = 0; i < cands.length; i++) {
      var c = cands[i], dd = dist(this.x, this.y, c.x, c.y);
      if (dd < bd && this.canSee(world, c, chasing)) { bd = dd; best = c; }
    }
    this.seen = best;
  }
  var seen = this.seen;
  if (seen) {
    if (this.state !== 'chase') { this.alert = 0.45; this.state = 'chase'; }
    this.memory = 3; this.lx = seen.x; this.ly = seen.y; this.target = seen;
  } else if (this.state === 'chase') {
    this.memory -= dt;
    if (this.memory <= 0 || dist(this.x, this.y, this.lx, this.ly) < 6) { this.state = 'search'; this.searchT = 1.8; this.lookT = 0; }
  }
  if (this.state === 'chase' && dist(this.x, this.y, this.hx, this.hy) > 220) this.memory = 0;   // не уходит слишком далеко от дома
  if (this.alert > 0) { this.alert -= dt; return; }

  var spd = 0, tx = this.x, ty = this.y;
  if (this.state === 'chase') {
    spd = cfg.chase; tx = this.lx; ty = this.ly;
    var tg = this.target;
    if (seen && tg && dist(this.x, this.y, tg.x, tg.y) < 9 && this.cool <= 0) {
      if (tg === player) { if (player.invul <= 0) { game.hitPlayer(this); this.cool = 1.2; this.state = 'stunned'; this.t = 1.1; return; } }
      else { tg.stun = 1.2; this.cool = 1.2; this.state = 'stunned'; this.t = 0.9; return; }
    }
  } else if (this.state === 'search') {                 // потерял из виду — осматривается
    this.searchT -= dt; this.lookT -= dt;
    if (this.lookT <= 0) { this.dir = DIR_LIST[Math.floor(Math.random() * 4)]; this.lookT = 0.45; }
    if (this.searchT <= 0) this.state = 'return';
  } else if (this.state === 'return') {
    spd = cfg.wander * 1.6; tx = this.hx; ty = this.hy;
    if (dist(this.x, this.y, tx, ty) < 6) this.state = 'idle';
  } else {                                             // idle: гуляет рядом с домом и оглядывается
    this.t -= dt; this.lookT -= dt;
    if (this.lookT <= 0 && !this.walk) { this.dir = DIR_LIST[Math.floor(Math.random() * 4)]; this.lookT = 1.4 + Math.random() * 2; }
    if (this.t <= 0) {
      this.t = 1.5 + Math.random() * 3;
      if (Math.random() < 0.55) { var a = Math.random() * 6.28, r = Math.random() * 24; this.tx = this.hx + Math.cos(a) * r; this.ty = this.hy + Math.sin(a) * r; this.walk = true; }
      else this.walk = false;
    }
    if (this.walk && dist(this.x, this.y, this.tx, this.ty) > 3) { spd = cfg.wander; tx = this.tx; ty = this.ty; } else this.walk = false;
  }
  if (spd) {
    var dx = tx - this.x, dy = ty - this.y, d = Math.hypot(dx, dy) || 1, vx = dx / d * spd * dt, vy = dy / d * spd * dt;
    var m = this.tryMove(world, vx, vy);
    if (!m) { m = this.tryMove(world, -vy * 1.5, vx * 1.5) || this.tryMove(world, vy * 1.5, -vx * 1.5); }
    this.moving = m; this.face(vx, vy); if (m) this.anim += dt * 60;
    // упёрся и не может пройти — не лезет «на пролом», а сдаётся и ищет
    if (this.state === 'chase') { this.stuckT = m ? 0 : this.stuckT + dt; if (this.stuckT > 0.9) { this.memory = 0; this.stuckT = 0; } }
  }
};
