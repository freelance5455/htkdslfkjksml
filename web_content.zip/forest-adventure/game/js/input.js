// Управление: виртуальный джойстик (сенсор) + клавиатура для проверки на компьютере
var Input = {
  canvas: null, W: 1, H: 1, keys: {}, onInteract: null, onAttack: null,
  joy: { active: false, id: -1, bx: 0, by: 0, kx: 0, ky: 0, R: 60 },
  vec: function () {
    var j = this.joy, x = 0, y = 0;
    if (j.active) {
      x = (j.kx - j.bx) / j.R; y = (j.ky - j.by) / j.R;
      var m = Math.hypot(x, y);
      if (m < 0.18) { x = y = 0; } else if (m > 1) { x /= m; y /= m; }
    }
    var k = this.keys;
    var kx = (k.ArrowRight || k.KeyD ? 1 : 0) - (k.ArrowLeft || k.KeyA ? 1 : 0);
    var ky = (k.ArrowDown || k.KeyS ? 1 : 0) - (k.ArrowUp || k.KeyW ? 1 : 0);
    if (kx || ky) { var m2 = Math.hypot(kx, ky); x = kx / m2; y = ky / m2; }
    return { x: x, y: y };
  },
  defaultBase: function () {
    this.joy.R = Math.round(this.H * 0.17);
    return { x: this.joy.R * 1.5 + this.H * 0.03, y: this.H - this.joy.R * 1.5 - this.H * 0.03 };
  },
  init: function (canvas) {
    var self = this, j = this.joy;
    this.canvas = canvas;
    function pos(e) {
      var r = canvas.getBoundingClientRect();
      return { x: (e.clientX - r.left) * canvas.width / r.width, y: (e.clientY - r.top) * canvas.height / r.height };
    }
    canvas.addEventListener('pointerdown', function (e) {
      var p = pos(e);
      if (j.active || p.x > canvas.width * 0.55) return;
      try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
      j.active = true; j.id = e.pointerId;
      j.R = Math.round(self.H * 0.17);
      j.bx = clamp(p.x, j.R * 1.2, canvas.width * 0.5); j.by = clamp(p.y, canvas.height * 0.3, canvas.height - j.R * 1.2);
      j.kx = p.x; j.ky = p.y;
      e.preventDefault();
    });
    canvas.addEventListener('pointermove', function (e) {
      if (!j.active || e.pointerId !== j.id) return;
      var p = pos(e); j.kx = p.x; j.ky = p.y; e.preventDefault();
    });
    function up(e) { if (j.active && e.pointerId === j.id) { j.active = false; j.id = -1; } }
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    window.addEventListener('keydown', function (e) {
      self.keys[e.code] = true;
      if ((e.code === 'KeyE' || e.code === 'Enter') && self.onInteract) self.onInteract();
      if ((e.code === 'Space' || e.code === 'KeyF') && self.onAttack) self.onAttack();
      if (e.code.indexOf('Arrow') === 0 || e.code === 'Space') e.preventDefault();
    });
    window.addEventListener('keyup', function (e) { self.keys[e.code] = false; });
    window.addEventListener('blur', function () { self.keys = {}; j.active = false; });
  }
};
