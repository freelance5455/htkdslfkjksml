#!/usr/bin/env python3
"""Генератор пиксельных текстур «Лесного приключения».

Все картинки создаются в папку game/assets/.  Любую из них можно просто заменить своим PNG
(с тем же именем) — игра подхватит её автоматически.

Запуск:  python3 tools/make_assets.py
"""
import math, os, random, subprocess, sys
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "game", "assets")
SRC_SPRITES = os.path.join(ROOT, "tools", "source_sprites")
for d in ("tiles", "objects", "characters"):
    os.makedirs(os.path.join(OUT, d), exist_ok=True)

R = random.Random(11)


def C(h, a=255):
    if len(h) == 4:
        h = "#" + "".join(ch * 2 for ch in h[1:])
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)


# ---------- единая палитра ----------
P = dict(
    g0=C("#235a33"), g1=C("#2f7a3a"), g2=C("#3c9444"), g3=C("#52ad55"), g4=C("#7cc96a"),
    dirt=C("#a67c4a"), dirt_d=C("#8a6338"), dirt_l=C("#bd9660"), pebble=C("#6f5a45"),
    sand=C("#d9c88e"), sand_d=C("#c3b176"),
    w0=C("#2a5f9e"), w1=C("#357bc0"), w2=C("#4f9ae0"), w3=C("#bfe2ff"),
    wood=C("#8a5a2b"), wood_l=C("#a87038"), wood_d=C("#5e3a1c"), wood_dd=C("#3d2411"),
    wall=C("#5f9150"), wall_l=C("#7bb266"), wall_d=C("#456f3a"), wall_dd=C("#2c4a27"),
    roof=C("#6e5238"), roof_l=C("#8a6a4a"), roof_d=C("#4c3825"), moss=C("#527f3c"),
    hole=C("#14110d"), glass=C("#a9c9d6"), glass_d=C("#6f8d9b"),
    web=(236, 236, 240, 210),
    ash=C("#3d3f46"), ash_l=C("#4a4d55"), ash_d=C("#2f3036"),
    walk=C("#bdbdb5"), walk_d=C("#a4a49c"), walk_s=C("#8a8a84"),
    cob=C("#9b8f7e"), cob_d=C("#7f7466"), cob_l=C("#b3a794"),
    ink=C("#101418"),
)
T = (0, 0, 0, 0)


def new(w=16, h=16, fill=T):
    return Image.new("RGBA", (w, h), fill)


def px(im, x, y, c):
    if 0 <= x < im.width and 0 <= y < im.height:
        im.putpixel((x, y), c)


def specks(im, colors, n):
    for _ in range(n):
        px(im, R.randrange(im.width), R.randrange(im.height), R.choice(colors))


def save(kind, name, im):
    im.save(os.path.join(OUT, kind, name + ".png"))
    MANIFEST.append(kind + "/" + name)


MANIFEST = []

# =============== ТАЙЛЫ 16x16 ===============

def grass(var):
    im = new(16, 16, P["g2"])
    specks(im, [P["g1"], P["g1"], P["g3"]], 22)
    for _ in range(3):
        x, y = R.randrange(1, 15), R.randrange(3, 15)
        px(im, x, y, P["g4"]); px(im, x, y - 1, P["g4"]); px(im, x + 1, y - 2, P["g3"])
        px(im, x - 1, y, P["g1"])
    return im


for i in range(4):
    save("tiles", f"grass{i}", grass(i))
for i, (a, b) in enumerate([(C("#ffffff"), C("#ffd84a")), (C("#ff9bd0"), C("#ffffff")), (C("#c9a6ff"), C("#ffd84a"))]):
    im = grass(i)
    for _ in range(3):
        x, y = R.randrange(2, 14), R.randrange(2, 14)
        px(im, x, y, a); px(im, x + 1, y, a); px(im, x, y + 1, a); px(im, x - 1, y, a); px(im, x, y - 1, a)
        px(im, x, y, b)
    save("tiles", f"flower{i}", im)

for i in range(3):
    im = new(16, 16, P["dirt"])
    specks(im, [P["dirt_d"], P["dirt_l"], P["dirt_d"]], 26)
    for _ in range(2):
        x, y = R.randrange(1, 14), R.randrange(1, 14)
        px(im, x, y, P["pebble"]); px(im, x + 1, y, P["pebble"]); px(im, x, y + 1, P["dirt_d"])
    save("tiles", f"dirt{i}", im)

for i in range(2):
    im = new(16, 16, P["sand"]); specks(im, [P["sand_d"], P["dirt_l"]], 18)
    save("tiles", f"sand{i}", im)

for f in range(2):
    im = new(16, 16, P["w1"])
    specks(im, [P["w0"], P["w2"]], 14)
    for k in range(3):
        x = (R.randrange(0, 12) + f * 5) % 13
        y = 2 + k * 5 + R.randrange(0, 3)
        for dx in range(3 + R.randrange(2)):
            px(im, x + dx, y, P["w2"])
        px(im, x + 1, y - 1, P["w3"])
    save("tiles", f"water{f}", im)

# мостик: доски поперёк (путь идёт горизонтально)
im = new(16, 16, P["wood"])
for k in range(4):
    x0 = k * 4
    for y in range(16):
        px(im, x0, y, P["wood_d"])
        px(im, x0 + 1, y, P["wood_l"] if (y + k) % 5 else P["wood"])
        px(im, x0 + 2, y, P["wood"]); px(im, x0 + 3, y, P["wood"])
    px(im, x0 + 1, 2, P["wood_dd"]); px(im, x0 + 1, 13, P["wood_dd"])
save("tiles", "bridge", im)
for name, ys in (("rail_top", (0, 1, 2, 3)), ("rail_bottom", (12, 13, 14, 15))):
    im = new(16, 16)
    y0 = ys[0]
    for x in range(16):
        px(im, x, y0 + 1, P["wood_l"]); px(im, x, y0 + 2, P["wood"])
        px(im, x, y0 + 3, P["wood_d"])
    for x in (0, 8):
        for y in ys:
            px(im, x, y, P["wood_dd"]); px(im, x + 1, y, P["wood_d"])
    save("tiles", name, im)

# пол в домиках
for i in range(2):
    im = new(16, 16, P["wood_d"])
    for k in range(4):
        y0 = k * 4
        for x in range(16):
            px(im, x, y0, P["wood_dd"])
            px(im, x, y0 + 1, P["wood"] if (x + k * 3 + i) % 11 else P["wood_d"])
            px(im, x, y0 + 2, P["wood_d"]); px(im, x, y0 + 3, P["wood_d"])
    specks(im, [P["wood_dd"], P["wood"]], 6)
    save("tiles", f"floor{i}", im)
im = new(16, 16, P["wood_d"])
for x in range(16):
    for y in range(16):
        if (x // 4 + y // 4) % 2: px(im, x, y, P["wood"])
specks(im, [P["wood_dd"]], 8)
save("tiles", "doorstep", im)

# стены (зелёные брусья)
def wall(vertical, variant=""):
    im = new(16, 16, P["wall"])
    for k in range(4):
        o = k * 4
        for t in range(16):
            a, b = ((o, t) if vertical else (t, o))
            px(im, a, b, P["wall_dd"])
            a1, b1 = ((o + 1, t) if vertical else (t, o + 1))
            px(im, a1, b1, P["wall_l"] if t % 7 else P["wall"])
            a2, b2 = ((o + 3, t) if vertical else (t, o + 3))
            px(im, a2, b2, P["wall_d"])
    specks(im, [P["wall_d"], P["wall_l"]], 10)
    if variant == "crack":
        x, y = 5, 2
        for _ in range(11):
            px(im, x, y, P["wall_dd"]); x += R.choice([0, 1]); y += 1
    if variant == "hole":
        cx, cy = 8, 8
        for yy in range(16):
            for xx in range(16):
                d = math.hypot(xx - cx, yy - cy) + R.random() * 1.6
                if d < 4.2: px(im, xx, yy, P["hole"])
                elif d < 5.4: px(im, xx, yy, P["wood_dd"])
    if variant == "corner":
        for xx in range(0, 7):
            for yy in range(0, 6):
                if xx + yy < 7 + R.randrange(2): px(im, xx, yy, P["hole"])
    return im


for v in (False, True):
    s = "v" if v else "h"
    save("tiles", f"wall_{s}0", wall(v)); save("tiles", f"wall_{s}1", wall(v, "crack"))
    save("tiles", f"wall_{s}_hole", wall(v, "hole")); save("tiles", f"wall_{s}_corner", wall(v, "corner"))


def window(vertical):
    im = wall(vertical)
    d = ImageDraw.Draw(im)
    d.rectangle((3, 3, 12, 12), fill=P["wood_dd"])
    d.rectangle((4, 4, 11, 11), fill=P["glass"])
    d.line((4, 4, 11, 11), fill=P["glass_d"]); d.line((11, 4, 4, 11), fill=P["glass_d"])
    d.line((8, 4, 8, 11), fill=P["wood_dd"]); d.line((4, 8, 11, 8), fill=P["wood_dd"])
    # выбитые куски
    for (x0, y0, x1, y1) in ((4, 4, 7, 6), (9, 9, 11, 11)):
        d.rectangle((x0, y0, x1, y1), fill=P["hole"])
    px(im, 6, 7, P["web"]); px(im, 10, 5, (255, 255, 255, 255))
    return im


save("tiles", "window_h", window(False)); save("tiles", "window_v", window(True))

for name, (xs, ys) in dict(tl=(1, 1), tr=(-1, 1), bl=(1, -1), br=(-1, -1)).items():
    im = new(16, 16)
    ox = 0 if xs > 0 else 15
    oy = 0 if ys > 0 else 15
    for r in (6, 10, 14):
        for a in range(0, 91, 4):
            x = ox + xs * int(r * math.cos(math.radians(a)))
            y = oy + ys * int(r * math.sin(math.radians(a)))
            px(im, x, y, P["web"])
    for a in (0, 25, 45, 65, 90):
        for r in range(0, 15):
            x = ox + xs * int(r * math.cos(math.radians(a)))
            y = oy + ys * int(r * math.sin(math.radians(a)))
            px(im, x, y, P["web"])
    save("tiles", f"web_{name}", im)

# крыша
def roof(v):
    im = new(16, 16, P["roof"])
    for row in range(4):
        y0 = row * 4
        off = 4 if row % 2 else 0
        for x in range(16):
            px(im, x, y0 + 3, P["roof_d"])
            if (x + off) % 8 == 0: 
                for yy in range(4): px(im, x, y0 + yy, P["roof_d"])
            px(im, x, y0, P["roof_l"] if (x + off) % 8 else P["roof_d"])
    specks(im, [P["roof_d"], P["roof_l"]], 8)
    if v == 1:
        for _ in range(14): px(im, R.randrange(2, 14), R.randrange(2, 14), P["moss"])
        for _ in range(8): px(im, R.randrange(16), R.randrange(16), P["g3"])
    if v == 2:
        cx, cy = 8, 8
        for yy in range(16):
            for xx in range(16):
                d = math.hypot(xx - cx, yy - cy) + R.random() * 2
                if d < 4: px(im, xx, yy, P["hole"])
                elif d < 5.5: px(im, xx, yy, P["roof_d"])
    return im


for v in range(3):
    save("tiles", f"roof{v}", roof(v))

# ---------- город ----------
for i in range(2):
    im = new(16, 16, P["ash"]); specks(im, [P["ash_l"], P["ash_d"]], 26)
    save("tiles", f"asphalt{i}", im)
for i in range(2):
    im = new(16, 16, P["walk"])
    for x in range(16): px(im, x, 7 + i, P["walk_d"]); px(im, x, 15, P["walk_s"])
    for y in range(16): px(im, 7 + i, y, P["walk_d"]); px(im, 15, y, P["walk_s"])
    specks(im, [P["walk_d"]], 5)
    save("tiles", f"sidewalk{i}", im)
for i in range(2):
    im = new(16, 16, P["cob"])
    for r in range(4):
        y0 = r * 4
        for x in range(16): px(im, x, y0 + 3, P["cob_d"])
        for x0 in range(0 if r % 2 else 4, 16, 8):
            for yy in range(4): px(im, x0, y0 + yy, P["cob_d"])
    specks(im, [P["cob_l"], P["cob_d"]], 8)
    save("tiles", f"cobble{i}", im)
im = new(16, 16, C("#d5cfbf"))
for x in range(16):
    for y in range(16):
        if (x // 8 + y // 8) % 2: px(im, x, y, C("#c3bcab"))
for x in range(16): px(im, x, 0, C("#a89f8b")); px(im, x, 8, C("#a89f8b"))
for y in range(16): px(im, 0, y, C("#a89f8b")); px(im, 8, y, C("#a89f8b"))
save("tiles", "plaza", im)

STYLES = {
    "brick": dict(wall=C("#a4523f"), dark=C("#7e3b2d"), light=C("#be6a55"), roof=C("#6b6f78"), win=C("#27384e")),
    "concrete": dict(wall=C("#8f969e"), dark=C("#6c737b"), light=C("#a9b0b8"), roof=C("#5d636b"), win=C("#26323f")),
    "beige": dict(wall=C("#d3bd90"), dark=C("#b09b72"), light=C("#e6d4aa"), roof=C("#8a5a45"), win=C("#35465a")),
    "glass": dict(wall=C("#4c7099"), dark=C("#365578"), light=C("#6d93bd"), roof=C("#3c4a5c"), win=C("#9fd0f0")),
    "green": dict(wall=C("#6f9570"), dark=C("#557a57"), light=C("#8cb28d"), roof=C("#6a4a3a"), win=C("#2c3e48")),
}
LIT = C("#f6df7e")
for name, s in STYLES.items():
    for var in range(2):
        im = new(16, 16, s["wall"])
        for x in range(16): px(im, x, 0, s["light"]); px(im, x, 15, s["dark"])
        wc = LIT if var else s["win"]
        if name == "glass":
            for x in range(1, 15):
                for y in range(2, 14): px(im, x, y, s["win"] if (x + y) % 6 else s["light"])
            for x in range(1, 15): px(im, x, 8, s["dark"])
        else:
            for x in range(4, 12):
                for y in range(3, 12): px(im, x, y, wc)
            for y in range(3, 12): px(im, 8, y, s["dark"])
            for x in range(4, 12): px(im, x, 7, s["dark"])
            for x in range(3, 13): px(im, x, 12, s["dark"])
        save("tiles", f"bld_{name}_wall{var}", im)
    im = new(16, 16, s["wall"])
    for x in range(16): px(im, x, 0, s["light"]); px(im, x, 15, s["dark"])
    d = ImageDraw.Draw(im)
    d.rectangle((4, 2, 11, 15), fill=C("#3a2b22")); d.rectangle((5, 3, 10, 15), fill=C("#6b4a32"))
    d.rectangle((8, 9, 9, 10), fill=C("#e0c070"))
    save("tiles", f"bld_{name}_door", im)
    im = new(16, 16, s["wall"])
    d = ImageDraw.Draw(im)
    d.rectangle((1, 4, 14, 14), fill=C("#1f2a36")); d.rectangle((2, 5, 13, 13), fill=C("#8fc4d8"))
    d.line((2, 5, 6, 9), fill=C("#c8e6f0")); d.line((5, 5, 9, 9), fill=C("#c8e6f0"))
    d.rectangle((1, 1, 14, 3), fill=s["dark"])
    save("tiles", f"bld_{name}_shop", im)
    im = new(16, 16, s["roof"])
    specks(im, [tuple(max(0, c - 14) for c in s["roof"][:3]) + (255,), tuple(min(255, c + 12) for c in s["roof"][:3]) + (255,)], 22)
    save("tiles", f"bld_{name}_roof", im)
    im = new(16, 16, s["roof"])
    for x in range(16): px(im, x, 0, s["dark"]); px(im, x, 1, s["light"]); px(im, x, 15, s["dark"])
    specks(im, [s["dark"]], 8)
    save("tiles", f"bld_{name}_edge", im)

# =============== ОБЪЕКТЫ ===============

def shade_blob(w, h, tones, outline, seed, bumps=(5, 9), wob=0.07, hl=(0.5, 0.6), grain=0.22):
    r = random.Random(seed)
    im = new(w, h)
    ph1, ph2 = r.random() * 6, r.random() * 6
    cx, cy = (w - 1) / 2, (h - 1) / 2
    inside = [[False] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            dx, dy = (x - cx) / (w / 2), (y - cy) / (h / 2)
            a = math.atan2(dy, dx)
            rb = 1 + wob * math.sin(bumps[0] * a + ph1) + wob * 0.7 * math.sin(bumps[1] * a + ph2) - 0.06
            if math.hypot(dx, dy) <= rb:
                inside[y][x] = True
                light = -(dx * hl[0] + dy * hl[1]) + (r.random() - 0.5) * grain * 2
                idx = 3 if light > 0.55 else 2 if light > 0.1 else 1 if light > -0.45 else 0
                im.putpixel((x, y), tones[idx])
    for y in range(h):
        for x in range(w):
            if inside[y][x]:
                edge = False
                for ddx, ddy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + ddx, y + ddy
                    if nx < 0 or ny < 0 or nx >= w or ny >= h or not inside[ny][nx]:
                        edge = True
                if edge: im.putpixel((x, y), outline)
    return im


LEAF = [P["g0"], P["g1"], P["g2"], P["g4"]]
LEAF2 = [C("#1e4b2c"), C("#27663a"), C("#348049"), C("#5fb06a")]
LEAF3 = [C("#2d5a2a"), C("#3f7a2c"), C("#5d9a33"), C("#93c24a")]
OUTL = C("#12301d")


def tree(cw, ch, trunk_w, trunk_h, tones, seed):
    w, h = cw, ch + trunk_h - 3
    im = new(w, h)
    tx = (w - trunk_w) // 2
    for y in range(h - trunk_h, h):
        for x in range(tx, tx + trunk_w):
            c = P["wood"] if x < tx + trunk_w - 1 else P["wood_d"]
            if x == tx: c = P["wood_l"]
            px(im, x, y, c)
    for x in range(tx - 1, tx + trunk_w + 1):
        px(im, x, h - 1, P["wood_dd"])
    px(im, tx - 1, h - 2, P["wood_d"]); px(im, tx + trunk_w, h - 2, P["wood_d"])
    can = shade_blob(cw, ch, tones, OUTL, seed)
    im.alpha_composite(can, (0, 0))
    return im


save("objects", "tree_s", tree(22, 20, 4, 7, LEAF, 1))
save("objects", "tree_m", tree(30, 27, 5, 8, LEAF, 2))
save("objects", "tree_l", tree(40, 35, 6, 10, LEAF2, 3))
save("objects", "tree_m2", tree(32, 28, 5, 8, LEAF3, 4))


def pine(w, h, seed):
    im = new(w, h)
    r = random.Random(seed)
    tx = w // 2 - 2
    for y in range(h - 7, h):
        for x in range(tx, tx + 4):
            px(im, x, y, P["wood_d"] if x > tx + 1 else P["wood"])
    layers = 3
    lh = (h - 5) // layers + 3
    for L in range(layers):
        top = L * ((h - 8 - lh) // max(1, layers - 1)) if layers > 1 else 0
        half = int((w / 2) * (0.55 + 0.45 * (L + 1) / layers))
        for yy in range(lh):
            span = int(half * (yy + 1) / lh)
            for xx in range(-span, span + 1):
                x, y = w // 2 + xx, top + yy
                t = (xx / (span + 0.5))
                c = LEAF2[3] if (t < -0.35 and yy < lh - 2) else LEAF2[2] if t < 0.2 else LEAF2[1] if t < 0.65 else LEAF2[0]
                if r.random() < 0.08: c = LEAF2[1]
                if xx in (-span, span) or yy == lh - 1: c = OUTL
                px(im, x, y, c)
    return im


save("objects", "pine_s", pine(20, 30, 1)); save("objects", "pine_m", pine(26, 40, 2)); save("objects", "pine_l", pine(34, 52, 3))

im = new(24, 36)
d = ImageDraw.Draw(im)
d.rectangle((10, 12, 13, 35), fill=P["wood_d"]); d.rectangle((10, 12, 10, 35), fill=P["wood"])
for (x0, y0, x1, y1) in ((10, 18, 3, 8), (13, 14, 20, 5), (11, 24, 5, 17), (12, 10, 17, 2)):
    d.line((x0, y0, x1, y1), fill=P["wood_d"], width=2)
d.line((10, 12, 11, 2), fill=P["wood_d"], width=2)
save("objects", "dead_tree", im)

im = new(14, 10)
d = ImageDraw.Draw(im)
d.ellipse((1, 3, 12, 9), fill=P["wood_d"]); d.ellipse((2, 2, 11, 7), fill=P["wood_l"])
d.ellipse((4, 3, 9, 6), fill=P["wood"]); d.arc((3, 3, 10, 7), 0, 360, fill=P["wood_d"])
save("objects", "stump", im)

for i, (tones, berry) in enumerate([(LEAF, None), (LEAF3, C("#d63b4a")), (LEAF2, C("#e8e8ff"))]):
    im = shade_blob(18, 13, tones, OUTL, 20 + i, bumps=(6, 11), wob=0.1)
    if berry:
        for _ in range(5): px(im, R.randrange(4, 14), R.randrange(3, 10), berry)
    save("objects", f"bush{i}", im)

im = new(12, 10)
for x in range(0, 12, 2):
    for y in range(9, 3 - (x % 4), -1): px(im, x, y, P["g3"]); px(im, x + 1, y, P["g1"])
save("objects", "fern", im)
for i, (a, b) in enumerate([(C("#9ca3ad"), C("#6e757f")), (C("#8d949c"), C("#5f666e"))]):
    im = shade_blob(16 - i * 3, 12 - i * 2, [C("#50565e"), b, a, C("#c4cad2")], C("#2a2e34"), 40 + i, bumps=(3, 7), wob=0.12)
    save("objects", f"rock{i}", im)
im = new(30, 9)
d = ImageDraw.Draw(im)
d.rounded_rectangle((0, 1, 29, 8), 3, fill=P["wood_d"]); d.line((2, 3, 27, 3), fill=P["wood"])
d.ellipse((0, 1, 6, 8), fill=P["wood_l"]); d.ellipse((2, 3, 4, 6), fill=P["wood_d"])
save("objects", "log", im)
im = new(8, 8); d = ImageDraw.Draw(im)
d.rectangle((3, 4, 4, 7), fill=C("#efe6d0")); d.ellipse((0, 0, 7, 5), fill=C("#d8453a")); px(im, 2, 2, C("#fff")); px(im, 5, 1, C("#fff"))
save("objects", "mushroom", im)

# указатель и ворота в город
im = new(26, 30); d = ImageDraw.Draw(im)
d.rectangle((11, 6, 14, 29), fill=P["wood_d"]); d.rectangle((11, 6, 11, 29), fill=P["wood"])
d.polygon([(2, 3), (18, 3), (24, 8), (18, 13), (2, 13)], fill=P["wood_l"], outline=P["wood_dd"])
d.polygon([(6, 8), (16, 8)], fill=P["wood_dd"])
d.line((6, 8, 17, 8), fill=P["wood_dd"], width=2); d.polygon([(16, 5), (21, 8), (16, 11)], fill=P["wood_dd"])
save("objects", "sign_arrow", im)

im = new(64, 46); d = ImageDraw.Draw(im)
for x0 in (0, 52):
    d.rectangle((x0, 10, x0 + 11, 45), fill=C("#9a9a96"), outline=C("#5d5d5a"))
    d.rectangle((x0 + 2, 12, x0 + 4, 44), fill=C("#b9b9b4"))
    d.rectangle((x0 - 2, 6, x0 + 13, 12), fill=C("#7e7e7a"), outline=C("#4a4a47"))
    d.rectangle((x0 + 3, 0, x0 + 8, 6), fill=C("#f6df7e"), outline=C("#6e5a22"))
d.rectangle((10, 8, 53, 18), fill=C("#6c4a2e"), outline=C("#3a2616"))
for x in range(12, 52, 6): d.line((x, 9, x, 17), fill=C("#573b24"))
d.polygon([(26, 11), (36, 13), (26, 16)], fill=C("#f6df7e"))
save("objects", "town_gate", im)

# мебель
im = new(22, 15); d = ImageDraw.Draw(im)
d.rectangle((1, 1, 20, 13), fill=P["wood"], outline=P["wood_dd"])
for x in (6, 11, 16): d.line((x, 2, x, 12), fill=P["wood_d"])
d.polygon([(14, 1), (20, 1), (20, 6)], fill=P["hole"])
save("objects", "table", im)
im = new(16, 26); d = ImageDraw.Draw(im)
d.rectangle((0, 0, 15, 25), fill=P["wood_d"], outline=P["wood_dd"])
d.rectangle((2, 2, 13, 22), fill=C("#9a8f7a")); d.rectangle((2, 2, 13, 7), fill=C("#c9c1ad"))
d.line((3, 14, 12, 17), fill=C("#6e6552")); d.polygon([(8, 16), (13, 22), (13, 16)], fill=P["hole"])
save("objects", "bed", im)
im = new(9, 11); d = ImageDraw.Draw(im)
d.rectangle((0, 0, 8, 6), fill=P["wood"], outline=P["wood_dd"]); d.line((1, 7, 1, 10), fill=P["wood_dd"]); d.line((7, 7, 7, 10), fill=P["wood_dd"])
save("objects", "chair", im)
im = new(13, 14); d = ImageDraw.Draw(im)
d.rectangle((0, 0, 12, 13), fill=P["wood_l"], outline=P["wood_dd"]); d.line((0, 0, 12, 13), fill=P["wood_d"]); d.line((12, 0, 0, 13), fill=P["wood_d"])
save("objects", "crate", im)
im = new(12, 15); d = ImageDraw.Draw(im)
d.rounded_rectangle((0, 0, 11, 14), 3, fill=P["wood"], outline=P["wood_dd"]); d.line((0, 4, 11, 4), fill=C("#3a3a3a")); d.line((0, 10, 11, 10), fill=C("#3a3a3a"))
save("objects", "barrel", im)
im = new(26, 12); d = ImageDraw.Draw(im)
d.rectangle((0, 0, 25, 11), fill=P["wood_d"], outline=P["wood_dd"])
for x0, c in ((2, C("#7a3b3b")), (7, C("#3b5a7a")), (12, C("#7a6a3b")), (19, C("#4a6a3b"))):
    d.rectangle((x0, 2, x0 + 3, 9), fill=c)
save("objects", "shelf", im)
im = new(30, 20); d = ImageDraw.Draw(im)
d.rectangle((0, 0, 29, 19), fill=C("#7a3b3b")); d.rectangle((2, 2, 27, 17), outline=C("#c9a45a"))
d.rectangle((6, 6, 23, 13), outline=C("#c9a45a"))
save("objects", "rug", im)

# город
im = new(12, 30); d = ImageDraw.Draw(im)
d.rectangle((5, 6, 6, 29), fill=C("#33383f")); d.rectangle((2, 27, 9, 29), fill=C("#252a30"))
d.rectangle((2, 0, 9, 7), fill=C("#33383f")); d.rectangle((3, 1, 8, 6), fill=C("#f6e9a0"))
save("objects", "lamp", im)
im = new(24, 13); d = ImageDraw.Draw(im)
d.rectangle((0, 2, 23, 6), fill=C("#a87038"), outline=P["wood_dd"]); d.rectangle((1, 7, 22, 8), fill=P["wood_d"])
for x in (2, 20): d.rectangle((x, 7, x + 1, 12), fill=C("#3a3a3a"))
save("objects", "bench", im)
save("objects", "tree_city", tree(28, 24, 5, 9, LEAF3, 9))
im = shade_blob(18, 9, LEAF, OUTL, 77, bumps=(6, 12), wob=0.05); save("objects", "hedge", im)
im = new(10, 12); d = ImageDraw.Draw(im)
d.rectangle((0, 2, 9, 11), fill=C("#4d6b52"), outline=C("#1f2e22")); d.rectangle((0, 0, 9, 3), fill=C("#3a523f"), outline=C("#1f2e22"))
save("objects", "bin", im)
for name, col in (("red", "#c23b3b"), ("blue", "#3b6bc2"), ("white", "#e2e4e8")):
    im = new(34, 18); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 3, 33, 15), 4, fill=C(col), outline=C("#1c1c20"))
    d.rounded_rectangle((8, 0, 25, 8), 3, fill=C("#9fd0f0"), outline=C("#1c1c20"))
    d.rectangle((8, 3, 25, 8), fill=C("#9fd0f0"))
    d.line((16, 1, 16, 7), fill=C("#1c1c20"))
    for x in (5, 27): d.ellipse((x, 12, x + 5, 17), fill=C("#1c1c20"))
    d.rectangle((1, 6, 3, 8), fill=C("#f6df7e")); d.rectangle((30, 6, 32, 8), fill=C("#f6df7e"))
    save("objects", f"car_{name}", im)
im = new(54, 40); d = ImageDraw.Draw(im)
d.ellipse((2, 14, 51, 38), fill=C("#8b8b86"), outline=C("#55554f"))
d.ellipse((7, 18, 46, 34), fill=C("#4f9ae0"), outline=C("#bfe2ff"))
d.rectangle((24, 4, 29, 22), fill=C("#b9b9b4"), outline=C("#55554f"))
d.ellipse((19, 0, 34, 8), fill=C("#4f9ae0"), outline=C("#bfe2ff"))
for x in (21, 26, 31): d.line((x, 28, x + 1, 24), fill=C("#bfe2ff"))
save("objects", "fountain", im)

# оружие (лежит в домиках; в бою рисуется повёрнутым)
im = new(16, 5); d = ImageDraw.Draw(im)
d.line((1, 2, 14, 2), fill=P["wood"], width=2); d.line((1, 3, 14, 3), fill=P["wood_d"]); px(im, 14, 1, P["wood_l"]); px(im, 3, 1, P["wood_l"])
save("objects", "item_stick", im)
im = new(18, 6); d = ImageDraw.Draw(im)
d.polygon([(0, 2), (11, 0), (17, 1), (17, 4), (11, 5), (0, 3)], fill=C("#c99a5b"), outline=P["wood_dd"])
d.line((2, 2, 14, 2), fill=C("#e0b878")); d.rectangle((0, 2, 2, 3), fill=C("#3a3a3a"))
save("objects", "item_bat", im)
im = new(16, 8); d = ImageDraw.Draw(im)
d.ellipse((0, 0, 8, 7), fill=C("#3a3d44"), outline=C("#16181c")); d.ellipse((2, 2, 6, 5), fill=C("#52565e"))
d.rectangle((8, 3, 15, 4), fill=P["wood_d"], outline=P["wood_dd"])
save("objects", "item_pan", im)
im = new(16, 10); d = ImageDraw.Draw(im)
for (y0, off) in ((6, 0), (3, 2), (0, 0)):
    d.rounded_rectangle((off, y0, off + 12, y0 + 3), 1, fill=P["wood"], outline=P["wood_dd"])
    d.ellipse((off + 9, y0, off + 12, y0 + 3), fill=P["wood_l"], outline=P["wood_dd"])
save("objects", "item_wood", im)
im = new(9, 9); d = ImageDraw.Draw(im)
d.polygon([(4, 0), (5, 3), (8, 4), (5, 5), (4, 8), (3, 5), (0, 4), (3, 3)], fill=C("#ffe27a"))
save("objects", "sparkle", im)

# =============== UI ===============
for name, col in (("heart_full", "#e5384f"), ("heart_empty", "#4a3a40")):
    im = new(11, 10); d = ImageDraw.Draw(im)
    c = C(col)
    d.ellipse((0, 0, 5, 5), fill=c); d.ellipse((5, 0, 10, 5), fill=c); d.polygon([(0, 4), (10, 4), (5, 9)], fill=c)
    if name == "heart_full": px(im, 2, 2, C("#ff9aa8")); px(im, 1, 3, C("#ff9aa8"))
    save("objects", name, im)

# =============== ПЕРСОНАЖИ ===============
if os.path.isdir(SRC_SPRITES):
    tmp = os.path.join(OUT, "characters")
    subprocess.check_call([sys.executable, "-I", os.path.join(ROOT, "tools", "process_sprites.py"), SRC_SPRITES, tmp])
    for f in sorted(os.listdir(tmp)):
        if f.endswith(".png"): MANIFEST.append("characters/" + f[:-4])
else:
    print("!! нет tools/source_sprites — персонажи не обновлены")
    for f in sorted(os.listdir(os.path.join(OUT, "characters"))):
        if f.endswith(".png"): MANIFEST.append("characters/" + f[:-4])

with open(os.path.join(ROOT, "game", "js", "manifest.js"), "w") as f:
    f.write("// Список картинок. Создаётся автоматически: tools/make_assets.py\n")
    f.write("var ASSET_MANIFEST = [\n  " + ",\n  ".join('"%s"' % m for m in MANIFEST) + "\n];\n")
print("готово:", len(MANIFEST), "картинок")
