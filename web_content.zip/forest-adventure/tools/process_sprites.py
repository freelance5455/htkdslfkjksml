"""Обработка исходных картинок персонажей:
 - убирает «шахматный» фон,
 - режет на вид спереди / сбоку,
 - делает вид сзади, кадры шага,
 - перекрашивает в врагов (чёрный / оранжевый),
 - уменьшает до игрового размера.
Запуск: python3 tools/process_sprites.py <папка_с_исходниками> <папка_вывода>
"""
import sys, os
from collections import deque
from PIL import Image

SRC = sys.argv[1]
OUT = sys.argv[2]
os.makedirs(OUT, exist_ok=True)

FILES = {"hero": "11526.png", "green": "11529.png", "blue": "11528.png", "yellow": "11527.png"}
TARGET_H = 30  # высота персонажа в игровых пикселях


def is_bg(p):
    r, g, b = p[:3]
    return abs(r - g) < 14 and abs(g - b) < 14 and 38 <= r <= 135


def remove_bg(im):
    im = im.convert("RGBA")
    w, h = im.size
    px = im.load()
    seen = [[False] * w for _ in range(h)]
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            q.append((x, y))
    for y in range(h):
        for x in (0, w - 1):
            q.append((x, y))
    while q:
        x, y = q.popleft()
        if x < 0 or y < 0 or x >= w or y >= h or seen[y][x]:
            continue
        if not is_bg(px[x, y]):
            continue
        seen[y][x] = True
        px[x, y] = (0, 0, 0, 0)
        q.extend(((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)))
    # убрать одиночные серые «островки» внутри фона (между фигурами)
    for y in range(h):
        for x in range(w):
            p = px[x, y]
            if p[3] and is_bg(p):
                # серый пиксель, не связанный с белой головой/одеждой: если рядом есть прозрачный — удалить
                nb = 0
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h and px[nx, ny][3] == 0:
                        nb += 1
                if nb >= 2:
                    px[x, y] = (0, 0, 0, 0)
    return im


def split_figures(im):
    w, h = im.size
    px = im.load()
    cols = [any(px[x, y][3] for y in range(h)) for x in range(w)]
    groups, start = [], None
    for x, c in enumerate(cols + [False]):
        if c and start is None:
            start = x
        if not c and start is not None:
            if x - start >= 6:
                groups.append((start, x))
            start = None
    figs = []
    for a, b in groups:
        sub = im.crop((a, 0, b, h))
        figs.append(sub.crop(sub.getbbox()))
    return figs


def interior_mask(im):
    w, h = im.size
    px = im.load()
    m = [[False] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            if not px[x, y][3]:
                continue
            ok = True
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    nx, ny = x + dx, y + dy
                    if nx < 0 or ny < 0 or nx >= w or ny >= h or not px[nx, ny][3]:
                        ok = False
            m[y][x] = ok
    return m


def recolor(im, hood, hood_shade, pants, shoes, hand=None):
    """Перекраска красной кофты и штанов (для врагов)."""
    im = im.copy()
    px = im.load()
    w, h = im.size
    inter = interior_mask(im)
    # граница между кофтой и штанами: самая нижняя «красная» строка кофты
    red_rows = [y for y in range(h) for x in range(w)
                if px[x, y][3] and px[x, y][0] > 90 and px[x, y][1] < 50]
    last_hood = max(red_rows) if red_rows else int(h * 0.85)
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if not a:
                continue
            reddish = r > 70 and g < 60 and b < 60
            if reddish:
                # низ кофты чуть темнее = обувь (последние ~12% высоты)
                if y > h * 0.90:
                    px[x, y] = shoes + (255,)
                else:
                    px[x, y] = hood + (255,)
            elif r < 40 and g < 40 and b < 40 and inter[y][x] and y > h * 0.55:
                # штаны (внутренние тёмные пиксели ниже середины)
                px[x, y] = pants + (255,)
            elif r < 40 and g < 40 and b < 40 and inter[y][x] and y <= h * 0.55 and y > h * 0.35:
                # молния / складки
                px[x, y] = hood_shade + (255,)
    return im


def remove_zipper(im):
    im = im.copy()
    px = im.load()
    w, h = im.size
    inter = interior_mask(im)
    # самый частый цвет кофты
    from collections import Counter
    cnt = Counter(px[x, y][:3] for y in range(h) for x in range(w)
                  if px[x, y][3] and px[x, y][0] > 90 and px[x, y][1] < 50)
    base = cnt.most_common(1)[0][0] if cnt else (134, 11, 16)
    for y in range(int(h * 0.38), int(h * 0.82)):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a and r < 40 and g < 40 and b < 40 and inter[y][x]:
                px[x, y] = base + (255,)
    return im


def downscale(im, target_h=TARGET_H):
    w, h = im.size
    s = target_h / h
    nw = max(1, round(w * s))
    small = im.convert("RGBa").resize((nw, target_h), Image.BOX).convert("RGBA")
    px = small.load()
    for y in range(target_h):
        for x in range(nw):
            r, g, b, a = px[x, y]
            px[x, y] = (r, g, b, 255) if a >= 120 else (0, 0, 0, 0)
    return small


def walk_frames(small):
    """Два кадра шага: поочерёдно приподнимаем левую/правую ногу."""
    w, h = small.size
    frames = []
    leg_top = h - 8
    lift = 2
    for side in (0, 1):
        f = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        f.paste(small, (0, 0))
        px = f.load()
        x0, x1 = (0, w // 2) if side == 0 else (w // 2, w)
        # сдвиг ноги вверх на 1 пиксель
        for x in range(x0, x1):
            col = [px[x, y] for y in range(leg_top, h)]
            for i, y in enumerate(range(leg_top, h)):
                px[x, y] = (0, 0, 0, 0)
            for i, y in enumerate(range(leg_top - lift, h - lift)):
                if col[i][3]:
                    px[x, y] = col[i]
        frames.append(f)
    return frames


def save(name, im):
    im.save(os.path.join(OUT, name + ".png"))


def make_set(prefix, front, side, pal=None):
    back = remove_zipper(front)
    if pal:
        front, side, back = recolor(front, **pal), recolor(side, **pal), recolor(back, **pal)
    f_small, s_small, b_small = downscale(front), downscale(side), downscale(back)
    fw = walk_frames(f_small)
    bw = walk_frames(b_small)
    save(prefix + "_down", f_small)
    save(prefix + "_down_w1", fw[0])
    save(prefix + "_down_w2", fw[1])
    save(prefix + "_up", b_small)
    save(prefix + "_up_w1", bw[0])
    save(prefix + "_up_w2", bw[1])
    save(prefix + "_side", s_small)  # смотрит вправо, для влево зеркалим в игре
    sw = walk_frames(s_small)
    save(prefix + "_side_w1", sw[0])
    save(prefix + "_side_w2", sw[1])


figs = {}
for key, fn in FILES.items():
    im = remove_bg(Image.open(os.path.join(SRC, fn)))
    parts = split_figures(im)
    assert len(parts) >= 2, (key, len(parts))
    figs[key] = (parts[0], parts[1])
    make_set(key, parts[0], parts[1])

# враги — перекраска героя
hero_f, hero_s = figs["hero"]
for name, pal in {
    "black": dict(hood=(46, 46, 54), hood_shade=(30, 30, 36), pants=(26, 26, 32), shoes=(58, 58, 66)),
    "orange": dict(hood=(236, 128, 24), hood_shade=(196, 92, 10), pants=(214, 106, 14), shoes=(250, 160, 50)),
}.items():
    make_set(name, hero_f, hero_s, pal)

print("ok", {k: (v[0].size, v[1].size) for k, v in figs.items()})
