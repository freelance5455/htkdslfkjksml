#!/usr/bin/env python3
"""Собирает ВСЮ игру в один файл forest-adventure.html (картинки встроены).
Его можно открыть прямо на телефоне в Chrome — без сервера и без APK.
Запуск: python3 tools/bundle.py
"""
import base64, os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
G = os.path.join(ROOT, "game")
html = open(os.path.join(G, "index.html"), encoding="utf-8").read()
css = open(os.path.join(G, "css", "style.css"), encoding="utf-8").read()
html = html.replace('<link rel="stylesheet" href="css/style.css">', "<style>\n" + css + "\n</style>")

manifest = re.findall(r'"([^"]+)"', open(os.path.join(G, "js", "manifest.js"), encoding="utf-8").read())
data = {}
for m in manifest:
    key = m.split("/")[-1]
    with open(os.path.join(G, "assets", m + ".png"), "rb") as f:
        data[m] = "data:image/png;base64," + base64.b64encode(f.read()).decode()
asset_js = "var ASSET_DATA = {" + ",".join('"%s":"%s"' % (k, v) for k, v in data.items()) + "};\n"

def inline(match):
    src = match.group(1)
    code = open(os.path.join(G, src), encoding="utf-8").read()
    if src.endswith("manifest.js"):
        code += "\n" + asset_js
    return "<script>\n" + code + "\n</script>"
html = re.sub(r'<script src="([^"]+)"></script>', inline, html)
# в одно-файловой версии ключ — полное имя из манифеста
out = os.path.join(ROOT, "forest-adventure.html")
open(out, "w", encoding="utf-8").write(html)
print("готово:", out, round(os.path.getsize(out) / 1024), "КБ")
