# PocketEngine
Редактор 3D-сцен для телефона. Язык: JavaScript, графика: Three.js r128, оболочка: Capacitor (Android).
Подробная справка для разработчиков — в комментарии в начале www/index.html.

## Как получить APK (без компьютера с Android Studio)
1. Создай репозиторий на GitHub и загрузи туда содержимое этой папки (включая .github).
2. Вкладка Actions → Build APK → Run workflow.
3. Через пару минут скачай app-debug.apk из Artifacts (внутри zip).

## Как упаковать свою игру
1. В приложении во вкладке «Код» скопируй код сцены.
2. Вставь его в www/scene.js: window.PE_SCENE = `код`; и поставь window.PE_PLAYER_ONLY = true.
3. Закоммить — APK соберётся заново, уже с твоей игрой без редактора.
