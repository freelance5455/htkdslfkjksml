#!/usr/bin/env python3
"""Generate a Seedance 2.5 video with the official Higgsfield Python SDK."""

import os
import sys
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
import higgsfield_client


MODEL_ID = "bytedance/seedance-2.5/text-to-video"


def video_url_from(result: Any) -> Optional[str]:
    """Read the completed video URL without assuming one response shape."""
    if not isinstance(result, dict):
        return None
    video = result.get("video")
    if isinstance(video, str) and video.startswith(("https://", "http://")):
        return video
    if isinstance(video, dict):
        url = video.get("url")
        if isinstance(url, str) and url.startswith(("https://", "http://")):
            return url
    videos = result.get("videos")
    if isinstance(videos, list) and videos:
        first = videos[0]
        if isinstance(first, str) and first.startswith(("https://", "http://")):
            return first
        if isinstance(first, dict):
            url = first.get("url")
            if isinstance(url, str) and url.startswith(("https://", "http://")):
                return url
    return None


def main() -> int:
    load_dotenv(Path(__file__).with_name(".env.local"), override=False)
    credential = os.environ.get("HF_KEY", "")
    if not credential or ":" not in credential:
        print("Higgsfield is not configured. Enter HF_KEY in .env.local as key-id:key-secret.", file=sys.stderr)
        return 2

    try:
        result = higgsfield_client.subscribe(
            MODEL_ID,
            arguments={
                "prompt": "A cinematic scene at sunset",
                "duration": 5,
                "resolution": "720p",
                "aspect_ratio": "16:9",
                "bitrate_mode": "high",
                "output_format": "mp4",
                "generate_audio": True,
            },
        )
    except higgsfield_client.InsufficientCreditsError:
        print("Generation failed: the Higgsfield account has insufficient credits.", file=sys.stderr)
        return 3
    except higgsfield_client.HiggsfieldClientError as error:
        print("Generation failed or was canceled by Higgsfield: %s" % type(error).__name__, file=sys.stderr)
        return 4
    except Exception as error:
        print("Generation did not complete: %s" % type(error).__name__, file=sys.stderr)
        return 5

    status = str(result.get("status", "")).lower() if isinstance(result, dict) else ""
    if status in {"failed", "canceled", "cancelled", "moderated", "rejected"}:
        print("Generation ended without a video: %s" % status, file=sys.stderr)
        return 6

    url = video_url_from(result)
    if not url:
        print("Generation returned no usable video URL.", file=sys.stderr)
        return 7

    print(url)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
