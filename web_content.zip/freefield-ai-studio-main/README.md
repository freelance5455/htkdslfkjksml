# FreeField

FreeField is a local, open-source AI video and voice studio. It combines a cinematic browser interface with server-side integrations for Higgsfield video generation and ElevenLabs narration.

## Features

- Text-to-video generation with Seedance 2.5, Seedance 2.0, and Kling 3.0 Turbo
- Model, aspect-ratio, duration, and camera-motion controls
- ElevenLabs narration with an in-browser audio player
- Generated video preview and downloadable project metadata
- Server-side credential handling; provider secrets never enter browser JavaScript
- Zero-build frontend served by a small Python server

## Requirements

- Python 3.9 or newer
- A Higgsfield API key pair for video generation
- An ElevenLabs API key for narration, if desired

## Installation

```bash
git clone https://github.com/thisisnotforyou/freefield-ai-studio.git
cd freefield-ai-studio
python3 -m pip install -r requirements.txt
```

Copy the environment templates:

```bash
cp .env.example .env
cp .env.local.example .env.local
```

Add ElevenLabs settings to `.env`. Set `HF_KEY` in `.env.local` to the `key-id:key-secret` pair supplied by Higgsfield. Both local environment files are ignored by Git.

## Run the studio

```bash
python3 server.py
```

Open <http://127.0.0.1:8080>. The interface reports which providers are connected. Generating video or narration may consume provider credits.

## Run the Seedance example

```bash
python3 main.py
```

This submits a billable 5-second, 720p Seedance 2.5 request and prints the completed video URL. It exits without claiming success when the request fails, is canceled, is moderated, or returns no usable URL.

## Security

Never commit `.env`, `.env.local`, generated media, or editor swap files. If a credential appears in a chat, commit, issue, log, or screenshot, revoke it immediately. See [SECURITY.md](SECURITY.md) for reporting guidance.

## Contributing

Contributions are welcome. Read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request.

## License

FreeField is available under the [MIT License](LICENSE).
