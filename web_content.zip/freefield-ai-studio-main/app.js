const $ = (q) => document.querySelector(q);
let selectedMotion = 'Dolly In';
let latestProject = null;

document.querySelectorAll('[data-scroll]').forEach((button) => button.addEventListener('click', () => {
  document.getElementById(button.dataset.scroll).scrollIntoView({ behavior: 'smooth' });
}));

$('#prompt').addEventListener('input', (event) => {
  $('#promptCount').textContent = `${event.target.value.length} / 600`;
});

$('#motions').addEventListener('click', (event) => {
  const button = event.target.closest('button');
  if (!button) return;
  document.querySelectorAll('#motions button').forEach((item) => item.classList.remove('selected'));
  button.classList.add('selected');
  selectedMotion = button.dataset.value;
});

$('#narrationToggle').addEventListener('change', (event) => {
  $('#narrationBox').style.display = event.target.checked ? 'block' : 'none';
});

function toast(message) {
  $('#toast').textContent = message;
  $('#toast').classList.add('show');
  setTimeout(() => $('#toast').classList.remove('show'), 2600);
}

async function checkStatus() {
  try {
    const response = await fetch('/api/status');
    const status = await response.json();
    const configured = [status.elevenlabs && 'ElevenLabs', status.higgsfield && 'Higgsfield'].filter(Boolean);
    $('#apiStatus').textContent = configured.length ? `${configured.join(' + ')} connected` : 'Demo mode · add API keys';
    if (configured.length) $('.status').classList.add('ready');
  } catch (_) {
    $('#apiStatus').textContent = 'Demo mode · local preview';
  }
}

$('#createForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = event.currentTarget.querySelector('.generate');
  const payload = {
    prompt: $('#prompt').value.trim(),
    model: $('#model').value,
    format: $('#format').value,
    duration: Number($('#duration').value),
    motion: selectedMotion,
    narration_enabled: $('#narrationToggle').checked,
    narration: $('#narration').value.trim()
  };
  if (!payload.prompt) return toast('Describe your shot first');
  submit.disabled = true;
  submit.querySelector('span').textContent = 'Building project…';
  $('#preview').classList.add('working');
  $('#preview p').textContent = 'Directing your scene…';
  try {
    const response = await fetch('/api/create', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Could not create project');
    latestProject = data;
    $('#resultText').textContent = JSON.stringify(data, null, 2);
    $('#result').classList.add('show');
    $('#preview .preview-mark').textContent = '✓';
    $('#preview p').textContent = data.mode === 'demo' ? 'Project plan ready · demo mode' : 'Live generation request created';
    document.querySelectorAll('.generated-audio').forEach((item) => item.remove());
    if (data.narration && data.narration.audio_url) {
      const audio = document.createElement('audio');
      audio.controls = true;
      audio.src = data.narration.audio_url;
      audio.className = 'generated-audio';
      $('#preview').appendChild(audio);
    }
    document.querySelectorAll('.generated-video').forEach((item) => item.remove());
    if (data.video_url) {
      const video = document.createElement('video');
      video.controls = true;
      video.autoplay = true;
      video.muted = true;
      video.playsInline = true;
      video.src = data.video_url;
      video.className = 'generated-video';
      $('#preview').appendChild(video);
    }
    toast('Scene project created');
  } catch (error) {
    $('#preview p').textContent = error.message;
    toast(error.message);
  } finally {
    submit.disabled = false;
    submit.querySelector('span').textContent = 'Generate scene';
    $('#preview').classList.remove('working');
  }
});

$('#downloadBtn').addEventListener('click', () => {
  if (!latestProject) return;
  const blob = new Blob([JSON.stringify(latestProject, null, 2)], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `freefield-${latestProject.project_id}.json`;
  link.click();
  URL.revokeObjectURL(link.href);
});

checkStatus();
