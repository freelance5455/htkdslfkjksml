# Contributing

Thanks for helping improve FreeField.

## Local setup

1. Fork and clone the repository.
2. Install dependencies with `python3 -m pip install -r requirements.txt`.
3. Copy `.env.example` to `.env` and create `.env.local` only when you need provider access.
4. Start the app with `python3 server.py` and open `http://127.0.0.1:8080`.

Keep API keys, generated media, editor swap files, and personal data out of commits. Pull requests should explain the user-visible change and how it was tested. Provider calls can consume paid credits, so use mocks or non-billable checks during development whenever possible.
