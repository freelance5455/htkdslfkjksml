#!/usr/bin/env python3
"""Dependency-free local server for the FreeField studio."""
import json
import os
import pathlib
import re
import time
import uuid
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = pathlib.Path(__file__).resolve().parent
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)


def load_env(path):
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


load_env(ROOT / ".env")
load_env(ROOT / ".env.local")

VIDEO_MODELS = {
    "bytedance/seedance-2.5/text-to-video": "Seedance 2.5",
    "bytedance/seedance-2.0/text-to-video": "Seedance 2.0",
    "kling-video/v3.0-turbo/text-to-video": "Kling 3.0 Turbo",
}


def safe_id(value):
    return re.sub(r"[^a-zA-Z0-9_-]", "", value or "")


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def log_message(self, fmt, *args):
        print("[FreeField] " + fmt % args)

    def json_response(self, status, body):
        data = json.dumps(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/api/status":
            return self.json_response(200, {
                "elevenlabs": bool(os.environ.get("ELEVENLABS_API_KEY")),
                "higgsfield": bool(os.environ.get("HF_KEY")),
                "demo": not bool(os.environ.get("ELEVENLABS_API_KEY") or os.environ.get("HF_KEY")),
                "models": [{"id": key, "name": value} for key, value in VIDEO_MODELS.items()],
            })
        return super().do_GET()

    def do_POST(self):
        if self.path == "/api/configure-higgsfield":
            try:
                length = min(int(self.headers.get("Content-Length", "0")), 10_000)
                payload = json.loads(self.rfile.read(length) or b"{}")
                credential = str(payload.get("credential", "")).strip()
                if not credential or ":" not in credential:
                    return self.json_response(400, {"error": "Expected key-id:key-secret"})
                (ROOT / ".env.local").write_text(
                    "# Private Higgsfield credentials. This file is ignored by Git.\nHF_KEY=" + credential + "\n",
                    encoding="utf-8",
                )
                return self.json_response(200, {"saved": True})
            except (ValueError, TypeError, json.JSONDecodeError):
                return self.json_response(400, {"error": "Invalid request"})
        if self.path != "/api/create":
            return self.json_response(404, {"error": "Not found"})
        try:
            length = min(int(self.headers.get("Content-Length", "0")), 1_000_000)
            payload = json.loads(self.rfile.read(length) or b"{}")
            prompt = str(payload.get("prompt", "")).strip()
            if not prompt:
                return self.json_response(400, {"error": "A scene prompt is required"})
            project_id = uuid.uuid4().hex[:10]
            model_id = str(payload.get("model", "bytedance/seedance-2.5/text-to-video"))
            if model_id not in VIDEO_MODELS:
                return self.json_response(400, {"error": "Unsupported video model"})
            project = {
                "project_id": project_id,
                "created_at": int(time.time()),
                "mode": "demo",
                "status": "planned",
                "scene": {
                    "prompt": prompt[:600],
                    "aspect_ratio": payload.get("format", "16:9"),
                    "duration_seconds": min(max(int(payload.get("duration", 8)), 1), 30),
                    "camera_motion": payload.get("motion", "Dolly In"),
                    "model": model_id,
                },
                "narration": {
                    "enabled": bool(payload.get("narration_enabled")),
                    "text": str(payload.get("narration", ""))[:1000],
                    "provider": "elevenlabs",
                },
                "providers": {
                    "video": "higgsfield",
                    "voice": "elevenlabs",
                    "video_configured": bool(os.environ.get("HF_KEY")),
                    "voice_configured": bool(os.environ.get("ELEVENLABS_API_KEY")),
                },
                "next_step": "Generate from the studio after choosing a video model.",
            }
            if project["narration"]["enabled"] and project["narration"]["text"] and os.environ.get("ELEVENLABS_API_KEY"):
                project["narration"].update(self.generate_voice(project_id, project["narration"]["text"]))
                project["mode"] = "live"
                project["status"] = "voice_ready"

            if os.environ.get("HF_KEY"):
                video_result = self.generate_higgsfield(project["scene"])
                project["video_result"] = video_result
                project["video_url"] = self.video_url_from(video_result)
                if not project["video_url"]:
                    return self.json_response(502, {"error": "Higgsfield completed without a usable video URL"})
                project["mode"] = "live"
                project["status"] = "completed"
            return self.json_response(200, project)
        except (ValueError, TypeError, json.JSONDecodeError):
            return self.json_response(400, {"error": "Invalid request"})
        except (HTTPError, URLError) as error:
            return self.json_response(502, {"error": "Provider request failed: %s" % error})
        except Exception as error:
            return self.json_response(502, {"error": "Generation failed: %s" % type(error).__name__})

    def generate_voice(self, project_id, text):
        voice_id = safe_id(os.environ.get("ELEVENLABS_VOICE_ID") or "JBFqnCBsd6RMkjVDRZzb")
        if not voice_id:
            raise ValueError("ELEVENLABS_VOICE_ID is invalid")
        endpoint = "https://api.elevenlabs.io/v1/text-to-speech/%s?output_format=mp3_44100_128" % voice_id
        body = json.dumps({
            "text": text,
            "model_id": os.environ.get("ELEVENLABS_MODEL_ID") or "eleven_multilingual_v2",
            "voice_settings": {"stability": 0.5, "similarity_boost": 0.75, "style": 0.15, "use_speaker_boost": True},
        }).encode("utf-8")
        request = Request(endpoint, data=body, method="POST", headers={
            "Content-Type": "application/json", "Accept": "audio/mpeg",
            "xi-api-key": os.environ["ELEVENLABS_API_KEY"],
        })
        with urlopen(request, timeout=120) as response:
            audio = response.read()
        if not audio:
            raise URLError("ElevenLabs returned an empty audio file")
        filename = "freefield-%s.mp3" % project_id
        (OUTPUTS / filename).write_bytes(audio)
        return {"status": "ready", "voice_id": voice_id, "audio_url": "/outputs/%s" % filename}

    def generate_higgsfield(self, scene):
        import higgsfield_client
        prompt = scene["prompt"] + ". Camera movement: " + str(scene["camera_motion"]) + "."
        arguments = {
            "prompt": prompt,
            "duration": scene["duration_seconds"],
            "resolution": "720p",
            "aspect_ratio": scene["aspect_ratio"],
        }
        if scene["model"].startswith("bytedance/seedance"):
            arguments.update({"generate_audio": True})
            if "2.5" in scene["model"]:
                arguments.update({"bitrate_mode": "high", "output_format": "mp4"})
        return higgsfield_client.subscribe(scene["model"], arguments=arguments)

    def video_url_from(self, result):
        if not isinstance(result, dict):
            return None
        video = result.get("video")
        if isinstance(video, str) and video.startswith(("https://", "http://")):
            return video
        if isinstance(video, dict):
            url = video.get("url")
            if isinstance(url, str) and url.startswith(("https://", "http://")):
                return url
        videos = result.get("videos")
        if isinstance(videos, list) and videos:
            first = videos[0]
            if isinstance(first, str):
                return first
            if isinstance(first, dict):
                return first.get("url")
        return None


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print("FreeField is running at http://127.0.0.1:%d" % port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nFreeField stopped")
