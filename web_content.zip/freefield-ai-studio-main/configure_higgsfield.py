#!/usr/bin/env python3
"""Securely save Higgsfield credentials without echoing them to the terminal."""

from getpass import getpass
from pathlib import Path


target = Path(__file__).with_name(".env.local")
credential = getpass("Enter HF_KEY (key-id:key-secret): ").strip()
if not credential or ":" not in credential:
    raise SystemExit("Invalid format. Expected key-id:key-secret.")

target.write_text(
    "# Private Higgsfield credentials. This file is ignored by Git.\n"
    "HF_KEY=" + credential + "\n",
    encoding="utf-8",
)
print("Saved securely to .env.local.")
