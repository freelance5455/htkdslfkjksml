# Security

Please do not open a public issue containing API keys, credentials, private media, or personal information.

If you discover a security issue, report it privately to the repository owner through GitHub's private vulnerability reporting feature. Rotate any credential that has appeared in a commit, issue, pull request, log, or chat.

FreeField reads provider credentials only on the local Python server. Never move credentials into `index.html`, `app.js`, browser storage, or URLs.
