import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.trmaintenance.app',
  appName: 'TR Maintenance',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
