# TR Maintenance — Capacitor Android starter

यह प्रोजेक्ट आपकी मौजूदा HTML फ़ाइल को Capacitor ऐप के web assets के रूप में रखता है।

## इसमें क्या है
- `www/index.html`: मौजूदा TR Maintenance HTML portal
- `package.json`: Capacitor dependencies और scripts
- `capacitor.config.ts`: ऐप नाम `TR Maintenance`, App ID `com.trmaintenance.app`

## महत्वपूर्ण
यह ZIP अभी APK या AAB नहीं है। इस वातावरण में Android SDK/Android platform उपलब्ध नहीं था, इसलिए compiled APK/AAB बनाना संभव नहीं हुआ।

## Android build environment में आगे के चरण
Node.js और npm, Android SDK, JDK 17 या Capacitor/Gradle द्वारा समर्थित JDK, तथा Android build tools वाले कंप्यूटर या cloud build environment में:

1. ZIP extract करें।
2. Project folder में terminal खोलें।
3. `npm install`
4. `npx cap add android`
5. `npx cap sync android`
6. `npx cap open android`
7. Android Studio में debug APK या signed release AAB build करें।

अगर Android platform पहले से बना है, तो `npx cap add android` दोबारा न चलाएँ; `npx cap sync android` चलाएँ।

## Production में प्रकाशित करने से पहले जरूरी
- HTML demo में localStorage डेटा अलग-अलग मोबाइलों के बीच sync नहीं होता।
- Owner/Staff/Customer authentication को server-side authentication और role-based access से बदलें।
- Shared database और उचित security rules जोड़ें।
- Privacy Policy, Data safety form, icon, screenshots, testing और Play Console setup पूरा करें।
- HTML में hard-coded credentials हों तो उन्हें हटाकर rotate करें; असली credentials client-side code में न रखें।

यह starter project है, Play Store-ready app नहीं है।
