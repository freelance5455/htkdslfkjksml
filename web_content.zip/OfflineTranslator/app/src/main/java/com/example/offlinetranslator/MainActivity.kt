package com.example.offlinetranslator

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

class MainActivity : AppCompatActivity() {

    private data class Lang(val code: String, val name: String) {
        override fun toString() = name
    }

    private val langs = listOf(
        Lang(TranslateLanguage.ARABIC, "العربية"),
        Lang(TranslateLanguage.ENGLISH, "English"),
        Lang(TranslateLanguage.FRENCH, "Français"),
        Lang(TranslateLanguage.SPANISH, "Español"),
        Lang(TranslateLanguage.GERMAN, "Deutsch"),
        Lang(TranslateLanguage.ITALIAN, "Italiano"),
        Lang(TranslateLanguage.PORTUGUESE, "Português"),
        Lang(TranslateLanguage.TURKISH, "Türkçe"),
        Lang(TranslateLanguage.RUSSIAN, "Русский"),
        Lang(TranslateLanguage.CHINESE, "中文"),
        Lang(TranslateLanguage.JAPANESE, "日本語"),
        Lang(TranslateLanguage.KOREAN, "한국어"),
        Lang(TranslateLanguage.HINDI, "हिन्दी"),
        Lang(TranslateLanguage.URDU, "اردو"),
        Lang(TranslateLanguage.PERSIAN, "فارسی")
    )

    private lateinit var spinnerFrom: Spinner
    private lateinit var spinnerTo: Spinner
    private lateinit var etInput: EditText
    private lateinit var tvResult: TextView
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnTranslate: Button

    private var translator: Translator? = null
    private var currentPair: Pair<String, String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinnerFrom = findViewById(R.id.spinnerFrom)
        spinnerTo = findViewById(R.id.spinnerTo)
        etInput = findViewById(R.id.etInput)
        tvResult = findViewById(R.id.tvResult)
        tvStatus = findViewById(R.id.tvStatus)
        progress = findViewById(R.id.progress)
        btnTranslate = findViewById(R.id.btnTranslate)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs)
        spinnerFrom.adapter = adapter
        spinnerTo.adapter = adapter
        spinnerFrom.setSelection(0) // العربية
        spinnerTo.setSelection(1)   // English

        findViewById<Button>(R.id.btnSwap).setOnClickListener {
            val from = spinnerFrom.selectedItemPosition
            spinnerFrom.setSelection(spinnerTo.selectedItemPosition)
            spinnerTo.setSelection(from)
        }
        btnTranslate.setOnClickListener { translate() }
        findViewById<Button>(R.id.btnManage).setOnClickListener { showDownloadedModels() }
    }

    private fun translate() {
        val text = etInput.text.toString().trim()
        val from = spinnerFrom.selectedItem as Lang
        val to = spinnerTo.selectedItem as Lang

        if (text.isEmpty()) {
            Toast.makeText(this, R.string.empty_input, Toast.LENGTH_SHORT).show()
            return
        }
        if (from.code == to.code) {
            Toast.makeText(this, R.string.same_lang, Toast.LENGTH_SHORT).show()
            return
        }

        val pair = from.code to to.code
        if (pair != currentPair) {
            translator?.close()
            translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(from.code)
                    .setTargetLanguage(to.code)
                    .build()
            )
            currentPair = pair
        }
        val t = translator ?: return

        setBusy(true, getString(R.string.downloading))
        // بدون شرط Wi-Fi؛ التنزيل يتم مرة واحدة فقط ثم تعمل الترجمة محليًا
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tvStatus.text = getString(R.string.translating)
                t.translate(text)
                    .addOnSuccessListener { result ->
                        tvResult.text = result
                        setBusy(false, "")
                    }
                    .addOnFailureListener { e ->
                        tvResult.text = ""
                        setBusy(false, e.localizedMessage ?: "")
                    }
            }
            .addOnFailureListener {
                setBusy(false, getString(R.string.need_internet))
            }
    }

    private fun setBusy(busy: Boolean, status: String) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        btnTranslate.isEnabled = !busy
        tvStatus.text = status
    }

    private fun showDownloadedModels() {
        val manager = RemoteModelManager.getInstance()
        manager.getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { models ->
                val list = models.toList()
                if (list.isEmpty()) {
                    Toast.makeText(this, R.string.no_models, Toast.LENGTH_SHORT).show()
                    return@addOnSuccessListener
                }
                val names = list.map { m -> langs.firstOrNull { it.code == m.language }?.name ?: m.language }
                AlertDialog.Builder(this)
                    .setTitle(R.string.delete_title)
                    .setItems(names.toTypedArray()) { _, which ->
                        translator?.close()
                        translator = null
                        currentPair = null
                        manager.deleteDownloadedModel(list[which]).addOnSuccessListener {
                            Toast.makeText(this, R.string.deleted, Toast.LENGTH_SHORT).show()
                        }
                    }
                    .show()
            }
    }

    override fun onDestroy() {
        translator?.close()
        super.onDestroy()
    }
}
