/* ============================================================
   MindMirror — scoring.js
   Deterministic scoring engine. Same answers → same scores.
   No randomness anywhere.

   SCORING RULES (documented):

   1. Each quiz option carries a weight vector
      w = [analytical, social, exploratory, structured, reflective],
      where each entry is 0, 1, or 2.
   2. For each of the five traits:
         rawSum  = sum of that trait's weights across chosen answers
         maxSum  = sum of the maximum possible weight for that trait
                   across all questions in the quiz
         minSum  = sum of the minimum possible weight for that trait
                   across all questions in the quiz
      The trait is then scaled to 0–100:
         score = round(100 * (rawSum - minSum) / (maxSum - minSum))
      (If maxSum === minSum the trait is scored 50 by definition.)
   3. PROFILE ASSIGNMENT (in priority order — first match wins):
      a) BALANCER: if all five scores fall within a 26-point band
         (max - min <= 26), the profile is The Balancer.
      b) Otherwise the two highest traits are compared:
         Strategist : analytical is highest
         Connector  : social is highest
         Explorer   : exploratory is highest
         Builder    : structured is highest
         Observer   : reflective is highest
         (primary trait)
      c) TIE-BREAKING for the primary trait (when two or more traits
         share the top score), in fixed priority order:
         analytical > structured > reflective > exploratory > social.
         This order biases toward the more distinctive profile rather
         than defaulting everyone to Connector.
      d) SECONDARY MODIFIERS — the primary trait decides the family;
         the runner-up trait picks the variant profile:
         primary=analytical + runner-up=structured  → The Strategist
         primary=analytical + runner-up=reflective  → The Observer
         primary=exploratory + runner-up=social     → The Explorer
         primary=exploratory + runner-up=reflective → The Visionary
         primary=structured  + runner-up=analytical → The Builder
         primary=structured  + runner-up=exploratory→ The Adapter
         primary=social      + runner-up=*          → The Connector
         primary=reflective  + runner-up=*          → The Observer
         (fallback: family default = Strategist / Explorer / Builder /
          Connector / Observer)
   4. All arithmetic is integer/float deterministic; the engine uses no
      random number generation and no date-based variation.
   5. Results are presented as entertainment and self-reflection,
      not as a scientifically validated assessment.
   ============================================================ */

var MMScoring = (function () {
  "use strict";

  var TRAIT_ORDER = ["analytical", "social", "exploratory", "structured", "reflective"];

  /* Fixed tie-break priority: index 0 wins ties first. */
  var TIE_PRIORITY = ["analytical", "structured", "reflective", "exploratory", "social"];

  /* Runner-up variant table (see rule 3d above). */
  var VARIANT_TABLE = {
    analytical:  { structured: "strategist", reflective: "observer", _default: "strategist" },
    exploratory: { social: "explorer", reflective: "visionary", _default: "explorer" },
    structured:  { analytical: "builder", exploratory: "adapter", _default: "builder" },
    social:      { _default: "connector" },
    reflective:  { _default: "observer" }
  };

  var BALANCER_BAND = 26;

  /* ------------------------------------------------------------
     computeScores(quiz, answers)
     quiz   — quiz object from QUIZZES
     answers — array of option indices (0-3), length == items length
     returns { traits: {trait: 0-100}, sorted: [{key,label,score}] }
     ------------------------------------------------------------ */
  function computeScores(quiz, answers) {
    var traits = {};
    var mins = {}, maxs = {};
    var i, t, w;

    for (i = 0; i < TRAIT_ORDER.length; i++) {
      traits[TRAIT_ORDER[i]] = 0;
      mins[TRAIT_ORDER[i]] = 0;
      maxs[TRAIT_ORDER[i]] = 0;
    }

    // accumulate raw sums and min/max possible per trait
    for (i = 0; i < quiz.items.length; i++) {
      var weights = quiz.items[i].options.map(function (o) { return o.w; });
      var chosenIdx = (typeof answers[i] === "number") ? answers[i] : -1;

      for (var ti = 0; ti < TRAIT_ORDER.length; ti++) {
        t = TRAIT_ORDER[ti];
        var col = [];
        var min = 99, max = -1;
        for (var oi = 0; oi < weights.length; oi++) {
          var v = weights[oi][ti] || 0;
          col.push(v);
          if (v < min) min = v;
          if (v > max) max = v;
        }
        mins[t] += min;
        maxs[t] += max;
        if (chosenIdx >= 0 && chosenIdx < col.length) {
          traits[t] += col[chosenIdx];
        }
      }
    }

    // scale to 0-100
    for (i = 0; i < TRAIT_ORDER.length; i++) {
      t = TRAIT_ORDER[i];
      var span = maxs[t] - mins[t];
      if (span <= 0) {
        traits[t] = 50;
      } else {
        var pct = (traits[t] - mins[t]) / span;
        traits[t] = Math.round(pct * 100);
        if (traits[t] < 0) traits[t] = 0;
        if (traits[t] > 100) traits[t] = 100;
      }
    }

    // sorted list (score desc, then fixed tie priority)
    var sorted = TRAIT_ORDER.map(function (key) {
      return { key: key, label: quiz.traitLabels[key] || key, score: traits[key] };
    }).sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return TIE_PRIORITY.indexOf(a.key) - TIE_PRIORITY.indexOf(b.key);
    });

    return { traits: traits, sorted: sorted };
  }

  /* ------------------------------------------------------------
     assignProfile(scores) → profile key string
     Implements rules 3a–3d documented above.
     ------------------------------------------------------------ */
  function assignProfile(sorted) {
    if (!sorted || sorted.length < 5) return "balancer";

    var values = sorted.map(function (s) { return s.score; });
    var top = values[0], low = values[4];

    // 3a) Balancer band
    if (top - low <= BALANCER_BAND) return "balancer";

    // 3b/3c) primary trait with fixed tie-break
    var topScore = top;
    var candidates = sorted.filter(function (s) { return s.score === topScore; });
    var primary = candidates[0].key; // already tie-prioritized by sort
    var runnerUp = sorted[1].key;

    // 3d) variant selection
    var table = VARIANT_TABLE[primary] || {};
    var profileId = table[runnerUp] || table._default || "strategist";
    return profileId;
  }

  /* ------------------------------------------------------------
     evaluate(quiz, answers) — full deterministic evaluation
     returns { scores, sorted, profileKey, profile }
     ------------------------------------------------------------ */
  function evaluate(quiz, answers) {
    var result = computeScores(quiz, answers);
    var profileKey = assignProfile(result.sorted);
    var profile = PROFILES[profileKey];
    return {
      scores: result.traits,
      sorted: result.sorted,
      profileKey: profileKey,
      profile: profile
    };
  }

  /* ------------------------------------------------------------
     PROFILES — 8 personality profiles with conditional content.
     selectContent(scores) picks strength/blind/tip lines based on
     the user's actual scores, so results differ between users.
     ------------------------------------------------------------ */
  var PROFILES = {
    strategist: {
      key: "strategist",
      name: "The Strategist",
      icon: "#p-strategist",
      tagline: "Thoughtful by nature. Intentional by design.",
      description: "You approach life like a well-designed system. Before acting, you want to understand how the pieces fit — and once they do, you move with quiet confidence.",
      strengthsBuckets: {
        analytical: "You cut through noise and find the core of complex problems.",
        structured: "You turn vague goals into clear, actionable steps.",
        reflective: "Your decisions improve over time because you actually review them."
      },
      blindBuckets: {
        social: "Over-planning can crowd out the people and moments that matter.",
        exploratory: "Waiting for perfect information can mean waiting too long."
      },
      tipBuckets: {
        exploratory: "Try one small experiment this week where the outcome is unknown.",
        social: "Share an unfinished idea with someone and let their input in early.",
        reflective: "Schedule unstructured thinking time — your best plans start there."
      }
    },
    explorer: {
      key: "explorer",
      name: "The Explorer",
      icon: "#p-explorer",
      tagline: "Curious by default. Bold by choice.",
      description: "You treat the unknown as an invitation. Rather than following the map, you'd rather see what's around the next corner — and you usually find something interesting there.",
      strengthsBuckets: {
        exploratory: "You spot possibilities others walk straight past.",
        social: "You connect ideas and people in surprising, useful ways.",
        reflective: "You learn fast because every detour becomes a lesson."
      },
      blindBuckets: {
        structured: "Open roads can drift — finishing matters as much as starting.",
        analytical: "Excitement can outrun the facts worth checking first."
      },
      tipBuckets: {
        structured: "Pick one current project and give it a simple finish line.",
        analytical: "Before your next leap, write down the one assumption you're betting on.",
        reflective: "Keep a short 'what I learned' note after each new adventure."
      }
    },
    builder: {
      key: "builder",
      name: "The Builder",
      icon: "#p-builder",
      tagline: "Steady hands. Visible results.",
      description: "You make things real. Where others talk about ideas, you lay bricks — one reliable step after another — until the thing actually exists.",
      strengthsBuckets: {
        structured: "You turn intentions into schedules and schedules into reality.",
        analytical: "You build on solid ground, not wishful thinking.",
        reflective: "You improve your process with every project you finish."
      },
      blindBuckets: {
        exploratory: "A solid plan can become a cage when the situation changes.",
        social: "Working heads-down can leave allies and helpers out of the loop."
      },
      tipBuckets: {
        exploratory: "Leave one 'wildcard slot' in your week for unplanned opportunities.",
        social: "Show your work-in-progress to someone before it feels ready.",
        reflective: "Review a finished project for lessons, not just for defects."
      }
    },
    observer: {
      key: "observer",
      name: "The Observer",
      icon: "#p-observer",
      tagline: "Quiet eyes. Deep seeing.",
      description: "You notice what others miss. While the world rushes to speak, you watch, listen, and piece together an understanding that runs deeper than first impressions.",
      strengthsBuckets: {
        reflective: "You see patterns in your own behavior and change them deliberately.",
        analytical: "Your careful reading of situations keeps you well-informed.",
        social: "People feel genuinely heard when you're paying attention."
      },
      blindBuckets: {
        exploratory: "Watching is wise — but some doors only open from the inside.",
        social: "Insight kept silent helps no one, including you."
      },
      tipBuckets: {
        exploratory: "Act on one observation this week before you've fully refined it.",
        social: "Voice one of your quiet insights out loud — it will land better than you think.",
        structured: "Turn a recurring observation into a small, repeatable habit."
      }
    },
    connector: {
      key: "connector",
      name: "The Connector",
      icon: "#p-connector",
      tagline: "People first. Always in motion.",
      description: "You believe good things happen between people. You read the room, lift the mood, and somehow always know the right person for any problem.",
      strengthsBuckets: {
        social: "You build trust quickly and bring out the best in groups.",
        exploratory: "Your openness to people makes you open to ideas, too.",
        reflective: "You understand others because you understand yourself."
      },
      blindBuckets: {
        reflective: "Constant togetherness can drown out your own inner voice.",
        structured: "Saying yes to everyone can scatter your plans thin."
      },
      tipBuckets: {
        reflective: "Block one hour of solitude this week and protect it fiercely.",
        structured: "Choose your top two commitments and let the rest breathe.",
        analytical: "Before big group decisions, form your own view first."
      }
    },
    adapter: {
      key: "adapter",
      name: "The Adapter",
      icon: "#p-adapter",
      tagline: "Fluid by instinct. Ready for anything.",
      description: "You bend without breaking. When plans change, you don't panic — you adjust, improvise, and often end up somewhere better than the original plan.",
      strengthsBuckets: {
        exploratory: "Change energizes you instead of draining you.",
        structured: "You stay organized enough to pivot without chaos.",
        social: "You help others stay calm when plans fall apart."
      },
      blindBuckets: {
        reflective: "Constant adapting can mean constantly reacting.",
        analytical: "Flexibility works best when the goal is still clear."
      },
      tipBuckets: {
        reflective: "End your day by asking: did today move me toward anything I chose?",
        analytical: "Define what success looks like before the next pivot.",
        structured: "Anchor one fixed routine so change has a home base."
      }
    },
    visionary: {
      key: "visionary",
      name: "The Visionary",
      icon: "#p-visionary",
      tagline: "See it first. Build it next.",
      description: "You live slightly in the future. Ideas arrive as vivid pictures of what could be, and your challenge — and gift — is pulling those pictures into the present.",
      strengthsBuckets: {
        exploratory: "You imagine possibilities before evidence makes them obvious.",
        reflective: "Your ideas are grounded in real self-knowledge, not just daydreams.",
        social: "You make others believe in futures they hadn't imagined."
      },
      blindBuckets: {
        structured: "Visions need scaffolding — details decide whether they ship.",
        analytical: "A compelling picture deserves an honest reality check."
      },
      tipBuckets: {
        structured: "Take your boldest idea and write the very first concrete step.",
        analytical: "Pressure-test one vision with someone kind but skeptical.",
        reflective: "Revisit your old ideas — the pattern in them is your compass."
      }
    },
    balancer: {
      key: "balancer",
      name: "The Balancer",
      icon: "#p-balancer",
      tagline: "Even keel. All angles covered.",
      description: "You don't lean on a single way of thinking. Logic, curiosity, planning, people, and reflection all get a vote — which makes you adaptable, grounded, and hard to rattle.",
      strengthsBuckets: {
        analytical: "You weigh every angle before committing — and rarely regret it.",
        social: "You translate between different thinkers with ease.",
        structured: "Your balance keeps projects steady when things get messy."
      },
      blindBuckets: {
        exploratory: "Balance can blur into hesitation when a bold choice is needed.",
        reflective: "Serving every style can delay serving your own truth."
      },
      tipBuckets: {
        exploratory: "Practice one week of deliberately lopsided decisions.",
        reflective: "Notice which thinking style you avoid — that's where growth hides.",
        structured: "When stakes are low, decide fast on instinct alone."
      }
    }
  };

  /* Public API */
  return {
    TRAIT_ORDER: TRAIT_ORDER,
    PROFILES: PROFILES,
    computeScores: computeScores,
    assignProfile: assignProfile,
    evaluate: evaluate
  };
})();

/* Conditional content selectors used by app.js. They pick lines from the
   profile's content buckets based on the user's ACTUAL scores: strengths
   key off the top trait, blind spots and tips key off the lowest trait.
   Fixed fallbacks guarantee every profile always yields 3 strengths,
   2 blind spots, and 3 tips. */
function topTraitOf(sc, order) {
  var best = order[0];
  for (var i = 1; i < order.length; i++) if (sc[order[i]] > sc[best]) best = order[i];
  return best;
}
function lowTraitOf(sc, order) {
  var worst = order[0];
  for (var i = 1; i < order.length; i++) if (sc[order[i]] < sc[worst]) worst = order[i];
  return worst;
}
function pickLine(buckets, key, order) {
  if (buckets[key]) return { key: key, line: buckets[key] };
  for (var i = 0; i < order.length; i++) {
    if (buckets[order[i]]) return { key: order[i], line: buckets[order[i]] };
  }
  return null;
}

MMScoring.getStrengths = function (profile, scores) {
  var order = MMScoring.TRAIT_ORDER;
  var top = topTraitOf(scores, order);
  var first = pickLine(profile.strengthsBuckets, top, order);
  var out = [];
  if (first) out.push(first.line);
  for (var i = 0; i < order.length; i++) {
    var k = order[i];
    if ((!first || k !== first.key) && profile.strengthsBuckets[k]) out.push(profile.strengthsBuckets[k]);
  }
  return out.slice(0, 3);
};

MMScoring.getBlindSpots = function (profile, scores) {
  var order = MMScoring.TRAIT_ORDER;
  var low = lowTraitOf(scores, order);
  var first = pickLine(profile.blindBuckets, low, order);
  var out = [];
  if (first) out.push(first.line);
  for (var i = 0; i < order.length; i++) {
    var k = order[i];
    if ((!first || k !== first.key) && profile.blindBuckets[k]) out.push(profile.blindBuckets[k]);
  }
  return out.slice(0, 2);
};

MMScoring.getTips = function (profile, scores) {
  var order = MMScoring.TRAIT_ORDER;
  var low = lowTraitOf(scores, order);
  var first = pickLine(profile.tipBuckets, low, order);
  var out = [];
  if (first) out.push(first.line);
  for (var i = 0; i < order.length; i++) {
    var k = order[i];
    if ((!first || k !== first.key) && profile.tipBuckets[k]) out.push(profile.tipBuckets[k]);
  }
  return out.slice(0, 3);
};
