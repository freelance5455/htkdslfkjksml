/* ============================================================
   MindMirror — app.js
   View routing, quiz runner, results rendering, result-card
   canvas export, sharing, history and settings. Vanilla ES5.
   ============================================================ */

var MMApp = (function () {
  "use strict";

  var APP_VERSION = "1.0.0";

  /* ---------------- tiny helpers ---------------- */
  function $(id) { return document.getElementById(id); }
  function el(tag, className, text) {
    var e = document.createElement(tag);
    if (className) e.className = className;
    if (typeof text === "string") e.textContent = text;
    return e;
  }
  function useTag(symbolId, sizeAttr) {
    // returns an inline <svg><use/></svg> markup string (both href forms)
    return '<svg viewBox="0 0 48 48" style="width:' + (sizeAttr || 24) + 'px;height:' + (sizeAttr || 24) + 'px" aria-hidden="true"><use href="' + symbolId + '" xlink:href="' + symbolId + '"></use></svg>';
  }
  function fmtDate(iso) {
    try {
      var d = new Date(iso);
      if (isNaN(d.getTime())) return "";
      return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
    } catch (e) { return ""; }
  }

  /* ---------------- state ---------------- */
  var state = {
    view: "home",
    quiz: null,            // quiz object currently running
    answers: [],           // selected option indices (or undefined/null)
    index: 0,              // current question index
    result: null,          // result object currently displayed
    resultReturn: "discover",
    quizFrom: "discover",
    modalOkAction: null,
    modalCancelAction: null
  };

  /* ---------------- toast ---------------- */
  var toastTimer = null;
  function toast(msg) {
    var t = $("toast");
    if (!t) return;
    t.textContent = msg;
    t.classList.add("show");
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove("show"); }, 2600);
  }

  /* ---------------- modal ---------------- */
  function openModal(opts) {
    $("modalTitle").textContent = opts.title || "";
    $("modalBody").textContent = opts.body || "";
    var ok = $("modalOk"), cancel = $("modalCancel");
    ok.textContent = opts.okText || "Confirm";
    cancel.textContent = opts.cancelText || "Cancel";
    ok.className = "btn " + (opts.danger ? "btn-danger" : "btn-primary");
    cancel.hidden = !!opts.hideCancel;
    state.modalOkAction = opts.onOk || null;
    state.modalCancelAction = opts.onCancel || null;
    // Reset animation so it replays correctly on every open.
    // On Android WebView, a stale CSS animation fill state can leave the backdrop
    // at opacity:0 (invisible but still intercepting pointer events), making buttons
    // appear unresponsive. Toggling animation:none then restoring it forces a replay.
    var backdrop = $("modalBackdrop");
    backdrop.style.animation = "none";
    backdrop.hidden = false;
    requestAnimationFrame(function () {
      backdrop.style.animation = "";
    });
  }
  function closeModal() {
    $("modalBackdrop").hidden = true;
    state.modalOkAction = null;
    state.modalCancelAction = null;
  }
  function infoModal(title, body) {
    openModal({ title: title, body: body, okText: "Close", hideCancel: true });
  }

  /* ---------------- view switching ---------------- */
  var VIEW_IDS = {
    home: "view-home",
    discover: "view-discover",
    history: "view-history",
    settings: "view-settings",
    quiz: "view-quiz",
    result: "view-result"
  };

  function switchView(name) {
    if (!VIEW_IDS[name]) return;
    state.view = name;
    for (var key in VIEW_IDS) {
      if (Object.prototype.hasOwnProperty.call(VIEW_IDS, key)) {
        $(VIEW_IDS[key]).hidden = (key !== name);
      }
    }
    var navBtns = document.querySelectorAll(".bottom-nav .nav-item");
    for (var i = 0; i < navBtns.length; i++) {
      var target = navBtns[i].getAttribute("data-nav");
      if (target === name) navBtns[i].classList.add("active");
      else navBtns[i].classList.remove("active");
    }
    var appRoot = $("app");
    if (appRoot) {
      if (name === "quiz" || name === "result") appRoot.classList.add("immersive");
      else appRoot.classList.remove("immersive");
    }
    if (name === "history") renderHistory();
    if (name === "discover") renderQuizList();
    window.scrollTo(0, 0);
  }

  /* ================= HOME ================= */
  function renderExampleTypes() {
    var grid = $("exampleTypes");
    if (!grid) return;
    grid.innerHTML = "";
    var keys = Object.keys(MMScoring.PROFILES);
    keys.forEach(function (k) {
      var p = MMScoring.PROFILES[k];
      var chip = el("button", "type-chip");
      chip.type = "button";
      chip.setAttribute("aria-label", "About " + p.name);
      chip.innerHTML = useTag(p.icon, 26) +
        "<b>" + p.name + "</b>" +
        "<span>" + p.tagline + "</span>";
      chip.addEventListener("click", function () {
        infoModal(p.name, p.description);
      });
      grid.appendChild(chip);
    });
  }

  /* ================= DISCOVER ================= */
  function getValidProgress() {
    var p = MMStorage.getProgress();
    if (!p || typeof p.quizId !== "string") return null;
    var quiz = QUIZZES.getById(p.quizId);
    if (!quiz) return null;
    if (!Array.isArray(p.answers) || p.answers.length !== quiz.items.length) return null;
    if (typeof p.index !== "number" || p.index < 0 || p.index >= quiz.items.length) return null;
    var answered = 0;
    for (var i = 0; i < p.answers.length; i++) {
      var a = p.answers[i];
      if (typeof a === "number" && a >= 0 && a <= 3 && a === Math.floor(a)) {
        answered++;
      } else if (i < p.index) {
        return null; // answered questions must hold valid indices
      }
    }
    if (answered === 0) return null;
    return { quiz: quiz, progress: p, answered: answered };
  }

  function quizDoneResult(quizId) {
    var list = MMStorage.getResults();
    for (var i = 0; i < list.length; i++) {
      if (list[i].quizId === quizId) return list[i];
    }
    return null;
  }

  function renderQuizList() {
    var wrap = $("quizList");
    if (!wrap) return;
    wrap.innerHTML = "";
    var valid = getValidProgress();

    QUIZZES.all.forEach(function (quiz) {
      var done = quizDoneResult(quiz.id);
      var resumable = valid && valid.quiz.id === quiz.id;

      var item = el("div", "quiz-item");
      var top = el("div", "quiz-item-top");
      var h = el("h3", null, quiz.title);
      top.appendChild(h);
      item.appendChild(top);
      item.appendChild(el("p", null, quiz.subtitle));

      var badges = el("div", "quiz-item-badges");
      var b1 = el("span", "badge");
      b1.innerHTML = '<svg viewBox="0 0 24 24"><use href="#i-book" xlink:href="#i-book"></use></svg>' +
        quiz.questions + " questions";
      var b2 = el("span", "badge");
      b2.innerHTML = '<svg viewBox="0 0 24 24"><use href="#i-clock" xlink:href="#i-clock"></use></svg>' +
        "≈ " + quiz.minutes + " min";
      badges.appendChild(b1);
      badges.appendChild(b2);
      if (done && !resumable) {
        var b3 = el("span", "badge done");
        b3.innerHTML = '<svg viewBox="0 0 24 24"><use href="#i-check" xlink:href="#i-check"></use></svg>Completed';
        badges.appendChild(b3);
      }
      if (resumable) {
        var b4 = el("span", "badge");
        b4.textContent = "In progress · " + valid.answered + "/" + quiz.questions;
        badges.appendChild(b4);
      }
      item.appendChild(badges);

      var btn = el("button", resumable ? "btn btn-primary" : "btn btn-ghost");
      btn.type = "button";
      btn.textContent = resumable ? "Resume Quiz" : (done ? "Take It Again" : "Start Quiz");
      btn.addEventListener("click", function () { startQuizFlow(quiz); });
      item.appendChild(btn);

      wrap.appendChild(item);
    });
  }

  /* ================= QUIZ FLOW ================= */
  function startQuizFlow(quiz) {
    var valid = getValidProgress();
    if (valid && valid.quiz.id === quiz.id) {
      openModal({
        title: "Resume quiz?",
        body: "You have unfinished progress in “" + quiz.title + "” (" + valid.answered + "/" + quiz.questions + " answered).",
        okText: "Resume",
        cancelText: "Start over",
        onOk: function () { beginQuiz(quiz, valid.progress); },
        onCancel: function () { beginQuiz(quiz, null); }
      });
      return;
    }
    beginQuiz(quiz, null);
  }

  function beginQuiz(quiz, resumeProgress) {
    state.quizFrom = (state.view === "quiz") ? state.quizFrom : state.view;
    state.quiz = quiz;
    if (resumeProgress) {
      state.answers = resumeProgress.answers.slice();
      state.index = resumeProgress.index;
    } else {
      state.answers = [];
      for (var i = 0; i < quiz.items.length; i++) state.answers.push(null);
      state.index = 0;
    }
    $("quizName").textContent = quiz.title;
    $("quizTime").textContent = "≈ " + quiz.minutes + " min";
    $("qTotal").textContent = quiz.items.length;
    switchView("quiz");
    renderQuestion();
  }

  function persistProgress() {
    if (!state.quiz) return;
    var answered = false;
    for (var i = 0; i < state.answers.length; i++) {
      if (typeof state.answers[i] === "number") { answered = true; break; }
    }
    if (!answered) { MMStorage.clearProgress(); return; }
    MMStorage.saveProgress({
      v: 1,
      quizId: state.quiz.id,
      answers: state.answers,
      index: state.index,
      savedAt: new Date().toISOString()
    });
  }

  var OPTION_KEYS = ["A", "B", "C", "D"];

  function renderQuestion() {
    var quiz = state.quiz;
    if (!quiz) return;
    var item = quiz.items[state.index];

    $("qCurrent").textContent = String(state.index + 1);
    $("progressFill").style.width = (((state.index + 1) / quiz.items.length) * 100) + "%";
    $("questionText").textContent = item.q;

    var list = $("optionsList");
    list.innerHTML = "";
    var selected = state.answers[state.index];

    item.options.forEach(function (opt, i) {
      var btn = el("button", "option" + (selected === i ? " selected" : ""));
      btn.type = "button";
      btn.setAttribute("role", "radio");
      btn.setAttribute("aria-checked", selected === i ? "true" : "false");
      var key = el("span", "option-key", OPTION_KEYS[i]);
      var text = el("span", null, opt.t);
      btn.appendChild(key);
      btn.appendChild(text);
      btn.addEventListener("click", function () { selectOption(i); });
      list.appendChild(btn);
    });

    $("btnPrev").disabled = (state.index === 0);
    var next = $("btnNext");
    next.textContent = (state.index === quiz.items.length - 1) ? "Reveal My Results" : "Continue";
    next.disabled = (typeof selected !== "number");
  }

  function selectOption(i) {
    state.answers[state.index] = i;
    persistProgress();
    // repaint selection state without full re-render (keeps focus stable)
    var buttons = $("optionsList").querySelectorAll(".option");
    for (var b = 0; b < buttons.length; b++) {
      var isSel = (b === i);
      buttons[b].classList.toggle("selected", isSel);
      buttons[b].setAttribute("aria-checked", isSel ? "true" : "false");
    }
    $("btnNext").disabled = false;
  }

  function nextStep() {
    var quiz = state.quiz;
    if (!quiz) return;
    if (typeof state.answers[state.index] !== "number") return; // must answer first
    if (state.index < quiz.items.length - 1) {
      state.index++;
      persistProgress();
      renderQuestion();
    } else {
      finishQuiz();
    }
  }

  function prevStep() {
    if (state.index > 0) {
      state.index--;
      persistProgress();
      renderQuestion();
    }
  }

  function exitQuiz() {
    var answered = 0;
    for (var i = 0; i < state.answers.length; i++) {
      if (typeof state.answers[i] === "number") answered++;
    }
    openModal({
      title: "Exit quiz?",
      body: answered > 0
        ? "Your progress is saved on this device. You can resume later from Discover."
        : "You haven't answered any questions yet.",
      okText: "Exit",
      cancelText: "Keep going",
      onOk: function () {
        persistProgress();
        switchView(state.quizFrom === "quiz" ? "discover" : state.quizFrom);
      }
    });
  }

  /* ================= RESULTS ================= */
  function finishQuiz() {
    var quiz = state.quiz;
    if (!quiz) return;

    // safety: every question must have a valid answer
    for (var i = 0; i < state.answers.length; i++) {
      if (typeof state.answers[i] !== "number") {
        state.index = i;
        renderQuestion();
        toast("Please answer every question first");
        return;
      }
    }

    var ev = MMScoring.evaluate(quiz, state.answers);
    var profile = ev.profile;

    var result = {
      v: 1,
      quizId: quiz.id,
      quizTitle: quiz.title,
      profileKey: ev.profileKey,
      profileName: profile.name,
      tagline: profile.tagline,
      description: profile.description,
      iconRef: profile.icon,
      scores: ev.scores,
      sorted: ev.sorted,
      traitLabels: quiz.traitLabels,
      date: new Date().toISOString()
    };

    MMStorage.clearProgress();
    var saved = MMStorage.saveResult(result);
    state.result = result;
    state.resultReturn = "discover";
    renderResult(result);
    switchView("result");
    toast(saved ? "Result saved to My Results" : "Result ready (saving unavailable on this device)");
  }

  function renderResult(result) {
    var profile = MMScoring.PROFILES[result.profileKey];
    if (!profile) return;

    $("resultIcon").innerHTML = '<svg viewBox="0 0 48 48" aria-hidden="true"><use href="' + profile.icon + '" xlink:href="' + profile.icon + '"></use></svg>';
    $("resultName").textContent = profile.name;
    $("resultTagline").textContent = "“" + profile.tagline + "”";
    $("resultDesc").textContent = profile.description;

    var list = $("scoreList");
    list.innerHTML = "";
    result.sorted.forEach(function (s) {
      var row = el("div", "score-row");
      var lbl = el("span", null, s.label);
      var barWrap = el("div", "bar");
      var fill = el("i");
      fill.style.width = Math.max(2, s.score) + "%";
      barWrap.appendChild(fill);
      var val = el("b", null, String(s.score));
      row.appendChild(lbl);
      row.appendChild(barWrap);
      row.appendChild(val);
      list.appendChild(row);
    });
    $("scoreNote").textContent = "Scores are calculated from your answers on a 0–100 scale.";

    fillList($("strengthList"), MMScoring.getStrengths(profile, result.scores));
    fillList($("blindList"), MMScoring.getBlindSpots(profile, result.scores));
    fillList($("tipList"), MMScoring.getTips(profile, result.scores));

    // hide any previously shown card preview
    $("cardPreview").hidden = true;
    $("cardPreview").innerHTML = "";
  }

  function fillList(ul, items) {
    ul.innerHTML = "";
    items.forEach(function (text) {
      if (!text) return;
      ul.appendChild(el("li", null, text));
    });
  }

  /* ---------------- result card (canvas, 4:5) ---------------- */
  var SANS = '-apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

  function roundRectPath(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function drawLogoMark(ctx, x, y, s) {
    ctx.save();
    ctx.strokeStyle = "#9277F6";
    ctx.lineWidth = Math.max(4, s * 0.13);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(x, y + s * 0.62);
    ctx.lineTo(x, y);
    ctx.lineTo(x + s * 0.3, y + s * 0.36);
    ctx.lineTo(x + s * 0.5, y + s * 0.08);
    ctx.lineTo(x + s * 0.7, y + s * 0.36);
    ctx.lineTo(x + s, y);
    ctx.lineTo(x + s, y + s * 0.62);
    ctx.stroke();
    ctx.globalAlpha = 0.55;
    ctx.beginPath();
    ctx.moveTo(x - s * 0.05, y + s * 0.84);
    ctx.lineTo(x + s * 1.05, y + s * 0.84);
    ctx.stroke();
    ctx.restore();
  }

  function splitQuote(t) {
    var parts = String(t).split(". ");
    var lines = [];
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i].replace(/\.\s*$/, "");
      if (p) lines.push(p + ".");
    }
    return lines.slice(0, 2);
  }

  function drawCard(result) {
    var canvas = document.createElement("canvas");
    canvas.width = 800;
    canvas.height = 1000; // 4:5 portrait
    var ctx = canvas.getContext("2d");
    if (!ctx) return null;

    var profile = MMScoring.PROFILES[result.profileKey];
    if (!profile) return null;

    // background
    ctx.fillStyle = "#09090F";
    ctx.fillRect(0, 0, 800, 1000);
    var glow = ctx.createRadialGradient(400, -100, 40, 400, -100, 640);
    glow.addColorStop(0, "rgba(146,119,246,0.45)");
    glow.addColorStop(1, "rgba(146,119,246,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, 800, 620);
    var glow2 = ctx.createRadialGradient(760, 1050, 60, 760, 1050, 560);
    glow2.addColorStop(0, "rgba(196,181,253,0.16)");
    glow2.addColorStop(1, "rgba(196,181,253,0)");
    ctx.fillStyle = glow2;
    ctx.fillRect(0, 480, 800, 520);

    // frame
    roundRectPath(ctx, 28, 28, 744, 944, 36);
    ctx.strokeStyle = "rgba(255,255,255,0.14)";
    ctx.lineWidth = 2;
    ctx.stroke();

    // brand row
    drawLogoMark(ctx, 72, 76, 46);
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#F5F3FF";
    ctx.font = "800 33px " + SANS;
    ctx.fillText("MINDMIRROR", 140, 114);

    // eyebrow
    ctx.fillStyle = "#C4B5FD";
    ctx.font = "700 23px " + SANS;
    ctx.fillText("YOUR THINKING STYLE", 72, 236);

    // profile name
    ctx.fillStyle = "#F5F3FF";
    ctx.font = "800 74px " + SANS;
    ctx.fillText(profile.name, 72, 320);

    // quote
    ctx.fillStyle = "#A5A0B8";
    ctx.font = "italic 33px " + SANS;
    var qlines = splitQuote(profile.tagline);
    for (var qi = 0; qi < qlines.length; qi++) {
      ctx.fillText(qlines[qi], 72, 386 + qi * 50);
    }

    // three real trait scores
    var top3 = result.sorted.slice(0, 3);
    var y0 = 540;
    for (var si = 0; si < top3.length; si++) {
      var s = top3[si];
      var y = y0 + si * 96;
      ctx.textAlign = "left";
      ctx.fillStyle = "#A5A0B8";
      ctx.font = "600 28px " + SANS;
      ctx.fillText(s.label, 72, y);
      ctx.textAlign = "right";
      ctx.fillStyle = "#F5F3FF";
      ctx.font = "700 30px " + SANS;
      ctx.fillText(s.score + "/100", 728, y);
      ctx.textAlign = "left";
      // track
      roundRectPath(ctx, 72, y + 20, 656, 14, 7);
      ctx.fillStyle = "rgba(255,255,255,0.10)";
      ctx.fill();
      // fill
      var bw = Math.max(26, Math.round(656 * s.score / 100));
      roundRectPath(ctx, 72, y + 20, bw, 14, 7);
      var grad = ctx.createLinearGradient(72, 0, 728, 0);
      grad.addColorStop(0, "#C4B5FD");
      grad.addColorStop(1, "#9277F6");
      ctx.fillStyle = grad;
      ctx.fill();
    }

    // footer pill
    ctx.textAlign = "center";
    ctx.font = "700 26px " + SANS;
    var label = "DISCOVER YOUR PROFILE";
    var tw = ctx.measureText(label).width + 76;
    roundRectPath(ctx, (800 - tw) / 2, 836, tw, 66, 33);
    ctx.fillStyle = "rgba(146,119,246,0.18)";
    ctx.fill();
    ctx.strokeStyle = "rgba(146,119,246,0.55)";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = "#C4B5FD";
    ctx.fillText(label, 400, 880);

    ctx.fillStyle = "rgba(165,160,184,0.85)";
    ctx.font = "600 21px " + SANS;
    ctx.fillText("MindMirror · Discover the Way You Think", 400, 940);

    return canvas;
  }

  function cardFilename() {
    var key = state.result && state.result.profileKey ? state.result.profileKey : "result";
    return "mindmirror-" + key + ".png";
  }

  function showCardPreview(canvas, dataUrl) {
    var box = $("cardPreview");
    box.innerHTML = "";
    if (dataUrl) {
      var img = document.createElement("img");
      img.alt = "MindMirror result card";
      img.src = dataUrl;
      box.appendChild(img);
    } else {
      box.appendChild(canvas);
    }
    box.hidden = false;
  }

  function downloadCard() {
    if (!state.result) return;
    var canvas = drawCard(state.result);
    if (!canvas) {
      toast("Card preview isn't supported on this device");
      return;
    }
    // preview first (also acts as the manual long-press fallback)
    var dataUrl = null;
    try { dataUrl = canvas.toDataURL("image/png"); } catch (e) { dataUrl = null; }
    showCardPreview(canvas, dataUrl);

    MMSharing.downloadCanvas(canvas, cardFilename(), function (c, fallbackUrl) {
      // toBlob + anchor download both failed — the preview image is shown;
      // instruct the user to long-press it.
      toast("Long-press the card image to save it");
    });
  }

  /* ---------------- sharing ---------------- */
  function resultShareText(result) {
    var profile = MMScoring.PROFILES[result.profileKey];
    var top2 = result.sorted.slice(0, 2).map(function (s) {
      return s.label + " " + s.score + "/100";
    }).join(", ");
    return "I discovered my thinking style on MindMirror.\n" +
      "My profile: " + profile.name + " — " + profile.tagline + "\n" +
      top2 + "\n" +
      "Now it's your turn. Discover your profile!";
  }

  var CHALLENGE_TEXT = "I discovered my thinking style on MindMirror.\n" +
    "Now it's your turn.\n" +
    "Discover your profile!";

  function profileSummaryText(result) {
    var profile = MMScoring.PROFILES[result.profileKey];
    var scores = result.sorted.map(function (s) {
      return s.label + " " + s.score + "/100";
    }).join(" · ");
    var strengths = MMScoring.getStrengths(profile, result.scores);
    return "MindMirror Profile — " + profile.name + "\n" +
      "“" + profile.tagline + "”\n" +
      scores + "\n" +
      "Top strength: " + strengths[0] + "\n" +
      "Discovered with MindMirror — Discover the Way You Think.";
  }

  /* ================= HISTORY ================= */
  function renderHistory() {
    var wrap = $("historyList");
    if (!wrap) return;
    wrap.innerHTML = "";
    var list = MMStorage.getResults();

    if (!list.length) {
      var empty = el("div", "empty-state", "No results yet.\nTake a quiz and your profile will appear here.");
      empty.style.whiteSpace = "pre-line";
      wrap.appendChild(empty);
      return;
    }

    list.forEach(function (r) {
      var profile = MMScoring.PROFILES[r.profileKey] || { name: r.profileName || "Unknown", icon: "#p-balancer" };
      var card = el("div", "history-card");
      var ic = el("div", "history-icon");
      ic.innerHTML = '<svg viewBox="0 0 48 48"><use href="' + profile.icon + '" xlink:href="' + profile.icon + '"></use></svg>';
      var info = el("div", "history-info");
      info.appendChild(el("b", null, r.quizTitle || "Quiz"));
      info.appendChild(el("span", null, profile.name + " · " + fmtDate(r.date)));
      var btn = el("button", "btn btn-ghost", "View Results");
      btn.type = "button";
      btn.addEventListener("click", function () {
        state.result = r;
        state.resultReturn = "history";
        renderResult(r);
        switchView("result");
      });
      card.appendChild(ic);
      card.appendChild(info);
      card.appendChild(btn);
      wrap.appendChild(card);
    });
  }

  /* ================= SETTINGS ================= */
  function clearHistoryFlow() {
    var list = MMStorage.getResults();
    if (!list.length) { toast("Quiz history is already empty"); return; }
    openModal({
      title: "Clear quiz history?",
      body: "This permanently removes " + list.length + " saved result" + (list.length === 1 ? "" : "s") + " from this device.",
      okText: "Clear History",
      danger: true,
      onOk: function () {
        MMStorage.clearHistory();
        renderHistory();
        renderQuizList();
        toast("Quiz history cleared");
      }
    });
  }

  function deleteAllFlow() {
    openModal({
      title: "Delete all app data?",
      body: "This removes your results, quiz progress, and preferences from this device. This cannot be undone.",
      okText: "Delete Everything",
      danger: true,
      onOk: function () {
        MMStorage.clearAll();
        renderHistory();
        renderQuizList();
        toast("All app data deleted");
      }
    });
  }

  function resetUnfinishedFlow() {
    var valid = getValidProgress();
    if (!valid) { toast("No unfinished quiz found"); return; }
    openModal({
      title: "Reset unfinished quiz?",
      body: "Your saved progress in “" + valid.quiz.title + "” will be discarded.",
      okText: "Reset",
      danger: true,
      onOk: function () {
        MMStorage.clearProgress();
        renderQuizList();
        toast("Unfinished quiz reset");
      }
    });
  }

  /* ================= EVENTS ================= */
  function bindEvents() {
    // all data-nav triggers
    var navTriggers = document.querySelectorAll("[data-nav]");
    for (var i = 0; i < navTriggers.length; i++) {
      (function (node) {
        node.addEventListener("click", function () {
          switchView(node.getAttribute("data-nav"));
        });
      })(navTriggers[i]);
    }

    $("brandHome").addEventListener("click", function () { switchView("home"); });

    // hero
    $("btnStartMain").addEventListener("click", function () {
      startQuizFlow(QUIZZES.all[0]);
    });

    // discover — challenge
    $("btnChallengeShare").addEventListener("click", function () {
      MMSharing.shareText(CHALLENGE_TEXT,
        function (mode) { toast(mode === "copied" ? "No share sheet — challenge copied instead" : "Challenge shared!"); },
        function () { toast("Couldn't share on this device"); });
    });
    $("btnChallengeCopy").addEventListener("click", function () {
      MMSharing.copyText(CHALLENGE_TEXT,
        function () { toast("Challenge message copied"); },
        function () { toast("Copy failed — please copy manually"); });
    });

    // history topbar
    $("btnClearHistory").addEventListener("click", clearHistoryFlow);

    // settings
    $("setResetUnfinished").addEventListener("click", resetUnfinishedFlow);
    $("setClearHistory").addEventListener("click", clearHistoryFlow);
    $("setDeleteAll").addEventListener("click", deleteAllFlow);
    $("setAbout").addEventListener("click", function () {
      infoModal("About MindMirror",
        "MindMirror — Discover the Way You Think.\n\n" +
        "Version " + APP_VERSION + "\n\n" +
        "MindMirror is a self-reflection app with short quizzes about how you think, decide, and plan. " +
        "Everything runs and stays on your device — no account, no internet connection required.\n\n" +
        "Profiles are for entertainment and self-reflection, not scientific diagnoses.");
    });
    $("setPrivacy").addEventListener("click", function () {
      infoModal("Privacy information",
        "MindMirror collects nothing.\n\n" +
        "• No accounts, no sign-up, no personal information.\n" +
        "• Your answers and results are stored only on this device using local storage.\n" +
        "• Results do not sync across devices.\n" +
        "• No ads, no tracking, no network permissions needed.\n\n" +
        "Clearing app data in Settings permanently removes everything stored.");
    });

    // quiz
    $("btnQuizExit").addEventListener("click", exitQuiz);
    $("btnPrev").addEventListener("click", prevStep);
    $("btnNext").addEventListener("click", nextStep);

    // result
    $("btnResultBack").addEventListener("click", function () {
      switchView(state.resultReturn === "history" ? "history" : "discover");
    });
    $("btnRetake").addEventListener("click", function () {
      if (!state.result) return;
      var quiz = QUIZZES.getById(state.result.quizId);
      if (quiz) startQuizFlow(quiz);
    });
    $("btnShareResult").addEventListener("click", function () {
      if (!state.result) return;
      MMSharing.shareText(resultShareText(state.result),
        function (mode) { toast(mode === "copied" ? "No share sheet — summary copied instead" : "Shared!"); },
        function () { toast("Couldn't share on this device"); });
    });
    $("btnDownloadCard").addEventListener("click", downloadCard);
    $("btnCopySummary").addEventListener("click", function () {
      if (!state.result) return;
      MMSharing.copyText(profileSummaryText(state.result),
        function () { toast("Profile summary copied"); },
        function () { toast("Copy failed — please copy manually"); });
    });

    // modal
    $("modalOk").addEventListener("click", function () {
      var action = state.modalOkAction;
      closeModal();
      if (action) action();
    });
    $("modalCancel").addEventListener("click", function () {
      var action = state.modalCancelAction;
      closeModal();
      if (action) action();
    });
    $("modalBackdrop").addEventListener("click", function (e) {
      if (e.target === $("modalBackdrop")) {
        var action = state.modalCancelAction;
        closeModal();
        if (action) action();
      }
    });
  }

  /* ================= INIT ================= */
  // run fn once the startup splash is gone (immediately if there is no splash)
  function afterSplash(fn) {
    if (typeof MMSplash !== "undefined") MMSplash.whenDone(fn); else fn();
  }

  function offerResume() {
    var valid = getValidProgress();
    if (!valid) return;
    afterSplash(function () { setTimeout(function () {
      openModal({
        title: "Welcome back",
        body: "You have an unfinished quiz: “" + valid.quiz.title + "” (" + valid.answered + "/" + valid.quiz.questions + " answered).",
        okText: "Resume",
        cancelText: "Later",
        onOk: function () { beginQuiz(valid.quiz, valid.progress); }
      });
    }, 450); });
  }

  function init() {
    renderExampleTypes();
    renderQuizList();
    renderHistory();
    bindEvents();
    switchView("home");
    if (!MMStorage.isPersistent()) {
      afterSplash(function () {
        setTimeout(function () {
          toast("Storage unavailable — results won't persist between sessions");
        }, 1200);
      });
    }
    offerResume();
    if (typeof MMSplash !== "undefined") MMSplash.appReady();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  /* public (for debugging/testing) */
  return {
    switchView: switchView,
    getState: function () { return state; }
  };
})();
