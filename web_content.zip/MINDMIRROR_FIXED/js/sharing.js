/* ============================================================
   MindMirror — sharing.js
   Share & export helpers. Feature-detected with graceful
   fallbacks. Works fully offline from file:// URLs.

   - copyText: clipboard API → execCommand → manual select
   - shareText: Web Share API (if available) → copy fallback
   - shareFiles: Web Share API Level 2 with files (if supported)
   - downloadPNG: canvas.toBlob → download link; fallback opens
     the PNG data URL so the user can long-press to save.
   ============================================================ */

var MMSharing = (function () {
  "use strict";

  /* ---------- clipboard with 3-tier fallback ---------- */
  function copyText(text, onDone, onFail) {
    // Tier 1: Clipboard API (secure contexts; often works in WebView)
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(
        function () { if (onDone) onDone(true); },
        function () { legacyCopy(text, onDone, onFail); }
      );
      return;
    }
    legacyCopy(text, onDone, onFail);
  }

  function legacyCopy(text, onDone, onFail) {
    // Tier 2: temporary textarea + execCommand
    try {
      var ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.top = "-1000px";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, text.length);
      var ok = false;
      try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
      document.body.removeChild(ta);
      if (ok) { if (onDone) onDone(true); return; }
    } catch (e) { /* fall through */ }
    // Tier 3: manual — open a modal-style prompt for the user to copy
    manualCopy(text, onDone, onFail);
  }

  function manualCopy(text, onDone, onFail) {
    try {
      window.prompt("Long-press / Ctrl+C to copy:\n", text);
      if (onDone) onDone(true);
    } catch (e) {
      if (onFail) onFail(e);
    }
  }

  /* ---------- text sharing ---------- */
  function canShare() {
    return !!(navigator.share);
  }

  function shareText(text, onSuccess, onCancel) {
    if (canShare()) {
      navigator.share({ text: text }).then(
        function () { if (onSuccess) onSuccess("shared"); },
        function (err) {
          if (err && err.name === "AbortError") {
            if (onCancel) onCancel(err);
          } else {
            copyText(text,
              function () { if (onSuccess) onSuccess("copied"); },
              function () { if (onCancel) onCancel(err); });
          }
        }
      );
    } else {
      copyText(text,
        function () { if (onSuccess) onSuccess("copied"); },
        function () { if (onCancel) onCancel(null); });
    }
  }

  /* ---------- file sharing (result card PNG) ---------- */
  function canShareFiles() {
    try {
      return !!(navigator.canShare && navigator.canShare({ files: [new File([""], "t.png", { type: "image/png" })] }));
    } catch (e) {
      return false;
    }
  }

  function shareFileBlob(blob, title, text, onSuccess, onFail) {
    if (!canShareFiles()) { if (onFail) onFail("unsupported"); return; }
    try {
      var file = new File([blob], (title || "mindmirror") + ".png", { type: "image/png" });
      navigator.share({
        files: [file],
        title: "MindMirror",
        text: text || ""
      }).then(function () { if (onSuccess) onSuccess("shared"); },
        function (err) { if (onFail) onFail(err); });
    } catch (e) {
      if (onFail) onFail(e);
    }
  }

  /* ---------- PNG download from canvas ---------- */
  function downloadCanvas(canvas, filename, onFallback) {
    var saved = false;
    try {
      if (canvas.toBlob) {
        canvas.toBlob(function (blob) {
          if (!blob) { if (onFallback) onFallback(canvas); return; }
          try {
            var url = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = url;
            a.download = filename || "mindmirror-result.png";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
          } catch (e) {
            if (onFallback) onFallback(canvas);
          }
        }, "image/png");
        saved = true;
      }
    } catch (e) { saved = false; }

    if (!saved) {
      // toBlob missing or threw — try toDataURL
      try {
        var dataUrl = canvas.toDataURL("image/png");
        if (onFallback) onFallback(canvas, dataUrl);
      } catch (e2) {
        if (onFallback) onFallback(canvas);
      }
    }
  }

  return {
    copyText: copyText,
    shareText: shareText,
    canShare: canShare,
    canShareFiles: canShareFiles,
    shareFileBlob: shareFileBlob,
    downloadCanvas: downloadCanvas
  };
})();
