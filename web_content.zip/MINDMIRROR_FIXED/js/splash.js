/* ============================================================
   MindMirror — splash.js
   Orchestrates the startup splash. The splash leaves ONCE, when
   (a) the app reports it is ready AND (b) the short intentional
   entrance has played. Safeguards: failsafe timer, error hook,
   image-failure skip. The node is removed, never re-created, so
   background/resume and in-app navigation can't replay it.
   ============================================================ */
var MMSplash = (function () {
  "use strict";
  var MIN_SHOW_MS = 2300;      // fast startup: let the signature moment + wordmark land
  var MIN_REDUCED_MS = 500;    // prefers-reduced-motion
  var FAILSAFE_MS = 6000;      // never wait longer than this for readiness
  var FADE_MS = 300;           // must match .sp-leave transition in splash.css

  var root = document.getElementById("splash");
  var t0 = Date.now();
  var ready = false, leaving = false, done = false, scheduled = false, skipEntrance = false;
  var waiters = [], failsafe = null, leaveTimer = null;
  var reduced = false;
  try { reduced = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches); } catch (e) {}

  function finish() {
    if (done) return;
    done = true;
    clearTimeout(failsafe); clearTimeout(leaveTimer);
    window.removeEventListener("error", onError);
    if (root && root.parentNode) root.parentNode.removeChild(root);
    var fns = waiters; waiters = [];
    for (var i = 0; i < fns.length; i++) { try { fns[i](); } catch (e) {} }
  }

  function leave() {
    if (leaving || done) return;
    leaving = true;
    if (!root) { finish(); return; }
    root.setAttribute("aria-hidden", "true");
    root.addEventListener("transitionend", function (e) {
      if (e.target === root && e.propertyName === "opacity") finish();
    });
    setTimeout(finish, FADE_MS + 150);              // fallback if transitionend never fires
    root.className += " sp-leave";
  }

  function tryLeave() {
    if (!ready || scheduled || done) return;
    scheduled = true;
    var min = skipEntrance ? 0 : (reduced ? MIN_REDUCED_MS : MIN_SHOW_MS);
    var wait = min - (Date.now() - t0);
    if (wait > 0) leaveTimer = setTimeout(leave, wait); else leave();
  }

  function onError() { ready = true; tryLeave(); }   // a startup error must not hide the app behind the splash

  if (root) {
    var imgs = root.getElementsByTagName("img");
    for (var i = 0; i < imgs.length; i++) {
      // the request may already have failed before this script ran
      if (imgs[i].complete && imgs[i].naturalWidth === 0) skipEntrance = true;
      imgs[i].addEventListener("error", function () {
        // splash art missing: don't show a broken animation; leave as soon as the app is ready
        skipEntrance = true;
        if (ready) { clearTimeout(leaveTimer); leave(); }
      });
    }
    window.addEventListener("error", onError);
    failsafe = setTimeout(function () { ready = true; scheduled = true; leave(); }, FAILSAFE_MS);
  } else {
    done = true;
  }

  return {
    appReady: function () { ready = true; tryLeave(); },
    whenDone: function (fn) { if (done) fn(); else waiters.push(fn); }
  };
})();
