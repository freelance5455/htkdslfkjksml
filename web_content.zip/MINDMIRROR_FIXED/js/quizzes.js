/* ============================================================
   MindMirror — quizzes.js
   Quiz data. 31 distinct questions, each with 4 options.
   Every option maps to dimension weights: [analytical, social,
   exploratory, structured, reflective] — numbers 0..2.
   Consumed by scoring.js. No fetch, no JSON files.
   ============================================================ */

/* Shared dimension keys (5 traits scored 0-100):
   analytical  — decision-making preference (logic & analysis)
   social      — social preference (people & perspectives)
   exploratory — problem-solving preference (curiosity & trying)
   structured  — planning preference (order & plans)
   reflective  — reflection preference (introspection & calm)
*/

var QUIZZES = (function () {
  "use strict";

  /* ---------- QUIZ 1: How Do You Think? (main, 15 questions) ---------- */
  var mainQuiz = {
    id: "how-you-think",
    title: "How Do You Think?",
    subtitle: "The full MindMirror profile across five thinking dimensions.",
    questions: 15,
    minutes: 6,
    traits: ["analytical", "social", "exploratory", "structured", "reflective"],
    traitLabels: {
      analytical: "Analysis",
      social: "Connection",
      exploratory: "Exploration",
      structured: "Planning",
      reflective: "Reflection"
    },
    items: [
      {
        q: "When facing an unfamiliar problem, what do you usually do first?",
        options: [
          { t: "Break it into smaller parts.", w: [2, 0, 0, 1, 0] },
          { t: "Explore several possible approaches.", w: [0, 0, 2, 0, 1] },
          { t: "Ask someone for another perspective.", w: [0, 2, 0, 0, 1] },
          { t: "Try something and learn from the result.", w: [0, 0, 2, 0, 1] }
        ]
      },
      {
        q: "How do you prefer to spend a free weekend?",
        options: [
          { t: "Deep in a personal project or hobby.", w: [1, 0, 1, 1, 1] },
          { t: "Out with friends, meeting new people.", w: [0, 2, 1, 0, 0] },
          { t: "Wandering somewhere new with no fixed plan.", w: [0, 0, 2, 0, 1] },
          { t: "Recharging quietly with a good book.", w: [0, 0, 0, 0, 2] }
        ]
      },
      {
        q: "When making an important decision, what weighs most for you?",
        options: [
          { t: "Facts, data, and logical pros and cons.", w: [2, 0, 0, 1, 1] },
          { t: "How it affects the people I care about.", w: [0, 2, 0, 0, 1] },
          { t: "My gut feeling about what could be possible.", w: [0, 0, 2, 0, 1] },
          { t: "A clear plan with steps I can follow.", w: [1, 0, 0, 2, 0] }
        ]
      },
      {
        q: "Your ideal way to learn something new is:",
        options: [
          { t: "Studying how it works before touching it.", w: [2, 0, 0, 1, 1] },
          { t: "Discussing it with others who know it.", w: [0, 2, 1, 0, 0] },
          { t: "Experimenting until it makes sense.", w: [0, 0, 2, 0, 1] },
          { t: "Following a structured course step by step.", w: [0, 0, 0, 2, 0] }
        ]
      },
      {
        q: "A group project is announced. Your natural role is:",
        options: [
          { t: "Planning the timeline and dividing tasks.", w: [1, 1, 0, 2, 0] },
          { t: "Coordinating people and keeping morale up.", w: [0, 2, 0, 1, 0] },
          { t: "Generating ideas nobody else thought of.", w: [0, 0, 2, 0, 1] },
          { t: "Reviewing everything carefully before it ships.", w: [2, 0, 0, 1, 1] }
        ]
      },
      {
        q: "When plans suddenly change, you usually:",
        options: [
          { t: "Feel a jolt, then reorganize quickly.", w: [1, 0, 1, 2, 1] },
          { t: "Go with the flow and enjoy the surprise.", w: [0, 1, 2, 0, 0] },
          { t: "Check how others feel about the change.", w: [0, 2, 0, 0, 1] },
          { t: "Think through the new situation alone.", w: [1, 0, 0, 1, 2] }
        ]
      },
      {
        q: "Which work environment brings out your best?",
        options: [
          { t: "Quiet, focused, and well organized.", w: [1, 0, 0, 2, 2] },
          { t: "Lively, collaborative, full of conversation.", w: [0, 2, 1, 0, 0] },
          { t: "Flexible, with room to improvise.", w: [0, 0, 2, 0, 1] },
          { t: "Clear goals with freedom in the details.", w: [1, 0, 1, 1, 0] }
        ]
      },
      {
        q: "How do you feel about making lists and schedules?",
        options: [
          { t: "I live by them — they keep me sane.", w: [1, 0, 0, 2, 0] },
          { t: "I make them, then mostly ignore them.", w: [0, 0, 2, 0, 1] },
          { t: "I plan loosely and adjust as I go.", w: [0, 0, 1, 1, 1] },
          { t: "I plan in my head rather than on paper.", w: [1, 0, 0, 0, 2] }
        ]
      },
      {
        q: "After a busy social day, you recharge by:",
        options: [
          { t: "Being completely alone for a while.", w: [0, 0, 0, 0, 2] },
          { t: "Calling one close friend to debrief.", w: [0, 2, 0, 0, 1] },
          { t: "Doing something hands-on and absorbing.", w: [1, 0, 2, 0, 0] },
          { t: "Journaling or sorting your thoughts.", w: [0, 0, 0, 1, 2] }
        ]
      },
      {
        q: "When someone challenges your idea, you typically:",
        options: [
          { t: "Defend it with logic and evidence.", w: [2, 0, 0, 0, 1] },
          { t: "Ask questions to understand their view.", w: [0, 2, 1, 0, 1] },
          { t: "Get curious — maybe they're onto something.", w: [0, 1, 2, 0, 1] },
          { t: "Reconsider it privately later.", w: [0, 0, 0, 0, 2] }
        ]
      },
      {
        q: "Your relationship with deadlines is usually:",
        options: [
          { t: "I finish early — early is calm.", w: [1, 0, 0, 2, 1] },
          { t: "I finish on time with a steady pace.", w: [1, 1, 0, 1, 0] },
          { t: "I find my spark close to the deadline.", w: [0, 0, 2, 0, 1] },
          { t: "I renegotiate deadlines when needed.", w: [0, 2, 1, 0, 0] }
        ]
      },
      {
        q: "What kind of puzzles do you enjoy most?",
        options: [
          { t: "Logic puzzles with one clean solution.", w: [2, 0, 0, 1, 0] },
          { t: "Riddles that twist perspective.", w: [1, 0, 2, 0, 1] },
          { t: "Cooperative puzzles solved with friends.", w: [0, 2, 1, 0, 0] },
          { t: "Open-ended puzzles with many answers.", w: [0, 0, 2, 0, 1] }
        ]
      },
      {
        q: "In a debate, your instinct is to:",
        options: [
          { t: "Build the strongest rational case.", w: [2, 0, 0, 0, 1] },
          { t: "Find common ground between sides.", w: [0, 2, 0, 1, 0] },
          { t: "Challenge assumptions on both sides.", w: [1, 0, 2, 0, 1] },
          { t: "Listen more than you speak.", w: [0, 1, 0, 0, 2] }
        ]
      },
      {
        q: "How do you usually start your day?",
        options: [
          { t: "Reviewing today's plan before anything else.", w: [1, 0, 0, 2, 1] },
          { t: "Checking messages and saying good morning.", w: [0, 2, 0, 0, 0] },
          { t: "Following whatever mood the morning brings.", w: [0, 0, 2, 0, 0] },
          { t: "A few quiet minutes of thinking.", w: [0, 0, 0, 1, 2] }
        ]
      },
      {
        q: "When you imagine your best possible future, you see:",
        options: [
          { t: "A detailed roadmap already in motion.", w: [1, 0, 0, 2, 1] },
          { t: "New places, ideas, and possibilities.", w: [0, 0, 2, 0, 1] },
          { t: "A circle of people you love being around.", w: [0, 2, 0, 0, 0] },
          { t: "Deep understanding of yourself and the world.", w: [1, 0, 0, 0, 2] }
        ]
      }
    ]
  };

  /* ---------- QUIZ 2: How Do You Make Decisions? (8 questions) ---------- */
  var decisionsQuiz = {
    id: "how-you-decide",
    title: "How Do You Make Decisions?",
    subtitle: "Explore the thinking style behind your everyday choices.",
    questions: 8,
    minutes: 3,
    traits: ["analytical", "social", "exploratory", "structured", "reflective"],
    traitLabels: {
      analytical: "Logic",
      social: "Input",
      exploratory: "Intuition",
      structured: "Method",
      reflective: "Deliberation"
    },
    items: [
      {
        q: "You're choosing between two job offers. Your first instinct is to:",
        options: [
          { t: "Build a spreadsheet comparing everything.", w: [2, 0, 0, 2, 1] },
          { t: "Talk it over with people you trust.", w: [0, 2, 0, 0, 1] },
          { t: "Picture yourself actually living each option.", w: [0, 0, 2, 0, 1] },
          { t: "Sit with it for a few days quietly.", w: [0, 0, 0, 0, 2] }
        ]
      },
      {
        q: "When a decision goes wrong, you usually:",
        options: [
          { t: "Analyze exactly where the logic failed.", w: [2, 0, 0, 1, 1] },
          { t: "Ask others what they would have done.", w: [0, 2, 0, 0, 1] },
          { t: "Shrug — you win some, you learn some.", w: [0, 0, 2, 0, 0] },
          { t: "Add a step to your process for next time.", w: [1, 0, 0, 2, 1] }
        ]
      },
      {
        q: "How much do other people's opinions shape your choices?",
        options: [
          { t: "Very little — it's my call to make.", w: [1, 0, 1, 0, 1] },
          { t: "A lot — other views reveal my blind spots.", w: [0, 2, 0, 0, 1] },
          { t: "Depends how much I trust them.", w: [1, 1, 0, 1, 1] },
          { t: "I prefer to decide alone, then inform others.", w: [1, 0, 0, 1, 2] }
        ]
      },
      {
        q: "You need to buy something significant. You:",
        options: [
          { t: "Research specs and reviews for days.", w: [2, 0, 1, 1, 0] },
          { t: "Ask friends what they'd recommend.", w: [0, 2, 0, 0, 0] },
          { t: "Visit a store and see what feels right.", w: [0, 0, 2, 0, 0] },
          { t: "Set a budget and criteria, then filter.", w: [1, 0, 0, 2, 0] }
        ]
      },
      {
        q: "Big life decisions feel most comfortable when:",
        options: [
          { t: "Every option has been logically mapped.", w: [2, 0, 0, 1, 1] },
          { t: "The people who matter are on board.", w: [0, 2, 0, 0, 0] },
          { t: "It matches a vision you can feel.", w: [0, 0, 2, 0, 1] },
          { t: "There's a plan A, B, and C.", w: [1, 0, 0, 2, 0] }
        ]
      },
      {
        q: "When you must decide fast, you rely on:",
        options: [
          { t: "Whatever rule of thumb fits the case.", w: [2, 0, 0, 1, 0] },
          { t: "A quick call to someone seasoned.", w: [0, 2, 0, 0, 0] },
          { t: "Your gut and momentum.", w: [0, 0, 2, 0, 0] },
          { t: "The default you've already prepared.", w: [1, 0, 0, 2, 1] }
        ]
      },
      {
        q: "Do you ever revisit decisions you've already made?",
        options: [
          { t: "Rarely — doubt wastes energy.", w: [1, 0, 1, 1, 0] },
          { t: "Often — new input deserves a second look.", w: [0, 2, 0, 0, 1] },
          { t: "Only if circumstances genuinely change.", w: [1, 0, 0, 2, 1] },
          { t: "Always — reflection sharpens the next choice.", w: [0, 0, 0, 0, 2] }
        ]
      },
      {
        q: "What does a 'good decision' mean to you?",
        options: [
          { t: "One supported by the best available evidence.", w: [2, 0, 0, 1, 0] },
          { t: "One that keeps relationships healthy.", w: [0, 2, 0, 0, 1] },
          { t: "One that keeps the future open.", w: [0, 0, 2, 0, 1] },
          { t: "One that fits a long-term plan.", w: [1, 0, 0, 2, 1] }
        ]
      }
    ]
  };

  /* ---------- QUIZ 3: What's Your Planning Style? (8 questions) ---------- */
  var planningQuiz = {
    id: "planning-style",
    title: "What's Your Planning Style?",
    subtitle: "Find out how you structure goals, time, and big projects.",
    questions: 8,
    minutes: 3,
    traits: ["analytical", "social", "exploratory", "structured", "reflective"],
    traitLabels: {
      analytical: "Precision",
      social: "Alignment",
      exploratory: "Flexibility",
      structured: "Structure",
      reflective: "Review"
    },
    items: [
      {
        q: "You're starting a big personal project. The first thing you do is:",
        options: [
          { t: "Define the goal precisely and measure success.", w: [2, 0, 0, 2, 0] },
          { t: "Recruit friends or find collaborators.", w: [0, 2, 0, 0, 0] },
          { t: "Start immediately and steer as you learn.", w: [0, 0, 2, 0, 1] },
          { t: "Sketch milestones across the whole timeline.", w: [1, 0, 0, 2, 1] }
        ]
      },
      {
        q: "Your calendar is best described as:",
        options: [
          { t: "Fully booked and color-coded.", w: [1, 0, 0, 2, 0] },
          { t: "Mostly empty — plans live in my head.", w: [0, 0, 1, 0, 1] },
          { t: "Flexible blocks with room to improvise.", w: [0, 1, 2, 1, 0] },
          { t: "Shared with others so plans stay aligned.", w: [0, 2, 0, 1, 0] }
        ]
      },
      {
        q: "When a task takes longer than planned, you:",
        options: [
          { t: "Recalculate and update the whole schedule.", w: [2, 0, 0, 2, 1] },
          { t: "Cut scope to protect the deadline.", w: [1, 0, 0, 2, 0] },
          { t: "See where the project wants to go instead.", w: [0, 0, 2, 0, 1] },
          { t: "Reflect on why the estimate was off.", w: [0, 0, 0, 1, 2] }
        ]
      },
      {
        q: "How do you track progress on your goals?",
        options: [
          { t: "Numbers, metrics, and checklists.", w: [2, 0, 0, 2, 1] },
          { t: "Checking in with an accountability partner.", w: [0, 2, 0, 0, 0] },
          { t: "I notice progress when it's undeniable.", w: [0, 0, 2, 0, 0] },
          { t: "Weekly review notes with myself.", w: [0, 0, 0, 1, 2] }
        ]
      },
      {
        q: "Spontaneous invitations for this weekend make you feel:",
        options: [
          { t: "Annoyed — you had a plan.", w: [1, 0, 0, 2, 0] },
          { t: "Delighted — say yes to everything.", w: [0, 1, 2, 0, 0] },
          { t: "Open — depends who's asking.", w: [0, 2, 1, 0, 0] },
          { t: "Torn — you'll weigh it for a while.", w: [0, 0, 0, 1, 2] }
        ]
      },
      {
        q: "Your to-do list, realistically, is:",
        options: [
          { t: "Precise, prioritized, and mostly finished.", w: [2, 0, 0, 2, 1] },
          { t: "A creative pile of half-tamed ideas.", w: [0, 0, 2, 0, 0] },
          { t: "Shared tasks agreed with other people.", w: [0, 2, 0, 1, 0] },
          { t: "Three meaningful things per day, no more.", w: [0, 0, 0, 1, 2] }
        ]
      },
      {
        q: "Long-term goals work best for you when they are:",
        options: [
          { t: "Broken into quarterly targets.", w: [1, 0, 0, 2, 1] },
          { t: "Ambitious enough to excite others too.", w: [0, 2, 1, 0, 0] },
          { t: "Directional, not over-specified.", w: [0, 0, 2, 0, 1] },
          { t: "Written down and revisited often.", w: [1, 0, 0, 1, 2] }
        ]
      },
      {
        q: "A plan is only as good as:",
        options: [
          { t: "Its assumptions being verified.", w: [2, 0, 0, 1, 1] },
          { t: "The team actually believing in it.", w: [0, 2, 0, 1, 0] },
          { t: "Its willingness to bend with reality.", w: [0, 0, 2, 0, 1] },
          { t: "The lessons built into its revisions.", w: [0, 0, 0, 1, 2] }
        ]
      }
    ]
  };

  return {
    all: [mainQuiz, decisionsQuiz, planningQuiz],
    getById: function (id) {
      for (var i = 0; i < this.all.length; i++) {
        if (this.all[i].id === id) return this.all[i];
      }
      return null;
    }
  };
})();
