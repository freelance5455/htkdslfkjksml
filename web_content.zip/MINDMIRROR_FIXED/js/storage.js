/* ============================================================
   MindMirror — storage.js
   Safe localStorage wrapper with in-memory fallback.
   All access wrapped in try/catch. Never crashes when
   localStorage is unavailable (private mode, WebView limits).
   ============================================================ */

var MMStorage = (function () {
  "use strict";

  var PREFIX = "mindmirror.";
  var KEYS = {
    PROGRESS: "mindmirror.progress",          // unfinished quiz state
    RESULTS: "mindmirror.results",            // completed results array
    PREFS: "mindmirror.prefs"                 // user preferences
  };

  var memoryStore = {};   // fallback when localStorage is unavailable
  var persistent = (function () {
    try {
      var k = PREFIX + "__test";
      window.localStorage.setItem(k, "1");
      window.localStorage.removeItem(k);
      return true;
    } catch (e) {
      return false;
    }
  })();

  function safeParse(raw) {
    if (typeof raw !== "string" || raw === "") return null;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null; // invalid JSON treated as missing
    }
  }

  function get(key, fallbackValue) {
    var raw = null;
    try {
      raw = persistent ? window.localStorage.getItem(key) : memoryStore[key];
    } catch (e) {
      raw = memoryStore[key] || null;
    }
    var parsed = safeParse(raw);
    return parsed === null ? (typeof fallbackValue !== "undefined" ? fallbackValue : null) : parsed;
  }

  function set(key, value) {
    var raw;
    try {
      raw = JSON.stringify(value);
    } catch (e) {
      return false;
    }
    try {
      if (persistent) {
        window.localStorage.setItem(key, raw);
      } else {
        memoryStore[key] = raw;
      }
      return true;
    } catch (e) {
      memoryStore[key] = raw; // last-resort memory write
      return false;
    }
  }

  function remove(key) {
    try {
      if (persistent) window.localStorage.removeItem(key);
    } catch (e) { /* ignore */ }
    delete memoryStore[key];
  }

  /* ---------- public API ---------- */

  return {
    KEYS: KEYS,
    isPersistent: function () { return persistent; },

    /* Quiz progress (unfinished quiz). quizId + answers[] + index */
    getProgress: function () {
      return get(KEYS.PROGRESS, null);
    },
    saveProgress: function (progress) {
      return set(KEYS.PROGRESS, progress);
    },
    clearProgress: function () {
      remove(KEYS.PROGRESS);
    },

    /* Completed results: newest first. */
    getResults: function () {
      return get(KEYS.RESULTS, []);
    },
    saveResult: function (result) {
      if (!result || !result.quizId) return false;
      var list = get(KEYS.RESULTS, []);
      // keep only the latest result per quiz (retake replaces)
      list = list.filter(function (r) { return r.quizId !== result.quizId; });
      list.unshift(result);
      return set(KEYS.RESULTS, list);
    },

    /* Preferences */
    getPrefs: function () {
      return get(KEYS.PREFS, {});
    },
    savePrefs: function (prefs) {
      return set(KEYS.PREFS, prefs);
    },

    /* Safe reset functions */
    clearHistory: function () {
      remove(KEYS.RESULTS);
    },
    clearAll: function () {
      // remove every mindmirror.* key we know about, plus any stragglers
      remove(KEYS.PROGRESS);
      remove(KEYS.RESULTS);
      remove(KEYS.PREFS);
      try {
        if (persistent) {
          var doomed = [];
          for (var i = 0; i < window.localStorage.length; i++) {
            var k = window.localStorage.key(i);
            if (k && k.indexOf(PREFIX) === 0) doomed.push(k);
          }
          for (var j = 0; j < doomed.length; j++) window.localStorage.removeItem(doomed[j]);
        }
      } catch (e) { /* ignore */ }
      memoryStore = {};
    }
  };
})();
