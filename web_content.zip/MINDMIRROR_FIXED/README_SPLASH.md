# MindMirror — "The Inner Reveal" loading screen

## Files changed / added
- **New** `css/splash.css` — all splash styling + keyframes (reflection mask is an inline data URI on purpose: `file://` mask-image requests are CORS-blocked in Chromium/WebView).
- **New** `js/splash.js` — startup orchestration (`MMSplash`).
- **New** `assets/splash/` — `lid_top.png`, `lid_bottom.png`, `iris_l.png`, `iris_r.png` (≈230 KB total). These are slices of your supplied eye PNG with the background removed; recomposited they match the original artwork.
- **Edited** `index.html` — splash markup right after `<body>`, `splash.css` link, `splash.js` script before `app.js`.
- **Edited** `js/app.js` — `init()` now calls `MMSplash.appReady()` at its end, and the "Welcome back / resume" dialog and the storage-unavailable toast wait until the splash has left (otherwise they would appear underneath it). Behaviour and 450 ms / 1200 ms delays are unchanged, just counted from when the splash is gone. If `MMSplash` is missing the app behaves exactly as before.
- Not touched: quiz/scoring/results/history/sharing/settings code, `style.css`, icons, in-app logo, localStorage.

## How the animation works
Eight stages, CSS only (transform/opacity plus small clip-paths): quiet dark screen → one lavender stroke on the eye's axis → lids wipe in from opposite directions (top L→R, bottom R→L) → the two iris halves approach from ±4 % and settle on the seam → one narrow reflection pass clipped to the logo silhouette → `MINDMIRROR` + tagline rise a few px → thin indeterminate trace under the text → 300 ms opacity exit. Base styles are the final state, so if animations are disabled the logo is complete. `prefers-reduced-motion` shows the final composition and fades out in ~0.5 s.

## How readiness controls the exit
Startup is fully local and synchronous, so "ready" = `init()` finished. The splash leaves **once** when ready **and** `MIN_SHOW_MS` (2300 ms, top of `js/splash.js`) has passed, then fades 300 ms and its node is removed (never re-created, so resume-from-background / in-app navigation can't replay it). Safeguards: a `window` error before ready dismisses it; 6 s JS failsafe; 8 s CSS-only failsafe if JS itself dies; missing splash art skips the splash. To shorten the intro, lower `MIN_SHOW_MS`.

## How to test before building an APK
Open `index.html` in desktop Chrome (use device toolbar, ~390×844). To replay: hard-reload. To test resume dialog: start a quiz, answer a question, reload.

## What was verified (desktop Chromium via Playwright) vs. not
Verified: frame-by-frame look at 9 timestamps; no console/JS errors; splash intercepts taps while visible and not after removal; splash removed ≈2.8 s after navigation; resume dialog appears only after splash and both buttons work (Later → home, Resume → quiz, option selectable); init-throws, missing-image and reduced-motion paths; 320×568 / 390×844 / 412×915 layouts, no horizontal scroll.
**Not verified:** the real APK/WebView on a device — animation smoothness on low-end hardware, system-bar/safe-area insets inside your converter's WebView, and `file:///android_asset` loading. Please test on a phone before release.
