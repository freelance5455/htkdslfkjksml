============================================================
  MINDMIRROR — Discover the Way You Think
  Standalone HTML/CSS/JavaScript app · Version 1.0.0
============================================================

WHAT IS MINDMIRROR?
MindMirror is an offline personality-discovery app. Answer
thoughtful questions about how you think, decide, and plan,
and receive a personal profile with trait scores, strengths,
reflection points, practical suggestions, and a shareable
result card.

Everything runs 100% on your device. No server, no account,
no internet connection, and no personal data collection.

------------------------------------------------------------
QUICK START (BROWSER TEST)
------------------------------------------------------------
1. Extract this ZIP file.
2. Open the extracted MINDMIRROR folder.
3. Open index.html in a modern browser (Chrome, Edge, Firefox,
   or an Android WebView). The app starts on the Home screen.

No installation, no build step, and no Node.js is required.

------------------------------------------------------------
TURNING IT INTO AN ANDROID APK
------------------------------------------------------------
MindMirror is a static web app, so any "HTML to APK" converter
or WebView wrapper works:

1. Extract the ZIP (if you have not already).
2. Open your HTML-to-APK converter (for example Website 2 APK,
   WebIntoApp, AppsGeyser, Median, or an Android Studio
   WebView template that loads local assets).
3. Import the whole MINDMIRROR folder as the project assets.
4. Set the start page / entry file to:  index.html
5. Enable JavaScript in the WebView settings if the converter
   asks (it is required).
6. Recommended settings: allow local file access, disable
   "open external links", portrait orientation.
7. Build the APK, install it, and test on your phone.

OFFLINE BEHAVIOR
All quizzes, scoring, and saving work fully offline. The only
optional online feature is the native share sheet, which is
used when available and silently falls back to copying text.

------------------------------------------------------------
PROJECT STRUCTURE
------------------------------------------------------------
MINDMIRROR/
|-- index.html        App shell, screens, inline SVG icon sprite
|-- css/
|   +-- style.css     All styling (dark purple premium theme)
|-- js/
|   |-- storage.js    Safe localStorage wrapper + memory fallback
|   |-- quizzes.js    All quiz questions and answer weights
|   |-- scoring.js    Deterministic scoring engine + 8 profiles
|   |-- sharing.js    Clipboard / Web Share / PNG download helpers
|   +-- app.js        Screens, quiz flow, results, result card
|-- assets/
|   |-- logo.svg      Standalone brand logo
|   +-- icon.svg      Square app icon (APK launcher icon source)
+-- README.txt        This file

------------------------------------------------------------
THE QUIZZES
------------------------------------------------------------
1. How Do You Think?           15 questions · approx. 6 min (main profile)
2. How Do You Make Decisions?   8 questions · approx. 3 min
3. What's Your Planning Style?  8 questions · approx. 3 min

Scoring is deterministic: the same answers always produce the
same scores and the same profile. Eight profiles exist:
The Strategist, The Explorer, The Builder, The Observer,
The Connector, The Adapter, The Visionary, The Balancer.

An unfinished quiz is saved automatically. Close the app and
reopen it: the Home screen offers to resume where you left
off (Discover shows a Resume button too).

------------------------------------------------------------
DATA & PRIVACY
------------------------------------------------------------
- Answers, results, and quiz progress are saved only in the
  browser/WebView localStorage on your device.
- Nothing is uploaded anywhere; results do not sync across
  devices.
- Settings lets you clear quiz history, reset an unfinished
  quiz, or delete all saved data (each with a confirmation
  dialog).
- If localStorage is unavailable (some private modes), the
  app still runs; results just will not persist between
  sessions.

------------------------------------------------------------
HONEST TESTING NOTES
------------------------------------------------------------
Verified with automated tests before packaging:
- JavaScript syntax checks on every file.
- Every question has exactly four valid options.
- Scoring determinism and 0-100 score ranges.
- All eight profiles are reachable from real answer
  combinations (exhaustive check for the 8-question quizzes).
- LocalStorage behavior, invalid-JSON handling, and the
  no-storage memory fallback.
- Every element id and SVG icon reference used by the code
  exists in index.html; every referenced file exists.

NOT tested in this environment (no real device available):
- Rendering inside an actual Android WebView / finished APK.
- The native share sheet and long-press image saving on a
  physical device.
Please do a quick pass on a real device after building the
APK. The app degrades gracefully where features are missing.

------------------------------------------------------------
DISCLAIMER
------------------------------------------------------------
MindMirror profiles are for entertainment and self-reflection.
They are not scientifically validated and are not a diagnosis
of any kind.

Discover the Way You Think.
