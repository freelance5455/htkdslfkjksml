/* Fangbuch: Oberfläche, Speicher und Datenabruf */
(function () {
  'use strict';

  const FB = window.FB;
  const $app = document.getElementById('app');
  const $toast = document.getElementById('toast');

  const DB_NAME = 'fangbuch';
  const STORE = 'catches';
  const SESS = 'sessions';
  const FORECAST = 'https://api.open-meteo.com/v1/forecast?';
  const ARCHIVE = 'https://archive-api.open-meteo.com/v1/archive?';
  const MARINE = 'https://marine-api.open-meteo.com/v1/marine?';
  const DAY = 864e5;
  const DEFAULT_CHIPS = ['Hecht', 'Zander', 'Barsch', 'Dorsch', 'Forelle'];
  const FISH_SVG = '<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M7 32c8-12 24-14 34-4l13-8v24l-13-8C31 46 15 44 7 32z" fill="currentColor"/><circle cx="17" cy="30" r="2.2" fill="var(--surface-2)"/></svg>';

  const esc = FB.esc;
  const byId = (id) => document.getElementById(id);
  const newId = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2, 8));

  let urls = [];
  const objUrl = (blob) => { const u = URL.createObjectURL(blob); urls.push(u); return u; };
  const freeUrls = () => { urls.forEach((u) => URL.revokeObjectURL(u)); urls = []; };

  let toastTimer = null;
  function toast(msg) {
    $toast.textContent = msg;
    $toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => $toast.classList.remove('show'), 3200);
  }

  /* ---------- Speicher (IndexedDB, nur auf diesem Gerät) ---------- */
  let dbp = null;
  function openDb() {
    if (!dbp) {
      dbp = new Promise((resolve, reject) => {
        const r = indexedDB.open(DB_NAME, 2);
        r.onupgradeneeded = () => {
          const db = r.result;
          if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
          if (!db.objectStoreNames.contains(SESS)) db.createObjectStore(SESS, { keyPath: 'id' });
        };
        r.onsuccess = () => {
          r.result.onversionchange = () => { r.result.close(); dbp = null; };
          resolve(r.result);
        };
        r.onerror = () => { dbp = null; reject(r.error); };
      });
    }
    return dbp;
  }
  function run(store, mode, fn) {
    return openDb().then((db) => new Promise((resolve, reject) => {
      const tx = db.transaction(store, mode);
      const rq = fn(tx.objectStore(store));
      tx.oncomplete = () => resolve(rq ? rq.result : undefined);
      tx.onerror = tx.onabort = () => reject(tx.error);
    }));
  }
  const dbAll = () => run(STORE, 'readonly', (s) => s.getAll());
  const dbGet = (id) => run(STORE, 'readonly', (s) => s.get(id));
  const dbPut = (rec) => run(STORE, 'readwrite', (s) => s.put(rec));
  const dbDel = (id) => run(STORE, 'readwrite', (s) => s.delete(id));
  const sessAll = () => run(SESS, 'readonly', (s) => s.getAll());
  const sessGet = (id) => run(SESS, 'readonly', (s) => s.get(id));
  const sessPut = (rec) => run(SESS, 'readwrite', (s) => s.put(rec));
  const sessDel = (id) => run(SESS, 'readwrite', (s) => s.delete(id));

  /* ---------- Wetter, Wind, Luftdruck und Tide (Open-Meteo) ---------- */
  async function fetchJson(url) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 12000);
    try {
      const res = await fetch(url, { signal: ctl.signal });
      if (!res.ok) { const e = new Error('HTTP ' + res.status); e.status = res.status; throw e; }
      return await res.json();
    } finally {
      clearTimeout(timer);
    }
  }
  const coordQuery = (lat, lon) => 'latitude=' + lat.toFixed(4) + '&longitude=' + lon.toFixed(4);

  async function fetchWeather(lat, lon, t) {
    const q = coordQuery(lat, lon) +
      '&hourly=temperature_2m,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,pressure_msl' +
      '&wind_speed_unit=kmh&start_date=' + FB.ymdUTC(t - DAY) + '&end_date=' + FB.ymdUTC(t + DAY);
    const old = Date.now() - t > 85 * DAY;
    try {
      return FB.buildWeather(await fetchJson((old ? ARCHIVE : FORECAST) + q), t);
    } catch (e) {
      if (e.status !== 400) throw e;
      if (old) return null;
      try {
        return FB.buildWeather(await fetchJson(ARCHIVE + q), t);
      } catch (e2) {
        if (e2.status === 400) return null;
        throw e2;
      }
    }
  }

  async function fetchTide(lat, lon, t) {
    const q = coordQuery(lat, lon) + '&hourly=sea_level_height_msl&start_date=' + FB.ymdUTC(t - DAY) + '&end_date=' + FB.ymdUTC(t + DAY);
    try {
      return FB.analyzeTide(await fetchJson(MARINE + q), t);
    } catch (e) {
      if (e.status === 400) return null;
      throw e;
    }
  }

  /* status: ok (Daten da), none (Dienst hat keine Daten), pending (kein Netz, später erneut) */
  async function getConditions(lat, lon, t) {
    const [w, ti] = await Promise.allSettled([fetchWeather(lat, lon, t), fetchTide(lat, lon, t)]);
    if (w.status === 'rejected') return { status: 'pending', conditions: null };
    const conditions = { weather: w.value, tide: ti.status === 'fulfilled' ? ti.value : null, fetchedAt: Date.now() };
    return { status: conditions.weather || conditions.tide ? 'ok' : 'none', conditions };
  }

  let retrying = false;
  async function retryPending() {
    if (retrying || !navigator.onLine) return;
    retrying = true;
    let changed = false;
    try {
      const all = await dbAll();
      for (const c of all) {
        if (c.condStatus !== 'pending' || c.lat == null) continue;
        const r = await getConditions(c.lat, c.lon, c.caughtAt);
        c.tries = (c.tries || 0) + 1;
        if (r.status === 'pending') {
          if (c.tries < 6) { await dbPut(c); continue; }
          c.condStatus = 'none';
        } else {
          c.conditions = r.conditions;
          c.condStatus = r.status;
        }
        await dbPut(c);
        changed = true;
      }
    } catch (e) { /* beim nächsten Start erneut */ } finally {
      retrying = false;
    }
    if (changed && location.hash !== '#/neu') route();
  }

  /* ---------- Foto: verkleinern und Metadaten lesen ---------- */
  function loadImage(url) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('Bild nicht lesbar'));
      img.src = url;
    });
  }
  function drawToBlob(img, maxDim, quality) {
    const w = img.naturalWidth, h = img.naturalHeight;
    const s = Math.min(1, maxDim / Math.max(w, h));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w * s));
    c.height = Math.max(1, Math.round(h * s));
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    return new Promise((resolve, reject) => c.toBlob((b) => (b ? resolve(b) : reject(new Error('toBlob'))), 'image/jpeg', quality));
  }
  async function readExif(file) {
    try { return FB.parseExif(await file.slice(0, 262144).arrayBuffer()); } catch (e) { return null; }
  }
  async function processPhoto(file) {
    const exif = await readExif(file);
    const url = URL.createObjectURL(file);
    try {
      const img = await loadImage(url);
      return { photo: await drawToBlob(img, 1600, 0.82), thumb: await drawToBlob(img, 480, 0.76), exif };
    } catch (e) {
      return { photo: file, thumb: file, exif };
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  /* ---------- Anzeige der Bedingungen ---------- */
  const metric = (k, v, sub, extra) =>
    '<div class="metric' + (extra ? ' has-rose' : '') + '"><div class="k">' + esc(k) + '</div><div class="v">' + esc(v) + '</div>' +
    (sub ? '<div class="sub">' + sub + '</div>' : '') + (extra || '') + '</div>';

  function tideTitle(ti) {
    if (ti.phase === 'stau') return ti.turn === 'HW' ? 'Hochwasser' : ti.turn === 'NW' ? 'Niedrigwasser' : 'Stauwasser';
    return { steigend: 'Auflaufendes Wasser', fallend: 'Ablaufendes Wasser', kaum: 'Kaum Tidenhub' }[ti.phase] || 'Tide';
  }
  function tideSub(ti, t) {
    const parts = [];
    if (ti.phase === 'kaum') {
      parts.push('Pegel schwankt nur um ' + Math.round(ti.rangeM * 100) + ' cm');
    } else {
      if (ti.phase === 'stau') parts.push('Das Wasser steht (Stauwasser)');
      else if (ti.prev) parts.push(Math.max(1, Math.round((t - ti.prev.t) / 36e5)) + ' h nach ' + (ti.prev.type === 'HW' ? 'Hochwasser' : 'Niedrigwasser'));
      if (ti.next) parts.push('nächstes ' + (ti.next.type === 'HW' ? 'Hochwasser' : 'Niedrigwasser') + ' ca. ' + FB.fmtTime(ti.next.t));
    }
    parts.push('Pegel ' + FB.signed(ti.levelM, 2) + ' m zum Mittelwasser');
    return parts.map(esc).join('<br>');
  }

  function conditionsHtml(cond, t, full) {
    const w = cond && cond.weather, ti = cond && cond.tide;
    const cells = [];
    if (w) {
      if (w.code != null) cells.push(metric('Wetter', FB.weatherText(w.code), FB.isNum(w.tempC) ? esc(FB.n1(w.tempC)) + ' °C' : ''));
      if (FB.isNum(w.windKmh)) {
        const sub = Math.round(w.windKmh) + ' km/h' + (FB.isNum(w.gustKmh) ? ', Böen ' + Math.round(w.gustKmh) + ' km/h' : '');
        cells.push(metric('Wind', FB.compass(w.windDir) + ' · ' + FB.beaufort(w.windKmh) + ' Bft', esc(sub), FB.isNum(w.windDir) ? FB.windRose(w.windDir) : ''));
      }
      if (FB.isNum(w.pressure)) {
        const tr = FB.trendInfo(w.pressureDelta3h);
        cells.push(metric('Luftdruck', Math.round(w.pressure) + ' hPa', tr ? esc(tr.arrow + ' ' + tr.label + ' (' + FB.signed(w.pressureDelta3h) + ' hPa in 3 h)') : ''));
      }
    }
    cells.push(ti
      ? metric('Tide', tideTitle(ti), tideSub(ti, t))
      : metric('Tide', 'Keine Daten', 'Für diesen Ort liefert das Modell keine Tide, zum Beispiel an Binnengewässern.'));
    let html = '<div class="metrics">' + cells.join('') + '</div>';
    if (full) {
      if (w && w.series.length > 1) html += '<figure class="chart">' + FB.sparkSvg(w.series, t, { title: 'Luftdruck, 24 h', unit: ' hPa', digits: 0, minSpan: 4 }) + '</figure>';
      if (ti && ti.phase !== 'kaum' && ti.series.length > 1) html += '<figure class="chart">' + FB.sparkSvg(ti.series, t, { title: 'Pegel, 26 h', unit: ' m', digits: 2, minSpan: 0.3 }) + '</figure>';
      html += '<p class="fine">Modelldaten von <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo.com</a> (CC BY 4.0), Tide im 8-km-Raster und nicht für die Navigation geeignet.</p>';
    }
    return html;
  }

  function chipsFor(c) {
    const out = [];
    const w = c.conditions && c.conditions.weather, ti = c.conditions && c.conditions.tide;
    if (w) {
      if (FB.isNum(w.windKmh)) out.push(FB.compass(w.windDir) + ' ' + FB.beaufort(w.windKmh) + ' Bft');
      if (FB.isNum(w.pressure)) {
        const tr = FB.trendInfo(w.pressureDelta3h);
        out.push(Math.round(w.pressure) + ' hPa' + (tr ? ' ' + tr.arrow : ''));
      }
    }
    if (ti && ti.phase !== 'kaum') out.push(FB.tideWord(ti.phase, ti.turn));
    if (!w && c.condStatus === 'pending') out.push('Daten folgen');
    return out;
  }

  /* ---------- Routing ---------- */
  let routeSeq = 0;
  function route() {
    freeUrls();
    stopTick();
    armedKey = null;
    editSessionId = null;
    const seq = ++routeSeq;
    const h = location.hash || '#/';
    window.scrollTo(0, 0);
    let m;
    if (h === '#/neu') return viewNew();
    if ((m = h.match(/^#\/fang\/(.+)$/))) return viewDetail(decodeURIComponent(m[1]), seq);
    return viewList(seq, h === '#/zeiten' ? 'zeiten' : 'faenge');
  }

  /* ---------- Liste ---------- */
  function cardHtml(c) {
    const thumb = c.thumb ? '<img class="thumb" alt="" src="' + objUrl(c.thumb) + '">' : '<div class="thumb ph">' + FISH_SVG + '</div>';
    const chips = chipsFor(c).map((t) => '<span class="chip">' + esc(t) + '</span>').join('');
    return '<a class="card" href="#/fang/' + encodeURIComponent(c.id) + '">' + thumb +
      '<div class="meta"><div class="top"><span class="species">' + esc(c.species) + '</span><span class="len">' + esc(FB.n1(c.lengthCm)) + '<small> cm</small></span></div>' +
      '<div class="when">' + esc(FB.fmtDateTime(c.caughtAt)) + '</div>' +
      (c.spot ? '<div class="spot">' + esc(c.spot) + '</div>' : '') +
      (chips ? '<div class="chips">' + chips + '</div>' : '') + '</div></a>';
  }

  /* ---------- Liste, Timer und Angelzeiten ---------- */
  let tickId = null;
  let editSessionId = null;
  let armedKey = null;
  let armedTimer = null;

  const listTab = () => (location.hash === '#/zeiten' ? 'zeiten' : 'faenge');
  const onList = () => !location.hash || location.hash === '#/' || location.hash === '#/zeiten';
  function refreshList() {
    if (!onList()) return;
    freeUrls();
    viewList(++routeSeq, listTab());
  }
  function arm(key) {
    armedKey = key;
    clearTimeout(armedTimer);
    armedTimer = setTimeout(() => { armedKey = null; refreshList(); }, 4000);
    refreshList();
  }
  function stopTick() {
    if (tickId) { clearInterval(tickId); tickId = null; }
  }
  const fangWort = (n) => n + (n === 1 ? ' Fang' : ' Fänge');

  function startTick(sess, catches) {
    stopTick();
    const clock = byId('tClock'), info = byId('tCatch'), warn = byId('tWarn');
    if (!clock) return;
    const update = () => {
      const now = Date.now();
      clock.textContent = FB.fmtClock(now - sess.startedAt);
      const n = FB.countCatches(catches, sess.startedAt, now);
      info.textContent = n ? fangWort(n) + ' in dieser Angelzeit' : 'Noch kein Fang in dieser Angelzeit';
      warn.hidden = now - sess.startedAt < 16 * 36e5;
    };
    update();
    tickId = setInterval(update, 1000);
  }

  function timerHtml(running) {
    if (running) {
      const discard = armedKey === 'discard';
      return '<section class="timer running" aria-label="Angelzeit läuft">' +
        '<div class="t-top"><span class="t-label">Angelzeit läuft</span><span>seit ' + esc(FB.fmtTime(running.startedAt)) + ' Uhr</span></div>' +
        '<div id="tClock" class="t-clock" role="timer">0:00:00</div>' +
        '<div id="tCatch" class="t-catch"></div>' +
        '<p id="tWarn" class="t-warn" hidden>Der Timer läuft schon sehr lange. Falls du das Stoppen vergessen hast, beende ihn und passe die Zeiten danach unter „Angelzeiten“ an.</p>' +
        '<div class="row two"><button type="button" class="btn" data-action="timer-stop">Angeln beenden</button>' +
        '<button type="button" class="btn ghost' + (discard ? ' armed' : '') + '" data-action="timer-discard">' + (discard ? 'Wirklich verwerfen?' : 'Verwerfen') + '</button></div></section>';
    }
    return '<section class="timer"><div class="t-top"><span class="t-label">Angelzeit</span></div>' +
      '<p class="t-help">Starte den Timer, wenn du ans Wasser kommst. Ohne eingetragenen Fang zählt die Zeit als Schneidertag.</p>' +
      '<button type="button" class="btn primary wide" data-action="timer-start">Angeln starten</button></section>';
  }

  const sameDay = (a, b) => new Date(a).toDateString() === new Date(b).toDateString();

  function sessionRowHtml(s, catches) {
    if (editSessionId === s.id) {
      return '<div class="srow"><label for="sStart">Start</label><input id="sStart" type="datetime-local" value="' + FB.toLocalInput(s.startedAt) + '">' +
        '<label for="sEnd">Ende</label><input id="sEnd" type="datetime-local" value="' + FB.toLocalInput(s.endedAt) + '">' +
        '<p id="formErr" class="err" role="alert" hidden></p>' +
        '<div class="row two"><button type="button" class="btn primary small" data-action="sess-save" data-id="' + esc(s.id) + '">Speichern</button>' +
        '<button type="button" class="btn ghost small" data-action="sess-cancel">Abbrechen</button></div></div>';
    }
    const n = FB.countCatches(catches, s.startedAt, s.endedAt);
    const badge = n ? '<span class="chip ok">' + fangWort(n) + '</span>' : '<span class="chip blank">Schneidertag</span>';
    const range = FB.fmtTime(s.startedAt) + ' bis ' + FB.fmtTime(s.endedAt) + (sameDay(s.startedAt, s.endedAt) ? '' : ' (Folgetag)') + ' · ' + FB.fmtDuration(s.endedAt - s.startedAt);
    const del = armedKey === 'del:' + s.id;
    return '<div class="srow"><div class="s-head"><div><div class="s-date">' + esc(FB.fmtDate(s.startedAt)) + '</div><div class="sub">' + esc(range) + '</div></div>' + badge + '</div>' +
      '<div class="row two"><button type="button" class="btn ghost small" data-action="sess-edit" data-id="' + esc(s.id) + '">Zeiten ändern</button>' +
      '<button type="button" class="btn danger small' + (del ? ' armed' : '') + '" data-action="sess-del" data-id="' + esc(s.id) + '">' + (del ? 'Wirklich löschen?' : 'Löschen') + '</button></div></div>';
  }

  async function viewList(seq, tab) {
    let list, sessions;
    try {
      [list, sessions] = await Promise.all([dbAll(), sessAll()]);
    } catch (e) {
      $app.innerHTML = '<main class="wrap"><h1>Fangbuch</h1><p class="err">Der Speicher dieses Browsers ist nicht verfügbar. Private Tabs erlauben ihn oft nicht.</p></main>';
      return;
    }
    if (seq !== routeSeq) return;
    list.sort((a, b) => b.caughtAt - a.caughtAt);
    const running = sessions.find((s) => !s.endedAt) || null;
    const done = sessions.filter((s) => s.endedAt).sort((a, b) => b.startedAt - a.startedAt);
    const stats = FB.sessionStats(done, list);

    let summary, body;
    if (tab === 'zeiten') {
      summary = done.length
        ? stats.count + (stats.count === 1 ? ' Angelzeit' : ' Angelzeiten') + ' · ' + stats.blanks + (stats.blanks === 1 ? ' Schneidertag' : ' Schneidertage') + ' · ' + FB.fmtDuration(stats.totalMs) + ' am Wasser'
        : 'Noch keine Angelzeiten';
      body = done.length
        ? '<div class="srows">' + done.map((s) => sessionRowHtml(s, list)).join('') + '</div>' +
          '<p class="fine">Ein Schneidertag ist eine Angelzeit ohne Fang. Als Fang zählt jeder Eintrag, dessen Fangzeit in die Angelzeit fällt.</p>'
        : '<div class="empty"><h2>Noch keine Angelzeit gespeichert</h2><p>Starte oben den Timer, wenn du ans Wasser gehst, und beende ihn, wenn du fertig bist.</p></div>';
    } else {
      const biggest = list.reduce((m, c) => (!m || c.lengthCm > m.lengthCm ? c : m), null);
      summary = list.length ? fangWort(list.length) + ' · Größter: ' + esc(biggest.species) + ' ' + esc(FB.n1(biggest.lengthCm)) + ' cm' : 'Noch keine Fänge';
      body = list.length
        ? '<div class="cards">' + list.map(cardHtml).join('') + '</div><div class="foot"><button type="button" class="link" data-action="export">Als CSV exportieren</button>' +
          '<p class="fine">Die Fänge liegen nur auf diesem Gerät. Exportiere sie regelmäßig als Sicherung. Wetterdaten: <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo.com</a></p></div>'
        : '<div class="empty"><div class="empty-fish">' + FISH_SVG + '</div><h2>Dein erster Fang wartet</h2><p>Tippe unten auf „Fang eintragen“. Foto, Länge und Fischart gibst du ein, Standort, Wetter, Wind, Luftdruck und Tide kommen automatisch dazu.</p></div>';
    }

    $app.innerHTML =
      '<header class="bar"><div class="bar-in"><div><h1>Fangbuch</h1><p class="sub">' + summary + '</p></div></div></header>' +
      '<main class="wrap">' + timerHtml(running) +
      '<nav class="tabs" aria-label="Ansicht"><a class="tab" href="#/"' + (tab === 'faenge' ? ' aria-current="page"' : '') + '>Fänge</a>' +
      '<a class="tab" href="#/zeiten"' + (tab === 'zeiten' ? ' aria-current="page"' : '') + '>Angelzeiten</a></nav>' +
      body + '</main><a class="fab" href="#/neu">+ Fang eintragen</a>';
    if (running) startTick(running, list); else stopTick();
  }

  /* ---------- Neuer Fang ---------- */
  let draft = null;
  function resetDraft() {
    draft = {
      seq: routeSeq, photo: null, thumb: null, exif: null,
      species: '', length: '', spot: '', notes: '',
      whenMs: Date.now(), whenEdited: false,
      gps: null, gpsState: 'idle', manual: null, choice: 'auto', loc: null,
      cond: null, condState: 'idle', condKey: null, condSeq: 0, saving: false
    };
  }
  const alive = (d) => draft === d && routeSeq === d.seq;
  const condKey = (loc, t) => loc.lat.toFixed(3) + ',' + loc.lon.toFixed(3) + ',' + Math.round(t / 36e5);

  function showErr(msg) {
    const e = byId('formErr');
    if (!e) return;
    e.textContent = msg;
    e.hidden = !msg;
  }

  function renderSpeciesChips(list) {
    const box = byId('speciesChips');
    if (!box) return;
    const counts = {};
    list.forEach((c) => { counts[c.species] = (counts[c.species] || 0) + 1; });
    const top = Object.keys(counts).sort((a, b) => counts[b] - counts[a]).slice(0, 5);
    box.innerHTML = (top.length ? top : DEFAULT_CHIPS)
      .map((s) => '<button type="button" class="chip-btn" data-action="species-chip" data-v="' + esc(s) + '">' + esc(s) + '</button>').join('');
  }

  function viewNew() {
    resetDraft();
    const d = draft;
    $app.innerHTML =
      '<header class="bar"><div class="bar-in"><a class="back" href="#/">‹ Zurück</a><h1>Neuer Fang</h1></div></header>' +
      '<main class="wrap"><form id="catchForm" novalidate>' +
      '<section class="block"><div id="photoBox" class="photo-box"><span>Noch kein Foto</span></div>' +
      '<div class="row two"><button type="button" class="btn" data-action="pick-camera">Foto aufnehmen</button><button type="button" class="btn ghost" data-action="pick-gallery">Aus Galerie</button></div>' +
      '<input id="fileCam" type="file" accept="image/*" capture="environment" hidden><input id="fileGal" type="file" accept="image/*" hidden></section>' +
      '<section class="block"><label for="species">Fischart</label>' +
      '<input id="species" list="speciesList" autocomplete="off" autocapitalize="words" placeholder="z. B. Hecht">' +
      '<datalist id="speciesList">' + FB.SPECIES.map((s) => '<option value="' + esc(s) + '"></option>').join('') + '</datalist>' +
      '<div id="speciesChips" class="chips-row"></div>' +
      '<label for="length">Länge in cm</label><input id="length" type="number" inputmode="decimal" min="1" max="400" step="0.5" placeholder="z. B. 72">' +
      '<label for="spot">Gewässer oder Angelplatz <span class="opt">optional</span></label><input id="spot" autocomplete="off" placeholder="z. B. Schlei bei Kappeln"></section>' +
      '<section class="block"><label for="when">Fangzeit</label><input id="when" type="datetime-local" value="' + FB.toLocalInput(d.whenMs) + '">' +
      '<p id="whenHint" class="hint" hidden>Zeit aus den Foto-Daten übernommen.</p></section>' +
      '<section class="block"><div class="k">Standort</div><div id="locDyn" aria-live="polite"></div>' +
      '<details class="manual"><summary>Standort manuell eingeben</summary><div class="row inline">' +
      '<input id="manualLoc" inputmode="decimal" placeholder="54.3215, 10.1342" aria-label="Breite und Länge"><button type="button" class="btn ghost" data-action="apply-manual">Übernehmen</button></div></details></section>' +
      '<section class="block"><div class="k">Bedingungen</div><div id="condBox" aria-live="polite"></div></section>' +
      '<section class="block"><label for="notes">Notizen <span class="opt">optional</span></label><textarea id="notes" rows="2" placeholder="Köder, Technik, Tiefe …"></textarea></section>' +
      '<p id="formErr" class="err" role="alert" hidden></p>' +
      '<button id="saveBtn" class="btn primary wide" type="submit">Fang speichern</button></form></main>';

    byId('species').addEventListener('input', (e) => { d.species = e.target.value; });
    byId('length').addEventListener('input', (e) => { d.length = e.target.value; });
    byId('spot').addEventListener('input', (e) => { d.spot = e.target.value; });
    byId('notes').addEventListener('input', (e) => { d.notes = e.target.value; });
    byId('when').addEventListener('change', (e) => {
      const t = FB.fromLocalInput(e.target.value);
      if (!t) return;
      d.whenMs = t;
      d.whenEdited = true;
      byId('whenHint').hidden = true;
      scheduleConditions();
    });
    const onPick = (e) => { const f = e.target.files && e.target.files[0]; e.target.value = ''; onFile(f); };
    byId('fileCam').addEventListener('change', onPick);
    byId('fileGal').addEventListener('change', onPick);

    dbAll().then(renderSpeciesChips).catch(() => renderSpeciesChips([]));
    updateLocUI();
    updateCondUI();
    startGps();
  }

  async function onFile(file) {
    const d = draft;
    if (!file || !d) return;
    const box = byId('photoBox');
    if (box) box.innerHTML = '<span>Foto wird verarbeitet …</span>';
    const r = await processPhoto(file);
    if (!alive(d)) return;
    d.photo = r.photo;
    d.thumb = r.thumb;
    d.exif = r.exif;
    byId('photoBox').innerHTML = '<img alt="Vorschau des Fangfotos" src="' + objUrl(r.photo) + '">';
    const ex = r.exif;
    if (ex && ex.time && Math.abs(Date.now() - ex.time) > 30 * 60000 && !d.whenEdited) {
      d.whenMs = ex.time;
      byId('when').value = FB.toLocalInput(ex.time);
      byId('whenHint').hidden = false;
    }
    chooseLocation();
  }

  function startGps() {
    const d = draft;
    if (!navigator.geolocation) { d.gpsState = 'error'; chooseLocation(); return; }
    d.gpsState = 'searching';
    updateLocUI();
    navigator.geolocation.getCurrentPosition((pos) => {
      if (!alive(d)) return;
      d.gps = { lat: pos.coords.latitude, lon: pos.coords.longitude, acc: pos.coords.accuracy };
      d.gpsState = 'ok';
      chooseLocation();
    }, (err) => {
      if (!alive(d)) return;
      d.gpsState = err && err.code === 1 ? 'denied' : 'error';
      chooseLocation();
    }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 30000 });
  }

  /* Standard: Standort beim Eintragen. Ein altes Foto mit GPS-Daten gewinnt, weil es den echten Platz kennt. */
  function chooseLocation() {
    const d = draft;
    const ex = d.exif && d.exif.lat != null ? { lat: d.exif.lat, lon: d.exif.lon } : null;
    const exOld = d.exif && d.exif.time && Math.abs(Date.now() - d.exif.time) > 30 * 60000;
    let pick = d.choice;
    if (pick === 'auto') {
      if (ex && (exOld || !d.gps)) pick = 'photo';
      else if (d.gps) pick = 'gps';
      else if (d.manual) pick = 'manual';
      else pick = null;
    }
    let loc = null;
    if (pick === 'gps' && d.gps) loc = { lat: d.gps.lat, lon: d.gps.lon, acc: d.gps.acc, source: 'gps' };
    else if (pick === 'photo' && ex) loc = { lat: ex.lat, lon: ex.lon, acc: null, source: 'photo' };
    else if (pick === 'manual' && d.manual) loc = { lat: d.manual.lat, lon: d.manual.lon, acc: null, source: 'manual' };
    d.loc = loc;
    updateLocUI();
    scheduleConditions();
  }

  function updateLocUI() {
    const box = byId('locDyn');
    const d = draft;
    if (!box || !d) return;
    const has = { gps: !!d.gps, photo: !!(d.exif && d.exif.lat != null), manual: !!d.manual };
    const names = { gps: 'Mein Standort', photo: 'Aus dem Foto', manual: 'Manuell' };
    let status;
    if (d.loc) {
      status = '<strong>' + esc(FB.fmtCoords(d.loc.lat, d.loc.lon)) + '</strong>' + (d.loc.acc ? ' <span class="muted">± ' + Math.round(d.loc.acc) + ' m</span>' : '');
    } else if (d.gpsState === 'searching') {
      status = 'Standort wird bestimmt …';
    } else if (d.gpsState === 'denied') {
      status = 'Der Standortzugriff ist blockiert. Erlaube ihn in den Browser-Einstellungen oder gib den Ort unten ein.';
    } else {
      status = 'Kein Standort gefunden. Gib ihn unten manuell ein.';
    }
    const chips = Object.keys(names).filter((k) => has[k]).map((k) =>
      '<button type="button" class="chip-btn" data-action="loc-' + k + '" aria-pressed="' + (!!d.loc && d.loc.source === k) + '">' + names[k] + '</button>').join('');
    const retry = d.gpsState === 'searching' ? '' : '<button type="button" class="chip-btn" data-action="gps-retry">Neu bestimmen</button>';
    box.innerHTML = '<p class="loc-status">' + status + '</p><div class="chips-row">' + chips + retry + '</div>';
  }

  let condTimer = null;
  function scheduleConditions() {
    clearTimeout(condTimer);
    const d = draft;
    if (!d || !byId('condBox')) return;
    if (!d.loc) { d.cond = null; d.condState = 'idle'; d.condKey = null; updateCondUI(); return; }
    const key = condKey(d.loc, d.whenMs);
    if (key === d.condKey && d.condState === 'ok') return;
    d.condState = 'loading';
    updateCondUI();
    condTimer = setTimeout(() => runConditions(d, key), 500);
  }

  async function runConditions(d, key) {
    if (!alive(d)) return;
    const seq = ++d.condSeq;
    if (!navigator.onLine) { d.condState = 'offline'; updateCondUI(); return; }
    const r = await getConditions(d.loc.lat, d.loc.lon, d.whenMs);
    if (!alive(d) || seq !== d.condSeq) return;
    if (r.status === 'pending') { d.condState = 'offline'; d.cond = null; d.condKey = null; }
    else { d.cond = r.conditions; d.condState = r.status; d.condKey = key; }
    updateCondUI();
  }

  function updateCondUI() {
    const box = byId('condBox');
    const d = draft;
    if (!box || !d) return;
    const msg = {
      idle: 'Sobald der Standort feststeht, laden Wetter, Wind, Luftdruck und Tide.',
      loading: 'Wetter, Wind, Luftdruck und Tide werden geladen …',
      offline: 'Gerade kein Netz. Die Bedingungen werden nach dem Speichern automatisch nachgeladen, sobald du wieder online bist.',
      none: 'Für diesen Ort und Zeitpunkt liegen keine Daten vor.'
    };
    box.innerHTML = d.condState === 'ok' ? conditionsHtml(d.cond, d.whenMs, false) : '<p class="hint">' + msg[d.condState] + '</p>';
  }

  async function saveDraft() {
    const d = draft;
    if (!d || d.saving) return;
    const species = d.species.trim();
    const len = parseFloat(String(d.length).replace(',', '.'));
    if (!species) { showErr('Bitte die Fischart eintragen.'); byId('species').focus(); return; }
    if (!isFinite(len) || len <= 0 || len > 400) { showErr('Bitte die Länge in cm eintragen.'); byId('length').focus(); return; }
    showErr('');
    d.saving = true;
    const btn = byId('saveBtn');
    btn.disabled = true;
    btn.textContent = 'Speichern …';

    let cond = null, status = 'none';
    if (d.loc) {
      if (d.condState === 'ok' && d.condKey === condKey(d.loc, d.whenMs)) { cond = d.cond; status = 'ok'; }
      else if (navigator.onLine) { const r = await getConditions(d.loc.lat, d.loc.lon, d.whenMs); cond = r.conditions; status = r.status; }
      else status = 'pending';
    }
    const rec = {
      id: newId(), createdAt: Date.now(), caughtAt: d.whenMs,
      species, lengthCm: Math.round(len * 10) / 10, spot: d.spot.trim(), notes: d.notes.trim(),
      lat: d.loc ? d.loc.lat : null, lon: d.loc ? d.loc.lon : null,
      locAccuracy: d.loc ? d.loc.acc : null, locSource: d.loc ? d.loc.source : null,
      photo: d.photo, thumb: d.thumb, conditions: cond, condStatus: status, tries: 0
    };
    try {
      await dbPut(rec);
    } catch (e) {
      d.saving = false;
      btn.disabled = false;
      btn.textContent = 'Fang speichern';
      showErr('Speichern ist fehlgeschlagen. Möglicherweise ist der Gerätespeicher voll.');
      return;
    }
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    location.hash = '#/fang/' + encodeURIComponent(rec.id);
  }

  /* ---------- Detail ---------- */
  let current = null;
  let editing = false;
  let deleteArmed = false;
  let deleteTimer = null;

  const SOURCE_TEXT = { gps: 'GPS beim Eintragen', photo: 'aus den Foto-Daten', manual: 'manuell eingegeben' };

  function detailHtml(c) {
    const hero = c.photo ? '<div class="hero"><img alt="Foto: ' + esc(c.species) + '" src="' + objUrl(c.photo) + '"></div>' : '<div class="hero ph">' + FISH_SVG + '</div>';
    const head = editing
      ? '<section class="block"><label for="eSpecies">Fischart</label><input id="eSpecies" list="speciesList" autocomplete="off" value="' + esc(c.species) + '">' +
        '<datalist id="speciesList">' + FB.SPECIES.map((s) => '<option value="' + esc(s) + '"></option>').join('') + '</datalist>' +
        '<label for="eLength">Länge in cm</label><input id="eLength" type="number" inputmode="decimal" step="0.5" value="' + esc(c.lengthCm) + '">' +
        '<label for="eSpot">Gewässer oder Angelplatz</label><input id="eSpot" autocomplete="off" value="' + esc(c.spot) + '">' +
        '<label for="eNotes">Notizen</label><textarea id="eNotes" rows="3">' + esc(c.notes) + '</textarea>' +
        '<p id="formErr" class="err" role="alert" hidden></p>' +
        '<div class="row two"><button type="button" class="btn primary" data-action="edit-save">Speichern</button><button type="button" class="btn ghost" data-action="edit-cancel">Abbrechen</button></div></section>'
      : '<div class="title-row"><div><h1>' + esc(c.species) + '</h1><p class="when">' + esc(FB.fmtDateTime(c.caughtAt)) + '</p></div>' +
        '<div class="len big">' + esc(FB.n1(c.lengthCm)) + '<small> cm</small></div></div>';

    let place;
    if (c.lat != null) {
      place = '<section class="block"><div class="k">Fangplatz</div>' + (c.spot && !editing ? '<div class="v">' + esc(c.spot) + '</div>' : '') +
        '<div class="sub">' + esc(FB.fmtCoords(c.lat, c.lon)) + ' · ' + esc(SOURCE_TEXT[c.locSource] || '') + '</div>' +
        '<a class="btn ghost" href="' + FB.mapsUrl(c.lat, c.lon) + '" target="_blank" rel="noopener">In Karten öffnen</a></section>';
    } else {
      place = '<section class="block"><div class="k">Fangplatz</div><div class="sub">Kein Standort gespeichert.' + (c.spot && !editing ? ' ' + esc(c.spot) : '') + '</div></section>';
    }

    let cond;
    if (c.condStatus === 'ok') cond = conditionsHtml(c.conditions, c.caughtAt, true);
    else if (c.condStatus === 'pending') cond = '<p class="hint">Die Bedingungen werden geladen, sobald du wieder Netz hast.</p><button type="button" class="btn ghost" data-action="refetch">Jetzt versuchen</button>';
    else if (c.lat == null) cond = '<p class="hint">Ohne Standort gibt es keine Wetterdaten.</p>';
    else cond = '<p class="hint">Für diesen Ort und Zeitpunkt liegen keine Daten vor.</p><button type="button" class="btn ghost" data-action="refetch">Erneut laden</button>';

    return '<header class="bar"><div class="bar-in"><a class="back" href="#/">‹ Fänge</a></div></header><main class="wrap">' + hero + head + place +
      '<section class="block"><h2>Bedingungen beim Fang</h2>' + cond + '</section>' +
      (c.notes && !editing ? '<section class="block"><div class="k">Notizen</div><p class="notes">' + esc(c.notes) + '</p></section>' : '') +
      (editing ? '' : '<div class="row two actions"><button type="button" class="btn ghost" data-action="edit">Bearbeiten</button>' +
        '<button type="button" class="btn danger' + (deleteArmed ? ' armed' : '') + '" data-action="delete">' + (deleteArmed ? 'Wirklich löschen?' : 'Löschen') + '</button></div>') +
      '</main>';
  }

  async function viewDetail(id, seq) {
    let c;
    try { c = await dbGet(id); } catch (e) { c = null; }
    if (seq !== routeSeq) return;
    editing = false;
    deleteArmed = false;
    if (!c) {
      $app.innerHTML = '<header class="bar"><div class="bar-in"><a class="back" href="#/">‹ Fänge</a></div></header><main class="wrap"><p class="hint">Dieser Fang wurde nicht gefunden.</p></main>';
      return;
    }
    current = c;
    renderDetail();
  }

  function renderDetail() {
    freeUrls();
    $app.innerHTML = detailHtml(current);
  }

  async function saveEdit() {
    const species = byId('eSpecies').value.trim();
    const len = parseFloat(byId('eLength').value.replace(',', '.'));
    if (!species || !isFinite(len) || len <= 0 || len > 400) { showErr('Bitte Fischart und Länge in cm angeben.'); return; }
    current.species = species;
    current.lengthCm = Math.round(len * 10) / 10;
    current.spot = byId('eSpot').value.trim();
    current.notes = byId('eNotes').value.trim();
    try { await dbPut(current); } catch (e) { showErr('Speichern ist fehlgeschlagen.'); return; }
    editing = false;
    renderDetail();
    toast('Änderungen gespeichert');
  }

  async function refetch() {
    if (!current || current.lat == null) return;
    if (!navigator.onLine) { toast('Gerade kein Netz.'); return; }
    toast('Bedingungen werden geladen …');
    const r = await getConditions(current.lat, current.lon, current.caughtAt);
    if (r.status === 'pending') { toast('Der Abruf hat nicht geklappt. Bitte später erneut versuchen.'); return; }
    current.conditions = r.conditions;
    current.condStatus = r.status;
    await dbPut(current);
    renderDetail();
  }

  async function exportCsv() {
    const list = (await dbAll()).sort((a, b) => b.caughtAt - a.caughtAt);
    const blob = new Blob(['﻿' + FB.buildCsv(list)], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'fangbuch.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }

  /* ---------- Klicks und Formulare ---------- */
  const actions = {
    'pick-camera': () => byId('fileCam').click(),
    'pick-gallery': () => byId('fileGal').click(),
    'species-chip': (el) => { const v = el.getAttribute('data-v'); byId('species').value = v; draft.species = v; },
    'loc-gps': () => { draft.choice = 'gps'; chooseLocation(); },
    'loc-photo': () => { draft.choice = 'photo'; chooseLocation(); },
    'loc-manual': () => { draft.choice = 'manual'; chooseLocation(); },
    'gps-retry': () => { draft.choice = 'auto'; startGps(); },
    'apply-manual': () => {
      const p = FB.parseLatLon(byId('manualLoc').value);
      if (!p) { showErr('Koordinaten bitte so eingeben: 54.3215, 10.1342'); return; }
      showErr('');
      draft.manual = p;
      draft.choice = 'manual';
      chooseLocation();
    },
    'timer-start': async () => {
      try {
        const all = await sessAll();
        if (!all.some((x) => !x.endedAt)) await sessPut({ id: newId(), startedAt: Date.now(), endedAt: null });
      } catch (e) { toast('Der Timer konnte nicht gestartet werden.'); return; }
      refreshList();
    },
    'timer-stop': async () => {
      try {
        const run1 = (await sessAll()).find((x) => !x.endedAt);
        if (run1) {
          run1.endedAt = Date.now();
          await sessPut(run1);
          const n = FB.countCatches(await dbAll(), run1.startedAt, run1.endedAt);
          toast('Angelzeit ' + FB.fmtDuration(run1.endedAt - run1.startedAt) + ' gespeichert: ' + (n ? fangWort(n) : 'Schneidertag'));
        }
      } catch (e) { toast('Speichern ist fehlgeschlagen.'); }
      refreshList();
    },
    'timer-discard': async () => {
      if (armedKey !== 'discard') { arm('discard'); return; }
      clearTimeout(armedTimer);
      armedKey = null;
      try {
        const run1 = (await sessAll()).find((x) => !x.endedAt);
        if (run1) await sessDel(run1.id);
      } catch (e) { toast('Verwerfen ist fehlgeschlagen.'); }
      refreshList();
    },
    'sess-edit': (el) => { editSessionId = el.getAttribute('data-id'); refreshList(); },
    'sess-cancel': () => { editSessionId = null; refreshList(); },
    'sess-save': async (el) => {
      const a = FB.fromLocalInput(byId('sStart').value), b = FB.fromLocalInput(byId('sEnd').value);
      if (!a || !b || b <= a) { showErr('Das Ende muss nach dem Start liegen.'); return; }
      if (b > Date.now()) { showErr('Das Ende liegt in der Zukunft.'); return; }
      try {
        const rec = await sessGet(el.getAttribute('data-id'));
        if (rec) { rec.startedAt = a; rec.endedAt = b; await sessPut(rec); }
      } catch (e) { showErr('Speichern ist fehlgeschlagen.'); return; }
      editSessionId = null;
      refreshList();
      toast('Angelzeit angepasst');
    },
    'sess-del': async (el) => {
      const id = el.getAttribute('data-id');
      if (armedKey !== 'del:' + id) { arm('del:' + id); return; }
      clearTimeout(armedTimer);
      armedKey = null;
      try { await sessDel(id); } catch (e) { toast('Löschen ist fehlgeschlagen.'); }
      refreshList();
      toast('Angelzeit gelöscht');
    },
    'export': () => exportCsv(),
    'edit': () => { editing = true; renderDetail(); },
    'edit-cancel': () => { editing = false; renderDetail(); },
    'edit-save': () => saveEdit(),
    'refetch': () => refetch(),
    'delete': async () => {
      if (!deleteArmed) {
        deleteArmed = true;
        renderDetail();
        clearTimeout(deleteTimer);
        deleteTimer = setTimeout(() => { deleteArmed = false; if (current && !editing && location.hash.indexOf('#/fang/') === 0) renderDetail(); }, 4000);
        return;
      }
      clearTimeout(deleteTimer);
      try { await dbDel(current.id); } catch (e) { toast('Löschen ist fehlgeschlagen.'); return; }
      toast('Fang gelöscht');
      location.hash = '#/';
    }
  };

  $app.addEventListener('click', (e) => {
    const el = e.target.closest('[data-action]');
    if (!el) return;
    const fn = actions[el.getAttribute('data-action')];
    if (fn) { e.preventDefault(); fn(el); }
  });
  $app.addEventListener('submit', (e) => {
    if (e.target.id === 'catchForm') { e.preventDefault(); saveDraft(); }
  });

  window.addEventListener('hashchange', route);
  window.addEventListener('online', retryPending);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) retryPending(); });

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(() => {}); });
  }

  route();
  retryPending();
})();
