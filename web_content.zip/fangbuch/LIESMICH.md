# Fangbuch

Angelfänge mit Foto, Fischart, Länge, Standort, Wetter, Wind, Luftdruck und Tide festhalten.
Die App ist eine installierbare Web-App und braucht keinen App-Store.

## Online stellen (einmalig, nötig für Standort und Wetterdaten)

Die Dateien müssen über https erreichbar sein. Der einfachste Weg:

1. Diesen Ordner entpacken.
2. Auf https://app.netlify.com/drop den ganzen Ordner "fangbuch" in das Feld ziehen.
3. Netlify zeigt einen Link wie `https://irgendwas.netlify.app`. Diesen Link auf dem Handy öffnen.

Alternativen: GitHub Pages oder Cloudflare Pages (alle Dateien unverändert hochladen, `index.html` muss im Hauptordner liegen).

## Icon aufs Handy legen

- iPhone: Link in Safari öffnen, Teilen-Symbol, "Zum Home-Bildschirm".
- Android: Link in Chrome öffnen, Menü (drei Punkte), "App installieren" oder "Zum Startbildschirm hinzufügen".

iPhone: Die App vom Home-Bildschirm hat einen eigenen Speicher, getrennt von Safari. Lege das Icon an, bevor du Fänge einträgst, und nutze danach nur noch das Icon.

## Angelzeit-Timer und Schneidertage

Oben auf der Startseite startest du mit "Angeln starten" den Timer, wenn du ans Wasser gehst, und beendest ihn mit "Angeln beenden". Der Timer läuft auch weiter, wenn du die App schließt.

- Trägst du in dieser Zeit mindestens einen Fang ein, zählt die Angelzeit mit der Fangzahl. Sonst wird sie als Schneidertag gespeichert.
- Als Fang zählt jeder Eintrag, dessen Fangzeit in die Angelzeit fällt. Trägst du einen Fang nachträglich ein, passt sich die Wertung automatisch an.
- Im Tab "Angelzeiten" siehst du alle Zeiten mit Dauer und Wertung. Dort kannst du Start und Ende ändern (zum Beispiel, wenn du das Stoppen vergessen hast) oder eine Zeit löschen.
- "Verwerfen" bricht einen versehentlich gestarteten Timer ab, ohne etwas zu speichern.

## Wie die Daten entstehen

- Standort: GPS beim Eintragen. Hat das Foto GPS-Daten und wurde es früher aufgenommen, nutzt die App Ort und Zeit aus dem Foto. Beides lässt sich umschalten oder von Hand eingeben.
- Wetter, Wind (Richtung, km/h, Beaufort, Böen), Luftdruck mit 3-Stunden-Tendenz und Tide kommen von Open-Meteo für Ort und Fangzeit.
- Ohne Netz speichert die App den Fang trotzdem und lädt die Bedingungen nach, sobald wieder Verbindung besteht.
- Die Tide stammt aus einem Modell im 8-km-Raster. Sie ist an Küsten brauchbar, an Binnengewässern nicht verfügbar und ersetzt keine amtliche Tidentabelle.

## Sicherung

Fänge und Angelzeiten liegen nur auf dem Gerät. In der Fangliste unten gibt es "Als CSV exportieren" (Excel-tauglich, ohne Fotos).

## Quellen

Wetterdaten von Open-Meteo.com, Lizenz CC BY 4.0: https://open-meteo.com/
