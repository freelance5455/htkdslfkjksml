/* Fangbuch: reine Hilfsfunktionen ohne DOM (auch in Node testbar) */
(function (root) {
  'use strict';

  var WMO = {
    0: 'Klar', 1: 'Überwiegend klar', 2: 'Teils bewölkt', 3: 'Bedeckt',
    45: 'Nebel', 48: 'Reifnebel',
    51: 'Leichter Nieselregen', 53: 'Nieselregen', 55: 'Starker Nieselregen',
    56: 'Gefrierender Nieselregen', 57: 'Starker gefrierender Nieselregen',
    61: 'Leichter Regen', 63: 'Regen', 65: 'Starker Regen',
    66: 'Gefrierender Regen', 67: 'Starker gefrierender Regen',
    71: 'Leichter Schneefall', 73: 'Schneefall', 75: 'Starker Schneefall', 77: 'Schneegriesel',
    80: 'Leichte Regenschauer', 81: 'Regenschauer', 82: 'Heftige Regenschauer',
    85: 'Leichte Schneeschauer', 86: 'Schneeschauer',
    95: 'Gewitter', 96: 'Gewitter mit Hagel', 97: 'Starkes Gewitter', 99: 'Gewitter mit starkem Hagel'
  };

  var SPECIES = ['Aal', 'Aland', 'Äsche', 'Barsch', 'Brasse', 'Dorsch', 'Flunder', 'Forelle', 'Hecht',
    'Hering', 'Hornhecht', 'Karpfen', 'Lachs', 'Makrele', 'Meerforelle', 'Plattfisch',
    'Regenbogenforelle', 'Rotauge', 'Rotfeder', 'Schleie', 'Scholle', 'Wels', 'Wolfsbarsch', 'Zander'];

  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function pad(n) { return String(n).padStart(2, '0'); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function weatherText(code) {
    return Object.prototype.hasOwnProperty.call(WMO, code) ? WMO[code] : 'Wetter unbekannt';
  }

  /* Beaufort aus km/h: Obergrenzen der Stärken 0 bis 11 */
  var BFT_LIMITS = [1, 6, 12, 20, 29, 39, 50, 62, 75, 89, 103, 118];
  function beaufort(kmh) {
    for (var i = 0; i < BFT_LIMITS.length; i++) if (kmh < BFT_LIMITS[i]) return i;
    return 12;
  }

  /* Windrichtung = Richtung, aus der der Wind kommt; deutsche Kürzel (O = Ost) */
  var COMPASS = ['N', 'NNO', 'NO', 'ONO', 'O', 'OSO', 'SO', 'SSO', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  function compass(deg) {
    if (!isNum(deg)) return '–';
    return COMPASS[Math.round((((deg % 360) + 360) % 360) / 22.5) % 16];
  }

  /* ---------- Zeit und Zahlen ---------- */
  function ymdUTC(ms) {
    var d = new Date(ms);
    return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate());
  }
  function toLocalInput(ms) {
    var d = new Date(ms);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  function fromLocalInput(s) {
    var t = new Date(s).getTime();
    return isFinite(t) ? t : null;
  }

  var nf1 = new Intl.NumberFormat('de-DE', { maximumFractionDigits: 1 });
  var nf2 = new Intl.NumberFormat('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  var dfDate = new Intl.DateTimeFormat('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  var dfTime = new Intl.DateTimeFormat('de-DE', { hour: '2-digit', minute: '2-digit' });

  function n1(v) { return nf1.format(v); }
  function signed(v, digits) {
    return (v < 0 ? '−' : '+') + (digits === 2 ? nf2 : nf1).format(Math.abs(v));
  }
  function fmtDate(ms) { return dfDate.format(ms); }
  function fmtTime(ms) { return dfTime.format(ms); }
  function fmtDateTime(ms) { return fmtDate(ms) + ' · ' + fmtTime(ms); }

  function fmtCoords(lat, lon) {
    return Math.abs(lat).toFixed(4) + '° ' + (lat >= 0 ? 'N' : 'S') + ', ' +
      Math.abs(lon).toFixed(4) + '° ' + (lon >= 0 ? 'O' : 'W');
  }
  function mapsUrl(lat, lon) {
    return 'https://www.google.com/maps/search/?api=1&query=' + lat.toFixed(5) + ',' + lon.toFixed(5);
  }

  /* "54.3215, 10.1342" oder "54,3215 10,1342" */
  function parseLatLon(str) {
    var m = /(-?\d+(?:[.,]\d+)?)\s*[;,\s]\s*(-?\d+(?:[.,]\d+)?)/.exec(String(str || ''));
    if (!m) return null;
    var lat = parseFloat(m[1].replace(',', '.')), lon = parseFloat(m[2].replace(',', '.'));
    if (!isFinite(lat) || !isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return null;
    return { lat: lat, lon: lon };
  }

  /* ---------- Open-Meteo: Stundenreihen auswerten ---------- */
  function hourlyTimes(json) {
    var t = (json && json.hourly && json.hourly.time) || [];
    return t.map(function (s) { return Date.parse(s + 'Z'); });
  }
  function nearestIndex(times, target, maxGapMs) {
    var best = -1, bd = Infinity;
    for (var i = 0; i < times.length; i++) {
      var d = Math.abs(times[i] - target);
      if (d < bd) { bd = d; best = i; }
    }
    return bd <= (maxGapMs || 90 * 60000) ? best : -1;
  }

  function buildWeather(json, target) {
    var h = json && json.hourly, times = hourlyTimes(json);
    if (!h || !times.length) return null;
    var i = nearestIndex(times, target);
    if (i < 0) return null;
    var at = function (name, k) { return h[name] ? h[name][k] : null; };
    var pNow = at('pressure_msl', i), p3 = at('pressure_msl', i - 3);
    var w = {
      code: isNum(at('weather_code', i)) ? at('weather_code', i) : null,
      tempC: isNum(at('temperature_2m', i)) ? at('temperature_2m', i) : null,
      windKmh: isNum(at('wind_speed_10m', i)) ? at('wind_speed_10m', i) : null,
      windDir: isNum(at('wind_direction_10m', i)) ? at('wind_direction_10m', i) : null,
      gustKmh: isNum(at('wind_gusts_10m', i)) ? at('wind_gusts_10m', i) : null,
      pressure: isNum(pNow) ? pNow : null,
      pressureDelta3h: isNum(pNow) && isNum(p3) ? pNow - p3 : null,
      series: []
    };
    for (var k = Math.max(0, i - 12); k <= Math.min(times.length - 1, i + 12); k++) {
      var p = at('pressure_msl', k);
      if (isNum(p)) w.series.push({ t: times[k], v: p });
    }
    if (w.windKmh === null && w.pressure === null && w.tempC === null && w.code === null) return null;
    return w;
  }

  /* Luftdruck-Tendenz über 3 Stunden */
  function trendInfo(delta) {
    if (!isNum(delta)) return null;
    var a = Math.abs(delta);
    if (a < 1) return { arrow: '→', label: 'gleichbleibend' };
    var up = delta > 0;
    return { arrow: up ? '↗' : '↘', label: (a >= 3 ? 'stark ' : '') + (up ? 'steigend' : 'fallend') };
  }

  /* Tide aus dem Pegel (sea_level_height_msl): Phase, nächstes und letztes HW/NW */
  function analyzeTide(json, target) {
    var times = hourlyTimes(json);
    var h = json && json.hourly && json.hourly.sea_level_height_msl;
    if (!h || !times.length) return null;
    var i = nearestIndex(times, target);
    if (i < 0 || !isNum(h[i])) return null;

    var lo = Math.max(0, i - 13), hi = Math.min(times.length - 1, i + 13);
    var series = [], min = Infinity, max = -Infinity, k;
    for (k = lo; k <= hi; k++) {
      if (isNum(h[k])) {
        series.push({ t: times[k], v: h[k] });
        if (h[k] < min) min = h[k];
        if (h[k] > max) max = h[k];
      }
    }
    var range = max - min;

    var before = isNum(h[i - 1]) ? h[i - 1] : null;
    var after = isNum(h[i + 1]) ? h[i + 1] : null;
    var slope = null;
    if (before !== null && after !== null) slope = (after - before) / 2;
    else if (after !== null) slope = after - h[i];
    else if (before !== null) slope = h[i] - before;

    function extremumAt(j) {
      var a = h[j - 1], b = h[j], c = h[j + 1];
      if (!isNum(a) || !isNum(b) || !isNum(c)) return null;
      if (b >= a && b > c) return { type: 'HW', t: times[j], v: b };
      if (b <= a && b < c) return { type: 'NW', t: times[j], v: b };
      return null;
    }
    function extremum(dir) {
      for (var j = i + dir; j >= lo && j <= hi; j += dir) {
        var e = extremumAt(j);
        if (e) return e;
      }
      return null;
    }

    /* Liegt der Fang in der Stunde von Hoch- oder Niedrigwasser, steht das Wasser (Stauwasser) */
    var turn = range >= 0.2 ? extremumAt(i) : null;
    var phase;
    if (range < 0.2) phase = 'kaum';
    else if (turn || slope === null || Math.abs(slope) < 0.03) phase = 'stau';
    else phase = slope > 0 ? 'steigend' : 'fallend';

    return {
      levelM: h[i],
      phase: phase,
      turn: turn ? turn.type : null,
      rangeM: range,
      prev: phase === 'kaum' ? null : extremum(-1),
      next: phase === 'kaum' ? null : extremum(1),
      series: series
    };
  }

  function tideWord(phase, turn) {
    if (phase === 'stau' && turn) return turn === 'HW' ? 'Hochwasser' : 'Niedrigwasser';
    return { steigend: 'auflaufend', fallend: 'ablaufend', stau: 'Stauwasser', kaum: 'kaum Tide' }[phase] || '';
  }

  /* ---------- EXIF: Aufnahmezeit und GPS aus dem Foto ---------- */
  function readTiff(v, base) {
    var le = v.getUint16(base) === 0x4949;
    function u16(o) { return v.getUint16(base + o, le); }
    function u32(o) { return v.getUint32(base + o, le); }
    if (u16(2) !== 42) return null;
    var SIZES = { 1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8 };

    function ifd(o) {
      var n = u16(o), out = {};
      for (var i = 0; i < n; i++) {
        var e = o + 2 + i * 12, type = u16(e + 2), count = u32(e + 4);
        var total = (SIZES[type] || 1) * count;
        out[u16(e)] = { type: type, count: count, off: total <= 4 ? e + 8 : u32(e + 8) };
      }
      return out;
    }
    function ascii(entry) {
      var s = '';
      for (var i = 0; i < entry.count; i++) {
        var c = v.getUint8(base + entry.off + i);
        if (!c) break;
        s += String.fromCharCode(c);
      }
      return s;
    }
    function rat(o) { var d = u32(o + 4); return d ? u32(o) / d : NaN; }
    function dms(entry) { return rat(entry.off) + rat(entry.off + 8) / 60 + rat(entry.off + 16) / 3600; }

    var ifd0 = ifd(u32(4));
    var res = { lat: null, lon: null, time: null };

    var exifIfd = ifd0[0x8769] ? ifd(u32(ifd0[0x8769].off)) : null;
    var tEntry = (exifIfd && (exifIfd[0x9003] || exifIfd[0x9004])) || ifd0[0x0132];
    if (tEntry && tEntry.type === 2) {
      var m = /^(\d{4}):(\d{2}):(\d{2}) (\d{2}):(\d{2}):(\d{2})/.exec(ascii(tEntry));
      if (m && +m[1] > 1990) {
        var t = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime();
        if (isFinite(t)) res.time = t;
      }
    }

    if (ifd0[0x8825]) {
      var g = ifd(u32(ifd0[0x8825].off));
      if (g[1] && g[2] && g[3] && g[4] && g[2].count === 3 && g[4].count === 3) {
        var lat = dms(g[2]), lon = dms(g[4]);
        if (ascii(g[1]).charAt(0) === 'S') lat = -lat;
        if (ascii(g[3]).charAt(0) === 'W') lon = -lon;
        if (isFinite(lat) && isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && (lat !== 0 || lon !== 0)) {
          res.lat = lat;
          res.lon = lon;
        }
      }
    }
    return res.time === null && res.lat === null ? null : res;
  }

  function parseExif(buf) {
    try {
      var v = new DataView(buf);
      if (v.byteLength < 12 || v.getUint16(0) !== 0xFFD8) return null;
      var off = 2;
      while (off + 4 <= v.byteLength) {
        var marker = v.getUint16(off);
        if ((marker & 0xFF00) !== 0xFF00 || marker === 0xFFDA) return null;
        var len = v.getUint16(off + 2);
        if (marker === 0xFFE1 && v.getUint32(off + 4) === 0x45786966) return readTiff(v, off + 10);
        off += 2 + len;
      }
    } catch (e) { /* defekte Metadaten werden ignoriert */ }
    return null;
  }

  /* ---------- Diagramme als SVG-Text ---------- */
  function interp(series, t) {
    if (t <= series[0].t) return series[0].v;
    for (var i = 1; i < series.length; i++) {
      if (t <= series[i].t) {
        var a = series[i - 1], b = series[i];
        return a.v + (b.v - a.v) * (t - a.t) / (b.t - a.t);
      }
    }
    return series[series.length - 1].v;
  }

  function sparkSvg(series, markT, o) {
    if (!series || series.length < 2) return '';
    var W = 340, H = 104, pl = 10, pr = 10, pt = 18, pb = 20;
    var t0 = series[0].t, t1 = series[series.length - 1].t;
    var vs = series.map(function (p) { return p.v; });
    var lo = Math.min.apply(null, vs), hi = Math.max.apply(null, vs);
    var rangeText = lo.toFixed(o.digits) + ' bis ' + hi.toFixed(o.digits) + o.unit;
    var span = o.minSpan || 1;
    if (hi - lo < span) { var mid = (hi + lo) / 2; lo = mid - span / 2; hi = mid + span / 2; }
    function X(t) { return pl + (t - t0) / (t1 - t0) * (W - pl - pr); }
    function Y(v) { return pt + (1 - (v - lo) / (hi - lo)) * (H - pt - pb); }
    var pts = series.map(function (p) { return X(p.t).toFixed(1) + ',' + Y(p.v).toFixed(1); });
    var line = 'M' + pts.join(' L');
    var base = H - pb;
    var area = line + ' L' + X(t1).toFixed(1) + ',' + base + ' L' + X(t0).toFixed(1) + ',' + base + ' Z';
    var mt = Math.min(Math.max(markT, t0), t1), mx = X(mt), my = Y(interp(series, mt));
    function hoursLabel(ms) {
      var hrs = Math.round(ms / 36e5);
      return (hrs < 0 ? '−' : '+') + Math.abs(hrs) + ' h';
    }
    var left = mx - pl > 48 ? '<text class="s-t" x="' + pl + '" y="' + (H - 5) + '">' + hoursLabel(t0 - markT) + '</text>' : '';
    var right = (W - pr) - mx > 48 ? '<text class="s-t" x="' + (W - pr) + '" y="' + (H - 5) + '" text-anchor="end">' + hoursLabel(t1 - markT) + '</text>' : '';
    return '<svg class="spark" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(o.title) + '">' +
      '<path class="s-area" d="' + area + '"/><path class="s-line" d="' + line + '"/>' +
      '<line class="s-mark" x1="' + mx.toFixed(1) + '" x2="' + mx.toFixed(1) + '" y1="' + pt + '" y2="' + base + '"/>' +
      '<circle class="s-dot" cx="' + mx.toFixed(1) + '" cy="' + my.toFixed(1) + '" r="4"/>' +
      '<text class="s-t" x="' + pl + '" y="11">' + esc(o.title) + '</text>' +
      '<text class="s-t" x="' + (W - pr) + '" y="11" text-anchor="end">' + esc(rangeText) + '</text>' +
      left + '<text class="s-t s-fang" x="' + mx.toFixed(1) + '" y="' + (H - 5) + '" text-anchor="middle">Fang</text>' + right +
      '</svg>';
  }

  /* Pfeil zeigt dorthin, wohin der Wind weht (Richtung + 180°) */
  function windRose(deg) {
    return '<svg class="rose" viewBox="0 0 44 44" aria-hidden="true">' +
      '<circle class="r-ring" cx="22" cy="22" r="16"/>' +
      '<text class="r-n" x="22" y="7" text-anchor="middle">N</text>' +
      '<g transform="rotate(' + Math.round(deg + 180) + ' 22 22)"><path class="r-arrow" d="M22 12 L26.5 30 L22 26 L17.5 30 Z"/></g></svg>';
  }

  /* ---------- CSV (Semikolon, Dezimalkomma, für Excel) ---------- */
  function csvText(v) {
    var s = v === null || v === undefined ? '' : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    return /[;"\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function dec(v, d) { return isNum(v) ? v.toFixed(d).replace('.', ',') : ''; }

  function buildCsv(list) {
    var head = ['Datum', 'Uhrzeit', 'Fischart', 'Länge (cm)', 'Gewässer', 'Breitengrad', 'Längengrad', 'Wetter',
      'Temperatur (°C)', 'Wind (km/h)', 'Böen (km/h)', 'Windstärke (Bft)', 'Windrichtung', 'Luftdruck (hPa)',
      'Druckänderung 3 h (hPa)', 'Tide', 'Pegel (m zum Mittelwasser)', 'Notizen'];
    var rows = list.map(function (c) {
      var w = (c.conditions && c.conditions.weather) || {}, t = (c.conditions && c.conditions.tide) || null;
      var d = new Date(c.caughtAt);
      return [
        pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear(),
        pad(d.getHours()) + ':' + pad(d.getMinutes()),
        csvText(c.species), dec(c.lengthCm, 1), csvText(c.spot),
        dec(c.lat, 5), dec(c.lon, 5),
        w.code != null ? csvText(weatherText(w.code)) : '',
        dec(w.tempC, 1), dec(w.windKmh, 0), dec(w.gustKmh, 0),
        isNum(w.windKmh) ? beaufort(w.windKmh) : '', isNum(w.windDir) ? compass(w.windDir) : '',
        dec(w.pressure, 1), dec(w.pressureDelta3h, 1),
        t ? tideWord(t.phase, t.turn) : '', t ? dec(t.levelM, 2) : '',
        csvText(c.notes)
      ].join(';');
    });
    return [head.join(';')].concat(rows).join('\r\n');
  }

  var api = {
    SPECIES: SPECIES, isNum: isNum, esc: esc, weatherText: weatherText, beaufort: beaufort, compass: compass,
    ymdUTC: ymdUTC, toLocalInput: toLocalInput, fromLocalInput: fromLocalInput,
    n1: n1, signed: signed, fmtDate: fmtDate, fmtTime: fmtTime, fmtDateTime: fmtDateTime,
    fmtCoords: fmtCoords, mapsUrl: mapsUrl, parseLatLon: parseLatLon,
    buildWeather: buildWeather, trendInfo: trendInfo, analyzeTide: analyzeTide, tideWord: tideWord,
    parseExif: parseExif, sparkSvg: sparkSvg, windRose: windRose, buildCsv: buildCsv
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.FB = api;
})(typeof window !== 'undefined' ? window : this);
