npm create vite@latest mobile-code-studio -- --template react-ts
cd mobile-code-studio
npm install