package com.ayadlawa.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val background = Color.rgb(27, 28, 32)
        val blue = Color.rgb(110, 168, 255)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "AyadLawa Keyboard"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Use your Kurdish keyboard in WhatsApp, Facebook, Instagram and other apps."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 28)
        }

        fun actionButton(label: String, action: () -> Unit) =
            Button(this).apply {
                text = label
                textSize = 16f
                setTextColor(Color.WHITE)
                setBackgroundColor(blue)
                setOnClickListener { action() }
            }

        val enable = actionButton("1. Enable AyadLawa Keyboard") {
            startActivity(Intent("android.settings.INPUT_METHOD_SETTINGS"))
        }
        val choose = actionButton("2. Choose AyadLawa Keyboard") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        val note = TextView(this).apply {
            text = "After enabling it, open any app with a text field and select AyadLawa from the keyboard picker."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(enable, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        layout.addView(choose, LinearLayout.LayoutParams(-1, -2))
        layout.addView(note)
        setContentView(layout)
    }
}
