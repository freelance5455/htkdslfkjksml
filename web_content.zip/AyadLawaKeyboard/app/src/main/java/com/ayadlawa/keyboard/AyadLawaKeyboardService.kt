package com.ayadlawa.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AyadLawaKeyboardService : InputMethodService() {

    private enum class LayoutMode { SORANI, KURMANJI, ENGLISH, NUMBERS }
    private var mode = LayoutMode.SORANI
    private var caps = false

    private val bg = Color.rgb(13, 13, 15)
    private val keyColor = Color.rgb(38, 39, 43)
    private val altColor = Color.rgb(23, 24, 27)
    private val accent = Color.rgb(110, 168, 255)
    private val textColor = Color.rgb(242, 242, 242)

    override fun onCreateInputView(): View = buildKeyboard()

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
    }

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(5), dp(4), dp(7))
            setBackgroundColor(bg)
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        toolbar.addView(toolButton("کوردی") { mode = LayoutMode.SORANI; refresh() }, weightParams())
        toolbar.addView(toolButton("Kurmanji") { mode = LayoutMode.KURMANJI; refresh() }, weightParams())
        toolbar.addView(toolButton("EN") { mode = LayoutMode.ENGLISH; refresh() }, weightParams())
        toolbar.addView(toolButton("123") { mode = if (mode == LayoutMode.NUMBERS) LayoutMode.SORANI else LayoutMode.NUMBERS; refresh() }, weightParams())
        root.addView(toolbar, LinearLayout.LayoutParams(-1, dp(42)))

        val rows = currentRows()
        rows.forEachIndexed { index, row ->
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { character ->
                val letter = character.toString()
                val displayed = if (caps) letter.uppercase() else letter
                rowLayout.addView(keyButton(displayed) {
                    commit(displayed)
                }, LinearLayout.LayoutParams(0, dp(49), 1f))
            }
            root.addView(rowLayout, LinearLayout.LayoutParams(-1, dp(55)))
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        bottom.addView(actionButton("⇧", altColor) { caps = !caps; refresh() }, LinearLayout.LayoutParams(0, dp(49), 1.2f))
        bottom.addView(actionButton("?123", altColor) {
            mode = if (mode == LayoutMode.NUMBERS) LayoutMode.SORANI else LayoutMode.NUMBERS
            refresh()
        }, LinearLayout.LayoutParams(0, dp(49), 1.3f))
        bottom.addView(actionButton("🌐", altColor) {
            if (Build.VERSION.SDK_INT >= 28) switchToNextInputMethod(false)
            else (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, LinearLayout.LayoutParams(0, dp(49), 1f))
        bottom.addView(actionButton("،", keyColor) { commit("،") }, LinearLayout.LayoutParams(0, dp(49), 1f))
        bottom.addView(actionButton("space", keyColor) {
            commit(" ")
        }, LinearLayout.LayoutParams(0, dp(49), 3f))
        bottom.addView(actionButton("⌫", altColor) { deleteOne() }.apply {
            setOnLongClickListener {
                repeating = true
                val r = object : Runnable {
                    override fun run() {
                        if (!repeating) return
                        deleteOne()
                        postDelayed(this, 50)
                    }
                }
                post(r)
                true
            }
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) repeating = false
                false
            }
        }, LinearLayout.LayoutParams(0, dp(49), 1.3f))
        bottom.addView(actionButton("↵", accent) {
            val ic = currentInputConnection
            if (ic != null) {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                    ic.performEditorAction(action)
                } else {
                    ic.commitText("\n", 1)
                }
            }
        }, LinearLayout.LayoutParams(0, dp(49), 1.3f))
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(55)))

        return root
    }

    private fun currentRows(): List<String> = when (mode) {
        LayoutMode.SORANI -> listOf("قوەرتیئۆپڕ", "اسدفگھژکلێ", "زخجڤبنمشڵ", "غچحع")
        LayoutMode.KURMANJI -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm", "êîûçş")
        LayoutMode.ENGLISH -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        LayoutMode.NUMBERS -> listOf("١٢٣٤٥٦٧٨٩٠", "!@#$%&*()-", "+=/?:;.,")
    }

    private var repeating = false

    private fun deleteOne() {
        val ic = currentInputConnection ?: return
        if (ic.getSelectedText(0).isNullOrEmpty()) ic.deleteSurroundingText(1, 0)
        else ic.commitText("", 1)
    }

    private fun commit(value: String) {
        currentInputConnection?.commitText(value, 1)
    }

    private fun refresh() {
        setInputView(buildKeyboard())
    }

    private fun toolButton(label: String, action: () -> Unit) =
        actionButton(label, altColor, action).apply {
            textSize = 13f
        }

    private fun keyButton(label: String, action: () -> Unit) =
        actionButton(label, keyColor, action).apply {
            textSize = 20f
            typeface = Typeface.DEFAULT
        }

    private fun actionButton(label: String, color: Int, action: () -> Unit) =
        Button(this).apply {
            text = label
            setTextColor(textColor)
            textSize = 15f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(1), 0, dp(1), 0)
            background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(9).toFloat()
            }
            setOnClickListener { action() }
        }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(40), 1f).apply {
        setMargins(dp(2), dp(1), dp(2), dp(1))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
