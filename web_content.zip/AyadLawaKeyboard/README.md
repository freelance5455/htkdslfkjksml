# AyadLawa Keyboard — Android Studio starter project

This project converts the Sorani/Kurmanji keyboard concept into a native Android
Input Method Editor (IME), so Android can show it as a selectable system keyboard.

## Open and build
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `AyadLawaKeyboard` folder.
4. Allow Gradle sync to finish. Android Studio may download Android Gradle Plugin,
   Kotlin and Android SDK components.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press **Run** to install the app.

## Enable it on the phone
1. Open **AyadLawa Keyboard**.
2. Tap **Enable AyadLawa Keyboard**.
3. In Android's keyboard settings, turn on AyadLawa Keyboard.
4. Return to the app and tap **Choose AyadLawa Keyboard**, then select it.
5. Open WhatsApp, Notes or another app and tap a text field.

On Infinix/XOS, the settings wording can differ. Look under Settings → System
(or Additional settings) → Languages & input → On-screen keyboard / Manage keyboards.

## Included
- Android IME service declaration and input-method metadata
- Native keyboard UI using a dark theme and blue accent
- Sorani layout copied from the uploaded app's embedded HTML preview:
  قوەرتیئۆپڕ / اسدفگھژکلێ / زخجڤبنمشڵ / غچحع
- Kurmanji, English and number/symbol layout selectors
- Space, comma, delete, shift and enter actions
- Small launcher screen with Enable and Choose buttons

## Important
This is a native keyboard starter project, not a finished reproduction of every
feature in the existing APK. The APK's embedded web interface includes additional
settings, panels and features that are not yet ported into this native IME.
The uploaded APK is a compiled application, so this project does not replace or
modify that APK. It creates a separate Android Studio project that can be extended.

Before publishing, test the keyboard with multiple apps and Android versions.
A keyboard can receive sensitive text typed into it; only add network, analytics,
or logging features if they are genuinely needed and clearly disclosed.
