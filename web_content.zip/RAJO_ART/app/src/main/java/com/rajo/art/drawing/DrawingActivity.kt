
package com.rajo.art.drawing

import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.rajo.art.R
import com.rajo.art.floating.FloatingDrawingService
import com.rajo.art.floating.FloatingReferenceWindow
import com.rajo.art.floating.NotificationPermissionHelper
import com.rajo.art.floating.OverlayPermissionHelper
import com.rajo.art.image.ImageLoader
import com.rajo.art.image.ImageProcessor
import com.rajo.art.image.ImageSaver
import com.rajo.art.image.PhotoPickerHelper

class DrawingActivity : AppCompatActivity() {

    private lateinit var drawingView: DrawingView
    private lateinit var editor: DrawingEditor
    private lateinit var referenceImage: ImageView
    private lateinit var imageLayerManager: ImageLayerManager
    private lateinit var opacityController: ImageOpacityController

    private var floatingReferenceWindow:
        FloatingReferenceWindow? = null

    private var currentReferenceBitmap:
        Bitmap? = null

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_drawing
        )

        drawingView =
            findViewById(
                R.id.drawingView
            )

        referenceImage =
            findViewById(
                R.id.referenceImage
            )

        imageLayerManager =
            ImageLayerManager(
                referenceImage
            )

        editor =
            DrawingEditor(
                this,
                drawingView
            )

        findViewById<LinearLayout>(
            R.id.drawingToolbar
        ).addView(
            editor.createToolbar()
        )

        opacityController =
            ImageOpacityController(
                imageLayerManager,
                findViewById<TextView>(
                    R.id.tvOpacity
                )
            )

        opacityController.attach(
            findViewById<SeekBar>(
                R.id.opacitySeekBar
            )
        )

        floatingReferenceWindow =
            FloatingReferenceWindow(
                this
            )

        setupButtons()
        setupReferenceImageGestures()
    }

    private fun setupButtons() {

        findViewById<MaterialButton>(
            R.id.btnChooseImage
        ).setOnClickListener {

            PhotoPickerHelper.open(
                this
            )
        }

        findViewById<MaterialButton>(
            R.id.btnSaveDrawing
        ).setOnClickListener {

            saveDrawing()
        }

        findViewById<MaterialButton>(
            R.id.btnFloatingWindow
        ).setOnClickListener {

            openFloatingWindow()
        }

        findViewById<MaterialButton>(
            R.id.btnZoomIn
        ).setOnClickListener {

            imageLayerManager.scaleBy(
                1.15f
            )
        }

        findViewById<MaterialButton>(
            R.id.btnZoomOut
        ).setOnClickListener {

            imageLayerManager.scaleBy(
                0.87f
            )
        }

        findViewById<MaterialButton>(
            R.id.btnRotateLeft
        ).setOnClickListener {

            imageLayerManager.rotateBy(
                -15f
            )
        }

        findViewById<MaterialButton>(
            R.id.btnRotateRight
        ).setOnClickListener {

            imageLayerManager.rotateBy(
                15f
            )
        }

        findViewById<MaterialButton>(
            R.id.btnHideImage
        ).setOnClickListener {

            imageLayerManager.setVisible(
                false
            )
        }

        findViewById<MaterialButton>(
            R.id.btnShowImage
        ).setOnClickListener {

            if (
                referenceImage.drawable != null
            ) {

                imageLayerManager.setVisible(
                    true
                )

            } else {

                Toast.makeText(
                    this,
                    "اختر صورة أولاً",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        findViewById<MaterialButton>(
            R.id.btnBlackBackground
        ).setOnClickListener {

            processBlackBackground()
        }

        findViewById<MaterialButton>(
            R.id.btnWhiteBackground
        ).setOnClickListener {

            processWhiteBackground()
        }
    }

    private fun openFloatingWindow() {

        if (
            !OverlayPermissionHelper
                .canDrawOverlays(this)
        ) {

            Toast.makeText(
                this,
                "فعّل صلاحية الظهور فوق التطبيقات أولاً",
                Toast.LENGTH_LONG
            ).show()

            OverlayPermissionHelper
                .openSettings(this)

            return
        }

        NotificationPermissionHelper.request(
            this
        )

        val serviceIntent =
            Intent(
                this,
                FloatingDrawingService::class.java
            )

        try {

            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O
            ) {

                startForegroundService(
                    serviceIntent
                )

            } else {

                @Suppress("DEPRECATION")
                startService(
                    serviceIntent
                )
            }

            Toast.makeText(
                this,
                "تم تشغيل النوافذ العائمة",
                Toast.LENGTH_SHORT
            ).show()

        } catch (_: Exception) {

            Toast.makeText(
                this,
                "تعذر تشغيل النوافذ العائمة",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    @Deprecated(
        "Deprecated in Android API"
    )
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {

        super.onActivityResult(
            requestCode,
            resultCode,
            data
        )

        val uri =
            PhotoPickerHelper
                .getUriFromResult(
                    requestCode,
                    resultCode,
                    data
                )
                ?: return

        val bitmap =
            ImageLoader.load(
                this,
                uri
            )

        if (bitmap == null) {

            Toast.makeText(
                this,
                "تعذر فتح الصورة",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        currentReferenceBitmap =
            bitmap

        referenceImage.setImageBitmap(
            bitmap
        )

        referenceImage.visibility =
            android.view.View.VISIBLE

        imageLayerManager.reset()

        findViewById<SeekBar>(
            R.id.opacitySeekBar
        ).progress = 100

        if (
            OverlayPermissionHelper
                .canDrawOverlays(this)
        ) {

            try {

                floatingReferenceWindow?.show()

                floatingReferenceWindow
                    ?.setBitmap(
                        bitmap
                    )

            } catch (_: Exception) {
            }
        }

        Toast.makeText(
            this,
            "تمت إضافة الصورة المرجعية",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun setupReferenceImageGestures() {

        var lastX = 0f
        var lastY = 0f

        referenceImage.setOnTouchListener { _, event ->

            when (
                event.actionMasked
            ) {

                MotionEvent.ACTION_DOWN -> {

                    lastX =
                        event.rawX

                    lastY =
                        event.rawY

                    true
                }

                MotionEvent.ACTION_MOVE -> {

                    val dx =
                        event.rawX -
                            lastX

                    val dy =
                        event.rawY -
                            lastY

                    imageLayerManager.move(
                        dx,
                        dy
                    )

                    lastX =
                        event.rawX

                    lastY =
                        event.rawY

                    true
                }

                MotionEvent.ACTION_UP -> true

                else -> false
            }
        }
    }

    private fun saveDrawing() {

        val bitmap =
            drawingView.exportBitmap()

        val success =
            ImageSaver.save(
                this,
                bitmap,
                "RAJO_ART_${System.currentTimeMillis()}.png"
            )

        Toast.makeText(
            this,
            if (success) {
                "تم حفظ الرسم بنجاح"
            } else {
                "تعذر حفظ الرسم"
            },
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun processBlackBackground() {

        val bitmap =
            drawingView.exportBitmap()

        val processed =
            ImageProcessor.toBlackBackground(
                bitmap
            )

        val success =
            ImageSaver.save(
                this,
                processed,
                "RAJO_ART_BLACK_${System.currentTimeMillis()}.png"
            )

        Toast.makeText(
            this,
            if (success) {
                "تم إنشاء الصورة بالخلفية السوداء وحفظها"
            } else {
                "تعذر حفظ الصورة"
            },
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun processWhiteBackground() {

        val bitmap =
            drawingView.exportBitmap()

        val processed =
            ImageProcessor.toWhiteBackground(
                bitmap
            )

        val success =
            ImageSaver.save(
                this,
                processed,
                "RAJO_ART_WHITE_${System.currentTimeMillis()}.png"
            )

        Toast.makeText(
            this,
            if (success) {
                "تم إنشاء الصورة بالخلفية البيضاء وحفظها"
            } else {
                "تعذر حفظ الصورة"
            },
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onDestroy() {

        floatingReferenceWindow?.hide()

        floatingReferenceWindow =
            null

        super.onDestroy()
    }
}