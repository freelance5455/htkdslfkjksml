
package com.rajo.art.floating

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class FloatingLauncherView(
    private val context: Context,
    private val onNewWindow: () -> Unit,
    private val onClose: () -> Unit
) {

    private val windowManager =
        context.getSystemService(
            Context.WINDOW_SERVICE
        ) as WindowManager

    private var launcherView:
        TextView? = null

    private var params:
        WindowManager.LayoutParams? = null

    fun show() {

        if (launcherView != null) {
            return
        }

        val view =
            TextView(context).apply {

                text =
                    "+"

                textSize =
                    28f

                setTextColor(
                    Color.WHITE
                )

                gravity =
                    Gravity.CENTER

                background =
                    GradientDrawable().apply {

                        shape =
                            GradientDrawable.OVAL

                        setColor(
                            Color.rgb(
                                13,
                                71,
                                161
                            )
                        )

                        setStroke(
                            3,
                            Color.rgb(
                                33,
                                150,
                                243
                            )
                        )
                    }
            }

        val type =
            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O
            ) {

                WindowManager.LayoutParams
                    .TYPE_APPLICATION_OVERLAY

            } else {

                @Suppress("DEPRECATION")
                WindowManager.LayoutParams
                    .TYPE_PHONE
            }

        val windowParams =
            WindowManager.LayoutParams(
                70,
                70,
                type,
                WindowManager.LayoutParams
                    .FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )

        windowParams.gravity =
            Gravity.TOP or
                Gravity.START

        windowParams.x =
            20

        windowParams.y =
            250

        try {

            windowManager.addView(
                view,
                windowParams
            )

            launcherView =
                view

            params =
                windowParams

            setupTouch(
                view,
                windowParams
            )

        } catch (_: Exception) {
        }
    }

    private fun setupTouch(
        view: View,
        windowParams:
            WindowManager.LayoutParams
    ) {

        var downX =
            0f

        var downY =
            0f

        var startX =
            0

        var startY =
            0

        var moved =
            false

        view.setOnTouchListener { _, event ->

            when (
                event.actionMasked
            ) {

                MotionEvent.ACTION_DOWN -> {

                    downX =
                        event.rawX

                    downY =
                        event.rawY

                    startX =
                        windowParams.x

                    startY =
                        windowParams.y

                    moved =
                        false

                    true
                }

                MotionEvent.ACTION_MOVE -> {

                    val dx =
                        event.rawX -
                            downX

                    val dy =
                        event.rawY -
                            downY

                    if (
                        kotlin.math.abs(dx) > 8 ||
                        kotlin.math.abs(dy) > 8
                    ) {
                        moved =
                            true
                    }

                    windowParams.x =
                        startX +
                            dx.toInt()

                    windowParams.y =
                        startY +
                            dy.toInt()

                    try {

                        windowManager
                            .updateViewLayout(
                                view,
                                windowParams
                            )

                    } catch (_: Exception) {
                    }

                    true
                }

                MotionEvent.ACTION_UP -> {

                    if (!moved) {
                        onNewWindow()
                    }

                    true
                }

                MotionEvent.ACTION_CANCEL -> {

                    true
                }

                else -> false
            }
        }

        view.setOnLongClickListener {

            onClose()

            true
        }
    }

    fun hide() {

        val view =
            launcherView

        if (view != null) {

            try {

                windowManager.removeView(
                    view
                )

            } catch (_: Exception) {
            }
        }

        launcherView =
            null

        params =
            null
    }
}