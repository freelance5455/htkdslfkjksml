package com.rajo.art.image

import android.graphics.Bitmap
import android.graphics.Color

object ImageProcessor {

    fun toBlackBackground(source: Bitmap): Bitmap {

        val result = Bitmap.createBitmap(
            source.width,
            source.height,
            Bitmap.Config.ARGB_8888
        )

        for (x in 0 until source.width) {
            for (y in 0 until source.height) {

                val pixel = source.getPixel(x, y)

                val red = Color.red(pixel)
                val green = Color.green(pixel)
                val blue = Color.blue(pixel)

                val brightness =
                    (red + green + blue) / 3

                result.setPixel(
                    x,
                    y,
                    if (brightness > 128) {
                        Color.WHITE
                    } else {
                        Color.BLACK
                    }
                )
            }
        }

        return result
    }

    fun toWhiteBackground(source: Bitmap): Bitmap {

        val result = Bitmap.createBitmap(
            source.width,
            source.height,
            Bitmap.Config.ARGB_8888
        )

        for (x in 0 until source.width) {
            for (y in 0 until source.height) {

                val pixel = source.getPixel(x, y)

                val red = Color.red(pixel)
                val green = Color.green(pixel)
                val blue = Color.blue(pixel)

                val brightness =
                    (red + green + blue) / 3

                result.setPixel(
                    x,
                    y,
                    if (brightness > 128) {
                        Color.BLACK
                    } else {
                        Color.WHITE
                    }
                )
            }
        }

        return result
    }
}