package com.rajo.art.data

object DrawingRepository {

    const val MEN = "الشخصيات الرجال"
    const val ANIMALS = "الحيوانات"
    const val WEAPONS = "الأسلحة"
    const val REALISTIC = "العلامات الواقعية"
    const val TEXT = "المخططات النصية"
    const val EXTRA = "رسومات إضافية"

    fun getCategories(): List<String> {
        return listOf(
            MEN,
            ANIMALS,
            WEAPONS,
            REALISTIC,
            TEXT,
            EXTRA
        )
    }

    fun getDrawings(): List<DrawingItem> {
        return listOf(
            DrawingItem(
                1,
                "رسم شخصية 01",
                MEN,
                "مخطط شخصية قابل للرسم والتدريب."
            ),
            DrawingItem(
                2,
                "رسم شخصية 02",
                MEN,
                "مخطط شخصية إضافي."
            ),
            DrawingItem(
                3,
                "حيوان 01",
                ANIMALS,
                "مخطط حيوان للتدريب."
            ),
            DrawingItem(
                4,
                "سلاح 01",
                WEAPONS,
                "مخطط سلاح للتدريب على الرسم."
            ),
            DrawingItem(
                5,
                "علامة واقعية 01",
                REALISTIC,
                "مخطط واقعي للتدريب."
            ),
            DrawingItem(
                6,
                "مخطط نصي 01",
                TEXT,
                "مخطط نصي للرسم."
            ),
            DrawingItem(
                7,
                "رسم إضافي 01",
                EXTRA,
                "مخطط إضافي من RAJO ART."
            )
        )
    }

    fun getByCategory(category: String): List<DrawingItem> {
        return getDrawings().filter {
            it.category == category
        }
    }
}