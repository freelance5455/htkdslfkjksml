package com.rajo.art

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class CountryActivity : AppCompatActivity() {

    private val countries = mapOf(
        R.id.btnIraq to "العراق",
        R.id.btnSyria to "سوريا",
        R.id.btnJordan to "الأردن",
        R.id.btnSaudi to "السعودية",
        R.id.btnUae to "الإمارات",
        R.id.btnKuwait to "الكويت",
        R.id.btnQatar to "قطر",
        R.id.btnEgypt to "مصر",
        R.id.btnLebanon to "لبنان",
        R.id.btnPalestine to "فلسطين",
        R.id.btnTurkey to "تركيا"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_country)

        countries.forEach { (buttonId, country) ->
            findViewById<MaterialButton>(buttonId).setOnClickListener {
                saveCountryAndContinue(country)
            }
        }
    }

    private fun saveCountryAndContinue(country: String) {
        getSharedPreferences("rajo_art_prefs", MODE_PRIVATE)
            .edit()
            .putString("selected_country", country)
            .putBoolean("country_selected", true)
            .apply()

        Toast.makeText(
            this,
            "تم اختيار $country",
            Toast.LENGTH_SHORT
        ).show()

        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}