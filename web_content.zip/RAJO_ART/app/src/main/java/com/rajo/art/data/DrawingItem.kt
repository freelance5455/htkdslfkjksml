package com.rajo.art.data

data class DrawingItem(
    val id: Int,
    val title: String,
    val category: String,
    val description: String,
    val imageResId: Int? = null
)