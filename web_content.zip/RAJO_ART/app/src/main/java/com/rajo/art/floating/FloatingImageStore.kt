package com.rajo.art.floating

import android.net.Uri

object FloatingImageStore {

    private var imageUri: Uri? = null

    private var listener: ((Uri) -> Unit)? = null

    fun setListener(
        callback: (Uri) -> Unit
    ) {
        listener = callback

        imageUri?.let { uri ->
            callback(uri)
        }
    }

    fun setUri(
        uri: Uri
    ) {
        imageUri = uri

        listener?.invoke(uri)
    }

    fun getUri(): Uri? {
        return imageUri
    }

    fun clear() {
        imageUri = null
        listener = null
    }
}