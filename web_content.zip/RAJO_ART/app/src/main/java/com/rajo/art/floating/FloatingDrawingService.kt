package com.rajo.art.floating

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.rajo.art.R
import com.rajo.art.drawing.DrawingView

class FloatingDrawingService : Service() {

    companion object {
        private const val CHANNEL_ID =
            "rajo_art_floating"

        private const val NOTIFICATION_ID =
            1001

        const val ACTION_NEW_WINDOW =
            "com.rajo.art.NEW_WINDOW"

        const val ACTION_CLOSE_ALL =
            "com.rajo.art.CLOSE_ALL"
    }

    private lateinit var windowManager:
        WindowManager

    private val drawingWindows =
        mutableListOf<LinearLayout>()

    private val referenceWindows =
        mutableListOf<FloatingReferenceWindow>()

    private var launcher:
        FloatingLauncherView? = null

    override fun onCreate() {
        super.onCreate()

        windowManager =
            getSystemService(
                WINDOW_SERVICE
            ) as WindowManager

        createNotificationChannel()

        startForeground(
            NOTIFICATION_ID,
            createNotification()
        )

        createLauncher()

        createDrawingWindow()
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        when (intent?.action) {

            ACTION_NEW_WINDOW -> {
                showLauncherMenu()
            }

            ACTION_CLOSE_ALL -> {
                closeAll()
            }
        }

        return START_NOT_STICKY
    }

    private fun createLauncher() {

        launcher =
            FloatingLauncherView(
                context = this,

                onNewWindow = {
                    showLauncherMenu()
                },

                onClose = {
                    closeAll()
                }
            )

        launcher?.show()
    }

    private fun showLauncherMenu() {

        val menu =
            LinearLayout(this).apply {

                orientation =
                    LinearLayout.VERTICAL

                setPadding(
                    18,
                    18,
                    18,
                    18
                )

                background =
                    GradientDrawable().apply {

                        setColor(
                            Color.rgb(
                                7,
                                20,
                                38
                            )
                        )

                        cornerRadius =
                            28f

                        setStroke(
                            2,
                            Color.rgb(
                                33,
                                150,
                                243
                            )
                        )
                    }
            }

        val title =
            TextView(this).apply {

                text =
                    "RAJO ART"

                textSize =
                    18f

                setTextColor(
                    Color.WHITE
                )

                gravity =
                    Gravity.CENTER

                setPadding(
                    10,
                    10,
                    10,
                    18
                )
            }

        val drawing =
            createMenuButton(
                "🎨  نافذة رسم"
            ) {

                removeMenu(menu)

                createDrawingWindow()
            }

        val reference =
            createMenuButton(
                "🖼️  صورة مرجعية"
            ) {

                removeMenu(menu)

                createReferenceWindow()
            }

        val close =
            createMenuButton(
                "✕  إلغاء"
            ) {

                removeMenu(menu)
            }

        menu.addView(title)
        menu.addView(drawing)
        menu.addView(reference)
        menu.addView(close)

        val type =
            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O
            ) {

                WindowManager.LayoutParams
                    .TYPE_APPLICATION_OVERLAY

            } else {

                @Suppress("DEPRECATION")
                WindowManager.LayoutParams
                    .TYPE_PHONE
            }

        val params =
            WindowManager.LayoutParams(
                430,
                WindowManager.LayoutParams
                    .WRAP_CONTENT,
                type,
                WindowManager.LayoutParams
                    .FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )

        params.gravity =
            Gravity.TOP or Gravity.START

        params.x =
            40

        params.y =
            330

        try {

            windowManager.addView(
                menu,
                params
            )

        } catch (_: Exception) {
        }
    }

    private fun createReferenceWindow() {

        val window =
            FloatingReferenceWindow(
                this
            )

        referenceWindows.add(
            window
        )

        window.show()
    }

    private fun createMenuButton(
        text: String,
        action: () -> Unit
    ): TextView {

        return TextView(this).apply {

            this.text =
                text

            textSize =
                15f

            setTextColor(
                Color.WHITE
            )

            gravity =
                Gravity.CENTER

            setPadding(
                20,
                18,
                20,
                18
            )

            setOnClickListener {
                action()
            }
        }
    }

    private fun removeMenu(
        menu: View
    ) {

        try {

            windowManager.removeView(
                menu
            )

        } catch (_: Exception) {
        }
    }

    private fun createDrawingWindow() {

        val root =
            LinearLayout(this).apply {

                orientation =
                    LinearLayout.VERTICAL

                setPadding(
                    8,
                    8,
                    8,
                    8
                )

                background =
                    GradientDrawable().apply {

                        setColor(
                            Color.rgb(
                                5,
                                7,
                                10
                            )
                        )

                        cornerRadius =
                            24f

                        setStroke(
                            2,
                            Color.rgb(
                                33,
                                150,
                                243
                            )
                        )
                    }
            }

        val header =
            LinearLayout(this).apply {

                orientation =
                    LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER_VERTICAL
            }

        val title =
            TextView(this).apply {

                text =
                    "RAJO ART #${drawingWindows.size + 1}"

                textSize =
                    14f

                setTextColor(
                    Color.WHITE
                )

                gravity =
                    Gravity.CENTER_VERTICAL

                setPadding(
                    12,
                    0,
                    12,
                    0
                )

                layoutParams =
                    LinearLayout.LayoutParams(
                        0,
                        48
                    ).apply {
                        weight = 1f
                    }
            }

        val newButton =
            createHeaderButton("+")
        val minimizeButton =
            createHeaderButton("−")
        val maximizeButton =
            createHeaderButton("□")
        val closeButton =
            createHeaderButton("×")

        header.addView(title)
        header.addView(newButton)
        header.addView(minimizeButton)
        header.addView(maximizeButton)
        header.addView(closeButton)

        root.addView(header)

        val drawing =
            DrawingView(this).apply {

                layoutParams =
                    LinearLayout.LayoutParams(
                        620,
                        520
                    )
            }

        root.addView(
            drawing
        )

        val toolbar =
            LinearLayout(this).apply {

                orientation =
                    LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER
            }

        toolbar.addView(
            createToolButton(
                "مسح"
            ) {
                drawing.clearDrawing()
            }
        )

        toolbar.addView(
            createToolButton(
                "تراجع"
            ) {
                drawing.undo()
            }
        )

        toolbar.addView(
            createToolButton(
                "إعادة"
            ) {
                drawing.redo()
            }
        )

        toolbar.addView(
            createToolButton(
                "أبيض"
            ) {
                drawing.setBrushColor(
                    Color.WHITE
                )
            }
        )

        toolbar.addView(
            createToolButton(
                "أسود"
            ) {
                drawing.setBrushColor(
                    Color.BLACK
                )
            }
        )

        root.addView(
            toolbar
        )

        val type =
            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O
            ) {

                WindowManager.LayoutParams
                    .TYPE_APPLICATION_OVERLAY

            } else {

                @Suppress("DEPRECATION")
                WindowManager.LayoutParams
                    .TYPE_PHONE
            }

        val offset =
            drawingWindows.size * 35

        val params =
            WindowManager.LayoutParams(
                660,
                WindowManager.LayoutParams
                    .WRAP_CONTENT,
                type,
                WindowManager.LayoutParams
                    .FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )

        params.gravity =
            Gravity.TOP or
                Gravity.START

        params.x =
            30 + offset

        params.y =
            120 + offset

        try {

            windowManager.addView(
                root,
                params
            )

            drawingWindows.add(
                root
            )

        } catch (_: Exception) {

            return
        }

        attachDragging(
            root,
            header,
            params
        )

        newButton.setOnClickListener {

            showLauncherMenu()
        }

        minimizeButton.setOnClickListener {

            drawing.visibility =
                View.GONE

            toolbar.visibility =
                View.GONE

            params.width =
                250

            params.height =
                90

            try {

                windowManager
                    .updateViewLayout(
                        root,
                        params
                    )

            } catch (_: Exception) {
            }
        }

        maximizeButton.setOnClickListener {

            val metrics =
                resources.displayMetrics

            params.width =
                (
                    metrics.widthPixels *
                        0.92f
                    ).toInt()

            params.height =
                (
                    metrics.heightPixels *
                        0.75f
                    ).toInt()

            drawing.visibility =
                View.VISIBLE

            toolbar.visibility =
                View.VISIBLE

            try {

                windowManager
                    .updateViewLayout(
                        root,
                        params
                    )

            } catch (_: Exception) {
            }
        }

        closeButton.setOnClickListener {

            removeDrawingWindow(
                root
            )
        }
    }

    private fun createHeaderButton(
        text: String
    ): TextView {

        return TextView(this).apply {

            this.text =
                text

            textSize =
                20f

            setTextColor(
                Color.WHITE
            )

            gravity =
                Gravity.CENTER

            setPadding(
                14,
                0,
                14,
                0
            )
        }
    }

    private fun createToolButton(
        text: String,
        action: () -> Unit
    ): TextView {

        return TextView(this).apply {

            this.text =
                text

            textSize =
                12f

            setTextColor(
                Color.WHITE
            )

            gravity =
                Gravity.CENTER

            setPadding(
                12,
                10,
                12,
                10
            )

            setOnClickListener {
                action()
            }
        }
    }

    private fun attachDragging(
        window: View,
        handle: View,
        params: WindowManager.LayoutParams
    ) {

        var startX =
            params.x

        var startY =
            params.y

        var touchX =
            0f

        var touchY =
            0f

        handle.setOnTouchListener { _, event ->

            when (
                event.actionMasked
            ) {

                MotionEvent.ACTION_DOWN -> {

                    startX =
                        params.x

                    startY =
                        params.y

                    touchX =
                        event.rawX

                    touchY =
                        event.rawY

                    true
                }

                MotionEvent.ACTION_MOVE -> {

                    params.x =
                        startX +
                            (
                                event.rawX -
                                    touchX
                                ).toInt()

                    params.y =
                        startY +
                            (
                                event.rawY -
                                    touchY
                                ).toInt()

                    try {

                        windowManager
                            .updateViewLayout(
                                window,
                                params
                            )

                    } catch (_: Exception) {
                    }

                    true
                }

                else -> false
            }
        }
    }

    private fun removeDrawingWindow(
        window: LinearLayout
    ) {

        try {

            windowManager.removeView(
                window
            )

        } catch (_: Exception) {
        }

        drawingWindows.remove(
            window
        )
    }

    private fun closeAll() {

        drawingWindows
            .toList()
            .forEach { window ->

                try {

                    windowManager.removeView(
                        window
                    )

                } catch (_: Exception) {
                }
            }

        drawingWindows.clear()

        referenceWindows
            .toList()
            .forEach { window ->

                window.hide()
            }

        referenceWindows.clear()

        launcher?.hide()

        launcher =
            null

        stopSelf()
    }

    override fun onDestroy() {

        drawingWindows
            .toList()
            .forEach { window ->

                try {

                    windowManager.removeView(
                        window
                    )

                } catch (_: Exception) {
                }
            }

        drawingWindows.clear()

        referenceWindows
            .toList()
            .forEach { window ->

                window.hide()
            }

        referenceWindows.clear()

        launcher?.hide()

        launcher =
            null

        super.onDestroy()
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? {

        return null
    }

    private fun createNotificationChannel() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            val channel =
                NotificationChannel(
                    CHANNEL_ID,
                    "RAJO ART Floating Windows",
                    NotificationManager
                        .IMPORTANCE_LOW
                )

            getSystemService(
                NotificationManager::class.java
            ).createNotificationChannel(
                channel
            )
        }
    }

    private fun createNotification():
        Notification {

        return if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            Notification.Builder(
                this,
                CHANNEL_ID
            )
                .setContentTitle(
                    "RAJO ART"
                )
                .setContentText(
                    "النوافذ العائمة تعمل"
                )
                .setSmallIcon(
                    R.mipmap.ic_launcher
                )
                .setOngoing(
                    true
                )
                .build()

        } else {

            @Suppress("DEPRECATION")
            Notification.Builder(
                this
            )
                .setContentTitle(
                    "RAJO ART"
                )
                .setContentText(
                    "النوافذ العائمة تعمل"
                )
                .setSmallIcon(
                    R.mipmap.ic_launcher
                )
                .setOngoing(
                    true
                )
                .build()
        }
    }
}