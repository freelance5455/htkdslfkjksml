package com.rajo.art.drawing

import android.view.View

class ImageLayerManager(
    private val imageView: View
) {

    private var scale = 1f
    private var rotation = 0f

    fun move(
        dx: Float,
        dy: Float
    ) {
        imageView.translationX += dx
        imageView.translationY += dy
    }

    fun scaleBy(
        factor: Float
    ) {
        scale = (
            scale * factor
        ).coerceIn(
            0.2f,
            5f
        )

        imageView.scaleX = scale
        imageView.scaleY = scale
    }

    fun rotateBy(
        degrees: Float
    ) {
        rotation += degrees

        imageView.rotation =
            rotation
    }

    fun setOpacity(
        opacity: Float
    ) {
        imageView.alpha =
            opacity.coerceIn(
                0f,
                1f
            )
    }

    fun setVisible(
        visible: Boolean
    ) {
        imageView.visibility =
            if (visible) {
                View.VISIBLE
            } else {
                View.GONE
            }
    }

    fun reset() {

        scale = 1f
        rotation = 0f

        imageView.translationX = 0f
        imageView.translationY = 0f

        imageView.scaleX = 1f
        imageView.scaleY = 1f

        imageView.rotation = 0f
        imageView.alpha = 1f

        imageView.visibility =
            View.VISIBLE
    }
}