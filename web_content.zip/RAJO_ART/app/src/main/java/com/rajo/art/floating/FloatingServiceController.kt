package com.rajo.art.floating

import android.content.Context
import android.content.Intent
import android.os.Build

object FloatingServiceController {

    fun start(context: Context) {

        if (
            !OverlayPermissionHelper
                .canDrawOverlays(context)
        ) {
            return
        }

        val intent =
            Intent(
                context,
                FloatingDrawingService::class.java
            )

        try {

            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O
            ) {

                context.startForegroundService(
                    intent
                )

            } else {

                @Suppress("DEPRECATION")
                context.startService(
                    intent
                )
            }

        } catch (_: Exception) {
        }
    }

    fun stop(context: Context) {

        val intent =
            Intent(
                context,
                FloatingDrawingService::class.java
            )

        try {

            context.stopService(
                intent
            )

        } catch (_: Exception) {
        }
    }

    fun openNewWindow(
        context: Context
    ) {

        val intent =
            Intent(
                context,
                FloatingDrawingService::class.java
            ).apply {

                action =
                    FloatingDrawingService
                        .ACTION_NEW_WINDOW
            }

        try {

            context.startService(
                intent
            )

        } catch (_: Exception) {
        }
    }

    fun closeAll(
        context: Context
    ) {

        val intent =
            Intent(
                context,
                FloatingDrawingService::class.java
            ).apply {

                action =
                    FloatingDrawingService
                        .ACTION_CLOSE_ALL
            }

        try {

            context.startService(
                intent
            )

        } catch (_: Exception) {
        }
    }
}