package com.rajo.art.data

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.button.MaterialButton
import com.rajo.art.R
import com.rajo.art.drawing.DrawingActivity

class DrawingsListActivity : AppCompatActivity() {

    private lateinit var adapter: DrawingAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drawings_list)

        val recyclerView =
            findViewById<androidx.recyclerview.widget.RecyclerView>(
                R.id.drawingsRecyclerView
            )

        adapter = DrawingAdapter(
            DrawingRepository.getDrawings()
        ) { item ->
            openDrawing(item)
        }

        recyclerView.layoutManager =
            LinearLayoutManager(this)

        recyclerView.adapter = adapter

        setupCategories()
    }

    private fun setupCategories() {

        val container =
            findViewById<LinearLayout>(
                R.id.categoryContainer
            )

        DrawingRepository.getCategories()
            .forEach { category ->

                val button =
                    MaterialButton(this).apply {
                        text = category
                        isAllCaps = false
                        setOnClickListener {
                            adapter.updateItems(
                                DrawingRepository
                                    .getByCategory(category)
                            )
                        }
                    }

                container.addView(button)
            }
    }

    private fun openDrawing(item: DrawingItem) {

        val intent =
            Intent(this, DrawingActivity::class.java)

        intent.putExtra(
            "drawing_id",
            item.id
        )

        intent.putExtra(
            "drawing_title",
            item.title
        )

        startActivity(intent)
    }
}