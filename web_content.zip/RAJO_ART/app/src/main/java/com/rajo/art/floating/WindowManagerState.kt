package com.rajo.art.floating

object WindowManagerState {

    var floatingServiceRunning = false
        private set

    var drawingWindowCount = 0
        private set

    var referenceWindowCount = 0
        private set

    fun serviceStarted() {
        floatingServiceRunning = true
    }

    fun serviceStopped() {
        floatingServiceRunning = false
        drawingWindowCount = 0
        referenceWindowCount = 0
    }

    fun drawingOpened() {
        drawingWindowCount++
    }

    fun drawingClosed() {
        drawingWindowCount =
            (drawingWindowCount - 1)
                .coerceAtLeast(0)
    }

    fun referenceOpened() {
        referenceWindowCount++
    }

    fun referenceClosed() {
        referenceWindowCount =
            (referenceWindowCount - 1)
                .coerceAtLeast(0)
    }

    fun reset() {
        floatingServiceRunning = false
        drawingWindowCount = 0
        referenceWindowCount = 0
    }
}