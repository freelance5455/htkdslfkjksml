
package com.rajo.art.floating

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class FloatingWindowManager(
    private val context: Context
) {

    private val windowManager =
        context.getSystemService(
            Context.WINDOW_SERVICE
        ) as WindowManager

    private val windows =
        mutableListOf<View>()

    private val paramsMap =
        mutableMapOf<View, WindowManager.LayoutParams>()

    fun addWindow(
        view: View,
        width: Int = 600,
        height: Int = 600
    ) {

        if (windows.contains(view)) {
            return
        }

        val type =
            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O
            ) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

        val params =
            WindowManager.LayoutParams(
                width,
                height,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )

        params.gravity =
            Gravity.TOP or Gravity.START

        params.x = 50 + (windows.size * 40)
        params.y = 150 + (windows.size * 40)

        try {

            windowManager.addView(
                view,
                params
            )

            windows.add(view)
            paramsMap[view] = params

        } catch (_: Exception) {
        }
    }

    fun moveWindow(
        view: View,
        dx: Int,
        dy: Int
    ) {

        val params =
            paramsMap[view]
                ?: return

        params.x += dx
        params.y += dy

        update(view, params)
    }

    fun resizeWindow(
        view: View,
        width: Int,
        height: Int
    ) {

        val params =
            paramsMap[view]
                ?: return

        params.width =
            width.coerceAtLeast(250)

        params.height =
            height.coerceAtLeast(200)

        update(view, params)
    }

    fun minimizeWindow(
        view: View
    ) {

        val params =
            paramsMap[view]
                ?: return

        params.width = 220
        params.height = 90

        update(view, params)
    }

    fun maximizeWindow(
        view: View
    ) {

        val metrics =
            context.resources.displayMetrics

        val width =
            (metrics.widthPixels * 0.92f)
                .toInt()

        val height =
            (metrics.heightPixels * 0.70f)
                .toInt()

        val params =
            paramsMap[view]
                ?: return

        params.width = width
        params.height = height

        params.x = 20
        params.y = 100

        update(view, params)
    }

    private fun update(
        view: View,
        params: WindowManager.LayoutParams
    ) {

        try {

            windowManager.updateViewLayout(
                view,
                params
            )

        } catch (_: Exception) {
        }
    }

    fun removeWindow(
        view: View
    ) {

        try {

            windowManager.removeView(view)

        } catch (_: Exception) {
        }

        windows.remove(view)
        paramsMap.remove(view)
    }

    fun removeAllWindows() {

        windows.toList().forEach { view ->

            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
            }
        }

        windows.clear()
        paramsMap.clear()
    }

    fun getWindowCount(): Int {
        return windows.size
    }

    fun getWindows(): List<View> {
        return windows.toList()
    }

    fun isOpen(view: View): Boolean {
        return windows.contains(view)
    }
}