package com.rajo.art.floating

import android.view.MotionEvent
import android.view.View

class FloatingWindowController(
    private val manager: FloatingWindowManager
) {

    fun attachDrag(
        window: View,
        dragHandle: View
    ) {

        var startX = 0
        var startY = 0

        var touchX = 0f
        var touchY = 0f

        dragHandle.setOnTouchListener { _, event ->

            when (event.actionMasked) {

                MotionEvent.ACTION_DOWN -> {

                    startX = window.x.toInt()
                    startY = window.y.toInt()

                    touchX = event.rawX
                    touchY = event.rawY

                    true
                }

                MotionEvent.ACTION_MOVE -> {

                    val dx =
                        (event.rawX - touchX).toInt()

                    val dy =
                        (event.rawY - touchY).toInt()

                    manager.moveWindow(
                        window,
                        dx,
                        dy
                    )

                    touchX = event.rawX
                    touchY = event.rawY

                    true
                }

                MotionEvent.ACTION_UP -> {
                    true
                }

                else -> false
            }
        }
    }

    fun minimize(
        window: View
    ) {
        manager.minimizeWindow(window)
    }

    fun maximize(
        window: View
    ) {
        manager.maximizeWindow(window)
    }

    fun resize(
        window: View,
        width: Int,
        height: Int
    ) {
        manager.resizeWindow(
            window,
            width,
            height
        )
    }

    fun close(
        window: View
    ) {
        manager.removeWindow(window)
    }
}