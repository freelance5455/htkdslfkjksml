package com.rajo.art

import android.app.Application

class RajoArtApplication : Application() {

    override fun onCreate() {
        super.onCreate()
    }
}