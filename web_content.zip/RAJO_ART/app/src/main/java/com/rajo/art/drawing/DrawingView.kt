package com.rajo.art.drawing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paths = mutableListOf<DrawPath>()
    private val undonePaths = mutableListOf<DrawPath>()

    private var currentPath: Path? = null

    private var brushColor = Color.WHITE
    private var brushSize = 8f
    private var eraserEnabled = false

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.drawColor(Color.TRANSPARENT)

        paths.forEach { drawPath ->
            canvas.drawPath(
                drawPath.path,
                drawPath.paint
            )
        }

        currentPath?.let { path ->
            canvas.drawPath(
                path,
                createPaint()
            )
        }
    }

    override fun onTouchEvent(
        event: MotionEvent
    ): Boolean {

        val x = event.x
        val y = event.y

        when (event.actionMasked) {

            MotionEvent.ACTION_DOWN -> {

                currentPath = Path().apply {
                    moveTo(x, y)
                }

                undonePaths.clear()

                invalidate()

                return true
            }

            MotionEvent.ACTION_MOVE -> {

                currentPath?.lineTo(
                    x,
                    y
                )

                invalidate()

                return true
            }

            MotionEvent.ACTION_UP -> {

                currentPath?.let { path ->

                    paths.add(
                        DrawPath(
                            path = path,
                            paint = createPaint()
                        )
                    )
                }

                currentPath = null

                invalidate()

                return true
            }
        }

        return true
    }

    private fun createPaint(): Paint {

        return Paint(
            Paint.ANTI_ALIAS_FLAG
        ).apply {

            color = brushColor

            strokeWidth = brushSize

            style = Paint.Style.STROKE

            strokeCap =
                Paint.Cap.ROUND

            strokeJoin =
                Paint.Join.ROUND

            if (eraserEnabled) {

                xfermode =
                    PorterDuffXfermode(
                        PorterDuff.Mode.CLEAR
                    )
            }
        }
    }

    fun setBrushColor(
        color: Int
    ) {

        brushColor = color

        eraserEnabled = false

        invalidate()
    }

    fun setBrushSize(
        size: Float
    ) {

        brushSize =
            size.coerceIn(
                1f,
                100f
            )

        invalidate()
    }

    fun enableEraser(
        enabled: Boolean
    ) {

        eraserEnabled = enabled

        invalidate()
    }

    fun undo() {

        if (paths.isNotEmpty()) {

            undonePaths.add(
                paths.removeAt(
                    paths.lastIndex
                )
            )

            invalidate()
        }
    }

    fun redo() {

        if (undonePaths.isNotEmpty()) {

            paths.add(
                undonePaths.removeAt(
                    undonePaths.lastIndex
                )
            )

            invalidate()
        }
    }

    fun clearDrawing() {

        paths.clear()

        undonePaths.clear()

        currentPath = null

        invalidate()
    }

    fun exportBitmap(): Bitmap {

        val bitmap =
            Bitmap.createBitmap(
                width.coerceAtLeast(1),
                height.coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )

        val canvas =
            Canvas(bitmap)

        draw(canvas)

        return bitmap
    }

    private data class DrawPath(
        val path: Path,
        val paint: Paint
    )
}