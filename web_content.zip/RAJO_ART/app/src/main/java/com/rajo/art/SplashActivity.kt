package com.rajo.art

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.rajo.art.protection.IntegrityChecker

class SplashActivity : AppCompatActivity() {

    private val splashDelay = 1200L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*
         * فحص سلامة التطبيق قبل تشغيله.
         */
        if (!IntegrityChecker.isAppValid(this)) {
            finishAffinity()
            return
        }

        setContentView(R.layout.activity_main)

        Handler(Looper.getMainLooper()).postDelayed({
            openNextScreen()
        }, splashDelay)
    }

    private fun openNextScreen() {
        val preferences =
            getSharedPreferences("rajo_art_prefs", MODE_PRIVATE)

        val welcomeSeen =
            preferences.getBoolean("welcome_seen", false)

        val countrySelected =
            preferences.getBoolean("country_selected", false)

        val nextIntent = when {
            !welcomeSeen ->
                Intent(this, WelcomeActivity::class.java)

            !countrySelected ->
                Intent(this, CountryActivity::class.java)

            else ->
                Intent(this, HomeActivity::class.java)
        }

        startActivity(nextIntent)
        finish()
    }
}