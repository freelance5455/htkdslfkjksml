package com.rajo.art.drawing

import android.content.Context
import android.graphics.Color
import android.view.ViewGroup
import android.widget.LinearLayout
import com.google.android.material.button.MaterialButton

class DrawingEditor(
    private val context: Context,
    private val drawingView: DrawingView
) {

    fun createToolbar(): LinearLayout {

        val toolbar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
        }

        toolbar.addView(
            createButton("قلم") {
                drawingView.enableEraser(false)
            }
        )

        toolbar.addView(
            createButton("ممحاة") {
                drawingView.enableEraser(true)
            }
        )

        toolbar.addView(
            createButton("تراجع") {
                drawingView.undo()
            }
        )

        toolbar.addView(
            createButton("إعادة") {
                drawingView.redo()
            }
        )

        toolbar.addView(
            createButton("مسح الكل") {
                drawingView.clearDrawing()
            }
        )

        toolbar.addView(
            createButton("أبيض") {
                drawingView.setBrushColor(Color.WHITE)
            }
        )

        toolbar.addView(
            createButton("أسود") {
                drawingView.setBrushColor(Color.BLACK)
            }
        )

        toolbar.addView(
            createButton("أحمر") {
                drawingView.setBrushColor(Color.RED)
            }
        )

        toolbar.addView(
            createButton("أزرق") {
                drawingView.setBrushColor(Color.BLUE)
            }
        )

        toolbar.addView(
            createButton("أخضر") {
                drawingView.setBrushColor(Color.GREEN)
            }
        )

        toolbar.addView(
            createButton("صغير") {
                drawingView.setBrushSize(4f)
            }
        )

        toolbar.addView(
            createButton("متوسط") {
                drawingView.setBrushSize(10f)
            }
        )

        toolbar.addView(
            createButton("كبير") {
                drawingView.setBrushSize(20f)
            }
        )

        return toolbar
    }

    fun setColor(color: Int) {
        drawingView.setBrushColor(color)
    }

    fun setBrushSize(size: Float) {
        drawingView.setBrushSize(size)
    }

    fun setWhiteColor() {
        setColor(Color.WHITE)
    }

    fun setBlackColor() {
        setColor(Color.BLACK)
    }

    fun setRedColor() {
        setColor(Color.RED)
    }

    fun setBlueColor() {
        setColor(Color.BLUE)
    }

    private fun createButton(
        text: String,
        action: () -> Unit
    ): MaterialButton {

        return MaterialButton(context).apply {

            this.text = text

            layoutParams =
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(
                        4,
                        0,
                        4,
                        0
                    )
                }

            setOnClickListener {
                action()
            }
        }
    }
}