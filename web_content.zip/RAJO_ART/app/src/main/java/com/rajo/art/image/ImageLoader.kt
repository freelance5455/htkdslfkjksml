package com.rajo.art.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

object ImageLoader {

    fun load(
        context: Context,
        uri: Uri
    ): Bitmap? {

        return try {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {

                val source =
                    ImageDecoder.createSource(
                        context.contentResolver,
                        uri
                    )

                ImageDecoder.decodeBitmap(source)

            } else {

                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(
                    context.contentResolver,
                    uri
                )
            }

        } catch (_: Exception) {
            null
        }
    }
}