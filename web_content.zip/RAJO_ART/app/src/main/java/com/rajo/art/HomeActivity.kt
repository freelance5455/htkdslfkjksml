<?xml version="1.0" encoding="utf-8"?>

<ScrollView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/rajo_black"
    android:fillViewport="true">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="20dp"
        android:gravity="center_horizontal">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:text="@string/app_name"
            android:textColor="@color/rajo_white"
            android:textSize="30sp"
            android:textStyle="bold"/>

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:text="@string/drawings_list"
            android:textColor="@color/rajo_text_secondary"
            android:textSize="17sp"
            android:gravity="center"/>

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btnDrawingsList"
            android:layout_width="match_parent"
            android:layout_height="56dp"
            android:layout_marginTop="24dp"
            android:text="@string/drawings_list"
            android:textAllCaps="false"
            android:textSize="16sp"/>

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btnDrawing"
            android:layout_width="match_parent"
            android:layout_height="56dp"
            android:layout_marginTop="12dp"
            android:text="🎨  محرر الرسم"
            android:textAllCaps="false"
            android:textSize="16sp"/>

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btnPinterest"
            android:layout_width="match_parent"
            android:layout_height="56dp"
            android:layout_marginTop="12dp"
            android:text="@string/open_pinterest"
            android:textAllCaps="false"
            android:textSize="16sp"/>

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btnAbout"
            android:layout_width="match_parent"
            android:layout_height="56dp"
            android:layout_marginTop="12dp"
            android:text="👤  المطور والحقوق"
            android:textAllCaps="false"
            android:textSize="16sp"/>

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="32dp"
            android:text="أدوات RAJO ART"
            android:textColor="@color/rajo_white"
            android:textSize="20sp"
            android:textStyle="bold"
            android:gravity="center"/>

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="10dp"
            android:text="الرسم • حفظ الصور • الصور المرجعية • النوافذ العائمة"
            android:textColor="@color/rajo_text_secondary"
            android:textSize="14sp"
            android:gravity="center"/>

    </LinearLayout>

</ScrollView>