package com.rajo.art.drawing

import android.widget.SeekBar
import android.widget.TextView

class ImageOpacityController(
    private val manager: ImageLayerManager,
    private val label: TextView
) {

    fun attach(
        seekBar: SeekBar
    ) {

        seekBar.max = 100
        seekBar.progress = 100

        updateLabel(100)

        seekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {

                    val value =
                        progress.coerceIn(
                            0,
                            100
                        )

                    manager.setOpacity(
                        value / 100f
                    )

                    updateLabel(value)
                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) {
                }

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) {
                }
            }
        )
    }

    private fun updateLabel(
        value: Int
    ) {

        label.text =
            "شفافية الصورة: $value%"
    }
}