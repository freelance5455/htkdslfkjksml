package com.rajo.art

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        findViewById<MaterialButton>(R.id.btnTelegram).setOnClickListener {
            openTelegram()
        }

        findViewById<MaterialButton>(R.id.btnRate).setOnClickListener {
            openRating()
        }
    }

    private fun openTelegram() {
        try {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://t.me/NN3RB")
                )
            )
        } catch (_: Exception) {
            Toast.makeText(
                this,
                "تعذر فتح قناة التليجرام",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun openRating() {
        val packageName = packageName

        try {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=$packageName")
                )
            )
        } catch (_: Exception) {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(
                            "https://play.google.com/store/apps/details?id=$packageName"
                        )
                    )
                )
            } catch (_: Exception) {
                Toast.makeText(
                    this,
                    "تعذر فتح صفحة التطبيق",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}