package com.rajo.art.protection

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

object IntegrityChecker {

    /*
     * بعد أول Build رسمي للنسخة الأصلية،
     * نضع بصمة شهادة توقيع APK هنا.
     *
     * حالياً اتركها فارغة حتى نستخرج البصمة الأصلية.
     */
    private const val OFFICIAL_CERT_SHA256 = ""

    /*
     * حقوق التطبيق التي يجب أن تبقى موجودة.
     */
    private const val OFFICIAL_DEVELOPER = "راجو"
    private const val OFFICIAL_TELEGRAM = "@NN3RB"

    fun isAppValid(context: Context): Boolean {
        return try {
            checkCertificate(context) &&
                    checkProtectedRights(context)
        } catch (_: Exception) {
            false
        }
    }

    private fun checkCertificate(context: Context): Boolean {
        /*
         * أثناء التطوير، لا نوقف التطبيق لأن البصمة لم تُحدد بعد.
         */
        if (OFFICIAL_CERT_SHA256.isBlank()) {
            return true
        }

        val packageManager = context.packageManager

        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = packageManager.getPackageInfo(
                context.packageName,
                PackageManager.GET_SIGNING_CERTIFICATES
            )
            info.signingInfo?.apkContentsSigners
        } else {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(
                context.packageName,
                PackageManager.GET_SIGNATURES
            ).signatures
        }

        if (signatures.isNullOrEmpty()) {
            return false
        }

        return signatures.any { signature ->
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(signature.toByteArray())

            val current = digest.joinToString("") {
                "%02X".format(it)
            }

            current.equals(OFFICIAL_CERT_SHA256, ignoreCase = true)
        }
    }

    private fun checkProtectedRights(context: Context): Boolean {
        val developer =
            context.getString(com.rajo.art.R.string.welcome_developed)

        val telegram =
            context.getString(com.rajo.art.R.string.telegram_username)

        return developer.contains(OFFICIAL_DEVELOPER) &&
                telegram == OFFICIAL_TELEGRAM
    }
}