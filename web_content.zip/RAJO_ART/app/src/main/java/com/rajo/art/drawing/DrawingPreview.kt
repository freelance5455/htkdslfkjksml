package com.rajo.art.drawing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class DrawingPreview @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var bitmap: Bitmap? = null

    private val paint = Paint(
        Paint.ANTI_ALIAS_FLAG or
            Paint.FILTER_BITMAP_FLAG
    )

    fun setBitmap(newBitmap: Bitmap?) {
        bitmap = newBitmap
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.drawColor(
            android.graphics.Color.BLACK
        )

        val currentBitmap = bitmap ?: return

        val scale = minOf(
            width.toFloat() / currentBitmap.width,
            height.toFloat() / currentBitmap.height
        )

        val scaledWidth =
            currentBitmap.width * scale

        val scaledHeight =
            currentBitmap.height * scale

        val left =
            (width - scaledWidth) / 2f

        val top =
            (height - scaledHeight) / 2f

        canvas.drawBitmap(
            currentBitmap,
            null,
            android.graphics.RectF(
                left,
                top,
                left + scaledWidth,
                top + scaledHeight
            ),
            paint
        )
    }
}