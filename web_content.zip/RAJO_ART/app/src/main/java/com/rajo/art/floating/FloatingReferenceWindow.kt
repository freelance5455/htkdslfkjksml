package com.rajo.art.floating

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.rajo.art.image.ImageLoader

class FloatingReferenceWindow(
    private val context: Context
) {

    private val windowManager =
        context.getSystemService(
            Context.WINDOW_SERVICE
        ) as WindowManager

    private var root: LinearLayout? = null
    private var imageView: ImageView? = null
    private var params: WindowManager.LayoutParams? = null

    private var currentWidth = 580
    private var currentHeight = 680

    fun show() {

        if (root != null) return

        val container =
            LinearLayout(context).apply {

                orientation =
                    LinearLayout.VERTICAL

                setPadding(
                    8,
                    8,
                    8,
                    8
                )

                background =
                    GradientDrawable().apply {

                        setColor(
                            Color.rgb(
                                5,
                                7,
                                10
                            )
                        )

                        cornerRadius = 24f

                        setStroke(
                            2,
                            Color.rgb(
                                33,
                                150,
                                243
                            )
                        )
                    }
            }

        val header =
            LinearLayout(context).apply {

                orientation =
                    LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER_VERTICAL
            }

        val title =
            TextView(context).apply {

                text =
                    "الصورة المرجعية"

                textSize =
                    14f

                setTextColor(
                    Color.WHITE
                )

                gravity =
                    Gravity.CENTER_VERTICAL

                layoutParams =
                    LinearLayout.LayoutParams(
                        0,
                        48
                    ).apply {
                        weight = 1f
                    }
            }

        val zoomOut =
            createButton("−") {
                resizeBy(0.87f)
            }

        val zoomIn =
            createButton("+") {
                resizeBy(1.15f)
            }

        val reset =
            createButton("↺") {
                resetSize()
            }

        val choose =
            createButton("🖼") {
                openImagePicker()
            }

        val close =
            createButton("×") {
                hide()
            }

        header.addView(title)
        header.addView(zoomOut)
        header.addView(zoomIn)
        header.addView(reset)
        header.addView(choose)
        header.addView(close)

        container.addView(header)

        val image =
            ImageView(context).apply {

                layoutParams =
                    LinearLayout.LayoutParams(
                        550,
                        550
                    )

                scaleType =
                    ImageView.ScaleType.FIT_CENTER

                setBackgroundColor(
                    Color.rgb(
                        15,
                        20,
                        28
                    )
                )

                contentDescription =
                    "الصورة المرجعية"
            }

        container.addView(image)

        imageView =
            image

        val type =
            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O
            ) {

                WindowManager.LayoutParams
                    .TYPE_APPLICATION_OVERLAY

            } else {

                @Suppress("DEPRECATION")
                WindowManager.LayoutParams
                    .TYPE_PHONE
            }

        val windowParams =
            WindowManager.LayoutParams(
                currentWidth,
                currentHeight,
                type,
                WindowManager.LayoutParams
                    .FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )

        windowParams.gravity =
            Gravity.TOP or Gravity.START

        windowParams.x =
            80

        windowParams.y =
            180

        try {

            windowManager.addView(
                container,
                windowParams
            )

            root =
                container

            params =
                windowParams

            FloatingImageStore.setListener { uri ->

                setImageUri(uri)

            }

            FloatingImageStore
                .getUri()
                ?.let { uri ->

                    setImageUri(uri)

                }

        } catch (_: Exception) {

            return
        }

        attachDragging(
            container,
            header,
            windowParams
        )
    }

    private fun createButton(
        text: String,
        action: () -> Unit
    ): TextView {

        return TextView(context).apply {

            this.text =
                text

            textSize =
                18f

            setTextColor(
                Color.WHITE
            )

            gravity =
                Gravity.CENTER

            setPadding(
                12,
                0,
                12,
                0
            )

            setOnClickListener {
                action()
            }
        }
    }

    private fun openImagePicker() {

        val intent =
            Intent(
                context,
                FloatingImagePickerActivity::class.java
            )

        intent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
        )

        context.startActivity(
            intent
        )
    }

    private fun resizeBy(
        factor: Float
    ) {

        val windowParams =
            params ?: return

        currentWidth =
            (
                currentWidth * factor
                )
                .toInt()
                .coerceIn(
                    300,
                    getMaxWidth()
                )

        currentHeight =
            (
                currentHeight * factor
                )
                .toInt()
                .coerceIn(
                    250,
                    getMaxHeight()
                )

        windowParams.width =
            currentWidth

        windowParams.height =
            currentHeight

        val currentRoot =
            root ?: return

        try {

            windowManager.updateViewLayout(
                currentRoot,
                windowParams
            )

        } catch (_: Exception) {
        }
    }

    private fun resetSize() {

        currentWidth =
            580

        currentHeight =
            680

        val windowParams =
            params ?: return

        windowParams.width =
            currentWidth

        windowParams.height =
            currentHeight

        val currentRoot =
            root ?: return

        try {

            windowManager.updateViewLayout(
                currentRoot,
                windowParams
            )

        } catch (_: Exception) {
        }
    }

    private fun getMaxWidth(): Int {

        return (
            context.resources
                .displayMetrics
                .widthPixels * 0.95f
            ).toInt()
    }

    private fun getMaxHeight(): Int {

        return (
            context.resources
                .displayMetrics
                .heightPixels * 0.80f
            ).toInt()
    }

    private fun attachDragging(
        window: View,
        handle: View,
        windowParams: WindowManager.LayoutParams
    ) {

        var startX =
            windowParams.x

        var startY =
            windowParams.y

        var touchX =
            0f

        var touchY =
            0f

        handle.setOnTouchListener { _, event ->

            when (
                event.actionMasked
            ) {

                MotionEvent.ACTION_DOWN -> {

                    startX =
                        windowParams.x

                    startY =
                        windowParams.y

                    touchX =
                        event.rawX

                    touchY =
                        event.rawY

                    true
                }

                MotionEvent.ACTION_MOVE -> {

                    windowParams.x =
                        startX +
                            (
                                event.rawX -
                                    touchX
                                ).toInt()

                    windowParams.y =
                        startY +
                            (
                                event.rawY -
                                    touchY
                                ).toInt()

                    try {

                        windowManager
                            .updateViewLayout(
                                window,
                                windowParams
                            )

                    } catch (_: Exception) {
                    }

                    true
                }

                else -> false
            }
        }
    }

    fun setBitmap(
        bitmap: Bitmap
    ) {

        imageView?.setImageBitmap(
            bitmap
        )
    }

    fun setImageUri(
        uri: Uri
    ) {

        val bitmap =
            ImageLoader.load(
                context,
                uri
            )

        if (bitmap != null) {

            setBitmap(
                bitmap
            )
        }
    }

    fun hide() {

        val currentRoot =
            root

        if (currentRoot != null) {

            try {

                windowManager.removeView(
                    currentRoot
                )

            } catch (_: Exception) {
            }
        }

        root =
            null

        imageView =
            null

        params =
            null
    }
}