package com.rajo.art.floating

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object NotificationPermissionHelper {

    const val REQUEST_CODE = 7001

    fun isGranted(
        activity: Activity
    ): Boolean {

        if (Build.VERSION.SDK_INT < 33) {
            return true
        }

        return ContextCompat.checkSelfPermission(
            activity,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun request(
        activity: Activity
    ) {

        if (Build.VERSION.SDK_INT < 33) {
            return
        }

        if (!isGranted(activity)) {

            ActivityCompat.requestPermissions(
                activity,
                arrayOf(
                    Manifest.permission.POST_NOTIFICATIONS
                ),
                REQUEST_CODE
            )
        }
    }
}