package com.rajo.art.data

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.rajo.art.R

class DrawingAdapter(
    private var items: List<DrawingItem>,
    private val onClick: (DrawingItem) -> Unit
) : RecyclerView.Adapter<DrawingAdapter.DrawingViewHolder>() {

    class DrawingViewHolder(
        private val button: MaterialButton
    ) : RecyclerView.ViewHolder(button) {

        fun bind(
            item: DrawingItem,
            onClick: (DrawingItem) -> Unit
        ) {
            button.text = item.title
            button.setOnClickListener {
                onClick(item)
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): DrawingViewHolder {

        val button = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_drawing,
                parent,
                false
            ) as MaterialButton

        return DrawingViewHolder(button)
    }

    override fun onBindViewHolder(
        holder: DrawingViewHolder,
        position: Int
    ) {
        holder.bind(items[position], onClick)
    }

    override fun getItemCount(): Int = items.size

    fun updateItems(newItems: List<DrawingItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}