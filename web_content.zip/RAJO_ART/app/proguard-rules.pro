# RAJO ART - R8 / ProGuard Rules

# Keep Application class
-keep class com.rajo.art.RajoArtApplication { *; }

# Keep Activities
-keep class com.rajo.art.MainActivity { *; }

# Keep custom Views
-keep class com.rajo.art.** extends android.view.View { *; }

# Keep Services
-keep class com.rajo.art.** extends android.app.Service { *; }

# Keep Parcelable / Serializable classes
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}

-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
}

# Keep Material / AndroidX annotations
-keepattributes *Annotation*

# Keep generic signatures
-keepattributes Signature