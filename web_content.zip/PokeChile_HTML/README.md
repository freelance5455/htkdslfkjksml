# PokeChile — versión HTML/CSS/JavaScript

Esta carpeta contiene una web estática: `index.html`, `styles.css`, `app.js` y `manifest.json`.

## API integrada

Usa [API TCG / APITCG](https://docs.apitcg.com/) con la búsqueda `GET https://api.apitcg.com/api/products?tcg=pokemon&type=card&name=...&limit=24`, el detalle `GET /api/products/{id}` y la cabecera `x-api-key`. Los precios de mercado provienen de `markets.tcgplayer.prices` y están en USD.

En Ajustes puedes introducir tu API key. Para esta demo se guarda en `localStorage`, por lo que **no es seguro para una web pública ni una APK distribuida**: las personas podrían extraer la clave. Para producción, coloca un backend/proxy entre la app y APITCG. La clave compartida anteriormente debe regenerarse desde [APITCG API Key](https://apitcg.com/platform/api-key).

La conversión de USD a CLP usa una tasa ilustrativa `USD_CLP=950` en `app.js`; cámbiala por una tasa actual antes de publicar. No es precio de tiendas chilenas. La documentación de APITCG no indica un parámetro para filtrar por idioma, así que el selector es orientativo y conviene buscar el nombre en el idioma deseado.

## Abrir y convertir a APK

Abre `index.html` en un navegador o sirve la carpeta por HTTPS/servidor local. Para crear un APK real, envuelve la web con Capacitor o Android WebView y compílala con Android Studio. Este ZIP contiene la web, no un APK compilado.
