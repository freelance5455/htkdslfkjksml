// PokeChile — integración con API TCG (https://docs.apitcg.com/)
// La API publica precios internacionales en USD. Tipo de cambio referencial editable, no cotización en vivo.
const API_BASE='https://api.apitcg.com/api';
const USD_CLP=950;
let language='English',cards=[],saved=JSON.parse(localStorage.getItem('pokechile_saved')||'[]');
const $=id=>document.getElementById(id);
const key=()=>localStorage.getItem('pokechile_api_key')||'';
function updateSavedCount(){$('savedCount').textContent=saved.length}
function setStatus(message){const el=$('status');el.textContent=message;el.classList.toggle('hidden',!message)}
function showTab(tab){
 document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 $('explorePanel').classList.toggle('hidden',tab!=='explore');$('collectionPanel').classList.toggle('hidden',tab!=='collection');$('settingsPanel').classList.toggle('hidden',tab!=='settings');
 $('resultsTitle').parentElement.parentElement.classList.toggle('hidden',tab!=='explore');$('results').classList.toggle('hidden',tab!=='explore');
 $('emptyHint').classList.toggle('hidden',tab!=='explore'||cards.length>0);
 if(tab==='collection')renderCollection();if(tab==='settings')$('apiKey').value=key();
}
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
$('settingsBtn').addEventListener('click',()=>showTab('settings'));
document.querySelectorAll('.language').forEach(b=>b.addEventListener('click',()=>{
 language=b.dataset.lang;document.querySelectorAll('.language').forEach(x=>{x.classList.toggle('selected',x===b);x.querySelector('span').textContent=x===b?'✓':''});
 setStatus('Idioma elegido: '+(language==='English'?'inglés':'español')+'. La API TCG no documenta un filtro de idioma; prueba el nombre de la carta en el idioma deseado.');
}));
document.querySelectorAll('[data-query]').forEach(b=>b.addEventListener('click',()=>{$('query').value=b.dataset.query;searchCards()}));
$('searchForm').addEventListener('submit',e=>{e.preventDefault();searchCards()});
$('apiForm').addEventListener('submit',e=>{e.preventDefault();const v=$('apiKey').value.trim();if(v)localStorage.setItem('pokechile_api_key',v);else localStorage.removeItem('pokechile_api_key');alert('Configuración guardada en este navegador.');showTab('explore')});
async function api(path){
 const r=await fetch(`${API_BASE}${path}`,{headers:{'x-api-key':key(),Accept:'application/json'}});
 if(!r.ok){if(r.status===401)throw new Error('API key inválida o ausente. Revisa tu clave en APITCG.');if(r.status===429)throw new Error('Límite de solicitudes alcanzado. Revisa tu plan de APITCG.');throw new Error(`APITCG respondió ${r.status}.`)}
 return r.json();
}
function productId(c){return c?._id??c?.id??c?.productId}
function productImage(c){const i=c?.images;if(typeof i==='string')return i;if(Array.isArray(i))return i[0]?.large||i[0]?.small||i[0]?.url||'';return i?.large||i?.small||i?.medium||i?.url||c?.image||''}
function setName(c){return typeof c?.set==='string'?c.set:(c?.set?.name||c?.set?._id||'Pokémon TCG')}
function cardNumber(c){return c?.attributes?.Number||c?.attributes?.number||c?.number||c?.cardNumber||'—'}
async function searchCards(){
 const q=$('query').value.trim();if(!q)return;
 if(!key()){setStatus('Conecta tu API key de APITCG desde Ajustes para buscar cartas.');$('emptyHint').classList.add('hidden');return}
 setStatus('Buscando cartas…');$('results').innerHTML='';$('emptyHint').classList.add('hidden');
 try{
  const d=await api(`/products?tcg=pokemon&type=card&name=${encodeURIComponent(q)}&limit=24`);
  cards=Array.isArray(d)?d:(d.data||d.products||d.results||[]);
  if(!cards.length){setStatus('No encontramos cartas. Prueba otro nombre.');return}
  setStatus('');$('resultsTitle').textContent='Resultados';$('resultsSub').textContent=`${cards.length} cartas · datos de APITCG`;
  renderCards(cards,$('results'));$('emptyHint').classList.add('hidden');
 }catch(e){setStatus(`${e.message} Comprueba tu conexión y la documentación de APITCG.`)}
}
function renderCards(list,container){
 container.innerHTML='';
 list.forEach(c=>{
  const id=productId(c);const card=document.createElement('article');card.className='card';
  const art=document.createElement('div');art.className='card-art';const src=productImage(c);
  if(src){const img=document.createElement('img');img.src=src;img.alt=c.name||'Carta Pokémon';img.loading='lazy';img.onerror=()=>{img.remove();art.insertAdjacentHTML('afterbegin','<span style="color:#95a4bc">Pokémon TCG</span>')};art.append(img)}
  else art.innerHTML='<span style="color:#95a4bc">Pokémon TCG</span>';
  const save=document.createElement('button');save.className='save';save.textContent=saved.some(x=>String(productId(x))===String(id))?'★':'＋';save.setAttribute('aria-label','Guardar carta');save.addEventListener('click',()=>toggleSave(c));art.append(save);
  const title=document.createElement('h3');title.textContent=c.name||'Carta Pokémon';
  const meta=document.createElement('div');meta.className='card-meta';meta.textContent=`${setName(c)} · #${cardNumber(c)}`;
  const price=document.createElement('button');price.className='price-btn';price.textContent='♢  Ver precio CLP';price.addEventListener('click',()=>getPrice(c));
  card.append(art,title,meta,price);container.append(card);
 });
}
function toggleSave(c){
 const id=productId(c);const i=saved.findIndex(x=>String(productId(x))===String(id));if(i>=0)saved.splice(i,1);else saved.push(c);
 localStorage.setItem('pokechile_saved',JSON.stringify(saved));updateSavedCount();renderCards(cards,$('results'));renderCollection();
}
function renderCollection(){$('collectionGrid').innerHTML='';$('collectionEmpty').classList.toggle('hidden',saved.length>0);renderCards(saved,$('collectionGrid'))}
function clp(value){return Number(value).toLocaleString('es-CL',{style:'currency',currency:'CLP',maximumFractionDigits:0})}
async function getPrice(c){
 if(!key()){alert('Primero conecta tu API key de APITCG en Ajustes.');return}
 try{
  const id=productId(c);let product=c;
  if(id!==undefined){const d=await api(`/products/${encodeURIComponent(id)}`);product=d.data||d.product||d}
  const market=product?.markets?.tcgplayer;const prices=market?.prices||{};const printings=Array.isArray(market?.printings)?market.printings:[];
  const lines=[];
  if(prices.market!=null)lines.push(`Precio de mercado: ${clp(prices.market*USD_CLP)} CLP (US$ ${Number(prices.market).toFixed(2)})`);
  if(prices.low!=null)lines.push(`Mínimo: ${clp(prices.low*USD_CLP)} CLP`);
  if(prices.mid!=null)lines.push(`Mediana: ${clp(prices.mid*USD_CLP)} CLP`);
  if(prices.high!=null)lines.push(`Máximo: ${clp(prices.high*USD_CLP)} CLP`);
  if(printings.length){lines.push('');lines.push('Por impresión:');printings.forEach(p=>{const v=p.prices?.market;lines.push(`${p.subTypeName||'Impresión'}: ${v==null?'sin precio':clp(v*USD_CLP)+' CLP'}`)})}
  $('modalTitle').textContent=product.name||c.name;$('modalBody').textContent=`${setName(product)} · #${cardNumber(product)}\n\n${lines.join('\n')||'APITCG no entregó un precio de mercado para esta carta.'}\n\nFuente: TCGplayer vía APITCG. Conversión aproximada usando $${USD_CLP} CLP por USD; no es una cotización en vivo ni un precio de tienda chilena.`;
  $('priceModal').classList.remove('hidden');
 }catch(e){alert(`${e.message}\nComprueba los detalles en la documentación de APITCG.`)}
}
$('closeModal').addEventListener('click',()=>$('priceModal').classList.add('hidden'));
$('priceModal').addEventListener('click',e=>{if(e.target===$('priceModal'))$('priceModal').classList.add('hidden')});
updateSavedCount();
