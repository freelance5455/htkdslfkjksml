var API_BASE = "https://gamesite-river-7f77.nunu125125nunu.workers.dev/api/games";
var CATEGORIES = ["All","Kids Game","Survival Game","Horror Game","18+ Game","Minecraft"];
var MOD_API_BASE = "https://min-union-2505.naw125125naw.workers.dev/api";
function gameTitle(g){ return g.title || g.name || "Untitled"; }
function gameIcon(g){ return g.icon || g.icon_url || ""; }
function gameDownloads(g){ var v = g.total_downloads != null ? g.total_downloads : (g.download_count != null ? g.download_count : g.downloads); return v == null ? 0 : v; }
function gameDeveloper(g){ return g.developer || g.developer_name || "Unknown developer"; }
function gameScreenshots(g){
  var s = g.screenshots;
  if (Array.isArray(s)) return s;
  if (typeof s === "string") { try { var p = JSON.parse(s); return Array.isArray(p) ? p : []; } catch(e) { return s.split(",").map(function(x){return x.trim();}).filter(Boolean); } }
  return [];
}
function unwrap(d){
  if (Array.isArray(d)) return d;
  if (d && typeof d === "object") { var k=["games","data","results"]; for (var i=0;i<k.length;i++) if (Array.isArray(d[k[i]])) return d[k[i]]; }
  return [];
}
function fetchGames(category, search){
  var url = new URL(API_BASE);
  if (category && category !== "All") url.searchParams.set("category", category);
  if (search) url.searchParams.set("search", search);
  return fetch(url.toString()).then(function(r){ if(!r.ok) throw new Error("Failed"); return r.json(); }).then(unwrap);
}
function fetchGame(id){
  return fetch(API_BASE + "/" + id).then(function(r){ if(!r.ok) throw new Error("Not found"); return r.json(); })
    .then(function(d){ return (d && typeof d === "object" && d.game) ? d.game : d; });
}
function incrementDownload(id){ try { return fetch(API_BASE + "/" + id + "/download", { method: "POST" }); } catch(e) { return Promise.resolve(); } }
function qsId(){ return new URLSearchParams(location.search).get("id") || ""; }

/* ---------- Minecraft mods (CraftStore data, OMNi UI) ---------- */
function unwrapMods(d){
  if (Array.isArray(d)) return d;
  if (d && typeof d === "object") { var k=["mods","data","results"]; for (var i=0;i<k.length;i++) if (Array.isArray(d[k[i]])) return d[k[i]]; }
  return [];
}
function fetchMods(search){
  return fetch(MOD_API_BASE + "/mods").then(function(r){ if(!r.ok) throw new Error("Failed"); return r.json(); })
    .then(unwrapMods).then(function(list){
      var t = (search || "").trim().toLowerCase();
      if (!t) return list;
      return list.filter(function(m){
        return String(m.name||"").toLowerCase().indexOf(t) > -1 ||
               String(m.description||"").toLowerCase().indexOf(t) > -1 ||
               String(m.version||"").toLowerCase().indexOf(t) > -1;
      });
    });
}
function fetchMod(id){
  return fetchMods("").then(function(list){
    var m = list.filter(function(x){ return String(x.id) === String(id); })[0];
    if (!m) throw new Error("Not found");
    return m;
  });
}
function modImages(v){
  if (!v) return [];
  if (Array.isArray(v)) return v;
  try { var p = JSON.parse(v); return Array.isArray(p) ? p : [p]; }
  catch(e){ return String(v).split(",").map(function(x){ return x.trim(); }).filter(Boolean); }
}
function incrementModDownload(id){ try { return fetch(MOD_API_BASE + "/download/" + id, { method: "POST" }); } catch(e) { return Promise.resolve(); } }
