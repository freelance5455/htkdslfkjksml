
const API=(localStorage.getItem("LEGAL_API")||"http://127.0.0.1:8000/api").replace(/\/$/,"");
export function token(){return localStorage.getItem("LEGAL_TOKEN")||""}
async function req(path,opts={}){
 const headers={"Content-Type":"application/json",...(opts.headers||{})};
 const t=token(); if(t) headers.Authorization="Bearer "+t;
 const r=await fetch(API+path,{...opts,headers});
 const data=await r.json().catch(()=>({}));
 if(!r.ok) throw new Error(data.detail||"حدث خطأ في الخادم");
 return data;
}
export const register=(username,password)=>req("/register",{method:"POST",body:JSON.stringify({username,password})});
export const login=(username,password)=>req("/login",{method:"POST",body:JSON.stringify({username,password})});
export const logout=()=>req("/logout",{method:"POST"});
export const cases=()=>req("/cases");
export const addCase=(x)=>req("/cases",{method:"POST",body:JSON.stringify(x)});
export const deleteCase=(id)=>req("/cases/"+id,{method:"DELETE"});
export const appointments=()=>req("/appointments");
export const addAppointment=(x)=>req("/appointments",{method:"POST",body:JSON.stringify(x)});
