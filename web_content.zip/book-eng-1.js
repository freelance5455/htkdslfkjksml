/* JOSTECH — MANUEL 10 : ANGLAIS INFORMATIQUE NIVEAU 1 */
registerLessonDetail(10, 1, "eng-1-1-1", {
  title: "Leçon 1 : Essential IT Vocabulary & False Friends",
  duration: "35 min (Manuel complet)",
  objectives: [
    "Maîtriser le vocabulaire fondamental du matériel, du logiciel et des réseaux.",
    "Identifier et éviter les 8 faux-amis les plus pièges en informatique.",
    "Comprendre les verbes d'action courants des interfaces techniques."
  ],
  prerequisites: ["Notions d'anglais général (niveau lycée)."],
  sections: [
    {
      type: "table",
      title: "1. Vocabulaire IT fondamental (Core Vocabulary)",
      headers: ["Terme anglais", "Traduction exacte", "Exemple en contexte"],
      rows: [
        ["Hardware / Software", "Matériel / Logiciel", "RAM is hardware; the OS is software."],
        ["Database / Query", "Base de données / Requête", "Execute a SQL query on the database."],
        ["Bug / Troubleshooting", "Anomalie / Dépannage", "We need troubleshooting for this bug."],
        ["Backup / Restore", "Sauvegarde / Restaurer", "Restore the offline backup safely."],
        ["Bandwidth / Latency", "Bande passante / Latence", "Low latency improves online exams."],
        ["Credentials", "Identifiants (login + mdp)", "Never share your admin credentials."]
      ]
    },
    {
      type: "warning",
      title: "2. Les 8 Faux-Amis (False Friends) à éviter absolument",
      text: "• « Library » = Bibliothèque logicielle (ensemble de fonctions), JAMAIS une librairie (bookshop).\n• « Directory / Folder » = Dossier/Répertoire, PAS un directoire.\n• « Actually » = En fait / En réalité, PAS actuellement (currently).\n• « Eventually » = Finalement / Au bout du compte, PAS éventuellement (possibly).\n• « Resume » (verbe) = Reprendre (ex: Resume download), alors que « Résumé » (nom) = CV.\n• « Support » = Prendre en charge / Compatibilité (ex: Supports offline mode).\n• « Lecture » = Cours magistral universitaire, PAS la lecture (reading)."
    },
    {
      type: "theory",
      title: "3. Verbes d'action fréquents dans les outils (Git, Acode, Linux)",
      text: "Apprenez à reconnaître immédiatement les commandes d'interface : Fetch (aller chercher/récupérer), Parse (analyser syntaxiquement), Deploy (mettre en ligne), Merge (fusionner), Toggle (basculer ON/OFF), Overwrite (écraser un fichier), Prompt (demander à l'utilisateur / instruction IA)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Traduction sans piège de faux-amis",
      question: "Traduisez fidèlement en français technique : « Actually, our software supports this library, so check the root directory and resume the backup. »",
      solution: "« En fait, notre logiciel prend en charge cette bibliothèque, donc vérifiez le dossier racine et reprenez la sauvegarde. »"
    },
    {
      title: "Exercice 2 — QCM de compréhension",
      question: "Dans l'interface d'un cours en ligne, que signifie « Download the lecture notes before troubleshooting your device » ?",
      solution: "« Téléchargez les notes du cours magistral avant de dépanner votre appareil. »"
    }
  ],
  summary: "Maîtriser le lexique IT de base et éviter les faux-amis (library, directory, actually, resume, support) évite les contresens dans la pratique quotidienne.",
  references: ["Glendinning, E. — Oxford English for Information Technology."]
});