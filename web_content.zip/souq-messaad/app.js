/*
 * سوق مسعد — interactive product prototype
 *
 * This build deliberately keeps data local so it can run without a backend.
 * Production authentication, SMS OTP, image storage, search indexing and
 * moderation rules must be moved to a trusted server before release.
 */

const STORAGE_KEY = 'souq_messaad_state_v1';
const SESSION_KEY = 'souq_messaad_session_v1';
const ADMIN_PHONE = '0666000000';
const ADMIN_HASH = '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9'; // admin123 demo hash
const USER_HASH = '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'; // 123456 demo hash

const categories = [
  ['🛋️', 'أثاث'], ['📱', 'هواتف'], ['💻', 'حواسيب'], ['🚗', 'سيارات ودراجات'],
  ['👕', 'ملابس'], ['🏠', 'عقارات'], ['🐑', 'مواشي'], ['🐾', 'حيوانات'],
  ['📚', 'كتب'], ['🔧', 'خدمات وحرفيين'], ['🍰', 'مأكولات منزلية'], ['📦', 'أغراض مستعملة أو جديدة']
];

const seedState = {
  users: [
    { id: 'admin-1', name: 'مدير سوق مسعد', phone: ADMIN_PHONE, passwordHash: ADMIN_HASH, role: 'admin', phoneVerified: true, verified: true, status: 'active' },
    { id: 'user-2', name: 'محمد بوعلام', phone: '0550123456', passwordHash: USER_HASH, role: 'buyer', phoneVerified: true, verified: true, status: 'active' },
    { id: 'user-3', name: 'سارة مسعد', phone: '0550789456', passwordHash: USER_HASH, role: 'buyer', phoneVerified: true, verified: false, status: 'active' },
    { id: 'user-4', name: 'متجر النور', phone: '0660456789', passwordHash: USER_HASH, role: 'seller', phoneVerified: true, verified: true, status: 'active' }
  ],
  shops: [
    { id: 'shop-1', name: 'محل النور للإلكترونيات', owner: 'متجر النور', phone: '0660456789', location: 'وسط مدينة مسعد', description: 'هواتف وإكسسوارات أصلية مع خدمة ما بعد البيع.', status: 'approved', featured: true, emoji: '📱', userId: 'user-4' },
    { id: 'shop-2', name: 'دار الأناقة', owner: 'سارة مسعد', phone: '0550789456', location: 'مدينة مسعد', description: 'ملابس مختارة بعناية لكل أفراد العائلة.', status: 'approved', featured: true, emoji: '👕', userId: 'user-3' },
    { id: 'shop-3', name: 'أثاث البيت العصري', owner: 'محمد بوعلام', phone: '0550123456', location: 'مسعد', description: 'أثاث منزلي عملي بتصاميم عصرية.', status: 'approved', featured: true, emoji: '🛋️', userId: 'user-2' },
    { id: 'shop-pending', name: 'ورشة لمسة', owner: 'أحمد ق', phone: '0550999888', location: 'مدينة مسعد', description: 'طلب تسجيل محل بانتظار مراجعة الإدارة.', status: 'pending', featured: false, emoji: '🔧', userId: 'user-3' }
  ],
  sales: [
    { id: 'sale-1', name: 'iPhone 13 بحالة ممتازة', price: 85000, category: 'هواتف', condition: 'مستعمل', emoji: '📱', sellerId: 'user-2', seller: 'محمد بوعلام', phone: '0550123456', phoneVerified: true, sellerVerified: true, city: 'مسعد', description: 'هاتف iPhone 13، سعة 128GB، البطارية بحالة جيدة مع العلبة والشاحن.', status: 'published', visible: true, rating: 9.2, reviewCount: 2, createdAt: 'منذ ساعتين', shopId: null, reviewEligible: false },
    { id: 'sale-2', name: 'Samsung Galaxy A55', price: 55000, category: 'هواتف', condition: 'جديد', emoji: '📱', sellerId: 'user-4', seller: 'متجر النور', phone: '0660456789', phoneVerified: true, sellerVerified: true, city: 'مسعد', description: 'Samsung Galaxy A55 جديد، ضمان المحل وفاتورة شراء.', status: 'published', visible: true, rating: 9.6, reviewCount: 5, createdAt: 'منذ 4 ساعات', shopId: 'shop-1', reviewEligible: false },
    { id: 'sale-3', name: 'صالون عصري للمنزل', price: 120000, category: 'أثاث', condition: 'مستعمل', emoji: '🛋️', sellerId: 'user-2', seller: 'محمد بوعلام', phone: '0550123456', phoneVerified: true, sellerVerified: true, city: 'مسعد', description: 'صالون نظيف بلون بيج، مناسب لغرفة الجلوس. المعاينة داخل مسعد.', status: 'published', visible: true, rating: 8.8, reviewCount: 3, createdAt: 'أمس', shopId: 'shop-3', reviewEligible: false },
    { id: 'sale-4', name: 'دراجة نارية VMS', price: 310000, category: 'سيارات ودراجات', condition: 'مستعمل', emoji: '🏍️', sellerId: 'user-3', seller: 'سارة مسعد', phone: '0550789456', phoneVerified: true, sellerVerified: false, city: 'مسعد', description: 'دراجة نارية بحالة جيدة، أوراقها كاملة.', status: 'published', visible: true, rating: 9.0, reviewCount: 1, createdAt: 'منذ يومين', shopId: null, reviewEligible: false },
    { id: 'sale-5', name: 'حلويات منزلية مشكلة', price: 1800, category: 'مأكولات منزلية', condition: 'جديد', emoji: '🍰', sellerId: 'user-3', seller: 'سارة مسعد', phone: '0550789456', phoneVerified: true, sellerVerified: false, city: 'مسعد', description: 'علبة حلويات منزلية مشكلة، تحضير يومي وبطلب مسبق.', status: 'published', visible: true, rating: 9.7, reviewCount: 8, createdAt: 'منذ 3 أيام', shopId: null, reviewEligible: false },
    { id: 'sale-6', name: 'حاسوب محمول Lenovo', price: 68000, category: 'حواسيب', condition: 'مستعمل', emoji: '💻', sellerId: 'user-4', seller: 'متجر النور', phone: '0660456789', phoneVerified: true, sellerVerified: true, city: 'مسعد', description: 'Lenovo Core i5، ذاكرة 8GB وقرص SSD، مناسب للدراسة والعمل.', status: 'published', visible: true, rating: 8.9, reviewCount: 2, createdAt: 'منذ 4 أيام', shopId: 'shop-1', reviewEligible: false },
    { id: 'sale-pending', name: 'طاولة مكتب خشبية', price: 14500, category: 'أثاث', condition: 'مستعمل', emoji: '🪑', sellerId: 'user-3', seller: 'سارة مسعد', phone: '0550789456', phoneVerified: true, sellerVerified: false, city: 'مسعد', description: 'طاولة مكتب بحالة جيدة.', status: 'pending', visible: false, rating: 0, reviewCount: 0, createdAt: 'اليوم', shopId: null, reviewEligible: false }
  ],
  reviews: [
    { id: 'review-1', saleId: 'sale-1', userId: 'user-3', name: 'سارة مسعد', rating: 9, text: 'المنتج مطابق للوصف والتعامل كان محترمًا.', date: 'قبل يومين', status: 'published' },
    { id: 'review-2', saleId: 'sale-1', userId: 'user-4', name: 'متجر النور', rating: 10, text: 'هاتف نظيف جدًا وسريع.', date: 'قبل 5 أيام', status: 'published' },
    { id: 'review-3', saleId: 'sale-2', userId: 'user-2', name: 'محمد بوعلام', rating: 10, text: 'ضمان وفاتورة، تجربة ممتازة.', date: 'قبل أسبوع', status: 'published' }
  ],
  reports: [
    { id: 'report-1', saleId: 'sale-4', reason: 'معلومات خاطئة', reporter: 'سارة مسعد', status: 'open', date: 'اليوم' }
  ],
  verificationRequests: [
    { id: 'verify-1', userId: 'user-3', name: 'سارة مسعد', type: 'حساب موثق', status: 'pending', date: 'اليوم' }
  ],
  favorites: [],
  messages: [
    { id: 'chat-1', saleId: 'sale-1', buyerId: 'user-3', sellerId: 'user-2', messages: [
      { from: 'buyer', text: 'السلام عليكم، هل الهاتف ما زال متوفرًا؟' },
      { from: 'seller', text: 'وعليكم السلام، نعم متوفر في مسعد.' }
    ] }
  ]
};

let db = loadDb();
let session = loadSession();
let ui = {
  view: 'home',
  authMode: 'login',
  selectedCategory: '',
  searchQuery: '',
  sort: 'latest',
  condition: '',
  minPrice: '',
  maxPrice: '',
  mySalesOnly: false,
  filterOpen: false,
  selectedSaleId: null,
  selectedShopId: null,
  adminTab: 'sales',
  chatSaleId: null,
  modal: null
};

const app = document.getElementById('app');
const toast = document.getElementById('toast');

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function loadDb() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return { ...clone(seedState), ...JSON.parse(stored) };
  } catch (error) { console.warn('Local state reset', error); }
  return clone(seedState);
}
function saveDb() { localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); }
function loadSession() {
  try {
    const stored = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
    if (!stored || !stored.userId) return null;
    return stored;
  } catch (error) { return null; }
}
function saveSession(user) {
  session = { userId: user.id, issuedAt: Date.now() };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}
function clearSession() { session = null; localStorage.removeItem(SESSION_KEY); }
function currentUser() { return session ? db.users.find(user => user.id === session.userId) : null; }
function getSale(id) { return db.sales.find(sale => sale.id === id); }
function getShop(id) { return db.shops.find(shop => shop.id === id); }
function getUser(id) { return db.users.find(user => user.id === id); }
function escapeHtml(value = '') {
  return String(value).replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));
}
function initials(name = '') { return escapeHtml(name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join('') || 'م'); }
function money(value) { return `${Number(value || 0).toLocaleString('en-US')} <small>دج</small>`; }
function isAdmin() { return currentUser()?.role === 'admin'; }
function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 2600);
}
function stars(rating) { return `<span class="rating">★ ${Number(rating || 0).toFixed(1)}/10</span>`; }
function avatar(name, extra = '') { return `<div class="avatar ${extra}">${initials(name)}</div>`; }
function phoneBadge() { return '<span class="badge badge-phone">✓ رقم موثق</span>'; }
function verifiedBadge() { return '<span class="badge badge-verified">🔵 حساب موثق</span>'; }
function visibleSales() { return db.sales.filter(sale => sale.city === 'مسعد' && sale.status === 'published' && sale.visible !== false); }
function filteredSales() {
  let items = ui.mySalesOnly ? db.sales.filter(sale => sale.city === 'مسعد' && sale.sellerId === currentUser()?.id) : visibleSales();
  const query = ui.searchQuery.trim().toLowerCase();
  if (query) items = items.filter(sale => `${sale.name} ${sale.category} ${sale.description} ${sale.seller}`.toLowerCase().includes(query));
  if (ui.selectedCategory) items = items.filter(sale => sale.category === ui.selectedCategory);
  if (ui.condition) items = items.filter(sale => sale.condition === ui.condition);
  if (ui.minPrice !== '') items = items.filter(sale => sale.price >= Number(ui.minPrice));
  if (ui.maxPrice !== '') items = items.filter(sale => sale.price <= Number(ui.maxPrice));
  if (ui.sort === 'low') items.sort((a, b) => a.price - b.price);
  if (ui.sort === 'high') items.sort((a, b) => b.price - a.price);
  if (ui.sort === 'rating') items.sort((a, b) => b.rating - a.rating);
  return items;
}
function currentFavorites() {
  return db.favorites.filter(fav => fav.userId === currentUser()?.id).map(fav => fav.saleId);
}

function render() {
  if (!session || !currentUser()) {
    renderAuth();
    return;
  }
  if (ui.view === 'home') renderShell(renderHome(), 'home');
  else if (ui.view === 'search') renderShell(renderSearch(), 'search');
  else if (ui.view === 'add') renderShell(renderAdd(), 'add');
  else if (ui.view === 'favorites') renderShell(renderFavorites(), 'favorites');
  else if (ui.view === 'account') renderShell(renderAccount(), 'account');
  else if (ui.view === 'detail') renderShell(renderDetail(), '');
  else if (ui.view === 'shop') renderShell(renderShop(), '');
  else if (ui.view === 'shops') renderShell(renderShops(), 'home');
  else if (ui.view === 'admin' && isAdmin()) renderShell(renderAdmin(), 'account');
  else { ui.view = 'home'; renderShell(renderHome(), 'home'); }
  renderModal();
}

function renderAuth() {
  const admin = ui.authMode === 'admin';
  const signup = ui.authMode === 'signup';
  app.innerHTML = `
    <div class="auth-shell">
      <section class="auth-visual">
        <div class="brand-lockup"><span class="logo-mark">🛒</span><span>سوق مسعد</span></div>
        <div class="auth-visual-content">
          <div class="eyebrow">سوق مدينتك في مكان واحد</div>
          <h1>كل ما تحتاجه<br>قريب منك.</h1>
          <p>منتجات، محلات، خدمات وأشخاص من مسعد فقط — في تجربة سوق إلكتروني مرتبة وآمنة.</p>
          <div class="visual-pills"><span class="visual-pill">📍 مسعد فقط</span><span class="visual-pill">🔒 حساب آمن</span><span class="visual-pill">✅ مراجعة الإدارة</span></div>
        </div>
      </section>
      <section class="auth-panel">
        <div class="auth-card">
          <div class="brand-lockup"><span class="logo-mark">🛒</span><span>سوق مسعد</span></div>
          <h2>${admin ? 'دخول الإدارة' : signup ? 'أنشئ حسابك' : 'مرحبًا بعودتك'}</h2>
          <p class="lead">${admin ? 'بوابة منفصلة ومحمية لإدارة المنصة.' : signup ? 'ابدأ البيع والشراء داخل مدينة مسعد.' : 'سجّل الدخول إلى سوقك المحلي.'}</p>
          ${!admin ? `<div class="auth-switch"><button class="${!signup ? 'active' : ''}" data-action="auth-mode" data-value="login">تسجيل الدخول</button><button class="${signup ? 'active' : ''}" data-action="auth-mode" data-value="signup">إنشاء حساب</button></div>` : ''}
          ${signup ? renderSignupForm() : renderLoginForm(admin)}
          <div class="auth-foot">
            ${admin ? '<a data-action="auth-mode" data-value="login">العودة إلى دخول المستخدمين</a>' : '<a data-action="auth-mode" data-value="admin">دخول الإدارة الآمن</a>'}
            <br>باستخدامك سوق مسعد، توافق على شروط الاستخدام وسياسة الخصوصية.
          </div>
        </div>
      </section>
    </div>`;
}

function renderLoginForm(admin = false) {
  return `<form id="login-form" novalidate>
    <div class="field"><label for="login-phone">📱 رقم الهاتف</label><input class="input" id="login-phone" name="phone" inputmode="tel" placeholder="05 xx xx xx xx" required></div>
    <div class="field"><label for="login-password">🔐 كلمة المرور</label><input class="input" id="login-password" name="password" type="password" placeholder="أدخل كلمة المرور" required></div>
    <button class="btn btn-primary full" type="submit">${admin ? 'دخول لوحة الإدارة ←' : 'تسجيل الدخول ←'}</button>
    ${admin ? '<div class="notice">للتجربة فقط: 0666000000 / admin123. في الإنتاج يجب ربط ذلك بمصادقة خادم وصلاحيات منفصلة.</div>' : '<div style="text-align:center;margin-top:14px"><button class="btn btn-ghost" type="button" data-action="forgot">نسيت كلمة المرور؟</button></div>'}
  </form>`;
}

function renderSignupForm() {
  return `<form id="signup-form" novalidate>
    <div class="field"><label for="signup-name">👤 الاسم</label><input class="input" id="signup-name" name="name" placeholder="اكتب اسمك الكامل" required></div>
    <div class="field"><label for="signup-phone">📱 رقم الهاتف</label><input class="input" id="signup-phone" name="phone" inputmode="tel" placeholder="05 xx xx xx xx" required></div>
    <div class="form-grid">
      <div class="field"><label for="signup-password">🔐 كلمة المرور</label><input class="input" id="signup-password" name="password" type="password" minlength="6" placeholder="6 أحرف على الأقل" required></div>
      <div class="field"><label for="signup-confirm">🔐 تأكيد كلمة المرور</label><input class="input" id="signup-confirm" name="confirm" type="password" placeholder="أعد كلمة المرور" required></div>
    </div>
    <button class="btn btn-primary full" type="submit">إنشاء الحساب وإرسال رمز SMS ←</button>
    <div class="notice">📩 بعد الإرسال سيُطلب رمز SMS لتوثيق رقم الهاتف. هذا النموذج يحاكي التدفق محليًا.</div>
  </form>`;
}

function renderShell(content, active) {
  const user = currentUser();
  app.innerHTML = `<div class="app-shell">
    <header class="topbar"><div class="container topbar-inner">
      <button class="topbar-brand" data-action="go" data-value="home"><span class="logo-mark">🛒</span><span>سوق مسعد</span></button>
      <div class="location">📍 <span>السوق المحلي</span> مسعد</div>
      <div class="top-actions"><button class="icon-btn" data-action="notifications" aria-label="الإشعارات">🔔<span class="dot"></span></button><button class="avatar" data-action="go" data-value="account" aria-label="حسابي">${initials(user.name)}</button></div>
    </div></header>
    <main class="main-content"><div class="container">${content}</div></main>
    <nav class="bottom-nav"><div class="bottom-nav-inner">
      ${navItem('home', '🏠', 'الرئيسية', active)}
      ${navItem('search', '🔎', 'البحث', active)}
      ${navItem('add', '＋', 'أضف مبيعة', active, true)}
      ${navItem('favorites', '♡', 'المفضلة', active)}
      ${navItem('account', '👤', 'حسابي', active)}
    </div></nav>
  </div>`;
}
function navItem(view, icon, label, active, add = false) {
  return `<button class="nav-item ${active === view ? 'active' : ''} ${add ? 'nav-add' : ''}" data-action="go" data-value="${view}"><span class="nav-icon">${icon}</span><span>${label}</span></button>`;
}

function renderHome() {
  const sales = visibleSales().slice(0, 6);
  const featured = db.shops.filter(shop => shop.status === 'approved' && shop.featured);
  return `<section class="hero">
    <div class="hero-copy"><div class="eyebrow">أهلًا بك في سوق مسعد 👋</div><h1>سوق مدينتك<br>في مكان واحد</h1><p>اكتشف عروضًا حقيقية من أشخاص ومحلات داخل مسعد.</p></div>
    <form class="hero-search" id="hero-search"><div class="input-wrap"><span class="input-icon">🔍</span><input class="input" name="query" placeholder="ماذا تبحث في سوق مسعد؟" autocomplete="off"></div></form>
  </section>
  <div class="section-head"><h2>تصفح الأقسام</h2><a data-action="go" data-value="search">عرض الكل</a></div>
  <div class="categories">${categories.map(([icon, label]) => `<button class="category" data-action="category" data-value="${escapeHtml(label)}"><span class="category-icon">${icon}</span><span>${escapeHtml(label)}</span></button>`).join('')}</div>
  <div class="section-head"><h2>⭐ محلات مميزة في مسعد</h2><a data-action="go" data-value="shops">عرض الكل</a></div>
  <div class="horizontal-scroll">${featured.map(renderShopCard).join('')}</div>
  <div class="section-head"><h2>🔥 أحدث المبيعات</h2><a data-action="go" data-value="search">كل المبيعات</a></div>
  <div class="products-grid">${sales.map(renderProductCard).join('')}</div>`;
}

function renderShopCard(shop) {
  return `<article class="shop-card" data-action="open-shop" data-id="${shop.id}"><div class="shop-card-content"><span class="badge badge-dark">⭐ محل مميز</span><h3>${escapeHtml(shop.name)}</h3><p>${escapeHtml(shop.description)}</p><div class="shop-meta"><span>📍 ${escapeHtml(shop.location)}</span><span>›</span></div></div></article>`;
}

function renderProductCard(sale) {
  const favorite = currentFavorites().includes(sale.id);
  return `<article class="product-card" data-action="open-sale" data-id="${sale.id}">
    <div class="product-media"><span>${sale.emoji}</span>${sale.status !== 'published' ? '<span class="badge badge-pending" style="position:absolute;right:10px;bottom:10px">⏳ '+statusLabel(sale.status)+'</span>' : ''}<button class="heart" data-action="favorite" data-id="${sale.id}" aria-label="حفظ">${favorite ? '♥' : '♡'}</button></div>
    <div class="product-body"><h3>${escapeHtml(sale.name)}</h3><div class="price">${money(sale.price)}</div><div class="product-meta"><span>${escapeHtml(sale.condition)}</span>${stars(sale.rating)}</div><div class="product-seller"><span class="mini-avatar">${initials(sale.seller)}</span><span>${escapeHtml(sale.seller)}</span>${sale.sellerVerified ? '🔵' : ''}</div></div>
  </article>`;
}

function renderSearch() {
  const items = filteredSales();
  const sortLabels = { latest: 'الأحدث', low: 'الأقل سعرًا', high: 'الأعلى سعرًا', rating: 'الأعلى تقييمًا' };
  return `<div class="page-title"><h1>البحث في سوق مسعد</h1><p>نتائج من مدينة مسعد فقط — بدون أحياء أو مدن أخرى.</p></div>
    <form class="search-bar-large" id="search-form"><div class="input-wrap"><span class="input-icon">🔍</span><input class="input" name="query" value="${escapeHtml(ui.searchQuery)}" placeholder="ابحث عن هاتف، أثاث، خدمة..."></div><button class="btn btn-primary" type="submit">بحث</button><button class="btn btn-outline" type="button" data-action="toggle-filters">⚙ فلاتر</button></form>
    <div class="filter-row"><button class="filter-chip ${!ui.selectedCategory ? 'active' : ''}" data-action="clear-category">كل الأقسام</button>${categories.map(([, label]) => `<button class="filter-chip ${ui.selectedCategory === label ? 'active' : ''}" data-action="category" data-value="${escapeHtml(label)}">${escapeHtml(label)}</button>`).join('')}</div>
    ${ui.filterOpen ? `<div class="filter-panel"><div class="field"><label>الحالة</label><select class="select" id="condition-filter"><option value="">الكل</option><option ${ui.condition === 'جديد' ? 'selected' : ''}>جديد</option><option ${ui.condition === 'مستعمل' ? 'selected' : ''}>مستعمل</option></select></div><div class="field"><label>الترتيب</label><select class="select" id="sort-filter">${Object.entries(sortLabels).map(([key, label]) => `<option value="${key}" ${ui.sort === key ? 'selected' : ''}>${label}</option>`).join('')}</select></div><div class="field"><label>السعر من</label><input class="input" id="min-price" type="number" value="${escapeHtml(ui.minPrice)}" placeholder="0"></div><div class="field"><label>السعر إلى</label><input class="input" id="max-price" type="number" value="${escapeHtml(ui.maxPrice)}" placeholder="بدون حد"></div></div>` : ''}
    <div class="section-head"><h2>${ui.mySalesOnly ? '📦 مبيعاتي' : ui.searchQuery ? `نتائج «${escapeHtml(ui.searchQuery)}»` : 'كل المبيعات'}</h2><span class="muted" style="font-size:12px">${items.length} مبيعة</span></div>
    ${items.length ? `<div class="products-grid">${items.map(renderProductCard).join('')}</div>` : '<div class="empty-state"><div class="empty-icon">🔎</div><strong>لم نجد نتائج مطابقة</strong><div style="font-size:12px;margin-top:5px">جرّب كلمة أخرى أو غيّر الفلاتر.</div></div>'}`;
}

function renderFavorites() {
  const ids = currentFavorites();
  const sales = ids.map(getSale).filter(Boolean).filter(sale => sale.status === 'published');
  return `<div class="page-title"><h1>❤️ المفضلة</h1><p>المبيعات التي حفظتها للرجوع إليها لاحقًا.</p></div>${sales.length ? `<div class="products-grid">${sales.map(renderProductCard).join('')}</div>` : '<div class="empty-state"><div class="empty-icon">♡</div><strong>قائمة المفضلة فارغة</strong><div style="font-size:12px;margin-top:5px">اضغط ♡ على أي مبيعة لتحفظها هنا.</div><button class="btn btn-secondary" style="margin-top:17px" data-action="go" data-value="search">اكتشف المبيعات</button></div>'}`;
}

function renderAdd() {
  return `<div class="page-title"><h1>➕ أضف مبيعة</h1><p>اعرض منتجك أمام أهل مسعد — ستراجعه الإدارة قبل النشر.</p></div>
    <div class="form-card"><form id="sale-form" novalidate>
      <div class="upload-box" data-action="upload"><div><div style="font-size:31px;margin-bottom:4px">📷</div><strong>أضف صور المبيعة</strong><span>يمكنك إضافة حتى 8 صور واضحة</span></div></div>
      <div class="form-grid"><div class="field"><label for="sale-name">✏️ اسم المبيعة</label><input class="input" id="sale-name" name="name" placeholder="مثال: هاتف iPhone 13" required></div><div class="field"><label for="sale-price">💰 السعر بالدينار</label><input class="input" id="sale-price" name="price" type="number" min="0" placeholder="85,000" required></div><div class="field"><label for="sale-category">📂 القسم</label><select class="select" id="sale-category" name="category" required><option value="">اختر القسم</option>${categories.map(([, label]) => `<option>${escapeHtml(label)}</option>`).join('')}</select></div><div class="field"><label for="sale-condition">🆕 الحالة</label><select class="select" id="sale-condition" name="condition" required><option value="">اختر الحالة</option><option>جديد</option><option>مستعمل</option></select></div><div class="field full-col"><label for="sale-description">📝 الوصف</label><textarea class="textarea" id="sale-description" name="description" placeholder="اكتب تفاصيل واضحة عن المنتج ومكان المعاينة داخل مسعد..." required></textarea></div></div>
      <div class="notice">⏳ بعد الضغط على «إرسال للمراجعة» ستبقى المبيعة قيد المراجعة ولن تظهر للعامة حتى توافق عليها الإدارة.</div><button class="btn btn-primary full" style="margin-top:16px" type="submit">🚀 إرسال للمراجعة</button>
    </form></div>`;
}

function renderAccount() {
  const user = currentUser();
  const mySales = db.sales.filter(sale => sale.sellerId === user.id).length;
  return `<div class="account-head">${avatar(user.name, 'large')}<div><h1>${escapeHtml(user.name)}</h1><p>${escapeHtml(user.phone)}</p><div class="account-badges">${user.phoneVerified ? phoneBadge() : '<span class="badge badge-pending">⚠ رقم غير موثق</span>'}${user.verified ? verifiedBadge() : ''}</div></div></div>
    <div class="section-head"><h2>حسابك في سوق مسعد</h2></div>
    <div class="account-menu">
      <button class="menu-row" data-action="my-sales"><span class="menu-icon">📦</span><span class="menu-copy"><strong>مبيعاتي</strong><span>${mySales} مبيعات — إدارة الحالات والمتابعة</span></span><span class="menu-arrow">‹</span></button>
      <button class="menu-row" data-action="messages"><span class="menu-icon">💬</span><span class="menu-copy"><strong>رسائلي</strong><span>محادثاتك المرتبطة بالمبيعات</span></span><span class="menu-arrow">‹</span></button>
      <button class="menu-row" data-action="shop-request"><span class="menu-icon">🏪</span><span class="menu-copy"><strong>تسجيل محل</strong><span>قدّم طلبًا لصفحة محل داخل مسعد</span></span><span class="menu-arrow">‹</span></button>
      <button class="menu-row" data-action="verification"><span class="menu-icon">🔵</span><span class="menu-copy"><strong>طلب توثيق الحساب</strong><span>رقم الهاتف الموثق منفصل عن الحساب الموثق</span></span><span class="menu-arrow">‹</span></button>
      ${isAdmin() ? '<button class="menu-row" data-action="go" data-value="admin"><span class="menu-icon">🛡️</span><span class="menu-copy"><strong>لوحة الإدارة</strong><span>المستخدمون، المبيعات، البلاغات والإحصائيات</span></span><span class="menu-arrow">‹</span></button>' : ''}
      <button class="menu-row" data-action="logout"><span class="menu-icon" style="background:#fce8e8">🚪</span><span class="menu-copy"><strong style="color:var(--danger)">تسجيل الخروج</strong><span>إنهاء الجلسة على هذا الجهاز</span></span><span class="menu-arrow">‹</span></button>
    </div>`;
}

function renderDetail() {
  const sale = getSale(ui.selectedSaleId);
  if (!sale) return '<div class="empty-state">المبيعة غير موجودة.</div>';
  const reviews = db.reviews.filter(review => review.saleId === sale.id && review.status === 'published');
  const saved = currentFavorites().includes(sale.id);
  const canReview = sale.reviewEligible && currentUser()?.id !== sale.sellerId;
  return `<div class="back-row"><button class="icon-btn" data-action="back">→</button><h1>تفاصيل المبيعة</h1></div><div class="detail-layout"><div><div class="detail-media"><span>${sale.emoji}</span><button class="detail-heart" data-action="favorite" data-id="${sale.id}">${saved ? '♥' : '♡'}</button></div><div class="section-head"><h2>💬 تعليقات المشترين</h2><span class="muted" style="font-size:12px">بعد شراء فعلي فقط</span></div>${reviews.length ? `<div class="review-list">${reviews.map(renderReview).join('')}</div>` : '<div class="empty-state" style="padding:24px">لا توجد تعليقات منشورة بعد.</div>'}</div><div class="detail-content"><div class="detail-title-row"><div><span class="badge badge-phone">${escapeHtml(sale.category)}</span><h1>${escapeHtml(sale.name)}</h1></div></div><div class="detail-price">${money(sale.price)}</div><p class="detail-description">${escapeHtml(sale.description)}</p><div class="detail-info"><div class="info-cell"><span>الحالة</span><strong>${escapeHtml(sale.condition)}</strong></div><div class="info-cell"><span>الموقع</span><strong>📍 ${escapeHtml(sale.city)} فقط</strong></div><div class="info-cell"><span>تقييم المبيعة</span><strong>${stars(sale.rating)}</strong></div><div class="info-cell"><span>عدد التقييمات</span><strong>${sale.reviewCount} تقييم</strong></div></div><div class="seller-box">${avatar(sale.seller)}<div class="seller-copy"><strong>${escapeHtml(sale.seller)}</strong><span>${phoneBadge()} ${sale.sellerVerified ? verifiedBadge() : ''}</span></div><button class="icon-btn" data-action="call" data-id="${sale.id}">📞</button></div><div class="action-row"><button class="btn btn-primary" data-action="call" data-id="${sale.id}">📞 اتصال</button><button class="btn btn-secondary" data-action="message" data-id="${sale.id}">💬 مراسلة</button></div><button class="btn btn-ghost full" style="margin-top:8px;color:var(--danger)" data-action="report" data-id="${sale.id}">🚨 إبلاغ عن هذه المبيعة</button><div class="review-summary"><div class="review-number">${Number(sale.rating).toFixed(1)}</div><div><div class="review-stars">★★★★★</div><p>من 10 — تقييم المبيعة، وليس البائع</p></div></div>${canReview ? '<button class="btn btn-outline full" style="margin-top:14px" data-action="open-review" data-id="'+sale.id+'">⭐ قيّم هذه المبيعة</button>' : '<div class="notice" style="margin-top:14px">🔒 التقييم متاح فقط للمشتري بعد إتمام شراء فعلي موثّق. لا يمكن للبائع تقييم مبيعته.</div>'}</div></div>`;
}
function renderReview(review) {
  return `<article class="review"><div class="review-top">${avatar(review.name)}<strong>${escapeHtml(review.name)}</strong><span class="rating">★ ${review.rating}/10</span><time>${escapeHtml(review.date)}</time></div><p>${escapeHtml(review.text)}</p></article>`;
}

function renderShops() {
  const shops = db.shops.filter(shop => shop.status === 'approved');
  return `<div class="page-title"><h1>⭐ محلات مميزة في مسعد</h1><p>محلات مقبولة من الإدارة وتعمل داخل مدينة مسعد.</p></div><div class="horizontal-scroll" style="grid-auto-columns:minmax(270px,1fr)">${shops.map(renderShopCard).join('')}</div><div class="notice" style="margin-top:20px">🏪 هل تملك محلًا داخل مسعد؟ يمكنك إرسال طلب التسجيل من «حسابي»، وستراجعه الإدارة قبل الظهور.</div>`;
}

function renderShop() {
  const shop = getShop(ui.selectedShopId);
  if (!shop) return '<div class="empty-state">المحل غير موجود.</div>';
  const sales = db.sales.filter(sale => sale.shopId === shop.id && sale.status === 'published' && sale.visible !== false);
  return `<div class="back-row"><button class="icon-btn" data-action="back">→</button><h1>صفحة المحل</h1></div><section class="shop-hero"><div class="shop-hero-content"><span class="badge badge-dark">⭐ محل مميز في مسعد</span><h1>${escapeHtml(shop.name)}</h1><p>${escapeHtml(shop.description)}</p><div class="shop-info-row"><span>👤 ${escapeHtml(shop.owner)}</span><span>📞 ${escapeHtml(shop.phone)}</span><span>📍 ${escapeHtml(shop.location)}</span></div></div></section><div class="section-head"><h2>📦 مبيعات المحل</h2><span class="muted" style="font-size:12px">${sales.length} منتجات</span></div>${sales.length ? `<div class="products-grid">${sales.map(renderProductCard).join('')}</div>` : '<div class="empty-state">لا توجد مبيعات منشورة لهذا المحل حاليًا.</div>'}`;
}

function renderAdmin() {
  const counts = { users: db.users.length, sales: db.sales.length, shops: db.shops.length, pendingSales: db.sales.filter(s => s.status === 'pending').length, verification: db.verificationRequests.filter(r => r.status === 'pending').length, reports: db.reports.filter(r => r.status === 'open').length, published: visibleSales().length };
  return `<div class="admin-head"><div><h1>لوحة الإدارة</h1><p>تحكم كامل وآمن في سوق مسعد — المدينة كلها نطاق واحد.</p></div><span class="admin-lock">🛡️ صلاحيات المدير فقط</span></div><div class="stats-grid"><div class="stat-card"><div class="stat-icon">👥</div><strong>${counts.users}</strong><span>المستخدمون</span></div><div class="stat-card"><div class="stat-icon">📦</div><strong>${counts.sales}</strong><span>كل المبيعات</span></div><div class="stat-card"><div class="stat-icon">🏪</div><strong>${counts.shops}</strong><span>المحلات</span></div><div class="stat-card"><div class="stat-icon">⏳</div><strong>${counts.pendingSales}</strong><span>قيد المراجعة</span></div><div class="stat-card"><div class="stat-icon">🚨</div><strong>${counts.reports}</strong><span>بلاغات مفتوحة</span></div></div><div class="admin-tabs">${[['sales','📦 المبيعات'],['users','👥 المستخدمون'],['shops','🏪 المحلات'],['verification','🔵 التوثيق'],['reports','🚨 البلاغات'],['reviews','💬 التعليقات']].map(([key,label]) => `<button class="admin-tab ${ui.adminTab === key ? 'active' : ''}" data-action="admin-tab" data-value="${key}">${label}</button>`).join('')}</div>${renderAdminTable()}`;
}
function renderAdminTable() {
  if (ui.adminTab === 'sales') {
    return `<div class="admin-table"><div class="admin-row header"><span>المبيعة</span><span>البائع</span><span>الحالة</span><span>إجراء</span></div>${db.sales.map(sale => `<div class="admin-row"><div><div class="row-title">${sale.emoji} ${escapeHtml(sale.name)}</div><div class="row-sub">${money(sale.price)} · مسعد</div></div><div>${escapeHtml(sale.seller)}<div class="row-sub">${sale.category}</div></div><div>${statusBadge(sale.status)}</div><div class="row-actions">${sale.status === 'pending' ? `<button class="small-btn" data-action="admin-action" data-value="approve-sale" data-id="${sale.id}">قبول</button><button class="small-btn danger" data-action="admin-action" data-value="reject-sale" data-id="${sale.id}">رفض</button>` : `<button class="small-btn neutral" data-action="admin-action" data-value="hide-sale" data-id="${sale.id}">${sale.visible === false ? 'إظهار' : 'إخفاء'}</button><button class="small-btn danger" data-action="admin-action" data-value="delete-sale" data-id="${sale.id}">حذف</button>`}</div></div>`).join('')}</div>`;
  }
  if (ui.adminTab === 'users') return `<div class="admin-table"><div class="admin-row header"><span>المستخدم</span><span>الهاتف</span><span>الحالة</span><span>إجراء</span></div>${db.users.filter(u => u.role !== 'admin').map(user => `<div class="admin-row"><div><div class="row-title">${initials(user.name)} ${escapeHtml(user.name)}</div><div class="row-sub">${user.verified ? 'حساب موثق' : 'غير موثق'}</div></div><div>${escapeHtml(user.phone)}<div class="row-sub">${user.phoneVerified ? 'رقم موثق' : 'غير موثق'}</div></div><div>${statusBadge(user.status)}</div><div class="row-actions"><button class="small-btn" data-action="admin-action" data-value="toggle-user" data-id="${user.id}">${user.status === 'blocked' ? 'إلغاء الحظر' : 'حظر المستخدم'}</button></div></div>`).join('')}</div>`;
  if (ui.adminTab === 'shops') return `<div class="admin-table"><div class="admin-row header"><span>المحل</span><span>المالك</span><span>الحالة</span><span>إجراء</span></div>${db.shops.map(shop => `<div class="admin-row"><div><div class="row-title">${shop.emoji} ${escapeHtml(shop.name)}</div><div class="row-sub">${escapeHtml(shop.location)}</div></div><div>${escapeHtml(shop.owner)}</div><div>${statusBadge(shop.status)}</div><div class="row-actions">${shop.status === 'pending' ? `<button class="small-btn" data-action="admin-action" data-value="approve-shop" data-id="${shop.id}">قبول</button><button class="small-btn danger" data-action="admin-action" data-value="reject-shop" data-id="${shop.id}">رفض</button>` : `<button class="small-btn neutral" data-action="admin-action" data-value="toggle-featured" data-id="${shop.id}">${shop.featured ? 'إزالة التمييز' : 'تمييز المحل'}</button>`}</div></div>`).join('')}</div>`;
  if (ui.adminTab === 'verification') return `<div class="admin-table"><div class="admin-row header"><span>الطلب</span><span>المستخدم</span><span>الحالة</span><span>إجراء</span></div>${db.verificationRequests.map(req => `<div class="admin-row"><div><div class="row-title">🔵 ${escapeHtml(req.type)}</div><div class="row-sub">${escapeHtml(req.date)}</div></div><div>${escapeHtml(req.name)}</div><div>${statusBadge(req.status)}</div><div class="row-actions">${req.status === 'pending' ? `<button class="small-btn" data-action="admin-action" data-value="approve-verification" data-id="${req.id}">قبول</button><button class="small-btn danger" data-action="admin-action" data-value="reject-verification" data-id="${req.id}">رفض</button>` : '—'}</div></div>`).join('')}</div>`;
  if (ui.adminTab === 'reports') return `<div class="admin-table"><div class="admin-row header"><span>المبيعة</span><span>السبب</span><span>الحالة</span><span>إجراء</span></div>${db.reports.map(report => { const sale = getSale(report.saleId); return `<div class="admin-row"><div><div class="row-title">${sale?.emoji || '📦'} ${escapeHtml(sale?.name || 'مبيعة محذوفة')}</div><div class="row-sub">بلّغ عنه: ${escapeHtml(report.reporter)}</div></div><div>${escapeHtml(report.reason)}</div><div>${statusBadge(report.status)}</div><div class="row-actions">${report.status === 'open' ? `<button class="small-btn" data-action="admin-action" data-value="resolve-report" data-id="${report.id}">تمت المعالجة</button><button class="small-btn danger" data-action="admin-action" data-value="hide-reported" data-id="${report.id}">إخفاء المبيعة</button>` : '—'}</div></div>`; }).join('')}</div>`;
  return `<div class="admin-table"><div class="admin-row header"><span>التعليق</span><span>المبيعة</span><span>الحالة</span><span>إجراء</span></div>${db.reviews.map(review => { const sale = getSale(review.saleId); return `<div class="admin-row"><div><div class="row-title">⭐ ${review.rating}/10 · ${escapeHtml(review.name)}</div><div class="row-sub">${escapeHtml(review.text)}</div></div><div>${escapeHtml(sale?.name || '—')}</div><div>${statusBadge(review.status)}</div><div class="row-actions">${review.status === 'published' ? `<button class="small-btn danger" data-action="admin-action" data-value="delete-review" data-id="${review.id}">حذف التعليق</button>` : '—'}</div></div>`; }).join('')}</div>`;
}
function statusLabel(status) {
  return { published: 'منشورة', pending: 'قيد المراجعة', approved: 'مقبول', active: 'نشط', blocked: 'محظور', open: 'مفتوح', resolved: 'معالج', rejected: 'مرفوض' }[status] || status;
}
function statusBadge(status) {
  const labels = { published: 'منشورة', pending: 'قيد المراجعة', approved: 'مقبول', active: 'نشط', blocked: 'محظور', open: 'مفتوح', resolved: 'معالج', rejected: 'مرفوض' };
  const cls = ['pending', 'open'].includes(status) ? 'badge-pending' : ['blocked', 'rejected'].includes(status) ? 'badge-danger' : 'badge-verified';
  return `<span class="badge ${cls}">${escapeHtml(labels[status] || status)}</span>`;
}

function renderModal() {
  document.querySelectorAll('.modal-backdrop').forEach(element => element.remove());
  let html = '';
  if (ui.modal === 'report') {
    html = `<div class="modal-backdrop"><div class="modal"><div class="modal-head"><h2>🚨 إبلاغ عن المبيعة</h2><button class="close-btn" data-action="close-modal">×</button></div><p class="muted" style="font-size:12px;margin-top:0">اختر السبب الذي تريد إرساله إلى الإدارة.</p><div class="report-options">${['احتيال', 'معلومات خاطئة', 'منتج مخالف', 'إعلان مزعج', 'محتوى غير مناسب', 'سبب آخر'].map(reason => `<button class="report-option" data-action="submit-report" data-value="${reason}" data-id="${ui.selectedSaleId}">🚩 ${reason}</button>`).join('')}</div></div></div>`;
  }
  if (ui.modal === 'chat') {
    const sale = getSale(ui.chatSaleId);
    const chat = db.messages.find(item => item.saleId === ui.chatSaleId && item.buyerId === currentUser()?.id) || db.messages.find(item => item.saleId === ui.chatSaleId);
    html = `<div class="modal-backdrop"><div class="modal"><div class="modal-head"><h2>💬 مراسلة البائع</h2><button class="close-btn" data-action="close-modal">×</button></div><div class="chat-product"><div class="emoji">${sale?.emoji || '📦'}</div><div><strong>${escapeHtml(sale?.name || 'المبيعة')}</strong><span>المحادثة مرتبطة بهذه المبيعة · مسعد</span></div></div><div class="messages">${(chat?.messages || [{ from: 'seller', text: 'مرحبًا، كيف يمكنني مساعدتك؟' }]).map(message => `<div class="bubble ${message.from === 'buyer' ? 'mine' : 'theirs'}">${escapeHtml(message.text)}</div>`).join('')}</div><form id="chat-form" class="chat-input"><input class="input" name="message" placeholder="اكتب رسالتك..." required><button class="btn btn-primary" type="submit">إرسال</button></form></div></div>`;
  }
  if (ui.modal === 'review') {
    const sale = getSale(ui.selectedSaleId);
    html = `<div class="modal-backdrop"><div class="modal"><div class="modal-head"><h2>⭐ تقييم المبيعة</h2><button class="close-btn" data-action="close-modal">×</button></div><p class="muted" style="font-size:12px">تقييمك يخص «${escapeHtml(sale?.name || '')}» فقط. لا يوجد تقييم للبائع.</p><form id="review-form"><div class="field"><label>التقييم من 10</label><select class="select" name="rating" required>${Array.from({ length: 10 }, (_, i) => 10 - i).map(value => `<option value="${value}">${value}/10</option>`).join('')}</select></div><div class="field"><label>تعليقك</label><textarea class="textarea" name="text" placeholder="شارك تجربتك بعد الشراء الفعلي..." required></textarea></div><button class="btn btn-primary full" type="submit">نشر التقييم</button></form></div></div>`;
  }
  if (ui.modal === 'shop-request') {
    html = `<div class="modal-backdrop"><div class="modal"><div class="modal-head"><h2>🏪 تسجيل محل</h2><button class="close-btn" data-action="close-modal">×</button></div><form id="shop-form"><div class="field"><label>اسم المحل</label><input class="input" name="name" placeholder="مثال: محل مسعد" required></div><div class="field"><label>اسم صاحب المحل</label><input class="input" name="owner" value="${escapeHtml(currentUser().name)}" required></div><div class="field"><label>رقم الهاتف</label><input class="input" name="phone" value="${escapeHtml(currentUser().phone)}" required></div><div class="field"><label>وصف المحل</label><textarea class="textarea" name="description" placeholder="ما الذي يقدمه محلك؟" required></textarea></div><div class="field"><label>📍 موقع المحل داخل مسعد</label><input class="input" name="location" placeholder="مثال: وسط مدينة مسعد" required></div><button class="btn btn-primary full" type="submit">إرسال طلب التسجيل</button></form></div></div>`;
  }
  if (ui.modal === 'verification') {
    html = `<div class="modal-backdrop"><div class="modal"><div class="modal-head"><h2>🔵 طلب توثيق الحساب</h2><button class="close-btn" data-action="close-modal">×</button></div><p style="font-size:13px;line-height:1.8;color:#5d6a65">توثيق رقم الهاتف لا يعني تلقائيًا توثيق الحساب. أرسل طلبك ليقوم المدير بمراجعة البيانات.</p><form id="verification-form"><div class="field"><label>ملاحظة للإدارة</label><textarea class="textarea" name="note" placeholder="اكتب أي معلومات تساعد في مراجعة الطلب..."></textarea></div><button class="btn btn-primary full" type="submit">إرسال طلب التوثيق</button></form></div></div>`;
  }
  if (ui.modal) document.body.insertAdjacentHTML('beforeend', html);
  const backdrop = document.querySelector('.modal-backdrop');
  if (backdrop) backdrop.addEventListener('click', event => { if (event.target === backdrop) { ui.modal = null; renderModal(); } });
}

async function hashPassword(password) {
  if (window.crypto?.subtle) {
    const bytes = new TextEncoder().encode(password);
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest)).map(byte => byte.toString(16).padStart(2, '0')).join('');
  }
  return btoa(unescape(encodeURIComponent(password)));
}

async function handleSubmit(form) {
  const data = Object.fromEntries(new FormData(form).entries());
  if (form.id === 'login-form') {
    const hash = await hashPassword(data.password || '');
    const user = db.users.find(item => item.phone === data.phone.trim() && item.passwordHash === hash);
    if (!user) { showToast('رقم الهاتف أو كلمة المرور غير صحيحة'); return; }
    if (user.status === 'blocked') { showToast('هذا الحساب محظور من الإدارة'); return; }
    if (ui.authMode === 'admin' && user.role !== 'admin') { showToast('هذا الحساب لا يملك صلاحيات الإدارة'); return; }
    if (ui.authMode !== 'admin' && user.role === 'admin') { showToast('استخدم بوابة الإدارة المنفصلة'); return; }
    saveSession(user); ui.view = user.role === 'admin' ? 'admin' : 'home'; showToast('تم تسجيل الدخول بنجاح'); render(); return;
  }
  if (form.id === 'signup-form') {
    if (data.password !== data.confirm) { showToast('تأكيد كلمة المرور غير مطابق'); return; }
    if ((data.password || '').length < 6) { showToast('كلمة المرور يجب أن تكون 6 أحرف على الأقل'); return; }
    if (db.users.some(user => user.phone === data.phone.trim())) { showToast('رقم الهاتف مسجل مسبقًا'); return; }
    const user = { id: `user-${Date.now()}`, name: data.name.trim(), phone: data.phone.trim(), passwordHash: await hashPassword(data.password), role: 'buyer', phoneVerified: true, verified: false, status: 'active' };
    db.users.push(user); saveDb(); saveSession(user); ui.view = 'home'; showToast('تم إنشاء الحساب وتوثيق الرقم في النموذج التجريبي'); render(); return;
  }
  if (form.id === 'sale-form') {
    const user = currentUser();
    db.sales.unshift({ id: `sale-${Date.now()}`, name: data.name.trim(), price: Number(data.price), category: data.category, condition: data.condition, emoji: categoryEmoji(data.category), sellerId: user.id, seller: user.name, phone: user.phone, phoneVerified: user.phoneVerified, sellerVerified: user.verified, city: 'مسعد', description: data.description.trim(), status: 'pending', visible: false, rating: 0, reviewCount: 0, createdAt: 'الآن', shopId: null, reviewEligible: false });
    saveDb(); showToast('تم إرسال المبيعة للمراجعة'); ui.view = 'account'; render(); return;
  }
  if (form.id === 'chat-form') {
    const message = data.message.trim();
    if (!message) return;
    let chat = db.messages.find(item => item.saleId === ui.chatSaleId && item.buyerId === currentUser()?.id);
    const sale = getSale(ui.chatSaleId);
    if (!chat) { chat = { id: `chat-${Date.now()}`, saleId: ui.chatSaleId, buyerId: currentUser().id, sellerId: sale.sellerId, messages: [] }; db.messages.push(chat); }
    chat.messages.push({ from: currentUser().id === chat.buyerId ? 'buyer' : 'seller', text: message }); saveDb(); renderModal(); showToast('تم إرسال الرسالة'); return;
  }
  if (form.id === 'review-form') {
    const sale = getSale(ui.selectedSaleId);
    if (!sale?.reviewEligible || sale.sellerId === currentUser().id) { showToast('التقييم متاح بعد شراء فعلي موثّق فقط'); return; }
    db.reviews.push({ id: `review-${Date.now()}`, saleId: sale.id, userId: currentUser().id, name: currentUser().name, rating: Number(data.rating), text: data.text.trim(), date: 'الآن', status: 'published' });
    const reviews = db.reviews.filter(review => review.saleId === sale.id && review.status === 'published');
    sale.reviewCount = reviews.length; sale.rating = reviews.reduce((sum, review) => sum + Number(review.rating), 0) / reviews.length; saveDb(); ui.modal = null; showToast('تم نشر تقييمك'); render(); return;
  }
  if (form.id === 'shop-form') {
    db.shops.push({ id: `shop-${Date.now()}`, name: data.name.trim(), owner: data.owner.trim(), phone: data.phone.trim(), location: data.location.trim(), description: data.description.trim(), status: 'pending', featured: false, emoji: '🏪', userId: currentUser().id });
    saveDb(); ui.modal = null; showToast('تم إرسال طلب تسجيل المحل'); render(); return;
  }
  if (form.id === 'verification-form') {
    db.verificationRequests.push({ id: `verify-${Date.now()}`, userId: currentUser().id, name: currentUser().name, type: 'حساب موثق', status: 'pending', date: 'اليوم' });
    saveDb(); ui.modal = null; showToast('وصل طلب التوثيق إلى الإدارة'); render(); return;
  }
}

function categoryEmoji(category) { return categories.find(([, label]) => label === category)?.[0] || '📦'; }

function handleAction(element) {
  const action = element.dataset.action;
  const id = element.dataset.id;
  const value = element.dataset.value;
  if (action === 'auth-mode') { ui.authMode = value; renderAuth(); return; }
  if (action === 'forgot') { showToast('سيصل رابط الاستعادة إلى رقم هاتفك بعد ربط SMS في النسخة الإنتاجية'); return; }
  if (action === 'go') { ui.view = value; if (value === 'shops') { ui.searchQuery = ''; ui.mySalesOnly = false; } else if (value !== 'search') { ui.searchQuery = ''; ui.mySalesOnly = false; } else { ui.mySalesOnly = false; } render(); return; }
  if (action === 'notifications') { showToast('لا توجد إشعارات جديدة'); return; }
  if (action === 'logout') { clearSession(); ui.view = 'home'; ui.authMode = 'login'; showToast('تم تسجيل الخروج بأمان'); render(); return; }
  if (action === 'category') { ui.selectedCategory = value; ui.searchQuery = ''; ui.mySalesOnly = false; ui.view = 'search'; render(); return; }
  if (action === 'clear-category') { ui.selectedCategory = ''; ui.mySalesOnly = false; render(); return; }
  if (action === 'toggle-filters') { ui.filterOpen = !ui.filterOpen; render(); return; }
  if (action === 'open-sale') { ui.selectedSaleId = id; ui.view = 'detail'; render(); return; }
  if (action === 'open-shop') { ui.selectedShopId = id; ui.view = 'shop'; render(); return; }
  if (action === 'back') { ui.view = 'home'; render(); return; }
  if (action === 'favorite') {
    const user = currentUser(); const index = db.favorites.findIndex(fav => fav.userId === user.id && fav.saleId === id);
    if (index >= 0) { db.favorites.splice(index, 1); showToast('أزيلت من المفضلة'); } else { db.favorites.push({ userId: user.id, saleId: id }); showToast('أضيفت إلى المفضلة'); }
    saveDb(); render(); return;
  }
  if (action === 'call') { const sale = getSale(id); showToast(`سيتم الاتصال بـ ${sale?.seller || 'البائع'} على ${sale?.phone || ''}`); return; }
  if (action === 'message') { ui.chatSaleId = id; ui.modal = 'chat'; renderModal(); return; }
  if (action === 'report') { ui.selectedSaleId = id; ui.modal = 'report'; renderModal(); return; }
  if (action === 'submit-report') { db.reports.push({ id: `report-${Date.now()}`, saleId: id, reason: value, reporter: currentUser().name, status: 'open', date: 'اليوم' }); saveDb(); ui.modal = null; showToast('تم إرسال البلاغ إلى الإدارة'); render(); return; }
  if (action === 'open-review') { ui.selectedSaleId = id; ui.modal = 'review'; renderModal(); return; }
  if (action === 'close-modal') { ui.modal = null; renderModal(); return; }
  if (action === 'upload') { showToast('يمكن ربط اختيار الصور وتخزينها السحابيًا في النسخة الإنتاجية'); return; }
  if (action === 'messages') { const first = db.messages.find(chat => chat.buyerId === currentUser().id || chat.sellerId === currentUser().id); if (first) { ui.chatSaleId = first.saleId; ui.modal = 'chat'; renderModal(); } else showToast('لا توجد محادثات بعد'); return; }
  if (action === 'shop-request') { ui.modal = 'shop-request'; renderModal(); return; }
  if (action === 'verification') { ui.modal = 'verification'; renderModal(); return; }
  if (action === 'my-sales') { ui.view = 'search'; ui.searchQuery = ''; ui.selectedCategory = ''; ui.mySalesOnly = true; showToast('هذه مبيعاتك وحالات مراجعتها'); render(); return; }
  if (action === 'admin-tab' && isAdmin()) { ui.adminTab = value; render(); return; }
  if (action === 'admin-action' && isAdmin()) { adminAction(value, id); return; }
}

function adminAction(action, id) {
  if (action === 'approve-sale') { const sale = getSale(id); sale.status = 'published'; sale.visible = true; showToast('تم قبول المبيعة ونشرها'); }
  if (action === 'reject-sale') { const sale = getSale(id); sale.status = 'rejected'; sale.visible = false; showToast('تم رفض المبيعة'); }
  if (action === 'hide-sale') { const sale = getSale(id); sale.visible = sale.visible === false; showToast(sale.visible ? 'تم إظهار المبيعة' : 'تم إخفاء المبيعة'); }
  if (action === 'delete-sale') { db.sales = db.sales.filter(sale => sale.id !== id); showToast('تم حذف المبيعة'); }
  if (action === 'toggle-user') { const user = getUser(id); user.status = user.status === 'blocked' ? 'active' : 'blocked'; showToast(user.status === 'blocked' ? 'تم حظر المستخدم' : 'تم إلغاء الحظر'); }
  if (action === 'approve-shop') { const shop = getShop(id); shop.status = 'approved'; showToast('تم قبول تسجيل المحل'); }
  if (action === 'reject-shop') { const shop = getShop(id); shop.status = 'rejected'; showToast('تم رفض تسجيل المحل'); }
  if (action === 'toggle-featured') { const shop = getShop(id); shop.featured = !shop.featured; showToast(shop.featured ? 'أضيف إلى المحلات المميزة' : 'أزيل من المحلات المميزة'); }
  if (action === 'approve-verification' || action === 'reject-verification') { const req = db.verificationRequests.find(item => item.id === id); req.status = action === 'approve-verification' ? 'approved' : 'rejected'; const user = getUser(req.userId); if (user) user.verified = req.status === 'approved'; showToast(req.status === 'approved' ? 'تم توثيق الحساب' : 'تم رفض طلب التوثيق'); }
  if (action === 'resolve-report') { const report = db.reports.find(item => item.id === id); report.status = 'resolved'; showToast('تمت معالجة البلاغ'); }
  if (action === 'hide-reported') { const report = db.reports.find(item => item.id === id); const sale = getSale(report.saleId); if (sale) sale.visible = false; report.status = 'resolved'; showToast('تم إخفاء المبيعة ومعالجة البلاغ'); }
  if (action === 'delete-review') { db.reviews = db.reviews.filter(review => review.id !== id); showToast('تم حذف التعليق المخالف'); }
  saveDb(); render();
}

app.addEventListener('click', event => {
  const element = event.target.closest('[data-action]');
  if (element) handleAction(element);
});
app.addEventListener('submit', event => { event.preventDefault(); handleSubmit(event.target); });
app.addEventListener('change', event => {
  if (event.target.id === 'condition-filter') { ui.condition = event.target.value; render(); }
  if (event.target.id === 'sort-filter') { ui.sort = event.target.value; render(); }
  if (event.target.id === 'min-price') { ui.minPrice = event.target.value; render(); }
  if (event.target.id === 'max-price') { ui.maxPrice = event.target.value; render(); }
});
app.addEventListener('keydown', event => {
  if (event.key === 'Escape' && ui.modal) { ui.modal = null; renderModal(); }
});
document.addEventListener('click', event => {
  const element = event.target.closest('[data-action]');
  if (element && !app.contains(element)) handleAction(element);
});

document.addEventListener('submit', event => {
  if (event.target.id === 'hero-search' || event.target.id === 'search-form') {
    event.preventDefault(); const form = new FormData(event.target); ui.searchQuery = String(form.get('query') || '').trim(); ui.view = 'search'; render();
  } else if (!app.contains(event.target)) {
    event.preventDefault(); handleSubmit(event.target);
  }
});

if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
render();
