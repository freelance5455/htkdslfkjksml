package com.freefire.cheat.game;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import java.util.List;

public class GameDetector {
    private static final String TAG = "GameDetector";
    private static final String FREE_FIRE_PACKAGE = "com.garena.game.kgidb";
    private static final String FREE_FIRE_NAME = "Free Fire";
    
    private Context context;
    private boolean isGameRunning = false;
    private int gamePid = -1;
    
    public GameDetector(Context context) {
        this.context = context;
    }
    
    /**
     * Verifica se o Free Fire está rodando
     */
    public boolean isGameRunning() {
        ActivityManager manager = (ActivityManager) 
            context.getSystemService(Context.ACTIVITY_SERVICE);
        
        List<ActivityManager.RunningAppProcessInfo> processes = 
            manager.getRunningAppProcesses();
        
        for (ActivityManager.RunningAppProcessInfo process : processes) {
            if (process.processName.equals(FREE_FIRE_PACKAGE)) {
                isGameRunning = true;
                gamePid = process.pid;
                Log.d(TAG, "Free Fire detectado! PID: " + gamePid);
                return true;
            }
        }
        
        isGameRunning = false;
        return false;
    }
    
    /**
     * Obtém PID do jogo
     */
    public int getGamePid() {
        return gamePid;
    }
    
    /**
     * Verifica se estamos em modo jogo
     */
    public boolean isInGameMode() {
        return isGameRunning() && isOverlayActive();
    }
    
    /**
     * Verifica se overlay está ativo
     */
    private boolean isOverlayActive() {
        // Verifica se o serviço de overlay está rodando
        ActivityManager manager = (ActivityManager) 
            context.getSystemService(Context.ACTIVITY_SERVICE);
        
        List<ActivityManager.RunningServiceInfo> services = 
            manager.getRunningServices(100);
        
        for (ActivityManager.RunningServiceInfo service : services) {
            if (service.service.getPackageName().contains("cheat")) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Espera até o jogo iniciar
     */
    public void waitForGame() {
        while (!isGameRunning()) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                break;
            }
        }
        Log.d(TAG, "Jogo iniciado!");
    }
}