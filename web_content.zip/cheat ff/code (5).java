package com.freefire.cheat.render;

import android.graphics.*;
import android.view.View;

public class EspRenderer {
    private Paint boxPaint;
    private Paint linePaint;
    private Paint textPaint;
    private Paint healthBarPaint;
    
    public EspRenderer() {
        initPaints();
    }
    
    private void initPaints() {
        // Caixa do ESP
        boxPaint = new Paint();
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(3);
        boxPaint.setColor(Color.RED);
        boxPaint.setAntiAlias(true);
        
        // Linha de conexão
        linePaint = new Paint();
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(2);
        linePaint.setColor(Color.YELLOW);
        linePaint.setPathEffect(createDashPathEffect());
        
        // Texto
        textPaint = new Paint();
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(14);
        textPaint.setAntiAlias(true);
        
        // Barra de vida
        healthBarPaint = new Paint();
        healthBarPaint.setStyle(Paint.Style.FILL);
    }
    
    private DashPathEffect createDashPathEffect() {
        return new DashPathEffect(new float[]{10, 5}, 0);
    }
    
    /**
     * Desenha caixa ESP ao redor do jogador
     */
    public void drawBox(Canvas canvas, Player player) {
        // Caixa principal
        canvas.drawRect(player.x, player.y, 
                       player.x + player.width, player.y + player.height, 
                       boxPaint);
        
        // Cantos destacados
        int cornerSize = 10;
        Paint cornerPaint = new Paint();
        cornerPaint.setStyle(Paint.Style.STROKE);
        cornerPaint.setStrokeWidth(4);
        cornerPaint.setColor(Color.CYAN);
        
        // Canto superior esquerdo
        canvas.drawLine(player.x, player.y, 
                       player.x, player.y + cornerSize, cornerPaint);
        canvas.drawLine(player.x, player.y, 
                       player.x + cornerSize, player.y, cornerPaint);
        
        // Canto superior direito
        canvas.drawLine(player.x + player.width, player.y, 
                       player.x + player.width, player.y + cornerSize, cornerPaint);
        canvas.drawLine(player.x + player.width, player.y, 
                       player.x + player.width - cornerSize, player.y, cornerPaint);
        
        // Canto inferior esquerdo
        canvas.drawLine(player.x, player.y + player.height, 
                       player.x, player.y + player.height - cornerSize, cornerPaint);
        canvas.drawLine(player.x, player.y + player.height, 
                       player.x + cornerSize, player.y + player.height, cornerPaint);
        
        // Canto inferior direito
        canvas.drawLine(player.x + player.width, player.y + player.height, 
                       player.x + player.width, player.y + player.height - cornerSize, cornerPaint);
        canvas.drawLine(player.x + player.width, player.y + player.height, 
                       player.x + player.width - cornerSize, player.y + player.height, cornerPaint);
    }
    
    /**
     * Desenha linha de conexão até o jogador
     */
    public void drawConnectionLine(Canvas canvas, PointF playerPos, PointF cameraPos) {
        canvas.drawLine(cameraPos.x, cameraPos.y, 
                       playerPos.x, playerPos.y, 
                       linePaint);
    }
    
    /**
     * Desenha informação do jogador
     */
    public void drawInfo(Canvas canvas, Player player) {
        String info = String.format("%d HP - %.0fm", 
                                   player.health, 
                                   player.distance);
        
        // Fundo semi-transparente
        Rect background = new Rect(
            (int)player.x, 
            (int)player.y - 25, 
            (int)(player.x + player.width), 
            (int)player.y - 5
        );
        
        Paint bgPaint = new Paint();
        bgPaint.setColor(Color.parseColor("#80000000"));
        canvas.drawRect(background, bgPaint);
        
        // Texto
        canvas.drawText(info, player.x, player.y - 8, textPaint);
    }
    
    /**
     * Desenha barra de vida
     */
    public void drawHealthBar(Canvas canvas, Player player) {
        int barWidth = (int)(player.width * (player.health / 100f));
        
        // Cor baseada na vida
        if (player.health > 50) {
            healthBarPaint.setColor(Color.GREEN);
        } else if (player.health > 25) {
            healthBarPaint.setColor(Color.YELLOW);
        } else {
            healthBarPaint.setColor(Color.RED);
        }
        
        // Barra de vida
        canvas.drawRect(player.x, player.y - 10, 
                       player.x + barWidth, player.y, 
                       healthBarPaint);
        
        // Borda
        Paint borderPaint = new Paint();
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1);
        borderPaint.setColor(Color.BLACK);
        canvas.drawRect(player.x, player.y - 10, 
                       player.x + player.width, player.y, 
                       borderPaint);
    }
    
    /**
     * Desenha nome do jogador
     */
    public void drawName(Canvas canvas, Player player) {
        Paint namePaint = new Paint();
        namePaint.setColor(Color.WHITE);
        namePaint.setTextSize(12);
        namePaint.setFakeBoldText(true);
        
        canvas.drawText(player.name, player.x, player.y + player.height + 15, namePaint);
    }
    
    public static class Player {
        float x, y, width, height;
        int health;
        float distance;
        String name;
        PointF screenPos;
        
        public Player(float x, float y, float width, float height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
    }
}