package com.freefire.cheat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

public class MainActivity extends AppCompatActivity {
    
    private EditText ipInput;
    private Button connectBtn;
    private Switch espSwitch;
    private Switch aimbotSwitch;
    private TextView statusText;
    private CheckBox notifAlert;
    private CheckBox notifAim;
    private CheckBox notifConnect;
    
    private boolean isOverlayAllowed = false;
    private String deviceIp = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initViews();
        createNotificationChannel();
        checkOverlayPermission();
        getDeviceIp();
        
        setupListeners();
    }

    private void initViews() {
        ipInput = findViewById(R.id.ipAddress);
        connectBtn = findViewById(R.id.connectBtn);
        espSwitch = findViewById(R.id.espSwitch);
        aimbotSwitch = findViewById(R.id.aimbotSwitch);
        statusText = findViewById(R.id.statusText);
        notifAlert = findViewById(R.id.notifAlert);
        notifAim = findViewById(R.id.notifAim);
        notifConnect = findViewById(R.id.notifConnect);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                "CHEAT_CHANNEL",
                "Free Fire Cheats",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Notificações do cheat");
            
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
        }
    }

    private void checkOverlayPermission() {
        isOverlayAllowed = Settings.canDrawOverlays(this);
        if (!isOverlayAllowed) {
            showToast("Permita 'Desenho sobre outros apps' nas configurações!");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
        }
    }

    private void getDeviceIp() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface iface = interfaces.nextElement();
                if (iface.isLoopback() || !iface.isUp()) continue;
                
                Enumeration<InetAddress> addresses = iface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress addr = addresses.nextElement();
                    if (!addr.isLoopbackAddress() && addr instanceof java.net.Inet4Address) {
                        deviceIp = addr.getHostAddress();
                        ipInput.setText(deviceIp);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupListeners() {
        connectBtn.setOnClickListener(v -> {
            String ip = ipInput.getText().toString().trim();
            if (ip.isEmpty()) {
                showToast("Digite um IP válido!");
                return;
            }
            
            // Testa conexão
            if (testConnection(ip)) {
                statusText.setText("✅ Conectado via Wi-Fi");
                statusText.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                startService(new Intent(this, OverlayService.class));
                showToast("Serviço iniciado! Abra o Free Fire.");
                
                // Solicita notificações
                requestNotifications();
            } else {
                statusText.setText("❌ Falha na conexão");
                statusText.setTextColor(getResources().getColor(android.R.color.holo_red_light));
            }
        });

        espSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Envia sinal para o serviço
            Intent intent = new Intent("TOGGLE_ESP");
            intent.putExtra("enabled", isChecked);
            sendBroadcast(intent);
        });

        aimbotSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Intent intent = new Intent("TOGGLE_AIMBOT");
            intent.putExtra("enabled", isChecked);
            sendBroadcast(intent);
        });
    }

    private boolean testConnection(String ip) {
        try {
            return InetAddress.getByName(ip).isReachable(3000);
        } catch (Exception e) {
            return false;
        }
    }

    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ pede permissão explicitamente
            // Você precisa adicionar a permissão POST_NOTIFICATIONS no manifest
            showToast("Permita notificações nas configurações do app");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Registra receiver para mudanças de estado
        IntentFilter filter = new IntentFilter();
        filter.addAction("TOGGLE_ESP");
        filter.addAction("TOGGLE_AIMBOT");
        registerReceiver(overlayReceiver, filter);
    }

    private final BroadcastReceiver overlayReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("TOGGLE_ESP".equals(action)) {
                // Atualiza estado do ESP
            } else if ("TOGGLE_AIMBOT".equals(action)) {
                // Atualiza estado do Aimbot
            }
        }
    };
}