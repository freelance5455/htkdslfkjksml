class FreeFireADBOverlay {
    constructor() {
        this.adbConnected = false;
        this.overlayActive = false;
        this.permissionsGranted = false;
        
        // Configurações do overlay
        this.config = {
            fovSize: 150,
            boxWidth: 40,
            lineThickness: 2,
            showFov: true,
            showEspBox: true,
            showLine: true,
            showAimPoint: false
        };
        
        this.initElements();
        this.bindEvents();
        this.checkADBConnection();
    }

    initElements() {
        this.elements = {
            btnConnect: document.getElementById('btnConnect'),
            btnStartOverlay: document.getElementById('btnStartOverlay'),
            btnGrantPermission: document.getElementById('btnGrantPermission'),
            fovSize: document.getElementById('fovSize'),
            boxWidth: document.getElementById('boxWidth'),
            lineThickness: document.getElementById('lineThickness'),
            showFov: document.getElementById('showFov'),
            showEspBox: document.getElementById('showEspBox'),
            showLine: document.getElementById('showLine'),
            showAimPoint: document.getElementById('showAimPoint'),
            fovValue: document.getElementById('fovValue'),
            boxWidthValue: document.getElementById('boxWidthValue'),
            lineThicknessValue: document.getElementById('lineThicknessValue'),
            adbStatus: document.getElementById('adbStatus'),
            overlayStatus: document.getElementById('overlayStatus'),
            permStatus: document.getElementById('permStatus'),
            overlayCanvas: document.getElementById('overlayCanvas'),
            logContainer: document.getElementById('logContainer')
        };
    }

    bindEvents() {
        // Botões principais
        this.elements.btnConnect.addEventListener('click', () => this.connectADB());
        this.elements.btnStartOverlay.addEventListener('click', () => this.toggleOverlay());
        this.elements.btnGrantPermission.addEventListener('click', () => this.grantADBPermission());

        // Sliders de configuração
        this.elements.fovSize.addEventListener('input', (e) => {
            this.config.fovSize = parseInt(e.target.value);
            this.elements.fovValue.textContent = `${this.config.fovSize}px`;
            this.updateOverlay();
        });

        this.elements.boxWidth.addEventListener('input', (e) => {
            this.config.boxWidth = parseInt(e.target.value);
            this.elements.boxWidthValue.textContent = `${this.config.boxWidth}px`;
            this.updateOverlay();
        });

        this.elements.lineThickness.addEventListener('input', (e) => {
            this.config.lineThickness = parseInt(e.target.value);
            this.elements.lineThicknessValue.textContent = `${this.config.lineThickness}px`;
            this.updateOverlay();
        });

        // Checkboxes
        this.elements.showFov.addEventListener('change', (e) => {
            this.config.showFov = e.target.checked;
            this.updateOverlay();
        });

        this.elements.showEspBox.addEventListener('change', (e) => {
            this.config.showEspBox = e.target.checked;
            this.updateOverlay();
        });

        this.elements.showLine.addEventListener('change', (e) => {
            this.config.showLine = e.target.checked;
            this.updateOverlay();
        });

        this.elements.showAimPoint.addEventListener('change', (e) => {
            this.config.showAimPoint = e.target.checked;
            this.updateOverlay();
        });
    }

    async connectADB() {
        try {
            this.log('Conectando ao dispositivo ADB...', 'info');
            
            // Simula conexão ADB
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            this.adbConnected = true;
            this.updateADBStatus();
            this.log('Dispositivo ADB conectado com sucesso!', 'success');
            
        } catch (error) {
            this.log(`Erro ao conectar ADB: ${error.message}`, 'error');
        }
    }

    async grantADBPermission() {
        try {
            this.log('Solicitando permissão ADB...', 'info');
            
            // Simula concessão de permissão ADB
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            this.permissionsGranted = true;
            this.updatePermissionStatus();
            this.log('Permissão ADB concedida!', 'success');
            
        } catch (error) {
            this.log(`Erro ao conceder permissão: ${error.message}`, 'error');
        }
    }

    toggleOverlay() {
        if (!this.adbConnected || !this.permissionsGranted) {
            this.log('Conecte o ADB e conceda permissões primeiro!', 'warning');
            return;
        }

        if (this.overlayActive) {
            this.stopOverlay();
        } else {
            this.startOverlay();
        }
    }

    startOverlay() {
        this.overlayActive = true;
        this.elements.overlayCanvas.classList.remove('hidden');
        this.updateOverlayStatus();
        this.log('Overlay iniciado!', 'success');
        
        // Inicia loop de renderização
        this.renderLoop();
    }

    stopOverlay() {
        this.overlayActive = false;
        this.elements.overlayCanvas.classList.add('hidden');
        this.updateOverlayStatus();
        this.log('Overlay parado', 'info');
    }

    updateOverlay() {
        if (this.overlayActive) {
            this.renderOverlay();
        }
    }

    renderLoop() {
        const render = () => {
            if (this.overlayActive) {
                this.renderOverlay();
                requestAnimationFrame(render);
            }
        };
        requestAnimationFrame(render);
    }

    renderOverlay() {
        const canvas = this.elements.overlayCanvas;
        const ctx = canvas.getContext('2d');
        
        // Limpa o canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        
        // Desenha FOV
        if (this.config.showFov) {
            ctx.strokeStyle = '#ff0000';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(centerX, centerY, this.config.fovSize, 0, Math.PI * 2);
            ctx.stroke();
        }
        
        // Desenha ESP Box (simulado)
        if (this.config.showEspBox) {
            ctx.strokeStyle = '#00ff00';
            ctx.lineWidth = 1;
            const boxSize = this.config.boxWidth;
            ctx.strokeRect(centerX - boxSize, centerY - boxSize, boxSize * 2, boxSize * 2);
        }
        
        // Desenha Linhas (simulado)
        if (this.config.showLine) {
            ctx.strokeStyle = '#ffff00';
            ctx.lineWidth = this.config.lineThickness;
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(canvas.width, centerY);
            ctx.stroke();
            
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(centerX, canvas.height);
            ctx.stroke();
        }
        
        // Desenha ponto de mira
        if (this.config.showAimPoint) {
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(centerX, centerY, 3, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    checkADBConnection() {
        this.updateADBStatus();
    }

    updateADBStatus() {
        const statusClass = this.adbConnected ? 'active' : 'off';
        const statusText = this.adbConnected ? 'Conectado' : 'Desconectado';
        
        this.elements.adbStatus.className = `status ${statusClass}`;
        this.elements.adbStatus.textContent = statusText;
    }

    updatePermissionStatus() {
        const statusClass = this.permissionsGranted ? 'active' : 'pending';
        const statusText = this.permissionsGranted ? 'Concedida' : 'Pendente';
        
        this.elements.permStatus.className = `status ${statusClass}`;
        this.elements.permStatus.textContent = statusText;
    }

    updateOverlayStatus() {
        const statusClass = this.overlayActive ? 'active' : 'pending';
        const statusText = this.overlayActive ? 'Ativo' : 'Inativo';
        
        this.elements.overlayStatus.className = `status ${statusClass}`;
        this.elements.overlayStatus.textContent = statusText;
    }

    log(message, type = 'info') {
        const logEntry = document.createElement('div');
        logEntry.className = `log-entry ${type}`;
        logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        
        this.elements.logContainer.appendChild(logEntry);
        this.elements.logContainer.scrollTop = this.elements.logContainer.scrollHeight;
        
        // Limita número de logs
        if (this.elements.logContainer.children.length > 50) {
            this.elements.logContainer.removeChild(this.elements.logContainer.firstChild);
        }
    }
}

// Inicializa quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
    new FreeFireADBOverlay();
});