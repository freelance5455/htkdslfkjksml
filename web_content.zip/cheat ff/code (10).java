package com.freefire.cheat.memory;

import android.util.Log;
import java.io.*;
import java.util.*;

public class MemoryScanner {
    private static final String TAG = "MemoryScanner";
    private int pid;
    private String procPath;
    
    public MemoryScanner(int pid) {
        this.pid = pid;
        this.procPath = "/proc/" + pid;
    }
    
    /**
     * Lê memória do processo
     */
    public byte[] readMemory(long address, int size) {
        try {
            RandomAccessFile raf = new RandomAccessFile(
                procPath + "/mem", "r");
            
            raf.seek(address);
            byte[] buffer = new byte[size];
            raf.read(buffer);
            raf.close();
            
            return buffer;
        } catch (Exception e) {
            Log.e(TAG, "Erro ao ler memória: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Escreve na memória
     */
    public boolean writeMemory(long address, byte[] data) {
        try {
            RandomAccessFile raf = new RandomAccessFile(
                procPath + "/mem", "rw");
            
            raf.seek(address);
            raf.write(data);
            raf.close();
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Erro ao escrever memória: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Procura padrão de bytes na memória
     */
    public List<Long> patternScan(byte[] pattern, byte[] mask) {
        List<Long> results = new ArrayList<>();
        
        // Lê todo o memory map
        String maps = readFile("/proc/" + pid + "/maps");
        if (maps == null) return results;
        
        // Analisa cada segmento
        String[] lines = maps.split("\n");
        for (String line : lines) {
            if (line.contains("rw-p") || line.contains("r-xp")) {
                String[] parts = line.split(" ");
                String range = parts[0];
                String[] addrs = range.split("-");
                
                long start = Long.parseLong(addrs[0], 16);
                long end = Long.parseLong(addrs[1], 16);
                int size = (int)(end - start);
                
                // Lê segmento e procura padrão
                byte[] segment = readMemory(start, size);
                if (segment != null) {
                    List<Long> found = searchPattern(segment, pattern, mask);
                    for (long addr : found) {
                        results.add(start + addr);
                    }
                }
            }
        }
        
        return results;
    }
    
    private List<Long> searchPattern(byte[] data, byte[] pattern, byte[] mask) {
        List<Long> results = new ArrayList<>();
        
        for (int i = 0; i <= data.length - pattern.length; i++) {
            boolean match = true;
            for (int j = 0; j < pattern.length; j++) {
                if (mask[j] == 'x' && data[i + j] != pattern[j]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                results.add((long)i);
            }
        }
        
        return results;
    }
    
    private String readFile(String path) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Obtém PID do Free Fire
     */
    public static int getFreeFirePid() {
        try {
            Process process = Runtime.getRuntime().exec(
                "ps | grep com.garena.game.kgidb");
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream()));
            
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\s+");
                if (parts.length > 0) {
                    return Integer.parseInt(parts[1]);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return -1;
    }
}