package com.freefire.cheat;

import android.app.Application;
import android.util.Log;
import com.freefire.cheat.controller.CheatController;

public class FFApplication extends Application {
    private static final String TAG = "FFApplication";
    private CheatController cheatController;
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Aplicação iniciada");
        
        // Inicializa controlador de cheats
        cheatController = new CheatController(this);
        
        // Guarda referência global
        AppHolder.setCheatController(cheatController);
    }
    
    public CheatController getCheatController() {
        return cheatController;
    }
    
    // Classe holder para acesso global
    public static class AppHolder {
        private static CheatController controller;
        
        public static void setCheatController(CheatController c) {
            controller = c;
        }
        
        public static CheatController getCheatController() {
            return controller;
        }
    }
}