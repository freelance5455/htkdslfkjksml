package com.freefire.cheat.antiban;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class AntiBanManager {
    private static final String TAG = "AntiBanManager";
    private static final String PREFS_NAME = "antiban_config";
    private static final String KEY_BLACKLIST_COUNT = "blacklist_count";
    private static final String KEY_LAST_CHECK = "last_check";
    private static final String KEY_STEALTH_MODE = "stealth_mode";
    
    private Context context;
    private SharedPreferences prefs;
    private ConcurrentHashMap<String, Long> detectionLog = new ConcurrentHashMap<>();
    private boolean stealthMode = false;
    private int blacklistCount = 0;
    private Timer antiBanTimer;
    private List<String> suspiciousActivities = new ArrayList<>();
    
    // Padrões de deteção comuns
    private static final String[] COMMON_DETECTIONS = {
        "overlay_detected",
        "accessibility_enabled",
        "root_detected",
        "debug_mode",
        "unusual_input_pattern",
        "fast_aim",
        "wallhack_usage"
    };
    
    // Fatores de risco
    private static final Map<String, Integer> RISK_FACTORS = new HashMap<>() {{
        put("overlay_detected", 15);
        put("accessibility_enabled", 10);
        put("root_detected", 25);
        put("debug_mode", 5);
        put("unusual_input_pattern", 20);
        put("fast_aim", 30);
        put("wallhack_usage", 20);
    }};
    
    public AntiBanManager(Context context) {
        this.context = context;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        loadState();
    }
    
    private void loadState() {
        blacklistCount = prefs.getInt(KEY_BLACKLIST_COUNT, 0);
        stealthMode = prefs.getBoolean(KEY_STEALTH_MODE, false);
    }
    
    private void saveState() {
        prefs.edit()
            .putInt(KEY_BLACKLIST_COUNT, blacklistCount)
            .putBoolean(KEY_STEALTH_MODE, stealthMode)
            .apply();
    }
    
    /**
     * Verifica se o dispositivo está em risco de banimento
     */
    public boolean isAtRisk() {
        int totalRisk = calculateTotalRisk();
        return totalRisk > 50; // Limiar de risco
    }
    
    /**
     * Calcula o risco total baseado nas atividades suspeitas
     */
    private int calculateTotalRisk() {
        int risk = 0;
        long now = System.currentTimeMillis();
        
        for (Map.Entry<String, Long> entry : detectionLog.entrySet()) {
            String activity = entry.getKey();
            long detectedAt = entry.getValue();
            
            // Se detectado nos últimos 5 minutos, conta o risco
            if (now - detectedAt < 300000) {
                risk += RISK_FACTORS.getOrDefault(activity, 10);
            }
        }
        
        // Penaliza por múltiplas detecções
        if (detectionLog.size() > 5) {
            risk += 20;
        }
        
        return risk;
    }
    
    /**
     * Registra uma atividade suspeita
     */
    public void logSuspiciousActivity(String activity) {
        detectionLog.put(activity, System.currentTimeMillis());
        
        // Adiciona à lista de atividades suspeitas
        if (!suspiciousActivities.contains(activity)) {
            suspiciousActivities.add(activity);
        }
        
        Log.d(TAG, "Actividade suspeita registada: " + activity);
        
        // Verifica se entra em modo furtivo
        if (isAtRisk() && !stealthMode) {
            enterStealthMode();
        }
    }
    
    /**
     * Entra em modo furtivo
     */
    public void enterStealthMode() {
        stealthMode = true;
        saveState();
        Log.d(TAG, "Modo furtivo ativado!");
        
        // Esconde overlay temporariamente
        hideOverlay();
        
        // Simula comportamento normal por 30 segundos
        scheduleExitStealth();
    }
    
    /**
     * Sai do modo furtivo
     */
    public void exitStealthMode() {
        stealthMode = false;
        saveState();
        Log.d(TAG, "Modo furtivo desativado");
        showOverlay();
    }
    
    /**
     * Esconde o overlay (simula fechamento)
     */
    private void hideOverlay() {
        // Aqui você esconde a vista sobreposta
        Log.d(TAG, "Overlay escondido");
    }
    
    /**
     * Mostra o overlay novamente
     */
    private void showOverlay() {
        // Aqui você mostra a vista sobreposta
        Log.d(TAG, "Overlay mostrado");
    }
    
    /**
     * Programa saída do modo furtivo
     */
    private void scheduleExitStealth() {
        new Thread(() -> {
            try {
                Thread.sleep(30000); // 30 segundos
                exitStealthMode();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    /**
     * Verifica se há root detectado
     */
    public boolean isRootDetected() {
        String[] paths = {
            "/system/app/Superuser.apk",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/bin/su",
            "/data/local/su",
            "/system/usr/we-need-root/superuser.apk"
        };
        
        for (String path : paths) {
            if (new File(path).exists()) {
                return true;
            }
        }
        
        // Tenta executar su
        try {
            Process process = Runtime.getRuntime().exec(new String[]{
                "su", "-c", "echo root"
            });
            int exitCode = process.waitFor();
            return exitCode == 0;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Verifica se debug mode está ativo
     */
    public boolean isDebugMode() {
        return android.os.Build.TAGS != null && 
               android.os.Build.TAGS.contains("dev-keys");
    }
    
    /**
     * Gera um ID único disfarcado
     */
    public String getDisguisedDeviceId() {
        String androidId = Settings.Secure.getString(
            context.getContentResolver(), 
            Settings.ANDROID_ID
        );
        
        // Mistura o ID com informações do app
        String mixed = androidId + context.getPackageName() + System.currentTimeMillis();
        
        // Retorna hash simplificado
        return Integer.toString(mixed.hashCode(), 36);
    }
    
    /**
     * Verifica blacklist periodicamente
     */
    public void startPeriodicCheck() {
        antiBanTimer = new Timer();
        antiBanTimer.scheduleAtFixedRate(new java.util.TimerTask() {
            @Override
            public void run() {
                checkBlacklist();
            }
        }, 0, 60000); // A cada 1 minuto
    }
    
    /**
     * Verifica se está na blacklist
     */
    private void checkBlacklist() {
        String deviceId = getDisguisedDeviceId();
        
        // Simula verificação contra servidor
        boolean isInBlacklist = simulateBlacklistCheck(deviceId);
        
        if (isInBlacklist) {
            blacklistCount++;
            saveState();
            Log.d(TAG, "Dispositivo na blacklist! Contagem: " + blacklistCount);
            
            if (blacklistCount > 3) {
                enterStealthMode();
            }
        }
    }
    
    /**
     * Simula verificação de blacklist
     */
    private boolean simulateBlacklistCheck(String deviceId) {
        // Aqui você faria uma chamada HTTP real ao seu servidor
        // Por agora, simula aleatoriamente
        Random random = new Random();
        return random.nextInt(100) < 5; // 5% de chance
    }
    
    /**
     * Limpa logs de deteção
     */
    public void clearDetectionLogs() {
        detectionLog.clear();
        suspiciousActivities.clear();
        Log.d(TAG, "Logs de deteção limpos");
    }
    
    /**
     * Obt estatísticas de anti-ban
     */
    public String getStats() {
        return String.format(
            "Blacklists: %d | Atividades Suspeitas: %d | Modo Furtivo: %s",
            blacklistCount,
            detectionLog.size(),
            stealthMode ? "SIM" : "NÃO"
        );
    }
    
    /**
     * Para o timer periódico
     */
    public void stop() {
        if (antiBanTimer != null) {
            antiBanTimer.cancel();
        }
    }
}