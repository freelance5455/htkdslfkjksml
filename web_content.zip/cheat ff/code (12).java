package com.freefire.cheat.config;

import android.content.Context;
import android.content.SharedPreferences;
import Gson.Gson;
import Gson.GsonBuilder;
import java.io.*;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class ConfigManager {
    private static final String CONFIG_FILE = "cheat_config.json";
    private Context context;
    private SharedPreferences prefs;
    private Gson gson;
    
    // Configurações padrão
    private Map<String, Object> config = new HashMap<>();
    
    public ConfigManager(Context context) {
        this.context = context;
        this.prefs = context.getSharedPreferences("config", Context.MODE_PRIVATE);
        this.gson = new GsonBuilder().create();
        loadDefaults();
        loadFromFile();
    }
    
    private void loadDefaults() {
        config.put("esp_enabled", false);
        config.put("aimbot_enabled", false);
        config.put("fov_radius", 200);
        config.put("smoothing", 0.5);
        config.put("anti_ban", true);
        config.put("stealth_mode", false);
        config.put("notifications", true);
        config.put("wifi_debug_port", 8080);
    }
    
    /**
     * Carrega configuração do ficheiro
     */
    private void loadFromFile() {
        try {
            FileInputStream fis = context.openFileInput(CONFIG_FILE);
            byte[] data = fis.readAllBytes();
            fis.close();
            
            String json = new String(data);
            Map<String, Object> loaded = gson.fromJson(json, 
                new TypeToken<Map<String, Object>>(){}.getType());
            
            if (loaded != null) {
                config.putAll(loaded);
            }
        } catch (Exception e) {
            // Usa defaults
        }
    }
    
    /**
     * Guarda configuração
     */
    public void save() {
        try {
            String json = gson.toJson(config);
            FileOutputStream fos = context.openFileOutput(CONFIG_FILE, 
                Context.MODE_PRIVATE);
            fos.write(json.getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Obtém valor
     */
    public Object get(String key) {
        return config.get(key);
    }
    
    /**
     * Define valor
     */
    public void set(String key, Object value) {
        config.put(key, value);
        save();
    }
    
    /**
     * Obtém booleano
     */
    public boolean getBoolean(String key, boolean defaultVal) {
        Object val = config.get(key);
        if (val instanceof Boolean) {
            return (Boolean) val;
        }
        return defaultVal;
    }
    
    /**
     * Obtém inteiro
     */
    public int getInt(String key, int defaultVal) {
        Object val = config.get(key);
        if (val instanceof Number) {
            return ((Number) val).intValue();
        }
        return defaultVal;
    }
    
    /**
     * Obtém string
     */
    public String getString(String key, String defaultVal) {
        Object val = config.get(key);
        if (val instanceof String) {
            return (String) val;
        }
        return defaultVal;
    }
    
    /**
     * Reseta para padrões
     */
    public void reset() {
        loadDefaults();
        save();
    }
}