package com.freefire.cheat.notifications;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

public class NotificationManager {
    private static final String CHANNEL_ID = "cheat_channel";
    private static final String CHANNEL_NAME = "Free Fire Cheats";
    private Context context;
    private NotificationManager nm;
    
    public NotificationManager(Context context) {
        this.context = context;
        this.nm = (NotificationManager) 
            context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel();
    }
    
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Notificações do cheat");
            channel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            nm.createNotificationChannel(channel);
        }
    }
    
    /**
     * Mostra notificação discreta
     */
    public void showSilentNotification(String title, String content) {
        NotificationCompat.Builder builder = 
            new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(Notification.VISIBILITY_SECRET)
            .setAutoCancel(true);
        
        nm.notify(1, builder.build());
    }
    
    /**
     * Mostra notificação persistente (para manter overlay vivo)
     */
    public void showPersistentNotification() {
        Intent notificationIntent = new Intent(context, 
            com.freefire.cheat.MainActivity.class);
        
        PendingIntent pendingIntent = PendingIntent.getActivity(
            context, 0, notificationIntent, 
            PendingIntent.FLAG_IMMUTABLE);
        
        Notification notification = new NotificationCompat.Builder(
            context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_report_image)
            .setContentTitle("Free Fire Cheats")
            .setContentText("ESP e Aimbot Ativos")
            .setContentIntent(pendingIntent)
            .setTicker("Cheats ativos")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build();
        
        // Inicia serviço como foreground
        android.content.Intent serviceIntent = 
            new android.content.Intent(context, 
            com.freefire.cheat.OverlayService.class);
        
        android.app.ActivityManager am = 
            (android.app.ActivityManager) context.getSystemService(
            Context.ACTIVITY_SERVICE);
        
        // Mantém serviço vivo
        context.startForegroundService(serviceIntent);
    }
    
    /**
     * Cancela notificação
     */
    public void cancelNotification() {
        nm.cancel(1);
    }
}