package com.freefire.cheat.utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Surface;
import android.view.Window;
import android.view.WindowManager;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

public class ScreenshotManager {
    private Context context;
    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private Handler handler = new Handler(Looper.getMainLooper());
    
    public ScreenshotManager(Context context) {
        this.context = context;
        this.projectionManager = (MediaProjectionManager) 
            context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
    }
    
    /**
     * Inicia captura de tela
     */
    public void startCapture(int resultCode, Intent data) {
        int width = 1080;
        int height = 1920;
        int dpi = 420;
        
        imageReader = ImageReader.newInstance(width, height, 
            PixelFormat.RGBA_8888, 2);
        
        mediaProjection = projectionManager.getMediaProjection(
            resultCode, data);
        
        virtualDisplay = mediaProjection.createVirtualDisplay(
            "Screenshot",
            width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.getSurface(),
            null, null);
    }
    
    /**
     * Captura screenshot
     */
    public void takeScreenshot(Runnable callback) {
        Image image = imageReader.acquireLatestImage();
        if (image == null) return;
        
        Buffer buffer = image.getPlanes()[0].getBuffer();
        int width = image.getWidth();
        int height = image.getHeight();
        int pixelStride = image.getPlanes()[0].getPixelStride();
        int rowStride = image.getPlanes()[0].getRowStride();
        
        Bitmap bitmap = Bitmap.createBitmap(
            width, height, Bitmap.Config.ARGB_8888);
        
        bitmap.copyPixelsFromBuffer(buffer);
        
        // Salva ou envia
        saveScreenshot(bitmap);
        
        image.close();
        
        if (callback != null) {
            callback.run();
        }
    }
    
    private void saveScreenshot(Bitmap bitmap) {
        String path = "/sdcard/Download/screenshot_" + 
            System.currentTimeMillis() + ".png";
        
        try (FileOutputStream out = new FileOutputStream(path)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Para captura
     */
    public void stop() {
        if (virtualDisplay != null) {
            virtualDisplay.release();
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
        }
    }
}