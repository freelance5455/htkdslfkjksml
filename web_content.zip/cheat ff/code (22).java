package com.freefire.cheat.monitor;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Process;
import android.util.Log;
import java.io.*;
import java.util.*;

public class ProcessMonitor {
    private static final String TAG = "ProcessMonitor";
    private Context context;
    private List<String> monitoredProcesses = new ArrayList<>();
    private Map<String, Integer> processPids = new HashMap<>();
    
    public ProcessMonitor(Context context) {
        this.context = context;
        addMonitoredProcess("com.garena.game.kgidb"); // Free Fire
        addMonitoredProcess("com.garena.game.kgidm"); // Free Fire Global
    }
    
    private void addMonitoredProcess(String packageName) {
        monitoredProcesses.add(packageName);
    }
    
    /**
     * Atualiza PIDs dos processos
     */
    public void updateProcessPids() {
        ActivityManager manager = (ActivityManager) 
            context.getSystemService(Context.ACTIVITY_SERVICE);
        
        List<ActivityManager.RunningAppProcessInfo> processes = 
            manager.getRunningAppProcesses();
        
        for (ActivityManager.RunningAppProcessInfo process : processes) {
            if (monitoredProcesses.contains(process.processName)) {
                processPids.put(process.processName, process.pid);
                Log.d(TAG, "Processo " + process.processName + 
                    " PID: " + process.pid);
            }
        }
    }
    
    /**
     * Obtém PID do Free Fire
     */
    public int getFreeFirePid() {
        updateProcessPids();
        
        for (String pkg : monitoredProcesses) {
            if (processPids.containsKey(pkg)) {
                return processPids.get(pkg);
            }
        }
        
        return -1;
    }
    
    /**
     * Verifica se processo está rodando
     */
    public boolean isProcessRunning(String packageName) {
        updateProcessPids();
        return processPids.containsKey(packageName);
    }
    
    /**
     * Mata processo
     */
    public void killProcess(String packageName) {
        int pid = getPid(packageName);
        if (pid > 0) {
            Process.killProcess(pid);
            Log.d(TAG, "Processo " + packageName + " morto");
        }
    }
    
    private int getPid(String packageName) {
        return processPids.getOrDefault(packageName, -1);
    }
    
    /**
     * Lista todos os processos
     */
    public List<String> getAllProcesses() {
        ActivityManager manager = (ActivityManager) 
            context.getSystemService(Context.ACTIVITY_SERVICE);
        
        List<ActivityManager.RunningAppProcessInfo> processes = 
            manager.getRunningAppProcesses();
        
        List<String> names = new ArrayList<>();
        for (ActivityManager.RunningAppProcessInfo process : processes) {
            names.add(process.processName);
        }
        
        return names;
    }
}