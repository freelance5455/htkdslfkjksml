package com.freefire.cheat.network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class NetworkManager {
    private static final String TAG = "NetworkManager";
    private Context context;
    private ExecutorService executor;
    private Handler mainHandler;
    
    public NetworkManager(Context context) {
        this.context = context;
        this.executor = Executors.newCachedThreadPool();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }
    
    /**
     * Verifica conexão
     */
    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) 
            context.getSystemService(Context.CONNECTIVITY_SERVICE);
        
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnected();
    }
    
    /**
     * Faz POST request
     */
    public String postRequest(String url, String data) {
        try {
            URL obj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
            
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            
            OutputStream os = conn.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();
            
            InputStream is = conn.getInputStream();
            BufferedReader br = new BufferedReader(
                new InputStreamReader(is));
            
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line);
            }
            
            br.close();
            is.close();
            
            return response.toString();
        } catch (Exception e) {
            Log.e(TAG, "Erro POST: " + e.getMessage());
            return "";
        }
    }
    
    /**
     * Faz GET request
     */
    public String getRequest(String url) {
        try {
            URL obj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
            
            conn.setRequestMethod("GET");
            
            InputStream is = conn.getInputStream();
            BufferedReader br = new BufferedReader(
                new InputStreamReader(is));
            
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line);
            }
            
            br.close();
            is.close();
            
            return response.toString();
        } catch (Exception e) {
            Log.e(TAG, "Erro GET: " + e.getMessage());
            return "";
        }
    }
    
    /**
     * Envia dados assincronamente
     */
    public void sendAsync(String url, String data, 
                         Runnable onSuccess, Runnable onError) {
        executor.execute(() -> {
            try {
                String response = postRequest(url, data);
                if (mainHandler != null) {
                    mainHandler.post(() -> {
                        if (onSuccess != null) onSuccess.run();
                    });
                }
            } catch (Exception e) {
                if (mainHandler != null) {
                    mainHandler.post(() -> {
                        if (onError != null) onError.run();
                    });
                }
            }
        });
    }
    
    /**
     * Fecha conexões
     */
    public void shutdown() {
        executor.shutdown();
    }
}