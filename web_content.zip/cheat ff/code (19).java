package com.freefire.cheat.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

public class Utils {
    private static final String TAG = "Utils";
    
    /**
     * Gera hash MD5
     */
    public static String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return input;
        }
    }
    
    /**
     * Gera UUID único
     */
    public static String generateUniqueId(Context context) {
        String androidId = Settings.Secure.getString(
            context.getContentResolver(), 
            Settings.ANDROID_ID);
        
        String packageName = context.getPackageName();
        String version = getVersionName(context);
        
        return md5(androidId + packageName + version);
    }
    
    /**
     * Obtém versão do app
     */
    public static String getVersionName(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(
                context.getPackageName(), 0);
            return pi.versionName;
        } catch (Exception e) {
            return "1.0";
        }
    }
    
    /**
     * Sleep seguro
     */
    public static void safeSleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    /**
     * Converte pixels para dp
     */
    public static float pxToDp(Context context, float px) {
        float density = context.getResources().getDisplayMetrics().density;
        return px / density;
    }
    
    /**
     * Converte dp para pixels
     */
    public static float dpToPx(Context context, float dp) {
        float density = context.getResources().getDisplayMetrics().density;
        return dp * density;
    }
    
    /**
     * Verifica se é root
     */
    public static boolean isRootAvailable() {
        return new File("/system/bin/su").exists() ||
               new File("/system/xbin/su").exists() ||
               new File("/data/local/bin/su").exists();
    }
    
    /**
     * Executa comando como root
     */
    public static String execAsRoot(String command) {
        try {
            Process process = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(
                process.getOutputStream());
            
            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();
            
            BufferedReader br = new BufferedReader(
                new InputStreamReader(
                    process.getInputStream()));
            
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line).append("\n");
            }
            
            br.close();
            return response.toString();
        } catch (Exception e) {
            Log.e(TAG, "Erro exec root: " + e.getMessage());
            return "";
        }
    }
    
    /**
     * Formata tamanho de arquivo
     */
    public static String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.2f KB", 
            bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.2f MB", 
            bytes / (1024.0 * 1024));
        return String.format("%.2f GB", 
            bytes / (1024.0 * 1024 * 1024));
    }
    
    /**
     * Formata tempo
     */
    public static String formatTime(long milliseconds) {
        long seconds = milliseconds / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        
        if (hours > 0) {
            return hours + "h " + (minutes % 60) + "m";
        } else if (minutes > 0) {
            return minutes + "m " + (seconds % 60) + "s";
        } else {
            return seconds + "s";
        }
    }
}