package com.freefire.cheat;

import android.app.Service;
import android.content.Intent;
import android.graphics.*;
import android.hardware.SensorManager;
import android.os.*;
import android.view.*;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private View overlayView;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean espEnabled = false;
    private boolean aimbotEnabled = false;
    private List<Player> players = new ArrayList<>();
    private Timer antiBanTimer;
    private int blacklistCheckCount = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createOverlay();
        startAntiBanProtection();
        startNotificationService();
    }

    private void createOverlay() {
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                PixelFormat.TRANSPARENT
        );

        overlayView = new View(this) {
            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                drawEsp(canvas);
                drawAimbotCrosshair(canvas);
                drawInfo(canvas);
            }
        };

        // Toque passa pelo overlay
        overlayView.setOnTouchListener((v, event) -> {
            if (aimbotEnabled && event.getAction() == MotionEvent.ACTION_DOWN) {
                performAimshot();
                return true;
            }
            return false;
        });

        windowManager.addView(overlayView, params);
    }

    private void drawEsp(Canvas canvas) {
        if (!espEnabled) return;

        Paint boxPaint = new Paint();
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(3);
        boxPaint.setColor(Color.RED);

        for (Player player : players) {
            // Desenha caixa ao redor do inimigo
            canvas.drawRect(player.x, player.y, player.x + player.width, player.y + player.height, boxPaint);

            // Barra de vida
            Paint healthBar = new Paint();
            healthBar.setColor(player.health > 50 ? Color.GREEN : Color.YELLOW);
            canvas.drawRect(player.x, player.y - 10, player.x + player.width, player.y, healthBar);

            // Nome e distância
            Paint textPaint = new Paint();
            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(14);
            canvas.drawText("Inimigo - " + player.distance + "m", player.x, player.y - 20, textPaint);
        }
    }

    private void drawAimbotCrosshair(Canvas canvas) {
        if (!aimbotEnabled) return;

        Paint crosshair = new Paint();
        crosshair.setColor(Color.RED);
        crosshair.setStrokeWidth(2);

        int centerX = getWindowWidth() / 2;
        int centerY = getWindowHeight() / 2;

        // Mira em cruz
        canvas.drawLine(centerX - 20, centerY, centerX + 20, centerY, crosshair);
        canvas.drawLine(centerX, centerY - 20, centerX, centerY + 20, crosshair);
        canvas.drawCircle(centerX, centerY, 5, crosshair);
    }

    private void performAimshot() {
        // Simula toque na tela para atirar
        Intent tapIntent = new Intent(Intent.ACTION_MEDIA_BUTTON);
        tapIntent.putExtra(Intent.EXTRA_KEYCODE, KeyEvent.KEYCODE_CAMERA);
        sendBroadcast(tapIntent);

        // Vibra para feedback
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v != null) v.vibrate(50);
    }

    private void startAntiBanProtection() {
        antiBanTimer = new Timer();
        antiBanTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                checkForBlacklist();
                heartBeat();
            }
        }, 0, 5000); // A cada 5 segundos
    }

    private void checkForBlacklist() {
        // Verifica se o dispositivo foi blacklisted
        String deviceId = Settings.Secure.getString getContentResolver(), Settings.ANDROID_ID);
        
        // Simula verificação contra servidor anti-cheat
        if (blacklistCheckCount > 10) {
            // Se detectado, altera comportamento para parecer legítimo
            toggleStealthMode();
        }
        blacklistCheckCount++;
    }

    private void toggleStealthMode() {
        // Modo furtivo: desliga cheats temporariamente
        espEnabled = false;
        aimbotEnabled = false;
        updateOverlay();
        
        Toast.makeText(this, "Modo Furtivo Ativado!", Toast.LENGTH_SHORT).show();
        
        // Reativa após 10 segundos
        handler.postDelayed(() -> {
            espEnabled = true;
            aimbotEnabled = true;
            updateOverlay();
        }, 10000);
    }

    private void heartBeat() {
        // Envia heartbeat para parecer app normal
        // Aqui você pode enviar dados para seu servidor
    }

    private void startNotificationService() {
        // Notifica quando cheats estão ativos
        if (espEnabled || aimbotEnabled) {
            NotificationCompat.Builder builder = 
                new NotificationCompat.Builder(this, "CHEAT_CHANNEL")
                .setSmallIcon(R.drawable.ic_cheat)
                .setContentTitle("Free Fire Cheats")
                .setContentText("ESP e Aimbot Ativos")
                .setPriority(NotificationCompat.PRIORITY_LOW);
            
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.notify(1, builder.build());
            }
        }
    }

    private int getWindowWidth() {
        return windowManager.getDefaultDisplay().getWidth();
    }

    private int getWindowHeight() {
        return windowManager.getDefaultDisplay().getHeight();
    }

    private void updateOverlay() {
        handler.post(() -> {
            if (overlayView != null) {
                overlayView.invalidate();
            }
        });
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (overlayView != null) {
            windowManager.removeView(overlayView);
        }
        if (antiBanTimer != null) {
            antiBanTimer.cancel();
        }
    }

    // Classe Player para ESP
    public static class Player {
        float x, y, width, height;
        int health;
        float distance;
    }
}