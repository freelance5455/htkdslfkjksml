PINPLAY - Lalu Biru update

Berkas index.html adalah versi PINPLAY yang menambahkan:
Lalu Biru — Eleanor Whisper
YouTube audio ID: KJcsD8LgzTs

Cara mencoba:
1. Buka index.html atau salin seluruh isinya ke panel HTML di CodePen.
2. Jalankan dan cari lagu "Lalu Biru".
3. Ketuk lagu untuk menguji pemutaran.

Catatan: video/audio YouTube dapat memiliki batasan pemutaran tertanam tergantung pada perangkat, browser, atau pemilik video.
