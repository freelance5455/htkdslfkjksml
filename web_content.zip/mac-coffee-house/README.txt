MAC COFFEE HOUSE APP
=====================

Files:
- mac-coffee.html: standalone browser app
- README.txt: this guide

ANDROID SETUP
1. Extract mac-coffee-house.zip using your phone's file manager.
2. Open mac-coffee.html in an HTML editor such as Acode.
3. Use Preview / Open in Browser.
4. Add products, prices, unit costs and initial stock.
5. Record sales and expenses; use Reports for estimates.
6. Use Reports > Backup JSON regularly to save business data.

IMPORTANT
- This is a browser-based prototype, not an APK.
- Data is saved locally in the browser on this device.
- Clearing browser data can erase saved records. Export backups regularly.
- No cloud sync, staff login, online payment integration, or certified tax receipts.
- Profit is only an estimate based on recorded costs and expenses.
