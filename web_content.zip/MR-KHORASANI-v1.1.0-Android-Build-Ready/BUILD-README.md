# MR-KHORASANI v1.1.0 — Android Build Package

این بسته عمداً فقط برای Build اندروید مرتب شده است.

## مشخصات
- Package ID: `com.mrkhrasani.finance`
- Version: `1.1.0` / versionCode `2`
- minSdk: `24`
- targetSdk / compileSdk: `35`
- Java: `17`
- Android Gradle Plugin: `8.7.3`
- Gradle: `8.13`

## Build واقعی با GitHub Actions
1. محتویات این پوشه را در یک Repository جدید GitHub قرار دهید، به‌طوری‌که `android/` و `.github/` مستقیماً در ریشه Repository باشند.
2. از Actions، Workflow با نام `Build MR KHORASANI Android APK` را اجرا کنید.
3. پس از سبز شدن Build، از بخش Artifacts فایل `MR-KHORASANI-Finance-v1.1.0-APK` را دریافت کنید.
4. فایل APK حاصل برای نصب مستقیم روی گوشی‌های Android مناسب است.

## تست محلی
در پوشه `android`:

```bash
./gradlew :app:assembleDebug
```

خروجی:
`android/app/build/outputs/apk/debug/app-debug.apk`

## وضعیت امضا
این Workflow نسخه Debug را با debug keystore استاندارد Gradle/Android می‌سازد. برای استفاده Play Store باید Release keystore اختصاصی اضافه شود.
