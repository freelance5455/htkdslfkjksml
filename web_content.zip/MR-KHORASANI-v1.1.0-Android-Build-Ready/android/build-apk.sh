#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ -x ./gradlew ]]; then
  ./gradlew :app:assembleDebug --no-daemon
elif command -v gradle >/dev/null 2>&1; then
  gradle :app:assembleDebug --no-daemon
else
  echo "Gradle is not installed. Open this folder in Android Studio, or install Gradle 8.13+." >&2
  exit 2
fi
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
