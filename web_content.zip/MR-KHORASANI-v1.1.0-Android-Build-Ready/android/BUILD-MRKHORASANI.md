# MR,KHORASANI Android Build

This wrapper packages `assets/www` into Android using WebViewAssetLoader.

Before building from the updated source, place the production web bundle under:
`app/src/main/assets/www/`

Then run:
`./gradlew :app:assembleDebug`

Release/AAB requires a configured signing key.
