# MR KHORASANI Finance — Android APK Wrapper

پروژهٔ Android Studio برای بسته‌بندی سامانه مالی MR KHORASANI Finance.

- Application ID: `com.mrkhrasani.finance`
- Version: `1.0.0`
- Minimum Android: API 24
- Target / Compile SDK: 35
- WebView با `WebViewAssetLoader` محتوای `assets/www` را از مبدأ امن `https://appassets.androidplatform.net` سرو می‌کند.
- دادهٔ آفلاین در storage خود WebView می‌ماند.
- خروجی پشتیبان JSON از طریق پل `AndroidBackup` به پوشه Downloads می‌رود.

### ساخت APK در Android Studio
۱. از ریشهٔ مخزن `npm run android:www` را اجرا کنید تا رابط داخل `assets/www` قرار گیرد.  
۲. پوشهٔ `android/` را در Android Studio باز کنید.  
۳. **Build > Build APK(s)** نسخه Debug.

برای Release باید با keystore مالک سامانه امضا شود.

### ساخت با اسکریپت
`./build-apk.sh` اگر Gradle روی ماشین نصب باشد `:app:assembleDebug` را می‌زند.

### GitHub Actions
فایل `.github/workflows/android-debug.yml` در ریشهٔ مخزن، APK را روی runner لینوکس می‌سازد و به‌صورت artifact آپلود می‌کند.
