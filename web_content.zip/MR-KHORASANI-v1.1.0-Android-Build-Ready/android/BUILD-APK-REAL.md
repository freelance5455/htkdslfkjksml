# ساخت واقعی APK — MR KHORASANI

این پروژه برای Build واقعی Android آماده شده است.

## مشخصات Build
- Package ID: `com.mrkhrasani.finance`
- Main Activity: `com.mrkhrasani.finance.MainActivity`
- compileSdk / targetSdk: 35
- minSdk: 24
- Java: 17
- Gradle: 8.13
- Android Gradle Plugin: 8.7.3

## روش پیشنهادی — GitHub Actions
1. کل پوشه پروژه را داخل یک Repository در GitHub قرار دهید.
2. از مسیر **Actions**، Workflow با نام **Build MR KHORASANI Android APK** را اجرا کنید.
3. Workflow ابتدا Android SDK 35 و Build Tools 35.0.0 را نصب می‌کند.
4. سپس Package/Manifest را کنترل می‌کند.
5. بعد `assembleDebug` را در محیط واقعی Android Build اجرا می‌کند.
6. فایل `MR-KHORASANI-Finance-debug.apk` در بخش **Artifacts** قرار می‌گیرد.

این APK برای انتقال بین گوشی‌های Android و نصب مستقیم مناسب است.

## روش Android Studio
پوشه `android` را در Android Studio باز کنید و پروژه را Sync کنید، سپس:
`Build > Build APK(s)`

خروجی:
`android/app/build/outputs/apk/debug/app-debug.apk`

## نکته امضا
نسخه Debug با debug keystore اندروید ساخته می‌شود و برای تست/نصب مستقیم مناسب است. برای انتشار حرفه‌ای یا Play Store باید Release keystore اختصاصی ساخته و به CI به‌صورت Secret متصل شود.
