(function(){
  const URL='https://klomsegarpfdkhkmoazy.supabase.co';
  const KEY='sb_publishable_bkwQJ96fqM2zd0yu0XQ6LA_QJl2c2RV';
  let accessToken=null;
  async function request(path, options={}){
    const headers=Object.assign({'apikey':KEY,'Content-Type':'application/json','Accept':'application/json'},options.headers||{});
    if(accessToken) headers.Authorization='Bearer '+accessToken;
    const res=await fetch(URL+path,Object.assign({},options,{headers}));
    const text=await res.text();
    let data; try{data=text?JSON.parse(text):null}catch(e){data=text}
    if(!res.ok) throw new Error('Supabase '+res.status+': '+(data&&data.message?data.message:text));
    return data;
  }
  async function rpc(name,args){
    return request('/rest/v1/rpc/'+encodeURIComponent(name),{method:'POST',body:JSON.stringify(args||{})});
  }
  async function signIn(email,password){
    const data=await request('/auth/v1/token?grant_type=password',{method:'POST',body:JSON.stringify({email:email,password:password})});
    accessToken=data.access_token||null;
    if(data.refresh_token) localStorage.setItem('mr_supabase_refresh_token',data.refresh_token);
    return data;
  }
  async function signUp(email,password){
    const data=await request('/auth/v1/signup',{method:'POST',body:JSON.stringify({email:email,password:password})});
    if(data.access_token) accessToken=data.access_token;
    return data;
  }
  async function signOut(){
    try{if(accessToken) await request('/auth/v1/logout',{method:'POST'});}catch(e){}
    accessToken=null; localStorage.removeItem('mr_supabase_refresh_token');
  }
  async function health(){
    const started=Date.now();
    await request('/rest/v1/companies?select=id&limit=1');
    return {ok:true,latencyMs:Date.now()-started,url:URL};
  }
  window.MR_SUPABASE={url:URL,publishableKey:KEY,setAccessToken:function(t){accessToken=t||null},request:request,rpc:rpc,signIn:signIn,signUp:signUp,signOut:signOut,health:health};
  window.dispatchEvent(new CustomEvent('mr-supabase-ready'));
})();
