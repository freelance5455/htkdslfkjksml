(function(){
  function el(tag,attrs,text){var x=document.createElement(tag);Object.keys(attrs||{}).forEach(function(k){x[k]=attrs[k]});if(text)x.textContent=text;return x}
  function init(){
    if(!window.MR_SUPABASE)return;
    var box=el('div',{id:'mr-cloud-console'});
    box.style='position:fixed;left:12px;bottom:12px;z-index:99999;background:#111827;color:#fff;border:1px solid #d4af37;border-radius:14px;padding:10px;width:290px;box-shadow:0 10px 30px rgba(0,0,0,.25);font-family:Vazirmatn,sans-serif;font-size:12px;direction:rtl;';
    var title=el('div',{style:'font-weight:700;color:#d4af37;margin-bottom:8px'},'MR,KHORASANI • اتصال ابری');box.appendChild(title);
    var status=el('div',{style:'margin-bottom:8px;opacity:.9'},'در حال بررسی اتصال...');box.appendChild(status);
    var email=el('input',{type:'email',placeholder:'ایمیل',style:'width:100%;box-sizing:border-box;margin:3px 0;padding:8px;border-radius:8px;border:1px solid #374151;background:#1f2937;color:#fff'});
    var pass=el('input',{type:'password',placeholder:'رمز عبور',style:'width:100%;box-sizing:border-box;margin:3px 0;padding:8px;border-radius:8px;border:1px solid #374151;background:#1f2937;color:#fff'});
    var row=el('div',{style:'display:flex;gap:6px;margin-top:5px'});box.appendChild(email);box.appendChild(pass);box.appendChild(row);
    function btn(t){return el('button',{style:'flex:1;padding:7px;border:0;border-radius:8px;background:#d4af37;color:#111;cursor:pointer'},t)}
    var login=btn('ورود');var signup=btn('ثبت‌نام');row.appendChild(login);row.appendChild(signup);
    var ops=el('div',{style:'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:7px'});box.appendChild(ops);
    function op(t,fn){var b=btn(t);b.onclick=fn;ops.appendChild(b)}
    login.onclick=async function(){try{var r=await MR_SUPABASE.signIn(email.value,pass.value);status.textContent=r.access_token?'ورود موفق؛ Session فعال است.':'ورود انجام شد؛ ایمیل ممکن است نیاز به تأیید داشته باشد.'}catch(e){status.textContent='خطا: '+e.message}};
    signup.onclick=async function(){try{var r=await MR_SUPABASE.signUp(email.value,pass.value);status.textContent=r.access_token?'ثبت‌نام و ورود موفق.':'ثبت‌نام انجام شد؛ ایمیل را تأیید کنید.'}catch(e){status.textContent='خطا: '+e.message}};
    op('سلامت Backend',async function(){try{var r=await MR_SUPABASE.health();status.textContent='Supabase متصل • '+r.latencyMs+'ms'}catch(e){status.textContent='عدم اتصال: '+e.message}});
    op('بستن پنل',function(){box.remove()});
    document.body.appendChild(box);
    MR_SUPABASE.health().then(function(r){status.textContent='Backend متصل • بدون Session'}).catch(function(e){status.textContent='Backend در دسترس نیست'});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();