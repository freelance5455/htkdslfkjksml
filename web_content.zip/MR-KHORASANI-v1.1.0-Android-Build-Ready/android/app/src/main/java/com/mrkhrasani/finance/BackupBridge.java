package com.mrkhrasani.finance;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class BackupBridge {
    private final Context context;

    public BackupBridge(Context context) {
        this.context = context.getApplicationContext();
    }

    @JavascriptInterface
    public void exportJson(String filename, String json) {
        try {
            String safe = sanitize(filename);
            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) {
                    throw new IllegalStateException("insert failed");
                }
                try (OutputStream stream = context.getContentResolver().openOutputStream(uri)) {
                    if (stream == null) {
                        throw new IllegalStateException("stream");
                    }
                    stream.write(bytes);
                }
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                context.getContentResolver().update(uri, values, null, null);
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                try (FileOutputStream stream = new FileOutputStream(new File(dir, safe))) {
                    stream.write(bytes);
                }
            }
            toast("پشتیبان ذخیره شد: " + safe);
        } catch (Exception error) {
            toast("ذخیره پشتیبان ناموفق بود");
        }
    }

    private void toast(String message) {
        new Handler(Looper.getMainLooper())
                .post(() -> Toast.makeText(context, message, Toast.LENGTH_LONG).show());
    }

    private static String sanitize(String filename) {
        String safe = filename == null ? "backup.json" : filename.replaceAll("[^A-Za-z0-9._\\-]", "_");
        if (!safe.toLowerCase().endsWith(".json")) {
            safe = safe + ".json";
        }
        return safe;
    }
}
