-keepclassmembers class com.mrkhrasani.finance.BackupBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
