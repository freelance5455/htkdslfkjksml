# MR,KHORASANI Android package

This Android wrapper is retained from the supplied project and configured for the MR,KHORASANI product identity.

It packages `app/src/main/assets/www` through `WebViewAssetLoader` and supports Android 10+ while retaining API 24 minimum compatibility.

The updated source-of-truth application is in the parent workspace `src/`. After rebuilding the web bundle, copy its production static assets into `assets/www`, then run `./gradlew :app:assembleDebug` or `./gradlew :app:bundleRelease` with a configured signing key.
