# MR KHORASANI Finance — APK Build

Standalone Android wrapper. The finance app is bundled under `app/src/main/assets/www/` and served inside WebView through `WebViewAssetLoader` (no `file://` origin, so `localStorage` and ES modules work).

## Compatibility
- minSdk 24 (Android 7.0)
- targetSdk 35
- Universal debug APK from `assembleDebug`
- Offline: the UI is inside the APK. Ledger data lives in WebView storage on the device.

## Prepare web assets
From the repository root (Node 22):

```
npm install
npm run android:www
```

This writes the static bundle to `android/app/src/main/assets/www/`.

## GitHub Actions
`.github/workflows/android-debug.yml` installs Node, Java 17 and Gradle 8.13, bundles the web app, then builds:

`dist/MR-KHORASANI-Finance-v1.0.0.apk`

The APK is uploaded as an artifact with a SHA-256 checksum.

## Local build
Java 17 + Android SDK:

```
./build-apk.sh
```

or:

```
gradle :app:assembleDebug
```

Installable APK:

`app/build/outputs/apk/debug/app-debug.apk`

## Signing
The debug APK is signed by the build environment. For updates that install over an existing copy, keep one release keystore and sign every future APK with it.

Optional `keystore.properties` (never commit it):

```
storeFile=/secure/path/release.jks
storePassword=...
keyAlias=...
keyPassword=...
```

## Runtime notes
- JavaScript, DOM storage and the backup bridge (`AndroidBackup.exportJson`) are enabled.
- File picker is wired so JSON restore works from the in-app file input.
- Back button walks WebView history, then leaves the activity.
- External http(s) links open in the system browser; app URLs stay inside the WebView.
