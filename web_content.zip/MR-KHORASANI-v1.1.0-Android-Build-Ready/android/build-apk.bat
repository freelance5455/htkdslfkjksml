@echo off
setlocal
cd /d "%~dp0"
if not exist gradlew.bat (
  echo gradlew.bat not found.
  exit /b 2
)
call gradlew.bat :app:assembleDebug --no-daemon --stacktrace
if errorlevel 1 exit /b %errorlevel%
echo.
echo APK created:
echo %CD%\app\build\outputs\apk\debug\app-debug.apk
endlocal
