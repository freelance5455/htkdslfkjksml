import base64
import os
import re
import secrets
import time

from flask import jsonify, render_template, request, send_file

UID_RE = re.compile(r"^CS\d{6}$")
ID_RE = re.compile(r"^[a-f0-9]{12}$")
MAX_GRUPO = 4
MAX_GRUPOS_POR_PESSOA = 20
MAX_PEDIDOS = 50
MAX_AMIGOS = 200
MAX_MSGS_GRUPO = 1500
TRASH_DAYS = 30

FERRAMENTAS = {
    "nomes": "Gere 15 nomes criativos e variados para o que o usuário descrever (personagens, lugares, reinos...). Dê uma frase curta de significado para cada.",
    "cenario": "Crie um cenário rico e detalhado (ambiente, clima, sons, cheiros, ganchos de história) a partir da ideia do usuário.",
    "mundo": "Ajude com worldbuilding: geografia, culturas, magia ou tecnologia, política, história e conflitos, a partir da ideia do usuário.",
    "ideias": "Faça um brainstorm com 10 ideias originais e diferentes entre si a partir do tema do usuário.",
}


def init(app, auth_required, err, read_json, write_json, load_users, call_ai, DATA, MODES, USERS_FILE,
         lock, limitado, bloqueado, registrar):
    soc_dir = os.path.join(DATA, "social")
    dm_dir = os.path.join(DATA, "dm")
    grp_dir = os.path.join(DATA, "groups")
    grp_trash = os.path.join(DATA, "groups_trash")
    av_dir = os.path.join(DATA, "avatars")
    for p in (soc_dir, dm_dir, grp_dir, grp_trash, av_dir):
        os.makedirs(p, exist_ok=True)

    MSG_IA = "Calma, muitas mensagens para a IA. Espere um minutinho."

    # ---------- utilidades ----------
    def pub(uid, users=None):
        users = users if users is not None else load_users()
        u = users.get(uid)
        if not u:
            return {"uid": uid, "apelido": "(conta removida)", "avatar": "🍬", "bio": ""}
        return {"uid": uid, "apelido": u["apelido"], "avatar": u.get("avatar", "🍬"), "bio": u.get("bio", "")}

    def soc(uid):
        d = read_json(os.path.join(soc_dir, uid + ".json"), {})
        for k in ("amigos", "recebidas", "enviadas"):
            d.setdefault(k, [])
        return d

    def save_soc(uid, d):
        write_json(os.path.join(soc_dir, uid + ".json"), d)

    def rel(me, other):
        if me == other:
            return "eu"
        s = soc(me)
        for k, nome in (("amigos", "amigo"), ("recebidas", "recebida"), ("enviadas", "enviada")):
            if other in s[k]:
                return nome
        return "nenhuma"

    def txt(key, n):
        return str((request.get_json(silent=True) or {}).get(key, "")).strip()[:n]

    # ---------- página ----------
    @app.route("/social")
    def s_page():
        return render_template("Social.html")

    # ---------- perfil ----------
    @app.route("/api/perfil/<uid_alvo>")
    @auth_required
    def s_perfil(uid, uid_alvo):
        users = load_users()
        if uid_alvo not in users:
            return err("Usuário não encontrado.", 404)
        p = pub(uid_alvo, users)
        p["rel"] = rel(uid, uid_alvo)
        return jsonify(p)

    @app.route("/api/perfil", methods=["PUT"])
    @auth_required
    def s_perfil_editar(uid):
        d = request.get_json(silent=True) or {}
        with lock:
            users = load_users()
            u = users[uid]
            nick = str(d.get("apelido", u["apelido"])).strip()[:30]
            if len(nick) < 2:
                return err("O apelido precisa ter pelo menos 2 letras.")
            u["apelido"] = nick
            u["bio"] = str(d.get("bio", ""))[:200]
            av = str(d.get("avatar", ""))
            if av and len(av) <= 8 and not av.startswith("foto"):
                u["avatar"] = av
                # escolheu um emoji: a foto antiga não é mais usada
                try:
                    os.remove(os.path.join(av_dir, uid + ".jpg"))
                except OSError:
                    pass
            write_json(USERS_FILE, users)
            return jsonify(pub(uid, users))

    @app.route("/api/perfil/foto", methods=["POST"])
    @auth_required
    def s_foto(uid):
        prefix = "data:image/jpeg;base64,"
        img = txt("imagem", 200000)
        if not img.startswith(prefix):
            return err("Envie uma imagem JPEG.")
        try:
            raw = base64.b64decode(img[len(prefix):], validate=True)
        except Exception:
            return err("Imagem inválida.")
        if len(raw) > 90000 or raw[:2] != b"\xff\xd8":
            return err("Imagem inválida ou grande demais.")
        with lock:
            with open(os.path.join(av_dir, uid + ".jpg"), "wb") as f:
                f.write(raw)
            users = load_users()
            users[uid]["avatar"] = "foto:" + str(int(time.time()))
            write_json(USERS_FILE, users)
            return jsonify(pub(uid, users))

    @app.route("/api/avatar/<uid_alvo>")
    @auth_required
    def s_avatar(uid, uid_alvo):
        if not UID_RE.match(uid_alvo):
            return err("Sem foto.", 404)
        p = os.path.join(av_dir, uid_alvo + ".jpg")
        if not os.path.exists(p):
            return err("Sem foto.", 404)
        return send_file(p, mimetype="image/jpeg")

    # ---------- amizades ----------
    @app.route("/api/buscar/<q>")
    @auth_required
    def s_buscar(uid, q):
        if limitado(("busca", uid), 30, 60):
            return err("Muitas buscas seguidas. Espere um minuto.", 429)
        q = q.strip().upper()
        users = load_users()
        if not UID_RE.match(q):
            return err("UID inválido. Ele é parecido com CS123456.")
        if q not in users:
            return err("Nenhum usuário com esse UID.", 404)
        p = pub(q, users)
        p["rel"] = rel(uid, q)
        return jsonify(p)

    @app.route("/api/amigos")
    @auth_required
    def s_amigos(uid):
        s = soc(uid)
        users = load_users()
        return jsonify({k: [pub(x, users) for x in s[k]] for k in ("amigos", "recebidas", "enviadas")})

    @app.route("/api/amigos/<acao>/<other>", methods=["POST"])
    @auth_required
    def s_amigo_acao(uid, acao, other):
        if acao not in ("pedir", "aceitar", "recusar", "cancelar", "remover"):
            return err("Ação inválida.")
        if not UID_RE.match(other) or other == uid or other not in load_users():
            return err("Usuário não encontrado.", 404)

        def rm(lista, x):
            while x in lista:
                lista.remove(x)

        with lock:
            a, b = soc(uid), soc(other)
            if acao == "pedir":
                if other in a["amigos"]:
                    return err("Vocês já são amigos.")
                if other in a["recebidas"]:
                    acao = "aceitar"
                elif other in a["enviadas"]:
                    return err("Você já enviou um pedido.")
                else:
                    if len(a["enviadas"]) >= MAX_PEDIDOS:
                        return err("Você tem pedidos demais pendentes. Cancele alguns antes.")
                    if len(b["recebidas"]) >= MAX_PEDIDOS:
                        return err("Essa pessoa tem pedidos demais pendentes.")
                    a["enviadas"].append(other)
                    b["recebidas"].append(uid)
            if acao == "aceitar":
                if other not in a["recebidas"]:
                    return err("Não há pedido deste usuário.")
                if len(a["amigos"]) >= MAX_AMIGOS or len(b["amigos"]) >= MAX_AMIGOS:
                    return err("Limite de amigos atingido.")
                rm(a["recebidas"], other)
                rm(b["enviadas"], uid)
                a["amigos"].append(other)
                b["amigos"].append(uid)
            elif acao == "recusar":
                rm(a["recebidas"], other)
                rm(b["enviadas"], uid)
            elif acao == "cancelar":
                rm(a["enviadas"], other)
                rm(b["recebidas"], uid)
            elif acao == "remover":
                rm(a["amigos"], other)
                rm(b["amigos"], uid)
            save_soc(uid, a)
            save_soc(other, b)
        return jsonify({"ok": True})

    # ---------- mensagens privadas ----------
    def dm_path(a, b):
        x, y = sorted([a, b])
        return os.path.join(dm_dir, f"{x}__{y}.json")

    def dm_add(a, b, texto):
        with lock:
            p = dm_path(a, b)
            d = read_json(p, {"mensagens": []})
            d["mensagens"].append({"id": secrets.token_hex(6), "autor": a, "texto": texto, "ts": time.time()})
            d["mensagens"] = d["mensagens"][-500:]
            write_json(p, d)

    def eh_amigo(uid, other):
        return bool(UID_RE.match(other)) and other in soc(uid)["amigos"]

    @app.route("/api/dm/<other>", methods=["GET"])
    @auth_required
    def s_dm_ler(uid, other):
        if not eh_amigo(uid, other):
            return err("Vocês não são amigos.", 403)
        return jsonify(read_json(dm_path(uid, other), {"mensagens": []}))

    @app.route("/api/dm/<other>", methods=["POST"])
    @auth_required
    def s_dm_enviar(uid, other):
        if not eh_amigo(uid, other):
            return err("Vocês não são amigos.", 403)
        t = txt("texto", 2000)
        if not t:
            return err("Escreva uma mensagem.")
        if limitado(("dm", uid), 40, 60):
            return err("Calma! Muitas mensagens seguidas.", 429)
        dm_add(uid, other, t)
        return jsonify({"ok": True})

    @app.route("/api/dm/<other>/<mid>", methods=["DELETE"])
    @auth_required
    def s_dm_apagar(uid, other, mid):
        if not eh_amigo(uid, other):
            return err("Vocês não são amigos.", 403)
        with lock:
            p = dm_path(uid, other)
            d = read_json(p, {"mensagens": []})
            d["mensagens"] = [m for m in d["mensagens"] if not (m["id"] == mid and m["autor"] == uid)]
            write_json(p, d)
        return jsonify({"ok": True})

    # ---------- grupos ----------
    def gpath(gid, folder=None):
        return os.path.join(folder or grp_dir, gid + ".json")

    def todos(folder):
        out = []
        for n in os.listdir(folder):
            if n.endswith(".json"):
                g = read_json(os.path.join(folder, n), None)
                if g and g.get("id"):
                    out.append(g)
        return out

    def carregar(uid, gid):
        if not ID_RE.match(gid):
            return None
        g = read_json(gpath(gid), None)
        if not g or uid not in g.get("membros", []):
            return None
        g.setdefault("mensagens", [])
        g.setdefault("lixeira", [])
        g.setdefault("log", [])
        g.setdefault("encerrado", False)
        # mensagens apagadas somem de vez depois de 30 dias
        agora = time.time()
        limite = agora - TRASH_DAYS * 86400
        for m in g["lixeira"]:
            m.setdefault("apagada_em", agora)
        g["lixeira"] = [m for m in g["lixeira"] if m["apagada_em"] >= limite]
        return g

    def logar(g, uid, acao):
        g["log"].append({"ts": time.time(), "uid": uid, "acao": acao})
        g["log"] = g["log"][-200:]

    def salvar(g):
        g["mensagens"] = g["mensagens"][-MAX_MSGS_GRUPO:]
        write_json(gpath(g["id"]), g)

    def para_lixeira(g, uid, acao):
        logar(g, uid, acao)
        g["excluido_em"] = time.time()
        write_json(gpath(g["id"], grp_trash), g)
        os.remove(gpath(g["id"]))

    def visao(g):
        users = load_users()
        ids = set(g["membros"]) | {l["uid"] for l in g["log"]}
        ids |= {m["autor"] for m in g["mensagens"] + g["lixeira"] if m.get("autor")}
        return {**g, "pessoas": {i: pub(i, users) for i in ids}}

    @app.route("/api/grupos", methods=["GET"])
    @auth_required
    def s_grupos(uid):
        res = [{"id": g["id"], "nome": g.get("nome", "Grupo"), "n": len(g["membros"]),
                "encerrado": g.get("encerrado", False)}
               for g in todos(grp_dir) if uid in g.get("membros", [])]
        return jsonify(res)

    @app.route("/api/grupos", methods=["POST"])
    @auth_required
    def s_grupo_criar(uid):
        d = request.get_json(silent=True) or {}
        modo = d.get("modo") if d.get("modo") in MODES else "livre"
        with lock:
            if sum(1 for g in todos(grp_dir) if uid in g.get("membros", [])) >= MAX_GRUPOS_POR_PESSOA:
                return err("Você já participa de grupos demais. Saia de algum antes.")
            g = {"id": secrets.token_hex(6), "nome": txt("nome", 40) or "Grupo novo", "modo": modo,
                 "membros": [uid], "codigo": secrets.token_hex(4).upper(), "mensagens": [], "lixeira": [],
                 "log": [], "encerrado": False, "criado": time.time()}
            logar(g, uid, "criou o grupo")
            salvar(g)
        return jsonify({"id": g["id"]})

    @app.route("/api/grupos/entrar", methods=["POST"])
    @auth_required
    def s_grupo_entrar(uid):
        if bloqueado(("grp", uid), 10, 600):
            return err("Muitas tentativas com códigos errados. Espere alguns minutos.", 429)
        code = txt("codigo", 20).upper()
        with lock:
            if code:
                for g in todos(grp_dir):
                    if g.get("codigo") == code:
                        if uid in g["membros"]:
                            return jsonify({"id": g["id"]})
                        if g.get("encerrado"):
                            return err("Este grupo foi encerrado.")
                        if len(g["membros"]) >= MAX_GRUPO:
                            return err("O grupo já tem 4 pessoas.")
                        g.setdefault("log", [])
                        g["membros"].append(uid)
                        logar(g, uid, "entrou no grupo")
                        salvar(g)
                        return jsonify({"id": g["id"]})
        registrar(("grp", uid))
        return err("Código de convite não encontrado.", 404)

    @app.route("/api/grupos/<gid>", methods=["GET"])
    @auth_required
    def s_grupo_ver(uid, gid):
        g = carregar(uid, gid)
        return jsonify(visao(g)) if g else err("Grupo não encontrado.", 404)

    @app.route("/api/grupos/<gid>", methods=["PUT"])
    @auth_required
    def s_grupo_config(uid, gid):
        d = request.get_json(silent=True) or {}
        with lock:
            g = carregar(uid, gid)
            if not g:
                return err("Grupo não encontrado.", 404)
            if g["encerrado"]:
                return err("Este grupo foi encerrado.")
            nome = txt("nome", 40) or g["nome"]
            modo = d.get("modo") if d.get("modo") in MODES else g["modo"]
            logar(g, uid, f"alterou as configurações (nome: {nome}, modo: {modo})")
            g["nome"], g["modo"] = nome, modo
            salvar(g)
        return jsonify({"ok": True})

    @app.route("/api/grupos/<gid>/send", methods=["POST"])
    @auth_required
    def s_grupo_enviar(uid, gid):
        d = request.get_json(silent=True) or {}
        texto = txt("texto", 4000)
        if not texto:
            return err("Escreva uma mensagem.")
        if limitado(("gmsg", uid), 40, 60):
            return err("Calma! Muitas mensagens seguidas.", 429)
        with lock:
            g = carregar(uid, gid)
            if not g:
                return err("Grupo não encontrado.", 404)
            if g["encerrado"]:
                return err("Este grupo foi encerrado.")
            g["mensagens"].append({"id": secrets.token_hex(6), "autor": uid, "role": "user",
                                   "content": texto, "ts": time.time()})
            salvar(g)
            modo, hist, ficha = g["modo"], list(g["mensagens"][-30:]), g.get("ficha", "")
        if not d.get("ia"):
            return jsonify({"ok": True})
        if limitado(("ia", uid), 20, 60):
            return err("Sua mensagem foi enviada, mas a IA precisa descansar um minutinho. " + MSG_IA, 429)
        users = load_users()
        msgs = [{"role": "system", "content": MODES.get(modo, MODES["livre"]) +
                 " Várias pessoas conversam neste grupo e cada mensagem começa com o apelido de quem escreveu. "
                 "Responda a todos de forma coerente." +
                 (("\n\nFicha da história (siga sempre, é a memória fixa):\n" + ficha) if ficha else "")}]
        for m in hist:
            if m["role"] == "assistant":
                msgs.append({"role": "assistant", "content": m["content"]})
            else:
                msgs.append({"role": "user", "content": pub(m["autor"], users)["apelido"] + ": " + m["content"]})
        ok, res = call_ai(msgs)  # fora da trava
        if not ok:
            return err(res + " (Sua mensagem foi enviada.)", 502)
        with lock:
            g = read_json(gpath(gid), None)  # a resposta fica no grupo mesmo se o autor saiu nesse meio-tempo
            if g:
                g.setdefault("mensagens", [])
                g.setdefault("log", [])
                g["mensagens"].append({"id": secrets.token_hex(6), "autor": None, "role": "assistant",
                                       "content": res, "ts": time.time()})
                salvar(g)
        return jsonify({"ok": True})

    @app.route("/api/grupos/<gid>/ficha", methods=["PUT"])
    @auth_required
    def s_grupo_ficha(uid, gid):
        with lock:
            g = carregar(uid, gid)
            if not g:
                return err("Grupo não encontrado.", 404)
            if g["encerrado"]:
                return err("Este grupo foi encerrado.")
            g["ficha"] = txt("ficha", 4000)
            logar(g, uid, "editou a ficha da história")
            salvar(g)
        return jsonify({"ok": True})

    @app.route("/api/grupos/<gid>/msg/<mid>", methods=["DELETE"])
    @auth_required
    def s_msg_apagar(uid, gid, mid):
        with lock:
            g = carregar(uid, gid)
            if not g:
                return err("Grupo não encontrado.", 404)
            for m in g["mensagens"]:
                if m["id"] == mid:
                    g["mensagens"].remove(m)
                    m["apagada_em"] = time.time()
                    g["lixeira"].append(m)
                    logar(g, uid, "apagou uma mensagem")
                    salvar(g)
                    return jsonify({"ok": True})
        return err("Mensagem não encontrada.", 404)

    @app.route("/api/grupos/<gid>/restaurar/<mid>", methods=["POST"])
    @auth_required
    def s_msg_restaurar(uid, gid, mid):
        with lock:
            g = carregar(uid, gid)
            if not g:
                return err("Grupo não encontrado.", 404)
            for m in g["lixeira"]:
                if m["id"] == mid:
                    g["lixeira"].remove(m)
                    m.pop("apagada_em", None)
                    g["mensagens"].append(m)
                    g["mensagens"].sort(key=lambda x: x["ts"])
                    logar(g, uid, "restaurou uma mensagem")
                    salvar(g)
                    return jsonify({"ok": True})
        return err("Mensagem não encontrada.", 404)

    @app.route("/api/grupos/<gid>/convidar", methods=["POST"])
    @auth_required
    def s_convidar(uid, gid):
        alvo = txt("uid", 10)
        with lock:
            g = carregar(uid, gid)
            if not g:
                return err("Grupo não encontrado.", 404)
            if g["encerrado"]:
                return err("Este grupo foi encerrado.")
            if not eh_amigo(uid, alvo):
                return err("Você só pode convidar amigos.")
            if alvo in g["membros"]:
                return err("Essa pessoa já está no grupo.")
            if len(g["membros"]) >= MAX_GRUPO:
                return err("O grupo já tem 4 pessoas.")
            dm_add(uid, alvo, f"Convite para o grupo \"{g['nome']}\". Código: {g['codigo']}")
            logar(g, uid, "enviou um convite")
            salvar(g)
        return jsonify({"ok": True})

    @app.route("/api/grupos/<gid>/<acao>", methods=["POST"])
    @auth_required
    def s_grupo_acao(uid, gid, acao):
        if acao not in ("encerrar", "sair"):
            return err("Ação inválida.")
        with lock:
            g = carregar(uid, gid)
            if not g:
                return err("Grupo não encontrado.", 404)
            if acao == "encerrar":
                g["encerrado"] = True
                logar(g, uid, "encerrou o chat")
                salvar(g)
            elif len(g["membros"]) == 1:
                # último a sair: o grupo vai para a lixeira (30 dias) em vez de sumir
                para_lixeira(g, uid, "saiu e o grupo foi para a lixeira")
            else:
                g["membros"].remove(uid)
                logar(g, uid, "saiu do grupo")
                salvar(g)
        return jsonify({"ok": True})

    @app.route("/api/grupos/<gid>", methods=["DELETE"])
    @auth_required
    def s_grupo_excluir(uid, gid):
        with lock:
            g = carregar(uid, gid)
            if not g:
                return err("Grupo não encontrado.", 404)
            para_lixeira(g, uid, "excluiu o grupo")
        return jsonify({"ok": True})

    @app.route("/api/grupos/lixeira")
    @auth_required
    def s_grupos_lixeira(uid):
        limite = time.time() - TRASH_DAYS * 86400
        res = []
        with lock:
            for g in todos(grp_trash):
                if g.get("excluido_em", time.time()) < limite:
                    try:
                        os.remove(gpath(g["id"], grp_trash))
                    except OSError:
                        pass
                elif uid in g.get("membros", []):
                    res.append({"id": g["id"], "nome": g.get("nome", "Grupo")})
        return jsonify(res)

    @app.route("/api/grupos/lixeira/<gid>/restaurar", methods=["POST"])
    @auth_required
    def s_grupo_restaurar(uid, gid):
        if not ID_RE.match(gid):
            return err("Grupo não encontrado.", 404)
        with lock:
            g = read_json(gpath(gid, grp_trash), None)
            if not g or uid not in g.get("membros", []):
                return err("Grupo não encontrado.", 404)
            g.pop("excluido_em", None)
            g.setdefault("mensagens", [])
            g.setdefault("lixeira", [])
            g.setdefault("log", [])
            logar(g, uid, "restaurou o grupo")
            salvar(g)
            os.remove(gpath(gid, grp_trash))
        return jsonify({"ok": True})

    # ---------- ferramentas rápidas ----------
    @app.route("/api/ferramenta", methods=["POST"])
    @auth_required
    def s_ferramenta(uid):
        d = request.get_json(silent=True) or {}
        if d.get("tipo") not in FERRAMENTAS:
            return err("Ferramenta desconhecida.")
        if limitado(("ia", uid), 20, 60):
            return err(MSG_IA, 429)
        ok, res = call_ai([{"role": "system", "content": FERRAMENTAS[d["tipo"]]},
                           {"role": "user", "content": txt("texto", 2000) or "Surpreenda-me."}])
        return jsonify({"resposta": res}) if ok else err(res, 502)
