import hashlib
import json
import os
import re
import secrets
import socket
import sys
import threading
import time
import zipfile
from datetime import date
from functools import wraps
from urllib import error as urlerr
from urllib import request as urlreq
from urllib.parse import urlparse

from flask import Flask, jsonify, render_template, request, send_file, session

# ---------- Configuração ----------
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
CONFIG_FILE = os.path.join(BASE, "config.json")
USERS_FILE = os.path.join(DATA, "users.json")
MODEL = "nvidia/nemotron-3-ultra-550b-a55b:free"  # NÃO trocar sem autorização
API_URL = "https://openrouter.ai/api/v1/chat/completions"
TRASH_DAYS = 30
ID_RE = re.compile(r"^[a-f0-9]{12}$")

os.makedirs(DATA, exist_ok=True)
sys.path.insert(0, BASE)  # garante que o Social.py seja encontrado no Pydroid
os.chdir(BASE)

for _f in ("templates/Index.html", "templates/Social.html", "Social.py"):
    if not os.path.exists(os.path.join(BASE, _f)):
        print("ATENÇÃO: arquivo não encontrado:", os.path.join(BASE, _f))

if not os.path.exists(CONFIG_FILE):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({"openrouter_api_key": "COLE_SUA_CHAVE_AQUI"}, f, indent=2)

secret_path = os.path.join(DATA, "secret.key")
if not os.path.exists(secret_path):
    with open(secret_path, "w") as f:
        f.write(secrets.token_hex(32))
with open(secret_path) as f:
    SECRET = f.read().strip()

app = Flask(__name__, template_folder=os.path.join(BASE, "templates"))
app.secret_key = SECRET
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["PERMANENT_SESSION_LIFETIME"] = 60 * 60 * 24 * 30
app.config["MAX_CONTENT_LENGTH"] = 1_000_000  # nenhuma requisição passa de 1 MB

MODES = {
    "historias": "Você é uma co-autora criativa de histórias e novels. Ajude com narrativa, personagens, capítulos e universos. Mantenha coerência.",
    "fanfic": "Você é uma escritora de fanfics. Respeite o universo e os personagens originais e incorpore os acontecimentos pedidos pelo usuário.",
    "webtoon": "Você escreve roteiros de webtoon, manhwa, mangá e HQ divididos em painéis, com enquadramento, falas e descrição visual.",
    "rpg": "Você é mestre de RPG e roleplay. Dê personalidade própria aos personagens, crie acontecimentos dinâmicos e mantenha a continuidade.",
    "livre": "Você é a assistente criativa do CandyShopy Studio. Seja gentil, criativa e clara.",
}

# Trava única: protege TODOS os arquivos JSON contra duas requisições mexendo ao mesmo tempo.
LOCK = threading.RLock()


# ---------- Limite de tentativas (sem travar o servidor) ----------
_TENT = {}
_TENT_LOCK = threading.Lock()


def _limpar_tentativas(agora):
    if len(_TENT) > 5000:
        for k in list(_TENT):
            _TENT[k] = [t for t in _TENT[k] if agora - t < 3600]
            if not _TENT[k]:
                del _TENT[k]


def bloqueado(chave, maximo, janela):
    """Só consulta: já passou do limite de tentativas na janela (segundos)?"""
    agora = time.time()
    with _TENT_LOCK:
        return len([t for t in _TENT.get(chave, []) if agora - t < janela]) >= maximo


def registrar(chave):
    """Anota uma tentativa (use quando algo falhou)."""
    agora = time.time()
    with _TENT_LOCK:
        _TENT.setdefault(chave, []).append(agora)
        _limpar_tentativas(agora)


def limitado(chave, maximo, janela):
    """Anota uma tentativa e diz se passou do limite."""
    agora = time.time()
    with _TENT_LOCK:
        lst = [t for t in _TENT.get(chave, []) if agora - t < janela]
        lst.append(agora)
        _TENT[chave] = lst
        _limpar_tentativas(agora)
        return len(lst) > maximo


def ip_cliente():
    return request.remote_addr or "?"


# ---------- Utilidades ----------
def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


BACKUP_DIR = os.path.join(BASE, "backups")


def fazer_backup():
    with LOCK:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        path = os.path.join(BACKUP_DIR, time.strftime("backup_%Y-%m-%d_%H-%M-%S.zip"))
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for raiz, _, arquivos in os.walk(DATA):
                for a in arquivos:
                    if not a.endswith(".tmp"):
                        full = os.path.join(raiz, a)
                        z.write(full, os.path.relpath(full, BASE))
        antigos = sorted(f for f in os.listdir(BACKUP_DIR) if f.endswith(".zip"))
        for f in antigos[:-14]:
            os.remove(os.path.join(BACKUP_DIR, f))
        return path


def backup_automatico():
    while True:
        try:
            zips = sorted(f for f in os.listdir(BACKUP_DIR) if f.endswith(".zip")) if os.path.isdir(BACKUP_DIR) else []
            recente = zips and time.time() - os.path.getmtime(os.path.join(BACKUP_DIR, zips[-1])) < 6 * 3600
            if not recente:
                fazer_backup()
        except Exception as e:
            print("Falha no backup automático:", e)
        time.sleep(6 * 3600)


def eh_dono():
    """Só vale para quem usa o próprio celular onde o servidor roda.
    Se a requisição veio por proxy/túnel (cabeçalhos de encaminhamento), NÃO é o dono."""
    h = request.headers
    if h.get("X-Forwarded-For") or h.get("X-Real-IP") or h.get("Forwarded"):
        return False
    return request.remote_addr in ("127.0.0.1", "::1")


def convite_certo():
    with LOCK:
        cfg = read_json(CONFIG_FILE, {})
        if not cfg.get("codigo_convite"):
            cfg["codigo_convite"] = secrets.token_hex(3).upper()
            write_json(CONFIG_FILE, cfg)
        return cfg["codigo_convite"]


def hash_code(code):
    return hashlib.sha256((SECRET + code).encode()).hexdigest()


def load_users():
    return read_json(USERS_FILE, {})


def current_uid():
    uid = session.get("uid")
    if uid and uid in load_users():
        return uid
    return None


def chat_dir(uid):
    return os.path.join(DATA, "chats", uid)


def trash_dir(uid):
    return os.path.join(DATA, "trash", uid)


def err(msg, status=400):
    return jsonify({"erro": msg}), status


def auth_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        uid = current_uid()
        if not uid:
            return err("Faça login para continuar.", 401)
        return fn(uid, *a, **kw)

    return wrapper


def purge_trash(uid):
    folder = trash_dir(uid)
    if not os.path.isdir(folder):
        return
    limit = time.time() - TRASH_DAYS * 86400
    with LOCK:
        for name in os.listdir(folder):
            if not name.endswith(".json"):
                continue
            path = os.path.join(folder, name)
            chat = read_json(path, None)
            if not chat:  # arquivo ilegível: não apaga, só ignora
                continue
            if chat.get("deleted_at", time.time()) < limit:
                os.remove(path)


# ---------- Segurança das requisições ----------
@app.before_request
def checar_origem():
    # Bloqueia requisições de escrita vindas de outros sites (proteção CSRF)
    if request.method in ("POST", "PUT", "DELETE", "PATCH"):
        origem = request.headers.get("Origin")
        if origem and origem != "null" and urlparse(origem).netloc != request.host:
            return err("Origem não permitida.", 403)


@app.after_request
def cabecalhos(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "same-origin"
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.errorhandler(500)
def erro_500(e):
    if request.path.startswith("/api/"):
        return err("Erro interno do servidor.", 500)
    return "Erro interno do servidor.", 500


@app.errorhandler(413)
def erro_413(e):
    return err("Conteúdo grande demais.", 413)


# ---------- Páginas ----------
@app.route("/")
def home():
    return render_template("Index.html")


# ---------- Conta ----------
@app.route("/api/register", methods=["POST"])
def register():
    ip = ip_cliente()
    if bloqueado(("reg", ip), 10, 600):
        return err("Muitas tentativas. Espere alguns minutos.", 429)
    d = request.get_json(silent=True) or {}
    convite = str(d.get("convite", "")).strip().upper().encode()
    if not secrets.compare_digest(convite, convite_certo().encode()):
        registrar(("reg", ip))
        return err("Código de convite incorreto. Peça o código a quem criou o app.", 403)
    if limitado(("novaconta", ip), 5, 3600):
        return err("Muitas contas criadas deste aparelho. Tente mais tarde.", 429)
    nick = str(d.get("apelido", "")).strip()[:30]
    birth = str(d.get("nascimento", "")).strip()
    if len(nick) < 2:
        return err("Escolha um apelido com pelo menos 2 letras.")
    try:
        y, m, dd = map(int, birth.split("-"))
        b = date(y, m, dd)
    except ValueError:
        return err("Informe uma data de nascimento válida.")
    today = date.today()
    age = today.year - b.year - ((today.month, today.day) < (b.month, b.day))
    if age < 18 or age > 120:
        return err("O CandyShopy Studio é apenas para maiores de 18 anos.")

    with LOCK:
        users = load_users()
        uid = "CS" + str(secrets.randbelow(900000) + 100000)
        while uid in users:
            uid = "CS" + str(secrets.randbelow(900000) + 100000)
        code = "-".join(secrets.token_hex(2).upper() for _ in range(4))
        users[uid] = {
            "code_hash": hash_code(code),
            "apelido": nick,
            "nascimento": birth,
            "criado_em": time.time(),
        }
        write_json(USERS_FILE, users)
    session.permanent = True
    session["uid"] = uid
    return jsonify({"uid": uid, "codigo": code, "apelido": nick})


@app.route("/api/login", methods=["POST"])
def login():
    ip = ip_cliente()
    if bloqueado(("login", ip), 10, 300):
        return err("Muitas tentativas erradas. Espere 5 minutos.", 429)
    d = request.get_json(silent=True) or {}
    code = str(d.get("codigo", "")).strip().upper()
    h = hash_code(code)
    for uid, u in load_users().items():  # só LÊ, nunca cria pastas
        if secrets.compare_digest(u["code_hash"], h):
            session.permanent = True
            session["uid"] = uid
            return jsonify({"uid": uid, "apelido": u["apelido"]})
    registrar(("login", ip))
    return err("Código não encontrado.", 401)


@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/me")
def me():
    uid = current_uid()
    if not uid:
        return err("Não logado.", 401)
    u = load_users()[uid]
    return jsonify({"uid": uid, "apelido": u["apelido"], "dono": eh_dono()})


@app.route("/diagnostico")
def diagnostico():
    try:
        with open(os.path.join(BASE, "templates", "Index.html"), encoding="utf-8") as f:
            tem = 'id="convite"' in f.read()
    except OSError:
        tem = False
    return (
        "<meta name=viewport content='width=device-width,initial-scale=1'><body style='font:18px sans-serif;padding:20px'>"
        "<h2>Diagnóstico do CandyShopy</h2>"
        "<p>Servidor: <b>funcionando ✅</b></p>"
        f"<p>Index.html novo (com campo de convite): <b>{'sim ✅' if tem else 'NÃO ❌ - cole o Index.html novo'}</b></p>"
        "<p id=js>JavaScript: <b>NÃO está rodando ❌ (use o Chrome)</b></p>"
        "<script>document.getElementById('js').innerHTML='JavaScript: <b>funcionando ✅</b>';</script>"
    )


@app.route("/api/convite")
def convite_dono():
    # só mostra o código para quem usa o celular onde o app roda
    return jsonify({"codigo": convite_certo()} if eh_dono() else {})


@app.route("/api/backup")
@auth_required
def backup(uid):
    if not eh_dono():
        return err("Só o dono do app, usando o celular onde ele roda, pode baixar o backup.", 403)
    path = fazer_backup()
    return send_file(path, as_attachment=True, download_name=os.path.basename(path))


# ---------- Chats ----------
def summary(c):
    return {"id": c.get("id", ""), "titulo": c.get("titulo", "Sem título"),
            "modo": c.get("modo", "livre"), "atualizado": c.get("atualizado", 0)}


@app.route("/api/chats", methods=["GET"])
@auth_required
def list_chats(uid):
    folder = chat_dir(uid)
    items = []
    if os.path.isdir(folder):
        for n in os.listdir(folder):
            if n.endswith(".json"):
                c = read_json(os.path.join(folder, n), None)
                if c:
                    items.append(summary(c))
    items.sort(key=lambda c: c["atualizado"], reverse=True)
    return jsonify(items)


@app.route("/api/chats", methods=["POST"])
@auth_required
def new_chat(uid):
    d = request.get_json(silent=True) or {}
    modo = d.get("modo") if d.get("modo") in MODES else "livre"
    cid = secrets.token_hex(6)
    chat = {"id": cid, "titulo": "Novo chat", "modo": modo, "criado": time.time(),
            "atualizado": time.time(), "mensagens": []}
    with LOCK:
        write_json(os.path.join(chat_dir(uid), cid + ".json"), chat)
    return jsonify(chat)


def chat_path(uid, cid):
    if not ID_RE.match(cid):
        return None
    p = os.path.join(chat_dir(uid), cid + ".json")
    return p if os.path.exists(p) else None


@app.route("/api/chats/<cid>", methods=["GET"])
@auth_required
def get_chat(uid, cid):
    p = chat_path(uid, cid)
    chat = read_json(p, None) if p else None
    if not chat:
        return err("Chat não encontrado.", 404)
    return jsonify(chat)


@app.route("/api/chats/<cid>", methods=["DELETE"])
@auth_required
def trash_chat(uid, cid):
    with LOCK:
        p = chat_path(uid, cid)
        chat = read_json(p, None) if p else None
        if not chat:
            return err("Chat não encontrado.", 404)
        chat["deleted_at"] = time.time()
        write_json(os.path.join(trash_dir(uid), cid + ".json"), chat)
        os.remove(p)
    return jsonify({"ok": True})


def sistema_do_chat(chat, profundo):
    sistema = MODES.get(chat.get("modo"), MODES["livre"])
    if chat.get("ficha"):
        sistema += "\n\nFicha da história (siga sempre, é a memória fixa):\n" + chat["ficha"]
    if profundo:
        sistema += " Pense com cuidado: planeje a continuidade, a personalidade dos personagens e a coerência dos fatos antes de escrever, e capriche nos detalhes."
    return sistema


MSG_LIMITE_IA = "Calma, muitas mensagens seguidas para a IA. Espere um minutinho e toque em Tentar de novo."


@app.route("/api/chats/<cid>/regenerar", methods=["POST"])
@auth_required
def regenerar(uid, cid):
    d = request.get_json(silent=True) or {}
    with LOCK:
        p = chat_path(uid, cid)
        chat = read_json(p, None) if p else None
        if not chat:
            return err("Chat não encontrado.", 404)
        total = len(chat["mensagens"])
        hist = chat["mensagens"]
        if hist and hist[-1]["role"] == "assistant":
            hist = hist[:-1]
        if not hist or hist[-1]["role"] != "user":
            return err("Não há resposta para regenerar.")
        msgs = [{"role": "system", "content": sistema_do_chat(chat, d.get("profundo"))}]
        msgs += [{"role": m["role"], "content": m["content"]} for m in hist[-30:]]
    if limitado(("ia", uid), 20, 60):
        return err(MSG_LIMITE_IA, 429)
    ok, result = call_ai(msgs)  # fora da trava: a IA demora e não pode travar os outros
    if not ok:
        return err(result, 502)
    with LOCK:
        chat = read_json(p, None)
        if not chat or len(chat["mensagens"]) != total:
            return err("O chat mudou enquanto a IA respondia. Tente de novo.", 409)
        chat["mensagens"] = hist + [{"role": "assistant", "content": result, "ts": time.time()}]
        chat["atualizado"] = time.time()
        write_json(p, chat)
    return jsonify({"ok": True})


@app.route("/api/chats/<cid>/msg/<int:idx>", methods=["PUT"])
@auth_required
def editar_msg(uid, cid, idx):
    texto = str((request.get_json(silent=True) or {}).get("texto", "")).strip()[:8000]
    if not texto:
        return err("A mensagem não pode ficar vazia.")
    with LOCK:
        p = chat_path(uid, cid)
        chat = read_json(p, None) if p else None
        if not chat:
            return err("Chat não encontrado.", 404)
        if idx < 0 or idx >= len(chat["mensagens"]):
            return err("Mensagem não encontrada.", 404)
        chat["mensagens"][idx]["content"] = texto
        write_json(p, chat)
    return jsonify({"ok": True})


@app.route("/api/chats/<cid>/ficha", methods=["PUT"])
@auth_required
def save_ficha(uid, cid):
    ficha = str((request.get_json(silent=True) or {}).get("ficha", ""))[:4000]
    with LOCK:
        p = chat_path(uid, cid)
        chat = read_json(p, None) if p else None
        if not chat:
            return err("Chat não encontrado.", 404)
        chat["ficha"] = ficha
        write_json(p, chat)
    return jsonify({"ok": True})


@app.route("/api/chats/<cid>/send", methods=["POST"])
@auth_required
def send(uid, cid):
    d = request.get_json(silent=True) or {}
    text = str(d.get("texto", "")).strip()[:8000]
    if not text:
        return err("Escreva uma mensagem.")

    # 1) salva a mensagem ANTES de chamar a IA (se a IA falhar, nada se perde)
    with LOCK:
        p = chat_path(uid, cid)
        chat = read_json(p, None) if p else None
        if not chat:
            return err("Chat não encontrado.", 404)
        chat["mensagens"].append({"role": "user", "content": text, "ts": time.time(), "autor": uid})
        if chat["titulo"] == "Novo chat":
            chat["titulo"] = text[:40]
        chat["atualizado"] = time.time()
        write_json(p, chat)
        msgs = [{"role": "system", "content": sistema_do_chat(chat, d.get("profundo"))}]
        msgs += [{"role": m["role"], "content": m["content"]} for m in chat["mensagens"][-30:]]
        titulo = chat["titulo"]

    if limitado(("ia", uid), 20, 60):
        return err(MSG_LIMITE_IA, 429)

    # 2) chama a IA fora da trava
    ok, result = call_ai(msgs)
    if not ok:
        return err(result + " (Sua mensagem foi salva.)", 502)

    # 3) salva a resposta
    with LOCK:
        chat = read_json(p, None)
        if not chat:
            return err("O chat foi apagado enquanto a IA respondia.", 404)
        chat["mensagens"].append({"role": "assistant", "content": result, "ts": time.time()})
        chat["atualizado"] = time.time()
        write_json(p, chat)
    return jsonify({"resposta": result, "titulo": titulo})


def call_ai(messages):
    key = read_json(CONFIG_FILE, {}).get("openrouter_api_key", "")
    if not key or key == "COLE_SUA_CHAVE_AQUI":
        return False, "Falta a chave do OpenRouter no arquivo config.json."
    body = json.dumps({"model": MODEL, "messages": messages}).encode()
    ultimo = "Erro inesperado ao falar com a IA."
    for tentativa in range(2):  # 1 nova tentativa em falhas passageiras
        req = urlreq.Request(API_URL, data=body, headers={
            "Authorization": "Bearer " + key,
            "Content-Type": "application/json",
            "X-Title": "CandyShopy Studio",
        })
        try:
            with urlreq.urlopen(req, timeout=120) as r:
                data = json.loads(r.read().decode())
            texto = ((data.get("choices") or [{}])[0].get("message") or {}).get("content")
            if texto and texto.strip():
                return True, texto
            ultimo = "A IA devolveu uma resposta vazia. Tente novamente."
        except urlerr.HTTPError as e:
            if e.code == 401:
                return False, "Chave do OpenRouter inválida."
            if e.code == 402:
                return False, "Sem créditos no OpenRouter."
            if e.code == 429:
                ultimo = "Limite de uso atingido. Tente de novo em instantes."
            elif e.code >= 500:
                ultimo = "A IA está instável agora. Tente de novo em instantes."
            else:
                return False, f"A IA retornou erro {e.code}."
        except (socket.timeout, TimeoutError):
            return False, "A IA demorou demais para responder. Tente de novo."
        except urlerr.URLError:
            return False, "Sem conexão com a internet ou com o OpenRouter."
        except (KeyError, IndexError, TypeError, AttributeError, json.JSONDecodeError):
            ultimo = "Resposta inesperada da IA. Tente novamente."
        except Exception:
            return False, "Erro inesperado ao falar com a IA."
        if tentativa == 0:
            time.sleep(2)
    return False, ultimo


# ---------- Lixeira (separada por usuário) ----------
@app.route("/api/trash")
@auth_required
def list_trash(uid):
    purge_trash(uid)
    items = []
    folder = trash_dir(uid)
    if os.path.isdir(folder):
        for n in os.listdir(folder):
            if not n.endswith(".json"):
                continue
            c = read_json(os.path.join(folder, n), None)
            if c:
                left = TRASH_DAYS - int((time.time() - c.get("deleted_at", time.time())) / 86400)
                items.append({**summary(c), "dias_restantes": max(left, 0)})
    return jsonify(items)


def trash_path(uid, cid):
    if not ID_RE.match(cid):
        return None
    p = os.path.join(trash_dir(uid), cid + ".json")
    return p if os.path.exists(p) else None


@app.route("/api/trash/<cid>/restore", methods=["POST"])
@auth_required
def restore(uid, cid):
    with LOCK:
        p = trash_path(uid, cid)
        chat = read_json(p, None) if p else None
        if not chat:
            return err("Item não encontrado na lixeira.", 404)
        chat.pop("deleted_at", None)
        write_json(os.path.join(chat_dir(uid), cid + ".json"), chat)
        os.remove(p)
    return jsonify({"ok": True})


@app.route("/api/trash/<cid>", methods=["DELETE"])
@auth_required
def delete_forever(uid, cid):
    with LOCK:
        p = trash_path(uid, cid)  # só procura na pasta DESTE usuário
        if not p:
            return err("Item não encontrado na lixeira.", 404)
        os.remove(p)
    return jsonify({"ok": True})


import Social  # amigos, mensagens privadas, grupos e ferramentas

Social.init(app, auth_required, err, read_json, write_json, load_users, call_ai, DATA, MODES, USERS_FILE,
            LOCK, limitado, bloqueado, registrar)


if __name__ == "__main__":
    threading.Thread(target=backup_automatico, daemon=True).start()
    print("=" * 40)
    print("Código de convite para seus amigos:", convite_certo())
    print("=" * 40)
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
