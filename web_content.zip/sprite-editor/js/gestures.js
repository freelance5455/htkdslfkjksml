/* Gestos sobre el stage: dibujar, pan, zoom, rotar, tap-undo. */
(function(){
  const SE = window.SE;
  const st = SE.state;

  const pointers = new Map();
  let mode = null;             // 'draw' | 'gesture' | null
  let gesture = null;
  let lastTapTime = 0;

  const stage = () => SE.dom.stage;

  function stagePt(e){
    const r = stage().getBoundingClientRect();
    return { sx: e.clientX - r.left, sy: e.clientY - r.top };
  }

  function startGesture(){
    const pts = [...pointers.values()];
    const dx = pts[1].sx - pts[0].sx;
    const dy = pts[1].sy - pts[0].sy;
    const mid = { x:(pts[0].sx+pts[1].sx)/2, y:(pts[0].sy+pts[1].sy)/2 };
    gesture = {
      startDist: Math.max(1, Math.hypot(dx,dy)),
      startAngle: Math.atan2(dy,dx),
      startMid: mid,
      startView: { ...SE.view },
      anchorCanvas: SE.screenToCanvasExact(mid.x, mid.y),
      t0: Date.now(),
      moved: 0,
      lastRot: SE.view.rot,
    };
  }

  function updateGesture(){
    const pts = [...pointers.values()];
    const dx = pts[1].sx - pts[0].sx;
    const dy = pts[1].sy - pts[0].sy;
    const dist = Math.hypot(dx,dy);
    const angle = Math.atan2(dy,dx);
    const mid = { x:(pts[0].sx+pts[1].sx)/2, y:(pts[0].sy+pts[1].sy)/2 };

    let ns = gesture.startView.scale * (dist / gesture.startDist);
    ns = SE.clamp(ns, 0.25, 64);

    let dRot = angle - gesture.startAngle;
    while(dRot > Math.PI) dRot -= 2*Math.PI;
    while(dRot < -Math.PI) dRot += 2*Math.PI;
    const nr = gesture.startView.rot + dRot;

    const c = Math.cos(nr), s = Math.sin(nr);
    SE.view.scale = ns;
    SE.view.rot = nr;
    SE.view.x = mid.x - ns*(gesture.anchorCanvas.x*c - gesture.anchorCanvas.y*s);
    SE.view.y = mid.y - ns*(gesture.anchorCanvas.x*s + gesture.anchorCanvas.y*c);

    gesture.lastRot = nr;
    gesture.moved = Math.max(gesture.moved, Math.hypot(mid.x-gesture.startMid.x, mid.y-gesture.startMid.y));
    SE.applyView();
  }

  function onDown(e){
    if(!st.project) return;
    if(e.pointerType==='mouse' && e.button!==0 && e.button!==1) return;
    e.preventDefault();
    try { stage().setPointerCapture(e.pointerId); } catch(_){}

    const pt = stagePt(e);
    pointers.set(e.pointerId, pt);

    if(st.playing) SE.stopPlay();

    if(pointers.size===1){
      const tool = SE.getCurrentTool();
      const pixel = SE.screenToPixel(pt.sx, pt.sy);
      const ok = tool.start({ x:pixel.x, y:pixel.y, sx:pt.sx, sy:pt.sy });
      mode = ok ? 'draw' : null;
    } else if(pointers.size===2){
      if(mode==='draw'){
        const tool = SE.getCurrentTool();
        tool.cancel && tool.cancel();
      }
      mode = 'gesture';
      startGesture();
    }
  }

  function onMove(e){
    if(!pointers.has(e.pointerId)) return;
    e.preventDefault();
    const pt = stagePt(e);
    pointers.set(e.pointerId, pt);

    const pixel = SE.screenToPixel(pt.sx, pt.sy);
    SE.emit('hover', pixel);

    if(mode==='draw' && pointers.size===1){
      SE.getCurrentTool().move && SE.getCurrentTool().move({ x:pixel.x, y:pixel.y, sx:pt.sx, sy:pt.sy });
      SE.scheduleRender();
    } else if(mode==='gesture' && pointers.size>=2 && gesture){
      updateGesture();
    }
  }

  function onUp(e){
    if(!pointers.has(e.pointerId)) return;
    pointers.delete(e.pointerId);

    if(mode==='gesture' && pointers.size<2 && gesture){
      const g = gesture;
      const elapsed = Date.now()-g.t0;
      const rotDelta = Math.abs(g.lastRot - g.startView.rot);
      const scaleDelta = Math.abs(SE.view.scale - g.startView.scale) / g.startView.scale;
      // Tap 2 dedos = undo
      if(elapsed<320 && g.moved<22 && rotDelta<0.14 && scaleDelta<0.09){
        SE.undo();
        SE.emit('toast','Deshacer');
        SE.haptic(15);
      }
      gesture = null;
      mode = null;
    }

    if(pointers.size===0){
      if(mode==='draw'){
        const tool = SE.getCurrentTool();
        tool.end && tool.end();
        SE.emit('frames-changed'); // refresca thumb
      }
      mode = null;
      gesture = null;
    }
  }

  function onCancel(e){
    if(!pointers.has(e.pointerId)) return;
    pointers.delete(e.pointerId);
    if(mode==='draw'){
      SE.getCurrentTool().cancel && SE.getCurrentTool().cancel();
    }
    if(pointers.size===0){
      mode = null;
      gesture = null;
    }
  }

  function onWheel(e){
    if(!st.project) return;
    e.preventDefault();
    const r = stage().getBoundingClientRect();
    const x = e.clientX - r.left, y = e.clientY - r.top;
    SE.zoomAt(x, y, Math.exp(-e.deltaY * 0.0015));
  }

  SE.initGestures = ()=>{
    const s = stage();
    s.addEventListener('pointerdown', onDown);
    s.addEventListener('pointermove', onMove);
    s.addEventListener('pointerup', onUp);
    s.addEventListener('pointercancel', onCancel);
    s.addEventListener('lostpointercapture', onCancel);
    s.addEventListener('contextmenu', e=>e.preventDefault());
    s.addEventListener('wheel', onWheel, { passive:false });
  };
})();