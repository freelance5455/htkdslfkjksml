/* Toda la interfaz: barra, timeline, capas, menú, popups, modales. */
(function(){
  const SE = window.SE;
  const st = SE.state;
  const $ = SE.$;

  /* -------- Referencias -------- */
  const els = {};

  /* -------- Toast -------- */
  let toastTimer = null;
  SE.on('toast', (msg)=>{
    const t = $('toast');
    if(!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(()=>t.classList.remove('show'), 1300);
  });

  /* -------- Timeline -------- */
  function renderTimeline(force){
    const tl = $('timeline');
    const p = st.project;
    if(!p){ tl.innerHTML=''; return; }
    const scale = SE.thumbScale = Math.min(56/p.frameWidth, 56/p.frameHeight, 4);
    // diff mínimo: si el número de frames no cambió, sólo actualizamos selección
    const needRebuild = force || tl.childElementCount !== p.frames.length;
    if(needRebuild){
      tl.innerHTML = '';
      const frag = document.createDocumentFragment();
      p.frames.forEach((_,i)=>{
        const d = document.createElement('div');
        d.className = 'thumb' + (i===st.currentFrame?' selected':'');
        d.dataset.idx = i;
        d.appendChild(SE.makeThumb(i, scale));
        const num = document.createElement('div');
        num.className='num'; num.textContent = i+1;
        d.appendChild(num);
        d.addEventListener('pointerdown', ev=>{
          ev.preventDefault();
          if(st.playing) SE.stopPlay();
          st.currentFrame = i;
          if(st.currentLayer >= p.frames[i].layers.length) st.currentLayer = p.frames[i].layers.length-1;
          SE.emit('frame-changed');
          SE.scheduleRender();
          renderTimeline(false);
          renderLayerList();
          updateFrameInfo();
        });
        frag.appendChild(d);
      });
      tl.appendChild(frag);
    } else {
      tl.querySelectorAll('.thumb').forEach(el=>{
        el.classList.toggle('selected', +el.dataset.idx === st.currentFrame);
      });
    }
    // scroll al seleccionado
    const sel = tl.querySelector('.thumb.selected');
    if(sel) sel.scrollIntoView({ inline:'center', block:'nearest', behavior:'smooth' });
  }

  function updateThumb(i){
    const tl = $('timeline');
    const el = tl.querySelector(`.thumb[data-idx="${i}"]`);
    if(!el) return;
    const old = el.querySelector('canvas');
    if(old) el.replaceChild(SE.makeThumb(i, SE.thumbScale), old);
  }

  /* -------- Capas -------- */
  function renderLayerList(){
    const list = $('layerList');
    const p = st.project;
    if(!p){ list.innerHTML=''; return; }
    const frame = p.frames[st.currentFrame];
    if(!frame) return;
    if(st.currentLayer >= frame.layers.length) st.currentLayer = frame.layers.length-1;
    list.innerHTML = '';
    for(let i=frame.layers.length-1; i>=0; i--){
      const layer = frame.layers[i];
      const row = document.createElement('div');
      row.className = 'layer-item' + (i===st.currentLayer?' selected':'');

      // mini canvas
      const mini = SE.newCanvas(p.frameWidth, p.frameHeight);
      const s = Math.min(36/p.frameWidth, 36/p.frameHeight, 1);
      const w = Math.max(1, Math.round(p.frameWidth*s));
      const h = Math.max(1, Math.round(p.frameHeight*s));
      mini.width = w; mini.height = h;
      mini.className = 'thumb-mini';
      mini.style.width = w+'px'; mini.style.height = h+'px';
      mini.getContext('2d').drawImage(layer.canvas, 0, 0, w, h);
      row.appendChild(mini);

      const nm = document.createElement('div');
      nm.className = 'nm';
      nm.textContent = layer.name;
      if(!layer.visible) nm.style.opacity = '.45';
      row.appendChild(nm);

      const modeTag = document.createElement('span');
      modeTag.className = 'mode';
      if(layer.blend && layer.blend!=='source-over'){
        modeTag.textContent = { multiply:'×', screen:'⊙', overlay:'◐', lighter:'+', difference:'Δ' }[layer.blend] || layer.blend;
      }
      row.appendChild(modeTag);

      const vis = document.createElement('input');
      vis.type = 'checkbox'; vis.checked = layer.visible;
      vis.addEventListener('click', e=>e.stopPropagation());
      vis.addEventListener('change', ()=>{
        layer.visible = vis.checked;
        SE.invalidate(st.currentFrame);
        SE.emit('composite', st.currentFrame);
        renderLayerList();
        SE.scheduleRender();
        updateThumb(st.currentFrame);
      });
      row.appendChild(vis);

      row.addEventListener('click', ()=>{
        st.currentLayer = i;
        renderLayerList();
        syncLayerPanel();
      });
      // long-press rename
      let lp = null;
      row.addEventListener('pointerdown', ()=>{
        lp = setTimeout(()=>{
          lp = null;
          const name = prompt('Nombre de la capa:', layer.name);
          if(name){ layer.name = name; renderLayerList(); }
        }, 550);
      });
      row.addEventListener('pointerup', ()=>{ if(lp){ clearTimeout(lp); lp=null; } });
      row.addEventListener('pointerleave', ()=>{ if(lp){ clearTimeout(lp); lp=null; } });

      list.appendChild(row);
    }
  }

  function syncLayerPanel(){
    const p = st.project;
    if(!p) return;
    const layer = p.frames[st.currentFrame]?.layers[st.currentLayer];
    if(!layer) return;
    $('layerOpacity').value = Math.round(layer.opacity*100);
    $('layerOpacityVal').textContent = Math.round(layer.opacity*100);
    $('layerVisible').checked = layer.visible;
    $('layerLocked').checked = layer.locked;
    $('layerBlend').value = layer.blend || 'source-over';
    $('layerFrameNum').textContent = (st.currentFrame+1);
  }

  /* -------- Info de frames -------- */
  function updateFrameInfo(){
    const p = st.project;
    $('frameCount').textContent = p ? p.frames.length : 0;
    $('frameCurrent').textContent = p ? (st.currentFrame+1) : 0;
  }

  /* -------- Toolbar sync -------- */
  function syncToolbar(){
    $('tbTool').textContent = SE.TOOL_ICONS[st.tool] || '✏️';
    $('tbTool').classList.toggle('active', st.tool!=='pencil');
    $('tbSizeVal').textContent = st.brush.size;
    $('tbColorA').style.background = st.color;
    $('tbColorB').style.background = st.colorB;
    $('tbUndo').disabled = SE.history.undo.length===0;
    $('tbRedo').disabled = SE.history.redo.length===0;
    document.querySelectorAll('.tool-btn').forEach(b=>{
      b.classList.toggle('active', b.dataset.tool===st.tool);
    });
  }

  /* -------- Popups -------- */
  function togglePopup(id){
    const el = $(id);
    const willShow = el.classList.contains('hidden');
    ['popSize','popColor'].forEach(x=>$(x).classList.add('hidden'));
    if(willShow) el.classList.remove('hidden');
  }

  /* -------- Sheet -------- */
  function openSheet(panel){
    document.querySelectorAll('.panel').forEach(p=>p.classList.add('hidden'));
    $('panel-'+panel).classList.remove('hidden');
    $('sheet').classList.add('open');
    $('backdrop').classList.add('open');
    ['popSize','popColor'].forEach(id=>$(id).classList.add('hidden'));
  }
  function closeSheet(){
    $('sheet').classList.remove('open');
    $('backdrop').classList.remove('open');
  }
  SE.closeSheet = closeSheet;

  /* -------- Menú: herramientas -------- */
  function buildToolGrid(){
    const grid = $('toolGrid');
    grid.innerHTML = '';
    SE.TOOL_ORDER.forEach(k=>{
      const b = document.createElement('button');
      b.className = 'tool-btn';
      b.dataset.tool = k;
      b.textContent = SE.TOOL_ICONS[k];
      b.title = SE.TOOL_NAMES[k];
      b.onclick = ()=>{
        st.tool = k;
        syncToolbar();
        SE.emit('toast', SE.TOOL_NAMES[k]);
        SE.haptic(8);
      };
      grid.appendChild(b);
    });
    syncToolbar();
  }

  /* -------- Set de controles del menú -------- */
  function syncMenuControls(){
    $('shapeFillToggle').textContent = 'Relleno: ' + (st.shape.fill?'ON':'OFF');
    $('shapeFillToggle').classList.toggle('active', st.shape.fill);
    $('shapeStroke').value = st.shape.stroke;
    $('symX').classList.toggle('active', st.symmetry.x);
    $('symY').classList.toggle('active', st.symmetry.y);
    $('gridEnabled').checked = st.grid.show;
    $('gridSize').value = st.grid.size;
    $('onionEnabled').checked = st.onion.enabled;
    $('onionPrev').value = st.onion.prev;
    $('onionNext').value = st.onion.next;
    $('onionOpacity').value = Math.round(st.onion.opacity*100);
    $('onionOpacityVal').textContent = Math.round(st.onion.opacity*100);
    $('fps').value = st.project?.fps || 12;
    $('loopPlay').checked = st.loop;
    $('pingpong').checked = st.pingpong;
    document.querySelectorAll('.ctab').forEach(t=>t.classList.toggle('active', t.dataset.tab===st.editSlot));
  }

  /* -------- Setup -------- */
  function setup(){
    /* Header */
    $('btnNew').onclick = ()=>{
      $('newModal').classList.remove('hidden');
      setTimeout(()=>$('newW').focus(), 100);
    };
    $('btnImport').onclick = ()=> $('fileInput').click();
    $('btnExport').onclick = ()=> SE.exportSheet();
    $('btnSave').onclick   = ()=> SE.saveProject();
    $('btnLoad').onclick   = ()=> $('projInput').click();

    /* Toolbar */
    $('tbUndo').onclick = ()=>{ if(SE.undo()){ renderTimeline(false); renderLayerList(); updateThumb(st.currentFrame); }};
    $('tbRedo').onclick = ()=>{ if(SE.redo()){ renderTimeline(false); renderLayerList(); updateThumb(st.currentFrame); }};
    $('tbTool').onclick = ()=>{
      const order = SE.TOOL_ORDER;
      const i = order.indexOf(st.tool);
      st.tool = order[(i+1)%order.length];
      syncToolbar();
      SE.emit('toast', SE.TOOL_NAMES[st.tool]);
    };
    $('tbTool').addEventListener('contextmenu', e=>{ e.preventDefault(); openSheet('menu'); });
    $('tbSwap').onclick = ()=>{ SE.swapColors(); };
    $('tbSize').onclick = (e)=>{ e.stopPropagation(); togglePopup('popSize'); };
    $('tbColor').onclick = (e)=>{ e.stopPropagation(); togglePopup('popColor'); };
    $('tbTimeline').onclick = ()=>{
      const tl = $('timeline');
      tl.classList.toggle('hidden');
      $('tbTimeline').textContent = tl.classList.contains('hidden') ? '⬆' : '⬇';
    };
    $('tbLayers').onclick = ()=>{ renderLayerList(); syncLayerPanel(); openSheet('layers'); };
    $('tbMenu').onclick   = ()=>{ syncMenuControls(); openSheet('menu'); };

    /* Cierre de popups al tocar fuera */
    document.addEventListener('pointerdown', e=>{
      ['popSize','popColor'].forEach(id=>{
        const el = $(id);
        if(el.classList.contains('hidden')) return;
        if(el.contains(e.target)) return;
        if($('tbSize').contains(e.target) || $('tbColor').contains(e.target)) return;
        el.classList.add('hidden');
      });
    }, true);

    /* Size / Opacity popup */
    $('sizeSlider').oninput = e=> setBrushSize(+e.target.value);
    $('opacitySlider').oninput = e=> setBrushOpacity(+e.target.value);

    /* Color popup */
    $('colorInput').oninput = e=> SE.setColor(e.target.value, st.editSlot);
    $('colorHex').oninput = e=>{
      const v = e.target.value.trim();
      if(/^#?[0-9a-fA-F]{3}$/.test(v) || /^#?[0-9a-fA-F]{6}$/.test(v)){
        const hex = v.startsWith('#')?v:'#'+v;
        SE.setColor(hex, st.editSlot);
      }
    };
    document.querySelectorAll('.ctab').forEach(t=>{
      t.onclick = ()=>{ st.editSlot = t.dataset.tab; syncMenuControls(); SE.emit('color'); };
    });
    const pal = $('swatches');
    pal.innerHTML = '';
    (st.palette||[]).forEach(hex=>{
      const b = document.createElement('button');
      b.style.background = hex;
      b.onclick = ()=> SE.setColor(hex, st.editSlot);
      pal.appendChild(b);
    });

    /* Sheet */
    $('backdrop').onclick = closeSheet;
    $('sheet').querySelector('.grabber').onclick = closeSheet;

    /* Menú: herramientas */
    buildToolGrid();

    /* Forma */
    $('shapeFillToggle').onclick = ()=>{ st.shape.fill = !st.shape.fill; syncMenuControls(); };
    $('shapeStroke').oninput = e=>{ st.shape.stroke = Math.max(1, +e.target.value||1); };

    /* Simetría */
    $('symX').onclick = ()=>{ st.symmetry.x = !st.symmetry.x; syncMenuControls(); SE.renderOverlay(); };
    $('symY').onclick = ()=>{ st.symmetry.y = !st.symmetry.y; syncMenuControls(); SE.renderOverlay(); };

    /* Cuadrícula */
    $('gridEnabled').onchange = e=>{ st.grid.show = e.target.checked; SE.renderOverlay(); };
    $('gridSize').oninput = e=>{ st.grid.size = Math.max(1, Math.min(128, +e.target.value||8)); SE.renderOverlay(); };

    /* Onion */
    $('onionEnabled').onchange = e=>{ st.onion.enabled = e.target.checked; SE.renderEditor(); };
    $('onionPrev').oninput = e=>{ st.onion.prev = SE.clamp(+e.target.value||0, 0, 6); SE.renderEditor(); };
    $('onionNext').oninput = e=>{ st.onion.next = SE.clamp(+e.target.value||0, 0, 6); SE.renderEditor(); };
    $('onionOpacity').oninput = e=>{
      st.onion.opacity = (+e.target.value)/100;
      $('onionOpacityVal').textContent = e.target.value;
      SE.renderEditor();
    };

    /* Frames */
    $('btnAddFrame').onclick = ()=> addFrame(false);
    $('btnDupFrame').onclick = ()=> addFrame(true);
    $('btnDelFrame').onclick = delFrame;
    $('btnMoveLeft').onclick  = ()=> moveFrame(-1);
    $('btnMoveRight').onclick = ()=> moveFrame(1);
    $('btnClearFrame').onclick = clearFrame;

    /* Capas */
    $('btnAddLayer').onclick = addLayer;
    $('btnDupLayer').onclick = dupLayer;
    $('btnDelLayer').onclick = delLayer;
    $('btnLayerUp').onclick   = ()=> reorderLayer(1);
    $('btnLayerDown').onclick = ()=> reorderLayer(-1);
    $('btnMergeDown').onclick = mergeLayerDown;
    $('btnRenameLayer').onclick = renameLayer;
    $('btnClearLayer').onclick = clearLayer;
    $('layerOpacity').oninput = e=>{
      const l = SE.layer(); if(!l) return;
      l.opacity = (+e.target.value)/100;
      $('layerOpacityVal').textContent = e.target.value;
      SE.invalidate(st.currentFrame);
      SE.emit('composite', st.currentFrame);
      updateThumb(st.currentFrame);
    };
    $('layerBlend').onchange = e=>{
      const l = SE.layer(); if(!l) return;
      l.blend = e.target.value;
      SE.invalidate(st.currentFrame);
      SE.emit('composite', st.currentFrame);
      updateThumb(st.currentFrame);
    };
    $('layerVisible').onchange = e=>{
      const l = SE.layer(); if(!l) return;
      l.visible = e.target.checked;
      SE.invalidate(st.currentFrame);
      SE.emit('composite', st.currentFrame);
      renderLayerList(); updateThumb(st.currentFrame);
    };
    $('layerLocked').onchange = e=>{
      const l = SE.layer(); if(!l) return;
      l.locked = e.target.checked;
    };

    /* Animación */
    $('btnPlay').onclick = ()=> st.playing ? SE.stopPlay() : SE.startPlay();
    $('fps').oninput = e=>{
      if(st.project) st.project.fps = SE.clamp(+e.target.value||12, 1, 60);
      if(st.playing){ SE.stopPlay(); SE.startPlay(); }
    };
    $('loopPlay').onchange = e=>{ st.loop = e.target.checked; };
    $('pingpong').onchange = e=>{ st.pingpong = e.target.checked; };

    /* Vista */
    $('btnFit').onclick = ()=> SE.fitView();
    $('btn1to1').onclick = ()=>{ SE.view.scale = 1; SE.applyView(); };
    $('btnRot0').onclick = ()=>{ SE.view.rot = 0; SE.fitView(); };
    $('btnZoomIn').onclick  = ()=> SE.zoomAt(SE.dom.stage.clientWidth/2, SE.dom.stage.clientHeight/2, 1.35);
    $('btnZoomOut').onclick = ()=> SE.zoomAt(SE.dom.stage.clientWidth/2, SE.dom.stage.clientHeight/2, 1/1.35);

    /* Tema */
    $('themeSel').onchange = e=>{
      document.documentElement.dataset.theme = e.target.value;
      try{ localStorage.setItem('se-theme', e.target.value); }catch(_){}
    };
    const savedTheme = (()=>{ try{ return localStorage.getItem('se-theme'); }catch(_){ return null; }})();
    if(savedTheme){ $('themeSel').value = savedTheme; document.documentElement.dataset.theme = savedTheme; }

    /* Modales */
    $('newCancel').onclick = ()=> $('newModal').classList.add('hidden');
    $('newOk').onclick = ()=>{
      const w = SE.clamp(+$('newW').value||32, 1, 512);
      const h = SE.clamp(+$('newH').value||32, 1, 512);
      const n = SE.clamp(+$('newLayers').value||1, 1, 10);
      SE.newProject(w, h, n);
      $('newModal').classList.add('hidden');
    };
    $('impCancel').onclick = ()=>{ $('modal').classList.add('hidden'); SE.pendingImage=null; };
    $('impOk').onclick = ()=> SE.confirmImport();
    $('impW').oninput = ()=> SE.syncImportFromPixels();
    $('impH').oninput = ()=> SE.syncImportFromPixels();
    $('impCols').oninput = ()=> SE.syncImportFromFrames();
    $('impRows').oninput = ()=> SE.syncImportFromFrames();
    $('expCancel').onclick = ()=> $('exportModal').classList.add('hidden');
    $('expOk').onclick = ()=> SE.doExport();
    $('expCols').oninput = ()=> SE.updateExportPreview();
    $('expScale').oninput = ()=> SE.updateExportPreview();

    /* Atajos de teclado */
    window.addEventListener('keydown', e=>{
      if(e.target.tagName==='INPUT' || e.target.tagName==='SELECT') return;
      const p = st.project; if(!p) return;
      if(e.key===' '){ e.preventDefault(); st.playing?SE.stopPlay():SE.startPlay(); }
      else if(e.key==='ArrowLeft'){ if(st.currentFrame>0){ st.currentFrame--; SE.emit('frame-changed'); SE.scheduleRender(); renderTimeline(false); renderLayerList(); updateFrameInfo(); }}
      else if(e.key==='ArrowRight'){ if(st.currentFrame<p.frames.length-1){ st.currentFrame++; SE.emit('frame-changed'); SE.scheduleRender(); renderTimeline(false); renderLayerList(); updateFrameInfo(); }}
      else if((e.ctrlKey||e.metaKey) && e.key==='z' && !e.shiftKey){ e.preventDefault(); SE.undo(); renderTimeline(false); renderLayerList(); updateThumb(st.currentFrame); }
      else if((e.ctrlKey||e.metaKey) && (e.key==='y'||(e.key==='z'&&e.shiftKey))){ e.preventDefault(); SE.redo(); renderTimeline(false); renderLayerList(); updateThumb(st.currentFrame); }
      else if(e.key==='e'||e.key==='E'){ $('tbTool').click(); }
      else if(e.key==='b'||e.key==='B'){ st.tool='pencil'; syncToolbar(); }
      else if(e.key==='g'||e.key==='G'){ st.grid.show = !st.grid.show; SE.renderOverlay(); }
    });

    /* Resize */
    window.addEventListener('resize', ()=>{
      SE.dom.stage && SE.renderOverlay();
      if(st.project) SE.fitView();
    });
    window.addEventListener('orientationchange', ()=> setTimeout(()=>{
      SE.renderOverlay();
      if(st.project) SE.fitView();
    }, 300));
  }

  /* -------- setBrushSize / Opacity -------- */
  function setBrushSize(v){
    st.brush.size = SE.clamp(v|0, 1, 64);
    $('sizeSlider').value = st.brush.size;
    $('sizeVal').textContent = st.brush.size;
    $('tbSizeVal').textContent = st.brush.size;
  }
  function setBrushOpacity(v){
    st.brush.opacity = SE.clamp(v/100, 0.01, 1);
    const pc = Math.round(st.brush.opacity*100);
    $('opacitySlider').value = pc;
    $('opacityVal').textContent = pc;
  }
  SE.setBrushSize = setBrushSize;
  SE.setBrushOpacity = setBrushOpacity;

  /* -------- Operaciones de frames -------- */
  function addFrame(dup){
    const p = st.project; if(!p) return;
    const src = p.frames[st.currentFrame];
    let nf;
    if(dup){
      nf = { layers: src.layers.map(l=>{
        const c = SE.newCanvas(p.frameWidth, p.frameHeight);
        SE.ctx(c).drawImage(l.canvas,0,0);
        return { name:l.name, visible:l.visible, opacity:l.opacity, locked:l.locked, blend:l.blend, canvas:c };
      })};
    } else {
      nf = SE.newFrame(p.frameWidth, p.frameHeight, src.layers.length);
      nf.layers.forEach((l,i)=>{ l.name = src.layers[i].name; });
    }
    p.frames.splice(st.currentFrame+1, 0, nf);
    st.currentFrame++;
    SE.invalidate();
    renderTimeline(true); renderLayerList(); updateFrameInfo();
    SE.scheduleRender(); SE.emit('frame-changed');
  }
  function delFrame(){
    const p = st.project; if(!p) return;
    if(p.frames.length<=1){ SE.emit('toast','Debe quedar al menos 1 frame'); return; }
    if(!confirm('¿Borrar el frame actual?')) return;
    p.frames.splice(st.currentFrame,1);
    if(st.currentFrame>=p.frames.length) st.currentFrame = p.frames.length-1;
    SE.invalidate();
    renderTimeline(true); renderLayerList(); updateFrameInfo(); SE.scheduleRender();
  }
  function moveFrame(dir){
    const p = st.project; if(!p) return;
    const i = st.currentFrame;
    const j = i+dir;
    if(j<0 || j>=p.frames.length) return;
    [p.frames[i], p.frames[j]] = [p.frames[j], p.frames[i]];
    st.currentFrame = j;
    renderTimeline(true); updateFrameInfo();
  }
  function clearFrame(){
    const p = st.project; if(!p) return;
    if(!confirm('¿Limpiar todas las capas del frame actual?')) return;
    const frame = p.frames[st.currentFrame];
    frame.layers.forEach(l=> SE.ctx(l.canvas).clearRect(0,0,l.canvas.width,l.canvas.height));
    SE.clearHistory(); SE.invalidate();
    renderLayerList(); SE.scheduleRender(); updateThumb(st.currentFrame);
  }

  /* -------- Operaciones de capas -------- */
  function addLayer(){
    const p = st.project; if(!p) return;
    const frame = p.frames[st.currentFrame];
    frame.layers.push(SE.newLayer(p.frameWidth, p.frameHeight, 'Capa '+(frame.layers.length+1)));
    st.currentLayer = frame.layers.length-1;
    SE.invalidate(st.currentFrame);
    renderLayerList(); syncLayerPanel(); updateThumb(st.currentFrame); SE.scheduleRender();
  }
  function dupLayer(){
    const p = st.project; if(!p) return;
    const frame = p.frames[st.currentFrame];
    const src = frame.layers[st.currentLayer];
    const c = SE.newCanvas(p.frameWidth, p.frameHeight);
    SE.ctx(c).drawImage(src.canvas,0,0);
    const nl = { name: src.name+' copia', visible:src.visible, opacity:src.opacity, locked:src.locked, blend:src.blend, canvas:c };
    frame.layers.splice(st.currentLayer+1, 0, nl);
    st.currentLayer++;
    SE.invalidate(st.currentFrame);
    renderLayerList(); syncLayerPanel(); updateThumb(st.currentFrame); SE.scheduleRender();
  }
  function delLayer(){
    const frame = SE.frame(); if(!frame) return;
    if(frame.layers.length<=1){ SE.emit('toast','Debe quedar al menos 1 capa'); return; }
    if(!confirm('¿Borrar la capa actual?')) return;
    frame.layers.splice(st.currentLayer,1);
    if(st.currentLayer>=frame.layers.length) st.currentLayer = frame.layers.length-1;
    SE.invalidate(st.currentFrame);
    renderLayerList(); syncLayerPanel(); updateThumb(st.currentFrame); SE.scheduleRender();
  }
  function reorderLayer(dir){
    const frame = SE.frame(); if(!frame) return;
    const i = st.currentLayer, j = i+dir;
    if(j<0 || j>=frame.layers.length) return;
    [frame.layers[i], frame.layers[j]] = [frame.layers[j], frame.layers[i]];
    st.currentLayer = j;
    SE.invalidate(st.currentFrame);
    renderLayerList(); syncLayerPanel(); updateThumb(st.currentFrame); SE.scheduleRender();
  }
  function mergeLayerDown(){
    const frame = SE.frame(); if(!frame) return;
    const i = st.currentLayer;
    if(i<=0){ SE.emit('toast','No hay capa debajo'); return; }
    const top = frame.layers[i], bot = frame.layers[i-1];
    const x = SE.ctx(bot.canvas);
    x.save();
    x.globalAlpha = top.opacity;
    x.globalCompositeOperation = top.blend || 'source-over';
    x.drawImage(top.canvas,0,0);
    x.restore();
    frame.layers.splice(i,1);
    st.currentLayer = i-1;
    SE.invalidate(st.currentFrame);
    renderLayerList(); syncLayerPanel(); updateThumb(st.currentFrame); SE.scheduleRender();
    SE.emit('toast','Capas fusionadas');
  }
  function renameLayer(){
    const l = SE.layer(); if(!l) return;
    const name = prompt('Nombre de la capa:', l.name);
    if(name){ l.name = name; renderLayerList(); }
  }
  function clearLayer(){
    const l = SE.layer(); if(!l) return;
    const before = SE.snapLayer(st.currentFrame, st.currentLayer);
    SE.ctx(l.canvas).clearRect(0,0,l.canvas.width,l.canvas.height);
    SE.commitPixels(st.currentFrame, st.currentLayer, before);
    SE.invalidate(st.currentFrame);
    renderLayerList(); updateThumb(st.currentFrame); SE.scheduleRender();
    SE.emit('toast','Capa limpiada');
  }

  /* -------- PLAY -------- */
  SE.startPlay = ()=>{
    const p = st.project; if(!p) return;
    if(p.frames.length<2){ SE.emit('toast','Sólo hay 1 frame'); return; }
    st.playing = true; st.playDir = 1;
    $('btnPlay').textContent = '⏸ Pausa';
    const step = ()=>{
      if(!st.playing) return;
      const n = p.frames.length;
      let next;
      if(st.pingpong){
        next = st.currentFrame + st.playDir;
        if(next>=n){ next = n-2; st.playDir = -1; }
        else if(next<0){ next = 1; st.playDir = 1; }
        next = SE.clamp(next, 0, n-1);
      } else {
        next = st.currentFrame + 1;
        if(next>=n){
          if(!st.loop){ SE.stopPlay(); return; }
          next = 0;
        }
      }
      st.currentFrame = next;
      SE.renderEditor(); SE.renderPreview();
      $('timeline').querySelectorAll('.thumb').forEach(el=>{
        el.classList.toggle('selected', +el.dataset.idx===st.currentFrame);
      });
      const sel = $('timeline').querySelector('.thumb.selected');
      if(sel) sel.scrollIntoView({ inline:'center', block:'nearest', behavior:'auto' });
      st.playTimer = setTimeout(step, 1000/(p.fps||12));
    };
    st.playTimer = setTimeout(step, 1000/(p.fps||12));
  };
  SE.stopPlay = ()=>{
    st.playing = false;
    clearTimeout(st.playTimer);
    $('btnPlay').textContent = '▶ Reproducir';
    SE.renderEditor();
  };

  /* -------- Exponer renderers -------- */
  SE.renderTimeline = renderTimeline;
  SE.renderLayerList = renderLayerList;
  SE.updateThumb = updateThumb;
  SE.updateFrameInfo = updateFrameInfo;
  SE.syncToolbar = syncToolbar;
  SE.syncLayerPanel = syncLayerPanel;
  SE.syncMenuControls = syncMenuControls;
  SE.setupUI = setup;
  SE.els = els;
})();