/* Arranque: inicializa todo y conecta eventos. */
(function(){
  const SE = window.SE;

  function boot(){
    SE.initRender();
    SE.initGestures();
    SE.setupUI();
    SE.wireFileInputs();
    SE.setBrushSize(1);
    SE.setBrushOpacity(100);

    // Listeners centrales
    SE.on('composite', (i)=>{
      SE.invalidate(i);
      SE.scheduleRender();
    });
    SE.on('history', ()=> SE.syncToolbar());
    SE.on('color', ()=>{
      SE.syncToolbar();
      const ci = SE.$('colorInput');
      const ch = SE.$('colorHex');
      const c = SE.activeColor();
      if(ci) ci.value = c;
      if(ch) ch.value = c;
      // rebuild recent swatches
      const r = SE.$('recentColors');
      if(r){
        r.innerHTML = '';
        SE.state.recentColors.forEach(hex=>{
          const b = document.createElement('button');
          b.style.background = hex;
          b.onclick = ()=> SE.setColor(hex, SE.state.editSlot);
          r.appendChild(b);
        });
      }
    });
    SE.on('frames-changed', ()=>{
      SE.updateThumb(SE.state.currentFrame);
    });
    SE.on('frame-changed', ()=>{
      SE.renderTimeline(false);
      SE.renderLayerList();
      SE.updateFrameInfo();
    });
    SE.on('hover', (p)=>{
      const el = SE.$('hudCoords');
      if(el) el.textContent = p.x+','+p.y;
    });

    // Drag & drop
    const stage = SE.dom.stage;
    stage.addEventListener('dragover', e=>e.preventDefault());
    stage.addEventListener('drop', (e)=>{
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if(!file || !file.type.startsWith('image/')) return;
      const img = new Image();
      img.onload = ()=>{ SE.askFrameSize(img); URL.revokeObjectURL(img.src); };
      img.src = URL.createObjectURL(file);
    });

    // Render inicial
    SE.renderOverlay();
    SE.applyView();
    SE.syncToolbar();
    SE.syncMenuControls();

    // Arranca con un proyecto demo vacío (32×32, 1 capa)
    SE.newProject(32, 32, 1);
    SE.state.currentFrame = 0;
    SE.state.currentLayer = 0;
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();