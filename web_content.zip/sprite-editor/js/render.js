/* Render: composición de frames, capas, overlay, thumbnails, vista. */
(function(){
  const SE = window.SE;
  const { $, newCanvas, ctx, emit } = SE;

  SE.dom = {
    stage: null, editor:null, ectx:null,
    overlay:null, octx:null, preview:null, pctx:null,
    timeline:null
  };

  const DPR = Math.min(2, window.devicePixelRatio||1);

  /* ---------- Caché de composites ---------- */
  const compCache = new Map();     // frameIdx -> canvas
  const tintCache = new Map();     // `idx|tint` -> canvas

  SE.invalidate = (i)=>{
    if(i===undefined) compCache.clear();
    else compCache.delete(i);
    tintCache.clear();
  };

  SE.getComposite = (idx)=>{
    let c = compCache.get(idx);
    if(c) return c;
    const p = SE.state.project;
    if(!p) return newCanvas(1,1);
    const frame = p.frames[idx];
    if(!frame) return newCanvas(p.frameWidth, p.frameHeight);
    c = newCanvas(p.frameWidth, p.frameHeight);
    const x = ctx(c);
    x.imageSmoothingEnabled = false;
    for(const l of frame.layers){
      if(!l.visible || l.opacity<=0) continue;
      x.globalAlpha = l.opacity;
      x.globalCompositeOperation = l.blend || 'source-over';
      x.drawImage(l.canvas,0,0);
    }
    x.globalAlpha = 1;
    x.globalCompositeOperation = 'source-over';
    compCache.set(idx, c);
    if(compCache.size>64) compCache.delete(compCache.keys().next().value);
    return c;
  };

  function tintedFrame(idx, tint){
    const key = idx+'|'+tint;
    let c = tintCache.get(key);
    if(c) return c;
    const base = SE.getComposite(idx);
    c = newCanvas(base.width, base.height);
    const x = ctx(c);
    x.drawImage(base,0,0);
    x.globalCompositeOperation = 'source-atop';
    x.globalAlpha = 0.7;
    x.fillStyle = tint;
    x.fillRect(0,0,c.width,c.height);
    tintCache.set(key,c);
    if(tintCache.size>32) tintCache.delete(tintCache.keys().next().value);
    return c;
  }

  /* ---------- Transformación de vista ---------- */
  SE.frameToScreen = (x,y)=>{
    const c = Math.cos(SE.view.rot), s = Math.sin(SE.view.rot);
    return {
      x: SE.view.x + SE.view.scale*(x*c - y*s),
      y: SE.view.y + SE.view.scale*(x*s + y*c)
    };
  };
  SE.screenToCanvasExact = (sx,sy)=>{
    const dx = sx - SE.view.x, dy = sy - SE.view.y;
    const c = Math.cos(-SE.view.rot), s = Math.sin(-SE.view.rot);
    return {
      x: (dx*c - dy*s)/SE.view.scale,
      y: (dx*s + dy*c)/SE.view.scale
    };
  };
  SE.screenToPixel = (sx,sy)=>{
    const p = SE.screenToCanvasExact(sx,sy);
    return { x: Math.floor(p.x), y: Math.floor(p.y) };
  };

  SE.applyView = ()=>{
    const d = SE.dom;
    const t = `translate(${SE.view.x}px,${SE.view.y}px) rotate(${SE.view.rot}rad) scale(${SE.view.scale})`;
    d.editor.style.transform = t;
    d.overlay.style.transform = t;
    const deg = (((SE.view.rot*180/Math.PI)%360)+360)%360;
    const z = SE.$('hudZoom');
    if(z) z.textContent = (Math.round(SE.view.scale*100)/100)+'x · '+deg.toFixed(0)+'°';
  };

  SE.fitView = ()=>{
    const p = SE.state.project;
    if(!p) return;
    const d = SE.dom;
    const W = p.frameWidth, H = p.frameHeight;
    const sw = Math.max(40, d.stage.clientWidth-40);
    const sh = Math.max(40, d.stage.clientHeight-40);
    const cc = Math.abs(Math.cos(SE.view.rot));
    const ss = Math.abs(Math.sin(SE.view.rot));
    const bw = W*cc + H*ss;
    const bh = W*ss + H*cc;
    let sc = Math.min(sw/bw, sh/bh);
    sc = sc>=1 ? Math.floor(sc) : Math.round(sc*100)/100;
    SE.view.scale = SE.clamp(sc, 0.25, 64);
    const c = Math.cos(SE.view.rot), s = Math.sin(SE.view.rot);
    const cx = W/2, cy = H/2;
    SE.view.x = d.stage.clientWidth/2 - SE.view.scale*(cx*c - cy*s);
    SE.view.y = d.stage.clientHeight/2 - SE.view.scale*(cx*s + cy*c);
    SE.applyView();
  };

  SE.zoomAt = (sx,sy,factor)=>{
    const cp = SE.screenToCanvasExact(sx,sy);
    const ns = SE.clamp(SE.view.scale*factor, 0.25, 64);
    SE.view.scale = ns;
    const c = Math.cos(SE.view.rot), s = Math.sin(SE.view.rot);
    SE.view.x = sx - ns*(cp.x*c - cp.y*s);
    SE.view.y = sy - ns*(cp.x*s + cp.y*c);
    SE.applyView();
  };

  /* ---------- Tamaño de canvas ---------- */
  function ensureSize(cv, w, h){
    if(cv.width!==w || cv.height!==h){
      cv.width = w; cv.height = h;
      cv.style.width = w+'px';
      cv.style.height = h+'px';
    }
  }
  function ensureOverlaySize(){
    const w = SE.dom.stage.clientWidth;
    const h = SE.dom.stage.clientHeight;
    const ov = SE.dom.overlay;
    if(ov.width!==Math.round(w*DPR) || ov.height!==Math.round(h*DPR)){
      ov.width = Math.round(w*DPR);
      ov.height = Math.round(h*DPR);
      ov.style.width = w+'px';
      ov.style.height = h+'px';
    }
  }

  /* ---------- Render principal ---------- */
  let rafId = null;
  SE.scheduleRender = ()=>{
    if(rafId) return;
    rafId = requestAnimationFrame(()=>{
      rafId = null;
      SE.renderEditor();
      SE.renderOverlay();
      SE.renderPreview();
    });
  };

  SE.renderEditor = ()=>{
    const p = SE.state.project;
    const d = SE.dom;
    if(!p){ ensureSize(d.editor,0,0); return; }
    const W = p.frameWidth, H = p.frameHeight;
    ensureSize(d.editor, W, H);
    const x = d.ectx;
    x.imageSmoothingEnabled = false;
    x.clearRect(0,0,W,H);

    if(SE.state.onion.enabled && !SE.state.playing){
      const o = SE.state.onion;
      for(let k=o.prev;k>=1;k--){
        const i = SE.state.currentFrame - k;
        if(i<0) continue;
        x.globalAlpha = o.opacity/k;
        x.drawImage(tintedFrame(i,'#ff3355'),0,0);
      }
      for(let k=o.next;k>=1;k--){
        const i = SE.state.currentFrame + k;
        if(i>=p.frames.length) continue;
        x.globalAlpha = o.opacity/k;
        x.drawImage(tintedFrame(i,'#33aaff'),0,0);
      }
      x.globalAlpha = 1;
    }
    x.drawImage(SE.getComposite(SE.state.currentFrame),0,0);
  };

  /* ---------- Overlay (cuadrícula, simetría, previsualización de forma) ---------- */
  SE._overlayDraw = null;   // tools.js puede asignar una función de dibujo
  SE.renderOverlay = ()=>{
    const d = SE.dom;
    ensureOverlaySize();
    const x = d.octx;
    x.setTransform(DPR,0,0,DPR,0,0);
    const w = d.stage.clientWidth, h = d.stage.clientHeight;
    x.clearRect(0,0,w,h);
    const p = SE.state.project;
    if(!p) return;
    const W = p.frameWidth, H = p.frameHeight;

    // Cuadrícula
    if(SE.state.grid.show && SE.state.grid.size>0){
      const step = SE.view.scale*SE.state.grid.size;
      if(step>=6){
        x.strokeStyle = 'rgba(255,255,255,0.16)';
        x.lineWidth = 1;
        x.beginPath();
        for(let gx=SE.state.grid.size; gx<W; gx+=SE.state.grid.size){
          const a = SE.frameToScreen(gx,0), b = SE.frameToScreen(gx,H);
          x.moveTo(a.x,a.y); x.lineTo(b.x,b.y);
        }
        for(let gy=SE.state.grid.size; gy<H; gy+=SE.state.grid.size){
          const a = SE.frameToScreen(0,gy), b = SE.frameToScreen(W,gy);
          x.moveTo(a.x,a.y); x.lineTo(b.x,b.y);
        }
        x.stroke();
      }
    }

    // Ejes de simetría
    if(SE.state.symmetry.x){
      const a = SE.frameToScreen(W/2, 0), b = SE.frameToScreen(W/2, H);
      x.strokeStyle = 'rgba(255,80,120,0.55)';
      x.lineWidth = 1;
      x.setLineDash([5,4]);
      x.beginPath(); x.moveTo(a.x,a.y); x.lineTo(b.x,b.y); x.stroke();
      x.setLineDash([]);
    }
    if(SE.state.symmetry.y){
      const a = SE.frameToScreen(0, H/2), b = SE.frameToScreen(W, H/2);
      x.strokeStyle = 'rgba(80,180,255,0.55)';
      x.lineWidth = 1;
      x.setLineDash([5,4]);
      x.beginPath(); x.moveTo(a.x,a.y); x.lineTo(b.x,b.y); x.stroke();
      x.setLineDash([]);
    }

    // Borde del frame
    const c0 = SE.frameToScreen(0,0), c1 = SE.frameToScreen(W,0),
          c2 = SE.frameToScreen(W,H), c3 = SE.frameToScreen(0,H);
    x.strokeStyle = 'rgba(255,255,255,0.35)';
    x.lineWidth = 1;
    x.beginPath();
    x.moveTo(c0.x,c0.y); x.lineTo(c1.x,c1.y);
    x.lineTo(c2.x,c2.y); x.lineTo(c3.x,c3.y); x.closePath();
    x.stroke();

    // Preview de herramienta (línea, rect, elipse)
    if(SE._overlayDraw){
      const saved = { x: x, view: SE.view };
      try { SE._overlayDraw(x); } catch(_){}
    }
  };

  /* ---------- Preview (esquina) ---------- */
  SE.renderPreview = ()=>{
    const p = SE.state.project;
    const pv = SE.dom.preview;
    if(!p){ pv.style.display='none'; return; }
    pv.style.display = 'block';
    const targetW = 90;
    const s = Math.max(1, targetW/p.frameWidth);
    pv.width = p.frameWidth;
    pv.height = p.frameHeight;
    pv.style.width = (p.frameWidth*s)+'px';
    pv.style.height = (p.frameHeight*s)+'px';
    const x = SE.dom.pctx;
    x.imageSmoothingEnabled = false;
    x.clearRect(0,0,pv.width,pv.height);
    x.drawImage(SE.getComposite(SE.state.currentFrame),0,0);
  };

  /* ---------- Thumbnails ---------- */
  SE.thumbScale = 1;
  SE.makeThumb = (idx, scale)=>{
    const p = SE.state.project;
    const w = Math.max(1, Math.round(p.frameWidth*scale));
    const h = Math.max(1, Math.round(p.frameHeight*scale));
    const c = newCanvas(w,h);
    const x = ctx(c);
    x.imageSmoothingEnabled = false;
    x.drawImage(SE.getComposite(idx),0,0,w,h);
    return c;
  };

  /* ---------- Inicializar referencias ---------- */
  SE.initRender = ()=>{
    SE.dom.stage   = SE.$('stage');
    SE.dom.editor  = SE.$('editor');
    SE.dom.ectx    = SE.dom.editor.getContext('2d');
    SE.dom.overlay = SE.$('overlay');
    SE.dom.octx    = SE.dom.overlay.getContext('2d');
    SE.dom.preview = SE.$('preview');
    SE.dom.pctx    = SE.dom.preview.getContext('2d');
    SE.dom.timeline= SE.$('timeline');
  };
})();