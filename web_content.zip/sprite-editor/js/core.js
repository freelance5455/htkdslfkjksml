/* Núcleo: estado, modelo, eventos, historial, colores. */
window.SE = window.SE || {};
(function(){
  const SE = window.SE;

  /* ---------------- Eventos ---------------- */
  const ls = {};
  SE.on   = (e,f)=>{ (ls[e]=ls[e]||[]).push(f); };
  SE.off  = (e,f)=>{ const a=ls[e]; if(a){const i=a.indexOf(f); if(i>=0)a.splice(i,1);} };
  SE.emit = (e,d)=>{ const a=ls[e]; if(a) for(let i=0;i<a.length;i++) a[i](d); };

  /* ---------------- Utilidades ---------------- */
  SE.$ = id => document.getElementById(id);
  SE.newCanvas = (w,h)=>{ const c=document.createElement('canvas'); c.width=w; c.height=h; return c; };
  SE.ctx = c => c.getContext('2d');
  SE.hexToRgb = hex=>{
    let h=(hex||'#000').replace('#','');
    if(h.length===3) h=h.split('').map(x=>x+x).join('');
    if(h.length!==6) return [0,0,0];
    const v=parseInt(h,16)|0;
    return [(v>>16)&255,(v>>8)&255,v&255];
  };
  SE.clamp = (v,a,b)=>v<a?a:v>b?b:v;

  /* ---------------- Modelo ---------------- */
  SE.newLayer = (w,h,name)=>({
    name: name||'Capa',
    visible:true, opacity:1, locked:false, blend:'source-over',
    canvas: SE.newCanvas(w,h)
  });
  SE.newFrame = (w,h,n=1)=>({
    layers: Array.from({length:n},(_,i)=>SE.newLayer(w,h,'Capa '+(i+1)))
  });

  /* ---------------- Estado global ---------------- */
  const DEFAULT_PALETTE = [
    '#000000','#1d2b53','#7e2553','#008751',
    '#ab5236','#5f574f','#c2c3c7','#fff1e8',
    '#ff004d','#ffa300','#ffec27','#00e436',
    '#29adff','#83769c','#ff77a8','#ffccaa'
  ];

  SE.state = {
    project:null,
    currentFrame:0,
    currentLayer:0,
    tool:'pencil',
    color:'#ff3b30',
    colorB:'#000000',
    editSlot:'A',
    brush:{ size:1, opacity:1, antialias:false, pixelPerfect:true },
    shape:{ fill:false, stroke:1 },
    grid:{ show:false, size:8 },
    onion:{ enabled:true, prev:1, next:1, opacity:0.30 },
    symmetry:{ x:false, y:false },
    playing:false, loop:true, pingpong:false, playDir:1,
    playTimer:null,
    palette: DEFAULT_PALETTE.slice(),
    recentColors: [],
  };

  SE.view = { x:0, y:0, scale:8, rot:0 };

  /* ---------------- Accesores ---------------- */
  SE.frame = () => SE.state.project?.frames[SE.state.currentFrame];
  SE.layer = () => SE.frame()?.layers[SE.state.currentLayer];
  SE.frameAt = i => SE.state.project?.frames[i];
  SE.layerAt = (fi,li) => SE.state.project?.frames[fi]?.layers[li];
  SE.frameW  = () => SE.state.project?.frameWidth||0;
  SE.frameH  = () => SE.state.project?.frameHeight||0;

  /* ---------------- Historial ---------------- */
  SE.history = { undo:[], redo:[], limit:120 };

  SE.snapLayer = (fi,li)=>{
    const l = SE.layerAt(fi,li);
    if(!l) return null;
    const c = SE.newCanvas(l.canvas.width,l.canvas.height);
    SE.ctx(c).drawImage(l.canvas,0,0);
    return c;
  };
  SE.commitPixels = (fi,li,before)=>{
    if(!before) return;
    const after = SE.snapLayer(fi,li);
    SE.history.undo.push({type:'px', fi, li, before, after});
    if(SE.history.undo.length>SE.history.limit) SE.history.undo.shift();
    SE.history.redo.length = 0;
    SE.emit('history');
  };
  SE.undo = ()=>{
    const e = SE.history.undo.pop();
    if(!e) return false;
    const l = SE.layerAt(e.fi,e.li);
    if(l && e.type==='px'){
      const c = SE.ctx(l.canvas);
      c.clearRect(0,0,l.canvas.width,l.canvas.height);
      c.drawImage(e.before,0,0);
    }
    SE.history.redo.push(e);
    SE.state.currentFrame = e.fi;
    SE.state.currentLayer = e.li;
    SE.emit('composite', e.fi);
    SE.emit('history');
    return true;
  };
  SE.redo = ()=>{
    const e = SE.history.redo.pop();
    if(!e) return false;
    const l = SE.layerAt(e.fi,e.li);
    if(l && e.type==='px'){
      const c = SE.ctx(l.canvas);
      c.clearRect(0,0,l.canvas.width,l.canvas.height);
      c.drawImage(e.after,0,0);
    }
    SE.history.undo.push(e);
    SE.state.currentFrame = e.fi;
    SE.state.currentLayer = e.li;
    SE.emit('composite', e.fi);
    SE.emit('history');
    return true;
  };
  SE.clearHistory = ()=>{ SE.history.undo.length=0; SE.history.redo.length=0; SE.emit('history'); };

  /* ---------------- Color ---------------- */
  SE.setColor = (hex, slot)=>{
    if(slot==='B' || slot==='a' || slot==='A' && false){} // placeholder
    slot = slot || SE.state.editSlot || 'A';
    if(slot==='B') SE.state.colorB = hex;
    else {
      SE.state.color = hex;
      const r = SE.state.recentColors;
      const i = r.indexOf(hex);
      if(i>=0) r.splice(i,1);
      r.unshift(hex);
      if(r.length>16) r.pop();
    }
    SE.emit('color');
  };
  SE.activeColor = ()=> SE.state.editSlot==='B' ? SE.state.colorB : SE.state.color;
  SE.swapColors = ()=>{
    const a=SE.state.color;
    SE.state.color = SE.state.colorB;
    SE.state.colorB = a;
    SE.emit('color');
  };

  /* ---------------- Toques hápticos ---------------- */
  SE.haptic = (ms=10)=>{
    if(navigator.vibrate && !SE.state._hapticsOff){
      try{ navigator.vibrate(ms); }catch(_){}
    }
  };
})();