/* Importar, exportar, guardar/cargar proyecto, nuevo proyecto. */
(function(){
  const SE = window.SE;
  const st = SE.state;

  /* ---------------- Nuevo proyecto ---------------- */
  SE.newProject = (w,h,nLayers)=>{
    st.project = {
      frameWidth: w, frameHeight: h, fps: 12,
      frames: [ SE.newFrame(w,h,nLayers) ]
    };
    st.currentFrame = 0; st.currentLayer = 0;
    SE.clearHistory(); SE.invalidate();
    SE.view.rot = 0;
    SE.$('hint').style.display = 'none';
    SE.renderTimeline(true);
    SE.renderLayerList();
    SE.updateFrameInfo();
    SE.syncToolbar();
    SE.scheduleRender();
    requestAnimationFrame(()=> SE.fitView());
    SE.emit('toast', `Proyecto ${w}×${h}`);
  };

  /* ---------------- Importar PNG ---------------- */
  SE.pendingImage = null;

  SE.askFrameSize = (img)=>{
    SE.pendingImage = img;
    SE.$('importInfo').textContent = `Imagen: ${img.width}×${img.height}px.`;
    SE.$('impW').value = Math.min(img.width, 32);
    SE.$('impH').value = Math.min(img.height, 32);
    SE.syncImportFromPixels();
    SE.$('modal').classList.remove('hidden');
  };

  SE.syncImportFromPixels = ()=>{
    const img = SE.pendingImage; if(!img) return;
    const fw = +SE.$('impW').value||0, fh = +SE.$('impH').value||0;
    if(fw<1 || fh<1){ SE.renderImportPreview(); return; }
    SE.$('impCols').value = Math.max(1, Math.floor(img.width/fw));
    SE.$('impRows').value = Math.max(1, Math.floor(img.height/fh));
    SE.renderImportPreview();
  };
  SE.syncImportFromFrames = ()=>{
    const img = SE.pendingImage; if(!img) return;
    const c = +SE.$('impCols').value||0, r = +SE.$('impRows').value||0;
    if(c<1 || r<1){ SE.renderImportPreview(); return; }
    SE.$('impW').value = Math.max(1, Math.floor(img.width/c));
    SE.$('impH').value = Math.max(1, Math.floor(img.height/r));
    SE.renderImportPreview();
  };
  SE.renderImportPreview = ()=>{
    const img = SE.pendingImage; if(!img) return;
    const fw = +SE.$('impW').value||0, fh = +SE.$('impH').value||0;
    const cols = +SE.$('impCols').value||0, rows = +SE.$('impRows').value||0;
    const el = SE.$('importPreview');
    if(fw<1||fh<1||cols<1||rows<1){ el.innerHTML = '<span style="color:#ff9500">Define valores válidos</span>'; return; }
    if(fw>img.width || fh>img.height){ el.innerHTML = '<span style="color:#ff453a">Frame más grande que la imagen</span>'; return; }
    const total = cols*rows;
    const sx = img.width - cols*fw, sy = img.height - rows*fh;
    let txt = `<b>${total}</b> cuadros de <b>${fw}×${fh}px</b><br>${cols} col × ${rows} fila${rows>1?'s':''}`;
    if(sx>0 || sy>0){
      const arr=[];
      if(sx>0) arr.push(`${sx}px derecha`);
      if(sy>0) arr.push(`${sy}px abajo`);
      txt += `<br><span style="color:#ff9500">⚠ Sobran ${arr.join(' y ')}</span>`;
    } else {
      txt += `<br><span style="color:#34c759">✓ Corte exacto</span>`;
    }
    el.innerHTML = txt;
  };

  SE.confirmImport = ()=>{
    const img = SE.pendingImage; if(!img) return;
    const fw = +SE.$('impW').value, fh = +SE.$('impH').value;
    if(!fw || !fh || fw<1 || fh<1) return;
    const cols = Math.floor(img.width/fw);
    const rows = Math.floor(img.height/fh);
    if(cols*rows===0){ alert('Frame más grande que la imagen.'); return; }

    const src = SE.newCanvas(img.width, img.height);
    SE.ctx(src).drawImage(img,0,0);
    const frames = [];
    for(let r=0;r<rows;r++){
      for(let c=0;c<cols;c++){
        const fc = SE.newCanvas(fw,fh);
        const x = SE.ctx(fc);
        x.imageSmoothingEnabled = false;
        x.drawImage(src, c*fw, r*fh, fw, fh, 0, 0, fw, fh);
        frames.push({ layers:[{ name:'Base', visible:true, opacity:1, locked:false, blend:'source-over', canvas:fc }] });
      }
    }

    st.project = { frameWidth:fw, frameHeight:fh, fps:12, frames };
    st.currentFrame = 0; st.currentLayer = 0;
    SE.clearHistory(); SE.invalidate();
    SE.view.rot = 0;
    SE.$('hint').style.display = 'none';
    SE.renderTimeline(true); SE.renderLayerList(); SE.updateFrameInfo(); SE.syncToolbar();
    SE.scheduleRender();
    requestAnimationFrame(()=> SE.fitView());
    SE.emit('toast', `${frames.length} frames importados`);
    SE.$('modal').classList.add('hidden');
    SE.pendingImage = null;
  };

  /* ---------------- Exportar ---------------- */
  SE.exportSheet = ()=>{
    if(!st.project) return;
    SE.$('expCols').value = 1;
    SE.$('expScale').value = 1;
    SE.updateExportPreview();
    SE.$('exportModal').classList.remove('hidden');
  };
  SE.updateExportPreview = ()=>{
    const p = st.project; if(!p) return;
    const cols = Math.max(1, +SE.$('expCols').value||1);
    const scale = SE.clamp(+SE.$('expScale').value||1, 1, 16);
    const total = p.frames.length;
    const rows = Math.ceil(total/cols);
    const cells = cols*rows;
    const vacios = cells-total;
    const w = p.frameWidth*cols*scale;
    const h = p.frameHeight*rows*scale;
    SE.$('exportInfo').textContent = `${total} frames de ${p.frameWidth}×${p.frameHeight}px`;
    let txt = `${cols} col × ${rows} fila${rows>1?'s':''} = <b>${cells} cuadros</b>`;
    if(vacios>0) txt += ` <span style="color:#ff9500">(${vacios} vacío${vacios>1?'s':''})</span>`;
    txt += `<br>Imagen final: <b>${w}×${h}px</b>`;
    SE.$('exportPreview').innerHTML = txt;
  };
  SE.doExport = ()=>{
    const p = st.project; if(!p) return;
    const cols = Math.max(1, +SE.$('expCols').value||1);
    const scale = SE.clamp(+SE.$('expScale').value||1, 1, 16);
    const rows = Math.ceil(p.frames.length/cols);
    const fw = p.frameWidth*scale, fh = p.frameHeight*scale;
    const out = SE.newCanvas(p.frameWidth*cols*scale, p.frameHeight*rows*scale);
    const x = SE.ctx(out);
    x.imageSmoothingEnabled = false;
    p.frames.forEach((_,i)=>{
      const col = i%cols, row = Math.floor(i/cols);
      x.drawImage(SE.getComposite(i), col*fw, row*fh, fw, fh);
    });
    out.toBlob((blob)=>{
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'spritesheet.png';
      document.body.appendChild(a); a.click();
      setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 2000);
      SE.$('status').textContent = 'Exportado';
      SE.emit('toast','PNG exportado');
    }, 'image/png');
    SE.$('exportModal').classList.add('hidden');
  };

  /* ---------------- Proyecto JSON ---------------- */
  SE.saveProject = ()=>{
    const p = st.project; if(!p) return;
    SE.$('status').textContent = 'Guardando...';
    const data = {
      v: 3,
      frameWidth: p.frameWidth, frameHeight: p.frameHeight, fps: p.fps,
      symmetry: st.symmetry, grid: st.grid, onion: st.onion,
      palette: st.palette,
      frames: p.frames.map(f=>({
        layers: f.layers.map(l=>({
          name: l.name, visible: l.visible, opacity: l.opacity,
          locked: l.locked, blend: l.blend,
          dataURL: l.canvas.toDataURL('image/png')
        }))
      }))
    };
    const blob = new Blob([JSON.stringify(data)], { type:'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'proyecto.spriteproj.json';
    document.body.appendChild(a); a.click();
    setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    SE.$('status').textContent = 'Guardado';
    SE.emit('toast','Proyecto guardado');
  };

  SE.loadProjectFile = (file)=>{
    SE.$('status').textContent = 'Cargando...';
    const reader = new FileReader();
    reader.onload = async ()=>{
      try{
        const data = JSON.parse(reader.result);
        const frames = [];
        for(const f of data.frames){
          const layers = [];
          for(const l of f.layers){
            const layer = await new Promise((res, rej)=>{
              const img = new Image();
              img.onload = ()=>{
                const c = SE.newCanvas(data.frameWidth, data.frameHeight);
                const x = SE.ctx(c);
                x.imageSmoothingEnabled = false;
                x.drawImage(img,0,0);
                res({ name:l.name, visible:l.visible, opacity:l.opacity,
                      locked:!!l.locked, blend:l.blend||'source-over', canvas:c });
              };
              img.onerror = rej;
              img.src = l.dataURL;
            });
            layers.push(layer);
          }
          frames.push({ layers });
        }
        st.project = {
          frameWidth: data.frameWidth, frameHeight: data.frameHeight,
          fps: data.fps || 12, frames
        };
        if(data.symmetry) Object.assign(st.symmetry, data.symmetry);
        if(data.grid)     Object.assign(st.grid, data.grid);
        if(data.onion)    Object.assign(st.onion, data.onion);
        if(Array.isArray(data.palette)) st.palette = data.palette;
        st.currentFrame = 0; st.currentLayer = 0;
        SE.clearHistory(); SE.invalidate();
        SE.view.rot = 0;
        SE.$('hint').style.display = 'none';
        SE.renderTimeline(true); SE.renderLayerList(); SE.updateFrameInfo();
        SE.syncToolbar(); SE.syncMenuControls();
        SE.scheduleRender();
        requestAnimationFrame(()=> SE.fitView());
        SE.$('status').textContent = 'Cargado';
        SE.emit('toast','Proyecto cargado');
      } catch(err){
        alert('Error: '+err.message);
        SE.$('status').textContent = '';
      }
    };
    reader.readAsText(file);
  };

  /* ---------------- Wire inputs de archivo ---------------- */
  SE.wireFileInputs = ()=>{
    SE.$('fileInput').onchange = (e)=>{
      const file = e.target.files[0]; if(!file) return;
      const img = new Image();
      img.onload = ()=>{ SE.askFrameSize(img); URL.revokeObjectURL(img.src); };
      img.src = URL.createObjectURL(file);
      e.target.value = '';
    };
    SE.$('projInput').onchange = (e)=>{
      const file = e.target.files[0]; if(!file) return;
      SE.loadProjectFile(file);
      e.target.value = '';
    };
  };
})();