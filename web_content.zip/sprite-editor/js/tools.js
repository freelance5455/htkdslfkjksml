/* Herramientas de dibujo: lápiz, borrador, relleno, cuentagotas,
   línea, rectángulo, elipse, mover vista. */
(function(){
  const SE = window.SE;
  const st = SE.state;

  /* -------- utilidades de pixel -------- */
  const inB = (x,y)=> x>=0 && y>=0 && x<SE.frameW() && y<SE.frameH();

  function pixelLine(x0,y0,x1,y1, cb){
    // Bresenham
    x0|=0; y0|=0; x1|=0; y1|=0;
    const dx = Math.abs(x1-x0), sx = x0<x1?1:-1;
    const dy = -Math.abs(y1-y0), sy = y0<y1?1:-1;
    let err = dx+dy;
    for(;;){
      cb(x0,y0);
      if(x0===x1 && y0===y1) break;
      const e2 = 2*err;
      if(e2>=dy){ err+=dy; x0+=sx; }
      if(e2<=dx){ err+=dx; y0+=sy; }
    }
  }

  /* -------- pincel: pinta un pixel con simetría -------- */
  function paintPoint(layer, px, py, color, erasing){
    const x = SE.ctx(layer.canvas);
    const s = st.brush.size;
    const a = erasing ? 1 : st.brush.opacity;
    if(erasing){
      x.globalCompositeOperation = 'destination-out';
      x.fillStyle = '#000';
    } else {
      x.globalCompositeOperation = 'source-over';
      x.fillStyle = color;
    }
    x.globalAlpha = a;

    const drawDot = (cx,cy)=>{
      if(st.brush.antialias && s>1){
        x.beginPath();
        x.arc(cx+0.5,cy+0.5,s/2,0,Math.PI*2);
        x.fill();
      } else {
        const off = (s-1)>>1;
        x.fillRect(cx-off, cy-off, s, s);
      }
    };

    const W = SE.frameW(), H = SE.frameH();
    drawDot(px,py);
    if(st.symmetry.x) drawDot(W-1-px, py);
    if(st.symmetry.y) drawDot(px, H-1-py);
    if(st.symmetry.x && st.symmetry.y) drawDot(W-1-px, H-1-py);

    x.globalAlpha = 1;
    x.globalCompositeOperation = 'source-over';
  }

  /* -------- pixel-perfect sobre un conjunto de puntos -------- */
  function pixelPerfectFilter(pts){
    if(!st.brush.pixelPerfect || pts.length<3) return pts;
    const out = [];
    for(let i=0;i<pts.length;i++){
      const p = pts[i];
      if(i>0 && i<pts.length-1){
        const a = pts[i-1], b = pts[i+1];
        // p es esquina si a y b son adyacentes en ejes distintos a p
        const cornerH = (a.x===p.x && b.y===p.y) || (b.x===p.x && a.y===p.y);
        if(cornerH && Math.abs(a.x-p.x)+Math.abs(a.y-p.y)===1 && Math.abs(b.x-p.x)+Math.abs(b.y-p.y)===1){
          continue; // descarta la esquina
        }
      }
      out.push(p);
    }
    return out;
  }

  /* -------- flood fill -------- */
  function floodFill(layer, px, py, color, opacity){
    const W = SE.frameW(), H = SE.frameH();
    if(px<0||py<0||px>=W||py>=H) return false;
    const x = SE.ctx(layer.canvas);
    const img = x.getImageData(0,0,W,H);
    const d = img.data;
    const i0 = (py*W+px)*4;
    const t0=d[i0], t1=d[i0+1], t2=d[i0+2], t3=d[i0+3];
    const [fr,fg,fb] = SE.hexToRgb(color);
    const fa = Math.round(SE.clamp(opacity,0,1)*255);
    if(t0===fr && t1===fg && t2===fb && t3===fa) return false;

    // BFS con Uint32 para comparar rápido
    const target = (t0<<24>>>0) | (t1<<16) | (t2<<8) | t3;
    // Nota: usamos un test explícito para robustez
    const stack = new Int32Array(W*H*2);
    let sp = 0;
    stack[sp++] = px; stack[sp++] = py;
    const seen = new Uint8Array(W*H);
    let changed = false;
    while(sp>0){
      const y = stack[--sp], xx = stack[--sp];
      if(xx<0||y<0||xx>=W||y>=H) continue;
      const idx = y*W+xx;
      if(seen[idx]) continue;
      seen[idx] = 1;
      const i = idx*4;
      if(d[i]!==t0 || d[i+1]!==t1 || d[i+2]!==t2 || d[i+3]!==t3) continue;
      d[i]=fr; d[i+1]=fg; d[i+2]=fb; d[i+3]=fa;
      changed = true;
      stack[sp++] = xx+1; stack[sp++] = y;
      stack[sp++] = xx-1; stack[sp++] = y;
      stack[sp++] = xx;   stack[sp++] = y+1;
      stack[sp++] = xx;   stack[sp++] = y-1;
    }
    if(changed) x.putImageData(img,0,0);
    return changed;
  }

  /* -------- herramientas -------- */
  const tools = {};

  function beginLayerEdit(){
    const fi = st.currentFrame, li = st.currentLayer;
    return { fi, li, before: SE.snapLayer(fi, li) };
  }
  function commitLayerEdit(ctxInfo){
    if(!ctxInfo) return;
    SE.commitPixels(ctxInfo.fi, ctxInfo.li, ctxInfo.before);
    SE.invalidate(ctxInfo.fi);
    SE.emit('composite', ctxInfo.fi);
  }

  /* --- Pincel / Borrador (base compartida) --- */
  function makePaintTool(kind){
    let info=null, last=null, strokePts=[];
    return {
      start(pt){
        const layer = SE.layer();
        if(!layer || !layer.visible || layer.locked) return false;
        info = beginLayerEdit();
        last = { x:pt.x, y:pt.y };
        strokePts = [last];
        paintPoint(layer, pt.x, pt.y, SE.activeColor(), kind==='eraser');
        SE.invalidate(st.currentFrame);
        SE.emit('composite', st.currentFrame);
        return true;
      },
      move(pt){
        if(!info) return;
        const layer = SE.layer();
        if(!layer) return;
        const pixels = [];
        pixelLine(last.x, last.y, pt.x, pt.y, (px,py)=>pixels.push({x:px,y:py}));
        // filtrar el primero (ya pintado)
        const filtered = pixelPerfectFilter(pixels);
        for(const p of filtered) paintPoint(layer, p.x, p.y, SE.activeColor(), kind==='eraser');
        last = { x:pt.x, y:pt.y };
        SE.invalidate(st.currentFrame);
        SE.emit('composite', st.currentFrame);
      },
      end(){
        if(!info) return;
        commitLayerEdit(info);
        info = null; last = null; strokePts = [];
      },
      cancel(){
        if(!info) return;
        const l = SE.layerAt(info.fi, info.li);
        if(l){
          const x = SE.ctx(l.canvas);
          x.clearRect(0,0,l.canvas.width,l.canvas.height);
          x.drawImage(info.before,0,0);
        }
        SE.invalidate(info.fi);
        SE.emit('composite', info.fi);
        info = null;
      }
    };
  }

  tools.pencil = makePaintTool('pencil');
  tools.eraser = makePaintTool('eraser');

  /* --- Cuentagotas --- */
  tools.picker = {
    start(pt){
      if(!inB(pt.x,pt.y)) return false;
      const comp = SE.getComposite(st.currentFrame);
      const d = SE.ctx(comp).getImageData(pt.x,pt.y,1,1).data;
      if(d[3]===0){ SE.emit('toast','Transparente'); return true; }
      const hex = '#'+[d[0],d[1],d[2]].map(v=>v.toString(16).padStart(2,'0')).join('');
      SE.setColor(hex, st.editSlot);
      SE.emit('toast','Color '+hex);
      return true;
    },
    move(){}, end(){}, cancel(){}
  };

  /* --- Relleno --- */
  tools.bucket = {
    start(pt){
      const layer = SE.layer();
      if(!layer || !layer.visible || layer.locked) return false;
      const info = beginLayerEdit();
      const changed = floodFill(layer, pt.x, pt.y, SE.activeColor(), st.brush.opacity);
      SE.invalidate(st.currentFrame);
      SE.emit('composite', st.currentFrame);
      if(changed){
        SE.commitPixels(info.fi, info.li, info.before);
        SE.invalidate(info.fi);
        SE.emit('composite', info.fi);
      }
      return true;
    },
    move(){}, end(){}, cancel(){}
  };

  /* --- Mover vista --- */
  tools.pan = {
    start(pt){ this.sx = pt.sx; this.sy = pt.sy; this.vx = SE.view.x; this.vy = SE.view.y; return true; },
    move(pt){
      SE.view.x = this.vx + (pt.sx - this.sx);
      SE.view.y = this.vy + (pt.sy - this.sy);
      SE.applyView();
    },
    end(){}, cancel(){}
  };

  /* --- Formas: línea, rect, elipse --- */
  function makeShape(kind){
    let info=null, start=null, end=null;
    function drawStroke(x, x0,y0,x1,y1){
      const stroke = Math.max(1, st.shape.stroke|0);
      const color = SE.activeColor();
      const fill = st.shape.fill;
      const W = SE.frameW(), H = SE.frameH();

      const paint = (draw)=>{
        if(st.symmetry.x){
          draw(x0, y0, W-1-x1, y1);
          if(st.symmetry.y) draw(x0, H-1-y0, W-1-x1, H-1-y1);
        }
        if(st.symmetry.y) draw(x0, H-1-y0, x1, H-1-y1);
        draw(x0,y0,x1,y1);
      };

      x.save();
      x.imageSmoothingEnabled = false;
      x.globalAlpha = st.brush.opacity;
      x.strokeStyle = color;
      x.fillStyle = color;
      x.lineWidth = stroke;
      x.lineCap = 'butt';
      x.lineJoin = 'miter';

      const drawReal = (ax,ay,bx,by)=>{
        if(kind==='line'){
          if(st.brush.antialias){
            x.beginPath(); x.moveTo(ax+0.5,ay+0.5); x.lineTo(bx+0.5,by+0.5); x.stroke();
          } else {
            // pixel-perfect: rectángulos de tamaño brush
            const s = Math.max(1, stroke);
            const off = (s-1)>>1;
            pixelLine(ax,ay,bx,by,(px,py)=>{
              x.fillRect(px-off, py-off, s, s);
            });
          }
        } else if(kind==='rect'){
          const rx = Math.min(ax,bx), ry = Math.min(ay,by);
          const rw = Math.abs(bx-ax)+1, rh = Math.abs(by-ay)+1;
          if(fill) x.fillRect(rx,ry,rw,rh);
          if(stroke>0){
            if(!st.brush.antialias){
              for(let i=0;i<stroke;i++){
                x.strokeRect(rx-0.5+i, ry-0.5+i, rw-2*i+1, rh-2*i+1);
              }
            } else {
              x.strokeRect(rx+0.5, ry+0.5, rw-1, rh-1);
            }
          }
        } else if(kind==='ellipse'){
          const cx = (ax+bx)/2, cy = (ay+by)/2;
          const rw = Math.abs(bx-ax)/2, rh = Math.abs(by-ay)/2;
          x.beginPath();
          x.ellipse(cx+0.5, cy+0.5, rw, rh, 0, 0, Math.PI*2);
          if(fill) x.fill();
          if(stroke>0) x.stroke();
        }
      };

      paint(drawReal);
      x.restore();
    }

    return {
      start(pt){
        const layer = SE.layer();
        if(!layer || !layer.visible || layer.locked) return false;
        info = beginLayerEdit();
        start = { x:pt.x, y:pt.y };
        end = { x:pt.x, y:pt.y };
        SE._overlayDraw = (x)=>{
          // previsualización: pinta directamente en overlay con transformación pantalla
          const W = SE.frameW(), H = SE.frameH();
          x.save();
          // El overlay NO está transformado como el editor; hay que dibujar con frameToScreen
          // Para simplificar, pintamos en coords de pantalla usando transformaciones.
          // Truco: usar setTransform global
          x.setTransform(1,0,0,1,0,0);
          // Convertimos cada punto con frameToScreen y dibujamos
          const scale = SE.view.scale;
          const rot = SE.view.rot;
          const c = Math.cos(rot), s = Math.sin(rot);
          const f2s = (px,py)=>({
            x: SE.view.x + scale*(px*c - py*s),
            y: SE.view.y + scale*(px*s + py*c)
          });
          const a = f2s(start.x+0.5, start.y+0.5);
          const b = f2s(end.x+0.5, end.y+0.5);
          x.strokeStyle = SE.activeColor();
          x.globalAlpha = Math.max(0.4, st.brush.opacity);
          x.lineWidth = Math.max(1, st.shape.stroke * scale * 0.6);
          if(kind==='line'){
            x.beginPath(); x.moveTo(a.x,a.y); x.lineTo(b.x,b.y); x.stroke();
          } else if(kind==='rect'){
            const rx = Math.min(a.x,b.x), ry = Math.min(a.y,b.y);
            const rw = Math.abs(b.x-a.x), rh = Math.abs(b.y-a.y);
            if(st.shape.fill){ x.fillStyle = SE.activeColor(); x.fillRect(rx,ry,rw,rh); }
            x.strokeRect(rx,ry,rw,rh);
          } else if(kind==='ellipse'){
            const cx=(a.x+b.x)/2, cy=(a.y+b.y)/2;
            const rw=Math.abs(b.x-a.x)/2, rh=Math.abs(b.y-a.y)/2;
            x.beginPath(); x.ellipse(cx,cy,rw,rh,0,0,Math.PI*2);
            if(st.shape.fill){ x.fillStyle = SE.activeColor(); x.fill(); }
            x.stroke();
          }
          x.restore();
        };
        SE.scheduleRender();
        return true;
      },
      move(pt){
        if(!info) return;
        end = { x:pt.x, y:pt.y };
        SE.renderOverlay();
      },
      end(){
        if(!info) return;
        const layer = SE.layerAt(info.fi, info.li);
        if(layer){
          const x = SE.ctx(layer.canvas);
          x.imageSmoothingEnabled = false;
          drawStroke(x, start.x, start.y, end.x, end.y);
        }
        SE._overlayDraw = null;
        commitLayerEdit(info);
        info = null; start = null; end = null;
        SE.renderOverlay();
      },
      cancel(){
        if(!info) return;
        const l = SE.layerAt(info.fi, info.li);
        if(l){
          const x = SE.ctx(l.canvas);
          x.clearRect(0,0,l.canvas.width,l.canvas.height);
          x.drawImage(info.before,0,0);
        }
        SE._overlayDraw = null;
        SE.invalidate(info.fi);
        SE.emit('composite', info.fi);
        info = null; start = null; end = null;
        SE.renderOverlay();
      }
    };
  }

  tools.line    = makeShape('line');
  tools.rect    = makeShape('rect');
  tools.ellipse = makeShape('ellipse');

  /* --- registro --- */
  SE.toolRegistry = tools;
  SE.getCurrentTool = ()=> tools[st.tool] || tools.pencil;
  SE.TOOL_ICONS = { pencil:'✏️', eraser:'🧽', bucket:'🪣', picker:'💧', pan:'✋', line:'📏', rect:'▭', ellipse:'◯' };
  SE.TOOL_NAMES = { pencil:'Lápiz', eraser:'Borrador', bucket:'Relleno', picker:'Cuentagotas', pan:'Mover', line:'Línea', rect:'Rectángulo', ellipse:'Elipse' };
  SE.TOOL_ORDER = ['pencil','eraser','bucket','picker','line','rect','ellipse','pan'];
})();