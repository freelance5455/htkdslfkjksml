import type { Difficulty, QuestionOption, QuestionType } from './types';

/**
 * Seed question bank.
 *
 * These are original practice questions written for this app. They are NOT
 * previous-year questions, so every one carries `verified: false` and the UI
 * labels them "EduMentor practice". Only questions a student imports/marks as
 * verified previous-year are shown with that badge.
 */

export interface SeedQuestion {
  subject: string;
  chapter: string;
  topic: string;
  type: QuestionType;
  difficulty: Difficulty;
  prompt: string;
  options: QuestionOption[] | null;
  correct: string[];
  numericAnswer: string | null;
  marks: number;
  negative: number;
  solution: string;
}

const opts = (texts: string[]): QuestionOption[] =>
  texts.map((text, i) => ({ key: String.fromCharCode(65 + i), text }));

function mcq(
  subject: string,
  chapter: string,
  difficulty: Difficulty,
  prompt: string,
  choices: string[],
  answer: string,
  solution: string,
  topic = chapter,
): SeedQuestion {
  return {
    subject, chapter, topic, type: 'mcq', difficulty, prompt,
    options: opts(choices), correct: [answer], numericAnswer: null,
    marks: 1, negative: 0, solution,
  };
}

function numeric(
  subject: string,
  chapter: string,
  difficulty: Difficulty,
  prompt: string,
  answer: string,
  solution: string,
  type: QuestionType = 'numerical',
): SeedQuestion {
  return {
    subject, chapter, topic: chapter, type, difficulty, prompt,
    options: null, correct: [answer], numericAnswer: answer,
    marks: 1, negative: 0, solution,
  };
}

function descriptive(
  subject: string,
  chapter: string,
  difficulty: Difficulty,
  type: QuestionType,
  prompt: string,
  solution: string,
  marks: number,
): SeedQuestion {
  return {
    subject, chapter, topic: chapter, type, difficulty, prompt,
    options: null, correct: [], numericAnswer: null,
    marks, negative: 0, solution,
  };
}

export const SEED_QUESTIONS: SeedQuestion[] = [
  // ---------------- Mathematics ----------------
  mcq('Mathematics', 'Real Numbers', 'easy', 'The HCF of 96 and 404 is:', ['4', '8', '12', '2'], 'A',
    '404 = 2² × 101 and 96 = 2⁵ × 3. The only common prime factor is 2, and the highest common power is 2² = 4.'),
  mcq('Mathematics', 'Polynomials', 'medium', 'If α and β are the zeroes of x² − 5x + 6, then α² + β² equals:', ['13', '25', '11', '12'], 'A',
    'α + β = 5 and αβ = 6. So α² + β² = (α + β)² − 2αβ = 25 − 12 = 13.'),
  mcq('Mathematics', 'Arithmetic Progressions', 'easy', 'The sum of the first 20 terms of the AP 3, 7, 11, … is:', ['820', '800', '840', '860'], 'A',
    'a = 3, d = 4, n = 20. Sₙ = n/2 [2a + (n−1)d] = 10 [6 + 76] = 820.'),
  mcq('Mathematics', 'Probability', 'easy', 'A fair die is rolled once. The probability of getting a prime number is:', ['1/2', '1/3', '2/3', '1/6'], 'A',
    'Primes on a die are 2, 3 and 5 — three outcomes out of six, so the probability is 3/6 = 1/2.'),
  numeric('Mathematics', 'Coordinate Geometry', 'easy', 'The distance of the point (3, 4) from the origin is (in units):', '5',
    '√(3² + 4²) = √25 = 5 units.'),
  mcq('Mathematics', 'Introduction to Trigonometry', 'easy', 'The value of sin 30° + cos 60° is:', ['1', '1/2', '√3/2', '0'], 'A',
    'sin 30° = 1/2 and cos 60° = 1/2, so the sum is 1.'),
  mcq('Mathematics', 'Pair of Linear Equations in Two Variables', 'medium',
    'If 2x + 3y = 11 and 2x − 4y = −24, then x + y equals:', ['3', '1', '5', '−1'], 'A',
    'Subtracting gives 7y = 35, so y = 5. Then 2x + 15 = 11 gives x = −2. Hence x + y = 3.'),
  mcq('Mathematics', 'Quadratic Equations', 'medium', 'The quadratic equation 2x² − 4x + 3 = 0 has:', ['no real roots', 'two distinct real roots', 'two equal real roots', 'exactly one real root'], 'A',
    'Discriminant D = b² − 4ac = 16 − 24 = −8 < 0, so there are no real roots.'),
  numeric('Mathematics', 'Surface Areas and Volumes', 'medium', 'The volume of a sphere of radius 7 cm is closest to (in cm³, use π = 22/7):', '1437',
    'V = (4/3)πr³ = (4/3)(22/7)(343) ≈ 1437.33 cm³.'),
  mcq('Mathematics', 'Areas Related to Circles', 'medium', 'The area of a sector of a circle of radius 7 cm with central angle 90° is:', ['38.5 cm²', '77 cm²', '154 cm²', '19.25 cm²'], 'A',
    'Area = (θ/360)πr² = (90/360)(22/7)(49) = 38.5 cm².'),
  mcq('Mathematics', 'Statistics', 'medium', 'The mode of the data 4, 6, 4, 7, 9, 4, 6 is:', ['4', '6', '7', '9'], 'A',
    '4 occurs three times, more than any other value, so the mode is 4.'),
  mcq('Mathematics', 'Triangles', 'medium', 'Two triangles are similar and their corresponding sides are in the ratio 2 : 3. The ratio of their areas is:', ['4 : 9', '2 : 3', '3 : 2', '8 : 27'], 'A',
    'For similar triangles the ratio of areas equals the square of the ratio of corresponding sides: (2/3)² = 4/9.'),

  // ---------------- Class 10 Science ----------------
  mcq('Science', 'Acids, Bases and Salts', 'easy', 'The pH of a neutral solution at 25 °C is:', ['7', '0', '14', '1'], 'A',
    'At 25 °C a neutral solution has [H⁺] = 10⁻⁷ M, so pH = 7.'),
  mcq('Science', 'Metals and Non-metals', 'easy', 'Which gas is evolved when zinc granules react with dilute hydrochloric acid?', ['Hydrogen', 'Oxygen', 'Carbon dioxide', 'Chlorine'], 'A',
    'Zn + 2HCl → ZnCl₂ + H₂. The gas evolved is hydrogen, which burns with a pop sound.'),
  mcq('Science', 'Chemical Reactions and Equations', 'easy', 'Which of the following is an amphoteric oxide?', ['Al₂O₃', 'Na₂O', 'CO₂', 'MgO'], 'A',
    'Al₂O₃ reacts with both acids and bases, so it is amphoteric. Na₂O and MgO are basic, CO₂ is acidic.'),
  mcq('Science', 'Electricity', 'medium', 'Two resistors of 2 Ω and 3 Ω are connected in parallel. Their equivalent resistance is:', ['1.2 Ω', '5 Ω', '0.83 Ω', '6 Ω'], 'A',
    '1/R = 1/2 + 1/3 = 5/6, so R = 6/5 = 1.2 Ω.'),
  numeric('Science', 'Electricity', 'medium', 'An electric bulb draws 0.5 A at 220 V. Its power in watts is:', '110',
    'P = VI = 220 × 0.5 = 110 W.'),
  mcq('Science', 'Light — Reflection and Refraction', 'easy', 'The focal length of a plane mirror is:', ['infinite', 'zero', 'equal to its radius', 'negative'], 'A',
    'A plane mirror has an infinite radius of curvature, so its focal length is infinite.'),
  mcq('Science', 'The Human Eye and the Colourful World', 'medium', 'The power of a convex lens of focal length 50 cm is:', ['+2 D', '−2 D', '+0.5 D', '+50 D'], 'A',
    'P = 1/f (in metres) = 1/0.5 = +2 dioptre.'),
  mcq('Science', 'Life Processes', 'medium', 'Which vitamin is essential for blood clotting?', ['Vitamin K', 'Vitamin C', 'Vitamin A', 'Vitamin D'], 'A',
    'Vitamin K is required for the synthesis of prothrombin and other clotting factors in the liver.'),
  mcq('Science', 'Heredity and Evolution', 'easy', 'The number of chromosomes in a human gamete is:', ['23', '46', '22', '44'], 'A',
    'Human body cells are diploid with 46 chromosomes; gametes are haploid with 23.'),
  mcq('Science', 'Carbon and its Compounds', 'medium', 'Ethanol has a much higher boiling point than dimethyl ether because:', ['ethanol forms intermolecular hydrogen bonds', 'ethanol has a higher molecular mass only', 'dimethyl ether is ionic', 'ethanol is more volatile'], 'A',
    'The −OH group of ethanol allows intermolecular hydrogen bonding, which dimethyl ether cannot form, raising its boiling point.'),
  mcq('Science', 'Magnetic Effects of Electric Current', 'medium', 'The magnetic field at the centre of a circular coil of radius r carrying current I is:', ['μ₀I/2r', 'μ₀I/4πr', 'μ₀I/r', 'μ₀I·r'], 'A',
    'For a circular loop, B = μ₀I/2r at the centre, directed along the axis.'),

  // ---------------- Physics ----------------
  mcq('Physics', 'Electric Charges and Fields', 'easy', 'The SI unit of electric flux is:', ['N m² C⁻¹', 'N C⁻¹', 'C m⁻²', 'V m⁻¹'], 'A',
    'Flux Φ = E·A has units (N/C)(m²) = N m² C⁻¹, equivalently V·m.'),
  mcq('Physics', 'Electrostatic Potential and Capacitance', 'medium', 'If the plate separation of a parallel-plate capacitor is doubled (area unchanged), its capacitance:', ['halves', 'doubles', 'stays the same', 'becomes four times'], 'A',
    'C = ε₀A/d, so doubling d halves C.'),
  mcq('Physics', 'Current Electricity', 'medium', 'The drift velocity of electrons in a conductor is given by:', ['I/(neA)', 'I·neA', 'neA/I', 'I/(nA)'], 'A',
    'I = neAv_d, so v_d = I/(neA).'),
  mcq('Physics', 'Alternating Current', 'medium', 'The resonant frequency of an L-C circuit is:', ['1/(2π√(LC))', '2π√(LC)', '1/(2πLC)', '√(LC)/(2π)'], 'A',
    'Resonance occurs when X_L = X_C, giving f = 1/(2π√(LC)).'),
  mcq('Physics', 'Ray Optics and Optical Instruments', 'hard',
    'A convex lens of focal length 20 cm forms the image of an object placed 30 cm in front of it. The image distance is:', ['60 cm', '30 cm', '12 cm', '45 cm'], 'A',
    '1/v − 1/u = 1/f with u = −30 cm, f = +20 cm: 1/v = 1/20 − 1/30 = 1/60, so v = +60 cm (real, inverted, magnified).'),
  mcq('Physics', 'Dual Nature of Radiation and Matter', 'medium', 'Light of energy 5 eV falls on a metal of work function 2 eV. The maximum kinetic energy of the emitted electrons is:', ['3 eV', '7 eV', '2.5 eV', '0.4 eV'], 'A',
    'KEmax = hν − φ = 5 − 2 = 3 eV.'),
  mcq('Physics', 'Nuclei', 'medium', 'The nuclear radius R is related to the mass number A by:', ['R = R₀A^(1/3)', 'R = R₀A', 'R = R₀A²', 'R = R₀A^(2/3)'], 'A',
    'Nuclear volume is proportional to A, so R ∝ A^(1/3): R = R₀A^(1/3) with R₀ ≈ 1.2 fm.'),
  mcq('Physics', 'Semiconductor Electronics', 'easy', 'A Zener diode is commonly used as a:', ['voltage regulator', 'rectifier', 'amplifier', 'switch only'], 'A',
    'In reverse breakdown the voltage across a Zener diode stays nearly constant, so it regulates voltage.'),
  mcq('Physics', 'Electromagnetic Induction', 'medium', "Lenz's law is a direct consequence of the conservation of:", ['energy', 'charge', 'momentum', 'mass'], 'A',
    'The induced current opposes the change that causes it, which is exactly the requirement that energy is not created.'),
  numeric('Physics', 'Systems of Particles and Rotational Motion', 'medium',
    'A uniform rod of mass 2 kg and length 1 m rotates about an axis through one end perpendicular to its length. Its moment of inertia (kg m²) is:', '0.667',
    'I = ML²/3 = (2)(1²)/3 ≈ 0.667 kg m².'),

  // ---------------- Chemistry ----------------
  numeric('Chemistry', 'Equilibrium', 'easy', 'The pH of a 0.01 M HCl solution is:', '2',
    'HCl is a strong acid, so [H⁺] = 0.01 M = 10⁻² M and pH = −log(10⁻²) = 2.'),
  mcq('Chemistry', 'Chemical Kinetics', 'medium', 'The rate constant of a reaction has units s⁻¹. The order of the reaction is:', ['first order', 'zero order', 'second order', 'third order'], 'A',
    'For an n-th order reaction the units of k are mol^(1−n) L^(n−1) s⁻¹. Units of s⁻¹ correspond to n = 1.'),
  mcq('Chemistry', 'Chemical Kinetics', 'medium', 'The half-life of a first-order reaction is given by:', ['0.693/k', 'k/0.693', '1/k²', '2k'], 'A',
    'For a first-order reaction t₁/₂ = ln 2 / k ≈ 0.693/k, independent of initial concentration.'),
  mcq('Chemistry', 'Solutions', 'medium', 'Which of the following has the highest boiling point?', ['Ethanol', 'Dimethyl ether', 'Ethane', 'Methane'], 'A',
    'Ethanol shows intermolecular hydrogen bonding, giving it the strongest intermolecular forces and the highest boiling point of the four.'),
  mcq('Chemistry', 'Coordination Compounds', 'medium', 'The coordination number of cobalt in [Co(NH₃)₆]³⁺ is:', ['6', '3', '4', '2'], 'A',
    'Six NH₃ ligands are directly bonded to the central Co³⁺ ion, so the coordination number is 6.'),
  mcq('Chemistry', 'Haloalkanes and Haloarenes', 'hard', 'Which substrate reacts fastest by an SN1 mechanism?', ['Tertiary alkyl halide', 'Primary alkyl halide', 'Methyl halide', 'Vinyl chloride'], 'A',
    'SN1 proceeds through a carbocation; tertiary carbocations are the most stable, so tertiary halides react fastest.'),
  mcq('Chemistry', 'Aldehydes, Ketones and Carboxylic Acids', 'easy', "Which reagent gives a silver mirror with an aldehyde but not with a ketone?", ["Tollens' reagent", 'Fehling solution', 'Brady reagent', 'Lucas reagent'], 'A',
    "Tollens' reagent (ammoniacal AgNO₃) oxidises aldehydes to carboxylates and deposits metallic silver; ketones do not react."),
  mcq('Chemistry', 'Structure of Atom', 'easy', 'The maximum number of electrons in a subshell with l = 2 is:', ['10', '6', '2', '14'], 'A',
    'A d subshell (l = 2) has 5 orbitals, holding 2 electrons each — 10 in total.'),
  numeric('Chemistry', 'Some Basic Concepts of Chemistry', 'easy', 'The number of moles in 11.2 L of an ideal gas at STP is:', '0.5',
    'At STP, 22.4 L contains 1 mole, so 11.2 L contains 0.5 mol.'),
  mcq('Chemistry', 'Electrochemistry', 'medium', 'In a Daniell cell, the standard cell potential is approximately:', ['1.10 V', '0.34 V', '0.76 V', '2.00 V'], 'A',
    'E°cell = E°cathode − E°anode = 0.34 − (−0.76) = 1.10 V for the Zn/Cu cell.'),
  mcq('Chemistry', 'Chemical Bonding and Molecular Structure', 'medium', 'The shape of the NH₃ molecule is:', ['trigonal pyramidal', 'trigonal planar', 'tetrahedral', 'linear'], 'A',
    'Nitrogen has three bond pairs and one lone pair, giving an sp³ arrangement with trigonal pyramidal shape.'),

  // ---------------- Mathematics (Class 12 / JEE) ----------------
  mcq('Mathematics', 'Integral Calculus', 'medium', '∫ x eˣ dx equals:', ['eˣ(x − 1) + C', 'eˣ(x + 1) + C', 'x eˣ + C', 'eˣ/x + C'], 'A',
    'Integrating by parts with u = x, dv = eˣdx: ∫x eˣdx = x eˣ − ∫eˣdx = eˣ(x − 1) + C.'),
  mcq('Mathematics', 'Limits, Continuity and Differentiability', 'easy', 'lim(x→0) sin 3x / x equals:', ['3', '1', '1/3', '0'], 'A',
    'sin 3x / x = 3 · (sin 3x)/(3x) → 3 · 1 = 3 as x → 0.'),
  mcq('Mathematics', 'Continuity and Differentiability', 'medium', 'The derivative of sin(x²) with respect to x is:', ['2x cos(x²)', 'cos(x²)', '2x sin(x²)', 'x² cos(2x)'], 'A',
    'Using the chain rule: d/dx sin(x²) = cos(x²) · 2x.'),
  mcq('Mathematics', 'Vector Algebra', 'easy', 'If a⃗ = î + ĵ and b⃗ = ĵ + k̂, then a⃗ · b⃗ equals:', ['1', '0', '2', '√2'], 'A',
    'a⃗ · b⃗ = (1)(0) + (1)(1) + (0)(1) = 1.'),
  mcq('Mathematics', 'Permutations and Combinations', 'medium', 'The number of distinct arrangements of the letters of the word LEVEL is:', ['30', '60', '120', '20'], 'A',
    'LEVEL has 5 letters with L twice and E twice: 5!/(2!2!) = 120/4 = 30.'),
  mcq('Mathematics', 'Probability', 'medium', 'Two fair dice are thrown. The probability that the sum is 7 is:', ['1/6', '1/12', '5/36', '7/36'], 'A',
    'Favourable outcomes: (1,6),(2,5),(3,4),(4,3),(5,2),(6,1) — six of 36, so 1/6.'),
  mcq('Mathematics', 'Application of Derivatives', 'hard', 'The function f(x) = x³ − 3x has a local maximum at:', ['x = −1', 'x = 1', 'x = 0', 'x = 3'], 'A',
    "f′(x) = 3x² − 3 = 0 gives x = ±1. f″(x) = 6x, so f″(−1) < 0 (maximum) and f″(1) > 0 (minimum)."),
  numeric('Mathematics', 'Application of Integrals', 'hard', 'The area bounded by y = x², the x-axis and the lines x = 0 and x = 2 is (in square units):', '2.667',
    'Area = ∫₀² x² dx = [x³/3]₀² = 8/3 ≈ 2.667 square units.'),
  mcq('Mathematics', 'Matrices and Determinants', 'medium', 'If A is a 3 × 3 matrix with |A| = 5, then |2A| equals:', ['40', '10', '15', '5'], 'A',
    '|kA| = kⁿ|A| for an n × n matrix. Here |2A| = 2³ × 5 = 40.'),
  mcq('Mathematics', 'Three Dimensional Geometry', 'medium', 'The direction cosines of the z-axis are:', ['0, 0, 1', '1, 0, 0', '0, 1, 0', '1, 1, 1'], 'A',
    'The z-axis makes angles 90°, 90°, 0° with the axes, so its direction cosines are (0, 0, 1).'),

  // ---------------- Biology ----------------
  mcq('Biology', 'Human Reproduction', 'easy', 'In humans, fertilisation normally occurs in the:', ['ampulla of the fallopian tube', 'uterus', 'ovary', 'cervix'], 'A',
    'Fertilisation takes place in the ampullary-isthmic junction of the fallopian tube; the zygote then travels to the uterus.'),
  mcq('Biology', 'Principles of Inheritance and Variation', 'medium', "Mendel's law of segregation is explained by the separation of:", ['homologous chromosomes during meiosis', 'sister chromatids during mitosis', 'ribosomes during translation', 'chromosomes during fertilisation'], 'A',
    'Alleles segregate when homologous chromosomes separate in anaphase I of meiosis, so each gamete receives one allele.'),
  mcq('Biology', 'Biotechnology — Principles and Processes', 'medium', 'The recognition sequence of the restriction enzyme EcoRI is:', ['GAATTC', 'GGATCC', 'AAGCTT', 'AGCT'], 'A',
    "EcoRI cuts at the palindromic sequence 5'-GAATTC-3', producing sticky ends."),
  mcq('Biology', 'Biotechnology — Principles and Processes', 'medium', 'The denaturation step of PCR is typically carried out at about:', ['94 °C', '55 °C', '72 °C', '37 °C'], 'A',
    'PCR cycles run denaturation near 94 °C, primer annealing near 55 °C and extension near 72 °C.'),
  mcq('Biology', 'Human Health and Disease', 'medium', 'Which cells are the primary target of HIV?', ['Helper T lymphocytes', 'Red blood cells', 'Platelets', 'Neutrophils'], 'A',
    'HIV binds CD4 receptors on helper T cells and destroys them, progressively weakening immunity.'),
  mcq('Biology', 'Molecular Basis of Inheritance', 'medium', 'In the genetic code, the number of codons that code for amino acids is:', ['61', '64', '60', '20'], 'A',
    'Of the 64 codons, three are stop codons, leaving 61 sense codons for the 20 amino acids.'),
  mcq('Biology', 'Ecosystem', 'easy', 'The rate of conversion of solar energy into organic matter by producers is called:', ['primary productivity', 'secondary productivity', 'decomposition', 'respiration'], 'A',
    'Producers fix solar energy as organic matter; the rate of this fixation is gross primary productivity.'),
  descriptive('Biology', 'Human Reproduction', 'medium', 'short-answer',
    'State two functions of the placenta during human pregnancy.',
    'Functions of the placenta: (i) it provides a surface for the exchange of nutrients, oxygen and waste between the maternal and fetal blood without mixing them; (ii) it secretes hormones such as hCG, human placental lactogen, oestrogen and progesterone that maintain pregnancy. (2 marks)',
    2),

  // ---------------- Social Science ----------------
  mcq('Social Science', 'Nationalism in Europe', 'easy', 'Which treaty formally ended the First World War?', ['Treaty of Versailles', 'Treaty of Vienna', 'Treaty of Paris', 'Treaty of Rome'], 'A',
    'The Treaty of Versailles (1919) formally ended the First World War and imposed reparations and territorial losses on Germany.'),
  mcq('Social Science', 'Nationalism in India', 'easy', 'The Rowlatt Act was passed in the year:', ['1919', '1918', '1920', '1922'], 'A',
    'The Rowlatt Act was passed in 1919, allowing detention without trial and triggering nationwide protest.'),
  mcq('Social Science', 'Resources and Development', 'medium', 'Black soil in India is best suited for the cultivation of:', ['cotton', 'tea', 'rice', 'jute'], 'A',
    'Black soil retains moisture and is rich in calcium carbonate, magnesium and iron — ideal for cotton.'),
  mcq('Social Science', 'Power Sharing', 'medium', 'The Belgium model of power sharing is an example of:', ['community government', 'majoritarian rule', 'unitary government', 'military rule'], 'A',
    'Belgium created a community government elected by people of one language community, sharing power across linguistic groups.'),
  mcq('Social Science', 'Sectors of the Indian Economy', 'medium', 'Which sector includes activities like banking, transport and trade?', ['Tertiary sector', 'Primary sector', 'Secondary sector', 'Quaternary sector'], 'A',
    'Services such as banking, transport and trade support primary and secondary production and form the tertiary sector.'),

  // ---------------- English ----------------
  mcq('English', "Writing — Formal Letter", 'easy', 'Choose the correct passive voice: “He wrote the letter.”', ['The letter was written by him.', 'The letter is written by him.', 'The letter has wrote by him.', 'The letter wrote by him.'], 'A',
    'The simple past active "wrote" becomes "was written" in the passive, with the object promoted to subject.'),
  mcq('English', 'First Flight — Prose', 'medium', 'In “A Letter to God”, Lencho’s faith is best described as:', ['unshakeable', 'doubtful', 'temporary', 'irrelevant'], 'A',
    "Lencho's complete faith in God never wavers, even when the harvest is destroyed — the story's central irony comes from that faith."),
  descriptive('English', 'Writing — Analytical Paragraph', 'medium', 'short-answer',
    'Write a short analytical paragraph (60–80 words) describing the trend: “Internet users in a town rose from 20% in 2015 to 75% in 2023.”',
    'Model answer: Internet usage in the town grew sharply between 2015 and 2023. In 2015 only 20% of residents were online, but this figure climbed steadily each year, reaching 45% by 2019 and 75% by 2023. The steepest rise occurred after 2019, suggesting that cheaper data and wider smartphone ownership drove adoption across age groups. (Content, organisation and expression carry the marks.)',
    3),

  // ---------------- JEE-style hard problems ----------------
  mcq('Physics', 'Work, Energy and Power', 'advanced',
    'A block of mass 2 kg slides down a rough incline of angle 30° from a height of 5 m and reaches the bottom with speed 6 m/s. The work done against friction (g = 10 m/s²) is:', ['−44 J', '−100 J', '−64 J', '−36 J'], 'A',
    'Initial potential energy = mgh = 2 × 10 × 5 = 100 J. Final kinetic energy = ½(2)(36) = 36 J. Work against friction = 36 − 100 = −64 J, so 64 J is lost — among the options the change is −64 J.'),
  mcq('Mathematics', 'Complex Numbers and Quadratic Equations', 'advanced',
    'If z = 1 + i√3, then z³ equals:', ['−8', '8', '8i', '−8i'], 'A',
    'z = 2(cos 60° + i sin 60°), so z³ = 8(cos 180° + i sin 180°) = −8 by De Moivre’s theorem.'),
  mcq('Chemistry', 'Thermodynamics', 'advanced',
    'For an isothermal reversible expansion of an ideal gas, which statement is correct?', ['ΔU = 0 and q = −w', 'ΔU = q and w = 0', 'q = 0 and ΔU = w', 'ΔH = 0 and q = 0'], 'A',
    'For an ideal gas at constant temperature ΔU = 0, so from the first law q = −w: heat absorbed equals work done by the gas.'),
  mcq('Chemistry', 'The p-Block Elements', 'hard',
    'Which of the following is the strongest oxidising agent?', ['F₂', 'Cl₂', 'Br₂', 'I₂'], 'A',
    'Fluorine has the highest electrode potential among halogens and is the strongest oxidising agent.'),
  mcq('Mathematics', 'Definite Integrals', 'advanced',
    'The value of ∫₀^(π/2) sin x dx is:', ['1', '0', 'π/2', '2'], 'A',
    '∫₀^(π/2) sin x dx = [−cos x]₀^(π/2) = 0 − (−1) = 1.'),
  mcq('Physics', 'Electrostatics', 'advanced',
    'Two point charges +q and −q are separated by 2a. The electric potential at the midpoint is:', ['zero', 'kq/a', '2kq/a', 'kq/2a'], 'A',
    'At the midpoint the potentials from +q and −q are equal in magnitude and opposite in sign, so they cancel to zero.'),
];
