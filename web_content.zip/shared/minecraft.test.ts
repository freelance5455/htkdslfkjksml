import { describe, expect, it } from "vitest";
import {
  createMinecraftProperties,
  createNebulaManifest,
  makeEmptyDraft,
  type ServerDraft,
} from "./minecraft";

function draft(overrides: Partial<ServerDraft> = {}): ServerDraft {
  const empty = makeEmptyDraft(new Date("2026-10-01T00:00:00.000Z"));
  return { ...empty, id: "server-test", ...overrides };
}

describe("Minecraft settings export", () => {
  it("exports Java MOTD, maximum players and a minimum protection radius", () => {
    const properties = createMinecraftProperties(
      draft({
        name: "Nebula & Friends",
        color: "#71e7ff",
        maxPlayers: 32,
        protectionWidth: 1,
        protectionLength: 1,
      })
    );
    expect(properties).toContain("motd=§bNebula & Friends");
    expect(properties).toContain("max-players=32");
    expect(properties).toContain("spawn-protection=1");
    expect(properties).toContain("online-mode=true");
  });

  it("exports Bedrock keys without claiming Java spawn protection", () => {
    const properties = createMinecraftProperties(
      draft({ edition: "bedrock", name: "PE World", maxPlayers: 8 })
    );
    expect(properties).toContain("server-name=PE World");
    expect(properties).toContain("max-players=8");
    expect(properties).toContain("server-port=19132");
    expect(properties).toContain(
      "does not provide vanilla square/explosion spawn protection"
    );
    expect(properties).not.toContain("spawn-protection=");
  });

  it("preserves the requested 100 by 100 area and documents the real deployment boundary", () => {
    const config = JSON.parse(
      createNebulaManifest(
        draft({ protectionWidth: 100, protectionLength: 100 })
      )
    );
    expect(config.server.spawnProtection).toMatchObject({
      width: 100,
      length: 100,
      requested: true,
    });
    expect(config.server.spawnProtection.explosions).toContain(
      "requires a compatible"
    );
    expect(config.note).toContain("does not start or host");
  });
});
