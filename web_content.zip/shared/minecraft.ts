export type Edition = "java" | "bedrock";
export type ServerSoftware = "vanilla" | "forge";
export type JavaTrack = "old_alpha" | "old_beta" | "release" | "snapshot";
export type HostingState = "draft";

export interface ServerDraft {
  id: string;
  name: string;
  color: string;
  edition: Edition;
  software: ServerSoftware;
  track: JavaTrack;
  version: string;
  maxPlayers: number;
  protectionWidth: number;
  protectionLength: number;
  iconData: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface JavaVersionCatalog {
  versions: string[];
  updatedAt: string;
  source: "Mojang";
}

export const trackLabels: Record<JavaTrack, string> = {
  old_alpha: "Alpha",
  old_beta: "Beta",
  release: "Релизы",
  snapshot: "Снапшоты",
};

export const sampleVersions: Record<JavaTrack, string[]> = {
  old_alpha: ["a1.2.6", "a1.2.5", "a1.2.4", "a1.2.3", "a1.2.2"],
  old_beta: ["b1.7.3", "b1.7.2", "b1.7.1", "b1.6.6", "b1.6.5"],
  release: ["1.21.4", "1.21.3", "1.21.2", "1.21.1", "1.20.6"],
  snapshot: ["25w02a", "24w46a", "24w45a", "24w44a", "24w43a"],
};

export function makeEmptyDraft(now = new Date()): Omit<ServerDraft, "id"> {
  const stamp = now.toISOString();
  return {
    name: "Мой сервер",
    color: "#71e7ff",
    edition: "java",
    software: "vanilla",
    track: "release",
    version: "",
    maxPlayers: 12,
    protectionWidth: 16,
    protectionLength: 16,
    iconData: null,
    createdAt: stamp,
    updatedAt: stamp,
  };
}

function propertyValue(value: string): string {
  return value
    .replace(/[\\\r\n\t]/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
}

function colorToLegacyCode(hex: string): string {
  const palette = [
    { code: "f", rgb: [255, 255, 255] },
    { code: "e", rgb: [255, 255, 85] },
    { code: "6", rgb: [255, 170, 0] },
    { code: "c", rgb: [255, 85, 85] },
    { code: "4", rgb: [170, 0, 0] },
    { code: "d", rgb: [255, 85, 255] },
    { code: "5", rgb: [170, 0, 170] },
    { code: "9", rgb: [85, 85, 255] },
    { code: "1", rgb: [0, 0, 170] },
    { code: "b", rgb: [85, 255, 255] },
    { code: "3", rgb: [0, 170, 170] },
    { code: "a", rgb: [85, 255, 85] },
    { code: "2", rgb: [0, 170, 0] },
    { code: "7", rgb: [170, 170, 170] },
    { code: "8", rgb: [85, 85, 85] },
    { code: "0", rgb: [0, 0, 0] },
  ];
  const channels = hex
    .match(/[0-9a-f]{2}/gi)
    ?.map(part => Number.parseInt(part, 16)) ?? [113, 231, 255];
  let best = palette[0];
  let bestDistance = Number.POSITIVE_INFINITY;
  for (const candidate of palette) {
    const distance = channels.reduce(
      (sum, channel, index) => sum + (channel - candidate.rgb[index]) ** 2,
      0
    );
    if (distance < bestDistance) {
      best = candidate;
      bestDistance = distance;
    }
  }
  return `§${best.code}`;
}

export function createMinecraftProperties(draft: ServerDraft): string {
  const name = propertyValue(draft.name) || "Nebula Server";
  const color = colorToLegacyCode(draft.color);
  if (draft.edition === "bedrock") {
    return [
      `server-name=${name}`,
      `max-players=${draft.maxPlayers}`,
      "server-port=19132",
      "server-portv6=19133",
      "online-mode=true",
      "allow-list=false",
      "level-name=world",
      "# Bedrock Dedicated Server does not provide vanilla square/explosion spawn protection.",
      "# The requested protection area is saved in nebula-config.json for a compatible addon/host.",
      "",
    ].join("\n");
  }
  const radius = Math.max(
    1,
    Math.ceil(Math.max(draft.protectionWidth, draft.protectionLength) / 2)
  );
  return [
    `motd=${color}${name}`,
    `max-players=${draft.maxPlayers}`,
    `spawn-protection=${radius}`,
    "online-mode=true",
    "server-port=25565",
    "level-name=world",
    "enable-command-block=false",
    "",
  ].join("\n");
}

export function createNebulaManifest(draft: ServerDraft): string {
  return JSON.stringify(
    {
      product: "Nebula Server Studio",
      status: "configuration-only",
      server: {
        name: propertyValue(draft.name),
        edition: draft.edition,
        software:
          draft.edition === "java" ? draft.software : "bedrock-dedicated",
        versionTrack: draft.edition === "java" ? draft.track : "latest-stable",
        version: draft.version,
        maxPlayers: draft.maxPlayers,
        spawnProtection: {
          requested: true,
          width: draft.protectionWidth,
          length: draft.protectionLength,
          explosions:
            "requires a compatible server add-on or mod; vanilla properties are not a guarantee",
        },
        iconFormat: draft.iconData ? "server-icon.png (64x64 PNG)" : null,
      },
      note: "This file describes settings only; it does not start or host a Minecraft server.",
    },
    null,
    2
  );
}
