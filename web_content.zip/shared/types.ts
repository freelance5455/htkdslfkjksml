export type Depth = "BRIEF" | "NORMAL" | "DETAILED" | "DEEP" | "RESEARCH";
export type Status = "AVAILABLE" | "LIMITED" | "CONFIG_REQUIRED" | "UNAVAILABLE" | "UNVERIFIED";
export type Permission = "READ" | "SAFE_WRITE" | "SENSITIVE" | "EXTERNAL_ACTION";
export type Verification = "VERIFIED" | "FAILED" | "UNVERIFIED";

export interface JarvisResponse {
  text: string;
  depth: Depth;
  status: Status;
  verification: Verification;
  actions: string[];
}

export interface Capability {
  name: string;
  status: Status;
  description: string;
}
