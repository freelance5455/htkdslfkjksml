/**
 * JARVIS Personal Autonomous AI Operating System
 * Shared Browser-Safe Contracts & Type Definitions
 * 
 * IMPORTANT: This module MUST contain ONLY browser-safe TypeScript.
 * Absolutely NO Node.js APIs, Express types, database drivers, secrets, or process.env access.
 */

export type PermissionLevel = 'READ' | 'SAFE_WRITE' | 'SENSITIVE' | 'EXTERNAL_ACTION';

export type TaskStatus =
  | 'IDLE'
  | 'PERCEIVING'
  | 'PLANNING'
  | 'EXECUTING'
  | 'WAITING_PERMISSION'
  | 'VERIFYING'
  | 'REPLANNING'
  | 'COMPLETED'
  | 'FAILED';

export type CoreLoopStage =
  | 'PERCEIVE'
  | 'UNDERSTAND'
  | 'REMEMBER'
  | 'PLAN'
  | 'SELECT_MODEL'
  | 'SELECT_TOOLS'
  | 'EXECUTE'
  | 'OBSERVE'
  | 'VERIFY'
  | 'REPLAN'
  | 'RESPOND';

export type AgentRole =
  | 'GENERAL'
  | 'PLANNER'
  | 'RESEARCH'
  | 'CODING'
  | 'VISION'
  | 'AUTOMATION'
  | 'SECURITY';

export interface ModelMetadata {
  id: string;
  name: string;
  provider: 'gemini' | 'openai-compat' | 'local-heuristic';
  category: 'reasoning' | 'coding' | 'vision' | 'general';
  contextWindow: number;
  inputCostPer1kTokens: number;
  outputCostPer1kTokens: number;
  isHealthy: boolean;
  averageLatencyMs: number;
  totalTokensUsed: number;
  totalRequests: number;
}

export interface ModelRouteRequest {
  prompt: string;
  systemInstruction?: string;
  requiredCategory?: 'reasoning' | 'coding' | 'vision' | 'general';
  temperature?: number;
  maxTokens?: number;
}

export interface ModelRouteResponse {
  modelId: string;
  provider: string;
  text: string;
  promptTokens: number;
  completionTokens: number;
  latencyMs: number;
  costUsd: number;
}

export interface MemoryEntry {
  id: string;
  userId: string;
  type: 'short_term' | 'long_term' | 'task_history' | 'knowledge';
  key: string;
  content: string;
  importance: number; // 1 to 10
  tags: string[];
  createdAt: string;
  updatedAt: string;
  metadata?: Record<string, unknown>;
}

export interface MemoryQuery {
  text?: string;
  type?: MemoryEntry['type'];
  minImportance?: number;
  tags?: string[];
  limit?: number;
}

export type ExecutionMode =
  | 'REAL'
  | 'SIMULATED'
  | 'UNAVAILABLE'
  | 'BLOCKED_REQUIRES_PERMISSION'
  | 'FAILED';

export type CapabilityAvailability =
  | 'REAL'
  | 'SIMULATED'
  | 'UNAVAILABLE'
  | 'ONLINE'
  | 'OFFLINE_READY'
  | 'DEGRADED';

export type SafetyLevel = 'SAFE' | 'CONTROLLED' | 'RESTRICTED' | 'CRITICAL';

export type CapabilityCategory =
  | 'conversation'
  | 'explanation'
  | 'reasoning'
  | 'computation'
  | 'coding'
  | 'research'
  | 'memory'
  | 'security'
  | 'system'
  | 'automation'
  | 'document_analysis'
  | 'multimodal'
  | 'device_control'
  | 'cybersecurity';

export interface CapabilityDescriptor {
  capabilityId: string;
  id: string; // backwards-compatible alias
  name: string;
  description: string;
  category: CapabilityCategory;
  requiredPermissions: PermissionLevel;
  supportedInputs: Record<string, unknown>;
  supportedOutputs: Record<string, unknown>;
  executionMode: ExecutionMode;
  availability: CapabilityAvailability;
  provider: string;
  safetyLevel: SafetyLevel;
  verificationMethod: string;
  failureModes: string[];
  supportedEnvironments?: string[];
  dependencies?: string[];
  riskLevel?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export type FailureClassification =
  | 'NONE'
  | 'TIMEOUT'
  | 'AUTH_ERROR'
  | 'RATE_LIMIT'
  | 'UNAVAILABLE'
  | 'INVALID_INPUT'
  | 'PERMISSION_DENIED'
  | 'EXECUTION_ERROR'
  | 'VERIFICATION_FAILED'
  | 'NETWORK_ERROR'
  | 'PROVIDER_ERROR'
  | 'TOOL_NOT_FOUND'
  | 'UNAVAILABLE_ENVIRONMENT'
  | 'UNKNOWN';

export type ResponseDepthLevel = 'BRIEF' | 'NORMAL' | 'DETAILED' | 'DEEP' | 'RESEARCH';

export function normalizeResponseDepth(depth?: string): ResponseDepthLevel {
  if (!depth) return 'NORMAL';
  const clean = depth.trim().toUpperCase().replace('-', '_');
  if (clean === 'BRIEF' || clean === 'SHORT' || clean === 'CONCISE') return 'BRIEF';
  if (clean === 'STANDARD' || clean === 'NORMAL') return 'NORMAL';
  if (clean === 'IN_DEPTH' || clean === 'DETAILED') return 'DETAILED';
  if (clean === 'DEEP') return 'DEEP';
  if (clean === 'RESEARCH') return 'RESEARCH';
  return 'NORMAL';
}

export interface ToolParameter {
  type: 'string' | 'number' | 'boolean' | 'object' | 'array';
  description: string;
  required?: boolean;
  default?: unknown;
}

export interface ToolDefinition {
  name: string;
  purpose?: string;
  description: string;
  parameters: Record<string, ToolParameter>;
  outputSchema?: Record<string, unknown>;
  permissionLevel: PermissionLevel;
  executionStatus?: ExecutionMode;
  executionMode?: ExecutionMode;
  safetyLevel?: SafetyLevel;
  provider?: string;
  timeoutMs: number;
  retryPolicy?: { maxRetries: number; backoffMs?: number };
  verificationMethod?: string;
  safetyConstraints?: string[];
  capabilityId?: string;
  execute?: (input: any, context?: any) => Promise<any>;
}

export interface ToolExecutionResult {
  toolName: string;
  toolId?: string;
  executionState?: ExecutionMode;
  executionMode?: ExecutionMode;
  provider?: string;
  output: unknown;
  result?: unknown;
  data?: any;
  startedAt?: string;
  completedAt?: string;
  durationMs?: number;
  executionTimeMs: number;
  success: boolean;
  permissionGranted: boolean;
  verification?: VerificationResult;
  error?: string;
  failureClassification?: FailureClassification;
}

export interface SkillCapability {
  name: string;
  description: string;
}

export interface SkillDefinition {
  id: string;
  name: string;
  description: string;
  version: string;
  capabilities: SkillCapability[];
  requiredTools: string[];
  requiredPermissions: PermissionLevel[];
  status: 'ACTIVE' | 'DEPRECATED' | 'DISABLED';
}

export type VerificationStatus = 'VERIFIED' | 'NOT_VERIFIED' | 'UNVERIFIED' | 'PARTIALLY_VERIFIED' | 'FAILED' | 'SKIPPED';

export type ExecutionState =
  | 'PLANNED'
  | 'EXECUTING'
  | 'EXECUTED'
  | 'VERIFIED'
  | 'COMPLETED'
  | 'FAILED'
  | 'NOT_EXECUTED'
  | 'WAITING_PERMISSION'
  | 'BLOCKED_REQUIRES_PERMISSION'
  | 'SIMULATED'
  | 'UNAVAILABLE';

export type ModelProviderSource =
  | 'REAL_MODEL'
  | 'LOCAL_HEURISTIC'
  | 'FALLBACK_MODEL'
  | 'TOOL_RESULT'
  | 'MIXED'
  | 'UNKNOWN';

export type MemorySourceType =
  | 'STORED'
  | 'CURRENT_CONTEXT'
  | 'INFERRED'
  | 'NOT_STORED'
  | 'UNKNOWN';

export interface VerificationResult {
  stepId: string;
  status: VerificationStatus;
  passed: boolean;
  checksPerformed: string[];
  evidence?: Record<string, unknown> | string[];
  failures?: string[];
  warnings?: string[];
  score?: number; // 0.0 to 1.0 based on actual passed checks count (no arbitrary percentages)
  verifiedAt: string;
  verificationMethod?: string;
  failureClassification?: 'NONE' | 'RECOVERABLE' | 'CRITICAL' | 'PERMISSION_DENIED' | 'TIMEOUT';
  remediationAdvice?: string;
  timestamp: string;
}

export interface TaskStep {
  id: string;
  stepNumber: number;
  title: string;
  description: string;
  assignedAgent: AgentRole;
  toolName?: string;
  toolInput?: Record<string, unknown>;
  toolOutput?: unknown;
  toolResult?: ToolExecutionResult;
  status:
    | 'PENDING'
    | 'RUNNING'
    | 'WAITING_PERMISSION'
    | 'VERIFIED'
    | 'FAILED'
    | 'SKIPPED'
    | 'PLANNED'
    | 'EXECUTING'
    | 'EXECUTED'
    | 'BLOCKED_REQUIRES_PERMISSION'
    | 'SIMULATED'
    | 'UNAVAILABLE';
  executionState?: ExecutionState;
  verificationCriteria: string;
  verificationResult?: VerificationResult;
  retryCount: number;
  maxRetries: number;
  error?: string;
}

export interface TaskPlan {
  id: string;
  taskId: string;
  goal: string;
  steps: TaskStep[];
  selectedSkills: string[];
  selectedTools: string[];
  selectedCapabilities?: string[];
  primaryModel: string;
  reasoning: string;
  estimatedEffort: 'low' | 'medium' | 'high';
  createdAt: string;
}

export interface TaskItem {
  id: string;
  userId: string;
  title: string;
  rawPrompt: string;
  status: TaskStatus;
  currentStage: CoreLoopStage;
  plan?: TaskPlan;
  resultSummary?: string;
  pendingPermissionStep?: TaskStep;
  createdAt: string;
  updatedAt: string;
  logs: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  taskId?: string;
  conversationId?: string;
  coreStage?: CoreLoopStage;
  executionState?: ExecutionState;
  metadata?: {
    modelUsed?: string;
    modelProviderSource?: ModelProviderSource;
    tokensUsed?: number;
    latencyMs?: number;
    toolsCalled?: string[];
    verificationStatus?: VerificationStatus;
    verificationScore?: number;
    memorySource?: MemorySourceType;
    researchConsulted?: boolean;
    isSimulated?: boolean;
    verifiedAt?: string;
    hadFallback?: boolean;
    intent?: string;
    safetyViolation?: boolean;
    [key: string]: unknown;
  };
}

export interface AgentMessage {
  id: string;
  fromAgent: AgentRole | 'JARVIS_CORE';
  toAgent: AgentRole | 'JARVIS_CORE';
  content: string;
  timestamp: string;
}

export interface AgentInfo {
  role: AgentRole;
  name: string;
  description: string;
  capabilities: string[];
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  permissionLevel: PermissionLevel;
  details: Record<string, unknown>;
  status: 'ALLOWED' | 'DENIED' | 'PENDING_APPROVAL';
}

export interface PendingPermissionRequest {
  id: string;
  taskId: string;
  stepId: string;
  action: string;
  toolName: string;
  permissionLevel: PermissionLevel;
  details: Record<string, unknown>;
  createdAt: string;
}

export interface SystemEvent {
  id: string;
  timestamp: string;
  type: 'CORE_LOOP' | 'AGENT' | 'TOOL' | 'MODEL' | 'SECURITY' | 'VERIFICATION';
  stage?: CoreLoopStage;
  message: string;
  data?: unknown;
}

export interface SystemStatus {
  system: string;
  assistantIdentity?: string;
  version?: string;
  operationalStatus: string;
  coreLoop: string;
  environment?: string;
  database?: unknown;
  activeAgentsCount: number;
  registeredToolsCount: number;
  registeredSkillsCount: number;
  modelsConfiguredCount: number;
  totalTasksExecuted: number;
  pendingAuthorizationsCount: number;
  memoryUsageRssMb: number;
  hasGeminiApiKey: boolean;
}

export type MemoryEpistemicState = 'STORED' | 'CURRENT_CONTEXT' | 'INFERRED' | 'UNKNOWN';

export type VoicePersonality = 'CALM' | 'PROFESSIONAL' | 'FRIENDLY' | 'TECHNICAL' | 'CONCISE';

export interface VoiceSettings {
  enabled: boolean;
  voiceURI?: string;
  rate: number;
  pitch: number;
  volume: number;
  personality: VoicePersonality;
}

// === API Request and Response Contracts ===

export interface ApiResponse<T = unknown> {
  success?: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface HealthApiResponse {
  status: 'ok' | 'degraded' | 'error';
  system: string;
  version: string;
  environment: string;
  timestamp: string;
  uptime: number;
}

export interface ChatApiRequest {
  prompt: string;
  conversationId?: string;
}

export interface ChatApiResponse {
  success: boolean;
  task: TaskItem;
  message: ChatMessage;
  error?: string;
}

export interface TasksListApiResponse {
  tasks: TaskItem[];
}

export interface TaskDetailApiResponse {
  task: TaskItem;
  error?: string;
}

export interface TaskApproveApiResponse {
  success: boolean;
  task?: TaskItem;
  error?: string;
}

export interface TaskRejectApiResponse {
  success: boolean;
  task?: TaskItem;
  error?: string;
}

export interface MessagesListApiResponse {
  messages: ChatMessage[];
}

export interface MemoryListApiResponse {
  memories: MemoryEntry[];
}

export interface MemoryStoreApiRequest {
  key: string;
  content: string;
  type?: MemoryEntry['type'];
  importance?: number;
  tags?: string[];
}

export interface MemoryStoreApiResponse {
  success: boolean;
  memory?: MemoryEntry;
  error?: string;
}

export interface MemoryDeleteApiResponse {
  success: boolean;
}

export interface ToolsApiResponse {
  tools: ToolDefinition[];
}

export interface ToolExecuteApiRequest {
  toolName: string;
  parameters?: Record<string, unknown>;
  params?: Record<string, unknown>;
}

export interface SkillsApiResponse {
  skills: SkillDefinition[];
}

export interface ModelsApiResponse {
  models: ModelMetadata[];
}

export interface AgentsApiResponse {
  agents: AgentInfo[];
  recentMessages: AgentMessage[];
}

export interface SecurityAuditApiResponse {
  auditLogs: AuditLog[];
  pendingRequests: PendingPermissionRequest[];
}

// === Task #9 Workspace, Founder, Version & Discovery Contracts ===

export type ConversationTopic =
  | 'General'
  | 'Quantum Physics'
  | 'AI Engineering'
  | 'JARVIS Development'
  | 'School'
  | 'Programming'
  | 'Research'
  | 'Custom';

export interface ConversationItem {
  id: string;
  userId: string;
  title: string;
  topic?: string;
  createdAt: string;
  updatedAt: string;
  messageCount?: number;
  lastMessageSnippet?: string;
  isArchived?: boolean;
  isTrash?: boolean;
  hasCustomTitle?: boolean;
  projectId?: string;
  projectName?: string;
}

export interface ConversationsListApiResponse {
  conversations: ConversationItem[];
}

export interface ConversationDetailApiResponse {
  conversation: ConversationItem;
  messages: ChatMessage[];
  error?: string;
}

export interface ConversationCreateApiRequest {
  title?: string;
  topic?: string;
  projectId?: string;
}

export interface ConversationUpdateApiRequest {
  title?: string;
  topic?: string;
  isArchived?: boolean;
  isTrash?: boolean;
  hasCustomTitle?: boolean;
  projectId?: string | null;
}

export interface ConversationSearchApiResponse {
  query: string;
  totalFound: number;
  conversations: Array<ConversationItem & { matchedSnippet?: string }>;
}

// === Task #10 Projects System Contracts ===

export interface ProjectItem {
  id: string;
  userId: string;
  name: string;
  description: string;
  contextBrief?: string;
  status: 'ACTIVE' | 'ARCHIVED';
  isArchived?: boolean;
  isTrash?: boolean;
  conversationCount?: number;
  conversations?: ConversationItem[];
  createdAt: string;
  updatedAt: string;
}

export interface ProjectsListApiResponse {
  projects: ProjectItem[];
}

export interface ProjectDetailApiResponse {
  project: ProjectItem;
  conversations: ConversationItem[];
  error?: string;
}

export interface ProjectCreateApiRequest {
  name: string;
  description?: string;
  contextBrief?: string;
}

export interface ProjectUpdateApiRequest {
  name?: string;
  description?: string;
  contextBrief?: string;
  status?: 'ACTIVE' | 'ARCHIVED';
  isArchived?: boolean;
  isTrash?: boolean;
}

export type CapabilityAwarenessStatus =
  | 'AVAILABLE'
  | 'UNAVAILABLE'
  | 'REQUIRES_PERMISSION'
  | 'REQUIRES_INTEGRATION'
  | 'NOT_SUPPORTED';

export type MemoryEpistemicLabel =
  | 'STORED'
  | 'CURRENT_CONTEXT'
  | 'INFERRED'
  | 'UNKNOWN';

export interface FounderProfile {
  name: string;
  role: string;
  preferredAddress: string;
  academicLevel: string;
  interests: string[];
  projectVision: string;
  projectPrinciples: string[];
  longTermInterests: string[];
}

export interface VersionEvolutionEntry {
  version: string;
  previousVersion?: string;
  releaseDate: string;
  changelog: string[];
  capabilitiesAdded: string[];
  bugsFixed: string[];
  testsPassedCount: number;
  checkpointRef: string;
  isEligible: boolean;
}

export interface VersionMetadata {
  currentVersion: string;
  productName: string;
  previousVersion: string;
  underlyingArchitecture: {
    primaryModelProvider: string;
    fallbackProvider: string;
    localHeuristicActive: boolean;
    registeredToolsCount: number;
    registeredCapabilitiesCount: number;
  };
  evolutionLifecycle: string[];
  history: VersionEvolutionEntry[];
  lastValidatedTimestamp: string;
}

export type FreeResourceCategory =
  | 'ai_tools'
  | 'courses'
  | 'legal_streaming'
  | 'music'
  | 'developer_tools'
  | 'hosting'
  | 'educational'
  | 'open_source';

export type FreeResourcePricingModel =
  | 'PERMANENTLY_FREE'
  | 'FREE_TIER'
  | 'TRIAL_ONLY'
  | 'FREEMIUM'
  | 'OPEN_SOURCE';

export interface FreeResourceAccessRequirements {
  loginRequired: boolean;
  signupRequired: boolean;
  paymentCardRequired: boolean; // If true, NOT genuinely free upfront!
  trialPeriodDays?: number;
  usageLimits: string;
  adsPresent: boolean;
  regionRestrictions?: string;
}

export interface FreeResourceLegitimacyCheck {
  isOfficialSource: boolean;
  isLegal: boolean;
  isPiracyOrBypass: boolean;
  safetyRating: 'VERIFIED_SAFE' | 'REQUIRES_CAUTION' | 'PROHIBITED';
  copyrightNotice?: string;
}

export interface FreeResourceItem {
  id: string;
  name: string;
  category: FreeResourceCategory;
  url: string;
  description: string;
  pricingModel: FreeResourcePricingModel;
  isGenuinelyFree: boolean;
  access: FreeResourceAccessRequirements;
  legitimacy: FreeResourceLegitimacyCheck;
  currentAvailability: 'ONLINE_VERIFIED' | 'KNOWN_ACTIVE' | 'ACCESS_UNVERIFIED';
  liveVerificationStatus: 'LIVE_CHECKED' | 'CURATED_INDEX' | 'UNAVAILABLE';
  verificationNote: string;
}

export interface FreeResourceQuery {
  query?: string;
  category?: FreeResourceCategory;
  mustBeGenuinelyFree?: boolean;
  noPaymentCardRequired?: boolean;
  limit?: number;
}

export interface FreeResourceResult {
  query: string;
  category?: string;
  totalFound: number;
  resources: FreeResourceItem[];
  researchNotice: string;
  legalCompliancePassed: boolean;
  refusalReason?: string;
  suggestedLegalAlternatives?: string[];
}

export type VoiceSessionStatus =
  | 'IDLE'
  | 'LISTENING'
  | 'PROCESSING'
  | 'PAUSED'
  | 'ERROR'
  | 'UNSUPPORTED';

export interface ContinuousVoiceSessionState {
  status: VoiceSessionStatus;
  isSupported: boolean;
  recognizedSegments: string[];
  currentTranscript: string;
  errorMessage?: string;
  unsupportedReason?: string;
}

// === Task #11 File, Document & Universal Knowledge Contracts ===

export interface FileAttachmentEntity {
  id: string;
  conversationId?: string;
  projectId?: string;
  userId: string;
  filename: string;
  originalName: string;
  mimeType: string;
  sizeBytes: number;
  fileCategory: 'pdf' | 'document' | 'code' | 'image' | 'text' | 'other';
  storagePath: string;
  textContent?: string;
  summary?: string;
  isExtracted: boolean;
  extractionStatus: 'EXTRACTED' | 'OCR_REQUIRED' | 'UNSUPPORTED' | 'FAILED' | 'EMPTY';
  extractionNote?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface GeneratedDocumentEntity {
  id: string;
  title: string;
  filename: string;
  format: 'pdf' | 'txt' | 'md' | 'json' | 'csv';
  content: string;
  sizeBytes: number;
  conversationId?: string;
  projectId?: string;
  userId: string;
  createdAt: string;
  downloadUrl: string;
}

export type UniversalStatusLabel =
  | 'FREE'
  | 'FREE_TIER'
  | 'OPEN_SOURCE'
  | 'PUBLIC_DOMAIN'
  | 'AD_SUPPORTED'
  | 'TRIAL'
  | 'LOGIN_REQUIRED'
  | 'PAYMENT_REQUIRED'
  | 'REGION_RESTRICTED'
  | 'LIMITED'
  | 'UNKNOWN'
  | 'UNVERIFIED';

export type ResourceAvailabilityStatus =
  | 'ONLINE_VERIFIED'
  | 'RECORDED_ACTIVE'
  | 'LIVE_CHECK_UNAVAILABLE'
  | 'SHUT_DOWN'
  | 'BLOCKED_OR_REGION_RESTRICTED'
  | 'UNVERIFIED';

export interface UniversalResourceInvestigation {
  query: string;
  name: string;
  type: string;
  purpose: string;
  officialSource: string;
  currentAvailability: ResourceAvailabilityStatus;
  pricingModel: FreeResourcePricingModel | 'UNKNOWN';
  statusLabels: UniversalStatusLabel[];
  isGenuinelyFree: boolean | null;
  loginRequired: boolean | null;
  paymentCardRequired: boolean | null;
  isOpenSource: boolean | null;
  isPublicDomain: boolean | null;
  isAdSupported: boolean | null;
  usageLimits: string;
  majorLimitations: string[];
  legitimacySignals: string[];
  safetyConcerns: string[];
  alternatives: Array<{ name: string; url: string; note: string }>;
  verificationConfidence: number;
  verifiedSources: string[];
  statusNote: string;
  directAnswer: string;
}

export interface WebResearchSourceCitation {
  title: string;
  url: string;
  authoritativeRating: 'HIGH' | 'MEDIUM' | 'COMMUNITY' | 'UNVERIFIED';
  snippet: string;
  relevanceScore: number;
}

export interface WebResearchReport {
  query: string;
  sourcesExaminedCount: number;
  citations: WebResearchSourceCitation[];
  conflictDetected: boolean;
  conflictNotes?: string;
  conciseSummary: string;
  detailedFindings: string[];
  synthesisConfidence: number;
  verificationMethod: string;
}
