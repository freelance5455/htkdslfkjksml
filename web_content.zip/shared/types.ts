/**
 * Shared domain types used by both the React client and the Worker API.
 * These mirror the D1 schema in worker/schema.ts.
 */

export type ExamId = 'cbse10' | 'cbse12' | 'jee-main' | 'jee-advanced' | 'custom';

export type TeachingMode = 'beginner' | 'exam' | 'advanced';

export type QuestionType =
  | 'mcq'
  | 'multiple-correct'
  | 'numerical'
  | 'integer'
  | 'assertion-reason'
  | 'case-based'
  | 'short-answer'
  | 'long-answer'
  | 'competency';

export type Difficulty = 'easy' | 'medium' | 'hard' | 'advanced';

export interface ExamPattern {
  id: ExamId;
  label: string;
  description: string;
  durationMinutes: number;
  subjects: string[];
  /** Marking rules that are actually published by the board/conducting body. */
  marking: {
    correct: number;
    incorrect: number | null;
    unattempted: number;
    note: string;
  };
  sections: { name: string; types: QuestionType[]; count: number; marksEach: number }[];
  negativeMarking: boolean;
  officialSource: string;
  answerEvaluation: 'objective' | 'mixed';
}

export interface ChapterSeed {
  subject: string;
  chapters: string[];
}

export interface StudentProfile {
  userId: number;
  name: string;
  email: string;
  exam: ExamId;
  examLabel: string;
  examDate: string | null;
  classLevel: string;
  board: string;
  targetScore: string;
  dailyHours: number;
  schoolStart: string | null;
  schoolEnd: string | null;
  coachingStart: string | null;
  coachingEnd: string | null;
  sleepAt: string;
  wakeAt: string;
  preferredStart: string;
  preferredEnd: string;
  subjects: string[];
  weakSubjects: string[];
  strongSubjects: string[];
  learningStyle: string;
  currentPerformance: string;
  commitments: string;
  onboarded: boolean;
  createdAt: string;
}

export interface ChapterProgress {
  id: number;
  subject: string;
  chapter: string;
  status: 'not-started' | 'learning' | 'revising' | 'confident';
  mastery: number;
  lastStudied: string | null;
  nextReview: string | null;
  intervalDays: number;
  ease: number;
  repetitions: number;
}

export interface StudySessionRow {
  id: number;
  date: string;
  minutes: number;
  subject: string;
  chapter: string | null;
  source: string;
  createdAt: string;
}

export interface ScheduleItem {
  id: number;
  date: string;
  startTime: string;
  endTime: string;
  title: string;
  kind: 'learn' | 'revise' | 'practice' | 'mock' | 'break' | 'school' | 'coaching' | 'other';
  subject: string | null;
  chapter: string | null;
  status: 'pending' | 'done' | 'missed' | 'rescheduled';
  priority: number;
  notes: string | null;
  planId: number | null;
}

export interface QuestionOption {
  key: string;
  text: string;
}

export interface QuestionRow {
  id: number;
  subject: string;
  chapter: string;
  topic: string | null;
  type: QuestionType;
  difficulty: Difficulty;
  prompt: string;
  options: QuestionOption[] | null;
  correct: string[];
  numericAnswer: string | null;
  marks: number;
  negative: number;
  solution: string;
  source: 'seed' | 'ai' | 'resource' | 'previous-year';
  sourceLabel: string;
  verified: boolean;
  year: number | null;
  resourceId: number | null;
  resourcePages: string | null;
  testId: number | null;
  createdAt: string;
}

export interface TestRow {
  id: number;
  title: string;
  exam: ExamId;
  config: TestConfig;
  durationMinutes: number;
  totalMarks: number;
  status: 'draft' | 'in-progress' | 'submitted';
  createdAt: string;
  questionCount: number;
}

export interface TestConfig {
  exam: ExamId;
  subjects: string[];
  chapters: string[];
  types: QuestionType[];
  difficulty: Difficulty;
  questionCount: number;
  durationMinutes: number;
  negativeMarking: boolean;
  useResources: boolean;
  resourceIds: number[];
  instructions?: string;
  generatedBy: 'ai' | 'bank';
}

export interface AttemptAnswer {
  questionId: number;
  response: string[];
  numeric: string | null;
  timeSpentSeconds: number;
  marked: boolean;
  visited: boolean;
}

export interface AttemptRow {
  id: number;
  testId: number;
  status: 'in-progress' | 'submitted';
  startedAt: string;
  submittedAt: string | null;
  answers: Record<string, AttemptAnswer>;
  score: number;
  maxScore: number;
  correct: number;
  incorrect: number;
  unattempted: number;
  accuracy: number;
  timeSpentSeconds: number;
  report: AttemptReport | null;
}

export interface EvaluatedQuestion {
  questionId: number;
  subject: string;
  chapter: string;
  type: QuestionType;
  difficulty: Difficulty;
  prompt: string;
  correct: string[];
  numericAnswer: string | null;
  response: string[];
  numericResponse: string | null;
  status: 'correct' | 'incorrect' | 'unattempted' | 'partial';
  awarded: number;
  maxMarks: number;
  solution: string;
  explanation: string | null;
  timeSpentSeconds: number;
  mistakeType: MistakeType | null;
}

export type MistakeType =
  | 'conceptual'
  | 'calculation'
  | 'formula'
  | 'careless'
  | 'time-management'
  | 'incomplete-preparation'
  | 'misinterpretation';

export interface AttemptReport {
  evaluated: EvaluatedQuestion[];
  subjects: { subject: string; correct: number; incorrect: number; unattempted: number; score: number; max: number; accuracy: number }[];
  chapters: { chapter: string; subject: string; correct: number; total: number; accuracy: number }[];
  difficulties: { difficulty: Difficulty; correct: number; total: number; accuracy: number }[];
  mistakeCounts: Record<string, number>;
  attemptRate: number;
  timeEfficiency: string;
  summary: string;
  strengths: string[];
  improvements: string[];
  improvementPlan: { title: string; detail: string; priority: 'high' | 'medium' | 'low' }[];
  analysisSource: 'ai' | 'rules';
  generatedAt: string;
}

export interface ResourceRow {
  id: number;
  name: string;
  kind: string;
  sizeBytes: number;
  pageCount: number;
  chunkCount: number;
  status: 'processing' | 'ready' | 'failed' | 'empty';
  subject: string | null;
  chapters: string[];
  error: string | null;
  summary: string | null;
  createdAt: string;
}

export interface ResourceChunk {
  id: number;
  resourceId: number;
  resourceName: string;
  page: number;
  text: string;
  score?: number;
}

export interface RevisionCard {
  id: number;
  front: string;
  back: string;
  subject: string | null;
  chapter: string | null;
  source: 'ai' | 'question' | 'manual' | 'formula';
  due: string;
  intervalDays: number;
  ease: number;
  repetitions: number;
  lapses: number;
  questionId: number | null;
}

export interface ChatMessage {
  id?: number;
  role: 'user' | 'assistant';
  content: string;
  citations?: { resourceName: string; page: number }[];
  createdAt?: string;
}

export interface ChatThread {
  id: number;
  title: string;
  mode: TeachingMode;
  subject: string | null;
  chapter: string | null;
  updatedAt: string;
}

export interface DashboardData {
  profile: StudentProfile;
  stats: {
    preparation: number;
    syllabusCompletion: number;
    chaptersTotal: number;
    chaptersDone: number;
    studyMinutes7d: number;
    studyMinutes30d: number;
    streak: number;
    testsTaken: number;
    avgAccuracy: number | null;
    revisionDue: number;
    resourcesReady: number;
    questionsSolved: number;
  };
  subjects: { subject: string; total: number; confident: number; learning: number; notStarted: number; completion: number; mastery: number }[];
  weakest: { subject: string; chapter: string; mastery: number; status: string }[];
  strongest: { subject: string; chapter: string; mastery: number; status: string }[];
  recentTests: { id: number; title: string; score: number; max: number; accuracy: number; submittedAt: string; exam: ExamId }[];
  trend: { date: string; accuracy: number; score: number }[];
  today: ScheduleItem[];
  upcoming: ScheduleItem[];
  badges: { id: string; label: string; description: string; earned: boolean; icon: string }[];
  nextExam: { label: string; date: string | null; daysLeft: number | null };
  dailyGoalMinutes: number;
}

export interface QuestionBankFilters {
  subject?: string;
  chapter?: string;
  type?: QuestionType | '';
  difficulty?: Difficulty | '';
  source?: string;
  search?: string;
  bookmarked?: boolean;
  attempted?: 'incorrect' | 'correct' | 'unattempted' | '';
}

export interface ApiError {
  error: string;
  code?: string;
  detail?: string;
  setupRequired?: boolean;
}
