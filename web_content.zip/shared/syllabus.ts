import type { ExamId } from './types';

/**
 * Chapter maps per subject/exam. These follow the published CBSE/NCERT chapter
 * structure and the JEE Main/Advanced syllabus subjects. They are a starting
 * syllabus a student can edit; nothing here is presented as official content.
 */

const MATHS_10 = [
  'Real Numbers', 'Polynomials', 'Pair of Linear Equations in Two Variables', 'Quadratic Equations',
  'Arithmetic Progressions', 'Triangles', 'Coordinate Geometry', 'Introduction to Trigonometry',
  'Some Applications of Trigonometry', 'Circles', 'Areas Related to Circles', 'Surface Areas and Volumes',
  'Statistics', 'Probability',
];

const SCIENCE_10 = [
  'Chemical Reactions and Equations', 'Acids, Bases and Salts', 'Metals and Non-metals', 'Carbon and its Compounds',
  'Life Processes', 'Control and Coordination', 'How do Organisms Reproduce', 'Heredity and Evolution',
  'Light — Reflection and Refraction', 'The Human Eye and the Colourful World', 'Electricity',
  'Magnetic Effects of Electric Current', 'Our Environment', 'Sustainable Management of Natural Resources',
];

const SST_10 = [
  'Nationalism in Europe', 'Nationalism in India', 'The Making of a Global World', 'Resources and Development',
  'Forest and Wildlife Resources', 'Water Resources', 'Agriculture', 'Minerals and Energy Resources',
  'Manufacturing Industries', 'Power Sharing', 'Federalism', 'Political Parties', 'Development',
  'Sectors of the Indian Economy', 'Money and Credit',
];

const ENGLISH_10 = [
  'Reading Comprehension', 'Writing — Formal Letter', 'Writing — Analytical Paragraph', 'Grammar — Tenses',
  'Grammar — Modals and Determiners', 'First Flight — Prose', 'First Flight — Poetry', 'Footprints Without Feet',
];

const PHYSICS_12 = [
  'Electric Charges and Fields', 'Electrostatic Potential and Capacitance', 'Current Electricity',
  'Moving Charges and Magnetism', 'Magnetism and Matter', 'Electromagnetic Induction', 'Alternating Current',
  'Electromagnetic Waves', 'Ray Optics and Optical Instruments', 'Wave Optics', 'Dual Nature of Radiation and Matter',
  'Atoms', 'Nuclei', 'Semiconductor Electronics',
];

const CHEM_12 = [
  'Solutions', 'Electrochemistry', 'Chemical Kinetics', 'The d- and f-Block Elements', 'Coordination Compounds',
  'Haloalkanes and Haloarenes', 'Alcohols, Phenols and Ethers', 'Aldehydes, Ketones and Carboxylic Acids',
  'Amines', 'Biomolecules',
];

const MATHS_12 = [
  'Relations and Functions', 'Inverse Trigonometric Functions', 'Matrices', 'Determinants', 'Continuity and Differentiability',
  'Application of Derivatives', 'Integrals', 'Application of Integrals', 'Differential Equations', 'Vector Algebra',
  'Three Dimensional Geometry', 'Linear Programming', 'Probability',
];

const BIO_12 = [
  'Sexual Reproduction in Flowering Plants', 'Human Reproduction', 'Reproductive Health', 'Principles of Inheritance and Variation',
  'Molecular Basis of Inheritance', 'Evolution', 'Human Health and Disease', 'Microbes in Human Welfare',
  'Biotechnology — Principles and Processes', 'Biotechnology and its Applications', 'Organisms and Populations',
  'Ecosystem', 'Biodiversity and Conservation',
];

const ENGLISH_12 = [
  'Reading Comprehension', 'Note Making', 'Writing — Notice and Invitation', 'Writing — Letter', 'Writing — Article and Report',
  'Flamingo — Prose', 'Flamingo — Poetry', 'Vistas — Supplementary',
];

const JEE_PHYSICS = [
  'Units and Measurements', 'Motion in a Straight Line', 'Motion in a Plane', 'Laws of Motion', 'Work, Energy and Power',
  'System of Particles and Rotational Motion', 'Gravitation', 'Mechanical Properties of Solids', 'Mechanical Properties of Fluids',
  'Thermal Properties of Matter', 'Thermodynamics', 'Kinetic Theory', 'Oscillations', 'Waves',
  'Electric Charges and Fields', 'Electrostatic Potential and Capacitance', 'Current Electricity', 'Moving Charges and Magnetism',
  'Magnetism and Matter', 'Electromagnetic Induction', 'Alternating Current', 'Electromagnetic Waves', 'Ray Optics',
  'Wave Optics', 'Dual Nature of Radiation and Matter', 'Atoms', 'Nuclei', 'Semiconductor Electronics and Devices',
];

const JEE_CHEM = [
  'Some Basic Concepts of Chemistry', 'Structure of Atom', 'Classification of Elements and Periodicity',
  'Chemical Bonding and Molecular Structure', 'Thermodynamics', 'Equilibrium', 'Redox Reactions', 'Solutions',
  'Electrochemistry', 'Chemical Kinetics', 'The p-Block Elements', 'The d- and f-Block Elements', 'Coordination Compounds',
  'Haloalkanes and Haloarenes', 'Alcohols, Phenols and Ethers', 'Aldehydes, Ketones and Carboxylic Acids', 'Amines',
  'Biomolecules', 'Practical Organic Chemistry', 'Hydrocarbons', 'States of Matter', 'Surface Chemistry',
  'General Principles and Processes of Isolation of Elements',
];

const JEE_MATHS = [
  'Sets, Relations and Functions', 'Complex Numbers and Quadratic Equations', 'Matrices and Determinants',
  'Permutations and Combinations', 'Mathematical Induction', 'Binomial Theorem', 'Sequences and Series',
  'Limits, Continuity and Differentiability', 'Integral Calculus', 'Differential Equations', 'Coordinate Geometry — Straight Lines',
  'Coordinate Geometry — Circles', 'Conic Sections', 'Three Dimensional Geometry', 'Vector Algebra', 'Statistics and Probability',
  'Trigonometry', 'Mathematical Reasoning',
];

export const SYLLABUS: Record<string, Record<string, string[]>> = {
  cbse10: { Mathematics: MATHS_10, Science: SCIENCE_10, 'Social Science': SST_10, English: ENGLISH_10 },
  cbse12: { Physics: PHYSICS_12, Chemistry: CHEM_12, Mathematics: MATHS_12, Biology: BIO_12, English: ENGLISH_12 },
  'jee-main': { Physics: JEE_PHYSICS, Chemistry: JEE_CHEM, Mathematics: JEE_MATHS },
  'jee-advanced': { Physics: JEE_PHYSICS, Chemistry: JEE_CHEM, Mathematics: JEE_MATHS },
  custom: { Physics: JEE_PHYSICS, Chemistry: JEE_CHEM, Mathematics: JEE_MATHS },
};

export function subjectsForExam(exam: ExamId, classLevel?: string): string[] {
  if (exam === 'cbse10') return Object.keys(SYLLABUS.cbse10);
  if (exam === 'cbse12') return Object.keys(SYLLABUS.cbse12);
  if (exam === 'jee-main' || exam === 'jee-advanced') return ['Physics', 'Chemistry', 'Mathematics'];
  const level = classLevel?.includes('10') ? 'cbse10' : 'cbse12';
  return Object.keys(SYLLABUS[level]);
}

export function chaptersFor(exam: ExamId, subject: string): string[] {
  const byExam = SYLLABUS[exam] ?? {};
  if (byExam[subject]) return byExam[subject];
  for (const key of Object.keys(SYLLABUS)) {
    if (SYLLABUS[key][subject]) return SYLLABUS[key][subject];
  }
  return [];
}

export function allChapters(exam: ExamId, subjects: string[]): { subject: string; chapter: string }[] {
  const out: { subject: string; chapter: string }[] = [];
  for (const subject of subjects) for (const chapter of chaptersFor(exam, subject)) out.push({ subject, chapter });
  return out;
}
