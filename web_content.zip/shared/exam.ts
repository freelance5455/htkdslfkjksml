import type { ExamId, ExamPattern } from './types';

/**
 * Exam patterns below follow the published, stable features of each exam:
 * total duration, subject set, and negative-marking rules. Question counts and
 * per-question marks are kept deliberately approximate where the board changes
 * them every year, and the app labels them "indicative" so we never present an
 * invented pattern as the official one.
 */
export const EXAM_PATTERNS: Record<ExamId, ExamPattern> = {
  cbse10: {
    id: 'cbse10',
    label: 'CBSE Class 10 Board',
    description: 'CBSE Class 10 board examination — competency-focused, mixed objective and descriptive answers.',
    durationMinutes: 180,
    subjects: ['Mathematics', 'Science', 'Social Science', 'English'],
    marking: { correct: 1, incorrect: 0, unattempted: 0, note: 'CBSE board theory papers carry no negative marking. Marks shown are indicative.' },
    sections: [
      { name: 'Section A — Objective', types: ['mcq', 'assertion-reason'], count: 20, marksEach: 1 },
      { name: 'Section B — Very short answer', types: ['short-answer'], count: 6, marksEach: 2 },
      { name: 'Section C — Short answer', types: ['short-answer', 'case-based'], count: 7, marksEach: 3 },
      { name: 'Section D — Long answer', types: ['long-answer', 'competency'], count: 5, marksEach: 5 },
    ],
    negativeMarking: false,
    officialSource: 'CBSE curriculum & sample question papers (cbseacademic.nic.in)',
    answerEvaluation: 'mixed',
  },
  cbse12: {
    id: 'cbse12',
    label: 'CBSE Class 12 Board',
    description: 'CBSE Class 12 board examination — theory papers with competency-based and case-study questions.',
    durationMinutes: 180,
    subjects: ['Physics', 'Chemistry', 'Mathematics', 'Biology', 'English'],
    marking: { correct: 1, incorrect: 0, unattempted: 0, note: 'CBSE board theory papers carry no negative marking. Marks shown are indicative.' },
    sections: [
      { name: 'Section A — MCQ / Assertion-Reason', types: ['mcq', 'assertion-reason'], count: 16, marksEach: 1 },
      { name: 'Section B — Very short answer', types: ['short-answer'], count: 7, marksEach: 2 },
      { name: 'Section C — Short answer', types: ['short-answer', 'case-based'], count: 5, marksEach: 3 },
      { name: 'Section D — Case-based', types: ['case-based'], count: 2, marksEach: 4 },
      { name: 'Section E — Long answer', types: ['long-answer'], count: 3, marksEach: 5 },
    ],
    negativeMarking: false,
    officialSource: 'CBSE Class 12 sample question papers (cbseacademic.nic.in)',
    answerEvaluation: 'mixed',
  },
  'jee-main': {
    id: 'jee-main',
    label: 'JEE Main',
    description: 'NTA JEE Main (Paper 1) — MCQ and numerical-value questions with negative marking for MCQs.',
    durationMinutes: 180,
    subjects: ['Physics', 'Chemistry', 'Mathematics'],
    marking: { correct: 4, incorrect: -1, unattempted: 0, note: 'MCQ: +4 / −1. Numerical-value questions: +4 / −1 as per NTA practice. Duration is 3 hours for Paper 1.' },
    sections: [
      { name: 'Section A — MCQ', types: ['mcq'], count: 20, marksEach: 4 },
      { name: 'Section B — Numerical value', types: ['numerical', 'integer'], count: 10, marksEach: 4 },
    ],
    negativeMarking: true,
    officialSource: 'NTA JEE (Main) information bulletin & practice papers',
    answerEvaluation: 'objective',
  },
  'jee-advanced': {
    id: 'jee-advanced',
    label: 'JEE Advanced',
    description: 'IIT JEE Advanced — multi-concept problems, multiple-correct and integer-type questions with partial marking.',
    durationMinutes: 180,
    subjects: ['Physics', 'Chemistry', 'Mathematics'],
    marking: { correct: 4, incorrect: -2, unattempted: 0, note: 'Paper-wise marking varies each year (partial marking for multiple-correct, +4/−2 patterns). Marks and counts here are indicative — always check the current year paper pattern.' },
    sections: [
      { name: 'Section 1 — Single correct', types: ['mcq'], count: 6, marksEach: 3 },
      { name: 'Section 2 — One or more correct', types: ['multiple-correct'], count: 5, marksEach: 4 },
      { name: 'Section 3 — Numerical / integer', types: ['integer', 'numerical'], count: 4, marksEach: 3 },
    ],
    negativeMarking: true,
    officialSource: 'JEE (Advanced) organising institute information brochure',
    answerEvaluation: 'objective',
  },
  custom: {
    id: 'custom',
    label: 'Custom Exam Profile',
    description: 'Your own exam profile: pick subjects, chapters and marking rules yourself.',
    durationMinutes: 120,
    subjects: [],
    marking: { correct: 1, incorrect: 0, unattempted: 0, note: 'Custom profile — marking is configured by you in test settings.' },
    sections: [],
    negativeMarking: false,
    officialSource: 'User-defined',
    answerEvaluation: 'mixed',
  },
};

export const EXAM_LIST = Object.values(EXAM_PATTERNS);

export const DIFFICULTY_LABEL: Record<string, string> = {
  easy: 'Easy',
  medium: 'Medium',
  hard: 'Hard',
  advanced: 'Advanced',
};

export const QUESTION_TYPE_LABEL: Record<string, string> = {
  mcq: 'Single correct MCQ',
  'multiple-correct': 'Multiple correct',
  numerical: 'Numerical value',
  integer: 'Integer type',
  'assertion-reason': 'Assertion & Reason',
  'case-based': 'Case-based',
  'short-answer': 'Short answer',
  'long-answer': 'Long answer',
  competency: 'Competency-based',
};

export function isObjective(type: string): boolean {
  return ['mcq', 'multiple-correct', 'numerical', 'integer', 'assertion-reason'].includes(type);
}

export function examLabel(id: string): string {
  return EXAM_PATTERNS[id as ExamId]?.label ?? 'Custom Exam Profile';
}

export const MISTAKE_LABELS: Record<string, string> = {
  conceptual: 'Conceptual misunderstanding',
  calculation: 'Calculation error',
  formula: 'Formula confusion',
  careless: 'Careless mistake',
  'time-management': 'Time-management issue',
  'incomplete-preparation': 'Incomplete preparation',
  misinterpretation: 'Incorrect question interpretation',
};
