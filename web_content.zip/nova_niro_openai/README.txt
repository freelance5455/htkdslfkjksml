NOVA NIRO — OPENAI API
======================

Fitur di proyek ini:
- Chat dengan OpenAI Responses API.
- Unggah foto ke chat untuk analisis visual dan identifikasi benda.
- Analisis foto untuk mencari petunjuk lokasi; membaca metadata GPS EXIF jika tersedia.
- Generator gambar OpenAI Images API.
- Studio unduh file teks/kode: TXT, MD, JSON, HTML, CSV, JS, PY, CSS, XML, SVG.
- UI responsif untuk ponsel dan desktop.

PENTING:
Kunci API yang pernah diposting ke chat harus dianggap bocor. Cabut/revoke kunci tersebut di
dashboard OpenAI dan buat kunci baru. Jangan pernah memasukkan kunci yang diposting itu ke proyek.
Saya sengaja tidak menyertakan kunci apa pun.

Persyaratan:
- Node.js LTS
- OpenAI API key baru dengan billing/akses model yang sesuai
- Koneksi internet

Menjalankan:
1. Ekstrak ZIP.
2. Buka terminal di folder proyek.
3. Jalankan: npm install
4. Salin .env.example menjadi .env
   Windows PowerShell: Copy-Item .env.example .env
   macOS/Linux: cp .env.example .env
5. Buka .env, masukkan API key BARU pada OPENAI_API_KEY.
6. Jika model default tidak tersedia di akun API, ganti OPENAI_MODEL dengan model teks/vision yang
   tersedia di akunmu. Untuk gambar, ganti OPENAI_IMAGE_MODEL dengan model gambar yang tersedia.
7. Jalankan: npm start
8. Buka http://localhost:3000

Lokasi foto:
- Jika metadata GPS masih tersimpan, aplikasi akan melaporkannya sebagai metadata, bukan jaminan.
- Jika GPS tidak ada, model hanya memperkirakan dari petunjuk visual. Tidak bisa memastikan
  koordinat atau alamat pasti dari visual saja.
- Jangan gunakan fitur ini untuk melacak orang atau menemukan alamat pribadi tanpa izin.

Batasan fitur:
- Video: proyek ini belum menghasilkan file video secara langsung. Tidak menyatakan fitur video
  aktif jika API video tidak dikonfigurasi. Bisa gunakan chat untuk menyusun prompt, naskah,
  shot list, dan storyboard. Integrasi video langsung membutuhkan layanan/model yang tersedia
  untuk akun dan implementasi API tambahan.
- "Semua format file" tidak realistis secara literal. Versi ini mendukung format teks/kode umum.
  PDF, DOCX, XLSX, audio, dan format biner lain perlu generator khusus.
- Tidak semua model tersedia di semua akun. Model dan biaya dapat berubah; cek dokumentasi resmi.

Keamanan penggunaan:
- Jangan upload foto pribadi tanpa izin.
- Untuk publikasi, tambahkan autentikasi, rate limiting, batas ukuran, logging yang tidak menyimpan
  konten sensitif, HTTPS, dan kontrol biaya.
- Jangan commit file .env ke repositori.
- Penggunaan OpenAI API dapat dikenakan biaya terpisah dari langganan ChatGPT.
