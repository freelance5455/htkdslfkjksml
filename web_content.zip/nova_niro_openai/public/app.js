const $ = s => document.querySelector(s);
let imageFile = null, imageUrl = null, locationFile = null, locationDataUrl = null;
const history = [];
function addMessage(role, text, imgUrl=null) {
  const row=document.createElement("div"); row.className=`message ${role}`;
  const avatar=document.createElement("div"); avatar.className="avatar"; avatar.textContent=role==="assistant"?"✦":"●";
  const bubble=document.createElement("div"); bubble.className="bubble"; bubble.textContent=text;
  if(imgUrl){const img=document.createElement("img");img.src=imgUrl;img.alt="Foto terlampir";bubble.appendChild(img);}
  row.append(avatar,bubble);$("#messages").appendChild(row);$("#messages").scrollTop=$("#messages").scrollHeight;return row;
}
function busy(on){$("#send-btn").disabled=on;$("#send-btn").textContent=on?"…":"↑";$("#chat-input").disabled=on;}
function toDataUrl(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(Error("Tidak bisa membaca file."));r.readAsDataURL(file);});}
function clearAttachment(){if(imageUrl)URL.revokeObjectURL(imageUrl);imageFile=null;imageUrl=null;$("#chat-image").value="";$("#attach-chip").classList.add("hidden");}
$("#chat-image").addEventListener("change",()=>{const f=$("#chat-image").files?.[0];if(!f)return;if(f.size>6*1024*1024){alert("Ukuran foto maksimal 6 MB.");$("#chat-image").value="";return;}imageFile=f;imageUrl=URL.createObjectURL(f);$("#attach-name").textContent="Foto: "+f.name;$("#attach-chip").classList.remove("hidden");});
$("#remove-attach").addEventListener("click",clearAttachment);
$("#chat-form").addEventListener("submit",async e=>{
 e.preventDefault();const message=$("#chat-input").value.trim();if(!message)return;
 const file=imageFile, preview=imageUrl;addMessage("user",message,preview);$("#chat-input").value="";clearAttachment();
 const waiting=addMessage("assistant","NOVA NIRO sedang berpikir…");busy(true);
 try{
  const imageDataUrl=file?await toDataUrl(file):null;
  const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,imageDataUrl,history})});
  const d=await r.json();if(!r.ok)throw Error(d.error||"Permintaan gagal.");
  waiting.querySelector(".bubble").textContent=d.answer;history.push({role:"user",content:message},{role:"assistant",content:d.answer});if(history.length>20)history.splice(0,history.length-20);
 }catch(err){waiting.querySelector(".bubble").textContent="Gagal: "+err.message;}finally{busy(false);$("#chat-input").focus();}
});
document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>{$("#chat-input").value=b.dataset.prompt;$("#chat-input").focus();}));
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>{
 document.querySelectorAll("[data-view]").forEach(n=>n.classList.toggle("active",n===b));
 const name=b.dataset.view;["chat","image","files","location"].forEach(v=>$("#"+v+"-view").classList.toggle("hidden",v!==name));
 $("#page-title").textContent=({chat:"Chat dengan NOVA NIRO",image:"Buat Gambar",files:"Studio File",location:"Lokasi dari Foto"})[name];
}));
$("#image-form").addEventListener("submit",async e=>{
 e.preventDefault();const prompt=$("#image-prompt").value.trim();if(!prompt)return;const btn=$("#image-btn"),out=$("#image-output");btn.disabled=true;btn.textContent="Sedang membuat…";out.classList.remove("hidden");out.textContent="Menghubungi model gambar OpenAI…";
 try{const r=await fetch("/api/image",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});const d=await r.json();if(!r.ok)throw Error(d.error||"Gagal membuat gambar.");
 out.replaceChildren();const img=document.createElement("img");img.src=d.imageDataUrl;img.alt="Gambar hasil NOVA NIRO";const a=document.createElement("a");a.href=d.imageDataUrl;a.download="nova-niro.png";a.textContent="Unduh gambar";out.append(img,document.createElement("br"),a);
 }catch(err){out.textContent="Gagal: "+err.message;}finally{btn.disabled=false;btn.textContent="✦ Buat gambar";}
});
$("#download-file").addEventListener("click",()=>{
 const name=($("#file-name-input").value.trim()||"hasil-nova").replace(/[^a-zA-Z0-9_-]/g,"_").slice(0,80);
 const ext=$("#file-format").value;let content=$("#file-content").value;
 if(!content.trim()){alert("Isi konten file terlebih dahulu.");return;}
 if(ext==="json"){try{content=JSON.stringify(JSON.parse(content),null,2);}catch{alert("Konten JSON tidak valid. Periksa tanda kurung dan koma.");return;}}
 const mime=({txt:"text/plain",md:"text/markdown",json:"application/json",html:"text/html",csv:"text/csv",js:"text/javascript",py:"text/x-python",css:"text/css",xml:"application/xml",svg:"image/svg+xml"})[ext];
 const blob=new Blob([content],{type:`${mime};charset=utf-8`});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`${name}.${ext}`;a.click();URL.revokeObjectURL(url);
});
$("#location-image").addEventListener("change",async()=>{
 const f=$("#location-image").files?.[0];locationFile=f||null;locationDataUrl=null;$("#analyze-location").disabled=!f;$("#location-result").textContent="";
 const preview=$("#location-preview");preview.replaceChildren();if(!f)return;
 if(f.size>6*1024*1024){alert("Ukuran foto maksimal 6 MB.");$("#location-image").value="";locationFile=null;$("#analyze-location").disabled=true;return;}
 locationDataUrl=await toDataUrl(f);const img=document.createElement("img");img.src=locationDataUrl;img.alt="Pratinjau foto";preview.append(img);
});
$("#analyze-location").addEventListener("click",async()=>{
 if(!locationDataUrl)return;const btn=$("#analyze-location"),out=$("#location-result");btn.disabled=true;btn.textContent="Menganalisis…";out.textContent="Memeriksa metadata dan petunjuk visual…";
 try{const r=await fetch("/api/photo-location",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({imageDataUrl:locationDataUrl})});const d=await r.json();if(!r.ok)throw Error(d.error||"Analisis gagal.");out.textContent=d.answer;}
 catch(err){out.textContent="Gagal: "+err.message;}finally{btn.disabled=false;btn.textContent="⌖ Analisis foto";}
});
fetch("/api/health").then(r=>r.json()).then(d=>{$("#api-status").textContent=d.apiKeyConfigured?"API key terpasang":"API key belum dipasang";}).catch(()=>{$("#api-status").textContent="Server tidak terhubung";});
