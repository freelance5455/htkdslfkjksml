import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import Exifr from "exifr";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
app.use(express.json({ limit: "12mb" }));
app.use(express.static(path.join(__dirname, "public")));

function getClient() {
  if (!process.env.OPENAI_API_KEY) {
    const e = new Error("API key belum dipasang. Isi OPENAI_API_KEY di file .env.");
    e.status = 503;
    throw e;
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}
function apiError(err, res, feature) {
  console.error(`${feature} error:`, err?.message || err);
  const status = Number.isInteger(err?.status) ? err.status : 500;
  let message = "Permintaan gagal. Periksa koneksi, konfigurasi model, dan log server.";
  if (status === 401) message = "API key tidak valid. Periksa OPENAI_API_KEY di .env.";
  else if (status === 429) message = "Batas pemakaian atau saldo API tercapai. Periksa dashboard billing dan limits OpenAI.";
  else if (status === 503) message = err.message;
  res.status(status).json({ error: message });
}
app.get("/api/health", (_req, res) => {
  res.json({ ok: true, apiKeyConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { message, imageDataUrl, history = [] } = req.body ?? {};
    if (typeof message !== "string" || !message.trim()) return res.status(400).json({ error: "Tulis pesan terlebih dahulu." });
    if (message.length > 12000) return res.status(413).json({ error: "Pesan terlalu panjang (maks. 12.000 karakter)." });
    if (imageDataUrl && (typeof imageDataUrl !== "string" || !/^data:image\/(png|jpeg|jpg|webp|gif);base64,/i.test(imageDataUrl))) {
      return res.status(400).json({ error: "Gambar harus PNG, JPG, WEBP, atau GIF." });
    }
    const client = getClient();
    const content = [{ type: "input_text", text: message.trim() }];
    if (imageDataUrl) content.push({ type: "input_image", image_url: imageDataUrl, detail: "auto" });
    const safeHistory = Array.isArray(history) ? history.slice(-10).filter(m =>
      m && ["user", "assistant"].includes(m.role) && typeof m.content === "string"
    ).map(m => ({ role: m.role, content: m.content.slice(0, 4000) })) : [];
    const input = [...safeHistory, { role: "user", content }];
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6",
      instructions: "Namamu NOVA NIRO. Kamu adalah asisten AI serbaguna yang ramah, jelas, dan jujur. Jawab dalam bahasa pengguna. Bantu belajar, menulis, coding, analisis, dan tugas sehari-hari. Untuk gambar, sebutkan objek yang tampak dan bedakan fakta dari dugaan. Untuk lokasi dari foto, jangan mengklaim koordinat atau alamat pasti hanya dari tampilan visual; jelaskan petunjuk dan tingkat ketidakpastian. Jangan mengarang kemampuan atau hasil.",
      input
    });
    res.json({ answer: response.output_text || "Model tidak mengembalikan teks jawaban." });
  } catch (err) { apiError(err, res, "Chat"); }
});

app.post("/api/image", async (req, res) => {
  try {
    const { prompt } = req.body ?? {};
    if (typeof prompt !== "string" || !prompt.trim()) return res.status(400).json({ error: "Tulis deskripsi gambar." });
    if (prompt.length > 4000) return res.status(413).json({ error: "Prompt terlalu panjang." });
    const client = getClient();
    const result = await client.images.generate({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare",
      prompt: prompt.trim(),
      size: "1024x1024"
    });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) return res.status(502).json({ error: "Model gambar tidak mengembalikan gambar." });
    res.json({ imageDataUrl: `data:image/png;base64,${b64}` });
  } catch (err) { apiError(err, res, "Image"); }
});

app.post("/api/photo-location", async (req, res) => {
  try {
    const { imageDataUrl } = req.body ?? {};
    if (typeof imageDataUrl !== "string" || !/^data:image\/(png|jpeg|jpg|webp|gif);base64,/i.test(imageDataUrl)) {
      return res.status(400).json({ error: "Unggah foto yang valid." });
    }
    const client = getClient();
    let metadataText = "Tidak ada koordinat GPS EXIF yang dapat dibaca dari file ini.";
    try {
      const base64 = imageDataUrl.split(",")[1];
      const buf = Buffer.from(base64, "base64");
      const exif = await Exifr.parse(buf, { gps: true });
      if (exif?.latitude != null && exif?.longitude != null) {
        metadataText = `Metadata GPS EXIF ditemukan: latitude ${exif.latitude}, longitude ${exif.longitude}. Jelaskan bahwa metadata bisa tidak ada, salah, atau sudah berubah.`;
      }
    } catch {}
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6",
      instructions: "Analisis foto untuk memperkirakan lokasi secara bertanggung jawab. Jangan pernah mengaku dapat memastikan lokasi tepat dari petunjuk visual saja. Jika GPS EXIF tersedia, laporkan sebagai metadata yang mungkin tidak akurat dan sarankan verifikasi. Jika tidak, berikan kemungkinan umum berdasarkan petunjuk visual, jelaskan ketidakpastian, dan jangan menebak identitas atau alamat rumah pribadi.",
      input: [{
        role: "user",
        content: [
          { type: "input_text", text: `Perkirakan lokasi dari petunjuk yang terlihat dalam foto. Pisahkan pengamatan dari dugaan. ${metadataText}` },
          { type: "input_image", image_url: imageDataUrl, detail: "high" }
        ]
      }]
    });
    res.json({ answer: response.output_text || "Tidak ada hasil analisis." });
  } catch (err) { apiError(err, res, "Photo location"); }
});

app.listen(PORT, () => console.log(`NOVA NIRO berjalan di http://localhost:${PORT}`));