/* PWA install support and actionable diagnostics for AsimAI. Install UI is Chrome's native one only. */
(() => {
  'use strict';
  const root = document.documentElement;
  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const isChrome = /Chrome\//.test(navigator.userAgent) && !/Edg\//.test(navigator.userAgent) && !/OPR\//.test(navigator.userAgent);
  const canUseServiceWorker = () => window.isSecureContext && 'serviceWorker' in navigator;

  function applyDeviceLayout() {
    const ua = navigator.userAgent || '';
    const mobileUA = /Android|iPhone|iPod|Mobile|IEMobile|Opera Mini/i.test(ua);
    const tabletUA = /iPad|Tablet/i.test(ua);
    const width = Math.min(window.innerWidth || 9999, (window.visualViewport && window.visualViewport.width) || 9999);
    const physicalWidth = Math.min(screen.width || width, screen.availWidth || width);
    const mobile = (mobileUA && (navigator.maxTouchPoints || 0) > 0 && !tabletUA) || width <= 820 || ((navigator.maxTouchPoints || 0) > 0 && physicalWidth <= 820);
    root.classList.toggle('asim-mobile-device', mobile);
    root.classList.toggle('asim-desktop-device', !mobile);
    if (document.body) {
      document.body.classList.toggle('asim-mobile-device', mobile);
      document.body.classList.toggle('asim-desktop-device', !mobile);
    }
  }
  applyDeviceLayout();
  window.addEventListener('resize', applyDeviceLayout, { passive: true });
  window.addEventListener('orientationchange', () => setTimeout(applyDeviceLayout, 150), { passive: true });
  window.visualViewport?.addEventListener('resize', applyDeviceLayout, { passive: true });

  // Install is handled 100% by Chrome's own built-in UI (address-bar install icon / mini-infobar / menu).
  // We deliberately do NOT call preventDefault() on 'beforeinstallprompt', so Chrome shows its native prompt.
  window.addEventListener('appinstalled', () => {
    console.info('[AsimAI PWA] app installed');
  });

  if (canUseServiceWorker()) {
    const swURL = new URL('./service-worker.js', location.href);
    const scopeURL = new URL('./', location.href);
    window.addEventListener('load', () => {
      navigator.serviceWorker.register(swURL.href, { scope: scopeURL.href, updateViaCache: 'none' })
        .then(registration => {
          registration.update().catch(() => {});
          console.info('[AsimAI PWA] service worker ready for scope:', registration.scope);
        })
        .catch(error => console.warn('[AsimAI PWA] registration failed:', error));
    }, { once: true });
  } else {
    console.info('[AsimAI PWA] secure context required for install and service worker; open over HTTPS or localhost.');
  }
})();
