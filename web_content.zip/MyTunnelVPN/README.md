# My Tunnel VPN  (com.mytunnel.vpn)

Kotlin + Jetpack Compose + Material 3, MVVM, Room, DataStore, VpnService, Play Billing, AdMob.

## Build (APK)
1. Android Studio (Koala 2024.1+ / JDK 17) me `MyTunnelVPN` folder open karein.
2. Gradle sync hone dein (internet chahiye, wrapper khud download ho jata hai).
3. Phone USB debugging on -> **Run**. Ya APK: `Build > Build APK(s)` -> `app/build/outputs/apk/debug/`.
4. Release/Play Store: `Build > Generate Signed Bundle / APK` (apni keystore se).

## Pehli baar chalane par (debug)
Debug build me `DEMO_MODE = true` hai: seeded servers (config khali) simulated connect hote hain taake UI test ho sake.
**Release build me demo nahi hai** - har server ko real config chahiye.

## Real servers kaise lagayein
- Quick test: Servers -> Custom -> Import (WireGuard `.conf`, `.ovpn`, V2Ray/Xray JSON, `vmess://`, `vless://`).
- Production: `data/SeedServers.kt` me apne hosts + `config` dalein, ya apne panel API se `ServerDao.upsertAll()` karein.

## Kya poori tarah kaam karta hai
- WireGuard: real engine (official wireguard-android library). Split tunneling bhi.
- VpnService, foreground notification, kill switch (blackhole TUN), auto reconnect, timer, speed graph,
  data usage (Room), overlay bubble, QS tile, boot auto-start, speed test, IP check, favorites/search/random,
  zones + tier locking, Billing structure, AdMob banner (test ids), offline AI help, WhatsApp support, feedback.

## Native cores (OpenVPN / V2Ray VMess+VLESS / Xray) - ZAROORI
Ye cores native libraries hain jo is zip me shamil nahi (maine internet se download nahi kiye). Wiring tayyar hai:
`vpn/Engines.kt` -> `CoreBridge` interface. Aap ko sirf ye karna hai:
1. V2Ray/Xray: `libv2ray.aar` (AndroidLibXrayLite) `app/libs/` me rakhein, `build.gradle.kts` me `implementation(files("libs/libv2ray.aar"))` uncomment karein.
   OpenVPN: ics-openvpn (`de.blinkt.openvpn`) ya `ovpn3` core integrate karein.
2. `CoreBridge` implement karein: core ko `tunFd` dein, aur core ke outbound sockets par `protect(fd)` lagayein.
3. `CoreBridgeProvider.bridge = YourBridge()` set karein (Application.onCreate me).
Jab tak ye na ho, OpenVPN/VMess/VLESS/Xray servers par clear error aata hai (WireGuard theek chalta hai).

## Play Store notes
- VPN apps ko "VpnService declaration" aur privacy policy chahiye. `foregroundServiceType=specialUse` ki Play Console me wazahat deni hoti hai.
- AdMob: manifest me test APP_ID aur `ads/Ads.kt` me test banner id hai - apni real ids se badlein.
- Billing product ids: `premium_monthly`, `vip_monthly` (Play Console me subscriptions banayein). Production me purchase verification apne server par karein.
- AI Help abhi offline knowledge-base se jawab deta hai. LLM chahiye to `AiHelper.REMOTE_URL` par apna backend lagayein (API key app me kabhi na rakhein).
- WhatsApp support: 03157742662 (`util/Utils.kt`).

## Android Studio me build karne ka tareeqa (step by step)
1. Android Studio download karein (developer.android.com/studio), install karein. JDK 17 saath aata hai.
2. ZIP extract karein -> Android Studio: **File > Open** -> `MyTunnelVPN` folder chunein.
3. Neeche "Sync" chalne dein (pehli baar 5-15 min, internet on). Error ho to **File > Sync Project with Gradle Files**.
4. SDK missing ka message aaye to **Install** dabayein (Android SDK 34).
5. **Preview dekhna:** `ui/Previews.kt` kholein -> top-right "Split" ya "Design". App chalaye baghair look dikhta hai.
6. **Phone par chalana:** phone me Settings > About > Build number 7 baar tap > Developer options > USB debugging on. USB se joden, upar device chunein, green **Run** dabayein. (Ya Emulator: Device Manager > Create device.)
7. **APK banana:** Build > Build APK(s) > "locate" dabayein. File: `app/build/outputs/apk/debug/app-debug.apk` - phone me bhej kar install karein (Unknown sources allow).
8. **Play Store ke liye:** Build > Generate Signed Bundle / APK > Android App Bundle, apni keystore banayein (backup rakhein!).
Note: Compose project phone ke andar (AIDE/Termux) me build karna bharosemand nahi - PC par Android Studio istemal karein.

## Update (build fix + naye features)
- **newly.app error `Could not find or load main class "-Xmx64m"`**: `gradlew` ki JVM options me ghalat quotes thay, aur `gradle-wrapper.jar` zip me nahi thi. Naya `gradlew` theek hai: jar na ho to khud download karta hai, warna Gradle 8.7 seedha download karke chalata hai (download links built-in).
- **Har country ka server**: `data/Countries.kt` (196 countries) - pehli launch par offline DB me add hote hain, internet ke baghair bhi list dikhti hai.
- **Pakistan ki sab SIMs**: `data/PakistanCarriers.kt` - Jazz/Warid, Zong, Telenor, Ufone, SCOM ke alag profiles + operator detect.
- **Offline**: servers list/settings/AI help net ke baghair chalte hain. VPN tunnel khud net ke baghair nahi ban sakta, is par clear message aata hai.
- **Preview**: `ui/Previews.kt` (Home + Servers, dark/light).
- **Zaroori**: `Countries.SERVER_DOMAIN` (example.com) ko apne real server domain se badlein, warna release me connect nahi hoga. OpenVPN/VMess/VLESS/Xray ke liye abhi bhi native core bridge chahiye (upar "Native cores").

## Free online APK build (newly ke baghair) - GitHub Actions
1. github.com par free account -> New repository -> is folder ki saari files upload karein (`.github` folder samet).
2. Repo me **Actions** tab -> **Build APK** -> **Run workflow**.
3. 5-10 min baad build ke andar **Artifacts -> MyTunnelVPN-debug-apk** download karein (yahi APK download link hai).

## Naye features (area report, rewards, online/offline)
- Home: **Online / Offline** label (net on/off live).
- Stats tab: speed test + **Area network report** (location on ho to jagah ka naam, SIM operator, ping, packet loss, service quality %, pichle 15 reports).
- **Rewards** tab: daily reward (7 din ki streak), 4 daily missions, points aur levels (Bronze/Silver/Gold/Platinum).
- Real VPN: WireGuard abhi bhi real hai; baqi protocols ke liye apne real servers + native core chahiye (upar "Native cores").

## Voice chat, Staff system (is update me)
- AI Help: **mic** button se bol kar poochhein (Google speech), jawab text me bhi aur **speaker** icon on ho to bol kar bhi. Speaker icon se off.
- **Staff / admin system**: `backend/` folder (Node server + web panel). Admin staff accounts banata hai; staff users, device model, Android/app version, points (earnings), streak, last seen dekhta hai. Setup `backend/README.md` me.
  App me `STAFF_API_URL` aur `DEVICE_KEY` (app/build.gradle.kts) set karein. Settings me user "Staff sync" band kar sakta hai.
