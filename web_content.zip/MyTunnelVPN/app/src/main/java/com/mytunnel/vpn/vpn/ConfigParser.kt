package com.mytunnel.vpn.vpn

import android.util.Base64
import com.mytunnel.vpn.data.Protocol
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder

data class Parsed(val protocol: Protocol, val host: String, val port: Int, val name: String)

/** Detects and reads basic info from: .ovpn, WireGuard .conf, V2Ray/Xray JSON, vmess:// and vless:// links. */
object ConfigParser {

    fun parse(raw: String): Parsed? {
        val t = raw.trim()
        return try {
            when {
                t.startsWith("vmess://") -> vmessLink(t)
                t.startsWith("vless://") -> vlessLink(t)
                t.startsWith("{") -> json(t)
                t.contains("[Interface]") && t.contains("[Peer]") -> wireguard(t)
                Regex("(?m)^\\s*remote\\s+\\S+").containsMatchIn(t) -> openvpn(t)
                else -> null
            }
        } catch (e: Exception) { null }
    }

    private fun wireguard(t: String): Parsed? {
        val ep = Regex("(?im)^\\s*Endpoint\\s*=\\s*(.+)$").find(t)?.groupValues?.get(1)?.trim() ?: return null
        val i = ep.lastIndexOf(':')
        val host = ep.substring(0, i).trim('[', ']')
        return Parsed(Protocol.WIREGUARD, host, ep.substring(i + 1).trim().toInt(), host)
    }

    private fun openvpn(t: String): Parsed? {
        val m = Regex("(?m)^\\s*remote\\s+(\\S+)(?:\\s+(\\d+))?").find(t) ?: return null
        val host = m.groupValues[1]
        val port = m.groupValues[2].ifBlank { "1194" }.toInt()
        return Parsed(Protocol.OPENVPN, host, port, host)
    }

    private fun vmessLink(t: String): Parsed? {
        val b64 = t.removePrefix("vmess://").trim().replace('-', '+').replace('_', '/')
        val o = JSONObject(String(Base64.decode(b64, Base64.DEFAULT)))
        val host = o.optString("add")
        if (host.isBlank()) return null
        return Parsed(Protocol.VMESS, host, o.optString("port").toInt(), o.optString("ps").ifBlank { host })
    }

    private fun vlessLink(t: String): Parsed? {
        val u = URI(t)
        val host = u.host ?: return null
        val name = u.rawFragment?.let { URLDecoder.decode(it, "UTF-8") } ?: host
        val reality = (u.rawQuery ?: "").contains("security=reality")
        return Parsed(if (reality) Protocol.XRAY else Protocol.VLESS, host, if (u.port > 0) u.port else 443, name)
    }

    private fun json(t: String): Parsed? {
        val o = JSONObject(t)
        val out = o.optJSONArray("outbounds")?.optJSONObject(0) ?: return null
        val proto = out.optString("protocol")
        val st = out.optJSONObject("settings")
        val vnext = st?.optJSONArray("vnext")?.optJSONObject(0)
        val host = vnext?.optString("address") ?: st?.optString("address") ?: return null
        val port = vnext?.optInt("port") ?: st?.optInt("port") ?: 443
        val reality = out.optJSONObject("streamSettings")?.optString("security") == "reality"
        val p = when {
            proto == "vmess" -> Protocol.VMESS
            proto == "vless" && reality -> Protocol.XRAY
            proto == "vless" -> Protocol.VLESS
            else -> return null
        }
        return Parsed(p, host, port, o.optString("remarks").ifBlank { host })
    }
}
