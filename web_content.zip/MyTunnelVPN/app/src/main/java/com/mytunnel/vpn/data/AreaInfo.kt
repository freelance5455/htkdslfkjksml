package com.mytunnel.vpn.data

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale

data class AreaReport(
    val time: Long, val place: String, val carrier: String, val type: String,
    val downKbps: Int, val upKbps: Int, val pingMs: Int, val lossPct: Int, val score: Int, val quality: String
) {
    /** History me save karne ki ek line. */
    fun line() = listOf(time, place.replace("|", " "), carrier.replace("|", " "), type, score, pingMs).joinToString("|")
}

data class AreaState(val running: Boolean = false, val report: AreaReport? = null)

/** Mojooda jagah par network service ka maap: ping, packet loss, bandwidth, SIM operator, (optional) location. */
object AreaInfo {
    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    suspend fun measure(ctx: Context, withLocation: Boolean): AreaReport = withContext(Dispatchers.IO) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val type = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other"
        }
        val carrier = runCatching {
            (ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).networkOperatorName
        }.getOrDefault("").ifBlank { "Unknown" }

        val times = ArrayList<Int>()
        var fail = 0
        for (host in listOf("1.1.1.1", "8.8.8.8", "9.9.9.9")) {
            repeat(2) {
                val t = System.nanoTime()
                val ok = runCatching { Socket().use { it.connect(InetSocketAddress(host, 443), 2500) } }.isSuccess
                if (ok) times.add(((System.nanoTime() - t) / 1_000_000).toInt()) else fail++
            }
        }
        val total = times.size + fail
        val ping = if (times.isEmpty()) 0 else times.average().toInt()
        val loss = if (total == 0) 100 else fail * 100 / total

        var place = ""
        if (withLocation) runCatching {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getProviders(true).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
            if (loc != null) {
                place = runCatching {
                    Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
                        ?.let { listOfNotNull(it.subLocality ?: it.locality, it.adminArea).joinToString(", ") } ?: ""
                }.getOrDefault("")
                if (place.isBlank()) place = "%.3f, %.3f".format(loc.latitude, loc.longitude)
            }
        }
        if (place.isBlank()) place = if (withLocation) "Location nahi mili" else "Location off"

        val score = if (times.isEmpty()) 0 else (100 - ping / 4 - loss * 2).coerceIn(0, 100)
        val quality = when {
            times.isEmpty() -> "Offline"
            score >= 75 -> "Excellent"
            score >= 50 -> "Good"
            score >= 25 -> "Weak"
            else -> "Poor"
        }
        AreaReport(
            System.currentTimeMillis(), place, carrier, type,
            caps?.linkDownstreamBandwidthKbps ?: 0, caps?.linkUpstreamBandwidthKbps ?: 0, ping, loss, score, quality
        )
    }
}
