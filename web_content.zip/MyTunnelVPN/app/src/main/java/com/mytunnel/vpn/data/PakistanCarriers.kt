package com.mytunnel.vpn.data

import android.content.Context
import android.telephony.TelephonyManager

/**
 * Pakistan ki har SIM (Jazz, Zong, Telenor, Ufone, SCOM) ke liye alag server profile.
 * Har profile alag port/protocol try karta hai, kyunke har network par VPN traffic alag tarah block/slow hota hai.
 */
object PakistanCarriers {
    data class Carrier(val key: String, val label: String, val ports: List<Int>, val keywords: List<String>)

    val all = listOf(
        Carrier("jazz", "Jazz / Warid", listOf(443, 80, 8080, 53), listOf("jazz", "mobilink", "warid")),
        Carrier("zong", "Zong", listOf(443, 8443, 80, 53), listOf("zong", "cmpak")),
        Carrier("telenor", "Telenor", listOf(443, 80, 8080, 1194), listOf("telenor")),
        Carrier("ufone", "Ufone", listOf(443, 80, 53, 8080), listOf("ufone", "pta")),
        Carrier("scom", "SCOM / Onic", listOf(443, 80, 8080, 53), listOf("scom", "onic"))
    )

    /** Mojooda SIM ka operator naam (permission ke baghair) -> Carrier, na mile to null. */
    fun detect(ctx: Context): Carrier? {
        val name = runCatching {
            (ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).networkOperatorName.lowercase()
        }.getOrDefault("")
        return all.firstOrNull { c -> c.keywords.any { name.contains(it) } }
    }

    val servers: List<ServerEntity> by lazy {
        all.mapIndexed { i, c ->
            ServerEntity(
                id = "pk-" + c.key, name = "Karachi • " + c.label, country = "Pakistan", countryCode = "PK",
                host = "pk-" + c.key + "." + Countries.SERVER_DOMAIN, port = c.ports.first(),
                protocol = Protocol.WIREGUARD.name, zone = Zone.FREE.name,
                load = 20 + i * 5, ping = 25 + i * 4, config = ""
            )
        }
    }
}
