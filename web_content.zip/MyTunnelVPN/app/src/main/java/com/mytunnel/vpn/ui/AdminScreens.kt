package com.mytunnel.vpn.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.mytunnel.vpn.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

// Pre-filled so the hidden login screen already has your credentials in it — just tap "Login".
// Keep these in sync with the server's ADMIN_USER / ADMIN_PASSWORD. Change any time you rotate the password.
private const val DEFAULT_ADMIN_USER = "admin_xal7c8kn6ymc"
private const val DEFAULT_ADMIN_PASS = "wQ=HAgcHBTj1bdTAd="

private const val PREFS = "staff_session"
private const val KEY_TOKEN = "token"
private const val KEY_ROLE = "role"
private const val KEY_USER = "user"

private fun savedToken(ctx: Context): Triple<String?, String?, String?> {
    val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    return Triple(p.getString(KEY_TOKEN, null), p.getString(KEY_ROLE, null), p.getString(KEY_USER, null))
}
private fun saveSession(ctx: Context, token: String, role: String, user: String) {
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_TOKEN, token).putString(KEY_ROLE, role).putString(KEY_USER, user).apply()
}
private fun clearSession(ctx: Context) {
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
}

private fun httpPost(urlStr: String, path: String, bodyJson: JSONObject, token: String? = null): Pair<Int, String> {
    val conn = (URL(urlStr.trimEnd('/') + path).openConnection() as HttpURLConnection)
    conn.requestMethod = "POST"
    conn.doOutput = true
    conn.connectTimeout = 10000
    conn.readTimeout = 10000
    conn.setRequestProperty("Content-Type", "application/json")
    if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
    OutputStreamWriter(conn.outputStream).use { it.write(bodyJson.toString()) }
    val code = conn.responseCode
    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
    val text = stream?.bufferedReader()?.readText() ?: ""
    return code to text
}

private fun httpGet(urlStr: String, path: String, token: String): Pair<Int, String> {
    val conn = (URL(urlStr.trimEnd('/') + path).openConnection() as HttpURLConnection)
    conn.requestMethod = "GET"
    conn.connectTimeout = 10000
    conn.readTimeout = 10000
    conn.setRequestProperty("Authorization", "Bearer $token")
    val code = conn.responseCode
    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
    val text = stream?.bufferedReader()?.readText() ?: ""
    return code to text
}

/** Hidden staff/admin login — reached only via the 5-tap secret on the splash screen. */
@Composable
fun AdminLoginScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var user by remember { mutableStateOf(DEFAULT_ADMIN_USER) }
    var pass by remember { mutableStateOf(DEFAULT_ADMIN_PASS) }
    var remember by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var session by remember { mutableStateOf(savedToken(ctx)) }
    val apiUrl = BuildConfig.STAFF_API_URL

    Scaffold(topBar = {
        TopAppBar(title = { Text("Staff / Admin") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
        })
    }) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(20.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (apiUrl.isBlank()) {
                Icon(Icons.Filled.CloudOff, null, Modifier.size(48.dp))
                Spacer(Modifier.height(12.dp))
                Text(
                    "Server configure nahi hai. app/build.gradle.kts mein STAFF_API_URL set karein (apna backend ka URL) aur dubara build karein.",
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                return@Column
            }

            if (session.first != null) {
                // already logged in on this device
                Icon(Icons.Filled.AdminPanelSettings, null, Modifier.size(48.dp))
                Spacer(Modifier.height(8.dp))
                Text("Logged in as ${session.third} (${session.second})", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(20.dp))
                AdminOverview(apiUrl, session.first!!)
                Spacer(Modifier.height(20.dp))
                OutlinedButton(onClick = { clearSession(ctx); session = Triple(null, null, null) }) { Text("Logout") }
                return@Column
            }

            Icon(Icons.Filled.Lock, null, Modifier.size(48.dp))
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(value = user, onValueChange = { user = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = pass, onValueChange = { pass = it }, label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = remember, onCheckedChange = { remember = it })
                Text("Is device par mujhe yaad rakho (dobara login na mangay)")
            }
            error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    error = null; loading = true
                    scope.launch {
                        val (code, text) = withContext(Dispatchers.IO) {
                            try {
                                httpPost(apiUrl, "/api/staff/login", JSONObject().put("user", user.trim()).put("pass", pass))
                            } catch (e: Exception) { -1 to (e.message ?: "network error") }
                        }
                        loading = false
                        if (code == 200) {
                            val j = JSONObject(text)
                            val token = j.getString("token"); val role = j.getString("role")
                            if (remember) saveSession(ctx, token, role, user.trim())
                            session = Triple(token, role, user.trim())
                        } else {
                            error = try { JSONObject(text).optString("error", "login nahi ho saka") } catch (e: Exception) { "login nahi ho saka ($code)" }
                        }
                    }
                },
                enabled = !loading && user.isNotBlank() && pass.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (loading) "..." else "Login") }
        }
    }
}

@Composable
private fun AdminOverview(apiUrl: String, token: String) {
    var text by remember { mutableStateOf("Loading...") }
    LaunchedEffect(Unit) {
        val (code, body) = withContext(Dispatchers.IO) {
            try { httpGet(apiUrl, "/api/staff/overview", token) } catch (e: Exception) { -1 to (e.message ?: "error") }
        }
        text = if (code == 200) {
            val j = JSONObject(body)
            "Users: ${j.optInt("users")}\nActive (24h): ${j.optInt("active24h")}\nTotal points: ${j.optInt("totalPoints")}"
        } else "Overview load nahi hui ($code)"
    }
    Card(Modifier.fillMaxWidth()) { Text(text, Modifier.padding(16.dp)) }
}
