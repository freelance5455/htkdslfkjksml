package com.mytunnel.vpn.util

import android.content.Context
import android.os.Build
import android.telephony.TelephonyManager

/**
 * Device ka naam aur SIM/carrier ka naam — phone NUMBER kabhi nahi padha jata,
 * na hi is file mein aisi koi dangerous permission (READ_PHONE_STATE) ki zaroorat hai.
 */
object DeviceInfo {
    fun deviceName(): String = "${Build.MANUFACTURER} ${Build.MODEL}".trim()

    /** SIM/network ka naam, jaise "Jazz", "Telenor" — sirf naam, number nahi. Agar SIM na ho to "No SIM". */
    fun carrierName(ctx: Context): String = runCatching {
        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val name = tm?.simOperatorName?.takeIf { it.isNotBlank() }
            ?: tm?.networkOperatorName?.takeIf { it.isNotBlank() }
        name ?: "No SIM"
    }.getOrDefault("Nahi pata")
}
