package com.mytunnel.vpn.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mytunnel.vpn.viewmodel.ChatViewModel
import com.mytunnel.vpn.viewmodel.MainViewModel

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun AppRoot(vm: MainViewModel, onToggle: () -> Unit, onBuy: (String) -> Unit, onRestore: () -> Unit) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Tab("home", "Home", Icons.Filled.Home), Tab("servers", "Servers", Icons.Filled.Dns),
        Tab("stats", "Stats", Icons.Filled.BarChart), Tab("rewards", "Rewards", Icons.Filled.EmojiEvents),
        Tab("help", "AI Help", Icons.Filled.SmartToy),
        Tab("settings", "Settings", Icons.Filled.Settings)
    )
    val chatVm: ChatViewModel = viewModel()

    AppBackground {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                if (tabs.any { it.route == route }) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)) {
                        tabs.forEach { t ->
                            NavigationBarItem(
                                selected = route == t.route,
                                onClick = {
                                    nav.navigate(t.route) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }
                                },
                                icon = { Icon(t.icon, null) }, label = { Text(t.label, maxLines = 1) }, alwaysShowLabel = false
                            )
                        }
                    }
                }
            }
        ) { pad ->
            NavHost(nav, startDestination = "splash", modifier = Modifier.padding(pad)) {
                composable("splash") {
                    SplashScreen(
                        onAdminTrigger = { nav.navigate("admin-login") { popUpTo("splash") { inclusive = true } } },
                        onDone = {
                            val done = vm.prefsSnapshot().onboarded
                            nav.navigate(if (done) "home" else "onboarding") { popUpTo("splash") { inclusive = true } }
                        }
                    )
                }
                composable("admin-login") {
                    AdminLoginScreen(onBack = { nav.navigate("home") { popUpTo("admin-login") { inclusive = true } } })
                }
                composable("onboarding") {
                    OnboardingScreen {
                        vm.finishOnboarding()
                        nav.navigate("home") { popUpTo("onboarding") { inclusive = true } }
                    }
                }
                composable("home") { HomeScreen(vm, onToggle, { nav.navigate("servers") }, { nav.navigate("premium") }) }
                composable("servers") { ServersScreen(vm) { nav.navigate("premium") } }
                composable("stats") { StatsScreen(vm) }
                composable("rewards") { RewardsScreen(vm) }
                composable("help") { ChatScreen(chatVm) }
                composable("settings") { SettingsScreen(vm) { nav.navigate("premium") } }
                composable("premium") { PremiumScreen(vm, onBuy, onRestore) { nav.popBackStack() } }
            }
        }
    }
}
