package com.mytunnel.vpn.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mytunnel.vpn.billing.BillingManager
import com.mytunnel.vpn.data.Protocol
import com.mytunnel.vpn.data.ServerEntity
import com.mytunnel.vpn.data.canUse
import com.mytunnel.vpn.util.flag
import com.mytunnel.vpn.viewmodel.MainViewModel

@Composable
fun ServersScreen(vm: MainViewModel, onPremium: () -> Unit) {
    val all by vm.servers.collectAsStateWithLifecycle()
    val set by vm.settings.collectAsStateWithLifecycle()
    val sel by vm.selected.collectAsStateWithLifecycle()
    val q by vm.query.collectAsStateWithLifecycle()
    var zone by remember { mutableStateOf("ALL") }
    var paste by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importUri) }

    val zones = listOf("ALL" to "All", "FAV" to "★", "FREE" to "Free", "PREMIUM" to "Premium", "VIP" to "VIP", "CUSTOM" to "Custom")
    val list = all.filter {
        (zone == "ALL" || (zone == "FAV" && it.favorite) || it.zone == zone) &&
            (q.isBlank() || it.name.contains(q, true) || it.country.contains(q, true))
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Servers", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = vm::refreshPings) { Icon(Icons.Filled.Refresh, null) }
            FilledTonalButton(onClick = vm::randomServer) { Icon(Icons.Filled.Shuffle, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Random") }
        }
        OutlinedTextField(
            value = q, onValueChange = { vm.query.value = it }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            leadingIcon = { Icon(Icons.Filled.Search, null) }, placeholder = { Text("Search country or city") },
            shape = RoundedCornerShape(16.dp)
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            zones.forEach { (k, label) -> FilterChip(selected = zone == k, onClick = { zone = k }, label = { Text(label) }) }
        }
        if (zone == "CUSTOM") {
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(arrayOf("*/*")) }) { Icon(Icons.Filled.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Import file") }
                OutlinedButton(onClick = { paste = true }) { Text("Paste config / link") }
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(list, key = { it.id }) { s ->
                ServerItem(s, selected = sel?.id == s.id, allowed = canUse(s, set.tier),
                    onClick = { if (canUse(s, set.tier)) vm.select(s) else onPremium() },
                    onFav = { vm.toggleFavorite(s) }, onDelete = { vm.deleteCustom(s) })
            }
        }
    }

    if (paste) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { paste = false },
            title = { Text("Paste config") },
            text = { OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().heightIn(min = 160.dp), placeholder = { Text("vmess://… vless://… ya poori config") }) },
            confirmButton = { TextButton(onClick = { vm.importConfig(text); paste = false }) { Text("Import") } },
            dismissButton = { TextButton(onClick = { paste = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ServerItem(s: ServerEntity, selected: Boolean, allowed: Boolean, onClick: () -> Unit, onFav: () -> Unit, onDelete: () -> Unit) {
    val mod = Modifier.fillMaxWidth().let {
        if (selected) it.border(2.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(24.dp)) else it
    }
    GlassCard(mod, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(flag(s.countryCode), fontSize = 30.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.name, fontWeight = FontWeight.Bold)
                Text("${s.country} • ${Protocol.valueOf(s.protocol).label}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (s.zone != "CUSTOM") {
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { s.load / 100f }, modifier = Modifier.fillMaxWidth(0.7f),
                        color = when { s.load < 40 -> Color(0xFF00E0C6); s.load < 70 -> Color(0xFFFFB84D); else -> Color(0xFFFF5C7A) }
                    )
                    Text("Load ${s.load}%", style = MaterialTheme.typography.labelSmall)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                if (s.zone != "CUSTOM") Text("${s.ping} ms", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.secondary)
                Row {
                    if (!allowed) Icon(Icons.Filled.Lock, null, Modifier.size(20.dp).align(Alignment.CenterVertically), tint = MaterialTheme.colorScheme.tertiary)
                    if (s.zone == "CUSTOM") IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, null) }
                    IconButton(onClick = onFav) {
                        Icon(if (s.favorite) Icons.Filled.Star else Icons.Filled.StarBorder, null, tint = MaterialTheme.colorScheme.tertiary)
                    }
                }
            }
        }
    }
}

@Composable
fun PremiumScreen(vm: MainViewModel, onBuy: (String) -> Unit, onRestore: () -> Unit, onBack: () -> Unit) {
    val set by vm.settings.collectAsStateWithLifecycle()
    val rows = listOf(
        listOf("Servers", "3", "All", "All + exclusive"),
        listOf("Speed", "Limited", "High", "Max"),
        listOf("Ads", "Yes", "No", "No"),
        listOf("VIP servers", "—", "—", "✓"),
        listOf("Custom configs", "✓", "✓", "✓"),
        listOf("Support", "Standard", "Priority", "Priority")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.Close, null) }
            Text("Packages", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Icon(Icons.Filled.WorkspacePremium, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.tertiary)
        Text("Current plan: ${set.tier}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row { Spacer(Modifier.weight(1.3f)); listOf("Free", "Premium", "VIP").forEach { Text(it, Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) } }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            rows.forEach { r ->
                Row(Modifier.padding(vertical = 6.dp)) {
                    Text(r[0], Modifier.weight(1.3f))
                    r.drop(1).forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onBuy(BillingManager.PREMIUM_ID) }, Modifier.fillMaxWidth().height(54.dp)) { Text("Get Premium") }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { onBuy(BillingManager.VIP_ID) }, Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
        ) { Text("Get VIP", color = Color.Black) }
        TextButton(onClick = onRestore) { Text("Restore purchases") }
        Text("Price Google Play checkout par dikhayi jaati hai. Kabhi bhi cancel kar sakte hain.", style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (com.mytunnel.vpn.BuildConfig.DEBUG) {
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = { vm.setTier(if (set.tier == "VIP") "FREE" else "VIP") }) { Text("DEBUG: toggle VIP") }
        }
    }
}
