package com.mytunnel.vpn.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mytunnel.vpn.vpn.Status

@Composable
fun isDark() = MaterialTheme.colorScheme.background.luminance() < 0.5f

/** Full-screen gradient background. */
@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val brush = if (isDark()) Brush.verticalGradient(listOf(Color(0xFF0B0F1A), Color(0xFF151040), Color(0xFF0B0F1A)))
    else Brush.verticalGradient(listOf(Color(0xFFF4F6FF), Color(0xFFE9E4FF)))
    Box(Modifier.fillMaxSize().background(brush), content = content)
}

/** Glassmorphism card: translucent fill + soft light border. */
@Composable
fun GlassCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val dark = isDark()
    val shape = RoundedCornerShape(24.dp)
    var m = modifier
        .clip(shape)
        .background(if (dark) Color.White.copy(alpha = 0.07f) else Color.White.copy(alpha = 0.75f))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = if (dark) 0.25f else 0.9f), Color.White.copy(alpha = 0.03f))), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

/** Big circular Connect / Disconnect button with pulse animation. */
@Composable
fun ConnectButton(status: Status, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "pulse")
    val pulse by inf.animateFloat(
        initialValue = 1f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    val base = MaterialTheme.colorScheme.primary
    val color by animateColorAsState(
        when (status) {
            Status.CONNECTED -> Color(0xFF00E0C6)
            Status.CONNECTING -> Color(0xFFFFB84D)
            Status.ERROR -> Color(0xFFFF5C7A)
            else -> base
        }, label = "c"
    )
    val ring = if (status == Status.CONNECTED || status == Status.CONNECTING) pulse else 1f
    Box(Modifier.size(230.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(215.dp).scale(ring).clip(CircleShape).background(color.copy(alpha = 0.14f)))
        Box(Modifier.size(185.dp).clip(CircleShape).background(color.copy(alpha = 0.22f)))
        Box(
            Modifier.size(155.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(color, color.copy(alpha = 0.65f))))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.PowerSettingsNew, null, tint = Color.White, modifier = Modifier.size(52.dp))
                Text(
                    when (status) {
                        Status.CONNECTED -> "DISCONNECT"; Status.CONNECTING -> "CONNECTING"; else -> "CONNECT"
                    }, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

/** Real-time speed graph (values in KB/s). */
@Composable
fun SpeedGraph(values: List<Float>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val max = (values.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val dx = size.width / (values.size - 1)
        val line = Path()
        values.forEachIndexed { i, v ->
            val x = i * dx
            val y = size.height - (v / max) * size.height * 0.9f
            if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
        }
        val fill = Path().apply { addPath(line); lineTo(size.width, size.height); lineTo(0f, size.height); close() }
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(line, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
        drawLine(color.copy(alpha = 0.25f), Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx())
    }
}
