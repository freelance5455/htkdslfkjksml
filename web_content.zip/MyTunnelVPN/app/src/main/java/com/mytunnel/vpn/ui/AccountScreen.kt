package com.mytunnel.vpn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mytunnel.vpn.util.DeviceInfo
import com.mytunnel.vpn.viewmodel.MainViewModel

/**
 * Pehli dafa app khulne par (onboarding ke baad) dikhta hai — koi password/typing nahi,
 * sirf "Guest" ya "Google" chunein. Yeh asal "login" nahi, sirf ek tap se shuru hona hai.
 */
@Composable
fun AccountScreen(vm: MainViewModel, onGoogleClick: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(90.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(48.dp)) }
        Spacer(Modifier.height(16.dp))
        Text("Khush aamdeed", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            "Shuru karne ke liye ek tareeqa chunein — kuch type karne ki zaroorat nahi.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
        )

        Button(onClick = { vm.loginGuest(); onDone() }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.PersonOutline, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Guest ke tor par jaari rakhein  (+100 points)")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onGoogleClick, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.AccountCircle, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Google se sign in karein")
        }

        Spacer(Modifier.height(28.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("Is device ki maloomat", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.PhoneAndroid, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp)); Text(DeviceInfo.deviceName())
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.SimCard, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp)); Text(DeviceInfo.carrierName(ctx))
                }
            }
        }
    }
}

/** Settings/Profile mein dikhane ke liye chhota card — login ke baad bhi apni maloomat dekh sakein. */
@Composable
fun ProfileCard(vm: MainViewModel) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    if (s.accountType.isBlank()) return
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (s.accountType == "GOOGLE") Icons.Filled.AccountCircle else Icons.Filled.PersonOutline, null)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.displayName.ifBlank { "Guest" }, fontWeight = FontWeight.Bold)
                    if (s.email.isNotBlank()) Text(s.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                AssistChip(onClick = {}, label = { Text("${s.points} pts") })
            }
            Spacer(Modifier.height(8.dp))
            Text("Device: ${DeviceInfo.deviceName()}", style = MaterialTheme.typography.bodySmall)
            Text("SIM: ${DeviceInfo.carrierName(ctx)}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { vm.logoutAccount() }) { Text("Sign out") }
        }
    }
}
