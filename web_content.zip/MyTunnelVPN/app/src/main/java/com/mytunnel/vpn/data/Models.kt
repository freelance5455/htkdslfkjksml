package com.mytunnel.vpn.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

enum class Protocol(val label: String) {
    WIREGUARD("WireGuard"), OPENVPN("OpenVPN"),
    VMESS("V2Ray VMess"), VLESS("V2Ray VLESS"), XRAY("Xray")
}

/** Zones: FREE (ads, few servers), PREMIUM, VIP (exclusive), CUSTOM (user imported). */
enum class Zone(val label: String) { FREE("Free"), PREMIUM("Premium"), VIP("VIP"), CUSTOM("Custom") }

@Entity(tableName = "servers")
data class ServerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val country: String,
    val countryCode: String,
    val host: String,
    val port: Int,
    val protocol: String,   // Protocol.name
    val zone: String,       // Zone.name
    val load: Int,          // 0..100 %
    val ping: Int,          // ms (cached)
    val config: String,     // raw .ovpn / wg conf / v2ray json / vmess:// link
    val favorite: Boolean = false
)

@Entity(tableName = "usage")
data class UsageEntity(@PrimaryKey val day: String, val rx: Long, val tx: Long)

@Dao
interface ServerDao {
    @Query("SELECT * FROM servers ORDER BY zone, ping")
    fun all(): Flow<List<ServerEntity>>
    @Query("SELECT * FROM servers WHERE id = :id")
    suspend fun get(id: String): ServerEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(s: ServerEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(l: List<ServerEntity>)
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMissing(l: List<ServerEntity>)
    @Query("UPDATE servers SET favorite = :f WHERE id = :id")
    suspend fun setFavorite(id: String, f: Boolean)
    @Query("UPDATE servers SET ping = :p WHERE id = :id")
    suspend fun setPing(id: String, p: Int)
    @Query("DELETE FROM servers WHERE id = :id AND zone = 'CUSTOM'")
    suspend fun deleteCustom(id: String)
    @Query("SELECT COUNT(*) FROM servers")
    suspend fun count(): Int
}

@Dao
interface UsageDao {
    @Query("SELECT * FROM usage ORDER BY day DESC LIMIT 30")
    fun recent(): Flow<List<UsageEntity>>
    @Query("SELECT * FROM usage WHERE day = :day")
    suspend fun get(day: String): UsageEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(u: UsageEntity)
}

@Database(entities = [ServerEntity::class, UsageEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun servers(): ServerDao
    abstract fun usage(): UsageDao
    companion object {
        fun build(ctx: android.content.Context) =
            Room.databaseBuilder(ctx, AppDatabase::class.java, "mytunnel.db").build()
    }
}

/** Does the user's tier allow this server? */
fun canUse(s: ServerEntity, tier: String): Boolean = when (s.zone) {
    "FREE", "CUSTOM" -> true
    "PREMIUM" -> tier == "PREMIUM" || tier == "VIP"
    "VIP" -> tier == "VIP"
    else -> false
}
