package com.mytunnel.vpn.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mytunnel.vpn.ads.AdBanner
import com.mytunnel.vpn.data.Protocol
import com.mytunnel.vpn.util.*
import com.mytunnel.vpn.viewmodel.MainViewModel
import com.mytunnel.vpn.vpn.Status
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onAdminTrigger: () -> Unit = {}, onDone: () -> Unit = {}) {
    val t = rememberInfiniteTransition(label = "s")
    val sc by t.animateFloat(0.9f, 1.1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "sc")
    // Hidden staff/admin entry: tap the app name 5 times (within ~2.5s of each tap) to open the admin login.
    // Nothing is shown to a normal user who just taps once or twice by accident.
    var tapCount by remember { mutableIntStateOf(0) }
    var lastTap by remember { mutableLongStateOf(0L) }
    var triggered by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(110.dp).scale(sc).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.PowerSettingsNew, null, tint = Color.White, modifier = Modifier.size(56.dp)) }
            Spacer(Modifier.height(20.dp))
            Text(
                "My Tunnel VPN", fontSize = 28.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) {
                    val now = System.currentTimeMillis()
                    tapCount = if (now - lastTap < 2500) tapCount + 1 else 1
                    lastTap = now
                    if (tapCount >= 5 && !triggered) {
                        triggered = true
                        onAdminTrigger()
                    }
                }
            )
            Text("Fast • Secure • Private", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    LaunchedEffect(Unit) {
        delay(1400)
        if (!triggered) onDone()
    }
}

private data class Page(val icon: ImageVector, val title: String, val text: String)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val pages = listOf(
        Page(Icons.Filled.Lock, "Secure Everything", "WireGuard, OpenVPN, V2Ray aur Xray - apni pasand ka protocol chunein."),
        Page(Icons.Filled.Bolt, "Fast Servers", "Server load aur ping dekh kar sab se behtareen server chunein."),
        Page(Icons.Filled.WorkspacePremium, "Free, Premium & VIP", "Free se shuru karein, kabhi bhi Premium ya VIP me upgrade karein.")
    )
    val pager = rememberPagerState(pageCount = { pages.size })
    var page by remember { mutableIntStateOf(0) }
    LaunchedEffect(pager.currentPage) { page = pager.currentPage }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        HorizontalPager(pager, Modifier.weight(1f)) { i ->
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(pages[i].icon, null, Modifier.size(110.dp), tint = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(24.dp))
                Text(pages[i].title, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(pages[i].text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            pages.indices.forEach { i ->
                Box(Modifier.size(if (i == page) 22.dp else 8.dp, 8.dp).clip(CircleShape)
                    .background(if (i == page) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant))
            }
        }
        Spacer(Modifier.height(20.dp))
        val scope = rememberCoroutineScope()
        Button(
            onClick = { if (page == pages.lastIndex) onDone() else scope.launch { pager.animateScrollToPage(page + 1) } },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text(if (page == pages.lastIndex) "Get Started" else "Next") }
    }
}

@Composable
fun HomeScreen(vm: MainViewModel, onToggle: () -> Unit, onServers: () -> Unit, onPremium: () -> Unit) {
    val vpn by vm.vpn.collectAsStateWithLifecycle()
    val sel by vm.selected.collectAsStateWithLifecycle()
    val set by vm.settings.collectAsStateWithLifecycle()
    val hist by vm.history.collectAsStateWithLifecycle()
    val ip by vm.ip.collectAsStateWithLifecycle()
    val online by vm.online.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("My Tunnel", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (vpn.status == Status.CONNECTED) {
                // Fully-filled, high-visibility badge whenever the VPN tunnel is actually up.
                AssistChip(
                    onClick = {}, label = { Text("VPN ON", fontWeight = FontWeight.Bold) },
                    leadingIcon = { Icon(Icons.Filled.Shield, null, Modifier.size(18.dp), tint = Color.White) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = Color(0xFF22C55E), labelColor = Color.White
                    ),
                    border = null
                )
                Spacer(Modifier.width(8.dp))
            }
            AssistChip(
                onClick = {}, label = { Text(if (online) "Online" else "Offline") },
                leadingIcon = { Icon(if (online) Icons.Filled.Wifi else Icons.Filled.WifiOff, null, Modifier.size(18.dp)) }
            )
            Spacer(Modifier.width(8.dp))
            AssistChip(onClick = onPremium, label = { Text(set.tier) }, leadingIcon = { Icon(Icons.Filled.WorkspacePremium, null, Modifier.size(18.dp)) })
        }

        ConnectButton(vpn.status, onToggle)

        Text(
            when (vpn.status) {
                Status.CONNECTED -> "Protected"
                Status.CONNECTING -> vpn.message.ifBlank { "Connecting…" }
                Status.ERROR -> vpn.message.ifBlank { "Connection failed" }
                Status.DISCONNECTED -> "Not connected"
            },
            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
            color = if (vpn.status == Status.ERROR) Color(0xFFFF5C7A) else MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Text(
            if (vpn.status == Status.CONNECTED) fmtDuration(now - vpn.connectedAt) else "00:00:00",
            fontSize = 30.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.secondary
        )
        Spacer(Modifier.height(12.dp))

        // Easy protocol switching
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Protocol.values().forEach { p ->
                FilterChip(selected = sel?.protocol == p.name, onClick = { vm.selectProtocol(p) }, label = { Text(p.label) })
            }
        }
        Spacer(Modifier.height(12.dp))

        GlassCard(Modifier.fillMaxWidth(), onClick = onServers) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(flag(sel?.countryCode ?: ""), fontSize = 34.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(sel?.name ?: "Select a server", fontWeight = FontWeight.Bold)
                    Text(
                        sel?.let { "${Protocol.valueOf(it.protocol).label} • ${it.ping} ms • load ${it.load}%" } ?: "Tap to choose",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
            }
        }
        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassCard(Modifier.weight(1f)) {
                Text("↓ Download", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(fmtSpeed(vpn.downBps), fontWeight = FontWeight.Bold)
            }
            GlassCard(Modifier.weight(1f)) {
                Text("↑ Upload", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(fmtSpeed(vpn.upBps), fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.dp))

        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Current IP", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(ip, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { vm.refreshIp() }) { Icon(Icons.Filled.Refresh, null) }
            }
        }
        Spacer(Modifier.height(12.dp))

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Live speed", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            SpeedGraph(hist, MaterialTheme.colorScheme.secondary, Modifier.fillMaxWidth().height(90.dp))
        }

        if (set.tier == "FREE") { Spacer(Modifier.height(12.dp)); AdBanner() }
        Spacer(Modifier.height(16.dp))
    }
}
