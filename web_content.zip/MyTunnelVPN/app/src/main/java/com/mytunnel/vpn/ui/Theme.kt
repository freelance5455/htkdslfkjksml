package com.mytunnel.vpn.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF7C5CFF), secondary = Color(0xFF00E0C6), tertiary = Color(0xFFFFB84D),
    background = Color(0xFF0B0F1A), surface = Color(0xFF141A2B),
    onBackground = Color(0xFFEAF0FF), onSurface = Color(0xFFEAF0FF),
    surfaceVariant = Color(0xFF1C2440), onSurfaceVariant = Color(0xFFA9B4D6)
)
private val LightScheme = lightColorScheme(
    primary = Color(0xFF5B3DF5), secondary = Color(0xFF00A896), tertiary = Color(0xFFE08A00),
    background = Color(0xFFF4F6FF), surface = Color.White,
    onBackground = Color(0xFF10162B), onSurface = Color(0xFF10162B),
    surfaceVariant = Color(0xFFE6EAFB), onSurfaceVariant = Color(0xFF51597A)
)

/** Material 3 theme. Dark is the default; Light is switchable in Settings. */
@Composable
fun MyTunnelTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}
