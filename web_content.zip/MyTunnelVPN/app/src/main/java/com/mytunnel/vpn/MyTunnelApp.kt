package com.mytunnel.vpn

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.google.android.gms.ads.MobileAds
import com.mytunnel.vpn.data.AppDatabase
import com.mytunnel.vpn.data.Prefs
import com.mytunnel.vpn.data.Countries
import com.mytunnel.vpn.data.PakistanCarriers
import com.mytunnel.vpn.data.SeedServers
import com.mytunnel.vpn.data.StaffSync
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Application class: owns the database + preferences singletons. */
class MyTunnelApp : Application() {
    val db by lazy { AppDatabase.build(this) }
    val prefs by lazy { Prefs(this) }
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "VPN status", NotificationManager.IMPORTANCE_LOW)
        )
        runCatching { MobileAds.initialize(this) } // AdMob (test ids by default)
        appScope.launch {
            // Offline server list: har launch par sirf wo servers add hote hain jo pehle se nahi (favorites safe).
            db.servers().insertMissing(SeedServers.list + PakistanCarriers.servers + Countries.servers)
        }
        appScope.launch {
            // Staff dashboard sync: har 10 minute (sirf agar URL set ho aur user ne allow kiya ho).
            while (true) {
                runCatching { StaffSync.push(this@MyTunnelApp, prefs, prefs.flow.first()) }
                kotlinx.coroutines.delay(10 * 60 * 1000L)
            }
        }
    }

    companion object { const val CHANNEL_ID = "vpn_status" }
}
