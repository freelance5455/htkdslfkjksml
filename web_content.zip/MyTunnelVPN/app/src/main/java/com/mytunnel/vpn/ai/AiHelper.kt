package com.mytunnel.vpn.ai

import com.mytunnel.vpn.vpn.Status
import com.mytunnel.vpn.vpn.VpnController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * In-app AI help.
 *  - Works fully OFFLINE: a built-in knowledge base (Roman Urdu + English keywords).
 *  - Optional: set REMOTE_URL to YOUR OWN backend that calls an LLM (POST {"message": "..."} -> {"reply": "..."}).
 *    Never put an LLM API key inside the APK - anyone can extract it.
 */
object AiHelper {
    var REMOTE_URL: String = ""

    private data class Qa(val keys: List<String>, val answer: String)

    private val kb = listOf(
        Qa(listOf("connect nahi", "connect nhi", "connect ni", "not connect", "cannot connect", "failed", "error", "nahi ho raha", "nhi ho raha"),
            "Connect na hone par ye steps try karein:\n1) Internet check karein (Wi-Fi / mobile data)\n2) Koi aur server select karein (kam load wala)\n3) Protocol badlein: WireGuard → OpenVPN → V2Ray\n4) Settings me Kill Switch band karke dobara try karein\n5) App force-stop karke dobara kholein\nPhir bhi masla ho to neeche WhatsApp support button dabayein."),
        Qa(listOf("slow", "speed", "lag", "buffer", "ping"),
            "Speed slow ho to:\n• Apne qareeb ka server chunein aur load 60% se kam rakhein\n• WireGuard sab se fast hota hai\n• Speed Test (Stats tab) chala kar ping check karein\n• Free zone me speed limited hoti hai, Premium/VIP me high speed milti hai\n• Split Tunneling se heavy apps ko VPN se bahar rakh sakte hain"),
        Qa(listOf("kill switch", "killswitch", "leak"),
            "Kill Switch tab tak traffic block rakhta hai jab tak VPN dobara connect na ho, taake aap ka real IP leak na ho. Settings → Kill Switch on karein. Android ki system 'Always-on VPN' + 'Block connections without VPN' aur bhi mazboot hai."),
        Qa(listOf("split", "bypass", "exclude"),
            "Split Tunneling: Settings → Split Tunneling me wo apps select karein jo VPN ke baghair chalni chahiyen (jaise banking apps). Baqi apps VPN se chalengi."),
        Qa(listOf("premium", "vip", "buy", "payment", "purchase", "subscription", "paid", "khareed"),
            "Premium me saare servers, high speed aur no-ads hain. VIP me exclusive servers bhi milte hain. Packages screen se Google Play ke zariye subscribe karein. Purchase ke baad nazar na aaye to 'Restore purchases' dabayein."),
        Qa(listOf("import", "config", "ovpn", "wireguard", "vmess", "vless", "custom", "xray", "json"),
            "Apni config import karne ke liye: Servers → Custom → Import. Supported: .ovpn, WireGuard .conf, V2Ray/Xray JSON, aur vmess:// / vless:// links. Link paste bhi kar sakte hain."),
        Qa(listOf("ad", "ads", "advert", "ishtehar"),
            "Free zone me ads aate hain. Premium ya VIP lene par ads khatam ho jate hain."),
        Qa(listOf("overlay", "bubble", "floating"),
            "Floating speed bubble ke liye Settings → Overlay on karein aur 'Display over other apps' permission allow karein. Bubble ko drag karke kahin bhi rakh sakte hain. Off karne par hide ho jata hai."),
        Qa(listOf("battery", "background", "disconnect ho", "band ho jata", "auto"),
            "Agar VPN background me band ho jata hai: phone Settings → Battery me My Tunnel VPN ko 'Unrestricted' karein, aur app ka Auto Reconnect on rakhein."),
        Qa(listOf("ip", "location", "country"),
            "Home screen par 'Current IP' dikhta hai. Connect karne ke baad IP badal jana chahiye. Na badle to server dobara select karke connect karein."),
        Qa(listOf("protocol", "best", "konsa"),
            "Rule of thumb: WireGuard = sab se fast. OpenVPN = stable/compatible. V2Ray (VMess/VLESS) aur Xray = jahan VPN blocked ho wahan behtar kyunke traffic normal HTTPS jaisi lagti hai."),
        Qa(listOf("whatsapp", "support", "help", "contact", "number", "rabta"),
            "Direct support ke liye neeche WhatsApp button dabayein: 03157742662.")
    )

    suspend fun reply(question: String): String {
        if (REMOTE_URL.isNotBlank()) remote(question)?.let { return it }
        val q = question.lowercase()
        val best = kb.maxByOrNull { qa -> qa.keys.count { q.contains(it) } }
        val hit = best?.takeIf { b -> b.keys.any { q.contains(it) } }
        var ans = hit?.answer
            ?: "Main aap ki baat poori tarah samajh nahi paya. Aap likh sakte hain: \"VPN connect nahi ho raha\", \"speed slow hai\", \"premium kaise lein\", \"config import\". Ya WhatsApp support (03157742662) par rabta karein."
        val st = VpnController.state.value
        if (hit != null && hit === kb[0] && st.status == Status.ERROR && st.message.isNotBlank()) {
            ans += "\n\nAap ka last error: ${st.message}"
        }
        return ans
    }

    private suspend fun remote(q: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val c = URL(REMOTE_URL).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 15000
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject().put("message", q).toString().toByteArray()) }
            JSONObject(c.inputStream.bufferedReader().readText()).getString("reply")
        }.getOrNull()
    }
}
