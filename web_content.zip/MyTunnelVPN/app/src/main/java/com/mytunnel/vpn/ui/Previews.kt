package com.mytunnel.vpn.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.mytunnel.vpn.vpn.Status

/** Android Studio -> open this file -> "Split" / "Design" tab to see the look without running the app. */
@Composable
private fun PreviewBody(dark: Boolean) = MyTunnelTheme(dark) {
    AppBackground {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ConnectButton(Status.CONNECTED) {}
            GlassCard(Modifier.fillMaxWidth()) { Text("🇳🇱 Amsterdam • WireGuard • 95 ms") }
            SpeedGraph(List(30) { (it * 7 % 23).toFloat() }, Color(0xFF00E0C6), Modifier.fillMaxWidth().height(80.dp))
        }
    }
}

@Preview(showBackground = true, heightDp = 640, widthDp = 360) @Composable fun PreviewDark() = PreviewBody(true)
@Preview(showBackground = true, heightDp = 640, widthDp = 360) @Composable fun PreviewLight() = PreviewBody(false)

@Composable
private fun ServerRowPreview(dark: Boolean) = MyTunnelTheme(dark) {
    AppBackground {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("🇵🇰 Karachi • Jazz / Warid" to "30 ms", "🇵🇰 Karachi • Zong" to "29 ms", "🇦🇪 Dubai" to "45 ms", "🇬🇧 London" to "70 ms").forEach { (n, p) ->
                GlassCard(Modifier.fillMaxWidth()) { Text("$n  •  $p") }
            }
        }
    }
}

@Preview(showBackground = true, heightDp = 640, widthDp = 360) @Composable fun PreviewServersDark() = ServerRowPreview(true)
@Preview(showBackground = true, heightDp = 640, widthDp = 360) @Composable fun PreviewServersLight() = ServerRowPreview(false)
