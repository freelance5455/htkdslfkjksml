package com.mytunnel.vpn.vpn

import com.mytunnel.vpn.data.ServerEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

enum class Status { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class VpnState(
    val status: Status = Status.DISCONNECTED,
    val server: ServerEntity? = null,
    val connectedAt: Long = 0L,
    val downBps: Long = 0L,   // bytes / second
    val upBps: Long = 0L,
    val rx: Long = 0L,        // session totals
    val tx: Long = 0L,
    val message: String = ""
)

/** Process-wide VPN state. The service writes, UI / tile / overlay read. */
object VpnController {
    val state = MutableStateFlow(VpnState())
    fun update(block: VpnState.() -> VpnState) = state.update { it.block() }
    fun reset() { state.value = VpnState() }
}
