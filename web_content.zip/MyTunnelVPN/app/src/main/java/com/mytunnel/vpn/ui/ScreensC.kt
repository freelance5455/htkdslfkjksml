package com.mytunnel.vpn.ui

import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Locale
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mytunnel.vpn.data.Prefs
import com.mytunnel.vpn.util.*
import com.mytunnel.vpn.viewmodel.ChatViewModel
import com.mytunnel.vpn.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------ AI chat

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val msgs by vm.messages.collectAsStateWithLifecycle()
    val typing by vm.typing.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val state = rememberLazyListState()

    // ---- Voice: bol kar poochhein + jawab bol kar sunein (toggle) ----
    var speak by remember { mutableStateOf(true) }
    val startCount = remember { msgs.size }
    val tts = remember { arrayOfNulls<TextToSpeech>(1) }
    DisposableEffect(Unit) {
        tts[0] = TextToSpeech(ctx) { status ->
            val t = tts[0]
            if (status == TextToSpeech.SUCCESS && t != null && t.setLanguage(Locale("ur", "PK")) < TextToSpeech.LANG_AVAILABLE) {
                t.setLanguage(Locale.getDefault())
            }
        }
        onDispose { tts[0]?.stop(); tts[0]?.shutdown() }
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val said = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!said.isNullOrBlank()) vm.send(said)
    }
    fun startMic() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Bol kar poochhein")
        runCatching { micLauncher.launch(i) }.onFailure { Toast.makeText(ctx, "Is phone par voice input maujood nahi", Toast.LENGTH_SHORT).show() }
    }
    LaunchedEffect(msgs.size) {
        val last = msgs.lastOrNull()
        if (speak && msgs.size > startCount && last != null && !last.fromUser) tts[0]?.speak(last.text, TextToSpeech.QUEUE_FLUSH, null, "reply")
    }
    LaunchedEffect(msgs.size, typing) { if (msgs.isNotEmpty()) state.animateScrollToItem((msgs.size - 1 + (if (typing) 1 else 0)).coerceAtLeast(0)) }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("AI Help", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { speak = !speak; if (!speak) tts[0]?.stop() }) {
                Icon(if (speak) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff, "Jawab bol kar sunayen")
            }
            FilledTonalButton(onClick = { openWhatsApp(ctx) }) { Icon(Icons.Filled.SupportAgent, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("WhatsApp") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("VPN connect nahi ho raha", "Speed slow hai", "Premium kaise lein?", "Config import kaise karein?").forEach {
                SuggestionChip(onClick = { vm.send(it) }, label = { Text(it) })
            }
        }
        LazyColumn(Modifier.weight(1f).padding(vertical = 8.dp), state = state, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (m.fromUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Text(m.text, Modifier.padding(12.dp), color = if (m.fromUser) androidx.compose.ui.graphics.Color.White else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            if (typing) item { Text("typing…", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f), placeholder = { Text("Apna sawal likhein…") },
                shape = RoundedCornerShape(24.dp), maxLines = 3,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { vm.send(input); input = "" })
            )
            IconButton(onClick = { startMic() }) { Icon(Icons.Filled.Mic, "Bol kar poochhein", tint = MaterialTheme.colorScheme.secondary) }
            IconButton(onClick = { vm.send(input); input = "" }) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = MaterialTheme.colorScheme.primary) }
        }
    }
}

// ------------------------------------------------------------------ Settings

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, onPremium: () -> Unit) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    var split by remember { mutableStateOf(false) }
    var feedback by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        ProfileCard(vm)

        GlassCard(Modifier.fillMaxWidth(), onClick = onPremium) {
            Text("Plan: ${s.tier}", fontWeight = FontWeight.Bold)
            Text("Free vs Premium vs VIP dekhein / upgrade karein", style = MaterialTheme.typography.bodySmall)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("Dark theme", "Light theme ke liye off karein", s.dark) { vm.setBool(Prefs.K.DARK, it) }
            SwitchRow("Kill Switch", "VPN girne par saari traffic block", s.killSwitch) { vm.setBool(Prefs.K.KILL, it) }
            SwitchRow("Auto Reconnect", "Connection toot'ne par khud reconnect", s.autoReconnect) { vm.setBool(Prefs.K.RECONNECT, it) }
            SwitchRow("Auto-start on boot", "Phone on hone par VPN chalu", s.autoStart) { vm.setBool(Prefs.K.AUTOSTART, it) }
            SwitchRow("Staff sync", "Device model, Android/app version aur rewards points staff dashboard ko jate hain. Location ya browsing nahi.", s.staffSync) { vm.setBool(Prefs.K.SYNC, it) }
            SwitchRow("Speed overlay", "Floating bubble (drag kar sakte hain)", s.overlay) { on ->
                if (on && !Settings.canDrawOverlays(ctx)) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                }
                vm.setBool(Prefs.K.OVERLAY, on)
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { split = true }, Modifier.fillMaxWidth()) { Text("Split Tunneling (${s.splitApps.size} apps bypass)") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("System Always-on VPN settings") }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Support", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { openWhatsApp(ctx) }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.SupportAgent, null); Spacer(Modifier.width(8.dp)); Text("WhatsApp Support  $SUPPORT_LOCAL_NUMBER") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { feedback = true }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.Feedback, null); Spacer(Modifier.width(8.dp)); Text("Send feedback") }
        }
        Text("My Tunnel VPN v1.0.0", Modifier.align(Alignment.CenterHorizontally), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    if (feedback) {
        var t by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { feedback = false },
            title = { Text("Feedback") },
            text = { OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth().heightIn(min = 120.dp), placeholder = { Text("Apna feedback likhein") }) },
            confirmButton = { TextButton(onClick = { openWhatsApp(ctx, "Feedback (My Tunnel VPN): $t"); feedback = false }) { Text("Send") } },
            dismissButton = { TextButton(onClick = { feedback = false }) { Text("Cancel") } }
        )
    }
    if (split) SplitDialog(s.splitApps, onSave = { vm.setSplit(it); split = false }, onDismiss = { split = false })
}

private data class AppItem(val pkg: String, val label: String)

@Composable
private fun SplitDialog(current: Set<String>, onSave: (Set<String>) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var chosen by remember { mutableStateOf(current) }
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            pm.getInstalledApplications(0)
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != ctx.packageName }
                .map { AppItem(it.packageName, it.loadLabel(pm).toString()) }
                .sortedBy { it.label.lowercase() }
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Apps jo VPN bypass karengi") },
        text = {
            if (apps == null) CircularProgressIndicator()
            else LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(apps!!) { a ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(a.pkg in chosen, { on -> chosen = if (on) chosen + a.pkg else chosen - a.pkg })
                        Text(a.label)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(chosen) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ------------------------------------------------------------------ Stats + speed test

@Composable
fun StatsScreen(vm: MainViewModel) {
    val st by vm.speedTest.collectAsStateWithLifecycle()
    val usage by vm.usage.collectAsStateWithLifecycle()
    val vpn by vm.vpn.collectAsStateWithLifecycle()
    val maxUse = (usage.maxOfOrNull { it.rx + it.tx } ?: 1L).coerceAtLeast(1L)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Speed Test & Stats", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Metric("Ping", "${st.pingMs} ms"); Metric("Download", "%.1f Mbps".format(st.downMbps)); Metric("Upload", "%.1f Mbps".format(st.upMbps))
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = vm::runSpeedTest, enabled = !st.running, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Speed, null); Spacer(Modifier.width(8.dp)); Text(if (st.running) st.note else "Start speed test")
            }
            if (st.note == "Internet nahi hai") Text(st.note, color = MaterialTheme.colorScheme.error)
        }
        AreaSection(vm)
        GlassCard(Modifier.fillMaxWidth()) {
            Text("This session", fontWeight = FontWeight.Bold)
            Text("↓ ${fmtBytes(vpn.rx)}    ↑ ${fmtBytes(vpn.tx)}")
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Data usage (last 30 days)", fontWeight = FontWeight.Bold)
            if (usage.isEmpty()) Text("Abhi koi data usage nahi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            usage.forEach { u ->
                Column(Modifier.padding(vertical = 4.dp)) {
                    Row { Text(u.day, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall); Text(fmtBytes(u.rx + u.tx), style = MaterialTheme.typography.bodySmall) }
                    LinearProgressIndicator(progress = { (u.rx + u.tx).toFloat() / maxUse }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold)
    }
}
