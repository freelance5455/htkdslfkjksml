package com.mytunnel.vpn.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Daily reward (7-day streak) + daily missions. Sab kuch phone me save hota hai, net ki zaroorat nahi. */
object Rewards {
    data class Mission(val id: String, val title: String, val reward: Int)
    data class Level(val name: String, val minPoints: Int)

    val missions = listOf(
        Mission("connect", "VPN connect karein", 20),
        Mission("speed", "Speed test chalayein", 10),
        Mission("area", "Apne area ka signal check karein", 10),
        Mission("fav", "Ek server favorite karein", 5)
    )
    val streakRewards = listOf(10, 15, 20, 30, 40, 60, 100)
    val levels = listOf(Level("Bronze", 0), Level("Silver", 200), Level("Gold", 500), Level("Platinum", 1000))

    private val fmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    fun today(): String = fmt.format(Date())
    fun yesterday(): String {
        val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, -1); return fmt.format(c.time)
    }
    fun levelFor(points: Int): Level = levels.last { points >= it.minPoints }
    fun nextLevel(points: Int): Level? = levels.firstOrNull { it.minPoints > points }
}
