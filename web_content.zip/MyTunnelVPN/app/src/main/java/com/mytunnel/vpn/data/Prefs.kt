package com.mytunnel.vpn.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("settings")

data class AppSettings(
    val dark: Boolean = true,
    val killSwitch: Boolean = false,
    val autoReconnect: Boolean = true,
    val autoStart: Boolean = false,
    val overlay: Boolean = false,
    val onboarded: Boolean = false,
    val tier: String = "FREE",            // FREE | PREMIUM | VIP
    val splitApps: Set<String> = emptySet(), // apps that BYPASS the VPN
    val lastServerId: String = "",
    val points: Int = 0,
    val streak: Int = 0,
    val lastClaim: String = "",
    val missionDay: String = "",
    val missionsDone: Set<String> = emptySet(),
    val reports: String = "",
    val deviceId: String = "",
    val staffSync: Boolean = true
)

class Prefs(private val ctx: Context) {
    object K {
        val DARK = booleanPreferencesKey("dark")
        val KILL = booleanPreferencesKey("kill")
        val RECONNECT = booleanPreferencesKey("reconnect")
        val AUTOSTART = booleanPreferencesKey("autostart")
        val OVERLAY = booleanPreferencesKey("overlay")
        val ONBOARDED = booleanPreferencesKey("onboarded")
        val TIER = stringPreferencesKey("tier")
        val SPLIT = stringSetPreferencesKey("split")
        val LAST = stringPreferencesKey("last")
        val POINTS = intPreferencesKey("points")
        val STREAK = intPreferencesKey("streak")
        val LAST_CLAIM = stringPreferencesKey("last_claim")
        val MDAY = stringPreferencesKey("mday")
        val MDONE = stringSetPreferencesKey("mdone")
        val REPORTS = stringPreferencesKey("reports")
        val DEVICE_ID = stringPreferencesKey("device_id")
        val SYNC = booleanPreferencesKey("staff_sync")
    }

    val flow: Flow<AppSettings> = ctx.store.data.map {
        AppSettings(
            dark = it[K.DARK] ?: true,
            killSwitch = it[K.KILL] ?: false,
            autoReconnect = it[K.RECONNECT] ?: true,
            autoStart = it[K.AUTOSTART] ?: false,
            overlay = it[K.OVERLAY] ?: false,
            onboarded = it[K.ONBOARDED] ?: false,
            tier = it[K.TIER] ?: "FREE",
            splitApps = it[K.SPLIT] ?: emptySet(),
            lastServerId = it[K.LAST] ?: "",
            points = it[K.POINTS] ?: 0,
            streak = it[K.STREAK] ?: 0,
            lastClaim = it[K.LAST_CLAIM] ?: "",
            missionDay = it[K.MDAY] ?: "",
            missionsDone = it[K.MDONE] ?: emptySet(),
            reports = it[K.REPORTS] ?: "",
            deviceId = it[K.DEVICE_ID] ?: "",
            staffSync = it[K.SYNC] ?: true
        )
    }

    suspend fun update(block: MutablePreferences.() -> Unit) {
        ctx.store.edit { it.block() }
    }
}
