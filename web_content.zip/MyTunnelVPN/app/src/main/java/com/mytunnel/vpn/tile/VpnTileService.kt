package com.mytunnel.vpn.tile

import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat
import com.mytunnel.vpn.MainActivity
import com.mytunnel.vpn.vpn.MyTunnelVpnService
import com.mytunnel.vpn.vpn.Status
import com.mytunnel.vpn.vpn.VpnController
import com.mytunnel.vpn.vpn.VpnState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect

/** Quick Settings tile: tap to connect (last server) / disconnect. */
class VpnTileService : TileService() {
    private var job: Job? = null

    override fun onStartListening() {
        job = CoroutineScope(Dispatchers.Main).launch { VpnController.state.collect { render(it) } }
    }
    override fun onStopListening() { job?.cancel() }

    private fun render(s: VpnState) {
        qsTile?.apply {
            state = if (s.status == Status.CONNECTED) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "My Tunnel"
            if (Build.VERSION.SDK_INT >= 29) subtitle = when (s.status) {
                Status.CONNECTED -> "Connected"; Status.CONNECTING -> "Connecting…"; else -> "Off"
            }
            updateTile()
        }
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        val st = VpnController.state.value.status
        if (st == Status.CONNECTED || st == Status.CONNECTING) {
            startService(MyTunnelVpnService.disconnectIntent(this)); return
        }
        if (VpnService.prepare(this) != null) {
            // First time: VPN permission dialog needs an Activity.
            startActivityAndCollapse(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            ContextCompat.startForegroundService(this, MyTunnelVpnService.connectIntent(this, null))
        }
    }
}
