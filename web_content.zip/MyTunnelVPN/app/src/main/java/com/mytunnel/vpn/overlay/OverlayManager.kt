package com.mytunnel.vpn.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.mytunnel.vpn.util.fmtSpeed

/** Floating, draggable speed bubble (needs "Display over other apps" permission). */
class OverlayManager(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: TextView? = null

    fun show() {
        if (view != null || !Settings.canDrawOverlays(ctx)) return
        val tv = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 12f; setPadding(32, 18, 32, 18)
            background = GradientDrawable().apply {
                cornerRadius = 60f; setColor(0xCC141A2B.toInt()); setStroke(2, 0xFF7C5CFF.toInt())
            }
            text = "↓ 0 B/s\n↑ 0 B/s"
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 300 }

        tv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                return true
            }
        })
        runCatching { wm.addView(tv, lp); view = tv }
    }

    fun update(down: Long, up: Long) { view?.text = "↓ ${fmtSpeed(down)}\n↑ ${fmtSpeed(up)}" }

    fun hide() { view?.let { runCatching { wm.removeView(it) } }; view = null }
}
