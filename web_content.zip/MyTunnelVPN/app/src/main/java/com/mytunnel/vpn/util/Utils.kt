package com.mytunnel.vpn.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.text.DecimalFormat

const val SUPPORT_LOCAL_NUMBER = "03157742662"
const val SUPPORT_INTL_NUMBER = "923157742662" // Pakistan +92, leading 0 dropped

/** Country code ("PK") -> flag emoji. */
fun flag(cc: String): String {
    if (cc.length != 2 || !cc.all { it.isLetter() }) return "🌐"
    val a = Character.toChars(0x1F1E6 + (cc[0].uppercaseChar() - 'A'))
    val b = Character.toChars(0x1F1E6 + (cc[1].uppercaseChar() - 'A'))
    return String(a) + String(b)
}

fun fmtBytes(b: Long): String {
    val d = DecimalFormat("0.##")
    return when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> d.format(b / 1024.0) + " KB"
        b < 1024L * 1024 * 1024 -> d.format(b / 1048576.0) + " MB"
        else -> d.format(b / 1073741824.0) + " GB"
    }
}

fun fmtSpeed(bytesPerSec: Long) = fmtBytes(bytesPerSec) + "/s"

fun fmtDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

/** Opens a WhatsApp chat with the support number (optionally pre-filled text). */
fun openWhatsApp(ctx: Context, text: String = "Salam, mujhe My Tunnel VPN me help chahiye.") {
    val uri = Uri.parse("https://wa.me/$SUPPORT_INTL_NUMBER?text=${Uri.encode(text)}")
    ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
