package com.mytunnel.vpn.data

/**
 * Demo / placeholder servers shown on first launch (works offline).
 * IMPORTANT: replace host + config with YOUR real servers (or load them from your panel API).
 * Servers with an empty `config` only "connect" in debug DEMO_MODE.
 */
object SeedServers {
    private fun s(id: String, name: String, c: String, cc: String, p: Protocol, z: Zone, load: Int, ping: Int) =
        ServerEntity(id, name, c, cc, "${cc.lowercase()}.example.com", 443, p.name, z.name, load, ping, "")

    val list = listOf(
        // ---- FREE ----
        s("f-us", "New York", "United States", "US", Protocol.WIREGUARD, Zone.FREE, 72, 140),
        s("f-nl", "Amsterdam", "Netherlands", "NL", Protocol.OPENVPN, Zone.FREE, 64, 95),
        s("f-de", "Frankfurt", "Germany", "DE", Protocol.VMESS, Zone.FREE, 58, 88),
        s("f-in", "Mumbai", "India", "IN", Protocol.WIREGUARD, Zone.FREE, 69, 60),
        s("f-pk", "Karachi", "Pakistan", "PK", Protocol.OPENVPN, Zone.FREE, 55, 30),
        s("f-tr", "Istanbul", "Turkey", "TR", Protocol.VLESS, Zone.FREE, 61, 110),
        s("f-br", "Sao Paulo", "Brazil", "BR", Protocol.WIREGUARD, Zone.FREE, 66, 150),
        s("f-id", "Jakarta", "Indonesia", "ID", Protocol.OPENVPN, Zone.FREE, 70, 95),
        // ---- PREMIUM ----
        s("p-uk", "London", "United Kingdom", "GB", Protocol.WIREGUARD, Zone.PREMIUM, 31, 70),
        s("p-sg", "Singapore", "Singapore", "SG", Protocol.VLESS, Zone.PREMIUM, 22, 60),
        s("p-jp", "Tokyo", "Japan", "JP", Protocol.VMESS, Zone.PREMIUM, 35, 82),
        s("p-ca", "Toronto", "Canada", "CA", Protocol.OPENVPN, Zone.PREMIUM, 27, 120),
        s("p-ae", "Dubai", "UAE", "AE", Protocol.WIREGUARD, Zone.PREMIUM, 18, 45),
        s("p-fr", "Paris", "France", "FR", Protocol.VMESS, Zone.PREMIUM, 24, 75),
        s("p-au", "Sydney", "Australia", "AU", Protocol.WIREGUARD, Zone.PREMIUM, 29, 160),
        s("p-kr", "Seoul", "South Korea", "KR", Protocol.VLESS, Zone.PREMIUM, 20, 90),
        s("p-it", "Milan", "Italy", "IT", Protocol.OPENVPN, Zone.PREMIUM, 33, 80),
        s("p-es", "Madrid", "Spain", "ES", Protocol.WIREGUARD, Zone.PREMIUM, 26, 85),
        s("p-ru", "Moscow", "Russia", "RU", Protocol.XRAY, Zone.PREMIUM, 40, 100),
        s("p-za", "Johannesburg", "South Africa", "ZA", Protocol.WIREGUARD, Zone.PREMIUM, 30, 180),
        // ---- VIP ----
        s("v-ch", "Zurich", "Switzerland", "CH", Protocol.XRAY, Zone.VIP, 9, 78),
        s("v-se", "Stockholm", "Sweden", "SE", Protocol.WIREGUARD, Zone.VIP, 12, 92),
        s("v-hk", "Hong Kong", "Hong Kong", "HK", Protocol.XRAY, Zone.VIP, 15, 55),
        s("v-no", "Oslo", "Norway", "NO", Protocol.WIREGUARD, Zone.VIP, 10, 88),
        s("v-nz", "Auckland", "New Zealand", "NZ", Protocol.VLESS, Zone.VIP, 8, 190),
        s("v-lu", "Luxembourg City", "Luxembourg", "LU", Protocol.XRAY, Zone.VIP, 6, 70),
        s("v-ie", "Dublin", "Ireland", "IE", Protocol.WIREGUARD, Zone.VIP, 11, 65)
    )
}
