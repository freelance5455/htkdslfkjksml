package com.mytunnel.vpn.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mytunnel.vpn.data.Rewards
import com.mytunnel.vpn.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun scoreColor(score: Int) = when {
    score >= 75 -> Color(0xFF00E0C6)
    score >= 50 -> Color(0xFF8BE04A)
    score >= 25 -> Color(0xFFFFB84D)
    else -> Color(0xFFFF5C7A)
}

/** Apne area ka network report (ping, packet loss, bandwidth, SIM, location) + pichle reports. */
@Composable
fun AreaSection(vm: MainViewModel) {
    val ctx = LocalContext.current
    val st by vm.area.collectAsStateWithLifecycle()
    val set by vm.settings.collectAsStateWithLifecycle()
    val online by vm.online.collectAsStateWithLifecycle()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> vm.checkArea(granted) }
    val r = st.report

    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.SignalCellularAlt, null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.width(8.dp))
            Text("Area network report", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(if (online) "Online" else "Offline", color = if (online) Color(0xFF00E0C6) else Color(0xFFFF5C7A), fontWeight = FontWeight.SemiBold)
        }
        Text(
            "Location on ho to aap ke area ki service (kitni aa rahi hai) naapi jati hai aur save hoti hai.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        if (r != null) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.place, fontWeight = FontWeight.SemiBold)
                    Text("${r.carrier} • ${r.type}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("${r.score}%", color = scoreColor(r.score), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
            }
            LinearProgressIndicator(progress = { r.score / 100f }, color = scoreColor(r.score), modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
            Text("Service: ${r.quality}", fontWeight = FontWeight.SemiBold, color = scoreColor(r.score))
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                AreaMetric("Ping", "${r.pingMs} ms")
                AreaMetric("Loss", "${r.lossPct}%")
                AreaMetric("Link down", if (r.downKbps > 0) "%.0f Mbps".format(r.downKbps / 1000.0) else "—")
            }
            Spacer(Modifier.height(10.dp))
        }
        Button(
            onClick = {
                val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (granted) vm.checkArea(true) else launcher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            },
            enabled = !st.running, modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.MyLocation, null); Spacer(Modifier.width(8.dp))
            Text(if (st.running) "Naap raha hoon…" else "Check my area")
        }

        val history = set.reports.lines().filter { it.isNotBlank() }.mapNotNull { l ->
            val p = l.split("|")
            if (p.size < 6) null else p
        }
        if (history.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("Pichle reports", fontWeight = FontWeight.Bold)
            history.forEach { p ->
                val score = p[4].toIntOrNull() ?: 0
                val time = runCatching { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(p[0].toLong())) }.getOrDefault("")
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p[1], style = MaterialTheme.typography.bodyMedium)
                        Text("$time • ${p[2]} • ${p[3]} • ${p[5]} ms", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("$score%", color = scoreColor(score), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AreaMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

/** Daily reward, streak, daily missions, levels. */
@Composable
fun RewardsScreen(vm: MainViewModel) {
    val set by vm.settings.collectAsStateWithLifecycle()
    val today = Rewards.today()
    val claimed = set.lastClaim == today
    val done = if (set.missionDay == today) set.missionsDone else emptySet()
    val level = Rewards.levelFor(set.points)
    val next = Rewards.nextLevel(set.points)
    // Streak tootta hai agar kal claim nahi kiya.
    val streak = if (set.lastClaim == today || set.lastClaim == Rewards.yesterday()) set.streak else 0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Rewards", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.EmojiEvents, null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${set.points} points", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Level: ${level.name}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (next != null) {
                val span = (next.minPoints - level.minPoints).coerceAtLeast(1)
                LinearProgressIndicator(progress = { ((set.points - level.minPoints).toFloat() / span).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                Text("${next.name} ke liye ${next.minPoints - set.points} points aur", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Daily reward", fontWeight = FontWeight.Bold)
            Text("Rozana aayen, streak barhayen. Din miss hua to streak dobara 1 se.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Rewards.streakRewards.forEachIndexed { i, r ->
                    val reached = i < streak
                    Surface(
                        shape = MaterialTheme.shapes.medium, modifier = Modifier.weight(1f),
                        color = if (reached) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(Modifier.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("D${i + 1}", style = MaterialTheme.typography.labelSmall, color = if (reached) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("+$r", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, color = if (reached) Color.Black else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = vm::claimDaily, enabled = !claimed, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.CardGiftcard, null); Spacer(Modifier.width(8.dp))
                Text(if (claimed) "Aaj ka reward le liya" else "Claim today's reward")
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Daily missions (${done.size}/${Rewards.missions.size})", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Rewards.missions.forEach { m ->
                val ok = m.id in done
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked, null, tint = if (ok) Color(0xFF00E0C6) else MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(10.dp))
                    Text(m.title, Modifier.weight(1f))
                    Text("+${m.reward}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                }
            }
            Text("Missions har din naye ho jate hain.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Levels", fontWeight = FontWeight.Bold)
            Rewards.levels.forEach { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(l.name, Modifier.weight(1f), fontWeight = if (l == level) FontWeight.Bold else FontWeight.Normal)
                    Text(if (l.minPoints == 0) "Start" else "${l.minPoints} points", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
