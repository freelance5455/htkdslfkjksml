package com.mytunnel.vpn.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat
import com.mytunnel.vpn.MyTunnelApp
import com.mytunnel.vpn.vpn.MyTunnelVpnService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/** Auto-start on boot (only if the user enabled it AND VPN permission was granted before). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = ctx.applicationContext as MyTunnelApp
        val st = runBlocking { app.prefs.flow.first() }
        if (st.autoStart && VpnService.prepare(ctx) == null) {
            ContextCompat.startForegroundService(ctx, MyTunnelVpnService.connectIntent(ctx, st.lastServerId.ifBlank { null }))
        }
    }
}
