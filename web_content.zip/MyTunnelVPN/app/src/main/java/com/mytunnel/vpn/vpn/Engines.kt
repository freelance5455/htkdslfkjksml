package com.mytunnel.vpn.vpn

import android.content.Context
import android.net.VpnService
import android.os.ParcelFileDescriptor
import com.mytunnel.vpn.BuildConfig
import com.mytunnel.vpn.data.AppSettings
import com.mytunnel.vpn.data.Protocol
import com.mytunnel.vpn.data.ServerEntity
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.StringReader

/** One engine per protocol family. The foreground service drives them. */
interface VpnEngine {
    suspend fun start(service: VpnService, s: ServerEntity, st: AppSettings): Boolean
    fun stop()
    fun isUp(): Boolean
}

fun engineFor(ctx: Context, s: ServerEntity): VpnEngine = when {
    BuildConfig.DEMO_MODE && s.config.isBlank() -> DemoEngine()
    s.config.isBlank() -> throw IllegalStateException("Is server ka config missing hai. Server edit karke config add karein.")
    s.protocol == Protocol.WIREGUARD.name -> WireGuardEngine(ctx)
    else -> CoreEngine(CoreBridgeProvider.get())
}

/** Debug-only simulated connection so you can test the UI without real servers. */
class DemoEngine : VpnEngine {
    private var up = false
    override suspend fun start(service: VpnService, s: ServerEntity, st: AppSettings): Boolean {
        delay(1500); up = true; return true
    }
    override fun stop() { up = false }
    override fun isUp() = up
}

/** REAL WireGuard via the official wireguard-android tunnel library (userspace Go backend). */
class WireGuardEngine(ctx: Context) : VpnEngine {
    private val backend = GoBackend(ctx.applicationContext)
    private val tunnel = object : Tunnel {
        override fun getName() = "mytunnel"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    override suspend fun start(service: VpnService, s: ServerEntity, st: AppSettings): Boolean =
        withContext(Dispatchers.IO) {
            var text = s.config
            // Split tunneling: listed apps bypass the tunnel.
            if (st.splitApps.isNotEmpty()) {
                text = text.replaceFirst("[Interface]", "[Interface]\nExcludedApplications = ${st.splitApps.joinToString(", ")}")
            }
            val cfg = Config.parse(BufferedReader(StringReader(text)))
            backend.setState(tunnel, Tunnel.State.UP, cfg)
            true
        }

    override fun stop() { runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) } }
    override fun isUp() = runCatching { backend.getState(tunnel) == Tunnel.State.UP }.getOrDefault(false)
}

/**
 * Plug-in point for native cores (OpenVPN / V2Ray / Xray).
 * Implement this with libv2ray / AndroidLibXrayLite (VMess, VLESS, Xray) or ics-openvpn.
 * See README.md -> "Native cores".
 */
interface CoreBridge {
    /** Start the core and make it read/write packets of the TUN `tunFd`. `protect(fd)` must be applied to the core's outbound sockets. */
    fun start(protocol: Protocol, config: String, tunFd: Int, protect: (Int) -> Boolean)
    fun stop()
    fun isRunning(): Boolean
}

object CoreBridgeProvider {
    /** Replace with your real bridge once you added the native AAR. */
    var bridge: CoreBridge = object : CoreBridge {
        override fun start(protocol: Protocol, config: String, tunFd: Int, protect: (Int) -> Boolean) {
            throw IllegalStateException("${protocol.label} core abhi link nahi hai. README ka 'Native cores' section dekhein.")
        }
        override fun stop() {}
        override fun isRunning() = false
    }
    fun get(): CoreBridge = bridge
}

/** Builds a TUN with VpnService.Builder and hands it to the native core. */
class CoreEngine(private val core: CoreBridge) : VpnEngine {
    private var tun: ParcelFileDescriptor? = null

    override suspend fun start(service: VpnService, s: ServerEntity, st: AppSettings): Boolean =
        withContext(Dispatchers.IO) {
            val b = service.Builder()
                .setSession("My Tunnel VPN")
                .setMtu(1500)
                .addAddress("10.8.0.2", 32).addRoute("0.0.0.0", 0)
                .addAddress("fd00:8::2", 128).addRoute("::", 0)  // route IPv6 too => no IPv6 leaks
                .addDnsServer("1.1.1.1").addDnsServer("8.8.8.8")
            st.splitApps.forEach { runCatching { b.addDisallowedApplication(it) } }
            val fd = b.establish() ?: return@withContext false
            tun = fd
            core.start(Protocol.valueOf(s.protocol), s.config, fd.fd) { service.protect(it) }
            true
        }

    override fun stop() {
        runCatching { core.stop() }
        runCatching { tun?.close() }
        tun = null
    }
    override fun isUp() = tun != null && core.isRunning()
}
