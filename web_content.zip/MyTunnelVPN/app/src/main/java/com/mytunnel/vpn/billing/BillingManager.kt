package com.mytunnel.vpn.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*

/**
 * Google Play Billing structure (subscriptions).
 * 1) Create subscriptions in Play Console with ids below.
 * 2) For production, verify purchases on YOUR server (Play Developer API) - client-only checks can be bypassed.
 */
class BillingManager(ctx: Context, private val onTier: (String) -> Unit) {
    companion object {
        const val PREMIUM_ID = "premium_monthly"
        const val VIP_ID = "vip_monthly"
    }

    private val details = mutableMapOf<String, ProductDetails>()

    private val client: BillingClient = BillingClient.newBuilder(ctx)
        .setListener { r, purchases ->
            if (r.responseCode == BillingClient.BillingResponseCode.OK) purchases?.forEach(::handle)
        }
        .enablePendingPurchases()
        .build()

    fun connect() {
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(r: BillingResult) {
                if (r.responseCode == BillingClient.BillingResponseCode.OK) { loadProducts(); restore() }
            }
            override fun onBillingServiceDisconnected() {}
        })
    }

    private fun loadProducts() {
        val list = listOf(PREMIUM_ID, VIP_ID).map {
            QueryProductDetailsParams.Product.newBuilder().setProductId(it).setProductType(BillingClient.ProductType.SUBS).build()
        }
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(list).build()) { _, l ->
            l.forEach { details[it.productId] = it }
        }
    }

    fun buy(activity: Activity, productId: String) {
        val pd = details[productId] ?: return
        val token = pd.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: return
        val p = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).setOfferToken(token).build()
        client.launchBillingFlow(activity, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(p)).build())
    }

    /** Re-check existing subscriptions ("Restore purchases"). */
    fun restore() {
        client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()) { r, list ->
            if (r.responseCode == BillingClient.BillingResponseCode.OK) {
                val active = list.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }
                if (active.isEmpty()) onTier("FREE") else active.forEach(::handle)
            }
        }
    }

    private fun handle(p: Purchase) {
        if (p.purchaseState != Purchase.PurchaseState.PURCHASED) return
        if (!p.isAcknowledged) {
            client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) {}
        }
        onTier(if (p.products.any { it == VIP_ID }) "VIP" else "PREMIUM")
    }

    fun end() { client.endConnection() }
}
