package com.mytunnel.vpn.viewmodel

import android.app.Application
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mytunnel.vpn.MyTunnelApp
import com.mytunnel.vpn.data.*
import com.mytunnel.vpn.vpn.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.UUID

data class SpeedResult(val running: Boolean = false, val pingMs: Int = 0, val downMbps: Double = 0.0, val upMbps: Double = 0.0, val note: String = "")

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as MyTunnelApp

    val settings = a.prefs.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val servers = a.db.servers().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val usage = a.db.usage().recent().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val vpn = VpnController.state

    /** Selected server (falls back to the first server the user's tier allows). */
    val selected = combine(servers, settings) { l, s ->
        l.firstOrNull { it.id == s.lastServerId && canUse(it, s.tier) } ?: l.firstOrNull { canUse(it, s.tier) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val query = MutableStateFlow("")
    val history = MutableStateFlow(List(60) { 0f })      // KB/s, last 60 s
    val ip = MutableStateFlow("—")
    val speedTest = MutableStateFlow(SpeedResult())
    val area = MutableStateFlow(AreaState())
    /** Net on = true, net off = false (Home par "Online / Offline" label). */
    val online = MutableStateFlow(true)
    private var netCb: android.net.ConnectivityManager.NetworkCallback? = null

    init {
        viewModelScope.launch {
            vpn.collect { s ->
                val v = if (s.status == Status.CONNECTED) s.downBps / 1024f else 0f
                history.value = (history.value + v).takeLast(60)
            }
        }
        viewModelScope.launch {
            vpn.map { it.status }.distinctUntilChanged().drop(1).collect { delay(1500); refreshIp() }
        }
        refreshIp()
        viewModelScope.launch { vpn.map { it.status }.distinctUntilChanged().collect { if (it == Status.CONNECTED) completeMission("connect") } }
        runCatching {
            val cm = a.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            online.value = cm.getNetworkCapabilities(cm.activeNetwork)
                ?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            val cb = object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) { online.value = true; refreshIp() }
                override fun onLost(network: android.net.Network) { online.value = false }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
        }
    }

    override fun onCleared() {
        runCatching {
            val cm = a.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            netCb?.let { cm.unregisterNetworkCallback(it) }
        }
        super.onCleared()
    }

    // ---- daily reward + missions -------------------------------------------
    fun claimDaily() = viewModelScope.launch {
        val s = prefsSnapshot(); val today = Rewards.today()
        if (s.lastClaim == today) { toast("Aaj ka reward le chuke hain, kal dobara aayen"); return@launch }
        val streak = if (s.lastClaim == Rewards.yesterday()) s.streak + 1 else 1
        val r = Rewards.streakRewards[(streak - 1) % Rewards.streakRewards.size]
        a.prefs.update { this[Prefs.K.POINTS] = s.points + r; this[Prefs.K.STREAK] = streak; this[Prefs.K.LAST_CLAIM] = today }
        toast("Daily reward: +$r points (din $streak)")
    }

    fun completeMission(id: String) = viewModelScope.launch {
        val m = Rewards.missions.firstOrNull { it.id == id } ?: return@launch
        val s = prefsSnapshot(); val today = Rewards.today()
        val done = if (s.missionDay == today) s.missionsDone else emptySet()
        if (id in done) return@launch
        a.prefs.update { this[Prefs.K.MDAY] = today; this[Prefs.K.MDONE] = done + id; this[Prefs.K.POINTS] = s.points + m.reward }
        toast("Mission poora: +${m.reward} points")
    }

    // ---- area signal report ---------------------------------------------------
    fun checkArea(withLocation: Boolean) {
        if (area.value.running) return
        viewModelScope.launch {
            area.value = AreaState(true, area.value.report)
            val r = AreaInfo.measure(a, withLocation)
            area.value = AreaState(false, r)
            a.prefs.update {
                val old = this[Prefs.K.REPORTS] ?: ""
                this[Prefs.K.REPORTS] = (r.line() + "\n" + old).lines().filter { it.isNotBlank() }.take(15).joinToString("\n")
            }
            completeMission("area")
        }
    }

    suspend fun prefsSnapshot() = a.prefs.flow.first()

    fun toast(t: String) = Toast.makeText(a, t, Toast.LENGTH_SHORT).show()

    // ---- selection -----------------------------------------------------------
    fun select(s: ServerEntity) {
        if (!canUse(s, settings.value.tier)) return
        viewModelScope.launch {
            a.prefs.update { this[Prefs.K.LAST] = s.id }
            if (vpn.value.status == Status.CONNECTED || vpn.value.status == Status.CONNECTING) reconnect(s.id)
        }
    }

    fun selectProtocol(p: Protocol) {
        val tier = settings.value.tier
        val best = servers.value.filter { it.protocol == p.name && canUse(it, tier) }.minByOrNull { it.ping }
        if (best == null) toast("${p.label} ke liye is plan me koi server nahi") else select(best)
    }

    fun randomServer() {
        val tier = settings.value.tier
        val pool = servers.value.filter { canUse(it, tier) && it.id != selected.value?.id }
        if (pool.isEmpty()) toast("Koi aur server nahi mila") else select(pool.random())
    }

    private fun reconnect(id: String) =
        ContextCompat.startForegroundService(a, MyTunnelVpnService.connectIntent(a, id))

    fun toggleFavorite(s: ServerEntity) = viewModelScope.launch {
        a.db.servers().setFavorite(s.id, !s.favorite)
        if (!s.favorite) completeMission("fav")
    }
    fun deleteCustom(s: ServerEntity) = viewModelScope.launch { a.db.servers().deleteCustom(s.id) }

    // ---- custom configs ------------------------------------------------------
    fun importConfig(text: String) = viewModelScope.launch {
        val p = ConfigParser.parse(text)
        if (p == null) { toast("Config samajh nahi aayi (.ovpn / WireGuard / V2Ray JSON / vmess:// / vless://)"); return@launch }
        a.db.servers().upsert(
            ServerEntity("custom-" + UUID.randomUUID().toString().take(8), p.name, "Custom", "UN", p.host, p.port,
                p.protocol.name, Zone.CUSTOM.name, 0, 0, text.trim())
        )
        toast("Config import ho gayi: ${p.protocol.label}")
    }

    fun importUri(uri: Uri) = viewModelScope.launch {
        val text = withContext(Dispatchers.IO) {
            runCatching { a.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() }.getOrNull()
        }
        if (text.isNullOrBlank()) toast("File read nahi hui") else importConfig(text)
    }

    // ---- settings ------------------------------------------------------------
    fun setBool(key: androidx.datastore.preferences.core.Preferences.Key<Boolean>, v: Boolean) =
        viewModelScope.launch { a.prefs.update { this[key] = v } }

    // ---- account: guest or Google -------------------------------------------
    /** Ek hi dafa chalta hai: guest ban kar turant 100 points milte hain. */
    fun loginGuest() = viewModelScope.launch {
        val s = prefsSnapshot()
        if (s.accountType.isNotBlank()) return@launch
        a.prefs.update {
            this[Prefs.K.ACCOUNT_TYPE] = "GUEST"
            this[Prefs.K.DISPLAY_NAME] = "Guest"
            this[Prefs.K.POINTS] = s.points + 100
        }
        toast("Guest ke tor par shuru — +100 points!")
    }

    fun loginGoogle(name: String, email: String) = viewModelScope.launch {
        val s = prefsSnapshot()
        val firstTime = s.accountType.isBlank()
        a.prefs.update {
            this[Prefs.K.ACCOUNT_TYPE] = "GOOGLE"
            this[Prefs.K.DISPLAY_NAME] = name
            this[Prefs.K.EMAIL] = email
            if (firstTime) this[Prefs.K.POINTS] = s.points + 100
        }
        toast(if (firstTime) "Khush aamdeed, $name — +100 points!" else "Khush aamdeed wapis, $name")
    }

    fun logoutAccount() = viewModelScope.launch {
        a.prefs.update { this[Prefs.K.ACCOUNT_TYPE] = ""; this[Prefs.K.DISPLAY_NAME] = ""; this[Prefs.K.EMAIL] = "" }
    }

    fun setTier(t: String) = viewModelScope.launch { a.prefs.update { this[Prefs.K.TIER] = t } }
    fun setSplit(apps: Set<String>) = viewModelScope.launch { a.prefs.update { this[Prefs.K.SPLIT] = apps } }
    fun finishOnboarding() = viewModelScope.launch { a.prefs.update { this[Prefs.K.ONBOARDED] = true } }

    /** Real ping: TCP connect time to each server host:port (unreachable servers keep the old value). */
    fun refreshPings() = viewModelScope.launch(Dispatchers.IO) {
        servers.value.map { s ->
            async {
                runCatching {
                    val t = System.nanoTime()
                    Socket().use { it.connect(InetSocketAddress(s.host, s.port), 2000) }
                    a.db.servers().setPing(s.id, ((System.nanoTime() - t) / 1_000_000).toInt())
                }
            }
        }.awaitAll()
    }

    // ---- network tools -------------------------------------------------------
    fun refreshIp() = viewModelScope.launch(Dispatchers.IO) {
        ip.value = runCatching {
            val c = URL("https://api.ipify.org").openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000
            c.inputStream.bufferedReader().readText().trim()
        }.getOrDefault("Offline")
    }

    fun runSpeedTest() {
        if (speedTest.value.running) return
        viewModelScope.launch(Dispatchers.IO) {
            speedTest.value = SpeedResult(running = true, note = "Ping...")
            val pings = (1..3).mapNotNull {
                runCatching {
                    val t = System.nanoTime()
                    Socket().use { s -> s.connect(InetSocketAddress("1.1.1.1", 443), 3000) }
                    ((System.nanoTime() - t) / 1_000_000).toInt()
                }.getOrNull()
            }
            if (pings.isEmpty()) { speedTest.value = SpeedResult(note = "Internet nahi hai"); return@launch }
            val ping = pings.average().toInt()
            speedTest.value = SpeedResult(running = true, pingMs = ping, note = "Download...")
            val down = runCatching {
                val c = URL("https://speed.cloudflare.com/__down?bytes=15000000").openConnection() as HttpURLConnection
                c.connectTimeout = 5000; c.readTimeout = 8000
                val buf = ByteArray(32768); var total = 0L; val t0 = System.nanoTime()
                c.inputStream.use { while (true) { val n = it.read(buf); if (n < 0) break; total += n; if (System.nanoTime() - t0 > 8e9) break } }
                total * 8 / 1e6 / ((System.nanoTime() - t0) / 1e9)
            }.getOrDefault(0.0)
            speedTest.value = SpeedResult(running = true, pingMs = ping, downMbps = down, note = "Upload...")
            val up = runCatching {
                val c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 5000; c.readTimeout = 8000
                c.setFixedLengthStreamingMode(3_000_000)
                val t0 = System.nanoTime()
                c.outputStream.use { o -> val b = ByteArray(32768); var left = 3_000_000; while (left > 0) { val n = minOf(left, b.size); o.write(b, 0, n); left -= n } }
                c.responseCode
                3_000_000 * 8 / 1e6 / ((System.nanoTime() - t0) / 1e9)
            }.getOrDefault(0.0)
            speedTest.value = SpeedResult(false, ping, down, up, "Done")
            completeMission("speed")
        }
    }
}
