package com.mytunnel.vpn

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mytunnel.vpn.billing.BillingManager
import com.mytunnel.vpn.ui.AppRoot
import com.mytunnel.vpn.ui.MyTunnelTheme
import com.mytunnel.vpn.viewmodel.MainViewModel
import com.mytunnel.vpn.vpn.MyTunnelVpnService
import com.mytunnel.vpn.vpn.Status
import com.mytunnel.vpn.vpn.VpnController

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private lateinit var billing: BillingManager

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startVpn() else vm.toast("VPN permission zaroori hai")
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        billing = BillingManager(this) { vm.setTier(it) }.also { it.connect() }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent {
            val s by vm.settings.collectAsStateWithLifecycle()
            MyTunnelTheme(dark = s.dark) {
                AppRoot(vm = vm, onToggle = ::toggle, onBuy = { billing.buy(this, it) }, onRestore = { billing.restore() })
            }
        }
    }

    private fun toggle() {
        val st = VpnController.state.value.status
        if (st == Status.CONNECTED || st == Status.CONNECTING) {
            startService(MyTunnelVpnService.disconnectIntent(this))
        } else {
            val i = VpnService.prepare(this)
            if (i != null) vpnPermission.launch(i) else startVpn()
        }
    }

    private fun startVpn() {
        val id = vm.selected.value?.id ?: return vm.toast("Pehle server select karein")
        ContextCompat.startForegroundService(this, MyTunnelVpnService.connectIntent(this, id))
    }

    override fun onDestroy() { billing.end(); super.onDestroy() }
}
