package com.mytunnel.vpn

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.mytunnel.vpn.billing.BillingManager
import com.mytunnel.vpn.ui.AppRoot
import com.mytunnel.vpn.ui.MyTunnelTheme
import com.mytunnel.vpn.viewmodel.MainViewModel
import com.mytunnel.vpn.vpn.MyTunnelVpnService
import com.mytunnel.vpn.vpn.Status
import com.mytunnel.vpn.vpn.VpnController

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private lateinit var billing: BillingManager

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startVpn() else vm.toast("VPN permission zaroori hai")
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    private val googleSignIn = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            vm.loginGoogle(account.displayName ?: account.email ?: "Google user", account.email ?: "")
        } catch (e: ApiException) {
            if (e.statusCode != 12501) vm.toast("Google sign-in nahi ho saka (${e.statusCode})") // 12501 = user ne cancel kiya
        }
    }

    private fun googleClient(): GoogleSignInClient? {
        if (BuildConfig.GOOGLE_WEB_CLIENT_ID.isBlank()) {
            vm.toast("Pehle Google Sign-In setup karein — README.md 'Google Sign-In' section dekhein")
            return null
        }
        val opts = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(BuildConfig.GOOGLE_WEB_CLIENT_ID)
            .requestEmail()
            .build()
        return GoogleSignIn.getClient(this, opts)
    }

    private fun startGoogleSignIn() { googleClient()?.let { googleSignIn.launch(it.signInIntent) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        billing = BillingManager(this) { vm.setTier(it) }.also { it.connect() }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        requestOverlayPermissionIfNeeded()
        requestIgnoreBatteryOptimizations()

        setContent {
            val s by vm.settings.collectAsStateWithLifecycle()
            MyTunnelTheme(dark = s.dark) {
                AppRoot(
                    vm = vm, onToggle = ::toggle, onBuy = { billing.buy(this, it) }, onRestore = { billing.restore() },
                    onGoogleSignIn = ::startGoogleSignIn
                )
            }
        }
    }

    private fun toggle() {
        val st = VpnController.state.value.status
        if (st == Status.CONNECTED || st == Status.CONNECTING) {
            startService(MyTunnelVpnService.disconnectIntent(this))
        } else {
            val i = VpnService.prepare(this)
            if (i != null) vpnPermission.launch(i) else startVpn()
        }
    }

    private fun startVpn() {
        val id = vm.selected.value?.id ?: return vm.toast("Pehle server select karein")
        ContextCompat.startForegroundService(this, MyTunnelVpnService.connectIntent(this, id))
    }

    // "Display over other apps" — lets a VPN status overlay / connect-reminder show on top of other apps.
    // This is a special permission: declaring it in the manifest isn't enough, user must approve it in Settings.
    private fun requestOverlayPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) { /* device doesn't expose this screen, ignore */ }
        }
    }

    // Asks Android not to kill the VPN connection in the background (battery optimization whitelist).
    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) { /* some OEMs block this intent, ignore */ }
        }
    }

    override fun onDestroy() { billing.end(); super.onDestroy() }
}
