package com.mytunnel.vpn.data

import android.content.Context
import android.os.Build
import com.mytunnel.vpn.BuildConfig
import com.mytunnel.vpn.util.DeviceInfo
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Staff dashboard ko device ki basic maloomat bhejta hai (backend/ folder).
 * Kya jata hai: random device id, phone model, SIM/carrier ka NAAM (number nahi), Android version,
 * app version, points, streak, plan, account type (guest/google) aur naam.
 * Kya NAHI jata: phone number, location, browsing, IP, ya koi aur personal data.
 * Settings me "Staff sync" se band ho jata hai.
 */
object StaffSync {
    suspend fun push(ctx: Context, prefs: Prefs, s: AppSettings) {
        if (!s.staffSync || BuildConfig.STAFF_API_URL.isBlank() || BuildConfig.DEVICE_KEY.isBlank()) return
        var id = s.deviceId
        if (id.isBlank()) { id = UUID.randomUUID().toString(); prefs.update { this[Prefs.K.DEVICE_ID] = id } }
        val today = Rewards.today()
        val body = JSONObject()
            .put("id", id).put("model", DeviceInfo.deviceName()).put("os", Build.VERSION.RELEASE)
            .put("carrier", DeviceInfo.carrierName(ctx))
            .put("account", s.accountType).put("name", s.displayName)
            .put("app", BuildConfig.VERSION_NAME).put("points", s.points).put("streak", s.streak)
            .put("missions", if (s.missionDay == today) s.missionsDone.size else 0).put("tier", s.tier)
        runCatching {
            val c = URL(BuildConfig.STAFF_API_URL.trimEnd('/') + "/api/device").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 8000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-device-key", BuildConfig.DEVICE_KEY)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            c.responseCode; c.disconnect()
        }
    }
}
