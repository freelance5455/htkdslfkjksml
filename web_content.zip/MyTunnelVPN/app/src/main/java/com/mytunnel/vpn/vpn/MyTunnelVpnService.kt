package com.mytunnel.vpn.vpn

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.TrafficStats
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.os.Process
import com.mytunnel.vpn.MainActivity
import com.mytunnel.vpn.MyTunnelApp
import com.mytunnel.vpn.R
import com.mytunnel.vpn.data.Prefs
import com.mytunnel.vpn.data.UsageEntity
import com.mytunnel.vpn.overlay.OverlayManager
import com.mytunnel.vpn.util.fmtSpeed
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Foreground VpnService. Responsibilities:
 *  - start / stop the engine of the chosen server
 *  - foreground notification (with Disconnect action)
 *  - speed + data usage tracking
 *  - Auto Reconnect, Kill Switch (blackhole TUN while the tunnel is down)
 *  - floating speed overlay
 */
class MyTunnelVpnService : VpnService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var connectJob: Job? = null
    private var engine: VpnEngine? = null
    private var blackhole: ParcelFileDescriptor? = null
    @Volatile private var userStopped = false
    private lateinit var overlay: OverlayManager
    private val app get() = application as MyTunnelApp

    override fun onCreate() {
        super.onCreate()
        overlay = OverlayManager(this)
        // Show / hide overlay bubble live when setting or state changes.
        scope.launch(Dispatchers.Main) {
            combine(app.prefs.flow.map { it.overlay }.distinctUntilChanged(), VpnController.state) { o, s -> o to s }
                .collect { (enabled, s) ->
                    if (enabled && s.status == Status.CONNECTED) { overlay.show(); overlay.update(s.downBps, s.upBps) }
                    else overlay.hide()
                }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, notification("My Tunnel VPN"))
        if (intent?.action == ACTION_DISCONNECT) { disconnect(); return START_NOT_STICKY }
        userStopped = false
        val id = intent?.getStringExtra(EXTRA_SERVER_ID)
        connectJob?.cancel()
        val old = engine; engine = null
        if (old != null) Thread { old.stop() }.start()
        connectJob = scope.launch { connectLoop(id) }
        return START_STICKY
    }

    // ---- connect / reconnect -------------------------------------------------

    private suspend fun connectLoop(id: String?) {
        var attempt = 0
        while (currentCoroutineContext().isActive && !userStopped) {
            releaseKillSwitch()
            if (tryConnect(id)) { attempt = 0; monitor(); if (userStopped) return }
            val st = app.prefs.flow.first()
            if (st.killSwitch && !userStopped) engageKillSwitch()
            if (!st.autoReconnect || attempt >= 5) {
                if (!userStopped) {
                    val msg = VpnController.state.value.message.ifBlank { "Connection lost" }
                    VpnController.update { copy(status = Status.ERROR, message = msg) }
                    if (!st.killSwitch) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
                }
                return
            }
            attempt++
            VpnController.update { copy(status = Status.CONNECTING, message = "Reconnecting ($attempt/5)…") }
            notify("Reconnecting ($attempt/5)…")
            delay(3000)
        }
    }

    private suspend fun tryConnect(id: String?): Boolean {
        val st = app.prefs.flow.first()
        val s = app.db.servers().get(id ?: st.lastServerId)
        if (s == null) { VpnController.update { copy(message = "Koi server select nahi hai") }; return false }
        VpnController.update { copy(status = Status.CONNECTING, server = s, message = "") }
        notify("Connecting to ${s.name}…")
        if (s.config.isNotBlank() && !hasInternet()) {
            VpnController.update { copy(message = "Internet nahi hai. Net on karein, phir connect karein (servers list offline bhi mehfooz hai).") }
            return false
        }
        return try {
            val e = engineFor(this, s)
            engine = e
            val ok = e.start(this, s, st)
            if (ok) {
                VpnController.update { copy(status = Status.CONNECTED, connectedAt = System.currentTimeMillis(), message = "") }
                app.prefs.update { this[Prefs.K.LAST] = s.id }
                notify("Connected • ${s.name}")
            }
            ok
        } catch (t: Throwable) {
            VpnController.update { copy(message = t.message ?: "Connection failed") }
            false
        }
    }

    private fun hasInternet(): Boolean = runCatching {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }.getOrDefault(true)

    /** Runs while the tunnel is up: speed, totals, daily data usage. Returns when the tunnel drops. */
    private suspend fun monitor() {
        val uid = Process.myUid()
        fun rx() = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0)
        fun tx() = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0)
        var pRx = rx(); var pTx = tx()
        var sRx = 0L; var sTx = 0L; var pendRx = 0L; var pendTx = 0L; var tick = 0
        while (currentCoroutineContext().isActive && !userStopped && engine?.isUp() == true) {
            delay(1000)
            val cRx = rx(); val cTx = tx()
            val dRx = (cRx - pRx).coerceAtLeast(0); val dTx = (cTx - pTx).coerceAtLeast(0)
            pRx = cRx; pTx = cTx; sRx += dRx; sTx += dTx; pendRx += dRx; pendTx += dTx
            VpnController.update { copy(downBps = dRx, upBps = dTx, rx = sRx, tx = sTx) }
            if (++tick % 5 == 0) notify("↓ ${fmtSpeed(dRx)}  ↑ ${fmtSpeed(dTx)}")
            if (tick % 10 == 0) { saveUsage(pendRx, pendTx); pendRx = 0; pendTx = 0 }
        }
        saveUsage(pendRx, pendTx)
        VpnController.update { copy(downBps = 0, upBps = 0) }
    }

    private suspend fun saveUsage(rx: Long, tx: Long) {
        if (rx == 0L && tx == 0L) return
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val cur = app.db.usage().get(day)
        app.db.usage().put(UsageEntity(day, (cur?.rx ?: 0) + rx, (cur?.tx ?: 0) + tx))
    }

    // ---- kill switch ---------------------------------------------------------
    // In-app kill switch: while the tunnel is down we hold a TUN that routes everything
    // to nowhere, so no traffic leaks. (System-level "Always-on VPN + Block connections
    // without VPN" is even stronger; Settings screen links to it.)

    private fun engageKillSwitch() {
        if (blackhole != null) return
        blackhole = runCatching {
            Builder().setSession("My Tunnel - Kill Switch")
                .addAddress("10.255.0.2", 32).addRoute("0.0.0.0", 0)
                .addAddress("fd00:255::2", 128).addRoute("::", 0)
                .establish()
        }.getOrNull()
    }

    private fun releaseKillSwitch() { runCatching { blackhole?.close() }; blackhole = null }

    // ---- stop ----------------------------------------------------------------

    private fun disconnect() {
        userStopped = true
        connectJob?.cancel()
        releaseKillSwitch()
        val e = engine; engine = null
        Thread { e?.stop() }.start()
        VpnController.reset()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() { disconnect(); super.onRevoke() }

    override fun onDestroy() {
        overlay.hide()
        scope.cancel()
        super.onDestroy()
    }

    // ---- notification --------------------------------------------------------

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, MyTunnelVpnService::class.java).setAction(ACTION_DISCONNECT), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, MyTunnelApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("My Tunnel VPN")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Disconnect", stop).build())
            .build()
    }

    private fun notify(text: String) {
        getSystemService(Context.NOTIFICATION_SERVICE).let {
            (it as android.app.NotificationManager).notify(NOTIF_ID, notification(text))
        }
    }

    companion object {
        const val ACTION_CONNECT = "com.mytunnel.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.mytunnel.vpn.DISCONNECT"
        const val EXTRA_SERVER_ID = "server_id"
        private const val NOTIF_ID = 1001

        fun connectIntent(ctx: Context, serverId: String?) =
            Intent(ctx, MyTunnelVpnService::class.java).setAction(ACTION_CONNECT).putExtra(EXTRA_SERVER_ID, serverId)

        fun disconnectIntent(ctx: Context) =
            Intent(ctx, MyTunnelVpnService::class.java).setAction(ACTION_DISCONNECT)
    }
}
