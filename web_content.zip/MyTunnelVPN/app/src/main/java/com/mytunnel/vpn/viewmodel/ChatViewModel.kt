package com.mytunnel.vpn.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mytunnel.vpn.ai.AiHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

data class ChatMsg(val text: String, val fromUser: Boolean)

class ChatViewModel : ViewModel() {
    val messages = MutableStateFlow(
        listOf(ChatMsg("Salam! Main My Tunnel AI Help hoon. VPN connect, speed, packages ya settings ke baare me kuch bhi poochein.", false))
    )
    val typing = MutableStateFlow(false)

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        messages.value = messages.value + ChatMsg(t, true)
        viewModelScope.launch {
            typing.value = true
            delay(500)
            val r = AiHelper.reply(t)
            messages.value = messages.value + ChatMsg(r, false)
            typing.value = false
        }
    }
}
