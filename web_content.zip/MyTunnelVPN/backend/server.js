// My Tunnel VPN - staff / admin backend. Zero dependencies (Node 18+).
// Start:  ADMIN_PASSWORD=yourStrongPass DEVICE_KEY=longRandomKey node server.js
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = +process.env.PORT || 8080;
const DATA = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const DEVICE_KEY = process.env.DEVICE_KEY || '';
const SECRET = process.env.TOKEN_SECRET || crypto.randomBytes(32).toString('hex');

let db = { devices: {}, staff: {} };
try { db = JSON.parse(fs.readFileSync(DATA, 'utf8')); } catch (e) {}
const save = () => { const t = DATA + '.tmp'; fs.writeFileSync(t, JSON.stringify(db)); fs.renameSync(t, DATA); };

const hash = (pw, salt = crypto.randomBytes(16).toString('hex')) =>
  salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
const verify = (pw, stored) => {
  const [salt, h] = stored.split(':');
  const a = Buffer.from(h, 'hex'), b = crypto.scryptSync(pw, salt, 32);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};
if (!Object.values(db.staff).some(s => s.role === 'admin')) {
  const user = (process.env.ADMIN_USER || 'admin').toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 32) || 'admin';
  const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(14).toString('base64url');
  db.staff[user] = { role: 'admin', pass: hash(pw) };
  save();
  console.log(process.env.ADMIN_PASSWORD
    ? `Admin user "${user}" created.`
    : `Admin user "${user}" created. Password: ${pw}  (isay save kar lein, dobara nahi dikhega)`);
}

const sign = o => { const p = Buffer.from(JSON.stringify(o)).toString('base64url');
  return p + '.' + crypto.createHmac('sha256', SECRET).update(p).digest('base64url'); };
const unsign = t => { if (!t) return null; const [p, s] = t.split('.');
  if (!p || !s) return null;
  const e = crypto.createHmac('sha256', SECRET).update(p).digest('base64url');
  if (s.length !== e.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(e))) return null;
  const o = JSON.parse(Buffer.from(p, 'base64url').toString()); return o.exp > Date.now() ? o : null; };

const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise((ok, no) => { let d = ''; req.on('data', c => { d += c; if (d.length > 20000) { req.destroy(); no(); } });
  req.on('end', () => { try { ok(JSON.parse(d || '{}')); } catch (e) { no(e); } }); });
const str = (v, n = 80) => String(v ?? '').slice(0, n);
const num = v => Math.max(0, Math.min(1e9, Math.floor(+v || 0)));

const fails = {};
const tooMany = ip => (fails[ip] || 0) >= 8;

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'); const p = url.pathname;
  const ip = req.socket.remoteAddress;
  try {
    if (req.method === 'GET' && (p === '/' || p === '/panel')) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(fs.readFileSync(path.join(__dirname, 'panel.html')));
    }
    // ---- app -> server: device heartbeat (user ki marzi se, Settings me off ho sakta hai)
    if (req.method === 'POST' && p === '/api/device') {
      if (!DEVICE_KEY || req.headers['x-device-key'] !== DEVICE_KEY) return send(res, 401, { error: 'bad key' });
      const b = await body(req);
      const id = str(b.id, 40); if (!/^[A-Za-z0-9-]{8,40}$/.test(id)) return send(res, 400, { error: 'bad id' });
      const old = db.devices[id] || { first: Date.now() };
      db.devices[id] = { ...old, id, model: str(b.model), os: str(b.os, 20), app: str(b.app, 20),
        points: num(b.points), streak: num(b.streak), missions: num(b.missions), tier: str(b.tier, 10),
        lastSeen: Date.now() };
      save(); return send(res, 200, { ok: true });
    }
    // ---- staff login
    if (req.method === 'POST' && p === '/api/staff/login') {
      if (tooMany(ip)) return send(res, 429, { error: 'bohat koshishein, baad me try karein' });
      const b = await body(req); const s = db.staff[str(b.user, 32)];
      if (!s || !verify(str(b.pass, 200), s.pass)) { fails[ip] = (fails[ip] || 0) + 1; setTimeout(() => delete fails[ip], 600000); return send(res, 401, { error: 'ghalat user/password' }); }
      return send(res, 200, { token: sign({ u: str(b.user, 32), r: s.role, exp: Date.now() + 12 * 3600e3 }), role: s.role });
    }
    // ---- staff / admin APIs
    if (p.startsWith('/api/staff/') || p.startsWith('/api/admin/')) {
      const a = unsign((req.headers.authorization || '').replace('Bearer ', ''));
      if (!a || !db.staff[a.u]) return send(res, 401, { error: 'login karein' });
      if (p.startsWith('/api/admin/') && db.staff[a.u].role !== 'admin') return send(res, 403, { error: 'sirf admin' });

      if (p === '/api/staff/overview') {
        const l = Object.values(db.devices), day = Date.now() - 864e5;
        return send(res, 200, { users: l.length, active24h: l.filter(d => d.lastSeen > day).length,
          totalPoints: l.reduce((s, d) => s + d.points, 0), top: l.sort((x, y) => y.points - x.points).slice(0, 5) });
      }
      if (p === '/api/staff/users') {
        const q = (url.searchParams.get('q') || '').toLowerCase();
        const l = Object.values(db.devices).filter(d => !q || (d.model + d.id + d.os).toLowerCase().includes(q))
          .sort((x, y) => y.points - x.points).slice(0, 500);
        return send(res, 200, l);
      }
      if (p === '/api/admin/staff' && req.method === 'GET')
        return send(res, 200, Object.entries(db.staff).map(([user, s]) => ({ user, role: s.role })));
      if (p === '/api/admin/staff' && req.method === 'POST') {
        const b = await body(req); const u = str(b.user, 32);
        if (!/^[a-z0-9_]{3,32}$/.test(u) || str(b.pass, 200).length < 8) return send(res, 400, { error: 'user a-z0-9_ (3+), password 8+ huroof' });
        db.staff[u] = { role: b.role === 'admin' ? 'admin' : 'staff', pass: hash(str(b.pass, 200)) }; save();
        return send(res, 200, { ok: true });
      }
      if (p === '/api/admin/staff' && req.method === 'DELETE') {
        const u = str(url.searchParams.get('user'), 32);
        if (u === a.u) return send(res, 400, { error: 'apna account delete nahi ho sakta' });
        delete db.staff[u]; save(); return send(res, 200, { ok: true });
      }
    }
    send(res, 404, { error: 'not found' });
  } catch (e) { send(res, 400, { error: 'bad request' }); }
}).listen(PORT, () => console.log('Staff panel: http://localhost:' + PORT));
