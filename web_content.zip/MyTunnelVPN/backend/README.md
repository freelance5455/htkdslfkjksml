# Staff / Admin backend
Chalane ke liye (Node 18+, koi package install nahi):
    ADMIN_USER=apna_username ADMIN_PASSWORD=mazboot_password DEVICE_KEY=lamba_random_key node server.js
Phir browser me http://SERVER:8080 kholein. Login: `ADMIN_USER` (ya "admin" agar set na kiya ho) + `ADMIN_PASSWORD`.

NOTE: `ADMIN_USER`/`ADMIN_PASSWORD` sirf **pehli dafa** (jab `data.json` mein koi admin na ho) use hote hain, jis se pehla admin account banta hai. Us ke baad password sirf hashed form database mein rehta hai — recover nahi ho sakta, sirf naya banaya ja sakta hai (neeche dekhein).

- Admin: staff accounts banata/hatata hai, sab users dekhta hai.
- Staff: sirf dekh sakta hai (users, device model/Android/app version, points, streak, last seen).

App me `app/build.gradle.kts` ke `STAFF_API_URL` (https://aap-ka-server) set karein — yeh hidden admin login (app ke splash screen par naam 5 baar tap karein) is URL par hi connect karta hai. `DEVICE_KEY` wohi key hai jo device heartbeat ke liye hai, admin login ke liye zaroori nahi.

HTTPS zaroor lagayein (nginx / Caddy / Cloudflare) — warna password network par plain text jaisa expose ho sakta hai. Points app report karti hai, is liye payout se pehle server-side check karein.

## Admin password bhool gaye / badalna hai to:
1. Server band karein, `data.json` mein `staff` object se apna user hata dein (ya pura `data.json` delete, agar sirf testing data hai), phir `ADMIN_USER=... ADMIN_PASSWORD=...` ke sath dobara start karein — naya admin ban jayega.
   - Ya: command line se `curl -X POST .../api/admin/staff` existing admin token ke sath naya staff/admin user bana sakte hain (dekhein server.js ka `/api/admin/staff` route).
