# Staff / Admin backend
Chalane ke liye (Node 18+, koi package install nahi):
    ADMIN_PASSWORD=mazboot_password DEVICE_KEY=lamba_random_key node server.js
Phir browser me http://SERVER:8080 kholein. Login: `admin` + aap ka password.
- Admin: staff accounts banata/hatata hai, sab users dekhta hai.
- Staff: sirf dekh sakta hai (users, device model/Android/app version, points, streak, last seen).
App me `app/build.gradle.kts` ke `STAFF_API_URL` (https://aap-ka-server) aur `DEVICE_KEY` (wohi key) set karein.
HTTPS zaroor lagayein (nginx / Caddy / Cloudflare). Points app report karti hai, is liye payout se pehle server-side check karein.
