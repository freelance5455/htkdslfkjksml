import os,json,re,ast,hashlib,hmac,secrets,subprocess
from pathlib import Path
from datetime import datetime,timezone
from fastapi import FastAPI,WebSocket,WebSocketDisconnect,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

BASE=Path(__file__).resolve().parent
MEM=BASE/"memory"; WORK=BASE/"workspace"; MEDIA=BASE/"media"
for p in (MEM,WORK,MEDIA): p.mkdir(exist_ok=True)
OWNER="रुद्र सिंह पढ़ियार"
PASSWORD_HASH=os.getenv("PRIME_PRIVATE_PASSWORD_SHA256","")
NAMES=["Ultra AI","D.C. AI","Translator AI","Gamer AI","Live Animation AI","Audio Editor AI","Code Creator AI","AI Photos","AI Videos","AI 3D Creator"]
app=FastAPI(title="AI_OS_By_Rudra")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["GET","POST"],allow_headers=["*"])

def slug(s): return re.sub(r"[^a-z0-9]+","_",s.lower()).strip("_")
class Agent:
 def __init__(self,name):
  self.name=name; self.path=MEM/(slug(name)+".json")
  try:self.history=json.loads(self.path.read_text("utf-8"))
  except:self.history=[]
 def remember(self,role,msg):
  self.history.append({"role":role,"content":str(msg)[:4000],"time":datetime.now(timezone.utc).isoformat()})
  self.history=self.history[-120:]; self.path.write_text(json.dumps(self.history,ensure_ascii=False,indent=2),encoding="utf-8")
 async def reply(self,msg): return f"{self.name}: संदेश प्राप्त हुआ। वास्तविक AI provider जोड़ना बाकी है।"

def calculate(expr):
 tree=ast.parse(expr,mode="eval")
 allowed=(ast.Expression,ast.BinOp,ast.UnaryOp,ast.Constant,ast.Add,ast.Sub,ast.Mult,ast.Div,ast.FloorDiv,ast.Mod,ast.Pow,ast.USub,ast.UAdd)
 if any(type(n) not in allowed for n in ast.walk(tree)): raise ValueError("अमान्य गणितीय expression")
 if any(isinstance(n,ast.Constant) and (type(n.value) not in (int,float) or abs(n.value)>1000000) for n in ast.walk(tree)): raise ValueError("संख्या सीमा से बाहर")
 value=eval(compile(tree,"<safe-calc>","eval"),{"__builtins__":{}},{})
 if not isinstance(value,(int,float)) or abs(value)>10**12: raise ValueError("परिणाम सीमा से बाहर")
 return value

class UltraAI(Agent):
 async def reply(self,msg):
  try:d=json.loads(msg)
  except:return 'JSON command दें: {"action":"list"} / write / read / calculate'
  a=d.get("action"); n=d.get("file","")
  if n and (Path(n).name!=n or n in (".","..")): return "केवल workspace filename मान्य है।"
  p=WORK/n if n else None
  if a=="list": return json.dumps([x.name for x in WORK.iterdir() if x.is_file()])
  if a=="write" and p: p.write_text(str(d.get("content",""))[:20000],encoding="utf-8"); return "Saved: "+n
  if a=="read" and p: return p.read_text("utf-8")[:12000] if p.is_file() else "File not found"
  if a=="calculate":
   try:return str(calculate(str(d.get("expression",""))))
   except Exception as e:return "Calculation error: "+str(e)
  return "Allowed actions: list, read, write, calculate. Arbitrary exec disabled."

class DeviceController(Agent):
 async def reply(self,msg): return "D.C. AI safe demo: native Android integration, explicit user consent and trusted pairing are required. Remote taps/stealth control are not implemented."
class TranslatorAI(Agent): pass
class GamerAI(Agent): pass
class AnimationAI(Agent): pass
class AudioEditorAI(Agent): pass
class CodeCreatorAI(Agent): pass
class PhotosAI(Agent): pass
class VideosAI(Agent):
 async def reply(self,msg): return "Video AI orchestration placeholder: connect an authorized video-generation provider."
class ThreeDAI(Agent): pass
classes=[UltraAI,DeviceController,TranslatorAI,GamerAI,AnimationAI,AudioEditorAI,CodeCreatorAI,PhotosAI,VideosAI,ThreeDAI]
agents={n:c(n) for n,c in zip(NAMES,classes)}

@app.get("/")
def home(): return {"name":"AI_OS_By_Rudra","owner":OWNER,"agents":NAMES,"status":"online"}
@app.get("/health")
def health(): return {"status":"ok"}
class Login(BaseModel): password:str
@app.post("/private/login")
def login(d:Login):
 if not PASSWORD_HASH: raise HTTPException(503,"Configure PRIME_PRIVATE_PASSWORD_SHA256 first")
 candidate=hashlib.sha256(d.password.encode()).hexdigest()
 if not hmac.compare_digest(candidate,PASSWORD_HASH): raise HTTPException(401,"गलत पासवर्ड")
 return {"ok":True,"token":secrets.token_urlsafe(24),"owner":OWNER}
@app.websocket("/ws")
async def socket(ws:WebSocket):
 await ws.accept()
 try:
  while True:
   d=await ws.receive_json(); name=str(d.get("agent","Ultra AI")); msg=str(d.get("message",""))[:4000]
   if name not in agents: await ws.send_json({"type":"error","message":"Unknown module"}); continue
   ag=agents[name]; ag.remember("user",msg)
   try: answer=await ag.reply(msg)
   except Exception as e: answer="Request error: "+str(e)[:200]
   ag.remember("assistant",answer)
   await ws.send_json({"type":"reply","agent":name,"message":answer})
 except WebSocketDisconnect: pass

@app.post("/video/join")
def join():
 clips=sorted(MEDIA.glob("clip_*.mp4"))
 if not clips: raise HTTPException(400,"Add media/clip_*.mp4 first")
 ffmpeg=os.getenv("FFMPEG_PATH","ffmpeg"); manifest=MEDIA/"concat_list.txt"
 manifest.write_text("".join("file '"+p.name+"'\n" for p in clips),encoding="utf-8")
 try: subprocess.run([ffmpeg,"-y","-f","concat","-safe","1","-i",manifest.name,"-c","copy","joined_video.mp4"],cwd=MEDIA,check=True,capture_output=True,text=True,timeout=1800)
 except FileNotFoundError: raise HTTPException(503,"FFmpeg not installed/configured")
 except subprocess.CalledProcessError as e: raise HTTPException(500,e.stderr[-1000:])
 except subprocess.TimeoutExpired: raise HTTPException(504,"FFmpeg timeout")
 return {"ok":True,"file":"media/joined_video.mp4","clips":len(clips)}
if __name__=="__main__":
 import uvicorn
 uvicorn.run(app,host="127.0.0.1",port=5000)
