package ly.pharmacy.pos

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.net.NetworkInterface
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class ApiException(val status: NanoHTTPD.Response.IStatus, message: String) : Exception(message)

class PosServer(private val ctx: Context, port: Int) : NanoHTTPD(port) {

    private val db = Db(ctx)
    private val sessions = ConcurrentHashMap<String, JSONObject>()
    private val lock = Any()

    private data class Alloc(val itemId: Long, val batchId: Long, val qty: Double, val price: Double, val cost: Double)

    private fun bad(m: String) = ApiException(Response.Status.BAD_REQUEST, m)

    private fun ok(x: Any): Response =
        newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", x.toString())

    override fun serve(s: IHTTPSession): Response {
        return try {
            if (!s.uri.startsWith("/api/")) serveStatic(s.uri)
            else synchronized(lock) { api(s) }
        } catch (e: ApiException) {
            newFixedLengthResponse(e.status, "application/json; charset=utf-8",
                JSONObject().put("error", e.message ?: "خطأ").toString())
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "application/json; charset=utf-8",
                JSONObject().put("error", e.message ?: "خطأ داخلي").toString())
        }
    }

    // ---------- الملفات الثابتة (الواجهة) ----------
    private fun serveStatic(uri: String): Response {
        val path = "www" + (if (uri == "/" || uri.isEmpty()) "/index.html" else uri)
        if (path.contains("..")) throw ApiException(Response.Status.FORBIDDEN, "ممنوع")
        return try {
            val mime = when (path.substringAfterLast('.', "")) {
                "html" -> "text/html; charset=utf-8"
                "js" -> "application/javascript; charset=utf-8"
                "css" -> "text/css; charset=utf-8"
                "png" -> "image/png"
                else -> "application/octet-stream"
            }
            newChunkedResponse(Response.Status.OK, mime, ctx.assets.open(path))
        } catch (e: java.io.FileNotFoundException) {
            newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain; charset=utf-8", "غير موجود")
        }
    }

    // ---------- المسارات ----------
    private fun readBody(s: IHTTPSession): JSONObject {
        val files = HashMap<String, String>()
        s.parseBody(files)
        val raw = files["postData"] ?: return JSONObject()
        return if (raw.isBlank()) JSONObject() else JSONObject(raw)
    }

    private fun api(s: IHTTPSession): Response {
        val path = s.uri.removePrefix("/api/").trim('/')
        val m = s.method
        val get = m == Method.GET
        fun p(k: String): String? = s.parameters[k]?.firstOrNull()?.takeIf { it.isNotBlank() }
        val body = if (m == Method.POST) readBody(s) else JSONObject()

        if (path == "login") return login(body)
        if (path == "ping") return ok(JSONObject().put("ok", true))

        val token = s.headers["x-token"] ?: throw ApiException(Response.Status.UNAUTHORIZED, "سجّل الدخول")
        val user = sessions[token] ?: throw ApiException(Response.Status.UNAUTHORIZED, "انتهت الجلسة")
        fun admin() {
            if (user.getString("role") != "admin") throw ApiException(Response.Status.FORBIDDEN, "هذه العملية للمدير فقط")
        }
        val uid = user.getLong("id")

        return when {
            path == "me" -> ok(user)
            path == "info" -> ok(JSONObject().put("ips", localIps()).put("port", listeningPort))

            path == "items" && get -> ok(listItems(::p))
            path == "items" -> { admin(); ok(saveItem(body)) }

            path == "parties" && get -> {
                val kind = p("kind") ?: "customer"
                val q = Util.norm(p("q") ?: "")
                ok(db.rows("SELECT * FROM parties WHERE kind=? AND active=1 AND name LIKE ? ORDER BY name LIMIT 300", kind, "%$q%"))
            }
            path == "parties" -> {
                val kind = body.optString("kind", "customer")
                if (kind == "supplier") admin()
                ok(saveParty(body))
            }
            path == "payments" -> ok(addPayment(uid, body))

            path == "sales" && get -> {
                val d = p("date") ?: today()
                ok(db.rows("SELECT s.*, IFNULL(p.name,'') AS party_name FROM sales s LEFT JOIN parties p ON p.id=s.party_id WHERE s.created_at BETWEEN ? AND ? ORDER BY s.id DESC LIMIT 500", "$d 00:00:00", "$d 23:59:59"))
            }
            path == "sales" -> ok(createSale(uid, body))
            path.startsWith("sales/") -> {
                val id = path.substringAfter('/')
                val head = db.one("SELECT s.*, IFNULL(p.name,'') AS party_name FROM sales s LEFT JOIN parties p ON p.id=s.party_id WHERE s.id=?", id)
                    ?: throw bad("الفاتورة غير موجودة")
                head.put("lines", db.rows("SELECT l.qty, l.price, i.name FROM sale_lines l JOIN items i ON i.id=l.item_id WHERE l.sale_id=?", id))
                ok(head)
            }

            path == "purchases" && get -> { admin(); ok(db.rows("SELECT pu.*, p.name AS party_name FROM purchases pu JOIN parties p ON p.id=pu.party_id ORDER BY pu.id DESC LIMIT 50")) }
            path == "purchases" -> { admin(); ok(createPurchase(uid, body)) }

            path == "reports/summary" -> { admin(); ok(summary(p("from") ?: today(), p("to") ?: today())) }
            path == "reports/low" -> { admin(); ok(db.rows("SELECT * FROM (SELECT i.id, i.name, i.company, i.min_qty, (SELECT IFNULL(SUM(qty),0) FROM batches b WHERE b.item_id=i.id) AS stock FROM items i WHERE i.active=1 AND i.min_qty>0) WHERE stock<=min_qty ORDER BY name LIMIT 500")) }
            path == "reports/expiring" -> {
                admin()
                val days = (p("days")?.toIntOrNull() ?: 90).coerceIn(1, 1000)
                ok(db.rows("SELECT i.name, b.batch_no, b.expiry, b.qty FROM batches b JOIN items i ON i.id=b.item_id WHERE b.qty>0 AND b.expiry<>'' AND b.expiry<=date('now','localtime','+$days day') ORDER BY b.expiry LIMIT 500"))
            }
            path == "reports/debts" -> { admin(); ok(db.rows("SELECT id, kind, name, phone, balance FROM parties WHERE balance>0.0005 AND active=1 ORDER BY kind, balance DESC")) }

            path == "users" && get -> { admin(); ok(db.rows("SELECT id, name, role, active FROM users ORDER BY id")) }
            path == "users" -> { admin(); ok(saveUser(body)) }

            path == "backup" -> { admin(); backup() }
            else -> throw ApiException(Response.Status.NOT_FOUND, "مسار غير معروف")
        }
    }

    private fun today(): String = db.one("SELECT date('now','localtime') AS d")!!.getString("d")

    private fun login(b: JSONObject): Response {
        val u = db.one("SELECT id, name, role FROM users WHERE name=? AND pin=? AND active=1",
            b.optString("name"), Util.sha(b.optString("pin")))
            ?: throw ApiException(Response.Status.UNAUTHORIZED, "الاسم أو الرمز غير صحيح")
        val t = UUID.randomUUID().toString()
        sessions[t] = u
        return ok(JSONObject().put("token", t).put("user", u))
    }

    private fun localIps(): JSONArray {
        val out = JSONArray()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    val h = a.hostAddress ?: continue
                    if (!a.isLoopbackAddress && !h.contains(':')) out.put(h)
                }
            }
        } catch (_: Exception) {}
        return out
    }

    // ---------- الأصناف ----------
    private fun listItems(p: (String) -> String?): JSONArray {
        val lim = (p("limit")?.toIntOrNull() ?: 40).coerceIn(1, 200)
        val where = StringBuilder("i.active=1")
        val args = ArrayList<String>()
        val bc = p("barcode")
        val q = Util.norm(p("q") ?: "")
        if (bc != null) {
            where.append(" AND i.barcode=?"); args.add(bc)
        } else if (q.isNotEmpty()) {
            where.append(" AND (i.barcode=?")
            args.add(q)
            val words = q.split(" ").filter { it.isNotEmpty() }
            where.append(" OR (1=1")
            for (w in words) { where.append(" AND i.name_norm LIKE ?"); args.add("%$w%") }
            where.append("))")
        }
        val sql = "SELECT i.*, " +
            "(SELECT IFNULL(SUM(qty),0) FROM batches b WHERE b.item_id=i.id) AS stock, " +
            "(SELECT MIN(expiry) FROM batches b WHERE b.item_id=i.id AND b.qty>0 AND b.expiry<>'') AS next_expiry " +
            "FROM items i WHERE $where ORDER BY i.name_norm LIMIT $lim"
        return db.rows(sql, *args.toTypedArray())
    }

    private fun saveItem(b: JSONObject): JSONObject {
        val name = b.optString("name").trim()
        if (name.isEmpty()) throw bad("اسم الصنف مطلوب")
        val cv = ContentValues().apply {
            put("name", name)
            put("name_norm", Util.norm(name))
            put("barcode", b.optString("barcode").trim().ifEmpty { null })
            put("company", b.optString("company"))
            put("unit", b.optString("unit", "علبة"))
            put("cost_price", b.optDouble("cost_price", 0.0))
            put("sell_price", b.optDouble("sell_price", 0.0))
            put("min_qty", b.optDouble("min_qty", 0.0))
        }
        val w = db.writableDatabase
        w.beginTransaction()
        try {
            val id: Long
            if (b.optLong("id", 0) > 0) {
                id = b.getLong("id")
                w.update("items", cv, "id=?", arrayOf(id.toString()))
            } else {
                id = w.insertOrThrow("items", null, cv)
                val q = b.optDouble("opening_qty", 0.0)
                if (q > 0) {
                    val bv = ContentValues().apply {
                        put("item_id", id); put("batch_no", b.optString("batch_no"))
                        put("expiry", b.optString("expiry")); put("qty", q)
                        put("cost", b.optDouble("cost_price", 0.0))
                    }
                    w.insertOrThrow("batches", null, bv)
                }
            }
            w.setTransactionSuccessful()
            return JSONObject().put("id", id)
        } catch (e: SQLiteConstraintException) {
            throw bad("الباركود مستخدم لصنف آخر")
        } finally {
            w.endTransaction()
        }
    }

    // ---------- العملاء والموردون ----------
    private fun saveParty(b: JSONObject): JSONObject {
        val name = b.optString("name").trim()
        if (name.isEmpty()) throw bad("الاسم مطلوب")
        val cv = ContentValues().apply {
            put("kind", b.optString("kind", "customer")); put("name", name); put("phone", b.optString("phone"))
        }
        val w = db.writableDatabase
        val id = if (b.optLong("id", 0) > 0) {
            cv.remove("kind"); w.update("parties", cv, "id=?", arrayOf(b.getLong("id").toString())); b.getLong("id")
        } else w.insertOrThrow("parties", null, cv)
        return JSONObject().put("id", id)
    }

    private fun addPayment(uid: Long, b: JSONObject): JSONObject {
        val amount = Util.r3(b.getDouble("amount"))
        if (amount <= 0) throw bad("المبلغ غير صحيح")
        val pid = b.getLong("party_id")
        val w = db.writableDatabase
        w.beginTransaction()
        try {
            val cv = ContentValues().apply {
                put("created_at", now()); put("user_id", uid); put("party_id", pid)
                put("amount", amount); put("note", b.optString("note"))
            }
            w.insertOrThrow("payments", null, cv)
            w.execSQL("UPDATE parties SET balance=balance-? WHERE id=?", arrayOf<Any?>(amount, pid))
            w.setTransactionSuccessful()
        } finally { w.endTransaction() }
        return JSONObject().put("ok", true)
    }

    private fun now(): String = db.one("SELECT datetime('now','localtime') AS d")!!.getString("d")

    // ---------- فاتورة بيع (FEFO: الأقرب انتهاءً أولاً، ويُمنع بيع المنتهي) ----------
    private fun createSale(uid: Long, b: JSONObject): JSONObject {
        val lines = b.getJSONArray("lines")
        if (lines.length() == 0) throw bad("الفاتورة فارغة")
        val partyId = b.optLong("party_id", 0)
        val w = db.writableDatabase
        w.beginTransaction()
        try {
            val created = now()
            val head = ContentValues().apply {
                put("created_at", created); put("user_id", uid)
                if (partyId > 0) put("party_id", partyId)
                put("note", b.optString("note"))
            }
            val saleId = w.insertOrThrow("sales", null, head)
            var subtotal = 0.0

            for (i in 0 until lines.length()) {
                val l = lines.getJSONObject(i)
                val itemId = l.getLong("item_id")
                val qty = l.getDouble("qty")
                val price = l.getDouble("price")
                if (qty <= 0 || price < 0) throw bad("كمية أو سعر غير صحيح")
                var need = qty
                val allocs = ArrayList<Alloc>()
                w.rawQuery(
                    "SELECT id, qty, cost FROM batches WHERE item_id=? AND qty>0 " +
                        "AND (expiry='' OR expiry>=date('now','localtime')) " +
                        "ORDER BY CASE WHEN expiry='' THEN '9999-12-31' ELSE expiry END, id",
                    arrayOf(itemId.toString())
                ).use { c ->
                    while (need > 1e-9 && c.moveToNext()) {
                        val take = minOf(c.getDouble(1), need)
                        allocs.add(Alloc(itemId, c.getLong(0), take, price, c.getDouble(2)))
                        need -= take
                    }
                }
                if (need > 1e-9) {
                    val n = db.one("SELECT name FROM items WHERE id=?", itemId.toString())?.getString("name") ?: "#$itemId"
                    throw bad("الكمية غير متوفرة (أو منتهية الصلاحية): $n")
                }
                for (a in allocs) {
                    w.execSQL("UPDATE batches SET qty=qty-? WHERE id=?", arrayOf<Any?>(a.qty, a.batchId))
                    val lv = ContentValues().apply {
                        put("sale_id", saleId); put("item_id", a.itemId); put("batch_id", a.batchId)
                        put("qty", a.qty); put("price", a.price); put("cost", a.cost)
                    }
                    w.insertOrThrow("sale_lines", null, lv)
                    subtotal += a.qty * a.price
                }
            }

            subtotal = Util.r3(subtotal)
            val discount = Util.r3(b.optDouble("discount", 0.0).coerceIn(0.0, subtotal))
            val total = Util.r3(subtotal - discount)
            val paid = Util.r3(b.optDouble("paid", total).coerceIn(0.0, total))
            val debt = Util.r3(total - paid)
            if (debt > 0.0005 && partyId <= 0) throw bad("البيع الآجل يحتاج اختيار عميل")
            w.execSQL("UPDATE sales SET subtotal=?, discount=?, total=?, paid=? WHERE id=?",
                arrayOf<Any?>(subtotal, discount, total, paid, saleId))
            if (debt > 0.0005) w.execSQL("UPDATE parties SET balance=balance+? WHERE id=?", arrayOf<Any?>(debt, partyId))
            w.setTransactionSuccessful()
            return JSONObject().put("id", saleId).put("created_at", created)
                .put("subtotal", subtotal).put("discount", discount).put("total", total).put("paid", paid)
        } finally {
            w.endTransaction()
        }
    }

    // ---------- فاتورة شراء ----------
    private fun createPurchase(uid: Long, b: JSONObject): JSONObject {
        val lines = b.getJSONArray("lines")
        if (lines.length() == 0) throw bad("الفاتورة فارغة")
        val partyId = b.optLong("party_id", 0)
        if (partyId <= 0) throw bad("اختر المورد")
        val w = db.writableDatabase
        w.beginTransaction()
        try {
            val head = ContentValues().apply {
                put("created_at", now()); put("user_id", uid); put("party_id", partyId)
                put("ref_no", b.optString("ref_no"))
            }
            val pid = w.insertOrThrow("purchases", null, head)
            var total = 0.0
            for (i in 0 until lines.length()) {
                val l = lines.getJSONObject(i)
                val itemId = l.getLong("item_id")
                val qty = l.getDouble("qty")
                val cost = l.getDouble("cost")
                val batchNo = l.optString("batch_no").trim()
                val expiry = l.optString("expiry").trim()
                val sell = l.optDouble("sell_price", 0.0)
                if (qty <= 0 || cost < 0) throw bad("كمية أو تكلفة غير صحيحة")
                val ex = db.one("SELECT id FROM batches WHERE item_id=? AND batch_no=? AND expiry=?", itemId.toString(), batchNo, expiry)
                if (ex != null) {
                    w.execSQL("UPDATE batches SET qty=qty+?, cost=? WHERE id=?", arrayOf<Any?>(qty, cost, ex.getLong("id")))
                } else {
                    val bv = ContentValues().apply {
                        put("item_id", itemId); put("batch_no", batchNo); put("expiry", expiry)
                        put("qty", qty); put("cost", cost)
                    }
                    w.insertOrThrow("batches", null, bv)
                }
                w.execSQL("UPDATE items SET cost_price=? WHERE id=?", arrayOf<Any?>(cost, itemId))
                if (sell > 0) w.execSQL("UPDATE items SET sell_price=? WHERE id=?", arrayOf<Any?>(sell, itemId))
                val lv = ContentValues().apply {
                    put("purchase_id", pid); put("item_id", itemId); put("batch_no", batchNo)
                    put("expiry", expiry); put("qty", qty); put("cost", cost)
                }
                w.insertOrThrow("purchase_lines", null, lv)
                total += qty * cost
            }
            total = Util.r3(total)
            val paid = Util.r3(b.optDouble("paid", total).coerceIn(0.0, total))
            w.execSQL("UPDATE purchases SET total=?, paid=? WHERE id=?", arrayOf<Any?>(total, paid, pid))
            val debt = Util.r3(total - paid)
            if (debt > 0.0005) w.execSQL("UPDATE parties SET balance=balance+? WHERE id=?", arrayOf<Any?>(debt, partyId))
            w.setTransactionSuccessful()
            return JSONObject().put("id", pid).put("total", total)
        } finally {
            w.endTransaction()
        }
    }

    // ---------- التقارير ----------
    private fun summary(from: String, to: String): JSONObject {
        val a = "$from 00:00:00"; val z = "$to 23:59:59"
        val s = db.one("SELECT COUNT(*) AS n, IFNULL(SUM(total),0) AS total, IFNULL(SUM(paid),0) AS paid, IFNULL(SUM(discount),0) AS discount FROM sales WHERE created_at BETWEEN ? AND ?", a, z)!!
        val gross = db.one("SELECT IFNULL(SUM((l.price-l.cost)*l.qty),0) AS g FROM sale_lines l JOIN sales s ON s.id=l.sale_id WHERE s.created_at BETWEEN ? AND ?", a, z)!!.getDouble("g")
        s.put("profit", Util.r3(gross - s.getDouble("discount")))
        s.put("purchases", db.one("SELECT IFNULL(SUM(total),0) AS t FROM purchases WHERE created_at BETWEEN ? AND ?", a, z)!!.getDouble("t"))
        s.put("top", db.rows("SELECT i.name, SUM(l.qty) AS qty, SUM(l.qty*l.price) AS amount FROM sale_lines l JOIN sales s ON s.id=l.sale_id JOIN items i ON i.id=l.item_id WHERE s.created_at BETWEEN ? AND ? GROUP BY l.item_id ORDER BY amount DESC LIMIT 10", a, z))
        return s
    }

    // ---------- المستخدمون والنسخ الاحتياطي ----------
    private fun saveUser(b: JSONObject): JSONObject {
        val name = b.optString("name").trim()
        val pin = b.optString("pin")
        if (name.isEmpty()) throw bad("الاسم مطلوب")
        val w = db.writableDatabase
        val id = b.optLong("id", 0)
        try {
            if (id > 0) {
                if (pin.isNotEmpty()) w.execSQL("UPDATE users SET pin=? WHERE id=?", arrayOf<Any?>(Util.sha(pin), id))
                w.execSQL("UPDATE users SET name=?, role=?, active=? WHERE id=?",
                    arrayOf<Any?>(name, b.optString("role", "cashier"), b.optInt("active", 1), id))
            } else {
                if (pin.length < 4) throw bad("الرمز 4 أرقام على الأقل")
                val cv = ContentValues().apply {
                    put("name", name); put("pin", Util.sha(pin)); put("role", b.optString("role", "cashier"))
                }
                w.insertOrThrow("users", null, cv)
            }
        } catch (e: SQLiteConstraintException) { throw bad("الاسم مستخدم") }
        sessions.clear() // إجبار الجميع على تسجيل الدخول من جديد بعد تغيير المستخدمين
        return JSONObject().put("ok", true)
    }

    private fun backup(): Response {
        db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() }
        val f = File(db.writableDatabase.path)
        val r = newFixedLengthResponse(Response.Status.OK, "application/octet-stream", FileInputStream(f), f.length())
        r.addHeader("Content-Disposition", "attachment; filename=pharmacy-backup.db")
        return r
    }
}
