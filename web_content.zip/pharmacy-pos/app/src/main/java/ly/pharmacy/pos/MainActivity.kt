package ly.pharmacy.pos

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * وضعان:
 *  - خادم: يشغّل خدمة الخادم ويفتح الواجهة محلياً.
 *  - نقطة بيع: يفتح واجهة الخادم عبر شبكة الواي فاي (عنوان IP).
 */
class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private var web: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        when (prefs.getString("mode", null)) {
            "server" -> { startServer(); openWeb("http://127.0.0.1:${ServerService.PORT}/") }
            "client" -> openWeb("http://${prefs.getString("ip", "")}:${ServerService.PORT}/")
            else -> showSetup()
        }
    }

    private fun startServer() {
        startForegroundService(Intent(this, ServerService::class.java))
    }

    private fun showSetup() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "إعداد هذا الجهاز"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.BLACK)
        })
        val serverBtn = Button(this).apply { text = "هذا الجهاز هو الخادم (يحمل قاعدة البيانات)" }
        val ip = EditText(this).apply {
            hint = "عنوان IP للخادم مثل 192.168.1.10"
            inputType = InputType.TYPE_CLASS_PHONE
            gravity = Gravity.CENTER
        }
        val clientBtn = Button(this).apply { text = "نقطة بيع (اتصال بالخادم)" }
        root.addView(serverBtn); root.addView(ip); root.addView(clientBtn)
        setContentView(root)

        serverBtn.setOnClickListener {
            prefs.edit().putString("mode", "server").apply()
            startServer()
            openWeb("http://127.0.0.1:${ServerService.PORT}/")
        }
        clientBtn.setOnClickListener {
            val v = ip.text.toString().trim()
            if (v.isEmpty()) { ip.error = "أدخل عنوان IP"; return@setOnClickListener }
            prefs.edit().putString("mode", "client").putString("ip", v).apply()
            openWeb("http://$v:${ServerService.PORT}/")
        }
    }

    private inner class Bridge {
        @JavascriptInterface
        fun print() {
            runOnUiThread {
                val w = web ?: return@runOnUiThread
                val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print("فاتورة", w.createPrintDocumentAdapter("فاتورة"), PrintAttributes.Builder().build())
            }
        }

        @JavascriptInterface
        fun resetMode() {
            prefs.edit().clear().apply()
            stopService(Intent(this@MainActivity, ServerService::class.java))
            runOnUiThread { recreate() }
        }

        @JavascriptInterface
        fun mode(): String = prefs.getString("mode", "") ?: ""
    }

    private fun openWeb(url: String) {
        val w = WebView(this)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "AndroidBridge")
        w.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView, req: WebResourceRequest, err: WebResourceError) {
                if (req.isForMainFrame) {
                    view.loadDataWithBaseURL(null,
                        "<html dir='rtl'><body style='font-family:sans-serif;text-align:center;padding:40px'>" +
                            "<h2>تعذّر الاتصال بالخادم</h2><p>تأكد أن جهاز الخادم شغّال وأن الواي فاي متصل.</p>" +
                            "<p><a href='$url'>إعادة المحاولة</a></p></body></html>",
                        "text/html", "utf-8", null)
                }
            }
        }
        setContentView(w)
        // الخدمة تحتاج لحظات لتبدأ في وضع الخادم
        w.postDelayed({ w.loadUrl(url) }, if (prefs.getString("mode", "") == "server") 700L else 0L)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }
}
