package ly.pharmacy.pos

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import fi.iki.elonen.NanoHTTPD

/** خدمة تبقي الخادم شغالاً حتى لو أُغلقت الشاشة. */
class ServerService : Service() {

    companion object {
        const val PORT = 8080
        @Volatile var server: PosServer? = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("srv", "خادم الصيدلية", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "srv")
            .setContentTitle("خادم الصيدلية يعمل")
            .setContentText("نقاط البيع تتصل عبر المنفذ $PORT")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        if (server == null) {
            server = PosServer(applicationContext, PORT).also {
                it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        server?.stop()
        server = null
        super.onDestroy()
    }
}
