package ly.pharmacy.pos

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

object Util {
    private val tashkeel = Regex("[ً-ْـ]")

    /** تطبيع النص العربي/الإنجليزي للبحث: حروف صغيرة، توحيد الألف والياء والتاء المربوطة، حذف التشكيل. */
    fun norm(s: String): String = tashkeel.replace(s.lowercase().trim(), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه')

    /** الدينار الليبي 3 خانات عشرية */
    fun r3(x: Double): Double = Math.round(x * 1000.0) / 1000.0

    fun sha(s: String): String = MessageDigest.getInstance("SHA-256")
        .digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

class Db(private val ctx: Context) : SQLiteOpenHelper(ctx, "pharmacy.db", null, 1) {

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        val sql = ctx.assets.open("schema.sql").bufferedReader(Charsets.UTF_8).readText()
        sql.split(";").map { it.trim() }.filter { it.isNotEmpty() }.forEach { db.execSQL(it) }
        // المدير الافتراضي — غيّر الرمز بعد أول دخول
        val cv = ContentValues().apply {
            put("name", "admin"); put("pin", Util.sha("1234")); put("role", "admin")
        }
        db.insert("users", null, cv)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun rows(sql: String, vararg args: String): JSONArray {
        val out = JSONArray()
        writableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) {
                val o = JSONObject()
                for (i in 0 until c.columnCount) {
                    val n = c.getColumnName(i)
                    when (c.getType(i)) {
                        Cursor.FIELD_TYPE_NULL -> o.put(n, JSONObject.NULL)
                        Cursor.FIELD_TYPE_INTEGER -> o.put(n, c.getLong(i))
                        Cursor.FIELD_TYPE_FLOAT -> o.put(n, c.getDouble(i))
                        else -> o.put(n, c.getString(i))
                    }
                }
                out.put(o)
            }
        }
        return out
    }

    fun one(sql: String, vararg args: String): JSONObject? {
        val r = rows(sql, *args)
        return if (r.length() > 0) r.getJSONObject(0) else null
    }
}
