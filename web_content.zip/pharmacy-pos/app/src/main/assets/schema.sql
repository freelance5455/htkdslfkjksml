CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  pin TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'cashier',
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS items(
  id INTEGER PRIMARY KEY,
  barcode TEXT,
  name TEXT NOT NULL,
  name_norm TEXT NOT NULL,
  company TEXT DEFAULT '',
  unit TEXT DEFAULT 'علبة',
  cost_price REAL NOT NULL DEFAULT 0,
  sell_price REAL NOT NULL DEFAULT 0,
  min_qty REAL NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_items_barcode ON items(barcode) WHERE barcode IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_items_norm ON items(name_norm);

CREATE TABLE IF NOT EXISTS batches(
  id INTEGER PRIMARY KEY,
  item_id INTEGER NOT NULL REFERENCES items(id),
  batch_no TEXT NOT NULL DEFAULT '',
  expiry TEXT NOT NULL DEFAULT '',
  qty REAL NOT NULL DEFAULT 0,
  cost REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_batches_item ON batches(item_id, expiry);
CREATE INDEX IF NOT EXISTS idx_batches_expiry ON batches(expiry);

CREATE TABLE IF NOT EXISTS parties(
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  phone TEXT DEFAULT '',
  balance REAL NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_parties_kind ON parties(kind, name);

CREATE TABLE IF NOT EXISTS sales(
  id INTEGER PRIMARY KEY,
  created_at TEXT NOT NULL,
  user_id INTEGER,
  party_id INTEGER,
  subtotal REAL NOT NULL DEFAULT 0,
  discount REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL DEFAULT 0,
  paid REAL NOT NULL DEFAULT 0,
  note TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(created_at);

CREATE TABLE IF NOT EXISTS sale_lines(
  id INTEGER PRIMARY KEY,
  sale_id INTEGER NOT NULL REFERENCES sales(id),
  item_id INTEGER NOT NULL,
  batch_id INTEGER NOT NULL,
  qty REAL NOT NULL,
  price REAL NOT NULL,
  cost REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sale_lines_sale ON sale_lines(sale_id);
CREATE INDEX IF NOT EXISTS idx_sale_lines_item ON sale_lines(item_id);

CREATE TABLE IF NOT EXISTS purchases(
  id INTEGER PRIMARY KEY,
  created_at TEXT NOT NULL,
  user_id INTEGER,
  party_id INTEGER NOT NULL,
  ref_no TEXT DEFAULT '',
  total REAL NOT NULL DEFAULT 0,
  paid REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(created_at);

CREATE TABLE IF NOT EXISTS purchase_lines(
  id INTEGER PRIMARY KEY,
  purchase_id INTEGER NOT NULL REFERENCES purchases(id),
  item_id INTEGER NOT NULL,
  batch_no TEXT NOT NULL DEFAULT '',
  expiry TEXT NOT NULL DEFAULT '',
  qty REAL NOT NULL,
  cost REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_purchase_lines_p ON purchase_lines(purchase_id);

CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY,
  created_at TEXT NOT NULL,
  user_id INTEGER,
  party_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  note TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_payments_party ON payments(party_id)
