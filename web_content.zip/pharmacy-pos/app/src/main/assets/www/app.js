'use strict';
// ================= أدوات عامة =================
let token = '';
let me = null;
try { token = localStorage.getItem('tok') || ''; } catch (e) {}

const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = n => (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
const qfmt = n => (Number(n) || 0).toLocaleString('en-US', { maximumFractionDigits: 3 });
const todayStr = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const main = () => $('#main');

function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg; t.className = 'on' + (bad ? ' bad' : '');
  clearTimeout(toast.t); toast.t = setTimeout(() => { t.className = ''; }, 2600);
}

async function api(path, body) {
  const r = await fetch('/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'X-Token': token },
    body: body ? JSON.stringify(body) : undefined
  });
  let j = {};
  try { j = await r.json(); } catch (e) {}
  if (r.status === 401 && path !== '/login') { logout(); throw new Error('انتهت الجلسة'); }
  if (!r.ok) throw new Error(j.error || 'خطأ');
  return j;
}
const run = async fn => { try { return await fn(); } catch (e) { toast(e.message, true); } };

function logout() {
  token = ''; me = null;
  try { localStorage.removeItem('tok'); } catch (e) {}
  $('#app').classList.add('hidden'); $('#login').classList.remove('hidden');
}

function shopName() { try { return localStorage.getItem('shop') || 'الصيدلية'; } catch (e) { return 'الصيدلية'; } }

// ================= الدخول والتنقل =================
$('#loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  try {
    const r = await api('/login', { name: $('#lu').value.trim(), pin: $('#lp').value });
    token = r.token; me = r.user;
    try { localStorage.setItem('tok', token); } catch (x) {}
    $('#lp').value = ''; $('#lerr').textContent = '';
    start();
  } catch (x) { $('#lerr').textContent = x.message; }
});

const PAGES = [
  { id: 'pos', t: 'نقطة البيع', fn: pagePOS },
  { id: 'purchases', t: 'المشتريات', fn: pagePurchases, admin: true },
  { id: 'items', t: 'الأصناف', fn: pageItems, admin: true },
  { id: 'parties', t: 'العملاء والموردون', fn: pageParties },
  { id: 'sales', t: 'فواتير اليوم', fn: pageSales },
  { id: 'reports', t: 'التقارير', fn: pageReports, admin: true },
  { id: 'settings', t: 'الإعدادات', fn: pageSettings }
];

function start() {
  $('#login').classList.add('hidden'); $('#app').classList.remove('hidden');
  const pages = PAGES.filter(p => !p.admin || me.role === 'admin');
  $('#nav').innerHTML = pages.map(p => `<button data-p="${p.id}">${p.t}</button>`).join('') +
    `<span class="sp"></span><button id="out">خروج (${esc(me.name)})</button>`;
  $('#nav').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.id === 'out') return logout();
    go(b.dataset.p);
  };
  go('pos');
}

function go(id) {
  const p = PAGES.find(x => x.id === id);
  document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.p === id));
  run(() => p.fn());
}

(async () => {
  if (!token) return logout();
  try { me = await api('/me'); start(); } catch (e) { logout(); }
})();

// ================= الإيصال والطباعة =================
function printReceipt(sale, cart, partyName) {
  const rows = cart.map(l => `<tr><td>${esc(l.name)}</td><td class="num">${qfmt(l.qty)}</td><td class="num">${fmt(l.price)}</td><td class="num">${fmt(l.qty * l.price)}</td></tr>`).join('');
  $('#receipt').innerHTML = `
    <h3>${esc(shopName())}</h3>
    <p>فاتورة رقم ${sale.id} — ${esc(sale.created_at)}</p>
    ${partyName ? `<p>العميل: ${esc(partyName)}</p>` : ''}
    <table><tr><th>الصنف</th><th>كمية</th><th>سعر</th><th>مجموع</th></tr>${rows}</table>
    <p>الإجمالي: ${fmt(sale.subtotal)}</p>
    ${sale.discount > 0 ? `<p>الخصم: ${fmt(sale.discount)}</p>` : ''}
    <h3>الصافي: ${fmt(sale.total)} د.ل</h3>
    <p>المدفوع: ${fmt(sale.paid)}</p>
    <p>مع تمنياتنا بالشفاء العاجل</p>`;
  if (window.AndroidBridge && window.AndroidBridge.print) window.AndroidBridge.print();
  else window.print();
}

// ================= نقطة البيع =================
let cart = [];
let posParty = null;

async function pagePOS() {
  main().innerHTML = `
  <div class="grid two">
    <div>
      <div class="card">
        <input id="q" class="grow" placeholder="ابحث بالاسم أو امسح الباركود ثم Enter" autocomplete="off">
        <div id="res" style="margin-top:8px"></div>
      </div>
      <div class="card"><table><thead><tr><th>الصنف</th><th class="num">الكمية</th><th class="num">السعر</th><th class="num">المجموع</th><th></th></tr></thead><tbody id="cart"></tbody></table></div>
    </div>
    <div class="card">
      <div class="f"><label>العميل (اختياري للنقدي، مطلوب للآجل)</label><select id="party"><option value="">— بدون —</option></select></div>
      <div class="row" style="margin-top:8px">
        <div class="f"><label>الخصم</label><input id="disc" type="number" step="0.001" min="0" value="0"></div>
        <div class="f"><label>المدفوع</label><input id="paid" type="number" step="0.001" min="0"></div>
      </div>
      <div>الإجمالي: <span id="sub">0.000</span></div>
      <div class="total" id="net">0.000</div>
      <div id="debt" class="low"></div>
      <div class="row" style="margin-top:10px">
        <button class="btn primary grow" id="save">حفظ وطباعة</button>
        <button class="btn" id="clear">فاتورة جديدة</button>
      </div>
    </div>
  </div>`;

  const parties = await api('/parties?kind=customer');
  $('#party').innerHTML = '<option value="">— بدون —</option>' + parties.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  if (posParty) $('#party').value = posParty;
  $('#party').onchange = () => { posParty = $('#party').value; };

  const q = $('#q'); q.focus();
  let timer;
  q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(search, 150); });
  q.addEventListener('keydown', async e => {
    if (e.key !== 'Enter') return;
    const v = q.value.trim(); if (!v) return;
    const r = await run(() => api('/items?limit=40&q=' + encodeURIComponent(v)));
    if (!r) return;
    const hit = r.find(x => x.barcode === v) || (r.length === 1 ? r[0] : null);
    if (hit) { addToCart(hit); q.value = ''; $('#res').innerHTML = ''; }
  });
  $('#disc').oninput = totals; $('#paid').oninput = () => { $('#paid').dataset.touched = '1'; totals(); };
  $('#clear').onclick = () => { cart = []; renderCart(); q.focus(); };
  $('#save').onclick = saveSale;
  renderCart();

  async function search() {
    const v = q.value.trim();
    if (!v) { $('#res').innerHTML = ''; return; }
    const r = await run(() => api('/items?limit=15&q=' + encodeURIComponent(v)));
    if (!r) return;
    $('#res').innerHTML = r.length ? `<table><tbody>${r.map(i => `
      <tr class="click" data-id="${i.id}">
        <td>${esc(i.name)}<br><small>${esc(i.company)}</small></td>
        <td class="num ${i.stock <= 0 ? 'low' : ''}">${qfmt(i.stock)}</td>
        <td class="num">${fmt(i.sell_price)}</td>
        <td><small>${esc(i.next_expiry || '')}</small></td></tr>`).join('')}</tbody></table>` : '<small>لا نتائج</small>';
    $('#res').onclick = e => {
      const tr = e.target.closest('tr'); if (!tr) return;
      addToCart(r.find(x => x.id == tr.dataset.id)); q.value = ''; $('#res').innerHTML = ''; q.focus();
    };
  }
}

function addToCart(i) {
  if (i.stock <= 0) return toast('لا يوجد مخزون لهذا الصنف', true);
  const ex = cart.find(l => l.item_id === i.id);
  if (ex) ex.qty += 1;
  else cart.push({ item_id: i.id, name: i.name, price: i.sell_price, qty: 1, stock: i.stock });
  renderCart();
}

function renderCart() {
  const tb = $('#cart'); if (!tb) return;
  tb.innerHTML = cart.map((l, k) => `<tr>
    <td>${esc(l.name)}</td>
    <td class="num"><input type="number" min="0.001" step="any" value="${l.qty}" data-k="${k}" data-f="qty" style="width:80px"></td>
    <td class="num">${me.role === 'admin' ? `<input type="number" step="0.001" value="${l.price}" data-k="${k}" data-f="price" style="width:90px">` : fmt(l.price)}</td>
    <td class="num">${fmt(l.qty * l.price)}</td>
    <td><button class="btn sm danger" data-del="${k}">✕</button></td></tr>`).join('');
  tb.oninput = e => {
    const k = e.target.dataset.k; if (k === undefined) return;
    cart[k][e.target.dataset.f] = parseFloat(e.target.value) || 0; totals(true);
  };
  tb.onclick = e => { const d = e.target.dataset.del; if (d !== undefined) { cart.splice(d, 1); renderCart(); } };
  totals();
}

function totals(keepRows) {
  const sub = cart.reduce((s, l) => s + l.qty * l.price, 0);
  const disc = Math.min(parseFloat($('#disc').value) || 0, sub);
  const net = sub - disc;
  $('#sub').textContent = fmt(sub); $('#net').textContent = fmt(net);
  const paid = $('#paid');
  if (!paid.dataset.touched) paid.value = net.toFixed(3);
  const debt = net - (parseFloat(paid.value) || 0);
  $('#debt').textContent = debt > 0.0005 ? 'آجل: ' + fmt(debt) : '';
  if (keepRows) {
    const rows = document.querySelectorAll('#cart tr');
    rows.forEach((tr, k) => { if (cart[k]) tr.children[3].textContent = fmt(cart[k].qty * cart[k].price); });
  }
}

async function saveSale() {
  if (!cart.length) return toast('الفاتورة فارغة', true);
  const partyId = $('#party').value;
  const r = await run(() => api('/sales', {
    party_id: partyId ? Number(partyId) : 0,
    discount: parseFloat($('#disc').value) || 0,
    paid: parseFloat($('#paid').value) || 0,
    lines: cart.map(l => ({ item_id: l.item_id, qty: l.qty, price: l.price }))
  }));
  if (!r) return;
  const name = partyId ? $('#party').selectedOptions[0].textContent : '';
  const printed = cart.slice();
  cart = []; posParty = null;
  toast('تم حفظ الفاتورة رقم ' + r.id);
  await pagePOS();
  printReceipt(r, printed, name);
}

// ================= المشتريات =================
let pcart = [];
async function pagePurchases() {
  const sup = await api('/parties?kind=supplier');
  main().innerHTML = `
  <div class="card">
    <div class="row">
      <div class="f"><label>المورد</label><select id="sup">${sup.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div>
      <div class="f"><label>رقم فاتورة المورد</label><input id="ref"></div>
    </div>
    <input id="pq" class="grow" placeholder="ابحث عن صنف أو امسح الباركود" autocomplete="off">
    <div id="pres" style="margin-top:8px"></div>
  </div>
  <div class="card" style="overflow-x:auto"><table>
    <thead><tr><th>الصنف</th><th>التشغيلة</th><th>الانتهاء</th><th class="num">الكمية</th><th class="num">التكلفة</th><th class="num">سعر البيع</th><th class="num">المجموع</th><th></th></tr></thead>
    <tbody id="pcart"></tbody></table>
    <div class="row" style="margin-top:10px">
      <div>الإجمالي: <b id="ptot">0.000</b></div>
      <div class="f"><label>المدفوع للمورد</label><input id="ppaid" type="number" step="0.001" min="0"></div>
      <button class="btn primary" id="psave">حفظ فاتورة الشراء</button>
    </div>
  </div>
  <div class="card"><b>آخر المشتريات</b><div id="plist"></div></div>`;
  if (!sup.length) toast('أضف مورداً أولاً من صفحة العملاء والموردون', true);

  const q = $('#pq');
  let timer;
  const add = i => {
    pcart.push({ item_id: i.id, name: i.name, batch_no: '', expiry: '', qty: 1, cost: i.cost_price, sell_price: i.sell_price });
    q.value = ''; $('#pres').innerHTML = ''; renderP(); q.focus();
  };
  const search = async enter => {
    const v = q.value.trim(); if (!v) { $('#pres').innerHTML = ''; return; }
    const r = await run(() => api('/items?limit=15&q=' + encodeURIComponent(v))); if (!r) return;
    if (enter) { const hit = r.find(x => x.barcode === v) || (r.length === 1 ? r[0] : null); if (hit) return add(hit); }
    $('#pres').innerHTML = `<table><tbody>${r.map(i => `<tr class="click" data-id="${i.id}"><td>${esc(i.name)}</td><td>${esc(i.company)}</td><td class="num">${qfmt(i.stock)}</td></tr>`).join('')}</tbody></table>`;
    $('#pres').onclick = e => { const tr = e.target.closest('tr'); if (tr) add(r.find(x => x.id == tr.dataset.id)); };
  };
  q.oninput = () => { clearTimeout(timer); timer = setTimeout(() => search(false), 150); };
  q.onkeydown = e => { if (e.key === 'Enter') search(true); };
  $('#psave').onclick = savePurchase;
  renderP();
  const list = await api('/purchases');
  $('#plist').innerHTML = `<table><tbody>${list.map(p => `<tr><td>#${p.id}</td><td>${esc(p.created_at)}</td><td>${esc(p.party_name)}</td><td class="num">${fmt(p.total)}</td></tr>`).join('')}</tbody></table>`;
}

function renderP() {
  const tb = $('#pcart'); if (!tb) return;
  tb.innerHTML = pcart.map((l, k) => `<tr>
    <td>${esc(l.name)}</td>
    <td><input data-k="${k}" data-f="batch_no" value="${esc(l.batch_no)}" style="width:90px"></td>
    <td><input type="date" data-k="${k}" data-f="expiry" value="${esc(l.expiry)}"></td>
    <td class="num"><input type="number" step="any" min="0" data-k="${k}" data-f="qty" value="${l.qty}" style="width:70px"></td>
    <td class="num"><input type="number" step="0.001" min="0" data-k="${k}" data-f="cost" value="${l.cost}" style="width:80px"></td>
    <td class="num"><input type="number" step="0.001" min="0" data-k="${k}" data-f="sell_price" value="${l.sell_price}" style="width:80px"></td>
    <td class="num">${fmt(l.qty * l.cost)}</td>
    <td><button class="btn sm danger" data-del="${k}">✕</button></td></tr>`).join('');
  tb.oninput = e => {
    const k = e.target.dataset.k; if (k === undefined) return;
    const f = e.target.dataset.f;
    pcart[k][f] = (f === 'batch_no' || f === 'expiry') ? e.target.value : (parseFloat(e.target.value) || 0);
    if (f === 'qty' || f === 'cost') { e.target.closest('tr').children[6].textContent = fmt(pcart[k].qty * pcart[k].cost); }
    ptotals();
  };
  tb.onclick = e => { const d = e.target.dataset.del; if (d !== undefined) { pcart.splice(d, 1); renderP(); } };
  ptotals(true);
}
function ptotals(reset) {
  const t = pcart.reduce((s, l) => s + l.qty * l.cost, 0);
  $('#ptot').textContent = fmt(t);
  if (reset || !$('#ppaid').dataset.touched) $('#ppaid').value = t.toFixed(3);
}
async function savePurchase() {
  if (!pcart.length) return toast('الفاتورة فارغة', true);
  const r = await run(() => api('/purchases', {
    party_id: Number($('#sup').value) || 0, ref_no: $('#ref').value,
    paid: parseFloat($('#ppaid').value) || 0, lines: pcart
  }));
  if (!r) return;
  pcart = []; toast('تم حفظ فاتورة الشراء رقم ' + r.id); pagePurchases();
}

// ================= الأصناف =================
async function pageItems() {
  main().innerHTML = `
  <div class="card"><div class="row">
    <input id="iq" class="grow" placeholder="ابحث في الأصناف" autocomplete="off">
    <button class="btn primary" id="inew">+ صنف جديد</button></div>
    <div style="overflow-x:auto"><table><thead><tr><th>الصنف</th><th>الشركة</th><th>الباركود</th><th class="num">التكلفة</th><th class="num">البيع</th><th class="num">المخزون</th><th>أقرب انتهاء</th><th></th></tr></thead>
    <tbody id="ilist"></tbody></table></div></div>`;
  let timer, rows = [];
  const load = async () => {
    const r = await run(() => api('/items?limit=100&q=' + encodeURIComponent($('#iq').value.trim()))); if (!r) return;
    rows = r;
    $('#ilist').innerHTML = r.map(i => `<tr>
      <td>${esc(i.name)}</td><td>${esc(i.company)}</td><td>${esc(i.barcode || '')}</td>
      <td class="num">${fmt(i.cost_price)}</td><td class="num">${fmt(i.sell_price)}</td>
      <td class="num ${i.min_qty > 0 && i.stock <= i.min_qty ? 'low' : ''}">${qfmt(i.stock)}</td>
      <td>${esc(i.next_expiry || '')}</td><td><button class="btn sm" data-e="${i.id}">تعديل</button></td></tr>`).join('');
  };
  $('#iq').oninput = () => { clearTimeout(timer); timer = setTimeout(load, 200); };
  $('#ilist').onclick = e => { const id = e.target.dataset.e; if (id) itemForm(rows.find(x => x.id == id), load); };
  $('#inew').onclick = () => itemForm(null, load);
  load();
}

function itemForm(it, done) {
  const isNew = !it; it = it || {};
  const m = document.createElement('div'); m.className = 'modal';
  m.innerHTML = `<div class="card"><h3>${isNew ? 'صنف جديد' : 'تعديل صنف'}</h3>
    <div class="row"><div class="f"><label>الاسم</label><input id="f_name" value="${esc(it.name)}"></div>
    <div class="f"><label>الشركة</label><input id="f_company" value="${esc(it.company)}"></div></div>
    <div class="row"><div class="f"><label>الباركود</label><input id="f_barcode" value="${esc(it.barcode || '')}"></div>
    <div class="f"><label>الوحدة</label><input id="f_unit" value="${esc(it.unit || 'علبة')}"></div></div>
    <div class="row"><div class="f"><label>سعر التكلفة</label><input id="f_cost" type="number" step="0.001" value="${it.cost_price || 0}"></div>
    <div class="f"><label>سعر البيع</label><input id="f_sell" type="number" step="0.001" value="${it.sell_price || 0}"></div>
    <div class="f"><label>حد الطلب (تنبيه النواقص)</label><input id="f_min" type="number" step="any" value="${it.min_qty || 0}"></div></div>
    ${isNew ? `<hr><b>رصيد افتتاحي (اختياري)</b><div class="row">
      <div class="f"><label>الكمية</label><input id="f_oq" type="number" step="any" value="0"></div>
      <div class="f"><label>التشغيلة</label><input id="f_ob"></div>
      <div class="f"><label>الانتهاء</label><input id="f_oe" type="date"></div></div>` : ''}
    <div class="row"><button class="btn primary" id="f_save">حفظ</button><button class="btn" id="f_cancel">إلغاء</button></div></div>`;
  document.body.appendChild(m);
  $('#f_name', m).focus();
  $('#f_cancel', m).onclick = () => m.remove();
  $('#f_save', m).onclick = async () => {
    const body = {
      id: it.id || 0, name: $('#f_name', m).value, company: $('#f_company', m).value,
      barcode: $('#f_barcode', m).value, unit: $('#f_unit', m).value,
      cost_price: parseFloat($('#f_cost', m).value) || 0, sell_price: parseFloat($('#f_sell', m).value) || 0,
      min_qty: parseFloat($('#f_min', m).value) || 0
    };
    if (isNew) { body.opening_qty = parseFloat($('#f_oq', m).value) || 0; body.batch_no = $('#f_ob', m).value; body.expiry = $('#f_oe', m).value; }
    const r = await run(() => api('/items', body));
    if (r) { m.remove(); toast('تم الحفظ'); done(); }
  };
}

// ================= العملاء والموردون =================
let partyKind = 'customer';
async function pageParties() {
  const isAdmin = me.role === 'admin';
  if (!isAdmin) partyKind = 'customer';
  main().innerHTML = `
  <div class="card">
    ${isAdmin ? `<div class="tabs"><button class="btn ${partyKind === 'customer' ? 'on' : ''}" data-k="customer">العملاء</button><button class="btn ${partyKind === 'supplier' ? 'on' : ''}" data-k="supplier">الموردون</button></div>` : ''}
    <div class="row"><input id="pn" class="grow" placeholder="اسم جديد"><input id="pp" placeholder="الهاتف"><button class="btn primary" id="padd">إضافة</button></div>
    <table><thead><tr><th>الاسم</th><th>الهاتف</th><th class="num">${partyKind === 'customer' ? 'عليه' : 'له'}</th><th></th></tr></thead><tbody id="plist2"></tbody></table>
  </div>`;
  document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => { partyKind = b.dataset.k; pageParties(); });
  const rows = await api('/parties?kind=' + partyKind);
  $('#plist2').innerHTML = rows.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.phone)}</td>
    <td class="num ${p.balance > 0.0005 ? 'low' : ''}">${fmt(p.balance)}</td>
    <td>${p.balance > 0.0005 ? `<button class="btn sm" data-pay="${p.id}" data-n="${esc(p.name)}">تسديد</button>` : ''}</td></tr>`).join('');
  $('#plist2').onclick = async e => {
    const id = e.target.dataset.pay; if (!id) return;
    const v = prompt('مبلغ التسديد من/إلى ' + e.target.dataset.n);
    const a = parseFloat(v); if (!a || a <= 0) return;
    const r = await run(() => api('/payments', { party_id: Number(id), amount: a }));
    if (r) { toast('تم التسجيل'); pageParties(); }
  };
  $('#padd').onclick = async () => {
    const r = await run(() => api('/parties', { kind: partyKind, name: $('#pn').value, phone: $('#pp').value }));
    if (r) { toast('تمت الإضافة'); pageParties(); }
  };
}

// ================= فواتير اليوم =================
async function pageSales() {
  main().innerHTML = `<div class="card"><div class="row"><input id="sd" type="date" value="${todayStr()}"></div>
    <table><thead><tr><th>#</th><th>الوقت</th><th>العميل</th><th class="num">الصافي</th><th class="num">المدفوع</th><th></th></tr></thead><tbody id="slist"></tbody></table></div>`;
  const load = async () => {
    const r = await run(() => api('/sales?date=' + $('#sd').value)); if (!r) return;
    $('#slist').innerHTML = r.map(s => `<tr><td>${s.id}</td><td>${esc(s.created_at.slice(11, 16))}</td><td>${esc(s.party_name)}</td>
      <td class="num">${fmt(s.total)}</td><td class="num">${fmt(s.paid)}</td><td><button class="btn sm" data-r="${s.id}">طباعة</button></td></tr>`).join('');
  };
  $('#sd').onchange = load;
  $('#slist').onclick = async e => {
    const id = e.target.dataset.r; if (!id) return;
    const s = await run(() => api('/sales/' + id)); if (!s) return;
    printReceipt(s, s.lines.map(l => ({ name: l.name, qty: l.qty, price: l.price })), s.party_name);
  };
  load();
}

// ================= التقارير =================
async function pageReports() {
  main().innerHTML = `
  <div class="card"><div class="row">
    <div class="f"><label>من</label><input id="rf" type="date" value="${todayStr()}"></div>
    <div class="f"><label>إلى</label><input id="rt" type="date" value="${todayStr()}"></div>
    <button class="btn primary" id="rgo">عرض</button></div></div>
  <div id="rsum"></div>
  <div class="grid two">
    <div class="card"><b>نواقص (المخزون ≤ حد الطلب)</b><div id="rlow"></div></div>
    <div class="card"><b>قرب انتهاء الصلاحية (90 يوماً)</b><div id="rexp"></div></div>
  </div>
  <div class="card"><b>الديون</b><div id="rdebt"></div></div>`;
  const load = async () => {
    const s = await run(() => api(`/reports/summary?from=${$('#rf').value}&to=${$('#rt').value}`)); if (!s) return;
    $('#rsum').innerHTML = `<div class="stats">
      <div class="stat">عدد الفواتير<b>${s.n}</b></div>
      <div class="stat">المبيعات<b>${fmt(s.total)}</b></div>
      <div class="stat">صافي الربح<b>${fmt(s.profit)}</b></div>
      <div class="stat">المشتريات<b>${fmt(s.purchases)}</b></div></div>
      <div class="card"><b>الأكثر مبيعاً</b><table><tbody>${s.top.map(t => `<tr><td>${esc(t.name)}</td><td class="num">${qfmt(t.qty)}</td><td class="num">${fmt(t.amount)}</td></tr>`).join('')}</tbody></table></div>`;
  };
  $('#rgo').onclick = load; load();
  const low = await api('/reports/low');
  $('#rlow').innerHTML = `<table><tbody>${low.map(i => `<tr><td>${esc(i.name)}</td><td class="num low">${qfmt(i.stock)} / ${qfmt(i.min_qty)}</td></tr>`).join('') || '<tr><td>لا يوجد</td></tr>'}</tbody></table>`;
  const ex = await api('/reports/expiring?days=90');
  $('#rexp').innerHTML = `<table><tbody>${ex.map(i => `<tr><td>${esc(i.name)}<br><small>${esc(i.batch_no)}</small></td><td>${esc(i.expiry)}</td><td class="num">${qfmt(i.qty)}</td></tr>`).join('') || '<tr><td>لا يوجد</td></tr>'}</tbody></table>`;
  const d = await api('/reports/debts');
  $('#rdebt').innerHTML = `<table><tbody>${d.map(p => `<tr><td>${p.kind === 'customer' ? 'عميل' : 'مورد'}</td><td>${esc(p.name)}</td><td>${esc(p.phone)}</td><td class="num low">${fmt(p.balance)}</td></tr>`).join('') || '<tr><td>لا يوجد</td></tr>'}</tbody></table>`;
}

// ================= الإعدادات =================
async function pageSettings() {
  const info = await api('/info');
  const admin = me.role === 'admin';
  main().innerHTML = `
  <div class="card"><b>اسم الصيدلية (يظهر في الفاتورة)</b>
    <div class="row"><input id="shop" class="grow" value="${esc(shopName())}"><button class="btn" id="shopsave">حفظ</button></div></div>
  <div class="card"><b>عنوان الخادم لنقاط البيع</b>
    <p>${info.ips.map(ip => `<code>http://${esc(ip)}:${info.port}</code>`).join(' &nbsp; ') || 'غير متصل بشبكة'}</p>
    <small>ثبّت هذا العنوان في الراوتر (DHCP Reservation) حتى لا يتغير.</small></div>
  ${admin ? `<div class="card"><b>المستخدمون</b><div id="ulist"></div>
    <div class="row" style="margin-top:8px"><input id="un" placeholder="اسم"><input id="up" placeholder="رمز (4+ أرقام)" inputmode="numeric">
    <select id="ur"><option value="cashier">كاشير</option><option value="admin">مدير</option></select><button class="btn primary" id="uadd">إضافة / تحديث الرمز</button></div></div>
  <div class="card"><b>نسخة احتياطية</b><p><small>احفظ الملف على فلاشة أو أرسله لنفسك يومياً.</small></p><button class="btn" id="bk">تنزيل نسخة احتياطية</button></div>` : ''}
  ${window.AndroidBridge ? `<div class="card"><button class="btn danger" id="reset">تغيير وضع هذا الجهاز (خادم/نقطة بيع)</button></div>` : ''}`;
  $('#shopsave').onclick = () => { try { localStorage.setItem('shop', $('#shop').value); } catch (e) {} toast('تم'); };
  if (window.AndroidBridge) $('#reset').onclick = () => { if (confirm('سيعود الجهاز لشاشة الإعداد. متابعة؟')) window.AndroidBridge.resetMode(); };
  if (!admin) return;
  const users = await api('/users');
  $('#ulist').innerHTML = `<table><tbody>${users.map(u => `<tr><td>${esc(u.name)}</td><td>${u.role === 'admin' ? 'مدير' : 'كاشير'}</td><td>${u.active ? '' : 'موقوف'}</td></tr>`).join('')}</tbody></table>`;
  $('#uadd').onclick = async () => {
    const ex = users.find(u => u.name === $('#un').value.trim());
    const r = await run(() => api('/users', { id: ex ? ex.id : 0, name: $('#un').value, pin: $('#up').value, role: $('#ur').value, active: 1 }));
    if (r) { toast('تم — سجّل الدخول من جديد'); logout(); }
  };
  $('#bk').onclick = async () => {
    const r = await fetch('/api/backup', { headers: { 'X-Token': token } });
    if (!r.ok) return toast('فشل التنزيل', true);
    const b = await r.blob(); const a = document.createElement('a');
    a.href = URL.createObjectURL(b); a.download = 'pharmacy-backup-' + todayStr() + '.db'; a.click();
  };
}
