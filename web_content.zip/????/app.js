
// الأصناف
const PRODUCTS = [
    {key: "meat", name: "هريس لحم"},
    {key: "chicken", name: "هريس دجاج"},
    {key: "aseed", name: "عصيد"}
];

// تخزين البيانات
let records = JSON.parse(
    localStorage.getItem("harees_records") || "[]"
);

let prices = JSON.parse(
    localStorage.getItem("harees_prices") ||
    '{"meat":8000,"chicken":6000,"aseed":1000}'
);

let currentReport = null;

// اختصار الوصول للعناصر
const $ = id => document.getElementById(id);

// حفظ البيانات
function saveData() {
    localStorage.setItem(
        "harees_records",
        JSON.stringify(records)
    );
}

// تنسيق الأرقام
function money(number) {
    return (Number(number) || 0).toLocaleString("en-US");
}

// التاريخ المحلي
function today() {
    const d = new Date();
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 10);
}

// اسم اليوم
function getDay(date) {
    return [
        "الأحد",
        "الاثنين",
        "الثلاثاء",
        "الأربعاء",
        "الخميس",
        "الجمعة",
        "السبت"
    ][new Date(date + "T12:00:00").getDay()];
}

// إنشاء جدول الأصناف
function buildEntry() {

    $("entryRows").innerHTML = PRODUCTS.map(p => `
        <tr>
            <th>${p.name}</th>

            <td>
                <input type="number"
                    min="0"
                    data-qty="${p.key}"
                    value="0">
            </td>

            <td>
                <input type="number"
                    min="0"
                    data-price="${p.key}"
                    value="${prices[p.key]}">
            </td>

            <td id="sum-${p.key}">0</td>
        </tr>
    `).join("");

    document.querySelectorAll("#entryRows input")
        .forEach(input => {
            input.addEventListener("input", calculate);
        });

    calculate();
}

// قراءة الكمية
function getQty(key) {
    return Number(
        document.querySelector(`[data-qty="${key}"]`).value
    ) || 0;
}

// قراءة السعر
function getPrice(key) {
    return Number(
        document.querySelector(`[data-price="${key}"]`).value
    ) || 0;
}

// الحساب التلقائي
function calculate() {

    let total = 0;

    PRODUCTS.forEach(p => {

        let amount = getQty(p.key) * getPrice(p.key);

        total += amount;

        $("sum-" + p.key).textContent = money(amount);

    });

    $("dayTotal").textContent = money(total);
}

// تفريغ الحقول
function clearFields() {

    PRODUCTS.forEach(p => {

        document.querySelector(
            `[data-qty="${p.key}"]`
        ).value = 0;

        document.querySelector(
            `[data-price="${p.key}"]`
        ).value = prices[p.key];

    });

    $("notes").value = "";

    calculate();
}

// عرض اسم اليوم
function updateDay() {

    const date = $("entryDate").value;

    if (date) {
        $("dayName").value = getDay(date);
    }
}

// تحميل سجل سابق
function loadRecord(date) {

    const record = records.find(r => r.date === date);

    clearFields();

    if (record) {

        PRODUCTS.forEach(p => {

            document.querySelector(
                `[data-qty="${p.key}"]`
            ).value = record.items[p.key].qty;

            document.querySelector(
                `[data-price="${p.key}"]`
            ).value = record.items[p.key].price;

        });

        $("notes").value = record.notes || "";
    }

    updateDay();
    calculate();
}

// حفظ سجل اليوم
function saveEntry() {

    const date = $("entryDate").value;

    if (!date) {
        $("entryMessage").textContent =
            "اختر التاريخ أولاً";
        return;
    }

    const items = {};
    let total = 0;

    PRODUCTS.forEach(p => {

        const qty = getQty(p.key);
        const price = getPrice(p.key);

        const amount = qty * price;

        items[p.key] = {
            qty,
            price,
            amount
        };

        total += amount;
    });

    const record = {
        date: date,
        day: getDay(date),
        items: items,
        total: total,
        notes: $("notes").value,
        updatedAt: new Date().toISOString()
    };

    const index = records.findIndex(
        r => r.date === date
    );

    if (index >= 0) {
        records[index] = record;
    } else {
        records.push(record);
    }

    records.sort((a, b) => a.date.localeCompare(b.date));

    saveData();

    $("entryMessage").textContent =
        "تم حفظ السجل بنجاح";
}

// بداية الأسبوع من السبت
function weekStart(date) {

    const d = new Date(date + "T12:00:00");

    const difference = (d.getDay() + 1) % 7;

    d.setDate(d.getDate() - difference);

    return d;
}

// إضافة أيام للتاريخ
function addDays(date, number) {

    const d = new Date(date + "T12:00:00");

    d.setDate(d.getDate() + number);

    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());

    return d.toISOString().slice(0, 10);
}

// عرض التقارير
function showReport() {

    const date = $("reportDate").value;

    if (!date) return;

    const type = $("reportType").value;

    let start, end, title;

    if (type === "week") {

        start = weekStart(date);

        const s = new Date(start);
        s.setMinutes(s.getMinutes() - s.getTimezoneOffset());

        start = s.toISOString().slice(0, 10);

        end = addDays(start, 6);

        title = "التقرير الأسبوعي";

    } else {

        start = date.slice(0, 7) + "-01";

        const d = new Date(
            start + "T12:00:00"
        );

        d.setMonth(d.getMonth() + 1);
        d.setDate(0);

        d.setMinutes(d.getMinutes() - d.getTimezoneOffset());

        end = d.toISOString().slice(0, 10);

        title = "التقرير الشهري";
    }

    const list = records.filter(r =>
        r.date >= start && r.date <= end
    );

    const sums = {};

    PRODUCTS.forEach(p => {
        sums[p.key] = {qty: 0, amount: 0};
    });

    let total = 0;

    list.forEach(r => {

        PRODUCTS.forEach(p => {

            const item = r.items[p.key] || {};

            sums[p.key].qty += Number(item.qty) || 0;

            sums[p.key].amount += Number(item.amount) || 0;

        });

        total += Number(r.total) || 0;

    });

    currentReport = {start, end, list, sums, total};

    $("reportOutput").innerHTML = `

        <h3>${title}</h3>

        <p>من ${start} إلى ${end}</p>

        <h3>إجمالي المبلغ: ${money(total)}</h3>

        <p>عدد الأيام المسجلة: ${list.length}</p>

        <table>
            <thead>
                <tr>
                    <th>الصنف</th>
                    <th>الكمية</th>
                    <th>المبلغ</th>
                </tr>
            </thead>

            <tbody>
                ${PRODUCTS.map(p => `
                    <tr>
                        <td>${p.name}</td>
                        <td>${money(sums[p.key].qty)}</td>
                        <td>${money(sums[p.key].amount)}</td>
                    </tr>
                `).join("")}
            </tbody>

            <tfoot>
                <tr>
                    <th colspan="2">الإجمالي</th>
                    <th>${money(total)}</th>
                </tr>
            </tfoot>
        </table>

        <h3>تفاصيل الأيام</h3>

        ${list.map(r => `
            <p>
                ${r.date} - ${r.day}
                : ${money(r.total)}
            </p>
        `).join("")}

        ${list.length ? "" : "<p>لا توجد سجلات لهذه الفترة</p>"}

    `;
}

// السجلات السابقة
function showRecords() {

    const month = $("recordsMonth").value;

    const list = records
        .filter(r => !month || r.date.startsWith(month))
        .slice()
        .reverse();

    $("recordsList").innerHTML = list.length
        ? list.map(r => `

            <div class="record">

                <strong>${r.day} - ${r.date}</strong>

                <p>الإجمالي: ${money(r.total)}</p>

                <div class="record-actions">

                    <button data-edit="${r.date}">
                        تعديل
                    </button>

                    <button class="danger"
                        data-delete="${r.date}">
                        حذف
                    </button>

                </div>

            </div>

        `).join("")
        : "<p>لا توجد سجلات محفوظة</p>";

    document.querySelectorAll("[data-edit]")
        .forEach(button => {

            button.onclick = () => {

                const date = button.dataset.edit;

                switchTab("entry");

                $("entryDate").value = date;

                loadRecord(date);
            };

        });

    document.querySelectorAll("[data-delete]")
        .forEach(button => {

            button.onclick = () => {

                const date = button.dataset.delete;

                if (confirm("هل تريد حذف هذا السجل؟")) {

                    records = records.filter(
                        r => r.date !== date
                    );

                    saveData();

                    showRecords();
                }
            };

        });
}

// إعداد الأسعار
function showPrices() {

    $("priceSettings").innerHTML = PRODUCTS.map(p => `

        <label>${p.name}</label>

        <input type="number"
            min="0"
            data-setting="${p.key}"
            value="${prices[p.key]}">

    `).join("");
}

// حفظ الأسعار
function savePrices() {

    PRODUCTS.forEach(p => {

        prices[p.key] = Number(
            document.querySelector(
                `[data-setting="${p.key}"]`
            ).value
        ) || 0;

    });

    localStorage.setItem(
        "harees_prices",
        JSON.stringify(prices)
    );

    $("settingsMessage").textContent =
        "تم حفظ الأسعار بنجاح";
}

// التنقل بين الصفحات
function switchTab(page) {

    document.querySelectorAll(".tab")
        .forEach(b => b.classList.toggle(
            "active",
            b.dataset.page === page
        ));

    document.querySelectorAll(".page")
        .forEach(p => p.classList.toggle(
            "active",
            p.id === page
        ));

    if (page === "records") {
        showRecords();
    }
}

// تصدير التقرير إلى Excel بصيغة CSV
function exportExcel() {

    if (!currentReport) {
        showReport();
    }

    if (!currentReport) return;

    let rows = [
        ["التاريخ", "اليوم", "الصنف",
         "الكمية", "السعر", "الإجمالي"]
    ];

    currentReport.list.forEach(r => {

        PRODUCTS.forEach(p => {

            const item = r.items[p.key] || {};

            rows.push([
                r.date,
                r.day,
                p.name,
                item.qty || 0,
                item.price || 0,
                item.amount || 0
            ]);

        });

    });

    const csv = "\uFEFF" + rows.map(row =>
        row.map(value =>
            '"' + String(value).replace(/"/g, '""') + '"'
        ).join(",")
    ).join("\r\n");

    const blob = new Blob(
        [csv],
        {type: "text/csv;charset=utf-8"}
    );

    downloadFile(blob, "تقرير_الهريس.csv");
}

// تنزيل ملف
function downloadFile(blob, filename) {

    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");

    a.href = url;
    a.download = filename;

    a.click();

    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// النسخ الاحتياطي
function backupData() {

    const data = {
        records: records,
        prices: prices
    };

    const blob = new Blob(
        [JSON.stringify(data, null, 2)],
        {type: "application/json"}
    );

    downloadFile(blob, "نسخة_احتياطية_الهريس.json");
}

// استعادة النسخة الاحتياطية
function restoreData(file) {

    const reader = new FileReader();

    reader.onload = () => {

        try {

            const data = JSON.parse(reader.result);

            if (!Array.isArray(data.records) ||
                !data.prices) {
                throw new Error("Invalid backup");
            }

            if (!confirm("سيتم استبدال البيانات الحالية. هل تريد المتابعة؟")) {
                return;
            }

            records = data.records;
            prices = data.prices;

            saveData();

            localStorage.setItem(
                "harees_prices",
                JSON.stringify(prices)
            );

            buildEntry();
            showPrices();
            showRecords();

            alert("تم استعادة البيانات بنجاح");

        } catch {

            alert("ملف النسخة الاحتياطية غير صالح");

        }
    };

    reader.readAsText(file);
}

// ربط الأزرار
document.querySelectorAll(".tab").forEach(button => {

    button.onclick = () => {
        switchTab(button.dataset.page);
    };

});

$("entryDate").value = today();

$("reportDate").value = today();

$("dayName").value = getDay(today());

buildEntry();

showPrices();

loadRecord(today());

$("entryDate").onchange = () => {
    loadRecord($("entryDate").value);
};

$("saveBtn").onclick = saveEntry;

$("clearBtn").onclick = () => {
    clearFields();
    $("entryMessage").textContent = "";
};

$("showReport").onclick = showReport;

$("exportCsv").onclick = exportExcel;

$("printReport").onclick = () => {

    if (!currentReport) {
        showReport();
    }

    if (currentReport) {
        window.print();
    }
};

$("recordsMonth").onchange = showRecords;

$("savePrices").onclick = savePrices;

$("backupBtn").onclick = backupData;

$("restoreFile").onchange = event => {

    if (event.target.files[0]) {
        restoreData(event.target.files[0]);
    }

    event.target.value = "";
};
