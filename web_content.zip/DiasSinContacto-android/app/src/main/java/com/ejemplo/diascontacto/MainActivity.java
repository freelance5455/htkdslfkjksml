package com.ejemplo.diascontacto;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        // Necesario para que localStorage guarde las notas y la fecha de inicio
        settings.setDomStorageEnabled(true);

        // La página viaja dentro de la app: funciona sin internet
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }
}
