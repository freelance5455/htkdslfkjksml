/* Apkomini — Popunder loader (unlimited, no cooldown)
   Vendor: nationalitypointyexcellent.com popunder tag.
   Loads on every page and re-arms on every user click so there is no
   frequency cap / cooldown on our side. */
(function () {
  var SRC = "https://nationalitypointyexcellent.com/a3/da/33/a3da3398c1115868515302c97f893226.js";

  function inject() {
    try {
      var s = document.createElement("script");
      s.type = "text/javascript";
      s.async = true;
      s.src = SRC + (SRC.indexOf("?") > -1 ? "&" : "?") + "r=" + Date.now() + Math.random();
      s.setAttribute("data-omni-pop", "1");
      (document.body || document.head || document.documentElement).appendChild(s);
      // keep the DOM clean: drop old tags, keep the newest few
      var all = document.querySelectorAll('script[data-omni-pop="1"]');
      for (var i = 0; i < all.length - 3; i++) {
        if (all[i].parentNode) all[i].parentNode.removeChild(all[i]);
      }
    } catch (e) {}
  }

  function start() {
    inject();
    // Unlimited: re-arm the popunder on every click, no cooldown at all.
    document.addEventListener("click", function () { inject(); }, true);
    document.addEventListener("touchstart", function () { inject(); }, true);
    // Also re-arm when the tab regains focus.
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden) inject();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }

  window.OmniPop = { fire: inject };
})();
