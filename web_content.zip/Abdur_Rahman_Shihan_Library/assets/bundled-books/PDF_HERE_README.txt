এখানে তোমার PDF বইগুলো রাখবে।
তারপর books.json ফাইলে প্রতিটি PDF-এর জন্য একটি entry যোগ করবে।
নমুনা books.json-এর entry:
{
  "subject": "বাংলা",
  "filename": "বাংলা ১ম পত্র.pdf",
  "file": "bangla-1.pdf"
}
file নামটি অবশ্যই এই ফোল্ডারের PDF-এর নামের সঙ্গে হুবহু মিলতে হবে।
একই Subject-এর একাধিক বইয়ের জন্য একই subject দিয়ে একাধিক entry যোগ করা যাবে।
