Abdur Rahman Shihan – PDF আগে থেকে যুক্ত করার প্যাকেজ

সবচেয়ে সহজ উপায়:
১) এই ZIP ফাইলটি ফোন/কম্পিউটারে Extract করো।
২) Extract করা ফোল্ডার খুলে assets > bundled-books ফোল্ডারে যাও।
৩) তোমার সব PDF বই এই bundled-books ফোল্ডারে Copy/Paste করো।
৪) bundled-books-এর books.json ফাইলটি Text Editor দিয়ে খুলে বইগুলোর তালিকা লেখো।
৫) Subject-এর নাম, PDF-এর নাম ও file-এর নাম ঠিকঠাক লিখে Save করো।
৬) পুরো Abdur_Rahman_Shihan_Library ফোল্ডারের সব ফাইল/ফোল্ডার select করে আবার ZIP করো।
   খেয়াল রাখবে: ZIP খুললে index.html সরাসরি প্রথম স্তরে থাকতে হবে; ভেতরে আরেকটি অতিরিক্ত parent folder যেন না থাকে।
৭) HTML to APK অ্যাপ খুলে ZIP File to APK চাপো।
৮) নতুন ZIP নির্বাচন করো; App name দাও: Abdur Rahman Shihan।
৯) Build/Generate APK করে ইনস্টল করো।

books.json-এর উদাহরণ:
{
  "books": [
    {"subject":"বাংলা","filename":"বাংলা ১ম পত্র.pdf","file":"bangla-1.pdf"},
    {"subject":"বাংলা","filename":"বাংলা ২য় পত্র.pdf","file":"bangla-2.pdf"},
    {"subject":"English","filename":"English Grammar.pdf","file":"english-grammar.pdf"},
    {"subject":"গণিত","filename":"উচ্চতর গণিত.pdf","file":"higher-math.pdf"}
  ]
}

নিয়ম:
- প্রতিটি PDF assets/bundled-books/ ফোল্ডারে রাখতে হবে।
- books.json-এর "file" মানটি PDF-এর প্রকৃত ফাইলনামের সঙ্গে হুবহু মিলবে।
- একই Subject-এ একাধিক PDF রাখা যাবে।
- APK-তে আগে থেকে যুক্ত PDF-গুলো অ্যাপ ইনস্টল করলেই দেখা যাবে এবং পড়া যাবে।
- ওই Subject-এ বই আগে থেকেই থাকলে Add/Edit অপশন দেখাবে না।
- অ্যাপের ভেতর থেকে পরে PDF যোগ করলে তা শুধু সেই ফোনে সংরক্ষিত হবে; সবার APK-তে দিতে হলে আবার ZIP-এ PDF রেখে APK build করতে হবে।

গুরুত্বপূর্ণ:
- PDF-গুলো কপিরাইট/ব্যবহারের অনুমতি আছে এমন বই হওয়া উচিত।
- APK বানানোর আগে test হিসেবে ১-২টি ছোট PDF দিয়ে চেষ্টা করো।
- HTML-to-APK converter-এর কিছু সংস্করণ assets ফোল্ডারের ফাইল fetch করতে বাধা দিতে পারে। এমন হলে Android Studio/WebView packaging প্রয়োজন হতে পারে।

Menu v3:
- Top-right menu opens Online PDF Book Search and Downloaded Books.
- Searches Internet Archive's public catalogue and fetches available PDF files.
- Downloaded PDFs are stored on this device and can be read offline.
- Check each book's rights/licence before downloading or sharing.
- Some HTML-to-APK WebViews may block cross-origin fetches/downloads; test on the actual APK.
