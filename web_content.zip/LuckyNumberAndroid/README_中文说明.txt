幸运数字 Android 项目 ZIP（测试版）

项目说明
- App 名称：幸运数字
- 应用包名：com.luckynumber.app
- 当前版本：1.0
- 最低 Android 版本：Android 6.0（API 23）
- 页面离线运行，核心功能不需要网络权限。
- HTML 页面放在 app/src/main/assets/index.html。

如何构建 APK
1. 将 ZIP 解压到手机 IDE 或电脑上的一个文件夹。
2. 使用支持 Android Gradle 项目的 IDE 打开项目根目录（包含 settings.gradle）。
3. 等待 Gradle 同步完成。
4. 运行 app 模块，或在 Build 菜单中构建 APK。
5. 调试 APK 通常位于 app/build/outputs/apk/debug/app-debug.apk。

注意
- 这是 Android Studio/兼容 IDE 可导入的项目 ZIP，不是已经编译好的 APK。
- 项目使用 Android Gradle Plugin 8.7.3、Kotlin 2.0.21，构建环境需要相应的 Android SDK 和兼容 JDK（通常 JDK 17）。
- 若手机 IDE 不支持该 Gradle 插件版本，需按该 IDE 支持的版本调整构建配置；网页功能本身位于 assets/index.html。
