# Stage 1218 — APK Identity Gate

Purpose: prove whether the APK installed on the phone is actually the newly built source.

Expected native Android dialog on launch:
- BUILD: CP-MARKET-CORE-1218-APK-IDENTITY
- VERSION: 12.6.0
- VERSION CODE: 148

This dialog is created by Android Activity code, before the WebView is loaded. It is not HTML/JavaScript.

Decision:
- If dialog does NOT appear: stop debugging Bridge/Market. The phone is not running this APK (or installation/build pipeline is not using this source).
- If dialog appears: APK identity is proven; continue to WebView bridge diagnosis.
