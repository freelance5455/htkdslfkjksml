# Stage 1208 — Transport Proof
- Native HTTP no longer requests gzip; Android transparent decompression ambiguity is removed.
- Ourbit spot ticker has a reliable fallback from `/api/v3/ticker/24hr` to `/api/v3/ticker/price`.
- Home accepts both full 24h ticker rows and price-only ticker rows.
- Full-universe polling is reduced to 15 seconds; chart requests remain symbol-specific.
- Spot chart no longer waits on legacy LBank K-line fallback.
- Futures performs an immediate real Ourbit K-line attempt and a short retry.
- No synthetic candles are used.
