# Stage 1231 — appassets root interception fix

The reported failure URL was `https://appassets.androidplatform.net/web/index.html` with `net::ERR_HTTP_RESPONSE_CODE_FAILURE`. The prior custom interceptor only accepted `cryptopulse.local`, so it would not serve this appassets URL. Stage 1231 explicitly intercepts both `cryptopulse.local` and `appassets.androidplatform.net` for `/web/*`, and loads the root page using the reported appassets URL. Encoded bridge requests continue through the bridge fallback router.

Version: 12.9.8, versionCode 160. Source ZIP only; APK build has not been verified in this environment.
