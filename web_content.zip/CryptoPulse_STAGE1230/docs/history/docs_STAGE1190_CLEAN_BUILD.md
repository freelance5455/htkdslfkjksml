# Stage 1190 — Clean WebView Build

- versionCode: 130
- versionName: 12.4.0
- visible marker: CLEAN-1190
- WebView is attached with setContentView() before the first loadUrl().
- WebView cache/history are cleared on cold start for this diagnostic build.
- Primary CryptoPulseNative interface uses one stable MarketBridge instance.
- Settings visibly reports CLEAN-1190 so an old APK/cache can be distinguished.
- No synthetic market data added.
