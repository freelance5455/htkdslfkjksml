# CryptoPulse Stage 1192 — Bridge Reattach + Native Fallback

- Version 12.4.2 / versionCode 132
- Build ID CP-CLEAN-1192
- Stable CryptoPulseNative is reattached before first load and after every real document finish.
- Settings diagnostic falls back to the Activity-intercepted cryptopulse://ourbit-diagnostic route if the JS interface is temporarily unavailable.
- No synthetic market data.
