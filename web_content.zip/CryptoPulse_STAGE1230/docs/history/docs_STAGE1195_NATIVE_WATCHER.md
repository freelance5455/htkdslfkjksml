# CryptoPulse Stage 1195 — Native Settings Watcher Diagnostic

Stage 1195 fixes the repeated white WebView error seen in Stage 1194.

## Root cause
The Settings page is a SPA/local document and the fallback diagnostic used a synthetic HTTPS navigation (`https://cryptopulse.local/ourbit-diagnostic`). On the affected WebView provider the navigation was rendered as an error page instead of being intercepted reliably.

## Fix
- Removed diagnostic navigation from Settings.
- Android polls the WebView DOM for the existing Settings diagnostic elements.
- Once detected, Android runs the Ourbit HTTP diagnostics directly.
- Results are injected into the current Settings document with `evaluateJavascript`.
- This path does not depend on `window.CryptoPulseNative` and does not navigate away from Settings.
- Build marker: CP-CLEAN-1195.
- Version: 12.4.5 / versionCode 135.

No synthetic market data is used.
