# CryptoPulse Stage 1191 — Diagnostic Route Fix

- Version: 12.4.1
- versionCode: 131
- Build ID: CP-CLEAN-1191
- Removed repeated `addJavascriptInterface(new MarketBridge(), ...)` calls from page callbacks.
- Kept exactly one stable MarketBridge attached before the first document load.
- Removed the custom `cryptopulse://ourbit-diagnostic` navigation path that could surface the Android WebView page-render error.
- Settings diagnostic button now calls `CryptoPulseNative.runOurbitDiagnostics()` directly.
- Added `getBuildId()` and `getBridgeVersion()` for on-device bridge verification.
- No synthetic market data added.
