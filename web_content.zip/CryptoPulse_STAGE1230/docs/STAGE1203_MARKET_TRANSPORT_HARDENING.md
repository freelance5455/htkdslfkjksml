# CryptoPulse Stage 1203 — Market Data Transport Hardening

## Purpose
Continue from Stage 1202 without changing the trading UI architecture.

## Root cause fixed
The Android native HTTP reader previously stopped reading a large Ourbit `/api/v3/ticker/24hr` response at 500,000 characters. The response could therefore be returned to JavaScript as truncated JSON, causing the Home market universe parser to see no valid rows and display «رمز ارزی پیدا نشد.»

## Changes
- Raised native JSON response read ceiling from 500 KB to 5 MB.
- Enabled HTTP redirect following and explicit connection close for the native market transport.
- Kept Ourbit as the authoritative market-data provider.
- Updated build/bridge IDs to 1203.
- Removed remaining visible LBank provider labels from the active market-data UI paths.
- Kept real OHLC-only chart behavior; no synthetic candles added.
- JavaScript syntax checked for `app.js`, `spot.html`, and `futures.html` with Node.js.

## Expected test
1. Fresh launch opens Home.
2. Home market universe should populate instead of «رمز ارزی پیدا نشد.»
3. Home rows should receive real Ourbit prices/24h change/volume.
4. Trade BTC/USDT should load real Ourbit candles.
5. Futures BTC/USDT should load real Ourbit ticker/order book/candles.
6. No fake/synthetic market values are introduced.

## Limitation
This environment does not contain an Android Gradle wrapper/SDK, so an APK build was not claimed or fabricated.
