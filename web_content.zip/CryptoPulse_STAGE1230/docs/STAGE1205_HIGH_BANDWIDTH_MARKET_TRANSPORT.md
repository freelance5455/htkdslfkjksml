# Stage 1205 — High-Bandwidth Market Transport

- Native HTTP executor increased from 6 to 12 workers.
- Ourbit responses request gzip compression and keep-alive instead of `Connection: close` + identity encoding.
- Futures ticker and depth are fetched concurrently on each polling cycle.
- Trade ticker and depth requests start concurrently.
- Futures ticker, depth, and 240-candle history start concurrently in the browser/native path.
- No synthetic candles are introduced.
- Purpose: reduce serial network waiting and improve simultaneous market-data delivery on weak/variable connections.
