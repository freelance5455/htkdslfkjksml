# Stage 1232 — Native APK asset root

The same `appassets.androidplatform.net/web/index.html` failure persisted after Stage 1231. This build removes that host from the initial navigation path entirely and loads the bundled HTML through Android's native `file:///android_asset/web/index.html` route.

WebView file access is enabled only as required to read bundled assets; `setAllowFileAccessFromFileURLs(false)` and `setAllowUniversalAccessFromFileURLs(false)` remain disabled to prevent file-origin cross-access. The existing native JavaScript bridge and market transport are retained.

Version: 12.9.9, versionCode 161. Source archive only; APK build was not run in this environment.
