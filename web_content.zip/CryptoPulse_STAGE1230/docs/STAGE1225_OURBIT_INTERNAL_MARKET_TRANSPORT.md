# Stage 1225 — Ourbit Internal Market Transport

Root cause found by comparing CryptoPulse with the supplied Ourbit APK: the real Ourbit Android app does not rely only on the public `/api/v3/ticker/*` route for its market Home. Its native code contains first-party spot market routes including `/platform/spot/market/v2/tickers`, `/platform/spot/market/v2/symbols`, and `/platform/spot/market/price/{currency}`. The APK configuration uses the global host `https://www.seebestfirst.com` for the current production host.

CryptoPulse Stage 1225 therefore prefers the same first-party market transport for Home/ticker data, with public V3 kept only as a fallback. The JS receiver now accepts nested arrays, maps, `data/list/tickers` containers, and the common ticker field variants.
