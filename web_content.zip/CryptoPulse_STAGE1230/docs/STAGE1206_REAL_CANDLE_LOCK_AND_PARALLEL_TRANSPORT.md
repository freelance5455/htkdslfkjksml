# CryptoPulse Stage 1206 — Real Candle Lock + Parallel Transport

## Root cause fixed
Stage 1205 still rebuilt Futures candles from locally sampled prices after each live ticker update. That could overwrite the real Ourbit K-Line history that had just arrived, leaving a flat/repeated chart.

## Changes
- Real Futures K-Line history is now marked with `fHasRealKlines` and is never replaced by session/sample candles.
- Live Futures ticker updates only merge into the current real candle.
- Startup no longer injects sampled candles into the chart before the real K-Line request completes.
- Futures ticker + order book + historical K-Line requests are launched in parallel.
- Automatic Spot-history/reference fallback is removed from the Futures startup path; no cross-market synthetic chart is used.
- Native HTTP transport now has a small retry and a gzip fallback for Android stacks that transparently decompress responses.
- Build ID: CP-MARKET-CORE-1206 / NativeBridge-1206.

## Official Ourbit references
- Spot K-Line response format: https://ourbitdevelop.github.io/apidocs/spot_v3_en/
- Official V1 Contract Postman collection: https://github.com/ourbitdevelop/ourbit-api-postman/blob/main/OURBIT%20V1%20contract.postman_collection.json
