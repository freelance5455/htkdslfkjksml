# Stage 1226 — WebViewAssetLoader hardening

## Root cause
The failing screen showed `https://appassets.androidplatform.net/web/index.html` but the installed build did not have a working asset handler for that URL. The previous source mixed a `file:///android_asset/...` load with a manual interception fallback.

## Fix
- Uses AndroidX `WebViewAssetLoader`.
- Registers `/web/` to `app/src/main/assets/web/`.
- Loads the bundled page as `https://appassets.androidplatform.net/web/index.html`.
- Native bridge is attached before page load.
- Adds a visible `CP 1226 • WEBVIEW ASSET LOADER` probe.
- If the main page fails, the app shows the build ID, exact URL and error code instead of a generic WebView error page.
- Version code 155, version 12.9.3.

Android's current documentation recommends WebViewAssetLoader for in-app content and discourages file:// URLs.
