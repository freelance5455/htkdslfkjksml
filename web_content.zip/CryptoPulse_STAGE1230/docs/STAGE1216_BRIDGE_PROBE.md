# Stage 1216 — Bridge Probe

Root-cause continuation after Stage 1215.

- One Android JavascriptInterface only: `CryptoPulseNative`.
- No prompt bridge and no JavaScript replacement.
- Native build banner: `CP 1216 • NATIVE APK LOADED`.
- Build ID: `CP-MARKET-CORE-1216-BRIDGE-PROBE`.
- versionCode 146 / versionName 12.5.8.
- Android injects a probe object after page load recording whether the document sees `CryptoPulseNative` and whether the two diagnostic methods are functions.

This stage is diagnostic; it does not claim APK compilation.
