# Stage 1209 — Per-Page Diagnostics

هدف: حذف حدس‌زدن در خرابی Market Data و نمایش خطای واقعی روی هر صفحه.

## صفحه‌ها
- Home
- Trade
- Futures
- Settings و سایر صفحات SPA

## اطلاعات
- Native Bridge / Build / Bridge version
- Ourbit Spot ping
- Spot ticker price BTCUSDT
- Spot K-Line BTCUSDT
- Futures ticker BTC_USDT
- Futures K-Line BTC_USDT
- HTTP status, latency, JSON shape, byte count
- Exception class/message
- runtime JS errors و Promise rejectionهای اخیر

## کنترل‌ها
- «تست» اجرای مجدد diagnostics
- «کپی» خروجی JSON برای ارسال به توسعه‌دهنده
- پنل باز/بسته و کم‌مزاحمت

این Stage عمداً قبل از تغییرات بیشتر در Chart/Market rendering ساخته شده تا علت واقعی خرابی مشخص شود.


## Stage 1210 Bridge Fix
- Persistent single CryptoPulseBridge instance.
- Reattach bridge before first load and after every onPageFinished.
- Diagnostics waits up to 3 seconds for bridge exposure instead of falsely declaring an immediate error during page startup.
