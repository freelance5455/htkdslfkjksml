# Stage 1211 — Stable Native Bridge

## Root cause identified
Stage 1210 reattached `CryptoPulseNative` inside `onPageFinished()` by first calling `removeJavascriptInterface()` and then `addJavascriptInterface()`.

That is unsafe for the current WebView document: JavaScript interfaces are exposed at document-load time. Removing the interface after the page is loaded can make `window.CryptoPulseNative` disappear from that document, while adding it again does not reliably re-inject the object until another navigation.

## Fix
- Attach one `CryptoPulseBridge` instance before the first `loadUrl()`.
- Never remove or re-add the bridge from `onPageFinished()`.
- Keep the same WebView and bridge alive for the SPA/local-page navigation model.
- `onPageFinished()` now only records a readiness marker.

## Expected result
`window.CryptoPulseNative` should exist on Home, Trade, Futures, Wallet and Settings without waiting for a bridge reattachment.
