# CryptoPulse Stage 1204 — Real K-Line Transport/Parser Hardening

Observed after Stage 1203: ticker transport works enough to show BTC price, but Trade/Futures charts remain flat/empty and Futures stays CONNECTING.

Fixes:
- Native Android now canonicalizes Ourbit Spot/Futures kline responses into one array shape before returning to WebView.
- Supports array-of-candles and columnar `time/open/high/low/close/volume` response shapes, including wrapped `data/result/rows/list` containers.
- Futures native feed sends a real historical 1m K-line snapshot immediately when the persistent feed starts.
- Futures UI consumes that real history directly; no sampled/fake candle is used for the historical chart.
- Removed the obsolete Trade SVG fallback path and stale LBank chart wording.
- Build ID: CP-MARKET-CORE-1204.

Official Ourbit contract docs confirm the public K-line endpoint and intervals used here. The official Postman collection documents `/api/v1/contract/kline/{symbol}` with `interval`, `start`, and `end` parameters. See the official collection: https://github.com/ourbitdevelop/ourbit-api-postman/blob/main/OURBIT%20V1%20contract.postman_collection.json
