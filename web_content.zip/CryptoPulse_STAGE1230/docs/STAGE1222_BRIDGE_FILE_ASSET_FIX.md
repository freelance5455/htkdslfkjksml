# Stage 1222 — Native Bridge File-Asset Fix

Observed device symptom: `CryptoPulseNative unavailable: the Android native bridge is not exposed in this WebView document.`

Root fix: keep the real Android `addJavascriptInterface()` bridge attached before the first navigation, but load the bundled WebView root through the Android asset URL `file:///android_asset/web/index.html` instead of manually intercepted `https://appassets.androidplatform.net/...` resources.

Reason: the previous custom `shouldInterceptRequest()` path made the document origin depend on a manually constructed WebResourceResponse. The bridge itself was correctly registered, but the installed WebView document did not see it. The file-asset root uses Android's native asset loader directly and preserves the same WebView/bridge object across local page navigation.

Market transport remains Ourbit-native. No LBank market source is reintroduced by this fix.
