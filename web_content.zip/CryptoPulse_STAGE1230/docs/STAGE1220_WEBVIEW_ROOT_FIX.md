# Stage 1220 - WebView root fix

The original Stage 1218 source contains assets/web/index.html. The observed device error used https://appassets.androidplatform.net/web/index.html and returned ERR_HTTP_RESPONSE_CODE_FAILURE.

Stage 1220 explicitly intercepts that exact appassets host and serves files from the APK's bundled assets/web directory, including HTML, JS, CSS, images and fonts. The local UI therefore has no network dependency. Bridge and Ourbit logic are unchanged.
