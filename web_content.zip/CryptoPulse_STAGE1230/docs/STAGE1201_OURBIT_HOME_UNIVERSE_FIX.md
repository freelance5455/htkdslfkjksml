# Stage 1201 — Ourbit Home Universe Fix

## Root cause
The clean 1200 build still rendered the Home market universe from a bundled LBank spot catalogue. The Ourbit bulk ticker callback only updated prices for symbols already present in that old catalogue. Lower rows that existed on LBank but were absent/different on Ourbit therefore remained `—`.

The missing-price helper also still expected the old LBank-only native method, which is not part of the clean 1200 bridge.

## Fix
- Ourbit `/api/v3/ticker/24hr` is now the authoritative Home USDT universe.
- The native Ourbit bulk callback rebuilds `coins` from every live USDT ticker and populates `liveCache` in one pass.
- Missing-price refreshes re-request the Ourbit bulk snapshot instead of LBank-specific pairs.
- LBank/CoinCap/Paprika Home fallback calls were removed from the 1201 startup path.
- Major coins retain stable ordering; remaining coins are ordered by 24h quote volume.
- No synthetic prices are generated.
- Android build marker: `CP-OURBIT-HOME-1201`, version `12.5.1`, versionCode `141`.
