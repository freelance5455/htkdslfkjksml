# Stage 1228 — Root WebView Fix

The failure persisted even after WebViewAssetLoader. Stage 1228 removes the `appassets.androidplatform.net` transport and AndroidX WebViewAssetLoader from the critical boot path.

The WebView now loads `https://cryptopulse.local/web/index.html`, and `WebViewClient.shouldInterceptRequest()` maps `/web/*` directly to APK `assets/web/*` using `AssetManager`. This gives the app a controlled HTTPS origin without relying on the special appassets host.

All HTML/JS/CSS/image subresources under `assets/web/` are served by the same interceptor. Native JS bridge remains registered before `loadUrl()`.
