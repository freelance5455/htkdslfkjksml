# Stage 1213 — Native Prompt Bridge Fallback

Stage 1212 still reported `CryptoPulseNative` missing on the device. This stage adds an independent WebChromeClient prompt transport.

- `WebChromeClient.onJsPrompt()` intercepts a private `__CP_NATIVE__` message.
- After each document finishes, Android injects a JavaScript proxy named `CryptoPulseNative`.
- The proxy forwards method calls through the intercepted prompt channel.
- Native asynchronous market calls still use the existing `push()` callback path.
- The original `addJavascriptInterface` bridge remains present, but the web app no longer depends on it when the prompt proxy is installed.
- Diagnostics metadata is `NativeBridge-1213-PROMPT-FALLBACK`.

This isolates the failure from Android JavaScript-interface exposure. If this stage reports the bridge as available, the remaining market-data tests can proceed independently.
