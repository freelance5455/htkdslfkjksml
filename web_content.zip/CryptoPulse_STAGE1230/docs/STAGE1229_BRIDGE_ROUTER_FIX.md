# CryptoPulse Stage 1229 — WebView bridge router fix

- Version: 12.9.6 (versionCode 158)
- Keeps the bundled `https://cryptopulse.local/web/index.html` asset loader.
- Implements the missing `handleBridgeFallbackUrl` method referenced by the WebView client.
- Routes fallback iframe calls (`cryptopulse://bridge/call?...`) through the native `CryptoPulseBridge` and returns an empty successful response from request interception, avoiding a failed WebView navigation for bridge calls.
- This is a source ZIP. It has not been built into an APK in this environment; build/install verification is still required.
