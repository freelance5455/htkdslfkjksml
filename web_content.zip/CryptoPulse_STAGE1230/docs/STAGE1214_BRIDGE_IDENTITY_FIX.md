# Stage 1214 — Bridge Identity Fix

Root-cause verification stage. Stage 1213 still shipped Android versionCode 143, so the device could not unambiguously prove that the new Bridge code was installed.

Changes:
- versionCode 144
- versionName 12.5.6
- BUILD_ID CP-MARKET-CORE-1214-BRIDGE-IDENTITY-FIX
- Native bridge metadata NativeBridge-1214-IDENTITY-FIX
- No new transport/API assumptions.

Test rule: the installed APK must report the 1214 build identity before any further Bridge diagnosis is considered.
