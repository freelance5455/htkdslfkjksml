# Stage 1212 — Native Bridge Bootstrap Recovery

Stage 1211 correctly stopped removing/re-adding the WebView JavaScript interface after page load, but the reported device test still showed `CryptoPulseNative` missing after 3 seconds.

Stage 1212 adds a safer bootstrap/recovery path:
- `CryptoPulseNative` is attached before the first load.
- It is re-attached in `onPageStarted`, i.e. before each new document is created.
- `onPageFinished` never removes the interface.
- A single post-load probe checks `typeof window.CryptoPulseNative`.
- If the probe reports missing, the bridge is attached again and the WebView performs one controlled reload; a view tag prevents an infinite reload loop.
- Diagnostic metadata identifies this build as `NativeBridge-1212-BOOTSTRAP`.

This stage is intended to prove whether the failure is document bootstrap/navigation related rather than an Ourbit API problem.
