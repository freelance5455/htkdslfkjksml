/* Stage 1225: Ourbit internal market transport + bridge fallback. */
(function(){
if(window.CryptoPulseNative)return;
const BUILD='CP-MARKET-CORE-1225-OURBIT-INTERNAL-MARKET-ROUTER';
function call(m,a){try{const q='cryptopulse://bridge/call?m='+encodeURIComponent(m)+'&a='+encodeURIComponent(JSON.stringify(a||[]));const f=document.createElement('iframe');f.style.display='none';f.src=q;(document.body||document.documentElement).appendChild(f);setTimeout(()=>{try{f.remove()}catch(_e){}},80)}catch(_e){}}
window.CryptoPulseNative={getBuildId:()=>BUILD,getBridgeVersion:()=> 'OurbitInternalMarket-1225',getNativeDiagnosticsMeta:()=>JSON.stringify({build:BUILD,version:'12.9.2',bridge:'OurbitInternalMarket-1225'}),getLocalPage:()=>'',getFuturesSnapshot:()=>'',fetchOurbitSpotKlines:(...a)=>call('fetchOurbitSpotKlines',a),fetchOurbitSpotTicker:(...a)=>call('fetchOurbitSpotTicker',a),fetchOurbitSpotDepth:(...a)=>call('fetchOurbitSpotDepth',a),fetchOurbitSpotTickers:(...a)=>call('fetchOurbitSpotTickers',a),fetchOurbitFuturesTicker:(...a)=>call('fetchOurbitFuturesTicker',a),fetchOurbitFuturesDepth:(...a)=>call('fetchOurbitFuturesDepth',a),fetchOurbitFuturesKlines:(...a)=>call('fetchOurbitFuturesKlines',a),fetchTickers:(...a)=>call('fetchTickers',a),fetchMarketUniverse:(...a)=>call('fetchMarketUniverse',a),restoreMarketCache:(...a)=>call('restoreMarketCache',a),startFuturesFeed:(...a)=>call('startFuturesFeed',a),runOurbitDiagnostics:(...a)=>call('runOurbitDiagnostics',a),enterChartFullscreen:(...a)=>call('enterChartFullscreen',a),exitChartFullscreen:(...a)=>call('exitChartFullscreen',a)};
window.__cpBridgeTransport='fallback-router';
})();
window.cpNativeProbeFromAndroid=null;

const API_BASES=['https://api.binance.com'];
const LBANK_WS='wss://api.lbank.info/ws/V2/';
const OURBIT_API_BASE='https://api.ourbit.com';
const OURBIT_CONTRACT_BASE='https://contract.ourbit.com';
const LBANK_API_BASES=['https://api.lbkex.com','https://api.lbank.info','https://www.lbkex.net'];
const LBANK_CONTRACT_BASES=['https://lbkperp.lbank.com'];
const LBANK_WS_BASES=['wss://api.lbank.info/ws/V2/','wss://www.lbkex.net/ws/V2/'];
const liveCache={};
const liveListeners={};
// Shared chart/history cache survives Home <-> Chart page swaps.
// It keeps the last usable candles immediately available while a fresh
// WebSocket history request runs in the background.
const CP_CHART_CACHE_STORAGE_KEY='cp_chart_history_cache_v1';
const CP_CHART_CACHE_MAX_AGE=6*60*60*1000;
const CP_CHART_CACHE_MAX_ENTRIES=24;
const __cpChartHistoryCache=window.__cpChartHistoryCache||Object.create(null);
let __cpChartPersistTimer=0;
window.__cpChartHistoryCache=__cpChartHistoryCache;
function cpChartCacheKey(sym,tf){return String(sym||'').toUpperCase()+'|'+String(tf||'live');}
function cpChartCacheClone(rows){return (Array.isArray(rows)?rows:[]).map(r=>Array.isArray(r)?r.slice():r).filter(r=>Array.isArray(r)&&r.length>=5);}
function cpLoadChartHistoryCache(){
  try{
    const raw=sessionStorage.getItem(CP_CHART_CACHE_STORAGE_KEY);
    if(!raw)return;
    const saved=JSON.parse(raw);
    if(!saved||typeof saved!=='object')return;
    const now=Date.now();
    Object.entries(saved).forEach(([k,v])=>{
      const at=Number(v?.at||0),rows=cpChartCacheClone(v?.rows);
      if(!at||!rows.length||now-at>CP_CHART_CACHE_MAX_AGE)return;
      __cpChartHistoryCache[k]={at,rows};
    });
  }catch(_e){}
}
function cpPersistChartHistoryCache(){
  try{
    const entries=Object.entries(__cpChartHistoryCache).sort((a,b)=>(Number(b[1]?.at||0)-Number(a[1]?.at||0))).slice(0,CP_CHART_CACHE_MAX_ENTRIES);
    const out={};
    for(const [k,v] of entries){
      if(!v?.rows?.length)continue;
      out[k]={at:Number(v.at||Date.now()),rows:cpChartCacheClone(v.rows).slice(-240)};
    }
    sessionStorage.setItem(CP_CHART_CACHE_STORAGE_KEY,JSON.stringify(out));
  }catch(_e){}
}
function cpChartCachePut(sym,tf,rows){
  const clean=cpChartCacheClone(rows).sort((a,b)=>Number(a[0])-Number(b[0])).slice(-240);
  if(clean.length<10)return false;
  __cpChartHistoryCache[cpChartCacheKey(sym,tf)]={at:Date.now(),rows:clean};
  if(!__cpChartPersistTimer){
    __cpChartPersistTimer=setTimeout(()=>{__cpChartPersistTimer=0;cpPersistChartHistoryCache()},700);
  }
  return true;
}
function cpChartCacheGet(sym,tf){
  const k=cpChartCacheKey(sym,tf),v=__cpChartHistoryCache[k];
  if(v?.rows?.length && Date.now()-Number(v.at||0)<=CP_CHART_CACHE_MAX_AGE)return cpChartCacheClone(v.rows);
  return null;
}
window.cpChartCachePut=cpChartCachePut;
window.cpChartCacheGet=cpChartCacheGet;
cpLoadChartHistoryCache();
const LIVE_CACHE_STORAGE_KEY='cp_live_market_cache_v72';
const LIVE_CACHE_MAX_AGE=120000;
let liveCacheSaveTimer=0;
function restoreSharedLiveCache(){
  try{const raw=localStorage.getItem(LIVE_CACHE_STORAGE_KEY);if(!raw)return;const saved=JSON.parse(raw);if(!saved||typeof saved!=='object')return;const now=Date.now();for(const [k,v] of Object.entries(saved)){const ts=Number(v?.lastUpdate||0);const price=Number(v?.price);if(!k||!Number.isFinite(price)||price<=0||!ts||now-ts>LIVE_CACHE_MAX_AGE)continue;liveCache[String(k).toUpperCase()]={...v,price,lastUpdate:ts,connected:false,restored:true};}}catch(_e){}
}
function persistSharedLiveCache(){
  if(liveCacheSaveTimer)return;
  liveCacheSaveTimer=setTimeout(()=>{liveCacheSaveTimer=0;try{const out={};for(const [k,v] of Object.entries(liveCache)){const ts=Number(v?.lastUpdate||0),price=Number(v?.price);if(Number.isFinite(price)&&price>0&&ts&&Date.now()-ts<=LIVE_CACHE_MAX_AGE)out[k]={price,change:Number(v.change)||0,volume:Number(v.volume)||0,lastUpdate:ts,provider:v.provider||'LBank'};}localStorage.setItem(LIVE_CACHE_STORAGE_KEY,JSON.stringify(out));}catch(_e){}},250);
}
restoreSharedLiveCache();
const liveSockets={};
const liveHub={ws:null,connecting:false,retry:0,timer:null,watchdog:null,pingTimer:null,lastMessage:0,provider:'ourbit'};
const pair=(sym)=>String(sym).toLowerCase()+'_usdt';
const lbankType=(interval)=>({ '1m':'minute1','5m':'minute5','15m':'minute15','30m':'minute30','1h':'hour1','4h':'hour4','1d':'day1','1w':'week1' }[interval]||'hour1');
function normalizeLbankKline(rows){return (rows||[]).map(k=>{const rawTs=Array.isArray(k)?Number(k[0]):Number(k.timestamp??k.t);const ts=Number.isFinite(rawTs)?(rawTs<100000000000?rawTs*1000:rawTs):NaN;return Array.isArray(k)?[ts,String(k[1]),String(k[2]),String(k[3]),String(k[4]),String(k[5]),Date.now(),'0','0','0','0','0']:[ts,String(k.open??k.o),String(k.high??k.h),String(k.low??k.l),String(k.close??k.c),String(k.volume??k.v),Date.now(),'0','0','0','0','0']}).filter(k=>Number.isFinite(k[0]));}
async function lbankFetch(path){
  let last;
  for(const base of LBANK_API_BASES){const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),7000);try{const r=await fetch(base+path,{cache:'no-store',signal:ctl.signal});if(!r.ok)throw new Error('HTTP '+r.status);return await r.json()}catch(e){last=e}finally{clearTimeout(timer)}}
  throw last||new Error('LBank network');
}
async function ourbitFetch(path){
  const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),7000);
  try{const r=await fetch(OURBIT_API_BASE+path,{cache:'no-store',signal:ctl.signal});if(!r.ok)throw new Error('Ourbit HTTP '+r.status);return await r.json()}finally{clearTimeout(timer)}
}
async function ourbitContractFetch(path){
  const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),7000);
  try{const r=await fetch(OURBIT_CONTRACT_BASE+path,{cache:'no-store',signal:ctl.signal});if(!r.ok)throw new Error('Ourbit Futures HTTP '+r.status);return await r.json()}finally{clearTimeout(timer)}
}
function ourbitRows(raw){
  if(Array.isArray(raw))return raw;
  const d=raw?.data??raw?.result??raw?.rows??raw?.list;
  if(Array.isArray(d))return d;
  if(d&&typeof d==='object'){
    if(Array.isArray(d.data))return d.data;
    if(Array.isArray(d.rows))return d.rows;
    if(Array.isArray(d.list))return d.list;
  }
  return [];
}
function normalizeOurbitKline(raw){
  const source=raw?.data&&typeof raw.data==='object'&&!Array.isArray(raw.data)?raw.data:raw;
  const arrays={
    t:source?.time??source?.times??source?.timestamp??source?.timestamps??source?.openTime??source?.openTimes,
    o:source?.open??source?.opens, h:source?.high??source?.highs,
    l:source?.low??source?.lows, c:source?.close??source?.closes,
    v:source?.volume??source?.vol??source?.vols
  };
  if(Array.isArray(arrays.t)&&Array.isArray(arrays.o)){
    const out=[];
    const n=Math.min(arrays.t.length,arrays.o.length,arrays.h?.length||Infinity,arrays.l?.length||Infinity,arrays.c?.length||Infinity);
    for(let i=0;i<n;i++){let ts=Number(arrays.t[i]);if(ts<100000000000)ts*=1000;out.push([ts,String(arrays.o[i]),String(arrays.h?.[i]??arrays.o[i]),String(arrays.l?.[i]??arrays.o[i]),String(arrays.c?.[i]??arrays.o[i]),String(arrays.v?.[i]??0),Date.now(),'0','0','0','0','0']);}
    return out.filter(r=>Number.isFinite(r[0])&&Number(r[1])>0&&Number(r[2])>0&&Number(r[3])>0&&Number(r[4])>0).sort((a,b)=>a[0]-b[0]);
  }
  return ourbitRows(raw).map(k=>{
    if(Array.isArray(k)){let ts=Number(k[0]);if(ts<100000000000)ts*=1000;return [ts,String(k[1]),String(k[2]),String(k[3]),String(k[4]),String(k[5]??0),Date.now(),'0','0','0','0','0']}
    const ts0=Number(k?.timestamp??k?.t??k?.openTime??k?.time??k?.ts),ts=ts0<100000000000?ts0*1000:ts0;
    return [ts,String(k?.open??k?.o),String(k?.high??k?.h),String(k?.low??k?.l),String(k?.close??k?.c),String(k?.volume??k?.v??k?.vol??0),Date.now(),'0','0','0','0','0'];
  }).filter(r=>Number.isFinite(r[0])&&Number(r[1])>0&&Number(r[2])>0&&Number(r[3])>0&&Number(r[4])>0).sort((a,b)=>a[0]-b[0]);
}
async function ourbitTicker(sym){const key=String(sym).toUpperCase();const d=await ourbitFetch('/api/v3/ticker/24hr?symbol='+encodeURIComponent(key+'USDT'));const x=Array.isArray(d)?d[0]:d?.data&&Array.isArray(d.data)?d.data[0]:(d?.data||d);const price=Number(x?.lastPrice??x?.last??x?.price??x?.close);if(!Number.isFinite(price)||price<=0)throw new Error('Ourbit bad ticker');const out={price,change:Number(x?.priceChangePercent??x?.changePercent??x?.change??0)||0,volume:Number(x?.quoteVolume??x?.volume??0)||0,high:Number(x?.highPrice??x?.high??price)||price,low:Number(x?.lowPrice??x?.low??price)||price,lastUpdate:Date.now(),connected:true,provider:'Ourbit'};liveCache[key]={...(liveCache[key]||{}),...out};setDataStatus(true);return out}
async function ourbitCandles(sym,interval='1m',limit=240){const key=String(sym).toUpperCase();const oi={'1m':'1m','5m':'5m','15m':'15m','30m':'30m','1h':'60m','4h':'4h','1d':'1d','1w':'1W'}[String(interval)]||String(interval);const d=await ourbitFetch('/api/v3/klines?symbol='+encodeURIComponent(key+'USDT')+'&interval='+encodeURIComponent(oi)+'&limit='+Math.min(1000,Math.max(20,limit)));const rows=normalizeOurbitKline(d);if(rows.length>=10){setDataStatus(true);return rows}throw new Error('Ourbit returned '+rows.length+' candles')}
async function ourbitDepth(sym,limit=10){const key=String(sym).toUpperCase();const d=await ourbitFetch('/api/v3/depth?symbol='+encodeURIComponent(key+'USDT')+'&limit='+Math.min(100,Math.max(5,limit)));const raw=d?.data||d||{};const norm=a=>(Array.isArray(a)?a:[]).map(x=>Array.isArray(x)?[+x[0],+x[1]]:[+(x?.price??x?.p),+(x?.qty??x?.quantity??x?.volume??x?.amount)]).filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));const out={asks:norm(raw.asks),bids:norm(raw.bids)};if(out.asks.length||out.bids.length){setDataStatus(true);return out}throw new Error('Ourbit depth empty')}
// Stage 1178: native Ourbit bridge; avoids WebView CORS restrictions.
function cpNativeOurbitRequest(method,args,timeout=8000){return new Promise((resolve,reject)=>{const b=window.CryptoPulseNative;if(!b||typeof b[method]!=='function')return reject(new Error('native Ourbit bridge unavailable'));const rid='ob_'+method+'_'+Date.now()+'_'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{try{delete window.__cpOurbitWaiters?.[rid]}catch(_e){};reject(new Error('native Ourbit timeout'))},timeout);window.__cpOurbitWaiters=window.__cpOurbitWaiters||{};window.__cpOurbitWaiters[rid]=(payload)=>{clearTimeout(timer);try{delete window.__cpOurbitWaiters[rid]}catch(_e){};try{resolve(typeof payload==='string'?JSON.parse(payload||'{}'):payload)}catch(e){reject(e)}};try{b[method](...(args||[]),rid)}catch(e){clearTimeout(timer);try{delete window.__cpOurbitWaiters[rid]}catch(_e){};reject(e)}})}
window.__cpOurbitResolve=(rid,payload)=>{try{window.__cpOurbitWaiters?.[String(rid)]?.(payload)}catch(_e){}};
window.cpNativeOurbitDiagnostics=(rid,payload)=>window.__cpOurbitResolve(rid,payload);
window.cpNativeOurbitKlines=(rid,payload)=>window.__cpOurbitResolve(rid,payload);window.cpNativeOurbitTicker=(rid,payload)=>window.__cpOurbitResolve(rid,payload);window.cpNativeOurbitDepth=(rid,payload)=>window.__cpOurbitResolve(rid,payload);window.cpNativeOurbitTickers=(rid,payload)=>window.__cpOurbitResolve(rid,payload);window.cpNativeOurbitFuturesTicker=(rid,payload)=>window.__cpOurbitResolve(rid,payload);window.cpNativeOurbitFuturesDepth=(rid,payload)=>window.__cpOurbitResolve(rid,payload);window.cpNativeOurbitFuturesKlines=(rid,payload)=>window.__cpOurbitResolve(rid,payload);
async function nativeOurbitSpotKlines(sym,tf,limit=240){const oi={'1m':'1m','5m':'5m','15m':'15m','30m':'30m','1h':'60m','4h':'4h','1d':'1d','1w':'1W'}[String(tf||'1m')]||String(tf||'1m');return normalizeOurbitKline(await cpNativeOurbitRequest('fetchOurbitSpotKlines',[String(sym||'BTC'),oi,Number(limit)||240]));}
async function nativeOurbitSpotTicker(sym){return cpNativeOurbitRequest('fetchOurbitSpotTicker',[String(sym||'BTC')]);}
async function nativeOurbitSpotDepth(sym,limit=10){const d=await cpNativeOurbitRequest('fetchOurbitSpotDepth',[String(sym||'BTC'),Number(limit)||10]);const raw=d?.data||d||{};const norm=a=>(Array.isArray(a)?a:[]).map(x=>Array.isArray(x)?[+x[0],+x[1]]:[+(x?.price??x?.p),+(x?.qty??x?.quantity??x?.volume??x?.amount)]).filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));return {asks:norm(raw.asks),bids:norm(raw.bids)};}
async function nativeOurbitFuturesTicker(sym){return cpNativeOurbitRequest('fetchOurbitFuturesTicker',[String(sym||'BTC')]);}
async function nativeOurbitFuturesDepth(sym,limit=20){return cpNativeOurbitRequest('fetchOurbitFuturesDepth',[String(sym||'BTC'),Number(limit)||20]);}
async function nativeOurbitFuturesKlines(sym,tf,limit=240){return cpNativeOurbitRequest('fetchOurbitFuturesKlines',[String(sym||'BTC'),String(tf||'Min1'),Number(limit)||240]);}

async function runOurbitDiagnostics(){
  const b=window.CryptoPulseNative;
  if(!b||typeof b.runOurbitDiagnostics!=='function') throw new Error('Native diagnostic bridge unavailable');
  return cpNativeOurbitRequest('runOurbitDiagnostics',[],45000);
}
window.runOurbitDiagnostics=runOurbitDiagnostics;


function markLiveData(){liveHub.lastMessage=Date.now()}
function notifyLive(sym,payload){(liveListeners[String(sym).toUpperCase()]||[]).slice().forEach(fn=>{try{fn(payload)}catch(e){}})}
function showNetworkAlert(){setDataStatus(false)}
function toast(t){const e=document.getElementById('toast');if(!e)return;e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),1800)}
function notifications(){try{const a=JSON.parse(localStorage.getItem('cp_notifications')||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
function refreshNotificationBadges(){const has=unreadNotifications()>0;document.querySelectorAll('#notifyBadge,#homeNotifyBadge').forEach(e=>{if(e){e.classList.toggle('has',has);e.style.display=has?'block':'none';}})}
window.__cpSyncNotificationBadge=refreshNotificationBadges;
function pushNotification(title,text,type='info'){const a=notifications();a.unshift({id:Date.now(),title,text,type,read:false,time:Date.now()});localStorage.setItem('cp_notifications',JSON.stringify(a.slice(0,50)));refreshNotificationBadges()}
function unreadNotifications(){return notifications().filter(x=>!x.read).length}
function setDataStatus(ok){
  const e=document.getElementById('dataStatus');
  if(e){e.textContent=ok?'● LIVE DATA':'● OFFLINE';e.className=ok?'live':'pill'}
  const overlay=document.getElementById('cpLiveOverlay');
  if(overlay){overlay.classList.toggle('connected',!!ok)}
}
function cpCleanMarketStatus(){
  try{
    const fresh=Object.values(liveCache).some(v=>Number(v?.price)>0 && Number(v?.lastUpdate)>0 && Date.now()-Number(v.lastUpdate)<45000);
    setDataStatus(fresh);
    const ov=document.getElementById('cpLiveOverlay');
    if(ov) ov.classList.toggle('show',!fresh);
    return fresh;
  }catch(_e){return false;}
}

function confirmLivePrice(price){
  const p=Number(price);
  if(Number.isFinite(p)&&p>0){liveHub.lastMessage=Date.now();setDataStatus(true);return true}
  return false
}
window.cpNativeSocketEvent=function(ev){
  try{
    const e=typeof ev==='string'?JSON.parse(ev):ev;
    if(!e)return;
    window.__cpNativeSocket=e;
    // Native Socket is authoritative for the transport, but LIVE still requires
    // an actual price. A tick therefore promotes the UI to LIVE; OPEN alone does not.
    if(e.type==='tick' && String(e.extra||'').includes('=')){
      const parts=String(e.extra).split('=');
      const sym=String(parts[0]||'').toUpperCase();
      const price=Number(parts.slice(1).join('='));
      if(sym && Number.isFinite(price) && price>0){
        liveCache[sym]={...(liveCache[sym]||{}),price,lastUpdate:Date.now(),connected:true,provider:'Ourbit Native REST'};
        persistSharedLiveCache();
        confirmLivePrice(price);
        notifyLive(sym,{type:'ticker',price,lastUpdate:Date.now(),provider:'Ourbit Native REST'});
      }
    }
    if(e.type==='failure' || e.type==='closed'){
      // Do not erase an actually fresh REST price just because the socket closed.
      cpCleanMarketStatus();
    }
  }catch(_e){}
};
function coinCards(list=coins){return list.map(c=>`<a href="asset.html?symbol=${encodeURIComponent(c[0])}" class="coin" style="text-decoration:none;color:inherit"><div class="coin-left">${coinIcon(c[0],c[1])}<div><b>${c[0]}</b><div class="muted">${c[1]}</div></div></div><div class="coin-price"><b>${c[2]}</b><div class="${String(c[3])[0]=='+'?'up':'down'}" style="font-size:11px">${c[3]}</div></div></a>`).join('')}
function getCoin(sym){return coins.find(c=>c[0]===sym)||coins[0]}

// TV77: one canonical symbol/name map for Home + Markets.
// The exchange pair is always the source of truth; this map only prevents
// aliases/legacy names from leaking into the visible mobile list.
const CP_CANONICAL_SYMBOLS=Object.freeze({
  BTC:'Bitcoin',ETH:'Ethereum',SOL:'Solana',BNB:'BNB',XRP:'XRP',ADA:'Cardano',
  DOGE:'Dogecoin',AVAX:'Avalanche',LINK:'Chainlink',TRX:'TRON',DOT:'Polkadot',
  LTC:'Litecoin',BCH:'Bitcoin Cash',UNI:'Uniswap',ATOM:'Cosmos',NEAR:'NEAR Protocol',
  AAVE:'Aave',SUI:'Sui',TON:'Toncoin',SHIB:'Shiba Inu',MATIC:'Polygon',POL:'Polygon',
  FTM:'Fantom',S:'Sonic',PEPE:'Pepe',FLOKI:'FLOKI',WIF:'dogwifhat',
  RENDER:'Render',TAO:'Bittensor',INJ:'Injective',SEI:'Sei',TIA:'Celestia',
  ARB:'Arbitrum',OP:'Optimism',APT:'Aptos',FIL:'Filecoin',ETC:'Ethereum Classic',
  XLM:'Stellar',HBAR:'Hedera',ALGO:'Algorand',VET:'VeChain',MANA:'Decentraland',
  MKR:'Maker',RUNE:'THORChain',GRT:'The Graph',JTO:'Jito',ONDO:'Ondo',ENA:'Ethena'
});
function cpCanonicalSymbol(sym){
  let s=String(sym||'').trim().toUpperCase().replace(/[\-/:]/g,'_').replace(/\s+/g,'');
  if(s.endsWith('_USDT'))s=s.slice(0,-5);
  else if(s.endsWith('USDT')&&s.length>4)s=s.slice(0,-4);
  return s;
}
function cpCanonicalName(sym,fallback){const k=cpCanonicalSymbol(sym);return CP_CANONICAL_SYMBOLS[k]||String(fallback||k)}
function latinDigits(v){return String(v??'').replace(/[۰-۹٠-٩]/g,d=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)>=0?'۰۱۲۳۴۵۶۷۸۹'.indexOf(d):'٠١٢٣٤٥٦٧٨٩'.indexOf(d)));}
function money(n){return Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
function coinIcon(sym,name=''){
  const s=String(sym||'').toUpperCase();
  const label=(s[0]||'?').replace(/[^A-Z0-9]/g,'?');
  const slug=encodeURIComponent(s.toLowerCase());
  const url='https://assets.coincap.io/assets/icons/'+slug+'@2x.png';
  const altUrl='https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/128/color/'+slug+'.png';
  return `<span class="coin-icon coin-logo-wrap"><img class="coin-logo" src="${url}" alt="${s} logo" loading="lazy" onerror="this.onerror=null;this.src='${altUrl}';this.classList.add('coin-logo-second');this.onerror=function(){this.style.display='none';this.nextElementSibling.style.display='grid'}"><span class="coin-logo-fallback">${label}</span></span>`;
}
function latinizeVisibleNumbers(root=document.body){if(!root)return;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);const nodes=[];while(w.nextNode())nodes.push(w.currentNode);nodes.forEach(n=>{if(n.parentElement&&['SCRIPT','STYLE'].includes(n.parentElement.tagName))return;const x=latinDigits(n.nodeValue);if(x!==n.nodeValue)n.nodeValue=x});root.querySelectorAll('input').forEach(e=>{if(e.value)e.value=latinDigits(e.value);if(e.placeholder)e.placeholder=latinDigits(e.placeholder)});}
const LANG_PAIRS={
'فارسی':'English','خانه':'Home','بازار':'Markets','معامله':'Trade','کیف پول':'Wallet','پروفایل':'Profile','تحلیل':'Analysis','استراتژی':'Strategies','تنظیمات':'Settings','اعلان‌ها':'Notifications','ذخیره تنظیمات':'Save Settings','بازنشانی':'Reset','زبان':'Language','تم برنامه':'App Theme','واحد حساب':'Account Currency','نمایش':'Display','حساب آزمایشی':'Paper Account','امنیت':'Security','فعال':'Enabled','خاموش':'Disabled','روشن، تیره یا حالت نیمه‌تیره':'Light, dark or midnight mode','زبان رابط کاربری':'Interface language','واحد نمایش ارزش دارایی':'Asset value unit','موجودی شبیه‌سازی‌شده برای تمرین':'Simulated balance for practice','هشدار قیمت و رویدادهای برنامه':'Price and app event alerts','رمز ورود برنامه':'App password','اختیاری؛ فقط برای تجربه محلی برنامه':'Optional; local app only','اتصال صرافی':'Exchange connection','در این نسخه سفارش واقعی ارسال نمی‌شود.':'Real orders are not sent in this version.','معاملات باز':'Open Positions','پوزیشن باز':'Open Position','هنوز پوزیشن بازی وجود ندارد.':'No open position yet.','سود/زیان':'P/L','قیمت باز شدن':'Entry Price','قیمت لیکویید شدن':'Liquidation Price','زمان باز شدن':'Open Time','مارجین':'Margin','اهرم':'Leverage','قیمت فعلی':'Current Price','ارزش معامله':'Position Value','بستن معامله':'Close Position','تایم‌فریم':'Timeframe','نمودار':'Chart','قیمت':'Price','مقدار':'Amount','خرید':'Buy','فروش':'Sell'};
const LANG_REVERSE=Object.fromEntries(Object.entries(LANG_PAIRS).map(([a,b])=>[b,a]));
function translatePage(en){const map=en?LANG_PAIRS:LANG_REVERSE;const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const nodes=[];while(w.nextNode())nodes.push(w.currentNode);nodes.forEach(n=>{if(!n.parentElement||['SCRIPT','STYLE','INPUT','TEXTAREA'].includes(n.parentElement.tagName))return;let t=n.nodeValue.trim();if(!t)return;for(const [a,b] of Object.entries(map)){if(t===a){n.nodeValue=n.nodeValue.replace(a,b);break}}});document.querySelectorAll('input,button,a,option,select').forEach(e=>{['placeholder','title','aria-label'].forEach(k=>{if(e.getAttribute(k)){let v=e.getAttribute(k);for(const [a,b] of Object.entries(map))v=v.split(a).join(b);e.setAttribute(k,v)}});if(e.tagName==='OPTION'){let v=e.textContent;for(const [a,b] of Object.entries(map))v=v.split(a).join(b);e.textContent=v}})}
function applyLanguage(){const en=isEnglish();document.documentElement.lang=en?'en':'fa';document.documentElement.dir=en?'ltr':'rtl';translatePage(en);latinizeVisibleNumbers();}
let _digitObserver=null;function startDigitObserver(){if(_digitObserver)_digitObserver.disconnect();_digitObserver=new MutationObserver(()=>latinizeVisibleNumbers());_digitObserver.observe(document.body,{subtree:true,childList:true,characterData:true});}
function chartSVG(seed=1){let pts=[];for(let i=0;i<48;i++){let y=150-Math.sin(i*.48+seed)*30-i*1.2+Math.sin(i*1.8)*8;pts.push(`${i*(800/47)},${y}`)}return `<svg viewBox="0 0 800 260" preserveAspectRatio="none"><g>${[40,90,140,190,240].map(y=>`<line class="chart-grid" x1="0" y1="${y}" x2="800" y2="${y}"/>`).join('')}</g><polyline class="chart-line" points="${pts.join(' ')}"/></svg>`}
function safeSettings(){try{const raw=localStorage.getItem('cp_settings')||'{}';const d=JSON.parse(raw);return d&&typeof d==='object'?d:{}}catch(e){try{localStorage.removeItem('cp_settings')}catch(_e){};return {}}}

// Stage 1209: per-page transport/runtime diagnostics. This is intentionally visible and
// collapsible so failures are actionable instead of leaving a blank Home/Chart.
(function(){
 if(window.__cpDiagInstalled)return; window.__cpDiagInstalled=true;
 window.__cpDiagResults={}; window.__cpDiagRuntime=[];
 const css=`.cp-diag{position:fixed;left:10px;right:10px;bottom:72px;z-index:99999;background:rgba(12,15,22,.96);color:#fff;border:1px solid rgba(255,255,255,.14);border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.35);font:12px/1.45 sans-serif;overflow:hidden}.cp-diag-head{display:flex;align-items:center;justify-content:space-between;padding:9px 11px}.cp-diag-title{font-weight:800}.cp-diag-actions{display:flex;gap:6px}.cp-diag button{border:0;border-radius:8px;padding:5px 8px;background:#2a3140;color:#fff}.cp-diag-body{display:none;padding:0 11px 10px;max-height:42vh;overflow:auto}.cp-diag.open .cp-diag-body{display:block}.cp-diag-row{padding:6px 0;border-top:1px solid rgba(255,255,255,.08);word-break:break-word}.cp-diag-ok{color:#75e39a}.cp-diag-bad{color:#ff7f86}.cp-diag-warn{color:#ffd166}.cp-diag-muted{opacity:.7}.cp-diag-pre{white-space:pre-wrap;margin:4px 0 0;font-family:monospace;font-size:11px}`;
 function ensureStyle(){if(document.getElementById('cpDiagStyle'))return;const st=document.createElement('style');st.id='cpDiagStyle';st.textContent=css;document.head.appendChild(st)}
 function esc(x){return String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
 function page(){return (window.__cpCurrentPage||location.pathname.split('/').pop()||'index.html').replace(/\.html$/i,'')||'home'}
 function render(){const box=document.getElementById('cpDiagBody');if(!box)return;const rows=[];const meta=window.__cpDiagMeta||{};rows.push(`<div class="cp-diag-row"><b>Page:</b> ${esc(page())} · <b>Build:</b> ${esc(meta.build||window.__cpBuildId||'?')} · <b>Bridge:</b> ${esc(meta.bridge||'?')}</div>`);for(const [k,v] of Object.entries(window.__cpDiagResults)){const ok=v.ok===true;const cls=ok?'cp-diag-ok':(v.ok===false?'cp-diag-bad':'cp-diag-warn');let line=`<div class="cp-diag-row"><span class="${cls}"><b>${esc(k)}</b> — ${ok?'OK':v.ok===false?'ERROR':'WAIT'}</span>`;if(v.http!=null)line+=` · HTTP ${esc(v.http)}`;if(v.ms!=null)line+=` · ${esc(v.ms)}ms`;if(v.error)line+=`<div class="cp-diag-pre">${esc(v.error)}</div>`;if(v.exception)line+=`<div class="cp-diag-pre">${esc(v.exception)}</div>`;if(v.errorBody)line+=`<div class="cp-diag-pre">${esc(v.errorBody)}</div>`;line+='</div>';rows.push(line)}if(window.__cpDiagRuntime.length)rows.push(`<div class="cp-diag-row cp-diag-bad"><b>Runtime errors</b><div class="cp-diag-pre">${esc(window.__cpDiagRuntime.slice(-5).join('\n'))}</div></div>`);if(!Object.keys(window.__cpDiagResults).length)rows.push('<div class="cp-diag-row cp-diag-muted">هنوز تستی اجرا نشده است.</div>');box.innerHTML=rows.join('')}
 window.cpShowDiagnostics=function(){ensureStyle();let el=document.getElementById('cpDiag');if(!el){el=document.createElement('section');el.id='cpDiag';el.className='cp-diag';el.innerHTML='<div class="cp-diag-head"><span class="cp-diag-title">🛠 عیب‌یابی بازار</span><div class="cp-diag-actions"><button id="cpDiagRun">تست</button><button id="cpDiagCopy">کپی</button><button id="cpDiagClose">×</button></div></div><div id="cpDiagBody" class="cp-diag-body"></div>';document.body.appendChild(el);el.querySelector('#cpDiagClose').onclick=()=>el.classList.remove('open');el.querySelector('.cp-diag-title').onclick=()=>el.classList.toggle('open');el.querySelector('#cpDiagRun').onclick=()=>window.cpRunDiagnostics(true);el.querySelector('#cpDiagCopy').onclick=()=>window.cpCopyDiagnostics();}render();el.classList.add('open');}
 window.cpRecheckNativeBridge=function(){ensureStyle();window.__cpDiagResults['Native Bridge']={ok:!!window.CryptoPulseNative,error:window.CryptoPulseNative?'':'CryptoPulseNative unavailable in this document'};render();if(window.CryptoPulseNative)window.cpRunDiagnostics(true)};
 window.cpRunDiagnostics=function(force){ensureStyle();window.cpShowDiagnostics();const id='diag_'+Date.now();window.__cpDiagResults={};window.__cpDiagResults['Native Bridge']={ok:!!window.CryptoPulseNative};if(!window.CryptoPulseNative){render();return}try{window.__cpDiagMeta=JSON.parse(window.CryptoPulseNative.getNativeDiagnosticsMeta()||'{}')}catch(e){}try{window.CryptoPulseNative.runOurbitDiagnostics(id)}catch(e){window.__cpDiagResults['Native diagnostics']={ok:false,error:String(e?.message||e)};render();}}
 window.cpNativeDiagnostics=function(rid,payload){try{const d=JSON.parse(payload||'{}');for(const t of (d.tests||[])){window.__cpDiagResults[t.name]=t;}window.__cpDiagResults['Diagnostics complete']={ok:true};}catch(e){window.__cpDiagResults['Diagnostics parser']={ok:false,error:String(e?.message||e)}}render();}
 window.cpCopyDiagnostics=function(){const text=JSON.stringify({page:page(),build:window.__cpDiagMeta,results:window.__cpDiagResults,runtime:window.__cpDiagRuntime},null,2);try{navigator.clipboard?.writeText(text);toast?.('گزارش عیب‌یابی کپی شد')}catch(e){window.prompt('Diagnostics',text)}}
 window.__cpDiagRuntimePush=function(msg){window.__cpDiagRuntime.push(String(msg));if(window.__cpDiagRuntime.length>20)window.__cpDiagRuntime.shift();render()}
 window.cpInstallPageDiagnostics=function(){ensureStyle();window.cpShowDiagnostics();let tries=0;const wait=()=>{tries++;if(window.CryptoPulseNative){window.cpRunDiagnostics(true);return}if(tries<12){setTimeout(wait,250);return}window.__cpDiagResults['Native Bridge']={ok:false,error:'CryptoPulseNative unavailable: the Android native bridge is not exposed in this WebView document.'};render()};setTimeout(wait,120)}
})();

function layout(title,subtitle,body,active){
 const prefs=safeSettings();
 document.documentElement.dataset.theme=prefs.theme||'Dark Pro';
 const safeBody=body==null?'':String(body);
 document.body.innerHTML=`<div class="app"><header class="top"><div class="brand"><a class="top-profile-btn" href="profile.html" aria-label="پروفایل">◉</a><div class="logo brand-logo"><img src="cryptopulse_new_logo.png" alt="CryptoPulse"></div><div><b>CryptoPulse</b><small>${subtitle||title||''}</small></div></div><div class="top-actions"><a class="top-settings-btn" href="settings.html" aria-label="تنظیمات">⚙</a><a class="notify-head" href="notifications.html" aria-label="اعلان‌ها">♧<em id="notifyBadge" class="${unreadNotifications()?'has':''}" style="display:${unreadNotifications()?'block':'none'}"></em></a><span id="dataStatus" class="pill">● CONNECTING</span></div></header><div id="cpLiveOverlay" class="cp-live-overlay"><img class="cp-live-logo" src="cryptopulse_new_logo.png" alt="CryptoPulse"></div>${safeBody}<div id="toast" class="toast"></div></div>${navHTML(active)}`;
 applyLanguage();startDigitObserver();
 try{window.__cpCurrentPage=active?String(active).replace(/\.html$/i,''):((location.pathname.split('/').pop()||'index.html').replace(/\.html$/i,''));window.cpInstallPageDiagnostics&&window.cpInstallPageDiagnostics();}catch(_e){}
 // Preserve the real connection state when Home/Markets/other pages are swapped
 // inside the same WebView. layout() used to recreate the header as CONNECTING
 // even while the same socket/native feed was still live.
 try{const recent=Object.values(liveCache).some(v=>Number(v?.price)>0 && Number(v?.lastUpdate)>0 && Date.now()-Number(v.lastUpdate)<45000); setDataStatus(recent);}catch(_e){}
}
window.addEventListener('error',e=>{
 try{
  // Ignore browser resource-loading events (e.g. image/font/CSS failures).
  // They don't carry a JS message/exception and must never become a generic
  // app error toast on pages such as Orders.
  if(!e?.message && !e?.error?.message && !e?.error)return;
  const msg=String(e?.message||e?.error?.message||'Unknown runtime error');
  const src=e?.filename?String(e.filename):'';
  const line=e?.lineno?String(e.lineno):'';
  const col=e?.colno?String(e.colno):'';
  const detail=msg+(src?' @ '+src:'')+(line?':'+line+(col?':'+col:''):'');
  console.error('CryptoPulse runtime error',e?.error||detail);
  const d=window.__cpChartDiag||{};
  d.runtimeError=detail; d.runtimeStack=String(e?.error?.stack||''); try{window.__cpDiagRuntimePush&&window.__cpDiagRuntimePush(detail)}catch(_e){}
  if(window.__cpChartDiag){window.__cpChartDiag=d;}
  const pre=document.getElementById('diagDetails');
  if(pre&&window.__cpChartDiag){pre.textContent=(pre.textContent||'')+'\nRuntime error: '+detail+(d.runtimeStack?'\n'+d.runtimeStack:'');}
  // Chart pages can remain usable after a non-fatal background exception.
  // Do not cover a working K-Line with the generic error toast.
  const isAsset=/asset\.html(?:$|[?#])/i.test(String(location.href||''));
  const isOrders=window.__cpCurrentPage==='orders';
  const isNotifications=window.__cpCurrentPage==='notifications';
  // Non-fatal runtime errors are logged for diagnostics but must not block the UI with a generic toast.
  // Individual operations/pages handle user-facing errors where appropriate.
 }catch(_e){}
});
window.addEventListener('unhandledrejection',e=>{
 try{
  const reason=e?.reason; const msg=String(reason?.message||reason||'Unhandled promise rejection');
  const d=window.__cpChartDiag||{}; d.runtimeError='Promise: '+msg; d.runtimeStack=String(reason?.stack||''); try{window.__cpDiagRuntimePush&&window.__cpDiagRuntimePush('Promise: '+msg)}catch(_e){}
  if(window.__cpChartDiag){window.__cpChartDiag=d;}
  const pre=document.getElementById('diagDetails');
  if(pre){pre.textContent=(pre.textContent||'')+'\nUnhandled promise: '+msg+(d.runtimeStack?'\n'+d.runtimeStack:'');}
  const isAsset=/asset\.html(?:$|[?#])/i.test(String(location.href||''));
  const isOrders=window.__cpCurrentPage==='orders';
  const isNotifications=window.__cpCurrentPage==='notifications';
  // Avoid a global error toast for background promise rejections; keep the UI usable.
  // Page-specific operations can surface their own actionable messages.
 }catch(_e){}
});
let coins=[];
// TV69: expose the live shared state to SPA pages loaded with eval().
// app.js keeps these as lexical variables; window.liveCache/window.coins were
// therefore empty/undefined inside markets.html even though Home had live data.
try{
  Object.defineProperty(window,'liveCache',{configurable:true,get:()=>liveCache});
  Object.defineProperty(window,'coins',{configurable:true,get:()=>coins});
}catch(_e){}
// TV55: legacy 9-coin seed is forbidden. The market list must come only from the
// live LBank universe/cache. This guard also clears an old persisted 9-coin seed.
(function(){
  try{
    const legacy=['BTC','ETH','SOL','BNB','XRP','ADA','DOGE','AVAX','LINK'];
    const raw=localStorage.getItem('cp_lbank_legacy_seed');
    if(raw==='9') localStorage.removeItem('cp_lbank_legacy_seed');
  }catch(_e){}
})();
const navFa=[['index.html','⌂','خانه'],['spot.html','⇄','معامله'],['futures.html','↗','فیوچرز'],['assets.html','◫','کیف پول']];
const navEn=[['index.html','⌂','Home'],['spot.html','⇄','Trade'],['futures.html','↗','Futures'],['assets.html','◫','Wallet']];
const moreFa=[['analysis.html','⌁','تحلیل'],['strategies.html','◎','استراتژی']];
const moreEn=[['analysis.html','⌁','Analysis'],['strategies.html','◎','Strategies']];
const isEnglish=()=>((safeSettings().lang||'فارسی')==='English');
const nav=()=>isEnglish()?navEn:navFa;
const moreNav=()=>isEnglish()?moreEn:moreFa;
const state=()=>{try{const d=JSON.parse(localStorage.getItem('cp_state'))||{};return {balance:+(d.balance??10000),history:Array.isArray(d.history)?d.history:[],open:d.open||null,openOrders:Array.isArray(d.openOrders)?d.openOrders:[],spot:Array.isArray(d.spot)?d.spot:[],holdings:d.holdings&&typeof d.holdings==='object'?d.holdings:{}}}catch(e){return{balance:10000,history:[],open:null,openOrders:[],spot:[],holdings:{}}}};
function saveState(s){localStorage.setItem('cp_state',JSON.stringify(s))}
function navHTML(active){
 const n=nav();
 const items=n.map(x=>`<a class="nav-item ${x[0]===active?'active':''}" href="${x[0]}" data-nav="${x[0]}" aria-label="${x[2]}"><span>${x[1]}</span>${x[2]}</a>`).join('');
 return `<nav class="nav" id="bottomNav">${items}</nav>`;
}
function toggleMoreNav(){}
let cpRouterBusy=false;
let __cpAssetTemplate='';
let __cpAssetWarmStarted=false;
function cpWarmAssetTemplate(){
  if(__cpAssetWarmStarted||__cpAssetTemplate)return;
  __cpAssetWarmStarted=true;
  try{
    if(window.CryptoPulseNative&&typeof window.CryptoPulseNative.getLocalPage==='function'){
      const h=window.CryptoPulseNative.getLocalPage('asset.html');
      if(h) __cpAssetTemplate=String(h);
      return;
    }
  }catch(_e){}
  try{fetch('asset.html',{cache:'force-cache'}).then(r=>r.ok?r.text():'').then(h=>{if(h)__cpAssetTemplate=h}).catch(()=>{});}catch(_e){}
}
async function cpLoadLocalPage(href,replace=false){
  if(cpRouterBusy)return false;
  cpRouterBusy=true;
  try{
    const u=new URL(href,location.href);
    const path=u.pathname.split('/').pop()||'index.html';
    if(!/^[a-zA-Z0-9_-]+\.html$/.test(path))throw new Error('external route');
    let html='';
    if(path==='asset.html'&&__cpAssetTemplate){
      html=__cpAssetTemplate;
    }else if(window.CryptoPulseNative&&typeof window.CryptoPulseNative.getLocalPage==='function'){
      html=window.CryptoPulseNative.getLocalPage(path);
    }else{
      const r=await fetch(path,{cache:'no-store'}); if(!r.ok)throw new Error('page '+r.status); html=await r.text();
    }
    if(!html)throw new Error('empty page');
    const doc=new DOMParser().parseFromString(html,'text/html');
    const scripts=[...doc.querySelectorAll('script')].filter(s=>!s.src).map(s=>s.textContent||'').filter(Boolean);
    const title=doc.querySelector('title')?.textContent||'CryptoPulse';
    if(replace)history.replaceState({cp:true},'',u.pathname+u.search+u.hash); else history.pushState({cp:true},'',u.pathname+u.search+u.hash);
    document.title=title;
    // Mark the destination before its script runs so global error handling and
    // page-specific cleanup know which screen is actually active.
    window.__cpCurrentPage=path.replace(/\.html$/i,'');
    // Stop the previous page's timers/listeners before evaluating the new route.
    // Without this, Trade's background chart/ticker tasks could keep touching the
    // DOM after navigating to Orders and produce a misleading generic error toast.
    try{if(typeof window.__cpPageCleanup==='function')window.__cpPageCleanup()}catch(_e){}
    window.__cpPageCleanup=null;
    for(const code of scripts){
      try{(0,eval)('(function(){\n'+code+'\n})()')}catch(err){console.error('CryptoPulse page script',err)}
    }
    return true;
  }catch(e){
    // Only fall back to a real navigation for an unsupported route.
    try{if(!String(href).startsWith('http'))window.location.href=href;else window.location.href=href}catch(_e){}
    return false;
  }finally{cpRouterBusy=false}
}
function navigateLocal(href){if(!href)return false;cpLoadLocalPage(href,false);return false}
function bindPersistentRouter(){
  if(window.__cpPersistentRouter)return;
  window.__cpPersistentRouter=true;
  document.addEventListener('click',e=>{
    const a=e.target.closest?.('a[href]'); if(!a)return;
    const raw=a.getAttribute('href')||'';
    if(!raw||raw.startsWith('#')||raw.startsWith('javascript:')||raw.startsWith('http:')||raw.startsWith('https:')||raw.startsWith('mailto:'))return;
    const u=new URL(raw,location.href);
    if(!/\.html$/i.test(u.pathname))return;
    e.preventDefault();e.stopPropagation();
    // REBUILD-PERSISTENCE: keep one WebView/JS context alive for every internal
    // CryptoPulse page. Full WebView navigation destroys the JS cache and forces
    // Market/Trade/Futures connections to reconnect; the persistent SPA router
    // instead swaps the local page script into the existing document.
    const localPath=u.pathname.split('/').pop()+u.search+u.hash;
    navigateLocal(localPath);
  },true);
  window.addEventListener('popstate',()=>{
    const path=location.pathname.split('/').pop()||'index.html';
    cpLoadLocalPage(path+location.search+location.hash,true);
  });
}
bindPersistentRouter();
// MOBILE FIX 1171: a cold Android WebView must never inherit Settings/Profile
// as its first visible route. Navigation inside the running SPA remains allowed;
// this guard only applies during the initial index bootstrap.
(function cpColdStartHomeGuard(){
  try{
    if(window.__cpColdStartHomeGuard)return;
    window.__cpColdStartHomeGuard=true;
    const p=(location.pathname.split('/').pop()||'index.html').toLowerCase();
    if(p!=='index.html' && !window.__cpCurrentPage){
      window.history.replaceState({cp:true},'', 'index.html');
      if(typeof window.layout==='function'){}
    }
  }catch(_e){}
})();
// Preload the lightweight asset page template in the background on Home so a coin tap
// can render the chart shell immediately instead of waiting for a native page fetch.
try{if(/(?:^|\/)index\.html(?:$|[?#])/i.test(String(location.href||''))){
  if('requestIdleCallback' in window) requestIdleCallback(()=>cpWarmAssetTemplate(),{timeout:700});
  else setTimeout(cpWarmAssetTemplate,250);
}}catch(_e){}
function bindBottomNav(){
 const go=e=>{const el=e.currentTarget;const href=el.getAttribute('data-nav')||el.getAttribute('href');if(!href)return;e.preventDefault();e.stopPropagation();navigateLocal(href)};
 document.querySelectorAll('#bottomNav [data-nav]').forEach(a=>{a.addEventListener('click',go,false);a.addEventListener('touchend',go,{passive:false})});
}
async function binanceFetch(path){
  let lastErr;
  for(const base of API_BASES){const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),7000);try{const r=await fetch(base+path,{cache:'no-store',signal:ctl.signal});if(!r.ok)throw new Error('HTTP '+r.status);return await r.json()}catch(e){lastErr=e}finally{clearTimeout(timer)}}
  throw lastErr||new Error('network');
}
async function api(path){return binanceFetch(path)}
function handleLiveMessage(m){
  if(!m||typeof m!=='object')return;
  const h=liveHub;
  if(m.action==='ping'&&m.ping){try{h.ws?.send(JSON.stringify({action:'pong',pong:m.ping}))}catch(e){};return}
  // LBank V2 tick packets from the proven Android WebSocket test have no
  // top-level `type`. The type is inside `tick.type` and the pair is inside
  // `tick.pair`, e.g. {SERVER:'V2', tick:{type:'tick',pair:'btc_usdt',latest:'...'}}.
  // Accept both the documented/envelope form and the test-proven V2 form.
  const tEnvelope=m.tick||m.ticker||m.data?.tick||m.data?.ticker;
  const type=String(m.type||tEnvelope?.type||'').toLowerCase();
  const channel=String(m.channel||'').toLowerCase();
  const isTicker=type==='tick'||channel.includes('_ticker')||channel.includes('ticker')||!!(tEnvelope&&tEnvelope.pair&&tEnvelope.latest!=null);
  const raw=String(m.pair||m.symbol||tEnvelope?.pair||channel.match(/(?:market_)?([^_]+_[^_]+)_ticker/i)?.[1]||'').toUpperCase();
  const key=raw.endsWith('_USDT')?raw.slice(0,-5):raw.replace('USDT','');
  if(!key)return;
  const t=tEnvelope;
  if(isTicker&&t){
    const price=Number(t.latest??t.lastPrice??t.last??t.price??t.close??t.closePrice);
    if(Number.isFinite(price)&&price>0){
      const out={price,change:Number(t.change??t.changeRate??t.changePercent??t.rose??0),volume:Number(t.vol??t.volume??t.amount??0),high:Number(t.high??price),low:Number(t.low??price),connected:true,lastUpdate:Date.now(),provider:'Ourbit'};
      liveCache[key]={...(liveCache[key]||{}),...out};
      // REBUILD19: the APK loads app/src/main/assets/web/app.js, not the
      // duplicate project-root app.js. Keep the visible Home row synchronized
      // directly from the proven LBank tick instead of only updating liveCache.
      const c=coins.find(x=>cpCanonicalSymbol(x[0])===key);
      if(c){
        c[2]=String(out.price);
        c[3]=(Number(out.change)>=0?'+':'')+Number(out.change||0).toFixed(2)+'%';
        c[4]=String(Number(out.volume)||0);
      }
      persistSharedLiveCache();confirmLivePrice(price);notifyLive(key,{type:'ticker',...out,event:m});
      try{syncHomeLiveRow(key,out)}catch(e){}
      try{window.dispatchEvent(new CustomEvent('cp-live-ticker',{detail:{symbol:key,price:out.price,change:out.change,high:out.high,low:out.low,volume:out.volume,at:out.lastUpdate}}))}catch(e){}
    }
  }
  if(type==='trade'&&m.trade){const t=m.trade;const price=Number(t.price??t.p);if(Number.isFinite(price)){const tsRaw=t.TS??t.ts??t.time;const n=Number(tsRaw);const ts=Number.isFinite(n)?(n<100000000000?n*1000:n):(Date.parse(String(tsRaw))||Date.now());liveCache[key]={...(liveCache[key]||{}),price,lastUpdate:Date.now(),connected:true,provider:'Ourbit'};persistSharedLiveCache();notifyLive(key,{type:'ticker',price,ts,trade:t});try{window.dispatchEvent(new CustomEvent('cp-live-tick',{detail:{symbol:key,price,ts}}))}catch(e){}}}
  if(type==='kbar'&&m.kbar){const k=m.kbar;const rawTs=Number(k.t);const kt=Number.isFinite(rawTs)?(rawTs<100000000000?rawTs*1000:rawTs):Date.now();const row=[kt,String(k.o),String(k.h),String(k.l),String(k.c),String(k.v),Date.now(),'0','0','0','0','0'];liveCache[key]={...(liveCache[key]||{}),price:+k.c,kline:row,connected:true,lastUpdate:Date.now(),provider:'Ourbit'};persistSharedLiveCache();notifyLive(key,{type:'kline',row,kline:k});try{window.dispatchEvent(new CustomEvent('cp-live-kline',{detail:{symbol:key,row}}))}catch(e){}}
  if(type==='depth'&&m.depth){const d=m.depth||{};const norm=(arr)=>Array.isArray(arr)?arr.map(x=>Array.isArray(x)?[Number(x[0]),Number(x[1])]:[Number(x?.price??x?.p),Number(x?.amount??x?.qty??x?.volume??x?.v)]).filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1])):[];const asks=norm(d.asks),bids=norm(d.bids);if(asks.length||bids.length){const payload={type:'depth',asks,bids,at:Date.now(),event:m};liveCache[key]={...(liveCache[key]||{}),depth:{asks,bids,at:payload.at},lastUpdate:payload.at,connected:true,provider:'Ourbit'};persistSharedLiveCache();notifyLive(key,payload);try{window.dispatchEvent(new CustomEvent('cp-live-depth',{detail:{symbol:key,asks,bids,at:payload.at}}))}catch(e){}}}
}
function closeLiveHub(){const h=liveHub;if(h.timer){clearTimeout(h.timer);h.timer=null}if(h.watchdog){clearInterval(h.watchdog);h.watchdog=null}if(h.pingTimer){clearInterval(h.pingTimer);h.pingTimer=null}const ws=h.ws;h.ws=null;h.connecting=false;if(ws){try{ws.onclose=null;ws.close()}catch(e){}}Object.keys(liveSockets).forEach(k=>delete liveSockets[k])}
function scheduleLiveReconnect(){const h=liveHub;if(h.timer||!navigator.onLine)return;const delay=Math.min(30000,Math.max(1200,1800*Math.pow(1.7,h.retry++)))+Math.floor(Math.random()*600);h.timer=setTimeout(()=>{h.timer=null;startLiveSocket()},delay)}
const liveDesiredSymbols=new Set();
const liveSubscribedSymbols=new Set();
// REBUILD35: shared K-line history request over the already-running Home socket.
const sharedKlineRequests=[];
function cpKlineSlot(tf){return ({live:'1min','1m':'1min','5m':'5min','15m':'15min','1h':'1hr','4h':'4hr','1d':'day','1w':'week'})[tf]||'1min'}
function cpKlineStep(tf){return ({live:60000,'1m':60000,'5m':300000,'15m':900000,'1h':3600000,'4h':14400000,'1d':86400000,'1w':604800000})[tf]||60000}
function cpKlineRowsFromMessage(m,target){const out=[];const num=v=>{if(typeof v==='number')return v;const n=Number(String(v??'').trim());return Number.isFinite(n)?n:NaN};const addArr=a=>{if(!Array.isArray(a)||a.length<5)return;const n=a.slice(0,6).map(num);if(!n.slice(0,5).every(Number.isFinite))return;const ts=n[0]<1e11?n[0]*1000:n[0];out.push([ts,n[1],n[2],n[3],n[4],Number.isFinite(n[5])?n[5]:0])};const addObj=k=>{if(!k||typeof k!=='object')return;const o=num(k.o??k.open),h=num(k.h??k.high),l=num(k.l??k.low),c=num(k.c??k.close),v=num(k.v??k.volume??0);if(![o,h,l,c].every(Number.isFinite))return;let ts=Date.parse(String(k.t??''));if(!Number.isFinite(ts)){const n=num(k.t??k.time??k.timestamp);ts=Number.isFinite(n)?(n<1e11?n*1000:n):NaN}if(Number.isFinite(ts))out.push([ts,o,h,l,c,Number.isFinite(v)?v:0])};const walk=v=>{if(v==null)return;if(typeof v==='string'){const t=v.trim();if(!t)return;try{walk(JSON.parse(t))}catch(_e){}return}if(Array.isArray(v)){if(v.length>=5&&v.every((x,i)=>i===0||typeof x!=='object'))addArr(v);else v.forEach(walk);return}if(typeof v==='object'){if(v.o!=null||v.open!=null||v.c!=null||v.close!=null)addObj(v);for(const k of Object.keys(v))walk(v[k]);}};const pairRaw=String(m?.pair||m?.kbar?.pair||m?.data?.pair||'').toLowerCase();if(target&&pairRaw&&pairRaw!==pair(target).toLowerCase())return [];walk(m);const map=new Map();out.forEach(r=>{const t=Number(r[0]);if(Number.isFinite(t))map.set(t,r)});return [...map.values()].sort((a,b)=>a[0]-b[0])}
function cpFlushSharedKlineRequests(){const ws=liveHub.ws;if(!ws||ws.readyState!==WebSocket.OPEN)return;for(const q of sharedKlineRequests){if(q.sent||q.done)continue;q.sent=true;const now=Math.floor(Date.now()/1000),step=Math.floor(cpKlineStep(q.tf)/1000),size=Math.min(240,Math.max(20,q.limit||240));try{ws.send(JSON.stringify({action:'request',request:'kbar',kbar:cpKlineSlot(q.tf),pair:pair(q.symbol),start:String(now-step*size),end:String(now),size:String(size)}));q.state='SENT'}catch(e){q.done=true;q.reject(e);continue}q.timer=setTimeout(()=>{if(q.done)return;q.done=true;const rows=[...q.rows.values()].sort((a,b)=>a[0]-b[0]);if(rows.length>=10)q.resolve(rows);else q.reject(Error('shared WebSocket returned '+rows.length+' candles'))},4000)}}
function cpRequestLBankKlines(symbol,tf,limit){return new Promise((resolve,reject)=>{const q={symbol:String(symbol||'').toUpperCase(),tf:String(tf||'live'),limit:limit||240,rows:new Map(),resolve,reject,sent:false,done:false,state:'WAIT',createdAt:Date.now()};sharedKlineRequests.push(q);if(!liveHub.ws||liveHub.ws.readyState!==WebSocket.OPEN)startLiveSocket();const wait=()=>{if(q.done)return;const w=liveHub.ws;if(w&&w.readyState===WebSocket.OPEN){cpFlushSharedKlineRequests();return}if(Date.now()-q.createdAt>7000){q.done=true;reject(Error('shared WebSocket did not open'));return}setTimeout(wait,120)};wait()})}
window.cpRequestLBankKlines=cpRequestLBankKlines;
function cpHandleSharedKlineMessage(m){if(!m)return;window.__cpLastSharedKlineMessage=JSON.stringify(m).slice(0,1800);const targetPair=String(m.pair||m.kbar?.pair||m.data?.pair||'').toLowerCase();for(const q of sharedKlineRequests){if(q.done)continue;if(targetPair&&targetPair!==pair(q.symbol).toLowerCase())continue;const parsed=cpKlineRowsFromMessage(m,q.symbol);q.lastParsed=parsed.length;parsed.forEach(r=>q.rows.set(r[0],r));if(q.rows.size>=10){q.done=true;if(q.timer)clearTimeout(q.timer);const rows=[...q.rows.values()].sort((a,b)=>a[0]-b[0]).slice(-Math.min(240,q.limit||240));q.resolve(rows)}}}
function sendLiveSubscription(ws,key){
  const sym=String(key||'').toUpperCase(); if(!sym||!ws||ws.readyState!==WebSocket.OPEN)return;
  const p=pair(sym);
  try{ws.send(JSON.stringify({action:'subscribe',subscribe:'tick',pair:p}))}catch(e){}
  try{ws.send(JSON.stringify({action:'subscribe',subscribe:'depth',depth:'100',pair:p}))}catch(e){}
  liveSubscribedSymbols.add(sym); liveSockets[sym]=ws;
}
function ensureLiveSubscriptions(symbols){
  const list=[...new Set((symbols||[]).map(x=>String(x||'').toUpperCase()).filter(Boolean))];
  list.forEach(s=>liveDesiredSymbols.add(s));
  const ws=liveHub.ws;
  if(ws&&ws.readyState===WebSocket.OPEN){
    const desired=[...liveDesiredSymbols];
    // LBank accepts pair subscriptions on the same socket; keep only a bounded
    // active window and rotate that window so every market eventually receives
    // real-time ticks instead of freezing after the first 60 symbols.
    const max=80;
    const slice=desired.slice(liveRotationCursor,liveRotationCursor+max);
    const batch=slice.length?slice:desired.slice(0,max);
    batch.forEach(s=>{if(!liveSubscribedSymbols.has(s))sendLiveSubscription(ws,s)});
  }
}
function ensureLiveKlineSubscription(symbols){
  const list=[...new Set((symbols||[]).map(x=>String(x||'').toUpperCase()).filter(Boolean))];
  const ws=liveHub.ws;
  if(!ws||ws.readyState!==WebSocket.OPEN||!list.length)return;
  list.forEach(sym=>{try{ws.send(JSON.stringify({action:'subscribe',subscribe:'kbar',kbar:'1min',pair:pair(sym)}))}catch(_e){} try{ws.send(JSON.stringify({action:'subscribe',subscribe:'depth',depth:'100',pair:pair(sym)}))}catch(_e){}});
}
function startLiveRotation(){
  if(liveRotationTimer)return;
  liveRotationTimer=setInterval(()=>{
    const ws=liveHub.ws;
    if(!ws||ws.readyState!==WebSocket.OPEN)return;
    const desired=[...liveDesiredSymbols];
    if(!desired.length)return;
    const max=80;
    liveRotationCursor=(liveRotationCursor+max)%desired.length;
    // Keep the socket bounded: unsubscribe the old window before subscribing
    // the next one, then retain the cache so prices remain visible between ticks.
    [...liveSubscribedSymbols].forEach(sym=>{
      try{ws.send(JSON.stringify({action:'unsubscribe',subscribe:'tick',pair:pair(sym)}))}catch(_e){}
      try{ws.send(JSON.stringify({action:'unsubscribe',subscribe:'trade',pair:pair(sym)}))}catch(_e){}
      try{ws.send(JSON.stringify({action:'unsubscribe',subscribe:'kbar',kbar:'1min',pair:pair(sym)}))}catch(_e){}
      try{ws.send(JSON.stringify({action:'unsubscribe',subscribe:'depth',depth:'100',pair:pair(sym)}))}catch(_e){}
    });
    liveSubscribedSymbols.clear();
    const batch=desired.slice(liveRotationCursor,liveRotationCursor+max);
    (batch.length?batch:desired.slice(0,max)).forEach(sym=>sendLiveSubscription(ws,sym));
  },10000);
}
function startLiveSocket(){
  // REBUILD15: browser WebSocket is the proven Android/WebView transport.
  // The standalone connection test on the same device successfully opened
  // api.lbank.info and received live BTC ticks, so use that exact path here.
  const h=liveHub;
  if(h.ws&&[WebSocket.OPEN,WebSocket.CONNECTING].includes(h.ws.readyState))return;
  if(!navigator.onLine||h.connecting)return;
  h.connecting=true; h.provider='lbank';
  let ws;
  try{const host=LBANK_WS_BASES[h.retry%LBANK_WS_BASES.length];ws=new WebSocket(host);h.wsHost=host}catch(e){h.connecting=false;scheduleLiveReconnect();return}
  h.ws=ws;
  ws.onopen=()=>{
    h.connecting=false;h.retry=0;
    // WebSocket OPEN is only transport readiness; do not call the app LIVE until a real price arrives.
    setDataStatus(false);
    liveSubscribedSymbols.clear();
    const priority=['BTC','ETH','BNB','SOL','XRP','DOGE','ADA','TRX'];
    const baseSymbols=liveDesiredSymbols.size?[...liveDesiredSymbols]:(coins.length?coins.map(c=>c[0]):priority);
    const initial=[...new Set([...priority,...baseSymbols])].slice(0,80);
    initial.forEach(sym=>sendLiveSubscription(ws,sym));
    initial.forEach(sym=>{try{ws.send(JSON.stringify({action:'subscribe',subscribe:'kbar',kbar:'1min',pair:pair(sym)}))}catch(_e){}});
    cpFlushSharedKlineRequests();
    liveRotationCursor=0;
    startLiveRotation();
    if(h.pingTimer)clearInterval(h.pingTimer);h.pingTimer=setInterval(()=>{try{if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({action:'ping',ping:String(Date.now())}))}catch(e){}},25000);
  };
  ws.onmessage=e=>{liveHub.lastMessage=Date.now();try{const raw=typeof e.data==='string'?e.data:new TextDecoder().decode(e.data);const msg=JSON.parse(raw);cpHandleSharedKlineMessage(msg);handleLiveMessage(msg)}catch(err){}};
  ws.onerror=()=>{try{ws.close()}catch(e){}};
  ws.onclose=()=>{if(h.ws===ws)h.ws=null;h.connecting=false;h.retry++;if(h.pingTimer){clearInterval(h.pingTimer);h.pingTimer=null}Object.keys(liveSockets).forEach(k=>delete liveSockets[k]);setDataStatus(false);scheduleLiveReconnect()};
  if(h.watchdog)clearInterval(h.watchdog);
  h.watchdog=setInterval(()=>{if(h.ws&&h.ws.readyState===WebSocket.OPEN&&Date.now()-h.lastMessage>60000){try{h.ws.close()}catch(e){}}else if(!h.ws&&!h.connecting&&navigator.onLine)startLiveSocket()},5000);
}
function subscribeLive(sym,fn){const key=String(sym).toUpperCase();liveDesiredSymbols.add(key);(liveListeners[key]||(liveListeners[key]=[])).push(fn);startLiveSocket();if(liveHub.ws&&liveHub.ws.readyState===WebSocket.OPEN&&!liveSubscribedSymbols.has(key))sendLiveSubscription(liveHub.ws,key);return ()=>{liveListeners[key]=(liveListeners[key]||[]).filter(x=>x!==fn)}}
const __cpAssetWaiters={ticker:new Map(),depth:new Map()};
window.cpNativeAssetTicker=function(id,payload){const f=__cpAssetWaiters.ticker.get(String(id));if(!f)return;__cpAssetWaiters.ticker.delete(String(id));try{f(JSON.parse(payload||'{}'))}catch(e){f(null)}};
window.cpNativeAssetDepth=function(id,payload){const f=__cpAssetWaiters.depth.get(String(id));if(!f)return;__cpAssetWaiters.depth.delete(String(id));try{f(JSON.parse(payload||'{}'))}catch(e){f(null)}};
function nativeAssetTicker(sym){return new Promise(resolve=>{if(!window.CryptoPulseNative?.fetchLBankAssetTicker)return resolve(null);const id='t'+Date.now()+Math.random();__cpAssetWaiters.ticker.set(id,resolve);try{window.CryptoPulseNative.fetchLBankAssetTicker(String(sym),id)}catch(e){__cpAssetWaiters.ticker.delete(id);resolve(null)}setTimeout(()=>{if(__cpAssetWaiters.ticker.has(id)){__cpAssetWaiters.ticker.delete(id);resolve(null)}},9000)})}
function nativeAssetDepth(sym,limit=10){return new Promise(resolve=>{if(!window.CryptoPulseNative?.fetchLBankAssetDepth)return resolve(null);const id='d'+Date.now()+Math.random();__cpAssetWaiters.depth.set(id,resolve);try{window.CryptoPulseNative.fetchLBankAssetDepth(String(sym),Number(limit)||10,id)}catch(e){__cpAssetWaiters.depth.delete(id);resolve(null)}setTimeout(()=>{if(__cpAssetWaiters.depth.has(id)){__cpAssetWaiters.depth.delete(id);resolve(null)}},9000)})}

async function lbankContractFetch(path){let lastErr;for(const base of LBANK_CONTRACT_BASES){const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),7000);try{const r=await fetch(base+path,{cache:'no-store',signal:ctl.signal});if(!r.ok)throw new Error('HTTP '+r.status);return await r.json()}catch(e){lastErr=e}finally{clearTimeout(timer)}}throw lastErr||new Error('contract network')}
function normalizeContractSymbol(sym){const k=String(sym||'BTC').toUpperCase();return k.endsWith('USDT')?k:k+'USDT'}
async function futuresMarketData(sym){const key=normalizeContractSymbol(sym).replace(/USDT$/,'_USDT');const d=await ourbitContractFetch('/api/v1/contract/ticker?symbol='+encodeURIComponent(key));const src=d?.data||d;const hit=Array.isArray(src)?src.find(x=>String(x?.symbol||'').toUpperCase().replace(/[^A-Z0-9]/g,'')===key.replace(/[^A-Z0-9]/g,'')):src;const lastPrice=Number(hit?.lastPrice??hit?.last??hit?.price??hit?.fairPrice);if(!Number.isFinite(lastPrice)||lastPrice<=0)throw new Error('Ourbit Futures ticker unavailable');return {lastPrice,markedPrice:Number(hit?.markedPrice??hit?.markPrice??lastPrice)||lastPrice,openPrice:Number(hit?.openPrice??hit?.open??lastPrice)||lastPrice,high:Number(hit?.highestPrice??hit?.highPrice??hit?.high??lastPrice)||lastPrice,low:Number(hit?.lowestPrice??hit?.lowPrice??hit?.low??lastPrice)||lastPrice,volume:Number(hit?.volume??hit?.vol??0)||0,funding:Number(hit?.prePositionFeeRate??hit?.fundingRate??0)||0,symbol:hit?.symbol||key,provider:'Ourbit Futures'} }
async function futuresMarketOrder(sym,depthN=20){const key=normalizeContractSymbol(sym).replace(/USDT$/,'_USDT');const d=await ourbitContractFetch('/api/v1/contract/depth_commits/'+encodeURIComponent(key)+'/'+Math.min(50,Math.max(1,depthN)));const src=d?.data||d||{};const norm=a=>(Array.isArray(a)?a:[]).map(x=>Array.isArray(x)?[Number(x[0]),Number(x[1])]:[Number(x?.price??x?.p),Number(x?.volume??x?.qty??x?.amount)]).filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));return {asks:norm(src.asks||src.ask),bids:norm(src.bids||src.bid)} }
async function futuresKlines(sym,interval='1m',limit=240){const key=normalizeContractSymbol(sym).replace(/USDT$/,'_USDT');const im={'1m':'Min1','5m':'Min5','15m':'Min15','30m':'Min30','1h':'Min60','4h':'Hour4','1d':'Day1','1w':'Week1'}[interval]||'Min1';const end=Date.now(),step=({'Min1':60000,'Min5':300000,'Min15':900000,'Min30':1800000,'Min60':3600000,'Hour4':14400000,'Day1':86400000,'Week1':604800000}[im]||60000);const start=end-step*Math.min(500,Math.max(20,limit));const d=await ourbitContractFetch('/api/v1/contract/kline/'+encodeURIComponent(key)+'?interval='+im+'&start='+start+'&end='+end);const rows=normalizeOurbitKline(d);if(rows.length>=10)return rows;throw new Error('Ourbit Futures returned '+rows.length+' candles')}
async function ticker(sym){
  const key=String(sym).toUpperCase();
  try{return await ourbitTicker(key)}catch(_ourbit){}
  try{
    const d=await lbankFetch('/v2/supplement/ticker/price.do?symbol='+encodeURIComponent(pair(key)));
    const row=Array.isArray(d?.data)?d.data[0]:d?.data; const price=Number(row?.price??row?.latest??row?.lastPrice??row?.last??row?.close);
    if(!Number.isFinite(price))throw new Error('bad latest price');
    let extra={change:0,volume:0,high:price,low:price};
    try{const q=await lbankFetch('/v2/ticker/24hr.do?symbol='+encodeURIComponent(pair(key)));const t=Array.isArray(q?.data)?q.data[0]?.ticker:q?.data?.ticker;if(t)extra={change:Number(t.change)||0,volume:Number(t.vol)||0,high:Number(t.high)||price,low:Number(t.low)||price}}catch(_e){}
    const out={price,...extra,lastUpdate:Date.now(),connected:true,provider:'Ourbit'};liveCache[key]={...(liveCache[key]||{}),...out};setDataStatus(true);return out;
  }catch(e){setDataStatus(false);throw e}
}
async function candles(sym,interval='1h',limit=240){
  const key=String(sym).toUpperCase();
  try{return await ourbitCandles(key,interval,limit)}catch(_ourbit){}
  const n=Math.min(2000,Math.max(20,limit));
  const type=lbankType(interval);
  const step=({minute1:60,minute5:300,minute15:900,minute30:1800,hour1:3600,hour4:14400,day1:86400,week1:604800}[type]||3600);
  // LBank requires `time` for K-line requests. Try now and previous windows so
  // gateways that interpret the timestamp as an end/start reference both work.
  const now=Math.floor(Date.now()/1000);
  const times=[now,now-step*n,now-step*n*2];
  let last;
  for(const t of times){
    try{
      const d=await lbankFetch(`/v2/kline.do?symbol=${encodeURIComponent(pair(key))}&type=${type}&size=${n}&time=${t}`);
      const rows=Array.isArray(d?.data)?d.data:d;
      const out=normalizeLbankKline(rows).sort((a,b)=>+a[0]-+b[0]);
      if(out.length>=Math.min(10,n)){setDataStatus(true);return out;}
      last=new Error('LBank returned '+out.length+' candles');
    }catch(e){last=e}
  }
  setDataStatus(false);throw last||new Error('No LBank candles');
}
async function depth(sym,limit=10){
  const key=String(sym).toUpperCase();
  try{return await ourbitDepth(key,limit)}catch(_ourbit){}
  try{
    const d=await lbankFetch(`/v2/depth.do?symbol=${encodeURIComponent(pair(key))}&size=${Math.min(60,limit)}`);
    const out=normalizeDepth(d);
    if(out.asks.length||out.bids.length){setDataStatus(true);return out}
  }catch(e){}
  throw new Error('LBank depth unavailable')
}
function normalizeDepth(d){
  const raw=d?.data||d;
  const asks=(raw?.asks||raw?.ask||[]).map(x=>Array.isArray(x)?[+x[0],+x[1]]:[+(x.price??x.p),+(x.amount??x.qty??x.volume??x.v)]).filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));
  const bids=(raw?.bids||raw?.bid||[]).map(x=>Array.isArray(x)?[+x[0],+x[1]]:[+(x.price??x.p),+(x.amount??x.qty??x.volume??x.v)]).filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));
  return {asks,bids};
}
async function livePrice(sym){return (await ticker(sym)).price}
function initLivePrice(sym,id){const update=()=>livePrice(sym).then(p=>{const e=document.getElementById(id);if(e)e.textContent=money(p)}).catch(()=>{});update();const off=subscribeLive(sym,d=>{if(d.type==='ticker'){const e=document.getElementById(id);if(e)e.textContent=money(d.price)}});return off}
window.addEventListener('online',()=>{
  try{ if(window.CryptoPulseNative?.fetchTickers) window.CryptoPulseNative.fetchTickers(); }catch(_e){}
});
window.addEventListener('offline',()=>{closeLiveHub();setDataStatus(false);showNetworkAlert(true)});
// CLEAN MARKET ENGINE v1: no browser WebSocket. Native REST is the single source of truth.
// WebSocket will be added only after the REST path is stable on Android.


function formatCompact(n){if(n>=1e9)return (n/1e9).toFixed(2)+'B';if(n>=1e6)return (n/1e6).toFixed(2)+'M';if(n>=1e3)return (n/1e3).toFixed(2)+'K';return Number(n||0).toFixed(2)}
function favorites(){try{return JSON.parse(localStorage.getItem('cp_favorites')||'[]')}catch{return[]}}
function toggleFavorite(sym){let a=favorites();a=a.includes(sym)?a.filter(x=>x!==sym):[...a,sym];localStorage.setItem('cp_favorites',JSON.stringify(a));return a}
function isFavorite(sym){return favorites().includes(sym)}
function saveAlert(sym,target,dir='above'){let a=[];try{a=JSON.parse(localStorage.getItem('cp_alerts')||'[]')}catch{};a.push({id:Date.now(),sym,target:+target,dir,active:true});localStorage.setItem('cp_alerts',JSON.stringify(a));return a}
function checkAlerts(sym,price){let a=[];try{a=JSON.parse(localStorage.getItem('cp_alerts')||'[]')}catch{};let changed=false;a=a.map(x=>{if(x.active&&x.sym===sym&&((x.dir==='above'&&price>=x.target)||(x.dir==='below'&&price<=x.target))){x.active=false;changed=true;toast(`هشدار ${sym}: قیمت به ${money(x.target)} رسید`)}return x});if(changed){localStorage.setItem('cp_alerts',JSON.stringify(a));pushNotification('هشدار قیمت',`هشدار ${sym} فعال شد؛ قیمت به ${money(price)} رسید`,'alert')}}


function profileState(){try{const d=JSON.parse(localStorage.getItem('cp_profile')||'{}');return {name:d.name||'CryptoPulse User',email:d.email||'',ref:d.ref||'',joined:d.joined||new Date().toLocaleDateString('en-US'),referrals:+(d.referrals||0),reward:+(d.reward||0),tier:d.tier||'Starter'}}catch(e){return {name:'CryptoPulse User',email:'',ref:'',joined:new Date().toLocaleDateString('en-US'),referrals:0,reward:0,tier:'Starter'}}}
function saveProfile(p){localStorage.setItem('cp_profile',JSON.stringify(p))}
function makeReferral(){const p=profileState();if(!p.ref)p.ref='CP'+Math.random().toString(36).slice(2,8).toUpperCase();saveProfile(p);return p.ref}
function copyText(t){navigator.clipboard?.writeText(t).then(()=>toast('کپی شد')).catch(()=>toast('کپی خودکار در دسترس نیست','error'))}
function profileStats(){const p=profileState(),s=state();return {trades:(s.history||[]).length+(s.spot||[]).length, pnl:(s.history||[]).reduce((a,x)=>a+(+x.pnl||0),0),referrals:p.referrals,reward:p.reward}}


function portfolioSummary(){
  const s=state(), holdings=s.holdings||{}; let total=0, assets=0;
  Object.entries(holdings).forEach(([sym,v])=>{const qty=+(v||0); if(qty>0){assets++; const cached=liveCache[String(sym).toUpperCase()]; const px=Number(cached?.price)||Number(getCoin(sym)?.[2])||0; total+=qty*px}});
  let futuresMargin=0, futuresPnl=0;
  const p=s.open;
  if(p&&Number.isFinite(+p.margin)){
    futuresMargin=+p.margin||0;
    const cached=liveCache[String(p.symbol||'').toUpperCase()];
    const mark=Number(cached?.price)||0;
    if(mark&&+p.entry){
      const move=p.side==='LONG'?(mark-p.entry)/p.entry:(p.entry-mark)/p.entry;
      futuresPnl=futuresMargin*(+p.leverage||1)*move;
    }
  }
  return {cash:+s.balance||0,assets,total,futuresMargin,futuresPnl,equity:(+s.balance||0)+total+futuresMargin+futuresPnl,history:(s.history||[]).length+(s.spot||[]).length};
}
function renderHomeSnapshot(){
  const el=document.getElementById('homeSnapshot'); if(!el)return;
  const p=portfolioSummary();
  el.innerHTML=`<div class="snapshot-card"><span>Paper Balance</span><b>${money(p.cash)} USDT</b><small>${p.history} معامله ثبت‌شده</small></div><div class="snapshot-card"><span>دارایی‌ها</span><b>${p.assets}</b><small>دارایی دارای موجودی</small></div><div class="snapshot-card"><span>ارزش تقریبی</span><b>${money(p.cash+p.total)} USDT</b><small>بر پایه قیمت‌های نمایشی</small></div>`;
}

function homeSkeletonRows(n=5){
  return Array.from({length:n},()=>`<div class="home-skeleton-row"><div><span class="skeleton-circle"></span><span class="skeleton-line skeleton-name"></span></div><span><span class="skeleton-line skeleton-price"></span><span class="skeleton-line skeleton-change"></span></span></div>`).join('');
}
function homePriceText(v){
  const n=Number(v);
  if(!Number.isFinite(n)||n<=0)return '—';
  if(n>=1000)return n.toLocaleString('en-US',{minimumFractionDigits:0,maximumFractionDigits:2});
  if(n>=1)return n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:4});
  if(n>=0.01)return n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:6});
  return n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:8});
}
function homeVolumeText(v){
  const n=Number(v);
  if(!Number.isFinite(n)||n<=0)return '—';
  if(n>=1e9)return (n/1e9).toFixed(n>=1e10?0:2).replace(/\.00$/,'')+'B';
  if(n>=1e6)return (n/1e6).toFixed(n>=1e7?0:2).replace(/\.00$/,'')+'M';
  if(n>=1e3)return (n/1e3).toFixed(n>=1e4?0:2).replace(/\.00$/,'')+'K';
  return n.toLocaleString('en-US',{maximumFractionDigits:0});
}
function syncHomeLiveRow(key,raw){
  const sym=cpCanonicalSymbol(key); if(!sym||!raw)return;
  const row=document.querySelector('#homeMarkets .home-coin-row[data-home-symbol="'+CSS.escape(sym)+'"]');
  if(!row)return;
  const price=Number(raw.price),change=Number(raw.change||0),volume=Number(raw.volume||0);
  const priceEl=row.querySelector('.home-price-cell b');
  const usdEl=row.querySelector('.home-price-cell span');
  const chEl=row.querySelector('.home-change');
  const volEl=row.querySelector('.home-coin-info small');
  if(priceEl)priceEl.textContent=homePriceText(price);
  if(usdEl)usdEl.textContent='$'+homePriceText(price);
  if(chEl){chEl.textContent=(change>=0?'+':'')+change.toFixed(2)+'%';chEl.className='home-change '+(change>=0?'up':'down')}
  if(volEl)volEl.textContent=homeVolumeText(volume)+' · حجم ۲۴ساعته';
}

function homeRow(c){
  const sym=cpCanonicalSymbol(c[0]), name=cpCanonicalName(sym,c[1]), raw=liveCache[sym]||liveCache[cpCanonicalSymbol(c[0])]||{};
  const price=Number(raw.price||c[2]);
  const change=Number.isFinite(Number(raw.change))?Number(raw.change):parseFloat(c[3])||0;
  const volume=Number.isFinite(Number(raw.volume))?Number(raw.volume):Number(c[4])||0;
  const hasLive=Number.isFinite(Number(raw.price)) && (!raw.lastUpdate || Date.now()-Number(raw.lastUpdate)<120000);
  const priceText=hasLive?homePriceText(price):'—';
  const dollarText=hasLive?'$'+homePriceText(price):'—';
  const changeText=hasLive?((change>=0?'+':'')+change.toFixed(2)+'%'):'—';
  const changeClass=change>=0?'up':'down';
  return `<div class="home-coin-row" data-home-symbol="${sym}">
    <div class="home-change ${changeClass}">${changeText}</div>
    <div class="home-price-cell"><b>${priceText}</b><span>${dollarText}</span></div>
    <a href="asset.html?symbol=${encodeURIComponent(sym)}" class="home-coin-main">
      <div class="home-coin-info">${coinIcon(sym,name)}<div><b>${sym}</b><span>${name}</span><small>${homeVolumeText(volume)} · حجم ۲۴ساعته</small></div></div>
    </a>
  </div>`;
}
function homeSort(list,filter){
  const x=[...list];
  if(filter==='fav')return x.filter(c=>isFavorite(c[0]));
  if(filter==='up')return x.sort((a,b)=>(Number(liveCache[b[0]]?.change ?? (parseFloat(b[3])||0)))-(Number(liveCache[a[0]]?.change ?? (parseFloat(a[3])||0))));
  if(filter==='down')return x.sort((a,b)=>(Number(liveCache[a[0]]?.change ?? (parseFloat(a[3])||0)))-(Number(liveCache[b[0]]?.change ?? (parseFloat(b[3])||0))));
  if(filter==='vol')return x.sort((a,b)=>(Number(liveCache[b[0]]?.volume ?? (parseFloat(b[4])||0)))-(Number(liveCache[a[0]]?.volume ?? (parseFloat(a[4])||0))));
  if(filter==='new'){
    // REBUILD73: Newest must never depend on the current market/volume order.
    // The bundled LBank spot catalogue is maintained in listing-oriented order;
    // use that stable catalogue rank first, and only use the seen-pairs delta as
    // a secondary signal. This prevents BTC/ETH from appearing as "new" merely
    // because they are major/high-volume assets.
    const rank=window.__cpListingRank instanceof Map ? window.__cpListingRank : null;
    const fresh=(()=>{try{return JSON.parse(localStorage.getItem('cp_new_pairs')||'[]')}catch{return[]}})();
    const freshSet=new Set(fresh.map(v=>cpCanonicalSymbol(v)));
    return x.sort((a,b)=>{
      const ak=cpCanonicalSymbol(a[0]), bk=cpCanonicalSymbol(b[0]);
      const af=freshSet.has(ak)?1:0, bf=freshSet.has(bk)?1:0;
      if(af!==bf)return bf-af;
      const ar=rank&&rank.has(ak)?rank.get(ak):999999;
      const br=rank&&rank.has(bk)?rank.get(bk):999999;
      if(ar!==br)return ar-br;
      return String(ak).localeCompare(String(bk));
    });
  }
  return x;
}
let homeMarketFilter='all',homeVisibleCount=40,homeMarketQuery='';
function renderHomeMarkets(){
  const box=document.getElementById('homeMarkets'); if(!box)return;
  const term=homeMarketQuery.trim().toUpperCase();
  let list=coins.map(c=>[cpCanonicalSymbol(c[0]),cpCanonicalName(c[0],c[1]),c[2],c[3],c[4]]).filter(c=>!term||c[0].includes(term)||String(c[1]).toUpperCase().includes(term));
  list=homeSort(list,homeMarketFilter);
  // Favorites means exactly the coins the user starred. Never silently
  // replace an empty Favorites tab with volume-ranked coins.
  // TV82: "همه" is the only unlimited tab. Every other market tab is capped at 40 rows.
  // Search respects the same rule: use "همه" when the user wants the complete matching universe.
  const shown=homeMarketFilter==='all' ? list : list.slice(0,40);
  box.innerHTML=shown.length?shown.map(homeRow).join(''):'<div class="home-empty">رمز ارزی پیدا نشد.</div>';
  // TV75: every currently rendered Home row is immediately promoted to the
  // shared live feed. Do not depend on the original universe ordering; lower
  // rows must receive the same live treatment as the first rows.
  if(shown.length){
    const visibleSymbols=shown.map(c=>String(c[0]||'').toUpperCase()).filter(Boolean);
    setTimeout(()=>{try{ensureLiveSubscriptions(visibleSymbols);requestMissingVisiblePrices(true)}catch(_e){}},0);
  }
}
function bindHomeMarketEvents(){
  // The WebView keeps one JS context while pages are swapped. Remove the old
  // Home window listener before binding the new DOM so returning to Home does
  // not accumulate scroll handlers.
  if(window.__cpHomeScrollHandler){
    try{window.removeEventListener('scroll',window.__cpHomeScrollHandler)}catch(_e){}
    window.__cpHomeScrollHandler=null;
  }
  const q=document.getElementById('homeMarketSearch');
  if(q)q.addEventListener('input',()=>{homeMarketQuery=q.value;homeVisibleCount=Number.MAX_SAFE_INTEGER;renderHomeMarkets();setTimeout(()=>{try{requestMissingVisiblePrices(true)}catch(_e){}},20)});
  document.querySelectorAll('#homeFilters [data-home-filter]').forEach(b=>b.addEventListener('click',()=>{
    document.querySelectorAll('#homeFilters [data-home-filter]').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');homeMarketFilter=b.dataset.homeFilter;homeVisibleCount=Number.MAX_SAFE_INTEGER;renderHomeMarkets();
    setTimeout(()=>{try{requestMissingVisiblePrices(true)}catch(_e){}},20);
  }));
  const box=document.getElementById('homeMarkets');
  if(box)box.addEventListener('click',e=>{
    const star=e.target.closest('[data-home-fav]'); if(!star)return;
    e.preventDefault();e.stopPropagation();toggleFavorite(star.dataset.homeFav);renderHomeMarkets();
  });
  let scrollRetryTimer=0;
  const onHomeScroll=()=>{
    // TV81: all markets are already on Home; scrolling only refreshes visible prices.
    clearTimeout(scrollRetryTimer);scrollRetryTimer=setTimeout(()=>{try{requestMissingVisiblePrices(true)}catch(_e){}},120);
  };
  window.__cpHomeScrollHandler=onHomeScroll;
  window.addEventListener('scroll',onHomeScroll,{passive:true});
}
function homeLiveReady(){
  if(liveHub.lastMessage && Date.now()-liveHub.lastMessage<30000)return true;
  const now=Date.now();
  return Object.values(liveCache).some(v=>Number.isFinite(Number(v?.price))&&v?.lastUpdate&&now-Number(v.lastUpdate)<120000);
}
function renderHomeBalance(){
  const total=document.getElementById('homeTotal'),pnl=document.getElementById('homePnl');
  if(!total||!pnl)return;
  if(!homeLiveReady()){
    total.innerHTML='<span class="skeleton-line skeleton-balance"></span>';pnl.className='skeleton-line skeleton-pnl';pnl.textContent='';return;
  }
  const hs=portfolioSummary();
  total.textContent=money(hs.cash+hs.total)+' USDT';
  pnl.className='up';pnl.textContent='LIVE';
}
// TV34: Home never invents a market universe. The authoritative list comes from
// the native LBank ALL ticker stream. If that feed is unavailable, keep the
// current list/cache instead of injecting stale symbols.
function mergeFallbackUniverse(){ return 0; }
let nativeMarketRequestAt=0;
function applyMarketTickerPayload(payload){
  let q=null;
  try{q=typeof payload==='string'?JSON.parse(payload):payload}catch(_e){q=null}
  let rows=Array.isArray(q?.data)?q.data:[];
  if(!rows.length && q?.data && typeof q.data==='object'){
    rows=Object.entries(q.data).map(([symbol,v])=>({symbol,ticker:v}));
  }
  if(!rows.length && Array.isArray(q)) rows=q;
  let updated=0;
  for(const r of rows){
    const symRaw=String(r?.symbol||r?.pair||r?.instrumentID||r?.instrumentId||'');
    const key=cpCanonicalSymbol(symRaw);
    if(!key)continue;
    const t=r?.ticker||r?.tick||r?.data?.ticker||r;
    const price=Number(t?.latest ?? t?.lastPrice ?? t?.last ?? t?.price ?? t?.close ?? t?.closePrice),
          change=Number(t?.change ?? t?.changeRate ?? t?.changePercent ?? t?.priceChangePercent ?? t?.increase ?? t?.riseRate),
          vol=Number(t?.vol ?? t?.volume ?? t?.quoteVolume ?? t?.amount ?? t?.turnover);
    if(!Number.isFinite(price))continue;
    liveCache[key]={...(liveCache[key]||{}),price,change:Number.isFinite(change)?change:(liveCache[key]?.change||0),volume:Number.isFinite(vol)?vol:(liveCache[key]?.volume||0),connected:true,lastUpdate:Date.now(),provider:'LBank Native'};persistSharedLiveCache();
    const c=coins.find(x=>cpCanonicalSymbol(x[0])===key);
    if(c){c[2]=String(price);if(Number.isFinite(change))c[3]=(change>=0?'+':'')+change.toFixed(2)+'%';if(Number.isFinite(vol))c[4]=String(vol)}
    updated++;
  }
  if(updated){liveHub.lastMessage=Date.now();setDataStatus(true);window.dispatchEvent(new Event('cp-market-prices-ready'));renderHomeMarkets?.();renderHomeBalance?.();requestVisiblePricesSoon();}
  return updated;
}
function applyNativeMarketCache(payload){
  let q=null;
  try{q=typeof payload==='string'?JSON.parse(payload):payload}catch(_e){q=null}
  const rows=Array.isArray(q)?q:[];
  let updated=0;
  const now=Date.now();
  for(const r of rows){
    const key=cpCanonicalSymbol(r?.symbol||'');
    const price=Number(r?.price);
    if(!key||!Number.isFinite(price)||price<=0)continue;
    const old=liveCache[key]||{};
    const ts=Number(r?.lastUpdate)||now;
    const change=Number(r?.change),vol=Number(r?.volume);
    liveCache[key]={...old,price,change:Number.isFinite(change)?change:(old.change||0),volume:Number.isFinite(vol)?vol:(old.volume||0),connected:true,lastUpdate:ts,provider:String(r?.provider||'LBank Native Background')};persistSharedLiveCache();
    const c=coins.find(x=>cpCanonicalSymbol(x[0])===key);
    if(c){c[2]=String(price);if(Number.isFinite(change))c[3]=(change>=0?'+':'')+change.toFixed(2)+'%';if(Number.isFinite(vol))c[4]=String(vol)}
    updated++;
  }
  // TV38: materialize the shared native cache directly into the shared coins model.
  try{
    const existing=new Set(coins.map(c=>String(c[0]).toUpperCase()));
    const nameMap={BTC:'Bitcoin',ETH:'Ethereum',SOL:'Solana',BNB:'BNB',XRP:'XRP',ADA:'Cardano',DOGE:'Dogecoin',AVAX:'Avalanche',LINK:'Chainlink',DOT:'Polkadot',TRX:'TRON',POL:'Polygon',MATIC:'Polygon',S:'Sonic',FTM:'Fantom',EGLD:'MultiversX',GRT:'The Graph',MKR:'Maker',RUNE:'THORChain',INJ:'Injective'};
    for(const r of rows){
      const k=String(r?.symbol||'').toUpperCase();
      if(!k||existing.has(k)||!Number.isFinite(Number(r?.price)))continue;
      coins.push([k,nameMap[k]||k,String(r.price),Number.isFinite(Number(r.change))?(Number(r.change)>=0?'+':'')+Number(r.change).toFixed(2)+'%':'0.00%',Number.isFinite(Number(r.volume))?String(r.volume):'0']);
      existing.add(k);
    }
  }catch(_e){}
  if(updated){liveHub.lastMessage=now;setDataStatus(true);renderHomeMarkets?.();renderHomeBalance?.();window.dispatchEvent(new Event('cp-market-cache-restored'));window.dispatchEvent(new Event('cp-market-prices-ready'));}
  return updated;
}
window.cpNativeRestoreMarketCache=applyNativeMarketCache;

// MOBILE FIX 1172: Android sends exact missing-symbol ticker rows through
// fetchMissingLBankTickers().  Stage 1171 had the native sender but no JS
// receiver, so lower Home rows stayed on "—" even when Android had a price.
async function cpBrowserBulkLBankHomePrices(){
  try{
    const r=await fetch('https://api.lbank.info/v2/ticker/24hr.do?symbol=all',{cache:'no-store'});
    if(!r.ok)return false;
    const q=await r.json();
    const rows=Array.isArray(q?.data)?q.data:[];
    let n=0;
    for(const row of rows){
      const key=String(row?.symbol||'').toUpperCase().replace(/_USDT$/,'');
      const t=row?.ticker||{}; const price=Number(t.latest??t.price??row?.price);
      if(!key||!(price>0))continue;
      const v={price,change:Number(t.change)||0,volume:Number(t.vol)||0,high:Number(t.high)||price,low:Number(t.low)||price,lastUpdate:Date.now(),connected:true,provider:'Ourbit'};
      liveCache[key]={...(liveCache[key]||{}),...v}; syncHomeLiveRow(key,v); n++;
    }
    if(n)persistSharedLiveCache();
    return n>0;
  }catch(_e){return false}
}
window.cpBrowserBulkLBankHomePrices=cpBrowserBulkLBankHomePrices;
window.cpNativeOurbitTickers=function(requestId,payload){
  // Resolve a pending single-request promise first. Home bulk requests use
  // ids such as home/universe/restore and continue through the parser below.
  try{const waiter=window.__cpOurbitWaiters?.[String(requestId)];if(waiter){waiter(payload);return 0;}}catch(_e){}
  try{
    const raw=typeof payload==='string'?JSON.parse(payload||'[]'):payload;
    const rows=[];
    const add=v=>{if(Array.isArray(v)){v.forEach(add);return}if(v&&typeof v==='object')rows.push(v)};
    const collect=v=>{
      if(Array.isArray(v)){v.forEach(add);return true}
      if(!v||typeof v!=='object')return false;
      let found=false;
      for(const k of ['data','result','rows','list','tickers','symbols','items','records']){const x=v[k];if(Array.isArray(x)){x.forEach(add);found=true}else if(x&&typeof x==='object'){if(Array.isArray(x.data)){x.data.forEach(add);found=true}else if(Array.isArray(x.list)){x.list.forEach(add);found=true}else if(Array.isArray(x.tickers)){x.tickers.forEach(add);found=true}}}
      if(!found){
        // Some first-party Ourbit responses are maps keyed by symbol.
        for(const [k,vv] of Object.entries(v)){
          if(vv&&typeof vv==='object'&&!Array.isArray(vv)){
            const hinted=String(vv.symbol??vv.pair??vv.market??vv.currency??k).toUpperCase();
            if(/(?:USDT|_USDT|\/USDT)$/.test(hinted)||vv.lastPrice!=null||vv.price!=null||vv.last!=null||vv.latest!=null){add({symbol:k,...vv});found=true}
          }
        }
      }
      return found
    };
    collect(raw);
    const universe=[];const seen=new Set();const now=Date.now();
    const major=['BTC','ETH','BNB','SOL','XRP','DOGE','ADA','TRX','AVAX','LINK','DOT','LTC','BCH','UNI','NEAR','APT','SUI','TON','SHIB','PEPE','XLM','ATOM','ETC','FIL','HBAR','ICP','ARB','OP','AAVE','ALGO','VET','POL','MATIC','MKR','INJ','TIA','SEI','RUNE','JUP','WIF','BONK'];
    const rank=new Map(major.map((x,i)=>[x,i]));
    for(const x of rows){
      const rawSym=String(x?.symbol??x?.pair??x?.market??x?.currency??x?.baseCurrency??x?.symbolName??x?.symbolDisplay??x?.s??'').toUpperCase().trim();
      const key=cpCanonicalSymbol(rawSym);
      if(!key||seen.has(key))continue;
      const nested=x?.ticker&&typeof x.ticker==='object'?x.ticker:(x?.data&&typeof x.data==='object'&&!Array.isArray(x.data)?x.data:x);
      const price=Number(nested?.lastPrice??nested?.last??nested?.latest??nested?.price??nested?.close??nested?.closePrice??nested?.c??x?.lastPrice??x?.price);
      if(!Number.isFinite(price)||price<=0)continue;
      const change=Number(nested?.priceChangePercent??nested?.changePercent??nested?.changeRate??nested?.change??nested?.increase??nested?.riseRate??x?.priceChangePercent??0)||0;
      const volume=Number(nested?.quoteVolume??nested?.volume??nested?.vol??nested?.amount??nested?.turnover??x?.quoteVolume??0)||0;
      const name=cpCanonicalName(key,window.__cpBundledNames?.[key]||x?.name||key);
      seen.add(key);liveCache[key]={...(liveCache[key]||{}),price,change,volume,lastUpdate:now,connected:true,provider:'Ourbit Native App'};
      universe.push([key,name,String(price),(change>=0?'+':'')+change.toFixed(2)+'%',String(volume)]);
    }
    universe.sort((a,b)=>{const ar=rank.has(a[0])?rank.get(a[0]):9999,br=rank.has(b[0])?rank.get(b[0]):9999;if(ar!==br)return ar-br;if(ar===9999){const av=Number(a[4])||0,bv=Number(b[4])||0;if(av!==bv)return bv-av}return String(a[0]).localeCompare(String(b[0]))});
    if(universe.length){
      coins=universe;window.__cpOurbitUniverseAt=now;window.__cpOurbitTransportError='';liveHub.lastMessage=now;persistSharedLiveCache();setDataStatus(true);
      window.dispatchEvent(new Event('cp-market-universe-ready'));window.dispatchEvent(new Event('cp-market-prices-ready'));
      if(document.getElementById('homeMarkets')){renderHomeMarkets();renderHomeBalance()}
    }else{
      setDataStatus(false);
      try{window.__cpMarketTransportError='Ourbit market response contained no usable ticker rows';window.__cpOurbitRawShape=raw&&typeof raw==='object'?Object.keys(raw).slice(0,30):typeof raw}catch(_e){}
    }
    return universe.length;
  }catch(e){try{window.__cpMarketTransportError='Ourbit ticker parse: '+String(e?.message||e)}catch(_e){}return 0}
};

window.cpNativeMissingLBankMarketRow=function(payload){
  try{
    const d=typeof payload==='string'?JSON.parse(payload||'{}'):(payload||{});
    const key=cpCanonicalSymbol(d.symbol||d.pair||'');
    const price=Number(d.price??d.latest??d.lastPrice??d.last??d.close);
    if(!key||!Number.isFinite(price)||price<=0)return false;
    const change=Number(d.change??d.changeRate??d.changePercent??0);
    const volume=Number(d.volume??d.vol??d.quoteVolume??d.amount??d.turnover??0);
    const now=Date.now();
    liveCache[key]={
      ...(liveCache[key]||{}),
      price,
      change:Number.isFinite(change)?change:(liveCache[key]?.change||0),
      volume:Number.isFinite(volume)?volume:(liveCache[key]?.volume||0),
      connected:true,
      lastUpdate:now,
      provider:'LBank Native Missing'
    };
    const c=coins.find(x=>cpCanonicalSymbol(x?.[0])===key);
    if(c){
      c[2]=String(price);
      if(Number.isFinite(change))c[3]=(change>=0?'+':'')+change.toFixed(2)+'%';
      if(Number.isFinite(volume))c[4]=String(volume);
    }
    try{persistSharedLiveCache()}catch(_e){}
    try{syncHomeLiveRow(key,liveCache[key])}catch(_e){}
    if(document.getElementById('homeMarkets')){ try{syncHomeLiveRow(key,liveCache[key])}catch(_e){} }
    setDataStatus(true);
    window.dispatchEvent(new Event('cp-market-prices-ready'));
    return true;
  }catch(_e){return false}
};

window.cpRestoreSharedLiveCache=restoreSharedLiveCache;
window.cpGetSharedLivePrice=(sym)=>{const k=String(sym||'').toUpperCase();const v=liveCache[k];return v&&Number.isFinite(Number(v.price))?v:null};
window.cpGetSharedLiveDepth=(sym)=>{const k=String(sym||'').toUpperCase();const v=liveCache[k]?.depth;return v&&(Array.isArray(v.asks)||Array.isArray(v.bids))?v:null};

window.cpNativeMarketData=applyMarketTickerPayload;

// Also accept a direct market-data callback from future/native builds.
window.cpNativeOurbitMarket=function(requestId,payload){return window.cpNativeOurbitTickers(requestId,payload)};

// TV32: Native Ourbit pair universe is the single source of truth on Android.
// The native layer sends {pairs:["btc_usdt",...], tickers:[...]} here.  Older
// versions had the Java sender but no JS receiver, so the real universe never
// reached Home and the hardcoded fallback remained visible.
window.cpNativeMarketUniverse=function(payload){
  let q=null;
  try{q=typeof payload==='string'?JSON.parse(payload):payload}catch(_e){q=null}
  if(!q)return 0;
  let pairs=Array.isArray(q.pairs)?q.pairs.map(x=>String(x||'')).filter(Boolean):[];
  // TV78: the current LBank snapshot is authoritative. Never merge an old
  // persisted universe back into the live list: that was the root cause of
  // stale symbols (AVO/GME/etc.) remaining visible with no current price.
  // Old cache may still be used for a fresh price, but old symbols must not
  // resurrect themselves into the market universe.
  try{
    const version='tv88';
    if(localStorage.getItem('cp_universe_schema')!==version){
      localStorage.removeItem('cp_lbank_usdt_universe');
      localStorage.setItem('cp_universe_schema',version);
    }
  }catch(_e){}
  const tickers=Array.isArray(q.tickers)?q.tickers:[];
  // Merge every Ourbit ticker symbol into the universe as the official source.
  // This also handles currencyPairs responses whose JSON shape changed.
  try{for(const r of tickers){const s=String(r?.symbol||'');if(cpCanonicalSymbol(s))pairs.push(cpCanonicalSymbol(s)+'_usdt')}pairs=[...new Set(pairs)]}catch(_e){}
  if(!pairs.length && tickers.length){
    pairs=tickers.map(r=>{const k=cpCanonicalSymbol(r?.symbol||'');return k?k+'_usdt':''}).filter(Boolean);
  }
  // If native cache already contains LBank rows, use them as an additional
  // source of symbols. This makes the list independent from callback timing.
  try{
    for(const r of (Array.isArray(q.cache)?q.cache:[])){const k=cpCanonicalSymbol(r?.symbol||'');if(k)pairs.push(k+'_usdt')}
    pairs=[...new Set(pairs)];
  }catch(_e){}
  if(!pairs.length){
    try{ if(Array.isArray(coins)&&coins.length) return coins.length; }catch(_e){}
    return 0;
  }
  const tickerMap=new Map();
  // TV80: merge the native cache from the same atomic snapshot. The pair list
  // and ticker/cache can arrive in different callbacks; never throw away a
  // valid cached price just because its ticker row was not in this payload.
  const nativeCacheMap=new Map();
  try{
    for(const r of (Array.isArray(q.cache)?q.cache:[])){
      const k=cpCanonicalSymbol(r?.symbol||'');
      const price=Number(r?.price);
      if(k&&Number.isFinite(price)&&price>0) nativeCacheMap.set(k,{price,change:Number(r?.change),volume:Number(r?.volume),lastUpdate:Number(r?.lastUpdate)||Date.now()});
    }
  }catch(_e){}
  const bundledNames=new Map();
  try{for(const r of (Array.isArray(q.catalog)?q.catalog:[])){const ss=String(r?.symbol||'').toUpperCase();if(ss)bundledNames.set(ss.replace(/_USDT$/,''),String(r?.name||ss))}}catch(_e){}
  for(const r of tickers){
    const k=cpCanonicalSymbol(r?.symbol||'');
    if(k)tickerMap.set(k+'_USDT',r);
  }
  const oldMap=new Map(coins.map(c=>[String(c[0]).toUpperCase(),c]));
  const names={
    BTC:'Bitcoin',ETH:'Ethereum',SOL:'Solana',BNB:'BNB',XRP:'XRP',ADA:'Cardano',DOGE:'Dogecoin',
    AVAX:'Avalanche',LINK:'Chainlink',DOT:'Polkadot',TRX:'TRON',POL:'Polygon',LTC:'Litecoin',
    BCH:'Bitcoin Cash',UNI:'Uniswap',ATOM:'Cosmos',ETC:'Ethereum Classic',XLM:'Stellar',FIL:'Filecoin',
    APT:'Aptos',ARB:'Arbitrum',OP:'Optimism',NEAR:'NEAR Protocol',ICP:'Internet Computer',AAVE:'Aave',
    ALGO:'Algorand',VET:'VeChain',HBAR:'Hedera',SAND:'The Sandbox',MANA:'Decentraland',EGLD:'MultiversX',
    S:'Sonic',GRT:'The Graph',MKR:'Maker',RUNE:'THORChain',INJ:'Injective',SUI:'Sui',SEI:'Sei',TIA:'Celestia',
    PEPE:'Pepe',SHIB:'Shiba Inu',TON:'Toncoin',KAS:'Kaspa',TAO:'Bittensor',RENDER:'Render',FET:'Artificial Superintelligence Alliance',
    WLD:'Worldcoin',ENA:'Ethena',ONDO:'Ondo',JTO:'Jito',STRK:'Starknet',ZK:'ZKsync',NOT:'Notcoin',KAVA:'Kava',
    MINA:'Mina',ROSE:'Oasis',CELO:'Celo',IOTA:'IOTA',FLOW:'Flow',THETA:'Theta Network',CAKE:'PancakeSwap',
    GALA:'Gala',APE:'ApeCoin',CHZ:'Chiliz',ENJ:'Enjin Coin',BAT:'Basic Attention Token',ZIL:'Zilliqa',ONE:'Harmony',
    HOT:'Holo',ANKR:'Ankr',SKL:'SKALE',YFI:'yearn.finance',SFP:'SafePal',TWT:'Trust Wallet Token',MASK:'Mask Network',
    GMT:'STEPN',LUNC:'Terra Classic',USTC:'TerraClassicUSD',KSM:'Kusama',WOO:'WOO Network',API3:'API3',LPT:'Livepeer',
    AR:'Arweave',CKB:'Nervos Network',ASTR:'Astar',DYM:'Dymension',BLUR:'Blur',MANTA:'Manta Network',ALT:'AltLayer',
    ORDI:'ORDI',SATS:'SATS',MEME:'Memecoin',BOME:'BOOK OF MEME'
  };
  const pairSymbols=new Set(pairs.map(x=>cpCanonicalSymbol(x)).filter(Boolean));
  // LBank migrations such as MATIC->POL and FTM->S can leave old catalogue
  // entries behind. Prefer the currently quoted LBank symbol so the UI does not
  // show a duplicate dead row with a dash beside the live replacement.
  const legacyReplacement={MATIC:'POL',FTM:'S'};
  const next=[];
  const seen=new Set();
  for(const raw of pairs){
    const sym=cpCanonicalSymbol(raw);
    if(!sym)continue;
    if(legacyReplacement[sym] && pairSymbols.has(legacyReplacement[sym]))continue;
    const pair=sym+'_USDT';
    if(!sym||seen.has(sym))continue;
    seen.add(sym);
    const r=tickerMap.get(pair);
    const t=r?.ticker||r||{};
    const cached=nativeCacheMap.get(sym);
    const priceRaw=Number(t.latest ?? t.close ?? t.lastPrice ?? t.price);
    const changeRaw=Number(t.change ?? t.changeRate ?? t.priceChangePercent ?? t.increase);
    const volRaw=Number(t.vol ?? t.volume ?? t.quoteVolume ?? t.amount);
    const price=Number.isFinite(priceRaw)&&priceRaw>0?priceRaw:Number(cached?.price);
    const change=Number.isFinite(changeRaw)?changeRaw:Number(cached?.change);
    const vol=Number.isFinite(volRaw)?volRaw:Number(cached?.volume);
    const old=oldMap.get(sym);
    if(Number.isFinite(price)&&price>0){
      liveCache[sym]={...(liveCache[sym]||{}),price,change:Number.isFinite(change)?change:0,volume:Number.isFinite(vol)?vol:0,connected:true,lastUpdate:Date.now(),provider:'Ourbit Native Universe'};
    }
    next.push([
      sym,
      names[sym]||cpCanonicalName(sym,old?.[1])||sym,
      Number.isFinite(price)&&price>0?String(price):(old?.[2]||'—'),
      Number.isFinite(change)?((change>=0?'+':'')+change.toFixed(2)+'%'):(old?.[3]||'0.00%'),
      Number.isFinite(vol)?String(vol):(old?.[4]||'0')
    ]);
  }
  if(!next.length)return 0;
  try{window.__cpUniverseStats={pairs:pairs.length,tickers:tickers.length,display:next.length,cache:Array.isArray(q.cache)?q.cache.length:0,source:String(q.source||'Ourbit'),at:Date.now()};localStorage.setItem('cp_universe_stats',JSON.stringify(window.__cpUniverseStats));console.log('CryptoPulse Universe',window.__cpUniverseStats)}catch(_e){}
  const canonMap=new Map();
  for(const c of next){const k=cpCanonicalSymbol(c[0]);if(!k)continue;if(!canonMap.has(k))canonMap.set(k,[k,cpCanonicalName(k,c[1]),c[2],c[3],c[4]])}
  // TV84: deterministic Home ordering. The exchange universe remains the
  // source of truth, but its raw/catalog order must never leak into the UI.
  // Major spot assets come first; every remaining live asset is then ordered
  // by 24h quote volume (with symbol as a stable tie-breaker).
  const majorOrder=['BTC','ETH','BNB','SOL','XRP','DOGE','ADA','TRX','AVAX','LINK','DOT','LTC','BCH','UNI','NEAR','APT','SUI','TON','SHIB','PEPE','XLM','ATOM','ETC','FIL','HBAR','ICP','ARB','OP','AAVE','ALGO','VET','MATIC','POL','MKR','INJ','TIA','SEI','RUNE','JUP','WIF','BONK'];
  const majorRank=new Map(majorOrder.map((k,i)=>[k,i]));
  const volumeOf=(c)=>{const k=cpCanonicalSymbol(c[0]);const live=liveCache[k];const v=Number(live?.volume);if(Number.isFinite(v)&&v>0)return v;const raw=Number(c[4]);return Number.isFinite(raw)&&raw>0?raw:0};
  coins=[...canonMap.values()].sort((a,b)=>{
    const ar=majorRank.has(a[0])?majorRank.get(a[0]):9999;
    const br=majorRank.has(b[0])?majorRank.get(b[0]):9999;
    if(ar!==br)return ar-br;
    if(ar===9999){const av=volumeOf(a),bv=volumeOf(b);if(av!==bv)return bv-av;}
    return String(a[0]).localeCompare(String(b[0]));
  });
  try{localStorage.setItem('cp_ourbit_usdt_universe',JSON.stringify(pairs.map(x=>cpCanonicalSymbol(x))))}catch(_e){}
  liveHub.lastMessage=Date.now();
  setDataStatus(true);
  window.dispatchEvent(new Event('cp-market-universe-ready'));
  renderHomeMarkets?.();
  renderHomeBalance?.();
  return next.length;
};

const CP_BUNDLED_LBANK_SPOT_CATALOG=[{"symbol":"gnon_usdt","name":"numogram"},{"symbol":"ava_usdt","name":"AVA (Wormhole)"},{"symbol":"sbr_usdt","name":"Strategic Bitcoin Reserve"},{"symbol":"purpe_usdt","name":"Purple Pepe"},{"symbol":"joe1_usdt","name":"Joecoin"},{"symbol":"alch_usdt","name":"Alchemist AI"},{"symbol":"brownie_usdt","name":"CZ&quot;s Dog"},{"symbol":"nftpunk_usdt","name":"NFTPUNK2.0"},{"symbol":"shiro_usdt","name":"Shiro Neko"},{"symbol":"yne_usdt","name":"yesnoerror"},{"symbol":"xiasi_usdt","name":"Xiasi Inu"},{"symbol":"avo_usdt","name":"avo"},{"symbol":"gme_usdt","name":"GameStop"},{"symbol":"yapper_usdt","name":"Yapper"},{"symbol":"pnut_usdt","name":"Peanut the Squirrel"},{"symbol":"moolah_usdt","name":"Moolah"},{"symbol":"foxy_usdt","name":"Foxy"},{"symbol":"turbo_usdt","name":"Turbo"},{"symbol":"broccoli2_usdt","name":"Broccoli"},{"symbol":"lofi_usdt","name":"LOFI price"},{"symbol":"kabosu_usdt","name":"kabosu"},{"symbol":"candle_usdt","name":"Candle TV"},{"symbol":"useless_usdt","name":"Useless Coin"},{"symbol":"trumpsol_usdt","name":"OFFICIAL TRUMP"},{"symbol":"elon_usdt","name":"Dogelon"},{"symbol":"mooncoin_usdt","name":"Mooncoin"},{"symbol":"neiro_usdt","name":"Neiro"},{"symbol":"memefi_usdt","name":"MEMEFI"},{"symbol":"hammy_usdt","name":"Sad Hamster"},{"symbol":"bully_usdt","name":"Dolos The Bully"},{"symbol":"wizard_usdt","name":"Wizard Gang"},{"symbol":"gpu_usdt","name":"NodeAI"},{"symbol":"ly_usdt","name":"Lilly Finance"},{"symbol":"retardio_usdt","name":"RETARDIO"},{"symbol":"siren_usdt","name":"SIREN"},{"symbol":"magic_usdt","name":"MAGIC"},{"symbol":"spx_usdt","name":"SPX6900"},{"symbol":"fartcoin_usdt","name":"FartCoin"},{"symbol":"duck_usdt","name":"DuckChain"},{"symbol":"ca_usdt","name":"Caila"},{"symbol":"vision_usdt","name":"OpenVision"},{"symbol":"shoggoth_usdt","name":"Shoggoth"},{"symbol":"froc_usdt","name":"Based Froc"},{"symbol":"dbx_usdt","name":"DBX"},{"symbol":"monkephone_usdt","name":"Monke Phone"},{"symbol":"captainbnb_usdt","name":"CaptainBNB"},{"symbol":"caw_usdt","name":"A Hunters Dream"},{"symbol":"italianrot_usdt","name":"Italian Brainrot"},{"symbol":"rasmr_usdt","name":"rasmr"},{"symbol":"nuit_usdt","name":"nuit"},{"symbol":"bitcoin_usdt","name":"HarryPotterObamaSonic10Inu"},{"symbol":"ktz_usdt","name":"KILLTHEZERO"},{"symbol":"1_usdt","name":"just buy $1 worth of this coin"},{"symbol":"moonkin_usdt","name":"JuliaOS"},{"symbol":"rato_usdt","name":"Rato The Rat"},{"symbol":"cv_usdt","name":"Crypto Villains"},{"symbol":"zerebro_usdt","name":"Zerebro"},{"symbol":"vvaifu_usdt","name":"Dasha"},{"symbol":"miyazaki_usdt","name":"Miyazaki Inu"},{"symbol":"buddy_usdt","name":"CreatorBuddy"},{"symbol":"prompt1_usdt","name":"promptbidder"},{"symbol":"rizzmas_usdt","name":"Rizzmas"},{"symbol":"dogegov_usdt","name":"Department Of Government Efficiency"},{"symbol":"coco_usdt","name":"COCO COIN"},{"symbol":"babyshark_usdt","name":"Baby Shark Meme"},{"symbol":"rfc_usdt","name":"Retard Finder Coin"},{"symbol":"acid_usdt","name":"Acid AI"},{"symbol":"letsbonk_usdt","name":"Let&quot;s BONK"},{"symbol":"ultra_usdt","name":"UltraSafe"},{"symbol":"fightsol_usdt","name":"FIGHT"},{"symbol":"jos_usdt","name":"JuliaOS"},{"symbol":"virgen_usdt","name":"VIRGEN by Virtuals"},{"symbol":"crybb_usdt","name":"CryBaby"},{"symbol":"billy_usdt","name":"Billy"},{"symbol":"king1_usdt","name":"CHARLES"},{"symbol":"hvi_usdt","name":"Hungarian Vizsla Inu"},{"symbol":"lol_usdt","name":"LOL"},{"symbol":"brise_usdt","name":"Bitrise Token"},{"symbol":"hood_usdt","name":"Robinhood"},{"symbol":"myro_usdt","name":"Myro"},{"symbol":"skicat_usdt","name":"SKI MASK CAT"},{"symbol":"quack_usdt","name":"RichQUACK.com"},{"symbol":"froge_usdt","name":"Froge"},{"symbol":"mirai_usdt","name":"MIRAI"},{"symbol":"mog_usdt","name":"Mog Coin"},{"symbol":"tag_usdt","name":"Tagger"},{"symbol":"egl1_usdt","name":"EGL1"},{"symbol":"bob3_usdt","name":"Build On BNB"},{"symbol":"giko_usdt","name":"Giko Cat"},{"symbol":"melania_usdt","name":"Melania Meme"},{"symbol":"doginme_usdt","name":"DOGINME"},{"symbol":"house_usdt","name":"Housecoin"},{"symbol":"mlg_usdt","name":"360noscope420blazeit"},{"symbol":"ridge_usdt","name":"RIDGE"},{"symbol":"u_usdt","name":"U"},{"symbol":"mates_usdt","name":"MATES"},{"symbol":"ball_usdt","name":"POWERBALL"},{"symbol":"liberty_usdt","name":"Torch of Liberty"},{"symbol":"dino_usdt","name":"DINO"},{"symbol":"pippin_usdt","name":"PIPPIN"},{"symbol":"fatcoin_usdt","name":"fatcoin"},{"symbol":"aidoge_usdt","name":"AIDOGE"},{"symbol":"neet_usdt","name":"NotInEmploymentEducationTraining"},{"symbol":"iq_usdt","name":"IQ6900"},{"symbol":"clanker_usdt","name":"tokenbot"},{"symbol":"rich_usdt","name":"GET RICH QUICK"},{"symbol":"griffain_usdt","name":"test griffain.com"},{"symbol":"ban_usdt","name":"Comedian"},{"symbol":"jager_usdt","name":"Jager Hunter"},{"symbol":"degenai_usdt","name":"Degen Spartan AI"},{"symbol":"michi_usdt","name":"Michi"},{"symbol":"bananas31_usdt","name":"Banana For Scale"},{"symbol":"barronsol_usdt","name":"Official Barron Meme"},{"symbol":"faith_usdt","name":"FAITH"},{"symbol":"mixie_usdt","name":"Mixie"},{"symbol":"scard_usdt","name":"SCARDust"},{"symbol":"rifampicin_usdt","name":"Rifampicin"},{"symbol":"kekius_usdt","name":"Kekius Maximus"},{"symbol":"iris_usdt","name":"I.R.I.S by Virtuals"},{"symbol":"mori_usdt","name":"MORI COIN"},{"symbol":"apple_usdt","name":"Apple"},{"symbol":"project89_usdt","name":"Project89"},{"symbol":"fivess_usdt","name":"FiveSs"},{"symbol":"launchcoin_usdt","name":"Launch Coin on Believe"},{"symbol":"smoon_usdt","name":"SaylorMoon"},{"symbol":"agixt_usdt","name":"AGiXT"},{"symbol":"banana_usdt","name":"Banana Gun"},{"symbol":"noice_usdt","name":"noice"},{"symbol":"nyla_usdt","name":"NYLA"},{"symbol":"doodi_usdt","name":"DOODiPALS"},{"symbol":"dogecoin_usdt","name":"Buff Doge Coin"},{"symbol":"splat_usdt","name":"Ask Splat"},{"symbol":"daddydoge_usdt","name":"DaddyDoge"},{"symbol":"snibbu_usdt","name":"Snibbu"},{"symbol":"nobody_usdt","name":"Nobody Sausage"},{"symbol":"erc69_usdt","name":"Expansive Rectal Coin"},{"symbol":"grift_usdt","name":"ORBIT"},{"symbol":"kiba_usdt","name":"Kiba Inu"},{"symbol":"evan_usdt","name":"Evan"},{"symbol":"act_usdt","name":"Act I"},{"symbol":"lou_usdt","name":"lou"},{"symbol":"sen_usdt","name":"Sentio Protocol"},{"symbol":"send_usdt","name":"SEND"},{"symbol":"swarms_usdt","name":"swarms"},{"symbol":"void_usdt","name":"Nothing"},{"symbol":"broccoli_usdt","name":"CZ&quot;S DOG"},{"symbol":"virtual_usdt","name":"Virtual Protocol"},{"symbol":"quarm_usdt","name":"QUARM"},{"symbol":"kled_usdt","name":"KLEDAI"},{"symbol":"doge_usdt","name":"Dogecoin"},{"symbol":"chillguy_usdt","name":"Just a chill guy"},{"symbol":"bnkr_usdt","name":"BankrCoin"},{"symbol":"snek_usdt","name":"SNEK"},{"symbol":"gork_usdt","name":"New XAI gork"},{"symbol":"leopard_usdt","name":"LEOPARD"},{"symbol":"gass_usdt","name":"Gasspas"},{"symbol":"jellyjelly_usdt","name":"jelly-my-jelly"},{"symbol":"lumo_usdt","name":"Lumo-8B-Instruct"},{"symbol":"perry_usdt","name":"PERRY"},{"symbol":"fuckcoin_usdt","name":"fuckcoin"},{"symbol":"fb_usdt","name":"Fractal Bitcoin"},{"symbol":"dbr_usdt","name":"deBridge"},{"symbol":"pwease_usdt","name":"pwease"},{"symbol":"agon_usdt","name":"AGON Agent"},{"symbol":"bome_usdt","name":"BOOK OF MEME"},{"symbol":"solace_usdt","name":"Solace by Virtuals"},{"symbol":"opaium_usdt","name":"opaium"},{"symbol":"ygg_usdt","name":"Yield Guild Games"},{"symbol":"llm_usdt","name":"Large Language Model"},{"symbol":"fafo_usdt","name":"FAFO"},{"symbol":"tm_usdt","name":"Trench Medic"},{"symbol":"mini_usdt","name":"mini"},{"symbol":"startup_usdt","name":"Startup"},{"symbol":"cloudy_usdt","name":"Cloudyheart"},{"symbol":"totoro_usdt","name":"Totoro Inu"},{"symbol":"blovely_usdt","name":"Baby Lovely Inu"},{"symbol":"zeus1_usdt","name":"Pepes Dog"},{"symbol":"miggles_usdt","name":"Mister Miggles"},{"symbol":"happy_usdt","name":"HAPPY CAT"},{"symbol":"tapeth_usdt","name":"The America Party"},{"symbol":"boop_usdt","name":"BOOP"},{"symbol":"prcl_usdt","name":"Parcl"},{"symbol":"wojak_usdt","name":"WOJAK COIN"},{"symbol":"lovely_usdt","name":"Lovely Finance"},{"symbol":"skyai_usdt","name":"SKYAI"},{"symbol":"neur_usdt","name":"neur.sh"},{"symbol":"sigma_usdt","name":"SIGMA"},{"symbol":"stupid_usdt","name":"StupidCoin"},{"symbol":"mask1_usdt","name":"catwifmask"},{"symbol":"fartcat_usdt","name":"FartCat"},{"symbol":"spl_usdt","name":"SPL"},{"symbol":"usa_usdt","name":"American Coin"},{"symbol":"ainti_usdt","name":"AIntivirus"},{"symbol":"dreams_usdt","name":"Daydreams"},{"symbol":"kori_usdt","name":"Kori The Pom"},{"symbol":"whisp_usdt","name":"WHISP"},{"symbol":"schizo_usdt","name":"schizo"},{"symbol":"dawgs_usdt","name":"SPACEDAWGS"},{"symbol":"solami_usdt","name":"solami"},{"symbol":"sbet_usdt","name":"SharpLink Gaming"},{"symbol":"nub_usdt","name":"nubcat"},{"symbol":"cocoro_usdt","name":"Cocoro"},{"symbol":"moby_usdt","name":"Moby AI"},{"symbol":"ghibli_usdt","name":"Ghiblification"},{"symbol":"babydoge_usdt","name":"BABYDOGE"},{"symbol":"mana_usdt","name":"Decentraland"},{"symbol":"wolverinu_usdt","name":"WOLVERINU"},{"symbol":"moodeng_usdt","name":"Moo Deng"},{"symbol":"metav_usdt","name":"METAVERSE"},{"symbol":"chillhouse_usdt","name":"Chill House"},{"symbol":"axr_usdt","name":"Axelrod by Virtuals"},{"symbol":"dxb_usdt","name":"DXBPay"},{"symbol":"test_usdt","name":"TESTCOIN"},{"symbol":"wif_usdt","name":"dogwifhat"},{"symbol":"ubc_usdt","name":"Universal Basic Compute"},{"symbol":"jproof_usdt","name":"JProof"},{"symbol":"dogeai_usdt","name":"DOGE AI"},{"symbol":"tap_usdt","name":"THE AMERICA PARTY"},{"symbol":"labubu_usdt","name":"LABUBU"},{"symbol":"oil_usdt","name":"Digital Oil Memecoin"},{"symbol":"grph_usdt","name":"Soul Graph"},{"symbol":"mbf_usdt","name":"MoonBear Finance"},{"symbol":"klee_usdt","name":"Klee Kai"},{"symbol":"saitanobi_usdt","name":"SAITANOBI"},{"symbol":"tibbir_usdt","name":"Ribbita by Virtuals"},{"symbol":"janitor_usdt","name":"Janitor"},{"symbol":"hippo_usdt","name":"hippoHippo_CTO"},{"symbol":"doger_usdt","name":"DOGELINK"},{"symbol":"aft_usdt","name":"AIFlow"},{"symbol":"mack_usdt","name":"Mack the Meowing Cat"},{"symbol":"donkey_usdt","name":"donkey"},{"symbol":"tank_usdt","name":"AgentTank"},{"symbol":"buttcoin_usdt","name":"The Next Bitcoin"},{"symbol":"lljeffy_usdt","name":"vitafin"},{"symbol":"bscreener_usdt","name":"BelieveScreener"},{"symbol":"moodengeth_usdt","name":"MOO DENG"},{"symbol":"verse_usdt","name":"Verse World"},{"symbol":"arc_usdt","name":"AI Rig Complex"},{"symbol":"drb_usdt","name":"DebtReliefBot"},{"symbol":"buck_usdt","name":"GME MASCOT"},{"symbol":"aixbt_usdt","name":"aixbt by Virtuals"},{"symbol":"lucky_usdt","name":"LBank Mascot"},{"symbol":"moonpig_usdt","name":"moonpig"},{"symbol":"pcule_usdt","name":"Polycule"},{"symbol":"ski_usdt","name":"SKI MASK DOG"},{"symbol":"odom_usdt","name":"ODOM"},{"symbol":"fullsend_usdt","name":"Fullsend Community Coin"},{"symbol":"kek_usdt","name":"KEK by Virtuals"},{"symbol":"elonsol_usdt","name":"Official Elon Coin"},{"symbol":"do2_usdt","name":"DO2"},{"symbol":"gork1_usdt","name":"@gork"},{"symbol":"degen_usdt","name":"Degen"},{"symbol":"major_usdt","name":"Major price"},{"symbol":"mamo_usdt","name":"Mamo"},{"symbol":"luce_usdt","name":"Official Mascot of the Holy Year"},{"symbol":"alon_usdt","name":"ALON"},{"symbol":"car_usdt","name":"Central African Republic Meme"},{"symbol":"stonks_usdt","name":"STONKS"},{"symbol":"giga_usdt","name":"GIGACHAD"},{"symbol":"ltex_usdt","name":"Ltradex"},{"symbol":"toly_usdt","name":"toly&quot;s minutes"},{"symbol":"apx1_usdt","name":"ApolloX"},{"symbol":"gfm_usdt","name":"GoFundMeme"},{"symbol":"nap_usdt","name":"SNAP"},{"symbol":"fitcoin_usdt","name":"FITCOIN"},{"symbol":"salary_usdt","name":"salary"},{"symbol":"mononokeinu_usdt","name":"MONONOKEINU"},{"symbol":"broccoli4_usdt","name":"Broccoli"},{"symbol":"tremp_usdt","name":"Doland tremp"},{"symbol":"taboo_usdt","name":"TABOO"},{"symbol":"people_usdt","name":"ConstitutionDAO"},{"symbol":"slerf_usdt","name":"SLERF"},{"symbol":"buidl_usdt","name":"buidl"},{"symbol":"shibdoge_usdt","name":"SHIBDOGE"},{"symbol":"jtvo_usdt","name":"Jatev"},{"symbol":"cult_usdt","name":"Milady Cult Coin"},{"symbol":"gorilla_usdt","name":"gorilla"},{"symbol":"snai_usdt","name":"SwarmNode.ai"},{"symbol":"goglz_usdt","name":"GOGGLES"},{"symbol":"broccoli1_usdt","name":"Broccoli1"},{"symbol":"mew_usdt","name":"cat in a dogs world"},{"symbol":"img_usdt","name":"Infinite Money Glitch"},{"symbol":"mubarak_usdt","name":"Mubarak"},{"symbol":"babysaitama_usdt","name":"Baby Saitama Inu"},{"symbol":"memecoin_usdt","name":"Memecoin"},{"symbol":"opus_usdt","name":"Claude Opus"},{"symbol":"vibe_usdt","name":"VIBE CAT"},{"symbol":"nura_usdt","name":"Nura Labs"},{"symbol":"jailstool_usdt","name":"Stool Prisondente"},{"symbol":"lambo_usdt","name":"LAMBO"},{"symbol":"yzy_usdt","name":"YZY"},{"symbol":"collat_usdt","name":"Collaterize"},{"symbol":"xbt_usdt","name":"XBT"},{"symbol":"mtn_usdt","name":"mtnCapital"},{"symbol":"gor_usdt","name":"Gorbagana"},{"symbol":"aimonica_usdt","name":"Aimonica Brands"},{"symbol":"zailgo_usdt","name":"ZAILGO"},{"symbol":"id1_usdt","name":"Integrity DAO"},{"symbol":"form_usdt","name":"BinaryX"},{"symbol":"usduc_usdt","name":"unstable coin"},{"symbol":"sif_usdt","name":"Solana Index Fund"},{"symbol":"koma_usdt","name":"Koma Inu"},{"symbol":"buckazoids_usdt","name":"BUCKAZOIDS"},{"symbol":"bulla_usdt","name":"BULLA"},{"symbol":"sc_usdt","name":"Shark Cat"},{"symbol":"olivia_usdt","name":"AIGOV"},{"symbol":"maneki_usdt","name":"MANEKI"},{"symbol":"keycat_usdt","name":"Keyboard Cat"},{"symbol":"cocoroeth_usdt","name":"COCORO"},{"symbol":"shib_usdt","name":"shib"},{"symbol":"licko_usdt","name":"LICKO"},{"symbol":"aa_usdt","name":"A3S"},{"symbol":"kbbb_usdt","name":"KILL BIG BEAUTIFUL BILL"},{"symbol":"p1_usdt","name":"PEPE ONE"},{"symbol":"pengu_usdt","name":"Pudgy Penguins"},{"symbol":"ai16z_usdt","name":"ai16z"},{"symbol":"buzz_usdt","name":"Hive AI"},{"symbol":"eliza_usdt","name":"ELIZA"},{"symbol":"ket_usdt","name":"yellow ket"},{"symbol":"trencher_usdt","name":"trencher"},{"symbol":"aart_usdt","name":"ALL.ART"},{"symbol":"popcat_usdt","name":"Popcat"},{"symbol":"fat_usdt","name":"FAT NIGGA SEASON"},{"symbol":"lockin_usdt","name":"LOCK IN"},{"symbol":"dpcore_usdt","name":"DeepCore AI"},{"symbol":"terminus_usdt","name":"First City in Mars"},{"symbol":"mambo_usdt","name":"Mambo"},{"symbol":"wink_usdt","name":"WINK"},{"symbol":"baseisforevery1_usdt","name":"Base is for everyone"},{"symbol":"lester_usdt","name":"Litecoin Mascot"},{"symbol":"dog_usdt","name":"DOG GO TO THE MOON"},{"symbol":"trenches_usdt","name":"TheTrenches"},{"symbol":"hmstr_usdt","name":"Hamster Kombat"},{"symbol":"pepe_usdt","name":"Pepe"},{"symbol":"brett_usdt","name":"Brett"},{"symbol":"wen_usdt","name":"WEN"},{"symbol":"bobo_usdt","name":"BOBO"},{"symbol":"poodl_usdt","name":"POODL"},{"symbol":"vine_usdt","name":"Vine Coin"},{"symbol":"bunker_usdt","name":"BunkerCoin"},{"symbol":"ponke_usdt","name":"PONKE"},{"symbol":"floki_usdt","name":"FLOKI"},{"symbol":"tut_usdt","name":"Tutorial"},{"symbol":"uro_usdt","name":"Urolithin A"},{"symbol":"dupe_usdt","name":"Dupe"},{"symbol":"trust_usdt","name":"Trust The Process"},{"symbol":"fred_usdt","name":"First Convicted Raccon"},{"symbol":"troll_usdt","name":"TROLL"},{"symbol":"dusk1_usdt","name":"DUSK"},{"symbol":"fomo_usdt","name":"FOMO"},{"symbol":"ufd_usdt","name":"Unicorn Fart Dust"},{"symbol":"b_usdt","name":"B"},{"symbol":"hosico_usdt","name":"Hosico cat"},{"symbol":"ladys_usdt","name":"Milady Meme Coin"},{"symbol":"luigi_usdt","name":"Luigi Mangione"},{"symbol":"shrub_usdt","name":"SHRUB"},{"symbol":"avaai_usdt","name":"AVAAI"},{"symbol":"titcoin_usdt","name":"titcoin"},{"symbol":"goonc_usdt","name":"gooncoin"},{"symbol":"aios_usdt","name":"AIOS Foundation"},{"symbol":"sse_usdt","name":"Solana Social Explorer"},{"symbol":"szn_usdt","name":"Szn"},{"symbol":"tst_usdt","name":"TokenTest"},{"symbol":"kawa_usdt","name":"Kawakami"},{"symbol":"giggles_usdt","name":"Giggles"},{"symbol":"goatseus_usdt","name":"goatse"},{"symbol":"dark_usdt","name":"Dark Eclipse"},{"symbol":"gm_usdt","name":"GOMBLE"},{"symbol":"cheems_usdt","name":"Cheems"},{"symbol":"fight_usdt","name":"Fight to MAGA"},{"symbol":"ikun_usdt","name":"IKUN"},{"symbol":"tracy_usdt","name":"TracyAI by Virtuals"},{"symbol":"knet_usdt","name":"Kingnet AI"}];
// TV62: load the bundled LBank spot catalogue directly inside the WebView.
// This removes the startup timing dependency on the native Java callback: the
// catalogue provides symbols/names only; prices are still filled exclusively
// by live native/LBank feeds.
async function loadBundledSpotCatalogue(){
  // 1202: bundled LBank catalogue is names-only metadata. It must NEVER
  // overwrite the live Ourbit market universe or create stale symbols.
  try{
    const rows=Array.isArray(CP_BUNDLED_LBANK_SPOT_CATALOG)?CP_BUNDLED_LBANK_SPOT_CATALOG:[];
    window.__cpBundledNames=window.__cpBundledNames||{};
    for(const r of rows){const k=cpCanonicalSymbol(r?.symbol||'');if(k)window.__cpBundledNames[k]=String(r?.name||k);}
    return rows.length;
  }catch(_e){return 0}
}

// REBUILD73: preserve the authoritative bundled catalogue order as a stable
// listing-order index for the Newest tab. This is intentionally independent of
// price, volume, and the major-coin ordering used by the main All tab.
try{
  const cat=Array.isArray(CP_BUNDLED_LBANK_SPOT_CATALOG)?CP_BUNDLED_LBANK_SPOT_CATALOG:[];
  window.__cpListingRank=new Map(cat.map((r,i)=>[cpCanonicalSymbol(r.symbol||r[0]||''),i]).filter(([k])=>k));
}catch(_e){window.__cpListingRank=new Map()}

loadBundledSpotCatalogue();
try{setTimeout(()=>{try{window.CryptoPulseNative?.fetchOurbitSpotTickers?.('startup')}catch(_e){}},50)}catch(_e){}

// After the bulk response lands, immediately re-scan the exact rendered Home slice.
// This is intentionally independent from the 8-second global refresh timer.
function requestVisiblePricesSoon(){
  try{ requestMissingVisiblePrices(true); }catch(_e){}
}


// Native Android fills symbols that the bulk LBank ticker does not return.
// Apply each completed row immediately so prices appear progressively while
// the user scrolls instead of waiting for the full batch.
function applyMissingLBankMarketRow(payload){
  let r=null;
  try{r=typeof payload==='string'?JSON.parse(payload):payload}catch(_e){r=null}
  if(!r)return 0;
  const key=String(r?.symbol||'').toUpperCase();
  const price=Number(r?.price);
  if(!key||!Number.isFinite(price)||price<=0)return 0;
  const change=Number(r?.change),vol=Number(r?.volume);
  const old=liveCache[key]||{};
  liveCache[key]={...old,price,change:Number.isFinite(change)?change:(old.change||0),volume:Number.isFinite(vol)?vol:(old.volume||0),connected:true,lastUpdate:Date.now(),provider:String(r?.provider||'LBank Native Single')};
  const c=coins.find(x=>x[0]===key);
  if(c){
    c[2]=String(price);
    if(Number.isFinite(change))c[3]=(change>=0?'+':'')+change.toFixed(2)+'%';
    if(Number.isFinite(vol))c[4]=String(vol);
  }
  liveHub.lastMessage=Date.now();
  setDataStatus(true);
  window.dispatchEvent(new Event('cp-market-prices-ready'));
  renderHomeMarkets?.();
  renderHomeBalance?.();
  // Do NOT immediately call requestMissingVisiblePrices() here. The native
  // callback itself came from that request; doing so created a callback/request
  // loop and could keep Home in its skeleton/error state. The shared pulse will
  // request stale/missing rows on its normal cadence.
  return 1;
}
window.cpNativeMissingLBankMarketRow=applyMissingLBankMarketRow;

function applyMissingLBankMarketData(payload){
  let q=null;
  try{q=typeof payload==='string'?JSON.parse(payload):payload}catch(_e){q=null}
  const rows=Array.isArray(q)?q:[];
  let updated=0;
  for(const r of rows)updated+=applyMissingLBankMarketRow(r);
  // The native side sends this callback when the complete retry batch has finished.
  // Release the in-flight gate immediately so the next scan can request only the
  // symbols that are still missing.
  nativeMissingBatchBusy=false;
  return updated;
}
window.cpNativeMissingLBankMarketData=applyMissingLBankMarketData;

// Fill missing LBank symbols from a secondary public ticker feed.
function applyBinanceMarketTickerPayload(payload){
  let q=null;
  try{q=typeof payload==='string'?JSON.parse(payload):payload}catch(_e){q=null}
  const rows=Array.isArray(q)?q:[];
  const aliases={MATIC:'POL',FTM:'S'};
  let updated=0;
  for(const r of rows){
    const rawSym=String(r?.symbol||'').toUpperCase();
    if(!rawSym.endsWith('USDT'))continue;
    const base=rawSym.slice(0,-4);
    const key=Object.keys(aliases).find(k=>aliases[k]===base)||base;
    if(!coins.some(c=>c[0]===key))continue;
    const price=Number(r?.lastPrice),change=Number(r?.priceChangePercent),vol=Number(r?.quoteVolume);
    if(!Number.isFinite(price))continue;
    const old=liveCache[key];
    // LBank stays authoritative when it has a recent value.
    if(old&&Number.isFinite(Number(old.price))&&old.lastUpdate&&Date.now()-old.lastUpdate<30000&&String(old.provider||'').startsWith('LBank'))continue;
    liveCache[key]={...(old||{}),price,change:Number.isFinite(change)?change:(old?.change||0),volume:Number.isFinite(vol)?vol:(old?.volume||0),connected:true,lastUpdate:Date.now(),provider:'Secondary'};
    const c=coins.find(x=>x[0]===key);
    if(c){c[2]=String(price);if(Number.isFinite(change))c[3]=(change>=0?'+':'')+change.toFixed(2)+'%';if(Number.isFinite(vol))c[4]=String(vol)}
    updated++;
  }
  if(updated){liveHub.lastMessage=Date.now();setDataStatus(true);window.dispatchEvent(new Event('cp-market-prices-ready'));renderHomeMarkets?.();renderHomeBalance?.();}
  return updated;
}
window.cpNativeBinanceMarketData=applyBinanceMarketTickerPayload;

// Broad secondary feed: CoinCap returns a single compact list of USD prices,
// which lets the app fill symbols that are not currently present in LBank/Binance.
function applyCoinCapMarketTickerPayload(payload){
  let q=null;
  try{q=typeof payload==='string'?JSON.parse(payload):payload}catch(_e){q=null}
  const rows=Array.isArray(q?.data)?q.data:[];
  let updated=0;
  const bySym=new Map(rows.map(r=>[String(r?.symbol||'').toUpperCase(),r]));
  const aliases={POL:'MATIC',S:'FTM'};
  for(const c of coins){
    const key=String(c[0]).toUpperCase();
    let r=bySym.get(key);
    if(!r && key==='MATIC') r=bySym.get('POL');
    if(!r && key==='FTM') r=bySym.get('S');
    if(!r)continue;
    const price=Number(r?.priceUsd), change=Number(r?.changePercent24Hr), vol=Number(r?.volumeUsd24Hr);
    if(!Number.isFinite(price))continue;
    const old=liveCache[key];
    // Never overwrite a fresh LBank value. This feed is only for missing/stale rows.
    if(old&&Number.isFinite(Number(old.price))&&old.lastUpdate&&Date.now()-old.lastUpdate<30000&&String(old.provider||'').startsWith('LBank'))continue;
    liveCache[key]={...(old||{}),price,change:Number.isFinite(change)?change:(old?.change||0),volume:Number.isFinite(vol)?vol:(old?.volume||0),connected:true,lastUpdate:Date.now(),provider:'CoinCap Secondary'};
    c[2]=String(price);
    if(Number.isFinite(change))c[3]=(change>=0?'+':'')+change.toFixed(2)+'%';
    if(Number.isFinite(vol))c[4]=String(vol);
    updated++;
  }
  if(updated){try{persistSharedLiveCache()}catch(_e){};liveHub.lastMessage=Date.now();setDataStatus(true);window.dispatchEvent(new Event('cp-market-prices-ready'));renderHomeMarkets?.();renderHomeBalance?.();}
  return updated;
}
window.cpNativeCoinCapMarketData=applyCoinCapMarketTickerPayload;

function applyCoinPaprikaMarketTickerPayload(payload){
  let q=null;
  try{q=typeof payload==='string'?JSON.parse(payload):payload}catch(_e){q=null}
  const rows=Array.isArray(q)?q:[];
  let updated=0;
  const bySym=new Map(rows.map(r=>[String(r?.symbol||'').toUpperCase(),r]));
  for(const c of coins){
    const key=String(c[0]).toUpperCase();
    const r=bySym.get(key);
    if(!r)continue;
    const price=Number(r?.quotes?.USD?.price), change=Number(r?.quotes?.USD?.percent_change_24h), vol=Number(r?.quotes?.USD?.volume_24h);
    if(!Number.isFinite(price))continue;
    const old=liveCache[key];
    if(old&&Number.isFinite(Number(old.price))&&old.lastUpdate&&Date.now()-old.lastUpdate<30000&&String(old.provider||'').startsWith('LBank'))continue;
    liveCache[key]={...(old||{}),price,change:Number.isFinite(change)?change:(old?.change||0),volume:Number.isFinite(vol)?vol:(old?.volume||0),connected:true,lastUpdate:Date.now(),provider:'CoinPaprika Secondary'};
    c[2]=String(price);
    if(Number.isFinite(change))c[3]=(change>=0?'+':'')+change.toFixed(2)+'%';
    if(Number.isFinite(vol))c[4]=String(vol);
    updated++;
  }
  if(updated){try{persistSharedLiveCache()}catch(_e){};liveHub.lastMessage=Date.now();setDataStatus(true);window.dispatchEvent(new Event('cp-market-prices-ready'));renderHomeMarkets?.();renderHomeBalance?.();}
  return updated;
}
window.cpNativeCoinPaprikaMarketData=applyCoinPaprikaMarketTickerPayload;
let nativeFallbackRequestAt=0;
let nativeMissingRequestAt=0;
let nativeMissingBatchBusy=false;
let nativeMissingCursor=0;
let nativeMissingRetryTimer=0;
let liveRotationTimer=0;
let liveRotationCursor=0;
function getRenderedHomeSymbols(){
  const out=[];
  document.querySelectorAll('#homeMarkets .home-coin-row a.home-coin-main[href*="asset.html?symbol="]').forEach(a=>{
    try{const u=new URL(a.getAttribute('href'),location.href);const s=(u.searchParams.get('symbol')||'').toUpperCase();if(s)out.push(s)}catch(_e){}
  });
  return [...new Set(out)];
}
function getAllMissingMarketSymbols(){
  const now=Date.now(), out=[];
  const source=Array.isArray(coins)?coins:[];
  for(const c of source){
    const sym=String(c?.[0]||'').toUpperCase();
    if(!sym)continue;
    const raw=liveCache[sym];
    const price=Number(raw?.price);
    if(!raw||!Number.isFinite(price)||price<=0||!raw.lastUpdate||now-Number(raw.lastUpdate)>90000)out.push(sym);
  }
  return [...new Set(out)];
}
function requestMissingVisiblePrices(force=false){
  // 1201: Ourbit is the only Home market source. The old LBank-only missing
  // ticker bridge did not exist in the clean build, so lower rows could never
  // request a live price. Re-request the complete Ourbit ticker snapshot instead.
  if(!window.CryptoPulseNative||typeof window.CryptoPulseNative.fetchOurbitSpotTickers!=='function')return;
  const now=Date.now();
  if(!force && now-nativeMissingRequestAt<1800)return;
  if(nativeMissingBatchBusy && !force)return;
  let renderedList=[...coins];
  try{renderedList=homeSort(renderedList,homeMarketFilter)}catch(_e){}
  const domSymbols=getRenderedHomeSymbols();
  const domSet=new Set(domSymbols);
  const lookAhead=renderedList.filter(c=>!domSet.has(String(c[0]).toUpperCase())).slice(0,40).map(c=>String(c[0]).toUpperCase());
  const visiblePriority=[...new Set([...domSymbols,...lookAhead])];
  const allMissing=getAllMissingMarketSymbols();
  if(!allMissing.length)return;

  // Visible rows always get first priority. The remaining missing symbols are
  // rotated in batches so a permanently unavailable pair cannot starve the rest.
  const visibleMissing=visiblePriority.filter(s=>allMissing.includes(s));
  const visibleSet=new Set(visibleMissing);
  const rest=allMissing.filter(s=>!visibleSet.has(s));
  const batchSize=20;
  if(nativeMissingCursor>=rest.length)nativeMissingCursor=0;
  const rotated=rest.length ? rest.slice(nativeMissingCursor).concat(rest.slice(0,nativeMissingCursor)) : [];
  const batch=[...new Set([...visibleMissing,...rotated])].slice(0,batchSize);
  if(!batch.length)return;
  nativeMissingCursor=(nativeMissingCursor+Math.max(1,batch.length-visibleMissing.length))%Math.max(1,rest.length);
  nativeMissingRequestAt=now;
  nativeMissingBatchBusy=true;
  ensureLiveSubscriptions([...new Set([...visiblePriority,...batch])].slice(0,200));
  // One authoritative Ourbit snapshot contains every currently quoted USDT pair.
  // Do not request LBank symbols individually; many of those pairs are not quoted
  // on Ourbit and were the direct cause of persistent dashes in lower Home rows.
  try{window.CryptoPulseNative.fetchOurbitSpotTickers('home_missing')}catch(_e){}
  setTimeout(()=>{nativeMissingBatchBusy=false;},3500);
}
// REBUILD65: Home return must hydrate the COMPLETE market universe, not only
// the rows currently visible on screen. The shared cache is kept intact, so
// this never creates a second market connection; it simply asks the native
// LBank ticker engine to fill every missing/stale symbol in small batches.
let __cpHomeAllPriceTimer=0;
let __cpHomeAllPriceCursor=0;
function requestAllHomePrices(force=false){
  if(!window.CryptoPulseNative||typeof window.CryptoPulseNative.fetchOurbitSpotTickers!=='function')return;
  if(force){try{window.CryptoPulseNative.fetchOurbitSpotTickers?.('home')}catch(_e){};try{window.CryptoPulseNative.fetchCoinPaprikaTickers?.()}catch(_e){};try{cpBrowserBulkOurbitHomePrices()}catch(_e){}}
  if(!Array.isArray(coins)||!coins.length){
    try{window.CryptoPulseNative?.fetchMarketUniverse?.()}catch(_e){}
    return;
  }
  const now=Date.now();
  const missing=[];
  for(const c of coins){
    const sym=String(c?.[0]||'').toUpperCase();
    if(!sym)continue;
    const v=liveCache[sym], price=Number(v?.price), ts=Number(v?.lastUpdate||0);
    if(force || !Number.isFinite(price) || price<=0 || !ts || now-ts>90000) missing.push(sym);
  }
  if(!missing.length)return;
  if(__cpHomeAllPriceCursor>=missing.length)__cpHomeAllPriceCursor=0;
  const batch=missing.slice(__cpHomeAllPriceCursor,__cpHomeAllPriceCursor+20);
  __cpHomeAllPriceCursor=(__cpHomeAllPriceCursor+Math.max(1,batch.length))%Math.max(1,missing.length);
  try{ensureLiveSubscriptions(missing.slice(0,80))}catch(_e){}
  try{window.CryptoPulseNative.fetchOurbitSpotTickers('home_batch')}catch(_e){}
  if(!__cpHomeAllPriceTimer){
    __cpHomeAllPriceTimer=setInterval(()=>{
      if(document.visibilityState==='hidden')return;
      if(!document.getElementById('homeMarkets'))return;
      try{requestAllHomePrices(false)}catch(_e){}
    },2800);
  }
}
function startMissingPriceRetryLoop(){
  if(nativeMissingRetryTimer)return;
  const tick=()=>{
    if(document.visibilityState==='hidden')return;
    try{requestMissingVisiblePrices(false)}catch(_e){nativeMissingBatchBusy=false}
  };
  tick();
  nativeMissingRetryTimer=setInterval(tick,3000);
}
startMissingPriceRetryLoop();
async function cpBrowserBulkOurbitHomePrices(){
  try{
    const r=await fetch(OURBIT_API_BASE+'/api/v3/ticker/24hr',{cache:'no-store'});if(!r.ok)throw new Error('Ourbit HTTP '+r.status);
    const q=await r.json();const rows=Array.isArray(q)?q:(Array.isArray(q?.data)?q.data:[]);let n=0;
    for(const x of rows){const raw=String(x?.symbol||'').toUpperCase();if(!raw.endsWith('USDT'))continue;const sym=raw.slice(0,-4);const price=Number(x?.lastPrice??x?.last??x?.price);if(!Number.isFinite(price)||price<=0)continue;liveCache[sym]={...(liveCache[sym]||{}),price,change:Number(x?.priceChangePercent??x?.changePercent??0)||0,volume:Number(x?.quoteVolume??x?.volume??0)||0,lastUpdate:Date.now(),connected:true,provider:'Ourbit'};n++;try{syncHomeLiveRow(sym,liveCache[sym])}catch(_e){}}
    if(n){persistSharedLiveCache();setDataStatus(true)}return n;
  }catch(_e){return 0}
}
async function refreshMarketPrices(){
  // Android native HTTPS is the primary feed. It bypasses WebView CORS restrictions.
  if(window.CryptoPulseNative&&typeof window.CryptoPulseNative.fetchTickers==='function'){
    const now=Date.now();
    if(now-nativeMarketRequestAt<1200){requestMissingVisiblePrices();return 0;}
    nativeMarketRequestAt=now;
    try{window.CryptoPulseNative.fetchTickers();
      // IMPORTANT: the bulk endpoint does not always contain every pair. Explicitly
      // request missing visible rows instead of waiting for the secondary feeds.
      setTimeout(requestMissingVisiblePrices,180);
      setTimeout(requestMissingVisiblePrices,1200);
      // Fetch the secondary feed less often; it only fills missing symbols.
      // Secondary feeds are deliberately triggered on the first pass and then every 10s
      // while Home is active. They fill rows that LBank does not quote (or temporarily omits)
      // instead of leaving the lower half of the list stuck on dashes.
      if(Date.now()-nativeFallbackRequestAt>30000){
        nativeFallbackRequestAt=Date.now();
        if(typeof window.CryptoPulseNative.fetchFallbackTickers==='function') window.CryptoPulseNative.fetchFallbackTickers();
        if(typeof window.CryptoPulseNative.fetchCoinCapTickers==='function') window.CryptoPulseNative.fetchCoinCapTickers();
        if(typeof window.CryptoPulseNative.fetchCoinPaprikaTickers==='function') window.CryptoPulseNative.fetchCoinPaprikaTickers();
      }
      return 0;
    }catch(_e){requestMissingVisiblePrices();}
  }
  // Browser fallback for non-Android preview/testing.
  let updated=0;
  try{updated=await cpBrowserBulkOurbitHomePrices();if(updated)return updated}catch(_e){}
  try{
    const q=await lbankFetch('/v2/ticker/24hr.do?symbol=all');
    updated=applyMarketTickerPayload(q);
    if(updated)return updated;
  }catch(_e){}
  return updated;
}

async function loadHomeMarketUniverse(){
  try{
    const pairsRes=await lbankFetch('/v2/currencyPairs.do');
    const pairs=Array.isArray(pairsRes?.data)?pairsRes.data:[];
    const usdt=pairs.map(x=>String(x).toLowerCase()).filter(x=>/_usdt$/.test(x));
    const next=usdt.map(p=>p.replace(/_usdt$/i,'').toUpperCase()).filter(Boolean);
    if(!next.length)throw new Error('No LBank USDT pairs');
    let seen=[];try{seen=JSON.parse(localStorage.getItem('cp_seen_pairs')||'[]')}catch(_e){seen=[]}
    const seenSet=new Set(seen);const fresh=seen.length?next.filter(s=>!seenSet.has(s)):[];
    localStorage.setItem('cp_new_pairs',JSON.stringify(fresh.slice(0,500)));
    localStorage.setItem('cp_seen_pairs',JSON.stringify(next.slice(0,5000)));
    let rows=[];
    try{const tickRes=await lbankFetch('/v2/ticker/24hr.do?symbol=all');rows=Array.isArray(tickRes?.data)?tickRes.data:[]}catch(_e){}
    const map=new Map(rows.map(r=>[String(r.symbol||'').toUpperCase(),r]));
    const merged=next.map(sym=>{const r=map.get(sym+'_USDT'),t=r?.ticker||{},old=getCoin(sym);const price=Number(t.latest),change=Number(t.change),vol=Number(t.vol);if(Number.isFinite(price))liveCache[sym]={...(liveCache[sym]||{}),price,change:Number.isFinite(change)?change:0,volume:Number.isFinite(vol)?vol:0,connected:true,lastUpdate:Date.now(),provider:'Ourbit'};return [sym,old&&old[1]||sym,Number.isFinite(price)?String(price):(old?.[2]||'—'),Number.isFinite(change)?((change>=0?'+':'')+change.toFixed(2)+'%'):(old?.[3]||'0.00%'),Number.isFinite(vol)?String(vol):(old?.[4]||'0')];});
    const majorOrder=['BTC','ETH','BNB','SOL','XRP','DOGE','ADA','TRX','AVAX','LINK','DOT','LTC','BCH','UNI','NEAR','APT','SUI','TON','SHIB','PEPE','XLM','ATOM','ETC','FIL','HBAR','ICP','ARB','OP','AAVE','ALGO','VET','MATIC','POL','MKR','INJ','TIA','SEI','RUNE','JUP','WIF','BONK'];
    const majorRank=new Map(majorOrder.map((k,i)=>[k,i]));
    coins=merged.sort((a,b)=>{const ar=majorRank.has(a[0])?majorRank.get(a[0]):9999,br=majorRank.has(b[0])?majorRank.get(b[0]):9999;if(ar!==br)return ar-br;if(ar===9999){const av=Number(liveCache[a[0]]?.volume)||Number(a[4])||0,bv=Number(liveCache[b[0]]?.volume)||Number(b[4])||0;if(av!==bv)return bv-av;}return String(a[0]).localeCompare(String(b[0]));});
    if(merged.some(c=>Number.isFinite(Number(liveCache[c[0]]?.price)))){liveHub.lastMessage=Date.now();setDataStatus(true)} window.dispatchEvent(new Event('cp-market-universe-ready'));renderHomeMarkets?.();
    if(typeof render==='function')render();
  }catch(e){
    // Android: never replace a failed live universe with invented symbols.
    // The native bridge will deliver the authoritative LBank universe.
    // No fallback universe on Android. A failed exchange request must not
    // create fake/stale rows with dashes. Native retries on its own.
    window.dispatchEvent(new Event('cp-market-universe-ready'));renderHomeMarkets?.();
    if(typeof render==='function')render();
  }
}
// TV71: keep one shared near-real-time market pulse alive across SPA pages.
// WebSocket remains the fastest path; native bulk LBank ticker refresh is the
// reliability path for Android WebView/network combinations where WS packets
// are delayed or dropped.  The native bridge itself rate-limits duplicate calls.
let __cpMarketPulseStarted=false;
let __cpMarketPulseTimer=0;
function startSharedMarketPulse(){
  if(__cpMarketPulseStarted)return;
  __cpMarketPulseStarted=true;
  const pulse=()=>{
    if(document.visibilityState==='hidden')return;
    try{
      if(window.CryptoPulseNative?.fetchTickers) window.CryptoPulseNative.fetchTickers();
    }catch(_e){}
    // CLEAN ENGINE: no socket subscriptions here. Native engine owns market transport.

  };
  // Start the proven browser socket immediately; native REST/cache remains a
  // secondary source for non-WebSocket pages.
  try{startLiveSocket()}catch(_e){}
  try{ensureLiveSubscriptions(['BTC','ETH','BNB','SOL','XRP','DOGE','ADA','TRX'])}catch(_e){}
  pulse();
  if(!__cpMarketPulseTimer)__cpMarketPulseTimer=setInterval(pulse,15000);
}

startSharedMarketPulse();
// TV80: bootstrap the authoritative universe after WebView startup without
// creating a second live price connection.
let __cpUniverseBootstrapTimer=0;
function ensureSharedMarketUniverse(){
  try{window.CryptoPulseNative?.fetchMarketUniverse?.()}catch(_e){}
  if(__cpUniverseBootstrapTimer)return;
  let tries=0;
  __cpUniverseBootstrapTimer=setInterval(()=>{
    tries++;
    if(Array.isArray(window.coins)&&window.coins.length){clearInterval(__cpUniverseBootstrapTimer);__cpUniverseBootstrapTimer=0;return;}
    try{window.CryptoPulseNative?.fetchMarketUniverse?.()}catch(_e){}
    if(tries>=8){clearInterval(__cpUniverseBootstrapTimer);__cpUniverseBootstrapTimer=0}
  },1500);
}
function initHomePage(){
  // IMPORTANT: Home is re-rendered into the same WebView DOM when navigating
  // back from Markets. A permanent global "initialized" flag therefore leaves
  // the freshly-created Home skeleton untouched. Re-bind against the current
  // DOM instead; the shared socket/cache themselves remain singleton.
  const home=document.getElementById('homeMarkets');
  if(!home)return;
  // TV37 ROOT FIX: Home and Markets share ONE native LBank market feed.
  // Do not open a browser WebSocket or a separate REST universe here.
  renderHomeMarkets();
  bindHomeMarketEvents();
  renderHomeBalance();
  try{window.CryptoPulseNative?.restoreMarketCache?.()}catch(_e){}
  const refresh=()=>{try{restoreSharedLiveCache()}catch(_e){};renderHomeMarkets();renderHomeBalance()};
  if(!window.__cpHomeEventsBound){
    window.__cpHomeEventsBound=true;
    window.addEventListener('cp-market-cache-restored',()=>{if(document.getElementById('homeMarkets'))refresh()});
    window.addEventListener('cp-market-prices-ready',()=>{if(document.getElementById('homeMarkets'))refresh()});
    window.addEventListener('cp-market-universe-ready',()=>{if(document.getElementById('homeMarkets'))refresh()});
  }
  // The shared pulse owns live updates. Home only restores/reads the shared cache.
  refresh();
  // If this is the first Home render and the catalogue callback has not landed
  // yet, explicitly ask the Android bridge for the authoritative LBank universe.
  // This is a one-shot universe request, not a new price connection.
  if(!coins.length) ensureSharedMarketUniverse();
  // REBUILD65: when returning to Home, hydrate the COMPLETE coin list first.
  // The shared connection/cache remains the single source of truth; visible
  // rows are still prioritized, but every missing/stale coin is now requested
  // in rotating batches instead of waiting for scrolling.
  setTimeout(()=>{
    try{requestMissingVisiblePrices(true)}catch(_e){}
    try{requestAllHomePrices(true)}catch(_e){}
    // MOBILE FIX 1173: warm secondary public feeds immediately. They fill
    // catalogue symbols that are temporarily absent from the LBank snapshot.
    try{window.CryptoPulseNative?.fetchFallbackTickers?.()}catch(_e){}
    try{window.CryptoPulseNative?.fetchCoinCapTickers?.()}catch(_e){}
    setTimeout(()=>{try{window.CryptoPulseNative?.fetchCoinPaprikaTickers?.()}catch(_e){}},7000);
    // MOBILE FIX 1171: keep rotating through the complete LBank universe even
    // when every row initially has a cached/stale value. Lower rows must not
    // depend on scrolling into view. The native bridge remains rate-limited.
    try{requestAllHomePrices(false)}catch(_e){}
  },80);
  try{
    if(window.__cpHomePriceWatch)clearInterval(window.__cpHomePriceWatch);
    window.__cpHomePriceWatch=setInterval(()=>{
      if(document.visibilityState==='hidden'||!document.getElementById('homeMarkets'))return;
      try{requestAllHomePrices(false)}catch(_e){}
    },2200);
  }catch(_e){}

}

function initDashboard(){
  const render=async()=>{
    const d=await ticker('BTC');
    const price=document.getElementById('btcPrice'); if(price)price.textContent=money(d.price);
    const ch=document.getElementById('btcChange'); if(ch){ch.textContent=(d.change>=0?'+':'')+d.change.toFixed(2)+'%';ch.className=d.change>=0?'up':'down'}
    const cc=document.getElementById('btcChangeCard'); if(cc){cc.textContent=(d.change>=0?'+':'')+d.change.toFixed(2)+'% امروز';cc.className=d.change>=0?'up':'down'}
    const vol=document.getElementById('btcVolume'); if(vol)vol.textContent=formatCompact(d.volume);
    const st=document.getElementById('syncTime'); if(st)st.textContent=new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    checkAlerts('BTC',d.price);
  };
  render(); setInterval(render,10000);
  renderWatchlist();
  renderHomeSnapshot();
}
function renderWatchlist(){
  const box=document.getElementById('watchlist'), empty=document.getElementById('watchEmpty'); if(!box)return;
  const fav=favorites(); const list=coins.filter(c=>fav.includes(c[0]));
  box.innerHTML=list.length?coinCards(list.slice(0,6)) : ''; if(empty)empty.style.display=list.length?'none':'block';
}

function calcRSI(values, period=14){if(values.length<=period)return 50;let gains=0,losses=0;for(let i=1;i<=period;i++){const d=values[i]-values[i-1];if(d>=0)gains+=d;else losses-=d}let avgG=gains/period,avgL=losses/period;for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];avgG=((avgG*(period-1))+Math.max(d,0))/period;avgL=((avgL*(period-1))+Math.max(-d,0))/period}if(avgL===0)return 100;return 100-(100/(1+avgG/avgL))}
function calcEMA(values,period){const k=2/(period+1);let ema=values[0];for(let i=1;i<values.length;i++)ema=values[i]*k+ema*(1-k);return ema}
function calcMACD(values){const fast=calcEMA(values.slice(-60),12),slow=calcEMA(values.slice(-60),26);const macd=fast-slow;return {value:macd,signal:macd*0.88}}
function volatility(values){if(values.length<2)return 0;const r=[];for(let i=1;i<values.length;i++)r.push(Math.log(values[i]/values[i-1]));const avg=r.reduce((a,b)=>a+b,0)/r.length;return Math.sqrt(r.reduce((a,b)=>a+(b-avg)**2,0)/r.length)*100}

setInterval(()=>{try{cpCleanMarketStatus()}catch(_e){}},1000);
