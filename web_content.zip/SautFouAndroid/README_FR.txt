SAUT FOU ! — Projet Android de départ
======================================

IMPORTANT
- Ce dossier est un projet source Android, PAS un APK déjà compilé.
- L'application affiche le prototype HTML local dans une WebView.
- La compilation doit être faite dans Android Studio avec Internet et le SDK Android installés.

COMPILATION SUR ORDINATEUR (méthode la plus fiable)
1. Installe Android Studio depuis https://developer.android.com/studio
2. Décompresse le fichier ZIP.
3. Dans Android Studio : Open, puis sélectionne le dossier SautFouAndroid.
4. Accepte l'installation des composants Gradle/SDK proposés.
5. Attends la fin de la synchronisation.
6. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Le fichier APK de débogage sera normalement créé dans :
   app/build/outputs/apk/debug/app-debug.apk
8. Transfère cet APK sur le téléphone Android et ouvre-le.
   Si Android demande l'autorisation, autorise l'installation de cette source.

TEST SUR TÉLÉPHONE
- Active les options développeur et le débogage USB seulement si tu utilises USB.
- Le moyen simple est de copier app-debug.apk vers le téléphone et l'ouvrir.
- N'installe que les APK dont tu connais l'origine.

LIMITES DE CETTE VERSION
- Prototype 2D, pas un jeu 3D.
- Pas de publicité, de compte utilisateur, de multijoueur ou d'achats intégrés.
- Avant Google Play : tester sur plusieurs appareils, créer une icône et des captures,
  préparer la fiche de confidentialité si nécessaire, et générer une version signée.
- Google Play peut demander un Android App Bundle (AAB) et impose les exigences
  actuelles de niveau d'API et de compte développeur.

SI TU N'AS QU'UN TÉLÉPHONE ANDROID
Android Studio est destiné à un ordinateur. Il faudra utiliser un ordinateur disponible
ou un environnement de compilation cloud compatible Android/Gradle. Ne saisis jamais
de mot de passe ou de clé de signature dans un service inconnu.
