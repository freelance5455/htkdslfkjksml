CREATIVE STUDIO PRO — ANDROID STUDIO PROJECT
Produced by Mr Biswa

WHAT THIS IS
A starter Android Studio project that opens the included HTML app in an Android WebView.
It is project source code, not a compiled APK.

BUILD AN APK
1. Install Android Studio on a Windows, macOS, or Linux computer.
2. Extract CreativeStudioPro_Android.zip.
3. In Android Studio choose Open, then select the extracted CreativeStudioPro_Android folder.
4. Allow Android Studio to sync Gradle and install the required Android SDK (compile SDK 35).
5. For a test APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When finished, choose Locate in the notification. The APK is normally under app/build/outputs/apk/debug/app-debug.apk.
7. For a release APK, use Build > Generate Signed Bundle / APK and create/securely store a signing key.

NOTES
- This project has not been compiled or tested here; a suitable Android build environment is required.
- The app's booking/payment data is saved in WebView local storage on this device only.
- Cloud database, secure admin authentication, AI API services, verified payment processing, and full video export are not configured.
- WhatsApp opens a prefilled chat; it does not automatically send messages.
- The included payment QR image shows recipient name JHUNI DALEI. Verify recipient details before accepting payments.
