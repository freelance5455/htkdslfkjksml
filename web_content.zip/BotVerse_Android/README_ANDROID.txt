BOTVERSE - PROJETO ANDROID

Este projeto empacota a versão web do BotVerse Pro em um aplicativo Android via WebView.

Para gerar o APK no Android Studio:
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Build > Build APK(s).
4. O APK será gerado em app/build/outputs/apk/debug/app-debug.apk.

Observação: a versão original usa /api/chat para IA. O APK empacota a interface e os recursos locais; para IA real, configure/aponte o backend conforme a documentação da versão Pro.
