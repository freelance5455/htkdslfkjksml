package com.botverse.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;

public class MainActivity extends Activity {
    private WebView web;
    private static final int PICK_IMAGE = 1001;
    private ValueCallback<Uri[]> fileCallback;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                startActivityForResult(i, PICK_IMAGE);
                return true;
            }
        });
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
    public void chooseImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, PICK_IMAGE);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode != RESULT_OK && fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri u = data.getData();
            if (fileCallback != null) { fileCallback.onReceiveValue(u == null ? null : new Uri[]{u}); fileCallback = null; }
            if (u != null) web.evaluateJavascript("window.__androidPickedImage && window.__androidPickedImage(" + quote(u.toString()) + ");", null);
        }
    }
    private String quote(String x) { return "'" + x.replace("\\", "\\\\").replace("'", "\\'") + "'"; }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    public class AndroidBridge {
        @JavascriptInterface public void pickImage() { runOnUiThread(() -> chooseImage()); }
    }
}
