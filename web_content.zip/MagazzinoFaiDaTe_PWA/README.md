# Magazzino Fai da Te — PWA
App web installabile Android, con inventario, ricerca, categorie, quantità, posizione, note, foto, import/export CSV e QR identificativi (generazione QR tramite servizio internet esterno).

## Installazione
Carica tutti i file su un hosting HTTPS (ad esempio GitHub Pages o Netlify). Apri l'indirizzo con Chrome Android e scegli dal menu **Installa app** o **Aggiungi a schermata Home**. Per test locali usa `python -m http.server 8000` e apri `http://localhost:8000`; non aprire index.html direttamente come file.

## Offline e dati
Dopo il primo caricamento il service worker mette in cache l'app. Inventario e foto restano nel localStorage del browser sul dispositivo; non esiste sincronizzazione cloud. Esporta periodicamente il CSV. Le foto non sono incluse nel CSV. La generazione QR richiede internet. La scansione QR con fotocamera non è inclusa in questa versione.


## Mappa delle ubicazioni
La schermata iniziale mostra una tessera per ogni combinazione zona/scaffale/ripiano-cassetto. Tocca una tessera per filtrare e visualizzare gli attrezzi conservati in quella posizione. I vecchi articoli con il solo campo posizione vengono mantenuti e mostrati come zona legacy.
