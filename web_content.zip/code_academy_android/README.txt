CODE ACADEMY — proyecto inicial para Android
=============================================

QUÉ INCLUYE
- Interfaz móvil oscura.
- Cursos iniciales de HTML, CSS, JavaScript y Python.
- Lecciones, preguntas y XP.
- Editor web con vista previa.
- Laboratorio Python mediante Pyodide (requiere internet para cargar el motor la primera vez).
- Progreso guardado localmente en el navegador.
- Archivos base de PWA.

IMPORTANTE
Este proyecto es una primera versión educativa. No incluye cuentas en la nube, sincronización entre dispositivos ni un APK nativo. El editor web ejecuta código en un iframe aislado; aun así, úsalo solo para ejercicios de confianza. No introduzcas tokens, contraseñas ni datos privados.

CÓMO ABRIRLO EN ANDROID
1. Descarga el ZIP en tu teléfono.
2. Usa la app Archivos / Files de Google.
3. Entra a Descargas y toca code_academy_android.zip.
4. Pulsa Extraer o Descomprimir.
5. Guarda la carpeta extraída en Descargas o Documentos.
6. Para probarlo localmente, abre index.html desde un editor como Acode.

NOTA SOBRE INSTALACIÓN COMO APP
Abrir index.html localmente sirve para probar la interfaz, pero PWA y service worker requieren que la web esté alojada mediante HTTPS (o un entorno local compatible). Para instalarla desde Chrome, primero sube los archivos a un hosting HTTPS estático; después abre el enlace en Chrome y usa el menú ⋮ > Añadir a pantalla de inicio / Instalar aplicación. El laboratorio Python necesita internet la primera vez.

NO HAY QUE DESCOMPRIMIRLO EN ANDROID/DATA.
Guarda la carpeta en Descargas o Documentos para evitar problemas de permisos.
