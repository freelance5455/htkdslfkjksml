const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const courses = [
  {id:"html",title:"HTML desde cero",desc:"Construye la estructura de páginas web.",icon:"🌐",tag:"PRINCIPIANTE",lessons:[
    {title:"Tu primera página",time:"5 min",body:"HTML define la estructura de una página. Las etiquetas le dicen al navegador qué mostrar.",code:'<h1>¡Hola, mundo!</h1>\n<p>Estoy aprendiendo HTML.</p>',quiz:"¿Qué etiqueta crea el título principal?",options:["<p>","<h1>","<img>"],answer:1},
    {title:"Textos y enlaces",time:"6 min",body:"Usa <code>&lt;p&gt;</code> para párrafos, <code>&lt;strong&gt;</code> para dar importancia y <code>&lt;a&gt;</code> para crear enlaces.",code:'<h1>Mi sitio</h1>\n<p>Visita mi <strong>página</strong>.</p>\n<a href="https://example.com">Abrir enlace</a>',quiz:"¿Qué etiqueta crea un enlace?",options:["<a>","<h1>","<br>"],answer:0},
    {title:"Imágenes y listas",time:"7 min",body:"Las listas ordenadas usan <code>&lt;ol&gt;</code>, las listas con viñetas usan <code>&lt;ul&gt;</code> y cada elemento va dentro de <code>&lt;li&gt;</code>.",code:'<h2>Mis lenguajes</h2>\n<ul><li>HTML</li><li>CSS</li><li>JavaScript</li></ul>',quiz:"¿Qué etiqueta representa un elemento de lista?",options:["<li>","<title>","<head>"],answer:0}
  ]},
  {id:"css",title:"CSS y diseño web",desc:"Colores, espacios y diseños adaptables.",icon:"🎨",tag:"PRINCIPIANTE",lessons:[
    {title:"Dale estilo a tu página",time:"6 min",body:"CSS cambia la apariencia de HTML. Puedes controlar colores, tamaños, bordes y espaciado.",code:'h1 {\n  color: rebeccapurple;\n  font-size: 32px;\n}\nbody { font-family: sans-serif; }',quiz:"¿Qué propiedad cambia el color del texto?",options:["font-size","color","padding"],answer:1},
    {title:"Espaciado y tarjetas",time:"8 min",body:"<code>padding</code> crea espacio dentro de un elemento y <code>margin</code> crea espacio por fuera.",code:'.card {\n  padding: 20px;\n  margin: 12px;\n  border-radius: 16px;\n  background: #eee;\n}',quiz:"¿Qué propiedad redondea las esquinas?",options:["border-radius","margin","display"],answer:0}
  ]},
  {id:"js",title:"JavaScript interactivo",desc:"Variables, funciones y botones con lógica.",icon:"⚡",tag:"PRINCIPIANTE",lessons:[
    {title:"Variables y mensajes",time:"7 min",body:"JavaScript añade comportamiento a las páginas. Declara variables con <code>const</code> o <code>let</code>.",code:'const nombre = "Alex";\nconsole.log("Hola, " + nombre);',quiz:"¿Qué función muestra un mensaje en la consola?",options:["console.log()","show.text()","print.web()"],answer:0},
    {title:"Funciones",time:"8 min",body:"Una función reúne instrucciones que puedes reutilizar cuando las necesites.",code:'function saludar(nombre) {\n  return "¡Hola, " + nombre + "!";\n}\nconsole.log(saludar("Alex"));',quiz:"¿Qué palabra se usa para declarar una función?",options:["make","function","repeat"],answer:1}
  ]},
  {id:"python",title:"Python práctico",desc:"Aprende la sintaxis y ejecuta tus primeros programas.",icon:"🐍",tag:"PRINCIPIANTE",lessons:[
    {title:"Hola, Python",time:"5 min",body:"<code>print()</code> muestra información. Los textos se escriben entre comillas.",code:'print("¡Hola, mundo!")\nprint("Estoy aprendiendo Python")',quiz:"¿Qué función muestra texto en Python?",options:["console.log()","echo()","print()"],answer:2},
    {title:"Variables y números",time:"7 min",body:"Las variables guardan datos. Python reconoce números, texto y muchos otros tipos de valores.",code:'nombre = "Alex"\nedad = 15\nprint(nombre)\nprint(edad + 1)',quiz:"¿Cómo asignas un valor a una variable?",options:["nombre = valor","nombre == valor","set nombre valor"],answer:0}
  ]}
];

const state = {xp:0, completed:[], courseId:"html", lessonIndex:0, lang:"html"};
const saved = (()=>{try{return JSON.parse(localStorage.getItem("codeAcademyProgress")||"{}")}catch{return {}}})();
state.xp = Number(saved.xp)||0;
state.completed = Array.isArray(saved.completed)?saved.completed:[];
const starter = {
 html:'<h1>¡Hola, mundo!</h1>\\n<p>Esta es mi primera página.</p>\\n<button onclick="alert(\\'¡Funciona!\\')">Haz clic</button>',
 css:'body { font-family: Arial, sans-serif; padding: 24px; background: #f4f0ff; }\\nh1 { color: #6d28d9; }\\nbutton { padding: 10px 14px; border: 0; border-radius: 9px; background: #7c3aed; color: white; }',
 js:'document.body.innerHTML = "<h1>¡JavaScript funciona!</h1><p>Ya puedes crear páginas interactivas.</p>";'
};
const defaults = {
 html:'<h1>¡Hola, mundo!</h1>\n<p>Esta es mi primera página.</p>\n<button onclick="alert(\\'¡Funciona!\\')">Haz clic</button>',
 css:'body { font-family: Arial, sans-serif; padding: 24px; background: #f4f0ff; }\nh1 { color: #6d28d9; }\nbutton { padding: 10px 14px; border: 0; border-radius: 9px; background: #7c3aed; color: white; }',
 js:'document.body.innerHTML = "<h1>¡JavaScript funciona!</h1><p>Ya puedes crear páginas interactivas.</p>";'
};
let code = {...defaults};

function save(){localStorage.setItem("codeAcademyProgress",JSON.stringify({xp:state.xp,completed:state.completed}));}
function courseProgress(c){return c.lessons.filter((_,i)=>state.completed.includes(`${c.id}:${i}`)).length;}
function totalLessons(){return courses.reduce((n,c)=>n+c.lessons.length,0);}
function renderCourses(target){
  $(target).innerHTML=courses.map(c=>{const done=courseProgress(c),pct=Math.round(done/c.lessons.length*100);return `<article class="course-card" data-course="${c.id}"><div class="course-icon">${c.icon}</div><div class="course-info"><h3>${c.title}</h3><p>${c.desc}</p><div class="course-meta"><span>${c.lessons.length} lecciones</span><span>·</span><span>${done} completadas</span></div><div class="mini-progress"><span style="width:${pct}%"></span></div></div><span class="course-arrow">›</span></article>`}).join("");
  $$(target+" [data-course]").forEach(el=>el.addEventListener("click",()=>openCourse(el.dataset.course)));
}
function updateProgress(){
  $("#xpValue").textContent=state.xp+" XP";$("#profileXp").textContent=state.xp+" XP";
  $("#doneValue").textContent=state.completed.length;$("#profileDone").textContent=state.completed.length;
  $("#profilePercent").textContent=Math.round(state.completed.length/totalLessons()*100)+"%";
  $("#completedList").innerHTML=state.completed.length?state.completed.map(key=>{const [cid,li]=key.split(":");const c=courses.find(x=>x.id===cid);return c?`<div class="completed-item"><span>✓</span><div>${c.title} — ${c.lessons[Number(li)]?.title||"Lección"}</div></div>`:""}).join(""):'<div class="empty-state">Todavía no has terminado lecciones. ¡Elige un curso para comenzar!</div>';
  save();renderCourses("#homeCourses");renderCourses("#allCourses");
}
function go(page){
  $$(".page").forEach(p=>p.classList.toggle("active",p.id===page));
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.go===page));
  window.scrollTo({top:0,behavior:"smooth"});
}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),2300);}
function openCourse(id){
  state.courseId=id;const c=courses.find(x=>x.id===id);if(!c)return;
  $("#lessonContent").innerHTML=`<div class="lesson-hero"><span class="eyebrow">${c.tag} · ${c.lessons.length} LECCIONES</span><h1>${c.icon} ${c.title}</h1><p>${c.desc} Selecciona una lección para comenzar.</p></div>`+
  c.lessons.map((l,i)=>`<article class="course-card" data-lesson="${i}"><div class="course-icon">${state.completed.includes(`${c.id}:${i}`)?"✓":String(i+1).padStart(2,"0")}</div><div class="course-info"><h3>${l.title}</h3><p>${l.time} · ${state.completed.includes(`${c.id}:${i}`)?"Completada":"Lección práctica"}</p></div><span class="course-arrow">›</span></article>`).join("");
  $$("#lessonContent [data-lesson]").forEach(el=>el.addEventListener("click",()=>openLesson(Number(el.dataset.lesson))));
  go("lesson");
}
function openLesson(index){
  state.lessonIndex=index;const c=courses.find(x=>x.id===state.courseId),l=c.lessons[index],key=`${c.id}:${index}`,done=state.completed.includes(key);
  $("#lessonContent").innerHTML=`<button class="back-btn" id="lessonBack">← Todas las lecciones</button><div class="lesson-hero"><span class="eyebrow">${c.title.toUpperCase()} · LECCIÓN ${index+1}</span><h1>${l.title}</h1><p>${l.time} de lectura y práctica</p></div><section class="lesson-block"><h2>📘 Aprende</h2><p>${l.body}</p><p>Observa este ejemplo y fíjate en cómo está escrito. Después puedes modificarlo en el laboratorio.</p><pre class="code-sample">${escapeHTML(l.code)}</pre><button class="primary lesson-action" id="tryCode">Probar en el laboratorio →</button></section><section class="lesson-block"><h2>🧠 Comprueba lo aprendido</h2><p>${l.quiz}</p><div id="quizOptions">${l.options.map((o,i)=>`<button class="quiz-option" data-answer="${i}">${escapeHTML(o)}</button>`).join("")}</div><p id="quizFeedback" class="muted"></p></section><button class="primary lesson-action" id="completeLesson">${done?"✓ Lección completada":"Marcar lección como completada · +20 XP"}</button>`;
  $("#lessonBack").onclick=()=>openCourse(c.id);
  $("#tryCode").onclick=()=>{go("lab");if(c.id==="python"){ $("#pythonEditor").value=l.code; }else{state.lang=c.id==="css"?"css":c.id==="js"?"js":"html";code[state.lang]=l.code;setLang(state.lang);}};
  $$("#quizOptions [data-answer]").forEach(btn=>btn.onclick=()=>{const correct=Number(btn.dataset.answer)===l.answer;$$("#quizOptions button").forEach(b=>{b.disabled=true;if(Number(b.dataset.answer)===l.answer)b.classList.add("correct")});if(!correct)btn.classList.add("wrong");$("#quizFeedback").textContent=correct?"¡Correcto! Sigue así.":"No pasa nada: revisa la lección y vuelve a intentarlo.";if(correct)toast("¡Respuesta correcta!");});
  $("#completeLesson").onclick=()=>{if(!state.completed.includes(key)){state.completed.push(key);state.xp+=20;updateProgress();toast("¡Lección completada! +20 XP");}else toast("Esta lección ya está completada.");openCourse(c.id);};
}
function escapeHTML(s){return s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");}
function setLang(lang){
  state.lang=lang;$$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.lang===lang));$("#codeEditor").value=code[lang];$("#editorStatus").textContent="Editando "+lang.toUpperCase();
}
function runWeb(){
  code[state.lang]=$("#codeEditor").value;
  const html=state.lang==="html"?code.html:state.lang==="css"?"<h1>Vista previa CSS</h1><p>Cambia los estilos y ejecuta otra vez.</p>":"<h1>Vista previa JavaScript</h1><p>Abre la consola del navegador para ver resultados.</p>";
  const css=state.lang==="css"?code.css:code.css;
  const js=state.lang==="js"?code.js:"";
  const safeDoc=`<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body>${html}<script>${js.replace(/<\/script/gi,"<\\/script")}<\/script></body></html>`;
  $("#preview").srcdoc=safeDoc;$("#editorStatus").textContent="Ejecutado · vista previa actualizada";
}
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$$(".tab").forEach(b=>b.addEventListener("click",()=>setLang(b.dataset.lang)));
$("#runWeb").addEventListener("click",runWeb);
$("#resetCode").addEventListener("click",()=>{code={...defaults};setLang(state.lang);$("#editorStatus").textContent="Código restablecido";});
$("#themeBtn").addEventListener("click",()=>{document.body.classList.toggle("light");localStorage.setItem("codeAcademyLight",document.body.classList.contains("light")?"1":"0");});
if(localStorage.getItem("codeAcademyLight")==="1")document.body.classList.add("light");
$("#clearProgress").addEventListener("click",()=>{if(confirm("¿Seguro que quieres borrar todo tu progreso?")){state.xp=0;state.completed=[];updateProgress();toast("Progreso borrado");}});
let pyodidePromise=null;
$("#runPython").addEventListener("click",async()=>{
  const btn=$("#runPython"),out=$("#pythonOutput");btn.disabled=true;out.textContent="Preparando Python…";$("#pythonStatus").textContent="Cargando motor de Python";
  try{
    if(!pyodidePromise){pyodidePromise=(async()=>{const s=document.createElement("script");s.src="https://cdn.jsdelivr.net/pyodide/v0.27.7/full/pyodide.js";document.head.appendChild(s);await new Promise((resolve,reject)=>{s.onload=resolve;s.onerror=()=>reject(new Error("No se pudo descargar Python. Comprueba tu conexión."));});return await loadPyodide();})(); }
    const py=await pyodidePromise;let output="";py.setStdout({batched:(s)=>{output+=s;}});py.setStderr({batched:(s)=>{output+=s;}});await py.runPythonAsync($("#pythonEditor").value);out.textContent=output||"(El programa terminó sin mostrar texto.)";$("#pythonStatus").textContent="Ejecución terminada";
  }catch(e){out.textContent=String(e);$("#pythonStatus").textContent="No se pudo ejecutar";}
  finally{btn.disabled=false;}
});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
updateProgress();setLang("html");runWeb();
