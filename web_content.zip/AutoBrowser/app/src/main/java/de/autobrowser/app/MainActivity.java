package de.autobrowser.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.util.Base64;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private android.content.SharedPreferences prefs;
    private boolean dark;
    private LinearLayout root, favoritesBox;
    private EditText address;
    private final ArrayList<String[]> favorites = new ArrayList<>();
    private int bg, panel, fg, muted, accent, field;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("autobrowser", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", false);
        loadFavorites();
        render();
    }

    private void colors() {
        bg = Color.parseColor(dark ? "#10141D" : "#F3F6FB");
        panel = Color.parseColor(dark ? "#1B2330" : "#FFFFFF");
        fg = Color.parseColor(dark ? "#F4F7FC" : "#172033");
        muted = Color.parseColor(dark ? "#AAB5C5" : "#667085");
        accent = Color.parseColor("#2878E5");
        field = Color.parseColor(dark ? "#273244" : "#EEF2F8");
    }

    private void render() {
        colors();
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20), dp(18), dp(20), dp(20)); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); setContentView(root);

        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("AutoBrowser", 27, true, fg); brand.addView(title);
        TextView subtitle = text("Dein Schnellzugriff auf Chrome", 13, false, muted); brand.addView(subtitle);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        Button theme = button(dark ? "☀ Hell" : "☾ Dunkel", false); theme.setOnClickListener(v -> { dark = !dark; prefs.edit().putBoolean("dark", dark).apply(); render(); }); header.addView(theme);
        content.addView(header); space(content, 24);

        TextView label = text("WEBSEITE ODER SUCHBEGRIFF", 12, true, muted); content.addView(label); space(content, 8);
        address = new EditText(this); address.setSingleLine(true); address.setTextSize(16); address.setTextColor(fg); address.setHintTextColor(muted); address.setHint("z. B. https://www.google.de"); address.setPadding(dp(15), dp(13), dp(15), dp(13)); address.setBackground(round(field, 14)); address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setOnEditorActionListener((v, action, event) -> { if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_SEARCH) { openInput(); return true; } return false; });
        content.addView(address, new LinearLayout.LayoutParams(-1, dp(54))); space(content, 12);
        Button search = button("Mit Chrome suchen / öffnen", true); search.setOnClickListener(v -> openInput()); content.addView(search, new LinearLayout.LayoutParams(-1, dp(52))); space(content, 10);
        Button google = button("Google öffnen", false); google.setOnClickListener(v -> openChrome("https://www.google.com")); content.addView(google, new LinearLayout.LayoutParams(-1, dp(48))); space(content, 26);

        LinearLayout favHeader = new LinearLayout(this); favHeader.setGravity(Gravity.CENTER_VERTICAL);
        favHeader.addView(text("Meine Favoriten", 19, true, fg), new LinearLayout.LayoutParams(0, -2, 1));
        Button add = button("＋ Hinzufügen", false); add.setOnClickListener(v -> addFavorite()); favHeader.addView(add); content.addView(favHeader); space(content, 10);
        favoritesBox = new LinearLayout(this); favoritesBox.setOrientation(LinearLayout.VERTICAL); content.addView(favoritesBox); drawFavorites();
        space(content, 20);
        TextView foot = text("AutoBrowser öffnet Webseiten in Google Chrome. Favoriten werden lokal auf diesem Gerät gespeichert.", 12, false, muted); content.addView(foot);
    }

    private void drawFavorites() {
        favoritesBox.removeAllViews();
        if (favorites.isEmpty()) { TextView empty = text("Noch keine Favoriten. Tippe auf „Hinzufügen“, um eine Webseite zu speichern.", 14, false, muted); empty.setPadding(dp(15), dp(18), dp(15), dp(18)); empty.setBackground(round(panel, 14)); favoritesBox.addView(empty); return; }
        for (int i = 0; i < favorites.size(); i++) {
            final int index = i; String[] item = favorites.get(i);
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(14), dp(11), dp(8), dp(11)); row.setBackground(round(panel, 14));
            LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
            info.addView(text(item[0], 15, true, fg)); info.addView(text(item[1], 11, false, muted));
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
            Button go = smallButton("Öffnen"); go.setOnClickListener(v -> openChrome(item[1])); row.addView(go);
            Button del = smallButton("✕"); del.setOnClickListener(v -> { favorites.remove(index); saveFavorites(); drawFavorites(); }); row.addView(del);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8); favoritesBox.addView(row, lp);
        }
    }

    private void openInput() {
        String raw = address.getText().toString().trim(); if (raw.isEmpty()) return;
        String url;
        if (raw.matches("(?i)^[a-z][a-z0-9+.-]*://.*")) url = raw;
        else if (raw.contains(".") && !raw.contains(" ")) url = "https://" + raw;
        else { try { url = "https://www.google.com/search?q=" + URLEncoder.encode(raw, "UTF-8"); } catch (Exception e) { url = "https://www.google.com"; } }
        openChrome(url);
    }

    private void openChrome(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setPackage("com.android.chrome");
            startActivity(intent);
        } catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            catch (Exception ignored) { Toast.makeText(this, "Kein Browser gefunden.", Toast.LENGTH_LONG).show(); }
        }
    }

    private void addFavorite() {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(4), dp(4), dp(4), dp(4));
        EditText name = new EditText(this); name.setHint("Name, z. B. YouTube"); form.addView(name);
        EditText url = new EditText(this); url.setHint("Adresse, z. B. https://youtube.com"); url.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI); form.addView(url);
        new AlertDialog.Builder(this).setTitle("Favorit hinzufügen").setView(form).setNegativeButton("Abbrechen", null).setPositiveButton("Speichern", (d, w) -> {
            String n = name.getText().toString().trim(), u = url.getText().toString().trim();
            if (u.isEmpty()) { Toast.makeText(this, "Bitte eine Webadresse eingeben.", Toast.LENGTH_SHORT).show(); return; }
            if (!u.matches("(?i)^[a-z][a-z0-9+.-]*://.*")) u = "https://" + u;
            if (n.isEmpty()) n = u;
            favorites.add(new String[]{n, u}); saveFavorites(); drawFavorites();
        }).show();
    }

    private void loadFavorites() {
        String data = prefs.getString("favorites", ""); if (data.isEmpty()) return;
        for (String line : data.split("\\n")) { String[] p = line.split("\\|", 2); if (p.length == 2) try { favorites.add(new String[]{new String(Base64.decode(p[0], Base64.DEFAULT), StandardCharsets.UTF_8), new String(Base64.decode(p[1], Base64.DEFAULT), StandardCharsets.UTF_8)}); } catch (Exception ignored) {} }
    }
    private void saveFavorites() {
        StringBuilder b = new StringBuilder(); for (String[] f : favorites) b.append(Base64.encodeToString(f[0].getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP)).append('|').append(Base64.encodeToString(f[1].getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP)).append('\n');
        prefs.edit().putString("favorites", b.toString()).apply();
    }

    private TextView text(String s, int size, boolean bold, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private Button button(String s, boolean primary) { Button b = new Button(this); b.setText(s); b.setTextSize(14); b.setAllCaps(false); b.setTextColor(primary ? Color.WHITE : fg); b.setBackground(round(primary ? accent : panel, 13)); return b; }
    private Button smallButton(String s) { Button b = button(s, false); b.setTextSize(12); b.setMinWidth(dp(48)); b.setPadding(dp(6), 0, dp(6), 0); return b; }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private void space(LinearLayout box, int h) { View v = new View(this); box.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
