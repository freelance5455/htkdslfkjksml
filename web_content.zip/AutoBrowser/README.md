# AutoBrowser

AutoBrowser ist eine kleine Android-Startoberfläche für Google Chrome. Enthalten sind Hell-/Dunkelmodus, Google-Suche, Chrome-Start und lokal gespeicherte Favoriten.

## Dateien
- `index.html`: eigenständige HTML-Version, z. B. als Eingabe für einen HTML-zu-APK-Wrapper.
- `app/src/main/assets/index.html`: Kopie der HTML-Datei im Android-Projekt.
- `app/`: natives Android-Studio-Projekt. Die native App verwendet Android-Oberflächenelemente und startet Chrome für Webseiten.

## Android-APK bauen
1. Android Studio installieren.
2. Den Ordner `AutoBrowser` in Android Studio öffnen.
3. Gradle-Synchronisierung abwarten (Android SDK 35 erforderlich).
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)** wählen.
5. Die APK liegt anschließend unter `app/build/outputs/apk/debug/app-debug.apk`.

Für eine eigene Release-Signatur: **Build → Generate Signed Bundle / APK** wählen und einen eigenen Keystore erstellen. Keystore und Passwörter sicher aufbewahren.

## HTML in eine APK umwandeln
Die Datei `index.html` ist eine eigenständige Web-Oberfläche und kann in einen HTML-zu-APK-Wrapper bzw. ein WebView-Projekt übernommen werden. Dabei muss der Wrapper lokale Dateien und JavaScript unterstützen. Webseiten werden über normale externe Links geöffnet; Android öffnet dafür den Standardbrowser (Chrome, wenn als Standardbrowser eingerichtet). Favoriten und Design-Einstellung werden im lokalen Browser-Speicher abgelegt.

## Einschränkung Android Auto
Dies ist keine Android-Auto-Freigabe. Android Auto erlaubt keine beliebige Browser-Oberfläche im Fahrzeugdisplay. Die App ist für die Nutzung auf dem Smartphone gedacht.
