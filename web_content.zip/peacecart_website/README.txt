PEACECART WEBSITE STARTER

Files:
- index.html: single-page responsive storefront preview.

How to use on Android:
1. Download and extract peacecart_website.zip.
2. The HTML file is a static website. To publish it, use a static hosting service you trust or copy the page sections into Google Sites.
3. Google Sites does not directly import a full HTML website as an editable site. If you use Google Sites, copy the text and recreate the sections/pages manually.
4. This is a catalogue preview only. No checkout, payment collection, order form, login, or personal-data collection is implemented.
5. Replace suggested product prices and descriptions with accurate details before offering anything for sale.
6. Add only verified contact information and an accurate privacy/returns policy before launch.

Security notes:
- The page uses no external JavaScript libraries, trackers, remote fonts, or third-party scripts.
- No website can be guaranteed completely bug-free or virus-proof in every environment. Review the files and hosting service before publishing.
- Keep your Google account secure and do not publish passwords, OTPs, bank PINs, or private information.
