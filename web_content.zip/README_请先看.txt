工地希伯来语 2000 条 · Android 原生语音修复版

修复点：不再仅依赖 WebView 不支持的 speechSynthesis；新增 Android TextToSpeech 原生桥接。

注意：本 ZIP 是 Android 原生项目源码，不是 APK；不能直接上传到仅支持 HTML ZIP 的 Zip to APK 网页打包器，否则无法编译原生 Java 代码。

需使用 AndroidIDE（手机端）或 Android Studio（电脑端）打开此 Gradle 项目并构建 APK。
手机需要安装支持 he-IL 的希伯来语 TTS 引擎/语音数据。

数据沿用上一版 2000 条，内容尚未全部经过人工语言审核，安全指令不要作为现场唯一依据。
