SHADOW EXECUTOR — FLOATING UI WEB PACKAGE

Contents: index.html

Features:
- Xeno-inspired dark purple visual style
- Small floating S icon that expands/minimizes a draggable workspace window
- Luau text editor
- Saved scripts in localStorage
- Safe preview console (only simple print("text") lines are previewed)
- No Roblox connection, live-game injection, or exploit functionality

Free Android-only packaging idea:
1. Extract this ZIP on your Android device using its file manager.
2. Use a reputable online HTML-to-APK builder that accepts an HTML file or ZIP.
3. Upload index.html (or the ZIP if the builder accepts ZIP packages), set app name to Shadow Executor, and generate the APK.
4. Review requested permissions; this app needs no special permissions for its basic features.
5. Test saving/reopening scripts before relying on it. Storage may be cleared if app data is cleared or the app is uninstalled.

This is a web app source package, not a compiled APK. The preview does not run arbitrary Luau or interact with Roblox.
