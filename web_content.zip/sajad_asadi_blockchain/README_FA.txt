SAJAD ASADI BLOCKCHAIN LAB - نسخه 1.0

این بسته یک وب‌اپلیکیشن قابل نصب (PWA) است، نه APK مستقل.

برای استفاده:
1) پوشه را روی یک هاست HTTPS استاتیک آپلود کنید.
2) لینک index.html را در Chrome اندروید باز کنید.
3) از منوی سه‌نقطه Chrome گزینه Install app یا Add to Home screen را بزنید.

امکانات:
- هدایت جست‌وجوی TXID و آدرس عمومی به اکسپلوررهای Ethereum، BNB Smart Chain و TRON.
- لینک مستقیم به Etherscan، BscScan و Tronscan.
- راهنمای امنیتی.

محدودیت:
این نسخه هنوز API اختصاصی، تحلیل خودکار ریسک، اعلان یا کیف پول ندارد.
برای تبدیل به APK واقعی، باید پروژه در محیط Android/Capacitor یا Android Studio بسته‌بندی و امضا شود.
هرگز عبارت بازیابی یا کلید خصوصی را وارد نکنید.
