MCS LAGERWEB-APP – einfache Anleitung

DATEIEN
- index.html: die Web-App
- manifest.webmanifest und sw.js: Installation als Web-App (PWA)

SO NUTZT DU SIE
1. Die App muss über eine HTTPS-Adresse geöffnet werden, damit der Kamerascanner im Handy-Browser funktioniert. Eine lokale HTML-Datei kann die Kamera blockieren.
2. Öffne die HTTPS-Adresse auf dem Samsung in Google Chrome.
3. Chrome-Menü (drei Punkte) -> „Zum Startbildschirm hinzufügen“ oder „App installieren“.
4. Die App speichert Daten lokal im Browser auf genau diesem Gerät.
5. Unter Übersicht regelmäßig „Sicherung exportieren“ drücken. JSON-Sicherung sicher aufbewahren.
6. Zum Wiederherstellen „Sicherung importieren“ verwenden.

SCANNEN
- Kamera starten, Kamerazugriff erlauben, Barcode in die Kamera halten.
- Falls der Browser BarcodeDetector nicht unterstützt, IMEI manuell eintippen.
- Erstes Erfassen: Gerät kommt ins Lager.
- Erneutes Erfassen einer IMEI, die noch im Lager liegt: Gerät wird als verkauft markiert.
- Eine bereits verkaufte IMEI wird nicht automatisch wieder aufgenommen.
- Ein Verkauf kann auch in der Lagerliste per „Als verkauft markieren“ erfasst werden.

WICHTIG
- Daten sind lokal auf dem Gerät und werden nicht automatisch zwischen mehreren Handys synchronisiert.
- Regelmäßig Sicherungen exportieren. Browserdaten nicht löschen, bevor eine Sicherung erstellt wurde.
- Für Kamera ist HTTPS erforderlich; eine normale Datei vom PC reicht dafür in der Regel nicht.
