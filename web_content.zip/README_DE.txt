SCHACH ANALYSE – ANDROID-STUDIO-PROJEKT

Was enthalten ist:
- Ein vollständiges, einfaches Android-Studio-Projekt.
- Die App öffnet das Analysewerkzeug direkt in einer Android-WebView.
- Internetzugriff wird für die Lichess Cloud-Evaluation benötigt.

WICHTIG:
- Dies ist eine separate Analyse-App, kein Overlay über Chess.com.
- Die App erkennt keine Schachstellung automatisch vom Bildschirm.
- Sie enthält keine lokal eingebundene Stockfish-Engine.
- Sie kann nur Stellungen analysieren, für die Lichess eine Cloud-Analyse bereitstellt.

APK erstellen:
1. ZIP entpacken.
2. Android Studio installieren und starten.
3. "Open" wählen und den entpackten Ordner "SchachAnalyseAndroid" öffnen.
4. Warten, bis Gradle-Synchronisierung abgeschlossen ist.
5. Falls Android Studio ein Android SDK installieren möchte, den Vorschlägen folgen.
6. Menü Build > Build Bundle(s) / APK(s) > Build APK(s) auswählen.
7. Nach erfolgreichem Build auf "locate" klicken. Die APK liegt normalerweise unter:
   app/build/outputs/apk/debug/app-debug.apk
8. APK auf das Samsung-Handy übertragen und installieren. Android kann vorher die Erlaubnis
   zum Installieren unbekannter Apps verlangen.

Voraussetzungen:
- Android Studio auf einem Computer (Windows, macOS oder Linux).
- Internetverbindung für Gradle/SDK-Download und für Cloud-Analysen.

Das Projekt wurde als Quellprojekt vorbereitet; eine fertige APK wird hier nicht mitgeliefert.
