PEUGEOT 208 DASHBOARD – WEB-APP

INHALT: index.html, manifest.webmanifest, sw.js und App-Icons.

SO INSTALLIERST DU SIE:
Eine installierbare Web-App benötigt eine HTTPS-Adresse. Die ZIP-Datei enthält alle App-Dateien, ist aber selbst keine APK.
1. ZIP auf dem Nothing Phone entpacken.
2. Den gesamten Inhalt zu einem kostenlosen statischen HTTPS-Host hochladen (z. B. GitHub Pages; Konto nötig).
3. Die veröffentlichte HTTPS-Adresse in Chrome öffnen.
4. Chrome-Menü ⋮ > „App installieren“ oder „Zum Startbildschirm hinzufügen“.

Du kannst index.html auch direkt im Browser öffnen, um sie zu testen; PWA-Installation und GPS funktionieren lokal eventuell eingeschränkt.

FUNKTIONEN:
- Fahrten erfassen und Kilometerstand erhöhen
- Tankvorgänge und Volltank-Einträge speichern
- Verbrauch aus Volltank-Daten schätzen
- geschätzten Tankinhalt und Reichweite anzeigen
- Standort nur auf Knopfdruck speichern, Google-Maps-Link
- Verlauf sowie JSON-Backup exportieren/importieren

DATENSCHUTZ: Daten werden lokal im Browser gespeichert. Exportiere Backups regelmäßig. Das Löschen von Browserdaten kann lokale App-Daten entfernen. Kilometerstand wird nicht automatisch vom Fahrzeug ausgelesen; Tankinhalt/Reichweite sind Schätzungen.
