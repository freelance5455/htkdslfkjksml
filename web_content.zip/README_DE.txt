LERNWERK – erweitertes APK-Baupaket
=====================================

INHALT
- HTMLtoAPK/index.html: Offline-HTML-Version für einen HTML-to-APK-Konverter.
- Android-Projekt/: natives Android-WebView-Projekt mit Android-Druckdialog und Teilen/Speichern über das Android-Teilen-Menü.
- .github/workflows/build-apk.yml: GitHub Actions Build-Workflow.

FUNKTIONEN
- Klassenstufen 1.–2. bis 13. Klasse, Berufsschule, Erwachsenenbildung und klassenübergreifende Lerngruppen.
- Freies Fach- und Themenfeld.
- Auswahl von Aufgabenformaten und Sozialformen/Methoden.
- Mehrere Gestaltungsstile, Dokumenttypen, Umfang und didaktische Ansätze.
- Differenzierung, Hilfen, Punkte, Lösungsblatt/Erwartungshorizont.
- Offline-Vorlagengenerator, Vorschau und Einstellungen lokal merken.
- Druckfunktion: im nativen Android-Projekt über Android PrintManager.
- Text/HTML/Lösungen: Teilen-Menü in der Android-App; im Browser Download.
- NEU: „KI-Auftrag teilen“ erstellt einen detaillierten Prompt für eine externe KI-App.

WICHTIGE GRENZEN
- Diese ZIP enthält KEINE integrierte echte KI und KEINEN KI-API-Schlüssel. Die Arbeitsblätter selbst werden offline anhand von Vorlagen erzeugt. Für echte KI-Erstellung den Button „KI-Auftrag teilen“ verwenden und den Prompt an eine KI-App senden; dazu ist meist Internet und ein KI-Dienst/Konto nötig.
- Die Musterlösungen der Offline-Vorlagen sind teils allgemeine Erwartungshinweise und nicht immer fachlich konkrete Lösungen. Bitte vor Unterrichtseinsatz prüfen.
- Druck und Dateifreigabe sind im Android-Projekt implementiert, konnten hier aber nicht auf einem realen Android-Gerät getestet werden.
- Ein einfacher HTML-to-APK-Konverter kann Android-spezifische Druck-/Teilen-Funktionen ignorieren. Für diese Funktionen möglichst den Ordner „Android-Projekt“ als Android-Projekt bauen (z. B. über den beigefügten GitHub Actions Workflow).
- Diese Version kann nicht garantieren, dass sie pixelgenau mit nicht vorliegenden Referenzbildern übereinstimmt.

WAS IST DIE RICHTIGE DATEI?
Wenn dein Konverter eine HTML-Datei verlangt: HTMLtoAPK/index.html verwenden.
Wenn du den nativen Druckdialog und das Android-Teilen-Menü benötigst: Android-Projekt verwenden, nicht nur die einzelne HTML-Datei.

PRÜFUNG
- JavaScript-Syntax mit Node.js geprüft.
- HTML-Datei im ZIP und Android-Projekt-Asset synchronisiert.
- Keine APK wurde hier gebaut oder auf einem Android-Gerät getestet.
