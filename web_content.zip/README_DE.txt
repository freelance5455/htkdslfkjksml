MINI-GAME ANDROID-APP-PROJEKT
==============================

Wichtig: Dies ist ein Android-Studio-Projekt, noch keine installierbare APK-Datei.
Ich kann die App nicht direkt auf deinem Handy installieren oder hier eine fertige,
auf deinem Gerät getestete APK garantieren.

So wird daraus eine APK:
1. Ein Erwachsener/Entwickler installiert Android Studio auf einem Computer.
2. Android Studio: „Open“ wählen und den entpackten Ordner MiniGameHandy öffnen.
3. Warten, bis Gradle fertig synchronisiert hat.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) auswählen.
5. Die erzeugte APK muss auf das Android-Handy übertragen und dort bewusst installiert
   werden. Android kann vor Apps außerhalb des Play Stores warnen.

Internet:
Das Spiel lädt die Three.js-3D-Bibliothek von einem CDN und benötigt daher Internet.

Steuerung:
- Linker virtueller Stick: laufen
- Rechts über den Bildschirm ziehen: umsehen
- JUMP: springen

Dies ist eine einfache Demo, kein vollständiges Roblox-Spiel. Der Code ist ein
Startprojekt und sollte vor einer Veröffentlichung auf Geräten getestet werden.
