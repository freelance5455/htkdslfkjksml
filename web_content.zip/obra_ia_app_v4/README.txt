OBRA IA v15 - Tareo en una sola lista

CAMBIOS EN ESTA VERSION:
- Tareo en una sola lista, sin tarjetas individuales por trabajador.
- Cada trabajador muestra nombre, asistencia ✓ / X, hora de ingreso, refrigerio ✓ / X, hora de salida, horas del día y total semanal.
- Refrigerio ✓ descuenta 1 hora; refrigerio X significa que trabajó corrido y no descuenta esa hora.
- Las horas del día se calculan automáticamente con ingreso y salida.
- El total semanal suma las horas registradas de lunes a domingo.
- Sin columnas de cargo ni partida.
- Se conserva el resto de módulos de OBRA IA de la versión anterior.

CÓMO USAR:
1. Descomprime el ZIP.
2. Abre obra_ia_app_v4/index.html en Chrome.
3. Entra a Tareo.
4. Marca ✓ Asistió o X Falta. Si asistió, registra ingreso y salida; marca ✓ si tomó refrigerio o X si trabajó corrido.
5. Los cambios se guardan automáticamente en el almacenamiento local del navegador.

IMPORTANTE:
- Antes de reemplazar una versión anterior, exporta tus datos desde Configuración como respaldo.
- La app guarda los datos en este dispositivo/navegador; no sincroniza automáticamente entre dispositivos.
- Si la instalaste previamente como aplicación, cierra y vuelve a abrirla para cargar la actualización.
