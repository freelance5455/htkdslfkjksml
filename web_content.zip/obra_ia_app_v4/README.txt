OBRA IA - versión 7 (duraciones, horarios y voz mejorada)

CÓMO ABRIR
1. Extrae todo el ZIP en una carpeta.
2. Abre index.html con Chrome actualizado en Android o en una computadora.
3. En “Actividades”, edita cada actividad y define duración estimada y hora más temprana de inicio.
4. En “IA / Distribución”, pulsa “Generar / Regenerar distribución”.
5. La distribución muestra hora de inicio y fin. Una misma persona puede pasar a otra actividad si sus horarios no se cruzan.
6. Pulsa “Editar personal directamente” para cambiar, quitar o agregar trabajadores. Los cambios manuales se guardan automáticamente.

COMANDOS POR VOZ DE EJEMPLO
- “Picado piso 6 frente 2 dura 2 horas”.
- “Habilitado empieza a las 10:00”.
- “Pasa Gustavo a Habilitado”.
- “Gustavo es rápido para picado”.
- “Agrega actividad vaciado de contrapiso”.

MICRÓFONO
- En la pantalla “Voz”, pulsa “Probar micrófono” y luego “Empezar a hablar”. Acepta el permiso cuando Android lo solicite.
- El reconocimiento de voz depende de que el navegador y el entorno lo permitan. Si la app se abre dentro de una vista previa de archivos o como archivo local y el micrófono no funciona, abre la app desde Chrome actualizado mediante una dirección HTTPS. Revisa también Ajustes de Android > Aplicaciones > Chrome > Permisos > Micrófono.
- El reconocimiento de voz web puede requerir conexión a Internet.

DATOS Y RESPALDO
- No necesitas usar pulgar arriba/abajo para cambiar una asignación.
- Se conserva la clave de almacenamiento local de versiones anteriores para ayudar a mantener los datos en el mismo navegador/origen. El almacenamiento local no se comparte necesariamente entre diferentes rutas, navegadores o modos de apertura.
- Antes de reemplazar una versión, entra en Configuración > Exportar todo a JSON y guarda el respaldo.
- Esta es una aplicación web local/PWA, no un APK instalado desde Play Store.
