OBRA IA - versión avanzada v6 (edición directa de distribución)

CÓMO ABRIR
1. Extrae todo el ZIP en una carpeta.
2. Abre index.html con Chrome en Android o en una computadora.
3. Entra a “IA / Distribución”.
4. Pulsa “Generar / Regenerar distribución”.
5. Pulsa “Editar personal directamente”.
6. En cada actividad podrás cambiar el trabajador con la lista, quitarlo o agregar otro trabajador libre. Los cambios se guardan automáticamente en el almacenamiento local del navegador.

IMPORTANTE
- No necesitas usar los botones de pulgar arriba/abajo para corregir una asignación.
- Los trabajadores no se pueden asignar dos veces a distintas actividades en la misma distribución; si está asignado en otra actividad, primero quítalo de allí.
- La aplicación es una aplicación web local/PWA, no un APK instalado desde Play Store.
- Los datos permanecen en el almacenamiento del navegador de ese dispositivo. Usa Configuración > Exportar todo a JSON para hacer respaldo antes de cambiar de navegador, borrar datos o reinstalar.
- Si ya usabas una versión anterior en el mismo navegador, los datos se mantienen porque se conserva la clave de almacenamiento.
