#!/system/bin/sh
# C10_transition_animation_scale — transition animation scale
# Cut transition animation scale to 0.5.
MODULE_ID="C10_transition_animation_scale"
. "$(dirname "$0")/../lib/core.sh"
vcg_init
apply() {
    vcg_apply_or_skip C10_ENABLED || return 0
    vcg_put global transition_animation_scale 0.5
}
revert() {
    vcg_restore_setting global transition_animation_scale
}
case "${1:-apply}" in apply) apply ;; revert) revert ;; *) exit 1 ;; esac
