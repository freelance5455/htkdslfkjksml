from flask import Flask, request, jsonify, render_template
from web3 import Web3
import sqlite3
import datetime
import os

# --- CONFIGURATION ---
# Replace these with your actual details for Mainnet/BSC
RPC_URL = 'https://eth.llamarpc.com' # Example public RPC
PRIVATE_KEY = 'YOUR_PRIVATE_KEY_HERE' 
TREASURY_ADDRESS = 'YOUR_TREASURY_WALLET_ADDRESS' 

# For demonstration purposes, we use a mock mode if no key is provided
MOCK_MODE = PRIVATE_KEY == 'YOUR_PRIVATE_KEY_HERE'

app = Flask(__name__, template_folder='.')

# Initialize Database
def init_db():
    conn = sqlite3.connect('flash_tether.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS claims 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  wallet TEXT, 
                  date TEXT, 
                  amount REAL)''')
    conn.commit()
    conn.close()

init_db()

# Connect to Web3
w3 = Web3(Web3.HTTPProvider(RPC_URL))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/mint', methods=['POST'])
def mint_and_send():
    data = request.get_json()
    wallet = data.get('wallet_address')
    amount = data.get('amount_usdt')

    # Validation
    if not wallet or not amount:
        return jsonify({'error': 'Missing parameters'}), 400
    
    if amount < 1 or amount > 100:
        return jsonify({'error': 'Daily limit is between $1 and $100.'}), 400

    # Check Daily Limit
    today = datetime.date.today().isoformat()
    conn = sqlite3.connect('flash_tether.db')
    c = conn.cursor()
    
    # Sum up what this user already claimed today
    c.execute("SELECT SUM(amount) FROM claims WHERE wallet=? AND date=?", (wallet, today))
    result = c.fetchone()[0]
    total_claimed = result if result else 0
    
    if total_claimed + amount > 100:
        conn.close()
        return jsonify({'error': f'Daily limit reached! You have already claimed ${total_claimed}.', 'current_total': total_claimed}), 400

    # Generate Transaction Hash (Mock or Real)
    tx_hash = ""
    if MOCK_MODE:
        tx_hash = f"0xmock_{datetime.datetime.now().timestamp()}"
    else:
        try:
            # Basic ERC20 Transfer Logic
            # Note: For a real app, you need the USDT Contract ABI
            contract = w3.eth.contract(address='0xdAC17F958D2ee523a2206206994597C13D881ecE', abi=[...]) # Add ABI here
            
            # Build transaction
            nonce = w3.eth.get_transaction_count(TREASURY_ADDRESS)
            tx = contract.functions.transfer(wallet, int(amount * 1000000)).buildTransaction({
                'chainId': 1,
                'gas': 200000,
                'gasPrice': w3.to_wei('5', 'gwei'),
                'nonce': nonce,
            })
            
            signed_tx = w3.eth.account.sign_transaction(tx, PRIVATE_KEY)
            tx_hash = w3.to_hex(w3.eth.send_raw_transaction(signed_tx.rawTransaction))
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    # Record in Database
    c.execute("INSERT INTO claims (wallet, date, amount) VALUES (?, ?, ?)", (wallet, today, amount))
    conn.commit()
    conn.close()

    return jsonify({
        'message': 'Flash tokens created successfully!',
        'tx_hash': tx_hash,
        'amount': amount,
        'wallet': wallet
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)