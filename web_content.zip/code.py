import flask
import random
import json
import os
from datetime import datetime, timedelta

app = flask.Flask(__name__)

# File to store generation logs
LOG_FILE = 'cards_log.json'

def get_luhn_number():
    """Generates a valid credit card number using the Luhn algorithm."""
    # Start with a common prefix (e.g., Visa starts with 4, Mastercard with 51-55)
    # We'll use Visa (4) as default
    number = ['4']
    
    # Generate 14 random digits
    for _ in range(14):
        number.append(str(random.randint(0, 9)))
    
    # Calculate Luhn check digit
    total = 0
    double = False
    for digit in reversed(number):
        if double:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
        double = not double
    
    check_digit = (10 - (total % 10)) % 10
    number.append(str(check_digit))
    
    return ''.join(number)

def get_expiry_date():
    """Returns an expiry date 1 year from now in MM/YY format."""
    future_date = datetime.now() + timedelta(days=365)
    return future_date.strftime('%m/%y')

def get_cvv():
    """Generates a random 3-digit CVV."""
    return str(random.randint(100, 999))

def check_daily_limit():
    """Checks if a card has been generated today."""
    if not os.path.exists(LOG_FILE):
        return False
    
    try:
        with open(LOG_FILE, 'r') as f:
            log = json.load(f)
        
        today = datetime.now().strftime('%Y-%m-%d')
        if log.get(today):
            return True
    except (json.JSONDecodeError, IOError):
        pass
    
    return False

def record_generation():
    """Records that a card was generated today."""
    today = datetime.now().strftime('%Y-%m-%d')
    log = {}
    
    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE, 'r') as f:
                log = json.load(f)
        except (json.JSONDecodeError, IOError):
            log = {}
    
    log[today] = datetime.now().isoformat()
    
    with open(LOG_FILE, 'w') as f:
        json.dump(log, f)

@app.route('/')
def index():
    return flask.render_template('index.html')

@app.route('/generate')
def generate():
    if check_daily_limit():
        return flask.jsonify({
            'error': 'You have already generated your card for today.'
        }), 429 # Too Many Requests / Limit Exceeded
    
    number = get_luhn_number()
    expiry = get_expiry_date()
    cvv = get_cvv()
    
    record_generation()
    
    return flask.jsonify({
        'number': number,
        'expiry': expiry,
        'cvv': cvv,
        'balance': '$100.00'
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)