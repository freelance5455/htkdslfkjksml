from flask import Flask, render_template, request, jsonify
import datetime

app = Flask(__name__)

# Configuration
DAILY_LIMIT = 100
APP_NAME = "USDT Flash Token Generator"

@app.route('/')
def index():
    """Serve the main index.html file."""
    return render_template('index.html')

@app.route('/api/check_limit', methods=['POST'])
def check_limit():
    """
    API Endpoint to check remaining daily limit.
    In a production app, you'd store this in a database (SQLite/PostgreSQL).
    For this demo, we rely on the frontend's localStorage, 
    but this endpoint allows server-side validation if needed.
    """
    # Example: Read from a simple JSON file or DB
    # For now, we just return the config
    return jsonify({
        "daily_limit": DAILY_LIMIT,
        "message": "Limit check successful"
    })

@app.route('/api/generate', methods=['POST'])
def generate_tokens():
    """
    API Endpoint to log a generation request.
    """
    data = request.json
    amount = data.get('amount')
    wallet = data.get('wallet_address')
    
    if not amount or not wallet:
        return jsonify({"error": "Missing amount or wallet address"}), 400
        
    # Logic to save to DB would go here
    # Example: db.save_transaction(user_id, amount, wallet)
    
    return jsonify({
        "status": "success",
        "message": f"{amount} USDT Flash Tokens generated for {wallet}",
        "timestamp": datetime.datetime.now().isoformat()
    })

if __name__ == '__main__':
    # Create templates folder if it doesn't exist
    import os
    if not os.path.exists('templates'):
        os.makedirs('templates')
    
    app.run(debug=True, port=5000)