Yoga Secret — پروژه اندروید

نامی که زیر آیکون برنامه در گوشی نمایش داده می‌شود: Yoga Secret
شناسه برنامه: com.saniyar.yogasecret

ساخت APK:
1) Android Studio را نصب کنید (JDK 17 و Android SDK Platform 35).
2) پوشه YogaSecret_Android را در Android Studio باز کنید.
3) صبر کنید Gradle Sync کامل شود.
4) از منوی Build گزینه Build Bundle(s) / APK(s) و سپس Build APK(s) را انتخاب کنید.
5) فایل خروجی معمولاً در app/build/outputs/apk/debug/app-debug.apk قرار می‌گیرد.

فایل HTML اصلی داخل app/src/main/assets/index.html قرار داده شده است.
JavaScript و ذخیره‌سازی محلی فعال هستند. هنگام اجرای تایمر، صفحه با پرچم بومی اندروید روشن نگه داشته می‌شود.
برای دریافت فونت‌های آنلاین Google Fonts و قابلیت‌های وابسته به اینترنت، اتصال اینترنت لازم است.
