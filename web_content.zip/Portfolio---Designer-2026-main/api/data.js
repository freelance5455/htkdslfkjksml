// Vercel Function: guarda e serve os dados do portfólio (partilhados por todos os visitantes)
// GET  /api/data -> devolve os dados (público)
// POST /api/data -> {action:"login"|"save"|"changepw", password, ...} (a senha é verificada AQUI no servidor)
// Base de dados: Upstash Redis (ligado em Vercel → Storage). Não precisa de instalar nada.
const { pbkdf2Sync, timingSafeEqual, randomBytes } = require("node:crypto");

// hash PBKDF2-SHA256 (salt:hash) da senha do admin. Pode ser substituído pela variável de ambiente ADMIN_CRED.
const DEFAULT_CRED = "8973fcd849288df2b3fe46eb7bd47d91:558f2f173e0b3ecb1c9dfc4d06e5edc7eaa13cb72a210535627129ea0c8762de";
const ITER = 200000;
const MAX_BYTES = 4000000; // limite de pedido do Vercel é 4.5 MB

const DB_URL = () => process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
const DB_TOKEN = () => process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;

async function redis(cmd) {
  const r = await fetch(DB_URL(), {
    method: "POST",
    headers: { Authorization: "Bearer " + DB_TOKEN(), "Content-Type": "application/json" },
    body: JSON.stringify(cmd),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new Error(j.error || "redis " + r.status);
  return j.result;
}
const getJSON = async (k) => { const v = await redis(["GET", k]); if (v == null) return null; try { return JSON.parse(v); } catch (_) { return null; } };
const setJSON = (k, v) => redis(["SET", k, JSON.stringify(v)]);

function verify(pwd, cred) {
  try {
    const [salt, hash] = String(cred).split(":");
    const h = pbkdf2Sync(String(pwd), Buffer.from(salt, "hex"), ITER, 32, "sha256");
    const e = Buffer.from(hash, "hex");
    return h.length === e.length && timingSafeEqual(h, e);
  } catch (_) { return false; }
}

module.exports = async (req, res) => {
  const send = (code, obj, headers = {}) => {
    Object.entries(headers).forEach(([k, v]) => res.setHeader(k, v));
    res.status(code).json(obj);
  };

  if (!DB_URL() || !DB_TOKEN()) return send(500, { error: "no_database" });

  try {
    // ---------- leitura pública ----------
    if (req.method === "GET") {
      const d = await getJSON("portfolio:data");
      return send(200, d || { data: {}, updated: 0 }, {
        "Cache-Control": "public, max-age=0, s-maxage=15, stale-while-revalidate=60",
      });
    }
    if (req.method !== "POST") return send(405, { error: "method" });

    let body = req.body;
    if (typeof body === "string") { try { body = JSON.parse(body); } catch (_) { body = null; } }
    if (!body || typeof body !== "object") return send(400, { error: "bad_json" });

    // ---------- protecção contra tentativas em massa ----------
    const auth = (await getJSON("portfolio:auth")) || { fails: 0, lockUntil: 0 };
    if (Date.now() < auth.lockUntil) {
      return send(429, { error: "locked", retry: Math.ceil((auth.lockUntil - Date.now()) / 1000) });
    }
    const stored = await redis(["GET", "portfolio:cred"]);
    const cred = stored || process.env.ADMIN_CRED || DEFAULT_CRED;
    if (!verify(body.password, cred)) {
      auth.fails = (auth.fails || 0) + 1;
      if (auth.fails >= 5) { auth.lockUntil = Date.now() + 60000; auth.fails = 0; }
      await setJSON("portfolio:auth", auth);
      return send(401, { error: "denied" });
    }
    if (auth.fails) await setJSON("portfolio:auth", { fails: 0, lockUntil: 0 });

    // ---------- acções ----------
    if (body.action === "login") return send(200, { ok: true });

    if (body.action === "changepw") {
      const nw = String(body.newPassword || "");
      if (nw.length < 10) return send(400, { error: "short" });
      const salt = randomBytes(16);
      const hash = pbkdf2Sync(nw, salt, ITER, 32, "sha256");
      await redis(["SET", "portfolio:cred", salt.toString("hex") + ":" + hash.toString("hex")]);
      return send(200, { ok: true });
    }

    if (body.action === "save") {
      const src = body.data && typeof body.data === "object" ? body.data : null;
      if (!src) return send(400, { error: "no_data" });
      const clean = {};
      for (const [k, v] of Object.entries(src)) {
        if (!/^sp_/.test(k) || /^sp_admin/.test(k) || typeof v !== "string") continue;
        clean[k] = v;
      }
      const payload = { data: clean, updated: Date.now() };
      if (JSON.stringify(payload).length > MAX_BYTES) return send(413, { error: "too_big" });
      await setJSON("portfolio:data", payload);
      return send(200, { ok: true, updated: payload.updated, keys: Object.keys(clean).length });
    }

    return send(400, { error: "unknown_action" });
  } catch (e) {
    return send(500, { error: "server", detail: String(e && e.message || e) });
  }
};
