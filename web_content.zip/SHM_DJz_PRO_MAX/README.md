# SHM DJz PRO MAX — Android Studio WebView project

## Included
- Two independent audio decks with local audio-file selection
- Simultaneous playback, cue, seek and 5-second rewind
- Crossfader with equal-power blend
- Per-deck gain, volume, tempo and low/mid/high EQ
- Per-deck low-pass filter
- Echo and reverb send effects
- Sample pads and four basic beat-machine patterns
- Android `ACTION_OPEN_DOCUMENT` audio picker through `WebChromeClient`

## Open in Android Studio
1. Extract this ZIP.
2. In Android Studio choose **Open** and select the extracted `SHM_DJz_PRO_MAX` folder.
3. Allow Gradle sync. Use JDK 17 with Android Gradle Plugin 8.7.3.
4. Connect an Android device or start an emulator, then press **Run**.
5. To make an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important audio notes
- Press a playback or sample button first to initialize the Web Audio engine.
- Choose two audio files from the device using the LOAD TRACK buttons.
- Supported file formats depend on the Android version and device codecs.
- Tempo currently changes playback speed and pitch together. The KEY LOCK button is an interface placeholder; pitch-preserving time-stretch is not included.
- The Automix button starts both loaded tracks and gradually moves the crossfader. It is a basic transition helper, not beat-grid analysis.
- Use headphones and keep device volume at a safe level.

## APK size target
This source ZIP is intentionally not padded. Its APK will not automatically be 70–100 MB. To reach that range legitimately, add licensed/offline demo music, sample packs, artwork, and any required native audio libraries under `app/src/main/assets/` or Android resources. Then build a release APK and check its actual size. Do not add random filler files; they increase download size without improving the DJ app.

## Current limitations
This is a functional WebView starter DJ mixer, not a professional time-stretching DJ engine. Browser-based Web Audio latency and audio routing vary by device. For low-latency pro performance, a native Android audio engine (for example Oboe/AAudio) would be a later upgrade.
