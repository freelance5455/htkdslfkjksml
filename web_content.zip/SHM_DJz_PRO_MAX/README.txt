SHM DJz PRO MAX

HOW TO USE
1. Extract this ZIP file.
2. Open index.html in a modern browser (Chrome or Edge recommended).
3. Tap LOAD TRACK A and LOAD TRACK B to choose audio files from your device.
4. Use the deck controls and mixer.

NOTES
- Audio files are selected locally in your browser; they are not uploaded.
- Audio playback and effects require a browser that supports the Web Audio API.
- For best results, use headphones and allow audio playback when prompted.
- This is a browser-based project; it does not include music files.
