RX-ASAD FF MARKET Android demo project

Features:
- Min/max price filter
- Sample account listings
- Sell Your ID demo form
- Phone call and WhatsApp contact buttons on listing cards
- Responsive dark/red layout

How to build:
1. Extract ZIP.
2. Open project folder in AndroidIDE.
3. Sync Gradle.
4. Build APK.

Demo limitations:
- No backend or persistent database; listings are in-memory and reset when app reloads.
- Contact numbers are entered per demo listing. No payment/escrow or account authentication.
- Use safe, trusted communication and do not share passwords or OTPs.
