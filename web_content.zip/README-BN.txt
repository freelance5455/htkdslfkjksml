ULTIMATE DRIVE – FINAL ANDROID / OFFLINE PACKAGE
===============================================

এই ZIP-এ আছে:
- index.html: গেমের আপডেটেড সোর্স
- Mountain scenery + winding mountain pass
- মোবাইল touch control / আগের vehicle physics
- PWA manifest + service worker (ওয়েব ভার্সনের cache)
- Capacitor Android wrapper setup
- build-assets.mjs: Three.js-কে লোকাল ফাইলে bundle করে; APK চালাতে ইন্টারনেট লাগে না

গুরুত্বপূর্ণ সীমাবদ্ধতা:
এই পরিবেশে ইন্টারনেট বন্ধ থাকায় Three.js লাইব্রেরি ডাউনলোড করা যায়নি এবং Android SDK/Gradle build চালানো হয়নি। তাই এই ZIP-এ প্রস্তুত APK নেই। নিচের build steps একবার ইন্টারনেট-যুক্ত কম্পিউটারে চালালে Three.js অ্যাপের ভিতরে bundle হবে; এরপর তৈরি APK অফলাইনে চলবে।

APK তৈরির সহজ পদ্ধতি (Windows / Mac / Linux):
1) Node.js LTS এবং Android Studio ইনস্টল করুন। Android Studio-তে Android SDK ও Build Tools ইনস্টল করুন।
2) ZIP extract করুন। এই ফোল্ডারে Terminal / CMD খুলুন।
3) চালান:
   npm install
   npm run build:web
   npx cap add android
   npx cap sync android
   npx cap open android
4) প্রথমবার Android Studio-তে android/app/src/main/AndroidManifest.xml খুলে <activity ...> ট্যাগে android:screenOrientation="landscape" যোগ করুন (অন্য attributes মুছবেন না)। এরপর Gradle sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5) APK সাধারণত android/app/build/outputs/apk/debug/app-debug.apk-এ তৈরি হবে। ফোনে কপি করে install করুন।

প্রতিবার index.html বদলালে:
   npm run cap:sync
তারপর Android Studio থেকে আবার Build APK(s)।

ফোনে:
- landscape orientation-এ খেলার জন্য তৈরি।
- APK install হওয়ার পর গেমের Three.js engine লোকাল asset থেকে লোড হবে; gameplay-তে internet দরকার নেই।
- প্রথমবার build-এর সময় npm install-এর জন্য internet লাগবে।
- ফোনে install করতে Android-এর “Install unknown apps” অনুমতি দিতে হতে পারে। কেবল নিজের তৈরি APK-ই install করুন।

নোট:
এটি drive.io-এর হুবহু কপি নয়; অনুপ্রাণিত mountain-driving পরিবেশসহ নিজস্ব গেম। বর্তমান গেমের physics, traffic, mission এবং vehicle systems মূল সোর্স থেকে বজায় রাখা হয়েছে। বাস্তব ফোনে final performance test করা আবশ্যক।
