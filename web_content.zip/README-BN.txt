MY STOCK — PWA PACKAGE

সবচেয়ে সহজ ব্যবহার:
1) এই ফোল্ডার/ZIP-টি এমন একটি HTTPS web hosting-এ upload করতে হবে।
2) ফোনের Chrome-এ সেই web address খুলুন।
3) Chrome-এর Install app / Add to Home screen চাপুন।
4) My Stock ফোনে standalone app-এর মতো খুলবে।

গুরুত্বপূর্ণ:
- শুধু ZIP ফাইল ফোনে খুললেই PWA install হবে না; PWA install-এর জন্য HTTPS web address দরকার।
- আপনার মূল My Stock HTML app index.html হিসেবে রাখা হয়েছে।
- manifest.webmanifest + service-worker.js যোগ করা হয়েছে।
- service worker app shell cache করবে, ফলে পরে network না থাকলেও app খোলার সুবিধা থাকবে (app-এর cloud/data sync আলাদা বিষয়)।
