এটি Australia Work Visa-এর Android project। ZIP নিজে APK নয়।
Build environment-এ project খুলে Build APK করলে APK তৈরি হবে। এটি Australian Government-এর অফিসিয়াল অ্যাপ নয়।