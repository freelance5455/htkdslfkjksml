ST World bd Delivery v7
v6-এর সব ফিচারের সাথে প্রতিটি অর্ডারে Customer Call এবং WhatsApp অপশন যোগ করা হয়েছে।
Rider অর্ডার খুলে Customer-কে সরাসরি ফোন করতে পারবে।
Pickup Shop ও Rider-এর Call/WhatsApp অপশনও আছে।
Rider Payment Admin নিজে সেট করতে পারে।
গুরুত্বপূর্ণ: এটি এখনো local/offline browser storage। আলাদা ফোন/PC-তে স্বয়ংক্রিয় shared sync নেই।
