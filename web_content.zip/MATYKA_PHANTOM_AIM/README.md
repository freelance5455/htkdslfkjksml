# MATYKA PHANTOM AIM VIP

Aplicativo web responsivo da identidade MATYKA CHEATS.

## Como abrir
1. Extraia o arquivo ZIP.
2. Abra a pasta `MATYKA_PHANTOM_AIM`.
3. Abra `index.html` em um navegador moderno.

## Recursos do painel
- Interface MATYKA PHANTOM AIM VIP com arte da Duquesa.
- Controles de ativação e sliders internos para Headtricker, Precision, Boneco Lento, Calibrador 2X e No Recoil.
- Phantom Aim VIP com cadeado e aviso de aquisição por R$ 2,00.
- Preferências internas de Hz Alto e FPS Boost (60, 80, 100, 120, 150, 144 e 190 FPS).
- Otimização de dados e configurações locais do próprio painel.
- Gerador de sensibilidade de 0 a 200, com seleção de ponto Pescoço ou Cabeça.
- Histórico local, exportação e remoção de configurações.

## Observação técnica
Os controles alteram os estados e valores armazenados no próprio painel. Uma página web não consegue, por si só, alterar a mira, o comportamento de oponentes, o recoil, os Hz físicos da tela ou o FPS de um jogo externo. Nenhum código é injetado em jogos ou processos externos.
