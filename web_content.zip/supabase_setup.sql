-- ACHAR SERVIÇO V2 — esquema inicial do banco Supabase
-- Execute no SQL Editor do seu projeto. Revise as políticas antes de publicar.
create extension if not exists pgcrypto;

create table if not exists public.professionals (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 name text not null,
 phone text not null,
 email text,
 service text not null,
 city text not null,
 neighborhood text,
 photo_url text,
 availability text,
 experience text,
 portfolio text default '',
 approved boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.service_requests (
 id uuid primary key default gen_random_uuid(),
 customer_id uuid not null references auth.users(id) on delete cascade,
 professional_id uuid references public.professionals(id) on delete set null,
 customer text not null,
 phone text not null,
 service text not null,
 city text not null,
 neighborhood text,
 when_needed text,
 details text not null,
 status text not null default 'Pendente'
   check(status in ('Pendente','Em negociação','Em andamento','Concluído','Cancelado')),
 created_at timestamptz not null default now()
);
create table if not exists public.reviews (
 id uuid primary key default gen_random_uuid(),
 professional_id uuid not null references public.professionals(id) on delete cascade,
 reviewer_id uuid not null references auth.users(id) on delete cascade,
 rating integer not null check(rating between 1 and 5),
 comment text default '',
 created_at timestamptz not null default now(),
 unique(professional_id, reviewer_id)
);

alter table public.professionals enable row level security;
alter table public.service_requests enable row level security;
alter table public.reviews enable row level security;

-- Profissionais aprovados podem ser vistos publicamente.
drop policy if exists "Public can view approved professionals" on public.professionals;
create policy "Public can view approved professionals" on public.professionals for select using (approved = true or auth.uid() = user_id);
drop policy if exists "Users create own professional profile" on public.professionals;
create policy "Users create own professional profile" on public.professionals for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users update own professional profile" on public.professionals;
create policy "Users update own professional profile" on public.professionals for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users delete own professional profile" on public.professionals;
create policy "Users delete own professional profile" on public.professionals for delete to authenticated using (auth.uid() = user_id);

-- Cada cliente vê e altera apenas suas solicitações. Profissionais associados podem consultar as solicitações destinadas a eles.
drop policy if exists "Users view own requests" on public.service_requests;
create policy "Users view own requests" on public.service_requests for select to authenticated using (
 auth.uid() = customer_id or exists(select 1 from public.professionals p where p.id = professional_id and p.user_id = auth.uid())
);
drop policy if exists "Users create own requests" on public.service_requests;
create policy "Users create own requests" on public.service_requests for insert to authenticated with check (auth.uid() = customer_id);
drop policy if exists "Users update own requests" on public.service_requests;
create policy "Users update own requests" on public.service_requests for update to authenticated using (
 auth.uid() = customer_id or exists(select 1 from public.professionals p where p.id = professional_id and p.user_id = auth.uid())
) with check (
 auth.uid() = customer_id or exists(select 1 from public.professionals p where p.id = professional_id and p.user_id = auth.uid())
);
drop policy if exists "Users delete own requests" on public.service_requests;
create policy "Users delete own requests" on public.service_requests for delete to authenticated using (auth.uid() = customer_id);

-- Avaliações públicas para leitura; usuários autenticados criam e alteram apenas a própria avaliação.
drop policy if exists "Public can view reviews" on public.reviews;
create policy "Public can view reviews" on public.reviews for select using (true);
drop policy if exists "Users create own reviews" on public.reviews;
create policy "Users create own reviews" on public.reviews for insert to authenticated with check (auth.uid() = reviewer_id);
drop policy if exists "Users update own reviews" on public.reviews;
create policy "Users update own reviews" on public.reviews for update to authenticated using (auth.uid() = reviewer_id) with check (auth.uid() = reviewer_id);
drop policy if exists "Users delete own reviews" on public.reviews;
create policy "Users delete own reviews" on public.reviews for delete to authenticated using (auth.uid() = reviewer_id);

-- NOTA DE SEGURANÇA:
-- Para aprovar perfis e administrar usuários, implemente função/Edge Function protegida
-- ou políticas específicas baseadas em app_metadata/role. Não confie em ADMIN_EMAILS
-- no arquivo do navegador como controle de segurança. Não coloque service_role/secret key no app.
