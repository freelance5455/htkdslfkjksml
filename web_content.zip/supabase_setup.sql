-- Kanona FC online database setup
-- Run the whole script in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- Restrict administration to the exact Auth user created for the club admin.
insert into public.admin_users(user_id)
values ('47b47f28-07ee-4760-a44e-b3bb51e72341')
on conflict (user_id) do nothing;

create or replace function public.is_club_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_users a
    where a.user_id = (select auth.uid())
  );
$$;
revoke all on function public.is_club_admin() from public;
grant execute on function public.is_club_admin() to anon, authenticated;

create table if not exists public.news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  category text not null default 'Club News',
  image_url text,
  published_at date not null default current_date,
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.fixtures (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  status text not null default 'Upcoming',
  match_date date,
  score text,
  image_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  position text,
  squad_number integer,
  image_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.news enable row level security;
alter table public.fixtures enable row level security;
alter table public.players enable row level security;

drop policy if exists "Public can read published news" on public.news;
create policy "Public can read published news" on public.news for select to anon, authenticated using (is_published = true or public.is_club_admin());
drop policy if exists "Admin can insert news" on public.news;
create policy "Admin can insert news" on public.news for insert to authenticated with check (public.is_club_admin());
drop policy if exists "Admin can update news" on public.news;
create policy "Admin can update news" on public.news for update to authenticated using (public.is_club_admin()) with check (public.is_club_admin());
drop policy if exists "Admin can delete news" on public.news;
create policy "Admin can delete news" on public.news for delete to authenticated using (public.is_club_admin());

drop policy if exists "Public can read fixtures" on public.fixtures;
create policy "Public can read fixtures" on public.fixtures for select to anon, authenticated using (true);
drop policy if exists "Admin can insert fixtures" on public.fixtures;
create policy "Admin can insert fixtures" on public.fixtures for insert to authenticated with check (public.is_club_admin());
drop policy if exists "Admin can update fixtures" on public.fixtures;
create policy "Admin can update fixtures" on public.fixtures for update to authenticated using (public.is_club_admin()) with check (public.is_club_admin());
drop policy if exists "Admin can delete fixtures" on public.fixtures;
create policy "Admin can delete fixtures" on public.fixtures for delete to authenticated using (public.is_club_admin());

drop policy if exists "Public can read players" on public.players;
create policy "Public can read players" on public.players for select to anon, authenticated using (true);
drop policy if exists "Admin can insert players" on public.players;
create policy "Admin can insert players" on public.players for insert to authenticated with check (public.is_club_admin());
drop policy if exists "Admin can update players" on public.players;
create policy "Admin can update players" on public.players for update to authenticated using (public.is_club_admin()) with check (public.is_club_admin());
drop policy if exists "Admin can delete players" on public.players;
create policy "Admin can delete players" on public.players for delete to authenticated using (public.is_club_admin());

-- Private admin list: no public reads or writes.
drop policy if exists "Admins can read admin list" on public.admin_users;
create policy "Admins can read admin list" on public.admin_users for select to authenticated using (public.is_club_admin());

grant select on public.news, public.fixtures, public.players to anon, authenticated;
grant insert, update, delete on public.news, public.fixtures, public.players to authenticated;

-- Public photo delivery; only the registered club admin can upload, change, or delete.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('club-media', 'club-media', true, 8388608, array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public = true, file_size_limit = 8388608,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif'];

drop policy if exists "Public can view club media" on storage.objects;
create policy "Public can view club media" on storage.objects for select to anon, authenticated using (bucket_id = 'club-media');
drop policy if exists "Club admin can upload media" on storage.objects;
create policy "Club admin can upload media" on storage.objects for insert to authenticated with check (bucket_id = 'club-media' and public.is_club_admin());
drop policy if exists "Club admin can update media" on storage.objects;
create policy "Club admin can update media" on storage.objects for update to authenticated using (bucket_id = 'club-media' and public.is_club_admin()) with check (bucket_id = 'club-media' and public.is_club_admin());
drop policy if exists "Club admin can delete media" on storage.objects;
create policy "Club admin can delete media" on storage.objects for delete to authenticated using (bucket_id = 'club-media' and public.is_club_admin());
