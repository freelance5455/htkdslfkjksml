-- LubriAgro: execute no SQL Editor do seu projeto Supabase.
-- Use Auth com uma conta da equipe compartilhada entre as instalações durante o piloto.
create table if not exists public.lubriagro_instalacoes (
  device_id text primary key,
  device_name text not null default 'Aparelho LubriAgro',
  owner_email text not null,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  app_version text
);
alter table public.lubriagro_instalacoes enable row level security;
-- Piloto: usuários autenticados podem ler e atualizar registros de todas as instalações.
-- Para uso comercial/múltiplas empresas, substituir por políticas de organização/roles.
drop policy if exists "lubriagro_team_read" on public.lubriagro_instalacoes;
create policy "lubriagro_team_read" on public.lubriagro_instalacoes for select to authenticated using (true);
drop policy if exists "lubriagro_team_insert" on public.lubriagro_instalacoes;
create policy "lubriagro_team_insert" on public.lubriagro_instalacoes for insert to authenticated with check (true);
drop policy if exists "lubriagro_team_update" on public.lubriagro_instalacoes;
create policy "lubriagro_team_update" on public.lubriagro_instalacoes for update to authenticated using (true) with check (true);
-- Importante: NÃO crie políticas para anon e nunca use a chave service_role no app.
