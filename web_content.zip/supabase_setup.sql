-- ISMAIL AUTOS v1.5.3: private cloud backup with atomic revision protection
-- Run this complete script in Supabase SQL Editor. Existing backup payloads are preserved.
create table if not exists public.shop_backups (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null,
  revision bigint not null default 1,
  updated_at timestamptz not null default now()
);

alter table public.shop_backups add column if not exists revision bigint not null default 1;
alter table public.shop_backups enable row level security;

drop policy if exists "Users read own shop backup" on public.shop_backups;
create policy "Users read own shop backup"
on public.shop_backups for select to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users insert own shop backup" on public.shop_backups;
create policy "Users insert own shop backup"
on public.shop_backups for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users update own shop backup" on public.shop_backups;
create policy "Users update own shop backup"
on public.shop_backups for update to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- Atomic compare-and-swap: only the phone holding the latest revision can save.
create or replace function public.save_shop_backup(p_payload jsonb, p_expected_revision bigint)
returns bigint
language plpgsql
security invoker
set search_path = public
as $$
declare
  saved_revision bigint;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    raise exception 'INVALID_BACKUP_PAYLOAD';
  end if;
  if p_expected_revision is null or p_expected_revision < 0 then
    raise exception 'INVALID_EXPECTED_REVISION';
  end if;

  if p_expected_revision = 0 then
    insert into public.shop_backups(user_id, payload, revision, updated_at)
    values (auth.uid(), p_payload, 1, now())
    on conflict (user_id) do nothing
    returning revision into saved_revision;
  else
    update public.shop_backups
       set payload = p_payload,
           revision = revision + 1,
           updated_at = now()
     where user_id = auth.uid()
       and revision = p_expected_revision
    returning revision into saved_revision;
  end if;

  if saved_revision is null then
    raise exception 'CLOUD_REVISION_CONFLICT';
  end if;
  return saved_revision;
end;
$$;

grant execute on function public.save_shop_backup(jsonb, bigint) to authenticated;
