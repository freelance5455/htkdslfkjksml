AKS TRAVEL AGENCY - ANDROID APP SOURCE

इस ZIP में आपके मौजूदा ऑफलाइन HTML पोर्टल का Android WebView ऐप प्रोजेक्ट है।

महत्वपूर्ण:
- इस वातावरण में Android SDK/Gradle build tools उपलब्ध नहीं हैं, इसलिए अभी वास्तविक APK compile नहीं हो सकी है।
- यह Android Studio में खोलकर APK बनाने योग्य प्रोजेक्ट है; ZIP स्वयं APK नहीं है।
- ऐप का डेटा उसी मोबाइल के WebView/local storage में रहता है। ऐप हटाने या app data clear करने से रिकॉर्ड मिट सकते हैं। नियमित backup रखें।
- WhatsApp/फोन/बाहरी लिंक के लिए संबंधित ऐप और कभी-कभी इंटरनेट चाहिए।
- ब्राउज़र नोटिफिकेशन और पृष्ठभूमि रिमाइंडर Android WebView में हर परिस्थिति में सुनिश्चित नहीं हैं; पोर्टल को खोलकर रखने पर उपलब्ध फीचर ही चलेंगे।

APK बनाने का तरीका:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio > Open > इस फोल्डर AKS_Travel_Android_App को चुनें।
4. Gradle sync पूरा होने दें और SDK 35/Android SDK platform इंस्टॉल करने को कहे तो इंस्टॉल करें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK आमतौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगी।
7. APK को अपने Android मोबाइल में भेजें, खोलें और पूछे जाने पर इस स्रोत से install की अनुमति दें। केवल अपनी बनाई/विश्वसनीय APK ही इंस्टॉल करें।

वैकल्पिक: इस प्रोजेक्ट को GitHub पर main branch में अपलोड करके Actions > Build AKS Travel APK > Run workflow चलाएँ। Build सफल होने पर Actions run के Artifacts से APK डाउनलोड की जा सकती है।
