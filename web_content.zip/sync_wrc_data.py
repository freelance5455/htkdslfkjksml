#!/usr/bin/env python3
"""Polite public WildRiftCore snapshot synchronizer for MAZEN RIFT AI.

Only public pages on wildriftcore.com are requested. The crawler checks robots.txt,
uses one sequential request stream, obeys a delay, and never bypasses login,
challenge pages, paywalls, or other access controls.

The output schema is the same schema consumed by index.html (window.WRC_DB).
Run from the project directory: python sync_wrc_data.py
"""
from __future__ import annotations
import argparse, json, re, time, gzip, hashlib, urllib.robotparser, mimetypes
from pathlib import Path
from urllib.parse import urljoin, urlparse, urldefrag
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from xml.etree import ElementTree as ET
from html.parser import HTMLParser

BASE = 'https://wildriftcore.com'
ROOT = Path(__file__).resolve().parent
UA = 'MAZEN-RIFT-AI-public-reference-reader/2.0 (polite sequential crawl)'
HUBS = {
    'home': '/en/', 'champions': '/en/champions/', 'builds': '/en/builds/',
    'counters': '/en/counter-picks/', 'synergies': '/en/synergies/',
    'items': '/en/items/', 'meta': '/en/meta/', 'tierlist': '/en/tierlist/',
    'rankings': '/en/rankings/', 'draft': '/en/draft/', 'guides': '/en/guides/'
}
ALLOWED_PATHS = ('/en/champions/', '/en/items/', '/en/tierlist/', '/en/rankings/',
                 '/en/counter-picks/', '/en/synergies/', '/en/builds/',
                 '/en/guides/', '/en/draft/', '/en/meta/')
LANES = [('Baron', ('baron lane', 'top lane')), ('Jungle', ('jungle',)),
         ('Mid', ('mid lane',)), ('Dragon', ('dragon lane', 'adc', 'bot lane')),
         ('Support', ('support',))]

class PageParser(HTMLParser):
    BLOCKS = {'h1','h2','h3','h4','h5','p','li','td','th','blockquote'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.blocks=[]; self._block_stack=[]; self.links=[]; self._link_stack=[]
        self.images=[]; self.meta={}; self.title=''; self._in_title=False; self.all_text=[]
        self._script_type=''; self._script_data=[]; self.jsonld=[]; self.canonical=''
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag == 'title': self._in_title=True
        if tag == 'meta':
            key=(a.get('property') or a.get('name') or '').lower()
            if key and a.get('content'): self.meta[key]=a['content'].strip()
        if tag == 'link' and a.get('rel','').lower()=='canonical' and a.get('href'):
            self.canonical=a['href']
        if tag == 'script' and 'ld+json' in a.get('type','').lower():
            self._script_type='jsonld'; self._script_data=[]
        if tag in self.BLOCKS:
            self.blocks.append({'tag':tag,'text':'','class':a.get('class',''),'id':a.get('id','')})
            self._block_stack.append(len(self.blocks)-1)
        if tag == 'a' and a.get('href'):
            item={'href':a['href'],'text':'','title':a.get('title',''),'aria':a.get('aria-label',''),'class':a.get('class','')}
            self.links.append(item); self._link_stack.append(len(self.links)-1)
        if tag == 'img':
            src=a.get('data-src') or a.get('data-lazy-src') or a.get('src') or ''
            srcset=a.get('data-srcset') or a.get('srcset') or ''
            if not src and srcset: src=srcset.split(',')[0].strip().split(' ')[0]
            self.images.append({'src':src,'srcset':srcset,'alt':a.get('alt',''),'title':a.get('title',''),'class':a.get('class','')})
    def handle_endtag(self, tag):
        if tag=='title': self._in_title=False
        if tag=='a' and self._link_stack: self._link_stack.pop()
        if tag in self.BLOCKS and self._block_stack:
            # Close the most recent matching block, tolerate malformed nesting.
            for i in range(len(self._block_stack)-1,-1,-1):
                idx=self._block_stack[i]
                if self.blocks[idx]['tag']==tag:
                    self._block_stack=self._block_stack[:i]; break
        if tag=='script' and self._script_type=='jsonld':
            raw=''.join(self._script_data).strip()
            if raw:
                try: self.jsonld.append(json.loads(raw))
                except Exception: pass
            self._script_type=''; self._script_data=[]
    def handle_data(self, data):
        text=' '.join(data.split())
        if not text: return
        self.all_text.append(text)
        if self._in_title: self.title=(self.title+' '+text).strip()
        if self._block_stack: self.blocks[self._block_stack[-1]]['text']=(self.blocks[self._block_stack[-1]]['text']+' '+text).strip()
        if self._link_stack: self.links[self._link_stack[-1]]['text']=(self.links[self._link_stack[-1]]['text']+' '+text).strip()
        if self._script_type=='jsonld': self._script_data.append(data)


def get(url, timeout=25):
    req=Request(url, headers={'User-Agent':UA,'Accept':'text/html,application/xml,text/plain;q=0.9,*/*;q=0.5','Accept-Encoding':'gzip'})
    with urlopen(req, timeout=timeout) as response:
        raw=response.read()
        if response.headers.get('Content-Encoding','').lower()=='gzip': raw=gzip.decompress(raw)
        return raw, response.headers.get_content_type(), response.geturl()

def canonical(url):
    url=urldefrag(url)[0]
    p=urlparse(url)
    if p.scheme not in ('http','https') or p.netloc.lower() not in ('wildriftcore.com','www.wildriftcore.com'): return None
    path=p.path or '/'
    if not path.endswith('/') and '.' not in path.rsplit('/',1)[-1]: path += '/'
    return BASE+path

def read_robots():
    url=BASE+'/robots.txt'
    raw,_,_=get(url)
    parser=urllib.robotparser.RobotFileParser(); parser.set_url(url)
    parser.parse(raw.decode('utf-8','replace').splitlines())
    return parser

def sitemap_candidates(robots):
    out=[]
    # RobotFileParser does not expose sitemap directives consistently across Python versions.
    try:
        raw,_,_=get(BASE+'/robots.txt')
        for line in raw.decode('utf-8','replace').splitlines():
            if line.lower().startswith('sitemap:'): out.append(line.split(':',1)[1].strip())
    except Exception: pass
    out += [BASE+'/sitemap.xml',BASE+'/sitemap_index.xml',BASE+'/wp-sitemap.xml']
    return list(dict.fromkeys(out))

def parse_sitemap(url, seen=None):
    seen=seen or set()
    if url in seen: return []
    seen.add(url)
    try: raw,_,_=get(url); root=ET.fromstring(raw)
    except Exception: return []
    out=[]
    for node in root.iter():
        if node.tag.endswith('}loc') and node.text:
            loc=node.text.strip()
            if loc.lower().endswith('.xml') or 'sitemap' in loc.lower(): out.extend(parse_sitemap(loc,seen))
            else:
                c=canonical(loc)
                if c and c.startswith(BASE+'/en/'): out.append(c)
    return out

def allowed(robots, url):
    return robots.can_fetch(UA,url)

def sections_from_blocks(blocks):
    sections=[]; current={'heading':'Page content','blocks':[]}
    for b in blocks:
        if not b['text']: continue
        if b['tag'] in ('h1','h2','h3','h4','h5'):
            if current['blocks'] or current['heading']!='Page content': sections.append(current)
            current={'heading':b['text'],'blocks':[]}
        else: current['blocks'].append({'type':b['tag'],'text':b['text']})
    if current['blocks'] or current['heading']!='Page content': sections.append(current)
    return sections

def normalize_image(src, page_url):
    if not src: return None
    if src.startswith('data:'): return None
    return urljoin(page_url,src)

def detect_roles(text):
    head=' '.join(text.split())[:900].lower()
    found=[]
    for lane, aliases in LANES:
        if any(re.search(r'(?<![a-z])'+re.escape(alias)+r'(?![a-z])',head) for alias in aliases): found.append(lane)
    return found

def detect_archetype(text):
    head=' '.join(text.split())[:900]
    terms=['tank support','drain-tank','bruiser','marksman','assassin','mage','enchanter','engage','peel','fighter','tank','support','AP','AD','magic','physical']
    found=[]
    for term in terms:
        if re.search(r'(?<![A-Za-z])'+re.escape(term)+r'(?![A-Za-z])',head,re.I): found.append(term)
    return ' · '.join(found)

def extract_stats(text):
    result={}
    for key,pat in [('winRate',r'(?:Win\s*Rate|Win)\s*(?:\(30d\))?\s*([0-9]+(?:\.[0-9]+)?)\s*%'),
                    ('pickRate',r'Pick\s*(?:Rate)?\s*([0-9]+(?:\.[0-9]+)?)\s*%'),
                    ('banRate',r'Ban\s*(?:Rate)?\s*([0-9]+(?:\.[0-9]+)?)\s*%')]:
        m=re.search(pat,text,re.I)
        if m: result[key]=float(m.group(1))
    return result

def extract_item_records(record):
    items=[]; sections=record['sections']; url=record['url']
    for section in sections:
        heading=section['heading']
        if heading.lower() in ('items','wild rift items','full catalog','patch core','anti-frontline','supports'): continue
        texts=[b['text'] for b in section['blocks']]
        desc=next((t for t in texts if len(t)>45), '')
        name=heading.strip()
        if not name or len(name)>80: continue
        # Only retain item-like records that are linked from an item page or contain a known price/category context.
        if '/items/' not in url: continue
        price=None
        m=re.search(r'\b(\d{3,5})\b', ' '.join(texts[:2]))
        if m: price=int(m.group(1))
        items.append({'name':name,'description':desc,'category':texts[0] if texts else '',
                      'price':price,'tags':texts[1:4],'sourceUrl':url})
    return items

def parse_matchup_wall(text, champ_name, champ_lane, all_names, source_url):
    """Extract only explicit verdict/name pairs shown in a champion's WRC matchup wall."""
    low=text.lower(); start=low.find('matchup wall')
    if start<0: start=low.find('counters and synergies')
    if start<0: return [],[]
    chunk=text[start:start+1800]
    names=sorted(set(all_names),key=len,reverse=True)
    name_pattern='|'.join(re.escape(n) for n in names)
    if not name_pattern: return [],[]
    token_pattern=re.compile(r'\b(Hard|Unfav(?:ourable|orable)?|Skill|Fav(?:ourable|orable)?|Ideal|Strong|Related)\.?\s+('+name_pattern+r')',re.I)
    matchups=[]; synergies=[]
    for m in token_pattern.finditer(chunk):
        token=m.group(1).lower(); other=m.group(2)
        canonical=next((n for n in names if n.lower()==other.lower()),other)
        if token=='hard':
            matchups.append({'champion':champ_name,'opponent':canonical,'verdict':'Hard','lane':champ_lane,'sourceUrl':source_url})
        elif token.startswith('unfav'):
            matchups.append({'champion':champ_name,'opponent':canonical,'verdict':'Unfavorable','lane':champ_lane,'sourceUrl':source_url})
        elif token=='skill':
            matchups.append({'champion':champ_name,'opponent':canonical,'verdict':'Skill','lane':champ_lane,'sourceUrl':source_url})
        elif token.startswith('fav'):
            matchups.append({'champion':champ_name,'opponent':canonical,'verdict':'Favorable','lane':champ_lane,'sourceUrl':source_url})
        elif token in ('ideal','strong','related'):
            synergies.append({'champion':champ_name,'partner':canonical,'tier':token.title(),'note':f'Listed as {token.title()} in the WildRiftCore matchup wall.','sourceUrl':source_url})
    return matchups,synergies



def parse_counter_page(record, champion, all_names):
    """Extract explicit champion-vs-champion verdicts from a WRC counters page."""
    verdict_by_heading = {
        'hard counters': 'Hard', 'hard counter': 'Hard',
        'unfavorable': 'Unfavorable', 'unfavourable': 'Unfavorable',
        'skill matchups': 'Skill', 'skill matchup': 'Skill',
        'favorable': 'Favorable', 'favourable': 'Favorable',
    }
    lane_headings = {'top': 'Baron', 'top lane': 'Baron', 'baron': 'Baron', 'baron lane': 'Baron',
                     'jungle': 'Jungle', 'mid': 'Mid', 'mid lane': 'Mid',
                     'adc': 'Dragon', 'dragon': 'Dragon', 'dragon lane': 'Dragon',
                     'support': 'Support'}
    name_lookup = {str(n).strip().casefold(): str(n).strip() for n in all_names if n}
    current_lane = champion.get('lane') or ((champion.get('roles') or [None])[0])
    current_verdict = None
    rows = []
    for section in record.get('sections', []):
        heading = re.sub(r'\s+', ' ', str(section.get('heading', '')).strip())
        low = heading.casefold()
        if low in lane_headings:
            current_lane = lane_headings[low]
            current_verdict = None
            continue
        if low in verdict_by_heading:
            current_verdict = verdict_by_heading[low]
            continue
        opponent = name_lookup.get(low)
        if current_verdict and opponent and opponent.casefold() != str(champion.get('name', '')).casefold():
            rows.append({'champion': champion.get('name'), 'opponent': opponent,
                         'verdict': current_verdict, 'lane': current_lane,
                         'sourceUrl': record.get('url')})
    unique = {}
    for row in rows:
        unique[(row['champion'], row['opponent'], row['verdict'], row['lane'])] = row
    return list(unique.values())

def load_seed():
    path=ROOT/'wrc-data.json'
    if not path.exists(): raise SystemExit('wrc-data.json is missing; refusing to create a blank database.')
    data=json.loads(path.read_text(encoding='utf-8'))
    for key,default in [('champions',[]),('guides',{}),('items',[]),('metaByLane',{}),('matchups',[]),('synergies',[]),('pages',[]),('championPages',{}),('sourcePages',{}),('coverage',{})]:
        data.setdefault(key,default)
    return data

def main():
    ap=argparse.ArgumentParser(description='Synchronize public WildRiftCore pages into the local offline database.')
    ap.add_argument('--delay',type=float,default=1.5,help='minimum seconds between page requests (default: 1.5)')
    ap.add_argument('--max-pages',type=int,default=1200,help='maximum HTML pages to capture (default: 1200)')
    ap.add_argument('--no-sitemap',action='store_true',help='discover pages from public section hubs only')
    ap.add_argument('--download-images',action='store_true',help='download champion portraits linked by WildRiftCore after checking each image host robots.txt')
    args=ap.parse_args()
    if args.delay<1.0: raise SystemExit('Delay must be at least 1.0 seconds to keep requests polite.')
    print('Reading robots.txt…')
    try: robots=read_robots()
    except Exception as exc: raise SystemExit(f'Cannot read robots.txt; stopping without crawling: {exc}')
    data=load_seed(); discovered=[]
    if not args.no_sitemap:
        for sm in sitemap_candidates(robots): discovered.extend(parse_sitemap(sm))
    discovered += [BASE+path for path in HUBS.values()]
    queue=list(dict.fromkeys(discovered)); seen=set(); captured=[]; item_map={x['name'].lower():x for x in data['items']}
    champion_map={x['slug']:x for x in data['champions'] if x.get('slug')}
    champion_pages={k:list(v) for k,v in data.get('championPages',{}).items()}
    page_map={p.get('url'):p for p in data.get('pages',[]) if p.get('url')}
    def download_portrait(slug, image_url):
        nonlocal last_request
        host=urlparse(image_url).netloc.lower()
        if not host: return None
        if host not in asset_robots:
            robots_url=f'https://{host}/robots.txt'
            try:
                raw,_,_=get(robots_url)
                rp=urllib.robotparser.RobotFileParser(); rp.set_url(robots_url); rp.parse(raw.decode('utf-8','replace').splitlines())
                asset_robots[host]=rp
            except Exception:
                asset_robots[host]=None
        rp=asset_robots[host]
        if rp is None or not rp.can_fetch(UA,image_url): return None
        wait=delay-(time.monotonic()-last_request)
        if wait>0: time.sleep(wait)
        try:
            raw,ctype,_=get(image_url); last_request=time.monotonic()
            if not ctype.startswith('image/'): return None
            ext=mimetypes.guess_extension(ctype.split(';')[0]) or '.img'
            if ext=='.jpe': ext='.jpg'
            dest=ROOT/'assets'/'champions'/f'{slug}{ext}'
            dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(raw)
            return str(dest.relative_to(ROOT)).replace('\\','/')
        except Exception as exc:
            last_request=time.monotonic(); print('IMAGE SKIP',slug,str(exc)[:100]); return None
    site_delay=robots.crawl_delay(UA) or 0
    rate=robots.request_rate(UA)
    rate_delay=(rate.seconds/rate.requests) if rate and rate.requests else 0
    delay=max(1.0,args.delay,site_delay,rate_delay); last_request=0.0; asset_robots={}
    while queue and len(captured)<args.max_pages:
        url=queue.pop(0)
        if url in seen: continue
        seen.add(url)
        if not allowed(robots,url): continue
        wait=delay-(time.monotonic()-last_request)
        if wait>0: time.sleep(wait)
        try:
            raw,ctype,final_url=get(url); last_request=time.monotonic()
            if 'html' not in ctype: continue
            html=raw.decode('utf-8','replace'); parser=PageParser(); parser.feed(html)
            blocks=[b for b in parser.blocks if b['text']]
            text='\n'.join(b['text'] for b in blocks)
            final=canonical(final_url) or url
            images=[]
            for im in parser.images:
                src=normalize_image(im.get('src'),final)
                if src: images.append({**im,'src':src})
            if parser.meta.get('og:image'):
                og=normalize_image(parser.meta['og:image'],final)
                if og and not any(x['src']==og for x in images): images.insert(0,{'src':og,'alt':parser.meta.get('og:title','')})
            links=[]
            for a in parser.links:
                href=urljoin(final,a['href'])
                links.append({**a,'url':href})
                nxt=canonical(href)
                if nxt and nxt not in seen and any(nxt.startswith(BASE+x) for x in ALLOWED_PATHS): queue.append(nxt)
            record={'url':final,'title':parser.title or parser.meta.get('og:title',''),
                    'description':parser.meta.get('description') or parser.meta.get('og:description',''),
                    'headings':[b['text'] for b in blocks if b['tag'] in ('h1','h2','h3','h4','h5')],
                    'sections':sections_from_blocks(blocks),'text':text,'fullText':' '.join(parser.all_text),'images':images,
                    'links':links,'jsonld':parser.jsonld}
            page_map[final]=record; captured.append(final)
            path=urlparse(final).path
            m=re.search(r'/en/champions/([^/]+)/',path)
            if m:
                slug=m.group(1)
                cp=champion_pages.setdefault(slug,[])
                if not any(x.get('url')==final for x in cp): cp.append(record)
                champ=champion_map.get(slug)
                if champ:
                    champ['sourceUrl']=BASE+f'/en/champions/{slug}/'
                    name=champ.get('name','').lower()
                    candidate=champ.get('image') if str(champ.get('image') or '').startswith('http') else None
                    if not candidate:
                        candidate=next((im['src'] for im in images if name and (name in (im.get('alt','')+' '+im.get('title','')).lower() or slug in im['src'].lower())),None)
                    if candidate and not champ.get('image'): champ['image']=candidate
                    if candidate and args.download_images and str(champ.get('image') or '').startswith('http'):
                        local=download_portrait(slug,candidate)
                        if local: champ['image']=local
                    roles=detect_roles(text[:900])
                    if roles:
                        existing=champ.get('roles') or ([champ.get('lane')] if champ.get('lane') else [])
                        champ['roles']=list(dict.fromkeys([x for x in existing+roles if x]))
                    archetype=detect_archetype(text[:900])
                    if archetype: champ['archetype']=archetype
                    if path.rstrip('/').endswith('/'+slug):
                        ms,ss=parse_matchup_wall(record['fullText'],champ.get('name',slug),champ.get('lane') or (champ.get('roles') or [None])[0],champion_map.keys() and [x.get('name','') for x in data['champions']],final)
                        for row in ms:
                            if not any(x.get('champion')==row['champion'] and x.get('opponent')==row['opponent'] and x.get('verdict')==row['verdict'] and x.get('lane')==row['lane'] for x in data['matchups']): data['matchups'].append(row)
                        for row in ss:
                            if not any(x.get('champion')==row['champion'] and x.get('partner')==row['partner'] and x.get('tier')==row['tier'] for x in data['synergies']): data['synergies'].append(row)
                    stats=extract_stats(text[:2500])
                    if stats:
                        champ['pageStats']={**(champ.get('pageStats') or {}),**stats,'scope':'WildRiftCore champion page · 30-day page stats'}
                    if path.rstrip('/').endswith('/counters'):
                        counter_rows=parse_counter_page(record,champ,[x.get('name','') for x in data['champions']])
                        for row in counter_rows:
                            if not any(x.get('champion')==row['champion'] and x.get('opponent')==row['opponent'] and x.get('verdict')==row['verdict'] and x.get('lane')==row['lane'] for x in data['matchups']):
                                data['matchups'].append(row)
            if '/items/' in path:
                for item in extract_item_records(record):
                    image=next((im['src'] for im in images if item['name'].lower() in (im.get('alt','')+' '+im.get('title','')).lower()),None)
                    if image: item['image']=image
                    key=item['name'].lower(); prior=item_map.get(key,{})
                    item_map[key]={**prior,**item}
            print(f'[{len(captured)}] {final}')
        except (HTTPError,URLError,TimeoutError,Exception) as exc:
            last_request=time.monotonic(); print('SKIP',url,str(exc)[:180])
            # Continue sequentially; no retries against blocked or failed endpoints.
    data['schemaVersion']=2
    data['version']='3.12.0'
    data['championPages']=champion_pages
    data['pages']=list(page_map.values())
    data['items']=sorted(item_map.values(),key=lambda x:x['name'].lower())
    data['sourcePages']={**data.get('sourcePages',{}),**{k:BASE+v for k,v in HUBS.items()}}
    data['source']={**data.get('source',{}),'name':'WildRiftCore','url':BASE,
                    'captured':time.strftime('%Y-%m-%d %H:%M:%S UTC'),'lastSync':'success' if captured else 'no-pages-captured'}
    # Coverage distinguishes what the website advertises from what this local snapshot actually contains.
    champion_detail_count=sum(1 for k,v in champion_pages.items() if v)
    data['coverage']={**data.get('coverage',{}),'champions':len(data['champions']),
        'championPagesCaptured':champion_detail_count,'championGuidesCaptured':sum(1 for x in data['champions'] if x.get('slug') in champion_pages),'pagesCaptured':len(data['pages']),
        'counterPagesCaptured':sum(1 for p in data['pages'] if '/counters/' in p.get('url','')),'buildPagesCaptured':sum(1 for p in data['pages'] if '/builds/' in p.get('url','')),'synergyPagesCaptured':sum(1 for p in data['pages'] if '/synergies/' in p.get('url','')),
        'championSpecificMatchupsCaptured':len(data.get('matchups',[])),
        'matchupsCaptured':len(data.get('matchups',[])),'synergiesCaptured':len(data.get('synergies',[])),'championPortraitsCaptured':sum(1 for x in data['champions'] if x.get('image')),'rankTiersCaptured':data.get('coverage',{}).get('rankTiersCaptured',1),
        'itemsCaptured':len(data['items']),'itemsWithDescriptionsCaptured':sum(1 for x in data['items'] if x.get('description')),'itemRecordsStored':len(data['items']),'itemsAvailableOnSite':data.get('coverage',{}).get('itemsAvailableOnSite',111),
        'guidePagesAvailableOnSite':data.get('coverage',{}).get('guidePagesAvailableOnSite',715),
        'note':'Only public pages actually captured are stored. Website-advertised totals are separate and are not represented as locally downloaded.'}
    out=ROOT/'wrc-data.json'; js=ROOT/'wrc-data.js'
    payload=json.dumps(data,ensure_ascii=False,separators=(',',':'))
    out.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    js.write_text('window.WRC_DB='+payload+';\n',encoding='utf-8')
    print('\nSync complete:',len(captured),'new pages,',len(champion_pages),'champion page groups,',len(data['items']),'item records.')
    print('Offline database written to wrc-data.json and wrc-data.js.')
    print('A skipped, blocked, or uncaptured page remains absent; it is never filled with guessed game data.')

if __name__=='__main__': main()
