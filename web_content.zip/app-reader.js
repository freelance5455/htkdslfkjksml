/* JOSTECH — PARCOURS DISCIPLINE, LECTEUR DE COURS & SIGNALEMENT */
function openDiscipline(discId, lvl = 1) {
  const d = DISCIPLINES.find(x => x.id === discId); if (!d) return;
  currentDiscId = discId;
  const act = d.status === "pilot" || d.status === "active", badge = $("disc-detail-badge");
  badge.className = act ? "pill-badge pilot" : "pill-badge";
  badge.textContent = d.status === "pilot" ? "Discipline Pilote V1" : (d.status === "active" ? "Publiée par Admin" : "En cours de déploiement");
  $("disc-detail-title").textContent = `${d.num}. ${d.title}`;
  $("disc-detail-desc").textContent = d.shortDesc;
  const lw = $("disc-levels-wrap"), uw = $("disc-upcoming-wrap");
  if (d.levels && Object.keys(d.levels).length) { lw.style.display = "block"; uw.style.display = "none"; renderDisciplineLevel(d, lvl); }
  else {
    lw.style.display = "none"; uw.style.display = "block";
    $("disc-upcoming-msg").innerHTML = "<strong>En cours de déploiement :</strong> Contenu bientôt publié via l'espace administrateur. Programme officiel :";
    $("disc-upcoming-topics").innerHTML = d.topics.map(t => `<li>${escapeHtml(t)}</li>`).join("");
  }
  navigateTo("discipline-detail");
}

function renderDisciplineLevel(d, lvl) {
  currentLevelNum = lvl;
  document.querySelectorAll("#disc-levels-tabs .level-tab").forEach(b => b.classList.toggle("active", Number(b.dataset.level) === lvl));
  const lo = d.levels[lvl], sub = $("disc-level-subtitle"), box = $("disc-chapters-container");
  box.innerHTML = "";
  if (!lo || !lo.chapters || !lo.chapters.length) { sub.textContent = ""; box.innerHTML = `<div class="info-banner">Aucune leçon publiée dans ce niveau.</div>`; return; }
  sub.textContent = lo.subtitle;
  const done = getCompletedLessons();
  lo.chapters.forEach(chap => {
    const card = document.createElement("div"); card.className = "chapter-card";
    card.innerHTML = `<h4 class="chapter-title">${escapeHtml(chap.title)}</h4>`;
    chap.lessons.forEach(ls => {
      const ok = done.includes(ls.id), row = document.createElement("div");
      row.className = ok ? "lesson-row done" : "lesson-row";
      row.onclick = () => openLesson(d.id, lvl, ls.id);
      row.innerHTML = `<div class="lesson-meta"><strong>${escapeHtml(ls.title)}</strong><span>Lecture : ${escapeHtml(ls.duration)}</span></div><div class="lesson-status">${ok ? "✓" : "▶"}</div>`;
      card.appendChild(row);
    });
    box.appendChild(card);
  });
}
document.querySelectorAll("#disc-levels-tabs .level-tab").forEach(b => b.addEventListener("click", () => { const d = DISCIPLINES.find(x => x.id === currentDiscId); if (d) renderDisciplineLevel(d, Number(b.dataset.level)); }));

function copyTextSafe(txt) {
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(() => showToast("Copié !")).catch(() => fallbackCopy(txt));
  else fallbackCopy(txt);
}
function fallbackCopy(txt) {
  const ta = document.createElement("textarea"); ta.value = txt; ta.style.cssText = "position:fixed;opacity:0";
  document.body.appendChild(ta); ta.select();
  try { document.execCommand("copy"); showToast("Copié !"); } catch (e) {}
  document.body.removeChild(ta);
}

async function openLesson(discId, lvl, lessonId) {
  const d = DISCIPLINES.find(x => x.id === discId);
  if (!d || !d.levels || !d.levels[lvl]) return;
  let ls = null; d.levels[lvl].chapters.forEach(c => { const f = c.lessons.find(x => x.id === lessonId); if (f) ls = f; });
  if (!ls) return;
  if (typeof BOOK_FILES !== "undefined" && BOOK_FILES[lessonId] && !ls._bookLoaded) {
    const offBooks = safeLoadJSON("jostech_offline_books", {});
    if (offBooks[lessonId]) { const sc = document.createElement("script"); sc.textContent = offBooks[lessonId]; document.body.appendChild(sc); }
    else {
      try {
        const res = await fetch(BOOK_FILES[lessonId] + "?t=" + Date.now());
        if (res.ok) { const txt = await res.text(); if (txt.trim()) { const sc = document.createElement("script"); sc.textContent = txt; document.body.appendChild(sc); } }
      } catch (e) {}
    }
  }
  renderLessonView(d, discId, lvl, ls);
}

function updateFavButton(id) {
  const btn = $("btn-fav-lesson"); if (!btn || typeof isLessonFavorite !== "function") return;
  const fav = isLessonFavorite(id);
  btn.classList.toggle("fav-active", fav); btn.textContent = fav ? "★ Favori" : "☆ Favori";
}

function renderLessonView(d, discId, lvl, ls) {
  currentDiscId = discId; currentLevelNum = lvl; currentLessonId = ls.id;
  saveRecentLesson(d, lvl, ls);
  $("btn-back-to-disc").onclick = () => openDiscipline(discId, lvl);
  $("lesson-duration").textContent = ls.duration;
  $("lesson-breadcrumb").textContent = `${d.title} • Niveau ${lvl}`;
  $("lesson-title").textContent = ls.title;
  if ($("btn-lesson-quiz")) $("btn-lesson-quiz").onclick = () => {
    if (typeof QUIZZES !== "undefined" && typeof startQuiz === "function") {
      const m = QUIZZES.find(q => q.discId === discId && q.mode === "training") || QUIZZES.find(q => q.discId === discId);
      if (m) return startQuiz(m.id);
    }
    navigateTo("exams");
  };
  updateFavButton(ls.id);
  if ($("btn-fav-lesson")) $("btn-fav-lesson").onclick = () => { if (typeof toggleFavoriteLesson === "function") { toggleFavoriteLesson(d, lvl, ls); updateFavButton(ls.id); } };

  $("lesson-objectives-box").innerHTML = `<h4>Objectifs pédagogiques</h4><ul>${ls.objectives.map(o => `<li>${escapeHtml(o)}</li>`).join("")}</ul>`;
  $("lesson-prereq-box").innerHTML = `<h4>Prérequis</h4><ul>${ls.prerequisites.map(p => `<li>${escapeHtml(p)}</li>`).join("")}</ul>`;

  const secBox = $("lesson-sections"); secBox.innerHTML = "";
  ls.sections.forEach(sec => {
    const el = document.createElement("div");
    const bul = (sec.bullets && sec.bullets.length) ? `<ul style="margin-top:8px;">${sec.bullets.map(b => `<li>${escapeHtml(b)}</li>`).join("")}</ul>` : "";
    if (sec.type === "definition") { el.className = "lesson-box definition"; el.innerHTML = `<h4>Définition — ${escapeHtml(sec.term)}</h4>${renderParagraphsHtml(sec.text)}${bul}`; }
    else if (sec.type === "theory") { el.className = "lesson-box"; el.innerHTML = `<h4>${escapeHtml(sec.title)}</h4>${renderParagraphsHtml(sec.text)}${bul}`; }
    else if (sec.type === "example") { el.className = "lesson-box example"; el.innerHTML = `<h4>Exemple — ${escapeHtml(sec.title)}</h4>${renderParagraphsHtml(sec.text)}${bul}`; }
    else if (sec.type === "warning") { el.className = "lesson-box"; el.style.borderLeft = "4px solid #f59e0b"; el.innerHTML = `<h4>⚠ ${escapeHtml(sec.title)}</h4>${renderParagraphsHtml(sec.text)}${bul}`; }
    else if (sec.type === "table") {
      el.className = "lesson-box";
      el.innerHTML = `<h4>${escapeHtml(sec.title)}</h4><div class="table-wrap"><table class="lesson-table"><thead><tr>${sec.headers.map(h => `<th>${escapeHtml(h)}</th>`).join("")}</tr></thead><tbody>${sec.rows.map(r => `<tr>${r.map(c => `<td>${escapeHtml(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
    } else if (sec.type === "code") {
      el.className = "code-card";
      const hd = document.createElement("div"); hd.className = "code-header";
      const sp = document.createElement("span"); sp.textContent = sec.lang;
      const bt = document.createElement("button"); bt.className = "copy-btn"; bt.textContent = "Copier"; bt.onclick = () => copyTextSafe(sec.code);
      hd.appendChild(sp); hd.appendChild(bt);
      const pre = document.createElement("pre"); pre.className = "code-pre"; pre.textContent = sec.code;
      el.appendChild(hd); el.appendChild(pre);
    }
    secBox.appendChild(el);
  });

  const exBox = $("lesson-exercise-box"); exBox.innerHTML = "";
  const exList = Array.isArray(ls.exercises) ? ls.exercises : (ls.exercise ? [ls.exercise] : []);
  exBox.style.display = exList.length ? "block" : "none";
  exList.forEach((ex, i) => {
    const w = document.createElement("div");
    if (i > 0) w.style.cssText = "margin-top:18px;padding-top:16px;border-top:1px solid var(--border-metal);";
    const eh = document.createElement("h4"); eh.textContent = ex.title || (exList.length > 1 ? `Exercice ${i + 1}` : "Exercice");
    const eq = document.createElement("div"); eq.style.marginBottom = "12px"; eq.innerHTML = renderParagraphsHtml(ex.question);
    const eb = document.createElement("button"); eb.className = "btn-secondary"; eb.textContent = "Voir le corrigé détaillé";
    const es = document.createElement("div"); es.className = "solution-box"; es.textContent = ex.solution;
    eb.onclick = () => { eb.textContent = es.classList.toggle("open") ? "Masquer le corrigé" : "Voir le corrigé détaillé"; };
    w.appendChild(eh); w.appendChild(eq); w.appendChild(eb); w.appendChild(es); exBox.appendChild(w);
  });

  $("lesson-summary-box").innerHTML = `<h4>Résumé à retenir</h4>${renderParagraphsHtml(ls.summary)}`;
  $("lesson-refs-box").innerHTML = `<h4>Références bibliographiques</h4><ul>${ls.references.map(r => `<li>${escapeHtml(r)}</li>`).join("")}</ul>`;
  updateCompleteButton(ls.id);
  $("btn-complete-lesson").onclick = () => toggleLessonComplete(ls.id);
  $("btn-report-error").onclick = () => openReportModal(ls);

  const seq = []; [1, 2, 3].forEach(l => { if (d.levels[l]) d.levels[l].chapters.forEach(c => c.lessons.forEach(x => seq.push({ l, x }))); });
  const idx = seq.findIndex(item => item.x.id === ls.id);
  $("btn-prev-lesson").disabled = idx <= 0;
  $("btn-prev-lesson").onclick = () => { if (idx > 0) openLesson(discId, seq[idx - 1].l, seq[idx - 1].x.id); };
  $("btn-next-lesson").disabled = idx < 0 || idx >= seq.length - 1;
  $("btn-next-lesson").onclick = () => { if (idx >= 0 && idx < seq.length - 1) openLesson(discId, seq[idx + 1].l, seq[idx + 1].x.id); };
  navigateTo("lesson");
}

function updateCompleteButton(id) {
  const b = $("btn-complete-lesson"); if (!b) return;
  const ok = getCompletedLessons().includes(id);
  b.classList.toggle("completed", ok);
  b.textContent = ok ? "✓ Leçon terminée (Cliquer pour annuler)" : "✓ Marquer cette leçon comme terminée";
}
function toggleLessonComplete(id) {
  let done = getCompletedLessons();
  if (done.includes(id)) { done = done.filter(x => x !== id); showToast("Leçon retirée"); }
  else { done.push(id); showToast("Bravo ! Leçon validée."); }
  safeSaveJSON("jostech_completed_lessons", done); updateCompleteButton(id); updateDashboardStats();
}

const reportModal = $("report-modal");
function openReportModal(ls) { reportingLesson = ls; $("report-lesson-name").textContent = "Leçon : " + ls.title; $("report-message").value = ""; reportModal.classList.add("open"); }
function closeReportModal() { reportModal.classList.remove("open"); }
$("report-submit-btn").addEventListener("click", () => {
  const msg = $("report-message").value.trim(); if (!msg) return showToast("Décrivez le problème.");
  const r = safeLoadJSON("jostech_reports", []); r.push({ lessonId: reportingLesson ? reportingLesson.id : "", message: msg, date: new Date().toISOString() });
  safeSaveJSON("jostech_reports", r); closeReportModal(); showToast("Merci ! Signalement enregistré.");
});