/* JOSTECH — COURS 08 : ROBOTIQUE & SYSTÈMES EMBARQUÉS */
registerDisciplineLevels(8, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "Électronique de base, capteurs, actionneurs et loi d'Ohm.",
    chapters: [{
      id: "rob-1-1", title: "Chapitre 1 : Électronique et Chaîne d'Action",
      lessons: [{
        id: "rob-1-1-1", title: "Leçon 1 : Loi d'Ohm, Capteurs et Actionneurs", duration: "25 min",
        objectives: ["Appliquer la loi d'Ohm U = R × I.", "Distinguer capteurs (entrées) et actionneurs (sorties)."],
        prerequisites: ["Notions de physique élémentaire."],
        sections: [
          { type: "definition", term: "Chaîne fonctionnelle d'un robot", text: "Un robot perçoit son environnement grâce aux Capteurs (ultrasons, température, caméra), réfléchit via son Microcontrôleur, et agit physiquement grâce aux Actionneurs (moteurs DC, servomoteurs, relais, LED)." },
          { type: "theory", title: "Loi d'Ohm (U = R × I)", text: "La tension U (Volts) égale la résistance R (Ohms) multipliée par l'intensité du courant I (Ampères). On place toujours une résistance en série devant une LED pour limiter le courant et éviter de la griller." }
        ],
        exercise: {
          question: "Une sortie Arduino délivre 5V. Une LED consomme 2V et supporte 20 mA (0,02 A). Quelle résistance minimale R = (5 - 2) / 0,02 faut-il placer en série ?",
          solution: "R = 3V / 0,02A = 150 Ohms (en pratique on choisit souvent 220 Ohms par sécurité)."
        },
        summary: "Capteurs = sens du robot ; Actionneurs = muscles du robot ; Loi d'Ohm = protection électrique indispensable.",
        references: ["Monk, S. — Electronics Cookbook."]
      }]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "Microcontrôleurs Arduino, signaux numériques, analogiques et PWM.",
    chapters: [{
      id: "rob-2-1", title: "Chapitre 2 : Programmation Arduino & PWM",
      lessons: [{
        id: "rob-2-1-1", title: "Leçon 1 : setup(), loop(), ADC et Signal PWM", duration: "30 min",
        objectives: ["Structurer un programme Arduino (C++).", "Contrôler la vitesse d'un moteur via PWM (analogWrite)."],
        prerequisites: ["Niveau 1 — Robotique et bases C/C++."],
        sections: [
          { type: "code", lang: "C++ Arduino — Lecture capteur & LED PWM", code: "void setup() {\n  pinMode(9, OUTPUT); // Broche PWM\n}\nvoid loop() {\n  int val = analogRead(A0);      // Lit 0..1023 (ADC 10 bits)\n  int pwm = map(val, 0, 1023, 0, 255);\n  analogWrite(9, pwm);           // Régule la puissance\n  delay(50);\n}" },
          { type: "theory", title: "Comment fonctionne le PWM ?", text: "Un microcontrôleur ne sort que 0V ou 5V. Pour faire tourner un moteur à mi-vitesse, il allume et éteint le 5V des milliers de fois par seconde : avec un rapport cyclique de 50 %, le moteur reçoit en moyenne 2,5V." }
        ],
        exercise: {
          question: "Un convertisseur analogique-numérique (ADC) sur 10 bits donne une valeur de 0 à 1023 pour 0V à 5V. Quelle valeur numérique correspond environ à 2,5V ?",
          solution: "La moitié de 1023, soit environ 512."
        },
        summary: "Arduino exécute setup() une fois puis répète loop() indéfiniment, combinant lecture ADC et pilotage PWM.",
        references: ["Arduino Official Reference."]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Systèmes embarqués temps réel, asservissement PID et automatisation.",
    chapters: [{
      id: "rob-3-1", title: "Chapitre 3 : Automatisation & Contrôle PID",
      lessons: [{
        id: "rob-3-1-1", title: "Leçon 1 : Boucle Fermée, Régulateur PID et Temps Réel", duration: "30 min",
        objectives: ["Opposer boucle ouverte et boucle fermée.", "Comprendre les 3 termes P, I et D d'un asservissement."],
        prerequisites: ["Niveau 2 — Robotique et mathématiques."],
        sections: [
          { type: "definition", term: "Régulateur PID (Proportionnel - Intégral - Dérivé)", text: "Pour maintenir un drone stable ou un bras robotisé exactement sur sa cible (consigne) malgré le vent ou la charge, le PID calcule la correction selon l'erreur e(t) = Consigne - Mesure :\n• P : corrige proportionnellement à l'erreur actuelle.\n• I : élimine l'erreur statique accumulée dans le temps.\n• D : anticipe la vitesse de variation pour amortir les oscillations." },
          { type: "warning", title: "Piège temps réel : delay()", text: "Dans un robot industriel rapide, delay(1000) bloque tout le processeur pendant 1 seconde (le robot devient aveugle aux obstacles !). On utilise des interruptions matérielles ou millis() non bloquant." }
        ],
        exercise: {
          question: "Pourquoi un robot suiveur de ligne uniquement Proportionnel (P) trop fort oscille-t-il en zigzag ?",
          solution: "Parce qu'un gain P élevé corrige brusquement sans freiner à l'approche de la ligne ; ajouter un terme Dérivé (D) amortit ce dépassement."
        },
        summary: "L'automatisation industrielle moderne repose sur le contrôle en boucle fermée (PID), des bus embarqués fiables (I2C, SPI, CAN) et du code temps réel non bloquant.",
        references: ["Siciliano, B. — Robotics: Modelling, Planning and Control."]
      }]
    }]
  }
});