# SkyWeather Android project

This is an Android Studio project wrapping the SkyWeather demo UI in a WebView. The weather values are sample data, not live forecasts.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`SkyWeather`) as a project.
3. Let Gradle sync and install the Android SDK for API 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (typically `app/build/outputs/apk/debug/app-debug.apk`).

No weather API key or network access is needed for this demo. Live weather requires adding a weather provider and Internet permission.
