export default {

    create() {

        const content =
            document.createElement("div");

        content.style.cssText = `
            padding:20px;
            height:100%;
            display:flex;
            flex-direction:column;
            gap:15px;
        `;

        content.innerHTML = `

            <input
                id="calcDisplay"
                readonly
                value="0"
                style="
                    width:100%;
                    box-sizing:border-box;
                    padding:18px;
                    border:0;
                    outline:0;
                    border-radius:14px;
                    background:rgba(255,255,255,.07);
                    color:white;
                    font-size:28px;
                    text-align:right;
                "
            >

            <div style="
                display:grid;
                grid-template-columns:
                    repeat(4,1fr);
                gap:8px;
                flex:1;
            ">

                ${[
                    "7","8","9","/",
                    "4","5","6","*",
                    "1","2","3","-",
                    "0",".","C","+",
                    "="
                ].map(key => `
                    <button
                        class="calc-button"
                        data-key="${key}"
                    >
                        ${key}
                    </button>
                `).join("")}

            </div>
        `;

        const display =
            content.querySelector("#calcDisplay");

        let expression = "";

        content
            .querySelectorAll(".calc-button")
            .forEach(button => {

                button.addEventListener(
                    "click",
                    () => {

                        const key =
                            button.dataset.key;

                        if (key === "C") {

                            expression = "";

                            display.value = "0";

                            return;
                        }

                        if (key === "=") {

                            try {

                                expression =
                                    String(
                                        Function(
                                            `"use strict";
                                            return (${expression})`
                                        )()
                                    );

                                display.value =
                                    expression;

                            } catch {

                                expression = "";

                                display.value =
                                    "Error";

                            }

                            return;
                        }

                        expression += key;

                        display.value =
                            expression;

                    }
                );

            });

        return WindowManager.create({

            appId: "calculator",

            title: "Calculator",

            icon: "＋",

            width: 350,

            height: 470,

            content

        });

    }

};