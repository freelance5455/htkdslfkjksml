export default {

    create() {

        const content =
            document.createElement("div");

        content.style.cssText = `
            width:100%;
            height:100%;
            box-sizing:border-box;
            padding:18px;
            background:#07070b;
            color:#d9d9df;
            font-family:monospace;
            font-size:13px;
            overflow:auto;
        `;

        content.innerHTML = `
            <div>
                Nexora Terminal
            </div>

            <div style="
                opacity:.45;
                margin-top:5px;
            ">
                Nexora System Shell
            </div>

            <div
                id="terminalOutput"
                style="margin-top:20px"
            >
                Welcome to Nexora.
            </div>

            <div style="
                display:flex;
                margin-top:12px;
            ">

                <span style="color:#9b9bff">
                    nexora
                </span>

                <span>
                    :~$
                </span>

                <input
                    id="terminalInput"
                    autocomplete="off"
                    style="
                        flex:1;
                        border:0;
                        outline:0;
                        background:transparent;
                        color:white;
                        font:inherit;
                        margin-left:8px;
                    "
                >

            </div>
        `;

        const input =
            content.querySelector(
                "#terminalInput"
            );

        const output =
            content.querySelector(
                "#terminalOutput"
            );

        input.addEventListener(
            "keydown",
            event => {

                if (event.key !== "Enter") {
                    return;
                }

                const command =
                    input.value.trim();

                input.value = "";

                if (!command) return;

                const line =
                    document.createElement("div");

                line.style.marginTop = "8px";

                if (command === "help") {

                    line.textContent =
                        "Available commands: help, clear, apps, version";

                } else if (command === "clear") {

                    output.innerHTML = "";

                } else if (command === "apps") {

                    output.textContent =
                        Nexora.System
                            .getApps()
                            .map(app => app.id)
                            .join(", ");

                } else if (command === "version") {

                    output.textContent =
                        "Nexora OS v" +
                        Nexora.System.version;

                } else {

                    line.textContent =
                        "Command not found: " +
                        command;

                }

                if (command !== "clear") {

                    output.appendChild(line);

                }

            }
        );

        const window =
            WindowManager.create({

                appId: "terminal",

                title: "Terminal",

                icon: ">_",

                width: 680,

                height: 430,

                content

            });

        setTimeout(
            () => input.focus(),
            100
        );

        return window;

    }

};