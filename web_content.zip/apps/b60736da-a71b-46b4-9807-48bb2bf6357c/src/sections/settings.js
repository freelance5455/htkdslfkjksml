/* SmartiQo · Admin settings */
window.PAGES = window.PAGES || {};
window.PAGES.settings = (function () {

  let TAB = 'departments';
  let SETTINGS = {};
  let DEPTS = [], FMS = [], PEOPLE = [], ROLES = [], FORMS = [];

  const TABS = [
    ['departments', 'Departments'], ['fms', 'FMS'], ['people', 'People'], ['roles', 'Roles'],
    ['forms', 'Forms'], ['calendar', 'Google Calendar'], ['notifications', 'Notifications'],
    ['sla', 'SLA & escalation'], ['reports', 'Reports'], ['branding', 'Branding'], ['audit', 'Audit log']
  ];

  function get(key, fallback) {
    const r = SETTINGS[key];
    if (!r) return fallback;
    try { return JSON.parse(r); } catch (e) { return fallback; }
  }
  async function save(key, obj) {
    await window.agentdb.executeQuery('save_setting', { key: key, value: JSON.stringify(obj) });
    SETTINGS[key] = JSON.stringify(obj);
  }
  function sw(on, id, cls) {
    return '<button class="switch ' + (on ? 'on' : '') + '" id="' + id + '" type="button" aria-pressed="' + (on ? 'true' : 'false') + '"></button>';
  }

  async function render(el) {
    if ('settingsTab' in App.state) { TAB = App.state.settingsTab || 'departments'; delete App.state.settingsTab; }
    const me = Auth.getSession();

    let s, d, f, p, r, fm;
    try {
      [s, d, f, p, r, fm] = await Promise.all([
        window.agentdb.executeQuery('load_settings', {}),
        window.agentdb.executeQuery('load_departments', {}),
        window.agentdb.executeQuery('load_fms', { department_id: 0, status: '' }),
        window.agentdb.executeQuery('load_users', {}),
        window.agentdb.executeQuery('load_roles', {}),
        window.agentdb.executeQuery('load_forms', { department_id: 0, fms_id: 0 })
      ]);
    } catch (e) {
      el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>';
      return;
    }
    SETTINGS = {}; s.rows.forEach(x => SETTINGS[x.key] = x.value);
    DEPTS = d.rows; FMS = f.rows; PEOPLE = p.rows; ROLES = r.rows; FORMS = fm.rows;

    el.innerHTML =
      '<div class="page-head"><div><h1>Admin Settings</h1><div class="sub">Departments, people, access and platform configuration</div></div>' +
      '<div class="page-actions"><span class="pill blue">' + UI.esc(me.name) + ' · administrator</span></div></div>' +
      '<div class="tabs" id="setTabs">' + TABS.map(t => '<button data-stab="' + t[0] + '" class="' + (TAB === t[0] ? 'on' : '') + '">' + t[1] + '</button>').join('') + '</div>' +
      '<div id="setBody"></div>';

    document.querySelectorAll('[data-stab]').forEach(b => b.onclick = () => { TAB = b.dataset.stab; document.querySelectorAll('[data-stab]').forEach(x => x.classList.toggle('on', x.dataset.stab === TAB)); paint(); });
    paint();
  }

  async function paint() {
    const body = document.getElementById('setBody');
    if (!body) return;
    body.innerHTML = '<div class="loading-row">Loading…</div>';
    try {
      if (TAB === 'departments') tabDepartments(body);
      else if (TAB === 'fms') tabFms(body);
      else if (TAB === 'people') tabPeople(body);
      else if (TAB === 'roles') tabRoles(body);
      else if (TAB === 'forms') tabForms(body);
      else if (TAB === 'calendar') tabCalendar(body);
      else if (TAB === 'notifications') tabNotifications(body);
      else if (TAB === 'sla') tabSla(body);
      else if (TAB === 'reports') tabReports(body);
      else if (TAB === 'branding') tabBranding(body);
      else if (TAB === 'audit') await tabAudit(body);
    } catch (e) { body.innerHTML = '<div class="banner warn">' + UI.icon('alert', 15) + '<div>' + UI.esc(e.message) + '</div></div>'; }
  }

  /* ---------------- departments ---------------- */
  function tabDepartments(body) {
    body.innerHTML = '<div class="card"><div class="card-head"><div><h3>Departments</h3><div class="hint">' + DEPTS.length + ' departments · heads, FMS coverage and workload</div></div>' +
      '<button class="btn primary sm" id="sdAdd">' + UI.icon('plus', 13) + ' Add department</button></div><div class="card-body tight"><div class="tbl-wrap">' +
      '<table class="tbl"><thead><tr><th>Department</th><th>Code</th><th>Head</th><th class="num">FMS</th><th class="num">Employees</th><th class="num">Tasks</th><th class="num">Overdue</th><th></th></tr></thead><tbody>' +
      DEPTS.map(d => '<tr><td><div class="flex items-center gap8"><span style="width:6px;height:22px;border-radius:4px;background:' + UI.esc(d.color) + '"></span><span class="strong">' + UI.esc(d.name) + '</span></div></td>' +
        '<td class="small">' + UI.esc(d.code || '—') + '</td><td class="small">' + UI.esc(d.head_name || 'Not assigned') + '</td>' +
        '<td class="num">' + d.fms_count + '</td><td class="num">' + d.employee_count + '</td><td class="num">' + d.total_tasks + '</td>' +
        '<td class="num" style="color:' + (d.overdue ? 'var(--bad)' : 'inherit') + '">' + d.overdue + '</td>' +
        '<td class="nowrap"><button class="btn sm" data-dept="' + d.id + '">Edit</button></td></tr>').join('') +
      '</tbody></table></div></div></div>';
    body.querySelector('#sdAdd').onclick = () => window.PAGES.departments.deptModal(null);
    body.querySelectorAll('[data-dept]').forEach(b => b.onclick = () => window.PAGES.departments.deptModal(DEPTS.find(d => Number(d.id) === Number(b.dataset.dept))));
  }

  /* ---------------- fms ---------------- */
  function tabFms(body) {
    body.innerHTML = '<div class="card"><div class="card-head"><div><h3>FMS configuration</h3><div class="hint">' + FMS.length + ' processes · dashboard, sheet and form URLs</div></div>' +
      '<button class="btn primary sm" id="sfAdd">' + UI.icon('plus', 13) + ' Add FMS</button></div><div class="card-body tight"><div class="tbl-wrap">' +
      '<table class="tbl"><thead><tr><th>FMS</th><th>Department</th><th class="num">SLA</th><th class="num">Steps</th><th class="num">Overdue</th><th>Dashboard URL</th><th>Status</th><th></th></tr></thead><tbody>' +
      FMS.map(f => '<tr><td><div class="flex items-center gap8"><span class="fc-code" style="font-size:9px">' + UI.esc(f.code || 'FMS') + '</span><span class="strong">' + UI.esc(f.name) + '</span></div></td>' +
        '<td class="small">' + UI.esc(f.department_name || '—') + '</td>' +
        '<td class="num small">' + UI.hrs(f.sla_hours) + '</td><td class="num">' + f.total_tasks + '</td>' +
        '<td class="num" style="color:' + (f.overdue ? 'var(--bad)' : 'inherit') + '">' + f.overdue + '</td>' +
        '<td class="small">' + (f.dashboard_url ? '<a href="' + UI.esc(f.dashboard_url) + '" target="_blank" rel="noopener">' + UI.esc(f.dashboard_url.slice(0, 34)) + '…</a>' : '<span style="color:var(--warn)">Not configured</span>') + '</td>' +
        '<td>' + UI.pill(f.status) + '</td>' +
        '<td class="nowrap"><button class="btn sm" data-fms="' + f.id + '">Configure</button></td></tr>').join('') +
      '</tbody></table></div></div></div>';
    body.querySelector('#sfAdd').onclick = () => window.PAGES.fms.fmsModal(null);
    body.querySelectorAll('[data-fms]').forEach(b => b.onclick = () => window.PAGES.fms.fmsModal(FMS.find(f => Number(f.id) === Number(b.dataset.fms))));
  }

  /* ---------------- people ---------------- */
  const MODULE_LABELS = [
    ['overview', 'Overview'], ['departments', 'Departments'], ['fms', 'FMS Management'],
    ['tasks', 'Task Tracking'], ['site-visits', 'Site Visits'], ['service-visits', 'Service Visits'],
    ['forms', 'Forms'], ['documents', 'Documents'], ['reports', 'Reports'], ['tools', 'Business Tools'],
    ['notifications', 'Notifications']
  ];

  function accessLabel(p) {
    if (p.role === 'admin') return '<span class="pill blue">Full access</span>';
    let perms = [];
    try { perms = Array.isArray(p.permissions) ? p.permissions : JSON.parse(p.permissions || '[]'); } catch (e) { perms = []; }
    if (!perms.length) return '<span class="tag">Role default</span>';
    const names = perms.map(k => (MODULE_LABELS.find(m => m[0] === k) || [k, k])[1]);
    return '<span class="tag" title="' + UI.esc(names.join(', ')) + '">' + names.length + ' module' + (names.length === 1 ? '' : 's') + '</span>' +
      (p.view_only ? ' <span class="pill amber">View only</span>' : '');
  }

  function tabPeople(body) {
    body.innerHTML = '<div class="card"><div class="card-head"><div><h3>People and access</h3><div class="hint">' + PEOPLE.length + ' accounts · create logins, set which modules each person sees, and whether they can edit</div></div>' +
      '<button class="btn primary sm" id="spAdd" data-write>' + UI.icon('plus', 13) + ' Add person</button></div><div class="card-body tight"><div class="tbl-wrap">' +
      '<table class="tbl"><thead><tr><th>Name</th><th>Login ID</th><th>Role</th><th>Access</th><th class="num">Tasks</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead><tbody>' +
      PEOPLE.map(p => '<tr><td><div class="flex items-center gap8">' + UI.avatar(p.full_name, p.avatar_color, 'sm') + '<div><div class="strong" style="font-size:12px">' + UI.esc(p.full_name) + '</div><div class="small">' + UI.esc(p.designation || p.department_name || '') + '</div></div></div></td>' +
        '<td class="small">' + UI.esc(p.email) + '</td>' +
        '<td><span class="tag">' + UI.esc(String(p.role).replace(/_/g, ' ')) + '</span></td>' +
        '<td>' + accessLabel(p) + '</td>' +
        '<td class="num">' + (p.assigned_tasks != null ? p.assigned_tasks : '—') + '</td>' +
        '<td>' + (p.is_active ? '<span class="pill green">Active</span>' : '<span class="pill grey">Disabled</span>') + '</td>' +
        '<td class="small nowrap">' + (p.last_login ? UI.fmtDate(p.last_login) : 'Never') + '</td>' +
        '<td class="nowrap"><button class="btn sm" data-user="' + p.id + '">Edit</button> <button class="btn sm" data-pw="' + p.id + '" title="Reset password">' + UI.icon('lock', 12) + '</button></td></tr>').join('') +
      '</tbody></table></div></div></div>';
    body.querySelector('#spAdd').onclick = () => userModal(null);
    body.querySelectorAll('[data-user]').forEach(b => b.onclick = () => userModal(PEOPLE.find(p => Number(p.id) === Number(b.dataset.user))));
    body.querySelectorAll('[data-pw]').forEach(b => b.onclick = () => passwordReset(PEOPLE.find(p => Number(p.id) === Number(b.dataset.pw))));
  }

  function permsOf(p) {
    if (!p) return [];
    try { return Array.isArray(p.permissions) ? p.permissions : JSON.parse(p.permissions || '[]'); } catch (e) { return []; }
  }

  function userModal(P) {
    const isNew = !P;
    const current = permsOf(P);
    const boxes = MODULE_LABELS.map(m => '<label class="check" style="padding:6px 8px;border:1px solid var(--line);border-radius:8px;background:var(--card)">' +
      '<input type="checkbox" data-mod="' + m[0] + '"' + (current.indexOf(m[0]) >= 0 ? ' checked' : '') + '> ' + m[1] + '</label>').join('');

    UI.modal({
      title: isNew ? 'Add person and login' : 'Edit ' + P.full_name,
      size: 'wide',
      body: '<div class="form-grid">' +
        '<div class="field"><label>Full name *</label><input class="input" id="uName" value="' + UI.esc(P ? P.full_name : '') + '"></div>' +
        '<div class="field"><label>Login ID (email) *</label><input class="input" id="uEmail" type="email" placeholder="name@smartiqo.com" value="' + UI.esc(P ? P.email : '') + '"' + (isNew ? '' : ' readonly style="background:var(--line-soft)"') + '></div>' +
        '<div class="field"><label>Role</label><select class="select" id="uRole">' + ['employee', 'department_head', 'admin'].map(r => '<option value="' + r + '"' + (P && P.role === r ? ' selected' : '') + '>' + r.replace(/_/g, ' ') + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Department</label><select class="select" id="uDept"><option value="0">No department</option>' + DEPTS.map(d => '<option value="' + d.id + '"' + (P && Number(P.department_id) === Number(d.id) ? ' selected' : '') + '>' + UI.esc(d.name) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Designation</label><input class="input" id="uDesig" value="' + UI.esc(P ? P.designation || '' : '') + '"></div>' +
        '<div class="field"><label>Phone</label><input class="input" id="uPhone" value="' + UI.esc(P ? P.phone || '' : '') + '"></div>' +
        (isNew
          ? '<div class="field"><label>Set password *</label><input class="input" id="uPass" value="Welcome@123"></div>' +
            '<div class="field"><label>Account status</label><select class="select" id="uActive"><option value="true">Active</option><option value="false">Disabled</option></select></div>'
          : '<div class="field"><label>Account status</label><select class="select" id="uActive"><option value="true"' + (P.is_active ? ' selected' : '') + '>Active</option><option value="false"' + (!P.is_active ? ' selected' : '') + '>Disabled</option></select></div>') +
        '<div class="field full"><label>Module access</label>' +
        '<div class="flex wrap gap8" style="margin-bottom:8px">' +
        '<button type="button" class="btn sm" data-preset="default">Role default</button>' +
        '<button type="button" class="btn sm" data-preset="forms">Forms only</button>' +
        '<button type="button" class="btn sm" data-preset="tasks-forms">Tasks + Forms</button>' +
        '<button type="button" class="btn sm" data-preset="all">Everything</button></div>' +
        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:7px" id="uMods">' + boxes + '</div>' +
        '<div class="small" style="margin-top:6px">Nothing ticked = the role\u2019s default modules. Admins always see everything.</div></div>' +
        '<div class="field full"><label>Editing rights</label>' +
        '<label class="check" style="padding:8px 10px;border:1px solid var(--line);border-radius:8px"><input type="checkbox" id="uViewOnly"' + (P && P.view_only ? ' checked' : '') + '> <b style="font-weight:650">View only</b> \u2014 this person can open their modules but cannot create, edit or delete anything</label></div>' +
        '</div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="uSave">' + (isNew ? 'Create login' : 'Save person') + '</button>',
      onMount: (bg, close) => {
        const mods = Array.from(bg.querySelectorAll('[data-mod]'));
        const setMods = (list) => mods.forEach(m => m.checked = list.indexOf(m.dataset.mod) >= 0);
        bg.querySelectorAll('[data-preset]').forEach(b => b.onclick = () => {
          const p = b.dataset.preset;
          if (p === 'default') setMods([]);
          else if (p === 'forms') setMods(['forms']);
          else if (p === 'tasks-forms') setMods(['tasks', 'forms']);
          else setMods(MODULE_LABELS.map(m => m[0]));
        });

        bg.querySelector('#uSave').onclick = async () => {
          const name = bg.querySelector('#uName').value.trim();
          if (!name) { UI.toast('Name is required', 'bad'); return; }
          const perms = mods.filter(m => m.checked).map(m => m.dataset.mod).join(',');
          const viewOnly = bg.querySelector('#uViewOnly').checked;
          const btn = bg.querySelector('#uSave'); btn.disabled = true;
          try {
            if (isNew) {
              const email = bg.querySelector('#uEmail').value.trim();
              if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { UI.toast('Enter a valid login ID (email)', 'bad'); btn.disabled = false; return; }
              const pass = bg.querySelector('#uPass').value;
              if (pass.length < 8) { UI.toast('Password needs at least 8 characters', 'bad'); btn.disabled = false; return; }
              const r = await window.agentdb.executeQuery('create_user', {
                full_name: name, email: email, password_hash: Auth.hash(pass),
                role: bg.querySelector('#uRole').value, department_id: Number(bg.querySelector('#uDept').value) || 0,
                designation: bg.querySelector('#uDesig').value.trim(), phone: bg.querySelector('#uPhone').value.trim(),
                permissions: perms, view_only: viewOnly
              });
              await window.PAGES.departments.audit('User created', 'user', String(r.rows[0] ? r.rows[0].id : ''), email + ' · ' + (perms || 'role default') + (viewOnly ? ' · view only' : ''));
              close(); UI.toast('Login created — share the email and password privately', 'ok'); App.rerender();
            } else {
              await window.agentdb.executeQuery('update_user', {
                id: P.id, full_name: name, role: bg.querySelector('#uRole').value,
                department_id: Number(bg.querySelector('#uDept').value) || 0,
                designation: bg.querySelector('#uDesig').value.trim(), phone: bg.querySelector('#uPhone').value.trim(),
                is_active: bg.querySelector('#uActive').value === 'true',
                permissions: perms, view_only: viewOnly
              });
              await window.PAGES.departments.audit('User updated', 'user', String(P.id), name + ' · ' + (perms || 'role default') + (viewOnly ? ' · view only' : ''));
              close(); UI.toast('Person updated', 'ok'); App.rerender();
            }
          } catch (e) { btn.disabled = false; UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  function passwordReset(P) {
    UI.modal({
      title: 'Reset password · ' + P.full_name,
      body: '<div class="banner warn">' + UI.icon('lock', 15) + '<div>This replaces the stored password immediately. Share the new password with ' + UI.esc(P.full_name) + ' privately.</div></div>' +
        '<div class="field"><label>New password</label><input class="input" id="pwNew" value="Welcome@123"></div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="pwSave">Reset password</button>',
      onMount: (bg, close) => {
        bg.querySelector('#pwSave').onclick = async () => {
          const v = bg.querySelector('#pwNew').value;
          if (v.length < 8) { UI.toast('Use at least 8 characters', 'bad'); return; }
          try {
            await window.agentdb.executeQuery('reset_password', { id: P.id, password_hash: Auth.hash(v) });
            await window.PAGES.departments.audit('Password reset', 'user', String(P.id), P.email);
            close(); UI.toast('Password updated', 'ok');
          } catch (e) { UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  /* ---------------- roles ---------------- */
  function tabRoles(body) {
    body.innerHTML = '<div class="card"><div class="card-head"><div><h3>Roles and permissions</h3><div class="hint">What each role may do across SmartiQo</div></div></div><div class="card-body">' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px">' +
      ROLES.map(r => {
        let perms = [];
        try { perms = JSON.parse(r.permissions || '[]'); } catch (e) { perms = []; }
        return '<div class="card" style="margin:0;box-shadow:none"><div class="card-head"><h3 style="text-transform:capitalize">' + UI.esc(r.name.replace(/_/g, ' ')) + '</h3><button class="btn sm" data-role="' + r.id + '">Edit</button></div>' +
          '<div class="card-body"><p class="small" style="margin:0 0 8px">' + UI.esc(r.description || '') + '</p>' +
          '<div class="flex wrap gap8">' + (perms.length ? perms.map(p => '<span class="tag">' + UI.esc(String(p).replace(/_/g, ' ')) + '</span>').join('') : '<span class="small">No permissions recorded</span>') + '</div></div></div>';
      }).join('') + '</div></div></div>';
    body.querySelectorAll('[data-role]').forEach(b => b.onclick = () => roleModal(ROLES.find(r => Number(r.id) === Number(b.dataset.role))));
  }

  function roleModal(R) {
    let perms = R.permissions || '[]';
    UI.modal({
      title: 'Edit role · ' + R.name.replace(/_/g, ' '),
      body: '<div class="field"><label>Role name</label><input class="input" id="roName" value="' + UI.esc(R.name) + '"></div>' +
        '<div class="field"><label>Description</label><input class="input" id="roDesc" value="' + UI.esc(R.description || '') + '"></div>' +
        '<div class="field"><label>Permissions (JSON array)</label><textarea class="textarea" id="roPerms" style="min-height:110px;font-family:monospace;font-size:12px">' + UI.esc(perms) + '</textarea></div>' +
        '<div class="small">Example: ["view_all","manage_fms","manage_users"]. Role names are used by access rules, so rename with care.</div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="roSave">Save role</button>',
      onMount: (bg, close) => {
        bg.querySelector('#roSave').onclick = async () => {
          const p = bg.querySelector('#roPerms').value.trim() || '[]';
          try { JSON.parse(p); } catch (e) { UI.toast('Permissions must be valid JSON', 'bad'); return; }
          try {
            await window.agentdb.executeQuery('update_role', {
              id: R.id, name: bg.querySelector('#roName').value.trim(), description: bg.querySelector('#roDesc').value.trim(), permissions: p
            });
            await window.PAGES.departments.audit('Role updated', 'role', String(R.id), bg.querySelector('#roName').value.trim());
            close(); UI.toast('Role saved', 'ok'); App.rerender();
          } catch (e) { UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  /* ---------------- forms ---------------- */
  function tabForms(body) {
    body.innerHTML = '<div class="card"><div class="card-head"><div><h3>Form configuration</h3><div class="hint">' + FORMS.length + ' forms · deadlines and triggers drive pending-form tracking</div></div>' +
      '<button class="btn primary sm" id="sformAdd">' + UI.icon('plus', 13) + ' Add form</button></div><div class="card-body tight"><div class="tbl-wrap">' +
      '<table class="tbl"><thead><tr><th>Form</th><th>FMS</th><th>Department</th><th>Type</th><th class="num">Deadline</th><th>Required</th><th class="num">Submissions</th><th></th></tr></thead><tbody>' +
      FORMS.map(f => '<tr><td><div class="strong" style="font-size:12px">' + UI.esc(f.name) + '</div>' + (f.form_url ? '<div class="small"><a href="' + UI.esc(f.form_url) + '" target="_blank" rel="noopener">Open form</a></div>' : '') + '</td>' +
        '<td class="small">' + UI.esc(f.fms_name || '—') + '</td><td class="small">' + UI.esc(f.department_name || '—') + '</td>' +
        '<td class="small">' + UI.esc(String(f.form_type).replace(/_/g, ' ')) + '</td>' +
        '<td class="num">' + f.deadline_hours + 'h</td>' +
        '<td>' + (f.is_required ? '<span class="pill amber">Required</span>' : '<span class="pill grey">Optional</span>') + '</td>' +
        '<td class="num">' + f.submissions + '</td>' +
        '<td><button class="btn sm" data-fform="' + f.id + '">Edit</button></td></tr>').join('') +
      '</tbody></table></div></div></div>';
    body.querySelector('#sformAdd').onclick = () => window.PAGES.forms.formModal(null);
    body.querySelectorAll('[data-fform]').forEach(b => b.onclick = () => window.PAGES.forms.formModal(FORMS.find(f => Number(f.id) === Number(b.dataset.fform))));
  }

  /* ---------------- settings-backed tabs ---------------- */
  function settingsCard(title, hint, fields, key, saveLabel) {
    return '<div class="card" style="max-width:760px"><div class="card-head"><div><h3>' + title + '</h3><div class="hint">' + hint + '</div></div></div><div class="card-body">' +
      fields + '<button class="btn primary mt12" id="sSave">' + (saveLabel || 'Save settings') + '</button></div></div>';
  }

  function tabCalendar(body) {
    const c = get('google_calendar', {});
    body.innerHTML = '<div class="banner warn" style="max-width:760px">' + UI.icon('calendar', 15) + '<div><b>Google Calendar is not connected.</b> Saving the fields below records your intended configuration only — no OAuth token exists in this workspace, so no events are created or synced. Connect the Google Calendar integration to enable live sync.</div></div>' +
      settingsCard('Google Calendar connection', 'Used to push visit events and pull changes back',
        '<div class="form-grid">' +
        '<div class="field full"><label>OAuth client ID</label><input class="input" id="gcClient" value="' + UI.esc(c.client_id || '') + '" placeholder="xxxx.apps.googleusercontent.com"></div>' +
        '<div class="field"><label>Calendar ID</label><input class="input" id="gcCal" value="' + UI.esc(c.calendar_id || 'primary') + '"></div>' +
        '<div class="field"><label>Connected</label><input class="input" value="' + (c.connected ? 'Yes' : 'No') + '" disabled></div>' +
        '<div class="field"><label>Sync visits</label><select class="select" id="gcSync"><option value="true"' + (c.sync_enabled ? ' selected' : '') + '>Enabled once connected</option><option value="false"' + (!c.sync_enabled ? ' selected' : '') + '>Off</option></select></div>' +
        '<div class="field"><label>Add Google Meet by default</label><select class="select" id="gcMeet"><option value="false"' + (!c.meet_by_default ? ' selected' : '') + '>No</option><option value="true"' + (c.meet_by_default ? ' selected' : '') + '>Yes</option></select></div>' +
        '</div><div class="small mt8">Last sync: ' + (c.last_sync ? UI.fmtDateTime(c.last_sync) : 'never') + '</div>',
        null, null, 'Save configuration');
    body.querySelector('#sSave').onclick = async () => {
      const next = Object.assign({}, c, {
        client_id: body.querySelector('#gcClient').value.trim(), calendar_id: body.querySelector('#gcCal').value.trim() || 'primary',
        sync_enabled: body.querySelector('#gcSync').value === 'true', meet_by_default: body.querySelector('#gcMeet').value === 'true'
      });
      try { await save('google_calendar', next); await window.PAGES.departments.audit('Calendar configuration saved', 'settings', 'google_calendar', ''); UI.toast('Configuration saved', 'ok'); }
      catch (e) { UI.toast(e.message, 'bad'); }
    };
  }

  function tabNotifications(body) {
    const n = get('notification_rules', {});
    const rows = [
      ['visits', 'Visit reminders', 'Notify the assignee when a visit is scheduled or rescheduled'],
      ['approaching', 'Approaching SLA', 'Warn before a step breaches its due date'],
      ['overdue', 'Overdue escalation', 'Alert the owner and department head when a step goes overdue'],
      ['completed', 'Completion notice', 'Notify the department head when a step is completed'],
      ['pending_forms', 'Pending form reminders', 'Remind the responsible person about outstanding forms']
    ];
    body.innerHTML = settingsCard('Notification rules', 'Applied by the workflow engine when events occur',
      '<div id="ntList">' + rows.map(r => '<div class="setting-row"><div><h5>' + r[1] + '</h5><p>' + r[2] + '</p></div>' + sw(!!n[r[0]], 'nt_' + r[0]) + '</div>').join('') + '</div>' +
      '<div class="form-grid mt12"><div class="field"><label>Digest frequency</label><select class="select" id="ntFreq">' +
      ['realtime', 'daily', 'weekly'].map(f => '<option value="' + f + '"' + (n.frequency === f ? ' selected' : '') + '>' + f + '</option>').join('') + '</select></div>' +
      '<div class="field"><label>Quiet hours</label><input class="input" id="ntQuiet" value="' + UI.esc(n.quiet_hours || '20:00-08:00') + '"></div></div>');
    rows.forEach(r => {
      const b = document.getElementById('nt_' + r[0]);
      if (b) b.onclick = () => { b.classList.toggle('on'); b.setAttribute('aria-pressed', b.classList.contains('on')); };
    });
    body.querySelector('#sSave').onclick = async () => {
      const next = { frequency: body.querySelector('#ntFreq').value, quiet_hours: body.querySelector('#ntQuiet').value.trim() };
      rows.forEach(r => next[r[0]] = document.getElementById('nt_' + r[0]).classList.contains('on'));
      try { await save('notification_rules', next); UI.toast('Notification rules saved', 'ok'); } catch (e) { UI.toast(e.message, 'bad'); }
    };
  }

  function tabSla(body) {
    const s = get('sla_defaults', {});
    body.innerHTML = settingsCard('SLA and escalation', 'Defaults used when a new FMS step is created',
      '<div class="form-grid">' +
      '<div class="field"><label>Default SLA (hours)</label><input class="input" id="slaHrs" type="number" min="1" value="' + (s.default_hours || 24) + '"></div>' +
      '<div class="field"><label>Grace period (minutes)</label><input class="input" id="slaGrace" type="number" min="0" value="' + (s.grace_minutes || 15) + '"></div>' +
      '<div class="field"><label>Escalation after (hours)</label><input class="input" id="slaEsc" type="number" min="0" value="' + (s.escalation_hours || 48) + '"></div>' +
      '<div class="field"><label>Automatic overdue marking</label><select class="select" id="slaAuto"><option value="true"' + (s.auto_overdue !== false ? ' selected' : '') + '>Enabled</option><option value="false"' + (s.auto_overdue === false ? ' selected' : '') + '>Disabled</option></select></div>' +
      '</div><div class="small mt8">Overdue marking runs each time the workspace is opened; steps past their due date move to Overdue and raise a notification.</div>');
    body.querySelector('#sSave').onclick = async () => {
      try {
        await save('sla_defaults', {
          default_hours: Number(body.querySelector('#slaHrs').value) || 24,
          grace_minutes: Number(body.querySelector('#slaGrace').value) || 0,
          escalation_hours: Number(body.querySelector('#slaEsc').value) || 48,
          auto_overdue: body.querySelector('#slaAuto').value === 'true'
        });
        UI.toast('SLA settings saved', 'ok');
      } catch (e) { UI.toast(e.message, 'bad'); }
    };
  }

  function tabReports(body) {
    const r = get('report_config', {});
    body.innerHTML = settingsCard('Report defaults', 'Applied to generated PDF and printed reports',
      '<div class="form-grid">' +
      '<div class="field"><label>Paper size</label><select class="select" id="rpPaper">' + ['A4', 'A3', 'Letter'].map(p => '<option value="' + p + '"' + (r.paper === p ? ' selected' : '') + '>' + p + '</option>').join('') + '</select></div>' +
      '<div class="field"><label>Include charts on screen report</label><select class="select" id="rpCharts"><option value="true"' + (r.include_charts !== false ? ' selected' : '') + '>Yes</option><option value="false"' + (r.include_charts === false ? ' selected' : '') + '>No</option></select></div>' +
      '<div class="field full"><label>Footer line</label><input class="input" id="rpFooter" value="' + UI.esc(r.footer || '') + '"></div>' +
      '</div>');
    body.querySelector('#sSave').onclick = async () => {
      try {
        await save('report_config', {
          paper: body.querySelector('#rpPaper').value, include_charts: body.querySelector('#rpCharts').value === 'true',
          footer: body.querySelector('#rpFooter').value.trim(), logo: r.logo !== false
        });
        UI.toast('Report settings saved', 'ok');
      } catch (e) { UI.toast(e.message, 'bad'); }
    };
  }

  function tabBranding(body) {
    const b = get('branding', {});
    body.innerHTML = settingsCard('Branding', 'Company naming and accent colour',
      '<div class="form-grid">' +
      '<div class="field"><label>Company</label><input class="input" id="brCompany" value="' + UI.esc(b.company || 'SmartiQo') + '"></div>' +
      '<div class="field"><label>Product</label><input class="input" id="brProduct" value="' + UI.esc(b.product || '') + '"></div>' +
      '<div class="field full"><label>Tagline</label><input class="input" id="brTag" value="' + UI.esc(b.tagline || '') + '"></div>' +
      '<div class="field"><label>Accent colour</label><input class="input" id="brPrimary" value="' + UI.esc(b.primary || '#1D6BF3') + '" placeholder="#1D6BF3"></div>' +
      '<div class="field"><label>Ink colour</label><input class="input" id="brInk" value="' + UI.esc(b.ink || '#0A0E17') + '"></div>' +
      '</div><div class="small mt8">The accent colour is applied to this browser session immediately.</div>');
    body.querySelector('#sSave').onclick = async () => {
      const next = {
        company: body.querySelector('#brCompany').value.trim(), product: body.querySelector('#brProduct').value.trim(),
        tagline: body.querySelector('#brTag').value.trim(), primary: body.querySelector('#brPrimary').value.trim(),
        ink: body.querySelector('#brInk').value.trim()
      };
      try {
        await save('branding', next);
        if (/^#[0-9a-f]{6}$/i.test(next.primary)) document.documentElement.style.setProperty('--blue', next.primary);
        if (/^#[0-9a-f]{6}$/i.test(next.ink)) document.documentElement.style.setProperty('--ink', next.ink);
        UI.toast('Branding saved', 'ok'); App.rerender();
      } catch (e) { UI.toast(e.message, 'bad'); }
    };
  }

  async function tabAudit(body) {
    const r = await window.agentdb.executeQuery('load_audit', { limit: 100 });
    body.innerHTML = '<div class="card"><div class="card-head"><div><h3>Audit log</h3><div class="hint">Last ' + r.rows.length + ' recorded actions</div></div></div><div class="card-body tight"><div class="tbl-wrap">' +
      '<table class="tbl"><thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Entity</th><th>Details</th></tr></thead><tbody>' +
      r.rows.map(a => '<tr><td class="small nowrap">' + UI.fmtDateTime(a.created_at) + '</td><td class="small">' + UI.esc(a.actor_name || 'System') + '</td>' +
        '<td class="strong" style="font-size:12px">' + UI.esc(a.action) + '</td><td class="small">' + UI.esc(a.entity_type || '—') + ' ' + UI.esc(a.entity_id || '') + '</td>' +
        '<td class="small">' + UI.esc(a.details || '') + '</td></tr>').join('') +
      '</tbody></table></div></div></div>';
  }

  return { render };
})();
