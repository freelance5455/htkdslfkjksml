/* SmartiQo · Task tracking with SLA states */
window.PAGES = window.PAGES || {};
window.PAGES.tasks = (function () {

  const F = { fms_id: 0, department_id: 0, assigned_to: 0, status: '', search: '' };
  let DEPTS = [], FMS = [], PEOPLE = [], ROWS = [];
  let PAGE = 25;

  function consumeState() {
    const s = App.state;
    if ('taskFms' in s) { F.fms_id = Number(s.taskFms) || 0; delete s.taskFms; }
    if ('taskDept' in s) { F.department_id = Number(s.taskDept) || 0; delete s.taskDept; }
    if ('taskStatus' in s) { F.status = s.taskStatus || ''; delete s.taskStatus; }
  }

  function applyScope() {
    const u = Auth.getSession(); if (!u) return;
    if (u.role === 'department_head') { F.department_id = u.department_id || 0; F.assigned_to = 0; }
    else if (u.role === 'employee') { F.assigned_to = u.id; F.department_id = 0; }
  }

  async function fetchTasks() {
    const q = {
      fms_id: F.fms_id, department_id: F.department_id, assigned_to: F.assigned_to,
      status: F.status === 'completed' ? '' : F.status,
      from_date: App.state.from, to_date: App.state.to, search: F.search
    };
    const r = await window.agentdb.executeQuery('load_tasks', q);
    let rows = r.rows;
    if (F.status === 'completed') rows = rows.filter(x => x.status === 'completed_on_time' || x.status === 'completed_late');
    return rows;
  }

  function countStatus(rows, fn) { return rows.filter(fn).length; }

  function kpis(rows) {
    const done = countStatus(rows, r => r.status === 'completed_on_time' || r.status === 'completed_late');
    const onTime = countStatus(rows, r => r.status === 'completed_on_time');
    const pending = countStatus(rows, r => r.status === 'not_started' || r.status === 'in_progress' || r.status === 'on_hold');
    const overdue = countStatus(rows, r => r.status === 'overdue');
    return '<div class="kpi-grid">' +
      '<div class="kpi blue"><div class="k-top"><span class="k-lbl">Tasks in view</span><span class="k-ico">' + UI.icon('checks', 14) + '</span></div><div class="k-val">' + UI.n(rows.length) + '</div><div class="k-sub">' + UI.esc(App.rangeLabel()) + '</div></div>' +
      '<div class="kpi ok"><div class="k-top"><span class="k-lbl">Completed</span><span class="k-ico">' + UI.icon('checkCircle', 14) + '</span></div><div class="k-val">' + UI.n(done) + '</div><div class="k-sub">' + UI.n(onTime) + ' on time · ' + UI.n(done - onTime) + ' late</div></div>' +
      '<div class="kpi warn"><div class="k-top"><span class="k-lbl">In flight</span><span class="k-ico">' + UI.icon('clock', 14) + '</span></div><div class="k-val">' + UI.n(pending) + '</div><div class="k-sub">Not started / in progress / hold</div></div>' +
      '<div class="kpi bad"><div class="k-top"><span class="k-lbl">Overdue</span><span class="k-ico">' + UI.icon('alert', 14) + '</span></div><div class="k-val">' + UI.n(overdue) + '</div><div class="k-sub">Past SLA due date</div></div>' +
      '<div class="kpi purple"><div class="k-top"><span class="k-lbl">On-time rate</span><span class="k-ico">' + UI.icon('chart', 14) + '</span></div><div class="k-val">' + UI.pct(onTime, done) + '%</div><div class="k-sub">Of completed work</div></div>' +
      '</div>';
  }

  function rowHtml(t) {
    const late = t.hours_overdue > 0 && t.status !== 'completed_on_time' && t.status !== 'completed_late';
    return '<tr data-task="' + t.id + '" style="cursor:pointer">' +
      '<td><div class="strong">' + UI.esc(t.task_code) + '</div><div class="small">' + UI.esc(t.step_name || '—') + '</div></td>' +
      '<td><div class="strong" style="font-size:12px">' + UI.esc(t.fms_code || '') + '</div><div class="small">' + UI.esc(t.fms_name) + '</div></td>' +
      '<td class="small">' + UI.esc(t.department_name || '—') + '</td>' +
      '<td><div class="flex items-center gap8">' + UI.avatar(t.assignee, '#64748B', 'sm') + '<span class="small">' + UI.esc(t.assignee || 'Unassigned') + '</span></div></td>' +
      '<td class="nowrap"><div class="small">' + UI.fmtDate(t.due_at) + '</div>' + (late ? '<div class="small" style="color:var(--bad);font-weight:600">' + UI.hrs(t.hours_overdue) + ' over</div>' : '') + '</td>' +
      '<td class="small nowrap">' + UI.hrs(t.age_hours) + '</td>' +
      '<td>' + UI.pill(t.status) + '</td>' +
      '<td class="nowrap">' + UI.prio(t.priority) + '</td>' +
      '</tr>';
  }

  function tableHtml(rows) {
    if (!rows.length) return UI.empty('No tasks in this view', 'Adjust the filters or widen the reporting period.', '<button class="btn primary sm" id="emptyNewTask">' + UI.icon('plus', 13) + ' New task</button>');
    const shown = rows.slice(0, PAGE);
    return '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Task</th><th>FMS</th><th>Department</th><th>Assignee</th><th>Due</th><th>Age</th><th>Status</th><th>Priority</th></tr></thead><tbody>' +
      shown.map(rowHtml).join('') + '</tbody></table></div>' +
      (rows.length > PAGE ? '<div class="flex items-center gap8" style="padding:10px 14px;border-top:1px solid var(--line)"><span class="small">Showing ' + shown.length + ' of ' + rows.length + '</span><button class="btn sm ml-auto" id="tMore">Show ' + Math.min(40, rows.length - shown.length) + ' more</button></div>' : '');
  }

  async function render(el, ctx) {
    consumeState(); applyScope(); PAGE = 25;
    const admin = Auth.isAdmin();
    const me = Auth.getSession();

    let depts, fms, people;
    try {
      [depts, fms, people] = await Promise.all([
        window.agentdb.executeQuery('load_departments', {}),
        window.agentdb.executeQuery('load_fms', { department_id: 0, status: '' }),
        window.agentdb.executeQuery('load_people', { department_id: 0, role: '' })
      ]);
    } catch (e) { el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>'; return; }
    DEPTS = depts.rows; FMS = fms.rows; PEOPLE = people.rows;

    let rows = [];
    try { rows = await fetchTasks(); }
    catch (e) { el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div><b>Tasks did not load.</b><br>' + UI.esc(e.message) + '</div></div>'; return; }
    ROWS = rows;

    const scoped = me.role !== 'admin';
    const activeFms = F.fms_id ? FMS.find(f => Number(f.id) === Number(F.fms_id)) : null;

    el.innerHTML =
      '<div class="page-head"><div><h1>Task Tracking</h1><div class="sub">Every FMS step with its SLA clock, owner and live status · ' + UI.esc(App.rangeLabel()) + '</div></div>' +
      '<div class="page-actions"><button class="btn" id="tExport">' + UI.icon('download', 14) + ' Export CSV</button>' +
      (!scoped || me.role === 'department_head' ? '<button class="btn primary" id="tNew">' + UI.icon('plus', 14) + ' New task</button>' : '') + '</div></div>' +
      (activeFms ? '<div class="banner info">' + UI.icon('layers', 15) + '<div>Showing steps of <b>' + UI.esc(activeFms.name) + '</b> only. <button class="btn sm" id="tClearFms" style="margin-left:8px">Clear filter</button></div></div>' : '') +
      (scoped ? '<div class="banner info">' + UI.icon('shield', 15) + '<div>' + (me.role === 'department_head' ? 'You are viewing your department’s work only.' : 'You are viewing tasks assigned to you.') + '</div></div>' : '') +
      '<div id="taskKpis">' + kpis(rows) + '</div>' +
      '<div class="toolbar">' +
      '<div class="grow"><input class="input" id="tSearch" placeholder="Search by task code, step, FMS or assignee…" style="width:100%" value="' + UI.esc(F.search) + '"></div>' +
      '<select class="select" id="tFms"><option value="0">All FMS</option>' + FMS.map(f => '<option value="' + f.id + '"' + (Number(F.fms_id) === Number(f.id) ? ' selected' : '') + '>' + UI.esc(f.code || f.name) + ' · ' + UI.esc(f.name) + '</option>').join('') + '</select>' +
      (!scoped ? '<select class="select" id="tDept"><option value="0">All departments</option>' + DEPTS.map(d => '<option value="' + d.id + '"' + (Number(F.department_id) === Number(d.id) ? ' selected' : '') + '>' + UI.esc(d.name) + '</option>').join('') + '</select>' : '') +
      (!scoped ? '<select class="select" id="tEmp"><option value="0">Everyone</option>' + PEOPLE.map(p => '<option value="' + p.id + '"' + (Number(F.assigned_to) === Number(p.id) ? ' selected' : '') + '>' + UI.esc(p.full_name) + '</option>').join('') + '</select>' : '') +
      '<select class="select" id="tStatus">' +
      [['', 'All statuses'], ['not_started', 'Not started'], ['in_progress', 'In progress'], ['overdue', 'Overdue'], ['completed', 'Completed (all)'], ['completed_on_time', 'Completed on time'], ['completed_late', 'Completed late'], ['on_hold', 'On hold'], ['cancelled', 'Cancelled']]
        .map(o => '<option value="' + o[0] + '"' + (F.status === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') +
      '</select></div>' +
      '<div class="card"><div class="card-head"><h3>Work queue</h3><span class="small" id="tCount">' + rows.length + ' tasks</span></div>' +
      '<div class="card-body tight" id="taskTable">' + tableHtml(rows) + '</div></div>';

    bindTable(el);
    document.getElementById('tSearch').oninput = UI.debounce(() => { F.search = document.getElementById('tSearch').value.trim(); refresh(); }, 260);
    document.getElementById('tFms').onchange = (e) => { F.fms_id = Number(e.target.value) || 0; refresh(); };
    const dsel = document.getElementById('tDept'); if (dsel) dsel.onchange = (e) => { F.department_id = Number(e.target.value) || 0; refresh(); };
    const esel = document.getElementById('tEmp'); if (esel) esel.onchange = (e) => { F.assigned_to = Number(e.target.value) || 0; refresh(); };
    document.getElementById('tStatus').onchange = (e) => { F.status = e.target.value; refresh(); };
    const clr = document.getElementById('tClearFms'); if (clr) clr.onclick = () => { F.fms_id = 0; App.rerender(); };
    const nb = document.getElementById('tNew'); if (nb) nb.onclick = () => openCreate();
    const ex = document.getElementById('tExport');
    if (ex) ex.onclick = () => UI.downloadCsv(ROWS.map(t => ({
      TaskCode: t.task_code, Step: t.step_name, FMS: t.fms_name, Department: t.department_name,
      Assignee: t.assignee, Status: t.status, Priority: t.priority, Created: t.created_at,
      Due: t.due_at, Completed: t.completed_at || '', AgeHours: t.age_hours, HoursOverdue: t.hours_overdue
    })), 'smartiqo-tasks.csv');

    async function refresh() {
      const box = document.getElementById('taskTable');
      if (!box) return;
      box.innerHTML = '<div class="loading-row">Loading…</div>';
      try {
        ROWS = await fetchTasks();
        const k = document.getElementById('taskKpis'), c = document.getElementById('tCount');
        if (k) k.innerHTML = kpis(ROWS);
        if (c) c.textContent = ROWS.length + ' tasks';
        PAGE = 25;
        box.innerHTML = tableHtml(ROWS);
        bindTable(el);
      } catch (e) { box.innerHTML = '<div class="banner warn">' + UI.icon('alert', 15) + '<div>' + UI.esc(e.message) + '</div></div>'; }
    }

    function bindTable(root) {
      root.querySelectorAll('[data-task]').forEach(r => r.onclick = () => openTask(Number(r.dataset.task)));
      const e2 = root.querySelector('#emptyNewTask'); if (e2) e2.onclick = () => openCreate();
      const more = root.querySelector('#tMore');
      if (more) more.onclick = () => {
        PAGE += 40;
        const box = document.getElementById('taskTable');
        box.innerHTML = tableHtml(ROWS);
        bindTable(el);
      };
    }

    if ('taskFocus' in App.state) {
      const id = Number(App.state.taskFocus); delete App.state.taskFocus;
      if (id) openTask(id);
    }
  }

  async function openTask(id) {
    let t = ROWS.find(x => Number(x.id) === Number(id));
    if (!t) {
      try { const r = await window.agentdb.executeQuery('task_detail', { id: id }); t = r.rows[0]; }
      catch (e) { UI.toast(e.message, 'bad'); return; }
    }
    if (!t) { UI.toast('Task not found', 'bad'); return; }
    const me = Auth.getSession();
    const admin = Auth.isAdmin();

    let hist = { rows: [] }, forms = { rows: [] };
    try {
      [hist, forms] = await Promise.all([
        window.agentdb.executeQuery('task_history', { task_id: t.id }),
        window.agentdb.executeQuery('load_forms', { department_id: 0, fms_id: t.fms_id })
      ]);
    } catch (e) { }

    const required = forms.rows.filter(f => f.is_required);
    const canEdit = admin || me.role === 'department_head' || Number(t.assigned_to) === Number(me.id);

    const d = UI.drawer({
      title: t.task_code + ' · ' + (t.step_name || 'Step'),
      sub: '<span class="pill ' + (UI.STATUS[t.status] || { cls: 'grey' }).cls + '">' + UI.esc((UI.STATUS[t.status] || {}).label || t.status) + '</span> <span class="small">' + UI.esc(t.fms_name) + '</span>',
      body:
        '<dl class="kv mb16">' +
        '<dt>FMS</dt><dd>' + UI.esc(t.fms_name) + (t.fms_code ? ' <span class="tag">' + UI.esc(t.fms_code) + '</span>' : '') + '</dd>' +
        '<dt>Department</dt><dd>' + UI.esc(t.department_name || '—') + '</dd>' +
        '<dt>Assignee</dt><dd>' + UI.esc(t.assignee || 'Unassigned') + '</dd>' +
        '<dt>Priority</dt><dd>' + UI.prio(t.priority) + '</dd>' +
        '<dt>Created</dt><dd>' + UI.fmtDateTime(t.created_at) + '</dd>' +
        '<dt>Started</dt><dd>' + (t.started_at ? UI.fmtDateTime(t.started_at) : '—') + '</dd>' +
        '<dt>Due (SLA)</dt><dd>' + UI.fmtDateTime(t.due_at) + '</dd>' +
        '<dt>Completed</dt><dd>' + (t.completed_at ? UI.fmtDateTime(t.completed_at) : '—') + '</dd>' +
        '<dt>Age</dt><dd>' + UI.hrs(t.age_hours) + (t.hours_overdue > 0 ? ' <span class="pill red">' + UI.hrs(t.hours_overdue) + ' overdue</span>' : '') + '</dd>' +
        '<dt>Remarks</dt><dd>' + UI.esc(t.remarks || '—') + '</dd></dl>' +
        (canEdit ? '<div class="card" style="box-shadow:none"><div class="card-head"><h3>Update status</h3></div><div class="card-body">' +
          '<div class="form-grid"><div class="field"><label>New status</label><select class="select" id="dStatus">' +
          [['in_progress', 'In progress'], ['completed', 'Completed'], ['on_hold', 'On hold'], ['not_started', 'Not started'], ['cancelled', 'Cancelled']]
            .map(o => '<option value="' + o[0] + '"' + (t.status === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></div>' +
          '<div class="field"><label>Note (optional)</label><input class="input" id="dNote" placeholder="What changed?"></div></div>' +
          '<button class="btn primary block" id="dSave">' + UI.icon('save', 14) + ' Save update</button>' +
          '<div class="small mt8">Completing a task records it as on time or late automatically against the SLA due date.</div>' +
          '</div></div>' : '') +
        (required.length ? '<div class="card" style="box-shadow:none;margin-top:12px"><div class="card-head"><h3>Required forms</h3><span class="small">' + required.length + '</span></div><div class="card-body tight">' +
          required.map(f => '<div class="setting-row" style="padding:11px 16px"><div><h5>' + UI.esc(f.name) + '</h5><p>' + UI.esc(f.form_type.replace(/_/g, ' ')) + ' · deadline ' + f.deadline_hours + 'h</p></div>' +
            '<button class="btn sm" data-form="' + f.id + '">Record</button></div>').join('') + '</div></div>' : '') +
        '<div class="card" style="box-shadow:none;margin-top:12px"><div class="card-head"><h3>Activity</h3><span class="small">' + hist.rows.length + ' entries</span></div><div class="card-body">' +
        (hist.rows.length ? '<div class="timeline">' + hist.rows.map(h => '<div class="tl-item"><div style="font-weight:600">' + UI.esc(h.action) +
          (h.to_status ? ' → ' + UI.esc((UI.STATUS[h.to_status] || {}).label || h.to_status) : '') + '</div>' +
          (h.note ? '<div class="small">' + UI.esc(h.note) + '</div>' : '') +
          '<div class="t">' + UI.esc(h.actor) + ' · ' + UI.rel(h.created_at) + '</div></div>').join('') + '</div>'
          : '<p class="small" style="margin:0">No activity recorded yet.</p>') + '</div></div>',
      foot: (admin ? '<button class="btn danger sm" id="dDelete">' + UI.icon('trash', 13) + ' Delete</button>' : '') +
        '<button class="btn" data-close>Close</button>',
      onMount: (bg, close) => {
        const sv = bg.querySelector('#dSave');
        if (sv) sv.onclick = async () => {
          const status = bg.querySelector('#dStatus').value, note = bg.querySelector('#dNote').value.trim();
          sv.disabled = true;
          try {
            await window.agentdb.executeQuery('update_task_status', { id: t.id, status: status, remarks: note, actor_id: me.id });
            await window.PAGES.departments.audit('Task status updated', 'task', String(t.id), t.task_code + ' → ' + status);
            close(); UI.toast('Task updated', 'ok'); App.rerender();
          } catch (e) { sv.disabled = false; UI.toast(e.message, 'bad'); }
        };
        bg.querySelectorAll('[data-form]').forEach(b => b.onclick = () => {
          const f = forms.rows.find(x => Number(x.id) === Number(b.dataset.form));
          close(); submitForm(f, t);
        });
        const del = bg.querySelector('#dDelete');
        if (del) del.onclick = async () => {
          const ok = await UI.confirmAction('Delete task ' + t.task_code + '? This cannot be undone.', { danger: true, confirmLabel: 'Delete task' });
          if (!ok) return;
          try { await window.agentdb.executeQuery('delete_task', { id: t.id }); close(); UI.toast('Task deleted', 'ok'); App.rerender(); }
          catch (e) { UI.toast(e.message, 'bad'); }
        };
      }
    });
    return d;
  }

  function submitForm(form, task) {
    const me = Auth.getSession();
    UI.modal({
      title: 'Record submission · ' + form.name,
      body: '<div class="banner info">' + UI.icon('clipboard', 15) + '<div>Mark this form as received for <b>' + UI.esc(task ? task.task_code : '') + '</b>. Paste the form response link or reference number so the record can be traced.</div></div>' +
        '<div class="field"><label>Response reference / link</label><input class="input" id="fsRef" placeholder="https://forms.gle/… or reference number"></div>' +
        '<div class="field"><label>Submitted by</label><input class="input" value="' + UI.esc(me.name) + '" disabled></div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="fsSave">Record submission</button>',
      onMount: (bg, close) => {
        bg.querySelector('#fsSave').onclick = async () => {
          const ref = bg.querySelector('#fsRef').value.trim();
          try {
            await window.agentdb.executeQuery('record_form_submission', {
              form_id: form.id, visit_id: 0, task_id: task ? task.id : 0, submitted_by: me.id, reference: ref
            });
            await window.PAGES.departments.audit('Form submission recorded', 'form', String(form.id), form.name);
            close(); UI.toast('Form submission recorded', 'ok'); App.rerender();
          } catch (e) { UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  async function openCreate(fmsId, deptId) {
    const me = Auth.getSession();
    let depts = DEPTS, fms = FMS, people = PEOPLE;
    if (!depts.length) {
      try {
        [depts, fms, people] = await Promise.all([
          window.agentdb.executeQuery('load_departments', {}),
          window.agentdb.executeQuery('load_fms', { department_id: 0, status: '' }),
          window.agentdb.executeQuery('load_people', { department_id: 0, role: '' })
        ]).then(r => [r[0].rows, r[1].rows, r[2].rows]);
      } catch (e) { depts = []; fms = []; people = []; }
    }
    const preFms = Number(fmsId || F.fms_id || 0);
    const preDept = Number(deptId || F.department_id || (me.role === 'department_head' ? me.department_id : 0) || 0);
    const permittedFms = me.role === 'admin' ? fms : fms.filter(f => Number(f.department_id) === Number(me.department_id));

    const m = UI.modal({
      title: 'New task',
      size: 'wide',
      body: '<div class="form-grid">' +
        '<div class="field full"><label>FMS *</label><select class="select" id="nFms">' +
        (permittedFms.length ? permittedFms.map(f => '<option value="' + f.id + '"' + (Number(preFms) === Number(f.id) ? ' selected' : '') + '>' + UI.esc(f.name) + ' (' + UI.esc(f.code || '') + ')</option>').join('') : '<option value="0">No FMS available</option>') +
        '</select></div>' +
        '<div class="field full"><label>Step / task name *</label><input class="input" id="nStep" placeholder="e.g. Verify quotation with vendor"></div>' +
        '<div class="field"><label>Department</label><select class="select" id="nDept"><option value="0">Inherit from FMS</option>' +
        depts.map(d => '<option value="' + d.id + '"' + (Number(preDept) === Number(d.id) ? ' selected' : '') + '>' + UI.esc(d.name) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Employee name *</label><select class="select" id="nEmp"><option value="0">Choose an employee</option>' +
        people.map(p => '<option value="' + p.id + '">' + UI.esc(p.full_name) + ' · ' + UI.esc(p.department_name || p.designation || '') + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Due date *</label><input class="input" id="nDue" type="date" value="' + UI.todayISO(1) + '"></div>' +
        '<div class="field"><label>SLA (hours)</label><input class="input" id="nSla" type="number" min="1" value="' + (preFms && fms.find(f => Number(f.id) === preFms) ? fms.find(f => Number(f.id) === preFms).sla_hours : 24) + '"></div>' +
        '<div class="field"><label>Priority</label><select class="select" id="nPrio"><option value="medium">Medium</option><option value="low">Low</option><option value="high">High</option><option value="critical">Critical</option></select></div>' +
        '<div class="field full"><label>Remarks</label><textarea class="textarea" id="nRem"></textarea></div></div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="nSave">Create task</button>',
      onMount: (bg, close) => {
        const fsel = bg.querySelector('#nFms'), dsel = bg.querySelector('#nDept'), ssel = bg.querySelector('#nSla');
        const due = bg.querySelector('#nDue');
        const syncDue = () => {
          if (!due || due.dataset.touched === '1') return;
          const h = Number(ssel.value) || 24;
          const d = new Date(Date.now() + h * 3600 * 1000);
          const iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
          due.value = iso;
        };
        if (due) due.addEventListener('change', () => { due.dataset.touched = '1'; });
        if (ssel) ssel.addEventListener('input', syncDue);
        syncDue();
        fsel.onchange = () => {
          const f = fms.find(x => Number(x.id) === Number(fsel.value));
          if (f) { if (f.department_id) dsel.value = String(f.department_id); if (f.sla_hours) ssel.value = f.sla_hours; }
        };
        bg.querySelector('#nSave').onclick = async () => {
          const fms_id = Number(fsel.value) || 0;
          const step = bg.querySelector('#nStep').value.trim();
          if (!fms_id) { UI.toast('Choose the FMS this task belongs to', 'bad'); return; }
          if (!step) { UI.toast('Give the step a name', 'bad'); return; }
          const emp = Number(bg.querySelector('#nEmp').value) || 0;
          if (!emp) { UI.toast('Choose the employee this task is for', 'bad'); return; }
          const dueVal = bg.querySelector('#nDue').value;
          if (!dueVal) { UI.toast('Pick a due date', 'bad'); return; }
          const dept = Number(dsel.value) || 0;
          const f = fms.find(x => Number(x.id) === fms_id) || {};
          const payload = {
            fms_id: fms_id, department_id: dept || f.department_id || 0,
            assigned_to: emp,
            step_name: step, sla_hours: Number(ssel.value) || 24,
            priority: bg.querySelector('#nPrio').value, remarks: bg.querySelector('#nRem').value,
            actor_id: me.id,
            due_at: new Date(dueVal + 'T18:00:00').toISOString()
          };
          const btn = bg.querySelector('#nSave'); btn.disabled = true;
          try {
            const r = await window.agentdb.executeQuery('create_task', payload);
            await window.PAGES.departments.audit('Task created', 'task', String(r.rows[0].id), step);
            close(); UI.toast('Task ' + r.rows[0].task_code + ' created', 'ok');
            App.state.taskFocus = r.rows[0].id; App.rerender();
          } catch (e) { btn.disabled = false; UI.toast(e.message, 'bad'); }
        };
      }
    });
    return m;
  }

  return { render, openCreate, openTask };
})();
