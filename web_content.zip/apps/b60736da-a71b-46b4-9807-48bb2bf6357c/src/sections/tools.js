/* SmartiQo · Business tools and external links */
window.PAGES = window.PAGES || {};
window.PAGES.tools = (function () {

  let LINKS = [];

  async function render(el) {
    const me = Auth.getSession();
    const admin = Auth.isAdmin();
    try {
      LINKS = (await window.agentdb.executeQuery('load_links', { active_only: false })).rows;
    } catch (e) {
      el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>';
      return;
    }

    const cats = Array.from(new Set(LINKS.map(l => l.category || 'Other')));
    const placeholders = LINKS.filter(isPlaceholder).length;

    el.innerHTML =
      '<div class="page-head"><div><h1>Business Tools</h1><div class="sub">The external systems SmartiQo processes hand off to</div></div>' +
      '<div class="page-actions">' + (admin ? '<button class="btn primary" id="tAddLink">' + UI.icon('plus', 14) + ' Add link</button>' : '') + '</div></div>' +

      '<div class="card"><div class="card-head"><h3>Quick actions</h3><span class="small">Start the most common work</span></div><div class="card-body">' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:9px">' +
      '<button class="btn" data-act="task">' + UI.icon('plus', 14) + ' New task</button>' +
      '<button class="btn" data-act="site">' + UI.icon('pin', 14) + ' Schedule site visit</button>' +
      '<button class="btn" data-act="service">' + UI.icon('wrench', 14) + ' Schedule service visit</button>' +
      '<button class="btn" data-act="forms">' + UI.icon('clipboard', 14) + ' Pending forms</button>' +
      '<button class="btn" data-act="doc">' + UI.icon('folder', 14) + ' Documents</button>' +
      '<button class="btn" data-act="report">' + UI.icon('chart', 14) + ' Reports</button>' +
      '</div></div></div>' +

      (placeholders ? '<div class="banner warn">' + UI.icon('alert', 15) + '<div><b>' + placeholders + ' tool link' + (placeholders > 1 ? 's are' : ' is') + ' still a placeholder.</b> These open a generic service page until an administrator replaces the URL in Admin Settings → Business Tools.</div></div>' : '') +

      cats.map(c => '<div class="card"><div class="card-head"><h3>' + UI.esc(c) + '</h3><span class="small">' + LINKS.filter(l => (l.category || 'Other') === c).length + ' tools</span></div>' +
        '<div class="card-body"><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(285px,1fr));gap:12px">' +
        LINKS.filter(l => (l.category || 'Other') === c).map(linkCard).join('') + '</div></div></div>').join('') +

      (!LINKS.length ? '<div class="card card-body">' + UI.empty('No tools configured', 'Add the systems your team uses every day.', admin ? '<button class="btn primary" data-addlink>Add link</button>' : '') + '</div>' : '');

    el.querySelectorAll('[data-act]').forEach(b => b.onclick = () => {
      const a = b.dataset.act;
      if (a === 'task') window.PAGES.tasks.openCreate();
      else if (a === 'site') App.navigate('/site-visits');
      else if (a === 'service') App.navigate('/service-visits');
      else if (a === 'forms') App.navigate('/forms');
      else if (a === 'doc') App.navigate('/documents');
      else if (a === 'report') App.navigate('/reports');
    });
    el.querySelectorAll('[data-link]').forEach(a => a.onclick = () => openLink(Number(a.dataset.link)));
    el.querySelectorAll('[data-editlink]').forEach(b => b.onclick = (e) => { e.preventDefault(); e.stopPropagation(); linkModal(LINKS.find(l => Number(l.id) === Number(b.dataset.editlink))); });
    const al = el.querySelector('#tAddLink'); if (al) al.onclick = () => linkModal(null);
    el.querySelectorAll('[data-addlink]').forEach(b => b.onclick = () => linkModal(null));
    el.querySelectorAll('[data-dellink]').forEach(b => b.onclick = async (e) => {
      e.preventDefault(); e.stopPropagation();
      const l = LINKS.find(x => Number(x.id) === Number(b.dataset.dellink));
      const ok = await UI.confirmAction('Remove “' + l.name + '” from Business Tools?', { danger: true, confirmLabel: 'Remove link' });
      if (!ok) return;
      try { await window.agentdb.executeQuery('delete_link', { id: l.id }); UI.toast('Link removed', 'ok'); App.rerender(); }
      catch (err) { UI.toast(err.message, 'bad'); }
    });
  }

  function isPlaceholder(l) {
    return /replace this url/i.test(l.description || '');
  }

  function linkCard(l) {
    return '<div class="link-card" data-link="' + l.id + '" role="link" tabindex="0">' +
      '<div class="link-ico">' + UI.icon(l.icon || 'link', 17) + '</div>' +
      '<div style="min-width:0;flex:1"><div class="flex items-center gap8"><span class="strong" style="font-size:13px">' + UI.esc(l.name) + '</span>' +
      (isPlaceholder(l) ? '<span class="tag" style="background:var(--warn-soft);color:#B54708">Demo</span>' : '') +
      (!l.is_active ? '<span class="tag">Hidden</span>' : '') + '</div>' +
      '<div class="small" style="margin-top:3px;line-height:1.4">' + UI.esc(l.description || '') + '</div>' +
      '<div class="small" style="margin-top:6px;color:var(--blue);font-size:11px">' + UI.esc(host(l.url)) + '</div></div>' +
      (Auth.isAdmin() ? '<span style="display:flex;gap:4px"><button class="btn sm" data-editlink="' + l.id + '" title="Edit">' + UI.icon('edit', 12) + '</button>' +
        '<button class="btn sm danger" data-dellink="' + l.id + '" title="Remove">' + UI.icon('trash', 12) + '</button></span>' : '') +
      '</div>';
  }

  function host(u) {
    try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; }
  }

  function openLink(id) {
    const l = LINKS.find(x => Number(x.id) === Number(id));
    if (!l) return;
    if (isPlaceholder(l)) {
      UI.modal({
        title: l.name,
        body: '<div class="banner warn">' + UI.icon('alert', 15) + '<div><b>This link is a placeholder.</b><br>' + UI.esc(l.description || '') + '</div></div>' +
          '<dl class="kv"><dt>Configured URL</dt><dd><a href="' + UI.esc(l.url) + '" target="_blank" rel="noopener">' + UI.esc(l.url) + '</a></dd><dt>Category</dt><dd>' + UI.esc(l.category || '—') + '</dd></dl>',
        foot: (Auth.isAdmin() ? '<button class="btn primary" id="lkEdit">Replace URL</button>' : '') + '<button class="btn" data-close>Close</button>',
        onMount: (bg, close) => {
          const e = bg.querySelector('#lkEdit'); if (e) e.onclick = () => { close(); linkModal(l); };
        }
      });
      return;
    }
    window.open(l.url, '_blank', 'noopener');
  }

  function linkModal(l) {
    const isNew = !l;
    UI.modal({
      title: isNew ? 'Add business tool' : 'Edit ' + l.name,
      body: '<div class="form-grid">' +
        '<div class="field full"><label>Name *</label><input class="input" id="lkName" value="' + UI.esc(l ? l.name : '') + '"></div>' +
        '<div class="field full"><label>URL *</label><input class="input" id="lkUrl" value="' + UI.esc(l ? l.url : '') + '" placeholder="https://…"></div>' +
        '<div class="field"><label>Category</label><input class="input" id="lkCat" value="' + UI.esc(l ? l.category || '' : 'Business Apps') + '"></div>' +
        '<div class="field"><label>Sort order</label><input class="input" id="lkSort" type="number" value="' + (l ? l.sort_order : 100) + '"></div>' +
        '<div class="field full"><label>Description</label><textarea class="textarea" id="lkDesc">' + UI.esc(l ? l.description || '' : '') + '</textarea></div>' +
        '<div class="field"><label>Visible</label><select class="select" id="lkActive"><option value="true"' + (!l || l.is_active ? ' selected' : '') + '>Shown in Business Tools</option><option value="false"' + (l && !l.is_active ? ' selected' : '') + '>Hidden</option></select></div>' +
        '</div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="lkSave">Save link</button>',
      onMount: (bg, close) => {
        bg.querySelector('#lkSave').onclick = async () => {
          const name = bg.querySelector('#lkName').value.trim(), url = bg.querySelector('#lkUrl').value.trim();
          if (!name || !url) { UI.toast('Name and URL are required', 'bad'); return; }
          const payload = {
            name: name, url: url, description: bg.querySelector('#lkDesc').value, category: bg.querySelector('#lkCat').value.trim(),
            icon: 'link', sort_order: Number(bg.querySelector('#lkSort').value) || 100,
            is_active: bg.querySelector('#lkActive').value === 'true'
          };
          try {
            if (isNew) await window.agentdb.executeQuery('create_link', payload);
            else await window.agentdb.executeQuery('update_link', Object.assign({ id: l.id }, payload));
            await window.PAGES.departments.audit(isNew ? 'Business tool added' : 'Business tool updated', 'link', l ? String(l.id) : '', name);
            close(); UI.toast('Link saved', 'ok'); App.rerender();
          } catch (e) { UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  return { render };
})();
