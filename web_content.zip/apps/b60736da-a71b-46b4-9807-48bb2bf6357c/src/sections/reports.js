/* SmartiQo · Reports and analytics */
window.PAGES = window.PAGES || {};
window.PAGES.reports = (function () {

  const R = { dept: 0, fms: 0 };
  let DATA = null;

  function agg(rows, keyFn, labelFn) {
    const map = {};
    rows.forEach(t => {
      const k = keyFn(t) || 'Unassigned';
      if (!map[k]) map[k] = { key: k, label: labelFn ? labelFn(t) : k, total: 0, done: 0, ontime: 0, late: 0, overdue: 0, pending: 0 };
      const m = map[k];
      m.total++;
      if (t.status === 'completed_on_time') { m.done++; m.ontime++; }
      else if (t.status === 'completed_late') { m.done++; m.late++; }
      else if (t.status === 'overdue') m.overdue++;
      else if (t.status === 'not_started' || t.status === 'in_progress' || t.status === 'on_hold') m.pending++;
    });
    return Object.keys(map).map(k => map[k]).sort((a, b) => b.overdue - a.overdue || b.total - a.total);
  }

  async function render(el) {
    const me = Auth.getSession();
    const admin = Auth.isAdmin();
    if ('reportDept' in App.state) { R.dept = Number(App.state.reportDept) || 0; delete App.state.reportDept; }
    if ('reportFms' in App.state) { R.fms = Number(App.state.reportFms) || 0; delete App.state.reportFms; }
    if (me.role === 'department_head') R.dept = me.department_id || 0;

    let depts = [], fms = [];
    try {
      const [d, f] = await Promise.all([
        window.agentdb.executeQuery('load_departments', {}),
        window.agentdb.executeQuery('load_fms', { department_id: 0, status: '' })
      ]);
      depts = d.rows; fms = f.rows;
    } catch (e) { }

    let tasks, pending, visits;
    try {
      [tasks, pending, visits] = await Promise.all([
        window.agentdb.executeQuery('load_tasks', {
          fms_id: R.fms, department_id: R.dept, assigned_to: 0, status: '',
          from_date: App.state.from, to_date: App.state.to, search: ''
        }),
        window.agentdb.executeQuery('pending_forms_list', { department_id: R.dept, employee_id: 0, fms_id: R.fms }),
        window.agentdb.executeQuery('load_visits', {
          visit_type: '', from_date: App.state.from, to_date: App.state.to, department_id: R.dept, employee_id: 0, status: ''
        })
      ]);
    } catch (e) {
      el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>';
      return;
    }
    const rows = tasks.rows;
    const truncated = rows.length >= 400;
    DATA = { tasks: rows, pending: pending.rows, visits: visits.rows };

    const done = rows.filter(t => t.status === 'completed_on_time' || t.status === 'completed_late').length;
    const onTime = rows.filter(t => t.status === 'completed_on_time').length;
    const overdue = rows.filter(t => t.status === 'overdue').length;
    const pendingCount = rows.filter(t => t.status === 'not_started' || t.status === 'in_progress' || t.status === 'on_hold').length;
    const rate = UI.pct(onTime, done);
    const deptAgg = agg(rows, t => t.department_name);
    const fmsAgg = agg(rows, t => t.fms_code || t.fms_name, t => t.fms_name);
    const peopleAgg = agg(rows, t => t.assignee);
    const pendingForms = pending.rows.filter(p => p.is_breached).length;
    const siteCount = visits.rows.filter(v => v.visit_type === 'site').length;
    const serviceCount = visits.rows.filter(v => v.visit_type === 'service').length;
    const visitDone = visits.rows.filter(v => v.status === 'completed').length;
    const visitCancelled = visits.rows.filter(v => v.status === 'cancelled').length;
    const scopeLabel = R.fms ? (fms.find(f => Number(f.id) === Number(R.fms)) || {}).name
      : R.dept ? (depts.find(d => Number(d.id) === Number(R.dept)) || {}).name : 'All departments';
    const periodLabel = UI.fmtDate(App.state.from) + ' – ' + UI.fmtDate(App.state.to);

    const insights = [];
    if (overdue) insights.push(overdue + ' steps are past their SLA, concentrated in ' + (deptAgg[0] ? deptAgg[0].label : 'no single department') + '.');
    if (rate < 70 && done) insights.push('On-time completion is ' + rate + '% of finished work — late completions are the main gap.');
    if (pendingForms) insights.push(pendingForms + ' form submissions are past their deadline.');
    if (!rows.length) insights.push('No steps were created in this period for the selected scope.');
    if (!insights.length) insights.push('Work is within SLA for this period: no overdue steps and no breached forms.');

    el.innerHTML =
      '<div class="page-head no-print"><div><h1>Reports & Analytics</h1><div class="sub">Period ' + UI.esc(periodLabel) + ' · ' + UI.esc(scopeLabel) + '</div></div>' +
      '<div class="page-actions">' +
      (!admin ? '' : '<select class="select" id="rDept" style="height:38px"><option value="0">All departments</option>' + depts.map(d => '<option value="' + d.id + '"' + (Number(R.dept) === Number(d.id) ? ' selected' : '') + '>' + UI.esc(d.name) + '</option>').join('') + '</select>') +
      '<select class="select" id="rFms" style="height:38px"><option value="0">All FMS</option>' + fms.map(f => '<option value="' + f.id + '"' + (Number(R.fms) === Number(f.id) ? ' selected' : '') + '>' + UI.esc(f.code || f.name) + ' · ' + UI.esc(f.name) + '</option>').join('') + '</select>' +
      '<button class="btn" id="rCsv">' + UI.icon('download', 14) + ' CSV</button>' +
      '<button class="btn" id="rPdf">' + UI.icon('download', 14) + ' Download PDF</button>' +
      '<button class="btn primary" id="rPrint">' + UI.icon('printer', 14) + ' Print</button></div></div>' +

      (truncated ? '<div class="banner warn no-print">' + UI.icon('alert', 15) + '<div><b>This period holds more than 400 steps.</b> Figures below cover the first 400 returned by the tracker; narrow the period or department for complete numbers.</div></div>' : '') +

      '<div class="card no-print"><div class="card-head"><div><h3>Delivery trend</h3><div class="hint">Created, completed and overdue steps</div></div></div><div class="card-body"><div class="chart-box"><canvas id="rChart"></canvas></div></div></div>' +

      '<div class="rep-sheet" id="report-sheet">' +
      '<div class="rep-head"><div><div class="rep-brand"><div class="rep-mark">S</div><div><div style="font-size:13px;font-weight:700">SmartiQo</div><div style="font-size:9.5px;color:#A9B8D1">Centralized Process Management</div></div></div>' +
      '<h2 style="margin-top:16px">Operations Performance Report</h2><div class="rs">' + UI.esc(scopeLabel) + ' · ' + UI.esc(periodLabel) + '</div></div>' +
      '<div style="text-align:right;font-size:10px;color:#A9B8D1;line-height:1.7">Generated ' + UI.fmtDate(new Date()) + '<br>By ' + UI.esc(me.name) + '<br>' + UI.esc((me.role || '').replace(/_/g, ' ')) + '</div></div>' +
      '<div class="rep-body">' +
      '<div class="rep-kpis">' +
      repKpi(rows.length, 'Steps in period') + repKpi(done, 'Completed') + repKpi(rate + '%', 'On-time rate') +
      repKpi(overdue, 'Overdue') + repKpi(pendingCount, 'In flight') + repKpi(visits.rows.length, 'Visits') +
      repKpi(pending.rows.length, 'Forms pending') + repKpi(pendingForms, 'Forms breached') +
      '</div>' +

      '<div class="rep-sec"><h4>Executive summary</h4><ul style="margin:0;padding-left:16px;font-size:10.5px;line-height:1.75;color:#334155">' +
      insights.map(i => '<li>' + UI.esc(i) + '</li>').join('') +
      '<li>' + rows.length + ' steps tracked, ' + done + ' completed (' + UI.pct(done, rows.length) + '% completion) and ' + pendingCount + ' still open.</li>' +
      '<li>' + visits.rows.length + ' visits in the period: ' + siteCount + ' site, ' + serviceCount + ' service, ' + visitDone + ' completed, ' + visitCancelled + ' cancelled.</li>' +
      '</ul></div>' +

      '<div class="rep-sec"><h4>Department performance</h4>' + repTable(['Department', 'Steps', 'Completed', 'On time', 'Late', 'Pending', 'Overdue', 'On-time %'],
        deptAgg.map(d => [d.label, d.total, d.done, d.ontime, d.late, d.pending, d.overdue, UI.pct(d.ontime, d.done) + '%'])) +
      '</div>' +

      '<div class="rep-sec"><h4>FMS performance</h4>' + repTable(['FMS', 'Steps', 'Completed', 'On time', 'Late', 'Pending', 'Overdue', 'On-time %'],
        fmsAgg.slice(0, 18).map(d => [d.label, d.total, d.done, d.ontime, d.late, d.pending, d.overdue, UI.pct(d.ontime, d.done) + '%'])) + '</div>' +

      '<div class="rep-sec"><h4>Employee performance</h4>' + repTable(['Employee', 'Steps', 'Completed', 'On time', 'Late', 'Pending', 'Overdue', 'On-time %'],
        peopleAgg.slice(0, 12).map(d => [d.label, d.total, d.done, d.ontime, d.late, d.pending, d.overdue, UI.pct(d.ontime, d.done) + '%'])) + '</div>' +

      '<div class="rep-sec"><h4>Visit activity</h4>' +
      repTable(['Visit type', 'Scheduled', 'Completed', 'Cancelled', 'Forms pending'], [
        ['Site visits', siteCount, visits.rows.filter(v => v.visit_type === 'site' && v.status === 'completed').length,
          visits.rows.filter(v => v.visit_type === 'site' && v.status === 'cancelled').length, visits.rows.filter(v => v.visit_type === 'site' && v.form_status === 'pending').length],
        ['Service visits', serviceCount, visits.rows.filter(v => v.visit_type === 'service' && v.status === 'completed').length,
          visits.rows.filter(v => v.visit_type === 'service' && v.status === 'cancelled').length, visits.rows.filter(v => v.visit_type === 'service' && v.form_status === 'pending').length]
      ]) + '</div>' +

      '<div class="rep-sec"><h4>Outstanding forms (oldest first)</h4>' +
      (pending.rows.length ? repTable(['Form', 'Subject', 'Assignee', 'Reference date', 'Days pending', 'Deadline'],
        pending.rows.slice(0, 12).map(p => [p.form_name, p.subject || '—', p.assignee || 'Unassigned', UI.fmtDate(p.ref_date), p.days_pending, p.is_breached ? 'Breached' : 'Within ' + p.deadline_hours + 'h'])) :
        '<div style="font-size:10.5px;color:#64748B">No outstanding form submissions for this scope.</div>') +
      '</div>' +
      '</div>' +
      '<div class="rep-foot"><span>SmartiQo · Internal & Confidential</span><span>' + UI.esc(periodLabel) + ' · page 1</span></div>' +
      '</div>';

    const dsel = document.getElementById('rDept'); if (dsel) dsel.onchange = (e) => { R.dept = Number(e.target.value) || 0; App.rerender(); };
    const fsel = document.getElementById('rFms'); if (fsel) fsel.onchange = (e) => { R.fms = Number(e.target.value) || 0; App.rerender(); };
    document.getElementById('rCsv').onclick = () => UI.downloadCsv(rows.map(t => ({
      Task: t.task_code, Step: t.step_name, FMS: t.fms_name, Department: t.department_name, Assignee: t.assignee,
      Status: t.status, Priority: t.priority, Created: t.created_at, Due: t.due_at, Completed: t.completed_at || '',
      AgeHours: t.age_hours, HoursOverdue: t.hours_overdue
    })), 'smartiqo-report-' + App.state.from + '-to-' + App.state.to + '.csv');
    document.getElementById('rPdf').onclick = () => UI.downloadPdf('#report-sheet', 'SmartiQo-operations-report-' + App.state.from + '.pdf');
    document.getElementById('rPrint').onclick = () => UI.printEl('#report-sheet', 'SmartiQo Operations Report');

    // screen chart
    const byDay = {};
    rows.forEach(t => {
      const k = String(t.created_at).slice(0, 10);
      byDay[k] = byDay[k] || { c: 0, d: 0 };
      byDay[k].c++;
      if (t.status === 'completed_on_time' || t.status === 'completed_late') byDay[k].d++;
    });
    const days = Object.keys(byDay).sort();
    UI.chart(document.getElementById('rChart'), {
      type: 'bar',
      data: {
        labels: days.map(d => UI.fmtShort(d)),
        datasets: [
          { label: 'Created', data: days.map(d => byDay[d].c), backgroundColor: 'rgba(29,107,243,.75)', borderRadius: 3, maxBarThickness: 20 },
          { label: 'Completed', data: days.map(d => byDay[d].d), backgroundColor: 'rgba(14,159,110,.8)', borderRadius: 3, maxBarThickness: 20 }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 8, boxHeight: 8, usePointStyle: true } } },
        scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 12 } }, y: { beginAtZero: true, grid: { color: UI.gridColor() }, ticks: { precision: 0 } } }
      }
    });
  }

  function repKpi(v, l) {
    const shown = typeof v === 'number' ? UI.n(v) : UI.esc(String(v));
    return '<div class="rep-kpi"><div class="v">' + shown + '</div><div class="l">' + UI.esc(l) + '</div></div>';
  }
  function repTable(head, rows) {
    return '<table class="rep-tbl"><thead><tr>' + head.map(h => '<th>' + UI.esc(h) + '</th>').join('') + '</tr></thead><tbody>' +
      (rows.length ? rows.map(r => '<tr>' + r.map(c => '<td>' + UI.esc(c) + '</td>').join('') + '</tr>').join('') : '<tr><td colspan="' + head.length + '">No data</td></tr>') +
      '</tbody></table>';
  }

  return { render };
})();
