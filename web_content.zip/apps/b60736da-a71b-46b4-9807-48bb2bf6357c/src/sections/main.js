// SmartiQo · entry point. The section runner calls render() once; the app then
// owns routing internally. No global init() is defined on purpose.

const SECTIONS = [
  {
    el: '#content',
    render: function () {
      const content = document.getElementById('content');
      if (content) content.hidden = false;
      const loading = document.getElementById('loading');
      if (loading) loading.hidden = true;
      window.App.boot();
    }
  }
];
