/* SmartiQo · Notifications centre */
window.PAGES = window.PAGES || {};
window.PAGES.notifications = (function () {

  let ROWS = [];
  let FILTER = 'all';

  function targetFor(n) {
    const t = (n.entity_type || '').toLowerCase();
    const id = Number(n.entity_id) || 0;
    if (t === 'task' && id) { App.state.taskFocus = id; return '/tasks'; }
    if (t === 'fms') return id ? '/fms/' + id : '/fms';
    if (t === 'form') return '/forms';
    if (t === 'visit') return '/site-visits';
    if (t === 'document') return '/documents';
    if (t === 'department') return id ? '/departments/' + id : '/departments';
    return null;
  }

  async function render(el) {
    const me = Auth.getSession();
    try {
      const [r, u] = await Promise.all([
        window.agentdb.executeQuery('load_notifications', { user_id: me.id, limit: 60 }),
        window.agentdb.executeQuery('unread_count', { user_id: me.id })
      ]);
      ROWS = r.rows;
      const unread = u.rows[0] ? Number(u.rows[0].unread) : 0;
      const today = ROWS.filter(n => String(n.created_at).slice(0, 10) === UI.todayISO(0)).length;

      el.innerHTML =
        '<div class="page-head"><div><h1>Notifications</h1><div class="sub">Alerts for your scope — overdue steps, visits, forms and assignment changes</div></div>' +
        '<div class="page-actions"><button class="btn" id="nAll">' + UI.icon('check', 14) + ' Mark all read</button></div></div>' +
        '<div class="kpi-grid">' +
        '<div class="kpi ' + (unread ? 'bad' : 'ok') + '"><div class="k-top"><span class="k-lbl">Unread</span><span class="k-ico">' + UI.icon('bell', 14) + '</span></div><div class="k-val">' + unread + '</div><div class="k-sub">Needs your attention</div></div>' +
        '<div class="kpi blue"><div class="k-top"><span class="k-lbl">Inbox</span><span class="k-ico">' + UI.icon('mail', 14) + '</span></div><div class="k-val">' + ROWS.length + '</div><div class="k-sub">Most recent 60</div></div>' +
        '<div class="kpi purple"><div class="k-top"><span class="k-lbl">Today</span><span class="k-ico">' + UI.icon('calendar', 14) + '</span></div><div class="k-val">' + today + '</div><div class="k-sub">' + UI.fmtDate(new Date()) + '</div></div>' +
        '</div>' +
        '<div class="toolbar"><div class="seg"><button data-nf="all" class="' + (FILTER === 'all' ? 'on' : '') + '">All</button><button data-nf="unread" class="' + (FILTER === 'unread' ? 'on' : '') + '">Unread</button></div>' +
        '<span class="small">' + ROWS.length + ' notifications</span></div>' +
        '<div class="card"><div class="card-body tight" id="nList"></div></div>';

      paint();
      document.querySelectorAll('[data-nf]').forEach(b => b.onclick = () => { FILTER = b.dataset.nf; App.rerender(); });
      document.getElementById('nAll').onclick = async () => {
        try {
          await window.agentdb.executeQuery('mark_all_read', { user_id: me.id });
          UI.toast('All notifications marked read', 'ok');
          App.refreshBadge(); App.rerender();
        } catch (e) { UI.toast(e.message, 'bad'); }
      };
    } catch (e) {
      el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>';
    }
  }

  function paint() {
    const box = document.getElementById('nList');
    if (!box) return;
    const rows = FILTER === 'unread' ? ROWS.filter(n => !n.is_read) : ROWS;
    if (!rows.length) {
      box.innerHTML = UI.empty(FILTER === 'unread' ? 'No unread notifications' : 'You are all caught up', 'New alerts about your work appear here.');
      return;
    }
    box.innerHTML = rows.map(n => {
      const route = targetFor(n);
      return '<div class="notif-item ' + (n.is_read ? '' : 'unread') + '" data-n="' + n.id + '" ' + (route ? 'data-route="' + route + '"' : '') + ' style="' + (route ? 'cursor:pointer' : '') + '">' +
        '<span class="notif-dot ' + (n.is_read ? 'read' : '') + '"></span>' +
        '<div style="flex:1;min-width:0"><div class="flex items-center gap8"><span class="strong" style="font-size:12.8px">' + UI.esc(n.title) + '</span>' +
        (n.kind ? '<span class="tag">' + UI.esc(String(n.kind).replace(/_/g, ' ')) + '</span>' : '') + '</div>' +
        '<div class="small" style="margin-top:2px;line-height:1.45">' + UI.esc(n.body || '') + '</div>' +
        '<div class="small" style="margin-top:4px;font-size:10.5px">' + UI.rel(n.created_at) + '</div></div>' +
        (route ? '<span class="ml-auto" style="color:var(--muted);align-self:center">' + UI.icon('arrow', 14) + '</span>' : '') +
        '</div>';
    }).join('');

    box.querySelectorAll('[data-n]').forEach(it => it.onclick = async () => {
      const n = ROWS.find(x => Number(x.id) === Number(it.dataset.n));
      if (!n) return;
      if (!n.is_read) {
        try { await window.agentdb.executeQuery('mark_one_read', { id: n.id }); n.is_read = true; } catch (e) { }
        App.refreshBadge();
      }
      const route = it.dataset.route;
      if (route) App.navigate(route);
      else paint();
    });
  }

  return { render };
})();
