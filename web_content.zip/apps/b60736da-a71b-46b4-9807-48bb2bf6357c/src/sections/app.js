/* SmartiQo · app shell, navigation and routing */
const App = (function () {
  const NAV = [
    { group: 'Operations', items: [
      { r: 'overview', label: 'Overview', icon: 'overview' },
      { r: 'departments', label: 'Departments', icon: 'building', hideFor: ['employee'] },
      { r: 'fms', label: 'FMS Management', icon: 'layers' },
      { r: 'tasks', label: 'Task Tracking', icon: 'checks' }
    ] },
    { group: 'Scheduling', items: [
      { r: 'site-visits', label: 'Site Visits', icon: 'pin' },
      { r: 'service-visits', label: 'Service Visits', icon: 'wrench' }
    ] },
    { group: 'Process Library', items: [
      { r: 'forms', label: 'Forms', icon: 'clipboard' },
      { r: 'documents', label: 'Documents', icon: 'folder' }
    ] },
    { group: 'Knowledge', items: [
      { r: 'reports', label: 'Reports & Analytics', icon: 'chart', hideFor: ['employee'] },
      { r: 'tools', label: 'Business Tools', icon: 'grid' }
    ] },
    { group: 'System', items: [
      { r: 'notifications', label: 'Notifications', icon: 'bell' },
      { r: 'settings', label: 'Admin Settings', icon: 'gear', adminOnly: true }
    ] }
  ];

  const TITLES = {
    overview: 'Overview', departments: 'Departments', fms: 'FMS Management', tasks: 'Task Tracking',
    'site-visits': 'Site Visit Scheduling', 'service-visits': 'Service Visit Scheduling', forms: 'Forms',
    documents: 'Documents', reports: 'Reports & Analytics', tools: 'Business Tools',
    notifications: 'Notifications', settings: 'Admin Settings'
  };

  const state = {
    user: null,
    rangeKey: 'month',
    from: null,
    to: null,
    search: '',
    unread: 0
  };

  function setRange(key) {
    const t = new Date();
    const iso = (x) => x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0');
    let from, to;
    if (key === 'today') { from = iso(t); to = iso(t); }
    else if (key === 'yesterday') { const y = new Date(t); y.setDate(y.getDate() - 1); from = iso(y); to = iso(y); }
    else if (key === 'week') { const w = new Date(t); w.setDate(w.getDate() - 6); from = iso(w); to = iso(t); }
    else if (key === 'month') { from = iso(new Date(t.getFullYear(), t.getMonth(), 1)); to = iso(t); }
    else if (key === 'lastmonth') { from = iso(new Date(t.getFullYear(), t.getMonth() - 1, 1)); to = iso(new Date(t.getFullYear(), t.getMonth(), 0)); }
    else if (key === 'quarter') { const q = new Date(t); q.setMonth(q.getMonth() - 2); from = iso(new Date(q.getFullYear(), q.getMonth(), 1)); to = iso(t); }
    state.rangeKey = key;
    state.from = from; state.to = to;
  }

  function rangeLabel() {
    const sel = document.getElementById('rangeSelect');
    if (sel) return sel.options[sel.selectedIndex].text;
    return 'This month';
  }

  function currentRoute() {
    const h = (location.hash || '#/overview').replace(/^#\/?/, '');
    const parts = h.split('/').filter(Boolean);
    return { route: parts[0] || 'overview', id: parts[1] || null };
  }

  function navHtml() {
    const role = state.user.role;
    return NAV.map(g => {
      const items = g.items.filter(i => Auth.allowed(i.r) && (i.hideFor || []).indexOf(role) < 0 && (!i.adminOnly || role === 'admin'));
      if (!items.length) return '';
      return '<div class="nav-group"><div class="nav-label">' + g.group + '</div>' +
        items.map(i => '<div class="nav-item" data-route="' + i.r + '">' + UI.icon(i.icon, 16) + '<span>' + i.label + '</span>' +
          (i.r === 'notifications' ? '<span class="nav-badge" id="navBadge" hidden>0</span>' : '') + '</div>').join('') +
        '</div>';
    }).join('');
  }

  function shellHtml() {
    const u = state.user;
    return '<div class="shell">' +
      '<aside class="sidebar" id="sidebar">' +
      '<div class="brand"><div class="brand-mark">S</div><div><div class="brand-name">SmartiQo</div><div class="brand-sub">Process Management</div></div></div>' +
      '<nav class="side-nav">' + navHtml() + '</nav>' +
      '<div class="side-foot"><div class="side-user" id="sideUser">' + UI.avatar(u.name, u.color) +
      '<div style="min-width:0"><div class="nm">' + UI.esc(u.name) + '</div><div class="rl">' + UI.esc((u.role || '').replace(/_/g, ' ')) + '</div></div>' +
      '<span class="ml-auto" style="color:#66799A">' + UI.icon('chevron', 14) + '</span></div></div>' +
      '</aside>' +
      '<div class="main">' +
      '<header class="topbar">' +
      '<button class="mobile-top no-print" id="menuBtn" aria-label="Menu">' + UI.icon('menu', 17) + '</button>' +
      '<div class="crumb">SmartiQo <span style="opacity:.5">/</span> <b id="crumbNow">Overview</b></div>' +
      '<div class="top-search"><span class="si">' + UI.icon('search', 14) + '</span>' +
      '<input id="globalSearch" type="search" placeholder="Search FMS, tasks, customers, documents…" autocomplete="off">' +
      '<div class="search-pop" id="searchPop"></div></div>' +
      '<div class="top-actions">' +
      '<select class="range-select no-print" id="rangeSelect" title="Reporting period">' +
      '<option value="today">Today</option><option value="yesterday">Yesterday</option>' +
      '<option value="week">This week</option><option value="month" selected>This month</option>' +
      '<option value="lastmonth">Last month</option><option value="quarter">Last 3 months</option>' +
      '<option value="custom">Custom range…</option></select>' +
      '<div style="position:relative"><button class="icon-btn no-print" id="bellBtn" title="Notifications">' + UI.icon('bell', 16) + '<span class="dot" id="bellDot" hidden></span></button>' +
      '<div class="drop" id="bellDrop" style="min-width:330px;right:0"></div></div>' +
      '<div style="position:relative"><div class="top-user" id="userBtn">' + UI.avatar(u.name, u.color, 'sm') +
      '<div><div class="nm">' + UI.esc(u.name.split(' ')[0]) + '</div><div class="rl">' + UI.esc((u.role || '').replace(/_/g, ' ')) + '</div></div>' + UI.icon('chevron', 13) + '</div>' +
      '<div class="drop" id="userDrop"></div></div>' +
      '</div></header>' +
      '<main class="page" id="pageRoot"></main>' +
      '</div></div>';
  }

  function bindShell() {
    document.querySelectorAll('.nav-item').forEach(n => {
      n.onclick = () => { navigate('/' + n.dataset.route); document.getElementById('sidebar').classList.remove('open'); };
    });
    document.getElementById('menuBtn').onclick = () => document.getElementById('sidebar').classList.toggle('open');

    const rs = document.getElementById('rangeSelect');
    rs.value = state.rangeKey;
    rs.onchange = () => {
      if (rs.value === 'custom') { customRange(); return; }
      setRange(rs.value); rerender();
    };

    const bell = document.getElementById('bellBtn'), bd = document.getElementById('bellDrop');
    bell.onclick = (e) => { e.stopPropagation(); toggleDrop(bd); if (bd.classList.contains('on')) loadBell(bd); };
    const ub = document.getElementById('userBtn'), ud = document.getElementById('userDrop');
    ud.innerHTML = '<div style="padding:9px 10px 8px"><div class="strong" style="font-size:12.5px">' + UI.esc(state.user.name) + '</div><div class="small">' + UI.esc(state.user.email) + '</div>' +
      '<div class="tag" style="margin-top:6px">' + UI.esc((state.user.role || '').replace(/_/g, ' ')) + '</div></div><div class="drop-sep"></div>' +
      '<div class="drop-item" data-act="profile">' + UI.icon('user', 14) + ' My profile</div>' +
      '<div class="drop-item" data-act="password">' + UI.icon('lock', 14) + ' Change password</div>' +
      '<div class="drop-item" data-act="theme">' + UI.icon('eye', 14) + ' Toggle theme</div>' +
      '<div class="drop-sep"></div>' +
      '<div class="drop-item" data-act="logout" style="color:var(--bad)">' + UI.icon('logout', 14) + ' Sign out</div>';
    ub.onclick = (e) => { e.stopPropagation(); toggleDrop(ud); };
    ud.querySelectorAll('[data-act]').forEach(it => {
      it.onclick = () => { ud.classList.remove('on'); const a = it.dataset.act; if (a === 'logout') logout(); else if (a === 'profile') profileModal(); else if (a === 'password') passwordModal(); else toggleTheme(); };
    });
    document.getElementById('sideUser').onclick = () => { profileModal(); };

    const gs = document.getElementById('globalSearch'), pop = document.getElementById('searchPop');
    gs.oninput = UI.debounce(async () => {
      const term = gs.value.trim();
      if (term.length < 2) { pop.classList.remove('on'); return; }
      try {
        const r = await window.agentdb.executeQuery('global_search', { term });
        if (!r.rows.length) { pop.innerHTML = '<div class="sp-item" style="cursor:default"><span class="sp-sub">No matches for “' + UI.esc(term) + '”</span></div>'; }
        else {
          pop.innerHTML = r.rows.map(x => '<div class="sp-item" data-route="' + UI.esc(x.route) + '"><span class="sp-kind">' + UI.esc(x.kind) + '</span><div style="min-width:0"><div class="sp-lbl">' + UI.esc(x.label) + '</div><div class="sp-sub">' + UI.esc(x.sub || '') + '</div></div></div>').join('');
          pop.querySelectorAll('.sp-item').forEach(i => i.onclick = () => { pop.classList.remove('on'); gs.value = ''; navigate(i.dataset.route); });
        }
        pop.classList.add('on');
      } catch (e) { console.warn(e); }
    }, 260);
    document.addEventListener('click', (e) => {
      if (!pop.contains(e.target) && e.target !== gs) pop.classList.remove('on');
      if (!bd.contains(e.target) && e.target !== bell) bd.classList.remove('on');
      if (!ud.contains(e.target) && !ub.contains(e.target)) ud.classList.remove('on');
    });
    gs.addEventListener('keydown', e => { if (e.key === 'Enter') { const first = pop.querySelector('.sp-item[data-route]'); if (first) first.click(); } });
  }

  function toggleDrop(el) {
    const open = el.classList.contains('on');
    document.querySelectorAll('.drop.on').forEach(d => d.classList.remove('on'));
    if (!open) el.classList.add('on');
  }

  async function loadBell(bd) {
    try {
      const r = await window.agentdb.executeQuery('load_notifications', { user_id: state.user.id, limit: 6 });
      bd.innerHTML = '<div style="padding:10px 12px 6px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--muted)">Notifications</div>' +
        (r.rows.length ? r.rows.map(x => '<div class="drop-item" style="align-items:flex-start" data-nid="' + x.id + '">' +
          '<span class="notif-dot ' + (x.is_read ? 'read' : '') + '" style="margin-top:5px"></span><div><div style="font-size:12px;font-weight:600">' + UI.esc(x.title) + '</div><div class="small" style="white-space:normal">' + UI.esc(x.body || '') + '</div><div class="small" style="font-size:10px;margin-top:2px">' + UI.rel(x.created_at) + '</div></div></div>').join('')
          : '<div class="sp-sub" style="padding:14px 12px">You are all caught up.</div>') +
        '<div class="drop-sep"></div><div class="drop-item" id="allNotifs">' + UI.icon('arrow', 14) + ' View all notifications</div>';
      bd.querySelector('#allNotifs').onclick = () => { bd.classList.remove('on'); navigate('/notifications'); };
    } catch (e) { bd.innerHTML = '<div class="sp-sub" style="padding:14px">Could not load notifications.</div>'; }
  }

  function customRange() {
    UI.modal({
      title: 'Custom date range',
      body: '<div class="form-grid"><div class="field"><label>From</label><input class="input" type="date" id="crFrom" value="' + state.from + '"></div>' +
        '<div class="field"><label>To</label><input class="input" type="date" id="crTo" value="' + state.to + '"></div></div>' +
        '<div class="small">Applies to Overview, Task Tracking and Reports.</div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="crApply">Apply range</button>',
      onMount: (bg, close) => {
        bg.querySelector('#crApply').onclick = () => {
          const f = bg.querySelector('#crFrom').value, t = bg.querySelector('#crTo').value;
          if (!f || !t) { UI.toast('Choose both dates', 'bad'); return; }
          if (f > t) { UI.toast('From date must be before To date', 'bad'); return; }
          state.from = f; state.to = t; state.rangeKey = 'custom';
          const sel = document.getElementById('rangeSelect');
          const opt = document.createElement('option');
          opt.value = 'custom'; opt.textContent = UI.fmtShort(f) + ' – ' + UI.fmtShort(t); opt.selected = true;
          sel.querySelectorAll('option[data-c]').forEach(o => o.remove()); opt.dataset.c = '1';
          sel.appendChild(opt); sel.value = 'custom';
          close(); rerender();
        };
      }
    });
  }

  function toggleTheme() {
    const h = document.documentElement;
    h.setAttribute('data-theme', h.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    rerender();
  }

  function profileModal() {
    const u = state.user;
    UI.modal({
      title: 'My profile',
      body: '<div class="flex items-center gap12 mb16">' + UI.avatar(u.name, u.color, 'lg') + '<div><div class="strong" style="font-size:15px">' + UI.esc(u.name) + '</div><div class="small">' + UI.esc(u.designation || '') + '</div></div></div>' +
        '<dl class="kv"><dt>Email</dt><dd>' + UI.esc(u.email) + '</dd><dt>Role</dt><dd style="text-transform:capitalize">' + UI.esc((u.role || '').replace(/_/g, ' ')) + '</dd><dt>Access scope</dt><dd>' + (u.role === 'admin' ? 'All departments' : u.role === 'department_head' ? 'Own department' : 'Own tasks and visits') + '</dd><dt>Session</dt><dd>Active · role-based</dd></dl>',
      foot: '<button class="btn" data-close>Close</button>'
    });
  }

  function passwordModal() {
    UI.modal({
      title: 'Change password',
      body: '<div class="field"><label>Current password</label><input class="input" type="password" id="cpOld"></div>' +
        '<div class="field"><label>New password</label><input class="input" type="password" id="cpNew" placeholder="At least 8 characters"></div>' +
        '<div class="field"><label>Confirm new password</label><input class="input" type="password" id="cpNew2"></div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="cpSave">Update password</button>',
      onMount: (bg, close) => {
        bg.querySelector('#cpSave').onclick = async () => {
          const o = bg.querySelector('#cpOld').value, n1 = bg.querySelector('#cpNew').value, n2 = bg.querySelector('#cpNew2').value;
          if (!o || !n1) { UI.toast('Fill in all fields', 'bad'); return; }
          if (n1.length < 8) { UI.toast('Use at least 8 characters', 'bad'); return; }
          if (n1 !== n2) { UI.toast('New passwords do not match', 'bad'); return; }
          try {
            const chk = await Auth.login(state.user.email, o);
            if (chk.error) { UI.toast('Current password is incorrect', 'bad'); return; }
            await window.agentdb.executeQuery('reset_password', { id: state.user.id, password_hash: Auth.hash(n1) });
            close(); UI.toast('Password updated', 'ok');
          } catch (e) { UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  function logout() {
    Auth.clear();
    state.user = null;
    location.hash = '';
    boot();
  }

  async function refreshBadge() {
    try {
      const r = await window.agentdb.executeQuery('unread_count', { user_id: state.user.id });
      const c = r.rows[0] ? Number(r.rows[0].unread) : 0;
      state.unread = c;
      const dot = document.getElementById('bellDot'), badge = document.getElementById('navBadge');
      if (dot) dot.hidden = c === 0;
      if (badge) { badge.hidden = c === 0; badge.textContent = c > 99 ? '99+' : c; }
    } catch (e) { }
  }

  function updateChrome(route) {
    document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.route === route));
    const c = document.getElementById('crumbNow');
    if (c) c.textContent = TITLES[route] || 'Overview';
    document.title = (TITLES[route] || 'Overview') + ' · SmartiQo';
  }

  async function renderRoute() {
    const { route, id } = currentRoute();
    document.body.classList.toggle('view-only', Auth.viewOnly());
    if (!TITLES[route]) { location.hash = '#/' + Auth.firstRoute(); return; }
    if (!Auth.allowed(route)) { location.hash = '#/' + Auth.firstRoute(); return; }
    const def = NAV.reduce((a, g) => a.concat(g.items), []).find(i => i.r === route);
    if (def && (def.hideFor || []).indexOf(state.user.role) >= 0) { location.hash = '#/' + Auth.firstRoute(); return; }
    updateChrome(route);
    // Any open modal or drawer belongs to the previous route.
    document.querySelectorAll('.modal-bg').forEach(m => m.remove());
    const root = document.getElementById('pageRoot');
    if (!root) return;
    root.innerHTML = '<div class="loading-row">Loading ' + (TITLES[route] || '') + '…</div>';
    try {
      const page = window.PAGES[route];
      if (!page) throw new Error('Unknown page ' + route);
      await page.render(root, { id: id, state: state });
    } catch (e) {
      console.error('[page]', route, e);
      root.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div><b>Could not load this page.</b><br>' + UI.esc(e.message) + '</div></div>';
    }
    window.scrollTo({ top: 0, behavior: 'instant' });
  }

  function rerender() { renderRoute(); }

  function navigate(hash) {
    if (location.hash === '#' + hash) renderRoute();
    else location.hash = hash;
  }

  function enter(user) {
    state.user = user;
    if (!state.from) setRange('month');
    const content = document.getElementById('content');
    document.body.classList.toggle('view-only', Auth.viewOnly());
    content.innerHTML = shellHtml();
    bindShell();
    refreshBadge();
    const home = Auth.firstRoute();
    const want = '#/' + home;
    // Setting the hash fires hashchange, which renders the route once. Only
    // render directly when the hash is already where we want it.
    if (location.hash === want) renderRoute();
    else if (location.hash && Auth.allowed(currentRoute().route)) renderRoute();
    else location.hash = want;
    // Persist overdue states + notify (server-side), then refresh badge.
    window.agentdb.executeQuery('sync_overdue', {})
      .then(() => refreshBadge())
      .catch(e => console.warn('[sync_overdue]', e.message));
  }

  // Read-only accounts cannot write even if they reach a write control: the
  // data layer refuses the call, so nothing can be saved by accident.
  function installWriteGuard() {
    if (window.__sqWriteGuard || !window.agentdb || !window.agentdb.executeQuery) return;
    window.__sqWriteGuard = true;
    const raw = window.agentdb.executeQuery.bind(window.agentdb);
    window.agentdb.executeQuery = function (name, params) {
      if (Auth.viewOnly() && /^(create_|update_|delete_|save_|link_|reset_password|reschedule_|record_|sync_overdue|sync_visit_form_status)/.test(name)) {
        UI.toast('View-only account — changes are disabled.', 'warn');
        return Promise.reject(new Error('View-only account'));
      }
      return raw(name, params);
    };
  }

  async function boot() {
    installWriteGuard();
    const content = document.getElementById('content');
    const u = Auth.getSession();
    if (!u) {
      content.hidden = false;
      document.getElementById('loading').hidden = true;
      const wrap = document.createElement('div');
      wrap.id = 'loginMount';
      content.innerHTML = '';
      content.appendChild(wrap);
      Auth.renderLogin(wrap, (user) => enter(user));
      return;
    }
    enter(u);
  }

  window.addEventListener('hashchange', () => { if (state.user) renderRoute(); });

  return { boot, enter, navigate, rerender, renderRoute, state, setRange, logout, refreshBadge, rangeLabel };
})();

window.App = App;
