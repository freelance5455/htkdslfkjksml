/* SmartiQo · Site and service visit scheduling */
window.PAGES = window.PAGES || {};
(function () {
  function make(type) {
    const isSite = type === 'site';
    const M = {
      month: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
      view: 'calendar', dept: 0, emp: 0, status: '', rows: [], today: [], ready: false
    };

    function iso(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
    function monthStart() { return iso(new Date(M.month.getFullYear(), M.month.getMonth(), 1)); }
    function monthEnd() { return iso(new Date(M.month.getFullYear(), M.month.getMonth() + 1, 0)); }
    function monthLabel() { return M.month.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }); }

    function scope() {
      const u = Auth.getSession();
      if (!M.ready) {
        if (u.role === 'department_head') M.dept = u.department_id || 0;
        if (u.role === 'employee') M.emp = u.id;
        M.ready = true;
      }
      return u;
    }

    async function loadMonth() {
      const r = await window.agentdb.executeQuery('load_visits', {
        visit_type: type, from_date: monthStart(), to_date: monthEnd(),
        department_id: M.dept, employee_id: M.emp, status: M.status
      });
      return r.rows;
    }
    async function loadToday() {
      const t = UI.todayISO(0);
      const r = await window.agentdb.executeQuery('load_visits', {
        visit_type: type, from_date: t, to_date: t, department_id: M.dept, employee_id: M.emp, status: ''
      });
      return r.rows;
    }

    function kpi(rows) {
      const today = UI.todayISO(0);
      const tCount = M.today.length;
      const scheduled = rows.filter(v => v.status === 'scheduled').length;
      const done = rows.filter(v => v.status === 'completed').length;
      const cancelled = rows.filter(v => v.status === 'cancelled').length;
      const forms = rows.filter(v => v.form_status === 'pending').length;
      const synced = rows.filter(v => v.calendar_event_id).length;
      return '<div class="kpi-grid">' +
        '<div class="kpi ' + (isSite ? 'blue' : 'purple') + '"><div class="k-top"><span class="k-lbl">Today</span><span class="k-ico">' + UI.icon(isSite ? 'pin' : 'wrench', 14) + '</span></div><div class="k-val">' + tCount + '</div><div class="k-sub">' + UI.fmtDate(today) + '</div></div>' +
        '<div class="kpi blue"><div class="k-top"><span class="k-lbl">Scheduled</span><span class="k-ico">' + UI.icon('calendar', 14) + '</span></div><div class="k-val">' + scheduled + '</div><div class="k-sub">' + UI.esc(monthLabel()) + '</div></div>' +
        '<div class="kpi ok"><div class="k-top"><span class="k-lbl">Completed</span><span class="k-ico">' + UI.icon('checkCircle', 14) + '</span></div><div class="k-val">' + done + '</div><div class="k-sub">' + cancelled + ' cancelled</div></div>' +
        '<div class="kpi warn"><div class="k-top"><span class="k-lbl">Forms pending</span><span class="k-ico">' + UI.icon('clipboard', 14) + '</span></div><div class="k-val">' + forms + '</div><div class="k-sub">After-visit forms due</div></div>' +
        '<div class="kpi ' + (synced ? 'ok' : 'purple') + '"><div class="k-top"><span class="k-lbl">Calendar synced</span><span class="k-ico">' + UI.icon('calendar', 14) + '</span></div><div class="k-val">' + synced + '/' + rows.length + '</div><div class="k-sub">' + (synced ? 'Google Calendar' : 'Not connected') + '</div></div>' +
        '</div>';
    }

    function calendarHtml(rows) {
      const first = new Date(M.month.getFullYear(), M.month.getMonth(), 1);
      const startOffset = (first.getDay() + 6) % 7;
      const days = new Date(M.month.getFullYear(), M.month.getMonth() + 1, 0).getDate();
      const prevDays = new Date(M.month.getFullYear(), M.month.getMonth(), 0).getDate();
      const todayStr = UI.todayISO(0);
      const byDay = {};
      rows.forEach(v => { const k = String(v.visit_date).slice(0, 10); (byDay[k] = byDay[k] || []).push(v); });

      let cells = '';
      for (let i = 0; i < startOffset; i++) {
        const dn = prevDays - startOffset + i + 1;
        cells += '<div class="cal-cell other"><div class="cal-date">' + dn + '</div></div>';
      }
      for (let d = 1; d <= days; d++) {
        const dateStr = iso(new Date(M.month.getFullYear(), M.month.getMonth(), d));
        const evs = (byDay[dateStr] || []).slice().sort((a, b) => String(a.start_time).localeCompare(String(b.start_time)));
        cells += '<div class="cal-cell' + (dateStr === todayStr ? ' today' : '') + '" data-day="' + dateStr + '">' +
          '<div class="cal-date">' + d + '</div>' +
          evs.slice(0, 2).map(v => '<span class="cal-ev ' + (v.visit_type === 'service' ? 'srv' : '') + '" data-visit="' + v.id + '" title="' + UI.esc(v.customer_name + ' · ' + v.status) + '">' +
            UI.fmtTime(v.start_time) + ' ' + UI.esc(v.customer_name) + '</span>').join('') +
          (evs.length > 2 ? '<span class="small" style="font-size:9px;color:var(--muted)">+' + (evs.length - 2) + ' more</span>' : '') +
          '</div>';
      }
      const tail = (7 - ((startOffset + days) % 7)) % 7;
      for (let i = 1; i <= tail; i++) cells += '<div class="cal-cell other"><div class="cal-date">' + i + '</div></div>';

      return '<div class="cal-grid">' + ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => '<div class="cal-dow">' + d + '</div>').join('') + cells + '</div>';
    }

    function listHtml(rows) {
      if (!rows.length) return UI.empty('No ' + (isSite ? 'site' : 'service') + ' visits this month', 'Schedule a visit or move to another month.', '<button class="btn primary sm" id="emptyVisit">' + UI.icon('plus', 13) + ' Schedule visit</button>');
      return '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Date</th><th>Time</th><th>Customer</th><th>City</th><th>Assignee</th><th>Department</th><th>Priority</th><th>Status</th><th>Form</th><th>Calendar</th></tr></thead><tbody>' +
        rows.map(v => '<tr data-visit="' + v.id + '" style="cursor:pointer">' +
          '<td class="nowrap"><div class="strong">' + UI.fmtShort(v.visit_date) + '</div><div class="small">' + new Date(String(v.visit_date).slice(0, 10) + 'T00:00:00').toLocaleDateString('en-GB', { weekday: 'short' }) + '</div></td>' +
          '<td class="mono nowrap small">' + UI.fmtTime(v.start_time) + '–' + UI.fmtTime(v.end_time) + '</td>' +
          '<td><div class="strong">' + UI.esc(v.customer_name) + '</div><div class="small">' + UI.esc(v.purpose || '') + '</div></td>' +
          '<td class="small">' + UI.esc(v.city || '—') + '</td>' +
          '<td class="small">' + UI.esc(v.assignee || 'Unassigned') + '</td>' +
          '<td class="small">' + UI.esc(v.department_name || '—') + '</td>' +
          '<td>' + UI.prio(v.priority) + '</td>' +
          '<td>' + UI.pill(v.status) + '</td>' +
          '<td>' + (v.form_status === 'pending' ? '<span class="pill amber">Pending</span>' : v.form_status === 'completed' ? '<span class="pill green">Received</span>' : '<span class="small">—</span>') + '</td>' +
          '<td>' + UI.pill(v.calendar_status || 'not_connected') + '</td></tr>').join('') +
        '</tbody></table></div>';
    }

    async function render(el) {
      const me = scope();
      const title = isSite ? 'Site Visits' : 'Service Visits';
      let depts = [], people = [];
      try {
        const [d, p] = await Promise.all([
          window.agentdb.executeQuery('load_departments', {}),
          window.agentdb.executeQuery('load_people', { department_id: 0, role: '' })
        ]);
        depts = d.rows; people = p.rows;
      } catch (e) { }
      let rows;
      try { rows = await loadMonth(); M.rows = rows; }
      catch (e) { el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>'; return; }
      try { M.today = await loadToday(); } catch (e) { M.today = []; }

      const scoped = me.role !== 'admin';

      el.innerHTML =
        '<div class="page-head"><div><h1>' + title + '</h1><div class="sub">' + (isSite ? 'Customer site visits, engineer allocation and after-visit forms' : 'Service calls, engineer allocation and service reports') + '</div></div>' +
        '<div class="page-actions"><button class="btn" id="vCal">' + UI.icon('calendar', 14) + ' Google Calendar</button>' +
        '<button class="btn" id="vExport">' + UI.icon('download', 14) + ' CSV</button>' +
        '<button class="btn primary" id="vNew">' + UI.icon('plus', 14) + ' Schedule visit</button></div></div>' +
        (rows.some(v => v.calendar_event_id) ? '' : '<div class="banner info">' + UI.icon('calendar', 15) + '<div><b>Google Calendar is not connected.</b> Visits are tracked in SmartiQo; once an admin connects the calendar in Admin Settings, events sync automatically. Nothing is being created in Google Calendar today.</div></div>') +
        (scoped ? '<div class="banner info">' + UI.icon('shield', 15) + '<div>' + (me.role === 'department_head' ? 'You are viewing your department’s visits.' : 'You are viewing visits assigned to you.') + '</div></div>' : '') +
        '<div id="vKpis">' + kpi(rows) + '</div>' +
        '<div class="toolbar"><div class="seg"><button data-view="calendar" class="' + (M.view === 'calendar' ? 'on' : '') + '">Calendar</button><button data-view="list" class="' + (M.view === 'list' ? 'on' : '') + '">List</button></div>' +
        '<div class="flex items-center gap8" style="margin-left:4px"><button class="btn sm" id="vPrev">‹</button><div class="strong" style="min-width:132px;text-align:center">' + monthLabel() + '</div><button class="btn sm" id="vNext">›</button><button class="btn sm" id="vToday">Today</button></div>' +
        (!scoped ? '<select class="select" id="vDept"><option value="0">All departments</option>' + depts.map(d => '<option value="' + d.id + '"' + (Number(M.dept) === Number(d.id) ? ' selected' : '') + '>' + UI.esc(d.name) + '</option>').join('') + '</select>' : '') +
        '<select class="select" id="vEmp"><option value="0">Everyone</option>' + people.map(p => '<option value="' + p.id + '"' + (Number(M.emp) === Number(p.id) ? ' selected' : '') + '>' + UI.esc(p.full_name) + '</option>').join('') + '</select>' +
        '<select class="select" id="vStatus"><option value="">All statuses</option>' + ['scheduled', 'completed', 'cancelled', 'rescheduled'].map(s => '<option value="' + s + '"' + (M.status === s ? ' selected' : '') + '>' + s.charAt(0).toUpperCase() + s.slice(1) + '</option>').join('') + '</select></div>' +
        '<div class="card"><div class="card-head"><h3>' + monthLabel() + '</h3><span class="small" id="vCount">' + rows.length + ' visits</span></div>' +
        '<div class="card-body" id="vBody">' + (M.view === 'calendar' ? calendarHtml(rows) : '<div style="overflow-x:auto">' + listHtml(rows) + '</div>') + '</div></div>';

      bind(el, rows, people, depts, me);

      async function refresh() {
        const body = document.getElementById('vBody');
        if (!body) return;
        body.innerHTML = '<div class="loading-row">Loading…</div>';
        try {
          rows = await loadMonth(); M.rows = rows; M.today = await loadToday();
          document.getElementById('vKpis').innerHTML = kpi(rows);
          const c = document.getElementById('vCount'); if (c) c.textContent = rows.length + ' visits';
          body.innerHTML = M.view === 'calendar' ? calendarHtml(rows) : '<div style="overflow-x:auto">' + listHtml(rows) + '</div>';
          bind(el, rows, people, depts, me);
        } catch (e) { body.innerHTML = '<div class="banner warn">' + UI.icon('alert', 15) + '<div>' + UI.esc(e.message) + '</div></div>'; }
      }

      function bind(root, rws, ppl, dpts, usr) {
        root.querySelectorAll('[data-view]').forEach(b => b.onclick = () => { M.view = b.dataset.view; App.rerender(); });
        const pv = root.querySelector('#vPrev'); if (pv) pv.onclick = () => { M.month = new Date(M.month.getFullYear(), M.month.getMonth() - 1, 1); App.rerender(); };
        const nx = root.querySelector('#vNext'); if (nx) nx.onclick = () => { M.month = new Date(M.month.getFullYear(), M.month.getMonth() + 1, 1); App.rerender(); };
        const td = root.querySelector('#vToday'); if (td) td.onclick = () => { M.month = new Date(new Date().getFullYear(), new Date().getMonth(), 1); App.rerender(); };
        const dp = root.querySelector('#vDept'); if (dp) dp.onchange = (e) => { M.dept = Number(e.target.value) || 0; refresh(); };
        const ep = root.querySelector('#vEmp'); if (ep) ep.onchange = (e) => { M.emp = Number(e.target.value) || 0; refresh(); };
        const st = root.querySelector('#vStatus'); if (st) st.onchange = (e) => { M.status = e.target.value; refresh(); };
        const nv = root.querySelector('#vNew'); if (nv) nv.onclick = () => visitModal(null, UI.todayISO(0), usr, ppl, dpts);
        const ev = root.querySelector('#emptyVisit'); if (ev) ev.onclick = () => visitModal(null, UI.todayISO(0), usr, ppl, dpts);
        const ex = root.querySelector('#vExport');
        if (ex) ex.onclick = () => UI.downloadCsv(M.rows.map(v => ({
          Date: v.visit_date, Start: v.start_time, End: v.end_time, Customer: v.customer_name, Phone: v.customer_phone,
          City: v.city, Address: v.address, Type: v.visit_type, Assignee: v.assignee, Department: v.department_name,
          Purpose: v.purpose, Status: v.status, Priority: v.priority, FormStatus: v.form_status, Calendar: v.calendar_status
        })), 'smartiqo-' + (isSite ? 'site' : 'service') + '-visits.csv');
        const cal = root.querySelector('#vCal'); if (cal) cal.onclick = calendarModal;
        root.querySelectorAll('[data-day]').forEach(c => c.onclick = (e) => {
          if (e.target.closest('[data-visit]')) return;
          visitModal(null, c.dataset.day, usr, ppl, dpts);
        });
        root.querySelectorAll('[data-visit]').forEach(v => v.onclick = (e) => { e.stopPropagation(); openVisit(Number(v.dataset.visit), rws, ppl, dpts, usr); });
      }
    }

    function calendarModal() {
      UI.modal({
        title: 'Google Calendar',
        body: '<div class="banner warn">' + UI.icon('alert', 15) + '<div><b>Google Calendar is not connected.</b><br>Visit records live in SmartiQo and no events are being written to Google Calendar. Connecting the calendar needs an OAuth client ID and calendar ID, configured by an administrator.</div></div>' +
          '<dl class="kv"><dt>Status</dt><dd>' + UI.pill('not_connected') + '</dd><dt>Calendar</dt><dd>primary</dd><dt>Syncing</dt><dd>Off</dd><dt>Meet links</dt><dd>Off</dd></dl>' +
          '<p class="small mt12">To enable sync: Admin Settings → Google Calendar → paste the OAuth client ID and calendar ID, then enable syncing. Existing visits can then be pushed individually from their detail view.</p>',
        foot: (Auth.isAdmin() ? '<button class="btn primary" id="calCfg">Open calendar settings</button>' : '<button class="btn" data-close>Close</button>'),
        onMount: (bg, close) => {
          const c = bg.querySelector('#calCfg');
          if (c) c.onclick = () => { close(); App.state.settingsTab = 'calendar'; App.navigate('/settings'); };
        }
      });
    }

    function visitModal(v, date, me, people, depts) {
      const isNew = !v;
      const m = UI.modal({
        title: isNew ? 'Schedule ' + (isSite ? 'site' : 'service') + ' visit' : 'Reschedule visit',
        size: 'wide',
        body: '<div class="form-grid">' +
          '<div class="field full"><label>Customer / site name *</label><input class="input" id="vCust" value="' + UI.esc(v ? v.customer_name : '') + '"></div>' +
          '<div class="field"><label>Phone</label><input class="input" id="vPhone" value="' + UI.esc(v ? v.customer_phone || '' : '') + '"></div>' +
          '<div class="field"><label>City</label><input class="input" id="vCity" value="' + UI.esc(v ? v.city || '' : '') + '"></div>' +
          '<div class="field full"><label>Address</label><input class="input" id="vAddr" value="' + UI.esc(v ? v.address || '' : '') + '"></div>' +
          '<div class="field"><label>Date *</label><input class="input" type="date" id="vDate" value="' + UI.esc(v ? String(v.visit_date).slice(0, 10) : date) + '"></div>' +
          '<div class="field"><label>Assigned to</label><select class="select" id="vEmp2"><option value="0">Unassigned</option>' +
          people.map(p => '<option value="' + p.id + '"' + (v && Number(v.assigned_to) === Number(p.id) ? ' selected' : '') + '>' + UI.esc(p.full_name) + ' · ' + UI.esc(p.department_name || '') + '</option>').join('') + '</select></div>' +
          '<div class="field"><label>Start time</label><input class="input" type="time" id="vStart" value="' + (v && v.start_time ? UI.fmtTime(v.start_time) : '10:00') + '"></div>' +
          '<div class="field"><label>End time</label><input class="input" type="time" id="vEnd" value="' + (v && v.end_time ? UI.fmtTime(v.end_time) : '11:30') + '"></div>' +
          (isNew ? '<div class="field"><label>Department</label><select class="select" id="vDept2"><option value="0">Unassigned</option>' +
            depts.map(d => '<option value="' + d.id + '"' + (me.role === 'department_head' && Number(me.department_id) === Number(d.id) ? ' selected' : '') + '>' + UI.esc(d.name) + '</option>').join('') + '</select></div>' +
            '<div class="field"><label>Priority</label><select class="select" id="vPrio"><option value="medium">Medium</option><option value="high">High</option><option value="low">Low</option><option value="critical">Critical</option></select></div>' : '') +
          '<div class="field full"><label>Purpose</label><input class="input" id="vPurpose" value="' + UI.esc(v ? v.purpose || '' : '') + '" placeholder="Installation, inspection, preventive maintenance…"></div>' +
          '<div class="field full"><label>Remarks</label><textarea class="textarea" id="vRem">' + UI.esc(v ? v.remarks || '' : '') + '</textarea></div></div>',
        foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="vSave">' + (isNew ? 'Schedule visit' : 'Save changes') + '</button>',
        onMount: (bg, close) => {
          bg.querySelector('#vSave').onclick = async () => {
            const cust = bg.querySelector('#vCust').value.trim();
            const dt = bg.querySelector('#vDate').value;
            if (!cust) { UI.toast('Customer name is required', 'bad'); return; }
            if (!dt) { UI.toast('Choose a visit date', 'bad'); return; }
            const btn = bg.querySelector('#vSave'); btn.disabled = true;
            try {
              if (isNew) {
                await window.agentdb.executeQuery('create_visit', {
                  visit_type: type, customer_name: cust, customer_phone: bg.querySelector('#vPhone').value.trim(),
                  address: bg.querySelector('#vAddr').value.trim(), city: bg.querySelector('#vCity').value.trim(),
                  assigned_to: Number(bg.querySelector('#vEmp2').value) || 0,
                  department_id: Number(bg.querySelector('#vDept2').value) || 0,
                  visit_date: dt, start_time: bg.querySelector('#vStart').value || '10:00',
                  end_time: bg.querySelector('#vEnd').value || '11:30',
                  purpose: bg.querySelector('#vPurpose').value.trim(), remarks: bg.querySelector('#vRem').value.trim(),
                  priority: bg.querySelector('#vPrio').value, status: 'scheduled'
                });
                await window.PAGES.departments.audit('Visit scheduled', 'visit', '', cust + ' on ' + dt);
                UI.toast('Visit scheduled for ' + UI.fmtShort(dt), 'ok');
              } else {
                await window.agentdb.executeQuery('reschedule_visit', {
                  id: v.id, visit_date: dt, start_time: bg.querySelector('#vStart').value || '10:00', end_time: bg.querySelector('#vEnd').value || '11:30'
                });
                await window.agentdb.executeQuery('update_visit', {
                  id: v.id, status: v.status === 'completed' ? 'completed' : 'rescheduled',
                  purpose: bg.querySelector('#vPurpose').value.trim(), remarks: bg.querySelector('#vRem').value.trim(), priority: v.priority
                });
                await window.PAGES.departments.audit('Visit rescheduled', 'visit', String(v.id), cust + ' → ' + dt);
                UI.toast('Visit rescheduled', 'ok');
              }
              close(); App.rerender();
            } catch (e) { btn.disabled = false; UI.toast(e.message, 'bad'); }
          };
        }
      });
      return m;
    }

    async function openVisit(id, rows, people, depts, me) {
      let v = (rows || M.rows).find(x => Number(x.id) === Number(id));
      if (!v) return;
      let forms = { rows: [] };
      try { forms = await window.agentdb.executeQuery('load_forms', { department_id: v.department_id || 0, fms_id: 0 }); } catch (e) { }
      const after = forms.rows.filter(f => f.form_type === 'after_visit' || f.form_type === 'feedback');

      const d = UI.drawer({
        title: v.customer_name,
        sub: '<span class="pill ' + (UI.STATUS[v.status] || { cls: 'grey' }).cls + '">' + UI.esc((UI.STATUS[v.status] || {}).label || v.status) + '</span> <span class="small">' + UI.fmtDate(v.visit_date) + ' · ' + UI.fmtTime(v.start_time) + '–' + UI.fmtTime(v.end_time) + '</span>',
        body: '<dl class="kv mb16">' +
          '<dt>Type</dt><dd><span class="pill ' + (isSite ? 'blue' : 'purple') + '">' + (isSite ? 'Site visit' : 'Service visit') + '</span></dd>' +
          '<dt>Phone</dt><dd>' + UI.esc(v.customer_phone || '—') + '</dd>' +
          '<dt>City</dt><dd>' + UI.esc(v.city || '—') + '</dd>' +
          '<dt>Address</dt><dd>' + UI.esc(v.address || '—') + '</dd>' +
          '<dt>Assignee</dt><dd>' + UI.esc(v.assignee || 'Unassigned') + '</dd>' +
          '<dt>Department</dt><dd>' + UI.esc(v.department_name || '—') + '</dd>' +
          '<dt>Priority</dt><dd>' + UI.prio(v.priority) + '</dd>' +
          '<dt>Purpose</dt><dd>' + UI.esc(v.purpose || '—') + '</dd>' +
          '<dt>Remarks</dt><dd>' + UI.esc(v.remarks || '—') + '</dd>' +
          '<dt>Form</dt><dd>' + (v.form_status === 'pending' ? '<span class="pill amber">After-visit form pending</span>' : v.form_status === 'completed' ? '<span class="pill green">Form received</span>' : '<span class="small">Not required yet</span>') + '</dd>' +
          '<dt>Calendar</dt><dd>' + UI.pill(v.calendar_status || 'not_connected') + '</dd></dl>' +
          '<div class="card" style="box-shadow:none"><div class="card-head"><h3>Actions</h3></div><div class="card-body" style="display:flex;flex-direction:column;gap:8px">' +
          '<button class="btn block" id="vResched">' + UI.icon('calendar', 14) + ' Reschedule</button>' +
          (v.status !== 'completed' ? '<button class="btn primary block" id="vDone">' + UI.icon('checkCircle', 14) + ' Mark completed</button>' : '') +
          (v.status !== 'cancelled' ? '<button class="btn block" id="vCancel">' + UI.icon('x', 14) + ' Cancel visit</button>' : '') +
          '<button class="btn block" id="vCalSync">' + UI.icon('calendar', 14) + ' Add to Google Calendar</button>' +
          '</div></div>' +
          (after.length ? '<div class="card" style="box-shadow:none;margin-top:12px"><div class="card-head"><h3>After-visit form</h3></div><div class="card-body">' +
            '<p class="small" style="margin:0 0 10px">Record the form response so the visit closes complete.</p>' +
            '<button class="btn primary block" id="vForm">' + UI.icon('clipboard', 14) + ' Record form submission</button></div></div>' : ''),
        foot: (Auth.isAdmin() ? '<button class="btn danger sm" id="vDelete">' + UI.icon('trash', 13) + ' Delete</button>' : '') + '<button class="btn" data-close>Close</button>',
        onMount: (bg, close) => {
          const rs = bg.querySelector('#vResched'); if (rs) rs.onclick = () => { close(); visitModal(v, String(v.visit_date).slice(0, 10), me, people, depts); };
          const dn = bg.querySelector('#vDone');
          if (dn) dn.onclick = async () => {
            const ok = await UI.confirmAction('Mark this visit as completed? An after-visit form becomes due.', { confirmLabel: 'Mark completed' });
            if (!ok) return;
            try {
              await window.agentdb.executeQuery('update_visit', { id: v.id, status: 'completed', purpose: '', remarks: '', priority: v.priority });
              await window.PAGES.departments.audit('Visit completed', 'visit', String(v.id), v.customer_name);
              close(); UI.toast('Visit completed', 'ok'); App.rerender();
            } catch (e) { UI.toast(e.message, 'bad'); }
          };
          const cn = bg.querySelector('#vCancel');
          if (cn) cn.onclick = async () => {
            const ok = await UI.confirmAction('Cancel this visit?', { danger: true, confirmLabel: 'Cancel visit' });
            if (!ok) return;
            try {
              await window.agentdb.executeQuery('update_visit', { id: v.id, status: 'cancelled', purpose: '', remarks: '', priority: v.priority });
              await window.PAGES.departments.audit('Visit cancelled', 'visit', String(v.id), v.customer_name);
              close(); UI.toast('Visit cancelled', 'ok'); App.rerender();
            } catch (e) { UI.toast(e.message, 'bad'); }
          };
          const cs = bg.querySelector('#vCalSync'); if (cs) cs.onclick = () => { close(); calendarModal(); };
          const fm = bg.querySelector('#vForm');
          if (fm) fm.onclick = () => { close(); formModal(v, after, me); };
          const dl = bg.querySelector('#vDelete');
          if (dl) dl.onclick = async () => {
            const ok = await UI.confirmAction('Delete this visit permanently?', { danger: true, confirmLabel: 'Delete visit' });
            if (!ok) return;
            try { await window.agentdb.executeQuery('delete_visit', { id: v.id }); close(); UI.toast('Visit deleted', 'ok'); App.rerender(); }
            catch (e) { UI.toast(e.message, 'bad'); }
          };
        }
      });
      return d;
    }

    function formModal(v, forms, me) {
      const options = forms.length ? forms : [{ id: 0, name: 'No after-visit form configured for this department' }];
      UI.modal({
        title: 'Record form submission',
        body: '<div class="banner info">' + UI.icon('clipboard', 15) + '<div>Submitting closes the after-visit requirement for <b>' + UI.esc(v.customer_name) + '</b>.</div></div>' +
          '<div class="field"><label>Form</label><select class="select" id="vfForm">' + options.map(f => '<option value="' + f.id + '">' + UI.esc(f.name) + '</option>').join('') + '</select></div>' +
          '<div class="field"><label>Response reference / link</label><input class="input" id="vfRef" placeholder="https://forms.gle/… or reference number"></div>',
        foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="vfSave"' + (forms.length ? '' : ' disabled') + '>Record submission</button>',
        onMount: (bg, close) => {
          bg.querySelector('#vfSave').onclick = async () => {
            const fid = Number(bg.querySelector('#vfForm').value) || 0;
            if (!fid) return;
            const btn = bg.querySelector('#vfSave'); btn.disabled = true;
            try {
              await window.agentdb.executeQuery('record_form_submission', {
                form_id: fid, visit_id: v.id, task_id: 0, submitted_by: me.id, reference: bg.querySelector('#vfRef').value.trim()
              });
              await window.agentdb.executeQuery('sync_visit_form_status', { id: v.id });
              await window.PAGES.departments.audit('After-visit form received', 'visit', String(v.id), v.customer_name);
              close(); UI.toast('Form submission recorded', 'ok'); App.rerender();
            } catch (e) { btn.disabled = false; UI.toast(e.message, 'bad'); }
          };
        }
      });
    }

    return { render, visitModal, calendarModal };
  }

  window.PAGES['site-visits'] = make('site');
  window.PAGES['service-visits'] = make('service');
})();
