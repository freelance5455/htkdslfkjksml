/* SmartiQo · shared UI helpers */
const UI = (function () {
  const ICONS = {
    overview: 'M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z',
    building: 'M3 21h18M5 21V5a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v16M15 21V9h2a2 2 0 0 1 2 2v10M9 7h2M9 11h2M9 15h2',
    layers: 'M12 2 2 7l10 5 10-5zM2 12l10 5 10-5M2 17l10 5 10-5',
    check: 'M20 6 9 17l-5-5',
    checks: 'M9 11l3 3L22 4M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11',
    pin: 'M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0zM12 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    wrench: 'M14.7 6.3a4 4 0 0 0 5 5l-9.4 9.4a2.8 2.8 0 0 1-4-4zM14.7 6.3l3-3 3 3-3 3',
    clipboard: 'M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2M9 2h6v4H9zM9 12h6M9 16h4',
    folder: 'M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z',
    chart: 'M3 3v18h18M7 16v-5M12 16V8M17 16v-3',
    grid: 'M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z',
    bell: 'M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0',
    gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z',
    search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.3-4.3',
    chevron: 'M6 9l6 6 6-6',
    user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
    logout: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
    plus: 'M12 5v14M5 12h14',
    x: 'M18 6 6 18M6 6l12 12',
    download: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
    printer: 'M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v8H6z',
    refresh: 'M23 4v6h-6M1 20v-6h6M3.5 9a9 9 0 0 1 14.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0 0 20.5 15',
    alert: 'M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01',
    clock: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2',
    checkCircle: 'M22 11.1V12a10 10 0 1 1-5.9-9.1M22 4 12 14.01l-3-3',
    external: 'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14 21 3',
    calendar: 'M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
    lock: 'M5 11h14v11H5zM8 11V7a4 4 0 0 1 8 0v4',
    eye: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    eyeOff: 'M17.9 17.9A10.1 10.1 0 0 1 12 20c-7 0-11-8-11-8a18.5 18.5 0 0 1 5.1-5.9M9.9 4.2A9.1 9.1 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.2 3.2M1 1l22 22M9.9 9.9a3 3 0 0 0 4.2 4.2',
    shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
    arrow: 'M5 12h14M12 5l7 7-7 7',
    trash: 'M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6',
    edit: 'M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z',
    file: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M16 13H8M16 17H8M10 9H8',
    link: 'M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1',
    users: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
    menu: 'M3 12h18M3 6h18M3 18h18',
    filter: 'M22 3H2l8 9.5V19l4 2v-8.5z',
    play: 'M6 3l14 9-14 9z',
    upload: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12',
    save: 'M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2zM17 21v-8H7v8M7 3v5h8',
    mail: 'M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 6l-10 7L2 6',
    plus2: 'M12 8v8M8 12h8M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z'
  };

  const STATUS = {
    not_started: { label: 'Not started', cls: 'grey' },
    in_progress: { label: 'In progress', cls: 'blue' },
    completed_on_time: { label: 'On time', cls: 'green' },
    completed_late: { label: 'Completed late', cls: 'amber' },
    overdue: { label: 'Overdue', cls: 'red' },
    on_hold: { label: 'On hold', cls: 'grey' },
    cancelled: { label: 'Cancelled', cls: 'grey' },
    scheduled: { label: 'Scheduled', cls: 'blue' },
    rescheduled: { label: 'Rescheduled', cls: 'purple' },
    completed: { label: 'Completed', cls: 'green' },
    pending: { label: 'Pending', cls: 'amber' },
    active: { label: 'Active', cls: 'green' },
    inactive: { label: 'Inactive', cls: 'grey' },
    not_connected: { label: 'Not synced', cls: 'grey' },
    pending_update: { label: 'Resync pending', cls: 'amber' },
    pending_cancel: { label: 'Cancel pending', cls: 'amber' },
    synced: { label: 'Synced', cls: 'green' },
    not_applicable: { label: '—', cls: 'grey' },
    company: { label: 'Company', cls: 'blue' },
    department: { label: 'Department', cls: 'grey' },
    verified: { label: 'Verified', cls: 'green' }
  };

  const PRIORITY = {
    low: { label: 'Low', cls: 'grey' },
    medium: { label: 'Medium', cls: 'blue' },
    high: { label: 'High', cls: 'amber' },
    critical: { label: 'Critical', cls: 'red' }
  };

  function esc(v) {
    if (v === null || v === undefined) return '';
    return String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function icon(name, size, cls) {
    const p = ICONS[name] || ICONS.link;
    const s = size || 16;
    return '<svg class="ico ' + (cls || '') + '" width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + p + '"/></svg>';
  }

  function d(v) { return v ? new Date(v) : null; }
  function fmtDate(v) {
    const x = d(v); if (!x || isNaN(x)) return '—';
    return x.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  }
  function fmtShort(v) {
    const x = d(v); if (!x || isNaN(x)) return '—';
    return x.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
  }
  function fmtDateTime(v) {
    const x = d(v); if (!x || isNaN(x)) return '—';
    return x.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) + ', ' + fmtTime(x);
  }
  function fmtTime(v) {
    if (!v) return '—';
    if (typeof v === 'string' && /^\d{2}:\d{2}/.test(v)) return v.slice(0, 5);
    const x = new Date(v); if (isNaN(x)) return '—';
    return x.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  }
  function rel(v) {
    const x = d(v); if (!x) return '—';
    const s = (Date.now() - x.getTime()) / 1000;
    const a = Math.abs(s);
    const suffix = s < 0 ? 'from now' : 'ago';
    if (a < 60) return 'just now';
    if (a < 3600) return Math.round(a / 60) + 'm ' + suffix;
    if (a < 86400) return Math.round(a / 3600) + 'h ' + suffix;
    if (a < 2592000) return Math.round(a / 86400) + 'd ' + suffix;
    return fmtDate(x);
  }
  function hrs(v) {
    if (v === null || v === undefined || v === '') return '—';
    const n = Number(v);
    if (isNaN(n)) return '—';
    if (n < 1) return Math.round(n * 60) + 'm';
    if (n < 48) return (Math.round(n * 10) / 10) + 'h';
    return (Math.round(n / 2.4) / 10) + 'd';
  }
  function initials(name) {
    return String(name || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  }
  function avatar(name, color, size) {
    const s = size || '';
    return '<span class="avatar ' + s + '" style="background:' + esc(color || '#1D6BF3') + '">' + esc(initials(name)) + '</span>';
  }
  function pill(status, labelOverride) {
    const m = STATUS[status] || { label: (status || '—').replace(/_/g, ' '), cls: 'grey' };
    return '<span class="pill ' + m.cls + '">' + esc(labelOverride || m.label) + '</span>';
  }
  function prio(p) {
    const m = PRIORITY[p] || PRIORITY.medium;
    return '<span class="pill ' + m.cls + '">' + m.label + '</span>';
  }
  function pct(a, b) { if (!b) return 0; return Math.round((Number(a) / Number(b)) * 100); }
  function bar(p, cls) {
    const v = Math.max(0, Math.min(100, Number(p) || 0));
    return '<div class="bar ' + (cls || '') + '"><span style="width:' + v + '%"></span></div>';
  }
  function n(v) { return Number(v || 0).toLocaleString('en-IN'); }

  function toast(msg, kind) {
    let w = document.querySelector('.toast-wrap');
    if (!w) { w = document.createElement('div'); w.className = 'toast-wrap'; document.body.appendChild(w); }
    const t = document.createElement('div');
    t.className = 'toast ' + (kind || '');
    t.innerHTML = icon(kind === 'bad' ? 'alert' : 'checkCircle', 15) + '<span>' + esc(msg) + '</span>';
    w.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .25s'; setTimeout(() => t.remove(), 260); }, 3600);
  }

  function modal(opts) {
    const bg = document.createElement('div');
    bg.className = 'modal-bg';
    bg.innerHTML = '<div class="modal ' + (opts.size || '') + '" role="dialog" aria-modal="true">' +
      '<div class="modal-head"><h3>' + esc(opts.title || '') + '</h3><button class="close-x" type="button" aria-label="Close">&times;</button></div>' +
      '<div class="modal-body">' + (opts.body || '') + '</div>' +
      (opts.foot === null ? '' : '<div class="modal-foot">' + (opts.foot || '<button class="btn" data-close>Close</button>') + '</div>') +
      '</div>';
    document.body.appendChild(bg);
    const close = () => { bg.remove(); if (opts.onClose) opts.onClose(); };
    bg.querySelector('.close-x').onclick = close;
    bg.addEventListener('mousedown', e => { if (e.target === bg) close(); });
    bg.querySelectorAll('[data-close]').forEach(b => b.onclick = close);
    if (opts.onMount) opts.onMount(bg, close);
    return { el: bg, body: bg.querySelector('.modal-body'), close };
  }

  function drawer(opts) {
    const bg = document.createElement('div');
    bg.className = 'modal-bg';
    bg.style.padding = '0';
    bg.style.background = 'rgba(10,14,23,.42)';
    bg.innerHTML = '<div class="detail-drawer"><div class="dd-head"><div><h3 style="font-size:15px;font-weight:700">' + esc(opts.title || '') + '</h3>' +
      (opts.sub ? '<div class="small" style="margin-top:3px">' + opts.sub + '</div>' : '') +
      '</div><button class="close-x" type="button">&times;</button></div>' +
      '<div class="dd-body">' + (opts.body || '') + '</div>' +
      (opts.foot ? '<div class="dd-foot">' + opts.foot + '</div>' : '') + '</div>';
    document.body.appendChild(bg);
    const close = () => { bg.remove(); if (opts.onClose) opts.onClose(); };
    bg.querySelector('.close-x').onclick = close;
    bg.addEventListener('mousedown', e => { if (e.target === bg) close(); });
    bg.querySelectorAll('[data-close]').forEach(b => b.onclick = close);
    if (opts.onMount) opts.onMount(bg, close);
    return { el: bg, body: bg.querySelector('.dd-body'), close };
  }

  async function confirmAction(msg, opts) {
    try { return await window.agentdb.confirm(msg, opts || {}); }
    catch (e) { return false; }
  }

  function csvEscape(v) {
    const s = v === null || v === undefined ? '' : String(v);
    return '"' + s.replace(/"/g, '""') + '"';
  }
  async function downloadCsv(rows, filename, cols) {
    if (!rows || !rows.length) { toast('Nothing to export for this selection', 'bad'); return; }
    const keys = cols ? cols.map(c => c.key) : Object.keys(rows[0]);
    const heads = cols ? cols.map(c => c.label) : keys;
    const lines = [heads.map(csvEscape).join(',')];
    rows.forEach(r => lines.push(keys.map(k => csvEscape(r[k])).join(',')));
    try {
      await window.agentdb.download(lines.join('\n'), filename);
      toast('Exported ' + rows.length + ' rows to ' + filename, 'ok');
    } catch (e) { toast('Export failed: ' + e.message, 'bad'); }
  }

  const charts = {};
  function chart(canvas, cfg) {
    if (!canvas || typeof Chart === 'undefined') return null;
    if (charts[canvas.id]) { charts[canvas.id].destroy(); delete charts[canvas.id]; }
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
    Chart.defaults.font.size = 11;
    Chart.defaults.color = dark ? '#93A2BA' : '#7C8AA3';
    // Draw synchronously: an idle or background tab never runs animation
    // frames, which used to leave charts blank in previews and screenshots.
    cfg.options = cfg.options || {};
    if (cfg.options.animation === undefined) cfg.options.animation = false;
    const c = new Chart(canvas.getContext('2d'), cfg);
    charts[canvas.id] = c;
    return c;
  }
  function palette() {
    return ['#1D6BF3', '#06B6D4', '#7C3AED', '#F59E0B', '#0E9F6E', '#EC4899', '#EF4444', '#64748B'];
  }
  function gridColor() {
    return document.documentElement.getAttribute('data-theme') === 'dark' ? 'rgba(255,255,255,.07)' : 'rgba(15,23,42,.06)';
  }

  function empty(title, sub, action) {
    return '<div class="empty"><div class="e-ico">' + icon('layers', 22) + '</div><h4>' + esc(title) + '</h4><p>' + esc(sub || '') + '</p>' + (action || '') + '</div>';
  }
  function loading() { return '<div class="loading-row">Loading…</div>'; }

  function debounce(fn, ms) {
    let t; return function () { const a = arguments, c = this; clearTimeout(t); t = setTimeout(() => fn.apply(c, a), ms || 250); };
  }

  function formData(form) {
    const out = {};
    new FormData(form).forEach((v, k) => { out[k] = v; });
    return out;
  }

  function todayISO(offset) {
    const x = new Date();
    if (offset) x.setDate(x.getDate() + offset);
    const p2 = n => String(n).padStart(2, '0');
    return x.getFullYear() + '-' + p2(x.getMonth() + 1) + '-' + p2(x.getDate());
  }

  function downloadPdf(sel, filename) {
    try { window.agentdb.downloadPdf(sel, { filename: filename, pageNumbers: true }); }
    catch (e) { toast('PDF export failed: ' + e.message, 'bad'); }
  }
  function printEl(sel, title) {
    try { window.agentdb.print(sel, { title: title }); }
    catch (e) { toast('Print failed: ' + e.message, 'bad'); }
  }

  return {
    esc, icon, fmtDate, fmtShort, fmtDateTime, fmtTime, rel, hrs, initials, avatar, pill, prio, pct, bar, n,
    toast, modal, drawer, confirmAction, downloadCsv, chart, palette, gridColor, empty, loading, debounce,
    formData, todayISO, downloadPdf, printEl, STATUS, PRIORITY
  };
})();
