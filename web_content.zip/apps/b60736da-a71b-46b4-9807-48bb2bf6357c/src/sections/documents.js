/* SmartiQo · Document library */
window.PAGES = window.PAGES || {};
window.PAGES.documents = (function () {

  let DOCS = [], DEPTS = [], CATS = [];
  const D = { dept: 0, cat: '', search: '' };

  const TYPE_ICON = { PDF: 'file', Sheet: 'grid', Doc: 'file', Link: 'link', Video: 'play', Other: 'folder', XLSX: 'grid', DOCX: 'file' };

  async function render(el) {
    const me = Auth.getSession();
    const admin = Auth.isAdmin();
    const canAdd = admin || me.role === 'department_head';

    let settings;
    try {
      const [d, s] = await Promise.all([
        window.agentdb.executeQuery('load_departments', {}),
        window.agentdb.executeQuery('load_settings', {})
      ]);
      DEPTS = d.rows;
      const row = s.rows.find(r => r.key === 'doc_categories');
      try { CATS = row ? JSON.parse(row.value) : []; } catch (e) { CATS = []; }
    } catch (e) { DEPTS = []; CATS = []; }

    try {
      DOCS = (await window.agentdb.executeQuery('load_documents', { department_id: D.dept, category: D.cat, search: D.search })).rows;
    } catch (e) {
      el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>';
      return;
    }
    if (!CATS.length) CATS = Array.from(new Set(DOCS.map(d => d.category).filter(Boolean)));

    const usedCats = Array.from(new Set(DOCS.map(d => d.category).filter(Boolean)));
    const latest = DOCS.slice().sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0];

    el.innerHTML =
      '<div class="page-head"><div><h1>Documents</h1><div class="sub">SOPs, policies, process documents and training material in one library</div></div>' +
      '<div class="page-actions"><button class="btn" id="docExport">' + UI.icon('download', 14) + ' Export CSV</button>' +
      (canAdd ? '<button class="btn primary" id="docNew">' + UI.icon('plus', 14) + ' Add document</button>' : '') + '</div></div>' +
      '<div class="kpi-grid">' +
      '<div class="kpi blue"><div class="k-top"><span class="k-lbl">Documents</span><span class="k-ico">' + UI.icon('folder', 14) + '</span></div><div class="k-val">' + DOCS.length + '</div><div class="k-sub">In this view</div></div>' +
      '<div class="kpi purple"><div class="k-top"><span class="k-lbl">Categories</span><span class="k-ico">' + UI.icon('layers', 14) + '</span></div><div class="k-val">' + usedCats.length + '</div><div class="k-sub">' + UI.esc(usedCats.slice(0, 2).join(', ') || '—') + '</div></div>' +
      '<div class="kpi ok"><div class="k-top"><span class="k-lbl">Departments</span><span class="k-ico">' + UI.icon('building', 14) + '</span></div><div class="k-val">' + new Set(DOCS.map(d => d.department_id).filter(Boolean)).size + '</div><div class="k-sub">Covered by this library</div></div>' +
      '<div class="kpi warn"><div class="k-top"><span class="k-lbl">Latest upload</span><span class="k-ico">' + UI.icon('clock', 14) + '</span></div><div class="k-val" style="font-size:16px">' + (latest ? UI.fmtShort(latest.created_at) : '—') + '</div><div class="k-sub">' + UI.esc(latest ? latest.name.slice(0, 28) : 'No documents yet') + '</div></div>' +
      '</div>' +
      '<div class="toolbar"><div class="grow"><input class="input" id="docSearch" placeholder="Search documents…" style="width:100%" value="' + UI.esc(D.search) + '"></div>' +
      '<select class="select" id="docCat"><option value="">All categories</option>' + usedCats.map(c => '<option value="' + UI.esc(c) + '"' + (D.cat === c ? ' selected' : '') + '>' + UI.esc(c) + '</option>').join('') + '</select>' +
      '<select class="select" id="docDept"><option value="0">All departments</option>' + DEPTS.map(d => '<option value="' + d.id + '"' + (Number(D.dept) === Number(d.id) ? ' selected' : '') + '>' + UI.esc(d.name) + '</option>').join('') + '</select></div>' +
      '<div id="docBody"></div>';

    paint();
    document.getElementById('docSearch').oninput = UI.debounce(() => { D.search = document.getElementById('docSearch').value.trim(); refresh(); }, 250);
    document.getElementById('docCat').onchange = (e) => { D.cat = e.target.value; refresh(); };
    document.getElementById('docDept').onchange = (e) => { D.dept = Number(e.target.value) || 0; refresh(); };
    const nb = document.getElementById('docNew'); if (nb) nb.onclick = () => docModal(null);
    const ex = document.getElementById('docExport');
    if (ex) ex.onclick = () => UI.downloadCsv(DOCS.map(d => ({
      Name: d.name, Category: d.category, Department: d.department_name, Type: d.file_type,
      Access: d.access_level, UploadedBy: d.uploaded_by_name, Created: d.created_at, URL: d.file_url || '', Description: d.description || ''
    })), 'smartiqo-documents.csv');

    async function refresh() {
      const body = document.getElementById('docBody');
      if (!body) return;
      body.innerHTML = '<div class="loading-row">Loading…</div>';
      try {
        DOCS = (await window.agentdb.executeQuery('load_documents', { department_id: D.dept, category: D.cat, search: D.search })).rows;
        paint();
      } catch (e) { body.innerHTML = '<div class="banner warn">' + UI.icon('alert', 15) + '<div>' + UI.esc(e.message) + '</div></div>'; }
    }

    function paint() {
      const body = document.getElementById('docBody');
      if (!DOCS.length) { body.innerHTML = '<div class="card card-body">' + UI.empty('No documents match', 'Adjust the filters or add the first document.', canAdd ? '<button class="btn primary" data-adddoc>Add document</button>' : '') + '</div>'; }
      else {
        body.innerHTML = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px">' + DOCS.map(card).join('') + '</div>';
      }
      body.querySelectorAll('[data-doc]').forEach(c => c.onclick = (e) => { if (e.target.closest('a')) return; openDoc(Number(c.dataset.doc)); });
      const ad = body.querySelector('[data-adddoc]'); if (ad) ad.onclick = () => docModal(null);
    }
  }

  function card(d) {
    const ic = TYPE_ICON[d.file_type] || 'file';
    return '<div class="dept-card" data-doc="' + d.id + '" style="display:flex;gap:11px;align-items:flex-start">' +
      '<div class="link-ico">' + UI.icon(ic, 17) + '</div>' +
      '<div style="min-width:0;flex:1">' +
      '<div class="strong" style="font-size:13px;line-height:1.3">' + UI.esc(d.name) + '</div>' +
      '<div class="small" style="margin-top:3px">' + UI.esc(d.category || 'Uncategorised') + ' · ' + UI.esc(d.department_name || 'Company-wide') + '</div>' +
      '<div class="small" style="margin-top:6px;display:flex;align-items:center;gap:6px">' +
      '<span class="tag">' + UI.esc(d.file_type || 'FILE') + '</span>' +
      '<span>' + UI.fmtShort(d.created_at) + '</span>' +
      (d.file_url ? '<span class="ml-auto" style="color:var(--blue)">' + UI.icon('external', 12) + '</span>' : '') + '</div></div></div>';
  }

  function openDoc(id) {
    const d = DOCS.find(x => Number(x.id) === Number(id)); if (!d) return;
    const me = Auth.getSession();
    UI.drawer({
      title: d.name,
      sub: '<span class="tag">' + UI.esc(d.file_type || 'FILE') + '</span> <span class="small">' + UI.esc(d.category || 'Uncategorised') + '</span>',
      body: '<dl class="kv mb16"><dt>Department</dt><dd>' + UI.esc(d.department_name || 'Company-wide') + '</dd>' +
        '<dt>Access</dt><dd style="text-transform:capitalize">' + UI.esc(d.access_level || 'company') + '</dd>' +
        '<dt>Uploaded by</dt><dd>' + UI.esc(d.uploaded_by_name || '—') + '</dd>' +
        '<dt>Added</dt><dd>' + UI.fmtDateTime(d.created_at) + '</dd>' +
        '<dt>Description</dt><dd>' + UI.esc(d.description || '—') + '</dd></dl>' +
        (d.file_url ? '<a class="btn primary block" href="' + UI.esc(d.file_url) + '" target="_blank" rel="noopener">' + UI.icon('external', 14) + ' Open document</a>'
          : '<div class="banner warn">' + UI.icon('alert', 15) + '<div>No file URL is attached to this record. Edit it to add the Drive or document link.</div></div>'),
      foot: (Auth.isAdmin() || me.role === 'department_head' ? '<button class="btn" id="docEdit">' + UI.icon('edit', 13) + ' Edit</button><button class="btn danger sm" id="docDel">' + UI.icon('trash', 13) + ' Delete</button>' : '') + '<button class="btn" data-close>Close</button>',
      onMount: (bg, close) => {
        const ed = bg.querySelector('#docEdit'); if (ed) ed.onclick = () => { close(); docModal(d); };
        const del = bg.querySelector('#docDel');
        if (del) del.onclick = async () => {
          const ok = await UI.confirmAction('Remove “' + d.name + '” from the library?', { danger: true, confirmLabel: 'Delete document' });
          if (!ok) return;
          try { await window.agentdb.executeQuery('delete_document', { id: d.id }); close(); UI.toast('Document removed', 'ok'); App.rerender(); }
          catch (e) { UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  function docModal(d) {
    const me = Auth.getSession();
    const isNew = !d;
    const cats = CATS.length ? CATS : ['SOP', 'Process Documents', 'Policies', 'Training Materials', 'Department Documents', 'Reports', 'Other'];
    UI.modal({
      title: isNew ? 'Add document' : 'Edit document',
      size: 'wide',
      body: '<div class="form-grid">' +
        '<div class="field full"><label>Document name *</label><input class="input" id="dName" value="' + UI.esc(d ? d.name : '') + '"></div>' +
        '<div class="field"><label>Category</label><select class="select" id="dCat">' + cats.map(c => '<option value="' + UI.esc(c) + '"' + (d && d.category === c ? ' selected' : '') + '>' + UI.esc(c) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Department</label><select class="select" id="dDept"><option value="0">Company-wide</option>' + DEPTS.map(x => '<option value="' + x.id + '"' + (d && Number(d.department_id) === Number(x.id) ? ' selected' : '') + '>' + UI.esc(x.name) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>File type</label><select class="select" id="dType">' + ['PDF', 'Doc', 'Sheet', 'Link', 'Video', 'Other'].map(t => '<option value="' + t + '"' + (d && d.file_type === t ? ' selected' : '') + '>' + t + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Access</label><select class="select" id="dAccess"><option value="company"' + (!d || d.access_level === 'company' ? ' selected' : '') + '>Company</option><option value="department"' + (d && d.access_level === 'department' ? ' selected' : '') + '>Department only</option></select></div>' +
        '<div class="field full"><label>File / Drive URL</label><input class="input" id="dUrl" value="' + UI.esc(d ? d.file_url || '' : '') + '" placeholder="https://drive.google.com/…"></div>' +
        '<div class="field full"><label>Description</label><textarea class="textarea" id="dDesc">' + UI.esc(d ? d.description || '' : '') + '</textarea></div></div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="dSave">Save document</button>',
      onMount: (bg, close) => {
        bg.querySelector('#dSave').onclick = async () => {
          const name = bg.querySelector('#dName').value.trim();
          if (!name) { UI.toast('Document name is required', 'bad'); return; }
          const btn = bg.querySelector('#dSave'); btn.disabled = true;
          try {
            const payload = {
              name: name, department_id: Number(bg.querySelector('#dDept').value) || 0,
              category: bg.querySelector('#dCat').value, description: bg.querySelector('#dDesc').value,
              uploaded_by: me.id, file_type: bg.querySelector('#dType').value,
              file_url: bg.querySelector('#dUrl').value.trim(), access_level: bg.querySelector('#dAccess').value
            };
            if (isNew) await window.agentdb.executeQuery('create_document', payload);
            else await window.agentdb.executeQuery('update_document', Object.assign({ id: d.id }, payload));
            await window.PAGES.departments.audit(isNew ? 'Document added' : 'Document updated', 'document', d ? String(d.id) : '', name);
            close(); UI.toast('Document saved', 'ok'); App.rerender();
          } catch (e) { btn.disabled = false; UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  return { render, docModal };
})();
