/* SmartiQo · Department management */
window.PAGES = window.PAGES || {};
window.PAGES.departments = (function () {

  function card(d) {
    const p = UI.pct(d.on_time, d.completed);
    return '<div class="dept-card" data-dept="' + d.id + '">' +
      '<div class="dc-top"><span style="width:9px;height:38px;border-radius:6px;background:' + UI.esc(d.color) + '"></span>' +
      '<div style="flex:1;min-width:0"><div class="dc-name">' + UI.esc(d.name) + '</div>' +
      '<div class="small">' + UI.esc(d.head_name || 'No head assigned') + '</div></div>' +
      '<span class="tag">' + UI.esc(d.code || '') + '</span></div>' +
      '<div class="dept-metrics">' +
      '<div class="dm"><div class="v">' + d.fms_count + '</div><div class="l">FMS</div></div>' +
      '<div class="dm"><div class="v">' + d.total_tasks + '</div><div class="l">Tasks</div></div>' +
      '<div class="dm"><div class="v" style="color:' + (d.overdue ? 'var(--bad)' : 'inherit') + '">' + d.overdue + '</div><div class="l">Overdue</div></div>' +
      '</div>' +
      '<div class="flex items-center gap8 mb8"><div style="flex:1">' + UI.bar(p, p >= 70 ? 'ok' : p >= 40 ? 'amber' : 'bad') + '</div><span class="small mono">' + p + '% on-time</span></div>' +
      '<div class="flex items-center gap8 small"><span>' + UI.icon('users', 12) + ' ' + d.employee_count + ' employees</span>' +
      (d.pending_forms ? '<span class="pill amber" style="margin-left:auto">' + d.pending_forms + ' forms</span>' : '<span class="ml-auto small">' + d.today_visits + ' visits today</span>') + '</div></div>';
  }

  async function render(el, ctx) {
    if (ctx.id) return renderDetail(el, ctx);
    const admin = Auth.isAdmin();
    const me = Auth.getSession();
    const r = await window.agentdb.executeQuery('load_departments', {});
    if (!admin) r.rows = r.rows.filter(x => Number(x.id) === Number(me.department_id));
    el.innerHTML =
      '<div class="page-head"><div><h1>Departments</h1><div class="sub">' + r.rows.length + ' departments · performance, FMS ownership and team workload</div></div>' +
      '<div class="page-actions">' + (admin ? '<button class="btn primary" id="addDept">' + UI.icon('plus', 14) + ' Add department</button>' : '') + '</div></div>' +
      '<div class="kpi-grid">' +
      '<div class="kpi blue"><div class="k-top"><span class="k-lbl">Departments</span><span class="k-ico">' + UI.icon('building', 14) + '</span></div><div class="k-val">' + r.rows.length + '</div><div class="k-sub">Active structure</div></div>' +
      '<div class="kpi purple"><div class="k-top"><span class="k-lbl">Employees</span><span class="k-ico">' + UI.icon('users', 14) + '</span></div><div class="k-val">' + r.rows.reduce((a, x) => a + Number(x.employee_count), 0) + '</div><div class="k-sub">Across all departments</div></div>' +
      '<div class="kpi ok"><div class="k-top"><span class="k-lbl">Completed tasks</span><span class="k-ico">' + UI.icon('checkCircle', 14) + '</span></div><div class="k-val">' + UI.n(r.rows.reduce((a, x) => a + Number(x.completed), 0)) + '</div><div class="k-sub">All time</div></div>' +
      '<div class="kpi bad"><div class="k-top"><span class="k-lbl">Overdue</span><span class="k-ico">' + UI.icon('alert', 14) + '</span></div><div class="k-val">' + UI.n(r.rows.reduce((a, x) => a + Number(x.overdue), 0)) + '</div><div class="k-sub">Needs escalation</div></div>' +
      '</div>' +
      '<div class="grid-4" style="gap:12px">' + r.rows.map(card).join('') + '</div>';

    el.querySelectorAll('.dept-card').forEach(c => c.onclick = () => App.navigate('/departments/' + c.dataset.dept));
    const add = el.querySelector('#addDept');
    if (add) add.onclick = () => deptModal(null);
  }

  async function renderDetail(el, ctx) {
    const id = Number(ctx.id);
    const me = Auth.getSession();
    if (!Auth.isAdmin() && Number(me.department_id) !== id) { location.hash = '#/departments'; return; }
    let d, fms, people, docs;
    try {
      [d, fms, people, docs] = await Promise.all([
        window.agentdb.executeQuery('department_detail', { id: id }),
        window.agentdb.executeQuery('department_fms', { department_id: id }),
        window.agentdb.executeQuery('load_people', { department_id: id, role: '' }),
        window.agentdb.executeQuery('load_documents', { department_id: id, category: '', search: '' })
      ]);
    } catch (e) {
      el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>';
      return;
    }
    if (!d.rows.length) { el.innerHTML = UI.empty('Department not found', 'It may have been removed.'); return; }
    const D = d.rows[0];
    const p = UI.pct(D.on_time, D.completed);
    const admin = Auth.isAdmin();

    el.innerHTML =
      '<div class="page-head"><div><div class="crumb" style="margin-bottom:6px"><a href="#/departments">Departments</a> <span style="opacity:.5">/</span> <b>' + UI.esc(D.name) + '</b></div>' +
      '<h1>' + UI.esc(D.name) + '</h1><div class="sub">' + UI.esc(D.description || '') + '</div></div>' +
      '<div class="page-actions">' + (admin ? '<button class="btn" id="editDept">' + UI.icon('edit', 14) + ' Edit</button>' : '') +
      '<button class="btn" id="deptReport">' + UI.icon('chart', 14) + ' Department report</button>' +
      '<button class="btn primary" id="deptTask">' + UI.icon('plus', 14) + ' New task</button></div></div>' +

      '<div class="kpi-grid">' +
      '<div class="kpi blue"><div class="k-top"><span class="k-lbl">Assigned FMS</span><span class="k-ico">' + UI.icon('layers', 14) + '</span></div><div class="k-val">' + D.fms_count + '</div><div class="k-sub">Processes owned</div></div>' +
      '<div class="kpi purple"><div class="k-top"><span class="k-lbl">Total tasks</span><span class="k-ico">' + UI.icon('checks', 14) + '</span></div><div class="k-val">' + D.total_tasks + '</div><div class="k-sub">' + D.pending + ' pending · ' + D.overdue + ' overdue</div></div>' +
      '<div class="kpi ok"><div class="k-top"><span class="k-lbl">Completed</span><span class="k-ico">' + UI.icon('checkCircle', 14) + '</span></div><div class="k-val">' + D.completed + '</div><div class="k-sub">' + D.on_time + ' on time · ' + D.late + ' late</div></div>' +
      '<div class="kpi warn"><div class="k-top"><span class="k-lbl">Pending forms</span><span class="k-ico">' + UI.icon('clipboard', 14) + '</span></div><div class="k-val">' + D.pending_forms + '</div><div class="k-sub">Awaiting submission</div></div>' +
      '<div class="kpi ok"><div class="k-top"><span class="k-lbl">On-time rate</span><span class="k-ico">' + UI.icon('chart', 14) + '</span></div><div class="k-val">' + p + '%</div><div class="k-sub">On time / completed</div></div>' +
      '</div>' +

      '<div class="banner info">' + UI.icon('user', 15) + '<div>Department head: <b>' + UI.esc(D.head_name || 'Not assigned') + '</b> · ' + D.employee_count + ' employees · ' + D.today_visits + ' visits scheduled today</div></div>' +

      '<div class="two-col">' +
      '<div class="stack">' +
      '<div class="card"><div class="card-head"><h3>Assigned FMS</h3><span class="small">' + fms.rows.length + ' processes</span></div>' +
      '<div class="card-body tight"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>FMS</th><th class="num">Tasks</th><th class="num">Done</th><th class="num">Overdue</th><th>Completion</th><th></th></tr></thead><tbody>' +
      (fms.rows.length ? fms.rows.map(f => {
        const cp = UI.pct(f.completed, f.total_tasks);
        return '<tr><td><div class="strong">' + UI.esc(f.name) + '</div><div class="small">' + UI.esc(f.code || '') + '</div></td>' +
          '<td class="num">' + f.total_tasks + '</td><td class="num">' + f.completed + '</td>' +
          '<td class="num" style="color:' + (f.overdue ? 'var(--bad)' : 'inherit') + '">' + f.overdue + '</td>' +
          '<td><div class="flex items-center gap8"><div style="flex:1;min-width:50px">' + UI.bar(cp, cp >= 70 ? 'ok' : cp >= 40 ? 'amber' : 'bad') + '</div><span class="small mono">' + cp + '%</span></div></td>' +
          '<td><button class="btn sm" data-fms="' + f.id + '">Open</button></td></tr>';
      }).join('') : '<tr><td colspan="6">' + UI.empty('No FMS assigned', 'Assign processes from Admin Settings → FMS Management.', '') + '</td></tr>') +
      '</tbody></table></div></div></div>' +

      '<div class="card"><div class="card-head"><h3>Employees</h3><span class="small">' + people.rows.length + ' people</span></div>' +
      '<div class="card-body tight"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Name</th><th>Role</th><th class="num">Tasks</th><th class="num">Overdue</th><th>Completion</th></tr></thead><tbody>' +
      people.rows.map(x => {
        const cp = UI.pct(x.completed, x.total_tasks);
        return '<tr><td><div class="flex items-center gap8">' + UI.avatar(x.full_name, x.avatar_color, 'sm') + '<div><div class="strong">' + UI.esc(x.full_name) + '</div><div class="small">' + UI.esc(x.designation || '') + '</div></div></div></td>' +
          '<td class="small" style="text-transform:capitalize">' + UI.esc(x.role.replace(/_/g, ' ')) + '</td>' +
          '<td class="num">' + x.total_tasks + '</td><td class="num">' + x.overdue + '</td>' +
          '<td><span class="small mono">' + cp + '%</span></td></tr>';
      }).join('') + '</tbody></table></div></div></div>' +
      '</div>' +

      '<div class="stack">' +
      '<div class="card"><div class="card-head"><h3>Department documents</h3><button class="btn sm" data-route="/documents">All ' + UI.icon('arrow', 12) + '</button></div>' +
      '<div class="card-body tight">' +
      (docs.rows.length ? docs.rows.slice(0, 6).map(dc => '<div class="notif-item" style="align-items:center"><span class="link-ico" style="width:30px;height:30px;border-radius:8px">' + UI.icon('file', 14) + '</span>' +
        '<div style="flex:1"><div class="strong" style="font-size:12.3px">' + UI.esc(dc.name) + '</div><div class="small">' + UI.esc(dc.category) + ' · ' + UI.esc(dc.file_type) + '</div></div>' +
        '<span class="tag">' + UI.esc(dc.file_type) + '</span></div>').join('') : '<div class="small" style="padding:14px 16px">No documents for this department yet.</div>') +
      '</div></div>' +
      '<div class="card"><div class="card-head"><h3>Department health</h3></div><div class="card-body">' +
      '<dl class="kv"><dt>Completion rate</dt><dd>' + UI.pct(D.completed, D.total_tasks) + '%</dd>' +
      '<dt>On-time rate</dt><dd>' + p + '%</dd>' +
      '<dt>Open workload</dt><dd>' + D.pending + ' tasks</dd>' +
      '<dt>Overdue</dt><dd style="color:' + (D.overdue ? 'var(--bad)' : 'inherit') + '">' + D.overdue + ' tasks</dd>' +
      '<dt>Pending forms</dt><dd>' + D.pending_forms + '</dd>' +
      '<dt>Visits today</dt><dd>' + D.today_visits + '</dd></dl>' +
      '<button class="btn block mt12" id="deptTasks">View department tasks ' + UI.icon('arrow', 13) + '</button></div></div>' +
      '</div></div>';

    el.querySelectorAll('[data-fms]').forEach(b => b.onclick = () => App.navigate('/fms/' + b.dataset.fms));
    el.querySelectorAll('[data-route]').forEach(b => b.onclick = () => App.navigate(b.dataset.route));
    const dt = el.querySelector('#deptTask'); if (dt) dt.onclick = () => window.PAGES.tasks.openCreate(null, id);
    const dts = el.querySelector('#deptTasks'); if (dts) dts.onclick = () => { App.state.taskDept = id; App.navigate('/tasks'); };
    const dr = el.querySelector('#deptReport'); if (dr) dr.onclick = () => { App.state.reportDept = id; App.navigate('/reports'); };
    const ed = el.querySelector('#editDept'); if (ed) ed.onclick = () => deptModal(D);
  }

  async function deptModal(D) {
    const people = await window.agentdb.executeQuery('load_people', { department_id: 0, role: '' });
    const heads = people.rows.filter(p => p.role === 'department_head' || p.role === 'admin');
    const m = UI.modal({
      title: D ? 'Edit department' : 'Add department',
      body: '<div class="form-grid">' +
        '<div class="field full"><label>Department name *</label><input class="input" id="dName" value="' + UI.esc(D ? D.name : '') + '" placeholder="e.g. Customer Success"></div>' +
        '<div class="field"><label>Short code</label><input class="input" id="dCode" value="' + UI.esc(D ? D.code || '' : '') + '" placeholder="CSU" maxlength="6"></div>' +
        '<div class="field"><label>Accent colour</label><input class="input" id="dColor" type="color" value="' + UI.esc(D ? D.color : '#1D6BF3') + '" style="padding:4px"></div>' +
        '<div class="field full"><label>Department head</label><select class="select" id="dHead"><option value="0">Not assigned</option>' +
        heads.map(h => '<option value="' + h.id + '"' + (D && D.head_user_id === h.id ? ' selected' : '') + '>' + UI.esc(h.full_name) + ' · ' + UI.esc(h.designation || h.role) + '</option>').join('') + '</select></div>' +
        '<div class="field full"><label>Description</label><textarea class="textarea" id="dDesc" placeholder="What this department owns">' + UI.esc(D ? D.description || '' : '') + '</textarea></div></div>' +
        (D ? '<button class="btn danger sm mt8" id="dDel">' + UI.icon('trash', 13) + ' Delete department</button>' : ''),
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="dSave">Save department</button>',
      onMount: (bg, close) => {
        bg.querySelector('#dSave').onclick = async () => {
          const name = bg.querySelector('#dName').value.trim();
          if (!name) { UI.toast('Department name is required', 'bad'); return; }
          const payload = { name: name, code: bg.querySelector('#dCode').value.trim(), description: bg.querySelector('#dDesc').value, color: bg.querySelector('#dColor').value };
          try {
            if (D) {
              await window.agentdb.executeQuery('update_department', Object.assign({ id: D.id, head_user_id: Number(bg.querySelector('#dHead').value) || 0 }, payload));
            } else {
              const r = await window.agentdb.executeQuery('create_department', payload);
              const nid = r.rows[0].id;
              const head = Number(bg.querySelector('#dHead').value) || 0;
              if (head) await window.agentdb.executeQuery('update_department', Object.assign({ id: nid, head_user_id: head }, payload));
            }
            await audit('Department saved', 'departments', String(D ? D.id : ''), name);
            close(); UI.toast('Department saved', 'ok'); App.rerender();
          } catch (e) { UI.toast(e.message, 'bad'); }
        };
        const del = bg.querySelector('#dDel');
        if (del) del.onclick = async () => {
          const ok = await UI.confirmAction('Delete “' + D.name + '”? Tasks and FMS will keep their history but lose the department link.', { danger: true, confirmLabel: 'Delete' });
          if (!ok) return;
          try {
            await window.agentdb.executeQuery('delete_department', { id: D.id });
            close(); UI.toast('Department deleted', 'ok'); App.navigate('/departments'); App.rerender();
          } catch (e) { UI.toast(e.message, 'bad'); }
        };
      }
    });
    return m;
  }

  async function audit(action, type, id, details) {
    try {
      const u = Auth.user();
      await window.agentdb.executeQuery('log_audit', { user_id: u.id, actor_name: u.name, action: action, entity_type: type, entity_id: id, details: details || '' });
    } catch (e) { }
  }

  return { render, deptModal, audit };
})();
