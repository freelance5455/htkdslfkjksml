/* SmartiQo · Pending forms and form library */
window.PAGES = window.PAGES || {};
window.PAGES.forms = (function () {

  let TAB = 'library';
  let pendingRows = [], formRows = [], fmsList = [], deptList = [], peopleList = [];
  let FMS_FILTER = 0;

  function scopeParams() {
    const u = Auth.getSession();
    if (u.role === 'department_head') return { department_id: u.department_id || 0, employee_id: 0 };
    if (u.role === 'employee') return { department_id: 0, employee_id: u.id };
    return { department_id: 0, employee_id: 0 };
  }

  async function render(el) {
    const me = Auth.getSession();
    const admin = Auth.isAdmin();
    if ('formFms' in App.state) { FMS_FILTER = Number(App.state.formFms) || 0; delete App.state.formFms; }
    const sp = scopeParams();

    try {
      const [p, f, m, d, pl] = await Promise.all([
        window.agentdb.executeQuery('pending_forms_list', { department_id: sp.department_id, employee_id: sp.employee_id, fms_id: FMS_FILTER }),
        window.agentdb.executeQuery('load_forms', { department_id: 0, fms_id: 0 }),
        window.agentdb.executeQuery('load_fms', { department_id: 0, status: '' }),
        window.agentdb.executeQuery('load_departments', {}),
        window.agentdb.executeQuery('load_people', { department_id: 0, role: '' })
      ]);
      pendingRows = p.rows; formRows = f.rows; fmsList = m.rows; deptList = d.rows; peopleList = pl.rows;
    } catch (e) {
      el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>';
      return;
    }

    const breached = pendingRows.filter(p => p.is_breached).length;
    const required = formRows.filter(f => f.is_required).length;
    const activeFms = FMS_FILTER ? fmsList.find(f => Number(f.id) === Number(FMS_FILTER)) : null;

    el.innerHTML =
      '<div class="page-head"><div><h1>Forms</h1><div class="sub">Form library mapped to FMS and steps — plus every submission still owed</div></div>' +
      '<div class="page-actions"><button class="btn" id="fExport">' + UI.icon('download', 14) + ' Export CSV</button>' +
      ((admin || me.role === 'department_head') && Auth.canEdit() ? '<button class="btn primary" id="fNew" data-write>' + UI.icon('plus', 14) + ' Add form</button>' : '') + '</div></div>' +
      (activeFms ? '<div class="banner info">' + UI.icon('layers', 15) + '<div>Filtered to <b>' + UI.esc(activeFms.name) + '</b>. <button class="btn sm" id="fClear" style="margin-left:8px">Clear</button></div></div>' : '') +
      '<div class="kpi-grid">' +
      '<div class="kpi warn"><div class="k-top"><span class="k-lbl">Pending submissions</span><span class="k-ico">' + UI.icon('clipboard', 14) + '</span></div><div class="k-val">' + pendingRows.length + '</div><div class="k-sub">Awaiting a response</div></div>' +
      '<div class="kpi bad"><div class="k-top"><span class="k-lbl">Past deadline</span><span class="k-ico">' + UI.icon('alert', 14) + '</span></div><div class="k-val">' + breached + '</div><div class="k-sub">Form deadline breached</div></div>' +
      '<div class="kpi blue"><div class="k-top"><span class="k-lbl">Forms tracked</span><span class="k-ico">' + UI.icon('checks', 14) + '</span></div><div class="k-val">' + formRows.length + '</div><div class="k-sub">' + required + ' required</div></div>' +
      '<div class="kpi purple"><div class="k-top"><span class="k-lbl">Submissions logged</span><span class="k-ico">' + UI.icon('checkCircle', 14) + '</span></div><div class="k-val">' + UI.n(formRows.reduce((a, f) => a + Number(f.submissions || 0), 0)) + '</div><div class="k-sub">All time</div></div>' +
      '</div>' +
      '<div class="tabs"><button data-tab="library" class="' + (TAB === 'library' ? 'on' : '') + '">Form library (' + formRows.length + ')</button>' +
      '<button data-tab="pending" class="' + (TAB === 'pending' ? 'on' : '') + '">Pending submissions (' + pendingRows.length + ')</button></div>' +
      '<div id="fBody"></div>';

    const fc = document.getElementById('fClear');
    if (fc) fc.onclick = () => { FMS_FILTER = 0; App.rerender(); };
    document.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { TAB = b.dataset.tab; App.rerender(); });
    const nb = document.getElementById('fNew'); if (nb) nb.onclick = () => formModal(null);
    const ex = document.getElementById('fExport');
    if (ex) ex.onclick = () => {
      if (TAB === 'pending') UI.downloadCsv(pendingRows.map(p => ({
        Form: p.form_name, Type: p.form_type, Subject: p.subject, FMS: p.fms_name, Department: p.department_name,
        Assignee: p.assignee, ReferenceDate: p.ref_date, DaysPending: p.days_pending, DeadlineHours: p.deadline_hours, Breached: p.is_breached ? 'YES' : 'no'
      })), 'smartiqo-pending-forms.csv');
      else UI.downloadCsv(formRows.map(f => ({
        Form: f.name, Type: f.form_type, FMS: f.fms_name, Department: f.department_name, Trigger: f.trigger_step,
        DeadlineHours: f.deadline_hours, Required: f.is_required ? 'YES' : 'no', Submissions: f.submissions, LastSubmission: f.last_submission || '', URL: f.form_url || ''
      })), 'smartiqo-form-library.csv');
    };

    paint();
  }

  function paint() {
    const body = document.getElementById('fBody');
    if (!body) return;
    if (TAB === 'pending') body.innerHTML = pendingHtml();
    else body.innerHTML = libraryHtml();
    document.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('on', b.dataset.tab === TAB));

    body.querySelectorAll('[data-rec]').forEach(b => b.onclick = () => recordModal(pendingRows.find(p => String(p.form_id) + '-' + String(p.visit_id || 0) + '-' + String(p.task_id || 0) === b.dataset.rec)));
    body.querySelectorAll('[data-link]').forEach(a => a.onclick = (e) => e.stopPropagation());
    body.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => formModal(formRows.find(f => Number(f.id) === Number(b.dataset.edit))));
    body.querySelectorAll('[data-del]').forEach(b => b.onclick = () => deleteForm(formRows.find(f => Number(f.id) === Number(b.dataset.del))));
    body.querySelectorAll('[data-newform]').forEach(b => b.onclick = () => formModal(null));
  }

  function pendingHtml() {
    if (!pendingRows.length) return '<div class="card card-body">' + UI.empty('Nothing pending', 'Every required form has been submitted. Completed visits and steps with an outstanding form appear here automatically.') + '</div>';
    return '<div class="card"><div class="card-head"><h3>Outstanding submissions</h3><span class="small">Ordered by reference date</span></div><div class="card-body tight"><div class="tbl-wrap">' +
      '<table class="tbl"><thead><tr><th>Subject</th><th>Form</th><th>FMS</th><th>Department</th><th>Assignee</th><th>Reference date</th><th class="num">Days</th><th>Deadline</th><th></th></tr></thead><tbody>' +
      pendingRows.map(p => {
        const key = String(p.form_id) + '-' + String(p.visit_id || 0) + '-' + String(p.task_id || 0);
        return '<tr><td><div class="strong">' + UI.esc(p.subject || '—') + '</div><div class="small">' + (p.source === 'visit' ? 'Visit' : 'Task step') + '</div></td>' +
          '<td><div class="strong" style="font-size:12px">' + UI.esc(p.form_name) + '</div><div class="small">' + UI.esc(String(p.form_type).replace(/_/g, ' ')) + '</div></td>' +
          '<td class="small">' + UI.esc(p.fms_name || '—') + '</td>' +
          '<td class="small">' + UI.esc(p.department_name || '—') + '</td>' +
          '<td class="small">' + UI.esc(p.assignee || 'Unassigned') + '</td>' +
          '<td class="small nowrap">' + UI.fmtDate(p.ref_date) + '</td>' +
          '<td class="num">' + p.days_pending + '</td>' +
          '<td>' + (p.is_breached ? '<span class="pill red">Breached</span>' : '<span class="pill blue">Within ' + p.deadline_hours + 'h</span>') + '</td>' +
          '<td class="nowrap"><button class="btn sm primary" data-rec="' + key + '">Record</button></td></tr>';
      }).join('') + '</tbody></table></div></div></div>';
  }

  function libraryHtml() {
    if (!formRows.length) return '<div class="card card-body">' + UI.empty('No forms configured', 'Add the Google Forms your FMS steps depend on.', '<button class="btn primary" data-newform>Add form</button>') + '</div>';
    return '<div class="card"><div class="card-head"><h3>Form library</h3><span class="small">' + formRows.length + ' forms · trigger steps and deadlines</span></div><div class="card-body tight"><div class="tbl-wrap">' +
      '<table class="tbl"><thead><tr><th>Form name</th><th>FMS name</th><th>Step</th><th>Form link</th><th>Department</th><th class="num">Deadline</th><th>Required</th><th class="num">Submissions</th><th>Last received</th><th></th></tr></thead><tbody>' +
      formRows.map(f => '<tr><td><div class="strong">' + UI.esc(f.name) + '</div><div class="small">' + UI.esc(String(f.form_type).replace(/_/g, ' ')) + '</div></td>' +
        '<td class="small">' + UI.esc(f.fms_name || '—') + '</td>' +
        '<td class="small">' + UI.esc(f.trigger_step || '—') + '</td>' +
        '<td class="small">' + (f.form_url ? '<a href="' + UI.esc(f.form_url) + '" target="_blank" rel="noopener" data-link style="display:inline-flex;align-items:center;gap:5px;font-weight:600">Open form ' + UI.icon('external', 11) + '</a>' : '<span class="small">No link attached</span>') + '</td>' +
        '<td class="small">' + UI.esc(f.department_name || '—') + '</td>' +
        '<td class="num">' + f.deadline_hours + 'h</td>' +
        '<td>' + (f.is_required ? '<span class="pill amber">Required</span>' : '<span class="pill grey">Optional</span>') + '</td>' +
        '<td class="num">' + f.submissions + '</td>' +
        '<td class="small nowrap">' + (f.last_submission ? UI.fmtDate(f.last_submission) : '—') + '</td>' +
        '<td class="nowrap">' + ((Auth.isAdmin() || Auth.getSession().role === 'department_head') && Auth.canEdit() ? '<button class="btn sm" data-edit="' + f.id + '">Edit</button> <button class="btn sm danger" data-del="' + f.id + '">' + UI.icon('trash', 12) + '</button>' : '') + '</td></tr>').join('') +
      '</tbody></table></div></div></div>';
  }

  function recordModal(row) {
    if (!row) return;
    const me = Auth.getSession();
    UI.modal({
      title: 'Record submission · ' + row.form_name,
      body: '<div class="banner info">' + UI.icon('clipboard', 15) + '<div>Recording a submission for <b>' + UI.esc(row.subject || 'this item') + '</b> clears it from the pending list.</div></div>' +
        '<dl class="kv mb16"><dt>Form</dt><dd>' + UI.esc(row.form_name) + '</dd><dt>Reference</dt><dd>' + UI.esc(row.subject || '—') + '</dd>' +
        '<dt>Reference date</dt><dd>' + UI.fmtDate(row.ref_date) + '</dd><dt>Deadline</dt><dd>' + row.deadline_hours + ' hours' + (row.is_breached ? ' <span class="pill red">breached</span>' : '') + '</dd></dl>' +
        '<div class="field"><label>Response reference / link</label><input class="input" id="rRef" placeholder="https://forms.gle/… or reference number"></div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="rSave">Record submission</button>',
      onMount: (bg, close) => {
        bg.querySelector('#rSave').onclick = async () => {
          const btn = bg.querySelector('#rSave'); btn.disabled = true;
          try {
            await window.agentdb.executeQuery('record_form_submission', {
              form_id: row.form_id, visit_id: row.visit_id || 0, task_id: row.task_id || 0,
              submitted_by: me.id, reference: bg.querySelector('#rRef').value.trim()
            });
            if (row.visit_id) {
              try { await window.agentdb.executeQuery('sync_visit_form_status', { id: row.visit_id }); } catch (e) { }
            }
            await window.PAGES.departments.audit('Form submission recorded', 'form', String(row.form_id), row.subject || row.form_name);
            close(); UI.toast('Submission recorded', 'ok'); App.rerender();
          } catch (e) { btn.disabled = false; UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  function formModal(F) {
    const types = ['intake', 'after_visit', 'checklist', 'signoff', 'feedback', 'data_capture', 'standard'];
    UI.modal({
      title: F ? 'Edit form · ' + F.name : 'Add form',
      size: 'wide',
      body: '<div class="form-grid">' +
        '<div class="field full"><label>Form name *</label><input class="input" id="fmName" value="' + UI.esc(F ? F.name : '') + '" placeholder="e.g. After Site Visit Form"></div>' +
        '<div class="field"><label>FMS name</label><select class="select" id="fmFms"><option value="0">Not mapped</option>' + fmsList.map(f => '<option value="' + f.id + '"' + (F && Number(F.fms_id) === Number(f.id) ? ' selected' : '') + '>' + UI.esc(f.name) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Step *</label><input class="input" id="fmTrig" value="' + UI.esc(F ? F.trigger_step || '' : '') + '" placeholder="e.g. Visit completed"></div>' +
        '<div class="field full"><label>Form link (URL) *</label><input class="input" id="fmUrl" value="' + UI.esc(F ? F.form_url || '' : '') + '" placeholder="https://forms.gle/…"></div>' +
        '<div class="field"><label>Form type</label><select class="select" id="fmType">' + types.map(t => '<option value="' + t + '"' + (F && F.form_type === t ? ' selected' : '') + '>' + t.replace(/_/g, ' ') + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Department</label><select class="select" id="fmDept"><option value="0">Not mapped</option>' + deptList.map(d => '<option value="' + d.id + '"' + (F && Number(F.department_id) === Number(d.id) ? ' selected' : '') + '>' + UI.esc(d.name) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Responsible person</label><select class="select" id="fmResp"><option value="0">Not assigned</option>' + peopleList.map(p => '<option value="' + p.id + '"' + (F && Number(F.responsible_user_id) === Number(p.id) ? ' selected' : '') + '>' + UI.esc(p.full_name) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Deadline (hours)</label><input class="input" id="fmDl" type="number" min="1" value="' + (F ? F.deadline_hours : 24) + '"></div>' +
        '<div class="field"><label>Submission required</label><select class="select" id="fmReq"><option value="true"' + (!F || F.is_required ? ' selected' : '') + '>Required</option><option value="false"' + (F && !F.is_required ? ' selected' : '') + '>Optional</option></select></div>' +
        '<div class="field"><label>Status</label><select class="select" id="fmStatus"><option value="active"' + (!F || F.status === 'active' ? ' selected' : '') + '>Active</option><option value="inactive"' + (F && F.status === 'inactive' ? ' selected' : '') + '>Inactive</option></select></div>' +
        '</div>',
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="fmSave">Save form</button>',
      onMount: (bg, close) => {
        bg.querySelector('#fmSave').onclick = async () => {
          const name = bg.querySelector('#fmName').value.trim();
          if (!name) { UI.toast('Form name is required', 'bad'); return; }
          const step = bg.querySelector('#fmTrig').value.trim();
          const url = bg.querySelector('#fmUrl').value.trim();
          if (!step) { UI.toast('Which FMS step does this form belong to?', 'bad'); return; }
          if (!/^https?:\/\//i.test(url)) { UI.toast('Paste the form link (https://…)', 'bad'); return; }
          const payload = {
            name: name, form_type: bg.querySelector('#fmType').value,
            fms_id: Number(bg.querySelector('#fmFms').value) || 0,
            department_id: Number(bg.querySelector('#fmDept').value) || 0,
            form_url: bg.querySelector('#fmUrl').value.trim(),
            trigger_step: bg.querySelector('#fmTrig').value.trim(),
            is_required: bg.querySelector('#fmReq').value === 'true',
            responsible_user_id: Number(bg.querySelector('#fmResp').value) || 0,
            deadline_hours: Number(bg.querySelector('#fmDl').value) || 24,
            status: bg.querySelector('#fmStatus').value
          };
          const btn = bg.querySelector('#fmSave'); btn.disabled = true;
          try {
            if (F) await window.agentdb.executeQuery('update_form', Object.assign({ id: F.id }, payload));
            else await window.agentdb.executeQuery('create_form', payload);
            await window.PAGES.departments.audit(F ? 'Form updated' : 'Form created', 'form', F ? String(F.id) : '', name);
            close(); UI.toast('Form saved', 'ok'); App.rerender();
          } catch (e) { btn.disabled = false; UI.toast(e.message, 'bad'); }
        };
      }
    });
  }

  async function deleteForm(F) {
    if (!F) return;
    const ok = await UI.confirmAction('Delete “' + F.name + '”? Submissions already recorded are kept.', { danger: true, confirmLabel: 'Delete form' });
    if (!ok) return;
    try { await window.agentdb.executeQuery('delete_form', { id: F.id }); UI.toast('Form deleted', 'ok'); App.rerender(); }
    catch (e) { UI.toast(e.message, 'bad'); }
  }

  return { render, formModal };
})();
