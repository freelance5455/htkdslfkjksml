/* SmartiQo · Overview dashboard */
window.PAGES = window.PAGES || {};
window.PAGES.overview = (function () {

  function kpiCard(o) {
    return '<div class="kpi ' + o.tone + '" ' + (o.route ? 'data-route="' + o.route + '"' : '') + (o.status ? ' data-status="' + o.status + '"' : '') + ' role="button" tabindex="0">' +
      '<div class="k-top"><span class="k-lbl">' + UI.esc(o.label) + '</span><span class="k-ico">' + UI.icon(o.icon, 14) + '</span></div>' +
      '<div class="k-val">' + o.val + '</div>' +
      '<div class="k-sub">' + (o.sub || '') + '</div></div>';
  }

  async function render(el, ctx) {
    const s = ctx.state, sc = Auth.scope();
    const u = s.user;
    const hour = new Date().getHours();
    const greet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

    let k, trend, depts, fms, dist, emps, visits;
    try {
      [k, trend, depts, fms, dist, emps, visits] = await Promise.all([
        window.agentdb.executeQuery('dashboard_kpis', { from_date: s.from, to_date: s.to, department_id: sc.dept, user_id: sc.uid }),
        window.agentdb.executeQuery('dashboard_trend', { from_date: s.from, to_date: s.to, department_id: sc.dept, user_id: sc.uid }),
        window.agentdb.executeQuery('dashboard_dept_perf', {}),
        window.agentdb.executeQuery('dashboard_fms_perf', {}),
        window.agentdb.executeQuery('dashboard_pending_dist', {}),
        window.agentdb.executeQuery('dashboard_top_employees', {}),
        window.agentdb.executeQuery('dashboard_today_visits', {})
      ]);
    } catch (e) {
      el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div><b>Dashboard data did not load.</b><br>' + UI.esc(e.message) + '</div></div>';
      return;
    }

    const K = k.rows[0] || {};
    // On-time rate = completed on time / completed, the same basis the
    // Operations Performance Report uses, so both screens agree.
    const perf = UI.pct(K.on_time, K.completed);
    const scopeNote = u.role === 'admin' ? 'Company-wide' : u.role === 'department_head' ? 'Department scope' : 'My workspace';

    el.innerHTML =
      '<div class="page-head no-print"><div><h1>' + greet + ', ' + UI.esc(u.name.split(' ')[0]) + '</h1>' +
      '<div class="sub">' + scopeNote + ' · reporting period <b>' + UI.esc(App.rangeLabel()) + '</b> · ' + UI.fmtDate(new Date()) + '</div></div>' +
      '<div class="page-actions"><button class="btn" id="ovRefresh">' + UI.icon('refresh', 14) + ' Refresh</button>' +
      (Auth.allowed('forms') ? '<button class="btn" id="ovForms">' + UI.icon('clipboard', 14) + ' Forms</button>' : '') +
      '<button class="btn primary" id="ovTask" data-write>' + UI.icon('plus', 14) + ' New task</button></div></div>' +

      '<div class="hero"><div style="position:relative;z-index:1"><h2>Operations control centre</h2>' +
      '<p>Every department, FMS, task, visit and form in one place — ' + UI.n(K.total_tasks) + ' tasks tracked in this period.</p></div>' +
      '<div class="hr-stats">' +
      '<div class="hr-stat"><div class="v" style="color:#FF9C93">' + UI.n(K.overdue) + '</div><div class="l">Overdue</div></div>' +
      '<div class="hr-stat"><div class="v">' + UI.n(K.pending) + '</div><div class="l">In flight</div></div>' +
      '<div class="hr-stat"><div class="v">' + UI.n(K.today_site + K.today_service) + '</div><div class="l">Visits today</div></div>' +
      '<div class="hr-stat"><div class="v" style="color:#8FD9B6">' + perf + '%</div><div class="l">On-time rate</div></div>' +
      '</div></div>' +

      '<div class="kpi-grid no-print">' +
      kpiCard({ label: 'Departments', val: UI.n(K.departments), icon: 'building', tone: 'blue', route: '/departments', sub: UI.n(K.users) + ' active users' }) +
      kpiCard({ label: 'Active FMS', val: UI.n(K.active_fms), icon: 'layers', tone: 'blue', route: '/fms', sub: 'Open FMS library' }) +
      kpiCard({ label: 'FMS tasks', val: UI.n(K.total_tasks), icon: 'checks', tone: 'purple', route: '/tasks', sub: 'In selected period' }) +
      kpiCard({ label: 'Completed', val: UI.n(K.completed), icon: 'checkCircle', tone: 'ok', route: '/tasks', status: 'completed', sub: UI.n(K.on_time) + ' on time · ' + UI.n(K.late) + ' late' }) +
      kpiCard({ label: 'Pending', val: UI.n(K.pending), icon: 'clock', tone: 'warn', route: '/tasks', status: 'in_progress', sub: 'Not started / in progress / hold' }) +
      kpiCard({ label: 'Overdue', val: UI.n(K.overdue), icon: 'alert', tone: 'bad', route: '/tasks', status: 'overdue', sub: 'SLA breached' }) +
      kpiCard({ label: "Today's site visits", val: UI.n(K.today_site), icon: 'pin', tone: 'blue', route: '/site-visits', sub: 'Scheduled for today' }) +
      kpiCard({ label: "Today's service visits", val: UI.n(K.today_service), icon: 'wrench', tone: 'purple', route: '/service-visits', sub: 'Scheduled for today' }) +
      kpiCard({ label: 'Pending forms', val: UI.n(K.pending_forms), icon: 'clipboard', tone: 'warn', route: '/forms', sub: 'Awaiting submission' }) +
      kpiCard({ label: 'Dept performance', val: perf + '%', icon: 'chart', tone: 'ok', route: '/reports', sub: 'On time / completed' }) +
      '</div>' +

      '<div class="two-col no-print">' +
      '<div class="card"><div class="card-head"><div><h3>FMS completion trend</h3><div class="hint">Tasks created vs completed vs overdue — ' + UI.esc(App.rangeLabel().toLowerCase()) + '</div></div>' +
      '<div class="seg"><button class="on" data-trend="all">All</button><button data-trend="dept">By dept</button></div></div>' +
      '<div class="card-body"><div class="chart-box"><canvas id="chTrend" aria-label="FMS completion trend"></canvas></div></div></div>' +

      '<div class="card"><div class="card-head"><div><h3>On-time vs overdue</h3><div class="hint">Completion quality in this period</div></div></div>' +
      '<div class="card-body"><div class="chart-box"><canvas id="chSplit" aria-label="On-time versus overdue"></canvas></div>' +
      '<div class="grid-4 mt12" style="gap:8px">' +
      '<div class="dm"><div class="v">' + UI.hrs(K.avg_hours) + '</div><div class="l">Avg completion</div></div>' +
      '<div class="dm"><div class="v">' + UI.pct(K.on_time, K.completed) + '%</div><div class="l">On-time share</div></div>' +
      '<div class="dm"><div class="v">' + UI.n(K.late) + '</div><div class="l">Completed late</div></div>' +
      '<div class="dm"><div class="v">' + UI.n(K.pending) + '</div><div class="l">Still open</div></div>' +
      '</div></div></div></div>' +

      '<div class="card no-print"><div class="card-head"><div><h3>Department performance</h3><div class="hint">Click a department to open its dashboard</div></div>' +
      '<button class="btn sm" data-route="/departments">All departments ' + UI.icon('arrow', 12) + '</button></div>' +
      '<div class="card-body tight"><div class="tbl-wrap"><table class="tbl"><thead><tr>' +
      '<th>Department</th><th>Head</th><th class="num">FMS</th><th class="num">Tasks</th><th class="num">Completed</th><th class="num">Pending</th><th class="num">Overdue</th><th>On-time rate</th><th>Pending forms</th></tr></thead><tbody>' +
      depts.rows.map(d => {
        const p = UI.pct(d.on_time, d.completed);
        return '<tr class="dept-row" data-dept="' + d.id + '" style="cursor:pointer">' +
          '<td><div class="flex items-center gap8"><span style="width:7px;height:26px;border-radius:4px;background:' + UI.esc(d.color) + '"></span><div><div class="strong">' + UI.esc(d.name) + '</div><div class="small">' + UI.esc(d.code || '') + '</div></div></div></td>' +
          '<td class="small">' + UI.esc(d.head_name || 'Not assigned') + '</td>' +
          '<td class="num">' + d.fms_count + '</td><td class="num">' + d.total_tasks + '</td><td class="num">' + d.completed + '</td>' +
          '<td class="num">' + d.pending + '</td><td class="num" style="color:' + (d.overdue > 0 ? 'var(--bad)' : 'inherit') + ';font-weight:' + (d.overdue > 0 ? 650 : 400) + '">' + d.overdue + '</td>' +
          '<td><div class="flex items-center gap8"><div style="flex:1;min-width:70px">' + UI.bar(p, p >= 70 ? 'ok' : p >= 40 ? 'amber' : 'bad') + '</div><span class="small mono">' + p + '%</span></div></td>' +
          '<td>' + (d.pending_forms > 0 ? '<span class="pill amber">' + d.pending_forms + ' pending</span>' : '<span class="small">None</span>') + '</td></tr>';
      }).join('') + '</tbody></table></div></div></div>' +

      '<div class="two-col no-print">' +
      '<div class="card"><div class="card-head"><div><h3>FMS-wise performance</h3><div class="hint">Overdue load by process</div></div>' +
      '<button class="btn sm" data-route="/fms">FMS library ' + UI.icon('arrow', 12) + '</button></div>' +
      '<div class="card-body"><div class="chart-box"><canvas id="chFms" aria-label="FMS overdue"></canvas></div></div></div>' +
      '<div class="card"><div class="card-head"><div><h3>Pending work distribution</h3><div class="hint">Open + overdue by department</div></div></div>' +
      '<div class="card-body"><div class="chart-box"><canvas id="chDist" aria-label="Pending work by department"></canvas></div></div></div></div>' +

      '<div class="two-col no-print">' +
      '<div class="card"><div class="card-head"><div><h3>Today\'s schedule</h3><div class="hint">' + visits.rows.length + ' visits for ' + UI.fmtDate(new Date()) + '</div></div>' +
      '<button class="btn sm" data-route="/site-visits">Open calendar ' + UI.icon('arrow', 12) + '</button></div>' +
      '<div class="card-body tight">' + (visits.rows.length ? '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Time</th><th>Customer</th><th>Type</th><th>Assignee</th><th>Status</th><th>Form</th></tr></thead><tbody>' +
        visits.rows.map(v => '<tr><td class="nowrap mono">' + UI.fmtTime(v.start_time) + '–' + UI.fmtTime(v.end_time) + '</td>' +
          '<td><div class="strong">' + UI.esc(v.customer_name) + '</div><div class="small">' + UI.esc(v.city || '') + '</div></td>' +
          '<td><span class="pill ' + (v.visit_type === 'site' ? 'blue' : 'purple') + '">' + (v.visit_type === 'site' ? 'Site' : 'Service') + '</span></td>' +
          '<td class="small">' + UI.esc(v.assignee || 'Unassigned') + '</td>' +
          '<td>' + UI.pill(v.status) + '</td><td>' + (v.form_status === 'pending' ? '<span class="pill amber">Pending</span>' : '<span class="small">—</span>') + '</td></tr>').join('') +
        '</tbody></table></div>' : UI.empty('No visits scheduled today', 'Schedule a site or service visit to see it here.', '<button class="btn primary sm" data-route="/site-visits">Schedule visit</button>')) + '</div></div>' +

      '<div class="card"><div class="card-head"><div><h3>Employee work performance</h3><div class="hint">Ranked by overdue load</div></div></div>' +
      '<div class="card-body tight"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Employee</th><th class="num">Tasks</th><th class="num">Done</th><th class="num">Overdue</th><th>Completion</th></tr></thead><tbody>' +
      emps.rows.map(e => {
        const p = UI.pct(e.completed, e.total_tasks);
        return '<tr><td><div class="flex items-center gap8">' + UI.avatar(e.full_name, '#64748B', 'sm') + '<div><div class="strong" style="font-size:12px">' + UI.esc(e.full_name) + '</div><div class="small">' + UI.esc(e.department_name || '') + '</div></div></div></td>' +
          '<td class="num">' + e.total_tasks + '</td><td class="num">' + e.completed + '</td>' +
          '<td class="num" style="color:' + (e.overdue > 0 ? 'var(--bad)' : 'inherit') + '">' + e.overdue + '</td>' +
          '<td><div class="flex items-center gap8"><div style="flex:1;min-width:50px">' + UI.bar(p, p >= 70 ? 'ok' : p >= 40 ? 'amber' : 'bad') + '</div><span class="small mono">' + p + '%</span></div></td></tr>';
      }).join('') + '</tbody></table></div></div></div></div>' +

      '<div class="card"><div class="card-head"><div><h3>FMS performance detail</h3><div class="hint">On-time, late, pending and overdue steps for every process</div></div>' +
      '<button class="btn sm" id="ovExport">' + UI.icon('download', 13) + ' Export CSV</button></div>' +
      '<div class="card-body tight"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>FMS</th><th>Department</th><th class="num">Tasks</th><th class="num">On time</th><th class="num">Late</th><th class="num">Pending</th><th class="num">Overdue</th><th class="num">Avg time</th><th>Completion</th><th>FMS</th></tr></thead><tbody>' +
      fms.rows.map(f => {
        const p = UI.pct(f.completed, f.total_tasks);
        return '<tr><td><div class="strong">' + UI.esc(f.name) + '</div><div class="small">' + UI.esc(f.code || '') + '</div></td>' +
          '<td class="small">' + UI.esc(f.department_name || '—') + '</td><td class="num">' + f.total_tasks + '</td>' +
          '<td class="num">' + f.on_time + '</td><td class="num">' + f.late + '</td><td class="num">' + f.pending + '</td>' +
          '<td class="num" style="color:' + (f.overdue ? 'var(--bad)' : 'inherit') + '">' + f.overdue + '</td>' +
          '<td class="num small">' + UI.hrs(f.avg_hours) + '</td>' +
          '<td><div class="flex items-center gap8"><div style="flex:1;min-width:60px">' + UI.bar(p, p >= 70 ? 'ok' : p >= 40 ? 'amber' : 'bad') + '</div><span class="small mono">' + p + '%</span></div></td>' +
          '<td><button class="btn sm" data-fms="' + f.id + '">Open</button></td></tr>';
      }).join('') + '</tbody></table></div></div></div>';

    // interactions
    el.querySelectorAll('[data-route]').forEach(b => b.onclick = (e) => {
      e.stopPropagation();
      App.state.taskStatus = b.dataset.status || '';
      App.navigate(b.dataset.route);
    });
    el.querySelectorAll('.dept-row').forEach(r => r.onclick = () => App.navigate('/departments/' + r.dataset.dept));
    el.querySelectorAll('[data-fms]').forEach(b => b.onclick = () => App.navigate('/fms/' + b.dataset.fms));
    const rf = el.querySelector('#ovRefresh'); if (rf) rf.onclick = () => App.rerender();
    const nt = el.querySelector('#ovTask'); if (nt) nt.onclick = () => window.PAGES.tasks.openCreate();
    const fm = el.querySelector('#ovForms'); if (fm) fm.onclick = () => App.navigate('/forms');
    const ex = el.querySelector('#ovExport');
    if (ex) ex.onclick = () => UI.downloadCsv(fms.rows.map(f => ({
      FMS: f.name, Code: f.code, Department: f.department_name, Tasks: f.total_tasks, OnTime: f.on_time,
      Late: f.late, Pending: f.pending, Overdue: f.overdue, AvgHours: f.avg_hours, CompletionPct: UI.pct(f.completed, f.total_tasks)
    })), 'smartiqo-fms-performance.csv');

    // charts
    const rows = trend.rows;
    const labels = rows.map(r => UI.fmtShort(r.day));
    UI.chart(document.getElementById('chTrend'), {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          { label: 'Created', data: rows.map(r => r.created), borderColor: '#1D6BF3', backgroundColor: 'rgba(29,107,243,.12)', fill: true, tension: .35, borderWidth: 2, pointRadius: 0, pointHoverRadius: 4 },
          { label: 'Completed', data: rows.map(r => r.completed), borderColor: '#0E9F6E', backgroundColor: 'rgba(14,159,110,.10)', fill: true, tension: .35, borderWidth: 2, pointRadius: 0, pointHoverRadius: 4 },
          { label: 'Overdue', data: rows.map(r => r.overdue), borderColor: '#D92D20', backgroundColor: 'rgba(217,45,32,.08)', fill: true, tension: .35, borderWidth: 2, pointRadius: 0, pointHoverRadius: 4 }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 8, boxHeight: 8, usePointStyle: true, padding: 14 } } },
        scales: {
          x: { grid: { display: false }, ticks: { maxTicksLimit: 10 } },
          y: { beginAtZero: true, grid: { color: UI.gridColor() }, ticks: { precision: 0 } }
        }
      }
    });

    UI.chart(document.getElementById('chSplit'), {
      type: 'doughnut',
      data: {
        labels: ['On time', 'Completed late', 'Pending', 'Overdue'],
        datasets: [{
          data: [K.on_time || 0, K.late || 0, K.pending || 0, K.overdue || 0],
          backgroundColor: ['#0E9F6E', '#F79009', '#1D6BF3', '#D92D20'],
          borderWidth: 0, hoverOffset: 4
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '66%',
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 8, boxHeight: 8, usePointStyle: true, padding: 12 } } }
      }
    });

    UI.chart(document.getElementById('chFms'), {
      type: 'bar',
      data: {
        labels: fms.rows.slice(0, 8).map(f => f.code || f.name.slice(0, 14)),
        datasets: [
          { label: 'Overdue', data: fms.rows.slice(0, 8).map(f => f.overdue), backgroundColor: '#D92D20', borderRadius: 4, maxBarThickness: 16 },
          { label: 'Pending', data: fms.rows.slice(0, 8).map(f => f.pending), backgroundColor: '#1D6BF3', borderRadius: 4, maxBarThickness: 16 }
        ]
      },
      options: {
        indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 8, boxHeight: 8, usePointStyle: true } } },
        scales: { x: { beginAtZero: true, grid: { color: UI.gridColor() }, ticks: { precision: 0 } }, y: { grid: { display: false } } }
      }
    });

    UI.chart(document.getElementById('chDist'), {
      type: 'doughnut',
      data: {
        labels: dist.rows.map(d => d.name),
        datasets: [{ data: dist.rows.map(d => d.pending + d.overdue), backgroundColor: UI.palette(), borderWidth: 0, hoverOffset: 4 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '58%',
        plugins: { legend: { position: 'right', labels: { boxWidth: 8, boxHeight: 8, usePointStyle: true, padding: 9, font: { size: 10 } } } }
      }
    });

    console.log('[dashboard] rendered', K.total_tasks, 'tasks in range');
  }

  return { render };
})();
