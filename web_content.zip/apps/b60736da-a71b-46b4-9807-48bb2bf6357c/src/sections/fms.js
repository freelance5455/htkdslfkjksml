/* SmartiQo · FMS library and FMS workspace */
window.PAGES = window.PAGES || {};
window.PAGES.fms = (function () {

  let cache = { rows: [], depts: [], linked: [] };

  function card(f) {
    const p = UI.pct(f.completed, f.total_tasks);
    return '<div class="fms-card" data-fms="' + f.id + '">' +
      '<div class="fc-top"><div style="flex:1;min-width:0"><div class="flex items-center gap8"><span class="fc-code">' + UI.esc(f.code || 'FMS') + '</span>' +
      (f.status === 'active' ? '<span class="pill green">Active</span>' : '<span class="pill grey">Inactive</span>') + '</div>' +
      '<div class="fc-name">' + UI.esc(f.name) + '</div>' +
      '<div class="small" style="margin-top:2px">' + UI.esc(f.department_name || 'No department') + ' · SLA ' + UI.hrs(f.sla_hours) + '</div></div></div>' +
      '<div class="fc-body">' +
      '<div class="mini-stats"><span><b>' + f.total_tasks + '</b> tasks</span><span><b>' + f.completed + '</b> done</span>' +
      '<span style="color:' + (f.overdue ? 'var(--bad)' : 'inherit') + '"><b style="color:inherit">' + f.overdue + '</b> overdue</span>' +
      (f.pending_forms ? '<span><b>' + f.pending_forms + '</b> forms</span>' : '') + '</div>' +
      '<div class="flex items-center gap8 mb8"><div style="flex:1">' + UI.bar(p, p >= 70 ? 'ok' : p >= 40 ? 'amber' : 'bad') + '</div><span class="small mono">' + p + '%</span></div>' +
      '<div class="flex items-center gap8" style="margin-top:10px">' +
      '<button class="btn sm primary" data-open="' + f.id + '">' + UI.icon('external', 13) + ' Open FMS</button>' +
      '<button class="btn sm" data-det="' + f.id + '">Details</button>' +
      '<span class="small ml-auto">' + UI.icon('clipboard', 12) + ' ' + f.form_count + '</span></div>' +
      '</div></div>';
  }

  async function render(el, ctx) {
    if (ctx.id) return renderDetail(el, ctx);
    let fms, depts, linked;
    try {
      [fms, depts, linked] = await Promise.all([
        window.agentdb.executeQuery('load_fms', { department_id: 0, status: '' }),
        window.agentdb.executeQuery('load_departments', {}),
        window.agentdb.executeQuery('fms_departments_map', {})
      ]);
    } catch (e) {
      el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>';
      return;
    }
    cache = { rows: fms.rows, depts: depts.rows, linked: linked.rows };
    const admin = Auth.isAdmin();

    el.innerHTML =
      '<div class="page-head"><div><h1>FMS Management</h1><div class="sub">One library for every SmartiQo process — open, configure and monitor each FMS</div></div>' +
      '<div class="page-actions">' + (admin ? '<button class="btn primary" id="addFms">' + UI.icon('plus', 14) + ' Add FMS</button>' : '') + '</div></div>' +
      '<div class="kpi-grid">' +
      '<div class="kpi blue"><div class="k-top"><span class="k-lbl">Total FMS</span><span class="k-ico">' + UI.icon('layers', 14) + '</span></div><div class="k-val">' + fms.rows.length + '</div><div class="k-sub">' + fms.rows.filter(f => f.status === 'active').length + ' active</div></div>' +
      '<div class="kpi purple"><div class="k-top"><span class="k-lbl">Tracked tasks</span><span class="k-ico">' + UI.icon('checks', 14) + '</span></div><div class="k-val">' + UI.n(fms.rows.reduce((a, x) => a + Number(x.total_tasks), 0)) + '</div><div class="k-sub">Across all processes</div></div>' +
      '<div class="kpi ok"><div class="k-top"><span class="k-lbl">Completed</span><span class="k-ico">' + UI.icon('checkCircle', 14) + '</span></div><div class="k-val">' + UI.n(fms.rows.reduce((a, x) => a + Number(x.completed), 0)) + '</div><div class="k-sub">' + UI.n(fms.rows.reduce((a, x) => a + Number(x.on_time), 0)) + ' on time</div></div>' +
      '<div class="kpi bad"><div class="k-top"><span class="k-lbl">Overdue steps</span><span class="k-ico">' + UI.icon('alert', 14) + '</span></div><div class="k-val">' + UI.n(fms.rows.reduce((a, x) => a + Number(x.overdue), 0)) + '</div><div class="k-sub">SLA breaches</div></div>' +
      '<div class="kpi warn"><div class="k-top"><span class="k-lbl">Configured URLs</span><span class="k-ico">' + UI.icon('link', 14) + '</span></div><div class="k-val">' + fms.rows.filter(f => f.dashboard_url).length + '/' + fms.rows.length + '</div><div class="k-sub">Dashboard links</div></div>' +
      '</div>' +
      '<div class="toolbar"><div class="grow"><input class="input" id="fmsSearch" placeholder="Search FMS by name, code or category…" style="width:100%"></div>' +
      '<select class="select" id="fmsDept"><option value="0">All departments</option>' + depts.rows.map(d => '<option value="' + d.id + '">' + UI.esc(d.name) + '</option>').join('') + '</select>' +
      '<select class="select" id="fmsStatus"><option value="">All statuses</option><option value="active">Active</option><option value="inactive">Inactive</option></select>' +
      '<button class="btn sm" id="fmsExport">' + UI.icon('download', 13) + ' CSV</button></div>' +
      '<div class="grid-3" id="fmsGrid" style="grid-template-columns:repeat(auto-fill,minmax(285px,1fr))"></div>';

    function paint() {
      const q = (document.getElementById('fmsSearch').value || '').toLowerCase();
      const st = document.getElementById('fmsStatus').value;
      const rows = cache.rows.filter(f =>
        (!q || (f.name + ' ' + (f.code || '') + ' ' + (f.category || '') + ' ' + (f.department_name || '')).toLowerCase().includes(q)) &&
        (!st || f.status === st));
      const g = document.getElementById('fmsGrid');
      g.innerHTML = rows.length ? rows.map(card).join('') : UI.empty('No FMS match these filters', 'Adjust the search or add a new process.', admin ? '<button class="btn primary" id="emptyAdd">Add FMS</button>' : '');
      g.querySelectorAll('[data-fms]').forEach(c => c.onclick = (e) => { if (e.target.closest('button')) return; App.navigate('/fms/' + c.dataset.fms); });
      g.querySelectorAll('[data-open]').forEach(b => b.onclick = (e) => { e.stopPropagation(); openFms(Number(b.dataset.open)); });
      g.querySelectorAll('[data-det]').forEach(b => b.onclick = (e) => { e.stopPropagation(); App.navigate('/fms/' + b.dataset.det); });
      const ea = g.querySelector('#emptyAdd'); if (ea) ea.onclick = () => fmsModal(null);
    }
    paint();
    document.getElementById('fmsSearch').oninput = UI.debounce(paint, 160);
    document.getElementById('fmsStatus').onchange = paint;
    document.getElementById('fmsDept').onchange = async (e) => {
      const dept = Number(e.target.value);
      const r = await window.agentdb.executeQuery('load_fms', { department_id: dept, status: '' });
      cache.rows = r.rows; paint();
    };
    const add = document.getElementById('addFms'); if (add) add.onclick = () => fmsModal(null);
    const ex = document.getElementById('fmsExport');
    if (ex) ex.onclick = () => UI.downloadCsv(cache.rows.map(f => ({
      FMS: f.name, Code: f.code, Department: f.department_name, Status: f.status, SLAHours: f.sla_hours,
      Tasks: f.total_tasks, Completed: f.completed, OnTime: f.on_time, Late: f.late, Pending: f.pending,
      Overdue: f.overdue, PendingForms: f.pending_forms, AvgHours: f.avg_hours, DashboardURL: f.dashboard_url || ''
    })), 'smartiqo-fms-library.csv');
  }

  async function renderDetail(el, ctx) {
    const id = Number(ctx.id);
    let f, forms, linked, depts;
    try {
      [f, forms, linked, depts] = await Promise.all([
        window.agentdb.executeQuery('fms_detail', { id: id }),
        window.agentdb.executeQuery('load_forms', { department_id: 0, fms_id: id }),
        window.agentdb.executeQuery('fms_departments_map', {}),
        window.agentdb.executeQuery('load_departments', {})
      ]);
    } catch (e) { el.innerHTML = '<div class="banner warn">' + UI.icon('alert', 16) + '<div>' + UI.esc(e.message) + '</div></div>'; return; }
    if (!f.rows.length) { el.innerHTML = UI.empty('FMS not found', 'It may have been deleted.'); return; }
    const F = f.rows[0];
    const admin = Auth.isAdmin();
    const from = UI.todayISO(-180), to = UI.todayISO(0);
    const tasks = await window.agentdb.executeQuery('load_tasks', { fms_id: id, department_id: 0, assigned_to: 0, status: '', from_date: from, to_date: to, search: '' });
    const maps = linked.rows.filter(x => x.fms_id === id);
    const p = UI.pct(F.completed, F.total_tasks);

    el.innerHTML =
      '<div class="page-head"><div><div class="crumb" style="margin-bottom:6px"><a href="#/fms">FMS Management</a> <span style="opacity:.5">/</span> <b>' + UI.esc(F.code || F.name) + '</b></div>' +
      '<h1>' + UI.esc(F.name) + '</h1><div class="sub">' + UI.esc(F.description || 'No description configured') + '</div></div>' +
      '<div class="page-actions"><button class="btn" id="fmsTasks">' + UI.icon('checks', 14) + ' Task tracking</button>' +
      '<button class="btn primary" id="fmsOpen">' + UI.icon('external', 14) + ' Open FMS</button>' +
      (admin ? '<button class="btn" id="fmsEdit">' + UI.icon('edit', 14) + ' Configure</button>' : '') + '</div></div>' +

      '<div class="banner ' + (F.dashboard_url ? 'ok' : 'warn') + '">' + UI.icon(F.dashboard_url ? 'checkCircle' : 'alert', 15) +
      '<div>' + (F.dashboard_url
        ? 'Dashboard URL configured · <b>' + UI.esc(F.dashboard_url) + '</b>. Open FMS launches the live process.'
        : '<b>No dashboard URL configured yet.</b> This FMS is tracked inside SmartiQo. An admin can attach the live FMS dashboard, Google Sheet and form URLs in Configure so Open FMS launches the real system.') + '</div></div>' +

      '<div class="kpi-grid">' +
      '<div class="kpi blue"><div class="k-top"><span class="k-lbl">Total steps</span><span class="k-ico">' + UI.icon('checks', 14) + '</span></div><div class="k-val">' + F.total_tasks + '</div><div class="k-sub">Last 180 days</div></div>' +
      '<div class="kpi ok"><div class="k-top"><span class="k-lbl">Completed</span><span class="k-ico">' + UI.icon('checkCircle', 14) + '</span></div><div class="k-val">' + F.completed + '</div><div class="k-sub">' + F.on_time + ' on time · ' + F.late + ' late</div></div>' +
      '<div class="kpi warn"><div class="k-top"><span class="k-lbl">Pending</span><span class="k-ico">' + UI.icon('clock', 14) + '</span></div><div class="k-val">' + F.pending + '</div><div class="k-sub">In progress / not started</div></div>' +
      '<div class="kpi bad"><div class="k-top"><span class="k-lbl">Overdue</span><span class="k-ico">' + UI.icon('alert', 14) + '</span></div><div class="k-val">' + F.overdue + '</div><div class="k-sub">Past SLA</div></div>' +
      '<div class="kpi purple"><div class="k-top"><span class="k-lbl">Avg completion</span><span class="k-ico">' + UI.icon('clock', 14) + '</span></div><div class="k-val">' + UI.hrs(F.avg_hours) + '</div><div class="k-sub">SLA ' + UI.hrs(F.sla_hours) + '</div></div>' +
      '</div>' +

      '<div class="two-col"><div class="stack">' +
      '<div class="card"><div class="card-head"><h3>Process steps</h3><span class="small">' + tasks.rows.length + ' steps · completion ' + p + '%</span></div>' +
      '<div class="card-body tight" style="max-height:430px;overflow-y:auto"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Task</th><th>Step</th><th>Owner</th><th>Due</th><th>Status</th></tr></thead><tbody>' +
      (tasks.rows.length ? tasks.rows.slice(0, 60).map(t => '<tr data-task="' + t.id + '" style="cursor:pointer"><td><div class="strong">' + UI.esc(t.task_code) + '</div><div class="small">' + UI.rel(t.created_at) + '</div></td>' +
        '<td class="small">' + UI.esc(t.step_name || '—') + '</td><td class="small">' + UI.esc(t.assignee || 'Unassigned') + '</td>' +
        '<td class="small nowrap">' + UI.fmtShort(t.due_at) + '</td><td>' + UI.pill(t.status) + '</td></tr>').join('') : '<tr><td colspan="5">' + UI.empty('No steps recorded', 'Tasks created for this FMS will appear here.', '') + '</td></tr>') +
      '</tbody></table></div></div></div>' +

      '<div class="card"><div class="card-head"><h3>Mapped forms</h3><span class="small">' + forms.rows.length + ' forms</span></div>' +
      '<div class="card-body tight"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Form</th><th>Type</th><th>Trigger</th><th class="num">Submissions</th><th>Required</th></tr></thead><tbody>' +
      (forms.rows.length ? forms.rows.map(fm => '<tr><td><div class="strong">' + UI.esc(fm.name) + '</div><div class="small">' + UI.esc(fm.deadline_hours) + 'h deadline</div></td>' +
        '<td class="small">' + UI.esc(fm.form_type.replace(/_/g, ' ')) + '</td><td class="small">' + UI.esc(fm.trigger_step || '—') + '</td>' +
        '<td class="num">' + fm.submissions + '</td><td>' + (fm.is_required ? '<span class="pill amber">Required</span>' : '<span class="pill grey">Optional</span>') + '</td></tr>').join('') :
        '<tr><td colspan="5">' + UI.empty('No forms mapped', 'Add a Google Form to start tracking submissions.', admin ? '<button class="btn sm primary" data-gotoforms>Add form</button>' : '') + '</td></tr>') +
      '</tbody></table></div></div></div>' +
      '</div>' +

      '<div class="stack">' +
      '<div class="card"><div class="card-head"><h3>Configuration</h3></div><div class="card-body">' +
      '<dl class="kv"><dt>FMS code</dt><dd>' + UI.esc(F.code || '—') + '</dd>' +
      '<dt>Department</dt><dd>' + UI.esc(F.department_name || '—') + '</dd>' +
      '<dt>Also assigned to</dt><dd>' + (maps.filter(m => m.department_id !== F.department_id).map(m => UI.esc(m.name)).join(', ') || '—') + '</dd>' +
      '<dt>Owner</dt><dd>' + UI.esc(F.owner_name || '—') + '</dd>' +
      '<dt>Process start</dt><dd>' + UI.fmtDate(F.start_date) + '</dd>' +
      '<dt>SLA</dt><dd>' + UI.hrs(F.sla_hours) + '</dd>' +
      '<dt>Status</dt><dd>' + UI.pill(F.status) + '</dd>' +
      '<dt>Category</dt><dd>' + UI.esc(F.category || '—') + '</dd></dl>' +
      '<div class="drop-sep" style="margin:12px 0"></div>' +
      '<dl class="kv"><dt>Dashboard URL</dt><dd>' + (F.dashboard_url ? '<a href="' + UI.esc(F.dashboard_url) + '" target="_blank" rel="noopener">' + UI.esc(F.dashboard_url.slice(0, 44)) + (F.dashboard_url.length > 44 ? '…' : '') + '</a>' : '<span class="small">Not configured</span>') + '</dd>' +
      '<dt>Google Sheet</dt><dd>' + (F.sheet_url ? '<a href="' + UI.esc(F.sheet_url) + '" target="_blank" rel="noopener">Open sheet</a>' : '<span class="small">Not configured</span>') + '</dd>' +
      '<dt>Form URLs</dt><dd>' + (F.form_urls ? UI.esc(F.form_urls).split(',').filter(Boolean).map(u => '<a href="' + UI.esc(u.trim()) + '" target="_blank" rel="noopener">Form</a>').join(' · ') : '<span class="small">Not configured</span>') + '</dd>' +
      '<dt>Embedding</dt><dd>' + (F.embeddable ? 'Allowed' : 'Open in new tab only') + '</dd></dl>' +
      '</div></div>' +
      '<div class="card"><div class="card-head"><h3>Reporting configuration</h3></div><div class="card-body">' +
      '<p class="small" style="margin:0 0 10px">This FMS feeds the company reports with its steps, on-time rate and pending forms.</p>' +
      '<button class="btn block" id="fmsReport">' + UI.icon('chart', 14) + ' Open FMS report</button>' +
      '<button class="btn block mt8" id="fmsForms">' + UI.icon('clipboard', 14) + ' Pending forms for this FMS</button></div></div>' +
      '</div></div>';

    el.querySelectorAll('[data-task]').forEach(r => r.onclick = () => { App.state.taskFocus = Number(r.dataset.task); App.navigate('/tasks'); });
    el.querySelector('#fmsOpen').onclick = () => openFms(id);
    const ed = el.querySelector('#fmsEdit'); if (ed) ed.onclick = () => fmsModal(F);
    el.querySelector('#fmsTasks').onclick = () => { App.state.taskFms = id; App.navigate('/tasks'); };
    el.querySelector('#fmsReport').onclick = () => { App.state.reportFms = id; App.navigate('/reports'); };
    el.querySelector('#fmsForms').onclick = () => { App.state.formFms = id; App.navigate('/forms'); };
    const gf = el.querySelector('[data-gotoforms]'); if (gf) gf.onclick = () => App.navigate('/forms');
  }

  function openFms(id) {
    const f = (cache.rows || []).find(x => Number(x.id) === Number(id));
    const row = f || null;
    if (!row) {
      window.agentdb.executeQuery('fms_detail', { id: id }).then(r => {
        cache.rows = cache.rows || [];
        if (r.rows.length) { cache.rows.push(r.rows[0]); openFms(id); }
      });
      return;
    }
    if (!row.dashboard_url) {
      UI.modal({
        title: 'Open ' + row.name,
        body: '<div class="banner warn">' + UI.icon('alert', 15) + '<div><b>No live dashboard URL is attached to this FMS yet.</b><br>Until one is configured, the FMS runs inside SmartiQo: steps, SLA, forms and reports are all tracked here.</div></div>' +
          '<p class="small">Admins can attach the FMS dashboard, Google Sheet and form URLs from <b>Configure</b>.</p>',
        foot: (Auth.isAdmin() ? '<button class="btn primary" id="cfgNow">Configure FMS</button>' : '') + '<button class="btn" data-close>Close</button>',
        onMount: (bg, close) => {
          const c = bg.querySelector('#cfgNow');
          if (c) c.onclick = () => { close(); App.navigate('/fms/' + row.id); setTimeout(() => fmsModal(row), 260); };
        }
      });
      return;
    }
    const body = '<div class="banner info">' + UI.icon('external', 15) + '<div>The live FMS opens below. Some providers (Google Workspace, many SaaS tools) block embedding — if the panel is blank, use <b>Open in new tab</b>.</div></div>' +
      '<div style="margin-bottom:10px"><a class="btn sm primary" href="' + UI.esc(row.dashboard_url) + '" target="_blank" rel="noopener">' + UI.icon('external', 13) + ' Open in new tab</a></div>' +
      '<iframe src="' + UI.esc(row.dashboard_url) + '" style="width:100%;height:58vh;border:1px solid var(--line);border-radius:10px;background:#fff" referrerpolicy="no-referrer"></iframe>';
    UI.modal({ title: row.name, size: 'xl', body: body, foot: '<button class="btn" data-close>Close</button>' });
  }

  async function fmsModal(F) {
    const depts = await window.agentdb.executeQuery('load_departments', {});
    const people = await window.agentdb.executeQuery('load_people', { department_id: 0, role: '' });
    const m = UI.modal({
      title: F ? 'Configure ' + F.name : 'Add FMS',
      size: 'wide',
      body: '<div class="form-grid">' +
        '<div class="field full"><label>FMS name *</label><input class="input" id="fName" value="' + UI.esc(F ? F.name : '') + '" placeholder="e.g. Quality Audit FMS"></div>' +
        '<div class="field"><label>FMS code</label><input class="input" id="fCode" value="' + UI.esc(F ? F.code || '' : '') + '" placeholder="QAF" maxlength="8"></div>' +
        '<div class="field"><label>Category</label><input class="input" id="fCat" value="' + UI.esc(F ? F.category || '' : '') + '" placeholder="Field Operations"></div>' +
        '<div class="field"><label>Department</label><select class="select" id="fDept"><option value="0">Unassigned</option>' +
        depts.rows.map(d => '<option value="' + d.id + '"' + (F && F.department_id === d.id ? ' selected' : '') + '>' + UI.esc(d.name) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>Department head / owner</label><select class="select" id="fOwner"><option value="0">Not assigned</option>' +
        people.rows.filter(p => p.role !== 'employee').map(p => '<option value="' + p.id + '"' + (F && F.owner_user_id === p.id ? ' selected' : '') + '>' + UI.esc(p.full_name) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label>SLA (hours)</label><input class="input" id="fSla" type="number" min="1" value="' + (F ? F.sla_hours : 24) + '"></div>' +
        '<div class="field"><label>Process start date</label><input class="input" id="fStart" type="date" value="' + (F && F.start_date ? String(F.start_date).slice(0, 10) : UI.todayISO(0)) + '"></div>' +
        '<div class="field full"><label>Dashboard URL</label><input class="input" id="fUrl" value="' + UI.esc(F ? F.dashboard_url || '' : '') + '" placeholder="https://your-fms-dashboard"></div>' +
        '<div class="field"><label>Google Sheet URL</label><input class="input" id="fSheet" value="' + UI.esc(F ? F.sheet_url || '' : '') + '" placeholder="https://docs.google.com/spreadsheets/…"></div>' +
        '<div class="field"><label>Form URLs (comma separated)</label><input class="input" id="fForms" value="' + UI.esc(F ? F.form_urls || '' : '') + '" placeholder="https://forms.gle/…"></div>' +
        '<div class="field full"><label>Description</label><textarea class="textarea" id="fDesc">' + UI.esc(F ? F.description || '' : '') + '</textarea></div>' +
        '<div class="field"><label>Status</label><select class="select" id="fStatus"><option value="active"' + (!F || F.status === 'active' ? ' selected' : '') + '>Active</option><option value="inactive"' + (F && F.status === 'inactive' ? ' selected' : '') + '>Inactive</option></select></div>' +
        '<div class="field"><label>Embedding</label><select class="select" id="fEmbed"><option value="false">Open in new tab</option><option value="true"' + (F && F.embeddable ? ' selected' : '') + '>Allow embedded view</option></select></div>' +
        '</div>' + (F ? '<div class="drop-sep" style="margin:14px 0"></div><div class="flex gap8"><button class="btn danger sm" id="fDel">' + UI.icon('trash', 13) + ' Delete FMS</button>' +
          '<button class="btn sm" id="fTask">' + UI.icon('plus', 13) + ' Add step</button><button class="btn sm" id="fForm">' + UI.icon('clipboard', 13) + ' Add form</button></div>' : ''),
      foot: '<button class="btn" data-close>Cancel</button><button class="btn primary" id="fSave">Save FMS</button>',
      onMount: (bg, close) => {
        bg.querySelector('#fSave').onclick = async () => {
          const name = bg.querySelector('#fName').value.trim();
          if (!name) { UI.toast('FMS name is required', 'bad'); return; }
          const p = {
            name: name, code: bg.querySelector('#fCode').value.trim(), description: bg.querySelector('#fDesc').value,
            department_id: Number(bg.querySelector('#fDept').value) || 0,
            dashboard_url: bg.querySelector('#fUrl').value.trim(), sheet_url: bg.querySelector('#fSheet').value.trim(),
            form_urls: bg.querySelector('#fForms').value.trim(),
            owner_user_id: Number(bg.querySelector('#fOwner').value) || 0,
            start_date: bg.querySelector('#fStart').value, sla_hours: Number(bg.querySelector('#fSla').value) || 24,
            category: bg.querySelector('#fCat').value.trim(), status: bg.querySelector('#fStatus').value,
            embeddable: bg.querySelector('#fEmbed').value === 'true'
          };
          try {
            let id = F ? F.id : null;
            if (F) await window.agentdb.executeQuery('update_fms', Object.assign({ id: F.id }, p));
            else { const r = await window.agentdb.executeQuery('create_fms', p); id = r.rows[0].id; }
            if (p.department_id) { try { await window.agentdb.executeQuery('link_fms_department', { fms_id: id, department_id: p.department_id }); } catch (e) { } }
            await window.PAGES.departments.audit(F ? 'FMS updated' : 'FMS created', 'fms', String(id), name);
            close(); UI.toast('FMS saved', 'ok'); App.rerender();
          } catch (e) { UI.toast(e.message, 'bad'); }
        };
        const del = bg.querySelector('#fDel');
        if (del) del.onclick = async () => {
          const ok = await UI.confirmAction('Delete “' + F.name + '” and all of its steps? This cannot be undone.', { danger: true, confirmLabel: 'Delete FMS' });
          if (!ok) return;
          try { await window.agentdb.executeQuery('delete_fms', { id: F.id }); close(); UI.toast('FMS deleted', 'ok'); App.navigate('/fms'); App.rerender(); }
          catch (e) { UI.toast(e.message, 'bad'); }
        };
        const ft = bg.querySelector('#fTask');
        if (ft) ft.onclick = () => { close(); window.PAGES.tasks.openCreate(F.id); };
        const ff = bg.querySelector('#fForm');
        if (ff) ff.onclick = () => { close(); App.navigate('/forms'); App.state.formFms = F.id; };
      }
    });
    return m;
  }

  return { render, fmsModal, openFms };
})();
