/* SmartiQo · authentication + login screen */
const Auth = (function () {
  let memorySession = null;

  function sha256Hex(str) {
    var K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
      0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
      0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
      0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
      0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
      0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
      0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
      0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
    var H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
    var bytes = new TextEncoder().encode(str), l = bytes.length;
    var buf = new Uint8Array(((((l + 8) >> 6) + 1) << 6));
    buf.set(bytes); buf[l] = 0x80;
    var dv = new DataView(buf.buffer), bitLen = l * 8;
    dv.setUint32(buf.length - 8, Math.floor(bitLen / 4294967296));
    dv.setUint32(buf.length - 4, bitLen >>> 0);
    var w = new Int32Array(64);
    function rr(x, n) { return (x >>> n) | (x << (32 - n)); }
    for (var off = 0; off < buf.length; off += 64) {
      for (var i = 0; i < 16; i++) w[i] = dv.getInt32(off + i * 4);
      for (i = 16; i < 64; i++) {
        var s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        var s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (i = 0; i < 64; i++) {
        var S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25);
        var ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + K[i] + w[i]) | 0;
        var S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22);
        var maj = (a & b) ^ (a & c) ^ (b & c);
        var t2 = (S0 + maj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    return H.map(function (x) { return ('00000000' + (x >>> 0).toString(16)).slice(-8); }).join('');
  }

  // Permissions can arrive as a jsonb array, a JSON string or a comma list.
  function permList(v) {
    if (Array.isArray(v)) return v.map(String).filter(Boolean);
    if (typeof v === 'string') {
      const t = v.trim();
      if (!t) return [];
      try {
        const p = JSON.parse(t);
        if (Array.isArray(p)) return p.map(String).filter(Boolean);
      } catch (e) { /* not JSON — treat as a comma list */ }
      return t.split(',').map(x => x.trim()).filter(Boolean);
    }
    return [];
  }

  function setSession(u, remember) {
    if (u) u.permissions = permList(u.permissions);
    memorySession = u;
    try {
      if (remember) window.sessionStorage.setItem('sq_user', JSON.stringify(u));
      else window.sessionStorage.removeItem('sq_user');
    } catch (e) { /* storage unavailable — in-memory session only */ }
  }
  function getSession() {
    if (memorySession) return memorySession;
    try {
      const raw = window.sessionStorage.getItem('sq_user');
      if (raw) {
        memorySession = JSON.parse(raw);
        if (memorySession) memorySession.permissions = permList(memorySession.permissions);
      }
    } catch (e) { /* ignore */ }
    return memorySession;
  }
  function clear() {
    memorySession = null;
    try { window.sessionStorage.removeItem('sq_user'); } catch (e) { }
  }
  function user() { return getSession(); }
  function role() { const u = user(); return u ? u.role : null; }
  function isAdmin() { return role() === 'admin'; }
  function scope() {
    const u = user();
    if (!u) return { dept: 0, uid: 0 };
    if (u.role === 'admin') return { dept: 0, uid: 0 };
    if (u.role === 'department_head') return { dept: u.department_id || 0, uid: 0 };
    return { dept: 0, uid: u.id };
  }
  // Modules a person may open. Admin sees everything; an empty list means the
  // role default; a non-empty list is an explicit allow-list set by an admin.
  const MODULES = ['overview', 'departments', 'fms', 'tasks', 'site-visits', 'service-visits', 'forms', 'documents', 'reports', 'tools', 'notifications'];

  function allowed(route) {
    const u = user();
    if (!u) return false;
    if (u.role === 'admin') return true;
    if (route === 'settings') return false;
    const perms = (u.permissions || []).filter(Boolean);
    if (perms.length) return perms.indexOf(route) >= 0;
    const roleDefaults = {
      department_head: ['overview', 'departments', 'fms', 'tasks', 'site-visits', 'service-visits', 'forms', 'documents', 'reports', 'tools', 'notifications'],
      employee: ['overview', 'tasks', 'site-visits', 'service-visits', 'forms', 'documents', 'notifications']
    };
    return (roleDefaults[u.role] || roleDefaults.employee).indexOf(route) >= 0;
  }
  function firstRoute() {
    const list = user() && user().role === 'admin' ? ['overview'] : MODULES.filter(allowed);
    return list[0] || 'notifications';
  }
  function viewOnly() { const u = user(); return !!(u && u.view_only) && u.role !== 'admin'; }
  function canEdit() { return !viewOnly(); }

  function can(perm) {
    const r = role();
    if (r === 'admin') return true;
    if (r === 'department_head') return ['dept.view', 'task.view', 'task.update', 'visit.manage', 'report.view', 'document.view', 'form.view', 'form.submit'].indexOf(perm) >= 0;
    return ['task.view_own', 'task.update_own', 'form.submit', 'document.view', 'visit.view_own'].indexOf(perm) >= 0;
  }

  async function login(email, password) {
    const r = await window.agentdb.executeQuery('auth_login', { email: email.trim() });
    if (!r.rows.length) return { error: 'No account found for that email address.' };
    const u = r.rows[0];
    if (!u.is_active) return { error: 'This account has been deactivated. Contact your administrator.' };
    const hash = sha256Hex(password);
    if (hash !== u.password_hash) return { error: 'Incorrect password. Please try again.' };
    const perms = permList(u.permissions);
    const session = {
      id: u.id, name: u.full_name, email: u.email, role: u.role,
      department_id: u.department_id, designation: u.designation, color: u.avatar_color,
      permissions: perms.map(String), view_only: !!u.view_only
    };
    return { user: session };
  }

  const SHIELD_LOCK = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9.2 12.2V10a2.8 2.8 0 0 1 5.6 0v2.2"/><rect x="8.2" y="12.2" width="7.6" height="5" rx="1.2"/></svg>';
  const SHIELD_CHECK = (sz) => '<svg width="' + (sz || 15) + '" height="' + (sz || 15) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M8.8 11.8l2.2 2.2 4.2-4.4"/></svg>';

  const SKYLINE = '<svg class="auth-sky" viewBox="0 0 640 140" preserveAspectRatio="none" aria-hidden="true" fill="#E8EEF8"><path d="M0 140V96h18V72h26v24h14V58h30v38h18V80h22v16h16V64h28v32h20V88h18v-8h24v20h14V54h30v46h18V76h26v24h16V62h28v34h20v-6h18v12h20V70h26v26h18V84h22v16h12v40z"/><path d="M0 140v-16h34v-10h28v10h26v-8h30v8h24v-12h28v12h26v-6h30v6h22v-10h26v10h34v-8h28v8h26v-6h30v6h20v-8h26v8h30z" fill="#DFE8F5"/></svg>';

  function mockHtml() {
    const nav = [['grid', 'Dashboard', 1], ['layers', 'FMS Management', 0], ['building', 'Departments', 0],
      ['pin', 'Site Visits', 0], ['wrench', 'Service Visits', 0], ['chart', 'Reports', 0],
      ['folder', 'Forms & Documents', 0], ['gear', 'Settings', 0]];
    return '<div class="mock">' +
      '<div class="mock-side"><div class="mock-logo">Smarti<b>Qo</b></div>' +
      nav.map(n => '<div class="mock-nav' + (n[2] ? ' on' : '') + '">' + UI.icon(n[0], 11) + '<span>' + n[1] + '</span></div>').join('') +
      '</div>' +
      '<div class="mock-main">' +
      '<div class="mock-top"><div class="mock-search">' + UI.icon('search', 11) + '<span>Search here…</span></div>' +
      '<div class="mock-on"><span style="width:5px;height:5px;border-radius:50%;background:#0E9F6E;display:block"></span>Online</div>' +
      UI.icon('bell', 12) + '<div class="mock-ava">AD</div></div>' +
      '<div class="mock-kpis" id="mockKpis"></div>' +
      '<div class="mock-grid">' +
      '<div class="mock-card"><h5>Completion rate</h5><div class="donut" id="mockDonut"><b id="mockRate">—</b></div><div class="donut-cap">of all FMS steps</div></div>' +
      '<div class="mock-card"><h5>FMS completion trend</h5>' +
      '<svg class="mock-spark" id="mockSpark" viewBox="0 0 200 74" preserveAspectRatio="none" aria-hidden="true"></svg>' +
      '<div style="font-size:7px;color:#8496AE;display:flex;gap:9px;margin-top:2px"><span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:2px;background:#1D6BF3;display:block"></span>Created</span><span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:2px;background:#0E9F6E;display:block"></span>Completed</span></div>' +
      '</div></div>' +
      '<div class="mock-card"><h5>Department performance</h5><div class="mock-bars" id="mockBars"></div></div>' +
      '</div></div>';
  }


  /* ---- animated management wallpaper behind the login (canvas) ----
     Grid drift + process nodes/links + travelling signals + floating task
     cards + a live mini bar chart. Stops as soon as the login unmounts and
     renders a single static frame when the user prefers reduced motion. */
  function mountWallpaper() {
    const cv = document.getElementById('authWall');
    if (!cv || !cv.getContext) return;
    const ctx = cv.getContext('2d');
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let W = 0, H = 0, raf = 0, last = 0;
    let nodes = [], cards = [], bars = [], sigs = [];
    const rnd = (a, b) => a + Math.random() * (b - a);

    function rr(x, y, w, h, r) {
      r = Math.min(r, w / 2, h / 2);
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + w, y, x + w, y + h, r);
      ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r);
      ctx.arcTo(x, y, x + w, y, r);
      ctx.closePath();
    }

    function seed() {
      const n = Math.max(9, Math.min(34, Math.round(W * H / 30000)));
      nodes = [];
      for (let i = 0; i < n; i++) {
        nodes.push({ x: rnd(0.06, 0.94) * W, y: rnd(0.08, 0.92) * H, r: rnd(2, 3.8),
          ph: rnd(0, 6.28), sp: rnd(0.3, 0.7), vx: rnd(-9, 9), vy: rnd(-7, 7) });
      }
      cards = [];
      const cn = Math.max(3, Math.min(7, Math.round(W / 190)));
      for (let i = 0; i < cn; i++) {
        cards.push({ x: rnd(0.05, 0.8) * W, y: rnd(0, 1) * H, w: rnd(66, 100),
          h: rnd(30, 42), sp: rnd(7, 15), a: rnd(0.06, 0.13), p: rnd(0.35, 0.95) });
      }
      bars = [];
      const gap = Math.max(20, W / 34);
      for (let x = 14; x < W - 14; x += gap) {
        bars.push({ x: x, ph: rnd(0, 6.28), sp: rnd(0.5, 1.1) });
      }
      sigs = [];
      for (let i = 0; i < 5; i++) {
        sigs.push({ a: Math.floor(Math.random() * nodes.length), b: Math.floor(Math.random() * nodes.length), t: rnd(0, 1), sp: rnd(0.12, 0.3) });
      }
    }

    function draw(t, dt) {
      if (!W || !H) return;
      ctx.clearRect(0, 0, W, H);

      // 1 — drifting process grid
      const gap = 48, off = (t * 7) % gap;
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(120,170,255,0.06)';
      ctx.beginPath();
      for (let x = -gap + off; x < W + gap; x += gap) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
      for (let y = -gap + off; y < H + gap; y += gap) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
      ctx.stroke();

      // 2 — nodes drift
      for (const n of nodes) {
        n.x += n.vx * dt; n.y += n.vy * dt;
        if (n.x < W * 0.04 || n.x > W * 0.96) n.vx *= -1;
        if (n.y < H * 0.05 || n.y > H * 0.95) n.vy *= -1;
        n.ph += dt * n.sp;
      }

      // 3 — process links
      const maxD = Math.max(120, Math.min(190, W / 5));
      ctx.lineWidth = 0.9;
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j];
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          if (d < maxD) {
            ctx.strokeStyle = 'rgba(90,160,255,' + ((1 - d / maxD) * 0.24).toFixed(3) + ')';
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
      }

      // 4 — step markers
      for (const n of nodes) {
        const p = 0.5 + 0.5 * Math.sin(n.ph);
        const r = n.r * (1 + 0.22 * p);
        ctx.fillStyle = 'rgba(56,189,248,' + (0.09 + 0.1 * p).toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(n.x, n.y, r * 4.2, 0, 6.283); ctx.fill();
        ctx.fillStyle = 'rgba(226,240,255,' + (0.5 + 0.3 * p).toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, 6.283); ctx.fill();
      }

      // 5 — signals travelling along the process
      for (const s of sigs) {
        s.t += dt * s.sp;
        if (s.t >= 1 || !nodes[s.a] || !nodes[s.b] || s.a === s.b) {
          s.a = Math.floor(Math.random() * nodes.length);
          s.b = Math.floor(Math.random() * nodes.length);
          s.t = 0; s.sp = rnd(0.12, 0.3);
          continue;
        }
        const A = nodes[s.a], B = nodes[s.b];
        const x = A.x + (B.x - A.x) * s.t, y = A.y + (B.y - A.y) * s.t;
        const g = ctx.createRadialGradient(x, y, 0, x, y, 9);
        g.addColorStop(0, 'rgba(200,242,255,.85)');
        g.addColorStop(1, 'rgba(56,189,248,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, y, 9, 0, 6.283); ctx.fill();
      }

      // 6 — floating task cards with progress
      for (const c of cards) {
        c.y -= c.sp * dt;
        if (c.y + c.h < -12) { c.y = H + 12; c.x = rnd(0.05, 0.8) * W; c.p = rnd(0.3, 0.95); }
        ctx.fillStyle = 'rgba(15,40,86,' + c.a.toFixed(3) + ')';
        rr(c.x, c.y, c.w, c.h, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(140,190,255,.17)'; ctx.lineWidth = 1;
        rr(c.x + 0.5, c.y + 0.5, c.w - 1, c.h - 1, 7); ctx.stroke();
        ctx.fillStyle = 'rgba(170,205,255,.26)';
        ctx.fillRect(c.x + 9, c.y + 8, c.w * 0.42, 3);
        ctx.fillStyle = 'rgba(255,255,255,.09)';
        ctx.fillRect(c.x + 9, c.y + c.h - 14, c.w - 18, 4);
        ctx.fillStyle = 'rgba(56,189,248,.6)';
        ctx.fillRect(c.x + 9, c.y + c.h - 14, (c.w - 18) * c.p, 4);
      }

      // 7 — live bar chart along the bottom
      const base = H - 20;
      for (const b of bars) {
        b.ph += dt * b.sp;
        const hh = 12 + 40 * (0.5 + 0.5 * Math.sin(b.ph));
        const g2 = ctx.createLinearGradient(0, base - hh, 0, base);
        g2.addColorStop(0, 'rgba(56,189,248,.34)');
        g2.addColorStop(1, 'rgba(56,189,248,.02)');
        ctx.fillStyle = g2;
        rr(b.x, base - hh, 8, hh, 2); ctx.fill();
      }
    }

    function frame(now) {
      if (!document.body.contains(cv)) { raf = 0; return; }
      const t = now / 1000;
      const dt = Math.min(0.06, last ? t - last : 0.016);
      last = t;
      draw(t, dt);
      raf = requestAnimationFrame(frame);
    }

    function resize() {
      if (!document.body.contains(cv)) return;
      const r = cv.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(1, Math.round(r.width)), h = Math.max(1, Math.round(r.height));
      if (w === W && h === H) return;
      W = w; H = h;
      cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      seed();
      // Paint straight away: resizing a canvas wipes it, and a throttled or
      // hidden frame may not give us another animation callback for a while.
      draw(performance.now() / 1000, 0);
    }

    resize();
    window.addEventListener('resize', resize);
    draw(performance.now() / 1000, 0);
    if (!reduce) { cancelAnimationFrame(raf); raf = requestAnimationFrame(frame); }
  }

  function renderLogin(el, onSuccess) {
    el.innerHTML =
      '<div class="auth-shell">' +
      '<section class="auth-left">' + SKYLINE +
      '<div class="auth-inner">' +
      '<div class="auth-logo">Smarti<span>Qo</span><sup>®</sup></div>' +
      '<div class="auth-card">' +
      '<h1>Welcome to <em>SmartiQo</em></h1>' +
      '<div class="auth-sub">Centralized Process Management System</div>' +
      '<div class="login-err" id="loginErr"></div>' +
      '<form id="loginForm" autocomplete="on" novalidate>' +
      '<div class="afield"><span class="afi">' + UI.icon('mail', 17) + '</span>' +
      '<input id="liEmail" name="email" type="text" autocomplete="username" placeholder="Email / Username" spellcheck="false" required></div>' +
      '<div class="afield"><span class="afi">' + UI.icon('lock', 17) + '</span>' +
      '<input id="liPass" name="password" type="password" autocomplete="current-password" placeholder="Password" required>' +
      '<button type="button" class="pw-eye" id="pwToggle" aria-label="Show password">' + UI.icon('eye', 16) + '</button></div>' +
      '<div class="arow"><label class="acheck"><input type="checkbox" name="remember" checked><span class="box">' + UI.icon('check', 11) + '</span>Remember Me</label>' +
      '<a id="forgotLink" role="button" tabindex="0">Forgot Password?</a></div>' +
      '<button class="abtn" type="submit" id="loginBtn">' + SHIELD_LOCK + ' Secure Login</button>' +
      '</form>' +
      '<div class="asec">' + SHIELD_CHECK(15) + ' Secure Enterprise Access</div>' +
      '<div class="ameta"><span>' + UI.icon('user', 12) + ' Role-Based Access</span><i></i><span>' + UI.icon('lock', 12) + ' Session Management</span></div>' +
      '</div></div>' +
      '<div class="auth-foot">SmartiQo © 2026. All rights reserved.</div>' +
      '</section>' +
      '<section class="auth-right" aria-hidden="true">' +
      '<canvas id="authWall"></canvas>' +
      '<svg class="awave" viewBox="0 0 120 900" preserveAspectRatio="none"><path d="M0 0h34c26 96 12 214 40 330 26 108 2 244-26 340-14 48-22 92-24 230H0z" fill="#0C3576" opacity=".5"/><path d="M0 0h14c20 120 6 236 26 348 18 102 2 226-20 322-12 52-16 92-18 230H0z" fill="#1D6BF3" opacity=".18"/></svg>' +
      '<div class="auth-pill"><span class="ok">' + SHIELD_CHECK(12) + '</span> Secure Enterprise Access</div>' +
      '<div class="auth-mock">' + mockHtml() + '</div>' +
      '</section></div>';

    mountWallpaper();

    const form = document.getElementById('loginForm');
    const errEl = document.getElementById('loginErr');
    const btn = document.getElementById('loginBtn');
    const pass = document.getElementById('liPass');
    const btnHtml = btn.innerHTML;

    document.getElementById('pwToggle').onclick = function () {
      const show = pass.type === 'password';
      pass.type = show ? 'text' : 'password';
      this.innerHTML = UI.icon(show ? 'eyeOff' : 'eye', 16);
      this.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    };
    document.getElementById('forgotLink').onclick = (e) => {
      e.preventDefault();
      UI.modal({
        title: 'Reset your password',
        body: '<p style="font-size:12.8px;color:var(--text-2);line-height:1.6">Password changes are handled by a SmartiQo administrator so that audit history stays intact.</p>' +
          '<div class="banner info" style="margin:14px 0 0">' + UI.icon('mail', 15) + '<div>Ask your admin to reset it from <b>Admin Settings → People</b>, or write to <b>admin@smartiqo.com</b>.</div></div>'
      });
    };

    form.onsubmit = async function (ev) {
      ev.preventDefault();
      errEl.style.display = 'none';
      const email = form.email.value.trim(), password = form.password.value;
      if (!email || !password) { showErr('Enter your email and password.'); return; }
      btn.disabled = true; btn.textContent = 'Signing in…';
      try {
        const res = await login(email, password);
        if (res.error) { showErr(res.error); return; }
        setSession(res.user, form.remember.checked);
        try { await window.agentdb.executeQuery('auth_touch', { id: res.user.id }); } catch (e) { }
        onSuccess(res.user);
      } catch (e) {
        showErr('Sign-in failed: ' + e.message);
      } finally {
        btn.disabled = false; btn.innerHTML = btnHtml;
      }
    };
    function showErr(m) { errEl.textContent = m; errEl.style.display = 'block'; }

    // Live preview: real counts, so the panel is not decoration.
    (async function () {
      try {
        const [k, dp, tr] = await Promise.all([
          window.agentdb.executeQuery('login_preview', {}),
          window.agentdb.executeQuery('login_preview_depts', {}),
          window.agentdb.executeQuery('login_trend', {})
        ]);
        const r = k.rows[0] || {};
        const tiles = [
          ['Total Departments', r.departments, 0], ['Active FMS', r.active_fms, 0],
          ['FMS Tasks', r.total_tasks, 0], ['Completed Tasks', r.completed_tasks, 0],
          ['Pending Tasks', r.pending_tasks, 0], ['Overdue Tasks', r.overdue_tasks, 1],
          ["Today's Site Visits", r.site_visits, 0], ["Today's Service Visits", r.service_visits, 0]
        ];
        const g = document.getElementById('mockKpis');
        if (g) g.innerHTML = tiles.map(t => '<div class="mock-k"><div class="l">' + t[0] + '</div><div class="v' + (t[2] && t[1] > 0 ? ' red' : '') + '">' + UI.n(t[1]) + '</div></div>').join('');

        const total = Number(r.total_tasks) || 0, done = Number(r.completed_tasks) || 0;
        const p = total ? Math.round(done / total * 100) : 0;
        const donut = document.getElementById('mockDonut'), rate = document.getElementById('mockRate');
        if (donut) donut.style.background = 'conic-gradient(#1D6BF3 0 ' + p + '%, #E8EEF7 ' + p + '% 100%)';
        if (rate) rate.textContent = p + '%';

        const days = tr.rows || [];
        const spark = document.getElementById('mockSpark');
        if (spark && days.length) {
          const max = Math.max(1, ...days.map(d => Math.max(Number(d.created), Number(d.completed))));
          const line = (key, color) => {
            const pts = days.map((d, i) => {
              const x = (i / Math.max(1, days.length - 1)) * 196 + 2;
              const y = 70 - (Number(d[key]) / max) * 62;
              return x.toFixed(1) + ',' + y.toFixed(1);
            }).join(' ');
            return '<polyline points="' + pts + '" fill="none" stroke="' + color + '" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round" opacity=".95"/>';
          };
          spark.innerHTML = line('created', '#1D6BF3') + line('completed', '#0E9F6E');
        }

        const bars = document.getElementById('mockBars');
        if (bars && dp.rows.length) {
          bars.innerHTML = dp.rows.slice(0, 5).map(d => {
            const pc = UI.pct(d.completed, d.total_tasks);
            return '<div class="mock-bar"><span>' + UI.esc(d.name) + '</span><i><b style="width:' + pc + '%"></b></i><span>' + pc + '%</span></div>';
          }).join('');
        }
      } catch (e) {
        console.warn('[login preview]', e.message);
      }
    })();
  }

  return { renderLogin, login, setSession, getSession, clear, user, role, isAdmin, scope, can, allowed, firstRoute, viewOnly, canEdit, MODULES, hash: sha256Hex };
})();
