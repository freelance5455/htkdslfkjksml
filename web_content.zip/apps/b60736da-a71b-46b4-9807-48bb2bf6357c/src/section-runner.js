// Section runner, seeded by AgentBase: it runs SECTIONS from sections/main.js.
// Keep this file as it is and its <script> tag after main.js.
(function () {
  'use strict';
  // A page with its own init() runs everything itself; a section the page
  // passed to gsDash.loadSections is the kit's to run and refresh.
  function pageHasInit() {
    return typeof init === 'function';
  }
  function kitOwns(section, el) {
    const owns = window.gsDash?.loadSections?.owns;
    return typeof owns === 'function' && owns(section, el) === true;
  }

  function sections() {
    return typeof SECTIONS !== 'undefined' && Array.isArray(SECTIONS) ? SECTIONS : [];
  }
  function byId(id) {
    return document.getElementById(id);
  }

  function showError(msg) {
    const loading = byId('loading');
    if (loading) loading.hidden = true;
    const errEl = byId('error');
    if (!errEl) return;
    errEl.replaceChildren();
    const text = document.createElement('div');
    text.textContent = 'Error: ' + msg;
    const btn = document.createElement('button');
    btn.textContent = 'Retry';
    btn.onclick = () => {
      errEl.hidden = true;
      if (loading) loading.hidden = false;
      if (pageHasInit()) init();
      else run();
    };
    errEl.append(text, btn);
    errEl.hidden = false;
  }

  function showContent() {
    const loading = byId('loading');
    const errEl = byId('error');
    const content = byId('content');
    if (loading) loading.hidden = true;
    if (errEl) errEl.hidden = true;
    if (content) content.hidden = false;
  }

  // Before any stand-down: a page's own init() may call these.
  if (typeof window.showError !== 'function') window.showError = showError;
  if (typeof window.showContent !== 'function') window.showContent = showContent;
  if (pageHasInit()) return;

  // Render a section in place of what its previous render added, so a
  // refresh never stacks a second copy (gsDash.section and appendChild
  // append). Only that section's own output is swapped: the container's
  // markup, its live controls and other sections sharing it stay put.
  function renderSection(section, result, el) {
    const old = (section.added || []).filter((node) => node.parentNode === el);
    const next = old.length ? old[old.length - 1].nextSibling : null;
    old.forEach((node) => node.remove());
    const before = new Set(el.childNodes);
    section.render(result, el);
    section.added = Array.from(el.childNodes).filter((node) => !before.has(node));
    if (next && next.parentNode === el) section.added.forEach((node) => el.insertBefore(node, next));
  }

  // Query -> render -> yield to the browser -> next. Rendering every
  // section in a single pass freezes the view for the whole page, and
  // making the fetches serial does not fix that: the giant render is.
  async function run() {
    if (pageHasInit()) return;
    console.log('[init] starting');
    try {
      for (const section of sections()) {
        const el = document.querySelector(section.el);
        if (!el || kitOwns(section, el)) continue;
        const result = section.queryName
          ? await window.agentdb.executeQuery(section.queryName, section.params || {})
          : null;
        renderSection(section, result, el);
        // Reveal THIS section's own container. Every container in the shell
        // starts `hidden`, so a view that adds one per section would render
        // into elements nobody ever unhides. showContent() drops the
        // spinner as soon as the first section is up.
        el.hidden = false;
        showContent();
        console.log('[render]', section.el, result ? result.row_count + ' rows' : 'no query');
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
      // Also when SECTIONS is still empty, so a freshly seeded view does
      // not sit on 'Loading...' forever.
      showContent();
      console.log('[init] done');
    } catch (e) {
      console.error('[error]', e.message);
      window.showError(e.message);
    }
  }

  // Kit blocks (editTable, form, cardList, kanban, importer) announce every
  // saved add / edit / delete as gsdash:data-changed. Re-run the query
  // sections (cards, charts, summaries) so they follow without a reload.
  // Mount-only sections hold blocks that follow writes themselves; a section
  // with unsaved edits catches up on the next write. One pass at a time: a
  // write during a pass queues one more, so old totals never land last.
  let refreshing = false;
  let refreshAgain = false;
  async function refreshSections() {
    do {
      refreshAgain = false;
      const all = sections();
      for (const section of all) {
        const el = document.querySelector(section.el);
        if (!el || !section.queryName || kitOwns(section, el)) continue;
        if (window.gsDash.hasEdits?.(el)) continue;
        // Another section mounted inside this one's output would go with it.
        const holdsOther = all.some((other) => {
          const o = other !== section && document.querySelector(other.el);
          return o && (section.added || []).some((node) => node.contains(o));
        });
        if (holdsOther) continue;
        try {
          const result = await window.agentdb.executeQuery(section.queryName, section.params || {});
          // The user started editing in it while the query ran: keep that.
          if (window.gsDash.hasEdits?.(el)) continue;
          renderSection(section, result, el);
          console.log('[render] refreshed', section.el);
        } catch (e) {
          console.error('[error]', e.message);
        }
      }
    } while (refreshAgain);
    refreshing = false;
  }
  window.gsDash?.onDataChanged?.(() => {
    if (pageHasInit()) return;
    if (refreshing) { refreshAgain = true; return; }
    refreshing = true;
    setTimeout(refreshSections, 0);
  });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
})();
