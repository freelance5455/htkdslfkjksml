export default {

    create() {

        const content =
            document.createElement("div");

        content.style.cssText = `
            width:100%;
            height:100%;
            display:flex;
            flex-direction:column;
            background:#0b0b10;
        `;

        content.innerHTML = `

            <div style="
                height:50px;
                min-height:50px;
                display:flex;
                align-items:center;
                gap:7px;
                padding:0 10px;
                background:rgba(255,255,255,.04);
            ">

                <button id="back">←</button>

                <button id="forward">→</button>

                <button id="reload">↻</button>

                <input
                    id="url"
                    value="https://example.com"
                    style="
                        flex:1;
                        min-width:0;
                        padding:9px 13px;
                        border:1px solid rgba(255,255,255,.08);
                        border-radius:11px;
                        background:rgba(255,255,255,.06);
                        color:white;
                        outline:none;
                    "
                >

                <button id="go">
                    Go
                </button>

            </div>

            <iframe
                id="browserFrame"
                style="
                    flex:1;
                    width:100%;
                    border:0;
                    background:white;
                "
                sandbox="
                    allow-forms
                    allow-modals
                    allow-popups
                    allow-presentation
                    allow-same-origin
                    allow-scripts
                    allow-downloads
                "
            ></iframe>
        `;

        const frame =
            content.querySelector(
                "#browserFrame"
            );

        const input =
            content.querySelector("#url");

        const navigate =
            () => {

                let url =
                    input.value.trim();

                if (!url) return;

                if (
                    !/^https?:\/\//i.test(url)
                ) {

                    url =
                        "https://" + url;

                }

                input.value = url;

                frame.src = url;

            };

        content
            .querySelector("#go")
            .addEventListener(
                "click",
                navigate
            );

        input.addEventListener(
            "keydown",
            event => {

                if (event.key === "Enter") {
                    navigate();
                }

            }
        );

        content
            .querySelector("#reload")
            .addEventListener(
                "click",
                () => frame.contentWindow.location.reload()
            );

        content
            .querySelector("#back")
            .addEventListener(
                "click",
                () => frame.contentWindow.history.back()
            );

        content
            .querySelector("#forward")
            .addEventListener(
                "click",
                () => frame.contentWindow.history.forward()
            );

        setTimeout(
            navigate,
            100
        );

        return WindowManager.create({

            appId: "browser",

            title: "Nexora Browser",

            icon: "◎",

            width: 900,

            height: 600,

            content

        });

    }

};