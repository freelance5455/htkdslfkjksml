export default {

    create() {

        return WindowManager.create({

            appId: "welcome",

            title: "Welcome to Nexora",

            icon: "N",

            width: 600,

            height: 400,

            content: `
                <div class="nexora-app-page">

                    <div style="
                        text-align:center;
                        padding:50px 30px;
                    ">

                        <div style="
                            font-size:72px;
                            font-weight:700;
                            letter-spacing:8px;
                        ">
                            N
                        </div>

                        <h1 style="
                            margin-top:15px;
                            font-size:28px;
                        ">
                            Welcome to Nexora
                        </h1>

                        <p style="
                            margin-top:12px;
                            opacity:.55;
                        ">
                            Your system. Your way.
                        </p>

                        <p style="
                            margin-top:30px;
                            opacity:.35;
                            font-size:13px;
                        ">
                            Nexora OS v0.1.0
                        </p>

                    </div>

                </div>
            `

        });

    }

};