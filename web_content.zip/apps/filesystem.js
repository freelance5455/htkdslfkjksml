"use strict";

window.Nexora = window.Nexora || {};

window.Nexora.FileSystem = {

    initialized: false,

    root: {
        type: "folder",
        name: "D",
        children: {}
    },

    init() {

        if (this.initialized) return;

        this.load();

        this.ensureFolder("Apps");
        this.ensureFolder("Documents");
        this.ensureFolder("Downloads");
        this.ensureFolder("Pictures");
        this.ensureFolder("AppData");

        this.save();

        this.initialized = true;

        console.log("[FileSystem] D:/ ready.");

    },

    load() {

        try {

            const saved =
                localStorage.getItem(
                    "nexora-filesystem"
                );

            if (!saved) return;

            const parsed =
                JSON.parse(saved);

            if (
                parsed &&
                parsed.type === "folder"
            ) {

                this.root = parsed;

            }

        } catch (error) {

            console.error(
                "[FileSystem] Load error:",
                error
            );

        }

    },

    save() {

        localStorage.setItem(
            "nexora-filesystem",
            JSON.stringify(this.root)
        );

    },

    normalize(path) {

        path = String(path || "")
            .replaceAll("\\", "/")
            .trim();

        if (path === "D") {
            return [];
        }

        if (path.startsWith("D/")) {
            path = path.slice(2);
        }

        return path
            .split("/")
            .filter(Boolean);

    },

    getNode(path) {

        const parts =
            this.normalize(path);

        let node = this.root;

        for (const part of parts) {

            if (
                !node.children ||
                !node.children[part]
            ) {

                return null;

            }

            node =
                node.children[part];

        }

        return node;

    },

    getParent(path) {

        const parts =
            this.normalize(path);

        if (!parts.length) {
            return null;
        }

        const name =
            parts.pop();

        const parent =
            this.getNode(
                "D/" + parts.join("/")
            );

        return {
            parent,
            name
        };

    },

    exists(path) {

        return !!this.getNode(path);

    },

    ensureFolder(path) {

        const parts =
            this.normalize(path);

        let node = this.root;

        for (const part of parts) {

            if (!node.children[part]) {

                node.children[part] = {

                    type: "folder",

                    name: part,

                    children: {}

                };

            }

            node =
                node.children[part];

            if (
                node.type !== "folder"
            ) {

                throw new Error(
                    `${part} is not a folder`
                );

            }

        }

        this.save();

        return node;

    },

    mkdir(path) {

        return this.ensureFolder(path);

    },

    writeFile(path, content = "") {

        const result =
            this.getParent(path);

        if (
            !result ||
            !result.parent
        ) {

            throw new Error(
                `Parent folder does not exist: ${path}`
            );

        }

        result.parent.children[
            result.name
        ] = {

            type: "file",

            name: result.name,

            content: String(content),

            size:
                String(content).length,

            modified:
                Date.now()

        };

        this.save();

        return this.getNode(path);

    },

    readFile(path) {

        const node =
            this.getNode(path);

        if (!node) {

            throw new Error(
                `File not found: ${path}`
            );

        }

        if (
            node.type !== "file"
        ) {

            throw new Error(
                `${path} is not a file`
            );

        }

        return node.content;

    },

    delete(path) {

        const result =
            this.getParent(path);

        if (
            !result ||
            !result.parent
        ) {

            return false;

        }

        if (
            !result.parent.children[
                result.name
            ]
        ) {

            return false;

        }

        delete result.parent.children[
            result.name
        ];

        this.save();

        return true;

    },

    list(path = "D") {

        const node =
            this.getNode(path);

        if (!node) {

            throw new Error(
                `Path not found: ${path}`
            );

        }

        if (
            node.type !== "folder"
        ) {

            throw new Error(
                `${path} is not a folder`
            );

        }

        return Object.values(
            node.children || {}
        ).sort(
            (a, b) => {

                if (
                    a.type !== b.type
                ) {

                    return a.type === "folder"
                        ? -1
                        : 1;

                }

                return a.name.localeCompare(
                    b.name
                );

            }
        );

    },

    createApp(name) {

        name =
            String(name || "")
                .trim()
                .replace(
                    /[<>:"/\\|?*]/g,
                    ""
                );

        if (!name) {

            throw new Error(
                "App name cannot be empty."
            );

        }

        const path =
            `D/Apps/${name}`;

        if (
            this.exists(path)
        ) {

            throw new Error(
                `An app named "${name}" already exists.`
            );

        }

        this.mkdir(path);
        this.mkdir(`${path}/Assets`);
        this.mkdir(`${path}/Scripts`);
        this.mkdir(`${path}/Data`);

        const starter = `Import System
Import UI
Import Began

Window = System.CreateWindow()

Window.Title = "${name}"
Window.Width = 600
Window.Height = 400

UI = System.CreateUI(Window)

Title = UI.Text("${name}")

Button = UI.Button("Click Me")

Began.ButtonClicked:Connect(function(Button)

    System.Print(Button.Name)

end)
`;

        this.writeFile(
            `${path}/main.nexpy`,
            starter
        );

        this.writeFile(
            `${path}/manifest.json`,
            JSON.stringify(
                {
                    name,
                    version: "1.0.0",
                    main: "main.nexpy",
                    engine: "Nexora",
                    language: "NexPy"
                },
                null,
                4
            )
        );

        this.save();

        return path;

    },

    flatten(node, currentPath = "") {

        const result = [];

        for (
            const child
            of Object.values(
                node.children || {}
            )
        ) {

            const path =
                currentPath
                    ? `${currentPath}/${child.name}`
                    : child.name;

            if (
                child.type === "folder"
            ) {

                result.push({
                    path,
                    type: "folder"
                });

                result.push(
                    ...this.flatten(
                        child,
                        path
                    )
                );

            } else {

                result.push({

                    path,

                    type: "file",

                    content:
                        child.content || ""

                });

            }

        }

        return result;

    },

    exportApp(path) {

        const node =
            this.getNode(path);

        if (
            !node ||
            node.type !== "folder"
        ) {

            throw new Error(
                "App folder not found."
            );

        }

        return {

            format: "nexapp",

            version: 1,

            name: node.name,

            files:
                this.flatten(node)

        };

    },

    importApp(data) {

        if (
            !data ||
            data.format !== "nexapp"
        ) {

            throw new Error(
                "Invalid Nexora app."
            );

        }

        const name =
            String(
                data.name || "ImportedApp"
            )
                .replace(
                    /[<>:"/\\|?*]/g,
                    ""
                )
                .trim();

        if (!name) {

            throw new Error(
                "Invalid app name."
            );

        }

        let finalName = name;
        let counter = 2;

        while (
            this.exists(
                `D/Apps/${finalName}`
            )
        ) {

            finalName =
                `${name} ${counter}`;

            counter++;

        }

        const root =
            `D/Apps/${finalName}`;

        this.mkdir(root);

        for (
            const item
            of data.files || []
        ) {

            const target =
                `${root}/${item.path}`;

            if (
                item.type === "folder"
            ) {

                this.mkdir(target);

            } else {

                const normalized =
                    this.normalize(target);

                normalized.pop();

                if (
                    normalized.length
                ) {

                    this.mkdir(
                        "D/" +
                        normalized.join("/")
                    );

                }

                this.writeFile(
                    target,
                    item.content || ""
                );

            }

        }

        this.save();

        return root;

    }

};