import crypto from 'crypto';
import jwt from 'jsonwebtoken';
const salt=process.env.FOUNDER_PASSWORD_SALT||'';
const expected=process.env.FOUNDER_PASSWORD_HASH||'';
export function founderLogin(password){
  if(!salt||!expected||!password) return null;
  const got=crypto.scryptSync(String(password),salt,64).toString('hex');
  const a=Buffer.from(got,'hex'), b=Buffer.from(expected,'hex');
  if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return null;
  return jwt.sign({role:'admin',scope:'founder'},process.env.JWT_SECRET,{expiresIn:'30m'});
}
export function requireFounder(req,res,next){
  if(req.user?.role!=='admin'||req.user?.scope!=='founder') return res.status(403).json({error:'founder_only'});
  next();
}
