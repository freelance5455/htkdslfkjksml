import jwt from 'jsonwebtoken';
export function signUser(user){return jwt.sign({sub:user.id,role:user.role},process.env.JWT_SECRET,{expiresIn:'7d'})}
export function auth(req,res,next){try{const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))return res.status(401).json({error:'unauthorized'});req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET);next()}catch{return res.status(401).json({error:'invalid_token'})}}
export function role(...roles){return (req,res,next)=>roles.includes(req.user?.role)?next():res.status(403).json({error:'forbidden'})}
