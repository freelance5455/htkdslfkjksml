import dotenv from 'dotenv';dotenv.config();
export async function askGemini(message,context=''){
 if(!process.env.GEMINI_API_KEY) throw new Error('AI_NOT_CONFIGURED');
 const model=process.env.GEMINI_MODEL||'gemini-2.5-flash';
 const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`;
 const body={contents:[{role:'user',parts:[{text:`أنت AMAZON GAZA AI، مساعد تسوق عربي لمنصة تجارة إلكترونية في غزة. لا تخترع أسعاراً أو مخزوناً. سياق: ${context}\nالسؤال: ${message}`}]}],generationConfig:{temperature:.25,maxOutputTokens:700}};
 const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
 if(!r.ok) throw new Error(`GEMINI_${r.status}`); const j=await r.json();
 return j.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('')||'لم أستطع توليد إجابة الآن.';
}
