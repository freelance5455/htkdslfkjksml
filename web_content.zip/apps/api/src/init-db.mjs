import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import pg from 'pg';
const { Pool } = pg;

const shouldInit = /^(1|true|yes)$/i.test(process.env.INIT_DB || '');
if (!shouldInit) process.exit(0);
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required when INIT_DB=true');

const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'disable' ? false : { rejectUnauthorized: false } });
const root = path.resolve(process.cwd(), '../../');
const schema = await fs.readFile(path.join(root, 'database/schema.sql'), 'utf8');
const seed = await fs.readFile(path.join(root, 'database/seed.sql'), 'utf8');

for (let attempt = 1; attempt <= 20; attempt++) {
  try {
    const c = await pool.connect();
    try {
      await c.query('BEGIN');
      await c.query(schema);
      await c.query(seed);
      await c.query('COMMIT');
      console.log('AMAZON GAZA: PostgreSQL schema + seed ready');
    } catch (e) {
      await c.query('ROLLBACK');
      throw e;
    } finally { c.release(); }
    await pool.end();
    process.exit(0);
  } catch (e) {
    console.error(`Database init attempt ${attempt}/20 failed:`, e.message);
    if (attempt === 20) { await pool.end(); process.exit(1); }
    await new Promise(r => setTimeout(r, 3000));
  }
}
