export default {

    create() {

        const content =
            document.createElement("div");

        content.style.cssText = `
            width:100%;
            height:100%;
            padding:20px;
            color:white;
        `;

        content.innerHTML = `

            <div style="
                display:flex;
                gap:8px;
                margin-bottom:20px;
            ">

                <button class="nexora-ui-button">
                    ←
                </button>

                <button class="nexora-ui-button">
                    →
                </button>

                <input
                    class="nexora-ui-input"
                    value="Home"
                    style="flex:1"
                >

            </div>

            <div style="
                display:grid;
                grid-template-columns:
                    repeat(auto-fill,minmax(120px,1fr));
                gap:12px;
            ">

                <div class="nexora-file-card">
                    📁
                    <span>Documents</span>
                </div>

                <div class="nexora-file-card">
                    📁
                    <span>Downloads</span>
                </div>

                <div class="nexora-file-card">
                    📁
                    <span>Pictures</span>
                </div>

                <div class="nexora-file-card">
                    📁
                    <span>Apps</span>
                </div>

            </div>
        `;

        return WindowManager.create({

            appId: "explorer",

            title: "File Explorer",

            icon: "📁",

            width: 720,

            height: 480,

            content

        });

    }

};