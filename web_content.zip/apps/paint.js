export default {

    create() {

        const content =
            document.createElement("div");

        content.style.cssText = `
            width:100%;
            height:100%;
            display:flex;
            flex-direction:column;
            background:#111118;
        `;

        content.innerHTML = `

            <div style="
                height:48px;
                min-height:48px;
                display:flex;
                align-items:center;
                gap:8px;
                padding:0 12px;
                background:rgba(255,255,255,.04);
            ">

                <button id="clear">
                    Clear
                </button>

                <label>
                    Size
                    <input
                        id="size"
                        type="range"
                        min="1"
                        max="40"
                        value="5"
                    >
                </label>

            </div>

            <canvas
                id="paintCanvas"
                style="
                    flex:1;
                    width:100%;
                    height:100%;
                    touch-action:none;
                    background:white;
                "
            ></canvas>
        `;

        const canvas =
            content.querySelector(
                "#paintCanvas"
            );

        const ctx =
            canvas.getContext("2d");

        const resize =
            () => {

                const rect =
                    canvas.getBoundingClientRect();

                const old =
                    document.createElement("canvas");

                old.width = canvas.width;
                old.height = canvas.height;

                old.getContext("2d")
                    .drawImage(canvas, 0, 0);

                canvas.width =
                    Math.max(1, rect.width);

                canvas.height =
                    Math.max(1, rect.height);

                ctx.drawImage(old, 0, 0);

            };

        setTimeout(resize, 0);

        window.addEventListener(
            "resize",
            resize
        );

        let drawing = false;

        canvas.addEventListener(
            "pointerdown",
            event => {

                drawing = true;

                canvas.setPointerCapture(
                    event.pointerId
                );

                ctx.beginPath();

                ctx.moveTo(
                    event.offsetX,
                    event.offsetY
                );

            }
        );

        canvas.addEventListener(
            "pointermove",
            event => {

                if (!drawing) return;

                ctx.lineWidth =
                    Number(
                        content.querySelector(
                            "#size"
                        ).value
                    );

                ctx.lineCap = "round";

                ctx.strokeStyle = "#111118";

                ctx.lineTo(
                    event.offsetX,
                    event.offsetY
                );

                ctx.stroke();

            }
        );

        canvas.addEventListener(
            "pointerup",
            () => {
                drawing = false;
            }
        );

        canvas.addEventListener(
            "pointercancel",
            () => {
                drawing = false;
            }
        );

        content
            .querySelector("#clear")
            .addEventListener(
                "click",
                () => {

                    ctx.clearRect(
                        0,
                        0,
                        canvas.width,
                        canvas.height
                    );

                    ctx.fillStyle = "white";

                    ctx.fillRect(
                        0,
                        0,
                        canvas.width,
                        canvas.height
                    );

                }
            );

        return WindowManager.create({

            appId: "paint",

            title: "Paint",

            icon: "✦",

            width: 700,

            height: 500,

            content

        });

    }

};