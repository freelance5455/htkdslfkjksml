export default {
    id: "about",

    name: "About Nexora",

    description: "Information about Nexora OS",

    icon: "ℹ",

    width: 500,

    height: 340,

    async open() {

        const content = document.createElement("div");

        content.style.cssText = `
            width: 100%;
            height: 100%;
            padding: 30px;

            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;

            text-align: center;

            color: white;
        `;

        content.innerHTML = `
            <div style="
                width: 70px;
                height: 70px;

                display: flex;
                align-items: center;
                justify-content: center;

                border-radius: 20px;

                background:
                    linear-gradient(
                        145deg,
                        rgba(255,255,255,.16),
                        rgba(255,255,255,.05)
                    );

                border: 1px solid rgba(255,255,255,.10);

                box-shadow:
                    0 15px 40px rgba(0,0,0,.25);

                font-size: 34px;
                font-weight: 700;
            ">
                N
            </div>

            <h2 style="
                margin-top: 18px;
                font-size: 22px;
                font-weight: 600;
            ">
                Nexora OS
            </h2>

            <p style="
                margin-top: 6px;
                font-size: 13px;
                opacity: .5;
            ">
                Version 0.1.0
            </p>

            <p style="
                margin-top: 20px;
                font-size: 13px;
                opacity: .7;
                max-width: 340px;
                line-height: 1.6;
            ">
                A web-based operating system built
                around freedom, customization and
                modern web technologies.
            </p>

            <p style="
                margin-top: 18px;
                font-size: 12px;
                opacity: .35;
            ">
                Your system. Your way.
            </p>
        `;

        WindowManager.create({

            appId: "about",

            title: "About Nexora",

            icon: "ℹ",

            width: this.width,

            height: this.height,

            content: content

        });

    }
};