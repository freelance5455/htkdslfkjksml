export default {

    create() {

        const content =
            document.createElement("div");

        content.style.cssText = `
            padding:25px;
            color:white;
        `;

        content.innerHTML = `

            <h2>Settings</h2>

            <p style="
                margin-top:8px;
                opacity:.5;
            ">
                Customize your Nexora environment.
            </p>

            <div style="
                margin-top:25px;
                display:grid;
                gap:10px;
            ">

                <button class="settings-card">
                    Appearance
                    <span>Desktop visual settings</span>
                </button>

                <button class="settings-card">
                    Display
                    <span>Resolution and interface</span>
                </button>

                <button class="settings-card">
                    System
                    <span>Nexora system information</span>
                </button>

                <button class="settings-card">
                    Applications
                    <span>Application management</span>
                </button>

            </div>
        `;

        return WindowManager.create({

            appId: "settings",

            title: "Settings",

            icon: "⚙",

            width: 650,

            height: 450,

            content

        });

    }

};