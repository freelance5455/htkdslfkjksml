export default {

    create() {

        return WindowManager.create({

            appId: "trash",

            title: "Trash",

            icon: "⌫",

            width: 500,

            height: 350,

            content: `
                <div style="
                    height:100%;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    text-align:center;
                    color:white;
                ">

                    <div>

                        <div style="
                            font-size:55px;
                            opacity:.6;
                        ">
                            ⌫
                        </div>

                        <h2 style="
                            margin-top:15px;
                        ">
                            Trash is empty
                        </h2>

                        <p style="
                            margin-top:8px;
                            opacity:.45;
                        ">
                            Deleted files will appear here.
                        </p>

                    </div>

                </div>
            `

        });

    }

};