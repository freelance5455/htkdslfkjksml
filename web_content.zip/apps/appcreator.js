"use strict";

const NexPyAPI = {

    Cursor: {
        description: "Controls the Nexora cursor and virtual pointer.",
        items: {
            SetStyle: "Changes the cursor visual style.",
            SetSize: "Changes the cursor size.",
            SetColor: "Changes the cursor color.",
            SetVisible: "Shows or hides the cursor.",
            SetVirtualVisible: "Shows or hides the mobile virtual cursor.",
            SetSpeed: "Changes virtual cursor movement speed.",
            GetStyle: "Returns the current cursor style.",
            GetSize: "Returns the current cursor size.",
            GetColor: "Returns the current cursor color.",
            GetSpeed: "Returns the current cursor speed."
        }
    },

    System: {
        description: "Core Nexora system API.",
        items: {
            CreateWindow: "Creates a new Nexora window.",
            Print: "Prints a value to the NexPy output console.",
            ReadFile: "Reads a file from the Nexora filesystem.",
            WriteFile: "Writes content to a file.",
            FileExists: "Checks if a file exists.",
            CreateFolder: "Creates a folder."
        }
    },

    UI: {
        description: "Creates and controls user interfaces.",
        items: {
            Text: "Creates a text element.",
            Button: "Creates a clickable button.",
            Input: "Creates a text input.",
            Panel: "Creates a UI panel.",
            Enable: "Enables the UI.",
            Clear: "Removes all UI elements."
        }
    },

    Began: {
        description: "NexPy event system. Inspired by Roblox-style connections.",
        items: {
            ButtonClicked: "Fires when a NexPy UI button is clicked.",
            WindowOpened: "Fires when a NexPy window opens.",
            WindowClosed: "Fires when a NexPy window closes.",
            KeyDown: "Fires when a keyboard key is pressed.",
            KeyUp: "Fires when a keyboard key is released.",
            MouseClicked: "Fires when the mouse is clicked."
        }
    },

    Graphics2D: {
        description: "2D drawing and canvas API.",
        items: {
            CreateCanvas: "Creates a 2D drawing canvas.",
            Rectangle: "Creates a rectangle.",
            Circle: "Creates a circle.",
            Line: "Creates a line.",
            Text: "Draws text.",
            Clear: "Clears the canvas."
        }
    },

    Graphics3D: {
        description: "3D scene API.",
        items: {
            CreateScene: "Creates a 3D scene.",
            Part: "Creates a 3D part.",
            Camera: "Controls the scene camera.",
            Clear: "Clears the 3D scene."
        }
    },

    Storage: {
        description: "Persistent local NexPy storage.",
        items: {
            Get: "Gets a stored value.",
            Set: "Stores a value.",
            Remove: "Removes a stored value."
        }
    },

    Window: {
        description: "Properties available on a NexPy window.",
        items: {
            Title: "The title displayed on the window.",
            Width: "Window width in pixels.",
            Height: "Window height in pixels."
        }
    },

    Button: {
        description: "Properties available on a UI Button.",
        items: {
            Name: "The internal button name.",
            Text: "The text displayed on the button.",
            Visible: "Controls whether the button is visible.",
            Enabled: "Controls whether the button can be used."
        }
    }
};

const nexpySignals = {};

function createNexPySignal() {

    const listeners = [];

    return {

        Connect(callback) {

            if (
                typeof callback !== "function"
            ) {
                return {
                    Disconnect() {}
                };
            }

            listeners.push(callback);

            return {

                Disconnect() {

                    const index =
                        listeners.indexOf(callback);

                    if (index >= 0) {
                        listeners.splice(index, 1);
                    }

                }

            };

        },

        Fire(...args) {

            for (
                const callback
                of [...listeners]
            ) {

                try {
                    callback(...args);
                } catch (error) {
                    console.error(
                        "[NexPy Event]",
                        error
                    );
                }

            }

        }

    };

}

nexpySignals.ButtonClicked =
    createNexPySignal();

nexpySignals.WindowOpened =
    createNexPySignal();

nexpySignals.WindowClosed =
    createNexPySignal();

nexpySignals.KeyDown =
    createNexPySignal();

nexpySignals.KeyUp =
    createNexPySignal();

nexpySignals.MouseClicked =
    createNexPySignal();

function escapeHTML(value) {

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}

function highlightCode(code) {

    const regex =
        /(--[^\n]*|"[^"\n]*"|'[^'\n]*'|\b\d+(?:\.\d+)?\b|\b(?:Import|Load|function|end|true|false|nil|If|Then|Else)\b|\b(?:System|UI|Began|Graphics2D|Graphics3D|Storage|Window|Button)\b)/g;

    let result = "";
    let last = 0;

    for (
        const match of code.matchAll(regex)
    ) {

        result += escapeHTML(
            code.slice(
                last,
                match.index
            )
        );

        const token = match[0];

        let className =
            "token-normal";

        if (
            token.startsWith("--")
        ) {

            className =
                "token-comment";

        } else if (
            token.startsWith('"') ||
            token.startsWith("'")
        ) {

            className =
                "token-string";

        } else if (
            /^\d/.test(token)
        ) {

            className =
                "token-number";

        } else if (
            [
                "Import",
                "Load",
                "function",
                "end",
                "If",
                "Then",
                "Else"
            ].includes(token)
        ) {

            className =
                "token-keyword";

        } else {

            className =
                "token-library";

        }

        result +=
            `<span class="${className}">${escapeHTML(token)}</span>`;

        last =
            match.index + token.length;

    }

    result += escapeHTML(
        code.slice(last)
    );

    return result || " ";

}

function getValue(
    expression,
    variables
) {

    expression =
        expression.trim();

    if (
        expression.startsWith('"') &&
        expression.endsWith('"')
    ) {

        return expression.slice(1, -1);

    }

    if (
        expression.startsWith("'") &&
        expression.endsWith("'")
    ) {

        return expression.slice(1, -1);

    }

    if (
        expression === "true"
    ) return true;

    if (
        expression === "false"
    ) return false;

    if (
        expression === "nil"
    ) return null;

    if (
        /^-?\d+(?:\.\d+)?$/.test(
            expression
        )
    ) {

        return Number(expression);

    }

    const member =
        expression.match(
            /^([A-Za-z_]\w*)((?:\.[A-Za-z_]\w*)+)$/
        );

    if (member) {

        let value =
            variables[member[1]];

        for (
            const part
            of member[2]
                .slice(1)
                .split(".")
        ) {

            if (
                value == null
            ) {
                return undefined;
            }

            value =
                value[part];

        }

        return value;

    }

    if (
        Object.prototype.hasOwnProperty.call(
            variables,
            expression
        )
    ) {

        return variables[expression];

    }

    return expression;

}

function expressionValue(
    expression,
    variables
) {

    expression =
        expression.trim();

    if (
        expression.includes("+")
    ) {

        return expression
            .split("+")
            .map(
                part =>
                    getValue(
                        part,
                        variables
                    )
            )
            .join("");

    }

    return getValue(
        expression,
        variables
    );

}

function normalizePath(path) {

    if (
        typeof path !== "string"
    ) {
        return path;
    }

    return path.trim();

}

function createRuntime(
    root,
    print
) {

    const variables = {};

    const System = {

        CreateWindow() {

            const element =
                document.createElement("div");

            element.style.cssText = `
                width:100%;
                height:100%;
                padding:20px;
                box-sizing:border-box;
                background:#101216;
                color:white;
                font-family:system-ui;
            `;

            const api = {

                element,

                Title: "NexPy Window",

                Width: 500,

                Height: 300,

                _window: null

            };

            api.Open = () => {

                api._window =
                    WindowManager.create({

                        appId:
                            "nexpy-runtime-" +
                            Date.now(),

                        title:
                            api.Title,

                        width:
                            Math.min(
                                api.Width,
                                window.innerWidth - 40
                            ),

                        height:
                            Math.min(
                                api.Height,
                                window.innerHeight - 100
                            ),

                        content:
                            element.outerHTML

                    });

                nexpySignals.WindowOpened.Fire(
                    api
                );

                return api._window;

            };

            return api;

        },

        Print: print,

        ReadFile(path) {

            return Nexora.FileSystem.readFile(
                normalizePath(path)
            );

        },

        WriteFile(path, content) {

            return Nexora.FileSystem.writeFile(
                normalizePath(path),
                content
            );

        },

        FileExists(path) {

            return Nexora.FileSystem.exists(
                normalizePath(path)
            );

        },

        CreateFolder(path) {

            return Nexora.FileSystem.mkdir(
                normalizePath(path)
            );

        }

    };

    const UI = {

        Create(windowApi) {

            return createUI(
                windowApi
            );

        }

    };

    const runtime = {

        System,

        UI,

        Began: {

            ButtonClicked:
                nexpySignals.ButtonClicked,

            WindowOpened:
                nexpySignals.WindowOpened,

            WindowClosed:
                nexpySignals.WindowClosed,

            KeyDown:
                nexpySignals.KeyDown,

            KeyUp:
                nexpySignals.KeyUp,

            MouseClicked:
                nexpySignals.MouseClicked

        },

        Storage: {

            Get(key) {

                return localStorage.getItem(
                    "nexpy-" + key
                );

            },

            Set(key, value) {

                localStorage.setItem(
                    "nexpy-" + key,
                    value
                );

            },

            Remove(key) {

                localStorage.removeItem(
                    "nexpy-" + key
                );

            }

        }

    };

    return {
        variables,
        runtime
    };

}

function createUI(
    windowApi
) {

    const container =
        document.createElement("div");

    container.style.cssText = `
        width:100%;
        height:100%;
        display:flex;
        flex-direction:column;
        gap:12px;
        padding:20px;
        box-sizing:border-box;
        overflow:auto;
        color:white;
    `;

    if (
        windowApi?.element
    ) {

        windowApi.element.appendChild(
            container
        );

    }

    function Text(text) {

        const element =
            document.createElement("div");

        element.textContent =
            text;

        element.style.cssText = `
            color:white;
            font-size:18px;
        `;

        container.appendChild(
            element
        );

        return {

            element,

            Name: "Text",

            Text: text

        };

    }

    function Button(text) {

        const element =
            document.createElement("button");

        element.textContent =
            text;

        element.style.cssText = `
            padding:11px 16px;
            width:max-content;
            border:1px solid rgba(255,255,255,.1);
            border-radius:10px;
            background:rgba(255,255,255,.07);
            color:white;
            cursor:pointer;
        `;

        const api = {

            element,

            Name: "Button",

            Text: text,

            Visible: true,

            Enabled: true

        };

        element.addEventListener(
            "click",
            () => {

                if (
                    api.Enabled === false
                ) {
                    return;
                }

                nexpySignals.ButtonClicked.Fire(
                    api
                );

            }
        );

        container.appendChild(
            element
        );

        return api;

    }

    function Input(placeholder) {

        const element =
            document.createElement("input");

        element.placeholder =
            placeholder || "";

        element.style.cssText = `
            padding:10px;
            border-radius:10px;
            border:1px solid rgba(255,255,255,.1);
            background:rgba(255,255,255,.05);
            color:white;
            outline:none;
        `;

        container.appendChild(
            element
        );

        return {

            element,

            Name: "Input",

            Value: ""

        };

    }

    return {

        Text,

        Button,

        Input,

        Enable() {

            container.style.display =
                "flex";

        },

        Clear() {

            container.innerHTML =
                "";

        }

    };

}

function parseLoad(line) {

    const match =
        line.match(
            /^Load\s*\(\s*D\/["'](.+?)["']\s*\)$/
        );

    if (!match) {
        return null;
    }

    return `D/${match[1]}`;

}

function executeEventBody(
    body,
    variables,
    output
) {

    for (
        const line
        of body
    ) {

        const current =
            line.trim();

        if (!current) {
            continue;
        }

        const print =
            current.match(
                /^System\.Print\((.*)\)$/
            );

        if (print) {

            output(
                expressionValue(
                    print[1],
                    variables
                )
            );

            continue;

        }

        const property =
            current.match(
                /^([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)+)\s*=\s*(.+)$/
            );

        if (!property) {
            continue;
        }

        const path =
            property[1].split(".");

        const value =
            expressionValue(
                property[2],
                variables
            );

        let target =
            variables[path.shift()];

        for (
            const key
            of path.slice(0, -1)
        ) {

            target =
                target?.[key];

        }

        const finalKey =
            path[path.length - 1];

        if (
            target &&
            finalKey
        ) {

            target[finalKey] =
                value;

            if (
                target.element &&
                finalKey === "Text"
            ) {

                target.element.textContent =
                    value;

            }

            if (
                target.element &&
                finalKey === "Visible"
            ) {

                target.element.style.display =
                    value
                        ? ""
                        : "none";

            }

        }

    }

}

function runNexPy(
    code,
    root,
    output
) {

    const lines =
        code
            .replaceAll("\r", "")
            .split("\n");

    const runtime =
        createRuntime(
            root,
            output
        );

    const variables =
        runtime.variables;

    const api =
        runtime.runtime;

    let index = 0;

    while (
        index < lines.length
    ) {

        const line =
            lines[index].trim();

        index++;

        if (
            !line ||
            line.startsWith("--")
        ) {
            continue;
        }

        if (
            /^Import\s+/.test(line)
        ) {

            output(
                `Imported ${line.slice(7).trim()}`
            );

            continue;

        }

        const loaded =
            parseLoad(line);

        if (loaded) {

            if (
                !Nexora.FileSystem.exists(
                    loaded
                )
            ) {

                throw new Error(
                    `Load failed: ${loaded}`
                );

            }

            output(
                `Loaded ${loaded}`
            );

            continue;

        }

        const event =
            line.match(
                /^Began\.([A-Za-z_]\w*)\s*:\s*Connect\s*\(\s*function\s*\((.*?)\)\s*$/
            );

        if (event) {

            const eventName =
                event[1];

            const parameter =
                event[2].trim();

            const body = [];

            while (
                index < lines.length
            ) {

                const current =
                    lines[index].trim();

                index++;

                if (
                    current === "end)" ||
                    current === ")" ||
                    current === "end"
                ) {

                    break;

                }

                body.push(current);

            }

            const signal =
                nexpySignals[eventName];

            if (!signal) {

                output(
                    `Unknown event: ${eventName}`
                );

                continue;

            }

            signal.Connect(
                value => {

                    const local = {
                        ...variables
                    };

                    if (parameter) {

                        local[
                            parameter
                        ] = value;

                    }

                    executeEventBody(
                        body,
                        local,
                        output
                    );

                }
            );

            continue;

        }

        const assignment =
            line.match(
                /^([A-Za-z_]\w*)\s*=\s*(.+)$/
            );

        if (assignment) {

            const name =
                assignment[1];

            const expression =
                assignment[2];

            if (
                expression ===
                "System.CreateWindow()"
            ) {

                variables[name] =
                    api.System.CreateWindow();

                continue;

            }

            if (
                expression ===
                "System.CreateUI(Window)"
            ) {

                variables[name] =
                    api.UI.Create(
                        variables.Window
                    );

                continue;

            }

            const button =
                expression.match(
                    /^UI\.Button\((.*)\)$/
                );

            if (button) {

                variables[name] =
                    variables.UI.Button(
                        expressionValue(
                            button[1],
                            variables
                        )
                    );

                continue;

            }

            const text =
                expression.match(
                    /^UI\.Text\((.*)\)$/
                );

            if (text) {

                variables[name] =
                    variables.UI.Text(
                        expressionValue(
                            text[1],
                            variables
                        )
                    );

                continue;

            }

            const input =
                expression.match(
                    /^UI\.Input\((.*)\)$/
                );

            if (input) {

                variables[name] =
                    variables.UI.Input(
                        expressionValue(
                            input[1],
                            variables
                        )
                    );

                continue;

            }

            variables[name] =
                expressionValue(
                    expression,
                    variables
                );

            continue;

        }

        const property =
            line.match(
                /^([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)+)\s*=\s*(.+)$/
            );

        if (property) {

            const path =
                property[1].split(".");

            const value =
                expressionValue(
                    property[2],
                    variables
                );

            let target =
                variables[path.shift()];

            for (
                const key
                of path.slice(0, -1)
            ) {

                target =
                    target?.[key];

            }

            const finalKey =
                path[path.length - 1];

            if (
                target &&
                finalKey
            ) {

                target[finalKey] =
                    value;

                if (
                    target.element &&
                    finalKey === "Text"
                ) {

                    target.element.textContent =
                        value;

                }

                if (
                    target.element &&
                    finalKey === "Visible"
                ) {

                    target.element.style.display =
                        value
                            ? ""
                            : "none";

                }

            }

            continue;

        }

        const print =
            line.match(
                /^System\.Print\((.*)\)$/
            );

        if (print) {

            output(
                expressionValue(
                    print[1],
                    variables
                )
            );

            continue;

        }

        output(
            `Ignored: ${line}`
        );

    }

}

export default {

    create() {

        const defaultName =
            "My NexPy App";

        const defaultCode =
`Import System
Import UI
Import Began

Window = System.CreateWindow()

Window.Title = "${defaultName}"
Window.Width = 600
Window.Height = 400

UI = System.CreateUI(Window)

Title = UI.Text("${defaultName}")

Button = UI.Button("Click Me")

Began.ButtonClicked:Connect(function(Button)

    System.Print(Button.Name)

end)
`;

        const content = `

<style>

.nexpy-root {
    width:100%;
    height:100%;
    display:flex;
    flex-direction:column;
    background:#0d0f13;
    color:#e7e9ee;
    font-family:system-ui,sans-serif;
    overflow:hidden;
}

.nexpy-toolbar {
    height:46px;
    min-height:46px;
    display:flex;
    align-items:center;
    gap:7px;
    padding:0 9px;
    background:#111318;
    border-bottom:1px solid rgba(255,255,255,.07);
}

.nexpy-project {
    width:170px;
    height:31px;
    box-sizing:border-box;
    padding:0 10px;
    border:1px solid rgba(255,255,255,.09);
    border-radius:7px;
    background:#090b0f;
    color:white;
    outline:none;
}

.nexpy-button {
    height:31px;
    padding:0 10px;
    border:1px solid rgba(255,255,255,.08);
    border-radius:7px;
    background:#181b21;
    color:#ddd;
    cursor:pointer;
}

.nexpy-button:hover {
    background:#252a33;
}

.nexpy-layout {
    flex:1;
    min-height:0;
    display:flex;
}

.nexpy-explorer {
    width:205px;
    min-width:205px;
    background:#111318;
    border-right:1px solid rgba(255,255,255,.07);
    display:flex;
    flex-direction:column;
}

.nexpy-explorer-title {
    height:38px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 10px;
    font-size:11px;
    font-weight:700;
    letter-spacing:1px;
    opacity:.65;
}

.nexpy-tree {
    flex:1;
    overflow:auto;
    padding:4px;
}

.nexpy-tree-item {
    min-height:28px;
    display:flex;
    align-items:center;
    gap:7px;
    border-radius:6px;
    padding-right:7px;
    cursor:pointer;
    font-size:12px;
    user-select:none;
}

.nexpy-tree-item:hover {
    background:rgba(255,255,255,.06);
}

.nexpy-tree-item.active {
    background:rgba(80,130,255,.17);
}

.nexpy-workspace {
    flex:1;
    min-width:0;
    display:flex;
    flex-direction:column;
}

.nexpy-tabs {
    height:36px;
    min-height:36px;
    display:flex;
    background:#090b0f;
    border-bottom:1px solid rgba(255,255,255,.06);
    overflow:auto;
}

.nexpy-tab {
    min-width:130px;
    padding:0 12px;
    display:flex;
    align-items:center;
    color:#777;
    font-size:12px;
    border-right:1px solid rgba(255,255,255,.05);
}

.nexpy-tab.active {
    color:white;
    background:#111318;
}

.nexpy-editor {
    position:relative;
    flex:1;
    min-height:0;
    display:flex;
    background:#0d0f13;
}

.nexpy-lines {
    width:48px;
    flex-shrink:0;
    padding-top:14px;
    padding-right:9px;
    box-sizing:border-box;
    text-align:right;
    color:#454b56;
    font:13px/20px Consolas,monospace;
    overflow:hidden;
    user-select:none;
}

.nexpy-code-wrap {
    position:relative;
    flex:1;
    min-width:0;
    overflow:hidden;
}

.nexpy-highlight,
.nexpy-code {
    position:absolute;
    inset:0;
    margin:0;
    padding:14px;
    box-sizing:border-box;
    font:13px/20px Consolas,monospace;
    white-space:pre;
    tab-size:4;
}

.nexpy-highlight {
    overflow:hidden;
    pointer-events:none;
    color:#ddd;
}

.nexpy-code {
    resize:none;
    border:0;
    outline:0;
    background:transparent;
    color:transparent;
    caret-color:white;
    overflow:auto;
}

.nexpy-code::selection {
    background:rgba(90,130,255,.35);
}

.token-keyword {
    color:#d88aff;
}

.token-library {
    color:#65b7ff;
}

.token-string {
    color:#8fd694;
}

.token-number {
    color:#e7b96a;
}

.token-comment {
    color:#555c68;
}

.nexpy-bottom {
    height:135px;
    min-height:90px;
    display:flex;
    flex-direction:column;
    background:#090b0f;
    border-top:1px solid rgba(255,255,255,.07);
}

.nexpy-output-title {
    height:30px;
    display:flex;
    align-items:center;
    padding:0 10px;
    font-size:10px;
    font-weight:700;
    letter-spacing:1px;
    opacity:.55;
}

.nexpy-output {
    flex:1;
    padding:7px 11px;
    overflow:auto;
    color:#aaa;
    white-space:pre-wrap;
    font:12px/18px Consolas,monospace;
}

.nexpy-status {
    height:23px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:0 9px;
    background:#151820;
    color:#777;
    font:11px Consolas,monospace;
}

.nexpy-autocomplete {
    position:absolute;
    width:300px;
    max-width:calc(100% - 20px);
    min-height:40px;
    z-index:500;
    display:none;
    border:1px solid rgba(255,255,255,.13);
    border-radius:8px;
    background:#171a20;
    box-shadow:0 16px 40px rgba(0,0,0,.5);
    overflow:hidden;
}

.nexpy-suggestion {
    padding:8px 10px;
    cursor:pointer;
}

.nexpy-suggestion:hover {
    background:rgba(80,130,255,.16);
}

.nexpy-suggestion-name {
    font:13px Consolas,monospace;
    color:white;
}

.nexpy-suggestion-description {
    margin-top:4px;
    font-size:11px;
    color:#777;
    white-space:normal;
}

.nexpy-config {
    position:absolute;
    top:46px;
    right:0;
    width:290px;
    bottom:0;
    z-index:800;
    display:none;
    padding:15px;
    box-sizing:border-box;
    background:#111318;
    border-left:1px solid rgba(255,255,255,.08);
    box-shadow:-20px 0 45px rgba(0,0,0,.35);
    overflow:auto;
}

.nexpy-config.open {
    display:block;
}

.nexpy-config h3 {
    margin:0 0 15px;
    font-size:15px;
}

.nexpy-config-row {
    padding:13px 0;
    border-bottom:1px solid rgba(255,255,255,.06);
}

.nexpy-config-label {
    font-size:12px;
}

.nexpy-config-description {
    margin-top:5px;
    color:#666;
    font-size:11px;
    line-height:1.4;
}

.nexpy-toggle {
    margin-top:9px;
}

.nexpy-number {
    width:100%;
    box-sizing:border-box;
    margin-top:9px;
    padding:8px;
    border:1px solid rgba(255,255,255,.08);
    border-radius:7px;
    background:#090b0f;
    color:white;
    outline:none;
}

@media(max-width:800px) {

    .nexpy-explorer {
        width:150px;
        min-width:150px;
    }

    .nexpy-project {
        width:120px;
    }

}

@media(max-width:600px) {

    .nexpy-explorer {
        width:120px;
        min-width:120px;
    }

    .nexpy-project {
        width:100px;
    }

    .nexpy-button {
        padding:0 7px;
        font-size:11px;
    }

}

</style>

<div class="nexpy-root">

    <div class="nexpy-toolbar">

        <input
            class="nexpy-project"
            value="${defaultName}"
            placeholder="App name..."
        >

        <button
            class="nexpy-button"
            data-action="create"
        >
            Create
        </button>

        <button
            class="nexpy-button"
            data-action="new"
        >
            New
        </button>

        <button
            class="nexpy-button"
            data-action="save"
        >
            Save
        </button>

        <button
            class="nexpy-button"
            data-action="run"
        >
            ▶ Run
        </button>

        <button
            class="nexpy-button"
            data-action="terminal"
        >
            Terminal
        </button>

        <button
            class="nexpy-button"
            data-action="export"
        >
            Export
        </button>

        <button
            class="nexpy-button"
            data-action="config"
            title="NexPy Settings"
        >
            ⚙
        </button>

    </div>

    <div class="nexpy-layout">

        <aside class="nexpy-explorer">

            <div class="nexpy-explorer-title">
                <span>EXPLORER</span>

                <span>
                    + &nbsp;📁
                </span>
            </div>

            <div class="nexpy-tree"></div>

        </aside>

        <section class="nexpy-workspace">

            <div class="nexpy-tabs"></div>

            <div class="nexpy-editor">

                <div class="nexpy-lines"></div>

                <div class="nexpy-code-wrap">

                    <pre
                        class="nexpy-highlight"
                    ></pre>

                    <textarea
                        class="nexpy-code"
                        spellcheck="false"
                        autocomplete="off"
                    ></textarea>

                    <div
                        class="nexpy-autocomplete"
                    ></div>

                </div>

            </div>

            <div class="nexpy-bottom">

                <div class="nexpy-output-title">
                    OUTPUT
                </div>

                <div class="nexpy-output"></div>

            </div>

            <div class="nexpy-status">

                <span class="nexpy-status-file">
                    main.nexpy
                </span>

                <span class="nexpy-status-position">
                    Ln 1, Col 1
                </span>

            </div>

        </section>

    </div>

    <div class="nexpy-config">

        <h3>NexPy Settings</h3>

        <div class="nexpy-config-row">

            <div class="nexpy-config-label">
                Autocomplete
            </div>

            <div class="nexpy-config-description">
                Show the closest NexPy suggestion while typing.
            </div>

            <label class="nexpy-toggle">

                <input
                    type="checkbox"
                    data-setting="autocomplete"
                    checked
                >

                Enabled

            </label>

        </div>

        <div class="nexpy-config-row">

            <div class="nexpy-config-label">
                Autocomplete Offset
            </div>

            <div class="nexpy-config-description">
                Controls the distance between the suggestion box and the current line.
            </div>

            <input
                class="nexpy-number"
                type="number"
                min="0"
                max="100"
                value="4"
                data-setting="offset"
            >

        </div>

        <div class="nexpy-config-row">

            <div class="nexpy-config-label">
                API Information
            </div>

            <div class="nexpy-config-description">
                Autocomplete descriptions are enabled automatically.
                The suggestion shows what each property or function is used for.
            </div>

        </div>

    </div>

</div>
`;

        const viewportWidth =
            Math.max(
                420,
                window.innerWidth - 30
            );

        const viewportHeight =
            Math.max(
                350,
                window.innerHeight - 90
            );

        const width =
            Math.min(
                1050,
                viewportWidth
            );

        const height =
            Math.min(
                720,
                viewportHeight
            );

        const win =
            WindowManager.create({

                appId:
                    "appcreator",

                title:
                    "App Creator",

                icon:
                    "⌘",

                width,

                height,

                minWidth:
                    Math.min(
                        650,
                        viewportWidth
                    ),

                minHeight:
                    Math.min(
                        450,
                        viewportHeight
                    ),

                content

            });

        const root =
            win.element;

        const editor =
            root.querySelector(
                ".nexpy-code"
            );

        const highlight =
            root.querySelector(
                ".nexpy-highlight"
            );

        const lines =
            root.querySelector(
                ".nexpy-lines"
            );

        const tree =
            root.querySelector(
                ".nexpy-tree"
            );

        const tabs =
            root.querySelector(
                ".nexpy-tabs"
            );

        const output =
            root.querySelector(
                ".nexpy-output"
            );

        const autocomplete =
            root.querySelector(
                ".nexpy-autocomplete"
            );

        const config =
            root.querySelector(
                ".nexpy-config"
            );

        const projectName =
            root.querySelector(
                ".nexpy-project"
            );

        const statusFile =
            root.querySelector(
                ".nexpy-status-file"
            );

        const statusPosition =
            root.querySelector(
                ".nexpy-status-position"
            );

        const autocompleteToggle =
            root.querySelector(
                '[data-setting="autocomplete"]'
            );

        const autocompleteOffset =
            root.querySelector(
                '[data-setting="offset"]'
            );

        let appPath = null;

        let activeFile =
            "main.nexpy";

        let files = {

            "main.nexpy":
                defaultCode

        };

        let settings = {

            autocomplete:
                localStorage.getItem(
                    "nexpy-autocomplete"
                ) !== "false",

            offset:
                Number(
                    localStorage.getItem(
                        "nexpy-autocomplete-offset"
                    ) || 4
                )

        };

        autocompleteToggle.checked =
            settings.autocomplete;

        autocompleteOffset.value =
            settings.offset;

        function log(text) {

            output.textContent +=
                String(text) +
                "\n";

            output.scrollTop =
                output.scrollHeight;

        }

        function render() {

            highlight.innerHTML =
                highlightCode(
                    editor.value
                );

        }

        function updateLines() {

            const count =
                editor.value
                    .split("\n")
                    .length;

            lines.innerHTML =
                Array.from(
                    {
                        length: count
                    },
                    (_, i) =>
                        `<div>${i + 1}</div>`
                ).join("");

        }

        function updateStatus() {

            const position =
                editor.selectionStart;

            const before =
                editor.value.slice(
                    0,
                    position
                );

            const lineNumber =
                before.split("\n").length;

            const lastBreak =
                before.lastIndexOf("\n");

            const column =
                position -
                lastBreak;

            statusFile.textContent =
                activeFile;

            statusPosition.textContent =
                `Ln ${lineNumber}, Col ${column}`;

        }

        function syncEditor() {

            editor.value =
                files[activeFile] || "";

            render();

            updateLines();

            updateStatus();

        }

        function saveCurrent() {

            files[activeFile] =
                editor.value;

            if (!appPath) {

                log(
                    "No project created yet."
                );

                return;

            }

            Nexora.FileSystem.writeFile(
                `${appPath}/${activeFile}`,
                editor.value
            );

            log(
                `Saved ${activeFile}`
            );

        }

        function refreshTree() {

            tree.innerHTML = "";

            if (!appPath) {

                tree.innerHTML = `
                    <div style="
                        padding:14px;
                        color:#666;
                        font-size:12px;
                    ">
                        Create a project first.
                    </div>
                `;

                return;

            }

            function draw(
                folderPath,
                level
            ) {

                const items =
                    Nexora.FileSystem.list(
                        folderPath
                    );

                for (
                    const item
                    of items
                ) {

                    const itemPath =
                        `${folderPath}/${item.name}`;

                    const element =
                        document.createElement(
                            "div"
                        );

                    element.className =
                        "nexpy-tree-item";

                    element.style.paddingLeft =
                        `${7 + level * 14}px`;

                    element.innerHTML =
                        item.type === "folder"
                            ? `📁 ${escapeHTML(item.name)}`
                            : `📄 ${escapeHTML(item.name)}`;

                    if (
                        item.type === "file"
                    ) {

                        const relative =
                            itemPath.slice(
                                appPath.length + 1
                            );

                        if (
                            relative === activeFile
                        ) {

                            element.classList.add(
                                "active"
                            );

                        }

                        element.onclick =
                            () => {

                                if (
                                    files[activeFile] !==
                                    editor.value
                                ) {

                                    saveCurrent();

                                }

                                activeFile =
                                    relative;

                                files[activeFile] =
                                    Nexora.FileSystem.readFile(
                                        itemPath
                                    );

                                syncEditor();

                                refreshTree();

                            };

                    }

                    tree.appendChild(
                        element
                    );

                    if (
                        item.type === "folder"
                    ) {

                        draw(
                            itemPath,
                            level + 1
                        );

                    }

                }

            }

            draw(
                appPath,
                0
            );

        }

        function createProject() {

            const name =
                projectName.value.trim();

            if (!name) {

                alert(
                    "Enter a name for the app."
                );

                return;

            }

            try {

                appPath =
                    Nexora.FileSystem.createApp(
                        name
                    );

                activeFile =
                    "main.nexpy";

                files = {

                    "main.nexpy":
                        Nexora.FileSystem.readFile(
                            `${appPath}/main.nexpy`
                        )

                };

                syncEditor();

                refreshTree();

                log(
                    `Project created: ${name}`
                );

                log(
                    `Path: ${appPath}`
                );

                if (
                    Nexora.Notifications
                ) {

                    Nexora.Notifications.success(
                        "Project Created",
                        name
                    );

                }

            } catch (error) {

                alert(
                    error.message
                );

            }

        }

        function newProject() {

            appPath = null;

            activeFile =
                "main.nexpy";

            files = {

                "main.nexpy":
                    defaultCode

            };

            projectName.value =
                "My NexPy App";

            syncEditor();

            refreshTree();

            log(
                "New project created in memory."
            );

        }

        function createFile() {

            if (!appPath) {

                alert(
                    "Create a project first."
                );

                return;

            }

            const name =
                prompt(
                    "File name:",
                    "script.nexpy"
                );

            if (!name) return;

            const path =
                `${appPath}/${name.trim()}`;

            if (
                Nexora.FileSystem.exists(
                    path
                )
            ) {

                alert(
                    "That file already exists."
                );

                return;

            }

            Nexora.FileSystem.writeFile(
                path,
                ""
            );

            activeFile =
                name.trim();

            files[activeFile] =
                "";

            syncEditor();

            refreshTree();

        }

        function createFolder() {

            if (!appPath) {

                alert(
                    "Create a project first."
                );

                return;

            }

            const name =
                prompt(
                    "Folder name:",
                    "Scripts"
                );

            if (!name) return;

            Nexora.FileSystem.mkdir(
                `${appPath}/${name.trim()}`
            );

            refreshTree();

        }

        function runCode() {

            saveCurrent();

            output.textContent = "";

            log(
                `Running ${activeFile}...`
            );

            try {

                runNexPy(
                    editor.value,
                    root,
                    log
                );

                log(
                    "Program finished."
                );

            } catch (error) {

                log(
                    `Error: ${error.message}`
                );

                console.error(error);

            }

        }

        function openTerminal() {

            if (
                Nexora.System
            ) {

                Nexora.System.launch(
                    "nexpyTerminal"
                );

            }

        }

        function exportProject() {

            if (!appPath) {

                alert(
                    "Create a project first."
                );

                return;

            }

            saveCurrent();

            Nexora.AppSystem.export(
                appPath
            );

        }

        function getCurrentToken() {

            const position =
                editor.selectionStart;

            const before =
                editor.value.slice(
                    0,
                    position
                );

            const match =
                before.match(
                    /[A-Za-z_][A-Za-z0-9_]*$/
                );

            return match
                ? match[0]
                : "";

        }

        function getContext() {

            const position =
                editor.selectionStart;

            const before =
                editor.value.slice(
                    0,
                    position
                );

            const line =
                before.slice(
                    before.lastIndexOf("\n") + 1
                );

            const member =
                line.match(
                    /([A-Za-z_]\w*)\.[A-Za-z_]*$/
                );

            if (member) {

                return member[1];

            }

            return null;

        }

        function buildSuggestions() {

            const token =
                getCurrentToken();

            const context =
                getContext();

            let source = [];

            if (
                context &&
                NexPyAPI[context]
            ) {

                source =
                    Object.entries(
                        NexPyAPI[context].items
                    )
                    .map(
                        ([name, description]) => ({
                            name,
                            description
                        })
                    );

            } else {

                for (
                    const [group, data]
                    of Object.entries(
                        NexPyAPI
                    )
                ) {

                    source.push({

                        name: group,

                        description:
                            data.description

                    });

                    for (
                        const [
                            name,
                            description
                        ]
                        of Object.entries(
                            data.items
                        )
                    ) {

                        source.push({

                            name,

                            description

                        });

                    }

                }

                source.push({

                    name: "Import",
                    description:
                        "Imports a NexPy library."

                });

                source.push({

                    name: "Load",
                    description:
                        "Loads a file or folder from D/."

                });

            }

            if (!token) {

                return source
                    .filter(
                        item =>
                            [
                                "Import",
                                "Load",
                                "System",
                                "UI",
                                "Began",
                                "Graphics2D",
                                "Graphics3D",
                                "Storage"
                            ].includes(
                                item.name
                            )
                    )
                    .slice(0, 1);

            }

            const lower =
                token.toLowerCase();

            const scored =
                source
                    .map(item => {

                        const name =
                            item.name.toLowerCase();

                        let score = 999;

                        if (
                            name === lower
                        ) {

                            score = 0;

                        } else if (
                            name.startsWith(lower)
                        ) {

                            score = 10 +
                                (
                                    name.length -
                                    lower.length
                                );

                        } else if (
                            name.includes(lower)
                        ) {

                            score = 100 +
                                name.indexOf(
                                    lower
                                );

                        }

                        return {
                            ...item,
                            score
                        };

                    })
                    .filter(
                        item =>
                            item.score < 999
                    )
                    .sort(
                        (a, b) => {

                            if (
                                a.score !==
                                b.score
                            ) {

                                return (
                                    a.score -
                                    b.score
                                );

                            }

                            return a.name.localeCompare(
                                b.name
                            );

                        }
                    );

            return scored.length
                ? [scored[0]]
                : [];

        }

        function positionAutocomplete() {

            const position =
                editor.selectionStart;

            const before =
                editor.value.slice(
                    0,
                    position
                );

            const lineIndex =
                before.split("\n").length - 1;

            const lineText =
                before.slice(
                    before.lastIndexOf("\n") + 1
                );

            const column =
                lineText.length;

            const lineHeight =
                20;

            const top =
                14 +
                lineIndex *
                lineHeight -
                editor.scrollTop;

            const left =
                Math.min(
                    300,
                    Math.max(
                        5,
                        14 +
                        column * 7.8
                    )
                );

            autocomplete.style.left =
                `${left}px`;

            autocomplete.style.bottom =
                "auto";

            autocomplete.style.top =
                `${Math.max(
                    2,
                    top -
                    4 -
                    settings.offset -
                    autocomplete.offsetHeight
                )}px`;

        }

        function closeAutocomplete() {

            autocomplete.style.display =
                "none";

        }

        function showAutocomplete() {

            if (
                !settings.autocomplete
            ) {

                closeAutocomplete();

                return;

            }

            const suggestions =
                buildSuggestions();

            if (
                suggestions.length !== 1
            ) {

                closeAutocomplete();

                return;

            }

            const item =
                suggestions[0];

            autocomplete.innerHTML = `

                <div
                    class="nexpy-suggestion"
                    data-value="${escapeHTML(item.name)}"
                >

                    <div class="nexpy-suggestion-name">
                        ${escapeHTML(item.name)}
                    </div>

                    <div class="nexpy-suggestion-description">
                        ${escapeHTML(item.description)}
                    </div>

                </div>

            `;

            autocomplete.style.display =
                "block";

            positionAutocomplete();

            autocomplete
                .querySelector(
                    ".nexpy-suggestion"
                )
                .onclick =
                    event => {

                        event.stopPropagation();

                        acceptSuggestion(
                            item.name
                        );

                    };

        }

        function acceptSuggestion(
            value
        ) {

            const position =
                editor.selectionStart;

            const before =
                editor.value.slice(
                    0,
                    position
                );

            const match =
                before.match(
                    /[A-Za-z_][A-Za-z0-9_]*$/
                );

            const start =
                match
                    ? position -
                      match[0].length
                    : position;

            editor.setRangeText(
                value,
                start,
                position,
                "end"
            );

            files[activeFile] =
                editor.value;

            render();

            updateLines();

            updateStatus();

            closeAutocomplete();

            editor.focus();

        }

        editor.addEventListener(
            "input",
            () => {

                files[activeFile] =
                    editor.value;

                render();

                updateLines();

                updateStatus();

                showAutocomplete();

            }
        );

        editor.addEventListener(
            "click",
            () => {

                updateStatus();

                closeAutocomplete();

            }
        );

        editor.addEventListener(
            "keyup",
            event => {

                updateStatus();

                if (
                    event.key === "Escape"
                ) {

                    closeAutocomplete();

                    return;

                }

                if (
                    event.key === "ArrowDown" ||
                    event.key === "ArrowUp"
                ) {

                    return;

                }

                if (
                    event.key === "Enter" &&
                    autocomplete.style.display !==
                    "none"
                ) {

                    const suggestion =
                        autocomplete.querySelector(
                            ".nexpy-suggestion"
                        );

                    if (suggestion) {

                        event.preventDefault();

                        acceptSuggestion(
                            suggestion.dataset.value
                        );

                    }

                    return;

                }

                showAutocomplete();

            }
        );

        editor.addEventListener(
            "scroll",
            () => {

                highlight.scrollTop =
                    editor.scrollTop;

                highlight.scrollLeft =
                    editor.scrollLeft;

                lines.scrollTop =
                    editor.scrollTop;

                if (
                    autocomplete.style.display !==
                    "none"
                ) {

                    positionAutocomplete();

                }

            }
        );

        document.addEventListener(
            "pointerdown",
            event => {

                if (
                    !autocomplete.contains(
                        event.target
                    ) &&
                    event.target !== editor
                ) {

                    closeAutocomplete();

                }

            },
            true
        );

        config.addEventListener(
            "pointerdown",
            event => {

                event.stopPropagation();

            }
        );

        autocomplete.addEventListener(
            "pointerdown",
            event => {

                event.stopPropagation();

            }
        );

        autocompleteToggle.addEventListener(
            "change",
            () => {

                settings.autocomplete =
                    autocompleteToggle.checked;

                localStorage.setItem(
                    "nexpy-autocomplete",
                    String(
                        settings.autocomplete
                    )
                );

                if (
                    !settings.autocomplete
                ) {

                    closeAutocomplete();

                }

            }
        );

        autocompleteOffset.addEventListener(
            "input",
            () => {

                settings.offset =
                    Math.max(
                        0,
                        Math.min(
                            100,
                            Number(
                                autocompleteOffset.value
                            ) || 0
                        )
                    );

                localStorage.setItem(
                    "nexpy-autocomplete-offset",
                    String(
                        settings.offset
                    )
                );

                if (
                    autocomplete.style.display !==
                    "none"
                ) {

                    positionAutocomplete();

                }

            }
        );

        root
            .querySelectorAll(
                "[data-action]"
            )
            .forEach(
                button => {

                    button.addEventListener(
                        "click",
                        event => {

                            const action =
                                button.dataset.action;

                            if (
                                action ===
                                "create"
                            ) {

                                createProject();

                            }

                            if (
                                action ===
                                "new"
                            ) {

                                newProject();

                            }

                            if (
                                action ===
                                "save"
                            ) {

                                saveCurrent();

                            }

                            if (
                                action ===
                                "run"
                            ) {

                                runCode();

                            }

                            if (
                                action ===
                                "terminal"
                            ) {

                                openTerminal();

                            }

                            if (
                                action ===
                                "export"
                            ) {

                                exportProject();

                            }

                            if (
                                action ===
                                "config"
                            ) {

                                config.classList.toggle(
                                    "open"
                                );

                                closeAutocomplete();

                            }

                        }
                    );

                }
            );

        syncEditor();

        refreshTree();

        log(
            "NexPy Editor ready."
        );

        log(
            "Create a project to start."
        );

        return win;

    }

};