export default {

    create() {

        const content =
            document.createElement("div");

        content.style.cssText = `
            padding:24px;
            color:white;
        `;

        content.innerHTML = `
            <h2>Nexora Apps</h2>

            <p style="
                margin-top:8px;
                opacity:.5;
            ">
                Applications installed on Nexora.
            </p>

            <div
                id="nexora-installed-apps"
                style="
                    margin-top:25px;
                    display:grid;
                    grid-template-columns:
                        repeat(auto-fill,minmax(180px,1fr));
                    gap:12px;
                "
            ></div>
        `;

        const grid =
            content.querySelector(
                "#nexora-installed-apps"
            );

        for (
            const app
            of Nexora.System.getApps()
        ) {

            const card =
                document.createElement("button");

            card.style.cssText = `
                padding:18px;
                border:1px solid rgba(255,255,255,.08);
                border-radius:15px;
                background:rgba(255,255,255,.05);
                color:white;
                text-align:left;
                cursor:pointer;
            `;

            card.innerHTML = `
                <div style="
                    font-size:25px;
                ">
                    ${app.icon}
                </div>

                <strong style="
                    display:block;
                    margin-top:10px;
                ">
                    ${app.name}
                </strong>

                <small style="
                    display:block;
                    margin-top:5px;
                    opacity:.45;
                ">
                    ${app.description}
                </small>
            `;

            card.addEventListener(
                "click",
                () => Nexora.System.launch(app.id)
            );

            grid.appendChild(card);

        }

        return WindowManager.create({

            appId: "apps",

            title: "Nexora Apps",

            icon: "◈",

            width: 650,

            height: 450,

            content

        });

    }

};