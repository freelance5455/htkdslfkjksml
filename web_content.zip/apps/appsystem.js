"use strict";

window.Nexora = window.Nexora || {};

window.Nexora.AppSystem = {

    initialized: false,

    init() {

        if (this.initialized) return;

        this.initialized = true;

        console.log(
            "[AppSystem] Ready."
        );

    },

    async importFile(file) {

        if (!file) {
            throw new Error(
                "No file selected."
            );
        }

        const text =
            await file.text();

        let data;

        try {

            data =
                JSON.parse(text);

        } catch {

            throw new Error(
                "Invalid Nexora app package."
            );

        }

        const path =
            Nexora.FileSystem.importApp(
                data
            );

        if (
            Nexora.Notifications
        ) {

            Nexora.Notifications.success(
                "App Installed",
                `${data.name} was imported successfully.`
            );

        }

        return path;

    },

    import() {

        const input =
            document.createElement(
                "input"
            );

        input.type = "file";

        input.accept =
            ".nexapp,application/json";

        input.onchange =
            async () => {

                const file =
                    input.files?.[0];

                if (!file) return;

                try {

                    await this.importFile(
                        file
                    );

                } catch (error) {

                    console.error(error);

                    if (
                        Nexora.Notifications
                    ) {

                        Nexora.Notifications.error(
                            "Import Failed",
                            error.message
                        );

                    }

                }

            };

        input.click();

    },

    export(path) {

        const data =
            Nexora.FileSystem.exportApp(
                path
            );

        const blob =
            new Blob(
                [
                    JSON.stringify(
                        data,
                        null,
                        4
                    )
                ],
                {
                    type:
                        "application/json"
                }
            );

        const url =
            URL.createObjectURL(
                blob
            );

        const a =
            document.createElement(
                "a"
            );

        a.href = url;

        a.download =
            `${data.name}.nexapp`;

        document.body.appendChild(a);

        a.click();

        a.remove();

        URL.revokeObjectURL(url);

        if (
            Nexora.Notifications
        ) {

            Nexora.Notifications.success(
                "App Exported",
                `${data.name}.nexapp is ready.`
            );

        }

    }

};