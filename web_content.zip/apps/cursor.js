export default {

    id: "cursor",

    name: "Cursor",

    description:
        "Customize the Nexora cursor.",

    icon: "⌁",

    create() {

        const root =
            document.createElement("div");

        root.style.cssText = `
            width:100%;
            height:100%;
            box-sizing:border-box;
            padding:22px;
            color:white;
            overflow:auto;
            font-family:system-ui,sans-serif;
        `;

        root.innerHTML = `

            <div style="
                display:flex;
                align-items:center;
                justify-content:space-between;
                margin-bottom:20px;
            ">

                <div>

                    <div style="
                        font-size:24px;
                        font-weight:700;
                    ">
                        Cursor
                    </div>

                    <div style="
                        opacity:.45;
                        font-size:13px;
                        margin-top:5px;
                    ">
                        Customize your Nexora pointer
                    </div>

                </div>

                <div
                    id="cursorPreview"
                    style="
                        width:70px;
                        height:70px;
                        border-radius:18px;
                        background:rgba(255,255,255,.05);
                        border:1px solid rgba(255,255,255,.08);
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        font-size:30px;
                    "
                >
                    +
                </div>

            </div>

            <div style="
                display:grid;
                grid-template-columns:
                    repeat(auto-fit,minmax(150px,1fr));
                gap:10px;
            ">

                <button class="cursor-style" data-style="default">
                    Default
                </button>

                <button class="cursor-style" data-style="dot">
                    Dot
                </button>

                <button class="cursor-style" data-style="ring">
                    Ring
                </button>

                <button class="cursor-style" data-style="cross">
                    Cross
                </button>

                <button class="cursor-style" data-style="glow">
                    Glow
                </button>

                <button class="cursor-style" data-style="square">
                    Square
                </button>

                <button class="cursor-style" data-style="pointer">
                    Pointer
                </button>

            </div>

            <div style="
                margin-top:22px;
                display:grid;
                gap:14px;
            ">

                <label style="
                    display:grid;
                    gap:7px;
                    font-size:13px;
                ">

                    Cursor size

                    <input
                        id="cursorSize"
                        type="range"
                        min="8"
                        max="80"
                        step="1"
                    >

                </label>

                <label style="
                    display:grid;
                    gap:7px;
                    font-size:13px;
                ">

                    Cursor color

                    <input
                        id="cursorColor"
                        type="color"
                        style="
                            width:100%;
                            height:40px;
                            border:0;
                            background:transparent;
                        "
                    >

                </label>

                <label style="
                    display:flex;
                    align-items:center;
                    justify-content:space-between;
                    gap:15px;
                ">

                    <span>
                        Show cursor
                    </span>

                    <input
                        id="cursorVisible"
                        type="checkbox"
                    >

                </label>

                <label style="
                    display:flex;
                    align-items:center;
                    justify-content:space-between;
                    gap:15px;
                ">

                    <span>
                        Virtual mobile cursor
                    </span>

                    <input
                        id="virtualVisible"
                        type="checkbox"
                    >

                </label>

                <label style="
                    display:grid;
                    gap:7px;
                    font-size:13px;
                ">

                    Virtual cursor speed

                    <input
                        id="cursorSpeed"
                        type="range"
                        min="0.25"
                        max="5"
                        step="0.25"
                    >

                </label>

            </div>

            <div style="
                margin-top:24px;
                display:flex;
                gap:10px;
            ">

                <button id="resetCursor">
                    Reset
                </button>

            </div>

            <div
                id="cursorStatus"
                style="
                    margin-top:15px;
                    opacity:.45;
                    font-size:12px;
                "
            ></div>
        `;

        const buttons =
            root.querySelectorAll(
                ".cursor-style"
            );

        const size =
            root.querySelector(
                "#cursorSize"
            );

        const color =
            root.querySelector(
                "#cursorColor"
            );

        const visible =
            root.querySelector(
                "#cursorVisible"
            );

        const virtualVisible =
            root.querySelector(
                "#virtualVisible"
            );

        const speed =
            root.querySelector(
                "#cursorSpeed"
            );

        const status =
            root.querySelector(
                "#cursorStatus"
            );

        const preview =
            root.querySelector(
                "#cursorPreview"
            );

        const cursor =
            window.Nexora.Cursor;

        function refresh() {

            if (!cursor) {
                return;
            }

            size.value =
                cursor.getSize();

            color.value =
                cursor.getColor();

            visible.checked =
                cursor.settings.visible;

            virtualVisible.checked =
                cursor.settings.virtualVisible;

            speed.value =
                cursor.getSpeed();

            preview.textContent =
                cursor.getStyle() ===
                "default"
                    ? "↖"
                    : cursor.getStyle() ===
                        "dot"
                        ? "•"
                        : cursor.getStyle() ===
                            "ring"
                            ? "○"
                            : cursor.getStyle() ===
                                "cross"
                                ? "+"
                                : cursor.getStyle() ===
                                    "glow"
                                    ? "✦"
                                    : cursor.getStyle() ===
                                        "square"
                                        ? "□"
                                        : "↗";

            preview.style.color =
                cursor.getColor();

            preview.style.fontSize =
                `${Math.max(
                    18,
                    cursor.getSize()
                )}px`;

            status.textContent =
                `Style: ${cursor.getStyle()} • ${cursor.getSize()}px`;
        }

        buttons.forEach(
            button => {

                button.style.cssText = `
                    padding:12px;
                    border-radius:12px;
                    border:1px solid rgba(255,255,255,.08);
                    background:rgba(255,255,255,.05);
                    color:white;
                    cursor:pointer;
                `;

                button.addEventListener(
                    "click",
                    () => {

                        cursor.setStyle(
                            button.dataset.style
                        );

                        refresh();

                    }
                );
            }
        );

        size.addEventListener(
            "input",
            () => {

                cursor.setSize(
                    size.value
                );

                refresh();

            }
        );

        color.addEventListener(
            "input",
            () => {

                cursor.setColor(
                    color.value
                );

                refresh();

            }
        );

        visible.addEventListener(
            "change",
            () => {

                cursor.setVisible(
                    visible.checked
                );

                refresh();

            }
        );

        virtualVisible.addEventListener(
            "change",
            () => {

                cursor.setVirtualVisible(
                    virtualVisible.checked
                );

                refresh();

            }
        );

        speed.addEventListener(
            "input",
            () => {

                cursor.setSpeed(
                    speed.value
                );

                refresh();

            }
        );

        root.querySelector(
            "#resetCursor"
        ).addEventListener(
            "click",
            () => {

                cursor.reset();

                refresh();

            }
        );

        refresh();

        return WindowManager.create({

            appId: "cursor",

            title: "Cursor",

            icon: "⌁",

            width: 560,

            height: 520,

            minWidth: 360,

            minHeight: 400,

            content: root

        });
    }
};