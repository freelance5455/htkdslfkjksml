'use client';
import {MapContainer,TileLayer,Marker,useMapEvents} from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
const icon=new L.Icon({iconUrl:'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',iconRetinaUrl:'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',shadowUrl:'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',iconSize:[25,41],iconAnchor:[12,41]});
function Click({onPick}:{onPick:(p:[number,number])=>void}){useMapEvents({click(e){onPick([e.latlng.lat,e.latlng.lng])}});return null}
export default function MapClient({lat=31.5,lng=34.47,onPick}:{lat?:number,lng?:number,onPick:(p:[number,number])=>void}){return <MapContainer center={[lat,lng]} zoom={11} style={{height:'420px',width:'100%',borderRadius:16}}><TileLayer attribution="&copy; OpenStreetMap contributors" url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"/><Marker position={[lat,lng]} icon={icon}/><Click onPick={onPick}/></MapContainer>}
