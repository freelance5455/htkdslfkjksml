import './globals.css';import type {ReactNode} from 'react';
export default function Layout({children}:{children:ReactNode}){return <html lang="ar" dir="rtl"><head><meta name="theme-color" content="#ffffff"/><meta name="description" content="AMAZON GAZA — Gaza Digital Marketplace"/></head><body>{children}</body></html>}
