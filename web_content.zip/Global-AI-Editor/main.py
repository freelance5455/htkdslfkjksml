import os
import base64
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Global AI Editor Backend")

# For production, replace "*" with your actual frontend origin.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

async def generate_image_api(prompt: str) -> bytes:
    """DEMO ONLY: returns placeholder bytes, not a valid generated image.
    Connect a real image-generation provider here before production use.
    """
    raise NotImplementedError(
        "Image generation is not connected. Configure a real provider in generate_image_api()."
    )

async def text_to_speech_api(text: str, voice_id: str = "en-US") -> bytes:
    """DEMO ONLY: connect a real text-to-speech provider here."""
    raise NotImplementedError(
        "Text-to-speech is not connected. Configure a real provider in text_to_speech_api()."
    )

@app.get("/")
def read_root():
    return {"message": "Global AI Editor Backend is running", "mode": "starter"}

class ImageRequest(BaseModel):
    prompt: str

class AudioRequest(BaseModel):
    text: str
    voice_id: str = "en-US"

@app.post("/generate-image")
async def handle_image_generation(req: ImageRequest):
    if not req.prompt.strip():
        raise HTTPException(status_code=400, detail="Prompt cannot be empty.")
    try:
        image_bytes = await generate_image_api(req.prompt.strip())
        return {
            "status": "success",
            "image_data": base64.b64encode(image_bytes).decode("utf-8"),
            "message": "Image generated successfully",
        }
    except NotImplementedError as e:
        raise HTTPException(status_code=501, detail=str(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Image generation failed.")

@app.post("/generate-audio")
async def handle_audio_generation(req: AudioRequest):
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="Text cannot be empty.")
    try:
        audio_bytes = await text_to_speech_api(req.text.strip(), req.voice_id)
        return {
            "status": "success",
            "audio_data": base64.b64encode(audio_bytes).decode("utf-8"),
            "message": "Audio generated successfully",
        }
    except NotImplementedError as e:
        raise HTTPException(status_code=501, detail=str(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Audio generation failed.")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
