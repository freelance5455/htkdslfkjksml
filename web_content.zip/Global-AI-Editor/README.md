# Global AI Editor — Starter ZIP

This archive contains:
- `main.py`: FastAPI backend starter
- `index.html`: browser interface
- `requirements.txt`: Python dependencies

## Important
This is a starter template, not a fully connected AI product. The original sample used fake byte sequences that are not valid image/audio files. To avoid showing fake success, the provider functions in `main.py` return a clear `501 Not Implemented` response until you connect real image and text-to-speech APIs.

## Run locally
1. Install Python 3.10+.
2. In this folder, run:
   ```bash
   pip install -r requirements.txt
   uvicorn main:app --host 0.0.0.0 --port 8000
   ```
3. Open `index.html` in a browser.
4. The default backend URL is `http://127.0.0.1:8000`.

For deployment, set the backend URL in the page to your deployed API URL and configure CORS to allow only your frontend origin. Do not place provider API keys in `index.html`; keep them in server environment variables.
