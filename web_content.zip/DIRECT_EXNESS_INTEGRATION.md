# Exness Gold Bot — Direct-Exness / Phone-Only Architecture

## Important status

This version is **phone-only** and contains a clean API boundary for direct broker
integration. It does **not** pretend that an arbitrary MT5 username/password can
be used as an order API.

Exness publishes API Terms of Use, but the public Exness pages reviewed for this
project do not document a generic retail MT5 order-placement REST endpoint that
we can safely hard-code into an APK. Exness documents mobile MT5/Exness Trade
order execution, while MetaTrader 5 mobile is not a host for custom MQL5 EAs.

Therefore:

- No PC is required by the app architecture.
- No VPS is required by the app architecture.
- Do NOT enter your MT5 master password into this APK.
- Automatic live order execution is disabled until an authorized Exness API
  credential/method is supplied and implemented.
- The included `ExnessTradingApi` interface is the integration boundary.

## Build

Open this project in Android Studio and build:

Build -> Build Bundle(s) / APK(s) -> Build APK(s)

## Next integration step

If Exness grants your account an API method for trading, implement
`ExnessTradingApi` using the exact documented authentication and endpoints.
Do not invent endpoints or scrape the mobile app.

## Safety

Start with a demo account. Keep a hard stop/emergency-disable control in the app.
Never ship broker secrets in source code or log them to Logcat.
