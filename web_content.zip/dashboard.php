<?php
session_start(); require_once __DIR__ . '/includes.php'; require_login();
$pageTitle = 'Личный кабинет'; include __DIR__ . '/header.php';
?>
<section class="dashboard-head"><div><div class="eyebrow">ЛИЧНОЕ ПРОСТРАНСТВО</div><h1>Привет, <?= h($_SESSION['user']['name']) ?> <span>👋</span></h1><p>Ты успешно вошёл в свой аккаунт.</p></div><div class="status"><i></i> Вы вошли в систему</div></section>
<section class="dashboard-grid"><article class="dash-card profile-card"><div class="avatar"><?= h(mb_strtoupper(mb_substr($_SESSION['user']['name'],0,1))) ?></div><div class="eyebrow">ТВОЙ ПРОФИЛЬ</div><h2><?= h($_SESSION['user']['name']) ?></h2><p><?= h($_SESSION['user']['email']) ?></p><div class="divider"></div><div class="detail"><span>Статус</span><b>Активен</b></div><div class="detail"><span>Сессия</span><b>Авторизована</b></div></article>
<article class="dash-card welcome-card"><div class="eyebrow">ПАНЕЛЬ УПРАВЛЕНИЯ</div><h2>Всё готово.</h2><p>Регистрация и авторизация работают. Эта страница доступна только после входа в аккаунт.</p><a class="btn secondary" href="about.php">О проекте <span>→</span></a></article>
<article class="dash-card mini-card"><div class="mini-symbol">✓</div><h3>Аккаунт создан</h3><p>Данные пользователя сохранены на сервере.</p></article>
<article class="dash-card mini-card"><div class="mini-symbol">⌁</div><h3>Защищённая страница</h3><p>Без входа кабинет перенаправляет на страницу авторизации.</p></article></section>
<?php include __DIR__ . '/footer.php'; ?>