package com.myfinance.manager

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var pending: String = ""
    private var chooser: ValueCallback<Array<Uri>>? = null

    private val createDoc = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { it.write(pending.toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show()
        }
    }
    private val pdfQueue = ArrayList<Pair<String, ByteArray>>()
    private var pdfCurrent: ByteArray? = null
    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val data = pdfCurrent
        pdfCurrent = null
        if (uri != null && data != null) {
            contentResolver.openOutputStream(uri)?.use { it.write(data) }
            Toast.makeText(this, "PDF saved", Toast.LENGTH_SHORT).show()
            nextPdf()
        } else {
            pdfQueue.clear()
        }
    }

    private fun nextPdf() {
        if (pdfQueue.isEmpty()) return
        val n = pdfQueue.removeAt(0)
        pdfCurrent = n.second
        createPdf.launch(n.first)
    }

    private val pick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        chooser = null
    }

    inner class Bridge {
        @JavascriptInterface
        fun save(name: String, text: String) { pending = text; runOnUiThread { createDoc.launch(name) } }

        @JavascriptInterface
        fun savePdfs(json: String) {
            Thread {
                try {
                    val d = JSONObject(json)
                    val a = PdfMaker.summary(this@MainActivity, d)
                    val b = PdfMaker.transactions(this@MainActivity, d)
                    val base = d.optString("file", "Statement")
                    runOnUiThread {
                        pdfQueue.clear()
                        pdfQueue.add(Pair(base + "_Summary.pdf", a))
                        pdfQueue.add(Pair(base + "_Transactions.pdf", b))
                        nextPdf()
                    }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "Could not create the PDF files", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }

        @JavascriptInterface
        fun openLink(url: String) {
            // Only the creator's YouTube channel may be opened; opens in the phone's browser/YouTube app.
            if (!url.startsWith("https://youtube.com/@p2gyt")) return
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "No app found to open the link", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            blockNetworkLoads = true
            allowFileAccess = true
            allowContentAccess = false
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                val i = Intent(Intent.ACTION_GET_CONTENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                pick.launch(i); return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { web.evaluateJavascript("window.goBack&&window.goBack()") { r -> if (r != "true") super.onBackPressed() } }
}
