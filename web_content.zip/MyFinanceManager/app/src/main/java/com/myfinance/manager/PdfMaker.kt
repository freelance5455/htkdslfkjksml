package com.myfinance.manager

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale

private const val PW = 595
private const val PH = 842
private const val MX = 36f
private val C_INK = Color.parseColor("#0B1020")
private val C_CYAN = Color.parseColor("#00B8E6")
private val C_TEXT = Color.parseColor("#1B2438")
private val C_MUTE = Color.parseColor("#6B7690")
private val C_LINE = Color.parseColor("#DCE3F0")
private val C_ROW = Color.parseColor("#F1F6FD")
private val C_POS = Color.parseColor("#0A9F6B")
private val C_NEG = Color.parseColor("#E0334F")
private val C_PINK = Color.parseColor("#FF4D6D")
private val PALETTE = intArrayOf(
    Color.parseColor("#00B8E6"), Color.parseColor("#7B61FF"), Color.parseColor("#00C98B"),
    Color.parseColor("#FFB020"), Color.parseColor("#FF4D6D"), Color.parseColor("#4DA3FF"),
    Color.parseColor("#B05CFF"), Color.parseColor("#8A94A8")
)

private fun shortNum(v: Double): String = when {
    v >= 1e7 -> String.format(Locale.US, "%.1fCr", v / 1e7)
    v >= 1e5 -> String.format(Locale.US, "%.1fL", v / 1e5)
    v >= 1e3 -> String.format(Locale.US, "%.0fk", v / 1e3)
    else -> String.format(Locale.US, "%.0f", v)
}

private fun colorOf(k: String): Int = when (k) {
    "g" -> C_POS
    "r" -> C_NEG
    else -> C_TEXT
}

object PdfMaker {
    fun summary(ctx: Context, d: JSONObject): ByteArray {
        val p = PdfDoc(ctx, d, "Income & Expense Statement")
        p.buildSummary()
        return p.finish()
    }

    fun transactions(ctx: Context, d: JSONObject): ByteArray {
        val p = PdfDoc(ctx, d, "Transaction Statement")
        p.buildTransactions()
        return p.finish()
    }
}

class PdfDoc(ctx: Context, private val d: JSONObject, private val title: String) {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private lateinit var c: Canvas
    private var n = 0
    private var y = 0f
    private val logo: Bitmap? = try {
        ctx.assets.open("logo.png").use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) {
        null
    }

    // ---------- drawing helpers ----------
    private fun paint(size: Float, color: Int, bold: Boolean, align: Paint.Align): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = size
        p.color = color
        p.textAlign = align
        p.typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        return p
    }

    private fun text(
        s: String, x: Float, yy: Float, size: Float, color: Int = C_TEXT,
        bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT, maxW: Float = 0f
    ) {
        var t = s
        val p = paint(size, color, bold, align)
        if (maxW > 0f) {
            val k = p.breakText(t, true, maxW, null)
            if (k < t.length) t = t.substring(0, maxOf(k - 1, 0)) + "…"
        }
        c.drawText(t, x, yy, p)
    }

    private fun fill(l: Float, t: Float, r: Float, b: Float, color: Int, rad: Float = 0f) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        if (rad > 0f) c.drawRoundRect(RectF(l, t, r, b), rad, rad, p) else c.drawRect(l, t, r, b, p)
    }

    private fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.strokeWidth = 0.8f
        c.drawLine(x1, y1, x2, y2, p)
    }

    // ---------- page frame ----------
    private fun newPage() {
        closePage()
        n++
        val pg = doc.startPage(PdfDocument.PageInfo.Builder(PW, PH, n).create())
        page = pg
        c = pg.canvas
        header()
        y = 106f
    }

    private fun closePage() {
        val pg = page ?: return
        footer()
        doc.finishPage(pg)
        page = null
    }

    private fun header() {
        c.drawColor(Color.WHITE)
        fill(0f, 0f, PW.toFloat(), 84f, C_INK)
        fill(0f, 84f, PW.toFloat(), 87f, C_CYAN)
        val lg = logo
        if (lg != null) {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            bp.isFilterBitmap = true
            c.drawBitmap(lg, null, RectF(MX, 14f, MX + 56f, 70f), bp)
        }
        text("P2GYT", MX + 68f, 38f, 22f, C_CYAN, true)
        text(title, MX + 68f, 58f, 11f, Color.WHITE)
        text("BY: " + d.optString("by"), PW - MX, 36f, 11f, Color.WHITE, true, Paint.Align.RIGHT)
        text(d.optString("email"), PW - MX, 52f, 9f, Color.parseColor("#9FB4D9"), false, Paint.Align.RIGHT)
        text(d.optString("period"), PW - MX, 68f, 9f, C_CYAN, false, Paint.Align.RIGHT, 260f)
    }

    private fun footer() {
        line(MX, PH - 34f, PW - MX, PH - 34f, C_LINE)
        text(
            "My Finance Manager  |  by " + d.optString("by") + "  |  " + d.optString("email"),
            MX, PH - 20f, 8f, C_MUTE
        )
        text("Page $n", PW - MX, PH - 20f, 8f, C_MUTE, false, Paint.Align.RIGHT)
    }

    private fun ensure(h: Float) {
        if (y + h > PH - 44f) newPage()
    }

    private fun section(s: String) {
        ensure(40f)
        fill(MX, y, MX + 4f, y + 14f, C_CYAN)
        text(s.uppercase(Locale.US), MX + 10f, y + 11f, 11f, C_TEXT, true)
        y += 24f
    }

    // ---------- shared blocks ----------
    private fun kpis() {
        val a = d.optJSONArray("kpi") ?: return
        val cnt = a.length()
        if (cnt == 0) return
        val gap = 8f
        val w = (PW - 2 * MX - gap * (cnt - 1)) / cnt
        for (i in 0 until cnt) {
            val o = a.getJSONObject(i)
            val x = MX + i * (w + gap)
            fill(x, y, x + w, y + 54f, C_ROW, 8f)
            fill(x, y + 8f, x + 3f, y + 46f, C_CYAN)
            text(o.optString("l"), x + 10f, y + 18f, 8f, C_MUTE, false, Paint.Align.LEFT, w - 14f)
            text(o.optString("v"), x + 10f, y + 40f, 12f, colorOf(o.optString("c")), true, Paint.Align.LEFT, w - 14f)
        }
        y += 70f
    }

    private fun rows(a: JSONArray?) {
        if (a == null) return
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            ensure(22f)
            if (i % 2 == 0) fill(MX, y, PW - MX, y + 20f, C_ROW)
            val b = o.optBoolean("b", false)
            if (b) line(MX, y, PW - MX, y, C_CYAN)
            text(o.optString("l"), MX + 8f, y + 14f, 10f, C_TEXT, b, Paint.Align.LEFT, 330f)
            text(o.optString("v"), PW - MX - 8f, y + 14f, 10f, colorOf(o.optString("c")), true, Paint.Align.RIGHT, 170f)
            y += 20f
        }
        y += 12f
    }

    // ---------- charts ----------
    private fun bars() {
        val s = d.optJSONArray("series") ?: return
        section("Income vs expenses")
        ensure(210f)
        val cnt = s.length()
        var mx = 1.0
        for (i in 0 until cnt) {
            val o = s.getJSONObject(i)
            mx = maxOf(mx, o.optDouble("inc", 0.0), o.optDouble("exp", 0.0))
        }
        val top = y + 6f
        val h = 140f
        val left = MX + 34f
        val wAll = PW - MX - left
        val base = top + h
        for (g in 0..4) {
            val yy = base - h * g / 4f
            line(left, yy, PW - MX, yy, C_LINE)
            text(shortNum(mx * g / 4.0), left - 4f, yy + 3f, 7f, C_MUTE, false, Paint.Align.RIGHT)
        }
        if (cnt > 0) {
            val slot = wAll / cnt
            val bw = minOf(slot * 0.38f, 14f)
            val step = maxOf(1, Math.ceil(cnt / 16.0).toInt())
            for (i in 0 until cnt) {
                val o = s.getJSONObject(i)
                val cx = left + slot * (i + 0.5f)
                val h1 = (o.optDouble("inc", 0.0) / mx * h).toFloat()
                val h2 = (o.optDouble("exp", 0.0) / mx * h).toFloat()
                if (h1 > 0f) fill(cx - bw, base - h1, cx, base, C_CYAN)
                if (h2 > 0f) fill(cx, base - h2, cx + bw, base, C_PINK)
                if (i % step == 0) text(o.optString("l"), cx, base + 11f, 7f, C_MUTE, false, Paint.Align.CENTER)
            }
        }
        fill(left, base + 22f, left + 9f, base + 31f, C_CYAN)
        text("Income", left + 14f, base + 30f, 8f, C_TEXT)
        fill(left + 70f, base + 22f, left + 79f, base + 31f, C_PINK)
        text("Expenses", left + 84f, base + 30f, 8f, C_TEXT)
        y = base + 44f
    }

    private fun donut() {
        val a = d.optJSONArray("alloc") ?: return
        section("Where the money went")
        ensure(150f)
        var total = 0.0
        for (i in 0 until a.length()) total += maxOf(a.getJSONObject(i).optDouble("v", 0.0), 0.0)
        val cx = MX + 70f
        val cy = y + 66f
        val r = 50f
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 22f
        if (total <= 0.0) {
            p.color = C_LINE
            c.drawCircle(cx, cy, r, p)
        } else {
            var start = -90f
            for (i in 0 until a.length()) {
                val v = maxOf(a.getJSONObject(i).optDouble("v", 0.0), 0.0)
                if (v <= 0.0) continue
                val sweep = (v / total * 360.0).toFloat()
                p.color = PALETTE[i % PALETTE.size]
                c.drawArc(rect, start, maxOf(sweep - 0.8f, 0.5f), false, p)
                start += sweep
            }
        }
        var ly = y + 22f
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val v = maxOf(o.optDouble("v", 0.0), 0.0)
            val pct = if (total > 0.0) String.format(Locale.US, "%.0f%%", v / total * 100.0) else "0%"
            fill(MX + 160f, ly - 8f, MX + 170f, ly + 2f, PALETTE[i % PALETTE.size])
            text(o.optString("l"), MX + 178f, ly, 9f, C_TEXT, false, Paint.Align.LEFT, 170f)
            text(o.optString("t"), PW - MX - 44f, ly, 9f, C_TEXT, true, Paint.Align.RIGHT)
            text(pct, PW - MX, ly, 9f, C_MUTE, false, Paint.Align.RIGHT)
            ly += 20f
        }
        y += 140f
    }

    private fun cats() {
        val a = d.optJSONArray("cats") ?: return
        section("Expenses by category")
        if (a.length() == 0) {
            text("No expenses in this period", MX + 8f, y + 10f, 9f, C_MUTE)
            y += 26f
            return
        }
        var mx = 1.0
        for (i in 0 until a.length()) mx = maxOf(mx, a.getJSONObject(i).optDouble("v", 0.0))
        val bx = MX + 118f
        val bw = PW - MX - 96f - bx
        for (i in 0 until minOf(a.length(), 8)) {
            ensure(22f)
            val o = a.getJSONObject(i)
            text(o.optString("l"), MX + 4f, y + 12f, 9f, C_TEXT, false, Paint.Align.LEFT, 108f)
            fill(bx, y + 3f, bx + bw, y + 13f, C_ROW, 4f)
            val w = (o.optDouble("v", 0.0) / mx * bw).toFloat()
            if (w > 0f) fill(bx, y + 3f, bx + maxOf(w, 4f), y + 13f, PALETTE[i % PALETTE.size], 4f)
            text(o.optString("t"), PW - MX, y + 12f, 9f, C_TEXT, true, Paint.Align.RIGHT)
            y += 22f
        }
        y += 8f
    }

    // ---------- statement 1 ----------
    fun buildSummary() {
        newPage()
        text("INCOME & EXPENSE STATEMENT", MX, y + 6f, 15f, C_TEXT, true)
        y += 22f
        text(d.optString("period") + "   |   Generated " + d.optString("generated"), MX, y + 2f, 9f, C_MUTE)
        y += 20f
        kpis()
        section("Totals by head")
        rows(d.optJSONArray("heads"))
        bars()
        donut()
        cats()
        section("Position at end of period")
        rows(d.optJSONArray("snap"))
    }

    // ---------- statement 2 ----------
    private fun txHead() {
        fill(MX, y, PW - MX, y + 20f, C_INK)
        text("DATE", MX + 6f, y + 14f, 8.5f, Color.WHITE, true)
        text("NAME", MX + 62f, y + 14f, 8.5f, Color.WHITE, true)
        text("CATEGORY", MX + 214f, y + 14f, 8.5f, Color.WHITE, true)
        text("TYPE", MX + 316f, y + 14f, 8.5f, Color.WHITE, true)
        text("AMOUNT", PW - MX - 6f, y + 14f, 8.5f, Color.WHITE, true, Paint.Align.RIGHT)
        y += 22f
    }

    fun buildTransactions() {
        newPage()
        text("TRANSACTION STATEMENT", MX, y + 6f, 15f, C_TEXT, true)
        y += 22f
        val a = d.optJSONArray("tx") ?: JSONArray()
        text(
            d.optString("period") + "   |   " + a.length() + " transactions   |   Generated " + d.optString("generated"),
            MX, y + 2f, 9f, C_MUTE
        )
        y += 18f
        txHead()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val note = o.optString("note")
            val h = if (note.isEmpty()) 20f else 29f
            if (y + h > PH - 44f) {
                newPage()
                txHead()
            }
            if (i % 2 == 0) fill(MX, y, PW - MX, y + h, C_ROW)
            text(o.optString("d"), MX + 6f, y + 13f, 8.5f, C_TEXT)
            text(o.optString("n"), MX + 62f, y + 13f, 9f, C_TEXT, true, Paint.Align.LEFT, 146f)
            text(o.optString("c"), MX + 214f, y + 13f, 8.5f, C_TEXT, false, Paint.Align.LEFT, 96f)
            text(o.optString("ty"), MX + 316f, y + 13f, 8.5f, C_MUTE, false, Paint.Align.LEFT, 118f)
            text(
                o.optString("a"), PW - MX - 6f, y + 13f, 9.5f,
                if (o.optBoolean("pos")) C_POS else C_NEG, true, Paint.Align.RIGHT, 100f
            )
            if (note.isNotEmpty()) text(note, MX + 62f, y + 24f, 7.5f, C_MUTE, false, Paint.Align.LEFT, 420f)
            y += h
        }
        y += 14f
        section("Totals by transaction type")
        rows(d.optJSONArray("totals"))
    }

    fun finish(): ByteArray {
        closePage()
        val bo = ByteArrayOutputStream()
        doc.writeTo(bo)
        doc.close()
        return bo.toByteArray()
    }
}
