plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.myfinance.manager"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.myfinance.manager"
        minSdk = 24; targetSdk = 34
        versionCode = 6; versionName = "1.5"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.appcompat:appcompat:1.6.1") }
