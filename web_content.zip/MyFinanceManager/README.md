# My Finance Manager – build guide (Windows 11)

One-time setup (internet needed ONLY for this):
1. Install Android Studio (https://developer.android.com/studio). Let it install the Android SDK.
2. File > Open > select the MyFinanceManager folder. Wait for "Gradle sync" to finish (downloads Gradle + AGP once).
3. Build > Build Bundle(s)/APK(s) > Build APK(s). Click "locate" when done.
   Debug APK: app/build/outputs/apk/debug/app-debug.apk

Install on phone: copy app-debug.apk to the phone (USB/Drive), tap it, allow "Install unknown apps" for your file manager, install.
(Or enable USB debugging and press the green Run button.)

Updates: edit app/src/main/assets/index.html (the whole app), increase versionCode in app/build.gradle.kts, rebuild and install over the old APK (same signing key = data kept). Use Settings > Full JSON backup before updating.

After install the app needs no internet and has no INTERNET permission.

## PDF statements (v1.9)
Reports page (or Settings) > "Download PDF statements" > choose Whole year / Single month / All time.
Two PDFs are created on the phone (no internet): *_Summary.pdf (totals of all heads, income-vs-expense chart,
allocation donut, category bars, balances) and *_Transactions.pdf (every transaction + totals).
Android asks where to save each file. Both carry the P2GYT logo, "BY: M.S.BALAJI" and the email on every page.
