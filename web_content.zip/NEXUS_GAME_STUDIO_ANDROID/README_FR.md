# NEXUS GAME STUDIO

Projet source à convertir en APK avec Capacitor.

## Construction (ordinateur requis)
1. Installer Node.js LTS et Android Studio.
2. Décompresser le ZIP et ouvrir un terminal dans ce dossier.
3. Exécuter :
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. Dans Android Studio, construire l'APK.

## Connexion au serveur existant
L'application appelle par défaut `POST /api/games/chat` et envoie :
`{"message":"...","prompt":"..."}`
Elle accepte une réponse JSON contenant `reply`, `response` ou `message`.

IMPORTANT : cette route est une hypothèse de raccordement, elle n'est pas confirmée sur ton Render. Avant usage réel, il faut vérifier le chemin, le format JSON et CORS de ton backend existant, puis adapter le code si nécessaire. Ne colle jamais tes clés API dans l'application : conserve-les dans Render.

## Limites
Ce ZIP contient une interface mobile de départ, l'icône et la configuration Capacitor. Il n'est pas un APK compilé et ne garantit pas encore la connexion au serveur. Les moteurs de création spécialisés (génération 2D/3D, images, vidéo, audio, export de jeu) doivent être intégrés et testés séparément.
