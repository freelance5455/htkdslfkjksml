# Mi Emprendimiento: de HTML a APK

## Opción A: PWABuilder (sin instalar nada, la más fácil)
1. Sube la carpeta `www` a un hosting gratuito con HTTPS (Netlify Drop, GitHub Pages, Cloudflare Pages).
2. Entra a https://www.pwabuilder.com, pega la URL y elige Android.
3. Descarga el paquete y usa el APK que incluye (firmado para pruebas).

## Opción B: Capacitor + Android Studio (APK propio)
Requisitos: Node.js 18+, Android Studio (incluye el SDK) y JDK 17.

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

En Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
Por línea de comandos:

    cd android
    ./gradlew assembleDebug      (en Windows: gradlew.bat assembleDebug)

El APK queda en `android/app/build/outputs/apk/debug/app-debug.apk`.
Cópialo al celular, ábrelo y acepta instalar de origen desconocido.

## Notas
- Los datos se guardan en el almacenamiento local de la app. Usa Exportar respaldo del Resumen con frecuencia: si desinstalas la app, se pierden.
- Para publicar en Play Store necesitas un APK/AAB firmado en modo release.
- Para cambiar el icono, reemplaza los PNG de `www/icons`, o usa `@capacitor/assets`.
