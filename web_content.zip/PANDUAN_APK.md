# Panduan Build APK Android (HTML to APK) & Aktivasi Auto-OTP Gmail

## 1. Perbedaan Utama Versi APK Ini
- **100% Mandiri Tanpa Server Web/Netlify:** Seluruh tampilan dan logika aplikasi berada di dalam `index.html` dengan navigasi bawah khas aplikasi Android (*Sewa & Stok*, *Pesanan & OTP*, *Developer*), sehingga tidak ada lagi pesan error *"Web butuh server Netlify aktif"*.
- **Siap Dikonversi ke APK:** Anda bisa langsung memilih `index.html` (atau file ZIP ini) di aplikasi **HTML to APK** pada HP Android Anda untuk menghasilkan file `.apk`.

---

## 2. Cara Mengaktifkan Pembaca OTP Moonton Otomatis & Sinkron Stok Antar-HP di APK
Karena sistem keamanan Android tidak mengizinkan file HTML lokal membuka port IMAP (`993`) langsung dari HP pembeli, APK ini menggunakan **Google Apps Script** (layanan gratis resmi milik Google sendiri, tanpa hosting/domain/Netlify):

1. Buka browser di HP/PC, masuk ke **[script.google.com](https://script.google.com)** menggunakan akun **Gmail Induk** (`harapanindubapam@gmail.com`).
2. Klik **Project Baru**, hapus semua kode bawaan, lalu salin-tempel seluruh isi file **`GoogleAppsScript_OTP.gs`** yang ada di dalam ZIP ini.
3. Klik **Terapkan (Deploy)** → **Deployment baru**.
4. Klik ikon gerigi di samping "Pilih jenis" → pilih **Aplikasi Web (Web App)**.
   - **Jalankan sebagai:** `Saya` (`harapanindubapam@gmail.com`)
   - **Yang memiliki akses:** `Siapa saja` (`Anyone`)
5. Klik **Terapkan**, izinkan akses ke Gmail Anda, lalu salin **URL Aplikasi Web** yang muncul.
6. Buka APK **FirasX Rent** → Login sebagai Developer (`FirasXDev` / `Cgh1yg6`) → tempel URL tersebut ke kolom **URL Mesin Pembaca Gmail APK**, isi Gmail Induk & App Password 16 digit, lalu klik **Simpan & Cek Otomatis**.

Setelah langkah ini selesai:
- Kode OTP Moonton yang masuk ke **email bertitik** (`h.ara.panindubapam@gmail.com`, dll.) otomatis terbaca di dalam APK.
- Setiap kali Developer menambah/menghapus stok atau mengubah harga di APK, semua HP pembeli langsung melihat perubahan terbaru secara otomatis.
