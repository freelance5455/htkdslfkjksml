Tactical merged update: includes the existing Tactical app plus the 2018 teams update. Root index.html is the APK converter entry point.
