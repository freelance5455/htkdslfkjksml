AGIT KASIR — Versi demo web untuk Android

Cara mencoba:
1. Buka file index.html dengan browser modern (Chrome disarankan).
2. Tambahkan produk terlebih dahulu melalui tombol Tambah produk.
3. Isi harga jual, modal/HPP per unit, dan stok awal.
4. Catat penjualan dan pengeluaran.
5. Lihat laporan bulanan, lalu gunakan Cadangkan data secara berkala.

Catatan:
- Ini versi web offline yang bisa dicoba di browser, belum APK Android yang terpasang.
- Data tersimpan lokal pada browser/perangkat yang digunakan. Membersihkan data browser dapat menghapus data; buat cadangan JSON.
- Penjualan mengurangi stok produk otomatis.
- Laba dihitung dari penjualan dikurangi HPP produk terjual dan pengeluaran tercatat. Hindari mencatat pembelian stok penuh sebagai biaya sekaligus memasukkan HPP unit yang sama ke produk, agar laba tidak terhitung dua kali.
- Versi demo belum memakai login, sinkronisasi cloud, atau penguncian PIN.
