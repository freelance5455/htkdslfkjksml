'use strict';
/* PATHOS — local-first roadmap manager. All data stays in this browser (localStorage). */
const K='pathos.v1',$=s=>document.querySelector(s);
const def=()=>({roadmaps:[],inbox:[],journal:[],log:[],cats:['Web Development','Communication','Ethical Hacking','Fitness','Finance','Trading','Study','Personal Growth','Future Goals'],settings:{name:'',accent:'#c9a96e',theme:'dark',compact:false,exported:null}});
let S;try{S={...def(),...JSON.parse(localStorage.getItem(K)||'{}')};S.settings={...def().settings,...S.settings}}catch(e){S=def()}
const uid=()=>Math.random().toString(36).slice(2,9)+Date.now().toString(36).slice(-3);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const td=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
function save(){try{localStorage.setItem(K,JSON.stringify(S))}catch(e){toast('Could not save — storage is full or blocked. Export a backup.')}}
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('show'),2800)}
const R=id=>S.roadmaps.find(r=>r.id==id),tasks=r=>r.stages.flatMap(s=>s.tasks);
const cur=r=>tasks(r).find(t=>t.status!=='done'&&!t.skipped);
const pct=r=>{const a=tasks(r);return a.length?Math.round(a.filter(t=>t.status==='done').length*100/a.length):0};
const isDone=r=>tasks(r).length>0&&tasks(r).every(t=>t.status==='done'||t.skipped)&&tasks(r).some(t=>t.status==='done');
const touch=r=>r.updated=Date.now();
const mins=s=>{const m=/(\d+(?:\.\d+)?)\s*(min|m\b|h|hr|hour)/i.exec(s||'');return m?(/^m/i.test(m[2])?+m[1]:+m[1]*60):0};
const fmtM=m=>m>=60?(m/60).toFixed(1).replace('.0','')+' h':m+' min';
/* status: done | skipped | locked | avail | prog */
function st(r,t){if(t.status==='done')return'done';if(t.skipped)return'skipped';const pr=t.status==='prog'?'prog':'avail';return(r.free||t.unlocked||cur(r)===t)?pr:'locked'}
const mkT=o=>({id:uid(),title:'New task',desc:'',dur:'',due:'',prio:'Medium',status:'todo',notes:'',links:[],...o});
const mkS=o=>({id:uid(),title:'New stage',notes:'',tasks:[],...o});
const mkR=o=>({id:uid(),title:'Untitled roadmap',icon:'✦',desc:'',category:'Personal Growth',difficulty:'Beginner',start:td(),target:'',pinned:false,archived:false,later:false,free:false,notes:'',original:'',stages:[],created:Date.now(),updated:Date.now(),...o});

/* ---------- Parser (local, no AI) ---------- */
function parse(txt){
 const L=txt.replace(/\r/g,'').split('\n'),h1=L.filter(l=>/^#\s/.test(l.trim())).length,hh=L.some(l=>/^#{2,3}\s/.test(l.trim()));
 let title='',intro=[],stages=[],cs=null,ct=null,hd=0;
 const nb=l=>l.replace(/^(#{1,6}\s*|[-*•▪◦]\s+|\d+[.)]\s+)/,'').replace(/^\[[ xX]\]\s*/,'').replace(/\*\*|__/g,'').trim();
 const add=(l,ind)=>{if(!cs){cs={title:'Tasks',tasks:[]};stages.push(cs)}let t=nb(l),d='';if(t.length>110){const i=t.search(/[.:;—–]\s/);const k=i>20&&i<110?i+1:110;d=t.slice(k).trim();t=t.slice(0,k).trim()}ct={title:t,desc:d,ind,kids:[]};cs.tasks.push(ct)};
 for(const raw of L){const l=raw.trim();if(!l||/^[-=_*]{3,}$/.test(l))continue;
  const ind=raw.length-raw.trimStart().length,b=/^([-*•▪◦]\s|\d+[.)]\s|\[[ xX]\])/.test(l);
  if(/^#\s/.test(l)&&h1==1&&hh&&!cs&&!title){title=nb(l);continue}
  const head=/^#{1,3}\s/.test(l)||(!b&&(/^\**(stage|phase|week|module|level|part|month|milestone)\s*[\d#]/i.test(l)||/^\*\*[^*]+\*\*:?$/.test(l)||(/:$/.test(l)&&l.length<80)));
  if(head){hd++;cs={title:nb(l).replace(/:$/,''),tasks:[]};stages.push(cs);ct=null}
  else if(b){if(ct&&ind>ct.ind)ct.kids.push(nb(l));else add(l,ind)}
  else if(/^day\s*\d+/i.test(l)||(!ct&&cs))add(l,ind);
  else if(ct)ct.desc+=(ct.desc?'\n':'')+l;
  else intro.push(l)}
 const all=stages.flatMap(s=>s.tasks);let conf=hd?'good':'medium';
 if(!hd&&stages.length==1&&all.filter(t=>t.kids.length).length>=2){stages=all.map(t=>({title:t.title,tasks:t.kids.length?t.kids.map(k=>({title:k,desc:'',kids:[]})):[{title:t.title,desc:t.desc,kids:[]}]}));conf='medium'}
 else all.forEach(t=>{if(t.kids.length)t.desc=(t.desc?t.desc+'\n':'')+t.kids.map(k=>'- '+k).join('\n')});
 stages=stages.filter(s=>s.tasks.length);
 if(!stages.length){const ls=L.map(x=>nb(x.trim())).filter(Boolean);stages=ls.length?[{title:'Imported',tasks:ls.map(t=>({title:t.slice(0,110),desc:t.length>110?t:'',kids:[]}))}]:[];conf='low'}
 return{title,intro:intro.join('\n'),stages,conf}}
const SAMPLE=`# Communication Skills
## Stage 1: Foundation
- Learn the basics of active listening (30 min)
- Record yourself speaking for 2 minutes and review it
## Stage 2: Daily Practice
1. Start one short conversation every day
2. Write down what went well and what to improve
## Stage 3: Real-Life Conversations
- Join a meetup or group discussion
  - Prepare two questions in advance
- Give a 5 minute talk to a friend
## Stage 4: Confidence Building
- Reflect on your progress at the end of each week`;
function toStages(ps){return ps.map(s=>mkS({title:s.title,tasks:s.tasks.map(t=>{const m=/(\d+(?:\.\d+)?\s*(?:min|mins|minutes|hrs?|hours?))/i.exec(t.title+' '+t.desc);return mkT({title:t.title,desc:t.desc,dur:m?m[1]:'',links:((t.title+' '+t.desc).match(/https?:\/\/[^\s)]+/g)||[])})})}))}

/* ---------- Modal ---------- */
function modal(title,fields,cb,okLabel='Save'){const m=document.createElement('div');m.className='modal';
 m.innerHTML=`<form><h3>${title}</h3>${fields.map(f=>`<label>${f.l}${f.o?`<select name="${f.k}">${f.o.map(o=>`<option ${o==f.v?'selected':''}>${esc(o)}</option>`).join('')}</select>`:f.t=='area'?`<textarea name="${f.k}" rows="${f.r||4}">${esc(f.v)}</textarea>`:`<input name="${f.k}" type="${f.t||'text'}" value="${esc(f.v)}" ${f.list?'list="cats"':''}>`}</label>`).join('')}<datalist id="cats">${S.cats.map(c=>`<option value="${esc(c)}">`).join('')}</datalist><div class="row"><button type="button" class="ghost" onclick="this.closest('.modal').remove()">Cancel</button><button class="gold">${okLabel}</button></div></form>`;
 m.querySelector('form').onsubmit=e=>{e.preventDefault();cb(Object.fromEntries(new FormData(e.target)));m.remove()};document.body.append(m);const i=m.querySelector('input,textarea');i&&i.focus()}
const addCat=c=>{c=(c||'').trim();if(c&&!S.cats.includes(c))S.cats.push(c)};

/* ---------- Actions ---------- */
let mode='timeline',open=new Set(),collapsed=new Set(),F={q:'',cat:'',status:''};
const find=(r,tid)=>{for(const s of r.stages){const i=s.tasks.findIndex(t=>t.id==tid);if(i>-1)return{s,i,t:s.tasks[i]}}};
const done=(r)=>{save();render()};
function tog(rid,tid){const r=R(rid),{t}=find(r,tid);if(st(r,t)=='locked')return;
 if(t.status=='done'){t.status='todo';delete t.doneAt;S.log=S.log.filter(l=>l.tid!=tid)}else{t.status='done';t.doneAt=td();S.log.push({d:td(),rid,tid})}
 touch(r);if(isDone(r)){if(!r.completedAt){r.completedAt=td();toast('✦ Roadmap complete. Well done.')}}else{delete r.completedAt;if(t.status=='done'){const n=cur(r);toast(n?'Done. Next: '+n.title.slice(0,40):'Done')}}done(r)}
function setT(rid,tid,k){const r=R(rid),{t}=find(r,tid);
 if(k=='unlock')t.unlocked=!t.unlocked;if(k=='skip')t.skipped=!t.skipped;if(k=='prog')t.status=t.status=='prog'?'todo':'prog';if(k=='plan')t.plan=t.plan==td()?'':td();touch(r);done(r)}
function note(rid,tid,v){const r=R(rid);if(tid=='_r')r.notes=v;else{const f=find(r,tid);f?f.t.notes=v:r.stages.find(s=>s.id==tid).notes=v}touch(r);save()}
function editT(rid,tid){const r=R(rid),{t}=find(r,tid);modal('Edit step',[{k:'title',l:'Title',v:t.title},{k:'desc',l:'Instructions',t:'area',v:t.desc,r:6},{k:'dur',l:'Estimated duration (e.g. 30 min)',v:t.dur},{k:'due',l:'Due date',t:'date',v:t.due},{k:'prio',l:'Priority',o:['Low','Medium','High'],v:t.prio},{k:'links',l:'Resource links (one per line)',t:'area',v:t.links.join('\n'),r:3}],d=>{Object.assign(t,d,{links:d.links.split('\n').map(x=>x.trim()).filter(Boolean)});touch(r);done(r)})}
function addT(rid,sid){const r=R(rid),s=r.stages.find(x=>x.id==sid),t=mkT();s.tasks.push(t);open.add(t.id);touch(r);save();editT(rid,t.id);render()}
function delT(rid,tid){if(!confirm('Delete this step?'))return;const r=R(rid),f=find(r,tid);f.s.tasks.splice(f.i,1);touch(r);done(r)}
function dupT(rid,tid){const r=R(rid),f=find(r,tid);f.s.tasks.splice(f.i+1,0,{...f.t,id:uid(),status:'todo',doneAt:undefined,links:[...f.t.links]});touch(r);done(r)}
const mv=(a,i,d)=>{const j=i+d;if(j<0||j>=a.length)return;[a[i],a[j]]=[a[j],a[i]]};
function mvT(rid,tid,d){const r=R(rid),f=find(r,tid);mv(f.s.tasks,f.i,d);touch(r);done(r)}
function addS(rid){modal('New stage',[{k:'title',l:'Stage name',v:''}],d=>{const r=R(rid);r.stages.push(mkS({title:d.title||'New stage'}));touch(r);done(r)})}
function editS(rid,sid){const r=R(rid),s=r.stages.find(x=>x.id==sid);modal('Rename stage',[{k:'title',l:'Stage name',v:s.title}],d=>{s.title=d.title||s.title;touch(r);done(r)})}
function delS(rid,sid){if(!confirm('Delete this stage and all its steps?'))return;const r=R(rid);r.stages=r.stages.filter(s=>s.id!=sid);touch(r);done(r)}
function mvS(rid,sid,d){const r=R(rid);mv(r.stages,r.stages.findIndex(s=>s.id==sid),d);touch(r);done(r)}
function colS(sid){collapsed.has(sid)?collapsed.delete(sid):collapsed.add(sid);render()}
function op(tid){open.has(tid)?open.delete(tid):open.add(tid);render()}
function cont(rid){const t=cur(R(rid));if(!t)return;const f=find(R(rid),t.id);collapsed.delete(f.s.id);open.add(t.id);render();setTimeout(()=>document.getElementById('t'+t.id)?.scrollIntoView({behavior:'smooth',block:'center'}),50)}
function rmForm(r,cb,title){modal(title,[{k:'title',l:'Title',v:r.title},{k:'icon',l:'Icon (emoji or symbol)',v:r.icon},{k:'category',l:'Category (type your own to create one)',v:r.category,list:1},{k:'difficulty',l:'Difficulty',o:['Beginner','Intermediate','Advanced'],v:r.difficulty},{k:'desc',l:'Description',t:'area',v:r.desc},{k:'start',l:'Start date',t:'date',v:r.start},{k:'target',l:'Target completion date',t:'date',v:r.target}],cb)}
function editR(id){const r=R(id);rmForm(r,d=>{addCat(d.category);Object.assign(r,d);touch(r);done(r)},'Edit roadmap')}
function togR(id,k){const r=R(id);r[k]=!r[k];touch(r);done(r);if(k=='archived')toast(r.archived?'Archived':'Restored')}
function dupR(id){const r=R(id),c=JSON.parse(JSON.stringify(r));c.id=uid();c.title+=' (copy)';c.created=c.updated=Date.now();delete c.completedAt;c.pinned=false;c.stages.forEach(s=>{s.id=uid();s.tasks.forEach(t=>{t.id=uid();t.status='todo';delete t.doneAt;delete t.unlocked;delete t.skipped;delete t.plan})});S.roadmaps.push(c);save();location.hash='#/r/'+c.id;toast('Duplicated with progress reset')}
let undo=null;
function delR(id){if(!confirm('Delete this roadmap permanently?'))return;undo={r:R(id),log:S.log.filter(l=>l.rid==id)};S.roadmaps=S.roadmaps.filter(r=>r.id!=id);S.log=S.log.filter(l=>l.rid!=id);save();location.hash='#/roadmaps';toast('Deleted. Settings → Undo last delete')}
function undoDel(){if(!undo)return;S.roadmaps.push(undo.r);S.log.push(...undo.log);undo=null;save();render();toast('Restored')}
function newManual(){rmForm(mkR(),d=>{addCat(d.category);const r=mkR(d);r.stages.push(mkS({title:'Stage 1',tasks:[mkT({title:'First step'})]}));S.roadmaps.push(r);save();location.hash='#/r/'+r.id})}  
function addToday(){const v=$('#addsel').value;if(!v)return;const[rid,tid]=v.split('|');setT(rid,tid,'plan')}

/* ---------- Views ---------- */
function applyTheme(){const s=S.settings,h=document.documentElement;h.dataset.theme=s.theme;h.style.setProperty('--a',s.accent);document.body.classList.toggle('compact',s.compact)}
function nav(){const p=route()[0],L=[['','Home'],['roadmaps','Roadmaps'],['today','Today'],['new','Add roadmap'],['notes','Notes & inbox'],['stats','Progress'],['settings','Settings']];
 $('#side').innerHTML=`<div class="logo" style="padding:0 12px 14px;font-size:1.1rem">PATHOS</div>`+L.map(([h,n])=>`<a href="#/${h}" class="${p==h?'on':''}" onclick="document.body.classList.remove('nav')">${n}</a>`).join('')+(S.roadmaps.some(r=>r.pinned&&!r.archived)?'<small class="mu">Pinned</small>':'')+S.roadmaps.filter(r=>r.pinned&&!r.archived).map(r=>`<a href="#/r/${r.id}" class="${location.hash=='#/r/'+r.id?'on':''}">${esc(r.icon)} ${esc(r.title)}</a>`).join('')}
const route=()=>location.hash.slice(2).split('/');
function render(){applyTheme();const[p,id]=route(),v={'':dash,roadmaps:list,r:detail,today,new:imp,notes,stats,settings}[p]||dash;$('#app').innerHTML=v(id);nav();if(p=='roadmaps')fill();if(p=='new')pv();document.body.classList.remove('nav')}
const empty=(m,b)=>`<div class="empty"><p>${m}</p>${b||''}</div>`;
const bar=p=>`<div class="bar"><i style="width:${p}%"></i></div>`;
const rcard=r=>`<a href="#/r/${r.id}" class="card" style="display:block;color:inherit"><div class="row"><span style="font-size:1.4rem">${esc(r.icon)}</span><h3 class="sp">${esc(r.title)}</h3>${r.pinned?'<span class="tag">pinned</span>':''}</div><div class="mu">${esc(r.category)} · ${tasks(r).length} steps</div>${bar(pct(r))}<div class="mu">${pct(r)}% complete${cur(r)?' · Next: '+esc(cur(r).title.slice(0,50)):''}</div></a>`;
function tl(){const d=td(),o=[];S.roadmaps.filter(r=>!r.archived).forEach(r=>tasks(r).forEach(t=>{if(t.skipped)return;const dn=t.status=='done';if(dn&&t.doneAt!=d)return;const k=dn?'done':t.due&&t.due<d?'over':t.due==d?'due':t.plan==d?'plan':null;if(k)o.push({r,t,k})}));const P={High:0,Medium:1,Low:2};return o.sort((a,b)=>(a.k=='done')-(b.k=='done')||(b.k=='over')-(a.k=='over')||P[a.t.prio]-P[b.t.prio])}
function trow({r,t,k}){const x=st(r,t);return`<div class="task ${x}"><button class="dot" ${x=='locked'?'disabled title="Locked until earlier steps are done"':''} onclick="tog('${r.id}','${t.id}')" aria-label="Toggle complete">${x=='done'?'✓':''}</button><div class="tb"><div class="tt">${esc(t.title)}</div><div class="mu">${esc(r.icon)} <a href="#/r/${r.id}">${esc(r.title)}</a> ${k=='over'?'<span class="tag over">overdue '+t.due+'</span>':''}${t.prio=='High'?'<span class="tag High">High</span>':''}${t.dur?` <span class="tag">${esc(t.dur)}</span>`:''}${x=='locked'?'<span class="tag">locked</span>':''}</div></div></div>`}
function dash(){const A=S.roadmaps.filter(r=>!r.archived),act=A.filter(r=>!r.later&&!isDone(r)&&tasks(r).length),all=A.flatMap(tasks),dn=all.filter(t=>t.status=='done').length,h=new Date().getHours(),g=h<12?'Good morning':h<18?'Good afternoon':'Good evening',T=tl(),d=td();
 const rec=[...A].sort((a,b)=>b.updated-a.updated).slice(0,3),up=A.flatMap(r=>tasks(r).filter(t=>t.due>=d&&t.status!='done').map(t=>({r,t}))).sort((a,b)=>a.t.due>b.t.due?1:-1).slice(0,4);
 return`<h1>${g}${S.settings.name?', '+esc(S.settings.name):''}</h1><p class="mu">One step at a time.</p>
 ${exportNag()}<div class="grid s4"><div class="card stat"><b>${A.length}</b><span>Roadmaps</span></div><div class="card stat"><b>${act.length}</b><span>Active</span></div><div class="card stat"><b>${A.filter(isDone).length}</b><span>Completed</span></div><div class="card stat"><b>${all.length?Math.round(dn*100/all.length)+'%':'—'}</b><span>Tasks done (${dn}/${all.length})</span></div></div>
 <div class="card"><h2>Continue</h2>${act.length?act.map(rcard).join(''):empty('No active roadmaps yet.','<a class="gold" href="#/new">Create your first roadmap</a>')}</div>
 <div class="grid c2"><div class="card"><h2>Today</h2>${T.length?T.slice(0,5).map(trow).join('')+'<a href="#/today">See all</a>':empty('Nothing scheduled for today.','<a href="#/today">Plan your day</a>')}</div>
 <div class="card"><h2>Upcoming deadlines</h2>${up.length?up.map(({r,t})=>`<div class="task"><div class="tb"><div class="tt">${esc(t.title)}</div><div class="mu">${t.due} · <a href="#/r/${r.id}">${esc(r.title)}</a></div></div></div>`).join(''):empty('No dated steps. Dates are optional.')}</div></div>
 <div class="card"><h2>Recently updated</h2>${rec.length?rec.map(rcard).join(''):empty('Nothing yet.')}</div>`}
function exportNag(){const e=S.settings.exported,n=S.roadmaps.length;if(!n)return'';const days=e?(Date.now()-e)/864e5:99;return days>14?`<div class="card"><span class="mu">${e?'Last backup: '+new Date(e).toLocaleDateString():'You have never exported a backup.'}</span> <a href="#/settings">Back up now</a></div>`:''}
function list(){return`<div class="row"><h1 class="sp">Roadmaps</h1><a class="gold" href="#/new">+ New</a></div><div class="card"><input id="q" placeholder="Search roadmaps, stages, tasks" value="${esc(F.q)}" oninput="F.q=this.value;fill()"><div class="row" style="margin-top:8px"><select id="fc" onchange="F.cat=this.value;fill()" style="flex:1"><option value="">All categories</option>${S.cats.map(c=>`<option ${F.cat==c?'selected':''}>${esc(c)}</option>`).join('')}</select><select onchange="F.status=this.value;fill()" style="flex:1">${['','Active','Completed','Archived','Start later','Pinned'].map(s=>`<option value="${s}" ${F.status==s?'selected':''}>${s||'All statuses'}</option>`).join('')}</select></div></div><div id="list"></div>`}
function fill(){const q=F.q.toLowerCase(),el=$('#list');if(!el)return;
 const m=S.roadmaps.filter(r=>{const s=F.status;if(s=='Archived'?!r.archived:r.archived)return false;if(s=='Active'&&(r.later||isDone(r)))return false;if(s=='Completed'&&!isDone(r))return false;if(s=='Start later'&&!r.later)return false;if(s=='Pinned'&&!r.pinned)return false;if(F.cat&&r.category!=F.cat)return false;
  return!q||[r.title,r.desc,r.category,...r.stages.map(x=>x.title),...tasks(r).map(t=>t.title+' '+t.desc)].join(' ').toLowerCase().includes(q)}).sort((a,b)=>b.pinned-a.pinned||b.updated-a.updated);
 const lat=m.filter(r=>r.later),main=m.filter(r=>!r.later);
 el.innerHTML=(main.length?main.map(rcard).join(''):S.roadmaps.length?empty('No roadmaps match.'):empty('No roadmaps yet.','<a class="gold" href="#/new">Create one</a>'))+(lat.length?'<h2>Roadmaps to start later</h2>'+lat.map(rcard).join(''):'')}
function taskHTML(r,t){const x=st(r,t),c=cur(r)===t,o=open.has(t.id)&&mode!='compact';
 return`<div class="task ${x} ${c?'cur':''}" id="t${t.id}"><button class="dot" ${x=='locked'?'disabled title="Locked"':''} onclick="tog('${r.id}','${t.id}')" aria-label="Toggle complete">${x=='done'?'✓':x=='prog'?'◐':''}</button><div class="tb"><div class="tt" onclick="op('${t.id}')">${esc(t.title)}</div>
 <div class="row mu" style="gap:4px">${c?'<span class="tag" style="color:var(--a)">current</span>':''}<span class="tag">${{done:'Completed',skipped:'Skipped',locked:'Locked',avail:'Available',prog:'In progress'}[x]}</span>${t.prio!='Medium'?`<span class="tag ${t.prio}">${t.prio}</span>`:''}${t.dur?`<span class="tag">${esc(t.dur)}</span>`:''}${t.due?`<span class="tag ${t.due<td()&&x!='done'?'over':''}">due ${t.due}</span>`:''}</div>
 ${o?`<div class="det">${esc(t.desc)||'<span class="mu">No instructions yet.</span>'}${t.links.length?'<div>'+t.links.map(l=>`<div><a href="${esc(l)}" target="_blank" rel="noopener noreferrer">${esc(l)}</a></div>`).join('')+'</div>':''}<textarea rows="3" placeholder="Notes for this step" oninput="note('${r.id}','${t.id}',this.value)">${esc(t.notes)}</textarea><div class="row"><button class="sm" onclick="editT('${r.id}','${t.id}')">Edit</button><button class="sm" onclick="setT('${r.id}','${t.id}','prog')">${t.status=='prog'?'Stop':'Start'}</button><button class="sm" onclick="setT('${r.id}','${t.id}','plan')">${t.plan==td()?'Remove from today':'Add to today'}</button>${x=='locked'||t.unlocked?`<button class="sm" onclick="setT('${r.id}','${t.id}','unlock')">${t.unlocked?'Re-lock':'Unlock'}</button>`:''}${x!='done'?`<button class="sm" onclick="setT('${r.id}','${t.id}','skip')">${t.skipped?'Unskip':'Skip'}</button>`:''}<button class="sm" onclick="mvT('${r.id}','${t.id}',-1)">↑</button><button class="sm" onclick="mvT('${r.id}','${t.id}',1)">↓</button><button class="sm" onclick="dupT('${r.id}','${t.id}')">Duplicate</button><button class="sm danger" onclick="delT('${r.id}','${t.id}')">Delete</button></div></div>`:''}</div></div>`}
function detail(id){const r=R(id);if(!r)return empty('Roadmap not found.','<a href="#/roadmaps">Back to roadmaps</a>');const c=cur(r),cs=c&&find(r,c.id).s,p=pct(r),a=tasks(r);
 return`<div class="card"><div class="row"><span style="font-size:1.8rem">${esc(r.icon)}</span><h1 class="sp">${esc(r.title)}</h1></div><p>${esc(r.desc)}</p><div class="row mu"><span class="tag">${esc(r.category)}</span><span class="tag">${r.difficulty}</span>${r.start?`<span class="tag">start ${r.start}</span>`:''}${r.target?`<span class="tag">target ${r.target}</span>`:''}${r.completedAt?`<span class="tag" style="color:var(--a)">completed ${r.completedAt}</span>`:''}</div>${bar(p)}<div class="mu">${p}% · ${a.filter(t=>t.status=='done').length} of ${a.length} done${c?` · ${esc(cs.title)} → ${esc(c.title)}`:''}</div>
 <div class="row" style="margin-top:12px">${c?`<button class="gold" onclick="cont('${r.id}')">Continue next step</button>`:''}<button class="sm" onclick="editR('${r.id}')">Edit</button><button class="sm" onclick="togR('${r.id}','pinned')">${r.pinned?'Unpin':'Pin'}</button><button class="sm" onclick="togR('${r.id}','later')">${r.later?'Start now':'Start later'}</button><button class="sm" onclick="dupR('${r.id}')">Duplicate</button><button class="sm" onclick="togR('${r.id}','archived')">${r.archived?'Restore':'Archive'}</button><button class="sm danger" onclick="delR('${r.id}')">Delete</button></div>
 <label style="display:flex;gap:8px;align-items:center;margin-top:12px"><input type="checkbox" style="width:20px;min-height:20px" ${r.free?'checked':''} onchange="R('${r.id}').free=this.checked;save();render()"> Free navigation (work on any step in any order)</label></div>
 <div class="row tabs">${['timeline','checklist','compact'].map(m=>`<button class="sm ${mode==m?'on':''}" onclick="mode='${m}';render()">${m[0].toUpperCase()+m.slice(1)}</button>`).join('')}<button class="sm ${mode=='calendar'?'on':''}" onclick="mode='calendar';render()">Dated</button></div>
 ${mode=='calendar'?dated(r):`<div class="${mode=='timeline'?'tl':''} ${mode=='compact'?'compact-v':''}">${r.stages.map((s,i)=>{const sd=s.tasks.filter(t=>t.status=='done').length,col=collapsed.has(s.id);return`<div class="stage"><div class="sh" onclick="colS('${s.id}')"><h3>${i+1}. ${esc(s.title)}</h3><span class="mu">${sd}/${s.tasks.length} ${col?'▸':'▾'}</span></div>${col?'':`<div class="tasks">${s.tasks.map(t=>taskHTML(r,t)).join('')}</div><div class="row" style="margin-top:8px"><button class="sm" onclick="addT('${r.id}','${s.id}')">+ Step</button><button class="sm" onclick="editS('${r.id}','${s.id}')">Rename</button><button class="sm" onclick="mvS('${r.id}','${s.id}',-1)">↑</button><button class="sm" onclick="mvS('${r.id}','${s.id}',1)">↓</button><button class="sm danger" onclick="delS('${r.id}','${s.id}')">Delete</button></div><textarea rows="2" style="margin-top:8px" placeholder="Stage notes" oninput="note('${r.id}','${s.id}',this.value)">${esc(s.notes)}</textarea>`}</div>`}).join('')}</div>`}
 <button class="sm" onclick="addS('${r.id}')">+ Add stage</button>
 <div class="card" style="margin-top:16px"><h2>Roadmap notes</h2><textarea rows="5" placeholder="Lessons, problems, ideas…" oninput="note('${r.id}','_r',this.value)">${esc(r.notes)}</textarea></div>
 ${r.original?`<details class="card"><summary>Original imported text</summary><div class="pre mu" style="margin-top:8px">${esc(r.original)}</div></details>`:''}`}
function dated(r){const a=tasks(r).filter(t=>t.due).sort((x,y)=>x.due>y.due?1:-1);return a.length?`<div class="card">${a.map(t=>`<div class="task ${st(r,t)}"><div class="tb"><div class="tt">${t.due}</div><div>${esc(t.title)} <span class="tag">${st(r,t)}</span></div></div></div>`).join('')}</div>`:empty('No steps have due dates. Add one from a step’s Edit form.')}
function today(){const T=tl(),dn=T.filter(x=>x.k=='done').length,m=T.filter(x=>x.k!='done').reduce((s,x)=>s+mins(x.t.dur),0),opts=S.roadmaps.filter(r=>!r.archived).flatMap(r=>tasks(r).filter(t=>t.status!='done'&&!t.skipped&&t.plan!=td()&&st(r,t)!='locked').map(t=>`<option value="${r.id}|${t.id}">${esc(r.title)} — ${esc(t.title.slice(0,50))}</option>`));
 return`<h1>Today</h1><p class="mu">${new Date().toDateString()}</p><div class="card"><div class="mu">${dn} of ${T.length} complete${m?' · about '+fmtM(m)+' remaining (from your estimates)':''}</div>${bar(T.length?Math.round(dn*100/T.length):0)}</div>
 <div class="card">${T.length?T.map(x=>trow(x)+`<div class="mu" style="margin:-4px 0 6px 44px"><a href="#/r/${x.r.id}">Open roadmap</a></div>`).join(''):empty('Nothing scheduled. Give a step a due date, or add one below.')}</div>
 <div class="card"><h2>Add to today’s plan</h2>${opts.length?`<div class="row"><select id="addsel" style="flex:1"><option value="">Choose a step</option>${opts.join('')}</select><button class="gold" onclick="addToday()">Add</button></div>`:'<span class="mu">No available steps.</span>'}</div>`}
function imp(){return`<h1>Add a roadmap</h1><div class="card"><h2>Paste a roadmap</h2><p class="mu">Paste from ChatGPT or anywhere. Parsing runs on your device, with no AI or API key. Check the preview before saving.</p><textarea id="raw" rows="9" placeholder="Paste your roadmap here"></textarea><div class="row" style="margin-top:8px"><button class="gold" onclick="doParse()">Detect structure</button><button onclick="$('#raw').value=SAMPLE">Use sample format</button></div></div><div id="pv"></div><div class="card"><h2>Create manually</h2><p class="mu">Start empty and add stages and steps yourself.</p><button onclick="newManual()">Create from scratch</button></div>`}
let P=null;
function doParse(){const v=$('#raw').value;if(!v.trim())return toast('Paste some text first');P=parse(v);P.raw=v;pv()}
function pv(){const el=$('#pv');if(!el||!P)return;const w={low:'Structure not confidently detected. Every line became a step. Edit or delete before saving; nothing was invented.',medium:'No clear stage headings found; grouping is a best guess. Please review.',good:'Stages detected. Review and edit below.'}[P.conf];
 el.innerHTML=`<div class="card"><h2>Preview</h2><p class="mu">${w}</p><label>Roadmap title<input id="pt" value="${esc(P.title)}" oninput="P.title=this.value"></label><label>Category<input list="cats" id="pc" value="Personal Growth"></label><datalist id="cats">${S.cats.map(c=>`<option value="${esc(c)}">`).join('')}</datalist>
 ${P.stages.map((s,i)=>`<div class="stage"><div class="row"><input class="sp" value="${esc(s.title)}" oninput="P.stages[${i}].title=this.value"><button class="sm danger" onclick="P.stages.splice(${i},1);pv()">✕</button></div>${s.tasks.map((t,j)=>`<div class="row" style="margin:6px 0 0 14px"><input class="sp" value="${esc(t.title)}" oninput="P.stages[${i}].tasks[${j}].title=this.value"><button class="sm danger" onclick="P.stages[${i}].tasks.splice(${j},1);pv()">✕</button></div>`).join('')}</div>`).join('')}
 <button class="gold" onclick="saveImp()" ${P.stages.length?'':'disabled'}>Save roadmap</button></div>`}
function saveImp(){const cat=$('#pc').value.trim()||'Personal Growth';addCat(cat);const r=mkR({title:P.title.trim()||'Imported roadmap',category:cat,desc:P.intro.slice(0,500),original:P.raw,stages:toStages(P.stages.filter(s=>s.tasks.length))});S.roadmaps.push(r);P=null;save();location.hash='#/r/'+r.id;toast('Saved. Edit any step on the roadmap page.')}
function notes(){const J=[...S.journal].reverse();return`<h1>Notes & inbox</h1><div class="card"><h2>Quick capture</h2><div class="row"><input id="ib" class="sp" placeholder="An idea or future roadmap" style="flex:1"><button class="gold" onclick="addIb()">Add</button></div>${S.inbox.map(i=>`<div class="row" style="margin-top:8px"><span class="sp">${esc(i.t)}</span><button class="sm" onclick="ibRm('${i.id}')">→ Start later</button><button class="sm danger" onclick="S.inbox=S.inbox.filter(x=>x.id!='${i.id}');save();render()">✕</button></div>`).join('')||'<p class="mu">Inbox is empty.</p>'}</div>
 <div class="card"><h2>Learning journal</h2><label>Type<select id="jt">${['Journal','Lesson learned','Problem faced','Question for ChatGPT','Idea to practise'].map(x=>`<option>${x}</option>`).join('')}</select></label><textarea id="jx" rows="4" placeholder="Write here"></textarea><button class="gold" style="margin-top:8px" onclick="addJ()">Save entry</button></div>
 ${J.map(j=>`<div class="card"><div class="mu">${j.d} · ${esc(j.type)}</div><div style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(j.t)}</div><button class="sm danger" onclick="S.journal=S.journal.filter(x=>x.id!='${j.id}');save();render()">Delete</button></div>`).join('')}`}
function addIb(){const v=$('#ib').value.trim();if(!v)return;S.inbox.push({id:uid(),t:v});save();render()}
function ibRm(id){const i=S.inbox.find(x=>x.id==id);S.roadmaps.push(mkR({title:i.t,later:true}));S.inbox=S.inbox.filter(x=>x.id!=id);save();toast('Added to "Roadmaps to start later"');render()}
function addJ(){const v=$('#jx').value.trim();if(!v)return;S.journal.push({id:uid(),d:td(),type:$('#jt').value,t:v});save();render()}
function stats(){const A=S.roadmaps.filter(r=>!r.archived),all=A.flatMap(tasks),dn=all.filter(t=>t.status=='done'),days=[...Array(14)].map((_,i)=>{const d=new Date();d.setDate(d.getDate()-13+i);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}),cnt=days.map(d=>S.log.filter(l=>l.d==d).length),mx=Math.max(1,...cnt),tm=dn.reduce((s,t)=>s+mins(t.dur),0);
 return`<h1>Progress</h1>${all.length?'':empty('Add a roadmap to see your progress.')}<div class="grid s4"><div class="card stat"><b>${dn.length}</b><span>Completed</span></div><div class="card stat"><b>${all.length-dn.length}</b><span>Remaining</span></div><div class="card stat"><b>${S.log.filter(l=>l.d>=days[7]).length}</b><span>Last 7 days</span></div><div class="card stat"><b>${tm?fmtM(tm):'—'}</b><span>Estimated time of completed steps</span></div></div>
 <div class="card"><h2>Activity, last 14 days</h2><div class="row" style="align-items:flex-end;height:80px;gap:4px;flex-wrap:nowrap">${cnt.map((c,i)=>`<div class="sp" title="${days[i]}: ${c}" style="background:${c?'var(--a)':'var(--bd)'};height:${c?Math.max(10,c/mx*100):4}%;border-radius:3px"></div>`).join('')}</div></div>
 <div class="card"><h2>By roadmap</h2>${A.map(r=>`<div><a href="#/r/${r.id}">${esc(r.icon)} ${esc(r.title)}</a><span class="mu"> ${pct(r)}%</span>${bar(pct(r))}</div>`).join('')||'<span class="mu">None yet.</span>'}</div>
 <div class="card"><h2>Completed roadmaps</h2>${S.roadmaps.filter(r=>r.completedAt).map(r=>`<div>${esc(r.title)} <span class="mu">${r.completedAt}</span></div>`).join('')||'<span class="mu">None yet.</span>'}</div>`}
function settings(){const s=S.settings;return`<h1>Settings</h1><div class="card"><label>Your name<input value="${esc(s.name)}" oninput="S.settings.name=this.value;save()"></label><label>Accent colour<input type="color" value="${s.accent}" oninput="S.settings.accent=this.value;save();applyTheme()"></label><label>Theme<select onchange="S.settings.theme=this.value;save();render()"><option value="dark" ${s.theme=='dark'?'selected':''}>Dark</option><option value="light" ${s.theme=='light'?'selected':''}>Light</option></select></label><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" style="width:20px;min-height:20px" ${s.compact?'checked':''} onchange="S.settings.compact=this.checked;save();render()"> Compact layout</label>
 <label>Add a category<input id="nc" placeholder="e.g. Languages" onchange="addCat(this.value);save();toast('Category added');this.value=''"></label></div>
 <div class="card"><h2>Backup</h2><p class="mu">Data lives only in this browser. Clearing site data or switching browsers will erase it, so export regularly.<br>Last export: ${s.exported?new Date(s.exported).toLocaleString():'never'}</p><div class="row"><button class="gold" onclick="exp()">Export JSON</button><button onclick="$('#imf').click()">Import JSON</button><input id="imf" type="file" accept=".json,application/json" hidden onchange="impJ(this.files[0])">${undo?'<button onclick="undoDel()">Undo last delete</button>':''}<button class="danger" onclick="clr()">Clear all data</button></div></div>`}
function exp(){const b=new Blob([JSON.stringify(S,null,1)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='pathos-backup-'+td()+'.json';a.click();S.settings.exported=Date.now();save();render()}
function impJ(f){if(!f)return;const rd=new FileReader();rd.onload=()=>{try{const d=JSON.parse(rd.result);if(!Array.isArray(d.roadmaps))throw 0;if(!confirm('Replace ALL current data with this backup ('+d.roadmaps.length+' roadmaps)?'))return;S={...def(),...d};S.settings={...def().settings,...d.settings};save();render();toast('Backup restored')}catch(e){toast('That file is not a valid PATHOS backup')}};rd.readAsText(f)}
function clr(){if(!confirm('Delete ALL roadmaps, notes and settings? Export a backup first.'))return;if(!confirm('This cannot be undone. Continue?'))return;S=def();save();location.hash='#/';render()}
addEventListener('hashchange',render);render();
