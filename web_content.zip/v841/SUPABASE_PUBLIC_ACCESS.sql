-- Khajura School Management v8.43
-- Supabase Dashboard -> SQL Editor -> New query -> paste and Run.
-- This enables public READ ONLY access to notices; it does not allow public edits.

begin;

grant usage on schema public to anon, authenticated;

alter table public.notices enable row level security;
drop policy if exists "Public can read notices" on public.notices;
create policy "Public can read notices"
on public.notices
for select
to anon, authenticated
using (true);

-- Current Supabase projects may require explicit table-level grants.
grant select on table public.notices to anon, authenticated;

-- Public student listing is no longer needed in the home page, but keep its existing
-- limited-column policy/grant only if your app still uses it elsewhere.
notify pgrst, 'reload schema';
commit;
