**Direct**

Not connected

## Connect with a friend

No server in the middle. Scan each other's QR codes (or trade the two codes by text), and your devices link up directly.

Your name

Send this invite to your friend

Paste their reply here

Paste the invite you received Send this reply back