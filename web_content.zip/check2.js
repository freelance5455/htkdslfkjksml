
// === v4.4 TR Teste: feedback táctil dos botões ===
(function(){
  function isButton(el){
    return el && el.closest && el.closest('button, .btn, [role="button"], input[type="button"], input[type="submit"]');
  }
  document.addEventListener('pointerdown', function(e){
    var b = isButton(e.target);
    if (!b) return;
    b.classList.add('v44-btn-pressed');
  }, {passive:true});
  function release(e){
    var b = isButton(e.target);
    if (b) {
      b.classList.remove('v44-btn-pressed');
      if (b.tagName === 'BUTTON' && /guardar|salvar|save/i.test((b.innerText || b.value || '').trim())) {
        b.classList.add('v44-save-ok');
        setTimeout(function(){ b.classList.remove('v44-save-ok'); }, 900);
        showV44Toast('Guardado ✓');
      }
    }
  }
  document.addEventListener('pointerup', release, {passive:true});
  document.addEventListener('pointercancel', release, {passive:true});
  document.addEventListener('pointerleave', function(e){
    var b = isButton(e.target);
    if (b) b.classList.remove('v44-btn-pressed');
  }, {passive:true});

  window.showV44Toast = function(msg){
    var t = document.querySelector('.v44-toast');
    if (!t) {
      t = document.createElement('div');
      t.className = 'v44-toast';
      t.setAttribute('aria-live','polite');
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(function(){ t.classList.remove('show'); }, 1100);
  };
})();
