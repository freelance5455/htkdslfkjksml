
RTT Ledger - Android APK Source
================================

This folder contains the HTML file ready to convert to Android APK using Website2APK or similar wrapper.

Files:
- index.html : Main ledger dashboard (offline, only Export PDF available)

Features in Android version:
- Uses APKX v1 offline PDF engine (from your sample.html) - no external libraries
- Export PDF: Tap "Export PDF" -> Android print screen -> choose "Save as PDF" -> pick folder
- All data stored locally on device (localStorage)
- Username/password authentication (same as web version)
- Add/Edit/Delete customers and ledger entries
- Backup/Restore via copy/paste (works offline)
- No Excel export (hidden) - as requested, only PDF in Android version

How to create APK:

Option 1 - Website2APK Builder (https://www.website2apk.com):
1. Open Website2APK Builder
2. Choose "Create Android App from Website" -> "Local HTML File"
3. Select index.html from this folder
4. App Name: RTT Ledger
5. Package Name: com.raajeswari.textile.ledger
6. Enable: File Access, JavaScript, Local Storage, Allow File Upload
7. Set Orientation: Portrait
8. Build APK

Option 2 - Using Android Studio WebView (manual):
1. Create new Android project with WebView
2. Load file:///android_asset/index.html
3. Enable JavaScript, DOM Storage, File Access
4. Add permissions for storage if needed

Important settings for PDF to work:
- WebView must support window.print() -> triggers APKX print layer
- Enable JavaScript and DOM storage
- Allow blob: and data: URLs

The PDF export logic used is exactly from your attached sample.html (APKX v1):
- Renders HTML to canvas via SVG foreignObject (offline)
- Converts canvas to JPEG
- Embeds JPEG into PDF (pure JS, no external libs)
- Shows preview with "Save as PDF" button that calls native print

For backup/restore on Android:
- Backup creates JSON text you can copy to WhatsApp/Keep/Gmail
- Restore accepts pasted text or file selection

Credentials:
- First launch: Create account (username/password + security question)
- Data stays on device only, salted + hashed (SHA256 pure JS, 20000 iterations)
- Recovery via security question or recovery code

Initial data:
- 253 customers from RTT_CUSTOMER_DATABASE.xlsx preloaded on first launch
- You can add/edit/delete and add ledger transactions

