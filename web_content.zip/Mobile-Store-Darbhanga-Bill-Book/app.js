/* Mobile Store Darbhanga — offline bill book (vanilla JS, no dependencies).
 * Data lives in localStorage; the first run seeds itself from data.js. */
(function () {
  "use strict";

  var LS_KEY = "msd_billbook_v1";

  // ---------- state ----------
  var state = load();
  var cart = [];
  var editing = { product: null, customer: null };

  function load() {
    try {
      var raw = localStorage.getItem(LS_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) { /* fall through to bundled data */ }
    var seed = (typeof BILL_BOOK_DATA === "object" && BILL_BOOK_DATA) || {};
    return {
      settings: seed.settings || {},
      products: seed.products || [],
      customers: seed.customers || [],
      invoices: seed.invoices || [],
      counters: seed.counters || {}
    };
  }
  function save() { localStorage.setItem(LS_KEY, JSON.stringify(state)); }

  // ---------- helpers ----------
  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function inr(n) {
    n = Number(n) || 0;
    return "\u20B9" + n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function ddmmyyyy(iso) {
    if (!iso) return "";
    var p = String(iso).slice(0, 10).split("-");
    return p.length === 3 ? p[2] + "/" + p[1] + "/" + p[0] : iso;
  }
  function fyOf(iso) {
    var y = parseInt(String(iso).slice(0, 4), 10), m = parseInt(String(iso).slice(5, 7), 10);
    var start = m >= 4 ? y : y - 1;
    var a = String(start % 100), b = String((start + 1) % 100);
    return (a.length < 2 ? "0" + a : a) + "-" + (b.length < 2 ? "0" + b : b);
  }
  var ONES = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
    "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  var TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
  function two(n) { return n < 20 ? ONES[n] : TENS[Math.floor(n / 10)] + (n % 10 ? " " + ONES[n % 10] : ""); }
  function three(n) {
    var h = Math.floor(n / 100), r = n % 100, out = h ? ONES[h] + " Hundred" : "";
    return (r ? (out ? out + " " : "") + two(r) : out) || "";
  }
  function words(n) {
    n = Math.round(Number(n) || 0);
    if (n === 0) return "Rupees Zero Only";
    var parts = [], crore = Math.floor(n / 1e7); n %= 1e7;
    var lakh = Math.floor(n / 1e5); n %= 1e5;
    var thousand = Math.floor(n / 1e3); n %= 1000;
    if (crore) parts.push(two(crore) + " Crore");
    if (lakh) parts.push(two(lakh) + " Lakh");
    if (thousand) parts.push(two(thousand) + " Thousand");
    if (n) parts.push(three(n));
    return "Rupees " + parts.join(" ") + " Only";
  }
  function splitGst(taxable) {
    var cgst = Math.round(taxable * 9) / 100, sgst = Math.round(taxable * 9) / 100;
    return [Math.round(cgst * 100) / 100, Math.round(sgst * 100) / 100];
  }
  function todayIso() {
    var d = new Date(), m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + "-" + (m < 10 ? "0" + m : m) + "-" + (day < 10 ? "0" + day : day);
  }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }

  function toast(msg, isErr) {
    var t = document.createElement("div");
    t.className = "toast" + (isErr ? " err" : "");
    t.textContent = msg;
    $("toastWrap").appendChild(t);
    setTimeout(function () { t.remove(); }, 3200);
  }

  function openModal(html) { $("modalBox").innerHTML = html; $("modalOverlay").hidden = false; }
  function closeModal() { $("modalOverlay").hidden = true; }
  $("modalOverlay").addEventListener("click", function (e) { if (e.target === this) closeModal(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeModal(); });

  // ---------- tabs ----------
  $("nav").addEventListener("click", function (e) {
    var btn = e.target.closest("[data-tab]");
    if (!btn) return;
    document.querySelectorAll(".nav-btn").forEach(function (b) { b.classList.toggle("active", b === btn); });
    document.querySelectorAll(".tab").forEach(function (s) { s.classList.toggle("active", s.id === "tab-" + btn.dataset.tab); });
    if (btn.dataset.tab === "invoices") renderInvoices();
    if (btn.dataset.tab === "products") renderProducts();
    if (btn.dataset.tab === "customers") renderCustomers();
    if (btn.dataset.tab === "settings") renderSettings();
  });

  // ================= NEW BILL =================
  function renderProductResults() {
    var q = ($("productSearch").value || "").toLowerCase().trim();
    var hits = state.products.filter(function (p) {
      var hay = (p.brand + " " + p.model + " " + (p.variant || "")).toLowerCase();
      return !q || hay.indexOf(q) !== -1;
    }).slice(0, 8);
    $("productResults").innerHTML = hits.map(function (p) {
      var stock = p.stock > 0 ? p.stock + " in stock" : "out of stock";
      return '<div class="product-hit"><div><strong>' + esc(p.brand + " " + p.model) + "</strong>" +
        '<div class="meta">' + esc(p.variant || "") + " \u00B7 HSN " + esc(p.hsn) + " \u00B7 " + stock + "</div></div>" +
        '<div style="text-align:right"><div class="price">' + inr(p.selling_price) + "</div>" +
        '<button class="btn sm primary" data-add="' + esc(p.id) + '" ' + (p.stock > 0 ? "" : "disabled") + ">Add</button></div></div>";
    }).join("") || '<p class="hint">No products found. Add them under the Products tab.</p>';
  }

  $("productSearch").addEventListener("input", renderProductResults);
  $("productResults").addEventListener("click", function (e) {
    var btn = e.target.closest("[data-add]");
    if (!btn) return;
    addToCart(btn.dataset.add);
  });

  function addToCart(productId) {
    var p = state.products.find(function (x) { return x.id === productId; });
    if (!p) return;
    var line = cart.find(function (l) { return l.product_id === productId; });
    if (line) { line.qty += 1; }
    else {
      cart.push({
        product_id: p.id, description: [p.brand, p.model, p.variant].filter(Boolean).join(", "),
        hsn: p.hsn || "85171200", qty: 1, rate: Number(p.selling_price) || 0,
        imei: p.imei1 || "", gst_rate: p.gst_rate || 18
      });
    }
    renderCart();
  }

  function cartTotals() {
    var taxable = 0, cgst = 0, sgst = 0;
    cart.forEach(function (l) {
      var t = Math.round(l.qty * l.rate * 100) / 100;
      var g = splitGst(t);
      taxable += t; cgst += g[0]; sgst += g[1];
    });
    taxable = Math.round(taxable * 100) / 100;
    cgst = Math.round(cgst * 100) / 100;
    sgst = Math.round(sgst * 100) / 100;
    var raw = Math.round((taxable + cgst + sgst) * 100) / 100;
    var grand = Math.round(raw);
    return { taxable: taxable, cgst: cgst, sgst: sgst, roundOff: Math.round((grand - raw) * 100) / 100, grand: grand };
  }

  function renderCart() {
    var body = $("cartBody");
    body.innerHTML = cart.map(function (l, i) {
      var t = Math.round(l.qty * l.rate * 100) / 100;
      var g = splitGst(t);
      return "<tr>" +
        '<td>' + (i + 1) + "</td>" +
        "<td><strong>" + esc(l.description) + '</strong><div class="meta" style="font-size:12px;color:#64748B">HSN ' + esc(l.hsn) + "</div></td>" +
        '<td><input data-cart="' + i + '" data-field="imei" value="' + esc(l.imei) + '" placeholder="IMEI" style="max-width:150px" /></td>' +
        '<td><input data-cart="' + i + '" data-field="qty" type="number" min="1" value="' + l.qty + '" style="max-width:70px" /></td>' +
        '<td><input data-cart="' + i + '" data-field="rate" type="number" min="0" step="0.01" value="' + l.rate + '" style="max-width:110px" /></td>' +
        "<td>18%</td>" +
        '<td class="num">' + inr(t + g[0] + g[1]) + "</td>" +
        '<td><button class="btn sm danger" data-remove="' + i + '">\u00D7</button></td>' +
        "</tr>";
    }).join("");
    $("cartEmpty").hidden = cart.length > 0;
    var s = cartTotals();
    $("sumTaxable").textContent = inr(s.taxable);
    $("sumCgst").textContent = inr(s.cgst);
    $("sumSgst").textContent = inr(s.sgst);
    $("sumRound").textContent = (s.roundOff >= 0 ? "+" : "\u2212") + inr(Math.abs(s.roundOff));
    $("sumGrand").textContent = inr(s.grand);
    renderProductResults();
  }

  $("cartBody").addEventListener("input", function (e) {
    var input = e.target.closest("[data-cart]");
    if (!input) return;
    var line = cart[Number(input.dataset.cart)];
    if (!line) return;
    if (input.dataset.field === "qty") line.qty = Math.max(1, parseInt(input.value, 10) || 1);
    if (input.dataset.field === "rate") line.rate = Math.max(0, parseFloat(input.value) || 0);
    if (input.dataset.field === "imei") line.imei = input.value;
    if (input.dataset.field !== "imei") renderCart(); else updateTotalsOnly();
  });
  function updateTotalsOnly() {
    var s = cartTotals();
    $("sumTaxable").textContent = inr(s.taxable);
    $("sumCgst").textContent = inr(s.cgst);
    $("sumSgst").textContent = inr(s.sgst);
    $("sumRound").textContent = (s.roundOff >= 0 ? "+" : "\u2212") + inr(Math.abs(s.roundOff));
    $("sumGrand").textContent = inr(s.grand);
  }
  $("cartBody").addEventListener("click", function (e) {
    var btn = e.target.closest("[data-remove]");
    if (!btn) return;
    cart.splice(Number(btn.dataset.remove), 1);
    renderCart();
  });

  // customer phone lookup
  $("custPhone").addEventListener("change", function () {
    var phone = this.value.trim();
    if (!phone) { $("custHint").textContent = ""; return; }
    var c = state.customers.find(function (x) { return x.phone === phone; });
    if (c) {
      $("custName").value = c.name; $("custAddress").value = c.address || ""; $("custGstin").value = c.gstin || "";
      $("custHint").textContent = "Existing customer found — details filled from khata.";
    } else {
      $("custHint").textContent = "New customer — will be added to khata on save.";
    }
  });

  function clearBillForm() {
    cart = [];
    ["custPhone", "custName", "custAddress", "custGstin", "billNotes", "productSearch"].forEach(function (id) { $(id).value = ""; });
    $("custHint").textContent = "";
    renderCart();
  }

  function saveBill(andPrint) {
    var name = $("custName").value.trim(), phone = $("custPhone").value.trim();
    if (!name || !phone) { toast("Customer name and phone are required.", true); return; }
    if (!cart.length) { toast("Add at least one product to the bill.", true); return; }

    // stock validation
    for (var i = 0; i < cart.length; i++) {
      var p = state.products.find(function (x) { return x.id === cart[i].product_id; });
      if (p && p.stock < cart[i].qty) { toast("Insufficient stock for " + p.model + " (available " + p.stock + ").", true); return; }
    }

    var dateIso = todayIso();
    var fy = fyOf(dateIso);
    var key = "invoice_" + fy;
    state.counters[key] = (state.counters[key] || 0) + 1;
    var invoiceNo = "MSD/" + fy + "/" + String(state.counters[key]).padStart(4, "0");

    var items = cart.map(function (l) {
      var t = Math.round(l.qty * l.rate * 100) / 100, g = splitGst(t);
      return {
        product_id: l.product_id, description: l.description, hsn: l.hsn, imei: l.imei.trim(),
        qty: l.qty, rate: l.rate, gst_rate: 18, taxable: t, cgst: g[0], sgst: g[1],
        amount: Math.round((t + g[0] + g[1]) * 100) / 100
      };
    });
    var s = cartTotals();
    var inv = {
      id: uid(), invoice_no: invoiceNo, date: dateIso,
      customer: { name: name, phone: phone, address: $("custAddress").value.trim(), gstin: $("custGstin").value.trim() },
      items: items, payment_mode: $("payMode").value, notes: $("billNotes").value.trim(),
      taxable_total: s.taxable, cgst_total: s.cgst, sgst_total: s.sgst,
      round_off: s.roundOff, grand_total: s.grand, amount_in_words: words(s.grand),
      created_at: new Date().toISOString()
    };
    state.invoices.unshift(inv);

    // upsert khata + stock movement
    var cust = state.customers.find(function (x) { return x.phone === phone; });
    if (!cust) { state.customers.push({ id: uid(), name: name, phone: phone, address: inv.customer.address, gstin: inv.customer.gstin }); }
    else { cust.name = name; if (inv.customer.address) cust.address = inv.customer.address; if (inv.customer.gstin) cust.gstin = inv.customer.gstin; }
    cart.forEach(function (l) {
      var p = state.products.find(function (x) { return x.id === l.product_id; });
      if (p) p.stock -= l.qty;
    });

    save();
    clearBillForm();
    toast("Invoice " + invoiceNo + " saved — " + inr(s.grand));
    if (andPrint) { printInvoice(inv.id); }
    renderInvoices();
  }
  $("savePrintBtn").addEventListener("click", function () { saveBill(true); });
  $("saveBtn").addEventListener("click", function () { saveBill(false); });
  $("clearBtn").addEventListener("click", clearBillForm);

  // ================= INVOICES =================
  function renderInvoices() {
    var q = ($("invoiceSearch").value || "").toLowerCase().trim();
    var rows = state.invoices.filter(function (v) {
      if (!q) return true;
      return (v.invoice_no + " " + v.customer.name + " " + v.customer.phone).toLowerCase().indexOf(q) !== -1;
    });
    $("invoiceRows").innerHTML = rows.map(function (v) {
      return "<tr>" +
        '<td class="num">' + esc(v.invoice_no) + "</td>" +
        "<td>" + ddmmyyyy(v.date) + "</td>" +
        "<td>" + esc(v.customer.name) + "</td>" +
        '<td class="num">' + esc(v.customer.phone) + "</td>" +
        '<td><span class="badge ' + v.payment_mode.toLowerCase() + '">' + esc(v.payment_mode) + "</span></td>" +
        "<td>" + v.items.length + "</td>" +
        '<td class="num"><strong>' + inr(v.grand_total) + "</strong></td>" +
        '<td><button class="btn sm" data-view="' + esc(v.id) + '">View</button> ' +
        '<button class="btn sm" data-print="' + esc(v.id) + '">Print</button> ' +
        '<button class="btn sm danger" data-del-inv="' + esc(v.id) + '">Delete</button></td>' +
        "</tr>";
    }).join("");
    $("invoiceEmpty").textContent = rows.length ? "" : (q ? "No invoices match your search." : "No invoices yet — create your first bill.");
  }
  $("invoiceSearch").addEventListener("input", renderInvoices);
  $("invoiceRows").addEventListener("click", function (e) {
    var view = e.target.closest("[data-view]"), print = e.target.closest("[data-print]"), del = e.target.closest("[data-del-inv]");
    if (view) viewInvoice(view.dataset.view);
    if (print) printInvoice(print.dataset.print);
    if (del) {
      var inv = state.invoices.find(function (x) { return x.id === del.dataset.delInv; });
      openModal('<h2>Delete invoice ' + esc(inv ? inv.invoice_no : "") + '?</h2>' +
        '<p class="hint">Stock will be returned to the catalog. This cannot be undone.</p>' +
        '<div class="modal-actions"><button class="btn ghost" onclick="document.getElementById(\'modalOverlay\').hidden=true">Cancel</button>' +
        '<button class="btn primary" id="confirmDelInv">Delete</button></div>');
      $("confirmDelInv").onclick = function () {
        state.invoices = state.invoices.filter(function (x) { return x.id !== del.dataset.delInv; });
        save(); closeModal(); renderInvoices(); toast("Invoice deleted.");
      };
    }
  });

  // ================= INVOICE PRINT (A4) =================
  function invoiceSheet(inv) {
    var shop = state.settings || {};
    var rows = inv.items.map(function (it, i) {
      return "<tr>" +
        "<td>" + (i + 1) + "</td>" +
        "<td><strong>" + esc(it.description) + "</strong>" + (it.imei ? '<div style="font-size:10.5px;color:#4B5563">IMEI: <span style="font-family:var(--mono)">' + esc(it.imei) + "</span></div>" : "") + "</td>" +
        '<td class="num">' + esc(it.hsn) + "</td>" +
        '<td style="text-align:center">' + it.qty + "</td>" +
        '<td class="num">' + inr(it.rate) + "</td>" +
        '<td class="num">' + inr(it.taxable) + "</td>" +
        '<td class="num">' + inr(it.cgst) + "</td>" +
        '<td class="num">' + inr(it.sgst) + "</td>" +
        '<td class="num"><strong>' + inr(it.amount) + "</strong></td>" +
        "</tr>";
    }).join("");
    return '<div class="invoice-sheet">' +
      '<div class="inv-head"><div><h1>' + esc(shop.name || "Mobile Store Darbhanga") + "</h1>" +
      "<p>" + esc(shop.tagline || "") + "</p><p>" + esc(shop.address || "") + "</p>" +
      "<p>Phone: " + esc(shop.phone || "") + (shop.email ? " \u00B7 " + esc(shop.email) : "") + "</p></div>" +
      '<div class="right"><div>GSTIN: ' + esc(shop.gstin || "") + "</div><div>State: " + esc(shop.state_code || "") + "</div>" +
      (shop.upi_id ? "<div>UPI: " + esc(shop.upi_id) + "</div>" : "") + "</div></div>" +
      '<div class="inv-title"><h2>TAX INVOICE</h2><div class="inv-meta">' +
      "<div>Invoice No: <span class='num'>" + esc(inv.invoice_no) + "</span></div>" +
      "<div>Date: <span class='num'>" + ddmmyyyy(inv.date) + "</span></div>" +
      "<div>Payment: " + esc(inv.payment_mode) + "</div></div></div>" +
      '<div class="inv-parties"><div class="box"><h3>Billed To</h3><strong>' + esc(inv.customer.name) + "</strong><br/>" +
      "Phone: " + esc(inv.customer.phone) + "<br/>" + esc(inv.customer.address || "\u2014") +
      (inv.customer.gstin ? "<br/>GSTIN: " + esc(inv.customer.gstin) : "") + "</div>" +
      '<div class="box"><h3>Invoice Summary</h3>Items: ' + inv.items.length +
      "<br/>Taxable Value: <strong>" + inr(inv.taxable_total) + "</strong>" +
      "<br/>CGST 9% + SGST 9% (18% GST)<br/>Grand Total: <strong>" + inr(inv.grand_total) + "</strong></div></div>" +
      '<table class="inv-table"><thead><tr><th>#</th><th>Description</th><th>HSN</th><th>Qty</th><th>Rate</th><th>Taxable</th><th>CGST 9%</th><th>SGST 9%</th><th>Amount</th></tr></thead>' +
      "<tbody>" + rows + "</tbody></table>" +
      '<div class="totals">' +
      '<div class="sum-row"><span>Taxable Value</span><strong>' + inr(inv.taxable_total) + "</strong></div>" +
      '<div class="sum-row"><span>CGST @ 9%</span><strong>' + inr(inv.cgst_total) + "</strong></div>" +
      '<div class="sum-row"><span>SGST @ 9%</span><strong>' + inr(inv.sgst_total) + "</strong></div>" +
      '<div class="sum-row"><span>Round Off</span><strong>' + (inv.round_off >= 0 ? "+" : "\u2212") + inr(Math.abs(inv.round_off)) + "</strong></div>" +
      '<div class="sum-row grand"><span>Grand Total</span><strong>' + inr(inv.grand_total) + "</strong></div></div>" +
      '<div class="words"><strong>Amount in Words:</strong> ' + esc(inv.amount_in_words) + "</div>" +
      (inv.notes ? '<div class="words"><strong>Notes:</strong> ' + esc(inv.notes) + "</div>" : "") +
      '<div class="inv-foot"><div><strong>Terms &amp; Conditions</strong><br/>' + esc(shop.terms || "").replace(/\n/g, "<br/>") + "</div>" +
      '<div style="text-align:right"><div class="sig">For ' + esc(shop.name || "Mobile Store Darbhanga") + "<br/>Authorised Signatory</div></div></div>" +
      '<p style="text-align:center;font-size:11px;color:#6B7280;margin-top:14px">This is a computer generated invoice \u00B7 18% GST (CGST 9% + SGST 9%) \u00B7 ' + esc(shop.name || "") + ", Darbhanga</p>" +
      "</div>";
  }

  function printInvoice(id) {
    var inv = state.invoices.find(function (x) { return x.id === id; });
    if (!inv) { toast("Invoice not found.", true); return; }
    $("printArea").innerHTML = invoiceSheet(inv);
    setTimeout(function () { window.print(); }, 60);
  }

  function viewInvoice(id) {
    var inv = state.invoices.find(function (x) { return x.id === id; });
    if (!inv) return;
    openModal('<div class="card-head"><h2>Invoice ' + esc(inv.invoice_no) + '</h2><button class="btn ghost" id="modalClose">\u00D7 Close</button></div>' +
      '<div style="overflow:auto;max-height:60vh">' + invoiceSheet(inv) + "</div>" +
      '<div class="modal-actions"><button class="btn primary" id="modalPrint">Print</button></div>');
    $("modalClose").onclick = closeModal;
    $("modalPrint").onclick = function () { printInvoice(id); closeModal(); };
  }

  // ================= PRODUCTS =================
  function renderProducts() {
    var q = ($("productFilter").value || "").toLowerCase().trim();
    var rows = state.products.filter(function (p) {
      return !q || (p.brand + " " + p.model + " " + (p.variant || "")).toLowerCase().indexOf(q) !== -1;
    });
    $("productRows").innerHTML = rows.map(function (p) {
      return "<tr>" +
        "<td><strong>" + esc(p.model) + "</strong></td>" +
        "<td>" + esc(p.brand) + "</td>" +
        "<td>" + esc(p.variant || "\u2014") + "</td>" +
        '<td class="num">' + esc(p.hsn) + "</td>" +
        '<td class="num">' + inr(p.selling_price) + "</td>" +
        '<td><span class="badge ' + (p.stock < 3 ? "low" : "ok") + '">' + p.stock + (p.stock < 3 ? " \u00B7 low" : "") + "</span></td>" +
        '<td><span class="imei-chip">' + esc(p.imei1 || "\u2014") + "</span></td>" +
        '<td><button class="btn sm" data-edit-p="' + esc(p.id) + '">Edit</button> ' +
        '<button class="btn sm danger" data-del-p="' + esc(p.id) + '">Delete</button></td>' +
        "</tr>";
    }).join("");
    $("productEmpty").textContent = rows.length ? "" : "No products found.";
  }
  $("productFilter").addEventListener("input", renderProducts);

  function productModal(p) {
    editing.product = p ? p.id : null;
    var v = function (k) { return esc(p ? (p[k] != null ? p[k] : "") : (k === "hsn" ? "85171200" : k === "gst_rate" ? 18 : k === "category" ? "Smartphone" : "")); };
    openModal('<h2>' + (p ? "Edit Product" : "Add Product") + '</h2>' +
      '<div class="form-row"><label>Brand<input id="pBrand" value="' + v("brand") + '" placeholder="Samsung"/></label>' +
      '<label>Model<input id="pModel" value="' + v("model") + '" placeholder="Galaxy S24 Ultra"/></label></div>' +
      '<div class="form-row"><label>Variant (storage / colour)<input id="pVariant" value="' + v("variant") + '" placeholder="256GB / Titanium Black"/></label>' +
      '<label>Category<input id="pCategory" value="' + v("category") + '" placeholder="Smartphone / Accessory"/></label></div>' +
      '<div class="form-row"><label>HSN Code<input id="pHsn" value="' + v("hsn") + '"/></label>' +
      '<label>GST Rate (%)<input id="pGst" type="number" min="0" step="0.5" value="' + v("gst_rate") + '"/></label></div>' +
      '<div class="form-row"><label>IMEI 1<input id="pImei1" value="' + v("imei1") + '"/></label>' +
      '<label>IMEI 2<input id="pImei2" value="' + v("imei2") + '"/></label></div>' +
      '<div class="form-row"><label>Cost Price (\u20B9)<input id="pCost" type="number" min="0" value="' + v("cost_price") + '"/></label>' +
      '<label>Selling Price (\u20B9)<input id="pPrice" type="number" min="0" value="' + v("selling_price") + '"/></label></div>' +
      '<div class="form-row"><label>Stock (units)<input id="pStock" type="number" min="0" value="' + v("stock") + '"/></label></div>' +
      '<div class="modal-actions"><button class="btn ghost" id="modalClose">Cancel</button>' +
      '<button class="btn primary" id="saveProduct" data-testid="btn-save-product">' + (p ? "Update" : "Add") + " Product</button></div>");
    $("modalClose").onclick = closeModal;
    $("saveProduct").onclick = function () {
      var obj = {
        brand: $("pBrand").value.trim(), model: $("pModel").value.trim(),
        variant: $("pVariant").value.trim(), category: $("pCategory").value.trim() || "Smartphone",
        hsn: $("pHsn").value.trim() || "85171200", gst_rate: parseFloat($("pGst").value) || 18,
        imei1: $("pImei1").value.trim(), imei2: $("pImei2").value.trim(),
        cost_price: parseFloat($("pCost").value) || 0, selling_price: parseFloat($("pPrice").value) || 0,
        stock: parseInt($("pStock").value, 10) || 0
      };
      if (!obj.brand || !obj.model) { toast("Brand and model are required.", true); return; }
      if (editing.product) {
        var idx = state.products.findIndex(function (x) { return x.id === editing.product; });
        obj.id = editing.product; state.products[idx] = obj;
        toast("Product updated.");
      } else {
        obj.id = uid(); state.products.push(obj);
        toast("Product added to catalog.");
      }
      save(); closeModal(); renderProducts(); renderProductResults();
    };
  }
  $("addProductBtn").addEventListener("click", function () { productModal(null); });
  $("productRows").addEventListener("click", function (e) {
    var edit = e.target.closest("[data-edit-p]"), del = e.target.closest("[data-del-p]");
    if (edit) productModal(state.products.find(function (x) { return x.id === edit.dataset.editP; }));
    if (del) {
      state.products = state.products.filter(function (x) { return x.id !== del.dataset.delP; });
      save(); renderProducts(); toast("Product deleted.");
    }
  });

  // ================= CUSTOMERS =================
  function customerStats(phone) {
    var bills = state.invoices.filter(function (v) { return v.customer.phone === phone; });
    var total = bills.reduce(function (s, v) { return s + (Number(v.grand_total) || 0); }, 0);
    return { bills: bills.length, total: total };
  }
  function renderCustomers() {
    $("customerRows").innerHTML = state.customers.map(function (c) {
      var st = customerStats(c.phone);
      return "<tr>" +
        "<td><strong>" + esc(c.name) + "</strong></td>" +
        '<td class="num">' + esc(c.phone) + "</td>" +
        "<td>" + esc(c.address || "\u2014") + "</td>" +
        "<td>" + (c.gstin ? '<span class="imei-chip">' + esc(c.gstin) + "</span>" : "\u2014") + "</td>" +
        "<td>" + st.bills + "</td>" +
        '<td class="num"><strong>' + inr(st.total) + "</strong></td>" +
        '<td><button class="btn sm" data-edit-c="' + esc(c.id) + '">Edit</button> ' +
        '<button class="btn sm danger" data-del-c="' + esc(c.id) + '">Delete</button></td>' +
        "</tr>";
    }).join("");
    $("customerEmpty").textContent = state.customers.length ? "" : "No customers yet.";
  }
  function customerModal(c) {
    editing.customer = c ? c.id : null;
    var v = function (k) { return esc(c ? (c[k] || "") : ""); };
    openModal("<h2>" + (c ? "Edit Customer" : "Add Customer") + '</h2>' +
      '<div class="form-row"><label>Full Name<input id="cName" value="' + v("name") + '"/></label>' +
      '<label>Phone<input id="cPhone" value="' + v("phone") + '"/></label></div>' +
      '<div class="form-row"><label>Address / Locality<input id="cAddress" value="' + v("address") + '" placeholder="Mirzapur, Darbhanga"/></label>' +
      '<label>GSTIN (optional)<input id="cGstin" value="' + v("gstin") + '"/></label></div>' +
      '<div class="modal-actions"><button class="btn ghost" id="modalClose">Cancel</button>' +
      '<button class="btn primary" id="saveCustomer" data-testid="btn-save-customer">' + (c ? "Update" : "Add") + " Customer</button></div>");
    $("modalClose").onclick = closeModal;
    $("saveCustomer").onclick = function () {
      var obj = { name: $("cName").value.trim(), phone: $("cPhone").value.trim(), address: $("cAddress").value.trim(), gstin: $("cGstin").value.trim() };
      if (!obj.name || !obj.phone) { toast("Name and phone are required.", true); return; }
      if (editing.customer) {
        var idx = state.customers.findIndex(function (x) { return x.id === editing.customer; });
        obj.id = editing.customer; state.customers[idx] = obj;
        toast("Customer updated.");
      } else {
        obj.id = uid(); state.customers.push(obj);
        toast("Customer added to khata.");
      }
      save(); closeModal(); renderCustomers();
    };
  }
  $("addCustomerBtn").addEventListener("click", function () { customerModal(null); });
  $("customerRows").addEventListener("click", function (e) {
    var edit = e.target.closest("[data-edit-c]"), del = e.target.closest("[data-del-c]");
    if (edit) customerModal(state.customers.find(function (x) { return x.id === edit.dataset.editC; }));
    if (del) {
      state.customers = state.customers.filter(function (x) { return x.id !== del.dataset.delC; });
      save(); renderCustomers(); toast("Customer deleted.");
    }
  });

  // ================= SETTINGS =================
  function renderSettings() {
    var s = state.settings || {};
    var f = function (id, label, val, type) {
      return '<label class="block-label">' + label + '<input id="' + id + '" type="' + (type || "text") + '" value="' + esc(val || "") + '"/></label>';
    };
    $("settingsForm").innerHTML =
      f("sName", "Shop Name", s.name || "Mobile Store Darbhanga") +
      f("sTagline", "Tagline", s.tagline) +
      f("sAddress", "Address", s.address) +
      f("sPhone", "Phone", s.phone) +
      f("sEmail", "Email", s.email, "email") +
      f("sGstin", "GSTIN", s.gstin) +
      f("sState", "State Code", s.state_code || "10 - Bihar") +
      f("sUpi", "UPI ID", s.upi_id) +
      '<label class="block-label">Terms &amp; Conditions<textarea id="sTerms" rows="4">' + esc(s.terms || "") + "</textarea></label>";
  }
  $("saveSettingsBtn").addEventListener("click", function () {
    state.settings = {
      name: $("sName").value.trim(), tagline: $("sTagline").value.trim(), address: $("sAddress").value.trim(),
      phone: $("sPhone").value.trim(), email: $("sEmail").value.trim(), gstin: $("sGstin").value.trim(),
      state_code: $("sState").value.trim(), upi_id: $("sUpi").value.trim(), terms: $("sTerms").value
    };
    save(); applyBrand(); toast("Shop profile saved.");
  });
  $("resetDataBtn").addEventListener("click", function () {
    openModal("<h2>Reset to bundled data?</h2><p class='hint'>All bills and edits made in this browser will be replaced by the data shipped inside the ZIP.</p>" +
      '<div class="modal-actions"><button class="btn ghost" id="modalClose">Cancel</button><button class="btn primary" id="confirmReset">Reset</button></div>');
    $("modalClose").onclick = closeModal;
    $("confirmReset").onclick = function () { localStorage.removeItem(LS_KEY); location.reload(); };
  });

  function applyBrand() {
    var s = state.settings || {};
    $("brandName").textContent = s.name || "Mobile Store Darbhanga";
    $("brandTagline").textContent = s.tagline || "";
    document.title = (s.name || "Mobile Store") + " \u2014 Bill Book";
  }

  // ---------- boot ----------
  applyBrand();
  renderProductResults();
  renderCart();
})();
