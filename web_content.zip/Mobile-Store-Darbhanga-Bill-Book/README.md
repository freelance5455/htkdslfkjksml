# Mobile Store Darbhanga — Offline Bill Book

A self-contained GST billing website for the shop. **No internet, no installation, no server
needed** — everything is plain HTML, CSS and JavaScript.

## How to use

1. Unzip this folder anywhere (keep all files together).
2. Double-click **index.html** — it opens in your browser (Chrome/Edge/Firefox).
3. Start billing.

## Features

- **New Bill** — search the product catalog, add items, capture IMEI, pick a payment mode
  (Cash / UPI / Card / Credit) and watch CGST 9% + SGST 9% (18% GST) and round-off update live.
  **Save & Print** stores the invoice and opens the browser print dialog (A4 tax invoice).
- **Invoices** — search, view, reprint or delete past bills (deleting returns stock).
- **Products** — your mobile inventory with brand, model, variant, HSN, IMEI, prices and stock;
  low-stock items get a warning badge.
- **Customers** — a khata of every customer with bill count and lifetime spend.
- **Settings** — shop name, address, GSTIN, UPI ID and invoice terms.

## Where is my data?

Everything is saved automatically in **this browser's localStorage** on the computer you use.
- The bundle ships with the shop data exported from the online bill book on
  (see `data.js`), used the first time you open it.
- Use **Settings → Reset to Bundled Data** to restore that snapshot.
- Tip: take a fresh ZIP from the online bill book from time to time — it carries the latest
  invoices and stock.
