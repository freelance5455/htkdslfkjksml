import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "أضف OPENAI_API_KEY إلى ملف .env أولاً." });
    }
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 40) {
      return res.status(400).json({ error: "سجل المحادثة غير صالح." });
    }
    const cleanMessages = messages
      .filter(m => ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .map(m => ({ role: m.role, content: m.content.slice(0, 12000) }));
    if (!cleanMessages.length || cleanMessages.at(-1).role !== "user") {
      return res.status(400).json({ error: "أرسل رسالة مستخدم صالحة." });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions: "أنت ADNAN ZERO X AI، مساعد ذكي مفيد وواضح. أجب بلغة المستخدم، وكن دقيقاً وآمناً.",
      input: cleanMessages
    });
    res.json({ reply: response.output_text || "لم أتمكن من إنشاء رد نصي." });
  } catch (error) {
    console.error("OpenAI request failed:", error?.message || error);
    const status = Number(error?.status) || 500;
    res.status(status >= 400 && status < 600 ? status : 500).json({
      error: status === 401 ? "مفتاح API غير صالح. أنشئ مفتاحاً جديداً وتحقق من الإعدادات."
        : status === 429 ? "تم بلوغ حد الاستخدام أو الرصيد. تحقق من حساب API."
        : "حدث خطأ أثناء الاتصال بخدمة الذكاء الاصطناعي. تحقق من الإعدادات وحاول مجدداً."
    });
  }
});

app.listen(PORT, () => console.log(`ADNAN ZERO X AI يعمل على http://localhost:${PORT}`));