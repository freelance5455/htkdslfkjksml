AEROFLEX FUTURISTIC STORE — DEMO

Pages: Home, Shop, Product detail, Login, Create account, Shopping bag, Wishlist, Account, Contact.
Features: sample products, category filter, search, price sorting, demo local account, cart, wishlist, responsive mobile layout.

MOBILE TEST:
1. ZIP extract karein.
2. index.html ko Chrome ya HTML preview app mein open karein.
3. Internet on rakhein taake photos/fonts load hon.
4. signup.html par demo account banayein, phir login/cart/wishlist test karein.

IMPORTANT:
Yeh front-end demo hai. Account/password browser local storage mein save hote hain, is liye real password use na karein. Real email verification, password reset, orders, payments, inventory, admin backend aur customer data storage abhi included nahi. Contact form message send nahi karta. Prices aur product photos samples hain. 1LINK/banking API connected nahi hai. API secret ko kabhi HTML/JS mein na rakhein.

APK:
ZIP ko rename karke APK nahi ban sakti. Android WebView/Capacitor wrapper aur Android build chahiye. APK banane se pehle browser demo test karein.
