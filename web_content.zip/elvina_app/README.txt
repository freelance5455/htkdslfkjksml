ELVINA — Women’s Clothing Business Manager

WHAT THIS IS
A small, mobile-friendly offline-capable-in-practice web app source (HTML/JavaScript). It is NOT an Android APK yet.

HOW TO USE ON ANDROID
1. Extract ELVINA_Source.zip using your phone's Files app.
2. Open index.html with Chrome or another browser.
3. Login password: lovelvina
4. Add products, record sales, add other expenses, and check the totals.

IMPORTANT
- Records are stored locally in that browser on that device using localStorage.
- Clearing browser/site data can erase records. Use “হিসাব CSV ডাউনলোড” for backups.
- The login password is included in the source code and is only a basic lock, not secure account authentication.
- This ZIP contains the source files; it does not contain a compiled APK. Creating a real APK requires an Android build tool/service.
