package com.minecraftmodstudio.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.widget.Toast;
import android.util.Base64;

import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4107;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,13,20));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,13,20));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        webView.setBackgroundColor(android.graphics.Color.rgb(8,13,20));
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] accepted = params.getAcceptTypes();
                    String accept = (accepted != null && accepted.length > 0) ? accepted[0] : "*/*";
                    if (accept.contains("json")) intent.setType("application/json");
                    else if (accept.startsWith("audio")) intent.setType("audio/ogg");
                    else if (accept.startsWith("image")) intent.setType("image/*");
                    else intent.setType("*/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new FileBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    private class FileBridge {
        @JavascriptInterface public void requestAIAsync(String endpoint, String apiKey, String body, String requestId) {
            new Thread(() -> {
                String result = requestAI(endpoint, apiKey, body);
                String safeId = org.json.JSONObject.quote(requestId == null ? "" : requestId);
                String safeResult = org.json.JSONObject.quote(result);
                runOnUiThread(() -> webView.evaluateJavascript("window.__mmsAIResolve(" + safeId + "," + safeResult + ")", null));
            }).start();
        }
        @JavascriptInterface public String requestAI(String endpoint, String apiKey, String body) {
            HttpURLConnection connection = null;
            try {
                if (endpoint == null || !endpoint.startsWith("https://")) throw new Exception("Solo se permiten direcciones HTTPS.");
                URL url = new URL(endpoint);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(90000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setRequestProperty("Accept", "application/json");
                if (apiKey != null && !apiKey.trim().isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
                byte[] payload = (body == null ? "{}" : body).getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = connection.getOutputStream()) { out.write(payload); }
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 400 ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder response = new StringBuilder();
                if (stream != null) {
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = stream.read(buffer)) != -1) response.append(new String(buffer, 0, n, StandardCharsets.UTF_8));
                    stream.close();
                }
                if (code < 200 || code >= 300) return "{\"_httpError\":" + code + ",\"message\":" + org.json.JSONObject.quote(response.toString()) + "}";
                return response.toString();
            } catch (Exception e) {
                return "{\"_httpError\":0,\"message\":" + org.json.JSONObject.quote(e.getMessage() == null ? "Error de conexión" : e.getMessage()) + "}";
            } finally { if (connection != null) connection.disconnect(); }
        }
        @JavascriptInterface public void openCreativeMode() {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://creativemode.net/"));
                startActivity(intent);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "No se pudo abrir CreativeMode", Toast.LENGTH_LONG).show());
            }
        }
        @JavascriptInterface public void saveFile(String base64, String fileName, String mimeType) {
            try {
                String safeName = fileName == null ? "export.bin" : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Minecraft Mod Studio");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No se pudo crear el archivo");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(data); }
                    values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                } else {
                    File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Minecraft Mod Studio");
                    if (!dir.exists()) dir.mkdirs();
                    try (FileOutputStream out = new FileOutputStream(new File(dir, safeName))) { out.write(data); }
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Guardado en Descargas / Minecraft Mod Studio", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "No se pudo guardar el archivo: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : false", value -> {
                if (!"true".equals(value)) MainActivity.super.onBackPressed();
            });
        } else super.onBackPressed();
    }
}
