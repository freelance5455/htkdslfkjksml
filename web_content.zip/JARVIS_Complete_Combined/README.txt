JARVIS Complete Combined HTML Project

This ZIP combines BOTH previous projects in one index.html:
- JARVIS assistant chat and device text-to-speech
- Armor schematics
- Fictional orbital Dog Cannon display and visual diagnostic
- Minecraft house plans
- Minecraft in-game weapon recipes (swords, bow, crossbow)
- Armor equipment notes

Extract and open index.html in a modern browser.

This is a standalone web demo, not an APK. Basic build catalog is local.
Voice recognition may require browser support and internet. The orbital cannon
is a fictional visual display only; no real weapon functionality is included.
Weapon recipes are for Minecraft game items only.
