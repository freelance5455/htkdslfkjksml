MEESHO RTO INVENTORY APP - v1

Use:
1. Open index.html in Chrome.
2. Export/download your Meesho inventory as CSV.
3. Select the CSV. Choose SKU + Stock columns if auto-detection is wrong.
4. Import/update inventory.
5. Scan/enter SKU.
6. ORDER -1 reduces stock.
7. RTO/RETURN +1 increases stock.
8. Export CSV for backup.

This version stores data locally on the device/browser.
It does NOT directly connect to Meesho or change Meesho stock automatically.
Automatic Meesho API sync requires an authorized Meesho integration/API access.
