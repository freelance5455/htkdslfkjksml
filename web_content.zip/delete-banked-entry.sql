-- Banked-entry deletion RPC for Daily Progress Manager
-- Run this entire script once in Supabase SQL Editor.

create or replace function public.delete_banked_entry(
  p_item_id uuid,
  p_day date,
  p_entry_id text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item public.items%rowtype;
  v_entry jsonb;
  v_new_progress jsonb := '[]'::jsonb;
  v_day_found boolean := false;
  v_entry_found boolean := false;
  v_banked_entries jsonb := '[]'::jsonb;
  v_filtered jsonb;
  v_banked numeric := 0;
  v_target text := p_entry_id;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select * into v_item
  from public.items
  where id = p_item_id;

  if not found then
    raise exception 'Item not found';
  end if;

  if v_item.owner_id <> auth.uid() and not public.is_admin() then
    raise exception 'You are not allowed to change this item';
  end if;

  for v_entry in
    select value
    from jsonb_array_elements(coalesce(v_item.daily_progress, '[]'::jsonb))
  loop
    if v_entry->>'date' = p_day::text then
      v_day_found := true;

      if jsonb_typeof(v_entry->'banked_entries') = 'array' then
        v_banked_entries := v_entry->'banked_entries';
        select coalesce(jsonb_agg(e), '[]'::jsonb)
        into v_filtered
        from jsonb_array_elements(v_banked_entries) e
        where coalesce(e->>'id','') <> v_target;

        if jsonb_array_length(v_filtered) < jsonb_array_length(v_banked_entries) then
          v_entry_found := true;
        end if;

        v_banked_entries := v_filtered;
      elsif v_target = ('legacy-' || p_day::text) and coalesce((v_entry->>'banked')::numeric, 0) > 0 then
        -- Support old single-value Banked records created before banked_entries existed.
        v_entry_found := true;
        v_banked_entries := '[]'::jsonb;
      end if;

      select coalesce(sum(coalesce((e->>'amount')::numeric, 0)), 0)
      into v_banked
      from jsonb_array_elements(v_banked_entries) e;

      v_entry := jsonb_set(v_entry, '{banked_entries}', v_banked_entries, true);
      v_entry := jsonb_set(v_entry, '{banked}', to_jsonb(v_banked), true);
      v_new_progress := v_new_progress || jsonb_build_array(v_entry);
    else
      v_new_progress := v_new_progress || jsonb_build_array(v_entry);
    end if;
  end loop;

  if not v_day_found then
    raise exception 'No Banked entries found for today';
  end if;
  if not v_entry_found then
    raise exception 'That Banked entry could not be found';
  end if;

  update public.items
  set daily_progress = v_new_progress,
      updated_at = now()
  where id = p_item_id;

  return jsonb_build_object(
    'ok', true,
    'item_id', p_item_id,
    'date', p_day,
    'entry_id', p_entry_id,
    'banked', v_banked
  );
end;
$$;

revoke all on function public.delete_banked_entry(uuid, date, text) from public;
grant execute on function public.delete_banked_entry(uuid, date, text) to authenticated;
