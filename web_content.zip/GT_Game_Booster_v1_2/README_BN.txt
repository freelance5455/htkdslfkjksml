GT GAME BOOSTER v1.3 — SOURCE PROJECT
====================================

ফোল্ডার:
- index.html : Browser/WebView preview (আসল Android overlay নয়)
- assets/gt-logo.svg : নতুন GT gaming emblem
- android/ : Native Android Studio project (Kotlin)

Android build:
1. Android Studio-তে android ফোল্ডারটি Open করুন।
2. Gradle sync শেষ হতে দিন। Android SDK 35 ইনস্টল থাকতে হবে।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
4. ফোনে ইনস্টল করে অ্যাপ খুলুন। ৮ সেকেন্ডের intro শেষে Dashboard আসবে।
5. ENABLE DISPLAY OVER OTHER APPS চাপুন। Android Settings-এ GT Game Booster-এর Allow display over other apps চালু করে Back করুন।
6. ACTIVATE FLOATING GT চাপুন। স্ক্রিনে GT bubble দেখা যাবে; টেনে সরানো যাবে। ট্যাপ করলে Quick Menu খুলবে।
7. Notification থেকে STOP অথবা Quick Menu-র CLOSE FLOATING MENU দিয়ে বন্ধ করা যাবে।

গুরুত্বপূর্ণ বাস্তব সীমাবদ্ধতা:
- এই অ্যাপটি game launcher + user-enabled floating overlay companion। এটি Free Fire-এর game files পরিবর্তন করে না।
- Android-এর সাধারণ third-party app অন্য অ্যাপের আসল FPS নির্ভুলভাবে পড়তে/জোর করে 120 FPS দিতে পারে না। 120 FPS কেবল ফোন ও গেম নিজে সমর্থন করলে গেমের settings-এ পাওয়া যায়।
- কোনো app physical RAM বাড়াতে, hardware heating নিশ্চিতভাবে কমাতে, সব lag দূর করতে বা antivirus scan-এর বিকল্প হতে পারে না। তাই UI-তে এসবের ভুয়া নিশ্চয়তা দেখানো হয়নি।
- Overlay permission Android Settings থেকে ব্যবহারকারী নিজে অনুমোদন করবেন। Accessibility, contacts, location, broad storage বা VPN permission চাওয়া হয় না। Notification permission Android 13+ এ service notification দেখানোর জন্য চাওয়া হয়।
- Google Play-এ প্রকাশের আগে Play Console-এর বর্তমান target API, foreground-service declaration, privacy policy এবং testing requirements যাচাই করতে হবে। Android Studio build সফল হলেই Play approval নিশ্চিত নয়।

Redeem code / ₹30 Premium:
- UI-তে redeem-code screen আছে, কিন্তু secure verification server যুক্ত করা হয়নি।
- কোনো master password বা redeem-code database APK/HTML-এর ভিতরে রাখা নিরাপদ নয়; reverse-engineering করে বের করা যায়।
- Redeem code ও owner password server-side-এ salted hash, rate-limit, one-time redemption এবং HTTPS দিয়ে যাচাই করতে হবে। এই project-এ hard-coded password রাখা হয়নি।
- ₹30 payment collection/real purchase এখনো যুক্ত নয়। Payment provider/Play Billing ও server verification যুক্ত না করে টাকা নেওয়া বা Premium active দেখানো যাবে না।

প্রজেক্টটি source code; ready-to-install APK/AAB নয়।
