package com.gtgamebooster

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.animation.ObjectAnimator
import android.widget.FrameLayout
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val gold = Color.rgb(255, 198, 67)
    private val cyan = Color.rgb(89, 224, 255)
    private lateinit var status: TextView
    private lateinit var permissionBtn: Button
    private lateinit var startBtn: Button
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 8, 16)
        window.navigationBarColor = Color.rgb(7, 8, 16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(22, 13, 42), Color.rgb(6, 9, 18), Color.rgb(4, 12, 22)))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val logo = TextView(this).apply {
            text = "GT"; textSize = 29f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(gold, Color.rgb(125, 58, 255))).apply { cornerRadius = dp(17).toFloat(); setStroke(dp(2), Color.WHITE) }
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(62), dp(62)))
        val brand = TextView(this).apply { text = "  GT GAME BOOSTER\n  ELITE GAME COMPANION"; textSize = 16f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setLineSpacing(dp(3).toFloat(), 1f) }
        header.addView(brand)
        val premium = Button(this).apply { text = "♛ ₹30"; isAllCaps = false; setTextColor(Color.BLACK); background = goldGradient(); setOnClickListener { showPremiumDialog() } }
        header.addView(premium, LinearLayout.LayoutParams(dp(86), dp(42)).apply { gravity = Gravity.CENTER_VERTICAL; weight = 1f })
        root.addView(header, lp())

        val hero = TextView(this).apply {
            text = "\n⚡  OWN YOUR GAME\n\nA clean floating game companion.\nLaunch your installed game and control the GT overlay from any screen.\n"
            textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = card(Color.rgb(23, 20, 43), Color.rgb(151, 82, 255)); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        root.addView(hero, lp())
        status = TextView(this).apply { text = "● STATUS  •  OVERLAY PERMISSION NOT CHECKED"; textSize = 12f; setTextColor(cyan); gravity = Gravity.CENTER; setPadding(0, dp(15), 0, dp(15)) }
        root.addView(status, lp())
        permissionBtn = button("①  ENABLE DISPLAY OVER OTHER APPS", cyan)
        startBtn = button("⚡  ACTIVATE FLOATING GT", gold)
        val stop = button("■  STOP FLOATING MENU", Color.rgb(194, 91, 255))
        root.addView(permissionBtn, lp()); root.addView(startBtn, lp()); root.addView(stop, lp())
        val gameTitle = section("QUICK GAME LAUNCH")
        root.addView(gameTitle, lp())
        root.addView(button("🎮  OPEN FREE FIRE / INDIA", cyan).apply { setOnClickListener { launchFirst(listOf("com.dts.freefireth", "com.dts.freefireindia"), "Free Fire") } }, lp())
        root.addView(button("⚡  OPEN FREE FIRE MAX", cyan).apply { setOnClickListener { launchFirst(listOf("com.dts.freefiremax"), "Free Fire MAX") } }, lp())
        root.addView(section("GT PREMIUM  •  ₹30"), lp())
        val features = TextView(this).apply {
            text = "♛ Premium theme & floating panel\n✓ FPS-friendly game session shortcuts\n✓ Quick access to installed games\n✓ Premium interface and controls\n\nNote: FPS, RAM, temperature and network performance depend on Android, device hardware and the game. This app cannot force 120 FPS, guarantee zero lag, cool hardware, or remove viruses."
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(dp(16), dp(15), dp(16), dp(15)); background = card(Color.rgb(19, 17, 31), gold)
        }
        root.addView(features, lp())
        root.addView(button("🔐  ENTER REDEEM CODE", gold).apply { setOnClickListener { showPremiumDialog() } }, lp())
        val note = TextView(this).apply { text = "Permissions: only Display over other apps is required for the floating button. Notifications are requested on Android 13+ for the ongoing service notice. No Accessibility permission or broad file access is needed."; textSize = 11f; setTextColor(Color.GRAY); setPadding(dp(5), dp(15), dp(5), dp(15)) }
        root.addView(note, lp())
        val splash = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(7, 5, 17), Color.rgb(34, 13, 57), Color.rgb(5, 11, 22)))
        }
        val splashLogo = TextView(this).apply {
            text = "GT  ⚡"; textSize = 62f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setShadowLayer(dp(22).toFloat(), 0f, 0f, cyan)
        }
        val splashLabel = TextView(this).apply {
            text = "GAME BOOSTER  •  ELITE EDITION"; textSize = 12f; gravity = Gravity.CENTER
            setTextColor(gold); letterSpacing = .22f
        }
        val splashStack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        splashStack.addView(splashLogo, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(120)))
        splashStack.addView(splashLabel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))
        splash.addView(splashStack, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(splash)
        ObjectAnimator.ofFloat(splashLogo, View.SCALE_X, .72f, 1.08f, 1f).apply { duration = 1700; start() }
        ObjectAnimator.ofFloat(splashLogo, View.SCALE_Y, .72f, 1.08f, 1f).apply { duration = 1700; start() }
        ObjectAnimator.ofFloat(splashLogo, View.ALPHA, .35f, 1f).apply { duration = 1400; start() }
        splash.postDelayed({ setContentView(scroll); refreshStatus() }, 8000L)

        permissionBtn.setOnClickListener { requestOverlay() }
        startBtn.setOnClickListener { startFloating() }
        stop.setOnClickListener { stopService(Intent(this, FloatingService::class.java)); refreshStatus("Floating menu stopped") }
        refreshStatus()
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) refreshStatus() }
    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) { refreshStatus("Overlay permission already enabled"); return }
        try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)) }
    }
    private fun startFloating() {
        if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Allow Display over other apps first", Toast.LENGTH_LONG).show(); requestOverlay(); return }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
        }
        try {
            val i = Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            refreshStatus("GT floating menu is active")
        } catch (e: Exception) { refreshStatus("Could not start service: ${e.javaClass.simpleName}") }
    }
    private fun launchFirst(packages: List<String>, label: String) {
        val intent = packages.firstNotNullOfOrNull { pkg -> packageManager.getLaunchIntentForPackage(pkg) }
        if (intent == null) { Toast.makeText(this, "$label is not installed or not visible to Android", Toast.LENGTH_LONG).show(); return }
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Could not launch $label", Toast.LENGTH_LONG).show() }
    }
    private fun showPremiumDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(4)) }
        val info = TextView(this).apply { text = "GT PREMIUM • ₹30\n\nPremium access is activated with a redeem code issued by the app owner. Code verification must be performed by a secure server; a secret/password stored inside an APK can be extracted."; setTextColor(Color.WHITE); textSize = 14f }
        val code = EditText(this).apply { hint = "Enter redeem code"; setSingleLine(true) }
        box.addView(info); box.addView(code)
        android.app.AlertDialog.Builder(this).setTitle("♛  Redeem Premium").setView(box)
            .setPositiveButton("VERIFY CODE") { _, _ -> Toast.makeText(this, "Connect a secure redeem-code verification server to activate Premium.", Toast.LENGTH_LONG).show() }
            .setNegativeButton("CANCEL", null).show().getButton(-1)?.setTextColor(gold)
    }
    private fun refreshStatus(extra: String? = null) {
        val allowed = Settings.canDrawOverlays(this)
        status.text = "●  ${if (allowed) "OVERLAY PERMISSION ON" else "OVERLAY PERMISSION REQUIRED"}" + (extra?.let { "\n$it" } ?: "")
        permissionBtn.text = if (allowed) "✓  DISPLAY PERMISSION ENABLED" else "①  ENABLE DISPLAY OVER OTHER APPS"
    }
    private fun card(color: Int, stroke: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(color, Color.rgb(12, 13, 24))).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), stroke) }
    private fun goldGradient() = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(gold, Color.rgb(255, 231, 156))).apply { cornerRadius = dp(14).toFloat() }
    private fun button(label: String, accent: Int) = Button(this).apply { text = label; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE); background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(35, 23, 60), Color.rgb(15, 25, 40))).apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), accent) } }
    private fun section(s: String) = TextView(this).apply { text = s; textSize = 14f; setTextColor(gold); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(4), dp(14), 0, dp(6)) }
    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(11) }
}
