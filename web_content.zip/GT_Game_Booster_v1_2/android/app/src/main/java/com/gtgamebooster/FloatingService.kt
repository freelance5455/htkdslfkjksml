package com.gtgamebooster

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*

class FloatingService : Service() {
    companion object {
        const val ACTION_START = "com.gtgamebooster.START"
        private const val CHANNEL = "gt_floating_service"
        private const val NOTIFICATION_ID = 4107
    }
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            .setContentTitle("GT Game Booster is active")
            .setContentText("Floating GT menu is running • Tap Stop to close")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "STOP", PendingIntent.getService(this, 2,
                Intent(this, FloatingService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .build() else Notification.Builder(this).setContentTitle("GT Game Booster is active").setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(NOTIFICATION_ID, notification)
        showBubble()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (Settings.canDrawOverlays(this)) showBubble() else stopSelf()
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "GT Floating Menu", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }
    private fun type() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun panelBg() = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(36, 17, 60), Color.rgb(7, 13, 25))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(2), Color.rgb(188, 102, 255)) }
    private fun showBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return
        val v = TextView(this).apply {
            text = "GT"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(255, 203, 77), Color.rgb(120, 43, 255))).apply { shape = GradientDrawable.OVAL; setStroke(dp(3), Color.WHITE) }
            elevation = dp(14).toFloat(); contentDescription = "GT floating game booster menu"
        }
        bubbleParams = WindowManager.LayoutParams(dp(60), dp(60), type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(14); y = dp(190) }
        v.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { sx = event.rawX; sy = event.rawY; ox = bubbleParams.x; oy = bubbleParams.y; moved = false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - sx).toInt(); val dy = (event.rawY - sy).toInt()
                        if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                        bubbleParams.x = (ox + dx).coerceAtLeast(0); bubbleParams.y = (oy + dy).coerceAtLeast(0)
                        try { wm.updateViewLayout(v, bubbleParams) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); return true }
                }
                return true
            }
        })
        bubble = v
        try { wm.addView(v, bubbleParams) } catch (_: Exception) { bubble = null; stopSelf() }
    }
    private fun togglePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {}; panel = null; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = panelBg(); elevation = dp(20).toFloat() }
        val title = TextView(this).apply { text = "GT  ⚡  QUICK BOOST MENU"; textSize = 16f; setTextColor(Color.rgb(255, 207, 92)); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8)) }
        val state = TextView(this).apply { text = "● FLOATING MENU ACTIVE"; textSize = 12f; setTextColor(Color.rgb(103, 255, 167)); gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(12)) }
        box.addView(title); box.addView(state)
        box.addView(action("🎮  OPEN FREE FIRE", Color.rgb(82, 221, 255)) { launch(listOf("com.dts.freefireth", "com.dts.freefireindia"), "Free Fire") })
        box.addView(action("⚡  OPEN FREE FIRE MAX", Color.rgb(82, 221, 255)) { launch(listOf("com.dts.freefiremax"), "Free Fire MAX") })
        box.addView(action("✓  BOOST SESSION: ON", Color.rgb(111, 255, 171)) { state.text = "● GAME SESSION ACTIVE • GT MENU ON" })
        box.addView(action("×  CLOSE FLOATING MENU", Color.rgb(255, 117, 135)) { stopSelf() })
        val p = WindowManager.LayoutParams(dp(290), WindowManager.LayoutParams.WRAP_CONTENT, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
        panel = box
        try { wm.addView(box, p) } catch (_: Exception) { panel = null; Toast.makeText(this, "Could not display GT menu. Check overlay permission.", Toast.LENGTH_LONG).show() }
    }
    private fun action(label: String, accent: Int, click: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(26, 27, 49), Color.rgb(13, 22, 37))).apply { cornerRadius = dp(13).toFloat(); setStroke(dp(1), accent) }
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply { bottomMargin = dp(8) }
    }
    private fun launch(packages: List<String>, label: String) {
        val launchIntent = packages.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (launchIntent == null) { Toast.makeText(this, "$label not found. Install it first.", Toast.LENGTH_LONG).show(); return }
        try { launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launchIntent); panel?.let { wm.removeView(it) }; panel = null }
        catch (_: Exception) { Toast.makeText(this, "Unable to open $label", Toast.LENGTH_LONG).show() }
    }
    @Suppress("DEPRECATION")
    override fun onDestroy() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null; bubble = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }
}
