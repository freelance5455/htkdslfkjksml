FF PANEL DEMO — SOURCE PROJECT

Ini aplikasi demo visual mandiri, bukan cheat dan tidak terhubung ke Free Fire.

Cara membuat APK:
1. Instal Android Studio di komputer.
2. Ekstrak ZIP ini.
3. Buka folder FFPanelDemo melalui Android Studio.
4. Tunggu Gradle sync selesai.
5. Pilih Build > Build APK(s).
6. Setelah selesai, pilih Locate untuk menemukan APK hasil build.

Catatan:
- Build membutuhkan koneksi internet untuk mengunduh Android Gradle Plugin/SDK bila belum tersedia.
- APK belum dikompilasi di sini; file ini adalah source project Android Studio.
