# EstudaFácil 2.4

Aplicativo Android de estudos com interface azul e branca, sem IA.

## Funções
- Cadastro do dia da prova, matéria, o que estudar e tempo planejado.
- Notificação programada para as 19h do dia anterior à prova, com a matéria e o assunto para revisar.
- Lista de planos salvos localmente no aparelho, com opção de apagar (e cancelar o lembrete correspondente).
- Resumos prontos de Matemática, Linguagens, Ciências da Natureza e Ciências Humanas.

## Importante sobre notificações
- Ao abrir o app, permita notificações quando o Android solicitar.
- O aviso é programado para o dia anterior à prova às 19h. Se esse horário já passou, não será programado para aquela prova.
- O Android ou a economia de bateria podem atrasar alguns avisos.
- Este ZIP contém o código-fonte, não um APK pronto para instalar. Abra o projeto no Android Studio para compilar e testar.
