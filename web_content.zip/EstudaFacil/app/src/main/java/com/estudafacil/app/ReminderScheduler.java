package com.estudafacil.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class ReminderScheduler {
    private ReminderScheduler() {}
    private static PendingIntent pending(Context context, String id, String title, boolean update) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("reminder_id", id);
        intent.putExtra("reminder_title", title);
        int flags = PendingIntent.FLAG_IMMUTABLE | (update ? PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_NO_CREATE);
        return PendingIntent.getBroadcast(context, id.hashCode(), intent, flags);
    }
    public static void schedule(Context context, String id, String title, long atMillis) {
        if (atMillis <= System.currentTimeMillis()) return;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(context, id, title, true);
        if (manager == null || pi == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
        else manager.set(AlarmManager.RTC_WAKEUP, atMillis, pi);
    }
    public static void cancel(Context context, String id) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(context, id, "", false);
        if (manager != null && pi != null) { manager.cancel(pi); pi.cancel(); }
    }
}
