import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "20kb" }));

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/api/estudar", async (req, res) => {
  try {
    const { subject = "Outro assunto", prompt = "" } = req.body ?? {};
    if (typeof prompt !== "string" || !prompt.trim()) {
      return res.status(400).json({ error: "Digite um assunto para estudar." });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "O serviço de IA ainda não foi configurado no servidor." });
    }

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-6-astra",
        instructions: "Você é o tutor do aplicativo EstudaFácil. Responda em português brasileiro, com linguagem clara para estudantes do ensino médio. Explique passo a passo quando ajudar em matemática, dê exemplos e não invente fontes.",
        input: `Matéria: ${String(subject).slice(0, 100)}\nPergunta do estudante: ${prompt.trim().slice(0, 6000)}`
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("OpenAI API error:", data);
      return res.status(502).json({ error: "A IA não conseguiu responder agora. Verifique a configuração do serviço." });
    }
    const answer = data.output_text;
    if (!answer) return res.status(502).json({ error: "A IA retornou uma resposta vazia." });
    return res.json({ answer });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Erro interno no serviço de IA." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`EstudaFácil IA disponível na porta ${port}`));
