# Serviço de IA do EstudaFácil

Este backend conecta o app à OpenAI Responses API. O app deve apontar para a URL HTTPS pública deste servidor, por exemplo `https://seu-dominio.example/api/estudar`.

## Configuração
1. Use um computador/ambiente de servidor com Node.js 20 ou superior.
2. Nesta pasta, execute `npm install`.
3. Copie `.env.example` para `.env` e configure `OPENAI_API_KEY` no ambiente do servidor.
4. Execute `npm start`.
5. Publique o servidor em um serviço de hospedagem com HTTPS e configure controles de uso/limites antes de compartilhar o app.

A chave de API é secreta e deve ficar apenas no servidor. O uso da API pode ter custos e exige uma conta com acesso/billing configurado. Não compartilhe sua chave. Peça ajuda a um responsável adulto para configurar a conta e a hospedagem se necessário.

## Formato
POST `/api/estudar` com JSON:
`{"subject":"Matemática","prompt":"Explique raiz quadrada com exemplos"}`

Resposta:
`{"answer":"..."}`
