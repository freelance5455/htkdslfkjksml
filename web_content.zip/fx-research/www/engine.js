// FX Research engine. Signals at bar i use data <= i only; entry = open of bar i+1.
(function(R){
const atr=(c,n,i)=>{if(i<n)return null;let s=0;for(let k=i-n+1;k<=i;k++){const p=c[k-1];s+=Math.max(c[k].h-c[k].l,Math.abs(c[k].h-p.c),Math.abs(c[k].l-p.c));}return s/n};
const S={
 donchian:{name:'FX Donchian Trend (LEAN-style, assumed)',def:{n:20,atrN:14,slM:2,tpR:2},
  sig(c,i,p){const a=atr(c,p.atrN,i);if(a===null||i<p.n)return null;let hi=-1e9,lo=1e9;
   for(let k=i-p.n;k<i;k++){hi=Math.max(hi,c[k].h);lo=Math.min(lo,c[k].l)}
   const d=c[i].c>hi?1:c[i].c<lo?-1:0;if(!d)return null;return{dir:d,sl:p.slM*a,tp:p.tpR*p.slM*a}}},
 meanrev:{name:'Mean Reversion (z-score, assumed)',def:{n:20,k:2,atrN:14,slM:2},
  sig(c,i,p){const a=atr(c,p.atrN,i);if(a===null||i<p.n)return null;let m=0;for(let k=i-p.n+1;k<=i;k++)m+=c[k].c;m/=p.n;
   let v=0;for(let k=i-p.n+1;k<=i;k++)v+=(c[k].c-m)**2;const s=Math.sqrt(v/p.n);if(!s)return null;
   const z=(c[i].c-m)/s;if(Math.abs(z)<p.k)return null;return{dir:z<0?1:-1,sl:p.slM*a,tp:Math.abs(c[i].c-m)}}},
 vwap:{name:'VWAP Reversion (equal-weight session mean, assumed)',def:{k:1.5,minBars:6,atrN:14,slM:2,erN:30,erMax:0.35,maxBars:24,sessHour:0},
  // erMax: skip when the market is trending (efficiency ratio > erMax; 1 = filter off). maxBars: time stop (0 = off). sessHour: UTC hour the session mean resets.
  sig(c,i,p){const a=atr(c,p.atrN,i);if(a===null)return null;
   if(p.erMax<1&&i>=p.erN){const net=Math.abs(c[i].c-c[i-p.erN].c);let sm=0;for(let k=i-p.erN+1;k<=i;k++)sm+=Math.abs(c[k].c-c[k-1].c);if(sm>0&&net/sm>p.erMax)return null}
   const ss=t=>Math.floor((t-p.sessHour*3600)/86400),day=ss(c[i].t);let sum=0,n=0;
   for(let k=i;k>=0&&ss(c[k].t)===day;k--){sum+=(c[k].h+c[k].l+c[k].c)/3;n++}
   if(n<p.minBars)return null;const v=sum/n,dev=c[i].c-v;if(Math.abs(dev)<p.k*a)return null;
   return{dir:dev<0?1:-1,sl:p.slM*a,tp:Math.abs(dev),mb:p.maxBars||0}}},
 nocandle:{name:'NO Candle (ported from your Pine script)',def:{pivotN:2,emaLen:200,valid:9,maxPend:3,wickTol:0,slMode:0,slBuf:0,useWick:0,rangeMult:2,rr:1,trendMode:0,enL:1,enS:1},sig(){return null},custom:1}
};
function backtest(c,key,p,cfg){const st=S[key];if(st.custom)return backtestNO(c,p,cfg);let bal=cfg.balance,tr=[],eq=[{t:c[0].t,v:bal}];const adv=cfg.spread/2+cfg.slip;
 for(let i=0;i<c.length-1;i++){const g=st.sig(c,i,p);if(!g||!(g.sl>0)||!(g.tp>0))continue;
  const e=c[i+1].o+g.dir*adv,sl=e-g.dir*g.sl,tp=e+g.dir*g.tp,u=bal*cfg.riskPct/100/g.sl;let x=null,r='EOD',j=i+1;
  for(;j<c.length;j++){const b=c[j];const hs=g.dir>0?b.l<=sl:b.h>=sl,ht=g.dir>0?b.h>=tp:b.l<=tp;
   if(hs){x=sl-g.dir*adv;r='SL';break}if(ht){x=tp-g.dir*adv;r='TP';break}if(g.mb&&j>=i+g.mb){x=b.c-g.dir*adv;r='TIME';break}}
  if(x===null){j=c.length-1;x=c[j].c-g.dir*adv}
  const pnl=(x-e)*g.dir*u;bal+=pnl;tr.push({t0:c[i+1].t,t1:c[j].t,dir:g.dir,entry:e,exit:x,sl,tp,pnl,reason:r,bal});eq.push({t:c[j].t,v:bal});i=j}
 return{trades:tr,eq,stats:stats(tr,cfg.balance,eq)}}

// NO Candle: ported from the user's Pine v6 script (limit orders at the NO candle open, valid candles #1..N, trend via BOS+EMA).
function backtestNO(c,p,cfg){const n=c.length,N=p.pivotN,adv=cfg.spread/2+cfg.slip,tr=[],k=2/(p.emaLen+1),ema=new Array(n).fill(null);let bal=cfg.balance;const eq=[{t:c[0].t,v:bal}];
 {let sm=0;for(let i=0;i<n;i++){if(i<p.emaLen-1)sm+=c[i].c;else if(i===p.emaLen-1){sm+=c[i].c;ema[i]=sm/p.emaLen}else ema[i]=c[i].c*k+ema[i-1]*(1-k)}}
 const bh=i=>Math.max(c[i].o,c[i].c),bl=i=>Math.min(c[i].o,c[i].c);
 let sH=null,sL=null,sHw=null,sLw=null,sHb=true,sLb=true,iDir=0,streak=0,pend=[],pos=null;
 const allow=(d,e)=>p.trendMode==2?e===d:p.trendMode==1?iDir===d:p.trendMode==3?(iDir===d||e===d):(iDir===d&&streak>=(e===d?1:2));
 const close=(b,x,why)=>{const pnl=(x-pos.entry)*pos.dir*pos.u;bal+=pnl;tr.push({t0:c[pos.eb].t,t1:b.t,dir:pos.dir,entry:pos.entry,exit:x,sl:pos.sl,tp:pos.tp,pnl,reason:why,bal});eq.push({t:b.t,v:bal});pos=null};
 for(let j=0;j<n;j++){const b=c[j];
  if(!pos&&pend.length){const s=pend.find(s=>s.cb<j&&j<=s.exp&&(s.dir>0?b.l<=s.lvl:b.h>=s.lvl));
   if(s){const raw=s.dir>0?Math.min(b.o,s.lvl):Math.max(b.o,s.lvl),entry=raw+s.dir*adv,risk=s.sl==null?s.range*p.rangeMult:(entry-s.sl)*s.dir;pend=[];
    if(risk>0)pos={dir:s.dir,eb:j,entry,sl:entry-s.dir*risk,tp:entry+s.dir*risk*p.rr,u:bal*cfg.riskPct/100/risk};
    else{tr.push({t0:b.t,t1:b.t,dir:s.dir,entry,exit:entry,sl:s.sl,tp:null,pnl:0,reason:'GAP',bal});eq.push({t:b.t,v:bal})}}}
  if(pos){const hs=pos.dir>0?b.l<=pos.sl:b.h>=pos.sl,ht=pos.dir>0?b.h>=pos.tp:b.l<=pos.tp;if(hs)close(b,pos.sl-pos.dir*adv,'SL');else if(ht)close(b,pos.tp-pos.dir*adv,'TP')}
  if(j>=2*N){const q=j-N,hi=bh(q),lo=bl(q);let ph=true,pl=true;for(let m=q-N;m<=q+N;m++){if(m===q)continue;if(m<q?bh(m)>=hi:bh(m)>hi)ph=false;if(m<q?bl(m)<=lo:bl(m)<lo)pl=false}
   if(ph){sH=hi;sHw=c[q].h;sHb=false}if(pl){sL=lo;sLw=c[q].l;sLb=false}}
  if(!sHb&&b.c>sH){streak=iDir===1?streak+1:1;iDir=1;sHb=true}
  if(!sLb&&b.c<sL){streak=iDir===-1?streak+1:1;iDir=-1;sLb=true}
  const e=ema[j]==null?0:b.c>ema[j]?1:b.c<ema[j]?-1:0,La=allow(1,e),Sa=allow(-1,e);
  pend=pend.filter(s=>j<s.exp&&(s.dir>0?La:Sa));
  const tol=p.wickTol+1e-12,bull=b.c>b.o&&(p.wickTol==0?b.o===b.l:b.o-b.l<=tol),bear=b.c<b.o&&(p.wickTol==0?b.o===b.h:b.h-b.o<=tol);
  const d=bull&&La&&p.enL?1:bear&&Sa&&p.enS?-1:0;
  if(d&&!pos&&j>p.emaLen&&ema[j]!=null){const useSw=p.slMode==0,ref=d>0?(p.useWick?sLw:sL):(p.useWick?sHw:sH),sl=useSw&&ref!=null?ref-d*p.slBuf:null,ok=!useSw||(sl!=null&&(d>0?sl<b.o:sl>b.o));
   if(ok){while(pend.length>=p.maxPend)pend.shift();pend.push({dir:d,lvl:b.o,range:b.h-b.l,sl:useSw?sl:null,cb:j,exp:j+p.valid})}}}
 if(pos)close(c[n-1],c[n-1].c-pos.dir*adv,'EOD');
 return{trades:tr,eq,stats:stats(tr,cfg.balance,eq)}}
function stats(tr,b0,eq){const w=tr.filter(t=>t.pnl>0),l=tr.filter(t=>t.pnl<=0),gw=w.reduce((a,t)=>a+t.pnl,0),gl=-l.reduce((a,t)=>a+t.pnl,0);
 let pk=b0,dd=0;for(const q of eq){pk=Math.max(pk,q.v);dd=Math.max(dd,(pk-q.v)/pk)}
 return{n:tr.length,wins:w.length,losses:l.length,winRate:tr.length?w.length/tr.length:null,net:tr.reduce((a,t)=>a+t.pnl,0),
  pf:gl>0?gw/gl:(gw>0?Infinity:null),maxDD:dd,avgWin:w.length?gw/w.length:null,avgLoss:l.length?-gl/l.length:null,
  exp:tr.length?tr.reduce((a,t)=>a+t.pnl,0)/tr.length:null,lowSample:tr.length<30}}
function disagreements(c,ps){let n=0,tot=0;for(let i=0;i<c.length;i++){const d=Object.keys(S).map(k=>(S[k].sig(c,i,ps[k])||{}).dir).filter(Boolean);
 if(d.length){tot++;if(d.includes(1)&&d.includes(-1))n++}}return{conflicts:n,barsWithSignal:tot}}
R.FX={S,backtest,stats,disagreements,atr};if(typeof module!=='undefined')module.exports=R.FX;
})(typeof window!=='undefined'?window:globalThis);
