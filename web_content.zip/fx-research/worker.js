// Cloudflare Worker proxy. Secret: wrangler secret put TD_KEY  (never in code/app).
const OK=['time_series','quote'],SYM=/^[A-Z]{3}\/[A-Z]{3}$/;
export default{async fetch(r,env){const u=new URL(r.url),ep=u.pathname.slice(1);
 const cors={'Access-Control-Allow-Origin':env.ALLOW_ORIGIN||'*','Content-Type':'application/json'};
 if(r.method==='OPTIONS')return new Response(null,{headers:cors});
 const s=u.searchParams.get('symbol')||'';if(!OK.includes(ep)||!SYM.test(s))return new Response('{"status":"error","message":"bad request"}',{status:400,headers:cors});
 const q=new URLSearchParams({symbol:s,apikey:env.TD_KEY,timezone:'UTC'});
 for(const k of['interval','outputsize','start_date','end_date'])if(u.searchParams.get(k))q.set(k,u.searchParams.get(k));
 const x=await fetch(`https://api.twelvedata.com/${ep}?${q}`,{cf:{cacheTtl:60}});return new Response(await x.text(),{status:x.status,headers:cors})}};
