const {backtest,stats}=require('./www/engine.js');const assert=require('assert');
// Known case: flat 1.0000 range then breakout; Donchian must go long at NEXT open, hit TP.
const c=[];for(let i=0;i<40;i++)c.push({t:i*3600,o:1,h:1.001,l:0.999,c:1});
c.push({t:40*3600,o:1,h:1.01,l:1,c:1.009});            // breakout bar (signal at close)
c.push({t:41*3600,o:1.009,h:1.05,l:1.009,c:1.04});     // entry bar, rallies
const r=backtest(c,'donchian',{n:20,atrN:14,slM:2,tpR:2},{balance:10000,riskPct:1,spread:0,slip:0});
assert(r.trades.length===1&&r.trades[0].dir===1&&r.trades[0].entry===1.009,'entry at next open');
assert(r.trades[0].t0===41*3600,'no look-ahead: entry not on signal bar');
assert(r.trades[0].reason==='TP'&&r.trades[0].pnl>0,'TP hit');
// SL-first rule: bar spanning both SL and TP counts as loss
const d=c.slice(0,41);d.push({t:41*3600,o:1.009,h:1.2,l:0.8,c:1});
assert(backtest(d,'donchian',{n:20,atrN:14,slM:2,tpR:2},{balance:10000,riskPct:1,spread:0,slip:0}).trades[0].reason==='SL','SL first');
// Stats arithmetic
const s=stats([{pnl:100},{pnl:-50},{pnl:50}],1000,[{v:1000},{v:1100},{v:1050},{v:1100}]);
assert(s.wins===2&&Math.abs(s.pf-3)<1e-9&&s.exp===100/3&&Math.abs(s.maxDD-50/1100)<1e-9);
console.log('all engine tests passed');

// NO Candle port: bullish NO candle (open==low) -> limit at its open, filled next bar, TP hit after.
const x=[];for(let i=0;i<10;i++){const o=1+i*0.01;x.push({t:i*900,o,h:o+0.012,l:o-0.002,c:o+0.01})}
x.push({t:10*900,o:1.10,h:1.11,l:1.10,c:1.108});
x.push({t:11*900,o:1.108,h:1.109,l:1.099,c:1.10});
x.push({t:12*900,o:1.10,h:1.12,l:1.095,c:1.115});
const q=backtest(x,'nocandle',{pivotN:1,emaLen:5,valid:9,maxPend:3,wickTol:0,slMode:1,slBuf:0,useWick:0,rangeMult:1,rr:1,trendMode:2,enL:1,enS:1},{balance:10000,riskPct:1,spread:0,slip:0});
assert(q.trades.length===1,'one NO trade');const T=q.trades[0];
assert(T.dir===1&&Math.abs(T.entry-1.10)<1e-9&&T.t0===11*900,'fills at NO open on candle #1');
assert(T.reason==='TP'&&Math.abs(T.exit-1.11)<1e-9&&T.pnl>0,'TP at entry+risk*RR');
console.log('NO Candle port test passed');

// Time stop: a trade that never hits SL/TP must exit at bar i+maxBars close with reason TIME.
const {S:SS}=require('./www/engine.js');
SS.tmp={name:'t',def:{},sig:(c,i)=>i===20?{dir:1,sl:5,tp:5,mb:5}:null};
const fl=[];for(let i=0;i<40;i++)fl.push({t:i*900,o:1,h:1.001,l:0.999,c:1});
const tt=backtest(fl,'tmp',{},{balance:10000,riskPct:1,spread:0,slip:0});
assert(tt.trades.length===1&&tt.trades[0].reason==='TIME'&&tt.trades[0].t1===25*900,'time stop');
console.log('time-stop test passed');
