# FX Research (research only, no trading)
Structure: `www/` app (index.html, engine.js) · `worker.js` key-hiding proxy · `.github/workflows/apk.yml` APK build · `test.js` engine tests.

## 1. Secure API key (free)
Cloudflare dashboard → Workers → create from `worker.js` → Settings → Variables → add **secret** `TD_KEY` = your Twelve Data key. Copy the worker URL. The key never touches the app.
## 2. Build APK (phone-only, free)
Make a GitHub repo, upload this folder (incl. `.github`), Actions tab → "Build APK" → Run → download artifact `fx-research-apk` (debug APK, installable; allow unknown sources).
## 3. Use
Settings → paste Worker URL → Save & test.
## Assumptions / limits
- Donchian, Mean Reversion, VWAP are **assumed** implementations. NO Candle is a port of your Pine v6 script (backtestNO in engine.js). Not yet verified against TradingView's trade list; position size uses risk % (the Pine script uses 10% equity), and pivot tie-breaking may differ slightly.
- VWAP uses equal-weighted session price (FX has no real volume).
- Backtest: entry next-candle open, SL before TP in same bar, constant spread, P&L in quote currency (JPY/XAU not converted), no swaps/gaps. Twelve Data free tier limits history/rate; XAU/USD availability depends on your plan.
- Tested: engine unit tests (`node test.js`, passing). NOT tested: live Twelve Data calls, Worker deploy, APK build, on-device performance — I couldn't execute those here.
- Charts are drawn by a built-in canvas chart (no external library, works offline).
