# 🐿️ Flappy Squirrel - Edição Selvagem

Um jogo completo estilo Flappy Bird feito em HTML5 Canvas, Tailwind CSS e Web Audio API nativo.

## 🌟 Funcionalidades
- **3 Estilos de Avatar:** Tico (Clássico), Sombra (Noturno) e Solaris (Dourado Real).
- **Ciclo de Dia e Noite Dinâmico:** Transição suave a cada 59 segundos de jogo (com céu adaptativo, sol, lua, vaga-lumes e estrelas brancas monocromáticas).
- **Progressão de Biomas a cada 50 pontos:**
  - 0-49: Floresta de Outono 🍂
  - 50-99: Bosque Místico 🌲
  - 100-149: Taiga Nevada ❄️
  - 150-199: Bosque Sakura 🌸
  - 200+: Reino Celestial ✨
- **HUD Ergonômico:** Nome do jogador e pontuação lado a lado, com botões amplos de Pausa e Sair logo abaixo.
- **Áudio Nativo:** Efeitos sonoros sintetizados via Web Audio API (sem arquivos externos necessários).
- **Controles Responsivos:** Teclado (Espaço, P, Esc, Enter) e toque em tela em smartphones e tablets.

## 🚀 Como Jogar
Basta extrair o arquivo zip e abrir o arquivo `index.html` (ou `flappy_squirrel.html`) diretamente em qualquer navegador moderno (Chrome, Edge, Firefox, Safari).
