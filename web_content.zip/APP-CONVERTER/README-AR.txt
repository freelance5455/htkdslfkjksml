AMAZON GAZA — تحويل الموقع إلى APK

1) انشر apps/web على Vercel.
2) انشر apps/api على Render واربط PostgreSQL.
3) بعد حصولك على رابط HTTPS للواجهة، افتح index.html هنا.
4) بدّل YOUR-AMAZON-GAZA.vercel.app بالرابط الحقيقي.
5) ارفع APP-CONVERTER إلى خدمة تحويل HTML/ZIP إلى APK.

مهم: التطبيق يعمل بالإنترنت فقط، لذلك يجب أن يكون رابط HTTPS النهائي متاحاً.
