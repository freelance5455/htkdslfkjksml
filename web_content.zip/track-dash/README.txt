Track Dash - 3D endless runner

RUN LOCALLY
  Open index.html in a browser, or serve the folder:  python3 -m http.server 8000
  Needs internet once: three.js (r128) and the Bungee font load from CDNs.
  For fully offline use / Android: download
  https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
  save it as three.min.js next to index.html, and change the script tag in index.html to:
  <script src="three.min.js"></script>

ANDROID APP (Capacitor)
  npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
  npx cap init TrackDash com.example.trackdash --web-dir=www
  mkdir www && cp index.html style.css game.js three.min.js www/
  npx cap add android && npx cap sync
  npx cap open android   (build the APK in Android Studio)
  Tip: set the activity to fullscreen portrait/landscape in AndroidManifest.xml.

FILES: index.html, style.css, game.js
