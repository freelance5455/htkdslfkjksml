const $=id=>document.getElementById(id), rnd=(a,b)=>a+Math.random()*(b-a), ri=n=>Math.floor(Math.random()*n);
const LX=[-2.4,0,2.4], V0=14, VMAX=38;
let best=0; try{best=+localStorage.getItem('trackdash-best')||0}catch(e){}

/* ---------- renderer / scene ---------- */
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.shadowMap.enabled=true;
$('wrap').appendChild(renderer.domElement);
const scene=new THREE.Scene();
scene.fog=new THREE.Fog(0xd9715f,45,170);
(()=>{const c=document.createElement('canvas');c.width=2;c.height=256;const x=c.getContext('2d'),g=x.createLinearGradient(0,0,0,256);
 g.addColorStop(0,'#2a1654');g.addColorStop(.5,'#8a3f7a');g.addColorStop(.8,'#ff8a4c');g.addColorStop(1,'#ffc27a');x.fillStyle=g;x.fillRect(0,0,2,256);
 scene.background=new THREE.CanvasTexture(c)})();
const camera=new THREE.PerspectiveCamera(62,1,.1,320);
scene.add(new THREE.HemisphereLight(0xffc9a0,0x3a2068,.95));
const sun=new THREE.DirectionalLight(0xffb27a,1.1);sun.position.set(-6,12,6);sun.castShadow=true;
Object.assign(sun.shadow.camera,{left:-8,right:8,top:8,bottom:-8,near:1,far:40});sun.shadow.mapSize.set(1024,1024);
scene.add(sun,sun.target);
const sunDisc=new THREE.Mesh(new THREE.CircleGeometry(24,40),new THREE.MeshBasicMaterial({color:0xffe2a0,fog:false}));
sunDisc.position.set(0,22,-250);scene.add(sunDisc);

const M=(c,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:c,roughness:.7,metalness:.1},o));
const box=(w,h,d,m,x=0,y=0,z=0)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);return o};

/* ---------- player ---------- */
const pl=new THREE.Group();scene.add(pl);
const body=new THREE.Group();pl.add(body);
const skin=M(0xf1b58c),shirt=M(0xff6b3d),pants=M(0x2d4fd8),shoe=M(0xf5f5f5),capM=M(0x19d3c5),packM=M(0xffc83d);
body.add(box(.72,.85,.42,shirt,0,1.15,0),box(.42,.42,.42,skin,0,1.78,0),box(.48,.14,.48,capM,0,2.0,0),box(.42,.05,.26,capM,0,1.94,-.32),box(.52,.6,.22,packM,0,1.2,.32),
 box(.06,.06,.02,M(0x111111),-.1,1.8,-.22),box(.06,.06,.02,M(0x111111),.1,1.8,-.22));
const limb=(w,h,d,m,x,y)=>{const g=new THREE.Group();g.position.set(x,y,0);g.add(box(w,h,d,m,0,-h/2,0));body.add(g);return g};
const armL=limb(.2,.75,.22,shirt,-.47,1.52),armR=limb(.2,.75,.22,shirt,.47,1.52),legL=limb(.28,.78,.3,pants,-.19,.8),legR=limb(.28,.78,.3,pants,.19,.8);
legL.add(box(.32,.14,.44,shoe,0,-.8,-.06));legR.add(box(.32,.14,.44,shoe,0,-.8,-.06));
pl.traverse(o=>{if(o.isMesh)o.castShadow=true});

/* ---------- track tiles ---------- */
const TL=40,tiles=[];
const bedM=M(0x3b3040),railM=M(0xc4c4d0,{metalness:.8,roughness:.3}),sleepM=M(0x5a3a2a),platM=M(0x7a6a7a),lineM=M(0xffc83d,{emissive:0x553300});
const sleepG=new THREE.BoxGeometry(1.4,.12,.5),railG=new THREE.BoxGeometry(.1,.16,TL);
for(let i=0;i<5;i++){
 const g=new THREE.Group();
 const bed=box(26,.2,TL,bedM,0,-.1,0);bed.receiveShadow=true;g.add(bed);
 for(const s of [-1,1]){const p=box(4,.5,TL,platM,s*8,.15,0);p.receiveShadow=true;g.add(p);g.add(box(.2,.05,TL,lineM,s*6.1,.42,0))}
 for(const x of LX){for(const r of [-.55,.55])g.add(box(.1,.16,TL,railM,x+r,.08,0)).position;
  for(let k=0;k<TL/2;k++){const s=new THREE.Mesh(sleepG,sleepM);s.position.set(x,.04,-TL/2+k*2+1);s.receiveShadow=true;g.add(s)}}
 g.position.z=20-i*TL;scene.add(g);tiles.push(g);
}
/* ---------- buildings ---------- */
const wtex=(()=>{const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');x.fillStyle='#1b1330';x.fillRect(0,0,64,64);
 for(let i=0;i<4;i++)for(let j=0;j<4;j++){x.fillStyle=Math.random()<.4?'#ffd27a':'#3a2c5c';x.fillRect(i*16+3,j*16+3,10,10)}
 const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;return t})();
const blds=[],BN=14,BS=24;
for(const s of [-1,1])for(let i=0;i<BN;i++){
 const w=rnd(8,13),h=rnd(14,44),d=rnd(14,20),g=new THREE.BoxGeometry(w,h,d),uv=g.attributes.uv;
 for(let k=0;k<uv.count;k++)uv.setXY(k,uv.getX(k)*w/9,uv.getY(k)*h/9);
 const b=new THREE.Mesh(g,new THREE.MeshLambertMaterial({map:wtex,color:[0xffffff,0xd8c8ff,0xffd2c0][ri(3)]}));
 b.position.set(s*(10.5+w/2+rnd(0,3)),h/2-.3,10-i*BS);scene.add(b);blds.push(b);
}

/* ---------- obstacles / coins ---------- */
const obstacles=[],coins=[],parts=[];
const trainCols=[0xd9433b,0x2a7fd1,0x2fb37a,0xe0a82e],darkM=M(0x1a1626),winM=M(0x9fd8ff,{emissive:0x2a4a66}),lampM=M(0xfff2a0,{emissive:0xffe070}),
 orangeM=M(0xff7a1a),whiteM=M(0xf4f4f4),steelM=M(0x777788,{metalness:.6});
function addTrain(x,z){
 const g=new THREE.Group(),col=trainCols[ri(4)],L=12;
 g.add(box(2.1,3,L,M(col),0,1.7,0),box(1.8,.5,L-.6,darkM,0,.3,0),box(2.0,.2,L,M(0x555566),0,3.25,0),box(2.12,.3,L+.02,whiteM,0,1.1,0));
 for(let k=0;k<4;k++)for(const s of [-1,1])g.add(box(.05,.85,1.5,winM,s*1.06,2.4,-4.2+k*2.8));
 g.add(box(1.6,1.2,.06,darkM,0,2.3,L/2+.01),box(.4,.4,.08,lampM,-.6,1.4,L/2+.03),box(.4,.4,.08,lampM,.6,1.4,L/2+.03),box(1.7,.4,.06,winM,0,2.9,L/2+.03));
 g.position.set(x,0,z);scene.add(g);obstacles.push({m:g,x,hz:L/2,y0:0,y1:3.1});
}
function addLow(x,z){
 const g=new THREE.Group();
 g.add(box(.18,.9,.3,steelM,-.8,.45,0),box(.18,.9,.3,steelM,.8,.45,0),box(1.9,.28,.3,orangeM,0,.74,0),box(1.9,.28,.3,whiteM,0,.4,0));
 for(let k=0;k<4;k++)g.add(box(.2,.28,.32,M(0x222222),-.7+k*.47,.74,0));
 g.position.set(x,0,z);scene.add(g);obstacles.push({m:g,x,hz:.3,y0:0,y1:.9});
}
function addHigh(x,z){
 const g=new THREE.Group();
 g.add(box(.2,2.6,.3,steelM,-1,1.3,0),box(.2,2.6,.3,steelM,1,1.3,0),box(2.2,.7,.35,M(0x2a7fd1),0,1.85,0),box(1.8,.12,.37,lampM,0,1.85,0));
 g.position.set(x,0,z);scene.add(g);obstacles.push({m:g,x,hz:.35,y0:1.3,y1:2.5});
}
const coinG=new THREE.CylinderGeometry(.34,.34,.08,20).rotateX(Math.PI/2),coinM=M(0xffc83d,{metalness:.7,roughness:.25,emissive:0x664400});
function addCoin(x,y,z){const m=new THREE.Mesh(coinG,coinM);m.position.set(x,y,z);scene.add(m);coins.push({m,x,y})}
function coinLine(x,z,n,gap,y){for(let i=0;i<n;i++)addCoin(x,y,z-i*gap)}
function coinArc(x,z){[1.0,1.7,2.1,1.7,1.0].forEach((y,i)=>addCoin(x,y,z+1.6-i*.8))}

let nextZ=-40;
function spawnRow(){
 const r=Math.random();let L=2;
 if(r<.3){L=12;const safe=ri(3);for(let i=0;i<3;i++)if(i!==safe&&Math.random()<.8)addTrain(LX[i],nextZ-L/2);
  if(Math.random()<.8)coinLine(LX[safe],nextZ-1,8,1.3,.9)}
 else if(r<.5){let any=-1;for(let i=0;i<3;i++)if(Math.random()<.6){addLow(LX[i],nextZ-1);if(any<0)any=i}
  if(any<0){any=ri(3);addLow(LX[any],nextZ-1)}coinArc(LX[any],nextZ-1)}
 else if(r<.7){let any=-1;for(let i=0;i<3;i++)if(Math.random()<.6){addHigh(LX[i],nextZ-1);if(any<0)any=i}
  if(any<0){any=ri(3);addHigh(LX[any],nextZ-1)}coinLine(LX[any],nextZ+1,4,.8,.6)}
 else if(r<.85){let free=ri(3);for(let i=0;i<3;i++)if(i!==free)(Math.random()<.5?addLow:addHigh)(LX[i],nextZ-1);coinLine(LX[free],nextZ+3,6,1.3,.9)}
 else{L=14;let l=ri(3);for(let i=0;i<9;i++){if(i===4)l=Math.max(0,Math.min(2,l+(Math.random()<.5?-1:1)));addCoin(LX[l],.9,nextZ-i*1.5)}}
 nextZ-=L+10+speed*.7+rnd(0,6);
}

/* ---------- particles ---------- */
const pG=new THREE.BoxGeometry(.14,.14,.14);
function burst(x,y,z,col,n,sp=4){for(let i=0;i<n;i++){const m=new THREE.Mesh(pG,new THREE.MeshBasicMaterial({color:col}));m.position.set(x,y,z);scene.add(m);
 parts.push({m,vx:rnd(-sp,sp),vy:rnd(1,sp+2),vz:rnd(-sp,sp),life:rnd(.35,.7)})}}

/* ---------- audio ---------- */
let AC,master,muted=false;
function audio(){if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)();master=AC.createGain();master.gain.value=.5;master.connect(AC.destination)}catch(e){}}if(AC&&AC.state==='suspended')AC.resume()}
function tone(f,dur,type='square',vol=.12,slide=0,delay=0){if(!AC||muted)return;const t=AC.currentTime+delay,o=AC.createOscillator(),g=AC.createGain();o.type=type;o.frequency.setValueAtTime(f,t);
 if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(30,f+slide),t+dur);g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);o.connect(g);g.connect(master);o.start(t);o.stop(t+dur)}
function noise(dur,vol,fq){if(!AC||muted)return;const n=AC.sampleRate*dur,b=AC.createBuffer(1,n,AC.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*(1-i/n);
 const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=b;f.type='lowpass';f.frequency.value=fq;g.gain.value=vol;s.connect(f);f.connect(g);g.connect(master);s.start()}
const SFX={coin(){tone(988,.08,'square',.1);tone(1319,.16,'square',.1,0,.07)},jump(){tone(300,.22,'sine',.22,500)},slide(){noise(.35,.3,2000)},lane(){tone(240,.08,'triangle',.15,-80)},
 land(){tone(100,.1,'sine',.25,-40)},crash(){noise(.9,.7,700);tone(130,.6,'sawtooth',.25,-90)}};
let step=0;
function music(){if(state==='play'&&AC&&!muted){const arp=[440,523,659,523,587,523,659,784],bass=[110,110,131,98];
 if(step%4===0)tone(bass[(step>>3)%4],.22,'triangle',.16);tone(arp[step%8]*((step>>4)%2?1.125:1),.09,'square',.035);step++}
 setTimeout(music,Math.max(85,150-(speed-V0)*2.5))}

/* ---------- state ---------- */
let state='menu',speed=V0,time=0,dist=0,coinN=0,lane=1,px=0,py=0,vy=0,slideT=0,runPh=0,deadT=0,shake=0,camX=0;
const g=34;
function reset(){
 for(const o of obstacles)scene.remove(o.m);for(const c of coins)scene.remove(c.m);for(const p of parts)scene.remove(p.m);
 obstacles.length=coins.length=parts.length=0;
 nextZ=-45;time=dist=coinN=0;speed=V0;lane=1;px=0;py=vy=0;slideT=0;deadT=0;shake=0;pl.rotation.set(0,0,0);pl.position.set(0,0,0);
 $('flash').style.opacity=0;$('best').textContent='Best '+best;
}
function start(){audio();reset();state='play';for(const id of ['menu','over','pause'])$(id).classList.remove('on');$('hud').style.display='flex';$('btns').style.display='flex'}
function die(){
 state='dead';deadT=0;shake=1;SFX.crash();burst(px,1,0,0xffc83d,24,6);burst(px,1,0,0xff6b3d,16,5);$('flash').style.opacity=.55;setTimeout(()=>{$('flash').style.opacity=0},120);
 const sc=score();if(sc>best){best=sc;try{localStorage.setItem('trackdash-best',best)}catch(e){}}
 setTimeout(()=>{if(state==='dead'){$('fs').textContent=sc;$('fc').textContent=coinN;$('fb').textContent=best;$('over').classList.add('on')}},1000);
}
const score=()=>Math.floor(dist)+coinN*10;
function togglePause(){if(state==='play'){state='pause';$('pause').classList.add('on')}else if(state==='pause'){state='play';$('pause').classList.remove('on')}}

/* ---------- input ---------- */
function act(a){
 if(state!=='play'){if(state==='dead'&&deadT>.9&&(a==='go'))start();return}
 if(a==='left'&&lane>0){lane--;SFX.lane()}
 else if(a==='right'&&lane<2){lane++;SFX.lane()}
 else if(a==='up'&&py<=.01){vy=12;slideT=0;SFX.jump()}
 else if(a==='down'){if(py>.01)vy=-26;slideT=.75;SFX.slide()}
}
addEventListener('keydown',e=>{audio();const k=e.key.toLowerCase();
 if(['arrowleft','arrowright','arrowup','arrowdown',' '].includes(k))e.preventDefault();
 if(k==='arrowleft'||k==='a')act('left');else if(k==='arrowright'||k==='d')act('right');
 else if(k==='arrowup'||k==='w'||k===' ')act('up');else if(k==='arrowdown'||k==='s')act('down');
 else if(k==='p'||k==='escape')togglePause();else if(k==='m')toggleMute();
 else if(k==='enter'||k==='r'){if(state==='menu'||state==='dead')act2()}});
function act2(){if(state==='menu'||(state==='dead'&&deadT>.9))start()}
let tx,ty;
addEventListener('touchstart',e=>{audio();tx=e.touches[0].clientX;ty=e.touches[0].clientY},{passive:true});
addEventListener('touchend',e=>{if(tx==null||state!=='play')return;const t=e.changedTouches[0],dx=t.clientX-tx,dy=t.clientY-ty;
 if(Math.max(Math.abs(dx),Math.abs(dy))<24)act('up');else if(Math.abs(dx)>Math.abs(dy))act(dx>0?'right':'left');else act(dy<0?'up':'down');tx=null},{passive:true});
function toggleMute(){muted=!muted;$('mbtn').style.opacity=muted?.4:1}
$('start').onclick=start;$('again').onclick=start;$('resume').onclick=togglePause;$('pbtn').onclick=togglePause;$('mbtn').onclick=toggleMute;
document.addEventListener('visibilitychange',()=>{if(document.hidden&&state==='play')togglePause()});

/* ---------- loop ---------- */
function scroll(d){
 for(const t of tiles){t.position.z+=d;if(t.position.z>TL/2+14)t.position.z-=TL*tiles.length}
 for(const b of blds){b.position.z+=d;if(b.position.z>45)b.position.z-=BN*BS}
}
function animatePlayer(dt,running){
 const sl=slideT>0&&py<=.01,air=py>.01;
 if(running)runPh+=dt*(8+speed*.45);
 const s=Math.sin(runPh);
 if(air){legL.rotation.x=-.9;legR.rotation.x=.5;armL.rotation.x=-2.6;armR.rotation.x=-2.2;body.position.y=0}
 else if(sl){legL.rotation.x=-1.3;legR.rotation.x=-1.3;armL.rotation.x=-1.5;armR.rotation.x=-1.5}
 else{legL.rotation.x=s*1.0;legR.rotation.x=-s*1.0;armL.rotation.x=-s*.9;armR.rotation.x=s*.9;body.position.y=Math.abs(s)*.09}
 const tilt=sl?1.15:0;pl.rotation.x+=(tilt-pl.rotation.x)*Math.min(1,dt*18);
}
let last=performance.now();
function frame(now){
 requestAnimationFrame(frame);
 const dt=Math.min(.05,(now-last)/1000);last=now;
 if(state==='menu'){scroll(9*dt);animatePlayer(dt,true);runPh+=0;}
 else if(state==='play')update(dt);
 else if(state==='dead'){deadT+=dt;pl.rotation.x-=Math.max(0,(1.4+pl.rotation.x*-1))>0?5*dt:0;if(pl.rotation.x<-1.5)pl.rotation.x=-1.5;pl.position.y=Math.max(0,pl.position.y-dt*3);
  shake=Math.max(0,shake-dt*2)}
 for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.life-=dt;p.vy-=14*dt;p.m.position.x+=p.vx*dt;p.m.position.y=Math.max(.05,p.m.position.y+p.vy*dt);p.m.position.z+=p.vz*dt;
  if(p.life<=0){scene.remove(p.m);parts.splice(i,1)}}
 for(const c of coins)c.m.rotation.y+=dt*4;
 // camera
 camX+=(px*.55-camX)*Math.min(1,dt*6);
 const sx=shake*(Math.random()-.5)*.6,sy=shake*(Math.random()-.5)*.6;
 camera.position.set(camX+sx,(innerWidth<innerHeight?5.4:4.4)+sy+py*.25,innerWidth<innerHeight?10:7.5);
 camera.lookAt(px*.3,1.5,-10);
 camera.fov+=((state==='play'?60+(speed-V0)*.35:62)-camera.fov)*.05;camera.updateProjectionMatrix();
 sun.position.set(px-6,12,6);sun.target.position.set(px,0,0);
 renderer.render(scene,camera);
}
function update(dt){
 time+=dt;speed=Math.min(VMAX,V0+time*.4);const d=speed*dt;dist+=d/2;
 scroll(d);nextZ+=d;while(nextZ>-130)spawnRow();
 for(let i=obstacles.length-1;i>=0;i--){const o=obstacles[i];o.m.position.z+=d;if(o.m.position.z>o.hz+14){scene.remove(o.m);obstacles.splice(i,1)}}
 for(let i=coins.length-1;i>=0;i--){const c=coins[i];c.m.position.z+=d;if(c.m.position.z>12){scene.remove(c.m);coins.splice(i,1)}}
 // player
 px+=(LX[lane]-px)*Math.min(1,dt*15);pl.position.x=px;pl.rotation.z=(px-LX[lane])*.12;
 if(slideT>0)slideT-=dt;
 if(py>0||vy>0){vy-=g*dt;py+=vy*dt;if(py<=0){py=0;vy=0;SFX.land();burst(px,.1,0,0xdddddd,5,2)}}
 pl.position.y=py;animatePlayer(dt,true);
 if(py<=.01&&Math.random()<dt*12*(speed/VMAX))burst(px,.05,.3,0x9a8a8a,1,1);
 // collisions
 const sliding=slideT>0&&py<=.01,ph=sliding?.75:1.9,pz=.35;
 for(const o of obstacles){const oz=o.m.position.z;
  if(Math.abs(oz)<o.hz+pz&&Math.abs(o.x-px)<1.15&&py<o.y1&&py+ph>o.y0){die();return}}
 for(let i=coins.length-1;i>=0;i--){const c=coins[i],cz=c.m.position.z;
  if(Math.abs(cz)<.9&&Math.abs(c.x-px)<1&&c.y>py-.2&&c.y<py+ph+.2){scene.remove(c.m);coins.splice(i,1);coinN++;SFX.coin();burst(px,c.y,0,0xffd75a,6,3);
   const cn=$('coins');cn.classList.remove('pop');void cn.offsetWidth;cn.classList.add('pop')}}
 $('sc').textContent=score();$('cn').textContent=coinN;$('mb').style.width=((speed-V0)/(VMAX-V0)*100)+'%';
}
function resize(){const w=innerWidth,h=innerHeight-(parseFloat(getComputedStyle(document.documentElement).paddingTop)||0);renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix()}
addEventListener('resize',resize);resize();reset();music();
requestAnimationFrame(frame);
