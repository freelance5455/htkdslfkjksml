# Socle 3.7 — Conséquences des décisions du manager

## Objectif
Rendre certaines décisions de gestion réellement engageantes, avec des effets persistants sur la trésorerie, les relations avec le conseil et la carrière du manager.

## Fonctions intégrées
- Négociation des contrats du staff : proposition du club, acceptation/refus ou contre-proposition, puis signature explicite par le manager.
- Contrats de 1 à 5 saisons, salaire journalier en Gold et prime de signature.
- Prime payée à la signature ; salaire journalier déduit de la trésorerie et inscrit au journal financier.
- Paiement partiel si la trésorerie ne suffit pas ; signalement de l'impayé et baisse de la confiance financière du conseil.
- Évaluation de la sécurité du manager : si la confiance globale reste strictement inférieure à 15/100 pendant sept jours consécutifs, le manager est licencié, son poste est libéré et l'événement est archivé. Une remontée de confiance remet le compteur à zéro.
- Calcul de modificateurs transparents issus des compétences du staff et des tâches déléguées, pour préparer leur raccordement aux systèmes de développement sportif.
- Interface d'administration du staff : proposer, répondre et signer les contrats.

## Limites explicites
- Les salaires du staff sont exprimés en Gold par jour afin d'éviter de supposer une durée annuelle de saison non définie.
- Les modificateurs de compétence sont calculés et testés, mais leur effet direct sur les résultats sportifs, le développement des damistes et les blessures reste à connecter dans une étape ultérieure.
- Les montants et seuils de ce socle sont des paramètres de simulation provisoires, pas des barèmes historiques du CGD.
- Le rendu visuel réel sur appareil mobile n'a pas été validé dans ce cycle.
