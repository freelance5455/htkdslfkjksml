SKETCHBOOK — BLE + CLASSIC BLUETOOTH ANDROID PROJECT

This is a standalone Android Studio project for Sketchbook. It is NOT an APK.
It adds an Android JavaScript bridge for:
- Classic Bluetooth SPP: already-paired HC-05 / HC-06 / ESP32 BluetoothSerial devices.
- Bluetooth Low Energy: scan, connect by supplied service + characteristic UUID, write, and receive notifications.
- Existing HTML editor and AI features remain in assets/index.html.

IMPORTANT LIMITATIONS
- This is an initial implementation and has not been built or tested on a physical phone/board.
- BLE boards must advertise and implement the exact service and characteristic UUIDs entered in Sketchbook.
- The initial BLE scanner connects automatically if exactly one device is found; if multiple devices are found it asks for a device number.
- Classic Bluetooth devices must first be paired in Android Settings.
- Classic SPP uses the standard serial UUID 00001101-0000-1000-8000-00805F9B34FB. A board using a custom profile needs a code change.
- The HTML-to-APK website wrapper will NOT include this native bridge. Build this project as the separate Sketchbook APK.
- USB serial and firmware flashing are not added by this Bluetooth bridge.
- Keep your OpenRouter API key private. It is stored by the HTML app in local browser storage.

BUILD
1. Open this folder as a project in Android Studio.
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the resulting app-debug.apk on your Android phone.
5. On Android, enable Bluetooth and grant the requested nearby-device permissions.
6. Pair HC-05 / HC-06 in Android Settings before using Classic Bluetooth.

The project uses Java and a WebView, and the app remains named Sketchbook.
