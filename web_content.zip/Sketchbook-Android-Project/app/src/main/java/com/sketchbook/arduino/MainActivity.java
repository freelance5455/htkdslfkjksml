
package com.sketchbook.arduino;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private WebView webView;
    private BluetoothAdapter adapter;
    private BluetoothSocket classicSocket;
    private OutputStream classicOut;
    private Thread classicReader;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic bleCharacteristic;
    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int REQ_BT = 77;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF101827);
        getWindow().setNavigationBarColor(0xFF101827);
        BluetoothManager manager=(BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        adapter=manager==null?null:manager.getAdapter();
        webView=new WebView(this);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new BtBridge(), "SketchbookBT");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean has(String permission) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED;
    }
    private boolean permissionsOk() {
        if(Build.VERSION.SDK_INT>=31)
            return has(Manifest.permission.BLUETOOTH_CONNECT) && has(Manifest.permission.BLUETOOTH_SCAN);
        return Build.VERSION.SDK_INT<23 || has(Manifest.permission.ACCESS_FINE_LOCATION);
    }
    private void askPermissions() {
        if(Build.VERSION.SDK_INT>=31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQ_BT);
        else if(Build.VERSION.SDK_INT>=23) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_BT);
    }
    private void js(String kind,String payload) {
        try {
            JSONObject o=new JSONObject(); o.put("kind",kind); o.put("payload",payload);
            String encoded=o.toString();
            runOnUiThread(()->webView.evaluateJavascript("window.sketchbookBtEvent && window.sketchbookBtEvent("+JSONObject.quote(kind)+","+JSONObject.quote(payload)+")",null));
        } catch(Exception ignored) {}
    }
    private String safeName(BluetoothDevice d) {
        try { String n=d.getName(); return n==null?"Bluetooth device":n; } catch(SecurityException e){return "Bluetooth device";}
    }

    private class BtBridge {
        @JavascriptInterface public void listPairedDevices() {
            if(!permissionsOk()){askPermissions();js("classicStatus","Grant Bluetooth permission, then tap Load paired devices again.");return;}
            try {
                JSONArray a=new JSONArray();
                for(BluetoothDevice d:adapter.getBondedDevices()){
                    JSONObject o=new JSONObject();o.put("name",safeName(d));o.put("address",d.getAddress());a.put(o);
                }
                js("classicDevices",a.toString());
            } catch(Exception e){js("classicStatus","Could not list paired devices: "+e.getMessage());}
        }
        @JavascriptInterface public void classicConnect(String address) {
            if(!permissionsOk()){askPermissions();js("classicStatus","Bluetooth permission required. Try Connect again after granting it.");return;}
            new Thread(()->{
                classicDisconnectInternal();
                try {
                    BluetoothDevice d=adapter.getRemoteDevice(address);
                    classicSocket=d.createRfcommSocketToServiceRecord(SPP_UUID);
                    adapter.cancelDiscovery();
                    classicSocket.connect(); classicOut=classicSocket.getOutputStream();
                    js("classicStatus","Connected to "+safeName(d));
                    InputStream in=classicSocket.getInputStream(); byte[] buf=new byte[1024];
                    classicReader=Thread.currentThread();
                    int n; while(classicSocket!=null && (n=in.read(buf))!=-1) js("classicData",new String(buf,0,n,StandardCharsets.UTF_8));
                } catch(Exception e){js("classicStatus","Connection failed: "+e.getMessage());classicDisconnectInternal();}
            }).start();
        }
        @JavascriptInterface public void classicSend(String text) {
            new Thread(()->{try{if(classicOut==null)throw new IOException("Not connected");classicOut.write((text+"\n").getBytes(StandardCharsets.UTF_8));classicOut.flush();}catch(Exception e){js("classicStatus","Send failed: "+e.getMessage());}}).start();
        }
        @JavascriptInterface public void classicDisconnect(){classicDisconnectInternal();js("classicStatus","Disconnected");}
        @JavascriptInterface public void scanBle() {
            if(!permissionsOk()){askPermissions();js("bleStatus","Grant Bluetooth permissions, then tap Connect BLE again.");return;}
            if(adapter==null||!adapter.isEnabled()){js("bleStatus","Turn on Bluetooth in Android Settings.");return;}
            scanner=adapter.getBluetoothLeScanner();
            if(scanner==null){js("bleStatus","BLE scanner unavailable.");return;}
            JSONArray found=new JSONArray();
            Map<String,BluetoothDevice> devices=new LinkedHashMap<>();
            scanCallback=new ScanCallback(){
                @Override public void onScanResult(int type,ScanResult result){
                    BluetoothDevice d=result.getDevice(); String address=d.getAddress();
                    if(!devices.containsKey(address)){
                        devices.put(address,d);
                        try{JSONObject o=new JSONObject();o.put("name",safeName(d));o.put("address",address);found.put(o);}catch(Exception ignored){}
                    }
                }
                @Override public void onScanFailed(int error){js("bleStatus","BLE scan failed: "+error);}
            };
            try{
                scanner.startScan(scanCallback);
                handler.postDelayed(()->{
                    try{scanner.stopScan(scanCallback);}catch(Exception ignored){}
                    js("bleScan",found.toString());
                },7000);
            }catch(Exception e){js("bleStatus","BLE scan error: "+e.getMessage());}
        }
        @JavascriptInterface public void bleConnect(String address,String serviceUuid,String characteristicUuid) {
            if(!permissionsOk()){askPermissions();js("bleStatus","Bluetooth permission required.");return;}
            try{
                BluetoothDevice d=adapter.getRemoteDevice(address);
                gatt=d.connectGatt(MainActivity.this,false,new BluetoothGattCallback(){
                    @Override public void onConnectionStateChange(BluetoothGatt g,int status,int state){
                        if(state==BluetoothProfile.STATE_CONNECTED){js("bleStatus","Connected. Discovering services…");g.discoverServices();}
                        else if(state==BluetoothProfile.STATE_DISCONNECTED){bleCharacteristic=null;js("bleStatus","Disconnected");}
                    }
                    @Override public void onServicesDiscovered(BluetoothGatt g,int status){
                        try{
                            BluetoothGattService svc=g.getService(UUID.fromString(serviceUuid));
                            if(svc==null)throw new Exception("Service UUID not found");
                            bleCharacteristic=svc.getCharacteristic(UUID.fromString(characteristicUuid));
                            if(bleCharacteristic==null)throw new Exception("Characteristic UUID not found");
                            int p=bleCharacteristic.getProperties();
                            if((p & (BluetoothGattCharacteristic.PROPERTY_NOTIFY|BluetoothGattCharacteristic.PROPERTY_INDICATE))!=0){
                                g.setCharacteristicNotification(bleCharacteristic,true);
                                BluetoothGattDescriptor desc=bleCharacteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
                                if(desc!=null){desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);g.writeDescriptor(desc);}
                            }
                            js("bleStatus","Connected to "+safeName(d)+". Ready.");
                        }catch(Exception e){js("bleStatus","BLE setup failed: "+e.getMessage());}
                    }
                    @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){
                        byte[] v=c.getValue();js("bleData",new String(v,StandardCharsets.UTF_8));
                    }
                });
            }catch(Exception e){js("bleStatus","BLE connect failed: "+e.getMessage());}
        }
        @JavascriptInterface public void bleSend(String text){
            try{
                if(gatt==null||bleCharacteristic==null)throw new Exception("Not connected");
                bleCharacteristic.setValue(text.getBytes(StandardCharsets.UTF_8));
                bleCharacteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                if(!gatt.writeCharacteristic(bleCharacteristic))throw new Exception("Write could not be queued");
            }catch(Exception e){js("bleStatus","BLE send failed: "+e.getMessage());}
        }
        @JavascriptInterface public void bleDisconnect(){try{if(gatt!=null){gatt.disconnect();gatt.close();gatt=null;}bleCharacteristic=null;js("bleStatus","Disconnected");}catch(Exception e){js("bleStatus","Disconnect error: "+e.getMessage());}}
    }

    private synchronized void classicDisconnectInternal(){
        try{if(classicSocket!=null)classicSocket.close();}catch(Exception ignored){}
        classicSocket=null;classicOut=null;classicReader=null;
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==REQ_BT) js("classicStatus",(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)?"Permission granted. Tap the Bluetooth action again.":"Bluetooth permission denied.");
    }
    @Override public void onDestroy(){
        classicDisconnectInternal();
        try{if(gatt!=null){gatt.disconnect();gatt.close();}}catch(Exception ignored){}
        if(webView!=null){webView.destroy();webView=null;}
        super.onDestroy();
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
