const MAP_NAMES=['Castle','Lanterns','Harbor','Bamboo','Blossom'];
const MAP_COUNT=MAP_NAMES.length;
function mapRng(seed){let s=seed;return()=>{s=(s*16807)%2147483647;return (s-1)/2147483646;};}
function mapGlow(c,x,y,r,col,a){const g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,hexA(col,a));g.addColorStop(1,hexA(col,0));c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);}
function mapRidge(c,base,amp,seed,col){
  c.fillStyle=col;c.beginPath();c.moveTo(0,H);
  for(let x=0;x<=W;x+=8){const y=base+Math.sin(x*.009+seed)*amp+Math.sin(x*.023+seed*2.3)*amp*.4;c.lineTo(x,y);}
  c.lineTo(W,H);c.closePath();c.fill();
}
function mapStarfield(c,n,seed,maxY){const r=mapRng(seed);const out=[];for(let i=0;i<n;i++)out.push({x:r()*W,y:r()*maxY,p:r()*6});return out;}
const MAP_STARS=[mapStarfield(120,1),mapStarfield(120,2),mapStarfield(90,3),mapStarfield(100,4),mapStarfield(110,5)];
const MAP_CACHE=[];
function mapStatic(id){
  if(MAP_CACHE[id])return MAP_CACHE[id];
  const cv=document.createElement('canvas');cv.width=W;cv.height=H;
  MAP_PAINT[id].s(cv.getContext('2d'));
  MAP_CACHE[id]=cv;return cv;
}
function mapBackdrop(id,t){
  ctx.drawImage(mapStatic(id),0,0);
  MAP_PAINT[id].d(ctx,t);
}
const MAP_PAINT=[
{ /* 0 Castle */
  s(c){
    const g=c.createLinearGradient(0,0,0,GROUND);g.addColorStop(0,'#0e0620');g.addColorStop(.6,'#3a1d58');g.addColorStop(1,'#8a5a9a');
    c.fillStyle=g;c.fillRect(0,0,W,H);
    mapRidge(c,420,30,1,'#2a1640');
    c.fillStyle='#0c0814';
    const cx=640;
    c.fillRect(cx-240,300,480,300);
    c.fillRect(cx-150,190,300,120);
    for(const [x,w,h] of [[cx-260,90,400],[cx+170,90,400],[cx-70,140,250]]){
      c.fillRect(x,300-(h-300),w,h);
      c.beginPath();c.moveTo(x-8,300-(h-300));c.lineTo(x+w/2,300-(h-300)-130);c.lineTo(x+w+8,300-(h-300));c.fill();
    }
    c.fillRect(cx-22,120,44,80);c.beginPath();c.moveTo(cx-30,120);c.lineTo(cx,40);c.lineTo(cx+30,120);c.fill();
    c.strokeStyle='rgba(255,200,140,.25)';c.lineWidth=2;c.beginPath();c.moveTo(cx+260,300);c.lineTo(cx+262,40);c.stroke();
    c.fillStyle='#120a1c';
    c.beginPath();c.moveTo(-40,GROUND);c.lineTo(W+40,GROUND);c.lineTo(W*.8,H);c.lineTo(W*.2,H);c.fill();
    c.fillStyle='#2a2430';
    for(let i=0;i<14;i++){const y=GROUND+(i*i)*.7+6;c.fillRect(0,y,W,1);}
    c.strokeStyle='rgba(0,0,0,.35)';c.lineWidth=2;
    for(let x=-200;x<W+200;x+=110){c.beginPath();c.moveTo(640+(x-640)*.2,GROUND);c.lineTo(x,H);c.stroke();}
    c.fillStyle='#1a1420';c.fillRect(0,GROUND-10,W,10);
    const vg=c.createRadialGradient(640,360,380,640,360,820);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.55)');c.fillStyle=vg;c.fillRect(0,0,W,H);
  },
  d(c,t){
    const r=mapRng(9);
    for(const s of MAP_STARS[0]){c.globalAlpha=.35+.45*Math.sin(t*2+s.p);c.fillStyle='#fff';c.fillRect(s.x,s.y,2,2);}
    c.globalAlpha=1;
    mapGlow(c,1000,130,190,'#ffe8b8',.45+.06*Math.sin(t*1.3));
    c.fillStyle='#fff3d6';c.beginPath();c.arc(1000,130,62,0,6.2832);c.fill();
    for(let i=0;i<3;i++){const x=((t*(12+i*7)+i*420)%(W+400))-200;c.globalAlpha=.16;c.fillStyle='#d8c4f0';c.beginPath();c.ellipse(x,120+i*60,220,26,0,0,6.2832);c.fill();}
    c.globalAlpha=1;
    for(let i=0;i<8;i++){const wx=640+(i%4-1.5)*40-(i>3?120:0),wy=(i<4?300:300)-(i%2)*70-(i>3?50:0);const f=.6+.4*Math.sin(t*5+i*1.7);mapGlow(c,wx,wy-10,28,'#ffb050',.35*f);}
  }
},
{ /* 1 Lanterns */
  s(c){
    const g=c.createLinearGradient(0,0,0,GROUND);g.addColorStop(0,'#02090e');g.addColorStop(.7,'#0c3a34');g.addColorStop(1,'#1f5a4a');
    c.fillStyle=g;c.fillRect(0,0,W,H);
    const r=mapRng(21);
    for(let k=0;k<4;k++){
      const col=['#0a2a26','#0c3530','#0e4038','#124a40'][k];
      c.fillStyle=col;
      for(let i=0;i<14;i++){const x=r()*W,y=GROUND-60-k*40-r()*40,rad=50+r()*70;c.beginPath();c.ellipse(x,y,rad,rad*.7,0,0,6.2832);c.fill();}
    }
    c.fillStyle='#071512';
    c.fillRect(0,0,120,GROUND);c.fillRect(W-150,0,150,GROUND);
    c.beginPath();c.moveTo(0,300);c.quadraticCurveTo(160,260,260,380);c.lineTo(260,400);c.quadraticCurveTo(120,330,0,350);c.fill();
    c.beginPath();c.moveTo(W,260);c.quadraticCurveTo(W-200,230,W-300,360);c.lineTo(W-300,380);c.quadraticCurveTo(W-160,300,W,320);c.fill();
    c.fillStyle='#0b2a26';c.beginPath();c.ellipse(640,GROUND+30,380,40,0,0,6.2832);c.fill();
    const pond=c.createLinearGradient(0,GROUND,0,H);pond.addColorStop(0,'#1a5a5a');pond.addColorStop(1,'#0c2e34');
    c.fillStyle=pond;c.fillRect(0,GROUND,W,H-GROUND);
    c.strokeStyle='rgba(120,255,220,.12)';c.lineWidth=2;
    for(let y=GROUND+20;y<H;y+=24){c.beginPath();c.moveTo(0,y);c.lineTo(W,y);c.stroke();}
    c.fillStyle='#0a1e18';c.fillRect(0,GROUND-6,W,8);
  },
  d(c,t){
    for(const s of MAP_STARS[1]){c.globalAlpha=.25+.3*Math.sin(t*1.5+s.p);c.fillStyle='#bff';c.fillRect(s.x,s.y,2,2);}
    c.globalAlpha=1;
    const r=mapRng(33);
    for(let i=0;i<9;i++){
      const x=60+i*140+(i%2)*30,y=170+(i%3)*50+Math.sin(t*.6+i)*4;
      const sway=Math.sin(t*1.2+i*.9)*10;
      c.strokeStyle='rgba(60,100,80,.6)';c.lineWidth=2;c.beginPath();c.moveTo(x,0);c.lineTo(x+sway*.4,y);c.stroke();
      mapGlow(c,x+sway,y+40,90,'#ffb040',.35+.08*Math.sin(t*3+i));
      c.fillStyle='#ffb040';c.beginPath();c.ellipse(x+sway,y+40,14,18,0,0,6.2832);c.fill();
      c.fillStyle='#fff0c0';c.beginPath();c.ellipse(x+sway,y+40,6,9,0,0,6.2832);c.fill();
    }
    for(let i=0;i<26;i++){
      const x=(r()*W+t*(8+i%5*3))%W,y=GROUND-250+r()*240+Math.sin(t*2+i)*20;
      const a=.5+.5*Math.sin(t*4+i*2.1);
      mapGlow(c,x,y,10,'#c8ff80',.5*a);
    }
    c.globalAlpha=.06;c.fillStyle='#bff8e0';
    for(let i=0;i<3;i++){const sx=((t*6+i*400)%(W+300))-150;c.beginPath();c.moveTo(sx,0);c.lineTo(sx+120,0);c.lineTo(sx+260,GROUND);c.lineTo(sx+140,GROUND);c.fill();}
    c.globalAlpha=1;
    c.fillStyle='rgba(180,255,230,.08)';c.fillRect(0,470+Math.sin(t*.6)*8,W,60);
  }
},
{ /* 2 Harbor */
  s(c){
    const g=c.createLinearGradient(0,0,0,400);g.addColorStop(0,'#2a4a7a');g.addColorStop(.55,'#f08a4b');g.addColorStop(1,'#ffd49a');
    c.fillStyle=g;c.fillRect(0,0,W,400);
    const sea=c.createLinearGradient(0,380,0,GROUND);sea.addColorStop(0,'#4a7a9a');sea.addColorStop(1,'#1a3a5a');
    c.fillStyle=sea;c.fillRect(0,380,W,H-380);
    mapRidge(c,360,28,4,'#3a3a5a');
    mapRidge(c,372,14,8,'#2a2a48');
    c.fillStyle='#1c1624';
    for(const [x,y,w] of [[90,520,180],[1020,500,200]]){
      c.beginPath();c.moveTo(x,y);c.lineTo(x+w,y);c.lineTo(x+w-20,y+30);c.lineTo(x+20,y+30);c.fill();
      c.fillRect(x+w/2-2,y-120,4,120);c.fillRect(x+w/2-40,y-90,80,4);
    }
    c.fillStyle='#5a3a24';
    c.fillRect(0,GROUND-30,W,60);
    for(let x=0;x<W;x+=44){c.fillStyle='#4a2e1a';c.fillRect(x,GROUND-30,4,60);}
    c.fillStyle='#3a2414';c.fillRect(0,GROUND+30,W,H-GROUND-30);
    c.fillStyle='#1a1008';for(let x=40;x<W;x+=160){c.fillRect(x,GROUND+30,14,40);}
    c.fillStyle='rgba(0,0,0,.12)';c.fillRect(0,0,W,H);
  },
  d(c,t){
    mapGlow(c,800,300,240,'#ffe0a0',.5+.05*Math.sin(t));
    c.fillStyle='#ffe8b0';c.beginPath();c.arc(800,300,46,0,6.2832);c.fill();
    c.strokeStyle='rgba(255,240,200,.25)';c.lineWidth=2;
    for(let y=392;y<GROUND;y+=7){const w=40+(y-380)*2.5;const x=800+Math.sin(t*1.5+y*.3)*(w*.4);c.globalAlpha=.25+.2*Math.sin(t*2+y);c.beginPath();c.moveTo(x-w/2,y);c.lineTo(x+w/2,y);c.stroke();}
    c.globalAlpha=1;
    c.fillStyle='rgba(0,0,0,.4)';
    for(let i=0;i<4;i++){const x=((t*(20+i*6)+i*340)%(W+200))-100;const y=180+i*18;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+8,y-8,x+16,y);c.quadraticCurveTo(x+24,y-8,x+32,y);c.strokeStyle='rgba(20,20,30,.6)';c.lineWidth=2;c.stroke();}
    const bob=Math.sin(t*1.4)*3;
    c.fillStyle='#2a1a10';c.beginPath();c.moveTo(300,520+bob);c.lineTo(440,520+bob);c.lineTo(420,548+bob);c.lineTo(320,548+bob);c.fill();
    c.fillStyle='#e8d8b8';c.fillRect(304,504+bob,132,14);
  }
},
{ /* 3 Bamboo */
  s(c){
    const g=c.createLinearGradient(0,0,0,GROUND);g.addColorStop(0,'#04120c');g.addColorStop(1,'#1c4030');
    c.fillStyle=g;c.fillRect(0,0,W,H);
    const r=mapRng(55);
    for(let i=0;i<34;i++){const x=r()*W,h=260+r()*240,w=6+r()*8;c.fillStyle='rgba(20,50,30,.8)';c.fillRect(x,GROUND-h,w,h);c.fillStyle='rgba(40,80,50,.6)';for(let n=0;n<h;n+=44)c.fillRect(x-1,GROUND-n,w+2,3);}
    c.fillStyle='#0c2014';c.fillRect(0,GROUND-40,W,40);
    c.fillStyle='#16301e';c.beginPath();c.moveTo(0,GROUND);c.lineTo(W,GROUND);c.lineTo(W,H);c.lineTo(0,H);c.fill();
    c.fillStyle='#4a5a50';
    for(let i=0;i<7;i++){const x=260+i*120,y=GROUND+60+(i%3)*18;c.beginPath();c.ellipse(x,y,36,12,0,0,6.2832);c.fill();}
    c.fillStyle='#2e3e32';c.fillRect(0,GROUND+2,W,4);
  },
  d(c,t){
    mapGlow(c,520,140,260,'#c8ffd8',.25);
    c.fillStyle='#e8fff0';c.beginPath();c.arc(520,140,44,0,6.2832);c.fill();
    for(const s of MAP_STARS[3]){c.globalAlpha=.3+.4*Math.sin(t*2.2+s.p);c.fillStyle='#e8fff0';c.fillRect(s.x,s.y,2,2);}
    c.globalAlpha=1;
    const r=mapRng(77);
    for(let i=0;i<6;i++){
      const x=-40+i*240+(i%2)*60,sway=Math.sin(t*.9+i)*18;
      c.fillStyle='rgba(18,44,28,.95)';
      c.beginPath();c.moveTo(x,H);c.quadraticCurveTo(x+sway*.6,H*.5,x+sway,-10);c.lineTo(x+sway+14,-10);c.quadraticCurveTo(x+sway*.6+14,H*.5,x+18,H);c.fill();
      for(let n=0;n<3;n++){const ly=160+n*160+i*20;c.fillStyle='rgba(40,96,56,.9)';c.beginPath();c.ellipse(x+sway+(n%2?-30:30),ly,38,8,(n%2?-.4:.4)+sway*.01,0,6.2832);c.fill();}
    }
    for(let i=0;i<22;i++){
      const x=(r()*W+t*(30+i%4*10))%W,y=((r()*H+t*(40+i%3*12))%(GROUND+60));
      c.fillStyle='rgba(160,230,150,.7)';c.beginPath();c.ellipse(x,y,6,2.5,t+i,0,6.2832);c.fill();
    }
  }
},
{ /* 4 Blossom Shrine */
  s(c){
    const g=c.createLinearGradient(0,0,0,GROUND);g.addColorStop(0,'#241038');g.addColorStop(.55,'#7a3a6a');g.addColorStop(1,'#f0a0b0');
    c.fillStyle=g;c.fillRect(0,0,W,H);
    mapRidge(c,430,22,6,'#4a2448');
    mapRidge(c,455,14,9,'#2e1638');
    c.fillStyle='#1e0e24';
    c.fillRect(780,260,320,240);
    c.beginPath();c.moveTo(740,270);c.lineTo(940,190);c.lineTo(1140,270);c.lineTo(1120,280);c.lineTo(940,210);c.lineTo(760,280);c.fill();
    c.fillRect(800,160,280,40);c.beginPath();c.moveTo(780,170);c.lineTo(940,110);c.lineTo(1100,170);c.fill();
    c.fillStyle='#3a1020';c.fillRect(540,210,16,300);c.fillRect(720,210,16,300);c.fillRect(490,230,280,14);c.fillRect(520,300,220,10);
    c.fillStyle='#2a0a18';c.beginPath();c.moveTo(470,210);c.quadraticCurveTo(628,160,786,210);c.lineTo(786,226);c.quadraticCurveTo(628,176,470,226);c.fill();
    c.fillStyle='#120a14';c.fillRect(0,GROUND-20,W,H-GROUND+20);
    for(let x=60;x<W;x+=150){c.fillStyle='#2a1a22';c.fillRect(x,GROUND-20,120,6);}
    c.strokeStyle='rgba(255,180,200,.25)';c.lineWidth=2;c.beginPath();c.moveTo(0,GROUND);c.lineTo(W,GROUND);c.stroke();
  },
  d(c,t){
    const r=mapRng(99);
    for(const [x0,y0,rad] of [[120,120,150],[1160,110,170],[640,40,130]]){
      const sway=Math.sin(t*.5+x0)*8;
      c.fillStyle='rgba(255,170,200,.25)';
      for(let i=0;i<22;i++){const a=i*2.7+x0,d=rad*(.3+.7*((i*37)%10)/10);c.beginPath();c.arc(x0+sway+Math.cos(a)*d,y0+Math.sin(a)*d*.6,14+(i%3)*5,0,6.2832);c.fill();}
    }
    for(const s of MAP_STARS[4]){c.globalAlpha=.2+.3*Math.sin(t*1.8+s.p);c.fillStyle='#ffe6f0';c.fillRect(s.x,s.y,2,2);}
    c.globalAlpha=1;
    for(const [x,y] of [[800,250],[1040,250],[220,300]]){const f=.6+.4*Math.sin(t*4+x);mapGlow(c,x,y,80,'#ffb060',.4*f);c.fillStyle='#ffc070';c.beginPath();c.ellipse(x,y,12,16,0,0,6.2832);c.fill();}
    for(let i=0;i<20;i++){
      const x=(r()*W+t*(18+i%4*6))%W,y=((r()*H+t*(30+i%3*8)))%(GROUND+40);
      c.fillStyle='rgba(255,200,215,.85)';c.beginPath();c.ellipse(x,y,5,3,t*2+i,0,6.2832);c.fill();
    }
  }
}
];
function mapFor(cfg){
  const pick=cfg.map!==undefined?cfg.map:save.map;
  if(pick>=0&&pick<MAP_COUNT)return pick;
  if(cfg.mode==='story'&&STORY[cfg.idx])return (STORY[cfg.idx].w-1)%MAP_COUNT;
  return (cfg.arena||0)%MAP_COUNT;
}
function cycleMap(){save.map=save.map+1>=MAP_COUNT?-1:save.map+1;persist();}
function mapLabel(){return 'MAP: '+(save.map<0?'AUTO':MAP_NAMES[save.map]);}
