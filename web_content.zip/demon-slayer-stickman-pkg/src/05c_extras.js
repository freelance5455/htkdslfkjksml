/* ---------- AUDIO (procedural SFX + music, optional custom track) ---------- */
let AC=null,master=null,sfxBus=null,musBus=null,noiseBuf=null,musNext=0,musI=0,customAudio=null;
function audioInit(){
  if(AC){if(AC.state==='suspended')AC.resume();return;}
  try{
    AC=new (window.AudioContext||window.webkitAudioContext)();
    master=AC.createGain();master.gain.value=.9;master.connect(AC.destination);
    sfxBus=AC.createGain();sfxBus.gain.value=.7;sfxBus.connect(master);
    musBus=AC.createGain();musBus.gain.value=.3;musBus.connect(master);
    applyVolumes();
    const len=Math.floor(AC.sampleRate*.6);
    noiseBuf=AC.createBuffer(1,len,AC.sampleRate);
    const d=noiseBuf.getChannelData(0);
    for(let i=0;i<len;i++)d[i]=Math.random()*2-1;
  }catch(e){AC=null;}
}
function tone(f0,f1,dur,type,vol,dest,delay){
  const t=AC.currentTime+(delay||0);
  const o=AC.createOscillator(),g=AC.createGain();
  o.type=type||'sine';
  o.frequency.setValueAtTime(f0,t);
  o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);
  g.gain.setValueAtTime(.0001,t);
  g.gain.exponentialRampToValueAtTime(vol,t+.01);
  g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  o.connect(g);g.connect(dest||sfxBus);
  o.start(t);o.stop(t+dur+.05);
}
function noise(dur,vol,hp,dest,delay){
  const t=AC.currentTime+(delay||0);
  const s=AC.createBufferSource(),g=AC.createGain(),fl=AC.createBiquadFilter();
  s.buffer=noiseBuf;fl.type='highpass';fl.frequency.value=hp||800;
  g.gain.setValueAtTime(vol,t);
  g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  s.connect(fl);fl.connect(g);g.connect(dest||sfxBus);
  s.start(t,Math.random()*.3);s.stop(t+dur+.02);
}
const SFX={
  swing(){noise(.18,.35,1400);tone(900,300,.16,'triangle',.12);},
  heavy(){noise(.28,.5,500);tone(260,70,.3,'sawtooth',.18);},
  wave(){tone(400,1200,.3,'sine',.18);noise(.25,.25,1200);},
  hit(){noise(.12,.6,300);tone(180,60,.15,'square',.2);},
  big(){noise(.4,.8,200);tone(120,40,.5,'sawtooth',.3);tone(70,30,.6,'sine',.35,null,.02);},
  block(){tone(1800,900,.12,'triangle',.25);noise(.06,.3,3000);},
  dash(){noise(.2,.25,2000);tone(500,1200,.16,'sine',.08);},
  ult(){tone(90,500,.9,'sawtooth',.2);noise(.9,.5,800);tone(660,1320,.6,'sine',.12,null,.25);},
  ko(){tone(220,40,1.2,'sawtooth',.25);noise(1,.6,100);}
};
function vol(k){const v=save[k];return v===undefined?1:clamp(v,0,1);}
function applyVolumes(){
  if(!AC)return;
  sfxBus.gain.value=.7*vol('sfxVol');
  musBus.gain.value=.3*vol('musVol');
  if(customAudio)customAudio.volume=.5*vol('musVol');
}
function sfx(n){
  if(!AC||save.sfx===0||vol('sfxVol')<=0)return;
  const f=SFX[n];
  if(f){try{f();}catch(e){}}
}
const JSCALE=[0,2,3,7,8];
const JPROG=[[0,3,7],[-2,2,5],[-5,0,3],[-3,2,5]];
const MUS_ROOT=110;
let musBar=0,musBarNext=0;
function jfreq(semi){return MUS_ROOT*Math.pow(2,semi/12);}
function choir(freqs,dur,dest,delay){
  const t=AC.currentTime+(delay||0);
  const f=AC.createBiquadFilter();f.type='lowpass';
  f.frequency.setValueAtTime(600,t);f.frequency.linearRampToValueAtTime(1100,t+dur*.5);f.frequency.linearRampToValueAtTime(600,t+dur);
  const g=AC.createGain();
  g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.09,t+dur*.35);g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  f.connect(g);g.connect(dest);
  for(const fq of freqs)for(const det of [-7,7]){
    const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=fq;o.detune.value=det;
    o.connect(f);o.start(t);o.stop(t+dur+.1);
  }
}
function flute(freq,dur,dest,delay){
  const t=AC.currentTime+(delay||0);
  const o=AC.createOscillator(),g=AC.createGain(),l=AC.createOscillator(),lg=AC.createGain();
  o.type='sine';o.frequency.value=freq;
  l.frequency.value=5.2;lg.gain.value=freq*.012;
  l.connect(lg);lg.connect(o.frequency);
  g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.15,t+.14);
  g.gain.setValueAtTime(.15,t+dur*.7);g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  o.connect(g);g.connect(dest);
  o.start(t);l.start(t);o.stop(t+dur+.05);l.stop(t+dur+.05);
}
function musicTick(){
  if(!AC||save.music===0||vol('musVol')<=0||customAudio)return;
  if(AC.state!=='running')return;
  const beat=60/72;
  if(!musBarNext)musBarNext=AC.currentTime+.2;
  while(musBarNext<AC.currentTime+.6){
    const d=musBarNext-AC.currentTime,ch=JPROG[musBar%JPROG.length];
    choir(ch.map(s=>jfreq(s)),beat*4,musBus,d);
    tone(72,38,.6,'sine',.28,musBus,d);
    tone(72,38,.45,'sine',.2,musBus,d+beat*2);
    noise(.08,.1,250,musBus,d+beat*2);
    let deg=(musBar*3)%JSCALE.length;
    for(let b=0;b<4;b++){
      if(Math.random()<.7){
        deg=Math.max(0,Math.min(9,deg+[-1,0,1,1,2][Math.floor(Math.random()*5)]));
        flute(jfreq(JSCALE[deg%5]+12*Math.floor(deg/5)+12),beat*(Math.random()<.5?1.5:.9),musBus,d+b*beat);
      }
    }
    musBar++;musBarNext+=beat*4;
  }
}
function setMusic(on){
  save.music=on?1:0;persist();
  if(customAudio){if(on)customAudio.play().catch(()=>{});else customAudio.pause();}
}
function pickCustomMusic(){
  const inp=document.createElement('input');
  inp.type='file';inp.accept='audio/*';
  inp.onchange=()=>{
    const f=inp.files&&inp.files[0];
    if(!f)return;
    try{
      if(customAudio)customAudio.pause();
      customAudio=new Audio(URL.createObjectURL(f));
      customAudio.loop=true;customAudio.volume=.5*vol('musVol');
      if(save.music!==0)customAudio.play().catch(()=>{});
      showToast('Custom music loaded: '+f.name.slice(0,30));
    }catch(e){showToast('Could not load that file.');}
  };
  inp.click();
}

/* ---------- CUTSCENES ---------- */
const CUTS=[
  [['narr','Rokuro collapses, his shadow scattering into the dark.'],['you','Rest now. The night is not over yet.']],
  [['narr','The drums fall silent as the mansion trembles.'],['you','The Lower Moons are closer than I thought.']],
  [['narr','Threads snap one by one as the spider demon falls.'],['you','Their web ends here.']],
  [['narr','The dolls drop their strings, lifeless.'],['you','Something stronger waits beyond this.']],
  [['narr','The last sickle clatters against the stone.'],['you','Five more Moons. I will not stop.']],
  [['narr','Enmu\'s dream shatters. The world wakes with a gasp.'],['you','Nezuko, I will bring you back to the sun.']],
  [['narr','The Entertainment District goes quiet at last.'],['you','One Upper Moon down. Then the rest.']],
  [['narr','The poison vases shatter across the floor.'],['foe','Clever... but not clever enough.']],
  [['narr','Sorrow, rage and joy fade into a single cry.'],['you','Feelings are strong, but resolve is stronger.']],
  [['narr','Frost melts from the blade as Doma falls.'],['you','The cold has lifted from this town.']],
  [['narr','Akaza\'s last strike lands on nothing but air.'],['you','His strength was real. So was his pain.']],
  [['narr','The Moon sinks behind the clouds.'],['you','The first demon, and the strongest. It ends here.']],
  [['narr','Muzan crumbles to ash, his endless hunger silenced.'],['narr','Dawn breaks over the mountains. The war is over.']],
  [['narr','Lanterns sway above the crowded street.'],['you','Stay sharp. The lanterns hide the demon well.']],
  [['narr','The bamboo falls silent after the biwa stops.'],['you','A song is still a weapon. Keep moving.']],
  [['narr','The mountain shakes as the demon collapses.'],['you','We reached the top. On to the next moon.']],
  [['narr','The lake cracks and the frozen body sinks.'],['you','The cold cannot stop what I protect.']],
  [['narr','The volcano rumbles, quieter now.'],['foe','Hm... still not enough.']],
  [['narr','The castle walls crumble under the last emotion.'],['you','Every feeling is real. But I choose mine.']],
  [['narr','The shrine bells ring as the moon returns to the sky.'],['you','Brother... I finally see you.']],
  [['narr','Poisoned waves recede from the cliff.'],['you','The sea remembers every one you hurt.']],
  [['narr','Snow covers the valley where the blood sickles fell.'],['you','No more blood in this valley.']],
  [['narr','The Demon King falls for good. The dream fades.'],['narr','The worlds are quiet at last. The journey goes on.']],
  [['narr','The last puppet falls silent beneath the shrine.'],['you','Their strings are cut. Rest now.']],
  [['narr','The fan folds shut and the dancer breaks apart.'],['you','A dance this cruel should not be repeated.']],
  [['narr','The shadows fade as the last cleave lands.'],['you','The shrine is free. On to the next storm.']],
  [['narr','The wind dies and the storm falls silent.'],['you','Akaza, your rage ends here.']],
  [['narr','The ice field cracks and the lotus sinks.'],['you','The cold has finally lifted from this land.']],
  [['narr','Ten thousand blades clatter to the ground.'],['you','Your bones will never become swords now.']],
  [['narr','The six eyes close and the moon dims.'],['you','One night was never enough for you.']],
  [['narr','The silk tears apart and the mountain breathes again.'],['you','Nothing binds me now.']],
  [['narr','The Demon King crumbles to dust beneath the moon.'],['narr','Pixel War ends here, but the wind still whispers.']]
];
let cut=null;
let cutSpeaker=null;
const VOICE={};
function voiceFor(id){
  if(VOICE[id])return VOICE[id];
  let h=0;for(const ch of String(id))h=(h*31+ch.charCodeAt(0))|0;
  const pitch=id==='narr'?.9:[.7,.8,.9,1,1.1,1.2,1.3][Math.abs(h)%7];
  VOICE[id]={pitch:pitch,rate:id==='narr'?.9:1};
  return VOICE[id];
}
function blipSpeak(id,text){
  if(!AC||vol('sfxVol')<=0)return;
  const v=voiceFor(id),base=(id==='narr'?150:190)*v.pitch;
  let t=.05;
  for(const ch of text){
    if(t>7)break;
    if(/[aeiouyAEIOUY]/.test(ch)){tone(base*rnd(.92,1.08),base*.78,.1,'triangle',.11*vol('sfxVol'),sfxBus,t);t+=.09;}
    else if(/[bcdfghjklmnpqrstvwxzBCDFGHJKLMNPQRSTVWXZ]/.test(ch))t+=.035;
    else if(/[.!?,;:]/.test(ch))t+=.16;
    else if(ch===' ')t+=.05;
  }
}
function speakLine(id,text){
  const v=voiceFor(id);
  try{
    if(!('speechSynthesis' in window)){blipSpeak(id,text);return;}
    const synth=speechSynthesis;
    const voices=synth.getVoices();
    if(!voices.length){blipSpeak(id,text);return;}
    synth.cancel();
    let started=false;
    setTimeout(()=>{
      const u=new SpeechSynthesisUtterance(text);
      const en=voices.find(x=>/^en/i.test(x.lang))||voices[0];
      u.voice=en;u.lang=en.lang;
      u.pitch=v.pitch;u.rate=v.rate;u.volume=clamp(vol('sfxVol'),0,1);
      u.onstart=()=>{started=true;};
      u.onerror=()=>{if(!started){started=true;blipSpeak(id,text);}};
      synth.speak(u);
      setTimeout(()=>{if(!started){started=true;synth.cancel();blipSpeak(id,text);}},900);
    },60);
  }catch(e){blipSpeak(id,text);}
}
function startCut(arg){
  const idx=arg&&arg.idx!==undefined?arg.idx:0;
  cut={idx:idx,i:0,ch:0,t:0,foe:STORY[idx].e,spk:-1};
}
function cutLine(){
  const L=CUTS[cut.idx]||[];
  return L[Math.min(cut.i,L.length-1)];
}
function updateCut(dt){
  if(!cut)return;
  cut.t+=dt;cut.ch+=dt*40;
}
function advanceCut(){
  if(!cut)return;
  const L=CUTS[cut.idx]||[],line=cutLine();
  if(Math.floor(cut.ch)<line[1].length){cut.ch=line[1].length;return;}
  cut.i++;cut.ch=0;
  if(cut.i>=L.length)endCut();
}
function endCut(){
  if(!cut)return;
  cut=null;cutSpeaker=null;
  try{if('speechSynthesis' in window)speechSynthesis.cancel();}catch(e){}
  goto('story');
}
function drawCut(){
  if(!cut)return;
  const line=cutLine();
  const spkId=line[0]==='you'?sel:line[0]==='foe'?cut.foe:null;
  if(cut.spk!==cut.i){cut.spk=cut.i;if(spkId)speakLine(spkId,line[1]);else speakLine('narr',line[1]);}
  cutSpeaker=(cut.ch<line[1].length)?spkId:null;
  if(cut.t<2.8)drawSlice(cut.foe);
  ctx.save();ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(0,0,W,H);ctx.restore();
  btns.push({x:0,y:0,w:W,h:H,fn:advanceCut});
  if(line[0]==='you')drawPortrait(sel,380,520,2.6,1);
  if(line[0]==='foe')drawPortrait(cut.foe,900,520,2.6,-1);
  ctx.save();
  ctx.fillStyle='rgba(10,6,16,.85)';rr(110,540,1060,140,14);ctx.fill();
  ctx.strokeStyle='#ffb36b';ctx.lineWidth=2;ctx.stroke();
  ctx.textAlign='left';ctx.textBaseline='middle';
  const who=line[0]==='you'?CH[sel].n:line[0]==='foe'?CH[cut.foe].n:'';
  if(who){ctx.fillStyle='#ffd27a';ctx.font='bold 20px Georgia';ctx.fillText(who,140,572);}
  ctx.fillStyle='#ffe2b8';ctx.font=(line[0]==='narr'?'italic ':'')+'24px Georgia';
  ctx.fillText(line[1].slice(0,Math.floor(cut.ch)),140,midLine(who));
  ctx.font='14px Georgia';ctx.fillStyle='#c8a8d8';ctx.textAlign='right';
  ctx.fillText('Click or press Enter to continue',1150,650);
  ctx.restore();
  Btn(1080,20,160,40,'SKIP',endCut,{f:'bold 15px Georgia'});
}
function midLine(who){return who?616:610;}
function drawSlice(foe){
  const t=cut.t,col='#ff3a3a';
  const P0={x:900,y:430};
  let dx=1,dy=.6;const L0=Math.hypot(dx,dy);dx/=L0;dy/=L0;
  const nx=-dy,ny=dx;
  const clipSide=sg=>{
    const A={x:P0.x-dx*1200,y:P0.y-dy*1200},B={x:P0.x+dx*1200,y:P0.y+dy*1200};
    const pts=[A,B,{x:B.x+nx*1200*sg,y:B.y+ny*1200*sg},{x:A.x+nx*1200*sg,y:A.y+ny*1200*sg}];
    ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);for(const p of pts)ctx.lineTo(p.x,p.y);ctx.closePath();ctx.clip();
  };
  const k=clamp(t/.4,0,1),sep=clamp((t-.4)/1.1,0,1),fade=clamp(1-(t-1.7)/1.0,0,1);
  if(!cut.sliced&&t>=.36){cut.sliced=true;burst(P0.x,P0.y,col,26,300,'spark');shake=Math.max(shake,8);}
  ctx.save();ctx.globalAlpha=fade;
  ctx.save();clipSide(1);drawPortrait(foe,900,610,2.1,-1);ctx.restore();
  ctx.save();clipSide(-1);
  ctx.translate(P0.x,P0.y);ctx.rotate(sep*.4);ctx.translate(-P0.x,-P0.y);
  ctx.translate(-nx*sep*210,-ny*sep*210);
  drawPortrait(foe,900,610,2.1,-1);
  ctx.restore();
  ctx.globalAlpha=fade;
  if(k>0&&t<1){
    const g=k*(1-clamp((t-.3)/.6,0,1));
    ctx.strokeStyle='rgba(255,255,255,'+(0.4+0.6*g)+')';ctx.lineWidth=2+10*g;
    ctx.beginPath();ctx.moveTo(P0.x-dx*900*k,P0.y-dy*900*k);ctx.lineTo(P0.x+dx*900*k,P0.y+dy*900*k);ctx.stroke();
  }
  if(sep>0){
    ctx.strokeStyle=hexA(col,.9*(1-sep*.6));ctx.lineWidth=3;
    ctx.beginPath();ctx.moveTo(P0.x-dx*900,P0.y-dy*900);ctx.lineTo(P0.x+dx*900,P0.y+dy*900);ctx.stroke();
  }
  ctx.restore();
}
addEventListener('keydown',e=>{
  if(scene==='login')return;
  if(scene==='cutscene'&&(e.key==='Enter'||e.key===' ')){e.preventDefault();advanceCut();}
});
