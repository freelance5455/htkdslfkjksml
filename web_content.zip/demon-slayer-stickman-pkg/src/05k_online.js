/* ---------- ONLINE (server connection, matchmaking, parties) ---------- */
const SERVER_URL='ws://localhost:8080';
const net={ws:null,token:null,profile:null,status:'',queued:null,party:null,match:null,remote:null,outActs:[],lastSend:0,authWait:null,reward:null};
function netConnect(){
  return new Promise((resolve,reject)=>{
    if(net.ws&&net.ws.readyState===1){resolve(net.ws);return;}
    let ws;
    try{ws=new WebSocket(SERVER_URL);}catch(e){reject(e);return;}
    const to=setTimeout(()=>{try{ws.close();}catch(e){}reject(new Error('timeout'));},5000);
    ws.onopen=()=>{clearTimeout(to);net.ws=ws;resolve(ws);};
    ws.onerror=()=>{clearTimeout(to);reject(new Error('offline'));};
    ws.onclose=()=>{
      if(net.ws===ws)net.ws=null;
      net.queued=null;net.party=null;
      if(net.match){net.match=null;showToast('Connection to the server was lost.');}
    };
    ws.onmessage=ev=>{let m;try{m=JSON.parse(ev.data);}catch(e){return;}netMsg(m);};
  });
}
function saveSession(o){try{localStorage.setItem('ds_session',JSON.stringify(o));}catch(e){}}
function loadSession(){try{return JSON.parse(localStorage.getItem('ds_session')||'null');}catch(e){return null;}}
function hasSession(){const s=loadSession();return !!(s&&s.user);}
function bootAccount(){const s=loadSession();if(s&&s.user){account.user=s.user;setSaveOwner(s.user);}}
function startScene(){if(hasSession()){bootAccount();return 'menu';}return 'login';}
function bootAccount(){const s=loadSession();if(s&&s.user){account.user=s.user;setSaveOwner(s.user);}}
function startScene(){if(hasSession()){bootAccount();return 'menu';}return 'login';}
function netSend(obj){if(net.ws&&net.ws.readyState===1)net.ws.send(JSON.stringify(obj));}
function netAuth(t,user,pass){
  return new Promise(resolve=>{
    net.authWait=resolve;
    netSend({t:t,user:user,pass:pass});
    setTimeout(()=>{if(net.authWait===resolve){net.authWait=null;resolve({ok:false,msg:'Server did not answer'});}},6000);
  });
}
function netMsg(m){
  switch(m.t){
    case 'auth':
      net.profile=m.profile;net.token=m.token;
      if(net.profile){account.user=net.profile.name;setSaveOwner(account.user);saveSession({user:net.profile.name,token:m.token,online:true});}
      if(net.authWait){const r=net.authWait;net.authWait=null;r({ok:true,profile:m.profile});}
      break;
    case 'err':
      if(net.authWait){const r=net.authWait;net.authWait=null;r({ok:false,msg:m.msg});}
      else showToast(m.msg);
      net.status=m.msg;
      break;
    case 'queued':net.queued=m.mode;net.status='Searching for a '+(m.mode==='ranked'?'ranked':'quick')+' match...';break;
    case 'cancelled':net.queued=null;net.party=null;net.status='';break;
    case 'party':net.party=m.code;net.status='Party code '+m.code+': waiting for your opponent';break;
    case 'matched':
      net.queued=null;net.party=null;
      net.match={id:m.matchId,side:m.side,mode:m.mode,opp:m.opp,started:false};
      net.lock=freshLock();
      net.status='Match found vs '+m.opp.name+' (Lv '+m.opp.level+')';
      netSend({t:'char',char:sel});
      break;
    case 'start':
      if(!net.match)break;
      net.match.started=true;
      goto('battle',{mode:'online',p:m.you,e:m.opp,diff:'normal',arena:0,rounds:1,online:true,side:m.side});
      break;
    case 'tick':
      if(net.lock&&Number.isInteger(m.n))net.lock.remote[m.n]=m.c||NEUTRAL_CMD;
      break;
    case 'opp_left':
      showToast('Your opponent disconnected.');
      if(battle&&battle.mode==='online')goto('menu');
      break;
    case 'reward':
      net.match=null;
      net.profile=m.profile;net.reward=m;
      showToast((m.won?'VICTORY':'DEFEAT')+'  +'+m.xp.toLocaleString()+' XP');
      if(m.profile.level>m.levelBefore)setTimeout(()=>showToast('LEVEL UP! Level '+m.profile.level),2700);
      break;
  }
}
const LOCK={STEP:1/60,DELAY:6};
const NEUTRAL_CMD={mx:0,block:false,jump:false,light:false,heavy:false,s1:false,s2:false,ult:false,dash:false};
function freshLock(){return {tick:0,acc:0,local:{},remote:{},cmdLocal:null,cmdRemote:null,waitT:0};}
net.lock=freshLock();
function lockReset(){
  const L=net.lock;L.tick=0;L.acc=0;L.waitT=0;L.cmdLocal=null;L.cmdRemote=null;
  for(let i=0;i<LOCK.DELAY;i++){L.local[i]=NEUTRAL_CMD;L.remote[i]=NEUTRAL_CMD;}
}
function lockLocalCmd(){return net.lock.cmdLocal||NEUTRAL_CMD;}
function lockRemoteCmd(){return net.lock.cmdRemote||NEUTRAL_CMD;}
function lockUpdate(dt){
  const L=net.lock;
  if(!battle||battle.mode!=='online')return;
  L.acc=Math.min(L.acc+dt,.25);
  let steps=0;
  while(L.acc>=LOCK.STEP&&steps<4&&scene==='battle'){
    if(!lockStep()){
      L.waitT+=dt;
      if(L.waitT>8){showToast('Opponent is not responding.');net.match=null;goto('menu');}
      break;
    }
    L.waitT=0;L.acc-=LOCK.STEP;steps++;
  }
}
function lockStep(){
  const L=net.lock,n=L.tick;
  const rem=L.remote[n]||(battle.phase==='end'?NEUTRAL_CMD:null);
  if(!rem)return false;
  L.cmdLocal=L.local[n]||NEUTRAL_CMD;
  L.cmdRemote=rem;
  delete L.local[n];delete L.remote[n];
  updateBattle(LOCK.STEP);
  L.tick=n+1;
  const pc=readPlayerCmd();
  const cmd={mx:pc.mx,block:!!pc.block,jump:!!pc.jump,light:!!pc.light,heavy:!!pc.heavy,s1:!!pc.s1,s2:!!pc.s2,ult:!!pc.ult,dash:!!pc.dash};
  L.local[n+LOCK.DELAY]=cmd;
  netSend({t:'tick',n:n+LOCK.DELAY,c:cmd});
  return true;
}
const joinInput=document.createElement('input');
joinInput.placeholder='6-digit code';joinInput.maxLength=6;joinInput.inputMode='numeric';
joinInput.style.cssText='position:fixed;display:none;z-index:5;box-sizing:border-box;padding:6px 14px;font-family:Georgia,serif;font-weight:bold;background:rgba(16,6,14,.92);color:#ffe2b8;border:2px solid #ff9a3a;border-radius:8px;outline:none;';
joinInput.addEventListener('input',()=>{joinInput.value=joinInput.value.replace(/\D/g,'');});
joinInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();netJoin();}});
document.body.appendChild(joinInput);
function placeJoin(){placeOverlay(joinInput,440,544,240,44);}
function joinShow(on){joinInput.style.display=on?'block':'none';if(on)placeJoin();else joinInput.blur();}
function netJoin(){
  const code=joinInput.value.trim();
  if(!/^\d{6}$/.test(code)){net.status='Enter the 6-digit party code';return;}
  netSend({t:'party_join',code:code});
}
async function netEnsure(){
  if(!(net.ws&&net.ws.readyState===1)){
    try{await netConnect();}catch(e){net.status='Server offline. Check SERVER_URL.';return false;}
  }
  if(!net.profile){
    const s=loadSession();
    if(s&&s.online&&s.token){const r=await netAuth('resume',s.user,s.token);if(!r.ok){net.status=r.msg;return false;}}
  }
  return true;
}
function drawOnline(){
  placeJoin();
  const p=net.profile;
  ctx.save();
  ctx.fillStyle='rgba(16,6,14,.85)';ctx.fillRect(330,110,620,520);
  ctx.fillStyle='#ff9a3a';ctx.fillRect(330,110,620,4);
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillStyle='#ffd27a';ctx.font='bold 32px Georgia';ctx.fillText('ONLINE 1v1',640,150);
  if(p){
    ctx.textAlign='left';ctx.fillStyle='#ffe2b8';ctx.font='bold 20px Georgia';
    ctx.fillText(p.name,362,192);
    ctx.textAlign='right';ctx.fillStyle='#ffd27a';
    ctx.fillText('Level '+p.level+' / 200   '+p.rank+'  ('+p.rp+' RP)',918,192);
    ctx.fillStyle='#2a1a24';ctx.fillRect(362,212,556,16);
    const frac=p.level>=200?1:Math.min(1,p.xp/p.xpNext);
    ctx.fillStyle='#ffb24a';ctx.fillRect(362,212,556*frac,16);
    ctx.textAlign='center';ctx.fillStyle='#ffe2b8';ctx.font='13px Georgia';
    ctx.fillText(p.level>=200?'MAX LEVEL':'XP '+p.xp.toLocaleString()+' / '+p.xpNext.toLocaleString(),640,220);
  }else{
    ctx.textAlign='center';ctx.fillStyle='#ffe2b8';ctx.font='bold 18px Georgia';
    ctx.fillText('Log in to the server to play online',640,200);
  }
  ctx.textAlign='center';ctx.fillStyle='#ff8a7a';ctx.font='bold 17px Georgia';
  ctx.fillText(net.status||'',640,256);
  ctx.restore();
  const lvl=p?p.level:1,ranked=lvl>=20;
  Btn(440,300,400,44,'QUICK MATCH',()=>{netQueue('quick');},{f:'bold 18px Georgia'});
  Btn(440,356,400,44,ranked?'RANKED 1v1':'RANKED 1v1 (LEVEL 20)',()=>{netQueue('ranked');},{f:'bold 18px Georgia'});
  Btn(440,412,400,44,'CREATE PARTY',async()=>{if(await netEnsure())netSend({t:'party_create'});},{f:'bold 18px Georgia'});
  Btn(440,468,400,44,'CANCEL',()=>{netSend({t:'cancel'});net.status='';},{f:'bold 18px Georgia'});
  Btn(690,544,150,44,'JOIN',()=>netJoin(),{f:'bold 18px Georgia'});
  ctx.save();ctx.textAlign='center';ctx.fillStyle='#b8a8b8';ctx.font='14px Georgia';
  ctx.fillText('Quick matches give 500-2000 XP. Ranked gives 3000-5000 XP and rank points.',640,612);
  ctx.restore();
}
async function netQueue(mode){
  if(!(await netEnsure()))return;
  if(!net.profile){net.status='Log in to the server first';return;}
  netSend({t:'queue',mode:mode});
}
