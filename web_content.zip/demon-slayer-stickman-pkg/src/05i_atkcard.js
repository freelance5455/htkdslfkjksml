const ACD_SRC={};
/* ---------- ATTACK CARD ANIMATION (light/heavy) ---------- */
const ACD={},ACD_M={};
for(const k in ACD_SRC){const im=new Image();im.src=ACD_SRC[k];ACD[k]=im;}
const ACD_DUR=2.4;
let acdKey=null,acdStart=0;
function acdBegin(f,key){
  const id=f.id+'_'+key;
  if(!ACD[id])return;
  acdKey=id;acdStart=performance.now();
}
function acdActive(){
  if(!acdKey)return false;
  if((performance.now()-acdStart)/1000>=ACD_DUR){acdKey=null;return false;}
  return true;
}
function acdMasked(id){
  if(ACD_M[id])return ACD_M[id];
  const im=ACD[id];
  if(!im||!im.complete||!im.naturalWidth)return null;
  const c=document.createElement('canvas');c.width=144;c.height=224;
  const g=c.getContext('2d');
  g.drawImage(im,0,0,144,224);
  g.globalCompositeOperation='destination-in';
  const rg=g.createRadialGradient(72,112,0,72,112,84);
  rg.addColorStop(0,'rgba(0,0,0,1)');rg.addColorStop(.5,'rgba(0,0,0,1)');rg.addColorStop(1,'rgba(0,0,0,0)');
  g.fillStyle=rg;g.fillRect(0,0,144,224);
  ACD_M[id]=c;return c;
}
function drawAtkCardOn(f){
  if(!acdActive())return;
  const cv2=acdMasked(acdKey);
  if(!cv2)return;
  const el=(performance.now()-acdStart)/1000;
  const heavy=acdKey.endsWith('_heavy');
  const t=el/ACD_DUR;
  const w=170,h=264;
  const ang=(heavy?10:5)*Math.sin(2*Math.PI*t)*(t<.5?1:-.4)*Math.PI/180;
  const sc=1+(heavy?.08:.03)*Math.sin(Math.PI*t);
  ctx.save();
  ctx.translate(f.x,f.y);
  ctx.scale(f.facing,1);
  ctx.translate(0,-h*.45);
  ctx.rotate(ang);ctx.scale(sc,sc);
  ctx.drawImage(cv2,-w/2,-h/2,w,h);
  ctx.restore();
}
