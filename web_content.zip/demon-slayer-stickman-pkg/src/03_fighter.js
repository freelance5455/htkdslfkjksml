
/* ---------- FIGHTERS ---------- */
let frameDt=1/60;
function makeAI(d){return{d:d,tm:0,mv:0,blockT:0,mist:0};}
function makeF(id,x,facing,ai,diffKey,hpm,absHp){
  const c=CH[id];
  const mhp=absHp?absHp:Math.round(c.hp*(hpm||1));
  return {
    id:id,c:c,x:x,y:GROUND,vy:0,kx:0,facing:facing,hp:mhp,max:mhp,breath:100,ult:0,onG:true,
    t:0,ph:0,atk:null,cd:{s1:0,s2:0,dash:0,ult:0},stun:0,blk:false,gb:0,dsh:0,inv:0,
    combo:0,comboT:0,dealt:0,flash:0,trail:[],dead:false,lastMx:0,infinite:false,dummy:false,
    J:null,ai:ai?makeAI(DIFF[diffKey]||DIFF.normal):null
  };
}
function canAct(f){return !f.atk&&f.stun<=0&&!f.dead&&!f.blk&&f.gb<=0;}

function blendJ(a,b,k){
  const o={};
  for(const key in b){
    const va=a[key],vb=b[key];
    if(typeof vb==='number')o[key]=va!==undefined?va+(vb-va)*k:vb;
    else if(vb&&typeof vb.x==='number')o[key]=va?{x:va.x+(vb.x-va.x)*k,y:va.y+(vb.y-va.y)*k}:vb;
    else o[key]=vb;
  }
  return o;
}
function legIK(hip,a,lift){
  const tx=hip.x+Math.sin(a)*80,ty=hip.y+Math.cos(a)*80-lift;
  const dx=tx-hip.x,dy=ty-hip.y;
  const d=clamp(Math.hypot(dx,dy),20,81.9),base=Math.atan2(dx,dy);
  const ang=Math.acos(clamp((42*42+d*d-40*40)/(2*42*d),-1,1));
  const ka=base+ang;
  return{k:{x:hip.x+Math.sin(ka)*42,y:hip.y+Math.cos(ka)*42},f:{x:hip.x+Math.sin(base)*d,y:hip.y+Math.cos(base)*d}};
}
function computePose(f,dt){
  const c=f.c;
  const mv=f.onG&&Math.abs(f.lastMx||0)>.1&&!f.blk&&!f.dead;
  if(mv)f.ph+=dt*(10+c.sp*.012);
  const s=Math.sin(f.ph),cs=Math.cos(f.ph);
  const bob=f.onG?(mv?-Math.abs(cs)*3.4:Math.sin(f.t*3.2)*1.8):0;
  let lean=0,aUr=.9,aFr=1.6,sa=2.6,aUl=-.35,aFl=.25,lF=.22,lB=-.22;
  let liftF=0,liftB=0;
  if(mv){
    if(scene==='battle'){const pcs=f.pcs===undefined?1:f.pcs;if(pcs*cs<0)burst(f.x,GROUND-2,'#c9b48e',3,70,'spark');f.pcs=cs;}
    lF=.1+s*.7;lB=.1-s*.7;
    aUl=-s*.9;aFl=aUl+.5+Math.max(0,-cs)*.3;
    aUr=.9-s*.25;aFr=aUr+.6+Math.max(0,cs)*.25;
    lean=.06+Math.abs(cs)*.03;
    liftF=Math.max(0,cs)*9;liftB=Math.max(0,-cs)*9;
  }
  if(!f.onG){lF=.9;lB=-.5;aUl=-1.9;aFl=-2.2;aUr=2.2;aFr=2.6;sa=1.5;}
  const sg=SIG_STYLE[c.id];if(sg&&f.onG&&!mv&&!f.atk&&!f.blk&&!f.dead&&f.stun<=0){lean+=sg[1];aUr+=sg[2];lF+=sg[3];lB-=sg[3];}
  if(f.blk){aUr=1.7;aFr=2.6;sa=1.45;aUl=1.2;aFl=2.4;lean=-.05;}
  if(f.stun>0&&!f.dead){lean=-.3;aUr=-.6;aFr=-.2;sa=-.6;aUl=-1.2;aFl=-1.8;}
  if(f.atk){
    const m=f.atk.m,p=clamp(f.atk.t/m.dur,0,1),k=f.atk.k;
    const sm=x=>x*x*(3-2*x);
    const q=p<.25?-.35*sm(p/.25):p<.5?-.35+1.35*(1-Math.pow(1-(p-.25)/.25,3)):1-sm((p-.5)/.5);
    const pose=(R,W,S)=>q<0?lerp(R,W,-q/.35):lerp(R,S,q);
    if(k==='light'){aUr=pose(.9,2.6,.3);sa=pose(1.5,2.9,.3);aFr=aUr+.5;lean=pose(0,-.08,.22);}
    else if(k==='heavy'){aUr=pose(.9,3.1,.9);sa=pose(1.5,3.1,.9);aFr=aUr+.4;lean=pose(0,-.12,.28);lF=pose(.22,-.25,.6);lB=pose(.22,.5,-.45);}
    else if(k==='s1'){aUr=pose(.8,.4,1.55);aFr=aUr;sa=pose(1.3,.9,1.56);lean=pose(.05,-.05,.15);}
    else if(k==='s2'){aUr=pose(.2,-.6,1.8);aFr=aUr+.2;sa=pose(.2,.9,-.4);lean=pose(.05,-.05,.12);lF=pose(.22,-.15,.65);lB=pose(.22,.4,-.5);}
    else{aUr=f.atk.t*16;aFr=aUr+.5;sa=aUr+.8;lean=.1;}
  }
  if(f.dead){lean=-1.5;aUr=-.3;aFr=.2;sa=.4;aUl=-.5;aFl=0;}
  const hip={x:0,y:-80+bob*.5};
  const rot=p=>{
    if(!lean)return p;
    const dx=p.x-hip.x,dy=p.y-hip.y,cs2=Math.cos(lean),sn=Math.sin(lean);
    return{x:hip.x+dx*cs2-dy*sn,y:hip.y+dx*sn+dy*cs2};
  };
  const sh={x:1,y:-130+bob};
  const eR=P(sh,V(aUr,30)),hR=P(eR,V(aFr,28)),tip=P(hR,V(sa,92));
  const eL=P(sh,V(aUl,28)),hL=P(eL,V(aFl,26));
  const LF=legIK(hip,lF,liftF),LB=legIK(hip,lB,liftB);
  const kF=LF.k,fF=LF.f,kB=LB.k,fB=LB.f;
  const NJ={hip:hip,neck:rot({x:0,y:-136+bob}),head:rot({x:5,y:-162+bob}),sh:rot(sh),eR:rot(eR),hR:rot(hR),tip:rot(tip),eL:rot(eL),hL:rot(hL),kF:kF,fF:fF,kB:kB,fB:fB,lean:lean};
  f.J=f.Jp?blendJ(f.Jp,NJ,.6):NJ;f.Jp=f.J;
}

/* ---------- FIGHTER DRAWING ---------- */
function seg(a,b,col,w){
  ctx.lineCap='round';ctx.lineJoin='round';
  ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);
  ctx.strokeStyle=OUT;ctx.lineWidth=w+4;ctx.stroke();
  ctx.strokeStyle=col;ctx.lineWidth=w;ctx.stroke();
}
function pathPts(pts){ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i].x,pts[i].y);ctx.closePath();}
function polyFill(pts,col){pathPts(pts);ctx.fillStyle=col;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=2.5;ctx.stroke();}
function circ(p,r,col){ctx.beginPath();ctx.arc(p.x,p.y,r,0,6.2832);ctx.fillStyle=col;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=2;ctx.stroke();}
function offs(p,list){return list.map(d=>({x:p.x+d[0],y:p.y+d[1]}));}

function shadeFill(pts,base,dk){
  polyFill(pts,base);
  ctx.save();pathPts(pts);ctx.clip();
  const sh=pts.map(p=>({x:p.x-6,y:p.y-6}));
  ctx.beginPath();ctx.rect(-400,-400,800,800);
  ctx.moveTo(sh[0].x,sh[0].y);for(let i=1;i<sh.length;i++)ctx.lineTo(sh[i].x,sh[i].y);ctx.closePath();
  ctx.fillStyle=dk;ctx.fill('evenodd');
  ctx.restore();
}
function darkenHex(h,a){
  const n=parseInt(h.slice(1),16);
  const f=v=>Math.round(v*(1-a)).toString(16).padStart(2,'0');
  return '#'+f(n>>16&255)+f(n>>8&255)+f(n&255);
}
function drawCoat(f,pts){
  const c=f.c,pt=PT_OVERRIDE[c.id]||c.pt;
  shadeFill(pts,c.ho,darkenHex(c.ho,.4));
  ctx.save();pathPts(pts);ctx.clip();
  ctx.strokeStyle='rgba(10,10,14,.4)';ctx.lineWidth=3;
  if(pt==='check'){
    for(let i=-60;i<70;i+=14){ctx.beginPath();ctx.moveTo(i-40,-160);ctx.lineTo(i+30,0);ctx.stroke();}
    for(let i=-60;i<70;i+=14){ctx.beginPath();ctx.moveTo(i+30,-160);ctx.lineTo(i-40,0);ctx.stroke();}
  }else if(pt==='stripe'){
    for(let i=-40;i<50;i+=12){ctx.beginPath();ctx.moveTo(i,-160);ctx.lineTo(i,0);ctx.stroke();}
  }else if(pt==='tri'){
    ctx.fillStyle=lightenHex(c.ho,.3);
    for(let y=-150,r=0;y<0;y+=24,r++)for(let x=-60+(r%2)*16;x<60;x+=32){
      ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+14,y+20);ctx.lineTo(x-14,y+20);ctx.closePath();ctx.fill();
    }
  }else if(pt==='scale'){
    ctx.strokeStyle=darkenHex(c.ho,.35);ctx.lineWidth=2;
    for(let y=-160,r=0;y<0;y+=16,r++)for(let x=-60+(r%2)*12;x<60;x+=24){ctx.beginPath();ctx.arc(x,y,12,0,Math.PI);ctx.stroke();}
  }else if(pt==='dots'){
    ctx.fillStyle=lightenHex(c.ho,.35);
    for(let y=-150,r=0;y<0;y+=22,r++)for(let x=-60+(r%2)*12;x<60;x+=24){ctx.beginPath();ctx.arc(x,y,3,0,6.2832);ctx.fill();}
  }
  ctx.restore();
  seg(pts[0],pts[3],c.fx2,2.5);
  seg(pts[1],pts[2],c.fx2,2.5);
}
function hairCape(hd,L,hc){
  if(L<=0)return;
  polyFill(offs(hd,[[-10,-6],[-12-L*.3,-6+L*.2],[-14-L*.3,-6+L*.6],[-8-L*.1,-6+L*.75],[-4,4]]),hc);
  seg(offs(hd,[[-8,-4]])[0],offs(hd,[[-13-L*.25,-6+L*.5]])[0],lightenHex(hc,.25),1.6);
}
function drawBoarMask(hd,c){
  const skin='#8a7a5a',dk=darkenHex(skin,.35);
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(hd.x-17,hd.y-4);
  ctx.bezierCurveTo(hd.x-19,hd.y-24,hd.x+12,hd.y-27,hd.x+16,hd.y-8);
  ctx.bezierCurveTo(hd.x+26,hd.y-4,hd.x+27,hd.y+10,hd.x+19,hd.y+12);
  ctx.bezierCurveTo(hd.x+12,hd.y+19,hd.x-10,hd.y+19,hd.x-17,hd.y+8);
  ctx.closePath();
  ctx.fillStyle=skin;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=2.5;ctx.stroke();
  ctx.strokeStyle=dk;ctx.lineWidth=1.4;
  for(let i=0;i<5;i++){const x=hd.x-12+i*6;ctx.beginPath();ctx.moveTo(x,hd.y-18+(i%2)*2);ctx.lineTo(x-3,hd.y-22);ctx.stroke();}
  ctx.fillStyle='#14080a';ctx.beginPath();ctx.ellipse(hd.x+6,hd.y-3,5.5,4.5,0,0,6.2832);ctx.fill();
  ctx.fillStyle='#5ad8ff';ctx.beginPath();ctx.arc(hd.x+7,hd.y-3,3,0,6.2832);ctx.fill();
  ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(hd.x+8,hd.y-4,.9,0,6.2832);ctx.fill();
  ctx.beginPath();ctx.ellipse(hd.x+22,hd.y+5,7,6,0,0,6.2832);ctx.fillStyle='#e8a8a8';ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=2;ctx.stroke();
  ctx.fillStyle='#5a2a2a';ctx.beginPath();ctx.arc(hd.x+24,hd.y+3,1.2,0,6.2832);ctx.arc(hd.x+20,hd.y+3,1.2,0,6.2832);ctx.fill();
  seg({x:hd.x+14,y:hd.y+12},{x:hd.x+21,y:hd.y+21},'#f5f0e0',3.5);
  seg({x:hd.x+8,y:hd.y+14},{x:hd.x+11,y:hd.y+24},'#f5f0e0',3);
  ctx.restore();
}
function drawHair(f,back){
  const c=f.c,hd=f.J.head,hc=c.hc,st=c.hs,hi=lightenHex(hc,.3);
  if(back){
    if(st!=='bald')hairCape(hd,HAIR_LEN[c.id]||0,hc);
    if(st==='flow')polyFill(offs(hd,[[-6,-2],[-30,8],[-36,38],[-24,60],[-14,36],[-2,10]]),hc);
    if(st==='ponytail')polyFill(offs(hd,[[-12,-10],[-34,-4],[-44,16],[-34,22],[-22,6],[-10,2]]),hc);
    if(st==='bob')polyFill(offs(hd,[[-18,-6],[-22,16],[-6,22],[10,12],[12,-6]]),hc);
    return;
  }
  if(st==='mask'){drawBoarMask(hd,c);return;}
  if(st==='spiky'||st==='tuft'){
    const L=st==='tuft'?[[-18,4],[-20,-8],[-12,-6],[-14,-24],[-6,-12],[-4,-30],[2,-14],[8,-30],[10,-14],[18,-24],[16,-6],[21,2],[10,0],[0,-4],[-10,2]]
                       :[[-19,4],[-16,-10],[-8,-7],[-6,-22],[1,-13],[5,-26],[10,-13],[18,-18],[16,-5],[21,3],[12,0],[0,-4],[-10,2]];
    polyFill(offs(hd,L),hc);
  }
  if(st==='bowl'||st==='long'||st==='flow'||st==='bob'||st==='ponytail'){
    ctx.beginPath();ctx.arc(hd.x,hd.y,18,Math.PI,2*Math.PI);ctx.closePath();
    ctx.fillStyle=hc;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=2;ctx.stroke();
  }
  if(st==='bowl'||st==='long'||st==='flow')
    polyFill(offs(hd,[[-17,1],[-4,8],[10,-2],[18,1],[18,-4],[-17,-4]]),hc);
  if(st==='flow'){
    polyFill(offs(hd,[[-17,0],[-22,20],[-14,28],[-12,6]]),hc);
    polyFill(offs(hd,[[15,0],[21,18],[13,26],[12,6]]),hc);
  }
  if(st==='bob'){
    polyFill(offs(hd,[[-18,0],[-20,16],[-12,18],[-14,2]]),hc);
    polyFill(offs(hd,[[-17,-2],[-10,8],[-4,0],[2,9],[8,2],[14,8],[18,0],[18,-4],[-17,-4]]),hc);
  }
  if(st==='ponytail'){
    polyFill(offs(hd,[[-17,1],[-4,6],[10,-2],[18,1],[18,-4],[-17,-4]]),hc);
    ctx.beginPath();ctx.arc(hd.x-16,hd.y-8,6,0,6.2832);ctx.fillStyle=hc;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=2;ctx.stroke();
  }
  if(st==='horn'){
    seg({x:hd.x-7,y:hd.y-12},{x:hd.x-14,y:hd.y-32},'#e0d0a8',4);
    seg({x:hd.x+3,y:hd.y-14},{x:hd.x+8,y:hd.y-34},'#e0d0a8',4);
    ctx.beginPath();ctx.arc(hd.x,hd.y,18,Math.PI,2*Math.PI);ctx.closePath();
    ctx.fillStyle=hc;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=2;ctx.stroke();
  }
  if(st==='bald'){
    seg({x:hd.x-6,y:hd.y-8},{x:hd.x-1,y:hd.y-12},'#403020',2);
  }
  if(st!=='bald'){
    seg({x:hd.x-10,y:hd.y-12},{x:hd.x+2,y:hd.y-17},hi,2);
    seg({x:hd.x+4,y:hd.y-14},{x:hd.x+12,y:hd.y-8},hi,1.6);
  }
}
function drawFace(f){
  const c=f.c,hd=f.J.head,m=f.facing;
  if(c.dem){
    ctx.shadowColor=c.ey;ctx.shadowBlur=Q().glow?14:0;
    const eye=(x,y,rx,ry)=>{
      ctx.fillStyle='#ffffff';ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,6.2832);ctx.fill();
      ctx.fillStyle=c.ey;ctx.beginPath();ctx.ellipse(x,y,rx*.72,ry*.72,0,0,6.2832);ctx.fill();
    };
    eye(hd.x+8,hd.y-3,4.4,4.8);
    const g=DEMON_GLYPH[c.id];
    if(g){
      ctx.save();ctx.translate(hd.x+8,hd.y-3);ctx.scale(m,1);ctx.shadowBlur=0;
      ctx.fillStyle='#ffffff';ctx.font='bold 4.5px serif';ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText(g,0,0);ctx.restore();
    }
    if(c.id==='kokushibo'){
      ctx.shadowBlur=0;
      for(const [x,y] of [[2,-11],[-4,-6],[12,2],[4,4],[-1,-1]])eye(hd.x+x,hd.y+y,1.9,2.2);
    }
    ctx.shadowBlur=0;
    return;
  }
  ctx.shadowColor=c.ey;ctx.shadowBlur=Q().glow?14:0;
  ctx.fillStyle=c.ey;ctx.beginPath();ctx.ellipse(hd.x+7,hd.y-3,3.6,4.4,0,0,6.2832);ctx.fill();
  ctx.fillStyle='#ffffff';ctx.beginPath();ctx.ellipse(hd.x+8,hd.y-4,1.6,1.9,0,0,6.2832);ctx.fill();
  ctx.shadowBlur=0;
}
function strip(P,W){
  const L=[],R=[];
  for(let i=0;i<P.length;i++){
    const p=P[i],q=P[Math.min(i+1,P.length-1)],o=P[Math.max(i-1,0)];
    let tx=q.x-o.x,ty=q.y-o.y;const m=Math.hypot(tx,ty)||1;tx/=m;ty/=m;
    const nx=-ty,ny=tx,w=W[i];
    L.push({x:p.x+nx*w,y:p.y+ny*w});R.push({x:p.x-nx*w,y:p.y-ny*w});
  }
  return L.concat(R.reverse());
}
function drawBlade(hand,tip,c){
  const dx=tip.x-hand.x,dy=tip.y-hand.y,L=Math.hypot(dx,dy)||1,ux=dx/L,uy=dy/L,nx=-uy,ny=ux;
  const at=(d,o)=>({x:hand.x+ux*d+nx*o,y:hand.y+uy*d+ny*o});
  const G=16,glow=Q().glow;
  ctx.save();ctx.lineJoin='round';ctx.lineCap='round';
  const wrapC=hexA(c.fx,.9);
  seg(at(-11,0),at(G,0),'#1a1620',5.2);
  for(let d=-10;d<G-1;d+=2.4){seg(at(d,-4.2),at(d+1.4,4.2),'#2b2230',1.3);}
  seg(at(-11,0),at(G-1,0),wrapC,.7);
  const pm=at(-12,0);
  ctx.beginPath();ctx.arc(pm.x,pm.y,4.6,0,6.2832);
  const pg=ctx.createRadialGradient(pm.x-1.5,pm.y-1.5,.5,pm.x,pm.y,4.6);
  pg.addColorStop(0,'#fff0c0');pg.addColorStop(1,'#a07a2a');
  ctx.fillStyle=pg;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=1.4;ctx.stroke();
  const gp=at(G,0),ga=Math.atan2(ny,nx);
  ctx.beginPath();ctx.ellipse(gp.x,gp.y,9.5,4.2,ga,0,6.2832);
  const tg=ctx.createRadialGradient(gp.x,gp.y,1,gp.x,gp.y,10);
  tg.addColorStop(0,'#f6e08a');tg.addColorStop(1,'#8a6a1e');
  ctx.fillStyle=tg;ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=1.6;ctx.stroke();
  ctx.beginPath();ctx.ellipse(gp.x,gp.y,4.2,1.8,ga,0,6.2832);ctx.fillStyle='#1a1420';ctx.fill();
  ctx.strokeStyle=hexA(c.fx,.95);ctx.lineWidth=1.2;ctx.stroke();
  const N=18,left=[],right=[],pts=[];
  const prof=s=>({d:G+2+(L-G-2)*s,w:3.6*Math.pow(1-s,.7)+.3,c:Math.sin(s*Math.PI)*-4.2});
  for(let i=0;i<=N;i++){const q=prof(i/N);left.push(at(q.d,q.c+q.w));right.push(at(q.d,q.c-q.w));pts.push(q);}
  ctx.beginPath();ctx.moveTo(left[0].x,left[0].y);
  for(const p of left)ctx.lineTo(p.x,p.y);
  for(let i=N;i>=0;i--)ctx.lineTo(right[i].x,right[i].y);
  ctx.closePath();
  const sun=c.id==='tanjiro'||c.id==='yoriichi';
  const bg=ctx.createLinearGradient(hand.x,hand.y,tip.x,tip.y);
  if(sun){bg.addColorStop(0,'#7a1a10');bg.addColorStop(.35,'#ff8a6a');bg.addColorStop(.7,'#fff4ec');bg.addColorStop(1,'#ff5a3a');}
  else{bg.addColorStop(0,'#aeb8c4');bg.addColorStop(.35,'#f4f8fc');bg.addColorStop(.7,'#ffffff');bg.addColorStop(1,c.bl||'#dfe8ff');}
  if(glow){ctx.shadowColor=c.fx;ctx.shadowBlur=18;}
  ctx.fillStyle=bg;ctx.fill();
  ctx.shadowBlur=0;
  ctx.strokeStyle=OUT;ctx.lineWidth=1.8;ctx.stroke();
  ctx.beginPath();
  for(let i=1;i<N;i++){const q=prof(i/N);const wv=Math.sin(i*2.1)*.5;const p=at(q.d,q.c+q.w*.45+wv);i===1?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y);}
  ctx.strokeStyle=sun?'#ffd23a':hexA(c.fx,.9);ctx.lineWidth=1.3;if(glow){ctx.shadowColor=sun?'#ff4a2a':c.fx;ctx.shadowBlur=6;}ctx.stroke();ctx.shadowBlur=0;
  ctx.beginPath();
  for(let i=1;i<N;i++){const q=prof(i/N);const p=at(q.d,q.c-q.w*.6);i===1?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y);}
  ctx.strokeStyle='rgba(60,70,90,.55)';ctx.lineWidth=.9;ctx.stroke();
  const tipP=at(L,0);
  if(glow){const tg2=ctx.createRadialGradient(tipP.x,tipP.y,0,tipP.x,tipP.y,9);tg2.addColorStop(0,'rgba(255,255,255,.95)');tg2.addColorStop(.4,hexA(c.fx,.6));tg2.addColorStop(1,hexA(c.fx,0));ctx.fillStyle=tg2;ctx.beginPath();ctx.arc(tipP.x,tipP.y,9,0,6.2832);ctx.fill();}
  const sh=(performance.now()/700)%1,si=Math.floor(sh*(N-2))+1,sq=prof(si/N);
  const s1=at(sq.d-5,sq.c+sq.w*.2),s2=at(sq.d+5,sq.c+sq.w*.2);
  ctx.strokeStyle='rgba(255,255,255,.85)';ctx.lineWidth=2.2;ctx.beginPath();ctx.moveTo(s1.x,s1.y);ctx.lineTo(s2.x,s2.y);ctx.stroke();
  ctx.restore();
}
function drawClaws(h,t,c){
  const a=Math.atan2(t.y-h.y,t.x-h.x),glow=Q().glow;
  const fist=c.id==='wakuraba';
  const palmCol=fist?'#16101a':(c.sk||'#d8c8b0'),clawCol=fist?'#0c0810':'#f4eedc',glowCol=fist?'#ff2a3a':c.fx;
  const ux=Math.cos(a),uy=Math.sin(a),nx=-uy,ny=ux;
  ctx.save();ctx.lineJoin='round';ctx.lineCap='round';
  if(glow){ctx.shadowColor=glowCol;ctx.shadowBlur=14;}
  const palm=[];
  for(let i=0;i<12;i++){const q=i/12*6.2832;palm.push({x:h.x+Math.cos(q)*8*ux-Math.sin(q)*6*nx+ux*2,y:h.y+Math.cos(q)*8*uy-Math.sin(q)*6*ny+uy*2});}
  polyFill(palm,palmCol);
  ctx.shadowBlur=0;
  for(const k of [-1.5,-.5,.5,1.5]){
    const bx=h.x+nx*k*4.2+ux*6,by=h.y+ny*k*4.2+uy*6;
    const d0=a+k*.22;
    const P0={x:bx,y:by};
    const P1={x:P0.x+Math.cos(d0)*11,y:P0.y+Math.sin(d0)*11};
    const P2={x:P1.x+Math.cos(d0+.1)*10,y:P1.y+Math.sin(d0+.1)*10};
    const P3={x:P2.x+Math.cos(d0+.2)*9,y:P2.y+Math.sin(d0+.2)*9};
    polyFill(strip([P0,P1,P2],[3.9,3.4,3.0]),palmCol);
    const C=[P2,P3,{x:P3.x+Math.cos(d0+.42)*15,y:P3.y+Math.sin(d0+.42)*15}];
    if(glow){ctx.shadowColor=glowCol;ctx.shadowBlur=8;}
    polyFill(strip(C,[2.7,1.6,.2]),clawCol);
    ctx.shadowBlur=0;
    const tipP=C[2];
    ctx.beginPath();ctx.arc(tipP.x,tipP.y,1.6,0,6.2832);ctx.fillStyle=hexA(c.fx,.95);ctx.fill();
    seg(P1,P2,hexA('#000000',.25),.8);
    ctx.beginPath();ctx.arc(P1.x,P1.y,1.5,0,6.2832);ctx.fillStyle=hexA(c.fx,.85);ctx.fill();
  }
  if(glow){ctx.shadowColor=c.fx;ctx.shadowBlur=10;}
  seg({x:h.x-ux*6,y:h.y-uy*6},{x:h.x+ux*4,y:h.y+uy*4},hexA(c.fx,.7),1.4);
  ctx.restore();
}
function drawClub(h,t,c){
  const dx=t.x-h.x,dy=t.y-h.y,L=Math.hypot(dx,dy)||1,ux=dx/L,uy=dy/L;
  const e={x:h.x+ux*70,y:h.y+uy*70};
  seg(h,e,'#5a3a22',12);
  for(let k=0;k<7;k++){const a=k/7*6.2832;seg(e,{x:e.x+Math.cos(a)*22,y:e.y+Math.sin(a)*22},'#9aa0a8',4);}
  circ(e,15,'#3a2418');
}
function drawFighter(f,ox,oy,sc){
  const c=f.c,J=f.J;if(!J)return;
  const s=sc||1;
  ctx.save();
  ctx.translate(ox!==undefined?ox:f.x,oy!==undefined?oy:f.y);
  ctx.scale(f.facing*s,s);
  const hip=J.hip;
  const mvf=f.lastMx?Math.sin(f.t*10)*7:Math.sin(f.t*2)*2;
  shadeFill([{x:J.sh.x-6,y:J.sh.y+4},{x:-30+mvf,y:-44},{x:-18,y:-18},{x:hip.x+6,y:hip.y+10},{x:hip.x+12,y:hip.y-4}],c.ho,darkenHex(c.ho,.4));
  seg(J.hip,J.kB,c.hk,9);seg(J.kB,J.fB,c.hk,8);circ(J.fB,3.5,'#111');
  shadeFill([{x:hip.x-16,y:hip.y-4},{x:hip.x+16,y:hip.y-4},{x:hip.x+26,y:-24},{x:hip.x-26,y:-24}],c.hk,darkenHex(c.hk,.45));
  seg(J.hip,J.kF,c.hk,9);seg(J.kF,J.fF,c.hk,8);circ(J.fF,3.5,'#111');
  seg(J.neck,hip,'#1a1a22',13);
  seg(J.sh,J.eL,c.ho,9);seg(J.eL,J.hL,c.ho,8);circ(J.hL,4.5,c.sk);
  drawHair(f,true);
  circ(J.head,17,c.hs==='mask'?c.sk:'#0b0a0e');
  drawHair(f,false);
  if(c.hs!=='mask')drawFace(f);
  drawMouth(f);
  drawCoat(f,[{x:J.neck.x-13,y:J.neck.y+4},{x:J.neck.x+13,y:J.neck.y+4},{x:hip.x+15,y:hip.y+6},{x:hip.x-15,y:hip.y+6}]);
  polyFill([{x:J.neck.x-9,y:J.neck.y+3},{x:J.neck.x+1,y:J.neck.y+20},{x:J.neck.x+9,y:J.neck.y+3}],lightenHex(c.ho,.22));
  seg({x:J.neck.x-11,y:J.neck.y+7},{x:hip.x-13,y:hip.y+1},lightenHex(c.ho,.35),2);
  polyFill([{x:hip.x-16,y:hip.y-3},{x:hip.x+16,y:hip.y-3},{x:hip.x+17,y:hip.y+5},{x:hip.x-17,y:hip.y+5}],lightenHex(c.hk,.2));
  seg(J.sh,J.eR,c.ho,10);seg(J.eR,J.hR,c.ho,9);circ(J.hR,4.5,c.sk);
  if(c.wp==='club')drawClub(J.hR,J.tip,c);
  else if(c.bl){
    drawBlade(J.hR,J.tip,c);
    if(c.lh===2)drawBlade(J.hL,P(J.hL,V(2.2,70)),c);
  }else drawClaws(J.hR,J.tip,c);
  if(c.dem&&!c.bl&&c.wp!=='club')drawClaws(J.hL,{x:J.hL.x+f.facing*30,y:J.hL.y+6},c);
  ctx.restore();
}
function drawDummy(f){
  ctx.save();
  ctx.translate(f.x+rnd(-f.flash*3,f.flash*3),f.y);
  polyFill([{x:-8,y:-160},{x:8,y:-160},{x:8,y:0},{x:-8,y:0}],'#6b4a2a');
  polyFill([{x:-44,y:-124},{x:44,y:-124},{x:44,y:-112},{x:-44,y:-112}],'#5a3a20');
  ctx.beginPath();ctx.arc(0,-150,18,0,6.2832);ctx.fillStyle='#c9a86a';ctx.fill();ctx.strokeStyle=OUT;ctx.lineWidth=2;ctx.stroke();
  ctx.restore();
}
function drawTrail(f){
  const tr=f.trail,n=tr.length;if(n<2)return;
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.lineCap='round';
  for(let i=1;i<n;i++){
    const a=tr[i-1],b=tr[i],k=i/n;
    ctx.strokeStyle=hexA(b.c,k*.75);
    ctx.lineWidth=2+k*14*b.w;
    ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();
  }
  ctx.restore();
}
function drawMouth(f){
  if(!cut||!cutSpeaker||f.id!==cutSpeaker)return;
  const hd=f.J.head,open=1.2+2.4*Math.abs(Math.sin(performance.now()/90));
  ctx.save();
  ctx.fillStyle='#2a0a10';ctx.beginPath();ctx.ellipse(hd.x+6*f.facing,hd.y+7,2.6,open,0,0,6.2832);ctx.fill();
  ctx.restore();
}
