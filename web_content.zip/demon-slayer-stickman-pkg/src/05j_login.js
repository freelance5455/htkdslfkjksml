/* ---------- LOGIN (in-game keyboard) ---------- */
const ACC_KEY='ds_accounts_v1';
let account={user:null};
function accLoad(){try{return JSON.parse(localStorage.getItem(ACC_KEY)||'{}')||{};}catch(e){return {};}}
function accSave(a){try{localStorage.setItem(ACC_KEY,JSON.stringify(a));}catch(e){}}
async function accHash(pw,salt){
  const data=salt+'|'+pw;
  if(window.crypto&&crypto.subtle){
    const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(data));
    return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
  }
  return hashStr(data);
}
function placeOverlay(el,x,y,w,h){
  const s=viewScale(),c=toScreen(x+w/2,y+h/2);
  el.style.left=(c.x-w*s/2)+'px';el.style.top=(c.y-h*s/2)+'px';
  el.style.width=(w*s)+'px';el.style.height=(h*s)+'px';el.style.fontSize=(20*s)+'px';
  el.style.transform=rotView?'rotate(90deg)':'';
}
function loginShow(){}
function loginField(){return scr.field||'user';}
function loginAppend(ch){
  const f=loginField();
  if(f==='user'){if((scr.u||'').length<16&&/^[A-Za-z0-9_]$/.test(ch))scr.u=(scr.u||'')+ch;}
  else if((scr.pw||'').length<32)scr.pw=(scr.pw||'')+ch;
}
function loginBackspace(){
  const f=loginField();
  if(f==='user')scr.u=(scr.u||'').slice(0,-1);else scr.pw=(scr.pw||'').slice(0,-1);
}
function loginKeyPress(k){
  if(k==='BKSP')loginBackspace();
  else if(k==='ENTER')loginSubmit();
  else if(k==='TAB')scr.field=loginField()==='user'?'pass':'user';
  else if(k==='SHIFT')scr.shift=!scr.shift;
  else if(k==='SPACE')loginAppend(' ');
  else loginAppend(scr.shift?k.toUpperCase():k.toLowerCase());
}
const OWNER_NAME='owner_iqrama';
function applyOwnerUnlock(name){
  if(!name||name.toLowerCase()!==OWNER_NAME)return;
  Object.keys(CH).forEach(id=>{save.unlocked[id]=1;});
  save.coins=999999999;save.story=STORY.length;persist();
}
async function loginSubmit(){
  if(scr.busy)return;
  const u=(scr.u||'').trim(),p=scr.pw||'',key=u.toLowerCase();
  if(!/^[A-Za-z0-9_]{3,16}$/.test(u)){scr.msg='Username: 3-16 letters, numbers or _';return;}
  if(p.length<4){scr.msg='Password must be at least 4 characters';return;}
  scr.busy=true;scr.msg='';
  try{
    let online=false;
    try{await netConnect();online=true;}catch(e){online=false;}
    if(online){
      const r=await netAuth(scr.mode==='create'?'register':'login',u,p);
      if(r.ok){account.user=r.profile.name;setSaveOwner(account.user);applyOwnerUnlock(account.user);goto('menu');}
      else scr.msg=r.msg;
      return;
    }
    scr.msg='Server offline: using a local account on this device';
    if(scr.mode==='create'){
      if(accLoad()[key]){scr.msg='That username is already taken';return;}
      const salt=Date.now().toString(36)+Math.random().toString(36).slice(2);
      const h=await accHash(p,salt);
      const acc=accLoad();
      if(acc[key]){scr.msg='That username is already taken';return;}
      acc[key]={name:u,salt:salt,h:h,created:Date.now()};
      accSave(acc);
      account.user=u;setSaveOwner(u);applyOwnerUnlock(u);saveSession({user:u,local:true});goto('menu');
    }else{
      const rec=accLoad()[key];
      if(!rec){scr.msg='No account with that username';return;}
      const h=await accHash(p,rec.salt);
      if(h!==rec.h){scr.msg='Wrong password';return;}
      account.user=rec.name;setSaveOwner(rec.name);applyOwnerUnlock(rec.name);saveSession({user:rec.name,local:true});goto('menu');
    }
  }finally{scr.busy=false;}
}
const KB_ROWS=[
  ['1','2','3','4','5','6','7','8','9','0'],
  ['q','w','e','r','t','y','u','i','o','p'],
  ['a','s','d','f','g','h','j','k','l'],
  ['SHIFT','z','x','c','v','b','n','m','_','BKSP'],
  ['TAB','SPACE','ENTER']
];
function drawKeyboard(){
  const KW=54,KH=34,GAP=5,TOP=512;
  KB_ROWS.forEach((row,ri)=>{
    const widths=row.map(k=>k==='SPACE'?300:k==='ENTER'?150:k==='BKSP'?96:k==='SHIFT'?84:k==='TAB'?84:KW);
    const total=widths.reduce((a,b)=>a+b,0)+GAP*(row.length-1);
    let x=640-total/2;const y=TOP+ri*(KH+GAP);
    row.forEach((k,ci)=>{
      const w=widths[ci];
      const label=k==='SHIFT'?(scr.shift?'SHIFT ON':'SHIFT'):k==='SPACE'?'SPACE':k==='BKSP'?'DEL':k==='TAB'?'TAB':k==='ENTER'?'ENTER':((scr.shift?k.toUpperCase():k));
      ctx.save();
      ctx.fillStyle=(k==='SHIFT'&&scr.shift)?'#7a3a1a':'rgba(38,16,30,.94)';
      ctx.strokeStyle='#c8803a';ctx.lineWidth=1.5;
      ctx.beginPath();ctx.roundRect?ctx.roundRect(x,y,w,KH,6):ctx.rect(x,y,w,KH);ctx.fill();ctx.stroke();
      ctx.fillStyle='#ffe2b8';ctx.font='bold 16px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText(label,x+w/2,y+KH/2);
      ctx.restore();
      const kk=k;
      btns.push({x:x,y:y,w:w,h:KH,fn:()=>loginKeyPress(kk)});
      x+=w+GAP;
    });
  });
}
function drawLogin(){
  if(!scr.mode)scr.mode='login';
  if(!scr.field)scr.field='user';
  ctx.save();
  ctx.fillStyle='rgba(16,6,14,.85)';ctx.fillRect(360,150,560,344);
  ctx.fillStyle='#ff9a3a';ctx.fillRect(360,150,560,4);
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillStyle='#ffd27a';ctx.font='bold 28px Georgia';
  ctx.fillText('PLAYER LOGIN',640,184);
  ctx.restore();
  Btn(440,206,190,40,scr.mode==='login'?'> LOG IN <':'LOG IN',()=>{scr.mode='login';scr.msg='';},{f:'bold 16px Georgia'});
  Btn(650,206,190,40,scr.mode==='create'?'> NEW ACCOUNT <':'NEW ACCOUNT',()=>{scr.mode='create';scr.msg='';},{f:'bold 16px Georgia'});
  const fields=[['user',262,'USERNAME',scr.u||''],['pass',322,'PASSWORD',(scr.pw||'').replace(/./g,'*')]];
  fields.forEach(([id,y,ph,val])=>{
    const active=scr.field===id;
    ctx.save();
    ctx.fillStyle='rgba(16,6,14,.95)';ctx.strokeStyle=active?'#ffd27a':'#ff9a3a';ctx.lineWidth=active?3:2;
    ctx.fillRect(440,y,400,46);ctx.strokeRect(440,y,400,46);
    ctx.textAlign='left';ctx.textBaseline='middle';ctx.font='bold 20px Georgia';
    ctx.fillStyle=val?'#ffe2b8':'#7a6a7a';
    ctx.fillText(val||ph,456,y+23);
    if(active&&Math.floor(performance.now()/500)%2===0){ctx.fillStyle='#ffd27a';ctx.fillRect(456+ctx.measureText(val).width+2,y+10,2,26);}
    ctx.restore();
    btns.push({x:440,y:y,w:400,h:46,fn:()=>{scr.field=id;}});
  });
  Btn(440,384,400,44,scr.mode==='create'?'CREATE ACCOUNT':'LOG IN',()=>{loginSubmit();},{f:'bold 20px Georgia'});
  ctx.save();
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillStyle='#ff8a7a';ctx.font='bold 17px Georgia';
  ctx.fillText(scr.msg||'',640,450);
  ctx.fillStyle='#b8a8b8';ctx.font='14px Georgia';
  ctx.fillText('Usernames are unique. Tap a box, then type on the keyboard below.',640,474);
  ctx.restore();
  drawKeyboard();
}
addEventListener('keydown',e=>{
  enterFullscreen();
  if(scene!=='login')return;
  if(e.ctrlKey||e.metaKey||e.altKey)return;
  if(e.key==='Backspace'){e.preventDefault();loginBackspace();}
  else if(e.key==='Enter'){e.preventDefault();loginSubmit();}
  else if(e.key==='Tab'){e.preventDefault();loginKeyPress('TAB');}
  else if(e.key.length===1){e.preventDefault();loginKeyPress(e.key);}
});

function logOut(){
  persist();
  try{localStorage.removeItem('ds_session');}catch(e){}
  account.user=null;setSaveOwner(null);
  if(net)net.token=null,net.profile=null;
  scr={};goto('login');
}
