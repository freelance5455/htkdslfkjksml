/* ---------- FINISHERS (god-like cutscene after killing the enemy) ---------- */
const FINISH={
  tanjiro:['Sun Breathing: Thousand-Dawn Sun','The sun rises for everyone I could not save.'],
  zenitsu:['Thunderclap and Flash: Divine Speed','Faster than thought. Faster than fate.'],
  inosuke:['Beast Breathing: Final Fang Storm','Nothing survives the beast of the mountain!'],
  obanai:['Serpent Breathing: Endless Coil','Your bones belong to me now.'],
  giyu:['Water Breathing: Eternal Tide','Still water sees all. Sleep now.'],
  sanemi:['Wind Breathing: Typhoon Crown','The storm does not ask permission.'],
  rengoku:['Flame Breathing: Rising Sun Inferno','Set your heart ablaze! This is the end!'],
  mitsuri:['Love Breathing: Endless Bloom','Even monsters bloom when they fall.'],
  yoriichi:['Sun Origin: Sunfall Eternal','Before the first sword, there was only the sun.'],
  kokushibo:['Moon Breathing: Crescent Eclipse','The Moon sees your end, and it is beautiful.'],
  akaza:['Destructive Death: Final Collapse','Your strength means nothing before my fist.'],
  doma:['Ice Crystal: Absolute Winter','Feel the cold of the Moon forever.'],
  gyokko:['Art of Vases: Ten Thousand Hells','Your skin will shatter like porcelain.'],
  gyutaro:['Blood Sickle: Crimson Rain','Your blood will paint the sky red!'],
  hantengu:['Emotion Split: Ten Thousand Wrath','Every emotion I have ends you at once!'],
  rui:['Spider Web: Final Snare','Caught. Nothing escapes my threads.'],
  enmu:['Dream Prison: Eternal Sleep','Sleep forever inside my dream.'],
  wakuraba:['Frenzy Drum: Final Beat','The drums of the mansion echo your end.'],
  muzan:['Blood Demon Art: Ultimate Source','I am eternal. You are nothing.'],
  shinobu:['Insect Breathing: Wisteria Poison','One drop of poison is all it takes.'],
  tengen:['Sound Breathing: Explosive Crescendo','Let the music of the blast carry you away!'],
  muichiro:['Mist Breathing: Endless Fog','Lost in the mist, you will never find the way out.'],
  gyomei:['Stone Breathing: Mountain Crusher','Like a mountain, I do not move. Now you fall.'],
  kanao:['Flower Breathing: Lily Tempest','A flower in the wind. Your end is gentle.'],
  nezuko:['Demon Claw: Crimson Sunder','My brother protects me. And you will fall.'],
  daki:['Obi Strangle: Silken Doom','Tied up, cut, and gone!'],
  nakime:['Biwa Requiem: Final Note','One last note for your funeral.'],
  sabito:['Water Breathing: Hidden Rain','The rain I carry is for those who fell.'],
  makomo:['Snow Breathing: Winter Blizzard','The snow covers everything, even your name.'],
  kaigaku:['Demon Scroll: Ten Thousand Blades','Your bones will become my blades!'],
  susamaru:['Shrine Dance: Last Veil','Dance for the dead, mortal.'],
  yushiro:['Bloodbound Storm: Final Cleave','Your shadow ends here.'],
  tanjuro:['Ubuyashiki Iai: Final Sheath','The clan\'s blade is final.'],
  kagaya:['Ancestral Sun Shield: Last Light','The clan will endure.'],
  tamayo:['Hundred Puppet Hands: Final Hold','Stillness is all that remains.'],
  aoi:['Blue Storm Flurry: Last Wave','The flow ends here.'],
  kiyo:['Terauchi Storm: Final Slash','Hold your ground, friend.'],
  shinobubro:['Insect Storm: Final Swarm','The insects take you.'],
  tengenbro:['Sound Storm: Final Resonance','Your ears will ring forever.'],
  kagayabro:['Clan Blade: Last Strike','The clan does not yield.'],
  tanjurowife:['Warm Light: Final Embrace','Rest now, child.'],
  suma:['Floral Storm: Last Petal','The petals fall for you.'],
  kiriya:['Ubuyashiki Barrier: Final Sword','The clan\'s blade is final.']
};
const FIN_DUR=5.6;
let fin=null;
function startFinish(b){
  const id=b.cfg.p,F=FINISH[id]||['Final Release','It is over.'];
  fin={id:id,foe:b.cfg.e,tech:F[0],line:F[1],t:0,b:b};
  shake=Math.max(shake,14*Q().shake);flashA=.9;sfx('big');
}
function endFinish(){
  const b=fin?fin.b:battle;
  fin=null;
  if(b&&b.phase==='finish')b.phase='end';
}
function updateFinish(dt){
  if(!fin)return;
  fin.t+=dt;
  if(fin.t>=FIN_DUR)endFinish();
}
function drawFinish(){
  if(!fin)return;
  const t=fin.t,col=CH[fin.id].fx||'#ffd27a';
  ctx.save();
  ctx.fillStyle='rgba(0,0,0,'+Math.min(.94,t*1.6)+')';ctx.fillRect(0,0,W,H);
  const rayA=clamp((t-.2)/.5,0,1)*(1-clamp((t-FIN_DUR+.8)/.8,0,1));
  ctx.globalAlpha=rayA*.42;ctx.fillStyle=col;
  for(let i=0;i<28;i++){
    const a=i*Math.PI*2/28+t*.7;
    ctx.beginPath();ctx.moveTo(640,330);ctx.lineTo(640+Math.cos(a)*1600,330+Math.sin(a)*1600);
    ctx.lineTo(640+Math.cos(a+.06)*1600,330+Math.sin(a+.06)*1600);ctx.closePath();ctx.fill();
  }
  ctx.globalAlpha=1;
  const core=ctx.createRadialGradient(640,330,10,640,330,160+clamp(t,0,1.4)*240);
  core.addColorStop(0,hexA('#ffffff',.9*clamp(t/.8,0,1)));core.addColorStop(.35,hexA(col,.55));core.addColorStop(1,hexA(col,0));
  ctx.fillStyle=core;ctx.fillRect(0,0,W,H);
  for(const t0 of [.7,1.5,2.4]){
    const k=(t-t0)/.9;
    if(k>0&&k<1){ctx.globalAlpha=1-k;ctx.strokeStyle=col;ctx.lineWidth=20*(1-k)+2;ctx.beginPath();ctx.arc(640,330,40+k*780,0,6.2832);ctx.stroke();}
  }
  ctx.globalAlpha=1;
  const pk=easeOutBack(clamp(t/.7,0,1));
  drawPortrait(fin.id,430,650,Math.max(.05,2.5*pk),1);
  drawPortrait(fin.foe,880,650,2.2,-1);
  ctx.textAlign='center';ctx.textBaseline='middle';
  if(t>.4){
    ctx.globalAlpha=clamp((t-.4)/.3,0,1);ctx.fillStyle='#fff1dc';ctx.font='bold 20px Georgia';
    ctx.fillText('FINAL RELEASE',640,58);
    ctx.globalAlpha=1;
  }
  const tp=easeOutBack(clamp((t-1.0)/.45,0,1));
  if(tp>0){
    ctx.save();ctx.translate(640,112);ctx.scale(tp,tp);
    ctx.font='bold 46px Impact, "Arial Black", Georgia';ctx.lineJoin='round';
    ctx.lineWidth=10;ctx.strokeStyle='#000';ctx.strokeText(fin.tech,0,0);
    ctx.fillStyle=col;ctx.fillText(fin.tech,0,0);
    ctx.restore();
  }
  if(t>2.2){
    const n=Math.floor((t-2.2)*28),txt=fin.line.slice(0,n);
    ctx.fillStyle='rgba(10,6,16,.85)';rr(140,580,1000,96,14);ctx.fill();
    ctx.strokeStyle=col;ctx.lineWidth=2;ctx.stroke();
    ctx.fillStyle='#ffe2b8';ctx.font='italic 26px Georgia';ctx.textAlign='center';
    ctx.fillText(txt,640,628);
  }
  if(t>3.2){
    ctx.globalAlpha=clamp((t-3.2)/.4,0,1);ctx.fillStyle='#ff8a8a';ctx.font='bold 18px Georgia';ctx.textAlign='center';
    ctx.fillText('DEFEATED: '+CH[fin.foe].n.toUpperCase(),640,160);
    ctx.globalAlpha=1;
  }
  ctx.fillStyle='#c8a8d8';ctx.font='14px Georgia';ctx.textAlign='right';
  ctx.fillText('Click or press Enter to continue',1150,700);
  ctx.restore();
  btns.push({x:0,y:0,w:W,h:H,fn:endFinish});
}
addEventListener('keydown',e=>{
  if(scene==='login')return;
  if(scene==='battle'&&fin&&(e.key==='Enter'||e.key===' ')){e.preventDefault();endFinish();}
});
