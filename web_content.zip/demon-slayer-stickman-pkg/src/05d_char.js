/* ---------- TIERS ---------- */
const TIER={
  tanjiro:2,yoriichi:1,muzan:1,
  giyu:2,sanemi:2,rengoku:2,mitsuri:2,obanai:2,shinobu:2,tengen:2,muichiro:2,gyomei:2,
  kokushibo:2,akaza:2,doma:2,gyokko:2,gyutaro:2,hantengu:2,daki:2,nakime:2,
  zenitsu:3,inosuke:3,kanao:3,nezuko:3,rui:3,enmu:3,wakuraba:3,sabito:3,makomo:4,kaigaku:2,susamaru:3,yushiro:4,tanjuro:2,kagaya:2,tamayo:3,
  aoi:4,kiyo:4,shinobubro:3,tengenbro:3,kagayabro:3,tanjurowife:4,suma:4,kiriya:2
};
const TIER_DMG={1:1.4,2:1.25,3:1.1,4:1};
const HAIR_LEN={tanjiro:80,zenitsu:70,inosuke:85,obanai:100,giyu:70,sanemi:72,rengoku:70,mitsuri:110,yoriichi:90,kokushibo:100,akaza:62,doma:95,gyokko:40,gyutaro:75,hantengu:80,rui:100,enmu:70,wakuraba:66,muzan:72,shinobu:92,tengen:75,muichiro:90,gyomei:0,kanao:100,nezuko:110,daki:115,nakime:100,sabito:66,makomo:100,kaigaku:80,};
const PT_OVERRIDE={inosuke:'scale',gyomei:'scale',yoriichi:'scale',shinobu:'dots',mitsuri:'dots',kanao:'dots',nezuko:'dots',daki:'dots',nakime:'dots',makomo:'dots',doma:'dots',giyu:'check',tengen:'check',sabito:'check',obanai:'stripe',sanemi:'stripe',muichiro:'stripe',kokushibo:'stripe',akaza:'tri',rengoku:'tri',zenitsu:'tri'};
for(const k in CH){
  CH[k].tier=TIER[k]||4;
  CH[k].dm=+(CH[k].dm*TIER_DMG[CH[k].tier]).toFixed(3);
  if(CH[k].dem)CH[k].ey='#ff2a2a';
}
const TIER_FX={1:{n:1.6,aura:'#ffd24a',slashes:2},2:{n:1.3,aura:'#ff8a3a',slashes:2},3:{n:1,aura:null,slashes:1},4:{n:.7,aura:null,slashes:1}};
const DEMON_GLYPH={kokushibo:'上壱',doma:'上弐',akaza:'上参',hantengu:'上肆',gyokko:'上肆',gyutaro:'上陸',daki:'上陸',nakime:'上伍',enmu:'下壱',wakuraba:'下参',rui:'下伍',muzan:'鬼',kaigaku:'鬼'};
const WORLD_NAMES={1:'LOWER MOON HUNT',2:'UPPER MOON WAR',3:'LANTERN NIGHTS',4:'BAMBOO SONG',5:'DEMON MOUNTAIN',6:'FROZEN OATH',7:'VOLCANO TRIAL',8:'RUINED EMOTIONS',9:'MOON SHRINE',10:'POISON TIDE',11:'SNOW VALLEY',12:'THE DEMON REALM',13:'SHRINE OF SHADOWS',14:'STORM OF THE HASHIRA',15:'THE LAST MOON'};
function drawAura(f){
  const t=TIER_FX[f.c.tier];if(!t||!t.aura)return;
  const k=.5+.5*Math.sin(menuT*4+f.x*.01);
  ctx.save();ctx.globalCompositeOperation='lighter';
  const g=ctx.createRadialGradient(f.x,f.y-90,20,f.x,f.y-90,130);
  g.addColorStop(0,hexA(t.aura,.25*k));g.addColorStop(1,hexA(t.aura,0));
  ctx.fillStyle=g;ctx.fillRect(f.x-150,f.y-230,300,300);ctx.restore();
}

/* ---------- SIGNATURE STYLES ----------
   [effect shape, lean, arm offset, leg spread] per character */
const SIG_STYLE={
  tanjiro:['ring',0,0,0],zenitsu:['bolt',.12,-.2,.18],inosuke:['crack',-.04,.3,.2],obanai:['streak',.06,.4,0],
  giyu:['ring',-.02,-.1,.05],sanemi:['streak',-.06,.2,.12],rengoku:['puff',-.08,.15,.06],mitsuri:['puff',.1,-.1,.08],
  shinobu:['shard',0,.25,-.05],tengen:['ring',-.04,-.2,.1],muichiro:['puff',.04,.3,-.08],gyomei:['crack',-.1,-.3,.14],kanao:['shard',.05,-.25,.04],nezuko:['drop',.18,.3,-.05],daki:['streak',.02,.45,0],
  nakime:['ring',.05,.35,-.04],yoriichi:['ring',-.06,.05,.06],kokushibo:['crescent',-.02,.2,-.05],akaza:['crack',.05,.3,.14],
  doma:['shard',.02,.1,.06],gyokko:['drop',.1,.2,-.05],gyutaro:['crescent',.1,.25,0],hantengu:['puff',.08,.2,0],
  rui:['streak',.04,.25,-.03],enmu:['ring',0,.2,-.06],wakuraba:['crack',-.02,-.15,.16],muzan:['drop',.12,.3,-.08],sabito:['ring',.02,.1,.04],makomo:['ring',.1,.2,0],kaigaku:['streak',.04,.3,.1],
};
const FX_SHAPES=[];
function lightenHex(h,a){
  const n=parseInt(h.slice(1),16);
  const f=v=>Math.min(255,Math.round(v+(255-v)*a)).toString(16).padStart(2,'0');
  return '#'+f(n>>16&255)+f(n>>8&255)+f(n&255);
}
function spawnShape(f,shape,col){
  const dir=f.facing;
  const s={s:shape,x:f.x+dir*rnd(-10,110),y:f.y-rnd(20,170),vx:0,vy:0,a:rnd(0,6.28),c:col,face:dir,life:rnd(.45,.85),j:[]};
  s.max=s.life;
  for(let i=0;i<8;i++)s.j.push(rnd(-1,1));
  if(shape==='streak'||shape==='crescent')s.vx=dir*rnd(380,620);
  else if(shape==='crack')s.y=GROUND;
  else if(shape==='bolt')s.y=f.y-170;
  else if(shape==='drop')s.vy=rnd(180,320);
  else if(shape==='puff')s.vy=-rnd(30,80);
  else if(shape==='shard'){s.vx=rnd(-220,220);s.vy=rnd(-220,120);}
  if(FX_SHAPES.length>180)FX_SHAPES.shift();
  FX_SHAPES.push(s);
}
function sigStyle(f){return SIG_STYLE[f.c.id]||['ring'];}
function sigFx(f,key){
  const n=Math.round((key==='s2'?7:key==='s1'?5:6)*TIER_FX[f.c.tier].n);
  for(let i=0;i<n;i++)spawnShape(f,sigStyle(f)[0],i%2?f.c.fx2:f.c.fx);
}
function sigTick(f){
  if(Math.random()<.5)spawnShape(f,sigStyle(f)[0],Math.random()<.5?f.c.fx:f.c.fx2);
}
function updateShapes(dt){
  for(let i=FX_SHAPES.length-1;i>=0;i--){
    const s=FX_SHAPES[i];
    s.x+=s.vx*dt;s.y+=s.vy*dt;s.life-=dt;
    if(s.life<=0)FX_SHAPES.splice(i,1);
  }
}
function drawShapes(){
  if(!FX_SHAPES.length)return;
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.lineCap='round';ctx.lineJoin='round';
  for(const s of FX_SHAPES){
    const k=Math.max(0,s.life/s.max),g=1-k;
    ctx.save();
    ctx.globalAlpha=k;ctx.strokeStyle=s.c;ctx.fillStyle=s.c;ctx.lineWidth=3;
    switch(s.s){
      case 'ring':{const r=12+g*70;ctx.beginPath();ctx.ellipse(s.x,s.y,r,r*.4,0,0,6.2832);ctx.stroke();break;}
      case 'bolt':{ctx.beginPath();ctx.moveTo(s.x,s.y);for(let i=1;i<=6;i++)ctx.lineTo(s.x+s.j[i]*22,s.y+i*(190/6));ctx.stroke();break;}
      case 'crack':{ctx.beginPath();for(let i=0;i<5;i++){const x=s.x+(i-2)*60,l=g*70;ctx.moveTo(x,GROUND);ctx.lineTo(x+s.j[i]*l,GROUND+l*.35);}ctx.stroke();break;}
      case 'streak':{ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(s.x-90*s.face,s.y);ctx.lineTo(s.x,s.y);ctx.stroke();break;}
      case 'puff':{ctx.globalAlpha=k*.45;ctx.beginPath();ctx.arc(s.x,s.y,14+g*26,0,6.2832);ctx.fill();break;}
      case 'shard':{ctx.translate(s.x,s.y);ctx.rotate(s.a+g*6);ctx.beginPath();ctx.moveTo(0,-10);ctx.lineTo(6,6);ctx.lineTo(-6,6);ctx.closePath();ctx.fill();break;}
      case 'crescent':{ctx.lineWidth=6;ctx.translate(s.x,s.y);ctx.scale(s.face,1);ctx.beginPath();ctx.arc(0,0,44,-1.1,1.1);ctx.stroke();break;}
      case 'drop':{ctx.beginPath();ctx.ellipse(s.x,s.y,3,6,0,0,6.2832);ctx.fill();break;}
    }
    ctx.restore();
  }
  ctx.restore();
}

/* ---------- MENU ---------- */
function drawMenu(){
  const t=menuT,ch=CH[sel];
  ctx.save();
  const ag=ctx.createRadialGradient(960,420,30,960,420,330);
  ag.addColorStop(0,hexA(ch.fx,.5));ag.addColorStop(1,hexA(ch.fx,0));
  ctx.fillStyle=ag;ctx.fillRect(560,60,800,660);
  ctx.globalCompositeOperation='lighter';
  for(let i=0;i<3;i++){
    ctx.fillStyle='rgba(255,200,140,'+(.045+.025*Math.sin(t*2+i))+')';
    ctx.beginPath();ctx.moveTo(640+i*120,0);ctx.lineTo(720+i*120,0);ctx.lineTo(440+i*120,H);ctx.lineTo(360+i*120,H);ctx.closePath();ctx.fill();
  }
  ctx.restore();
  ctx.save();
  ctx.fillStyle='rgba(16,6,14,.78)';
  ctx.beginPath();ctx.moveTo(30,64);ctx.lineTo(800,30);ctx.lineTo(800,236);ctx.lineTo(30,240);ctx.closePath();ctx.fill();
  ctx.fillStyle='#ff9a3a';ctx.beginPath();ctx.moveTo(30,240);ctx.lineTo(800,236);ctx.lineTo(800,242);ctx.lineTo(30,246);ctx.closePath();ctx.fill();
  ctx.textAlign='left';ctx.textBaseline='alphabetic';
  ctx.font='bold 88px Georgia';
  ctx.fillStyle='rgba(0,0,0,.65)';ctx.fillText('DEMON SLAYER',74,166);
  const tg=ctx.createLinearGradient(70,80,700,170);
  tg.addColorStop(0,'#fff0c0');tg.addColorStop(.5,'#ffb24a');tg.addColorStop(1,'#ff4a1a');
  ctx.fillStyle=tg;ctx.fillText('DEMON SLAYER',70,160);
  ctx.lineWidth=3;ctx.strokeStyle=OUT;ctx.strokeText('DEMON SLAYER',70,160);
  ctx.font='bold 26px Georgia';ctx.fillStyle='#ffd27a';ctx.fillText('PIXEL WAR',72,206);
  ctx.restore();
  const items=[
    ['STORY MODE',()=>goto('story')],
    ['OFFLINE BATTLE',()=>goto('offline')],
    ['QUICK FIGHT',()=>{quick.mode='quick';goto('quick');}],
    ['TRAINING ARENA',()=>{quick.mode='training';quick.p=trial||sel;goto('quick');}],
    ['CHARACTER SELECT',()=>goto('select')],
    ['CHARACTER SHOP',()=>goto('shop')],
    ['TIER LIST',()=>goto('tiers')],
    ['CUSTOM CONTROLS',()=>goto('controls')],
    ['SETTINGS',()=>goto('settings')],
    ['ONLINE MULTIPLAYER',()=>showToast('Coming soon')],
    ['LOG OUT',()=>logOut()]
  ];
  items.forEach((it,i)=>{
    const slide=Math.max(0,1-(menuT-i*.06)*4)*80;
    const x=60-slide,y=250+i*44,w=360,h=40;
    ctx.save();
    ctx.beginPath();ctx.moveTo(x+14,y);ctx.lineTo(x+w,y);ctx.lineTo(x+w-14,y+h);ctx.lineTo(x,y+h);ctx.closePath();
    const g=ctx.createLinearGradient(x,y,x+w,y);
    g.addColorStop(0,'rgba(130,34,54,.94)');g.addColorStop(1,'rgba(30,10,24,.9)');
    ctx.fillStyle=g;ctx.fill();
    ctx.fillStyle='#ff9a3a';ctx.fillRect(x,y,5,h);
    ctx.strokeStyle='rgba(255,180,100,.55)';ctx.lineWidth=1.5;ctx.stroke();
    ctx.fillStyle='#fff1dc';ctx.font='bold 18px Georgia';ctx.textAlign='left';ctx.textBaseline='middle';
    ctx.fillText(it[0],x+22,y+h/2+1);
    ctx.fillStyle='rgba(255,200,140,'+(.5+.4*Math.sin(t*5+i))+')';ctx.textAlign='right';
    ctx.fillText('>',x+w-16,y+h/2+1);
    ctx.restore();
    btns.push({x:x,y:y,w:w,h:h,fn:it[1]});
  });
  ctx.save();
  ctx.fillStyle='rgba(10,6,16,.7)';rr(940,56,320,112,14);ctx.fill();
  ctx.strokeStyle=hexA(ch.fx,.8);ctx.lineWidth=2;ctx.stroke();
  ctx.textAlign='center';ctx.textBaseline='alphabetic';
  ctx.fillStyle='#ffe2b8';ctx.font='bold 24px Georgia';ctx.fillText(ch.n,1100,96);
  ctx.font='14px Georgia';ctx.fillStyle='#c8a8d8';ctx.fillText(ch.b,1100,120);
  ctx.fillStyle=hexA(ch.fx,1);ctx.font='bold 14px Georgia';ctx.fillText('TIER '+ch.tier+'   x'+(TIER_DMG[ch.tier]).toFixed(2)+' DAMAGE',1100,146);
  ctx.restore();
  ctx.save();
  ctx.textAlign='right';ctx.font='bold 22px Georgia';ctx.fillStyle='#ffd27a';
  ctx.fillText('Demon Coins: '+save.coins.toLocaleString(),1250,36);
  ctx.textAlign='left';ctx.fillStyle='#ffe2b8';ctx.font='bold 16px Georgia';ctx.fillText('Player: '+(account.user||'-'),30,300);ctx.textAlign='right';
  ctx.restore();
  ctx.save();
  const sy=Math.min(save.story,STORY.length)/STORY.length;
  ctx.fillStyle='#e8c8ff';ctx.font='15px Georgia';ctx.textAlign='left';
  ctx.fillText('Story progress: '+Math.min(save.story,STORY.length)+' / '+STORY.length,70,700);
  ctx.fillStyle='rgba(20,8,20,.8)';rr(70,708,300,8,4);ctx.fill();
  ctx.fillStyle='#ffb36b';rr(70,708,300*sy,8,4);ctx.fill();
  ctx.restore();
  drawPortrait(sel,980,640,2.6,1);
}

/* ---------- TIER LIST ---------- */
function drawTiers(){
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffd27a';ctx.font='bold 34px Georgia';
  ctx.fillText('TIER LIST',640,46);
  ctx.font='15px Georgia';ctx.fillStyle='#e8c8ff';
  ctx.fillText('Higher tiers hit harder:   T1 x1.40    T2 x1.25    T3 x1.10    T4 x1.00',640,80);
  ctx.restore();
  Btn(30,18,120,40,'BACK',()=>goto('menu'));
  const rows=[[1,'TIER 1','Top of the Corps','#ffd24a'],[2,'TIER 2','Hashira & Upper Moons','#ff8a3a'],[3,'TIER 3','Elite Slayers & Lower Moons','#b080ff'],[4,'TIER 4','Normal Demon Slayers','#8a9aa8']];
  let y=110;
  for(const [t,label,sub,col] of rows){
    const names=ROSTER.filter(id=>CH[id].tier===t);
    const rowH=Math.max(1,Math.ceil(names.length/5))*44+16;
    ctx.save();
    ctx.fillStyle='rgba(12,6,20,.85)';rr(40,y,190,rowH,10);ctx.fill();
    ctx.strokeStyle=col;ctx.lineWidth=3;ctx.stroke();
    ctx.fillStyle=col;ctx.font='bold 24px Georgia';ctx.textAlign='left';ctx.textBaseline='middle';
    ctx.fillText(label,58,y+rowH/2-10);
    ctx.font='12px Georgia';ctx.fillStyle='#e8c8ff';ctx.fillText(sub,58,y+rowH/2+14);
    ctx.restore();
    names.forEach((id,i)=>{
      const cx=250+(i%5)*190,cy=y+8+Math.floor(i/5)*44;
      ctx.save();
      ctx.fillStyle=save.unlocked[id]?'rgba(60,24,40,.92)':'rgba(30,20,30,.7)';rr(cx,cy,180,36,8);ctx.fill();
      ctx.strokeStyle=col;ctx.lineWidth=1.5;ctx.stroke();
      ctx.fillStyle=save.unlocked[id]?'#ffe2b8':'#8a7a8a';ctx.font='bold 14px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText(CH[id].n.slice(0,22),cx+90,cy+18);
      ctx.restore();
    });
    y+=rowH+14;
  }
}

/* ---------- CUSTOM CONTROLS ---------- */
let ctrlDrag=null;
function ctrlItems(){
  const L=layout();
  return [{k:'joy',x:L.joy.x,y:L.joy.y,r:L.joy.r,lab:'MOVE'}].concat(L.btns.map(b=>({k:b.k,x:b.x,y:b.y,r:b.r,lab:b.lab})));
}
function ctrlPress(p){
  let best=null,bd=1e9;
  for(const it of ctrlItems()){
    const d=Math.hypot(p.x-it.x,p.y-it.y);
    if(d<=it.r+14&&d<bd){bd=d;best=it;}
  }
  if(best)ctrlDrag={k:best.k,dx:p.x-best.x,dy:p.y-best.y,r:best.r};
}
function ctrlMove(p){
  if(!ctrlDrag)return;
  const r=ctrlDrag.r;
  const x=clamp(p.x-ctrlDrag.dx,r,W-r),y=clamp(p.y-ctrlDrag.dy,r,H-r);
  save.layout=save.layout||{};
  save.layout[ctrlDrag.k]={x:Math.round(x),y:Math.round(y)};
}
function drawCtrlEdit(){
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffd27a';ctx.font='bold 26px Georgia';
  ctx.fillText('CUSTOM CONTROLS  -  drag any control anywhere on the screen',680,30);
  ctx.restore();
  Btn(30,8,120,38,'DONE',()=>{ctrlDrag=null;persist();goto('menu');},{f:'bold 15px Georgia'});
  Btn(170,8,170,38,'RESET LAYOUT',()=>{save.layout=null;persist();},{f:'bold 15px Georgia'});
  ctx.save();
  for(const it of ctrlItems()){
    ctx.beginPath();ctx.arc(it.x,it.y,it.r,0,6.2832);
    ctx.fillStyle='rgba(30,12,30,.6)';ctx.fill();
    ctx.strokeStyle='#ffb36b';ctx.lineWidth=3;ctx.setLineDash([10,8]);ctx.stroke();ctx.setLineDash([]);
    ctx.fillStyle='#fff1dc';ctx.font='bold '+Math.round(it.r*.4)+'px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillText(it.lab,it.x,it.y);
  }
  ctx.restore();
}
