/* ---------- ULTIMATE CUTSCENES (fight pauses, character powers up, then the ultimate lands) ---------- */
const ULT_CUT={
  tanjiro:['Hinokami Kagura: Sun Dance Unleashed','I will burn away everything that hurts them!'],
  zenitsu:['Thunder Breathing: Ninth Form','Lightning, take me to the end!'],
  inosuke:['Beast Breathing: Ultimate Rampage','Me king of the mountain! Crush!'],
  obanai:['Serpent Breathing: Hundred Coils','Constrict. Do not let go.'],
  giyu:['Water Breathing: Ninth Form, Dead Calm','Stillness is the deadliest form of motion.'],
  sanemi:['Wind Breathing: Storm of Blades','Get out of my way!'],
  rengoku:['Flame Breathing: Hundred Blazing Suns','Ah, my heart burns for you!'],
  mitsuri:['Love Breathing: Thousand Petals','Let me love you all the way to the end!'],
  yoriichi:['Sun Origin: Radiant Dominion','All of this is beneath the Sun.'],
  kokushibo:['Moon Breathing: Six Eyes Awaken','Six eyes see your every move.'],
  akaza:['Destructive Death: Ultimate Burst','Hahaha! Keep up, keep up!'],
  doma:['Ice Crystal: Frozen Heaven','The whole world turns to ice!'],
  gyokko:['Art of Vases: Porcelain Storm','Every vase hides a poison.'],
  gyutaro:['Blood Sickle: Infinite Ribbons','Your flesh will be shredded!'],
  hantengu:['Emotion Split: Legion of Wrath','Every body, every emotion, attack!'],
  rui:['Spider Thread: Web Cage','You are caught in my web, and it will tighten.'],
  enmu:['Dream Prison: Infinite Nightmare','Sleep. Sleep. And never wake up!'],
  wakuraba:['Frenzy Drum: Mansion Hymn','The drums are calling.'],
  muzan:['Blood Demon Art: Ultimate Flesh','I will consume the entire world.'],
  shinobu:['Insect Breathing: Poison Hive','The hive remembers every wound.'],
  tengen:['Sound Breathing: Grand Finale','Ladies and gentlemen, this is the finale!'],
  muichiro:['Mist Breathing: Ninth Form, Sea of Fog','Disappear into the mist.'],
  gyomei:['Stone Breathing: Mountain Eclipse','The mountain falls upon you.'],
  kanao:['Flower Breathing: Wisteria Wind','Let the flowers bloom through the storm.'],
  nezuko:['Demon Blood Art: Crimson Flood','My brother, stand behind me. I will do this.'],
  daki:['Obi Dance: Thousand Silk Bind','Bind them tight, my obi!'],
  nakime:['Biwa Requiem: Thunder Refrain','Let the strings hear your end.'],
  sabito:['Water Breathing: Rain of Remembrance','For everyone who fell before me!'],
  makomo:['Snow Breathing: Blizzard Crown','Snow falls, and the cold takes everything.'],
  kaigaku:['Demon Scroll: Endless Swords','Blades without end!'],
  susamaru:['Shrine Dance: Endless Veil','Dance for the dead, mortal.'],
  yushiro:['Bloodbound Storm: Storm Cleave','Your shadow ends here.'],
  tanjuro:['Ubuyashiki Iai: Thousand Sheaths','The clan\'s blade is final.'],
  kagaya:['Ancestral Sun Shield: Dawn Barrier','The clan will endure.'],
  tamayo:['Hundred Puppet Hands: Grip Eternal','Stillness is all that remains.'],
  aoi:['Blue Storm Flurry: Endless Flow','The flow ends here.'],
  kiyo:['Terauchi Storm: Dawn Slash','Hold your ground, friend.'],
  shinobubro:['Insect Storm: Thousand Swarm','The insects take you.'],
  tengenbro:['Sound Storm: Endless Echo','Your ears will ring forever.'],
  kagayabro:['Clan Blade: Ancestral Strike','The clan does not yield.'],
  tanjurowife:['Warm Light: Warm Embrace','Rest now, child.'],
  suma:['Floral Storm: Blizzard of Petals','The petals fall for you.'],
  kiriya:['Ubuyashiki Barrier: Eternal Sword','The clan\'s blade is final.']
};
const ULT_DUR=2.8;
let ultCut=null;
function startUltCut(b,id,isEnemy){
  const U=ULT_CUT[id]||['Ultimate Strike','This is my true power.'];
  ultCut={id:id,foe:isEnemy?b.cfg.p:b.cfg.e,tech:U[0],line:U[1],t:0,b:b,side:isEnemy?-1:1};
  b.phase='ultcut';
  shake=Math.max(shake,10*Q().shake);
  sfx('ult');
}
function endUltCut(){
  const b=ultCut?ultCut.b:battle;
  ultCut=null;
  if(b&&b.phase==='ultcut')b.phase='fight';
}
function updateUltCut(dt){
  if(!ultCut)return;
  ultCut.t+=dt;
  if(ultCut.t>=ULT_DUR)endUltCut();
}
function drawUltCut(){
  if(!ultCut)return;
  const t=ultCut.t,col=CH[ultCut.id].fx||'#ffd27a';
  const slide=easeOutCubic(clamp(t/.55,0,1));
  const px0=-260+680*slide,py=560;
  const px=ultCut.side===1?px0:1280-px0;
  ctx.save();
  ctx.fillStyle='rgba(0,0,0,'+Math.min(.97,t*2.5)+')';ctx.fillRect(0,0,W,H);
  ctx.globalAlpha=clamp(t/.4,0,1)*.6;ctx.fillStyle=col;
  for(let i=0;i<22;i++){const y=60+i*28,x=(t*1400+i*170)%(W+300)-150;ctx.fillRect(x,y,160+(i%3)*60,3);}
  ctx.globalAlpha=1;
  const aura=ctx.createRadialGradient(px,330,20,px,330,260+clamp(t,0,1.2)*160);
  aura.addColorStop(0,hexA(col,.7));aura.addColorStop(1,hexA(col,0));
  ctx.fillStyle=aura;ctx.fillRect(0,0,W,H);
  if(t>.5){
    ctx.globalAlpha=clamp((t-.5)/.4,0,1);ctx.strokeStyle=col;ctx.lineWidth=5;
    ctx.beginPath();ctx.moveTo(px-520*clamp((t-.5)/.6,0,1),py+8);ctx.lineTo(px+520*clamp((t-.5)/.6,0,1),py+8);ctx.stroke();
    ctx.globalAlpha=1;
  }
  for(const t0 of [.6,1.3]){
    const k=(t-t0)/.8;
    if(k>0&&k<1){ctx.globalAlpha=1-k;ctx.strokeStyle=col;ctx.lineWidth=16*(1-k)+2;ctx.beginPath();ctx.ellipse(px,py+10,60+k*620,(60+k*620)*.22,0,0,6.2832);ctx.stroke();}
  }
  ctx.globalAlpha=1;
  drawPortrait(ultCut.id,px+Math.sin(t*60)*(t<.55?6*(1-slide):0),py,2.8,ultCut.side);
  drawPortrait(ultCut.foe,ultCut.side===1?1000:280,560,2.2,-ultCut.side);
  ctx.textAlign='center';ctx.textBaseline='middle';
  const tp=easeOutBack(clamp((t-.7)/.4,0,1));
  if(tp>0){
    ctx.save();ctx.translate(640,110);ctx.scale(tp,tp);
    ctx.font='bold 42px Impact, "Arial Black", Georgia';ctx.lineJoin='round';
    ctx.lineWidth=9;ctx.strokeStyle='#000';ctx.strokeText(ultCut.tech,0,0);
    ctx.fillStyle=col;ctx.fillText(ultCut.tech,0,0);
    ctx.restore();
  }
  if(t>1.5){
    const n=Math.floor((t-1.5)*28),txt=ultCut.line.slice(0,n);
    ctx.fillStyle='rgba(10,6,16,.85)';rr(140,580,1000,86,14);ctx.fill();
    ctx.strokeStyle=col;ctx.lineWidth=2;ctx.stroke();
    ctx.fillStyle='#ffe2b8';ctx.font='italic 25px Georgia';
    ctx.fillText(txt,640,623);
  }
  if(t>ULT_DUR-.5){
    ctx.globalAlpha=clamp((t-(ULT_DUR-.5))/.5,0,1)*.85;ctx.fillStyle='#ffffff';ctx.fillRect(0,0,W,H);ctx.globalAlpha=1;
  }
  ctx.fillStyle='#c8a8d8';ctx.font='14px Georgia';ctx.textAlign='right';
  ctx.fillText('Click or press Enter to skip',1150,700);
  ctx.restore();
  btns.push({x:0,y:0,w:W,h:H,fn:endUltCut});
}
addEventListener('keydown',e=>{
  if(scene==='login')return;
  if(scene==='battle'&&ultCut&&(e.key==='Enter'||e.key===' ')){e.preventDefault();endUltCut();}
});
