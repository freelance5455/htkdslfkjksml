
/* ---------- UI STATE ---------- */
let scene='intro',scr={},trans=null,btns=[],menuT=0,toastObj=null;
let rosterDet='tanjiro',sel='tanjiro',trial=null;
let offCfg={diff:'normal',arena:0,rounds:1,opp:'rui'};
let waves=[],parts=[],texts=[],petals=[];

function Btn(x,y,w,h,label,fn,o){
  o=o||{};
  btns.push({x:x,y:y,w:w,h:h,fn:fn});
  ctx.save();
  const g=ctx.createLinearGradient(0,y,0,y+h);
  g.addColorStop(0,o.a||'#6a2238');g.addColorStop(1,o.b||'#2a0c1a');
  ctx.fillStyle=g;rr(x,y,w,h,10);ctx.fill();
  ctx.strokeStyle=o.s||'#ffb36b';ctx.lineWidth=2;ctx.stroke();
  ctx.fillStyle=o.tc||'#fff1dc';ctx.font=o.f||'bold 20px Georgia';
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillText(label,x+w/2,y+h/2+1);
  ctx.restore();
}
function showToast(m){toastObj={m:m,t:2.6};}
const PREV={};
function drawPortrait(id,x,y,sc,face){
  if(ART[id]&&ART[id].complete&&ART[id].naturalWidth){drawArtPortrait(id,x,y,sc,face);return;}
  let f=PREV[id];
  if(!f){f=makeF(id,0,1,false,'normal',1);PREV[id]=f;}
  f.facing=face||1;f.t+=frameDt;f.lastMx=0;f.onG=true;f.y=GROUND;
  computePose(f,frameDt);
  drawFighter(f,x,y,sc);
}
function goto(name,arg){trans={to:name,arg:arg,st:0,t:0};}
function enterScene(name,arg){
  scene=name;scr={};menuT=0;loginShow(name==='login');joinShow(name==='online');
  if(name==='battle'){startBattle(arg);return;}
  if(name==='cutscene'){startCut(arg);return;}
  if(name==='select'||name==='shop'){scr.kind=name;rosterDet=sel;}
}

/* ---------- ROSTER (SELECT / SHOP) ---------- */
function drawRoster(kind){
  const modalOpen=!!scr.modal;
  ctx.save();
  ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffd27a';ctx.font='bold 34px Georgia';
  ctx.fillText(kind==='select'?'CHARACTER SELECT':'CHARACTER SHOP',640,46);
  ctx.restore();
  if(!modalOpen)Btn(30,18,120,40,'BACK',()=>goto('menu'));
  ctx.save();ctx.textAlign='right';ctx.font='bold 20px Georgia';ctx.fillStyle='#ffd27a';
  ctx.fillText('Demon Coins: '+save.coins.toLocaleString(),1250,46);ctx.restore();
  const pg=scr.page||0,PAGE=25;
  ROSTER.slice(pg*PAGE,pg*PAGE+PAGE).forEach((id,i)=>{
    const c=CH[id],cx=i%5,row=Math.floor(i/5),x=40+cx*172,y=96+row*120;
    const owned=!!save.unlocked[id];
    if(!modalOpen)btns.push({x:x,y:y,w:162,h:104,fn:()=>{rosterDet=id;}});
    ctx.save();
    const g=ctx.createLinearGradient(0,y,0,y+104);
    g.addColorStop(0,rosterDet===id?'#5a2a3a':'#2a1430');g.addColorStop(1,'#120818');
    ctx.fillStyle=g;rr(x,y,162,104,10);ctx.fill();
    ctx.strokeStyle=rosterDet===id?'#ffd24a':(owned?'#8a5a3a':'#3a2a3a');ctx.lineWidth=2;ctx.stroke();
    ctx.restore();
    ctx.save();ctx.textAlign='left';ctx.textBaseline='middle';ctx.globalAlpha=owned?1:.6;
    ctx.fillStyle='#ffe2b8';ctx.font='bold 13px Georgia';ctx.fillText(c.n.slice(0,18),x+8,y+14);
    ctx.font='9px Georgia';ctx.fillStyle='#c8a8d8';ctx.fillText(c.b.slice(0,26),x+8,y+27);
    ctx.font='bold 11px Georgia';ctx.fillStyle=owned?'#7cf07c':'#ffd24a';
    ctx.fillText(owned?'OWNED':(c.p===0?'FREE':c.p.toLocaleString()+' coins'),x+8,y+90);
    ctx.restore();
    drawPortrait(id,x+110,y+100,.34,1);
  });
  if(!modalOpen){
    const pages=Math.ceil(ROSTER.length/25);
    if(pg>0)Btn(40,686,120,30,'< PREV',()=>{scr.page=pg-1;},{f:'bold 14px Georgia'});
    if(pg<pages-1)Btn(1040,686,120,30,'NEXT >',()=>{scr.page=pg+1;},{f:'bold 14px Georgia'});
    ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffe2b8';ctx.font='bold 14px Georgia';
    ctx.fillText('Page '+(pg+1)+' / '+pages,640,701);ctx.restore();
  }
  // detail panel
  const d=rosterDet,dc=CH[d],dOwned=!!save.unlocked[d];
  ctx.save();ctx.fillStyle='rgba(12,6,20,.9)';rr(910,96,340,590,14);ctx.fill();
  ctx.strokeStyle='#ffb36b';ctx.lineWidth=2;ctx.stroke();ctx.restore();
  drawPortrait(d,1080,400,1.3,1);
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillStyle='#ffe2b8';ctx.font='bold 22px Georgia';ctx.fillText(dc.n,1080,428);
  ctx.font='14px Georgia';ctx.fillStyle='#c8a8d8';ctx.fillText(dc.b,1080,450);
  ctx.textAlign='left';ctx.font='bold 13px Georgia';ctx.fillStyle='#ffe2b8';
  const bars=[['HP',clamp(dc.hp/1800,0,1)],['SPEED',clamp((dc.sp-300)/200,0,1)],['POWER',clamp(dc.dm/1.3,0,1)]];
  bars.forEach((b,i)=>{
    const yy=478+i*22;
    ctx.fillStyle='#ffe2b8';ctx.fillText(b[0],930,yy);
    ctx.fillStyle='#2a1a2a';rr(1010,yy-6,230,12,6);ctx.fill();
    ctx.fillStyle='#ffb36b';rr(1010,yy-6,230*b[1],12,6);ctx.fill();
  });
  ctx.font='12px Georgia';ctx.fillStyle='#ffe2b8';
  ctx.fillText(('S1: '+dc.s1).slice(0,40),930,556);
  ctx.fillText(('S2: '+dc.s2).slice(0,40),930,574);
  ctx.fillText(('ULT: '+dc.ul).slice(0,40),930,592);
  ctx.restore();
  if(!modalOpen){
    if(dOwned){
      if(kind==='select'){
        if(sel===d)Btn(930,630,300,40,'SELECTED',()=>{});
        else Btn(930,630,300,40,'SELECT',()=>{sel=d;showToast(dc.n+' selected');});
      }else Btn(930,630,300,40,'OWNED',()=>{});
    }else{
      if(kind==='select')Btn(930,630,300,40,'TRY IN TRAINING',()=>{trial=d;showToast('Trial enabled for the Training Arena only.');},{f:'bold 17px Georgia'});
      else Btn(930,630,300,40,'UNLOCK - '+dc.p.toLocaleString(),()=>{
        if(save.coins>=dc.p)scr.modal={t:'buy',id:d};
        else scr.modal={t:'poor',id:d,need:dc.p-save.coins};
      },{f:'bold 17px Georgia'});
    }
  }
}
function drawModal(){
  const m=scr.modal;
  if(!m)return;
  ctx.save();ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(0,0,W,H);ctx.restore();
  ctx.save();ctx.fillStyle='#140a1e';rr(330,220,620,260,18);ctx.fill();
  ctx.strokeStyle='#ffb36b';ctx.lineWidth=3;ctx.stroke();ctx.restore();
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffe2b8';ctx.font='22px Georgia';
  if(m.t==='buy'){
    const c=CH[m.id];
    ctx.fillText('Unlock '+c.n+' for '+c.p.toLocaleString()+' Demon Coins?',640,300);
    ctx.restore();
    Btn(400,370,200,50,'YES',()=>{
      const cc=CH[m.id];
      save.coins-=cc.p;save.unlocked[m.id]=1;persist();
      scr.modal=null;showToast(cc.n+' unlocked!');
    });
    Btn(680,370,200,50,'NO',()=>{scr.modal=null;});
  }else if(m.t==='poor'){
    ctx.fillText('You need '+m.need.toLocaleString()+' more Demon Coins.',640,300);
    ctx.restore();
    Btn(400,370,200,50,'EARN COINS',()=>{scr.modal=null;goto('offline');});
    Btn(680,370,200,50,'CLOSE',()=>{scr.modal=null;});
  }else if(m.t==='erase'){
    ctx.fillText('Erase ALL progress? This cannot be undone.',640,300);
    ctx.restore();
    Btn(400,370,200,50,'ERASE',()=>{
      save.coins=0;save.unlocked={tanjiro:1,zenitsu:1};save.story=0;save.bossWins={};
      sel='tanjiro';trial=null;persist();scr.modal=null;showToast('Progress erased.');
    },{a:'#6a1a1a',b:'#2a0808'});
    Btn(680,370,200,50,'CANCEL',()=>{scr.modal=null;});
  }
}

/* ---------- OFFLINE SETUP ---------- */
function drawOffline(){
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffd27a';ctx.font='bold 34px Georgia';
  ctx.fillText('OFFLINE BATTLE',640,46);ctx.restore();
  Btn(30,18,120,40,'BACK',()=>goto('menu'));
  ctx.save();ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillStyle='#ffd27a';ctx.font='bold 18px Georgia';
  ctx.fillText('DIFFICULTY',60,140);ctx.fillText('ARENA',60,226);ctx.fillText('ROUNDS',60,316);ctx.fillText('OPPONENT',60,406);
  ctx.restore();
  DIFF_KEYS.forEach((k,i)=>{
    const on=offCfg.diff===k;
    Btn(60+i*124,160,114,44,DIFF[k].lab,()=>{offCfg.diff=k;},on?{a:'#c4502a',b:'#6a2a10'}:undefined);
  });
  ARENAS.forEach((a,i)=>{
    const on=offCfg.arena===i;
    Btn(60+i*212,246,200,44,a.n,()=>{offCfg.arena=i;},on?{a:'#c4502a',b:'#6a2a10'}:undefined);
  });
  Btn(60,336,200,44,'1 ROUND',()=>{offCfg.rounds=1;},offCfg.rounds===1?{a:'#c4502a',b:'#6a2a10'}:undefined);
  Btn(480,336,200,44,mapLabel(),()=>cycleMap(),{f:'bold 15px Georgia'});
  Btn(270,336,200,44,'BEST OF 3',()=>{offCfg.rounds=3;},offCfg.rounds===3?{a:'#c4502a',b:'#6a2a10'}:undefined);
  const cycle=d=>{const i=ROSTER.indexOf(offCfg.opp);offCfg.opp=ROSTER[(i+d+ROSTER.length)%ROSTER.length];};
  Btn(60,426,60,44,'<',()=>cycle(-1));
  ctx.save();ctx.fillStyle='rgba(10,6,16,.7)';rr(130,426,330,44,10);ctx.fill();
  ctx.fillStyle='#ffe2b8';ctx.font='bold 20px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillText(CH[offCfg.opp].n,295,448);ctx.restore();
  Btn(470,426,60,44,'>',()=>cycle(1));
  Btn(60,520,470,60,'START BATTLE',()=>{
    if(!save.unlocked[sel]){showToast('Unlock this character in the shop first.');return;}
    goto('battle',{mode:'offline',p:sel,e:offCfg.opp,diff:offCfg.diff,arena:offCfg.arena,rounds:offCfg.rounds});
  },{f:'bold 26px Georgia'});
  ctx.save();ctx.textAlign='center';ctx.font='bold 18px Georgia';ctx.fillStyle='#ffe2b8';
  ctx.fillText(CH[sel].n,820,200);ctx.fillText(CH[offCfg.opp].n,1130,200);
  ctx.font='bold 40px Georgia';ctx.fillStyle='#ff5a2a';ctx.fillText('VS',975,420);
  ctx.restore();
  drawPortrait(sel,820,560,1.6,1);
  drawPortrait(offCfg.opp,1130,560,1.6,-1);
}

/* ---------- STORY MAP ---------- */
function startStory(i){
  if(!save.unlocked[sel]){showToast('Unlock this character in the shop first.');return;}
  const st=STORY[i];
  goto('battle',{mode:'story',idx:i,p:sel,e:st.e,diff:st.d,arena:st.a!==undefined?st.a:(st.w===1?0:3),rounds:1,line:st.line});
}
function drawStory(){
  const curW=STORY[Math.min(save.story,STORY.length-1)].w;
  const w=scr.world||curW;
  const nodes=STORY.map((st,i)=>({st:st,i:i})).filter(o=>o.st.w===w);
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffd27a';ctx.font='bold 34px Georgia';
  ctx.fillText('STORY MODE',640,46);ctx.restore();
  Btn(30,18,120,40,'BACK',()=>goto('menu'));
  ctx.save();ctx.textAlign='right';ctx.font='bold 18px Georgia';ctx.fillStyle='#ffe2b8';
  ctx.fillText('Progress '+Math.min(save.story,STORY.length)+' / '+STORY.length+'   Coins '+save.coins.toLocaleString(),1250,46);ctx.restore();
  const unlocked=nodes.length>0&&nodes[0].i<=save.story;
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='bold 24px Georgia';ctx.fillStyle=unlocked?'#ffd27a':'#7a6a7a';
  ctx.fillText('WORLD '+w+': '+WORLD_NAMES[w]+(unlocked?'':'  (locked)'),640,130);ctx.restore();
  Btn(60,110,70,44,'<',()=>{scr.world=Math.max(1,w-1);});
  Btn(1150,110,70,44,'>',()=>{scr.world=Math.min(15,w+1);});
  Btn(960,110,170,44,mapLabel(),()=>cycleMap(),{f:'bold 15px Georgia'});
  const n=nodes.length,SP=Math.min(200,1000/Math.max(1,n-1));
  nodes.forEach((o,k)=>{
    const i=o.i,st=o.st,x=640+(k-(n-1)/2)*SP,y=330;
    if(k>0){
      const px=640+(k-1-(n-1)/2)*SP;
      ctx.save();ctx.strokeStyle='rgba(255,190,120,.4)';ctx.lineWidth=4;
      ctx.beginPath();ctx.moveTo(px,y);ctx.lineTo(x,y);ctx.stroke();ctx.restore();
    }
    const done=i<save.story,isCur=i===save.story,avail=i<=save.story;
    ctx.save();
    if(isCur){const pulse=.5+.5*Math.sin(menuT*4);ctx.shadowColor='#ff7a2a';ctx.shadowBlur=20+pulse*15;}
    ctx.beginPath();ctx.arc(x,y,36,0,6.2832);
    ctx.fillStyle=done?'#c8a040':isCur?'#c4502a':'#2a2030';ctx.fill();
    ctx.strokeStyle=avail?'#ffe2b8':'#4a3a4a';ctx.lineWidth=3;ctx.stroke();
    ctx.restore();
    ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#fff';ctx.font='bold 22px Georgia';
    ctx.fillText(done?'✓':String(i+1),x,y);
    ctx.font='bold 13px Georgia';ctx.fillStyle=avail?'#ffe2b8':'#7a6a7a';
    ctx.fillText(st.t.slice(0,20),x,y+56);
    ctx.font='11px Georgia';ctx.fillStyle='#c8a8d8';
    ctx.fillText(avail?CH[st.e].n.slice(0,18):'LOCKED',x,y+74);
    ctx.restore();
    if(avail)btns.push({x:x-60,y:y-44,w:120,h:150,fn:()=>startStory(i)});
  });
}

/* ---------- SETTINGS ---------- */
function drawSettings(){
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffd27a';ctx.font='bold 34px Georgia';
  ctx.fillText('SETTINGS',640,46);ctx.restore();
  Btn(30,18,120,40,'BACK',()=>goto('menu'));
  const rows=[
    {l:'Graphics',type:'btn',label:'Graphics: '+Q().n,fn:()=>{save.graphics=(save.graphics+1)%QUAL.length;persist();}},
    {l:'Button Size',type:'num',v:Math.round(save.btnScale*100)+'%',d:()=>{save.btnScale=clamp(+(save.btnScale-.1).toFixed(1),.6,1.6);persist();},u:()=>{save.btnScale=clamp(+(save.btnScale+.1).toFixed(1),.6,1.6);persist();}},
    {l:'Joystick Size',type:'num',v:Math.round(save.joyScale*100)+'%',d:()=>{save.joyScale=clamp(+(save.joyScale-.1).toFixed(1),.6,1.6);persist();},u:()=>{save.joyScale=clamp(+(save.joyScale+.1).toFixed(1),.6,1.6);persist();}},
    {l:'Button Opacity',type:'num',v:Math.round(save.opacity*100)+'%',d:()=>{save.opacity=clamp(+(save.opacity-.1).toFixed(1),.3,1);persist();},u:()=>{save.opacity=clamp(+(save.opacity+.1).toFixed(1),.3,1);persist();}},
    {l:'Left-Handed Layout',type:'btn',label:'Left-Handed: '+(save.lh?'ON':'OFF'),fn:()=>{save.lh=save.lh?0:1;persist();}},
    {l:'Show FPS',type:'btn',label:'FPS Counter: '+(save.fps?'ON':'OFF'),fn:()=>{save.fps=save.fps?0:1;persist();}},
    {l:'Sound Effects',type:'num',v:Math.round(vol('sfxVol')*100)+'%',d:()=>{audioInit();save.sfxVol=clamp(+(vol('sfxVol')-.1).toFixed(1),0,1);applyVolumes();persist();},u:()=>{audioInit();save.sfxVol=clamp(+(vol('sfxVol')+.1).toFixed(1),0,1);applyVolumes();persist();}},
    {l:'Music',type:'num',v:Math.round(vol('musVol')*100)+'%',d:()=>{audioInit();save.musVol=clamp(+(vol('musVol')-.1).toFixed(1),0,1);applyVolumes();persist();},u:()=>{audioInit();save.musVol=clamp(+(vol('musVol')+.1).toFixed(1),0,1);applyVolumes();persist();}},
    {l:'Custom Music',type:'btn',label:'Choose Your Own Track',fn:()=>{audioInit();pickCustomMusic();}},
    {l:'Reset Controls',type:'btn',label:'Restore Default Controls',fn:()=>{save.btnScale=1;save.joyScale=1;save.opacity=.85;save.lh=0;save.layout=null;persist();showToast('Controls reset.');}},
    {l:'Erase Progress',type:'btn',label:'Erase All Progress',fn:()=>{scr.modal={t:'erase'};},o:{a:'#6a1a1a',b:'#2a0808'}}
  ];
  rows.forEach((r,i)=>{
    const y=104+i*56;
    ctx.save();ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillStyle='#ffe2b8';ctx.font='bold 20px Georgia';
    ctx.fillText(r.l,120,y+22);ctx.restore();
    if(r.type==='num'){
      Btn(700,y,60,44,'-',r.d);
      ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffd27a';ctx.font='bold 20px Georgia';
      ctx.fillText(r.v,840,y+22);ctx.restore();
      Btn(900,y,60,44,'+',r.u);
    }else{
      Btn(700,y,380,44,r.label,r.fn,r.o);
    }
  });
  if(scr.modal)return;
}

/* ---------- TRANSITIONS / TOAST ---------- */
function drawToast(){
  if(!toastObj)return;
  const a=Math.min(1,toastObj.t);
  ctx.save();ctx.globalAlpha=a;ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillStyle='rgba(20,8,24,.9)';rr(340,650,600,40,10);ctx.fill();
  ctx.strokeStyle='#ffb36b';ctx.lineWidth=2;ctx.stroke();
  ctx.fillStyle='#ffe2b8';ctx.font='bold 17px Georgia';ctx.fillText(toastObj.m,640,670);
  ctx.restore();
}

/* ---------- INPUT ---------- */
const KEYMAP={a:'left',arrowleft:'left',d:'right',arrowright:'right',w:'jump',arrowup:'jump',' ':'jump',s:'block',arrowdown:'block',l:'block',j:'light',k:'heavy',u:'s1',i:'s2',o:'ult',shift:'dash',e:'dash',escape:'pause',p:'pause'};
function keyAct(e){return KEYMAP[(e.key||'').toLowerCase()];}
function toggleFullscreen(){
  try{
    if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});
    else document.documentElement.requestFullscreen().catch(()=>{});
  }catch(_){}
}
addEventListener('keydown',e=>{
  enterFullscreen();
  if(scene==='login')return;
  audioInit();
  if((e.key==='f'||e.key==='F')&&!e.ctrlKey&&!e.metaKey&&!e.repeat){toggleFullscreen();return;}
  const a=keyAct(e);if(!a)return;
  e.preventDefault();
  if(a==='pause'){if(!e.repeat)togglePause();return;}
  if(a==='left')held.left=true;
  else if(a==='right')held.right=true;
  else if(a==='block')held.kbBlock=true;
  else if(!e.repeat)edge[a]=true;
});
addEventListener('keyup',e=>{
  if(scene==='login')return;
  const a=keyAct(e);if(!a)return;
  if(a==='left')held.left=false;
  else if(a==='right')held.right=false;
  else if(a==='block')held.kbBlock=false;
});
addEventListener('blur',()=>{held.left=held.right=held.kbBlock=false;held.blockCnt=0;ptrMap.clear();joyActive=false;joyBlock=false;});
function lockLandscape(){try{const o=window.screen&&window.screen.orientation;if(o&&o.lock)o.lock('landscape').catch(()=>{});}catch(_){}}
function enterFullscreen(){
  try{
    const el=document.documentElement;
    if(document.fullscreenElement||!el.requestFullscreen)return;
    el.requestFullscreen().then(lockLandscape).catch(()=>{});
  }catch(_){}
}
document.addEventListener('fullscreenchange',()=>{if(document.fullscreenElement)lockLandscape();});
function firstTap(){audioInit();enterFullscreen();}
function updJoy(p,L){
  let dx=(p.x-L.joy.x)/L.joy.r,dy=(p.y-L.joy.y)/L.joy.r;
  const len=Math.hypot(dx,dy);
  if(len>1){dx/=len;dy/=len;}
  joyX=dx;joyY=dy;
  if(dy<-.6&&!joyLatch){edge.jump=true;joyLatch=true;}
  if(dy>-.3)joyLatch=false;
  joyBlock=dy>.6;
}
cv.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('pointerdown',e=>{
  e.preventDefault();firstTap();
  try{cv.setPointerCapture(e.pointerId);}catch(_){}
  if(trans)return;
  const p=toL(e);
  for(let i=btns.length-1;i>=0;i--){
    const b=btns[i];
    if(p.x>=b.x&&p.x<=b.x+b.w&&p.y>=b.y&&p.y<=b.y+b.h){b.fn();return;}
  }
  if(scene==='controls'){ctrlPress(p);return;}
  if(scene!=='battle'||!battle||battle.paused||battle.phase==='end')return;
  const L=layout();
  for(const bt of L.btns){
    if(Math.hypot(p.x-bt.x,p.y-bt.y)<=bt.r+10){
      ptrMap.set(e.pointerId,{k:bt.k});
      if(bt.k==='block')held.blockCnt++;else edge[bt.k]=true;
      return;
    }
  }
  if(Math.hypot(p.x-L.joy.x,p.y-L.joy.y)<=L.joy.r*1.5){
    ptrMap.set(e.pointerId,{joy:true});joyActive=true;updJoy(p,L);
  }
});
cv.addEventListener('pointermove',e=>{
  if(scene==='controls'){ctrlMove(toL(e));return;}
  const m=ptrMap.get(e.pointerId);
  if(m&&m.joy&&battle)updJoy(toL(e),layout());
});
function ptrEnd(e){
  if(ctrlDrag){ctrlDrag=null;persist();}
  const m=ptrMap.get(e.pointerId);if(!m)return;
  ptrMap.delete(e.pointerId);
  if(m.k==='block')held.blockCnt=Math.max(0,held.blockCnt-1);
  if(m.joy){joyActive=false;joyX=0;joyY=0;joyBlock=false;joyLatch=false;}
}
cv.addEventListener('pointerup',ptrEnd);
cv.addEventListener('pointercancel',ptrEnd);

/* ---------- MAIN LOOP ---------- */
function render(){
  ctx.fillStyle='#05060c';ctx.fillRect(0,0,W,H);
  btns=[];
  if(scene==='battle'){
    drawBattle();
  }else{
    drawArena(ARENAS[0],menuT);
    drawPetals();
    if(scene==='menu')drawMenu();
    else if(scene==='select'||scene==='shop')drawRoster(scr.kind||scene);
    else if(scene==='offline')drawOffline();
    else if(scene==='story')drawStory();
    else if(scene==='settings')drawSettings();
    else if(scene==='cutscene')drawCut();
    else if(scene==='tiers')drawTiers();
    else if(scene==='controls')drawCtrlEdit();
    else if(scene==='intro')drawIntro();
    else if(scene==='quick')drawQuick();
    else if(scene==='login')drawLogin();
    else if(scene==='online')drawOnline();
    if(scr.modal)drawModal();
  }
  if(trans){
    const a=trans.st===0?trans.t/.22:1-trans.t/.22;
    ctx.fillStyle='rgba(0,0,0,'+clamp(a,0,1)+')';ctx.fillRect(0,0,W,H);
  }
  drawToast();
  if(save.fps){
    ctx.save();ctx.fillStyle='#7cf07c';ctx.font='bold 14px Georgia';ctx.textAlign='left';
    ctx.fillText('FPS '+fpsV,8,H-10);ctx.restore();
  }
}
function update(dt){
  frameDt=dt;
  menuT+=dt;
  updatePetals(dt);updateParts(dt);updateTexts(dt);updateFxAll(dt);
  if(shake>0)shake=Math.max(0,shake-dt*40);
  if(flashA>0)flashA=Math.max(0,flashA-dt*2.5);
  if(toastObj){toastObj.t-=dt;if(toastObj.t<=0)toastObj=null;}
  if(trans){
    trans.t+=dt;
    if(trans.st===0&&trans.t>=.22){enterScene(trans.to,trans.arg);trans.st=1;trans.t=0;}
    else if(trans.st===1&&trans.t>=.22)trans=null;
  }
  if(scene==='battle'){if(battle&&battle.mode==='online')lockUpdate(dt);else updateBattle(dt);}
  else for(const k in edge)edge[k]=false;
}
let last=performance.now(),fpsT=0,fpsN=0,fpsV=60;
function frame(now){
  let dt=(now-last)/1000;last=now;
  if(dt>.05)dt=.05;if(dt<0)dt=0;
  fpsT+=dt;fpsN++;
  if(fpsT>=.5){fpsV=Math.round(fpsN/fpsT);fpsT=0;fpsN=0;}
  update(dt);
  render();
  requestAnimationFrame(frame);
}
if(tamperWarn)showToast('Save data was altered, so progress was reset.');
requestAnimationFrame(frame);
