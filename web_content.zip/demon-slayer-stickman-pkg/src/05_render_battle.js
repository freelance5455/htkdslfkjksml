
/* ---------- EFFECTS ---------- */
const STARS=Array.from({length:90},()=>({x:Math.random()*W,y:Math.random()*380,p:Math.random()*6}));
function burst(x,y,c,n,sp,kind){
  const cnt=Math.round(n*PM());
  for(let i=0;i<cnt;i++){
    const ang=Math.random()*6.2832,spd=sp*rnd(.3,1);
    parts.push({x:x,y:y,vx:Math.cos(ang)*spd,vy:Math.sin(ang)*spd,life:rnd(.25,.5),max:.5,c:c,k:kind});
  }
  const cap=Q().max;
  if(parts.length>cap)parts.splice(0,parts.length-cap);
}
function updateParts(dt){
  for(let i=parts.length-1;i>=0;i--){
    const p=parts[i];
    p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=500*dt;p.life-=dt;
    if(p.life<=0)parts.splice(i,1);
  }
}
function drawParts(){
  ctx.save();ctx.globalCompositeOperation='lighter';
  for(const p of parts){
    const a=Math.max(0,p.life/p.max);
    if(p.k==='spark'){
      ctx.strokeStyle=hexA(p.c,a);ctx.lineWidth=2.5;ctx.lineCap='round';
      ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x-p.vx*.03,p.y-p.vy*.03);ctx.stroke();
    }else{
      ctx.fillStyle=hexA(p.c,a);
      ctx.beginPath();ctx.arc(p.x,p.y,3,0,6.2832);ctx.fill();
    }
  }
  ctx.restore();
}
function addText(x,y,s,c,big){texts.push({x:x,y:y,s:s,c:c,big:big||1,t:0});}
function updateTexts(dt){
  for(let i=texts.length-1;i>=0;i--){const t=texts[i];t.t+=dt;if(t.t>.9)texts.splice(i,1);}
}
function drawTexts(){
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';
  for(const t of texts){
    const a=1-t.t/.9;
    ctx.globalAlpha=a;ctx.fillStyle=t.c;
    ctx.font='bold '+Math.round(26*t.big)+'px Georgia';
    ctx.fillText(t.s,t.x,t.y-t.t*60);
  }
  ctx.restore();
}
function updatePetals(dt){
  const want=Q().pet;
  while(petals.length<want)petals.push({x:rnd(0,W),y:rnd(-100,H),vx:rnd(-30,-10),vy:rnd(40,90),r:rnd(0,6.2),s:rnd(4,8)});
  while(petals.length>want)petals.pop();
  for(const p of petals){
    p.x+=(p.vx+Math.sin(p.y*.01)*20)*dt;p.y+=p.vy*dt;p.r+=dt*2;
    if(p.y>H+10){p.y=-10;p.x=rnd(0,W);}
    if(p.x<-20)p.x=W+20;
  }
}
function drawPetals(){
  ctx.save();ctx.fillStyle='rgba(255,183,213,.85)';
  for(const p of petals){
    ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.r);
    ctx.beginPath();ctx.ellipse(0,0,p.s,p.s*.55,0,0,6.2832);ctx.fill();
    ctx.restore();
  }
  ctx.restore();
}

/* ---------- ARENA ---------- */
function ridge(base,amp,seed,col){
  ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(0,H);
  for(let x=0;x<=W+40;x+=40){
    const y=base+Math.sin(x*.012+seed)*amp+Math.sin(x*.031+seed*1.7)*amp*.45;
    ctx.lineTo(x,y);
  }
  ctx.lineTo(W,H);ctx.closePath();ctx.fill();
}
function temple(x,y,s,col){
  ctx.fillStyle=col;
  ctx.fillRect(x-60*s,y-80*s,120*s,80*s);
  ctx.beginPath();
  ctx.moveTo(x-120*s,y-80*s);ctx.lineTo(x,y-120*s);ctx.lineTo(x+120*s,y-80*s);
  ctx.lineTo(x+90*s,y-80*s);ctx.lineTo(x,y-100*s);ctx.lineTo(x-90*s,y-80*s);
  ctx.closePath();ctx.fill();
}
function treeBlob(x,y,r,col){
  ctx.fillStyle=col;
  ctx.beginPath();ctx.arc(x,y,r,0,6.2832);ctx.arc(x+r*.7,y+r*.3,r*.8,0,6.2832);ctx.arc(x-r*.6,y+r*.4,r*.7,0,6.2832);ctx.fill();
}
function drawArena(th,t,map){
  if(map!==undefined&&MAP_PAINT[map]){mapBackdrop(map,t);return;}
  const g=ctx.createLinearGradient(0,0,0,GROUND);
  g.addColorStop(0,th.sky[0]);g.addColorStop(1,th.sky[1]);
  ctx.fillStyle=g;ctx.fillRect(0,0,W,GROUND+4);
  if(th.moon){
    for(const s of STARS){ctx.globalAlpha=.4+.4*Math.sin(t*2+s.p);ctx.fillStyle='#ffffff';ctx.fillRect(s.x,s.y,2,2);}
    ctx.globalAlpha=1;
    const mg=ctx.createRadialGradient(1000,130,20,1000,130,170);
    mg.addColorStop(0,'rgba(255,240,200,.9)');mg.addColorStop(.3,'rgba(255,220,160,.3)');mg.addColorStop(1,'rgba(255,200,120,0)');
    ctx.fillStyle=mg;ctx.fillRect(820,-40,360,340);
    ctx.fillStyle='#fff3d6';ctx.beginPath();ctx.arc(1000,130,62,0,6.2832);ctx.fill();
  }
  ridge(420,40,0,'rgba(30,14,44,.75)');
  ridge(470,28,2.1,'rgba(20,10,30,.9)');
  if(th.tree){for(const x of [60,240,560,900,1160])treeBlob(x,500,70,'rgba(10,20,14,.9)');}
  temple(1120,500,1,'rgba(12,6,18,.95)');
  if(!th.tree)temple(150,500,.8,'rgba(12,6,18,.95)');
  ctx.fillStyle=th.ground;ctx.fillRect(0,GROUND,W,H-GROUND);
  ctx.strokeStyle='rgba(0,0,0,.25)';ctx.lineWidth=2;
  for(let x=-200;x<W+200;x+=90){ctx.beginPath();ctx.moveTo(x,GROUND);ctx.lineTo(x-60,H);ctx.stroke();}
  ctx.strokeStyle='rgba(255,190,120,.35)';ctx.lineWidth=3;
  ctx.beginPath();ctx.moveTo(0,GROUND);ctx.lineTo(W,GROUND);ctx.stroke();
  if(Q().fog){
    ctx.fillStyle=hexA(th.fog,.14);
    ctx.fillRect(0,470+Math.sin(t*.7)*8,W,110);
    ctx.fillStyle=hexA(th.fog,.09);
    ctx.fillRect(0,520+Math.sin(t*.5+1)*6,W,80);
  }
  const vg=ctx.createRadialGradient(640,360,380,640,360,820);
  vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.55)');
  ctx.fillStyle=vg;ctx.fillRect(0,0,W,H);
}
/* ---------- BATTLE RENDER ---------- */
function drawBattle(){
  const b=battle;
  const p1=b.p1,p2=b.p2;
  ctx.save();
  if(shake>0)ctx.translate(rnd(-shake,shake),rnd(-shake,shake)*.6);
  drawArena(b.arena,b.t,b.map);
  drawWaves();
  drawGhosts();
  const order=p1.x<=p2.x?[p1,p2]:[p2,p1];
  for(const f of order){
    drawAura(f);
    drawTrail(f);
    if(f.dummy)drawDummy(f);else if(f===p1&&acdActive())drawAtkCardOn(f);else if(artReady(f.id))drawSpriteFighter(f);else drawFighter(f);
  }
  drawSlashes();
  drawRings();
  drawShapes();
  drawParts();
  drawTexts();
  drawPetals();
  ctx.restore();
  if(flashA>0){ctx.fillStyle='rgba(255,255,255,'+flashA+')';ctx.fillRect(0,0,W,H);}
  drawHUD(b);
  drawAnnounce();
  if(b.line&&b.t<5){
    const a=b.t>4?1-(b.t-4):1;
    ctx.save();ctx.globalAlpha=Math.max(0,a);
    ctx.fillStyle='rgba(10,6,16,.7)';rr(340,104,600,34,8);ctx.fill();
    ctx.fillStyle='#ffe2b8';ctx.font='italic 18px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillText(b.line,640,121);
    ctx.restore();
  }
  drawControls(b);
  // buttons (pause / training menu)
  Btn(1190,14,76,36,b.paused?'PLAY':'II',()=>togglePause(),{f:'bold 18px Georgia'});
  if(b.train)Btn(1098,14,84,36,'MENU',()=>{b.panel=!b.panel;},{f:'bold 16px Georgia'});
  if(b.train&&b.panel)drawTrainPanel(b);
  if(b.paused)drawPause();
  if(b.phase==='finish')drawFinish();
  if(b.phase==='ultcut')drawUltCut();
  if(b.phase==='end')drawBattleEnd(b);
}
function drawAnnounce(){
  if(!announce)return;
  const k=Math.min(1,announce.t/.3,(1.4-announce.t)/.2+1);
  ctx.save();ctx.globalAlpha=Math.max(0,Math.min(1,k));
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.font='bold 84px Georgia';
  ctx.lineWidth=8;ctx.strokeStyle=OUT;ctx.strokeText(announce.txt,640,300);
  ctx.fillStyle='#ffd27a';ctx.fillText(announce.txt,640,300);
  ctx.restore();
}
function hudPanel(f,x,y,label){
  ctx.save();
  ctx.fillStyle='rgba(10,6,16,.6)';rr(x,y,440,88,12);ctx.fill();
  ctx.strokeStyle='rgba(255,180,100,.5)';ctx.lineWidth=2;ctx.stroke();
  ctx.fillStyle='#ffe2b8';ctx.font='bold 17px Georgia';ctx.textAlign='left';ctx.textBaseline='middle';
  ctx.fillText(label+'  '+f.c.n,x+12,y+14);
  const hf=clamp(f.hp/f.max,0,1);
  ctx.fillStyle='#2a0a10';rr(x+12,y+30,416,18,6);ctx.fill();
  const hg=ctx.createLinearGradient(x,0,x+420,0);
  hg.addColorStop(0,hf>.5?'#4fe08a':hf>.25?'#ffd24a':'#ff4a4a');hg.addColorStop(1,hf>.5?'#2aa860':hf>.25?'#ff9a20':'#a01030');
  ctx.fillStyle=hg;rr(x+12,y+30,Math.max(0,416*hf),18,6);ctx.fill();
  ctx.fillStyle='#fff';ctx.font='bold 12px Georgia';ctx.textAlign='right';
  ctx.fillText(Math.ceil(f.hp)+' / '+f.max,x+424,y+39);
  ctx.textAlign='left';
  ctx.fillStyle='#1a2a3a';rr(x+12,y+56,416,10,5);ctx.fill();
  ctx.fillStyle='#4fb3ff';rr(x+12,y+56,416*clamp(f.breath/100,0,1),10,5);ctx.fill();
  ctx.fillStyle='#2a2010';rr(x+12,y+72,416,8,4);ctx.fill();
  ctx.fillStyle=f.ult>=100?'#ffe066':'#c89a30';rr(x+12,y+72,416*clamp(f.ult/100,0,1),8,4);ctx.fill();
  ctx.restore();
}
function drawHUD(b){
  hudPanel(b.p1,24,18,'YOU');
  hudPanel(b.p2,W-24-440,18,'ENEMY');
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';
  if(b.train){ctx.fillStyle='#ffe2b8';ctx.font='bold 22px Georgia';ctx.fillText('TRAINING',640,60);}
  else{
    ctx.fillStyle='#fff';ctx.font='bold 46px Georgia';ctx.fillText(Math.max(0,Math.ceil(b.time)),640,58);
    ctx.font='14px Georgia';ctx.fillStyle='#ffe2b8';
    ctx.fillText('Round '+b.round+'  |  '+b.wins[0]+' - '+b.wins[1],640,86);
  }
  ctx.restore();
  if(b.p1.combo>=2){
    ctx.save();ctx.fillStyle='#ffd24a';ctx.font='bold 28px Georgia';ctx.textAlign='left';
    ctx.fillText(b.p1.combo+' HITS',30,150);ctx.restore();
  }
  if(b.p2.combo>=2){
    ctx.save();ctx.fillStyle='#ff8a8a';ctx.font='bold 28px Georgia';ctx.textAlign='right';
    ctx.fillText(b.p2.combo+' HITS',W-30,150);ctx.restore();
  }
}
function layout(){
  const m=save.lh?1:0;
  const X=x=>m?W-x:x;
  const s=save.btnScale;
  const B=(k,x,y,r,lab)=>({k:k,x:X(x),y:y,r:r*s,lab:lab});
  const ov=save.layout||{};
  const L={
    joy:{x:X(150),y:600,r:88*save.joyScale},
    btns:[B('light',1190,622,50,'ATK'),B('heavy',1078,640,42,'HVY'),B('s1',1196,498,40,'S1'),B('s2',1076,520,40,'S2'),
      B('ult',1250,380,44,'ULT'),B('block',958,640,38,'BLK'),B('dash',930,545,34,'DASH'),B('jump',1000,465,38,'JUMP')]
  };
  if(ov.joy){L.joy.x=ov.joy.x;L.joy.y=ov.joy.y;}
  for(const bt of L.btns){if(ov[bt.k]){bt.x=ov[bt.k].x;bt.y=ov[bt.k].y;}}
  return L;
}
function drawControls(b){
  const L=layout(),p=b.p1,a=save.opacity;
  ctx.save();ctx.globalAlpha=a;
  ctx.beginPath();ctx.arc(L.joy.x,L.joy.y,L.joy.r,0,6.2832);
  ctx.fillStyle='rgba(20,10,30,.45)';ctx.fill();
  ctx.strokeStyle='rgba(255,190,120,.7)';ctx.lineWidth=3;ctx.stroke();
  const kx=L.joy.x+joyX*L.joy.r*.6,ky=L.joy.y+joyY*L.joy.r*.6;
  ctx.beginPath();ctx.arc(kx,ky,L.joy.r*.36,0,6.2832);ctx.fillStyle='rgba(255,170,90,.6)';ctx.fill();
  ctx.textAlign='center';ctx.textBaseline='middle';
  for(const bt of L.btns){
    ctx.beginPath();ctx.arc(bt.x,bt.y,bt.r,0,6.2832);
    ctx.fillStyle='rgba(30,12,30,.55)';ctx.fill();
    ctx.strokeStyle=p.c.fx;ctx.lineWidth=3;ctx.stroke();
    ctx.fillStyle='#fff1dc';ctx.font='bold '+Math.round(bt.r*.4)+'px Georgia';
    ctx.fillText(bt.lab,bt.x,bt.y);
    let frac=0;
    if(bt.k==='s1'||bt.k==='s2'||bt.k==='ult')frac=clamp(p.cd[bt.k]/MOVES[bt.k].cd,0,1);
    if(frac>0){
      ctx.beginPath();ctx.moveTo(bt.x,bt.y);ctx.arc(bt.x,bt.y,bt.r,-Math.PI/2,-Math.PI/2+6.2832*frac);ctx.closePath();
      ctx.fillStyle='rgba(0,0,0,.6)';ctx.fill();
    }
    if(bt.k==='ult'){
      ctx.beginPath();ctx.arc(bt.x,bt.y,bt.r+5,-Math.PI/2,-Math.PI/2+6.2832*(p.ult/100));
      ctx.strokeStyle='#ffd24a';ctx.lineWidth=4;ctx.stroke();
    }
    if(bt.k==='s1'||bt.k==='s2'){
      ctx.fillStyle='#ffe2b8';ctx.font='bold 11px Georgia';
      ctx.fillText((bt.k==='s1'?p.c.s1:p.c.s2).slice(0,16),bt.x,bt.y+bt.r+10);
    }
  }
  ctx.restore();
}
function drawTrainPanel(b){
  ctx.save();
  ctx.fillStyle='rgba(12,6,20,.9)';rr(860,150,400,420,14);ctx.fill();
  ctx.strokeStyle='#ffb36b';ctx.lineWidth=2;ctx.stroke();
  ctx.fillStyle='#ffe2b8';ctx.font='bold 22px Georgia';ctx.textAlign='center';
  ctx.fillText('TRAINING MENU',1060,176);
  ctx.restore();
  const rowY=[206,256,306,356,406];
  Btn(900,rowY[0],320,40,'Bot: '+['Stationary','Defensive','Aggressive'][trainCfg.bot],()=>{
    trainCfg.bot=(trainCfg.bot+1)%3;
    b.p2.dummy=trainCfg.bot===0;
    b.p2.ai=trainCfg.bot===0?null:makeAI(TRAIN_BOTS[trainCfg.bot]);
  });
  Btn(900,rowY[1],320,40,'Infinite HP: '+(trainCfg.inf?'ON':'OFF'),()=>{trainCfg.inf=trainCfg.inf?0:1;});
  Btn(900,rowY[2],320,40,'Unlimited Meters: '+(trainCfg.meters?'ON':'OFF'),()=>{
    trainCfg.meters=trainCfg.meters?0:1;b.p1.infinite=!!trainCfg.meters;
  });
  Btn(900,rowY[3],150,40,'Reset Dummy',()=>{b.p2.hp=b.p2.max;b.p2.dead=false;},{f:'bold 15px Georgia'});
  Btn(1070,rowY[3],150,40,'Reset Cooldown',()=>{b.p1.cd={s1:0,s2:0,dash:0,ult:0};},{f:'bold 15px Georgia'});
  Btn(900,rowY[4],150,40,'Reset Spots',()=>{resetRound(b);b.phase='fight';},{f:'bold 15px Georgia'});
  Btn(1070,rowY[4],150,40,'Exit',()=>{goto('menu');},{f:'bold 15px Georgia'});
  ctx.save();
  ctx.fillStyle='#ffe2b8';ctx.font='bold 17px Georgia';ctx.textAlign='left';
  ctx.fillText('Total Damage: '+b.p1.dealt,900,470);
  ctx.fillText('Current Combo: '+b.p1.combo,900,496);
  ctx.fillText('Best Combo: '+(b.p1.maxCombo||0),900,522);
  ctx.restore();
  Btn(900,540,320,40,'Close Menu',()=>{b.panel=false;});
}
function drawPause(){
  ctx.save();
  ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(0,0,W,H);
  ctx.fillStyle='#ffd27a';ctx.font='bold 56px Georgia';ctx.textAlign='center';
  ctx.fillText('PAUSED',640,220);
  ctx.restore();
  Btn(540,280,200,50,'RESUME',()=>togglePause());
  Btn(540,350,200,50,'RESTART',()=>{if(battle)startBattle(battle.cfg);});
  Btn(540,420,200,50,'QUIT',()=>goto('menu'));
}
function drawBattleEnd(b){
  ctx.save();
  ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(0,0,W,H);
  ctx.fillStyle='rgba(14,6,20,.94)';rr(340,180,600,340,18);ctx.fill();
  ctx.strokeStyle='#ffb36b';ctx.lineWidth=3;ctx.stroke();
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillStyle=b.win?'#ffd24a':'#ff5a5a';
  ctx.font='bold 60px Georgia';ctx.fillText(b.win?'VICTORY':'DEFEAT',640,240);
  ctx.fillStyle='#ffe2b8';ctx.font='20px Georgia';
  ctx.fillText(b.reward||(b.win?'Victory':'Better luck next time'),640,296);
  ctx.restore();
  const back=b.mode==='story'?'story':b.mode==='offline'?'offline':b.mode==='quick'?'quick':'menu';
  Btn(380,350,160,50,'REMATCH',()=>{if(battle)startBattle(battle.cfg);});
  Btn(560,350,160,50,'CONTINUE',()=>{if(b.mode==='story'&&b.win)goto('cutscene',{idx:b.cfg.idx});else goto(back);});
  Btn(740,350,160,50,'MENU',()=>goto('menu'));
}
function togglePause(){
  if(scene!=='battle'||!battle||battle.phase==='end')return;
  battle.paused=!battle.paused;
}
