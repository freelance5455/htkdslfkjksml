/* ---------- COMBAT FX ---------- */
let slashes=[],rings=[],ghosts=[];
function ringFx(x,y,col,r,life){rings.push({x:x,y:y,col:col,r0:r*.25,r1:r,life:life,max:life});}
function slashFx(f){
  const k=f.atk?f.atk.k:'light',c=f.atk&&f.atk.m.col==='fx2'?f.c.fx2:f.c.fx;
  const S={light:[-2.5,.8,95,7],heavy:[-2.9,.6,110,11],s1:[1.3,-1.7,100,8,true],s2:[-.2,2.2,105,9],ult:[0,6.2,135,12]}[k]||[-2.5,.8,95,7];
  slashes.push({x:f.x,y:f.y,ox:f.J.hR.x,oy:f.J.hR.y,face:f.facing,a0:S[0],a1:S[1],r:S[2],w:S[3],acw:!!S[4],c:c,life:.22,max:.22});
  if(TIER_FX[f.c.tier].slashes>1){const s0=slashes[slashes.length-1];slashes.push(Object.assign({},s0,{a0:s0.a0+.35,a1:s0.a1+.35,r:s0.r+14,life:.3,max:.3}));}
}
function atkFx(f){
  const a=f.atk,k=a.k;
  if(k==='ult'){
    if(a.t<.75)sigTick(f);
    if(a.t<.75&&Math.random()<.85)burst(f.x+rnd(-45,45),f.y-rnd(30,170),f.c.fx,2,180,'dot');
    if(Math.random()<.4)burst(f.x,f.y-100,f.c.fx2,1,300,'spark');
  }else if(k!=='light'&&Math.random()<.6){
    const t=f.J.tip;
    burst(f.x+t.x*f.facing,f.y+t.y,f.c.fx,1,220,'spark');
  }
}
function startFx(f,key){
  if(key!=='light')sigFx(f,key);
  if(key==='ult'){
    addText(f.x,GROUND-250,f.c.ul,f.c.fx,1);
    ringFx(f.x,f.y-90,f.c.fx,170,.7);
    burst(f.x,f.y-90,f.c.fx2,Math.round(36*TIER_FX[f.c.tier].n),460,'spark');
    burst(f.x,f.y-90,'#ffffff',14,240,'dot');
    sfx('ult');
  }else sfx(key==='light'||key==='s2'?'swing':key==='heavy'?'heavy':'wave');
}
function dashFx(f,back){
  ringFx(f.x,f.y-60,back?'#cfe8ff':'#ffffff',back?70:50,.25);
  burst(f.x,f.y-60,f.c.fx,10,220,'dot');
  sfx('dash');
}
function ghostTick(f,dt){
  if(Q().ps<1.4)return;
  f.gT=(f.gT||0)-dt;
  if(f.gT>0||!(f.atk||f.dsh>0))return;
  f.gT=.035;
  ghosts.push({x:f.x,y:f.y,facing:f.facing,J:f.J,c:f.c,t:f.t,lastMx:f.lastMx,life:.22,max:.22});
  if(ghosts.length>60)ghosts.shift();
}
function updateFxAll(dt){
  for(const list of [slashes,rings,ghosts]){
    for(let i=list.length-1;i>=0;i--){list[i].life-=dt;if(list[i].life<=0)list.splice(i,1);}
  }
  updateShapes(dt);
  if(scene==='intro')updateIntro(dt);
  if(scene==='cutscene')updateCut(dt);
  musicTick();
}
function drawGhosts(){
  if(!ghosts.length)return;
  for(const g of ghosts){
    ctx.save();ctx.globalAlpha=.32*(g.life/g.max);
    drawFighter({x:g.x,y:g.y,facing:g.facing,J:g.J,c:g.c,t:g.t,lastMx:g.lastMx},undefined,undefined,undefined);
    ctx.restore();
  }
}
function drawSlashes(){
  if(!slashes.length)return;
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.lineCap='round';
  for(const s of slashes){
    const k=s.life/s.max;
    ctx.save();
    ctx.translate(s.x+s.ox*s.face,s.y+s.oy);ctx.scale(s.face,1);
    ctx.strokeStyle=hexA(s.c,k);ctx.lineWidth=s.w*(.4+k);
    if(Q().glow){ctx.shadowColor=s.c;ctx.shadowBlur=16;}
    ctx.beginPath();ctx.arc(0,0,s.r,s.a0,s.a1,s.acw);ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
}
function drawRings(){
  if(!rings.length)return;
  ctx.save();ctx.globalCompositeOperation='lighter';
  for(const r of rings){
    const k=1-r.life/r.max,rad=r.r0+(r.r1-r.r0)*k;
    ctx.globalAlpha=Math.max(0,1-k);ctx.strokeStyle=r.col;ctx.lineWidth=2+6*(1-k);
    if(Q().glow){ctx.shadowColor=r.col;ctx.shadowBlur=18;}
    ctx.beginPath();ctx.ellipse(r.x,r.y,rad,rad*.35,0,0,6.2832);ctx.stroke();
  }
  ctx.restore();
}
