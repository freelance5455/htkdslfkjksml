
/* ---------- INPUT STATE ---------- */
const held={left:false,right:false,kbBlock:false,blockCnt:0};
const edge={jump:false,light:false,heavy:false,s1:false,s2:false,ult:false,dash:false};
let joyX=0,joyY=0,joyActive=false,joyBlock=false,joyLatch=false;
const ptrMap=new Map();
function readPlayerCmd(){
  const mx=clamp((held.right?1:0)-(held.left?1:0)+(joyActive?joyX:0),-1,1);
  const c={mx:mx,block:held.kbBlock||held.blockCnt>0||joyBlock,jump:edge.jump,light:edge.light,heavy:edge.heavy,s1:edge.s1,s2:edge.s2,ult:edge.ult,dash:edge.dash};
  for(const k in edge)edge[k]=false;
  return c;
}

/* ---------- AI ---------- */
function aiThink(f,opp,dt){
  const a=f.ai,d=a.d,c={};
  const dist=Math.abs(opp.x-f.x),tw=opp.x>f.x?1:-1;
  a.tm-=dt;a.mist-=dt;a.blockT-=dt;
  if(opp.atk&&dist<200&&Math.random()<d.block*dt*5)a.blockT=.3+Math.random()*.25;
  c.block=a.blockT>0;
  if(a.mist>0){c.mx=0;return c;}
  if(opp.stun>0&&dist<170&&Math.random()<d.aggro*dt*5){c.light=true;if(d.aggro>.7)c.heavy=true;}
  if(a.tm<=0){
    a.tm=d.react*(.6+Math.random()*.8);
    if(Math.random()<d.mist){a.mist=.5;return c;}
    a.mv=dist>230?tw:dist<110?-tw*.6:(Math.random()<.5?0:tw*.3);
    if(dist<160&&Math.random()<d.aggro){
      const r=Math.random();
      if(r<.45)c.light=true;
      else if(r<.7)c.heavy=true;
      else if(r<.85&&f.cd.s1<=0&&f.breath>=25)c.s1=true;
      else if(r<.95&&f.cd.s2<=0&&f.breath>=20)c.s2=true;
      else c.light=true;
      if(f.ult>=100&&Math.random()<.35)c.ult=true;
    }
    if(f.ult>=100&&dist<300&&Math.random()<.4)c.ult=true;
    if(dist>300&&Math.random()<.05)c.dash=true;
    if(dist<130&&Math.random()<.03){c.dash=true;a.mv=-tw;}
    if(Math.random()<.06)c.jump=true;
  }
  c.mx=a.mv;
  return c;
}

/* ---------- COMBAT ---------- */
function startAtk(f,key){
  const m=MOVES[key],c=f.c;
  if(!canAct(f))return false;
  if(m.cost&&f.breath<m.cost&&!f.infinite)return false;
  if(m.cd&&f.cd[key]>0)return false;
  if(m.ult){if(f.ult<100&&!f.infinite)return false;if(!f.infinite)f.ult=0;}
  if(m.cost&&!f.infinite)f.breath-=m.cost;
  if(m.cd)f.cd[key]=m.cd;
  const hits=m.hits.map(h=>Object.assign({},h));
  if(key==='light'&&c.lh===2)hits.push({t:.2,r:120,dm:6,kb:90,st:.16});
  f.atk={k:key,m:m,t:0,hits:hits,done:hits.map(()=>false),waved:false};
  startFx(f,key);
  if(key==='ult'&&battle&&battle.phase==='fight'&&(f===battle.p1||(f===battle.p2&&!battle.train)))startUltCut(battle,f.id,f===battle.p2);
  return true;
}
function updateAtk(f,dt,opp){
  const a=f.atk,m=a.m;
  a.t+=dt;
  atkFx(f);
  if(m.lunge&&a.t>=m.lunge[0]&&a.t<=m.lunge[1])f.x+=f.facing*m.lunge[2]*dt;
  if(m.wave&&!a.waved&&a.t>=m.wave){a.waved=true;spawnWave(f,opp);}
  for(let i=0;i<a.hits.length;i++){
    const h=a.hits[i];
    if(!a.done[i]&&a.t>=h.t){
      a.done[i]=true;
      slashFx(f);
      const inRange=Math.abs(opp.x-f.x)<=h.r*f.c.rm&&(opp.x-f.x)*f.facing>-30;
      if(inRange&&!opp.dead&&opp.inv<=0)applyHit(f,opp,h,!!m.big,f.facing);
    }
  }
  if(m.tr&&f.J){
    const tp=f.J.tip;
    f.trail.push({x:f.x+tp.x*f.facing,y:f.y+tp.y,c:m.col==='fx2'?f.c.fx2:f.c.fx,w:m.tr});
    while(f.trail.length>Q().trail)f.trail.shift();
  }
  if(a.t>=m.dur)f.atk=null;
}
function applyHit(a,b,h,big,sgn){
  const blocked=b.blk&&b.facing===-sgn;
  const dm=h.dm*a.c.dm;
  const dmg=Math.max(1,Math.round(dm*(blocked?.2:1)));
  b.hp-=dmg;
  a.dealt+=dmg;
  if(blocked){
    b.breath=Math.max(0,b.breath-dm*2.5);
    addText(b.x,b.y-170,'BLOCK',"#8fd8ff",.8);
    burst(b.x-sgn*20,b.y-100,'#8fd8ff',10,260,'spark');
    sfx('block');
    hitStop=Math.max(hitStop,.03);
    shake=Math.max(shake,3*Q().shake);
  }else{
    b.stun=Math.max(b.stun,h.st);
    b.kx=sgn*h.kb;
    b.flash=1;
    a.combo++;a.comboT=1.6;
    if(a.combo>(a.maxCombo||0))a.maxCombo=a.combo;
    a.ult=Math.min(100,a.ult+dm*.9);
    b.ult=Math.min(100,b.ult+dm*.45);
    sfx(big?'big':'hit');
    burst(b.x-sgn*15,b.y-100,a.c.fx,big?26:14,big?520:340,'spark');
    burst(b.x,b.y-100,'#ffffff',big?8:4,200,'dot');
    addText(b.x+rnd(-10,10),b.y-190,'-'+dmg,big?'#ffd860':'#ffffff',big?1.2:.8);
    hitStop=Math.max(hitStop,big?.09:.05);
    shake=Math.max(shake,(big?14:6)*Q().shake);
    if(big){flashA=Math.max(flashA,.35);ringFx(b.x,b.y-100,a.c.fx,190,.45);}
  }
  if(b.hp<0)b.hp=0;
}
function spawnWave(f,opp){
  const c=f.c;
  waves.push({x:f.x+f.facing*50,y:GROUND-95,vx:f.facing*c.ws,col:c.wc,style:c.wt,life:1.6,owner:f,target:opp,face:f.facing,hit:false});
}
function updateWaves(dt){
  for(let i=waves.length-1;i>=0;i--){
    const w=waves[i];
    w.x+=w.vx*dt;w.life-=dt;
    const t=w.target;
    if(!w.hit&&!t.dead&&t.inv<=0&&Math.abs(t.x-w.x)<42){
      w.hit=true;
      applyHit(w.owner,t,{dm:10,st:.2,kb:160},false,w.face);
    }
    if(w.life<=0||w.hit||w.x<-60||w.x>W+60)waves.splice(i,1);
  }
}
function drawWaves(){
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.lineCap='round';
  for(const w of waves){
    ctx.save();ctx.translate(w.x,w.y);ctx.scale(w.face,1);
    ctx.strokeStyle=w.col;ctx.lineWidth=7;
    if(Q().glow){ctx.shadowColor=w.col;ctx.shadowBlur=18;}
    ctx.beginPath();
    if(w.style==='thread'){
      for(let k=0;k<3;k++){ctx.moveTo(-60,-40+k*20);ctx.quadraticCurveTo(-30,-30+k*20+Math.sin(w.life*10+k)*8,0,-40+k*20);}
    }else if(w.style==='gale'){
      for(let k=0;k<3;k++){ctx.arc(0,0,30+k*12,-1.1,1.1);}
    }else{
      ctx.arc(0,0,40,-1.2,1.2);
    }
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
}
function updateFighter(f,dt,cmd,opp){
  f.t+=dt;
  f.flash=Math.max(0,f.flash-dt*4);
  for(const k in f.cd)if(f.cd[k]>0)f.cd[k]-=dt;
  if(f.comboT>0)f.comboT-=dt;else f.combo=0;
  if(f.inv>0)f.inv-=dt;
  if(f.stun>0)f.stun-=dt;
  if(f.gb>0)f.gb-=dt;
  if(f.dead){
    f.blk=false;f.atk=null;f.dsh=0;
    f.kx*=Math.pow(.02,dt);f.x+=f.kx*dt;
    f.x=clamp(f.x,40,W-40);
    computePose(f,dt);
    return;
  }
  if(!f.atk&&!f.blk)f.breath=Math.min(100,f.breath+14*dt);
  if(f.infinite){f.breath=100;f.ult=100;}
  f.blk=!!cmd.block&&f.onG&&!f.atk&&f.stun<=0&&f.gb<=0;
  if(f.blk){f.breath-=12*dt;if(f.breath<=0){f.breath=0;f.blk=false;f.gb=1.1;}}
  if(cmd.dash&&f.cd.dash<=0&&f.breath>=15&&!f.atk&&f.stun<=0&&f.gb<=0){
    const back=(cmd.mx||0)*f.facing<-.3;
    if(!f.infinite)f.breath-=back?12:15;
    f.cd.dash=back?.7:.85;f.dsh=back?.22:.18;f.inv=back?.32:.2;
    f.dsd=back?-f.facing:f.facing;f.dsSpd=back?640:760;
    dashFx(f,back);
  }
  let mx=clamp(cmd.mx||0,-1,1);
  if(f.atk||f.stun>0)mx=0;else if(f.blk)mx*=.4;
  if(f.dsh>0){f.dsh-=dt;f.x+=(f.dsd||f.facing)*(f.dsSpd||760)*dt;}
  else f.x+=mx*f.c.sp*(f.ai?f.ai.d.spd:1)*dt;
  f.lastMx=mx;
  f.x+=f.kx*dt;f.kx*=Math.pow(.01,dt);
  if(cmd.jump&&f.onG&&!f.atk&&f.stun<=0&&!f.blk){f.vy=-980;f.onG=false;}
  if(!f.onG){f.vy+=GRAV*dt;f.y+=f.vy*dt;if(f.y>=GROUND){f.y=GROUND;f.vy=0;f.onG=true;}}
  f.x=clamp(f.x,40,W-40);
  if(!f.atk&&f.stun<=0&&!f.blk&&Math.abs(opp.x-f.x)>4)f.facing=opp.x>f.x?1:-1;
  if(canAct(f)){
    if(cmd.light)startAtk(f,'light');
    else if(cmd.heavy)startAtk(f,'heavy');
    else if(cmd.s1)startAtk(f,'s1');
    else if(cmd.s2)startAtk(f,'s2');
    else if(cmd.ult)startAtk(f,'ult');
  }
  if(f.atk)updateAtk(f,dt,opp);
  if(!f.atk&&f.trail.length)f.trail.shift();
  computePose(f,dt);
  ghostTick(f,dt);
}
function separation(a,b){
  const d=b.x-a.x,m=50;
  if(Math.abs(d)<m){const push=(m-Math.abs(d))/2,sg=d>=0?1:-1;a.x-=sg*push;b.x+=sg*push;}
}

/* ---------- BATTLE FLOW ---------- */
let battle=null;
let trainCfg={bot:0,inf:0,meters:0};
function resetRound(b){
  const fs=[b.p1,b.p2];
  b.p1.x=260;b.p2.x=980;
  for(const f of fs){
    f.hp=f.max;f.breath=100;f.ult=0;f.dead=false;f.atk=null;f.stun=0;f.kx=0;f.dsh=0;
    f.onG=true;f.y=GROUND;f.vy=0;f.blk=false;f.gb=0;f.trail=[];f.flash=0;f.combo=0;
    f.cd={s1:0,s2:0,dash:0,ult:0};
    if(f.ai){f.ai.tm=0;f.ai.blockT=0;f.ai.mist=0;}
  }
  b.p1.facing=1;b.p2.facing=-1;
  b.time=200;
  waves=[];
}
function startBattle(cfg){
  const train=cfg.mode==='training';
  const pid=cfg.p||sel;
  const online=cfg.mode==='online',side=online?(cfg.side||0):0;
  const p1=online?makeF(pid,side===0?260:980,side===0?1:-1,null,'normal',1):makeF(pid,260,1,null,'normal',1);
  p1.infinite=!!(train&&trainCfg.meters);
  let p2;
  if(train){
    p2=makeF(cfg.e||'rui',980,-1,null,'normal',1);
    p2.dummy=trainCfg.bot===0;
    p2.ai=trainCfg.bot===0?null:makeAI(TRAIN_BOTS[trainCfg.bot]);
  }else{
    const dk=cfg.diff||'normal';
    p2=online?makeF(cfg.e,side===0?980:260,side===0?-1:1,null,'normal',1):makeF(cfg.e,980,-1,true,dk,1,DIFF[dk].hp);
  }
  if(online){p2.ai=null;lockReset();}
  battle={cfg:cfg,mode:cfg.mode,train:train,p1:p1,p2:p2,arena:ARENAS[cfg.arena||0],
    map:mapFor(cfg),
    rounds:cfg.rounds||1,wins:[0,0],round:1,phase:'intro',introT:1.6,time:200,t:0,koT:0,
    paused:false,panel:false,win:null,reward:'',line:cfg.line||null,koLoser:null};
  announce={txt:train?'TRAINING':'ROUND 1',t:1.4};
  waves=[];parts=[];texts=[];
  scene='battle';
}
function killFighter(f,b){
  f.dead=true;f.hp=0;f.atk=null;f.stun=2;f.blk=false;
  b.phase='ko';b.koT=2.4;b.koLoser=f===b.p1?0:1;
  announce={txt:'K.O.',t:1.8};
  sfx('ko');
  slow=1.2;flashA=.5;shake=Math.max(shake,16*Q().shake);
  burst(f.x,f.y-90,'#ff4a4a',30,600,'spark');
}
function endRound(b){
  if(b.koLoser===0)b.wins[1]++;else b.wins[0]++;
  const need=b.rounds===1?1:2;
  if(b.wins[0]>=need||b.wins[1]>=need){
    b.phase='end';b.win=b.wins[0]>=need;
    finishBattle(b);
    if(b.win&&b.koLoser===1&&!b.train){b.phase='finish';startFinish(b);}
    return;
  }
  b.round++;resetRound(b);
  b.phase='intro';b.introT=1.6;
  announce={txt:'ROUND '+b.round,t:1.4};
}
function timeUp(b){
  const r1=b.p1.hp/b.p1.max,r2=b.p2.hp/b.p2.max;
  if(Math.abs(r1-r2)<.001){resetRound(b);b.phase='intro';b.introT=1.2;announce={txt:'DRAW',t:1.2};return;}
  killFighter(r1>r2?b.p2:b.p1,b);
}
function finishBattle(b){
  const cfg=b.cfg,win=b.win;
  let rew='';
  if(b.mode==='offline'){
    if(win){const r=DIFF[cfg.diff].rew;save.coins+=r;rew='+'+r+' Demon Coins';}
  }else if(b.mode==='story'){
    if(win){
      const idx=cfg.idx,st=STORY[idx];
      const base=idx===save.story?200+idx*40:50;
      let bonus=0;
      if(!save.bossWins[st.e]){bonus=idx<6?500:(st.e==='muzan'?2500:1000);save.bossWins[st.e]=1;}
      if(idx===save.story)save.story++;
      save.coins+=base+bonus;
      rew='+'+(base+bonus)+' Demon Coins'+(bonus?' (first victory bonus!)':'');
    }
  }
  b.reward=rew;
  persist();
}
function updateBattle(dt){
  const b=battle;if(!b||b.paused)return;
  b.t+=dt;
  let fdt=dt;
  if(hitStop>0){hitStop-=dt;fdt=0;}
  else if(slow>0){slow-=dt;fdt=dt*.35;}
  const p1=b.p1,p2=b.p2;
  const online=b.mode==='online';
  const pc=online?lockLocalCmd():readPlayerCmd();
  let ec={};
  if(b.phase==='fight'&&p2.ai&&!p2.dead)ec=aiThink(p2,p1,fdt);
  else if(online&&!p2.dead)ec=lockRemoteCmd();
  if(online&&b.phase==='end'&&!b.netReported){b.netReported=true;netSend({t:'result',won:!!b.win});}
  if(b.phase==='intro'){
    b.introT-=dt;
    if(b.introT<=0){b.phase='fight';announce={txt:'FIGHT!',t:.9};}
  }
  if(b.phase==='fight'||b.phase==='intro'||b.phase==='ko'){
    const live=b.phase==='fight';
    const swap=online&&net.match&&net.match.side===1;
    const A=swap?p2:p1,Ac=swap?ec:pc,B=swap?p1:p2,Bc=swap?pc:ec;
    updateFighter(A,fdt,live?Ac:{},B);
    updateFighter(B,fdt,live?Bc:{},A);
    separation(p1,p2);
    updateWaves(fdt);
  }
  if(b.phase==='fight'){
    if(!b.train){
      b.time-=fdt;
      if(b.time<=0)timeUp(b);
    }
    if(!b.train){
      if(p1.hp<=0&&b.phase==='fight')killFighter(p1,b);
      else if(p2.hp<=0&&b.phase==='fight')killFighter(p2,b);
    }
  }else if(b.phase==='ko'){
    b.koT-=dt;
    if(b.koT<=0)endRound(b);
  }
  if(b.train){
    if(trainCfg.inf)p1.hp=p1.max;
    if(p1.hp<=0){p1.hp=p1.max;p1.stun=0;addText(p1.x,p1.y-200,'RESET','#9fe8ff',1);}
    if(p2.hp<=0){p2.hp=p2.max;p2.dead=false;addText(p2.x,p2.y-200,'RESET','#9fe8ff',1);}
    if(p1.infinite){p1.breath=100;p1.ult=100;}
  }
  if(b.phase==='finish')updateFinish(dt);
  if(b.phase==='ultcut')updateUltCut(dt);
  if(b.phase==='end'&&b.mode==='story'&&b.win&&!trans){b.endT=(b.endT||0)+dt;if(b.endT>3.2)goto('cutscene',{idx:b.cfg.idx});}
  if(announce){announce.t-=dt;if(announce.t<=0)announce=null;}
}
let shake=0,flashA=0,hitStop=0,slow=0,announce=null;
