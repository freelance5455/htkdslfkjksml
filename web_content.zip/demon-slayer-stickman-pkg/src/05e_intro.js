/* ---------- INTRO (title sequence) ---------- */
let introT=0;
function easeOutBack(x){const c1=1.70158,c3=c1+1;return 1+c3*Math.pow(x-1,3)+c1*Math.pow(x-1,2);}
function easeOutCubic(x){return 1-Math.pow(1-x,3);}
function popText(str,cx,cy,size,fill,stroke,t0,step){
  ctx.save();
  ctx.font='bold '+size+'px Impact, "Arial Black", Georgia';
  ctx.textBaseline='middle';ctx.textAlign='left';ctx.lineJoin='round';
  const chars=[...str],ws=chars.map(ch=>ctx.measureText(ch).width);
  const total=ws.reduce((a,b)=>a+b,0);
  let x=cx-total/2;
  chars.forEach((ch,i)=>{
    const p=clamp((introT-t0-i*step)/.35,0,1);
    if(p>0){
      const s=easeOutBack(p);
      ctx.save();
      ctx.translate(x+ws[i]/2,cy);ctx.scale(s,s);
      ctx.lineWidth=size*.1;ctx.strokeStyle=stroke;ctx.strokeText(ch,-ws[i]/2,0);
      ctx.fillStyle=fill;ctx.fillText(ch,-ws[i]/2,0);
      ctx.restore();
    }
    x+=ws[i];
  });
  ctx.restore();
}
function drawIntro(){
  const t=introT;
  const g=ctx.createLinearGradient(0,0,0,H);
  g.addColorStop(0,'#14020a');g.addColorStop(.55,'#4a0a14');g.addColorStop(1,'#0a0204');
  ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  ctx.save();ctx.globalAlpha=.1;ctx.fillStyle='#ff4a4a';
  for(let i=0;i<18;i++){const a=i*Math.PI*2/18+t*.05;ctx.beginPath();ctx.moveTo(640,300);ctx.lineTo(640+Math.cos(a)*1400,300+Math.sin(a)*1400);ctx.lineTo(640+Math.cos(a+.08)*1400,300+Math.sin(a+.08)*1400);ctx.closePath();ctx.fill();}
  ctx.restore();
  const mp=easeOutCubic(clamp((t-.1)/1,0,1));
  const mx=640,my=240;
  ctx.save();
  const mg=ctx.createRadialGradient(mx,my,80,mx,my,460);
  mg.addColorStop(0,'rgba(255,70,70,.55)');mg.addColorStop(1,'rgba(255,40,60,0)');
  ctx.globalAlpha=mp;ctx.fillStyle=mg;ctx.fillRect(0,0,W,H);
  const moonG=ctx.createRadialGradient(mx-50,my-60,20,mx,my,200);
  moonG.addColorStop(0,'#fff4f2');moonG.addColorStop(.45,'#ff6a6a');moonG.addColorStop(1,'#b8141e');
  ctx.beginPath();ctx.arc(mx,my,200*mp,0,6.2832);ctx.fillStyle=moonG;ctx.fill();
  ctx.fillStyle='rgba(120,20,30,.25)';
  for(const [cx,cy,r] of [[600,200,26],[690,270,18],[650,300,30],[610,260,12]]){ctx.beginPath();ctx.arc(cx,cy,r*mp,0,6.2832);ctx.fill();}
  ctx.restore();
  ctx.fillStyle='#07020a';
  for(let i=0;i<16;i++){
    const x=i*90-30+(i%2)*14,h=130+(i*41)%120;
    ctx.beginPath();ctx.moveTo(x,H);ctx.lineTo(x+46,H-h);ctx.lineTo(x+92,H);ctx.closePath();ctx.fill();
  }
  const ra=easeOutCubic(clamp((t-.8)/1.3,0,1));
  if(ra>0){
    ctx.save();ctx.strokeStyle='#e0141e';ctx.lineWidth=34;ctx.lineCap='round';
    ctx.beginPath();ctx.arc(640,440,262,-Math.PI*.9,-Math.PI*.9+Math.PI*2*ra);ctx.stroke();
    ctx.restore();
  }
  const cast=[
    {id:'nezuko',x:150,y:300,sc:1.5,face:1,from:-700,delay:.25},
    {id:'shinobu',x:360,y:300,sc:1.5,face:1,from:-700,delay:.3},
    {id:'kokushibo',x:920,y:300,sc:1.5,face:-1,from:700,delay:.3},
    {id:'muichiro',x:1130,y:300,sc:1.5,face:-1,from:700,delay:.35},
    {id:'zenitsu',x:200,y:560,sc:2.3,face:1,from:-700,delay:.5},
    {id:'rengoku',x:430,y:580,sc:1.9,face:1,from:-700,delay:.45},
    {id:'tanjiro',x:640,y:540,sc:2.9,face:1,from:0,delay:.2},
    {id:'giyu',x:850,y:580,sc:1.9,face:-1,from:700,delay:.45},
    {id:'inosuke',x:1085,y:560,sc:2.3,face:-1,from:700,delay:.6}
  ];
  for(const c of cast){
    const p=clamp((t-c.delay)/.7,0,1);
    if(p<=0)continue;
    const e=easeOutBack(p);
    const x=c.x+c.from*(1-easeOutCubic(p));
    const y=c.y+(c.from===0?260*(1-easeOutCubic(p)):0);
    const sc=Math.max(.05,c.sc*e);
    ctx.save();
    const aura=ctx.createRadialGradient(x,y-120*sc,10,x,y-120*sc,190*sc);
    aura.addColorStop(0,hexA(CH[c.id].fx,.45*p));aura.addColorStop(1,hexA(CH[c.id].fx,0));
    ctx.fillStyle=aura;ctx.fillRect(x-220*sc,y-330*sc,440*sc,380*sc);
    ctx.restore();
    drawPortrait(c.id,x,y,sc,c.face);
  }
  ctx.save();const sh=t>1.2&&t<2.2?(2.2-t)*7:0;ctx.translate(Math.sin(t*70)*sh,Math.cos(t*60)*sh);
  popText('DEMON',640,160,128,'#ffffff','#000000',1.0,.12);
  popText('SLAYER',640,284,128,'#e0141e','#000000',1.3,.1);
  ctx.restore();
  const sub=easeOutCubic(clamp((t-2.1)/.6,0,1));
  ctx.save();ctx.globalAlpha=clamp(sub*1.2,0,1);
  ctx.translate(0,(1-sub)*180);
  ctx.font='bold 44px Impact, "Arial Black", Georgia';ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.lineWidth=8;ctx.strokeStyle='#000';ctx.strokeText('PIXEL WAR',640,400);
  ctx.fillStyle='#ffc23a';ctx.fillText('PIXEL WAR',640,400);
  ctx.restore();
  ctx.save();ctx.strokeStyle='rgba(255,255,255,.18)';ctx.lineWidth=2;
  for(let i=0;i<12;i++){const x=(t*900+i*150)%(W+300)-150,y=40+i*50;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-120,y);ctx.stroke();}
  ctx.restore();
  for(let i=0;i<40;i++){
    const x=(i*137)%W,y=H-((t*70+i*53)%H);
    ctx.globalAlpha=.4+.4*Math.sin(t*3+i);
    ctx.fillStyle='#ffd27a';ctx.beginPath();ctx.arc(x,y,1.8,0,6.2832);ctx.fill();
  }
  ctx.globalAlpha=1;
  const cr=easeOutCubic(clamp((t-2.8)/.6,0,1));
  if(cr>0){
    ctx.save();ctx.globalAlpha=cr;
    ctx.fillStyle='rgba(10,4,12,.7)';rr(430,428,420,38,10);ctx.fill();
    ctx.strokeStyle='#ffc23a';ctx.lineWidth=1.5;ctx.stroke();
    ctx.font='bold 17px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillStyle='#ffe2b8';ctx.fillText('MADE BY INFINITY FORGE STUDIO',640,447);
    ctx.restore();
  }
  if(t>3){
    ctx.save();ctx.globalAlpha=.5+.5*Math.sin(t*5);
    ctx.fillStyle='#fff1dc';ctx.font='bold 22px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillText('CLICK OR PRESS ANY KEY',640,690);
    ctx.restore();
  }
  btns.push({x:0,y:0,w:W,h:H,fn:introSkip});
}
function introSkip(){
  if(introT>.5&&!trans)goto(startScene());
}
function updateIntro(dt){
  introT+=dt;
  if(introT>9&&!trans)goto(startScene());
}
addEventListener('keydown',e=>{
  if(scene==='login')return;
  if(scene==='intro'&&introT>.5&&!trans){e.preventDefault();goto(startScene());}
});
