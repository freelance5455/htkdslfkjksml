const W=1280,H=720,GROUND=600,GRAV=2600;
const cv=document.getElementById('game'),ctx=cv.getContext('2d');
const DPR=Math.min(window.devicePixelRatio||1,2);
let rotView=false;
function resize(){
  rotView=innerHeight>innerWidth;
  const s=rotView?Math.min(innerWidth/H,innerHeight/W):Math.min(innerWidth/W,innerHeight/H);
  cv.style.width=(W*s)+'px';cv.style.height=(H*s)+'px';
  cv.style.transform=rotView?'translate(-50%,-50%) rotate(90deg)':'translate(-50%,-50%)';
  cv.width=Math.round(W*DPR);cv.height=Math.round(H*DPR);
  ctx.setTransform(cv.width/W,0,0,cv.height/H,0,0);
}
function viewScale(){return parseFloat(cv.style.width)/W;}
function toScreen(x,y){
  const r=cv.getBoundingClientRect(),cw=parseFloat(cv.style.width),ch=parseFloat(cv.style.height);
  const cx=r.left+r.width/2,cy=r.top+r.height/2;
  const lx=(x/W)*cw-cw/2,ly=(y/H)*ch-ch/2;
  return rotView?{x:cx-ly,y:cy+lx}:{x:cx+lx,y:cy+ly};
}
addEventListener('resize',resize);resize();

const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
const rnd=(a,b)=>a+Math.random()*(b-a);
const OUT='#0b0710';
function hexA(h,a){const n=parseInt(h.slice(1),16);return 'rgba('+(n>>16&255)+','+(n>>8&255)+','+(n&255)+','+a+')';}
function toL(e){
  const r=cv.getBoundingClientRect();
  if(!rotView)return{x:(e.clientX-r.left)/r.width*W,y:(e.clientY-r.top)/r.height*H};
  const cw=parseFloat(cv.style.width),ch=parseFloat(cv.style.height);
  const cx=r.left+r.width/2,cy=r.top+r.height/2;
  const sx=e.clientX-cx,sy=e.clientY-cy;
  return{x:(sy+cw/2)/cw*W,y:(-sx+ch/2)/ch*H};
}
function V(a,l){return{x:Math.sin(a)*l,y:Math.cos(a)*l};}
function P(a,b){return{x:a.x+b.x,y:a.y+b.y};}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}

/* ---------- SAVE (local, with integrity hash) ---------- */
const SAVE_KEY='demon_slayer_stickman_v1';
const save={coins:0,unlocked:{tanjiro:1,zenitsu:1},story:0,bossWins:{},graphics:4,btnScale:1,joyScale:1,opacity:.85,lh:0,fps:0,sfx:1,music:1,map:-1};
const SAVE_DEFAULT=JSON.parse(JSON.stringify(save));
let saveOwner=null;
function saveKey(){return saveOwner?SAVE_KEY+':'+saveOwner.toLowerCase():SAVE_KEY;}
function setSaveOwner(name){
  saveOwner=name||null;
  Object.keys(save).forEach(k=>{delete save[k];});
  Object.assign(save,JSON.parse(JSON.stringify(SAVE_DEFAULT)));
  tamperWarn=false;loadSave();
}
let tamperWarn=false;
function hashStr(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return(h>>>0).toString(36);}
function persist(){const p=JSON.stringify(save);try{localStorage.setItem(saveKey(),JSON.stringify({p:p,h:hashStr(p)}));}catch(e){}}
function loadSave(){
  try{
    const raw=JSON.parse(localStorage.getItem(saveKey())||'null');
    if(!raw)return;
    if(hashStr(raw.p)!==raw.h){tamperWarn=true;return;}
    Object.assign(save,JSON.parse(raw.p));
  }catch(e){}
}
loadSave();
const Q=()=>QUAL[save.graphics]||QUAL[2];
const PM=()=>Q().ps;

/* ---------- DATA ---------- */
const QUAL=[
  {n:'LOW',pet:0,trail:6,glow:0,fog:0,max:140,ps:.4},
  {n:'MEDIUM',pet:16,trail:10,glow:0,fog:1,max:260,ps:.7},
  {n:'HIGH',pet:30,trail:14,glow:1,fog:1,max:420,ps:1},
  {n:'ULTRA',pet:55,trail:18,glow:1,fog:1,max:640,ps:1.4},
  {n:'MAX',pet:90,trail:26,glow:1,fog:1,max:900,ps:2}
];
const RAW={
  tanjiro:{n:'Tanjiro Kamado',b:'Water > Sun Breathing',p:0,hp:1000,sp:340,dm:1,hc:'#2b1a12',hs:'spiky',ho:'#1d6b4c',pt:'check',hk:'#2a2630',sk:'#f2cba4',ey:'#d9482b',bl:'#e9f3ff',fx:'#4fb3ff',fx2:'#ff7a2a',s1:'Water Surface Slash',s2:'Sun Dance: Flame Dance',ul:'Hinokami Kagura',wc:'#4fb3ff',ws:520,wt:'curve',st:.2},
  zenitsu:{n:'Zenitsu Agatsuma',b:'Thunder Breathing',p:0,hp:900,sp:420,dm:.95,hc:'#f2d25a',hs:'tuft',ho:'#e8c64a',pt:'tri',hk:'#8a6a20',sk:'#f2cba4',ey:'#f5e46a',bl:'#fff7b0',fx:'#ffe14d',fx2:'#ffffff',s1:'Thunderclap and Flash',s2:'Sixfold',ul:'Seventh Form: Honoikazuchi',wc:'#ffe14d',ws:900,wt:'wave',st:.15,rm:1.05},
  inosuke:{n:'Inosuke Hashibira',b:'Beast Breathing',p:1000,hp:1000,sp:380,dm:.9,hc:'#e8e0c8',hs:'mask',ho:'#7a8a3c',pt:'plain',hk:'#2a2a2a',sk:'#e6dcc0',ey:'#ffffff',bl:'#dbe8ff',fx:'#c8d8ff',fx2:'#ff5a7a',s1:'Crazy Cutting',s2:'Spatial Awareness',ul:'Fang of the Mountain King',wc:'#c8d8ff',ws:600,wt:'gale',st:.16,lh:2},
  obanai:{n:'Obanai Iguro',b:'Serpent Breathing',p:1500,hp:950,sp:390,dm:1,hc:'#15151d',hs:'bowl',ho:'#2b2b33',pt:'stripe',hk:'#3a1a2a',sk:'#f2cba4',ey:'#7ee07e',bl:'#d8ffd0',fx:'#7ee07e',fx2:'#2e9e4a',s1:'Winding Serpent Slash',s2:'Coil Choke',ul:'Slithering Serpent',wc:'#7ee07e',ws:440,wt:'curve',st:.3,rm:1.1},
  giyu:{n:'Giyu Tomioka',b:'Water Breathing',p:3000,hp:1100,sp:360,dm:1.05,hc:'#1d2430',hs:'bowl',ho:'#2a4a7a',pt:'check',hk:'#1a1f2a',sk:'#f2cba4',ey:'#4fb3ff',bl:'#dff0ff',fx:'#3fa0ff',fx2:'#9fe0ff',s1:'Water Surface Slash',s2:'Striking Tide',ul:'Dead Calm',wc:'#3fa0ff',ws:500,wt:'curve',st:.25},
  sanemi:{n:'Sanemi Shinazugawa',b:'Wind Breathing',p:3000,hp:1100,sp:400,dm:1.05,hc:'#eeeeee',hs:'spiky',ho:'#dcdcdc',pt:'plain',hk:'#2a2a2a',sk:'#f2cba4',ey:'#7cf07c',bl:'#e0ffe0',fx:'#6ff27a',fx2:'#c8ffb0',s1:'Dust Whirlwind Cutter',s2:'Gale-Sudden Gusts',ul:'Idaten Typhoon',wc:'#6ff27a',ws:620,wt:'gale',st:.2,sc:1},
  rengoku:{n:'Kyojuro Rengoku',b:'Flame Breathing',p:4000,hp:1200,sp:370,dm:1.15,hc:'#f5b642',hs:'spiky',ho:'#f29a1c',pt:'plain',hk:'#1c1c1c',sk:'#f2cba4',ey:'#ff7a1a',bl:'#fff0d0',fx:'#ff6a1a',fx2:'#ffb040',s1:'Rising Scorching Sun',s2:'Flame Tiger',ul:'Ninth Form: Rengoku',wc:'#ff6a1a',ws:560,wt:'wave',st:.3},
  mitsuri:{n:'Mitsuri Kanroji',b:'Love Breathing',p:3000,hp:1000,sp:390,dm:1.05,hc:'#ff7fb0',hs:'ponytail',ho:'#2b7a6a',pt:'plain',hk:'#ff8ac0',sk:'#f8d6c0',ey:'#ff7fc0',bl:'#ffd0e8',fx:'#ff7fc0',fx2:'#ff4fa0',s1:'Shivers of First Love',s2:'Catlove Shower',ul:'Cat-Legged Winds of Love',wc:'#ff7fc0',ws:460,wt:'curve',rm:1.25,st:.2},
  yoriichi:{n:'Yoriichi Tsugikuni',b:'Sun Breathing (Legendary)',p:15000,hp:1300,sp:440,dm:1.25,hc:'#1b1b1b',hs:'spiky',ho:'#1a1a1a',pt:'stripe',hk:'#101010',sk:'#f2cba4',ey:'#ff3a1a',bl:'#ff5a2a',fx:'#ff4a1a',fx2:'#ff8a3a',s1:'Sun Dance: Clear Blue Sky',s2:'Sun Dance: Fire Wheel',ul:'Thirteenth Form',wc:'#ff4a1a',ws:700,wt:'curve',rm:1.1,st:.18},
  kokushibo:{n:'Kokushibo',b:'Moon Breathing',p:7500,hp:1400,sp:400,dm:1.2,hc:'#111111',hs:'long',ho:'#1a0d2e',pt:'stripe',hk:'#0a0614',sk:'#e8dcea',ey:'#b388ff',bl:'#ece1ff',fx:'#b388ff',fx2:'#6a3aff',s1:"Moon's Dusk",s2:'Perpetual Night',ul:'Waning Moonswaths',wc:'#b388ff',ws:520,wt:'gale',rm:1.1,dem:1,st:.25},
  akaza:{n:'Akaza',b:'Upper Three: Martial Arts',p:7500,hp:1400,sp:420,dm:1.25,hc:'#dfe0e6',hs:'horn',ho:'#3a0a14',pt:'plain',hk:'#2a0a10',sk:'#e8c8b0',ey:'#ff3a5a',bl:null,fx:'#ff3a5a',fx2:'#ff8a3a',s1:'Destructive Shockwave',s2:'Blazing Dash',ul:'Compass Needle Hand',wc:'#ff3a5a',ws:600,wt:'wave',st:.3,dem:1},
  doma:{n:'Doma',b:'Upper Two: Ice',p:7500,hp:1350,sp:380,dm:1.15,hc:'#aee8ff',hs:'long',ho:'#dff6ff',pt:'plain',hk:'#2a4a6a',sk:'#f0f8ff',ey:'#6ad8ff',bl:null,fx:'#6ad8ff',fx2:'#e0ffff',s1:'Ice Lotus Wave',s2:'Frozen Dash',ul:'Blizzard Field',wc:'#6ad8ff',ws:480,wt:'curve',dem:1,st:.25},
  gyokko:{n:'Gyokko',b:'Upper Four: Vases',p:5000,hp:1300,sp:340,dm:1.1,hc:'#8a6a4a',hs:'bald',ho:'#2a2030',pt:'plain',hk:'#1a1a22',sk:'#e0c0a0',ey:'#ffd24a',bl:null,fx:'#ffd24a',fx2:'#b08a30',s1:'Poison Vase',s2:'Pot Dash',ul:'Pot Barrage',wc:'#ffd24a',ws:380,wt:'wave',dem:1,st:.3},
  gyutaro:{n:'Gyutaro',b:'Upper Six: Blood Sickles',p:5000,hp:1200,sp:400,dm:1.1,hc:'#3a1a1a',hs:'horn',ho:'#4a1a2a',pt:'plain',hk:'#2a0a14',sk:'#e0b8a0',ey:'#ff5a7a',bl:null,fx:'#ff5a7a',fx2:'#ff2a2a',s1:'Blood Sickle',s2:'Poison Chain',ul:'Sickle Storm',wc:'#ff5a7a',ws:560,wt:'curve',dem:1,st:.25},
  hantengu:{n:'Hantengu',b:'Upper Four: Emotions',p:5000,hp:1500,sp:350,dm:1.1,hc:'#3a6a9a',hs:'horn',ho:'#3a3a5a',pt:'plain',hk:'#1a1a2a',sk:'#dcd0c0',ey:'#e0c040',bl:null,fx:'#8ab0ff',fx2:'#ffd060',s1:'Sorrow Wave',s2:'Anger Lunge',ul:'Rage Storm',wc:'#8ab0ff',ws:520,wt:'wave',dem:1,st:.25},
  rui:{n:'Rui',b:'Lower Five: Threads',p:2500,hp:1000,sp:380,dm:1,hc:'#ffb0e0',hs:'long',ho:'#2a1a3a',pt:'plain',hk:'#1a1020',sk:'#f0e0e8',ey:'#ff3a8a',bl:null,fx:'#ff6ab0',fx2:'#c060ff',s1:'Thread Net',s2:'String Snap',ul:'Spider Maze',wc:'#ff6ab0',ws:420,wt:'thread',dem:1,st:.35},
  enmu:{n:'Enmu',b:'Lower One: Dream',p:2500,hp:1100,sp:360,dm:1,hc:'#1a1a1a',hs:'bald',ho:'#2a2a3a',pt:'plain',hk:'#101018',sk:'#e8e0f0',ey:'#c040ff',bl:null,fx:'#c040ff',fx2:'#6020a0',s1:'Dream Projection',s2:'Sleep Wave',ul:'Nightmare Realm',wc:'#c040ff',ws:380,wt:'wave',dem:1,st:.4},
  wakuraba:{n:'Wakuraba',b:'Lower Three: Brawler',p:2500,hp:1100,sp:400,dm:1.05,hc:'#e0b080',hs:'horn',ho:'#4a2a10',pt:'plain',hk:'#1a1008',sk:'#d8a880',ey:'#ff9a20',bl:null,fx:'#ff9a20',fx2:'#c05a10',s1:'Fists of Fury',s2:'Rushing Hit',ul:'Mountain Crash',wc:'#ff9a20',ws:600,wt:'wave',dem:1,st:.3},
  muzan:{n:'Muzan Kibutsuji',b:'Demon King',p:15000,hp:1800,sp:400,dm:1.2,hc:'#050505',hs:'bald',ho:'#140a20',pt:'plain',hk:'#0a0a0a',sk:'#f0ece8',ey:'#ff3a3a',bl:null,fx:'#a040ff',fx2:'#ff2a6a',s1:'Tentacle Lash',s2:'Limb Burst',ul:'Regeneration Flood',wc:'#a040ff',ws:640,wt:'gale',dem:1,st:.25},
  shinobu:{n:'Shinobu Kocho',b:'Insect Breathing',p:3000,hp:950,sp:430,dm:.95,hc:'#1a1420',hs:'bob',ho:'#2e1d4a',pt:'plain',hk:'#1a1024',sk:'#f2d5c0',ey:'#c58cff',bl:'#f0e0ff',fx:'#c58cff',fx2:'#80ffb0',s1:'Insect Dance: Butterfly Dance',s2:'Wisteria Needle',ul:'Butterfly Dance: Fifth',wc:'#c58cff',ws:500,wt:'curve',st:.15,rm:1.1},
  tengen:{n:'Tengen Uzui',b:'Sound Breathing',p:4000,hp:1150,sp:400,dm:1.1,hc:'#c8a0d8',hs:'spiky',ho:'#f0c040',pt:'check',hk:'#2a1a10',sk:'#e8c0a0',ey:'#ffd24a',bl:'#fff0a0',fx:'#ffd24a',fx2:'#ff8a3a',s1:'Sound: Rising Waves',s2:'Sound: Resonance Strike',ul:'Sound: Thunder Crash Roar',wc:'#ffd24a',ws:560,wt:'wave',st:.22},
  muichiro:{n:'Muichiro Tokito',b:'Mist Breathing',p:4500,hp:1000,sp:420,dm:1,hc:'#b8c8e0',hs:'bowl',ho:'#3a4a6a',pt:'stripe',hk:'#1a2030',sk:'#f2d8c8',ey:'#a8d8ff',bl:'#e0f0ff',fx:'#a8d8ff',fx2:'#e8f8ff',s1:'Mist Dance: Whirling Mist',s2:'Mist Swirl',ul:'Mist Breath: Scattering Fog',wc:'#a8d8ff',ws:460,wt:'curve',st:.2},
  gyomei:{n:'Gyomei Himejima',b:'Stone Breathing',p:5000,hp:1600,sp:320,dm:1.3,hc:'#2a2a2a',hs:'bald',ho:'#5a4a3a',pt:'plain',hk:'#2a2018',sk:'#d8b898',ey:'#ffffff',bl:null,wp:'club',fx:'#c8a070',fx2:'#8a6a40',s1:'Stone Rock Splitter',s2:'Sturdy Smash',ul:'Stone Breathing: Ninth Form',wc:'#c8a070',ws:420,wt:'wave',rm:1.3,st:.35},
  kanao:{n:'Kanao Tsuyuri',b:'Flower Breathing',p:2500,hp:950,sp:420,dm:1,hc:'#1a1a2a',hs:'flow',ho:'#2a4a7a',pt:'plain',hk:'#1a1a2a',sk:'#f2d5c4',ey:'#ff9ad0',bl:'#d0e8ff',fx:'#ff9ad0',fx2:'#ffd0f0',s1:'Flower Slash',s2:'Flower Lunge',ul:'Flower Breath: Petal Storm',wc:'#ff9ad0',ws:440,wt:'curve',st:.2},
  nezuko:{n:'Nezuko Kamado',b:'Blood Demon Art',p:2500,hp:1000,sp:430,dm:1.05,hc:'#1a1a1a',hs:'long',ho:'#d86a8a',pt:'plain',hk:'#1a1a1a',sk:'#f2cba4',ey:'#ff3a3a',bl:null,fx:'#ff3a3a',fx2:'#ff9a20',s1:'Demon Claw Slash',s2:'Flame Claw Rush',ul:'Demon Art: Dragon Burst',wc:'#ff3a3a',ws:460,wt:'curve',dem:1,st:.2},
  daki:{n:'Daki',b:'Upper Six: Obi Demon',p:7500,hp:1350,sp:400,dm:1.15,hc:'#f2c8e0',hs:'flow',ho:'#c0306a',pt:'stripe',hk:'#2a0a14',sk:'#f0d8c8',ey:'#ff5aa0',bl:null,fx:'#ff5aa0',fx2:'#ffd0ff',s1:'Obi Whip',s2:'Silk Snare',ul:'Obi Mountain Crush',wc:'#ff5aa0',ws:520,wt:'thread',dem:1,st:.3},
  nakime:{n:'Nakime',b:'Upper Five: Biwa Demon',p:7500,hp:1300,sp:380,dm:1.1,hc:'#3a2a1a',hs:'flow',ho:'#5a3a2a',pt:'plain',hk:'#1a1010',sk:'#f0e0d0',ey:'#ffd080',bl:null,fx:'#ffd080',fx2:'#ff8040',s1:'Biwa Sound Wave',s2:'Melody Lash',ul:'Biwa Requiem',wc:'#ffd080',ws:460,wt:'wave',dem:1,st:.25},
  sabito:{n:'Sabito',b:'Water Breathing (Student)',p:2500,hp:950,sp:420,dm:1,hc:'#c8c8d8',hs:'spiky',ho:'#2a3a5a',pt:'check',hk:'#1a2030',sk:'#f2cba4',ey:'#7fd0ff',bl:'#dff0ff',fx:'#4fb3ff',fx2:'#9fe0ff',s1:'Water Surface Slash',s2:'Wave Dash',ul:'Water Whirl',wc:'#4fb3ff',ws:500,wt:'curve',st:.2},
  makomo:{n:'Makomo',b:'Water Breathing (Student)',p:2500,hp:950,sp:430,dm:.95,hc:'#2a2a3a',hs:'long',ho:'#2a6aa0',pt:'plain',hk:'#1a2a40',sk:'#f2d5c4',ey:'#7fd0ff',bl:'#dff0ff',fx:'#7fd0ff',fx2:'#e0f8ff',s1:'Tiny Wave Cut',s2:'Ocean Hop',ul:'Gentle Tide',wc:'#7fd0ff',ws:460,wt:'curve',st:.18},
  kaigaku:{n:'Kaigaku',b:'Upper Moon Demon',p:7500,hp:1350,sp:420,dm:1.15,hc:'#2a2a2a',hs:'horn',ho:'#3a1a2a',pt:'plain',hk:'#1a0a10',sk:'#e0c8c0',ey:'#ff3a3a',bl:null,fx:'#ff3a3a',fx2:'#ff8a3a',s1:'Demon Claw Gust',s2:'Dark Dash',ul:'Storm of Claws',wc:'#ff8a3a',ws:520,wt:'gale',dem:1,st:.25},
  susamaru:{n:'Susamaru',b:'Demon Shrine Maiden',p:3500,hp:1150,sp:400,dm:1.05,hc:'#2a1a2a',hs:'long',ho:'#3a1a3a',pt:'plain',hk:'#1a1020',sk:'#e8d0c0',ey:'#ff5a8a',bl:null,fx:'#ff5a8a',fx2:'#c060ff',s1:'Fan Slash',s2:'Dancing Veil',ul:'Ghostly Shrine Dance',wc:'#ff5a8a',ws:460,wt:'curve',st:.2,dem:1},
  yushiro:{n:'Yushiro',b:'Demon Servant: Shadow Cleave',p:2500,hp:1000,sp:410,dm:1,hc:'#1a1a2a',hs:'bob',ho:'#2a2a4a',pt:'plain',hk:'#1a1a2a',sk:'#e8d4c0',ey:'#ffd24a',bl:null,fx:'#ffd24a',fx2:'#ff8a3a',s1:'Shadow Sweep',s2:'Quick Dash',ul:'Bloodbound Storm',wc:'#ffd24a',ws:460,wt:'curve',st:.2,dem:1},
  tanjuro:{n:'Tanjuro Ubuyashiki',b:'Ubuyashiki Swordsmanship',p:4000,hp:1100,sp:380,dm:1.1,hc:'#c8c8d0',hs:'long',ho:'#2a2a3a',pt:'plain',hk:'#1a1a2a',sk:'#f2d8c4',ey:'#7fd0ff',bl:'#e8f4ff',fx:'#9fd8ff',fx2:'#ffffff',s1:'Ubuyashiki Iai Strike',s2:'Calm Step Slash',ul:'Ubuyashiki Vow',wc:'#9fd8ff',ws:500,wt:'curve',st:.2},
  kagaya:{n:'Kagaya Ubuyashiki',b:'Head of the Ubuyashiki Clan',p:6000,hp:1200,sp:360,dm:1.15,hc:'#2a1a40',hs:'long',ho:'#3a2a5a',pt:'stripe',hk:'#1a1a30',sk:'#f0e0d0',ey:'#ffd080',bl:'#fff0d8',fx:'#ffd080',fx2:'#ffffff',s1:'Ancestral Blade',s2:'Shadow Step',ul:'Sun Shield of the Clan',wc:'#ffd080',ws:520,wt:'curve',st:.2},
  aoi:{n:'Aoi Kanzaki',b:'Demon Slayer Corps',p:2000,hp:950,sp:420,dm:.95,hc:'#2a4aa0',hs:'long',ho:'#2a4aa0',pt:'plain',hk:'#1a2a40',sk:'#f2d5c4',ey:'#4fb3ff',bl:'#dff0ff',fx:'#4fb3ff',fx2:'#e0f8ff',s1:'Aoi Slash',s2:'Quick Lunge',ul:'Blue Storm Flurry',wc:'#4fb3ff',ws:460,wt:'curve',st:.2},
  kiyo:{n:'Kiyo Terauchi',b:'Demon Slayer Corps',p:2000,hp:1000,sp:400,dm:1,hc:'#e8c8a0',hs:'tuft',ho:'#c09050',pt:'plain',hk:'#3a2a20',sk:'#f2cba4',ey:'#c09050',bl:'#fff0d8',fx:'#ffd080',fx2:'#ffffff',s1:'Terauchi Slash',s2:'Rushing Step',ul:'Terauchi Storm',wc:'#ffd080',ws:480,wt:'curve',st:.2},
  shinobubro:{n:"Shinobu's Brother",b:'Insect Breathing',p:3000,hp:1000,sp:400,dm:1,hc:'#1a1420',hs:'bob',ho:'#2e1d4a',pt:'plain',hk:'#1a1024',sk:'#f2d5c0',ey:'#c58cff',bl:'#f0e0ff',fx:'#c58cff',fx2:'#80ffb0',s1:'Insect Slash',s2:'Butterfly Step',ul:'Insect Storm',wc:'#c58cff',ws:460,wt:'curve',st:.2},
  tengenbro:{n:"Tengen's Brother",b:'Sound Breathing',p:3000,hp:1050,sp:400,dm:1.05,hc:'#c8a0d8',hs:'spiky',ho:'#f0c040',pt:'check',hk:'#2a1a10',sk:'#e8c0a0',ey:'#ffd24a',bl:'#fff0a0',fx:'#ffd24a',fx2:'#ff8a3a',s1:'Sound Wave Cut',s2:'Resonance Dash',ul:'Sound Storm',wc:'#ffd24a',ws:500,wt:'wave',st:.2},
  kagayabro:{n:"Kagaya's Brother",b:'Ubuyashiki Clan',p:3500,hp:1050,sp:380,dm:1.05,hc:'#2a1a40',hs:'long',ho:'#3a2a5a',pt:'stripe',hk:'#1a1a30',sk:'#f0e0d0',ey:'#ffd080',bl:'#fff0d8',fx:'#ffd080',fx2:'#ffffff',s1:'Clan Blade',s2:'Quiet Step',ul:'Clan Barrier',wc:'#ffd080',ws:500,wt:'curve',st:.2},
  tanjurowife:{n:"Tanjuro's Wife",b:'Kamado Family',p:2000,hp:950,sp:400,dm:.95,hc:'#3a1a1a',hs:'bob',ho:'#c04050',pt:'plain',hk:'#2a1010',sk:'#f2d5c4',ey:'#8a4a2a',bl:null,fx:'#ff8a6a',fx2:'#ffd0c0',s1:'Household Strike',s2:'Quick Hop',ul:'Warm Light',wc:'#ff8a6a',ws:460,wt:'curve',st:.2},
  suma:{n:'Suma',b:'Demon Slayer Corps',p:2000,hp:950,sp:420,dm:.95,hc:'#f0e8f0',hs:'long',ho:'#c0306a',pt:'plain',hk:'#2a1a2a',sk:'#f2d5c4',ey:'#ff5aa0',bl:'#ffe0f0',fx:'#ff5aa0',fx2:'#ffd0ff',s1:'Flower Swirl Slash',s2:'Petal Dash',ul:'Floral Storm',wc:'#ff5aa0',ws:440,wt:'curve',st:.2},
  kiriya:{n:'Kiriya Ubuyashiki',b:'Ubuyashiki Clan',p:6000,hp:1200,sp:360,dm:1.15,hc:'#e8e8f0',hs:'bob',ho:'#1a1a2a',pt:'stripe',hk:'#1a1a30',sk:'#f0e0d0',ey:'#7fd0ff',bl:'#e8f4ff',fx:'#9fd8ff',fx2:'#ffffff',s1:'Clan Iai',s2:'Shadow Dash',ul:'Ubuyashiki Barrier',wc:'#9fd8ff',ws:520,wt:'curve',st:.2},
  tamayo:{n:'Tamayo',b:'Demon Scholar: Mind Control',p:5000,hp:1050,sp:390,dm:1.05,hc:'#e8e0f0',hs:'bob',ho:'#2a2a4a',pt:'plain',hk:'#1a1a30',sk:'#f4e8e0',ey:'#ff5ad0',bl:null,fx:'#ff5ad0',fx2:'#c0a0ff',s1:'Mind Ripple',s2:'Chain Hand',ul:'Hundred Puppet Hands',wc:'#ff5ad0',ws:460,wt:'wave',st:.25,dem:1},
};
const CH={};
for(const k in RAW){CH[k]=Object.assign({id:k,lh:1,rm:1,dem:0,sc:0,wt:'curve',ws:500,st:.2,pt:'plain',bl:'#e8f2ff',sk:'#f2cba4'},RAW[k]);}
const ROSTER=['tanjiro','zenitsu','inosuke','obanai','giyu','sanemi','rengoku','mitsuri','yoriichi','kokushibo','akaza','doma','gyokko','gyutaro','hantengu','rui','enmu','wakuraba','muzan','shinobu','tengen','muichiro','gyomei','kanao','nezuko','daki','nakime','sabito','makomo','kaigaku','susamaru','yushiro','tanjuro','kagaya','tamayo','aoi','kiyo','shinobubro','tengenbro','kagayabro','tanjurowife','suma','kiriya'];
const DIFF={
  easy:{react:.4,aggro:.45,block:.35,mist:.15,spd:.95,rew:50,hp:500,lab:'Easy'},
  normal:{react:.28,aggro:.6,block:.5,mist:.08,spd:1.05,rew:100,hp:650,lab:'Normal'},
  hard:{react:.18,aggro:.75,block:.7,mist:.04,spd:1.12,rew:175,hp:800,lab:'Hard'},
  demon:{react:.1,aggro:.85,block:.8,mist:.02,spd:1.2,rew:250,hp:950,lab:'Demon'},
  hashira:{react:.05,aggro:.95,block:.9,mist:0,spd:1.28,rew:350,hp:1100,lab:'Hashira'}
};
const DIFF_KEYS=Object.keys(DIFF);
const TRAIN_BOTS=[null,{react:.5,aggro:.1,block:.9,mist:0,spd:.5},{react:.1,aggro:.9,block:.2,mist:0,spd:1.1}];
const STORY=[
  {w:1,t:'Forest Demon',e:'susamaru',d:'easy',line:'The forest is cold. Something waits between the trees.'},
  {w:1,t:'Tsuzumi Mansion',e:'wakuraba',d:'normal',line:'Drums echo through the mansion halls.'},
  {w:1,t:'Mount Natagumo',e:'rui',d:'normal',line:'Threads hang from every branch.'},
  {w:1,t:'Lower Four',e:'tamayo',d:'hard',line:'Dolls move where no one stands.'},
  {w:1,t:'Lower Six',e:'yushiro',d:'hard',line:'Sickles sing in the dark.'},
  {w:1,t:'Lower One: Enmu',e:'enmu',d:'demon',line:'Sleep is a trap. Wake up, swordsman.'},
  {w:2,t:'Entertainment District',e:'gyutaro',d:'demon',line:'Neon lights and blood. The Upper Moons have arrived.'},
  {w:2,t:'Gyokko',e:'gyokko',d:'hard',line:'Every vase hides a poison.'},
  {w:2,t:'Hantengu',e:'hantengu',d:'hard',line:'Emotions split into many bodies.'},
  {w:2,t:'Doma',e:'doma',d:'demon',line:'The cold spreads across the ground.'},
  {w:2,t:'Akaza',e:'akaza',d:'hashira',line:'Martial arts without mercy.'},
  {w:2,t:'Kokushibo',e:'kokushibo',d:'hashira',line:'The Moon sees everything.'},
  {w:2,t:'Muzan Kibutsuji',e:'muzan',d:'hashira',line:'The source of all demons. End him.'},
  {w:3,t:'Lantern Street',e:'daki',d:'hard',a:4,line:'Lanterns flicker over a city that never sleeps.'},
  {w:4,t:'Bamboo Grove',e:'nakime',d:'hard',a:5,line:'A biwa sings through the bamboo.'},
  {w:5,t:'Demon Mountain',e:'kaigaku',d:'demon',a:6,line:'The mountain demands a toll in blood.'},
  {w:6,t:'Frozen Lake',e:'doma',d:'hashira',a:7,line:'The lake freezes solid around your steps.'},
  {w:7,t:'Volcano Shrine',e:'akaza',d:'hashira',a:8,line:'Fire and fists, pushed to the limit.'},
  {w:8,t:'Ruined Castle',e:'hantengu',d:'hashira',a:9,line:'Every emotion returns in one enormous body.'},
  {w:9,t:'Moon Shrine',e:'kokushibo',d:'hashira',a:0,line:'The moon watches the final rematch.'},
  {w:10,t:'Ocean Cliff',e:'gyokko',d:'hashira',a:10,line:'The waves carry poisoned vases.'},
  {w:11,t:'Snow Valley',e:'gyutaro',d:'hashira',a:11,line:'Blood sickles glitter in the snow.'},
  {w:12,t:'Demon Realm',e:'muzan',d:'hashira',a:3,line:'Beyond the dream, the Demon King waits again.'},
  {w:13,t:'Shrine of Shadows',e:'tamayo',d:'hard',a:13,line:'Puppets hang from the shrine beams, waiting for their strings.'},
  {w:13,t:'Shrine Maiden Dance',e:'susamaru',d:'hard',a:14,line:'A fan opens and the shrine goes silent.'},
  {w:13,t:'Shadow Cleave',e:'yushiro',d:'hashira',a:15,line:'Shadows move faster than the eye can follow.'},
  {w:14,t:'Storm Of The Hashira',e:'akaza',d:'hashira',a:16,line:'The wind carries the stench of demon blood.'},
  {w:14,t:'Ice Lotus Field',e:'doma',d:'hashira',a:17,line:'Every step freezes the ground beneath you.'},
  {w:14,t:'Scroll of Blades',e:'kaigaku',d:'hashira',a:18,line:'Ten thousand swords fall from the sky.'},
  {w:15,t:'The Last Moon',e:'kokushibo',d:'hashira',a:0,line:'Six eyes watch the final night.'},
  {w:15,t:'Obi Mountain',e:'daki',d:'hashira',a:1,line:'Silk binds the mountain in a web of blood.'},
  {w:15,t:'Demon King Returns',e:'muzan',d:'hashira',a:2,line:'The Demon King rises for one last war.'}
];
const ARENAS=[
  {n:'Moonlit Temple',sky:['#070a1c','#2a1540'],moon:1,ground:'#3a2415',fog:'#7a5a9a',tree:1},
  {n:'Forest Night',sky:['#04080f','#12301e'],moon:1,ground:'#1e2a1a',fog:'#3c6a4a',tree:1},
  {n:'Mansion Hall',sky:['#120a14','#3a1424'],moon:0,ground:'#3d1e12',fog:'#8a4a50',tree:0},
  {n:'Entertainment District',sky:['#1a0a1c','#4a1a30'],moon:0,ground:'#2a1a1e',fog:'#c05080',tree:0},
  {n:'Lantern Street',sky:['#140a1c','#3a1a3a'],moon:0,ground:'#2a1a24',fog:'#d06090',tree:0},
  {n:'Bamboo Grove',sky:['#06140c','#1c3a24'],moon:1,ground:'#1e2a1a',fog:'#5a9a6a',tree:1},
  {n:'Demon Mountain',sky:['#0a0a18','#2a1a3a'],moon:1,ground:'#2e2620',fog:'#7a6a9a',tree:0},
  {n:'Frozen Lake',sky:['#061020','#1a3050'],moon:1,ground:'#3a4a5a',fog:'#a0d0ff',tree:0},
  {n:'Volcano Shrine',sky:['#1a0404','#4a1008'],moon:0,ground:'#2a0e06',fog:'#ff6a2a',tree:0},
  {n:'Ruined Castle',sky:['#100a10','#2a1a24'],moon:1,ground:'#2a2420',fog:'#7a6a7a',tree:1},
  {n:'Ocean Cliff',sky:['#041018','#0e2a3a'],moon:1,ground:'#3a3228',fog:'#5a8aa0',tree:0},
  {n:'Snow Valley',sky:['#0e1420','#2a3850'],moon:1,ground:'#c8d4e0',fog:'#e8f0ff',tree:0},
  {n:'Butterfly Mansion',sky:['#1a0a24','#4a1a4a'],moon:1,ground:'#2e1a2a',fog:'#c07ad0',tree:0},
  {n:'Final Selection Forest',sky:['#050c08','#1a2e1a'],moon:1,ground:'#18240f',fog:'#4a7a48',tree:1},
  {n:'Mugen Train',sky:['#0a0a10','#262634'],moon:0,ground:'#2a2a30',fog:'#6a6a80',tree:0},
  {n:'Swordsmith Village',sky:['#1c0c06','#5a2a10'],moon:0,ground:'#3a2414',fog:'#e08a40',tree:0},
  {n:'Infinity Castle',sky:['#06040c','#1c1032'],moon:1,ground:'#1a1424',fog:'#6a3a9a',tree:0},
  {n:'Mount Natagumo',sky:['#06060c','#1a1830'],moon:1,ground:'#16141e',fog:'#5a5a8a',tree:1},
  {n:'Nighttime Demon Village',sky:['#080410','#2a1020'],moon:1,ground:'#241a1a',fog:'#a03a50',tree:0}
];
const MOVES={
  light:{dur:.34,hits:[{t:.12,r:120,dm:7,kb:120,st:.18}],col:'fx',tr:1},
  heavy:{dur:.62,hits:[{t:.32,r:150,dm:15,kb:340,st:.38}],col:'fx2',tr:1.5,lunge:[.18,.34,240]},
  s1:{dur:.5,hits:[{t:.24,r:110,dm:10,kb:200,st:.25}],wave:.24,col:'fx',tr:1.2,cost:25,cd:3.2},
  s2:{dur:.46,hits:[{t:.1,r:115,dm:9,kb:180,st:.22}],lunge:[0,.2,880],col:'fx2',tr:1.2,cost:20,cd:3.8},
  ult:{dur:1.7,hits:[{t:.45,r:150,dm:6,kb:90,st:.14},{t:.62,r:150,dm:6,kb:90,st:.14},{t:.8,r:160,dm:7,kb:100,st:.16},{t:.98,r:160,dm:7,kb:100,st:.16},{t:1.2,r:190,dm:20,kb:520,st:.5}],lunge:[.3,.8,700],col:'fx2',tr:2.2,ult:1,big:1,cd:10}
};
