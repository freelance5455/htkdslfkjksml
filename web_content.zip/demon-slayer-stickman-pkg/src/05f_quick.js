/* ---------- QUICK FIGHT ---------- */
let quick={p:'tanjiro',e:'rengoku',diff:'hard',pick:'p',mode:'quick'};
function drawQuickPanel(side,x,id,label){
  const on=quick.pick===side;
  ctx.save();
  ctx.fillStyle='rgba(12,6,20,.88)';rr(x,122,340,224,14);ctx.fill();
  ctx.strokeStyle=on?'#ffd24a':'#6a4a5a';ctx.lineWidth=on?4:2;ctx.stroke();
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillStyle=on?'#ffd24a':'#c8a8d8';ctx.font='bold 15px Georgia';ctx.fillText(label,x+170,140);
  ctx.fillStyle='#ffe2b8';ctx.font='bold 17px Georgia';ctx.fillText(CH[id].n,x+170,160);
  ctx.restore();
  drawPortrait(id,x+170,336,.85,side==='p'?1:-1);
  btns.push({x:x,y:122,w:340,h:224,fn:()=>{quick.pick=side;}});
}
function drawQuick(){
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffd27a';ctx.font='bold 34px Georgia';
  ctx.fillText(quick.mode==='training'?'TRAINING SETUP':'QUICK FIGHT',640,46);
  ctx.font='bold 22px Georgia';ctx.fillStyle='#ff5a2a';ctx.fillText('VS',640,236);
  ctx.restore();
  Btn(30,18,120,40,'BACK',()=>goto('menu'));
  Btn(30,76,150,36,mapLabel(),()=>cycleMap(),{f:'bold 14px Georgia'});
  Btn(1050,18,200,40,'START',()=>goto('battle',{mode:quick.mode,p:quick.p,e:quick.e,diff:quick.diff,arena:Math.floor(Math.random()*ARENAS.length),rounds:1}),{f:'bold 20px Georgia'});
  if(quick.mode!=='training')DIFF_KEYS.forEach((k,i)=>{
    const on=quick.diff===k;
    Btn(190+i*180,76,164,36,DIFF[k].lab+' ('+DIFF[k].hp+' HP)',()=>{quick.diff=k;},on?{a:'#c4502a',b:'#6a2a10',f:'bold 14px Georgia'}:{f:'bold 14px Georgia'});
  });
  drawQuickPanel('p',40,quick.p,'YOU  (tap to pick)');
  drawQuickPanel('e',900,quick.e,'OPPONENT  (tap to pick)');
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='bold 14px Georgia';ctx.fillStyle='#e8c8ff';
  ctx.fillText('Choose a side above, then tap any fighter below to assign them',640,348);
  ctx.restore();
  ROSTER.forEach((id,i)=>{
    const cx=40+(i%9)*132,cy=360+Math.floor(i/9)*64;
    const c=CH[id];
    ctx.save();
    ctx.fillStyle=quick.p===id||quick.e===id?'rgba(80,30,40,.92)':'rgba(30,14,30,.88)';
    rr(cx,cy,124,58,10);ctx.fill();
    ctx.strokeStyle=quick.p===id?'#ffd24a':quick.e===id?'#ff4a4a':'#5a3a4a';ctx.lineWidth=quick.p===id||quick.e===id?3:1.5;ctx.stroke();
    ctx.fillStyle='#ffe2b8';ctx.font='bold 13px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillText(c.n.slice(0,17),cx+62,cy+19);
    ctx.font='10px Georgia';ctx.fillStyle='#c8a8d8';
    ctx.fillText('T'+c.tier+(quick.p===id?' YOU':'')+(quick.e===id?' ENEMY':''),cx+62,cy+40);
    ctx.restore();
    btns.push({x:cx,y:cy,w:124,h:58,fn:()=>{quick[quick.pick]=id;}});
  });
}
