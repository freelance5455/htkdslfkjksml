'use strict';
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'accounts.json');
const MAX_LEVEL = 200;
const RANKED_LEVEL = 20;
const MAX_CONNECTIONS = 100000;
const RANKS = [
  { min: 2000, name: 'Master' }, { min: 1400, name: 'Diamond' }, { min: 900, name: 'Platinum' },
  { min: 500, name: 'Gold' }, { min: 200, name: 'Silver' }, { min: 0, name: 'Bronze' }
];

const xpToNext = lvl => 1000 + 25 * lvl;
const randInt = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const rankOf = rp => RANKS.find(r => rp >= r.min).name;

function addXp(acc, amount) {
  acc.xp += amount;
  while (acc.level < MAX_LEVEL && acc.xp >= xpToNext(acc.level)) {
    acc.xp -= xpToNext(acc.level);
    acc.level++;
  }
  if (acc.level >= MAX_LEVEL) acc.xp = 0;
}

let accounts = {};
try { accounts = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (e) { accounts = {}; }
let saveTimer = null;
function saveSoon() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    fs.writeFile(DATA_FILE, JSON.stringify(accounts), () => {});
  }, 2000);
}

const sessions = new Map();
const clients = new Map();
const quickQueue = [];
const rankedQueue = [];
const parties = new Map();
const matches = new Map();

const profileOf = acc => ({
  name: acc.name, level: acc.level, xp: acc.xp, xpNext: xpToNext(acc.level),
  rp: acc.rp, rank: rankOf(acc.rp), rankedUnlocked: acc.level >= RANKED_LEVEL
});

function send(ws, msg) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(msg));
}

function hashPassword(pw, salt) {
  return new Promise((resolve, reject) => {
    crypto.scrypt(pw, salt, 32, (err, key) => (err ? reject(err) : resolve(key.toString('hex'))));
  });
}

async function register(user, pass) {
  const key = user.toLowerCase();
  if (accounts[key]) return { ok: false, msg: 'That username is already taken' };
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = await hashPassword(pass, salt);
  if (accounts[key]) return { ok: false, msg: 'That username is already taken' };
  accounts[key] = { name: user, salt, hash, level: 1, xp: 0, rp: 0, created: Date.now() };
  saveSoon();
  return { ok: true, key };
}

async function login(user, pass) {
  const key = user.toLowerCase();
  const acc = accounts[key];
  if (!acc) return { ok: false, msg: 'No account with that username' };
  const hash = await hashPassword(pass, acc.salt);
  if (hash !== acc.hash) return { ok: false, msg: 'Wrong password' };
  return { ok: true, key };
}

function removeFromQueues(state) {
  for (const q of [quickQueue, rankedQueue]) {
    const i = q.indexOf(state);
    if (i >= 0) q.splice(i, 1);
  }
}

function leaveParty(state) {
  if (state.party) {
    const p = parties.get(state.party);
    if (p && p.host === state) parties.delete(state.party);
    else if (p) p.guest = null;
    state.party = null;
  }
}

function startMatch(a, b, mode) {
  const id = crypto.randomBytes(8).toString('hex');
  const match = { id, mode, players: [a, b], chars: [null, null], ended: false, reported: false };
  matches.set(id, match);
  a.match = match; b.match = match;
  a.side = 0; b.side = 1;
  for (const [me, opp] of [[a, b], [b, a]]) {
    send(me.ws, { t: 'matched', matchId: id, mode, side: me.side,
      opp: { name: opp.name, level: opp.level, rank: rankOf(opp.rp) } });
  }
}

function tryQueue(mode) {
  const q = mode === 'ranked' ? rankedQueue : quickQueue;
  while (q.length >= 2) {
    const a = q.shift(), b = q.shift();
    if (a.ws.readyState !== 1 || b.ws.readyState !== 1) continue;
    startMatch(a, b, mode);
  }
}

function finishMatch(match, winnerSide) {
  if (match.ended) return;
  match.ended = true;
  const mode = match.mode;
  match.players.forEach((p, i) => {
    const acc = accounts[p.key];
    if (!acc) return;
    const won = i === winnerSide;
    let gained;
    if (mode === 'ranked') {
      gained = randInt(3000, 5000);
      acc.rp = Math.max(0, acc.rp + (won ? 25 : -15));
    } else {
      gained = randInt(500, 2000);
    }
    const before = acc.level;
    addXp(acc, gained);
    p.match = null;
    send(p.ws, { t: 'reward', won, mode, xp: gained, levelBefore: before, profile: profileOf(acc) });
  });
  saveSoon();
  setTimeout(() => matches.delete(match.id), 60000);
}

function handle(ws, state, msg) {
  switch (msg.t) {
    case 'resume': {
      const key = String(msg.user || '').toLowerCase();
      const acc = accounts[key];
      if (state.key) return;
      if (!acc || !acc.tok || typeof msg.token !== 'string' || msg.token !== acc.tok) {
        return send(ws, { t: 'err', msg: 'Session expired. Log in again.' });
      }
      if ([...clients.values()].some(s => s.key === key && s.ws.readyState === 1)) {
        return send(ws, { t: 'err', msg: 'This account is already online' });
      }
      state.key = key; state.name = acc.name; state.level = acc.level; state.rp = acc.rp;
      send(ws, { t: 'auth', token: acc.tok, profile: profileOf(acc) });
      return;
    }
    case 'register':
    case 'login': {
      const user = String(msg.user || '').trim(), pass = String(msg.pass || '');
      if (!/^[A-Za-z0-9_]{3,16}$/.test(user)) return send(ws, { t: 'err', msg: 'Username: 3-16 letters, numbers or _' });
      if (pass.length < 4) return send(ws, { t: 'err', msg: 'Password must be at least 4 characters' });
      if (state.key) return send(ws, { t: 'err', msg: 'Already logged in' });
      (async () => {
        const r = msg.t === 'register' ? await register(user, pass) : await login(user, pass);
        if (!r.ok) return send(ws, { t: 'err', msg: r.msg });
        if ([...clients.values()].some(s => s.key === r.key && s.ws.readyState === 1)) {
          return send(ws, { t: 'err', msg: 'This account is already online' });
        }
        const acc = accounts[r.key];
        if (!acc.tok) { acc.tok = crypto.randomBytes(24).toString('hex'); saveSoon(); }
        state.key = r.key;
        state.name = accounts[r.key].name;
        state.level = accounts[r.key].level;
        state.rp = accounts[r.key].rp;
        send(ws, { t: 'auth', token: acc.tok, profile: profileOf(acc) });
      })().catch(() => send(ws, { t: 'err', msg: 'Server error, try again' }));
      return;
    }
    case 'queue': {
      if (!state.key) return send(ws, { t: 'err', msg: 'Log in first' });
      if (state.match) return send(ws, { t: 'err', msg: 'You are already in a match' });
      const acc = accounts[state.key];
      if (msg.mode === 'ranked' && acc.level < RANKED_LEVEL) {
        return send(ws, { t: 'err', msg: 'Reach level ' + RANKED_LEVEL + ' to unlock ranked' });
      }
      removeFromQueues(state);
      leaveParty(state);
      state.level = acc.level; state.rp = acc.rp;
      (msg.mode === 'ranked' ? rankedQueue : quickQueue).push(state);
      send(ws, { t: 'queued', mode: msg.mode });
      tryQueue(msg.mode === 'ranked' ? 'ranked' : 'quick');
      return;
    }
    case 'cancel': {
      removeFromQueues(state);
      leaveParty(state);
      send(ws, { t: 'cancelled' });
      return;
    }
    case 'party_create': {
      if (!state.key) return send(ws, { t: 'err', msg: 'Log in first' });
      removeFromQueues(state);
      leaveParty(state);
      let code;
      do { code = String(randInt(100000, 999999)); } while (parties.has(code));
      parties.set(code, { code, host: state, guest: null });
      state.party = code;
      send(ws, { t: 'party', code });
      return;
    }
    case 'party_join': {
      if (!state.key) return send(ws, { t: 'err', msg: 'Log in first' });
      const code = String(msg.code || '').trim();
      const p = parties.get(code);
      if (!p) return send(ws, { t: 'err', msg: 'No party with that code' });
      if (p.host === state) return send(ws, { t: 'err', msg: 'That is your own party' });
      if (p.guest) return send(ws, { t: 'err', msg: 'That party is full' });
      removeFromQueues(state);
      leaveParty(state);
      parties.delete(code);
      startMatch(p.host, state, 'party');
      return;
    }
    case 'char': {
      const m = state.match;
      if (!m) return;
      m.chars[state.side] = String(msg.char || '').slice(0, 20);
      if (m.chars[0] && m.chars[1] && !m.started) {
        m.started = true;
        const seed = crypto.randomBytes(4).readUInt32LE(0);
        m.players.forEach((p, i) => send(p.ws, { t: 'start', matchId: m.id, side: i, you: m.chars[i], opp: m.chars[1 - i], seed }));
      }
      return;
    }
    case 'tick': {
      const m = state.match;
      if (!m || !m.started || m.ended) return;
      if (!state.allow()) return;
      const other = m.players[1 - state.side];
      const n = Number.isInteger(msg.n) ? msg.n : -1;
      const c = msg.c && typeof msg.c === 'object' ? msg.c : {};
      const clean = { mx: Math.max(-1, Math.min(1, Number(c.mx) || 0)), block: !!c.block };
      for (const k of ['jump', 'light', 'heavy', 's1', 's2', 'ult', 'dash']) clean[k] = !!c[k];
      send(other.ws, { t: 'tick', n, c: clean });
      return;
    }
    case 'result': {
      const m = state.match;
      if (!m || m.ended || m.reported) return;
      m.reported = true;
      const won = !!msg.won;
      finishMatch(m, won ? state.side : 1 - state.side);
      return;
    }
    default:
      return;
  }
}

const httpServer = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Demon Slayer Pixel War server. Online players: ' + clients.size);
});
const wss = new WebSocketServer({ server: httpServer, maxPayload: 16 * 1024 });

wss.on('connection', (ws) => {
  if (clients.size >= MAX_CONNECTIONS) { ws.close(1013, 'Server full'); return; }
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  let tokens = 200, last = Date.now();
  const state = { ws, key: null, name: null, level: 1, rp: 0, match: null, side: null, party: null,
    allow() { const now = Date.now(); tokens = Math.min(200, tokens + (now - last) * 0.15); last = now; if (tokens < 1) return false; tokens -= 1; return true; } };
  clients.set(ws, state);
  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw); } catch (e) { return; }
    handle(ws, state, msg);
  });
  ws.on('close', () => {
    removeFromQueues(state);
    leaveParty(state);
    if (state.match && !state.match.ended) {
      const m = state.match;
      const other = m.players[1 - state.side];
      send(other.ws, { t: 'opp_left' });
      finishMatch(m, 1 - state.side);
    }
    clients.delete(ws);
  });
});

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    ws.ping();
  }
}, 30000);
wss.on('close', () => clearInterval(heartbeat));

httpServer.listen(PORT, () => console.log('Pixel War server listening on port ' + PORT));
