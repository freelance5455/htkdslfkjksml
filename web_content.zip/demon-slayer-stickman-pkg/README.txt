DEMON SLAYER: STICKMAN WARRIORS (single-file HTML5 canvas game)

HOW TO PLAY
- Open index.html in a browser (landscape recommended; phones: rotate to landscape).
- Keyboard: A/D move, W/Space jump, S/L block, J light, K heavy, U skill 1, I skill 2, O ultimate, Shift dash, Esc pause.
- Backdash: hold the direction AWAY from the enemy and press Dash (Shift). Plain Dash goes forward.
- Touch: joystick bottom-left, buttons bottom-right. Joystick pointing away + DASH = backdash.

WHAT'S IN THIS BUILD
- 31 fighters (roster pages in Character Select): original 22 plus Shinobu, Tengen, Muichiro,
  Gyomei, Genya, Kanao, Nezuko, Daki, Nakime.
- Demons fight without swords (claws), except Kokushibo. Gyomei uses a club.
- Procedural sword art (guard, grip, tapered blade with glow) and slash arcs on every attack.
- Ultimates: rings, aura sparks, name banner and multi-hit shockwaves.
- Enemy HP by difficulty: Easy 500, Normal 650, Hard 800, Demon 950, Hashira 1100 (+150 per step).
- Story: a cutscene plays after every stage you win, and an ending after Muzan.
- Sound: procedural sound effects and background music (Settings > Sound Effects / Music).
  Settings > Custom Music lets you load your own audio file (for example, an official soundtrack
  you own). Official anime audio is not included because it is copyrighted.
- Graphics default to MAX (afterimages during dashes and attacks). Lower it in Settings if needed.

FILES
- index.html : the complete game (built from src/).
- src/       : source parts, concatenated in order by build.sh
               (01_head, 02_core, 03_fighter, 04_logic, 05_render_battle, 05b_fx, 05c_extras, 06_screens, 09_tail).
- build.sh   : rebuilds index.html after editing src/.

ROUND 2 ADDITIONS
- Redesigned main menu with a character hero panel, aura and tier readout.
- TIER LIST screen (main menu): Tier 1 Tanjiro, Zenitsu, Yoriichi, Muzan. Tier 2 all Hashira and
  Upper Moons. Tier 3 Inosuke, Kanao, Nezuko and Lower Moons. Tier 4 Genya and normal slayers.
  Damage multiplier by tier: T1 x1.40, T2 x1.25, T3 x1.10, T4 x1.00. Edit TIER in src/05d_char.js to change it.
- CUSTOM CONTROLS (main menu): drag any button or the joystick anywhere on screen. Stored per save.
  RESET LAYOUT restores the default positions.
- Battle timer is 200 seconds.
- Each fighter has a unique stance and signature effect shape (SIG_STYLE in src/05d_char.js).
- New hairstyles (bob, ponytail, flowing) with highlights on all hair.

ROUND 3 ADDITIONS
- Title intro on launch: moon rises, characters slide in and pop, logo letters pop in.
  Tap, click, or press any key to continue (auto-continues after 9 seconds).
  On the first tap the game requests fullscreen and a landscape lock (browsers only allow this after a tap).
- Tanjiro is Tier 2; Zenitsu is Tier 3 (edit TIER in src/05d_char.js).
- Long hair for every fighter (length per character in HAIR_LEN, src/05d_char.js).
- Inosuke wears a boar-head mask with tusks and a snout.
- Shaded coats, hakama and obi, detailed eyes, and a haori collar on every fighter.

ROUND 4 ADDITIONS
- QUICK FIGHT (main menu): pick any fighter for yourself and for the opponent, plus difficulty.
- Four more fighters: Sabito, Makomo, Kaigaku, Shinjuro Rengoku (35 total).
- Bots are harder: lower reaction time, more aggression and blocking, and they punish stuns.
- Faces are solid black with glowing eyes (Inosuke keeps his boar mask). Clothes have trim and new patterns
  (scales, dots, triangles, checks, stripes), set per fighter in PT_OVERRIDE in src/05d_char.js.
- Very long hair for every fighter with hair (HAIR_LEN in src/05d_char.js).
- Background music is a procedurally generated relaxed Japanese-style track (pentatonic choir pads, flute,
  soft taiko). It is original and does not reproduce any copyrighted soundtrack. Use Settings > Custom Music for your own track.
- Intro shows more characters from the cast.

NOT INCLUDED
- Online multiplayer (needs a server).
- Official anime soundtrack and voice lines (copyrighted; use Settings > Custom Music).
- Full anime cast beyond the 31 listed; unique movesets for every character (several share attack types).
- Android packaging; Beginner/Standard/Advanced control presets.

Saves use localStorage with a hash check; edited save data resets progress.

ROUND 5 ADDITIONS
- Training mode: pick any fighter as your opponent (Quick Fight-style setup screen).
- Quick Fight and Training Arena both list all 35 fighters.
- Story mode: 10 new worlds (3-12), 23 stages total, paged by world with < and > buttons. Cutscenes added for every new stage.
- Demons (CH.dem) have red eyes. Demon eyes show a kanji glyph (demons only; table DEMON_GLYPH in 05d_char.js, approximate, verify against the anime).
- Kokushibo has six eyes.
- Intro: light rays, title shake on impact, speed streaks.
- Skill animations scale by tier: higher-tier fighters (lower tier number) get extra slash arcs, bigger bursts and a tier aura (TIER_FX in 05d_char.js).
- Cooldowns increased: S1 3.2s, S2 3.8s, Ultimate 10s. Ultimate cooldown ring shown on the HUD.

ROUND 6 ADDITIONS
- Finisher cutscene: when your fighter wins a match by killing the enemy, a god-like finishing cinematic plays before the results. Each of the 35 fighters has their own technique name and line (FINISH table in src/05g_finish.js). Click or press Enter to skip. Not shown in training.

ROUND 7 ADDITIONS
- Ultimate cutscene: when you use an ultimate in any battle, the fight pauses, your fighter powers up in a cinematic with a unique ultimate name and line for every character (ULT_CUT table in src/05h_ultcut.js), then the ultimate attack plays. Click or press Enter to skip.

ROUND 8 ADDITIONS (partial pass of the master spec)
- 8 more named arenas (Butterfly Mansion, Final Selection Forest, Mugen Train, Swordsmith Village, Infinity Castle, Mount Natagumo, Nighttime Demon Village). Arenas differ by colour, fog and moon; they are not yet full art scenes.
- Settings: Sound Effects and Music volume sliders (0% mutes). Existing story/quick arenas are unchanged.
- Not yet done from the master spec: parries and counters, air attacks, combo system, awakening form, boss phases and boss health bars, character levels and mastery, missions and achievements, collection screen, Survival / Boss Rush / Time Attack / Endless modes, mobile control overhaul, animated victory/defeat screens, parallax backgrounds.

ROUND 9 ADDITIONS
- Swords redrawn for every character: wrapped hilt with pommel, sculpted tsuba guard, steel gradient with a moving sheen, a wavy hamon edge in the character's colour, and glow.
- Demon hands redrawn: segmented palm with fingers, tapered glowing talons with tip glints. Demons (non-sword) now get claws on both hands.

ROUND 10 ADDITIONS
- Cutscenes: the speaking character's mouth animates, and each line is read aloud with a voice pitched per character (browser speech; falls back to silent text if the browser has no speech voices). Narration uses a separate voice. Speech follows the Sound Effects volume and stops when the cutscene ends.
- Walking: gait-based stride with foot lift, double-step body bob, counter-swinging arms with elbow bend, and a lean that follows the stride.
- Attacks (light, heavy, skills): each now has a wind-up, a snapping strike and a recovery, so hits read more clearly.

ROUND 11 ADDITIONS
- Speech: browser voices are used when available (waits for voices, times out and falls back). If the browser has no voices or speech does not start, a synthesized voice plays instead: pitched blips per syllable, one pitch per character. Narration has its own pitch.
- Legs: two-bone knee IK so knees bend forward and feet stay planted during the walk. Footstep dust on each step in battle.
- Swords: glowing tip glint.
- Demon claws: glowing joint highlights on each finger.

ROUND 12 ADDITIONS
- Intro: "MADE BY INFINITY FORGE STUDIO" credit fades in under the title.

ROUND 14 ADDITIONS
- Enemies now use their ultimate reliably (when their ultimate meter is full and they are in range), and it plays the same ultimate cinematic, mirrored.
- Story win: the defeated enemy is sliced diagonally at the start of the cutscene, and the top half slides away before the narration.

ROUND 15 ADDITIONS
- Story win slice: the enemy is now drawn smaller and fully on screen, and the top half is sliced and flies off more clearly.

ROUND 16 ADDITIONS
- Intro subtitle and page title now read PIXEL WAR.
- Sun breathers (Tanjiro, Yoriichi) have a red-white Sun blade with a gold edge.
- Wakuraba (fist demon) has the black clawed hands with red glow.

ROUND 17 ADDITIONS
- PC / laptop: keyboard controls (A/D move, W jump, S or L block, J light, K heavy, U skill 1, I skill 2, O ultimate, Shift or E dash, Esc or P pause) verified; F toggles fullscreen.

ROUND 18 ADDITIONS
- Character art: row 1 of the Demon Slayer Corps roster (Tanjiro, Zenitsu, Inosuke, Kanao, Genya, Sabito, Makomo, Nezuko) replaces the stickman portrait in menus and cutscenes. Other characters still use the stickman until their row is supplied. src/07_art.js holds the images.

ROUND 19 ADDITIONS
- Character art: transparent sprites for Tanjiro, Zenitsu, Inosuke, Nezuko, Kanao, Sabito and Makomo replace the earlier card art in menus and cutscenes. Demon-form sprites are in the file but not yet mapped (game has one Tanjiro and one Nezuko).

ROUND 20 ADDITIONS
- Character art: transparent sprites for the Hashira row (Giyu, Shinobu, Rengoku, Tengen, Muichiro, Sanemi, Obanai, Mitsuri, Gyomei) added. They replace the stickman in menus and cutscenes.
- Battle sprites: every character with art now appears in battle as its sprite, with walking bob and sway, attack lean, block/stun/dead poses, and a hit flash. Characters without art still use the stickman.

ROUND 21 ADDITIONS
- Character art: transparent sprites for Kokushibo, Douma, Akaza, Hantengu, Gyokko, Daki, Gyutaro, Nakime, Kaigaku, Enmu, Rui, Wakuraba, Yoriichi, Muzan (used in menus, cutscenes and battle). The sheet's second Kaigaku and second Daki are not mapped.
- New characters added to the roster: Susamaru, Yushiro, Tanjuro Ubuyashiki, Kagaya Ubuyashiki and Tamayo. Each has stats, a tier, skills, a finisher line and an ultimate line. Roster is now 40 characters.

ROUND 22 ADDITIONS
- Removed characters without a photo: Rokuro, Mukago, Kamanue, Genya and Shinjuro. Story stages that used Rokuro, Mukago and Kamanue now use Susamaru, Tamayo and Yushiro.
- New characters with photos: Aoi Kanzaki, Kiyo Terauchi, Shinobu's Brother, Tengen's Brother, Kagaya's Brother, Tanjuro's Wife, Suma and Kiriya Ubuyashiki. Each has stats, a tier, skills, a finisher line and an ultimate line.
- Yushiro's sprite is replaced with the new photo.
- Roster is now 43 characters.

ROUND 23 ADDITIONS
- Light and heavy attack cards: when the player uses a light or heavy attack, the matching card for Tanjiro, Zenitsu, Inosuke, Nezuko, Kanao or Sabito plays a 2.4 second swing animation at the left of the battle (rotation swing, zoom and light sweep). Heavy swings wider. Other characters have no card yet.
- The animation is drawn from the card images in src/05i_atkcard.js. Demon forms are not mapped to a character yet.

ROUND 24 ADDITIONS
- The light and heavy attack card no longer appears at the side. For Tanjiro, Zenitsu, Inosuke, Nezuko, Kanao and Sabito, the character from the card replaces the battle sprite for 2.4 seconds on the player's light or heavy attack, moving with the fighter and swinging. The card frame is faded out.

ROUND 25 ADDITIONS
- Breathing attack cards for Giyu, Shinobu, Kyojuro Rengoku, Tengen, Muichiro, Sanemi, Obanai, Mitsuri and Gyomei. On light or heavy attack, the matching card takes the fighter's place for 2.4 seconds in place of the sprite. Tanjiro, Zenitsu, Inosuke, Nezuko, Kanao and Sabito keep their earlier cards.

ROUND 26 ADDITIONS
- Breathing swing cards now cover the demons from the latest sheet: Kokushibo, Douma, Akaza, Hantengu, Gyokko, Daki, Gyutaro, Nakime, Kaigaku, Enmu, Rui, Wakuraba, Susamaru, Yushiro, Yoriichi, Muzan, Kagaya Ubuyashiki and Tamayo. Light and heavy attacks for these characters now play the card swing in battle. The second Kaigaku and second Daki on the sheet are not used.

ROUND 27 ADDITIONS
- Breathing swing cards for Yushiro (new card), Aoi Kanzaki, Kiyo Terauchi, Shinobu's Brother, Tengen's Brother, Kagaya's Brother, Tanjuro's Wife and Kiriya Ubuyashiki. Light and heavy attacks play the card swing in battle.

ROUND 28 ADDITIONS
- Menu title now reads DEMON SLAYER with the subtitle PIXEL WAR.
- Story mode has three new worlds: 13 Shrine of Shadows, 14 Storm of the Hashira and 15 The Last Moon, with nine new stages (32 total). Each new stage has its own cutscene.

ROUND 29 ADDITIONS
- Login screen after the intro: players log in with a username and password, or create a new account. Usernames are unique (case-insensitive); a taken name is refused. Passwords are stored as SHA-256 hashes with a per-account salt.
- Accounts are saved in this browser only (localStorage key ds_accounts_v1). Uniqueness is enforced on this device; accounts on other devices are not checked.
- The menu shows the logged-in player name.

ROUND 30 ADDITIONS (ONLINE)
- server/server.js is a Node WebSocket server. It provides:
  - accounts with unique usernames (case-insensitive) and scrypt-hashed passwords
  - levels 1 to 200. Each level needs 1000 + 25 x level XP.
  - quick 1v1 matches give 500 to 2000 random XP to both players
  - ranked 1v1 unlocks at level 20 and gives 3000 to 5000 random XP. Each ranked win gives +25 RP and each loss gives -15 RP.
  - ranks by RP: Bronze 0, Silver 200, Gold 500, Platinum 900, Diamond 1400, Master 2000
  - create party gives a random 6-digit code. A second player joins with the code and the match starts.
  - match inputs are relayed between the two players
- Run it: cd server, npm install, npm start (PORT and DATA_FILE can be set as environment variables).
- The game connects to SERVER_URL at the top of src/05k_online.js (default ws://localhost:8080). Change it to your deployed server (wss:// behind HTTPS) and rebuild.
- If the server is offline, login uses a local account on this device.

LIMITS
- The server is a single process with state in memory and accounts saved to a JSON file. It is not a 100,000-player deployment. That needs several server instances, a shared matchmaking store (for example Redis), a real database (for example PostgreSQL), TLS, and load testing. Nothing here has been load tested.
- Each player's fight is simulated on their own device. Inputs are relayed, but the two copies can drift slightly.
- The server trusts the first result reported by a match. A modified client can report a win.

ROUND 31 ADDITIONS (ONLINE, SYNCED FIGHTS)
- Online fights run in lockstep. Each player's input is sent for a fixed tick 6 steps (100 ms) ahead, and both devices advance only when they have both players' inputs. The battle uses a fixed 60 steps per second. In testing, two browser clients stayed identical across 181 ticks with hits (zero mismatches).
- Each player's fighter spawns on their side (left or right), and the update order is fixed by side so both copies resolve hits the same way.
- The opponent's health is their character's health, not the difficulty value.
- Server: per-connection rate limit on relayed inputs, 30-second heartbeat to drop dead connections, and a connection cap.
- Deployment: server/Dockerfile and server/docker-compose.yml. Set SERVER_URL in src/05k_online.js to your server address (wss:// behind HTTPS) and rebuild.
- Load check on one server process: 2000 open connections, all accepted in about 1.4 seconds, server still responding. Not tested at 100,000 players.
- Still open: the Docker image has not been built here (Docker is not available in this environment). The server trusts the first result reported by a match.
- server/render.yaml is a Render blueprint (Docker, always-on plan, persistent disk). It is not tested.

ROUND 32 ADDITIONS
- Login is remembered on this browser. Once you log in, the game opens the menu directly on later launches. Clearing site data (or uninstalling) asks for login again.
- Online accounts use a server login token that stays valid until the account is changed. Local accounts (offline fallback) are remembered the same way.
- The ONLINE MULTIPLAYER menu item shows "Coming soon".

ROUND 33 ADDITIONS
- On a portrait phone the game now turns itself to landscape on launch. Taps, login and party code boxes follow the rotated view. The old "rotate your device" message is gone. Browsers can't rotate the screen on their own, so the game is drawn rotated.

Round 34 - In-game keyboard for login
- The login screen no longer uses the phone's on-screen keyboard. Username and password are typed on a built-in keyboard drawn inside the game, which turns with the rotated view from the start.
- Keys: letters, digits, _, SHIFT, DEL, TAB (switch field), SPACE, ENTER (submit). Physical keyboards also work.
- Username: 3-16 letters, digits or _. Password: at least 4 characters.
- Source: src/05j_login.js (drawKeyboard, loginKeyPress, loginSubmit).

Round 35 - Fullscreen
- The game asks for fullscreen on your first tap or key press, and again on any later tap or key press while it is not fullscreen. Browsers don't allow fullscreen without a tap or key press, so it can't start on page load.
- Once fullscreen, the game locks to landscape where the browser supports it (Android Chrome). iPhone Safari does not support fullscreen for web pages, so there the game runs in the normal browser view.
- F still toggles fullscreen on or off.
- Source: src/06_screens.js (enterFullscreen, lockLandscape, firstTap).

Round 36 - Owner account
- Logging in as Owner_iqrama (password iqrama) unlocks all characters, all story stages and sets coins to 999,999,999 on that device. Source: src/05j_login.js (applyOwnerUnlock).
- The password is visible in the shipped code. Remove the applyOwnerUnlock block before sharing the game publicly.

Round 37 - Light and heavy attack cards removed
- The breathing-style card that replaced the fighter during light and heavy attacks is gone, along with its card images (src/05i_atkcard.js, src/04_logic.js).
- Normal light and heavy swings, their effects and sounds are unchanged.

Round 38 - Multiple accounts and maps
- Each account has its own progress (coins, unlocks, story). Create as many accounts as you like; names are unique.
- LOG OUT in the main menu returns to the login screen so you can log into or create another account.
- Maps (src/05l_maps.js, 5 images). Story: world number cycles through the 5 maps. Offline, quick fight and training: the arena number picks the map (arena mod 5). Online: arena 0 picks map 0.
- Progress saved before the update is kept under the old shared save key and does not transfer to accounts.

Round 39 - Walking and fight animation
- Characters with sprite art now get a walk cycle (stride bob, forward lean, footfall squash), idle breathing, jump stretch, and a squash and dust burst on landing.
- Attacks have wind-up, lunge and recovery. Heavy moves and ults are stronger than light moves.
- Fast movement and strikes leave a short motion trail.
- Source: src/07_art.js (drawSpriteFighter).

Round 40 - Landscape maps and map picker
- Removed the two vertical maps. There are now 3 landscape maps: Castle, Forest, Harbor. Each fills the screen with no side bars.
- MAP button on Story, Offline Battle, Quick Fight and Training Arena. It cycles AUTO, Castle, Forest, Harbor. The choice is saved per account.
- AUTO keeps the old rules: story world number, or the arena number for other modes.
- Source: src/05l_maps.js (mapFor, cycleMap, mapLabel).

Round 41 - Five new maps (replaces image maps)
- All image maps removed. Five new maps are drawn in code with layered scenery and animation: Castle (moonlit castle, drifting clouds), Lanterns (forest with swaying lanterns and fireflies), Harbor (sunset dock with sea shimmer and gulls), Bamboo (grove with swaying stalks and falling leaves), Blossom (shrine with torii gate, lanterns and blossom trees).
- Map picker (MAP button) cycles AUTO and the five maps. The chosen map is saved per account.
- Source: src/05l_maps.js (MAP_PAINT).
