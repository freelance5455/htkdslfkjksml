#!/bin/sh
# Rebuilds index.html from src/ parts in order.
cd "$(dirname "$0")"
cat src/01_head.html src/02_core.js src/03_fighter.js src/04_logic.js src/05_render_battle.js src/05b_fx.js src/05c_extras.js src/05d_char.js src/05e_intro.js src/05f_quick.js src/05g_finish.js src/05h_ultcut.js src/05i_atkcard.js src/05l_maps.js src/05j_login.js src/05k_online.js src/07_art.js src/06_screens.js src/09_tail.html > index.html
echo "Built index.html"
