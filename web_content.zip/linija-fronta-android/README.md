# Linija Fronta – Android build

This folder is a complete Android Studio project. It wraps the game (`app/src/main/assets/index.html`)
in a fullscreen, landscape WebView. Everything runs offline: graphics, fonts and the soundtrack are inside the file.

## Option A: Android Studio (on your computer)
1. Install Android Studio and open this folder (File → Open).
2. Let it finish syncing (first time downloads the Android tools).
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. The APK lands in `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and open it
   (Android will ask you to allow installs from that source).

## Option B: GitHub builds it for you (no Android Studio)
1. Create a new GitHub repository and upload the contents of this folder (including the hidden `.github` folder).
2. Open the repository's **Actions** tab; the "Build APK" workflow runs automatically.
3. When it finishes (about 3–5 minutes), open the run and download **linija-fronta-apk** from Artifacts.

## Controls on the phone
Left thumb: move. Drag on the right side: look around (also up/down). PALI: fire. 1/2: cycle weapons. F: squad follow/hold.
The Android back button opens the pause menu.

## Updating the game
Replace `app/src/main/assets/index.html` with a newer `linija-fronta.html` and build again.
