# Sabzi Luxe Billing — Android Project

આ પ્રોજેક્ટ તમારા હાલના `sabzi_luxe_pappa_simple_qr_offline.html` બિલિંગ પેજને Android WebView એપ તરીકે પેક કરે છે.

## ખાસ નોંધ
- આ **Android Studio project** છે, તૈયાર/બિલ્ડ થયેલી APK નથી.
- `minSdk 26` એટલે Android 8.0 અથવા ઉપરનું લક્ષ્ય રાખ્યું છે; દરેક ફોન પર વાસ્તવિક ટેસ્ટ કરવો જરૂરી છે.
- એપમાં WebView DOM storage ચાલુ છે અને HTML એપનું સ્થાનિક URL `file:///android_asset/index.html` છે.
- એપ uninstall કરવાથી અથવા App data clear કરવાથી સ્થાનિક ડેટા ગુમાઈ શકે છે. નિયમિત રીતે Backup લો અને બેકઅપ ફાઇલ અલગ રાખો.
- UPI QR માં બિલની રકમ ઉમેરાય છે; ચુકવણી સફળ થઈ કે નહીં તે Paytm/બેંકમાં જાતે ચકાસવું.

## APK બનાવવાની રીત
1. કમ્પ્યુટર પર Android Studio અને JDK 17 ઇન્સ્ટોલ કરો.
2. Android Studio ખોલો → **Open** → આ ZIPમાંથી બહાર કાઢેલું `SabziLuxe_Android_Project` ફોલ્ડર પસંદ કરો.
3. Gradle Sync પૂરો થવા દો. જરૂર પડે તો Android SDK Platform 35 ઇન્સ્ટોલ કરો.
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)** પસંદ કરો.
5. APK સામાન્ય રીતે `app/build/outputs/apk/debug/app-debug.apk` માં મળશે.
6. APK તમારા ફોનમાં મોકલો. ફોન પૂછે તો આ ફાઇલ મેનેજર/બ્રાઉઝરને “Install unknown apps” મંજૂરી આપો, પછી APK ઇન્સ્ટોલ કરો.

## પપ્પાના ફોનમાં ડેટા સુરક્ષિત રાખવા
- એપમાં ભાવ/સ્ટોક સેટ કર્યા પછી Backup બનાવો.
- ફોન બદલતા પહેલા Backup લો અને નવી ઇન્સ્ટોલેશનમાં Restore કરો.
- પહેલાં નાની ટેસ્ટ બિલ બનાવો, બેકઅપ/રીસ્ટોર ચકાસો અને પછી વાસ્તવિક ઉપયોગ શરૂ કરો.
