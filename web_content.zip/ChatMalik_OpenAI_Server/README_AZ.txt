CHATMALIK — OPENAI SERVER PAKETİ

Bu ZIP-də:
- public/: ChatMalik-in sadə veb interfeysi
- server.js: OpenAI API-yə server tərəfdən sorğu göndərən backend
- package.json: Node.js asılılıqları

İŞƏ SALMA:
1. ZIP-i Node.js dəstəkləyən hostinqə yüklə.
2. Build/Install əmri: npm install
3. Start əmri: npm start
4. Hostinqin Environment Variables bölməsində:
   OPENAI_API_KEY = öz yeni OpenAI API açarın
   OPENAI_MODEL = gpt-4o-mini  (istəyə bağlı)
5. Deploy et və verilən HTTPS ünvanını aç.
6. /api/health ünvanında {"ok":true,...} görünməlidir.

TƏHLÜKƏSİZLİK:
- API açarını index.html, app.js və ya ZIP-in içinə yazma.
- Açarı yalnız hostinqin gizli Environment Variables bölməsinə əlavə et.
- Söhbət funksiyası üçün OpenAI API hesabında aktiv API billing/kredit tələb oluna bilər.

QEYD:
Bu ZIP hazır server kodudur, lakin öz-özünə internetdə yayımlanmır.
Hostinq hesabına yerləşdirilməli və OPENAI_API_KEY serverdə təyin edilməlidir.
