const form = document.getElementById("chat-form");
const input = document.getElementById("prompt");
const messagesEl = document.getElementById("messages");
const send = document.getElementById("send");
const statusEl = document.getElementById("status");
const history = [];

function addMessage(role, content) {
  const el = document.createElement("div");
  el.className = `bubble ${role}`;
  el.textContent = content;
  messagesEl.appendChild(el);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function checkServer() {
  try {
    const r = await fetch("/api/health");
    statusEl.textContent = r.ok ? "Server aktivdir" : "Server xətası";
  } catch {
    statusEl.textContent = "Serverə qoşulmayıb";
  }
}
checkServer();

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  addMessage("user", text);
  history.push({ role: "user", content: text });
  input.value = "";
  send.disabled = true;
  send.textContent = "Gözlə…";
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Sorğu alınmadı.");
    addMessage("assistant", data.reply);
    history.push({ role: "assistant", content: data.reply });
  } catch (error) {
    addMessage("assistant", "Xəta: " + error.message);
  } finally {
    send.disabled = false;
    send.textContent = "Göndər";
    input.focus();
  }
});
