/* =========================================================================
   scrypt — دالة اشتقاق مفتاح مقاومة للعتاد (RFC 7914).
   -------------------------------------------------------------------------
   لماذا ننفّذها هنا؟ Web Crypto لا يدعم scrypt، لكننا نحتاج نفس المعاملات
   على الجوال (JS) وعلى الكمبيوتر (Node) ليتوافق الملف بين الجهازين.
   جزء PBKDF2-HMAC-SHA256 نحسبه عبر Web Crypto (بسرعة الأصل)،
   والجزء الثقيل (ROMix) نحسبه في JS.
   ========================================================================= */
'use strict';

const SCRYPT = (() => {
  const enc = new TextEncoder();

  /* --------------------------------------------------- أدواتworking */

  function u32(buf, off) {
    return (buf[off] | (buf[off + 1] << 8) | (buf[off + 2] << 16) | (buf[off + 3] << 24)) >>> 0;
  }

  function w32(buf, off, val) {
    buf[off] = val & 0xff;
    buf[off + 1] = (val >>> 8) & 0xff;
    buf[off + 2] = (val >>> 16) & 0xff;
    buf[off + 3] = (val >>> 24) & 0xff;
  }

  function rotl(a, b) {
    return ((a << b) | (a >>> (32 - b))) >>> 0;
  }

  /* ------------------------------------------------- PBKDF2-HMAC-SHA256 */

  async function pbkdf2(passwordBytes, saltBytes, iterations, dkLen) {
    const base = await crypto.subtle.importKey(
      'raw', passwordBytes, 'PBKDF2', false, ['deriveBits'],
    );
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt: saltBytes, iterations, hash: 'SHA-256' },
      base,
      dkLen * 8,
    );
    return new Uint8Array(bits);
  }

  /* ------------------------------------------------------- Salsa20/8 core */

  /**
   * Salsa20/8 على 64 بايت (16 كلمة uint32 little-endian).
   * @param {Uint8Array} out ناتج 64 بايت
   * @param {Uint8Array} inp مدخل 64 بايت
   * @param {number} off إزاحة المدخل
   */
  function salsa20_8(out, inp, off) {
    const x = new Uint32Array(16);
    for (let i = 0; i < 16; i += 1) x[i] = u32(inp, off + i * 4);

    const x00 = x[0]; const x01 = x[1]; const x02 = x[2]; const x03 = x[3];
    const x04 = x[4]; const x05 = x[5]; const x06 = x[6]; const x07 = x[7];
    const x08 = x[8]; const x09 = x[9]; const x10 = x[10]; const x11 = x[11];
    const x12 = x[12]; const x13 = x[13]; const x14 = x[14]; const x15 = x[15];

    let v0 = x00; let v1 = x01; let v2 = x02; let v3 = x03;
    let v4 = x04; let v5 = x05; let v6 = x06; let v7 = x07;
    let v8 = x08; let v9 = x09; let v10 = x10; let v11 = x11;
    let v12 = x12; let v13 = x13; let v14 = x14; let v15 = x15;

    for (let round = 0; round < 8; round += 2) {
      // ── جولة الأعمدة ──
      v4 = (v4 ^ rotl((v0 + v12) >>> 0, 7)) >>> 0;
      v8 = (v8 ^ rotl((v4 + v0) >>> 0, 9)) >>> 0;
      v12 = (v12 ^ rotl((v8 + v4) >>> 0, 13)) >>> 0;
      v0 = (v0 ^ rotl((v12 + v8) >>> 0, 18)) >>> 0;
      v9 = (v9 ^ rotl((v5 + v1) >>> 0, 7)) >>> 0;
      v13 = (v13 ^ rotl((v9 + v5) >>> 0, 9)) >>> 0;
      v1 = (v1 ^ rotl((v13 + v9) >>> 0, 13)) >>> 0;
      v5 = (v5 ^ rotl((v1 + v13) >>> 0, 18)) >>> 0;
      v14 = (v14 ^ rotl((v10 + v6) >>> 0, 7)) >>> 0;
      v2 = (v2 ^ rotl((v14 + v10) >>> 0, 9)) >>> 0;
      v6 = (v6 ^ rotl((v2 + v14) >>> 0, 13)) >>> 0;
      v10 = (v10 ^ rotl((v6 + v2) >>> 0, 18)) >>> 0;
      v3 = (v3 ^ rotl((v15 + v11) >>> 0, 7)) >>> 0;
      v7 = (v7 ^ rotl((v3 + v15) >>> 0, 9)) >>> 0;
      v11 = (v11 ^ rotl((v7 + v3) >>> 0, 13)) >>> 0;
      v15 = (v15 ^ rotl((v11 + v7) >>> 0, 18)) >>> 0;

      // ── جولة الصفوف ──
      v1 = (v1 ^ rotl((v0 + v3) >>> 0, 7)) >>> 0;
      v2 = (v2 ^ rotl((v1 + v0) >>> 0, 9)) >>> 0;
      v3 = (v3 ^ rotl((v2 + v1) >>> 0, 13)) >>> 0;
      v0 = (v0 ^ rotl((v3 + v2) >>> 0, 18)) >>> 0;
      v6 = (v6 ^ rotl((v5 + v4) >>> 0, 7)) >>> 0;
      v7 = (v7 ^ rotl((v6 + v5) >>> 0, 9)) >>> 0;
      v4 = (v4 ^ rotl((v7 + v6) >>> 0, 13)) >>> 0;
      v5 = (v5 ^ rotl((v4 + v7) >>> 0, 18)) >>> 0;
      v11 = (v11 ^ rotl((v10 + v9) >>> 0, 7)) >>> 0;
      v8 = (v8 ^ rotl((v11 + v10) >>> 0, 9)) >>> 0;
      v9 = (v9 ^ rotl((v8 + v11) >>> 0, 13)) >>> 0;
      v10 = (v10 ^ rotl((v9 + v8) >>> 0, 18)) >>> 0;
      v12 = (v12 ^ rotl((v15 + v14) >>> 0, 7)) >>> 0;
      v13 = (v13 ^ rotl((v12 + v15) >>> 0, 9)) >>> 0;
      v14 = (v14 ^ rotl((v13 + v12) >>> 0, 13)) >>> 0;
      v15 = (v15 ^ rotl((v14 + v13) >>> 0, 18)) >>> 0;
    }

    w32(out, off + 0, (x00 + v0) >>> 0);
    w32(out, off + 4, (x01 + v1) >>> 0);
    w32(out, off + 8, (x02 + v2) >>> 0);
    w32(out, off + 12, (x03 + v3) >>> 0);
    w32(out, off + 16, (x04 + v4) >>> 0);
    w32(out, off + 20, (x05 + v5) >>> 0);
    w32(out, off + 24, (x06 + v6) >>> 0);
    w32(out, off + 28, (x07 + v7) >>> 0);
    w32(out, off + 32, (x08 + v8) >>> 0);
    w32(out, off + 36, (x09 + v9) >>> 0);
    w32(out, off + 40, (x10 + v10) >>> 0);
    w32(out, off + 44, (x11 + v11) >>> 0);
    w32(out, off + 48, (x12 + v12) >>> 0);
    w32(out, off + 52, (x13 + v13) >>> 0);
    w32(out, off + 56, (x14 + v14) >>> 0);
    w32(out, off + 60, (x15 + v15) >>> 0);
  }

  /* ------------------------------------------------------------ BlockMix */

  /**
   * BlockMix: يخلط 2r كتلة (128r بايت) — RFC 7914 §5.
   * inBuf/outBuf بطول 128r، sX 64 بايت، sY 128r، T 64 بايت.
   */
  function blockMix(inBuf, outBuf, r, sX, sY, T) {
    sX.set(inBuf.subarray((2 * r - 1) * 64, 2 * r * 64));
    for (let i = 0; i < 2 * r; i += 1) {
      for (let j = 0; j < 64; j += 1) T[j] = sX[j] ^ inBuf[i * 64 + j];
      salsa20_8(sX, T, 0);
      const dst = (i % 2 === 0) ? (i / 2) : (r + (i - 1) / 2);
      sY.set(sX, dst * 64);
    }
    outBuf.set(sY);
  }

  /* -------------------------------------------------------------- ROMix */

  function romix(B, r, N, V) {
    const blockLen = 128 * r;
    let xa = new Uint8Array(blockLen);
    let xb = new Uint8Array(blockLen);
    const sX = new Uint8Array(64);
    const sY = new Uint8Array(blockLen);
    const T = new Uint8Array(64);
    let tmp;

    xa.set(B);

    for (let i = 0; i < N; i += 1) {
      V.set(xa, i * blockLen);
      blockMix(xa, xb, r, sX, sY, T);
      tmp = xa; xa = xb; xb = tmp;
    }

    for (let i = 0; i < N; i += 1) {
      // Integerify: أول 4 بايت من آخر كتلة (little-endian)
      const j = u32(xa, (2 * r - 1) * 64) % N;
      for (let k = 0; k < blockLen; k += 1) xa[k] ^= V[j * blockLen + k];
      blockMix(xa, xb, r, sX, sY, T);
      tmp = xa; xa = xb; xb = tmp;
    }

    B.set(xa);
  }

  /* -------------------------------------------------------------- scrypt */

  /**
   * scrypt(password, salt, N, r, p, dkLen) → Promise<Uint8Array>
   * @param {string|Uint8Array} password
   * @param {string|Uint8Array} salt
   */
  async function scrypt(password, salt, N, r, p, dkLen) {
    const pwd = typeof password === 'string' ? enc.encode(password) : password;
    const slt = typeof salt === 'string' ? enc.encode(salt) : salt;
    const blockLen = 128 * r;

    // 1) B = PBKDF2-HMAC-SHA256(pwd, salt, 1, p * 128 * r)
    const B = await pbkdf2(pwd, slt, 1, p * blockLen);

    // 2) ROMix لكل كتلة
    const V = new Uint8Array(N * blockLen);
    for (let i = 0; i < p; i += 1) {
      romix(B.subarray(i * blockLen, (i + 1) * blockLen), r, N, V);
    }

    // 3) dk = PBKDF2-HMAC-SHA256(pwd, B, 1, dkLen)
    return pbkdf2(pwd, B, 1, dkLen);
  }

  return { scrypt, pbkdf2 };
})();

window.SCRYPT = SCRYPT;
