package com.dompetku.finalapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_CREATE = 4101, REQ_OPEN = 4102;
    private String pendingBackup = "";
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }
    public class Bridge {
        @JavascriptInterface public void exportBackup(String json, String filename) {
            pendingBackup = json;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.setType("application/json"); i.putExtra(Intent.EXTRA_TITLE, filename); startActivityForResult(i, REQ_CREATE);
        }
        @JavascriptInterface public void requestRestore() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/json"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, REQ_OPEN);
        }
    }
    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (result != RESULT_OK || data == null) return;
        try {
            Uri u = data.getData();
            if (req == REQ_CREATE) {
                try (OutputStream out = getContentResolver().openOutputStream(u)) { out.write(pendingBackup.getBytes(StandardCharsets.UTF_8)); }
                webView.evaluateJavascript("nativeBackupDone(true)", null);
            } else if (req == REQ_OPEN) {
                try (InputStream in = getContentResolver().openInputStream(u); ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
                    byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) buf.write(b, 0, n);
                    String json = new String(buf.toByteArray(), StandardCharsets.UTF_8);
                    webView.evaluateJavascript("nativeRestore(" + org.json.JSONObject.quote(json) + ")", null);
                }
            }
        } catch (Exception e) { webView.evaluateJavascript("nativeBackupDone(false)", null); }
    }
    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}
