DompetKu FINAL 1.0

Format: project Android siap diekstrak lalu dibuka di aplikasi builder Android di HP.
Package: com.dompetku.finalapp
Tidak memakai login, server, cloud, atau sinkronisasi bank. Data inti tersimpan lokal.
Ikon header menggunakan logo.png yang berada langsung di assets agar WebView tidak mengalami broken image.
