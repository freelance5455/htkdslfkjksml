package com.javidmusic.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 4107;
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new AudioWebViewClient());
        webView.addJavascriptInterface(new JavidBridge(this), "AndroidJavidMusic");
        webView.loadUrl("file:///android_asset/www/index.html");
        setContentView(webView);
    }

    private boolean hasAudioPermission() {
        String p = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAudioPermission() {
        if (hasAudioPermission()) { sendSongs(); return; }
        String p = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        requestPermissions(new String[]{p}, REQ_AUDIO);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_AUDIO) {
            if (hasAudioPermission()) sendSongs();
            else webView.evaluateJavascript("window.onNativeMusicPermissionDenied && window.onNativeMusicPermissionDenied()", null);
        }
    }

    private void sendSongs() {
        new Thread(() -> {
            JSONArray arr = querySongs();
            runOnUiThread(() -> webView.evaluateJavascript("window.onNativeSongs(" + JSONObject.quote(arr.toString()) + ")", null));
        }).start();
    }

    private JSONArray querySongs() {
        JSONArray out = new JSONArray();
        ContentResolver cr = getContentResolver();
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.MIME_TYPE};
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String sort = MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC";
        try (Cursor c = cr.query(collection, projection, selection, null, sort)) {
            if (c == null) return out;
            int idCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID), titleCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE), artistCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST), albumCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM), durCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION), mimeCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE);
            while(c.moveToNext()) {
                try {
                    long id=c.getLong(idCol); JSONObject o=new JSONObject();
                    o.put("id", "media_"+id); o.put("mediaId", id);
                    o.put("title", safe(c.getString(titleCol), "آهنگ")); o.put("artist", safe(c.getString(artistCol), "هنرمند نامشخص"));
                    o.put("album", safe(c.getString(albumCol), "")); o.put("duration", c.getLong(durCol)); o.put("mime", safe(c.getString(mimeCol), "audio/mpeg"));
                    out.put(o);
                } catch(Exception ignored) {}
            }
        } catch(Exception ignored) {}
        return out;
    }
    private String safe(String s,String d){ return s==null||s.trim().isEmpty()?d:s; }

    public class JavidBridge {
        private final Context context;
        JavidBridge(Context c){context=c;}
        @JavascriptInterface public void requestMusicPermission(){ runOnUiThread(MainActivity.this::requestAudioPermission); }
        @JavascriptInterface public void refreshMusic(){ if(hasAudioPermission()) sendSongs(); else requestAudioPermission(); }
    }

    private class AudioWebViewClient extends WebViewClient {
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return audioResponse(request.getUrl().toString());
        }
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) { return audioResponse(url); }
        private WebResourceResponse audioResponse(String url) {
            final String prefix="https://javid.local/audio/";
            if(!url.startsWith(prefix)) return null;
            try {
                long id=Long.parseLong(url.substring(prefix.length()).split("[/?#]")[0]);
                Uri u=Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, String.valueOf(id));
                InputStream in=getContentResolver().openInputStream(u);
                if(in==null) return null;
                String mime=getContentResolver().getType(u); if(mime==null)mime="audio/mpeg";
                return new WebResourceResponse(mime,"UTF-8",in);
            } catch(Exception e){return null;}
        }
    }
}
