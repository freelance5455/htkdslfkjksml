# Javid Music — Native Android

نسخه Native جاوید موزیک با مجوز واقعی Android MediaStore.

- Android 13+: `READ_MEDIA_AUDIO`
- Android 12 و پایین‌تر: `READ_EXTERNAL_STORAGE`
- بعد از اجازه، آهنگ‌های Music/MediaStore به‌صورت خودکار اسکن می‌شوند.
- پخش با URI داخلی برنامه انجام می‌شود و نیاز به انتخاب تک‌تک فایل‌ها نیست.
- Package: `com.javidmusic.app`
- Target SDK: 35

این پروژه برای Build به Android Gradle Plugin 8.7.3 و Gradle 8.x نیاز دارد.
