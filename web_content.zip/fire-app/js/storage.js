/* Fire — persistência local (demonstração) */
const FireStorage = {
  KEY: 'fire_demo_v1',

  load() {
    try {
      const raw = localStorage.getItem(this.KEY);
      if (!raw) return this.defaultState();
      const data = JSON.parse(raw);
      return { ...this.defaultState(), ...data };
    } catch {
      return this.defaultState();
    }
  },

  save(state) {
    try {
      localStorage.setItem(this.KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('FireStorage: falha ao salvar', e);
    }
  },

  defaultState() {
    return {
      session: null,          // { userId }
      users: [],              // contas locais
      conversations: [],      // { id, participants[], lastMessage, updatedAt, unread }
      messages: {}            // { [convId]: [msg...] }
    };
  },

  // Contas de demonstração (claramente fictícias)
  seedDemoUsers(state) {
    if (state.users.some(u => u.isDemo)) return state;

    const demos = [
      {
        id: 'demo_ana',
        displayName: 'Ana (exemplo)',
        handle: 'ana.exemplo',
        email: 'ana@exemplo.local',
        password: 'demo1234',
        isDemo: true,
        createdAt: Date.now() - 86400000 * 3
      },
      {
        id: 'demo_bruno',
        displayName: 'Bruno (exemplo)',
        handle: 'bruno.dev',
        email: 'bruno@exemplo.local',
        password: 'demo1234',
        isDemo: true,
        createdAt: Date.now() - 86400000 * 2
      },
      {
        id: 'demo_carla',
        displayName: 'Carla (exemplo)',
        handle: 'carla.design',
        email: 'carla@exemplo.local',
        password: 'demo1234',
        isDemo: true,
        createdAt: Date.now() - 86400000
      }
    ];

    state.users = [...state.users, ...demos];
    return state;
  }
};
