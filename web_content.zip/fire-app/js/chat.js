/* Fire — conversas e mensagens (local) */
const FireChat = {
  getConversations() {
    const me = FireAuth.currentUser();
    if (!me) return [];
    return (FireAuth.state.conversations || [])
      .filter(c => c.participants.includes(me.id))
      .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  },

  getOrCreateConversation(otherUserId) {
    const me = FireAuth.currentUser();
    if (!me || otherUserId === me.id) return null;

    let conv = (FireAuth.state.conversations || []).find(c =>
      c.participants.length === 2 &&
      c.participants.includes(me.id) &&
      c.participants.includes(otherUserId)
    );

    if (!conv) {
      conv = {
        id: FireUtils.uid(),
        participants: [me.id, otherUserId],
        lastMessage: null,
        updatedAt: Date.now(),
        unread: 0
      };
      FireAuth.state.conversations.push(conv);
      FireAuth.state.messages[conv.id] = [];
      FireStorage.save(FireAuth.state);
    }
    return conv;
  },

  getMessages(convId) {
    return (FireAuth.state.messages[convId] || []).slice();
  },

  sendMessage(convId, text) {
    const me = FireAuth.currentUser();
    if (!me || !text || !text.trim()) return null;

    const msg = {
      id: FireUtils.uid(),
      convId,
      senderId: me.id,
      text: text.trim().slice(0, 4000),
      createdAt: Date.now(),
      status: 'sent' // local only
    };

    if (!FireAuth.state.messages[convId]) FireAuth.state.messages[convId] = [];
    FireAuth.state.messages[convId].push(msg);

    const conv = FireAuth.state.conversations.find(c => c.id === convId);
    if (conv) {
      conv.lastMessage = { text: msg.text, senderId: me.id, at: msg.createdAt };
      conv.updatedAt = msg.createdAt;
      // em modo local não incrementamos unread para o próprio usuário
    }

    FireStorage.save(FireAuth.state);
    return msg;
  },

  deleteConversation(convId) {
    const me = FireAuth.currentUser();
    if (!me) return;
    FireAuth.state.conversations = FireAuth.state.conversations.filter(c => c.id !== convId);
    delete FireAuth.state.messages[convId];
    FireStorage.save(FireAuth.state);
  },

  markRead(convId) {
    const conv = FireAuth.state.conversations.find(c => c.id === convId);
    if (conv) {
      conv.unread = 0;
      FireStorage.save(FireAuth.state);
    }
  },

  otherParticipant(conv) {
    const me = FireAuth.currentUser();
    if (!me || !conv) return null;
    const otherId = conv.participants.find(id => id !== me.id);
    return FireAuth.getUserById(otherId);
  }
};
