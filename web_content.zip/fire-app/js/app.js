/* Fire — aplicação principal */
(function () {
  'use strict';

  let currentConvId = null;
  let searchDebounced = null;

  // ---------- Navegação de telas ----------
  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const el = document.getElementById(id);
    if (el) el.classList.add('active');
  }

  function showApp() {
    document.getElementById('welcome')?.classList.remove('active');
    document.getElementById('auth')?.classList.remove('active');
    document.getElementById('app')?.classList.add('active');
    renderConversations();
    showSidebar();
  }

  function showSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const chat = document.querySelector('.chat-panel');
    if (sidebar) sidebar.classList.remove('hidden');
    if (chat) {
      chat.classList.remove('open');
      if (window.innerWidth >= 768) {
        // desktop: mantém painel
      } else {
        currentConvId = null;
      }
    }
  }

  function openChat(convId) {
    currentConvId = convId;
    FireChat.markRead(convId);
    renderConversations();
    renderChat();

    const sidebar = document.querySelector('.sidebar');
    const chat = document.querySelector('.chat-panel');
    if (window.innerWidth < 768) {
      if (sidebar) sidebar.classList.add('hidden');
      if (chat) chat.classList.add('open');
    } else {
      if (chat) chat.classList.add('open');
    }
  }

  // ---------- Renderização ----------
  function renderConversations() {
    const list = document.getElementById('conv-list');
    if (!list) return;

    const convs = FireChat.getConversations();
    if (!convs.length) {
      list.innerHTML = `
        <div class="empty-state">
          <svg width="64" height="64" fill="currentColor" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12zM7 9h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z"/></svg>
          <p>Comece uma conversa pesquisando um <strong>@</strong> no campo acima.</p>
          <p style="margin-top:0.75rem;font-size:0.82rem">Contas de exemplo: <code>@ana.exemplo</code>, <code>@bruno.dev</code>, <code>@carla.design</code></p>
        </div>`;
      return;
    }

    list.innerHTML = convs.map(c => {
      const other = FireChat.otherParticipant(c);
      if (!other) return '';
      const preview = c.lastMessage
        ? (c.lastMessage.senderId === FireAuth.currentUser()?.id ? 'Você: ' : '') + c.lastMessage.text
        : 'Nenhuma mensagem ainda';
      const active = c.id === currentConvId ? 'active' : '';
      return `
        <div class="conv-item ${active}" data-id="${c.id}" role="button" tabindex="0">
          <div class="avatar" style="background:${FireUtils.avatarColor(other.handle)}">${FireUtils.initials(other.displayName)}</div>
          <div class="conv-info">
            <div class="conv-name">${FireUtils.escapeHtml(other.displayName)}</div>
            <div class="conv-preview">${FireUtils.escapeHtml(preview)}</div>
          </div>
          <div class="conv-meta">
            <span class="conv-time">${c.lastMessage ? FireUtils.formatTime(c.lastMessage.at) : ''}</span>
            ${c.unread > 0 ? `<span class="unread">${c.unread}</span>` : ''}
          </div>
        </div>`;
    }).join('');

    list.querySelectorAll('.conv-item').forEach(el => {
      el.addEventListener('click', () => openChat(el.dataset.id));
      el.addEventListener('keydown', e => { if (e.key === 'Enter') openChat(el.dataset.id); });
    });
  }

  function renderChat() {
    const panel = document.querySelector('.chat-panel');
    if (!panel) return;

    if (!currentConvId) {
      panel.innerHTML = `
        <div class="empty-chat desktop-only" style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-sec)">
          <img src="assets/fire-logo.png" alt="" width="80" style="opacity:0.35;margin-bottom:1rem">
          <p>Selecione uma conversa</p>
        </div>`;
      return;
    }

    const conv = FireAuth.state.conversations.find(c => c.id === currentConvId);
    const other = FireChat.otherParticipant(conv);
    if (!other) return;

    const msgs = FireChat.getMessages(currentConvId);
    const me = FireAuth.currentUser();

    panel.innerHTML = `
      <div class="chat-header">
        <button class="icon-btn dark mobile-only" id="btn-back" aria-label="Voltar">←</button>
        <div class="avatar" style="background:${FireUtils.avatarColor(other.handle)}">${FireUtils.initials(other.displayName)}</div>
        <div class="info">
          <div class="name">${FireUtils.escapeHtml(other.displayName)}</div>
          <div class="handle">@${FireUtils.escapeHtml(other.handle)}${other.isDemo ? ' · exemplo' : ''}</div>
        </div>
        <button class="icon-btn dark" id="btn-chat-menu" aria-label="Opções">⋮</button>
      </div>
      <div class="messages" id="messages"></div>
      <div class="composer">
        <textarea id="msg-input" rows="1" placeholder="Mensagem" aria-label="Escrever mensagem"></textarea>
        <button class="send-btn" id="btn-send" aria-label="Enviar" disabled>➤</button>
      </div>`;

    const msgBox = document.getElementById('messages');
    msgBox.innerHTML = msgs.map(m => {
      const mine = m.senderId === me.id;
      return `
        <div class="msg ${mine ? 'sent' : 'received'}">
          ${FireUtils.escapeHtml(m.text)}
          <div class="time">${FireUtils.formatTime(m.createdAt)}</div>
        </div>`;
    }).join('');
    msgBox.scrollTop = msgBox.scrollHeight;

    document.getElementById('btn-back')?.addEventListener('click', () => {
      currentConvId = null;
      showSidebar();
      renderConversations();
    });

    document.getElementById('btn-chat-menu')?.addEventListener('click', () => {
      if (confirm('Excluir esta conversa da lista? (apenas neste dispositivo)')) {
        FireChat.deleteConversation(currentConvId);
        currentConvId = null;
        showSidebar();
        renderConversations();
        FireUtils.toast('Conversa removida');
      }
    });

    const input = document.getElementById('msg-input');
    const sendBtn = document.getElementById('btn-send');

    function updateSend() {
      sendBtn.disabled = !input.value.trim();
    }
    input.addEventListener('input', () => {
      updateSend();
      input.style.height = 'auto';
      input.style.height = Math.min(input.scrollHeight, 120) + 'px';
    });
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        doSend();
      }
    });
    sendBtn.addEventListener('click', doSend);

    function doSend() {
      const text = input.value.trim();
      if (!text) return;
      FireChat.sendMessage(currentConvId, text);
      input.value = '';
      input.style.height = 'auto';
      updateSend();
      renderChat();
      renderConversations();
    }

    setTimeout(() => input.focus(), 100);
  }

  // ---------- Pesquisa ----------
  function setupSearch() {
    const input = document.getElementById('search-input');
    const results = document.getElementById('search-results');
    if (!input || !results) return;

    searchDebounced = FireUtils.debounce(() => {
      const q = input.value.trim();
      if (!q) {
        results.classList.remove('visible');
        results.innerHTML = '';
        return;
      }
      const users = FireAuth.findUsersByHandle(q);
      results.classList.add('visible');
      if (!users.length) {
        results.innerHTML = `<div class="search-empty">Nenhum usuário encontrado para “${FireUtils.escapeHtml(q)}”</div>`;
        return;
      }
      results.innerHTML = users.map(u => `
        <div class="search-item" data-id="${u.id}" role="button" tabindex="0">
          <div class="avatar" style="background:${FireUtils.avatarColor(u.handle)}">${FireUtils.initials(u.displayName)}</div>
          <div class="meta">
            <div class="name">${FireUtils.escapeHtml(u.displayName)}${u.isDemo ? ' <span style="font-size:0.75rem;color:var(--warning)">(exemplo)</span>' : ''}</div>
            <div class="handle">@${FireUtils.escapeHtml(u.handle)}</div>
          </div>
        </div>`).join('');

      results.querySelectorAll('.search-item').forEach(el => {
        el.addEventListener('click', () => startChatWith(el.dataset.id));
        el.addEventListener('keydown', e => { if (e.key === 'Enter') startChatWith(el.dataset.id); });
      });
    }, 250);

    input.addEventListener('input', searchDebounced);
    input.addEventListener('focus', () => { if (input.value.trim()) searchDebounced(); });
  }

  function startChatWith(userId) {
    const conv = FireChat.getOrCreateConversation(userId);
    if (!conv) {
      FireUtils.toast('Não é possível conversar consigo mesmo');
      return;
    }
    document.getElementById('search-input').value = '';
    document.getElementById('search-results').classList.remove('visible');
    openChat(conv.id);
  }

  // ---------- Formulários Auth ----------
  function setupAuthForms() {
    // Login
    document.getElementById('form-login')?.addEventListener('submit', e => {
      e.preventDefault();
      clearErrors('form-login');
      const email = document.getElementById('login-email').value;
      const password = document.getElementById('login-password').value;
      const res = FireAuth.login({ email, password });
      if (!res.ok) {
        showError('login-email', res.error);
        return;
      }
      FireUtils.toast('Bem-vindo(a), ' + res.user.displayName);
      showApp();
    });

    // Cadastro
    document.getElementById('form-register')?.addEventListener('submit', e => {
      e.preventDefault();
      clearErrors('form-register');
      const displayName = document.getElementById('reg-name').value;
      const handle = document.getElementById('reg-handle').value;
      const email = document.getElementById('reg-email').value;
      const password = document.getElementById('reg-password').value;
      const password2 = document.getElementById('reg-password2').value;

      if (password !== password2) {
        showError('reg-password2', 'As senhas não coincidem.');
        return;
      }

      const res = FireAuth.register({ displayName, handle, email, password });
      if (!res.ok) {
        Object.entries(res.errors).forEach(([k, msg]) => {
          const map = { displayName: 'reg-name', handle: 'reg-handle', email: 'reg-email', password: 'reg-password' };
          if (map[k]) showError(map[k], msg);
        });
        return;
      }
      FireUtils.toast('Conta criada! Olá, ' + res.user.displayName);
      showApp();
    });
  }

  function showError(inputId, msg) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const group = input.closest('.form-group');
    if (group) {
      group.classList.add('has-error');
      const err = group.querySelector('.error');
      if (err) err.textContent = msg;
    }
  }

  function clearErrors(formId) {
    document.querySelectorAll(`#${formId} .form-group`).forEach(g => {
      g.classList.remove('has-error');
      const err = g.querySelector('.error');
      if (err) err.textContent = '';
    });
  }

  // ---------- Settings ----------
  function openSettings() {
    const user = FireAuth.currentUser();
    if (!user) return;
    showScreen('settings');
    document.getElementById('set-name').textContent = user.displayName;
    document.getElementById('set-handle').textContent = '@' + user.handle;
    document.getElementById('set-email').textContent = user.email;
  }

  // ---------- Init ----------
  function init() {
    FireAuth.init();
    setupAuthForms();
    setupSearch();

    // Botões de navegação
    document.getElementById('btn-create-account')?.addEventListener('click', () => {
      showScreen('auth');
      document.getElementById('auth-login').style.display = 'none';
      document.getElementById('auth-register').style.display = 'block';
    });
    document.getElementById('btn-login')?.addEventListener('click', () => {
      showScreen('auth');
      document.getElementById('auth-login').style.display = 'block';
      document.getElementById('auth-register').style.display = 'none';
    });
    document.getElementById('link-to-register')?.addEventListener('click', e => {
      e.preventDefault();
      document.getElementById('auth-login').style.display = 'none';
      document.getElementById('auth-register').style.display = 'block';
    });
    document.getElementById('link-to-login')?.addEventListener('click', e => {
      e.preventDefault();
      document.getElementById('auth-login').style.display = 'block';
      document.getElementById('auth-register').style.display = 'none';
    });
    document.getElementById('btn-back-auth')?.addEventListener('click', () => showScreen('welcome'));

    document.getElementById('btn-settings')?.addEventListener('click', openSettings);
    document.getElementById('btn-back-settings')?.addEventListener('click', () => {
      showScreen('app');
      document.getElementById('app').classList.add('active');
    });
    document.getElementById('btn-logout')?.addEventListener('click', () => {
      if (confirm('Sair da conta?')) {
        FireAuth.logout();
        currentConvId = null;
        showScreen('welcome');
        FireUtils.toast('Você saiu');
      }
    });
    document.getElementById('btn-clear-data')?.addEventListener('click', () => {
      if (confirm('Apagar todos os dados locais deste navegador? Esta ação não pode ser desfeita.')) {
        localStorage.removeItem(FireStorage.KEY);
        FireAuth.logout();
        location.reload();
      }
    });

    // Sessão existente?
    if (FireAuth.isLoggedIn()) {
      showApp();
    } else {
      showScreen('welcome');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
