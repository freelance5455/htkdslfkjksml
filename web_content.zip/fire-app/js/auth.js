/* Fire — autenticação local (demonstração) */
const FireAuth = {
  state: null,

  init() {
    this.state = FireStorage.load();
    this.state = FireStorage.seedDemoUsers(this.state);
    FireStorage.save(this.state);
    return this.state.session;
  },

  currentUser() {
    if (!this.state?.session?.userId) return null;
    return this.state.users.find(u => u.id === this.state.session.userId) || null;
  },

  isLoggedIn() {
    return !!this.currentUser();
  },

  register({ displayName, handle, email, password }) {
    const errors = {};
    const name = (displayName || '').trim();
    const h = FireUtils.normalizeHandle(handle);
    const em = (email || '').trim().toLowerCase();
    const pw = password || '';

    if (!name || name.length < 2) errors.displayName = 'Informe um nome com pelo menos 2 caracteres.';
    if (!FireUtils.isValidHandle(h)) {
      errors.handle = 'Use 3 a 24 caracteres: letras, números, ponto ou sublinhado.';
    } else if (this.state.users.some(u => FireUtils.normalizeHandle(u.handle) === h)) {
      errors.handle = 'Este @ já está em uso.';
    }
    if (!FireUtils.isValidEmail(em)) errors.email = 'E-mail inválido.';
    else if (this.state.users.some(u => u.email === em)) errors.email = 'Este e-mail já está cadastrado.';
    if (pw.length < 6) errors.password = 'A senha deve ter pelo menos 6 caracteres.';

    if (Object.keys(errors).length) return { ok: false, errors };

    const user = {
      id: FireUtils.uid(),
      displayName: name,
      handle: h,
      email: em,
      password: pw, // apenas demonstração local — NUNCA faça isso em produção
      isDemo: false,
      createdAt: Date.now()
    };

    this.state.users.push(user);
    this.state.session = { userId: user.id };
    FireStorage.save(this.state);
    return { ok: true, user };
  },

  login({ email, password }) {
    const em = (email || '').trim().toLowerCase();
    const pw = password || '';
    const user = this.state.users.find(u => u.email === em && u.password === pw);
    if (!user) {
      return { ok: false, error: 'E-mail ou senha incorretos.' };
    }
    this.state.session = { userId: user.id };
    FireStorage.save(this.state);
    return { ok: true, user };
  },

  logout() {
    if (this.state) {
      this.state.session = null;
      FireStorage.save(this.state);
    }
  },

  findUsersByHandle(query) {
    const q = FireUtils.normalizeHandle(query);
    if (!q || q.length < 1) return [];
    const me = this.currentUser();
    return this.state.users
      .filter(u => {
        if (me && u.id === me.id) return false;
        const h = FireUtils.normalizeHandle(u.handle);
        const n = (u.displayName || '').toLowerCase();
        return h.includes(q) || n.includes(q);
      })
      .slice(0, 12);
  },

  getUserById(id) {
    return this.state.users.find(u => u.id === id) || null;
  },

  updateProfile({ displayName }) {
    const user = this.currentUser();
    if (!user) return { ok: false };
    if (displayName && displayName.trim().length >= 2) {
      user.displayName = displayName.trim();
      FireStorage.save(this.state);
      return { ok: true, user };
    }
    return { ok: false, error: 'Nome inválido.' };
  }
};
