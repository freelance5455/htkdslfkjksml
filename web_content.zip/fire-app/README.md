# Fire — Aplicativo de Mensagens

**Fire** é um protótipo funcional de mensageiro com identidade visual própria (azul-marinho + chama ciano).  
Este pacote é uma **demonstração local** completa, pensada para ser aberta, testada e evoluída por qualquer pessoa.

## O que funciona de verdade (neste ZIP)

| Recurso | Status |
|---------|--------|
| Tela de boas-vindas + logo oficial | ✅ |
| Cadastro de conta (nome, @, e-mail, senha) | ✅ local |
| Login / logout | ✅ local |
| Validação de @ (3–24 chars, único, normalizado) | ✅ |
| Pesquisa por @ ou nome | ✅ (contas locais + 3 exemplos) |
| Lista de conversas ordenada por atividade | ✅ |
| Envio e leitura de mensagens de texto | ✅ local |
| Layout responsivo (celular / tablet / desktop) | ✅ |
| PWA (instalável no celular e desktop) | ✅ |
| Persistência via `localStorage` | ✅ |
| Estados vazios, erros de formulário, toast | ✅ |

## O que **não** está implementado (e não é fingido)

- Servidor real / banco multiusuário
- Mensagens entre dispositivos ou pessoas diferentes na internet
- Login com Google / OAuth
- Criptografia ponta a ponta auditada
- Notificações push reais
- Upload de arquivos, áudio, vídeo ou chamadas
- Grupos, status/stories, bloqueio no servidor

Tudo isso exige backend, infraestrutura e configuração. O app deixa isso **explícito** na interface e neste README.

## Como executar (site / website)

### Opção 1 — Abrir direto
1. Descompacte o ZIP.
2. Abra `index.html` no navegador (Chrome, Firefox, Edge, Safari).

> Em alguns navegadores o `file://` limita o service worker. Prefira a opção 2.

### Opção 2 — Servidor local (recomendado)
```bash
# Na pasta do projeto
npx --yes serve .
# ou
python3 -m http.server 8080
```
Acesse `http://localhost:3000` (ou a porta indicada).

### Opção 3 — Publicar como website
- Envie a pasta inteira para qualquer hospedagem estática (Netlify, Vercel, GitHub Pages, Cloudflare Pages, S3, etc.).
- Não há variáveis de ambiente obrigatórias.

## Contas de exemplo (demonstração)

| E-mail | Senha | @ |
|--------|-------|---|
| ana@exemplo.local | demo1234 | @ana.exemplo |
| bruno@exemplo.local | demo1234 | @bruno.dev |
| carla@exemplo.local | demo1234 | @carla.design |

Você também pode criar sua própria conta. Os dados ficam **somente** no navegador.

## Estrutura do projeto

```
fire-app/
├── index.html
├── manifest.json      # PWA
├── sw.js              # Service Worker
├── README.md
├── assets/
│   └── fire-logo.png  # Logo oficial
├── css/
│   └── styles.css
└── js/
    ├── utils.js
    ├── storage.js
    ├── auth.js
    ├── chat.js
    └── app.js
```

## Converter para APK (Android)

Este projeto é uma **web app / PWA**. Para gerar um APK:

### Caminho recomendado — Capacitor (ou Cordova)
1. Instale Node.js e o Android Studio (SDK).
2. Na pasta do projeto:
```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init Fire com.fire.app --web-dir .
npx cap add android
npx cap sync
npx cap open android
```
3. No Android Studio: Build → Build Bundle(s) / APK(s).

### Alternativa rápida — PWA Builder / Bubblewrap
- Acesse [www.pwabuilder.com](https://www.pwabuilder.com), informe a URL publicada do site e gere o pacote Android.

### Limitação importante
Um APK gerado a partir deste código continua sendo a **mesma demonstração local**.  
Mensagens reais entre usuários exigem backend (API + banco + autenticação + WebSocket ou similar).

## Segurança (modo demonstração)

- Senhas são armazenadas em texto no `localStorage` **apenas para demo**.  
  Em produção use hashing (bcrypt/argon2) no servidor e nunca no cliente.
- Não há proteção contra XSS em mensagens além de escape de HTML.
- Não use este código como base de produção sem revisão de segurança completa.

## Próximos passos sugeridos

1. Backend (Node/Express, Supabase, Firebase, etc.)
2. Autenticação real + JWT / sessões
3. WebSocket ou polling para mensagens em tempo real
4. Upload de mídia com storage privado
5. Notificações push
6. Testes automatizados e CI

---

**Fire** — comunicação rápida, confiável e simples.  
Logo e identidade conforme especificação oficial do projeto.
