PANCHAL BUSINESS MANAGER - APK FORGE WEB ROOT

This ZIP is flattened for tools that open index.html directly.
Import/extract the ZIP so index.html is at the web root, with css/, js/, vendor/, manifest.json and sw.js beside it.
Do NOT open the original nested project folder or src/App.tsx in a plain HTML wrapper.
Start page: index.html
All CSS and JavaScript assets are local.
