# راه‌اندازی رایگان AliChat

برای اجرای دائمی این پروژه به یک ماشین همیشه‌روشن نیاز است. یکی از گزینه‌های رسمی دارای منابع Always Free، Oracle Cloud Infrastructure است. طبق مستندات فعلی Oracle، منابع Always Free شامل VMهای Compute و فضای ذخیره‌سازی است؛ ظرفیت و موجودی منطقه‌ای ممکن است محدود باشد.

## 1) ساخت VM

- یک حساب OCI بسازید.
- یک VM با Ubuntu 24.04 انتخاب کنید.
- برای این پروژه یک VM با حدود 1 تا 2 OCPU و 4 تا 8GB RAM مناسب شروع است.
- یک Public IPv4 اختصاص دهید.
- پورت‌های 22، 80 و 443 را در Security List/NSG باز کنید.

## 2) نصب Docker

روی Ubuntu:

```bash
sudo apt update
sudo apt install -y ca-certificates curl git
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER"
```

بعد از ورود مجدد:

```bash
docker --version
docker compose version
```

## 3) انتقال پروژه

کل ZIP را روی VM منتقل و استخراج کنید:

```bash
unzip AliChat_V3_6_Server_Bundle_PRODUCTION.zip -d alichat
cd alichat
```

## 4) نصب با HTTPS

دامنه خودتان را به IP سرور وصل کنید؛ سپس:

```bash
./setup-server.sh
```

اسکریپت Caddy را اجرا می‌کند و HTTPS را به‌صورت خودکار مدیریت می‌کند.

## 5) آدرس داخل برنامه

در صفحه ورود AliChat، آدرس زیر را وارد کنید:

```text
https://chat.example.com
```

یا اگر APK را دوباره build می‌کنید، مقدار `window.ALICHAT_SERVER_URL` در `apk-config.js` را روی آدرس سرور قرار دهید.

## نکته مهم درباره رایگان بودن

Always Free بودن به معنی تضمین ظرفیت VM در لحظه ساخت نیست؛ Oracle ممکن است در یک منطقه خطای کمبود ظرفیت بدهد. همچنین شرایط Free Tier می‌تواند تغییر کند، بنابراین قبل از ساخت، صفحه رسمی Oracle را بررسی کنید.
