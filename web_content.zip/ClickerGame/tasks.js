// ============================================
//  DEFAULT TASKS
// ============================================

const DEFAULT_TASKS = {

    male: {
    },

    female: {
    }
};
// ===== GAME =====

function doClick() {
    clicks++;
    localStorage.setItem('clicks', clicks);
    updateUI();

    if (clicks % 5 === 0) {
        if (isMultiplayer && roomRef) {
            // Ich habe 5 Clicks → Gegner soll Kategorie wählen
            document.getElementById('waiting-popup').style.display = 'flex';
            document.getElementById('waiting-text').textContent = 'Opponent is choosing a category...';

            roomRef.update({
                waitingPlayer: myPlayerName,   // ich warte
                chooser: null,
                chosenCategory: null
            });
        } else {
            showCategorySelection();
        }
    }

    const btn = document.querySelector('.clicker-btn');
    btn.style.transform = 'scale(0.9)';
    setTimeout(() => btn.style.transform = '', 100);
}

function listenToRoom() {
    if (roomListener) roomRef.off('value', roomListener);

    roomListener = roomRef.on('value', snap => {
        const data = snap.val();
        if (!data) {
            alert('Room closed');
            leaveLobby();
            return;
        }

        renderLobby(data);

        // Beide Ready → Spiel starten
        if (data.hostReady && data.guestReady && data.status === 'waiting') {
            roomRef.update({ status: 'playing' });
        }

        if (data.status === 'playing' && !isMultiplayer) {
            startMultiplayerGame();
        }

        // Jemand wartet auf Kategorie-Auswahl
        if (data.waitingPlayer && data.waitingPlayer !== myPlayerName) {
            // Ich bin der Gegner → ich muss wählen
            if (document.getElementById('category-popup').style.display !== 'flex' &&
                document.getElementById('waiting-popup').style.display !== 'flex') {
                showCategorySelectionForOpponent(data.waitingPlayer);
            }
        }

        // Kategorie wurde für mich gewählt
        if (data.chosenCategory && data.chosenCategory.forPlayer === myPlayerName) {
            document.getElementById('waiting-popup').style.display = 'none';
            document.getElementById('category-popup').style.display = 'none';

            const cat = data.chosenCategory.category;
            const list = TASKS[currentGender][cat];
            if (list && list.length > 0) {
                currentTask = list[Math.floor(Math.random() * list.length)];
                showTask(cat, currentTask, false);
            }

            // zurücksetzen
            roomRef.update({
                waitingPlayer: null,
                chosenCategory: null
            });
        }
    });
}

function showCategorySelectionForOpponent(forPlayer) {
    const cats = Object.keys(TASKS[currentGender]).filter(c => c !== 'punishment');
    const container = document.getElementById('category-buttons');
    container.innerHTML = '';

    document.getElementById('category-popup-title').textContent = 'Choose Category for Opponent';
    document.getElementById('category-popup-hint').textContent = 'Pick a task type for them';

    cats.forEach(cat => {
        const btn = document.createElement('button');
        btn.className = 'category-btn';
        btn.textContent = cat;
        btn.onclick = () => {
            document.getElementById('category-popup').style.display = 'none';
            // Kategorie an den wartenden Spieler schicken
            roomRef.update({
                chosenCategory: {
                    category: cat,
                    forPlayer: forPlayer
                },
                waitingPlayer: null
            });
        };
        container.appendChild(btn);
    });

    document.getElementById('category-popup').style.display = 'flex';
}