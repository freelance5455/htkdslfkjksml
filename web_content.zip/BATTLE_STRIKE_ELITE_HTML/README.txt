BATTLE STRIKE – ELITE (HTML prototype)

HOW TO PLAY
- Open index.html in a modern browser with internet access.
- The Three.js library is loaded from jsDelivr CDN, so the first launch needs internet.
- Desktop: WASD to move, mouse to look (click game to lock pointer), left click to fire, R to reload, Space to jump.
- Android: use the left joystick to move, drag on the right side of the screen to look, FIRE / JUMP / RELOAD buttons.

WHAT THIS IS
A playable early 3D training-zone prototype using HTML, CSS, JavaScript and Three.js.
It includes a third-person player, simple training map, buildings, trees, cover, enemy targets, shooting, ammo, reload, health and mobile touch controls.

LIMITATIONS
This is not a complete BGMI-scale game. It does not yet include online multiplayer, 100-player servers, an 8x8 km map, full weapon inventory, vehicles, parachuting, safe-zone systems, voice chat, anti-cheat, or production-grade character/weapon assets.
An APK is not included. Packaging as Android APK is a separate next step (for example with Capacitor and Android build tools).
