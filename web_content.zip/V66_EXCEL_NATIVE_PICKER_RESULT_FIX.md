# V66 Excel native picker result fix

Version 2.32 / versionCode 36.

Fixes the V65 failure where the import status could remain on “Opening Excel files in Downloads…” without returning the selected file.

Changes:
- Choose File now launches Android's native `ACTION_OPEN_DOCUMENT` directly, without `Intent.createChooser`.
- The selected `content://` URI is handled in `MainActivity.onActivityResult()`.
- Native XLSX/CSV/TXT parsing continues through the existing bridge into the import preview.
- If no system document picker Activity is available, the app falls back to its own Downloads list.
- The fallback Downloads query runs off the UI thread so a slow/vendor-specific MediaStore provider cannot freeze the app.
- Browser/web builds still retain the normal HTML file input fallback.
