Stone Pro v14.3 — three separate apps
  site/worker/      کارگر     (own data, own install icon)
  site/contractor/  پیمانکار
  site/owner/       کارفرما
They share nothing: every app keeps its data under its own storage prefix and its own offline cache,
and a backup file made in one app is refused by the others. Upload the whole site/ folder to an HTTPS host
(Netlify/Cloudflare Pages: site/_headers is applied automatically; nginx: add nginx-snippet.conf to your server block).
Each app is opened at its own address, e.g. https://your-domain/worker/ . Give each user group only its own link.
You can also host each folder on its own domain/subdomain.
Keep the readable source private; only upload site/.
Note: browser code can be made hard to read but never impossible to copy; real protection needs server-side logic and legal terms.

--- v14.6 (app feel) ---
Added to all three apps (native.css / native.js): no pull-to-refresh, no rubber-band, Android Back button walks back through screens
instead of closing the app, offline / new-version / install notices. Service-worker caches bumped to v14-6 so users get it automatically.
In the APK converter turn OFF "pull to refresh" / "swipe refresh" for any app you wrap.
