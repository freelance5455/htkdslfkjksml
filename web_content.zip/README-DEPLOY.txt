Stone Pro v14.3 — three separate apps
  site/worker/      کارگر     (own data, own install icon)
  site/contractor/  پیمانکار
  site/owner/       کارفرما
They share nothing: every app keeps its data under its own storage prefix and its own offline cache,
and a backup file made in one app is refused by the others. Upload the whole site/ folder to an HTTPS host
(Netlify/Cloudflare Pages: site/_headers is applied automatically; nginx: add nginx-snippet.conf to your server block).
Each app is opened at its own address, e.g. https://your-domain/worker/ . Give each user group only its own link.
You can also host each folder on its own domain/subdomain.
Keep the readable source private; only upload site/.
Note: browser code can be made hard to read but never impossible to copy; real protection needs server-side logic and legal terms.
