Stone Pro v14.3 - deploy package (minified)
1. Upload the contents of ysp-pwa/ to the root of an HTTPS site (HTTPS is required for the PWA and service worker).
2. Netlify / Cloudflare Pages: the _headers file is applied automatically.
   nginx: paste nginx-snippet.conf inside your server { } block.
3. Do NOT upload the readable source, tests or older zips to the server.
Note: code that runs in a browser can be made hard to read but never impossible to copy.
