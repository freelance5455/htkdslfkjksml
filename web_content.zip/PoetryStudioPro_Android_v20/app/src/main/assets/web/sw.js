const CACHE='poetry-studio-pro-v30-offline';
const APP=['./','./index.html','./manifest.webmanifest','./sw.js'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(APP)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  event.respondWith((async()=>{
    const cached=await caches.match(event.request);
    try{
      const res=await fetch(event.request);
      if(res&&(res.ok||res.type==='opaque')){
        const u=new URL(event.request.url);
        if(u.origin===location.origin){
          caches.open(CACHE).then(c=>c.put(event.request,res.clone())).catch(()=>{});
        }
      }
      return res;
    }catch(e){return cached||new Response('Offline resource unavailable',{status:503})}
  })());
});
