const CACHE='poetry-studio-pro-v16-inkai-offline';
const APP=['./','./index.html','./manifest.webmanifest','./sw.js'];
const AI_HOSTS=['cdn.jsdelivr.net','huggingface.co','cdn-lfs.huggingface.co','cdn-lfs-us-1.hf.co','cdn-lfs-eu-1.hf.co','hf.co'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(APP)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  event.respondWith((async()=>{
    const cached=await caches.match(event.request);
    try{
      const res=await fetch(event.request);
      if(res&&(res.ok||res.type==='opaque')){
        const u=new URL(event.request.url);
        if(u.origin===location.origin||AI_HOSTS.includes(u.hostname)){
          caches.open(CACHE).then(c=>c.put(event.request,res.clone())).catch(()=>{});
        }
      }
      return res;
    }catch(e){return cached||new Response('Offline resource unavailable',{status:503})}
  })());
});
