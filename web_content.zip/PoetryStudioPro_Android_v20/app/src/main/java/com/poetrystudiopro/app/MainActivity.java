package com.poetrystudiopro.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int BT_ENABLE_REQUEST = 2001;
    private static final int BT_DISCOVERABLE_REQUEST = 2002;
    private WebView web;
    private BtBridge bt;
    private ValueCallback<Uri[]> pendingFileCallback;
    private WebView printWebView;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setBackgroundColor(Color.TRANSPARENT);

        // Serve the bundled app through a real HTTPS origin instead of file://.
        // This is important for WebAssembly/ES modules, IndexedDB and OPFS used
        // by the real offline InkAI engine. It also fixes the WebView error
        // "Failed to fetch dynamically imported module: remote resource".
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        web.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    pendingFileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    try {
                        for (String resource : request.getResources()) {
                            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                                if (Build.VERSION.SDK_INT < 23 ||
                                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                                } else {
                                    request.deny();
                                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 43);
                                }
                                return;
                            }
                        }
                        request.deny();
                    } catch (Exception ignored) { request.deny(); }
                });
            }
        });

        ReminderReceiver.ensureChannel(this);
        bt = new BtBridge(this, web);
        web.addJavascriptInterface(bt, "PoetryWifi");
        web.addJavascriptInterface(bt, "PoetryBluetoothNative");
        web.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        setContentView(web);
        web.loadUrl("https://appassets.androidplatform.net/assets/web/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (pendingFileCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null) {
                    Uri uri = data.getData();
                    if (uri != null) result = new Uri[]{uri};
                }
                pendingFileCallback.onReceiveValue(result);
                pendingFileCallback = null;
            }
            return;
        }
        if (bt != null && (requestCode == BT_ENABLE_REQUEST || requestCode == BT_DISCOVERABLE_REQUEST)) {
            bt.onBluetoothActivityResult(requestCode, resultCode);
        }
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (bt != null && r == 42) bt.onBluetoothPermissionsResult(g);
        if (r == 43 && bt != null) bt.emitState("permissions");
    }

    @Override public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript(
                "(function(){try{if(window.PoetryAndroid&&window.PoetryAndroid.handleBack)return window.PoetryAndroid.handleBack();}catch(e){}return false;})()",
                value -> { if (!"true".equals(value) && web.canGoBack()) web.goBack(); }
            );
        } else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (pendingFileCallback != null) { pendingFileCallback.onReceiveValue(null); pendingFileCallback = null; }
        if (bt != null) { bt.stop(); bt.close(); }
        if (web != null) web.destroy();
        if (printWebView != null) { printWebView.destroy(); printWebView = null; }
        super.onDestroy();
    }

    public static class AndroidBridge {
        private final Activity a;
        AndroidBridge(Activity a) { this.a = a; }

        @JavascriptInterface public boolean saveTextFile(String filename, String text, String mime) {
            try {
                return saveBytes(filename, String.valueOf(text == null ? "" : text).getBytes(StandardCharsets.UTF_8),
                    mime == null ? "text/plain;charset=utf-8" : mime);
            } catch (Exception e) {
                Toast.makeText(a, "Could not save file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                return false;
            }
        }

        @JavascriptInterface public boolean saveBlobBase64(String filename, String base64, String mime) {
            try {
                byte[] bytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                return saveBytes(filename, bytes, mime == null ? "application/octet-stream" : mime);
            } catch (Exception e) {
                Toast.makeText(a, "Could not save file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                return false;
            }
        }

        
        @JavascriptInterface public boolean shareImageBase64(String filename, String base64, String mime) {
            try {
                byte[] bytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                String safe = (filename == null || filename.trim().isEmpty()) ? "PoetryCard.png" : filename.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (!safe.toLowerCase().endsWith(".png") && !safe.toLowerCase().endsWith(".jpg")) safe = safe + ".png";
                File cacheDir = new File(a.getCacheDir(), "share");
                if (!cacheDir.exists()) cacheDir.mkdirs();
                File out = new File(cacheDir, safe);
                try (FileOutputStream fos = new FileOutputStream(out)) { fos.write(bytes); }
                Uri uri;
                if (Build.VERSION.SDK_INT >= 24) {
                    uri = androidx.core.content.FileProvider.getUriForFile(a, a.getPackageName() + ".fileprovider", out);
                } else {
                    uri = Uri.fromFile(out);
                }
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime == null || mime.isEmpty() ? "image/png" : mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.putExtra(Intent.EXTRA_SUBJECT, "Poetry Studio Pro");
                a.startActivity(Intent.createChooser(send, "Share poem card"));
                return true;
            } catch (Exception e) {
                try { Toast.makeText(a, "Share failed: " + e.getMessage(), Toast.LENGTH_SHORT).show(); } catch (Exception ignored) {}
                return false;
            }
        }


        private boolean saveBytes(String filename, byte[] bytes, String mime) throws IOException {
            String safe = (filename == null || filename.trim().isEmpty()) ? "PoetryStudioFile" : filename.replaceAll("[\\\\/:*?\"<>|]", "_");
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, safe);
                v.put(android.provider.MediaStore.Downloads.MIME_TYPE, mime);
                v.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Poetry Studio Pro");
                v.put(android.provider.MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = a.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return false;
                try (OutputStream out = a.getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Unable to open device storage.");
                    out.write(bytes);
                } catch (Exception e) {
                    a.getContentResolver().delete(uri, null, null);
                    throw e;
                }
                v.clear();
                v.put(android.provider.MediaStore.Downloads.IS_PENDING, 0);
                a.getContentResolver().update(uri, v, null, null);
                return true;
            }

            File dir = new File(a.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Poetry Studio Pro");
            if (!dir.exists() && !dir.mkdirs()) return false;
            File file = new File(dir, safe);
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write(bytes);
            }
            return true;
        }

        @JavascriptInterface public boolean requestNotificationPermission() {
            if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                a.runOnUiThread(() -> a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 44));
                return false;
            }
            return true;
        }

        @JavascriptInterface public boolean isNotificationPermissionGranted() {
            return Build.VERSION.SDK_INT < 33 || a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface public boolean scheduleReminder(String id, String title, String message, long triggerAt, String repeat) {
            boolean ok = ReminderReceiver.schedule(a.getApplicationContext(), id, title, message, triggerAt, repeat);
            if (ok && Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                a.runOnUiThread(() -> a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 44));
            }
            return ok;
        }

        @JavascriptInterface public void openNotificationSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName());
                a.startActivity(i);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public void openExactAlarmSettings() {
            if (Build.VERSION.SDK_INT >= 31) {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    i.setData(Uri.parse("package:" + a.getPackageName()));
                    a.startActivity(i);
                } catch (Exception ignored) {}
            }
        }

        @JavascriptInterface public boolean isBiometricAvailable() {
            try {
                BiometricManager bm = BiometricManager.from(a);
                int r = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
                return r == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public String getBiometricAccountId() {
            return a.getSharedPreferences("poetry_biometric", Context.MODE_PRIVATE).getString("account_id", "");
        }

        @JavascriptInterface public void enableBiometricForAccount(final String accountId) {
            if (accountId == null || accountId.trim().isEmpty()) return;
            a.runOnUiThread(() -> authenticateBiometricInternal(accountId, true));
        }

        @JavascriptInterface public void authenticateBiometric(final String accountId) {
            if (accountId == null || accountId.trim().isEmpty()) return;
            String saved = getBiometricAccountId();
            if (!accountId.equals(saved)) {
                try { a.runOnUiThread(() -> Toast.makeText(a, "Biometrics are not enabled for this account.", Toast.LENGTH_SHORT).show()); } catch (Exception ignored) {}
                return;
            }
            a.runOnUiThread(() -> authenticateBiometricInternal(accountId, false));
        }

        private void authenticateBiometricInternal(final String accountId, final boolean enrolling) {
            try {
                BiometricManager bm = BiometricManager.from(a);
                int r = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
                if (r != BiometricManager.BIOMETRIC_SUCCESS) {
                    web.evaluateJavascript("window.onNativeBiometricResult&&window.onNativeBiometricResult(false," + JSONObject.quote(accountId) + ")", null);
                    Toast.makeText(a, "Biometric unlock is not available on this device.", Toast.LENGTH_SHORT).show();
                    return;
                }
                Executor executor = ContextCompat.getMainExecutor(a);
                BiometricPrompt prompt = new BiometricPrompt(a, executor, new BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        if (enrolling) {
                            a.getSharedPreferences("poetry_biometric", Context.MODE_PRIVATE).edit().putString("account_id", accountId).apply();
                            Toast.makeText(a, "Biometric unlock enabled for this account.", Toast.LENGTH_SHORT).show();
                        }
                        web.evaluateJavascript("window.onNativeBiometricResult&&window.onNativeBiometricResult(true," + JSONObject.quote(accountId) + ")", null);
                    }
                    @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                        web.evaluateJavascript("window.onNativeBiometricResult&&window.onNativeBiometricResult(false," + JSONObject.quote(accountId) + ")", null);
                    }
                    @Override public void onAuthenticationFailed() {}
                });
                BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle(enrolling ? "Enable biometric unlock" : "Unlock Poetry Studio Pro")
                    .setSubtitle(enrolling ? "Confirm your biometric to protect this account" : "Verify your fingerprint or face")
                    .setNegativeButtonText("Use PIN instead")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK)
                    .build();
                prompt.authenticate(info);
            } catch (Exception e) {
                try { web.evaluateJavascript("window.onNativeBiometricResult&&window.onNativeBiometricResult(false," + JSONObject.quote(accountId) + ")", null); } catch (Exception ignored) {}
            }
        }

        @JavascriptInterface public void disableBiometric() {
            a.getSharedPreferences("poetry_biometric", Context.MODE_PRIVATE).edit().clear().apply();
        }

        @JavascriptInterface public void cancelReminder(String id) {
            ReminderReceiver.cancel(a.getApplicationContext(), id);
        }

        @JavascriptInterface public boolean canScheduleExactReminders() {
            if (Build.VERSION.SDK_INT < 31) return true;
            android.app.AlarmManager am = (android.app.AlarmManager)a.getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        }

        @JavascriptInterface public void testPoetryNotification() {
            a.runOnUiThread(() -> {
                try {
                    ReminderReceiver.ensureChannel(a.getApplicationContext());
                    android.app.NotificationManager nm=(android.app.NotificationManager)a.getSystemService(Context.NOTIFICATION_SERVICE);
                    androidx.core.app.NotificationCompat.Builder b=new androidx.core.app.NotificationCompat.Builder(a.getApplicationContext(),"poetry_reminders")
                        .setSmallIcon(com.poetrystudiopro.app.R.drawable.ic_notification)
                        .setContentTitle("Poetry Studio Pro")
                        .setContentText("Notifications are working. Your poetry reminders can reach you here.")
                        .setAutoCancel(true)
                        .setPriority(androidx.core.app.NotificationCompat.PRIORITY_DEFAULT);
                    if(nm!=null)nm.notify(0x5053,b.build());
                } catch(Exception e) { Toast.makeText(a,"Notification test failed: "+e.getMessage(),Toast.LENGTH_SHORT).show(); }
            });
        }

        @JavascriptInterface public boolean printHtml(final String html, final String title) {
            a.runOnUiThread(() -> {
                try {
                    if (a instanceof MainActivity) {
                        MainActivity activity = (MainActivity) a;
                        if (activity.printWebView != null) activity.printWebView.destroy();
                        activity.printWebView = new WebView(a);
                    }
                    WebView targetWebView = ((MainActivity) a).printWebView;
                    WebSettings settings = targetWebView.getSettings();
                    settings.setJavaScriptEnabled(false);
                    targetWebView.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            try {
                                PrintManager pm = (PrintManager) a.getSystemService(Context.PRINT_SERVICE);
                                PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(
                                    title == null || title.trim().isEmpty() ? "Poetry Studio" : title);
                                pm.print(
                                    title == null || title.trim().isEmpty() ? "Poetry Studio" : title,
                                    adapter,
                                    new PrintAttributes.Builder()
                                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                        .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                        .build()
                                );
                            } catch (Exception e) {
                                Toast.makeText(a, "Print/PDF could not be opened.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    targetWebView.loadDataWithBaseURL("file:///android_asset/web/", html == null ? "" : html,
                        "text/html", "UTF-8", null);
                } catch (Exception e) {
                    Toast.makeText(a, "Print/PDF could not be opened.", Toast.LENGTH_SHORT).show();
                }
            });
            return true;
        }

        @JavascriptInterface public boolean openInChrome(String url) {
            return openExternalUrl(url);
        }

        @JavascriptInterface public boolean openExternalUrl(String url) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                a.startActivity(i);
                return true;
            } catch (Exception e) { return false; }
        }
    }

    public static class BtBridge {
        static final UUID UUID_SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        final Activity a; final WebView w; final BluetoothAdapter adapter; final ExecutorService pool = Executors.newCachedThreadPool();
        final Map<String,Peer> peers = new ConcurrentHashMap<>();
        final Map<String,BluetoothDevice> discovered = new ConcurrentHashMap<>();
        volatile BluetoothServerSocket server; volatile boolean running;
        volatile String pendingAction = null;
        volatile String pendingAddress = null;
        final BroadcastReceiver receiver = new BroadcastReceiver() {
            public void onReceive(Context c, Intent i) {
                if (BluetoothDevice.ACTION_FOUND.equals(i.getAction())) {
                    BluetoothDevice d;
                    if (Build.VERSION.SDK_INT >= 33) d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                    else d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (d != null) { String addr = d.getAddress(); discovered.put(addr, d); emitDevice(d); }
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(i.getAction())) {
                    emitState("scan_finished");
                }
            }
        };

        BtBridge(Activity a, WebView w) {
            this.a=a; this.w=w; adapter=BluetoothAdapter.getDefaultAdapter();
            try {
                IntentFilter f = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
                if (Build.VERSION.SDK_INT >= 33) a.registerReceiver(receiver, f, Context.RECEIVER_EXPORTED);
                else a.registerReceiver(receiver, f);
            } catch(Exception ignored){}
        }

        @JavascriptInterface public boolean isSupported(){return adapter!=null;}
        @JavascriptInterface public boolean isEnabled(){try{return adapter!=null&&adapter.isEnabled();}catch(Exception e){return false;}}
        @JavascriptInterface public void requestPermissions(){
            requestBluetoothPermissions(null, null);
        }
        private boolean hasBluetoothPermissions(boolean forHost){
            if(Build.VERSION.SDK_INT < 31) return true;
            boolean scan = a.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED;
            boolean connect = a.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
            boolean advertise = !forHost || a.checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE)==PackageManager.PERMISSION_GRANTED;
            return scan && connect && advertise;
        }
        private boolean requestBluetoothPermissions(String action, String address){
            if(Build.VERSION.SDK_INT < 31) return true;
            ArrayList<String> p=new ArrayList<>();
            if(a.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.BLUETOOTH_SCAN);
            if(a.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.BLUETOOTH_CONNECT);
            if(action != null && action.equals("host") && a.checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            if(!p.isEmpty()){
                pendingAction=action; pendingAddress=address;
                a.requestPermissions(p.toArray(new String[0]),42);
                emitState("bluetooth_permission_required");
                return false;
            }
            return true;
        }
        private boolean ensureEnabled(String action, String address){
            if(adapter==null){emitState("bluetooth_unsupported");return false;}
            if(!adapter.isEnabled()){
                pendingAction=action; pendingAddress=address;
                try { a.startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), BT_ENABLE_REQUEST); }
                catch(Exception e){ emitState("bluetooth_enable_error:"+e.getMessage()); }
                return false;
            }
            return true;
        }
        void continuePending(){
            String action=pendingAction, address=pendingAddress;
            pendingAction=null; pendingAddress=null;
            if(action==null)return;
            if("host".equals(action)) startHostInternal();
            else if("scan".equals(action)) startClassicDiscoveryInternal();
            else if("connect".equals(action)) connectBLEInternal(address);
        }
        void onBluetoothPermissionsResult(int[] grantResults){
            boolean ok=true; if(grantResults!=null && grantResults.length>0) for(int g:grantResults) if(g!=PackageManager.PERMISSION_GRANTED) ok=false;
            if(!ok){pendingAction=null;pendingAddress=null;emitState("bluetooth_permission_denied");return;}
            if(ensureEnabled(pendingAction,pendingAddress)){
                if("host".equals(pendingAction)) requestDiscoverableAndHost();
                else continuePending();
            }
        }
        void onBluetoothActivityResult(int requestCode,int resultCode){
            if(resultCode!=Activity.RESULT_OK){String action=pendingAction;pendingAction=null;pendingAddress=null;emitState("bluetooth_action_cancelled:"+String.valueOf(action));return;}
            if(requestCode==BT_ENABLE_REQUEST){
                if("host".equals(pendingAction)) requestDiscoverableAndHost();
                else continuePending();
            } else if(requestCode==BT_DISCOVERABLE_REQUEST){ continuePending(); }
        }
        private void requestDiscoverableAndHost(){
            try{
                Intent i=new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,300);
                a.startActivityForResult(i,BT_DISCOVERABLE_REQUEST);
            }catch(Exception e){emitState("discoverable_error:"+e.getMessage());continuePending();}
        }
        @JavascriptInterface public void openBluetoothSettings(){try{a.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));}catch(Exception e){a.startActivity(new Intent(Settings.ACTION_SETTINGS));}}
        @JavascriptInterface public String getLocalName(){try{return adapter==null?"":String.valueOf(adapter.getName());}catch(Exception e){return "Poetry Poet";}}
        @JavascriptInterface public String getLocalAddress(){return "";}
        @JavascriptInterface public String getDevices(){JSONArray ar=new JSONArray(); try{for(BluetoothDevice d:discovered.values()){JSONObject o=new JSONObject();o.put("name",safeName(d));o.put("address",d.getAddress());o.put("type","bluetooth");ar.put(o);}}catch(Exception ignored){} return ar.toString();}
        @JavascriptInterface public String getConnectedPeers(){JSONArray ar=new JSONArray();for(Peer p:peers.values())try{JSONObject o=new JSONObject();o.put("id",p.id);o.put("address",p.id);o.put("name",p.name);ar.put(o);}catch(Exception ignored){}return ar.toString();}
        @JavascriptInterface public int getConnectedPeerCount(){return peers.size();}
        @JavascriptInterface public void startHost(){
            if(adapter==null){emitState("bluetooth_unsupported");return;}
            if(!requestBluetoothPermissions("host",null))return;
            pendingAction="host";
            if(!ensureEnabled("host",null))return;
            requestDiscoverableAndHost();
        }
        private void startHostInternal(){
            if(adapter==null||!hasBluetoothPermissions(true)||!adapter.isEnabled())return;
            running=true;
            pool.execute(()->{try{
                if(server!=null)server.close();
                server=adapter.listenUsingRfcommWithServiceRecord("Poetry Studio Pro Community",UUID_SPP);
                emitState("hosting");
                while(running){BluetoothSocket s=server.accept();if(s!=null)addPeer(s);}
            }catch(Exception e){if(running)emitState("host_error:"+e.getMessage());}});
        }
        @JavascriptInterface public void startServer(){startHost();}
        @JavascriptInterface public void startBLEScan(){startClassicDiscovery();}
        @JavascriptInterface public void startClassicDiscovery(){
            if(adapter==null){emitState("bluetooth_unsupported");return;}
            if(!requestBluetoothPermissions("scan",null))return;
            if(!ensureEnabled("scan",null))return;
            startClassicDiscoveryInternal();
        }
        private void startClassicDiscoveryInternal(){
            if(adapter==null||!hasBluetoothPermissions(false)||!adapter.isEnabled())return;
            try{
                discovered.clear();
                // Paired devices are immediately useful and do not require discovery.
                for(BluetoothDevice d:adapter.getBondedDevices()){if(d!=null){discovered.put(d.getAddress(),d);emitDevice(d);}}
                if(adapter.isDiscovering())adapter.cancelDiscovery();
                boolean started=adapter.startDiscovery();
                emitState(started?"scanning":"scan_start_failed");
            }catch(SecurityException e){emitState("scan_permission_error:"+e.getMessage());}
             catch(Exception e){emitState("scan_error:"+e.getMessage());}
        }
        @JavascriptInterface public void scan(){startClassicDiscovery();}
        @JavascriptInterface public void discover(){startClassicDiscovery();}
        @JavascriptInterface public void stopScan(){try{if(adapter!=null&&adapter.isDiscovering())adapter.cancelDiscovery();emitState("scan_stopped");}catch(Exception ignored){}}
        @JavascriptInterface public void connect(String id){connectBLE(id);}
        @JavascriptInterface public void connectBLE(String address){
            if(adapter==null){emitState("bluetooth_unsupported");return;}
            if(!requestBluetoothPermissions("connect",address))return;
            if(!ensureEnabled("connect",address))return;
            connectBLEInternal(address);
        }
        private void connectBLEInternal(String address){
            BluetoothDevice d=discovered.get(address);
            try{
                if(d==null&&adapter!=null)d=adapter.getRemoteDevice(address);
                final BluetoothDevice x=d;
                if(x==null){emitState("connect_error:device_not_found");return;}
                pool.execute(()->{
                    BluetoothSocket s=null;
                    try{
                        if(adapter!=null&&adapter.isDiscovering())adapter.cancelDiscovery();
                        emitState("connecting:"+x.getAddress());
                        s=x.createRfcommSocketToServiceRecord(UUID_SPP);
                        s.connect();
                        addPeer(s); emitState("connected:"+x.getAddress());
                    }catch(Exception e){try{if(s!=null)s.close();}catch(Exception ignored){} emitState("connect_error:"+e.getMessage());}
                });
            }catch(SecurityException e){emitState("connect_permission_error:"+e.getMessage());}
             catch(Exception e){emitState("connect_error:"+e.getMessage());}
        }
        @JavascriptInterface public boolean send(String json){return broadcast(json);}
        @JavascriptInterface public boolean sendData(String json){return broadcast(json);}
        @JavascriptInterface public boolean sendTo(String address,String json){Peer p=peers.get(address);if(p==null)return false;return p.send(json);}
        @JavascriptInterface public void disconnect(){stop();}
        @JavascriptInterface public void stop(){running=false;try{if(adapter!=null&&adapter.isDiscovering())adapter.cancelDiscovery();}catch(Exception ignored){}try{if(server!=null)server.close();}catch(Exception ignored){}for(Peer p:new ArrayList<>(peers.values()))p.close();peers.clear();emitState("stopped");}
        private boolean broadcast(String json){boolean ok=false;for(Peer p:peers.values())ok|=p.send(json);return ok;}
        private void addPeer(BluetoothSocket s){if(peers.size()>=7){try{s.close();}catch(Exception ignored){}return;}Peer p=new Peer(s);peers.put(p.id,p);emitDevice(s.getRemoteDevice());emitState("peer_connected");pool.execute(p);}
        String safeName(BluetoothDevice d){try{return d.getName()==null?"Nearby poet":d.getName();}catch(Exception e){return "Nearby poet";}}
        void emitDevice(BluetoothDevice d){String payload;try{JSONObject o=new JSONObject();o.put("name",safeName(d));o.put("address",d.getAddress());o.put("type","bluetooth");payload=o.toString();}catch(Exception e){return;}js("window.onPoetryWifiDevice && window.onPoetryWifiDevice("+JSONObject.quote(payload)+");");js("window.PoetryBluetooth && PoetryBluetooth._emit && PoetryBluetooth._emit('bluetoothDeviceFound',"+payload+");");}
        void emitMessage(String raw){js("window.onPoetryWifiMessage && window.onPoetryWifiMessage("+JSONObject.quote(raw)+");");}
        void emitState(String st){js("window.onPoetryWifiState && window.onPoetryWifiState("+JSONObject.quote(st)+");");}
        void close(){try{a.unregisterReceiver(receiver);}catch(Exception ignored){}pool.shutdownNow();}
        void js(String code){w.post(()->{try{w.evaluateJavascript(code,null);}catch(Exception ignored){}});}
        class Peer implements Runnable{final BluetoothSocket s;final String id;final String name;final BufferedReader in;final BufferedWriter out;volatile boolean alive=true;Peer(BluetoothSocket s){this.s=s;id=s.getRemoteDevice().getAddress();name=safeName(s.getRemoteDevice());BufferedReader ii=null;BufferedWriter oo=null;try{ii=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));oo=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8));}catch(Exception ignored){}in=ii;out=oo;}public void run(){try{String line;while(alive&&in!=null&&(line=in.readLine())!=null){emitMessage(line);}}catch(Exception ignored){}finally{close();peers.remove(id);emitState("peer_disconnected");}}synchronized boolean send(String x){if(!alive||out==null)return false;try{out.write(x.replace("\n"," "));out.write("\n");out.flush();return true;}catch(Exception e){close();return false;}}void close(){alive=false;try{s.close();}catch(Exception ignored){}}}
    }
}
