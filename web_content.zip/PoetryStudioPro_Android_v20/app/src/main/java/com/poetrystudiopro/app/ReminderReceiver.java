package com.poetrystudiopro.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.Map;

/** Native Android reminder scheduler used by the WebView poetry reminder UI. */
public class ReminderReceiver extends BroadcastReceiver {
    private static final String PREFS = "poetry_reminders_native";
    private static final String CHANNEL_ID = "poetry_reminders";
    private static final String ACTION_REMINDER = "com.poetrystudiopro.app.POETRY_REMINDER";
    private static final String ACTION_BOOT = "android.intent.action.BOOT_COMPLETED";
    private static final String ACTION_PACKAGE_REPLACED = "android.intent.action.MY_PACKAGE_REPLACED";
    private static final String ACTION_EXACT_PERMISSION = "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED";

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Poetry Reminders", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("Writing, reading and poetry practice reminders");
                nm.createNotificationChannel(ch);
            }
        }
    }

    private static int requestCode(String id) {
        return id == null ? 1 : (id.hashCode() & 0x7fffffff);
    }

    private static PendingIntent pendingIntent(Context context, String id, long triggerAt, String title, String message, String repeat) {
        Intent i = new Intent(context, ReminderReceiver.class);
        i.setAction(ACTION_REMINDER);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("message", message);
        i.putExtra("triggerAt", triggerAt);
        i.putExtra("repeat", repeat);
        return PendingIntent.getBroadcast(context, requestCode(id), i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }

    public static boolean schedule(Context context, String id, String title, String message, long triggerAt, String repeat) {
        try {
            if (id == null || id.trim().isEmpty() || triggerAt <= System.currentTimeMillis()) return false;
            ensureChannel(context);
            String safeTitle = (title == null || title.trim().isEmpty()) ? "Poetry reminder" : title.trim();
            String safeMessage = (message == null || message.trim().isEmpty()) ? "It is time for your poetry practice." : message.trim();
            String safeRepeat = repeat == null ? "none" : repeat;
            PendingIntent pi = pendingIntent(context, id, triggerAt, safeTitle, safeMessage, safeRepeat);
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return false;
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
            JSONObject obj = new JSONObject();
            obj.put("id", id); obj.put("title", safeTitle); obj.put("message", safeMessage);
            obj.put("triggerAt", triggerAt); obj.put("repeat", safeRepeat);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(id, obj.toString()).apply();
            return true;
        } catch (Exception e) { return false; }
    }

    public static void cancel(Context context, String id) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.cancel(pendingIntent(context, id, 0, "", "", "none"));
        } catch (Exception ignored) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(id).apply();
    }

    private static long nextTrigger(long oldTrigger, String repeat) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(oldTrigger);
        if ("daily".equals(repeat)) c.add(Calendar.DAY_OF_YEAR, 1);
        else if ("weekly".equals(repeat)) c.add(Calendar.WEEK_OF_YEAR, 1);
        else if ("monthly".equals(repeat)) c.add(Calendar.MONTH, 1);
        else return 0;
        return c.getTimeInMillis();
    }

    private void showNotification(Context context, String id, String title, String message, String repeat, long triggerAt) {
        ensureChannel(context);
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(context, requestCode(id), open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(com.poetrystudiopro.app.R.drawable.ic_notification)
                .setContentTitle(title == null || title.isEmpty() ? "Poetry Studio Pro" : title)
                .setContentText(message == null || message.isEmpty() ? "It is time for your poetry practice." : message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(requestCode(id), b.build());

        if (repeat != null && !"none".equals(repeat)) {
            long next = nextTrigger(triggerAt, repeat);
            if (next > System.currentTimeMillis()) schedule(context, id, title, message, next, repeat);
        } else {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(id).apply();
        }
    }

    private static void rescheduleAll(Context context) {
        Map<String, ?> all = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getAll();
        for (Map.Entry<String, ?> e : all.entrySet()) {
            try {
                JSONObject o = new JSONObject(String.valueOf(e.getValue()));
                long at = o.optLong("triggerAt", 0);
                String repeat = o.optString("repeat", "none");
                if ("none".equals(repeat) && at <= System.currentTimeMillis()) {
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(e.getKey()).apply();
                    continue;
                }
                if (at <= System.currentTimeMillis()) at = nextTrigger(at, repeat);
                if (at > System.currentTimeMillis()) schedule(context, o.optString("id", e.getKey()), o.optString("title", "Poetry reminder"), o.optString("message", "It is time for your poetry practice."), at, repeat);
            } catch (Exception ignored) {}
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        if (ACTION_BOOT.equals(intent.getAction()) || ACTION_PACKAGE_REPLACED.equals(intent.getAction()) || ACTION_EXACT_PERMISSION.equals(intent.getAction())) {
            rescheduleAll(context.getApplicationContext());
            return;
        }
        if (!ACTION_REMINDER.equals(intent.getAction())) return;
        String id = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        String message = intent.getStringExtra("message");
        String repeat = intent.getStringExtra("repeat");
        long triggerAt = intent.getLongExtra("triggerAt", System.currentTimeMillis());
        showNotification(context.getApplicationContext(), id, title, message, repeat, triggerAt);
    }
}
