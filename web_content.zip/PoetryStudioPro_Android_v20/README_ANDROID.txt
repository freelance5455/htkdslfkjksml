Poetry Studio Pro — Android Offline Build

This project packages Poetry Studio Pro as a self-contained Android WebView application.

Core writing, Vault, forms, sharing/export, reminders and craft tools are designed to work offline after installation. The application contains no remote model service, LLM runtime, model downloader, or inference engine.

Build requirements
- Android Studio / Gradle
- Android SDK compatible with the project compileSdk

The web application is stored under app/src/main/assets/web/.
