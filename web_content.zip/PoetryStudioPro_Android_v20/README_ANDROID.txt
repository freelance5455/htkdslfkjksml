POETRY STUDIO PRO v20 — ULTIMATE OFFLINE ANDROID STUDIO BUILD
============================================================

THE BEST OFFLINE POETRY STUDIO ON ANDROID — BUILT TO BEAT EVERY COMPETITOR

What this is
------------
A complete Android Studio project that wraps Poetry Studio Pro’s self-contained
web application in a production-grade WebView shell. Everything runs offline.
No account servers, no model downloads, no first-run internet requirement.

InkAI is a fully local creative intelligence. It writes, edits, analyzes,
coaches, suggests forms, works with sound (rhyme, meter, alliteration,
assonance, stress), prepares performance notes, and more — entirely on-device.

Bluetooth Community remains the unique offline social layer: up to 7 peers
connected via Classic RFCOMM. Poems and packets travel without Wi-Fi or
cellular. The transport is exposed through the existing PoetryWifi bridge name
for full compatibility with the web layer.

WHY THIS BEATS THE CURRENT TOP POETRY APPS
------------------------------------------
Competitor weaknesses this release deliberately destroys:

• Poet Assistant / RhymeZone-style tools → deeper offline sound analysis
  + live form validation + coaching, not just a dictionary.
• Poetizer / Miraquill / social poetry apps → true privacy + local Bluetooth
  sharing + professional export. No forced feed, no ads, no data mining.
• Generic AI poem generators (online) → InkAI is offline, form-aware, voice-
  preserving, and never phones home.
• Collaborative apps (Rhyma, HaikuJAM) → local multi-device Bluetooth sessions
  that work in a café, park, or classroom with zero infrastructure.
• Publishing tools → Chapbook Builder produces clean, line-break-preserving
  multi-poem PDFs ready for print or further layout.
• Visual share tools → Share Card Studio generates beautiful poem images
  offline for Instagram, WhatsApp, Stories, etc.

v20 ULTIMATE FEATURE PACK (new / heavily upgraded)
--------------------------------------------------
1. Form Master Lab
   - 18+ classical & modern forms with live syllable / line / rhyme checkers
   - Haiku, Tanka, Sonnet (Shakespearean & Petrarchan), Villanelle, Pantoum,
     Ghazal, Limerick, Cinquain, Free verse, Prose poem, Spoken-word skeleton
   - Instant feedback while you write

2. Share Card Studio
   - Offline canvas-based poem cards
   - Multiple elegant themes, fonts, background treatments
   - One-tap PNG export to device Downloads / share sheet
   - Perfect for social without leaving the app or exposing your work online

3. Chapbook / Collection Builder
   - Select any poems from your Vault
   - Re-order, add title page + optional dedication
   - Generate a single professional multi-page PDF with preserved line breaks,
     stanza spacing, and page numbers
   - Ideal first step toward a printed chapbook or KDP manuscript

4. Sound Lab (enhanced)
   - Rhyme density, alliteration score, assonance / consonance maps
   - Approximate stress & reading-time estimates
   - Side-by-side comparison of two drafts for sonic improvement

5. Poet Streaks & Gentle Goals
   - Daily writing streak (local only, no cloud)
   - Optional form-practice goals
   - Soft encouragement, never pressure or dark-pattern gamification

6. Spoken Word / Performance Mode
   - Large, high-contrast reading view
   - Performance annotations from InkAI ([PAUSE], [EMPHASIS], breath marks)
   - Recording integration already present in the native shell

7. Everything previous versions already did well, refined:
   - Full offline InkAI (write / edit / analyze / create / sound / learn / perform)
   - Vault with tags, collections, private flag, version history, draft recovery
   - Bluetooth peer community
   - Reading Mode, Theme Studio, Poetry Academy, Circle / Chorus
   - PDF + Vault dual export, biometric lock options, reminders
   - No ads, no tracking, no mandatory accounts for core features

Build instructions
------------------
1. Open this folder in Android Studio (Hedgehog / Iguana / newer recommended).
2. Let Gradle sync. Internet is only needed for the first dependency resolve
   (androidx.webkit + androidx.core). After that the project is fully offline.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install on device(s). Grant Bluetooth, Notifications, and Microphone when asked.
5. For community testing: one phone Hosts Bluetooth Community, others Join.

Permissions (already declared)
------------------------------
• Bluetooth (legacy + Android 12+ SCAN / CONNECT / ADVERTISE)
• POST_NOTIFICATIONS + SCHEDULE_EXACT_ALARM + RECEIVE_BOOT_COMPLETED (reminders)
• RECORD_AUDIO (spoken-word capture)
• INTERNET (present but unused by core offline path; kept for future optional
  features and WebView asset loader safety)

Architecture notes
------------------
• MainActivity hosts a hardened WebView with WebViewAssetLoader so the web app
  runs under a secure https://appassets.androidplatform.net origin. This enables
  modern storage (IndexedDB / OPFS) and modules without file:// restrictions.
• Native bridge (AndroidBridge + BtBridge) exposes file save, print, Bluetooth
  host/peer, biometrics, and system intents to JavaScript.
• All creative intelligence lives inside the single offline index.html + its
  bundled engines. No remote LLM calls.

Version history snapshot
------------------------
v17–v19  Offline InkAI solidification, Bluetooth community, vault polish
v20      Form Master, Share Cards, Chapbook Builder, Sound Lab upgrades,
         Streaks, Performance mode refinements — the “beat every competitor”
         release.

License / ownership
-------------------
Treat this as your production source. Customize freely. The creative engine
and UI are designed for poets who refuse to rent their tools from the cloud.

Enjoy writing. The page is waiting.
