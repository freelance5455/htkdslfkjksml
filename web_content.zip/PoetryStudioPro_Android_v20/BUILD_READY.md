# Poetry Studio Pro v20 — Ultimate Offline Android Studio Build

## Status
**Production-ready.** Version 20.0 — the “beat every top poetry app” release.

## Toolchain
- Android Gradle Plugin: 8.6.1 (or compatible)
- Gradle: 8.7+
- compileSdk / targetSdk: 35
- minSdk: 26
- versionCode: 20
- versionName: 20.0

## What changed in v20
- Form Master Lab with live validation for 18+ forms
- Share Card Studio (offline canvas → PNG)
- Chapbook / Collection Builder (multi-poem professional PDF)
- Enhanced Sound Lab
- Local Poet Streaks & gentle goals
- Performance / Spoken Word mode refinements
- Full documentation rewrite positioning the app as the offline leader
- All previous offline InkAI + Bluetooth community + Vault features retained and polished

## Build steps
1. Open the root folder in Android Studio.
2. Gradle sync (first sync needs network for androidx dependencies only).
3. Build > Build APK(s).
4. Install and grant runtime permissions (Bluetooth, Notifications, Microphone).

## Offline guarantee
Core writing, InkAI, Vault, Form Master, Share Cards, Chapbook export, and Bluetooth community require **zero internet** after install.

## Notes for maintainers
The creative surface lives in `app/src/main/assets/web/index.html`.
Native bridges live in `MainActivity.java` (AndroidBridge + BtBridge).
