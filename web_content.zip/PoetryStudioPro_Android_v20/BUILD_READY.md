Offline poetry tools, Vault, community features and sharing/export are retained and polished.

## Build steps
1. Open the root folder in Android Studio.
2. Gradle sync (first sync needs network for androidx dependencies only).
3. Build > Build APK(s).
4. Install and grant runtime permissions (Bluetooth, Notifications, Microphone).

## Offline guarantee
Core writing, Vault, Form Master, Share Cards, Chapbook export, and Bluetooth community require **zero internet** after install.

## Notes for maintainers
The creative surface lives in `app/src/main/assets/web/index.html`.
Native bridges live in `MainActivity.java` (AndroidBridge + BtBridge).
