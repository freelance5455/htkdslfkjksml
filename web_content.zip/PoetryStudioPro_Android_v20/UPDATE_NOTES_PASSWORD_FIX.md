# Poetry Studio Pro — Password Auth & Create Profile Fixes

## Fixes (v34.1)
- **Begin Journey / Continue button now works**: `continueAccountCreation()` was calling an undefined previous handler, so tapping "Begin Journey" did nothing. It now validates name, date of birth, country, email, and password, builds `pendingAccountDraft`, and advances to the optional profile photo step (then onboarding).
- **Password show/hide works**: Added the missing `togglePasswordVisibility(inputId, btn)` function used by the eye buttons on both password fields. Buttons also get a higher z-index so taps register reliably.
- **Sign-in uses account password**: `unlockSelectedAccount()` now verifies against `passwordHash` (SHA-256) for password-based accounts, with legacy 6-digit PIN fallback for older records.
- Fixed `legacyDigest` using an undefined `pin` variable (now uses the `value` argument).

## Account creation flow
1. Create Profile form → Begin Journey (validates all fields)
2. Optional photo step → Continue / Skip
3. Onboarding screens → Create My Studio
4. Account is persisted with password hash + one-time Reset Code

## Validation
- Password: 8+ characters, at least one number and one symbol
- Email uniqueness checked across local accounts
- Device account limit still enforced (max 5)

## Note
The Android APK itself was not compiled in this environment. Rebuild the APK with Gradle after syncing these assets.
