# Poetry Studio Pro — Password-Only Auth Fix

## Fixes
- Removed the visible 6-digit PIN fields from account creation.
- Account creation now uses email + strong password only.
- Reworked the onboarding `Create My Studio` action with explicit validation and error handling.
- Added password show/hide controls and a live password-strength message.
- Password authentication is used for account unlock.
- Reset Code remains the offline recovery mechanism.
- Change Password accepts the current password or Reset Code.
- Account deletion verification now uses the account password flow.
- Obsolete PIN keypad screen is hidden.
- User-facing PIN/Recovery Key wording was replaced with Password/Reset Code wording.

## Validation
- 22 JavaScript blocks syntax-checked: 0 failures.
- Signup PIN input elements: 0.
- Android INTERNET permission: 0.
- AI identifiers in web app/service worker: 0.

## Note
The Android APK itself was not compiled in this environment because Gradle/Android SDK downloads are unavailable here. The project remains ready for Android-side Gradle compilation.
