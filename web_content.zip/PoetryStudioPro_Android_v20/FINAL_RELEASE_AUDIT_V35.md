# Poetry Studio Pro — v35.0.0 Stabilization Audit

## Scope
This release is based on the uploaded v35 project. Existing poetry functionality was preserved while the account/security layer was consolidated and hardened.

## Security changes
- Repaired the duplicate `bootAccountGate` JavaScript declaration.
- Removed the legacy six-digit account-PIN fallback from account authentication.
- Added a canonical PBKDF2-HMAC-SHA-256 password record with per-account random salt and versioned parameters.
- Added one-time migration from the previous SHA-256 password record after a successful password login.
- Added password login attempt tracking with a five-attempt / 15-minute lockout.
- Completed Reset Code display, acknowledgement, copy/save/print, login-page recovery, Settings recovery, and regeneration handlers.
- Reset Code remains plaintext-free at rest and is stored as a hash.
- Preserved the five-attempt / 15-minute Reset Code lockout.
- Made account storage fail closed on Android when the native secure-encryption bridge is present but unavailable.
- Account deletion uses the canonical password verifier.
- Removed account-level PIN state on startup.

## Validation
- All 23 inline JavaScript blocks pass Node syntax validation.
- No OpenAI/Gemini/Claude references were found in the application HTML.
- No `fetch()` or `XMLHttpRequest` calls were found in the application HTML.
- No legacy account-password fallback remains in the authentication path.
- Android INTERNET permission remains absent.
- PBKDF2 Web Crypto derivation was functionally exercised in Node.

## Build limitation
A Gradle debug build was attempted. It could not proceed because Gradle 8.7 is not cached in the environment and the wrapper attempted to download it from `downloads.gradle.org`, which is unreachable from this environment. Therefore no APK build success is claimed here.
