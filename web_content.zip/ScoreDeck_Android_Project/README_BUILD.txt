ScoreDeck — CBSE Class 12 Practice + Blueprint App

This is an incremental update of the existing ScoreDeck Android project.

Important:
- Visible app name: ScoreDeck
- Existing applicationId/package identity is preserved for update compatibility.
- Existing localStorage keys are preserved for backward compatibility.
- Version: 1.2 (versionCode 3)

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK as an update to the existing ScoreDeck app.

The bundled app is offline and loads app/src/main/assets/index.html.
