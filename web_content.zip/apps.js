'use strict';
const killed=new Set();
function launch(a){
 toggleStart(false);
 switch(a){
  case 'notepad':return openNotepad();
  case 'calc':return openCalc();
  case 'mspaint':return openPaint();
  case 'cmd':return openCmd();
  case 'taskmgr':return openTaskmgr();
  case 'iexplore':return openIE();
  case 'winmine':return openMine();
  case 'control':return openControl();
  case 'run':return openRun();
  case 'download':return openDownload();
  case 'kiva':return openKiva();
  case 'explorer':if(!shell)return restoreShell();return openExplorer(FS);
  case 'mycomputer':return openExplorer(FS);
  case 'mydocs':return openExplorer(DOCS);
  case 'recycle':return openExplorer(RECYCLE);
  case 'c':return openExplorer(C);
  case 'help':case 'winver':return aboutBox();
  case 'sysprops':return sysProps();
  case 'display':return displayProps();
 }
}

/* Notepad */
function openNotepad(node,initial,name){
 const title=node?node.name:(name||'Untitled');
 const win=createWindow({title:title+' - Notepad',icon:'notepad',w:480,h:320,proc:'notepad.exe'});
 win.body.innerHTML=`<div class="menubar"><span class="m-file">File</span><span class="m-edit">Edit</span><span>Format</span><span>View</span><span class="m-help">Help</span></div><textarea class="np" spellcheck="false" inputmode="none" aria-label="Text editor"></textarea>`;
 const ta=$('textarea',win.body);ta.value=node?(node.content||'').replace(/\r/g,''):(initial||'');
 const save=()=>{if(node&&isAlive(node)){node.content=ta.value;node.date=new Date();node.size=Math.max(1,Math.ceil(ta.value.length/1024))+' KB'}else{node=mk(uniqueName(DOCS,'Untitled','.txt'),'txt',{date:new Date(),size:'1 KB',content:ta.value});add(DOCS,node);win.setTitle(node.name+' - Notepad');msgBox('Notepad',`Saved to ${pathOf(node)}`,'info')}refreshAll()};
 const f=$('.m-file',win.body);f.onclick=()=>menuAt(f,[{label:'New',action:()=>{ta.value='';node=null;win.setTitle('Untitled - Notepad')}},{label:'Save',action:save},'-',{label:'Exit',action:()=>win.close()}]);
 const ed=$('.m-edit',win.body);ed.onclick=()=>menuAt(ed,[{label:'Select All',action:()=>{ta.focus();ta.select()}},{label:'Time/Date',action:()=>{ta.focus();insert(ta,fmt(new Date()))}}]);
 $('.m-help',win.body).onclick=aboutBox;
 return win;
}

/* Calculator */
function openCalc(){
 const win=createWindow({title:'Calculator',icon:'calc',w:250,h:'auto',noMax:1,noResize:1,proc:'calc.exe'});
 const keys=['Back','CE','C','±','sqrt','7','8','9','/','%','4','5','6','*','1/x','1','2','3','-','=','0','00','.','+','='];
 win.body.innerHTML=`<div class="menubar"><span>Edit</span><span>View</span><span>Help</span></div><div class="calc"><div class="calc-d">0.</div><div class="calc-g"></div></div>`;
 const d=$('.calc-d',win.body),g=$('.calc-g',win.body);let cur='0',acc=null,op=null,fresh=true;
 const show=()=>d.textContent=cur.includes('.')||isNaN(cur)?cur:cur+'.';
 const compute=()=>{const b=parseFloat(cur);let r=op==='+'?acc+b:op==='-'?acc-b:op==='*'?acc*b:b===0?NaN:acc/b;cur=isFinite(r)?String(+r.toPrecision(12)):'Cannot divide by zero';acc=isFinite(r)?r:null};
 keys.forEach(k=>{const b=document.createElement('button');b.className='xbtn'+(/[\/*\-+=]|C|Back|CE/.test(k)&&k!=='1/x'?' op':'');b.textContent=k;b.onclick=()=>press(k);g.appendChild(b)});
 function press(k){
  if(/^\d+$/.test(k)||k==='.'){if(fresh){cur=k==='.'?'0.':k==='00'?'0':k;fresh=false}else{if(k==='.'&&cur.includes('.'))return;cur=cur==='0'&&k!=='.'?k.replace('00','0'):cur+k}}
  else if('+-*/'.includes(k)){if(op&&!fresh)compute();else acc=parseFloat(cur);op=k;fresh=true}
  else if(k==='='){if(op){compute();op=null}fresh=true}
  else if(k==='C'){cur='0';acc=null;op=null;fresh=true}
  else if(k==='CE'){cur='0';fresh=true}
  else if(k==='Back'){cur=cur.length>1?cur.slice(0,-1):'0'}
  else if(k==='±'){cur=String(-parseFloat(cur))}
  else if(k==='sqrt'){const v=parseFloat(cur);cur=v<0?'Invalid input':String(+Math.sqrt(v).toPrecision(12));fresh=true}
  else if(k==='%'){cur=String((acc||0)*parseFloat(cur)/100)}
  else if(k==='1/x'){const v=parseFloat(cur);cur=v===0?'Cannot divide by zero':String(+(1/v).toPrecision(12));fresh=true}
  show();
 }
}

/* Paint */
function openPaint(){
 const win=createWindow({title:'untitled - Paint',icon:'paint',w:560,h:380,proc:'mspaint.exe'});
 const COLS=['#000','#808080','#800000','#808000','#008000','#008080','#000080','#800080','#808040','#004040','#0080ff','#004080','#8000ff','#804000','#fff','#c0c0c0','#f00','#ff0','#0f0','#0ff','#00f','#f0f','#ffff80','#00ff80','#80ffff','#8080ff','#ff0080','#ff8040'];
 win.body.innerHTML=`<div class="menubar"><span class="m-file">File</span><span>Edit</span><span>View</span><span>Image</span><span>Colors</span><span>Help</span></div><div class="pt-main"><div class="pt-tools"></div><div class="pt-area"><canvas aria-label="Drawing canvas"></canvas></div></div><div class="pt-pal"><div class="pt-cur"><i></i></div><div class="pt-cols"></div></div>`;
 const cv=$('canvas',win.body),cx=cv.getContext('2d');let color='#000',size=2,erase=false;
 const tools=[['Pencil',2,0],['Brush',6,0],['Big',14,0],['Eraser',16,1]];
 tools.forEach(([n,s,e],i)=>{const b=document.createElement('button');b.textContent=n;if(!i)b.classList.add('on');b.onclick=()=>{size=s;erase=!!e;$$('.pt-tools button',win.body).forEach(x=>x.classList.remove('on'));b.classList.add('on')};$('.pt-tools',win.body).appendChild(b)});
 const clr=document.createElement('button');clr.textContent='Clear';clr.onclick=()=>{cx.fillStyle='#fff';cx.fillRect(0,0,cv.width,cv.height)};$('.pt-tools',win.body).appendChild(clr);
 const curI=$('.pt-cur i',win.body);curI.style.background=color;
 COLS.forEach(c=>{const i=document.createElement('i');i.style.background=c;i.onclick=()=>{color=c;curI.style.background=c};$('.pt-cols',win.body).appendChild(i)});
 const fit=()=>{const tmp=document.createElement('canvas');tmp.width=cv.width;tmp.height=cv.height;tmp.getContext('2d').drawImage(cv,0,0);cv.width=Math.max(10,cv.clientWidth);cv.height=Math.max(10,cv.clientHeight);cx.fillStyle='#fff';cx.fillRect(0,0,cv.width,cv.height);cx.drawImage(tmp,0,0)};
 requestAnimationFrame(fit);win.onResize=fit;
 const pos=e=>{const p=toLocal(e),r=localRect(cv);return{x:(p.x-r.x)*cv.width/cv.clientWidth,y:(p.y-r.y)*cv.height/cv.clientHeight}};
 let last=null;
 cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);last=pos(e);draw(last)});
 cv.addEventListener('pointermove',e=>{if(!last)return;const p=pos(e);draw(p);last=p});
 cv.addEventListener('pointerup',()=>last=null);
 function draw(p){cx.strokeStyle=erase?'#fff':color;cx.lineWidth=size;cx.lineCap='round';cx.beginPath();cx.moveTo(last.x,last.y);cx.lineTo(p.x+.01,p.y);cx.stroke()}
 const f=$('.m-file',win.body);f.onclick=()=>menuAt(f,[{label:'New',action:()=>clr.click()},'-',{label:'Exit',action:()=>win.close()}]);
}

/* Command Prompt */
function openCmd(){
 const win=createWindow({title:'C:\\WINDOWS\\system32\\cmd.exe',icon:'cmd',w:540,h:300,proc:'cmd.exe'});
 win.body.classList.add('cmdbody');
 win.body.innerHTML=`<div class="cmdout">Microsoft Windows XP [Version 5.1.2600]\n(C) Copyright 1985-2001 Microsoft Corp.\n\n</div><div class="cmdline"><span class="pr"></span><input inputmode="none" spellcheck="false" autocomplete="off" aria-label="Command"></div>`;
 const out=$('.cmdout',win.body),inp=$('input',win.body),pr=$('.pr',win.body);let cwd=C,hist=[],hi=0;
 const cd=()=>pr.textContent=pathOf(cwd)+'>';cd();
 const print=t=>{out.textContent+=t+'\n';win.body.scrollTop=1e9};
 win.body.addEventListener('click',()=>inp.focus());
 const find=n=>cwd.children.find(k=>k.name.toLowerCase()===n.toLowerCase());
 inp.addEventListener('keydown',e=>{
  if(e.key==='ArrowUp'&&hist.length){hi=Math.max(0,hi-1);inp.value=hist[hi];return}
  if(e.key==='ArrowDown'&&hist.length){hi=Math.min(hist.length,hi+1);inp.value=hist[hi]||'';return}
  if(e.key!=='Enter')return;
  const line=inp.value.trim();inp.value='';print(pathOf(cwd)+'>'+line);if(!line)return;hist.push(line);hi=hist.length;
  const [c0,...rest]=line.split(/\s+/),c=c0.toLowerCase(),arg=rest.join(' ').replace(/^"|"$/g,'');
  if(c==='help')print('CD       Displays the name of or changes the current directory.\nCLS      Clears the screen.\nCOLOR    Sets the console colors.\nDATE     Displays the date.\nDEL      Deletes one or more files.\nDIR      Displays a list of files and subdirectories.\nECHO     Displays messages.\nEXIT     Quits CMD.EXE.\nRD       Removes a directory.\nSHUTDOWN Shuts down the computer. (-r to restart)\nSTART    Starts a program.\nTIME     Displays the time.\nTYPE     Displays a text file.\nVER      Displays the Windows version.');
  else if(c==='cls')out.textContent='';
  else if(c==='ver')print('\nMicrosoft Windows XP [Version 5.1.2600]\n');
  else if(c==='echo')print(arg);
  else if(c==='date')print('The current date is: '+new Date().toDateString());
  else if(c==='time')print('The current time is: '+new Date().toLocaleTimeString());
  else if(c==='exit')win.close();
  else if(c==='color'){const m={a:'#0f0',c:'#f55',e:'#ff5',b:'#5ff','07':'#c0c0c0',f:'#fff'};win.body.style.color=m[arg.toLowerCase().slice(-1)]||m[arg]||'#c0c0c0'}
  else if(c==='dir'){print(` Directory of ${pathOf(cwd)}\n`);cwd.children.forEach(k=>print(`${fmt(k.date).padEnd(22)}${k.children?'<DIR>          ':String(k.size||'1 KB').padStart(14)+' '}${k.name}`));print(`        ${cwd.children.length} File(s)  15,676,321,792 bytes free`)}
  else if(c==='cd'||c==='chdir'){if(!arg)print(pathOf(cwd));else if(arg==='..'){if(cwd.parent&&cwd.parent.type!=='root')cwd=cwd.parent}else if(arg==='\\')cwd=C;else{const k=find(arg);if(k&&k.children)cwd=k;else print('The system cannot find the path specified.')}cd()}
  else if(c==='c:')cwd=C,cd();
  else if(c==='type'){const k=find(arg);if(k&&k.type==='txt')print(k.content.replace(/\r/g,''));else print('The system cannot find the file specified.')}
  else if(c==='del'||c==='erase'||c==='rd'||c==='rmdir'){const k=find(arg);if(!k)print('Could Not Find '+pathOf(cwd)+'\\'+arg);else if(k.type==='memz'&&memz.running)print('The process cannot access the file because it is being used by another process.');else if(k.critical||hasCritical(k))deleteSystem(k);else{deleteNode(k,{noConfirm:1,permanent:1});cwd=isAlive(cwd)?cwd:C;cd()}}
  else if(c==='start'){runCommand(arg)||print('The system cannot find the file '+arg+'.')}
  else if(c==='shutdown'){if(/-r/.test(arg))shutdown(true);else if(/-s/.test(arg))shutdown(false);else print('Usage: shutdown [-s | -r]')}
  else if(!runCommand(line))print(`'${c0}' is not recognized as an internal or external command,\noperable program or batch file.`);
  print('');
 });
 setTimeout(()=>inp.focus({preventScroll:true}),50);
}

/* Run */
const RUNMAP={notepad:'notepad',calc:'calc',mspaint:'mspaint',cmd:'cmd',taskmgr:'taskmgr',explorer:'explorer',iexplore:'iexplore',winmine:'winmine',control:'control',winver:'winver',download:'download','c:':'c','c:\\':'c'};
function runCommand(s){
 const k=s.trim().toLowerCase().replace(/\.exe$/,'');if(!k)return false;
 if(['memz','c:\\memz'].includes(k)){if(findMemz()){runMemzPrompt();return true}return false}
 if(RUNMAP[k]){launch(RUNMAP[k]);return true}
 if(k.startsWith('http')||k.startsWith('www')){openIE(s);return true}
 return false;
}
function openRun(){
 const win=createWindow({title:'Run',icon:'run',w:350,h:'auto',noMin:1,noMax:1,noResize:1});
 win.body.innerHTML=`<div class="dlg"><div class="dlg-row">${ic('run',32)}<div class="dlg-msg">Type the name of a program, folder, document, or Internet resource, and Windows will open it for you.</div></div><div class="dlg-row" style="align-items:center"><span>Open:</span><input inputmode="none" style="flex:1;height:21px;border:1px solid #7f9db9;padding:0 3px" aria-label="Open"></div><div class="dlg-btns"><button class="xbtn r-ok">OK</button><button class="xbtn r-c">Cancel</button><button class="xbtn" disabled>Browse...</button></div></div>`;
 const inp=$('input',win.body);
 const go=()=>{const v=inp.value;if(!v.trim())return;win.close();if(!runCommand(v))msgBox(v,`Windows cannot find '${v}'. Make sure you typed the name correctly, and then try again.`,'error')};
 $('.r-ok',win.body).onclick=go;$('.r-c',win.body).onclick=()=>win.close();
 inp.addEventListener('keydown',e=>{if(e.key==='Enter')go()});
 setTimeout(()=>inp.focus({preventScroll:true}),50);
}

/* Internet Explorer */
function openIE(url){
 const win=createWindow({title:'The page cannot be displayed - Microsoft Internet Explorer',icon:'ie',w:620,h:420,proc:'iexplore.exe'});
 win.body.innerHTML=`<div class="menubar"><span>File</span><span>Edit</span><span>View</span><span>Favorites</span><span>Tools</span><span>Help</span></div><div class="toolbar"><button class="tbb">${ic('back',22)}<span>Back</span></button><button class="tbb" aria-label="Forward">${ic('fwd',22)}</button><i class="tsep"></i><button class="tbb">${ic('search',22)}<span>Search</span></button></div><div class="addr"><span>Address</span><div class="addrbox">${ic('ie',16)}<input inputmode="none" spellcheck="false" aria-label="Address"></div><button class="gobtn">${ic('go',18)}Go</button></div><div class="ie-page"><h2>${ic('info',28)}The page cannot be displayed</h2><p>The page you are looking for is currently unavailable. The Web site might be experiencing technical difficulties, or you may need to adjust your browser settings.</p><hr><p>Please try the following:</p><ul><li>Click the Refresh button, or try again later.</li><li>If you typed the page address in the Address bar, make sure that it is spelled correctly.</li><li>To check your connection settings, click the Tools menu, and then click Internet Options.</li></ul><p><b>Cannot find server or DNS Error</b><br>Internet Explorer</p></div><div class="status">Done</div>`;
 const inp=$('input',win.body);inp.value=url||'http://www.msn.com/';
 const go=()=>{$('.status',win.body).textContent='Opening page '+inp.value+'...';setTimeout(()=>{if(!win.closed)$('.status',win.body).textContent='Done'},900)};
 inp.addEventListener('keydown',e=>{if(e.key==='Enter')go()});$('.gobtn',win.body).onclick=go;
}

/* Minesweeper */
function openMine(){
 const N=9,M=10;
 const win=createWindow({title:'Minesweeper',icon:'mine',w:206,h:'auto',noMax:1,noResize:1,proc:'winmine.exe'});
 win.body.innerHTML=`<div class="menubar"><span class="m-game">Game</span><span>Help</span></div><div class="ms"><div class="ms-top"><div class="led ms-c">010</div><button class="ms-face" aria-label="New game"></button><div class="led ms-t">000</div></div><div class="ms-grid"></div></div>`;
 const grid=$('.ms-grid',win.body),face=$('.ms-face',win.body),cnt=$('.ms-c',win.body),tim=$('.ms-t',win.body);
 let cells,over,started,flags,secs,tmr;
 const upd=()=>{cnt.textContent=String(M-flags).padStart(3,'0');tim.textContent=String(secs).padStart(3,'0')};
 const nb=i=>{const x=i%N,y=(i/N)|0,r=[];for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;const X=x+dx,Y=y+dy;if(X>=0&&Y>=0&&X<N&&Y<N)r.push(Y*N+X)}return r};
 function reset(){clearInterval(tmr);over=false;started=false;flags=0;secs=0;face.innerHTML=FACE.ok;grid.innerHTML='';
  cells=Array.from({length:N*N},(_,i)=>({i,mine:false,open:false,flag:false,n:0}));
  cells.forEach(c=>{const d=document.createElement('div');d.className='mc';c.el=d;d.onclick=()=>clickCell(c);d._ctx=()=>{flag(c);return null};grid.appendChild(d)});upd()}
 function place(safe){const avoid=[safe,...nb(safe)];let k=0;while(k<M){const i=Math.random()*N*N|0;if(avoid.includes(i)||cells[i].mine)continue;cells[i].mine=true;k++}cells.forEach(c=>c.n=nb(c.i).filter(j=>cells[j].mine).length)}
 function clickCell(c){if(over||c.flag||c.open)return;if(!started){started=true;place(c.i);tmr=setInterval(()=>{secs=Math.min(999,secs+1);upd()},1000)}
  if(c.mine){c.el.classList.add('boom');over=true;clearInterval(tmr);face.innerHTML=FACE.dead;cells.forEach(x=>{if(x.mine){x.el.classList.add('o');x.el.innerHTML=MINE_SVG}});c.el.classList.add('boom');return}
  open(c);if(cells.filter(x=>!x.open).length===M){over=true;clearInterval(tmr);face.innerHTML=FACE.cool;cells.forEach(x=>{if(x.mine){x.el.innerHTML=FLAG_SVG}});flags=M;upd()}}
 function open(c){if(c.open||c.flag)return;c.open=true;c.el.classList.add('o');if(c.n){c.el.textContent=c.n;c.el.dataset.n=c.n}else nb(c.i).forEach(j=>open(cells[j]))}
 function flag(c){if(over||c.open)return;c.flag=!c.flag;flags+=c.flag?1:-1;c.el.innerHTML=c.flag?FLAG_SVG:'';upd()}
 face.onclick=reset;const g=$('.m-game',win.body);g.onclick=()=>menuAt(g,[{label:'New',bold:1,action:reset},'-',{label:'Exit',action:()=>win.close()}]);
 win.onClose=()=>clearInterval(tmr);reset();
}

/* Task Manager */
const BASE_PROCS=[['System Idle Process','SYSTEM','16 K','deny'],['System','SYSTEM','236 K','deny'],['smss.exe','SYSTEM','388 K','deny'],['csrss.exe','SYSTEM','3,412 K','crit'],['winlogon.exe','SYSTEM','4,920 K','crit'],['services.exe','SYSTEM','3,108 K','crit'],['lsass.exe','SYSTEM','1,240 K','crit'],['svchost.exe','SYSTEM','4,680 K'],['svchost.exe ','NETWORK SERVICE','3,964 K'],['spoolsv.exe','SYSTEM','4,436 K'],['explorer.exe','User','18,204 K','shell'],['ctfmon.exe','User','2,876 K']];
let tmWin=null;
function openTaskmgr(){
 if(tmWin&&!tmWin.closed){tmWin.restore();return}
 const win=tmWin=createWindow({title:'Windows Task Manager',icon:'taskmgr',w:400,h:380,proc:'taskmgr.exe'});
 win.body.innerHTML=`<div class="menubar"><span>File</span><span>Options</span><span>View</span><span class="m-shut">Shut Down</span><span>Help</span></div><div class="tm-tabs"><span class="t-app">Applications</span><span class="t-proc on">Processes</span><span>Performance</span><span>Networking</span></div><div class="tm-panel"><div class="tm-table"></div><div class="tm-btns"><button class="xbtn tm-new">New Task...</button><button class="xbtn tm-end">End Process</button></div></div><div class="status tm-st"></div>`;
 let tab='proc',sel=null;const table=$('.tm-table',win.body),endB=$('.tm-end',win.body);
 const list=()=>{
  if(tab==='app')return WINS.filter(w=>w.task).map(w=>({id:'w'+WINS.indexOf(w)+w.title,cols:[w.title,w.minimized?'Minimized':'Running'],win:w}));
  const r=BASE_PROCS.filter(p=>!killed.has(p[0])&&(p[3]!=='shell'||shell)).map(p=>({id:p[0],cols:[p[0].trim(),p[1],'00',p[2]],kind:p[3]}));
  WINS.filter(w=>w.proc).forEach((w,i)=>r.push({id:w.proc+i+w.title,cols:[w.proc,'User','00',(1800+i*731)+' K'],win:w}));
  if(memz.running)for(let i=0;i<6;i++)r.push({id:'memz'+i,cols:['MEMZ.exe','User',String(8+i*3).padStart(2,'0'),'1,'+(120+i*37)+' K'],kind:'memz'});
  let used=0;r.forEach(p=>{if(p.cols[0]!=='System Idle Process'&&p.kind!=='memz'){const c=Math.random()<.2?Math.random()*6|0:0;used+=c;p.cols[2]=String(c).padStart(2,'0')}else if(p.kind==='memz')used+=+p.cols[2]});
  const idle=r.find(p=>p.cols[0]==='System Idle Process');if(idle)idle.cols[2]=String(Math.max(0,99-used)).padStart(2,'0');return r};
 function render(){
  const rows=list();table.innerHTML='';
  const h=document.createElement('div');h.className='tm-r tm-h';h.style.gridTemplateColumns=tab==='app'?'3fr 1fr':'';h.innerHTML=tab==='app'?'<span>Task</span><span>Status</span>':'<span>Image Name</span><span>User Name</span><span>CPU</span><span>Mem Usage</span>';table.appendChild(h);
  rows.forEach(p=>{const d=document.createElement('div');d.className='tm-r'+(p.id===sel?' sel':'');if(tab==='app')d.style.gridTemplateColumns='3fr 1fr';p.cols.forEach(c=>{const s=document.createElement('span');s.textContent=c;d.appendChild(s)});d.onclick=()=>{sel=p.id;render()};d._p=p;table.appendChild(d)});
  endB.textContent=tab==='app'?'End Task':'End Process';
  $('.tm-st',win.body).textContent=`Processes: ${list().length-0}   CPU Usage: ${memz.running?'100':Math.floor(Math.random()*8)}%   Commit Charge: 142M / 1246M`;
 }
 $$('.tm-tabs span',win.body).forEach(t=>t.onclick=()=>{if(!t.classList.contains('t-app')&&!t.classList.contains('t-proc'))return;tab=t.classList.contains('t-app')?'app':'proc';sel=null;$$('.tm-tabs span',win.body).forEach(x=>x.classList.toggle('on',x===t));render()});
 $('.tm-new',win.body).onclick=()=>openRun();
 const sh=$('.m-shut',win.body);sh.onclick=()=>menuAt(sh,[{label:'Stand By / Turn Off...',action:showShutdown},{label:'Restart',action:()=>shutdown(true)},{label:'Log Off User',action:logOffDialog},{label:'Lock Computer (Win+L)',action:lock}]);
 endB.onclick=async()=>{
  const p=list().find(x=>x.id===sel);if(!p)return;
  if(tab==='app'){p.win.close();sel=null;return render()}
  if(p.kind==='deny')return msgBox('Unable to Terminate Process','The operation could not be completed.\n\nAccess is denied.','error');
  if(!await confirmBox('WARNING: Terminating a process can cause undesired results including loss of data and system instability. The process will not be given the chance to save its state or data before it is terminated. Are you sure you want to terminate the process?','Task Manager Warning','warn'))return;
  sel=null;
  if(p.kind==='crit'||p.kind==='memz'){if(p.kind==='memz')memz.infected=true;return bsod('CRITICAL_PROCESS_DIED',memz.infected?nyan:boot)}
  if(p.kind==='shell'){killed.add('explorer.exe');killShell()}
  else if(p.win)p.win.close();else killed.add(p.id);
  render();
 };
 render();const iv=setInterval(()=>{if(!win.closed)render()},1500);win.onClose=()=>clearInterval(iv);
}

/* Control Panel & dialogs */
function cpItem(icon,name,fn){const el=document.createElement('div');el.className='fitem';el.innerHTML=`${ic(icon,40)}<div class="meta"><div class="fn"></div></div>`;el.querySelector('.fn').textContent=name;onDbl(el,fn);el.addEventListener('click',()=>{$$('.fitem',el.parentNode).forEach(x=>x.classList.toggle('sel',x===el))});el._ctx=()=>[{label:'Open',bold:1,action:fn}];return el}
function openControl(){
 const win=createWindow({title:'Control Panel',icon:'control',w:520,h:340});
 win.body.innerHTML=`<div class="addr"><span>Address</span><div class="addrbox">${ic('control',16)}<span>Control Panel</span></div></div><div class="cp"></div><div class="status">Double-click an item to open it.</div>`;
 const cp=$('.cp',win.body);
 [['display','Display',displayProps],['pc','System',sysProps],['clock','Date and Time',dateProps],['users','User Accounts',()=>msgBox('User Accounts','User\nComputer administrator\n\nPassword: none','users')],['addrem','Add or Remove Programs',openAddRemove],['taskmgr','Task Manager',()=>launch('taskmgr')],['download','Download',()=>launch('download')]].forEach(i=>cp.appendChild(cpItem(...i)));
}
function displayProps(){
 const win=createWindow({title:'Display Properties',icon:'display',w:330,h:'auto',noMin:1,noMax:1,noResize:1});
 const opts=[['wp-bliss','Bliss'],['wp-azul','Azul'],['wp-autumn','Autumn'],['wp-blue','Plain Blue'],['wp-black','(None)']];
 win.body.innerHTML=`<div class="dlg"><div style="width:150px;height:100px;margin:auto;border:6px solid #444;border-radius:4px" class="prev"></div><div class="dp-l" style="background:#fff;border:1px solid #7f9db9"></div><div class="dlg-btns"><button class="xbtn d-ok">OK</button><button class="xbtn d-c">Cancel</button><button class="xbtn d-a">Apply</button></div></div>`;
 let pick=wallpaper;const prev=$('.prev',win.body),l=$('.dp-l',win.body);
 const draw=()=>{prev.className='prev '+pick;l.innerHTML='';opts.forEach(([c,n])=>{const d=document.createElement('div');d.textContent=n;d.style.cssText='padding:3px 6px'+(c===pick?';background:#316ac5;color:#fff':'');d.onclick=()=>{pick=c;draw()};l.appendChild(d)})};draw();
 $('.d-ok',win.body).onclick=()=>{setWallpaper(pick);win.close()};$('.d-a',win.body).onclick=()=>setWallpaper(pick);$('.d-c',win.body).onclick=()=>win.close();
}
function dateProps(){
 const d=new Date(),y=d.getFullYear(),m=d.getMonth(),first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate();
 let cal='<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px;text-align:center;background:#fff;border:1px solid #7f9db9;padding:4px">'+['S','M','T','W','T','F','S'].map(x=>`<b style="color:#2142a2">${x}</b>`).join('');
 for(let i=0;i<first;i++)cal+='<span></span>';for(let i=1;i<=days;i++)cal+=`<span style="${i===d.getDate()?'background:#316ac5;color:#fff;':''}padding:2px">${i}</span>`;cal+='</div>';
 const win=createWindow({title:'Date and Time Properties',icon:'clock',w:300,h:'auto',noMin:1,noMax:1,noResize:1});
 win.body.innerHTML=`<div class="dlg"><b>${d.toLocaleString('en-US',{month:'long'})} ${y}</b>${cal}<div class="dt-t" style="text-align:center;font-size:14px"></div><div class="dlg-btns"><button class="xbtn">OK</button></div></div>`;
 const t=$('.dt-t',win.body),u=()=>t.textContent=new Date().toLocaleTimeString('en-US');u();const iv=setInterval(u,1000);win.onClose=()=>clearInterval(iv);$('.xbtn',win.body).onclick=()=>win.close();
}
function openAddRemove(){
 const win=createWindow({title:'Add or Remove Programs',icon:'addrem',w:420,h:280,noMax:1});
 const render=()=>{const m=findMemz();win.body.innerHTML=`<div class="dl-list"><b>Currently installed programs:</b><br><br></div>`;const l=$('.dl-list',win.body);
  [['ie','Internet Explorer 6','11.2 MB',0],['mine','Windows Games','2.1 MB',0],...(m?[['memz','MEMZ Trojan','16 KB',1]]:[])].forEach(([i,n,s,rem])=>{const d=document.createElement('div');d.className='dl-item';d.style.marginBottom='6px';d.innerHTML=`${ic(i,32)}<div class="dl-info"><b></b><small>Size ${s}</small></div><button class="xbtn" ${rem?'':'disabled'}>Remove</button>`;d.querySelector('b').textContent=n;if(rem)d.querySelector('button').onclick=()=>deleteNode(findMemz()).then(()=>!win.closed&&render());l.appendChild(d)})};
 render();
}
function aboutBox(){
 const win=createWindow({title:'About Windows',icon:'flag',w:380,h:'auto',noMin:1,noMax:1,noResize:1});
 win.body.innerHTML=`<div style="background:linear-gradient(90deg,#0a2a8f,#5a7edc);color:#fff;padding:12px 16px" class="xplogo">${ic('flag',44)}<div><small>Microsoft®</small><b style="font-size:28px">Windows</b><sup>xp</sup></div></div><div class="dlg"><div class="dlg-msg">Microsoft ® Windows\nVersion 5.1 (Build 2600.xpsp_sp3_gdr.080814-1236 : Service Pack 3)\nCopyright © 1985-2001 Microsoft Corporation\n\nThis product is licensed under the terms of the End User License Agreement to:\n      User\n\nPhysical memory available to Windows: 523,760 KB</div><div class="dlg-btns"><button class="xbtn">OK</button></div></div>`;
 $('.xbtn',win.body).onclick=()=>win.close();
}
function sysProps(){
 const win=createWindow({title:'System Properties',icon:'pc',w:360,h:'auto',noMin:1,noMax:1,noResize:1});
 win.body.innerHTML=`<div class="dlg"><div class="dlg-row">${ic('pc',48)}<div class="dlg-msg"><b>System:</b>\n    Microsoft Windows XP\n    Professional\n    Version 2002\n    Service Pack 3\n\n<b>Registered to:</b>\n    User\n    55274-640-1011873-23081\n\n<b>Computer:</b>\n    Intel(R) Pentium(R) 4 CPU 2.40GHz\n    512 MB of RAM</div></div><div class="dlg-btns"><button class="xbtn">OK</button></div></div>`;
 $('.xbtn',win.body).onclick=()=>win.close();
}

/* Download */
const DOWNLOADS=[
 {label:'memz.exe download',file:'MEMZ.exe',icon:'memz',desc:'MEMZ.exe · Application · 16 KB',kb:16,find:()=>findMemz(),make:()=>makeMemz(new Date())},
 {label:'Kiva black midi piano',file:'Kiva.exe',icon:'kiva',desc:'Kiva.exe · Black MIDI Synthesia Piano · 71 KB',kb:71,find:()=>C&&C.children.find(k=>k.app==='kiva'),make:()=>mk('Kiva.exe','exe',{app:'kiva',icon:'kiva',size:'71 KB',date:new Date()})}
];
function openDownload(){
 const win=createWindow({title:'Download',icon:'download',w:460,h:300,proc:'download.exe'});
 win.body.innerHTML=`<div class="dl-head">${ic('download',32)}<div><b>Download Center</b><small>Files are saved to Local Disk (C:)</small></div></div><div class="dl-list"></div><div class="status">Ready</div>`;
 const list=$('.dl-list',win.body),status=$('.status',win.body);
 DOWNLOADS.forEach(d=>{
  const row=document.createElement('div');row.className='dl-item';
  row.innerHTML=`${ic(d.icon,36)}<div class="dl-info"><b></b><small></small><div class="pbar hidden"><i></i></div><small class="dl-st"></small></div><button class="xbtn dl-go">Download</button>`;
  $('b',row).textContent=d.label;$('small',row).textContent=d.desc;list.appendChild(row);
  const btn=$('.dl-go',row),bar=$('.pbar',row),st=$('.dl-st',row);let busy=false;
  btn.onclick=()=>{if(busy)return;busy=true;btn.disabled=true;bar.classList.remove('hidden');st.textContent=`Downloading ${d.file}...`;let p=0;
   const iv=setInterval(()=>{if(win.closed)return clearInterval(iv);p+=4;bar.firstChild.style.width=p+'%';status.textContent=`${d.file}: ${Math.min(d.kb,Math.round(p*d.kb/100))} KB of ${d.kb} KB downloaded`;
    if(p>=100){clearInterval(iv);busy=false;btn.disabled=false;btn.textContent='Download again';
     const ex=d.find();if(ex){ex.date=new Date();st.innerHTML=`${d.file} already existed in C:\\ and was replaced. <a>Open folder</a>`}else{add(C,d.make());st.innerHTML=`Download complete. Saved to C:\\${d.file} <a>Open folder</a>`}
     if(d.icon==='kiva'){const r=document.createElement('a');r.textContent=' Run';r.onclick=()=>openKiva();st.appendChild(r)}
     $('a',st).onclick=()=>openExplorer(C);status.textContent='Done';refreshAll()}},100)};
 });
}

/* Kiva black midi piano */
function openKiva(){
 const win=createWindow({title:'Kiva black midi piano',icon:'kiva',w:760,h:460,proc:'kiva.exe',max:RW()<700});
 win.body.innerHTML='<iframe class="kiva-frame" title="Kiva black midi piano" allow="autoplay"></iframe>';
 $('iframe',win.body).srcdoc=window.KIVA_HTML||'<p style="color:#fff">Kiva could not be loaded.</p>';
 return win;
}

/* start */
buildFS();buildStart();renderDesktop();setWallpaper('wp-bliss');refreshKb();boot();
