RUMAL HISAB MANAGER - ANDROID PROJECT

यह Android Studio प्रोजेक्ट है। इसमें आपका Rumal Hisab Manager वेब ऐप Android WebView के अंदर चलता है।
मजदूरी दर: ₹5 प्रति जमा रुमाल। लेबर नाम/मोबाइल खोज, क्रेडिट-डेबिट एंट्री और लेजर HTML फाइल में शामिल हैं।

APK बनाने का तरीका:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में इस ZIP को Extract करके RumalHisabAndroid फोल्डर Open करें।
3. Gradle Sync पूरा होने दें। जरूरत पड़ने पर Android SDK Platform 35 इंस्टॉल करें।
4. मेन्यू Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।
6. APK फोन में भेजकर इंस्टॉल करें। फोन में "Install unknown apps" की अनुमति मांग सकता है।

जरूरी:
- इस चैट के उपलब्ध वातावरण में Android SDK/Gradle build tool नहीं है, इसलिए यहां सीधे तैयार APK compile नहीं हो सका।
- डेटा फोन के ऐप के local storage में रहता है। ऐप का डेटा/ऐप हटाने से पहले बैकअप लें।
- यह शुरुआती WebView APK project है; Play Store पर डालने से पहले signing, testing और backup/export की Android-native जाँच जरूरी है।
