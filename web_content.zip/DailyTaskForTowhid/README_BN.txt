Daily Task for Towhid — Android Studio Project

এই প্রজেক্টে আপনার দেওয়া Notebook 2026 Report HTML একইভাবে Android WebView-এর মধ্যে চালানো হবে।
ইন্টারনেট ছাড়াই কাজ করবে। WebView DOM storage চালু আছে, তাই একই অ্যাপের ভিতরে LocalStorage-এ Task ও Draft সংরক্ষিত থাকবে।

APK তৈরি করার নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio খুলে Open নির্বাচন করুন।
3. এই ZIP Extract করে DailyTaskForTowhid ফোল্ডারটি Open করুন।
4. Gradle Sync শেষ হতে দিন (প্রথমবার ইন্টারনেট লাগবে, SDK 35 ও Gradle dependencies নামবে)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
6. APK পাওয়া যাবে: app/build/outputs/apk/debug/app-debug.apk
7. APK ফোনে পাঠিয়ে Install করুন। প্রয়োজনে Android Settings থেকে Install unknown apps অনুমতি দিন।

নোট:
- এই পরিবেশে Android SDK/Gradle ইনস্টল নেই, তাই সরাসরি APK compile করা সম্ভব হয়নি। এটি সম্পূর্ণ Android Studio project; Android Studio দিয়ে APK তৈরি করা যাবে।
- অ্যাপের ডেটা ফোনের অ্যাপ স্টোরেজে থাকবে। App data clear বা অ্যাপ uninstall করলে ডেটা মুছে যেতে পারে। নিয়মিত Backup ডাউনলোড/রিস্টোর ব্যবহার করুন।
- HTML-এর বর্তমান LocalStorage key ও মূল ডিজাইন/ফিচার অপরিবর্তিত রাখা হয়েছে।
