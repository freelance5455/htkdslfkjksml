# CGD — Étape 6.5 : écran 05, Choix du club (disposition FM27)

- Dernière étape de la nouvelle carrière : liste des 36 clubs disponibles à gauche (nom, division, étoiles selon la division), fiche du club choisi à droite (effectif avec niveaux, budget, objectifs du conseil), bouton « Prendre mes fonctions ».
- Le choix de la galaxie de départ reste obligatoire et se fait dans la barre du haut ; le rappel Mode / Réputation / IA et le bouton « Modifier » (retour à la configuration) sont conservés.
- En mode « sans emploi », la liste est remplacée par un message : le poste se choisit sur le marché des emplois.
- Les 24 emplacements des Ligues C et D restent verrouillés (indiqué sous la fiche).
- Les objectifs affichés sont ceux que le conseil donne réellement à la prise de fonction (3 objectifs par défaut, identiques pour tous les clubs).
- La validation du formulaire est inchangée (`validateCareerSelection`, `createManagerProfile`, prise de fonction et message de bienvenue).
- En paysage bas (≤ 560 px) l'en-tête CGD est masqué et la page ne défile pas ; seules la liste et la fiche défilent à l'intérieur.
- Code : `src/club-pick.js`, branchements dans `src/app.js` (étape « club » de renderCareerProfile), styles dans le bloc `fm27-terrain`.
- Non fait : l'ordre des étapes de création reste Profil → Configuration → Compétition → Club (la maquette prévoit Configuration → Manager → Club) ; écrans 03 et 04 à refaire ensuite.
