import { json, tokenFrom } from '../../../../_utils.js';
export async function onRequestDelete({ request, params, env }) {
  const token = tokenFrom(request);
  if (!token) return json({error:'Creator token missing.'},401);
  const owned = await env.DB.prepare('SELECT id FROM quizzes WHERE id = ? AND creator_token = ?').bind(params.id,token).first();
  if (!owned) return json({error:'Quiz not found or you do not own it.'},404);
  await env.DB.prepare('DELETE FROM results WHERE id = ? AND quiz_id = ?').bind(params.resultId,params.id).run();
  return json({ok:true});
}
