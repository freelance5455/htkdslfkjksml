import { json, tokenFrom } from './_utils.js';

export async function onRequestGet({ request, params, env }) {
  const row = await env.DB.prepare('SELECT id, creator_name, creator_token, category, questions_json, created_at FROM quizzes WHERE id = ?').bind(params.id).first();
  if (!row) return json({error:'Quiz not found.'},404);
  const isOwner = tokenFrom(request) && tokenFrom(request) === row.creator_token;
  const allQuestions = JSON.parse(row.questions_json);
  const questions = isOwner
    ? allQuestions
    : allQuestions.map(q => ({id:q.id,text:q.text,options:q.options,image:q.image || ''}));
  let results = [];
  if (isOwner) {
    const rs = await env.DB.prepare('SELECT id, participant_name, score, total, percentage, created_at FROM results WHERE quiz_id = ? ORDER BY created_at DESC').bind(params.id).all();
    results = (rs.results || []).map(r => ({id:r.id,participantName:r.participant_name,score:r.score,total:r.total,percentage:r.percentage,createdAt:r.created_at}));
  }
  return json({quiz:{id:row.id,creatorName:row.creator_name,category:row.category,questions,createdAt:row.created_at,results}});
}

export async function onRequestDelete({ request, params, env }) {
  const token = tokenFrom(request);
  if (!token) return json({error:'Creator token missing.'},401);
  const row = await env.DB.prepare('SELECT id FROM quizzes WHERE id = ? AND creator_token = ?').bind(params.id,token).first();
  if (!row) return json({error:'Quiz not found or you do not own it.'},404);
  await env.DB.prepare('DELETE FROM results WHERE quiz_id = ?').bind(params.id).run();
  await env.DB.prepare('DELETE FROM quizzes WHERE id = ? AND creator_token = ?').bind(params.id,token).run();
  return json({ok:true});
}
