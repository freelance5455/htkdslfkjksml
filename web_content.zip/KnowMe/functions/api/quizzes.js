import { json, tokenFrom, safeQuiz } from './_utils.js';

export async function onRequestGet({ request, env }) {
  const token = tokenFrom(request);
  if (!token) return json({error:'Creator token missing.'}, 401);
  const rows = await env.DB.prepare('SELECT id, creator_name, category, questions_json, created_at FROM quizzes WHERE creator_token = ? ORDER BY created_at DESC').bind(token).all();
  const quizzes = [];
  for (const row of (rows.results || [])) {
    const rs = await env.DB.prepare('SELECT id, participant_name, score, total, percentage, created_at FROM results WHERE quiz_id = ? ORDER BY created_at DESC').bind(row.id).all();
    quizzes.push({id:row.id,creatorName:row.creator_name,category:row.category,questions:JSON.parse(row.questions_json),createdAt:row.created_at,results:(rs.results||[]).map(r=>({id:r.id,participantName:r.participant_name,score:r.score,total:r.total,percentage:r.percentage,createdAt:r.created_at}))});
  }
  return json({quizzes});
}

export async function onRequestPost({ request, env }) {
  const token = tokenFrom(request);
  if (!token) return json({error:'Creator token missing.'}, 401);
  let body;
  try { body = await request.json(); } catch { return json({error:'Invalid JSON.'},400); }
  const quiz = safeQuiz(body);
  if (!quiz) return json({error:'Please check the quiz details and questions.'},400);
  const exists = await env.DB.prepare('SELECT id FROM quizzes WHERE id = ?').bind(quiz.id).first();
  if (exists) return json({error:'Quiz code collision. Please publish again.'},409);
  await env.DB.prepare('INSERT INTO quizzes (id, creator_name, creator_token, category, questions_json) VALUES (?, ?, ?, ?, ?)').bind(quiz.id, quiz.creatorName, token, quiz.category, JSON.stringify(quiz.questions)).run();
  return json({id:quiz.id,ok:true},201);
}
