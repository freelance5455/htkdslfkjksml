export function json(data, status=200) {
  return new Response(JSON.stringify(data), {status, headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}});
}
export function tokenFrom(request) {
  const t = request.headers.get('X-KnowMe-Token') || '';
  return /^[a-f0-9-]{20,80}$/i.test(t) ? t : '';
}
export function makeId() {
  return Array.from(crypto.getRandomValues(new Uint8Array(9))).map(x=>x.toString(16).padStart(2,'0')).join('').slice(0,16);
}
export function safeQuiz(body) {
  if (!body || typeof body !== 'object') return null;
  const id = String(body.id || '');
  const creatorName = String(body.creatorName || '').trim().slice(0,40);
  const category = String(body.category || '');
  if (!/^[a-f0-9]{10,20}$/i.test(id) || !creatorName || !['couples','friends','family'].includes(category) || !Array.isArray(body.questions) || body.questions.length < 1 || body.questions.length > 100) return null;
  const questions = [];
  for (const raw of body.questions) {
    const text = String(raw.text || '').trim().slice(0,240);
    const options = Array.isArray(raw.options) ? raw.options.slice(0,4).map(x=>String(x||'').trim().slice(0,120)) : [];
    const correct = Number(raw.correct);
    const image = typeof raw.image === 'string' && raw.image.startsWith('data:image/') && raw.image.length < 1500000 ? raw.image : '';
    if (!text || options.length !== 4 || options.some(x=>!x) || new Set(options).size !== 4 || !Number.isInteger(correct) || correct<0 || correct>3) return null;
    questions.push({id:String(raw.id||makeId()),text,options,correct,image});
  }
  return {id,creatorName,category,questions};
}
