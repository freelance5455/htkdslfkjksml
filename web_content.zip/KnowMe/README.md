# KnowMe — ready-to-deploy starter project

KnowMe is a mobile-friendly quiz website with:
- Welcome screen (name + optional gender choice)
- Create Quiz / Open Quiz Through a Link
- Couples / Friends / Family categories
- 20 starter questions per category
- Custom multiple-choice questions and optional images
- One-question-at-a-time participant flow, locked answers, score at the end
- Creator dashboard, result list, share links, delete quiz/result controls
- Three sound effects (buttons, answer lock, results reveal), with mute control
- Cloudflare Pages + Pages Functions + D1 database support

## Important honesty note
This project is ready for deployment configuration, but it is **not yet online** and no domain has been purchased or connected. Test it locally first. The database-backed features require deploying to Cloudflare Pages and creating/binding a D1 database. Do not publish a real quiz until you have tested the deployment and privacy rules.

## Deploy with Cloudflare Pages
1. Create a GitHub repository and upload the contents of this folder (not the ZIP itself).
2. In Cloudflare, open **Workers & Pages → Create → Pages → Connect to Git** and select the repository.
3. Framework preset: **None**. Build command: leave blank. Build output directory: `/public`.
4. In the Pages project, open **Settings → Functions → D1 database bindings** and add a binding named `DB` connected to your D1 database.
5. Create a D1 database named `knowme-db`.
6. Run the SQL in `schema.sql` against that database using the Cloudflare D1 console.
7. Deploy/redeploy. Your Pages Functions in `/functions/api/` provide the backend.
8. Test quiz creation, sharing, submission, and deletion using two different browsers/devices.
9. Only after tests pass, buy a domain if you want one, then add it in Cloudflare Pages → Custom domains and follow its DNS instructions.

## Security / production checklist
- This version uses a creator access token stored in the browser and sent to the API. Keep it private.
- It includes basic validation and a same-origin API design, but it is not a professional security audit. Before a large public launch, add rate limiting, abuse reporting, data retention rules, and stronger creator authentication.
- Participant display names are public to the quiz creator. Do not ask users to enter sensitive information.
- Images are limited by the browser to 1 MB each and stored as data URLs in D1; for a large public launch, move images to object storage.
- Free hosting/database tiers have usage limits and can change. “Free” is not a guarantee of unlimited capacity.
- No advertising code is included.
