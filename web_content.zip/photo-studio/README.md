# استوديو الصور الذكي — مشروع أندرويد (Capacitor)

## المتطلبات
Node.js 18+ و Android Studio.

## خطوات عمل الـ APK
1. افتح التيرمنال داخل المجلد وشغّل:
   npm install
   npx cap add android
   npx cap sync android
2. لتجربة سريعة: npx cap open android ثم Build > Build APK(s) من Android Studio.
   أو من التيرمنال: cd android && ./gradlew assembleDebug
   الملف يطلع في android/app/build/outputs/apk/debug/
3. لنسخة للنشر: Build > Generate Signed Bundle / APK.

## ملاحظات
- أي تعديل في www/index.html: شغّل npx cap sync android بعده.
- إزالة الخلفية بالذكاء الاصطناعي (@imgly/background-removal) بتشتغل على الجهاز، وبتحمّل النموذج أول مرة بس (محتاج نت)، وبعدها بيتخزن.
- الحفظ: بيفتح قائمة المشاركة، منها تحفظ في المعرض أو الملفات.
- ميزات Claude (الأمر النصي والتحليل): ادخل مفتاح API من تبويب الذكاء الاصطناعي > ⚙ مفتاح Claude API. المفتاح بيتخزن على الجهاز.
