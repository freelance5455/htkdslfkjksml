var C="cwm-v2";
var URLS=["./","index.html","manifest.webmanifest","icon-192.png","icon-512.png",
"https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js",
"https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js",
"https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"];
self.addEventListener("install",function(e){
  e.waitUntil(caches.open(C).then(function(c){return Promise.all(URLS.map(function(u){return c.add(u).catch(function(){})}))}).then(function(){return self.skipWaiting()}));
});
self.addEventListener("activate",function(e){
  e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return x!==C}).map(function(x){return caches.delete(x)}))}).then(function(){return self.clients.claim()}));
});
self.addEventListener("fetch",function(e){
  if(e.request.method!=="GET")return;
  var same=new URL(e.request.url).origin===location.origin;
  function put(res){var cp=res.clone();caches.open(C).then(function(c){c.put(e.request,cp)}).catch(function(){});return res}
  e.respondWith(same
    ?fetch(e.request).then(put).catch(function(){return caches.match(e.request).then(function(r){return r||caches.match("index.html")})})
    :caches.match(e.request).then(function(r){return r||fetch(e.request).then(put)}));
});
