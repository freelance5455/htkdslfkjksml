import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import {
  AnatomicalStructure,
  AnatomicalSystemId,
  ANATOMICAL_STRUCTURES,
} from '../../data/anatomyData';
import {
  Maximize2,
  RotateCcw,
  Eye,
  EyeOff,
  Layers,
  Compass,
  Sparkles,
} from 'lucide-react';

interface Anatomy3DCanvasProps {
  selectedStructure: AnatomicalStructure | null;
  onSelectStructure: (structure: AnatomicalStructure) => void;
  visibleSystems: Record<AnatomicalSystemId, boolean>;
  systemOpacities: Record<AnatomicalSystemId, number>;
  showLabels: boolean;
  showBodySilhouette: boolean;
  highlightedStructureId?: string | null;
  quizTargetId?: string | null;
}

export const Anatomy3DCanvas: React.FC<Anatomy3DCanvasProps> = ({
  selectedStructure,
  onSelectStructure,
  visibleSystems,
  systemOpacities,
  showLabels,
  showBodySilhouette,
  highlightedStructureId,
  quizTargetId,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const meshesMapRef = useRef<Map<string, THREE.Mesh[]>>(new Map());
  const materialsMapRef = useRef<Map<string, THREE.MeshStandardMaterial[]>>(new Map());
  const silhouetteMeshRef = useRef<THREE.Group | null>(null);
  const labelSpritesRef = useRef<Map<string, THREE.Sprite>>(new Map());
  const animFrameIdRef = useRef<number | null>(null);

  const [hoveredStructure, setHoveredStructure] = useState<AnatomicalStructure | null>(null);
  const [activePreset, setActivePreset] = useState<'anterior' | 'posterior' | 'thorax' | 'abdomen' | 'head'>('anterior');

  // Helper to create clean text sprite for 3D label
  const createLabelSprite = (text: string, subtext: string, color: string) => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 80;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      // Rounded pill background
      ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
      ctx.beginPath();
      ctx.roundRect(4, 4, 248, 72, 16);
      ctx.fill();

      // Border with system color
      ctx.lineWidth = 3;
      ctx.strokeStyle = color;
      ctx.stroke();

      // Text
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 22px system-ui, -apple-system, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(text, 128, 34);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '16px system-ui, -apple-system, sans-serif';
      ctx.fillText(subtext, 128, 60);
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    const spriteMaterial = new THREE.SpriteMaterial({
      map: texture,
      transparent: true,
      depthTest: false,
    });
    const sprite = new THREE.Sprite(spriteMaterial);
    sprite.scale.set(0.65, 0.22, 1);
    return sprite;
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x0a0f1d); // Deep medical navy slate

    // Subtle coordinate grid floor
    const grid = new THREE.GridHelper(4, 20, 0x1e293b, 0x0f172a);
    grid.position.y = -1.8;
    scene.add(grid);

    // 2. Camera setup
    const width = container.clientWidth || 600;
    const height = container.clientHeight || 500;
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 50);
    camera.position.set(0, 0.3, 3.4);
    cameraRef.current = camera;

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    rendererRef.current = renderer;
    container.replaceChildren(renderer.domElement);

    // 4. OrbitControls setup
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.minDistance = 0.8;
    controls.maxDistance = 6.0;
    controls.target.set(0, 0.2, 0);
    controls.maxPolarAngle = Math.PI * 0.95;
    controlsRef.current = controls;

    // 5. Lighting rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x090d16, 0.6);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.4);
    keyLight.position.set(3, 4, 4);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 0.7);
    fillLight.position.set(-3, 2, -2);
    scene.add(fillLight);

    const backRimLight = new THREE.DirectionalLight(0xec4899, 0.5);
    backRimLight.position.set(0, 4, -4);
    scene.add(backRimLight);

    // 6. Build Translucent Body Silhouette
    const silhouetteGroup = new THREE.Group();
    silhouetteMeshRef.current = silhouetteGroup;

    const silhouetteMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.08,
      roughness: 0.5,
      metalness: 0.1,
      side: THREE.DoubleSide,
      depthWrite: false,
    });

    // Head silhouette
    const headGeom = new THREE.SphereGeometry(0.32, 24, 24);
    headGeom.scale(1, 1.25, 1.05);
    const headMesh = new THREE.Mesh(headGeom, silhouetteMat);
    headMesh.position.set(0, 1.48, 0.05);
    silhouetteGroup.add(headMesh);

    // Torso silhouette
    const torsoGeom = new THREE.CylinderGeometry(0.48, 0.42, 1.4, 24, 8);
    torsoGeom.scale(1.2, 1, 0.75);
    const torsoMesh = new THREE.Mesh(torsoGeom, silhouetteMat);
    torsoMesh.position.set(0, 0.35, 0.05);
    silhouetteGroup.add(torsoMesh);

    // Pelvis/Hips silhouette
    const hipsGeom = new THREE.SphereGeometry(0.46, 24, 16);
    hipsGeom.scale(1.15, 0.8, 0.75);
    const hipsMesh = new THREE.Mesh(hipsGeom, silhouetteMat);
    hipsMesh.position.set(0, -0.42, 0.02);
    silhouetteGroup.add(hipsMesh);

    // Legs silhouettes
    const legGeom = new THREE.CylinderGeometry(0.18, 0.12, 1.1, 16);
    const leftLegMesh = new THREE.Mesh(legGeom, silhouetteMat);
    leftLegMesh.position.set(0.24, -1.05, 0.02);
    const rightLegMesh = new THREE.Mesh(legGeom, silhouetteMat);
    rightLegMesh.position.set(-0.24, -1.05, 0.02);
    silhouetteGroup.add(leftLegMesh, rightLegMesh);

    // Arms silhouettes
    const armGeom = new THREE.CylinderGeometry(0.12, 0.09, 1.1, 16);
    const leftArmMesh = new THREE.Mesh(armGeom, silhouetteMat);
    leftArmMesh.position.set(0.68, 0.32, 0);
    leftArmMesh.rotation.z = -0.15;
    const rightArmMesh = new THREE.Mesh(armGeom, silhouetteMat);
    rightArmMesh.position.set(-0.68, 0.32, 0);
    rightArmMesh.rotation.z = 0.15;
    silhouetteGroup.add(leftArmMesh, rightArmMesh);

    scene.add(silhouetteGroup);

    // 7. Procedural Anatomical Structure Meshes
    const meshesMap = new Map<string, THREE.Mesh[]>();
    const materialsMap = new Map<string, THREE.MeshStandardMaterial[]>();
    const labelSprites = new Map<string, THREE.Sprite>();

    // Helper to register mesh with structure
    const registerPart = (structureId: string, mesh: THREE.Mesh, mat: THREE.MeshStandardMaterial) => {
      mesh.userData = { structureId };
      const currentList = meshesMap.get(structureId) || [];
      currentList.push(mesh);
      meshesMap.set(structureId, currentList);

      const matList = materialsMap.get(structureId) || [];
      matList.push(mat);
      materialsMap.set(structureId, matList);

      scene.add(mesh);
    };

    // ==========================================
    // BUILD CIRCULATORY SYSTEM
    // ==========================================
    // A. Heart (Muscular body + apex + atria)
    const heartMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      roughness: 0.35,
      metalness: 0.15,
      emissive: 0x450a0a,
      emissiveIntensity: 0.2,
    });
    const heartGroup = new THREE.Group();
    const heartGeom = new THREE.SphereGeometry(0.18, 24, 24);
    heartGeom.scale(1.0, 1.25, 0.9);
    const heartVentricle = new THREE.Mesh(heartGeom, heartMat);
    heartVentricle.position.set(0.08, 0.45, 0.25);
    heartVentricle.rotation.z = -0.35;
    heartVentricle.rotation.x = 0.2;
    registerPart('heart', heartVentricle, heartMat);

    // Atria
    const atriaGeom = new THREE.SphereGeometry(0.12, 18, 18);
    const heartAtria = new THREE.Mesh(atriaGeom, heartMat);
    heartAtria.position.set(0.02, 0.58, 0.22);
    registerPart('heart', heartAtria, heartMat);

    // B. Aorta (Curved arch tube)
    const aortaCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.05, 0.58, 0.24),
      new THREE.Vector3(0.02, 0.76, 0.22),
      new THREE.Vector3(-0.06, 0.78, 0.18),
      new THREE.Vector3(-0.08, 0.65, 0.08),
      new THREE.Vector3(-0.06, 0.15, 0.02),
    ]);
    const aortaGeom = new THREE.TubeGeometry(aortaCurve, 32, 0.045, 12, false);
    const aortaMat = new THREE.MeshStandardMaterial({
      color: 0xdc2626,
      roughness: 0.3,
      metalness: 0.2,
    });
    const aortaMesh = new THREE.Mesh(aortaGeom, aortaMat);
    registerPart('aorta', aortaMesh, aortaMat);

    // C. Vena Cava (Blue venous cylinder)
    const vcCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.14, 0.85, 0.18),
      new THREE.Vector3(-0.12, 0.55, 0.2),
      new THREE.Vector3(-0.12, 0.15, 0.08),
      new THREE.Vector3(-0.1, -0.3, 0.05),
    ]);
    const vcGeom = new THREE.TubeGeometry(vcCurve, 24, 0.04, 12, false);
    const vcMat = new THREE.MeshStandardMaterial({
      color: 0x2563eb,
      roughness: 0.4,
      metalness: 0.1,
    });
    const vcMesh = new THREE.Mesh(vcGeom, vcMat);
    registerPart('vena_cava', vcMesh, vcMat);

    // D. Pulmonary Vessels
    const pvMat = new THREE.MeshStandardMaterial({
      color: 0x6366f1,
      roughness: 0.4,
      metalness: 0.15,
    });
    const pvGeom = new THREE.CylinderGeometry(0.03, 0.03, 0.28, 12);
    const pvLeft = new THREE.Mesh(pvGeom, pvMat);
    pvLeft.position.set(0.18, 0.58, 0.16);
    pvLeft.rotation.z = Math.PI / 3;
    const pvRight = new THREE.Mesh(pvGeom, pvMat);
    pvRight.position.set(-0.18, 0.58, 0.16);
    pvRight.rotation.z = -Math.PI / 3;
    registerPart('pulmonary_vessels', pvLeft, pvMat);
    registerPart('pulmonary_vessels', pvRight, pvMat);

    // ==========================================
    // BUILD RESPIRATORY SYSTEM
    // ==========================================
    // A. Trachea & Main Bronchi
    const tracheaCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 1.15, 0.12),
      new THREE.Vector3(0, 0.88, 0.16),
      new THREE.Vector3(0, 0.72, 0.14),
    ]);
    const tracheaGeom = new THREE.TubeGeometry(tracheaCurve, 20, 0.036, 12, false);
    const tracheaMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.3,
      metalness: 0.1,
    });
    const tracheaMesh = new THREE.Mesh(tracheaGeom, tracheaMat);
    registerPart('trachea', tracheaMesh, tracheaMat);

    // Left and Right Bronchi branches
    const leftBronchusCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0.72, 0.14),
      new THREE.Vector3(0.18, 0.62, 0.12),
    ]);
    const rightBronchusCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0.72, 0.14),
      new THREE.Vector3(-0.18, 0.62, 0.12),
    ]);
    const lbGeom = new THREE.TubeGeometry(leftBronchusCurve, 12, 0.024, 10, false);
    const rbGeom = new THREE.TubeGeometry(rightBronchusCurve, 12, 0.024, 10, false);
    registerPart('trachea', new THREE.Mesh(lbGeom, tracheaMat), tracheaMat);
    registerPart('trachea', new THREE.Mesh(rbGeom, tracheaMat), tracheaMat);

    // B. Right Lung (3 Lobes)
    const rightLungMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.55,
      metalness: 0.05,
      transparent: true,
      opacity: 0.88,
    });
    const rightLungGeom = new THREE.SphereGeometry(0.24, 24, 24);
    rightLungGeom.scale(0.85, 1.45, 0.95);
    const rightLungMesh = new THREE.Mesh(rightLungGeom, rightLungMat);
    rightLungMesh.position.set(-0.34, 0.46, 0.12);
    registerPart('right_lung', rightLungMesh, rightLungMat);

    // C. Left Lung (2 Lobes with cardiac notch)
    const leftLungMat = new THREE.MeshStandardMaterial({
      color: 0x0369a1,
      roughness: 0.55,
      metalness: 0.05,
      transparent: true,
      opacity: 0.88,
    });
    const leftLungGeom = new THREE.SphereGeometry(0.22, 24, 24);
    leftLungGeom.scale(0.78, 1.4, 0.9);
    const leftLungMesh = new THREE.Mesh(leftLungGeom, leftLungMat);
    leftLungMesh.position.set(0.35, 0.48, 0.12);
    registerPart('left_lung', leftLungMesh, leftLungMat);

    // D. Diaphragm Dome
    const diaphragmGeom = new THREE.CylinderGeometry(0.48, 0.52, 0.06, 24);
    diaphragmGeom.scale(1.0, 1.0, 0.65);
    const diaphragmMat = new THREE.MeshStandardMaterial({
      color: 0x0891b2,
      roughness: 0.6,
      metalness: 0.05,
      side: THREE.DoubleSide,
    });
    const diaphragmMesh = new THREE.Mesh(diaphragmGeom, diaphragmMat);
    diaphragmMesh.position.set(0, 0.16, 0.08);
    registerPart('diaphragm', diaphragmMesh, diaphragmMat);

    // ==========================================
    // BUILD DIGESTIVE SYSTEM
    // ==========================================
    // A. Esophagus (Posterior to trachea)
    const esoCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 1.05, 0.02),
      new THREE.Vector3(0, 0.65, 0.02),
      new THREE.Vector3(0.08, 0.22, 0.05),
    ]);
    const esoGeom = new THREE.TubeGeometry(esoCurve, 20, 0.024, 10, false);
    const esoMat = new THREE.MeshStandardMaterial({
      color: 0xf97316,
      roughness: 0.5,
    });
    registerPart('esophagus', new THREE.Mesh(esoGeom, esoMat), esoMat);

    // B. Stomach (J-shaped bag)
    const stomachMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.4,
      metalness: 0.1,
    });
    const stomachGeom = new THREE.SphereGeometry(0.16, 20, 20);
    stomachGeom.scale(1.2, 1.6, 0.85);
    const stomachMesh = new THREE.Mesh(stomachGeom, stomachMat);
    stomachMesh.position.set(0.18, 0.04, 0.18);
    stomachMesh.rotation.z = -0.4;
    registerPart('stomach', stomachMesh, stomachMat);

    // C. Liver (Wedge shape)
    const liverMat = new THREE.MeshStandardMaterial({
      color: 0xb45309,
      roughness: 0.45,
      metalness: 0.1,
    });
    const liverGeom = new THREE.CylinderGeometry(0.1, 0.26, 0.28, 16);
    liverGeom.scale(1.3, 0.9, 0.9);
    const liverMesh = new THREE.Mesh(liverGeom, liverMat);
    liverMesh.position.set(-0.24, 0.08, 0.16);
    liverMesh.rotation.z = 0.5;
    registerPart('liver', liverMesh, liverMat);

    // D. Pancreas (Transverse glandular head & tail)
    const pancMat = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.5,
    });
    const pancGeom = new THREE.CylinderGeometry(0.04, 0.06, 0.26, 12);
    const pancMesh = new THREE.Mesh(pancGeom, pancMat);
    pancMesh.position.set(0.06, -0.04, 0.08);
    pancMesh.rotation.z = Math.PI / 2.3;
    registerPart('pancreas', pancMesh, pancMat);

    // E. Small Intestine (Central Coils)
    const siMat = new THREE.MeshStandardMaterial({
      color: 0xfb923c,
      roughness: 0.6,
    });
    const siGeom = new THREE.TorusGeometry(0.14, 0.06, 12, 24);
    siGeom.scale(1.1, 1.2, 0.8);
    const siMesh = new THREE.Mesh(siGeom, siMat);
    siMesh.position.set(0.0, -0.25, 0.18);
    registerPart('small_intestine', siMesh, siMat);

    // F. Colon (Large Intestine arch around small intestine)
    const colonMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.5,
      metalness: 0.1,
    });
    const colonCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.28, -0.42, 0.14), // Cecum
      new THREE.Vector3(-0.28, -0.12, 0.14), // Ascending
      new THREE.Vector3(0.0, -0.08, 0.16),   // Transverse
      new THREE.Vector3(0.28, -0.12, 0.14),  // Descending
      new THREE.Vector3(0.24, -0.42, 0.14),  // Sigmoid
      new THREE.Vector3(0.0, -0.55, 0.08),   // Rectum
    ]);
    const colonGeom = new THREE.TubeGeometry(colonCurve, 32, 0.048, 12, false);
    registerPart('colon', new THREE.Mesh(colonGeom, colonMat), colonMat);

    // ==========================================
    // BUILD URINARY SYSTEM
    // ==========================================
    // A. Kidneys (Left & Right bean shapes)
    const kidneyMat = new THREE.MeshStandardMaterial({
      color: 0x9333ea,
      roughness: 0.4,
      metalness: 0.1,
    });
    const leftKidneyGeom = new THREE.SphereGeometry(0.09, 16, 16);
    leftKidneyGeom.scale(0.8, 1.3, 0.7);
    const leftKidney = new THREE.Mesh(leftKidneyGeom, kidneyMat);
    leftKidney.position.set(0.24, 0.08, -0.08);
    leftKidney.rotation.z = -0.2;
    registerPart('kidneys', leftKidney, kidneyMat);

    const rightKidney = new THREE.Mesh(leftKidneyGeom.clone(), kidneyMat);
    rightKidney.position.set(-0.24, 0.04, -0.08); // Right is slightly lower
    rightKidney.rotation.z = 0.2;
    registerPart('kidneys', rightKidney, kidneyMat);

    // B. Ureters
    const ureterMat = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      roughness: 0.5,
    });
    const leftUreterCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.22, 0.04, -0.06),
      new THREE.Vector3(0.12, -0.22, -0.02),
      new THREE.Vector3(0.06, -0.48, 0.08),
    ]);
    const rightUreterCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.22, 0.0, -0.06),
      new THREE.Vector3(-0.12, -0.22, -0.02),
      new THREE.Vector3(-0.06, -0.48, 0.08),
    ]);
    const luGeom = new THREE.TubeGeometry(leftUreterCurve, 16, 0.014, 8, false);
    const ruGeom = new THREE.TubeGeometry(rightUreterCurve, 16, 0.014, 8, false);
    registerPart('ureters', new THREE.Mesh(luGeom, ureterMat), ureterMat);
    registerPart('ureters', new THREE.Mesh(ruGeom, ureterMat), ureterMat);

    // C. Bladder
    const bladderMat = new THREE.MeshStandardMaterial({
      color: 0x7c3aed,
      roughness: 0.35,
      metalness: 0.15,
    });
    const bladderGeom = new THREE.SphereGeometry(0.12, 18, 18);
    bladderGeom.scale(1.1, 0.95, 1.0);
    const bladderMesh = new THREE.Mesh(bladderGeom, bladderMat);
    bladderMesh.position.set(0, -0.52, 0.12);
    registerPart('bladder', bladderMesh, bladderMat);

    // ==========================================
    // BUILD NERVOUS SYSTEM
    // ==========================================
    // A. Brain (Cerebrum hemispheres)
    const brainMat = new THREE.MeshStandardMaterial({
      color: 0xec4899,
      roughness: 0.55,
      metalness: 0.1,
    });
    const brainGeom = new THREE.SphereGeometry(0.24, 24, 24);
    brainGeom.scale(1.0, 1.15, 1.25);
    const brainMesh = new THREE.Mesh(brainGeom, brainMat);
    brainMesh.position.set(0, 1.48, 0.05);
    registerPart('brain', brainMesh, brainMat);

    // B. Cerebellum & Brainstem
    const cbMat = new THREE.MeshStandardMaterial({
      color: 0xdb2777,
      roughness: 0.6,
    });
    const cbGeom = new THREE.SphereGeometry(0.11, 16, 16);
    cbGeom.scale(1.4, 0.9, 0.9);
    const cbMesh = new THREE.Mesh(cbGeom, cbMat);
    cbMesh.position.set(0, 1.32, -0.12);
    registerPart('cerebellum', cbMesh, cbMat);

    // C. Spinal Cord (Runs along posterior rachis)
    const cordCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 1.28, -0.06),
      new THREE.Vector3(0, 0.85, -0.12),
      new THREE.Vector3(0, 0.45, -0.15),
      new THREE.Vector3(0, 0.05, -0.12),
      new THREE.Vector3(0, -0.32, -0.08),
    ]);
    const cordGeom = new THREE.TubeGeometry(cordCurve, 24, 0.022, 10, false);
    const cordMat = new THREE.MeshStandardMaterial({
      color: 0xf43f5e,
      roughness: 0.3,
    });
    registerPart('spinal_cord', new THREE.Mesh(cordGeom, cordMat), cordMat);

    // ==========================================
    // BUILD SKELETAL SYSTEM
    // ==========================================
    const boneMat = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.3,
      metalness: 0.1,
    });

    // A. Cranium (Skull dome)
    const skullGeom = new THREE.SphereGeometry(0.26, 20, 20);
    skullGeom.scale(0.95, 1.1, 1.1);
    const skullMesh = new THREE.Mesh(skullGeom, boneMat);
    skullMesh.position.set(0, 1.5, 0.05);
    registerPart('cranium', skullMesh, boneMat);

    // B. Spine (Vertebral column segments)
    const spineMat = new THREE.MeshStandardMaterial({
      color: 0xcbd5e1,
      roughness: 0.4,
    });
    for (let i = 0; i < 18; i++) {
      const vertGeom = new THREE.CylinderGeometry(0.045, 0.045, 0.038, 12);
      const vertMesh = new THREE.Mesh(vertGeom, spineMat);
      vertMesh.position.set(0, 1.25 - i * 0.09, -0.18 + Math.sin(i * 0.3) * 0.03);
      registerPart('spine', vertMesh, spineMat);
    }

    // C. Rib Cage & Sternum
    const ribMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.5,
    });
    for (let r = 0; r < 7; r++) {
      const ribRingGeom = new THREE.TorusGeometry(0.38 - r * 0.015, 0.018, 8, 24, Math.PI * 1.8);
      ribRingGeom.scale(0.95, 0.65, 0.95);
      const ribRing = new THREE.Mesh(ribRingGeom, ribMat);
      ribRing.rotation.x = Math.PI / 2;
      ribRing.position.set(0, 0.76 - r * 0.08, 0.02);
      registerPart('ribcage', ribRing, ribMat);
    }
    // Sternum
    const sternumGeom = new THREE.BoxGeometry(0.07, 0.45, 0.025);
    const sternumMesh = new THREE.Mesh(sternumGeom, boneMat);
    sternumMesh.position.set(0, 0.54, 0.32);
    registerPart('ribcage', sternumMesh, boneMat);

    // D. Pelvis (Bone girdle)
    const pelvisMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.45,
    });
    const pelvisGeom = new THREE.TorusGeometry(0.34, 0.08, 12, 24, Math.PI);
    pelvisGeom.scale(1.15, 0.65, 0.9);
    const pelvisMesh = new THREE.Mesh(pelvisGeom, pelvisMat);
    pelvisMesh.rotation.x = Math.PI * 0.4;
    pelvisMesh.position.set(0, -0.42, 0.02);
    registerPart('pelvis', pelvisMesh, pelvisMat);

    // E. Femur Bones (Left & Right)
    const femurMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.35,
    });
    const femurGeom = new THREE.CylinderGeometry(0.04, 0.035, 0.85, 12);
    const leftFemur = new THREE.Mesh(femurGeom, femurMat);
    leftFemur.position.set(0.24, -1.02, 0.02);
    leftFemur.rotation.z = -0.05;
    const rightFemur = new THREE.Mesh(femurGeom, femurMat);
    rightFemur.position.set(-0.24, -1.02, 0.02);
    rightFemur.rotation.z = 0.05;
    registerPart('femur', leftFemur, femurMat);
    registerPart('femur', rightFemur, femurMat);

    // ==========================================
    // BUILD MUSCULAR SYSTEM
    // ==========================================
    // A. Pectorals
    const pecMat = new THREE.MeshStandardMaterial({
      color: 0xea580c,
      roughness: 0.6,
      metalness: 0.05,
    });
    const pecGeom = new THREE.BoxGeometry(0.24, 0.18, 0.05);
    const leftPec = new THREE.Mesh(pecGeom, pecMat);
    leftPec.position.set(0.18, 0.54, 0.34);
    leftPec.rotation.z = -0.15;
    const rightPec = new THREE.Mesh(pecGeom, pecMat);
    rightPec.position.set(-0.18, 0.54, 0.34);
    rightPec.rotation.z = 0.15;
    registerPart('pectorals', leftPec, pecMat);
    registerPart('pectorals', rightPec, pecMat);

    // B. Abdominals
    const abMat = new THREE.MeshStandardMaterial({
      color: 0xc2410c,
      roughness: 0.6,
    });
    const abGeom = new THREE.BoxGeometry(0.28, 0.42, 0.04);
    const abMesh = new THREE.Mesh(abGeom, abMat);
    abMesh.position.set(0, -0.15, 0.28);
    registerPart('abdominals', abMesh, abMat);

    // C. Quadriceps (Thighs)
    const quadMat = new THREE.MeshStandardMaterial({
      color: 0x9a3412,
      roughness: 0.55,
    });
    const quadGeom = new THREE.CylinderGeometry(0.11, 0.09, 0.72, 14);
    const leftQuad = new THREE.Mesh(quadGeom, quadMat);
    leftQuad.position.set(0.24, -0.98, 0.14);
    const rightQuad = new THREE.Mesh(quadGeom, quadMat);
    rightQuad.position.set(-0.24, -0.98, 0.14);
    registerPart('quadriceps', leftQuad, quadMat);
    registerPart('quadriceps', rightQuad, quadMat);

    // ==========================================
    // BUILD 3D PIN LABELS
    // ==========================================
    ANATOMICAL_STRUCTURES.forEach((struct) => {
      const sprite = createLabelSprite(struct.nameFr, struct.nameAr, struct.color);
      sprite.position.set(struct.position[0], struct.position[1] + 0.18, struct.position[2] + 0.08);
      sprite.visible = showLabels;
      scene.add(sprite);
      labelSprites.set(struct.id, sprite);
    });

    meshesMapRef.current = meshesMap;
    materialsMapRef.current = materialsMap;
    labelSpritesRef.current = labelSprites;

    // 8. Raycasting interaction
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const onPointerMove = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);

      // Collect active visible meshes
      const visibleMeshes: THREE.Mesh[] = [];
      meshesMap.forEach((meshes, structId) => {
        const struct = ANATOMICAL_STRUCTURES.find((s) => s.id === structId);
        if (struct && visibleSystems[struct.system]) {
          meshes.forEach((m) => {
            if (m.visible) visibleMeshes.push(m);
          });
        }
      });

      const intersects = raycaster.intersectObjects(visibleMeshes, false);
      if (intersects.length > 0) {
        const topHit = intersects[0].object as THREE.Mesh;
        const structId = topHit.userData.structureId;
        const found = ANATOMICAL_STRUCTURES.find((s) => s.id === structId);
        if (found) {
          setHoveredStructure(found);
          renderer.domElement.style.cursor = 'pointer';
          return;
        }
      }
      setHoveredStructure(null);
      renderer.domElement.style.cursor = 'grab';
    };

    const onPointerDown = () => {
      renderer.domElement.style.cursor = 'grabbing';
    };

    const onClick = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);

      const visibleMeshes: THREE.Mesh[] = [];
      meshesMap.forEach((meshes, structId) => {
        const struct = ANATOMICAL_STRUCTURES.find((s) => s.id === structId);
        if (struct && visibleSystems[struct.system]) {
          meshes.forEach((m) => {
            if (m.visible) visibleMeshes.push(m);
          });
        }
      });

      const intersects = raycaster.intersectObjects(visibleMeshes, false);
      if (intersects.length > 0) {
        const topHit = intersects[0].object as THREE.Mesh;
        const structId = topHit.userData.structureId;
        const found = ANATOMICAL_STRUCTURES.find((s) => s.id === structId);
        if (found) {
          onSelectStructure(found);
        }
      }
    };

    const domElement = renderer.domElement;
    domElement.addEventListener('mousemove', onPointerMove);
    domElement.addEventListener('mousedown', onPointerDown);
    domElement.addEventListener('click', onClick);

    // 9. Resize handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // 10. Animation loop
    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
      window.removeEventListener('resize', handleResize);
      domElement.removeEventListener('mousemove', onPointerMove);
      domElement.removeEventListener('mousedown', onPointerDown);
      domElement.removeEventListener('click', onClick);

      // Dispose resources
      renderer.dispose();
      controls.dispose();
      scene.clear();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Sync System Visibilities and Opacities
  useEffect(() => {
    meshesMapRef.current.forEach((meshes, structId) => {
      const struct = ANATOMICAL_STRUCTURES.find((s) => s.id === structId);
      if (!struct) return;

      const isSysVisible = visibleSystems[struct.system];
      const opacity = systemOpacities[struct.system] ?? 1.0;

      meshes.forEach((mesh) => {
        mesh.visible = isSysVisible;
      });

      const mats = materialsMapRef.current.get(structId);
      if (mats) {
        mats.forEach((mat) => {
          mat.transparent = opacity < 0.99;
          mat.opacity = opacity;
        });
      }
    });

    // Update label sprites visibility
    labelSpritesRef.current.forEach((sprite, structId) => {
      const struct = ANATOMICAL_STRUCTURES.find((s) => s.id === structId);
      if (!struct) return;
      const isSysVisible = visibleSystems[struct.system];
      sprite.visible = showLabels && isSysVisible;
    });

    // Update silhouette visibility
    if (silhouetteMeshRef.current) {
      silhouetteMeshRef.current.visible = showBodySilhouette;
    }
  }, [visibleSystems, systemOpacities, showLabels, showBodySilhouette]);

  // Sync Selection Highlight & Emissive Pulse
  useEffect(() => {
    const activeId = highlightedStructureId || selectedStructure?.id || quizTargetId;

    meshesMapRef.current.forEach((meshes, structId) => {
      const isSelected = structId === activeId;
      const mats = materialsMapRef.current.get(structId);

      if (mats) {
        mats.forEach((mat) => {
          if (isSelected) {
            mat.emissive.setHex(0x38bdf8); // Bright sky blue glow
            mat.emissiveIntensity = 0.6;
          } else {
            mat.emissive.setHex(0x000000);
            mat.emissiveIntensity = 0.0;
          }
        });
      }
    });

    // Animate camera focus towards selected structure if active
    if (selectedStructure && cameraRef.current && controlsRef.current) {
      const targetPos = selectedStructure.targetLookAt || selectedStructure.position;
      controlsRef.current.target.set(targetPos[0], targetPos[1], targetPos[2]);
    }
  }, [selectedStructure, highlightedStructureId, quizTargetId]);

  // Camera Presets
  const setCameraPreset = (preset: 'anterior' | 'posterior' | 'thorax' | 'abdomen' | 'head') => {
    if (!cameraRef.current || !controlsRef.current) return;
    setActivePreset(preset);

    switch (preset) {
      case 'anterior':
        cameraRef.current.position.set(0, 0.3, 3.4);
        controlsRef.current.target.set(0, 0.2, 0);
        break;
      case 'posterior':
        cameraRef.current.position.set(0, 0.3, -3.4);
        controlsRef.current.target.set(0, 0.2, 0);
        break;
      case 'thorax':
        cameraRef.current.position.set(0, 0.55, 1.8);
        controlsRef.current.target.set(0, 0.5, 0.1);
        break;
      case 'abdomen':
        cameraRef.current.position.set(0, -0.15, 1.8);
        controlsRef.current.target.set(0, -0.15, 0.1);
        break;
      case 'head':
        cameraRef.current.position.set(0, 1.48, 1.4);
        controlsRef.current.target.set(0, 1.45, 0.05);
        break;
    }
    controlsRef.current.update();
  };

  const resetCamera = () => {
    setCameraPreset('anterior');
  };

  return (
    <div className="relative w-full h-[520px] md:h-[620px] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl select-none">
      
      {/* 3D Canvas Mount Point */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Floating Overlay Controls */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
        
        {/* Left: Camera Angles HUD */}
        <div className="flex items-center gap-1.5 p-1.5 bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700/60 shadow-lg pointer-events-auto">
          <span className="text-[11px] font-semibold text-slate-400 px-2 flex items-center gap-1">
            <Compass className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden sm:inline">الزاوية:</span>
          </span>
          <button
            onClick={() => setCameraPreset('anterior')}
            className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
              activePreset === 'anterior'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            أمامي (Ant.)
          </button>
          <button
            onClick={() => setCameraPreset('posterior')}
            className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
              activePreset === 'posterior'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            خلفي (Post.)
          </button>
          <button
            onClick={() => setCameraPreset('head')}
            className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all hidden md:inline-block ${
              activePreset === 'head'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            الرأس
          </button>
          <button
            onClick={() => setCameraPreset('thorax')}
            className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
              activePreset === 'thorax'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            الصدر
          </button>
          <button
            onClick={() => setCameraPreset('abdomen')}
            className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
              activePreset === 'abdomen'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            البطن
          </button>
          <button
            onClick={resetCamera}
            title="إعادة ضبط المشهد"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors ml-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right: Quick Instructions / Touch indicator */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-900/80 backdrop-blur-md rounded-xl border border-slate-800 text-slate-300 text-xs">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>انقر على أي عضو لاكتشاف اسمه ومصطلحاته السريرية</span>
        </div>
      </div>

      {/* Floating Hover Badge */}
      {hoveredStructure && !selectedStructure && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 px-4 py-2 bg-slate-900/95 backdrop-blur-md border border-teal-500/50 rounded-xl shadow-xl flex items-center gap-3 animate-fade-in pointer-events-none">
          <div
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: hoveredStructure.color }}
          />
          <div className="text-right">
            <div className="text-xs font-bold text-white flex items-center gap-2">
              <span>{hoveredStructure.nameFr}</span>
              <span className="text-teal-400 font-semibold">{hoveredStructure.nameAr}</span>
            </div>
            <div className="text-[10px] text-slate-400 font-latin">
              {hoveredStructure.nameEn} · {hoveredStructure.systemNameFr}
            </div>
          </div>
        </div>
      )}

      {/* Bottom Floating Legend / Mobile touch hint */}
      <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[11px] text-slate-400 pointer-events-none">
        <span className="bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-lg border border-slate-800 hidden sm:inline-block">
          🖱️ تدوير: سحب بالماوس / تكبير: عجلة الفأرة / إزاحة: زر أيمن
        </span>
        <span className="bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-lg border border-slate-800 sm:hidden">
          👆 دوّر واسحب بإصبعك للاستكشاف
        </span>

        <span className="bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-lg border border-slate-800 text-teal-400 font-medium">
          Three.js WebGL Real-time Engine
        </span>
      </div>

    </div>
  );
};
