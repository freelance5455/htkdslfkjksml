# CGD V117 — Socle 1.4 : administration des calendriers officiels

## Nouveautés
- Ajout d'un panneau d'administration accessible depuis l'écran du calendrier central.
- Saisie des sept jeudis lunaires officiels de la Coupe des Clubs : jour absolu de saison, mois lunaire et jour lunaire.
- Saisie de la date officielle de fin de saison régulière publiée par la FGD.
- Saisie des dates officielles AGD de la Coupe Intergalactique des galaxies et de l'Intergalactique des Clubs.
- Les données ne sont pas préremplies par des dates fictives.
- Validation de l'ensemble sur une copie de la sauvegarde avant application : une erreur ne modifie pas la carrière active.
- Les validations existantes contrôlent les jeudis, la cadence de sept jours, la fin de saison, les intervalles de repos et les chevauchements.
- Le calendrier reste verrouillé tant que les moteurs de toutes les compétitions ne sont pas intégrés.

## Modèle de date
Le formulaire demande un jour absolu de saison (jour 1 = lundi), en plus du mois et du jour lunaires pour les jeudis de Coupe des Clubs. Il s'agit d'une coordonnée de calendrier interne, pas d'une conversion automatique en date civile. Les valeurs doivent être transcrites depuis les publications officielles FGD/AGD et le calendrier lunaire retenu par l'organisation.

## Contrôles
- 93 tests automatisés réussis.
- Tests dédiés au traitement atomique du formulaire, au refus d'une date AGD trop proche et au rejet d'un calendrier lunaire incomplet.
- Syntaxe vérifiée pour les modules JavaScript.
- Le test navigateur/tactile réel reste à effectuer.

## Limites connues
- Aucun calendrier officiel réel n'est fourni avec cette version : le panneau attend la saisie des valeurs authentiques.
- L'écran d'administration ne remplace pas les moteurs manquants : Champions League, Coupe Intergalactique des galaxies, Intergalactique des Clubs, Coupe Lunaire et Dame d'Or.
- La saison reste protégée contre le démarrage tant que ces moteurs et les calendriers officiels ne sont pas prêts.
