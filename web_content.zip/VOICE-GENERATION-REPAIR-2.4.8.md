# ANONYMOUX STUDIO 2.4.8 — Voice generation repair

## Implemented
- Fish Audio model catalogue now accepts the provider's documented `svc` model type (and legacy `tts`) instead of dropping the public voice models. Pagination respects the provider's `has_more` field.
- Agent creation preserves explicit `expressive: false` instead of dropping the value.
- Voice Studio selection is stored in the existing account-scoped `workspace_preferences` table and loaded from the server, with browser storage retained as a local fallback.
- Fish Audio browser SDK is pinned to `@fishaudio/agent-client@0.3.0`.
- Agent session end now fetches Fish Audio session details and reconciles provider-reported LLM token usage by `message_generation_id`. The unique provider usage ID and deterministic wallet reference make repeat reconciliation idempotent.
- Added `api/agent/reconcile-session.php` for retrying usage retrieval after provider post-call usage becomes complete.

## Agent billing safety
Fish Audio session details expose LLM token cost fields in USD. The application records these amounts. Wallet conversion is disabled by default and only charges when `ANONYMOUX_AGENT_CREDITS_PER_USD` is explicitly configured to a positive value. Do not enable this until the operator has selected and tested a business conversion rate. Incomplete usage is not charged. If the user has insufficient credits, the usage row is marked `unpaid` rather than silently dropping the liability.

Fish Audio session detail schema does not establish a complete ASR/TTS usage cost in the fields currently consumed here. This build does not invent those charges or claim to reconcile provider costs that are not returned.

## Configuration
- Existing `FISH_AUDIO_API_KEY` / Admin → Voice AI key management remains unchanged.
- Existing `ANONYMOUX_KEY_ENCRYPTION_SECRET` remains required for encrypted stored API keys.
- Optional `ANONYMOUX_AGENT_CREDITS_PER_USD=0` (default) records measured LLM USD usage without charging ANON credits. Set a positive value only after deciding the platform's credit conversion policy.
- No database schema migration is required; it reuses existing `workspace_preferences`, `agent_usage`, `agent_sessions`, and `credit_transactions` tables.

## Verification limits
Static PHP/JS syntax and regression checks are run in the build environment. Live Fish Audio API requests, provider usage settlement, real browser WebRTC audio, and production database behavior require the site's real credentials, PHP cURL, and deployed database.
