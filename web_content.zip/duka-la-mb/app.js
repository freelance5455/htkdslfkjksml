(function () {
  "use strict";

  var KEY = "dukaLaMB_v1";
  var ROLE_KEY = "dukaLaMB_role";
  var MINE_KEY = "dukaLaMB_mine";
  var PIN_KEY = "dukaLaMB_pin";

  // Vifurushi vinavyoonyeshwa (kwa MB). Bei huhesabiwa kutoka kwenye kiwango cha mipangilio.
  var PACKAGES = [500, 1000, 2000, 5000, 10000, 20000];
  // Vifurushi vinavyotumika kutengeneza matangazo ya juu.
  var AD_PACKAGES = [1000, 5000, 10000];

  var DEFAULTS = {
    shop: "Duka la MB",
    phone: "0616804799",
    mbPer1000: 1000,
    theme: "usiku",
    bgCustom: "",
    ads: []
  };

  // Mandhari (rangi za mandharinyuma). Ongeza mpya hapa ili ionekane kwenye mipangilio.
  var THEMES = {
    usiku:    { name: "Usiku",    bg1: "#0a2a33", bg2: "#04141b", accent: "#ffc83d", mode: "dark" },
    bahari:   { name: "Bahari",   bg1: "#0b2f6b", bg2: "#051a3d", accent: "#5ee1ff", mode: "dark" },
    zambarau: { name: "Zambarau", bg1: "#2b1458", bg2: "#12082b", accent: "#ffb86b", mode: "dark" },
    machweo:  { name: "Machweo",  bg1: "#4a1522", bg2: "#1d0a10", accent: "#ffb347", mode: "dark" },
    msitu:    { name: "Msitu",    bg1: "#12351f", bg2: "#08190f", accent: "#d6f26b", mode: "dark" },
    mwanga:   { name: "Mwanga",   bg1: "#f4f7f5", bg2: "#dce8e2", accent: "#0b7a68", mode: "light" }
  };

  var unlocked = false;
  var failCount = 0;
  var lockUntil = 0;

  // ---------- Hifadhi ----------
  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) {
        var d = JSON.parse(raw);
        d.settings = Object.assign({}, DEFAULTS, d.settings || {});
        if (!Array.isArray(d.settings.ads)) d.settings.ads = [];
        d.orders = d.orders || [];
        return d;
      }
    } catch (e) {}
    return { settings: Object.assign({}, DEFAULTS), orders: [] };
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
  }
  function loadMine() {
    try { return JSON.parse(localStorage.getItem(MINE_KEY)) || []; } catch (e) { return []; }
  }
  function saveMine(list) {
    try { localStorage.setItem(MINE_KEY, JSON.stringify(list)); } catch (e) {}
  }

  var state = load();
  var mine = loadMine();

  // ---------- Vifaa ----------
  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function fmt(n) { return Number(n).toLocaleString("en-US"); }
  function calcMB(tsh) { return Math.floor((tsh / 1000) * state.settings.mbPer1000); }
  function priceFor(mb) { return Math.ceil((mb * 1000) / state.settings.mbPer1000); }
  function sizeParts(mb) {
    return mb >= 1000 ? { n: String(+(mb / 1000).toFixed(2)), u: "GB" } : { n: String(mb), u: "MB" };
  }
  function sizeText(mb) { var p = sizeParts(mb); return p.u + " " + p.n; }
  function fmtDate(ts) {
    var d = new Date(ts);
    return d.toLocaleDateString("sw-TZ", { day: "2-digit", month: "short" }) + " " +
      d.toLocaleTimeString("sw-TZ", { hour: "2-digit", minute: "2-digit" });
  }
  function statusLabel(s) {
    return s === "done" ? "Imekamilika" : s === "rejected" ? "Imekataliwa" : "Inasubiri";
  }
  function normPhone(p) { return String(p).replace(/[^\d]/g, ""); }
  function validPhone(p) { return /^0\d{9}$/.test(p) || /^255\d{9}$/.test(p); }
  function msg(el, text, ok) {
    el.textContent = text;
    el.className = "msg " + (ok ? "ok" : "err");
  }
  function copyText(text, btn, original) {
    function done() {
      btn.textContent = "Imenakiliwa";
      setTimeout(function () { btn.textContent = original; }, 1600);
    }
    function fallback() {
      try {
        var ta = document.createElement("textarea");
        ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
      } catch (e) {}
      done();
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, fallback);
    } else { fallback(); }
  }

  // ---------- Mandhari ----------
  function hexToRgb(h) {
    h = h.replace("#", "");
    if (h.length === 3) h = h.split("").map(function (c) { return c + c; }).join("");
    var n = parseInt(h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function toHex(rgb) {
    return "#" + rgb.map(function (c) { return ("0" + c.toString(16)).slice(-2); }).join("");
  }
  function luminance(rgb) { return (0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]) / 255; }

  function applyTheme() {
    var s = state.settings;
    var t = THEMES[s.theme] || THEMES.usiku;
    var bg1 = t.bg1, bg2 = t.bg2, accent = t.accent, mode = t.mode;

    if (/^#[0-9a-f]{6}$/i.test(s.bgCustom || "")) {
      var rgb = hexToRgb(s.bgCustom);
      mode = luminance(rgb) > 0.6 ? "light" : "dark";
      bg1 = s.bgCustom;
      var k = mode === "light" ? 0.9 : 0.45;
      bg2 = toHex(rgb.map(function (c) { return Math.round(c * k); }));
      accent = mode === "light" ? "#0b7a68" : (t.mode === "light" ? THEMES.usiku.accent : t.accent);
    }

    var root = document.documentElement;
    root.style.setProperty("--bg1", bg1);
    root.style.setProperty("--bg2", bg2);
    root.style.setProperty("--accent", accent);
    root.style.setProperty("--accent-rgb", hexToRgb(accent).join(","));
    root.setAttribute("data-mode", mode);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", bg2);
  }

  function renderSwatches() {
    var active = state.settings.bgCustom ? "" : state.settings.theme;
    $("swatches").innerHTML = Object.keys(THEMES).map(function (k) {
      var t = THEMES[k];
      return '<button type="button" class="swatch" data-theme="' + k + '" aria-pressed="' + (k === active) + '" ' +
        'style="--s1:' + t.bg1 + ';--s2:' + t.bg2 + ';--s3:' + t.accent + '">' +
        '<i></i><span>' + t.name + '</span></button>';
    }).join("");
    var cc = state.settings.bgCustom || (THEMES[state.settings.theme] || THEMES.usiku).bg1;
    $("bgCustom").value = cc;
  }

  // ---------- Akaunti (Mteja / Mmiliki) ----------
  function setRole(role) {
    var isCustomer = role !== "owner";
    var dlg = $("payDialog");
    if (dlg.open && dlg.close) dlg.close();
    $("viewCustomer").classList.toggle("hidden", !isCustomer);
    $("viewOwner").classList.toggle("hidden", isCustomer);
    $("tabCustomer").classList.toggle("active", isCustomer);
    $("tabOwner").classList.toggle("active", !isCustomer);
    try { localStorage.setItem(ROLE_KEY, isCustomer ? "customer" : "owner"); } catch (e) {}
    if (isCustomer) { unlocked = false; renderCustomer(); startAds(); }
    else { stopAds(); renderOwner(); }
    window.scrollTo(0, 0);
  }

  document.querySelectorAll(".seg-btn").forEach(function (b) {
    b.addEventListener("click", function () { setRole(b.getAttribute("data-role")); });
  });

  function renderHeader() {
    $("shopName").textContent = state.settings.shop;
    document.title = state.settings.shop;
  }

  // ---------- Matangazo ya juu ----------
  var adIdx = 0, adTimer = null, adScrollT = null;
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function buildSlides() {
    var rate = state.settings.mbPer1000;
    var slides = [];
    AD_PACKAGES.forEach(function (mb, i) {
      var price = "TSh " + fmt(priceFor(mb));
      var title, sub;
      // Nafasi zisizokatika ili "TSh 1,000" na "GB 1" visigawanyike mistari miwili
      var nb = function (s) { return s.replace(/ /g, " "); };
      if (i === 0) {
        title = nb(sizeText(mb)) + " kwa " + nb(price);
        sub = "Bei nafuu zaidi. Kila GB ni TSh " + fmt(priceFor(1000)) + ", hata ukinunua kubwa.";
      } else if (i === 1) {
        title = nb(sizeText(mb)) + " kwa " + nb(price);
        sub = "Bei ileile kwa kila GB. Ukinunua zaidi, bei kwa GB haipandi.";
      } else {
        title = nb(sizeText(mb)) + " kwa " + nb(price);
        sub = "Kwa video, mitandao na kazi bila kuhesabu MB.";
      }
      slides.push({ mb: mb, title: title, sub: sub, price: price });
    });
    (state.settings.ads || []).forEach(function (t) {
      if (t) slides.push({ text: t });
    });
    return slides;
  }

  function renderAds() {
    var slides = buildSlides();
    $("adsTrack").innerHTML = slides.map(function (s, i) {
      var c = "c" + ((i % 4) + 1);
      if (s.mb) {
        var p = sizeParts(s.mb);
        return '<article class="ad ' + c + '" aria-label="Tangazo ' + (i + 1) + ' la ' + slides.length + '">' +
          '<div class="ad-copy"><h3 class="ad-title">' + esc(s.title) + '</h3>' +
          '<p class="ad-sub">' + esc(s.sub) + '</p>' +
          '<button type="button" class="ad-cta" data-mb="' + s.mb + '">Nunua ' + esc(sizeText(s.mb)) + '</button></div>' +
          '<div class="ad-fig" aria-hidden="true"><span class="ad-num">' + esc(p.n) + '</span>' +
          '<span class="ad-unit">' + p.u + '</span><span class="ad-price">' + esc(s.price) + '</span></div>' +
          '</article>';
      }
      return '<article class="ad ' + c + '" aria-label="Tangazo ' + (i + 1) + ' la ' + slides.length + '">' +
        '<div class="ad-copy"><h3 class="ad-title">' + esc(s.text) + '</h3>' +
        '<button type="button" class="ad-cta" data-go="1">Angalia vifurushi</button></div>' +
        '<div class="ad-fig" aria-hidden="true"><span class="ad-mark">MB</span></div>' +
        '</article>';
    }).join("");

    $("adsDots").innerHTML = slides.map(function (s, i) {
      return '<button type="button" class="dot" data-i="' + i + '" aria-label="Tangazo ' + (i + 1) + '"></button>';
    }).join("");
    $("adsDots").classList.toggle("hidden", slides.length < 2);
    adIdx = 0;
    $("adsTrack").scrollLeft = 0;
    updateDots();
  }

  function adCount() { return $("adsTrack").children.length; }

  function updateDots() {
    var dots = $("adsDots").children;
    for (var i = 0; i < dots.length; i++) {
      dots[i].setAttribute("aria-current", i === adIdx ? "true" : "false");
    }
  }

  function goAd(i, smooth) {
    var t = $("adsTrack"), n = adCount();
    if (!n) return;
    adIdx = ((i % n) + n) % n;
    t.scrollTo({ left: adIdx * t.clientWidth, behavior: smooth && !reduceMotion ? "smooth" : "auto" });
    updateDots();
  }

  function startAds() {
    stopAds();
    if (reduceMotion || adCount() < 2) return;
    adTimer = setInterval(function () {
      if (document.hidden || $("viewCustomer").classList.contains("hidden") || $("payDialog").open) return;
      goAd(adIdx + 1, true);
    }, 5000);
  }
  function stopAds() { if (adTimer) { clearInterval(adTimer); adTimer = null; } }

  var adsTrack = $("adsTrack");
  adsTrack.addEventListener("scroll", function () {
    clearTimeout(adScrollT);
    adScrollT = setTimeout(function () {
      var w = adsTrack.clientWidth || 1;
      var i = Math.round(adsTrack.scrollLeft / w);
      if (i !== adIdx) { adIdx = i; updateDots(); }
    }, 60);
  }, { passive: true });
  ["pointerenter", "focusin", "touchstart"].forEach(function (ev) {
    adsTrack.addEventListener(ev, stopAds, { passive: true });
  });
  ["pointerleave", "focusout", "touchend"].forEach(function (ev) {
    adsTrack.addEventListener(ev, function () {
      if (!$("viewCustomer").classList.contains("hidden")) startAds();
    }, { passive: true });
  });
  adsTrack.addEventListener("keydown", function (e) {
    if (e.key === "ArrowRight") { goAd(adIdx + 1, true); e.preventDefault(); }
    if (e.key === "ArrowLeft") { goAd(adIdx - 1, true); e.preventDefault(); }
  });
  $("adsDots").addEventListener("click", function (e) {
    var i = e.target.getAttribute && e.target.getAttribute("data-i");
    if (i !== null && i !== undefined) goAd(parseInt(i, 10), true);
  });
  adsTrack.addEventListener("click", function (e) {
    var el = e.target.closest ? e.target.closest(".ad-cta") : null;
    if (!el) return;
    if (el.getAttribute("data-mb")) openPay(parseInt(el.getAttribute("data-mb"), 10));
    else $("pkgSection").scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "start" });
  });

  // ---------- Mteja: vifurushi ----------
  function renderPackages() {
    $("rateText").textContent = "TSh 1,000 = " + fmt(state.settings.mbPer1000) + " MB";
    $("pkgGrid").innerHTML = PACKAGES.map(function (mb) {
      var p = sizeParts(mb), price = priceFor(mb);
      return '<button type="button" class="pkg" data-mb="' + mb + '" aria-label="Nunua ' + esc(sizeText(mb)) + ' kwa TSh ' + fmt(price) + '">' +
        '<span class="pkg-size"><b>' + esc(p.n) + '</b><span>' + p.u + '</span></span>' +
        '<span class="pkg-price">TSh ' + fmt(price) + '</span>' +
        '<span class="pkg-go">Lipa</span></button>';
    }).join("");
  }

  $("pkgGrid").addEventListener("click", function (e) {
    var el = e.target.closest ? e.target.closest(".pkg") : null;
    if (el) openPay(parseInt(el.getAttribute("data-mb"), 10));
  });

  function updateCustom() {
    var amt = parseInt($("customAmt").value, 10) || 0;
    var mb = calcMB(amt);
    $("customOut").textContent = mb >= 1000 ? sizeText(mb).replace("GB ", "") + " GB" : fmt(mb) + " MB";
  }
  $("customAmt").addEventListener("input", updateCustom);
  $("customGo").addEventListener("click", function () {
    var amt = parseInt($("customAmt").value, 10);
    if (!amt || amt < 100) return msg($("customMsg"), "Kiasi cha chini ni TSh 100.", false);
    $("customMsg").textContent = "";
    openPay(null, amt);
  });

  function renderMyOrders() {
    var box = $("myOrders");
    var list = state.orders.filter(function (o) { return mine.indexOf(o.id) !== -1; })
      .sort(function (a, b) { return b.time - a.time; });
    if (!list.length) {
      box.innerHTML = '<p class="empty">Bado hujaweka oda. Chagua kifurushi hapo juu ili uanze.</p>';
      return;
    }
    box.innerHTML = list.map(function (o) {
      return '<div class="order">' +
        '<div class="order-head"><b>' + fmt(o.mb) + ' MB</b>' +
        '<span class="badge ' + o.status + '">' + statusLabel(o.status) + '</span></div>' +
        '<p class="order-meta">TSh ' + fmt(o.amount) + ' • ' + esc(o.phone) +
        '<br>Muamala: ' + esc(o.tx) + ' • ' + fmtDate(o.time) + '</p>' +
        '</div>';
    }).join("");
  }

  function renderCustomer() {
    renderHeader();
    renderAds();
    renderPackages();
    updateCustom();
    renderMyOrders();
  }

  // ---------- Dirisha la malipo ----------
  var sel = { mb: 0, amount: 0 };
  var dlg = $("payDialog");

  function openPay(mb, amount) {
    if (mb) { sel.mb = mb; sel.amount = priceFor(mb); }
    else { sel.amount = amount; sel.mb = calcMB(amount); }

    $("paySize").textContent = sel.mb >= 1000 ? sizeText(sel.mb) : fmt(sel.mb) + " MB";
    $("payPrice").textContent = "TSh " + fmt(sel.amount);
    $("payAmountInline").textContent = "TSh " + fmt(sel.amount);
    $("payPhone").textContent = state.settings.phone;
    $("orderForm").reset();
    $("formMsg").textContent = "";
    $("payPane").classList.remove("hidden");
    $("paySuccess").classList.add("hidden");
    $("payTitle").textContent = "Lipa kwa HaloPesa";

    if (typeof dlg.showModal === "function") { if (!dlg.open) dlg.showModal(); }
    else dlg.setAttribute("open", "");
    dlg.scrollTop = 0;
  }

  function closePay() {
    if (typeof dlg.close === "function") dlg.close();
    else dlg.removeAttribute("open");
    renderMyOrders();
  }

  $("payClose").addEventListener("click", closePay);
  $("successClose").addEventListener("click", closePay);
  dlg.addEventListener("click", function (e) { if (e.target === dlg) closePay(); });
  dlg.addEventListener("close", function () { if (!$("viewCustomer").classList.contains("hidden")) startAds(); });

  $("copyPhone").addEventListener("click", function () {
    copyText(state.settings.phone, $("copyPhone"), "Nakili namba");
  });
  $("copyAmount").addEventListener("click", function () {
    copyText(String(sel.amount), $("copyAmount"), "Nakili kiasi");
  });

  $("orderForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var m = $("formMsg");
    var phone = normPhone($("custPhone").value);
    var tx = $("txId").value.trim();

    if (!sel.amount || sel.amount < 100) return msg(m, "Kiasi cha chini ni TSh 100.", false);
    if (!validPhone(phone)) return msg(m, "Weka namba sahihi ya simu (mfano 0712345678).", false);
    if (tx.length < 4) return msg(m, "Weka namba ya muamala kutoka kwenye ujumbe wa HaloPesa.", false);

    var dup = state.orders.some(function (o) { return o.tx.toLowerCase() === tx.toLowerCase(); });
    if (dup) return msg(m, "Namba hii ya muamala imeshatumika.", false);

    var order = {
      id: "o" + Date.now() + Math.floor(Math.random() * 1000),
      name: $("custName").value.trim(),
      phone: phone,
      amount: sel.amount,
      mb: sel.mb,
      tx: tx,
      status: "pending",
      time: Date.now()
    };
    state.orders.push(order);
    mine.push(order.id);
    save(); saveMine(mine);

    $("payPane").classList.add("hidden");
    $("paySuccess").classList.remove("hidden");
    $("payTitle").textContent = "Asante";
    $("successText").textContent = "Tumepokea oda ya " + (order.mb >= 1000 ? sizeText(order.mb) : fmt(order.mb) + " MB") +
      " kwa namba " + phone + ". Mmiliki akithibitisha malipo, bando litatumwa.";
    renderMyOrders();
  });

  // ---------- PIN ya Mmiliki ----------
  function getPin() {
    try { return JSON.parse(localStorage.getItem(PIN_KEY)); } catch (e) { return null; }
  }
  function fallbackHash(data) {
    var h = 5381;
    for (var i = 0; i < data.length; i++) h = ((h << 5) + h + data.charCodeAt(i)) | 0;
    return "x" + (h >>> 0).toString(16);
  }
  function hashPin(pin, salt, forceFallback) {
    var data = salt + ":" + pin;
    if (!forceFallback && window.crypto && window.crypto.subtle && window.TextEncoder) {
      return window.crypto.subtle.digest("SHA-256", new TextEncoder().encode(data)).then(function (buf) {
        return Array.prototype.map.call(new Uint8Array(buf), function (b) {
          return ("0" + b.toString(16)).slice(-2);
        }).join("");
      });
    }
    return Promise.resolve(fallbackHash(data));
  }
  function storePin(pin) {
    var salt = String(Date.now()) + Math.random().toString(36).slice(2);
    return hashPin(pin, salt).then(function (hash) {
      try { localStorage.setItem(PIN_KEY, JSON.stringify({ salt: salt, hash: hash })); } catch (e) {}
    });
  }
  function checkPin(pin) {
    var stored = getPin();
    if (!stored) return Promise.resolve(false);
    return hashPin(pin, stored.salt, stored.hash.charAt(0) === "x").then(function (h) {
      return h === stored.hash;
    });
  }
  function isPin(s) { return /^\d{4}$/.test(s); }

  function setupLock() {
    var hasPin = !!getPin();
    $("lockTitle").textContent = hasPin ? "Ingiza PIN ya Mmiliki" : "Weka PIN ya Mmiliki";
    $("lockHint").textContent = hasPin
      ? "Ingiza PIN yako ili kuona oda na mipangilio."
      : "Hii ni mara ya kwanza. Chagua PIN ya tarakimu 4 itakayolinda upande wa Mmiliki.";
    $("pinLabel").textContent = hasPin ? "PIN" : "PIN mpya (tarakimu 4)";
    $("pinConfirmWrap").classList.toggle("hidden", hasPin);
    $("pinConfirm").required = !hasPin;
    $("lockBtn").textContent = hasPin ? "Fungua" : "Hifadhi PIN";
    $("pinInput").value = "";
    $("pinConfirm").value = "";
    $("lockMsg").textContent = "";
  }

  $("lockForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var m = $("lockMsg");
    var pin = $("pinInput").value.trim();
    if (!isPin(pin)) return msg(m, "PIN lazima iwe tarakimu 4.", false);

    if (!getPin()) {
      if (pin !== $("pinConfirm").value.trim()) return msg(m, "PIN hazilingani. Jaribu tena.", false);
      storePin(pin).then(function () { unlocked = true; renderOwner(); });
      return;
    }

    var wait = Math.ceil((lockUntil - Date.now()) / 1000);
    if (wait > 0) return msg(m, "Subiri sekunde " + wait + " kisha ujaribu tena.", false);

    checkPin(pin).then(function (ok) {
      if (ok) { failCount = 0; unlocked = true; renderOwner(); return; }
      failCount++;
      $("pinInput").value = "";
      if (failCount >= 5) {
        failCount = 0;
        lockUntil = Date.now() + 30000;
        msg(m, "Umekosea mara 5. Subiri sekunde 30.", false);
      } else {
        msg(m, "PIN si sahihi.", false);
      }
    });
  });

  $("lockNow").addEventListener("click", function () {
    unlocked = false;
    renderOwner();
    window.scrollTo(0, 0);
  });

  $("pinForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var m = $("pinMsg");
    var oldPin = $("oldPin").value.trim();
    var p1 = $("newPin").value.trim();
    var p2 = $("newPin2").value.trim();
    if (!isPin(p1)) return msg(m, "PIN mpya lazima iwe tarakimu 4.", false);
    if (p1 !== p2) return msg(m, "PIN mpya hazilingani.", false);
    checkPin(oldPin).then(function (ok) {
      if (!ok) return msg(m, "PIN ya sasa si sahihi.", false);
      storePin(p1).then(function () {
        $("pinForm").reset();
        msg(m, "PIN imebadilishwa.", true);
      });
    });
  });

  // ---------- Mmiliki ----------
  var filter = "pending";

  function renderOwner() {
    renderHeader();

    $("ownerLock").classList.toggle("hidden", unlocked);
    $("ownerPanel").classList.toggle("hidden", !unlocked);
    if (!unlocked) { setupLock(); return; }

    var pending = 0, done = 0, money = 0, mb = 0;
    state.orders.forEach(function (o) {
      if (o.status === "pending") pending++;
      if (o.status === "done") { done++; money += o.amount; mb += o.mb; }
    });
    $("stPending").textContent = fmt(pending);
    $("stDone").textContent = fmt(done);
    $("stMoney").textContent = fmt(money);
    $("stMB").textContent = fmt(mb);

    $("setShop").value = state.settings.shop;
    $("setPhone").value = state.settings.phone;
    $("setRate").value = state.settings.mbPer1000;
    $("adsText").value = (state.settings.ads || []).join("\n");
    renderSwatches();

    var list = state.orders.filter(function (o) { return filter === "all" || o.status === filter; })
      .sort(function (a, b) { return b.time - a.time; });
    var box = $("ownerOrders");
    if (!list.length) {
      box.innerHTML = '<p class="empty">Hakuna oda hapa.</p>';
      return;
    }
    box.innerHTML = list.map(function (o) {
      var actions = o.status === "pending"
        ? '<div class="order-actions">' +
          '<button class="btn-ok" data-act="done" data-id="' + o.id + '">Thibitisha</button>' +
          '<button class="btn-no" data-act="rejected" data-id="' + o.id + '">Kataa</button></div>'
        : '';
      return '<div class="order">' +
        '<div class="order-head"><b>' + fmt(o.mb) + ' MB • TSh ' + fmt(o.amount) + '</b>' +
        '<span class="badge ' + o.status + '">' + statusLabel(o.status) + '</span></div>' +
        '<p class="order-meta">' + (o.name ? esc(o.name) + ' • ' : '') + 'Tuma MB kwa: <b>' + esc(o.phone) + '</b>' +
        '<br>Muamala: ' + esc(o.tx) + ' • ' + fmtDate(o.time) + '</p>' +
        actions + '</div>';
    }).join("");
  }

  $("filter").addEventListener("change", function () {
    filter = this.value;
    renderOwner();
  });

  $("ownerOrders").addEventListener("click", function (e) {
    var act = e.target.getAttribute && e.target.getAttribute("data-act");
    var id = e.target.getAttribute && e.target.getAttribute("data-id");
    if (!act || !id) return;
    if (act === "rejected" && !confirm("Una uhakika unataka kukataa oda hii?")) return;
    state.orders.forEach(function (o) { if (o.id === id) o.status = act; });
    save();
    renderOwner();
  });

  // Mandhari
  $("swatches").addEventListener("click", function (e) {
    var el = e.target.closest ? e.target.closest(".swatch") : null;
    if (!el) return;
    state.settings.theme = el.getAttribute("data-theme");
    state.settings.bgCustom = "";
    save(); applyTheme(); renderSwatches();
  });
  $("bgCustom").addEventListener("input", function () {
    state.settings.bgCustom = this.value;
    save(); applyTheme();
    document.querySelectorAll(".swatch").forEach(function (s) { s.setAttribute("aria-pressed", "false"); });
  });
  $("bgReset").addEventListener("click", function () {
    state.settings.bgCustom = "";
    state.settings.theme = DEFAULTS.theme;
    save(); applyTheme(); renderSwatches();
  });

  // Matangazo
  $("adsForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var lines = $("adsText").value.split("\n").map(function (l) { return l.trim().slice(0, 90); })
      .filter(Boolean).slice(0, 8);
    state.settings.ads = lines;
    save();
    $("adsText").value = lines.join("\n");
    msg($("adsMsg"), lines.length ? "Matangazo " + lines.length + " yamehifadhiwa." : "Matangazo yako yameondolewa.", true);
  });

  // Mipangilio ya duka
  $("settingsForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var m = $("settingsMsg");
    var phone = normPhone($("setPhone").value);
    var rate = parseInt($("setRate").value, 10);
    if (!validPhone(phone)) return msg(m, "Namba ya simu si sahihi.", false);
    if (!rate || rate < 1) return msg(m, "Weka idadi sahihi ya MB.", false);
    state.settings.shop = $("setShop").value.trim() || DEFAULTS.shop;
    state.settings.phone = phone;
    state.settings.mbPer1000 = rate;
    save();
    renderHeader();
    msg(m, "Mipangilio imehifadhiwa.", true);
  });

  $("exportCsv").addEventListener("click", function () {
    var rows = [["Tarehe", "Jina", "Namba", "TSh", "MB", "Muamala", "Hali"]];
    state.orders.forEach(function (o) {
      rows.push([new Date(o.time).toISOString(), o.name, o.phone, o.amount, o.mb, o.tx, statusLabel(o.status)]);
    });
    var csv = rows.map(function (r) {
      return r.map(function (c) { return '"' + String(c == null ? "" : c).replace(/"/g, '""') + '"'; }).join(",");
    }).join("\n");
    var blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "oda-duka-la-mb.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  });

  $("clearAll").addEventListener("click", function () {
    if (!confirm("Futa oda ZOTE? Hili haliwezi kurudishwa.")) return;
    state.orders = [];
    mine = [];
    save(); saveMine(mine);
    renderOwner();
  });

  document.addEventListener("visibilitychange", function () {
    if (!document.hidden && !$("viewCustomer").classList.contains("hidden")) startAds();
  });

  // ---------- Anza ----------
  applyTheme();
  var startRole = "customer";
  try { startRole = localStorage.getItem(ROLE_KEY) || "customer"; } catch (e) {}
  setRole(startRole);
})();
