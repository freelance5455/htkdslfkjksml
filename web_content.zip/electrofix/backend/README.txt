ElectroFix deployed source package. Backend secrets are intentionally excluded.
