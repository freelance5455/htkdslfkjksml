# ElectroFix source package

Current app: https://fixit-ai-sk6dde.v2.appdeploy.ai/

Secrets are not included.
