const promptBox = document.getElementById("prompt");
const feedback = document.getElementById("feedback");
const original = promptBox.value;

document.getElementById("copy").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(promptBox.value);
    feedback.textContent = "Instruções copiadas para a área de transferência.";
  } catch (e) {
    promptBox.focus();
    promptBox.select();
    const ok = document.execCommand("copy");
    feedback.textContent = ok
      ? "Instruções copiadas para a área de transferência."
      : "Não foi possível copiar automaticamente. Selecione o texto e copie manualmente.";
  }
});

document.getElementById("download").addEventListener("click", () => {
  const blob = new Blob([promptBox.value], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "prompt-modo-irrestrito.txt";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  feedback.textContent = "Arquivo de texto preparado para exportação.";
});

document.getElementById("reset").addEventListener("click", () => {
  promptBox.value = original;
  feedback.textContent = "Texto original restaurado.";
});

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
