// ==================== TROP ADMIN PANEL ====================
// ⚠️ WARNING: Client-side admin auth is NOT secure.
// For production, use Firebase Auth with custom claims or a backend.
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAUOtiDyr00PbQnxEC1SLfowSQDTBqNuwo",
  authDomain: "trop-61179.firebaseapp.com",
  projectId: "trop-61179",
  storageBucket: "trop-61179.firebasestorage.app",
  messagingSenderId: "745538607340",
  appId: "1:745538607340:web:29d149fe181aeddf2eadc9"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ⚠️ CHANGE THESE BEFORE DEPLOYING
const ADMIN_USER = "trop_admin";
const ADMIN_PASS = "change_this_password";

if (ADMIN_PASS === "change_this_password") {
  console.warn("⚠️ Admin password not changed! Change it before deploying.");
}

window.adminLogin = function () {
  const u = document.getElementById('adminUser').value.trim();
  const p = document.getElementById('adminPass').value.trim();
  if (u === ADMIN_USER && p === ADMIN_PASS) {
    sessionStorage.setItem('trop_admin_auth', '1');
    document.getElementById('adminLogin').style.display = 'none';
    document.getElementById('adminDashboard').style.display = 'block';
    loadAdminData();
  } else {
    alert('❌ Invalid credentials');
  }
};

window.adminLogout = function () {
  sessionStorage.removeItem('trop_admin_auth');
  location.reload();
};

async function loadAdminData() {
  try {
    const usersSnap = await getDocs(collection(db, "users"));
    const reelsSnap = await getDocs(collection(db, "trop_reels"));
    const reportsSnap = await getDocs(collection(db, "reports"));

    document.getElementById('totalUsers').textContent = usersSnap.size;
    document.getElementById('totalReels').textContent = reelsSnap.size;

    const reports = reportsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    const monReports = reports.filter(r => r.type === 'monetization');
    const otherReports = reports.filter(r => r.type !== 'monetization');

    document.getElementById('totalReports').textContent = otherReports.length;
    document.getElementById('totalMon').textContent = monReports.length;

    const rlist = document.getElementById('reportsList');
    rlist.innerHTML = otherReports.length ? '' : '<div style="padding:12px;color:#888;">No reports</div>';
    otherReports.slice(0, 30).forEach(r => {
      const div = document.createElement('div');
      div.className = 'list-item';
      div.innerHTML = `<span><b>${r.targetUsername || r.targetId}</b> — ${r.reason || 'N/A'}</span><span style="color:#888;font-size:11px;">${new Date(r.createdAt||0).toLocaleDateString()}</span>`;
      rlist.appendChild(div);
    });

    const mlist = document.getElementById('monList');
    mlist.innerHTML = monReports.length ? '' : '<div style="padding:12px;color:#888;">No requests</div>';
    monReports.slice(0, 30).forEach(r => {
      const div = document.createElement('div');
      div.className = 'list-item';
      div.innerHTML = `<span>👤 <b>${r.targetUsername || r.targetId}</b></span><span style="color:#0095f6;">${new Date(r.createdAt||0).toLocaleDateString()}</span>`;
      mlist.appendChild(div);
    });

    const ulist = document.getElementById('usersList');
    ulist.innerHTML = '';
    usersSnap.docs.slice(0, 20).forEach(d => {
      const u = d.data();
      const div = document.createElement('div');
      div.className = 'list-item';
      div.innerHTML = `<span>@${u.username || 'unknown'} — ${u.fullName || ''}</span><span style="color:#888;font-size:11px;">${(u.videos||[]).length} videos</span>`;
      ulist.appendChild(div);
    });
  } catch (e) {
    console.error('Admin load failed:', e);
    alert('Failed to load admin data: ' + e.message);
  }
}

if (sessionStorage.getItem('trop_admin_auth') === '1') {
  document.getElementById('adminLogin').style.display = 'none';
  document.getElementById('adminDashboard').style.display = 'block';
  loadAdminData();
}

console.log("✅ admin.js loaded");