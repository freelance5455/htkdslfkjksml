// ==================== FIREBASE + SUPABASE CONFIG ====================
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendPasswordResetEmail, updatePassword, reauthenticateWithCredential, EmailAuthProvider, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import { getFirestore, collection, doc, setDoc, updateDoc, arrayUnion, arrayRemove, increment, getDoc, getDocs, query, where, onSnapshot, deleteDoc } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAUOtiDyr00PbQnxEC1SLfowSQDTBqNuwo",
  authDomain: "trop-61179.firebaseapp.com",
  projectId: "trop-61179",
  storageBucket: "trop-61179.firebasestorage.app",
  messagingSenderId: "745538607340",
  appId: "1:745538607340:web:29d149fe181aeddf2eadc9",
  measurementId: "G-2YBGLZZ1N2"
};

const SUPABASE_URL = "https://kjjjnezdtpytxbkhuczy.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_EjDpkO2sNIsMQsxmsNLOGg_uqSfhEXk";
const SUPABASE_VIDEO_BUCKET = "videos";
const DEFAULT_AVATAR = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><circle cx='50' cy='50' r='50' fill='%231a1a1a'/><circle cx='50' cy='38' r='16' fill='%23555'/><path d='M15 90c2-20 18-30 35-30s33 10 35 30z' fill='%23555'/></svg>";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// ⚠️ AUTH FLOW LOCK — signup/login ke dauraan onAuthStateChanged ko rokta hai
window._tropAuthFlowLock = false;
window.DEFAULT_AVATAR = DEFAULT_AVATAR;

let supabase = null;
try {
  if (SUPABASE_URL.startsWith("https://") && SUPABASE_ANON_KEY.trim()) {
    supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    window.tropSupabaseReady = true;
    console.log("TROP Supabase Connected ✅");
  }
} catch (e) { console.error("Supabase init failed:", e); }

// ---------- EXPOSE to app.js ----------
window.tropAuth = auth;
window.tropDb = db;
window.tropOnAuthStateChanged = onAuthStateChanged;
window.tropGetDoc = getDoc;
window.tropDoc = doc;
window.tropSignOut = signOut;

// ---------- VIDEO UPLOAD ----------
window.tropUploadVideo = async function (file, uid, qualityLabel) {
  if (!file || !file.type.startsWith("video/")) throw new Error("INVALID_VIDEO");
  if (!supabase) throw new Error("SUPABASE_NOT_CONFIGURED");
  if (!uid) throw new Error("AUTH_REQUIRED");
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").replace(/_+/g, "_");
  const path = uid + "/" + Date.now() + "_" + (qualityLabel || "orig") + "_" + Math.random().toString(36).slice(2, 8) + "_" + safeName;
  const { error } = await supabase.storage.from(SUPABASE_VIDEO_BUCKET).upload(path, file, { cacheControl: "3600", upsert: false, contentType: file.type });
  if (error) {
    if (/row-level security|RLS/i.test(error.message || "")) {
      const e = new Error("SUPABASE_STORAGE_RLS"); e.originalMessage = error.message; throw e;
    }
    throw error;
  }
  const { data } = supabase.storage.from(SUPABASE_VIDEO_BUCKET).getPublicUrl(path);
  if (!data?.publicUrl) throw new Error("VIDEO_URL_FAILED");
  return { videoUrl: data.publicUrl, storagePath: path, quality: qualityLabel };
};

window.tropUploadStory = async function (file, uid) {
  if (!supabase || !file || !uid) throw new Error("STORY_UPLOAD_ERROR");
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const path = uid + "/stories/" + Date.now() + "_" + Math.random().toString(36).slice(2, 8) + "_" + safe;
  const { error } = await supabase.storage.from(SUPABASE_VIDEO_BUCKET).upload(path, file, { upsert: false, contentType: file.type });
  if (error) throw error;
  const { data } = supabase.storage.from(SUPABASE_VIDEO_BUCKET).getPublicUrl(path);
  return data.publicUrl;
};

// ---------- SIGNUP (with orphan recovery) ----------
window.tropSignup = async function (name, username, password, pic, bio) {
  const cleanUsername = username.trim().toLowerCase();
  if (!cleanUsername) throw new Error("USERNAME_REQUIRED");
  if (cleanUsername.length < 5) throw new Error("USERNAME_TOO_SHORT");
  if (!password || password.length < 6) throw new Error("PASSWORD_TOO_SHORT");

  const existing = await getDocs(query(collection(db, "users"), where("username", "==", cleanUsername)));
  if (!existing.empty) throw new Error("USERNAME_TAKEN");

  const internalEmail = cleanUsername + "@trop.app";
  window._tropAuthFlowLock = true;

  let credential;
  try {
    credential = await createUserWithEmailAndPassword(auth, internalEmail, password);
  } catch (e) {
    if (e.code === "auth/email-already-in-use") {
      try {
        credential = await signInWithEmailAndPassword(auth, internalEmail, password);
      } catch (signInErr) {
        window._tropAuthFlowLock = false;
        throw new Error("USERNAME_TAKEN");
      }
    } else {
      window._tropAuthFlowLock = false;
      throw e;
    }
  }

  try {
    const profile = {
      fullName: name.trim(), username: cleanUsername,
      pic: pic || DEFAULT_AVATAR, bio: bio || "",
      followers: 0, following: 0, videos: [], savedVideos: [],
      followingUsers: [], followersUsers: [], blockedUsers: [],
      verified: false, createdAt: Date.now()
    };
    await setDoc(doc(db, "users", credential.user.uid), profile);
    return { uid: credential.user.uid, ...profile };
  } finally {
    window._tropAuthFlowLock = false;
  }
};

// ---------- LOGIN ----------
window.tropLogin = async function (username, password) {
  const cleanUsername = String(username || "").trim().toLowerCase();
  if (!cleanUsername || !password) throw new Error("CREDENTIALS_REQUIRED");
  const snap = await getDocs(query(collection(db, "users"), where("username", "==", cleanUsername)));
  if (snap.empty) throw new Error("USER_NOT_FOUND");
  const profile = snap.docs[0].data();
  const internalEmail = cleanUsername + "@trop.app";
  window._tropAuthFlowLock = true;
  try {
    const credential = await signInWithEmailAndPassword(auth, internalEmail, password);
    return { uid: credential.user.uid, ...profile };
  } finally {
    window._tropAuthFlowLock = false;
  }
};

window.tropLogout = async function () { await signOut(auth); };

window.tropGetProfile = async function (uid) {
  const snap = await getDoc(doc(db, "users", uid));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
};

window.tropLoadUsers = async function () {
  const snap = await getDocs(collection(db, "users"));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

window.tropSaveProfile = async function (profile) {
  const uid = window.firebaseCurrentUserUid;
  if (!uid) throw new Error("AUTH_REQUIRED");
  await updateDoc(doc(db, "users", uid), {
    username: profile.username, fullName: profile.fullName,
    bio: profile.bio || "", pic: profile.pic || DEFAULT_AVATAR,
    followers: Number(profile.followers || 0), following: Number(profile.following || 0),
    videos: Array.isArray(profile.videos) ? profile.videos : [],
    savedVideos: Array.isArray(profile.savedVideos) ? profile.savedVideos : [],
    followingUsers: Array.isArray(profile.followingUsers) ? profile.followingUsers : [],
    followersUsers: Array.isArray(profile.followersUsers) ? profile.followersUsers : [],
    updatedAt: Date.now()
  });
};

window.tropSendPasswordReset = async function (username) {
  const clean = String(username || "").trim().toLowerCase();
  if (!clean) throw new Error("USERNAME_REQUIRED");
  const snap = await getDocs(query(collection(db, "users"), where("username", "==", clean)));
  if (snap.empty) throw new Error("USER_NOT_FOUND");
  await sendPasswordResetEmail(auth, clean + "@trop.app");
};

window.tropChangePassword = async function (currentPassword, newPassword) {
  const user = auth.currentUser;
  if (!user || !user.email) throw new Error("AUTH_REQUIRED");
  const cred = EmailAuthProvider.credential(user.email, currentPassword);
  await reauthenticateWithCredential(user, cred);
  await updatePassword(user, newPassword);
};

window.tropReport = async function (type, targetId, targetUsername, reason) {
  const reporterUid = window.firebaseCurrentUserUid;
  if (!reporterUid || !targetId) throw new Error("AUTH_REQUIRED");
  await setDoc(doc(collection(db, "reports")), {
    reporterUid, type: type || "content", targetId,
    targetUsername: targetUsername || "", reason: reason || "Other", createdAt: Date.now()
  });
};

window.tropToggleBlock = async function (targetUid, blocked) {
  const uid = window.firebaseCurrentUserUid;
  if (!uid || !targetUid || uid === targetUid) throw new Error("INVALID_USER");
  await updateDoc(doc(db, "users", uid), blocked
    ? { blockedUsers: arrayUnion(targetUid) }
    : { blockedUsers: arrayRemove(targetUid) });
};

window.tropToggleFollow = async function (targetUid, targetUsername, shouldFollow) {
  const myUid = window.firebaseCurrentUserUid;
  if (!myUid || !targetUid || myUid === targetUid) throw new Error("FOLLOW_INVALID");
  const myRef = doc(db, "users", myUid);
  const targetRef = doc(db, "users", targetUid);
  const meSnap = await getDoc(myRef);
  const me = meSnap.exists() ? meSnap.data() : {};
  const myFollowing = Array.isArray(me.followingUsers) ? me.followingUsers : [];
  if (shouldFollow) {
    if (myFollowing.includes(targetUid)) return { targetUid, following: true };
    await updateDoc(myRef, { followingUsers: arrayUnion(targetUid), following: increment(1) });
    await updateDoc(targetRef, { followersUsers: arrayUnion(myUid), followers: increment(1) });
  } else {
    if (!myFollowing.includes(targetUid)) return { targetUid, following: false };
    await updateDoc(myRef, { followingUsers: arrayRemove(targetUid), following: increment(-1) });
    await updateDoc(targetRef, { followersUsers: arrayRemove(myUid), followers: increment(-1) });
  }
  return { targetUid, following: shouldFollow };
};

// ---------- REELS ----------
const REELS_COLLECTION = "trop_reels";

function tropReelKey(videoUrl) {
  let hash = 2166136261;
  const text = String(videoUrl || "");
  for (let i = 0; i < text.length; i++) { hash ^= text.charCodeAt(i); hash = Math.imul(hash, 16777619); }
  return "v_" + (hash >>> 0).toString(16);
}

window.tropSaveReel = async function (reel) {
  if (!reel || !reel.videoUrl) throw new Error("REEL_DATA_INVALID");
  const docId = reel.docId || tropReelKey(reel.videoUrl);
  const payload = {
    ownerUid: reel.ownerUid || window.firebaseCurrentUserUid || "",
    user: reel.user || "", pic: reel.pic || DEFAULT_AVATAR, videoUrl: reel.videoUrl,
    caption: reel.caption || "", thumbnail: reel.thumbnail || "",
    music: reel.music || "", quality: reel.quality || "",
    duration: Number(reel.duration || 0),
    likes: Number(reel.likes || 0), views: Number(reel.views || 0), shares: Number(reel.shares || 0),
    comments: Array.isArray(reel.comments) ? reel.comments : [],
    likedBy: Array.isArray(reel.likedBy) ? [...new Set(reel.likedBy)] : [],
    viewedBy: Array.isArray(reel.viewedBy) ? [...new Set(reel.viewedBy)] : [],
    sharedBy: Array.isArray(reel.sharedBy) ? [...new Set(reel.sharedBy)] : [],
    savedBy: Array.isArray(reel.savedBy) ? [...new Set(reel.savedBy)] : [],
    createdAt: Number(reel.createdAt || Date.now()),
    updatedAt: Date.now()
  };
  await setDoc(doc(db, REELS_COLLECTION, docId), payload, { merge: true });
  return { ...reel, ...payload, docId };
};

window.tropLoadReels = async function () {
  const snap = await getDocs(collection(db, REELS_COLLECTION));
  return snap.docs.map(d => {
    const data = d.data() || {};
    return {
      docId: d.id, ...data,
      likedBy: Array.isArray(data.likedBy) ? data.likedBy : [],
      viewedBy: Array.isArray(data.viewedBy) ? data.viewedBy : [],
      sharedBy: Array.isArray(data.sharedBy) ? data.sharedBy : [],
      savedBy: Array.isArray(data.savedBy) ? data.savedBy : [],
      comments: Array.isArray(data.comments) ? data.comments : []
    };
  });
};

window.tropDeleteReel = async function (reelId, videoUrl) {
  if (!reelId) throw new Error("REEL_REQUIRED");
  await deleteDoc(doc(db, REELS_COLLECTION, String(reelId)));
  if (supabase && videoUrl) {
    try {
      const marker = "/storage/v1/object/public/" + SUPABASE_VIDEO_BUCKET + "/";
      const pos = videoUrl.indexOf(marker);
      if (pos >= 0) {
        const path = decodeURIComponent(videoUrl.substring(pos + marker.length));
        await supabase.storage.from(SUPABASE_VIDEO_BUCKET).remove([path]);
      }
    } catch (e) { console.warn("Storage delete skipped:", e); }
  }
};

window.tropDeleteOwnVideo = async function (uid, videoUrl, reelId) {
  if (!uid || !videoUrl) throw new Error("VIDEO_REQUIRED");
  if (reelId) await window.tropDeleteReel(reelId, videoUrl);
  const userRef = doc(db, "users", uid);
  const snap = await getDoc(userRef);
  if (snap.exists()) {
    const data = snap.data();
    const videos = Array.isArray(data.videos) ? data.videos.filter(v => v !== videoUrl) : [];
    await updateDoc(userRef, { videos });
  }
};

// ---------- CHAT ----------
function tropThreadId(a, b) { return [a, b].sort().join("_"); }

window.tropSendMessage = async function (targetUid, text, replyTo) {
  const uid = window.firebaseCurrentUserUid;
  if (!uid || !targetUid || !String(text || "").trim()) throw new Error("MESSAGE_REQUIRED");
  const threadId = tropThreadId(uid, targetUid);
  const ref = doc(collection(db, "chats", threadId, "messages"));
  const payload = { senderUid: uid, receiverUid: targetUid, text: String(text).trim(), createdAt: Date.now() };
  if (replyTo) payload.replyTo = { id: replyTo.id, text: replyTo.text, senderUid: replyTo.senderUid };
  await setDoc(ref, payload);
  try {
    await setDoc(doc(db, "users", uid, "chatThreads", targetUid), {
      otherUid: targetUid, lastMessage: payload.text, lastMessageAt: payload.createdAt, lastSenderUid: uid
    }, { merge: true });
  } catch(e) {}
  try {
    await setDoc(doc(db, "users", targetUid, "chatThreads", uid), {
      otherUid: uid, lastMessage: payload.text, lastMessageAt: payload.createdAt, lastSenderUid: uid
    }, { merge: true });
  } catch(e) {}
};

window.tropListenMessages = function (targetUid, callback) {
  const uid = window.firebaseCurrentUserUid;
  if (!uid || !targetUid) return () => {};
  const threadId = tropThreadId(uid, targetUid);
  return onSnapshot(collection(db, "chats", threadId, "messages"), snap => {
    const list = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => Number(a.createdAt || 0) - Number(b.createdAt || 0));
    callback(list);
  }, err => console.error("Message sync failed:", err));
};

window.tropListenChatThreads = function (callback) {
  const uid = window.firebaseCurrentUserUid;
  if (!uid) return () => {};
  return onSnapshot(collection(db, "users", uid, "chatThreads"), snap => {
    callback(snap.docs.map(d => ({ otherUid: d.id, ...d.data() })));
  }, err => console.error("Chat threads sync failed:", err));
};

console.log("✅ firebase-config.js loaded");