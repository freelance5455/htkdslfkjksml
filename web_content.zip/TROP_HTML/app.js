// ==================== TROP MAIN APP ====================
// ⚠️ app.js ek regular (non-module) script hai. Module `firebase-config.js`
// pehle load hota hai aur window.trop* helpers ready karta hai.

// ---------- CONSTANTS ----------
const DEFAULT_AVATAR = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><circle cx='50' cy='50' r='50' fill='%231a1a1a'/><circle cx='50' cy='38' r='16' fill='%23555'/><path d='M15 90c2-20 18-30 35-30s33 10 35 30z' fill='%23555'/></svg>";
const MAX_VIDEO_DURATION_SEC = 7 * 60;
const TROP_NEW_WINDOW_MS = 3 * 24 * 60 * 60 * 1000;

// ---------- STATE ----------
let sessionId = 'guest_' + Math.random().toString(36).substr(2, 8);
window.firebaseCurrentUserUid = null;

let ownProfile = {
  username: "", fullName: "", bio: "", pic: DEFAULT_AVATAR,
  followers: 0, following: 0, videos: [], savedVideos: [],
  followingUsers: [], followersUsers: [], blockedUsers: [], verified: false
};
let allUsers = [];
let storyData = [{ user: "Your Story", pic: DEFAULT_AVATAR, images: [], time: "Now", viewers: [], likers: [] }];
let reelsData = [];
let currentOtherUser = null;
let currentChatUser = null;
let currentReelCommentIndex = null;
let currentReplyMessage = null;
let currentReelIndex = 0;
let pendingVideoFile = null;
let pendingVideoQuality = "720p";
let storyImageIndex = 0;
let shareLock = false;
let viewLockSet = new Set();
let chatThreadsCache = [];
let chatThreadsUnsub = null;
let unreadChatCount = 0;
let lastReadAt = {};

// ============================================================
// PAGE FRAGMENT LOADER (works on http:// AND file://)
// ============================================================
const PAGE_FALLBACKS = {
  homePage: `
    <div class="refresh-btn" onclick="refreshHome()">↻ Refresh Feed</div>
    <div class="stories" id="storiesRow">
      <div class="story" onclick="openStoryViewer()">
        <div class="story-ring"><img src="" id="storyOwnPic" alt=""><div class="story-badge">+</div></div>
        <span>Your story</span>
      </div>
    </div>
    <div id="homeFeed"></div>`,
  searchPage: `
    <div class="search-header"><input type="text" class="search-input" id="searchInput" placeholder="Search users by username or name" oninput="searchUsers()"></div>
    <div class="search-results" id="searchResults"></div>`,
  reelsPage: `
    <div style="position:relative;height:100%;">
      <button class="refresh-btn" onclick="refreshReels()" style="position:absolute;top:10px;right:10px;z-index:20;">↻ Refresh Reels</button>
      <div class="reels-container" id="reelsContainer"></div>
    </div>`,
  messagesPage: `
    <div style="padding:14px 16px;font-weight:600;font-size:16px;border-bottom:1px solid #262626;">Chats</div>
    <div class="messages-list" id="messagesList"></div>`,
  profilePage: `
    <div class="profile-header">
      <div class="profile-top">
        <img src="" class="profile-pic-big" id="ownProfilePic" alt="">
        <div class="profile-stats">
          <div class="stat"><div class="num" id="ownPostCount">0</div><div class="label">Posts</div></div>
          <div class="stat" onclick="showUserList('followers')"><div class="num" id="ownFollowerCount">0</div><div class="label">Followers</div></div>
          <div class="stat" onclick="showUserList('following')"><div class="num" id="ownFollowingCount">0</div><div class="label">Following</div></div>
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div>
          <div class="profile-name" id="ownFullName">Your Name</div>
          <div class="profile-bio" id="ownBio"></div>
        </div>
        <svg onclick="openSettings()" fill="currentColor" viewBox="0 0 24 24" width="28" height="28" style="cursor:pointer;color:#f5f5f5;">
          <circle cx="12" cy="12" r="2.5"/><circle cx="12" cy="5" r="2.5"/><circle cx="12" cy="19" r="2.5"/><circle cx="5" cy="12" r="2.5"/><circle cx="19" cy="12" r="2.5"/>
        </svg>
      </div>
      <button class="edit-btn" onclick="openEditProfile()">Edit Profile</button>
    </div>
    <div class="profile-grid" id="profileGrid"></div>`
};

const loadedPages = new Set();

async function loadPageFragment(pageId) {
  if (loadedPages.has(pageId)) return;
  const el = document.getElementById(pageId);
  if (!el) return;
  const src = el.dataset.pageSrc;
  let loaded = false;
  if (src) {
    try {
      const res = await fetch(src);
      if (res.ok) {
        el.innerHTML = await res.text();
        loaded = true;
      }
    } catch (e) { /* file:// or offline — use fallback */ }
  }
  if (!loaded && PAGE_FALLBACKS[pageId]) {
    el.innerHTML = PAGE_FALLBACKS[pageId];
  }
  loadedPages.add(pageId);
}

async function preloadAllPageFragments() {
  const ids = ['homePage', 'searchPage', 'reelsPage', 'messagesPage', 'profilePage'];
  await Promise.all(ids.map(loadPageFragment));
}

// ============================================================
// VERIFIED TICK
// ============================================================
function isVerifiedUser(username) {
  if (!username) return false;
  const u = allUsers.find(x => x.username === username);
  if (!u) return username === ownProfile.username && ownProfile.verified === true;
  return u.verified === true;
}
function verifiedTickHTML(username, size) {
  if (!isVerifiedUser(username)) return '';
  let cls = 'verified-tick';
  if (size === true || size === 'big') cls += ' big';
  else if (size === 'small') cls += ' small';
  return '<span class="' + cls + '" title="Verified Account"></span>';
}

// ============================================================
// 80/20 MIX
// ============================================================
function tropBuildMixedFeed(sourceList) {
  if (!Array.isArray(sourceList) || sourceList.length === 0) return [];
  const now = Date.now();
  const uid = window.firebaseCurrentUserUid || 'guest';
  const isNew = (r) => {
    const ageMs = now - Number(r.createdAt || 0);
    const seenByMe = Array.isArray(r.viewedBy) && r.viewedBy.includes(uid);
    return ageMs < TROP_NEW_WINDOW_MS && !seenByMe;
  };
  const newOnes = sourceList.filter(isNew);
  const oldOnes = sourceList.filter(r => !isNew(r));
  const shuffle = (arr) => { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; };
  shuffle(newOnes); shuffle(oldOnes);
  const total = newOnes.length + oldOnes.length;
  let targetNew = Math.round(total * 0.8);
  if (targetNew > newOnes.length) targetNew = newOnes.length;
  let targetOld = total - targetNew;
  if (targetOld > oldOnes.length) targetOld = oldOnes.length;
  const mixed = [...newOnes.slice(0, targetNew), ...oldOnes.slice(0, targetOld)];
  const seen = new Set();
  const finalList = [];
  mixed.forEach(r => { if (!seen.has(r.videoUrl)) { seen.add(r.videoUrl); finalList.push(r); } });
  return shuffle(finalList);
}

// ============================================================
// AUTH UI
// ============================================================
function showSignup() {
  document.getElementById('loginPage').classList.remove('active');
  document.getElementById('signupPage').classList.add('active');
  document.getElementById('signupUserError').classList.remove('show');
}
function showLogin() {
  document.getElementById('signupPage').classList.remove('active');
  document.getElementById('loginPage').classList.add('active');
}

function applyDefaultAvatar() {
  const ids = ['signupProfilePic', 'ownProfilePic', 'navProfilePic', 'storyOwnPic', 'editProfilePic'];
  ids.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.src = DEFAULT_AVATAR;
  });
}

let signupPicData = null;
function handleSignupPic(event) {
  const file = event.target.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const img = new Image();
    img.onload = () => {
      const size = 300;
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = size;
      const ctx = canvas.getContext('2d');
      const scale = Math.max(size / img.width, size / img.height);
      const w = img.width * scale, h = img.height * scale;
      ctx.drawImage(img, (size-w)/2, (size-h)/2, w, h);
      signupPicData = canvas.toDataURL('image/jpeg', 0.72);
      const el = document.getElementById('signupProfilePic');
      if (el) el.src = signupPicData;
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
  event.target.value = '';
}

function validateSignupUser() {
  const user = document.getElementById('signupUser').value.trim().toLowerCase();
  const err = document.getElementById('signupUserError');
  if (user.length < 5) { err.textContent = 'Username must be at least 5 characters'; err.classList.add('show'); return false; }
  if (!/^[a-z0-9._]+$/.test(user)) { err.textContent = 'Only letters, numbers, dots, underscores allowed'; err.classList.add('show'); return false; }
  if (allUsers.some(u => u.username === user)) { err.textContent = 'Username already taken'; err.classList.add('show'); return false; }
  err.classList.remove('show'); return true;
}

async function signup() {
  const name = document.getElementById('signupName').value.trim();
  const user = document.getElementById('signupUser').value.trim().toLowerCase();
  const pass = document.getElementById('signupPass').value.trim();
  if (!name) return showToast('Please enter your full name');
  if (!user) return showToast('Please enter a username');
  if (!pass) return showToast('Please enter a password');
  if (user.length < 5) return showToast('Username must be at least 5 characters');
  if (!/^[a-z0-9._]+$/.test(user)) return showToast('Only letters, numbers, dots, underscores allowed');
  if (pass.length < 6) return showToast('Password must be at least 6 characters');

  const btn = document.querySelector('#signupPage .auth-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Creating...'; }

  try {
    const pic = signupPicData || DEFAULT_AVATAR;
    const profile = await window.tropSignup(name, user, pass, pic, '');
    window.firebaseCurrentUserUid = profile.uid;
    sessionId = profile.uid;
    ownProfile = { ...ownProfile,
      username: profile.username, fullName: profile.fullName, pic: profile.pic,
      bio: profile.bio || '', followers: 0, following: 0,
      videos: [], savedVideos: [], followingUsers: [], followersUsers: [],
      blockedUsers: [], verified: false };
    allUsers = await window.tropLoadUsers();
    allUsers = allUsers.map(u => ({ ...u, isFollowing: false, isOwn: u.username === profile.username }));
    try { reelsData = await window.tropLoadReels(); } catch(e) { reelsData = []; }
    await ensureOwnReelsPersisted();
    if (typeof window.tropBootRefreshFeeds === 'function') await window.tropBootRefreshFeeds();
    storyData[0].pic = ownProfile.pic;
    storyData[0].user = ownProfile.fullName;
    updateOwnProfileUI(); updateProfileStats();
    document.getElementById('signupPage').classList.remove('active');
    document.getElementById('app').classList.add('active');
    const sop = document.getElementById('storyOwnPic'); if (sop) sop.src = ownProfile.pic;
    buildReels(); generateHomeFeed();
    startChatThreadsListener();
    showToast('Welcome to TROP!');
    signupPicData = null;
    document.getElementById('signupName').value = '';
    document.getElementById('signupUser').value = '';
    document.getElementById('signupPass').value = '';
    const spp = document.getElementById('signupProfilePic'); if (spp) spp.src = DEFAULT_AVATAR;
    document.getElementById('signupUserError').classList.remove('show');
  } catch (error) {
    console.error('Signup error:', error);
    const msg = error.message || '', code = error.code || '';
    if (msg === 'USERNAME_TAKEN' || code === 'auth/email-already-in-use') showToast('Username already taken');
    else if (msg === 'USERNAME_TOO_SHORT') showToast('Username must be at least 5 characters');
    else if (msg === 'PASSWORD_TOO_SHORT' || code === 'auth/weak-password') showToast('Password must be at least 6 characters');
    else if (code === 'auth/invalid-email') showToast('Invalid username format');
    else if (code === 'auth/network-request-failed') showToast('Network error. Check connection');
    else if (code === 'auth/too-many-requests') showToast('Too many attempts. Try later');
    else showToast(msg || 'Signup failed. Try again.');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Sign Up'; }
  }
}

async function login() {
  const user = document.getElementById('loginUser').value.trim().toLowerCase();
  const pass = document.getElementById('loginPass').value.trim();
  if (!user) return showToast('Please enter your username');
  if (!pass) return showToast('Please enter your password');

  const btn = document.querySelector('#loginPage .auth-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Logging in...'; }

  try {
    const profile = await window.tropLogin(user, pass);
    window.firebaseCurrentUserUid = profile.uid;
    sessionId = profile.uid;
    ownProfile.username = profile.username;
    ownProfile.fullName = profile.fullName;
    ownProfile.pic = profile.pic || DEFAULT_AVATAR;
    ownProfile.bio = profile.bio || '';
    ownProfile.followers = profile.followers || 0;
    ownProfile.following = profile.following || 0;
    ownProfile.videos = profile.videos || [];
    ownProfile.savedVideos = profile.savedVideos || [];
    ownProfile.followingUsers = profile.followingUsers || [];
    ownProfile.followersUsers = profile.followersUsers || [];
    ownProfile.blockedUsers = profile.blockedUsers || [];
    ownProfile.verified = profile.verified === true;
    allUsers = await window.tropLoadUsers();
    allUsers = allUsers.map(u => ({ ...u, isFollowing: (profile.followingUsers || []).includes(u.id), isOwn: u.username === profile.username }));
    reelsData = await window.tropLoadReels();
    await ensureOwnReelsPersisted();
    if (typeof window.tropBootRefreshFeeds === 'function') await window.tropBootRefreshFeeds();
    storyData[0].pic = ownProfile.pic;
    storyData[0].user = ownProfile.fullName;
    storyData[0].images = (profile.story && Number(profile.story.expiresAt || 0) > Date.now()) ? (profile.story.items || []) : [];
    document.getElementById('loginPage').classList.remove('active');
    document.getElementById('app').classList.add('active');
    const sop = document.getElementById('storyOwnPic'); if (sop) sop.src = ownProfile.pic;
    updateOwnProfileUI(); updateProfileStats();
    generateHomeFeed(); buildReels();
    startChatThreadsListener();
    showToast('Welcome back, ' + ownProfile.fullName + '!');
    document.getElementById('loginUser').value = '';
    document.getElementById('loginPass').value = '';
  } catch (error) {
    console.error('Login error:', error);
    const msg = error.message || '', code = error.code || '';
    if (msg === 'USER_NOT_FOUND') showToast('User not found. Please sign up.');
    else if (msg === 'CREDENTIALS_REQUIRED') showToast('Please enter username and password');
    else if (['auth/invalid-credential','auth/wrong-password','auth/user-not-found','auth/invalid-login-credentials'].includes(code)) showToast('Incorrect username or password');
    else if (code === 'auth/too-many-requests') showToast('Too many attempts. Try later');
    else if (code === 'auth/network-request-failed') showToast('Network error. Check connection');
    else showToast(msg || 'Login failed. Try again.');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Log In'; }
  }
}

async function logout() {
  try {
    document.querySelectorAll('video').forEach(v => { try { v.pause(); } catch(e){} });
    if (window._tropChatUnsub) { window._tropChatUnsub(); window._tropChatUnsub = null; }
    if (chatThreadsUnsub) { chatThreadsUnsub(); chatThreadsUnsub = null; }
    if (window.tropLogout) await window.tropLogout();
    window.firebaseCurrentUserUid = null;
    sessionId = 'guest_' + Math.random().toString(36).substr(2, 8);
    reelsData = []; allUsers = []; viewLockSet.clear();
    chatThreadsCache = []; unreadChatCount = 0; lastReadAt = {};
    updateChatUnreadDot();
    ownProfile = { username:"", fullName:"", bio:"", pic: DEFAULT_AVATAR, followers:0, following:0, videos:[], savedVideos:[], followingUsers:[], followersUsers:[], blockedUsers:[], verified:false };
    document.getElementById('app').classList.remove('active');
    document.getElementById('loginPage').classList.add('active');
    showToast('Logged out');
  } catch (e) { console.error(e); showToast('Logout failed'); }
}

// ============================================================
// NAVIGATION
// ============================================================
function goToPage(page) {
  document.querySelectorAll('video').forEach(video => {
    const onReels = !!video.closest('#reelsPage');
    const onHome = !!video.closest('#homePage');
    const keep = (page === 'reels' && onReels) || (page === 'home' && onHome);
    if (!keep) { try { video.pause(); video.muted = true; } catch(e){} }
  });
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const target = document.getElementById(page + 'Page');
  if (target) target.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active');
    if (item.dataset.page === page) item.classList.add('active');
  });
  if (page === 'home') generateHomeFeed();
  if (page === 'search') { const si = document.getElementById('searchInput'); if (si) si.value = ''; searchUsers(); }
  if (page === 'messages') { loadMessagesList(); markAllChatsRead(); }
  if (page === 'reels') { prepareReelFeed(); buildReels(); setTimeout(() => { tropApplyReelTransforms(false); tropSyncReelPlayback(); }, 30); }
  if (page === 'profile') updateProfileStats();
}

// ============================================================
// SEARCH
// ============================================================
function searchUsers() {
  const si = document.getElementById('searchInput');
  const results = document.getElementById('searchResults');
  if (!si || !results) return;
  const q = si.value.toLowerCase().trim();
  results.innerHTML = '';
  if (q === '') {
    results.innerHTML = `<div class="search-empty">🔍 Start typing to search users<div class="hint">Search by username or full name</div></div>`;
    return;
  }
  const filtered = allUsers.filter(u => !u.isOwn && (
    u.username.toLowerCase().includes(q) || (u.fullName||'').toLowerCase().includes(q)
  ));
  if (filtered.length === 0) {
    results.innerHTML = `<div class="search-empty">No users found for "<b>${escapeHTML(q)}</b>"</div>`;
    return;
  }
  filtered.forEach(user => {
    const div = document.createElement('div');
    div.className = 'search-user';
    div.onclick = () => openOtherProfile(user.username);
    div.innerHTML = `<img src="${user.pic || DEFAULT_AVATAR}"><div class="info"><div class="username">${user.username}${verifiedTickHTML(user.username,'small')}</div><div class="fullname">${user.fullName||''}</div></div>`;
    results.appendChild(div);
  });
}

// ============================================================
// OTHER PROFILE
// ============================================================
function openOtherProfile(username) {
  if (username === ownProfile.username) { goToPage('profile'); return; }
  const user = allUsers.find(u => u.username === username);
  if (!user) { showToast('User not found'); return; }
  currentOtherUser = user;
  currentOtherUser.isFollowing = Array.isArray(ownProfile.followingUsers) && ownProfile.followingUsers.includes(user.id);
  document.getElementById('otherProfilePic').src = user.pic || DEFAULT_AVATAR;
  document.getElementById('otherFullName').innerHTML = (user.fullName||'') + verifiedTickHTML(user.username, 'big');
  document.getElementById('otherBio').innerHTML = (user.bio || '').replace(/\n/g, '<br>');
  document.getElementById('otherPostCount').textContent = (user.videos || []).length;
  document.getElementById('otherFollowerCount').textContent = Number(user.followers || 0).toLocaleString('en-IN');
  document.getElementById('otherFollowingCount').textContent = Number(user.following || 0).toLocaleString('en-IN');
  const followBtn = document.getElementById('followBtn');
  if (user.isFollowing) { followBtn.textContent = 'Following'; followBtn.classList.add('following'); }
  else { followBtn.textContent = 'Follow'; followBtn.classList.remove('following'); }
  const blockBtn = document.getElementById('blockBtn');
  if (blockBtn) blockBtn.textContent = (ownProfile.blockedUsers||[]).includes(user.id) ? 'Unblock' : 'Block';
  const grid = document.getElementById('otherProfileGrid');
  grid.innerHTML = '';
  if (user.videos && user.videos.length > 0) {
    user.videos.forEach(video => {
      const div = document.createElement('div');
      div.className = 'profile-video-item';
      const reel = reelsData.find(r => r.videoUrl === video);
      if (reel && reel.thumbnail) div.innerHTML = `<img src="${reel.thumbnail}">`;
      else div.innerHTML = `<video src="${video}" muted playsinline preload="metadata"></video>`;
      div.innerHTML += `<div class="video-stats-overlay">
        <span>❤️ ${reel?reel.likes:0}</span><span>💬 ${reel&&reel.comments?reel.comments.length:0}</span>
        <span>👁️ ${reel?reel.views:0}</span><span>↗️ ${reel?reel.shares:0}</span>
      </div>`;
      div.onclick = () => openReelFromIndex(reel);
      grid.appendChild(div);
    });
  } else {
    grid.innerHTML = '<div style="grid-column:1/-1;padding:40px;text-align:center;color:#a8a8a8;">No videos yet</div>';
  }
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('otherProfilePage').classList.add('active');
}

function openReelFromIndex(reel) {
  if (!reel) return;
  const idx = reelsData.indexOf(reel);
  if (idx < 0) return;
  goToPage('reels');
  setTimeout(() => {
    currentReelIndex = idx;
    const slides = document.querySelectorAll('.reel-slide');
    slides.forEach((s, i) => { s.style.transition = 'transform 0.4s'; s.style.transform = `translateY(${(i-currentReelIndex)*100}%)`; });
    setTimeout(() => tropSyncReelPlayback(), 400);
  }, 100);
}

async function toggleFollow() {
  if (!currentOtherUser || !window.firebaseCurrentUserUid) return;
  const shouldFollow = !currentOtherUser.isFollowing;
  const targetUid = currentOtherUser.id;
  if (!targetUid || targetUid === window.firebaseCurrentUserUid) return showToast('Cannot follow this account');
  const btn = document.getElementById('followBtn');
  if (btn.disabled) return;
  if (btn) btn.disabled = true;
  try {
    await window.tropToggleFollow(targetUid, currentOtherUser.username, shouldFollow);
    currentOtherUser.isFollowing = shouldFollow;
    if (!Array.isArray(ownProfile.followingUsers)) ownProfile.followingUsers = [];
    if (shouldFollow) {
      if (!ownProfile.followingUsers.includes(targetUid)) ownProfile.followingUsers.push(targetUid);
      ownProfile.following = (ownProfile.following||0)+1;
    } else {
      ownProfile.followingUsers = ownProfile.followingUsers.filter(id => id !== targetUid);
      ownProfile.following = Math.max(0,(ownProfile.following||1)-1);
    }
    const target = allUsers.find(u => u.id === targetUid);
    if (target) {
      target.isFollowing = shouldFollow;
      target.followersUsers = Array.isArray(target.followersUsers) ? target.followersUsers : [];
      if (shouldFollow && !target.followersUsers.includes(window.firebaseCurrentUserUid)) target.followersUsers.push(window.firebaseCurrentUserUid);
      if (!shouldFollow) target.followersUsers = target.followersUsers.filter(id => id !== window.firebaseCurrentUserUid);
      target.followers = target.followersUsers.length;
      currentOtherUser = target;
    }
    if (btn) { btn.textContent = shouldFollow ? 'Following' : 'Follow'; btn.classList.toggle('following', shouldFollow); }
    document.getElementById('otherFollowerCount').textContent = (currentOtherUser.followers || 0).toLocaleString('en-IN');
    document.getElementById('ownFollowingCount').textContent = ownProfile.following;
    showToast(shouldFollow ? 'Followed' : 'Unfollowed');
    updateProfileStats();
  } catch (e) { console.error(e); showToast('Follow update failed'); }
  finally { if (btn) btn.disabled = false; }
}

function openChatFromProfile() { if (!currentOtherUser) return; openChat(currentOtherUser.username); }

async function reportCurrentUser() {
  if (!currentOtherUser) return;
  const reason = prompt('Report reason:');
  if (!reason) return;
  try { await window.tropReport('user', currentOtherUser.id, currentOtherUser.username, reason); showToast('Report submitted'); }
  catch(e) { showToast('Report failed'); }
}

async function toggleCurrentBlock() {
  if (!currentOtherUser) return;
  const blocked = Array.isArray(ownProfile.blockedUsers) && ownProfile.blockedUsers.includes(currentOtherUser.id);
  try {
    await window.tropToggleBlock(currentOtherUser.id, !blocked);
    ownProfile.blockedUsers = blocked ? ownProfile.blockedUsers.filter(x=>x!==currentOtherUser.id) : [...(ownProfile.blockedUsers||[]), currentOtherUser.id];
    document.getElementById('blockBtn').textContent = blocked ? 'Block' : 'Unblock';
    generateHomeFeed(); buildReels();
    showToast(blocked ? 'User unblocked' : 'User blocked');
  } catch(e) { showToast('Block failed'); }
}

// ============================================================
// CHAT
// ============================================================
function loadMessagesList() {
  const list = document.getElementById('messagesList');
  if (!list) return;
  list.innerHTML = '';
  if (!window.firebaseCurrentUserUid) {
    list.innerHTML = `<div class="messages-empty">Please login to see your chats</div>`;
    return;
  }
  if (!chatThreadsCache || chatThreadsCache.length === 0) {
    list.innerHTML = `<div class="messages-empty">💬 No conversations yet<div class="hint">Open someone's profile and tap Message to start chatting</div></div>`;
    return;
  }
  const sorted = [...chatThreadsCache].sort((a, b) => Number(b.lastMessageAt||0) - Number(a.lastMessageAt||0));
  sorted.forEach(thread => {
    const user = allUsers.find(u => u.id === thread.otherUid) || { id: thread.otherUid, username: 'user', fullName: '', pic: DEFAULT_AVATAR };
    const div = document.createElement('div');
    div.className = 'message-item';
    const prefix = thread.lastSenderUid === window.firebaseCurrentUserUid ? 'You: ' : '';
    const preview = prefix + (thread.lastMessage || 'Tap to chat');
    const readAt = Number(lastReadAt[thread.otherUid] || 0);
    const isUnread = thread.lastSenderUid && thread.lastSenderUid !== window.firebaseCurrentUserUid && Number(thread.lastMessageAt||0) > readAt;
    const badge = isUnread ? `<span class="message-badge">●</span>` : '';
    const t = Number(thread.lastMessageAt || 0);
    let timeStr = '';
    if (t) {
      const d = new Date(t);
      const now = new Date();
      timeStr = d.toDateString() === now.toDateString()
        ? d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
        : d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
    }
    div.onclick = () => openChat(user.username);
    div.innerHTML = `
      <img src="${user.pic||DEFAULT_AVATAR}">
      <div class="message-info">
        <div class="name">${user.username}${verifiedTickHTML(user.username,'small')}${badge}</div>
        <div class="preview">${escapeHTML(preview)}</div>
      </div>
      <div class="message-time">${timeStr}</div>`;
    list.appendChild(div);
  });
}

function markAllChatsRead() {
  if (!chatThreadsCache) return;
  const now = Date.now();
  chatThreadsCache.forEach(t => { lastReadAt[t.otherUid] = now; });
  unreadChatCount = 0;
  updateChatUnreadDot();
  loadMessagesList();
}

function updateChatUnreadDot() {
  const dot = document.getElementById('chatUnreadDot');
  if (!dot) return;
  if (unreadChatCount > 0) dot.classList.add('show');
  else dot.classList.remove('show');
}

function startChatThreadsListener() {
  if (!window.firebaseCurrentUserUid || typeof window.tropListenChatThreads !== 'function') return;
  if (chatThreadsUnsub) { chatThreadsUnsub(); chatThreadsUnsub = null; }
  chatThreadsUnsub = window.tropListenChatThreads(threads => {
    chatThreadsCache = threads;
    let count = 0;
    threads.forEach(t => {
      const readAt = Number(lastReadAt[t.otherUid] || 0);
      if (t.lastSenderUid && t.lastSenderUid !== window.firebaseCurrentUserUid && Number(t.lastMessageAt||0) > readAt) count++;
    });
    unreadChatCount = count;
    updateChatUnreadDot();
    if (document.getElementById('messagesPage')?.classList.contains('active')) loadMessagesList();
  });
}

function openChat(username) {
  const user = allUsers.find(u => u.username === username);
  if (!user) return;
  currentChatUser = user;
  document.getElementById('chatUserPic').src = user.pic || DEFAULT_AVATAR;
  document.getElementById('chatUserName').innerHTML = user.username + verifiedTickHTML(user.username,'small');
  document.getElementById('chatMessages').innerHTML = '';
  cancelReply();
  if (window.tropListenMessages) {
    if (window._tropChatUnsub) window._tropChatUnsub();
    window._tropChatUnsub = window.tropListenMessages(user.id, renderChatMessages);
  }
  document.getElementById('chatPage').classList.add('active');
  document.getElementById('chatInput').value = '';
  lastReadAt[user.id] = Date.now();
  unreadChatCount = Math.max(0, unreadChatCount - 1);
  updateChatUnreadDot();
}

function closeChat() {
  document.getElementById('chatPage').classList.remove('active');
  cancelReply();
  if (window._tropChatUnsub) { window._tropChatUnsub(); window._tropChatUnsub = null; }
  if (document.getElementById('messagesPage')?.classList.contains('active')) loadMessagesList();
}

function renderChatMessages(list) {
  const container = document.getElementById('chatMessages');
  if (!container) return;
  container.innerHTML = '';
  const uid = window.firebaseCurrentUserUid;
  list.forEach(m => {
    const div = document.createElement('div');
    div.className = 'msg ' + (m.senderUid === uid ? 'sent' : 'received');
    let inner = '';
    if (m.replyTo) inner += `<div class="reply-preview">↩ ${escapeHTML((m.replyTo.text||'').slice(0,60))}</div>`;
    inner += `<span>${escapeHTML(m.text||'')}</span>`;
    const payload = JSON.stringify({ id: m.id, text: m.text, senderUid: m.senderUid }).replace(/'/g, "&apos;").replace(/"/g, "&quot;");
    inner += `<button class="reply-btn" onclick='startReply(${payload})'>Reply</button>`;
    div.innerHTML = inner;
    container.appendChild(div);
  });
  container.scrollTop = container.scrollHeight;
}

function escapeHTML(s){ return String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

function startReply(msg) {
  currentReplyMessage = { id: msg.id, text: msg.text, senderUid: msg.senderUid };
  document.getElementById('replyPreviewText').textContent = '↩ ' + (msg.text||'').slice(0,50);
  document.getElementById('replyPreviewBar').classList.add('active');
  document.getElementById('chatInput').focus();
}

function cancelReply() {
  currentReplyMessage = null;
  const bar = document.getElementById('replyPreviewBar');
  if (bar) bar.classList.remove('active');
}

async function sendMessage() {
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if (!text || !currentChatUser) return;
  input.value = '';
  try {
    await window.tropSendMessage(currentChatUser.id, text, currentReplyMessage);
    cancelReply();
  } catch (e) { console.error(e); showToast('Message failed'); }
}

// ============================================================
// INSTANT VIEW REGISTRATION
// ============================================================
function registerReelViewInstant(reel) {
  if (!reel || !window.firebaseCurrentUserUid) return;
  if (!reel.docId && reel.id === undefined) return;
  const uid = window.firebaseCurrentUserUid;
  if (Array.isArray(reel.viewedBy) && reel.viewedBy.includes(uid)) return;
  const key = reel.docId || reel.videoUrl;
  if (viewLockSet.has(key)) return;
  viewLockSet.add(key);
  reel.views = Number(reel.views || 0) + 1;
  reel.viewedBy = Array.isArray(reel.viewedBy) ? [...reel.viewedBy, uid] : [uid];
  const idStr = reel.docId || reel.id;
  document.querySelectorAll('#reelsPage .reel-slide').forEach(slide => {
    if (slide.dataset.reelId == idStr) {
      const el = slide.querySelector('.reel-view-count');
      if (el) el.textContent = '👁️ ' + reel.views.toLocaleString('en-IN');
    }
  });
  const homeIdx = reelsData.indexOf(reel);
  if (homeIdx > -1) {
    document.querySelectorAll(`#homeFeed .post[data-reel-index="${homeIdx}"]`).forEach(post => {
      const spans = post.querySelectorAll('.home-action-bar span');
      spans.forEach(sp => { if (sp.textContent.startsWith('👁️')) sp.textContent = '👁️ ' + reel.views.toLocaleString('en-IN'); });
    });
  }
  window.tropSaveReel(reel).catch(e => console.error('View save failed:', e));
}

document.addEventListener('play', function (e) {
  const v = e.target;
  if (!(v instanceof HTMLVideoElement)) return;
  const slide = v.closest('#reelsPage .reel-slide');
  if (slide) {
    const id = slide.dataset.reelId;
    const reel = reelsData.find(r => (r.docId || r.id) == id);
    if (reel) registerReelViewInstant(reel);
    return;
  }
  const homePost = v.closest('#homeFeed .post');
  if (homePost) {
    const idx = Number(homePost.dataset.reelIndex);
    if (!isNaN(idx)) {
      const reel = reelsData[idx];
      if (reel) registerReelViewInstant(reel);
    }
  }
}, true);

// ============================================================
// REELS FEED
// ============================================================
let tropReelsSwipeBound = false;
let touchStartY = 0, touchStartX = 0, isSwiping = false, lastSwipeEnd = 0;

function prepareReelFeed() {
  if (!Array.isArray(reelsData) || reelsData.length === 0) return;
  const mixed = tropBuildMixedFeed(reelsData);
  if (mixed.length > 0) reelsData = mixed.map((r,i)=>({...r,id:i}));
  currentReelIndex = 0;
}

function buildReels() {
  const container = document.getElementById('reelsContainer');
  if (!container) return;
  container.innerHTML = '';
  const wrapper = document.createElement('div');
  wrapper.className = 'reel-wrapper';

  (ownProfile.videos || []).forEach(vid => {
    if (!reelsData.some(r => r.videoUrl === vid)) {
      reelsData.push({ user: ownProfile.username, ownerUid: window.firebaseCurrentUserUid,
        pic: ownProfile.pic, videoUrl: vid, thumbnail: '', caption: 'My video', music: '🎵 Original',
        likes: 0, views: 0, shares: 0, comments: [], likedBy: [], viewedBy: [], sharedBy: [], savedBy: [], createdAt: Date.now() });
    }
  });

  if (reelsData.length === 0) {
    wrapper.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#a8a8a8;">No reels yet</div>';
    container.appendChild(wrapper);
    return;
  }

  reelsData.forEach((reel, index) => {
    const slide = document.createElement('div');
    slide.className = 'reel-slide';
    slide.style.transform = `translateY(${index * 100}%)`;
    slide.dataset.reelId = reel.docId || reel.id;
    const actorId = window.firebaseCurrentUserUid || sessionId;
    const isLiked = (reel.likedBy||[]).includes(actorId);
    const isSaved = (reel.savedBy||[]).includes(actorId);
    const likes = Number(reel.likes||0);
    const commentCount = (reel.comments||[]).length;
    const saves = (reel.savedBy||[]).length;

    slide.innerHTML = `
      <video src="${reel.videoUrl}" poster="${reel.thumbnail||''}" loop playsinline preload="metadata"></video>
      <div class="reel-overlay"></div>
      <div class="reel-play-btn" onclick="toggleReelPlay(this)">▶</div>
      <div class="reel-content">
        <div class="reel-user">
          <img src="${reel.pic||DEFAULT_AVATAR}" onclick="openOtherProfile('${reel.user}')">
          <span class="reel-username" onclick="openOtherProfile('${reel.user}')">${reel.user}${verifiedTickHTML(reel.user,'small')}</span>
        </div>
        <div class="reel-caption">${escapeHTML(reel.caption||'')}</div>
        <div class="reel-music">${reel.music||'🎵 Original'}</div>
      </div>
      <div class="reel-actions">
        <svg class="reel-like-btn ${isLiked?'liked':''}" onclick="toggleReelLike(this,${index})" fill="currentColor" viewBox="0 0 24 24">
          <path d="M16.8 3.9A5 5 0 0 1 21.5 9.1c0 3.1-2.7 5-5.2 7.2-2.5 2.2-3.9 3.5-4.3 3.9-.4-.4-1.8-1.7-4.3-3.9C5.2 14.1 2.5 12.2 2.5 9.1a5 5 0 0 1 4.7-5.2 4.2 4.2 0 0 1 3.7 1.9c.8 1.2 1 1.8 1.1 1.8s.3-.6 1.1-1.8a4.2 4.2 0 0 1 3.7-1.9z"/>
        </svg>
        <div class="reel-count" onclick="showReelLikers(${index})">${likes.toLocaleString('en-IN')}</div>
        <svg onclick="openReelComment(${index})" fill="currentColor" viewBox="0 0 24 24"><path d="M20.7 17.8a1 1 0 0 1-.3.7L16.5 22.5l-1.3-1.3a1 1 0 0 1 0-1.4l3.9-3.9a1 1 0 0 1 1.4 0l1.3 1.3a1 1 0 0 1-.1 1.6z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M20.7 17.8a9.5 9.5 0 1 0-2.8 2.8" fill="none" stroke="currentColor" stroke-width="2"/></svg>
        <div class="reel-count" onclick="openReelComment(${index})" style="margin-top:-10px;font-size:11px;">${commentCount}</div>
        <svg onclick="shareReel(${index})" fill="currentColor" viewBox="0 0 24 24"><line stroke="currentColor" stroke-width="2" x1="22" x2="9.2" y1="3" y2="10.1"/><polygon fill="none" points="11.7 20.3 22 3 2 3 9.2 10.1 11.7 20.3" stroke="currentColor" stroke-width="2"/></svg>
        <div class="reel-share-count" onclick="showReelShares(${index})">${(reel.shares||0).toLocaleString('en-IN')}</div>
        <svg class="reel-save-btn ${isSaved?'saved':''}" onclick="toggleReelSave(this,${index})" fill="currentColor" viewBox="0 0 24 24"><polygon points="20 21 12 13.4 4 21 4 3 20 3 20 21" stroke="currentColor" stroke-width="2" fill="${isSaved?'#f5f5f5':'none'}"/></svg>
        <div class="reel-save-count" onclick="showReelSaves(${index})">${saves}</div>
        <div class="reel-view-count" onclick="showReelViews(${index})">👁️ ${(reel.views||0).toLocaleString('en-IN')}</div>
      </div>`;
    slide.dataset.likes = likes;
    slide.dataset.liked = isLiked ? 'true' : 'false';
    slide.dataset.saved = isSaved ? 'true' : 'false';
    slide.dataset.saves = saves;
    slide.dataset.shares = reel.shares || 0;
    wrapper.appendChild(slide);
  });

  container.appendChild(wrapper);
  tropApplyReelTransforms(false);
  tropBindReelsGestures();
  if (document.getElementById('reelsPage')?.classList.contains('active')) setTimeout(tropSyncReelPlayback, 0);
}

function tropApplyReelTransforms(animate) {
  const container = document.getElementById('reelsContainer');
  if (!container) return;
  container.querySelectorAll('.reel-slide').forEach((slide, i) => {
    slide.style.transition = animate ? 'transform .35s cubic-bezier(.25,.46,.45,.94)' : 'none';
    slide.style.transform = `translateY(${(i - currentReelIndex) * 100}%)`;
  });
}

function tropBindReelsGestures() {
  if (tropReelsSwipeBound) return;
  const container = document.getElementById('reelsContainer');
  if (!container) return;
  tropReelsSwipeBound = true;

  container.addEventListener('touchstart', e => {
    if (!document.getElementById('reelsPage')?.classList.contains('active')) return;
    touchStartY = e.touches[0].clientY; touchStartX = e.touches[0].clientX; isSwiping = false;
  }, { passive: true });

  container.addEventListener('touchmove', e => {
    if (!document.getElementById('reelsPage')?.classList.contains('active')) return;
    const dy = e.touches[0].clientY - touchStartY;
    const dx = e.touches[0].clientX - touchStartX;
    if (!isSwiping && (Math.abs(dy) > 8 || Math.abs(dx) > 8)) {
      isSwiping = true;
      const v = tropCurrentReelVideo();
      if (v && !v.paused) v.pause();
    }
    if (!isSwiping) return;
    if (Math.abs(dy) > Math.abs(dx)) {
      const h = container.offsetHeight || 1;
      container.querySelectorAll('.reel-slide').forEach((slide, i) => {
        slide.style.transition = 'none';
        slide.style.transform = `translateY(${(i - currentReelIndex) * 100 + (dy / h) * 100}%)`;
      });
    }
  }, { passive: true });

  container.addEventListener('touchend', e => {
    if (!document.getElementById('reelsPage')?.classList.contains('active')) return;
    const dy = e.changedTouches[0].clientY - touchStartY;
    const dx = e.changedTouches[0].clientX - touchStartX;
    const wasSwiping = isSwiping; isSwiping = false;
    if (!wasSwiping) return;
    lastSwipeEnd = Date.now();
    const th = 40;
    if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 30) { tropApplyReelTransforms(true); setTimeout(tropSyncReelPlayback, 360); return; }
    if (dy < -th && currentReelIndex < reelsData.length - 1) currentReelIndex++;
    else if (dy > th && currentReelIndex > 0) currentReelIndex--;
    tropApplyReelTransforms(true);
    setTimeout(tropSyncReelPlayback, 360);
  }, { passive: true });

  container.addEventListener('click', e => {
    if (!document.getElementById('reelsPage')?.classList.contains('active')) return;
    if (Date.now() - lastSwipeEnd < 400) return;
    const slide = e.target.closest('.reel-slide'); if (!slide) return;
    if (e.target.closest('.reel-actions, .reel-user, .reel-play-btn')) return;
    const v = slide.querySelector('video'); if (!v) return;
    const btn = slide.querySelector('.reel-play-btn');
    if (v.paused) { v.play().catch(()=>{}); btn?.classList.remove('show'); }
    else { v.pause(); btn?.classList.add('show'); }
  });
}

// ============================================================
// PLAYBACK
// ============================================================
let tropActiveAudioVideo = null;

function tropCurrentReelVideo() {
  if (!document.getElementById('reelsPage')?.classList.contains('active')) return null;
  const slides = document.querySelectorAll('#reelsPage .reel-slide');
  return slides[currentReelIndex]?.querySelector('video') || null;
}
function tropFreezeVideo(v) {
  if (!v || !(v instanceof HTMLVideoElement)) return;
  try { v.pause(); } catch(e){}
  try { v.muted = true; v.volume = 0; } catch(e){}
  if (tropActiveAudioVideo === v) tropActiveAudioVideo = null;
}
function tropFreezeAllVideos(except) {
  document.querySelectorAll('video').forEach(v => { if (v !== except) tropFreezeVideo(v); });
}
function tropPlayVideo(v) {
  if (!v || !(v instanceof HTMLVideoElement)) return;
  const onReels = !!v.closest('#reelsPage') && document.getElementById('reelsPage')?.classList.contains('active');
  const onHome = !!v.closest('#homePage') && document.getElementById('homePage')?.classList.contains('active');
  if (!onReels && !onHome) { tropFreezeVideo(v); return; }
  if (onReels && v !== tropCurrentReelVideo()) { tropFreezeVideo(v); return; }
  tropFreezeAllVideos(v);
  tropActiveAudioVideo = v;
  try {
    v.muted = false; v.volume = 1;
    const p = v.play();
    if (p && p.catch) p.catch(() => { v.muted = true; v.play().catch(()=>{}); });
  } catch(e){}
}

function tropSyncReelPlayback() {
  if (!document.getElementById('reelsPage')?.classList.contains('active')) return;
  const slides = document.querySelectorAll('#reelsPage .reel-slide');
  if (!slides.length) return;
  if (currentReelIndex >= slides.length) currentReelIndex = slides.length - 1;
  slides.forEach((slide, i) => {
    const v = slide.querySelector('video'); if (!v) return;
    if (i === currentReelIndex) tropPlayVideo(v);
    else tropFreezeVideo(v);
  });
}

// ============================================================
// LIKE
// ============================================================
async function toggleReelLike(el, index) {
  const reel = reelsData[index];
  if (!reel) return;
  const uid = window.firebaseCurrentUserUid || sessionId;
  if (!Array.isArray(reel.likedBy)) reel.likedBy = [];
  const liked = reel.likedBy.includes(uid);
  if (liked) {
    reel.likedBy = reel.likedBy.filter(x => x !== uid);
    reel.likes = Math.max(0, Number(reel.likes||1) - 1);
    el.classList.remove('liked');
  } else {
    reel.likedBy.push(uid);
    reel.likes = Number(reel.likes||0) + 1;
    el.classList.add('liked');
  }
  const slide = document.querySelectorAll('#reelsPage .reel-slide')[index];
  if (slide) {
    slide.dataset.likes = reel.likes;
    const countEl = slide.querySelector('.reel-count');
    if (countEl) countEl.textContent = reel.likes.toLocaleString('en-IN');
  }
  syncHomeFeedCounts(reel);
  try { if (reel.docId) await window.tropSaveReel(reel); }
  catch(e) { console.error('Like save failed:', e); }
}

function syncHomeFeedCounts(reel) {
  const idx = reelsData.indexOf(reel);
  if (idx < 0) return;
  document.querySelectorAll(`#homeFeed .post[data-reel-index="${idx}"]`).forEach(post => {
    const bar = post.querySelector('.home-action-bar');
    if (!bar) return;
    bar.querySelectorAll('span').forEach(sp => {
      if (sp.textContent.startsWith('❤️')) sp.textContent = '❤️ ' + (reel.likes||0);
      else if (sp.textContent.startsWith('💬')) sp.textContent = '💬 ' + (reel.comments||[]).length;
      else if (sp.textContent.startsWith('↗️')) sp.textContent = '↗️ ' + (reel.shares||0);
      else if (sp.textContent.startsWith('👁️')) sp.textContent = '👁️ ' + (reel.views||0);
    });
  });
}

// ============================================================
// SAVE
// ============================================================
async function toggleReelSave(el, index) {
  const reel = reelsData[index];
  if (!reel) return;
  const uid = window.firebaseCurrentUserUid || sessionId;
  if (!Array.isArray(reel.savedBy)) reel.savedBy = [];
  const saved = reel.savedBy.includes(uid);
  if (saved) {
    reel.savedBy = reel.savedBy.filter(x => x !== uid);
    ownProfile.savedVideos = (ownProfile.savedVideos||[]).filter(v => v !== reel.videoUrl);
    el.classList.remove('saved');
    el.querySelector('polygon').setAttribute('fill','none');
    showToast('Video unsaved');
  } else {
    reel.savedBy.push(uid);
    if (!ownProfile.savedVideos.includes(reel.videoUrl)) ownProfile.savedVideos.push(reel.videoUrl);
    el.classList.add('saved');
    el.querySelector('polygon').setAttribute('fill','#f5f5f5');
    showToast('Video saved! 💾');
  }
  const slide = document.querySelectorAll('#reelsPage .reel-slide')[index];
  if (slide) {
    slide.dataset.saved = !saved ? 'true' : 'false';
    slide.dataset.saves = reel.savedBy.length;
    const el2 = slide.querySelector('.reel-save-count');
    if (el2) el2.textContent = reel.savedBy.length;
  }
  try {
    if (reel.docId) await window.tropSaveReel(reel);
    if (window.tropSaveProfile) await window.tropSaveProfile(ownProfile);
  } catch(e) { console.error('Save failed:', e); }
}

// ============================================================
// SHARE
// ============================================================
async function shareReel(index) {
  if (shareLock) return;
  const reel = reelsData[index];
  if (!reel) return;
  shareLock = true;
  let shared = false;
  try {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'TROP', text: reel.caption || 'Check this on TROP', url: reel.videoUrl });
        shared = true;
      } catch(err) {
        if (err && err.name === 'AbortError') { shareLock = false; return; }
        throw err;
      }
    } else if (navigator.clipboard) {
      await navigator.clipboard.writeText(reel.videoUrl);
      shared = true;
      showToast('Link copied!');
    }
  } catch(e) { console.error('Share failed:', e); }
  if (shared) {
    const uid = window.firebaseCurrentUserUid || sessionId;
    if (!Array.isArray(reel.sharedBy)) reel.sharedBy = [];
    if (!reel.sharedBy.includes(uid)) {
      reel.sharedBy.push(uid);
      reel.shares = reel.sharedBy.length;
      const slide = document.querySelectorAll('#reelsPage .reel-slide')[index];
      if (slide) {
        slide.dataset.shares = reel.shares;
        const el = slide.querySelector('.reel-share-count');
        if (el) el.textContent = reel.shares;
      }
      syncHomeFeedCounts(reel);
      try { if (reel.docId) await window.tropSaveReel(reel); } catch(e) { console.error('Share save failed:', e); }
    }
  }
  setTimeout(() => { shareLock = false; }, 800);
}

// ============================================================
// COMMENTS
// ============================================================
function openReelComment(index) {
  currentReelCommentIndex = index;
  const reel = reelsData[index];
  if (!reel) return;
  if (!Array.isArray(reel.comments)) reel.comments = [];
  document.getElementById('reelCommentTitle').textContent = `Comments (${reel.comments.length})`;
  const list = document.getElementById('reelCommentList');
  list.innerHTML = '';
  if (reel.comments.length === 0) list.innerHTML = '<div style="padding:20px;text-align:center;color:#a8a8a8;">No comments yet</div>';
  const myUid = window.firebaseCurrentUserUid || sessionId;
  reel.comments.forEach((c, i) => {
    const div = document.createElement('div');
    div.className = 'reel-comment-item';
    const owner = allUsers.find(u => u.username === c.user);
    const pic = owner ? (owner.pic || DEFAULT_AVATAR) : (c.user === ownProfile.username ? ownProfile.pic : DEFAULT_AVATAR);
    const canDelete = c.user === ownProfile.username || reel.ownerUid === myUid;
    div.innerHTML = `<img src="${pic}"><div class="comment-body"><div class="comment-user">${c.user}${verifiedTickHTML(c.user,'small')}</div><div class="comment-text">${escapeHTML(c.text||'')}</div></div>${canDelete ? `<button class="comment-delete" onclick="deleteReelComment(${index},${i})">🗑</button>` : ''}`;
    list.appendChild(div);
  });
  document.getElementById('reelCommentInput').value = '';
  document.getElementById('reelCommentOverlay').classList.add('active');
  setTimeout(() => document.getElementById('reelCommentInput').focus(), 100);
}

function closeReelComment() {
  document.getElementById('reelCommentOverlay').classList.remove('active');
  currentReelCommentIndex = null;
}

async function sendReelComment() {
  if (currentReelCommentIndex === null) return;
  const input = document.getElementById('reelCommentInput');
  const text = input.value.trim();
  if (!text) return;
  const reel = reelsData[currentReelCommentIndex];
  if (!reel) return;
  if (!Array.isArray(reel.comments)) reel.comments = [];
  reel.comments.push({ user: ownProfile.username, text, time: Date.now() });
  input.value = '';
  try {
    if (reel.docId) await window.tropSaveReel(reel);
    openReelComment(currentReelCommentIndex);
    updateReelCommentCountInDOM(currentReelCommentIndex, reel.comments.length);
    syncHomeFeedCounts(reel);
    showToast('Comment posted');
  } catch(e) { console.error(e); showToast('Comment failed'); }
}

async function deleteReelComment(index, commentIndex) {
  const reel = reelsData[index];
  if (!reel) return;
  if (!Array.isArray(reel.comments)) return;
  if (!confirm('Delete this comment?')) return;
  reel.comments.splice(commentIndex, 1);
  try {
    if (reel.docId) await window.tropSaveReel(reel);
    openReelComment(index);
    updateReelCommentCountInDOM(index, reel.comments.length);
    syncHomeFeedCounts(reel);
    showToast('Comment deleted');
  } catch(e) { console.error(e); showToast('Delete failed'); }
}

function updateReelCommentCountInDOM(index, count) {
  const slide = document.querySelectorAll('#reelsPage .reel-slide')[index];
  if (!slide) return;
  const counts = slide.querySelectorAll('.reel-count');
  if (counts[1]) counts[1].textContent = count;
}

// ============================================================
// MODALS
// ============================================================
function renderUserModal(title, uids) {
  document.getElementById('reelModalTitle').textContent = title;
  const list = document.getElementById('reelModalList');
  list.innerHTML = '';
  if (!uids || uids.length === 0) { list.innerHTML = '<div style="padding:20px;text-align:center;color:#a8a8a8;">None yet</div>'; return; }
  const seen = new Set();
  uids.forEach(uid => {
    if (seen.has(uid)) return; seen.add(uid);
    const u = allUsers.find(x => x.id === uid) || allUsers.find(x => x.username === uid);
    const pic = u ? (u.pic || DEFAULT_AVATAR) : DEFAULT_AVATAR;
    const name = u ? u.fullName : uid;
    const uname = u ? u.username : uid;
    const div = document.createElement('div');
    div.className = 'reel-modal-item';
    div.innerHTML = `<img src="${pic}"><div><div class="name">${name}${verifiedTickHTML(uname,'small')}</div><div class="username">@${uname}</div></div>`;
    list.appendChild(div);
  });
  document.getElementById('reelModalOverlay').classList.add('active');
}
function showReelLikers(i) { const r = reelsData[i]; if (!r) return; renderUserModal(`Liked by (${(r.likedBy||[]).length})`, r.likedBy||[]); }
function showReelShares(i) { const r = reelsData[i]; if (!r) return; renderUserModal(`Shared by (${(r.sharedBy||[]).length})`, r.sharedBy||[]); }
function showReelSaves(i) { const r = reelsData[i]; if (!r) return; renderUserModal(`Saved by (${(r.savedBy||[]).length})`, r.savedBy||[]); }
function showReelViews(i) { const r = reelsData[i]; if (!r) return; renderUserModal(`Viewed by (${(r.viewedBy||[]).length})`, r.viewedBy||[]); }
function closeReelModal() { document.getElementById('reelModalOverlay').classList.remove('active'); }
function closeReelViewModal() { document.getElementById('reelViewModalOverlay').classList.remove('active'); }

// ============================================================
// VIDEO UPLOAD
// ============================================================
function handleVideoUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (!file.type.startsWith('video/')) { showToast('Please select a video file'); event.target.value=''; return; }
  if (file.size > 200 * 1024 * 1024) { showToast('Video file too large (max 200MB)'); event.target.value=''; return; }
  pendingVideoFile = file;
  pendingVideoQuality = '720p';
  document.getElementById('videoPostDescription').value = '';
  document.getElementById('videoValidationInfo').textContent = 'Checking video...';
  document.querySelectorAll('#qualityOptions label').forEach(l => l.classList.remove('selected'));
  const defaultLabel = document.querySelector('#qualityOptions input[value="720p"]')?.parentElement;
  if (defaultLabel) { defaultLabel.classList.add('selected'); const r = defaultLabel.querySelector('input'); if (r) r.checked = true; }
  const testVid = document.createElement('video');
  testVid.preload = 'metadata';
  testVid.onloadedmetadata = () => {
    const dur = testVid.duration;
    const w = testVid.videoWidth, h = testVid.videoHeight;
    if (dur > MAX_VIDEO_DURATION_SEC) {
      document.getElementById('videoValidationInfo').innerHTML = `<span style="color:#ed4956;">❌ Video too long: ${Math.round(dur)}s (max 7 minutes)</span>`;
      showToast('Maximum video length is 7 minutes');
      pendingVideoFile = null;
      return;
    }
    document.getElementById('videoValidationInfo').innerHTML = `✅ Duration: ${Math.round(dur)}s • ${w}×${h} • ${(file.size/1024/1024).toFixed(1)} MB`;
  };
  testVid.onerror = () => {
    document.getElementById('videoValidationInfo').innerHTML = '<span style="color:#ed4956;">❌ Invalid video file</span>';
    pendingVideoFile = null;
  };
  testVid.src = URL.createObjectURL(file);
  document.querySelectorAll('#qualityOptions input').forEach(r => {
    r.onchange = () => {
      document.querySelectorAll('#qualityOptions label').forEach(l => l.classList.remove('selected'));
      r.parentElement.classList.add('selected');
      pendingVideoQuality = r.value;
    };
  });
  document.getElementById('videoPostModal').classList.add('active');
}

function cancelVideoPost() {
  pendingVideoFile = null;
  pendingVideoQuality = '720p';
  document.getElementById('videoPostDescription').value = '';
  document.getElementById('videoPostModal').classList.remove('active');
  document.getElementById('videoUploadInput').value = '';
}

async function confirmVideoPost() {
  if (!pendingVideoFile) { showToast('No video selected'); return; }
  const file = pendingVideoFile;
  const description = document.getElementById('videoPostDescription').value.trim();
  const quality = pendingVideoQuality;
  pendingVideoFile = null;
  document.getElementById('videoPostModal').classList.remove('active');
  await uploadVideoFile(file, description, quality);
  document.getElementById('videoUploadInput').value = '';
}

async function uploadVideoFile(file, description, quality) {
  const prog = document.getElementById('uploadProgress');
  const fill = document.getElementById('uploadProgressFill');
  const txt = document.getElementById('uploadProgressText');
  prog.classList.add('active'); fill.style.width = '10%'; txt.textContent = 'Preparing...';
  try {
    const uid = window.firebaseCurrentUserUid;
    if (!uid) throw new Error('AUTH_REQUIRED');
    fill.style.width = '25%'; txt.textContent = 'Creating thumbnail...';
    let thumbnail = '';
    try { thumbnail = await createVideoThumbnail(file); } catch(e){ console.warn(e); }
    fill.style.width = '35%'; txt.textContent = 'Uploading video (' + quality + ')...';
    const result = await window.tropUploadVideo(file, uid, quality);
    fill.style.width = '85%'; txt.textContent = 'Publishing...';
    const newReel = {
      user: ownProfile.username, ownerUid: uid, pic: ownProfile.pic,
      videoUrl: result.videoUrl, thumbnail, caption: description || '',
      music: '🎵 Original', quality, createdAt: Date.now(),
      likes: 0, views: 0, shares: 0, comments: [],
      likedBy: [], viewedBy: [], sharedBy: [], savedBy: []
    };
    const saved = await window.tropSaveReel(newReel);
    newReel.docId = saved.docId;
    reelsData.unshift(newReel);
    reelsData = reelsData.map((r,i)=>({...r,id:i}));
    if (!ownProfile.videos) ownProfile.videos = [];
    if (!ownProfile.videos.includes(result.videoUrl)) ownProfile.videos.push(result.videoUrl);
    if (window.tropSaveProfile) await window.tropSaveProfile(ownProfile);
    fill.style.width = '100%'; txt.textContent = 'Upload complete ✅';
    showToast('Video uploaded successfully!');
    setTimeout(() => { prog.classList.remove('active'); fill.style.width = '0%'; }, 1500);
    buildReels(); updateProfileStats(); generateHomeFeed();
  } catch (error) {
    console.error('Upload failed:', error);
    prog.classList.remove('active'); fill.style.width = '0%';
    if (error.message === 'AUTH_REQUIRED') showToast('Please login again');
    else if (error.message === 'SUPABASE_STORAGE_RLS') showToast('Storage permission blocked');
    else showToast(error.message || 'Upload failed');
  }
}

function createVideoThumbnail(file) {
  return new Promise((resolve, reject) => {
    const v = document.createElement('video');
    const url = URL.createObjectURL(file);
    let done = false;
    v.muted = true; v.playsInline = true; v.preload = 'metadata';
    v.onloadedmetadata = () => { try { v.currentTime = Math.min(0.2, v.duration / 4); } catch(e){ draw(); } };
    v.onseeked = draw;
    v.onerror = () => { if (!done) { done = true; URL.revokeObjectURL(url); reject(new Error('THUMB_FAIL')); } };
    v.src = url;
    function draw() {
      if (done) return; done = true;
      try {
        const c = document.createElement('canvas');
        const maxW = 360;
        const ratio = v.videoHeight && v.videoWidth ? v.videoHeight / v.videoWidth : 16/9;
        c.width = maxW; c.height = Math.max(160, Math.round(maxW * ratio));
        c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
        const t = c.toDataURL('image/jpeg', 0.68);
        URL.revokeObjectURL(url); resolve(t);
      } catch(e) { URL.revokeObjectURL(url); reject(e); }
    }
  });
}

function toggleReelPlay(btn) {
  const slide = btn.closest('.reel-slide');
  const v = slide?.querySelector('video');
  if (!v) return;
  if (v.paused) { v.play().catch(()=>{}); btn.classList.remove('show'); }
  else { v.pause(); btn.classList.add('show'); }
}

// ============================================================
// HOME FEED
// ============================================================
function generateHomeFeed() {
  const feed = document.getElementById('homeFeed');
  if (!feed) return;
  feed.innerHTML = '';
  if (!Array.isArray(reelsData) || reelsData.length === 0) {
    feed.innerHTML = '<div style="padding:30px;text-align:center;color:#a8a8a8;">No videos yet</div>';
    return;
  }
  const finalList = tropBuildMixedFeed(reelsData);
  finalList.forEach(reel => {
    const div = document.createElement('div');
    div.className = 'post';
    div.dataset.reelIndex = reelsData.indexOf(reel);
    const comments = (reel.comments||[]).length;
    const uid = window.firebaseCurrentUserUid || sessionId;
    const isLiked = (reel.likedBy||[]).includes(uid);
    div.innerHTML = `
      <div class="post-header">
        <img src="${reel.pic||DEFAULT_AVATAR}">
        <span class="username">${reel.user}${verifiedTickHTML(reel.user,'small')}</span>
      </div>
      <div class="post-img-container">
        <video src="${reel.videoUrl}" class="post-img home-feed-video" playsinline preload="metadata" controls style="width:100%;max-height:480px;object-fit:cover;"></video>
      </div>
      <div class="home-action-bar">
        <svg class="${isLiked?'liked':''}" onclick="homeLike(this, ${reel.id ?? reelsData.indexOf(reel)})" fill="currentColor" viewBox="0 0 24 24">
          <path d="M16.8 3.9A5 5 0 0 1 21.5 9.1c0 3.1-2.7 5-5.2 7.2-2.5 2.2-3.9 3.5-4.3 3.9-.4-.4-1.8-1.7-4.3-3.9C5.2 14.1 2.5 12.2 2.5 9.1a5 5 0 0 1 4.7-5.2 4.2 4.2 0 0 1 3.7 1.9c.8 1.2 1 1.8 1.1 1.8s.3-.6 1.1-1.8a4.2 4.2 0 0 1 3.7-1.9z"/>
        </svg>
        <span>❤️ ${reel.likes||0}</span>
        <svg onclick="homeComment(${reel.id ?? reelsData.indexOf(reel)})" fill="currentColor" viewBox="0 0 24 24">
          <path d="M20.7 17.8a1 1 0 0 1-.3.7L16.5 22.5l-1.3-1.3a1 1 0 0 1 0-1.4l3.9-3.9a1 1 0 0 1 1.4 0l1.3 1.3a1 1 0 0 1-.1 1.6z" fill="none" stroke="currentColor" stroke-width="2"/>
          <path d="M20.7 17.8a9.5 9.5 0 1 0-2.8 2.8" fill="none" stroke="currentColor" stroke-width="2"/>
        </svg>
        <span>💬 ${comments}</span>
        <svg onclick="homeShare(${reel.id ?? reelsData.indexOf(reel)})" fill="currentColor" viewBox="0 0 24 24">
          <line stroke="currentColor" stroke-width="2" x1="22" x2="9.2" y1="3" y2="10.1"/>
          <polygon fill="none" points="11.7 20.3 22 3 2 3 9.2 10.1 11.7 20.3" stroke="currentColor" stroke-width="2"/>
        </svg>
        <span>↗️ ${reel.shares||0}</span>
        <span>👁️ ${reel.views||0}</span>
      </div>
      <div class="caption"><span class="username">${reel.user}</span> ${escapeHTML(reel.caption||'')}</div>
      <div class="view-comments">${comments} comments</div>`;
    div.querySelector('.post-header img').onclick = () => openOtherProfile(reel.user);
    div.querySelector('.post-header .username').onclick = () => openOtherProfile(reel.user);
    div.querySelector('.post-img-container').onclick = (e) => {
      if (e.target.tagName === 'VIDEO') return;
      const idx = reelsData.indexOf(reel);
      if (idx > -1) { goToPage('reels'); setTimeout(() => { currentReelIndex = idx; tropApplyReelTransforms(false); setTimeout(tropSyncReelPlayback, 100); }, 100); }
    };
    feed.appendChild(div);
  });
}

function homeLike(btn, idx) {
  let reel = reelsData.find(r => r.id === idx);
  if (!reel) reel = reelsData[idx];
  if (!reel) return;
  const realIdx = reelsData.indexOf(reel);
  if (realIdx < 0) return;
  toggleReelLike(btn, realIdx);
  const homePost = btn.closest('.post');
  if (homePost) {
    const likedNow = reel.likedBy && reel.likedBy.includes(window.firebaseCurrentUserUid || sessionId);
    btn.classList.toggle('liked', !!likedNow);
    syncHomeFeedCounts(reel);
  }
}

function homeComment(idx) {
  let reel = reelsData.find(r => r.id === idx);
  if (!reel) reel = reelsData[idx];
  if (!reel) return;
  const realIdx = reelsData.indexOf(reel);
  if (realIdx < 0) return;
  openReelComment(realIdx);
}

function homeShare(idx) {
  let reel = reelsData.find(r => r.id === idx);
  if (!reel) reel = reelsData[idx];
  if (!reel) return;
  const realIdx = reelsData.indexOf(reel);
  if (realIdx < 0) return;
  shareReel(realIdx);
}

// ============================================================
// PROFILE
// ============================================================
function updateOwnProfileUI() {
  const nameEl = document.getElementById('ownFullName');
  if (nameEl) nameEl.innerHTML = (ownProfile.fullName||'') + verifiedTickHTML(ownProfile.username, 'big');
  const bioEl = document.getElementById('ownBio');
  if (bioEl) bioEl.innerHTML = (ownProfile.bio||'').replace(/\n/g, '<br>');
  const pic = ownProfile.pic || DEFAULT_AVATAR;
  ['ownProfilePic', 'navProfilePic', 'storyOwnPic', 'storyViewerPic'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.src = pic;
  });
}

function updateProfileStats() {
  const pc = document.getElementById('ownPostCount');
  if (pc) pc.textContent = (ownProfile.videos||[]).length;
  const followers = Array.isArray(ownProfile.followersUsers) ? ownProfile.followersUsers.length : Number(ownProfile.followers||0);
  const following = Array.isArray(ownProfile.followingUsers) ? ownProfile.followingUsers.length : Number(ownProfile.following||0);
  ownProfile.followers = followers; ownProfile.following = following;
  const fc = document.getElementById('ownFollowerCount');
  if (fc) fc.textContent = followers;
  const fg = document.getElementById('ownFollowingCount');
  if (fg) fg.textContent = following;
  const grid = document.getElementById('profileGrid');
  if (!grid) return;
  grid.innerHTML = '';
  if (ownProfile.videos && ownProfile.videos.length > 0) {
    ownProfile.videos.forEach(video => {
      const div = document.createElement('div');
      div.className = 'profile-video-item';
      const reel = reelsData.find(r => r.videoUrl === video);
      const btn = document.createElement('button');
      btn.className = 'profile-video-delete'; btn.textContent = '🗑';
      btn.onclick = async (ev) => {
        ev.stopPropagation();
        if (!confirm('Delete this video?')) return;
        try {
          await window.tropDeleteOwnVideo(window.firebaseCurrentUserUid, video, reel?.docId);
          ownProfile.videos = ownProfile.videos.filter(v => v !== video);
          reelsData = reelsData.filter(r => r.videoUrl !== video);
          updateProfileStats(); buildReels(); generateHomeFeed();
          showToast('Video deleted');
        } catch(e) { console.error(e); showToast('Delete failed'); }
      };
      div.appendChild(btn);
      const media = document.createElement('div');
      if (reel && reel.thumbnail) media.innerHTML = `<img src="${reel.thumbnail}">`;
      else media.innerHTML = `<video src="${video}" muted playsinline preload="metadata"></video>`;
      div.appendChild(media.firstChild);
      const stats = document.createElement('div');
      stats.className = 'video-stats-overlay';
      stats.innerHTML = `<span>❤️ ${reel?reel.likes:0}</span><span>💬 ${reel&&reel.comments?reel.comments.length:0}</span><span>👁️ ${reel?reel.views:0}</span><span>↗️ ${reel?reel.shares:0}</span>`;
      div.appendChild(stats);
      div.onclick = () => openReelFromIndex(reel);
      grid.appendChild(div);
    });
  } else {
    grid.innerHTML = '<div style="grid-column:1/-1;padding:40px;text-align:center;color:#a8a8a8;">No videos yet. Upload your first video!</div>';
  }
}

async function ensureOwnReelsPersisted() {
  if (!window.firebaseCurrentUserUid) return;
  for (const url of (ownProfile.videos || [])) {
    if (!reelsData.some(r => r.videoUrl === url)) {
      const reel = { user: ownProfile.username, ownerUid: window.firebaseCurrentUserUid,
        pic: ownProfile.pic, videoUrl: url, thumbnail: '', caption: 'My video',
        music: '🎵 Original', createdAt: Date.now(),
        likes:0, views:0, shares:0, comments:[], likedBy:[], viewedBy:[], sharedBy:[], savedBy:[] };
      const saved = await window.tropSaveReel(reel);
      reel.docId = saved.docId;
      reelsData.push(reel);
    }
  }
}

async function tropBootRefreshFeeds() {
  try {
    const serverReels = await window.tropLoadReels();
    reelsData = serverReels.map((r, i) => ({ ...r, id: i }));
    if (typeof ensureOwnReelsPersisted === 'function') await ensureOwnReelsPersisted();
    prepareReelFeed();
    buildReels();
    generateHomeFeed();
  } catch (e) { console.error('Boot refresh failed:', e); }
}

async function tropRefreshAllData() {
  const uid = window.firebaseCurrentUserUid;
  if (!uid || !window.tropGetProfile) return;
  try {
    const fresh = await window.tropGetProfile(uid);
    if (fresh) {
      ownProfile.username = fresh.username || ownProfile.username;
      ownProfile.fullName = fresh.fullName || ownProfile.fullName;
      ownProfile.pic = fresh.pic || DEFAULT_AVATAR;
      ownProfile.bio = fresh.bio || '';
      ownProfile.videos = Array.isArray(fresh.videos) ? fresh.videos : [];
      ownProfile.savedVideos = Array.isArray(fresh.savedVideos) ? fresh.savedVideos : [];
      ownProfile.followingUsers = Array.isArray(fresh.followingUsers) ? fresh.followingUsers : [];
      ownProfile.followersUsers = Array.isArray(fresh.followersUsers) ? fresh.followersUsers : [];
      ownProfile.blockedUsers = Array.isArray(fresh.blockedUsers) ? fresh.blockedUsers : [];
      ownProfile.verified = fresh.verified === true;
      ownProfile.followers = ownProfile.followersUsers.length;
      ownProfile.following = ownProfile.followingUsers.length;
      storyData[0].pic = ownProfile.pic;
      storyData[0].user = ownProfile.fullName;
      storyData[0].images = (fresh.story && Number(fresh.story.expiresAt || 0) > Date.now()) ? (fresh.story.items || []) : [];
    }
    allUsers = await window.tropLoadUsers();
    allUsers = allUsers.map(u => ({ ...u, isFollowing: (ownProfile.followingUsers||[]).includes(u.id), isOwn: u.id === uid }));
    await tropBootRefreshFeeds();
    updateOwnProfileUI(); updateProfileStats();
  } catch(e) { console.error('Refresh failed:', e); }
}

function refreshHome() { tropBootRefreshFeeds().then(() => showToast('Feed refreshed')); }
function refreshReels() { prepareReelFeed(); buildReels(); setTimeout(() => { tropApplyReelTransforms(false); tropSyncReelPlayback(); }, 30); showToast('Reels refreshed'); }
function refreshProfile() { tropRefreshAllData().then(() => showToast('Profile refreshed')); }

// ============================================================
// EDIT PROFILE
// ============================================================
function openEditProfile() {
  document.getElementById('editUsername').value = ownProfile.username;
  document.getElementById('editFullName').value = ownProfile.fullName;
  document.getElementById('editBio').value = ownProfile.bio;
  document.getElementById('editProfilePic').src = ownProfile.pic || DEFAULT_AVATAR;
  document.getElementById('editProfilePage').classList.add('active');
}
function closeEditProfile() { document.getElementById('editProfilePage').classList.remove('active'); }

function handleFileUpload(event) {
  const file = event.target.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const img = new Image();
    img.onload = () => {
      const size = 400;
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = size;
      const ctx = canvas.getContext('2d');
      const scale = Math.max(size / img.width, size / img.height);
      const w = img.width * scale, h = img.height * scale;
      ctx.drawImage(img, (size-w)/2, (size-h)/2, w, h);
      document.getElementById('editProfilePic').src = canvas.toDataURL('image/jpeg', 0.75);
      showToast('Photo selected — press Done to save');
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
  event.target.value = '';
}

async function saveProfile() {
  const newUsername = document.getElementById('editUsername').value.trim().toLowerCase();
  const newFullName = document.getElementById('editFullName').value.trim();
  const newBio = document.getElementById('editBio').value.trim();
  const newPic = document.getElementById('editProfilePic').src;
  if (!newUsername || !newFullName) return showToast('Username and Name required');
  if (newUsername.length < 5) return showToast('Username must be 5+ chars');
  if (newUsername !== ownProfile.username) {
    const exists = allUsers.find(u => u.username === newUsername && u.id !== window.firebaseCurrentUserUid);
    if (exists) return showToast('Username already taken');
  }
  const oldUsername = ownProfile.username;
  ownProfile.username = newUsername;
  ownProfile.fullName = newFullName;
  ownProfile.bio = newBio;
  ownProfile.pic = newPic;
  try {
    await window.tropSaveProfile(ownProfile);
    for (const reel of reelsData) {
      if (reel.ownerUid === window.firebaseCurrentUserUid || reel.user === oldUsername) {
        reel.user = newUsername; reel.pic = newPic;
        if (reel.docId) await window.tropSaveReel(reel);
      }
    }
    const me = allUsers.find(u => u.id === window.firebaseCurrentUserUid);
    if (me) { me.username = newUsername; me.fullName = newFullName; me.bio = newBio; me.pic = newPic; }
    updateOwnProfileUI(); updateProfileStats();
    closeEditProfile(); buildReels(); generateHomeFeed();
    showToast('Profile updated ✓');
  } catch (e) { console.error(e); showToast('Save failed'); }
}

// ============================================================
// SETTINGS
// ============================================================
function openSettings() {
  renderSettingsContent();
  document.getElementById('settingsPanel').classList.add('active');
  document.getElementById('settingsOverlay').classList.add('active');
}
function closeSettings() {
  document.getElementById('settingsPanel').classList.remove('active');
  document.getElementById('settingsOverlay').classList.remove('active');
  const c = document.getElementById('savedVideosContainer');
  if (c) c.style.display = 'none';
}

function renderSettingsContent() {
  const el = document.getElementById('settingsContent');
  if (!el) return;
  el.innerHTML = `
    <div class="settings-group">Account</div>
    <div class="setting-item" onclick="openAccountSettings()">
      <div class="setting-icon">⚙️</div>
      <div class="setting-text"><div class="setting-label">Account & Security</div><div class="setting-desc">Password & login settings</div></div>
      <div class="setting-arrow">›</div>
    </div>
    <div class="setting-item" onclick="openMonetize()">
      <div class="setting-icon">💰</div>
      <div class="setting-text"><div class="setting-label">Monetization</div><div class="setting-desc">Creator Program & earnings</div></div>
      <div class="setting-arrow">›</div>
    </div>
    <div class="settings-group">Verification</div>
    <div class="setting-item" onclick="showToast('Red Tick — Coming Soon')">
      <div class="setting-icon"><div class="tick-preview"></div></div>
      <div class="setting-text"><div class="setting-label">Red Tick Verification</div><div class="setting-desc">Get verified badge on your profile</div></div>
      <span class="coming-soon-badge">Coming Soon</span>
    </div>
    <div class="settings-group">Preferences</div>
    <div class="setting-item" onclick="requestNotificationPermission()">
      <div class="setting-icon">🔔</div>
      <div class="setting-text"><div class="setting-label">Notifications</div><div class="setting-desc">Allow push notifications</div></div>
      <div class="setting-arrow">›</div>
    </div>
    <div class="setting-item" onclick="toggleSavedVideos()">
      <div class="setting-icon">💾</div>
      <div class="setting-text"><div class="setting-label">Saved Videos</div><div class="setting-desc">Videos you saved</div></div>
      <div class="setting-arrow">›</div>
    </div>
    <div id="savedVideosContainer" style="display:none;padding:0 20px 16px;">
      <div id="savedVideosGrid" class="profile-grid"></div>
    </div>
    <div class="settings-group">Danger Zone</div>
    <div class="setting-item danger" onclick="logout()">
      <div class="setting-icon">🚪</div>
      <div class="setting-text"><div class="setting-label">Logout</div><div class="setting-desc">Sign out from this device</div></div>
      <div class="setting-arrow">›</div>
    </div>`;
}

function toggleSavedVideos() {
  const c = document.getElementById('savedVideosContainer');
  if (!c) return;
  if (c.style.display === 'none') { c.style.display = 'block'; renderSavedVideos(); }
  else c.style.display = 'none';
}

function renderSavedVideos() {
  const grid = document.getElementById('savedVideosGrid');
  if (!grid) return;
  grid.innerHTML = '';
  const saved = ownProfile.savedVideos || [];
  if (!saved.length) { grid.innerHTML = '<div style="grid-column:1/-1;padding:20px;text-align:center;color:#a8a8a8;">No saved videos</div>'; return; }
  saved.forEach(vid => {
    const div = document.createElement('div');
    div.className = 'profile-video-item';
    div.innerHTML = `<video src="${vid}" muted playsinline preload="metadata"></video>`;
    div.onclick = () => {
      const reel = reelsData.find(r => r.videoUrl === vid);
      if (reel) { closeSettings(); openReelFromIndex(reel); }
    };
    grid.appendChild(div);
  });
}

function openAccountSettings() {
  const choice = prompt('Type "CHANGE" to change password');
  if (choice?.toLowerCase() === 'change') {
    const oldP = prompt('Current password:');
    const newP = prompt('New password (min 6):');
    if (!oldP || !newP || newP.length < 6) return showToast('Invalid');
    window.tropChangePassword(oldP, newP).then(() => showToast('Password changed')).catch(() => showToast('Change failed'));
  }
}

function requestNotificationPermission() {
  if ('Notification' in window) {
    Notification.requestPermission().then(p => {
      if (p === 'granted') { showToast('Notifications enabled'); new Notification('TROP', { body: 'You will now receive notifications' }); }
      else showToast('Permission denied');
    });
  } else showToast('Not supported');
}

function toggleNotifications() {
  const p = document.getElementById('notificationPanel');
  const o = document.getElementById('notifOverlay');
  if (p.classList.contains('active')) { p.classList.remove('active'); o.classList.remove('active'); }
  else { p.classList.add('active'); o.classList.add('active'); }
}

function forgotPassword() {
  const u = prompt('Enter your username:');
  if (!u) return;
  window.tropSendPasswordReset(u).then(() => showToast('Reset email sent')).catch(() => showToast('Username not found'));
}

// ============================================================
// MONETIZATION
// ============================================================
function openMonetize() { closeSettings(); renderMonetize(); document.getElementById('monetizePanel').classList.add('active'); }
function closeMonetize() { document.getElementById('monetizePanel').classList.remove('active'); }

function renderMonetize() {
  const el = document.getElementById('monetizeContent');
  if (!el) return;
  const followers = (ownProfile.followersUsers||[]).length;
  const videos = (ownProfile.videos||[]).length;
  let totalViews = 0;
  (ownProfile.videos||[]).forEach(url => { const r = reelsData.find(x => x.videoUrl === url); if (r) totalViews += Number(r.views||0); });
  const eligible = followers >= 1000 && totalViews >= 10000 && videos >= 5;
  const applied = localStorage.getItem('trop_mon_applied') === '1';
  const btnLabel = applied ? '✅ Application Submitted' : (eligible ? 'Apply for Monetization' : 'Complete Requirements to Apply');
  const btnDisabled = applied || !eligible ? 'disabled' : '';
  el.innerHTML = `
    <div class="monetize-hero">
      <h2>💰 TROP Creator Program</h2>
      <p>Turn your passion into income. Earn from Reels & Stories.</p>
      <div class="monetize-earnings">
        <div class="box"><div class="val">₹0</div><div class="lbl">Balance</div></div>
        <div class="box"><div class="val">₹0</div><div class="lbl">This Month</div></div>
        <div class="box"><div class="val">₹0</div><div class="lbl">Lifetime</div></div>
      </div>
    </div>
    <div class="monetize-section-title">Eligibility Progress</div>
    <div class="monetize-card">
      <div class="icon">👥</div>
      <div class="info"><div class="t">Followers</div><div class="d">${followers.toLocaleString('en-IN')} / 1,000</div>
        <div class="monetize-progress"><div class="fill" style="width:${Math.min(100, (followers/1000)*100)}%"></div></div>
      </div>
    </div>
    <div class="monetize-card">
      <div class="icon">👁️</div>
      <div class="info"><div class="t">Views (last 30 days)</div><div class="d">${totalViews.toLocaleString('en-IN')} / 10,000</div>
        <div class="monetize-progress"><div class="fill" style="width:${Math.min(100, (totalViews/10000)*100)}%"></div></div>
      </div>
    </div>
    <div class="monetize-card">
      <div class="icon">🎬</div>
      <div class="info"><div class="t">Videos Posted</div><div class="d">${videos} / 5</div>
        <div class="monetize-progress"><div class="fill" style="width:${Math.min(100, (videos/5)*100)}%"></div></div>
      </div>
    </div>
    <div class="monetize-section-title">Earning Program</div>
    <div class="monetize-card">
      <div class="icon">🎁</div>
      <div class="info"><div class="t">Reels Bonus</div><div class="d">Earn per 1,000 views</div></div>
      <div class="status ${eligible?'on':''}">${eligible?'Eligible':'Locked'}</div>
    </div>
    <button class="monetize-cta" ${btnDisabled} onclick="applyForMonetization()">${btnLabel}</button>
    <p style="font-size:11px;color:#777;text-align:center;margin-top:12px;">Payouts via UPI / Bank • Min ₹500</p>`;
}

async function applyForMonetization() {
  const uid = window.firebaseCurrentUserUid;
  if (!uid) return showToast('Please login');
  try {
    await window.tropReport('monetization', uid, ownProfile.username, 'Creator Program Application');
    localStorage.setItem('trop_mon_applied', '1');
    showToast('Application submitted 🎉');
    renderMonetize();
  } catch(e) { showToast('Failed'); }
}

// ============================================================
// USER LISTS
// ============================================================
function showUserList(kind) {
  let ids = [], title = 'Users';
  if (kind === 'followers') { ids = ownProfile.followersUsers||[]; title = 'Followers'; }
  if (kind === 'following') { ids = ownProfile.followingUsers||[]; title = 'Following'; }
  if (kind === 'otherFollowers') { ids = currentOtherUser?.followersUsers||[]; title = 'Followers'; }
  if (kind === 'otherFollowing') { ids = currentOtherUser?.followingUsers||[]; title = 'Following'; }
  const users = ids.map(id => allUsers.find(u => u.id === id)).filter(Boolean);
  document.getElementById('userListTitle').textContent = title;
  const box = document.getElementById('userListContent'); box.innerHTML = '';
  if (!users.length) box.innerHTML = '<div style="padding:30px;text-align:center;color:#aaa;">No users yet</div>';
  users.forEach(u => {
    const row = document.createElement('div');
    row.className = 'user-list-row';
    row.innerHTML = `<img src="${u.pic||DEFAULT_AVATAR}"><div><b>${u.username}${verifiedTickHTML(u.username,'small')}</b><div style="color:#aaa;font-size:12px;">${u.fullName||''}</div></div>`;
    row.onclick = () => { closeUserList(); openOtherProfile(u.username); };
    box.appendChild(row);
  });
  document.getElementById('userListModal').classList.add('active');
}
function closeUserList() { document.getElementById('userListModal').classList.remove('active'); }

// ============================================================
// STORIES
// ============================================================
function openStoryViewer() {
  document.getElementById('storyViewer').classList.add('active');
  showStory();
}
function closeStoryViewer() { document.getElementById('storyViewer').classList.remove('active'); }
function showStory() {
  const s = storyData[0];
  document.getElementById('storyViewerPic').src = s.pic || DEFAULT_AVATAR;
  document.getElementById('storyViewerName').innerHTML = (s.user||'') + verifiedTickHTML(ownProfile.username, 'small');
  if (!s.images || s.images.length === 0) {
    document.getElementById('storyViewerImage').src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 700"><rect width="400" height="700" fill="%231a1a1a"/><text x="200" y="350" font-family="sans-serif" font-size="20" fill="%23ffffff" text-anchor="middle">No Story Yet</text></svg>';
    return;
  }
  const item = s.images[storyImageIndex];
  const url = typeof item === 'string' ? item : item?.url;
  if (url) document.getElementById('storyViewerImage').src = url;
}
function nextStory() {
  const s = storyData[0];
  if (!s.images || s.images.length === 0) return closeStoryViewer();
  if (storyImageIndex < s.images.length - 1) { storyImageIndex++; showStory(); }
  else closeStoryViewer();
}
function prevStory() { if (storyImageIndex > 0) { storyImageIndex--; showStory(); } }
function chooseStoryMedia() { document.getElementById('storyMediaInput').click(); }
async function handleStoryMedia(event) {
  const file = event.target.files[0]; if (!file) return;
  const uid = window.firebaseCurrentUserUid; if (!uid) return;
  try {
    const url = await window.tropUploadStory(file, uid);
    storyData[0].images = [...(storyData[0].images||[]), { url, type: file.type.startsWith('video/') ? 'video' : 'image', createdAt: Date.now() }];
    showToast('Story added');
    showStory();
  } catch(e) { showToast('Story upload failed'); }
  event.target.value = '';
}
function deleteCurrentStory() { storyData[0].images = []; closeStoryViewer(); showToast('Story cleared'); }

// ============================================================
// UTILITIES
// ============================================================
function togglePasswordVisibility(id, btn) {
  const el = document.getElementById(id);
  if (!el) return;
  el.type = el.type === 'password' ? 'text' : 'password';
  if (btn) btn.textContent = el.type === 'password' ? '👁' : '🙈';
}

function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 2000);
}

// ============================================================
// EXPOSE to global (for inline onclick handlers)
// ============================================================
Object.assign(window, {
  showSignup, showLogin, handleSignupPic, validateSignupUser, signup, login, logout,
  goToPage, searchUsers, openOtherProfile, openReelFromIndex, toggleFollow,
  openChatFromProfile, reportCurrentUser, toggleCurrentBlock,
  loadMessagesList, markAllChatsRead, openChat, closeChat, startReply, cancelReply, sendMessage,
  registerReelViewInstant, prepareReelFeed, buildReels, tropApplyReelTransforms, tropSyncReelPlayback,
  toggleReelLike, syncHomeFeedCounts, toggleReelSave, shareReel,
  openReelComment, closeReelComment, sendReelComment, deleteReelComment,
  showReelLikers, showReelShares, showReelSaves, showReelViews, closeReelModal, closeReelViewModal,
  handleVideoUpload, cancelVideoPost, confirmVideoPost, toggleReelPlay,
  generateHomeFeed, homeLike, homeComment, homeShare,
  updateOwnProfileUI, updateProfileStats, ensureOwnReelsPersisted,
  tropBootRefreshFeeds, tropRefreshAllData, refreshHome, refreshReels, refreshProfile,
  openEditProfile, closeEditProfile, handleFileUpload, saveProfile,
  openSettings, closeSettings, toggleSavedVideos, openAccountSettings,
  requestNotificationPermission, toggleNotifications, forgotPassword,
  openMonetize, closeMonetize, applyForMonetization,
  showUserList, closeUserList,
  openStoryViewer, closeStoryViewer, nextStory, prevStory, chooseStoryMedia,
  handleStoryMedia, deleteCurrentStory,
  togglePasswordVisibility, showToast,
  loadPageFragment, preloadAllPageFragments
});

// ============================================================
// AUTH STATE LISTENER (moved here from firebase-config.js)
// ============================================================
window.tropAuthReady = new Promise((resolve) => {
  if (typeof window.tropOnAuthStateChanged !== 'function') {
    console.warn("tropOnAuthStateChanged not ready — retry in 100ms");
    setTimeout(() => resolve(false), 100);
    return;
  }
  window.tropOnAuthStateChanged(window.tropAuth, async (user) => {
    try {
      if (!user) { window.firebaseCurrentUserUid = null; resolve(false); return; }
      if (window._tropAuthFlowLock) { resolve(true); return; }
      if (document.getElementById("app")?.classList.contains("active")) {
        window.firebaseCurrentUserUid = user.uid;
        resolve(true);
        return;
      }
      const snap = await window.tropGetDoc(window.tropDoc(window.tropDb, "users", user.uid));
      if (!snap.exists()) {
        if (window._tropAuthFlowLock) { resolve(true); return; }
        await window.tropSignOut(window.tropAuth);
        resolve(false);
        return;
      }
      const profile = snap.data();
      window.firebaseCurrentUserUid = user.uid;

      ownProfile.username = profile.username || "";
      ownProfile.fullName = profile.fullName || "";
      ownProfile.pic = profile.pic || DEFAULT_AVATAR;
      ownProfile.bio = profile.bio || "";
      ownProfile.followers = profile.followers || 0;
      ownProfile.following = profile.following || 0;
      ownProfile.videos = profile.videos || [];
      ownProfile.savedVideos = profile.savedVideos || [];
      ownProfile.followingUsers = profile.followingUsers || [];
      ownProfile.followersUsers = profile.followersUsers || [];
      ownProfile.blockedUsers = profile.blockedUsers || [];
      ownProfile.verified = profile.verified === true;

      allUsers = await window.tropLoadUsers();
      allUsers = allUsers.map(u => ({ ...u, isFollowing: (profile.followingUsers || []).includes(u.id), isOwn: u.username === profile.username }));
      try { reelsData = await window.tropLoadReels(); } catch (e) { reelsData = []; }

      await ensureOwnReelsPersisted();
      await tropBootRefreshFeeds();

      storyData[0].pic = ownProfile.pic;
      storyData[0].user = ownProfile.fullName;
      storyData[0].images = (profile.story && Number(profile.story.expiresAt || 0) > Date.now()) ? (profile.story.items || []) : [];

      updateOwnProfileUI();
      updateProfileStats();

      document.getElementById("loginPage").classList.remove("active");
      document.getElementById("signupPage").classList.remove("active");
      document.getElementById("app").classList.add("active");
      const sop = document.getElementById("storyOwnPic");
      if (sop) sop.src = ownProfile.pic;
      buildReels();
      generateHomeFeed();
      startChatThreadsListener();
      console.log("TROP auto-login restored ✅");
      resolve(true);
    } catch (e) { console.error("Auto-login failed:", e); resolve(false); }
  });
});

// ============================================================
// INIT
// ============================================================
window.addEventListener('load', async () => {
  // Pages load karo pehle
  try { await preloadAllPageFragments(); } catch(e) { console.warn("Page preload failed:", e); }
  applyDefaultAvatar();
  try {
    const users = await window.tropLoadUsers();
    allUsers = users.map(u => ({ ...u, isFollowing: false, isOwn: false }));
  } catch(e) { console.error('Initial user load failed:', e); }

  setTimeout(async () => {
    if (window.tropAuthReady) await window.tropAuthReady;
    document.getElementById('splash').classList.add('hide');
    setTimeout(async () => {
      document.getElementById('splash').style.display = 'none';
      if (!window.firebaseCurrentUserUid) {
        document.getElementById('loginPage').classList.add('active');
        await tropBootRefreshFeeds();
      } else {
        await tropBootRefreshFeeds();
        tropRefreshAllData();
        startChatThreadsListener();
      }
    }, 600);
  }, 2000);
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') return;
  if (!window.firebaseCurrentUserUid) return;
  const appEl = document.getElementById('app');
  if (!appEl || !appEl.classList.contains('active')) return;
  clearTimeout(window._tropVisRefreshTimer);
  window._tropVisRefreshTimer = setTimeout(async () => {
    await tropBootRefreshFeeds();
  }, 400);
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    if (document.getElementById('settingsPanel').classList.contains('active')) closeSettings();
    if (document.getElementById('monetizePanel').classList.contains('active')) closeMonetize();
    if (document.getElementById('chatPage').classList.contains('active')) closeChat();
    if (document.getElementById('storyViewer').classList.contains('active')) closeStoryViewer();
    if (document.getElementById('editProfilePage').classList.contains('active')) closeEditProfile();
    if (document.getElementById('reelModalOverlay').classList.contains('active')) closeReelModal();
    if (document.getElementById('reelCommentOverlay').classList.contains('active')) closeReelComment();
  }
});

console.log('✅ app.js loaded — all handlers ready');