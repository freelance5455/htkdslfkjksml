/* تنظیمات سرور - تنها محل تعریف آدرس سرور.
   فعلاً سرور واقعی وجود ندارد: baseUrl = null  => همگام‌سازی غیرفعال.
   برای اتصال در آینده فقط همین فایل را تغییر دهید. */
(function (g) {
  g.RASAD_SERVER_CONFIG = {
    baseUrl: null,            // مثال آینده: "https://api.example.ir"  (فقط HTTPS پذیرفته می‌شود)
    apiPrefix: "/v1",
    timeoutMs: 15000,
    endpoints: {
      login: "/auth/login",
      refresh: "/auth/refresh",
      logout: "/auth/logout",
      push: "/sync/push",
      pull: "/sync/pull",
      health: "/health"
    },
    sync: { batchSize: 50, maxRetries: 5, conflictPolicy: "server-wins-keep-local-copy" }
  };
})(typeof globalThis !== "undefined" ? globalThis : window);
