# معماری و اتصال آیندهٔ سرور مرکزی

## اصل‌ها
- `original/index.html` هرگز تغییر نمی‌کند (هش در `original/SHA256SUMS`؛ اسکریپت ساخت پیش از شروع آن را بررسی می‌کند).
- `www/index.html` هر بار از روی فایل اصلی **تولید** می‌شود و فقط دو تغییر دارد:
  ۱) آدرس‌های CDN به `vendor/` محلی تبدیل می‌شوند (برای اجرای آفلاین)،
  ۲) ۵ تگ `<script>` لایهٔ سرور بعد از `<meta charset>` اضافه می‌شود.
- ذخیره‌سازی فعلی برنامه (localStorage / IndexedDB خودش) دست‌نخورده است. لایهٔ سرور در پایگاه جدا (`rasad_sync_db`) کار می‌کند.
- تا زمانی که `baseUrl` تنظیم نشود، وضعیت `not_configured` است و `syncNow()` هیچ موفقیتی گزارش نمی‌کند.

## لایه‌ها
| فایل | نقش |
|---|---|
| `config/server.config.js` | تنها محل آدرس سرور و مسیر endpointها (فعلاً `baseUrl: null`) |
| `src/api-service.js` | تنها محل `fetch`؛ HTTPS اجباری (به‌جز localhost برای تست)، timeout، Bearer، refresh خودکار، `Idempotency-Key`، دسته‌بندی خطا |
| `src/storage-layer.js` | UUID، زمان ISO-UTC، نمایش شمسی، صف ارسال (Outbox)، ذخیرهٔ توکن |
| `src/sync-engine.js` | ارسال دسته‌ای، دریافت تغییرات با cursor، تعارض، وضعیت‌ها |
| `src/app-bridge.js` | `window.RasadBridge` برای استفادهٔ برنامه |

## API برنامه (`window.RasadBridge`)
`recordChange(entity, 'upsert'|'delete', record)` · `syncNow()` · `onStatus(fn)` · `getStatus()` (وضعیت، تعداد در صف، آخرین همگام‌سازی) · `login/logout` · `setServerUrl(url)` · `registerEntity(name, applyFn)` · `exportBackup()/restoreBackup(json)` · `formatJalali(iso)`

وضعیت‌ها: `not_configured | offline | unauthenticated | idle | syncing | error`

## نکتهٔ مهم: اتصال فعلی برنامه به لایه
برنامهٔ اصلی هنوز `recordChange` را صدا نمی‌زند (چون فایل اصلی دست‌نخورده است). برای هر بخش (اموال، انبار، فاکتور…) در آینده باید در نقطهٔ ذخیرهٔ همان بخش یک خط `RasadBridge.recordChange(...)` اضافه شود. این تغییر کوچک و موضعی است، نه بازنویسی. همچنین برنامه از قبل کلید `SYNC_CONFIG` در localStorage دارد؛ پیش از وصل‌کردن، باید با این تنظیم موجود هماهنگ شود.

## قرارداد سرور (برای زمانی که سرور ساخته شد)
همهٔ مسیرها زیر `{baseUrl}/v1` و بدنهٔ JSON.

- `POST /auth/login` `{username,password}` → `{accessToken, refreshToken, user}`
- `POST /auth/refresh` `{refreshToken}` → `{accessToken, refreshToken?}`
- `POST /sync/push` (هدر `Idempotency-Key`)
  `{deviceId, items:[{opId, entity, op, record}]}` → `{ok, conflicts:[{entity,id,serverRecord}]}`
  سرور باید `opId` تکراری را نادیده بگیرد.
- `GET /sync/pull?since=<cursor>` → `{cursor, changes:[{entity, record}]}`
- `GET /health`

متادیتای هر رکورد: `_id` (UUID) · `_createdAt` · `_updatedAt` (ISO-UTC) · `_version` · `_deviceId` · `_deleted` (حذف نرم؛ هیچ رکوردی فیزیکی پاک نمی‌شود).

## تعارض
سیاست پیش‌فرض: نسخهٔ سرور اعمال می‌شود و نسخهٔ محلی در `records` با کلید `conflict:…` نگه‌داری می‌شود (قابل بازیابی). سیاست در `server.config.js` قابل تغییر است.

## آفلاین
ثبت‌ها در Outbox می‌مانند؛ فقط پس از تأیید سرور حذف می‌شوند. قطع اینترنت کار کاربر را متوقف نمی‌کند.

## امنیت توکن
در اندروید از `capacitor-secure-storage-plugin` (Keystore) استفاده می‌شود؛ بدون افزونه فقط در حافظه (با بستن برنامه پاک می‌شود). توکن هرگز در localStorage ذخیره نمی‌شود.
