# ساخت APK

## پیش‌نیازها (روی رایانهٔ شما)
- Node.js 18+ ، JDK 17 ، Android SDK (platform 34 + build-tools) یا Android Studio
- متغیر `ANDROID_HOME` و اینترنت (فقط برای مرحلهٔ اول)

## مراحل
```
sh scripts/setup-android.sh
```
این اسکریپت: نصب وابستگی‌ها ← دانلود کتابخانه‌های CDN و ساخت `www` ← `cap add android` ← minSdk=26 (اندروید ۸) و غیرفعال‌کردن HTTP ساده ← `cap sync` ← `assembleDebug`.
خروجی: `android/app/build/outputs/apk/debug/app-debug.apk`

## بعد از تغییر HTML اصلی
فایل جدید را در `original/index.html` بگذارید، سپس `original/SHA256SUMS` را بازسازی کنید (`cd original && sha256sum index.html > SHA256SUMS`) و `npm run android:sync` و `npm run android:debug` را اجرا کنید.

## نسخهٔ نهایی (Release)
با `keytool` یک keystore بسازید، آن را در `android/app/build.gradle` (signingConfigs) تعریف کنید و `npm run android:release` بزنید. keystore را حتماً پشتیبان بگیرید؛ بدون آن نمی‌توان برنامه را به‌روزرسانی کرد.

## آیکون
فایل `resources/icon.png` (۱۰۲۴×۱۰۲۴) را بگذارید؛ اسکریپت با `@capacitor/assets` آیکون‌ها را می‌سازد.

## محدودیت‌های شناخته‌شده
- OCR (Tesseract.js): خود کتابخانه محلی می‌شود، اما فایل‌های worker/زبان آن هنگام اولین استفاده از اینترنت دانلود می‌شوند؛ برای OCR آفلاین باید آن‌ها هم در `www/vendor` قرار گیرند.
- دانلود فایل/خروجی PDF و Excel داخل WebView اندروید ممکن است رفتار مرورگر دسکتاپ را نداشته باشد و باید روی دستگاه واقعی آزموده شود (در صورت نیاز با افزونهٔ Filesystem/Share).
- تست‌های بخش ۷ روی دستگاه (نصب، آفلاین، تصاویر، فارسی) هنوز انجام نشده‌اند.
