// آزمایش لایهٔ API و همگام‌سازی با یک سرور Mock محلی (فقط برای تست؛ سرور واقعی نیست).
// اجرا: node test/sync-mock.test.mjs
import http from "node:http";
import assert from "node:assert/strict";
import "../config/server.config.js";
import "../src/storage-layer.js";
import "../src/api-service.js";
import "../src/sync-engine.js";

const g = globalThis, S = g.RasadStorage, A = g.RasadApi, E = g.RasadSync;
const db = new Map(); const seenKeys = new Set(); let access = "tok1", pushCalls = 0, failNext = false;

const srv = http.createServer((req, res) => {
  let body = ""; req.on("data", d => body += d); req.on("end", () => {
    const send = (c, o) => { res.writeHead(c, { "Content-Type": "application/json" }); res.end(JSON.stringify(o)); };
    const u = new URL(req.url, "http://x");
    if (u.pathname === "/v1/health") return send(200, { ok: true });
    if (u.pathname === "/v1/auth/login") return send(200, { accessToken: "tok1", refreshToken: "ref1", user: { name: "t" } });
    if (u.pathname === "/v1/auth/refresh") { access = "tok2"; return send(200, { accessToken: "tok2", refreshToken: "ref1" }); }
    if (req.headers.authorization !== "Bearer " + access) return send(401, { message: "unauth" });
    if (u.pathname === "/v1/sync/push") {
      pushCalls++; if (failNext) { failNext = false; return send(500, { message: "boom" }); }
      const key = req.headers["idempotency-key"]; const b = JSON.parse(body); const conflicts = [];
      for (const it of b.items) {
        const cur = db.get(it.record._id);
        if (seenKeys.has(it.opId)) continue;                       // جلوگیری از ثبت تکراری
        seenKeys.add(it.opId);
        if (cur && cur._version >= it.record._version && cur._deviceId !== it.record._deviceId) conflicts.push({ entity: it.entity, id: it.record._id, serverRecord: cur });
        else db.set(it.record._id, it.record);
      }
      return send(200, { ok: true, conflicts });
    }
    if (u.pathname === "/v1/sync/pull") return send(200, { cursor: "c" + db.size, changes: [...db.values()].map(r => ({ entity: "items", record: r })) });
    send(404, {});
  });
});
await new Promise(r => srv.listen(0, "127.0.0.1", r));
const base = "http://127.0.0.1:" + srv.address().port;

const mk = (dev) => {
  const kv = new S.KV("t_" + dev), tokens = new S.TokenStore(null), api = new A.ApiService(g.RASAD_SERVER_CONFIG, tokens);
  return { kv, tokens, api, outbox: new S.Outbox(kv), eng: null, dev };
};
const setup = (dev) => { const c = mk(dev); c.eng = new E.SyncEngine(c.api, c.kv, c.outbox, g.RASAD_SERVER_CONFIG, dev); return c; };

// 1) بدون سرور: هیچ ادعای موفقیتی نباید وجود داشته باشد
const a = setup("devA");
let r = await a.eng.syncNow();
assert.equal(r.ok, false); assert.equal(r.reason, "not_configured");
await a.eng.recordChange("items", "upsert", { name: "میلگرد", qty: 5 });
assert.equal(await a.outbox.count(), 1, "ثبت آفلاین در صف می‌ماند");
console.log("✓ بدون سرور: not_configured و داده در صف حفظ شد");

// 2) آدرس ناامن رد می‌شود
a.api.setBaseUrl("http://evil.example.com");
await assert.rejects(() => a.api.health(), e => e.kind === "insecure_url");
console.log("✓ HTTP غیرمحلی رد شد");

// 3) ورود + ارسال
a.api.setBaseUrl(base);
await a.api.login("u", "p");
r = await a.eng.syncNow(); assert.equal(r.ok, true); assert.equal(r.pushed, 1);
assert.equal(await a.outbox.count(), 0); assert.equal(db.size, 1);
console.log("✓ ورود و ارسال موفق؛ صف خالی شد");

// 4) خطای سرور: صف حذف نمی‌شود، سپس ارسال مجدد بدون تکرار
await a.eng.recordChange("items", "upsert", { name: "سیمان", qty: 2 });
failNext = true; r = await a.eng.syncNow();
assert.equal(r.ok, false); assert.equal(await a.outbox.count(), 1); assert.equal(a.eng.status, "error");
r = await a.eng.syncNow(); assert.equal(r.ok, true); assert.equal(db.size, 2);
console.log("✓ خطای سرور: داده از دست نرفت؛ تلاش مجدد موفق و بدون رکورد تکراری");

// 5) انقضای توکن و refresh خودکار
access = "tok-new-expected"; await a.eng.recordChange("items", "upsert", { name: "شن", qty: 1 });
r = await a.eng.syncNow(); assert.equal(r.ok, true);
console.log("✓ 401 → refresh خودکار → ادامه");

// 6) دستگاه دوم: دریافت تغییرات
const b = setup("devB"); b.api.setBaseUrl(base); await b.api.login("u", "p"); access = "tok1";
const got = []; b.eng.registerEntity("items", rec => got.push(rec.name));
await b.api.tokens.set("tok1", "ref1");
r = await b.eng.syncNow(); assert.equal(r.ok, true); assert.equal(got.length, 3);
console.log("✓ دستگاه دوم ۳ رکورد را دریافت کرد");

// 7) تعارض: هر دو دستگاه یک رکورد را ویرایش می‌کنند
const rec = [...db.values()][0];
await a.eng.recordChange("items", "upsert", Object.assign({}, rec, { qty: 100 }));
await b.eng.recordChange("items", "upsert", Object.assign({}, rec, { qty: 200 }));
await a.eng.syncNow(); await b.eng.syncNow();
const conflicts = (await b.kv.all("records")).filter(([k]) => k.startsWith("conflict:"));
assert.ok(conflicts.length >= 1, "نسخهٔ محلی در تعارض باید نگه‌داری شود");
console.log("✓ تعارض شناسایی شد و نسخهٔ محلی نگه‌داری شد");

// 8) تاریخ
assert.match(S.nowIso(), /Z$/); console.log("✓ زمان ثبت: ISO-UTC | نمایش شمسی:", S.toJalali("2026-11-25T12:00:00Z"));
srv.close(); console.log("\nهمهٔ آزمایش‌ها گذشت (Mock محلی؛ اتصال واقعی ادعا نمی‌شود).");
