/* لایه ذخیره‌سازی محلی: متادیتای رکورد، صف ارسال (Outbox)، ذخیره امن توکن.
   ذخیره‌سازی فعلی برنامه (localStorage/IndexedDB خودش) دست‌نخورده می‌ماند؛
   این لایه فقط در پایگاه جداگانهٔ «rasad_sync_db» کار می‌کند. */
(function (g) {
  const uuid = () => (g.crypto && g.crypto.randomUUID) ? g.crypto.randomUUID()
    : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === "x" ? r : (r & 3 | 8)).toString(16); });
  const nowIso = () => new Date().toISOString();   // ذخیرهٔ استاندارد UTC

  // نمایش شمسی؛ مقدار ذخیره‌شده همیشه ISO-UTC است
  function toJalali(iso) {
    try {
      return new Intl.DateTimeFormat("fa-IR-u-ca-persian", { year: "numeric", month: "2-digit", day: "2-digit",
        hour: "2-digit", minute: "2-digit", timeZone: "Asia/Tehran" }).format(new Date(iso));
    } catch (_) { return iso; }
  }

  // افزودن متادیتا بدون حذف فیلدهای رکورد
  function stamp(rec, deviceId) {
    const t = nowIso();
    return Object.assign({}, rec, {
      _id: rec._id || uuid(), _createdAt: rec._createdAt || t, _updatedAt: t,
      _version: (rec._version || 0) + 1, _deviceId: deviceId, _deleted: !!rec._deleted });
  }

  const STORES = ["outbox", "meta", "records"];
  class KV {
    constructor(name) { this.name = name; this.mem = {}; STORES.forEach(s => this.mem[s] = new Map()); this.db = null; }
    async _db() {
      if (this.db || typeof indexedDB === "undefined") return this.db;
      this.db = await new Promise((ok, no) => {
        const r = indexedDB.open(this.name, 1);
        r.onupgradeneeded = () => STORES.forEach(s => r.result.createObjectStore(s));
        r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error);
      });
      return this.db;
    }
    _req(store, mode, fn) {
      return this._db().then(db => new Promise((ok, no) => {
        const q = fn(db.transaction(store, mode).objectStore(store));
        q.onsuccess = () => ok(q.result); q.onerror = () => no(q.error);
      }));
    }
    async get(store, key) { return (await this._db()) ? this._req(store, "readonly", s => s.get(key)) : this.mem[store].get(key); }
    async put(store, key, val) { if (await this._db()) await this._req(store, "readwrite", s => s.put(val, key)); else this.mem[store].set(key, val); }
    async del(store, key) { if (await this._db()) await this._req(store, "readwrite", s => s.delete(key)); else this.mem[store].delete(key); }
    async all(store) {
      if (!(await this._db())) return [...this.mem[store]];
      const keys = await this._req(store, "readonly", s => s.getAllKeys());
      const vals = await this._req(store, "readonly", s => s.getAll());
      return keys.map((k, i) => [k, vals[i]]);
    }
  }

  // توکن‌ها: در اندروید از افزونهٔ ذخیرهٔ امن (Keystore)، وگرنه فقط حافظهٔ موقت. هرگز در localStorage نوشته نمی‌شود.
  class TokenStore {
    constructor(secure) { this.sec = secure || null; this.mem = {}; }
    async _g(k) { return this.sec ? this.sec.get(k) : (this.mem[k] || null); }
    async _s(k, v) { if (this.sec) await this.sec.set(k, v); else this.mem[k] = v; }
    getAccess() { return this._g("access"); }
    getRefresh() { return this._g("refresh"); }
    async set(a, r) { await this._s("access", a); await this._s("refresh", r); }
    async clear() { await this._s("access", ""); await this._s("refresh", ""); }
    persistent() { return !!this.sec; }
  }

  class Outbox {
    constructor(kv) { this.kv = kv; }
    async enqueue(entity, op, record) {   // op: upsert | delete (حذف نرم)
      const id = uuid();
      const item = { id, entity, op, record, createdAt: nowIso(), tries: 0, lastError: null };
      await this.kv.put("outbox", id, item); return item;
    }
    async list(limit) {
      const a = (await this.kv.all("outbox")).map(x => x[1]).sort((x, y) => x.createdAt < y.createdAt ? -1 : 1);
      return limit ? a.slice(0, limit) : a;
    }
    async remove(ids) { for (const i of ids) await this.kv.del("outbox", i); }
    async markFailed(ids, msg) {
      for (const i of ids) { const it = await this.kv.get("outbox", i); if (it) { it.tries++; it.lastError = msg; await this.kv.put("outbox", i, it); } }
    }
    async count() { return (await this.kv.all("outbox")).length; }
  }

  g.RasadStorage = { uuid, nowIso, toJalali, stamp, KV, TokenStore, Outbox };
})(typeof globalThis !== "undefined" ? globalThis : window);
