/* موتور همگام‌سازی. هیچ‌گاه وانمود به موفقیت نمی‌کند:
   وضعیت‌ها: not_configured | offline | unauthenticated | idle | syncing | error */
(function (g) {
  class SyncEngine {
    constructor(api, kv, outbox, config, deviceId) {
      this.api = api; this.kv = kv; this.outbox = outbox; this.cfg = config; this.deviceId = deviceId;
      this.status = "not_configured"; this.lastError = null; this.listeners = []; this.applyRemote = null;
      this.entityHandlers = {};    // entity -> async (serverRecord) => void  (اعمال تغییر سرور روی داده‌های برنامه)
    }
    onChange(fn) { this.listeners.push(fn); }
    _set(s, err) { this.status = s; this.lastError = err || null; this.listeners.forEach(f => { try { f(this.snapshot()); } catch (_) {} }); }
    registerEntity(name, applyFn) { this.entityHandlers[name] = applyFn; }
    async refreshStatus() {
      if (!this.api.isConfigured()) return this._set("not_configured");
      if (typeof navigator !== "undefined" && navigator.onLine === false) return this._set("offline");
      if (!(await this.api.tokens.getAccess())) return this._set("unauthenticated");
      if (this.status === "not_configured" || this.status === "offline" || this.status === "unauthenticated") this._set("idle");
    }
    async snapshotAsync() {
      return Object.assign(this.snapshot(), { pending: await this.outbox.count(), lastSyncIso: await this.kv.get("meta", "lastSync") });
    }
    snapshot() { return { status: this.status, error: this.lastError, deviceId: this.deviceId }; }

    // ثبت تغییر محلی در صف (حتی در حالت آفلاین یا بدون سرور)
    async recordChange(entity, op, record) {
      const stamped = g.RasadStorage.stamp(record, this.deviceId);
      await this.kv.put("records", entity + ":" + stamped._id, stamped);
      await this.outbox.enqueue(entity, op, stamped);
      return stamped;
    }

    async syncNow() {
      await this.refreshStatus();
      if (this.status === "not_configured" || this.status === "offline" || this.status === "unauthenticated")
        return { ok: false, reason: this.status };
      if (this.status === "syncing") return { ok: false, reason: "busy" };
      this._set("syncing");
      try {
        const pushed = await this._push();
        const pulled = await this._pull();
        await this.kv.put("meta", "lastSync", g.RasadStorage.nowIso());
        this._set("idle");
        return { ok: true, pushed, pulled };
      } catch (e) {
        this._set(e.kind === "unauthorized" ? "unauthenticated" : e.kind === "offline" ? "offline" : "error", e.message);
        return { ok: false, reason: e.kind || "error", message: e.message };
      }
    }

    async _push() {
      let total = 0;
      for (;;) {
        const batch = await this.outbox.list(this.cfg.sync.batchSize);
        if (!batch.length) return total;
        const ids = batch.map(b => b.id);
        const key = "batch-" + ids.join(",");            // کلید ثابت => ارسال مجدد باعث ثبت تکراری نمی‌شود
        let res;
        try {
          res = await this.api.push({ deviceId: this.deviceId, items: batch.map(b => ({ opId: b.id, entity: b.entity, op: b.op, record: b.record })) }, key);
        } catch (e) { await this.outbox.markFailed(ids, e.message); throw e; }
        const conflicts = (res && res.conflicts) || [];
        for (const c of conflicts) await this._resolveConflict(c);
        await this.outbox.remove(ids);                     // فقط پس از تأیید سرور حذف می‌شود
        total += ids.length;
      }
    }

    // سیاست پیش‌فرض: نسخهٔ سرور اعمال می‌شود، نسخهٔ محلی در «records» با برچسب conflict نگه‌داری می‌شود (چیزی از بین نمی‌رود)
    async _resolveConflict(c) {
      const local = await this.kv.get("records", c.entity + ":" + c.id);
      if (local) await this.kv.put("records", "conflict:" + c.entity + ":" + c.id + ":" + Date.now(), { local, server: c.serverRecord });
      await this._applyServer(c.entity, c.serverRecord);
    }
    async _applyServer(entity, rec) {
      await this.kv.put("records", entity + ":" + rec._id, rec);
      const h = this.entityHandlers[entity]; if (h) await h(rec);
    }
    async _pull() {
      const since = (await this.kv.get("meta", "cursor")) || "";
      const res = await this.api.pull(since);
      const changes = (res && res.changes) || [];
      for (const ch of changes) {
        const local = await this.kv.get("records", ch.entity + ":" + ch.record._id);
        if (local && (local._version || 0) > (ch.record._version || 0)) continue;   // محلی جدیدتر است
        await this._applyServer(ch.entity, ch.record);
      }
      if (res && res.cursor) await this.kv.put("meta", "cursor", res.cursor);
      return changes.length;
    }
  }
  g.RasadSync = { SyncEngine };
})(typeof globalThis !== "undefined" ? globalThis : window);
