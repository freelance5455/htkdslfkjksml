/* پل اتصال: لایه‌ها را می‌سازد و فقط یک شیء سراسری window.RasadBridge ارائه می‌دهد.
   هیچ رابط کاربری اضافه یا تغییری در برنامهٔ اصلی ایجاد نمی‌کند.
   کد برنامه در آینده می‌تواند: RasadBridge.recordChange(...) , RasadBridge.syncNow() , RasadBridge.onStatus(fn) */
(function (g) {
  const S = g.RasadStorage, A = g.RasadApi, E = g.RasadSync;
  let deviceId = null;
  try {   // شناسهٔ دستگاه موجود برنامه (در صورت وجود) حفظ می‌شود
    deviceId = g.localStorage && g.localStorage.getItem("rasad_portal_device_id_v1");
    if (!deviceId && g.localStorage) { deviceId = S.uuid(); g.localStorage.setItem("rasad_portal_device_id_v1", deviceId); }
  } catch (_) { deviceId = deviceId || S.uuid(); }

  // افزونهٔ ذخیرهٔ امن اندروید (در صورت نصب)؛ در غیر این صورت توکن فقط در حافظه می‌ماند
  const plug = g.Capacitor && g.Capacitor.Plugins && g.Capacitor.Plugins.SecureStoragePlugin;
  const secure = plug ? {
    get: async k => { try { return (await plug.get({ key: k })).value; } catch (_) { return null; } },
    set: async (k, v) => plug.set({ key: k, value: v })
  } : null;

  const kv = new S.KV("rasad_sync_db");
  const tokens = new S.TokenStore(secure);
  const api = new A.ApiService(g.RASAD_SERVER_CONFIG, tokens);
  const outbox = new S.Outbox(kv);
  const engine = new E.SyncEngine(api, kv, outbox, g.RASAD_SERVER_CONFIG, deviceId);

  g.addEventListener && g.addEventListener("online", () => engine.refreshStatus());
  g.addEventListener && g.addEventListener("offline", () => engine.refreshStatus());
  engine.refreshStatus();

  g.RasadBridge = {
    deviceId, api, engine,
    isServerConfigured: () => api.isConfigured(),
    setServerUrl: u => api.setBaseUrl(u),
    login: (u, p) => api.login(u, p),
    logout: () => api.logout(),
    recordChange: (entity, op, rec) => engine.recordChange(entity, op, rec),
    registerEntity: (name, fn) => engine.registerEntity(name, fn),
    syncNow: () => engine.syncNow(),
    onStatus: fn => engine.onChange(fn),
    getStatus: () => engine.snapshotAsync(),
    formatJalali: S.toJalali,
    // پشتیبان‌گیری از پایگاه همگام‌سازی (صف + رکوردها + تعارض‌ها)
    async exportBackup() {
      const out = { format: "rasad-sync-backup-v1", at: S.nowIso(), deviceId };
      for (const st of ["outbox", "meta", "records"]) out[st] = await kv.all(st);
      return JSON.stringify(out);
    },
    async restoreBackup(json) {
      const d = JSON.parse(json); if (d.format !== "rasad-sync-backup-v1") throw new Error("فرمت پشتیبان نامعتبر است");
      for (const st of ["outbox", "meta", "records"]) for (const [k, v] of (d[st] || [])) await kv.put(st, k, v);
    }
  };
})(typeof globalThis !== "undefined" ? globalThis : window);
