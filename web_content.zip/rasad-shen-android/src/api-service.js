/* لایه مستقل ارتباط با سرور. هیچ بخش دیگری از برنامه مستقیم fetch نمی‌زند. */
(function (g) {
  class ApiError extends Error {
    constructor(kind, message, status) { super(message); this.kind = kind; this.status = status || 0; }
  }
  // kind: not_configured | insecure_url | offline | timeout | network | unauthorized | conflict | server | client

  class ApiService {
    constructor(config, tokenStore, fetchImpl) {
      this.config = config; this.tokens = tokenStore;
      this.fetch = fetchImpl || (typeof fetch !== "undefined" ? fetch.bind(g) : null);
      this.baseUrlOverride = null;
    }
    setBaseUrl(url) { this.baseUrlOverride = url || null; }
    get baseUrl() { return this.baseUrlOverride || this.config.baseUrl; }
    isConfigured() { return !!this.baseUrl; }
    _url(path) {
      const b = this.baseUrl;
      if (!b) throw new ApiError("not_configured", "سرور تنظیم نشده است");
      const local = /^http:\/\/(localhost|127\.0\.0\.1|10\.0\.2\.2)(:\d+)?/.test(b);
      if (!/^https:\/\//.test(b) && !local) throw new ApiError("insecure_url", "فقط آدرس HTTPS مجاز است");
      return b.replace(/\/+$/, "") + this.config.apiPrefix + path;
    }
    async request(method, path, body, opts) {
      opts = opts || {};
      const url = this._url(path);
      if (typeof navigator !== "undefined" && navigator.onLine === false) throw new ApiError("offline", "اینترنت قطع است");
      const headers = { "Content-Type": "application/json", "Accept": "application/json" };
      const tok = opts.noAuth ? null : await this.tokens.getAccess();
      if (tok) headers["Authorization"] = "Bearer " + tok;
      if (opts.idempotencyKey) headers["Idempotency-Key"] = opts.idempotencyKey;
      const ctl = typeof AbortController !== "undefined" ? new AbortController() : null;
      const timer = ctl ? setTimeout(() => ctl.abort(), this.config.timeoutMs) : null;
      let res;
      try {
        res = await this.fetch(url, { method, headers, body: body == null ? undefined : JSON.stringify(body), signal: ctl && ctl.signal });
      } catch (e) {
        throw new ApiError(e && e.name === "AbortError" ? "timeout" : "network", "خطای ارتباط با سرور");
      } finally { if (timer) clearTimeout(timer); }
      let data = null; try { data = await res.json(); } catch (_) {}
      if (res.ok) return data;
      if (res.status === 401 && !opts.retried && !opts.noAuth && await this._refresh())
        return this.request(method, path, body, Object.assign({}, opts, { retried: true }));
      const kind = res.status === 401 ? "unauthorized" : res.status === 409 ? "conflict" : res.status >= 500 ? "server" : "client";
      const err = new ApiError(kind, (data && data.message) || ("HTTP " + res.status), res.status); err.data = data; throw err;
    }
    async _refresh() {
      const rt = await this.tokens.getRefresh(); if (!rt) return false;
      try {
        const r = await this.request("POST", this.config.endpoints.refresh, { refreshToken: rt }, { noAuth: true, retried: true });
        await this.tokens.set(r.accessToken, r.refreshToken || rt); return true;
      } catch (_) { await this.tokens.clear(); return false; }
    }
    async login(username, password) {
      const r = await this.request("POST", this.config.endpoints.login, { username, password }, { noAuth: true });
      await this.tokens.set(r.accessToken, r.refreshToken); return r.user || null;
    }
    async logout() { try { await this.request("POST", this.config.endpoints.logout, {}); } catch (_) {} await this.tokens.clear(); }
    health() { return this.request("GET", this.config.endpoints.health, null, { noAuth: true }); }
    push(payload, key) { return this.request("POST", this.config.endpoints.push, payload, { idempotencyKey: key }); }
    pull(since) { return this.request("GET", this.config.endpoints.pull + "?since=" + encodeURIComponent(since || ""), null); }
  }
  g.RasadApi = { ApiService, ApiError };
})(typeof globalThis !== "undefined" ? globalThis : window);
