// ساخت پوشهٔ www از فایل اصلی (original/index.html) بدون دست‌زدن به خود فایل اصلی.
// 1) کتابخانه‌های CDN (Tailwind, Chart.js, JSZip, Lucide, QRCode, فونت Vazirmatn) را دانلود و محلی می‌کند تا برنامه کاملاً آفلاین کار کند.
// 2) آدرس‌های CDN را در نسخهٔ www جایگزین می‌کند.
// 3) تنها تغییر دیگر: افزودن چند تگ <script> لایهٔ سرور در ابتدای <head>.
// اجرا (یک‌بار، با اینترنت):  node scripts/prepare-www.mjs
// بدون اینترنت و فقط برای آزمایش ساختار:  node scripts/prepare-www.mjs --no-download
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const www = path.join(root, "www");
const vendor = path.join(www, "vendor");
const noDownload = process.argv.includes("--no-download");

const verify = fs.readFileSync(path.join(root, "original/SHA256SUMS"), "utf8").split(/\s+/)[0];
let html = fs.readFileSync(path.join(root, "original/index.html"), "utf8");
if (createHash("sha256").update(html).digest("hex") !== verify) { console.error("فایل اصلی تغییر کرده است!"); process.exit(1); }

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(vendor, { recursive: true });

const LIBS = [
  { re: /https:\/\/cdn\.tailwindcss\.com(?:\/[\d.]+)?/g, file: "tailwind.js", url: "https://cdn.tailwindcss.com/3.4.17" },
  { re: /https:\/\/cdn\.jsdelivr\.net\/npm\/chart\.js@4\.4\.1\/dist\/chart\.umd\.min\.js/g, file: "chart.umd.min.js", url: "https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js" },
  { re: /https:\/\/cdn\.jsdelivr\.net\/npm\/jszip@3\.10\.1\/dist\/jszip\.min\.js/g, file: "jszip.min.js", url: "https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js" },
  { re: /https:\/\/unpkg\.com\/lucide@latest/g, file: "lucide.js", url: "https://unpkg.com/lucide@latest" },
  { re: /https:\/\/cdn\.jsdelivr\.net\/npm\/tesseract\.js@5\/dist\/tesseract\.min\.js/g, file: "tesseract.min.js", url: "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js" },
  { re: /https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/jszip\/3\.10\.1\/jszip\.min\.js/g, file: "jszip-cdnjs.min.js", url: "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js" },
  { re: /https:\/\/cdn\.jsdelivr\.net\/npm\/xlsx@0\.18\.5\/dist\/xlsx\.full\.min\.js/g, file: "xlsx.full.min.js", url: "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js" },
  { re: /https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/qrcodejs\/1\.0\.0\/qrcode\.min\.js/g, file: "qrcode.min.js", url: "https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" },
];
const FONT_RE = /https:\/\/fonts\.googleapis\.com\/css2\?family=Vazirmatn[^"'\\<> ]*/g;

async function dl(url, ua) {
  const r = await fetch(url, { headers: ua ? { "User-Agent": ua } : {} });
  if (!r.ok) throw new Error(url + " -> " + r.status);
  return r;
}

for (const L of LIBS) {
  if (!L.re.test(html)) continue; L.re.lastIndex = 0;
  if (!noDownload) fs.writeFileSync(path.join(vendor, L.file), Buffer.from(await (await dl(L.url)).arrayBuffer()));
  html = html.replace(L.re, "vendor/" + L.file);
}

if (FONT_RE.test(html)) {
  FONT_RE.lastIndex = 0;
  const cssUrl = html.match(FONT_RE)[0].replace(/&amp;/g, "&");
  let css = "/* Vazirmatn محلی */\n";
  if (!noDownload) {
    css = await (await dl(cssUrl, "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")).text();
    fs.mkdirSync(path.join(vendor, "fonts"), { recursive: true });
    let i = 0;
    for (const u of [...new Set(css.match(/https:\/\/fonts\.gstatic\.com[^)'"]+/g) || [])]) {
      const name = "v" + (i++) + ".woff2";
      fs.writeFileSync(path.join(vendor, "fonts", name), Buffer.from(await (await dl(u)).arrayBuffer()));
      css = css.split(u).join("fonts/" + name);
    }
  }
  fs.writeFileSync(path.join(vendor, "vazirmatn.css"), css);
  html = html.replace(FONT_RE, "vendor/vazirmatn.css");
}
// preconnect به سرورهای فونت دیگر لازم نیست
html = html.replace(/<link rel=(\\?")preconnect(\\?") href=(\\?")https:\/\/fonts\.g[a-z]+\.com(\\?")( crossorigin)?\s*>\s*/g, "");

// لایهٔ سرور
fs.mkdirSync(path.join(www, "layer"), { recursive: true });
const layer = ["config/server.config.js", "src/storage-layer.js", "src/api-service.js", "src/sync-engine.js", "src/app-bridge.js"];
for (const f of layer) fs.copyFileSync(path.join(root, f), path.join(www, "layer", path.basename(f)));
const tags = layer.map(f => `  <script src="layer/${path.basename(f)}"></script>\n`).join("");
html = html.replace(/<meta charset=[^>]*>/i, m => m + "\n" + tags);

fs.writeFileSync(path.join(www, "index.html"), html);

const left = [...new Set(html.match(/(?:src|href)=\\?["']https?:\/\/[^"'\\ ]+/g) || [])];
console.log("www/index.html ساخته شد.");
console.log(noDownload ? "هشدار: حالت --no-download؛ کتابخانه‌ها محلی نشده‌اند و برنامه هنوز آفلاین نیست." : "کتابخانه‌ها دانلود و محلی شدند.");
console.log("ارجاع‌های خارجی باقی‌مانده (باید فقط لینک‌های داده/تصویر باشند):", left.length ? left : "هیچ");
