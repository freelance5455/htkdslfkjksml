#!/bin/sh
# اجرا روی رایانه‌ای که JDK 17، Android SDK (API 34) و اینترنت دارد.
set -e
cd "$(dirname "$0")/.."
npm install
node scripts/prepare-www.mjs            # دانلود کتابخانه‌ها و ساخت www
[ -d android ] || npx cap add android
# حداقل اندروید 8 (API 26)
sed -i 's/minSdkVersion = .*/minSdkVersion = 26/' android/variables.gradle
# جلوگیری از ترافیک HTTP ساده
grep -q usesCleartextTraffic android/app/src/main/AndroidManifest.xml || \
  sed -i 's/<application/<application android:usesCleartextTraffic="false"/' android/app/src/main/AndroidManifest.xml
# آیکون (اختیاری): فایل resources/icon.png (1024x1024) بگذارید
[ -f resources/icon.png ] && npx @capacitor/assets generate --android || echo "resources/icon.png یافت نشد؛ آیکون پیش‌فرض می‌ماند."
npx cap sync android
cd android && ./gradlew assembleDebug
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
