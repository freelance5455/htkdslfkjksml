# رصد شن - پروژهٔ Capacitor
وضعیت: **سورس آماده؛ APK ساخته نشده** (در محیط تولید این پروژه Android SDK و اینترنت نبود).
- `original/` فایل اصلی + پشتیبان (دست‌نخورده)
- `config/ src/` لایهٔ سرور آینده
- `scripts/` ساخت www و APK
- `test/sync-mock.test.mjs` آزمایش با سرور Mock (`npm run test:mock`)
- `docs/` معماری و ساخت APK
