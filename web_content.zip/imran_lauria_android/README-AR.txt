عمران ولاوريا — حزمة مصدر لتجهيز APK

المحتويات:
- www/index.html: لعبة ويب تفاعلية؛ اختيار بطل واحد ثم قفل الاختيار حتى بدء مغامرة جديدة، عوالم أنيمي تجريبية وساحة قتال.
- capacitor.config.json و package.json: إعداد أولي لتغليف اللعبة كتطبيق Android عبر Capacitor.

مهم:
هذه الحزمة ليست APK جاهزاً؛ لا يمكن تثبيت ZIP أو HTML على أنه APK. يلزم Node.js و Android Studio و Android SDK لبناء ملف APK، ثم توقيعه قبل التوزيع.

خطوات البناء على حاسوب:
1) فك ضغط الحزمة.
2) ثبّت Node.js LTS و Android Studio مع Android SDK.
3) افتح Terminal داخل مجلد المشروع وشغّل:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
4) في Android Studio اختر Build > Build APK(s) لإنشاء APK تجريبي.
5) قبل نشره للناس، أنشئ نسخة موقعة من Build > Generate Signed Bundle / APK.

ملاحظة: لا تستخدم شخصيات أو صور أو أسماء أنيمي محمية بحقوق الملكية دون إذن. أضف شخصيات أصلية أو أصولاً مرخصة.
