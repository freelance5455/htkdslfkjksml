package com.agentplatform.app; import android.webkit.JavascriptInterface;
public class AndroidBridge { private final MainActivity a; public AndroidBridge(MainActivity a){this.a=a;} @JavascriptInterface public void openAccessibilitySettings(){a.openAccessibility();} @JavascriptInterface public String getStatus(){return "Native Android bridge connected";} }
