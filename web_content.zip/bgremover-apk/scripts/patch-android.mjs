// Applies Android-specific tweaks after `cap add/sync` (safe to run repeatedly).
import { readFileSync, writeFileSync, existsSync } from 'node:fs';

// 1) Don't compress .onnx/.wasm/.data assets (faster load, lower RAM) + enable big heap for the WebView
const gradle = 'android/app/build.gradle';
if (existsSync(gradle)) {
  let g = readFileSync(gradle, 'utf8');
  if (!g.includes('noCompress')) {
    g = g.replace(/android\s*\{/, `android {\n    aaptOptions { noCompress 'onnx', 'wasm', 'data', 'tflite', 'binarypb' }`);
    writeFileSync(gradle, g);
  }
}
const manifest = 'android/app/src/main/AndroidManifest.xml';
if (existsSync(manifest)) {
  let m = readFileSync(manifest, 'utf8');
  if (!m.includes('android:largeHeap')) m = m.replace('<application', '<application android:largeHeap="true"');
  if (!m.includes('android:hardwareAccelerated')) m = m.replace('<application', '<application android:hardwareAccelerated="true"');
  // Not needed: the app is fully offline, so drop INTERNET only if you want a "no network" app.
  // m = m.replace(/\s*<uses-permission android:name="android.permission.INTERNET" \/>/, '');
  writeFileSync(manifest, m);
}
console.log('Android patch applied.');
