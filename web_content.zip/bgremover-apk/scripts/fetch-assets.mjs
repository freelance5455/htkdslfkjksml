// Downloads everything the app used to load from the internet, so the APK works 100% offline.
// Run once on a machine with internet:  npm run assets
import { mkdir, writeFile, stat } from 'node:fs/promises';
import { dirname } from 'node:path';

const ORT = 'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.18.0/dist/';
const MP  = 'https://cdn.jsdelivr.net/npm/@mediapipe/selfie_segmentation@0.1.1675465747/';
const HF  = 'https://huggingface.co/';

const files = [
  // ONNX Runtime (WASM, single-thread) – used by both Auto/Person and Smart AI brush
  ...['ort.min.js','ort-wasm.wasm','ort-wasm-simd.wasm','ort-wasm-threaded.wasm','ort-wasm-simd-threaded.wasm']
     .map(f => [ORT + f, 'www/vendor/ort/' + f]),
  // MediaPipe selfie segmentation (fallback engine)
  ...['selfie_segmentation.js','selfie_segmentation.binarypb','selfie_segmentation.tflite',
      'selfie_segmentation_solution_packed_assets.data','selfie_segmentation_solution_packed_assets_loader.js',
      'selfie_segmentation_solution_simd_wasm_bin.js','selfie_segmentation_solution_simd_wasm_bin.wasm',
      'selfie_segmentation_solution_wasm_bin.js','selfie_segmentation_solution_wasm_bin.wasm']
     .map(f => [MP + f, 'www/vendor/mediapipe/' + f]),
  // AI models
  [HF + 'Xenova/modnet/resolve/main/onnx/model.onnx',                     'www/models/modnet.onnx'],
  [HF + 'briaai/RMBG-1.4/resolve/main/onnx/model_quantized.onnx',         'www/models/rmbg14_q.onnx'],
];

const exists = async p => { try { return (await stat(p)).size > 1000 } catch { return false } };
let failed = 0;
for (const [url, out] of files) {
  if (await exists(out)) { console.log('✓ cached ', out); continue; }
  try {
    const r = await fetch(url, { redirect: 'follow' });
    if (!r.ok) throw new Error(r.status + ' ' + r.statusText);
    await mkdir(dirname(out), { recursive: true });
    await writeFile(out, Buffer.from(await r.arrayBuffer()));
    console.log('↓ saved  ', out);
  } catch (e) { failed++; console.error('✗ FAILED ', url, '-', e.message); }
}
if (failed) { console.error(`\n${failed} file(s) failed. Re-run "npm run assets".`); process.exit(1); }
console.log('\nAll assets ready.');
