// Fails the build if any AI model / runtime file is missing -> guarantees the APK really contains them.
import { statSync } from 'node:fs';
const need = [
  ['www/models/modnet.onnx', 10e6], ['www/models/rmbg14_q.onnx', 30e6],
  ['www/vendor/ort/ort.min.js', 100e3], ['www/vendor/ort/ort-wasm-simd.wasm', 1e6], ['www/vendor/ort/ort-wasm.wasm', 1e6],
  ['www/vendor/mediapipe/selfie_segmentation.js', 1e3], ['www/vendor/mediapipe/selfie_segmentation.tflite', 1e5],
];
let bad = 0, total = 0;
for (const [f, min] of need) {
  let n = 0; try { n = statSync(f).size } catch {}
  total += n;
  if (n < min) { bad++; console.error('✗ MISSING/INCOMPLETE', f, n + ' bytes'); } else console.log('✓', f, (n / 1048576).toFixed(1) + ' MB');
}
if (bad) { console.error('\nRun "npm run assets" with internet first.'); process.exit(1); }
console.log('\nAI bundle OK: ' + (total / 1048576).toFixed(0) + ' MB will be embedded in the APK.');
