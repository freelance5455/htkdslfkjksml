import re,subprocess
s=open('src/index.original.html',encoding='utf-8').read()
import os

# ======== COMMON FIXES (apply to every WebView / APK converter) ========
def rep0(a,b):
    global s
    assert a in s,a[:70]
    s=s.replace(a,b,1)
# 1) WebViews often give picked files an EMPTY mime type -> old code silently ignored them.
rep0("function lf(fl){if(!fl||!fl.type.startsWith('image/'))return;",
     "function lf(fl){if(!fl)return;if(fl.type&&!fl.type.startsWith('image/')&&!/\\.(jpe?g|png|webp|gif|bmp|avif|heic|heif)$/i.test(fl.name||'')){$('ue').textContent=T[L].imgfail;return}")
# 2) clear message when the image cannot be decoded (instead of doing nothing)
rep0("im.onerror=()=>{$('ue').textContent=T[L].urlfail};","im.onerror=()=>{$('ue').textContent=T[L].imgfail;typeof toast==='function'&&toast(T[L].imgfail)};")
rep0("Object.assign(T.en,{qwarn:","Object.assign(T.en,{imgfail:'Cannot open this image. Try a JPG or PNG (HEIC is not supported on some phones).',anyf:'Image not showing? Choose from all files',qwarn:")
rep0("Object.assign(T.th,{qwarn:","Object.assign(T.th,{imgfail:'เปิดรูปนี้ไม่ได้ ลองใช้ไฟล์ JPG หรือ PNG (บางเครื่องไม่รองรับ HEIC)',anyf:'ไม่เห็นรูป? เลือกจากไฟล์ทั้งหมด',qwarn:")
# 3) real <input type=file> laid transparently OVER the button (a real tap = works in every WebView;
#    programmatic input.click() on a display:none input is blocked in many converter WebViews)
rep0('<input id="f" type="file" accept="image/*" hidden>','')
rep0('<button class="p big" id="pick" data-t="open">Upload Image</button>',
 '<span id="pw" style="position:relative;display:inline-block"><button class="p big" id="pick" data-t="open">Upload Image</button><input id="f" type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/bmp,image/*" aria-label="Upload" style="position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;font-size:0"></span>')
rep0('<small id="ue"></small>',
 '<small id="ue"></small><span id="aw" style="position:relative;display:inline-block;margin-top:6px"><small id="any" data-t="anyf" style="text-decoration:underline;color:var(--mut)">Image not showing? Choose from all files</small><input id="f2" type="file" aria-label="All files" style="position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;font-size:0"></span>')
rep0("$('pick').onclick=()=>$('f').click();","$('f2').onchange=e=>{lf(e.target.files[0]);e.target.value=''};$('pick').onclick=()=>{};")
# ==============================================================
# standalone build for online 'website -> APK' converters (still needs internet for the AI models)
os.makedirs('dist-webview',exist_ok=True)
open('dist-webview/index.html','w',encoding='utf-8').write(s)
def rep(a,b):
    global s
    assert a in s,a[:70]
    s=s.replace(a,b,1)
rep('<link rel="manifest" href="manifest.webmanifest">\n','')
s=re.sub(r'<script type="application/ld\+json">.*?</script>\n','',s,flags=re.S)
rep("const ORT='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.18.0/dist/',HF='https://huggingface.co/',MN=HF+'Xenova/modnet/resolve/main/onnx/model.onnx',MU=HF+'briaai/RMBG-1.4/resolve/main/onnx/model_quantized.onnx';",
    "const BASE=new URL('./',location.href).href,ORT=BASE+'vendor/ort/',MN=BASE+'models/modnet.onnx',MU=BASE+'models/rmbg14_q.onnx';")
rep("src='https://cdn.jsdelivr.net/npm/@mediapipe/selfie_segmentation@0.1.1675465747/selfie_segmentation.js'","src='vendor/mediapipe/selfie_segmentation.js'")
rep("locateFile:f=>'https://cdn.jsdelivr.net/npm/@mediapipe/selfie_segmentation@0.1.1675465747/'+f","locateFile:f=>'vendor/mediapipe/'+f")
rep("const ORT2='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.22.0/dist/',BI=HF+'BRPOD123/birefnet-lite-1024-webgpu/resolve/main/onnx/model_fp16.onnx';",
    "const ORT2=BASE+'vendor/ort/',BI=BASE+'models/birefnet_lite_fp16.onnx'; // HQ/WebGPU: desktop only, disabled on phones")
rep("const PROXY='/api/proxy';","const NATIVE=!!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform()),PROXY=NATIVE?'':'/api/proxy';")
rep("r=await fetch(t,{signal:ac.signal});clearTimeout(to);if(!r.ok){er=r.status;continue}\nconst b=await r.blob();",
    "r=NATIVE?null:await fetch(t,{signal:ac.signal});clearTimeout(to);let b;if(NATIVE)b=await nativeGet(t);else{if(!r.ok){er=r.status;continue}b=await r.blob()}\n")
rep("er=e.name||'network'}}","er=(NATIVE&&e&&e.message)||e.name||'network'}}")
rep("$('pick').onclick=()=>{};","""if(NATIVE)$('f').style.pointerEvents='none';$('pick').onclick=async()=>{
  const cap=window.Capacitor,P=cap&&cap.Plugins;
  if(NATIVE&&P&&P.Camera&&P.Camera.pickImages){
    try{
      const r=await P.Camera.pickImages({limit:1,quality:100});
      const p=r&&r.photos&&r.photos[0];
      if(p){const bl=await (await fetch(p.webPath)).blob();
        lf(new File([bl],'photo.'+(p.format||'jpg'),{type:bl.type&&bl.type.startsWith('image/')?bl.type:'image/'+(p.format==='jpg'?'jpeg':(p.format||'jpeg'))}))}
      return;
    }catch(e){if(e&&/cancel/i.test(e.message||String(e)))return;console.warn('native picker failed',e)}
  }
  $('f').style.pointerEvents='auto';$('f').click();
};""")
# models are bundled in the app: read them directly, don't duplicate ~70 MB into the browser cache
rep("cc=await caches.open('bgm');r=await cc.match(url)","if(!url.startsWith(BASE)){cc=await caches.open('bgm');r=await cc.match(url)}")
rep("t.toBlob(b=>{const a=document.createElement('a');a.download='no-bg.png';a.href=URL.createObjectURL(b);a.click()},'image/png')};","t.toBlob(b=>saveImg(b),'image/png')};")
bridge=open('scripts/bridge.html',encoding='utf-8').read()
i=s.index('<script>\n'); s=s[:i]+bridge+s[i:]
open('www/index.html','w',encoding='utf-8').write(s)
for k,m in enumerate(re.findall(r'<script>\n(.*?)</script>',s,flags=re.S)):
    open(f'/tmp/q{k}.js','w').write(m); print('script',k,'syntax rc',subprocess.run(['node','--check',f'/tmp/q{k}.js'],capture_output=True,text=True).returncode)
print('remote urls left:',re.findall(r'https?://[^\s\'"`)<]+',re.sub(r'data:[^"]+','',s)))

