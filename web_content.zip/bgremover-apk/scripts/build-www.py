import re,subprocess
s=open('src/index.original.html',encoding='utf-8').read()
def rep(a,b):
    global s
    assert a in s,a[:70]
    s=s.replace(a,b,1)
rep('<link rel="manifest" href="manifest.webmanifest">\n','')
s=re.sub(r'<script type="application/ld\+json">.*?</script>\n','',s,flags=re.S)
rep("const ORT='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.18.0/dist/',HF='https://huggingface.co/',MN=HF+'Xenova/modnet/resolve/main/onnx/model.onnx',MU=HF+'briaai/RMBG-1.4/resolve/main/onnx/model_quantized.onnx';",
    "const BASE=new URL('./',location.href).href,ORT=BASE+'vendor/ort/',MN=BASE+'models/modnet.onnx',MU=BASE+'models/rmbg14_q.onnx';")
rep("src='https://cdn.jsdelivr.net/npm/@mediapipe/selfie_segmentation@0.1.1675465747/selfie_segmentation.js'","src='vendor/mediapipe/selfie_segmentation.js'")
rep("locateFile:f=>'https://cdn.jsdelivr.net/npm/@mediapipe/selfie_segmentation@0.1.1675465747/'+f","locateFile:f=>'vendor/mediapipe/'+f")
rep("const ORT2='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.22.0/dist/',BI=HF+'BRPOD123/birefnet-lite-1024-webgpu/resolve/main/onnx/model_fp16.onnx';",
    "const ORT2=BASE+'vendor/ort/',BI=BASE+'models/birefnet_lite_fp16.onnx'; // HQ/WebGPU: desktop only, disabled on phones")
rep("const PROXY='/api/proxy';","const NATIVE=!!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform()),PROXY=NATIVE?'':'/api/proxy';")
rep("r=await fetch(t,{signal:ac.signal});clearTimeout(to);if(!r.ok){er=r.status;continue}\nconst b=await r.blob();",
    "r=NATIVE?null:await fetch(t,{signal:ac.signal});clearTimeout(to);let b;if(NATIVE)b=await nativeGet(t);else{if(!r.ok){er=r.status;continue}b=await r.blob()}\n")
rep("er=e.name||'network'}}","er=(NATIVE&&e&&e.message)||e.name||'network'}}")
rep("$('pick').onclick=()=>$('f').click();","""$('pick').onclick=async()=>{
  const cap=window.Capacitor,P=cap&&cap.Plugins;
  if(NATIVE&&P&&P.Camera&&P.Camera.pickImages){
    try{
      const r=await P.Camera.pickImages({limit:1,quality:100});
      const p=r&&r.photos&&r.photos[0];
      if(p){const bl=await (await fetch(p.webPath)).blob();
        lf(new File([bl],'photo.'+(p.format||'jpg'),{type:bl.type&&bl.type.startsWith('image/')?bl.type:'image/'+(p.format==='jpg'?'jpeg':(p.format||'jpeg'))}))}
      return;
    }catch(e){if(e&&/cancel/i.test(e.message||String(e)))return;console.warn('native picker failed',e)}
  }
  $('f').click();
};""")
rep("t.toBlob(b=>{const a=document.createElement('a');a.download='no-bg.png';a.href=URL.createObjectURL(b);a.click()},'image/png')};","t.toBlob(b=>saveImg(b),'image/png')};")
bridge=open('scripts/bridge.html',encoding='utf-8').read()
i=s.index('<script>\n'); s=s[:i]+bridge+s[i:]
open('www/index.html','w',encoding='utf-8').write(s)
for k,m in enumerate(re.findall(r'<script>\n(.*?)</script>',s,flags=re.S)):
    open(f'/tmp/q{k}.js','w').write(m); print('script',k,'syntax rc',subprocess.run(['node','--check',f'/tmp/q{k}.js'],capture_output=True,text=True).returncode)
print('remote urls left:',re.findall(r'https?://[^\s\'"`)<]+',re.sub(r'data:[^"]+','',s)))
