// EdgeOne Pages function: free, same-origin image proxy for BG Remover.
// Put this file at  edge-functions/api/proxy.js  (next to index.html). It is served at  /api/proxy
// The page calls /api/proxy?url=<image url>; the server fetches the image and returns it from your own domain.
const MAX_BYTES = 15 * 1024 * 1024; // reject images larger than 15 MB
const PRIVATE = /^(localhost|.*\.local|.*\.internal|127\..*|10\..*|192\.168\..*|169\.254\..*|172\.(1[6-9]|2\d|3[01])\..*|\[.*\]|0\.0\.0\.0)$/i;

async function handle(context) {
  const req = context.request;
  const fail = (msg, status) => new Response(msg, { status });
  if (req.method !== 'GET') return fail('method not allowed', 405);
  // Only your own pages may use this proxy (browsers send Sec-Fetch-Site; other sites get "cross-site").
  const site = req.headers.get('sec-fetch-site');
  if (site && site !== 'same-origin') return fail('forbidden', 403);

  let target;
  try { target = new URL(new URL(req.url).searchParams.get('url')); } catch (e) { return fail('bad url', 400); }
  if (!/^https?:$/.test(target.protocol) || PRIVATE.test(target.hostname)) return fail('blocked url', 400);

  let r;
  try { r = await fetch(target.href, { headers: { 'Accept': 'image/*' }, redirect: 'follow' }); }
  catch (e) { return fail('fetch failed: ' + (e && e.message || e), 502); }
  const type = r.headers.get('content-type') || '';
  if (!r.ok) return fail('upstream ' + r.status, 502);
  if (!type.startsWith('image/')) return fail('not an image', 415);
  const headers = { 'Content-Type': type, 'Cache-Control': 'public, max-age=3600' };

  // read with a hard size cap
  const reader = r.body.getReader(), chunks = []; let size = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > MAX_BYTES) { reader.cancel(); return fail('too large', 413); }
    chunks.push(value);
  }
  const out = new Uint8Array(size); let o = 0;
  for (const c of chunks) { out.set(c, o); o += c.length; }
  return new Response(out, { headers });
}

// Any unexpected error is returned as text so you can see what went wrong.
export async function onRequest(context) {
  try { return await handle(context); }
  catch (e) { return new Response('proxy error: ' + (e && e.message || e), { status: 500 }); }
}
export default onRequest;
