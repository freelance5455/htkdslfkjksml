# BG Remover → Android APK

แอปทำงาน **ออฟไลน์ 100%** (โมเดล AI + ไลบรารีถูกแพ็กไว้ในตัวแอป) และบันทึก/แชร์รูป PNG ได้จริงบนมือถือ

## วิธีที่ 1 – สร้าง APK ผ่าน GitHub (ไม่ต้องลงอะไรในเครื่อง)
1. สร้าง repo ใหม่บน GitHub แล้วอัปโหลดทั้งโฟลเดอร์นี้
2. แท็บ **Actions → Build APK → Run workflow**
3. รอ ~5–10 นาที แล้วโหลด `BGRemover-debug-apk` จาก Artifacts → แตก zip → ได้ `app-debug.apk`

## วิธีที่ 2 – สร้างในเครื่อง
ต้องมี Node 18+, JDK 17, Android SDK (หรือ Android Studio)
```
npm install
npm run assets      # โหลดโมเดล/ไลบรารีมาเก็บใน www/ (ต้องมีเน็ต ~ 100 MB ครั้งเดียว)
npx cap add android
npm run icons       # สร้างไอคอนแอป
npm run sync
cd android && ./gradlew assembleDebug
```
ไฟล์อยู่ที่ `android/app/build/outputs/apk/debug/app-debug.apk`

## ปล่อยจริง (Play Store / เซ็นชื่อ)
```
keytool -genkey -v -keystore bg.jks -alias bg -keyalg RSA -keysize 2048 -validity 10000
```
แล้วตั้งค่า signing ใน `android/app/build.gradle` และรัน `./gradlew bundleRelease`

## สิ่งที่ปรับให้ใช้บน APK ได้
| ปัญหาในเว็บเดิม | วิธีแก้ |
|---|---|
| โหลด onnxruntime / mediapipe จาก CDN | โหลดเก็บไว้ที่ `www/vendor/` แล้วอ้างอิงแบบ local |
| โหลดโมเดลจาก HuggingFace ตอนใช้งาน | แพ็กไว้ที่ `www/models/` (ใช้งานครั้งแรกไม่ต้องรอ/ไม่ต้องใช้เน็ต) |
| ปุ่มดาวน์โหลดแบบ `<a download>` ใช้ใน WebView ไม่ได้ | ใช้ Capacitor Filesystem บันทึกที่ `Documents/BGRemover/` + เปิดหน้าต่างแชร์ |
| ปุ่ม Back ปิดแอปทันที | Back = กลับหน้าเริ่มต้น, หน้าเริ่มต้น = ออกจากแอป |
| รูปใหญ่ทำ RAM เต็ม | `largeHeap` + ไม่บีบอัดไฟล์ .onnx/.wasm |
| ลบ SEO/manifest/ลิงก์ YOUR-DOMAIN | ลบออก (ไม่จำเป็นในแอป) |

หมายเหตุ: โหมด High quality (WebGPU/BiRefNet) ปิดอยู่บนมือถืออยู่แล้วตามโค้ดเดิม จึงไม่ได้แพ็กโมเดลนี้
