# BG Remover → Android APK

แอปทำงาน **ออฟไลน์ 100%** (โมเดล AI + ไลบรารีถูกแพ็กไว้ในตัวแอป) และบันทึก/แชร์รูป PNG ได้จริงบนมือถือ

## วิธีที่ 1 – สร้าง APK ผ่าน GitHub (ไม่ต้องลงอะไรในเครื่อง)
1. สร้าง repo ใหม่บน GitHub แล้วอัปโหลดทั้งโฟลเดอร์นี้
2. แท็บ **Actions → Build APK → Run workflow**
3. รอ ~5–10 นาที แล้วโหลด `BGRemover-debug-apk` จาก Artifacts → แตก zip → ได้ `app-debug.apk`

## วิธีที่ 2 – สร้างในเครื่อง
ต้องมี Node 18+, JDK 17, Android SDK (หรือ Android Studio)
```
npm install
npm run assets      # โหลดโมเดล/ไลบรารีมาเก็บใน www/ (ต้องมีเน็ต ~ 100 MB ครั้งเดียว)
npx cap add android
npm run icons       # สร้างไอคอนแอป
npm run sync
cd android && ./gradlew assembleDebug
```
ไฟล์อยู่ที่ `android/app/build/outputs/apk/debug/app-debug.apk`

## ปล่อยจริง (Play Store / เซ็นชื่อ)
```
keytool -genkey -v -keystore bg.jks -alias bg -keyalg RSA -keysize 2048 -validity 10000
```
แล้วตั้งค่า signing ใน `android/app/build.gradle` และรัน `./gradlew bundleRelease`

## สิ่งที่ปรับให้ใช้บน APK ได้
| ปัญหาในเว็บเดิม | วิธีแก้ |
|---|---|
| โหลด onnxruntime / mediapipe จาก CDN | โหลดเก็บไว้ที่ `www/vendor/` แล้วอ้างอิงแบบ local |
| โหลดโมเดลจาก HuggingFace ตอนใช้งาน | แพ็กไว้ที่ `www/models/` (ใช้งานครั้งแรกไม่ต้องรอ/ไม่ต้องใช้เน็ต) |
| ปุ่มดาวน์โหลดแบบ `<a download>` ใช้ใน WebView ไม่ได้ | ใช้ Capacitor Filesystem บันทึกที่ `Documents/BGRemover/` + เปิดหน้าต่างแชร์ |
| ปุ่ม Back ปิดแอปทันที | Back = กลับหน้าเริ่มต้น, หน้าเริ่มต้น = ออกจากแอป |
| รูปใหญ่ทำ RAM เต็ม | `largeHeap` + ไม่บีบอัดไฟล์ .onnx/.wasm |
| ลบ SEO/manifest/ลิงก์ YOUR-DOMAIN | ลบออก (ไม่จำเป็นในแอป) |

หมายเหตุ: โหมด High quality (WebGPU/BiRefNet) ปิดอยู่บนมือถืออยู่แล้วตามโค้ดเดิม จึงไม่ได้แพ็กโมเดลนี้

## เวอร์ชันเต็ม (มีช่องวางลิงก์รูป)
- `src/index.original.html` = ไฟล์ต้นฉบับของคุณ, `www/index.html` = ไฟล์ที่แพตช์แล้วสำหรับ APK
- ถ้าแก้ต้นฉบับ ให้รัน `python3 scripts/build-www.py` เพื่อสร้าง `www/index.html` ใหม่
- ปุ่ม Upload ใช้ตัวเลือกรูปของ Android (ไม่ต้องขอสิทธิ์)
- ช่อง **Load จากลิงก์**: ในแอปจะโหลดผ่าน HTTP ของระบบ (CapacitorHttp) จึงไม่ติด CORS และ **ไม่ต้องใช้ proxy**
- `edge-functions/api/proxy.js` เก็บไว้สำหรับเวอร์ชันเว็บบน EdgeOne Pages เท่านั้น (ไม่ถูกแพ็กลง APK)

## ถ้าอัปโหลดรูปไม่ได้ (แก้แล้วในเวอร์ชันนี้)
สาเหตุที่พบบ่อยใน WebView ของแอปแปลงเว็บเป็น APK:
1. `<input type=file>` ที่ซ่อนอยู่ถูกสั่ง `.click()` จากโค้ด — WebView หลายตัวบล็อก → เปลี่ยนเป็นช่องเลือกไฟล์จริงที่วางโปร่งใสทับปุ่ม (แตะแล้วเปิดตัวเลือกไฟล์โดยตรง)
2. ไฟล์ที่เลือกมี MIME type ว่าง โค้ดเดิมเลยข้ามไปเฉยๆ → ตอนนี้ลองเปิดรูปเสมอ และแจ้งข้อความเมื่อเปิดไม่ได้
3. เพิ่มลิงก์ "ไม่เห็นรูป? เลือกจากไฟล์ทั้งหมด" เป็นทางสำรอง

ไฟล์สำหรับเว็บ→APK แบบออนไลน์ (WebIntoApp ฯลฯ): `dist-webview/index.html` (ต้องมีเน็ตเพื่อโหลดโมเดล AI)
ไฟล์สำหรับ Capacitor/ออฟไลน์: `www/index.html`

## โมเดล AI ฝังในแอป
`npm run assets` โหลดโมเดล (MODNet, RMBG-1.4) + onnxruntime + MediaPipe ลง `www/` แล้ว `npm run verify` เช็คว่าครบ ก่อน build ทุกครั้ง ผลคือ APK มีโมเดลอยู่ข้างใน ใช้งานครั้งแรกได้ทันทีโดยไม่ต้องมีเน็ต (APK ใหญ่ราว 100–130 MB)
