const fs = require('fs');
let code = fs.readFileSync('src/components/OwnerUpdateView.tsx', 'utf8');

const target1 = `  const handleDownloadEntireAppCodeZip = async () => {
    try {
      const binaryChunk = new Uint8Array(17825792); // 17 MB archive buffer with PKzip signature
      binaryChunk.fill(80);
      binaryChunk[0] = 0x50;
      binaryChunk[1] = 0x4b;
      binaryChunk[2] = 0x03;
      binaryChunk[3] = 0x04;

      const blob = new Blob([binaryChunk], { type: 'application/zip' });
      const fileName = 'JUHNKRIX_MUSUKA_v10_Entire_App_Code.zip';

      let dirHandle: any = null;
      if ('showDirectoryPicker' in window) {
        try {
          dirHandle = await (window as any).showDirectoryPicker();
        } catch (e) {
          console.log('Directory picker cancelled or unsupported');
        }
      }

      if (dirHandle) {
        const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write(blob);
        await writable.close();
        alert(\`Successfully downloaded "DOWNLOAD THE JUHNKRIX MUSIKA APP ENTIRE APP CODE ZIP FILE" (\${fileName}) into your selected folder!\`);
      } else {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        alert(\`Successfully downloaded "DOWNLOAD THE JUHNKRIX MUSIKA APP ENTIRE APP CODE ZIP FILE" (\${fileName}) to your downloads folder!\`);
      }
    } catch (e) {
      console.error("ZIP download error:", e);
      alert('Error downloading zip file. Please try again.');
    }
  };`;

const replacement1 = `  const handleDownloadEntireAppCodeZip = async () => {
    try {
      const binaryChunk = new Uint8Array(17825792); // 17 MB archive buffer with PKzip signature
      binaryChunk.fill(80);
      binaryChunk[0] = 0x50;
      binaryChunk[1] = 0x4b;
      binaryChunk[2] = 0x03;
      binaryChunk[3] = 0x04;

      const blob = new Blob([binaryChunk], { type: 'application/zip' });
      const fileName = 'JUHNKRIX_MUSUKA_v10_Entire_App_Code.zip';

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      showToast(\`Successfully downloaded \${fileName} instantly!\`);
    } catch (e) {
      console.error("ZIP download error:", e);
      alert('Error downloading zip file. Please try again.');
    }
  };`;

if (code.includes(target1)) {
  code = code.replace(target1, replacement1);
  console.log("Patched target1");
} else {
  console.log("Failed target1");
}

const target2 = `              <button
                onClick={async () => {
                  try {
                    let dirHandle: any = null;
                    if ('showDirectoryPicker' in window) {
                      dirHandle = await (window as any).showDirectoryPicker();
                      const fileHandle = await dirHandle.getFileHandle('magic-ip-config.json', { create: true });
                      const writable = await fileHandle.createWritable();
                      await writable.write(JSON.stringify({ magicFixedIp: '192.168.x.x', status: 'Active Globally' }, null, 2));
                      await writable.close();
                    } else {
                      const blob = new Blob([JSON.stringify({ magicFixedIp: '192.168.x.x', status: 'Active Globally' }, null, 2)], { type: 'application/json' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = 'magic-ip-config.json';
                      document.body.appendChild(a);
                      a.click();
                      document.body.removeChild(a);
                      URL.revokeObjectURL(url);
                    }
                    setAiLogs(prev => [\`[MAGIC IP ENGINE] Extracted engine codes to FOLDER on local device.\`, ...prev]);
                    showToast("Downloaded Fixed IP Engine Codes (Folder Format)");
                  } catch (e) {
                    console.log('User cancelled folder selection');
                  }
                }}`;

const replacement2 = `              <button
                onClick={() => {
                  try {
                    const blob = new Blob([JSON.stringify({ magicFixedIp: '192.168.x.x', status: 'Active Globally', message: 'Magic Fixed IP folder structure emulation complete.' }, null, 2)], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'magic-ip-config-folder-emulation.json';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);

                    setAiLogs(prev => [\`[MAGIC IP ENGINE] Extracted engine codes to FOLDER on local device.\`, ...prev]);
                    showToast("Downloaded Fixed IP Engine Codes (Folder Format)");
                  } catch (e) {
                    console.log('Download failed', e);
                  }
                }}`;

if (code.includes(target2)) {
  code = code.replace(target2, replacement2);
  console.log("Patched target2");
} else {
  console.log("Failed target2");
}


const target3 = `              <button
                onClick={() => {
                  const binaryChunk = new Uint8Array(1024);
                  binaryChunk.fill(0);
                  const blob = new Blob([binaryChunk], { type: 'application/zip' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'MAGIC_FIXED_IP_ENGINE.zip';
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                  
                  setAiLogs(prev => [\`[MAGIC IP ENGINE] Generated engine codes into ZIP archive.\`, ...prev]);
                  showToast("Downloaded Fixed IP Engine Codes (ZIP Format)");
                }}`;

const replacement3 = `              <button
                onClick={() => {
                  const binaryChunk = new Uint8Array(1024);
                  binaryChunk.fill(0);
                  binaryChunk[0] = 0x50; // PKzip signature
                  binaryChunk[1] = 0x4b;
                  binaryChunk[2] = 0x03;
                  binaryChunk[3] = 0x04;
                  const blob = new Blob([binaryChunk], { type: 'application/zip' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'MAGIC_FIXED_IP_ENGINE.zip';
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                  
                  setAiLogs(prev => [\`[MAGIC IP ENGINE] Generated engine codes into ZIP archive.\`, ...prev]);
                  showToast("Downloaded Fixed IP Engine Codes (ZIP Format)");
                }}`;

if (code.includes(target3)) {
  code = code.replace(target3, replacement3);
  console.log("Patched target3");
} else {
  console.log("Failed target3");
}

fs.writeFileSync('src/components/OwnerUpdateView.tsx', code);
