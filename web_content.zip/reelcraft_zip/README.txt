REELCRAFT AI — APKFORGE WEBSITE ZIP

UPLOAD
1. Upload this ZIP to APKForge if it supports website ZIP files.
2. If asked, extract the ZIP and select index.html as the start page.
3. Choose HTML/Website to APK (or ZIP to APK), build, install and test.

WORKING FEATURES
- Mobile-first creator dashboard and navigation
- 15 content tools: scripts, stories, hooks, video prompts, storyboard, editing plans, captions, hashtags, titles, bios, thumbnails, logo briefs, voiceovers, content calendar and sponsorship pitch
- Hindi/English language choice and style selector
- Copy generated content
- Favorites and history stored locally on the device/browser
- Tool search

IMPORTANT LIMITATIONS
This is a functional offline starter app using templates, not a live AI service. Real AI text/image/video/voice generation needs API access and a secure backend. Login, cloud sync, subscriptions, payments, referral system and admin dashboard are not implemented. No Instagram/YouTube engagement automation is included. Before Play Store publishing, add app icon, privacy policy, signing, testing and comply with current Play Console requirements. Do not put private API keys in client-side files.
