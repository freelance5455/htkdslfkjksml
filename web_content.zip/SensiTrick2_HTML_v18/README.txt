Sensi Trick 2.0 - v18

Correção desta versão:
- Botão "🎮 Entrar no Free Fire" tenta primeiro o esquema freefire:// e depois o intent Android.
- O erro de página do WebView não é mais mostrado imediatamente pelo próprio botão.
- O restante do projeto foi mantido baseado na v16.

Importante:
Esta é uma versão HTML para usar no conversor HTML TO APK. Um overlay real por cima do Free Fire (bolinha flutuante fora do app) exige suporte nativo do APK, incluindo permissão/serviço de sobreposição; HTML sozinho não consegue conceder isso.
