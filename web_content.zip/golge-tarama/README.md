# Defineci Gölge Tarama

Uydu ekran görüntüsünde alan çizip anomalileri renk skalasında gösteren tek sayfalık uygulama.

## Çalıştırma

`index.html` dosyasına çift tıkla; tarayıcıda açılır. Kurulum ve internet bağlantısı gerekmez
(internet yoksa yazı tipi yedeğe düşer, uygulama aynen çalışır).

## Kullanım

1. Google Earth'te alanı ekrana sığdırıp ekran görüntüsü al.
2. «Görüntü yükle» ile ekle (sürükle-bırak ve yapıştırma da çalışır).
3. Serbest veya Nokta modunda alanın etrafını çiz. Sonuç otomatik çıkar.
4. Hassasiyet, Temizleme, Ayrıntı ölçeği ve Sapma türü (Tümü, Koyu, Açık) ile ayarla.
5. «Kaydedilebilir resim oluştur» ile sonucu resme çevirip kaydet.

## Not

Bu araç görüntüdeki renk ve parlaklık sapmalarını öne çıkarır. Yer altındaki metal veya boşluğu
tek başına kanıtlamaz; manyetometre, GPR gibi ölçümlerle doğrulayın.
