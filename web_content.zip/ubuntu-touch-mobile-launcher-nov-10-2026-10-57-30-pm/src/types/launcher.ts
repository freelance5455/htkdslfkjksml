export type IconShape = 'squircle' | 'circle' | 'rounded' | 'square';
export type DockPosition = 'left' | 'bottom' | 'both';
export type YaruTheme = 'classic' | 'dark' | 'light';
export type AccentColor = 'orange' | 'aubergine' | 'green' | 'blue' | 'bark';

export interface AppItem {
  id: string;
  name: string;
  category: 'System' | 'Utilities' | 'Internet' | 'Media' | 'Development' | 'Productivity';
  icon: string;
  badge?: number;
  isInstalled: boolean;
  isPinnedToDock: boolean;
  isOnHomeScreen: boolean;
  homePosition?: { page: number; row: number; col: number };
  description: string;
  color: string;
}

export interface WallpaperOption {
  id: string;
  name: string;
  thumbnail: string;
  url: string;
  type: 'image' | 'gradient';
  tag: string;
}

export interface SystemNotification {
  id: string;
  appName: string;
  appIcon: string;
  title: string;
  body: string;
  time: string;
  unread: boolean;
  accentColor?: string;
}

export interface LauncherSettings {
  wallpaperId: string;
  customWallpaperUrl?: string;
  theme: YaruTheme;
  accentColor: AccentColor;
  iconShape: IconShape;
  dockPosition: DockPosition;
  dockAutoHide: boolean;
  gridColumns: 4 | 5;
  lockScreenEnabled: boolean;
  soundEnabled: boolean;
  showResourceWidget: boolean;
  showTerminalWidget: boolean;
  iconScale: number; // 0.8 to 1.2
}
