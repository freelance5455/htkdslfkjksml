import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AppItem, IconShape } from '../types/launcher';
import { AppIcon } from './AppIcon';
import { sound } from '../utils/audio';

interface EdgeDockProps {
  isOpen: boolean;
  onToggle: () => void;
  apps: AppItem[];
  runningApps: string[];
  activeAppId: string | null;
  onOpenApp: (appId: string) => void;
  onOpenDrawer: () => void;
  iconShape: IconShape;
}

export const EdgeDock: React.FC<EdgeDockProps> = ({
  isOpen,
  onToggle,
  apps,
  runningApps,
  activeAppId,
  onOpenApp,
  onOpenDrawer,
  iconShape
}) => {
  const pinnedApps = apps.filter((a) => a.isPinnedToDock);

  return (
    <>
      {/* Edge Swipe Trigger Zone (invisible or subtle indicator on left edge) */}
      <button
        type="button"
        onClick={() => {
          sound.playTap();
          onToggle();
        }}
        aria-label="Toggle Ubuntu Launcher Dock"
        className="absolute left-0 top-12 bottom-12 w-2.5 z-30 group cursor-pointer flex items-center focus:outline-none"
      >
        <div className="w-1 h-12 bg-white/30 group-hover:bg-[#E95420] group-hover:w-1.5 transition-all rounded-r-full" />
      </button>

      {/* Dock Container */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop for closing dock */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onToggle}
              className="absolute inset-0 bg-black/40 backdrop-blur-xs z-30"
            />

            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 260 }}
              className="absolute left-0 top-0 bottom-0 w-18 z-40 bg-[#1e051b]/92 backdrop-blur-xl border-r border-white/10 shadow-2xl flex flex-col items-center py-3 select-none"
            >
              {/* Top Ubuntu Circle of Friends / Dash Trigger */}
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  onOpenDrawer();
                }}
                className="w-11 h-11 mb-3 rounded-xl bg-gradient-to-br from-[#E95420] to-[#b33300] flex items-center justify-center text-white shadow-md shadow-orange-950/40 hover:scale-105 active:scale-95 transition-transform"
                title="Ubuntu Dash & Apps"
                aria-label="Ubuntu Dash"
              >
                <svg className="w-6 h-6 fill-white" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="11" fill="none" stroke="currentColor" strokeWidth="2" opacity="0.4" />
                  <circle cx="12" cy="12" r="5" fill="white" />
                  <circle cx="5" cy="12" r="2" fill="white" />
                  <circle cx="15.5" cy="6" r="2" fill="white" />
                  <circle cx="15.5" cy="18" r="2" fill="white" />
                </svg>
              </button>

              <div className="w-8 h-[1px] bg-white/15 mb-2" />

              {/* Scrollable list of dock icons */}
              <div className="flex-1 w-full overflow-y-auto overflow-x-hidden flex flex-col items-center gap-2 px-1 py-1">
                {pinnedApps.map((app) => {
                  const isRunning = runningApps.includes(app.id);
                  const isActive = activeAppId === app.id;

                  return (
                    <div key={app.id} className="relative flex items-center justify-center">
                      {/* Ubuntu Unity / Touch Running Triangle/Pip on Left */}
                      {isRunning && (
                        <div
                          className={`absolute -left-2.5 w-1.5 h-3 rounded-r-sm transition-all ${
                            isActive ? 'bg-[#E95420] w-2' : 'bg-white/80'
                          }`}
                        />
                      )}

                      <AppIcon
                        app={app}
                        size="dock"
                        shape={iconShape}
                        showLabel={false}
                        onClick={() => {
                          sound.playLaunch();
                          onOpenApp(app.id);
                        }}
                      />
                    </div>
                  );
                })}
              </div>

              {/* Bottom Settings shortcut */}
              <div className="pt-2 border-t border-white/15 w-full flex justify-center">
                <button
                  type="button"
                  onClick={() => {
                    sound.playTap();
                    onOpenApp('settings');
                  }}
                  className="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors active:scale-95"
                  title="Launcher Settings"
                  aria-label="Settings"
                >
                  <svg className="w-5 h-5 fill-none stroke-currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="3" />
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
                  </svg>
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
