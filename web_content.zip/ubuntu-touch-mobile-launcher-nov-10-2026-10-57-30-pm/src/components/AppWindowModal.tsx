import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Minus, Square } from 'lucide-react';
import { sound } from '../utils/audio';

interface AppWindowModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

export const AppWindowModal: React.FC<AppWindowModalProps> = ({
  isOpen,
  onClose,
  title,
  icon,
  children
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ y: '100%', opacity: 0.95 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: '100%', opacity: 0.95 }}
          transition={{ type: 'spring', damping: 28, stiffness: 270 }}
          className="absolute inset-0 z-40 flex flex-col bg-[#1A0B18] shadow-2xl overflow-hidden select-none"
        >
          {/* Ubuntu App Window Title Bar */}
          <div className="h-11 px-4 bg-[#2C001E] border-b border-orange-500/20 flex items-center justify-between shrink-0">
            {/* Left: Window Controls (Ubuntu classic left or right buttons) */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  onClose();
                }}
                className="w-4 h-4 rounded-full bg-[#E95420] hover:bg-[#d03d09] flex items-center justify-center text-white/90 shadow-sm active:scale-90 transition-transform cursor-pointer"
                title="Close"
                aria-label="Close"
              >
                <X size={10} strokeWidth={3} />
              </button>
              <div className="w-3.5 h-3.5 rounded-full bg-white/20" />
              <div className="w-3.5 h-3.5 rounded-full bg-white/20" />
            </div>

            {/* Center: Title & Icon */}
            <div className="flex items-center gap-2 text-xs font-semibold text-white truncate max-w-[200px]">
              {icon}
              <span className="truncate">{title}</span>
            </div>

            {/* Right: Quick close */}
            <button
              type="button"
              onClick={() => {
                sound.playTap();
                onClose();
              }}
              className="text-xs text-[#AEA79F] hover:text-white transition-colors"
            >
              Done
            </button>
          </div>

          {/* App Body */}
          <div className="flex-1 flex flex-col overflow-hidden relative">
            {children}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
