import React, { useState, useEffect } from 'react';
import { Cpu, HardDrive, Server, Activity } from 'lucide-react';
import { sound } from '../../utils/audio';

interface SystemMonitorWidgetProps {
  onOpenSysMonitor: () => void;
}

export const SystemMonitorWidget: React.FC<SystemMonitorWidgetProps> = ({ onOpenSysMonitor }) => {
  const [cpu, setCpu] = useState(19);
  const [ram, setRam] = useState(3.4);

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate natural minor CPU fluctuation
      setCpu((prev) => Math.min(85, Math.max(12, Math.round(prev + (Math.random() * 8 - 4)))));
      setRam((prev) => Math.min(6.8, Math.max(2.9, Number((prev + (Math.random() * 0.1 - 0.05)).toFixed(1)))));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div
      onClick={() => {
        sound.playTap();
        onOpenSysMonitor();
      }}
      className="w-full p-3 rounded-2xl bg-black/35 hover:bg-black/45 backdrop-blur-md border border-white/10 shadow-lg cursor-pointer transition-all active:scale-[0.99] group select-none"
      title="System Resource Monitor - Tap to open"
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <Activity size={13} className="text-[#38B44A]" />
          <span className="text-[11px] font-semibold text-white/90 uppercase tracking-wider">Ubuntu 24.04 LTS</span>
        </div>
        <span className="text-[10px] font-mono text-[#AEA79F]">Kernel 6.8</span>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {/* CPU */}
        <div className="bg-white/5 rounded-xl p-2 border border-white/5">
          <div className="flex items-center justify-between text-[10px] text-[#AEA79F] mb-1">
            <span className="flex items-center gap-1">
              <Cpu size={10} className="text-[#E95420]" /> CPU
            </span>
            <span className="font-mono text-white/90">{cpu}%</span>
          </div>
          <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden">
            <div
              className="bg-[#E95420] h-full transition-all duration-500"
              style={{ width: `${cpu}%` }}
            />
          </div>
        </div>

        {/* RAM */}
        <div className="bg-white/5 rounded-xl p-2 border border-white/5">
          <div className="flex items-center justify-between text-[10px] text-[#AEA79F] mb-1">
            <span className="flex items-center gap-1">
              <Server size={10} className="text-[#19B6EE]" /> RAM
            </span>
            <span className="font-mono text-white/90">{ram}G</span>
          </div>
          <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden">
            <div
              className="bg-[#19B6EE] h-full transition-all duration-500"
              style={{ width: `${(ram / 8) * 100}%` }}
            />
          </div>
        </div>

        {/* Disk */}
        <div className="bg-white/5 rounded-xl p-2 border border-white/5">
          <div className="flex items-center justify-between text-[10px] text-[#AEA79F] mb-1">
            <span className="flex items-center gap-1">
              <HardDrive size={10} className="text-[#38B44A]" /> Disk
            </span>
            <span className="font-mono text-white/90">48%</span>
          </div>
          <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden">
            <div className="bg-[#38B44A] h-full" style={{ width: '48%' }} />
          </div>
        </div>
      </div>
    </div>
  );
};
