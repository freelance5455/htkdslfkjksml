import React, { useState, useEffect } from 'react';
import { CloudSun, BatteryCharging } from 'lucide-react';
import { sound } from '../../utils/audio';

interface OrigamiClockWidgetProps {
  onOpenClock?: () => void;
  onOpenWeather?: () => void;
  batteryLevel?: number;
}

export const OrigamiClockWidget: React.FC<OrigamiClockWidgetProps> = ({
  onOpenClock,
  onOpenWeather,
  batteryLevel = 84
}) => {
  const [time, setTime] = useState<{ hours: string; minutes: string; seconds: string; ampm: string }>({
    hours: '12',
    minutes: '00',
    seconds: '00',
    ampm: 'PM'
  });
  const [dateStr, setDateStr] = useState('');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      const h = now.getHours();
      const m = now.getMinutes().toString().padStart(2, '0');
      const s = now.getSeconds().toString().padStart(2, '0');
      const ampm = h >= 12 ? 'PM' : 'AM';
      const formattedH = (h % 12 || 12).toString().padStart(2, '0');

      setTime({
        hours: formattedH,
        minutes: m,
        seconds: s,
        ampm
      });

      setDateStr(
        now.toLocaleDateString(undefined, {
          weekday: 'long',
          month: 'short',
          day: 'numeric'
        })
      );
    };

    update();
    const timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, []);

  // Circle circumferences for battery ring
  const radius = 64;
  const stroke = 5;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (batteryLevel / 100) * circumference;

  return (
    <div className="w-full flex flex-col items-center justify-center py-4 select-none">
      {/* Ubuntu Touch Circular Ring Clock */}
      <div
        onClick={() => {
          sound.playTap();
          if (onOpenClock) onOpenClock();
        }}
        className="relative w-44 h-44 rounded-full flex flex-col items-center justify-center cursor-pointer group active:scale-95 transition-transform"
        title="Ubuntu Origami Clock - Tap to open clock"
      >
        {/* Glow ambient background */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#77216F]/20 via-[#E95420]/15 to-transparent blur-md group-hover:opacity-100 transition-opacity" />

        {/* SVG Progress Rings (Battery & Activity) */}
        <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 160 160">
          {/* Background track */}
          <circle
            cx="80"
            cy="80"
            r={radius}
            fill="none"
            stroke="rgba(255, 255, 255, 0.12)"
            strokeWidth={stroke}
          />
          {/* Canonical Orange Battery Ring */}
          <circle
            cx="80"
            cy="80"
            r={radius}
            fill="none"
            stroke="#E95420"
            strokeWidth={stroke}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-700 ease-out"
          />
          {/* Inner decorative dot circle */}
          <circle
            cx="80"
            cy="80"
            r={radius - 10}
            fill="none"
            stroke="rgba(233, 84, 32, 0.25)"
            strokeWidth="1.5"
            strokeDasharray="3 6"
          />
        </svg>

        {/* Clock Text */}
        <div className="relative z-10 flex flex-col items-center">
          <div className="flex items-baseline text-white">
            <span className="text-4xl font-light tracking-tight font-sans drop-shadow-md">
              {time.hours}:{time.minutes}
            </span>
            <span className="ml-1 text-[11px] font-mono font-medium text-[#AEA79F]">
              {time.ampm}
            </span>
          </div>

          <div className="flex items-center gap-1 mt-1 text-[11px] text-[#AEA79F] font-mono">
            <BatteryCharging size={11} className="text-[#E95420]" />
            <span>{batteryLevel}% charged</span>
          </div>
        </div>
      </div>

      {/* Date & Weather Row */}
      <div className="flex items-center justify-center gap-3 mt-1 px-4 py-1.5 rounded-full bg-black/20 backdrop-blur-sm border border-white/5">
        <span className="text-xs font-medium text-white/90 drop-shadow-sm tracking-wide">
          {dateStr}
        </span>
        <span className="text-white/30 text-xs">·</span>
        <button
          type="button"
          onClick={() => {
            sound.playTap();
            if (onOpenWeather) onOpenWeather();
          }}
          className="flex items-center gap-1.5 text-xs text-white/80 hover:text-white transition-colors cursor-pointer"
        >
          <CloudSun size={13} className="text-[#E95420]" />
          <span>22°C Clear</span>
        </button>
      </div>
    </div>
  );
};
