import React from 'react';
import { Terminal, Play } from 'lucide-react';
import { sound } from '../../utils/audio';

interface TerminalWidgetProps {
  onOpenTerminalWithCommand: (command?: string) => void;
}

export const TerminalWidget: React.FC<TerminalWidgetProps> = ({ onOpenTerminalWithCommand }) => {
  const quickCommands = ['neofetch', 'uname -r', 'free -h', 'apt update'];

  return (
    <div
      onClick={() => {
        sound.playLaunch();
        onOpenTerminalWithCommand();
      }}
      className="w-full p-2.5 rounded-2xl bg-[#1e071c]/80 hover:bg-[#280926]/90 backdrop-blur-md border border-purple-500/30 shadow-lg cursor-pointer transition-all select-none"
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5 font-mono text-xs text-purple-300">
          <Terminal size={13} className="text-[#38B44A]" />
          <span className="text-white/90">ubuntu@touch:~$</span>
        </div>
        <span className="text-[10px] text-purple-400/80 font-mono">bash 5.2</span>
      </div>

      <div className="flex items-center gap-1.5 flex-wrap" onClick={(e) => e.stopPropagation()}>
        {quickCommands.map((cmd) => (
          <button
            key={cmd}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              sound.playLaunch();
              onOpenTerminalWithCommand(cmd);
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-black/40 hover:bg-[#E95420]/30 border border-purple-500/20 text-white/90 hover:text-white text-[11px] font-mono transition-colors active:scale-95"
          >
            <Play size={9} className="text-[#E95420]" fill="currentColor" />
            <span>{cmd}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
