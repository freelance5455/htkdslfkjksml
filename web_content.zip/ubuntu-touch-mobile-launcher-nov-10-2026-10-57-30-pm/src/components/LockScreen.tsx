import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronUp, BatteryCharging, Sparkles, Bell } from 'lucide-react';
import { SystemNotification } from '../types/launcher';
import { sound } from '../utils/audio';

interface LockScreenProps {
  isLocked: boolean;
  onUnlock: () => void;
  wallpaperUrl: string;
  isGradientWallpaper: boolean;
  notifications: SystemNotification[];
  batteryLevel?: number;
}

export const LockScreen: React.FC<LockScreenProps> = ({
  isLocked,
  onUnlock,
  wallpaperUrl,
  isGradientWallpaper,
  notifications,
  batteryLevel = 84
}) => {
  const [time, setTime] = useState({ hours: '12', minutes: '00', ampm: 'PM' });
  const [dateStr, setDateStr] = useState('');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      const h = now.getHours();
      const m = now.getMinutes().toString().padStart(2, '0');
      const ampm = h >= 12 ? 'PM' : 'AM';
      const formattedH = (h % 12 || 12).toString().padStart(2, '0');

      setTime({ hours: formattedH, minutes: m, ampm });
      setDateStr(
        now.toLocaleDateString(undefined, {
          weekday: 'long',
          month: 'long',
          day: 'numeric'
        })
      );
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleUnlock = () => {
    sound.playUnlock();
    onUnlock();
  };

  const radius = 72;
  const stroke = 6;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (batteryLevel / 100) * circumference;

  return (
    <AnimatePresence>
      {isLocked && (
        <motion.div
          initial={{ y: 0, opacity: 1 }}
          exit={{ y: '-100%', opacity: 0.95 }}
          transition={{ type: 'spring', damping: 28, stiffness: 240 }}
          className="absolute inset-0 z-50 flex flex-col items-center justify-between py-12 px-6 text-white select-none overflow-hidden"
          style={
            isGradientWallpaper
              ? { background: wallpaperUrl }
              : { backgroundImage: `url(${wallpaperUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }
          }
        >
          {/* Subtle dark gradient scrim for contrast */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/20 to-black/80 pointer-events-none" />

          {/* Top Brand Tag */}
          <div className="relative z-10 flex items-center gap-2 px-3 py-1 rounded-full bg-black/40 backdrop-blur-md border border-white/10">
            <svg className="w-3.5 h-3.5 fill-[#E95420]" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="5" fill="#E95420" />
              <circle cx="5" cy="12" r="2" fill="#E95420" />
              <circle cx="15.5" cy="6" r="2" fill="#E95420" />
              <circle cx="15.5" cy="18" r="2" fill="#E95420" />
            </svg>
            <span className="text-xs font-semibold tracking-wider text-white">ubuntu touch</span>
          </div>

          {/* Center Welcome Circle Clock */}
          <div className="relative z-10 flex flex-col items-center my-auto">
            <div className="relative w-52 h-52 rounded-full flex flex-col items-center justify-center">
              {/* Radial glow */}
              <div className="absolute inset-0 rounded-full bg-[#E95420]/15 blur-xl animate-pulse" />

              {/* Progress Ring */}
              <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 180 180">
                <circle
                  cx="90"
                  cy="90"
                  r={radius}
                  fill="none"
                  stroke="rgba(255, 255, 255, 0.15)"
                  strokeWidth={stroke}
                />
                <circle
                  cx="90"
                  cy="90"
                  r={radius}
                  fill="none"
                  stroke="#E95420"
                  strokeWidth={stroke}
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                />
                <circle
                  cx="90"
                  cy="90"
                  r={radius - 12}
                  fill="none"
                  stroke="rgba(233, 84, 32, 0.3)"
                  strokeWidth="1.5"
                  strokeDasharray="4 8"
                />
              </svg>

              <div className="relative z-10 text-center">
                <div className="flex items-baseline justify-center">
                  <span className="text-5xl font-light tracking-tight font-sans text-white">
                    {time.hours}:{time.minutes}
                  </span>
                </div>
                <p className="text-xs font-medium text-[#AEA79F] mt-1">{dateStr}</p>
                <div className="flex items-center justify-center gap-1 text-[11px] text-[#E95420] mt-1.5 font-mono">
                  <BatteryCharging size={12} />
                  <span>{batteryLevel}%</span>
                </div>
              </div>
            </div>

            {/* Notification Badge preview if any */}
            {notifications.length > 0 && (
              <div className="mt-4 px-4 py-2 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 flex items-center gap-2.5 max-w-xs">
                <Bell size={14} className="text-[#E95420] shrink-0" />
                <div className="min-w-0 text-left">
                  <p className="text-[11px] font-medium text-white truncate">
                    {notifications[0].title}
                  </p>
                  <p className="text-[10px] text-white/60 truncate">{notifications[0].body}</p>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Swipe Up to Unlock */}
          <div className="relative z-10 flex flex-col items-center">
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
              className="p-3 text-white/80"
            >
              <ChevronUp size={24} />
            </motion.div>
            <button
              type="button"
              onClick={handleUnlock}
              className="px-6 py-2.5 rounded-full bg-white/15 hover:bg-white/25 active:scale-95 border border-white/20 backdrop-blur-md text-xs font-semibold tracking-wider text-white shadow-lg transition-transform"
            >
              Swipe or Tap to Unlock
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
