import React, { useRef } from 'react';
import { AppItem, LauncherSettings } from '../types/launcher';
import { AppIcon } from './AppIcon';
import { OrigamiClockWidget } from './Widgets/OrigamiClockWidget';
import { SystemMonitorWidget } from './Widgets/SystemMonitorWidget';
import { TerminalWidget } from './Widgets/TerminalWidget';
import { BottomDock } from './BottomDock';
import { sound } from '../utils/audio';

interface HomeScreenProps {
  apps: AppItem[];
  settings: LauncherSettings;
  onOpenApp: (appId: string) => void;
  onOpenDrawer: () => void;
  onOpenShade: () => void;
  onOpenEditModal: () => void;
  onOpenClock: () => void;
  onOpenWeather: () => void;
  onOpenSysMonitor: () => void;
  onOpenTerminalWithCommand: (cmd?: string) => void;
  batteryLevel?: number;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  apps,
  settings,
  onOpenApp,
  onOpenDrawer,
  onOpenShade,
  onOpenEditModal,
  onOpenClock,
  onOpenWeather,
  onOpenSysMonitor,
  onOpenTerminalWithCommand,
  batteryLevel = 84
}) => {
  const homeApps = apps.filter((a) => a.isOnHomeScreen);
  const touchStartY = useRef<number | null>(null);
  const touchStartX = useRef<number | null>(null);
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    touchStartX.current = e.touches[0].clientX;

    // Start long-press detection
    longPressTimer.current = setTimeout(() => {
      sound.playTap();
      onOpenEditModal();
    }, 700);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    // If movement is detected, cancel long-press
    if (touchStartY.current !== null) {
      const deltaY = Math.abs(e.touches[0].clientY - touchStartY.current);
      const deltaX = Math.abs(e.touches[0].clientX - (touchStartX.current || 0));
      if (deltaY > 10 || deltaX > 10) {
        if (longPressTimer.current) {
          clearTimeout(longPressTimer.current);
          longPressTimer.current = null;
        }
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }

    if (touchStartY.current !== null) {
      const deltaY = e.changedTouches[0].clientY - touchStartY.current;
      const deltaX = e.changedTouches[0].clientX - (touchStartX.current || 0);

      // Vertical swipe gestures
      if (Math.abs(deltaY) > 45 && Math.abs(deltaY) > Math.abs(deltaX)) {
        if (deltaY < -45) {
          // Swipe Up -> Open App Drawer
          sound.playTap();
          onOpenDrawer();
        } else if (deltaY > 45) {
          // Swipe Down -> Open Indicator Shade
          sound.playTap();
          onOpenShade();
        }
      }
      touchStartY.current = null;
      touchStartX.current = null;
    }
  };

  const handleMouseDown = () => {
    longPressTimer.current = setTimeout(() => {
      sound.playTap();
      onOpenEditModal();
    }, 700);
  };

  const handleMouseUp = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  return (
    <main
      className="relative flex-1 flex flex-col justify-between overflow-hidden select-none"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onContextMenu={(e) => {
        e.preventDefault();
        sound.playTap();
        onOpenEditModal();
      }}
    >
      {/* Scrollable Desktop Area for Widgets & App Grid */}
      <div className="flex-1 overflow-y-auto px-4 py-2 space-y-4 no-scrollbar">
        {/* Origami Welcome Clock & Battery Ring */}
        <OrigamiClockWidget
          onOpenClock={onOpenClock}
          onOpenWeather={onOpenWeather}
          batteryLevel={batteryLevel}
        />

        {/* Linux Telemetry Widget if enabled */}
        {settings.showResourceWidget && (
          <SystemMonitorWidget onOpenSysMonitor={onOpenSysMonitor} />
        )}

        {/* Quick Bash Command Runner Widget if enabled */}
        {settings.showTerminalWidget && (
          <TerminalWidget onOpenTerminalWithCommand={onOpenTerminalWithCommand} />
        )}

        {/* Desktop App Grid */}
        <div className="pt-2">
          <div className="grid grid-cols-4 gap-y-4 gap-x-2 justify-items-center">
            {homeApps.map((app) => (
              <AppIcon
                key={app.id}
                app={app}
                size="md"
                shape={settings.iconShape}
                showLabel={true}
                onClick={() => {
                  sound.playLaunch();
                  onOpenApp(app.id);
                }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Nova-style Dock if enabled */}
      {(settings.dockPosition === 'bottom' || settings.dockPosition === 'both') && (
        <BottomDock
          apps={apps}
          onOpenApp={onOpenApp}
          onOpenDrawer={onOpenDrawer}
          iconShape={settings.iconShape}
        />
      )}
    </main>
  );
};
