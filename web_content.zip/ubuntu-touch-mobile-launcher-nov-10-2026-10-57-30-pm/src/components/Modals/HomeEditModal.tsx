import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Image, LayoutGrid, Palette, Sliders, Check, RotateCcw } from 'lucide-react';
import { LauncherSettings, WallpaperOption, IconShape, DockPosition, YaruTheme, AccentColor } from '../../types/launcher';
import { WALLPAPERS } from '../../data/wallpapers';
import { sound } from '../../utils/audio';

interface HomeEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: LauncherSettings;
  onUpdateSettings: (updates: Partial<LauncherSettings>) => void;
  onResetDefaults: () => void;
}

export const HomeEditModal: React.FC<HomeEditModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onResetDefaults
}) => {
  const iconShapes: { id: IconShape; label: string }[] = [
    { id: 'squircle', label: 'Ubuntu Squircle' },
    { id: 'circle', label: 'Circle' },
    { id: 'rounded', label: 'Rounded 2xl' },
    { id: 'square', label: 'Classic Square' }
  ];

  const dockPositions: { id: DockPosition; label: string }[] = [
    { id: 'both', label: 'Left Edge + Bottom' },
    { id: 'left', label: 'Left Edge Dock (Ubuntu Touch)' },
    { id: 'bottom', label: 'Bottom Dock (Nova Style)' }
  ];

  const themes: { id: YaruTheme; label: string }[] = [
    { id: 'classic', label: 'Aubergine Classic' },
    { id: 'dark', label: 'Yaru Dark' },
    { id: 'light', label: 'Yaru Light' }
  ];

  const accentColors: { id: AccentColor; hex: string; label: string }[] = [
    { id: 'orange', hex: '#E95420', label: 'Canonical Orange' },
    { id: 'aubergine', hex: '#77216F', label: 'Warm Aubergine' },
    { id: 'green', hex: '#38B44A', label: 'Sage Green' },
    { id: 'blue', hex: '#19B6EE', label: 'Prussian Blue' },
    { id: 'bark', hex: '#7B5B49', label: 'Bark Mocha' }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 26, stiffness: 260 }}
            className="absolute inset-x-0 bottom-0 max-h-[85%] z-50 rounded-t-3xl bg-[#1d051a] border-t border-orange-500/30 text-white flex flex-col shadow-2xl select-none"
          >
            {/* Grab handle */}
            <div className="w-10 h-1.5 bg-white/20 rounded-full mx-auto my-3" />

            <div className="px-5 pb-3 border-b border-white/10 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">Launcher Customizer</h3>
                <p className="text-xs text-[#AEA79F]">Nova-style configuration for Ubuntu Touch</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  onClose();
                }}
                className="p-1.5 text-white/60 hover:text-white rounded-full bg-white/10"
              >
                <X size={18} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-6">
              {/* Wallpaper Picker */}
              <div>
                <div className="flex items-center gap-2 mb-2.5">
                  <Image size={15} className="text-[#E95420]" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-white/90">
                    Ubuntu Wallpapers
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2.5">
                  {WALLPAPERS.map((wp) => {
                    const isSelected = settings.wallpaperId === wp.id;
                    return (
                      <button
                        key={wp.id}
                        type="button"
                        onClick={() => {
                          sound.playTap();
                          onUpdateSettings({ wallpaperId: wp.id });
                        }}
                        className={`relative aspect-[9/16] rounded-xl overflow-hidden border-2 transition-all group ${
                          isSelected
                            ? 'border-[#E95420] ring-2 ring-[#E95420]/50 scale-[1.02]'
                            : 'border-white/10 hover:border-white/30'
                        }`}
                      >
                        {wp.type === 'image' ? (
                          <img
                            src={wp.thumbnail}
                            alt={wp.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full" style={{ background: wp.url }} />
                        )}
                        <div className="absolute inset-x-0 bottom-0 p-1.5 bg-gradient-to-t from-black/90 to-transparent">
                          <p className="text-[10px] font-medium text-white truncate text-left">{wp.name}</p>
                        </div>
                        {isSelected && (
                          <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-[#E95420] text-white flex items-center justify-center shadow-md">
                            <Check size={12} strokeWidth={3} />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Icon Shape */}
              <div>
                <div className="flex items-center gap-2 mb-2.5">
                  <LayoutGrid size={15} className="text-[#E95420]" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-white/90">
                    Icon Mask & Shape
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {iconShapes.map((shape) => (
                    <button
                      key={shape.id}
                      type="button"
                      onClick={() => {
                        sound.playTap();
                        onUpdateSettings({ iconShape: shape.id });
                      }}
                      className={`flex items-center justify-between px-3 py-2.5 rounded-xl border text-xs transition-colors ${
                        settings.iconShape === shape.id
                          ? 'bg-[#E95420]/20 border-[#E95420] text-white font-medium'
                          : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
                      }`}
                    >
                      <span>{shape.label}</span>
                      {settings.iconShape === shape.id && <Check size={14} className="text-[#E95420]" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dock Position */}
              <div>
                <div className="flex items-center gap-2 mb-2.5">
                  <Sliders size={15} className="text-[#E95420]" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-white/90">
                    Dock Layout
                  </span>
                </div>
                <div className="flex flex-col gap-2">
                  {dockPositions.map((pos) => (
                    <button
                      key={pos.id}
                      type="button"
                      onClick={() => {
                        sound.playTap();
                        onUpdateSettings({ dockPosition: pos.id });
                      }}
                      className={`flex items-center justify-between px-3 py-2 rounded-xl border text-xs transition-colors ${
                        settings.dockPosition === pos.id
                          ? 'bg-[#E95420]/20 border-[#E95420] text-white font-medium'
                          : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
                      }`}
                    >
                      <span>{pos.label}</span>
                      {settings.dockPosition === pos.id && <Check size={14} className="text-[#E95420]" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Accent Colors */}
              <div>
                <div className="flex items-center gap-2 mb-2.5">
                  <Palette size={15} className="text-[#E95420]" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-white/90">
                    Accent Color
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  {accentColors.map((color) => (
                    <button
                      key={color.id}
                      type="button"
                      onClick={() => {
                        sound.playTap();
                        onUpdateSettings({ accentColor: color.id });
                      }}
                      className={`w-9 h-9 rounded-full flex items-center justify-center transition-transform ${
                        settings.accentColor === color.id
                          ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1d051a] scale-110'
                          : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: color.hex }}
                      title={color.label}
                    >
                      {settings.accentColor === color.id && <Check size={14} className="text-white" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Widgets Toggle */}
              <div className="space-y-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-white/90">
                  Home Screen Widgets
                </span>
                <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-xs text-white">Linux Resource Monitor</span>
                  <input
                    type="checkbox"
                    checked={settings.showResourceWidget}
                    onChange={(e) => onUpdateSettings({ showResourceWidget: e.target.checked })}
                    className="w-4 h-4 accent-[#E95420]"
                  />
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-xs text-white">Quick Bash Command Bar</span>
                  <input
                    type="checkbox"
                    checked={settings.showTerminalWidget}
                    onChange={(e) => onUpdateSettings({ showTerminalWidget: e.target.checked })}
                    className="w-4 h-4 accent-[#E95420]"
                  />
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-xs text-white">Lock Screen Enabled</span>
                  <input
                    type="checkbox"
                    checked={settings.lockScreenEnabled}
                    onChange={(e) => onUpdateSettings({ lockScreenEnabled: e.target.checked })}
                    className="w-4 h-4 accent-[#E95420]"
                  />
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-xs text-white">Haptic & UI Audio Feedback</span>
                  <input
                    type="checkbox"
                    checked={settings.soundEnabled}
                    onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
                    className="w-4 h-4 accent-[#E95420]"
                  />
                </div>
              </div>

              {/* Reset Defaults button */}
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  onResetDefaults();
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white font-medium transition-colors"
              >
                <RotateCcw size={14} />
                <span>Reset to Canonical Ubuntu Defaults</span>
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
