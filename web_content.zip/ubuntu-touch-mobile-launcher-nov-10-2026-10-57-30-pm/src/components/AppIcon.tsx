import React from 'react';
import {
  Terminal,
  Folder,
  ShoppingBag,
  SlidersHorizontal,
  Globe,
  Music,
  Activity,
  Calculator,
  FileText,
  Camera,
  Image as ImageIcon,
  Calendar,
  CloudSun,
  Clock,
  HelpCircle,
  LucideIcon
} from 'lucide-react';
import { AppItem, IconShape } from '../types/launcher';

const ICON_MAP: Record<string, LucideIcon> = {
  Terminal,
  Folder,
  ShoppingBag,
  SlidersHorizontal,
  Globe,
  Music,
  Activity,
  Calculator,
  FileText,
  Camera,
  Image: ImageIcon,
  Calendar,
  CloudSun,
  Clock,
  HelpCircle
};

interface AppIconProps {
  app: AppItem;
  size?: 'sm' | 'md' | 'lg' | 'dock';
  shape?: IconShape;
  showLabel?: boolean;
  onClick?: () => void;
  onContextMenu?: (e: React.MouseEvent) => void;
  className?: string;
}

export const AppIcon: React.FC<AppIconProps> = ({
  app,
  size = 'md',
  shape = 'squircle',
  showLabel = true,
  onClick,
  onContextMenu,
  className = ''
}) => {
  const IconComponent = ICON_MAP[app.icon] || HelpCircle;

  // Sizing map
  const sizeConfig = {
    sm: { box: 'w-10 h-10', icon: 20, text: 'text-[11px]' },
    md: { box: 'w-14 h-14', icon: 28, text: 'text-xs' },
    lg: { box: 'w-16 h-16', icon: 32, text: 'text-sm' },
    dock: { box: 'w-12 h-12', icon: 24, text: 'text-[10px]' }
  }[size];

  // Shape class
  const shapeClass = {
    squircle: 'rounded-[26%]',
    circle: 'rounded-full',
    rounded: 'rounded-2xl',
    square: 'rounded-lg'
  }[shape];

  // Specific Ubuntu gradients for authentic Yaru look
  const getGradient = () => {
    switch (app.id) {
      case 'terminal':
        return 'bg-gradient-to-br from-[#401235] via-[#2C001E] to-[#12000c] text-green-400 border border-purple-900/40';
      case 'files':
        return 'bg-gradient-to-br from-[#f26e3c] to-[#d8420c] text-white shadow-orange-950/20';
      case 'software':
        return 'bg-gradient-to-br from-[#eb5b29] via-[#E95420] to-[#b83707] text-white';
      case 'settings':
        return 'bg-gradient-to-br from-[#6f3263] via-[#5E2750] to-[#36132d] text-white';
      case 'browser':
        return 'bg-gradient-to-br from-[#ff8533] via-[#e55018] to-[#961e05] text-white';
      case 'music':
        return 'bg-gradient-to-br from-[#8d2a84] via-[#77216F] to-[#450f3f] text-white';
      case 'sysmonitor':
        return 'bg-gradient-to-br from-[#42c556] to-[#268c37] text-white';
      case 'calculator':
        return 'bg-gradient-to-br from-[#f58045] to-[#cc4612] text-white';
      case 'notes':
        return 'bg-gradient-to-br from-[#f2b827] to-[#d69204] text-amber-950';
      case 'camera':
        return 'bg-gradient-to-br from-[#441a3d] via-[#2C001E] to-[#170211] text-purple-200';
      case 'gallery':
        return 'bg-gradient-to-br from-[#913286] to-[#601358] text-white';
      case 'calendar':
        return 'bg-gradient-to-br from-[#24c4ff] to-[#0c8ab8] text-white';
      case 'weather':
        return 'bg-gradient-to-br from-[#38B44A] to-[#1c6928] text-white';
      case 'clock':
        return 'bg-gradient-to-br from-[#682c5b] to-[#421639] text-white';
      default:
        return 'bg-gradient-to-br from-[#77216F] to-[#E95420] text-white';
    }
  };

  return (
    <button
      type="button"
      onClick={onClick}
      onContextMenu={onContextMenu}
      className={`group flex flex-col items-center justify-center p-1.5 focus:outline-none transition-transform active:scale-90 cursor-pointer ${className}`}
      aria-label={app.name}
    >
      <div
        className={`relative ${sizeConfig.box} ${shapeClass} ${getGradient()} flex items-center justify-center shadow-md shadow-black/30 transition-all duration-200 group-hover:scale-105 group-hover:shadow-lg`}
      >
        {/* Top subtle highlight reflection curve */}
        <div className="absolute inset-x-1 top-0.5 h-1/2 bg-gradient-to-b from-white/20 to-transparent rounded-t-[20%] pointer-events-none" />

        <IconComponent size={sizeConfig.icon} strokeWidth={2.2} />

        {/* Badge counter */}
        {app.badge && app.badge > 0 && (
          <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-4 h-4 px-1 text-[10px] font-bold text-white bg-[#E95420] rounded-full ring-2 ring-black/40 shadow-sm animate-pulse">
            {app.badge}
          </span>
        )}
      </div>

      {showLabel && (
        <span
          className={`mt-1.5 ${sizeConfig.text} font-medium text-white/90 drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] truncate max-w-[76px] text-center tracking-tight transition-colors group-hover:text-white`}
        >
          {app.name}
        </span>
      )}
    </button>
  );
};
