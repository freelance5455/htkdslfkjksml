import React from 'react';
import { AppItem, IconShape } from '../types/launcher';
import { AppIcon } from './AppIcon';
import { sound } from '../utils/audio';

interface BottomDockProps {
  apps: AppItem[];
  onOpenApp: (appId: string) => void;
  onOpenDrawer: () => void;
  iconShape: IconShape;
}

export const BottomDock: React.FC<BottomDockProps> = ({
  apps,
  onOpenApp,
  onOpenDrawer,
  iconShape
}) => {
  // Primary dock items: Terminal, Files, Browser, Software, Settings (or Dash)
  const dockApps = apps.filter((a) => a.isPinnedToDock).slice(0, 4);

  return (
    <footer className="w-full px-4 pb-4 pt-2 z-20 flex justify-center">
      <div className="w-full max-w-sm px-3 py-2 rounded-3xl bg-black/40 backdrop-blur-xl border border-white/10 shadow-xl flex items-center justify-around gap-1">
        {dockApps.map((app) => (
          <AppIcon
            key={app.id}
            app={app}
            size="dock"
            shape={iconShape}
            showLabel={false}
            onClick={() => {
              sound.playLaunch();
              onOpenApp(app.id);
            }}
          />
        ))}

        {/* Center/End Ubuntu Dash Trigger Button */}
        <button
          type="button"
          onClick={() => {
            sound.playTap();
            onOpenDrawer();
          }}
          className="group flex flex-col items-center justify-center p-1.5 focus:outline-none transition-transform active:scale-90 cursor-pointer"
          aria-label="Open Ubuntu Dash and Apps"
        >
          <div className="w-12 h-12 rounded-[26%] bg-gradient-to-br from-[#E95420] via-[#c43b0c] to-[#77216F] flex items-center justify-center text-white shadow-md shadow-orange-950/40 group-hover:scale-105 transition-transform">
            <svg className="w-6 h-6 fill-white" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="11" fill="none" stroke="currentColor" strokeWidth="2" opacity="0.4" />
              <circle cx="12" cy="12" r="5" fill="white" />
              <circle cx="5" cy="12" r="2" fill="white" />
              <circle cx="15.5" cy="6" r="2" fill="white" />
              <circle cx="15.5" cy="18" r="2" fill="white" />
            </svg>
          </div>
        </button>
      </div>
    </footer>
  );
};
