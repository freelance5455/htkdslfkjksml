import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, Pin, Plus, Info, Trash2 } from 'lucide-react';
import { AppItem, IconShape } from '../types/launcher';
import { AppIcon } from './AppIcon';
import { sound } from '../utils/audio';

interface AppDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  apps: AppItem[];
  onOpenApp: (appId: string) => void;
  onTogglePinApp: (appId: string) => void;
  onAddToHomeScreen: (appId: string) => void;
  onUninstallApp?: (appId: string) => void;
  iconShape: IconShape;
}

export const AppDrawer: React.FC<AppDrawerProps> = ({
  isOpen,
  onClose,
  apps,
  onOpenApp,
  onTogglePinApp,
  onAddToHomeScreen,
  onUninstallApp,
  iconShape
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [contextApp, setContextApp] = useState<AppItem | null>(null);

  const categories = ['All', 'System', 'Utilities', 'Internet', 'Media', 'Development', 'Productivity'];

  const filteredApps = apps.filter((app) => {
    const matchesQuery =
      app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || app.category === selectedCategory;
    return matchesQuery && matchesCategory;
  });

  const handleAppContextMenu = (e: React.MouseEvent, app: AppItem) => {
    e.preventDefault();
    sound.playTap();
    setContextApp(app);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ y: '100%', opacity: 0.9 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: '100%', opacity: 0.9 }}
          transition={{ type: 'spring', damping: 27, stiffness: 270 }}
          className="absolute inset-0 z-50 flex flex-col bg-[#1c0218]/95 backdrop-blur-2xl text-white overflow-hidden shadow-2xl select-none"
        >
          {/* Top Search Bar */}
          <div className="pt-3 px-4 pb-2 border-b border-white/10 flex items-center gap-2">
            <div className="flex-1 relative flex items-center">
              <Search size={16} className="absolute left-3.5 text-[#AEA79F]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Ubuntu apps & scopes..."
                className="w-full pl-9 pr-8 py-2.5 bg-white/10 focus:bg-white/15 rounded-xl border border-white/10 focus:border-[#E95420] text-sm text-white placeholder-white/40 focus:outline-none transition-all"
                autoFocus
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 p-1 text-white/50 hover:text-white"
                >
                  <X size={14} />
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                sound.playTap();
                onClose();
              }}
              className="p-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white/80 hover:text-white active:scale-95 transition-transform"
              title="Close drawer"
              aria-label="Close drawer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Scope / Category Tabs */}
          <div className="px-4 py-2 overflow-x-auto flex items-center gap-1.5 no-scrollbar border-b border-white/5">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  sound.playTap();
                  setSelectedCategory(cat);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                  selectedCategory === cat
                    ? 'bg-[#E95420] text-white shadow-sm'
                    : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Apps Grid */}
          <div className="flex-1 overflow-y-auto px-4 py-4">
            {filteredApps.length === 0 ? (
              <div className="py-16 text-center text-white/40 text-sm">
                No apps found matching "{searchQuery}"
              </div>
            ) : (
              <div className="grid grid-cols-4 gap-y-4 gap-x-2 justify-items-center">
                {filteredApps.map((app) => (
                  <div key={app.id} className="relative">
                    <AppIcon
                      app={app}
                      size="md"
                      shape={iconShape}
                      showLabel={true}
                      onClick={() => {
                        sound.playLaunch();
                        onClose();
                        onOpenApp(app.id);
                      }}
                      onContextMenu={(e) => handleAppContextMenu(e, app)}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Context Menu Modal / Sheet for App Options */}
          <AnimatePresence>
            {contextApp && (
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 30 }}
                className="absolute inset-x-4 bottom-6 z-60 p-4 rounded-2xl bg-[#2C001E] border border-orange-500/30 shadow-2xl flex flex-col gap-2"
              >
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <div className="flex items-center gap-2.5">
                    <span className="font-semibold text-sm text-white">{contextApp.name}</span>
                    <span className="text-[11px] text-[#AEA79F]">{contextApp.category}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setContextApp(null)}
                    className="p-1 text-white/60 hover:text-white"
                  >
                    <X size={16} />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-1">
                  <button
                    type="button"
                    onClick={() => {
                      sound.playTap();
                      onTogglePinApp(contextApp.id);
                      setContextApp(null);
                    }}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white"
                  >
                    <Pin size={14} className={contextApp.isPinnedToDock ? 'text-[#E95420]' : ''} />
                    <span>{contextApp.isPinnedToDock ? 'Unpin from Dock' : 'Pin to Dock'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      sound.playTap();
                      onAddToHomeScreen(contextApp.id);
                      setContextApp(null);
                    }}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white"
                  >
                    <Plus size={14} />
                    <span>Add to Desktop</span>
                  </button>
                </div>

                <p className="text-[11px] text-white/60 px-1 pt-1 leading-relaxed">
                  {contextApp.description}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
