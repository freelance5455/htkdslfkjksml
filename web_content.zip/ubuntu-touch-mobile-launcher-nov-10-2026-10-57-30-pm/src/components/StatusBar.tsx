import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Volume2, Bluetooth, ChevronDown } from 'lucide-react';

interface StatusBarProps {
  onToggleShade: () => void;
  isOpenShade: boolean;
  batteryLevel?: number;
  wifiConnected?: boolean;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  onToggleShade,
  isOpenShade,
  batteryLevel = 84,
  wifiConnected = true
}) => {
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header
      onClick={onToggleShade}
      className="relative z-40 w-full h-8 px-4 flex items-center justify-between bg-black/35 hover:bg-black/50 backdrop-blur-md text-white select-none transition-colors cursor-pointer border-b border-white/5 active:bg-black/60"
      title="Tap or drag down for Ubuntu Indicator & Notification Shade"
    >
      {/* Left zone: Ubuntu Circle of Friends logo + Time */}
      <div className="flex items-center gap-2">
        <svg className="w-3.5 h-3.5 fill-[#E95420]" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="11" fill="none" stroke="currentColor" strokeWidth="2" opacity="0.3"/>
          <circle cx="12" cy="12" r="5" fill="#E95420"/>
          <circle cx="5" cy="12" r="2" fill="#E95420"/>
          <circle cx="15.5" cy="6" r="2" fill="#E95420"/>
          <circle cx="15.5" cy="18" r="2" fill="#E95420"/>
        </svg>
        <span className="text-[12px] font-medium tracking-tight opacity-90 font-mono">
          {timeStr}
        </span>
      </div>

      {/* Center zone: Pull indicator handle */}
      <div className="flex items-center justify-center opacity-40 hover:opacity-100 transition-opacity">
        <ChevronDown size={14} className={`transition-transform duration-200 ${isOpenShade ? 'rotate-180' : ''}`} />
      </div>

      {/* Right zone: System indicators */}
      <div className="flex items-center gap-2.5 text-xs text-white/90">
        <Bluetooth size={12} className="opacity-80" />
        {wifiConnected && <Wifi size={13} className="opacity-90" />}
        <Volume2 size={13} className="opacity-85" />
        <div className="flex items-center gap-1">
          <span className="text-[11px] font-mono opacity-80">{batteryLevel}%</span>
          <BatteryMedium size={14} className="text-white opacity-95" />
        </div>
      </div>
    </header>
  );
};
