import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Wifi,
  WifiOff,
  Bluetooth,
  Sun,
  Volume2,
  VolumeX,
  Flashlight,
  Moon,
  Plane,
  Terminal,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Trash2,
  X,
  ChevronUp,
  Sliders,
  Check
} from 'lucide-react';
import { SystemNotification, YaruTheme } from '../types/launcher';
import { sound } from '../utils/audio';

interface NotificationShadeProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: SystemNotification[];
  onDismissNotification: (id: string) => void;
  onClearAllNotifications: () => void;
  onOpenApp: (appId: string) => void;
  theme: YaruTheme;
  onToggleTheme: () => void;
}

export const NotificationShade: React.FC<NotificationShadeProps> = ({
  isOpen,
  onClose,
  notifications,
  onDismissNotification,
  onClearAllNotifications,
  onOpenApp,
  theme,
  onToggleTheme
}) => {
  // Quick settings states
  const [wifiOn, setWifiOn] = useState(true);
  const [bluetoothOn, setBluetoothOn] = useState(true);
  const [flashlightOn, setFlashlightOn] = useState(false);
  const [airplaneOn, setAirplaneOn] = useState(false);
  const [dndOn, setDndOn] = useState(false);
  const [volumeMuted, setVolumeMuted] = useState(false);
  const [brightness, setBrightness] = useState(85);
  const [volume, setVolume] = useState(70);

  // Music state
  const [isPlaying, setIsPlaying] = useState(false);
  const [songProgress, setSongProgress] = useState(38);

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playTap();
    setIsPlaying(!isPlaying);
  };

  const today = new Date().toLocaleDateString(undefined, {
    weekday: 'long',
    month: 'short',
    day: 'numeric'
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ y: '-100%', opacity: 0.8 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: '-100%', opacity: 0.8 }}
          transition={{ type: 'spring', damping: 28, stiffness: 280 }}
          className="absolute inset-0 z-50 flex flex-col bg-[#1A0B18]/95 backdrop-blur-2xl text-white overflow-hidden shadow-2xl border-b border-orange-500/20"
        >
          {/* Header */}
          <div className="pt-3 pb-3 px-5 border-b border-white/10 flex items-center justify-between bg-black/25">
            <div>
              <p className="text-xs uppercase tracking-wider text-[#AEA79F] font-medium">Ubuntu Touch</p>
              <h2 className="text-base font-semibold text-white tracking-tight">{today}</h2>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  onClose();
                  onOpenApp('settings');
                }}
                className="p-2 rounded-full hover:bg-white/10 active:scale-95 text-white/80 hover:text-white transition-colors"
                title="Settings"
                aria-label="Settings"
              >
                <Sliders size={18} />
              </button>
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  onClose();
                }}
                className="p-2 rounded-full hover:bg-white/10 active:scale-95 text-white/80 hover:text-white transition-colors"
                title="Close"
                aria-label="Close"
              >
                <ChevronUp size={20} />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
            {/* Quick Toggle Matrix */}
            <div className="grid grid-cols-4 gap-2.5">
              {/* Wi-Fi */}
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  setWifiOn(!wifiOn);
                }}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl transition-all ${
                  wifiOn
                    ? 'bg-[#E95420] text-white shadow-md shadow-orange-950/30'
                    : 'bg-white/10 text-white/60 hover:bg-white/15'
                }`}
              >
                {wifiOn ? <Wifi size={18} /> : <WifiOff size={18} />}
                <span className="text-[11px] font-medium mt-1 truncate">Wi-Fi</span>
              </button>

              {/* Bluetooth */}
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  setBluetoothOn(!bluetoothOn);
                }}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl transition-all ${
                  bluetoothOn
                    ? 'bg-[#19B6EE] text-white shadow-md shadow-blue-950/30'
                    : 'bg-white/10 text-white/60 hover:bg-white/15'
                }`}
              >
                <Bluetooth size={18} />
                <span className="text-[11px] font-medium mt-1 truncate">Bluetooth</span>
              </button>

              {/* Yaru Dark / Light */}
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  onToggleTheme();
                }}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl transition-all ${
                  theme === 'dark' || theme === 'classic'
                    ? 'bg-[#77216F] text-white shadow-md shadow-purple-950/30'
                    : 'bg-white text-slate-900 shadow-md'
                }`}
              >
                <Moon size={18} />
                <span className="text-[11px] font-medium mt-1 truncate">
                  {theme === 'dark' ? 'Yaru Dark' : theme === 'light' ? 'Yaru Light' : 'Aubergine'}
                </span>
              </button>

              {/* Flashlight */}
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  setFlashlightOn(!flashlightOn);
                }}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl transition-all ${
                  flashlightOn
                    ? 'bg-amber-400 text-amber-950 font-semibold shadow-md shadow-amber-950/30'
                    : 'bg-white/10 text-white/60 hover:bg-white/15'
                }`}
              >
                <Flashlight size={18} />
                <span className="text-[11px] font-medium mt-1 truncate">Torch</span>
              </button>

              {/* Airplane Mode */}
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  setAirplaneOn(!airplaneOn);
                }}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl transition-all ${
                  airplaneOn
                    ? 'bg-sky-500 text-white'
                    : 'bg-white/10 text-white/60 hover:bg-white/15'
                }`}
              >
                <Plane size={18} />
                <span className="text-[11px] font-medium mt-1 truncate">Airplane</span>
              </button>

              {/* Do Not Disturb */}
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  setDndOn(!dndOn);
                }}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl transition-all ${
                  dndOn
                    ? 'bg-[#38B44A] text-white'
                    : 'bg-white/10 text-white/60 hover:bg-white/15'
                }`}
              >
                <Moon size={18} />
                <span className="text-[11px] font-medium mt-1 truncate">DND</span>
              </button>

              {/* Mute Volume */}
              <button
                type="button"
                onClick={() => {
                  sound.playTap();
                  setVolumeMuted(!volumeMuted);
                }}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl transition-all ${
                  volumeMuted
                    ? 'bg-rose-600 text-white'
                    : 'bg-white/10 text-white/60 hover:bg-white/15'
                }`}
              >
                {volumeMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
                <span className="text-[11px] font-medium mt-1 truncate">
                  {volumeMuted ? 'Muted' : 'Sound'}
                </span>
              </button>

              {/* Quick Terminal */}
              <button
                type="button"
                onClick={() => {
                  sound.playLaunch();
                  onClose();
                  onOpenApp('terminal');
                }}
                className="flex flex-col items-center justify-center p-2.5 rounded-xl bg-purple-950/80 hover:bg-purple-900 border border-purple-500/30 text-emerald-400 transition-all"
              >
                <Terminal size={18} />
                <span className="text-[11px] font-medium mt-1 truncate text-white">Bash</span>
              </button>
            </div>

            {/* Brightness & Volume Sliders */}
            <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              {/* Brightness */}
              <div className="flex items-center gap-3">
                <Sun size={16} className="text-[#AEA79F]" />
                <input
                  type="range"
                  min="10"
                  max="100"
                  value={brightness}
                  onChange={(e) => setBrightness(Number(e.target.value))}
                  className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-[#E95420]"
                />
                <span className="text-xs font-mono text-[#AEA79F] w-7 text-right">{brightness}%</span>
              </div>

              {/* Volume */}
              <div className="flex items-center gap-3">
                <Volume2 size={16} className="text-[#AEA79F]" />
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volumeMuted ? 0 : volume}
                  disabled={volumeMuted}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-[#E95420]"
                />
                <span className="text-xs font-mono text-[#AEA79F] w-7 text-right">
                  {volumeMuted ? '0%' : `${volume}%`}
                </span>
              </div>
            </div>

            {/* Rhythmbox Media Player Card */}
            <div
              onClick={() => {
                sound.playTap();
                onClose();
                onOpenApp('music');
              }}
              className="p-3.5 rounded-2xl bg-gradient-to-r from-[#2C001E] to-[#4A1540] border border-purple-500/20 shadow-md cursor-pointer hover:border-purple-500/40 transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-[#E95420] flex items-center justify-center shrink-0 shadow-sm text-white">
                    <Play size={18} fill="currentColor" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-white truncate">Ubuntu Ambient Theme</p>
                    <p className="text-[11px] text-[#AEA79F] truncate">Canonical Audio Lab · Yaru Beats</p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      sound.playTap();
                      setSongProgress(Math.max(0, songProgress - 15));
                    }}
                    className="p-1.5 text-white/70 hover:text-white active:scale-95"
                    aria-label="Previous track"
                  >
                    <SkipBack size={16} />
                  </button>
                  <button
                    type="button"
                    onClick={togglePlay}
                    className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center active:scale-90 transition-transform"
                    aria-label={isPlaying ? 'Pause' : 'Play'}
                  >
                    {isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      sound.playTap();
                      setSongProgress((songProgress + 15) % 100);
                    }}
                    className="p-1.5 text-white/70 hover:text-white active:scale-95"
                    aria-label="Next track"
                  >
                    <SkipForward size={16} />
                  </button>
                </div>
              </div>

              {/* Progress bar */}
              <div className="mt-2.5 w-full bg-black/40 h-1 rounded-full overflow-hidden">
                <div
                  className="bg-[#E95420] h-full transition-all duration-300"
                  style={{ width: `${songProgress}%` }}
                />
              </div>
            </div>

            {/* Notifications Feed */}
            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-semibold tracking-wide text-white/80">
                  Notifications ({notifications.length})
                </span>
                {notifications.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      sound.playTap();
                      onClearAllNotifications();
                    }}
                    className="flex items-center gap-1 text-[11px] text-[#AEA79F] hover:text-[#E95420] transition-colors"
                  >
                    <Trash2 size={12} />
                    <span>Clear all</span>
                  </button>
                )}
              </div>

              {notifications.length === 0 ? (
                <div className="p-6 text-center text-xs text-white/40 bg-white/5 rounded-2xl border border-white/5">
                  <Check size={24} className="mx-auto mb-1 text-emerald-400/80" />
                  No pending notifications
                </div>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    className="group relative p-3 rounded-2xl bg-white/8 hover:bg-white/12 border border-white/10 transition-colors flex items-start justify-between gap-3"
                  >
                    <div
                      className="flex-1 cursor-pointer"
                      onClick={() => {
                        sound.playTap();
                        onClose();
                        if (n.appName === 'Ubuntu Software') onOpenApp('software');
                        else if (n.appName === 'Terminal') onOpenApp('terminal');
                        else if (n.appName === 'Calendar') onOpenApp('calendar');
                      }}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: n.accentColor || '#E95420' }}
                        />
                        <span className="text-[11px] font-semibold text-white/90">{n.appName}</span>
                        <span className="text-[10px] text-white/50">{n.time}</span>
                      </div>
                      <h4 className="text-xs font-medium text-white">{n.title}</h4>
                      <p className="text-[11px] text-white/70 line-clamp-2 mt-0.5 leading-relaxed">{n.body}</p>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        sound.playTap();
                        onDismissNotification(n.id);
                      }}
                      className="p-1.5 text-white/40 hover:text-white/90 active:scale-95 transition-colors"
                      title="Dismiss"
                      aria-label="Dismiss notification"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Bottom Pull Handle */}
          <div
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="py-2.5 flex items-center justify-center cursor-pointer hover:bg-white/5 transition-colors border-t border-white/5"
          >
            <div className="w-12 h-1 bg-white/30 rounded-full" />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
