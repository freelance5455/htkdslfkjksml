import React, { useState } from 'react';
import { Delete, Divide, X, Minus, Plus, Equal } from 'lucide-react';
import { sound } from '../../utils/audio';

export const CalculatorApp: React.FC = () => {
  const [display, setDisplay] = useState('0');
  const [prevValue, setPrevValue] = useState<number | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);

  const inputDigit = (digit: string) => {
    sound.playTap();
    if (waitingForOperand) {
      setDisplay(digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  };

  const inputDecimal = () => {
    sound.playTap();
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
      return;
    }
    if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const clear = () => {
    sound.playTap();
    setDisplay('0');
    setPrevValue(null);
    setOperator(null);
    setWaitingForOperand(false);
  };

  const performOperation = (nextOperator: string) => {
    sound.playTap();
    const inputValue = parseFloat(display);

    if (prevValue === null) {
      setPrevValue(inputValue);
    } else if (operator) {
      const currentValue = prevValue || 0;
      let result = 0;
      switch (operator) {
        case '+':
          result = currentValue + inputValue;
          break;
        case '-':
          result = currentValue - inputValue;
          break;
        case '×':
          result = currentValue * inputValue;
          break;
        case '÷':
          result = inputValue === 0 ? 0 : currentValue / inputValue;
          break;
        default:
          result = inputValue;
      }
      setPrevValue(result);
      setDisplay(String(Number(result.toFixed(6))));
    }

    setWaitingForOperand(true);
    setOperator(nextOperator);
  };

  const handleEquals = () => {
    if (!operator || prevValue === null) return;
    performOperation(operator);
    setOperator(null);
  };

  return (
    <div className="flex-1 flex flex-col bg-[#1c0218] text-white p-4 select-none">
      {/* Display */}
      <div className="flex-1 flex flex-col justify-end p-4 rounded-2xl bg-black/40 border border-white/5 mb-4 text-right">
        {operator && (
          <span className="text-xs font-mono text-[#E95420] mb-1">
            {prevValue} {operator}
          </span>
        )}
        <span className="text-4xl font-mono font-light tracking-tight truncate text-white">
          {display}
        </span>
      </div>

      {/* Button Keypad */}
      <div className="grid grid-cols-4 gap-2.5">
        <button
          type="button"
          onClick={clear}
          className="h-13 rounded-2xl bg-[#5E2750] hover:bg-[#77216F] text-white font-medium text-base active:scale-95 transition-all"
        >
          AC
        </button>
        <button
          type="button"
          onClick={() => {
            sound.playTap();
            setDisplay(String(-parseFloat(display)));
          }}
          className="h-13 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-medium text-base active:scale-95 transition-all"
        >
          ±
        </button>
        <button
          type="button"
          onClick={() => {
            sound.playTap();
            setDisplay(String(parseFloat(display) / 100));
          }}
          className="h-13 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-medium text-base active:scale-95 transition-all"
        >
          %
        </button>
        <button
          type="button"
          onClick={() => performOperation('÷')}
          className={`h-13 rounded-2xl ${
            operator === '÷' ? 'bg-white text-[#E95420]' : 'bg-[#E95420] hover:bg-[#c93e0d] text-white'
          } font-bold text-lg active:scale-95 transition-all flex items-center justify-center`}
        >
          <Divide size={20} />
        </button>

        {['7', '8', '9'].map((d) => (
          <button
            key={d}
            type="button"
            onClick={() => inputDigit(d)}
            className="h-13 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-medium text-xl active:scale-95 transition-all"
          >
            {d}
          </button>
        ))}
        <button
          type="button"
          onClick={() => performOperation('×')}
          className={`h-13 rounded-2xl ${
            operator === '×' ? 'bg-white text-[#E95420]' : 'bg-[#E95420] hover:bg-[#c93e0d] text-white'
          } font-bold text-lg active:scale-95 transition-all flex items-center justify-center`}
        >
          <X size={20} />
        </button>

        {['4', '5', '6'].map((d) => (
          <button
            key={d}
            type="button"
            onClick={() => inputDigit(d)}
            className="h-13 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-medium text-xl active:scale-95 transition-all"
          >
            {d}
          </button>
        ))}
        <button
          type="button"
          onClick={() => performOperation('-')}
          className={`h-13 rounded-2xl ${
            operator === '-' ? 'bg-white text-[#E95420]' : 'bg-[#E95420] hover:bg-[#c93e0d] text-white'
          } font-bold text-lg active:scale-95 transition-all flex items-center justify-center`}
        >
          <Minus size={20} />
        </button>

        {['1', '2', '3'].map((d) => (
          <button
            key={d}
            type="button"
            onClick={() => inputDigit(d)}
            className="h-13 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-medium text-xl active:scale-95 transition-all"
          >
            {d}
          </button>
        ))}
        <button
          type="button"
          onClick={() => performOperation('+')}
          className={`h-13 rounded-2xl ${
            operator === '+' ? 'bg-white text-[#E95420]' : 'bg-[#E95420] hover:bg-[#c93e0d] text-white'
          } font-bold text-lg active:scale-95 transition-all flex items-center justify-center`}
        >
          <Plus size={20} />
        </button>

        <button
          type="button"
          onClick={() => inputDigit('0')}
          className="col-span-2 h-13 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-medium text-xl active:scale-95 transition-all"
        >
          0
        </button>
        <button
          type="button"
          onClick={inputDecimal}
          className="h-13 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xl active:scale-95 transition-all"
        >
          .
        </button>
        <button
          type="button"
          onClick={handleEquals}
          className="h-13 rounded-2xl bg-[#E95420] hover:bg-[#c93e0d] text-white font-bold text-xl active:scale-95 transition-all flex items-center justify-center shadow-lg shadow-orange-950/40"
        >
          <Equal size={22} />
        </button>
      </div>
    </div>
  );
};
