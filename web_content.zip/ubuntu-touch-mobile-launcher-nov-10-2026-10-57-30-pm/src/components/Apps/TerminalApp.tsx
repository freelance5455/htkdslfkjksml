import React, { useState, useRef, useEffect } from 'react';
import { Terminal as TerminalIcon, CornerDownLeft, Trash2, Play } from 'lucide-react';
import { sound } from '../../utils/audio';

interface TerminalAppProps {
  initialCommand?: string;
  onClose: () => void;
}

export const TerminalApp: React.FC<TerminalAppProps> = ({ initialCommand, onClose }) => {
  const [history, setHistory] = useState<Array<{ command?: string; output: string | React.ReactNode }>>([
    {
      output: (
        <div className="text-purple-300 mb-2">
          <p className="font-bold text-white">Ubuntu 24.04 LTS (Noble Numbat) - Mobile Edition</p>
          <p className="text-xs text-white/70">Linux 6.8.0-generic aarch64 · Welcome to the command line!</p>
          <p className="text-[11px] text-emerald-400 mt-1">Type 'help', 'neofetch', 'apt update', or 'ls' to start.</p>
        </div>
      )
    }
  ]);
  const [inputVal, setInputVal] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  const executeCommand = (cmd: string) => {
    sound.playTap();
    const cleanCmd = cmd.trim();
    if (!cleanCmd) return;

    let outputNode: React.ReactNode = '';

    const lower = cleanCmd.toLowerCase();
    if (lower === 'clear') {
      setHistory([]);
      return;
    } else if (lower === 'help') {
      outputNode = (
        <div className="space-y-1 text-white/80 text-xs">
          <p className="text-emerald-400 font-semibold">Available Ubuntu commands:</p>
          <p><span className="text-[#E95420] font-mono">neofetch</span> - Display system information & ASCII mascot</p>
          <p><span className="text-[#E95420] font-mono">ls</span> - List directory contents</p>
          <p><span className="text-[#E95420] font-mono">cat &lt;file&gt;</span> - Read file contents (e.g. cat welcome.txt)</p>
          <p><span className="text-[#E95420] font-mono">uname -a</span> - Print system architecture and kernel</p>
          <p><span className="text-[#E95420] font-mono">top / htop</span> - View CPU & process telemetry</p>
          <p><span className="text-[#E95420] font-mono">apt update</span> - Simulate package cache refresh</p>
          <p><span className="text-[#E95420] font-mono">whoami</span> - Print current Linux username</p>
          <p><span className="text-[#E95420] font-mono">cowsay &lt;msg&gt;</span> - Speak with the classic ASCII cow</p>
          <p><span className="text-[#E95420] font-mono">clear</span> - Clear terminal buffer</p>
        </div>
      );
    } else if (lower === 'neofetch') {
      outputNode = (
        <div className="font-mono text-xs flex gap-3 text-left py-2">
          {/* Ubuntu ASCII Logo */}
          <pre className="text-[#E95420] font-bold text-[10px] leading-tight select-none">
{`            .-/+oossssoo+/-.
        \`:+ssssssssssssssssss+:\`
      -+ssssssssssssssssssyyssss+-
    .ossssssssssssssssssdMMMNysssso.
   /ssssssssssshdmmNNmmyNMMMMhssssss/
  +ssssssssshmydMMMMMMMNddddyssssssss+
 /sssssssshNMMMyhhyyyyhmNMMMNhssssssss/
.ssssssssdMMMNhsssssssssshNMMMdssssssss.
+sssshhhyNMMNyssssssssssssyNMMMysssssss+
ossyNMMMNyMMhsssssssssssssshmmmhssssssso
ossyNMMMNyMMhsssssssssssssshmmmhssssssso
+sssshhhyNMMNyssssssssssssyNMMMysssssss+
.ssssssssdMMMNhsssssssssshNMMMdssssssss.
 /sssssssshNMMMyhhyyyyhdNMMMNhssssssss/
  +sssssssssdmydMMMMMMMMddddyssssssss+
   /ssssssssssshdmNNNNmyNMMMMhssssss/
    .ossssssssssssssssssdMMMNysssso.
      -+sssssssssssssssssyyyssss+-
        \`:+ssssssssssssssssss+:\`
            .-/+oossssoo+/-.`}
          </pre>
          <div className="text-[11px] leading-snug space-y-0.5">
            <p><span className="text-[#E95420] font-bold">user</span>@<span className="text-[#E95420] font-bold">ubuntu-touch</span></p>
            <p className="text-white/40">---------------------</p>
            <p><span className="text-[#AEA79F]">OS:</span> Ubuntu 24.04 LTS aarch64</p>
            <p><span className="text-[#AEA79F]">Host:</span> Mobile ARM64 Touch Device</p>
            <p><span className="text-[#AEA79F]">Kernel:</span> 6.8.0-45-generic</p>
            <p><span className="text-[#AEA79F]">Uptime:</span> 3 days, 4 hours, 21 mins</p>
            <p><span className="text-[#AEA79F]">Shell:</span> bash 5.2.21</p>
            <p><span className="text-[#AEA79F]">Theme:</span> Yaru-Aubergine-Dark</p>
            <p><span className="text-[#AEA79F]">CPU:</span> Cortex-A78 (8) @ 2.80GHz</p>
            <p><span className="text-[#AEA79F]">Memory:</span> 3418MiB / 7824MiB</p>
            <div className="flex gap-1 pt-1.5">
              <span className="w-2.5 h-2.5 bg-black rounded-xs" />
              <span className="w-2.5 h-2.5 bg-red-600 rounded-xs" />
              <span className="w-2.5 h-2.5 bg-green-600 rounded-xs" />
              <span className="w-2.5 h-2.5 bg-yellow-500 rounded-xs" />
              <span className="w-2.5 h-2.5 bg-[#19B6EE] rounded-xs" />
              <span className="w-2.5 h-2.5 bg-[#77216F] rounded-xs" />
              <span className="w-2.5 h-2.5 bg-[#E95420] rounded-xs" />
            </div>
          </div>
        </div>
      );
    } else if (lower === 'ls') {
      outputNode = (
        <div className="grid grid-cols-3 gap-1 font-mono text-xs py-1">
          <span className="text-[#19B6EE] font-bold">Documents/</span>
          <span className="text-[#19B6EE] font-bold">Downloads/</span>
          <span className="text-[#19B6EE] font-bold">Pictures/</span>
          <span className="text-[#19B6EE] font-bold">Music/</span>
          <span className="text-[#38B44A] font-bold">scripts.sh*</span>
          <span className="text-white">welcome.txt</span>
          <span className="text-white">noble_notes.md</span>
        </div>
      );
    } else if (lower === 'whoami') {
      outputNode = <p className="font-mono text-emerald-400">ubuntu</p>;
    } else if (lower.startsWith('cat')) {
      const target = lower.replace('cat', '').trim();
      if (target.includes('welcome') || target === '') {
        outputNode = (
          <div className="text-white/80 font-mono text-xs leading-relaxed bg-white/5 p-2 rounded-lg">
            Welcome to Ubuntu Touch Mobile Launcher!<br />
            Built with pure Canonical Yaru design, edge-swipe gestures, and authentic Linux spirit.<br />
            Enjoy the smoother responsive system animations.
          </div>
        );
      } else if (target.includes('notes')) {
        outputNode = (
          <div className="text-white/80 font-mono text-xs">
            [x] Test swipe gestures<br />
            [x] Check Ubuntu 24.04 noble numbat wallpapers<br />
            [ ] Customize bottom dock apps
          </div>
        );
      } else {
        outputNode = <p className="text-rose-400 font-mono">cat: {target}: No such file or directory</p>;
      }
    } else if (lower === 'uname -a' || lower === 'uname -r') {
      outputNode = (
        <p className="font-mono text-xs text-white/90">
          Linux ubuntu-mobile 6.8.0-45-generic #45-Ubuntu SMP PREEMPT_DYNAMIC aarch64 GNU/Linux
        </p>
      );
    } else if (lower.startsWith('cowsay')) {
      const msg = cleanCmd.replace(/^cowsay\s*/i, '') || 'Ubuntu is awesome!';
      outputNode = (
        <pre className="font-mono text-xs text-amber-300 leading-tight">
{`  _____________________________
< ${msg} >
  -----------------------------
        \\   ^__^
         \\  (oo)\\_______
            (__)\\       )\\/\\
                ||----w |
                ||     ||`}
        </pre>
      );
    } else if (lower.includes('apt update') || lower.includes('apt-get update')) {
      outputNode = (
        <div className="font-mono text-xs text-white/80 space-y-0.5">
          <p>Get:1 http://ports.ubuntu.com/ubuntu-ports noble InRelease [256 kB]</p>
          <p>Get:2 http://ports.ubuntu.com/ubuntu-ports noble-updates InRelease [126 kB]</p>
          <p>Get:3 http://ports.ubuntu.com/ubuntu-ports noble-security InRelease [126 kB]</p>
          <p className="text-emerald-400">Reading package lists... Done</p>
          <p className="text-emerald-400">All packages are up to date.</p>
        </div>
      );
    } else if (lower === 'date') {
      outputNode = <p className="font-mono text-xs text-white">{new Date().toString()}</p>;
    } else if (lower === 'top' || lower === 'htop') {
      outputNode = (
        <div className="font-mono text-xs space-y-1 text-white/80">
          <p className="text-emerald-400">Tasks: 184 total, 1 running, 183 sleeping</p>
          <p>%Cpu(s): 12.4 us, 2.1 sy, 0.0 ni, 85.5 id</p>
          <p>MiB Mem : 7824.0 total, 4406.0 free, 3418.0 used</p>
          <div className="text-[11px] grid grid-cols-4 gap-2 text-[#AEA79F] border-t border-white/10 pt-1">
            <span>PID USER</span>
            <span>CPU%</span>
            <span>MEM%</span>
            <span>COMMAND</span>
          </div>
          <div className="text-[11px] grid grid-cols-4 gap-2 text-white/90">
            <span>1024 ubuntu</span>
            <span>4.2</span>
            <span>2.8</span>
            <span>gnome-shell</span>
          </div>
          <div className="text-[11px] grid grid-cols-4 gap-2 text-white/90">
            <span>1408 ubuntu</span>
            <span>1.8</span>
            <span>1.2</span>
            <span>pipewire</span>
          </div>
        </div>
      );
    } else {
      outputNode = (
        <p className="font-mono text-xs text-rose-400">
          bash: {cleanCmd}: command not found. Type 'help' for available commands.
        </p>
      );
    }

    setHistory((prev) => [
      ...prev,
      { command: cleanCmd, output: outputNode }
    ]);
    setInputVal('');
  };

  useEffect(() => {
    if (initialCommand) {
      executeCommand(initialCommand);
    }
  }, [initialCommand]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  return (
    <div className="flex-1 flex flex-col bg-[#300A24] text-white font-mono overflow-hidden select-text">
      {/* Quick command ribbon */}
      <div className="px-3 py-1.5 bg-[#200417] border-b border-purple-900/40 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {['neofetch', 'ls', 'help', 'apt update', 'cowsay Linux Rocks!'].map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => executeCommand(c)}
            className="px-2 py-0.5 rounded text-[11px] bg-purple-900/40 hover:bg-[#E95420] text-purple-200 hover:text-white transition-colors shrink-0"
          >
            {c}
          </button>
        ))}
        <button
          type="button"
          onClick={() => setHistory([])}
          className="ml-auto p-1 text-white/40 hover:text-white"
          title="Clear"
        >
          <Trash2 size={13} />
        </button>
      </div>

      {/* Output Console */}
      <div className="flex-1 p-3.5 overflow-y-auto space-y-3 font-mono text-xs">
        {history.map((item, i) => (
          <div key={i} className="space-y-1">
            {item.command && (
              <div className="flex items-center gap-1.5 text-white/90">
                <span className="text-[#38B44A]">ubuntu@touch:~$</span>
                <span className="text-white font-semibold">{item.command}</span>
              </div>
            )}
            <div>{item.output}</div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          executeCommand(inputVal);
        }}
        className="p-2.5 bg-[#200417] border-t border-purple-900/50 flex items-center gap-2"
      >
        <span className="text-[#38B44A] text-xs">ubuntu@touch:~$</span>
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder="type bash command..."
          className="flex-1 bg-transparent text-white focus:outline-none text-xs font-mono"
          autoFocus
        />
        <button
          type="submit"
          className="p-1.5 rounded-lg bg-[#E95420] text-white hover:bg-[#c93e0d] active:scale-95 transition-transform"
        >
          <CornerDownLeft size={14} />
        </button>
      </form>
    </div>
  );
};
