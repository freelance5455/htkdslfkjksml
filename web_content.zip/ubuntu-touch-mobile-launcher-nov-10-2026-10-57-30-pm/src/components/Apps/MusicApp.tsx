import React, { useState } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Music as MusicIcon, Disc } from 'lucide-react';
import { sound } from '../../utils/audio';

interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
}

const PLAYLIST: Track[] = [
  { id: '1', title: 'Noble Numbat Synth', artist: 'Canonical Audio Lab', duration: '3:45' },
  { id: '2', title: 'Jammy Jellyfish Ambient', artist: 'Yaru Acoustic', duration: '4:12' },
  { id: '3', title: 'Aubergine Twilight (Lo-Fi)', artist: 'Linux Beats', duration: '2:58' },
  { id: '4', title: 'Kernel 6.8 Flow', artist: 'Tux & The Daemons', duration: '5:02' }
];

export const MusicApp: React.FC = () => {
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(42);

  const currentTrack = PLAYLIST[currentTrackIndex];

  const togglePlay = () => {
    sound.playTap();
    setIsPlaying(!isPlaying);
  };

  const nextTrack = () => {
    sound.playTap();
    setCurrentTrackIndex((prev) => (prev + 1) % PLAYLIST.length);
  };

  const prevTrack = () => {
    sound.playTap();
    setCurrentTrackIndex((prev) => (prev - 1 + PLAYLIST.length) % PLAYLIST.length);
  };

  return (
    <div className="flex-1 flex flex-col bg-gradient-to-b from-[#2C001E] via-[#46123b] to-[#170114] text-white p-4 select-none overflow-y-auto space-y-5">
      {/* Vinyl / Album Art */}
      <div className="flex flex-col items-center justify-center py-6">
        <div
          className={`relative w-44 h-44 rounded-full bg-gradient-to-tr from-[#111111] via-[#2C001E] to-[#77216F] flex items-center justify-center border-4 border-white/10 shadow-2xl transition-transform ${
            isPlaying ? 'animate-[spin_10s_linear_infinite]' : ''
          }`}
        >
          {/* Vinyl grooves */}
          <div className="w-32 h-32 rounded-full border border-white/10 flex items-center justify-center">
            <div className="w-20 h-20 rounded-full border border-white/10 flex items-center justify-center">
              <div className="w-10 h-10 rounded-full bg-[#E95420] flex items-center justify-center text-white shadow-inner">
                <Disc size={18} />
              </div>
            </div>
          </div>
        </div>

        <div className="text-center mt-5">
          <h3 className="text-base font-bold text-white tracking-tight">{currentTrack.title}</h3>
          <p className="text-xs text-[#AEA79F] mt-0.5">{currentTrack.artist}</p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-1.5 px-2">
        <div
          className="w-full bg-black/40 h-1.5 rounded-full overflow-hidden cursor-pointer"
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const pos = ((e.clientX - rect.left) / rect.width) * 100;
            setProgress(Math.round(pos));
          }}
        >
          <div className="bg-[#E95420] h-full transition-all" style={{ width: `${progress}%` }} />
        </div>
        <div className="flex justify-between text-[10px] font-mono text-[#AEA79F]">
          <span>1:28</span>
          <span>{currentTrack.duration}</span>
        </div>
      </div>

      {/* Transport Controls */}
      <div className="flex items-center justify-center gap-6 py-2">
        <button
          type="button"
          onClick={prevTrack}
          className="p-2 text-white/80 hover:text-white active:scale-90 transition-transform"
        >
          <SkipBack size={24} />
        </button>

        <button
          type="button"
          onClick={togglePlay}
          className="w-14 h-14 rounded-full bg-[#E95420] hover:bg-[#d03d09] text-white flex items-center justify-center shadow-lg shadow-orange-950/40 active:scale-95 transition-transform"
        >
          {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="ml-0.5" />}
        </button>

        <button
          type="button"
          onClick={nextTrack}
          className="p-2 text-white/80 hover:text-white active:scale-90 transition-transform"
        >
          <SkipForward size={24} />
        </button>
      </div>

      {/* Playlist */}
      <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
        <h4 className="text-xs font-bold uppercase tracking-wider text-[#AEA79F]">Ubuntu Library</h4>
        <div className="divide-y divide-white/5">
          {PLAYLIST.map((t, idx) => (
            <div
              key={t.id}
              onClick={() => {
                sound.playTap();
                setCurrentTrackIndex(idx);
                setIsPlaying(true);
              }}
              className={`py-2 px-2 flex items-center justify-between text-xs rounded-lg cursor-pointer transition-colors ${
                currentTrackIndex === idx ? 'bg-[#77216F]/40 text-[#E95420] font-semibold' : 'hover:bg-white/5 text-white/80'
              }`}
            >
              <div className="flex items-center gap-2 truncate">
                <span className="font-mono text-[10px] opacity-60 w-3">{idx + 1}</span>
                <span className="truncate">{t.title}</span>
              </div>
              <span className="font-mono text-[10px] opacity-60">{t.duration}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
