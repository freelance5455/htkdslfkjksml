import React from 'react';
import { Palette, Sliders, Layout, Lock, Volume2, Info, Check, Image as ImageIcon } from 'lucide-react';
import { LauncherSettings, YaruTheme, AccentColor, IconShape, DockPosition } from '../../types/launcher';
import { WALLPAPERS } from '../../data/wallpapers';
import { sound } from '../../utils/audio';

interface SettingsAppProps {
  settings: LauncherSettings;
  onUpdateSettings: (updates: Partial<LauncherSettings>) => void;
  onOpenEditModal: () => void;
}

export const SettingsApp: React.FC<SettingsAppProps> = ({
  settings,
  onUpdateSettings,
  onOpenEditModal
}) => {
  const accentColors: { id: AccentColor; hex: string; label: string }[] = [
    { id: 'orange', hex: '#E95420', label: 'Ubuntu Orange' },
    { id: 'aubergine', hex: '#77216F', label: 'Canonical Aubergine' },
    { id: 'green', hex: '#38B44A', label: 'Sage Green' },
    { id: 'blue', hex: '#19B6EE', label: 'Prussian Blue' },
    { id: 'bark', hex: '#7B5B49', label: 'Bark Mocha' }
  ];

  return (
    <div className="flex-1 flex flex-col bg-[#1A0B18] text-white select-none overflow-y-auto p-4 space-y-6">
      {/* Section: Appearance */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Palette size={16} className="text-[#E95420]" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-white">Yaru Appearance</h4>
        </div>

        <div className="space-y-3">
          {/* Theme selector */}
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <span className="text-xs font-medium text-white">Theme Variant</span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'classic', label: 'Aubergine' },
                { id: 'dark', label: 'Yaru Dark' },
                { id: 'light', label: 'Yaru Light' }
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    sound.playTap();
                    onUpdateSettings({ theme: t.id as YaruTheme });
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-medium border transition-colors ${
                    settings.theme === t.id
                      ? 'bg-[#E95420] border-[#E95420] text-white shadow-sm'
                      : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Accent Color */}
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <span className="text-xs font-medium text-white">Accent Color</span>
            <div className="flex items-center gap-2">
              {accentColors.map((col) => (
                <button
                  key={col.id}
                  type="button"
                  onClick={() => {
                    sound.playTap();
                    onUpdateSettings({ accentColor: col.id });
                  }}
                  className={`w-7 h-7 rounded-full flex items-center justify-center transition-transform ${
                    settings.accentColor === col.id ? 'ring-2 ring-white scale-110' : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: col.hex }}
                  title={col.label}
                >
                  {settings.accentColor === col.id && <Check size={12} className="text-white" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Section: Wallpaper */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <ImageIcon size={16} className="text-[#E95420]" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Background Wallpaper</h4>
          </div>
          <button
            type="button"
            onClick={() => {
              sound.playTap();
              onOpenEditModal();
            }}
            className="text-xs text-[#E95420] hover:underline"
          >
            Customize
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          {WALLPAPERS.slice(0, 3).map((wp) => (
            <button
              key={wp.id}
              type="button"
              onClick={() => {
                sound.playTap();
                onUpdateSettings({ wallpaperId: wp.id });
              }}
              className={`relative aspect-[9/16] rounded-xl overflow-hidden border-2 transition-all ${
                settings.wallpaperId === wp.id
                  ? 'border-[#E95420] ring-2 ring-[#E95420]/40'
                  : 'border-white/10 hover:border-white/30'
              }`}
            >
              <img
                src={wp.thumbnail}
                alt={wp.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-x-0 bottom-0 p-1 bg-black/70 text-[10px] text-white truncate text-left">
                {wp.name}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Section: Gestures & Behavior */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Sliders size={16} className="text-[#E95420]" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-white">Gestures & System</h4>
        </div>

        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <div className="pr-2">
              <p className="text-xs font-medium text-white">Ubuntu Touch Left Edge Dock</p>
              <p className="text-[11px] text-white/50">Swipe from left border to reveal dock</p>
            </div>
            <span className="text-xs text-emerald-400 font-mono">Active</span>
          </div>

          <div className="border-t border-white/10 pt-2.5 flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-white">Swipe Down for Indicator Shade</p>
              <p className="text-[11px] text-white/50">Pull from top bar or home screen</p>
            </div>
            <span className="text-xs text-emerald-400 font-mono">Active</span>
          </div>

          <div className="border-t border-white/10 pt-2.5 flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-white">Lock Screen Protection</p>
              <p className="text-[11px] text-white/50">Ubuntu Touch welcome clock ring</p>
            </div>
            <input
              type="checkbox"
              checked={settings.lockScreenEnabled}
              onChange={(e) => onUpdateSettings({ lockScreenEnabled: e.target.checked })}
              className="w-4 h-4 accent-[#E95420]"
            />
          </div>
        </div>
      </div>

      {/* Section: About */}
      <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
        <div className="flex items-center gap-2">
          <Info size={16} className="text-[#AEA79F]" />
          <h5 className="text-xs font-semibold text-white">About Ubuntu Touch Launcher</h5>
        </div>
        <p className="text-xs text-white/70 leading-relaxed">
          Inspired by Canonical Ubuntu Touch, Unity Desktop, and Nova Launcher customizability.
          Featuring lightweight zero-dependency architecture and responsive system animations.
        </p>
        <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-[#AEA79F] font-mono">
          <span>Version: 24.04-mobile</span>
          <span>Engine: React 19 + Motion</span>
        </div>
      </div>
    </div>
  );
};
