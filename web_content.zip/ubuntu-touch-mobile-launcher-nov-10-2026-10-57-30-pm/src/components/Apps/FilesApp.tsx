import React, { useState } from 'react';
import { Folder, FileText, Image as ImageIcon, Music, Terminal, ChevronRight, ArrowLeft } from 'lucide-react';
import { sound } from '../../utils/audio';

interface FileEntry {
  name: string;
  type: 'folder' | 'file';
  size?: string;
  ext?: string;
  content?: string;
}

const FILE_SYSTEM: Record<string, FileEntry[]> = {
  '/home/ubuntu': [
    { name: 'Documents', type: 'folder' },
    { name: 'Downloads', type: 'folder' },
    { name: 'Pictures', type: 'folder' },
    { name: 'Music', type: 'folder' },
    { name: 'Scripts', type: 'folder' },
    { name: 'welcome_to_ubuntu.txt', type: 'file', size: '1.2 KB', ext: 'txt', content: 'Welcome to Ubuntu Touch! A truly open, lightweight, gesture-driven Linux mobile launcher.' },
    { name: 'noble_specs.md', type: 'file', size: '3.4 KB', ext: 'md', content: '# Ubuntu 24.04 LTS Mobile\n- Kernel: Linux 6.8\n- Yaru Dark & Aubergine\n- Nova Customizer' }
  ],
  '/home/ubuntu/Documents': [
    { name: 'Kernel_Notes.txt', type: 'file', size: '2.1 KB', ext: 'txt', content: 'Linux Kernel 6.8.0-45-generic arm64 optimizations applied.' },
    { name: 'todo.md', type: 'file', size: '820 B', ext: 'md', content: '1. Swipe up for Ubuntu Dash\n2. Swipe left edge for Dock\n3. Pull down for Indicator shade' }
  ],
  '/home/ubuntu/Downloads': [
    { name: 'noble-numbat-arm64.iso', type: 'file', size: '3.8 GB', ext: 'iso' },
    { name: 'yaru-theme-update.tar.gz', type: 'file', size: '14.2 MB', ext: 'tar' }
  ],
  '/home/ubuntu/Pictures': [
    { name: 'noble_numbat_origami.jpg', type: 'file', size: '1.4 MB', ext: 'jpg' },
    { name: 'jammy_jellyfish_glow.jpg', type: 'file', size: '2.1 MB', ext: 'jpg' },
    { name: 'focal_fossa_dusk.jpg', type: 'file', size: '1.8 MB', ext: 'jpg' }
  ],
  '/home/ubuntu/Music': [
    { name: 'ubuntu_startup_sound.ogg', type: 'file', size: '420 KB', ext: 'ogg' },
    { name: 'canonical_ambient_synth.flac', type: 'file', size: '24.1 MB', ext: 'flac' }
  ],
  '/home/ubuntu/Scripts': [
    { name: 'backup_home.sh', type: 'file', size: '512 B', ext: 'sh', content: '#!/bin/bash\nrsync -av /home/ubuntu/ /media/backup/' },
    { name: 'sys_clean.sh', type: 'file', size: '240 B', ext: 'sh', content: '#!/bin/bash\nsudo apt autoremove -y && sudo apt clean' }
  ]
};

export const FilesApp: React.FC = () => {
  const [currentPath, setCurrentPath] = useState<string>('/home/ubuntu');
  const [selectedFile, setSelectedFile] = useState<FileEntry | null>(null);

  const entries = FILE_SYSTEM[currentPath] || [];

  const handleOpenEntry = (entry: FileEntry) => {
    sound.playTap();
    if (entry.type === 'folder') {
      setCurrentPath(`${currentPath}/${entry.name}`);
      setSelectedFile(null);
    } else {
      setSelectedFile(entry);
    }
  };

  const handleGoBack = () => {
    sound.playTap();
    if (selectedFile) {
      setSelectedFile(null);
      return;
    }
    const parts = currentPath.split('/');
    if (parts.length > 3) {
      parts.pop();
      setCurrentPath(parts.join('/'));
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#1E1E1E] text-white select-none overflow-hidden">
      {/* Path Breadcrumb Bar */}
      <div className="px-3.5 py-2.5 bg-[#252525] border-b border-white/10 flex items-center gap-2">
        {currentPath !== '/home/ubuntu' || selectedFile ? (
          <button
            type="button"
            onClick={handleGoBack}
            className="p-1 rounded hover:bg-white/10 text-white/80 hover:text-white"
          >
            <ArrowLeft size={16} />
          </button>
        ) : null}
        <div className="flex items-center gap-1 text-xs font-mono text-[#AEA79F] truncate">
          <span>{currentPath}</span>
          {selectedFile && (
            <>
              <ChevronRight size={12} />
              <span className="text-white font-medium">{selectedFile.name}</span>
            </>
          )}
        </div>
      </div>

      {/* Main Area */}
      <div className="flex-1 overflow-y-auto p-3">
        {selectedFile ? (
          <div className="p-4 rounded-xl bg-black/30 border border-white/10 space-y-3 font-mono">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-sm font-semibold text-[#E95420]">{selectedFile.name}</span>
              <span className="text-xs text-white/50">{selectedFile.size}</span>
            </div>
            <pre className="text-xs text-white/80 whitespace-pre-wrap leading-relaxed select-text font-mono">
              {selectedFile.content || `[Binary File: ${selectedFile.ext} archive or media preview]`}
            </pre>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2.5">
            {entries.map((entry) => (
              <button
                key={entry.name}
                type="button"
                onClick={() => handleOpenEntry(entry)}
                className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/5 hover:bg-white/10 active:scale-95 transition-all group"
              >
                {entry.type === 'folder' ? (
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#E95420] to-[#c93f0e] flex items-center justify-center text-white shadow-sm mb-1.5 group-hover:scale-105 transition-transform">
                    <Folder size={24} fill="currentColor" opacity={0.9} />
                  </div>
                ) : entry.ext === 'jpg' || entry.ext === 'png' ? (
                  <div className="w-12 h-12 rounded-xl bg-purple-900/60 flex items-center justify-center text-purple-300 shadow-sm mb-1.5">
                    <ImageIcon size={22} />
                  </div>
                ) : entry.ext === 'ogg' || entry.ext === 'flac' ? (
                  <div className="w-12 h-12 rounded-xl bg-[#77216F] flex items-center justify-center text-white shadow-sm mb-1.5">
                    <Music size={22} />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-white/80 shadow-sm mb-1.5">
                    <FileText size={22} />
                  </div>
                )}
                <span className="text-xs font-medium text-white/90 truncate w-full text-center">
                  {entry.name}
                </span>
                {entry.size && (
                  <span className="text-[10px] text-white/40 font-mono mt-0.5">{entry.size}</span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
