import React from 'react';
import { HelpCircle, Smartphone, Sliders, Terminal, MousePointer } from 'lucide-react';

export const GuideApp: React.FC = () => {
  return (
    <div className="flex-1 flex flex-col bg-[#1A0B18] text-white p-4 select-none overflow-y-auto space-y-4 leading-relaxed">
      <div className="text-center py-3 border-b border-white/10">
        <h3 className="text-base font-bold text-white">Ubuntu Touch Launcher Guide</h3>
        <p className="text-xs text-[#AEA79F] mt-0.5">Gestures, shortcuts, and Nova customizer</p>
      </div>

      <div className="space-y-3 text-xs">
        {/* Gestures Card */}
        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
          <div className="flex items-center gap-2 text-[#E95420] font-bold">
            <Smartphone size={16} />
            <span>Essential Touch Gestures</span>
          </div>
          <ul className="space-y-1.5 text-white/80 list-disc list-inside">
            <li><strong className="text-white">Swipe Down from Top:</strong> Opens the Ubuntu Indicator Shade with Quick Toggles, volume/brightness sliders, and notifications.</li>
            <li><strong className="text-white">Swipe Up from Bottom:</strong> Opens the Ubuntu Dash & App Drawer with real-time app search.</li>
            <li><strong className="text-white">Swipe Left Edge:</strong> Slides out the iconic Ubuntu Touch vertical dock with running app indicators.</li>
            <li><strong className="text-white">Long Press Desktop:</strong> Launches Nova-style Launcher Customizer (wallpapers, icon shapes, dock mode).</li>
          </ul>
        </div>

        {/* Customization Card */}
        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
          <div className="flex items-center gap-2 text-[#19B6EE] font-bold">
            <Sliders size={16} />
            <span>Nova-Grade Customization</span>
          </div>
          <p className="text-white/80">
            Switch between official Ubuntu 24.04 Noble Numbat, 22.04 Jammy Jellyfish, and 20.04 Focal Fossa mascots, change icon shapes (Squircle, Circle, Rounded, Square), and choose between Left Edge Dock, Bottom Dock, or both.
          </p>
        </div>

        {/* Terminal Card */}
        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
          <div className="flex items-center gap-2 text-[#38B44A] font-bold">
            <Terminal size={16} />
            <span>Integrated Linux Command Line</span>
          </div>
          <p className="text-white/80">
            Open the Terminal app or quick command bar to run real simulated bash commands: <code className="text-[#E95420]">neofetch</code>, <code className="text-[#E95420]">apt update</code>, <code className="text-[#E95420]">top</code>, and <code className="text-[#E95420]">cowsay</code>!
          </p>
        </div>
      </div>
    </div>
  );
};
