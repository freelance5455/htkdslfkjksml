import React from 'react';
import { CloudSun, Wind, Droplets, Compass, Sun, CloudRain } from 'lucide-react';

export const WeatherApp: React.FC = () => {
  const forecast = [
    { day: 'Fri', temp: '22°', min: '14°', icon: CloudSun, cond: 'Partly Sunny' },
    { day: 'Sat', temp: '24°', min: '16°', icon: Sun, cond: 'Clear Sky' },
    { day: 'Sun', temp: '19°', min: '13°', icon: CloudRain, cond: 'Light Rain' },
    { day: 'Mon', temp: '21°', min: '15°', icon: CloudSun, cond: 'Scattered Clouds' },
    { day: 'Tue', temp: '23°', min: '16°', icon: Sun, cond: 'Sunny' }
  ];

  return (
    <div className="flex-1 flex flex-col bg-gradient-to-b from-[#2C001E] via-[#5E2750] to-[#1c0218] text-white p-4 select-none overflow-y-auto space-y-4">
      {/* Current Conditions Card */}
      <div className="flex flex-col items-center justify-center py-6">
        <CloudSun size={64} className="text-[#E95420] mb-2 animate-pulse" />
        <span className="text-5xl font-light font-sans text-white">22°C</span>
        <h3 className="text-sm font-semibold text-white/90 mt-1">London, UK (Canonical HQ)</h3>
        <p className="text-xs text-[#AEA79F]">Clear with pleasant aubergine twilight</p>
      </div>

      {/* Atmospheric Indicators */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex flex-col items-center text-center">
          <Wind size={16} className="text-[#19B6EE] mb-1" />
          <span className="text-[10px] text-white/50">Wind</span>
          <span className="text-xs font-semibold text-white font-mono mt-0.5">14 km/h</span>
        </div>
        <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex flex-col items-center text-center">
          <Droplets size={16} className="text-[#38B44A] mb-1" />
          <span className="text-[10px] text-white/50">Humidity</span>
          <span className="text-xs font-semibold text-white font-mono mt-0.5">58%</span>
        </div>
        <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex flex-col items-center text-center">
          <Compass size={16} className="text-[#E95420] mb-1" />
          <span className="text-[10px] text-white/50">Pressure</span>
          <span className="text-xs font-semibold text-white font-mono mt-0.5">1018 hPa</span>
        </div>
      </div>

      {/* 5-day forecast */}
      <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
        <h4 className="text-xs font-bold uppercase tracking-wider text-[#AEA79F]">5-Day Forecast</h4>
        <div className="divide-y divide-white/5">
          {forecast.map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.day} className="py-2.5 flex items-center justify-between text-xs">
                <span className="w-8 font-semibold text-white">{item.day}</span>
                <div className="flex items-center gap-2 text-white/80">
                  <Icon size={16} className="text-[#E95420]" />
                  <span className="text-[11px] text-white/60">{item.cond}</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="font-bold text-white">{item.temp}</span>
                  <span className="text-white/40">{item.min}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
