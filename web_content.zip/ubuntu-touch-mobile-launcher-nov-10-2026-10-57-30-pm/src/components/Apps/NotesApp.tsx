import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Save, FileText } from 'lucide-react';
import { sound } from '../../utils/audio';

interface Note {
  id: string;
  title: string;
  content: string;
  date: string;
}

export const NotesApp: React.FC = () => {
  const [notes, setNotes] = useState<Note[]>(() => {
    try {
      const saved = localStorage.getItem('ubuntu_launcher_notes');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [
      {
        id: '1',
        title: 'Ubuntu Touch Gestures',
        content: '• Swipe down top bar: Indicator shade & quick settings\n• Swipe up anywhere: Ubuntu Dash & app drawer\n• Swipe left edge: Launcher dock\n• Long-press desktop: Nova Launcher customizer',
        date: 'Today'
      },
      {
        id: '2',
        title: 'Linux Bash Tips',
        content: 'apt update - refreshes package index\nneofetch - shows system specs\nuname -a - prints kernel architecture',
        date: 'Yesterday'
      }
    ];
  });

  const [activeNoteId, setActiveNoteId] = useState<string>(notes[0]?.id || '');

  useEffect(() => {
    localStorage.setItem('ubuntu_launcher_notes', JSON.stringify(notes));
  }, [notes]);

  const activeNote = notes.find((n) => n.id === activeNoteId);

  const createNote = () => {
    sound.playTap();
    const newNote: Note = {
      id: Date.now().toString(),
      title: 'New Note',
      content: '',
      date: 'Just now'
    };
    setNotes([newNote, ...notes]);
    setActiveNoteId(newNote.id);
  };

  const deleteNote = (id: string) => {
    sound.playTap();
    const remaining = notes.filter((n) => n.id !== id);
    setNotes(remaining);
    if (activeNoteId === id && remaining.length > 0) {
      setActiveNoteId(remaining[0].id);
    }
  };

  const updateContent = (val: string) => {
    const lines = val.split('\n');
    const title = lines[0]?.trim() || 'Untitled Note';
    setNotes((prev) =>
      prev.map((n) => (n.id === activeNoteId ? { ...n, title, content: val } : n))
    );
  };

  return (
    <div className="flex-1 flex bg-[#1e071c] text-white overflow-hidden select-none">
      {/* Sidebar Note List */}
      <div className="w-1/3 border-r border-white/10 flex flex-col bg-[#270b24]">
        <div className="p-3 border-b border-white/10 flex items-center justify-between">
          <span className="text-xs font-bold text-white flex items-center gap-1.5">
            <FileText size={14} className="text-[#E95420]" /> Notes
          </span>
          <button
            type="button"
            onClick={createNote}
            className="p-1 rounded-lg bg-[#E95420] text-white hover:bg-[#c93e0d] active:scale-95 transition-transform"
            title="Create note"
          >
            <Plus size={14} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-white/5">
          {notes.map((n) => (
            <div
              key={n.id}
              onClick={() => {
                sound.playTap();
                setActiveNoteId(n.id);
              }}
              className={`p-3 cursor-pointer transition-colors group flex items-start justify-between ${
                activeNoteId === n.id ? 'bg-[#77216F]/40 border-l-2 border-[#E95420]' : 'hover:bg-white/5'
              }`}
            >
              <div className="min-w-0 flex-1 pr-1">
                <p className="text-xs font-medium text-white truncate">{n.title}</p>
                <p className="text-[10px] text-white/50">{n.date}</p>
              </div>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  deleteNote(n.id);
                }}
                className="opacity-0 group-hover:opacity-100 p-1 text-white/40 hover:text-rose-400 transition-opacity"
              >
                <Trash2 size={12} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Note Editor */}
      <div className="flex-1 flex flex-col p-4 bg-[#1e071c]">
        {activeNote ? (
          <textarea
            value={activeNote.content}
            onChange={(e) => updateContent(e.target.value)}
            placeholder="Write note or paste commands..."
            className="w-full flex-1 bg-transparent text-white focus:outline-none resize-none text-xs leading-relaxed font-sans placeholder-white/30"
          />
        ) : (
          <div className="flex-1 flex items-center justify-center text-xs text-white/40">
            Select or create a note
          </div>
        )}
      </div>
    </div>
  );
};
