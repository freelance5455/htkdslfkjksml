import React, { useState } from 'react';
import { ShoppingBag, Download, Check, Star, Search, ShieldCheck } from 'lucide-react';
import { sound } from '../../utils/audio';

interface SoftwareItem {
  id: string;
  name: string;
  category: string;
  version: string;
  rating: number;
  description: string;
  developer: string;
  installed: boolean;
  size: string;
}

const FEATURED_SNAPS: SoftwareItem[] = [
  {
    id: 'vlc',
    name: 'VLC Media Player',
    category: 'Media',
    version: '3.0.20',
    rating: 4.8,
    description: 'The ultimate open source multimedia player for all codecs.',
    developer: 'VideoLAN',
    installed: false,
    size: '84 MB'
  },
  {
    id: 'gimp',
    name: 'GNU Image Manipulation',
    category: 'Graphics',
    version: '2.10.36',
    rating: 4.6,
    description: 'Professional raster graphics editor and digital photo retouching.',
    developer: 'GIMP Team',
    installed: false,
    size: '142 MB'
  },
  {
    id: 'vscode',
    name: 'Visual Studio Code',
    category: 'Development',
    version: '1.95.0',
    rating: 4.9,
    description: 'Code editor redefined and optimized for building modern web apps.',
    developer: 'Microsoft & Canonical',
    installed: true,
    size: '120 MB'
  },
  {
    id: 'blender',
    name: 'Blender 3D Suite',
    category: 'Development',
    version: '4.2.1',
    rating: 4.9,
    description: 'Open source 3D creation suite: modeling, rigging, rendering.',
    developer: 'Blender Foundation',
    installed: false,
    size: '310 MB'
  },
  {
    id: 'telegram',
    name: 'Telegram Desktop',
    category: 'Internet',
    version: '5.4.1',
    rating: 4.7,
    description: 'Fast, secure messaging app synchronized across all devices.',
    developer: 'Telegram FZ-LLC',
    installed: true,
    size: '65 MB'
  }
];

export const SoftwareCenterApp: React.FC = () => {
  const [apps, setApps] = useState<SoftwareItem[]>(FEATURED_SNAPS);
  const [activeTab, setActiveTab] = useState<'explore' | 'installed' | 'updates'>('explore');
  const [installingId, setInstallingId] = useState<string | null>(null);

  const toggleInstall = (id: string) => {
    sound.playTap();
    setInstallingId(id);
    setTimeout(() => {
      setApps((prev) =>
        prev.map((app) => (app.id === id ? { ...app, installed: !app.installed } : app))
      );
      setInstallingId(null);
      sound.playNotification();
    }, 1200);
  };

  const displayed = activeTab === 'installed' ? apps.filter((a) => a.installed) : apps;

  return (
    <div className="flex-1 flex flex-col bg-[#1A0B18] text-white select-none overflow-hidden">
      {/* Header bar */}
      <div className="p-4 bg-[#2C001E] border-b border-orange-500/20 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#E95420] flex items-center justify-center text-white">
            <ShoppingBag size={18} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Ubuntu Software</h3>
            <p className="text-[11px] text-[#AEA79F]">Snap store & Debian packages</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-black/40 p-1 rounded-lg">
          <button
            type="button"
            onClick={() => setActiveTab('explore')}
            className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
              activeTab === 'explore' ? 'bg-[#E95420] text-white' : 'text-white/60 hover:text-white'
            }`}
          >
            Explore
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('installed')}
            className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
              activeTab === 'installed' ? 'bg-[#E95420] text-white' : 'text-white/60 hover:text-white'
            }`}
          >
            Installed ({apps.filter((a) => a.installed).length})
          </button>
        </div>
      </div>

      {/* Snap list */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {displayed.map((app) => {
          const isBusy = installingId === app.id;
          return (
            <div
              key={app.id}
              className="p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors flex items-center justify-between gap-3"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <h4 className="text-sm font-semibold text-white truncate">{app.name}</h4>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-[#AEA79F] font-mono">
                    v{app.version}
                  </span>
                  <div className="flex items-center gap-0.5 text-amber-400 text-[11px] font-medium ml-1">
                    <Star size={11} fill="currentColor" />
                    <span>{app.rating}</span>
                  </div>
                </div>
                <p className="text-xs text-white/70 line-clamp-1">{app.description}</p>
                <div className="flex items-center gap-3 mt-1.5 text-[11px] text-[#AEA79F]">
                  <span className="flex items-center gap-1 text-emerald-400">
                    <ShieldCheck size={12} /> Verified Snap
                  </span>
                  <span>·</span>
                  <span>{app.developer}</span>
                  <span>·</span>
                  <span>{app.size}</span>
                </div>
              </div>

              <button
                type="button"
                disabled={isBusy}
                onClick={() => toggleInstall(app.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 flex items-center gap-1.5 transition-all active:scale-95 ${
                  app.installed
                    ? 'bg-white/10 text-white/80 hover:bg-rose-500/20 hover:text-rose-300'
                    : 'bg-[#E95420] hover:bg-[#c93e0d] text-white shadow-md'
                }`}
              >
                {isBusy ? (
                  <span className="animate-spin text-xs">⟳ Installing...</span>
                ) : app.installed ? (
                  <>
                    <Check size={13} className="text-emerald-400" /> Installed
                  </>
                ) : (
                  <>
                    <Download size={13} /> Install
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
