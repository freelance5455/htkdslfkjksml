import React, { useState, useEffect } from 'react';
import { Activity, Cpu, HardDrive, Server, XCircle } from 'lucide-react';
import { sound } from '../../utils/audio';

interface ProcessItem {
  pid: number;
  name: string;
  user: string;
  cpu: number;
  mem: string;
}

const INITIAL_PROCESSES: ProcessItem[] = [
  { pid: 1042, name: 'gnome-shell', user: 'ubuntu', cpu: 4.8, mem: '340 MB' },
  { pid: 1120, name: 'pipewire', user: 'ubuntu', cpu: 1.2, mem: '84 MB' },
  { pid: 1450, name: 'systemd', user: 'root', cpu: 0.1, mem: '32 MB' },
  { pid: 1823, name: 'firefox-bin', user: 'ubuntu', cpu: 3.6, mem: '512 MB' },
  { pid: 2104, name: 'snapd', user: 'root', cpu: 0.4, mem: '96 MB' },
  { pid: 2489, name: 'bash', user: 'ubuntu', cpu: 0.2, mem: '18 MB' },
  { pid: 3012, name: 'yaru-compositor', user: 'ubuntu', cpu: 2.1, mem: '148 MB' }
];

export const SystemMonitorApp: React.FC = () => {
  const [processes, setProcesses] = useState<ProcessItem[]>(INITIAL_PROCESSES);
  const [cpuHistory, setCpuHistory] = useState<number[]>([15, 22, 18, 30, 24, 19, 28, 22, 20]);

  useEffect(() => {
    const timer = setInterval(() => {
      const nextVal = Math.min(80, Math.max(10, Math.round(20 + (Math.random() * 20 - 10))));
      setCpuHistory((prev) => [...prev.slice(1), nextVal]);

      setProcesses((prev) =>
        prev.map((p) => ({
          ...p,
          cpu: Number(Math.max(0.1, p.cpu + (Math.random() * 0.8 - 0.4)).toFixed(1))
        }))
      );
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  const killProcess = (pid: number) => {
    sound.playTap();
    setProcesses((prev) => prev.filter((p) => p.pid !== pid));
  };

  return (
    <div className="flex-1 flex flex-col bg-[#1A0B18] text-white select-none overflow-hidden">
      {/* Top Resource Graph */}
      <div className="p-4 bg-[#2C001E] border-b border-orange-500/20 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity size={16} className="text-[#38B44A]" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">CPU History (8-Cores)</span>
          </div>
          <span className="text-xs font-mono text-[#E95420] font-bold">
            {cpuHistory[cpuHistory.length - 1]}%
          </span>
        </div>

        {/* Live SVG Graph Wave */}
        <div className="h-16 w-full bg-black/40 rounded-xl p-1 flex items-end gap-1.5 border border-white/5 overflow-hidden">
          {cpuHistory.map((val, idx) => (
            <div
              key={idx}
              className="flex-1 bg-gradient-to-t from-[#E95420] to-[#77216F] rounded-t-sm transition-all duration-500"
              style={{ height: `${val}%` }}
            />
          ))}
        </div>
      </div>

      {/* Process Table */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-4 py-2 bg-black/30 border-b border-white/10 grid grid-cols-5 text-[10px] font-mono text-[#AEA79F] uppercase">
          <span className="col-span-2">Process</span>
          <span>PID</span>
          <span>CPU%</span>
          <span className="text-right">Action</span>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-white/5">
          {processes.map((proc) => (
            <div
              key={proc.pid}
              className="px-4 py-2.5 grid grid-cols-5 items-center text-xs hover:bg-white/5 transition-colors font-mono"
            >
              <div className="col-span-2 truncate">
                <p className="font-semibold text-white truncate">{proc.name}</p>
                <p className="text-[10px] text-white/50">{proc.mem}</p>
              </div>
              <span className="text-white/70">{proc.pid}</span>
              <span className="text-emerald-400 font-bold">{proc.cpu}%</span>
              <div className="text-right">
                <button
                  type="button"
                  onClick={() => killProcess(proc.pid)}
                  className="p-1 text-white/40 hover:text-rose-400 active:scale-95 transition-colors"
                  title="Kill process"
                >
                  <XCircle size={15} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
