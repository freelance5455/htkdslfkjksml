import React, { useState } from 'react';
import { Globe, ArrowLeft, ArrowRight, RotateCw, Search, Bookmark, ExternalLink } from 'lucide-react';
import { sound } from '../../utils/audio';

const SPEED_DIAL = [
  { name: 'Ubuntu.com', url: 'https://ubuntu.com', desc: 'Canonical official homepage', tag: 'OS' },
  { name: 'Ubuntu Wiki', url: 'https://wiki.ubuntu.com', desc: 'Community guides & documentation', tag: 'Docs' },
  { name: 'Ubuntu Insights', url: 'https://ubuntu.com/blog', desc: 'Cloud, Server & Desktop news', tag: 'Blog' },
  { name: 'Ask Ubuntu', url: 'https://askubuntu.com', desc: 'Community Q&A and support', tag: 'Help' },
  { name: 'Ubuntu Touch', url: 'https://ubports.com', desc: 'UBports mobile Linux OS', tag: 'Mobile' },
  { name: 'Snapcraft', url: 'https://snapcraft.io', desc: 'App store for Linux', tag: 'Snaps' }
];

export const BrowserApp: React.FC = () => {
  const [urlInput, setUrlInput] = useState('https://ubuntu.com');
  const [activeSite, setActiveSite] = useState<string | null>(null);

  const handleNavigate = (url: string) => {
    sound.playTap();
    setUrlInput(url);
    setActiveSite(url);
  };

  return (
    <div className="flex-1 flex flex-col bg-[#1A0B18] text-white select-none overflow-hidden">
      {/* Address Bar */}
      <div className="p-2.5 bg-[#2C001E] border-b border-orange-500/20 flex items-center gap-2">
        <button
          type="button"
          onClick={() => {
            sound.playTap();
            setActiveSite(null);
          }}
          className="p-1 rounded text-white/70 hover:text-white"
          title="Home"
        >
          <ArrowLeft size={16} />
        </button>

        <div className="flex-1 relative flex items-center">
          <Globe size={14} className="absolute left-2.5 text-[#E95420]" />
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-black/40 rounded-xl border border-white/10 text-xs font-mono text-white placeholder-white/30 focus:outline-none focus:border-[#E95420]"
          />
        </div>

        <button
          type="button"
          onClick={() => handleNavigate(urlInput)}
          className="p-1.5 rounded-lg bg-[#E95420] text-white hover:bg-[#c93e0d]"
        >
          <RotateCw size={14} />
        </button>
      </div>

      {/* Browser View */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeSite ? (
          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 space-y-4 text-center">
            <Globe size={36} className="mx-auto text-[#E95420] animate-pulse" />
            <div>
              <h4 className="text-base font-bold text-white">{urlInput}</h4>
              <p className="text-xs text-white/60 mt-1">
                Ubuntu Web Secure Sandbox Environment
              </p>
            </div>
            <div className="p-4 rounded-xl bg-black/40 text-xs text-[#AEA79F] leading-relaxed text-left font-mono">
              GET {activeSite} HTTP/2<br />
              Status: 200 OK<br />
              Security: TLS 1.3 Strict-Transport-Security<br />
              Rendering engine: Gecko / WebKit Touch
            </div>
            <button
              type="button"
              onClick={() => setActiveSite(null)}
              className="px-4 py-2 rounded-xl bg-white/10 text-xs font-semibold hover:bg-white/15"
            >
              Return to Ubuntu Bookmarks
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#AEA79F] mb-3">
                Ubuntu Quick Bookmarks
              </h4>
              <div className="grid grid-cols-2 gap-2.5">
                {SPEED_DIAL.map((site) => (
                  <button
                    key={site.name}
                    type="button"
                    onClick={() => handleNavigate(site.url)}
                    className="p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-left transition-all active:scale-95 group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-white group-hover:text-[#E95420] transition-colors">
                        {site.name}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#E95420]/20 text-[#E95420] font-mono">
                        {site.tag}
                      </span>
                    </div>
                    <p className="text-[11px] text-white/60 line-clamp-1">{site.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
