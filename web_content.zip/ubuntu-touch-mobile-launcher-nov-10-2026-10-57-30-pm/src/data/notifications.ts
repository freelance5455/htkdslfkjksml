import { SystemNotification } from '../types/launcher';

export const INITIAL_NOTIFICATIONS: SystemNotification[] = [
  {
    id: 'notif_1',
    appName: 'Ubuntu Software',
    appIcon: 'ShoppingBag',
    title: 'System Updates Available',
    body: 'Linux kernel 6.8.0-45-generic and 12 snap packages are ready for update.',
    time: '12m ago',
    unread: true,
    accentColor: '#E95420'
  },
  {
    id: 'notif_2',
    appName: 'Terminal',
    appIcon: 'Terminal',
    title: 'Background task finished',
    body: 'rsync backup to /media/user/backup completed successfully (14.2 GB transferred).',
    time: '45m ago',
    unread: true,
    accentColor: '#77216F'
  },
  {
    id: 'notif_3',
    appName: 'Calendar',
    appIcon: 'Calendar',
    title: 'Ubuntu Release Party',
    body: 'Starts in 1 hour · Linux Community Discord & Jitsi Meet',
    time: '1h ago',
    unread: false,
    accentColor: '#19B6EE'
  }
];
