import { WallpaperOption } from '../types/launcher';

export const WALLPAPERS: WallpaperOption[] = [
  {
    id: 'noble_numbat',
    name: 'Noble Numbat (24.04)',
    thumbnail: '/src/assets/images/ubuntu_mascot_noble_numbat_1794329336672.jpg',
    url: '/src/assets/images/ubuntu_mascot_noble_numbat_1794329336672.jpg',
    type: 'image',
    tag: 'Official Mascot'
  },
  {
    id: 'jammy_jellyfish',
    name: 'Jammy Jellyfish (22.04)',
    thumbnail: '/src/assets/images/ubuntu_mascot_jammy_jellyfish_1794329337827.jpg',
    url: '/src/assets/images/ubuntu_mascot_jammy_jellyfish_1794329337827.jpg',
    type: 'image',
    tag: 'Official Mascot'
  },
  {
    id: 'focal_fossa',
    name: 'Focal Fossa (20.04)',
    thumbnail: '/src/assets/images/ubuntu_mascot_focal_fossa_1794329337046.jpg',
    url: '/src/assets/images/ubuntu_mascot_focal_fossa_1794329337046.jpg',
    type: 'image',
    tag: 'Official Mascot'
  },
  {
    id: 'classic_aubergine',
    name: 'Canonical Aubergine',
    thumbnail: '',
    url: 'radial-gradient(ellipse at 50% 100%, #77216F 0%, #2C001E 70%)',
    type: 'gradient',
    tag: 'Classic Gradient'
  },
  {
    id: 'ubuntu_dawn',
    name: 'Ubuntu Dawn & Orange',
    thumbnail: '',
    url: 'linear-gradient(145deg, #2C001E 0%, #5E2750 45%, #E95420 100%)',
    type: 'gradient',
    tag: 'Sunrise'
  },
  {
    id: 'yaru_dark_minimal',
    name: 'Yaru Dark Graphite',
    thumbnail: '',
    url: 'radial-gradient(circle at 50% 30%, #302434 0%, #17111A 85%)',
    type: 'gradient',
    tag: 'Minimal Dark'
  }
];
