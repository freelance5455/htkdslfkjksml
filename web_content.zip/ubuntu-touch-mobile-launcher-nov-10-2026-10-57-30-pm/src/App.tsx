/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Maximize2,
  Lock,
  RotateCcw,
  Sliders,
  Terminal,
  Folder,
  ShoppingBag,
  SlidersHorizontal,
  Globe,
  Music,
  Activity,
  Calculator,
  FileText,
  CloudSun,
  HelpCircle
} from 'lucide-react';
import { AppItem, LauncherSettings, SystemNotification } from './types/launcher';
import { INITIAL_APPS } from './data/initialApps';
import { WALLPAPERS } from './data/wallpapers';
import { INITIAL_NOTIFICATIONS } from './data/notifications';
import { StatusBar } from './components/StatusBar';
import { NotificationShade } from './components/NotificationShade';
import { EdgeDock } from './components/EdgeDock';
import { HomeScreen } from './components/HomeScreen';
import { AppDrawer } from './components/AppDrawer';
import { LockScreen } from './components/LockScreen';
import { HomeEditModal } from './components/Modals/HomeEditModal';
import { AppWindowModal } from './components/AppWindowModal';

// Interactive Apps
import { TerminalApp } from './components/Apps/TerminalApp';
import { SoftwareCenterApp } from './components/Apps/SoftwareCenterApp';
import { FilesApp } from './components/Apps/FilesApp';
import { CalculatorApp } from './components/Apps/CalculatorApp';
import { NotesApp } from './components/Apps/NotesApp';
import { SystemMonitorApp } from './components/Apps/SystemMonitorApp';
import { SettingsApp } from './components/Apps/SettingsApp';
import { BrowserApp } from './components/Apps/BrowserApp';
import { WeatherApp } from './components/Apps/WeatherApp';
import { MusicApp } from './components/Apps/MusicApp';
import { GuideApp } from './components/Apps/GuideApp';

import { sound } from './utils/audio';

const DEFAULT_SETTINGS: LauncherSettings = {
  wallpaperId: 'noble_numbat',
  theme: 'classic',
  accentColor: 'orange',
  iconShape: 'squircle',
  dockPosition: 'both',
  dockAutoHide: false,
  gridColumns: 4,
  lockScreenEnabled: false,
  soundEnabled: true,
  showResourceWidget: true,
  showTerminalWidget: true,
  iconScale: 1.0
};

export default function App() {
  // Launcher configuration state
  const [settings, setSettings] = useState<LauncherSettings>(() => {
    try {
      const saved = localStorage.getItem('ubuntu_launcher_settings');
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {
      // fallback
    }
    return DEFAULT_SETTINGS;
  });

  // Apps state
  const [apps, setApps] = useState<AppItem[]>(() => {
    try {
      const saved = localStorage.getItem('ubuntu_launcher_apps');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_APPS;
  });

  // Notifications state
  const [notifications, setNotifications] = useState<SystemNotification[]>(INITIAL_NOTIFICATIONS);

  // System UI navigation states
  const [isOpenShade, setIsOpenShade] = useState(false);
  const [isOpenDrawer, setIsOpenDrawer] = useState(false);
  const [isOpenDock, setIsOpenDock] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [isOpenEditModal, setIsOpenEditModal] = useState(false);

  // App window management
  const [activeAppId, setActiveAppId] = useState<string | null>(null);
  const [runningApps, setRunningApps] = useState<string[]>(['terminal', 'files']);
  const [terminalInitialCmd, setTerminalInitialCmd] = useState<string | undefined>();

  // Desktop preview frame mode
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);

  // Sync settings & sound
  useEffect(() => {
    localStorage.setItem('ubuntu_launcher_settings', JSON.stringify(settings));
    sound.enabled = settings.soundEnabled;
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('ubuntu_launcher_apps', JSON.stringify(apps));
  }, [apps]);

  // Current wallpaper
  const currentWallpaper =
    WALLPAPERS.find((w) => w.id === settings.wallpaperId) || WALLPAPERS[0];

  const handleUpdateSettings = (updates: Partial<LauncherSettings>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
  };

  const handleResetDefaults = () => {
    setSettings(DEFAULT_SETTINGS);
    setApps(INITIAL_APPS);
  };

  // Launch App handler
  const handleOpenApp = (appId: string) => {
    sound.playLaunch();
    setActiveAppId(appId);
    if (!runningApps.includes(appId)) {
      setRunningApps((prev) => [...prev, appId]);
    }
  };

  const handleCloseActiveApp = () => {
    sound.playTap();
    setActiveAppId(null);
  };

  const handleOpenTerminalWithCommand = (cmd?: string) => {
    setTerminalInitialCmd(cmd);
    handleOpenApp('terminal');
  };

  // Drawer pin/home actions
  const handleTogglePinApp = (appId: string) => {
    setApps((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, isPinnedToDock: !a.isPinnedToDock } : a))
    );
  };

  const handleAddToHomeScreen = (appId: string) => {
    setApps((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, isOnHomeScreen: true } : a))
    );
  };

  // Global Keyboard shortcuts (Super key, Esc, Ctrl+Alt+T)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (activeAppId) setActiveAppId(null);
        else if (isOpenShade) setIsOpenShade(false);
        else if (isOpenDrawer) setIsOpenDrawer(false);
        else if (isOpenEditModal) setIsOpenEditModal(false);
      } else if (e.key === 'Meta' || (e.ctrlKey && e.altKey && e.key.toLowerCase() === 't')) {
        e.preventDefault();
        if (e.key === 'Meta') {
          setIsOpenDrawer((prev) => !prev);
        } else {
          handleOpenApp('terminal');
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeAppId, isOpenShade, isOpenDrawer, isOpenEditModal]);

  // Render current app window contents
  const renderAppContent = () => {
    switch (activeAppId) {
      case 'terminal':
        return (
          <TerminalApp
            initialCommand={terminalInitialCmd}
            onClose={handleCloseActiveApp}
          />
        );
      case 'files':
        return <FilesApp />;
      case 'software':
        return <SoftwareCenterApp />;
      case 'settings':
        return (
          <SettingsApp
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onOpenEditModal={() => {
              handleCloseActiveApp();
              setIsOpenEditModal(true);
            }}
          />
        );
      case 'calculator':
        return <CalculatorApp />;
      case 'notes':
        return <NotesApp />;
      case 'sysmonitor':
        return <SystemMonitorApp />;
      case 'browser':
        return <BrowserApp />;
      case 'weather':
        return <WeatherApp />;
      case 'music':
        return <MusicApp />;
      case 'guide':
        return <GuideApp />;
      case 'calendar':
      case 'camera':
      case 'gallery':
      case 'clock':
        return (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-white space-y-3 bg-[#1A0B18]">
            <div className="w-16 h-16 rounded-2xl bg-[#E95420]/20 border border-[#E95420]/40 flex items-center justify-center text-[#E95420]">
              <HelpCircle size={32} />
            </div>
            <h4 className="text-base font-bold text-white capitalize">{activeAppId}</h4>
            <p className="text-xs text-[#AEA79F] max-w-xs leading-relaxed">
              Ubuntu Touch System Application preview active. Enjoy the native Yaru design!
            </p>
            <button
              type="button"
              onClick={handleCloseActiveApp}
              className="px-4 py-2 rounded-xl bg-[#E95420] text-xs font-semibold hover:bg-[#c93e0d]"
            >
              Back to Desktop
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  const getActiveAppTitle = () => {
    const found = apps.find((a) => a.id === activeAppId);
    return found ? found.name : 'Application';
  };

  return (
    <div className="min-h-screen w-full bg-[#140813] flex flex-col items-center justify-center relative overflow-hidden select-none font-sans">
      {/* Background ambient lighting */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-[#77216F]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-[#E95420]/15 rounded-full blur-3xl pointer-events-none" />

      {/* Top Floating Control Bar (for switching between Mobile Frame & Fullscreen) */}
      <nav className="fixed top-2 z-50 px-4 py-1.5 rounded-full bg-black/60 backdrop-blur-xl border border-white/10 shadow-2xl flex items-center gap-3 text-xs text-white/90">
        <div className="flex items-center gap-1.5 font-medium text-white">
          <svg className="w-3.5 h-3.5 fill-[#E95420]" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="5" fill="#E95420" />
            <circle cx="5" cy="12" r="2" fill="#E95420" />
            <circle cx="15.5" cy="6" r="2" fill="#E95420" />
            <circle cx="15.5" cy="18" r="2" fill="#E95420" />
          </svg>
          <span className="hidden sm:inline">Ubuntu Mobile Launcher</span>
        </div>

        <span className="text-white/20">|</span>

        {/* Viewport switch: Mobile frame vs Full native */}
        <button
          type="button"
          onClick={() => {
            sound.playTap();
            setIsPhoneFrame(!isPhoneFrame);
          }}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full transition-colors ${
            isPhoneFrame
              ? 'bg-[#E95420] text-white shadow-sm'
              : 'hover:bg-white/10 text-white/70 hover:text-white'
          }`}
          title="Toggle phone chassis frame"
        >
          {isPhoneFrame ? <Smartphone size={13} /> : <Maximize2 size={13} />}
          <span className="text-[11px] font-medium">
            {isPhoneFrame ? 'Phone Frame' : 'Fullscreen'}
          </span>
        </button>

        {/* Nova Customizer */}
        <button
          type="button"
          onClick={() => {
            sound.playTap();
            setIsOpenEditModal(true);
          }}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full hover:bg-white/10 text-white/80 hover:text-white transition-colors"
          title="Launcher Settings & Wallpaper"
        >
          <Sliders size={13} className="text-[#E95420]" />
          <span className="text-[11px] font-medium hidden sm:inline">Nova Tweaks</span>
        </button>

        {/* Lock Phone */}
        <button
          type="button"
          onClick={() => {
            sound.playTap();
            setIsLocked(true);
          }}
          className="flex items-center gap-1 px-2 py-1 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition-colors"
          title="Lock Screen"
        >
          <Lock size={13} />
        </button>
      </nav>

      {/* Main Container / Mobile Device Frame */}
      <div
        className={`relative transition-all duration-300 overflow-hidden flex flex-col ${
          isPhoneFrame
            ? 'w-full max-w-[410px] h-[840px] max-h-[92vh] rounded-[44px] ring-[12px] ring-[#2A232B] shadow-[0_25px_70px_rgba(0,0,0,0.85)] border-4 border-black/80 my-auto'
            : 'w-full h-screen rounded-none ring-0 shadow-none border-0'
        }`}
        style={
          currentWallpaper.type === 'image'
            ? {
                backgroundImage: `url(${currentWallpaper.url})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }
            : {
                background: currentWallpaper.url
              }
        }
      >
        {/* Subtle dark gradient scrim for contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60 pointer-events-none" />

        {/* Camera Punchhole for authentic phone frame */}
        {isPhoneFrame && (
          <div className="absolute top-2 left-1/2 -translate-x-1/2 z-50 w-24 h-4 bg-black rounded-full flex items-center justify-end pr-3 pointer-events-none shadow-md">
            <div className="w-2.5 h-2.5 rounded-full bg-[#111111] ring-1 ring-white/10" />
          </div>
        )}

        {/* Ubuntu Top Bar / Status Bar */}
        <StatusBar
          onToggleShade={() => {
            sound.playTap();
            setIsOpenShade(!isOpenShade);
          }}
          isOpenShade={isOpenShade}
        />

        {/* Left Edge Dock (Ubuntu Touch) */}
        {(settings.dockPosition === 'left' || settings.dockPosition === 'both') && (
          <EdgeDock
            isOpen={isOpenDock}
            onToggle={() => setIsOpenDock(!isOpenDock)}
            apps={apps}
            runningApps={runningApps}
            activeAppId={activeAppId}
            onOpenApp={(id) => {
              setIsOpenDock(false);
              handleOpenApp(id);
            }}
            onOpenDrawer={() => {
              setIsOpenDock(false);
              setIsOpenDrawer(true);
            }}
            iconShape={settings.iconShape}
          />
        )}

        {/* Desktop / Home Screen */}
        <HomeScreen
          apps={apps}
          settings={settings}
          onOpenApp={handleOpenApp}
          onOpenDrawer={() => setIsOpenDrawer(true)}
          onOpenShade={() => setIsOpenShade(true)}
          onOpenEditModal={() => setIsOpenEditModal(true)}
          onOpenClock={() => handleOpenApp('clock')}
          onOpenWeather={() => handleOpenApp('weather')}
          onOpenSysMonitor={() => handleOpenApp('sysmonitor')}
          onOpenTerminalWithCommand={handleOpenTerminalWithCommand}
        />

        {/* Ubuntu Indicator & Notification Shade */}
        <NotificationShade
          isOpen={isOpenShade}
          onClose={() => setIsOpenShade(false)}
          notifications={notifications}
          onDismissNotification={(id) => {
            setNotifications((prev) => prev.filter((n) => n.id !== id));
          }}
          onClearAllNotifications={() => setNotifications([])}
          onOpenApp={(id) => {
            setIsOpenShade(false);
            handleOpenApp(id);
          }}
          theme={settings.theme}
          onToggleTheme={() => {
            const nextTheme =
              settings.theme === 'classic' ? 'dark' : settings.theme === 'dark' ? 'light' : 'classic';
            handleUpdateSettings({ theme: nextTheme });
          }}
        />

        {/* Ubuntu Dash / App Drawer */}
        <AppDrawer
          isOpen={isOpenDrawer}
          onClose={() => setIsOpenDrawer(false)}
          apps={apps}
          onOpenApp={handleOpenApp}
          onTogglePinApp={handleTogglePinApp}
          onAddToHomeScreen={handleAddToHomeScreen}
          iconShape={settings.iconShape}
        />

        {/* App Window Modal (for opened apps) */}
        <AppWindowModal
          isOpen={!!activeAppId}
          onClose={handleCloseActiveApp}
          title={getActiveAppTitle()}
        >
          {renderAppContent()}
        </AppWindowModal>

        {/* Nova Launcher Customizer Modal */}
        <HomeEditModal
          isOpen={isOpenEditModal}
          onClose={() => setIsOpenEditModal(false)}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          onResetDefaults={handleResetDefaults}
        />

        {/* Lock Screen */}
        <LockScreen
          isLocked={isLocked}
          onUnlock={() => setIsLocked(false)}
          wallpaperUrl={currentWallpaper.url}
          isGradientWallpaper={currentWallpaper.type === 'gradient'}
          notifications={notifications}
        />
      </div>
    </div>
  );
}
