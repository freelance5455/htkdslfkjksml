# Moto Sim V73 — Phase 4

این نسخه اصلاحات مرحلهٔ چهارم را در `www/index.html` دارد. گزارش جزئیات در `PHASE4_ENGINEERING_NOTES_FA.md` است.

## بررسی ایستا
نیازمند Python 3 و Node.js:

```bash
python scripts/phase4_static_audit.py
```

این آزمون‌ها نحو JavaScript و چند invariant مهم را بررسی می‌کنند؛ جایگزین تست زندهٔ مرورگر، WebGL یا دستگاه اندرویدی نیستند.

## عیب‌یابی نصب قطعات
در اجرای مرورگر، پس از بارگذاری بازی، از کنسول توسعه‌دهنده استفاده کن:

```js
window.__mtGetEngineeringAudit()
```

خروجی، سازگاری دسته‌های تیونینگ و تشخیص مش‌های موتور انتخاب‌شده را گزارش می‌کند.
