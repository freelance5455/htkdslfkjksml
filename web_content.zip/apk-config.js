// AliChat APK configuration
// Set this to the URL where server.js is deployed before building the APK.
// Example: https://chat.example.com
window.ALICHAT_SERVER_URL = '';
