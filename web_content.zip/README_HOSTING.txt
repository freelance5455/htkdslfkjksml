PWA export - Arun Hub
================================
Files: index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png, robots.txt
Sab files EK hi folder me, ek saath upload karo.

HOSTING (HTTPS zaroori hai, warna install/offline nahi chalega):
1) Netlify Drop: app.netlify.com/drop -> poora folder drag karo -> link mil jayega.
2) Cloudflare Pages / GitHub Pages: repo/project me ye files daalo, Pages on karo.
3) Phone: link Chrome me kholo -> menu -> 'Install app' / 'Add to Home screen'.

UPDATE: app badalne par PWA Maker se dobara export karo, files overwrite karo.
Phone pe app 2 baar kholne par naya version aata hai (pehli baar purana, background me update).

PRIVACY WARN: noindex + robots.txt Google ko rokte hain, par URL phir bhi public hai.
Jise link mile wo app code dekh sakta hai. HTML me hardcoded party/rate/personal data ho to host mat karo.
robots.txt sirf tab kaam karta hai jab site domain/subdomain ke root par ho.
Built: 2026-10-19T19:02:51.694Z
