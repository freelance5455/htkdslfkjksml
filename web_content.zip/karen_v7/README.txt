KAREN V11 — Voz Gemini atualizada

Baseada na V10. Mantém nome opcional, desenvolvedor oficial Marcos, modo desenvolvedor e Gemini.

Mudanças V11:
- Voz tenta primeiro o formato atual da Interactions API do Gemini TTS.
- Se falhar, tenta generateContent como fallback.
- Erro da voz agora mostra o motivo real, em vez da mensagem enganosa de “configure uma chave”.
- Adicionado “Karen V11 • versão de desenvolvimento” no rodapé da tela.
- Histórico desta versão é separado da V10; configurações da V10 são migradas para V11.

Observação: se a API gerar o áudio mas o Android WebView bloquear a reprodução, o aviso mostrará isso claramente. Para microfone, o WebView ainda depende das permissões/ponte nativa do aplicativo HTML-to-APK; o app mantém fallback para gravador do aparelho quando disponível.
