KAREN V13 — Voz automática + cache + rolagem protegida

Principais mudanças:
- A Karen tenta falar automaticamente depois de cada resposta.
- O áudio gerado com sucesso fica em cache durante a sessão. Apertar o 🔊 novamente usa o áudio já gerado, evitando nova chamada de TTS para a mesma resposta.
- O botão 🔊 continua disponível para ouvir uma resposta específica.
- A área da conversa agora ocupa uma área própria com rolagem vertical, touch-action pan-y e overscroll-behavior para evitar o gesto de puxar a tela e atualizar.
- O rodapé mostra “Karen V13 • versão de desenvolvimento”.
- Nome opcional, desenvolvedor oficial Marcos, modo desenvolvedor e configurações Gemini são migrados da V12.
- Histórico da V13 é separado e não importa o histórico da V12.

IMPORTANTE SOBRE O TTS:
- A voz usa gemini-3.1-flash-tts-preview.
- Se a API retornar 429, a cota do projeto/modelo foi atingida.
- Se retornar 503, o modelo está com alta demanda temporária.
- O WebView/Android ainda pode bloquear reprodução automática após uma chamada assíncrona. A V13 tenta tocar automaticamente e mantém o botão 🔊 como fallback.
- A chave da API fica localmente no app. Para distribuição pública, não é seguro deixar uma chave diretamente no cliente; use um servidor/proxy.
