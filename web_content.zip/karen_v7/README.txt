KAREN V9 — Gemini + Voz reforçada + Nome opcional + Desenvolvedor Marcos

Base: V8 aprovada.

Novidades da V9:
- Botão de microfone: segure para falar e solte para virar texto.
- Usa SpeechRecognition quando disponível; se o WebView não oferecer, tenta gravar pelo microfone com MediaRecorder e transcrever usando Gemini 3.5 Transcribe.
- Botão de ouvir resposta: usa Gemini 3.1 Flash TTS Preview quando há chave Gemini; se falhar, tenta speechSynthesis do navegador.
- Cada resposta da Karen continua com seu próprio botão 🔊.
- Nome do usuário começa vazio. Só passa a existir quando a pessoa escolher um nome.
- Marcos continua sendo o desenvolvedor oficial, separado do nome do usuário.
- Modo desenvolvedor com senha local continua funcionando.
- A configuração da V8 é migrada automaticamente para a V9 quando disponível, incluindo a senha do desenvolvedor, chave e nome.
- Histórico é próprio da V9; o histórico antigo da V7 não é importado.

Importante:
- A chave Gemini deve ser inserida somente dentro do aplicativo.
- A V9 usa a API Gemini para TTS e transcrição quando possível; isso pode consumir cota da API.
- Se o APK/conversor bloquear acesso ao microfone, o Android/WebView ainda precisará permitir a permissão de microfone. O app mostra uma mensagem quando a permissão não estiver disponível.
- A senha local do modo desenvolvedor é proteção de teste, não autenticação segura para distribuição pública.
