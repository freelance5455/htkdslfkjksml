KAREN V7 — Gemini + Nome Personalizado + Modo Desenvolvedor

Esta é uma versão de desenvolvimento baseada na V6.

NOVO:
1) Nome personalizado: a pessoa pode escolher qualquer nome nas configurações ou dizer “Karen, me chame de Carlos”.
2) Modo desenvolvedor: em Configurações > Desenvolvedor, no primeiro uso o próprio aparelho permite criar uma senha. Depois a senha é verificada localmente por SHA-256 e o modo desenvolvedor pode ser ativado/desativado.
3) Quando o modo desenvolvedor está ativo, a instrução enviada ao Gemini informa que o usuário autenticado deve ser tratado como o desenvolvedor oficial Marcos.
4) Gemini usa a API Interactions, atualmente recomendada pelo Google para novos projetos.

IMPORTANTE SOBRE SEGURANÇA:
- Esta autenticação do desenvolvedor é APENAS para teste local nesta fase de desenvolvimento.
- A senha não é guardada em texto puro; é guardado um hash SHA-256 no armazenamento local.
- Não use esta versão como sistema de autenticação seguro para distribuir a terceiros.
- Para uma versão pública, a autenticação do desenvolvedor deverá ser feita por um backend/servidor e a chave Gemini também deverá ficar fora do APK.

GEMINI:
- Abra ⚙️ e cole sua própria chave Gemini no campo da API.
- Não envie a chave pelo chat.
- O modelo padrão permanece gemini-3.5-flash para preservar a compatibilidade da V6; ele pode ser alterado no campo Modelo se desejado.
