KAREN V12 — Voz Gemini atualizada

Baseada na V12. Mantém nome opcional, desenvolvedor oficial Marcos, modo desenvolvedor e Gemini.

Mudanças V12:
- Voz tenta primeiro o formato atual da Interactions API do Gemini TTS.
- Se falhar, tenta generateContent como fallback.
- Erro da voz agora mostra o motivo real, em vez da mensagem enganosa de “configure uma chave”.
- Adicionado “Karen V12 • versão de desenvolvimento” no rodapé da tela.
- Histórico desta versão é separado da V12; configurações da V12 são migradas para V12.

Observação: se a API gerar o áudio mas o Android WebView bloquear a reprodução, o aviso mostrará isso claramente. Para microfone, o WebView ainda depende das permissões/ponte nativa do aplicativo HTML-to-APK; o app mantém fallback para gravador do aparelho quando disponível.


V12 — diagnóstico de voz: erros da API agora mostram códigos como 429, 401, 403, 404 e 400. A V12 tenta generateContent primeiro e Interactions como segunda tentativa.
