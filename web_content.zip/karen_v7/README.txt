KAREN V10 — VOZ CORRIGIDA

Baseada na V9. Mantém Gemini, nome opcional, modo desenvolvedor e visual.

Voz de saída: usa o Gemini TTS via generateContent com o modelo gemini-3.1-flash-tts-preview e voz Kore. Isso evita depender do SpeechSynthesis do WebView.

Voz de entrada: tenta reconhecimento nativo/Web Speech; se o WebView não oferecer microfone, abre o gravador/selecionador de áudio do aparelho como fallback e envia o áudio ao Gemini 3.5 Transcribe para virar texto.

Observação: o funcionamento do microfone dentro de um APK baseado apenas em WebView depende de o conversor conceder RECORD_AUDIO e tratar WebView PermissionRequest. O Android exige permissão de execução e tratamento do pedido do WebView para captura de áudio.

A chave Gemini é configurada pelo usuário no próprio aplicativo. Não coloque chaves reais neste arquivo.
