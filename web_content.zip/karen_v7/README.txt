KAREN V8 — Gemini + Voz + Nome opcional + Modo Desenvolvedor

V8 baseada na V7, mantendo visual, personagem, Gemini e modo desenvolvedor.

NOVIDADES:
- Nome do usuário começa vazio. Karen não inventa nome.
- O usuário pode escolher o nome nas configurações ou dizer “Karen, me chama de ...”.
- O nome escolhido fica salvo localmente.
- Cada resposta da Karen tem botão 🔊 para ouvir aquela resposta.
- Botão “Ouvir resposta” reproduz a última resposta.
- Segure o botão 🎙️ enquanto fala; ao soltar, a fala vira texto na caixa de mensagem.
- O usuário pode editar o texto antes de enviar.
- Modo desenvolvedor continua protegido por senha local de teste.
- Marcos continua como desenvolvedor oficial, separado do nome do usuário.

MEMÓRIA:
- Esta V8 usa armazenamento próprio e NÃO importa o histórico da V7.
- O histórico desta V8 fica somente neste aparelho.
- A memória avançada entre versões fica para uma versão futura.

SEGURANÇA:
- A chave Gemini deve ser digitada somente no aplicativo.
- A senha do desenvolvedor é apenas uma proteção local de desenvolvimento; não é autenticação de produção.
