import React, { useEffect, useState } from "react";
import { callFunction, isConfigured } from "../lib/firebase";
import { Zap, CalendarCheck, Gift, Trophy, UserRound, Shield, LogOut, RefreshCw, Ticket, Megaphone, Users, CheckCircle2, LockKeyhole, QrCode, Sparkles } from "lucide-react";

const fmtError = (e) => e?.message?.replace(/^Firebase:\s*/,"") || "Something went wrong. Please try again.";
const phoneFormat = (raw) => raw.trim().replace(/[\s()-]/g,"");
function localPhone(raw) {
  let p = phoneFormat(raw);
  if (p.startsWith("00880")) p = "+880" + p.slice(5);
  if (p.startsWith("880")) p = "+" + p;
  if (p.startsWith("01") && p.length === 11) p = "+88" + p;
  return p;
}
const mask = (p) => p ? p.slice(0,4) + "••••" + p.slice(-3) : "";
const demoCustomer = (name, phone) => ({ customerId:"demo", name, phoneMasked:mask(localPhone(phone)), streak:0, xp:0, attendanceDates:[], coupons:[], spinsClaimed:0 });
const money = (v) => `${v}% OFF`;

export default function App() {
  const [portal, setPortal] = useState("customer");
  const [tab, setTab] = useState("home");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [dailyCode, setDailyCode] = useState("");
  const [customer, setCustomer] = useState(null);
  const [ownerPin, setOwnerPin] = useState("");
  const [ownerSession, setOwnerSession] = useState("");
  const [dashboard, setDashboard] = useState(null);
  const [announcementTitle, setAnnouncementTitle] = useState("");
  const [announcementBody, setAnnouncementBody] = useState("");
  const [announcements, setAnnouncements] = useState([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [demoMode, setDemoMode] = useState(!isConfigured);

  useEffect(() => { loadAnnouncements(); }, []);
  async function loadAnnouncements() {
    if (!isConfigured) { setAnnouncements([{id:"demo",title:"Welcome to ZONE PASS",body:"Join the club, check in daily and unlock rewards.",createdAt:null}]); return; }
    try { const r = await callFunction("getAnnouncements"); setAnnouncements(r.announcements || []); } catch {}
  }
  function flash(message) { setNotice(message); setError(""); }
  function fail(e) { setError(fmtError(e)); setNotice(""); }
  function switchPortal(p) { setPortal(p); setTab(p === "customer" ? "home" : "dashboard"); setNotice(""); setError(""); }
  async function run(action) {
    setBusy(true); setNotice(""); setError("");
    try { await action(); } catch (e) { fail(e); } finally { setBusy(false); }
  }
  function validateCustomer() {
    if (name.trim().length < 2) throw new Error("Enter your name (at least 2 characters).");
    if (!/^\+8801[3-9]\d{8}$/.test(localPhone(phone))) throw new Error("Enter a valid Bangladesh mobile number, e.g. 01XXXXXXXXX.");
  }
  async function join() {
    validateCustomer();
    if (demoMode) { setCustomer(demoCustomer(name.trim(),phone)); flash("Demo profile created on this device only. It is not saved to a live database."); return; }
    const r = await callFunction("registerCustomer",{name:name.trim(),phone:localPhone(phone)});
    setCustomer(r.customer); flash(r.existing ? "Welcome back! Your profile was updated." : "Welcome to ZONE PASS!");
  }
  async function lookup() {
    if (!/^\+8801[3-9]\d{8}$/.test(localPhone(phone))) throw new Error("Enter the phone number you used to join.");
    if (demoMode) { if (!customer) throw new Error("Create a demo profile first. Demo data is temporary."); flash("This is a local demo profile."); return; }
    const r = await callFunction("getCustomer",{phone:localPhone(phone)});
    setCustomer(r.customer); flash("Your profile is loaded.");
  }
  async function checkIn() {
    if (!customer) throw new Error("Join or load your profile first.");
    if (!dailyCode.trim()) throw new Error("Enter today's code shown inside the gaming zone.");
    if (demoMode) {
      const today = new Date().toLocaleDateString("en-CA",{timeZone:"Asia/Dhaka"});
      if (customer.attendanceDates?.includes(today)) throw new Error("Already checked in today in this demo.");
      const streak = customer.lastCheckIn === yesterdayBD() ? (customer.streak||0)+1 : 1;
      setCustomer({...customer, attendanceDates:[...(customer.attendanceDates||[]),today].slice(-90),lastCheckIn:today,streak,xp:(customer.xp||0)+10});
      flash("Demo check-in recorded on this device only. Real attendance needs the backend connected.");
      return;
    }
    const r = await callFunction("checkIn",{phone:localPhone(phone),dailyCode:dailyCode.trim()});
    setCustomer(r.customer); flash(r.message);
  }
  function yesterdayBD() {
    const now = new Date();
    const parts = new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Dhaka",year:"numeric",month:"2-digit",day:"2-digit"}).format(now).split("-").map(Number);
    const d = new Date(Date.UTC(parts[0],parts[1]-1,parts[2]-1));
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,"0")}-${String(d.getUTCDate()).padStart(2,"0")}`;
  }
  async function spin() {
    if (!customer) throw new Error("Join or load your profile first.");
    if (demoMode) {
      const eligible = Math.floor((customer.streak||0)/7);
      if (eligible <= (customer.spinsClaimed||0)) throw new Error("Reach a 7-day streak to unlock your next spin.");
      const n = Math.random()*100, discount = n<10?10:n<65?15:n<97?30:50;
      const coupon = {id:"demo-"+Date.now(),discount,code:"DEMO-"+Math.random().toString(36).slice(2,7).toUpperCase(),expiresAt:new Date(Date.now()+30*86400000).toISOString(),status:"active"};
      setCustomer({...customer,spinsClaimed:(customer.spinsClaimed||0)+1,coupons:[...(customer.coupons||[]),coupon],xp:(customer.xp||0)+25});
      flash(`Demo reward: ${discount}% OFF. This coupon is not valid in a real shop until the backend is connected.`);
      return;
    }
    const r = await callFunction("spinReward",{phone:localPhone(phone)});
    setCustomer(r.customer); flash(`Congratulations! You won ${r.coupon.discount}% OFF. Coupon: ${r.coupon.code}`);
  }
  async function ownerLogin() {
    if (demoMode) { if (ownerPin.length < 4) throw new Error("Enter at least 4 digits for demo access."); setOwnerSession("demo-owner-session"); setDashboard({customers:[],totalCustomers:0,todayCheckIns:0,activeCoupons:0,today:"Demo",settings:{}}); flash("Demo owner panel unlocked. This does not secure a real shop."); return; }
    const r = await callFunction("ownerLogin",{pin:ownerPin});
    setOwnerSession(r.ownerSession); await loadDashboard(r.ownerSession); setOwnerPin(""); flash("Owner panel unlocked.");
  }
  async function loadDashboard(session = ownerSession) {
    if (demoMode) { setDashboard(dashboard || {customers:[],totalCustomers:0,todayCheckIns:0,activeCoupons:0,today:"Demo",settings:{}}); return; }
    const r = await callFunction("ownerDashboard",{ownerSession:session}); setDashboard(r);
  }
  async function refreshOwner() { await loadDashboard(); flash("Dashboard refreshed."); }
  async function saveCode() {
    if (!dailyCode.trim()) throw new Error("Enter a 4–10 character code.");
    if (demoMode) { flash("Demo code set locally only. It is not accepted by a real attendance system."); return; }
    await callFunction("ownerSetDailyCode",{ownerSession,dailyCode:dailyCode.trim()}); setDailyCode(""); flash("Today's code has been saved securely.");
  }
  async function postAnnouncement() {
    if (announcementTitle.trim().length < 2 || announcementBody.trim().length < 2) throw new Error("Enter an announcement title and message.");
    if (demoMode) { setAnnouncements([{id:"demo-"+Date.now(),title:announcementTitle,body:announcementBody},...announcements]); flash("Demo announcement added on this device only."); }
    else { await callFunction("ownerPostAnnouncement",{ownerSession,title:announcementTitle,body:announcementBody}); await loadAnnouncements(); flash("Announcement published."); }
    setAnnouncementTitle(""); setAnnouncementBody("");
  }
  async function redeem(customerId,couponId) {
    if (demoMode) { flash("Demo redemption only. No real coupon was changed."); return; }
    await callFunction("ownerRedeemCoupon",{ownerSession,customerId,couponId}); await loadDashboard(); flash("Coupon redeemed.");
  }
  async function logoutOwner() {
    if (!demoMode && ownerSession) await callFunction("ownerLogout",{ownerSession});
    setOwnerSession(""); setDashboard(null); setOwnerPin(""); flash("Owner panel locked.");
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand-mark"><Zap size={22} fill="currentColor" /></div>
      <div className="brand"><b>ZONE<span>PASS</span></b><small>LEVEL UP YOUR LOYALTY</small></div>
      <div className="top-spacer" />
      <span className={`mode-chip ${demoMode ? "demo" : "live"}`}>{demoMode ? "PREVIEW MODE" : "CONNECTED"}</span>
    </header>

    <main className="main">
      <section className="hero">
        <div className="hero-orb orb-a"></div><div className="hero-orb orb-b"></div>
        <div className="eyebrow"><span className="pulse"></span> GAMING ZONE REWARDS</div>
        <h1>PLAY MORE.<br/><span>UNLOCK MORE.</span></h1>
        <p>Your time at the zone should reward you. Check in, build your streak and unlock member-only offers.</p>
        <div className="hero-stats"><div><strong>+10 XP</strong><small>DAILY CHECK-IN</small></div><i></i><div><strong>7 DAYS</strong><small>REWARD SPIN</small></div><i></i><div><strong>UP TO 50%</strong><small>DISCOUNT</small></div></div>
      </section>

      <div className="portal-switch">
        <button className={portal==="customer"?"active":""} onClick={()=>switchPortal("customer")}><UserRound size={16}/> Customer</button>
        <button className={portal==="owner"?"active":""} onClick={()=>switchPortal("owner")}><Shield size={16}/> Owner panel</button>
      </div>

      {notice && <div className="notice"><CheckCircle2 size={17}/><span>{notice}</span><button onClick={()=>setNotice("")}>×</button></div>}
      {error && <div className="error-msg"><span>!</span>{error}<button onClick={()=>setError("")}>×</button></div>}
      {demoMode && <div className="preview-warning"><Sparkles size={17}/><div><b>Preview only</b><p>This works as a local demo. Live database, secure attendance and owner access start after Firebase setup.</p></div></div>}

      {portal==="customer" ? <CustomerPortal
        tab={tab} setTab={setTab} name={name} setName={setName} phone={phone} setPhone={setPhone}
        customer={customer} dailyCode={dailyCode} setDailyCode={setDailyCode} announcements={announcements}
        busy={busy} join={()=>run(join)} lookup={()=>run(lookup)} checkIn={()=>run(checkIn)} spin={()=>run(spin)}
      /> : <OwnerPortal
        tab={tab} setTab={setTab} ownerPin={ownerPin} setOwnerPin={setOwnerPin} ownerSession={ownerSession}
        dashboard={dashboard} dailyCode={dailyCode} setDailyCode={setDailyCode}
        announcementTitle={announcementTitle} setAnnouncementTitle={setAnnouncementTitle}
        announcementBody={announcementBody} setAnnouncementBody={setAnnouncementBody}
        announcements={announcements} busy={busy} login={()=>run(ownerLogin)} refresh={()=>run(refreshOwner)}
        saveCode={()=>run(saveCode)} postAnnouncement={()=>run(postAnnouncement)} redeem={(a,b)=>run(()=>redeem(a,b))}
        logout={()=>run(logoutOwner)} demoMode={demoMode}
      />}
      <footer><div className="footer-logo"><Zap size={14} fill="currentColor"/> ZONE PASS</div><p>Made for your next level.</p><small>Keep your phone number private. Only share it with the gaming zone.</small></footer>
    </main>
  </div>;
}

function CustomerPortal({tab,setTab,name,setName,phone,setPhone,customer,dailyCode,setDailyCode,announcements,busy,join,lookup,checkIn,spin}) {
  const streak = customer?.streak || 0;
  const spins = Math.max(0,Math.floor(streak/7)-(customer?.spinsClaimed||0));
  return <section className="content-area">
    <div className="tabs">
      {[["home","Overview"],["attendance","Attendance"],["rewards","Rewards"],["profile","My profile"]].map(([id,label])=><button key={id} className={tab===id?"selected":""} onClick={()=>setTab(id)}>{label}</button>)}
    </div>
    {tab==="home" && <>
      <div className="section-heading"><div><small>YOUR PLAYER CARD</small><h2>{customer ? `Welcome, ${customer.name.split(" ")[0]}!` : "Join the squad."}</h2></div><span className="level-badge"><Trophy size={15}/> MEMBER</span></div>
      {!customer ? <JoinCard name={name} setName={setName} phone={phone} setPhone={setPhone} busy={busy} join={join} lookup={lookup}/> : <>
        <PlayerCard customer={customer}/>
        <div className="metric-grid"><Metric icon={<CalendarCheck/>} label="DAY STREAK" value={streak} suffix="days"/><Metric icon={<Zap/>} label="TOTAL XP" value={customer.xp||0} suffix="XP"/><Metric icon={<Gift/>} label="SPINS READY" value={spins} suffix="spin(s)"/></div>
        <div className="checkin-card"><div className="card-topline"><span className="icon-box"><QrCode size={20}/></span><span className="status-pill">SHOP CHECK-IN</span></div><h3>You're at the zone?</h3><p>Enter the short code displayed inside the shop to confirm today's visit.</p><div className="inline-form"><input value={dailyCode} onChange={e=>setDailyCode(e.target.value.toUpperCase())} placeholder="TODAY'S CODE" maxLength={10}/><button onClick={checkIn} disabled={busy}>Check in <CalendarCheck size={16}/></button></div><small className="hint">One check-in per day · Bangladesh time</small></div>
      </>}
      <Announcements announcements={announcements}/>
    </>}
    {tab==="attendance" && <><div className="section-heading"><div><small>SHOW UP. LEVEL UP.</small><h2>Attendance</h2></div><CalendarCheck size={24}/></div>{customer?<><div className="streak-panel"><div className="streak-number">{streak}<small>DAY STREAK</small></div><div><b>{streak>=7?"You're on fire!":"Keep your streak alive."}</b><p>{Math.max(0,7-(streak%7||0))} more consecutive day(s) to your next milestone.</p></div></div><div className="calendar-grid">{["M","T","W","T","F","S","S"].map((d,i)=><div className="weekday" key={i}>{d}</div>)}{Array.from({length:28},(_,i)=>{const date=new Date();date.setDate(date.getDate()-(27-i));const key=date.toLocaleDateString("en-CA",{timeZone:"Asia/Dhaka"});const attended=(customer.attendanceDates||[]).includes(key);return <div key={i} className={`day-cell ${attended?"attended":""}`}>{attended?<CheckCircle2 size={14}/>:date.getDate()}</div>})}</div></>:<JoinCard name={name} setName={setName} phone={phone} setPhone={setPhone} busy={busy} join={join} lookup={lookup}/>}</>}
    {tab==="rewards" && <><div className="section-heading"><div><small>LUCK FAVOURS THE LOYAL</small><h2>Reward wheel</h2></div><Gift size={24}/></div><div className="wheel-card"><div className="wheel"><div className="wheel-inner"><Gift size={34}/><b>SPIN</b></div></div><h3>{spins>0?"Your spin is ready!":"Earn your next spin."}</h3><p>Reach a 7-day streak to unlock a discount coupon. Each spin is processed by the server when connected.</p><button className="primary-btn" disabled={busy||!customer||spins<1} onClick={spin}><Sparkles size={17}/> Spin for reward</button><div className="odds"><span>10% off <b>10%</b></span><span>15% off <b>55%</b></span><span>30% off <b>32%</b></span><span>50% off <b>3%</b></span></div></div><div className="section-heading compact"><div><small>YOUR WALLET</small><h2>Coupons</h2></div><Ticket size={21}/></div><CouponList customer={customer}/></>}
    {tab==="profile" && <><div className="section-heading"><div><small>YOUR ACCOUNT</small><h2>My profile</h2></div><UserRound size={24}/></div>{customer?<div className="profile-card"><div className="avatar">{customer.name?.[0]?.toUpperCase()||"Z"}</div><h3>{customer.name}</h3><p>{customer.phoneMasked||mask(localPhone(phone))}</p><div className="profile-stats"><span><b>{customer.streak||0}</b> streak</span><span><b>{customer.xp||0}</b> XP</span><span><b>{customer.coupons?.length||0}</b> coupons</span></div><p className="privacy-note">Your number is used to find your profile. It is not verified by SMS, so do not use someone else's number.</p></div>:<JoinCard name={name} setName={setName} phone={phone} setPhone={setPhone} busy={busy} join={join} lookup={lookup}/>}</>}
  </section>;
}
function JoinCard({name,setName,phone,setPhone,busy,join,lookup}) {
  return <div className="join-card"><div className="join-icon"><UserRound size={24}/></div><h3>Get your ZONE PASS</h3><p>No password. Just your name and Bangladesh mobile number.</p><label>YOUR NAME</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Rahim Ahmed" maxLength={60}/><label>MOBILE NUMBER</label><input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="01XXXXXXXXX" inputMode="tel" maxLength={20}/><button className="primary-btn" onClick={join} disabled={busy}>{busy?"Please wait…":"Create / update profile"} <span>→</span></button><button className="text-btn" onClick={lookup} disabled={busy}>Already joined? Load my profile</button><small className="hint">Bangladesh numbers only · No SMS verification in this version</small></div>;
}
function PlayerCard({customer}) {
  return <div className="player-card"><div className="card-noise"></div><div className="player-card-top"><span>ZONE PASS <i>MEMBER</i></span><Zap size={20} fill="currentColor"/></div><div className="player-name">{customer.name}</div><div className="player-card-bottom"><div><small>PLAYER XP</small><b>{customer.xp||0}</b></div><div><small>CURRENT STREAK</small><b>{customer.streak||0} DAYS</b></div><div className="avatar-mini">{customer.name?.[0]?.toUpperCase()}</div></div></div>;
}
function Metric({icon,label,value,suffix}) { return <div className="metric-card"><span>{icon}</span><small>{label}</small><strong>{value}</strong><em>{suffix}</em></div>; }
function Announcements({announcements}) { return <div className="announcement-section"><div className="section-heading compact"><div><small>FROM THE ZONE</small><h2>Announcements</h2></div><Megaphone size={21}/></div>{announcements.length?announcements.map(a=><div className="announcement" key={a.id}><span className="announcement-icon"><Megaphone size={18}/></span><div><b>{a.title}</b><p>{a.body}</p></div></div>):<p className="empty">No announcements right now.</p>}</div>; }
function CouponList({customer}) {
  if (!customer) return <div className="empty-panel">Join or load your profile to see your coupons.</div>;
  const coupons=customer.coupons||[];
  return coupons.length?<div className="coupon-list">{[...coupons].reverse().map(c=><div className={`coupon ${c.status!=="active"?"used":""}`} key={c.id}><div className="coupon-discount"><b>{c.discount}%</b><small>OFF</small></div><div className="coupon-detail"><b>{c.code}</b><small>{c.status==="active"?"Ready to redeem":c.status==="redeemed"?"Already redeemed":"Expired"} · Expires {c.expiresAt?new Date(c.expiresAt).toLocaleDateString():"—"}</small></div><Ticket size={20}/></div>)}</div>:<div className="empty-panel">Your coupons will appear here after a reward spin.</div>;
}
function OwnerPortal({tab,setTab,ownerPin,setOwnerPin,ownerSession,dashboard,dailyCode,setDailyCode,announcementTitle,setAnnouncementTitle,announcementBody,setAnnouncementBody,announcements,busy,login,refresh,saveCode,postAnnouncement,redeem,logout,demoMode}) {
  if (!ownerSession) return <section className="content-area"><div className="owner-login"><div className="owner-lock"><LockKeyhole size={28}/></div><small>RESTRICTED AREA</small><h2>Owner access</h2><p>Enter your owner PIN to manage members, attendance and rewards.</p><label>OWNER PIN</label><input value={ownerPin} onChange={e=>setOwnerPin(e.target.value)} placeholder="Enter PIN" type="password" inputMode="numeric" maxLength={12}/><button className="primary-btn" disabled={busy} onClick={login}>{busy?"Checking…":"Unlock owner panel"} <LockKeyhole size={16}/></button><small className="hint">{demoMode?"Demo only: any 4+ character PIN unlocks the preview.":"PIN is checked securely by the backend."}</small></div></section>;
  }
  const d=dashboard||{customers:[],totalCustomers:0,todayCheckIns:0,activeCoupons:0};
  return <section className="content-area">
    <div className="owner-head"><div><small>ZONE MANAGEMENT</small><h2>Owner dashboard</h2></div><div className="owner-actions"><button className="icon-btn" onClick={refresh} disabled={busy}><RefreshCw size={17}/></button><button className="icon-btn" onClick={logout} disabled={busy}><LogOut size={17}/></button></div></div>
    <div className="tabs owner-tabs">{[["dashboard","Overview"],["members","Members"],["settings","Check-in code"],["news","Announcements"]].map(([id,label])=><button key={id} className={tab===id?"selected":""} onClick={()=>setTab(id)}>{label}</button>)}</div>
    {tab==="dashboard" && <><div className="owner-metrics"><div><Users/><small>MEMBERS</small><b>{d.totalCustomers}</b></div><div><CalendarCheck/><small>TODAY'S CHECK-INS</small><b>{d.todayCheckIns}</b></div><div><Ticket/><small>ACTIVE COUPONS</small><b>{d.activeCoupons}</b></div></div><div className="admin-panel"><h3>Quick actions</h3><button className="admin-action" onClick={()=>setTab("members")}><Users/> Browse customers <span>→</span></button><button className="admin-action" onClick={()=>setTab("settings")}><QrCode/> Set today's check-in code <span>→</span></button><button className="admin-action" onClick={()=>setTab("news")}><Megaphone/> Publish an announcement <span>→</span></button></div><p className="hint">Timezone: Asia/Dhaka · One verified attendance per customer per day.</p></>}
    {tab==="members" && <div className="admin-panel"><div className="panel-title"><h3>Customer list</h3><span>{d.customers?.length||0} shown</span></div>{(d.customers||[]).length?(d.customers||[]).map(c=><div className="member-row" key={c.customerId}><div className="member-avatar">{c.name?.[0]?.toUpperCase()}</div><div className="member-info"><b>{c.name}</b><small>{c.phoneMasked} · {c.streak} day streak · {c.xp} XP</small><div className="member-coupons">{(c.coupons||[]).filter(x=>x.status==="active").map(x=><button key={x.id} onClick={()=>redeem(c.customerId,x.id)} disabled={busy}>Redeem {x.discount}% · {x.code}</button>)}</div></div></div>)):<div className="empty-panel">No customers yet. Customers appear here after they join the live app.</div>}</div>}
    {tab==="settings" && <div className="admin-panel"><div className="settings-icon"><QrCode size={24}/></div><h3>Today's shop code</h3><p>Display a short code inside the gaming zone. Customers scan your shop QR to open this site, then enter the code to check in.</p><label>NEW DAILY CODE</label><input value={dailyCode} onChange={e=>setDailyCode(e.target.value.toUpperCase())} placeholder="e.g. ZONE731" maxLength={10}/><button className="primary-btn" onClick={saveCode} disabled={busy}>Save today's code <CheckCircle2 size={16}/></button><div className="security-note"><Shield size={18}/><p>Use a different code each day and only display it inside the shop. Never put the daily code on the public QR poster.</p></div></div>}
    {tab==="news" && <div className="admin-panel"><h3>New announcement</h3><label>TITLE</label><input value={announcementTitle} onChange={e=>setAnnouncementTitle(e.target.value)} placeholder="Weekend tournament" maxLength={80}/><label>MESSAGE</label><textarea value={announcementBody} onChange={e=>setAnnouncementBody(e.target.value)} placeholder="Tell members what's happening…" maxLength={500}/><button className="primary-btn" onClick={postAnnouncement} disabled={busy}>Publish announcement <Megaphone size={16}/></button><div className="panel-title mt"><h3>Recent announcements</h3></div>{announcements.map(a=><div className="announcement" key={a.id}><span className="announcement-icon"><Megaphone size={18}/></span><div><b>{a.title}</b><p>{a.body}</p></div></div>)}</div>}
  </section>;
}
