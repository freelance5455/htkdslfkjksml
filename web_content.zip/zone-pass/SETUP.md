# ZONE PASS — Supabase edition

This package adapts the ZONE PASS React/Vite frontend to Supabase. It includes the SQL schema and an Edge Function backend. It is **not live until the Edge Function is deployed, secrets are set, and the frontend is hosted**.

## What is included
- Mobile-first React customer and owner interfaces
- Supabase client configured with Project URL + publishable key
- `supabase/schema.sql` migration
- `supabase/functions/zone-pass/index.ts` server-side operations

## Important security notes
- Do not put `SUPABASE_SERVICE_ROLE_KEY` or `OWNER_PIN` in the frontend or `.env` file. Add them only as Supabase Edge Function secrets.
- The app does not verify phone ownership by SMS. Someone who knows another customer's number could access that profile. Do not treat phone number alone as strong authentication. Consider SMS OTP before real rewards are valuable.
- The Edge Function uses service-role access server-side; RLS blocks direct browser table access. Review and test all flows before public launch.
- Customer check-ins and reward spins change loyalty value. Test thoroughly and set a unique owner PIN.

## 1. Run the SQL schema
1. Open Supabase Dashboard → SQL Editor → New query.
2. Paste `supabase/schema.sql` and run it. It adds required columns/tables to the `customers` and `attendance` tables you already created.

## 2. Deploy the Edge Function
Supabase Edge Functions normally require the Supabase CLI or an editor/deploy workflow supported by your account. On a computer with Node.js and Supabase CLI, from this folder run:

```sh
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase secrets set OWNER_PIN=YOUR_LONG_PRIVATE_PIN SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY
supabase functions deploy zone-pass
```

The platform provides `SUPABASE_URL` automatically to Edge Functions. Do not expose the service-role key. If you cannot use a computer, tell me; we can explore a browser-based deployment route, but do not skip backend deployment.

## 3. Configure the frontend
Copy `.env.example` to `.env` and fill in:
- `VITE_SUPABASE_URL`: Project URL from Supabase → Data API
- `VITE_SUPABASE_PUBLISHABLE_KEY`: publishable key from Supabase → API Keys

These two values are intended for the browser. Never use a secret key here.

## 4. Build and host
```sh
npm install
npm run build
```
Upload the generated `dist` folder to a static host such as Vercel or Netlify. Add the same two `VITE_` variables in the hosting dashboard, then rebuild/redeploy.

## QR and daily code
The permanent shop QR should point to the deployed website URL. Do not put the daily attendance code inside the public QR. The owner sets a fresh daily code from the Owner panel after the Edge Function is deployed.

## Preview mode
If the two frontend variables are blank, the UI stays in local preview mode. Preview data is temporary and is not real attendance or redeemable coupons.
