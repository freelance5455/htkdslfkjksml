-- ZONE PASS Supabase schema. Run in Supabase SQL Editor.
-- The Edge Function uses the service-role key server-side; never put that key in the frontend.
alter table public.customers
  add column if not exists phone_masked text,
  add column if not exists attendance_dates date[] not null default '{}',
  add column if not exists streak integer not null default 0,
  add column if not exists xp integer not null default 0,
  add column if not exists coupons jsonb not null default '[]'::jsonb,
  add column if not exists last_check_in date,
  add column if not exists spins_claimed integer not null default 0,
  add column if not exists created_at timestamptz not null default now(),
  add column if not exists updated_at timestamptz not null default now();

create table if not exists public.zone_settings (
  id text primary key default 'shop' check (id = 'shop'),
  daily_code_hash text,
  code_updated_at timestamptz
);
create table if not exists public.zone_owner_sessions (
  token_hash text primary key,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create table if not exists public.zone_login_limits (
  ip_hash text primary key, attempts integer not null default 0,
  window_start timestamptz not null default now(), locked_until timestamptz
);
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(), title text not null, body text not null,
  active boolean not null default true, created_at timestamptz not null default now()
);

alter table public.customers enable row level security;
alter table public.attendance enable row level security;
alter table public.zone_settings enable row level security;
alter table public.zone_owner_sessions enable row level security;
alter table public.zone_login_limits enable row level security;
alter table public.announcements enable row level security;

-- No direct browser access. All reads/writes must go through the Edge Function.
revoke all on public.customers, public.attendance, public.zone_settings, public.zone_owner_sessions, public.zone_login_limits, public.announcements from anon, authenticated;
