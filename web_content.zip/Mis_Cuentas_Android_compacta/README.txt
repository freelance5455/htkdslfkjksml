MIS CUENTAS — PROYECTO ANDROID

Proyecto Android Studio con una actividad WebView que carga la app desde app/src/main/assets/index.html. No requiere permisos de Internet; los datos se guardan en el almacenamiento local de WebView en el dispositivo.

Para generar APK: abre esta carpeta en Android Studio, deja que Gradle sincronice y selecciona Build > Build APK(s). Se necesita Android Studio/SDK instalado. Este ZIP contiene el código fuente, no un APK ya compilado.
