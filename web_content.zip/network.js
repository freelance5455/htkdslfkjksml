// Nayeem network helpers: lightweight retry + online/offline UI.
export function watchNetwork(setOnline){
  const update=()=>setOnline(navigator.onLine);
  window.addEventListener("online",update);
  window.addEventListener("offline",update);
  update();
}
export async function retry(fn, attempts=3){
  let last;
  for(let i=0;i<attempts;i++){
    try{return await fn()}catch(e){last=e; await new Promise(r=>setTimeout(r,500*(i+1)))}
  }
  throw last;
}
