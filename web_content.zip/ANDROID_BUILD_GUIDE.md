# Color Rush — Android Project & Build Instructions

This archive contains the complete, up-to-date source code and Android native project for **Color Rush**.

---

## What's Included

- **Capacitor Android Native Project (`/android`)**
  - Configured with Google AdMob Rewarded Ads (`ca-app-pub-7257687669217703~4909222410`)
  - Configured with AdMob Rewarded Ad Unit ID (`ca-app-pub-7257687669217703/5696349618`)
  - Target SDK 34, Min SDK 22
- **Firebase Authentication & Cloud Firestore Leaderboard**
  - Google Sign-In with popup/native auth
  - Top 100 Global Leaderboard queries & score submission
  - Hardened Zero-Trust `firestore.rules` & `firebase-blueprint.json`
- **Game Features & Assets**
  - Daily Streak & 7-Day rewards
  - 6 Arcade Color Themes
  - 7 Unlockable Achievements
  - Fever Mode & Danger Bombs
  - Web Audio sound synthesizer & tactile haptics

---

## How to Build the Android App

### Option A: Using Android Studio (Recommended)

1. **Extract this ZIP file**:
   ```bash
   unzip color-rush-android.zip -d color-rush
   cd color-rush
   ```

2. **Install Node Dependencies & Build Web Assets**:
   ```bash
   npm install
   npm run build:android
   ```

3. **Open in Android Studio**:
   - Open Android Studio
   - Choose **Open an Existing Project**
   - Select the `android` directory inside the project (`color-rush/android`)
   - Wait for Gradle sync to complete
   - Click **Run** (Green play button) or select **Build > Build Bundle(s) / APK(s) > Build APK(s)**

---

### Option B: Command Line (Fast Build)

```bash
cd android
./gradlew assembleDebug
```

The compiled APK will be located at:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

## AdMob Configuration Summary

- **App ID**: `ca-app-pub-7257687669217703~4909222410` (set in `android/app/src/main/AndroidManifest.xml`)
- **Rewarded Ad Unit ID**: `ca-app-pub-7257687669217703/5696349618` (used for 10 coins bonus in `src/admob.ts`)
- **Testing**: Configured for live production ads.
