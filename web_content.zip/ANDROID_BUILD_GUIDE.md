# Smart Home Khata - Android APK Build Guide (com.smarthomekhata.app)

This project is fully configured for both **Instant Android Web App (PWA / WebAPK)** and **Native Android Release APK (via Capacitor & Android Studio / Gradle)**.

---

## Method 1: Instant 1-Tap Android Install (No PC or Gradle required)
Any Indian user on Android can install Smart Home Khata directly from mobile Chrome:
1. Open the hosted web URL in Chrome on any Android phone.
2. Tap the in-app **"ऐप इंस्टॉल करें (Install App)"** button or tap the Chrome three dots (⋮) and choose **"Add to Home screen / Install app"**.
3. It installs as a real standalone Android application with our custom green Rupee app icon, offline support, and full-screen experience.

---

## Method 2: Compile a Standalone Signed Release APK (`.apk`)

### Prerequisites:
- Node.js 18+ & npm
- Android Studio (Giraffe, Hedgehog, Iguana or newer) OR Android Command-Line Tools + JDK 17
- Gradle 8.2+

### Step-by-Step APK Generation:

1. **Build the web production bundle**:
   ```bash
   npm run build
   ```

2. **Sync the web build to the Android project**:
   ```bash
   npx cap sync android
   ```

3. **Option A: Build APK with Command Line (Quickest)**:
   ```bash
   cd android
   ./gradlew assembleDebug
   # Or for signed production release APK:
   ./gradlew assembleRelease
   ```
   Your generated APK file will be located at:
   `android/app/build/outputs/apk/release/app-release-unsigned.apk` (or `app-debug.apk`)

4. **Option B: Build & Sign APK via Android Studio (GUI)**:
   ```bash
   npx cap open android
   ```
   - In Android Studio, go to menu: **Build -> Generate Signed Bundle / APK**.
   - Select **APK**.
   - Choose or create your Keystore file (.jks).
   - Select **release** build variant and check **V1 and V2 (Full APK Signature)**.
   - Click **Finish**.
   - The final installable `.apk` file is generated and ready to share via WhatsApp, Google Drive, or upload to Google Play Store!

---

## Android App Specifications:
- **App Name**: Smart Home Khata (स्मार्ट घरेलू हिसाब-किताब)
- **Application ID / Package**: `com.smarthomekhata.app`
- **Min SDK**: 22 (Android 5.1 Lollipop - covers 99.8% of Indian Android devices)
- **Target SDK**: 34 (Android 14)
- **Theme Color**: `#15803d` (Indian Green)
- **Offline Storage**: IndexedDB + LocalStorage (100% offline functional without internet)
