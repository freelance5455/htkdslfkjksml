# ANONYMOUX STUDIO 2.5.9

- Retired the Explore page from signed-in navigation; old `community.php` bookmarks redirect to Dashboard.
- Rechecked Realtime Studio against the current Decart JavaScript SDK documentation. Added explicit handling for the SDK `sessionEnded` event and provider termination reasons.
- Raised the client-token endpoint's request allowance to accommodate SDK retries/reconnects, while retaining short-lived model/origin-scoped tokens.
- Added a transparent realtime pricing disclosure: provider rates are distinguished from ANONYMOUX credit prices, and the lack of local realtime wallet deductions is stated plainly.
- Corrected pricing documentation: default credit packages are seeded active; 6/11 credits per second remain candidate rates only and are not enforced.
