const fs = require("fs");

const content = fs.readFileSync("/tmp/page.html", "utf-8");
console.log("File loaded, length:", content.length);

const sStart = content.indexOf("<script>");
const sEnd = content.indexOf("</script>", sStart);
const script = content.substring(sStart + 8, sEnd);

const pDataPrefix = 'const _pData = "';
const pDataStart = script.indexOf(pDataPrefix);
if (pDataStart === -1) {
    console.error("pData prefix not found!");
    process.exit(1);
}
const valStart = pDataStart + pDataPrefix.length;
const pDataEnd = script.indexOf('";', valStart);
console.log("valStart:", valStart, "pDataEnd:", pDataEnd);

const _pData = script.substring(valStart, pDataEnd);
console.log("_pData length:", _pData.length);

const _stdB64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const _emjList = ["i", "\u2260", "5", "\ud83d\udc80", "\u221e", "_", "b", "2", "u", "\u00a7", "%", "f", "h", "a", "x", "l", "\u00a5", "\ud83d\udd12", "\u03bc", "v", "6", "-", "\u20ac", "\u274c", "\ud83e\udd75", "c", "\u00f7", "q", "r", "0", "\u03a9", "n", "3", "z", "^", "w", "7", "\u00a3", "&", "s", "\ud83d\udc7f", "g", "m", "=", "4", "p", "~", "t", "9", "\u03c0", "\u03bb", "\u20b9", "\ud83d\udd25", "y", "\u03b8", "k", "o", "\ud83c\udfaf", "8", "+", "j", "1", "\u26a1", "d"];
const _symMap = new Map();
for (let i = 0; i < _emjList.length; i++) {
    _symMap.set(_emjList[i], _stdB64[i]);
}
_symMap.set("•", "=");

const _sA = 119;
const _sB = 96;
const _sC = 9;

const _symArray = Array.from(_pData);
console.log("symArray count:", _symArray.length);
let _rawB64 = "";
for (let j = 0; j < _symArray.length; j++) {
    _rawB64 += _symMap.get(_symArray[j]) || _symArray[j];
}
console.log("rawB64 length:", _rawB64.length);

const _binStr = Buffer.from(_rawB64, "base64").toString("latin1");
const _len = _binStr.length;
console.log("binStr length:", _len);
const _outBuf = new Uint8Array(_len);
let _curA = _sA;
let _curB = _sB;
for (let k = 0; k < _len; k++) {
    let _val = _binStr.charCodeAt(k);
    _val = (_val ^ (k & 255)) & 255;
    _val = (_val - _curB + 256) & 255;
    _val = (_val ^ _curA) & 255;
    _outBuf[k] = _val;
    
    _curA = (_curA * 3 + _sC) & 255;
    _curB = (_curB + 19) & 255;
}

const _finalHtml = Buffer.from(_outBuf).toString("utf-8");
fs.writeFileSync("/tmp/decoded.html", _finalHtml);
console.log("Success! Decoded HTML written, length:", _finalHtml.length);
