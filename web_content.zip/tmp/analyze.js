const fs = require('fs');
const js = fs.readFileSync('/tmp/nexora.js', 'utf8');

// Find mentions of nexora
const matches = [];
const regex = /.{0,60}nexora.{0,60}/gi;
let m;
while ((m = regex.exec(js)) !== null) {
  matches.push(m[0].replace(/[\n\r]/g, ' '));
  if (matches.length > 50) break;
}
console.log('Nexora occurrences:');
matches.forEach((x, i) => console.log(`${i}: ${x}`));

// Search for UI keywords like "HTML", "CSS", "JS", "Console", "Preview", "Terminal"
const uiWords = ['Console', 'Preview', 'Terminal', 'Monaco', 'codemirror', 'prism', 'Settings', 'Templates', 'Projects', 'Download', 'Zip', 'AI', 'Chat', 'Ali Hassan', 'Coder Khatri'];
uiWords.forEach(w => {
  const count = (js.match(new RegExp(w, 'gi')) || []).length;
  console.log(`${w}: ${count}`);
});
