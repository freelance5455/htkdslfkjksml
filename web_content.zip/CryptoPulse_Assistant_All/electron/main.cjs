const { app, BrowserWindow } = require("electron");
const path = require("path");
const { ipcMain } = require("electron");
const { execFile } = require("child_process");
const { spawn } = require("child_process");
let server;
function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 850, minWidth: 760, minHeight: 600,
    title: "CryptoPulse Assistant",
    webPreferences: { contextIsolation: true, nodeIntegration: false, preload: path.join(__dirname, "preload.cjs") }
  });
  win.loadURL("http://localhost:3000");
}
ipcMain.handle("security:windows-quick-scan", async () => {
  if (process.platform !== "win32") return { ok: false, message: "This native scan is available only in the Windows desktop build." };
  return await new Promise(resolve => {
    execFile("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", "Start-MpScan -ScanType QuickScan"], { timeout: 120000 }, (error) => {
      if (error) resolve({ ok: false, message: "Could not start Microsoft Defender. Open Windows Security → Virus & threat protection → Quick scan. Defender may be unavailable or require administrator attention." });
      else resolve({ ok: true, message: "Microsoft Defender quick scan command was started. Check Windows Security for scan progress and results." });
    });
  });
});
app.whenReady().then(() => {
  server = spawn(process.execPath, [path.join(__dirname, "..", "server", "index.js")], {
    env: { ...process.env, ELECTRON_RUN_AS_NODE: "1", PORT: "3000" },
    stdio: "inherit"
  });
  setTimeout(createWindow, 1200);
});
app.on("window-all-closed", () => { if (server) server.kill(); if (process.platform !== "darwin") app.quit(); });
