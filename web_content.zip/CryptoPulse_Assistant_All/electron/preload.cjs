const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("cryptoPulseDesktop", {
  quickScan: () => ipcRenderer.invoke("security:windows-quick-scan")
});
