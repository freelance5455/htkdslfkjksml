require("dotenv").config();
const express = require("express");
const path = require("path");
const OpenAI = require("openai");

const app = express();
const port = process.env.PORT || 3000;
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "CryptoPulse Assistant", aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const messages = Array.isArray(req.body.messages) ? req.body.messages.slice(-20) : [];
    if (!messages.length) return res.status(400).json({ error: "Please enter a message." });
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI is not connected yet. Add your OpenAI API key to the server .env file." });
    }
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const input = messages.map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 8000)
    }));
    const response = await client.responses.create({
      model: "gpt-4.1-mini",
      instructions: "You are CryptoPulse Assistant, a helpful general-purpose assistant. You can explain crypto markets but never promise profits or present guesses as facts. Do not execute trades, transfers, purchases, emails, or other external actions. Ask for confirmation before any consequential action. State when live data has not been retrieved. Do not claim to have performed an action unless a connected tool actually did it.",
      input
    });
    res.json({ reply: response.output_text || "I could not produce a reply. Please try again." });
  } catch (err) {
    console.error("Chat error:", err.message);
    res.status(500).json({ error: "The AI request failed. Check the server API key, billing and connection." });
  }
});

app.listen(port, () => console.log(`CryptoPulse Assistant running at http://localhost:${port}`));
