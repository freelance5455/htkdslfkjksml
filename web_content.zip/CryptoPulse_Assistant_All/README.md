# CryptoPulse Assistant — all-platform starter

This project is a starter for a personal assistant across:
- Website: responsive browser app
- Android: Capacitor wrapper configuration
- Windows: Electron desktop configuration

## Included now
- Responsive assistant dashboard and chat UI
- Optional server-side OpenAI Responses API integration
- Public CoinGecko market-price display
- Local portfolio/watchlist-style holdings
- Browser voice input when supported
- Local reminders (only while the app/browser is running)
- Local chat history

## Important limits
This is a starter project, not a fully hosted service or a compiled APK/EXE.
You must configure an AI API key on a private server. API usage may cost money.
Do not put API keys in `public/index.html` or commit `.env`.
No exchange trading, wallet transfers, email sending, cloud memory sync, background push notifications, or autonomous computer control is enabled. Add secure integrations and explicit confirmation before external actions.

## Run the website locally
1. Install Node.js LTS.
2. Extract this ZIP.
3. Open a terminal in this folder.
4. Run `npm install`
5. Copy `.env.example` to `.env` and add your OpenAI API key.
6. Run `npm start`
7. Open `http://localhost:3000`

Without an API key, the market dashboard still works; AI chat displays a setup message.

## Windows desktop
Run `npm install`, then `npm run desktop`. Package an installer with `npm run build:windows`.
The desktop app starts a local Express server. For production distribution, bundle and test the server lifecycle and secure API-key configuration.

## Android
Install Node.js and Android platform tools. Then:
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. Open the generated Android project in Android Studio or use a configured cloud Android build.
The included Capacitor config is a starting point; Android build tooling is still required to produce an APK.

## API key
The server expects `OPENAI_API_KEY` in `.env`. Use a key from your OpenAI API account. Never share it in chat, screenshots, or public repositories.


## Security center (added)
- A security guidance page with device-specific instructions.
- Basic suspicious-URL pattern checks. This is only a heuristic warning, not a safety certification or malware scan.
- In the Windows Electron build, the button can request a Microsoft Defender Quick Scan through PowerShell. The result/progress is checked in Windows Security.
- In Android and ordinary browsers, it directs the user to built-in security tools (such as Google Play Protect). Android apps cannot silently inspect all installed apps/files or control Play Protect.
- It does not monitor the device continuously, inspect all files, detect every threat, or send background alerts. Those require OS-level permissions, native security integrations and, for ongoing monitoring, a dedicated security product.
