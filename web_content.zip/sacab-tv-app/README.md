# SACAB TV – Web Application (Source)

Premium streaming app. Black + gold (#F2C900). Firebase backend.

## Super Admin
Email: **abdimalikbaashi@gmail.com**  
Same login as users → Profile → **Admin Dashboard** (only for admin).

## Setup Firebase
1. Console → Authentication → Sign-in method → **Email/Password → Enable**
2. Realtime Database → Rules (start):

```json
{
  "rules": {
    ".read": true,
    ".write": "auth != null"
  }
}
```

## Run
Open `index.html` via local server (Acode / VS Code Live Server / Netlify).

## Edit
| Folder | Purpose |
|--------|---------|
| `index.html` | All screens |
| `css/app.css` | Design |
| `js/app.js` | Logic |
| `js/firebase-config.js` | Firebase keys |
| `js/i18n.js` | English / Somali |
| `assets/logo.png` | Logo |

## Features
Login/Register, Home, Search, Categories, My List, Player, Admin (content + ads), bilingual.
EOF
