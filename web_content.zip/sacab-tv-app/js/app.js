(function () {
  "use strict";

  var user = null;
  var profile = null;
  var isAdmin = false;
  var content = [];
  var currentItem = null;
  var currentSeasonIdx = 0;
  var playQueue = null; // { seriesId, seasonIdx, epIdx, list: [...] }

  function $(id) { return document.getElementById(id); }
  function show(el) { if (el) el.classList.remove("hidden"); }
  function hide(el) { if (el) el.classList.add("hidden"); }
  function toast(msg) {
    var t = $("toast");
    if (!t) return;
    t.textContent = msg;
    t.classList.add("show");
    setTimeout(function () { t.classList.remove("show"); }, 2500);
  }
  function err(id, msg) {
    var e = $(id);
    if (!e) return;
    e.textContent = msg;
    e.style.display = "block";
  }
  function clearErr(id) {
    var e = $(id);
    if (e) e.style.display = "none";
  }
  function esc(s) {
    var d = document.createElement("div");
    d.textContent = s == null ? "" : String(s);
    return d.innerHTML;
  }

  function showView(name) {
    ["login", "register", "forgot", "app"].forEach(function (v) {
      hide($("view-" + v));
    });
    show($("view-" + name));
  }

  function showPage(name) {
    document.querySelectorAll(".page").forEach(function (p) {
      p.classList.remove("active");
    });
    var page = $("page-" + name);
    if (page) page.classList.add("active");
    document.querySelectorAll(".nav-btn").forEach(function (b) {
      b.classList.toggle("active", b.getAttribute("data-page") === name);
    });
    var nav = $("bottomNav");
    if (nav) {
      nav.style.display = (name === "detail" || name === "admin" || name === "settings") ? "none" : "flex";
    }
    if (name === "home") loadHome();
    if (name === "mylist") loadMyList();
    if (name === "admin") loadAdmin();
  }

  function isSeriesType(t) {
    return t === "series" || t === "anime";
  }

  function normalizeSeasons(item) {
    if (!item) return [];
    if (Array.isArray(item.seasons) && item.seasons.length) {
      return item.seasons.map(function (s, i) {
        return {
          seasonNumber: s.seasonNumber || (i + 1),
          title: s.title || ("Season " + (s.seasonNumber || (i + 1))),
          episodes: Array.isArray(s.episodes) ? s.episodes : []
        };
      });
    }
    // legacy flat episodes → Season 1
    if (Array.isArray(item.episodes) && item.episodes.length) {
      return [{ seasonNumber: 1, title: "Season 1", episodes: item.episodes }];
    }
    return [];
  }

  function countEpisodes(item) {
    var n = 0;
    normalizeSeasons(item).forEach(function (s) {
      n += (s.episodes && s.episodes.length) || 0;
    });
    return n;
  }

  // Boot Firebase
  if (!window.initSacabFirebase || !window.initSacabFirebase()) {
    hide($("view-login"));
    show($("bootError"));
    return;
  }

  var auth = window.auth;
  var db = window.db;

  auth.onAuthStateChanged(function (u) {
    user = u;
    if (!u) {
      showView("login");
      isAdmin = false;
      return;
    }
    loadProfile(u.uid).then(function () {
      showView("app");
      showPage("home");
      checkAdmin(u);
      loadAds();
      if (window.I18N) window.I18N.set(window.I18N.lang);
    });
  });

  function loadProfile(uid) {
    return db.ref("users/" + uid).once("value").then(function (snap) {
      profile = snap.val() || {};
      if (profile.language && window.I18N) window.I18N.set(profile.language);
      if ($("pName")) $("pName").textContent = profile.name || user.displayName || "User";
      if ($("pEmail")) $("pEmail").textContent = user.email || "";
      if (profile.photoURL && $("pAvatar")) $("pAvatar").src = profile.photoURL;
      if ($("langSelect")) $("langSelect").value = window.I18N ? window.I18N.lang : "en";
    }).catch(function () { profile = {}; });
  }

  function checkAdmin(u) {
    isAdmin = false;
    var email = (u.email || "").toLowerCase();
    var superEmail = (window.SUPER_ADMIN_EMAIL || "").toLowerCase();
    return db.ref("admins/" + u.uid).once("value").then(function (snap) {
      var role = snap.val();
      if (role === "super" || role === "editor") isAdmin = true;
      if (email === superEmail) {
        isAdmin = true;
        if (!role) {
          db.ref("admins/" + u.uid).set("super");
          db.ref("users/" + u.uid + "/role").set("super");
        }
      }
      var btn = $("btnAdmin");
      if (btn) {
        if (isAdmin) btn.classList.remove("hidden");
        else btn.classList.add("hidden");
      }
    }).catch(function () {
      if (email === superEmail) {
        isAdmin = true;
        var btn = $("btnAdmin");
        if (btn) btn.classList.remove("hidden");
      }
    });
  }

  // Auth forms
  $("formLogin").addEventListener("submit", function (e) {
    e.preventDefault();
    clearErr("loginErr");
    auth.signInWithEmailAndPassword($("loginEmail").value.trim(), $("loginPassword").value)
      .catch(function (ex) {
        var msg = "Login failed";
        if (ex.code === "auth/user-not-found") msg = "Account not found – Sign Up";
        else if (ex.code === "auth/wrong-password" || ex.code === "auth/invalid-credential") msg = "Wrong email or password";
        else if (ex.code === "auth/operation-not-allowed") msg = "Enable Email/Password in Firebase";
        else if (ex.code === "auth/network-request-failed") msg = "Network error – check internet/VPN";
        else if (ex.message) msg = ex.message;
        err("loginErr", msg);
      });
  });

  $("formRegister").addEventListener("submit", function (e) {
    e.preventDefault();
    clearErr("regErr");
    var name = $("regName").value.trim();
    var email = $("regEmail").value.trim();
    var phone = $("regPhone").value.trim();
    var pass = $("regPass").value;
    var pass2 = $("regPass2").value;
    var lang = $("regLang").value;
    if (pass !== pass2) { err("regErr", "Passwords do not match"); return; }
    if (pass.length < 6) { err("regErr", "Password min 6 characters"); return; }
    auth.createUserWithEmailAndPassword(email, pass).then(function (cred) {
      return cred.user.updateProfile({ displayName: name }).then(function () {
        var data = { name: name, email: email, phone: phone || "", language: lang, role: "user", createdAt: Date.now() };
        var p = db.ref("users/" + cred.user.uid).set(data);
        if (email.toLowerCase() === (window.SUPER_ADMIN_EMAIL || "").toLowerCase()) {
          p = p.then(function () { return db.ref("admins/" + cred.user.uid).set("super"); });
        }
        if (window.I18N) window.I18N.set(lang);
        return p;
      });
    }).catch(function (ex) {
      var msg = "Registration failed";
      if (ex.code === "auth/email-already-in-use") msg = "Email already registered";
      else if (ex.code === "auth/operation-not-allowed") msg = "Enable Email/Password in Firebase";
      else if (ex.code === "auth/network-request-failed") msg = "Network error";
      else if (ex.message) msg = ex.message;
      err("regErr", msg);
    });
  });

  $("formForgot").addEventListener("submit", function (e) {
    e.preventDefault();
    clearErr("forgotErr");
    $("forgotOk").style.display = "none";
    auth.sendPasswordResetEmail($("forgotEmail").value.trim()).then(function () {
      $("forgotOk").style.display = "block";
    }).catch(function (ex) { err("forgotErr", ex.message || "Failed"); });
  });

  $("linkRegister").onclick = function (e) { e.preventDefault(); showView("register"); };
  $("linkLogin").onclick = function (e) { e.preventDefault(); showView("login"); };
  $("linkForgot").onclick = function (e) { e.preventDefault(); showView("forgot"); };
  $("linkBackLogin").onclick = function (e) { e.preventDefault(); showView("login"); };

  document.querySelectorAll(".nav-btn").forEach(function (b) {
    b.addEventListener("click", function () { showPage(b.getAttribute("data-page")); });
  });
  $("btnGoSearch").onclick = function () { showPage("search"); };
  $("btnGoProfile").onclick = function () { showPage("profile"); };
  $("btnSettings").onclick = function () { showPage("settings"); };
  $("settingsBack").onclick = function () { showPage("profile"); };
  $("btnLogout").onclick = function () { auth.signOut(); };
  $("btnAdmin").onclick = function () {
    if (isAdmin) showPage("admin");
    else toast("Access denied");
  };
  $("adminBack").onclick = function () { showPage("profile"); };
  $("detailBack").onclick = function () { showPage("home"); };
  if ($("langSelect")) {
    $("langSelect").onchange = function () {
      if (window.I18N) window.I18N.set(this.value);
      if (user) db.ref("users/" + user.uid + "/language").set(this.value);
    };
  }

  // ---------- Content ----------
  function loadContent() {
    return db.ref("content").once("value").then(function (snap) {
      var data = snap.val() || {};
      content = Object.keys(data).map(function (id) {
        var item = data[id];
        item.id = id;
        return item;
      });
      content.sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); });
      return content;
    }).catch(function () {
      content = [];
      return content;
    });
  }

  function cardHtml(item) {
    var img = item.poster || item.banner || "assets/logo.png";
    var meta = item.year || "";
    if (isSeriesType(item.type)) {
      var seasons = normalizeSeasons(item);
      meta += (meta ? " · " : "") + seasons.length + " Season" + (seasons.length !== 1 ? "s" : "");
    } else if (item.type) {
      meta += (meta ? " · " : "") + item.type;
    }
    return '<div class="card" data-id="' + item.id + '">' +
      '<img src="' + img + '" alt="" onerror="this.src=\'assets/logo.png\'">' +
      '<div class="t">' + esc(item.title || "") + "</div>" +
      '<div class="m">' + esc(meta) + "</div></div>";
  }

  function bindCards(root) {
    root.querySelectorAll(".card").forEach(function (c) {
      c.onclick = function () {
        var item = content.find(function (x) { return x.id === c.getAttribute("data-id"); });
        if (item) openDetail(item);
      };
    });
  }

  function loadHome() {
    var rows = $("homeRows");
    rows.innerHTML = '<div class="spinner"></div>';
    loadContent().then(function () {
      var feat = content.find(function (c) { return c.featured; }) || content[0];
      if (feat) {
        currentItem = feat;
        $("heroBg").style.backgroundImage = (feat.banner || feat.poster)
          ? "url(" + (feat.banner || feat.poster) + ")" : "";
        $("heroTitle").textContent = feat.title || "SACAB TV";
        $("heroDesc").textContent = feat.description || "";
        $("heroPlay").onclick = function () { startWatch(feat); };
        $("heroInfo").onclick = function () { openDetail(feat); };
      }

      var sections = [
        { title: "Trending Now", filter: function (c) { return c.trending; } },
        { title: "Popular Movies", filter: function (c) { return c.type === "movie"; } },
        { title: "Popular TV Series", filter: function (c) { return c.type === "series"; } },
        { title: "Popular Anime", filter: function (c) { return c.type === "anime"; } },
        { title: "Recently Added", filter: function () { return true; }, limit: 20 }
      ];

      var html = "";
      sections.forEach(function (sec) {
        var items = content.filter(sec.filter);
        if (sec.limit) items = items.slice(0, sec.limit);
        if (!items.length) return;
        html += '<div class="section"><h3>' + sec.title + '</h3><div class="row">' +
          items.map(cardHtml).join("") + "</div></div>";
      });

      // Continue watching
      if (user) {
        db.ref("watchHistory/" + user.uid).once("value").then(function (s) {
          var hist = s.val() || {};
          var ids = Object.keys(hist).sort(function (a, b) {
            return (hist[b].updatedAt || 0) - (hist[a].updatedAt || 0);
          }).slice(0, 12);
          if (ids.length) {
            var cont = ids.map(function (id) {
              return content.find(function (c) { return c.id === id; });
            }).filter(Boolean);
            if (cont.length) {
              var block = '<div class="section"><h3>Continue Watching</h3><div class="row">' +
                cont.map(cardHtml).join("") + "</div></div>";
              rows.insertAdjacentHTML("afterbegin", block);
              bindCards(rows);
            }
          }
        }).catch(function () {});
      }

      rows.innerHTML = html || '<div class="empty">No content yet. Admin can add Movies, Series & Anime.</div>';
      bindCards(rows);
    });
  }

  function openDetail(item) {
    currentItem = item;
    currentSeasonIdx = 0;
    showPage("detail");
    $("detailBanner").style.backgroundImage = "url(" + (item.banner || item.poster || "assets/logo.png") + ")";
    $("detailTitle").textContent = item.title || "";

    var seasons = normalizeSeasons(item);
    var metaParts = [item.year, item.type, item.genre, item.country].filter(Boolean);
    if (isSeriesType(item.type) && seasons.length) {
      metaParts.push(seasons.length + " Season" + (seasons.length !== 1 ? "s" : ""));
      metaParts.push(countEpisodes(item) + " Episodes");
    }
    $("detailMeta").textContent = metaParts.join(" · ");
    $("detailDesc").textContent = item.description || "";

    $("detailPlay").textContent = isSeriesType(item.type) ? "Watch Series" : "Watch Now";
    $("detailPlay").onclick = function () { startWatch(item); };
    updateFavBtn(item.id);
    $("detailFav").onclick = function () { toggleFav(item.id); };

    renderSeasonsAndEpisodes(item);
  }

  function renderSeasonsAndEpisodes(item) {
    var seasons = normalizeSeasons(item);
    var bar = $("seasonBar");
    var eps = $("detailEps");

    if (!isSeriesType(item.type) || !seasons.length) {
      if (bar) bar.style.display = "none";
      eps.innerHTML = "";
      return;
    }

    bar.style.display = "flex";
    bar.innerHTML = seasons.map(function (s, i) {
      return '<button type="button" class="season-btn' + (i === currentSeasonIdx ? " on" : "") +
        '" data-s="' + i + '">' + esc(s.title || ("Season " + (i + 1))) + "</button>";
    }).join("");

    bar.querySelectorAll(".season-btn").forEach(function (btn) {
      btn.onclick = function () {
        currentSeasonIdx = +btn.getAttribute("data-s");
        renderSeasonsAndEpisodes(item);
      };
    });

    var season = seasons[currentSeasonIdx] || { episodes: [] };
    var list = season.episodes || [];
    if (!list.length) {
      eps.innerHTML = '<div class="empty">No episodes in this season yet.</div>';
      return;
    }

    eps.innerHTML = "<h3 style='margin:12px 0 8px;font-size:1rem'>Episodes</h3>" +
      list.map(function (ep, i) {
        var num = ep.episodeNumber || (i + 1);
        var dur = ep.duration ? (" · " + ep.duration) : "";
        return '<div class="ep" data-i="' + i + '">' +
          '<img src="' + (ep.thumbnail || item.poster || "assets/logo.png") + '" onerror="this.src=\'assets/logo.png\'">' +
          "<div><h4>E" + num + " · " + esc(ep.title || ("Episode " + num)) + "</h4>" +
          "<p>" + esc(ep.description || "") + dur + "</p></div></div>";
      }).join("");

    eps.querySelectorAll(".ep").forEach(function (el) {
      el.onclick = function () {
        playEpisode(item, currentSeasonIdx, +el.getAttribute("data-i"));
      };
    });
  }

  function startWatch(item) {
    if (isSeriesType(item.type)) {
      var seasons = normalizeSeasons(item);
      if (!seasons.length || !seasons[0].episodes || !seasons[0].episodes.length) {
        toast("No episodes available");
        return;
      }
      // resume if history has episode index
      if (user) {
        db.ref("watchHistory/" + user.uid + "/" + item.id).once("value").then(function (s) {
          var h = s.val() || {};
          var si = h.seasonIdx || 0;
          var ei = h.episodeIdx || 0;
          if (!seasons[si] || !seasons[si].episodes[ei]) {
            si = 0; ei = 0;
          }
          playEpisode(item, si, ei, h.position || 0);
        }).catch(function () {
          playEpisode(item, 0, 0);
        });
      } else {
        playEpisode(item, 0, 0);
      }
      return;
    }
    // Movie
    playItem({
      id: item.id,
      title: item.title,
      videoUrl: item.videoUrl || item.video,
      isMovie: true
    });
  }

  function playEpisode(series, seasonIdx, epIdx, resumePos) {
    var seasons = normalizeSeasons(series);
    var season = seasons[seasonIdx];
    if (!season || !season.episodes || !season.episodes[epIdx]) {
      toast("Episode not found");
      return;
    }
    var ep = season.episodes[epIdx];
    var url = ep.videoUrl || ep.video || series.videoUrl;
    if (!url) { toast("No video URL for this episode"); return; }

    playQueue = {
      seriesId: series.id,
      seriesTitle: series.title,
      seasonIdx: seasonIdx,
      epIdx: epIdx,
      seasons: seasons
    };

    var title = series.title + " — S" + (season.seasonNumber || (seasonIdx + 1)) +
      "E" + (ep.episodeNumber || (epIdx + 1)) + " " + (ep.title || "");
    playItem({
      id: series.id,
      title: title,
      videoUrl: url,
      seasonIdx: seasonIdx,
      episodeIdx: epIdx,
      resumePos: resumePos || 0
    });
  }

  function playItem(item) {
    var url = item.videoUrl || item.video || "";
    if (!url) { toast("No video URL"); return; }
    $("playerTitle").textContent = item.title || "";
    var v = $("videoEl");
    v.src = url;
    $("player").classList.add("open");
    v.onended = onEpisodeEnded;
    if (item.resumePos) {
      v.addEventListener("loadedmetadata", function once() {
        v.currentTime = item.resumePos;
        v.removeEventListener("loadedmetadata", once);
      });
    } else if (user && item.id && item.isMovie) {
      db.ref("watchHistory/" + user.uid + "/" + item.id).once("value").then(function (s) {
        var d = s.val();
        if (d && d.position) v.currentTime = d.position;
      });
    }
    v.play().catch(function () {});
    currentItem = Object.assign({}, currentItem || {}, item);
  }

  function onEpisodeEnded() {
    if (!playQueue) return;
    var si = playQueue.seasonIdx;
    var ei = playQueue.epIdx;
    var seasons = playQueue.seasons;
    var nextEi = ei + 1;
    var nextSi = si;
    if (seasons[si] && seasons[si].episodes && nextEi < seasons[si].episodes.length) {
      // next episode same season
    } else if (si + 1 < seasons.length && seasons[si + 1].episodes && seasons[si + 1].episodes.length) {
      nextSi = si + 1;
      nextEi = 0;
    } else {
      toast("Series finished");
      return;
    }
    var series = content.find(function (c) { return c.id === playQueue.seriesId; });
    if (series) playEpisode(series, nextSi, nextEi);
  }

  function saveProgress() {
    var v = $("videoEl");
    if (!user || !currentItem || !currentItem.id || !v.currentTime || v.currentTime < 3) return;
    var payload = {
      position: v.currentTime,
      duration: v.duration || 0,
      updatedAt: Date.now(),
      title: currentItem.title || ""
    };
    if (playQueue) {
      payload.seasonIdx = playQueue.seasonIdx;
      payload.episodeIdx = playQueue.epIdx;
    }
    db.ref("watchHistory/" + user.uid + "/" + currentItem.id).update(payload);
  }

  $("playerClose").onclick = function () {
    saveProgress();
    var v = $("videoEl");
    v.pause();
    v.onended = null;
    v.removeAttribute("src");
    v.load();
    $("player").classList.remove("open");
    playQueue = null;
  };

  if ($("playerNext")) {
    $("playerNext").onclick = function () {
      if (!playQueue) { toast("No next episode"); return; }
      onEpisodeEnded();
    };
  }
  if ($("playerPrev")) {
    $("playerPrev").onclick = function () {
      if (!playQueue) return;
      var si = playQueue.seasonIdx;
      var ei = playQueue.epIdx;
      if (ei > 0) {
        ei -= 1;
      } else if (si > 0) {
        si -= 1;
        ei = (playQueue.seasons[si].episodes.length || 1) - 1;
      } else {
        toast("First episode");
        return;
      }
      var series = content.find(function (c) { return c.id === playQueue.seriesId; });
      if (series) playEpisode(series, si, ei);
    };
  }

  // save progress periodically
  setInterval(function () {
    if ($("player") && $("player").classList.contains("open")) saveProgress();
  }, 15000);

  function updateFavBtn(id) {
    if (!user) return;
    db.ref("favorites/" + user.uid + "/" + id).once("value").then(function (s) {
      $("detailFav").textContent = s.exists()
        ? (window.I18N ? window.I18N.get("removeFromList") : "Remove from My List")
        : (window.I18N ? window.I18N.get("addToList") : "Add to My List");
    });
  }

  function toggleFav(id) {
    if (!user) return;
    var ref = db.ref("favorites/" + user.uid + "/" + id);
    ref.once("value").then(function (s) {
      if (s.exists()) {
        ref.remove();
        toast("Removed from My List");
      } else {
        ref.set({ addedAt: Date.now() });
        toast("Added to My List");
      }
      updateFavBtn(id);
    });
  }

  function loadMyList() {
    var grid = $("listGrid");
    if (!user) { grid.innerHTML = '<div class="empty">Login required</div>'; return; }
    grid.innerHTML = '<div class="spinner"></div>';
    Promise.all([loadContent(), db.ref("favorites/" + user.uid).once("value")]).then(function (res) {
      var favs = res[1].val() || {};
      var items = content.filter(function (c) { return favs[c.id]; });
      grid.innerHTML = items.length ? items.map(cardHtml).join("") : '<div class="empty">No results</div>';
      bindCards(grid);
    });
  }

  var searchTimer;
  $("searchInput").oninput = function () {
    var q = this.value.trim().toLowerCase();
    clearTimeout(searchTimer);
    searchTimer = setTimeout(function () {
      var grid = $("searchGrid");
      if (!q) { grid.innerHTML = ""; return; }
      loadContent().then(function () {
        var r = content.filter(function (c) {
          return (c.title || "").toLowerCase().indexOf(q) >= 0 ||
            (c.genre || "").toLowerCase().indexOf(q) >= 0 ||
            (c.type || "").toLowerCase().indexOf(q) >= 0 ||
            (c.country || "").toLowerCase().indexOf(q) >= 0;
        });
        grid.innerHTML = r.length ? r.map(cardHtml).join("") : '<div class="empty">No results</div>';
        bindCards(grid);
      });
    }, 250);
  };

  document.querySelectorAll(".cat-btn").forEach(function (b) {
    b.onclick = function () {
      var type = b.getAttribute("data-type");
      loadContent().then(function () {
        var items = content.filter(function (c) { return c.type === type; });
        var grid = $("catGrid");
        grid.innerHTML = items.length ? items.map(cardHtml).join("") : '<div class="empty">No results</div>';
        bindCards(grid);
      });
    };
  });


  function ensureAdminAccess() {
    if (!user) return Promise.reject(new Error("Not signed in"));
    var email = (user.email || "").toLowerCase();
    var superEmail = (window.SUPER_ADMIN_EMAIL || "").toLowerCase();
    return db.ref("admins/" + user.uid).once("value").then(function (snap) {
      if (snap.exists()) {
        isAdmin = true;
        return snap.val();
      }
      if (email === superEmail) {
        return db.ref("admins/" + user.uid).set("super").then(function () {
          isAdmin = true;
          return db.ref("users/" + user.uid + "/role").set("super");
        }).then(function () { return "super"; });
      }
      return Promise.reject(new Error("PERMISSION_DENIED: Not an admin. Firebase rules block content writes."));
    });
  }

  // ========== ADMIN ==========
  function loadAdmin() {
    if (!isAdmin) { toast("Access denied"); showPage("profile"); return; }
    loadContent().then(function () {
      $("stContent").textContent = content.length;
      renderAdminContent();
    });
    db.ref("users").once("value").then(function (s) {
      var u = s.val() || {};
      $("stUsers").textContent = Object.keys(u).length;
      $("adminUsersList").innerHTML = Object.keys(u).map(function (uid) {
        var x = u[uid];
        return '<div class="list-row"><div class="info"><h4>' + esc(x.name || "User") +
          "</h4><p>" + esc(x.email || "") + " · " + (x.role || "user") + "</p></div></div>";
      }).join("") || '<div class="empty">No users</div>';
    }).catch(function () {
      $("adminUsersList").innerHTML = '<div class="empty">Cannot load users</div>';
    });
    loadAdsForm();
  }

  function renderAdminContent() {
    var list = $("adminContentList");
    list.innerHTML = content.map(function (item) {
      var extra = "";
      if (isSeriesType(item.type)) {
        extra = " · " + normalizeSeasons(item).length + "S / " + countEpisodes(item) + "E";
      }
      return '<div class="list-row">' +
        '<img src="' + (item.poster || "assets/logo.png") + '" onerror="this.src=\'assets/logo.png\'">' +
        '<div class="info"><h4>' + esc(item.title) + "</h4><p>" + esc(item.type || "") + extra +
        (item.featured ? " · Featured" : "") + "</p></div>" +
        '<div class="acts"><button class="sm edit" data-id="' + item.id + '">Edit</button>' +
        '<button class="sm del" data-id="' + item.id + '">Del</button></div></div>';
    }).join("") || '<div class="empty">No content</div>';

    list.querySelectorAll(".edit").forEach(function (b) {
      b.onclick = function () {
        var item = content.find(function (c) { return c.id === b.getAttribute("data-id"); });
        openContentForm(item);
      };
    });
    list.querySelectorAll(".del").forEach(function (b) {
      b.onclick = function () {
        if (!confirm("Delete this title?")) return;
        db.ref("content/" + b.getAttribute("data-id")).remove().then(function () {
          loadAdmin();
          toast("Deleted");
        });
      };
    });
  }

  document.querySelectorAll(".admin-tabs button").forEach(function (b) {
    b.onclick = function () {
      document.querySelectorAll(".admin-tabs button").forEach(function (x) { x.classList.remove("on"); });
      document.querySelectorAll(".admin-panel").forEach(function (x) { x.classList.remove("on"); });
      b.classList.add("on");
      $("tab-" + b.getAttribute("data-tab")).classList.add("on");
    };
  });

  $("btnAddContent").onclick = function () { openContentForm(null); };
  $("modalClose").onclick = function () { $("contentModal").classList.remove("open"); };

  function toggleTypeFields() {
    var t = $("cType").value;
    var series = isSeriesType(t);
    if ($("movieFields")) $("movieFields").style.display = series ? "none" : "block";
    if ($("seriesFields")) $("seriesFields").style.display = series ? "block" : "none";
  }

  if ($("cType")) $("cType").onchange = toggleTypeFields;

  // Seasons editor state
  var editorSeasons = [];

  function renderSeasonsEditor() {
    var box = $("seasonsEditor");
    if (!box) return;
    if (!editorSeasons.length) {
      box.innerHTML = '<p style="color:#666;font-size:0.85rem">No seasons yet. Click “Add Season”.</p>';
      return;
    }
    box.innerHTML = editorSeasons.map(function (s, si) {
      var eps = s.episodes || [];
      return '<div class="season-edit" data-si="' + si + '" style="background:#0e0e0e;border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:12px;margin-bottom:10px">' +
        '<div style="display:flex;gap:8px;align-items:center;margin-bottom:8px">' +
        '<input value="' + esc(s.title || ("Season " + (si + 1))) + '" data-field="title" data-si="' + si + '" placeholder="Season title" style="flex:1">' +
        '<button type="button" class="sm del" data-rm-season="' + si + '">Remove</button></div>' +
        eps.map(function (ep, ei) {
          return '<div style="border-top:1px solid rgba(255,255,255,0.06);padding-top:8px;margin-top:8px">' +
            '<div style="font-size:0.8rem;color:#F2C900;margin-bottom:4px">Episode ' + (ei + 1) +
            ' <button type="button" class="sm del" data-rm-ep="' + si + '-' + ei + '" style="float:right">×</button></div>' +
            '<input placeholder="Title" value="' + esc(ep.title || "") + '" data-ep="' + si + '-' + ei + '-title" style="margin-bottom:4px">' +
            '<input placeholder="Video URL" value="' + esc(ep.videoUrl || "") + '" data-ep="' + si + '-' + ei + '-videoUrl" style="margin-bottom:4px">' +
            '<input placeholder="Thumbnail URL" value="' + esc(ep.thumbnail || "") + '" data-ep="' + si + '-' + ei + '-thumbnail" style="margin-bottom:4px">' +
            '<input placeholder="Duration e.g. 45m" value="' + esc(ep.duration || "") + '" data-ep="' + si + '-' + ei + '-duration" style="margin-bottom:4px">' +
            '<textarea placeholder="Description" rows="2" data-ep="' + si + '-' + ei + '-description">' + esc(ep.description || "") + "</textarea></div>";
        }).join("") +
        '<button type="button" class="btn btn-outline" data-add-ep="' + si + '" style="width:auto;margin-top:8px;font-size:0.8rem">+ Episode</button></div>';
    }).join("");

    box.querySelectorAll("[data-rm-season]").forEach(function (b) {
      b.onclick = function () {
        editorSeasons.splice(+b.getAttribute("data-rm-season"), 1);
        renderSeasonsEditor();
      };
    });
    box.querySelectorAll("[data-add-ep]").forEach(function (b) {
      b.onclick = function () {
        collectEditorFromDOM();
        var si = +b.getAttribute("data-add-ep");
        if (!editorSeasons[si].episodes) editorSeasons[si].episodes = [];
        editorSeasons[si].episodes.push({ title: "", videoUrl: "", thumbnail: "", description: "", duration: "" });
        renderSeasonsEditor();
      };
    });
    box.querySelectorAll("[data-rm-ep]").forEach(function (b) {
      b.onclick = function () {
        collectEditorFromDOM();
        var parts = b.getAttribute("data-rm-ep").split("-");
        var si = +parts[0], ei = +parts[1];
        editorSeasons[si].episodes.splice(ei, 1);
        renderSeasonsEditor();
      };
    });
  }

  function collectEditorFromDOM() {
    var box = $("seasonsEditor");
    if (!box) return;
    box.querySelectorAll("input[data-field=title]").forEach(function (inp) {
      var si = +inp.getAttribute("data-si");
      if (editorSeasons[si]) editorSeasons[si].title = inp.value.trim();
    });
    box.querySelectorAll("[data-ep]").forEach(function (inp) {
      var parts = inp.getAttribute("data-ep").split("-");
      var si = +parts[0], ei = +parts[1], field = parts.slice(2).join("-");
      if (!editorSeasons[si] || !editorSeasons[si].episodes[ei]) return;
      editorSeasons[si].episodes[ei][field] = inp.value;
    });
  }

  if ($("btnAddSeason")) {
    $("btnAddSeason").onclick = function () {
      collectEditorFromDOM();
      editorSeasons.push({
        seasonNumber: editorSeasons.length + 1,
        title: "Season " + (editorSeasons.length + 1),
        episodes: [{ title: "Episode 1", videoUrl: "", thumbnail: "", description: "", duration: "" }]
      });
      renderSeasonsEditor();
    };
  }

  function openContentForm(item) {
    $("modalTitle").textContent = item ? "Edit Content" : "Add Content";
    $("cId").value = item ? item.id : "";
    $("cTitle").value = item ? item.title || "" : "";
    $("cType").value = item ? item.type || "movie" : "movie";
    $("cDesc").value = item ? item.description || "" : "";
    $("cYear").value = item ? item.year || "" : "";
    $("cGenre").value = item ? item.genre || "" : "";
    if ($("cCountry")) $("cCountry").value = item ? item.country || "" : "";
    if ($("cTrailer")) $("cTrailer").value = item ? item.trailerUrl || "" : "";
    $("cPoster").value = item ? item.poster || "" : "";
    $("cBanner").value = item ? item.banner || "" : "";
    if ($("cVideo")) $("cVideo").value = item ? item.videoUrl || "" : "";
    $("cFeat").checked = !!(item && item.featured);
    $("cTrend").checked = !!(item && item.trending);
    editorSeasons = item ? JSON.parse(JSON.stringify(normalizeSeasons(item))) : [];
    toggleTypeFields();
    renderSeasonsEditor();
    $("contentModal").classList.add("open");
  }

  $("formContent").onsubmit = function (e) {
    e.preventDefault();
    collectEditorFromDOM();
    ensureAdminAccess().then(function () {
    var id = $("cId").value || db.ref("content").push().key;
    var type = $("cType").value;
    var payload = {
      title: $("cTitle").value.trim(),
      type: type,
      description: $("cDesc").value.trim(),
      year: parseInt($("cYear").value, 10) || null,
      genre: $("cGenre").value.trim(),
      country: $("cCountry") ? $("cCountry").value.trim() : "",
      trailerUrl: $("cTrailer") ? $("cTrailer").value.trim() : "",
      poster: $("cPoster").value.trim(),
      banner: $("cBanner").value.trim(),
      featured: $("cFeat").checked,
      trending: $("cTrend").checked,
      updatedAt: Date.now()
    };

    if (isSeriesType(type)) {
      payload.seasons = editorSeasons.map(function (s, i) {
        return {
          seasonNumber: i + 1,
          title: s.title || ("Season " + (i + 1)),
          episodes: (s.episodes || []).map(function (ep, j) {
            return {
              episodeNumber: j + 1,
              title: ep.title || ("Episode " + (j + 1)),
              description: ep.description || "",
              thumbnail: ep.thumbnail || "",
              videoUrl: ep.videoUrl || "",
              duration: ep.duration || ""
            };
          })
        };
      });
      payload.videoUrl = "";
    } else {
      payload.videoUrl = $("cVideo") ? $("cVideo").value.trim() : "";
      payload.seasons = [];
    }

    var ref = db.ref("content/" + id);
    var op = $("cId").value
      ? ref.update(payload)
      : ref.set(Object.assign({ createdAt: Date.now() }, payload));
    op.then(function () {
      $("contentModal").classList.remove("open");
      toast("Saved");
      loadAdmin();
    }).catch(function (ex) {
      var m = ex.message || "Save failed";
      if (String(m).indexOf("PERMISSION_DENIED") >= 0 || (ex.code && String(ex.code).indexOf("PERMISSION") >= 0)) {
        m = "PERMISSION_DENIED: Update Realtime Database Rules (see README). Super admin must be in /admins.";
      }
      toast(m);
    });
    }).catch(function (ex) {
      toast(ex.message || "Admin access denied");
    });
  };

  // Ads (unchanged logic)
  function loadAdsForm() {
    db.ref("ads").once("value").then(function (s) {
      var a = s.val() || {};
      var n = a._network || {};
      if ($("adNet")) $("adNet").value = n.provider || "none";
      if ($("adPub")) $("adPub").value = n.publisherId || "";
      setAd("Top", a.home_top);
      setAd("Mid", a.home_mid);
      setAd("Det", a.detail);
    });
  }
  function setAd(key, ad) {
    ad = ad || {};
    if ($("ad" + key + "On")) $("ad" + key + "On").checked = !!ad.enabled;
    if ($("ad" + key + "Img")) $("ad" + key + "Img").value = ad.imageUrl || "";
    if ($("ad" + key + "Link")) $("ad" + key + "Link").value = ad.linkUrl || "";
    if ($("ad" + key + "Html")) $("ad" + key + "Html").value = ad.htmlCode || "";
  }
  if ($("btnSaveAds")) {
    $("btnSaveAds").onclick = function () {
      if (!isAdmin) return;
      db.ref("ads").update({
        _network: { provider: $("adNet").value, publisherId: $("adPub").value.trim(), updatedAt: Date.now() },
        home_top: { enabled: $("adTopOn").checked, imageUrl: $("adTopImg").value.trim(), linkUrl: $("adTopLink").value.trim(), htmlCode: $("adTopHtml").value.trim() },
        home_mid: { enabled: $("adMidOn").checked, imageUrl: $("adMidImg").value.trim(), linkUrl: $("adMidLink").value.trim(), htmlCode: $("adMidHtml").value.trim() },
        detail: { enabled: $("adDetOn").checked, imageUrl: $("adDetImg").value.trim(), linkUrl: $("adDetLink").value.trim(), htmlCode: $("adDetHtml").value.trim() }
      }).then(function () { toast("Ads saved"); loadAds(); });
    };
  }
  function loadAds() {
    db.ref("ads").once("value").then(function (s) {
      var a = s.val() || {};
      renderAd("adHomeTop", a.home_top);
      renderAd("adHomeMid", a.home_mid);
      renderAd("adDetail", a.detail);
    }).catch(function () {});
  }
  function renderAd(elId, ad) {
    var el = $(elId);
    if (!el) return;
    if (!ad || !ad.enabled) { el.classList.remove("show"); el.innerHTML = ""; return; }
    if (ad.htmlCode) { el.innerHTML = ad.htmlCode; el.classList.add("show"); }
    else if (ad.imageUrl) {
      el.innerHTML = '<a href="' + (ad.linkUrl || "#") + '" target="_blank" rel="noopener"><img src="' + ad.imageUrl + '" alt="Ad"></a>';
      el.classList.add("show");
    } else el.classList.remove("show");
  }

  if (window.I18N) window.I18N.set(window.I18N.lang);
})();
