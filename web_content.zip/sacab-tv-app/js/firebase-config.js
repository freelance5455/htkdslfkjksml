/* SACAB TV Firebase – project: sacab-tv */
window.SACAB_CONFIG = {
  apiKey: "AIzaSyBUGNzuSh8VI1GDlYPoSsrnk9ZV4TlPNFI",
  authDomain: "sacab-tv.firebaseapp.com",
  projectId: "sacab-tv",
  databaseURL: "https://sacab-tv-default-rtdb.firebaseio.com",
  storageBucket: "sacab-tv.firebasestorage.app",
  messagingSenderId: "287846086501",
  appId: "1:287846086501:web:868af496d750704d17938c",
  measurementId: "G-R8M41VQMFY"
};
window.SUPER_ADMIN_EMAIL = "abdimalikbaashi@gmail.com";

window.initSacabFirebase = function () {
  if (typeof firebase === "undefined") {
    return false;
  }
  try {
    if (!firebase.apps.length) {
      firebase.initializeApp(window.SACAB_CONFIG);
    }
    window.auth = firebase.auth();
    window.db = firebase.database();
    window.storage = firebase.storage();
    return true;
  } catch (e) {
    console.error(e);
    return false;
  }
};
