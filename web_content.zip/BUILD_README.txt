Ampoule Volume Calculator — Offline Web-to-APK package

Upload this ZIP to an HTML-to-APK builder that supports loading a local index.html bundle.
The entry point is index.html at the ZIP root. Keep all files together and preserve their names.

App behavior:
- English interface; 8 net solution weights in grams per batch.
- Volume (ml) = Net Weight (g) / Specific Gravity.
- Local browser/WebView storage only; no cloud, Firebase, login, or network API.
- Product list contains 16 rows copied from the supplied workbook; Somazina 4ml limits remain unset until entered by the manager.
- Manager PIN is configured locally on first launch.
- CSV export, JSON backup/restore, and print/PDF are provided by the app UI.

Important deployment checks:
1. Configure the builder for an offline/local HTML app (no remote website URL).
2. Enable JavaScript and local storage in its Android WebView settings.
3. Test that records persist after closing and reopening the APK.
4. Test JSON backup/restore and CSV export on the target phone.
5. Keep backup files securely; this ZIP contains no historical measurement records.

Data limitations:
- Offline data is stored separately on each phone. There is no automatic synchronization.
- Existing history can only be transferred if exported from the old app/browser first. Imported timestamps are preserved when present in the backup.
- A Manager PIN is a local convenience control, not strong enterprise authentication.
- Validate product names, SG values, and acceptance limits against the controlled laboratory source before operational use.
