#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
npm install
if [ ! -d android ]; then npx cap add android; fi
npx cap sync android
npx cap open android
