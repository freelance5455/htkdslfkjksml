# Rupauli Public Coaching Management — Android APK Project

## Is project mein kya hai
- `www/index.html`: coaching management app ka offline web app.
- `capacitor.config.json`: Android app identity/configuration.
- `www/assets/app-icon.svg`: app icon artwork reference.
- `BUILD-ANDROID.bat`: Windows par build preparation aur Android Studio open karne ka shortcut.

## Android APK banane ke liye
1. Windows laptop/PC par Node.js 22+ aur Android Studio install karein.
2. Android Studio ke SDK Manager se Android SDK Platform API 24+ install karein. Android Studio apna compatible JDK deta hai.
3. Is ZIP ko extract karein.
4. `BUILD-ANDROID.bat` par double-click karein. Ya project folder mein terminal khol kar ye commands chalayein:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
   `npx cap add android` sirf pehli baar chalana hai.
5. Android Studio mein Gradle sync complete hone dein.
6. Menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Debug APK yahan milega: `android/app/build/outputs/apk/debug/app-debug.apk`.
8. APK phone mein bhej kar install karein. Phone par “Install unknown apps” ki permission prompt aaye to sirf apne banaye APK ke liye allow karein.

## Laptop par chalana
`www/index.html` ko Chrome/Edge mein khol sakte hain. Windows desktop par bhi local browser data alag rahega; Android aur Laptop ka data automatic sync nahi hoga.

## App update karna
`www/index.html` replace/edit karne ke baad project folder mein:
```bash
npx cap sync android
npx cap open android
```
Phir Android Studio se naya APK build karein.

## App ID aur naam
- App name: Rupauli Coaching
- Application ID: `com.sajandigitalhub.rupaulicoaching`

## Login
Default login: `sajan` / `1234`. Pehli login ke baad Settings mein password badlein.

## Data aur security — bahut zaroori
- Ye version offline, single-device local storage par hai. Android aur Laptop ke beech records sync nahi hote.
- App ke browser/WebView storage mein data rehta hai. App uninstall/clear data karne par records mit sakte hain. Backup regularly export karke safe jagah rakhein.
- Login screen aur UI-level action guards casual access rokne ke liye hain. Ye server-side security/encryption nahi hai; device owner/technical user local data ko access kar sakta hai. Sensitive student records ke liye device lock aur regular backup use karein.
- Debug APK testing ke liye hai. Public distribution ke liye Android Studio mein **Build > Generate Signed Bundle / APK** se apni private signing key ke saath signed release APK banayein. Keystore/password ko safe rakhein; update ke liye wahi signing key chahiye.

## Original coaching logo
`www/assets/rupauli-original-logo.png` mein supplied Rupauli Public Coaching badge ko login screen par original form mein use kiya gaya hai. `app-icon.svg` generic launcher artwork reference hai; Android launcher icon ko Android Studio ke Image Asset Studio se original badge PNG ke basis par generate/replace kar sakte hain.
