@echo off
cd /d "%~dp0"
echo [1/4] Installing project dependencies...
call npm install
if errorlevel 1 goto fail
if not exist android\build.gradle (
  echo [2/4] Creating Android project...
  call npx cap add android
  if errorlevel 1 goto fail
) else (
  echo [2/4] Android project already exists.
)
echo [3/4] Syncing web app into Android project...
call npx cap sync android
if errorlevel 1 goto fail
echo [4/4] Opening Android Studio...
call npx cap open android
if errorlevel 1 goto fail
echo Done. In Android Studio choose Build ^> Build Bundle(s) / APK(s) ^> Build APK(s).
pause
exit /b 0
:fail
echo Build preparation failed. Check Node.js and Android Studio installation.
pause
exit /b 1
