"use strict";

const $ = id => document.getElementById(id);
const STORE = "teravideo_studio_v1";
let projects = [];
let currentId = null;
let media = [];
let tracks = [];
let activeUrl = null;
let toastTimer;

function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function safeLoad(){
  try {
    const data = JSON.parse(localStorage.getItem(STORE) || "null");
    if(data && Array.isArray(data.projects)) projects=data.projects;
  } catch(e) { projects=[]; }
  if(!projects.length) projects=[{id:uid(),name:"Meu primeiro vídeo",updated:new Date().toISOString()}];
  currentId=projects[0].id;
  save();
}
function save(){
  try{localStorage.setItem(STORE,JSON.stringify({projects}));}catch(e){}
  renderProjects();
}
function current(){return projects.find(p=>p.id===currentId)}
function notify(message){
  $("toast").textContent=message;
  $("toast").classList.add("show");
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>$("toast").classList.remove("show"),2800);
}
function touch(){if(current())current().updated=new Date().toISOString();save()}
function showPanel(name){
  ["editor","projects","media"].forEach(p=>$(p+"Panel").hidden=p!==name);
  document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active",b.dataset.panel===name));
  if(name==="projects")renderProjects();
  if(name==="media")renderMedia();
}
function openModal(title,description,value,callback){
  $("modalTitle").textContent=title;
  $("modalDescription").textContent=description;
  $("projectName").value=value||"";
  $("modal").hidden=false;
  $("projectName").focus();
  const finish=()=>{
    const v=$("projectName").value.trim();
    $("modal").hidden=true;
    $("confirmModal").removeEventListener("click",confirm);
    $("cancelModal").removeEventListener("click",cancel);
    callback(v);
  };
  const confirm=()=>finish();
  const cancel=()=>{
    $("modal").hidden=true;
    $("confirmModal").removeEventListener("click",confirm);
    $("cancelModal").removeEventListener("click",cancel);
  };
  $("confirmModal").addEventListener("click",confirm);
  $("cancelModal").addEventListener("click",cancel);
}
function newProject(){
  openModal("Novo projeto","Dê um nome à sua produção.","Novo projeto",name=>{
    if(!name)return notify("Digite um nome para o projeto.");
    const p={id:uid(),name,updated:new Date().toISOString()};
    projects.unshift(p);currentId=p.id;tracks=[];media=[];
    clearPreview();save();showPanel("editor");renderTimeline();
    notify("Projeto criado.");
  });
}
function clearPreview(){
  if(activeUrl){URL.revokeObjectURL(activeUrl);activeUrl=null;}
  $("video").pause();$("video").removeAttribute("src");$("video").load();
  $("video").hidden=true;$("welcome").hidden=false;
  $("mediaName").textContent="Nenhuma mídia selecionada";$("duration").textContent="00:00";
}
function formatTime(seconds){
  if(!Number.isFinite(seconds))return "00:00";
  const n=Math.max(0,Math.floor(seconds));
  return String(Math.floor(n/60)).padStart(2,"0")+":"+String(n%60).padStart(2,"0");
}
function importFiles(files){
  const accepted=Array.from(files||[]);
  if(!accepted.length)return;
  accepted.forEach(file=>{
    const item={id:uid(),file,name:file.name,type:file.type||"arquivo",size:file.size};
    media.push(item);
    if(file.type.startsWith("video/")||file.type.startsWith("audio/")||file.type.startsWith("image/")){
      tracks.push({id:uid(),kind:file.type.split("/")[0],name:file.name,file});
    }
  });
  const first=accepted.find(f=>f.type.startsWith("video/"));
  if(first)previewFile(first);
  touch();renderTimeline();renderMedia();
  notify(accepted.length+" arquivo(s) adicionado(s) nesta sessão.");
}
function previewFile(file){
  clearPreview();
  activeUrl=URL.createObjectURL(file);
  $("mediaName").textContent=file.name;
  if(file.type.startsWith("video/")){
    $("video").src=activeUrl;$("video").hidden=false;$("welcome").hidden=true;
    $("video").onloadedmetadata=()=>{$("duration").textContent=formatTime($("video").duration)};
  }else if(file.type.startsWith("image/")){
    $("welcome").hidden=false;
    $("welcome").querySelector("h2").textContent=file.name;
    $("welcome").querySelector("p").textContent="Imagem carregada. Pré-visualização de vídeo não disponível para este arquivo.";
    $("welcome").querySelector(".play-icon").textContent="▧";
    $("welcome").querySelector("#importMain").textContent="Importar outra mídia";
  }else if(file.type.startsWith("audio/")){
    $("welcome").hidden=false;
    $("welcome").querySelector("h2").textContent="Arquivo de áudio selecionado";
    $("welcome").querySelector("p").textContent=file.name;
  }
}
function renderTimeline(){
  const el=$("timeline");el.innerHTML="";
  if(!tracks.length){el.innerHTML='<div class="empty-timeline">Importe mídias ou adicione texto para montar seu projeto.</div>'}
  tracks.forEach(t=>{
    const row=document.createElement("div");row.className="clip";
    const icon=document.createElement("span");icon.className="clip-icon";icon.textContent=t.kind==="text"?"Ｔ":t.kind==="video"?"▶":t.kind==="audio"?"♫":t.kind==="image"?"▧":"⌖";
    const info=document.createElement("div");info.className="clip-info";
    const name=document.createElement("b");name.textContent=t.name;
    const desc=document.createElement("small");desc.textContent=t.kind==="text"?"Faixa de texto (estrutura visual)":t.kind==="marker"?"Marcador de edição":"Mídia importada · duração original não editada";
    info.append(name,desc);
    const del=document.createElement("button");del.textContent="Remover";del.addEventListener("click",()=>{tracks=tracks.filter(x=>x.id!==t.id);renderTimeline();touch()});
    row.append(icon,info,del);el.append(row);
  });
  $("trackCount").textContent=tracks.length+" item(ns) na linha do tempo";
}
function renderProjects(){
  const list=$("projectList");if(!list)return;list.innerHTML="";
  projects.forEach(p=>{
    const card=document.createElement("article");card.className="project-card";
    const title=document.createElement("h3");title.textContent=p.name;
    const date=document.createElement("p");date.textContent="Atualizado: "+new Date(p.updated).toLocaleDateString("pt-BR");
    const open=document.createElement("button");open.className="primary";open.textContent=p.id===currentId?"Projeto atual":"Abrir projeto";
    open.addEventListener("click",()=>{
      currentId=p.id;tracks=[];media=[];clearPreview();renderTimeline();$("projectTitle").textContent=p.name;showPanel("editor");
      notify("Projeto aberto. Importe novamente os arquivos para continuar.");
    });
    const rename=document.createElement("button");rename.className="secondary";rename.textContent="Renomear";
    rename.addEventListener("click",()=>openModal("Renomear projeto","Escolha um novo nome.",p.name,name=>{if(name){p.name=name;if(p.id===currentId)$("projectTitle").textContent=name;touch()}}));
    card.append(title,date,open,rename);list.append(card);
  });
}
function renderMedia(){
  const grid=$("mediaLibrary");if(!grid)return;grid.innerHTML="";
  if(!media.length){grid.innerHTML='<div class="project-card"><h3>Nenhuma mídia nesta sessão</h3><p>Importe vídeos, imagens ou áudios para começar.</p></div>';return}
  media.forEach(m=>{
    const card=document.createElement("article");card.className="media-card";
    const ico=document.createElement("div");ico.className="media-icon";ico.textContent=m.type.startsWith("video/")?"▶":m.type.startsWith("audio/")?"♫":m.type.startsWith("image/")?"▧":"▤";
    const name=document.createElement("b");name.textContent=m.name;
    const size=document.createElement("p");size.textContent=(m.size/1024/1024).toFixed(2)+" MB";
    const preview=document.createElement("button");preview.className="secondary";preview.textContent="Pré-visualizar";
    preview.addEventListener("click",()=>{previewFile(m.file);showPanel("editor")});
    card.append(ico,name,size,preview);grid.append(card);
  });
}
function addText(){
  openModal("Adicionar texto","Digite o conteúdo que deseja organizar como faixa.", "Meu texto",value=>{
    if(!value)return notify("Digite algum texto.");
    tracks.push({id:uid(),kind:"text",name:value});
    renderTimeline();touch();notify("Faixa de texto adicionada à estrutura do projeto.");
  });
}
safeLoad();
$("projectTitle").textContent=current().name;
renderTimeline();
$("newProject").addEventListener("click",newProject);
$("newProject2").addEventListener("click",newProject);
$("renameProject").addEventListener("click",()=>openModal("Renomear projeto","Digite o novo nome.",current().name,name=>{if(name){current().name=name;$("projectTitle").textContent=name;touch()}}));
document.querySelectorAll(".nav").forEach(b=>b.addEventListener("click",()=>showPanel(b.dataset.panel)));
$("importMain").addEventListener("click",()=>$("mediaInput").click());
$("importLibrary").addEventListener("click",()=>$("mediaInput").click());
$("mediaInput").addEventListener("change",e=>{importFiles(e.target.files);e.target.value=""});
$("addText").addEventListener("click",addText);
$("addMarker").addEventListener("click",()=>{tracks.push({id:uid(),kind:"marker",name:"Marcador "+(tracks.filter(t=>t.kind==="marker").length+1)});renderTimeline();touch();notify("Marcador adicionado.")});
$("clearTimeline").addEventListener("click",()=>{if(!tracks.length)return notify("A linha do tempo já está vazia.");tracks=[];renderTimeline();touch();notify("Linha do tempo limpa.")});
$("prepareExport").addEventListener("click",()=>{
  if(!tracks.length)return notify("Adicione mídias ou texto primeiro.");
  alert("Projeto preparado para revisão. Esta versão ainda não renderiza um MP4 final. Para exportar de verdade, é necessário integrar um motor de renderização e montar as faixas de vídeo, áudio e texto.");
});
$("video").addEventListener("timeupdate",()=>{$("duration").textContent=formatTime($("video").currentTime)+" / "+formatTime($("video").duration)});
window.addEventListener("beforeunload",()=>{if(activeUrl)URL.revokeObjectURL(activeUrl)});
