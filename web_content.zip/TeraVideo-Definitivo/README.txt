TERAVIDEO STUDIO 1.0
====================

COMO ABRIR
1. Extraia o ZIP.
2. Abra index.html em um navegador moderno.
3. Para melhor compatibilidade, hospede os arquivos em um servidor HTTPS.

RECURSOS IMPLEMENTADOS
- Interface adaptável para celular e computador.
- Criação, seleção e renomeação de projetos.
- Importação de vídeos, imagens e áudio.
- Pré-visualização local de vídeos.
- Biblioteca temporária de mídia.
- Estrutura visual de linha do tempo.
- Faixas de texto e marcadores.
- Salvamento local dos nomes dos projetos.

LIMITAÇÕES IMPORTANTES
- Não é um editor multipista profissional completo.
- A linha do tempo organiza itens, mas ainda não executa cortes reais.
- Os arquivos de mídia não são guardados permanentemente.
- Os projetos não guardam as mídias importadas depois que a sessão termina.
- Não existe renderização/exportação real de MP4 nesta versão.
- Login Google/YouTube e publicação direta não estão integrados.
- Um APK nativo precisa de um projeto Android, compilação e assinatura.
- Renomear um ZIP para APK não o transforma em aplicativo Android.

Para um editor profissional, a próxima etapa é integrar um motor de renderização,
um sistema real de faixas e cortes e, separadamente, a autenticação oficial
do YouTube para publicação autorizada.
