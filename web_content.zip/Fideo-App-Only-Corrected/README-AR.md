# Fideo — تطبيق أندرويد فقط

هذه الحزمة هي تطبيق Fideo فقط، وليست لوحة التحكم.

- نقطة تشغيل التطبيق: `app/src/main/assets/index.html`
- إعداد Supabase: `app/src/main/assets/config.js`
- الحزمة: `com.fideo.social`
- ناتج البناء: `app/build/outputs/apk/debug/app-debug.apk`

لوحة التحكم غير موجودة في هذه الحزمة عمدًا لتجنب فتحها بالخطأ.
