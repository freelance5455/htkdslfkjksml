(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const state = { music: [], videos: [], history: [], currentTrack: -1, toastTimer: null };
  const audio = $("audioPlayer");
  const views = [...document.querySelectorAll(".view")];
  const navItems = [...document.querySelectorAll(".nav-item")];

  function toast(message) {
    const el = $("toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => el.classList.remove("show"), 2700);
  }
  function safeText(value) { return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function formatTime(seconds) {
    if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
    const m = Math.floor(seconds / 60), s = Math.floor(seconds % 60);
    return `${m}:${String(s).padStart(2,"0")}`;
  }
  function go(viewId) {
    views.forEach(v => v.classList.toggle("active", v.id === viewId));
    navItems.forEach(n => n.classList.toggle("active", n.dataset.view === viewId));
    window.scrollTo({top:0, behavior:"smooth"});
  }
  document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => go(b.dataset.go)));
  navItems.forEach(b => b.addEventListener("click", () => go(b.dataset.view)));

  $("themeToggle").addEventListener("click", () => {
    document.body.classList.toggle("light");
    $("themeToggle").textContent = document.body.classList.contains("light") ? "☾" : "☼";
    toast(document.body.classList.contains("light") ? "Light theme enabled" : "Dark theme enabled");
  });
  $("aboutBtn").addEventListener("click", () => $("aboutDialog").showModal());
  $("closeAbout").addEventListener("click", () => $("aboutDialog").close());
  $("aboutOkay").addEventListener("click", () => $("aboutDialog").close());

  function openFilePicker(id) { $(id).click(); }
  $("homeUploadMusic").addEventListener("click", () => openFilePicker("musicInput"));
  $("uploadMusicBtn").addEventListener("click", () => openFilePicker("musicInput"));
  $("emptyMusicUpload").addEventListener("click", () => openFilePicker("musicInput"));
  $("libraryUploadMusic").addEventListener("click", () => openFilePicker("musicInput"));
  $("uploadVideoBtn").addEventListener("click", () => openFilePicker("videoInput"));
  $("emptyVideoUpload").addEventListener("click", () => openFilePicker("videoInput"));
  $("libraryUploadVideo").addEventListener("click", () => openFilePicker("videoInput"));

  $("musicInput").addEventListener("change", (e) => {
    const files = [...e.target.files].filter(f => f.type.startsWith("audio/") || /\.(mp3|m4a|wav|ogg|aac|flac)$/i.test(f.name));
    files.forEach(file => state.music.push({file, url:URL.createObjectURL(file), name:file.name.replace(/\.[^.]+$/,"")}));
    e.target.value = "";
    renderMusic();
    updateStats();
    if (files.length) toast(`${files.length} audio file${files.length===1?"":"s"} added`);
  });
  $("videoInput").addEventListener("change", (e) => {
    const files = [...e.target.files].filter(f => f.type.startsWith("video/") || /\.(mp4|webm|mov|m4v|ogv)$/i.test(f.name));
    files.forEach(file => state.videos.push({file, url:URL.createObjectURL(file), name:file.name.replace(/\.[^.]+$/,"")}));
    e.target.value = "";
    renderVideos();
    updateStats();
    if (files.length) toast(`${files.length} video file${files.length===1?"":"s"} added`);
  });

  function playTrack(index) {
    if (!state.music.length) { toast("Add audio files first to start listening"); return; }
    index = (index + state.music.length) % state.music.length;
    state.currentTrack = index;
    const track = state.music[index];
    audio.src = track.url;
    $("nowTitle").textContent = track.name;
    $("nowSubtitle").textContent = "Your library";
    $("playerArt").textContent = "♫";
    $("playerBar").hidden = false;
    audio.play().then(() => $("playPause").textContent = "Ⅱ").catch(() => {
      $("playPause").textContent = "▶";
      toast("Tap play to start this track");
    });
    renderMusic();
  }
  $("playPause").addEventListener("click", () => {
    if (!audio.src) { playTrack(0); return; }
    if (audio.paused) audio.play().then(() => $("playPause").textContent = "Ⅱ").catch(() => toast("Playback could not start"));
    else { audio.pause(); $("playPause").textContent = "▶"; }
  });
  $("prevTrack").addEventListener("click", () => playTrack(state.currentTrack - 1));
  $("nextTrack").addEventListener("click", () => playTrack(state.currentTrack + 1));
  $("closePlayer").addEventListener("click", () => { audio.pause(); $("playerBar").hidden = true; });
  audio.addEventListener("ended", () => { if (state.music.length > 1) playTrack(state.currentTrack + 1); else $("playPause").textContent = "▶"; });
  audio.addEventListener("play", () => $("playPause").textContent = "Ⅱ");
  audio.addEventListener("pause", () => $("playPause").textContent = "▶");
  audio.addEventListener("timeupdate", () => {
    $("currentTime").textContent = formatTime(audio.currentTime);
    $("duration").textContent = formatTime(audio.duration);
    $("progress").value = Number.isFinite(audio.duration) && audio.duration ? (audio.currentTime/audio.duration)*100 : 0;
  });
  $("progress").addEventListener("input", () => { if (Number.isFinite(audio.duration)) audio.currentTime = audio.duration * Number($("progress").value) / 100; });

  function renderMusic() {
    const q = $("musicSearch").value.trim().toLowerCase();
    const filtered = state.music.map((track,index)=>({...track,index})).filter(t=>t.name.toLowerCase().includes(q));
    $("musicEmpty").hidden = state.music.length > 0;
    $("musicList").innerHTML = filtered.map(t => `<div class="track"><div class="track-art">♫</div><div class="track-info"><strong>${safeText(t.name)}</strong><small>${safeText(t.file.type || "Audio file")} · ${formatBytes(t.file.size)}</small></div><button data-play="${t.index}" aria-label="Play ${safeText(t.name)}">▶</button><button data-remove-music="${t.index}" aria-label="Remove ${safeText(t.name)}">×</button></div>`).join("");
    $("musicList").querySelectorAll("[data-play]").forEach(b=>b.addEventListener("click",()=>playTrack(Number(b.dataset.play))));
    $("musicList").querySelectorAll("[data-remove-music]").forEach(b=>b.addEventListener("click",()=>removeMusic(Number(b.dataset.removeMusic))));
  }
  function removeMusic(index) {
    const track = state.music[index]; if (!track) return;
    if (state.currentTrack === index) { audio.pause(); audio.removeAttribute("src"); $("playerBar").hidden = true; state.currentTrack = -1; }
    else if (state.currentTrack > index) state.currentTrack--;
    URL.revokeObjectURL(track.url); state.music.splice(index,1); renderMusic(); updateStats(); toast("Track removed from this session");
  }
  $("musicSearch").addEventListener("input", renderMusic);

  function renderVideos() {
    const q = $("videoSearch").value.trim().toLowerCase();
    const filtered = state.videos.map((video,index)=>({...video,index})).filter(v=>v.name.toLowerCase().includes(q));
    $("videoEmpty").hidden = state.videos.length > 0;
    $("videoList").innerHTML = filtered.map(v=>`<button class="video-card-item" data-video="${v.index}"><div class="video-thumb">▶</div><div class="video-item-title">${safeText(v.name)}<small>${formatBytes(v.file.size)} · Tap to play</small></div></button>`).join("");
    $("videoList").querySelectorAll("[data-video]").forEach(b=>b.addEventListener("click",()=>playVideo(Number(b.dataset.video))));
  }
  function playVideo(index) {
    const video = state.videos[index]; if (!video) return;
    $("videoPlayer").src = video.url; $("videoCaption").textContent = video.name;
    $("videoDialog").showModal();
    $("videoPlayer").play().catch(()=>{});
  }
  $("closeVideo").addEventListener("click", closeVideo);
  $("videoDialog").addEventListener("click", e=>{ if(e.target === $("videoDialog")) closeVideo(); });
  function closeVideo() { $("videoPlayer").pause(); $("videoPlayer").removeAttribute("src"); $("videoPlayer").load(); $("videoDialog").close(); }
  $("videoSearch").addEventListener("input", renderVideos);

  function formatBytes(bytes) {
    if (!bytes) return "0 B";
    const units=["B","KB","MB","GB"], i=Math.min(Math.floor(Math.log(bytes)/Math.log(1024)),3);
    return `${(bytes/Math.pow(1024,i)).toFixed(i===0?0:1)} ${units[i]}`;
  }
  function updateStats() {
    $("musicCount").textContent = state.music.length;
    $("videoCount").textContent = state.videos.length;
    $("siteCount").textContent = state.history.length;
  }

  function normalizeUrl(raw) {
    let value = raw.trim();
    if (!value) return null;
    if (!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(value)) {
      if (value.includes(".") && !value.includes(" ")) value = "https://" + value;
      else return "https://www.google.com/search?q=" + encodeURIComponent(value);
    }
    try {
      const url = new URL(value);
      if (!["http:","https:"].includes(url.protocol)) return null;
      return url.href;
    } catch { return null; }
  }
  function openSite(raw) {
    const url = normalizeUrl(raw);
    if (!url) { toast("Enter a valid website address or search phrase"); return; }
    const opened = window.open(url, "_blank", "noopener,noreferrer");
    // Some webviews block popups. In that case, offer the user a direct click target.
    state.history = [{url, label: new URL(url).hostname.replace(/^www\./,"")}, ...state.history.filter(x=>x.url!==url)].slice(0,8);
    renderHistory(); updateStats();
    if (!opened) toast("Pop-up blocked. Allow pop-ups or open this address in your browser.");
    else toast("Website opened in a new tab");
  }
  $("browserForm").addEventListener("submit", e=>{e.preventDefault();openSite($("urlInput").value);});
  document.querySelectorAll("[data-site]").forEach(b=>b.addEventListener("click",()=>openSite(b.dataset.site)));
  function renderHistory() {
    $("historyList").innerHTML = state.history.length ? state.history.map((item,i)=>`<div class="history-item"><span>◎</span><span>${safeText(item.label)}</span><button data-history="${i}">Open ↗</button></div>`).join("") : '<p class="muted">Websites you open from here will appear in this list.</p>';
    $("historyList").querySelectorAll("[data-history]").forEach(b=>b.addEventListener("click",()=>openSite(state.history[Number(b.dataset.history)].url)));
  }

  // Release temporary file URLs when the page is closed.
  window.addEventListener("beforeunload", () => {
    state.music.forEach(x=>URL.revokeObjectURL(x.url));
    state.videos.forEach(x=>URL.revokeObjectURL(x.url));
  });
  renderMusic(); renderVideos(); updateStats();
})();