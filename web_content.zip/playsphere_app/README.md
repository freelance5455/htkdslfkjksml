# PlaySphere — Entertainment App Starter

A mobile-first HTML, CSS and JavaScript entertainment app starter with:
- Local music upload and playback
- Local video upload and playback
- Search/filter for selected media
- Favorite entertainment website shortcuts and address/search launcher
- Dark/light theme toggle
- Responsive bottom navigation and library statistics

## Run it on Android
1. Extract `playsphere_app.zip` into a folder.
2. Open `index.html` in a browser, or open the folder in a code editor such as Acode and use its preview.
3. Select **Music** or **Videos** and choose media files from your device.
4. Use **Browser** to open entertainment websites in a new tab.

## Make an Android APK
Use a reputable HTML-to-APK builder or package the project in a WebView-based Android app. Include `index.html`, `style.css`, and `app.js` together in the app's local assets. Test on a real Android device before distributing it.

## Current limitations
- Selected media is local to the current page session. It is not uploaded to a server and usually disappears when the page/session is closed.
- The Browser section opens sites in a new browser tab. It is not a full in-app browser.
- Third-party streaming sites may prohibit embedding or require their official app/login.
- This starter does not include user accounts, cloud uploads, shared libraries, playlists saved permanently, or a backend database.
- Only upload or stream content you have the right to use.

## Suggested next steps for a production app
- Add a backend API and authenticated accounts.
- Store uploaded files in object storage and metadata in a database.
- Add upload size limits, moderation/reporting, privacy controls, and access permissions.
- Use official embeds/APIs where a platform permits them.
