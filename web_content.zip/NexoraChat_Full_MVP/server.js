const express = require("express");
const http = require("http");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "DEV_ONLY_change_me_before_public_deploy_7d3a9f21";
const dbDir = path.join(__dirname, "data");
const dbFile = path.join(dbDir, "db.json");
fs.mkdirSync(dbDir, { recursive: true });
if (!fs.existsSync(dbFile)) fs.writeFileSync(dbFile, JSON.stringify({ users: [], messages: [], groups: [] }, null, 2));

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function readDB() {
  try {
    const d = JSON.parse(fs.readFileSync(dbFile, "utf8"));
    return { users: d.users || [], messages: d.messages || [], groups: d.groups || [] };
  } catch { return { users: [], messages: [], groups: [] }; }
}
function writeDB(db) { fs.writeFileSync(dbFile, JSON.stringify(db, null, 2)); }
function publicUser(u) { return { id: u.id, username: u.username, displayName: u.displayName, about: u.about || "", createdAt: u.createdAt }; }
function makeToken(u) { return jwt.sign({ id: u.id, username: u.username }, JWT_SECRET, { expiresIn: "14d" }); }
function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : "";
  try {
    if (!token) throw new Error("missing");
    const payload = jwt.verify(token, JWT_SECRET);
    const user = readDB().users.find(u => u.id === payload.id);
    if (!user) throw new Error("missing user");
    req.user = user; next();
  } catch { res.status(401).json({ error: "Please sign in again." }); }
}
function validUsername(v) { return /^[a-zA-Z0-9_]{3,20}$/.test(v); }

app.get("/health", (_req, res) => res.json({ success: true, app: "Nexora Chat", status: "online" }));
app.post("/api/register", async (req, res) => {
  const username = String(req.body.username || "").trim().toLowerCase();
  const displayName = String(req.body.displayName || "").trim().slice(0, 32);
  const password = String(req.body.password || "");
  if (!validUsername(username)) return res.status(400).json({ error: "Username 3–20 characters ka ho; letters, numbers aur _ use karo." });
  if (displayName.length < 1) return res.status(400).json({ error: "Apna display name likho." });
  if (password.length < 8) return res.status(400).json({ error: "Password kam se kam 8 characters ka hona chahiye." });
  const db = readDB();
  if (db.users.some(u => u.username === username)) return res.status(409).json({ error: "Ye username pehle se registered hai." });
  const user = { id: crypto.randomUUID(), username, displayName, passwordHash: await bcrypt.hash(password, 10), about: "", createdAt: new Date().toISOString() };
  db.users.push(user); writeDB(db);
  res.json({ token: makeToken(user), user: publicUser(user) });
});
app.post("/api/login", async (req, res) => {
  const username = String(req.body.username || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = readDB().users.find(u => u.username === username);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ error: "Username ya password galat hai." });
  res.json({ token: makeToken(user), user: publicUser(user) });
});
app.get("/api/me", auth, (req, res) => res.json({ user: publicUser(req.user) }));
app.patch("/api/me", auth, (req, res) => {
  const db = readDB();
  const u = db.users.find(x => x.id === req.user.id);
  if (typeof req.body.displayName === "string" && req.body.displayName.trim()) u.displayName = req.body.displayName.trim().slice(0, 32);
  if (typeof req.body.about === "string") u.about = req.body.about.trim().slice(0, 120);
  writeDB(db); res.json({ user: publicUser(u) });
});
app.get("/api/users", auth, (req, res) => {
  const q = String(req.query.q || "").trim().toLowerCase();
  if (q.length < 2) return res.json({ users: [] });
  const users = readDB().users.filter(u => u.id !== req.user.id && (u.username.includes(q) || u.displayName.toLowerCase().includes(q))).slice(0, 30).map(publicUser);
  res.json({ users });
});
app.get("/api/chats/:otherId/messages", auth, (req, res) => {
  const db = readDB();
  const other = db.users.find(u => u.id === req.params.otherId);
  if (!other || other.id === req.user.id) return res.status(404).json({ error: "User nahi mila." });
  const messages = db.messages.filter(m => m.kind === "dm" &&
    ((m.fromId === req.user.id && m.toId === other.id) || (m.fromId === other.id && m.toId === req.user.id))
  ).slice(-300);
  res.json({ messages });
});
app.post("/api/groups", auth, (req, res) => {
  const title = String(req.body.title || "").trim().slice(0, 50);
  if (title.length < 2) return res.status(400).json({ error: "Group name kam se kam 2 characters ka ho." });
  const db = readDB();
  const group = { id: crypto.randomUUID(), title, memberIds: [req.user.id], createdBy: req.user.id, createdAt: new Date().toISOString() };
  db.groups.push(group); writeDB(db);
  res.json({ group });
});
app.get("/api/groups", auth, (req, res) => {
  const groups = readDB().groups.filter(g => g.memberIds.includes(req.user.id));
  res.json({ groups });
});

const online = new Map(); // userId -> Set(socketId)
function roomFor(a, b) { return "dm:" + [a, b].sort().join(":"); }
io.use((socket, next) => {
  try {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    const payload = jwt.verify(token, JWT_SECRET);
    const user = readDB().users.find(u => u.id === payload.id);
    if (!user) return next(new Error("Unauthorized"));
    socket.data.user = publicUser(user);
    next();
  } catch { next(new Error("Unauthorized")); }
});
io.on("connection", socket => {
  const me = socket.data.user;
  if (!online.has(me.id)) online.set(me.id, new Set());
  online.get(me.id).add(socket.id);
  io.emit("presence", [...online.keys()]);
  socket.on("dm:join", otherId => {
    if (typeof otherId !== "string" || otherId === me.id) return;
    const exists = readDB().users.some(u => u.id === otherId);
    if (exists) socket.join(roomFor(me.id, otherId));
  });
  socket.on("dm:send", payload => {
    const toId = String(payload && payload.toId || "");
    const text = String(payload && payload.text || "").trim().slice(0, 4000);
    if (!text || !toId || toId === me.id) return;
    const db = readDB();
    if (!db.users.some(u => u.id === toId)) return;
    const message = { id: crypto.randomUUID(), kind: "dm", fromId: me.id, toId, fromName: me.displayName, text, createdAt: new Date().toISOString(), status: "sent" };
    db.messages.push(message);
    if (db.messages.length > 20000) db.messages = db.messages.slice(-20000);
    writeDB(db);
    io.to(roomFor(me.id, toId)).emit("dm:new", message);
    // Also notify the recipient's other devices even if the chat isn't open.
    for (const sid of (online.get(toId) || [])) io.to(sid).emit("dm:new", message);
    socket.emit("dm:ack", { id: message.id, status: "sent" });
  });
  socket.on("call:signal", payload => {
    const toId = String(payload && payload.toId || "");
    if (!toId || toId === me.id) return;
    for (const sid of (online.get(toId) || [])) io.to(sid).emit("call:signal", { fromId: me.id, fromName: me.displayName, data: payload.data });
  });
  socket.on("disconnect", () => {
    const set = online.get(me.id);
    if (set) { set.delete(socket.id); if (!set.size) online.delete(me.id); }
    io.emit("presence", [...online.keys()]);
  });
});

server.listen(PORT, "0.0.0.0", () => console.log(`Nexora Chat MVP running on http://127.0.0.1:${PORT}`));