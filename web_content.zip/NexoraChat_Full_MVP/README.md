# Nexora Chat — Full MVP Starter

This is a more complete starter than a static mockup. It includes a server and a mobile-friendly web client.

## Features included
- Register/login with username and password (password hashes via bcryptjs)
- JWT session tokens
- Search registered users by username/display name
- One-to-one real-time messages via Socket.IO
- Message history stored in a local JSON database
- Basic online/offline presence
- Editable display name and About
- Create a group record (group chat and member invitations are not implemented yet)
- Experimental one-to-one voice/video call signaling using WebRTC (requires HTTPS or localhost, permissions, and both users online)
- Health endpoint at `/health`

## Run in Termux
1. Extract this ZIP.
2. Open Termux and `cd` to the extracted `NexoraChat_Full_MVP` folder (use the actual path where you extracted it).
3. Run `pkg install nodejs` if Node.js is not installed.
4. Run `npm install`
5. Copy `.env.example` to `.env` and set a long random `JWT_SECRET`. For local testing it starts without `.env`, but that default is not safe for public hosting.
6. Run `npm start`
7. Open `http://127.0.0.1:3000` in the phone browser.
8. To chat between two devices, deploy the server to a host with HTTPS and give both people the same public app link. Localhost on one phone is not reachable by another person.

## Important limits
This is an MVP starter, **not a production-ready WhatsApp replacement**. The JSON file database is suitable only for local/testing and may be unsafe under concurrent writes. It has no phone OTP, password reset, moderation/admin dashboard, group chat/member invitations, push notifications, file/photo/video sharing, read/delivered receipts, verified end-to-end encryption, TURN relay, call controls/end-call UI, or store-ready Android APK. Voice/video is experimental and needs HTTPS, compatible networks, and additional hardening. Do not use for sensitive/private conversations until a security review and production database/deployment are done.

Before public launch, use a real database, HTTPS, rate limiting, request validation, account recovery, abuse reporting/blocking, backups, logging, privacy policy/terms, and security testing.
