Gestion Financière — V8

V8 reprend V6 et ajoute uniquement les modifications demandées :
- Mes ressources disponibles reste intemporel et indépendant du mois/année.
- Historique déplacé en bas de l'accueil.
- Historique avec accès aux données de Mes ressources disponibles.
- Dettes actuelles devient un bloc indépendant avec 5 lignes manuelles.
- Comptes pour enfants ajouté avec Enfant 1 à Enfant 5.
- Projet 1 à Projet 5 dans Mes ressources.
- Petite indication libre à côté de chaque compte dans Mes ressources uniquement (ex. Banque BESCAM).
- Code d'entrée demandé à l'ouverture/au retour dans l'application pour le profil actif.

Fonctionnement hors connexion et stockage local sur l'appareil.
