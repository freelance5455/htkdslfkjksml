# FeeSarthi v1.2 – kya badla (receipt Save / Share / PDF / Print fix)

## Badli hui files (UI/design bilkul same)
1. `2-ANDROID-APK/app/src/main/java/com/feesarthi/app/MainActivity.kt`  (poori file replace)
2. `2-ANDROID-APK/app/src/main/assets/www/index.html` aur `1-WEBSITE/index.html`  (dono same; sirf receipt JS functions)
3. `2-ANDROID-APK/app/build.gradle`  (versionCode 3 / 1.2)

AndroidManifest.xml, file_paths.xml (FileProvider) pehle se sahi the – unmein badlav ki zaroorat nahi.
Koi storage permission nahi chahiye (minSdk 29 + MediaStore).

## Ab kya hota hai
| Button | Ab |
|---|---|
| ⬇️ फोटो / Photo | PNG `Pictures/FeeSarthi` mein save -> Gallery mein dikhti hai |
| 📷 Share Photo | Android Share Sheet / seedha parent ki WhatsApp chat (FileProvider + ClipData) |
| 📄 PDF Download | PDF `Downloads/FeeSarthi` mein save + dialog: WhatsApp/Share, Open, OK |
| 🖨️ Print (receipt) | Receipt ka PDF Android print screen mein (Save as PDF ya printer) |
| Print (class sheet/report) | Pehle jaisa WebView print |

## Zaroori
- Agar APK kisi online "website to APK" converter se bana hai, to ye buttons kabhi nahi chalenge (native bridge nahi hota).
  Ab aisi APK mein button dabane par saaf message dikhega.
- `start_url` mein hosted link ho to us site par bhi ye naya `index.html` upload karein.
- Build: Android Studio ya GitHub Actions (README-APK.md). Maine yahan Android SDK na hone se APK build nahi kiya.
- Debug APK mein `chrome://inspect` se WebView console dekh sakte hain.
