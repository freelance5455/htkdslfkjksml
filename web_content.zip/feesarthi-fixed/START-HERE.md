# फीस सारथी (FeeSarthi) – Ready to Use

Is zip mein do cheezein hain:

| Folder | Kya hai |
|---|---|
| `1-WEBSITE/` | Website (ek `index.html`) + Firebase rules + phone icon. Hosting par daalni hai. |
| `2-ANDROID-APK/` | Android app project. Isse APK banta hai jisme WhatsApp, PDF, Download sab chalte hain. |

## Sabse pehle (2 minute) – bina kisi setup ke dekhna
`1-WEBSITE/index.html` ko Chrome mein kholein -> naya school banayein -> Settings -> "नमूना डेटा भरें".
(Ye demo mode hai; data sirf us phone mein rehta hai.)

## Asli use ka rasta (sab phones par ek jaisa data)
1. **Firebase banayein** (free): Authentication me Email/Password + Phone enable, Firestore Database create.
   Steps: `1-WEBSITE/README.md`.
2. `1-WEBSITE/index.html` ke upar `FIREBASE_CONFIG` mein apni values daalein; `firestore.rules` Publish karein.
3. Website host karein (Firebase Hosting / Netlify / GitHub Pages) -> aapko `https://...` link milega.
4. **APK**: `2-ANDROID-APK/app/src/main/res/values/strings.xml` mein `start_url` me apna https link daalein,
   phir APK banayein (`2-ANDROID-APK/README-APK.md`: Android Studio ya GitHub Actions).
5. APK install karke login karein. Pehla account Admin banta hai; staff Sign up karke aate hain, Admin approve karta hai.

## Buttons jo ab kaam karte hain (APK mein)
- **WhatsApp:** usi bacche ke parent ke number par WhatsApp khulta hai, raseed ka message likha hua.
- **Share Photo:** raseed ki photo WhatsApp ke zariye bhejna.
- **Photo / PDF Download:** `Downloads/FeeSarthi/` mein save.
- **Print / Class sheet PDF:** Android print screen -> "Save as PDF".
- **Excel (CSV) / Copy:** Downloads mein CSV file, ya copy karke Excel mein paste.

## Zaroor padhein
- APK maine yahan build karke nahi dekha (yahan Android SDK nahi hai). Build mein error aaye to screenshot bhejein.
- Asli SMS OTP aur Firebase ka kharch/seema Firebase ki current sharton par hai; WebView mein OTP kabhi-kabhi reCAPTCHA se atak sakta hai.
- Hafte mein ek baar Settings -> Backup se copy rakhein.
