# फीस सारथी – Android APK (WebView + Native Bridge)

Is project se banne wale APK mein ye buttons asli tarah kaam karte hain:
- **Save PDF / Print** -> Android ka print screen khulta hai -> "Save as PDF" chunein.
- **Download** (raseed photo, Excel CSV) -> file `Downloads/FeeSarthi/` mein save hoti hai.
- **WhatsApp** -> "WhatsApp par bhejein" dabate hi WhatsApp usi parent ke number par khulta hai, raseed ka message pehle se likha hua.
  "Share Photo" se raseed ki photo bhi usi chat mein bheji ja sakti hai.
- **PDF Download** -> raseed ka asli PDF `Downloads/FeeSarthi/` mein save hota hai (print screen ke bina).
- **Copy / Backup share, UPI ऐप, Back button** -> sab APK ke andar chalte hain.
(Online "website to APK" converters ye native kaam nahi karte, isliye wahan ye buttons band rehte hain.)

Zaroori: Android 10 ya usse naya phone. (v1.2 ke badlav: `../CHANGES-HINGLISH.md`)

## APK banane ke 2 tareeke

### Tareeka 1 – Android Studio (computer par)
1. Android Studio install karein -> **Open** -> is folder (`FeeSarthi-Android`) ko chunein. Pehli baar Gradle sync mein kuch minute lagte hain.
2. Menu: **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
3. APK yahan milega: `app/build/outputs/apk/debug/app-debug.apk` -> phone mein bhej kar install karein
   (Settings mein "Install unknown apps" allow karna padega).

### Tareeka 2 – GitHub se apne-aap (Android Studio ke bina)
1. github.com par free account -> **New repository** (naam: feesarthi-apk).
2. Is folder ki **saari files** repository ke root mein upload karein (`.github` folder ke saath).
   Phone se `.github/workflows/build-apk.yml` upload na ho to: Add file -> Create new file -> naam
   `.github/workflows/build-apk.yml` likhein aur is file ka text paste karein.
3. Upar **Actions** tab -> "Build APK" -> kuch minute mein hara tick.
4. Us run par kholein -> neeche **Artifacts -> FeeSarthi-APK** -> download karke install karein.

## Start URL (bahut zaroori faisla)
`app/src/main/res/values/strings.xml` mein `start_url`:
- **Khali** (default): APK ke andar ki app khulti hai = **demo mode** (data sirf is phone mein, internet nahi chahiye).
- **Apni hosted site ka link** (jaise `https://myschool.web.app`): **asli Firebase mode** (sab phones ka data ek jaisa,
  asli OTP). Site update karne par APK dobara nahi banana padta. Asli use ke liye yahi rakhein.
  Hosted site ke `index.html` mein Firebase config bhari honi chahiye aur Rules publish hone chahiye.

## Dhyan rakhein
- Ye APK maine yahan build karke nahi dekha (yahan Android SDK nahi hai). Build mein error aaye to error ka screenshot bhejein.
- Ye debug APK hai (apni personal install ke liye theek). Play Store ke liye release signing alag se karni hoti hai.
- Asli SMS OTP (Firebase Phone) WebView mein kabhi-kabhi reCAPTCHA ki wajah se nahi chalta. Aisa ho to
  `start_url` mein hosted link rakhein; phir bhi na chale to OTP ke liye alag native tareeka lagana padega.
- WhatsApp direct-chat (parent ke number par) har WhatsApp version par nahi chalta; tab share menu khulta hai.
