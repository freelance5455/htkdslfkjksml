package com.feesarthi.app

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

/**
 * FeeSarthi – WebView wrapper (v1.2).
 *
 * A plain WebView cannot download blob:/data: files, cannot open the share sheet with files and
 * cannot print a canvas/PDF. This class gives the web app a native bridge (window.AndroidBridge):
 *
 *   saveFile(name, mime, b64)        image/*  -> Pictures/FeeSarthi (shows in Gallery)
 *                                    others   -> Downloads/FeeSarthi
 *   saveAndOffer(name, mime, b64)    save + native dialog: Share / Open / OK   (used for PDF)
 *   shareFile(name, mime, b64, text, phone)   Android Share Sheet (WhatsApp first if phone given)
 *   printPdf(jobName, b64)           Android print screen for a generated PDF (receipt)
 *   printPage(title, landscape)      Android print screen for the current WebView page (reports)
 *   openWhatsApp / copyText / openUrl / isNative / bridgeVersion
 *
 * No storage permission is needed: minSdk is 29 and files are written through MediaStore.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var startHost = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        if (debuggable) WebView.setWebContentsDebuggingEnabled(true)   // chrome://inspect

        val startUrl = getString(R.string.start_url).trim()
        startHost = if (startUrl.isNotEmpty()) (Uri.parse(startUrl).host ?: "") else ""

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.setSupportZoom(false)
        s.mediaPlaybackRequiresUserGesture = false

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webChromeClient = WebChromeClient()   // JS dialogs / console support
        web.setDownloadListener { url, _, _, mime, _ ->
            // Fallback for <a download href="data:..."> ; blob: links are handled by the JS bridge calls.
            if (url.startsWith("data:") && url.contains(";base64,")) {
                try {
                    val head = url.substringBefore(";base64,").removePrefix("data:")
                    val type = if (head.isNotEmpty()) head else (mime ?: "application/octet-stream")
                    val ext = when {
                        type.contains("png") -> ".png"
                        type.contains("jpeg") -> ".jpg"
                        type.contains("pdf") -> ".pdf"
                        type.contains("csv") -> ".csv"
                        else -> ".bin"
                    }
                    saveToStore("FeeSarthi_" + System.currentTimeMillis() + ext, type, Base64.decode(url.substringAfter(";base64,"), Base64.DEFAULT))
                } catch (e: Exception) {
                    toast("सेव नहीं हो सका: " + e.message)
                }
            } else {
                openExternal(Uri.parse(url))
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val host = u.host ?: ""
                val webScheme = u.scheme == "https" || u.scheme == "http"
                val internal = webScheme &&
                    (host == WebViewAssetLoader.DEFAULT_DOMAIN || (startHost.isNotEmpty() && host == startHost))
                if (internal) return false
                openExternal(u)   // wa.me, upi://, tel:, mailto:, other sites -> open in the proper app
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(typeof appBack==='function')?String(appBack()):'false'") { r ->
                    if (r == null || !r.contains("true")) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        web.loadUrl(
            if (startUrl.isNotEmpty()) startUrl
            else "https://" + WebViewAssetLoader.DEFAULT_DOMAIN + "/assets/www/index.html"
        )
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("AndroidBridge")
        super.onDestroy()
    }

    // ---------------------------------------------------------------- helpers
    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    private fun safe(name: String): String = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file" }

    private fun openExternal(u: Uri) {
        try {
            val intent = if (u.scheme == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
            else Intent(Intent.ACTION_VIEW, u)
            startActivity(intent)
        } catch (e: Exception) {
            toast("यह लिंक खोल नहीं सका / Cannot open link")
        }
    }

    private fun whatsappPackage(): String? {
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                packageManager.getPackageInfo(p, 0)
                return p
            } catch (e: Exception) { /* not installed */ }
        }
        return null
    }

    /**
     * Writes [bytes] through MediaStore (no permission needed on Android 10+).
     * Images go to Pictures/FeeSarthi (visible in Gallery), everything else to Downloads/FeeSarthi.
     * Returns the content:// Uri of the saved file.
     */
    private fun saveToStore(name: String, mime: String, bytes: ByteArray): Uri {
        val isImage = mime.startsWith("image/")
        val collection = if (isImage) MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val folder = (if (isImage) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_DOWNLOADS) + "/FeeSarthi"
        val clean = safe(name)

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, clean)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(collection, values) ?: throw IllegalStateException("insert failed")
        try {
            val out = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("cannot open file")
            out.use { it.write(bytes) }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
        toast("सेव हो गया ✓  " + (if (isImage) "Gallery / Pictures/FeeSarthi/" else "Downloads/FeeSarthi/") + clean)
        return uri
    }

    /** Copies bytes to cache/shared and returns a FileProvider Uri (works for any receiving app). */
    private fun cacheUri(name: String, bytes: ByteArray): Uri {
        val dir = File(cacheDir, "shared").apply { mkdirs() }
        dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 24L * 3600 * 1000) it.delete() }
        val f = File(dir, safe(name))
        f.writeBytes(bytes)
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
    }

    /** Opens the Android Share Sheet. If [phone] is given and WhatsApp exists, tries that chat first. */
    private fun shareUri(uri: Uri, mime: String, text: String, phone: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            if (text.isNotEmpty()) putExtra(Intent.EXTRA_TEXT, text)
            clipData = ClipData.newRawUri("file", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val wa = whatsappPackage()
        try {
            if (phone.isNotEmpty() && wa != null) {
                send.setPackage(wa)
                send.putExtra("jid", phone.filter { it.isDigit() } + "@s.whatsapp.net")
                startActivity(send)
            } else {
                startActivity(Intent.createChooser(send, "भेजें / Share"))
            }
        } catch (e: Exception) {
            try {
                send.setPackage(null)
                send.removeExtra("jid")
                startActivity(Intent.createChooser(send, "भेजें / Share"))
            } catch (e2: Exception) {
                toast("Share नहीं हो सका / Cannot share")
            }
        }
    }

    private fun printPdfBytes(jobName: String, bytes: ByteArray) {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?, callback: LayoutResultCallback, extras: Bundle?
            ) {
                if (cancellationSignal != null && cancellationSignal.isCanceled) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(jobName + ".pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?, destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?, callback: WriteResultCallback
            ) {
                try {
                    ParcelFileDescriptor.AutoCloseOutputStream(destination).use { it.write(bytes) }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                }
            }
        }
        val attrs = PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
        pm.print(jobName, adapter, attrs)
    }

    // ---------------------------------------------------------------- JS bridge
    inner class Bridge {

        @JavascriptInterface
        fun isNative(): Boolean = true

        @JavascriptInterface
        fun bridgeVersion(): Int = 2

        /** Save a file: images -> Pictures/FeeSarthi (Gallery), others -> Downloads/FeeSarthi. */
        @JavascriptInterface
        fun saveFile(name: String, mime: String, b64: String): Boolean {
            return try {
                saveToStore(name, mime, Base64.decode(b64, Base64.DEFAULT))
                true
            } catch (e: Exception) {
                toast("सेव नहीं हो सका: " + e.message)
                false
            }
        }

        /** Save, then show a native dialog: Share (share sheet) / Open / OK. Used for the receipt PDF. */
        @JavascriptInterface
        fun saveAndOffer(name: String, mime: String, b64: String) {
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val saved = saveToStore(name, mime, bytes)
                val cached = cacheUri(name, bytes)
                runOnUiThread {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("सेव हो गया ✓")
                        .setMessage(safe(name) + "\nDownloads/FeeSarthi")
                        .setPositiveButton("WhatsApp / Share") { _, _ -> shareUri(cached, mime, "", "") }
                        .setNeutralButton("खोलें / Open") { _, _ ->
                            try {
                                startActivity(Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(saved, mime)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                })
                            } catch (e: Exception) {
                                toast("इस फाइल को खोलने वाला ऐप नहीं मिला")
                            }
                        }
                        .setNegativeButton("ठीक है / OK", null)
                        .show()
                }
            } catch (e: Exception) {
                toast("सेव नहीं हो सका: " + e.message)
            }
        }

        /** Share a file. If [phone] is given and WhatsApp is installed, tries to open that chat directly. */
        @JavascriptInterface
        fun shareFile(name: String, mime: String, b64: String, text: String, phone: String) {
            try {
                val uri = cacheUri(name, Base64.decode(b64, Base64.DEFAULT))
                runOnUiThread { shareUri(uri, mime, text, phone) }
            } catch (e: Exception) {
                toast("Share नहीं हो सका: " + e.message)
            }
        }

        @JavascriptInterface
        fun copyText(t: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("FeeSarthi", t))
                toast("कॉपी हो गया ✓")
            }
        }

        /** Print a generated PDF (receipt) – Android print screen -> printer or "Save as PDF". */
        @JavascriptInterface
        fun printPdf(jobName: String, b64: String) {
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                runOnUiThread {
                    try {
                        printPdfBytes(safe(jobName), bytes)
                    } catch (e: Exception) {
                        toast("Print नहीं हो सका: " + e.message)
                    }
                }
            } catch (e: Exception) {
                toast("Print नहीं हो सका: " + e.message)
            }
        }

        /** Prints the current WebView page (class sheets / reports). */
        @JavascriptInterface
        fun printPage(title: String, landscape: Boolean) {
            runOnUiThread {
                try {
                    val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val size = if (landscape) PrintAttributes.MediaSize.ISO_A4.asLandscape()
                    else PrintAttributes.MediaSize.ISO_A4
                    val attrs = PrintAttributes.Builder().setMediaSize(size).build()
                    val job = safe(title)
                    pm.print(job, web.createPrintDocumentAdapter(job), attrs)
                } catch (e: Exception) {
                    toast("Print नहीं हो सका: " + e.message)
                }
            }
        }

        /** Opens WhatsApp directly on the chat of [phone] (country code + number) with [text] pre-filled. */
        @JavascriptInterface
        fun openWhatsApp(phone: String, text: String) {
            runOnUiThread {
                val digits = phone.filter { it.isDigit() }
                val uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(text))
                val wa = whatsappPackage()
                try {
                    val i = Intent(Intent.ACTION_VIEW, uri)
                    if (wa != null) i.setPackage(wa)
                    startActivity(i)
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (e2: Exception) {
                        toast("WhatsApp नहीं खुला – क्या WhatsApp इंस्टॉल है?")
                    }
                }
            }
        }

        @JavascriptInterface
        fun openUrl(u: String) {
            runOnUiThread { openExternal(Uri.parse(u)) }
        }
    }
}
