# SEIA AI - Private Android starter project

**Creator credit:** By Ishan Ahmed Ansari

This is an Android Studio source project for a private-use starter app. It wraps an offline HTML/CSS/JavaScript interface in an Android WebView.

## Important limits
- This ZIP is **source code, not a compiled APK**.
- Chat responses are demo text, not a live AI model.
- Image and video generation are not connected to any generation service.
- File selection is local only; the app does not upload or analyze selected files.
- Before connecting a real AI API, use a secure backend rather than embedding a private API key in the app.

## Build an APK
1. Install Android Studio on a computer and open this folder (`SEIA AI`).
2. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
3. Connect an Android phone with USB debugging enabled, or use an emulator.
4. Use **Build > Build APK(s)**. Android Studio will show the output location after a successful build.
5. Test the APK on your own device before sharing it. Only install APKs from sources you trust.

## Project details
- App ID: `com.seia.ai`
- Minimum Android version: Android 6.0 (API 23)
- Target SDK: 35
- Version: 1.0
