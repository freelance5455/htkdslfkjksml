
import { createAHMADAiChat } from "./ai.js";
import { generateImageFromText } from "./image-ai.js";

// عناصر واجهة صناعة المحتوى
const creatorSection = document.getElementById("contentCreatorSection");
const contentEditorSection = document.getElementById("contentEditorSection");
const contentType = document.getElementById("contentType");
const contentTopic = document.getElementById("contentTopic");
const contentTone = document.getElementById("contentTone");

const generateBtn = document.getElementById("generateContentBtn");
const statusBox = document.getElementById("contentCreatorStatus");
const resultBox = document.getElementById("contentCreatorResult");
const outputBox = document.getElementById("contentCreatorOutput");
const copyBtn = document.getElementById("copyContentBtn");

// أسماء أنواع المحتوى
const contentTypeNames = {
  social: "منشور فيسبوك أو إنستغرام",
  ideas: "أفكار محتوى",
  video: "سيناريو فيديو أو يوتيوب أو TikTok",
  titles: "عناوين وأوصاف احترافية",
  marketing: "نص إعلاني وتسويقي"
};

// أسماء أساليب الكتابة
const contentToneNames = {
  professional: "احترافي",
  friendly: "ودّي وجذاب",
  marketing: "تسويقي ومقنع",
  creative: "إبداعي ومميز"
};

// إنشاء المحتوى
generateBtn?.addEventListener("click", async () => {
  const topic = contentTopic?.value.trim();

  if (!topic) {
    statusBox.hidden = false;
    statusBox.textContent = "يرجى كتابة موضوع المحتوى أولاً.";
    return;
  }

  const selectedType = contentTypeNames[contentType.value];
  const selectedTone = contentToneNames[contentTone.value];

  if (!selectedType || !selectedTone) {
    statusBox.hidden = false;
    statusBox.textContent = "يرجى اختيار نوع المحتوى وأسلوب الكتابة.";
    return;
  }

  generateBtn.disabled = true;
  generateBtn.textContent = "⏳ جارٍ إنشاء المحتوى...";

  statusBox.hidden = false;
  statusBox.textContent = "يعمل الذكاء الاصطناعي على إنشاء المحتوى...";
  resultBox.hidden = true;

  try {
    const creatorChat = createAHMADAiChat();

    const prompt = `
أنت خبير محترف في صناعة المحتوى باللغة العربية.

نوع المحتوى المطلوب: ${selectedType}

موضوع المحتوى:
${topic}

أسلوب الكتابة:
${selectedTone}

المطلوب:
- أنشئ محتوى احترافياً ومميزاً.
- اجعل النص مناسباً لنوع المحتوى المطلوب.
- استخدم لغة عربية سليمة وجذابة.
- تجنب الحشو والتكرار.
- قدم النتيجة النهائية مباشرة دون مقدمات طويلة.
- لا تخترع معلومات أو أرقاماً غير موجودة في الموضوع.
`;

    const result = await creatorChat.send(prompt);

    if (!result || !result.trim()) {
      throw new Error("لم يتم إنشاء محتوى.");
    }

    outputBox.textContent = result;
    resultBox.hidden = false;

    statusBox.textContent = "تم إنشاء المحتوى بنجاح.";

  } catch (error) {
    console.error("Content Creator Error:", error);

    statusBox.textContent =
      "تعذر إنشاء المحتوى. تحقق من الاتصال بالإنترنت وحاول مجدداً.";

  } finally {
    generateBtn.disabled = false;
    generateBtn.textContent = "✨ إنشاء المحتوى";
  }
});

// نسخ المحتوى
copyBtn?.addEventListener("click", async () => {
  const text = outputBox?.textContent || "";

  if (!text.trim()) return;

  try {
    await navigator.clipboard.writeText(text);
    copyBtn.textContent = "✓ تم النسخ";

  } catch (error) {
    const temporaryInput = document.createElement("textarea");

    temporaryInput.value = text;
    temporaryInput.style.position = "fixed";
    temporaryInput.style.opacity = "0";

    document.body.appendChild(temporaryInput);
    temporaryInput.select();

    const copied = document.execCommand("copy");
    temporaryInput.remove();

    copyBtn.textContent = copied ? "✓ تم النسخ" : "تعذر النسخ";
  }

  setTimeout(() => {
    copyBtn.textContent = "نسخ المحتوى";
  }, 2000);
});



/* ==========================================
   AHMAD AI - SMART CONTENT EDITOR
========================================== */

// عناصر محرر المحتوى
const editorInput = document.getElementById("contentEditorInput");
const editAction = document.getElementById("contentEditAction");
const editBtn = document.getElementById("editContentBtn");
const editorStatus = document.getElementById("contentEditorStatus");

const editorResult = document.getElementById("contentEditorResult");
const editorOutput = document.getElementById("contentEditorOutput");
const copyEditedBtn = document.getElementById("copyEditedContentBtn");

// تعليمات أنواع التعديل
const contentEditInstructions = {
  rewrite: "أعد صياغة النص بأسلوب مختلف مع الحفاظ على المعنى والمعلومات.",
  correct: "صحح الأخطاء الإملائية والنحوية وعلامات الترقيم دون تغيير المعنى.",
  shorten: "اختصر النص مع الحفاظ على أهم الأفكار والمعلومات.",
  expand: "وسّع النص وأضف تفاصيل مفيدة دون اختراع معلومات أو حقائق.",
  professional: "أعد كتابة النص بأسلوب احترافي ومنظم.",
  marketing: "حوّل النص إلى أسلوب تسويقي جذاب ومقنع دون ادعاءات غير مثبتة."
};

// تحسين المحتوى
editBtn?.addEventListener("click", async () => {
  const originalText = editorInput?.value.trim();
  const selectedAction = contentEditInstructions[editAction?.value];

  if (!originalText) {
    editorStatus.hidden = false;
    editorStatus.textContent = "يرجى كتابة النص المراد تعديله أولاً.";
    return;
  }

  if (!selectedAction) {
    editorStatus.hidden = false;
    editorStatus.textContent = "يرجى اختيار نوع التعديل.";
    return;
  }

  editBtn.disabled = true;
  editBtn.textContent = "⏳ جارٍ تحسين المحتوى...";

  editorStatus.hidden = false;
  editorStatus.textContent = "يعمل الذكاء الاصطناعي على تحسين النص...";
  editorResult.hidden = true;

  try {
    const editorChat = createAHMADAiChat();

    const prompt = `
أنت محرر محتوى عربي محترف.

المهمة:
${selectedAction}

قواعد العمل:
- حافظ على المعنى الأساسي للنص.
- لا تخترع معلومات أو أرقاماً.
- استخدم لغة عربية سليمة.
- أعد النتيجة النهائية مباشرة دون مقدمات طويلة.

النص المطلوب تعديله:
${originalText}
`;

    const result = await editorChat.send(prompt);

    if (!result || !result.trim()) {
      throw new Error("لم يتم الحصول على نتيجة.");
    }

    editorOutput.textContent = result;
    editorResult.hidden = false;

    editorStatus.textContent = "تم تحسين المحتوى بنجاح.";

  } catch (error) {
    console.error("Content Editor Error:", error);

    editorStatus.textContent =
      "تعذر تحسين المحتوى. تحقق من الاتصال بالإنترنت وحاول مجدداً.";

  } finally {
    editBtn.disabled = false;
    editBtn.textContent = "✨ تحسين المحتوى بالذكاء الاصطناعي";
  }
});

// نسخ النص المحسّن
copyEditedBtn?.addEventListener("click", async () => {
  const text = editorOutput?.textContent || "";

  if (!text.trim()) return;

  try {
    await navigator.clipboard.writeText(text);
    copyEditedBtn.textContent = "✓ تم النسخ";

  } catch (error) {
    const temporaryInput = document.createElement("textarea");

    temporaryInput.value = text;
    temporaryInput.style.position = "fixed";
    temporaryInput.style.opacity = "0";

    document.body.appendChild(temporaryInput);
    temporaryInput.select();

    const copied = document.execCommand("copy");
    temporaryInput.remove();

    copyEditedBtn.textContent = copied ? "✓ تم النسخ" : "تعذر النسخ";
  }

  setTimeout(() => {
    copyEditedBtn.textContent = "نسخ النص المحسّن";
  }, 2000);
});

/* فتح وإغلاق محرر المحتوى الذكي */
const openContentEditorBtn = document.getElementById("openContentEditorBtn");

openContentEditorBtn?.addEventListener("click", () => {
  const isHidden = contentEditorSection.hidden;

  contentEditorSection.hidden = !isHidden;

  openContentEditorBtn.textContent = isHidden
    ? "✕ إغلاق محرّر المحتوى الذكي"
    : "✨ فتح محرّر المحتوى الذكي";
});

/* ==========================================
   AHMAD AI - COMPLETE CONTENT PACKAGE
========================================== */

const packagePlatform = document.getElementById("packagePlatform");
const packageGoal = document.getElementById("packageGoal");
const generatePackageBtn = document.getElementById("generatePackageBtn");
const packageStatus = document.getElementById("packageStatus");
const packageResult = document.getElementById("packageResult");
const packageOutput = document.getElementById("packageOutput");
const copyPackageBtn = document.getElementById("copyPackageBtn");
// إنشاء حزمة المحتوى
generatePackageBtn?.addEventListener("click", async () => {
  const topic = document.getElementById("packageTopic")?.value.trim();
  const platform = packagePlatform?.value;
  const goal = packageGoal?.value;

  if (!topic) {
    packageStatus.hidden = false;
    packageStatus.textContent = "يرجى كتابة موضوع المحتوى أولاً.";
    return;
  }

  generatePackageBtn.disabled = true;
  generatePackageBtn.textContent = "⏳ جارٍ إعداد الحزمة...";

  packageStatus.hidden = false;
  packageStatus.textContent = "يعمل الذكاء الاصطناعي على إعداد الحزمة...";
  packageResult.hidden = true;

  try {
    const packageChat = createAHMADAiChat();

    const prompt = `
أنت خبير محترف في صناعة المحتوى الرقمي والتسويق.

أنشئ حزمة محتوى باللغة العربية وفق المعلومات التالية:

الموضوع:
${topic}

المنصة:
${platform}

الهدف:
${goal}

أريد خمسة أجزاء:

1. عنوان جذاب.
2. افتتاحية تشد الانتباه.
3. المحتوى الرئيسي.
4. دعوة للتفاعل.
5. نسخة بديلة مختلفة.

قواعد مهمة:
- اكتب بلغة عربية سليمة وطبيعية.
- اجعل المحتوى مناسباً للمنصة والهدف.
- تجنب الحشو والتكرار.
- لا تخترع معلومات أو إحصائيات.
- لا تضف أي مقدمات أو شروحات خارج النتائج.

أعد النتيجة بصيغة JSON صحيحة فقط، وفق هذا النموذج:

{
  "title": "العنوان الجذاب",
  "hook": "الافتتاحية",
  "main": "المحتوى الرئيسي",
  "cta": "دعوة التفاعل",
  "alternative": "النسخة البديلة"
}

لا تستخدم علامات Markdown ولا تضع JSON داخل كتل أكواد.
`;

    const result = await packageChat.send(prompt);

    if (!result || !result.trim()) {
      throw new Error("لم يتم إنشاء الحزمة.");
    }

    // تنظيف النتيجة وتحويلها إلى JSON
    const cleanResult = result
      .replace(/```json/gi, "")
      .replace(/```/g, "")
      .trim();

    const start = cleanResult.indexOf("{");
    const end = cleanResult.lastIndexOf("}");

    if (start === -1 || end === -1) {
      throw new Error("صيغة النتيجة غير صحيحة.");
    }

    const data = JSON.parse(cleanResult.slice(start, end + 1));

    const fields = {
      packageTitle: data.title,
      packageHook: data.hook,
      packageMain: data.main,
      packageCTA: data.cta,
      packageAlternative: data.alternative
    };

    // عرض كل نتيجة داخل بطاقتها
    for (const [id, value] of Object.entries(fields)) {
      const element = document.getElementById(id);

      if (!element || typeof value !== "string" || !value.trim()) {
        throw new Error("بعض أجزاء الحزمة غير مكتملة.");
      }

      element.textContent = value.trim();
    }

    packageResult.hidden = false;
    packageStatus.textContent = "✓ تم إنشاء حزمة المحتوى بنجاح.";

  } catch (error) {
    console.error("Content Package Error:", error);

    packageStatus.textContent =
      "تعذر إنشاء الحزمة. حاول مجدداً.";

  } finally {
    generatePackageBtn.disabled = false;
    generatePackageBtn.textContent = "✨ إنشاء حزمة المحتوى";
  }
});

// إنشاء صورة تعبّر عن حزمة المحتوى كاملة
const generatePackageImageBtn = document.getElementById("generatePackageImageBtn");

generatePackageImageBtn?.addEventListener("click", async () => {
  const imageSection = document.getElementById("packageImageSection");
  const imageElement = document.getElementById("packageGeneratedImage");
  const downloadLink = document.getElementById("downloadPackageImage");

  const contentParts = [
    document.getElementById("packageTitle")?.textContent,
    document.getElementById("packageHook")?.textContent,
    document.getElementById("packageMain")?.textContent,
    document.getElementById("packageCTA")?.textContent,
    document.getElementById("packageAlternative")?.textContent
  ];

  const fullContent = contentParts
    .map((text, index) => {
      const labels = [
        "العنوان",
        "الافتتاحية",
        "المحتوى الرئيسي",
        "دعوة التفاعل",
        "النسخة البديلة"
      ];

      return `${labels[index]}: ${text?.trim() || ""}`;
    })
    .join("\n\n");

  if (contentParts.some(text => !text?.trim())) {
    packageStatus.hidden = false;
    packageStatus.textContent = "أنشئ حزمة المحتوى كاملة أولاً.";
    return;
  }

  generatePackageImageBtn.disabled = true;
  generatePackageImageBtn.textContent = "⏳ جارٍ إنشاء الصورة...";

  packageStatus.hidden = false;
  packageStatus.textContent = "يجري تحليل النصوص الخمسة وتجهيز الصورة...";

  try {
    const image = await generateImageFromText(fullContent);

    imageElement.src = image;
    downloadLink.href = image;
    imageSection.hidden = false;

    packageStatus.textContent = "✓ تم إنشاء صورة الحزمة بنجاح.";

  } catch (error) {
    console.error("Package Image Error:", error);
    packageStatus.textContent =
      "تعذر إنشاء الصورة: " + error.message;

  } finally {
    generatePackageImageBtn.disabled = false;
    generatePackageImageBtn.textContent = "🎨 إنشاء صورة للمحتوى";
  }
});
// فتح معاينة الصورة بالحجم الكامل
const packageImage = document.getElementById("packageGeneratedImage");
const packageImageModal = document.getElementById("packageImageModal");
const packageModalImage = document.getElementById("packageModalImage");
const closePackageImageModal = document.getElementById("closePackageImageModal");

packageImage?.addEventListener("click", () => {
  packageModalImage.src = packageImage.src;
  packageImageModal.hidden = false;
});

closePackageImageModal?.addEventListener("click", () => {
  packageImageModal.hidden = true;
  packageModalImage.src = "";
});

packageImageModal?.addEventListener("click", (event) => {
  if (event.target === packageImageModal) {
    packageImageModal.hidden = true;
    packageModalImage.src = "";
  }
});
// وظيفة نسخ النصوص
async function copyPackageText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    const temporaryInput = document.createElement("textarea");

    temporaryInput.value = text;
    temporaryInput.style.position = "fixed";
    temporaryInput.style.opacity = "0";

    document.body.appendChild(temporaryInput);
    temporaryInput.select();

    const copied = document.execCommand("copy");
    temporaryInput.remove();

    return copied;
  }
}


// نسخ كل بطاقة بشكل منفصل
document.querySelectorAll(".package-copy-btn").forEach(button => {
  button.addEventListener("click", async () => {
    const targetId = button.dataset.copy;
    const target = document.getElementById(targetId);

    if (!target || !target.textContent.trim()) return;

    const originalText = button.textContent;
    const copied = await copyPackageText(target.textContent.trim());

    button.textContent = copied ? "✓ تم النسخ" : "تعذر النسخ";

    setTimeout(() => {
      button.textContent = originalText;
    }, 2000);
  });
});


// نسخ حزمة المحتوى كاملة
copyPackageBtn?.addEventListener("click", async () => {
  const sections = [
    ["العنوان الجذاب", "packageTitle"],
    ["الافتتاحية", "packageHook"],
    ["المحتوى الرئيسي", "packageMain"],
    ["دعوة للتفاعل", "packageCTA"],
    ["النسخة البديلة", "packageAlternative"]
  ];

  const text = sections.map(([title, id]) => {
    const element = document.getElementById(id);
    return `${title}:\n${element?.textContent || ""}`;
  }).join("\n\n");

  if (!text.trim()) return;

  const copied = await copyPackageText(text);

  copyPackageBtn.textContent = copied
    ? "✓ تم نسخ الحزمة"
    : "تعذر النسخ";

  setTimeout(() => {
    copyPackageBtn.textContent = "نسخ حزمة المحتوى كاملة";
  }, 2000);
});

/* فتح وإغلاق استوديو المحتوى المتكامل */

const openContentPackageBtn = document.getElementById("openContentPackageBtn");
const contentPackageSection = document.getElementById("contentPackageSection");

openContentPackageBtn?.addEventListener("click", () => {
  const isHidden = contentPackageSection.hidden;

  contentPackageSection.hidden = !isHidden;

  openContentPackageBtn.textContent = isHidden
    ? "✕ إغلاق استوديو المحتوى المتكامل"
    : "✨ فتح استوديو المحتوى المتكامل";
});

// ===== تحرير نتائج حزمة المحتوى =====

packageResult?.addEventListener("click", (event) => {
  const editButton = event.target.closest(".package-edit-btn");

  if (!editButton) return;

  const card = editButton.closest(".package-card");
  const content = card?.querySelector(".package-card-content");

  if (!content) return;

  const originalText = content.textContent;

  const editor = document.createElement("textarea");
  editor.value = originalText;
  editor.rows = Math.max(4, originalText.split("\n").length);
  editor.className = "package-edit-area";
  editor.dir = "rtl";

  content.replaceWith(editor);

  editButton.textContent = "حفظ التعديل";
  editButton.classList.add("saving");

  const cancelButton = document.createElement("button");
  cancelButton.type = "button";
  cancelButton.textContent = "إلغاء";
  cancelButton.className = "package-cancel-btn";

  editButton.after(cancelButton);

  editButton.onclick = (event) => {
  event.stopPropagation();
    const updatedText = editor.value.trim();

    if (!updatedText) {
      editor.focus();
      return;
    }

    content.textContent = updatedText;
    editor.replaceWith(content);

    editButton.textContent = "تعديل النص";
    editButton.classList.remove("saving");
    editButton.onclick = null;

    cancelButton.remove();
  };

  cancelButton.onclick = (event) => {
  event.stopPropagation();
    editor.replaceWith(content);
    editButton.textContent = "تعديل النص";
    editButton.classList.remove("saving");
    editButton.onclick = null;
    cancelButton.remove();
  };
});



/* ==========================================
   AHMAD AI - AUTO SAVE CONTENT PACKAGE
========================================== */

const PACKAGE_STORAGE_KEY = "ahmadContentPackage";

const packageTopicInput = document.getElementById("packageTopic");

const packageFieldIds = [
  "packageTitle",
  "packageHook",
  "packageMain",
  "packageCTA",
  "packageAlternative"
];

// جمع بيانات الحزمة
function getPackageData() {
  return {
    topic: packageTopicInput?.value || "",
    platform: packagePlatform?.value || "",
    goal: packageGoal?.value || "",

    fields: Object.fromEntries(
      packageFieldIds.map(id => [
        id,
        document.getElementById(id)?.textContent || ""
      ])
    )
  };
}

// حفظ الحزمة
function savePackageAutomatically() {
  try {
    const data = getPackageData();

    const hasContent = Object.values(data.fields)
      .some(value => value.trim());

    if (!hasContent) return;

    localStorage.setItem(
      PACKAGE_STORAGE_KEY,
      JSON.stringify(data)
    );

  } catch (error) {
    console.error("Package Auto Save Error:", error);
  }
}

// استعادة الحزمة المحفوظة
function restorePackageAutomatically() {
  try {
    const saved = localStorage.getItem(PACKAGE_STORAGE_KEY);

    if (!saved) return;

    const data = JSON.parse(saved);

    if (packageTopicInput) {
      packageTopicInput.value = data.topic || "";
    }

    if (packagePlatform) {
      packagePlatform.value = data.platform || "";
    }

    if (packageGoal) {
      packageGoal.value = data.goal || "";
    }

    packageFieldIds.forEach(id => {
      const element = document.getElementById(id);

      if (element) {
        element.textContent = data.fields?.[id] || "";
      }
    });

    const hasContent = packageFieldIds.some(id =>
      data.fields?.[id]?.trim()
    );

    if (hasContent) {
      packageResult.hidden = false;
      packageStatus.hidden = false;
      packageStatus.textContent = "✓ تمت استعادة آخر حزمة محفوظة.";
    }

  } catch (error) {
    console.error("Package Restore Error:", error);
  }
}

// مراقبة تعديلات النصوص
packageResult?.addEventListener("input", () => {
  savePackageAutomatically();
});

// حفظ عند تغيير بيانات الحزمة
packageTopicInput?.addEventListener("input", savePackageAutomatically);
packagePlatform?.addEventListener("change", savePackageAutomatically);
packageGoal?.addEventListener("change", savePackageAutomatically);

// مراقبة تغييرات البطاقات بعد إنشاء المحتوى أو حفظ التعديلات
if (packageResult) {
  const packageObserver = new MutationObserver(() => {
    savePackageAutomatically();
  });

  packageObserver.observe(packageResult, {
    subtree: true,
    childList: true,
    characterData: true
  });
}

// استعادة الحزمة عند فتح التطبيق
restorePackageAutomatically();