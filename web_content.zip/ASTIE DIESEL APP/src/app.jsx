import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContent';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import { SessionProvider } from '@/lib/session';
import { CartProvider } from '@/lib/cart';
import AppShell from '@/components/AppShell';
import RoleGuard from '@/components/RoleGuard';
import Entry from '@/pages/Entry';
import CustomerRegister from '@/pages/CustomerRegister';
import Home from '@/pages/Home';
import ProductDetail from '@/pages/ProductDetail';
import Cart from '@/pages/Cart';
import Chat from '@/pages/Chat';
import MyQuotes from '@/pages/MyQuotes';
import Profile from '@/pages/Profile';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminCategories from '@/pages/admin/AdminCategories';
import AdminProducts from '@/pages/admin/AdminProducts';
import AdminSellers from '@/pages/admin/AdminSellers';
import AdminCustomers from '@/pages/admin/AdminCustomers';
import AdminQuotes from '@/pages/admin/AdminQuotes';
import AdminSettings from '@/pages/admin/AdminSettings';
import SellerDashboard from '@/pages/seller/SellerDashboard';
import SellerQuotes from '@/pages/seller/SellerQuotes';
import SellerHistory from '@/pages/seller/SellerHistory';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <CartProvider>
        <Routes>
          <Route path="/" element={<Entry />} />
          <Route path="/register" element={<CustomerRegister />} />

          {/* Customer routes */}
          <Route element={<RoleGuard roles={["customer"]} />}>
            <Route element={<AppShell />}>
              <Route path="/catalog" element={<Home />} />
              <Route path="/product/:id" element={<ProductDetail />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/my-quotes" element={<MyQuotes />} />
              <Route path="/profile" element={<Profile />} />
            </Route>
          </Route>
          <Route path="/chat/:id" element={<Chat />} />

          {/* Admin routes */}
          <Route element={<RoleGuard roles={["admin"]} />}>
            <Route element={<AppShell />}>
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/categories" element={<AdminCategories />} />
              <Route path="/admin/products" element={<AdminProducts />} />
              <Route path="/admin/sellers" element={<AdminSellers />} />
              <Route path="/admin/customers" element={<AdminCustomers />} />
              <Route path="/admin/quotes" element={<AdminQuotes />} />
              <Route path="/admin/settings" element={<AdminSettings />} />
            </Route>
          </Route>
          <Route path="/admin/chat/:id" element={<Chat />} />

          {/* Seller routes */}
          <Route element={<RoleGuard roles={["seller"]} />}>
            <Route element={<AppShell />}>
              <Route path="/seller" element={<SellerDashboard />} />
              <Route path="/seller/quotes" element={<SellerQuotes />} />
              <Route path="/seller/history" element={<SellerHistory />} />
            </Route>
          </Route>
          <Route path="/seller/chat/:id" element={<Chat />} />

          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </CartProvider>
  );
};


function App() {
  return (
    <SessionProvider>
      <AuthProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <ScrollToTop />
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </QueryClientProvider>
      </AuthProvider>
    </SessionProvider>
  )
}

export default App
