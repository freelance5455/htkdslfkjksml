import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getQuotes } from "@/lib/quoteService";
import { ClipboardList, Clock, CheckCircle2, MessageSquare } from "lucide-react";

export default function SellerDashboard() {
  const [quotes, setQuotes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const q = await getQuotes();
      setQuotes(q);
      setLoading(false);
    })();
  }, []);

  if (loading) return <div className="p-10 flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-amber-500 rounded-full animate-spin" /></div>;

  const pending = quotes.filter((q) => q.status === "pending").length;
  const answered = quotes.filter((q) => q.status === "answered").length;
  const completed = quotes.filter((q) => q.status === "completed").length;

  return (
    <div className="p-6 lg:p-8">
      <h1 className="font-display text-2xl font-semibold mb-1">Panel de Vendedor</h1>
      <p className="text-stone-500 text-sm mb-6">Gestiona las cotizaciones de los clientes</p>
      <div className="grid grid-cols-3 gap-4">
        <Link to="/seller/quotes" className="bg-white rounded-2xl border border-stone-200 p-5 hover:shadow-sm transition-shadow">
          <Clock className="w-5 h-5 text-amber-600 mb-3" />
          <div className="text-3xl font-semibold">{pending}</div>
          <div className="text-xs text-stone-500 mt-1">Pendientes</div>
        </Link>
        <Link to="/seller/quotes" className="bg-white rounded-2xl border border-stone-200 p-5 hover:shadow-sm transition-shadow">
          <MessageSquare className="w-5 h-5 text-blue-600 mb-3" />
          <div className="text-3xl font-semibold">{answered}</div>
          <div className="text-xs text-stone-500 mt-1">Respondidas</div>
        </Link>
        <Link to="/seller/history" className="bg-white rounded-2xl border border-stone-200 p-5 hover:shadow-sm transition-shadow">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 mb-3" />
          <div className="text-3xl font-semibold">{completed}</div>
          <div className="text-xs text-stone-500 mt-1">Completadas</div>
        </Link>
      </div>
      <div className="mt-6">
        <Link to="/seller/quotes" className="inline-flex items-center gap-2 bg-stone-900 text-white rounded-xl px-4 py-3 hover:bg-stone-800">
          <ClipboardList className="w-4 h-4" /> Ver cotizaciones
        </Link>
      </div>
    </div>
  );
}