import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useSession } from "@/lib/session";
import { getQuotes } from "@/lib/quoteService";
import { cn } from "@/lib/utils";
import { MessageSquare, ChevronRight } from "lucide-react";

const statusLabels = { pending: "Pendiente", answered: "Respondida", completed: "Completada", cancelled: "Cancelada" };
const statusColors = { pending: "bg-amber-100 text-amber-700", answered: "bg-blue-100 text-blue-700", completed: "bg-emerald-100 text-emerald-700", cancelled: "bg-stone-200 text-stone-600" };

export default function MyQuotes() {
  const { session } = useSession();
  const navigate = useNavigate();
  const [quotes, setQuotes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session || session.role !== "customer") { navigate("/register"); return; }
    (async () => {
      try {
        const all = await getQuotes({ customer_id: session.id });
        setQuotes(all);
      } finally {
        setLoading(false);
      }
    })();
  }, [session, navigate]);

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-amber-500 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="font-display text-2xl font-semibold mb-6">Mis cotizaciones</h1>
      {quotes.length === 0 ? (
        <div className="text-center py-20 text-stone-400">
          <MessageSquare className="w-10 h-10 mx-auto mb-3 text-stone-300" />
          Aún no tienes cotizaciones.
        </div>
      ) : (
        <div className="space-y-3">
          {quotes.map((q) => (
            <Link key={q.id} to={`/chat/${q.id}`} className="block bg-white rounded-xl border border-stone-200 p-4 hover:shadow-sm transition-shadow">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-medium text-sm">{q.items?.length || 0} producto(s)</div>
                  <div className="text-xs text-stone-500 mt-1">{new Date(q.created_date).toLocaleDateString()} · {new Date(q.created_date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
                  {q.agreed_total && <div className="text-sm text-amber-700 font-medium mt-1">Total: ${q.agreed_total.toLocaleString()}</div>}
                </div>
                <div className="flex items-center gap-2">
                  <span className={cn("text-xs px-2.5 py-1 rounded-full font-medium", statusColors[q.status])}>{statusLabels[q.status]}</span>
                  <ChevronRight className="w-4 h-4 text-stone-400" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}