import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSession } from "@/lib/session";
import { createCustomer, findCustomerByPhone } from "@/lib/customerService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function CustomerRegister() {
  const { loginCustomer } = useSession();
  const navigate = useNavigate();
  const [form, setForm] = useState({ full_name: "", last_name: "", phone: "", email: "", address: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (!form.full_name || !form.last_name || !form.phone) {
      setError("Nombre, apellido y teléfono son obligatorios");
      return;
    }
    setLoading(true);
    try {
      let customer = await findCustomerByPhone(form.phone);
      if (!customer) customer = await createCustomer(form);
      loginCustomer(customer);
      navigate("/");
    } catch (err) {
      setError(err.message || "Error al registrar");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="font-display text-3xl font-semibold tracking-tight">ASTIE <span className="text-amber-600">DIESEL</span></div>
          <p className="text-stone-500 text-sm mt-2">Registro de cliente — sin contraseña</p>
        </div>
        <form onSubmit={submit} className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4 shadow-sm">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Nombre *</Label>
              <Input value={form.full_name} onChange={set("full_name")} className="mt-1" required />
            </div>
            <div>
              <Label>Apellido *</Label>
              <Input value={form.last_name} onChange={set("last_name")} className="mt-1" required />
            </div>
          </div>
          <div>
            <Label>Teléfono *</Label>
            <Input value={form.phone} onChange={set("phone")} className="mt-1" required />
          </div>
          <div>
            <Label>Email</Label>
            <Input type="email" value={form.email} onChange={set("email")} className="mt-1" />
          </div>
          <div>
            <Label>Dirección de entrega (opcional)</Label>
            <Input value={form.address} onChange={set("address")} className="mt-1" />
          </div>
          {error && <p className="text-red-600 text-sm">{error}</p>}
          <Button type="submit" disabled={loading} className="w-full bg-stone-900 hover:bg-stone-800">
            {loading ? "Guardando..." : "Entrar al catálogo"}
          </Button>
        </form>
        <button onClick={() => navigate("/")} className="block mx-auto mt-4 text-sm text-stone-500 hover:text-stone-900">
          ← Volver al inicio
        </button>
      </div>
    </div>
  );
}