import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getQuotes } from "@/lib/quoteService";
import { cn } from "@/lib/utils";
import { ChevronRight, MessageSquare } from "lucide-react";

const statusLabels = { pending: "Pendiente", answered: "Respondida", completed: "Completada", cancelled: "Cancelada" };
const statusColors = { pending: "bg-amber-100 text-amber-700", answered: "bg-blue-100 text-blue-700", completed: "bg-emerald-100 text-emerald-700", cancelled: "bg-stone-200 text-stone-600" };

export default function QuoteList({ title = "Cotizaciones", filterFn, basePath }) {
  const [quotes, setQuotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");

  useEffect(() => {
    (async () => {
      try {
        let all = await getQuotes();
        if (filterFn) all = all.filter(filterFn);
        setQuotes(all);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filtered = statusFilter === "all" ? quotes : quotes.filter((q) => q.status === statusFilter);

  if (loading) return <div className="p-10 flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-amber-500 rounded-full animate-spin" /></div>;

  return (
    <div className="p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-semibold">{title}</h1>
          <p className="text-stone-500 text-sm">{filtered.length} cotizaciones</p>
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {["all", "pending", "answered", "completed", "cancelled"].map((s) => (
            <button key={s} onClick={() => setStatusFilter(s)} className={cn("px-2.5 py-1 rounded-full text-xs border", statusFilter === s ? "bg-stone-900 text-white border-stone-900" : "bg-white border-stone-200 text-stone-600")}>
              {s === "all" ? "Todas" : statusLabels[s]}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        {filtered.map((q) => (
          <Link key={q.id} to={`${basePath}/${q.id}`} className="block bg-white rounded-xl border border-stone-200 p-4 hover:shadow-sm transition-shadow">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="font-medium text-sm">{q.customer_name}</div>
                <div className="text-xs text-stone-500 mt-0.5">{q.customer_phone}{q.items?.length ? ` · ${q.items.length} producto(s)` : ""}</div>
                <div className="text-xs text-stone-400 mt-0.5">{new Date(q.created_date).toLocaleString()}</div>
                {q.agreed_total && <div className="text-sm text-amber-700 font-medium mt-1">${q.agreed_total.toLocaleString()}</div>}
              </div>
              <div className="flex items-center gap-2">
                <span className={cn("text-xs px-2.5 py-1 rounded-full font-medium", statusColors[q.status])}>{statusLabels[q.status]}</span>
                <ChevronRight className="w-4 h-4 text-stone-400" />
              </div>
            </div>
          </Link>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-16 text-stone-400 text-sm">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 text-stone-300" />
            No hay cotizaciones.
          </div>
        )}
      </div>
    </div>
  );
}