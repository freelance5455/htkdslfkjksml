import React, { useState, useEffect } from "react";
import { getAppSettings, updateAppSettings, ensureAppSettings } from "@/lib/settingsService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, KeyRound, Save } from "lucide-react";

export default function AdminSettings() {
  const [settings, setSettings] = useState(null);
  const [adminPass, setAdminPass] = useState("");
  const [sellerPass, setSellerPass] = useState("");
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    (async () => {
      let s = await getAppSettings();
      if (!s) s = await ensureAppSettings();
      setSettings(s);
      setAdminPass(s.admin_password);
      setSellerPass(s.seller_password);
    })();
  }, []);

  const saveAdmin = async (e) => {
    e.preventDefault();
    if (!adminPass.trim()) return;
    setSaving(true);
    try {
      const u = await updateAppSettings(settings.id, { admin_password: adminPass });
      setSettings(u);
      setMsg("Contraseña de administrador actualizada");
      setTimeout(() => setMsg(""), 3000);
    } finally {
      setSaving(false);
    }
  };

  const saveSeller = async (e) => {
    e.preventDefault();
    if (!sellerPass.trim()) return;
    setSaving(true);
    try {
      const u = await updateAppSettings(settings.id, { seller_password: sellerPass });
      setSettings(u);
      setMsg("Contraseña de vendedores actualizada");
      setTimeout(() => setMsg(""), 3000);
    } finally {
      setSaving(false);
    }
  };

  if (!settings) return <div className="p-10 flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-amber-500 rounded-full animate-spin" /></div>;

  return (
    <div className="p-6 lg:p-8 max-w-xl">
      <h1 className="font-display text-2xl font-semibold mb-1">Configuración</h1>
      <p className="text-stone-500 text-sm mb-6">Contraseñas maestras y seguridad</p>

      {msg && <div className="mb-4 bg-emerald-50 text-emerald-700 text-sm rounded-lg px-4 py-2.5 border border-emerald-200">{msg}</div>}

      <form onSubmit={saveAdmin} className="bg-white rounded-2xl border border-stone-200 p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <Shield className="w-5 h-5 text-amber-600" />
          <h2 className="font-medium">Contraseña maestra ADMIN</h2>
        </div>
        <Label className="text-sm text-stone-500">Usada para acceder al panel de administrador</Label>
        <Input type="text" value={adminPass} onChange={(e) => setAdminPass(e.target.value)} className="mt-1 font-mono" />
        <Button type="submit" disabled={saving} className="mt-3"><Save className="w-4 h-4 mr-1" /> Guardar</Button>
      </form>

      <form onSubmit={saveSeller} className="bg-white rounded-2xl border border-stone-200 p-5">
        <div className="flex items-center gap-2 mb-3">
          <KeyRound className="w-5 h-5 text-amber-600" />
          <h2 className="font-medium">Contraseña maestra VENDEDORES</h2>
        </div>
        <Label className="text-sm text-stone-500">Compartida por todos los vendedores para acceder a su panel</Label>
        <Input type="text" value={sellerPass} onChange={(e) => setSellerPass(e.target.value)} className="mt-1 font-mono" />
        <Button type="submit" disabled={saving} className="mt-3"><Save className="w-4 h-4 mr-1" /> Guardar</Button>
      </form>
    </div>
  );
}