import React from "react";
import QuoteList from "./QuoteList";

export default function AdminQuotes() {
  return <QuoteList title="Cotizaciones" basePath="/admin/chat" />;
}