import React from "react";
import { Link, useLocation, useNavigate, Outlet } from "react-router-dom";
import { useSession } from "@/lib/session";
import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { ShoppingCart, LayoutDashboard, Package, Tags, Users, MessageSquare, Settings, LogOut, Boxes, ClipboardList, UserCog, Store } from "lucide-react";
import { cn } from "@/lib/utils";

const customerNav = [
  { label: "Catálogo", path: "/catalog", icon: Store },
  { label: "Mi Carrito", path: "/cart", icon: ShoppingCart },
  { label: "Mis Cotizaciones", path: "/my-quotes", icon: ClipboardList },
  { label: "Mi Perfil", path: "/profile", icon: UserCog },
];

const adminNav = [
  { label: "Dashboard", path: "/admin", icon: LayoutDashboard },
  { label: "Categorías", path: "/admin/categories", icon: Tags },
  { label: "Productos", path: "/admin/products", icon: Package },
  { label: "Vendedores", path: "/admin/sellers", icon: Users },
  { label: "Clientes", path: "/admin/customers", icon: UserCog },
  { label: "Cotizaciones", path: "/admin/quotes", icon: ClipboardList },
  { label: "Chat", path: "/admin/chat", icon: MessageSquare },
  { label: "Configuración", path: "/admin/settings", icon: Settings },
];

const sellerNav = [
  { label: "Panel", path: "/seller", icon: LayoutDashboard },
  { label: "Cotizaciones", path: "/seller/quotes", icon: ClipboardList },
  { label: "Chat", path: "/seller/chat", icon: MessageSquare },
  { label: "Mi Historial", path: "/seller/history", icon: MessageSquare },
];

export default function AppShell() {
  const { session, logout } = useSession();
  const { count } = useCart();
  const location = useLocation();
  const navigate = useNavigate();

  const role = session?.role || "customer";
  const nav = role === "admin" ? adminNav : role === "seller" ? sellerNav : customerNav;

  const isStaff = role === "admin" || role === "seller";

  return (
    <div className={`min-h-screen bg-stone-50 flex flex-col ${isStaff ? "md:flex-row" : ""}`}>
      {isStaff ? (
        <aside className="md:w-64 md:min-h-screen bg-stone-900 text-stone-100 flex md:flex-col items-stretch md:border-r border-stone-800">
          <div className="px-5 py-5 border-b border-stone-800 hidden md:block">
            <div className="font-display text-lg tracking-tight font-semibold">ASTIE DIESEL</div>
            <div className="text-[11px] uppercase tracking-widest text-amber-500/90 mt-0.5">
              {role === "admin" ? "Panel Administrador" : "Panel Vendedor"}
            </div>
          </div>
          <nav className="flex md:flex-col gap-1 overflow-x-auto px-2 py-3 md:py-4 flex-1">
            {nav.map((item) => {
              const active = location.pathname === item.path || (item.path !== "/admin" && item.path !== "/seller" && location.pathname.startsWith(item.path));
              const Icon = item.icon;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm whitespace-nowrap transition-colors",
                    active ? "bg-amber-500 text-stone-900 font-medium" : "text-stone-300 hover:bg-stone-800"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden md:inline">{item.label}</span>
                </Link>
              );
            })}
          </nav>
          <div className="px-3 py-3 border-t border-stone-800 hidden md:block">
            <div className="text-xs text-stone-400 mb-2 px-2">{session?.name}</div>
            <Button variant="ghost" size="sm" className="w-full justify-start text-stone-300 hover:text-white hover:bg-stone-800" onClick={() => { logout(); navigate("/"); }}>
              <LogOut className="w-4 h-4 mr-2" /> Cerrar sesión
            </Button>
          </div>
        </aside>
      ) : (
        <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-stone-200">
          <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
            <Link to="/" className="font-display text-xl font-semibold tracking-tight">
              ASTIE <span className="text-amber-600">DIESEL</span>
            </Link>
            <nav className="flex items-center gap-1">
              {nav.map((item) => {
                const Icon = item.icon;
                const active = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={cn(
                      "relative flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors",
                      active ? "text-stone-900 font-medium" : "text-stone-500 hover:text-stone-900"
                    )}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="hidden sm:inline">{item.label}</span>
                    {item.path === "/cart" && count > 0 && (
                      <span className="absolute -top-1 -right-1 bg-amber-500 text-stone-900 text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                        {count}
                      </span>
                    )}
                  </Link>
                );
              })}
              <Button variant="outline" size="sm" className="ml-2 hidden sm:flex" onClick={() => { logout(); navigate("/"); }}>
                <LogOut className="w-4 h-4 mr-1" /> Salir
              </Button>
            </nav>
          </div>
        </header>
      )}

      <main className="flex-1 min-w-0">
        <Outlet />
      </main>
    </div>
  );
}