# ASTIE DIESEL — versión independiente

Aplicación React/Vite preparada para funcionar sin plataforma externa. Los datos se almacenan localmente en el dispositivo mediante localStorage.

## Desarrollo

1. Instalar Node.js 20+.
2. Ejecutar `npm install`.
3. Ejecutar `npm run dev`.
4. Para producción: `npm run build`.

## Acceso inicial

- Administrador: `MEBAHEL5`
- Vendedor: `MEBAHEL5`

Las contraseñas pueden cambiarse desde Configuración.

> Importante: al eliminar Base44, esta versión ya no tiene servidor ni sincronización entre dispositivos. Cada instalación mantiene su propia base local.
