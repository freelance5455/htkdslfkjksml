import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.astiediesel.app',
  appName: 'ASTIE DIESEL',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#1c1917'
  }
};

export default config;
