# Generar APK de ASTIE DIESEL

Esta versión no depende de Base44. Para generar el APK en una PC con Android Studio:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

En Android Studio: **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

También puede ejecutarse:

```bash
npm run android:build
```

si el proyecto Android ya fue creado y el entorno Android SDK/Gradle está configurado.

## Datos

La app usa almacenamiento local del dispositivo. No hay servidor externo ni sincronización automática entre teléfonos/computadoras.
