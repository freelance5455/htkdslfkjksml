# ASTIE DIESEL developer notes

This project is independent of external app-builder backends. Keep application data local unless a future backend is explicitly added.
