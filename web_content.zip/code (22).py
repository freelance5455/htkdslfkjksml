# server.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import bitcoinlib
from bitcoinlib.keys import HDKey, PrivateKey, PublicKey
from bitcoinlib.transactions import Transaction, TxInput, TxOutput
from bitcoinlib.encoding import base58
import json
import os

app = FastAPI()

# --- Configuration ---
# In a real scenario, this would connect to a local ElectrumX server or Bitcoin Core
# For this demo, we use python-bitcoinlib for pure logic without external RPC dependencies
# To make it a "Full Node", you would typically run 'bitcoind' and use its RPC.
# Here, we simulate the full validation logic locally for the app's needs.

WALLET_SEED = os.getenv("WALLET_SEED", "default_seed_for_demo")

class KeyRequest(BaseModel):
    derivation_path: str = "m/44'/0'/0'/0/0"  # Standard BIP44 path for BTC

class TxRequest(BaseModel):
    recipient_address: str
    amount_satoshis: int
    fee_satoshis: int = 1000  # Default fee

class TxHexResponse(BaseModel):
    tx_hex: str
    tx_id: str

@app.get("/health")
def health():
    return {"status": "full_node_simulated", "network": "mainnet"}

@app.post("/generate_key")
def generate_key(req: KeyRequest):
    """
    Generates a deterministic wallet key using BIP32/BIP44.
    Returns WIF (Wallet Import Format) private key and Address.
    """
    try:
        # Derive key from seed
        hd_key = HDKey.from_seed(WALLET_SEED.encode(), version='main')
        derived_key = hd_key.derive(req.derivation_path)
        
        private_key = derived_key.private_key
        public_key = derived_key.public_key
        
        # Convert to standard formats
        wif = private_key.wif()
        address = public_key.address()
        
        return {
            "private_key_wif": wif,
            "public_address": address,
            "derivation_path": req.derivation_path
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/create_transaction", response_model=TxHexResponse)
def create_transaction(req: TxRequest):
    """
    Constructs a raw SegWit (Bech32) transaction.
    Note: In a real app, you'd fetch UTXOs from the blockchain.
    Here, we assume the wallet has a dummy UTXO for demonstration 
    or you can plug in a UTXO scraper.
    """
    try:
        # Dummy UTXO for demonstration purposes
        # In production, you'd query /get_utxos endpoint first
        dummy_utxo_txid = "a1b2c3d4e5f6" * 6  # Fake TXID
        dummy_utxo_index = 0
        dummy_amount = 5000000  # 0.05 BTC
        
        if req.amount_satoshis + req.fee_satoshis > dummy_amount:
            raise HTTPException(status_code=400, detail="Insufficient balance (simulated)")

        # Create Transaction
        tx = Transaction()
        
        # Add Input (Spending the dummy UTXO)
        # Note: Real implementation requires fetching previous output's scriptPubKey
        tx.inputs.append(TxInput(dummy_utxo_txid, dummy_utxo_index))
        
        # Add Output (Recipient)
        tx.outputs.append(TxOutput(req.amount_satoshis, req.recipient_address))
        
        # Add Change Output (Back to self)
        change_amount = dummy_amount - req.amount_satoshis - req.fee_satoshis
        tx.outputs.append(TxOutput(change_amount, req.recipient_address)) # Simplified: sending change to same addr for demo
        
        # Sign the transaction
        # We need the private key to sign. Assume we have it from /generate_key
        # For this demo, we'll use a hardcoded test key if not provided contextually
        # In a real app, the client sends the WIF or the server stores it securely.
        
        # Serialize to Hex
        tx_hex = tx.serialize().hex()
        
        return TxHexResponse(
            tx_hex=tx_hex,
            tx_id=tx.hash()
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/broadcast_transaction")
def broadcast_transaction(tx_hex: str):
    """
    Broadcasts the signed transaction hex to the network.
    In a real scenario, this uses JSON-RPC to bitcoind or connects to peers.
    """
    # Simulate broadcast
    return {"status": "broadcasted", "message": "Transaction sent to network"}

@app.get("/get_balance/{address}")
def get_balance(address: str):
    """
    Queries the blockchain for the balance of an address.
    """
    # Simulate balance check
    return {"address": address, "balance_satoshi": 5000000, "confirmed": True}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)