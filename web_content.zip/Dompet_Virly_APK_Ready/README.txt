DOMPET VIRLY — APK READY

Isi ZIP:
- index.html: aplikasi Dompet Virly
- icon.svg: ikon aplikasi

Cara membuat APK tanpa Android Studio:
1. Upload ZIP ini ke layanan HTML/ZIP to APK.
2. Nama aplikasi: Dompet Virly
3. Build APK.
4. Download APK lalu install di HP Android.

Aplikasi ini menyimpan transaksi secara lokal di HP dan dapat dipakai offline.
