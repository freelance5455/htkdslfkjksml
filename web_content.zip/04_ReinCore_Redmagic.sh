#!/bin/bash
# ReinCore Redmagic 11 Pro Plus
# Todos com 2>/dev/null || true

echo "Aplicando ReinCore Redmagic..."

# system.prop típico de performance
setprop debug.performance.tuning 1 2>/dev/null || true
setprop persist.sys.ui.hw 1 2>/dev/null || true
setprop debug.sf.hw 1 2>/dev/null || true
setprop debug.egl.hw 1 2>/dev/null || true
setprop debug.composition.type gpu 2>/dev/null || true
settings put system peak_refresh_rate 144 2>/dev/null || true
settings put system min_refresh_rate 144 2>/dev/null || true
settings put global force_gpu_rendering 1 2>/dev/null || true
cmd power set-fixed-performance-mode-enabled true 2>/dev/null || true

echo "ReinCore Redmagic aplicado!"
