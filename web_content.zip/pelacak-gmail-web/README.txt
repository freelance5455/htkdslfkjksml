PELACAK DAFTAR GMAIL - WEB APP (PWA)

ISI PAKET
- index.html: aplikasi utama dengan 8.192 daftar
- manifest.webmanifest: pengaturan instalasi
- sw.js: cache agar aplikasi dapat dibuka offline setelah pertama kali dimuat
- icons/: ikon aplikasi

CARA MEMASANG DI ANDROID
1. Ekstrak ZIP ini.
2. Unggah seluruh isi folder pelacak-gmail-web ke layanan hosting statis yang memberikan alamat HTTPS, misalnya GitHub Pages atau Netlify.
3. Buka alamat HTTPS situs tersebut di Chrome Android.
4. Tekan tombol "Pasang ke Layar Utama" jika muncul, atau menu ⋮ Chrome > Tambahkan ke layar utama / Instal aplikasi.

CATATAN
- Aplikasi harus dibuka dari alamat HTTPS agar fitur instalasi dan offline aktif. Membuka index.html langsung dari folder HP tidak cukup untuk instalasi PWA.
- Data status dan tanggal disimpan di penyimpanan browser pada perangkat tersebut. Gunakan Ekspor CSV secara berkala sebagai cadangan.
- Jika cache offline pertama kali, buka situs dengan internet sekali terlebih dahulu.
- Variasi titik pada alamat Gmail umumnya tetap menuju kotak masuk Gmail yang sama; variasi tersebut bukan akun Gmail terpisah.
