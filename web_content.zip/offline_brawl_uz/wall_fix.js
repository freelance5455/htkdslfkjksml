(function () {
  function getWalls() {
    var names = ["walls", "obstacles", "blocks", "barriers", "tiles", "colliders"];
    var list = [];
    for (var i = 0; i < names.length; i++) {
      var n = names[i];
      if (typeof window[n] !== "undefined" && Array.isArray(window[n])) {
        for (var j = 0; j < window[n].length; j++) {
          var w = window[n][j];
          if (w && typeof w.x === "number" && typeof w.y === "number") {
            var ww = typeof w.w === "number" ? w.w : (typeof w.width === "number" ? w.width : null);
            var hh = typeof w.h === "number" ? w.h : (typeof w.height === "number" ? w.height : null);
            if (ww !== null && hh !== null && ww > 0 && hh > 0) {
              list.push({ x: w.x, y: w.y, w: ww, h: hh, raw: w });
            } else if (typeof w.r === "number" || typeof w.radius === "number") {
              var wr = typeof w.r === "number" ? w.r : w.radius;
              list.push({ circle: true, x: w.x, y: w.y, r: wr, raw: w });
            }
          }
        }
      }
    }
    return list;
  }

  function getEntities() {
    var ents = [];
    var names = ["players", "bots", "enemies", "fighters", "brawlers", "units"];
    for (var i = 0; i < names.length; i++) {
      var n = names[i];
      if (typeof window[n] !== "undefined" && Array.isArray(window[n])) {
        for (var j = 0; j < window[n].length; j++) {
          if (window[n][j] && typeof window[n][j] === "object") ents.push(window[n][j]);
        }
      }
    }
    if (typeof player !== "undefined" && player && typeof player === "object" && ents.indexOf(player) === -1) {
      ents.push(player);
    }
    return ents;
  }

  function resolveCircleRect(ent, rect) {
    var r = typeof ent.radius === "number" ? ent.radius : (typeof ent.r === "number" ? ent.r : 18);
    var closestX = Math.max(rect.x, Math.min(ent.x, rect.x + rect.w));
    var closestY = Math.max(rect.y, Math.min(ent.y, rect.y + rect.h));
    var dx = ent.x - closestX;
    var dy = ent.y - closestY;
    var distSq = dx * dx + dy * dy;

    if (distSq < r * r) {
      var dist = Math.sqrt(distSq);
      if (dist > 0.0001) {
        var overlap = r - dist;
        ent.x += (dx / dist) * (overlap + 0.5);
        ent.y += (dy / dist) * (overlap + 0.5);
      } else {
        // Markazi ichiga kirib qolgan bo'lsa, eng yaqin chekkaga itarib chiqaramiz
        var leftPen = Math.abs(ent.x - rect.x);
        var rightPen = Math.abs(rect.x + rect.w - ent.x);
        var topPen = Math.abs(ent.y - rect.y);
        var botPen = Math.abs(rect.y + rect.h - ent.y);
        var minPen = Math.min(leftPen, rightPen, topPen, botPen);

        if (minPen === leftPen) ent.x = rect.x - r - 1;
        else if (minPen === rightPen) ent.x = rect.x + rect.w + r + 1;
        else if (minPen === topPen) ent.y = rect.y - r - 1;
        else ent.y = rect.y + rect.h + r + 1;
      }
      if (typeof ent.vx === "number") ent.vx *= 0.2;
      if (typeof ent.vy === "number") ent.vy *= 0.2;
    }
  }

  function resolveCircleCircle(ent, cWall) {
    var r = typeof ent.radius === "number" ? ent.radius : (typeof ent.r === "number" ? ent.r : 18);
    var minDist = r + cWall.r;
    var dx = ent.x - cWall.x;
    var dy = ent.y - cWall.y;
    var dist = Math.hypot(dx, dy);
    if (dist < minDist) {
      var nx = dist > 0.001 ? dx / dist : 1;
      var ny = dist > 0.001 ? dy / dist : 0;
      var overlap = minDist - dist;
      ent.x += nx * (overlap + 0.5);
      ent.y += ny * (overlap + 0.5);
    }
  }

  function clampToArena(ent) {
    var canvas = document.querySelector("canvas");
    var maxW = typeof worldWidth === "number" ? worldWidth : (typeof arenaWidth === "number" ? arenaWidth : (canvas ? canvas.width : 1200));
    var maxH = typeof worldHeight === "number" ? worldHeight : (typeof arenaHeight === "number" ? arenaHeight : (canvas ? canvas.height : 800));
    var r = typeof ent.radius === "number" ? ent.radius : (typeof ent.r === "number" ? ent.r : 18);

    if (maxW > 100 && maxH > 100) {
      if (ent.x < r + 4) ent.x = r + 4;
      if (ent.y < r + 4) ent.y = r + 4;
      if (ent.x > maxW - r - 4) ent.x = maxW - r - 4;
      if (ent.y > maxH - r - 4) ent.y = maxH - r - 4;
    }
  }

  function cleanBulletsAgainstWalls(walls) {
    var names = ["bullets", "projectiles", "shots", "missiles", "lasers", "attacks"];
    for (var i = 0; i < names.length; i++) {
      var n = names[i];
      if (typeof window[n] === "undefined" || !Array.isArray(window[n])) continue;
      var arr = window[n];
      for (var j = arr.length - 1; j >= 0; j--) {
        var b = arr[j];
        if (!b || typeof b.x !== "number" || typeof b.y !== "number") continue;
        var hit = false;
        for (var w = 0; w < walls.length; w++) {
          var wall = walls[w];
          if (wall.circle) {
            if (Math.hypot(b.x - wall.x, b.y - wall.y) <= wall.r + 3) {
              hit = true;
              break;
            }
          } else {
            if (b.x >= wall.x && b.x <= wall.x + wall.w && b.y >= wall.y && b.y <= wall.y + wall.h) {
              hit = true;
              break;
            }
          }
        }
        if (hit) {
          arr.splice(j, 1);
        }
      }
    }
  }

  function fixCollisions() {
    var walls = getWalls();
    var ents = getEntities();

    for (var i = 0; i < ents.length; i++) {
      var ent = ents[i];
      if (!ent || typeof ent.x !== "number" || typeof ent.y !== "number") continue;
      if (ent.dead === true || ent.alive === false || (typeof ent.hp === "number" && ent.hp <= 0)) continue;

      for (var w = 0; w < walls.length; w++) {
        var wall = walls[w];
        if (wall.circle) resolveCircleCircle(ent, wall);
        else resolveCircleRect(ent, wall);
      }
      clampToArena(ent);
    }

    if (walls.length > 0) {
      cleanBulletsAgainstWalls(walls);
    }
  }

  window.addEventListener("load", function () {
    setInterval(fixCollisions, 20);
  });
})();
