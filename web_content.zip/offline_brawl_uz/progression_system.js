(function () {
  var STORAGE_KEY = "brawl_uz_progress_v2";

  var defaultState = {
    lvl: 1,
    xp: 0,
    rpLvl: 1,
    rpXp: 0,
    trophies: 0,
    kills: 0,
    matches: 0,
    gorillaKills: 0,
    claimedLvlRewards: [],
    claimedRpRewards: [],
    claimedMissions: [],
    unlockedSkins: ["Klassik"],
    selectedSkin: "Klassik",
    _lastMatchCounted: false
  };

  function loadState() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return JSON.parse(JSON.stringify(defaultState));
      return Object.assign({}, JSON.parse(JSON.stringify(defaultState)), JSON.parse(raw));
    } catch (e) {
      return JSON.parse(JSON.stringify(defaultState));
    }
  }

  var state = loadState();

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {}
  }

  function getXpNeededForLvl(lvl) {
    return 100 + (lvl - 1) * 70;
  }

  function getRpXpNeeded(rpLvl) {
    return 120 + (rpLvl - 1) * 85;
  }

  var lvlRewards = [
    { lvl: 2, title: "LVL 2: Oltin Qirol Skini", skins: ["Oltin Qirol"] },
    { lvl: 3, title: "LVL 3: +50 Kubok & Soya Ninja", skins: ["Soya Ninja"], trophies: 50 },
    { lvl: 4, title: "LVL 4: Olmos Ritsar Skini", skins: ["Olmos Ritsar"] },
    {
      lvl: 5,
      title: "LVL 5 MEGA REWARD: Yaltillovchi Skinlar To'plami!",
      skins: ["Yaltiroq Oltin", "Neon Kamalak", "Zumrad Jilo", "Kristal Binafsha"],
      trophies: 120
    }
  ];

  var rpSkins = [
    { rpLvl: 2, name: "Olmos Ritsar (RP)" },
    { rpLvl: 5, name: "Ajdaho Imperatori (RP)" }
  ];

  var allShopSkins = [
    { name: "Klassik", tag: "Boshlang'ich" },
    { name: "Oltin Qirol", tag: "LVL 2" },
    { name: "Soya Ninja", tag: "LVL 3" },
    { name: "Olmos Ritsar", tag: "LVL 4" },
    { name: "Yaltiroq Oltin", tag: "LVL 5 Reward" },
    { name: "Neon Kamalak", tag: "LVL 5 Reward" },
    { name: "Zumrad Jilo", tag: "LVL 5 Reward" },
    { name: "Kristal Binafsha", tag: "LVL 5 Reward" },
    { name: "Olmos Ritsar (RP)", tag: "RP 2" },
    { name: "Ajdaho Imperatori (RP)", tag: "RP 5" }
  ];

  var missions = [
    {
      id: "gorilla_10_kills",
      text: "Gorillada 10 ta kill qil",
      current: function () { return state.gorillaKills; },
      target: 10,
      rpReward: 95,
      trophyReward: 35
    },
    {
      id: "play_10_matches",
      text: "10 ta match o'yna",
      current: function () { return state.matches; },
      target: 10,
      rpReward: 105,
      trophyReward: 40
    },
    {
      id: "total_15_kills",
      text: "Jami 15 ta kill qil",
      current: function () { return state.kills; },
      target: 15,
      rpReward: 85,
      trophyReward: 30
    }
  ];

  function isMenuOpen() {
    var menu = document.getElementById("menu");
    var welcome = document.getElementById("welcomeScreen");
    var mOpen = menu && getComputedStyle(menu).display !== "none";
    var wOpen = welcome && getComputedStyle(welcome).display !== "none";
    return Boolean(mOpen || wOpen);
  }

  function showBanner(msg) {
    var el = document.getElementById("progToast");
    if (!el) {
      el = document.createElement("div");
      el.id = "progToast";
      el.style.cssText =
        "position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:70;" +
        "padding:7px 14px;font-size:11px;font-weight:900;color:#fff;" +
        "background:rgba(15,23,42,0.92);border:2px solid #ffd32a;" +
        "border-radius:11px;pointer-events:none;transition:opacity 0.25s;text-align:center;";
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.style.opacity = "1";
    clearTimeout(window._progToastTimer);
    window._progToastTimer = setTimeout(function () {
      el.style.opacity = "0";
    }, 2200);
  }

  function unlockSkinList(list) {
    if (!Array.isArray(list)) return;
    for (var i = 0; i < list.length; i++) {
      var sName = list[i];
      if (state.unlockedSkins.indexOf(sName) === -1) {
        state.unlockedSkins.push(sName);
      }
    }
  }

  function addXp(amount) {
    state.xp += amount;
    while (state.xp >= getXpNeededForLvl(state.lvl)) {
      state.xp -= getXpNeededForLvl(state.lvl);
      state.lvl += 1;
      checkLvlRewards();
      if (isMenuOpen()) showBanner("LVL " + state.lvl + " ochildi!");
    }
    saveState();
  }

  function addRpXp(amount) {
    state.rpXp += amount;
    while (state.rpXp >= getRpXpNeeded(state.rpLvl)) {
      state.rpXp -= getRpXpNeeded(state.rpLvl);
      state.rpLvl += 1;
      checkRpRewards();
      if (isMenuOpen()) showBanner("RP " + state.rpLvl + " ochildi!");
    }
    saveState();
  }

  function checkLvlRewards() {
    for (var i = 0; i < lvlRewards.length; i++) {
      var r = lvlRewards[i];
      if (state.lvl >= r.lvl && state.claimedLvlRewards.indexOf(r.lvl) === -1) {
        state.claimedLvlRewards.push(r.lvl);
        if (r.skins) {
          unlockSkinList(r.skins);
          state.selectedSkin = r.skins[0];
        }
        if (r.trophies) state.trophies += r.trophies;
      }
    }
    saveState();
  }

  function checkRpRewards() {
    for (var i = 0; i < rpSkins.length; i++) {
      var s = rpSkins[i];
      if (state.rpLvl >= s.rpLvl && state.unlockedSkins.indexOf(s.name) === -1) {
        state.unlockedSkins.push(s.name);
      }
    }
    saveState();
  }

  function checkMissions() {
    for (var i = 0; i < missions.length; i++) {
      var m = missions[i];
      if (state.claimedMissions.indexOf(m.id) === -1 && m.current() >= m.target) {
        state.claimedMissions.push(m.id);
        state.trophies += m.trophyReward;
        addRpXp(m.rpReward);
      }
    }
    saveState();
  }

  var prevKills = 0;

  function syncStats() {
    var active = !isMenuOpen();

    if (active && !state._lastMatchCounted) {
      state.matches += 1;
      state.trophies += 5;
      addXp(15);
      state._lastMatchCounted = true;
      checkMissions();
      saveState();
    } else if (!active) {
      state._lastMatchCounted = false;
      prevKills = 0;
    }

    var currentKills = 0;
    if (typeof score === "number") currentKills = Math.max(0, Math.floor(score));
    else if (typeof killsCount === "number") currentKills = Math.max(0, Math.floor(killsCount));
    else if (typeof player !== "undefined" && player && typeof player.kills === "number") {
      currentKills = Math.max(0, Math.floor(player.kills));
    }

    if (active && currentKills > prevKills) {
      var diff = currentKills - prevKills;
      prevKills = currentKills;
      state.kills += diff;
      state.trophies += diff * 10;
      addXp(diff * 25);
      addRpXp(diff * 20);

      var skStr = (state.selectedSkin || "").toLowerCase();
      if (skStr.indexOf("gorilla") !== -1 || skStr.indexOf("qirol") !== -1) {
        state.gorillaKills += diff;
      }
      checkMissions();
      saveState();
    }
  }

  function applySelectedSkin() {
    var skinColors = {
      "Klassik": "",
      "Oltin Qirol": "#ffd32a",
      "Soya Ninja": "#6c5ce7",
      "Olmos Ritsar": "#00d2d3",
      "Yaltiroq Oltin": "#ffeaa7",
      "Neon Kamalak": "#00f2fe",
      "Zumrad Jilo": "#00e676",
      "Kristal Binafsha": "#d500f9",
      "Olmos Ritsar (RP)": "#00a8ff",
      "Ajdaho Imperatori (RP)": "#ff4757"
    };
    var col = skinColors[state.selectedSkin] || "";
    var targets = [];
    if (typeof player !== "undefined" && player) targets.push(player);
    if (typeof players !== "undefined" && Array.isArray(players) && players[0]) targets.push(players[0]);

    for (var i = 0; i < targets.length; i++) {
      var p = targets[i];
      if (!p._baseColor && p.color) p._baseColor = p.color;
      var chosen = col || p._baseColor;
      if (chosen) {
        if ("color" in p) p.color = chosen;
        if ("fill" in p) p.fill = chosen;
        if ("skinColor" in p) p.skinColor = chosen;
      }
    }
  }

  function ensureMenuAndShopControls() {
    var inMenu = isMenuOpen();

    var oldSkinBtn = document.getElementById("arenaSkinBtn");
    if (oldSkinBtn) oldSkinBtn.style.display = "none";

    var topBar = document.getElementById("progTopBar");
    if (!topBar) {
      topBar = document.createElement("div");
      topBar.id = "progTopBar";
      topBar.style.cssText =
        "position:fixed;top:42px;right:8px;z-index:28;display:flex;gap:5px;align-items:center;";
      document.body.appendChild(topBar);
    }

    if (!inMenu) {
      topBar.innerHTML =
        '<span style="padding:3px 7px;font-size:10px;font-weight:900;color:#fff;background:rgba(20,24,40,0.8);border:1px solid #ffd32a;border-radius:8px;">LVL ' +
        state.lvl +
        " • RP " +
        state.rpLvl +
        " • 🏆 " +
        state.trophies +
        "</span>";
      var modalHide = document.getElementById("progCenterModal");
      if (modalHide) modalHide.style.display = "none";
      return;
    }

    topBar.innerHTML =
      '<span style="padding:4px 8px;font-size:10px;font-weight:900;color:#fff;background:#1e272e;border:1px solid #ffd32a;border-radius:8px;">LVL ' +
      state.lvl +
      " | RP " +
      state.rpLvl +
      " | 🏆 " +
      state.trophies +
      "</span>" +
      '<button id="menuRewardBtn" style="padding:4px 9px;font-size:10px;font-weight:900;color:#111;background:#ffd32a;border:1px solid #fff;border-radius:8px;cursor:pointer;">REWARD</button>' +
      '<button id="menuShopBtn" style="padding:4px 9px;font-size:10px;font-weight:900;color:#fff;background:#3742fa;border:1px solid #a29bfe;border-radius:8px;cursor:pointer;">SHOP</button>';

    var rBtn = document.getElementById("menuRewardBtn");
    var sBtn = document.getElementById("menuShopBtn");
    if (rBtn) rBtn.onclick = function () { openSectionModal("reward"); };
    if (sBtn) sBtn.onclick = function () { openSectionModal("shop"); };
  }

  function openSectionModal(tab) {
    if (!isMenuOpen()) return;

    var modal = document.getElementById("progCenterModal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "progCenterModal";
      modal.style.cssText =
        "position:fixed;inset:0;z-index:65;background:rgba(0,0,0,0.78);" +
        "display:flex;align-items:center;justify-content:center;padding:14px;";
      document.body.appendChild(modal);
    }

    var bodyHtml = "";
    if (tab === "reward") {
      var xpNeed = getXpNeededForLvl(state.lvl);
      var rpNeed = getRpXpNeeded(state.rpLvl);

      var lvlListHtml = "";
      for (var rIdx = 0; rIdx < lvlRewards.length; rIdx++) {
        var lr = lvlRewards[rIdx];
        var opened = state.lvl >= lr.lvl;
        lvlListHtml +=
          '<div style="background:rgba(255,255,255,0.05);padding:6px 10px;border-radius:9px;margin-bottom:5px;display:flex;justify-content:space-between;align-items:center;">' +
          '<span style="font-size:10px;font-weight:800;color:#fff;">' +
          lr.title +
          "</span>" +
          '<span style="font-size:9px;font-weight:900;padding:3px 7px;border-radius:7px;background:' +
          (opened ? "#2ed573" : "#57606f") +
          ';color:' +
          (opened ? "#111" : "#fff") +
          ';">' +
          (opened ? "OCHILDI" : "LVL " + lr.lvl) +
          "</span></div>";
      }

      var mHtml = "";
      for (var i = 0; i < missions.length; i++) {
        var m = missions[i];
        var cur = Math.min(m.target, m.current());
        var done = state.claimedMissions.indexOf(m.id) !== -1;
        mHtml +=
          '<div style="background:rgba(255,255,255,0.06);padding:8px 10px;border-radius:10px;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;gap:8px;">' +
          '<div><div style="font-size:11px;font-weight:800;color:#fff;">' +
          m.text +
          '</div><div style="font-size:10px;color:#dfe6e9;">' +
          cur +
          "/" +
          m.target +
          " • +" +
          m.rpReward +
          " RP XP • +" +
          m.trophyReward +
          " 🏆</div></div>" +
          '<span style="font-size:10px;font-weight:900;padding:4px 8px;border-radius:8px;background:' +
          (done ? "#2ed573" : "#ffa502") +
          ';color:#111;">' +
          (done ? "OLINDI" : "DAVOMDA") +
          "</span></div>";
      }

      bodyHtml =
        '<div style="font-size:11px;margin-bottom:8px;color:#ffeaa7;">' +
        "LVL: <b>" + state.lvl + "</b> (" + state.xp + "/" + xpNeed + " XP) • " +
        "RP: <b>" + state.rpLvl + "</b> (" + state.rpXp + "/" + rpNeed + " RP XP) • " +
        "🏆 <b>" + state.trophies + "</b>" +
        "</div>" +
        '<div style="font-size:11px;font-weight:900;color:#ffd32a;margin-bottom:5px;">LVL REWARDLAR (5 LVL = YALTILLOVCHI SKINLAR):</div>' +
        lvlListHtml +
        '<div style="font-size:11px;font-weight:900;color:#7bed9f;margin:8px 0 5px;">VAZIFALAR:</div>' +
        mHtml;
    } else {
      var sHtml = "";
      for (var j = 0; j < allShopSkins.length; j++) {
        var item = allShopSkins[j];
        var unlocked = state.unlockedSkins.indexOf(item.name) !== -1;
        var picked = state.selectedSkin === item.name;
        sHtml +=
          '<div style="background:rgba(255,255,255,0.06);padding:8px 10px;border-radius:10px;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;">' +
          '<div><div style="font-size:11px;font-weight:900;color:#fff;">' +
          item.name +
          '</div><div style="font-size:10px;color:#a29bfe;">Manba: ' +
          item.tag +
          "</div></div>" +
          (unlocked
            ? '<button data-pick="' +
              item.name +
              '" class="shopPickBtn" style="padding:5px 10px;font-size:10px;font-weight:900;border-radius:8px;cursor:pointer;border:1px solid #ffd32a;background:' +
              (picked ? "#2ed573" : "#3742fa") +
              ';color:' +
              (picked ? "#111" : "#fff") +
              ';">' +
              (picked ? "TANLANGAN" : "TANLASH") +
              "</button>"
            : '<span style="padding:4px 8px;font-size:10px;font-weight:900;border-radius:8px;background:#57606f;color:#dfe6e9;">QULFLI</span>') +
          "</div>";
      }
      bodyHtml =
        '<div style="font-size:11px;font-weight:900;color:#70a1ff;margin-bottom:6px;">SHOP — SKINLAR:</div>' +
        sHtml;
    }

    modal.innerHTML =
      '<div style="width:100%;max-width:390px;max-height:85vh;overflow-y:auto;background:#141829;border:2px solid #ffd32a;border-radius:16px;padding:14px;color:#fff;font-family:sans-serif;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">' +
      '<div style="display:flex;gap:6px;">' +
      '<button id="tabRewardBtn" style="padding:5px 10px;font-size:10px;font-weight:900;border-radius:8px;cursor:pointer;border:none;background:' +
      (tab === "reward" ? "#ffd32a" : "#2f3640") +
      ";color:" +
      (tab === "reward" ? "#111" : "#fff") +
      ';">LVL / REWARD</button>' +
      '<button id="tabShopBtn" style="padding:5px 10px;font-size:10px;font-weight:900;border-radius:8px;cursor:pointer;border:none;background:' +
      (tab === "shop" ? "#3742fa" : "#2f3640") +
      ';color:#fff;">SHOP</button>' +
      "</div>" +
      '<button id="closeSectionModalBtn" style="background:#ff4757;color:#fff;border:none;border-radius:8px;padding:4px 10px;font-weight:900;cursor:pointer;">YOPISH</button>' +
      "</div>" +
      bodyHtml +
      "</div>";

    modal.style.display = "flex";

    document.getElementById("tabRewardBtn").onclick = function () { openSectionModal("reward"); };
    document.getElementById("tabShopBtn").onclick = function () { openSectionModal("shop"); };
    document.getElementById("closeSectionModalBtn").onclick = function () { modal.style.display = "none"; };

    var pickButtons = modal.querySelectorAll(".shopPickBtn");
    for (var k = 0; k < pickButtons.length; k++) {
      pickButtons[k].onclick = function () {
        state.selectedSkin = this.getAttribute("data-pick");
        saveState();
        applySelectedSkin();
        openSectionModal("shop");
      };
    }
  }

  window.addEventListener("load", function () {
    checkLvlRewards();
    checkRpRewards();
    ensureMenuAndShopControls();
    setInterval(function () {
      syncStats();
      applySelectedSkin();
      ensureMenuAndShopControls();
    }, 400);
  });
})();
