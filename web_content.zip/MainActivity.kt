package com.karen.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startKaren() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "KAREN"; textSize = 32f; gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Başlat'a bas, ekranda yüzen K butonu çıkacak.\nButona dokun ve konuş."
            gravity = Gravity.CENTER; setPadding(0, 24, 0, 48)
        }
        val start = Button(this).apply {
            text = "Karen'i Başlat"; setOnClickListener { checkAndStart() }
        }
        val stop = Button(this).apply {
            text = "Karen'i Durdur"
            setOnClickListener { stopService(Intent(this@MainActivity, KarenService::class.java)) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            addView(title); addView(info); addView(start); addView(stop)
        })
    }

    private fun checkAndStart() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    private fun startKaren() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Üstte gösterme iznini aç, sonra tekrar Başlat'a bas", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, KarenService::class.java))
        Toast.makeText(this, "Karen çevrimiçi", Toast.LENGTH_SHORT).show()
    }
}
