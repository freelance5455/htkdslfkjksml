package com.morisbaz.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity(), SensorEventListener {

    companion object {
        // >>> METTEZ ICI L'ADRESSE DE VOTRE SITE (celle où vous publiez index.html) <<<
        const val APP_URL = "https://VOTRE-SITE.netlify.app/"
        const val REQ_PERM = 42
        const val REQ_FILE = 43
    }

    private lateinit var web: WebView
    private var sm: SensorManager? = null
    private var stepSensor: Sensor? = null
    @Volatile private var steps = -1L
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private fun granted() =
        Build.VERSION.SDK_INT < 29 ||
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

    /** Fonctions appelées par la page : window.MorisNative.xxx() */
    inner class Bridge {
        @JavascriptInterface fun hasStepCounter(): Boolean = stepSensor != null
        @JavascriptInterface fun hasPermission(): Boolean = granted()
        @JavascriptInterface fun getStepCounter(): Long = steps
        @JavascriptInterface fun requestPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 29 && !granted())
                    requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), REQ_PERM)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        stepSensor = sm?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
        }
        web.addJavascriptInterface(Bridge(), "MorisNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (!r.isForMainFrame) return false
                if (r.url.host == Uri.parse(APP_URL).host) return false
                // liens externes (TikTok, Juice, WhatsApp...) : ouvrir hors de l'application
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        // Nécessaire pour les champs « Choisir un fichier » (preuves de paiement, photos produits)
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    startActivityForResult(p.createIntent(), REQ_FILE); true
                } catch (e: Exception) { fileCallback = null; false }
            }
        }
        if (savedInstanceState == null) web.loadUrl(APP_URL) else web.restoreState(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 29 && !granted())
            requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), REQ_PERM)
    }

    override fun onResume() {
        super.onResume()
        if (stepSensor != null && granted())
            sm?.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        super.onPause()
        sm?.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) { steps = e.values[0].toLong() }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM && stepSensor != null && granted())
            sm?.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_FILE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            fileCallback = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        web.saveState(out)
    }
}
