package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {

  companion object {
    private const val TAG = "MyraMainActivity"
    private const val ASSET_BASE_URL = "https://appassets.androidplatform.net/assets/index.html"
  }

  private lateinit var webView: WebView
  private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

  private val fileChooserLauncher =
      registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
          val data: Intent? = result.data
          val results =
              when {
                data?.data != null -> arrayOf(data.data!!)
                data?.clipData != null -> {
                  val clipData = data.clipData!!
                  Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                }
                else -> null
              }
          fileChooserCallback?.onReceiveValue(results)
        } else {
          fileChooserCallback?.onReceiveValue(null)
        }
        fileChooserCallback = null
      }

  private val permissionLauncher =
      registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
          permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
        Log.d(
            TAG,
            "Hardware permissions callback - Audio: $recordAudioGranted, Camera: $cameraGranted")
      }

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    setupEdgeToEdgeAndImmersive()
    requestRequiredPermissions()

    webView = WebView(this)
    configureWebView(webView)

    val container =
        FrameLayout(this).apply {
          layoutParams =
              ViewGroup.LayoutParams(
                  ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
          setBackgroundColor(Color.parseColor("#0B0E14"))
          addView(webView)
        }

    setContentView(container)

    setupBackNavigation()

    // Load entry point from local assets using secure appassets domain
    webView.loadUrl(ASSET_BASE_URL)
  }

  private fun setupEdgeToEdgeAndImmersive() {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    window.statusBarColor = Color.TRANSPARENT
    window.navigationBarColor = Color.TRANSPARENT

    val insetsController = WindowCompat.getInsetsController(window, window.decorView)
    insetsController.systemBarsBehavior =
        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    insetsController.isAppearanceLightStatusBars = false
    insetsController.isAppearanceLightNavigationBars = false
  }

  private fun requestRequiredPermissions() {
    val neededPermissions = mutableListOf<String>()

    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
        PackageManager.PERMISSION_GRANTED) {
      neededPermissions.add(Manifest.permission.RECORD_AUDIO)
    }

    if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=
        PackageManager.PERMISSION_GRANTED) {
      neededPermissions.add(Manifest.permission.CAMERA)
    }

    if (ContextCompat.checkSelfPermission(this, Manifest.permission.MODIFY_AUDIO_SETTINGS) !=
        PackageManager.PERMISSION_GRANTED) {
      neededPermissions.add(Manifest.permission.MODIFY_AUDIO_SETTINGS)
    }

    if (neededPermissions.isNotEmpty()) {
      permissionLauncher.launch(neededPermissions.toTypedArray())
    }
  }

  @SuppressLint("SetJavaScriptEnabled")
  private fun configureWebView(wv: WebView) {
    wv.setBackgroundColor(Color.parseColor("#0B0E14"))
    wv.isVerticalScrollBarEnabled = false
    wv.isHorizontalScrollBarEnabled = false
    wv.overScrollMode = View.OVER_SCROLL_NEVER
    wv.setLayerType(View.LAYER_TYPE_NONE, null)

    val settings = wv.settings

    // Core web application features
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    settings.databaseEnabled = true

    // File and content access
    settings.allowFileAccess = true
    settings.allowContentAccess = true
    @Suppress("DEPRECATION")
    settings.allowFileAccessFromFileURLs = true
    @Suppress("DEPRECATION")
    settings.allowUniversalAccessFromFileURLs = true

    // Media & Audio playback without requiring preliminary user click gesture
    settings.mediaPlaybackRequiresUserGesture = false

    // Allow mixed content and external APIs (Gemini, ElevenLabs, WebSockets)
    settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

    // Viewport and scaling
    settings.useWideViewPort = true
    settings.loadWithOverviewMode = true
    settings.setSupportZoom(false)
    settings.builtInZoomControls = false
    settings.displayZoomControls = false

    // Cache strategy
    settings.cacheMode = WebSettings.LOAD_DEFAULT

    // Configure secure asset loader for assets/
    val assetLoader =
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

    wv.webViewClient =
        object : WebViewClient() {
          override fun shouldInterceptRequest(
              view: WebView?,
              request: WebResourceRequest?
          ): WebResourceResponse? {
            val url = request?.url ?: return null

            // Intercept root favicon.ico requests to avoid net::ERR_NAME_NOT_RESOLVED
            if (url.path == "/favicon.ico" || url.lastPathSegment == "favicon.ico") {
              return WebResourceResponse(
                  "image/x-icon",
                  "UTF-8",
                  200,
                  "OK",
                  mapOf(
                      "Access-Control-Allow-Origin" to "*",
                      "Cache-Control" to "max-age=31536000"
                  ),
                  java.io.ByteArrayInputStream(ByteArray(0))
              )
            }

            val response = assetLoader.shouldInterceptRequest(url)
            if (response != null) {
              // Ensure cross-origin resource sharing headers are attached
              val headers =
                  (response.responseHeaders ?: mutableMapOf()).toMutableMap().apply {
                    put("Access-Control-Allow-Origin", "*")
                    put("Access-Control-Allow-Methods", "GET, POST, OPTIONS, HEAD")
                    put("Access-Control-Allow-Headers", "*")
                  }
              response.responseHeaders = headers
              return response
            }
            return super.shouldInterceptRequest(view, request)
          }

          override fun onReceivedError(
              view: WebView?,
              request: WebResourceRequest?,
              error: WebResourceError?
          ) {
            super.onReceivedError(view, request, error)
            if (request?.url?.path == "/favicon.ico" || request?.url?.lastPathSegment == "favicon.ico") return
            Log.w(
                TAG,
                "WebView Error: [${error?.errorCode}] ${error?.description} for ${request?.url}")
          }
        }

    wv.webChromeClient =
        object : WebChromeClient() {
          // Automatically grant microphone and camera hardware permissions to WebView
          override fun onPermissionRequest(request: PermissionRequest?) {
            runOnUiThread {
              Log.d(TAG, "Granting WebView hardware permissions: ${request?.resources?.toList()}")
              request?.grant(request.resources)
            }
          }

          override fun onPermissionRequestCanceled(request: PermissionRequest?) {
            super.onPermissionRequestCanceled(request)
            Log.w(TAG, "WebView permission request canceled")
          }

          override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
            Log.d(
                "MyraWebConsole",
                "${consoleMessage?.message()} -- line ${consoleMessage?.lineNumber()} (${consoleMessage?.sourceId()})")
            return true
          }

          override fun onShowFileChooser(
              webView: WebView?,
              filePathCallback: ValueCallback<Array<Uri>>?,
              fileChooserParams: FileChooserParams?
          ): Boolean {
            fileChooserCallback?.onReceiveValue(null)
            fileChooserCallback = filePathCallback

            val intent =
                fileChooserParams?.createIntent()
                    ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                      addCategory(Intent.CATEGORY_OPENABLE)
                      type = "*/*"
                    }

            try {
              fileChooserLauncher.launch(intent)
            } catch (e: Exception) {
              Log.w(TAG, "Failed to launch file chooser", e)
              fileChooserCallback?.onReceiveValue(null)
              fileChooserCallback = null
              return false
            }
            return true
          }
        }

    // Add JavaScript Interface for native interactions
    wv.addJavascriptInterface(WebAppInterface(this, wv), "AndroidBridge")
  }

  private fun setupBackNavigation() {
    onBackPressedDispatcher.addCallback(
        this,
        object : OnBackPressedCallback(true) {
          override fun handleOnBackPressed() {
            if (::webView.isInitialized && webView.canGoBack()) {
              webView.goBack()
            } else {
              isEnabled = false
              onBackPressedDispatcher.onBackPressed()
            }
          }
        })
  }

  override fun onResume() {
    super.onResume()
    if (::webView.isInitialized) {
      webView.onResume()
    }
  }

  override fun onPause() {
    if (::webView.isInitialized) {
      webView.onPause()
    }
    super.onPause()
  }

  override fun onDestroy() {
    if (::webView.isInitialized) {
      webView.stopLoading()
      webView.destroy()
    }
    super.onDestroy()
  }

  /** Native bridge interface exposed to JavaScript */
  class WebAppInterface(private val activity: Activity, private val webView: WebView) {

    @JavascriptInterface
    fun showToast(message: String) {
      activity.runOnUiThread {
        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
      }
    }

    @JavascriptInterface
    fun vibrate(milliseconds: Long) {
      activity.runOnUiThread {
        try {
          if (ContextCompat.checkSelfPermission(activity, Manifest.permission.VIBRATE) ==
              PackageManager.PERMISSION_GRANTED) {
            val vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            vibrator?.let {
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                it.vibrate(
                    VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
              } else {
                @Suppress("DEPRECATION")
                it.vibrate(milliseconds)
              }
            }
          }
        } catch (t: Throwable) {
          Log.w("MyraBridge", "Vibrate call ignored: ${t.message}")
        }
      }
    }

    @JavascriptInterface
    fun hasCameraPermission(): Boolean {
      return ContextCompat.checkSelfPermission(activity, Manifest.permission.CAMERA) ==
          PackageManager.PERMISSION_GRANTED
    }

    @JavascriptInterface
    fun hasAudioPermission(): Boolean {
      return ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO) ==
          PackageManager.PERMISSION_GRANTED
    }

    @JavascriptInterface
    fun toggleTorch(enable: Boolean): Boolean {
      return try {
        val cameraManager =
            activity.getSystemService(Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
        val cameraId = cameraManager?.cameraIdList?.firstOrNull()
        if (cameraManager != null && cameraId != null) {
          cameraManager.setTorchMode(cameraId, enable)
          true
        } else {
          false
        }
      } catch (e: Throwable) {
        Log.w("MyraBridge", "Torch toggle non-fatal: ${e.message}")
        false
      }
    }

    @JavascriptInterface
    fun getBatteryLevel(): Int {
      return try {
        val batteryManager =
            activity.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        batteryManager?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
      } catch (e: Throwable) {
        -1
      }
    }

    @JavascriptInterface
    fun isCharging(): Boolean {
      return try {
        val batteryManager =
            activity.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        val status =
            batteryManager?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_STATUS)
        status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
            status == android.os.BatteryManager.BATTERY_STATUS_FULL
      } catch (e: Throwable) {
        false
      }
    }

    @JavascriptInterface
    fun setMediaVolume(percent: Int): Boolean {
      return try {
        val audioManager =
            activity.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        if (audioManager != null) {
          val max = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
          val target = (max * (percent.coerceIn(0, 100) / 100.0f)).toInt()
          audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, target, 0)
          true
        } else {
          false
        }
      } catch (e: Throwable) {
        false
      }
    }

    @JavascriptInterface
    fun openExternalUrl(url: String): Boolean {
      return try {
        val intent =
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
              flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        activity.startActivity(intent)
        true
      } catch (e: Throwable) {
        false
      }
    }

    @JavascriptInterface
    fun killApp() {
      activity.runOnUiThread {
        try {
          activity.finishAffinity()
          android.os.Process.killProcess(android.os.Process.myPid())
        } catch (e: Throwable) {
          activity.finish()
        }
      }
    }

    @JavascriptInterface
    fun wipeAllData() {
      activity.runOnUiThread {
        try {
          android.webkit.WebStorage.getInstance().deleteAllData()
          webView.clearCache(true)
          webView.clearFormData()
          webView.clearHistory()
        } catch (e: Throwable) {
          Log.w("MyraBridge", "Wipe non-fatal: ${e.message}")
        }
      }
    }
  }
}
