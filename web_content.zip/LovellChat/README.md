# Lovell Chat — Android starter project

This is a mobile-friendly chat app prototype named **Lovell Chat**, using a blue-and-black theme.
It includes a chat-list UI, conversation UI, group chats, status, profile, image attachment preview, and voice-message recording UI.
It is a front-end starter, not a production messaging service: messages are stored locally in the browser and are not yet delivered to other users.

## Try it
1. Extract the ZIP.
2. Open `www/index.html` in a browser to preview the interface.
3. To turn it into an Android APK, use Android Studio with a WebView wrapper or Capacitor.

## What is not live yet
- User sign-in and multi-device accounts
- Real-time message delivery between phones
- Cloud image/audio storage and push notifications
- Voice/video calls
- End-to-end encryption

These require a backend such as Firebase and further Android configuration.
