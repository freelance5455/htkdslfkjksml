PROCESSOR HARDWARE — VIRTUAL SYSTEM
===================================

RUN IT
1. Extract the ZIP archive.
2. Open index.html in a modern browser (Chrome, Edge, Firefox, Safari).
3. Use the panel to try CPU/overclock simulations, cooling profiles, storage/RAM planning, architecture targets, virtual filesystem inspection, JSON export, and demo freeze/recovery.

WHAT IS INCLUDED
- Responsive single-file HTML interface
- CPU clock/load/temperature estimates (simulated only)
- Overclock target slider (simulated only)
- Cooling profiles (simulated fan RPM only)
- 2–32 TB storage planner and RAM planning selector
- x86_64 and arm64-v8a architecture selector
- Virtual filesystem tree and configuration export
- Freeze/recovery overlay
- Build-plan helper for Windows, Linux, Android, and browser

IMPORTANT LIMITATIONS
This is a browser-based prototype, not a complete hardware operating system. It does not read live sensors, control actual fan curves, change CPU/GPU clocks or voltage, mount a real virtual filesystem, install drivers, compile APK/EXE files, or freeze the physical device. Real integration needs native platform-specific code, suitable vendor/OS APIs, permissions, and hardware support.

ARCHITECTURE
x86_64 is for compatible 64-bit Intel/AMD platforms. arm64-v8a is a 64-bit ARM Android ABI. “x128 infinite bit” is not a standard CPU architecture/Android ABI and cannot be used as a substitute.
10 TB+ refers to storage capacity, not RAM.

ANDROID BUILD PATH
Use Android Studio with a WebView wrapper or a framework such as Capacitor. Build the APK for the target device ABI. The HTML itself is not an APK; the archive does not include Android SDK, drivers, or a compiled APK.
