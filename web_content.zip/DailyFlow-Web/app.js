const $=id=>document.getElementById(id);
const translations={
 fa:{brand:"دستیار روزانه تو",today:"برنامه امروز",keepGoing:"قدم‌های کوچک، پیشرفت بزرگ.",done:"انجام‌شده",completed:"تکمیل‌شده",remaining:"باقی‌مانده",nextTask:"فعالیت بعدی",yourPlan:"برنامه تو",timeline:"زمان‌بندی امروز",addTask:"افزودن فعالیت",offlineNote:"اطلاعات روی همین دستگاه ذخیره می‌شود.",newTask:"فعالیت جدید",taskName:"عنوان فعالیت",startTime:"ساعت",category:"دسته‌بندی",work:"کار",study:"مطالعه",health:"سلامتی",personal:"شخصی",reminder:"یادآوری داخل برنامه",saveTask:"ذخیره فعالیت",reminderHint:"یادآوری مرورگر فقط وقتی صفحه باز باشد قابل اتکاست.",empty:"هنوز فعالیتی ثبت نکرده‌ای. اولین فعالیتت را اضافه کن!",markDone:"انجام شد",undo:"برگرداندن",delete:"حذف",saved:"فعالیت ذخیره شد",deleted:"فعالیت حذف شد",notifyTitle:"یادآوری DailyFlow",notifyDenied:"اجازه اعلان داده نشد یا مرورگر پشتیبانی نمی‌کند.",reminderNow:"زمان فعالیتت رسیده:"},
 en:{brand:"YOUR DAILY COMPANION",today:"TODAY'S PLAN",keepGoing:"Small steps, big progress.",done:"completed",completed:"Completed",remaining:"Remaining",nextTask:"Next activity",yourPlan:"YOUR PLAN",timeline:"Today's timeline",addTask:"Add activity",offlineNote:"Your data is saved on this device.",newTask:"New activity",taskName:"Activity title",startTime:"Time",category:"Category",work:"Work",study:"Study",health:"Health",personal:"Personal",reminder:"In-app reminder",saveTask:"Save activity",reminderHint:"Browser reminders are reliable only while this page stays open.",empty:"No activities yet. Add your first activity!",markDone:"Mark done",undo:"Undo",delete:"Delete",saved:"Activity saved",deleted:"Activity deleted",notifyTitle:"DailyFlow reminder",notifyDenied:"Notifications are unavailable or permission was denied.",reminderNow:"It's time for:"}
};
let lang=localStorage.getItem("df-lang")||"fa", theme=localStorage.getItem("df-theme")||"dark", tasks=JSON.parse(localStorage.getItem("df-tasks")||"[]"), fired=new Set();
const cats={work:"work",study:"study",health:"health",personal:"personal"};
function t(k){return translations[lang][k]||k}
function applyLang(){document.documentElement.lang=lang;document.documentElement.dir=lang==="fa"?"rtl":"ltr";document.querySelectorAll("[data-i18n]").forEach(el=>el.textContent=t(el.dataset.i18n));$("langBtn").textContent=lang==="fa"?"EN":"فا";$("taskTitle").placeholder=lang==="fa"?"مثلاً مطالعه":"e.g. Reading";render()}
function applyTheme(){document.body.dataset.theme=theme;$("themeBtn").title=theme;localStorage.setItem("df-theme",theme)}
function dateLabel(){let d=new Date();return new Intl.DateTimeFormat(lang==="fa"?"fa-IR":"en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"}).format(d)}
function save(){localStorage.setItem("df-tasks",JSON.stringify(tasks));render()}
function render(){
 $("dateText").textContent=dateLabel();
 tasks.sort((a,b)=>a.time.localeCompare(b.time));
 const done=tasks.filter(x=>x.done).length, total=tasks.length, pct=total?Math.round(done/total*100):0;
 $("progressNumber").textContent=pct+"%";$("progressRing").style.setProperty("--progress",pct+"%");
 $("doneCount").textContent=done;$("remainingCount").textContent=total-done;
 const now=new Date().toTimeString().slice(0,5), next=tasks.find(x=>!x.done&&x.time>=now);
 $("nextTime").textContent=next?next.time:"—";
 const list=$("taskList");list.innerHTML="";
 if(!total){list.innerHTML=`<div class="empty">${t("empty")}</div>`;return}
 tasks.forEach(task=>{
  const el=document.createElement("article");el.className="task"+(task.done?" done":"");
  const time=document.createElement("div");time.className="task-time";time.textContent=task.time;
  const info=document.createElement("div");const title=document.createElement("div");title.className="task-title";title.textContent=task.title;const meta=document.createElement("div");meta.className="task-meta";meta.textContent=t(cats[task.category]||"personal");info.append(title,meta);
  const actions=document.createElement("div");actions.className="task-actions";
  const check=document.createElement("button");check.className="round-btn"+(task.done?" checked":"");check.textContent=task.done?"✓":"○";check.title=task.done?t("undo"):t("markDone");check.onclick=()=>{task.done=!task.done;save()};
  const del=document.createElement("button");del.className="round-btn";del.textContent="×";del.title=t("delete");del.onclick=()=>{tasks=tasks.filter(x=>x.id!==task.id);save();toast(t("deleted"))};
  actions.append(check,del);el.append(time,info,actions);list.append(el);
 });
}
function toast(msg){let x=$("toast");x.textContent=msg;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2400)}
$("addBtn").onclick=()=>{$("taskForm").reset();$("taskTime").value=new Date().toTimeString().slice(0,5);$("taskDialog").showModal()};
$("closeDialog").onclick=()=>$("taskDialog").close();
$("taskForm").addEventListener("submit",e=>{e.preventDefault();let title=$("taskTitle").value.trim();if(!title)return;tasks.push({id:Date.now(),title,time:$("taskTime").value,category:$("taskCategory").value,reminder:$("taskReminder").checked,done:false});save();$("taskDialog").close();toast(t("saved"))});
$("langBtn").onclick=()=>{lang=lang==="fa"?"en":"fa";localStorage.setItem("df-lang",lang);applyLang()};
const themes=["dark","light","midnight","emerald"];$("themeBtn").onclick=()=>{theme=themes[(themes.indexOf(theme)+1)%themes.length];applyTheme();toast(theme)};
async function askNotifications(){if(!("Notification"in window))return false;let p=Notification.permission;if(p==="default")p=await Notification.requestPermission();return p==="granted"}
async function checkReminders(){const now=new Date().toTimeString().slice(0,5);for(const task of tasks){const key=task.id+":"+new Date().toDateString();if(task.reminder&&!task.done&&task.time===now&&!fired.has(key)){fired.add(key);if(await askNotifications())new Notification(t("notifyTitle"),{body:t("reminderNow")+" "+task.title});else toast(t("notifyDenied"))}}}
applyTheme();applyLang();render();setInterval(checkReminders,15000);
if("serviceWorker"in navigator && location.protocol!=="file:"){navigator.serviceWorker.register("./sw.js").catch(()=>{});}
