package com.hrp.aitrader;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Background scan scaffold. WorkManager runs periodically subject to Android battery
 * optimization and network availability; it is not an exact 15-minute alarm.
 * It only reports a generic scan result in this starter and deliberately avoids
 * issuing trade signals without validated OHLCV/security evidence.
 */
public class BackgroundScanWorker extends Worker {
    private static final String CHANNEL = "hrp_market_alerts";
    public BackgroundScanWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        try {
            String response = get("https://api.dexscreener.com/token-boosts/latest/v1");
            JSONArray arr = new JSONArray(response);
            int count = arr.length();
            if (count > 0) notifyUser("H.R.P AI TRADER 2026", "" + count + " رکورد کشف اولیه دریافت شد؛ این اعلان سیگنال خرید نیست و امنیت/نقدینگی تأیید نشده است.");
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }

    private String get(String address) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(12000);
        c.setReadTimeout(12000);
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        } finally { c.disconnect(); }
    }

    private void notifyUser(String title, String body) {
        Context ctx = getApplicationContext();
        NotificationManager manager = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(new NotificationChannel(CHANNEL, "هشدارهای بازار", NotificationManager.IMPORTANCE_DEFAULT));
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT);
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
