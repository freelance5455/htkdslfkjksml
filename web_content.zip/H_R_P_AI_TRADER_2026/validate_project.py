from pathlib import Path
import re, subprocess, sys
root = Path(__file__).resolve().parent
html = root / "H_R_P_AI_TRADER_2026.html"
source = html.read_text(encoding="utf-8")
scripts = "\n".join(re.findall(r"<script>(.*?)</script>", source, re.S))
jsfile = root / "_validate.js"
jsfile.write_text(scripts, encoding="utf-8")
ids = set(re.findall(r'\bid="([^"]+)"', source))
refs = set(re.findall(r"\$\('([^']+)'\)", scripts))
missing = sorted(refs - ids)
assert not missing, f"DOM IDs referenced but missing: {missing}"
assert "H.R.P AI TRADER 2026" in source
assert all(f'id="tab-{tab}"' in source for tab in ["overview", "hunter", "technical", "paper", "ledger", "risk", "macro", "alerts", "settings"])
subprocess.run(["node", "--check", str(jsfile)], check=True)
project = root / "HRP_AI_TRADER_Android"
assert (project / "app/src/main/AndroidManifest.xml").exists()
assert (project / "app/src/main/java/com/hrp/aitrader/MainActivity.java").exists()
assert (project / ".github/workflows/build-apk.yml").exists()
print(f"PASS: JavaScript syntax; {len(ids)} HTML IDs; {len(refs)} referenced IDs; no missing IDs; Android scaffold files found.")
jsfile.unlink(missing_ok=True)
