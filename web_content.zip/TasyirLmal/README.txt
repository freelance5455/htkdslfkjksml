Application « تسيير المال » : projet Android Studio (WebView)

1. Décompresser le zip.
2. Android Studio > File > Open > choisir le dossier TasyirLmal.
   Attendre la fin de « Gradle sync » (internet nécessaire la première fois).
   Si Android Studio propose de mettre à jour Gradle / le plugin Android, accepter.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   Le fichier est ici : app/build/outputs/apk/debug/app-debug.apk
4. Copier l'APK sur le téléphone, l'ouvrir et autoriser l'installation depuis cette source.

Le code de l'application est dans app/src/main/assets/index.html.
Pour changer quelque chose, modifier ce fichier puis refaire l'étape 3.
Les données restent sur le téléphone (stockage local de l'application).
