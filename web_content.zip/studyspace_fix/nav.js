(() => {
  'use strict';
  function initStudyspace(){
    const menu=document.getElementById('studyspaceMenu');
    if(menu&&!menu.dataset.bound){
      const trigger=menu.querySelector('summary'),close=menu.querySelector('.drawer-close'),scrim=menu.querySelector('.site-menu-scrim');
      const closeMenu=(focus=false)=>{menu.open=false;if(focus&&trigger)trigger.focus({preventScroll:true});};
      close?.addEventListener('click',()=>closeMenu(true));scrim?.addEventListener('click',()=>closeMenu(true));
      menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>closeMenu(false)));
      document.addEventListener('keydown',e=>{if(e.key==='Escape'&&menu.open){e.preventDefault();closeMenu(true);}if(e.key==='/'&&!/input|textarea|select/i.test(document.activeElement?.tagName||'')&&!e.ctrlKey&&!e.metaKey&&!e.altKey){e.preventDefault();location.href=window.StudyspaceEconomy?.featureUnlocked('search')?'tools.html#search':'shop.html#features';}});
      menu.dataset.bound='1';
    }
    if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)&&!window.__studyspaceSwRegistered){window.__studyspaceSwRegistered=true;window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js?v=18',{updateViaCache:'none'}).then(reg=>reg.update().catch(()=>{})).catch(err=>console.warn('Studyspace offline support unavailable:',err)));}
    let deferredPrompt=null;
    window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;});
    window.StudyspaceInstall={available:()=>!!deferredPrompt,install:async()=>{if(!deferredPrompt)return false;deferredPrompt.prompt();const result=await deferredPrompt.userChoice;deferredPrompt=null;return result?.outcome==='accepted';}};
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initStudyspace,{once:true});else initStudyspace();
})();