(() => {
  'use strict';
  const KEY = 'studyspace-homework-v1';
  const E = window.StudyspaceEconomy;
  const $ = id => document.getElementById(id);
  const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const localISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const dateLabel = iso => { const [y,m,d]=String(iso).split('-').map(Number); return new Date(y,m-1,d,12).toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'}); };
  const today = localISO();
  const requestedDate = new URLSearchParams(location.search).get('date');
  const date = document.body.dataset.page === 'day' && requestedDate && /^\d{4}-\d{2}-\d{2}$/.test(requestedDate) ? requestedDate : today;
  const countChallenges = [1,2,3,4,5].map(goal => ({id:`homework-count-${goal}`,scope:'count',goal,coins:25,title:`Complete ${goal} school homework${goal===1?'':'s'}`,desc:goal===1?'Mark at least one homework entry complete.':`Finish ${goal} separate homework entries today.`}));
  const timeGoals = [5,10,25,30,45,50,60,120,180];
  const timeChallenges = timeGoals.map(goal => ({id:`homework-minutes-${goal}`,scope:'minutes',goal,coins:50,title:`Record ${goal} minute${goal===1?'':'s'} of homework`,desc:`Log at least ${goal} total minutes across all school subjects today.`}));
  function safeLoad(){
    try { const saved=JSON.parse(localStorage.getItem(KEY)||'null');if(saved&&typeof saved==='object'&&saved.days&&typeof saved.days==='object')return saved; }
    catch(err){ console.warn('Homework log could not be read.',err); }
    return {schemaVersion:1,days:{}};
  }
  let data = safeLoad();
  function dayRecord(iso=date){
    if(!data.days[iso]||typeof data.days[iso]!=='object')data.days[iso]={entries:[],countClaims:[],minuteClaims:[]};
    const d=data.days[iso];
    if(!Array.isArray(d.entries))d.entries=[];
    if(!Array.isArray(d.countClaims))d.countClaims=[];
    if(!Array.isArray(d.minuteClaims))d.minuteClaims=[];
    return d;
  }
  function save(){
    try { localStorage.setItem(KEY,JSON.stringify(data));window.dispatchEvent(new CustomEvent('studyspace:homework-updated',{detail:{date}}));return true; }
    catch(err){console.error('Could not save schoolwork.',err);toast('Could not save schoolwork in this browser. Check available storage.');return false;}
  }
  function toast(message){ if(E?.notify)E.notify(message);else{const el=$('economyToast');if(el){el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),3000);}} }
  function balance(){ E?.updateWalletUI(); document.querySelectorAll('[data-study-coins]').forEach(el=>{el.textContent=Number(E?.getState().coins||0).toLocaleString('en-IN');}); }
  function formatMinutes(value){const mins=Math.max(0,Math.floor(Number(value)||0));const h=Math.floor(mins/60),m=mins%60;return h?`${h}h ${m}m`: `${mins} min`;}
  function totals(iso=date){const d=dayRecord(iso);return {entries:d.entries.length,completed:d.entries.filter(x=>x&&x.done).length,minutes:d.entries.reduce((sum,x)=>sum+Math.max(0,Math.floor(Number(x.minutes)||0)),0)};}
  function renderLog(){
    const list=$('homeworkLogList');if(!list)return;
    const d=dayRecord(date),metric=totals(date);
    const heading=$('homeworkDateTitle');if(heading)heading.textContent=`Schoolwork · ${dateLabel(date)}`;
    const count=$('homeworkEntryCount');if(count)count.textContent=`${metric.entries} entr${metric.entries===1?'y':'ies'}`;
    const completed=$('homeworkDoneCount');if(completed)completed.textContent=String(metric.completed);
    const time=$('homeworkTotalMinutes');if(time)time.textContent=formatMinutes(metric.minutes);
    const next=$('homeworkNextTime');if(next){const nextGoal=timeGoals.find(x=>metric.minutes<x);next.textContent=nextGoal?`${nextGoal} min target`:'All daily time targets met';}
    list.innerHTML='';
    if(!d.entries.length){list.innerHTML='<div class="homework-empty"><span>✦</span><strong>No schoolwork logged yet</strong><p>Add each assignment above with its subject and minutes, then mark it complete when you finish.</p></div>';return;}
    d.entries.slice().sort((a,b)=>(a.createdAt||0)-(b.createdAt||0)).forEach(entry=>{
      const row=document.createElement('article');row.className=`homework-entry ${entry.done?'homework-entry-done':''}`;row.dataset.homeworkEntry=entry.id;
      row.innerHTML=`<label class="homework-entry-check"><input type="checkbox" data-homework-done="${escapeHTML(entry.id)}" ${entry.done?'checked':''} aria-label="Mark ${escapeHTML(entry.title)} complete"><span></span></label><div class="homework-entry-main"><strong>${escapeHTML(entry.title)}</strong><div class="homework-entry-meta"><span class="homework-subject-tag">${escapeHTML(entry.subject)}</span><span class="homework-duration">◷ ${formatMinutes(entry.minutes)}</span>${entry.done?'<span class="homework-complete-label">Completed ✓</span>':'<span class="homework-pending-label">In progress</span>'}</div></div><button class="homework-delete" data-homework-delete="${escapeHTML(entry.id)}" type="button" aria-label="Delete homework entry" title="Delete entry">×</button>`;
      list.appendChild(row);
    });
    renderChallenges();
  }
  function renderChallenges(){
    const countList=$('homeworkCountChallenges'),timeList=$('homeworkTimeChallenges');if(!countList&&!timeList)return;
    const t=totals(today),d=dayRecord(today);
    const renderOne=(challenge,claimed,progress,goal,label)=>{
      const ready=progress>=goal;
      const status=claimed?'CLAIMED ✓':ready?'READY TO CLAIM':'IN PROGRESS';
      return `<article class="homework-challenge ${claimed?'quest-claimed':''} ${ready&&!claimed?'quest-ready':''}" data-challenge-id="${challenge.id}"><div class="homework-challenge-head"><span class="homework-challenge-icon">${challenge.scope==='count'?'✓':'◷'}</span><span class="quest-state ${claimed?'claimed':ready?'ready':'waiting'}">${status}</span></div><h3>${escapeHTML(challenge.title)}</h3><p>${escapeHTML(challenge.desc)}</p><div class="quest-progress-meta"><span>${Math.min(goal,progress)} / ${goal} ${label}</span><strong>+${challenge.coins} ◈</strong></div><div class="quest-progress-track"><span style="width:${Math.min(100,progress/goal*100)}%"></span></div>${claimed?'<button class="claim-button" type="button" disabled>Claimed today</button>':ready?`<button class="claim-button" type="button" data-claim-homework="${challenge.id}">Claim +${challenge.coins} ◈</button>`:'<button class="claim-button" type="button" disabled>Keep going</button>'}</article>`;
    };
    if(countList)countList.innerHTML=countChallenges.map(ch=>renderOne(ch,d.countClaims.includes(ch.id),t.completed,ch.goal,'homeworks')).join('');
    if(timeList)timeList.innerHTML=timeChallenges.map(ch=>renderOne(ch,d.minuteClaims.includes(ch.id),t.minutes,ch.goal,'minutes')).join('');
  }
  function addHomework(event){
    event.preventDefault();
    const title=$('homeworkTitle')?.value.trim(),subject=$('homeworkSubject')?.value,minutes=Number($('homeworkMinutes')?.value);
    if(!title||!subject||!Number.isInteger(minutes)||minutes<1||minutes>720){toast('Enter the homework, subject and a time from 1 to 720 minutes.');return;}
    const d=dayRecord(date);d.entries.push({id:`hw-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`,title,subject,minutes,done:false,createdAt:Date.now()});
    if(!save())return;
    $('homeworkForm').reset();$('homeworkSubject').value='Mathematics';renderLog();toast('Schoolwork added. All subject minutes are totalled together.');
  }
  function changeCompleted(id,done){const entry=dayRecord(date).entries.find(x=>x.id===id);if(!entry)return;entry.done=!!done;save();renderLog();}
  function deleteHomework(id){const d=dayRecord(date);const entry=d.entries.find(x=>x.id===id);if(!entry)return;if(!window.confirm(`Delete “${entry.title}” from this date’s schoolwork log?`))return;d.entries=d.entries.filter(x=>x.id!==id);save();renderLog();toast('Schoolwork entry deleted.');}
  function claimExtra(challengeId,button){
    const challenge=[...countChallenges,...timeChallenges].find(x=>x.id===challengeId);if(!challenge)return;
    const d=dayRecord(today),metric=totals(today),progress=challenge.scope==='count'?metric.completed:metric.minutes;
    const claims=challenge.scope==='count'?d.countClaims:d.minuteClaims;
    if(progress<challenge.goal){toast('Reach the task goal before claiming.');return;}
    if(claims.includes(challenge.id)){toast('Already claimed today.');return;}
    const card=button?.closest('.homework-challenge');card?.classList.add('quest-claiming');
    const result=E?.grantExtraCoins(`homework:${today}:${challenge.id}`,challenge.coins);
    if(!result?.ok&&!result?.already){card?.classList.remove('quest-claiming');toast(result?.message||'Could not award the extra coins.');return;}
    claims.push(challenge.id);if(!save())return;
    toast(result.already?'This reward was already paid. Your claim was synced.':`+${challenge.coins} extra Study Coins! This reward does not affect your level.`);
    setTimeout(()=>{renderChallenges();balance();},420);
  }
  function init(){
    if(!$('homeworkForm')&&!$('homeworkLogList'))return;
    if($('homeworkForm'))$('homeworkForm').addEventListener('submit',addHomework);
    $('homeworkLogList')?.addEventListener('change',event=>{const input=event.target.closest('[data-homework-done]');if(input)changeCompleted(input.dataset.homeworkDone,input.checked);});
    $('homeworkLogList')?.addEventListener('click',event=>{const button=event.target.closest('[data-homework-delete]');if(button)deleteHomework(button.dataset.homeworkDelete);});
    document.addEventListener('click',event=>{const button=event.target.closest('[data-claim-homework]');if(button)claimExtra(button.dataset.claimHomework,button);});
    window.addEventListener('studyspace:homework-updated',()=>{balance();renderLog();});
    window.addEventListener('studyspace:economy-updated',balance);
    window.addEventListener('storage',event=>{if(event.key===KEY){data=safeLoad();renderLog();}if(event.key==='studyspace-economy-v1')balance();});
    dayRecord(date);renderLog();balance();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
