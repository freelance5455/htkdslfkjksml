(() => {
  'use strict';
  const E=window.StudyspaceEconomy;
  if(!E)return;
  const $=id=>document.getElementById(id);
  let deferRewardRefreshUntil=0;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const localDate=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
  const monthKey=()=>localDate().slice(0,7);
  const planner=()=>{try{const p=JSON.parse(localStorage.getItem('studyspace-planner-v1')||'null');return p&&p.days&&typeof p.days==='object'?p:{days:{}};}catch(_){return {days:{}};}};
  const tools=()=>{try{const d=JSON.parse(localStorage.getItem('studyspace-tools-v1')||'null');return d&&typeof d==='object'?d:{};}catch(_){return {};}};
  const dailyMetrics=()=>{
    const p=planner(),t=tools(),day=p.days?.[localDate()]||{},tasks=Array.isArray(day.tasks)?day.tasks:[],done=tasks.filter(x=>x&&x.done).length;
    const focusSecs=(Array.isArray(t.focusSessions)?t.focusSessions:[]).filter(s=>s&&s.date===localDate()).reduce((n,s)=>n+Math.max(0,Number(s.seconds)||((Number(s.minutes)||0)*60)),0);
    return {done,focusSecs,focusMins:Math.floor(focusSecs/60)};
  };
  const monthlyMetrics=()=>{
    const p=planner(),t=tools(),prefix=monthKey()+'-',entries=Object.entries(p.days||{}).filter(([iso])=>iso.startsWith(prefix));
    let productiveDays=0,completedTasks=0,studyMinutes=0;
    entries.forEach(([,d])=>{if(!d)return;if(d.status==='productive')productiveDays++;(Array.isArray(d.tasks)?d.tasks:[]).forEach(task=>{if(task&&task.done)completedTasks++;});(Array.isArray(d.studySessions)?d.studySessions:[]).forEach(s=>{studyMinutes+=Math.max(0,Number(s.minutes)||0);});});
    // Some focus sessions may exist before planner logging was introduced; use max per month to avoid double-counting them.
    const focusMins=(Array.isArray(t.focusSessions)?t.focusSessions:[]).filter(s=>s&&String(s.date||'').startsWith(prefix)).reduce((n,s)=>n+Math.max(0,Number(s.minutes)||0),0);
    studyMinutes=Math.max(studyMinutes,focusMins);
    return {productiveDays,completedTasks,studyMinutes};
  };
  function levelMult(level){return Math.max(1,Math.ceil(Math.min(99,level)/5));}
  function dailyTasks(){
    const m=dailyMetrics(),state=E.getState(),period=localDate(),claims=Array.isArray(state.dailyClaims?.[period])?state.dailyClaims[period]:[];
    const defs=[
      {id:'focus-5',kind:'focus',title:'Start a 5-minute focus session',desc:'Complete at least 5 minutes in Pomodoro & Focus.',base:50,goal:300,progress:m.focusSecs,ready:m.focusSecs>=300,progressLabel:`${Math.min(5,Math.floor(m.focusSecs/60))} / 5 min`},
      {id:'focus-15',kind:'focus',title:'Complete a 15-minute focus session',desc:'Reach 15 total focused minutes today. The 5-minute milestone still counts.',base:100,goal:900,progress:m.focusSecs,ready:m.focusSecs>=900,progressLabel:`${Math.min(15,Math.floor(m.focusSecs/60))} / 15 min`},
      {id:'focus-30',kind:'focus',title:'Reach 30 focused minutes',desc:'Build on your focus time and reach 30 minutes today.',base:200,goal:1800,progress:m.focusSecs,ready:m.focusSecs>=1800,progressLabel:`${Math.min(30,Math.floor(m.focusSecs/60))} / 30 min`},
      {id:'focus-60',kind:'focus',title:'Reach 60 focused minutes',desc:'Complete one hour of focused study time today.',base:400,goal:3600,progress:m.focusSecs,ready:m.focusSecs>=3600,progressLabel:`${Math.min(60,Math.floor(m.focusSecs/60))} / 60 min`},
      ...Array.from({length:8},(_,i)=>{const n=i+1;return {id:`calendar-tasks-${n}`,kind:'tasks',threshold:n,title:`Complete ${n} calendar task${n===1?'':'s'} today`,desc:n===1?'Finish one task on your day planner.':`Finish ${n} tasks today. Earlier milestones count too.`,base:25*n,goal:n,progress:m.done,ready:m.done>=n,progressLabel:`${Math.min(n,m.done)} / ${n} tasks`};})
    ];
    // Every level after Level 1 adds another study challenge, up to 12 extra level challenges.
    const levelChallengeCount=Math.min(12,Math.max(0,state.level-1));
    for(let i=1;i<=levelChallengeCount;i++){
      const goalMins=60+i*15;defs.push({id:`level-focus-${i}`,kind:'focus',title:`Level challenge: reach ${goalMins} focused minutes`,desc:`A higher-level daily challenge. Record ${goalMins} focused minutes today.`,base:150+i*50,goal:goalMins*60,progress:m.focusSecs,ready:m.focusSecs>=goalMins*60,progressLabel:`${Math.min(goalMins,Math.floor(m.focusSecs/60))} / ${goalMins} min`});
    }
    // Claimed daily tasks fade away; a new progressive focus challenge takes each claimed task's place.
    // IDs are stable for the date, so refreshing cannot duplicate a payout.
    for(let i=1;i<=claims.length;i++){
      const goalMins=60+i*5;defs.push({id:`bonus-focus-${i}`,kind:'focus',title:`Bonus challenge: ${goalMins} focused minutes`,desc:`Keep going: reach ${goalMins} total focused minutes today.`,base:75+Math.min(300,i*10),goal:goalMins*60,progress:m.focusSecs,ready:m.focusSecs>=goalMins*60,progressLabel:`${Math.min(goalMins,Math.floor(m.focusSecs/60))} / ${goalMins} min`});
    }
    const mult=levelMult(state.level);return defs.map(x=>({...x,claimed:claims.includes(x.id),coins:x.base*mult}));
  }
  const monthlyDefs=[
    {id:'productive-15',title:'Mark 15 days as Productive',desc:'Use the day check-in on 15 days this month.',field:'productiveDays',goal:15,weight:1},
    {id:'productive-20',title:'Mark 20 days as Productive',desc:'Build a helpful rhythm across 20 days.',field:'productiveDays',goal:20,weight:1.15},
    {id:'productive-25',title:'Mark 25 days as Productive',desc:'Check in as Productive on 25 days.',field:'productiveDays',goal:25,weight:1.3},
    {id:'calendar-25',title:'Complete 25 calendar tasks',desc:'Finish 25 tasks in your day planner this month.',field:'completedTasks',goal:25,weight:1.1},
    {id:'calendar-50',title:'Complete 50 calendar tasks',desc:'Finish 50 tasks in your day planner this month.',field:'completedTasks',goal:50,weight:1.4},
    {id:'study-5-hours',title:'Record 5 hours of study',desc:'Log 300 study minutes this month.',field:'studyMinutes',goal:300,weight:1.2},
    {id:'study-20-hours',title:'Record 20 hours of study',desc:'Log 1,200 study minutes this month.',field:'studyMinutes',goal:1200,weight:1.67},
    {id:'study-10-hours',title:'Study for 10 hours this month',desc:'Record 600 focused study minutes this month.',field:'studyMinutes',goal:600,weight:1.35},
    {id:'study-30-hours',title:'Study for 30 hours this month',desc:'Record 1,800 focused study minutes this month.',field:'studyMinutes',goal:1800,weight:2}
  ];
  function monthlyReward(level,weight){const scaled=5000+Math.round((Math.max(1,Math.min(99,level))-1)*(25000/98));return Math.min(50000,Math.round(scaled*weight));}
  function levelReq(level){return E.levelRequirement(level);}
  function renderRewards(){
    const state=E.getState(),mult=levelMult(state.level),daily=dailyTasks(),mMetrics=monthlyMetrics(),mState=E.getState(),period=monthKey(),claimedMonth=Array.isArray(mState.monthlyClaims?.[period])?mState.monthlyClaims[period]:[];
    if(!$('dailyQuestList'))return;
    $('rewardCoins').textContent=state.coins.toLocaleString('en-IN');$('rewardLevelEmblem').textContent=state.level;$('rewardLevelTitle').textContent=`Level ${state.level} · ${state.level<5?'Starter':state.level<20?'Focus Builder':state.level<50?'Study Strategist':state.level<80?'Master Learner':'Legendary Scholar'}`;
    const req=levelReq(state.level),progress=Math.min(req,state.claimedInLevel);$('levelTaskHint').textContent=state.level>=99?'You reached the maximum level. Keep claiming tasks to earn Study Coins.':`Claim ${Math.max(0,req-progress)} more reward${req-progress===1?'':'s'} to reach Level ${state.level+1}.`;$('levelProgressText').textContent=`${progress} / ${req} claims`; $('levelProgressFill').style.width=`${req?progress/req*100:100}%`;
    const claimedToday=Array.isArray(state.dailyClaims?.[localDate()])?state.dailyClaims[localDate()]:[];const dailySlots=Math.max(12,daily.length-claimedToday.length);$('dailyTaskProgress').textContent=`${claimedToday.length} reward${claimedToday.length===1?'':'s'} claimed today`;$('dailyTaskProgressFill').style.width=`${Math.min(100,claimedToday.length/dailySlots*100)}%`;
    const list=$('dailyQuestList');list.innerHTML='';daily.filter(task=>!task.claimed).forEach((task,index)=>{
      const card=document.createElement('article');card.className=`quest-card ${task.claimed?'quest-claimed':''} ${task.ready&&!task.claimed?'quest-ready':''}`;
      const tag=task.claimed?'<span class="quest-state claimed">CLAIMED ✓</span>':task.ready?'<span class="quest-state ready">READY TO CLAIM</span>':'<span class="quest-state waiting">IN PROGRESS</span>';
      const action=task.claimed?'<button type="button" class="claim-button" disabled>Claimed</button>':task.ready?`<button type="button" class="claim-button" data-claim-daily="${task.id}">Claim +${task.coins.toLocaleString('en-IN')} ◈</button>`:'<button type="button" class="claim-button" disabled>Not yet</button>';
      card.innerHTML=`<div class="quest-card-top"><span class="quest-number">${String(index+1).padStart(2,'0')}</span>${tag}</div><h3>${esc(task.title)}</h3><p>${esc(task.desc)}</p><div class="quest-progress-meta"><span>${esc(task.progressLabel)}</span><strong>+${task.coins.toLocaleString('en-IN')} ◈</strong></div><div class="quest-progress-track"><span style="width:${task.kind==='focus'?Math.min(100,task.progress/task.goal*100):Math.min(100,task.progress/task.goal*100)}%"></span></div>${action}`;list.appendChild(card);
    });
    const mm=$('monthlyQuestList');mm.innerHTML='';monthlyDefs.forEach((task,index)=>{
      const value=mMetrics[task.field],ready=value>=task.goal,claimed=claimedMonth.includes(task.id),reward=monthlyReward(state.level,task.weight),formatted=task.field==='studyMinutes'?`${Math.floor(value/60)}h ${value%60}m / ${task.goal/60}h`:`${Math.min(task.goal,value)} / ${task.goal}`;
      const card=document.createElement('article');card.className=`monthly-quest-card ${claimed?'quest-claimed':''} ${ready&&!claimed?'quest-ready':''}`;
      card.innerHTML=`<div class="monthly-mission-top"><span class="mission-symbol">${['◷','✦','☼','✓','✧','◈','✹','⌛','★'][index]}</span><span class="quest-state ${claimed?'claimed':ready?'ready':'waiting'}">${claimed?'CLAIMED ✓':ready?'READY TO CLAIM':'IN PROGRESS'}</span></div><h3>${esc(task.title)}</h3><p>${esc(task.desc)}</p><div class="quest-progress-meta"><span>${esc(formatted)}</span><strong>+${reward.toLocaleString('en-IN')} ◈</strong></div><div class="quest-progress-track"><span style="width:${Math.min(100,value/task.goal*100)}%"></span></div>${claimed?'<button class="claim-button" disabled>Claimed this month</button>':ready?`<button class="claim-button" data-claim-monthly="${task.id}">Claim +${reward.toLocaleString('en-IN')} ◈</button>`:'<button class="claim-button" disabled>Keep going</button>'}`;mm.appendChild(card);
    });
    const roadmap=$('levelRoadmap');roadmap.innerHTML='';const from=Math.max(1,state.level-1),to=Math.min(99,Math.max(state.level+3,state.level));for(let level=from;level<=Math.min(99,from+5);level++){const item=document.createElement('div');item.className=`roadmap-step ${level===state.level?'current':''} ${level<state.level?'completed':''}`;item.innerHTML=`<span>${level<state.level?'✓':level}</span><strong>Level ${level}</strong><small>${level<state.level?'Completed':level===state.level?`${progress}/${req} claims`:`${levelReq(level)} claims to advance`}</small>`;roadmap.appendChild(item);}
    E.updateWalletUI();
  }
  function claimDaily(id,button){const task=dailyTasks().find(t=>t.id===id);if(!task||!task.ready){E.notify('Complete the task goal before claiming this reward.');return;}if(task.claimed){E.notify('This daily task has already been claimed.');return;}button?.closest('.quest-card')?.classList.add('quest-claiming');deferRewardRefreshUntil=Date.now()+420;const result=E.taskClaim('daily',id,task.coins);if(!result.ok){deferRewardRefreshUntil=0;E.notify(result.message||'Could not claim that reward.');renderRewards();return;}E.notify(`+${result.coins.toLocaleString('en-IN')} Study Coins claimed!${result.levelUps?.length?` Level up: ${result.levelUps.join(' → ')}!`:''} A new challenge has appeared.`);setTimeout(()=>{deferRewardRefreshUntil=0;renderRewards();},420);}
  function claimMonthly(id){const task=monthlyDefs.find(t=>t.id===id);if(!task)return;const metrics=monthlyMetrics();if(metrics[task.field]<task.goal){E.notify('This monthly mission is not complete yet.');return;}const state=E.getState(),period=monthKey(),already=Array.isArray(state.monthlyClaims?.[period])&&state.monthlyClaims[period].includes(id);if(already){E.notify('This mission has already been claimed this month.');return;}const result=E.taskClaim('monthly',id,monthlyReward(state.level,task.weight));if(!result.ok){E.notify(result.message||'Could not claim that mission.');return;}E.notify(`Monthly mission claimed: +${result.coins.toLocaleString('en-IN')} Study Coins!${result.levelUps?.length?` Level up: ${result.levelUps.join(' → ')}!`:''}`);renderRewards();}

  const shopMeta={
    themes:{eyebrow:'THEME COLLECTION',title:'Find your atmosphere.',description:'Themes change the palette across Studyspace. The five ultra-premium character themes use full-screen backgrounds; switch on Translucent Backgrounds to see the artwork through glass panels.'},
    logos:{eyebrow:'APP IDENTITY',title:'Choose your mark.',description:'Logo purchases change the mark across the website and app manifest.'},
    features:{eyebrow:'PERMANENT TOOL ACCESS',title:'Unlock your study toolkit.',description:'One purchase permanently unlocks that feature in this browser using Study Coins.'},
    months:{eyebrow:'EXPAND YOUR CALENDAR',title:'Unlock the months you need.',description:'October–December 2026 are included. Unlock each 2027 month individually with Study Coins.'},
    font:{eyebrow:'PREMIUM TYPOGRAPHY',title:'Choose your reading mood.',description:'Buy premium aesthetic fonts. They change the typography across Studyspace and remain owned after refresh.'},
    timerSkin:{eyebrow:'FOCUS & POMODORO SKINS',title:'Style your focus sessions.',description:'Six cosmetic skins change the timer and focus card appearance without changing timer logic.'},
    analyticsSkin:{eyebrow:'ANALYTICS SKINS',title:'Make your progress reports yours.',description:'Six cosmetic skins recolor report cards and chart surfaces only; your existing analytics data stays unchanged.'},
    flashcardSkin:{eyebrow:'FLASHCARD SKINS',title:'Give revision cards a look.',description:'Six cosmetic skins style revision cards and quiz surfaces; no new study feature or learning data is added.'},
    timetableSkin:{eyebrow:'WEEKLY PLANNER SKINS',title:'Give your weekly planner a new look.',description:'Six skins restyle the weekday selector, weekly planner panel and saved schedule rows—without changing your timetable data.'}
  };
  let currentTab='themes';
  function shopCard({type,id,name,desc,price,icon,owned,applied,preview,extra=''}){
    let button='';
    if(owned){if(applied){button='<button class="shop-action applied" disabled>Applied ✓</button>';}else if(type==='theme'){button=`<button class="shop-action" data-apply-theme="${id}">Apply</button>`;}else if(type==='logo'){button=`<button class="shop-action" data-apply-logo="${id}">Apply</button>`;}else{button=`<button class="shop-action" data-apply-shop="${type}" data-apply-id="${id}">Apply</button>`;}}
    else button=`<button class="shop-action" data-buy-type="${type}" data-buy-id="${id}">Purchase <span>◈ ${Number(price).toLocaleString('en-IN')}</span></button>`;
    const status=owned?`<span class="shop-item-status ${applied?'applied':'owned'}">${applied?'CURRENTLY APPLIED':'OWNED'}</span>`:`<span class="shop-item-status ${price>=10000?'legendary-price':'coin-price'}">${price.toLocaleString('en-IN')} ◈</span>`;
    return `<article class="shop-item-card ${applied?'shop-item-applied':''}" ${extra}><div class="shop-item-visual ${preview?.className||''}" ${preview?.style?`style="${preview.style}"`:''}>${preview?.content||`<span>${esc(icon||'✦')}</span>`}<i></i><b></b></div><div class="shop-item-body"><div class="shop-item-title-row"><h3>${esc(name)}</h3>${status}</div><p>${esc(desc)}</p>${button}</div></article>`;
  }
  function renderShop(){
    if(!$('shopGrid'))return;const state=E.getState(),grid=$('shopGrid'),meta=shopMeta[currentTab];$('shopEyebrow').textContent=meta.eyebrow;$('shopCategoryTitle').textContent=meta.title;$('shopCategoryDescription').textContent=meta.description;
    document.querySelectorAll('[data-shop-tab]').forEach(b=>b.classList.toggle('active',b.dataset.shopTab===currentTab));
    $('shopCoins').textContent=state.coins.toLocaleString('en-IN');
    const currentTheme=E.themes.find(t=>t.id===state.selectedTheme);const currentLogo=E.logos.find(l=>l.id===state.selectedLogo);$('activeThemeName').textContent=currentTheme?.name||'Midnight Lavender';$('activeLogoName').textContent=`${currentLogo?.name||'Classic Studyspace'} logo`;
    const transparencyButton=$('themeTransparencyToggle');if(transparencyButton){transparencyButton.setAttribute('aria-pressed',state.transparencyEnabled?'true':'false');transparencyButton.classList.toggle('active',state.transparencyEnabled);transparencyButton.textContent=state.transparencyEnabled?'Translucent backgrounds: ON':'Translucent backgrounds: OFF';}
    const transparencyStatus=$('themeTransparencyStatus');if(transparencyStatus)transparencyStatus.textContent=state.transparencyEnabled?'Glass effect is enabled across all themes and pages.':'Glass effect is off; normal solid panel surfaces are used.';
    let items=[];
    if(currentTab==='themes')items=E.themes.map(t=>shopCard({type:'theme',id:t.id,name:t.name,desc:t.desc,price:t.price,icon:t.icon,owned:state.ownedThemes.includes(t.id),applied:state.selectedTheme===t.id,preview:{className:`preview-theme-${t.palette} ${['web-hero','arc-armour','panther-veil','naruto-flame','anime-neon'].includes(t.palette)?'preview-character-theme':''}`,content:`<span>${esc(t.icon)}</span><small>${esc(t.name.toUpperCase())}</small>`}}));
    if(currentTab==='logos')items=E.logos.map(l=>shopCard({type:'logo',id:l.id,name:l.name,desc:l.desc,price:l.price,icon:l.glyph,owned:state.ownedLogos.includes(l.id),applied:state.selectedLogo===l.id,preview:{className:`preview-logo preview-logo-${l.id}`,content:`<span>${esc(l.glyph)}</span>`}}));
    if(currentTab==='features')items=Object.entries(E.features).map(([id,f])=>shopCard({type:'feature',id,name:f.name,desc:id==='flashcards'?'Build personal flashcards, revise with spaced repetition and run quick quizzes.':id==='exams'?'Create exam dates and use a live countdown with preparation lists.':'Search tasks, notes, chapters, exams and saved learning materials in one place.',price:f.price,icon:id==='flashcards'?'✧':id==='exams'?'⌁':'⌕',owned:state.unlockedFeatures.includes(id),applied:state.unlockedFeatures.includes(id),preview:{className:`preview-feature-${id}`,content:`<span>${id==='flashcards'?'✧':id==='exams'?'⌁':'⌕'}</span><small>STUDY TOOL</small>`}}));
    if(currentTab==='months')items=E.months.map(m=>shopCard({type:'month',id:m.id,name:m.name,desc:`Unlock the full month view and open its daily planner pages.`,price:m.price,icon:'▦',owned:state.unlockedMonths.includes(m.id),applied:false,preview:{className:'preview-month',content:`<span>${Number(m.id.slice(5))}</span><small>2027</small>`}}));
    if(E.shopCatalogs?.[currentTab]){
      const cfg=E.shopState[currentTab],base=E.baseSkins[currentTab],catalog=[base,...E.shopCatalogs[currentTab]];
      items=catalog.map(item=>{
        const owned=state[cfg.owned].includes(item.id),applied=state[cfg.selected]===item.id;
        const isFont=currentTab==='font';
        const previewContent=isFont?`<span style="font-family:'${esc(item.family||'Inter')}',sans-serif">Aa</span><small>${esc(item.family||'System')}</small>`:`<span>${esc(item.icon||'✦')}</span><small>${esc(item.name.toUpperCase())}</small>`;
        return shopCard({type:currentTab,id:item.id,name:item.name,desc:item.desc,price:item.price,icon:item.icon||'Aa',owned,applied,preview:{className:`preview-skin preview-${item.id}`,content:previewContent}});
      });
    }
    grid.innerHTML=items.join('');E.applyBranding();
  }
  function setShopTab(tab){if(!shopMeta[tab])return;currentTab=tab;renderShop();}
  function setupShop(){if(!$('shopGrid'))return;const params=new URLSearchParams(location.search);const queryTab=params.get('tab');const hash=location.hash.replace('#','');currentTab=shopMeta[queryTab]?queryTab:shopMeta[hash]?hash:'themes';if(hash==='features')currentTab='features';if(hash==='months')currentTab='months';document.querySelectorAll('[data-shop-tab]').forEach(b=>b.addEventListener('click',()=>{const tab=b.dataset.shopTab;setShopTab(tab);history.replaceState(null,'',`#${tab}`);}));$('shopGrid').addEventListener('click',event=>{const buy=event.target.closest('[data-buy-type]');if(buy){const type=buy.dataset.buyType,id=buy.dataset.buyId;const res=E.buy(type,id);if(!res.ok){E.notify(res.message||'Purchase failed.');return;}if(type==='feature'&&window.StudyspaceToolsApplyLocks)window.StudyspaceToolsApplyLocks();E.notify(res.already?'Already owned.':type==='feature'?`${res.item.name} unlocked!`:type==='theme'?`${res.item.name} purchased and applied!`:type==='logo'?`${res.item.name} logo purchased and applied!`:E.shopCatalogs?.[type]?`${res.item.name} purchased and applied!`:`${res.item.name} calendar month unlocked!`);renderShop();return;}
      // Resolve specific theme/logo actions before generic skin actions. This also
      // makes failures explicit instead of showing a misleading generic style error.
      const t=event.target.closest('button[data-apply-theme]');if(t){const id=t.dataset.applyTheme;const ok=!!id&&E.applyTheme(id);if(ok){renderShop();E.notify('Theme applied across Studyspace.');}else{E.refresh();renderShop();E.notify('Could not apply theme. Check that it is owned and try refreshing the page.');}return;}
      const l=event.target.closest('button[data-apply-logo]');if(l){const id=l.dataset.applyLogo;const ok=!!id&&E.applyLogo(id);if(ok){renderShop();E.notify('Logo applied across Studyspace.');}else{E.refresh();renderShop();E.notify('Could not apply logo. Check that it is owned and try refreshing the page.');}return;}
      const generic=event.target.closest('button[data-apply-shop]');if(generic){const type=generic.dataset.applyShop,id=generic.dataset.applyId;if(type&&id&&E.applyShopItem(type,id)){renderShop();E.notify('Style applied across Studyspace.');}else{E.refresh();renderShop();E.notify('Could not apply that skin. Check that it is owned and try refreshing the page.');}return;}
    });
    $('themeTransparencyToggle')?.addEventListener('click',()=>{const next=!E.getState().transparencyEnabled;if(E.setTransparency(next)){renderShop();E.notify(next?'Translucent glass backgrounds enabled.':'Translucent backgrounds turned off.');}});
    renderShop();}
  function initRewards(){if(!$('dailyQuestList'))return;renderRewards();$('dailyQuestList').addEventListener('click',e=>{const b=e.target.closest('[data-claim-daily]');if(b)claimDaily(b.dataset.claimDaily,b);});$('monthlyQuestList').addEventListener('click',e=>{const b=e.target.closest('[data-claim-monthly]');if(b)claimMonthly(b.dataset.claimMonthly);});window.addEventListener('studyspace:economy-updated',()=>{if(Date.now()>=deferRewardRefreshUntil)renderRewards();});window.addEventListener('studyspace:planner-updated',renderRewards);}
  function bindStorageRefresh(){window.addEventListener('storage',e=>{if(['studyspace-economy-v1','studyspace-planner-v1','studyspace-tools-v1'].includes(e.key)){E.refresh();renderRewards();renderShop();}});}
  document.addEventListener('DOMContentLoaded',()=>{setupShop();initRewards();bindStorageRefresh();});
  if(document.readyState!=='loading'){setupShop();initRewards();bindStorageRefresh();}
})();
