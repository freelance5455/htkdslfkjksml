(() => {
  'use strict';
  const KEY = 'studyspace-economy-v1';
  const TOOLS_KEY = 'studyspace-tools-v1';
  const PLANNER_KEY = 'studyspace-planner-v1';
  const FEATURES = {
    flashcards: { name: 'Flashcards & Quiz Lab', price: 500 },
    exams: { name: 'Exam Countdown', price: 750 },
    search: { name: 'Global Search', price: 1000 },
    timetable: { name: 'Weekly Timetable', price: 400 }
  };
  const THEMES = [
    { id:'midnight', name:'Midnight Lavender', desc:'The original calm navy and lavender look.', price:0, palette:'midnight', icon:'✦', category:'classic', owned:true },
    { id:'ember-orange', name:'Ember Orange', desc:'Warm orange accents over deep charcoal.', price:500, palette:'ember-orange', icon:'☼', category:'classic' },
    { id:'cosmic-ember', name:'Cosmic Ember', desc:'Burnt orange, starlight and deep space.', price:1500, palette:'cosmic-ember', icon:'✺', category:'classic' },
    { id:'violet-cool', name:'Violet Cool', desc:'A polished violet and indigo atmosphere.', price:2000, palette:'violet-cool', icon:'◈', category:'classic' },
    { id:'green-cool', name:'Green Cool', desc:'Fresh emerald highlights and cool dark panels.', price:2500, palette:'green-cool', icon:'❋', category:'classic' },
    { id:'professional-slate', name:'Professional Slate', desc:'Quiet blue-grey surfaces and crisp details.', price:3500, palette:'professional-slate', icon:'▦', category:'professional' },
    { id:'aurora', name:'Aurora Glass', desc:'Teal and mint with a night-sky finish.', price:4000, palette:'aurora', icon:'✧', category:'professional' },
    { id:'celestial-anime', name:'Celestial Premium', desc:'A starfield-inspired premium purple-blue atmosphere.', price:5000, palette:'celestial-anime', icon:'✧', category:'special' },
    { id:'legendary-cosmos', name:'Legendary Cosmos', desc:'The highest-tier non-character gold-violet cosmic edition.', price:50000, palette:'legendary-cosmos', icon:'✹', category:'legendary' },
    { id:'web-hero', name:'Spider-Man • City Swing', desc:'Premium city-swing background using the Spider-Man reference image you supplied. The theme artwork stays behind translucent panels.', price:200000, palette:'web-hero', icon:'✳', category:'character-legendary' },
    { id:'arc-armour', name:'Iron Man • Arc Reactor Armor', desc:'Red-and-gold powered-armor aesthetic with a bright reactor and dynamic armor artwork.', price:500000, palette:'arc-armour', icon:'◉', category:'character-legendary' },
    { id:'panther-veil', name:'Black Panther • Violet Sentinel', desc:'A purple night-sky background using the Black Panther reference image you supplied.', price:800000, palette:'panther-veil', icon:'♜', category:'character-legendary' },
    { id:'naruto-flame', name:'Naruto • Shinobi Rise', desc:'Orange-and-black shinobi background using the Naruto reference image you supplied.', price:1200000, palette:'naruto-flame', icon:'☯', category:'character-legendary' },
    { id:'anime-neon', name:'Zenitsu • Thunder Flash', desc:'Golden lightning and dark-city background using the Zenitsu reference image you supplied.', price:2000000, palette:'anime-neon', icon:'⚡', category:'character-legendary' }
  ];
  const FONTS = [
    {id:'playfair',name:'Playfair Editorial',desc:'Elegant, bookish serif headings.',price:300,family:'Playfair Display',kind:'serif'},
    {id:'cinzel',name:'Cinzel Prestige',desc:'Regal lettering with refined character.',price:500,family:'Cinzel',kind:'serif'},
    {id:'quicksand',name:'Quicksand Soft',desc:'Rounded and gentle for a calm planner.',price:800,family:'Quicksand',kind:'sans'},
    {id:'poppins',name:'Poppins Studio',desc:'Modern geometric and clean.',price:1200,family:'Poppins',kind:'sans'},
    {id:'lora',name:'Lora Library',desc:'Warm editorial style for study notes.',price:1600,family:'Lora',kind:'serif'},
    {id:'outfit',name:'Outfit Modern',desc:'Crisp, premium contemporary lettering.',price:2000,family:'Outfit',kind:'sans'},
    {id:'dm-sans',name:'DM Sans Minimal',desc:'Polished, discreet and readable.',price:2500,family:'DM Sans',kind:'sans'},
    {id:'raleway',name:'Raleway Elegant',desc:'Fine lines and spacious headings.',price:3000,family:'Raleway',kind:'sans'},
    {id:'space-grotesk',name:'Space Grotesk',desc:'Futuristic but highly readable.',price:3500,family:'Space Grotesk',kind:'sans'},
    {id:'merriweather',name:'Merriweather Scholar',desc:'A classic book-inspired reading feel.',price:4000,family:'Merriweather',kind:'serif'},
    {id:'cormorant',name:'Cormorant Luxe',desc:'Airy, refined editorial typography.',price:4500,family:'Cormorant Garamond',kind:'serif'},
    {id:'manrope',name:'Manrope Signature',desc:'Smooth, balanced premium sans serif.',price:5000,family:'Manrope',kind:'sans'}
  ];
  const TIMER_SKINS = [
    {id:'timer-neon',name:'Neon Pulse',desc:'Purple glow rings and bright focus accents.',price:1000,icon:'◉'},
    {id:'timer-forest',name:'Forest Calm',desc:'Soft green focus timer appearance.',price:2000,icon:'❋'},
    {id:'timer-galaxy',name:'Galaxy Orbit',desc:'Cosmic gradients and an orbital ring.',price:3500,icon:'✦'},
    {id:'timer-amber',name:'Amber Focus',desc:'Warm amber and gold timer highlights.',price:5000,icon:'☼'},
    {id:'timer-aurora',name:'Aurora Flow',desc:'Teal, mint and glassy timer surfaces.',price:7500,icon:'✧'},
    {id:'timer-legend',name:'Legendary Focus',desc:'A premium violet-and-gold timer skin.',price:10000,icon:'✹'}
  ];
  const ANALYTICS_SKINS = [
    {id:'analytics-lavender',name:'Lavender Glass',desc:'Soft purple chart and insight surfaces.',price:500,icon:'▥'},
    {id:'analytics-ocean',name:'Ocean Metrics',desc:'Cool blue chart skin.',price:2500,icon:'≈'},
    {id:'analytics-emerald',name:'Emerald Data',desc:'Green-accented progress visuals.',price:7500,icon:'❋'},
    {id:'analytics-sunset',name:'Sunset Analytics',desc:'Warm coral and amber charts.',price:15000,icon:'☼'},
    {id:'analytics-aurora',name:'Aurora Insights',desc:'Teal gradients and luminous cards.',price:30000,icon:'✧'},
    {id:'analytics-royal',name:'Royal Observatory',desc:'Premium purple and gold report skin.',price:50000,icon:'✹'}
  ];
  const FLASHCARD_SKINS = [
    {id:'cards-paper',name:'Cream Paper',desc:'Warm paper-like revision cards.',price:500,icon:'▤'},
    {id:'cards-lavender',name:'Lavender Study',desc:'Lilac borders and smooth card surfaces.',price:2500,icon:'✧'},
    {id:'cards-neon',name:'Neon Recall',desc:'High-contrast neon review cards.',price:7500,icon:'⚡'},
    {id:'cards-cosmos',name:'Cosmic Recall',desc:'Deep-space cards with starry accents.',price:15000,icon:'✦'},
    {id:'cards-gold',name:'Scholar Gold',desc:'Elegant gold study-card treatment.',price:30000,icon:'♛'},
    {id:'cards-legendary',name:'Legendary Archive',desc:'The highest-tier collectible flashcard skin.',price:50000,icon:'✹'}
  ];
  const TIMETABLE_SKINS = [
    {id:'timetable-clean',name:'Clean Grid',desc:'Minimal schedule lines and spacing.',price:500,icon:'▦'},
    {id:'timetable-pastel',name:'Pastel Blocks',desc:'Soft pastel-looking timetable blocks.',price:2500,icon:'▧'},
    {id:'timetable-neon',name:'Neon Schedule',desc:'Glowing active-day accents.',price:7500,icon:'✧'},
    {id:'timetable-ocean',name:'Ocean Planner',desc:'Blue-green timetable surfaces.',price:15000,icon:'≈'},
    {id:'timetable-luxe',name:'Luxe Weekly',desc:'Refined amber and purple schedule style.',price:30000,icon:'♛'},
    {id:'timetable-legend',name:'Legendary Timetable',desc:'Premium gold-accented weekly layout.',price:50000,icon:'✹'}
  ];
  const SHOP_CATALOGS = {font:FONTS,timerSkin:TIMER_SKINS,analyticsSkin:ANALYTICS_SKINS,flashcardSkin:FLASHCARD_SKINS,timetableSkin:TIMETABLE_SKINS};
  const SHOP_STATE = {
    font:{owned:'ownedFonts',selected:'selectedFont',base:'system'},
    timerSkin:{owned:'ownedTimerSkins',selected:'selectedTimerSkin',base:'timer-default'},
    analyticsSkin:{owned:'ownedAnalyticsSkins',selected:'selectedAnalyticsSkin',base:'analytics-default'},
    flashcardSkin:{owned:'ownedFlashcardSkins',selected:'selectedFlashcardSkin',base:'cards-default'},
    timetableSkin:{owned:'ownedTimetableSkins',selected:'selectedTimetableSkin',base:'timetable-default'}
  };
  const BASE_SKINS = {
    font:{id:'system',name:'System Minimal',desc:'Your original Studyspace font.',price:0,family:'Inter',kind:'sans'},
    timerSkin:{id:'timer-default',name:'Original Timer',desc:'The original timer appearance.',price:0,icon:'◷'},
    analyticsSkin:{id:'analytics-default',name:'Original Analytics',desc:'The original analytics appearance.',price:0,icon:'▥'},
    flashcardSkin:{id:'cards-default',name:'Original Flashcards',desc:'The original flashcard appearance.',price:0,icon:'▤'},
    timetableSkin:{id:'timetable-default',name:'Original Timetable',desc:'The original timetable appearance.',price:0,icon:'▦'}
  };
  const LOGOS = [
    { id:'classic', name:'Classic Studyspace', desc:'The original S mark.', price:0, glyph:'S', owned:true },
    { id:'crescent', name:'Crescent', desc:'A quiet moon-inspired symbol.', price:500, glyph:'☾' },
    { id:'crystal', name:'Crystal', desc:'Clean geometric crystal mark.', price:1000, glyph:'◆' },
    { id:'orbit', name:'Orbit', desc:'A minimal orbital emblem.', price:2000, glyph:'◉' },
    { id:'phoenix', name:'Phoenix Spark', desc:'A bright, original rising-spark emblem.', price:5000, glyph:'✦' },
    { id:'webhero', name:'Web-Slinger Emblem', desc:'Original web-inspired geometric mark.', price:10000, glyph:'✳' },
    { id:'arctech', name:'Arc-Tech Emblem', desc:'Original reactor-inspired geometric mark.', price:15000, glyph:'◈' },
    { id:'anime', name:'Anime Star', desc:'A vivid, original starburst mark.', price:25000, glyph:'✧' }
  ];
  const MONTHS = [
    {id:'2027-01',name:'January 2027',price:200},{id:'2027-02',name:'February 2027',price:200},{id:'2027-03',name:'March 2027',price:200},
    {id:'2027-04',name:'April 2027',price:500},{id:'2027-05',name:'May 2027',price:500},{id:'2027-06',name:'June 2027',price:500},
    {id:'2027-07',name:'July 2027',price:1000},{id:'2027-08',name:'August 2027',price:1000},{id:'2027-09',name:'September 2027',price:1000},
    {id:'2027-10',name:'October 2027',price:1500},{id:'2027-11',name:'November 2027',price:1500},{id:'2027-12',name:'December 2027',price:1500}
  ];
  const palettes = {
    'midnight': {color:'#b9a9ff',color2:'#7665e8',bg:'#0c1020'},
    'ember-orange': {color:'#ffb36b',color2:'#f08032',bg:'#100f16'},
    'cosmic-ember': {color:'#ff9e6c',color2:'#e75b3e',bg:'#100d18'},
    'violet-cool': {color:'#d0a8ff',color2:'#895be5',bg:'#100d20'},
    'green-cool': {color:'#78e0ad',color2:'#30a879',bg:'#091611'},
    'professional-slate': {color:'#b0c7e4',color2:'#648bbd',bg:'#0c1420'},
    'aurora': {color:'#73e7d5',color2:'#359fa8',bg:'#07191e'},
    'web-hero': {color:'#ff8294',color2:'#347bff',bg:'#140d17'},
    'arc-armour': {color:'#ffd07a',color2:'#ef6c5f',bg:'#17110e'},
    'anime-neon': {color:'#ffd85c',color2:'#8a70ec',bg:'#120b22'},
    'celestial-anime': {color:'#b9b5ff',color2:'#52b3eb',bg:'#0a1025'},
    'legendary-cosmos': {color:'#f5d58a',color2:'#9b80ff',bg:'#110d20'},
    'panther-veil': {color:'#c8a7ff',color2:'#7049d4',bg:'#0a0912'},
    'naruto-flame': {color:'#ffad54',color2:'#e5532d',bg:'#140e0b'}
  };
  const logoMap = Object.fromEntries(LOGOS.map(l=>[l.id,l]));
  const defaults = () => ({schemaVersion:3, coins:0, level:1, claimedInLevel:0, lifetimeCoinsEarned:0, lifetimeCoinsSpent:0,
    dailyClaims:{}, monthlyClaims:{}, unlockedFeatures:[], ownedThemes:['midnight'], selectedTheme:'midnight', ownedLogos:['classic'], selectedLogo:'classic',
    ownedFonts:['system'], selectedFont:'system', ownedTimerSkins:['timer-default'], selectedTimerSkin:'timer-default',
    ownedAnalyticsSkins:['analytics-default'], selectedAnalyticsSkin:'analytics-default', ownedFlashcardSkins:['cards-default'], selectedFlashcardSkin:'cards-default',
    ownedTimetableSkins:['timetable-default'], selectedTimetableSkin:'timetable-default', transparencyEnabled:false,
    unlockedMonths:['2026-10','2026-11','2026-12'], purchaseLog:[], reminderLog:{}});
  function load(){
    try {
      const raw=localStorage.getItem(KEY); if(!raw) return defaults();
      const parsed=JSON.parse(raw); if(!parsed||typeof parsed!=='object'||Array.isArray(parsed)) return defaults();
      const d=defaults();
      d.coins=Math.max(0,Math.floor(Number(parsed.coins)||0)); d.level=Math.max(1,Math.min(99,Math.floor(Number(parsed.level)||1)));
      d.claimedInLevel=Math.max(0,Math.floor(Number(parsed.claimedInLevel)||0)); d.lifetimeCoinsEarned=Math.max(0,Math.floor(Number(parsed.lifetimeCoinsEarned)||0)); d.lifetimeCoinsSpent=Math.max(0,Math.floor(Number(parsed.lifetimeCoinsSpent)||0));
      for(const k of ['dailyClaims','monthlyClaims','reminderLog']) if(parsed[k]&&typeof parsed[k]==='object'&&!Array.isArray(parsed[k])) d[k]=parsed[k];
      for(const k of ['unlockedFeatures','ownedThemes','ownedLogos','unlockedMonths','purchaseLog','ownedFonts','ownedTimerSkins','ownedAnalyticsSkins','ownedFlashcardSkins','ownedTimetableSkins']) if(Array.isArray(parsed[k])) d[k]=parsed[k];
      d.transparencyEnabled=parsed.transparencyEnabled===true;
      d.ownedThemes=Array.from(new Set(['midnight',...d.ownedThemes.filter(x=>THEMES.some(t=>t.id===x))]));
      d.ownedLogos=Array.from(new Set(['classic',...d.ownedLogos.filter(x=>logoMap[x])]));
      for(const [type,cfg] of Object.entries(SHOP_STATE)){
        const catalog=[BASE_SKINS[type],...(SHOP_CATALOGS[type]||[])];
        const allowed=new Set(catalog.map(item=>item.id));
        d[cfg.owned]=Array.from(new Set([cfg.base,...(Array.isArray(d[cfg.owned])?d[cfg.owned]:[]).filter(x=>allowed.has(x))]));
        d[cfg.selected]=d[cfg.owned].includes(parsed[cfg.selected])?parsed[cfg.selected]:cfg.base;
      }
      d.unlockedFeatures=Array.from(new Set(d.unlockedFeatures.filter(x=>FEATURES[x])));
      d.unlockedMonths=Array.from(new Set(['2026-10','2026-11','2026-12',...d.unlockedMonths.filter(x=>MONTHS.some(m=>m.id===x))]));
      if(!d.ownedThemes.includes(parsed.selectedTheme)) d.selectedTheme='midnight'; else d.selectedTheme=parsed.selectedTheme;
      if(!d.ownedLogos.includes(parsed.selectedLogo)) d.selectedLogo='classic'; else d.selectedLogo=parsed.selectedLogo;
      d.schemaVersion=3; return d;
    } catch(err){ console.warn('Studyspace wallet could not be read; existing data was left untouched.',err); return defaults(); }
  }
  let state=load();
  function save(){
    try { localStorage.setItem(KEY,JSON.stringify(state)); updateWalletUI(); window.dispatchEvent(new CustomEvent('studyspace:economy-updated',{detail:{state:publicState()}})); return true; }
    catch(err){ console.error('Studyspace wallet save failed',err); return false; }
  }
  function publicState(){return JSON.parse(JSON.stringify(state));}
  function levelRequirement(level=state.level){if(level<=2)return 2;return Math.min(35,5+Math.floor((level-3)/3));}
  function currentPalette(){return palettes[state.selectedTheme]||palettes.midnight;}
  function updateWalletUI(){
    document.querySelectorAll('[data-study-coins],#shopCoins,#rewardCoins,#studyCoins').forEach(el=>el.textContent=Number(state.coins).toLocaleString('en-IN'));
    document.querySelectorAll('[data-study-level],#studyLevel').forEach(el=>el.textContent=`Level ${state.level}`);
  }
  function applyBranding(){
    if(document.body){
      document.body.dataset.theme=state.selectedTheme;
      document.body.dataset.fontStyle=state.selectedFont||'system';
      document.body.dataset.timerSkin=state.selectedTimerSkin||'timer-default';
      document.body.dataset.analyticsSkin=state.selectedAnalyticsSkin||'analytics-default';
      document.body.dataset.flashcardSkin=state.selectedFlashcardSkin||'cards-default';
      document.body.dataset.timetableSkin=state.selectedTimetableSkin||'timetable-default';
      document.body.classList.toggle('theme-translucent',state.transparencyEnabled===true);
    }
    const palette=currentPalette(); const meta=document.querySelector('meta[name="theme-color"]'); if(meta)meta.content=palette.bg;
    document.querySelectorAll('.brand-mark').forEach(el=>{el.textContent=(logoMap[state.selectedLogo]||logoMap.classic).glyph;el.dataset.logo=state.selectedLogo;});
    const icon=document.getElementById('appFavicon')||document.querySelector('link[rel="icon"]');if(icon)icon.href=`studyspace-logo-${state.selectedLogo}.svg`;
    const manifest=document.getElementById('appManifest')||document.querySelector('link[rel="manifest"]');if(manifest)manifest.href=`manifest-${state.selectedLogo}.webmanifest`;
    updateWalletUI(); applySidebarEntitlements(); applyFeatureLocks();
  }
  function applySidebarEntitlements(){
    document.querySelectorAll('[data-feature-nav]').forEach(a=>{
      const f=a.dataset.featureNav,unlocked=!!state.unlockedFeatures.includes(f);a.href=unlocked?`tools.html#${f}`:'shop.html#features';a.classList.toggle('is-unlocked',unlocked);
      const price=a.querySelector('.nav-lock-price');if(price){price.hidden=unlocked;if(unlocked)price.textContent='✓';}
      if(unlocked){const small=a.querySelector('small');if(small&&/cost|unlock|coin/i.test(small.textContent))small.textContent='Ready to open';}
    });
  }
  function applyFeatureLocks(){
    document.querySelectorAll('[data-feature-section]').forEach(section=>{
      const id=section.dataset.featureSection,unlocked=state.unlockedFeatures.includes(id);let curtain=section.querySelector(':scope > .feature-lock-curtain');
      if(unlocked){section.classList.remove('feature-is-locked');if(curtain)curtain.remove();section.querySelectorAll('[data-lock-was-disabled]').forEach(el=>{el.disabled=el.dataset.lockWasDisabled==='true';delete el.dataset.lockWasDisabled;});return;}
      section.classList.add('feature-is-locked');
      section.querySelectorAll('input,select,textarea,button').forEach(el=>{if(el.classList.contains('feature-unlock-button'))return;if(!el.hasAttribute('data-lock-was-disabled'))el.dataset.lockWasDisabled=el.disabled?'true':'false';el.disabled=true;});
      if(!curtain){curtain=document.createElement('div');curtain.className='feature-lock-curtain';curtain.innerHTML=`<div class="feature-lock-card"><span class="feature-lock-icon">▣</span><p class="eyebrow">PREMIUM STUDY TOOL</p><h3>Unlock ${FEATURES[id]?.name||'this feature'}</h3><p>This tool is ready in your Studyspace. Buy permanent access with Study Coins—no real-money payment.</p><strong class="feature-lock-price">◈ ${(FEATURES[id]?.price||0).toLocaleString('en-IN')} Study Coins</strong><a class="primary-button feature-unlock-button" href="shop.html#features">Visit Shop to unlock ↗</a></div>`;section.appendChild(curtain);}
    });
  }
  function featureUnlocked(id){return state.unlockedFeatures.includes(id);}
  function monthUnlocked(id){return ['2026-10','2026-11','2026-12'].includes(id)||state.unlockedMonths.includes(id);}
  function buy(type,id){
    const cfg=SHOP_STATE[type],catalog=SHOP_CATALOGS[type];
    const already = type==='feature'?featureUnlocked(id):type==='theme'?state.ownedThemes.includes(id):type==='logo'?state.ownedLogos.includes(id):type==='month'?monthUnlocked(id):cfg?state[cfg.owned].includes(id):false;
    if(already){if(type==='theme')applyTheme(id);if(type==='logo')applyLogo(id);if(cfg)applyShopItem(type,id);return {ok:true,already:true};}
    let item,price;
    if(type==='feature'){item=FEATURES[id];price=item?.price;}
    else if(type==='theme'){item=THEMES.find(x=>x.id===id);price=item?.price;}
    else if(type==='logo'){item=logoMap[id];price=item?.price;}
    else if(type==='month'){item=MONTHS.find(x=>x.id===id);price=item?.price;}
    else if(cfg){item=(catalog||[]).find(x=>x.id===id);price=item?.price;}
    if(!item||!Number.isFinite(price)||price<0)return {ok:false,message:'That shop item is not available.'};
    if(state.coins<price)return {ok:false,short:price-state.coins,message:`You need ${(price-state.coins).toLocaleString('en-IN')} more Study Coins.`};
    const before=JSON.stringify(state);
    state.coins-=price;state.lifetimeCoinsSpent+=price;
    if(type==='feature')state.unlockedFeatures.push(id);
    if(type==='theme'){state.ownedThemes.push(id);state.selectedTheme=id;}
    if(type==='logo'){state.ownedLogos.push(id);state.selectedLogo=id;}
    if(type==='month')state.unlockedMonths.push(id);
    if(cfg){state[cfg.owned].push(id);state[cfg.selected]=id;}
    state.purchaseLog.push({type,id,price,at:new Date().toISOString()}); if(state.purchaseLog.length>500)state.purchaseLog=state.purchaseLog.slice(-500);
    if(!save()){state=JSON.parse(before);return {ok:false,message:'Wallet could not save. No purchase was applied.'};}
    applyBranding();
    return {ok:true,already:false,item,price};
  }
  function applyShopItem(type,id){
    const cfg=SHOP_STATE[type];if(!cfg||!state[cfg.owned].includes(id))return false;
    const catalog=[BASE_SKINS[type],...(SHOP_CATALOGS[type]||[])];if(!catalog.some(x=>x.id===id))return false;
    const previous=state[cfg.selected];state[cfg.selected]=id;
    if(!save()){state[cfg.selected]=previous;return false;}
    applyBranding();return true;
  }
  function setTransparency(enabled){state.transparencyEnabled=!!enabled;if(!save())return false;applyBranding();return true;}
  function grantExtraCoins(id,amount){
    const rewardId=String(id||'').slice(0,180),payout=Math.max(0,Math.floor(Number(amount)||0));
    if(!rewardId||!payout)return {ok:false,message:'Invalid extra reward.'};
    if(state.purchaseLog.some(item=>item&&item.type==='extra-reward'&&item.id===rewardId))return {ok:false,already:true,message:'This extra reward was already paid.'};
    const before=JSON.stringify(state);state.coins+=payout;state.lifetimeCoinsEarned+=payout;
    state.purchaseLog.push({type:'extra-reward',id:rewardId,price:0,coins:payout,at:new Date().toISOString()});if(state.purchaseLog.length>1000)state.purchaseLog=state.purchaseLog.slice(-1000);
    if(!save()){state=JSON.parse(before);return {ok:false,message:'Coins could not be saved. Please try again.'};}
    return {ok:true,coins:payout};
  }
  function applyTheme(id){if(!state.ownedThemes.includes(id))return false;const previous=state.selectedTheme;state.selectedTheme=id;if(!save()){state.selectedTheme=previous;return false;}applyBranding();return true;}
  function applyLogo(id){if(!state.ownedLogos.includes(id))return false;const previous=state.selectedLogo;state.selectedLogo=id;if(!save()){state.selectedLogo=previous;return false;}applyBranding();return true;}
  function taskClaim(scope,key,amount){
    const isDaily=scope==='daily',bucket=isDaily?state.dailyClaims:state.monthlyClaims;const period=isDaily?localDate():localDate().slice(0,7);
    if(!bucket[period]||!Array.isArray(bucket[period]))bucket[period]=[];
    if(bucket[period].includes(key))return {ok:false,already:true,message:'This reward has already been claimed.'};
    const before=JSON.stringify(state);const payout=Math.max(0,Math.floor(Number(amount)||0));bucket[period].push(key);state.coins+=payout;state.lifetimeCoinsEarned+=payout;
    const was=state.level;state.claimedInLevel+=1;let levels=[];
    while(state.level<99&&state.claimedInLevel>=levelRequirement(state.level)){state.claimedInLevel-=levelRequirement(state.level);state.level+=1;levels.push(state.level);}
    if(state.level>=99){state.claimedInLevel=Math.min(state.claimedInLevel,levelRequirement(99));}
    state.purchaseLog.push({type:'reward',id:`${scope}:${period}:${key}`,price:0,coins:payout,at:new Date().toISOString()});if(state.purchaseLog.length>500)state.purchaseLog=state.purchaseLog.slice(-500);
    if(!save()){state=JSON.parse(before);return {ok:false,message:'Could not save your reward. Please try again.'};}
    return {ok:true,coins:payout,level:state.level,levelUps:levels,levelBefore:was};
  }
  function localDate(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
  function showSiteToast(message){const el=document.getElementById('economyToast')||document.getElementById('toolToast')||document.getElementById('toast');if(el){el.textContent=message;el.classList.add('show');clearTimeout(el._hideTimer);el._hideTimer=setTimeout(()=>el.classList.remove('show'),3400);}}
  function tickTimetableReminders(){
    let tools;try{tools=JSON.parse(localStorage.getItem(TOOLS_KEY)||'null');}catch(_){return;}
    if(!tools||!Array.isArray(tools.schedule)||!tools.schedule.length)return;
    const now=new Date(),day=String(now.getDay()),time=`${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`,date=localDate();
    for(const item of tools.schedule){
      if(!item||String(item.day)!==day||String(item.time)!==time||item.reminder===false)continue;
      const key=`${item.id||item.activity}:${date}:${time}`;if(state.reminderLog[key])continue;
      if('Notification'in window&&Notification.permission==='granted'){
        try{new Notification('Studyspace reminder',{body:`Time for ${item.activity||'your scheduled study session'}. Open your timetable to review it.`,icon:`studyspace-icon-192.png`});}catch(_e){showSiteToast(`Reminder: It’s time for ${item.activity||'your study session'}.`);}
      }else{
        if(document.visibilityState!=='visible')continue;
        showSiteToast(`⏰ Reminder: It’s time for ${item.activity||'your study session'}.`);
      }
      state.reminderLog[key]=Date.now();const keys=Object.keys(state.reminderLog);if(keys.length>1200)keys.slice(0,keys.length-1000).forEach(k=>delete state.reminderLog[k]);save();
    }
  }
  function setupThemeShopUpdates(){
    if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',setupThemeShopUpdates,{once:true});return;}
    applyBranding();
    window.addEventListener('storage',event=>{if(event.key===KEY){state=load();applyBranding();}if(event.key===TOOLS_KEY)window.dispatchEvent(new CustomEvent('studyspace:planner-updated'));if(event.key===PLANNER_KEY)window.dispatchEvent(new CustomEvent('studyspace:planner-updated'));});
    if(!window.__studyspaceReminderLoop){window.__studyspaceReminderLoop=true;tickTimetableReminders();setInterval(tickTimetableReminders,15000);window.addEventListener('focus',tickTimetableReminders);document.addEventListener('visibilitychange',()=>{if(!document.hidden)tickTimetableReminders();});}
  }
  window.StudyspaceEconomy={
    key:KEY,features:FEATURES,themes:THEMES,logos:LOGOS,months:MONTHS,palettes,fonts:FONTS,timerSkins:TIMER_SKINS,analyticsSkins:ANALYTICS_SKINS,flashcardSkins:FLASHCARD_SKINS,timetableSkins:TIMETABLE_SKINS,shopCatalogs:SHOP_CATALOGS,shopState:SHOP_STATE,baseSkins:BASE_SKINS,
    getState:publicState,levelRequirement,featureUnlocked,monthUnlocked,buy,applyTheme,applyLogo,applyShopItem,setTransparency,grantExtraCoins,taskClaim,applyBranding,updateWalletUI,
    setCoinBalanceForTesting:amount=>{const value=Number(amount);if(!Number.isSafeInteger(value)||value<0||value>2000000000)return {ok:false,message:'Enter a whole number from 0 to 2,000,000,000.'};const previous=state.coins;state.coins=value;if(!save()){state.coins=previous;return {ok:false,message:'Could not save the test balance. Your previous coin balance was retained.'};}return {ok:true,coins:state.coins};},
    notify:showSiteToast,refresh:()=>{state=load();applyBranding();},isLockedMonth:id=>!monthUnlocked(id),
    requestNotifications:async()=>{if(!('Notification'in window))return {ok:false,message:'This browser does not support web notifications.'};try{const permission=await Notification.requestPermission();return {ok:permission==='granted',message:permission==='granted'?'Notifications enabled. Keep Studyspace open for timetable reminders.':`Notification permission: ${permission}.`};}catch(e){return {ok:false,message:'Could not request notification permission.'};}},
    getWalletExport:()=>publicState(),restoreWallet:incoming=>{if(!incoming||typeof incoming!=='object'||!Number.isFinite(Number(incoming.coins))||!Array.isArray(incoming.ownedThemes)||!Array.isArray(incoming.unlockedFeatures))return {ok:false,message:'That is not a valid Study Coin wallet backup.'};const current=publicState();const positive=x=>(Number(x.coins)||0)>0||(Number(x.lifetimeCoinsEarned)||0)>0||(x.purchaseLog||[]).length>0;if(!positive(incoming)&&positive(current))return {ok:false,message:'This wallet backup is empty. Restore was blocked to protect your coins.'};try{state=JSON.parse(JSON.stringify(incoming));state=loadFromCandidate(state);if(!save())throw new Error();applyBranding();return {ok:true};}catch(e){state=current;return {ok:false,message:'Wallet restore failed; current data was retained.'};}}
  };
  function loadFromCandidate(candidate){const prev=localStorage.getItem(KEY);try{localStorage.setItem(KEY,JSON.stringify(candidate));return load();}finally{if(prev===null)localStorage.removeItem(KEY);else localStorage.setItem(KEY,prev);}}
  setupThemeShopUpdates();
})();
