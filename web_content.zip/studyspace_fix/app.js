(() => {
  'use strict';
  const STORAGE_KEY = 'studyspace-planner-v1';
  const RANGE_START = '2026-10-01';
  const RANGE_END = '2027-12-31';
  const MONTHS = [
    {year:2026,month:9,label:'October 2026'},{year:2026,month:10,label:'November 2026'},{year:2026,month:11,label:'December 2026'},
    ...Array.from({length:12},(_,i)=>({year:2027,month:i,label:new Date(2027,i,1,12).toLocaleDateString('en-IN',{month:'long',year:'numeric'})}))
  ];
  const todayISO = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const parseISO = s => { const [y,m,d]=String(s).split('-').map(Number); return new Date(y,m-1,d,12,0,0); };
  const toISO = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const dateLabel = s => parseISO(s).toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  const monthLabel = d => d.toLocaleDateString('en-IN',{month:'long',year:'numeric'});
  const inRange = s => s>=RANGE_START && s<=RANGE_END;
  const monthKeyForISO = s => String(s).slice(0,7);
  const monthUnlocked = key => window.StudyspaceEconomy ? window.StudyspaceEconomy.monthUnlocked(key) : !String(key).startsWith('2027-');
  const monthCanOpen = m => m.year < 2027 || monthUnlocked(`${m.year}-${String(m.month+1).padStart(2,'0')}`);
  const isValidISO = s => /^\d{4}-\d{2}-\d{2}$/.test(String(s)) && toISO(parseISO(s))===s;
  const escapeHTML = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const blankDay = () => ({tasks:[],status:'',notes:'',studySessions:[]});
  function loadData(){
    try { const parsed=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null'); if(parsed && typeof parsed==='object' && parsed.days) return parsed; }
    catch(e) { /* start with an empty planner if saved data is unreadable */ }
    return {days:{},meta:{schemaVersion:2,lastVisit:''}};
  }
  let data=loadData();
  function migrateData(){
    if(!data.days||typeof data.days!=='object') data.days={};
    if(!data.meta||!data.meta.schemaVersion){
      // Keep older manual red statuses red, and remove the old partial/yellow category.
      Object.values(data.days).forEach(d=>{
        if(!d||typeof d!=='object') return;
        if(d.status==='partial') d.status='';
        else if(d.status==='missed') d.status='missed';
        if(!Array.isArray(d.studySessions)) d.studySessions=[];
      });
      data.meta={schemaVersion:2,lastVisit:(data.meta&&data.meta.lastVisit)||''};
    }
    Object.values(data.days).forEach(d=>{if(!d||typeof d!=='object')return;if(!Array.isArray(d.tasks))d.tasks=[];if(!Array.isArray(d.studySessions))d.studySessions=[];if(typeof d.notes!=='string')d.notes='';if(!d.status)d.status='';});
    data.meta.schemaVersion=2;
  }
  function saveData(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(data));window.dispatchEvent(new CustomEvent('studyspace:planner-updated'));}catch(e){console.error('Could not save Studyspace data',e);}}
  function peekDay(s){return data.days[s]||blankDay();}
  function dayData(s){if(!data.days[s])data.days[s]=blankDay();const d=data.days[s];if(!Array.isArray(d.tasks))d.tasks=[];if(!Array.isArray(d.studySessions))d.studySessions=[];if(typeof d.notes!=='string')d.notes='';if(typeof d.status!=='string')d.status='';return d;}
  function applyMissedDaysOnVisit(){
    const today=todayISO(); data.meta=data.meta||{schemaVersion:2,lastVisit:''};
    const last=data.meta.lastVisit;
    if(typeof last==='string' && /^\d{4}-\d{2}-\d{2}$/.test(last) && last<today){
      const cursor=parseISO(last); cursor.setDate(cursor.getDate()+1);
      while(toISO(cursor)<today && toISO(cursor)<=RANGE_END){
        const iso=toISO(cursor);
        if(inRange(iso)){
          const existing=data.days[iso];
          if(!existing || !existing.status){const d=dayData(iso);d.status='missed';d.autoMissed=true;}
        }
        cursor.setDate(cursor.getDate()+1);
      }
    }
    data.meta.lastVisit=today; data.meta.schemaVersion=2; saveData();
  }
  function formatDuration(totalMinutes){
    const n=Math.max(0,Math.round(totalMinutes||0));
    if(n<60)return `${n} min`;
    const hours=Math.floor(n/60), mins=n%60;
    return mins?`${hours}h ${mins}m`:`${hours}h`;
  }
  function taskTotalsForMonth(year,month){
    let total=0,done=0,minutes=0,missed=0,productive=0,notProductive=0;
    const prefix=`${year}-${String(month+1).padStart(2,'0')}-`;
    Object.entries(data.days).forEach(([iso,d])=>{
      if(!iso.startsWith(prefix)||!d)return;
      (d.tasks||[]).forEach(t=>{total++;if(t.done)done++;});
      (d.studySessions||[]).forEach(s=>{minutes+=Number(s.minutes)||0;});
      if(d.status==='missed')missed++; else if(d.status==='productive')productive++; else if(d.status==='not-productive')notProductive++;
    });
    let current=0,best=0,daysInMonth=new Date(year,month+1,0).getDate();
    for(let day=1;day<=daysInMonth;day++){
      const iso=`${prefix}${String(day).padStart(2,'0')}`;
      if(peekDay(iso).status==='productive'){current++;best=Math.max(best,current);}else current=0;
    }
    return {total,done,percent:total?Math.round(done/total*100):0,minutes,missed,productive,notProductive,bestStreak:best};
  }
  function totalStudyMinutes(){let minutes=0;Object.values(data.days).forEach(d=>{if(!d||!Array.isArray(d.studySessions))return;d.studySessions.forEach(s=>minutes+=Number(s.minutes)||0);});return minutes;}

  let viewMonth={year:2026,month:9,label:'October 2026'};
  let setCalendarMonth=null;
  function monthIndex(year,month){return MONTHS.findIndex(m=>m.year===year&&m.month===month);}
  function renderMonthlySummary(){
    const title=document.getElementById('summaryMonth');if(!title)return;
    const stats=taskTotalsForMonth(viewMonth.year,viewMonth.month);
    title.textContent=monthLabel(new Date(viewMonth.year,viewMonth.month,1,12));
    const set=(id,val)=>{const el=document.getElementById(id);if(el)el.textContent=val;};
    set('monthProgressPercent',stats.percent+'%');set('monthTaskFraction',`${stats.done} of ${stats.total} tasks`);set('monthMissed',stats.missed);set('monthStreak',`${stats.bestStreak} ${stats.bestStreak===1?'day':'days'}`);set('monthStudyTime',formatDuration(stats.minutes));set('monthStudyDetail',`${stats.minutes.toLocaleString('en-IN')} minutes logged`);set('monthProgressLabel',stats.percent+'%');
    const bar=document.getElementById('monthProgressBar');if(bar)bar.style.width=stats.percent+'%';
    const select=document.getElementById('statsMonthSelect');if(select){const idx=monthIndex(viewMonth.year,viewMonth.month);if(idx>=0)select.value=String(idx);}
  }
  function renderCalendar(){
    const grid=document.getElementById('calendarGrid');if(!grid)return;
    const select=document.getElementById('monthSelect');
    const options=MONTHS.map((m,i)=>{const locked=!monthCanOpen(m);const price=window.StudyspaceEconomy?.months.find(x=>x.id===`${m.year}-${String(m.month+1).padStart(2,'0')}`)?.price||0;return `<option value="${i}">${locked?'🔒 ':''}${m.label}${locked?` — ${price} coins`:''}</option>`;}).join('');
    select.innerHTML=options;
    const statsSelect=document.getElementById('statsMonthSelect');if(statsSelect)statsSelect.innerHTML=options;
    function draw(){
      const m=MONTHS[Number(select.value)]||MONTHS[0];viewMonth={...m};grid.innerHTML='';
      const first=new Date(m.year,m.month,1,12),offset=(first.getDay()+6)%7,daysInMonth=new Date(m.year,m.month+1,0).getDate();
      for(let i=0;i<offset;i++){const blank=document.createElement('div');blank.className='day-cell outside';grid.appendChild(blank);}
      for(let day=1;day<=daysInMonth;day++){
        const iso=toISO(new Date(m.year,m.month,day,12)),dd=peekDay(iso),cell=document.createElement('button');
        cell.type='button';cell.className='day-cell'+(iso===todayISO()?' today':'')+(dd.status?' status-'+dd.status:'')+((dd.tasks||[]).length||(dd.studySessions||[]).length?' has-tasks':'');
        const marks={productive:'✓ Productive','not-productive':'× Not Productive',missed:'! Missed Day'};
        let detail=marks[dd.status]||'';
        if(!detail){const count=(dd.tasks||[]).length,mins=(dd.studySessions||[]).reduce((sum,s)=>sum+(Number(s.minutes)||0),0);if(count)detail=`${count} task${count===1?'':'s'}`;else if(mins)detail=formatDuration(mins);}
        cell.innerHTML=`<span class="day-number">${day}</span><span class="day-mark">${escapeHTML(detail)}</span>`;
        cell.setAttribute('aria-label',`${dateLabel(iso)}${dd.status?', '+({productive:'Productive Day','not-productive':'Not Productive',missed:'Missed Day'}[dd.status]||''):''}`);
        if(monthUnlocked(monthKeyForISO(iso)))cell.addEventListener('click',()=>location.href=`day.html?date=${iso}`);else{cell.classList.add('locked-month-day');cell.setAttribute('aria-label',`${dateLabel(iso)} is locked. Purchase this month in the Study Coin Shop.`);cell.addEventListener('click',()=>location.href='shop.html#months');}grid.appendChild(cell);
      }
      const total=offset+daysInMonth,trailing=(7-total%7)%7;for(let i=0;i<trailing;i++){const blank=document.createElement('div');blank.className='day-cell outside';grid.appendChild(blank);}
      renderMonthlySummary();
    }
    function syncToIndex(idx){const i=Math.max(0,Math.min(MONTHS.length-1,idx));const target=MONTHS[i];if(!monthCanOpen(target)){location.href='shop.html#months';return;}select.value=String(i);if(statsSelect)statsSelect.value=String(i);draw();}
    let active=monthIndex(viewMonth.year,viewMonth.month);if(active<0||!monthCanOpen(MONTHS[active]))active=0;select.value=String(active);if(statsSelect)statsSelect.value=select.value;
    select.addEventListener('change',()=>syncToIndex(Number(select.value)));
    if(statsSelect)statsSelect.addEventListener('change',()=>syncToIndex(Number(statsSelect.value)));
    document.getElementById('prevMonth').addEventListener('click',()=>syncToIndex(Number(select.value)-1));
    document.getElementById('nextMonth').addEventListener('click',()=>syncToIndex(Number(select.value)+1));
    setCalendarMonth=syncToIndex;
    draw();
  }
  function renderTopStats(){renderMonthlySummary();}
  function initCalendar(){
    const today=todayISO();const todayLink=document.getElementById('todayLink');todayLink.href=`day.html?date=${today}`;
    // Start with October 2026 unless today's date is inside the planner range.
    if(inRange(today)){const dt=parseISO(today);viewMonth={year:dt.getFullYear(),month:dt.getMonth(),label:monthLabel(dt)};}
    renderCalendar();renderTopStats();
  }

  function initDay(){
    const params=new URLSearchParams(location.search);let date=params.get('date')||todayISO();if(!isValidISO(date)||!inRange(date))date=RANGE_START;if(!monthUnlocked(monthKeyForISO(date))){location.replace('shop.html#months');return;}let currentDate=date;
    const title=document.getElementById('dayTitle'),subtitle=document.getElementById('daySubtitle'),list=document.getElementById('taskList'),empty=document.getElementById('emptyState');
    const input=document.getElementById('taskInput'),subject=document.getElementById('subjectInput'),priority=document.getElementById('priorityInput'),notes=document.getElementById('dayNotes');
    const progressRing=document.getElementById('progressRing'),progressPercent=document.getElementById('progressPercent'),progressFraction=document.getElementById('progressFraction'),taskCount=document.getElementById('taskCount'),statusNote=document.getElementById('statusNote');
    const prev=document.getElementById('previousDay'),next=document.getElementById('nextDay'),goToday=document.getElementById('goToday');
    const studyForm=document.getElementById('studyForm'),studySubject=document.getElementById('studySubject'),studyMinutes=document.getElementById('studyMinutes'),sessionList=document.getElementById('studySessionList');
    function navigate(s){if(!inRange(s))return;if(!monthUnlocked(monthKeyForISO(s))){location.href='shop.html#months';return;}location.href=`day.html?date=${s}`;}
    function renderDay(){
      const dd=dayData(currentDate);title.textContent=parseISO(currentDate).toLocaleDateString('en-IN',{day:'numeric',month:'long'});subtitle.textContent=dateLabel(currentDate)+(currentDate===todayISO()?' · This is today':'');notes.value=dd.notes||'';list.innerHTML='';
      dd.tasks.forEach(task=>{
        const row=document.createElement('div');row.className='task-item'+(task.done?' done':'');
        row.innerHTML=`<input class="task-check" type="checkbox" aria-label="Mark task complete" ${task.done?'checked':''}><div class="task-info"><div class="task-title">${escapeHTML(task.title)}</div><div class="task-meta"><span class="subject-tag">${escapeHTML(task.subject||'General')}</span>${task.priority==='High'?'<span class="priority-tag">High priority</span>':''}</div></div><button class="delete-task" type="button" aria-label="Delete task" title="Delete task">×</button>`;
        row.querySelector('.task-check').addEventListener('change',e=>{task.done=e.target.checked;saveData();renderDay();});
        row.querySelector('.delete-task').addEventListener('click',()=>{dd.tasks=dd.tasks.filter(t=>t.id!==task.id);saveData();renderDay();});list.appendChild(row);
      });
      empty.style.display=dd.tasks.length?'none':'block';const done=dd.tasks.filter(t=>t.done).length,total=dd.tasks.length,pct=total?Math.round(done/total*100):0;
      progressPercent.textContent=pct+'%';progressRing.style.background=`conic-gradient(var(--purple) ${pct*3.6}deg,#333750 ${pct*3.6}deg)`;progressFraction.textContent=`${done} of ${total} task${total===1?'':'s'}`;taskCount.textContent=`${total} task${total===1?'':'s'}`;
      document.querySelectorAll('.status-option').forEach(btn=>{const selected=btn.dataset.status===dd.status;btn.classList.toggle('selected',selected);btn.querySelector('.status-check').textContent=selected?'✓':'○';});
      const messages={productive:'Marked Productive Day on your calendar.', 'not-productive':'Marked Not Productive in red on your calendar.', missed:'This date is marked Missed Day in yellow because you did not open the planner that day.'};statusNote.textContent=messages[dd.status]||'Days you do not visit are marked Missed Day in yellow when you return.';
      prev.disabled=!inRange(toISO(new Date(parseISO(currentDate).getTime()-86400000)));next.disabled=!inRange(toISO(new Date(parseISO(currentDate).getTime()+86400000)));goToday.disabled=!inRange(todayISO())||currentDate===todayISO();
      renderSessions(dd);renderMonthlySummary();
    }
    function renderSessions(dd){
      sessionList.innerHTML='';let total=0;
      dd.studySessions.forEach(session=>{const mins=Number(session.minutes)||0;total+=mins;const row=document.createElement('div');row.className='session-item';row.innerHTML=`<span class="session-subject">${escapeHTML(session.subject)}</span><span class="session-minutes">${mins} min</span><button type="button" class="delete-session" aria-label="Delete study session" title="Delete session">×</button>`;row.querySelector('.delete-session').addEventListener('click',()=>{dd.studySessions=dd.studySessions.filter(s=>s.id!==session.id);saveData();renderDay();});sessionList.appendChild(row);});
      if(!dd.studySessions.length){const p=document.createElement('p');p.className='session-empty';p.textContent='No study time logged yet for this date.';sessionList.appendChild(p);}
      const count=document.getElementById('sessionCount');if(count)count.textContent=`${dd.studySessions.length} session${dd.studySessions.length===1?'':'s'}`;
      document.getElementById('studyTimeSum').textContent=formatDuration(total);document.getElementById('dailyTimeTotal').textContent=formatDuration(total);
    }
    document.getElementById('taskForm').addEventListener('submit',e=>{e.preventDefault();const value=input.value.trim();if(!value)return;const dd=dayData(currentDate);dd.tasks.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),title:value,subject:subject.value,priority:priority.value,done:false});saveData();input.value='';priority.value='Normal';renderDay();input.focus();});
    studyForm.addEventListener('submit',e=>{e.preventDefault();const sub=studySubject.value.trim(),mins=Number(studyMinutes.value);if(!sub||!Number.isInteger(mins)||mins<1||mins>1440){showToast('Enter a subject and study time from 1 to 1440 minutes.');return;}dayData(currentDate).studySessions.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),subject:sub,minutes:mins});saveData();studySubject.value='';studyMinutes.value='';renderDay();studySubject.focus();});
    document.querySelectorAll('.status-option').forEach(btn=>btn.addEventListener('click',()=>{const dd=dayData(currentDate);dd.status=btn.dataset.status;dd.autoMissed=false;saveData();renderDay();}));
    notes.addEventListener('input',()=>{dayData(currentDate).notes=notes.value;saveData();});
    prev.addEventListener('click',()=>navigate(toISO(new Date(parseISO(currentDate).getTime()-86400000))));next.addEventListener('click',()=>navigate(toISO(new Date(parseISO(currentDate).getTime()+86400000))));goToday.addEventListener('click',()=>navigate(todayISO()));
    renderDay();
  }

  function showToast(message){const toast=document.getElementById('toast');if(!toast){window.alert(message);return;}toast.textContent=message;toast.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>toast.classList.remove('show'),3000);}
  function showModal({title,message,confirmText='Yes, continue',danger=true,onConfirm}){
    const modal=document.getElementById('confirmModal');if(!modal){if(window.confirm(message))onConfirm();return;}
    document.getElementById('modalTitle').textContent=title;document.getElementById('modalMessage').textContent=message;const confirm=document.getElementById('modalConfirm');confirm.textContent=confirmText;confirm.className=danger?'danger-button':'primary-button';modal.hidden=false;
    const close=()=>{modal.hidden=true;confirm.onclick=null;document.getElementById('modalCancel').onclick=null;};
    confirm.onclick=()=>{close();onConfirm();};document.getElementById('modalCancel').onclick=close;modal.onclick=e=>{if(e.target===modal)close();};
  }

  function initMore(){
    const monthSelect=document.getElementById('clearMonth'),yearSelect=document.getElementById('clearYear'),daySelect=document.getElementById('clearDay');
    const monthOptions=[{month:10,year:2026,label:'October'},{month:11,year:2026,label:'November'},{month:12,year:2026,label:'December'},...Array.from({length:12},(_,i)=>({month:i+1,year:2027,label:new Date(2027,i,1,12).toLocaleDateString('en-IN',{month:'long'})}))];
    function updateMonthChoices(){const y=Number(yearSelect.value),valid=monthOptions.filter(m=>m.year===y);monthSelect.innerHTML=valid.map(m=>`<option value="${m.month}">${m.label}</option>`).join('');updateDays();}
    function updateDays(){const y=Number(yearSelect.value),m=Number(monthSelect.value),days=new Date(y,m,0).getDate();daySelect.innerHTML=Array.from({length:days},(_,i)=>`<option value="${i+1}">${i+1}</option>`).join('');}
    yearSelect.addEventListener('change',updateMonthChoices);monthSelect.addEventListener('change',updateDays);updateMonthChoices();

    function updateMoreStats(){let productive=0,recorded=0;Object.values(data.days).forEach(d=>{if(!d||typeof d!=='object')return;if(d.status==='productive')productive++;if(d.status||d.tasks?.length||d.studySessions?.length||d.notes)recorded++;});document.getElementById('moreProductive').textContent=productive;document.getElementById('moreTime').textContent=formatDuration(totalStudyMinutes());document.getElementById('moreRecorded').textContent=recorded;}
    updateMoreStats();
    document.getElementById('clearDayForm').addEventListener('submit',e=>{e.preventDefault();const iso=`${yearSelect.value}-${String(monthSelect.value).padStart(2,'0')}-${String(daySelect.value).padStart(2,'0')}`;if(!inRange(iso)){showToast('Choose a date from October 2026 through December 2027.');return;}if(!monthUnlocked(monthKeyForISO(iso))){location.href='shop.html#months';return;}
      showModal({title:'Clear this day?',message:`This will delete calendar tasks, study time, notes, status and homework entries for ${dateLabel(iso)}. This cannot be undone unless you have a backup.`,confirmText:'Delete day',danger:true,onConfirm:()=>{delete data.days[iso];saveData();let homework=null;try{homework=JSON.parse(localStorage.getItem('studyspace-homework-v1')||'null');}catch(_err){}if(homework&&homework.days&&typeof homework.days==='object'){delete homework.days[iso];try{localStorage.setItem('studyspace-homework-v1',JSON.stringify(homework));window.dispatchEvent(new CustomEvent('studyspace:homework-updated',{detail:{date:iso}}));}catch(_err){showToast('Calendar data cleared, but homework storage could not be updated. Use More & Backups to review your backup.');}}updateMoreStats();showToast(`${dateLabel(iso)} and its schoolwork have been cleared.`);}});
    });
    const toolsBackupInput=document.getElementById('importToolsBackupInput');
    if(toolsBackupInput) toolsBackupInput.addEventListener('change',e=>{
      const file=e.target.files&&e.target.files[0];if(!file)return;const status=document.getElementById('importToolsStatus');
      const reader=new FileReader();reader.onload=()=>{try{
        const parsed=JSON.parse(String(reader.result)),incoming=parsed.data||parsed;
        const valid=incoming&&typeof incoming==='object'&&!Array.isArray(incoming)&&Array.isArray(incoming.syllabus)&&Array.isArray(incoming.cards)&&Array.isArray(incoming.exams)&&Array.isArray(incoming.schedule)&&Array.isArray(incoming.awards)&&Array.isArray(incoming.focusSessions)&&Number.isFinite(Number(incoming.xp));
        if(!valid)throw new Error('This is not a valid Studyspace Studio backup. Choose studyspace-tools-backup.json.');
        let current=null;try{current=JSON.parse(localStorage.getItem('studyspace-tools-v1')||'null');}catch(_err){}
        const hasContent=x=>x&&(x.syllabus?.length||x.cards?.length||x.exams?.length||x.schedule?.length||x.focusSessions?.length||Number(x.xp)>0);
        if(!hasContent(incoming)&&hasContent(current))throw new Error('This Studio backup is empty. Restore was blocked to protect your existing tools data.');
        showModal({title:'Restore Studio data?',message:'This replaces current syllabus, flashcards, exams, timetable, focus history and Study XP in this browser. Planner tasks and Study Coin wallet progress will not change.',confirmText:'Restore Studio data',danger:false,onConfirm:()=>{try{localStorage.setItem('studyspace-tools-v1',JSON.stringify(incoming));status.textContent='Studyspace Studio data restored. Open Study Tools to review it.';showToast('Studio backup restored.');}catch(err){status.textContent='Could not save Studio data in this browser.';}}});
      }catch(err){status.textContent=err.message||'Could not read this Studio backup.';}e.target.value='';};reader.onerror=()=>{status.textContent='Could not read the selected file.';};reader.readAsText(file);
    });


    // Reset/restore snapshots are kept separately in this browser and never touch the live website files.
    const SNAP_KEY='studyspace-reset-snapshots-v1';
    function readSnapshots(){try{return JSON.parse(localStorage.getItem(SNAP_KEY)||'{}')||{};}catch(_){return {};}}
    function writeSnapshots(snap){localStorage.setItem(SNAP_KEY,JSON.stringify(snap));}
    function statusLine(id,msg){const el=document.getElementById(id);if(el)el.textContent=msg;}
    function saveSnapshot(name,keys){const all=readSnapshots();all[name]={at:new Date().toISOString(),values:{}};keys.forEach(k=>{try{all[name].values[k]=localStorage.getItem(k);}catch(_){all[name].values[k]=null;}});writeSnapshots(all);}
    function restoreSnapshot(name,keys,statusId){
      const all=readSnapshots(),snap=all[name];if(!snap||!snap.values){statusLine(statusId,'No snapshot saved yet. Use Reset once to create a restore point.');return;}
      keys.forEach(k=>{const v=snap.values[k];if(v===null||v===undefined)localStorage.removeItem(k);else localStorage.setItem(k,v);});
      if(window.StudyspaceEconomy)window.StudyspaceEconomy.refresh();
      statusLine(statusId,'Restored snapshot from '+new Date(snap.at).toLocaleString()+'.');
      showToast('Snapshot restored. Refreshing visible progress…');
      setTimeout(()=>location.reload(),350);
    }
    function resetKeys(name,keys,statusId,message){
      showModal({title:'Reset '+name+'?',message:message||'The current values will be saved as a restore point first. This reset cannot be undone except with Restore.',confirmText:'Save snapshot & reset',danger:true,onConfirm:()=>{
        saveSnapshot(name,keys);
        keys.forEach(k=>localStorage.removeItem(k));
        if(window.StudyspaceEconomy)window.StudyspaceEconomy.refresh();
        statusLine(statusId,'Reset complete. Previous values saved for Restore.');
        showToast(name+' reset. Previous values can be restored.');
        setTimeout(()=>location.reload(),350);
      }});
    }
    const plannerKeys=['studyspace-planner-v1','studyspace-homework-v1'];
    const toolsKeys=['studyspace-tools-v1'];
    const walletKey=['studyspace-economy-v1'];
    const allKeys=[...plannerKeys,...toolsKeys,...walletKey];
    const bindReset=(buttonId,restoreId,name,keys,statusId)=> {
      const b=document.getElementById(buttonId),r=document.getElementById(restoreId);
      if(b)b.addEventListener('click',()=>resetKeys(name,keys,statusId));
      if(r)r.addEventListener('click',()=>restoreSnapshot(name,keys,statusId));
    };
    bindReset('resetPlannerAll','restorePlannerLast','planner',plannerKeys,'plannerSnapshotStatus');
    bindReset('resetToolsAll','restoreToolsLast','tools',toolsKeys,'toolsSnapshotStatus');
    document.getElementById('restoreCoinsLast')?.addEventListener('click',()=>restoreSnapshot('coins',walletKey,'coinsSnapshotStatus'));
    document.getElementById('restoreRewardsLast')?.addEventListener('click',()=>restoreSnapshot('rewards',walletKey,'rewardsSnapshotStatus'));
    const customCoinsForm=document.getElementById('customCoinsForm');
    if(customCoinsForm)customCoinsForm.addEventListener('submit',event=>{
      event.preventDefault();
      const input=document.getElementById('customCoinsAmount');
      const status=document.getElementById('customCoinsStatus');
      const amount=Number(input?.value);
      if(!Number.isSafeInteger(amount)||amount<0||amount>2000000000){if(status)status.textContent='Enter a whole number from 0 to 2,000,000,000.';return;}
      const current=window.StudyspaceEconomy?.getState?.();
      if(!current||typeof window.StudyspaceEconomy.setCoinBalanceForTesting!=='function'){if(status)status.textContent='Coin wallet is not ready. Refresh this page and try again.';return;}
      showModal({title:'Set a test coin balance?',message:`This will change only your current balance to ${amount.toLocaleString('en-IN')} coins. Your current wallet will be saved first. Levels, reward claims, lifetime totals, shop purchases, themes, logos, and planner data will not be changed. Use “Restore last wallet” to return to the previous wallet.`,confirmText:'Save wallet & set coins',danger:false,onConfirm:()=>{
        try{saveSnapshot('coins',walletKey);const result=window.StudyspaceEconomy.setCoinBalanceForTesting(amount);if(!result.ok){if(status)status.textContent=result.message;return;}if(status)status.textContent=`Test balance set to ${result.coins.toLocaleString('en-IN')} coins. All other progress was preserved; use “Restore last wallet” to undo.`;statusLine('coinsSnapshotStatus','Previous wallet saved before setting custom coins.');showToast(`Test balance set to ${result.coins.toLocaleString('en-IN')} Study Coins.`);input.value=String(result.coins);}
        catch(_err){if(status)status.textContent='Could not set the test balance. Your saved progress was not intentionally changed.';}
      }});
    });
    // Wallet sub-resets keep unrelated entitlements intact; each has its own last snapshot.
    function resetWalletPart(part){
      const all=readSnapshots(),raw=localStorage.getItem('studyspace-economy-v1');
      let wallet={};try{wallet=JSON.parse(raw||'{}')||{};}catch(_){}
      all[part]={at:new Date().toISOString(),values:{'studyspace-economy-v1':raw}};
      writeSnapshots(all);
      if(part==='coins'){wallet.coins=0;wallet.lifetimeCoinsEarned=0;wallet.lifetimeCoinsSpent=0;}
      else {wallet.level=1;wallet.claimedInLevel=0;wallet.dailyClaims={};wallet.monthlyClaims={};}
      localStorage.setItem('studyspace-economy-v1',JSON.stringify(wallet));
      window.StudyspaceEconomy?.refresh();
      statusLine(part==='coins'?'coinsSnapshotStatus':'rewardsSnapshotStatus','Reset complete. Previous values saved for Restore.');
      setTimeout(()=>location.reload(),350);
    }
    document.getElementById('resetCoinsOnly')?.addEventListener('click',()=>showModal({title:'Reset Study Coins?',message:'Your current wallet will be saved first. This resets coin balance and lifetime coin totals but keeps purchased themes, logos and feature unlocks.',confirmText:'Save snapshot & reset coins',danger:true,onConfirm:()=>resetWalletPart('coins')}));
    document.getElementById('resetRewardsOnly')?.addEventListener('click',()=>showModal({title:'Reset Study Rewards?',message:'Your current wallet will be saved first. This resets reward claims and level progress but keeps your current coin balance and shop purchases.',confirmText:'Save snapshot & reset rewards',danger:true,onConfirm:()=>resetWalletPart('rewards')}));
    bindReset('resetPlannerExtras','restorePlannerExtras','planner-extras',[...plannerKeys,...toolsKeys],'extrasSnapshotStatus');
    bindReset('resetFullApp','restoreFullApp','full-website',allKeys,'fullSnapshotStatus');
    document.getElementById('resetWebsiteButton')?.addEventListener('click',()=>resetKeys('planner and schoolwork',plannerKeys,'plannerSnapshotStatus','This clears calendar tasks, study sessions, notes and homework logs. A snapshot is saved first so you can restore the previous values.'));

    document.getElementById('exportZipButton').addEventListener('click',async()=>{
      const button=document.getElementById('exportZipButton'),status=document.getElementById('exportStatus');button.disabled=true;button.textContent='Preparing ZIP…';status.textContent='Packaging website files and saved progress.';
      try{
        const fileNames=['index.html','day.html','monthly-analysis.html','more.html','tools.html','rewards.html','shop.html','extra-rewards.html','style.css','app.js','nav.js','economy.js','rewards-shop.js','extra-rewards.js','tools.js','manifest.webmanifest','manifest-classic.webmanifest','manifest-crescent.webmanifest','manifest-crystal.webmanifest','manifest-orbit.webmanifest','manifest-phoenix.webmanifest','manifest-webhero.webmanifest','manifest-arctech.webmanifest','manifest-anime.webmanifest','sw.js','theme-art-web.svg','theme-art-armor.svg','theme-art-panther.svg','theme-art-ninja.svg','theme-art-thunder.svg','theme-ref-spiderman.jpg','theme-ref-zenitsu.jpg','theme-ref-naruto.jpg','theme-ref-black-panther.jpg','studyspace-icon.svg','studyspace-icon-192.png','studyspace-icon-512.png','studyspace-logo-classic.svg','studyspace-logo-crescent.svg','studyspace-logo-crystal.svg','studyspace-logo-orbit.svg','studyspace-logo-phoenix.svg','studyspace-logo-webhero.svg','studyspace-logo-arctech.svg','studyspace-logo-anime.svg','logo-classic-192.png','logo-classic-512.png','logo-crescent-192.png','logo-crescent-512.png','logo-crystal-192.png','logo-crystal-512.png','logo-orbit-192.png','logo-orbit-512.png','logo-phoenix-192.png','logo-phoenix-512.png','logo-webhero-192.png','logo-webhero-512.png','logo-arctech-192.png','logo-arctech-512.png','logo-anime-192.png','logo-anime-512.png','README.txt'];const entries=[];
        for(const name of fileNames){const response=await fetch(name,{cache:'no-store'});if(!response.ok){if(name==='README.txt')continue;throw new Error(`Could not fetch ${name}. Make sure all website files are uploaded to the same folder.`);}entries.push({name,data:new Uint8Array(await response.arrayBuffer())});}
        const backup={app:'Studyspace',version:2,exportedAt:new Date().toISOString(),data:data};
        entries.push({name:'studyspace-backup.json',data:new TextEncoder().encode(JSON.stringify(backup,null,2))});
        let savedTools=null;try{savedTools=JSON.parse(localStorage.getItem('studyspace-tools-v1')||'null');}catch(_err){}
        const toolsBackup={app:'Studyspace Studio',version:2,exportedAt:new Date().toISOString(),data:savedTools||{schemaVersion:1,syllabus:[],cards:[],exams:[],schedule:[],xp:0,awards:[],focusSessions:[]}};
        entries.push({name:'studyspace-tools-backup.json',data:new TextEncoder().encode(JSON.stringify(toolsBackup,null,2))});
        let savedEconomy=null;try{savedEconomy=JSON.parse(localStorage.getItem('studyspace-economy-v1')||'null');}catch(_err){}
        const economyBackup={app:'Studyspace Coin Wallet',version:3,exportedAt:new Date().toISOString(),data:savedEconomy||{schemaVersion:3,coins:0,level:1,claimedInLevel:0,dailyClaims:{},monthlyClaims:{},unlockedFeatures:[],ownedThemes:['midnight'],selectedTheme:'midnight',ownedLogos:['classic'],selectedLogo:'classic',unlockedMonths:['2026-10','2026-11','2026-12'],purchaseLog:[]}};entries.push({name:'studyspace-economy-backup.json',data:new TextEncoder().encode(JSON.stringify(economyBackup,null,2))});
        let savedHomework=null;try{savedHomework=JSON.parse(localStorage.getItem('studyspace-homework-v1')||'null');}catch(_err){}
        const homeworkBackup={app:'Studyspace Homework & Extra Rewards',version:1,exportedAt:new Date().toISOString(),data:savedHomework||{schemaVersion:1,days:{}}};entries.push({name:'studyspace-homework-backup.json',data:new TextEncoder().encode(JSON.stringify(homeworkBackup,null,2))});
        const restoreReadme='STUDYSPACE BACKUP RESTORE\n\nWEBSITE FILES\nUpload the HTML, CSS, JavaScript, manifest, service worker, logo and icon files included in this ZIP to public_html. Studyspace uses local device storage only. No account system, PHP API or cloud account store is included.\n\nRESTORE STUDY DATA\nOpen More & Backups and choose studyspace-backup.json.\n\nRESTORE STUDY TOOLS\nChoose studyspace-tools-backup.json to restore syllabus, flashcards, exam dates, timetable and focus sessions.\n\nRESTORE STUDY COINS\nChoose studyspace-economy-backup.json to restore coins, level, claims, feature unlocks, themes, fonts, cosmetic skins, logos and calendar months.\n\nRESTORE SCHOOLWORK & EXTRA REWARDS\nChoose studyspace-homework-backup.json in More & Backups to restore per-day homework entries and homework reward claim history.\n\nIMPORTANT\nPlanner data, homework logs, Study Tools and the coin wallet are stored separately in this browser. A website ZIP does not automatically contain live browser data unless freshly exported. Never restore an empty snapshot over data you need.\n';
        entries.push({name:'RESTORE-INSTRUCTIONS.txt',data:new TextEncoder().encode(restoreReadme)});
        const blob=makeZip(entries),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`studyspace-backup-${todayISO()}.zip`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);status.textContent='ZIP downloaded with website files and planner, tools, homework and wallet data saved on this device.';
      }catch(err){status.textContent=err.message||'Export failed. Try again after refreshing the page.';}
      finally{button.disabled=false;button.innerHTML='<span>⇩</span> Export website + progress (.zip)';}
    });
    document.getElementById('importBackupInput').addEventListener('change',e=>{
      const file=e.target.files&&e.target.files[0];if(!file)return;const status=document.getElementById('importStatus');
      const reader=new FileReader();reader.onload=()=>{try{
        const parsed=JSON.parse(String(reader.result));const incoming=parsed.data||parsed;
        if(!incoming||typeof incoming.days!=='object'||!incoming.days||Array.isArray(incoming.days))throw new Error('This file does not contain a valid Studyspace planner backup. Choose studyspace-backup.json.');
        const incomingHasContent=Object.values(incoming.days).some(d=>d&&((Array.isArray(d.tasks)&&d.tasks.length)||(Array.isArray(d.studySessions)&&d.studySessions.length)||Boolean(d.notes)||(Boolean(d.status))));
        const currentHasContent=Object.values(data.days||{}).some(d=>d&&((Array.isArray(d.tasks)&&d.tasks.length)||(Array.isArray(d.studySessions)&&d.studySessions.length)||Boolean(d.notes)||(Boolean(d.status))));
        if(!incomingHasContent&&currentHasContent)throw new Error('This backup contains no saved study entries. Restoring it would erase your current progress, so it was blocked. Choose a fresh ZIP exported from your website.');
        showModal({title:'Restore study backup?',message:'This will replace study planner data currently saved in this browser. Your Study Coin wallet and Study Tools data are stored separately. Export current progress first if you want to keep it.',confirmText:'Restore planner',danger:false,onConfirm:()=>{data=incoming;if(!data.meta)data.meta={schemaVersion:2,lastVisit:todayISO()};data.meta.schemaVersion=2;data.meta.lastVisit=todayISO();Object.values(data.days).forEach(d=>{if(!d||typeof d!=='object')return;if(!Array.isArray(d.tasks))d.tasks=[];if(!Array.isArray(d.studySessions))d.studySessions=[];if(typeof d.notes!=='string')d.notes='';if(typeof d.status!=='string')d.status='';});saveData();updateMoreStats();status.textContent='Study backup restored successfully.';showToast('Planner backup restored. Open the calendar to review your progress.');}});
      }catch(err){status.textContent=err.message||'Could not read this backup file.';}e.target.value='';};reader.onerror=()=>{status.textContent='Could not read the selected file.';};reader.readAsText(file);
    });


    const economyBackupInput=document.getElementById('importEconomyBackupInput');
    if(economyBackupInput) economyBackupInput.addEventListener('change',e=>{
      const file=e.target.files&&e.target.files[0];if(!file)return;const status=document.getElementById('importEconomyStatus');
      const reader=new FileReader();reader.onload=()=>{try{const parsed=JSON.parse(String(reader.result)),incoming=parsed.data||parsed;const api=window.StudyspaceEconomy;if(!api)throw new Error('Wallet system is not available. Refresh and try again.');showModal({title:'Restore Study Coin wallet?',message:'This replaces your current Study Coins, level, reward claims, purchased features, themes, logos and unlocked months. Make a backup first.',confirmText:'Restore wallet',danger:false,onConfirm:()=>{const res=api.restoreWallet(incoming);status.textContent=res.ok?'Study Coin wallet restored.':(res.message||'Wallet restore failed.');if(res.ok)showToast('Wallet restored.');}});}catch(err){status.textContent=err.message||'Could not read wallet backup.';}e.target.value='';};reader.onerror=()=>{status.textContent='Could not read wallet backup.';};reader.readAsText(file);
    });

    const homeworkBackupInput=document.getElementById('importHomeworkBackupInput');
    if(homeworkBackupInput) homeworkBackupInput.addEventListener('change',e=>{
      const file=e.target.files&&e.target.files[0];if(!file)return;const status=document.getElementById('importHomeworkStatus');
      const reader=new FileReader();reader.onload=()=>{try{
        const parsed=JSON.parse(String(reader.result)),incoming=parsed.data||parsed;
        if(!incoming||typeof incoming!=='object'||Array.isArray(incoming)||!incoming.days||typeof incoming.days!=='object'||Array.isArray(incoming.days))throw new Error('This is not a valid homework backup. Choose studyspace-homework-backup.json.');
        const hasHomework=value=>Object.values(value?.days||{}).some(day=>day&&Array.isArray(day.entries)&&day.entries.length>0);
        let current=null;try{current=JSON.parse(localStorage.getItem('studyspace-homework-v1')||'null');}catch(_err){}
        if(!hasHomework(incoming)&&hasHomework(current))throw new Error('This backup contains no homework entries. Restore was blocked to protect your existing homework logs.');
        Object.entries(incoming.days).forEach(([iso,day])=>{
          if(!/^\d{4}-\d{2}-\d{2}$/.test(iso)||!day||typeof day!=='object'||Array.isArray(day))throw new Error('The backup contains an invalid schoolwork date. Nothing was changed.');
          if(!Array.isArray(day.entries))throw new Error(`The backup entries for ${iso} are invalid. Nothing was changed.`);
          day.entries.forEach(entry=>{if(!entry||typeof entry!=='object'||typeof entry.title!=='string'||!Number.isFinite(Number(entry.minutes))||Number(entry.minutes)<1||Number(entry.minutes)>720)throw new Error(`A homework entry for ${iso} is invalid. Nothing was changed.`);});
        });
        showModal({title:'Restore schoolwork & Extra Rewards?',message:'This replaces your homework logs and per-day extra-reward claim history. Your planner, Study Tools and coin wallet are stored separately. Export current progress first if you want to keep it.',confirmText:'Restore homework',danger:false,onConfirm:()=>{try{localStorage.setItem('studyspace-homework-v1',JSON.stringify({schemaVersion:1,days:incoming.days}));window.dispatchEvent(new CustomEvent('studyspace:homework-updated',{detail:{date:todayISO()}}));status.textContent='Homework and Extra Rewards data restored.';showToast('Schoolwork backup restored.');}catch(err){status.textContent='Could not save homework data in this browser.';}}});
      }catch(err){status.textContent=err.message||'Could not read homework backup.';}e.target.value='';};reader.onerror=()=>{status.textContent='Could not read homework backup.';};reader.readAsText(file);
    });

  }


  function initAnalysis(){
    const select=document.getElementById('analysisMonth');
    if(!select)return;
    select.innerHTML=MONTHS.map((m,i)=>{const locked=!monthCanOpen(m);const price=window.StudyspaceEconomy?.months.find(x=>x.id===`${m.year}-${String(m.month+1).padStart(2,'0')}`)?.price||0;return `<option value="${i}">${locked?'🔒 ':''}${m.label}${locked?` — ${price} coins`:''}</option>`;}).join('');
    const params=new URLSearchParams(location.search);
    const requested=params.get('month');
    const requestedIndex=MONTHS.findIndex(m=>`${m.year}-${String(m.month+1).padStart(2,'0')}`===requested);
    const today=inRange(todayISO())?parseISO(todayISO()):parseISO(RANGE_START);
    let currentIndex=monthIndex(today.getFullYear(),today.getMonth());if(currentIndex<0||!monthCanOpen(MONTHS[currentIndex]))currentIndex=0;
    const safeRequested=requestedIndex>=0&&monthCanOpen(MONTHS[requestedIndex])?requestedIndex:-1;select.value=String(safeRequested>=0?safeRequested:Math.max(0,currentIndex));

    const el=id=>document.getElementById(id);
    function render(){
      const mo=MONTHS[Number(select.value)]||MONTHS[0];
      const monthNumber=String(mo.month+1).padStart(2,'0');
      const prefix=`${mo.year}-${monthNumber}-`;
      const entries=Object.entries(data.days).filter(([iso])=>iso.startsWith(prefix)).sort(([a],[b])=>a.localeCompare(b));
      let totalMinutes=0,sessionCount=0,totalTasks=0,completedTasks=0,productive=0,missed=0,notProductive=0;
      const subjectMap=new Map(),dailyMinutes={},history=[];
      entries.forEach(([iso,d])=>{
        if(!d)return;
        (d.tasks||[]).forEach(task=>{totalTasks++;if(task.done)completedTasks++;});
        if(d.status==='productive')productive++;
        else if(d.status==='missed')missed++;
        else if(d.status==='not-productive')notProductive++;
        (d.studySessions||[]).forEach(session=>{
          const minutes=Number(session.minutes);
          if(!Number.isFinite(minutes)||minutes<=0)return;
          const subjectName=String(session.subject||'General').trim()||'General';
          const subjectKey=subjectName.toLocaleLowerCase();
          const current=subjectMap.get(subjectKey)||{name:subjectName,minutes:0,sessions:0};
          current.minutes+=minutes;current.sessions++;
          subjectMap.set(subjectKey,current);
          dailyMinutes[iso]=(dailyMinutes[iso]||0)+minutes;
          totalMinutes+=minutes;sessionCount++;
          history.push({date:iso,subject:subjectName,minutes});
        });
      });
      const subjectRows=Array.from(subjectMap.values()).sort((a,b)=>b.minutes-a.minutes||a.name.localeCompare(b.name));
      const reviewed=productive+missed+notProductive;
      const consistency=reviewed?Math.round(productive/reviewed*100):0;
      const numberOfDays=new Date(mo.year,mo.month+1,0).getDate();
      const daysWithTime=Object.keys(dailyMinutes).length;
      const set=(id,value)=>{const target=el(id);if(target)target.textContent=String(value);};
      const completion=totalTasks?Math.round(completedTasks/totalTasks*100):0;

      set('analysisTotalTime',formatDuration(totalMinutes));
      set('analysisSessionCount',`${sessionCount} study ${sessionCount===1?'session':'sessions'}`);
      set('analysisTasks',`${completedTasks} / ${totalTasks}`);
      set('analysisTaskPercent',`${completion}% complete`);
      set('analysisProductive',productive);
      set('analysisMissed',`${missed} missed · ${notProductive} not productive`);
      set('analysisAverage',formatDuration(daysWithTime?Math.round(totalMinutes/daysWithTime):0));
      set('analysisConsistency',`${consistency}%`);
      set('analysisStatusSummary',reviewed?`${reviewed} day${reviewed===1?'':'s'} checked in`:'No days reviewed yet');
      set('statusProductive',productive);
      set('statusMissed',missed);
      set('statusNotProductive',notProductive);
      set('statusUnmarked',Math.max(0,numberOfDays-reviewed));
      const ring=el('analysisRing');
      if(ring)ring.style.background=`conic-gradient(var(--purple) ${consistency*3.6}deg,#303a55 ${consistency*3.6}deg)`;

      set('subjectCount',`${subjectRows.length} ${subjectRows.length===1?'subject':'subjects'}`);
      const bars=el('subjectBars'),empty=el('subjectEmpty');
      if(bars){
        bars.innerHTML=subjectRows.map((subject,index)=>{
          const share=totalMinutes?Math.round(subject.minutes/totalMinutes*100):0;
          return `<div class="subject-row" style="animation-delay:${Math.min(index*35,280)}ms"><div class="subject-top"><strong>${escapeHTML(subject.name)}</strong><span>${formatDuration(subject.minutes)} · ${share}%</span></div><div class="subject-track" role="progressbar" aria-label="${escapeHTML(subject.name)} share of study time" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${share}"><div class="subject-fill" data-width="${share}%"></div></div></div>`;
        }).join('');
        if(empty)empty.hidden=subjectRows.length>0;
        requestAnimationFrame(()=>bars.querySelectorAll('.subject-fill').forEach(bar=>{bar.style.width=bar.dataset.width||'0%';}));
      }

      const chart=el('dailyChart');
      if(chart){
        const maxMinutes=Math.max(1,...Object.values(dailyMinutes));
        chart.innerHTML=Array.from({length:numberOfDays},(_,index)=>{
          const day=index+1;
          const iso=`${mo.year}-${monthNumber}-${String(day).padStart(2,'0')}`;
          const minutes=dailyMinutes[iso]||0;
          const height=minutes?Math.max(4,Math.round(minutes/maxMinutes*78)):0;
          const label=(day===1||day%5===0||day===numberOfDays)?day:'';
          const duration=formatDuration(minutes);
          return `<div class="daily-bar-col" title="${escapeHTML(`${day} ${mo.label.split(' ')[0]} · ${duration}`)}" aria-label="${escapeHTML(`${dateLabel(iso)}: ${duration} studied`)}"><div class="daily-bar" data-height="${height}%" style="height:0"></div><span class="daily-bar-label">${label}</span></div>`;
        }).join('');
        requestAnimationFrame(()=>chart.querySelectorAll('.daily-bar').forEach(bar=>{bar.style.height=bar.dataset.height||'0%';}));
      }

      const insights=[];
      if(subjectRows.length){
        const top=subjectRows[0];
        insights.push({icon:'✦',title:`Top subject: ${top.name}`,text:`${formatDuration(top.minutes)} logged (${totalMinutes?Math.round(top.minutes/totalMinutes*100):0}% of this month's study time).`});
        const bestDay=Object.entries(dailyMinutes).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]))[0];
        if(bestDay)insights.push({icon:'▥',title:'Your longest study day',text:`${dateLabel(bestDay[0])} · ${formatDuration(bestDay[1])} recorded.`});
      }else{
        insights.push({icon:'◷',title:'Start your study log',text:'Open any day, add a subject and minutes, and your analysis will build automatically.'});
      }
      insights.push({icon:'✓',title:'Task completion',text:totalTasks?`${completedTasks} of ${totalTasks} tasks completed (${completion}%).`:'No tasks have been added for this month yet.'});
      insights.push({icon:'◎',title:'Monthly check-ins',text:reviewed?`${productive} productive, ${notProductive} not productive and ${missed} missed day${missed===1?'':'s'} recorded.`:'Mark a day as Productive or Not Productive to start tracking consistency.'});
      set('insightsList','');
      const insightList=el('insightsList');
      if(insightList)insightList.innerHTML=insights.map((item,index)=>`<div class="insight-item" style="animation-delay:${Math.min(index*45,180)}ms"><span class="insight-icon" aria-hidden="true">${item.icon}</span><div><strong>${escapeHTML(item.title)}</strong><p>${escapeHTML(item.text)}</p></div></div>`).join('');

      history.sort((a,b)=>b.date.localeCompare(a.date));
      set('historyCount',`${history.length} ${history.length===1?'entry':'entries'}`);
      const rows=el('historyRows'),historyEmpty=el('historyEmpty');
      if(rows)rows.innerHTML=history.map(item=>`<tr><td>${escapeHTML(parseISO(item.date).toLocaleDateString('en-IN',{day:'numeric',month:'short'}))}</td><td>${escapeHTML(item.subject)}</td><td>${escapeHTML(formatDuration(item.minutes))}</td></tr>`).join('');
      if(historyEmpty)historyEmpty.hidden=history.length>0;
    }
    select.addEventListener('change',()=>{const mo=MONTHS[Number(select.value)];if(mo&&!monthCanOpen(mo)){location.href='shop.html#months';return;}render();});
    render();
  }

  // Create a standards-compliant, uncompressed ZIP without relying on an external library.
  function makeZip(entries){
    const encoder=new TextEncoder();const crcTable=makeCrcTable();
    const crc32=bytes=>{let crc=0xffffffff;for(const b of bytes)crc=crcTable[(crc^b)&0xff]^(crc>>>8);return (crc^0xffffffff)>>>0;};
    const u16=n=>new Uint8Array([n&255,(n>>>8)&255]);const u32=n=>new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]);
    const join=arrays=>{const len=arrays.reduce((s,a)=>s+a.length,0),out=new Uint8Array(len);let off=0;arrays.forEach(a=>{out.set(a,off);off+=a.length;});return out;};
    const local=[],central=[];let offset=0;
    entries.forEach(entry=>{const name=encoder.encode(entry.name),bytes=entry.data,crc=crc32(bytes);
      const localHeader=join([u32(0x04034b50),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(bytes.length),u32(bytes.length),u16(name.length),u16(0),name,bytes]);local.push(localHeader);
      const centralHeader=join([u32(0x02014b50),u16(20),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(bytes.length),u32(bytes.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),name]);central.push(centralHeader);offset+=localHeader.length;
    });
    const centralBytes=join(central),centralOffset=offset;const end=join([u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),u32(centralBytes.length),u32(centralOffset),u16(0)]);
    return new Blob([...local,centralBytes,end],{type:'application/zip'});
  }
  function makeCrcTable(){const table=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);table[n]=c>>>0;}return table;}

  migrateData();applyMissedDaysOnVisit();
  if(document.body.dataset.page==='calendar')initCalendar();
  if(document.body.dataset.page==='day')initDay();
  if(document.body.dataset.page==='more')initMore();
  if(document.body.dataset.page==='analysis')initAnalysis();
})();