STUDYSPACE — DEVICE-ONLY EDITION (NO ACCOUNTS OR CLOUD SYNC)
=====================================================

PACKAGE CONTENTS
- Fix: owned themes now use the dedicated Apply Theme handler, and owned app logos use the dedicated Apply Logo handler. Previously both were incorrectly routed through the cosmetic-skin handler, causing “Could not apply that style.”
- Fix: applying a theme or logo now rolls back the selection if saving the wallet fails, rather than reporting success for an unsaved change.
- Front page calendar, daily planner, Monthly Analysis and More & Backups.
- Study Tools includes Pomodoro & Focus, Syllabus Tracker, Weekly Timetable, Flashcards, Exam Countdown and Global Search (paid tool unlocks remain available).
- Study Rewards page with 99 levels, daily/monthly missions and animated replacement daily challenges.
- Study Coin Shop with themes, app logos, 12 premium fonts, six cosmetic focus-timer skins, six analytics skins, six flashcard skins, six timetable skins, tool unlocks and calendar-month unlocks.
- Extra Rewards page plus a homework log on each daily planner date.
- Expandable grouped navigation on all main pages, including Extra Rewards.

STUDY COINS & DAILY TASKS
- Standard Study Rewards require an explicit Claim tap and are limited to once per task per local date. They continue to use the 99-level system.
- Level 1 starts with 12 visible daily challenges. Claimed tasks animate out and are replaced with additional focus challenges; more special challenges appear as the level rises.
- Extra Rewards homework-count milestones award 25 coins each for 1, 2, 3, 4 and 5 completed homework entries.
- Extra Rewards time milestones award 50 coins each for 5, 10, 25, 30, 45, 50, 60, 120 and 180 logged homework minutes. Minutes across all subject entries are combined; homework-count milestones require the entries to be marked complete.
- Extra Rewards are fixed-coin challenges and do not increase Study Rewards level or level progress. Claim IDs prevent repeated payouts on the same saved date.

SHOP
- Celestial Premium costs 5,000 coins; Legendary Cosmos costs 50,000. The premium character theme ladder is Spider-Man 200,000; Iron Man 500,000; Black Panther 800,000; Naruto 1,200,000; Zenitsu 2,000,000 coins. The Spider-Man, Black Panther, Naruto and Zenitsu full-page backgrounds use the reference images supplied for this site; Iron Man retains the red/gold reactor artwork.
- Premium fonts: 12 styles priced from 300 to 5,000 coins.
- Focus timer themes, analytics skins, flashcard skins and timetable skins are cosmetic only; each collection has six items priced from 500 to 50,000 coins (timer skins range from 1,000 to 10,000).
- Translucent Backgrounds is an ON/OFF Shop setting. When ON, supported panels use a glass-like translucent look across the site. It is a cosmetic preference.
- Buying applies the item; owned items can be re-applied after refresh. Purchases and selection state are saved in the same Study Coin wallet.
- Calendar months: October–December 2026 are included. 2027 month prices remain grouped at 200 / 500 / 1,000 / 1,500 coins per month by quarter.

TIMETABLE REMINDERS
- Reminders use device local time. Browser notifications require permission and Studyspace to be open or running in a supported installed browser. Static hosting cannot guarantee notifications after the browser is fully closed.

UPLOAD SAFELY
1. Export a fresh backup from the live site first.
2. Extract this ZIP and upload every website file directly into public_html, replacing same-named files.
3. Keep files in the same folder. Upload extra-rewards.html, extra-rewards.js, theme-ref-spiderman.jpg, theme-ref-zenitsu.jpg, theme-ref-naruto.jpg, theme-ref-black-panther.jpg and every other file in the ZIP to the root of public_html.
4. Do not clear browser storage. Existing planner key studyspace-planner-v1, Study Tools key studyspace-tools-v1 and wallet key studyspace-economy-v1 remain unchanged.
5. Use More & Backups to export/restore planner, Study Tools, wallet and homework data separately. Homework backups are named studyspace-homework-backup.json.
6. Full website and planner reset include homework logs. Clearing one chosen date in More & Backups also clears that date’s homework entries. Reset creates a local snapshot first; use its Restore button to return the saved values.

PRIVACY & STORAGE
- Planner, homework, Study Tools and Study Coin data stay in this device/browser's local storage. There is no login, account system, PHP API or cloud sync.
- Data does not automatically move to another device. Clearing app/browser storage or uninstalling the app may remove locally saved data, so export backups regularly.


VERSION 12 SHOP, CHARACTER BACKGROUNDS & CONSISTENCY FIXES
- Increased the five premium character-style themes from 200,000 to 2,000,000 Study Coins. Celestial Premium remains 5,000 coins and Legendary Cosmos remains 50,000 coins.
- Added the exact four reference background image files supplied in the conversation for Spider-Man, Zenitsu, Naruto and Black Panther; added them to both the web background and Shop previews. Iron Man remains a separate red/gold reactor theme.
- Updated Focus & Pomodoro Skins and Weekly Planner Skins labels; selected weekly-planner skins now style the full planner section and schedule rows.
- Improved typography consistency and mobile type scale.
- Expanded the Shop transparency switch effect across nested cards and page surfaces.
- Added new background assets to the Service Worker cache and progress export ZIP, bumped all static asset versions and the Service Worker cache to v12.
