// ================================================================
//  CORE.JS — Путь к Бессмертию v5.8.1
//  Данные, состояние, хранилище, культивация, баффы, экипировка
//  Зависимости: нет
//  Используется: ui.js, gameplay.js, profession.js
// ================================================================

// ==================== 1. ВЕРСИЯ И КОНСТАНТЫ ====================
const GAME_VERSION = "5.8.1";

const REALMS = [
    "Зарождение Ци", "Конденсация Ци", "Заложение Основания",
    "Формирование Ядра", "Зарождение Души", "Ковка Духа",
    "Обретение Закона", "Единение с Путём", "Обретение Дао"
];
const LAYER_NAMES = [
    "Начальный", "Ранний", "Углублённый", "Средний",
    "Устойчивый", "Высокий", "Поздний", "Пиковый", "Великий Совершенный"
];

const BASE_QI = 100;
const LAYER_MULT = 1.2;
const REALM_MULT = 3.0;
const STAT_MULT = 1.18;
const EXCHANGE_RATE = 400;

const OFFLINE_CAP_SECONDS = 86400;
const MAX_BUFFS = 5;

// ==================== 2. ДАННЫЕ: ПЕРСОНАЖ ====================
const ORIGINS = [
    { id:"orphan",   icon:"🏚️", name:"Сирота из глухой деревни",   desc:"Скрытый талант: изредка клики дают двойной эффект.", quote:"Никто не знает твоего рода. Но что-то в крови отзывается на древние печати…", mods:{ qps:1.00, click:1.00, req:1.00, luck:1.20 } },
    { id:"clan",     icon:"🏯", name:"Отпрыск захудалого клана",    desc:"Старт: +50 Ци и +1 духовный камень.",              quote:"Твой род когда-то был велик. Осталось лишь имя и долг.", mods:{ qps:1.10, click:1.00, req:1.00, startQi:50, startStones:1 } },
    { id:"sect",     icon:"⛩️", name:"Послушник разорённой секты",  desc:"+10% к притоку Ци, но клик слабее на 15%.",         quote:"Учитель погиб, защищая тебя.", mods:{ qps:1.10, click:0.85, req:1.00 } },
    { id:"wanderer", icon:"🏔️", name:"Странник из пустошей",        desc:"+20% к силе клика, но пассив слабее на 10%.",       quote:"Ты выжил там, где умирают даже звери.", mods:{ qps:0.90, click:1.20, req:1.00 } },
    { id:"heir",     icon:"👑", name:"Наследник павшего царства",   desc:"Требования к прорыву выше на 15%.",                 quote:"Трон разрушен. Ты отстроишь его заново.", mods:{ qps:1.00, click:1.00, req:1.15 } }
];
const ROOTS = [
    { id:"single",  icon:"💠", name:"Одиночный корень",  desc:"Редчайший. ×1.5 приток, ×1.2 клик, требования ×1.3.", quote:"Небеса отметили тебя.", mods:{ qps:1.50, click:1.20, req:1.30 } },
    { id:"dual",    icon:"🔷", name:"Двойной корень",    desc:"Умеренные бонусы: ×1.2 / ×1.1 / ×1.1.",               quote:"Две стихии спорят в тебе.", mods:{ qps:1.20, click:1.10, req:1.10 } },
    { id:"penta",   icon:"🔶", name:"Пятеричный корень", desc:"Обычный жребий.",                                     quote:"Пять стихий собраны воедино.", mods:{ qps:0.90, click:1.00, req:1.00 } },
    { id:"chaotic", icon:"🌀", name:"Хаотичный корень",  desc:"Нити судьбы спутаны.",                                quote:"Никто не предскажет твой путь.", mods:{ qps:1.00, click:1.00, req:1.00, chaotic:true } },
    { id:"void",    icon:"⚫", name:"Пустой корень",     desc:"Проклятие. ×0.7, но требования ×0.8.",                 quote:"В тебе нет места для Ци.", mods:{ qps:0.70, click:0.70, req:0.80, void:true } }
];
const NATURES = [
    { id:"water", icon:"💧", name:"Созерцательный", element:"Вода",   desc:"+15% к пассивному притоку.",       quote:"Тихий омут.", mods:{ qps:1.15 } },
    { id:"fire",  icon:"🔥", name:"Пламенный",      element:"Огонь",  desc:"+25% к силе клика. 5% шанс выжечь Ци.", quote:"Пламя не спрашивает.", mods:{ click:1.25, burnRisk:0.05 } },
    { id:"metal", icon:"⚙️", name:"Расчётливый",    element:"Металл", desc:"+20% к находкам камней.",         quote:"Каждый шаг выверен.", mods:{ stoneLuck:1.20 } },
    { id:"earth", icon:"⛰️", name:"Непреклонный",   element:"Земля",  desc:"+10% к шансу успеха при прорыве.", quote:"Камень не гнётся.", mods:{ breakthrough:1.10 } },
    { id:"wood",  icon:"🌳", name:"Мечтательный",   element:"Дерево", desc:"Редкие события вдвое чаще.",       quote:"Грёзы важнее реальности.", mods:{ rareEvent:2.00 } }
];

const SURNAMES = ["Вэй","Ло","Хань","Чэнь","Му","Су","Юй","Шэнь","Линь","Тан","Ся","Чу","Гу","Хуа","Цзинь"];
const GIVENS   = ["Лин","Цин","Юэ","Фэн","Янь","Мин","Лань","Юй","Сяо","Чэн","Жуй","Нин","Вэй","Синь"];

// ==================== 3. ДАННЫЕ: СТАРТОВЫЕ ТЕХНИКИ ====================
const STARTER_TECHS = [
    { id:"mortal_breath", icon:"🌱", name:"Дыхание смертного", baseQps:0.10, cost:5,  desc:"Простая техника. Медленный, но честный путь." },
    { id:"qi_flow",       icon:"🌊", name:"Поток Ци",          baseQps:0.35, cost:15, desc:"Сбалансированный поток. Заметный рост." },
    { id:"heaven_path",   icon:"⭐", name:"Тропа Небес",        baseQps:0.80, cost:40, desc:"Ускоренный путь. Для тех, кто не боится высоты." }
];

// ==================== 4. ДАННЫЕ: ТЕХНИКИ КУЛЬТИВАЦИИ ====================
const TECHNIQUES = [
    { id:"jade_breath",    icon:"🌬️", name:"Дыхание Нефрита",   desc:"Плавное дыхание, очищающее меридианы.", effectLabel:"к притоку Ци",    effectPerPart:0.05, costs:[3,6,12,24,48] },
    { id:"iron_meridians", icon:"⚙️", name:"Стальные меридианы", desc:"Укрепляет тело и дух.",                 effectLabel:"к силе клика",   effectPerPart:0.08, costs:[3,6,12,24,48] },
    { id:"stone_sense",    icon:"💠", name:"Чутьё на камни",     desc:"Обострённое восприятие.",               effectLabel:"к шансу дропа",  effectPerPart:0.10, costs:[5,15,45] },
    { id:"light_step",     icon:"👣", name:"Лёгкий шаг",         desc:"Ускоренное перемещение.",               effectLabel:"быстрее задания", effectPerPart:0.05, costs:[8,24,72] }
];
const TECH_COMPLETE = { jade_breath:5, iron_meridians:5, stone_sense:3, light_step:3 };

// ==================== 5. ДАННЫЕ: БОЕВЫЕ ТЕХНИКИ ====================
const COMBAT_TECHS = [
    { id:"m_strike", tier:"mortal", icon:"👊", name:"Прямой удар",       desc:"Простой, но честный.", priceGold:100, priceStones:0, reqRealm:0, stats:{atk:3,def:0,spd:1} },
    { id:"m_block",  tier:"mortal", icon:"🛡️", name:"Стойка защиты",     desc:"Принять удар.",         priceGold:150, priceStones:0, reqRealm:0, stats:{atk:1,def:4,spd:0} },
    { id:"m_dodge",  tier:"mortal", icon:"💨", name:"Уклонение",          desc:"Не начать бой.",       priceGold:200, priceStones:0, reqRealm:0, stats:{atk:1,def:1,spd:5} },
    { id:"m_grip",   tier:"mortal", icon:"✊", name:"Мёртвая хватка",    desc:"Не отпустить врага.",  priceGold:250, priceStones:0, reqRealm:0, stats:{atk:4,def:2,spd:0} },
    { id:"m_charge", tier:"mortal", icon:"💥", name:"Разгон",             desc:"Ударить всем телом.",  priceGold:350, priceStones:0, reqRealm:0, stats:{atk:6,def:1,spd:1} },
    { id:"m_breath", tier:"mortal", icon:"🫁", name:"Дыхание боя",       desc:"Держать ритм.",         priceGold:500, priceStones:0, reqRealm:0, stats:{atk:3,def:3,spd:3} },
    { id:"c_fire",    tier:"cultivator", icon:"🔥", name:"Ладонь Пламени",       desc:"Огонь из ладони.",  priceGold:500,  priceStones:5,  reqRealm:2, stats:{atk:10,def:2,spd:3} },
    { id:"c_water",   tier:"cultivator", icon:"💧", name:"Хлыст Воды",           desc:"Гибкая, режущая.",  priceGold:500,  priceStones:5,  reqRealm:2, stats:{atk:7,def:4,spd:5} },
    { id:"c_wind",    tier:"cultivator", icon:"🌪️", name:"Порыв Ветра",          desc:"Удар невидимый.",   priceGold:800,  priceStones:8,  reqRealm:2, stats:{atk:8,def:2,spd:8} },
    { id:"c_earth",   tier:"cultivator", icon:"⛰️", name:"Каменный панцирь",      desc:"Земля как броня.",  priceGold:800,  priceStones:8,  reqRealm:2, stats:{atk:4,def:12,spd:0} },
    { id:"c_thunder", tier:"cultivator", icon:"⚡", name:"Молния в Кулаке",       desc:"Быстро и больно.",  priceGold:1200, priceStones:12, reqRealm:3, stats:{atk:14,def:3,spd:6} },
    { id:"c_form",    tier:"cultivator", icon:"🔷", name:"Формация Пяти Печатей", desc:"Пять стихий.",      priceGold:2000, priceStones:20, reqRealm:4, stats:{atk:12,def:12,spd:6} },
    { id:"i_heaven", tier:"immortal", icon:"🌌", name:"Разрыв Небес",      desc:"Пространство рвётся.",   priceGold:5000,  priceStones:50,  reqRealm:6, stats:{atk:35,def:15,spd:10} },
    { id:"i_soul",   tier:"immortal", icon:"👁️", name:"Взгляд Пустоты",    desc:"Разум стирается.",       priceGold:5000,  priceStones:50,  reqRealm:6, stats:{atk:20,def:10,spd:20} },
    { id:"i_time",   tier:"immortal", icon:"⏳", name:"Остановка Мига",    desc:"Один удар до вздоха.",   priceGold:8000,  priceStones:80,  reqRealm:7, stats:{atk:30,def:15,spd:35} },
    { id:"i_dao",    tier:"immortal", icon:"☯️", name:"Удар Истинного Дао", desc:"Не техника, а проявление.", priceGold:15000, priceStones:150, reqRealm:8, stats:{atk:60,def:40,spd:30} }
];

// ==================== 6. ДАННЫЕ: ЗАДАНИЯ ====================
const QUEST_SHORT = [
    { id:"dew",   icon:"🌙", name:"Собрать росу с лунных листьев",  desc:"На рассвете капли хранят силу ночи.", duration:30, base:1 },
    { id:"wood",  icon:"🪵", name:"Нарубить хвороста для костра",   desc:"Простая работа.",                     duration:30, base:1 },
    { id:"herbs", icon:"🌿", name:"Собрать травы у подножия",       desc:"Лекари платят за редкие стебли.",     duration:30, base:1 },
    { id:"water", icon:"💧", name:"Принести воды из источника",     desc:"Родник бьёт в чаще.",                 duration:30, base:1 },
    { id:"fish",  icon:"🎣", name:"Проверить сети рыбака",          desc:"Старик не может выйти к реке.",       duration:30, base:1 },
    { id:"horse", icon:"🐎", name:"Напоить коня у ручья",           desc:"Животное с норовом.",                 duration:30, base:1 }
];
const QUEST_MEDIUM = [
    { id:"caravan", icon:"🛡️", name:"Охранять караван на перевале",    desc:"Торговцы боятся разбойников.", duration:60, base:2 },
    { id:"escort",  icon:"🚶", name:"Сопроводить странника до деревни", desc:"Слепой старик не дойдёт сам.", duration:60, base:2 },
    { id:"watch",   icon:"🏯", name:"Обойти дозором окраины секты",    desc:"Скучная работа.",              duration:60, base:2 },
    { id:"clear",   icon:"⛰️", name:"Разобрать завал на горной тропе", desc:"Камни упали после грозы.",     duration:60, base:2 },
    { id:"altar",   icon:"🕯️", name:"Помочь старейшине с алтарём",     desc:"Старик слаб.",                 duration:60, base:2 }
];
const QUEST_LONG = [
    { id:"pagoda", icon:"🏛️", name:"Проникнуть в заброшенную пагоду",  desc:"Тени прошлого и камни.",       duration:180, base:3 },
    { id:"cave",   icon:"👻", name:"Очистить пещеру от духов",         desc:"Духи злые, жемчужины редки.",  duration:180, base:3 },
    { id:"mine",   icon:"⛏️", name:"Добыть руду в глубокой шахте",     desc:"Глубоко, темно, пыльно.",      duration:180, base:3 },
    { id:"scroll", icon:"📜", name:"Отыскать свиток в развалинах",     desc:"Бумага или сила.",             duration:180, base:3 },
    { id:"forest", icon:"🌲", name:"Пройти испытание в лесу иллюзий",  desc:"Лес показывает страхи.",       duration:180, base:3 }
];

// ==================== 7. ДАННЫЕ: ЛОКАЦИИ ПУТЕШЕСТВИЙ ====================
const LOCATIONS = [
    { id:"forest",   icon:"🌲", name:"Ближний лес",       desc:"Тихие тропы, знакомые с детства. Опасности почти нет.", duration:120,  reqRealm:0, rewards:{gold:[30,80],    stones:[0,1]},   risk:0    },
    { id:"mountain", icon:"⛰️", name:"Горный перевал",     desc:"Ветреные тропы, редкие звери.",                        duration:300,  reqRealm:0, rewards:{gold:[80,200],   stones:[1,2]},   risk:0.10 },
    { id:"pagoda",   icon:"🏯", name:"Заброшенная пагода", desc:"Тени прошлого. Камни и ловушки.",                       duration:600,  reqRealm:2, rewards:{gold:[200,500],  stones:[2,4]},   risk:0.20 },
    { id:"ruins",    icon:"🌌", name:"Древние руины",      desc:"Место, где время искажается.",                           duration:1200, reqRealm:4, rewards:{gold:[500,1200], stones:[5,10]},  risk:0.35 }
];

// ==================== 8. ДАННЫЕ: ВСТУПЛЕНИЯ ====================
const INTRO_ORIGIN = {
    orphan:   ["Ты родился в деревне, которой нет на картах.", "Ты помнишь только холод и голод.", "У тебя нет ни рода, ни дома."],
    clan:     ["Родовое поместье обветшало.", "В зале твоего клана висит портрет.", "Твой род известен только старикам."],
    sect:     ["Учитель погиб у тебя на глазах.", "Секту сожгли за одну ночь.", "Ты учился у великого человека."],
    wanderer: ["Пустоши не прощают ошибок.", "Ты шёл по мёртвой земле тридцать дней.", "В пустошах не говорят лишних слов."],
    heir:     ["Царство твоё лежит в руинах.", "Ты последний в роду.", "Тебе прочили трон. Ты получил пепел."]
};
const INTRO_ROOT = {
    single:  ["В первую ночь ты увидел свой корень во сне.", "Тебе сказали: одиночный корень — раз в сто лет.", "Твой корень — как одинокая звезда."],
    dual:    ["Две нити тянутся сквозь тебя.", "Огонь и вода в твоих меридианах.", "Между двумя стихиями — узкий мост."],
    penta:   ["Пять стихий смешались.", "Тебе не досталось блеска.", "Обычный корень — говорят люди."],
    chaotic: ["Ты чувствуешь движение, но не можешь предсказать.", "Нити судьбы спутаны.", "Твоё тело — как небо перед грозой."],
    void:    ["Внутри тебя — тишина.", "Ци не идёт к тебе, как к другим.", "Небо не смотрит на тебя."]
};
const INTRO_NATURE = {
    water: ["Ты смотрел на воду долго.", "Тихий омут — твой учитель.", "Твой разум — как гладь озера."],
    fire:  ["Ты вспыхиваешь раньше, чем думаешь.", "В твоей крови — пламя.", "Каждый вдох — как искра."],
    metal: ["Ты всегда считал шаги до первого.", "Твой разум холоден, как клинок.", "В твоих глазах — расчёт."],
    earth: ["Тебя пытались сломать. Ты стоишь.", "Ты как гора.", "В детстве тебя называли тупым."],
    wood:  ["Ты видишь сны наяву.", "Ты — как росток сквозь асфальт.", "Мечта — тоже сила."]
};
const INTRO_CLOSING = [
    "Ты садишься в позу лотоса. Первый вдох — и Ци отзывается.",
    "Ты закрываешь глаза. Один вдох. Один выдох. Путь начинается.",
    "Ты касаешься земли ладонями. Она холодна. Ты готов."
];

// ==================== 9. ДАННЫЕ: БАФФЫ ====================
const BUFFS_DATA = {
    wound_powder: { icon: "🌿", name: "Порошок от ран",     qps: 0.05, duration: 300,  desc: "+5% к притоку Ци" },
    warm_salve:   { icon: "🧴", name: "Согревающая мазь",   qps: 0.10, duration: 600,  desc: "+10% к притоку Ци" },
    vigor_brew:   { icon: "🍵", name: "Отвар бодрости",     qps: 0.20, duration: 900,  desc: "+20% к притоку Ци" },
    antidote:     { icon: "🧪", name: "Противоядие",         qps: 0.00, duration: 60,   desc: "Очищает тело" },
    sleep_powder: { icon: "💊", name: "Снотворный порошок", qps: 0.40, duration: 1800, desc: "+40% к притоку Ци" },
    // Талисманы (v5.8.1) — 3 баффа, действуют как снадобья
    clarity_seal:   { icon: "📜", name: "Талисман ясности",   qps: 0.25, duration: 900,  desc: "+25% к притоку Ци, 15 мин" },
    fortune_seal:   { icon: "📜", name: "Талисман удачи",     qps: 0.40, duration: 600,  desc: "+40% к притоку Ци, 10 мин" },
    steadfast_seal: { icon: "📜", name: "Талисман стойкости", qps: 0.30, duration: 1800, desc: "+30% к притоку Ци, 30 мин" }
};

// Талисманы (v5.8.1): 3 — временные баффы, 1 — щит, 1 — мгновенно
const TALISMAN_IDS = ["clarity_seal", "fortune_seal", "calm_seal", "steadfast_seal", "enlight_seal"];
const TALISMAN_NAMES = {
    clarity_seal:   "Талисман ясности",
    fortune_seal:   "Талисман удачи",
    calm_seal:      "Талисман покоя",
    steadfast_seal: "Талисман стойкости",
    enlight_seal:   "Талисман просветления"
};

// ==================== 10. ДАННЫЕ: ЭКИПИРОВКА ====================
const WEAPON_STATS = {
    dagger:     { atk: 5,  type: "weapon", icon: "🗡️", name: "Кинжал" },
    axe:        { atk: 12, type: "weapon", icon: "🪓", name: "Топор" },
    rune_blade: { atk: 25, type: "weapon", icon: "⚔️", name: "Рунный клинок" }
};
const ARMOR_STATS = {
    chainmail: { def: 8,  type: "armor", icon: "🛡️", name: "Кольчуга" },
    shield:    { def: 14, type: "armor", icon: "🛡️", name: "Щит" }
};

// ==================== 11. СОСТОЯНИЕ ====================
let qi = 0.0;
let qiPerSecond = 0.1;
let manualPower = 1.0;
let currentStageIndex = 0;

const targets = [];
(function generateTargets() {
    let c = BASE_QI;
    for (let r = 0; r < 9; r++) {
        for (let l = 0; l < 9; l++) {
            targets.push(Math.round(c));
            c *= LAYER_MULT;
        }
        c = targets[targets.length - 1] * REALM_MULT;
    }
})();

let _baseMods = null;

// ==================== 12. ХЕЛПЕРЫ ====================
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function randInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }

function stonesWord(n) {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return "камень";
    if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return "камня";
    return "камней";
}
function goldWord(n) {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return "золотой";
    if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return "золотых";
    return "золота";
}
function daysWord(n) {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return "день";
    if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return "дня";
    return "дней";
}
function ageWord(n) {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return "год";
    if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return "года";
    return "лет";
}
function formatDuration(sec) {
    if (sec < 60) return sec + " сек";
    const m = Math.floor(sec / 60), s = sec % 60;
    return s === 0 ? m + " мин" : m + " мин " + s + " сек";
}
function formatRemaining(ms) {
    if (ms < 0) ms = 0;
    const s = Math.ceil(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const r = s % 60;
    if (h > 0) return h + "ч " + m + "м";
    if (m > 0) return m + ":" + (r < 10 ? "0" + r : r);
    return r + " сек";
}
function formatDate(ts) {
    if (!ts) return "неизвестно";
    try { return new Date(ts).toLocaleDateString("ru-RU", { day:"numeric", month:"long", year:"numeric" }); }
    catch (e) { return "неизвестно"; }
}
function daysSince(ts) { return ts ? Math.max(0, Math.floor((Date.now() - ts) / 86400000)) : 0; }
function randomName() { return pick(SURNAMES) + " " + pick(GIVENS); }

// ==================== 13. ХРАНИЛИЩЕ: ПЕРСОНАЖ ====================
function getCharacter() {
    try {
        const r = localStorage.getItem("dao_character");
        return r ? JSON.parse(r) : null;
    } catch (e) { return null; }
}
function saveCharacterObj(o) {
    try { localStorage.setItem("dao_character", JSON.stringify(o)); } catch (e) {}
}
function isCultivator() {
    const ch = getCharacter();
    return !!(ch && ch.isCultivator);
}
function getRealmIdx() { return Math.floor(currentStageIndex / 9); }
function isHighRealm() { return currentStageIndex >= 27; }

// ==================== 14. ХРАНИЛИЩЕ: КАМНИ ====================
function getStones() { const c = getCharacter(); return c ? (c.stones || 0) : 0; }
function setStones(n) {
    const c = getCharacter();
    if (!c) return 0;
    c.stones = Math.max(0, n);
    saveCharacterObj(c);
    if (typeof renderStoneLine === "function") renderStoneLine();
    return c.stones;
}
function addStones(n) { return setStones(getStones() + n); }
function spendStones(n) {
    if (getStones() < n) return false;
    setStones(getStones() - n);
    return true;
}

// ==================== 15. ХРАНИЛИЩЕ: ЗОЛОТО ====================
function getGold() { const c = getCharacter(); return c ? (c.gold || 0) : 0; }
function setGold(n) {
    const c = getCharacter();
    if (!c) return 0;
    c.gold = Math.max(0, n);
    saveCharacterObj(c);
    if (typeof renderGoldLine === "function") renderGoldLine();
    return c.gold;
}
function addGold(n) { return setGold(getGold() + n); }
function spendGold(n) {
    if (getGold() < n) return false;
    setGold(getGold() - n);
    return true;
}

// ==================== 16. ХРАНИЛИЩЕ: ТЕХНИКИ КУЛЬТИВАЦИИ ====================
function getTechData() {
    try { return JSON.parse(localStorage.getItem("dao_techniques") || "{}"); }
    catch (e) { return {}; }
}
function setTechData(o) {
    try { localStorage.setItem("dao_techniques", JSON.stringify(o)); } catch (e) {}
}
function getTechParts(id) { return getTechData()[id] || 0; }
function setTechParts(id, n) {
    const d = getTechData();
    d[id] = n;
    setTechData(d);
}
function isTechComplete(id) { return getTechParts(id) >= (TECH_COMPLETE[id] || 999); }

function getTechBonuses() {
    return {
        qpsMult:       1 + getTechParts("jade_breath")    * 0.05,
        clickMult:     1 + getTechParts("iron_meridians") * 0.08,
        stoneLuckMult: 1 + getTechParts("stone_sense")    * 0.10,
        questTimeMult: Math.max(0.5, 1 - getTechParts("light_step") * 0.05)
    };
}

// ==================== 17. ХРАНИЛИЩЕ: БОЕВЫЕ ТЕХНИКИ ====================
function getCombatOwned() {
    try { return JSON.parse(localStorage.getItem("dao_combat_owned") || "{}"); }
    catch (e) { return {}; }
}
function setCombatOwned(o) {
    try { localStorage.setItem("dao_combat_owned", JSON.stringify(o)); } catch (e) {}
}
function isCombatOwned(id) { return !!getCombatOwned()[id]; }
function getCombatMastery(id) {
    const o = getCombatOwned()[id];
    return (o && typeof o.mastery === "number") ? o.mastery : 0;
}
function setCombatMastery(id, v) {
    const o = getCombatOwned();
    if (!o[id]) return 0;
    o[id].mastery = Math.max(0, Math.min(100, v));
    setCombatOwned(o);
    return o[id].mastery;
}

// ==================== 18. ХРАНИЛИЩЕ: ЗАДАНИЕ ====================
function getQuest() {
    try { return JSON.parse(localStorage.getItem("dao_v446_quest") || "null"); }
    catch (e) { return null; }
}
function setQuest(q) {
    try {
        if (q) localStorage.setItem("dao_v446_quest", JSON.stringify(q));
        else localStorage.removeItem("dao_v446_quest");
    } catch (e) {}
}
function hasQuest() { return !!getQuest(); }

// ==================== 19. ХРАНИЛИЩЕ: ПУТЕШЕСТВИЕ ====================
function getTravel() {
    try { return JSON.parse(localStorage.getItem("dao_v461_travel") || "null"); }
    catch (e) { return null; }
}
function setTravel(t) {
    try {
        if (t) localStorage.setItem("dao_v461_travel", JSON.stringify(t));
        else localStorage.removeItem("dao_v461_travel");
    } catch (e) {}
}
function hasTravel() { return !!getTravel(); }

// ==================== 20. ХРАНИЛИЩЕ: ИСТОРИЯ ПУТЕШЕСТВИЙ ====================
function getTravelHistory() {
    try { return JSON.parse(localStorage.getItem("dao_travel_history") || "[]"); }
    catch (e) { return []; }
}
function addTravelHistory(rec) {
    const h = getTravelHistory();
    h.unshift(rec);
    if (h.length > 20) h.length = 20;
    try { localStorage.setItem("dao_travel_history", JSON.stringify(h)); } catch (e) {}
}

// ==================== 21. ХРАНИЛИЩЕ: БАФФЫ ====================
function getBuffs() {
    const ch = getCharacter();
    if (!ch) return [];
    if (!Array.isArray(ch.buffs)) return [];
    const now = Date.now();
    const active = ch.buffs.filter(function(b) { return b.endsAt > now; });
    if (active.length !== ch.buffs.length) {
        ch.buffs = active;
        saveCharacterObj(ch);
    }
    return active;
}
function saveBuffs(list) {
    const ch = getCharacter();
    if (!ch) return;
    ch.buffs = list;
    saveCharacterObj(ch);
}
function addBuff(id) {
    const data = BUFFS_DATA[id];
    if (!data) return false;

    const current = getBuffs();
    const existing = current.find(function(b) { return b.id === id; });

    if (!existing && current.length >= MAX_BUFFS) {
        return { ok: false, reason: "limit" };
    }

    const now = Date.now();
    let newList;
    if (existing) {
        existing.endsAt = now + data.duration * 1000;
        newList = current;
    } else {
        newList = current.concat([{
            id: id,
            name: data.name,
            icon: data.icon,
            qpsMult: 1 + data.qps,
            endsAt: now + data.duration * 1000
        }]);
    }
    saveBuffs(newList);
    return { ok: true };
}

// ==================== 22. ХРАНИЛИЩЕ: ЭКИПИРОВКА ====================
function getEquipped() {
    const ch = getCharacter();
    if (!ch) return { weapon: null, armor: null };
    return {
        weapon: ch.equippedWeapon || null,
        armor: ch.equippedArmor || null
    };
}
function setEquipped(type, id) {
    const ch = getCharacter();
    if (!ch) return;
    if (type === "weapon") ch.equippedWeapon = id;
    else if (type === "armor") ch.equippedArmor = id;
    saveCharacterObj(ch);
}
function getEquipBonus() {
    const eq = getEquipped();
    const w = eq.weapon ? WEAPON_STATS[eq.weapon] : null;
    const a = eq.armor ? ARMOR_STATS[eq.armor] : null;
    return {
        atk: w ? (w.atk || 0) : 0,
        def: a ? (a.def || 0) : 0
    };
}

// ==================== 23. МОДИФИКАТОРЫ ПЕРСОНАЖА ====================
function combineMods(ch) {
    const r = { qps:1, click:1, req:1, startQi:0, startStones:0, luck:1, stoneLuck:1, breakthrough:1, rareEvent:1, burnRisk:0 };
    [ch.origin.mods || {}, ch.root.mods || {}, ch.nature.mods || {}].forEach(function(m) {
        if (m.qps != null) r.qps *= m.qps;
        if (m.click != null) r.click *= m.click;
        if (m.req != null) r.req *= m.req;
        if (m.startQi) r.startQi += m.startQi;
        if (m.startStones) r.startStones += m.startStones;
        if (m.luck != null) r.luck *= m.luck;
        if (m.stoneLuck != null) r.stoneLuck *= m.stoneLuck;
        if (m.breakthrough != null) r.breakthrough *= m.breakthrough;
        if (m.rareEvent != null) r.rareEvent *= m.rareEvent;
        if (m.burnRisk) r.burnRisk = Math.max(r.burnRisk, m.burnRisk);
    });
    return r;
}
function rebuildTargets(reqMult) {
    targets.length = 0;
    let c = BASE_QI;
    for (let r = 0; r < 9; r++) {
        for (let l = 0; l < 9; l++) {
            targets.push(Math.round(c * reqMult));
            c *= LAYER_MULT;
        }
        c = targets[targets.length - 1] * REALM_MULT / reqMult;
    }
}

function getCurrentAge(ch) {
    if (!ch) return 0;
    let base = ch.baseAge;
    if (typeof base !== "number") {
        const ranges = { orphan:[15,18], clan:[16,20], sect:[17,22], wanderer:[18,25], heir:[16,20] };
        const r = ranges[ch.origin && ch.origin.id] || [16, 22];
        base = r[0] + Math.floor(Math.random() * (r[1] - r[0] + 1));
        ch.baseAge = base;
        saveCharacterObj(ch);
    }
    const days = Math.max(0, Math.floor((Date.now() - (ch.rolledAt || Date.now())) / 86400000));
    return base + Math.floor(days / 30);
}

// ==================== 24. ЛОГИКА КУЛЬТИВАЦИИ ====================
function passiveLoop() {
    if (!isCultivator()) return;
    if (hasQuest() || hasTravel()) return;
    if (typeof window.daoHasProfessionActivity === "function" && window.daoHasProfessionActivity()) return;
    qi += qiPerSecond / 10;
    if (typeof updateUI === "function") updateUI();
}

function recalcStats() {
    const baseQps = 0.1 * Math.pow(STAT_MULT, currentStageIndex);
    const baseClick = 1.0 * Math.pow(STAT_MULT, currentStageIndex);
    const ch = getCharacter();

    if (!ch || !ch.isCultivator) {
        qiPerSecond = 0;
        manualPower = 0;
        return;
    }

    let baseMult = 1;
    const starter = STARTER_TECHS.find(function(t) { return t.id === ch.starterTech; });
    if (starter) baseMult = starter.baseQps / 0.1;

    const baseMods = _baseMods || { qps:1, click:1 };
    const tech = getTechBonuses();

    let buffsMult = 1;
    getBuffs().forEach(function(b) { buffsMult *= (b.qpsMult || 1); });

    const qpsMult = (baseMods.qps || 1) * tech.qpsMult * baseMult * buffsMult;
    const clickMult = (baseMods.click || 1) * tech.clickMult;

    qiPerSecond = +(baseQps * qpsMult).toFixed(2);
    manualPower = +(baseClick * clickMult).toFixed(1);
}
window.recalcStats = recalcStats;

function attemptBreakthrough() {
    if (!isCultivator()) {
        addLog("Ты ещё не культивируешь. Купи стартовую технику у менялы.", true);
        return;
    }
    if (hasQuest() || hasTravel()) return;
    if (typeof window.daoHasProfessionActivity === "function" && window.daoHasProfessionActivity()) return;
    if (currentStageIndex >= 80) return;
    const need = targets[currentStageIndex];
    if (qi < need) return;

    qi -= need;
    currentStageIndex++;
    recalcStats();
    const realm = REALMS[Math.floor(currentStageIndex / 9)];
    const layer = LAYER_NAMES[currentStageIndex % 9];
    addLog("⚡ ПРОРЫВ! Ты достиг: [" + realm + " — " + layer + "]!", true);

    if (getTechParts("stone_sense") >= 3) {
        addStones(1);
        addLog("💠 Чутьё на камни: +1 камень за прорыв.", true);
    }
    rollBreakthroughStone(currentStageIndex);
    saveGame();
    if (typeof updateUI === "function") updateUI();
}

// ==================== 25. ДРОП КАМНЕЙ ====================
const DROP_NORMAL_MSGS = [
    "💠 Под пальцами образовался духовный камень.",
    "💠 Из воздуха материализовался духовный камень.",
    "💠 Земля вздрогнула — камень выпал из ниоткуда.",
    "💠 Медитация оставила после себя дар.",
    "💠 Капля Ци застыла и обратилась в камень."
];
const DROP_REALM_MSGS = [
    "💠💠 Смена царства сотрясла небеса. Два камня упали.",
    "💠💠 Небо ответило на твой прорыв. Двойной дар.",
    "💠💠 Прежнее царство отпустило тебя, отдав два камня."
];

function rollBreakthroughStone(newStageIdx) {
    const baseMods = _baseMods || {};
    const tech = getTechBonuses();
    const stoneLuck = (baseMods.stoneLuck || 1) * tech.stoneLuckMult;
    const luck = baseMods.luck || 1;

    const isRealmChange = (newStageIdx % 9 === 0) && newStageIdx > 0;
    const isHighStage = newStageIdx >= 27;

    if (isRealmChange) {
        const amount = Math.random() < 0.5 ? 2 : 1;
        addStones(amount);
        if (amount === 2) addLog(pick(DROP_REALM_MSGS), true);
        else addLog("💠 Новое царство дарует камень.", true);
        return amount;
    }
    const baseChance = isHighStage ? 0.30 : 0.20;
    if (Math.random() >= baseChance * stoneLuck * luck) return 0;
    if (Math.random() < 0.25) {
        addStones(2);
        addLog(pick(DROP_REALM_MSGS), true);
        return 2;
    }
    addStones(1);
    addLog(pick(DROP_NORMAL_MSGS), true);
    return 1;
}

// ==================== 26. ЛОГ ====================
function addLog(message, isBreakthrough) {
    const logBox = document.getElementById("log");
    if (!logBox) return;
    const entry = document.createElement("div");
    entry.className = "log-entry" + (isBreakthrough ? " log-breakthrough" : "");
    let msg = String(message == null ? "" : message);
    if (msg.length > 200) msg = msg.slice(0, 197) + "...";
    entry.textContent = msg;
    logBox.prepend(entry);
    while (logBox.children.length > 100) {
        logBox.removeChild(logBox.lastChild);
    }
}
window.addLog = addLog;

// ==================== 27. СОХРАНЕНИЕ ====================
function saveGame() {
    const data = { qi: qi, stageIndex: currentStageIndex, lastSaveTime: Date.now(), version: GAME_VERSION };
    try { localStorage.setItem("cultivation_save_v2", JSON.stringify(data)); } catch (e) {}
    const ind = document.getElementById("save-status");
    if (ind) {
        ind.style.opacity = "0.7";
        setTimeout(function() { ind.style.opacity = "0"; }, 800);
    }
}

function loadGame() {
    let raw = null;
    try { raw = localStorage.getItem("cultivation_save_v2"); } catch (e) {}
    if (!raw) { try { raw = localStorage.getItem("cultivation_save"); } catch (e) {} }
    if (!raw) {
        addLog("Ты открыл глаза в хижине. В воздухе едва ощутимы нити Ци.");
        return;
    }
    try {
        const data = JSON.parse(raw);
        currentStageIndex = Math.min(data.stageIndex || 0, 80);
        recalcStats();
        const rawOffline = Math.max(0, Math.floor((Date.now() - (data.lastSaveTime || Date.now())) / 1000));
        const offlineSeconds = Math.min(rawOffline, OFFLINE_CAP_SECONDS);
        if (offlineSeconds > 5) {
            const mb = getTechParts("jade_breath") >= 5 ? 1.25 : 1.0;
            const gain = offlineSeconds * qiPerSecond * mb;
            qi = (data.qi || 0) + gain;
            const minutes = Math.floor(offlineSeconds / 60);
            const timeText = minutes > 0 ? minutes + " мин." : offlineSeconds + " сек.";
            const bonusNote = mb > 1 ? " (×1.25 от Дыхания Нефрита)" : "";
            const capNote = (rawOffline > OFFLINE_CAP_SECONDS) ? " [потолок 24ч]" : "";
            addLog("Ты вернулся из медитации (" + timeText + capNote + "). Накоплено " + gain.toFixed(1) + " Ци" + bonusNote + ".");
        } else {
            qi = data.qi || 0;
            addLog("Ты открыл глаза и продолжил циркуляцию Ци.");
        }
    } catch (e) { console.error("loadGame", e); }
}

function resetSave() {
    if (!confirm("Начать заново?\n\nБудет сброшено:\n• Прогресс культивации\n• Персонаж\n• Камни и золото\n• Все техники\n• Онбординг\n\nНастройки ориентации останутся.")) return;
    [
        "cultivation_save_v2", "cultivation_save",
        "dao_character", "dao_techniques", "dao_onboarding_ack",
        "dao_combat_owned", "dao_v446_quest", "dao_v461_travel", "dao_travel_history"
    ].forEach(function(k) {
        try { localStorage.removeItem(k); } catch (e) {}
    });
    location.reload();
}

// ==================== ЭКСПОРТ ДЛЯ UI ====================
window.daoCore = {
    GAME_VERSION: GAME_VERSION,
    getBuffs: getBuffs,
    saveBuffs: saveBuffs,
    addBuff: addBuff,
    getEquipped: getEquipped,
    setEquipped: setEquipped,
    getEquipBonus: getEquipBonus,
    BUFFS_DATA: BUFFS_DATA,
    WEAPON_STATS: WEAPON_STATS,
    ARMOR_STATS: ARMOR_STATS,
    TALISMAN_IDS: TALISMAN_IDS,
    TALISMAN_NAMES: TALISMAN_NAMES
};