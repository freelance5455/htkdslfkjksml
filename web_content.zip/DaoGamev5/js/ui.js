// ================================================================
//  UI.JS — Путь к Бессмертию v5.8.1
//  Интерфейс, меню, настройки, патчи, экспорт/импорт, онбординг,
//  баффы, экипировка, талисманы
//  Зависимости: core.js
//  Используется: gameplay.js, profession.js
// ================================================================

// ==================== 1. ОБНОВЛЕНИЕ ГЛАВНОГО UI ====================
function updateUI() {
    const ch = getCharacter();
    if (!ch) return;
    const cultivator = !!ch.isCultivator;
    const active = hasQuest() || hasTravel();
    const need = targets[currentStageIndex] || 100;

    const setText = function(id, val) {
        const el = document.getElementById(id);
        if (el && el.textContent !== String(val)) el.textContent = val;
    };
    const setWidth = function(id, pct) {
        const el = document.getElementById(id);
        if (el) el.style.width = pct + "%";
    };

    if (!cultivator) {
        setText("realm-text", "Смертный");
        setText("stage-text", "—");
        setText("qi-count", "—");
        setText("qi-target", "—");
        setText("qi-rate", "нужна техника культивации");
        setWidth("qi-progress", 0);
    } else {
        const realmIndex = Math.floor(currentStageIndex / 9);
        const layerIndex = currentStageIndex % 9;
        setText("realm-text", REALMS[realmIndex]);
        setText("stage-text", LAYER_NAMES[layerIndex]);
        setText("qi-count", qi.toFixed(1));
        setText("qi-target", need.toLocaleString("ru-RU"));
        setText("qi-rate", "+" + qiPerSecond.toFixed(2) + " / сек");
        setWidth("qi-progress", Math.min((qi / need) * 100, 100));
    }

    // Кнопка прорыва (D-10: сброс текста при потере .ready)
    const btnB = document.getElementById("btn-breakthrough");
    if (btnB) {
        const defaultText = "Совершить прорыв";
        if (!cultivator || currentStageIndex >= 80 || active) {
            btnB.classList.remove("ready");
            if (currentStageIndex >= 80) btnB.textContent = "Вы достигли вершины";
            else if (btnB.textContent !== defaultText && btnB.textContent.indexOf("Прорыв →") === 0) btnB.textContent = defaultText;
        } else if (qi >= need) {
            btnB.classList.add("ready");
            const nR = REALMS[Math.floor((currentStageIndex + 1) / 9)];
            const nL = LAYER_NAMES[(currentStageIndex + 1) % 9];
            const txt = "Прорыв → " + nR + " · " + nL;
            if (btnB.textContent !== txt) btnB.textContent = txt;
        } else {
            btnB.classList.remove("ready");
            if (btnB.textContent.indexOf("Прорыв →") === 0) btnB.textContent = defaultText;
        }
    }

    renderStoneLine();
    renderGoldLine();
    renderCharLine();
    renderBuffsPlaque();
    renderEquipLine();
    renderShieldLine();
    refreshActions();
    if (typeof renderQuestPlaque === "function") renderQuestPlaque();
    if (typeof renderTravelPlaque === "function") renderTravelPlaque();
}
window.updateUI = updateUI;

// ==================== 2. СТРОКИ РЕСУРСОВ ====================
function renderStoneLine() {
    const card = document.getElementById("dao-status-card");
    if (!card) return;
    const ch = getCharacter();
    let line = document.getElementById("dao-stone-line");
    if (!ch) { if (line) line.remove(); return; }
    if (!line) {
        line = document.createElement("div");
        line.id = "dao-stone-line";
        line.innerHTML = '<span>💠 Духовные камни:</span><span class="dao-stone-value" id="dao-stone-count">0</span>';
        const bar = card.querySelector(".progress-bar-bg");
        if (bar && bar.parentNode === card) bar.after(line);
        else card.appendChild(line);
    }
    const c = line.querySelector("#dao-stone-count");
    if (c) {
        const v = (ch.stones || 0).toLocaleString("ru-RU");
        if (c.textContent !== v) c.textContent = v;
    }
}

function renderGoldLine() {
    const card = document.getElementById("dao-status-card");
    if (!card) return;
    const ch = getCharacter();
    let line = document.getElementById("dao-gold-line");
    if (!ch) { if (line) line.remove(); return; }
    if (!line) {
        line = document.createElement("div");
        line.id = "dao-gold-line";
        line.innerHTML = '<span>💰 Золото:</span><span class="dao-gold-value" id="dao-gold-count">0</span>';
        const stone = document.getElementById("dao-stone-line");
        if (stone) stone.after(line);
        else card.appendChild(line);
    }
    const c = line.querySelector("#dao-gold-count");
    if (c) {
        const v = (ch.gold || 0).toLocaleString("ru-RU");
        if (c.textContent !== v) c.textContent = v;
    }
}

function renderCharLine() {
    const card = document.getElementById("dao-status-card");
    if (!card) return;
    const ch = getCharacter();
    let line = document.getElementById("dao-char-line");
    if (!ch) { if (line) line.remove(); return; }

    const originName = (ch.origin && ch.origin.name) || "неизвестно";
    const natureEl = (ch.nature && ch.nature.element) || "";
    const natureName = (ch.nature && ch.nature.name) || "";
    const name = ch.name || "Безымянный";

    if (!line) {
        line = document.createElement("div");
        line.id = "dao-char-line";
        card.insertBefore(line, card.firstChild);
    }
    const parts = [name, originName];
    if (natureEl) parts.push(natureEl);
    if (natureName) parts.push(natureName);
    const txt = parts.join(" · ");
    if (line.textContent !== txt) line.textContent = txt;
}

// ==================== 3. ПЛАШКА БАФФОВ (чипы) ====================
function fmtTimeShort(ms) {
    const s = Math.ceil(ms / 1000);
    const m = Math.floor(s / 60), r = s % 60;
    if (m >= 60) return Math.floor(m / 60) + "ч " + (m % 60) + "м";
    if (m > 0) return m + ":" + (r < 10 ? "0" + r : r);
    return r + "с";
}

function renderBuffsPlaque() {
    const card = document.getElementById("dao-status-card");
    if (!card) return;
    const buffs = getBuffs();
    let pl = document.getElementById("dao-buffs-plaque");

    if (buffs.length === 0) {
        if (pl) pl.remove();
        return;
    }

    if (!pl) {
        pl = document.createElement("div");
        pl.id = "dao-buffs-plaque";
        const gold = document.getElementById("dao-gold-line");
        if (gold && gold.parentNode === card) gold.after(pl);
        else card.appendChild(pl);
    }

    const now = Date.now();
    let html = "";
    buffs.forEach(function(b) {
        const remain = Math.max(0, b.endsAt - now);
        html +=
            '<span style="display:inline-flex;align-items:center;gap:3px;' +
                'background:rgba(126,231,255,.06);' +
                'border:1px solid rgba(126,231,255,.28);' +
                'border-radius:4px;padding:1px 5px;' +
                'font-size:.66rem;line-height:1.15;' +
                'color:var(--text-main);white-space:nowrap;">' +
                '<span style="font-size:.72rem;">' + b.icon + '</span>' +
                '<span>' + b.name + '</span>' +
                '<span style="color:var(--cyan);font-weight:700;' +
                    'font-variant-numeric:tabular-nums;margin-left:1px;">' +
                    fmtTimeShort(remain) + '</span>' +
            '</span>';
    });

    if (pl._daoLast !== html) {
        pl.innerHTML = html;
        pl._daoLast = html;
    }
}

// ==================== 4. СТРОКА ЭКИПИРОВКИ ====================
function renderEquipLine() {
    const card = document.getElementById("dao-status-card");
    if (!card) return;
    const ch = getCharacter();
    if (!ch) return;

    const eq = getEquipped();
    const stats = eq.weapon ? WEAPON_STATS[eq.weapon] : null;

    let line = document.getElementById("dao-equip-line");
    if (!line) {
        line = document.createElement("div");
        line.id = "dao-equip-line";
        const buffsPlaque = document.getElementById("dao-buffs-plaque");
        const gold = document.getElementById("dao-gold-line");
        if (buffsPlaque && buffsPlaque.parentNode === card) buffsPlaque.after(line);
        else if (gold && gold.parentNode === card) gold.after(line);
        else card.appendChild(line);
    }

    let valueHtml = "";
    if (stats) {
        valueHtml = stats.icon + " " + stats.name +
            '<small style="color:var(--text-dim);font-weight:400;font-size:.72rem;margin-left:4px;">+' +
            stats.atk + ' атк</small>';
    } else {
        valueHtml = "— не экипировано";
    }

    const newHtml =
        '<span style="color:var(--text-dim);display:inline-flex;align-items:center;gap:6px;">🗡️ Оружие:</span>' +
        '<span style="color:' + (stats ? '#ff9f5a' : 'var(--text-dim)') + ';font-weight:' + (stats ? '700' : '400') +
            ';text-align:right;' + (stats ? '' : 'font-style:italic;') + '">' + valueHtml + '</span>';

    if (line._daoLast !== newHtml) {
        line.innerHTML = newHtml;
        line._daoLast = newHtml;
    }
}

// ==================== 5. СТРОКА ЩИТА ПОКОЯ ====================
function renderShieldLine() {
    const card = document.getElementById("dao-status-card");
    if (!card) return;
    const ch = getCharacter();
    const hasShield = !!(ch && ch.talismanShield);

    let line = document.getElementById("dao-shield-line");
    if (!hasShield) {
        if (line) line.remove();
        return;
    }
    if (!line) {
        line = document.createElement("div");
        line.id = "dao-shield-line";
        line.style.cssText = "display:flex;justify-content:space-between;align-items:center;font-size:.82rem;margin-top:6px;padding-top:6px;border-top:1px dashed #30363d;";
        const equip = document.getElementById("dao-equip-line");
        const buffs = document.getElementById("dao-buffs-plaque");
        const gold = document.getElementById("dao-gold-line");
        if (equip && equip.parentNode === card) equip.after(line);
        else if (buffs && buffs.parentNode === card) buffs.after(line);
        else if (gold && gold.parentNode === card) gold.after(line);
        else card.appendChild(line);
    }
    const html = '<span style="color:var(--cyan);">🕊️ Щит покоя:</span><span style="color:var(--cyan);font-weight:700;">активен</span>';
    if (line._daoLast !== html) {
        line.innerHTML = html;
        line._daoLast = html;
    }
}

// ==================== 6. ДЕЙСТВИЯ С ПРЕДМЕТАМИ ====================
function drinkPotion(id) {
    const ch = getCharacter();
    if (!ch) return;
    const prof = ch.profession;
    if (!prof || !prof.products || !prof.products[id] || prof.products[id] <= 0) {
        alert("Нет такого снадобья в инвентаре.");
        return;
    }
    const data = BUFFS_DATA[id];
    if (!data) { alert("Неизвестное снадобье."); return; }

    const res = addBuff(id);
    if (res && res.ok === false && res.reason === "limit") {
        alert("Слишком много активных эффектов (макс " + MAX_BUFFS + ").\nДождись, пока истёчёт один.");
        return;
    }

    prof.products[id] -= 1;
    if (prof.products[id] <= 0) delete prof.products[id];
    ch.profession = prof;
    saveCharacterObj(ch);

    addLog(data.icon + " Ты выпил «" + data.name + "». " + data.desc + " (" + formatDuration(data.duration) + ")", true);
    recalcStats();
    updateUI();
    saveGame();
    rerenderInventoryTab();
}
window.daoDrinkPotion = drinkPotion;

function equipItem(itemId) {
    const ch = getCharacter();
    if (!ch) return;
    const prof = ch.profession;
    if (!prof || !prof.products || !prof.products[itemId] || prof.products[itemId] <= 0) {
        alert("Нет такого предмета в инвентаре.");
        return;
    }
    const stats = WEAPON_STATS[itemId];
    if (!stats) { alert("Это не оружие."); return; }

    setEquipped("weapon", itemId);
    addLog("🗡️ Ты экипировал «" + stats.name + "» (+" + stats.atk + " к атаке).", true);
    updateUI();
    saveGame();
    rerenderInventoryTab();
}
window.daoEquipWeapon = equipItem;

function unequipWeapon() {
    setEquipped("weapon", null);
    addLog("🗡️ Оружие снято.", true);
    updateUI();
    saveGame();
    rerenderInventoryTab();
}
window.daoUnequipWeapon = unequipWeapon;

// ==================== 7. ТАЛИСМАНЫ ====================
function activateTalisman(id) {
    const ch = getCharacter();
    if (!ch) return;
    const prof = ch.profession;
    if (!prof || !prof.products || !prof.products[id] || prof.products[id] <= 0) {
        alert("Нет такого талисмана в инвентаре.");
        return;
    }
    const name = TALISMAN_NAMES[id] || id;

    if (id === "calm_seal" && ch.talismanShield) {
        alert("Щит уже активен. Дождись его срабатывания.");
        return;
    }
    if (id === "enlight_seal") {
        if (!isCultivator()) { alert("Талисман просветления работает только у культиваторов."); return; }
        if (qiPerSecond <= 0) { alert("Нет активного притока Ци."); return; }
    }

    prof.products[id] -= 1;
    if (prof.products[id] <= 0) delete prof.products[id];
    ch.profession = prof;
    saveCharacterObj(ch);

    if (id === "clarity_seal" || id === "fortune_seal" || id === "steadfast_seal") {
        const res = addBuff(id);
        if (res && res.ok === false && res.reason === "limit") {
            prof.products[id] = (prof.products[id] || 0) + 1;
            ch.profession = prof;
            saveCharacterObj(ch);
            alert("Слишком много активных эффектов (макс " + MAX_BUFFS + ").");
            return;
        }
        addLog("📜 Активирован «" + name + "»: " + BUFFS_DATA[id].desc, true);
    } else if (id === "calm_seal") {
        ch.talismanShield = true;
        saveCharacterObj(ch);
        addLog("🕊️ Активирован «" + name + "»: следующий провал в путешествии отменяется.", true);
    } else if (id === "enlight_seal") {
        const gain = qiPerSecond * 600;
        qi += gain;
        addLog("✨ Активирован «" + name + "»: +" + gain.toFixed(1) + " Ци в пул.", true);
    }

    recalcStats();
    updateUI();
    saveGame();
    rerenderInventoryTab();
}
window.daoActivateTalisman = activateTalisman;

// ==================== 8. ОБОГАЩЕНИЕ ИНВЕНТАРЯ КНОПКАМИ ====================
function rerenderInventoryTab() {
    const overlay = document.getElementById("character-modal");
    if (!overlay || !overlay.classList.contains("show")) return;
    const invTab = overlay.querySelector('.tab[data-tab="inventory"]');
    if (invTab) invTab.click();
}

function enrichInventory() {
    const content = document.getElementById("char-content");
    if (!content) return;
    const overlay = document.getElementById("character-modal");
    if (!overlay || !overlay.classList.contains("show")) return;
    const activeTab = overlay.querySelector(".tab.active");
    if (!activeTab || activeTab.dataset.tab !== "inventory") return;

    const ch = getCharacter();
    if (!ch) return;
    const prof = ch.profession;
    if (!prof || !prof.products) return;

    const equipped = getEquipped();

    const rows = content.querySelectorAll("div");
    rows.forEach(function(row) {
        if (row.querySelector(".dao-inv-btn")) return;
        const txt = row.textContent || "";
        if (!/×\d+/.test(txt)) return;

        // 1. Оружие?
        let weaponId = null;
        Object.keys(WEAPON_STATS).forEach(function(id) {
            const s = WEAPON_STATS[id];
            if (txt.indexOf(s.icon) !== -1 && txt.indexOf(s.name) !== -1) weaponId = id;
        });
        if (weaponId && prof.products[weaponId] > 0) {
            const isEq = equipped.weapon === weaponId;
            const btn = document.createElement("button");
            btn.className = "dao-inv-btn";
            btn.textContent = isEq ? "Снять" : "Экипировать";
            btn.style.cssText = "min-height:26px;padding:2px 10px;font-size:.68rem;background:#21262d;border:1px solid " +
                (isEq ? "var(--crimson)" : "var(--gold)") + ";color:" +
                (isEq ? "var(--crimson)" : "var(--gold)") +
                ";border-radius:6px;font-weight:600;font-family:inherit;cursor:pointer;flex:0 0 auto;margin-left:6px;";
            btn.onclick = function(e) {
                e.preventDefault(); e.stopPropagation();
                if (isEq) unequipWeapon();
                else equipItem(weaponId);
            };
            row.appendChild(btn);
            return;
        }

        // 2. Талисман?
        let talismanId = null;
        TALISMAN_IDS.forEach(function(tid) {
            const nm = TALISMAN_NAMES[tid] || (BUFFS_DATA[tid] && BUFFS_DATA[tid].name) || "";
            if (nm && txt.indexOf(nm) !== -1) talismanId = tid;
        });
        if (talismanId && prof.products[talismanId] > 0) {
            const btn = document.createElement("button");
            btn.className = "dao-inv-btn";
            btn.textContent = "Активировать";
            btn.style.cssText = "min-height:26px;padding:2px 10px;font-size:.68rem;background:#21262d;border:1px solid var(--cyan);color:var(--cyan);border-radius:6px;font-weight:600;font-family:inherit;cursor:pointer;flex:0 0 auto;margin-left:6px;";
            btn.onclick = function(e) {
                e.preventDefault(); e.stopPropagation();
                activateTalisman(talismanId);
            };
            row.appendChild(btn);
            return;
        }

        // 3. Снадобье? (исключая талисманы)
        let potionId = null;
        Object.keys(BUFFS_DATA).forEach(function(id) {
            if (TALISMAN_IDS.indexOf(id) !== -1) return;
            const d = BUFFS_DATA[id];
            if (txt.indexOf(d.icon) !== -1 && txt.indexOf(d.name) !== -1) potionId = id;
        });
        if (potionId && prof.products[potionId] > 0) {
            const btn = document.createElement("button");
            btn.className = "dao-inv-btn";
            btn.textContent = "Выпить";
            btn.style.cssText = "min-height:26px;padding:2px 10px;font-size:.68rem;background:#21262d;border:1px solid var(--jade);color:var(--jade-glow);border-radius:6px;font-weight:600;font-family:inherit;cursor:pointer;flex:0 0 auto;margin-left:6px;";
            btn.onclick = function(e) { e.preventDefault(); e.stopPropagation(); drinkPotion(potionId); };
            row.appendChild(btn);
        }
    });
}
window.daoEnrichInventory = enrichInventory;

document.addEventListener("click", function(e) {
    const t = e.target.closest && e.target.closest('#character-modal .tab[data-tab="inventory"]');
    if (t) {
        setTimeout(enrichInventory, 200);
        setTimeout(enrichInventory, 600);
    }
}, true);

// ==================== 9. ПАНЕЛЬ ДЕЙСТВИЙ ====================
function refreshActions() {
    const cultivator = isCultivator();
    const highRealm = isHighRealm();
    const inTravel = hasTravel();
    const onQuest = hasQuest();
    const ch = getCharacter();
    const profBusy = !!(ch && ch.profession && (ch.profession.activeGather || ch.profession.activeCraft));
    const hasTechs = Object.keys(getCombatOwned()).length > 0;

    const map = {
        meditation: {
            available: cultivator && !inTravel && !onQuest && !profBusy,
            sub: cultivator ? ((inTravel || onQuest || profBusy) ? "занят" : "пассивно") : "закрыто"
        },
        training: {
            available: true,
            sub: hasTechs ? "в разделе Боевые" : "купить в Боевые"
        },
        travel: {
            available: !inTravel && !onQuest && !profBusy,
            sub: inTravel ? "в пути" : (profBusy ? "занят" : "4 локации")
        },
        contemplation: {
            available: highRealm,
            sub: highRealm ? "скоро" : "высокое царство"
        }
    };

    Object.keys(map).forEach(function(id) {
        const btn = document.querySelector('.action-btn[data-action="' + id + '"]');
        if (!btn) return;
        const m = map[id];
        btn.classList.toggle("available", m.available);
        btn.classList.toggle("locked", !m.available);
        const subEl = btn.querySelector(".action-sub");
        if (subEl && subEl.textContent !== m.sub) subEl.textContent = m.sub;
    });
}

function handleAction(id) {
    const cultivator = isCultivator();
    const highRealm = isHighRealm();
    switch (id) {
        case "meditation":
            if (!cultivator) { addLog("🧘 Сначала стань культиватором. Купи стартовую технику в 👤 → МЕНЯЛА.", true); return; }
            if (hasQuest() || hasTravel()) { addLog("🧘 Ты занят.", true); return; }
            addLog("🧘 Ты в потоке. Ци течёт сама: +" + qiPerSecond.toFixed(2) + " / сек.", true);
            return;
        case "training":
            if (typeof window.daoOpenCombatTab === "function") window.daoOpenCombatTab();
            else if (typeof openCharacterModal === "function") openCharacterModal();
            return;
        case "travel":
            if (hasTravel()) { addLog("🗺️ Ты уже в пути.", true); return; }
            if (typeof openTravelModal === "function") openTravelModal();
            return;
        case "contemplation":
            if (!highRealm) { addLog("🔮 Созерцание откроется с 4-го царства.", true); return; }
            addLog("🔮 Созерцание появится в следующем обновлении.", true);
            return;
    }
}
window.handleAction = handleAction;

// ==================== 10. ВСПОМОГАТЕЛЬНЫЕ АНИМАЦИИ ====================
function flashReward(rgb) {
    const card = document.getElementById("dao-status-card");
    if (!card) return;
    if (window.getComputedStyle(card).position === "static") card.style.position = "relative";
    const f = document.createElement("div");
    f.style.cssText = "position:absolute;inset:0;pointer-events:none;border-radius:10px;background:radial-gradient(circle at center,rgba(" + rgb + ",.35),rgba(" + rgb + ",0) 70%);animation:rewardFlash 1s ease-out forwards;z-index:5;";
    card.appendChild(f);
    setTimeout(function() { f.remove(); }, 1050);
}
window.flashReward = flashReward;

// ==================== 11. МЕНЮ ====================
function openMenu() {
    const gv = document.getElementById("game-version");
    if (gv) gv.textContent = GAME_VERSION;
    const pc = document.getElementById("patch-counter");
    if (pc) pc.textContent = "Активных патчей: " + getPatchCount();
    const m = document.getElementById("menu-modal");
    if (m) m.classList.add("show");
}
function closeMenu() { const m = document.getElementById("menu-modal"); if (m) m.classList.remove("show"); }
function openPatchModal() { closeMenu(); const p = document.getElementById("patch-modal"); if (p) p.classList.add("show"); }
function closePatchModal() { const p = document.getElementById("patch-modal"); if (p) p.classList.remove("show"); }

window.openMenu = openMenu;
window.closeMenu = closeMenu;
window.openPatchModal = openPatchModal;
window.closePatchModal = closePatchModal;

document.getElementById("menu-modal").addEventListener("click", function(e) { if (e.target === this) closeMenu(); });
document.getElementById("patch-modal").addEventListener("click", function(e) { if (e.target === this) closePatchModal(); });

// ==================== 12. НАСТРОЙКИ ====================
function openSettingsModal() {
    closeMenu();
    const old = document.getElementById("settings-modal");
    if (old) old.remove();
    const current = getOrientationPref();

    const overlay = document.createElement("div");
    overlay.id = "settings-modal";
    overlay.className = "modal-overlay show";
    overlay.innerHTML = `
        <div class="modal">
            <h2>Настройки</h2>
            <div style="font-size:.85rem;color:var(--text-dim);margin-bottom:8px;">Ориентация экрана</div>
            <div style="display:flex;flex-direction:column;gap:6px;">
                <button data-pref="auto" class="orient-btn">Авто (по датчику)</button>
                <button data-pref="landscape" class="orient-btn">Альбомная</button>
                <button data-pref="portrait" class="orient-btn">Портретная</button>
            </div>
            <div id="orient-status" style="font-size:.75rem;color:var(--text-dim);margin-top:10px;line-height:1.3;"></div>
            <div style="font-size:.85rem;color:var(--text-dim);margin:18px 0 8px 0;border-top:1px solid #30363d;padding-top:14px;">Патчи</div>
            <div class="modal-actions" style="gap:6px;">
                <button onclick="showPatchesList()">Список патчей</button>
                <button onclick="undoLastPatch()">Откатить последний патч</button>
                <button onclick="clearAllPatches()">Очистить все патчи</button>
            </div>
            <div style="font-size:.85rem;color:var(--text-dim);margin:18px 0 8px 0;border-top:1px solid #30363d;padding-top:14px;">Отладка</div>
            <div class="modal-actions" style="gap:6px;">
                <button onclick="dbgAddGold(1000)">🧪 +1000 золота</button>
                <button onclick="dbgAddStones(20)">🧪 +20 камней</button>
                <button onclick="dbgResetOnboarding()">Сбросить онбординг</button>
            </div>
            <div class="modal-actions" style="margin-top:14px;">
                <button id="close-settings-btn">Закрыть</button>
            </div>
        </div>`;
    document.body.appendChild(overlay);

    const statusEl = document.getElementById("orient-status");
    const btns = overlay.querySelectorAll(".orient-btn");
    function paint(active) {
        btns.forEach(function(b) {
            b.textContent = b.textContent.replace(/^✓ /, "");
            const isA = b.dataset.pref === active;
            b.style.borderColor = isA ? "var(--jade)" : "";
            b.style.color = isA ? "var(--jade-glow)" : "";
            if (isA) b.textContent = "✓ " + b.textContent;
        });
    }
    paint(current);
    btns.forEach(function(b) {
        b.onclick = function() {
            const pref = b.dataset.pref;
            setOrientationPref(pref);
            const res = applyOrientation(pref);
            paint(pref);
            statusEl.textContent = res.ok ? "Применено: " + res.msg : "⚠ " + res.msg;
            addLog("↻ Ориентация: " + pref, true);
        };
    });

    document.getElementById("close-settings-btn").onclick = function() { overlay.remove(); };
    overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };
}
window.openSettingsModal = openSettingsModal;

// ==================== 13. ОТЛАДКА ====================
function dbgAddGold(n) {
    const total = addGold(n);
    addLog("🧪 [ТЕСТ] +" + n + " золота. Всего: " + total, true);
}
function dbgAddStones(n) {
    const total = addStones(n);
    addLog("🧪 [ТЕСТ] +" + n + " камней. Всего: " + total, true);
}
function dbgResetOnboarding() {
    if (!confirm("Сбросить персонажа и показать онбординг?")) return;
    [
        "dao_character", "dao_onboarding_ack",
        "cultivation_save_v2", "cultivation_save",
        "dao_techniques", "dao_combat_owned",
        "dao_v446_quest", "dao_v461_travel", "dao_travel_history"
    ].forEach(function(k) { try { localStorage.removeItem(k); } catch (e) {} });
    location.reload();
}
window.dbgAddGold = dbgAddGold;
window.dbgAddStones = dbgAddStones;
window.dbgResetOnboarding = dbgResetOnboarding;

// ==================== 14. ОРИЕНТАЦИЯ ====================
const ORIENT_KEY = "dao_orientation_pref";
function getOrientationPref() { try { return localStorage.getItem(ORIENT_KEY) || "auto"; } catch (e) { return "auto"; } }
function setOrientationPref(v) { try { localStorage.setItem(ORIENT_KEY, v); } catch (e) {} }
function applyOrientation(pref) {
    try { if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock(); } catch (e) {}
    if (pref === "auto") return { ok: true, msg: "Авто" };
    const target = pref === "landscape" ? "landscape" : "portrait";
    try {
        if (screen.orientation && screen.orientation.lock) {
            const p = screen.orientation.lock(target);
            if (p && p.catch) p.catch(function() {});
            return { ok: true, msg: "Запрошено" };
        }
    } catch (e) {}
    const fns = ["lockOrientation", "mozLockOrientation", "msLockOrientation", "webkitLockOrientation"];
    for (let i = 0; i < fns.length; i++) {
        if (typeof screen[fns[i]] === "function") {
            try { screen[fns[i]](target); return { ok: true, msg: "Запрошено" }; } catch (e) {}
        }
    }
    return { ok: false, msg: "Не поддерживается" };
}
window.getOrientationPref = getOrientationPref;
window.setOrientationPref = setOrientationPref;
window.applyOrientation = applyOrientation;

// ==================== 15. СИСТЕМА ПАТЧЕЙ ====================
const PATCH_STORAGE_KEY = "dao_patches";

function extractPatchVersion(code) {
    if (!code) return null;
    const m = code.match(/DAO_PATCH\s+(v[\d.]+)/);
    return m ? m[1] : null;
}
function getPatchCount() {
    try {
        const list = JSON.parse(localStorage.getItem(PATCH_STORAGE_KEY) || "[]");
        return Array.isArray(list) ? list.length : 0;
    } catch (e) { return 0; }
}

function loadAllPatches() {
    let list = [];
    try { list = JSON.parse(localStorage.getItem(PATCH_STORAGE_KEY) || "[]"); } catch (e) { return; }
    if (!Array.isArray(list) || list.length === 0) return;
    const failed = [];
    const failedNames = [];
    list.forEach(function(p, i) {
        try { eval(p.code); }
        catch (e) {
            failed.push(i);
            failedNames.push((p.version || "#" + (i + 1)) + ": " + e.message);
            console.error("Патч не загружен:", p.version, e);
        }
    });
    if (failed.length > 0) {
        const remaining = list.filter(function(_, i) { return failed.indexOf(i) === -1; });
        try { localStorage.setItem(PATCH_STORAGE_KEY, JSON.stringify(remaining)); } catch (e) {}
        setTimeout(function() {
            addLog("⚠ Удалено сломанных патчей: " + failed.length + ". Проверь консоль.", true);
            failedNames.forEach(function(n) { console.warn("[dao] " + n); });
        }, 300);
    }
}

function clearAllPatches() {
    if (!confirm("Удалить все сохранённые патчи?")) return;
    try { localStorage.removeItem(PATCH_STORAGE_KEY); } catch (e) {}
    location.reload();
}
function undoLastPatch() {
    let list = [];
    try { list = JSON.parse(localStorage.getItem(PATCH_STORAGE_KEY) || "[]"); } catch (e) {}
    if (!Array.isArray(list) || list.length === 0) { alert("Нет патчей для отката."); return; }
    const last = list[list.length - 1];
    if (!confirm("Откатить патч " + (last.version || "") + "?")) return;
    list.pop();
    try { localStorage.setItem(PATCH_STORAGE_KEY, JSON.stringify(list)); } catch (e) {}
    saveGame();
    location.reload();
}
function showPatchesList() {
    let list = [];
    try { list = JSON.parse(localStorage.getItem(PATCH_STORAGE_KEY) || "[]"); } catch (e) {}
    if (!Array.isArray(list) || list.length === 0) { alert("Нет активных патчей."); return; }
    let t = "Активные патчи (" + list.length + "):\n\n";
    list.forEach(function(p, i) {
        const d = p.appliedAt ? new Date(p.appliedAt) : null;
        t += (i + 1) + ". " + (p.version || "?") + (d ? "  " + d.toLocaleDateString() : "") + "\n";
    });
    alert(t);
}
function applyPatch(code) {
    code = (code || "").trim();
    if (!code) { alert("Патч пустой"); return false; }
    if (!code.includes("DAO_PATCH")) { alert("Это не патч."); return false; }
    try {
        eval(code);
        let list = [];
        try { list = JSON.parse(localStorage.getItem(PATCH_STORAGE_KEY) || "[]"); } catch (e) {}
        if (!Array.isArray(list)) list = [];
        const v = extractPatchVersion(code);
        if (v) list = list.filter(function(p) { return extractPatchVersion(p.code) !== v; });
        list.push({ code: code, version: v, appliedAt: Date.now() });
        try { localStorage.setItem(PATCH_STORAGE_KEY, JSON.stringify(list)); } catch (e) {}
        addLog("✓ Патч применён и сохранён", true);
        saveGame();
        updateUI();
        return true;
    } catch (err) {
        alert("Ошибка:\n" + err.message);
        return false;
    }
}
function applyPatchFromInput() {
    const text = document.getElementById("patch-input").value;
    if (applyPatch(text)) {
        closePatchModal();
        document.getElementById("patch-input").value = "";
    }
}
window.clearAllPatches = clearAllPatches;
window.undoLastPatch = undoLastPatch;
window.showPatchesList = showPatchesList;
window.applyPatch = applyPatch;
window.applyPatchFromInput = applyPatchFromInput;

document.getElementById("patch-file").addEventListener("change", function(e) {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = function(ev) { document.getElementById("patch-input").value = ev.target.result; };
    r.readAsText(f);
});

// ==================== 16. ЭКСПОРТ / ИМПОРТ ====================
function buildSavePayload(full) {
    const ch = getCharacter();
    const data = {
        type: "dao_save",
        format: full ? "full" : "compact",
        version: GAME_VERSION,
        savedAt: Date.now(),
        qi: qi,
        stageIndex: currentStageIndex,
        character: ch,
        techniques: getTechData(),
        combatOwned: getCombatOwned(),
        travelHistory: getTravelHistory()
    };
    if (full) {
        try { data.patches = JSON.parse(localStorage.getItem(PATCH_STORAGE_KEY) || "[]"); }
        catch (e) { data.patches = []; }
    }
    return data;
}

function exportSave() {
    const old = document.getElementById("export-modal");
    if (old) old.remove();
    const compact = JSON.stringify(buildSavePayload(false), null, 2);

    const overlay = document.createElement("div");
    overlay.id = "export-modal";
    overlay.className = "modal-overlay show";
    overlay.innerHTML =
        '<div class="modal">' +
            '<h2>Сохранить</h2>' +
            '<p style="font-size:.8rem;color:var(--text-dim);margin-bottom:10px;line-height:1.4;">' +
                '<b style="color:var(--gold);">Компактное</b> — прогресс, персонаж, техники.<br>' +
                '<b style="color:var(--gold);">Полное</b> — с патчами.' +
            '</p>' +
            '<textarea id="export-text" readonly style="height:160px;font-size:.72rem;">' + compact.replace(/</g, "&lt;") + '</textarea>' +
            '<div class="modal-actions" style="margin-top:10px;">' +
                '<button class="primary" onclick="copyExport(\'compact\')">📋 Копировать компактное</button>' +
                '<button onclick="copyExport(\'full\')">📋 Копировать с патчами</button>' +
                '<button onclick="document.getElementById(\'export-modal\').remove()">Закрыть</button>' +
            '</div>' +
        '</div>';
    document.body.appendChild(overlay);
    overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };
}

function copyExport(mode) {
    const ta = document.getElementById("export-text");
    const text = JSON.stringify(buildSavePayload(mode === "full"), null, 2);
    ta.value = text;
    ta.focus();
    ta.select();
    try { document.execCommand("copy"); alert("Скопировано"); }
    catch (e) { alert("Скопируй вручную"); }
}

function importSaveFromText() {
    const old = document.getElementById("import-modal");
    if (old) old.remove();
    const overlay = document.createElement("div");
    overlay.id = "import-modal";
    overlay.className = "modal-overlay show";
    overlay.innerHTML =
        '<div class="modal">' +
            '<h2>Загрузить</h2>' +
            '<textarea id="import-text" placeholder="Вставь текст..." style="height:150px;font-size:.75rem;"></textarea>' +
            '<div class="modal-actions" style="margin-top:10px;">' +
                '<button class="primary" onclick="doImport()">Загрузить</button>' +
                '<button onclick="document.getElementById(\'import-modal\').remove()">Отмена</button>' +
            '</div>' +
        '</div>';
    document.body.appendChild(overlay);
    overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };
}

function doImport() {
    const text = document.getElementById("import-text").value.trim();
    if (!text) { alert("Пусто"); return; }
    let data;
    try { data = JSON.parse(text); }
    catch (e) { alert("Ошибка: " + e.message); return; }
    if (!data || data.type !== "dao_save") { alert("Это не сохранение."); return; }

    let mode = "progress";
    if (data.format === "full" && Array.isArray(data.patches) && data.patches.length > 0) {
        mode = confirm(
            "Найдено патчей: " + data.patches.length + ".\n\nOK — прогресс + патчи.\nОтмена — только прогресс."
        ) ? "full" : "progress";
    }

    qi = typeof data.qi === "number" ? data.qi : 0;
    currentStageIndex = Math.min(data.stageIndex || 0, 80);
    if (data.character) saveCharacterObj(data.character);
    if (data.techniques) setTechData(data.techniques);
    if (data.combatOwned) setCombatOwned(data.combatOwned);
    if (data.travelHistory) {
        try { localStorage.setItem("dao_travel_history", JSON.stringify(data.travelHistory)); } catch (e) {}
    }

    if (mode === "full") {
        try { localStorage.setItem(PATCH_STORAGE_KEY, JSON.stringify(data.patches)); } catch (e) {}
        recalcStats(); saveGame(); updateUI();
        addLog("✓ Импорт: прогресс + " + data.patches.length + " патчей. Перезагрузка…", true);
        const m = document.getElementById("import-modal"); if (m) m.remove();
        setTimeout(function() { location.reload(); }, 500);
        return;
    }
    recalcStats(); saveGame(); updateUI();
    addLog("✓ Прогресс загружен.", true);
    const m = document.getElementById("import-modal"); if (m) m.remove();
    closeMenu();
}

window.exportSave = exportSave;
window.copyExport = copyExport;
window.importSaveFromText = importSaveFromText;
window.doImport = doImport;

// ==================== 17. ОНБОРДИНГ ====================
function rollCharacter() {
    return {
        origin: pick(ORIGINS),
        root: pick(ROOTS),
        nature: pick(NATURES),
        rolledAt: Date.now()
    };
}

function renderRollCard(item, label) {
    return (
        '<div class="roll-card">' +
            '<div class="roll-card-label">' + label + '</div>' +
            '<div class="roll-card-title"><span class="roll-card-icon">' + item.icon + '</span><span>' + item.name + '</span></div>' +
            '<div class="roll-card-desc">' + item.desc + '</div>' +
            '<div class="roll-card-quote">«' + item.quote + '»</div>' +
        '</div>'
    );
}

function renderOnboarding() {
    const old = document.getElementById("dao-onboarding");
    if (old) old.remove();

    let rerolls = 3;
    const MAX_REROLLS = 3;
    let current = rollCharacter();

    const overlay = document.createElement("div");
    overlay.id = "dao-onboarding";
    overlay.className = "onboarding-overlay";
    overlay.innerHTML =
        '<div class="onboarding-box">' +
            '<h2 class="onboarding-title">СОЗДАНИЕ БЕССМЕРТНОГО</h2>' +
            '<div class="onboarding-sub">Небеса уже решили за тебя</div>' +
            '<div class="roll-grid" id="roll-grid">' +
                renderRollCard(current.origin, "Происхождение") +
                renderRollCard(current.root, "Духовный корень") +
                renderRollCard(current.nature, "Характер") +
            '</div>' +
            '<div class="rerolls-counter" id="rerolls-counter">Перебросов осталось: <b>' + rerolls + '</b> из ' + MAX_REROLLS + '</div>' +
            '<div class="name-block">' +
                '<div class="name-label">Имя</div>' +
                '<div class="name-row">' +
                    '<input type="text" class="name-input" id="name-input" maxlength="30" value="' + randomName() + '">' +
                    '<button class="name-dice" id="name-dice">🎲</button>' +
                '</div>' +
            '</div>' +
            '<div class="onboarding-actions">' +
                '<button id="reroll-btn">Перебросить судьбу</button>' +
                '<button class="primary" id="accept-btn">Принять судьбу</button>' +
            '</div>' +
            '<div class="roll-hint">3 переброса · имя можно изменить</div>' +
        '</div>';
    document.body.appendChild(overlay);

    const rerollBtn = document.getElementById("reroll-btn");
    const counter = document.getElementById("rerolls-counter");
    const nameInput = document.getElementById("name-input");

    function updReroll() {
        counter.innerHTML = "Перебросов осталось: <b>" + rerolls + "</b> из " + MAX_REROLLS;
        rerollBtn.disabled = rerolls <= 0;
        rerollBtn.textContent = rerolls <= 0 ? "Перебросы исчерпаны" : "Перебросить судьбу";
    }
    updReroll();

    rerollBtn.onclick = function() {
        if (rerolls <= 0) return;
        rerolls--;
        current = rollCharacter();
        const grid = document.getElementById("roll-grid");
        grid.innerHTML =
            renderRollCard(current.origin, "Происхождение") +
            renderRollCard(current.root, "Духовный корень") +
            renderRollCard(current.nature, "Характер");
        grid.querySelectorAll(".roll-card").forEach(function(c) {
            c.classList.add("flash");
            setTimeout(function() { c.classList.remove("flash"); }, 350);
        });
        updReroll();
    };

    document.getElementById("name-dice").onclick = function() { nameInput.value = randomName(); };

    document.getElementById("accept-btn").onclick = function() {
        const name = nameInput.value.trim();
        if (!name) { alert("Введи имя или нажми 🎲."); return; }
        const ranges = { orphan:[15,18], clan:[16,20], sect:[17,22], wanderer:[18,25], heir:[16,20] };
        const r = ranges[current.origin.id] || [16, 22];
        const ch = {
            name: name,
            origin: current.origin,
            root: current.root,
            nature: current.nature,
            rolledAt: Date.now(),
            rerollsUsed: MAX_REROLLS - rerolls,
            isCultivator: false,
            starterTech: null,
            stones: 0,
            gold: 0,
            baseAge: r[0] + Math.floor(Math.random() * (r[1] - r[0] + 1)),
            applied: false,
            introShown: false
        };
        saveCharacterObj(ch);
        try { localStorage.setItem("dao_onboarding_ack", "1"); } catch (e) {}
        location.reload();
    };
}
window.renderOnboarding = renderOnboarding;

// ==================== 18. ВСТУПЛЕНИЕ ====================
function showIntro(ch) {
    addLog(pick(INTRO_CLOSING));
    addLog(pick(INTRO_NATURE[ch.nature.id] || INTRO_NATURE.water));
    addLog(pick(INTRO_ROOT[ch.root.id] || INTRO_ROOT.penta));
    addLog(pick(INTRO_ORIGIN[ch.origin.id] || INTRO_ORIGIN.orphan), true);
    addLog("— " + ch.name + " —", true);
}
window.showIntro = showIntro;

// ==================== 19. ПРИМЕНЕНИЕ ПЕРСОНАЖА ====================
function applyCharacter() {
    const ch = getCharacter();
    if (!ch) return false;

    let changed = false;

    if (ch.applied === undefined) {
        ch.applied = true;
        changed = true;
        if (_baseMods === null) _baseMods = combineMods(ch);
    }

    if (typeof ch.isCultivator !== "boolean") {
        let hasProgress = currentStageIndex > 0 || Object.keys(getTechData()).length > 0;
        ch.isCultivator = hasProgress;
        if (hasProgress && !ch.starterTech) ch.starterTech = "mortal_breath";
        changed = true;
    }
    if (typeof ch.gold !== "number") { ch.gold = 0; changed = true; }
    if (typeof ch.baseAge !== "number") {
        const ranges = { orphan:[15,18], clan:[16,20], sect:[17,22], wanderer:[18,25], heir:[16,20] };
        const r = ranges[ch.origin && ch.origin.id] || [16, 22];
        ch.baseAge = r[0] + Math.floor(Math.random() * (r[1] - r[0] + 1));
        changed = true;
    }
    if (!Array.isArray(ch.buffs)) { ch.buffs = []; changed = true; }

    if (changed) saveCharacterObj(ch);

    _baseMods = combineMods(ch);
    rebuildTargets(_baseMods.req);

    if (!ch.applied) {
        if (_baseMods.startQi) qi += _baseMods.startQi;
        if (_baseMods.startStones) ch.stones = (ch.stones || 0) + _baseMods.startStones;
        ch.applied = true;
        saveCharacterObj(ch);
        const bonus = [];
        if (_baseMods.startQi) bonus.push("+" + _baseMods.startQi + " Ци");
        if (_baseMods.startStones) bonus.push("+" + _baseMods.startStones + " камень");
        if (bonus.length) addLog("✦ Стартовые дары: " + bonus.join(", "), true);
    }
    recalcStats();

    if (!ch.introShown) {
        setTimeout(function() {
            showIntro(ch);
            ch.introShown = true;
            saveCharacterObj(ch);
        }, 1200);
    }
    return true;
}
window.applyCharacter = applyCharacter;

// ==================== 20. ТИКИ ОБНОВЛЕНИЯ ====================
setInterval(renderCharLine, 2000);
setInterval(renderStoneLine, 2500);
setInterval(renderGoldLine, 2500);
setInterval(renderBuffsPlaque, 1000);
setInterval(renderEquipLine, 3000);
setInterval(renderShieldLine, 1500);
setInterval(refreshActions, 1500);