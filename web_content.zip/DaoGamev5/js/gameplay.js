```javascript
// ================================================================
//  GAMEPLAY.JS — Путь к Бессмертию v5.8.1
//  Задания, техники культивации, боевые, путешествия, окно персонажа
//  Зависимости: core.js, ui.js, profession.js (для проверок)
// ================================================================

// ============================================================
// ЧАСТЬ 1. ЗАДАНИЯ
// ============================================================

function rollStoneChance() {
    const realmIdx = getRealmIdx();
    let base = 0.05 + realmIdx * 0.01;
    const mods = _baseMods || {};
    return Math.min(0.30, base * (mods.rareEvent || 1));
}
function shouldBeStone() {
    if (!isCultivator()) return false;
    return Math.random() < rollStoneChance();
}
function rollQuestList() {
    const chosen = [], used = new Set();
    [QUEST_SHORT, QUEST_MEDIUM, QUEST_LONG].forEach(function(pool) {
        let q, t = 0;
        do { q = pick(pool); t++; } while (used.has(q.id) && t < 10);
        used.add(q.id);
        const clone = Object.assign({}, q);
        clone.isStone = shouldBeStone();
        chosen.push(clone);
    });
    return chosen;
}
function tierOf(q) {
    const d = q.duration || 30;
    if (d <= 45) return "short";
    if (d <= 120) return "medium";
    return "long";
}

const REWARDS = {
    mortal:      { short: { gold: 8,  stones: 0 }, medium: { gold: 20, stones: 0 }, long: { gold: 60,  stones: 0 } },
    cult_normal: { short: { gold: 10, stones: 0 }, medium: { gold: 25, stones: 0 }, long: { gold: 70,  stones: 0 } },
    cult_stone:  { short: { gold: 5,  stones: 1 }, medium: { gold: 10, stones: 1 }, long: { gold: 30,  stones: 2 } }
};

function questReward(q) {
    const tier = tierOf(q);
    const cult = isCultivator();
    const stone = !!q.isStone;
    if (!cult) return REWARDS.mortal[tier];
    return stone ? REWARDS.cult_stone[tier] : REWARDS.cult_normal[tier];
}
function rewardText(r) {
    const parts = [];
    if (r.gold > 0) parts.push("💰 " + r.gold);
    if (r.stones > 0) parts.push("💠 " + r.stones + " " + stonesWord(r.stones));
    return parts.join(" + ");
}

// ==================== ЕДИНАЯ ПАУЗА ЦИ (D-03) ====================
let _gameplayPausedQps = null;
function pauseQi() {
    if (_gameplayPausedQps === null) {
        _gameplayPausedQps = qiPerSecond;
        qiPerSecond = 0;
        if (typeof updateUI === "function") updateUI();
    }
}
function resumeQi() {
    if (_gameplayPausedQps !== null) {
        qiPerSecond = _gameplayPausedQps;
        _gameplayPausedQps = null;
    } else if (typeof recalcStats === "function") {
        recalcStats();
    }
    if (typeof updateUI === "function") updateUI();
}
window.daoPauseQi = pauseQi;
window.daoResumeQi = resumeQi;

// ==================== ПЛАШКА ЗАДАНИЯ ====================
function renderQuestPlaque() {
    const card = document.getElementById("dao-status-card");
    if (!card) return;
    const q = getQuest();
    let plaque = document.getElementById("dao-quest-plaque");
    if (!q) { if (plaque) plaque.remove(); return; }
    if (!plaque) {
        plaque = document.createElement("div");
        plaque.id = "dao-quest-plaque";
        card.insertBefore(plaque, card.firstChild);
    }
    if (q.isStone && !plaque.classList.contains("stone")) plaque.classList.add("stone");
    else if (!q.isStone && plaque.classList.contains("stone")) plaque.classList.remove("stone");

    const totalMs = Math.max(1, q.endsAt - q.startedAt);
    const remainMs = Math.max(0, q.endsAt - Date.now());
    const progress = Math.min(1, Math.max(0, 1 - remainMs / totalMs));
    let phase = "phase-start";
    if (progress >= 0.8) phase = "phase-end";
    else if (progress >= 0.4) phase = "phase-mid";
    if (plaque.dataset.phase !== phase) {
        plaque.classList.remove("phase-start", "phase-mid", "phase-end");
        plaque.classList.add(phase);
        plaque.dataset.phase = phase;
    }

    if (!plaque.querySelector(".plaque-row")) {
        plaque.innerHTML =
            '<div class="plaque-row">' +
                '<span class="plaque-name"></span>' +
                '<span class="plaque-timer"></span>' +
                '<button class="plaque-cancel" title="Отменить">✖</button>' +
            '</div>' +
            '<div class="plaque-bar"><div class="plaque-bar-fill"></div></div>';
        plaque.querySelector(".plaque-cancel").onclick = function(e) {
            e.preventDefault(); e.stopPropagation();
            cancelQuest();
        };
    }
    const nameEl = plaque.querySelector(".plaque-name");
    const timerEl = plaque.querySelector(".plaque-timer");
    const barEl = plaque.querySelector(".plaque-bar-fill");
    const name = (q.isStone ? "💠 " : "") + (q.icon || "") + " " + q.name;
    const time = "⏱ " + formatRemaining(remainMs);
    if (nameEl.textContent !== name) nameEl.textContent = name;
    if (timerEl.textContent !== time) timerEl.textContent = time;
    if (barEl) barEl.style.width = (progress * 100).toFixed(1) + "%";
}
window.renderQuestPlaque = renderQuestPlaque;

// ==================== ЗАПУСК / ЗАВЕРШЕНИЕ ====================
function startQuest(q) {
    if (hasQuest()) return;
    if (hasTravel()) { alert("Ты в путешествии."); return; }
    if (typeof window.daoHasProfessionActivity === "function" && window.daoHasProfessionActivity()) {
        alert("Сначала заверши работу в мастерской или поход.");
        return;
    }
    const now = Date.now();
    const obj = {
        id: q.id, icon: q.icon, name: q.name,
        duration: q.duration, base: q.base || 1,
        isStone: !!q.isStone,
        startedAt: now, endsAt: now + q.duration * 1000
    };
    setQuest(obj);
    closeQuestsModal();
    pauseQi();
    renderQuestPlaque();
    saveGame();
    const mark = obj.isStone ? "💠 Редкое задание: " : "📜 Начато задание: ";
    addLog(mark + "«" + q.name + "» — " + q.duration + " сек.", true);
}

function completeQuest(fromStartup) {
    const q = getQuest();
    if (!q) return;
    setQuest(null);
    resumeQi();
    renderQuestPlaque();

    const r = questReward(q);
    if (r.gold > 0) addGold(r.gold);
    if (r.stones > 0) addStones(r.stones);

    const prefix = fromStartup ? "Пока тебя не было, " : "";
    const marker = q.isStone ? "💠" : "📜";
    const text = marker + " " + prefix + "задание «" + q.name + "» завершено. " + rewardText(r) + ".";
    const logBox = document.getElementById("log");
    if (logBox) {
        const entry = document.createElement("div");
        entry.className = "log-entry log-breakthrough";
        entry.style.color = q.isStone ? "#7ee7ff" : "#f0c454";
        entry.textContent = text;
        logBox.prepend(entry);
    }

    if (getTechParts("stone_sense") >= 3) {
        addStones(1);
        if (logBox) {
            const e = document.createElement("div");
            e.className = "log-entry log-reward";
            e.textContent = "💠 Чутьё на камни принесло дополнительный камень!";
            logBox.prepend(e);
        }
    }

    if (typeof flashReward === "function") flashReward(q.isStone ? "126,231,255" : "240,196,84");
    updateUI();
    saveGame();
}

function cancelQuest() {
    const q = getQuest();
    if (!q) return;
    if (!confirm("Отменить задание «" + q.name + "»?\n\nНаграда не будет начислена.")) return;
    setQuest(null);
    resumeQi();
    renderQuestPlaque();
    updateUI();
    saveGame();
    addLog("📜 Задание «" + q.name + "» отменено. Награды нет.", true);
}

// ==================== МОДАЛКА ЗАДАНИЙ ====================
function injectQuestsModal() {
    if (document.getElementById("quests-modal")) return;
    const overlay = document.createElement("div");
    overlay.id = "quests-modal";
    overlay.className = "modal-overlay";
    overlay.innerHTML =
        '<div class="modal">' +
            '<h2>Задания</h2>' +
            '<div id="quests-content"></div>' +
            '<div class="modal-actions" style="margin-top:6px;">' +
                '<button id="close-quests-btn">Закрыть</button>' +
            '</div>' +
        '</div>';
    document.body.appendChild(overlay);
    overlay.querySelector("#close-quests-btn").onclick = function() { overlay.classList.remove("show"); };
    overlay.onclick = function(e) { if (e.target === overlay) overlay.classList.remove("show"); };
}

function renderQuestsList() {
    const container = document.getElementById("quests-content");
    if (!container) return;
    const list = rollQuestList();
    const active = getQuest();
    const traveling = hasTravel();
    const busyProf = typeof window.daoHasProfessionActivity === "function" && window.daoHasProfessionActivity();

    let html =
        '<div class="quests-head">' +
            '<div class="quests-hint">Культивация остановится<br>на время выполнения.</div>' +
            '<button class="quests-refresh" id="quests-refresh"' + (active || traveling || busyProf ? " disabled" : "") + '>🔄 Обновить</button>' +
        '</div>';
    if (active) {
        html += '<div class="quests-banner">📜 Идёт задание: <b>' + active.name + '</b><br>Закончится — сможешь взять новое.</div>';
    } else if (traveling) {
        html += '<div class="quests-banner" style="border-color:#d29922;color:#d29922;">🗺️ Ты в путешествии. Вернись — и возьмёшь задание.</div>';
    } else if (busyProf) {
        html += '<div class="quests-banner" style="border-color:#d29922;color:#d29922;">⚒️ Ты занят в мастерской. Закончи — и возьмёшь задание.</div>';
    }
    html += '<div class="quest-list">';
    list.forEach(function(q) {
        const r = questReward(q);
        const stoneBadge = q.isStone ? '<span class="quest-stone-badge">РЕДКОЕ</span>' : "";
        const cardClass = "quest-card" + (q.isStone ? " stone" : "");
        const rewardCls = q.isStone ? "stone-r" : "";
        const canStart = !active && !traveling && !busyProf;
        html +=
            '<div class="' + cardClass + '" data-quest-id="' + q.id + '">' +
                '<div class="quest-head">' +
                    '<div class="quest-icon">' + (q.isStone ? "💠" : q.icon) + '</div>' +
                    '<div class="quest-title">' + q.name + stoneBadge + '</div>' +
                '</div>' +
                '<div class="quest-desc">' + q.desc + '</div>' +
                '<div class="quest-meta">' +
                    '<span class="quest-duration">⏱ <b>' + formatDuration(q.duration) + '</b></span>' +
                    '<span class="quest-reward ' + rewardCls + '">' + rewardText(r) + '</span>' +
                '</div>' +
                '<button class="quest-start" data-quest-id="' + q.id + '"' + (!canStart ? " disabled" : "") + '>' +
                    (active ? "📜 Ты на задании" : (traveling ? "🗺️ В пути" : (busyProf ? "⚒️ Занят" : "Начать"))) +
                '</button>' +
            '</div>';
    });
    html += '</div>';
    container.innerHTML = html;

    const refreshBtn = document.getElementById("quests-refresh");
    if (refreshBtn && !active && !traveling && !busyProf) refreshBtn.onclick = renderQuestsList;

    container.querySelectorAll(".quest-start").forEach(function(btn) {
        if (btn.disabled) return;
        btn.onclick = function(e) {
            e.preventDefault(); e.stopPropagation();
            const q = list.find(function(x) { return x.id === btn.dataset.questId; });
            if (q) startQuest(q);
        };
    });
}

function openQuestsModal() {
    injectQuestsModal();
    renderQuestsList();
    document.getElementById("quests-modal").classList.add("show");
}
function closeQuestsModal() {
    const o = document.getElementById("quests-modal");
    if (o) o.classList.remove("show");
}
window.openQuestsModal = openQuestsModal;
window.closeQuestsModal = closeQuestsModal;

// ============================================================
// ЧАСТЬ 2. ТЕХНИКИ КУЛЬТИВАЦИИ
// ============================================================

function formatTechEffect(tech, partIndex) {
    const pct = Math.round((partIndex + 1) * tech.effectPerPart * 100);
    if (tech.id === "light_step") return "−" + pct + "% " + tech.effectLabel;
    return "+" + pct + "% " + tech.effectLabel;
}

function getMasteryText(id) {
    switch (id) {
        case "jade_breath":    return "Дар: +25% к офлайн-накоплению Ци.";
        case "iron_meridians": return "Дар: 5% шанс крита — клик даёт ×5 Ци.";
        case "stone_sense":    return "Дар: +1 камень за каждый прорыв и задание.";
        case "light_step":     return "Дар: ещё −20% ко времени заданий.";
        default: return "";
    }
}

function injectTechniquesModal() {
    if (document.getElementById("techniques-modal")) return;
    const overlay = document.createElement("div");
    overlay.id = "techniques-modal";
    overlay.className = "modal-overlay";
    overlay.innerHTML =
        '<div class="modal">' +
            '<h2>Техники культивации</h2>' +
            '<div id="techs-content"></div>' +
            '<div class="modal-actions" style="margin-top:6px;">' +
                '<button id="close-tech-btn">Закрыть</button>' +
            '</div>' +
        '</div>';
    document.body.appendChild(overlay);
    overlay.querySelector("#close-tech-btn").onclick = function() { overlay.classList.remove("show"); };
    overlay.onclick = function(e) { if (e.target === overlay) overlay.classList.remove("show"); };
}

function renderTechList() {
    const container = document.getElementById("techs-content");
    if (!container) return;
    const balance = getStones();

    const jade = getTechParts("jade_breath"), iron = getTechParts("iron_meridians");
    const sense = getTechParts("stone_sense"), step = getTechParts("light_step");
    const total = jade + iron + sense + step;
    const completeCount = [jade, iron, sense, step].filter(function(p, i) {
        const ids = ["jade_breath", "iron_meridians", "stone_sense", "light_step"];
        return p >= TECH_COMPLETE[ids[i]];
    }).length;
    const pct = Math.round((total / 16) * 100);

    let effHtml = "";
    if (total === 0) {
        effHtml = '<div style="font-size:.78rem;color:var(--text-dim);font-style:italic;">Пока ни одна техника не изучена.</div>';
    } else {
        const p = [];
        if (jade)  p.push('<span class="eff"><span class="eff-icon">📖</span>Ци +' + (jade * 5) + '%</span>');
        if (iron)  p.push('<span class="eff"><span class="eff-icon">📖</span>клик +' + (iron * 8) + '%</span>');
        if (sense) p.push('<span class="eff"><span class="eff-icon">📖</span>камни +' + (sense * 10) + '%</span>');
        if (step)  p.push('<span class="eff"><span class="eff-icon">📖</span>задания −' + (step * 5) + '%</span>');
        effHtml = '<div class="tech-summary-effects">' + p.join("") + '</div>';
    }

    let html =
        '<div class="tech-summary">' +
            '<div class="tech-summary-top">' +
                '<span class="tech-summary-label">Сводка культивации</span>' +
                '<span class="tech-summary-count">Собрано: ' + completeCount + ' / 4 · ' + total + ' / 16 частей</span>' +
            '</div>' +
            '<div class="tech-summary-bar"><div class="tech-summary-bar-fill" style="width:' + pct + '%;"></div></div>' +
            effHtml +
        '</div>' +
        '<div class="tech-head">' +
            '<div class="tech-hint">Техники покупаются за 💠 камни.<br>Баланс: <b style="color:#7ee7ff;">' + balance + ' ' + stonesWord(balance) + '</b></div>' +
            '<button class="tech-refresh" id="tech-refresh">🔄 Обновить</button>' +
        '</div>' +
        '<div class="tech-list">';

    TECHNIQUES.forEach(function(tech) {
        const bought = getTechParts(tech.id);
        const tot = tech.costs.length;
        const isComplete = bought >= tot;
        const notEnough = !isComplete && balance < tech.costs[bought];

        let partsHtml = "";
        for (let i = 0; i < tot; i++) {
            const f = i < bought;
            partsHtml += '<div class="tech-part' + (f ? ' filled' : '') + '">' + (f ? '✓' : (i + 1)) + '</div>';
        }

        let nextHtml = "", btnClass = "tech-buy", btnText = "Купить часть", btnDisabled = false;
        if (isComplete) {
            nextHtml = '<div class="tech-next" style="border-color:rgba(210,153,34,.4);background:rgba(210,153,34,.06);"><span class="next-label">Техника собрана</span>' + getMasteryText(tech.id) + '</div>';
            btnClass += " complete"; btnText = "✓ Собрано"; btnDisabled = true;
        } else {
            const nextCost = tech.costs[bought];
            if (notEnough) btnClass += " insufficient";
            nextHtml = '<div class="tech-next"><span class="next-label">Следующая часть ' + (bought + 1) + ' из ' + tot + '</span>Эффект: <span class="next-effect">' + formatTechEffect(tech, bought) + '</span><br>Цена: <span class="next-cost">💠 ' + nextCost + ' ' + stonesWord(nextCost) + '</span>' + (notEnough ? '<span style="color:var(--crimson);margin-left:6px;">(не хватает ' + (nextCost - balance) + ')</span>' : "") + '</div>';
        }

        html +=
            '<div class="tech-card' + (isComplete ? ' complete' : '') + '" data-tech-id="' + tech.id + '">' +
                '<div class="tech-title-row">' +
                    '<div class="tech-icon">' + tech.icon + '</div>' +
                    '<div class="tech-name">' + tech.name + '</div>' +
                    (isComplete ? '<div class="tech-complete-badge">СОБРАНО</div>' : "") +
                '</div>' +
                '<div class="tech-desc">' + tech.desc + '</div>' +
                '<div class="tech-parts">' + partsHtml + '</div>' +
                '<div class="tech-progress">' +
                    '<span>Собрано: <b>' + bought + ' / ' + tot + '</b></span>' +
                    (bought > 0 ? '<span>Бонус: <b style="color:#7ee7ff;">' + formatTechEffect(tech, bought - 1) + '</b></span>' : "") +
                '</div>' +
                nextHtml +
                '<button class="' + btnClass + '" data-tech-id="' + tech.id + '"' + (btnDisabled ? " disabled" : "") + '>' + btnText + '</button>' +
            '</div>';
    });
    html += '</div>';
    container.innerHTML = html;

    const refresh = document.getElementById("tech-refresh");
    if (refresh) refresh.onclick = renderTechList;

    container.querySelectorAll(".tech-buy").forEach(function(btn) {
        if (btn.disabled) return;
        btn.onclick = function(e) {
            e.preventDefault(); e.stopPropagation();
            const tid = btn.dataset.techId;
            const tech = TECHNIQUES.find(function(t) { return t.id === tid; });
            if (!tech) return;
            const bought = getTechParts(tid);
            const cost = tech.costs[bought];
            if (getStones() < cost) { alert("Не хватает камней."); return; }
            spendStones(cost);
            setTechParts(tid, bought + 1);
            const isComplete = (bought + 1) >= tech.costs.length;
            addLog("📖 «" + tech.name + "»: часть " + (bought + 1) + "/" + tech.costs.length + " изучена. −" + cost + " " + stonesWord(cost) + ".", isComplete);
            if (isComplete) addLog("✦ Техника «" + tech.name + "» собрана полностью!", true);
            renderTechList();
            recalcStats();
            updateUI();
            saveGame();
        };
    });
}

function openTechniquesModal() {
    injectTechniquesModal();
    renderTechList();
    document.getElementById("techniques-modal").classList.add("show");
}
window.openTechniquesModal = openTechniquesModal;

// ============================================================
// ЧАСТЬ 3. БОЕВЫЕ ТЕХНИКИ
// ============================================================

function getTrainCost(tech) {
    switch (tech.tier) {
        case "mortal":     return { gold: 5,  qiPct: 0, stones: 0 };
        case "cultivator": return { gold: 15, qiPct: 5, stones: 0 };
        case "immortal":   return { gold: 40, qiPct: 8, stones: 1 };
        default:           return { gold: 5,  qiPct: 0, stones: 0 };
    }
}

function canTrain(tech) {
    const ch = getCharacter();
    if (!ch) return { ok: false, reason: "no_char" };
    if (getCombatMastery(tech.id) >= 20) return { ok: false, reason: "limit" };
    const cost = getTrainCost(tech);
    const qiNeeded = Math.floor(qi * (cost.qiPct / 100));
    if ((ch.gold || 0) < cost.gold) return { ok: false, reason: "no_gold", need: cost.gold - (ch.gold || 0) };
    if ((ch.stones || 0) < cost.stones) return { ok: false, reason: "no_stones", need: cost.stones - (ch.stones || 0) };
    if (cost.qiPct > 0 && qiNeeded < 1) return { ok: false, reason: "no_qi" };
    return { ok: true, cost: cost, qiNeeded: qiNeeded };
}

function handleBuyCombat(techId) {
    const tech = COMBAT_TECHS.find(function(t) { return t.id === techId; });
    if (!tech) return;
    if (isCombatOwned(techId)) { alert("Уже изучена."); return; }
    if (getRealmIdx() < tech.reqRealm) { alert("Требуется: " + REALMS[tech.reqRealm]); return; }
    const ch = getCharacter();
    if ((ch.gold || 0) < tech.priceGold) { alert("Не хватает " + (tech.priceGold - (ch.gold || 0)) + " золота."); return; }
    if ((ch.stones || 0) < tech.priceStones) { alert("Не хватает " + (tech.priceStones - (ch.stones || 0)) + " " + stonesWord(tech.priceStones - (ch.stones || 0)) + "."); return; }

    const priceLine = [];
    if (tech.priceGold > 0) priceLine.push("💰 " + tech.priceGold + " золота");
    if (tech.priceStones > 0) priceLine.push("💠 " + tech.priceStones + " " + stonesWord(tech.priceStones));
    if (!confirm("Изучить «" + tech.name + "»?\n\n" + priceLine.join("\n") + "\n\nОсвоение начнётся с 0%.")) return;

    ch.gold -= tech.priceGold;
    ch.stones -= tech.priceStones;
    saveCharacterObj(ch);
    const o = getCombatOwned();
    o[techId] = { boughtAt: Date.now(), mastery: 0 };
    setCombatOwned(o);
    addLog("⚔️ Изучена боевая техника: «" + tech.name + "».", true);
    renderCombatTab();
    updateUI();
    saveGame();
}

function handleTrainCombat(techId) {
    const tech = COMBAT_TECHS.find(function(t) { return t.id === techId; });
    if (!tech) return;
    const check = canTrain(tech);
    if (!check.ok) {
        if (check.reason === "limit") alert("20% — дальше только в реальных боях.");
        else if (check.reason === "no_gold") alert("Не хватает " + check.need + " " + goldWord(check.need) + ".");
        else if (check.reason === "no_stones") alert("Не хватает " + check.need + " " + stonesWord(check.need) + ".");
        else if (check.reason === "no_qi") alert("Не хватает Ци.");
        return;
    }
    const ch = getCharacter();
    const cost = check.cost;
    const oldM = getCombatMastery(techId);
    const newM = Math.min(20, oldM + 2);

    const costLine = [];
    if (cost.gold > 0) costLine.push("💰 " + cost.gold + " золота");
    if (cost.qiPct > 0) costLine.push("🌊 " + check.qiNeeded + " Ци (" + cost.qiPct + "%)");
    if (cost.stones > 0) costLine.push("💠 " + cost.stones + " " + stonesWord(cost.stones));

    if (!confirm("Тренировать «" + tech.name + "»?\n\nСтоимость: " + costLine.join(" + ") + "\nОсвоение: " + oldM + "% → " + newM + "%")) return;

    ch.gold -= cost.gold;
    ch.stones -= cost.stones;
    saveCharacterObj(ch);
    if (cost.qiPct > 0) qi = Math.max(0, qi - check.qiNeeded);
    setCombatMastery(techId, newM);

    addLog("🥋 «" + tech.name + "»: освоение " + newM + "%.", newM >= 20);
    if (newM >= 20) addLog("✦ «" + tech.name + "» — предел тренировки. Дальше только бой.", true);
    renderCombatTab();
    updateUI();
    saveGame();
}

function renderCombatTab() {
    const content = document.getElementById("char-content");
    if (!content) return;
    const realmIdx = getRealmIdx();

    const mortalList = COMBAT_TECHS.filter(function(t) { return t.tier === "mortal"; });
    const cultList   = COMBAT_TECHS.filter(function(t) { return t.tier === "cultivator"; });
    const immList    = COMBAT_TECHS.filter(function(t) { return t.tier === "immortal"; });

    function ownCount(list) { return list.filter(function(t) { return isCombatOwned(t.id); }).length; }

    function renderCard(tech) {
        const owned = isCombatOwned(tech.id);
        const realmOK = realmIdx >= tech.reqRealm;
        const locked = !realmOK && !owned;
        const mastery = getCombatMastery(tech.id);
        const masteryMax = mastery >= 20;
        const cls = "cb-card" + (owned ? " owned" : "") + (locked ? " locked" : "") + (masteryMax ? " mastery-max" : "");

        let badge = "";
        if (owned) badge = '<span class="cb-badge owned">ИЗУЧЕНО</span>';
        else if (!realmOK) badge = '<span class="cb-badge locked">🔒</span>';

        let priceHtml = "";
        const pp = [];
        if (tech.priceGold > 0) pp.push('<span class="g">💰 ' + tech.priceGold.toLocaleString("ru-RU") + '</span>');
        if (tech.priceStones > 0) pp.push('<span class="s">💠 ' + tech.priceStones + ' ' + stonesWord(tech.priceStones) + '</span>');
        priceHtml = pp.join('<span class="sep">+</span>');

        let btnHtml;
        if (owned) {
            const cost = getTrainCost(tech);
            const check = canTrain(tech);
            const costParts = [];
            if (cost.gold > 0) costParts.push("💰 " + cost.gold);
            if (cost.qiPct > 0) costParts.push("🌊 " + cost.qiPct + "% Ци");
            if (cost.stones > 0) costParts.push("💠 " + cost.stones);

            let trainBtn;
            if (masteryMax) trainBtn = '<button class="cb-train limit" disabled>20% — дальше только в бою</button>';
            else if (check.ok) trainBtn = '<button class="cb-train" data-train-id="' + tech.id + '">Тренировать</button>';
            else {
                let reasonText = "Не хватает";
                if (check.reason === "no_gold") reasonText = "Не хватает " + check.need + " " + goldWord(check.need);
                else if (check.reason === "no_stones") reasonText = "Не хватает " + check.need + " " + stonesWord(check.need);
                else if (check.reason === "no_qi") reasonText = "Не хватает Ци";
                trainBtn = '<button class="cb-train cant-afford" disabled>' + reasonText + '</button>';
            }
            btnHtml =
                '<div class="cb-mastery"><span>Освоение</span><span class="pct">' + mastery + '%</span></div>' +
                '<div class="cb-mastery-bar"><div class="cb-mastery-bar-fill" style="width:' + mastery + '%;"></div></div>' +
                '<div class="cb-actions">' + trainBtn + '</div>' +
                (!masteryMax ? '<div class="cb-cost">Стоимость: ' + costParts.join(" + ") + '</div>' : '');
        } else if (locked) {
            btnHtml = '<button class="cb-buy" disabled>🔒 ' + REALMS[tech.reqRealm] + '</button>';
        } else {
            const canAfford = (getGold() >= tech.priceGold) && (getStones() >= tech.priceStones);
            btnHtml = canAfford
                ? '<div class="cb-meta"><div class="cb-price">' + priceHtml + '</div><button class="cb-buy" data-tech-id="' + tech.id + '">Изучить</button></div>'
                : '<div class="cb-meta"><div class="cb-price">' + priceHtml + '</div><button class="cb-buy cant-afford" disabled>Не хватает</button></div>';
        }

        return (
            '<div class="' + cls + '">' +
                '<div class="cb-head">' +
                    '<div class="cb-icon">' + tech.icon + '</div>' +
                    '<div class="cb-info">' +
                        '<div class="cb-name">' + tech.name + '</div>' +
                        '<div class="cb-desc">' + tech.desc + '</div>' +
                    '</div>' +
                    badge +
                '</div>' +
                '<div class="cb-stats">' +
                    '<span class="s">⚔ Атака <b>' + tech.stats.atk + '</b></span>' +
                    '<span class="s">🛡 Защита <b>' + tech.stats.def + '</b></span>' +
                    '<span class="s">💨 Скорость <b>' + tech.stats.spd + '</b></span>' +
                '</div>' +
                btnHtml +
            '</div>'
        );
    }

    function section(title, list, reqRealm) {
        const available = realmIdx >= reqRealm;
        const reqNote = available
            ? "Изучено: " + ownCount(list) + " / " + list.length
            : "🔒 Требуется " + REALMS[reqRealm];
        const cls = available ? "cb-section" : "cb-section locked";
        return (
            '<div class="' + cls + '">' +
                '<div class="cb-section-header">' +
                    '<span class="cb-section-title">' + title + '</span>' +
                    '<span class="cb-section-req">' + reqNote + '</span>' +
                '</div>' +
                list.map(renderCard).join("") +
            '</div>'
        );
    }

    let html =
        '<div class="cb-summary">' +
            '<div class="cb-summary-label">Боевые техники</div>' +
            '<div class="cb-summary-grid">' +
                '<div class="cb-summary-item"><span class="cnt">' + ownCount(mortalList) + ' / ' + mortalList.length + '</span><span class="lbl">Смертные</span></div>' +
                '<div class="cb-summary-item"><span class="cnt">' + ownCount(cultList) + ' / ' + cultList.length + '</span><span class="lbl">Культиваторов</span></div>' +
                '<div class="cb-summary-item"><span class="cnt">' + ownCount(immList) + ' / ' + immList.length + '</span><span class="lbl">Бессмертных</span></div>' +
            '</div>' +
        '</div>' +
        section("Техники смертных", mortalList, 0) +
        section("Техники культиваторов", cultList, 2) +
        section("Техники бессмертных", immList, 6);

    content.innerHTML = html;

    content.querySelectorAll(".cb-buy[data-tech-id]").forEach(function(b) {
        if (b.disabled) return;
        b.onclick = function(e) { e.preventDefault(); e.stopPropagation(); handleBuyCombat(b.dataset.techId); };
    });
    content.querySelectorAll(".cb-train[data-train-id]").forEach(function(b) {
        if (b.disabled) return;
        b.onclick = function(e) { e.preventDefault(); e.stopPropagation(); handleTrainCombat(b.dataset.trainId); };
    });
}

// ============================================================
// ЧАСТЬ 4. ПУТЕШЕСТВИЯ
// ============================================================

function renderTravelPlaque() {
    const card = document.getElementById("dao-status-card");
    if (!card) return;
    const t = getTravel();
    let plaque = document.getElementById("dao-travel-plaque");
    if (!t) { if (plaque) plaque.remove(); return; }
    if (!plaque) {
        plaque = document.createElement("div");
        plaque.id = "dao-travel-plaque";
        const questPlaque = document.getElementById("dao-quest-plaque");
        if (questPlaque && questPlaque.parentNode === card) card.insertBefore(plaque, questPlaque);
        else card.insertBefore(plaque, card.firstChild);
    }
    const loc = LOCATIONS.find(function(l) { return l.id === t.locationId; });
    if (loc && loc.risk >= 0.2) plaque.classList.add("dangerous");
    else plaque.classList.remove("dangerous");

    const totalMs = Math.max(1, t.endsAt - t.startedAt);
    const remainMs = Math.max(0, t.endsAt - Date.now());
    const progress = Math.min(1, Math.max(0, 1 - remainMs / totalMs));

    if (!plaque.querySelector(".plaque-row")) {
        plaque.innerHTML =
            '<div class="plaque-row">' +
                '<span class="plaque-name"></span>' +
                '<span class="plaque-timer"></span>' +
                '<button class="plaque-cancel" title="Прервать">✖</button>' +
            '</div>' +
            '<div class="plaque-bar"><div class="plaque-bar-fill"></div></div>';
        plaque.querySelector(".plaque-cancel").onclick = function(e) {
            e.preventDefault(); e.stopPropagation();
            cancelTravel();
        };
    }
    const nameEl = plaque.querySelector(".plaque-name");
    const timerEl = plaque.querySelector(".plaque-timer");
    const barEl = plaque.querySelector(".plaque-bar-fill");
    const name = "🗺️ " + (t.icon || "") + " " + t.name;
    const time = "⏱ " + formatRemaining(remainMs);
    if (nameEl.textContent !== name) nameEl.textContent = name;
    if (timerEl.textContent !== time) timerEl.textContent = time;
    if (barEl) barEl.style.width = (progress * 100).toFixed(1) + "%";
}
window.renderTravelPlaque = renderTravelPlaque;

function startTravel(loc) {
    if (hasTravel()) { alert("Ты уже в пути."); return; }
    if (hasQuest()) { alert("Сначала закончи задание."); return; }
    if (typeof window.daoHasProfessionActivity === "function" && window.daoHasProfessionActivity()) {
        alert("Сначала заверши работу в мастерской или поход.");
        return;
    }
    if (getRealmIdx() < loc.reqRealm) { alert("Требуется: " + REALMS[loc.reqRealm]); return; }

    const now = Date.now();
    setTravel({
        locationId: loc.id,
        name: loc.name,
        icon: loc.icon,
        duration: loc.duration,
        risk: loc.risk,
        rewards: loc.rewards,
        startedAt: now,
        endsAt: now + loc.duration * 1000
    });
    closeTravelModal();
    pauseQi();
    renderTravelPlaque();
    saveGame();
    addLog("🗺️ Ты отправляешься в «" + loc.name + "». Путь займёт " + formatDuration(loc.duration) + ".", true);
}

function completeTravel(fromStartup) {
    const t = getTravel();
    if (!t) return;
    setTravel(null);
    resumeQi();
    renderTravelPlaque();

    const loc = LOCATIONS.find(function(l) { return l.id === t.locationId; }) || t;
    const ch = getCharacter();
    const hasShield = !!(ch && ch.talismanShield);

    let failed = loc.risk > 0 && Math.random() < loc.risk;
    let shieldUsed = false;

    // Щит покоя превращает провал в успех (v5.8.1)
    if (failed && hasShield) {
        failed = false;
        shieldUsed = true;
    }

    let gold = 0, stones = 0;
    let outcome = "";

    if (failed) {
        gold = Math.round(loc.rewards.gold[0] * 0.3);
        outcome = "Путешествие прошло неудачно. Едва унёс ноги.";
    } else {
        gold = randInt(loc.rewards.gold[0], loc.rewards.gold[1]);
        stones = randInt(loc.rewards.stones[0], loc.rewards.stones[1]);
        outcome = "Путешествие прошло успешно.";
    }

    if (gold > 0) addGold(gold);
    if (stones > 0) addStones(stones);

    // Снимаем щит, если он сработал
    if (shieldUsed && ch) {
        ch.talismanShield = false;
        saveCharacterObj(ch);
    }

    const prefix = fromStartup ? "Пока тебя не было, " : "";
    const rewardParts = [];
    if (gold > 0) rewardParts.push("+" + gold + " золота");
    if (stones > 0) rewardParts.push("+" + stones + " " + stonesWord(stones));
    const rewardStr = rewardParts.length > 0 ? rewardParts.join(", ") : "ничего";

    const logBox = document.getElementById("log");
    if (logBox) {
        const entry = document.createElement("div");
        entry.className = "log-entry log-breakthrough";
        entry.style.color = failed ? "#f85149" : "#d29922";
        entry.textContent = (failed ? "⚠ " : "🗺️ ") + prefix + "«" + loc.name + "» завершено. " + outcome + " " + rewardStr + ".";
        logBox.prepend(entry);

        if (shieldUsed) {
            const e2 = document.createElement("div");
            e2.className = "log-entry log-reward";
            e2.textContent = "🕊️ Талисман покоя превратил провал в успех!";
            logBox.prepend(e2);
        }
    }

    addTravelHistory({ at: Date.now(), location: loc.name, icon: loc.icon, gold: gold, stones: stones, failed: failed });
    if (typeof flashReward === "function") flashReward(failed ? "248,81,73" : "210,153,34");
    updateUI();
    saveGame();
}
window.completeTravel = completeTravel;

function cancelTravel() {
    const t = getTravel();
    if (!t) return;
    if (!confirm("Прервать путешествие в «" + t.name + "»?\n\nНаграда не будет начислена.")) return;
    setTravel(null);
    resumeQi();
    renderTravelPlaque();
    updateUI();
    saveGame();
    addLog("🗺️ Путешествие в «" + t.name + "» прервано.", true);
}

function injectTravelModal() {
    const old = document.getElementById("travel-modal");
    if (old) old.remove();
    const overlay = document.createElement("div");
    overlay.id = "travel-modal";
    overlay.className = "modal-overlay";
    overlay.innerHTML =
        '<div class="modal">' +
            '<div class="travel-header">' +
                '<h2>Путешествие</h2>' +
                '<div class="travel-sub">Ты покидаешь место культивации. Возвращайся с добычей — или с пустыми руками.</div>' +
            '</div>' +
            '<div class="travel-body" id="travel-body"></div>' +
            '<div class="travel-footer">' +
                '<button id="close-travel-btn">Закрыть</button>' +
            '</div>' +
        '</div>';
    document.body.appendChild(overlay);
    overlay.querySelector("#close-travel-btn").onclick = function() { overlay.classList.remove("show"); };
    overlay.onclick = function(e) { if (e.target === overlay) overlay.classList.remove("show"); };
}

function renderTravelBody() {
    const body = document.getElementById("travel-body");
    if (!body) return;
    const realmIdx = getRealmIdx();
    const active = hasTravel();
    const onQuest = hasQuest();
    const busyProf = typeof window.daoHasProfessionActivity === "function" && window.daoHasProfessionActivity();

    let html = "";
    if (active) {
        html += '<div style="background:linear-gradient(90deg,rgba(210,153,34,.12),rgba(210,153,34,.02));border:1px solid #d29922;border-radius:8px;padding:10px 14px;font-size:.85rem;color:#d29922;margin-bottom:12px;text-align:center;">🗺️ Ты уже в пути: <b>' + active.name + '</b><br>Вернёшься — сможешь отправиться снова.</div>';
    } else if (onQuest) {
        html += '<div style="background:linear-gradient(90deg,rgba(46,160,67,.12),rgba(46,160,67,.02));border:1px solid var(--jade);border-radius:8px;padding:10px 14px;font-size:.85rem;color:var(--jade-glow);margin-bottom:12px;text-align:center;">📜 Ты на задании. Закончи его, прежде чем отправиться в путь.</div>';
    } else if (busyProf) {
        html += '<div style="background:linear-gradient(90deg,rgba(210,153,34,.12),rgba(210,153,34,.02));border:1px solid #d29922;border-radius:8px;padding:10px 14px;font-size:.85rem;color:#d29922;margin-bottom:12px;text-align:center;">⚒️ Ты занят в мастерской. Заверши работу.</div>';
    }

    html += '<div class="loc-cards">';
    LOCATIONS.forEach(function(loc) {
        const locked = realmIdx < loc.reqRealm;
        const canStart = !locked && !active && !onQuest && !busyProf;
        const goldMin = loc.rewards.gold[0], goldMax = loc.rewards.gold[1];
        const stoneMin = loc.rewards.stones[0], stoneMax = loc.rewards.stones[1];
        const stoneText = stoneMin === stoneMax ? stoneMin + " " + stonesWord(stoneMin) : stoneMin + "–" + stoneMax + " " + stonesWord(stoneMax);
        const riskPct = Math.round(loc.risk * 100);

        let badge = locked ? '<span class="loc-badge locked">🔒 ' + REALMS[loc.reqRealm] + '</span>' : "";

        html +=
            '<div class="loc-card' + (locked ? " locked" : "") + '">' +
                '<div class="loc-head">' +
                    '<div class="loc-icon">' + loc.icon + '</div>' +
                    '<div class="loc-info">' +
                        '<div class="loc-name">' + loc.name + '</div>' +
                        '<div class="loc-desc">' + loc.desc + '</div>' +
                    '</div>' +
                    badge +
                '</div>' +
                '<div class="loc-stats">' +
                    '<span class="s">⏱ <b>' + formatDuration(loc.duration) + '</b></span>' +
                    '<span class="s gold">💰 <b>' + goldMin + '–' + goldMax + '</b></span>' +
                    '<span class="s stone">💠 <b>' + stoneText + '</b></span>' +
                    (riskPct > 0 ? '<span class="s risk">⚠ <b>' + riskPct + '%</b></span>' : '') +
                '</div>' +
                '<button class="loc-start" data-loc-id="' + loc.id + '"' + (canStart ? "" : " disabled") + '>' +
                    (locked ? "🔒 Закрыто" : (active ? "Ты уже в пути" : (onQuest ? "Сначала закончи задание" : (busyProf ? "⚒️ Занят" : "Отправиться")))) +
                '</button>' +
            '</div>';
    });
    html += '</div>';

    const history = getTravelHistory();
    html += '<div class="travel-history"><div class="travel-history-title">История путешествий</div>';
    if (history.length === 0) {
        html += '<div class="travel-history-empty">Пока пусто. Отправляйся в путь — и здесь появятся записи.</div>';
    } else {
        history.forEach(function(h) {
            const d = new Date(h.at);
            const date = d.toLocaleDateString("ru-RU") + " " + d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
            const rp = [];
            if (h.gold > 0) rp.push("+" + h.gold + " зол.");
            if (h.stones > 0) rp.push("+" + h.stones + " 💠");
            const rt = rp.length > 0 ? rp.join(" ") : "без добычи";
            html += '<div class="travel-history-item">' +
                (h.failed ? "⚠" : "✓") + ' <span class="lbl">' + (h.icon || "🗺️") + ' ' + h.location + '</span> · ' + date + ' · <span class="rew">' + rt + '</span>' +
            '</div>';
        });
    }
    html += '</div>';

    body.innerHTML = html;

    body.querySelectorAll(".loc-start").forEach(function(btn) {
        if (btn.disabled) return;
        btn.onclick = function(e) {
            e.preventDefault(); e.stopPropagation();
            const loc = LOCATIONS.find(function(l) { return l.id === btn.dataset.locId; });
            if (!loc) return;
            const riskPct = Math.round(loc.risk * 100);
            const msg =
                "Отправиться в «" + loc.name + "»?\n\n" +
                "⏱ Время: " + formatDuration(loc.duration) + "\n" +
                "💰 Золото: " + loc.rewards.gold[0] + "–" + loc.rewards.gold[1] + "\n" +
                "💠 Камни: " + loc.rewards.stones[0] + "–" + loc.rewards.stones[1] + "\n" +
                (riskPct > 0 ? "⚠ Риск неудачи: " + riskPct + "%\n" : "") +
                "\nКультивация остановится.";
            if (!confirm(msg)) return;
            startTravel(loc);
        };
    });
}

function openTravelModal() {
    injectTravelModal();
    renderTravelBody();
    document.getElementById("travel-modal").classList.add("show");
}
function closeTravelModal() {
    const o = document.getElementById("travel-modal");
    if (o) o.classList.remove("show");
}
window.openTravelModal = openTravelModal;
window.closeTravelModal = closeTravelModal;

// ============================================================
// ЧАСТЬ 5. ОКНО ПЕРСОНАЖА
// ============================================================

function openCombatTab() {
    openCharacterModal();
    setTimeout(function() {
        const overlay = document.getElementById("character-modal");
        if (!overlay) return;
        const tab = overlay.querySelector('.tab[data-tab="combat"]');
        if (!tab) return;
        overlay.querySelectorAll(".tab").forEach(function(t) { t.classList.remove("active"); });
        tab.classList.add("active");
        switchTab("combat");
    }, 80);
}
window.daoOpenCombatTab = openCombatTab;

function injectCharacterModal() {
    const old = document.getElementById("character-modal");
    if (old) old.remove();
    const overlay = document.createElement("div");
    overlay.id = "character-modal";
    overlay.className = "modal-overlay";
    overlay.innerHTML =
        '<div class="modal">' +
            '<div class="char-header" id="char-header"></div>' +
            '<div class="tabs">' +
                '<button class="tab active" data-tab="general">ОБЩЕЕ</button>' +
                '<button class="tab" data-tab="meditation">ТЕХНИКИ</button>' +
                '<button class="tab" data-tab="combat">БОЕВЫЕ</button>' +
                '<button class="tab" data-tab="inventory">ИНВЕНТАРЬ</button>' +
                '<button class="tab" data-tab="exchange">МЕНЯЛА</button>' +
            '</div>' +
            '<div class="tab-content" id="char-content"></div>' +
            '<div class="char-footer">' +
                '<button id="close-char-btn">Закрыть</button>' +
            '</div>' +
        '</div>';
    document.body.appendChild(overlay);
    overlay.querySelector("#close-char-btn").onclick = function() { overlay.classList.remove("show"); };
    overlay.onclick = function(e) { if (e.target === overlay) overlay.classList.remove("show"); };
    overlay.querySelectorAll(".tab").forEach(function(tab) {
        tab.onclick = function() {
            overlay.querySelectorAll(".tab").forEach(function(t) { t.classList.remove("active"); });
            tab.classList.add("active");
            switchTab(tab.dataset.tab);
        };
    });
}

function renderCharHeader() {
    const header = document.getElementById("char-header");
    if (!header) return;
    const ch = getCharacter();
    if (!ch) return;
    const cultivator = !!ch.isCultivator;
    const realmName = cultivator ? REALMS[getRealmIdx()] : "Смертный";
    const badge = cultivator
        ? '<span class="char-header-status cultivator">Культиватор</span>'
        : '<span class="char-header-status mortal">Смертный</span>';

    let html = '<h2>' +
        '<span class="char-header-name">' + (ch.name || "Безымянный") + '</span>' +
        '<span class="char-header-tag">· ' + realmName + '</span>' +
        badge +
    '</h2>';

    const q = getQuest();
    if (q) {
        const remainMs = Math.max(0, q.endsAt - Date.now());
        const sec = Math.ceil(remainMs / 1000);
        const m = Math.floor(sec / 60), r = sec % 60;
        const timeText = sec < 60 ? sec + " сек" : m + ":" + (r < 10 ? "0" + r : r);
        const cls = q.isStone ? "char-header-quest stone" : "char-header-quest";
        html += '<div class="' + cls + '"><span class="q-name">' + (q.isStone ? "💠" : "📜") + ' ' + q.name + '</span><span class="q-timer">⏱ ' + timeText + '</span></div>';
    } else {
        html += '<div class="char-sub">' + (cultivator ? "Путь продолжается" : "Смертный до становления культиватором") + '</div>';
    }
    header.innerHTML = html;
}

function switchTab(tab) {
    switch (tab) {
        case "general":    renderGeneralTab(); break;
        case "meditation": renderMeditationTab(); break;
        case "combat":     renderCombatTab(); break;
        case "inventory":  renderInventoryTab(); break;
        case "exchange":   renderExchangeTab(); break;
        default:           renderGeneralTab();
    }
}

function renderGeneralTab() {
    const content = document.getElementById("char-content");
    if (!content) return;
    const ch = getCharacter();
    if (!ch) { content.innerHTML = '<div class="section-stub">Нет персонажа.</div>'; return; }

    const cultivator = !!ch.isCultivator;
    const realmIndex = Math.floor(currentStageIndex / 9);
    const layerIndex = currentStageIndex % 9;
    const need = targets[currentStageIndex] || 100;
    const progressPct = cultivator ? Math.min((qi / need) * 100, 100) : 0;
    const days = daysSince(ch.rolledAt);
    const daysText = days === 0 ? "сегодня" : days + " " + daysWord(days);
    const age = getCurrentAge(ch);
    const starter = STARTER_TECHS.find(function(t) { return t.id === ch.starterTech; });
    const gold = ch.gold || 0;
    const stones = ch.stones || 0;

    const originName = (ch.origin && ch.origin.name) || "неизвестно";
    const originIcon = (ch.origin && ch.origin.icon) || "❔";
    const rootName = (ch.root && ch.root.name) || "неизвестно";
    const rootIcon = (ch.root && ch.root.icon) || "❔";
    const natureName = (ch.nature && ch.nature.name) || "неизвестно";
    const natureIcon = (ch.nature && ch.nature.icon) || "❔";
    const natureEl = (ch.nature && ch.nature.element) || "";

    let html =
        '<div class="info-section">' +
            '<div class="info-header">Личность</div>' +
            '<div class="info-row"><span class="label">Имя</span><span class="value gold">' + (ch.name || "Безымянный") + '</span></div>' +
            '<div class="info-row"><span class="label">Возраст</span><span class="value">' + age + ' ' + ageWord(age) + '</span></div>' +
            '<div class="info-row"><span class="label">Происхождение</span><span class="value"><span class="with-icon">' + originIcon + ' ' + originName + '</span></span></div>' +
            '<div class="info-row"><span class="label">Духовный корень</span><span class="value"><span class="with-icon">' + rootIcon + ' ' + rootName + '</span></span></div>' +
            '<div class="info-row"><span class="label">Характер</span><span class="value"><span class="with-icon">' + natureIcon + ' ' + natureName + (natureEl ? ' · ' + natureEl : '') + '</span></span></div>' +
            '<div class="info-row"><span class="label">Начало пути</span><span class="value">' + formatDate(ch.rolledAt) + '</span></div>' +
            '<div class="info-row"><span class="label">Использовано перебросов</span><span class="value">' + (ch.rerollsUsed || 0) + ' из 3</span></div>' +
        '</div>' +
        '<div class="info-section">' +
            '<div class="info-header">Культивация</div>' +
            '<div class="info-row"><span class="label">Статус</span><span class="value ' + (cultivator ? "green" : "dim") + '">' + (cultivator ? "Культиватор" : "Смертный") + '</span></div>' +
            '<div class="info-row"><span class="label">Царство</span><span class="value">' + (cultivator ? REALMS[realmIndex] : "—") + '</span></div>' +
            '<div class="info-row"><span class="label">Слой</span><span class="value">' + (cultivator ? LAYER_NAMES[layerIndex] : "—") + '</span></div>' +
            '<div class="info-row"><span class="label">Ци</span><span class="value">' + (cultivator ? qi.toFixed(1) + " / " + need.toLocaleString("ru-RU") : "— / —") + '</span></div>' +
            (cultivator ? '<div class="mini-bar"><div class="mini-bar-fill" style="width:' + progressPct.toFixed(1) + '%;"></div></div>' : '') +
            '<div class="info-row"><span class="label">Приток</span><span class="value ' + (cultivator ? "green" : "dim") + '">' + (cultivator ? "+" + qiPerSecond.toFixed(2) + " / сек" : "нужна техника культивации") + '</span></div>' +
            '<div class="info-row"><span class="label">Прорывов совершено</span><span class="value">' + currentStageIndex + '</span></div>' +
            '<div class="info-row"><span class="label">Дней в пути</span><span class="value">' + daysText + '</span></div>' +
        '</div>';

    if (cultivator && starter) {
        html += '<div class="info-section">' +
            '<div class="info-header">Начало культивации</div>' +
            '<div class="info-row"><span class="label">Первая техника</span><span class="value gold">' + starter.icon + ' ' + starter.name + '</span></div>' +
        '</div>';
    }

    html += '<div class="info-section">' +
        '<div class="info-header">Богатство</div>' +
        '<div class="info-row"><span class="label">💠 Духовные камни</span><span class="value cyan">' + stones.toLocaleString("ru-RU") + ' ' + stonesWord(stones) + '</span></div>' +
        '<div class="info-row"><span class="label">💰 Золото</span><span class="value yellow">' + gold.toLocaleString("ru-RU") + '</span></div>' +
    '</div>';

    content.innerHTML = html;
}

function renderMeditationTab() {
    const content = document.getElementById("char-content");
    if (!content) return;
    const owned = TECHNIQUES.filter(function(t) { return getTechParts(t.id) > 0; });
    if (owned.length === 0) {
        content.innerHTML = '<div class="section-stub"><span class="stub-icon">📖</span>Пока ни одна техника культивации не изучена.<br><br>Изучи первую технику в разделе <b style="color:var(--gold);">📖 Техники</b>.</div>';
        return;
    }
    let html = "";
    owned.forEach(function(tech) {
        const parts = getTechParts(tech.id);
        const tot = tech.costs.length;
        const complete = isTechComplete(tech.id);
        const pct = Math.round((parts / tot) * 100);
        html +=
            '<div class="cb-card' + (complete ? " owned" : "") + '">' +
                '<div class="cb-head">' +
                    '<div class="cb-icon">' + tech.icon + '</div>' +
                    '<div class="cb-info">' +
                        '<div class="cb-name">' + tech.name + '</div>' +
                        '<div class="cb-desc">' + tech.desc + '</div>' +
                    '</div>' +
                    (complete ? '<span class="cb-badge owned">СОБРАНО</span>' : "") +
                '</div>' +
                '<div class="cb-mastery"><span>Освоение · ' + parts + ' / ' + tot + '</span><span class="pct">' + pct + '%</span></div>' +
                '<div class="cb-mastery-bar"><div class="cb-mastery-bar-fill" style="width:' + pct + '%;"></div></div>' +
                (parts > 0 ? '<div style="font-size:.76rem;color:var(--text-dim);">Активный бонус: <b style="color:#7ee7ff;">' + formatTechEffect(tech, parts - 1) + '</b></div>' : '') +
                (complete ? '<div style="margin-top:6px;padding:6px 8px;background:rgba(210,153,34,.10);border-left:2px solid var(--gold);border-radius:4px;font-size:.78rem;color:var(--gold);line-height:1.35;">✦ ' + getMasteryText(tech.id) + '</div>' : '') +
            '</div>';
    });
    content.innerHTML = html;
}

// Инвентарь: рисует ресурсы и продукты профессии, потом вызывает
// enrichInventory из ui.js, чтобы повесить кнопки действий.
function renderInventoryTab() {
    const content = document.getElementById("char-content");
    if (!content) return;
    const ch = getCharacter();
    if (!ch) { content.innerHTML = '<div class="section-stub">Нет персонажа.</div>'; return; }
    const prof = ch.profession;
    if (!prof) {
        content.innerHTML = '<div class="section-stub"><span class="stub-icon">🎒</span>Сначала выбери профессию.</div>';
        return;
    }
    const registry = window.daoProfessionsRegistry || {};
    const data = registry[prof.id];
    if (!data) {
        content.innerHTML = '<div class="section-stub">Данные профессии не найдены.</div>';
        return;
    }

    const g = data.gatherer, c = data.crafter;
    const res = prof.resources || {};
    const prods = prof.products || {};

    const ri = Object.keys(res).filter(function(k) { return res[k] > 0; }).map(function(k) {
        const r = g.resources.find(function(x) { return x.id === k; });
        return { icon: r ? r.icon : "❔", name: r ? r.name : k, count: res[k] };
    }).sort(function(a, b) { return b.count - a.count; });

    const pi = Object.keys(prods).filter(function(k) { return prods[k] > 0; }).map(function(k) {
        const r = c.recipes.find(function(x) { return x.id === k; });
        return { icon: r ? r.icon : "❔", name: r ? r.name : k, count: prods[k] };
    }).sort(function(a, b) { return b.count - a.count; });

    const tk = ri.length + pi.length;
    const tc = ri.reduce(function(s, i) { return s + i.count; }, 0) + pi.reduce(function(s, i) { return s + i.count; }, 0);

    function row(it) {
        return '<div style="background:#0d1117;border:1px solid #30363d;border-radius:8px;padding:8px 12px;margin-bottom:6px;display:flex;align-items:center;gap:10px;">' +
            '<div style="font-size:1.4rem;line-height:1;">' + it.icon + '</div>' +
            '<div style="flex:1;font-size:.85rem;color:var(--text-main);font-weight:600;">' + it.name + '</div>' +
            '<div style="font-size:1rem;font-weight:700;color:var(--jade-glow);font-variant-numeric:tabular-nums;min-width:40px;text-align:right;">×' + it.count + '</div>' +
        '</div>';
    }

    content.innerHTML =
        '<div style="background:linear-gradient(135deg,rgba(126,231,255,.05),rgba(46,160,67,.05));border:1px solid rgba(126,231,255,.2);border-radius:10px;padding:12px 14px;margin-bottom:16px;">' +
            '<div style="font-size:.68rem;color:var(--text-dim);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:8px;">Инвентарь</div>' +
            '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">' +
                '<div style="background:rgba(13,17,23,.4);border:1px solid #30363d;border-radius:8px;padding:8px;text-align:center;">' +
                    '<div style="font-size:1.05rem;font-weight:700;color:var(--cyan);font-variant-numeric:tabular-nums;">' + tk + '</div>' +
                    '<div style="font-size:.62rem;color:var(--text-dim);">видов</div>' +
                '</div>' +
                '<div style="background:rgba(13,17,23,.4);border:1px solid #30363d;border-radius:8px;padding:8px;text-align:center;">' +
                    '<div style="font-size:1.05rem;font-weight:700;color:var(--cyan);font-variant-numeric:tabular-nums;">' + tc + '</div>' +
                    '<div style="font-size:.62rem;color:var(--text-dim);">всего шт.</div>' +
                '</div>' +
            '</div>' +
        '</div>' +
        '<div style="font-size:.78rem;letter-spacing:1.5px;text-transform:uppercase;color:var(--gold);margin-bottom:10px;padding-bottom:6px;border-bottom:1px dashed #30363d;">' + g.icon + ' ' + g.resourceLabel + '</div>' +
        (ri.length === 0 ? '<div style="border:1px dashed #30363d;border-radius:8px;padding:14px;color:var(--text-dim);font-size:.76rem;text-align:center;">Пусто.</div>' : ri.map(row).join("")) +
        '<div style="font-size:.78rem;letter-spacing:1.5px;text-transform:uppercase;color:var(--gold);margin:18px 0 10px 0;padding-bottom:6px;border-bottom:1px dashed #30363d;">' + c.icon + ' ' + c.productLabel + '</div>' +
        (pi.length === 0 ? '<div style="border:1px dashed #30363d;border-radius:8px;padding:14px;color:var(--text-dim);font-size:.76rem;text-align:center;">Пусто.</div>' : pi.map(row).join(""));

    // Обогащаем кнопками (Выпить / Экипировать / Активировать) из ui.js
    setTimeout(function() {
        if (typeof window.daoEnrichInventory === "function") {
            try { window.daoEnrichInventory(); } catch (e) {}
        }
    }, 80);
}

function renderExchangeTab() {
    const content = document.getElementById("char-content");
    if (!content) return;
    const ch = getCharacter();
    if (!ch) { content.innerHTML = '<div class="section-stub">Нет персонажа.</div>'; return; }
    const gold = ch.gold || 0;
    const stones = ch.stones || 0;
    const cultivator = !!ch.isCultivator;
    const canExchange = gold >= EXCHANGE_RATE;
    const toFirst = Math.max(0, EXCHANGE_RATE - gold);

    let html =
        '<div class="ex-rate">' +
            'Курс менялы: <b>' + EXCHANGE_RATE + ' золота = 1 камень</b><br>' +
            '<span class="sub">У тебя: <b style="color:#f0c454;">💰 ' + gold.toLocaleString("ru-RU") + '</b> золота · <b style="color:#7ee7ff;">💠 ' + stones.toLocaleString("ru-RU") + '</b> камней</span>' +
            (!canExchange ? '<div class="hint">До первого обмена: <b style="color:#f0c454;">' + toFirst + ' золота</b></div>' : '') +
        '</div>' +
        '<div class="ex-buttons">' +
            '<button data-gold="' + EXCHANGE_RATE + '"' + (gold < EXCHANGE_RATE ? " disabled" : "") + '>Обменять ' + EXCHANGE_RATE + ' → 1</button>' +
            '<button data-gold="' + (EXCHANGE_RATE * 5) + '"' + (gold < EXCHANGE_RATE * 5 ? " disabled" : "") + '>Обменять ' + (EXCHANGE_RATE * 5) + ' → 5</button>' +
            '<button data-gold="' + (EXCHANGE_RATE * 10) + '"' + (gold < EXCHANGE_RATE * 10 ? " disabled" : "") + '>Обменять ' + (EXCHANGE_RATE * 10) + ' → 10</button>' +
            '<button data-gold="all"' + (gold < EXCHANGE_RATE ? " disabled" : "") + '>Обменять всё → ' + Math.floor(gold / EXCHANGE_RATE) + '</button>' +
        '</div>';

    if (!cultivator) {
        html += '<div class="starter-title">Стартовые техники культивации</div>';
        STARTER_TECHS.forEach(function(t) {
            const canAfford = stones >= t.cost;
            const needGold = t.cost * EXCHANGE_RATE;
            html +=
                '<div class="starter-card">' +
                    '<div class="row1"><div class="icon">' + t.icon + '</div><div class="name">' + t.name + '</div></div>' +
                    '<div class="desc">' + t.desc + '</div>' +
                    '<div class="meta"><span>Приток: <span class="gain">+' + t.baseQps.toFixed(2) + ' / сек</span></span><span class="price">💠 ' + t.cost + ' камней</span></div>' +
                    '<div class="price-gold">≈ ' + needGold.toLocaleString("ru-RU") + ' золота по курсу менялы</div>' +
                    '<button class="starter-buy" data-tech="' + t.id + '"' + (canAfford ? "" : " disabled") + '>' + (canAfford ? "Изучить технику" : "Не хватает камней") + '</button>' +
                '</div>';
        });
    } else {
        const starter = STARTER_TECHS.find(function(t) { return t.id === ch.starterTech; });
        html += '<div class="starter-title">Ты уже культиватор</div>' +
            '<div class="starter-card">' +
                '<div class="row1"><div class="icon">' + (starter ? starter.icon : "🌱") + '</div><div class="name">' + (starter ? starter.name : "Техника культивации") + '</div></div>' +
                '<div class="desc">Твой путь начался. Остальные техники — в разделе 📖 «Техники».</div>' +
            '</div>';
    }
    content.innerHTML = html;

    content.querySelectorAll(".ex-buttons button").forEach(function(b) {
        b.onclick = function() {
            const dataGold = b.dataset.gold;
            let amount = dataGold === "all" ? Math.floor((ch.gold || 0) / EXCHANGE_RATE) * EXCHANGE_RATE : parseInt(dataGold, 10);
            if (!amount || amount < EXCHANGE_RATE) return;
            const ch2 = getCharacter();
            if ((ch2.gold || 0) < amount) { alert("Недостаточно золота."); return; }
            ch2.gold -= amount;
            const gained = Math.floor(amount / EXCHANGE_RATE);
            ch2.stones = (ch2.stones || 0) + gained;
            saveCharacterObj(ch2);
            addLog("💱 Обмен: −" + amount + " золота, +" + gained + " камней.", true);
            renderExchangeTab();
            updateUI();
            saveGame();
        };
    });

    content.querySelectorAll(".starter-buy").forEach(function(b) {
        if (b.disabled) return;
        b.onclick = function() {
            const tid = b.dataset.tech;
            const tech = STARTER_TECHS.find(function(t) { return t.id === tid; });
            if (!tech) return;
            const ch2 = getCharacter();
            if ((ch2.stones || 0) < tech.cost) { alert("Не хватает камней."); return; }
            if (!confirm("Изучить «" + tech.name + "»?\n\nСтоимость: " + tech.cost + " камней.\nЭто начало твоего пути культивации.")) return;
            ch2.stones -= tech.cost;
            ch2.isCultivator = true;
            ch2.starterTech = tech.id;
            saveCharacterObj(ch2);
            recalcStats();
            updateUI();
            addLog("✦ Ты стал культиватором! Техника: «" + tech.name + "». Путь открыт.", true);
            saveGame();
            renderExchangeTab();
        };
    });
}

function openCharacterModal() {
    if (!document.getElementById("character-modal")) injectCharacterModal();
    const overlay = document.getElementById("character-modal");
    overlay.querySelectorAll(".tab").forEach(function(t) {
        t.classList.toggle("active", t.dataset.tab === "general");
    });
    renderCharHeader();
    renderGeneralTab();
    overlay.classList.add("show");
}
window.openCharacterModal = openCharacterModal;

// ============================================================
// ЧАСТЬ 6. ТИКИ
// ============================================================
setInterval(function() {
    const q = getQuest();
    if (q && Date.now() >= q.endsAt) { completeQuest(false); return; }
    if (q) renderQuestPlaque();
    const t = getTravel();
    if (t && Date.now() >= t.endsAt) { completeTravel(false); return; }
    if (t) renderTravelPlaque();
}, 500);

setInterval(function() {
    const overlay = document.getElementById("character-modal");
    if (overlay && overlay.classList.contains("show")) renderCharHeader();
}, 1000);

// ============================================================
// ЧАСТЬ 7. ЗАПУСК ИГРЫ
// ============================================================
window.onload = function() {
    try {
        localStorage.setItem("__dao_test", "1");
        localStorage.removeItem("__dao_test");
    } catch (e) {
        setTimeout(function() { addLog("⚠ Хранилище недоступно."); }, 400);
    }

    const hasChar = applyCharacter();
    loadGame();
    loadAllPatches();

    if (!hasChar) {
        setTimeout(function() {
            const ch = getCharacter();
            if (!ch) {
                const ack = (function() {
                    try { return localStorage.getItem("dao_onboarding_ack") === "1"; }
                    catch (e) { return false; }
                })();
                if (!ack) renderOnboarding();
            }
        }, 400);
    }

    const q = getQuest();
    if (q && Date.now() >= q.endsAt) completeQuest(true);
    else if (q) {
        pauseQi();
        renderQuestPlaque();
        addLog("📜 Задание продолжается: «" + q.name + "»", true);
    }

    const t = getTravel();
    if (t && Date.now() >= t.endsAt) completeTravel(true);
    else if (t) {
        pauseQi();
        renderTravelPlaque();
        addLog("🗺️ Путешествие продолжается: «" + t.name + "»", true);
    }

    updateUI();
    addLog("✓ Путь к Бессмертию v" + GAME_VERSION + " загружен", true);

    setInterval(passiveLoop, 100);
    setInterval(saveGame, 3000);

    document.addEventListener("visibilitychange", function() {
        if (document.visibilityState === "hidden") saveGame();
    });

    setTimeout(function() {
        const pref = getOrientationPref();
        if (pref === "auto") return;
        applyOrientation(pref);
    }, 400);
};
```

---

Готово

Ты заменил три файла:

· ✅ js/core.js
· ✅ js/ui.js
· ✅ js/gameplay.js

profession.js и index.html не трогались — они уже в порядке.

Что делать дальше

1. Сохрани все три файла.
2. ☰ → Настройки → Очистить все патчи (если они ещё висят — старые v5.8.1 больше не нужны, всё теперь в файлах).
3. Пересобери APK через HTML to APK Builder (папка project целиком).
4. Установи поверх старой версии (имя пакета то же, versionCode — +1).

Что проверить

· Версия в меню: должна быть 5.8.1.
· Кнопка ⚒️ — работает.
· Талисманы:
  · Открой инвентарь, у талисманов появится кнопка «Активировать».
  · Ясности / Удачи / Стойкости → дают бафф-чип под золотом.
  · Покоя → строка «🕊️ Щит покоя: активен».
  · Просветления → мгновенно начисляет Ци.

Всё. Можешь спокойно тестировать несколько дней. Если найдёшь баг или захочешь новую фичу — возвращайся, продолжим.