// ================================================================
//  PROFESSION.JS — Путь к Бессмертию v5.8
//  Профессии: 5 связок (добытчик + мастер)
//  Зависимости: core.js (данные, хранилище, утилиты)
//  Использует из core.js: randInt, formatDuration, formatRemaining,
//                          goldWord, stonesWord, getCharacter, saveCharacterObj,
//                          getRealmIdx, addLog, addGold, saveGame,
//                          hasQuest, hasTravel, updateUI
// ================================================================

(function() {
    "use strict";

    // ==================== ДАННЫЕ: 5 СВЯЗОК ====================
    const PROFESSIONS_DATA = {
        herbalist_alchemist: {
            id: "herbalist_alchemist",
            gatherer: {
                id: "herbalist", icon: "🌿", name: "Травник",
                desc: "Собирает травы в лесах и на склонах гор.",
                actionVerb: "в поход за травами",
                actionNoun: "поход",
                resourceLabel: "Травы",
                lengths: [
                    { id: "short",  icon: "🌿", name: "Короткий", timeSec: 60,  xp: 3,  min: 2,  max: 4,  rareChance: 0.05 },
                    { id: "medium", icon: "🌱", name: "Средний",  timeSec: 180, xp: 10, min: 8,  max: 15, rareChance: 0.15 },
                    { id: "long",   icon: "🌳", name: "Длинный",  timeSec: 600, xp: 30, min: 25, max: 35, rareChance: 0.30 }
                ],
                resources: [
                    { id: "moon_grass",   icon: "🌿", name: "Лунная трава",    weight: 4 },
                    { id: "earth_root",   icon: "🌱", name: "Земляной корень", weight: 4 },
                    { id: "jade_mint",    icon: "🍃", name: "Нефритовая мята", weight: 3 },
                    { id: "fire_leaf",    icon: "🔥", name: "Огненный лист",   weight: 2 },
                    { id: "silver_thorn", icon: "🌵", name: "Серебряный шип",  weight: 1 }
                ],
                prices: { moon_grass: 5, earth_root: 5, jade_mint: 7, fire_leaf: 12, silver_thorn: 20 }
            },
            crafter: {
                id: "alchemist", icon: "🧪", name: "Алхимик",
                desc: "Варит порошки, мази и отвары.",
                actionVerb: "варить",
                actionNoun: "варка",
                productLabel: "Снадобья",
                recipes: [
                    { id: "wound_powder", icon: "🌿", name: "Порошок от ран",     level: 0, timeSec: 20, needs: { moon_grass: 3 }, desc: "Лечит порезы и ушибы." },
                    { id: "warm_salve",   icon: "🧴", name: "Согревающая мазь",   level: 2, timeSec: 25, needs: { earth_root: 2, jade_mint: 1 }, desc: "От простуды и ломоты." },
                    { id: "vigor_brew",   icon: "🍵", name: "Отвар бодрости",     level: 4, timeSec: 35, needs: { jade_mint: 3, fire_leaf: 1 }, desc: "Снимает усталость." },
                    { id: "antidote",     icon: "🧪", name: "Противоядие",        level: 6, timeSec: 45, needs: { earth_root: 2, silver_thorn: 2 }, desc: "От яда змей и насекомых." },
                    { id: "sleep_powder", icon: "💊", name: "Снотворный порошок", level: 8, timeSec: 55, needs: { moon_grass: 3, fire_leaf: 2 }, desc: "Пик смертного ремесла." }
                ],
                prices: { wound_powder: 40, warm_salve: 80, vigor_brew: 150, antidote: 280, sleep_powder: 450 }
            }
        },
        miner_blacksmith: {
            id: "miner_blacksmith",
            gatherer: {
                id: "miner", icon: "⛏️", name: "Рудокоп",
                desc: "Спускается в шахты и находит руду в жилах земли.",
                actionVerb: "в поход за рудой",
                actionNoun: "поход",
                resourceLabel: "Руда",
                lengths: [
                    { id: "short",  icon: "⛏️", name: "Короткий", timeSec: 60,  xp: 3,  min: 2,  max: 4,  rareChance: 0.05 },
                    { id: "medium", icon: "🔨", name: "Средний",  timeSec: 180, xp: 10, min: 8,  max: 15, rareChance: 0.15 },
                    { id: "long",   icon: "⛰️", name: "Длинный",  timeSec: 600, xp: 30, min: 25, max: 35, rareChance: 0.30 }
                ],
                resources: [
                    { id: "copper_ore",     icon: "🪨", name: "Медная руда",     weight: 4 },
                    { id: "iron_ore",       icon: "⚙️", name: "Железная руда",   weight: 4 },
                    { id: "silver_ore",     icon: "🥈", name: "Серебряная руда", weight: 3 },
                    { id: "mithril_ore",    icon: "🔮", name: "Мифриловая руда", weight: 2 },
                    { id: "adamantite_ore", icon: "💎", name: "Адамантит",        weight: 1 }
                ],
                prices: { copper_ore: 6, iron_ore: 10, silver_ore: 18, mithril_ore: 35, adamantite_ore: 60 }
            },
            crafter: {
                id: "blacksmith", icon: "⚒️", name: "Кузнец",
                desc: "Куёт оружие, доспехи и рунные клинки.",
                actionVerb: "ковать",
                actionNoun: "ковка",
                productLabel: "Оружие и доспехи",
                recipes: [
                    { id: "dagger",     icon: "🗡️", name: "Кинжал",          level: 0, timeSec: 25, needs: { copper_ore: 3 }, desc: "Простое оружие ближнего боя." },
                    { id: "axe",        icon: "🪓", name: "Топор",           level: 2, timeSec: 35, needs: { iron_ore: 2, copper_ore: 1 }, desc: "Тяжёлое оружие, бьёт сильно." },
                    { id: "chainmail",  icon: "🛡️", name: "Кольчуга",        level: 4, timeSec: 45, needs: { iron_ore: 3, silver_ore: 1 }, desc: "Лёгкая защита для тела." },
                    { id: "shield",     icon: "🛡️", name: "Щит",             level: 6, timeSec: 55, needs: { silver_ore: 2, mithril_ore: 2 }, desc: "Надёжная защита в бою." },
                    { id: "rune_blade", icon: "⚔️", name: "Рунный клинок",   level: 8, timeSec: 75, needs: { mithril_ore: 3, adamantite_ore: 2 }, desc: "Оружие для настоящего воина." }
                ],
                prices: { dagger: 50, axe: 100, chainmail: 200, shield: 380, rune_blade: 650 }
            }
        },
        calli_scribes: {
            id: "calli_scribes",
            gatherer: {
                id: "calligrapher", icon: "✒️", name: "Каллиграф",
                desc: "Собирает материалы для письма и изучает искусство знаков.",
                actionVerb: "в поход за материалами",
                actionNoun: "поход",
                resourceLabel: "Материалы письма",
                lengths: [
                    { id: "short",  icon: "✒️", name: "Короткий", timeSec: 60,  xp: 3,  min: 2,  max: 4,  rareChance: 0.05 },
                    { id: "medium", icon: "📄", name: "Средний",  timeSec: 180, xp: 10, min: 8,  max: 15, rareChance: 0.15 },
                    { id: "long",   icon: "📜", name: "Длинный",  timeSec: 600, xp: 30, min: 25, max: 35, rareChance: 0.30 }
                ],
                resources: [
                    { id: "ink",       icon: "🖋️", name: "Тушь",            weight: 4 },
                    { id: "silk",      icon: "📄", name: "Шёлк",            weight: 4 },
                    { id: "parchment", icon: "📜", name: "Пергамент",       weight: 3 },
                    { id: "cinnabar",  icon: "🖍️", name: "Киноварь",        weight: 2 },
                    { id: "sky_paper", icon: "✨", name: "Небесная бумага", weight: 1 }
                ],
                prices: { ink: 5, silk: 6, parchment: 9, cinnabar: 14, sky_paper: 25 }
            },
            crafter: {
                id: "seal_master", icon: "📜", name: "Мастер печатей",
                desc: "Чертит талисманы силой знака и духа.",
                actionVerb: "чертить",
                actionNoun: "черчение",
                productLabel: "Талисманы",
                recipes: [
                    { id: "clarity_seal",   icon: "📜", name: "Талисман ясности",      level: 0, timeSec: 20, needs: { ink: 3 }, desc: "Помогает сосредоточиться." },
                    { id: "fortune_seal",   icon: "📜", name: "Талисман удачи",        level: 2, timeSec: 25, needs: { silk: 2, ink: 1 }, desc: "Приносит удачу в пути." },
                    { id: "calm_seal",      icon: "📜", name: "Талисман покоя",        level: 4, timeSec: 35, needs: { parchment: 3, cinnabar: 1 }, desc: "Успокаивает духов и зверей." },
                    { id: "steadfast_seal", icon: "📜", name: "Талисман стойкости",    level: 6, timeSec: 45, needs: { cinnabar: 3, sky_paper: 1 }, desc: "Укрепляет тело перед боем." },
                    { id: "enlight_seal",   icon: "📜", name: "Талисман просветления", level: 8, timeSec: 55, needs: { sky_paper: 3, cinnabar: 2 }, desc: "Пик смертного ремесла." }
                ],
                prices: { clarity_seal: 50, fortune_seal: 100, calm_seal: 200, steadfast_seal: 380, enlight_seal: 600 }
            }
        },
        pearl_jeweler: {
            id: "pearl_jeweler",
            gatherer: {
                id: "pearl_diver", icon: "🐚", name: "Ловец жемчуга",
                desc: "Ныряет в глубины и достаёт жемчуг со дна морей.",
                actionVerb: "в глубины за жемчугом",
                actionNoun: "погружение",
                resourceLabel: "Жемчуг и камни",
                lengths: [
                    { id: "short",  icon: "🐚", name: "Короткое", timeSec: 60,  xp: 3,  min: 2,  max: 4,  rareChance: 0.05 },
                    { id: "medium", icon: "🌊", name: "Среднее",  timeSec: 180, xp: 10, min: 8,  max: 15, rareChance: 0.15 },
                    { id: "long",   icon: "🐋", name: "Длинное",  timeSec: 600, xp: 30, min: 25, max: 35, rareChance: 0.30 }
                ],
                resources: [
                    { id: "river_pearl",  icon: "⚪", name: "Речной жемчуг",     weight: 4 },
                    { id: "sea_pearl",    icon: "🟡", name: "Морской жемчуг",    weight: 4 },
                    { id: "black_pearl",  icon: "⚫", name: "Чёрный жемчуг",     weight: 3 },
                    { id: "jade_stone",   icon: "🟢", name: "Нефритовый камень", weight: 2 },
                    { id: "spirit_stone", icon: "💠", name: "Духовный камень",   weight: 1 }
                ],
                prices: { river_pearl: 6, sea_pearl: 9, black_pearl: 15, jade_stone: 22, spirit_stone: 40 }
            },
            crafter: {
                id: "jeweler", icon: "💠", name: "Ювелир",
                desc: "Огранивает камни и делает амулеты, что хранят силу.",
                actionVerb: "огранить",
                actionNoun: "огранка",
                productLabel: "Амулеты",
                recipes: [
                    { id: "pearl_ring",     icon: "💍", name: "Кольцо с жемчугом",  level: 0, timeSec: 25, needs: { river_pearl: 2 }, desc: "Простое украшение." },
                    { id: "sea_pendant",    icon: "📿", name: "Морской подвесок",   level: 2, timeSec: 30, needs: { sea_pearl: 2, river_pearl: 1 }, desc: "Подвеска на ветру." },
                    { id: "jade_bracelet",  icon: "🟢", name: "Нефритовый браслет", level: 4, timeSec: 45, needs: { jade_stone: 2, sea_pearl: 1 }, desc: "Успокаивает дух." },
                    { id: "black_talisman", icon: "⚫", name: "Тёмный оберег",       level: 6, timeSec: 55, needs: { black_pearl: 2, jade_stone: 2 }, desc: "Защищает от дурного глаза." },
                    { id: "spirit_amulet",  icon: "💠", name: "Амулет духа",        level: 8, timeSec: 75, needs: { spirit_stone: 2, black_pearl: 2 }, desc: "Хранит частицу духа." }
                ],
                prices: { pearl_ring: 60, sea_pendant: 120, jade_bracelet: 240, black_talisman: 420, spirit_amulet: 700 }
            }
        },
        engraver_formation: {
            id: "engraver_formation",
            gatherer: {
                id: "engraver", icon: "🪚", name: "Гравёр",
                desc: "Ищет камни и дерево, пригодные для тонкой резьбы знаков.",
                actionVerb: "в поисках материалов",
                actionNoun: "поиск",
                resourceLabel: "Материалы для резьбы",
                lengths: [
                    { id: "short",  icon: "🪚", name: "Короткий", timeSec: 60,  xp: 3,  min: 2,  max: 4,  rareChance: 0.05 },
                    { id: "medium", icon: "🪵", name: "Средний",  timeSec: 180, xp: 10, min: 8,  max: 15, rareChance: 0.15 },
                    { id: "long",   icon: "🪨", name: "Длинный",  timeSec: 600, xp: 30, min: 25, max: 35, rareChance: 0.30 }
                ],
                resources: [
                    { id: "soft_wood",  icon: "🪵", name: "Мягкое дерево",    weight: 4 },
                    { id: "dark_stone", icon: "🪨", name: "Тёмный камень",    weight: 4 },
                    { id: "rune_slate", icon: "⬛", name: "Рунный сланец",    weight: 3 },
                    { id: "stargold",   icon: "🟡", name: "Звёздное золото",  weight: 2 },
                    { id: "void_gem",   icon: "🟣", name: "Пустотный камень", weight: 1 }
                ],
                prices: { soft_wood: 5, dark_stone: 8, rune_slate: 14, stargold: 24, void_gem: 45 }
            },
            crafter: {
                id: "formation_master", icon: "🕸️", name: "Мастер формаций",
                desc: "Вырезает знаки, из которых сплетаются защитные построения.",
                actionVerb: "вырезать",
                actionNoun: "резьба",
                productLabel: "Формации",
                recipes: [
                    { id: "ward_lesser",  icon: "🕸️", name: "Малый оберег",         level: 0, timeSec: 25, needs: { soft_wood: 2 }, desc: "Простая формация для дома." },
                    { id: "seal_ward",    icon: "🔷", name: "Печать защиты",        level: 2, timeSec: 35, needs: { dark_stone: 2, soft_wood: 1 }, desc: "Отгоняет мелких духов." },
                    { id: "rune_circle",  icon: "⚪", name: "Круг рун",             level: 4, timeSec: 50, needs: { rune_slate: 3, dark_stone: 1 }, desc: "Усиливает культивацию рядом." },
                    { id: "star_pattern", icon: "🌟", name: "Звёздный узор",        level: 6, timeSec: 65, needs: { stargold: 2, rune_slate: 2 }, desc: "Ловит энергию звёзд." },
                    { id: "void_array",   icon: "🟣", name: "Пустотное построение", level: 8, timeSec: 85, needs: { void_gem: 2, stargold: 3 }, desc: "Ломает реальность." }
                ],
                prices: { ward_lesser: 70, seal_ward: 150, rune_circle: 300, star_pattern: 500, void_array: 850 }
            }
        }
    };

    window.daoProfessionsData = PROFESSIONS_DATA;

    // ==================== ХРАНИЛИЩЕ ПРОФЕССИИ ====================
    function getProf() {
        const ch = getCharacter();
        return ch ? ch.profession : null;
    }
    function saveProf(p) {
        const ch = getCharacter();
        if (!ch) return;
        ch.profession = p;
        saveCharacterObj(ch);
    }
    function getProfData() {
        const p = getProf();
        return p ? (PROFESSIONS_DATA[p.id] || null) : null;
    }

    // ==================== МИГРАЦИЯ СТАРЫХ ПОЛЕЙ ====================
    (function migrate() {
        const p = getProf();
        if (!p) return;
        let changed = false;
        if (p.herbs && !p.resources) { p.resources = p.herbs; delete p.herbs; changed = true; }
        if (p.ores && !p.resources) { p.resources = p.ores; delete p.ores; changed = true; }
        if (p.potions && !p.products) { p.products = p.potions; delete p.potions; changed = true; }
        if (p.weapons && !p.products) { p.products = p.weapons; delete p.weapons; changed = true; }
        if (p.gatherQuest && !p.activeGather) { p.activeGather = p.gatherQuest; delete p.gatherQuest; changed = true; }
        if (p.gatherQuest2 && !p.activeGather) { p.activeGather = p.gatherQuest2; delete p.gatherQuest2; changed = true; }
        if (p.craftQuest && !p.activeCraft) { p.activeCraft = p.craftQuest; delete p.craftQuest; changed = true; }
        if (p.craftQuest2 && !p.activeCraft) { p.activeCraft = p.craftQuest2; delete p.craftQuest2; changed = true; }
        if (!p.resources) { p.resources = {}; changed = true; }
        if (!p.products) { p.products = {}; changed = true; }
        if (changed) saveProf(p);
    })();

    // ==================== УРОВНИ ====================
    function maxLevel() { return Math.min(80, 8 + 9 * getRealmIdx()); }
    function xpForGatherer(lv) { return 10 * (Math.floor(lv / 9) + 1); }
    function xpForCrafter(lv) { return 5 * (Math.floor(lv / 9) + 1); }

    function grantGathererXp(xp) {
        const p = getProf();
        if (!p) return;
        const maxL = maxLevel();
        if ((p.gathererLevel || 0) >= maxL) return;
        p.gathererXp = (p.gathererXp || 0) + xp;
        let leveled = false;
        while ((p.gathererLevel || 0) < maxL) {
            if (p.gathererXp >= xpForGatherer(p.gathererLevel)) {
                p.gathererXp -= xpForGatherer(p.gathererLevel);
                p.gathererLevel++;
                leveled = true;
            } else break;
        }
        saveProf(p);
        if (leveled) {
            const d = getProfData();
            addLog((d ? d.gatherer.icon : "🌿") + " " + (d ? d.gatherer.name : "Добытчик") + " достиг уровня " + p.gathererLevel + "!", true);
        }
    }
    function grantCrafterXp(xp) {
        const p = getProf();
        if (!p) return;
        const hardCap = Math.min(maxLevel(), p.gathererLevel || 0);
        if ((p.crafterLevel || 0) >= hardCap) return;
        p.crafterXp = (p.crafterXp || 0) + xp;
        let leveled = false;
        while ((p.crafterLevel || 0) < hardCap) {
            if (p.crafterXp >= xpForCrafter(p.crafterLevel)) {
                p.crafterXp -= xpForCrafter(p.crafterLevel);
                p.crafterLevel++;
                leveled = true;
            } else break;
        }
        saveProf(p);
        if (leveled) {
            const d = getProfData();
            addLog((d ? d.crafter.icon : "🧪") + " " + (d ? d.crafter.name : "Мастер") + " достиг уровня " + p.crafterLevel + "!", true);
        }
    }

    // ==================== ХЕЛПЕРЫ ====================
    function pickResource(resources, lucky) {
        const weights = resources.map(function(r) { return lucky && r.weight <= 2 ? r.weight * 3 : r.weight; });
        const total = weights.reduce(function(s, w) { return s + w; }, 0);
        let v = Math.random() * total;
        for (let i = 0; i < resources.length; i++) { v -= weights[i]; if (v <= 0) return resources[i]; }
        return resources[0];
    }
    function craftChance(recipe, crafterLvl) {
        const diff = (recipe.level || 0) - crafterLvl;
        if (diff <= 0) return 1;
        return Math.max(0.40, 1 - diff * 0.05);
    }

    // ==================== ПАУЗА КУЛЬТИВАЦИИ (общая) ====================
    let _frozenQps = null;
    function freeze() {
        if (_frozenQps === null && typeof qiPerSecond === "number") _frozenQps = qiPerSecond;
        qiPerSecond = 0;
        if (typeof updateUI === "function") updateUI();
    }
    function unfreeze() {
        if (_frozenQps !== null) { qiPerSecond = _frozenQps; _frozenQps = null; }
        else if (typeof recalcStats === "function") recalcStats();
        if (typeof updateUI === "function") updateUI();
    }

    // ==================== ФЛАГ АКТИВНОСТИ ====================
    // Используется из ui.js (refreshActions) и core.js (passiveLoop)
    function hasActivity() {
        const p = getProf();
        if (!p) return false;
        return !!(p.activeGather || p.activeCraft);
    }
    window.daoHasProfessionActivity = hasActivity;

    // ==================== ДОБЫЧА ====================
    function startGather(lengthId) {
        const p = getProf();
        const d = getProfData();
        if (!p || !d) return;
        if (p.activeGather) { alert("Ты уже в походе."); return; }
        if (p.activeCraft) { alert("Сначала закончи работу в мастерской."); return; }
        if (typeof hasQuest === "function" && hasQuest()) { alert("Сначала закончи задание."); return; }
        if (typeof hasTravel === "function" && hasTravel()) { alert("Ты в путешествии."); return; }
        const length = d.gatherer.lengths.find(function(l) { return l.id === lengthId; });
        if (!length) return;
        const now = Date.now();
        p.activeGather = {
            lengthId: length.id, name: length.name, icon: length.icon,
            startedAt: now, endsAt: now + length.timeSec * 1000
        };
        saveProf(p);
        freeze();
        renderPlaques();
        try { saveGame(); } catch (e) {}
        addLog(d.gatherer.icon + " Ты отправляешься " + d.gatherer.actionVerb + " (" + length.name.toLowerCase() + ").", true);
    }

    function completeGather(fromStartup) {
        const p = getProf();
        const d = getProfData();
        if (!p || !p.activeGather || !d) return;
        const q = p.activeGather;
        p.activeGather = null;
        const length = d.gatherer.lengths.find(function(l) { return l.id === q.lengthId; });
        if (!length) { saveProf(p); return; }

        if (!p.resources) p.resources = {};
        const count = randInt(length.min, length.max);
        const granted = {};
        for (let i = 0; i < count; i++) {
            const lucky = Math.random() < length.rareChance;
            const r = pickResource(d.gatherer.resources, lucky);
            granted[r.id] = (granted[r.id] || 0) + 1;
        }
        Object.keys(granted).forEach(function(k) { p.resources[k] = (p.resources[k] || 0) + granted[k]; });
        saveProf(p);
        grantGathererXp(length.xp);

        const prefix = fromStartup ? "Пока тебя не было, " : "";
        const list = Object.keys(granted).map(function(k) {
            const r = d.gatherer.resources.find(function(x) { return x.id === k; });
            return r.icon + " " + r.name + " ×" + granted[k];
        }).join(", ");
        addLog(d.gatherer.icon + " " + prefix + "поход завершён. Принесено: " + list + ". +" + length.xp + " опыта.", true);
        unfreeze();
        renderPlaques();
        try { saveGame(); } catch (e) {}
    }

    function cancelGather() {
        const p = getProf();
        if (!p || !p.activeGather) return;
        if (!confirm("Прервать поход?")) return;
        p.activeGather = null;
        saveProf(p);
        unfreeze();
        renderPlaques();
        try { saveGame(); } catch (e) {}
    }

    // ==================== КРАФТ ====================
    function canCraft(recipe) {
        const p = getProf();
        const d = getProfData();
        if (!p || !d) return { ok: false };
        const gL = p.gathererLevel || 0;
        const cL = p.crafterLevel || 0;
        if (gL < 5) return { ok: false, reason: "gatherer_low" };
        if ((recipe.level || 0) > maxLevel()) return { ok: false, reason: "realm" };
        const cap = Math.min(maxLevel(), gL);
        if (cL > cap) return { ok: false, reason: "crafter_cap" };
        const res = p.resources || {};
        const keys = Object.keys(recipe.needs);
        for (let i = 0; i < keys.length; i++) {
            if ((res[keys[i]] || 0) < recipe.needs[keys[i]]) return { ok: false, reason: "no_res" };
        }
        return { ok: true };
    }

    function startCraft(recipeId) {
        const p = getProf();
        const d = getProfData();
        if (!p || !d) return;
        if (p.activeCraft) { alert("Ты уже работаешь."); return; }
        if (p.activeGather) { alert("Сначала вернись из похода."); return; }
        if (typeof hasQuest === "function" && hasQuest()) { alert("Сначала закончи задание."); return; }
        if (typeof hasTravel === "function" && hasTravel()) { alert("Ты в путешествии."); return; }
        const recipe = d.crafter.recipes.find(function(r) { return r.id === recipeId; });
        if (!recipe) return;
        if (!canCraft(recipe).ok) { alert("Не хватает ресурсов."); return; }
        if (!p.resources) p.resources = {};
        Object.keys(recipe.needs).forEach(function(k) {
            p.resources[k] -= recipe.needs[k];
            if (p.resources[k] <= 0) delete p.resources[k];
        });
        const now = Date.now();
        p.activeCraft = {
            recipeId: recipe.id, name: recipe.name, icon: recipe.icon,
            startedAt: now, endsAt: now + recipe.timeSec * 1000
        };
        saveProf(p);
        freeze();
        renderPlaques();
        try { saveGame(); } catch (e) {}
        addLog(d.crafter.icon + " Ты начинаешь " + d.crafter.actionVerb + " «" + recipe.name + "».", true);
    }

    function completeCraft(fromStartup) {
        const p = getProf();
        const d = getProfData();
        if (!p || !p.activeCraft || !d) return;
        const cq = p.activeCraft;
        p.activeCraft = null;
        const recipe = d.crafter.recipes.find(function(r) { return r.id === cq.recipeId; });
        if (!recipe) { saveProf(p); return; }
        const cL = p.crafterLevel || 0;
        const success = Math.random() < craftChance(recipe, cL);
        const prefix = fromStartup ? "Пока тебя не было, " : "";
        if (success) {
            if (!p.products) p.products = {};
            p.products[recipe.id] = (p.products[recipe.id] || 0) + 1;
            const diff = Math.max(0, (recipe.level || 0) - cL);
            grantCrafterXp(1 + diff * 2);
            saveProf(p);
            addLog(d.crafter.icon + " " + prefix + "«" + recipe.name + "» готов! +" + (1 + diff * 2) + " опыта.", true);
        } else {
            grantCrafterXp(1);
            saveProf(p);
            addLog("🔥 " + prefix + "«" + recipe.name + "» не удался. Материалы сгорели. +1 опыт.", true);
        }
        unfreeze();
        renderPlaques();
        try { saveGame(); } catch (e) {}
    }

    function cancelCraft() {
        const p = getProf();
        if (!p || !p.activeCraft) return;
        if (!confirm("Прервать работу?\n\nМатериалы НЕ вернутся.")) return;
        p.activeCraft = null;
        saveProf(p);
        unfreeze();
        renderPlaques();
        try { saveGame(); } catch (e) {}
    }

    // ==================== ПЛАШКИ ====================
    function renderPlaques() {
        const card = document.getElementById("dao-status-card");
        if (!card) return;

        // Убираем возможные старые плашки от патчей
        ["dao-gather-plaque", "dao-craft-plaque",
         "dao-gather-plaque-v541", "dao-craft-plaque-v541"].forEach(function(id) {
            const e = document.getElementById(id);
            if (e) e.remove();
        });

        const p = getProf();
        const d = getProfData();
        if (!p || !d) {
            const gp = document.getElementById("dao-prof-gather-plaque");
            if (gp) gp.remove();
            const cp = document.getElementById("dao-prof-craft-plaque");
            if (cp) cp.remove();
            return;
        }

        if (p.activeGather) {
            const gq = p.activeGather;
            const total = Math.max(1, gq.endsAt - gq.startedAt);
            const remain = Math.max(0, gq.endsAt - Date.now());
            const prog = Math.min(1, Math.max(0, 1 - remain / total));
            let el = document.getElementById("dao-prof-gather-plaque");
            if (!el) {
                el = document.createElement("div");
                el.id = "dao-prof-gather-plaque";
                el.style.cssText = "position:relative;background:linear-gradient(90deg,rgba(46,160,67,.08),rgba(46,160,67,.01));border:1px solid var(--jade);border-radius:6px;padding:4px 8px 5px;margin-bottom:5px;overflow:hidden;";
                card.insertBefore(el, card.firstChild);
                el.innerHTML =
                    '<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;line-height:1.15;">' +
                        '<span data-role="name" style="color:var(--jade-glow);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.7rem;"></span>' +
                        '<span data-role="timer" style="color:var(--jade-glow);font-weight:700;font-variant-numeric:tabular-nums;font-size:.74rem;"></span>' +
                        '<button data-role="cancel" style="background:none;border:1px solid #484f58;color:var(--text-dim);border-radius:4px;width:18px;height:18px;padding:0;font-size:.7rem;line-height:1;cursor:pointer;">✖</button>' +
                    '</div>' +
                    '<div style="position:absolute;left:0;right:0;bottom:0;height:2px;background:rgba(48,54,61,.5);">' +
                        '<div data-role="bar" style="height:100%;width:0%;background:var(--jade-glow);transition:width .3s linear;"></div>' +
                    '</div>';
                el.querySelector('[data-role="cancel"]').onclick = function(e) {
                    e.preventDefault(); e.stopPropagation();
                    cancelGather();
                };
            }
            const nameEl = el.querySelector('[data-role="name"]');
            const timerEl = el.querySelector('[data-role="timer"]');
            const barEl = el.querySelector('[data-role="bar"]');
            const name = d.gatherer.icon + " " + d.gatherer.actionNoun + ": " + gq.name.toLowerCase();
            const time = "⏱ " + formatRemaining(remain);
            if (nameEl.textContent !== name) nameEl.textContent = name;
            if (timerEl.textContent !== time) timerEl.textContent = time;
            barEl.style.width = (prog * 100).toFixed(1) + "%";
        } else {
            const el = document.getElementById("dao-prof-gather-plaque");
            if (el) el.remove();
        }

        if (p.activeCraft) {
            const cq = p.activeCraft;
            const total = Math.max(1, cq.endsAt - cq.startedAt);
            const remain = Math.max(0, cq.endsAt - Date.now());
            const prog = Math.min(1, Math.max(0, 1 - remain / total));
            let el = document.getElementById("dao-prof-craft-plaque");
            if (!el) {
                el = document.createElement("div");
                el.id = "dao-prof-craft-plaque";
                el.style.cssText = "position:relative;background:linear-gradient(90deg,rgba(210,153,34,.08),rgba(210,153,34,.01));border:1px solid var(--gold);border-radius:6px;padding:4px 8px 5px;margin-bottom:5px;overflow:hidden;";
                card.insertBefore(el, card.firstChild);
                el.innerHTML =
                    '<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;line-height:1.15;">' +
                        '<span data-role="name" style="color:var(--gold);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.7rem;"></span>' +
                        '<span data-role="timer" style="color:var(--gold);font-weight:700;font-variant-numeric:tabular-nums;font-size:.74rem;"></span>' +
                        '<button data-role="cancel" style="background:none;border:1px solid #484f58;color:var(--text-dim);border-radius:4px;width:18px;height:18px;padding:0;font-size:.7rem;line-height:1;cursor:pointer;">✖</button>' +
                    '</div>' +
                    '<div style="position:absolute;left:0;right:0;bottom:0;height:2px;background:rgba(48,54,61,.5);">' +
                        '<div data-role="bar" style="height:100%;width:0%;background:var(--gold);transition:width .3s linear;"></div>' +
                    '</div>';
                el.querySelector('[data-role="cancel"]').onclick = function(e) {
                    e.preventDefault(); e.stopPropagation();
                    cancelCraft();
                };
            }
            const nameEl = el.querySelector('[data-role="name"]');
            const timerEl = el.querySelector('[data-role="timer"]');
            const barEl = el.querySelector('[data-role="bar"]');
            const name = d.crafter.icon + " " + d.crafter.actionNoun + ": " + cq.name;
            const time = "⏱ " + formatRemaining(remain);
            if (nameEl.textContent !== name) nameEl.textContent = name;
            if (timerEl.textContent !== time) timerEl.textContent = time;
            barEl.style.width = (prog * 100).toFixed(1) + "%";
        } else {
            const el = document.getElementById("dao-prof-craft-plaque");
            if (el) el.remove();
        }
    }

    // ==================== ВКЛАДКА ДОБЫЧИ ====================
    function renderGathererTab() {
        const content = document.getElementById("prof-modal-content");
        if (!content) return;
        const p = getProf();
        const d = getProfData();
        if (!p || !d) { content.innerHTML = '<div class="section-stub">Профессия не выбрана.</div>'; return; }

        const g = d.gatherer;
        const res = p.resources || {};
        const maxL = maxLevel();
        const lvl = p.gathererLevel || 0;
        const xp = p.gathererXp || 0;
        const need = xpForGatherer(lvl);
        const pct = Math.min(100, Math.round((xp / need) * 100));

        const inQ = typeof hasQuest === "function" && hasQuest();
        const inT = typeof hasTravel === "function" && hasTravel();
        const inG = !!p.activeGather;
        const inC = !!p.activeCraft;
        const can = !inQ && !inT && !inG && !inC;

        let status = "";
        if (inG) status = '<div style="text-align:center;color:var(--jade-glow);font-size:.82rem;margin-bottom:10px;">' + g.icon + ' Ты в походе…</div>';
        else if (inC) status = '<div style="text-align:center;color:var(--gold);font-size:.82rem;margin-bottom:10px;">Мастерская занята.</div>';
        else if (inQ) status = '<div style="text-align:center;color:var(--gold);font-size:.82rem;margin-bottom:10px;">📜 Сначала закончи задание.</div>';
        else if (inT) status = '<div style="text-align:center;color:var(--gold);font-size:.82rem;margin-bottom:10px;">🗺️ Ты в путешествии.</div>';

        let btns = "";
        g.lengths.forEach(function(l) {
            const desc = "≈ " + l.min + "–" + l.max + " шт · +" + l.xp + " опыта";
            btns +=
                '<button class="dao-g" data-l="' + l.id + '"' + (!can ? " disabled" : "") +
                ' style="background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:12px 14px;color:var(--text-main);font-family:inherit;cursor:pointer;display:flex;align-items:center;gap:12px;text-align:left;width:100%;margin-bottom:8px;' +
                (!can ? 'opacity:.4;cursor:not-allowed;' : '') + '">' +
                '<div style="font-size:1.6rem;line-height:1;">' + l.icon + '</div>' +
                '<div style="flex:1;min-width:0;">' +
                    '<div style="font-size:.92rem;font-weight:700;color:var(--jade-glow);">' + l.name + ' ' + g.actionNoun + '</div>' +
                    '<div style="font-size:.74rem;color:var(--text-dim);margin-top:2px;">' + formatDuration(l.timeSec) + ' · ' + desc + '</div>' +
                '</div></button>';
        });

        let cells = "";
        g.resources.forEach(function(r) {
            cells +=
                '<div style="background:#0d1117;border:1px solid #30363d;border-radius:8px;padding:8px 10px;display:flex;align-items:center;gap:8px;">' +
                    '<div style="font-size:1.3rem;line-height:1;">' + r.icon + '</div>' +
                    '<div style="flex:1;font-size:.78rem;">' + r.name + '</div>' +
                    '<div style="font-size:.9rem;font-weight:700;color:var(--jade-glow);font-variant-numeric:tabular-nums;">' + (res[r.id] || 0) + '</div>' +
                '</div>';
        });

        content.innerHTML =
            '<div style="display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:4px;">' +
                '<span style="color:var(--gold);font-weight:700;">' + g.icon + ' ' + g.name + '</span>' +
                '<span style="color:var(--text-main);font-variant-numeric:tabular-nums;">Уровень ' + lvl + ' / ' + maxL + '</span>' +
            '</div>' +
            '<div style="height:6px;background:#21262d;border-radius:3px;overflow:hidden;margin-bottom:12px;">' +
                '<div style="height:100%;background:linear-gradient(90deg,var(--jade),var(--jade-glow));width:' + pct + '%;transition:width .4s ease;"></div>' +
            '</div>' +
            status +
            '<div style="margin-bottom:14px;">' + btns + '</div>' +
            '<div style="font-size:.68rem;color:var(--text-dim);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:8px;padding-top:10px;border-top:1px dashed #30363d;">' + g.resourceLabel + '</div>' +
            '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">' + cells + '</div>';

        content.querySelectorAll(".dao-g").forEach(function(b) {
            if (b.disabled) return;
            b.onclick = function(e) {
                e.preventDefault(); e.stopPropagation();
                const l = g.lengths.find(function(x) { return x.id === b.dataset.l; });
                if (!l) return;
                if (!confirm("Отправиться в " + l.name.toLowerCase() + " " + g.actionVerb + "?\n\nВремя: " + formatDuration(l.timeSec) + "\nКультивация остановится.")) return;
                startGather(b.dataset.l);
                renderGathererTab();
            };
        });
    }

    // ==================== ВКЛАДКА МАСТЕРСКОЙ ====================
    function renderCrafterTab() {
        const content = document.getElementById("prof-modal-content");
        if (!content) return;
        const p = getProf();
        const d = getProfData();
        if (!p || !d) { content.innerHTML = '<div class="section-stub">Профессия не выбрана.</div>'; return; }

        const c = d.crafter;
        const g = d.gatherer;
        const res = p.resources || {};
        const prods = p.products || {};
        const gL = p.gathererLevel || 0;
        const cL = p.crafterLevel || 0;
        const cXp = p.crafterXp || 0;
        const maxL = maxLevel();
        const cap = Math.min(maxL, gL);
        const pct = Math.min(100, Math.round((cXp / xpForCrafter(cL)) * 100));

        if (gL < 5) {
            content.innerHTML =
                '<div class="section-stub">' +
                    '<span class="stub-icon">🔒</span>' +
                    '<b>' + c.name + ' закрыт</b><br><br>' +
                    'Доведи <b style="color:var(--jade-glow);">' + g.name + '</b> до 5-го уровня.<br>' +
                    'Сейчас: ' + gL + ' / 5.' +
                '</div>';
            return;
        }

        const inQ = typeof hasQuest === "function" && hasQuest();
        const inT = typeof hasTravel === "function" && hasTravel();
        const inG = !!p.activeGather;
        const inC = !!p.activeCraft;
        const busy = inQ || inT || inG || inC;

        let status = "";
        if (inC) status = '<div style="text-align:center;font-size:.78rem;color:var(--gold);margin-bottom:10px;">' + c.icon + ' Идёт работа…</div>';
        else if (inG) status = '<div style="text-align:center;font-size:.78rem;color:var(--gold);margin-bottom:10px;">' + g.icon + ' Ты в походе.</div>';
        else if (inQ) status = '<div style="text-align:center;font-size:.78rem;color:var(--gold);margin-bottom:10px;">📜 Ты на задании.</div>';
        else if (inT) status = '<div style="text-align:center;font-size:.78rem;color:var(--gold);margin-bottom:10px;">🗺️ Ты в путешествии.</div>';

        let recipes = "";
        c.recipes.forEach(function(r) {
            const lv = r.level || 0;
            const realmRestr = lv > maxL;
            const capRestr = cL > cap;
            const chance = craftChance(r, cL);
            const chancePct = Math.round(chance * 100);

            let miss = false;
            Object.keys(r.needs).forEach(function(k) { if ((res[k] || 0) < r.needs[k]) miss = true; });

            let cc = "var(--jade-glow)";
            if (chancePct < 60) cc = "var(--crimson)";
            else if (chancePct < 90) cc = "var(--gold)";

            let needsHtml = "";
            Object.keys(r.needs).forEach(function(k) {
                const res2 = g.resources.find(function(x) { return x.id === k; });
                const have = res[k] || 0;
                const m = have < r.needs[k];
                needsHtml +=
                    '<span style="display:inline-flex;align-items:center;gap:3px;color:' + (m ? 'var(--crimson)' : 'var(--text-dim)') + ';padding:2px 6px;border-radius:4px;background:rgba(13,17,23,.6);font-size:.72rem;">' +
                        (res2 ? res2.icon : "❔") + ' ' + (res2 ? res2.name : k) +
                        ' <b style="color:' + (m ? 'var(--crimson)' : 'var(--text-main)') + ';">' + have + '/' + r.needs[k] + '</b>' +
                    '</span>';
            });

            let dis = false;
            let txt = c.actionVerb.charAt(0).toUpperCase() + c.actionVerb.slice(1);
            const locked = realmRestr || capRestr;
            if (locked) { dis = true; txt = realmRestr ? "🔒 Нужно царство" : "🔒 " + g.name + " выше"; }
            else if (miss) { dis = true; txt = "Не хватает"; }
            else if (busy) { dis = true; txt = "Занят"; }

            recipes +=
                '<div style="background:#0d1117;border:1px solid ' +
                (locked ? '#30363d' : (miss || busy ? '#30363d' : 'rgba(46,160,67,.4)')) +
                ';border-radius:10px;padding:12px 14px;margin-bottom:10px;' + (locked ? 'opacity:.55;' : '') + '">' +
                '<div style="display:flex;align-items:flex-start;gap:10px;">' +
                    '<div style="font-size:1.5rem;line-height:1;">' + r.icon + '</div>' +
                    '<div style="flex:1;min-width:0;">' +
                        '<div style="font-size:.95rem;font-weight:700;color:var(--gold);line-height:1.25;margin-bottom:3px;">' + r.name + '</div>' +
                        '<div style="font-size:.74rem;color:var(--text-dim);line-height:1.35;">' + r.desc + '</div>' +
                    '</div>' +
                    '<div style="font-size:.62rem;color:' + cc + ';border:1px solid ' + cc + ';border-radius:4px;padding:2px 6px;font-weight:700;">Ур. ' + lv + '</div>' +
                '</div>' +
                '<div style="display:flex;flex-wrap:wrap;gap:6px;padding-top:6px;border-top:1px dashed #30363d;margin-top:8px;">' + needsHtml + '</div>' +
                '<div style="display:flex;justify-content:space-between;font-size:.75rem;color:var(--text-dim);margin-top:8px;">' +
                    '<span style="color:var(--text-main);">⏱ ' + formatDuration(r.timeSec) + '</span>' +
                    (!locked ? '<span style="color:' + cc + ';font-weight:700;">Шанс: ' + chancePct + '%</span>' : '') +
                '</div>' +
                '<button class="dao-c" data-r="' + r.id + '"' + (dis ? " disabled" : "") +
                ' style="min-height:38px;padding:8px 12px;font-size:.82rem;background:#21262d;border:1px solid ' +
                (dis && !locked ? 'var(--crimson)' : 'var(--jade)') +
                ';color:' + (dis && !locked ? 'var(--crimson)' : 'var(--jade-glow)') +
                ';border-radius:6px;font-weight:600;font-family:inherit;width:100%;margin-top:6px;' +
                (dis ? 'opacity:.75;cursor:not-allowed;' : 'cursor:pointer;') + '">' + txt + '</button>' +
                '</div>';
        });

        const pk = Object.keys(prods).filter(function(k) { return prods[k] > 0; });
        let prodHtml = pk.length === 0
            ? '<div style="font-size:.76rem;color:#484f58;font-style:italic;text-align:center;padding:10px 0;">Пока пусто.</div>'
            : "";
        pk.forEach(function(k) {
            const r = c.recipes.find(function(x) { return x.id === k; });
            if (!r) return;
            prodHtml +=
                '<div style="display:flex;justify-content:space-between;background:#0d1117;border:1px solid #30363d;border-radius:8px;padding:8px 12px;font-size:.82rem;margin-bottom:6px;">' +
                    '<span style="color:var(--text-main);">' + r.icon + ' ' + r.name + '</span>' +
                    '<span style="color:var(--jade-glow);font-weight:700;">×' + prods[k] + '</span>' +
                '</div>';
        });

        content.innerHTML =
            '<div style="display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:4px;">' +
                '<span style="color:var(--gold);font-weight:700;">' + c.icon + ' ' + c.name + '</span>' +
                '<span style="color:var(--text-main);font-variant-numeric:tabular-nums;">Уровень ' + cL + ' / ' + cap + '</span>' +
            '</div>' +
            '<div style="height:6px;background:#21262d;border-radius:3px;overflow:hidden;margin-bottom:12px;">' +
                '<div style="height:100%;background:linear-gradient(90deg,var(--jade),var(--jade-glow));width:' + pct + '%;transition:width .4s ease;"></div>' +
            '</div>' +
            status +
            '<div style="font-size:.68rem;color:var(--text-dim);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:10px;padding-top:10px;border-top:1px dashed #30363d;">Рецепты</div>' +
            recipes +
            '<div style="font-size:.68rem;color:var(--text-dim);letter-spacing:1.5px;text-transform:uppercase;margin:16px 0 8px 0;padding-top:10px;border-top:1px dashed #30363d;">' + c.productLabel + '</div>' +
            prodHtml;

        content.querySelectorAll(".dao-c").forEach(function(b) {
            if (b.disabled) return;
            b.onclick = function(e) {
                e.preventDefault(); e.stopPropagation();
                const r = c.recipes.find(function(x) { return x.id === b.dataset.r; });
                if (!r) return;
                const chancePct = Math.round(craftChance(r, cL) * 100);
                if (!confirm("Начать " + c.actionVerb + " «" + r.name + "»?\n\nШанс: " + chancePct + "%\n⏱ " + formatDuration(r.timeSec) + "\n\n⚠ При провале материалы сгорают.")) return;
                startCraft(b.dataset.r);
                renderCrafterTab();
            };
        });
    }

    // ==================== ОКНО ПРОФЕССИИ ====================
    function openProfessionModal() {
        const ch = getCharacter();
        if (!ch || !ch.profession) { showProfessionSelection(); return; }

        const old = document.getElementById("profession-modal");
        if (old) old.remove();

        const overlay = document.createElement("div");
        overlay.id = "profession-modal";
        overlay.className = "modal-overlay";
        overlay.innerHTML =
            '<div class="modal" style="max-width:640px;padding:0;overflow:hidden;display:flex;flex-direction:column;max-height:92vh;">' +
                '<div style="padding:14px 18px 12px;border-bottom:1px solid #30363d;flex:0 0 auto;">' +
                    '<h2 style="margin:0 0 4px 0;color:var(--gold);font-size:1.1rem;">Профессия</h2>' +
                    '<div id="prof-modal-sub" style="font-size:.78rem;color:var(--text-dim);line-height:1.4;"></div>' +
                '</div>' +
                '<div style="display:flex;border-bottom:1px solid #30363d;background:#0d1117;flex:0 0 auto;">' +
                    '<button class="prof-tab active" data-ptab="gatherer" style="flex:1;padding:12px 8px;background:transparent;border:none;border-bottom:2px solid var(--gold);color:var(--gold);font-size:.78rem;font-weight:600;font-family:inherit;cursor:pointer;">ДОБЫЧА</button>' +
                    '<button class="prof-tab" data-ptab="crafter" style="flex:1;padding:12px 8px;background:transparent;border:none;border-bottom:2px solid transparent;color:var(--text-dim);font-size:.78rem;font-weight:600;font-family:inherit;cursor:pointer;">МАСТЕРСКАЯ</button>' +
                '</div>' +
                '<div id="prof-modal-content" style="padding:16px 18px 18px;overflow-y:auto;flex:1 1 auto;min-height:200px;"></div>' +
                '<div style="padding:12px 18px;border-top:1px solid #30363d;flex:0 0 auto;">' +
                    '<button id="close-prof-btn" style="width:100%;min-height:44px;">Закрыть</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(overlay);

        overlay.querySelector("#close-prof-btn").onclick = function() { overlay.remove(); };
        overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };

        overlay.querySelectorAll(".prof-tab").forEach(function(tab) {
            tab.onclick = function() {
                overlay.querySelectorAll(".prof-tab").forEach(function(t) {
                    t.classList.remove("active");
                    t.style.borderBottomColor = "transparent";
                    t.style.color = "var(--text-dim)";
                });
                tab.classList.add("active");
                tab.style.borderBottomColor = "var(--gold)";
                tab.style.color = "var(--gold)";
                if (tab.dataset.ptab === "gatherer") renderGathererTab();
                else renderCrafterTab();
            };
        });

        const p = getProf();
        const d = getProfData();
        if (p && d) {
            const tabs = overlay.querySelectorAll(".prof-tab");
            if (tabs[0]) tabs[0].textContent = d.gatherer.icon + " " + d.gatherer.name.toUpperCase();
            if (tabs[1]) tabs[1].textContent = d.crafter.icon + " " + d.crafter.name.toUpperCase();
            const subEl = document.getElementById("prof-modal-sub");
            if (subEl) subEl.textContent =
                d.gatherer.icon + " " + d.gatherer.name + " " + (p.gathererLevel || 0) +
                " · " +
                d.crafter.icon + " " + d.crafter.name + " " + (p.crafterLevel || 0);
        }

        renderGathererTab();
        overlay.classList.add("show");
    }

    // ==================== ЭКРАН ВЫБОРА ПРОФЕССИИ ====================
    function showProfessionSelection() {
        const ch = getCharacter();
        if (ch && ch.profession) return;
        if (document.getElementById("dao-profession-onboarding")) return;
        if (document.getElementById("dao-onboarding")) return;

        const list = Object.keys(PROFESSIONS_DATA).map(function(k) { return PROFESSIONS_DATA[k]; });
        let selectedIndex = 0;

        const overlay = document.createElement("div");
        overlay.id = "dao-profession-onboarding";
        overlay.className = "profession-overlay";
        overlay.innerHTML =
            '<div class="profession-box">' +
                '<h2 class="prof-title">РЕМЕСЛО</h2>' +
                '<div class="prof-sub">Чем ты будешь зарабатывать на жизнь?</div>' +
                '<div id="dao-prof-list" style="display:flex;flex-direction:column;gap:14px;margin-bottom:20px;"></div>' +
                '<div style="display:flex;flex-direction:column;gap:10px;">' +
                    '<button class="primary" id="prof-accept-btn" style="min-height:52px;font-size:1rem;">Начать путь ремесленника</button>' +
                '</div>' +
                '<div class="prof-hint">Выбор ремесла — на всю жизнь. Смена только через нового персонажа.</div>' +
            '</div>';
        document.body.appendChild(overlay);

        const cont = document.getElementById("dao-prof-list");
        list.forEach(function(p, i) {
            const card = document.createElement("div");
            card.className = "dao-prof-card";
            card.style.cssText = "background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:14px 16px;cursor:pointer;transition:border-color .2s ease;";
            card.innerHTML =
                '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px;">' +
                    '<div style="display:flex;flex-direction:column;align-items:center;gap:4px;flex:1;">' +
                        '<span style="font-size:2rem;line-height:1;">' + p.gatherer.icon + '</span>' +
                        '<span style="font-size:.82rem;font-weight:700;color:var(--gold);">' + p.gatherer.name + '</span>' +
                        '<span style="font-size:.62rem;color:var(--text-dim);letter-spacing:1px;text-transform:uppercase;">добытчик</span>' +
                    '</div>' +
                    '<span style="font-size:1.4rem;color:var(--text-dim);">→</span>' +
                    '<div style="display:flex;flex-direction:column;align-items:center;gap:4px;flex:1;">' +
                        '<span style="font-size:2rem;line-height:1;">' + p.crafter.icon + '</span>' +
                        '<span style="font-size:.82rem;font-weight:700;color:var(--gold);">' + p.crafter.name + '</span>' +
                        '<span style="font-size:.62rem;color:var(--text-dim);letter-spacing:1px;text-transform:uppercase;">мастер</span>' +
                    '</div>' +
                '</div>' +
                '<div style="font-size:.78rem;color:var(--text-dim);line-height:1.4;text-align:center;padding-top:8px;border-top:1px dashed #30363d;">' + p.gatherer.desc + ' ' + p.crafter.desc + '</div>';
            card.onclick = function() { selectedIndex = i; paint(); };
            cont.appendChild(card);
        });

        function paint() {
            cont.querySelectorAll(".dao-prof-card").forEach(function(c, i) {
                c.style.borderColor = i === selectedIndex ? "var(--gold)" : "#30363d";
                c.style.background = i === selectedIndex ? "rgba(210,153,34,.06)" : "#0d1117";
            });
        }
        paint();

        document.getElementById("prof-accept-btn").onclick = function() {
            const p = list[selectedIndex];
            const ch2 = getCharacter();
            if (!ch2) return;
            ch2.profession = {
                id: p.id,
                gathererId: p.gatherer.id, crafterId: p.crafter.id,
                gathererLevel: 0, gathererXp: 0,
                crafterLevel: 0, crafterXp: 0,
                resources: {}, products: {},
                gatheredAt: Date.now()
            };
            saveCharacterObj(ch2);
            overlay.remove();
            addLog(p.gatherer.icon + " Ты избрал путь: " + p.gatherer.name + " → " + p.crafter.name + ".", true);
        };
    }

    // ==================== РАБОЧИЙ СТОЛ ====================
    function injectWorkshopButton() {
        const h = document.querySelector(".header");
        if (!h) return;
        if (document.getElementById("workshop-btn")) return;
        const btn = document.createElement("button");
        btn.id = "workshop-btn";
        btn.className = "top-btn";
        btn.title = "Рабочий стол";
        btn.textContent = "⚒️";
        btn.style.right = "0";
        btn.style.zIndex = "10";
        btn.onclick = function(e) {
            e.preventDefault();
            e.stopPropagation();
            openWorkshopHub();
        };
        h.appendChild(btn);
    }

    function openWorkshopHub() {
        const old = document.getElementById("workshop-hub");
        if (old) old.remove();

        const overlay = document.createElement("div");
        overlay.id = "workshop-hub";
        overlay.className = "modal-overlay";
        overlay.innerHTML =
            '<div class="modal" style="max-width:420px;">' +
                '<h2 style="text-align:center;margin-bottom:6px;">Рабочий стол</h2>' +
                '<div style="text-align:center;color:var(--gold);font-size:.8rem;letter-spacing:2px;text-transform:uppercase;margin-bottom:14px;">Куда идём?</div>' +
                '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;">' +
                    '<button class="dao-hub-tile" data-hub="tech"><span style="font-size:1.8rem;line-height:1;">📖</span><span style="font-size:.78rem;font-weight:600;">Техники</span></button>' +
                    '<button class="dao-hub-tile" data-hub="quests"><span style="font-size:1.8rem;line-height:1;">📜</span><span style="font-size:.78rem;font-weight:600;">Задания</span></button>' +
                    '<button class="dao-hub-tile" data-hub="prof"><span style="font-size:1.8rem;line-height:1;">🌿</span><span style="font-size:.78rem;font-weight:600;color:var(--jade-glow);">Профессия</span></button>' +
                    '<button class="dao-hub-tile" data-hub="shop" style="grid-column:1 / -1;"><span style="font-size:1.8rem;line-height:1;">🏪</span><span style="font-size:.78rem;font-weight:600;">Магазин</span></button>' +
                '</div>' +
                '<div class="modal-actions" style="margin-top:14px;">' +
                    '<button id="dao-close-hub">Закрыть</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(overlay);

        if (!document.getElementById("dao-hub-style")) {
            const s = document.createElement("style");
            s.id = "dao-hub-style";
            s.textContent = '.dao-hub-tile{background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:16px 8px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;cursor:pointer;font-family:inherit;color:var(--text-main);min-height:90px;transition:transform .05s ease,border-color .2s ease;}.dao-hub-tile:hover{border-color:var(--jade);}.dao-hub-tile:active{transform:scale(.96);background:#161b22;}';
            document.head.appendChild(s);
        }

        overlay.querySelector("#dao-close-hub").onclick = function() { overlay.remove(); };
        overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };
        overlay.querySelectorAll(".dao-hub-tile").forEach(function(tile) {
            tile.onclick = function(e) {
                e.preventDefault(); e.stopPropagation();
                const kind = tile.dataset.hub;
                overlay.remove();
                requestAnimationFrame(function() {
                    requestAnimationFrame(function() {
                        if (kind === "tech" && typeof openTechniquesModal === "function") openTechniquesModal();
                        else if (kind === "quests" && typeof openQuestsModal === "function") openQuestsModal();
                        else if (kind === "prof") openProfessionModal();
                        else if (kind === "shop") openShop();
                    });
                });
            };
        });
        overlay.classList.add("show");
    }

    // ==================== МАГАЗИН ====================
    function openShop() {
        const old = document.getElementById("shop-modal");
        if (old) old.remove();

        const p = getProf();
        const d = getProfData();
        if (!p || !d) { addLog("Сначала выбери профессию.", true); return; }

        const res = p.resources || {};
        const prods = p.products || {};
        const g = d.gatherer, c = d.crafter;

        let productsHtml = "";
        const pk = Object.keys(prods).filter(function(k) { return prods[k] > 0; });
        if (pk.length === 0) {
            productsHtml = '<div style="text-align:center;color:var(--text-dim);font-size:.82rem;padding:16px;">Пока пусто.</div>';
        } else {
            pk.forEach(function(k) {
                const r = c.recipes.find(function(x) { return x.id === k; });
                if (!r) return;
                productsHtml +=
                    '<div style="background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:10px 12px;margin-bottom:8px;display:flex;align-items:center;gap:10px;">' +
                        '<span style="font-size:1.4rem;line-height:1;">' + r.icon + '</span>' +
                        '<div style="flex:1;min-width:0;">' +
                            '<div style="font-size:.85rem;color:var(--text-main);font-weight:600;">' + r.name + '</div>' +
                            '<div style="font-size:.7rem;color:var(--text-dim);">В наличии: ' + prods[k] + '</div>' +
                        '</div>' +
                        '<div style="font-size:.8rem;color:var(--yellow);font-weight:700;text-align:right;">💰 ' + (c.prices[k] || 10) + '</div>' +
                        '<button class="dao-sp" data-id="' + k + '" data-c="' + prods[k] + '" style="min-height:32px;padding:4px 10px;font-size:.72rem;background:#21262d;border:1px solid var(--jade);color:var(--jade-glow);border-radius:6px;font-weight:600;font-family:inherit;cursor:pointer;">Продать ' + prods[k] + '</button>' +
                    '</div>';
            });
        }

        let resourcesHtml = "";
        const rk = Object.keys(res).filter(function(k) { return res[k] > 0; });
        if (rk.length === 0) {
            resourcesHtml = '<div style="text-align:center;color:var(--text-dim);font-size:.82rem;padding:16px;">Пусто.</div>';
        } else {
            rk.forEach(function(k) {
                const r = g.resources.find(function(x) { return x.id === k; });
                if (!r) return;
                resourcesHtml +=
                    '<div style="background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:10px 12px;margin-bottom:8px;display:flex;align-items:center;gap:10px;">' +
                        '<span style="font-size:1.4rem;line-height:1;">' + r.icon + '</span>' +
                        '<div style="flex:1;min-width:0;">' +
                            '<div style="font-size:.85rem;color:var(--text-main);font-weight:600;">' + r.name + '</div>' +
                            '<div style="font-size:.7rem;color:var(--text-dim);">В наличии: ' + res[k] + '</div>' +
                        '</div>' +
                        '<div style="font-size:.8rem;color:var(--yellow);font-weight:700;text-align:right;">💰 ' + (g.prices[k] || 3) + '</div>' +
                        '<button class="dao-sr" data-id="' + k + '" data-c="' + res[k] + '" style="min-height:32px;padding:4px 10px;font-size:.72rem;background:#21262d;border:1px solid var(--jade);color:var(--jade-glow);border-radius:6px;font-weight:600;font-family:inherit;cursor:pointer;">Продать ' + res[k] + '</button>' +
                    '</div>';
            });
        }

        let total = 0;
        pk.forEach(function(k) { total += (c.prices[k] || 10) * prods[k]; });
        rk.forEach(function(k) { total += (g.prices[k] || 3) * res[k]; });

        const overlay = document.createElement("div");
        overlay.id = "shop-modal";
        overlay.className = "modal-overlay";
        overlay.innerHTML =
            '<div class="modal" style="max-width:560px;max-height:92vh;display:flex;flex-direction:column;padding:0;overflow:hidden;">' +
                '<div style="padding:14px 18px 12px;border-bottom:1px solid #30363d;flex:0 0 auto;">' +
                    '<h2 style="margin:0 0 4px 0;color:var(--gold);font-size:1.1rem;">🏪 Магазин</h2>' +
                    '<div style="font-size:.78rem;color:var(--text-dim);">Продай изделия и сырьё за золото.</div>' +
                '</div>' +
                '<div style="padding:14px 18px 16px;overflow-y:auto;flex:1 1 auto;">' +
                    '<div style="background:linear-gradient(135deg,rgba(240,196,84,.08),rgba(240,196,84,.02));border:1px solid rgba(240,196,84,.3);border-radius:10px;padding:12px 14px;margin-bottom:14px;display:flex;justify-content:space-between;">' +
                        '<span style="font-size:.78rem;color:var(--text-dim);">Можно выручить</span>' +
                        '<span style="font-size:1rem;font-weight:700;color:var(--yellow);font-variant-numeric:tabular-nums;">💰 ' + total.toLocaleString("ru-RU") + '</span>' +
                    '</div>' +
                    '<div style="font-size:.68rem;color:var(--text-dim);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:8px;padding-bottom:6px;border-bottom:1px dashed #30363d;">' + c.icon + ' ' + c.productLabel + '</div>' +
                    productsHtml +
                    '<div style="font-size:.68rem;color:var(--text-dim);letter-spacing:1.5px;text-transform:uppercase;margin:16px 0 8px 0;padding-bottom:6px;border-bottom:1px dashed #30363d;">' + g.icon + ' ' + g.resourceLabel + '</div>' +
                    resourcesHtml +
                '</div>' +
                '<div style="padding:12px 18px;border-top:1px solid #30363d;flex:0 0 auto;">' +
                    '<button id="dao-sa" style="width:100%;min-height:44px;background:#21262d;border:1px solid var(--yellow);color:var(--yellow);border-radius:10px;font-weight:600;font-size:.9rem;font-family:inherit;cursor:pointer;' + (total > 0 ? '' : 'opacity:.35;cursor:not-allowed;') + '"' + (total > 0 ? '' : ' disabled') + '>💰 Продать всё за ' + total.toLocaleString("ru-RU") + '</button>' +
                    '<button id="dao-cs" style="width:100%;min-height:40px;margin-top:8px;">Закрыть</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(overlay);

        overlay.querySelector("#dao-cs").onclick = function() { overlay.remove(); };
        overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };

        overlay.querySelectorAll(".dao-sp").forEach(function(b) {
            b.onclick = function() {
                const p2 = getProf();
                const k = b.dataset.id;
                const cnt = parseInt(b.dataset.c, 10);
                const earned = (c.prices[k] || 10) * cnt;
                p2.products[k] = 0;
                saveProf(p2);
                addGold(earned);
                const rec = c.recipes.find(function(r) { return r.id === k; });
                addLog("💰 Продано: " + (rec ? rec.name : k) + " ×" + cnt + " за " + earned + " " + goldWord(earned) + ".", true);
                openShop();
            };
        });

        overlay.querySelectorAll(".dao-sr").forEach(function(b) {
            b.onclick = function() {
                const p2 = getProf();
                const k = b.dataset.id;
                const cnt = parseInt(b.dataset.c, 10);
                const earned = (g.prices[k] || 3) * cnt;
                p2.resources[k] = 0;
                saveProf(p2);
                addGold(earned);
                const r = g.resources.find(function(x) { return x.id === k; });
                addLog("💰 Продано: " + (r ? r.name : k) + " ×" + cnt + " за " + earned + " " + goldWord(earned) + ".", true);
                openShop();
            };
        });

        const sa = overlay.querySelector("#dao-sa");
        if (sa && !sa.disabled) {
            sa.onclick = function() {
                const p2 = getProf();
                let te = 0;
                Object.keys(p2.products || {}).forEach(function(k) { te += (c.prices[k] || 10) * (p2.products[k] || 0); p2.products[k] = 0; });
                Object.keys(p2.resources || {}).forEach(function(k) { te += (g.prices[k] || 3) * (p2.resources[k] || 0); p2.resources[k] = 0; });
                saveProf(p2);
                if (te > 0) addGold(te);
                addLog("💰 Всё продано за " + te + " " + goldWord(te) + ".", true);
                openShop();
            };
        }

        overlay.classList.add("show");
        if (typeof updateUI === "function") updateUI();
    }

    // ==================== ТЕСТОВЫЕ КНОПКИ В ОТЛАДКЕ ====================
    function finishGatherNow() {
        const p = getProf();
        if (!p) { alert("Нет профессии."); return; }
        if (!p.activeGather) { alert("Нет активного похода."); return; }
        p.activeGather.endsAt = Date.now() - 1;
        saveProf(p);
        addLog("🧪 [ТЕСТ] Поход завершён мгновенно.", true);
    }
    function finishCraftNow() {
        const p = getProf();
        if (!p) { alert("Нет профессии."); return; }
        if (!p.activeCraft) { alert("Нет активной работы."); return; }
        p.activeCraft.endsAt = Date.now() - 1;
        saveProf(p);
        addLog("🧪 [ТЕСТ] Работа завершена мгновенно.", true);
    }
    function grantAllResources() {
        const p = getProf();
        const d = getProfData();
        if (!p || !d) return;
        if (!p.resources) p.resources = {};
        d.gatherer.resources.forEach(function(r) {
            p.resources[r.id] = (p.resources[r.id] || 0) + 10;
        });
        saveProf(p);
        addLog("🧪 [ТЕСТ] +10 " + d.gatherer.resourceLabel.toLowerCase() + " каждого вида.", true);
    }

    function injectDebugButtons() {
        const settings = document.getElementById("settings-modal");
        if (!settings || !settings.classList.contains("show")) return;
        const modal = settings.querySelector(".modal");
        if (!modal) return;
        let debugBlock = null;
        modal.querySelectorAll("div").forEach(function(d) {
            if (d.children.length === 0 && d.textContent.trim() === "Отладка") debugBlock = d;
        });
        if (!debugBlock) return;
        let actions = debugBlock.nextElementSibling;
        while (actions && !actions.classList.contains("modal-actions")) actions = actions.nextElementSibling;
        if (!actions) return;

        [["dao-v58-fastgather", "🧪 Завершить поход сразу", finishGatherNow],
         ["dao-v58-fastcraft",  "🧪 Завершить работу сразу", finishCraftNow],
         ["dao-v58-allres",     "🧪 +10 всех ресурсов",      grantAllResources]].forEach(function(item) {
            if (!actions.querySelector("." + item[0])) {
                const b = document.createElement("button");
                b.className = item[0];
                b.textContent = item[1];
                b.onclick = item[2];
                actions.insertBefore(b, actions.firstChild);
            }
        });
    }

    // ==================== ТИК ЗАВЕРШЕНИЯ ====================
    // Общий тик: раз в 500 мс проверяем активность похода/крафта
    // и обновляем плашки. Также раз в 2 сек синхронизируем открытые
    // вкладки окна профессии (уровни / шкалы).
    let _tickCounter = 0;
    setInterval(function() {
        const p = getProf();
        if (!p) {
            // На случай, если у игрока нет профессии — прячем плашки
            const gp = document.getElementById("dao-prof-gather-plaque");
            if (gp) gp.remove();
            const cp = document.getElementById("dao-prof-craft-plaque");
            if (cp) cp.remove();
            return;
        }
        if (p.activeGather && Date.now() >= p.activeGather.endsAt) { completeGather(false); return; }
        if (p.activeCraft && Date.now() >= p.activeCraft.endsAt) { completeCraft(false); return; }
        if (p.activeGather || p.activeCraft) renderPlaques();

        // Раз в ~2 сек (каждые 4 тика) обновляем открытую вкладку
        _tickCounter++;
        if (_tickCounter % 4 === 0) {
            const m = document.getElementById("profession-modal");
            if (m && m.classList.contains("show")) {
                const a = m.querySelector(".prof-tab.active");
                if (a && a.dataset.ptab === "gatherer") renderGathererTab();
                else if (a && a.dataset.ptab === "crafter") renderCrafterTab();
            }
            // Тестовые кнопки в настройках
            if (document.getElementById("settings-modal")) injectDebugButtons();
        }
    }, 500);

    // ==================== ВОССТАНОВЛЕНИЕ ПОСЛЕ ЗАПУСКА ====================
    setTimeout(function() {
        const p = getProf();
        if (!p) return;
        if (p.activeGather) {
            if (Date.now() >= p.activeGather.endsAt) completeGather(true);
            else { freeze(); renderPlaques(); }
        }
        if (p.activeCraft) {
            if (Date.now() >= p.activeCraft.endsAt) completeCraft(true);
            else { freeze(); renderPlaques(); }
        }
    }, 1500);

    // ==================== БЫСТРЫЙ ПОКАЗ ЭКРАНА ВЫБОРА (v5.5.1) ====================
    // Проверка раз в 400 мс вместо 3 сек. Показываем только если:
    //  - персонаж есть, профессия не выбрана,
    //  - онбординг персонажа закрыт, вступление показано,
    //  - экран выбора профессии ещё не открыт.
    if (!window._daoProfFastTrigger) {
        window._daoProfFastTrigger = setInterval(function() {
            try {
                const ch = getCharacter();
                if (!ch) return;
                if (ch.profession) return;
                if (document.getElementById("dao-onboarding")) return;
                if (!ch.introShown) return;
                if (document.getElementById("dao-profession-onboarding")) return;
                showProfessionSelection();
            } catch (e) {}
        }, 400);
    }

    // Дополнительный триггер, если интро ещё не показано, но прошло время
    setTimeout(function() {
        try {
            const ch = getCharacter();
            if (!ch || ch.profession) return;
            if (document.getElementById("dao-profession-onboarding")) return;
            if (document.getElementById("dao-onboarding")) return;
            const age = Date.now() - (ch.rolledAt || 0);
            if (age > 2500) showProfessionSelection();
        } catch (e) {}
    }, 2500);

    // ==================== ИНИЦИАЛИЗАЦИЯ ====================
    function initWorkshopButton() {
        injectWorkshopButton();
        // Прячем старые иконки 📖 📜 (если их ещё рисуют базовые скрипты)
        ["techniques-btn", "quests-btn"].forEach(function(id) {
            const el = document.getElementById(id);
            if (!el) return;
            el.style.display = "none";
            el.style.visibility = "hidden";
            el.style.pointerEvents = "none";
            el.style.position = "absolute";
            el.style.left = "-9999px";
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initWorkshopButton);
    } else {
        initWorkshopButton();
    }
    setTimeout(initWorkshopButton, 500);
    setInterval(initWorkshopButton, 3000);

    // ==================== ЭКСПОРТ НАРУЖУ (D-01) ====================
    window.daoOpenProfessionModal = openProfessionModal;
    window.daoOpenShop = openShop;
    window.daoOpenWorkshopHub = openWorkshopHub;
    window.daoShowProfessionSelection = showProfessionSelection;

    // Глобальные короткие имена — для вызовов из onclick и патчей
    window.openProfessionModal = openProfessionModal;
    window.openShop = openShop;
    window.openWorkshopHub = openWorkshopHub;
    window.daoOpenProfession = openProfessionModal;

    // Данные профессий — для инвентаря в ui.js
    window.daoProfessionsRegistry = PROFESSIONS_DATA;

    try {
        if (typeof addLog === "function") addLog("✓ Профессии v5.8: 5 связок загружено", true);
    } catch (e) {}
})();