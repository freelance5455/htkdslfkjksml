/* Fibonacci Retracement — يُرسم دائماً من آخر موجة مؤكدة على ZigZag */
const FIB_VALS = [0, .236, .382, .5, .618, .786, 1];

function fibFromPoints(dir, hi, lo, i0) {
  return {
    dir, hi, lo, i0,
    lv: FIB_VALS.map(v => ({ v, p: dir === 'up' ? hi - (hi - lo) * v : lo + (hi - lo) * v }))
  };
}

function buildFib(z, trend) {
  const a = z[z.length - 2], b = z[z.length - 1];
  if (!a || !b) return null;
  const dir = trend === 'down' ? 'down' : trend === 'up' ? 'up' : (b.p > a.p ? 'up' : 'down');
  let hi, lo, i0;
  if (dir === 'up') {
    const kH = [...z].reverse().find(x => x.t === 'H');
    const kL = kH && [...z].reverse().find(x => x.t === 'L' && x.i < kH.i);
    if (kH && kL) { hi = kH.p; lo = kL.p; i0 = kL.i; }
  } else {
    const kL = [...z].reverse().find(x => x.t === 'L');
    const kH = kL && [...z].reverse().find(x => x.t === 'H' && x.i < kL.i);
    if (kH && kL) { hi = kH.p; lo = kL.p; i0 = kH.i; }
  }
  if (!hi || !lo || hi <= lo) return null;
  return fibFromPoints(dir, hi, lo, i0);
}

const fibPrice = (fib, v) => { if (!fib) return null; const l = fib.lv.find(x => x.v === v); return l ? l.p : null; };

/* منطقة 50% – 61.8% */
function fibBand(fib) {
  if (!fib) return null;
  const a = fibPrice(fib, .5), b = fibPrice(fib, .618);
  return { lo:Math.min(a, b), hi:Math.max(a, b) };
}
/* نطاق 38.2% – 78.6% */
function fibWide(fib) {
  if (!fib) return null;
  const a = fibPrice(fib, .382), b = fibPrice(fib, .786);
  return { lo:Math.min(a, b), hi:Math.max(a, b) };
}