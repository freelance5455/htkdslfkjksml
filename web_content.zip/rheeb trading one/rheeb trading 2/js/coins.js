/* صفحة العملات الرقمية */
$('#cf').innerHTML = [['all', 'الكل'], ['up', 'الصاعدة'], ['down', 'الهابطة'], ['fav', 'المفضلة'], ['|'],
  ['vol', 'الحجم'], ['price', 'السعر'], ['gain', 'الأعلى ارتفاعاً'], ['loss', 'الأكثر انخفاضاً']]
  .map(x => x[0] === '|' ? '<span style="border-inline-start:1px solid var(--line)"></span>'
    : `<button class="chip" data-k="${x[0]}">${x[1]}</button>`).join('');

$('#cf').onclick = e => {
  const k = e.target.dataset.k; if (!k) return;
  ['all', 'up', 'down', 'fav'].includes(k) ? S.flt = k : S.sort = k;
  renderCoins();
};
$('#q').oninput = e => { S.q = e.target.value.trim().toUpperCase(); renderCoins(); };

function renderCoins() {
  document.querySelectorAll('#cf .chip').forEach(b => b.classList.toggle('on', b.dataset.k === S.flt || b.dataset.k === S.sort));
  const a = Data.tickers.filter(t => t.sym.includes(S.q) &&
    (S.flt === 'all' || (S.flt === 'up' && t.chg > 0) || (S.flt === 'down' && t.chg < 0) || (S.flt === 'fav' && S.fav.has(t.sym))));
  const f = { vol:(x, y) => y.vol - x.vol, price:(x, y) => y.price - x.price, gain:(x, y) => y.chg - x.chg, loss:(x, y) => x.chg - y.chg }[S.sort];
  a.sort(f);

  $('#coins').innerHTML = a.length ? a.map(t => {
    const tr = t.sig ? TRD[t.sig.t4 === t.sig.t1 ? t.sig.t4 : 'side'] : null;
    const st = t.sig ? STAT[t.sig.status] : null;
    return `<div class="row" data-s="${t.sym}">
      <span class="logo" style="background:hsl(${Math.abs(hash(t.base)) % 360},55%,48%)">${t.base.slice(0, 2)}</span>
      <span class="sym"><b dir="ltr">${t.sym}</b><small>${t.base}</small></span>
      <span class="num">${fmt(t.price)}</span>
      <span class="num ${t.chg >= 0 ? 'up' : 'down'}">${t.chg >= 0 ? '+' : ''}${t.chg.toFixed(2)}%</span>
      <span class="num">${fv(t.vol)}</span>
      <span class="${tr ? tr[1] : ''}">${tr ? tr[2] + ' ' + tr[0] : '…'}</span>
      <span>${st ? `<span class="tag ${st[1]}">${st[0]}${t.sig.score ? ' · ' + t.sig.score : ''}</span>` : '…'}</span>
      <button class="star ${S.fav.has(t.sym) ? 'on' : ''}" data-f="${t.sym}">★</button>
    </div>`;
  }).join('') : '<div class="empty">لا توجد عملات مطابقة. جرّب إزالة الفلتر أو تغيير البحث.</div>';
}

$('#coins').onclick = e => {
  const f = e.target.closest('[data-f]');
  if (f) { const s = f.dataset.f; S.fav.has(s) ? S.fav.delete(s) : S.fav.add(s); save(); renderCoins(); return; }
  const r = e.target.closest('.row');
  if (r) { S.sym = r.dataset.s; go('chart'); }
};