/* FIBONACCI SMC SCALPING — التحليل، التقييم من 100، وإصدار الإشارة */
function analyze(c) {
  const n = S.n, z = pivots(c, n);
  const last = c[c.length - 1];
  const A = { z, price:last.close, last, len:c.length };
  const { H, L, high, low } = lastSwings(z);
  const h = H.slice(-2), l = L.slice(-2);
  A.trend = (h.length < 2 || l.length < 2) ? 'side'
    : (h[1].p > h[0].p && l[1].p > l[0].p) ? 'up'
    : (h[1].p < h[0].p && l[1].p < l[0].p) ? 'down' : 'side';
  A.fib = buildFib(z, A.trend);
  A.ob = orderBlocks(c);
  A.fvg = fvgZones(c, A.price);
  A.sd = sdZones(c, z);
  A.sr = srZones(H, L);
  A.ev = structureEvents(c, z);
  A.lastH = high; A.lastL = low;
  return A;
}

/* ---------- نظام التقييم من 100 نقطة ---------- */
function scoreSetup(a4, a1, a, side) {
  const buy = side === 'BUY', s = buy ? 'bull' : 'bear', want = buy ? 'up' : 'down';
  const p = a.price, tol = .0012, R = [];
  let sc = 0, zone = false, confirm = false;

  /* توافق 4H و1H — 20 */
  if (a4.trend === want && a1.trend === want) { sc += 20; R.push('توافق اتجاه 4H و1H (' + (buy ? 'صاعد' : 'هابط') + ')'); }
  else if (a4.trend === want || a1.trend === want) { sc += 6; R.push('توافق جزئي في الاتجاه'); }

  /* هيكل السوق — 15 */
  if (a.trend === want) { sc += 15; R.push(buy ? 'هيكل سوق صاعد على 15M (HH + HL)' : 'هيكل سوق هابط على 15M (LH + LL)'); }

  /* Fibonacci — 15 */
  const band = fibBand(a.fib), wide = fibWide(a.fib);
  if (band && p >= band.lo * (1 - tol) && p <= band.hi * (1 + tol)) {
    sc += 15; zone = true; R.push('السعر داخل منطقة فيبوناتشي 50% – 61.8%');
  } else if (wide && p >= wide.lo * (1 - tol) && p <= wide.hi * (1 + tol)) {
    sc += 8; zone = true; R.push('السعر داخل نطاق فيبوناتشي 38.2% – 78.6%');
  }

  /* Order Block — 15 */
  if (a.ob.some(z => z.s === s && inZ(p, z, tol))) {
    sc += 15; zone = true; R.push(buy ? 'السعر داخل Bullish Order Block' : 'السعر داخل Bearish Order Block');
  }

  /* FVG — 10 */
  if (a.fvg.some(z => z.s === s && inZ(p, z, tol))) {
    sc += 10; zone = true; R.push(buy ? 'السعر داخل Bullish FVG' : 'السعر داخل Bearish FVG');
  }

  /* Supply & Demand — تُحسب داخل منطقة الدعم/المقاومة */
  if (a.sd.some(z => z.s === s && inZ(p, z, tol))) { zone = true; R.push(buy ? 'السعر داخل منطقة Demand' : 'السعر داخل منطقة Supply'); }

  /* الدعم والمقاومة — 10 */
  const sr = a.sr.filter(x => buy ? (x.t === 'L' && x.p < p) : (x.t === 'H' && x.p > p))
    .sort((x, y) => buy ? y.p - x.p : x.p - y.p)[0];
  if (sr && Math.abs(p - sr.p) / p < .012) {
    sc += 10; R.push((buy ? 'قريب من دعم عند ' : 'قريب من مقاومة عند ') + fmt(sr.p));
  }

  /* BOS / CHoCH — 10 */
  const ev = a.ev[a.ev.length - 1];
  if (ev && ev.up === buy && ev.j >= a.len - 40) {
    sc += 10; R.push((ev.k === 'CHoCH' ? 'CHoCH ' : 'BOS ') + (buy ? 'صاعد' : 'هابط'));
  }

  /* شمعة التأكيد — 5 */
  if (buy ? a.last.close > a.last.open : a.last.close < a.last.open) {
    sc += 5; confirm = true; R.push('شمعة تأكيد ' + (buy ? 'صاعدة' : 'هابطة'));
  }

  return { score:Math.min(100, sc), reasons:R, zone, confirm };
}

/* ---------- إدارة الصفقة: وقف وهدف وفق Fibonacci والهيكل ---------- */
function levels(a, side, entry) {
  const buy = side === 'BUY';
  const below = [], above = [];
  a.z.forEach(x => (x.t === 'L' ? below : above).push(x.p));
  a.ob.forEach(z => (z.s === 'bull' ? below : above).push(z.s === 'bull' ? z.bot : z.top));
  a.sd.forEach(z => (z.s === 'bull' ? below : above).push(z.s === 'bull' ? z.bot : z.top));
  a.sr.forEach(x => (x.t === 'L' ? below : above).push(x.p));

  let sw;
  if (buy) { const c = below.filter(v => v < entry * .9999); sw = c.length ? Math.max(...c) : entry * .99; }
  else { const c = above.filter(v => v > entry * 1.0001); sw = c.length ? Math.min(...c) : entry * 1.01; }

  let sl = buy ? sw * .9985 : sw * 1.0015;
  if (buy ? sl >= entry : sl <= entry) sl = entry * (buy ? .99 : 1.01);

  /* الهدف: Fibonacci 0 للشراء، Fibonacci 100 للبيع */
  let tp = null;
  if (a.fib && a.fib.dir === (buy ? 'up' : 'down')) tp = buy ? a.fib.hi : a.fib.lo;
  const minRR = Math.max(2, S.rr);
  const need = entry + (buy ? 1 : -1) * Math.abs(entry - sl) * minRR;
  if (tp == null || (buy ? tp < need : tp > need)) tp = need;

  const rr = Math.abs(tp - entry) / Math.max(1e-12, Math.abs(entry - sl));
  return { entry, sl, tp, rr };
}

/* ---------- بناء الإشارة ---------- */
function buildSignal(sym, a4, a1, a) {
  const out = {
    sym, symbol:sym, t4:a4.trend, t1:a1.trend, t15:a.trend,
    status:'none', side:null, reasons:[], score:0, tf:'15M', rr:S.rr, time:Date.now()
  };
  if (!S.engine) { out.reasons.push('التحليل متوقف من الإعدادات'); return out; }
  if (a4.trend === 'side' || a4.trend !== a1.trend) {
    out.reasons.push('اتجاها 4H و1H غير متوافقين، لا تصدر صفقة');
    return out;
  }
  const buy = a4.trend === 'up', side = buy ? 'BUY' : 'SELL';
  out.side = side;
  const sc = scoreSetup(a4, a1, a, side);
  out.score = sc.score; out.reasons = sc.reasons;
  if (!sc.zone) { out.status = 'watch'; return out; }

  const lv = levels(a, side, a.price);
  out.entry = lv.entry; out.sl = lv.sl; out.tp = lv.tp; out.rr = +lv.rr.toFixed(2);
  out.status = (sc.score >= S.minScore && sc.confirm) ? 'signal' : 'wait';
  if (sc.score < S.minScore) out.reasons.push('قوة الإشارة ' + sc.score + ' أقل من الحد الأدنى ' + S.minScore);
  return out;
}

function signal(sym) {
  return buildSignal(
    sym,
    analyze(Data.klines(sym, '4H')),
    analyze(Data.klines(sym, '1H')),
    analyze(Data.klines(sym, '15M'))
  );
}