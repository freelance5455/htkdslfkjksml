/* صفحة الصفقات والإشارات + محرك الإشارات التاريخية (بدون أي معلومات مستقبلية) */
function runAll() {
  if (!S.engine) {
    Data.tickers.forEach(t => t.sig = { sym:t.sym, status:'none', t4:'side', t1:'side', t15:'side', reasons:[], score:0 });
    return;
  }
  Data.tickers.forEach(t => {
    if (!inWatch(t.sym)) return;
    const prev = t.sig;
    const s = signal(t.sym);
    t.sig = s;
    if (s.status === 'signal' && (!prev || prev.status !== 'signal') && S.notify)
      toast((s.side === 'BUY' ? 'شراء' : 'بيع') + ' ' + s.sym + ' · قوة ' + s.score);
  });
}

/* ---------- الإشارات التاريخية: تحليل كل شمعة بما كان متاحاً وقتها فقط ---------- */
const HIST = { key:null, list:[], map:new Map() };

function sliceClosed(arr, t, tfSec, max = 220) {
  let lo = 0, hi = arr.length;
  while (lo < hi) { const m = (lo + hi) >> 1; if (arr[m].time + tfSec <= t) lo = m + 1; else hi = m; }
  return arr.slice(Math.max(0, lo - max), lo);
}

function ensureHist() {
  const c = cur.c;
  if (!c || c.length < 160) return HIST.list;
  const key = [S.sym, S.tf, S.minScore, S.rr, S.n, c.length].join('|');
  if (HIST.key === key) return HIST.list;

  HIST.key = key; HIST.list = []; HIST.map = new Map();
  const a4 = Data.klines(S.sym, '4H'), a1 = Data.klines(S.sym, '1H');
  const start = Math.max(150, c.length - 300);
  let cool = -1;

  for (let i = start; i < c.length - 1; i++) {
    if (i < cool) continue;
    const win = c.slice(Math.max(0, i - 179), i + 1);
    const A = analyze(win);
    const t = c[i].time;
    const W4 = analyze(sliceClosed(a4, t, TFS['4H']));
    const W1 = analyze(sliceClosed(a1, t, TFS['1H']));
    const sg = buildSignal(S.sym, W4, W1, A);
    if (sg.status !== 'signal') continue;

    const buy = sg.side === 'BUY';
    let result = 'open', j = null;
    for (let k = i + 1; k < c.length; k++) {
      const x = c[k];
      if (buy ? x.low <= sg.sl : x.high >= sg.sl) { result = 'sl'; j = k; break; }
      if (buy ? x.high >= sg.tp : x.low <= sg.tp) { result = 'tp'; j = k; break; }
    }
    HIST.list.push({ i, j, time:t, side:sg.side, entry:sg.entry, sl:sg.sl, tp:sg.tp, score:sg.score, result, tf:S.tf });
    cool = i + 10;
  }
  return HIST.list;
}

/* ---------- صفحة الصفقات ---------- */
$('#sf').innerHTML = [['all', 'الكل'], ['signal', 'إشارات جاهزة'], ['wait', 'بانتظار تأكيد'], ['BUY', 'شراء'], ['SELL', 'بيع']]
  .map(x => `<button class="chip" data-k="${x[0]}">${x[1]}</button>`).join('');

$('#sf').onclick = e => { if (e.target.dataset.k) { S.sf = e.target.dataset.k; renderSigs(); } };
$('#rf').onclick = () => { runAll(); renderSigs(); };

function renderSigs() {
  if (!Data.tickers[0].sig) runAll();
  document.querySelectorAll('#sf .chip').forEach(b => b.classList.toggle('on', b.dataset.k === S.sf));

  if (!S.engine) {
    $('#sigs').innerHTML = '<div class="empty">التحليل متوقف. فعّله من صفحة الإعدادات لبدء المسح.</div>';
    return;
  }

  const rank = { signal:0, wait:1 };
  const a = Data.tickers.map(t => t.sig).filter(s => s && s.entry && (S.sf === 'all' || s.status === S.sf || s.side === S.sf));
  a.sort((x, y) => (rank[x.status] ?? 2) - (rank[y.status] ?? 2) || y.score - x.score);

  $('#sigs').innerHTML = a.length ? a.map(s => {
    const st = STAT[s.status] || STAT.none;
    return `<div class="card sig"><div class="t">
      <b dir="ltr" style="font-size:16px">${s.sym}</b>
      <span class="tag ${s.side === 'BUY' ? 'up' : 'down'}">${s.side === 'BUY' ? 'شراء' : 'بيع'}</span>
      <span class="tag ${st[1]}">${st[0]}</span>
      <span class="tag bl">${s.score}/100</span>
      <span class="tag">${s.tf}</span>
      <span class="sp"></span>
      <button class="btn g" data-o="${s.sym}">الشارت</button>
      ${s.status === 'signal' ? `<button class="btn" data-t="${s.sym}">تسجيل</button>` : ''}
    </div>
    <div class="sc"><span class="tag ${s.score >= S.minScore ? 'up' : 'bl'}">${s.score}</span><span class="tr"><i style="width:${s.score}%;background:${s.score >= S.minScore ? 'var(--up)' : 'var(--blue)'}"></i></span></div>
    <div class="kv"><span>الدخول</span><span class="num">${fmt(s.entry)}</span></div>
    <div class="kv"><span>وقف الخسارة</span><span class="num down">${fmt(s.sl)}</span></div>
    <div class="kv"><span>الهدف (1:${s.rr})</span><span class="num up">${fmt(s.tp)}</span></div>
    <ul class="r" style="margin-top:8px">${s.reasons.map(r => '<li>✓ ' + r + '</li>').join('')}</ul></div>`;
  }).join('') : '<div class="empty">لا توجد فرص تطابق الشروط الآن. الاستراتيجية لا تصدر صفقة إلا عند توافق 4H و1H ووصول السعر إلى منطقة دخول على 15M وتحقيق 80 نقطة على الأقل.</div>';
}

$('#sigs').onclick = e => {
  const o = e.target.dataset.o, t = e.target.dataset.t;
  if (o) { S.sym = o; go('chart'); }
  if (t) { take(Data.t(t).sig); go('log'); }
};