/* ZigZag — كشف القمم والقيعان المؤكدة (لا يعتمد على أي شمعة مستقبلية بعد نقطة التأكيد) */
function pivots(c, n) {
  const p = [];
  for (let i = n; i < c.length - n; i++) {
    let H = 1, L = 1;
    for (let j = 1; j <= n; j++) {
      if (c[i].high <= c[i - j].high || c[i].high <= c[i + j].high) H = 0;
      if (c[i].low >= c[i - j].low || c[i].low >= c[i + j].low) L = 0;
    }
    if (H) p.push({ i, t:'H', p:c[i].high });
    else if (L) p.push({ i, t:'L', p:c[i].low });
  }
  const z = [];
  for (const q of p) {
    const l = z[z.length - 1];
    if (l && l.t === q.t) { if ((q.t === 'H' && q.p > l.p) || (q.t === 'L' && q.p < l.p)) z[z.length - 1] = q; }
    else z.push(q);
  }
  return z;
}

/* آخر قمة وآخر قاع مؤكدين */
function lastSwings(z) {
  const H = z.filter(x => x.t === 'H'), L = z.filter(x => x.t === 'L');
  return { high:H[H.length - 1] || null, low:L[L.length - 1] || null, H, L };
}