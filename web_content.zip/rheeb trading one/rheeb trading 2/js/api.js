/* RAHIB TRADING PRO — الطبقة الأساسية: الثوابت، الحالة، الأدوات، ومصدر البيانات.
   المرحلة 1: محاكاة محلية. المرحلة 2: server-client.js يستبدل المصدر بالسيرفر. */
const $ = s => document.querySelector(s);

const COINS = "BTC ETH BNB SOL XRP ADA DOGE AVAX TRX DOT LINK POL TON SHIB LTC BCH UNI ATOM XLM ETC FIL APT NEAR ARB OP INJ SUI HBAR VET ICP IMX RNDR GRT AAVE MKR STX ALGO EGLD SAND MANA AXS THETA FTM FLOW XTZ EOS KAVA CHZ GALA LDO SNX CRV RUNE 1INCH ZEC DASH COMP ENJ BAT ZIL ANKR IOTA NEO WAVES KSM QTUM ONT CELO YFI SUSHI LRC ROSE MINA PEPE WLD SEI TIA PYTH JUP BONK FET AR PENDLE ENS BLUR DYDX CAKE GMX FLOKI ORDI JTO STRK W ONDO TAO CFX AGIX OCEAN RPL CKB".split(' ');

const TFS = { '5M':300, '15M':900, '30M':1800, '1H':3600, '4H':14400, '1D':86400, '1W':604800 };
const PRICE0 = { BTC:97000, ETH:3400, BNB:640, SOL:190, XRP:2.3, ADA:.95, DOGE:.38, AVAX:41, TRX:.25 };

const OVL = {
  zz:'ZigZag', fib:'Fibonacci', ob:'Order Blocks', fvg:'FVG',
  sd:'Supply & Demand', sr:'S&R', bos:'BOS / CHoCH', sig:'الإشارات التاريخية'
};

const STAT = {
  signal:['إشارة جاهزة','up'], wait:['بانتظار شمعة تأكيد','bl'],
  watch:['مراقبة','bl'], none:['لا صفقة','']
};
const TRD = { up:['صاعد','up','▲'], down:['هابط','down','▼'], side:['عرضي','','▬'] };

const SAVE = (() => { try { return JSON.parse(localStorage.getItem('rahib') || '{}'); } catch (e) { return {}; } })();

const S = {
  page:'coins', sym:'BTCUSDT', tf:'15M', q:'', sort:'vol', flt:'all', sf:'all',
  fav: new Set(SAVE.fav || []),
  theme: SAVE.theme || 'dark',
  rr: SAVE.rr || 2,
  n: SAVE.n || 4,
  api: SAVE.api || '',
  journal: SAVE.journal || [],
  ovl: { zz:1, fib:1, ob:1, fvg:1, sd:0, sr:1, bos:1, sig:1 },
  /* إضافات المرحلة 1 */
  engine: SAVE.engine !== false,
  notify: SAVE.notify !== false,
  minScore: SAVE.minScore || 80,
  watch: SAVE.watch || [],
  tg: SAVE.tg || { set:false, chat:'', enabled:false }
};

const save = () => {
  try {
    localStorage.setItem('rahib', JSON.stringify({
      fav:[...S.fav], theme:S.theme, rr:S.rr, n:S.n, api:S.api, journal:S.journal,
      engine:S.engine, notify:S.notify, minScore:S.minScore, watch:S.watch, tg:S.tg
    }));
  } catch (e) {}
};

const hash = s => [...s].reduce((a,c) => (a * 31 + c.charCodeAt(0)) | 0, 7);
const rng = a => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const fmt = p => p >= 1000 ? p.toLocaleString('en', { maximumFractionDigits:2 }) : p >= 1 ? p.toFixed(4) : p.toFixed(6);
const fv = v => v >= 1e9 ? (v / 1e9).toFixed(2) + 'B' : v >= 1e6 ? (v / 1e6).toFixed(1) + 'M' : (v / 1e3).toFixed(0) + 'K';
const inWatch = sym => !S.watch.length || S.watch.includes(sym);

/* ---------- Data layer (phase 2: replace with server calls) ---------- */
const Data = {
  tickers: COINS.map((b, i) => {
    const r = rng(hash(b));
    const p = PRICE0[b] || Math.pow(10, r() * 4 - 2.5);
    return { sym:b + 'USDT', base:b, price:p, chg:(r() - .5) * 14, vol:4e9 * Math.pow(.93, i) * (.7 + r() * .6), sig:null };
  }),
  cache: {},
  t(sym) { return this.tickers.find(x => x.sym === sym); },
  klines(sym, tf, n = 520) {
    const k = sym + tf;
    if (this.cache[k]) return this.cache[k];
    const T = this.t(sym), st = TFS[tf], r = rng(hash(k)), vol = .0035 * Math.sqrt(st / 900), ph = r() * 6, out = [];
    let p = 1, now = Math.floor(Date.now() / 1000 / st) * st;
    for (let i = 0; i < n; i++) {
      const d = Math.sin(i / 55 + ph) * vol * .45, o = p;
      const c = o * (1 + (r() - .5) * 2 * vol + d);
      const h = Math.max(o, c) * (1 + r() * vol * .6);
      const l = Math.min(o, c) * (1 - r() * vol * .6);
      out.push({ time: now - (n - 1 - i) * st, open:o, high:h, low:l, close:c, vol:(.4 + r()) * T.vol / 1e4 * (1 + Math.abs(c - o) / o * 60) });
      p = c;
    }
    const f = T.price / p;
    out.forEach(x => { x.open *= f; x.high *= f; x.low *= f; x.close *= f; });
    return this.cache[k] = out;
  },
  tick() {
    const now = Date.now() / 1000;
    this.tickers.forEach(T => {
      const f = 1 + (Math.random() - .5) * .0014;
      T.price *= f; T.chg += (f - 1) * 100;
      for (const tf in TFS) {
        const c = this.cache[T.sym + tf];
        if (!c) continue;
        const st = TFS[tf], l = c[c.length - 1];
        if (now >= l.time + st) c.push({ time:l.time + st, open:l.close, high:l.close, low:l.close, close:l.close, vol:0 });
        const x = c[c.length - 1];
        x.close = x.close * f;
        x.high = Math.max(x.high, x.close);
        x.low = Math.min(x.low, x.close);
        x.vol += T.vol / 4e5 * Math.random();
      }
    });
  },
  reset() { this.cache = {}; }
};