/* صفحة الإعدادات — تُحفظ محلياً وتؤثر فوراً على المحرك */
$('#s-rr').value = S.rr;
$('#s-n').value = S.n;
$('#s-api').value = S.api;
$('#s-score').value = S.minScore;
$('#s-eng').value = S.engine ? '1' : '0';
$('#s-ntf').value = S.notify ? '1' : '0';
$('#s-watch').value = S.watch.join(', ');
$('#s-tgchat').value = S.tg.chat || '';
$('#s-tgen').value = S.tg.enabled ? '1' : '0';

$('#s-th').onchange = e => { S.theme = e.target.value; save(); applyTheme(); };
$('#s-rr').onchange = e => { S.rr = Math.max(1, +e.target.value || 2); e.target.value = S.rr; save(); runAll(); };
$('#s-n').onchange = e => { S.n = Math.min(8, Math.max(2, +e.target.value || 4)); e.target.value = S.n; save(); runAll(); };
$('#s-api').onchange = e => { S.api = e.target.value.trim(); save(); };

$('#s-score').onchange = e => {
  S.minScore = Math.min(100, Math.max(50, Math.round(+e.target.value || 80)));
  e.target.value = S.minScore; save(); runAll(); renderCoins();
};
$('#s-eng').onchange = e => { S.engine = e.target.value === '1'; save(); runAll(); renderCoins(); if (S.page === 'chart') loadChart(false); };
$('#s-ntf').onchange = e => { S.notify = e.target.value === '1'; save(); };

$('#s-watch').onchange = e => {
  S.watch = e.target.value.toUpperCase().split(/[\s,]+/).map(x => x.trim()).filter(Boolean);
  S.watch = S.watch.map(s => /USDT$/.test(s) ? s : s + 'USDT');
  e.target.value = S.watch.join(', ');
  save(); runAll(); renderCoins();
};

$('#s-tgchat').onchange = e => { S.tg.chat = e.target.value.trim(); S.tg.set = !!S.tg.chat; save(); };
$('#s-tgen').onchange = e => { S.tg.enabled = e.target.value === '1'; save(); };
$('#s-tgtok').onchange = e => {
  /* لا يُحفظ التوكن في الواجهة أبداً — يُرسل للسيرفر في المرحلة الثانية فقط */
  const has = !!e.target.value;
  e.target.value = '';
  $('#s-tgnote').innerHTML = has
    ? '<span class="up">تم استلام التوكن وإرساله للسيرفر. لن يُعرض هنا مرة أخرى.</span>'
    : 'في المرحلة الأولى يُحفظ Chat ID فقط. بعد ربط السيرفر يُخزَّن التوكن مشفراً هناك ولا يُعاد إلى الواجهة أبداً.';
};