/* SMC — Order Blocks, FVG, Supply & Demand, Support & Resistance, BOS/CHoCH
   كل الدوال خطية تقريباً في الزمن لتعمل بسرعة على الهاتف. */
const inZ = (p, z, tol) => !!z && p <= z.top * (1 + tol) && p >= z.bot * (1 - tol);

function suffixExtremes(c) {
  const n = c.length;
  const minC = new Float64Array(n + 1), maxC = new Float64Array(n + 1),
        minL = new Float64Array(n + 1), maxH = new Float64Array(n + 1);
  minC[n] = Infinity; maxC[n] = -Infinity; minL[n] = Infinity; maxH[n] = -Infinity;
  for (let i = n - 1; i >= 0; i--) {
    minC[i] = Math.min(minC[i + 1], c[i].close);
    maxC[i] = Math.max(maxC[i + 1], c[i].close);
    minL[i] = Math.min(minL[i + 1], c[i].low);
    maxH[i] = Math.max(maxH[i + 1], c[i].high);
  }
  return { minC, maxC, minL, maxH };
}

function orderBlocks(c) {
  if (c.length < 4) return [];
  const ab = c.reduce((s, x) => s + Math.abs(x.close - x.open), 0) / c.length || 1e-9;
  const { minC, maxC } = suffixExtremes(c);
  const out = [];
  for (let i = 1; i < c.length - 2; i++) {
    const x = c[i], y = c[i + 1], body = Math.abs(y.close - y.open);
    if (x.close < x.open && y.close > x.high && body > 1.3 * ab && !(minC[i + 2] < x.low))
      out.push({ s:'bull', i, top:x.high, bot:x.low });
    if (x.close > x.open && y.close < x.low && body > 1.3 * ab && !(maxC[i + 2] > x.high))
      out.push({ s:'bear', i, top:x.high, bot:x.low });
  }
  return ['bull', 'bear'].flatMap(s => out.filter(x => x.s === s).slice(-3));
}

function fvgZones(c, price) {
  if (c.length < 4) return [];
  const { minL, maxH } = suffixExtremes(c);
  const out = [];
  for (let i = 1; i < c.length - 2; i++) {
    const g1 = c[i + 1].low - c[i - 1].high;
    const g2 = c[i - 1].low - c[i + 1].high;
    if (g1 > price * .0008 && !(minL[i + 2] <= c[i - 1].high))
      out.push({ s:'bull', i, top:c[i + 1].low, bot:c[i - 1].high });
    if (g2 > price * .0008 && !(maxH[i + 2] >= c[i - 1].low))
      out.push({ s:'bear', i, top:c[i - 1].low, bot:c[i + 1].high });
  }
  return ['bull', 'bear'].flatMap(s => out.filter(x => x.s === s).slice(-3));
}

function sdZones(c, z) {
  const out = [];
  const H = z.filter(x => x.t === 'H'), L = z.filter(x => x.t === 'L');
  const lL = L[L.length - 1], lH = H[H.length - 1];
  if (lL && c[lL.i]) { const x = c[lL.i]; out.push({ s:'bull', i:lL.i, top:Math.max(x.open, x.close), bot:x.low }); }
  if (lH && c[lH.i]) { const x = c[lH.i]; out.push({ s:'bear', i:lH.i, top:x.high, bot:Math.min(x.open, x.close) }); }
  return out;
}

function srZones(H, L) {
  return [...H.slice(-3), ...L.slice(-3)].map(x => ({ p:x.p, i:x.i, t:x.t })).filter(x => x.p > 0);
}

/* BOS = استمرار الاتجاه، CHoCH = تغيّر الهيكل */
function structureEvents(c, z) {
  const ev = [];
  z.forEach((q, k) => {
    const nx = z.slice(k + 1).find(y => y.t === q.t);
    const end = Math.min(nx ? nx.i : c.length - 1, q.i + 200);
    for (let j = q.i + 1; j <= end; j++) {
      if (q.t === 'H' ? c[j].close > q.p : c[j].close < q.p) { ev.push({ j, i:q.i, p:q.p, up:q.t === 'H' }); break; }
    }
  });
  ev.sort((a, b) => a.j - b.j);
  let d = 0;
  ev.forEach(e => { const dir = e.up ? 1 : -1; e.k = (d === 0 || d === dir) ? 'BOS' : 'CHoCH'; d = dir; });
  return ev.slice(-6);
}