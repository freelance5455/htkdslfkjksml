#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RAHIB TRADING PRO — Standalone Server (Standard Library Only)
- Runs perfectly on Pydroid 3, Linux, Windows.
- Serves REST + WebSocket + Static Files.
- Threaded price updater (updates every 3s) & threaded analysis worker.
"""
import os, sys, json, time, hmac, base64, secrets, socket, ssl, struct, hashlib
import threading, sqlite3, traceback
from datetime import datetime, timezone
from contextlib import contextmanager
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from urllib.parse import urlparse, parse_qs, urlencode
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from mimetypes import guess_type

# ═══════════════════════════════════════════════════════════════════════
# 1) الإعدادات
# ═══════════════════════════════════════════════════════════════════════
def _load_dotenv(path=".env"):
    if not os.path.exists(path): return
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line: continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except Exception: pass

_load_dotenv()

def _jwt_secret():
    sec = os.getenv("JWT_SECRET", "").strip()
    if sec: return sec
    p = ".jwt_secret"
    if os.path.exists(p):
        with open(p, "r") as f: return f.read().strip()
    new = secrets.token_hex(48)
    try:
        with open(p, "w") as f: f.write(new)
    except Exception: pass
    return new

class CFG:
    DB_PATH         = os.getenv("DB_PATH", "rahib.db")
    JWT_SECRET      = _jwt_secret()
    JWT_TTL         = int(os.getenv("JWT_TTL", 7 * 86400))
    ADMIN_USER      = os.getenv("ADMIN_USERNAME", "admin")
    ADMIN_PASS      = os.getenv("ADMIN_PASSWORD", "ChangeMe123!")
    FAPI            = os.getenv("BINANCE_FAPI", "https://fapi.binance.com").rstrip("/")
    TOP_N           = int(os.getenv("TOP_N", 100))
    EXCLUDE_BASES   = set(x.strip().upper() for x in os.getenv("EXCLUDE_BASES",
                        "USDT,USDC,BUSD,DAI,TUSD,FDUSD,USDP,USDD,EUR,GBP,BTCST,BTTC,WBTC").split(",") if x.strip())
    TG_TOKEN        = os.getenv("TELEGRAM_BOT_TOKEN", "")
    TG_CHAT         = os.getenv("TELEGRAM_CHAT_ID", "")
    TG_ENABLED      = os.getenv("TELEGRAM_ENABLED", "0") == "1"
    STATIC_DIR      = os.getenv("STATIC_DIR", ".")
    ENGINE_ENABLED  = os.getenv("ENGINE_ENABLED", "1") == "1"
    STRATEGY_ENABLED= os.getenv("STRATEGY_ENABLED", "1") == "1"
    MIN_SCORE       = int(os.getenv("MIN_SCORE", 80))
    RR              = float(os.getenv("RR", 2.0))
    RISK_PCT        = float(os.getenv("RISK_PCT", 1.0))
    MAX_RISK_PCT    = float(os.getenv("MAX_RISK_PCT", 5.0))
    ZIGZAG_N        = int(os.getenv("ZIGZAG_N", 4))
    FEE_PCT         = float(os.getenv("FEE_PCT", 0.04))
    SLIPPAGE_PCT    = float(os.getenv("SLIPPAGE_PCT", 0.02))
    START_TS        = time.time()

def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)

# ═══════════════════════════════════════════════════════════════════════
# 2) HTTP helpers (urllib)
# ═══════════════════════════════════════════════════════════════════════
try: _SSL_CTX = ssl.create_default_context()
except Exception: _SSL_CTX = ssl._create_unverified_context()

if not os.getenv("STRICT_SSL"):
    try:
        _SSL_CTX.check_hostname = False
        _SSL_CTX.verify_mode = ssl.CERT_NONE
    except Exception: pass

def fetch_json(url, timeout=15):
    try:
        req = Request(url, headers={"User-Agent": "RahibTrading/2.0"})
        with urlopen(req, timeout=timeout, context=_SSL_CTX) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None

def post_json(url, payload, timeout=15):
    try:
        body = json.dumps(payload).encode("utf-8")
        req = Request(url, data=body, method="POST",
                      headers={"Content-Type": "application/json", "User-Agent": "RahibTrading/2.0"})
        with urlopen(req, timeout=timeout, context=_SSL_CTX) as r:
            return json.loads(r.read().decode("utf-8"))
    except HTTPError as e:
        try: return json.loads(e.read().decode("utf-8"))
        except Exception: return None
    except Exception:
        return None

# ═══════════════════════════════════════════════════════════════════════
# 3) الأمان
# ═══════════════════════════════════════════════════════════════════════
def hash_password(pw):
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 120_000)
    return f"pbkdf2$120000${salt}${dk.hex()}"

def verify_password(pw, stored):
    try:
        scheme, iters, salt, digest = stored.split("$")
        if scheme != "pbkdf2": return False
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), int(iters))
        return hmac.compare_digest(dk.hex(), digest)
    except Exception: return False

def _b64u(b): return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")
def _b64ud(s): return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

def create_jwt(payload):
    h = _b64u(json.dumps({"alg":"HS256","typ":"JWT"}, separators=(",",":")).encode())
    body = dict(payload)
    body.setdefault("iat", int(time.time()))
    body.setdefault("exp", int(time.time()) + CFG.JWT_TTL)
    p = _b64u(json.dumps(body, separators=(",",":")).encode())
    sig = hmac.new(CFG.JWT_SECRET.encode(), f"{h}.{p}".encode(), hashlib.sha256).digest()
    return f"{h}.{p}.{_b64u(sig)}"

def decode_jwt(tok):
    try:
        h, p, s = tok.split(".")
        sig = hmac.new(CFG.JWT_SECRET.encode(), f"{h}.{p}".encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(_b64u(sig), s): return None
        body = json.loads(_b64ud(p))
        if body.get("exp", 0) < int(time.time()): return None
        return body
    except Exception: return None

# ═══════════════════════════════════════════════════════════════════════
# 4) قاعدة البيانات
# ═══════════════════════════════════════════════════════════════════════
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL, role TEXT DEFAULT 'user', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS coins (
  id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT UNIQUE NOT NULL,
  base TEXT NOT NULL, active INTEGER DEFAULT 1, added_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS signals (
  id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, side TEXT NOT NULL,
  status TEXT DEFAULT 'active', entry REAL, sl REAL, tp REAL, rr REAL DEFAULT 2.0,
  score INTEGER DEFAULT 0, reasons TEXT DEFAULT '[]', t4 TEXT, t1 TEXT, t15 TEXT,
  tf TEXT DEFAULT '15M', candle_time INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  telegram_sent INTEGER DEFAULT 0, exit_price REAL, exit_time INTEGER);
CREATE UNIQUE INDEX IF NOT EXISTS ix_sig ON signals (symbol, side, candle_time);
CREATE TABLE IF NOT EXISTS trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT, signal_id INTEGER, user_id INTEGER,
  symbol TEXT, side TEXT, entry REAL, sl REAL, tp REAL, status TEXT DEFAULT 'open',
  pnl_pct REAL, opened_at TEXT DEFAULT CURRENT_TIMESTAMP, closed_at TEXT);
CREATE TABLE IF NOT EXISTS strategy_settings (
  id INTEGER PRIMARY KEY CHECK (id=1), engine_enabled INTEGER DEFAULT 1, strategy_enabled INTEGER DEFAULT 1,
  min_score INTEGER DEFAULT 80, rr REAL DEFAULT 2.0, risk_pct REAL DEFAULT 1.0,
  max_risk_pct REAL DEFAULT 5.0, zigzag_n INTEGER DEFAULT 4, fee_pct REAL DEFAULT 0.04,
  slippage_pct REAL DEFAULT 0.02, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS telegram_settings (
  id INTEGER PRIMARY KEY CHECK (id=1), token TEXT DEFAULT '', chat_id TEXT DEFAULT '',
  enabled INTEGER DEFAULT 0, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, signal_id INTEGER, chat_id TEXT,
  status TEXT, detail TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
"""

@contextmanager
def db_conn():
    conn = sqlite3.connect(CFG.DB_PATH, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA synchronous=NORMAL")
        yield conn
        conn.commit()
    except Exception:
        conn.rollback(); raise
    finally: conn.close()

def init_db():
    with db_conn() as c:
        c.execute("PRAGMA journal_mode=WAL")
        c.executescript(SCHEMA)
        if not c.execute("SELECT id FROM users WHERE username=?", (CFG.ADMIN_USER,)).fetchone():
            c.execute("INSERT INTO users (username,password_hash,role) VALUES (?,?, 'admin')", (CFG.ADMIN_USER, hash_password(CFG.ADMIN_PASS)))
            log(f"admin created: {CFG.ADMIN_USER}")
        if not c.execute("SELECT id FROM strategy_settings WHERE id=1").fetchone():
            c.execute("""INSERT INTO strategy_settings (id,engine_enabled,strategy_enabled,min_score,rr,risk_pct,max_risk_pct,zigzag_n,fee_pct,slippage_pct)
                VALUES (1,?,?,?,?,?,?,?,?,?)""", (int(CFG.ENGINE_ENABLED), int(CFG.STRATEGY_ENABLED), CFG.MIN_SCORE, CFG.RR, CFG.RISK_PCT, CFG.MAX_RISK_PCT, CFG.ZIGZAG_N, CFG.FEE_PCT, CFG.SLIPPAGE_PCT))
        if not c.execute("SELECT id FROM telegram_settings WHERE id=1").fetchone():
            c.execute("INSERT INTO telegram_settings (id,token,chat_id,enabled) VALUES (1,?,?,?)", (CFG.TG_TOKEN, CFG.TG_CHAT, int(CFG.TG_ENABLED)))

def load_cfg():
    with db_conn() as c:
        r = c.execute("SELECT * FROM strategy_settings WHERE id=1").fetchone()
    return {
        "engine_enabled": bool(r["engine_enabled"]), "strategy_enabled": bool(r["strategy_enabled"]),
        "min_score": int(r["min_score"]), "rr": float(r["rr"]), "risk_pct": float(r["risk_pct"]),
        "max_risk_pct": float(r["max_risk_pct"]), "zigzag_n": int(r["zigzag_n"]),
        "fee_pct": float(r["fee_pct"]), "slippage_pct": float(r["slippage_pct"]),
    } if r else {}

def load_tg():
    with db_conn() as c:
        r = c.execute("SELECT * FROM telegram_settings WHERE id=1").fetchone()
    return {"token": r["token"] or "", "chat_id": r["chat_id"] or "", "enabled": bool(r["enabled"])} if r else {"token":"", "chat_id":"", "enabled":False}

# ═══════════════════════════════════════════════════════════════════════
# 5) Telegram
# ═══════════════════════════════════════════════════════════════════════
class Telegram:
    def __init__(self): self.token = ""; self.chat_id = ""; self.enabled = False
    def configure(self, token, chat_id, enabled):
        self.token = (token or "").strip(); self.chat_id = (chat_id or "").strip(); self.enabled = bool(enabled) and bool(self.token)
    def send_message(self, text, chat_id=None):
        if not self.enabled or not self.token: return False
        target = chat_id or self.chat_id
        if not target: return False
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        r = post_json(url, {"chat_id": target, "text": text, "parse_mode": "HTML", "disable_web_page_preview": True})
        return bool(r and r.get("ok"))
    def test(self): return self.send_message("✅ RAHIB TRADING PRO\nتم ربط Telegram بنجاح.")

tg = Telegram()

# ═══════════════════════════════════════════════════════════════════════
# 6) محرك التحليل (Fibonacci SMC Scalping)
# ═══════════════════════════════════════════════════════════════════════
TF_TO_BINANCE = {"5M":"5m","15M":"15m","30M":"30m","1H":"1h","4H":"4h","1D":"1d","1W":"1w"}
TF_SECONDS    = {"5M":300,"15M":900,"30M":1800,"1H":3600,"4H":14400,"1D":86400,"1W":604800}
FIB_VALS      = [0, .236, .382, .5, .618, .786, 1]

def _fmt(p): return round(p, 8)

def pivots(c, n):
    out = []; L = len(c)
    for i in range(n, L - n):
        H, Lo = True, True
        for j in range(1, n + 1):
            if c[i]["high"] <= c[i-j]["high"] or c[i]["high"] <= c[i+j]["high"]: H = False
            if c[i]["low"]  >= c[i-j]["low"]  or c[i]["low"]  >= c[i+j]["low"]:  Lo = False
            if not H and not Lo: break
        if H: out.append({"i":i,"t":"H","p":c[i]["high"]})
        elif Lo: out.append({"i":i,"t":"L","p":c[i]["low"]})
    z = []
    for q in out:
        if z and z[-1]["t"] == q["t"]:
            if (q["t"]=="H" and q["p"]>z[-1]["p"]) or (q["t"]=="L" and q["p"]<z[-1]["p"]): z[-1] = q
        else: z.append(q)
    return z

def last_swings(z):
    H = [x for x in z if x["t"]=="H"]; L = [x for x in z if x["t"]=="L"]
    return {"H":H,"L":L,"high":H[-1] if H else None,"low":L[-1] if L else None}

def build_fib(z, trend):
    if len(z) < 2: return None
    a, b = z[-2], z[-1]
    direction = trend if trend in ("up","down") else ("up" if b["p"] > a["p"] else "down")
    hi = lo = i0 = None
    if direction == "up":
        kH = next((x for x in reversed(z) if x["t"]=="H"), None)
        kL = next((x for x in reversed(z) if x["t"]=="L" and kH and x["i"] < kH["i"]), None)
        if kH and kL: hi, lo, i0 = kH["p"], kL["p"], kL["i"]
    else:
        kL = next((x for x in reversed(z) if x["t"]=="L"), None)
        kH = next((x for x in reversed(z) if x["t"]=="H" and kL and x["i"] < kL["i"]), None)
        if kH and kL: hi, lo, i0 = kH["p"], kL["p"], kH["i"]
    if hi is None or lo is None or hi <= lo: return None
    lv = [{"v":v, "p":_fmt(hi-(hi-lo)*v)} for v in FIB_VALS] if direction=="up" else [{"v":v, "p":_fmt(lo+(hi-lo)*v)} for v in FIB_VALS]
    return {"dir":direction, "hi":hi, "lo":lo, "i0":i0, "lv":lv}

def fib_price(fib, v):
    if not fib: return None
    for x in fib["lv"]:
        if abs(x["v"] - v) < 1e-9: return x["p"]
    return None

def fib_band(fib):
    if not fib: return None
    a, b = fib_price(fib, .5), fib_price(fib, .618)
    return {"lo":min(a,b), "hi":max(a,b)} if a and b else None

def fib_wide(fib):
    if not fib: return None
    a, b = fib_price(fib, .382), fib_price(fib, .786)
    return {"lo":min(a,b), "hi":max(a,b)} if a and b else None

def in_zone(p, z, tol):
    return z["bot"]*(1-tol) <= p <= z["top"]*(1+tol) if z else False

def _suffix_extremes(c):
    n = len(c); minC = [float("inf")]*(n+1); maxC = [float("-inf")]*(n+1)
    minL = [float("inf")]*(n+1); maxH = [float("-inf")]*(n+1)
    for i in range(n-1, -1, -1):
        minC[i] = min(minC[i+1], c[i]["close"]); maxC[i] = max(maxC[i+1], c[i]["close"])
        minL[i] = min(minL[i+1], c[i]["low"]);   maxH[i] = max(maxH[i+1], c[i]["high"])
    return minC, maxC, minL, maxH

def order_blocks(c):
    if len(c) < 4: return []
    ab = sum(abs(x["close"]-x["open"]) for x in c) / len(c) or 1e-9
    minC, maxC, _, _ = _suffix_extremes(c)
    out = []
    for i in range(1, len(c)-2):
        x, y = c[i], c[i+1]; body = abs(y["close"]-y["open"])
        if x["close"] < x["open"] and y["close"] > x["high"] and body > 1.3*ab and not (minC[i+2] < x["low"]):
            out.append({"s":"bull","i":i,"top":x["high"],"bot":x["low"]})
        if x["close"] > x["open"] and y["close"] < x["low"]  and body > 1.3*ab and not (maxC[i+2] > x["high"]):
            out.append({"s":"bear","i":i,"top":x["high"],"bot":x["low"]})
    return [x for x in out if x["s"]=="bull"][-3:] + [x for x in out if x["s"]=="bear"][-3:]

def fvg_zones(c, price):
    if len(c) < 4: return []
    _, _, minL, maxH = _suffix_extremes(c)
    out = []
    for i in range(1, len(c)-2):
        g1 = c[i+1]["low"] - c[i-1]["high"]; g2 = c[i-1]["low"] - c[i+1]["high"]
        if g1 > price*.0008 and not (minL[i+2] <= c[i-1]["high"]):
            out.append({"s":"bull","i":i,"top":c[i+1]["low"],"bot":c[i-1]["high"]})
        if g2 > price*.0008 and not (maxH[i+2] >= c[i-1]["low"]):
            out.append({"s":"bear","i":i,"top":c[i-1]["low"],"bot":c[i+1]["high"]})
    return [x for x in out if x["s"]=="bull"][-3:] + [x for x in out if x["s"]=="bear"][-3:]

def sd_zones(c, z):
    out = []
    L = [x for x in z if x["t"]=="L"]; H = [x for x in z if x["t"]=="H"]
    if L: out.append({"s":"bull","i":L[-1]["i"],"top":max(c[L[-1]["i"]]["open"],c[L[-1]["i"]]["close"]),"bot":c[L[-1]["i"]]["low"]})
    if H: out.append({"s":"bear","i":H[-1]["i"],"top":c[H[-1]["i"]]["high"],"bot":min(c[H[-1]["i"]]["open"],c[H[-1]["i"]]["close"])})
    return out

def sr_zones(H, L):
    return [{"p":x["p"], "i":x["i"], "t":x["t"]} for x in (H[-3:] + L[-3:])]

def structure_events(c, z):
    ev = []
    for k, q in enumerate(z):
        nx = next((y for y in z[k+1:] if y["t"]==q["t"]), None)
        end = min(nx["i"] if nx else len(c)-1, q["i"] + 200)
        for j in range(q["i"]+1, end+1):
            if (q["t"]=="H" and c[j]["close"] > q["p"]) or (q["t"]=="L" and c[j]["close"] < q["p"]):
                ev.append({"j":j, "i":q["i"], "p":q["p"], "up":q["t"]=="H"}); break
    ev.sort(key=lambda e: e["j"]); d = 0
    for e in ev:
        direction = 1 if e["up"] else -1
        e["k"] = "BOS" if (d==0 or d==direction) else "CHoCH"; d = direction
    return ev[-6:]

def analyze(c, zigzag_n=4):
    z = pivots(c, zigzag_n); last = c[-1]; price = last["close"]; sw = last_swings(z)
    H2 = sw["H"][-2:]; L2 = sw["L"][-2:]
    if len(H2) < 2 or len(L2) < 2: trend = "side"
    elif H2[1]["p"] > H2[0]["p"] and L2[1]["p"] > L2[0]["p"]: trend = "up"
    elif H2[1]["p"] < H2[0]["p"] and L2[1]["p"] < L2[0]["p"]: trend = "down"
    else: trend = "side"
    return {"z":z, "trend":trend, "price":price, "last":last, "len":len(c),
            "fib":build_fib(z, trend), "ob":order_blocks(c), "fvg":fvg_zones(c, price),
            "sd":sd_zones(c, z), "sr":sr_zones(sw["H"], sw["L"]), "ev":structure_events(c, z),
            "lastH":sw["high"], "lastL":sw["low"]}

def score_setup(a4, a1, a15, side, cfg):
    buy = side == "BUY"; s = "bull" if buy else "bear"; want = "up" if buy else "down"
    p = a15["price"]; tol = .0012; R = []; sc = 0; zone = False; confirm = False

    if a4["trend"]==want and a1["trend"]==want: sc += 20; R.append("توافق اتجاه 4H و1H (" + ("صاعد" if buy else "هابط") + ")")
    elif a4["trend"]==want or a1["trend"]==want: sc += 6; R.append("توافق جزئي في الاتجاه")
    if a15["trend"]==want: sc += 15; R.append("هيكل سوق صاعد على 15M (HH + HL)" if buy else "هيكل سوق هابط على 15M (LH + LL)")

    band, wide = fib_band(a15["fib"]), fib_wide(a15["fib"])
    if band and band["lo"]*(1-tol) <= p <= band["hi"]*(1+tol): sc += 15; zone = True; R.append("السعر داخل منطقة فيبوناتشي 50% – 61.8%")
    elif wide and wide["lo"]*(1-tol) <= p <= wide["hi"]*(1+tol): sc += 8; zone = True; R.append("السعر داخل نطاق فيبوناتشي 38.2% – 78.6%")

    if any(z["s"]==s and in_zone(p, z, tol) for z in a15["ob"]): sc += 15; zone = True; R.append("السعر داخل Bullish Order Block" if buy else "السعر داخل Bearish Order Block")
    if any(z["s"]==s and in_zone(p, z, tol) for z in a15["fvg"]): sc += 10; zone = True; R.append("السعر داخل Bullish FVG" if buy else "السعر داخل Bearish FVG")
    if any(z["s"]==s and in_zone(p, z, tol) for z in a15["sd"]): zone = True; R.append("السعر داخل منطقة Demand" if buy else "السعر داخل منطقة Supply")

    cands = [x for x in a15["sr"] if (buy and x["t"]=="L" and x["p"] < p) or (not buy and x["t"]=="H" and x["p"] > p)]
    sr = (max(cands, key=lambda x: x["p"]) if buy else min(cands, key=lambda x: x["p"])) if cands else None
    if sr and abs(p - sr["p"])/p < .012: sc += 10; R.append(("قريب من دعم عند " if buy else "قريب من مقاومة عند ") + f"{sr['p']:.6g}")

    if a15["ev"]:
        ev = a15["ev"][-1]
        if ev["up"]==buy and ev["j"] >= a15["len"]-40: sc += 10; R.append(("CHoCH " if ev["k"]=="CHoCH" else "BOS ") + ("صاعد" if buy else "هابط"))

    last = a15["last"]
    if (buy and last["close"] > last["open"]) or ((not buy) and last["close"] < last["open"]): sc += 5; confirm = True; R.append("شمعة تأكيد " + ("صاعدة" if buy else "هابطة"))
    return {"score":min(100, sc), "reasons":R, "zone":zone, "confirm":confirm}

def compute_levels(a, side, entry, cfg):
    buy = side == "BUY"; below, above = [], []
    for x in a["z"]: (below if x["t"]=="L" else above).append(x["p"])
    for z in a["ob"]: (below if z["s"]=="bull" else above).append(z["bot"] if z["s"]=="bull" else z["top"])
    for z in a["sd"]: (below if z["s"]=="bull" else above).append(z["bot"] if z["s"]=="bull" else z["top"])
    for x in a["sr"]: (below if x["t"]=="L" else above).append(x["p"])

    if buy:
        cands = [v for v in below if v < entry*.9999]; sw = max(cands) if cands else entry*.99
        sl = sw*.9985
        if sl >= entry: sl = entry*.99
    else:
        cands = [v for v in above if v > entry*1.0001]; sw = min(cands) if cands else entry*1.01
        sl = sw*1.0015
        if sl <= entry: sl = entry*1.01

    fib = a.get("fib"); tp = None
    if fib and fib["dir"] == ("up" if buy else "down"): tp = fib["hi"] if buy else fib["lo"]
    min_rr = max(2.0, float(cfg.get("rr", 2.0)))
    need = entry + (1 if buy else -1) * abs(entry - sl) * min_rr
    if tp is None or (buy and tp < need) or ((not buy) and tp > need): tp = need
    return {"entry":entry, "sl":sl, "tp":tp, "rr":round(abs(tp - entry) / max(1e-12, abs(entry - sl)), 2)}

def build_signal(symbol, a4, a1, a15, cfg):
    ctime = int(a15["last"].get("time", 0))
    out = {"symbol":symbol, "sym":symbol, "t4":a4["trend"], "t1":a1["trend"], "t15":a15["trend"],
           "status":"none", "side":None, "reasons":[], "score":0, "tf":"15M", "rr":cfg.get("rr", 2.0), "time":ctime, "candle_time":ctime}
    if not cfg.get("engine_enabled", True): out["reasons"].append("التحليل متوقف"); return out
    if a4["trend"]=="side" or a4["trend"] != a1["trend"]: out["reasons"].append("اتجاها 4H و1H غير متوافقين"); return out
    buy = a4["trend"] == "up"; side = "BUY" if buy else "SELL"; out["side"] = side
    sc = score_setup(a4, a1, a15, side, cfg); out["score"] = sc["score"]; out["reasons"] = sc["reasons"]
    if not sc["zone"]: out["status"] = "watch"; return out
    out.update(compute_levels(a15, side, a15["price"], cfg))
    if sc["score"] >= int(cfg.get("min_score", 80)) and sc["confirm"]: out["status"] = "signal"
    else:
        out["status"] = "wait"
        if sc["score"] < int(cfg.get("min_score", 80)): out["reasons"].append(f"قوة الإشارة {sc['score']} أقل من {cfg.get('min_score')}")
    return out

# ═══════════════════════════════════════════════════════════════════════
# 7) WebSockets
# ═══════════════════════════════════════════════════════════════════════
WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
def ws_accept(key): return base64.b64encode(hashlib.sha1((key + WS_GUID).encode()).digest()).decode()

class WSConn:
    def __init__(self, rfile, wfile):
        self.rfile = rfile; self.wfile = wfile; self.lock = threading.Lock(); self.closed = False
    def send_text(self, text):
        if self.closed: return False
        try:
            data = text.encode("utf-8"); n = len(data); frame = bytearray([0x81])
            if n < 126: frame.append(n)
            elif n < 65536: frame.append(126); frame.extend(struct.pack(">H", n))
            else: frame.append(127); frame.extend(struct.pack(">Q", n))
            with self.lock: self.wfile.write(bytes(frame) + data); self.wfile.flush()
            return True
        except Exception: self.closed = True; return False
    def recv_frame(self):
        try:
            b1 = self.rfile.read(1); b2 = self.rfile.read(1)
            if not b1 or not b2: return None
            opcode = b1[0] & 0x0F; masked = (b2[0] & 0x80) != 0; length = b2[0] & 0x7F
            if length == 126: length = struct.unpack(">H", self.rfile.read(2))[0]
            elif length == 127: length = struct.unpack(">Q", self.rfile.read(8))[0]
            mask = self.rfile.read(4) if masked else b"\x00\x00\x00\x00"
            payload = self.rfile.read(length) if length else b""
            if masked: payload = bytes(b ^ mask[i%4] for i, b in enumerate(payload))
            return opcode, payload
        except Exception: return None
    def close(self): self.closed = True

class WSHub:
    def __init__(self): self.clients = []; self.lock = threading.Lock()
    def add(self, ws):
        with self.lock: self.clients.append(ws)
    def remove(self, ws):
        with self.lock:
            if ws in self.clients: self.clients.remove(ws)
    def broadcast(self, msg):
        data = json.dumps(msg, ensure_ascii=False, default=str)
        with self.lock:
            dead = [ws for ws in self.clients if not ws.send_text(data)]
            for d in dead: self.clients.remove(d)
    def count(self):
        with self.lock: return len(self.clients)

hub_market = WSHub()
hub_signals = WSHub()

# ═══════════════════════════════════════════════════════════════════════
# 8) Engine (Price & Analysis Threads)
# ═══════════════════════════════════════════════════════════════════════
class Engine:
    def __init__(self):
        self.running = False; self.thread = None; self.last_cycle = None
        self.active_coins = []; self.prices = {}; self.candles = {}; self.price_stream_ok = False

    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        # خيط مستقل ومستمر لتحديث الأسعار كل 3 ثوانٍ (لحل مشكلة التجميد)
        threading.Thread(target=self._price_loop, daemon=True).start()

    def _price_loop(self):
        while self.running:
            try:
                self._refresh_prices()
                self._broadcast_prices()
            except Exception:
                pass
            time.sleep(3)

    def _loop(self):
        time.sleep(2)
        while self.running:
            t0 = time.time()
            try: self._cycle()
            except Exception: traceback.print_exc()
            elapsed = time.time() - t0
            time.sleep(max(2, 20 - elapsed))

    def _cycle(self):
        with db_conn() as c:
            rows = c.execute("SELECT symbol FROM coins WHERE active=1").fetchall()
        if not rows:
            self._seed_coins()
            with db_conn() as c:
                rows = c.execute("SELECT symbol FROM coins WHERE active=1").fetchall()
        self.active_coins = [r["symbol"] for r in rows]

        # التحليل فقط، لأن الأسعار لها خيط مستقل
        cfg = load_cfg()
        if cfg.get("engine_enabled"):
            for sym in self.active_coins:
                try: self._analyze_and_signal(sym, cfg)
                except Exception: traceback.print_exc()
        self.last_cycle = datetime.now(timezone.utc).isoformat(timespec="seconds")

    def _seed_coins(self):
        log("seeding coins…")
        data = fetch_json(CFG.FAPI + "/fapi/v1/ticker/24hr", timeout=20)
        if not data: return
        rows = []
        for t in data:
            sym = t.get("symbol","")
            if not sym.endswith("USDT"): continue
            base = sym[:-4]
            if base in CFG.EXCLUDE_BASES: continue
            try: rows.append({"symbol":sym,"base":base,"volume":float(t["quoteVolume"])})
            except Exception: continue
        rows.sort(key=lambda x: x["volume"], reverse=True)
        with db_conn() as c:
            for r in rows[:CFG.TOP_N]:
                c.execute("INSERT OR IGNORE INTO coins (symbol,base,active) VALUES (?,?,1)", (r["symbol"], r["base"]))
        log(f"seeded {len(rows[:CFG.TOP_N])} coins")

    def _refresh_prices(self):
        data = fetch_json(CFG.FAPI + "/fapi/v1/ticker/24hr", timeout=10)
        if not data: return
        wanted = set(self.active_coins) if self.active_coins else None
        now = time.time()
        for t in data:
            sym = t.get("symbol","")
            if wanted is not None and sym not in wanted: continue
            try:
                self.prices[sym] = {"price":float(t["lastPrice"]), "change":float(t["priceChangePercent"]), "volume":float(t["quoteVolume"]), "ts":now}
            except Exception: continue
        self.price_stream_ok = True

    def _broadcast_prices(self):
        if not self.prices: return
        hub_market.broadcast({"type":"prices", "data":{s:[p["price"], p["change"], p["volume"]] for s,p in self.prices.items()}})

    def get_klines(self, symbol, tf, limit=500, start_ms=None):
        btf = TF_TO_BINANCE.get(tf, "15m"); key = f"{symbol}|{tf}"
        ttl = {"15M":45,"30M":90,"1H":300,"4H":1200,"5M":30,"1D":3000,"1W":3000}.get(tf, 60)
        cached = self.candles.get(key)
        if cached and (time.time() - cached["ts"]) < ttl and not start_ms: return cached["data"]
        params = {"symbol":symbol, "interval":btf, "limit":min(1500, limit+5)}
        if start_ms: params["startTime"] = int(start_ms)
        raw = fetch_json(CFG.FAPI + "/fapi/v1/klines?" + urlencode(params), timeout=20)
        if not raw: return cached["data"] if cached else []
        candles = [{"time":int(k[0])//1000, "open":float(k[1]), "high":float(k[2]), "low":float(k[3]), "close":float(k[4]), "vol":float(k[5])} for k in raw]
        if candles:
            tf_sec = TF_SECONDS.get(tf, 900)
            if candles[-1]["time"] + tf_sec > time.time(): candles = candles[:-1]
        if not start_ms: self.candles[key] = {"ts":time.time(), "data":candles}
        return candles

    def _analyze_and_signal(self, sym, cfg):
        c15 = self.get_klines(sym, "15M", limit=400)
        if len(c15) < 120: return
        c1h = self.get_klines(sym, "1H", limit=400); c4h = self.get_klines(sym, "4H", limit=400)
        if len(c1h) < 80 or len(c4h) < 80: return

        a15, a1h, a4h = analyze(c15, cfg["zigzag_n"]), analyze(c1h, cfg["zigzag_n"]), analyze(c4h, cfg["zigzag_n"])
        sig = build_signal(sym, a4h, a1h, a15, cfg)
        self._update_active_signals(sym, c15[-1])

        if sig.get("status") != "signal": return
        ctime = sig["candle_time"]
        with db_conn() as c:
            if c.execute("SELECT id FROM signals WHERE symbol=? AND side=? AND candle_time=?", (sym, sig["side"], ctime)).fetchone(): return
            cur = c.execute("INSERT INTO signals (symbol,side,status,entry,sl,tp,rr,score,reasons,t4,t1,t15,tf,candle_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (sym, sig["side"], "active", sig["entry"], sig["sl"], sig["tp"], sig["rr"], sig["score"], json.dumps(sig["reasons"], ensure_ascii=False), sig["t4"], sig["t1"], sig["t15"], "15M", ctime))
            sid = cur.lastrowid
        payload = {"id":sid, "symbol":sym, "side":sig["side"], "status":"active", "entry":sig["entry"], "sl":sig["sl"], "tp":sig["tp"], "rr":sig["rr"], "score":sig["score"], "reasons":sig["reasons"], "t4":sig["t4"], "t1":sig["t1"], "t15":sig["t15"], "tf":"15M", "time":ctime, "candle_time":ctime}
        log(f"NEW SIGNAL {sym} {sig['side']} score={sig['score']}")
        hub_signals.broadcast({"type":"signal", "signal":payload})
        if tg.enabled: threading.Thread(target=self._send_tg_signal, args=(payload,), daemon=True).start()

    def _send_tg_signal(self, payload):
        try:
            text = f"🚀 <b>RAHIB TRADING PRO</b>\n\n🪙 العملة: <b>{payload['symbol']}</b>\n📊 نوع الصفقة: <b>{'شراء' if payload['side']=='BUY' else 'بيع'}</b>\n💰 سعر الدخول: <code>{payload['entry']:.6g}</code>\n🛑 Stop Loss: <code>{payload['sl']:.6g}</code>\n🎯 Take Profit: <code>{payload['tp']:.6g}</code>\n⭐ قوة الإشارة: <b>{payload['score']}/100</b>"
            if tg.send_message(text):
                with db_conn() as c: c.execute("UPDATE signals SET telegram_sent=1 WHERE id=?", (payload["id"],))
        except Exception: pass

    def _update_active_signals(self, sym, last_candle):
        to_update = []
        with db_conn() as c:
            for s in c.execute("SELECT * FROM signals WHERE symbol=? AND status='active'", (sym,)).fetchall():
                if s["side"]=="BUY":
                    if last_candle["low"] <= s["sl"]: to_update.append(("sl", s["sl"], s["id"]))
                    elif last_candle["high"] >= s["tp"]: to_update.append(("tp", s["tp"], s["id"]))
                else:
                    if last_candle["high"] >= s["sl"]: to_update.append(("sl", s["sl"], s["id"]))
                    elif last_candle["low"] <= s["tp"]: to_update.append(("tp", s["tp"], s["id"]))
            for st, px, sid in to_update:
                c.execute("UPDATE signals SET status=?, exit_price=?, exit_time=? WHERE id=?", (st, px, int(last_candle["time"]), sid))
        for st, px, sid in to_update:
            with db_conn() as c: s = c.execute("SELECT * FROM signals WHERE id=?", (sid,)).fetchone()
            if s:
                payload = dict(s); payload["reasons"] = json.loads(payload["reasons"] or "[]"); payload["time"] = payload["candle_time"]
                hub_signals.broadcast({"type":"update", "signal":payload})

engine = Engine()

# ═══════════════════════════════════════════════════════════════════════
# 9) Backtest
# ═══════════════════════════════════════════════════════════════════════
_HIST_CACHE = {}
def _slice_closed(arr, t, tf_sec, max_len=220):
    lo, hi = 0, len(arr)
    while lo < hi:
        m = (lo + hi) // 2
        if arr[m]["time"] + tf_sec <= t: lo = m + 1
        else: hi = m
    return arr[max(0, lo - max_len):lo]

def compute_history(symbol, c15, cfg, c1h, c4h):
    signals = []; start = max(150, len(c15) - 600); cool = -1
    for i in range(start, len(c15) - 1):
        if i < cool: continue
        window = c15[max(0, i-179):i+1]; a15 = analyze(window, cfg["zigzag_n"]); t = c15[i]["time"]
        w4 = _slice_closed(c4h, t, TF_SECONDS["4H"]); w1 = _slice_closed(c1h, t, TF_SECONDS["1H"])
        if len(w4) < 80 or len(w1) < 80: continue
        sig = build_signal(symbol, analyze(w4, cfg["zigzag_n"]), analyze(w1, cfg["zigzag_n"]), a15, cfg)
        if sig.get("status") != "signal": continue
        buy = sig["side"]=="BUY"; result = "open"; j = None
        for k in range(i+1, len(c15)):
            x = c15[k]
            if buy and x["low"] <= sig["sl"]: result="sl"; j=k; break
            if (not buy) and x["high"] >= sig["sl"]: result="sl"; j=k; break
            if buy and x["high"] >= sig["tp"]: result="tp"; j=k; break
            if (not buy) and x["low"] <= sig["tp"]: result="tp"; j=k; break
        signals.append({"time":t, "i":i, "j":j, "side":sig["side"], "entry":sig["entry"], "sl":sig["sl"], "tp":sig["tp"], "score":sig["score"], "result":result, "tf":"15M"}); cool = i + 10
    closed = [s for s in signals if s["result"] in ("tp","sl")]; wins = sum(1 for s in closed if s["result"]=="tp")
    fee = float(cfg.get("fee_pct", 0.04)); slip = float(cfg.get("slippage_pct", 0.02)); net = 0.0; returns = []; equity = 0.0; peak = 0.0; max_dd = 0.0
    for s in closed:
        rr = abs(s["tp"]-s["entry"]) / max(1e-12, abs(s["entry"]-s["sl"]))
        r = (rr if s["result"]=="tp" else -1.0) - (fee+slip)/100.0*2
        returns.append(r*100); equity += r*100; peak = max(peak, equity); max_dd = max(max_dd, peak - equity); net += r*100
    return {"signals":signals, "metrics":{"trades":len(signals), "wins":wins, "losses":len(closed)-wins, "win_rate":round(wins/len(closed)*100,2) if closed else 0, "net_pnl_pct":round(net,2), "max_drawdown_pct":round(max_dd,2), "avg_return_pct":round(sum(returns)/len(returns),2) if returns else 0, "fee_pct":fee, "slippage_pct":slip}}

# ═══════════════════════════════════════════════════════════════════════
# 10) HTTP Handler
# ═══════════════════════════════════════════════════════════════════════
class HTTPError(Exception):
    def __init__(self, status, detail): self.status = status; self.detail = detail

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, fmt, *args): pass

    def _write(self, status, body, ctype="application/json"):
        if isinstance(body, (dict, list)): body = json.dumps(body, ensure_ascii=False, default=str)
        if isinstance(body, str): body = body.encode("utf-8")
        try:
            self.send_response(status); self.send_header("Content-Type", ctype + "; charset=utf-8")
            self.send_header("Content-Length", str(len(body))); self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers", "*"); self.send_header("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS"); self.end_headers(); self.wfile.write(body)
        except Exception: pass

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length", "0"))
            return json.loads(self.rfile.read(n).decode("utf-8")) if n > 0 else {}
        except Exception: return {}

    def _auth(self):
        h = self.headers.get("Authorization","")
        return decode_jwt(h.split(" ",1)[1].strip()) if h.lower().startswith("bearer ") else None

    def _current_user(self):
        p = self._auth()
        if not p: return None
        with db_conn() as c: r = c.execute("SELECT id,username,role FROM users WHERE id=?", (int(p.get("sub",0)),)).fetchone()
        return dict(r) if r else None

    def _require_admin(self):
        u = self._current_user()
        if not u or u["role"] != "admin": raise HTTPError(403, "صلاحيات المدير مطلوبة")
        return u

    def do_OPTIONS(self): self._write(204, b"", "text/plain")
    def do_GET(self): self._safe("GET")
    def do_POST(self): self._safe("POST")
    def do_DELETE(self): self._safe("DELETE")

    def _safe(self, method):
        path = self.path.split("?")[0]
        if method == "GET" and path in ("/ws/market", "/ws/signals"): return self._handle_ws(path)
        try: self._route(method, path)
        except HTTPError as e: self._write(e.status, {"detail": e.detail})
        except Exception as e:
            traceback.print_exc(); self._write(500, {"detail": str(e)})

    def _route(self, method, path):
        q = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
        if path == "/api/health": return self._write(200, {"ok": True, "time": int(time.time())})
        if path == "/api/coins" and method == "GET": return self._coins()
        if path == "/api/coins" and method == "POST": return self._coin_add()
        if path.startswith("/api/coins/") and method == "GET": return self._coin_one(path.split("/",3)[3])
        if path.startswith("/api/coins/") and method == "DELETE": return self._coin_del(path.split("/",3)[3])
        if path.startswith("/api/chart/"): return self._chart(path.split("/",3)[3], q.get("tf","15M"), int(q.get("limit",500)))
        if path.startswith("/api/analysis/"): return self._analysis(path.split("/",3)[3], q.get("tf","15M"), int(q.get("limit",600)), int(q["start"]) if q.get("start") else None)
        if path.startswith("/api/history/"): return self._history(path.split("/",3)[3], int(q.get("bars",1500)))
        if path == "/api/signals": return self._signals(int(q.get("limit",100)))
        if path == "/api/trades": return self._trades(int(q.get("limit",40)))
        if path == "/api/backtest" and method == "POST": return self._backtest()
        if path == "/api/users/login" and method == "POST": return self._login()
        if path == "/api/users/register" and method == "POST": return self._register()
        if path == "/api/users/me": return self._me()
        if path == "/api/settings" and method == "GET": return self._write(200, load_cfg())
        if path == "/api/settings" and method == "POST": return self._save_settings()
        if path == "/api/telegram" and method == "GET": return self._tg_get()
        if path == "/api/telegram/config" and method == "POST": return self._tg_cfg()
        if path == "/api/telegram/test" and method == "POST": return self._tg_test()
        if path == "/api/admin/status": return self._admin_status()
        if path == "/api/admin/errors": return self._write(200, {"errors": []})
        if method == "GET": return self._static(path)
        self._write(404, {"detail":"not found"})

    def _handle_ws(self, path):
        if self.headers.get("Upgrade","").lower() != "websocket": return self._write(400, {"detail":"expected websocket"})
        key = self.headers.get("Sec-WebSocket-Key","")
        try:
            self.send_response(101, "Switching Protocols"); self.send_header("Upgrade", "websocket"); self.send_header("Connection", "Upgrade"); self.send_header("Sec-WebSocket-Accept", ws_accept(key)); self.end_headers()
        except Exception: return
        ws = WSConn(self.rfile, self.wfile); hub = hub_market if path == "/ws/market" else hub_signals; hub.add(ws)
        try:
            if path == "/ws/market" and engine.prices: ws.send_text(json.dumps({"type":"prices","data":{s:[p["price"], p["change"], p["volume"]] for s,p in engine.prices.items()}}, ensure_ascii=False))
            while not ws.closed:
                f = ws.recv_frame()
                if f is None or f[0] == 0x8: break
                if f[0] == 0x9: ws.send_text("pong")
        except Exception: pass
        finally: hub.remove(ws); ws.close()

    def _coins(self):
        with db_conn() as c: rows = c.execute("SELECT symbol,base FROM coins WHERE active=1").fetchall()
        out = []
        for r in rows:
            p = engine.prices.get(r["symbol"])
            if not p: continue
            with db_conn() as c: s = c.execute("SELECT t4,t1,status FROM signals WHERE symbol=? ORDER BY created_at DESC LIMIT 1", (r["symbol"],)).fetchone()
            out.append({"symbol":r["symbol"], "base":r["base"], "price":p["price"], "change":p["change"], "volume":p["volume"], "t4": s["t4"] if s else "side", "t1": s["t1"] if s else "side", "status": s["status"] if s else "none"})
        out.sort(key=lambda x: x["volume"], reverse=True)
        self._write(200, {"coins": out})

    def _coin_one(self, sym):
        with db_conn() as c: r = c.execute("SELECT * FROM coins WHERE symbol=?", (sym.upper(),)).fetchone()
        if not r: raise HTTPError(404, "العملة غير موجودة")
        p = engine.prices.get(sym.upper(), {}); self._write(200, {"symbol":sym.upper(), "base":r["base"], "price":p.get("price"), "change":p.get("change"), "volume":p.get("volume")})

    def _coin_add(self):
        self._require_admin(); sym = (self._body().get("symbol","")).upper().strip()
        if not sym.endswith("USDT"): sym += "USDT"
        with db_conn() as c:
            if c.execute("SELECT id FROM coins WHERE symbol=?", (sym,)).fetchone(): c.execute("UPDATE coins SET active=1 WHERE symbol=?", (sym,))
            else: c.execute("INSERT INTO coins (symbol,base,active) VALUES (?,?,1)", (sym, sym[:-4]))
        self._write(200, {"ok":True})

    def _coin_del(self, sym):
        self._require_admin()
        with db_conn() as c: c.execute("UPDATE coins SET active=0 WHERE symbol=?", (sym.upper(),))
        self._write(200, {"ok":True})

    def _chart(self, sym, tf, limit):
        limit = max(50, min(1500, limit)); self._write(200, {"symbol":sym.upper(), "tf":tf, "candles":engine.get_klines(sym.upper(), tf, limit=limit)})

    def _analysis(self, sym, tf, limit, start):
        sym = sym.upper(); limit = max(120, min(1500, limit)); cfg = load_cfg()
        start_ms = start * 1000 if (start and start < 10**10) else start
        c = engine.get_klines(sym, tf, limit=limit, start_ms=start_ms)
        if not c: raise HTTPError(404, "لا توجد بيانات")
        a = analyze(c, cfg.get("zigzag_n",4)); c4h = engine.get_klines(sym, "4H", limit=400); c1h = engine.get_klines(sym, "1H", limit=400)
        a4 = analyze(c4h, cfg["zigzag_n"]) if c4h else {"trend":"side"}; a1 = analyze(c1h, cfg["zigzag_n"]) if c1h else {"trend":"side"}
        sig = build_signal(sym, a4, a1, a, cfg)
        self._write(200, {"candles":c, "analysis":a, "signal":sig})

    def _history(self, sym, bars):
        sym = sym.upper(); bars = max(300, min(3000, bars))
        cached = _HIST_CACHE.get(sym)
        if cached and time.time() - cached["ts"] < 300: return self._write(200, {"signals": cached["signals"], "metrics": cached["metrics"]})
        cfg = load_cfg(); c15 = engine.get_klines(sym, "15M", limit=bars); c1h = engine.get_klines(sym, "1H", limit=1500); c4h = engine.get_klines(sym, "4H", limit=1500)
        if not c15 or not c1h or not c4h: raise HTTPError(404, "بيانات غير كافية")
        res = compute_history(sym, c15, cfg, c1h, c4h)
        _HIST_CACHE[sym] = {"ts":time.time(), "signals":res["signals"], "metrics":res["metrics"]}
        self._write(200, {"signals":res["signals"], "metrics":res["metrics"]})

    def _signals(self, limit):
        with db_conn() as c: rows = c.execute("SELECT * FROM signals ORDER BY created_at DESC LIMIT ?", (max(1, min(500, limit)),)).fetchall()
        out = []
        for s in rows:
            try: reasons = json.loads(s["reasons"] or "[]")
            except Exception: reasons = []
            out.append({"id":s["id"], "symbol":s["symbol"], "side":s["side"], "status":s["status"], "entry":s["entry"], "sl":s["sl"], "tp":s["tp"], "rr":s["rr"], "score":s["score"], "reasons":reasons, "t4":s["t4"], "t1":s["t1"], "t15":s["t15"], "tf":s["tf"], "time":s["candle_time"], "candle_time":s["candle_time"], "exit_price":s["exit_price"]})
        self._write(200, {"signals": out})

    def _trades(self, limit):
        with db_conn() as c:
            rows = c.execute("SELECT * FROM trades ORDER BY opened_at DESC LIMIT ?", (max(1, min(200, limit)),)).fetchall()
            total = c.execute("SELECT COUNT(*) as n FROM trades").fetchone()["n"]; opens = c.execute("SELECT COUNT(*) as n FROM trades WHERE status='open'").fetchone()["n"]
            closes = c.execute("SELECT pnl_pct FROM trades WHERE status!='open'").fetchall()
        wins = sum(1 for t in closes if (t["pnl_pct"] or 0) > 0); losses = sum(1 for t in closes if (t["pnl_pct"] or 0) < 0)
        out = [{"id":t["id"], "symbol":t["symbol"], "side":t["side"], "entry":t["entry"], "sl":t["sl"], "tp":t["tp"], "status":t["status"], "pnl_pct":t["pnl_pct"], "opened_at":t["opened_at"], "closed_at":t["closed_at"]} for t in rows]
        self._write(200, {"trades":out, "stats":{"total":total, "open":opens, "wins":wins, "losses":losses, "win_rate":round(wins/len(closes)*100,2) if closes else 0, "net_pct":round(sum((t["pnl_pct"] or 0) for t in closes),2)}})

    def _backtest(self):
        u = self._current_user()
        if not u: raise HTTPError(401, "تسجيل الدخول مطلوب")
        body = self._body(); sym = (body.get("symbol") or "").upper(); bars = max(300, min(3000, int(body.get("bars", 1500))))
        cfg = load_cfg(); c15 = engine.get_klines(sym, "15M", limit=bars); c1h = engine.get_klines(sym, "1H", limit=1500); c4h = engine.get_klines(sym, "4H", limit=1500)
        if not c15 or not c1h or not c4h: raise HTTPError(404, "بيانات غير كافية")
        res = compute_history(sym, c15, cfg, c1h, c4h); self._write(200, {"metrics":res["metrics"], "signals":res["signals"]})

    def _login(self):
        body = self._body()
        with db_conn() as c: r = c.execute("SELECT * FROM users WHERE username=?", ((body.get("username") or "").strip(),)).fetchone()
        if not r or not verify_password(body.get("password") or "", r["password_hash"]): raise HTTPError(401, "بيانات دخول غير صحيحة")
        self._write(200, {"token": create_jwt({"sub":str(r["id"]), "usr":r["username"], "role":r["role"]})})

    def _register(self):
        body = self._body(); u = (body.get("username") or "").strip(); p = body.get("password") or ""
        if len(u) < 3 or len(p) < 8: raise HTTPError(400, "الاسم ≥ 3 وكلمة المرور ≥ 8")
        with db_conn() as c:
            if c.execute("SELECT id FROM users WHERE username=?", (u,)).fetchone(): raise HTTPError(400, "الاسم مستخدم مسبقاً")
            c.execute("INSERT INTO users (username,password_hash,role) VALUES (?,?, 'user')", (u, hash_password(p)))
            r = c.execute("SELECT id,role FROM users WHERE username=?", (u,)).fetchone()
        self._write(200, {"token": create_jwt({"sub":str(r["id"]), "usr":u, "role":r["role"]})})

    def _me(self):
        u = self._current_user()
        if not u: raise HTTPError(401, "غير مصادق")
        self._write(200, u)

    def _save_settings(self):
        self._require_admin(); b = self._body()
        fields = ["engine_enabled","strategy_enabled","min_score","rr","risk_pct","max_risk_pct","zigzag_n","fee_pct","slippage_pct"]
        sets, vals = [], []
        for f in fields:
            if f in b and b[f] is not None: sets.append(f"{f}=?"); vals.append(int(b[f]) if isinstance(b[f], bool) else b[f])
        if sets:
            with db_conn() as c: c.execute(f"UPDATE strategy_settings SET {','.join(sets)} WHERE id=1", vals)
        self._write(200, {"ok":True, "settings": load_cfg()})

    def _tg_get(self):
        self._require_admin(); t = load_tg(); tok = t["token"]
        hint = (tok[:6] + "…" + tok[-4:]) if len(tok) >= 12 else ("*"*len(tok) if tok else "")
        self._write(200, {"token_set":bool(tok), "token_hint":hint, "chat_id":t["chat_id"], "enabled":t["enabled"]})

    def _tg_cfg(self):
        self._require_admin(); b = self._body()
        with db_conn() as c:
            if "token" in b and b["token"] is not None: c.execute("UPDATE telegram_settings SET token=? WHERE id=1", (b["token"].strip(),))
            if "chat_id" in b and b["chat_id"] is not None: c.execute("UPDATE telegram_settings SET chat_id=? WHERE id=1", (b["chat_id"].strip(),))
            if "enabled" in b and b["enabled"] is not None: c.execute("UPDATE telegram_settings SET enabled=? WHERE id=1", (int(bool(b["enabled"])),))
        t = load_tg(); tg.configure(t["token"], t["chat_id"], t["enabled"]); self._write(200, {"ok":True})

    def _tg_test(self):
        self._require_admin()
        if tg.test(): self._write(200, {"message":"تم ربط Telegram بنجاح"})
        else: raise HTTPError(400, "فشل الاتصال بـ Telegram")

    def _admin_status(self):
        self._require_admin()
        try:
            import resource
            mem_mb = round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1)
        except Exception: mem_mb = None
        with db_conn() as c:
            users_c = c.execute("SELECT COUNT(*) as n FROM users").fetchone()["n"]
            sigs_c = c.execute("SELECT COUNT(*) as n FROM signals").fetchone()["n"]
            open_c = c.execute("SELECT COUNT(*) as n FROM signals WHERE status='active'").fetchone()["n"]
        self._write(200, {"engine_running": engine.running, "price_stream": engine.price_stream_ok, "watching": len(engine.active_coins), "last_cycle": engine.last_cycle, "uptime_s": int(time.time() - CFG.START_TS), "ws_clients": {"market": hub_market.count(), "signals": hub_signals.count()}, "memory_mb": mem_mb, "load_avg": None, "database": "sqlite", "counts": {"users": users_c, "signals": sigs_c, "open_trades": open_c}})

    def _static(self, path):
        if path == "/" or not path: path = "/index.html"
        p = path.lstrip("/")
        if ".." in p: raise HTTPError(403, "forbidden")
        fp = os.path.join(CFG.STATIC_DIR, p)
        if not os.path.isfile(fp): raise HTTPError(404, "not found")
        try:
            with open(fp, "rb") as f: data = f.read()
            ctype, _ = guess_type(fp); self._write(200, data, ctype or "application/octet-stream")
        except Exception as e: raise HTTPError(500, str(e))

# ═══════════════════════════════════════════════════════════════════════
# 11) Main
# ═══════════════════════════════════════════════════════════════════════
def main():
    init_db()
    t = load_tg(); tg.configure(t["token"], t["chat_id"], t["enabled"])
    try:
        with db_conn() as c:
            if not c.execute("SELECT 1 FROM coins WHERE active=1 LIMIT 1").fetchone(): engine._seed_coins()
    except Exception: traceback.print_exc()
    engine.start()

    host = os.getenv("HOST", "0.0.0.0"); port = int(os.getenv("PORT", "8000"))
    srv = ThreadingHTTPServer((host, port), Handler); srv.daemon_threads = True

    log("═" * 55); log(f"RAHIB TRADING PRO — Server ready")
    log(f"Open:  http://127.0.0.1:{port}"); log(f"Static: {os.path.abspath(CFG.STATIC_DIR)}")
    log(f"Admin: {CFG.ADMIN_USER} / {CFG.ADMIN_PASS}"); log("═" * 55)

    try: srv.serve_forever()
    except KeyboardInterrupt:
        log("shutting down…"); engine.stop(); srv.shutdown()

if __name__ == "__main__":
    main()