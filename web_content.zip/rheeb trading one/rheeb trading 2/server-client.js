/* RAHIB TRADING PRO - server link (phase 2).
   Loaded after the original app. If the server answers, prices, candles, analysis, signals and
   trades come from it (REST + WebSocket); otherwise the original local simulation keeps working. */
(() => {
const base = () => (S.api || location.origin).replace(/\/+$/, '');
const Srv = { on: false, token: null, user: null, ws: null, ws2: null, busy: false, prep: false, maxed: false, hist: null, list: [], tc: null };
try { Srv.token = localStorage.getItem('rahib_tok'); } catch (e) {}
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const saveTok = t => { Srv.token = t; try { t ? localStorage.setItem('rahib_tok', t) : localStorage.removeItem('rahib_tok'); } catch (e) {} };

async function j(path, opt = {}) {
  const h = { 'Content-Type': 'application/json' };
  if (Srv.token) h.Authorization = 'Bearer ' + Srv.token;
  const r = await fetch(base() + path, { ...opt, headers: h });
  let d = null;
  try { d = await r.json(); } catch (e) {}
  if (!r.ok) throw new Error(d && typeof d.detail === 'string' ? d.detail : 'HTTP ' + r.status);
  if (d === null) throw new Error('رد غير صالح من السيرفر');
  return d;
}

/* header badge + toast */
const badge = document.createElement('span');
badge.className = 'tag'; badge.textContent = 'محاكاة';
$('#theme').before(badge);
const setMode = (on, txt) => { badge.textContent = txt || (on ? 'مباشر · Binance' : 'محاكاة'); badge.className = 'tag ' + (on ? 'up' : ''); };
function toast(t) {
  const d = document.createElement('div');
  d.textContent = t;
  d.style.cssText = 'position:fixed;inset-inline:16px;bottom:calc(88px + env(safe-area-inset-bottom,0px));z-index:50;background:var(--card);border:1px solid var(--blue);border-radius:14px;padding:12px 14px;box-shadow:var(--sh);text-align:center';
  document.body.appendChild(d); setTimeout(() => d.remove(), 5000);
}

/* ---------- connection ---------- */
const mapCoin = c => ({ sym: c.symbol, base: c.base, price: c.price, chg: c.change, vol: c.volume, sig: { t4: c.t4, t1: c.t1, status: c.status } });
async function refreshCoins() {
  const d = await j('/api/coins');
  if (!d.coins || !d.coins.length) throw new Error('empty');
  Data.tickers = d.coins.map(mapCoin);
}
function connect(path, onmsg, key) {
  let delay = 1000;
  const open = () => {
    const w = new WebSocket(base().replace(/^http/, 'ws') + path + (Srv.token ? '?token=' + encodeURIComponent(Srv.token) : ''));
    Srv[key] = w;
    w.onmessage = e => { try { onmsg(JSON.parse(e.data)); } catch (_) {} };
    w.onopen = () => { delay = 1000; setMode(true); refreshCoins().catch(() => {}); };
    w.onclose = () => { if (!Srv.on || Srv[key] !== w) return; setMode(false, 'إعادة الاتصال…'); setTimeout(open, delay); delay = Math.min(delay * 2, 15000); };
  };
  open();
}
function onPrices(d) {
  const now = Date.now() / 1000;
  for (const s in d) { const t = Data.t(s); if (t) { t.price = d[s][0]; t.chg = d[s][1]; t.vol = d[s][2]; } }
  const c = cur.c, t = Data.t(S.sym);
  if (Srv.on && c && c.length && t && S.page === 'chart') {
    const st = TFS[S.tf], l = c[c.length - 1];
    if (now >= l.time + st) c.push({ time: Math.floor(now / st) * st, open: l.close, high: t.price, low: t.price, close: t.price, vol: 0 });
    else { l.close = t.price; l.high = Math.max(l.high, t.price); l.low = Math.min(l.low, t.price); }
  }
}
function onSignal(m) {
  if (!m.signal) return;
  const s = m.signal, t = Data.t(s.symbol);
  if (m.type === 'signal') { toast('إشارة ' + (s.side === 'BUY' ? 'شراء' : 'بيع') + ' جديدة: ' + s.symbol); if (t) t.sig = { ...(t.sig || {}), status: 'signal' }; }
  else toast(s.symbol + ': ' + ({ tp: 'تحقق الهدف', sl: 'ضربت وقف الخسارة', cancelled: 'أُلغيت الإشارة' }[s.status] || 'تحديث'));
  if (S.page === 'sig') Srv.renderSigs();
  Srv.tc = null;
}
async function init() {
  try {
    await refreshCoins();
    Srv.on = true; Data.cache = {}; cur.c = null;
    OVL.sig = 'إشارات تاريخية'; S.ovl.sig = 1;
    $('#ovs').innerHTML = Object.entries(OVL).map(([k, v]) => `<button class="chip" data-o="${k}">${v}</button>`).join('');
    setMode(true);
    if (Srv.token) { try { Srv.user = await j('/api/users/me'); } catch (e) { saveTok(null); } }
    renderAuth();
    if (S.page === 'chart') loadChart(true); else go(S.page);
    connect('/ws/market', m => { if (m.type === 'prices') onPrices(m.data); }, 'ws');
    connect('/ws/signals', onSignal, 'ws2');
  } catch (e) {
    Srv.on = false; setMode(false);
    setTimeout(init, 45000);  // server not reachable yet: stay on the local simulation and retry
  }
}
setInterval(() => [Srv.ws, Srv.ws2].forEach(w => w && w.readyState === 1 && w.send('ping')), 25000);
setInterval(() => { if (Srv.on) refreshCoins().catch(() => {}); }, 60000);

/* ---------- chart ---------- */
function applyMarkers() {
  const c = cur.c, A = cur.an;
  if (!c || !A) return;
  const m = [];
  if (S.ovl.bos) A.ev.forEach(e => m.push({ time: c[e.j].time, position: e.up ? 'belowBar' : 'aboveBar', color: e.up ? '#00D6A0' : '#FF5268', shape: e.up ? 'arrowUp' : 'arrowDown', text: e.k }));
  if (S.ovl.sig && Srv.hist && Srv.hist.sym === S.sym) Srv.hist.list.forEach(s => {
    if (s.time < c[0].time) return;
    const b = s.side === 'BUY';
    m.push({ time: s.time, position: b ? 'belowBar' : 'aboveBar', color: b ? '#3987FF' : '#F5B83D', shape: b ? 'arrowUp' : 'arrowDown', text: (b ? 'BUY ' : 'SELL ') + s.score + ({ tp: ' ✓', sl: ' ✗' }[s.result] || '') });
  });
  m.sort((a, b) => a.time - b.time);
  ser.setMarkers(m);
}
async function loadHist() {
  if (!S.ovl.sig || (Srv.hist && Srv.hist.sym === S.sym && Date.now() - Srv.hist.ts < 300000)) return;
  const sym = S.sym;
  Srv.hist = { sym, ts: Date.now(), list: [], m: null };
  try { const d = await j('/api/history/' + sym + '?bars=1500'); Srv.hist = { sym, ts: Date.now(), list: d.signals, m: d.metrics }; if (sym === S.sym) applyMarkers(); } catch (e) {}
}

Srv.loadChart = async function (fit) {
  if (Srv.busy) return;
  Srv.busy = true;
  
  // تحديث العنوان فوراً حتى لا يبقى BTCUSDT عالقاً إذا حدث خطأ
  const T = Data.t(S.sym);
  if (T) {
    $('#cs').textContent = S.sym;
    $('#cp').textContent = fmt(T.price);
    $('#cc').textContent = (T.chg >= 0 ? '+' : '') + T.chg.toFixed(2) + '%';
    $('#cc').className = 'num ' + (T.chg >= 0 ? 'up' : 'down');
  }

  try {
    if (fit) { S.limit = 600; S.start = 0; Srv.maxed = false; }
    const d = await j(`/api/analysis/${S.sym}?tf=${S.tf}&limit=${S.limit || 600}` + (S.start ? '&start=' + Math.floor(S.start) : ''));
    
    // فحص أمان: التأكد من تهيئة الشارت قبل الرسم
    if (typeof chart === 'undefined' || !chart) {
      if (typeof initChart === 'function') initChart();
    }
    if (typeof chart === 'undefined' || !chart) {
      throw new Error('مكتبة الشارت غير محملة. تأكد من اتصالك بالإنترنت ثم أعد تحميل الصفحة.');
    }

    const old = cur.c ? cur.c.length : 0, rg = chart.timeScale().getVisibleLogicalRange();
    cur.c = d.candles; cur.an = d.analysis; cur.sg = d.signal;
    const c = cur.c;
    document.querySelectorAll('#tfs .chip').forEach(b => b.classList.toggle('on', b.dataset.t === S.tf));
    document.querySelectorAll('#ovs .chip').forEach(b => b.classList.toggle('on', !!S.ovl[b.dataset.o]));
    ser.setData(c);
    volS.setData(c.map(x => ({ time: x.time, value: x.vol, color: x.close >= x.open ? 'rgba(0,214,160,.35)' : 'rgba(255,82,104,.35)' })));
    zz.setData(S.ovl.zz ? d.analysis.z.map(q => ({ time: c[q.i].time, value: q.p })) : []);
    applyMarkers(); loadHist();
    if (fit) chart.timeScale().setVisibleLogicalRange({ from: c.length - 110, to: c.length + 8 });
    else if (Srv.prep && rg) { const add = c.length - old; chart.timeScale().setVisibleLogicalRange({ from: rg.from + add, to: rg.to + add }); }
    if (Srv.prep) { Srv.prep = false; if (c.length <= old + 5) Srv.maxed = true; }
    head(); strat(d.signal); draw();
    if (!Srv.hooked) {
      Srv.hooked = true;
      chart.timeScale().subscribeVisibleLogicalRangeChange(r => {  // scrolled to the left edge: load older candles
        if (!Srv.on || !r || Srv.busy || Srv.maxed || S.page !== 'chart' || r.from > 6 || (S.limit || 600) >= 3000) return;
        S.limit = (S.limit || 600) + 500; Srv.prep = true; Srv.loadChart(false);
      });
    }
  } catch (e) { 
    console.error(e);
    $('#strat').innerHTML = '<h3>تعذر تحميل التحليل</h3><p style="color:var(--tx2)">' + esc(e.message) + '</p>'; 
  }
  finally { Srv.busy = false; }
};

function strat(sg) {
  const el = $('#strat');
  if (!sg) { el.innerHTML = '<h3>FIBONACCI SMC SCALPING</h3><p style="color:var(--tx2)">لا يتوفر تحليل لهذه العملة بعد.</p>'; return; }
  const st = STAT[sg.status] || STAT.none, tr = k => `<span class="${TRD[k][1]}">${TRD[k][2]} ${TRD[k][0]}</span>`;
  el.innerHTML = `<h3>FIBONACCI SMC SCALPING</h3>
  <div class="kv"><span>اتجاه 4H</span>${tr(sg.t4)}</div><div class="kv"><span>تأكيد 1H</span>${tr(sg.t1)}</div><div class="kv"><span>إطار الدخول 15M</span>${tr(sg.t15)}</div>
  <div class="kv"><span>الحالة</span><span class="tag ${st[1]}">${st[0]}${sg.side ? ' · ' + (sg.side === 'BUY' ? 'شراء' : 'بيع') : ''}</span></div>
  ${sg.entry ? `<div class="kv"><span>قوة الإشارة</span><b>${sg.score}/100</b></div><div class="kv"><span>الدخول</span><span class="num">${fmt(sg.entry)}</span></div><div class="kv"><span>وقف الخسارة</span><span class="num down">${fmt(sg.sl)}</span></div><div class="kv"><span>الهدف (1:${sg.rr})</span><span class="num up">${fmt(sg.tp)}</span></div>` : ''}
  <ul class="r" style="margin-top:10px">${sg.reasons.length ? sg.reasons.map(r => '<li>✓ ' + esc(r) + '</li>').join('') : `<li>${sg.side ? 'لم يصل السعر إلى منطقة دخول بعد.' : 'اتجاها 4H و1H غير متوافقين، فلا تصدر صفقة.'}</li>`}</ul>
  ${sg.status === 'signal' ? '<button class="btn" style="width:100%;margin-top:10px" id="tk">تسجيل الصفقة</button>' : ''}
  <button class="btn g" style="width:100%;margin-top:8px" id="bt">اختبار تاريخي (Backtest)</button><div id="btr" style="margin-top:8px"></div>`;
  const b = $('#tk'); if (b) b.onclick = () => { take({ sym: S.sym, side: sg.side, entry: sg.entry, sl: sg.sl, tp: sg.tp }); go('log'); };
  $('#bt').onclick = async () => {
    $('#btr').innerHTML = '<span style="color:var(--tx2)">جارٍ الحساب…</span>';
    try {
      const m = (await j('/api/backtest', { method: 'POST', body: JSON.stringify({ symbol: S.sym, bars: 2000 }) })).metrics;
      $('#btr').innerHTML = [['الصفقات', m.trades], ['الرابحة / الخاسرة', m.wins + ' / ' + m.losses], ['نسبة النجاح', m.win_rate + '%'], ['صافي الربح', m.net_pnl_pct + '%'], ['أقصى تراجع', m.max_drawdown_pct + '%'], ['متوسط العائد', m.avg_return_pct + '%'], ['الرسوم / الانزلاق', m.fee_pct + '% / ' + m.slippage_pct + '%']].map(r => `<div class="kv"><span>${r[0]}</span><b class="num">${r[1]}</b></div>`).join('');
    } catch (e) { $('#btr').innerHTML = '<span class="down">' + esc(/تسجيل/.test(e.message) ? 'سجّل الدخول من الإعدادات لتشغيل الاختبار.' : e.message) + '</span>'; }
  };
}
$('#dg').onclick = async () => {
  const a = $('#d1').value, b = $('#d2').value;
  if (!a || !b) return;
  const f = new Date(a) / 1e3, t = new Date(b) / 1e3 + 86399;
  if (Srv.on && cur.c && f < cur.c[0].time) { S.start = f * 1000 - 864e5; await Srv.loadChart(false); }
  const c = cur.c;
  if (!c || f >= t || t < c[0].time || f > c[c.length - 1].time) { alert('الفترة خارج البيانات المتاحة لهذا الإطار الزمني. اختر تاريخاً أحدث أو إطاراً أكبر.'); return; }
  chart.timeScale().setVisibleRange({ from: Math.max(f, c[0].time), to: Math.min(t, c[c.length - 1].time) });
};

/* ---------- signals & trades ---------- */
const SL_ = { active: ['إشارة جاهزة', 'up'], tp: ['حققت الهدف', 'up'], sl: ['ضربت الوقف', 'down'], cancelled: ['ملغاة', ''] };
Srv.renderSigs = async function () {
  document.querySelectorAll('#sf .chip').forEach(b => b.classList.toggle('on', b.dataset.k === S.sf));
  try {
    const d = await j('/api/signals?limit=100');
    Srv.list = d.signals.filter(s => S.sf === 'all' || (S.sf === 'signal' && s.status === 'active') || s.side === S.sf);
  } catch (e) { $('#sigs').innerHTML = '<div class="empty">تعذر تحميل الإشارات: ' + esc(e.message) + '</div>'; return; }
  const waits = S.sf === 'wait' ? Data.tickers.filter(t => t.sig && t.sig.status === 'wait') : [];
  const cards = S.sf === 'wait' ? waits.map(t => `<div class="card sig"><div class="t"><b dir="ltr" style="font-size:16px">${t.sym}</b><span class="tag bl">بانتظار شمعة تأكيد</span><span class="sp"></span><button class="btn g" data-o="${t.sym}">الشارت</button></div></div>`)
    : Srv.list.map((s, i) => { const st = SL_[s.status] || SL_.cancelled; return `<div class="card sig"><div class="t"><b dir="ltr" style="font-size:16px">${s.symbol}</b><span class="tag ${s.side === 'BUY' ? 'up' : 'down'}">${s.side === 'BUY' ? 'شراء' : 'بيع'}</span><span class="tag ${st[1]}">${st[0]}</span><span class="tag bl">${s.score}/100</span><span class="sp"></span><button class="btn g" data-o="${s.symbol}">الشارت</button>${s.status === 'active' ? `<button class="btn" data-st="${i}">تسجيل</button>` : ''}</div>
      <div class="kv"><span>الدخول</span><span class="num">${fmt(s.entry)}</span></div><div class="kv"><span>وقف الخسارة</span><span class="num down">${fmt(s.sl)}</span></div><div class="kv"><span>الهدف (1:${s.rr})</span><span class="num up">${fmt(s.tp)}</span></div>
      <ul class="r" style="margin-top:8px">${s.reasons.map(r => '<li>✓ ' + esc(r) + '</li>').join('')}</ul></div>`; });
  $('#sigs').innerHTML = cards.length ? cards.join('') : '<div class="empty">لا توجد إشارات تطابق الفلتر الآن. السيرفر يحلل كل شمعة 15M مغلقة ولا يصدر صفقة إلا عند اكتمال الشروط وتقييم 80 على الأقل.</div>';
};
$('#sigs').addEventListener('click', e => {
  const k = e.target.dataset.st;
  if (k !== undefined && Srv.on) { const s = Srv.list[+k]; if (s) { take({ sym: s.symbol, side: s.side, entry: s.entry, sl: s.sl, tp: s.tp }); go('log'); } }
});
Srv.logExtra = async function () {
  if (!Srv.tc || Date.now() - Srv.tc.ts > 10000) { try { Srv.tc = { ts: Date.now(), d: await j('/api/trades?limit=40') }; } catch (e) { return; } }
  let el = $('#jl2');
  if (!el) { el = document.createElement('div'); el.id = 'jl2'; $('#jl').before(el); }
  const { trades, stats } = Srv.tc.d, n = stats.net_pct;
  el.innerHTML = `<h3 style="margin:16px 0 8px">صفقات السيرفر (مشتركة لكل المستخدمين)</h3><div class="stats"><div class="card">الصفقات<b>${stats.total}</b></div><div class="card">المفتوحة<b>${stats.open}</b></div><div class="card">نسبة النجاح<b>${stats.wins + stats.losses ? stats.win_rate + '%' : '—'}</b></div><div class="card">صافي النتائج<b class="num ${n >= 0 ? 'up' : 'down'}">${n >= 0 ? '+' : ''}${n}%</b></div></div>` +
    trades.map(t => { const p = t.pnl_pct, lab = { open: ['مفتوحة', 'bl'], tp: ['حقق الهدف', 'up'], sl: ['ضرب الوقف', 'down'], cancelled: ['ملغاة', ''] }[t.status];
      return `<div class="card sig"><div class="t"><b dir="ltr">${t.symbol}</b><span class="tag ${t.side === 'BUY' ? 'up' : 'down'}">${t.side === 'BUY' ? 'شراء' : 'بيع'}</span><span class="tag ${lab[1]}">${lab[0]}</span><span class="sp"></span>${p == null ? '' : `<b class="num ${p >= 0 ? 'up' : 'down'}">${p >= 0 ? '+' : ''}${p.toFixed(2)}%</b>`}</div><div class="kv"><span>الدخول</span><span class="num">${fmt(t.entry)}</span></div><div class="kv"><span>الوقف / الهدف</span><span class="num">${fmt(t.sl)} / ${fmt(t.tp)}</span></div></div>`; }).join('');
};

/* ---------- admin & account (inside Settings) ---------- */
const box = document.createElement('div');
box.id = 'srvbox'; box.style.cssText = 'max-width:520px;margin-top:14px';
$('#p-set').appendChild(box);
const msg = (t, ok) => { const m = $('#a-msg'); if (m) m.innerHTML = `<span class="${ok ? 'up' : 'down'}">${esc(t)}</span>`; };
const inp = (id, label, v, extra = '') => `<label class="f">${label}<input id="${id}" value="${esc(v ?? '')}" ${extra}></label>`;
function renderAuth() {
  if (!Srv.on) { box.innerHTML = ''; return; }
  if (!Srv.user) {
    box.innerHTML = `<div class="card panel"><h3>حساب المستخدم</h3>${inp('a-u', 'اسم المستخدم', '', 'autocomplete="username" dir="ltr"')}${inp('a-p', 'كلمة المرور (8 أحرف على الأقل)', '', 'type="password" autocomplete="current-password"')}
    <div class="bar"><button class="btn" data-a="login">دخول</button><button class="btn g" data-a="register">إنشاء حساب</button></div><div id="a-msg"></div></div>`;
    return;
  }
  box.innerHTML = `<div class="card panel"><h3>حساب المستخدم</h3><div class="kv"><span>${esc(Srv.user.username)}</span><span class="tag ${Srv.user.role === 'admin' ? 'bl' : ''}">${Srv.user.role === 'admin' ? 'مدير' : 'مستخدم'}</span></div><div class="bar" style="margin-top:10px"><button class="btn g" data-a="logout">تسجيل الخروج</button></div></div><div id="adm"></div>`;
  if (Srv.user.role === 'admin') renderAdmin();
}
async function renderAdmin() {
  let P, T;
  try { [P, T] = await Promise.all([j('/api/settings'), j('/api/telegram')]); } catch (e) { return; }
  const ck = (id, l, v) => `<label class="f" style="flex-direction:row;align-items:center;gap:10px"><input type="checkbox" id="${id}" ${v ? 'checked' : ''}>${l}</label>`;
  $('#adm').innerHTML = `<div class="card panel" style="margin-top:14px"><h3>إدارة الاستراتيجية</h3>${ck('a-eng', 'تشغيل تحليل السوق', P.engine_enabled)}${ck('a-str', 'تشغيل الاستراتيجية وإصدار الإشارات', P.strategy_enabled)}
    ${inp('a-score', 'الحد الأدنى لقوة الإشارة (50 إلى 100)', P.min_score, 'type="number" min="50" max="100"')}${inp('a-rr', 'المخاطرة إلى العائد 1 : ؟ (2 على الأقل)', P.rr, 'type="number" min="2" max="10" step="0.5"')}
    ${inp('a-risk', 'نسبة المخاطرة لكل صفقة % (للباكتيست)', P.risk_pct, 'type="number" step="0.1"')}${inp('a-mr', 'أقصى مسافة وقف خسارة %', P.max_risk_pct, 'type="number" step="0.1"')}
    ${inp('a-zz', 'حساسية ZigZag', P.zigzag_n, 'type="number" min="2" max="8"')}${inp('a-fee', 'رسوم التداول % لكل جهة', P.fee_pct, 'type="number" step="0.01"')}${inp('a-slip', 'الانزلاق السعري %', P.slippage_pct, 'type="number" step="0.01"')}
    <button class="btn" data-a="save">حفظ الإعدادات</button></div>
  <div class="card panel" style="margin-top:14px"><h3>Telegram</h3><p style="color:var(--tx2);font-size:12.5px;margin-bottom:10px">${T.token_set ? 'التوكن محفوظ مشفراً على السيرفر ' + esc(T.token_hint) : 'لم يُحفظ توكن بعد'}. لا يُعاد التوكن إلى الواجهة أبداً.</p>
    ${inp('a-tok', 'Bot Token (اتركه فارغاً للإبقاء على الحالي)', '', 'type="password" dir="ltr" autocomplete="off"')}${inp('a-chat', 'Chat ID', T.chat_id, 'dir="ltr"')}${ck('a-ten', 'إرسال الإشعارات', T.enabled)}
    <div class="bar"><button class="btn" data-a="tg">حفظ</button><button class="btn g" data-a="tgtest">إرسال رسالة تجريبية</button></div></div>
  <div class="card panel" style="margin-top:14px"><h3>العملات المراقبة</h3>${inp('a-coin', 'الرمز، مثل ARBUSDT', '', 'dir="ltr"')}<div class="bar"><button class="btn" data-a="coin+">إضافة</button><button class="btn g" data-a="coin-">حذف</button></div></div>
  <div class="card panel" style="margin-top:14px"><h3>حالة السيرفر</h3><div class="bar"><button class="btn g" data-a="stat">الحالة والموارد</button><button class="btn g" data-a="errs">سجل الأخطاء</button></div><div id="a-out"></div></div><div id="a-msg" style="margin-top:10px"></div>`;
}
box.onclick = async e => {
  const a = e.target.dataset.a;
  if (!a) return;
  const v = id => $('#' + id).value.trim(), ch = id => $('#' + id).checked;
  try {
    if (a === 'login' || a === 'register') {
      const d = await j('/api/users/' + a, { method: 'POST', body: JSON.stringify({ username: v('a-u'), password: v('a-p') }) });
      saveTok(d.token); Srv.user = await j('/api/users/me'); renderAuth();
    } else if (a === 'logout') { saveTok(null); Srv.user = null; renderAuth(); }
    else if (a === 'save') { await j('/api/settings', { method: 'POST', body: JSON.stringify({ engine_enabled: ch('a-eng'), strategy_enabled: ch('a-str'), min_score: +v('a-score'), rr: +v('a-rr'), risk_pct: +v('a-risk'), max_risk_pct: +v('a-mr'), zigzag_n: +v('a-zz'), fee_pct: +v('a-fee'), slippage_pct: +v('a-slip') }) }); msg('تم حفظ الإعدادات', 1); }
    else if (a === 'tg') { const b = { chat_id: v('a-chat') || undefined, enabled: ch('a-ten') }; if (v('a-tok')) b.token = v('a-tok'); await j('/api/telegram/config', { method: 'POST', body: JSON.stringify(b) }); renderAdmin(); setTimeout(() => msg('تم حفظ إعدادات Telegram', 1), 400); }
    else if (a === 'tgtest') { const d = await j('/api/telegram/test', { method: 'POST' }); msg(d.message + '.', 1); }
    else if (a === 'coin+') { await j('/api/coins', { method: 'POST', body: JSON.stringify({ symbol: v('a-coin') }) }); await refreshCoins(); msg('تمت إضافة العملة', 1); }
    else if (a === 'coin-') { await j('/api/coins/' + encodeURIComponent(v('a-coin').toUpperCase()), { method: 'DELETE' }); await refreshCoins(); msg('تم حذف العملة من المراقبة', 1); }
    else if (a === 'stat') { const s = await j('/api/admin/status'); $('#a-out').innerHTML = [['المحرك', s.engine_running ? 'يعمل' : 'متوقف'], ['بث الأسعار', s.price_stream ? 'متصل' : 'منقطع'], ['عملات مراقبة', s.watching], ['آخر دورة تحليل', s.last_cycle || '—'], ['مدة التشغيل (د)', Math.round(s.uptime_s / 60)], ['عملاء WebSocket', s.ws_clients.market + ' / ' + s.ws_clients.signals], ['الذاكرة MB', s.memory_mb ?? '—'], ['الحمل', s.load_avg ? s.load_avg.map(x => x.toFixed(2)).join(' ') : '—'], ['قاعدة البيانات', s.database], ['المستخدمون / الإشارات / المفتوحة', s.counts.users + ' / ' + s.counts.signals + ' / ' + s.counts.open_trades]].map(r => `<div class="kv"><span>${r[0]}</span><b class="num">${esc(r[1])}</b></div>`).join(''); }
    else if (a === 'errs') { const d = await j('/api/admin/errors'); $('#a-out').innerHTML = d.errors.length ? '<ul class="r">' + d.errors.slice(0, 30).map(x => `<li dir="ltr">${esc(x.time)} ${esc(x.level)} ${esc(x.logger)}: ${esc(x.msg)}</li>`).join('') + '</ul>' : '<p style="color:var(--tx2)">لا توجد أخطاء مسجلة.</p>'; }
  } catch (err) { msg(err.message, 0); }
};

/* ---------- hook into the original app ---------- */
const _lc = loadChart; loadChart = f => (Srv.on ? Srv.loadChart(f) : _lc(f));
const _rs = renderSigs; renderSigs = () => (Srv.on ? Srv.renderSigs() : _rs());
const _rl = renderLog; renderLog = () => { _rl(); if (Srv.on) Srv.logExtra(); else { const x = $('#jl2'); if (x) x.remove(); } };
const _ra = runAll; runAll = () => { if (!Srv.on) _ra(); };
const _tk = Data.tick.bind(Data); Data.tick = () => { if (!Srv.on) _tk(); };
$('#s-api').addEventListener('change', () => { Srv.on = false; [Srv.ws, Srv.ws2].forEach(w => w && w.close()); setTimeout(init, 100); });
init();
})();