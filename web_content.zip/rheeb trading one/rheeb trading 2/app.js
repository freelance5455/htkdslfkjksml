/* التطبيق: التنقل، المظهر، سجل الصفقات، الحلقة الحية */
const PAGES = [
  ['coins', 'العملات الرقمية', 'M3 17l6-6 4 4 8-8M15 7h6v6'],
  ['chart', 'الشارت والتحليل', 'M4 20V10M10 20V4M16 20v-8M22 20H2'],
  ['sig', 'الصفقات والإشارات', 'M13 2L4 14h7l-1 8 9-12h-7z'],
  ['log', 'سجل الصفقات', 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01'],
  ['set', 'الإعدادات', 'M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 1-2-1V5h-4v2l-2 1-2-1-2 4 2 1v2l-2 1 2 4 2-1 2 1v2h4v-2l2-1 2 1 2-4-2-1z']
];

$('#nav').innerHTML = PAGES.map(p => `<button data-p="${p[0]}"><svg viewBox="0 0 24 24"><path d="${p[2]}"/></svg>${p[1]}</button>`).join('');
$('#nav').onclick = e => { const b = e.target.closest('button'); if (b) go(b.dataset.p); };

function go(p) {
  S.page = p;
  document.querySelectorAll('.pg').forEach(x => x.classList.toggle('on', x.id === 'p-' + p));
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.p === p));
  scrollTo(0, 0);
  ({ coins:renderCoins, chart:openChart, sig:renderSigs, log:renderLog, set:() => {} })[p]();
}

function applyTheme() {
  document.documentElement.dataset.theme = S.theme;
  $('#theme').textContent = S.theme === 'dark' ? '☀' : '☾';
  $('#s-th').value = S.theme;
  if (chart) {
    const cs = getComputedStyle(document.documentElement);
    const tx = cs.getPropertyValue('--tx2').trim(), ln = cs.getPropertyValue('--line').trim();
    chart.applyOptions({
      layout:{ background:{ type:'solid', color:cs.getPropertyValue('--card').trim() }, textColor:tx },
      grid:{ vertLines:{ color:ln }, horzLines:{ color:ln } }
    });
    draw();
  }
}
$('#theme').onclick = () => { S.theme = S.theme === 'dark' ? 'light' : 'dark'; save(); applyTheme(); };

/* ---------- إشعار ---------- */
function toast(t) {
  const d = document.createElement('div');
  d.textContent = t;
  d.style.cssText = 'position:fixed;inset-inline:16px;bottom:calc(88px + env(safe-area-inset-bottom,0px));z-index:50;background:var(--card);border:1px solid var(--blue);border-radius:14px;padding:12px 14px;box-shadow:var(--sh);text-align:center';
  document.body.appendChild(d);
  setTimeout(() => d.remove(), 5000);
}

/* ---------- سجل الصفقات ---------- */
function take(s) {
  if (!s || !s.entry) return;
  const sym = s.sym || s.symbol;
  if (S.journal.some(j => j.sym === sym && j.st === 'open')) return;
  S.journal.unshift({
    id: Date.now(), sym, side: s.side, entry: s.entry, sl: s.sl, tp: s.tp,
    tf: s.tf || S.tf, score: s.score || 0, time: Date.now(), st: 'open'
  });
  save();
}

function track() {
  let ch = 0;
  S.journal.forEach(j => {
    if (j.st !== 'open') return;
    const T = Data.t(j.sym); if (!T) return;
    const p = T.price, b = j.side === 'BUY';
    if (b ? p >= j.tp : p <= j.tp) { j.st = 'tp'; j.exit = j.tp; ch = 1; }
    else if (b ? p <= j.sl : p >= j.sl) { j.st = 'sl'; j.exit = j.sl; ch = 1; }
  });
  if (ch) save();
}

const pnl = j => {
  if (j.st === 'cancelled') return 0;
  const T = Data.t(j.sym);
  const p = j.st === 'open' ? (T ? T.price : j.entry) : j.exit;
  return (j.side === 'BUY' ? p - j.entry : j.entry - p) / j.entry * 100;
};

function renderLog() {
  const J = S.journal, cl = J.filter(j => j.st !== 'open'), w = cl.filter(j => j.st === 'tp').length;
  const tot = cl.reduce((s, j) => s + pnl(j), 0);
  $('#st').innerHTML = `<div class="card">الصفقات<b>${J.length}</b></div>
    <div class="card">المفتوحة<b>${J.length - cl.length}</b></div>
    <div class="card">نسبة النجاح<b>${cl.length ? (w / cl.length * 100).toFixed(0) + '%' : '—'}</b></div>
    <div class="card">صافي النتائج<b class="num ${tot >= 0 ? 'up' : 'down'}">${tot >= 0 ? '+' : ''}${tot.toFixed(2)}%</b></div>`;

  $('#jl').innerHTML = J.length ? J.map(j => {
    const p = pnl(j);
    const fresh = j.st === 'open' && Date.now() - j.time < 9e5;
    const lab = { tp:['حقق الهدف', 'up'], sl:['ضرب الوقف', 'down'], cancelled:['ملغاة', ''], open:[fresh ? 'جديدة' : 'مفتوحة', 'bl'] }[j.st];
    return `<div class="card sig"><div class="t">
      <b dir="ltr">${j.sym}</b>
      <span class="tag ${j.side === 'BUY' ? 'up' : 'down'}">${j.side === 'BUY' ? 'شراء' : 'بيع'}</span>
      <span class="tag ${lab[1]}">${lab[0]}</span>
      <span class="tag">${j.tf || ''}</span>
      ${j.score ? `<span class="tag bl">${j.score}/100</span>` : ''}
      <span class="sp"></span>
      <b class="num ${p >= 0 ? 'up' : 'down'}">${p >= 0 ? '+' : ''}${p.toFixed(2)}%</b>
    </div>
    <div class="kv"><span>الدخول</span><span class="num">${fmt(j.entry)}</span></div>
    <div class="kv"><span>الوقف / الهدف</span><span class="num">${fmt(j.sl)} / ${fmt(j.tp)}</span></div>
    <div class="kv"><span>الوقت</span><span>${new Date(j.time).toLocaleString('ar')}</span></div>
    ${j.st === 'open' ? `<div class="bar" style="margin-top:10px"><button class="btn g" data-c="${j.id}">إلغاء الصفقة</button></div>` : ''}
    </div>`;
  }).join('') : '<div class="empty">السجل فارغ. سجّل أول صفقة من صفحة الصفقات والإشارات.</div>';
}

$('#jl').onclick = e => {
  const c = e.target.dataset.c;
  if (!c) return;
  const j = S.journal.find(x => String(x.id) === String(c));
  if (j && j.st === 'open') { j.st = 'cancelled'; save(); renderLog(); }
};

$('#clr').onclick = () => {
  if (S.journal.length && confirm('مسح كل الصفقات المسجلة؟')) { S.journal = []; save(); renderLog(); }
};

/* ---------- الحلقة الحية ---------- */
let tk = 0;
setInterval(() => {
  Data.tick(); track(); tk++;
  if (S.page === 'coins') renderCoins();
  if (S.page === 'chart' && cur.c) {
    const c = cur.c, l = c[c.length - 1];
    ser.update(l);
    volS.update({ time:l.time, value:l.vol, color:l.close >= l.open ? 'rgba(0,214,160,.35)' : 'rgba(255,82,104,.35)' });
    head();
    if (tk % 8 === 0) loadChart(false); else draw();
  }
  if (S.page === 'log') renderLog();
}, 1500);

applyTheme();
go('coins');
setTimeout(() => { runAll(); if (S.page === 'coins') renderCoins(); }, 50);