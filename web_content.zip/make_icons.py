# Genera los iconos del launcher de Android a partir del icono ORIGINAL (icon-512.png).
import os, sys
from PIL import Image
res = "android/app/src/main/res"
sizes = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
src = Image.open("icon-512.png").convert("RGBA")
for d, s in sizes.items():
    folder = os.path.join(res, "mipmap-" + d)
    os.makedirs(folder, exist_ok=True)
    im = src.resize((s, s), Image.LANCZOS)
    for n in ("ic_launcher.png", "ic_launcher_round.png", "ic_launcher_foreground.png"):
        im.save(os.path.join(folder, n))
# Quitar los iconos adaptativos por defecto de Capacitor para que se use el icono original tal cual
import shutil
shutil.rmtree(os.path.join(res, "mipmap-anydpi-v26"), ignore_errors=True)
print("Iconos listos")
