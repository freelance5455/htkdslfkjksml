(function (g) {
  'use strict';

  function normalizeEmail(value) {
    return String(value || '').trim().toLowerCase();
  }

  function resolveAuthenticatedUser(users, authUser, selectedId) {
    const nextUsers = (Array.isArray(users) ? users : []).map((u) => ({ ...u }));
    const authId = String(authUser && authUser.id || '').trim();
    const email = normalizeEmail(authUser && authUser.email);
    let index = nextUsers.findIndex((u) => authId && String(u.auth_id || '') === authId);

    if (index < 0 && email) {
      index = nextUsers.findIndex((u) => normalizeEmail(u.email) === email);
    }
    if (index < 0 && selectedId) {
      index = nextUsers.findIndex((u) => String(u.id || '') === String(selectedId));
    }

    const fallback = {
      id: 'u-' + (authId || email || 'user'),
      name: String(authUser && authUser.user_metadata && authUser.user_metadata.name || email || 'کاربر'),
      role: 'حسابدار',
      dbRole: 'ACCOUNTANT',
      email,
      auth_id: authId,
    };

    const user = index >= 0 ? { ...nextUsers[index], email, auth_id: authId } : fallback;
    if (index >= 0) nextUsers[index] = user;
    else nextUsers.push(user);

    return { user, users: nextUsers };
  }

  function shouldBootstrapOwner(member, companyUnclaimed) {
    return !member && companyUnclaimed === true;
  }

  g.MRKAuth = { normalizeEmail, resolveAuthenticatedUser, shouldBootstrapOwner };
})(window);
