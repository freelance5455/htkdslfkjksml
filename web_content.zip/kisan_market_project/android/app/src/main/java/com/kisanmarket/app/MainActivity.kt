package com.kisanmarket.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Forest = Color(0xFF216B37)
private val Pale = Color(0xFFEEF7EF)
private data class Listing(val title: String, val category: String, val detail: String, val area: String)
private val demoListings = listOf(
    Listing("Ragi / Finger millet", "Agriculture", "Sample listing · price not provided", "Karnataka"),
    Listing("Drip irrigation fittings", "Farm supplies", "Ask seller for a quote", "Karnataka"),
    Listing("Farm tools and hardware", "Shops", "Seller price not provided", "Maharashtra"),
    Listing("Pump repair service", "Services", "Request an estimate", "Tamil Nadu"),
    Listing("Fresh vegetables", "Agriculture", "Confirm availability with seller", "Karnataka"),
    Listing("Seeds and crop-care supplies", "Farm supplies", "Ask seller for a quote", "Maharashtra")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KisanMarketApp() }
    }
}

@Composable
fun KisanMarketApp() {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("All") }
    val context = LocalContext.current
    MaterialTheme(colorScheme = lightColorScheme(primary = Forest, secondary = Color(0xFF438A50))) {
        Scaffold(containerColor = Color(0xFFF7FAF7)) { padding ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Column(Modifier.fillMaxWidth().background(Forest, RoundedCornerShape(20.dp)).padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🌱", style = MaterialTheme.typography.headlineLarge)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("KISAN MARKET", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                Text("Buy Local. Sell Direct. Grow Together.", color = Color(0xFFE1F2E4), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("Founded by NARESH D", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Founder: nareshdnaresh505@gmail.com", color = Color(0xFFE1F2E4), style = MaterialTheme.typography.bodySmall)
                        Text("One marketplace for farmers, shops and local services.", color = Color.White)
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5D8))) {
                        Text("Official mandi prices are not connected yet. No live prices are invented. Verified prices must show source, market, date and unit.", Modifier.padding(14.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search products, shops or services") }, leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }, singleLine = true)
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("All", "Agriculture", "Farm supplies", "Shops", "Services").forEach { category ->
                            FilterChip(selected = selected == category, onClick = { selected = category }, label = { Text(category, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                }
                item { Text("Explore marketplace", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                items(demoListings.filter { (selected == "All" || it.category == selected) && (it.title + it.category + it.area).contains(query, true) }) { listing ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (listing.category == "Shops") Icons.Default.Storefront else Icons.Default.Agriculture, contentDescription = null, tint = Forest)
                                Spacer(Modifier.width(8.dp))
                                Text(listing.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            }
                            Text("${listing.category} · ${listing.area}", color = Forest, style = MaterialTheme.typography.labelMedium)
                            Text(listing.detail, style = MaterialTheme.typography.bodyMedium)
                            Text("Seller-listed information · not an official mandi price", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { Toast.makeText(context, "No consented, verified seller number is configured in this demo. No number is fabricated.", Toast.LENGTH_LONG).show() }) {
                                Text("Contact Seller")
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Pale)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Farmer problems we aim to solve", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Forest)
                            Text("Find buyers for produce · compare farm-input and local shop listings · discover repair services · use simple multilingual search · see last-updated labels for weak-connectivity situations.")
                            Spacer(Modifier.height(10.dp))
                            Text("Official mandi prices", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Forest)
                            Text("Unavailable until a verified official feed is connected. Planned sources include Agmarknet and data.gov.in. Each record must show its source, market, date and unit.")
                        }
                    }
                }
                item { Text("Prototype · Live listings, orders, seller verification and market-data feeds require a backend.", style = MaterialTheme.typography.labelSmall, color = Color.Gray) }
            }
        }
    }
}
