# KISAN MARKET — Android + Website Starter

**Founder:** NARESH D  
**Tagline:** Buy Local. Sell Direct. Grow Together.

This is a starter project, not a production marketplace. It includes a responsive website prototype and a native Android (Jetpack Compose) starter screen.

## Included
- Agricultural produce and local-shop/service listings
- Search and category filtering in the website demo
- Seller contact reveal interaction; demo listings do not contain real phone numbers
- Clear separation between official mandi prices and seller-listed prices
- No fabricated live mandi prices: the demo explicitly says live official data is not connected
- Android starter UI with the same core concept
- Founder contact and farmer-problem analysis section
- Android INTERNET permission added for future online API/backend calls

## Open the website demo
Open `web/index.html` in a browser. It works without a server.

## Open the Android project
Open the `android` folder in Android Studio. Use JDK 17 and a recent Android Studio version with Android Gradle Plugin support. Allow Gradle sync to download dependencies. The project may need Gradle/plugin version adjustments for your local Android Studio installation.

## Before publishing
1. Connect an authorized official mandi-data source (for example, Agmarknet/data.gov.in) and store source, market, date/time, commodity, unit, grade, min/modal/max price and freshness status for every price record.
2. Never show a price as current if the feed is missing or stale. Display “Unavailable” instead.
3. Build a secure backend, user authentication, seller consent, verified phone ownership, listing moderation, report/block tools, rate limits and privacy policy.
4. Use a database and server-side authorization; do not put secret API keys in the app.
5. Add multilingual translations, location/market coverage, order workflow, payment/refund policy and customer support.
6. Test with real sellers and buyers before a public release. This starter is not connected to live market data, payments, SMS or telephony.

## Suggested next architecture
- Android: Kotlin + Jetpack Compose
- Website: responsive HTML/CSS/JS prototype (replace with a production frontend when ready)
- Backend: authenticated REST API
- Database: PostgreSQL
- Data ingestion: permitted official mandi feeds with source timestamps and freshness checks

## Demo behavior
Seller phone numbers are not invented. Tapping **Contact Seller** explains that a real number appears only when the seller has opted in and the listing has a verified contact number configured.


## Farmer problem analysis and product decisions
- **Price uncertainty:** official mandi/APMC prices must show commodity/variety, market, state, date, unit, minimum/modal/maximum values and source URL. If source data is missing, malformed or older than the configured freshness window, show `Unavailable` or `Last updated` rather than claiming it is live.
- **Limited buyer discovery:** allow farmers to publish produce listings with quantity, quality/grade, location, availability and optional asking price; allow buyers to send enquiries.
- **Input and repair costs:** searchable listings for seeds, irrigation, pumps, farm equipment, hardware, electrical goods, groceries and repair services. Clearly mark these as seller-provided prices, not official mandi prices.
- **Trust and privacy:** verify seller phone ownership; reveal a phone number only after Contact Seller and only when the seller has explicitly opted in. Add report/block, moderation and scam warnings. Do not publish the founder's or any user's private details by default.
- **Language and usability:** phased rollout of major Indian languages, simple wording, accessible text, voice-friendly search and low-bandwidth behavior.
- **Rural connectivity:** show the timestamp and source of cached information; retry safely; never present stale cached values as current.
- **Order reliability:** create enquiry/order reference IDs and statuses, confirmation and cancellation paths, customer support and audit history before real transactions go live.

## Founder email and data storage
Use `nareshdnaresh505@gmail.com` as the founder/admin contact for alerts and support. Do **not** store all app data in email. Use an access-controlled database for accounts, seller consent, listings, enquiries and orders; encrypt sensitive data in transit and at rest, limit staff access, keep backups and publish a privacy policy. Never put database passwords or API secrets inside the Android app or public website code.

## Internet and official APMC/mandi integration
The project is prepared for internet access, but it is **not yet connected** to a production backend or live APMC feed. Candidate official sources to review for access, terms and update frequency:
- AGMARKNET: https://agmarknet.gov.in/
- Government of India OGD mandi daily-price dataset: https://data.gov.in/resource/current-daily-price-various-commodities-various-markets-mandi
- e-NAM trade dashboard: https://enam.gov.in/web/dashboard/trade-data/26/330

The data.gov.in description identifies the mandi dataset as generated through AGMARKNET and includes wholesale minimum, modal and maximum prices. Actual integration must use an authorized API/feed, observe its terms and rate limits, handle missing data, and retain the source and source timestamp. Do not scrape or imply a government partnership without authorization.

## Suggested production architecture
1. Android + responsive website clients.
2. HTTPS backend API with authentication and role-based access.
3. PostgreSQL database for users, businesses, products, seller-consent records, enquiries and source-stamped mandi price records.
4. Scheduled ingestion worker for authorized official market data, with validation, duplicate handling, freshness checks and monitoring.
5. Admin dashboard for reports, seller verification, suspicious listings and data-feed health.
6. Email notifications sent to the founder address only for appropriate administrative events; avoid sending sensitive farmer data in email.

## Farmer-first launch checklist
- Pilot with farmers, buyers, FPOs and local shops across a small set of markets, while allowing nationwide registration.
- Test commodity-name spelling, regional units, language quality, low-end Android devices and unreliable connections.
- Show the source and date beside every official price; distinguish wholesale mandi prices from retail/seller offers.
- Add grievance reporting, account deletion, privacy notice, consent logs and backup/restore procedures.
- Do not accept payments or claim orders are fulfilled until payment, refund, dispute and support workflows are implemented and tested.
