BBN NEWS Live Studio - Android Studio Project

APK बनाने के लिए:
1. ZIP को extract करें.
2. कंप्यूटर में Android Studio खोलें.
3. Open चुनें और extracted BBNNewsAndroid फ़ोल्डर चुनें.
4. Gradle sync पूरा होने दें. जरूरत पड़े तो Android SDK Platform 35 और JDK 17 इंस्टॉल करें.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें.
6. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में मिलेगा.

महत्वपूर्ण:
- यह HTML को Android WebView में चलाने वाला शुरुआती APK प्रोजेक्ट है.
- YouTube/Facebook लाइव स्ट्रीमिंग और चार लोगों की रिमोट वीडियो कॉल अभी वास्तविक रूप से लागू नहीं हैं; इनके लिए अतिरिक्त API/backend/WebRTC व्यवस्था चाहिए.
- इस प्रोजेक्ट में Gradle wrapper शामिल नहीं है; Android Studio के जरिए खोलें और build करें.
