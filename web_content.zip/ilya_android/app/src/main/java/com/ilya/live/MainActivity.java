package com.ilya.live;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.pm.PackageManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.widget.Toast;
import android.Manifest;
import android.view.WindowManager;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONArray;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int PICK_IMPORT = 41;
    private static final int CREATE_EXPORT = 42;
    private static final int PICK_RESTORE = 43;
    private static final int CREATE_BACKUP = 44;
    private String pendingExport = "{}";
    private Uri backupUri = null;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, 0);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0B0F19);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = params.createIntent();
                try { startActivityForResult(i, PICK_IMPORT); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
        });
        web.addJavascriptInterface(new NativeBridge(this), "IlyaNative");
        setContentView(web);
        // restore backup uri if previously chosen
        String saved = getSharedPreferences("collector", MODE_PRIVATE).getString("backup_uri", null);
        if (saved != null) {
            try { backupUri = Uri.parse(saved); } catch (Exception ignored) {}
        }
        // ساخت پوشه بکاپ از لحظه نصب/اولین اجرا
        try {
            File bdir = new File(getFilesDir(), "ilya_backups");
            if (!bdir.exists()) bdir.mkdirs();
        } catch (Exception ignored) {}
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        startCollector();
    }

    private void startCollector() {
        Intent i = new Intent(this, CollectorService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }
    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("(function(){if(typeof closeInAppBrowser==='function'&&document.getElementById('inAppBrowser')?.classList.contains('open')){closeInAppBrowser();return 'handled';}return 'no';})()", null);
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMPORT && fileCallback != null) {
            Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result); fileCallback = null;
        } else if ((requestCode == CREATE_EXPORT || requestCode == CREATE_BACKUP) && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {}
            if (requestCode == CREATE_BACKUP) {
                backupUri = uri;
                getSharedPreferences("collector", MODE_PRIVATE).edit().putString("backup_uri", uri.toString()).apply();
            }
            final String body = pendingExport;
            final Uri outUri = uri;
            final boolean isBackup = requestCode == CREATE_BACKUP;
            io.execute(() -> {
                try (OutputStream out = getContentResolver().openOutputStream(outUri, "wt")) {
                    if (out != null) out.write(body.getBytes(StandardCharsets.UTF_8));
                    runOnUiThread(() -> Toast.makeText(this, isBackup ? "فایل بکاپ دائمی آماده شد" : "فایل داده ذخیره شد", Toast.LENGTH_SHORT).show());
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(this, "ذخیره فایل ناموفق بود", Toast.LENGTH_LONG).show());
                }
            });
        } else if (requestCode == PICK_RESTORE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            io.execute(() -> {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) return;
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                    final String json = new String(bos.toByteArray(), StandardCharsets.UTF_8);
                    runOnUiThread(() -> {
                        if (web != null) {
                            String escaped = JSONObject.quote(json);
                            web.evaluateJavascript(
                                "(function(){try{const data=JSON.parse(" + escaped + ");if(typeof applyImportedData==='function'){applyImportedData(data);}else{console.log('applyImportedData missing');}}catch(e){console.error(e);}})()",
                                null);
                            Toast.makeText(this, "داده‌ها بازیابی شدند", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(this, "خواندن فایل ناموفق بود", Toast.LENGTH_LONG).show());
                }
            });
        }
    }

    private void writeToBackupUri(String json) {
        if (backupUri == null) {
            String saved = getSharedPreferences("collector", MODE_PRIVATE).getString("backup_uri", null);
            if (saved != null) {
                try { backupUri = Uri.parse(saved); } catch (Exception ignored) {}
            }
        }
        if (backupUri == null) return;
        final Uri uri = backupUri;
        final String body = json == null ? "{}" : json;
        io.execute(() -> {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out != null) out.write(body.getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) {
                // silent auto-backup failure
            }
        });
    }

    public class NativeBridge {
        private final Context ctx;
        NativeBridge(Context c) { ctx = c; }
        @JavascriptInterface public void startBackgroundCollector(String walletJson) {
            getSharedPreferences("collector", MODE_PRIVATE).edit().putString("wallets", walletJson == null ? "[]" : walletJson).apply();
            startCollector();
        }
        @JavascriptInterface public String readSnapshots() {
            return getSharedPreferences("collector", MODE_PRIVATE).getString("snapshots", "[]");
        }
        @JavascriptInterface public String readClipboard() {
            try { ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE); ClipData d = cm.getPrimaryClip(); if (d != null && d.getItemCount() > 0) return String.valueOf(d.getItemAt(0).coerceToText(ctx)); } catch(Exception ignored) {} return "";
        }
        @JavascriptInterface public void exportData(String json) {
            runOnUiThread(() -> {
                pendingExport = json == null ? "{}" : json;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, "ilya-wallet-data.json");
                startActivityForResult(i, CREATE_EXPORT);
            });
        }
        @JavascriptInterface public void chooseBackupFile(String json) {
            runOnUiThread(() -> {
                pendingExport = json == null ? "{}" : json;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, "ilya-backup-persistent.json");
                startActivityForResult(i, CREATE_BACKUP);
            });
        }
        @JavascriptInterface public void writeBackup(String json) {
            writeToBackupUri(json);
        }
        @JavascriptInterface public boolean hasBackupFile() {
            if (backupUri != null) return true;
            String saved = getSharedPreferences("collector", MODE_PRIVATE).getString("backup_uri", null);
            return saved != null && saved.length() > 0;
        }
        @JavascriptInterface public void importData() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i, PICK_RESTORE);
            });
        }
        @JavascriptInterface public void persistWallets(String json) {
            getSharedPreferences("collector", MODE_PRIVATE).edit().putString("wallets", json == null ? "[]" : json).apply();
        }
        /** ذخیره آخرین payload کامل برای بکاپ ۲ساعته سرویس پس‌زمینه */
        @JavascriptInterface public void storeFullBackup(String json) {
            getSharedPreferences("collector", MODE_PRIVATE).edit()
                .putString("full_backup_json", json == null ? "{}" : json)
                .apply();
        }
        @JavascriptInterface public void forceBackupNow() {
            Intent i = new Intent(MainActivity.this, CollectorService.class);
            i.setAction("FORCE_BACKUP");
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        }
        @JavascriptInterface public String getBackupDirPath() {
            File dir = new File(getFilesDir(), "ilya_backups");
            if (!dir.exists()) dir.mkdirs();
            return dir.getAbsolutePath();
        }
        @JavascriptInterface public void toast(String msg) { runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show()); }
    }
}
