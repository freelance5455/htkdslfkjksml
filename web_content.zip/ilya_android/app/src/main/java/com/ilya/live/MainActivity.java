package com.ilya.live;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.pm.PackageManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.widget.Toast;
import android.Manifest;
import android.view.WindowManager;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONArray;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int PICK_IMPORT = 41;
    private static final int CREATE_EXPORT = 42;
    private String pendingExport = "{}";
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, 0);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0B0F19);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = params.createIntent();
                try { startActivityForResult(i, PICK_IMPORT); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
        });
        web.addJavascriptInterface(new NativeBridge(this), "IlyaNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        startCollector();
    }

    private void startCollector() {
        Intent i = new Intent(this, CollectorService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }
    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("(function(){if(typeof closeInAppBrowser==='function'&&document.getElementById('inAppBrowser')?.classList.contains('open')){closeInAppBrowser();return 'handled';}return 'no';})()", null);
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMPORT && fileCallback != null) {
            Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result); fileCallback = null;
        } else if (requestCode == CREATE_EXPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData(); String body = pendingExport;
            io.execute(() -> { try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) { if (out != null) out.write(body.getBytes(StandardCharsets.UTF_8)); runOnUiThread(() -> Toast.makeText(this, "فایل داده ذخیره شد", Toast.LENGTH_SHORT).show()); } catch(Exception e) { runOnUiThread(() -> Toast.makeText(this, "ذخیره فایل ناموفق بود", Toast.LENGTH_LONG).show()); } });
        }
    }

    public class NativeBridge {
        private final Context ctx;
        NativeBridge(Context c) { ctx = c; }
        @JavascriptInterface public void startBackgroundCollector(String walletJson) {
            getSharedPreferences("collector", MODE_PRIVATE).edit().putString("wallets", walletJson == null ? "[]" : walletJson).apply();
            startCollector();
        }
        @JavascriptInterface public String readSnapshots() {
            return getSharedPreferences("collector", MODE_PRIVATE).getString("snapshots", "[]");
        }
        @JavascriptInterface public String readClipboard() {
            try { ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE); ClipData d = cm.getPrimaryClip(); if (d != null && d.getItemCount() > 0) return String.valueOf(d.getItemAt(0).coerceToText(ctx)); } catch(Exception ignored) {} return "";
        }
        @JavascriptInterface public void exportData(String json) {
            runOnUiThread(() -> { pendingExport = json == null ? "{}" : json; Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json"); i.putExtra(Intent.EXTRA_TITLE, "ilya-wallet-data.json"); startActivityForResult(i, CREATE_EXPORT); });
        }
        @JavascriptInterface public void importData() {
            runOnUiThread(() -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json"); startActivityForResult(i, PICK_IMPORT); });
        }
        @JavascriptInterface public void persistWallets(String json) {
            getSharedPreferences("collector", MODE_PRIVATE).edit().putString("wallets", json == null ? "[]" : json).apply();
        }
        @JavascriptInterface public void toast(String msg) { runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show()); }
    }
}
