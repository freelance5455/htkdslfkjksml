package com.ilya.live;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public class CollectorService extends Service {
    private static final String CHANNEL = "ilya_collector";
    private ScheduledExecutorService scheduler;
    private ExecutorService workers;
    private PowerManager.WakeLock wakeLock;
    @Override public void onCreate() { super.onCreate(); createChannel(); if (Build.VERSION.SDK_INT >= 26) startForeground(7, notification()); else startForeground(7, notification()); PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE); wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"IlyaLive:collector"); wakeLock.acquire(10*60*1000L); workers=Executors.newFixedThreadPool(6); scheduler=Executors.newSingleThreadScheduledExecutor(); scheduler.scheduleWithFixedDelay(this::collect, 3, 15, TimeUnit.SECONDS); }
    private void createChannel() { if (Build.VERSION.SDK_INT >= 26) { NotificationChannel c=new NotificationChannel(CHANNEL,"Ilya Live data collection",NotificationManager.IMPORTANCE_LOW); c.setDescription("جمع‌آوری داده کیف‌پول‌ها در پس‌زمینه"); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c); } }
    private Notification notification() { if(Build.VERSION.SDK_INT>=26) return new Notification.Builder(this,CHANNEL).setContentTitle("Ilya Live").setContentText("پایش پس‌زمینه فعال است؛ اینترنت و روشن‌بودن گوشی لازم است").setSmallIcon(android.R.drawable.stat_notify_sync).setOngoing(true).build(); return new Notification.Builder(this).setContentTitle("Ilya Live").setContentText("پایش پس‌زمینه فعال است").setSmallIcon(android.R.drawable.stat_notify_sync).setOngoing(true).build(); }
    private void collect() {
        try {
            String raw=getSharedPreferences("collector",MODE_PRIVATE).getString("wallets","[]"); JSONArray wallets=new JSONArray(raw); if(wallets.length()==0)return;
            JSONArray rows=new JSONArray(); CountDownLatch latch=new CountDownLatch(wallets.length());
            for(int i=0;i<wallets.length();i++){ final String addr=wallets.optString(i); workers.execute(()->{ try { JSONObject req=new JSONObject(); req.put("type","clearinghouseState"); req.put("user",addr); HttpURLConnection c=(HttpURLConnection)new URL("https://api.hyperliquid.xyz/info").openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(7000); c.setReadTimeout(10000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json"); try(OutputStream o=c.getOutputStream()){o.write(req.toString().getBytes(StandardCharsets.UTF_8));} int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while(is!=null&&(n=is.read(buf))>0)b.write(buf,0,n); if(is!=null)is.close(); if(code>=200&&code<300){JSONObject data=new JSONObject(b.toString("UTF-8")); JSONObject row=new JSONObject(); row.put("wallet",addr); row.put("timestamp",System.currentTimeMillis()); row.put("accountValue",data.optJSONObject("marginSummary")!=null?data.optJSONObject("marginSummary").optString("accountValue","0"):"0"); JSONArray positions=new JSONArray(); JSONArray aps=data.optJSONObject("assetPositions")!=null?data.optJSONObject("assetPositions").optJSONArray("assetPositions"):null; if(aps!=null)for(int j=0;j<aps.length();j++){JSONObject p=aps.optJSONObject(j);JSONObject pos=p==null?null:p.optJSONObject("position");if(pos!=null){JSONObject q=new JSONObject();q.put("coin",pos.optString("coin"));q.put("szi",pos.optString("szi","0"));q.put("entryPx",pos.optString("entryPx",""));q.put("positionValue",pos.optString("positionValue","0"));q.put("unrealizedPnl",pos.optString("unrealizedPnl","0"));positions.put(q);}} row.put("positions",positions); synchronized(rows){rows.put(row);} } c.disconnect(); } catch(Exception e){Log.w("IlyaCollector","wallet fetch failed: "+addr,e);} finally{latch.countDown();} }); }
            latch.await(12,TimeUnit.SECONDS); JSONArray previous=new JSONArray(getSharedPreferences("collector",MODE_PRIVATE).getString("snapshots","[]")); synchronized(rows){for(int i=0;i<rows.length();i++)previous.put(rows.get(i));} while(previous.length()>5000){JSONArray trimmed=new JSONArray();for(int i=previous.length()-4000;i<previous.length();i++)trimmed.put(previous.get(i));previous=trimmed;} getSharedPreferences("collector",MODE_PRIVATE).edit().putString("snapshots",previous.toString()).putLong("lastCollect",System.currentTimeMillis()).apply();
        } catch(Exception e){Log.e("IlyaCollector","cycle failed",e);}
    }
    @Override public int onStartCommand(Intent i,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){if(scheduler!=null)scheduler.shutdownNow();if(workers!=null)workers.shutdownNow();if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
