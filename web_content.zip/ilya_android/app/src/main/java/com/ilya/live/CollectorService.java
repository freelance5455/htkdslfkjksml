package com.ilya.live;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.*;

/**
 * سرویس پس‌زمینه:
 * - جمع‌آوری دوره‌ای داده کیف‌پول‌ها از API Hyperliquid
 * - بکاپ خودکار هر ۲ ساعت در پوشه داخلی برنامه + فایل بکاپ دائمی (در صورت انتخاب)
 */
public class CollectorService extends Service {
    private static final String TAG = "IlyaCollector";
    private static final String CHANNEL = "ilya_collector";
    private static final long BACKUP_INTERVAL_MS = 2L * 60L * 60L * 1000L; // 2 hours
    private static final long COLLECT_INTERVAL_SEC = 15;

    private ScheduledExecutorService scheduler;
    private ExecutorService workers;
    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        ensureBackupDir();
        if (Build.VERSION.SDK_INT >= 26) {
            startForeground(7, notification("پایش پس‌زمینه فعال است"));
        } else {
            startForeground(7, notification("پایش پس‌زمینه فعال است"));
        }
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "IlyaLive:collector");
        try {
            wakeLock.acquire(10 * 60 * 1000L);
        } catch (Exception ignored) {}

        workers = Executors.newFixedThreadPool(6);
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleWithFixedDelay(this::collect, 3, COLLECT_INTERVAL_SEC, TimeUnit.SECONDS);
        // بکاپ هر ۲ ساعت — اولین اجرا بعد از ۱ دقیقه
        scheduler.scheduleWithFixedDelay(this::autoBackup, 60, BACKUP_INTERVAL_MS / 1000, TimeUnit.SECONDS);
        Log.i(TAG, "CollectorService started; backup every 2h");
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL, "Ilya Live data collection", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("جمع‌آوری داده و بکاپ خودکار در پس‌زمینه");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    private Notification notification(String text) {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(this, CHANNEL)
                    .setContentTitle("Ilya Live")
                    .setContentText(text)
                    .setSmallIcon(android.R.drawable.stat_notify_sync)
                    .setOngoing(true)
                    .build();
        }
        return new Notification.Builder(this)
                .setContentTitle("Ilya Live")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setOngoing(true)
                .build();
    }

    /** پوشه بکاپ داخل حافظه داخلی اپ: files/ilya_backups/ */
    private File backupDir() {
        File dir = new File(getFilesDir(), "ilya_backups");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private void ensureBackupDir() {
        try {
            File dir = backupDir();
            File marker = new File(dir, ".ready");
            if (!marker.exists()) {
                try (FileWriter fw = new FileWriter(marker)) {
                    fw.write("ilya-backup-folder\n");
                }
            }
            Log.i(TAG, "Backup dir: " + dir.getAbsolutePath());
        } catch (Exception e) {
            Log.w(TAG, "ensureBackupDir failed", e);
        }
    }

    private void collect() {
        try {
            if (wakeLock != null && !wakeLock.isHeld()) {
                try { wakeLock.acquire(10 * 60 * 1000L); } catch (Exception ignored) {}
            }
            SharedPreferences prefs = getSharedPreferences("collector", MODE_PRIVATE);
            String raw = prefs.getString("wallets", "[]");
            JSONArray wallets = new JSONArray(raw);
            if (wallets.length() == 0) return;

            JSONArray rows = new JSONArray();
            CountDownLatch latch = new CountDownLatch(wallets.length());
            for (int i = 0; i < wallets.length(); i++) {
                final String addr = wallets.optString(i);
                workers.execute(() -> {
                    try {
                        JSONObject req = new JSONObject();
                        req.put("type", "clearinghouseState");
                        req.put("user", addr);
                        HttpURLConnection c = (HttpURLConnection) new URL("https://api.hyperliquid.xyz/info").openConnection();
                        c.setRequestMethod("POST");
                        c.setConnectTimeout(7000);
                        c.setReadTimeout(10000);
                        c.setDoOutput(true);
                        c.setRequestProperty("Content-Type", "application/json");
                        try (OutputStream o = c.getOutputStream()) {
                            o.write(req.toString().getBytes(StandardCharsets.UTF_8));
                        }
                        int code = c.getResponseCode();
                        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                        ByteArrayOutputStream b = new ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while (is != null && (n = is.read(buf)) > 0) b.write(buf, 0, n);
                        if (is != null) is.close();
                        if (code >= 200 && code < 300) {
                            JSONObject data = new JSONObject(b.toString("UTF-8"));
                            JSONObject row = new JSONObject();
                            row.put("wallet", addr);
                            row.put("timestamp", System.currentTimeMillis());
                            row.put("accountValue",
                                    data.optJSONObject("marginSummary") != null
                                            ? data.optJSONObject("marginSummary").optString("accountValue", "0")
                                            : "0");
                            JSONArray positions = new JSONArray();
                            JSONArray aps = data.optJSONArray("assetPositions");
                            if (aps != null) {
                                for (int j = 0; j < aps.length(); j++) {
                                    JSONObject p = aps.optJSONObject(j);
                                    JSONObject pos = p == null ? null : p.optJSONObject("position");
                                    if (pos != null) {
                                        JSONObject q = new JSONObject();
                                        q.put("coin", pos.optString("coin"));
                                        q.put("szi", pos.optString("szi", "0"));
                                        q.put("entryPx", pos.optString("entryPx", ""));
                                        q.put("positionValue", pos.optString("positionValue", "0"));
                                        q.put("unrealizedPnl", pos.optString("unrealizedPnl", "0"));
                                        positions.put(q);
                                    }
                                }
                            }
                            row.put("positions", positions);
                            synchronized (rows) { rows.put(row); }
                        }
                        c.disconnect();
                    } catch (Exception e) {
                        Log.w(TAG, "wallet fetch failed: " + addr, e);
                    } finally {
                        latch.countDown();
                    }
                });
            }
            latch.await(12, TimeUnit.SECONDS);
            JSONArray previous = new JSONArray(prefs.getString("snapshots", "[]"));
            synchronized (rows) {
                for (int i = 0; i < rows.length(); i++) previous.put(rows.get(i));
            }
            while (previous.length() > 5000) {
                JSONArray trimmed = new JSONArray();
                for (int i = previous.length() - 4000; i < previous.length(); i++) {
                    trimmed.put(previous.get(i));
                }
                previous = trimmed;
            }
            prefs.edit()
                    .putString("snapshots", previous.toString())
                    .putLong("lastCollect", System.currentTimeMillis())
                    .apply();
        } catch (Exception e) {
            Log.e(TAG, "cycle failed", e);
        }
    }

    /**
     * بکاپ خودکار هر ۲ ساعت:
     * 1) فایل timestamp‌دار در files/ilya_backups/
     * 2) کپی به latest.json همان پوشه
     * 3) در صورت وجود URI بکاپ دائمی، همان را هم به‌روز می‌کند
     */
    private void autoBackup() {
        try {
            SharedPreferences prefs = getSharedPreferences("collector", MODE_PRIVATE);
            JSONObject payload = new JSONObject();
            payload.put("exportedAt", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(new Date()));
            payload.put("exportedAtFa", new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(new Date()));
            payload.put("source", "CollectorService.autoBackup");
            payload.put("wallets", new JSONArray(prefs.getString("wallets", "[]")));
            payload.put("snapshots", new JSONArray(prefs.getString("snapshots", "[]")));
            // اگر WebView آخرین payload کامل را ذخیره کرده باشد
            String full = prefs.getString("full_backup_json", null);
            String body;
            if (full != null && full.length() > 10) {
                body = full;
            } else {
                body = payload.toString(2);
            }

            File dir = backupDir();
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File timed = new File(dir, "ilya-backup-" + ts + ".json");
            File latest = new File(dir, "ilya-backup-latest.json");
            writeFile(timed, body);
            writeFile(latest, body);

            // نگه داشتن حداکثر ۲۰ فایل timestamp‌دار
            File[] files = dir.listFiles((d, name) -> name.startsWith("ilya-backup-") && name.endsWith(".json") && !name.contains("latest"));
            if (files != null && files.length > 20) {
                java.util.Arrays.sort(files, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
                for (int i = 0; i < files.length - 20; i++) {
                    //noinspection ResultOfMethodCallIgnored
                    files[i].delete();
                }
            }

            // فایل دائمی انتخاب‌شده توسط کاربر
            String uriStr = prefs.getString("backup_uri", null);
            if (uriStr != null && uriStr.length() > 0) {
                try {
                    Uri uri = Uri.parse(uriStr);
                    try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                        if (out != null) {
                            out.write(body.getBytes(StandardCharsets.UTF_8));
                            out.flush();
                        }
                    }
                } catch (Exception e) {
                    Log.w(TAG, "persistent backup URI write failed", e);
                }
            }

            prefs.edit().putLong("lastAutoBackup", System.currentTimeMillis()).apply();
            Log.i(TAG, "Auto backup written: " + timed.getName());
            try {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) {
                    // به‌روز کردن نوتیفیکیشن سرویس (بدون اسپم جدا)
                    startForeground(7, notification("بکاپ خودکار · آخرین: " + ts));
                }
            } catch (Exception ignored) {}
        } catch (Exception e) {
            Log.e(TAG, "autoBackup failed", e);
        }
    }

    private void writeFile(File f, String body) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(body.getBytes(StandardCharsets.UTF_8));
            fos.flush();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "FORCE_BACKUP".equals(intent.getAction())) {
            workers.execute(this::autoBackup);
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            if (scheduler != null) scheduler.shutdownNow();
            if (workers != null) workers.shutdownNow();
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
