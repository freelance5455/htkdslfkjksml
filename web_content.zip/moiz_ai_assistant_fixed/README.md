# Moiz AI Assistant — rebuilt source ZIP

## Knowledge library
The included `knowledge.json` contains exactly 1,700 searchable question records in the categories shown in your screenshot:
- General Knowledge: 1,000
- Chemistry: 100
- Biology: 100
- Physics: 100
- Mathematics: 100
- English Grammar: 100
- Life-saving apocalypse survival tips: 100
- Emergency tools and their uses: 100

The library is generated from a smaller set of curated facts with multiple question phrasings; the 1,700 records are not 1,700 unrelated facts. If the assistant cannot find a match, try a shorter question with important keywords.

## Offline
- Simple greetings and conversation work offline.
- The built-in knowledge file and emergency guidance work offline when all project files are kept together and loaded by the app.
- For browser offline caching, run on localhost or HTTPS once so the service worker can cache `knowledge.json`. Opening a raw `file://` page does not support service-worker caching.

## Online AI
Online Gemini is optional. Set `GEMINI_API_KEY` in `script.js` and connect to the internet. A key embedded in a public app can be extracted; a secure backend is recommended for a public release.

## APK note
This is a rebuilt editable web-app source ZIP, not a newly signed Android APK. The APK you originally uploaded was a compiled WebView wrapper and did not contain the source files needed to patch it reliably. The original APK is not modified by this ZIP.

## Run
Keep `index.html`, `style.css`, `script.js`, `knowledge.json`, `sw.js`, and `manifest.webmanifest` in the same folder. Test via a local web server or package the project in an Android WebView/Capacitor project. The offline emergency content is general guidance and does not replace emergency services or professional first-aid training.
