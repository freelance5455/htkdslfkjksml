// Offline-first Moiz AI Assistant.
// The 1,700 searchable question records are stored in knowledge.json.
// Optional Gemini online support: configure a key below (client-side keys are extractable;
// for a public release use a secure backend instead).
const GEMINI_API_KEY = "";
const GEMINI_MODEL = "gemini-2.5-flash";
const chatBox = document.getElementById("chatBox");
const userInput = document.getElementById("userInput");
const sendButton = document.getElementById("sendButton");
let database = [];
let loadingDatabase = false;
let databaseError = "";
const history = [];

function norm(s) {
 return String(s).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"")
  .replace(/[^a-z0-9\s]/g," ").replace(/\s+/g," ").trim();
}
function appendMessage(text, who) {
 const el=document.createElement("div");
 el.className="message "+(who==="user"?"user-message":"bot-message");
 el.textContent=String(text);
 chatBox.appendChild(el); chatBox.scrollTop=chatBox.scrollHeight; return el;
}
async function loadDatabase() {
 if(database.length || loadingDatabase) return;
 loadingDatabase=true;
 try {
  const r=await fetch("./knowledge.json");
  if(!r.ok) throw new Error("knowledge.json could not be loaded");
  database=await r.json();
 } catch(e) {
  databaseError=e.message;
 } finally { loadingDatabase=false; }
}
function emergencyAnswer(q) {
 const rules=[
  [["heart attack","chest pain"],"POSSIBLE HEART ATTACK: Call emergency services immediately. Keep the person resting and calm. Do not let them drive. If they become unresponsive and are not breathing normally, start CPR if trained and follow the dispatcher."],
  [["not breathing","cardiac arrest","cpr"],"UNRESPONSIVE / NOT BREATHING NORMALLY: Call emergency services and ask for an AED. Start chest compressions in the centre of the chest at about 100–120 per minute. Use an AED as soon as available and follow its prompts."],
  [["heavy bleeding","bleeding"],"SEVERE BLEEDING: Call emergency services. Apply firm, continuous direct pressure with clean cloth or gauze. Do not keep lifting it to check. Follow emergency dispatcher instructions."],
  [["burn","scald"],"BURN: Cool under cool running water for 20 minutes if possible. Do not use ice, butter, toothpaste, or creams. Do not pull off material stuck to skin. Seek urgent help for serious, large, deep, face, hand, genital, chemical, or electrical burns."],
  [["choking"],"CHOKING: If they can cough or speak, encourage coughing. If they cannot breathe, speak, or cough effectively, call emergency services and give age-appropriate first aid. Adult/child: alternate 5 back blows and 5 abdominal thrusts. Infant: 5 back blows and 5 chest thrusts—never abdominal thrusts."],
  [["earthquake"],"EARTHQUAKE: DROP, COVER, and HOLD ON. Get under sturdy furniture, protect your head and neck, and stay away from windows. Do not use lifts. After shaking, leave damaged buildings carefully and expect aftershocks."],
  [["flood"],"FLOOD: Move to higher ground immediately. Never walk, swim, or drive through floodwater. Avoid electrical wires and contaminated water. Follow official evacuation instructions."],
  [["fire","house fire"],"FIRE: Alert everyone and leave using stairs, not lifts. Stay low under smoke. Close doors behind you if safe. Do not re-enter. Call the fire service from outside. If clothes catch fire: STOP, DROP, and ROLL."],
  [["snake bite","snakebite"],"SNAKEBITE: Keep the person still and calm, immobilize the bitten limb, and get emergency medical care immediately. Remove tight items. Do not cut, suck, ice, or apply a tourniquet. Do not try to catch the snake."],
  [["poison","poisoning"],"POISONING: Contact emergency medical services or a poison centre immediately. Do not induce vomiting or give food/drink unless a professional instructs you. Keep the product container. If unconscious, having seizures, or struggling to breathe, call emergency services now."],
  [["survival kit","emergency kit"],"EMERGENCY KIT: Drinking water, ready-to-eat food, essential medicines, first-aid kit, flashlight and batteries, power bank, radio, whistle, hygiene supplies, document copies, cash, and sturdy shoes."],
  [["water purification","purify water","boil water"],"WATER SAFETY: Prefer sealed safe water or an approved filter/disinfection method. If boiling, bring clear water to a rolling boil for 1 minute (3 minutes above 2,000 m), then cool and store covered. Boiling does not remove chemicals or salt."]
 ];
 for(const [keys,answer] of rules) if(keys.some(k=>q.includes(k))) return answer;
 return null;
}
function conversationReply(q) {
 if(/^(hi|hello|hey|salam|assalamualaikum|aoa)\b/.test(q)) return "Hello! 😊 How are you? What would you like to talk about?";
 if(q.includes("who created you")||q.includes("who made you")) return "I was created by Muhammad Moiz.";
 if(q.includes("your name")||q==="who are you") return "I am Moiz AI Assistant, created by Muhammad Moiz.";
 if(q.includes("how are you")) return "I'm doing well, thank you! How are you?";
 if(q.includes("thank")) return "You're very welcome! 😊";
 if(q.includes("joke")) return "Why did the computer go to the doctor? Because it caught a virus! 😄";
 if(q.includes("good morning")) return "Good morning! Have a great day! ☀️";
 if(q.includes("good night")) return "Good night! Take care. 🌙";
 if(q.includes("what can you do")||q.includes("features")) return "I can chat, answer my 1,700-question offline library, help with school subjects, and provide emergency guidance without internet.";
 if(q.includes("homework")||q.includes("exam")) return "Let's study together. Try 25 minutes of focused study followed by a 5-minute break. Send me your subject or question.";
 return null;
}
function findOffline(q) {
 const direct=database.find(x=>norm(x.question)===q);
 if(direct) return direct.answer;
 // First compare keyword phrases, then score shared meaningful words.
 let best=null,bestScore=0;
 const stop=new Set(["what","is","the","a","an","of","to","for","me","please","tell","can","you","how","do","i","know","answer","question","about","explain","give","short"]);
 const words=q.split(" ").filter(w=>w.length>2&&!stop.has(w));
 for(const item of database) {
  const k=norm(item.keywords+" "+item.question);
  let score=0;
  for(const w of words) if(k.includes(w)) score+=w.length>5?2:1;
  if(score>bestScore){best=item;bestScore=score;}
 }
 return bestScore>=2?best.answer:null;
}
async function onlineAnswer(prompt) {
 const contents=history.slice(-12).map(m=>({role:m.role,parts:[{text:m.text}]}));
 if(!contents.length) contents.push({role:"user",parts:[{text:prompt}]});
 const url=`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;
 const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents})});
 const data=await r.json();
 if(!r.ok) throw new Error(data.error?.message||"Online AI request failed");
 return data.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("").trim()||"Sorry, no answer was returned.";
}
let busy=false;
async function sendMessage() {
 const raw=userInput.value.trim(); if(!raw||busy)return;
 appendMessage(raw,"user");userInput.value="";
 const q=norm(raw);history.push({role:"user",text:raw});
 const small=conversationReply(q)||emergencyAnswer(q);
 if(small){appendMessage(small,"bot");history.push({role:"model",text:small});return;}
 busy=true;sendButton.disabled=true;
 const thinking=appendMessage("Thinking...","bot");
 try {
  await loadDatabase();
  let answer=findOffline(q);
  if(answer){thinking.textContent=answer;history.push({role:"model",text:answer});}
  else if(navigator.onLine&&GEMINI_API_KEY){
   answer=await onlineAnswer(raw);thinking.textContent=answer;history.push({role:"model",text:answer});
  } else {
   thinking.textContent=databaseError
    ? "Offline library could not load ("+databaseError+"). Keep index.html, script.js, style.css, and knowledge.json together in the same folder and open the app through a local web server or packaged app."
    : "I couldn't find that in my offline library. Try a shorter question with the main keywords, or connect to the internet and configure online AI.";
  }
 } catch(e){thinking.textContent="Online AI is unavailable. Offline questions and emergency help are still available. "+e.message;}
 finally{busy=false;sendButton.disabled=false;chatBox.scrollTop=chatBox.scrollHeight;}
}
sendButton.addEventListener("click",sendMessage);
userInput.addEventListener("keydown",e=>{if(e.key==="Enter")sendMessage();});
loadDatabase();
if("serviceWorker" in navigator && location.protocol.startsWith("http")) {
 window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
}
