CLAIM FORMS - APP BUILDER INPUT (DOUBLE BILL COPY)

This package contains the updated Medical Claim Form Filler HTML app.

Files:
- assets/index.html : complete app source

Printing change:
- The first 3 claim forms print first.
- The complete clinic bill prints twice consecutively at the end (normally pages 4 and 5).
- If a bill runs over multiple pages, both complete bill copies are included.
- Preview labels the two copies separately.

App Builder setup:
1. Extract this ZIP.
2. In App Builder > App Files > assets, import/replace index.html.
3. Configure the main screen to load the HTML asset in a WebView if supported.
4. Test Preview and Print before using real patient records.

The app uses external JavaScript libraries/fonts, so Internet access may be needed for PDF and spreadsheet functions. This is an HTML/WebView app source, not a native Android Studio project or signed Play Store AAB.
