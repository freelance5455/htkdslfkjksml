/*--- Avanquest WebEasy Custom Script ---*/

window.close()

/*--- EndOfFile ---*/
