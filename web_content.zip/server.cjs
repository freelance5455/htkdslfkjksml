var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var syncStore = /* @__PURE__ */ new Map();
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "10mb" }));
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.get("/api/download-ipk", (req, res) => {
    const ipkPath = import_path.default.join(process.cwd(), "hebrew-calendar_1.0.0_all.ipk");
    res.download(ipkPath, "hebrew-calendar_1.0.0_all.ipk", (err) => {
      if (err) {
        res.status(404).send("IPK installer package is currently being generated or not found.");
      }
    });
  });
  app.get("/api/sync/room/:roomId", (req, res) => {
    const { roomId } = req.params;
    const pin = req.query.pin || "";
    const cleanRoomId = roomId.toUpperCase().trim();
    const room = syncStore.get(cleanRoomId);
    if (!room) {
      return res.status(404).json({ error: "Sync room not found. You can create a new room with this ID." });
    }
    if (room.pin && room.pin !== pin) {
      return res.status(401).json({ error: "Incorrect room PIN / Passphrase." });
    }
    return res.json({
      success: true,
      roomId: cleanRoomId,
      updatedAt: room.updatedAt,
      devices: room.devices,
      data: room.data
    });
  });
  app.post("/api/sync/room/:roomId", (req, res) => {
    const { roomId } = req.params;
    const { pin, data } = req.body;
    const cleanRoomId = roomId.toUpperCase().trim();
    const existing = syncStore.get(cleanRoomId);
    if (existing && existing.pin && existing.pin !== (pin || "")) {
      return res.status(401).json({ error: "Incorrect room PIN." });
    }
    const deviceName = data?.deviceName || "Unknown Device";
    const devices = existing?.devices || [];
    if (!devices.includes(deviceName)) {
      devices.push(deviceName);
    }
    const updatedRoom = {
      roomId: cleanRoomId,
      pin: pin || "",
      data: data || {},
      updatedAt: Date.now(),
      devices
    };
    syncStore.set(cleanRoomId, updatedRoom);
    return res.json({
      success: true,
      roomId: cleanRoomId,
      timestamp: updatedRoom.updatedAt,
      devicesCount: devices.length
    });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Hebrew Calendar App server listening on port ${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
