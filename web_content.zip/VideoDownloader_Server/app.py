import os, re, uuid, shutil, threading, traceback
from pathlib import Path
from typing import Any
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, HttpUrl
import yt_dlp

BASE = Path(__file__).resolve().parent
DOWNLOAD_DIR = Path(os.getenv('DOWNLOAD_DIR', BASE / 'downloads'))
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
app = FastAPI(title='VideoDownloader API', version='1.0.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    # Always answer with JSON so the page shows a real message instead of "Failed to fetch"
    return JSONResponse({'detail': f'Server error: {str(exc)[:300]}'}, status_code=500)

app.mount('/static', StaticFiles(directory=BASE / 'static'), name='static')
TASKS: dict[str, dict[str, Any]] = {}
LOCK = threading.Lock()

class AnalyzeRequest(BaseModel):
    url: str

class DownloadRequest(BaseModel):
    url: str
    video_format_id: str | None = None
    audio_format_id: str | None = None
    audio_only: bool = False


def safe_title(value: str) -> str:
    value = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', '_', value or 'video')
    return value[:140].strip(' ._') or 'video'


def fmt_size(value):
    if not value:
        return 'Unknown'
    n = float(value)
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if n < 1024 or unit == 'TB':
            return f'{n:.1f} {unit}'
        n /= 1024


def base_opts() -> dict:
    opts: dict[str, Any] = {'quiet': True, 'no_warnings': True, 'noplaylist': True,
                            'extractor_retries': 3, 'socket_timeout': 20, 'retries': 5}
    # YouTube now needs a JavaScript runtime to solve its player challenges.
    runtimes = {}
    for name in ('deno', 'node', 'bun'):
        if shutil.which(name):
            runtimes[name] = {}
    if runtimes:
        opts['js_runtimes'] = runtimes
    # Optional: cookies help with "Sign in to confirm you're not a bot" on server IPs.
    cookie_file = os.getenv('YTDLP_COOKIES_FILE')
    cookie_text = os.getenv('YTDLP_COOKIES')
    if cookie_text and not cookie_file:
        cookie_file = str(BASE / 'cookies.txt')
        Path(cookie_file).write_text(cookie_text, encoding='utf-8')
    if cookie_file and Path(cookie_file).exists():
        opts['cookiefile'] = cookie_file
    proxy = os.getenv('YTDLP_PROXY')
    if proxy:
        opts['proxy'] = proxy
    return opts


def friendly_error(e: Exception) -> str:
    msg = re.sub(r'\x1b\[[0-9;]*m', '', str(e)).replace('ERROR: ', '').strip()
    low = msg.lower()
    if 'sign in to confirm' in low or 'not a bot' in low:
        return ('YouTube is blocking this server\'s IP address (bot check). Add YouTube cookies via the '
                'YTDLP_COOKIES environment variable (see README) or use a different host/proxy. Details: ' + msg[:200])
    if 'live event will begin' in low or 'premieres in' in low:
        return 'This live stream / premiere has not started yet. Try again once it is live. ' + msg[:150]
    if 'private video' in low or 'members-only' in low or 'login' in low:
        return 'This video is private or needs a signed-in account. ' + msg[:200]
    return msg[:350]


def extract(url: str):
    # Try the default client first, then fall back to other YouTube clients.
    attempts = [{}, {'extractor_args': {'youtube': {'player_client': ['tv', 'web_safari', 'mweb']}}},
                {'extractor_args': {'youtube': {'player_client': ['android_vr', 'ios']}}}]
    last: Exception | None = None
    for extra in attempts:
        opts = {**base_opts(), 'skip_download': True, **extra}
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
                if info and info.get('_type') == 'playlist' and info.get('entries'):
                    info = next((x for x in info['entries'] if x), info)
                if info and (info.get('formats') or info.get('url')):
                    return info
        except Exception as e:  # noqa: BLE001
            last = e
    if last:
        raise last
    raise RuntimeError('No downloadable formats were found for this URL.')

@app.get('/', response_class=HTMLResponse)
def home():
    return (BASE / 'static' / 'index.html').read_text(encoding='utf-8')

@app.post('/api/analyze')
def analyze(req: AnalyzeRequest):
    url = req.url.strip()
    if not url.startswith(('https://', 'http://')):
        raise HTTPException(400, 'Please enter a full http:// or https:// URL.')
    try:
        info = extract(url)
    except Exception as e:
        raise HTTPException(422, f'Could not analyze this URL: {friendly_error(e)}')
    videos, audios = [], []
    for f in info.get('formats') or []:
        if not f.get('format_id'):
            continue
        vcodec, acodec = f.get('vcodec'), f.get('acodec')
        size = f.get('filesize') or f.get('filesize_approx')
        if vcodec and vcodec != 'none':
            videos.append({'id': str(f['format_id']), 'label': f"{f.get('height') or '?'}p{f.get('fps') or ''} {f.get('ext','').upper()} · {f.get('vcodec','')}",
                           'height': f.get('height') or 0, 'fps': f.get('fps') or 0, 'ext': f.get('ext') or '',
                           'vcodec': vcodec, 'filesize': size or 0, 'filesize_str': fmt_size(size),
                           'has_audio': bool(acodec and acodec != 'none')})
        elif acodec and acodec != 'none':
            audios.append({'id': str(f['format_id']), 'label': f"{f.get('ext','').upper()} Audio · {f.get('abr') or '?'} kbps",
                           'ext': f.get('ext') or '', 'acodec': acodec, 'abr': f.get('abr') or 0,
                           'filesize': size or 0, 'filesize_str': fmt_size(size)})
    if not videos and not audios and info.get('url'):
        videos.append({'id': 'best', 'label': f"Best available {info.get('ext','').upper()}", 'height': 0, 'fps': 0,
                       'ext': info.get('ext') or '', 'vcodec': '', 'filesize': 0, 'filesize_str': 'Unknown', 'has_audio': True})
    videos.sort(key=lambda x: (x['height'], x['fps']), reverse=True)
    audios.sort(key=lambda x: x['abr'], reverse=True)
    return {'title': info.get('title') or 'Video', 'thumbnail': info.get('thumbnail') or '',
            'duration_str': info.get('duration_string') or '', 'uploader': info.get('uploader') or info.get('channel') or '',
            'video_formats': videos, 'audio_formats': audios}

class Cancelled(Exception): pass

def run_download(task_id: str, req: DownloadRequest):
    task = TASKS[task_id]
    try:
        if req.audio_only:
            if not req.audio_format_id:
                raise ValueError('Select an audio format first.')
            fmt = req.audio_format_id
            postprocessors = [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'm4a', 'preferredquality': '0'}]
        else:
            if not req.video_format_id:
                raise ValueError('Select a video quality first.')
            fmt = req.video_format_id
            if req.audio_format_id:
                fmt = f'{req.video_format_id}+{req.audio_format_id}'
            postprocessors = []
        def hook(d):
            if task['cancel'].is_set():
                raise Cancelled('Download cancelled by user')
            if d.get('status') == 'downloading':
                total = d.get('total_bytes') or d.get('total_bytes_estimate') or 0
                done = d.get('downloaded_bytes') or 0
                task.update({'status':'downloading', 'downloaded':done, 'total':total,
                             'percent': round(done * 100 / total, 1) if total else 0,
                             'speed': d.get('speed') or 0, 'eta': d.get('eta'),
                             'message': 'Downloading media…'})
            elif d.get('status') == 'finished':
                task.update({'percent': 99, 'message':'Processing / merging media…'})
        opts = {**base_opts(), 'format': fmt, 'outtmpl': str(DOWNLOAD_DIR / f'{task_id}_%(title).140B.%(ext)s'),
                'progress_hooks':[hook],
                'postprocessors':postprocessors, 'merge_output_format':'mp4',
                'restrictfilenames': True, 'continuedl': True}
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([req.url])
        matches = sorted(DOWNLOAD_DIR.glob(task_id + '_*'), key=lambda p:p.stat().st_mtime, reverse=True)
        if not matches:
            raise RuntimeError('Download completed but output file was not found.')
        file = matches[0]
        task.update({'status':'completed','percent':100,'message':'Download completed.','file':str(file),
                     'filename':file.name, 'total':file.stat().st_size, 'downloaded':file.stat().st_size})
    except Cancelled:
        task.update({'status':'cancelled','message':'Download cancelled.'})
        for p in DOWNLOAD_DIR.glob(task_id + '_*'):
            try: p.unlink()
            except OSError: pass
    except Exception as e:
        task.update({'status':'failed','message':friendly_error(e)})

@app.post('/api/download')
def start_download(req: DownloadRequest):
    if not req.url.startswith(('https://','http://')):
        raise HTTPException(400, 'Invalid URL')
    task_id = uuid.uuid4().hex
    TASKS[task_id] = {'id':task_id,'status':'queued','percent':0,'downloaded':0,'total':0,
                      'speed':0,'eta':None,'message':'Queued','cancel':threading.Event()}
    threading.Thread(target=run_download, args=(task_id,req), daemon=True).start()
    return {'task_id':task_id}

@app.get('/api/tasks/{task_id}')
def task_status(task_id: str):
    task = TASKS.get(task_id)
    if not task: raise HTTPException(404, 'Task not found')
    return {k:v for k,v in task.items() if k not in ('cancel','file')}

@app.post('/api/tasks/{task_id}/cancel')
def cancel(task_id: str):
    task = TASKS.get(task_id)
    if not task: raise HTTPException(404, 'Task not found')
    task['cancel'].set()
    return {'ok':True}

@app.get('/api/tasks/{task_id}/file')
def get_file(task_id: str):
    task = TASKS.get(task_id)
    if not task or task.get('status') != 'completed' or not task.get('file'):
        raise HTTPException(404, 'Download file is not ready')
    file = Path(task['file'])
    if not file.exists(): raise HTTPException(404, 'File no longer exists')
    return FileResponse(file, filename=task.get('filename') or file.name, media_type='application/octet-stream')

@app.get('/manifest.json')
def manifest():
    return JSONResponse({'name': 'Video Downloader', 'short_name': 'Downloader', 'start_url': '/',
                         'display': 'standalone', 'background_color': '#f1f5f9', 'theme_color': '#2563eb'})

@app.get('/health')
def health(): return {'ok': True, 'yt_dlp': yt_dlp.version.__version__, 'ffmpeg': bool(shutil.which('ffmpeg')),
                      'js_runtime': next((n for n in ('deno', 'node', 'bun') if shutil.which(n)), None)}
