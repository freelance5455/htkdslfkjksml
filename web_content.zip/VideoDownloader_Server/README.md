# VideoDownloader — Server-backed edition

This version fixes the two confirmed functional gaps in the browser-only ZIP:

1. **Real analysis:** `/api/analyze` calls `yt-dlp` on the server and returns the actual title, thumbnail, duration, video formats and audio-only formats. It no longer displays hard-coded demo qualities.
2. **Real download management:** `/api/download` starts a server-side `yt-dlp` job. The mobile UI polls real progress, speed and ETA, supports cancellation, and downloads the completed file from the server. FFmpeg is installed in the Docker image to merge separate audio/video streams and extract audio.

## Deploy online (phone-friendly)

This is a backend web app, not a static ZIP-to-APK website. It must be deployed to a Python-capable host. Easiest route:

1. Upload this folder to a GitHub repository.
2. Create a new Web Service on Render and connect the repository.
3. Choose **Docker** deployment (the included `Dockerfile` installs FFmpeg and Python dependencies).
4. Deploy. Open the generated HTTPS URL on your Android phone.
5. Optional: use Chrome menu → Add to Home screen.

`render.yaml` is included as a starting configuration. The service needs persistent disk storage if you want downloads to survive restarts; otherwise completed files are temporary. Configure a persistent disk mounted at `/app/downloads` on your hosting provider if available.

## Run locally

```bash
python -m venv .venv
# activate the environment, then:
pip install -r requirements.txt
# install FFmpeg separately and ensure `ffmpeg` is on PATH
uvicorn app:app --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000`.

## Notes and limitations

- Site support depends on the current `yt-dlp` extractors and the source site's access rules. Some URLs may fail, require sign-in/cookies, be private, geo-restricted, or be unavailable. No extractor can guarantee every site/link.
- The app does not bypass DRM, paywalls, private access controls, or other technical restrictions. Download only material you own or are authorized to download, and follow the source site's terms and applicable law.
- This demo server keeps task state in memory and is intended for personal testing. Restarting/redeploying clears task status. Production use should add authentication, per-user task isolation, quotas, cleanup/retention, and persistent job storage. Do not expose an unauthenticated public instance to arbitrary users.
- Hosting providers may impose CPU, bandwidth, storage and execution limits. Large video downloads may exceed free-tier limits. A server must have enough temporary disk space for the media and merged output.
- Android browser download behavior can vary. The completed file is served as an attachment; Chrome should show its normal download notification.

## Troubleshooting "Failed to fetch" (fixed in this version)

"Failed to fetch" means the page could not reach the server at all. Common causes:

- The server is asleep/restarting (free hosting plans) — wait ~60 s and retry. Open `<your-url>/health` to confirm it is up.
- The page was opened as a local file or from another domain — open it from the deployed URL, or tap **Server** in the header and enter your server address.
- YouTube needs a JavaScript runtime — the Dockerfile now installs Deno (check `/health` → `js_runtime`).
- YouTube blocks many datacenter IPs ("confirm you're not a bot"). Fix: export your YouTube cookies (Netscape format, cookies.txt) and set the env var `YTDLP_COOKIES` to the file's contents (or `YTDLP_COOKIES_FILE` to a path). Optionally set `YTDLP_PROXY`.
- Redeploy regularly: yt-dlp breaks when YouTube changes; the Dockerfile installs the newest yt-dlp on each build.
