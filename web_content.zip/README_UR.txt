Driver Speed & Route - APK Build Kit

Included:
- Driver_Speed_Route_Flutter_Project.zip (Flutter source plus index.html web demo)
- build.yml (GitHub Actions workflow template)
- index.html (standalone HTML web demo)

Important:
- This kit does NOT contain a compiled APK.
- GitHub Actions must run the build online before an APK can be downloaded.
- Create a GitHub repository.
- Upload Driver_Speed_Route_Flutter_Project.zip to the repository root.
- Create .github/workflows/build.yml and paste the contents of build.yml.
- Open Actions, select "Build Driver Speed Route APK", then choose "Run workflow".
- When successful, download the Driver-Speed-Route-APK artifact and extract app-release.apk.
- GitHub Actions is free only within the applicable usage quota.
- index.html is a web demo; the Android APK is built from the Flutter source, not from HTML.
