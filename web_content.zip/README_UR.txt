Food Online — Corrected Grocery Prototype

اس ورژن میں پچھلے مسئلے درست کیے گئے ہیں:
- نامناسب/random تصاویر کے لیے generic grocery query ختم کی گئی ہے۔
- سبزی، پھل، خشک میوہ، آٹا، چاول، دال، راشن اور مصالحہ ہر ایک کے لیے مخصوص image query رکھی گئی ہے۔
- duplicate product name کو ایک ہی بار رکھا گیا ہے۔
- ہر product کا ایک card ہے۔
- image card کا سائز compact square-style grocery display کے مطابق رکھا گیا ہے۔
- Cat, wine/alcohol, AC یا غیر متعلقہ تصویر intentionally catalog میں شامل نہیں کی گئی۔
- Ajinomoto/MSG شامل نہیں ہے۔

نوٹ: remote photographic image services کبھی کبھار search-result بدل سکتی ہیں؛ Play Store release سے پہلے images کو اپنی owned/licensed photos سے replace کرنا بہتر ہے۔
یہ prototype ہے؛ Firebase, secure admin, live prices اور production signing ابھی شامل نہیں۔
