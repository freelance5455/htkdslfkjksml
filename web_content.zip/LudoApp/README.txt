BUILD THE APK
1. Install Android Studio (free).  2. File > Open > select the LudoApp folder.
3. Wait for Gradle sync.  4. Build > Build Bundle(s)/APK(s) > Build APK(s).
5. Find it at app/build/outputs/apk/debug/app-debug.apk and install it on your phone.
