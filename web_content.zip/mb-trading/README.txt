MB TRADING (demo, no real money)

1. Extract this zip.
2. Open index.html in Chrome or Safari.
3. To host it, upload index.html to any static host (Netlify, GitHub Pages, Vercel).
