# PRIMExLODER Android project

This is a starter Android Studio project for a standalone launcher-style UI demo.
It does not inject into BGMI, modify game files, or implement cheat/anti-cheat bypass.

## Build
1. Install Android Studio.
2. Open this folder as a project.
3. Allow Gradle sync.
4. Choose Build > Build APK(s).
5. Install the generated APK on your Android device.

The key field is a UI demonstration only; no real key validation/backend is connected.
