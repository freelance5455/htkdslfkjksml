(function () {
  var MULTIPLIER = 2.6;

  var SKIN_PALETTES = {
    "Yaltiroq Oltin": {
      colors: ["#ffd32a", "#fff200", "#ff9f1a", "#ffffff"],
      ring: "#ffeaa7",
      speed: 0.015
    },
    "Neon Kamalak": {
      colors: ["#00f2fe", "#4facfe", "#ff0844", "#38ef7d", "#feca57"],
      ring: "#00f2fe",
      speed: 0.02
    },
    "Zumrad Jilo": {
      colors: ["#00e676", "#1de9b6", "#aeea00", "#ffffff"],
      ring: "#1de9b6",
      speed: 0.014
    },
    "Kristal Binafsha": {
      colors: ["#d500f9", "#7c4dff", "#ff4081", "#80d8ff"],
      ring: "#d500f9",
      speed: 0.016
    }
  };

  function getSelectedSkin() {
    try {
      var keys = ["brawl_uz_progress_v2", "brawl_uz_progress_v1"];
      for (var i = 0; i < keys.length; i++) {
        var raw = localStorage.getItem(keys[i]);
        if (raw) {
          var p = JSON.parse(raw);
          if (p && p.selectedSkin) return p.selectedSkin;
        }
      }
    } catch (e) {}
    return "Klassik";
  }

  function getActivePalette() {
    var sk = getSelectedSkin();
    if (SKIN_PALETTES[sk]) return SKIN_PALETTES[sk];
    if (sk.indexOf("Oltin") !== -1) return SKIN_PALETTES["Yaltiroq Oltin"];
    if (sk.indexOf("Ajdaho") !== -1 || sk.indexOf("Olmos") !== -1) return SKIN_PALETTES["Neon Kamalak"];
    if (sk.indexOf("Soya") !== -1) return SKIN_PALETTES["Kristal Binafsha"];
    return {
      colors: ["#ffd32a", "#00f2fe", "#ff6b6b", "#ffffff"],
      ring: "#ffd32a",
      speed: 0.012
    };
  }

  function getShimmerColor(pal, offset) {
    var cols = pal.colors;
    var idx = Math.floor((Date.now() * (pal.speed || 0.012) + (offset || 0)) % cols.length);
    return cols[idx];
  }

  function boostBulletArray(arr, pal) {
    if (!Array.isArray(arr)) return;
    for (var i = 0; i < arr.length; i++) {
      var b = arr[i];
      if (!b || typeof b !== "object") continue;

      var fromPlayer =
        b.fromPlayer === true ||
        b.isPlayer === true ||
        b.owner === "player" ||
        (typeof player !== "undefined" && player && (b.owner === player || b.shooter === player));

      if (fromPlayer || !b.owner) {
        if (!b._dmgBoosted) {
          if (typeof b.damage === "number" && b.damage > 0) {
            b.damage = Math.round(b.damage * MULTIPLIER);
            b._dmgBoosted = true;
          } else if (typeof b.dmg === "number" && b.dmg > 0) {
            b.dmg = Math.round(b.dmg * MULTIPLIER);
            b._dmgBoosted = true;
          } else if (typeof b.power === "number" && b.power > 0) {
            b.power = Math.round(b.power * MULTIPLIER);
            b._dmgBoosted = true;
          }
        }

        var shimmer = getShimmerColor(pal, i * 1.7);
        if ("color" in b) b.color = shimmer;
        if ("fill" in b) b.fill = shimmer;
        if ("stroke" in b) b.stroke = "#ffffff";
      }
    }
  }

  function boostPlayerDamageProps() {
    var targets = [];
    if (typeof player !== "undefined" && player && typeof player === "object") targets.push(player);
    if (typeof players !== "undefined" && Array.isArray(players) && players[0]) targets.push(players[0]);

    for (var i = 0; i < targets.length; i++) {
      var p = targets[i];
      if (!p._baseDmgBoosted) {
        if (typeof p.damage === "number" && p.damage > 0) {
          p.damage = Math.round(p.damage * MULTIPLIER);
          p._baseDmgBoosted = true;
        }
        if (typeof p.bulletDamage === "number" && p.bulletDamage > 0) {
          p.bulletDamage = Math.round(p.bulletDamage * MULTIPLIER);
          p._baseDmgBoosted = true;
        }
        if (typeof p.attackPower === "number" && p.attackPower > 0) {
          p.attackPower = Math.round(p.attackPower * MULTIPLIER);
          p._baseDmgBoosted = true;
        }
      }
    }
  }

  function drawShinyEffects(ctx, pal) {
    var names = ["bullets", "projectiles", "shots", "missiles", "lasers", "attacks"];
    for (var i = 0; i < names.length; i++) {
      var n = names[i];
      if (typeof window[n] === "undefined" || !Array.isArray(window[n])) continue;
      var arr = window[n];
      for (var j = 0; j < arr.length; j++) {
        var b = arr[j];
        if (!b || typeof b.x !== "number" || typeof b.y !== "number") continue;
        var fromPlayer =
          b.fromPlayer === true ||
          b.isPlayer === true ||
          b.owner === "player" ||
          (typeof player !== "undefined" && player && (b.owner === player || b.shooter === player));
        if (!fromPlayer && b.owner) continue;

        var c1 = getShimmerColor(pal, j * 1.4);
        var c2 = getShimmerColor(pal, j * 1.4 + 2.1);

        ctx.save();
        ctx.globalAlpha = 0.72;
        ctx.fillStyle = c1;
        ctx.beginPath();
        ctx.arc(b.x, b.y, 10, 0, Math.PI * 2);
        ctx.fill();

        ctx.globalAlpha = 0.96;
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(b.x, b.y, 4.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = c2;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(b.x, b.y, 13.5, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    // Agar yaltillovchi skin tanlangan bo'lsa, personaj atrofida jilo halqasi chizamiz
    var sk = getSelectedSkin();
    if (SKIN_PALETTES[sk] && typeof player !== "undefined" && player && typeof player.x === "number") {
      var t = Date.now() * 0.008;
      var pulse = 23 + Math.sin(t) * 3.5;
      ctx.save();
      ctx.strokeStyle = getShimmerColor(pal, 0.5);
      ctx.lineWidth = 2.5;
      ctx.globalAlpha = 0.8;
      ctx.beginPath();
      ctx.arc(player.x, player.y, pulse, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  function tick() {
    var pal = getActivePalette();
    boostPlayerDamageProps();
    var names = ["bullets", "projectiles", "shots", "missiles", "lasers", "attacks"];
    for (var i = 0; i < names.length; i++) {
      var n = names[i];
      if (typeof window[n] !== "undefined" && Array.isArray(window[n])) {
        boostBulletArray(window[n], pal);
      }
    }

    var canvas = document.querySelector("canvas");
    if (canvas) {
      var ctx = canvas.getContext("2d");
      if (ctx) drawShinyEffects(ctx, pal);
    }
  }

  window.addEventListener("load", function () {
    setInterval(tick, 33);
  });
})();
