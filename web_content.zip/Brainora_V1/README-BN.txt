# Brainora V1 – বাংলা Brain Test

এটি Brainora-এর প্রথম playable Version 1 prototype।

## ফিচার
- ২০টি বাংলা Brain Test প্রশ্ন
- Logic, Math, Pattern, Tricky, Memory ও Observation
- ২০ সেকেন্ড Timer
- Score + Accuracy + Best Score
- ৩টি Hint
- Home / Game / Result screen
- Offline-এ ব্রাউজারে চালানো যায়
- PWA manifest যুক্ত আছে

## ফোনে চালানো
1. `index.html`, `style.css`, `app.js`, `manifest.json` এবং `assets` ফোল্ডার একই জায়গায় রাখুন।
2. `index.html` Chrome-এ খুলে গেম চালিয়ে দেখুন।

## APK বানানো
এই Version-টি HTML ভিত্তিক। APK বানাতে কোনো Android WebView/App Builder-এ এই project-এর `index.html`-কে local start page হিসেবে ব্যবহার করা যাবে। Build/Export থেকে APK বের করতে হবে।

পরের Version-এ চাইলে:
- ১০০+ প্রশ্ন
- সুন্দর Brainora logo/icon
- Sound effects
- Daily Challenge
- Leaderboard
- Ads
- বাংলা/English language switch
- Play Store-ready package
যোগ করা যাবে।
