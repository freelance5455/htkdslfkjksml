const questions=[
 {c:"LOGIC",q:"একটি ঘরে ৫টি মোমবাতি জ্বলছিল। ২টি নিভিয়ে দিলে কয়টি থাকবে?",a:["২টি","৩টি","৫টি","০টি"],x:0,h:"নেভালেও মোমবাতিগুলো ঘরেই থাকে।"},
 {c:"MATH",q:"৫ + ৫ × ২ = ?",a:["২০","১৫","২৫","১০"],x:1,h:"আগে গুণ, পরে যোগ।"},
 {c:"PATTERN",q:"২, ৪, ৮, ১৬, ?",a:["২০","২৪","৩২","৩৬"],x:2,h:"প্রতিবার আগের সংখ্যাকে ২ দিয়ে গুণ।"},
 {c:"TRICKY",q:"কোন মাসে ২৮ দিন আছে?",a:["ফেব্রুয়ারি","জানুয়ারি","সব মাসে","শুধু লিপ ইয়ারে"],x:2,h:"প্রতিটি মাসেই অন্তত ২৮ দিন আছে।"},
 {c:"MATH",q:"১০০ থেকে ১০ বাদ দিলে কত থাকে?",a:["৯০","১০","৮০","০"],x:0,h:"সহজ বিয়োগ।"},
 {c:"MEMORY",q:"একটি পাখির ২টি ডানা। ৩টি পাখির মোট কয়টি ডানা?",a:["৩","৫","৬","৮"],x:2,h:"প্রতি পাখিতে ২টি।"},
 {c:"LOGIC",q:"তুমি দৌড়ে ২য় ব্যক্তিকে পেরিয়ে গেলে তুমি কত নম্বরে?",a:["১ম","২য়","৩য়","৪র্থ"],x:1,h:"তুমি ২য় ব্যক্তির জায়গা নেবে।"},
 {c:"MATH",q:"১২ ÷ ৩ + ২ = ?",a:["২","৪","৬","৮"],x:2,h:"আগে ভাগ: ৪, তারপর +২।"},
 {c:"OBSERVE",q:"কোনটি অন্যগুলোর মতো নয়?",a:["আপেল","আম","গাজর","কলা"],x:2,h:"গাজর ফল নয়।"},
 {c:"PATTERN",q:"১, ১, ২, ৩, ৫, ৮, ?",a:["১১","১২","১৩","১৫"],x:2,h:"আগের দুই সংখ্যার যোগফল।"},
 {c:"TRICKY",q:"একজন কৃষকের ১০টি ভেড়া ছিল। ৯টি ছাড়া সব মারা গেল। বাকি কয়টি?",a:["১টি","৯টি","০টি","১০টি"],x:1,h:"'৯টি ছাড়া সব' মানে ৯টি বেঁচে আছে।"},
 {c:"MATH",q:"এক ডজনের অর্ধেক কত?",a:["৪","৬","৮","১২"],x:1,h:"এক ডজন = ১২।"},
 {c:"LOGIC",q:"একটি ঘড়িতে ৩টা বাজে। ৩ ঘণ্টা পর কয়টা বাজবে?",a:["৫টা","৬টা","৭টা","৮টা"],x:1,h:"৩ + ৩ = ৬।"},
 {c:"PATTERN",q:"৩, ৬, ৯, ১২, ?",a:["১৪","১৫","১৬","১৮"],x:1,h:"প্রতি ধাপে +৩।"},
 {c:"TRICKY",q:"তোমার কাছে ৩টি আপেল। ২টি নিয়ে নিলে তোমার কাছে কয়টি?",a:["১টি","২টি","৩টি","৫টি"],x:1,h:"তুমি ২টি নিয়েছ।"},
 {c:"MATH",q:"৭ × ৩ − ৫ = ?",a:["১৪","১৬","১৮","২১"],x:1,h:"২১ − ৫ = ১৬।"},
 {c:"OBSERVE",q:"কোন শব্দটি আলাদা?",a:["নীল","লাল","সবুজ","চেয়ার"],x:3,h:"চেয়ার কোনো রং নয়।"},
 {c:"LOGIC",q:"একটি কলম ও পেন্সিলের মোট দাম ৩০ টাকা। কলম ২০ টাকা হলে পেন্সিল?",a:["৫","১০","১৫","২০"],x:1,h:"৩০ − ২০ = ১০।"},
 {c:"MEMORY",q:"মনে রাখো: 🍎 🟡 🍀 🔵। প্রথম চিহ্নটি কী ছিল?",a:["🔵","🍀","🍎","🟡"],x:2,h:"প্রথমটি ছিল আপেল।"},
 {c:"FINAL",q:"কোনটি বড়: ০.৯ নাকি ০.০৯?",a:["০.০৯","০.৯","সমান","জানা যায় না"],x:1,h:"দশমিকে ০.৯ = ০.৯০।"}
];

let index=0,score=0,correct=0,hints=3,timerId=null,timeLeft=20;
const $=id=>document.getElementById(id);
function show(id){document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));$(id).classList.add("active")}
function best(){return Number(localStorage.getItem("brainoraBest")||0)}
function toast(t){$("toast").textContent=t;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),1600)}
function start(){index=0;score=0;correct=0;hints=3;$("hints").textContent=hints;show("game");loadQuestion()}
function loadQuestion(){
 clearInterval(timerId); const q=questions[index]; timeLeft=20;
 $("qNo").textContent=index+1;$("score").textContent=score;$("category").textContent=q.c;
 $("question").textContent=q.q;$("feedback").textContent="";$("timer").textContent=timeLeft;
 $("progressBar").style.width=((index+1)/questions.length*100)+"%";
 const box=$("answers");box.innerHTML="";
 q.a.forEach((text,i)=>{const b=document.createElement("button");b.className="answer";b.textContent=text;b.onclick=()=>answer(i,b);box.appendChild(b)});
 timerId=setInterval(()=>{timeLeft--;$("timer").textContent=timeLeft;if(timeLeft<=0){clearInterval(timerId);answer(-1,null)}},1000)
}
function answer(choice,button){
 clearInterval(timerId);document.querySelectorAll(".answer").forEach(b=>b.classList.add("disabled"));
 const q=questions[index];
 if(choice===q.x){correct++;score+=10+timeLeft;$("score").textContent=score;if(button)button.classList.add("correct");$("feedback").textContent="✅ সঠিক উত্তর!";}
 else{if(button)button.classList.add("wrong");document.querySelectorAll(".answer")[q.x].classList.add("correct");$("feedback").textContent="❌ সঠিক উত্তর: "+q.a[q.x]}
 setTimeout(()=>{index++;index<questions.length?loadQuestion():finish()},850)
}
function finish(){
 clearInterval(timerId);const old=best();if(score>old)localStorage.setItem("brainoraBest",score);
 $("finalScore").textContent=score;$("correct").textContent=correct;$("accuracy").textContent=Math.round(correct/questions.length*100)+"%";$("best").textContent=best();$("bestHome").textContent=best();show("result")
}
$("startBtn").onclick=start;$("dailyBtn").onclick=()=>{toast("Daily Challenge শীঘ্রই আসছে!");start()}
$("againBtn").onclick=start;$("homeBtn").onclick=()=>{ $("bestHome").textContent=best();show("home") };
$("quitBtn").onclick=()=>{if(confirm("গেম বন্ধ করে Home-এ যাবেন?")){clearInterval(timerId);show("home")}}
$("hintBtn").onclick=()=>{if(hints<=0){toast("আর কোনো Hint নেই");return}hints--;$("hints").textContent=hints;$("feedback").textContent="💡 "+questions[index].h}
$("howBtn").onclick=()=>alert("প্রতিটি প্রশ্নের উত্তর দেওয়ার জন্য ২০ সেকেন্ড সময় পাবেন। সঠিক উত্তরে পয়েন্ট পাবেন। Hint ব্যবহার করলে একটি Hint কমবে।");
$("bestHome").textContent=best();
