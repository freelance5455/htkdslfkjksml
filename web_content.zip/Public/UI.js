


   
var PlayerNameField = document.getElementById("fname"),
    HostNameField = document.getElementById("lname"),
    LocalPlayerDot = document.getElementById("playerCol"),
    LocalPlayerName = document.getElementById("localplname"),
    winnerName = document.getElementById("winner"),
    hostID = document.getElementById("hostID");


var Pannels = [document.getElementById("HostScreen"),                      //0
    document.getElementById("JoinScreen"),                                 //1
    document.getElementById("LobbyHost"),                                  //2
    document.getElementById("StartConfirm"),                               //3
    document.getElementById("CountDown"),                                  //4
    document.getElementById("LobbyClient"),                                //5
    document.getElementById("GameEnd")]                                    //6

var Rounds = document.getElementById("rounds");


var clientMessage = document.getElementById("clientmessage");
clientMessage.innerHTML = "Loading ..";   

switchPannel(5);  

var interval = setInterval(function() {
    if(document.readyState === 'complete') {
        clearInterval(interval);
        switchPannel(0);
    }    
}, 300);

function switchPannel(int){
    
    for(var i = 0; i <Pannels.length; i++){
        if(i == int) Pannels[i].style.display = "block";
        else Pannels[i].style.display = "none";
    }
}

function onHostClicked(){

    let pname = PlayerNameField.value;

    if(pname.length < 4){ 
        showToast("Player name needs to be at least 4 characters long");
        return;
    }

    Host(pname);

    switchPannel(2);

    setHostUI(true);
}

function OnPracticeClicked(){
    let pname = PlayerNameField.value;

    if(pname.length < 4){ 
        showToast("Player name needs to be at least 4 characters long");
        return;
    }

    Host(pname);

    addCPUplayer();

    switchPannel(2);

    setHostUI(true);
}


function onJoinClicked(){

    let pname = PlayerNameField.value;

    if(pname.length < 4){ 
        showToast("Player name needs to be at least 4 characters long");
        return;
    }

    Create(pname);

    switchPannel(1);    

    setHostUI(false);

}

function onConnectClicked(){

    let hname = HostNameField.value;

    let pname = PlayerNameField.value;

    

    clientMessage.innerHTML = "Connecting ..";    


    Join(pname, hname);

    switchPannel(5);  
}



function setHostID(id){
    hostID.innerHTML = "Host ID : " + id ;
}
function copyHostID(){

    if(peer && peer.id){
        navigator.clipboard.writeText(peer.id).then(() => {
            alert("ID copied");
        });

        
    }
}



function handlevaluechanged1(){
    
    let str = PlayerNameField.value;
    str = str.replace(/[\W_]+/g,"");
    PlayerNameField.value = str;
    
}

function handlevaluechanged2(){
    return;
    let str = HostNameField.value;
    str = str.replace(/[\W_]+/g,"");
    HostNameField.value = str;
    
}



var rnds = 3;
Rounds.innerHTML = "Rounds : " + rnds;

function onRoundInc(){
    rnds += 2;
    if(rnds > 8) rnds = 1;

    Rounds.innerHTML = "Rounds : " + rnds;
}

function onStartHost(){
    switchPannel(3);
}


function onConfirmStart(){
    
    
    sendCountdown();     
}

function onRejectStart(){
    switchPannel(2);
}




var Toast = document.getElementById("toastBack"),
    ToastText = document.getElementById("toast");
function showToast(message){

    Toast.style.display = "block";
    
    ToastText.innerHTML = "⚠<br>" + message;
}
function toastclicked(){
    Toast.style.display = "none";
    ToastText.innerHTML = "";
}

var ldb = document.getElementById("leaderboard").getElementsByTagName("tr");

function tEntry(_name, _score, ){
    this.name = _name;
    this.score = _score;
}



function updateLeaderboard(data){
    
    
    
    data.shift();

    let array = [];
    if(data.length != gPlayers.length) return;

    for(let n = 0; n < gPlayers.length; n++ ){
        
        array.push(new tEntry(gPlayers[n].id, data[n]));
    }

    
    array.sort((a, b) => b.score - a.score);
    

    clearLeaderboard();

    for(let r = 0; r < array.length; r++){
        if(array[r].name == LocalPlayerName) {
            ldb[r].cells[1].style.color = "#96f2ff";
            ldb[r].cells[1].style.textShadow = "0 0 5px #96f2ff";

            ldb[r].cells[2].style.color = "#96f2ff)";
            ldb[r].cells[2].style.textShadow = "0 0 5px #96f2ff";
        }
        else{
            ldb[r].cells[1].style.color = "#80ced9";
            ldb[r].cells[1].style.textShadow = "none";

            ldb[r].cells[2].style.color = "#80ced9";
            ldb[r].cells[2].style.textShadow = "none";
        }
        ldb[r].cells[0].style.backgroundColor = hexGenerator(array[r].name, false);
        ldb[r].cells[1].innerHTML = array[r].name;
        ldb[r].cells[2].innerHTML = array[r].score == 0 ? "" : array[r].score;
    }

    if(array.length > 0) winnerName.innerHTML = array[0].name;

}

function clearLeaderboard(){

    for(let i = 0; i < ldb.length; i++){
    
        ldb[i].cells[0].style.backgroundColor = "transparent";
        ldb[i].cells[1].innerHTML = "";
        ldb[i].cells[2].innerHTML = "";
    }

}




var ctdntext = Pannels[4].getElementsByClassName("ctdn");

function startCountdown(){
    ct=0;
    ctdntext[0].innerHTML = " ";
    switchPannel(4);
    UIcountdown();
}

let ct = 0;
function UIcountdown(){
    

    

    if(ct > 0) ctdntext[ct-1].style.display = "none";
    if(ct > 4) { ct = 0; return;}
    ctdntext[ct].style.display = "block";
    
    ct++;    

    setTimeout(UIcountdown,ct > 3 ? 400 : 1000);
     



    
}

function gameEnded(){

    switchPannel(6);
}


function roundUI(data){
    if(!data[1]) return;

    ctdntext[0].innerHTML = data[1];
    ctdntext[0].style.display = "block";

    switchPannel(4);

}

function onBackToMainMenu(){
    window.location.reload();
}

var playagain = document.getElementById("playagain");

function setHostUI(isHost){ playagain.style.display = isHost ? "block" : "none"; }

function onRestartGame(){

    if(!game) return;

    Players.forEach(function(item) {
        item.score = 0;
    });     

    game = null;
    
    onConfirmStart();

    
}