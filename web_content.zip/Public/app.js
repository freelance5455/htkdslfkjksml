
const videoInput = document.getElementById("videoUrl");
const pasteBtn = document.getElementById("pasteBtn");
const downloadBtn = document.getElementById("downloadBtn");
const permission = document.getElementById("permission");
const message = document.getElementById("message");
const result = document.getElementById("result");
const preview = document.getElementById("preview");
const saveBtn = document.getElementById("saveBtn");

function isTikTokUrl(value) {
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();

    return (
      url.protocol === "https:" &&
      (
        host === "tiktok.com" ||
        host.endsWith(".tiktok.com")
      )
    );
  } catch {
    return false;
  }
}

pasteBtn.addEventListener("click", async () => {
  try {
    videoInput.value = await navigator.clipboard.readText();
    message.textContent = "Link berhasil ditempel.";
  } catch {
    message.textContent =
      "Clipboard tidak tersedia. Silakan tempel secara manual.";
  }
});

videoInput.addEventListener("input", () => {
  message.textContent = "";
  result.classList.add("hidden");
  preview.pause();
  preview.removeAttribute("src");
  saveBtn.removeAttribute("href");
});

downloadBtn.addEventListener("click", async () => {
  const url = videoInput.value.trim();

  if (!url) {
    message.textContent = "Masukkan link TikTok terlebih dahulu.";
    return;
  }

  if (!isTikTokUrl(url)) {
    message.textContent = "Link TikTok tidak valid.";
    return;
  }

  if (!permission.checked) {
    message.textContent =
      "Konfirmasi izin pengunduhan terlebih dahulu.";
    return;
  }

  downloadBtn.disabled = true;
  downloadBtn.innerHTML = "Memproses...";
  message.textContent = "Sedang memeriksa video...";
  result.classList.add("hidden");

  try {
    const response = await fetch("/api/download", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ url })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Video tidak tersedia.");
    }

    if (!data.download_url) {
      throw new Error("Link download tidak ditemukan.");
    }

    const downloadUrl = new URL(data.download_url);

    if (downloadUrl.protocol !== "https:") {
      throw new Error("Alamat video tidak aman.");
    }

    saveBtn.href = downloadUrl.href;

    if (data.preview_url) {
      preview.src = data.preview_url;
      preview.classList.remove("hidden");
    } else {
      preview.removeAttribute("src");
      preview.classList.add("hidden");
    }

    result.classList.remove("hidden");
    message.textContent = "Video berhasil diproses!";
  } catch (error) {
    message.textContent =
      error.message || "Terjadi kesalahan saat memproses video.";
  } finally {
    downloadBtn.disabled = false;
    downloadBtn.innerHTML = "<span>↓</span> Download Video";
  }
});
