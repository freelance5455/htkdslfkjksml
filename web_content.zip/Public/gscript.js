


var app = new PIXI.Application(
    {
        view: document.getElementById('board'),
        antialias: true
    });

document.body.appendChild(app.view);


var backdrop, gr, pointerGrey, pointerGreen;

backdrop = new PIXI.Sprite.from('Public/Assets/backdrop.png');

app.stage.addChild(backdrop);


var PlayerSprite = PIXI.Texture.from('Public/Assets/Dragoon.png'),
    bitchipSprite0 = PIXI.Texture.from('Public/Assets/bitchip0.png'),
    bitchipSprite1 = PIXI.Texture.from('Public/Assets/bitchip1.png');


let Q = Math.PI / 3;

var semicircle = new PIXI.Graphics(), semicircle2 = new PIXI.Graphics(), semicircle3 = new PIXI.Graphics();
    

semicircle.lineStyle(2, 0x314344);
semicircle.arc(0, 0, 510, Q, 2*Q, false);


semicircle2.lineStyle(2, 0x314344);
semicircle2.arc(0, 0, 510,  3*Q, 4*Q, false); 

semicircle.addChild(semicircle2);

semicircle3.lineStyle(2, 0x314344);
semicircle3.arc(0, 0, 510, 5*Q, 6*Q, false); 

semicircle.addChild(semicircle3);

var l1 = new PIXI.Graphics(), l2 = new PIXI.Graphics(), l3 = new PIXI.Graphics();

l1.position.set(256, -442);
l1.lineStyle(2, 0x314344)    
    .lineTo(-512, 0);
semicircle.addChild(l1);

l2.position.set(510, 0);
l2.lineStyle(2, 0x314344)    
    .lineTo(-256, 442);
semicircle.addChild(l2);

l3.position.set(-510, 0);
l3.lineStyle(2, 0x314344)    
    .lineTo(256, 442);
semicircle.addChild(l3);

app.stage.addChild(semicircle);

gr = new PIXI.Graphics();
gr.beginFill(0x0e0d0f);
gr.lineStyle(2, 0x314344);  //(thickness, color)
gr.drawCircle(0, 0, 500);   //(x,y,radius)
gr.endFill(); 

g2 = new PIXI.Graphics();
g2.lineStyle(1, 0x1d2627);  //(thickness, color)
g2.drawCircle(0, 0, 350);   //(x,y,radius)
g2.endFill(); 

gr.addChild(g2);

app.stage.addChild(gr); 

pointerGrey = new PIXI.Sprite.from('Public/Assets/Pointer.png');
pointerGrey.blendMode = PIXI.BLEND_MODES.ADD;
pointerGrey.tint = 0x555555;
pointerGrey.anchor.set(0.5);
pointerGrey.zIndex = 1;
app.stage.addChild(pointerGrey);

pointerGreen = new PIXI.Sprite.from('Public/Assets/Pointer2.png');
pointerGreen.blendMode = PIXI.BLEND_MODES.SCREEN;
pointerGreen.anchor.set(0.5);
app.stage.addChild(pointerGreen);




var Xo, Yo, S, X2o, Y2o;

var RR, RRR, rf = 0.09, r = 90, rr = 450;

function getViewport() {

    var viewPortWidth;
    var viewPortHeight;
   
    // the more standards compliant browsers (mozilla/netscape/opera/IE7) use window.innerWidth and window.innerHeight
    if (typeof window.innerWidth != 'undefined') {
      viewPortWidth = window.innerWidth,
      viewPortHeight = window.innerHeight
    }
   
   // IE6 in standards compliant mode (i.e. with a valid doctype as the first line in the document)
    else if (typeof document.documentElement != 'undefined'
    && typeof document.documentElement.clientWidth !=
    'undefined' && document.documentElement.clientWidth != 0) {
       viewPortWidth = document.documentElement.clientWidth,
       viewPortHeight = document.documentElement.clientHeight
    }
   
    // older versions of IE
    else {
      viewPortWidth = document.getElementsByTagName('body')[0].clientWidth,
      viewPortHeight = document.getElementsByTagName('body')[0].clientHeight
    }
    return [viewPortWidth, viewPortHeight];
   } // width x height

Resize();

window.addEventListener('resize', Resize);

window.addEventListener("orientationchange", function() {
    Resize();
  }, false);


function Resize(){

    

    let viewport = getViewport();

    if(viewport && viewport[0] && viewport[1])
    {
        app.renderer.resize(viewport[0], viewport[1]);
    }
    
    X2o = viewport[0];
    Y2o = viewport[1];
    Xo = viewport[0] / 2,
    Yo = viewport[1] / 2;
    S = 0.00098 * Math.min(viewport[0], viewport[1]);
        
        

    if(gPlayers) gPlayers.forEach(function(itm){ if(itm.dummy){ itm.dummy.scale.x = S * 0.2; itm.dummy.scale.y = S * 0.2; } });

    RR = S*S*r*r;
    RRR = S*S*rr*rr;    

    backdrop.width = app.view.width;
    backdrop.height = app.view.height;

    gr.position.x = Xo;
    gr.position.y = Yo;
    gr.scale.x = S;
    gr.scale.y = S;

    semicircle.position.x = Xo;
    semicircle.position.y = Yo;
    semicircle.scale.x = S;
    semicircle.scale.y = S;
    


    pointerGrey.scale.x = 0.2 * S;
    pointerGrey.scale.y = 0.2 * S;

    pointerGreen.scale.x = 0.2 * S;
    pointerGreen.scale.y = 0.2 * S;

}


function gPlayer(_id){

    this.id = _id;

    this.dummy;   
    
    var parent = this;

    this.setPosition = function(x, y){
        

        if(x && y){

        x = S * x + Xo;
        y = S * y + Yo;

        if(!parent.dummy) parent.dummy = spawnSprite(x, y, parent.id);
        }else if (parent.dummy){
            //unspawn           
            die(parent.dummy, parent, _dT, parent.lastX, parent.lastY, parent.nextX, parent.nextY);
            parent.dummy = undefined;            

            return;
        }
        
        parent.lastX = parent.nextX;
        parent.lastY = parent.nextY;

        parent.nextX = x;
        parent.nextY = y;

    }

    this.lastX;
    this.lastY;
    this.nextX;
    this.nextY;

    this.lastCollider;

    this.clear = function(){

        if(parent.dummy) app.stage.removeChild(parent.dummy);
        parent.dummy = undefined;

        parent.lastX = undefined;
        parent.lastY = undefined;
        parent.nextX = undefined;
        parent.nextY = undefined;
        parent.lastCollider = undefined;

    }

}

function die(_sprite, parent, dt, lx, ly, nx, ny){    
    
    if (!document.hasFocus()){  
        app.stage.removeChild(_sprite);
        return;
    }
        
    

    let sprite = new PIXI.AnimatedSprite(framesCrash); 

    sprite.anchor.set(0.5);

    sprite.scale.x = 0.2 * S;
    sprite.scale.y = 0.2 * S;

    sprite.tint = 0xffd87b;//0x719a9c;    

    sprite.position.x = _sprite.position.x;
    sprite.position.y = _sprite.position.y;

    let bitchip = new PIXI.Sprite(bitchipSprite0);

    bitchip.anchor.set(0.5);
    bitchip.position.x = 0;
    bitchip.position.y = 0;

    bitchip.tint = 0xffd87b;//0x719a9c;

    sprite.addChild(bitchip);
    
    sprite.animationSpeed = 0.5;
    sprite.loop = false;

    sprite.onComplete = function () {
        // finished!         
        ticker.destroy(); 
        app.stage.removeChild(sprite);           
        parent.clear();                
      };

    sprite.play();

    let Vx = (nx-lx)/dt,
        Vy = (ny-ly)/dt; 


    let ticker = new PIXI.Ticker;
    let lastT = Date.now();
    ticker.add((delta) => 
    { 
        let _ddt = Date.now()-lastT;        
        sprite.rotation  = t/16;
        sprite.position.x += _ddt*Vx;
        sprite.position.y += _ddt*Vy;
        lastT = Date.now();
        bitchip.alpha -= _ddt/200;
    })
    ticker.start();

    app.stage.removeChild(_sprite);
    app.stage.addChild(sprite);

    return sprite;

}

function spawnSprite(x,y, _id){

    let sprite = new PIXI.Sprite(PlayerSprite);



    let bitchip = new PIXI.Sprite(_id == LocalPlayerName ? bitchipSprite0 : bitchipSprite1); //

    bitchip.anchor.set(0.5);
    bitchip.position.x = 0;
    bitchip.position.y = 0;

    sprite.addChild(bitchip);

    sprite.tint = hexGenerator(_id, true);

    sprite.anchor.set(0.5);

    sprite.scale.x = 0.2 * S;
    sprite.scale.y = 0.2 * S;
    

    sprite.position.x = x;
    sprite.position.y = y;

    app.stage.addChild(sprite);

    return sprite;

}


var gPlayers = [];

var buffer = [];

function updateGlist(data){


    if(data.length !=  1 + 2*gPlayers.length) return;

    else if(data[0])
    {        
        let l = buffer.length - 1;

        if(l < 1) buffer.push(data);
        else if(buffer[l] && buffer[l][0] && data[0] > buffer[l][0]) buffer.push(data);  

        if(!e && l > 1) e = Date.now() - buffer[0][0];
    }
    
}





function lerp(_dt, _dT, _l, _L){

    let r = _dt/_dT;
    if(r > 5) r = 5;

    return r*(_L-_l) + _l;

}

function checkCollision(sprite1, sprite2){

    if(!sprite1 || !sprite2) return false;

    let dx = sprite2.position.x - sprite1.position.x,
        dy = sprite2.position.y - sprite1.position.y;

    if(dy*dy + dx*dx < RR)
    {

        return {x:dx/2, y:dy/2};

    }

    return false;
}

function checkBoundarycollision(sprite){

    let dx = sprite.position.x - Xo,
        dy = sprite.position.y - Yo;

    if(dy*dy + dx*dx > RRR)
    {

        return {x:rf*dx, y:rf*dy};

    } 

}


var e;

var t, dellltaT = 20, lasttT = Date.now(), _dT;


app.ticker.add((delta) => {

   
    dellltaT = Date.now() - lasttT;
    lasttT = Date.now();
    

    if(!e) return;

    t = Date.now() - e;

    gPlayers.forEach(function(item){
        if(item.dummy) item.dummy.rotation = t/16;
    }); 

    
    if(buffer.length < 2) return;

    let nn = 1;
    while (nn) {
        
        nn = undefined;
        
        if(buffer.length > 2 && buffer[1][0] < t){
             buffer.shift(); 
             nn = 1;        
             
             if(!buffer[1]) console.log(buffer);
             _dT = buffer[1][0] - buffer[0][0];
             
             for(var i = 0; i < gPlayers.length; i++){
        
                gPlayers[i].setPosition(buffer[0][2*i+1], buffer[0][2*i+2]);           
                
            }
        }
    }

    if(buffer.length < 2) return;

    let dt = t - buffer[0][0];
    

    gPlayers.forEach(function(gplr)
    {
        if(gplr.dummy && gplr.nextX && gplr.nextY){            
            if(gplr.lastX && gplr.lastY)
            {                
                gplr.dummy.position.x = lerp(dt, _dT, gplr.lastX, gplr.nextX);
                gplr.dummy.position.y = lerp(dt, _dT, gplr.lastY, gplr.nextY);

                gPlayers.forEach(function(oplr){
                    if(oplr != gplr){
                        let colp = checkCollision(gplr.dummy, oplr.dummy);
                        
                        if(colp) makeSpark(gplr, colp, oplr.dummy);
                    }
                });

                let col2 = checkBoundarycollision(gplr.dummy);

                if(col2) makeSpark(gplr, col2, null);
            }
        }
    });




  });

  