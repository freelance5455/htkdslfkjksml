


var Engine = Matter.Engine,
Render = Matter.Render,
Runner = Matter.Runner,
Bodies = Matter.Bodies,
Events = Matter.Events,
Composite = Matter.Composite;

// create an engine
var engine = Engine.create();


engine.world.gravity.x = 0;
engine.world.gravity.y = 0;
engine.enableSleeping = false;
engine.positionIterations = 10;
/*
var render = Render.create({
    element: document.body,
    engine: engine   
   
});
render.canvas.height = 800;
render.canvas.width = 1200;
render.context.translate(600, 400);
render.context.scale(0.5,0.5);
Render.run(render);*/

const boxpointlist =
[
    {x:	0	,y:	753	,a:	0	,bs:	522	},
    {x:	-198.03	,y:	544.082	,a:	0.349066	,bs:	174	},
    {x:	-570.204	,y:	-100.543	,a:	1.74533	,bs:	174	},
    {x:	-653	,y:	-376	,a:	2.094396	,bs:	522	},
    {x:	-372.174	,y:	-443.54	,a:	2.443462	,bs:	174	},
    {x:	198.03	,y:	544.082	,a:	-0.349066	,bs:	174	},
    {x:	570.204	,y:	-100.543	,a:	-1.74533	,bs:	174	},
    {x:	653	,y:	-376	,a:	-2.094396	,bs:	522	},
    {x:	372.174	,y:	-443.54	,a:	-2.443462	,bs:	174	}   
 
];
boxpointlist.forEach(function(point){

    let box = Bodies.rectangle(point.x, point.y, point.bs, point.bs);
    box.restitution = 0;
    Matter.Body.setAngle(box, point.a);
    Matter.Body.setStatic(box, true);

    Composite.add(engine.world, box);
});



window.addEventListener('keydown', function(event) {
    const key = event.key; // "ArrowRight", "ArrowLeft", "ArrowUp", or "ArrowDown"


    switch (event.key) {
    case "ArrowLeft":
        
        break;
    case "ArrowRight":
        
        break;  
    case "ArrowUp":
        
        break;
    case "ArrowDown":

        break;

    case "r":
        break;

    case "F5":
        
  
        break;   

    case "Enter":
       

        break;
                
    
}
});

 

var Target = Matter.Vector.create(0,0);

var isTouch, isMouse;

document.onpointermove  = (event) => {
    if(!isTouch && !isMouse){
        isMouse = event.pointerType == "mouse";
        isTouch = !isMouse;
    }
    if(isMouse) mousemove(event);
    if(isTouch) ontouch(event);
}
document.onlostpointercapture  = () => {lx = null; ly = null;
}

function mousemove(event){
        

    if(!S || !Xo || !Yo || !app) return;

    Target.x = (event.clientX-Xo) / S;
    Target.y = (event.clientY-Yo) / S;

    pointerGreen.position.x = event.clientX;
    pointerGreen.position.y = event.clientY;

    if(Matter.Vector.magnitudeSquared(Target) > 160000){ 
        Target = Matter.Vector.mult(Matter.Vector.normalise(Target), 400);        
    }

    pointerGrey.position.x = Target.x * S + Xo;
    pointerGrey.position.y = Target.y * S + Yo;

}

var dx, dy, lx, ly;

function ontouch(event){

    if(!S || !Xo || !Yo || !app) return;

    if(!dx || !dy) {dx = Xo; dy = Yo;}

    
    if(!lx || !ly) {lx = event.clientX; ly = event.clientY; return;}

    dx += (event.clientX - lx); dy += (event.clientY - ly);    

    dx = Math.max(0, dx); dy = Math.max(0, dy);
    dx = Math.min(X2o, dx); dy = Math.min(Y2o, dy);


    Target.x = (dx-Xo) / S;
    Target.y = (dy-Yo) / S;

    pointerGreen.position.x = dx;
    pointerGreen.position.y = dy;

    if(Matter.Vector.magnitudeSquared(Target) > 160000){ 
        Target = Matter.Vector.mult(Matter.Vector.normalise(Target), 400);        
    }

    pointerGrey.position.x = Target.x * S + Xo;
    pointerGrey.position.y = Target.y * S + Yo;

    lx = event.clientX; ly = event.clientY;
}

var strikes = [];

function strike(_bodyA, _bodyB){
    
    this. bodyA = _bodyA;
    this.bodyB = _bodyB;
}

function applystrike(bodyA, bodyB){
    if(!bodyA || !bodyB) return;

    let dd = Matter.Vector.normalise(Matter.Vector.sub(bodyB.position, bodyA.position)),
        ff = Matter.Vector.magnitude(Matter.Vector.sub(bodyB.velocity, bodyA.velocity));

    Matter.Body.applyForce(bodyA,
        bodyA.position,
        Matter.Vector.mult(dd, -0.005*ff) 
    );
    
    Matter.Body.applyForce(bodyB,
        bodyB.position,
        Matter.Vector.mult(dd, 0.005*ff) 
    );      
    

}

var CPUplayer, CPUtartget = [];
const cpuMinL = 50;
function addCPUplayer(){

    if(CPUplayer) return;

    CPUplayer = new Player(null, "CPU");  
    Players.push(CPUplayer);
    gPlayers.push(new gPlayer("CPU")); 
    CPUplayer.target = Matter.Vector.create(0, 0);

    var plist = [];
        plist.push(PLIST);

        Players.forEach(function (item)
        {
            plist.push({id: item.ID});
        });        

        sendScores();

}

setInterval(UpdatePhysics, 25);

var lastT = Date.now();

function UpdatePhysics(){


    var tnow = Date.now();
    Matter.Engine.update(engine, tnow - lastT, 1);
    lastT = tnow;

}



Events.on(engine,"beforeUpdate", function(event){

    
if(isHost){
   
          
    while(strikes.length > 0){

        applystrike(strikes[0].bodyA, strikes[0].bodyB);
       
        strikes.shift();
    }

    Players.forEach(function(item)
    {
        item.checkSpawn();
        if(item.PlayerObj && item.target)
        {
        perObj(item.PlayerObj, item.target);
         if(Matter.Vector.magnitudeSquared(item.PlayerObj.position) > 250000) item.kill();
        }
    });  
        

    nn++;
    if(nn<2) return;    

    if(Players[0])
    { 
        if(!Players[0].target)   Players[0].target = Matter.Vector.create(0,0);
        Players[0].target.x = Target.x;  
        Players[0].target.y = Target.y;    
        
    }

    if(CPUplayer){
        
        
       
        if(Players[0].PlayerObj){ 

            CPUtartget.push(Players[0].PlayerObj.position);
            let bb;
            while(CPUtartget.length > cpuMinL){
            CPUplayer.target = CPUtartget[0];
            CPUtartget.shift();
            bb= true;
            }
            if(!bb) {CPUplayer.target.x = -150 + 300* Math.random(); CPUplayer.target.y = -150 + 300* Math.random();}
        }
        else if(CPUplayer.target){
            CPUplayer.target.x = -150 + 300* Math.random(); CPUplayer.target.y = -150 + 300* Math.random();
            if(CPUtartget.length > 1) CPUtartget = [];
        }
    }

    sendPosData();
    nn = 0;
        
    }
    else if(unreliableToServ)
    { 
        nn++;
        if(nn<2) return;

        unreliableToServ.send({X:Target.x, Y:Target.y});
        nn = 0;
    
    }
});

function sendPosData(){

    let plist = [];   

    plist.push(Date.now());

    Players.forEach(function(pyr){
        if(pyr.PlayerObj) {plist.push(pyr.PlayerObj.position.x); plist.push(pyr.PlayerObj.position.y);}
        else {plist.push(undefined); plist.push(undefined)}
    });

    updateGlist(plist);
        
    // SEND TO ALL
    
        Players.forEach(function(item)
        {      
            if(item.UnreliableConnection) item.UnreliableConnection.send(plist);
        });
    
}

var nn = 0;


function perObj(bdy, tgate){

    let dir = Matter.Vector.sub(bdy.position, tgate),
        rsq = Matter.Vector.magnitudeSquared(dir);   

        


    Matter.Body.applyForce(bdy,
        bdy.position,
        Matter.Vector.mult(Matter.Vector.normalise(dir), -0.0014*(Math.min(rsq,10))) 
        );
    
}


var peer;

const BladeSize = 40;


var game;

function sndround(rno, total){
    let message = [];

    message.push(ROUND);

    message.push("Round " + (rno + 1) + " of " + total);

    Players.forEach(function(item){        
        if(item.ReliableConnection) item.ReliableConnection.send(message);
    });
    roundUI(message);

    setTimeout(cdwnEnd, 4000);

}

function cdwnEnd(){
    if(game) game.cdwn();
}

function codown(){
    let message = [];
    message.push(STARTCOUNTDOWN);
    
    startCountdown();
    Players.forEach(function(item){        
        if(item.ReliableConnection) item.ReliableConnection.send(message);
    });
    setTimeout(startGame, 4000);
}

function Game(_rounds){   

    this.rounds = _rounds;
    this.roundno = 0;

    this.startTime;

    var parent = this; 
    

    this.start = function(){

        if(parent.roundno < parent.rounds)
        {
            parent.roundno ++;            

            Players.forEach(function(item){
                item.spawnedOnce = false;
            });

            parent.startTime = Date.now();            
        }

    }

    this.cdwn = function(){
        Players.forEach(function(item){item.kill();});       
        codown();
    }

    this.endround = function(){

         

        if(parent.roundno < parent.rounds) { 
            // start next round
            sndround(parent.roundno, parent.rounds);

        }
        else{
            //send end game message
            sendScores();

            let d = [];
            d.push(GAMEENDED);
            Players.forEach(function(item){if(item.ReliableConnection) item.ReliableConnection.send(d)});
            gameEnded();
        }

    }

    
    this.playerdie = function(){
        
        if(!parent.startTime) return;

        sendScores();        

        let n = 0;

        Players.forEach(function(item){
            if(item.PlayerObj)  n++;
        });
        

        if(n<2){
            //end round
            parent.startTime = undefined;
            parent.endround();

        } 
    }


}

function sendScores(){
    
    let data = [];   
    data.push(SCORE);

    Players.forEach(function(item){
        data.push(item.score);        
    });    

    Players.forEach(function(item){
        if(item.ReliableConnection) item.ReliableConnection.send(data);         
    });
    updateLeaderboard(data);

}


function sendCountdown(){
    if(game) return;
    game = new Game(rnds);

    sendScores();
    sndround(game.roundno, game.rounds);   
}

function startGame(){
    if(game) game.start();
}


function Player(relConnection, _name){   
    
    var parent = this;

    this.PlayerObj;    

    this.target;
    
    //game params
        this.score = 0;

        this.lasthit;

        this.spawnedOnce = true;
    ////

    this.checkSpawn = function(){
        if(!parent.spawnedOnce && !parent.PlayerObj && parent.target){
            Players.forEach(function(plyr){
                if(plyr.PlayerObj && Matter.Vector.magnitudeSquared(Matter.Vector.sub(plyr.PlayerObj.position, parent.target) < 7000)) return;
            });
            parent.PlayerObj = spawnPlayer(parent.target.x, parent.target.y);
            parent.spawnedOnce = true;
        }
    }

    this.kill = function(){
        
        if(!parent.PlayerObj)return;
        Matter.Composite.remove(engine.world, parent.PlayerObj);
        parent.PlayerObj = null;  
        if(parent.lasthit && parent.lasthit.PlayerObj) parent.lasthit.score += getScore();
        if(game) game.playerdie();
    }
    

    this.ID = _name;

    if(!relConnection) return;
     // If local player, end here


    this.ID = relConnection.label;

    this.ReliableConnection = relConnection;
    
    this.UnreliableConnection = peer.connect(relConnection.peer, {reliable: false, serialization: "json"});

    this.UnreliableConnection.on('data', function(data)
    {
        //control
        if(!data.X || !data.Y) return;

        if(!parent.target) parent.target = Matter.Vector.create(0, 0);
        
        parent.target.x = data.X;
        parent.target.y = data.Y;

    });
    

}


var Players = [];


function spawnPlayer(x, y){

    var Obj = Bodies.circle(x, y, BladeSize);
    Obj.restitution = 1;
    Obj.mass = 5;
    Obj.friction = 0;
    Obj.frictionAir = 0.05;

    Composite.add(engine.world, Obj);

    return Obj;
}


const PLIST = "PLIST", SCORE = "SCORE", ROUND = "ROUND", STARTCOUNTDOWN = "STARTCOUNTDOWN", CONNECTIONFAILURE = "CONNECTFAIL", GAMEENDED = "GAMEENDED";

function Host(_name){

    if(peer) return;

    peer = new Peer(); 

    
    LocalPlayerName = _name;

    let hostPl = new Player(null, _name);
    Players.push(hostPl);
    gPlayers.push(new gPlayer(_name)); 
    hostName = _name;    
    
    sendScores();

    peer.on('error', function(e){console.log(e.type)});

    peer.on('open', function(){
        setHostID(peer.id);
    });

   
    peer.on('connection', function(conn){

        conn.on('data', function(data)
        {

            if(data == "ASKLIST"){
                if(game && game.roundno > 0){
                    let fail = [];
                    fail.push(CONNECTIONFAILURE);
                    conn.send(fail);
                    //conn.close();                    
                    return;
                }
                Players.push(new Player(conn, conn.label));  
                gPlayers.push(new gPlayer(conn.label));      
        
        //update playerlist
        var plist = [];
        plist.push(PLIST);

        Players.forEach(function (item)
        {
            plist.push({id: item.ID});
        });

        //send playerslist to all players
        Players.forEach(function (item)
        {
            if(item.ReliableConnection) item.ReliableConnection.send(plist);            
        });

        sendScores();

            }

            else if (data == PING){
                conn.send(PING);
            }

        });         
        

    });
    
    isHost = true;
}

var isHost;

function Create(_name){

    peer = new Peer(); 

    LocalPlayerName = _name;

}


var unreliableToServ, reliableToServ;
var LocalPlayerName;

function Join(_name, _hname){ 

    peer.on('connection', function(unreliableConnection){

        unreliableToServ = unreliableConnection;

        unreliableConnection.on('data', function(data){
              
                updateGlist(data);            
            
        });
    });


    
    reliableToServ = peer.connect(_hname, {label: _name, reliable: true});

    reliableToServ.on('open', function(){

        reliableToServ.send("ASKLIST");

        clientMessage.innerHTML = "Waiting for Host to start the game";

    });

    reliableToServ.on('data', function(data){
        

        if(data[0] && data[0]==CONNECTIONFAILURE){
            //connection rejected
            reliableToServ.close();
        }

        else if(data[0] && data[0]==PLIST){

            data.shift();
            gPlayers = [];
            data.forEach(function(item){
                gPlayers.push(new gPlayer(item.id));                
            });
        }
        else if(data[0] && data[0] == SCORE){            

            updateLeaderboard(data);

        }
        else if(data[0] && data[0] == ROUND){            
            
            roundUI(data);

        }
        else if(data[0] && data[0] == STARTCOUNTDOWN){            
            
            startCountdown();

        }
        else if(data[0] && data[0] == GAMEENDED){            
            
            gameEnded();

        }
        else if(data == PING){
            console.log(Date.now() - sendT);
        }
    });

    


}


function getScore(){
    let n = 0;
    Players.forEach(function(item){if(!item.PlayerObj) n++;});

    return n;
}


function SendData(){

    var string = document.getElementById("data").value;

Peerlist.forEach(function(item){
    item.sendRD(string);
});

  


}


Matter.Events.on(engine, 'collisionStart', function(event) {

    let pairs = event.pairs.slice()[0];

    if(pairs && !pairs.bodyA.isStatic && !pairs.bodyB.isStatic) {
        lhit(pairs.bodyA, pairs.bodyB);
        //add collision force
        strikes.push(new strike(pairs.bodyA, pairs.bodyB));
    }

    sendPosData();
});


function lhit(bodyA, bodyB){

    if(!bodyA || !bodyB) return;

    let pA, pB;

    Players.forEach(function(item){
        if(item.PlayerObj == bodyA) pA = item;
        else if(item.PlayerObj == bodyB) pB = item;
    });

    if(!pA || !pB) return;

    pA.lasthit = pB;
    pB.lasthit = pA;

}


/// Values


  function hexGenerator(str, ox) {

    if(str.length < 4){
        return ox ? "0xffffff" : "#ffffff";
    }
    var hash = 0;
    for (var i = 0; i < str.length; i++) {
      hash += str.charCodeAt(i);
    }
    
    return hslToHex(hash%360,100,50, ox);
  }

  function hslToHex(h, s, l, ox) {
    l /= 100;
    const a = s * Math.min(l, 1 - l) / 100;
    const f = n => {
      const k = (n + h / 30) % 12;
      const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
      return Math.round(255 * color).toString(16).padStart(2, '0');   // convert to Hex and prefix "0" if needed
    };
    if(ox) return `0x${f(0)}${f(8)}${f(4)}`;
    else return `#${f(0)}${f(8)}${f(4)}`;
  }

  const PING = "PING";
  var sendT;
function ping(){
    if(!isHost){
        sendT = Date.now();
        reliableToServ.send(PING);
    }
}

