

const loader = PIXI.Loader.shared;


var frames = [], frames00 = [], Rim1, RimBurst, framesCrash = [];
loadSprites();
function loadSprites() {
  for (var i = 1; i < 25; i++) {
    var val = i < 10 ? '0' + i : i;

    frames.push(PIXI.Texture.from('Public/Assets/SparkSeq/00' + val + '.png'));
  }

  for (var i = 1; i < 11; i++) {
    var val = i < 10 ? '0' + i : i;

    frames00.push(PIXI.Texture.from('Public/Assets/Spark00Seq/00' + val + '.png'));
  }

  

  Rim1 = PIXI.Texture.from('Public/Assets/RimSpark/Rim1.png');
  RimBurst = PIXI.Texture.from('Public/Assets/RimSpark/RimBurst.png');
  

  for (var i = 0; i < 9; i++) {

    framesCrash.push(PIXI.Texture.from('Public/Assets/CrashSeq/tile00' + i + '.png'));
  }

  

}




function makeSpark(parent, delta, collider)
{     
  _makeSpark(parent.dummy.position, delta);  
  _makeSpark(parent.dummy.position, delta);   

  _makeSpark00(parent.dummy.position, delta);    

  _makeSparkRotate(parent.dummy.position, delta, parent, collider);
}

function _makeSpark(pos, delta)
{
  let perp = Perpendiculat(delta);
  let velocity = {x: -0.5*perp.x +5 - 10*Math.random(), y: -0.5*perp.y +5 -  10*Math.random()} , decay = 0.4+0.5*Math.random();

// create an AnimatedSprite (brings back memories from the days of Flash, right ?)
let anim = new PIXI.AnimatedSprite(frames);

/*
 * An AnimatedSprite inherits all the properties of a PIXI sprite
 * so you can change its position, its anchor, mask it, etc
 */
anim.blendMode = PIXI.BLEND_MODES.ADD;
anim.scale.x = S;
anim.scale.y = S;
anim.x = pos.x + delta.x;
anim.y = pos.y + delta.y;
anim.anchor.set(0.5);
anim.animationSpeed = 2;
anim.rotation = Math.atan2(delta.y, delta.x);

anim.loop = false;
anim.play();

anim.onComplete = function () {
  // finished!
  
  ticker.destroy();
  app.stage.removeChild(anim);
  anim = undefined;
};

app.stage.addChild(anim);


let ticker = new PIXI.Ticker
    ticker.add((delta) => 
    { 
      anim.position.x += decay * velocity.x;
      anim.position.y += decay * velocity.y;
    })
    ticker.start();

}

function _makeSpark00(pos, delta)
{
  let perp = Perpendiculat(delta);
  let velocity = {x: -0.2*perp.x +5 - 10*Math.random(), y: -0.2*perp.y +5 -  10*Math.random()} , decay = 0.4+0.5*Math.random();

  

// create an AnimatedSprite (brings back memories from the days of Flash, right ?)
let anim = new PIXI.AnimatedSprite(frames00);

/*
 * An AnimatedSprite inherits all the properties of a PIXI sprite
 * so you can change its position, its anchor, mask it, etc
 */
anim.blendMode = PIXI.BLEND_MODES.ADD;
anim.scale.x = S * 0.2;
anim.scale.y = S * 0.2;
anim.x = pos.x + delta.x;
anim.y = pos.y + delta.y;
anim.anchor.set(0.5, 0.6);
anim.animationSpeed = 1;
anim.rotation = 3.14 + Math.atan2(delta.y, delta.x);

anim.loop = false;
anim.play();

anim.onComplete = function () {
  // finished!
  ticker.destroy();
  app.stage.removeChild(anim);
  anim = undefined;
};

app.stage.addChild(anim);

let ticker = new PIXI.Ticker;
    ticker.add((delta) => 
    { 
      anim.position.x += decay * velocity.x;
      anim.position.y += decay * velocity.y;
    })
    ticker.start();


}

const rimLife = 200;
function _makeSparkRotate(pos, delta, parent, collider){
   
if(parent.lastCollider == collider) return;

parent.lastCollider = collider;

let life = rimLife;

let rim1 = new PIXI.Sprite(Rim1);
let rimb = new PIXI.Sprite(RimBurst);

rim1.blendMode = PIXI.BLEND_MODES.ADD;
rimb.blendMode = PIXI.BLEND_MODES.ADD;


rim1.anchor.set(0.5);

rimb.scale.x = S * 0.18;
rimb.scale.y = S * 0.18;
rimb.anchor.set(0.5);

rimb.x = pos.x;
rimb.y = pos.y;

rimb.rotation = 1.57 + Math.atan2(delta.y, delta.x);

parent.dummy.addChild(rim1);
app.stage.addChild(rimb);


let ticker = new PIXI.Ticker
    ticker.add((delta) => 
    {
      
      if(parent.dummy && life > 0){
        rimb.position.x = parent.dummy.position.x;
        rimb.position.y = parent.dummy.position.y;

        let a = life / rimLife;

        rimb.alpha = a;
        rim1.alpha = a;

        life -= dellltaT;

      }else{
        parent.lastCollider = undefined;
        ticker.destroy();
        if(rimb) app.stage.removeChild(rimb);
        if(parent.dummy && rim1) parent.dummy.removeChild(rim1);
      }
      
    })
    ticker.start();

}



function Perpendiculat(vector)
    {
        return {x:vector.y, y:-vector.x};
    }