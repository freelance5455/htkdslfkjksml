Included: abduct.mp3, swing1-6.mp3 (katana swing shouts), giorgi1-4.mp3 (Giorgi death shouts)
Still to add (same folder, these names):
start.mp3    - sword sound at game start
slashes.mp3  - file with many sword slashes (random part plays on each kill)
