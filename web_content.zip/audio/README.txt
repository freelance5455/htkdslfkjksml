Still to add (same folder, these names):
start.mp3    - sword sound at game start
slashes.mp3  - file with many sword slashes (random part plays on each kill)
