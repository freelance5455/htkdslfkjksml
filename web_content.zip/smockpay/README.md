# SMOCK PAY V3 — Web App (PWA)

Application web responsive + PWA (installable sur Android/iPhone), interface en français.
Aucune dépendance, aucun build : fichiers statiques HTML/CSS/JS.

## Lancer
1. Dézipper.
2. Servir le dossier (la PWA exige http/https, pas `file://`) :
   `python3 -m http.server 8080` puis ouvrir http://localhost:8080
   ou déployer tel quel sur Netlify / Vercel / GitHub Pages / Cloudflare Pages.
3. Ouvrir **Configurer l'administrateur** (première visite) et créer le compte admin.

## Contenu (cahier des charges V3)
- Catalogue de 24 services + 4 offres e-commerce, prix de départ, cartes avec Commander / Devis.
- Comptes clients (inscription, rôles client/admin), tableau de bord client et admin.
- Commande → projet, 15 statuts, avancement, devis (acceptation/refus), prix par client.
- Messagerie par projet (non lus, notifications), demandes de documents + téléversement.
- Contrats électroniques : modèle généré, versions, signature client puis admin,
  empreinte SHA-256 + date + identité + user-agent, vérification d'intégrité, nouvelle version après signature.
- Liens de paiement (sans compte pour le payeur), solde/payé/restant, journal d'audit.
- Admin : services (ajout, modification, désactivation, suppression, image), paramètres, export JSON.

## ⚠ Limites honnêtes de cette livraison
- **Le projet v2 (SMOCK_PAY_Web_App_v2.zip) n'était pas disponible** : cette V3 est une base neuve.
  Le design (thème sombre/or) est à aligner avec celui de la v2 ; fusionner ensuite le code.
- **Mode démo** : les données sont dans le `localStorage` du navigateur. Les liens de paiement et
  les comptes ne fonctionnent donc que sur le même navigateur. Pour la production, remplacer `js/store.js`
  par des appels Supabase (schéma recommandé : `supabase/schema.sql`, RLS inclus).
- **Paiements** : aucun prestataire n'est intégré. Un paiement n'est jamais « confirmé » automatiquement :
  le payeur le *déclare*, l'admin le vérifie manuellement. La vérification côté serveur (webhooks,
  Edge Functions, `payment_events`) reste à faire (phase 9) après choix et validation du prestataire.
- **Signature électronique** : preuve technique simple. Sa valeur légale doit être validée selon les lois applicables.
- Mots de passe hachés en SHA-256 côté navigateur : acceptable pour la démo uniquement ; utiliser Supabase Auth en production.
- Fichiers limités à 600 Ko (localStorage) en démo ; en production : stockage privé + URL signées.

## Structure
```
index.html  manifest.webmanifest  sw.js
css/style.css
js/data.js   (services, offres, statuts)
js/store.js  (données — à remplacer par Supabase)
js/app.js    (routage + toutes les vues)
icons/icon.svg
supabase/schema.sql
```
