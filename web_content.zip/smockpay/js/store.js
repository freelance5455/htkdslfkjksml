/* SMOCK PAY V3 — couche de données.
   MODE DÉMO : tout est stocké dans le navigateur (localStorage).
   En production, remplacer ce fichier par des appels à Supabase (voir supabase/schema.sql). */
const Store = (() => {
  const KEY = "smockpay_v3";
  const uid = (p) => p + "_" + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
  const now = () => new Date().toISOString();
  const fresh = () => ({
    users: [], services: SERVICES.map(s => ({...s, active: true})), projects: [], messages: [],
    docRequests: [], files: [], contracts: [], payments: [], notifications: [], audit: [], session: null
  });
  let db;
  try { db = JSON.parse(localStorage.getItem(KEY)) || fresh(); } catch (e) { db = fresh(); }
  const save = () => {
    try { localStorage.setItem(KEY, JSON.stringify(db)); return true; }
    catch (e) { return false; }
  };
  const sha256 = async (txt) => {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(txt));
    return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
  };
  const hashPwd = (email, pwd) => sha256("smockpay|" + email.toLowerCase() + "|" + pwd);
  const log = (action, detail) => {
    const u = db.session && db.users.find(x => x.id === db.session);
    db.audit.push({id: uid("a"), at: now(), by: u ? u.email : "public", action, detail: detail || ""});
  };
  const notify = (userId, text, link) => {
    db.notifications.push({id: uid("n"), userId, text, link: link || "", at: now(), read: false});
  };
  return {
    get db() { return db; }, uid, now, save, sha256, hashPwd, log, notify,
    me() { return db.users.find(u => u.id === db.session) || null; },
    admin() { return db.users.find(u => u.role === "admin") || null; },
    hasAdmin() { return db.users.some(u => u.role === "admin"); },
    reset() { localStorage.removeItem(KEY); db = fresh(); }
  };
})();
