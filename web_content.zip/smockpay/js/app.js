/* SMOCK PAY V3 — application (SPA à routage par hash) — MODE DÉMO localStorage */
(() => {
const $app = document.getElementById("app");
const D = () => Store.db;
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money = (n, c = "USD") => Number(n || 0).toLocaleString("fr-FR") + " " + c;
const fd8 = d => d ? new Date(d).toLocaleDateString("fr-FR") : "—";
const fdt = d => d ? new Date(d).toLocaleString("fr-FR", {dateStyle: "short", timeStyle: "short"}) : "—";
const byId = (arr, id) => arr.find(x => x.id === id);
const user = id => byId(D().users, id);
const svc = id => byId(D().services, id);
const proj = id => byId(D().projects, id);
const settings = () => (D().settings = D().settings || {name: "SMOCK PAY", owner: "SMOCK DEV", email: "", phone: "", city: ""});
const MAX_FILE = 600 * 1024;

function toast(m) {
  const t = document.getElementById("toast");
  t.textContent = m; t.classList.add("on");
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("on"), 2800);
}
const go = h => { location.hash = h; };
const tagCls = s => /termin|livr|confirm|signé|Reçu/i.test(s) ? "ok" : /annul|suspend|expir/i.test(s) ? "bad" : /attente|À compléter|Devis|Partiel|Déclaré/i.test(s) ? "warn" : "";
const tag = s => `<span class="tag ${tagCls(s)}">${esc(s)}</span>`;
const unread = u => D().messages.filter(m => m.to === u.id && !m.read).length;

/* ---------- Mise en page ---------- */
function layout(inner, active) {
  const me = Store.me();
  const nav = [
    ["#/", "Accueil"], ["#/services", "Services"], ["#/tarifs", "Tarifs"]
  ].map(([h, l]) => `<a href="${h}" class="${active === h ? "on" : ""}">${l}</a>`).join("");
  let right;
  if (me) {
    right = `<a href="${me.role === "admin" ? "#/admin" : "#/dash"}">Tableau de bord</a><a href="#" data-act="logout">Déconnexion</a>`;
  } else {
    right = `<a href="#/login">Connexion</a><a href="#/register" class="btn sm">Inscription</a>`;
    if (!Store.hasAdmin()) right = `<a href="#/setup">Configurer l'administrateur</a>` + right;
  }
  return `<header class="top"><div class="wrap">
    <a class="logo" href="#/"><i>S</i>SMOCK PAY</a>
    <button class="burger" data-act="navtoggle" aria-label="Menu">☰</button>
    <nav class="nav" id="nav">${nav}${right}</nav></div></header>
    ${inner}
    <footer><div class="wrap">© ${new Date().getFullYear()} ${esc(settings().name)} — Responsable : ${esc(settings().owner)}. Les prix affichés sont des prix de départ indicatifs.</div></footer>`;
}
function dash(kind, active, inner) {
  const me = Store.me();
  const base = kind === "admin" ? "#/admin" : "#/dash";
  const items = kind === "admin"
    ? [["", "Vue d'ensemble"], ["clients", "Clients"], ["services", "Services & tarifs"], ["projects", "Projets"], ["messages", "Messages"], ["contracts", "Contrats"], ["transactions", "Paiements"], ["settings", "Paramètres"]]
    : [["", "Vue d'ensemble"], ["projects", "Mes projets"], ["messages", "Messages"], ["documents", "Documents"], ["contracts", "Contrats"], ["payments", "Paiements"]];
  const side = items.map(([k, l]) => {
    const b = k === "messages" && unread(me) ? `<span class="badge">${unread(me)}</span>` : "";
    return `<a href="${base}${k ? "/" + k : ""}" class="${active === k ? "on" : ""}"><span>${l}</span>${b}</a>`;
  }).join("");
  return layout(`<div class="wrap"><div class="dash"><aside class="side">${side}</aside><main>${inner}</main></div></div>`);
}

/* ---------- Pages publiques ---------- */
function svcCard(s, i) {
  const img = s.image ? `<img src="${esc(s.image)}" alt="${esc(s.name)}">` : s.icon;
  return `<article class="card svc" style="animation-delay:${(i % 12) * 40}ms"><div class="img">${img}</div><div class="body">
    <h3>${esc(s.name)}</h3><p>${esc(s.desc)}</p>
    <ul>${s.features.slice(0, 4).map(f => `<li>${esc(f)}</li>`).join("")}</ul>
    <div class="price"><small>À partir de</small> ${money(s.price, s.currency)}${s.plus ? " et plus" : ""}</div>
    <div class="actions"><a class="btn sm" href="#/order/${s.id}">Commander</a><a class="btn sm ghost" href="#/quote/${s.id}">Demander un devis</a><a class="btn sm ghost" href="#/service/${s.id}">Détails</a></div></div></article>`;
}
function home() {
  const act = D().services.filter(s => s.active);
  return layout(`<div class="wrap"><div class="banner"><img src="img/banner.jpg" alt="SMOCK PAY — Développez, Payez, Réussissez" fetchpriority="high"><a class="cta" href="#/services" aria-label="Construisons ensemble votre projet"></a></div><section class="hero">
    <h1>Votre présence en ligne, <b>conçue et livrée</b> par SMOCK PAY</h1>
    <p>Sites web, boutiques e-commerce et applications sur mesure. Commandez, suivez l'avancement, échangez vos documents et signez vos contrats électroniquement depuis un seul espace.</p>
    <div class="row"><a class="btn" href="#/services">Voir nos services</a><a class="btn ghost" href="#/register">Créer mon compte</a></div></section></div>
    <section class="s"><div class="wrap"><h2>NOS SERVICES DE DÉVELOPPEMENT WEB</h2><p class="sub">Tarifs de départ indicatifs — le montant définitif est confirmé après analyse de votre projet.</p>
    <div class="grid">${act.slice(0, 8).map(svcCard).join("")}</div>
    <div class="actions" style="margin-top:16px"><a class="btn ghost" href="#/services">Voir les ${act.length} services →</a></div></div></section>
    <section class="s"><div class="wrap"><h2>Offres e-commerce</h2><div class="grid">${offers()}</div></div></section>`, "#/");
}
function offers() {
  return OFFERS.map((o, i) => `<div class="card pad offer ${i === 1 ? "hot" : ""}"><h3>${esc(o.name)}</h3>
    <div class="price"><small>À partir de</small> ${money(o.price)}${o.plus ? " et plus" : ""}</div>
    <ul style="list-style:none;margin:10px 0;color:var(--mut);font-size:.88rem">${o.features.map(f => `<li>✓ ${esc(f)}</li>`).join("")}</ul>
    <a class="btn sm" href="#/quote/svc22">Demander un devis</a></div>`).join("");
}
function services() {
  const act = D().services.filter(s => s.active);
  return layout(`<div class="wrap"><section class="s"><h2>NOS SERVICES DE DÉVELOPPEMENT WEB</h2>
    <p class="sub">${act.length} services. Prix de départ indicatifs.</p><div class="grid">${act.map(svcCard).join("")}</div></section></div>`, "#/services");
}
function tarifs() {
  const rows = D().services.filter(s => s.active).map(s => `<tr><td>${s.n || ""}</td><td>${esc(s.name)}</td><td><b class="price">${money(s.price, s.currency)}${s.plus ? " et plus" : ""}</b></td><td><a class="btn sm ghost" href="#/quote/${s.id}">Devis</a></td></tr>`).join("");
  return layout(`<div class="wrap"><section class="s"><h2>Tarifs</h2>
    <p class="note" style="margin-bottom:14px">Ces tarifs sont des prix de départ indicatifs. Le prix définitif dépend des fonctionnalités, de la complexité et des exigences du client.</p>
    <div class="card pad tw"><table><thead><tr><th>N°</th><th>Service</th><th>Prix de départ</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
    <h2 style="margin:26px 0 12px">Offres e-commerce</h2><div class="grid">${offers()}</div></section></div>`, "#/tarifs");
}
function serviceDetail(id) {
  const s = svc(id);
  if (!s) return layout(`<div class="wrap"><p class="sub" style="margin-top:40px">Service introuvable.</p></div>`);
  return layout(`<div class="wrap"><section class="s"><div class="two"><div class="card svc"><div class="img" style="height:220px;font-size:5rem">${s.image ? `<img src="${esc(s.image)}" alt="">` : s.icon}</div></div>
    <div><h2>${esc(s.name)}</h2><p class="sub">${esc(s.desc)}</p><div class="price" style="margin-bottom:10px"><small>À partir de</small> ${money(s.price, s.currency)}${s.plus ? " et plus" : ""}</div>
    <h3 style="margin:10px 0">Fonctionnalités principales</h3><ul style="list-style:none;color:var(--mut)">${s.features.map(f => `<li>✓ ${esc(f)}</li>`).join("")}</ul>
    <div class="actions" style="margin-top:16px"><a class="btn" href="#/order/${s.id}">Commander</a><a class="btn ghost" href="#/quote/${s.id}">Demander un devis</a></div>
    <p class="sub" style="margin-top:14px;font-size:.85rem">Prix indicatif — montant définitif confirmé après analyse du projet.</p></div></div></section></div>`, "#/services");
}

/* ---------- Authentification ---------- */
function authForm(kind) {
  if (kind === "login") return layout(`<div class="wrap"><div class="card pad auth"><div class="authhead"><img src="img/logo-crop.png" alt="SMOCK PAY"><p>Développez • Payez • Réussissez</p></div><h2>Connexion</h2><form data-form="login"><label>Adresse e-mail<input name="email" type="email" required autocomplete="username"></label>
    <label>Mot de passe<input name="password" type="password" required autocomplete="current-password"></label><div class="msg-err" id="err"></div><button class="btn">Se connecter</button></form>
    <p class="sub" style="margin-top:12px">Pas encore de compte ? <a href="#/register">Inscription</a></p></div></div>`);
  if (kind === "setup") return layout(`<div class="wrap"><div class="card pad auth"><div class="authhead"><img src="img/logo-crop.png" alt="SMOCK PAY"><p>Développez • Payez • Réussissez</p></div><h2>Créer le compte administrateur</h2>
    ${Store.hasAdmin() ? `<p class="note">Un administrateur existe déjà.</p>` : `<p class="note info" style="margin-bottom:12px">Première configuration : ce compte gère toute la plateforme. Choisissez un mot de passe fort.</p>
    <form data-form="setup"><label>Nom complet<input name="name" required></label><label>E-mail<input name="email" type="email" required></label><label>Téléphone<input name="phone"></label>
    <label>Mot de passe (8 caractères min.)<input name="password" type="password" minlength="8" required></label><label>Confirmation<input name="password2" type="password" required></label>
    <div class="msg-err" id="err"></div><button class="btn">Créer l'administrateur</button></form>`}</div></div>`);
  return layout(`<div class="wrap"><div class="card pad auth"><div class="authhead"><img src="img/logo-crop.png" alt="SMOCK PAY"><p>Développez • Payez • Réussissez</p></div><h2>Créer mon compte</h2><form data-form="register"><label>Nom complet<input name="name" required autocomplete="name"></label>
    <label>Adresse e-mail<input name="email" type="email" required autocomplete="email"></label><label>Numéro de téléphone<input name="phone" type="tel" required autocomplete="tel"></label>
    <label>Mot de passe (8 caractères min.)<input name="password" type="password" minlength="8" required autocomplete="new-password"></label><label>Confirmation du mot de passe<input name="password2" type="password" required autocomplete="new-password"></label>
    <label class="chk"><input type="checkbox" name="terms" required><span>J'accepte les conditions d'utilisation.</span></label><div class="msg-err" id="err"></div><button class="btn">Créer mon compte</button></form>
    <p class="sub" style="margin-top:12px">Déjà inscrit ? <a href="#/login">Connexion</a></p></div></div>`);
}

/* ---------- Commande / devis ---------- */
function orderForm(id, mode) {
  const me = Store.me();
  if (!me) { sessionStorage.setItem("next", `#/${mode}/${id}`); go("#/login"); return ""; }
  if (me.role !== "client") return layout(`<div class="wrap"><p class="note" style="margin:40px 0">Les commandes sont réservées aux comptes clients.</p></div>`);
  const s = svc(id);
  if (!s) return layout(`<div class="wrap"><p class="sub">Service introuvable.</p></div>`);
  return layout(`<div class="wrap"><div class="card pad auth" style="max-width:600px"><h2>${mode === "quote" ? "Demander un devis" : "Commander"} — ${esc(s.name)}</h2>
    <p class="sub">Prix de départ indicatif : ${money(s.price, s.currency)}${s.plus ? " et plus" : ""}. Le montant définitif sera confirmé après analyse.</p>
    <form data-form="order"><input type="hidden" name="serviceId" value="${s.id}"><input type="hidden" name="mode" value="${mode}">
    <label>Nom du projet<input name="title" required value="${esc(s.name)}"></label>
    <label>Décrivez votre besoin<textarea name="description" required placeholder="Objectifs, public cible, fonctionnalités souhaitées, délais…"></textarea></label>
    <label>Budget envisagé (optionnel, en USD)<input name="budget" type="number" min="0"></label>
    <button class="btn">Envoyer la demande</button></form></div></div>`);
}

/* ---------- Blocs partagés ---------- */
function chat(p, isAdmin) {
  const me = Store.me();
  const ms = D().messages.filter(m => m.projectId === p.id).sort((a, b) => a.at.localeCompare(b.at));
  return `<div class="card pad"><h3>Messages</h3><div class="chat" style="margin:10px 0">${ms.length ? ms.map(m => `<div class="bub ${m.from === me.id ? "me" : ""}">${esc(m.text)}<small>${esc(user(m.from)?.name || "")} · ${fdt(m.at)}</small></div>`).join("") : `<p class="sub">Aucun message.</p>`}</div>
    <form data-form="message"><input type="hidden" name="projectId" value="${p.id}"><textarea name="text" required placeholder="Votre message…" style="min-height:60px"></textarea><button class="btn sm">Envoyer</button></form></div>`;
}
function docsBlock(p, isAdmin) {
  const reqs = D().docRequests.filter(r => r.projectId === p.id);
  const files = id => D().files.filter(f => f.requestId === id);
  const items = reqs.map(r => `<div class="hr"></div><div><b>${esc(r.type)}</b> ${tag(r.status)}<div class="sub" style="margin:2px 0">${esc(r.note || "")}</div>
    ${files(r.id).map(f => `<div style="font-size:.85rem">📎 <a href="${f.data}" download="${esc(f.name)}">${esc(f.name)}</a> <span class="sub">(${Math.round(f.size / 1024)} Ko · ${fdt(f.at)})</span></div>`).join("")}
    ${!isAdmin ? `<form data-form="upload" style="margin-top:8px;grid-template-columns:1fr auto"><input type="hidden" name="requestId" value="${r.id}"><input type="file" name="file" required><button class="btn sm">Téléverser</button></form>` :
      `<form data-form="docstatus" style="margin-top:8px;grid-template-columns:1fr auto"><input type="hidden" name="id" value="${r.id}"><select name="status">${DOC_STATUSES.map(s => `<option ${s === r.status ? "selected" : ""}>${s}</option>`).join("")}</select><button class="btn sm ghost">Statut</button></form>`}</div>`).join("");
  const add = isAdmin ? `<div class="hr"></div><form data-form="docreq"><input type="hidden" name="projectId" value="${p.id}"><label>Demander un document<select name="type">${DOC_TYPES.map(t => `<option>${t}</option>`).join("")}</select></label><label>Précisions<input name="note"></label><button class="btn sm">Envoyer la demande</button></form>` : "";
  return `<div class="card pad"><h3>Documents demandés</h3>${items || `<p class="sub">Aucune demande de document.</p>`}${add}<p class="sub" style="font-size:.75rem;margin-top:8px">Taille max. par fichier en mode démo : ${MAX_FILE / 1024} Ko.</p></div>`;
}
function contractBlock(p, isAdmin) {
  const cs = D().contracts.filter(c => c.projectId === p.id).sort((a, b) => b.version - a.version);
  const cur = cs.find(c => c.status !== "superseded");
  let h = `<div class="card pad"><h3>Contrat électronique</h3>`;
  if (!cur) {
    h += `<p class="sub">Aucun contrat.</p>`;
    if (isAdmin) h += `<form data-form="contract-create"><input type="hidden" name="projectId" value="${p.id}"><button class="btn sm">Préparer le contrat</button></form>`;
    return h + "</div>";
  }
  const sigs = cur.signatures.map(s => `<div style="font-size:.85rem">✍️ ${s.role === "client" ? "Client" : "SMOCK PAY"} : <b>${esc(s.name)}</b> — ${fdt(s.at)} <button class="btn sm ghost" data-act="verify" data-id="${cur.id}" data-sig="${s.at}">Vérifier</button><div class="sub" style="font-size:.7rem;word-break:break-all">SHA-256 : ${s.hash}</div></div>`).join("");
  h += `<p>Version ${cur.version} ${tag(({draft: "Brouillon", sent: "En attente de signature", signed_client: "Signé par le client", signed: "Signé par les deux parties"})[cur.status])}</p>`;
  if (isAdmin && cur.status === "draft") {
    h += `<form data-form="contract-save"><input type="hidden" name="id" value="${cur.id}"><textarea name="text" style="min-height:300px;font-size:.85rem">${esc(cur.text)}</textarea>
      <div class="actions"><button class="btn sm ghost" name="op" value="save">Enregistrer</button><button class="btn sm" name="op" value="send">Enregistrer et envoyer au client</button></div></form>`;
  } else {
    h += `<div class="contract">${esc(cur.text)}</div><div style="margin-top:10px">${sigs || `<p class="sub">Aucune signature.</p>`}</div>`;
  }
  if (!isAdmin && cur.status === "sent") {
    h += `<form data-form="sign-client" style="margin-top:12px"><input type="hidden" name="id" value="${cur.id}"><label class="chk"><input type="checkbox" name="ok" required><span>J'ai lu le contrat et j'en accepte les conditions.</span></label>
      <label>Tapez votre nom complet pour signer<input name="name" required placeholder="${esc(Store.me().name)}"></label><div class="msg-err" id="err"></div><button class="btn">Signer électroniquement</button></form>`;
  }
  if (isAdmin && cur.status === "signed_client") {
    h += `<form data-form="sign-admin" style="margin-top:12px"><input type="hidden" name="id" value="${cur.id}"><button class="btn ok sm">Contresigner (administrateur)</button></form>`;
  }
  if (isAdmin && cur.status !== "draft") {
    h += `<form data-form="contract-newver" style="margin-top:10px"><input type="hidden" name="id" value="${cur.id}"><button class="btn sm ghost">Créer une nouvelle version (modification)</button></form>`;
  }
  if (cs.length > 1) h += `<p class="sub" style="font-size:.8rem;margin-top:8px">Versions précédentes conservées : ${cs.filter(c => c.id !== cur.id).map(c => "v" + c.version).join(", ")}</p>`;
  return h + `<p class="sub" style="font-size:.75rem;margin-top:8px">La conformité juridique de la signature doit être vérifiée selon les lois applicables.</p></div>`;
}
function payBlock(p, isAdmin) {
  const ps = D().payments.filter(x => x.projectId === p.id);
  const paid = ps.filter(x => x.status === "confirmed").reduce((a, x) => a + Number(x.amount), 0);
  let h = `<div class="card pad"><h3>Paiements</h3><div class="stats" style="margin:10px 0"><div class="stat"><b>${money(p.price, p.currency)}</b><span>Prix convenu</span></div><div class="stat"><b>${money(paid, p.currency)}</b><span>Déjà payé (confirmé)</span></div><div class="stat"><b>${money(Math.max(0, (p.price || 0) - paid), p.currency)}</b><span>Solde restant</span></div></div>`;
  h += ps.length ? `<div class="tw"><table><tr><th>Description</th><th>Montant</th><th>Statut</th><th></th></tr>${ps.map(x => `<tr><td>${esc(x.description)}</td><td>${money(x.amount, x.currency)}</td><td>${tag(PAY_STATUSES[x.status])}</td><td><a href="#/pay/${x.id}">Lien</a></td></tr>`).join("")}</table></div>` : `<p class="sub">Aucun lien de paiement.</p>`;
  if (isAdmin) h += `<div class="hr"></div>` + payForm(p);
  return h + "</div>";
}
function payForm(p) {
  const exp = new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10);
  return `<form data-form="pay-create"><input type="hidden" name="projectId" value="${p ? p.id : ""}"><div class="two" style="gap:10px">
    <label>Montant<input name="amount" type="number" min="1" step="0.01" required></label><label>Devise<select name="currency"><option>USD</option><option>HTG</option><option>EUR</option></select></label></div>
    <label>Description<input name="description" required value="${p ? esc("Acompte — " + p.title) : ""}"></label>
    <div class="two" style="gap:10px"><label>Nom du client (si connu)<input name="clientName" value="${p ? esc(user(p.clientId)?.name || "") : ""}"></label><label>Frais éventuels<input name="fees" type="number" min="0" step="0.01" value="0"></label></div>
    <label>Date d'expiration<input name="expires" type="date" value="${exp}"></label><button class="btn sm">Générer le lien de paiement</button></form>`;
}
function statusPill(p) {
  return `<div style="display:grid;gap:6px;margin:10px 0"><div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap">${tag(p.status)}<b>${p.progress}%</b></div><div class="bar"><i style="width:${p.progress}%"></i></div></div>`;
}

/* ---------- Espace client ---------- */
function myProjects() { const me = Store.me(); return D().projects.filter(p => p.clientId === me.id); }
function clientDash(sub, id) {
  const me = Store.me();
  const ps = myProjects();
  const pids = ps.map(p => p.id);
  if (!sub) {
    const cur = ps.filter(p => !/terminé|livré|annulé|suspendu/i.test(p.status) && p.progress < 100).length;
    const done = ps.filter(p => /terminé|livré/i.test(p.status)).length;
    const wait = ps.filter(p => /attente|Devis|Demande|Analyse/i.test(p.status)).length;
    const toSign = D().contracts.filter(c => pids.includes(c.projectId) && c.status === "sent").length;
    const payWait = D().payments.filter(x => pids.includes(x.projectId) && x.status === "pending").length;
    const notes = D().notifications.filter(n => n.userId === me.id).sort((a, b) => b.at.localeCompare(a.at)).slice(0, 8);
    return dash("client", "", `<h2 class="h2">Bonjour, ${esc(me.name)}</h2><p class="sub">Voici l'état de vos projets.</p>
      <div class="stats"><div class="stat"><b>${cur}</b><span>Projets en cours</span></div><div class="stat"><b>${done}</b><span>Projets terminés</span></div><div class="stat"><b>${wait}</b><span>Projets en attente</span></div><div class="stat"><b>${toSign}</b><span>Contrats à signer</span></div><div class="stat"><b>${payWait}</b><span>Paiements en attente</span></div></div>
      <div class="card pad"><div style="display:flex;justify-content:space-between"><h3>Notifications récentes</h3><button class="btn sm ghost" data-act="readall">Tout marquer lu</button></div>
      ${notes.length ? notes.map(n => `<div style="padding:8px 0;border-bottom:1px solid var(--line);${n.read ? "opacity:.6" : ""}"><a href="${n.link || "#"}">${esc(n.text)}</a> <span class="sub" style="font-size:.75rem">${fdt(n.at)}</span></div>`).join("") : `<p class="sub">Aucune notification.</p>`}</div>
      <div class="actions" style="margin-top:14px"><a class="btn" href="#/services">Commander un nouveau projet</a></div>`);
  }
  if (sub === "projects") return dash("client", "projects", `<h2 class="h2">Mes projets</h2>${ps.length ? `<div class="grid">${ps.map(p => `<a class="card pad" href="#/dash/project/${p.id}" style="color:inherit"><h3>${esc(p.title)}</h3><p class="sub">${esc(svc(p.serviceId)?.name || "")}</p>${statusPill(p)}<div class="price">${p.price ? money(p.price, p.currency) : "Prix à confirmer"}</div><div class="sub" style="font-size:.8rem">Créé le ${fd8(p.createdAt)} · Livraison estimée : ${fd8(p.eta)}</div></a>`).join("")}</div>` : `<p class="sub">Aucun projet. <a href="#/services">Découvrir nos services</a></p>`}`);
  if (sub === "project") {
    const p = proj(id);
    if (!p || p.clientId !== me.id) return dash("client", "projects", `<p class="note">Projet introuvable ou accès refusé.</p>`);
    D().messages.forEach(m => { if (m.projectId === p.id && m.to === me.id) m.read = true; }); Store.save();
    const quote = p.status === "Devis envoyé" ? `<div class="note info" style="margin:10px 0">Un devis de <b>${money(p.price, p.currency)}</b> vous a été envoyé. <div class="actions" style="margin-top:8px"><button class="btn sm ok" data-act="quote-accept" data-id="${p.id}">Accepter le devis</button><button class="btn sm danger" data-act="quote-refuse" data-id="${p.id}">Refuser</button></div></div>` : "";
    return dash("client", "projects", `<a href="#/dash/projects">← Mes projets</a><div class="card pad" style="margin:10px 0"><h2 class="h2">${esc(p.title)}</h2><p class="sub">${esc(p.description)}</p>${statusPill(p)}${quote}
      <div class="stats"><div class="stat"><b>${p.price ? money(p.price, p.currency) : "—"}</b><span>Prix convenu</span></div><div class="stat"><b>${fd8(p.createdAt)}</b><span>Création</span></div><div class="stat"><b>${fd8(p.eta)}</b><span>Livraison estimée</span></div></div></div>
      <div class="two">${chat(p, false)}${docsBlock(p, false)}</div><div class="two" style="margin-top:16px">${contractBlock(p, false)}${payBlock(p, false)}</div>`);
  }
  if (sub === "messages") {
    return dash("client", "messages", `<h2 class="h2">Messages</h2>${ps.length ? ps.map(p => { const u = D().messages.filter(m => m.projectId === p.id && m.to === me.id && !m.read).length; return `<a class="card pad" style="display:flex;justify-content:space-between;margin-bottom:10px;color:inherit" href="#/dash/project/${p.id}"><span>${esc(p.title)}</span>${u ? `<span class="badge">${u} non lu(s)</span>` : `<span class="sub">Ouvrir</span>`}</a>`; }).join("") : `<p class="sub">Aucun projet.</p>`}`);
  }
  if (sub === "documents") {
    const reqs = D().docRequests.filter(r => pids.includes(r.projectId));
    const files = D().files.filter(f => pids.includes(f.projectId));
    return dash("client", "documents", `<h2 class="h2">Mes documents</h2><div class="card pad"><h3>Documents demandés</h3>${reqs.length ? `<div class="tw"><table><tr><th>Projet</th><th>Document</th><th>Statut</th><th></th></tr>${reqs.map(r => `<tr><td>${esc(proj(r.projectId).title)}</td><td>${esc(r.type)}<div class="sub">${esc(r.note || "")}</div></td><td>${tag(r.status)}</td><td><a href="#/dash/project/${r.projectId}">Répondre</a></td></tr>`).join("")}</table></div>` : `<p class="sub">Aucune demande.</p>`}</div>
      <div class="card pad" style="margin-top:14px"><h3>Fichiers envoyés</h3>${files.length ? files.map(f => `<div>📎 <a href="${f.data}" download="${esc(f.name)}">${esc(f.name)}</a> <span class="sub">${fdt(f.at)}</span></div>`).join("") : `<p class="sub">Aucun fichier.</p>`}</div>`);
  }
  if (sub === "contracts") {
    const cs = D().contracts.filter(c => pids.includes(c.projectId) && c.status !== "draft");
    return dash("client", "contracts", `<h2 class="h2">Contrats</h2>${cs.length ? cs.map(c => `<a class="card pad" style="display:flex;justify-content:space-between;margin-bottom:10px;color:inherit" href="#/dash/project/${c.projectId}"><span>${esc(proj(c.projectId).title)} — v${c.version}</span>${tag(c.status === "signed" ? "Signé par les deux parties" : c.status === "signed_client" ? "Signé par vous" : c.status === "superseded" ? "Remplacé" : "À signer")}</a>`).join("") : `<p class="sub">Aucun contrat.</p>`}`);
  }
  if (sub === "payments") {
    const ps2 = D().payments.filter(x => pids.includes(x.projectId));
    const total = ps.reduce((a, p) => a + Number(p.price || 0), 0);
    const paid = ps2.filter(x => x.status === "confirmed").reduce((a, x) => a + Number(x.amount), 0);
    return dash("client", "payments", `<h2 class="h2">Mes paiements</h2><div class="stats"><div class="stat"><b>${money(total)}</b><span>Montant total</span></div><div class="stat"><b>${money(paid)}</b><span>Déjà payé</span></div><div class="stat"><b>${money(Math.max(0, total - paid))}</b><span>Solde restant</span></div></div>
      <div class="card pad tw">${ps2.length ? `<table><tr><th>Date</th><th>Description</th><th>Montant</th><th>Statut</th><th></th></tr>${ps2.map(x => `<tr><td>${fd8(x.createdAt)}</td><td>${esc(x.description)}</td><td>${money(Number(x.amount) + Number(x.fees || 0), x.currency)}</td><td>${tag(PAY_STATUSES[x.status])}</td><td><a href="#/pay/${x.id}">Ouvrir le lien</a></td></tr>`).join("")}</table>` : `<p class="sub">Aucune transaction.</p>`}</div>`);
  }
  return dash("client", "", `<p class="note">Page introuvable.</p>`);
}

/* ---------- Administration ---------- */
function adminDash(sub, id) {
  const clients = D().users.filter(u => u.role === "client");
  if (!sub) {
    const nw = D().projects.filter(p => p.status === "Demande reçue").length;
    const sign = D().contracts.filter(c => c.status === "signed_client").length;
    const ver = D().payments.filter(x => x.status === "awaiting_verification").length;
    const rev = {}; D().payments.filter(x => x.status === "confirmed").forEach(x => rev[x.currency] = (rev[x.currency] || 0) + Number(x.amount));
    const me = Store.me();
    const notes = D().notifications.filter(n => n.userId === me.id).sort((a, b) => b.at.localeCompare(a.at)).slice(0, 10);
    return dash("admin", "", `<h2 class="h2">Tableau de bord administrateur</h2><div class="stats">
      <div class="stat"><b>${clients.length}</b><span>Clients</span></div><div class="stat"><b>${D().projects.length}</b><span>Projets</span></div><div class="stat"><b>${nw}</b><span>Nouvelles demandes</span></div>
      <div class="stat"><b>${sign}</b><span>Contrats à contresigner</span></div><div class="stat"><b>${ver}</b><span>Paiements à vérifier</span></div>
      <div class="stat"><b>${Object.entries(rev).map(([c, v]) => money(v, c)).join(" · ") || "0"}</b><span>Encaissé (confirmé)</span></div></div>
      <div class="card pad"><h3>Notifications</h3>${notes.length ? notes.map(n => `<div style="padding:8px 0;border-bottom:1px solid var(--line);${n.read ? "opacity:.6" : ""}"><a href="${n.link || "#"}">${esc(n.text)}</a> <span class="sub" style="font-size:.75rem">${fdt(n.at)}</span></div>`).join("") : `<p class="sub">Rien de nouveau.</p>`}<button class="btn sm ghost" style="margin-top:10px" data-act="readall">Tout marquer lu</button></div>`);
  }
  if (sub === "clients") {
    return dash("admin", "clients", `<h2 class="h2">Clients</h2><div class="card pad tw">${clients.length ? `<table><tr><th>Nom</th><th>E-mail</th><th>Tél.</th><th>Projets</th><th></th></tr>${clients.map(c => `<tr><td>${esc(c.name)}</td><td>${esc(c.email)}</td><td>${esc(c.phone)}</td><td>${D().projects.filter(p => p.clientId === c.id).length}</td><td><a href="#/admin/client/${c.id}">Détails</a></td></tr>`).join("")}</table>` : `<p class="sub">Aucun client inscrit.</p>`}</div>`);
  }
  if (sub === "client") {
    const c = user(id);
    if (!c) return dash("admin", "clients", `<p class="note">Client introuvable.</p>`);
    const ps = D().projects.filter(p => p.clientId === c.id), pids = ps.map(p => p.id);
    const acts = D().audit.filter(a => a.detail && a.detail.includes(c.id)).slice(-8).reverse();
    return dash("admin", "clients", `<a href="#/admin/clients">← Clients</a><div class="card pad" style="margin:10px 0"><h2 class="h2">${esc(c.name)}</h2><p class="sub">${esc(c.email)} · ${esc(c.phone)} · Inscrit le ${fd8(c.createdAt)}</p></div>
      <div class="two"><div class="card pad"><h3>Projets</h3>${ps.map(p => `<div style="padding:6px 0"><a href="#/admin/project/${p.id}">${esc(p.title)}</a> ${tag(p.status)}</div>`).join("") || `<p class="sub">Aucun.</p>`}</div>
      <div class="card pad"><h3>Résumé</h3><p>Messages : ${D().messages.filter(m => pids.includes(m.projectId)).length}</p><p>Documents reçus : ${D().files.filter(f => pids.includes(f.projectId)).length}</p><p>Contrats : ${D().contracts.filter(x => pids.includes(x.projectId)).length}</p><p>Paiements : ${D().payments.filter(x => pids.includes(x.projectId)).length}</p></div></div>
      <div class="card pad" style="margin-top:16px"><h3>Activités récentes</h3>${acts.map(a => `<div class="sub">${fdt(a.at)} — ${esc(a.action)}</div>`).join("") || `<p class="sub">Aucune.</p>`}</div>`);
  }
  if (sub === "services") return adminServices(id);
  if (sub === "projects") {
    const ps = [...D().projects].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return dash("admin", "projects", `<h2 class="h2">Projets & commandes</h2><div class="card pad tw">${ps.length ? `<table><tr><th>Projet</th><th>Client</th><th>Type</th><th>Statut</th><th>Prix</th><th></th></tr>${ps.map(p => `<tr><td>${esc(p.title)}</td><td>${esc(user(p.clientId)?.name || "")}</td><td>${p.kind === "quote" ? "Devis" : "Commande"}</td><td>${tag(p.status)} ${p.progress}%</td><td>${p.price ? money(p.price, p.currency) : "—"}</td><td><a href="#/admin/project/${p.id}">Gérer</a></td></tr>`).join("")}</table>` : `<p class="sub">Aucune demande.</p>`}</div>`);
  }
  if (sub === "project") {
    const p = proj(id);
    if (!p) return dash("admin", "projects", `<p class="note">Projet introuvable.</p>`);
    const me = Store.me();
    D().messages.forEach(m => { if (m.projectId === p.id && m.to === me.id) m.read = true; }); Store.save();
    const c = user(p.clientId);
    return dash("admin", "projects", `<a href="#/admin/projects">← Projets</a><div class="card pad" style="margin:10px 0"><h2 class="h2">${esc(p.title)}</h2><p class="sub">${esc(svc(p.serviceId)?.name || "")} · Client : <a href="#/admin/client/${c?.id}">${esc(c?.name || "")}</a> (${esc(c?.email || "")})</p><p>${esc(p.description)}</p>${p.budget ? `<p class="sub">Budget indiqué par le client : ${money(p.budget)}</p>` : ""}${statusPill(p)}
      <form data-form="project-update"><input type="hidden" name="id" value="${p.id}"><div class="two" style="gap:10px"><label>Statut<select name="status">${PROJECT_STATUSES.map(s => `<option ${s === p.status ? "selected" : ""}>${s}</option>`).join("")}</select></label>
      <label>Avancement (%)<input name="progress" type="number" min="0" max="100" value="${p.progress}"></label><label>Prix convenu / devis<input name="price" type="number" min="0" step="0.01" value="${p.price || ""}"></label>
      <label>Devise<select name="currency">${["USD", "HTG", "EUR"].map(x => `<option ${x === p.currency ? "selected" : ""}>${x}</option>`).join("")}</select></label><label>Livraison estimée<input name="eta" type="date" value="${p.eta || ""}"></label></div>
      <div class="actions"><button class="btn sm ghost" name="op" value="save">Enregistrer</button><button class="btn sm" name="op" value="quote">Enregistrer et envoyer le devis</button></div></form></div>
      <div class="two">${chat(p, true)}${docsBlock(p, true)}</div><div class="two" style="margin-top:16px">${contractBlock(p, true)}${payBlock(p, true)}</div>`);
  }
  if (sub === "messages") {
    const me = Store.me();
    return dash("admin", "messages", `<h2 class="h2">Messages</h2>${D().projects.map(p => { const u = D().messages.filter(m => m.projectId === p.id && m.to === me.id && !m.read).length; return `<a class="card pad" style="display:flex;justify-content:space-between;margin-bottom:10px;color:inherit" href="#/admin/project/${p.id}"><span>${esc(p.title)} — ${esc(user(p.clientId)?.name || "")}</span>${u ? `<span class="badge">${u} non lu(s)</span>` : ""}</a>`; }).join("") || `<p class="sub">Aucune conversation.</p>`}`);
  }
  if (sub === "contracts") {
    const cs = [...D().contracts].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return dash("admin", "contracts", `<h2 class="h2">Contrats & signatures</h2><div class="card pad tw">${cs.length ? `<table><tr><th>Projet</th><th>Version</th><th>Statut</th><th>Signatures</th><th></th></tr>${cs.map(c => `<tr><td>${esc(proj(c.projectId)?.title || "")}</td><td>v${c.version}</td><td>${tag(({draft: "Brouillon", sent: "En attente de signature", signed_client: "Signé par le client", signed: "Signé par les deux parties", superseded: "Remplacé"})[c.status])}</td><td>${c.signatures.length}</td><td><a href="#/admin/project/${c.projectId}">Ouvrir</a></td></tr>`).join("")}</table>` : `<p class="sub">Aucun contrat.</p>`}</div>`);
  }
  if (sub === "transactions") {
    const ps = [...D().payments].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return dash("admin", "transactions", `<h2 class="h2">Paiements & transactions</h2><div class="note info" style="margin-bottom:12px">Mode démo : aucun prestataire de paiement n'est connecté. Un paiement n'est « Confirmé » que lorsque l'administrateur le vérifie manuellement (référence de transaction contrôlée). L'intégration d'un prestataire avec vérification serveur (webhooks) est prévue à la phase 9.</div>
      <div class="card pad" style="margin-bottom:14px"><h3>Nouveau lien de paiement (sans projet)</h3>${payForm(null)}</div>
      <div class="card pad tw">${ps.length ? `<table><tr><th>Date</th><th>Description</th><th>Montant</th><th>Statut</th><th>Référence déclarée</th><th></th></tr>${ps.map(x => `<tr><td>${fd8(x.createdAt)}</td><td>${esc(x.description)}<div class="sub">${esc(x.clientName || "")}</div></td><td>${money(Number(x.amount) + Number(x.fees || 0), x.currency)}</td><td>${tag(PAY_STATUSES[x.status])}</td><td>${esc(x.ref || "—")}<div class="sub">${esc(x.payer || "")}</div></td>
      <td><div class="actions"><a class="btn sm ghost" href="#/pay/${x.id}">Lien</a><button class="btn sm ghost" data-act="copylink" data-id="${x.id}">Copier</button>${x.status === "awaiting_verification" ? `<button class="btn sm ok" data-act="pay-confirm" data-id="${x.id}">Confirmer</button>` : ""}${["pending", "awaiting_verification"].includes(x.status) ? `<button class="btn sm danger" data-act="pay-cancel" data-id="${x.id}">Annuler</button>` : ""}</div></td></tr>`).join("")}</table>` : `<p class="sub">Aucun paiement.</p>`}</div>`);
  }
  if (sub === "settings") {
    const s = settings();
    return dash("admin", "settings", `<h2 class="h2">Paramètres</h2><div class="card pad"><form data-form="settings"><div class="two" style="gap:10px"><label>Nom de l'entreprise<input name="name" value="${esc(s.name)}"></label><label>Responsable<input name="owner" value="${esc(s.owner)}"></label>
      <label>E-mail<input name="email" value="${esc(s.email)}"></label><label>Téléphone<input name="phone" value="${esc(s.phone)}"></label><label>Ville / Pays<input name="city" value="${esc(s.city)}"></label></div><button class="btn sm">Enregistrer</button></form></div>
      <div class="card pad" style="margin-top:14px"><h3>Sauvegarde</h3><p class="sub">Exportez toutes les données de cette démo (JSON).</p><button class="btn sm ghost" data-act="export">Exporter</button> <button class="btn sm danger" data-act="reset">Réinitialiser la démo</button></div>
      <div class="card pad tw" style="margin-top:14px"><h3>Historique des actions (audit)</h3><table><tr><th>Date</th><th>Par</th><th>Action</th></tr>${[...D().audit].reverse().slice(0, 40).map(a => `<tr><td>${fdt(a.at)}</td><td>${esc(a.by)}</td><td>${esc(a.action)}</td></tr>`).join("")}</table></div>`);
  }
  return dash("admin", "", `<p class="note">Page introuvable.</p>`);
}
function adminServices(id) {
  if (id) {
    const s = id === "new" ? {id: "", name: "", price: 250, plus: false, desc: "", features: [], active: true, icon: "🧩", currency: "USD"} : svc(id);
    if (!s) return dash("admin", "services", `<p class="note">Service introuvable.</p>`);
    return dash("admin", "services", `<a href="#/admin/services">← Services</a><div class="card pad" style="margin-top:10px"><h2 class="h2">${id === "new" ? "Ajouter un service" : "Modifier le service"}</h2>
      <form data-form="service-save"><input type="hidden" name="id" value="${s.id}"><label>Nom<input name="name" required value="${esc(s.name)}"></label><div class="two" style="gap:10px"><label>Prix de départ<input name="price" type="number" min="0" required value="${s.price}"></label>
      <label>Devise<select name="currency">${["USD", "HTG", "EUR"].map(x => `<option ${x === s.currency ? "selected" : ""}>${x}</option>`).join("")}</select></label></div>
      <label class="chk"><input type="checkbox" name="plus" ${s.plus ? "checked" : ""}><span>Afficher « et plus »</span></label><label>Description<textarea name="desc">${esc(s.desc)}</textarea></label>
      <label>Fonctionnalités (une par ligne)<textarea name="features">${esc(s.features.join("\n"))}</textarea></label><label>Icône (emoji)<input name="icon" value="${esc(s.icon)}"></label>
      <label>Image (max 300 Ko)<input type="file" name="image" accept="image/*"></label><label class="chk"><input type="checkbox" name="active" ${s.active ? "checked" : ""}><span>Service actif (visible publiquement)</span></label><button class="btn">Enregistrer</button></form></div>`);
  }
  return dash("admin", "services", `<div style="display:flex;justify-content:space-between;align-items:center"><h2 class="h2">Services & tarifs</h2><a class="btn sm" href="#/admin/services/new">+ Ajouter</a></div>
    <div class="card pad tw" style="margin-top:10px"><table><tr><th>Service</th><th>Prix de départ</th><th>État</th><th></th></tr>${D().services.map(s => `<tr><td>${esc(s.name)}</td><td>${money(s.price, s.currency)}${s.plus ? "+" : ""}</td><td>${tag(s.active ? "Actif" : "Désactivé")}</td>
    <td><div class="actions"><a class="btn sm ghost" href="#/admin/services/${s.id}">Modifier</a><button class="btn sm ghost" data-act="svc-toggle" data-id="${s.id}">${s.active ? "Désactiver" : "Activer"}</button><button class="btn sm danger" data-act="svc-del" data-id="${s.id}">Supprimer</button></div></td></tr>`).join("")}</table></div>`);
}

/* ---------- Paiement public (sans compte) ---------- */
function payPage(id) {
  const x = byId(D().payments, id);
  if (!x) return layout(`<div class="wrap"><div class="card pad pay"><h2>Lien de paiement introuvable</h2><p class="sub">Ce lien est invalide. En mode démo, les liens ne fonctionnent que dans le navigateur où ils ont été créés.</p></div></div>`);
  if (x.expires && x.status === "pending" && new Date(x.expires + "T23:59:59") < new Date()) { x.status = "expired"; Store.save(); }
  const total = Number(x.amount) + Number(x.fees || 0);
  let body;
  if (x.status === "pending") {
    body = `<div class="note" style="margin:12px 0">Aucun prestataire de paiement en ligne n'est encore connecté à SMOCK PAY. Effectuez le paiement selon les instructions communiquées par SMOCK PAY, puis déclarez-le ci-dessous. Il sera <b>confirmé uniquement après vérification</b> par SMOCK PAY.</div>
      <form data-form="pay-declare"><input type="hidden" name="id" value="${x.id}"><label>Votre nom<input name="payer" required value="${esc(x.clientName || "")}"></label><label>Méthode utilisée<input name="method" required placeholder="Ex. virement, transfert mobile…"></label><label>Référence / numéro de transaction<input name="ref" required></label><button class="btn">Déclarer mon paiement</button></form>`;
  } else if (x.status === "awaiting_verification") body = `<div class="note info" style="margin-top:12px">Votre déclaration (réf. ${esc(x.ref)}) a bien été reçue. Le paiement n'est pas encore confirmé : SMOCK PAY doit le vérifier.</div>`;
  else if (x.status === "confirmed") body = `<div class="note info" style="margin-top:12px;color:var(--ok)">✔ Paiement vérifié et confirmé le ${fdt(x.verifiedAt)}.</div>`;
  else body = `<div class="note" style="margin-top:12px">Ce lien n'est plus valide (${PAY_STATUSES[x.status].toLowerCase()}).</div>`;
  return layout(`<div class="wrap"><div class="card pad pay"><h2>Paiement SMOCK PAY</h2><p class="sub">${esc(x.description)}</p><div class="price" style="font-size:1.8rem;margin:8px 0">${money(total, x.currency)}</div>
    ${Number(x.fees) ? `<p class="sub">Dont frais : ${money(x.fees, x.currency)}</p>` : ""}<p>${tag(PAY_STATUSES[x.status])}</p>${x.expires ? `<p class="sub">Valable jusqu'au ${fd8(x.expires)}</p>` : ""}${body}<p class="sub" style="margin-top:12px;font-size:.8rem">Aucun compte n'est nécessaire pour ce paiement.</p></div></div>`);
}

/* ---------- Routeur ---------- */
function render(keep) {
  const y = window.scrollY;
  const p = location.hash.replace(/^#\/?/, "").split("/").filter(Boolean).map(decodeURIComponent);
  const me = Store.me();
  let html = "";
  const need = role => {
    if (!me) { sessionStorage.setItem("next", location.hash); go("#/login"); return false; }
    if (me.role !== role) { go(me.role === "admin" ? "#/admin" : "#/dash"); return false; }
    return true;
  };
  switch (p[0]) {
    case undefined: html = home(); break;
    case "services": html = services(); break;
    case "tarifs": html = tarifs(); break;
    case "service": html = serviceDetail(p[1]); break;
    case "login": html = authForm("login"); break;
    case "register": html = authForm("register"); break;
    case "setup": html = authForm("setup"); break;
    case "order": html = orderForm(p[1], "order"); break;
    case "quote": html = orderForm(p[1], "quote"); break;
    case "pay": html = payPage(p[1]); break;
    case "dash": if (!need("client")) return; html = clientDash(p[1], p[2]); break;
    case "admin": if (!need("admin")) return; html = adminDash(p[1], p[2]); break;
    default: html = layout(`<div class="wrap"><p class="sub" style="margin:60px 0">Page introuvable. <a href="#/">Accueil</a></p></div>`);
  }
  if (!html) return;
  document.body.classList.toggle("authpage", ["login", "register", "setup"].includes(p[0]));
  $app.innerHTML = html;
  window.scrollTo(0, keep ? y : 0);
}

/* ---------- Actions (clics) ---------- */
document.addEventListener("click", async e => {
  const el = e.target.closest("[data-act]");
  if (!el) return;
  const act = el.dataset.act, id = el.dataset.id, me = Store.me();
  const isAdmin = me && me.role === "admin";
  if (act === "navtoggle") return document.getElementById("nav").classList.toggle("open");
  e.preventDefault();
  if (act === "logout") { Store.log("Déconnexion"); D().session = null; Store.save(); go("#/"); return render(); }
  if (act === "readall") { D().notifications.forEach(n => { if (n.userId === me.id) n.read = true; }); Store.save(); return render(true); }
  if (act === "quote-accept" || act === "quote-refuse") {
    const p = proj(id); if (!p || p.clientId !== me.id) return;
    p.status = act === "quote-accept" ? "En attente de signature" : "Projet annulé";
    Store.notify(Store.admin().id, `Devis ${act === "quote-accept" ? "accepté" : "refusé"} : ${p.title}`, "#/admin/project/" + p.id);
    Store.log("Devis " + (act === "quote-accept" ? "accepté" : "refusé") + " " + p.id, me.id); Store.save(); toast("Réponse enregistrée"); return render(true);
  }
  if (act === "verify") {
    const c = byId(D().contracts, id), s = c.signatures.find(x => x.at === el.dataset.sig);
    const h = await Store.sha256(c.text);
    toast(h === s.hash ? "✔ Intégrité vérifiée : le contrat n'a pas été modifié depuis la signature." : "⚠ Le contenu ne correspond plus à la signature !"); return;
  }
  if (!isAdmin) return;
  if (act === "svc-toggle") { const s = svc(id); s.active = !s.active; Store.log("Service " + (s.active ? "activé" : "désactivé") + " " + s.name); Store.save(); return render(true); }
  if (act === "svc-del") { if (!confirm("Supprimer définitivement ce service ?")) return; D().services = D().services.filter(s => s.id !== id); Store.log("Service supprimé " + id); Store.save(); return render(true); }
  if (act === "copylink") {
    const url = location.href.split("#")[0] + "#/pay/" + id;
    try { await navigator.clipboard.writeText(url); toast("Lien copié"); } catch (_) { prompt("Copiez ce lien :", url); } return;
  }
  if (act === "pay-confirm") {
    const x = byId(D().payments, id);
    if (!confirm(`Confirmer que ${money(x.amount, x.currency)} (réf. ${x.ref}) a réellement été reçu et vérifié ?`)) return;
    x.status = "confirmed"; x.verifiedAt = Store.now(); x.verifiedBy = me.id;
    const p = x.projectId && proj(x.projectId);
    if (p) { Store.notify(p.clientId, "Votre paiement a été confirmé", "#/dash/payments"); if (/attente de paiement|Contrat signé/i.test(p.status)) p.status = "Paiement confirmé"; }
    Store.log("Paiement confirmé (vérification manuelle) " + x.id, p ? p.clientId : ""); Store.save(); toast("Paiement confirmé"); return render(true);
  }
  if (act === "pay-cancel") { const x = byId(D().payments, id); x.status = "cancelled"; Store.log("Paiement annulé " + id); Store.save(); return render(true); }
  if (act === "export") {
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(D(), null, 2)], {type: "application/json"})); a.download = "smockpay-sauvegarde.json"; a.click(); return;
  }
  if (act === "reset") { if (!confirm("Effacer TOUTES les données de la démo ?")) return; Store.reset(); go("#/"); return render(); }
});

/* ---------- Formulaires ---------- */
const fdata = f => Object.fromEntries(new FormData(f));
const err = m => { const n = document.getElementById("err"); if (n) n.textContent = m; };
const readFile = (file, max) => new Promise((res, rej) => {
  if (file.size > max) return rej(new Error(`Fichier trop volumineux (max ${Math.round(max / 1024)} Ko en mode démo).`));
  const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error("Lecture impossible")); r.readAsDataURL(file);
});
function afterLogin(u) {
  D().session = u.id; Store.log("Connexion"); Store.save();
  const next = sessionStorage.getItem("next"); sessionStorage.removeItem("next");
  go(next || (u.role === "admin" ? "#/admin" : "#/dash")); render();
}
document.addEventListener("submit", async e => {
  const f = e.target.closest("form[data-form]");
  if (!f) return;
  e.preventDefault();
  const k = f.dataset.form, d = fdata(f), me = Store.me();
  try {
    if (k === "setup" || k === "register") {
      if (k === "setup" && Store.hasAdmin()) return err("Un administrateur existe déjà.");
      const email = d.email.trim().toLowerCase();
      if (d.password.length < 8) return err("Mot de passe trop court (8 caractères minimum).");
      if (d.password !== d.password2) return err("Les mots de passe ne correspondent pas.");
      if (D().users.some(u => u.email === email)) return err("Cette adresse e-mail est déjà utilisée.");
      const u = {id: Store.uid("u"), name: d.name.trim(), email, phone: (d.phone || "").trim(), role: k === "setup" ? "admin" : "client", pass: await Store.hashPwd(email, d.password), createdAt: Store.now()};
      D().users.push(u); Store.log("Compte créé (" + u.role + ") " + u.id); return afterLogin(u);
    }
    if (k === "login") {
      const email = d.email.trim().toLowerCase(), u = D().users.find(x => x.email === email);
      if (!u || u.pass !== await Store.hashPwd(email, d.password)) return err("E-mail ou mot de passe incorrect.");
      return afterLogin(u);
    }
    if (k === "pay-declare") {
      const x = byId(D().payments, d.id); if (!x || x.status !== "pending") return;
      Object.assign(x, {status: "awaiting_verification", payer: d.payer, method: d.method, ref: d.ref, declaredAt: Store.now()});
      const a = Store.admin(); if (a) Store.notify(a.id, `Paiement déclaré à vérifier : ${x.description}`, "#/admin/transactions");
      Store.log("Paiement déclaré " + x.id); Store.save(); return render(true);
    }
    if (!me) return;
    if (k === "order") {
      const s = svc(d.serviceId);
      const p = {id: Store.uid("p"), clientId: me.id, serviceId: s.id, title: d.title.trim(), description: d.description.trim(), budget: d.budget || "", kind: d.mode, price: 0, currency: s.currency, status: "Demande reçue", progress: 0, eta: "", createdAt: Store.now()};
      D().projects.push(p);
      const a = Store.admin();
      if (a) { D().messages.push({id: Store.uid("m"), projectId: p.id, from: me.id, to: a.id, text: p.description, at: Store.now(), read: false}); Store.notify(a.id, `Nouvelle ${d.mode === "quote" ? "demande de devis" : "commande"} : ${p.title}`, "#/admin/project/" + p.id); }
      Store.log("Projet créé " + p.id, me.id); Store.save(); toast("Demande envoyée"); return go("#/dash/project/" + p.id);
    }
    if (k === "message") {
      const p = proj(d.projectId); const to = me.role === "admin" ? p.clientId : (Store.admin() || {}).id;
      if (me.role === "client" && p.clientId !== me.id) return;
      D().messages.push({id: Store.uid("m"), projectId: p.id, from: me.id, to, text: d.text.trim(), at: Store.now(), read: false});
      if (to) Store.notify(to, `Nouveau message — ${p.title}`, (me.role === "admin" ? "#/dash/project/" : "#/admin/project/") + p.id);
      Store.save(); return render(true);
    }
    if (k === "upload") {
      const r = byId(D().docRequests, d.requestId), p = r && proj(r.projectId);
      if (!p || p.clientId !== me.id) return;
      const file = f.querySelector("input[type=file]").files[0];
      const data = await readFile(file, MAX_FILE);
      D().files.push({id: Store.uid("f"), projectId: p.id, requestId: r.id, name: file.name, size: file.size, data, by: me.id, at: Store.now()});
      r.status = "Reçu";
      const a = Store.admin(); if (a) Store.notify(a.id, `Document reçu : ${r.type} (${p.title})`, "#/admin/project/" + p.id);
      Store.log("Fichier envoyé " + file.name, me.id);
      if (!Store.save()) { D().files.pop(); r.status = "En attente"; return toast("Stockage plein : fichier non enregistré."); }
      toast("Fichier envoyé"); return render(true);
    }
    if (k === "sign-client") {
      const c = byId(D().contracts, d.id), p = proj(c.projectId);
      if (p.clientId !== me.id || c.status !== "sent") return;
      if (d.name.trim().toLowerCase() !== me.name.trim().toLowerCase()) return err("Le nom saisi doit correspondre exactement au nom de votre compte.");
      c.signatures.push({role: "client", userId: me.id, name: me.name, at: Store.now(), ua: navigator.userAgent, hash: await Store.sha256(c.text)});
      c.status = "signed_client";
      const a = Store.admin(); if (a) Store.notify(a.id, `Contrat signé par le client : ${p.title}`, "#/admin/project/" + p.id);
      Store.log("Contrat signé (client) " + c.id, me.id); Store.save(); toast("Contrat signé"); return render(true);
    }
    if (me.role !== "admin") return;
    if (k === "docreq") {
      const p = proj(d.projectId);
      D().docRequests.push({id: Store.uid("r"), projectId: p.id, type: d.type, note: d.note, status: "En attente", createdAt: Store.now()});
      Store.notify(p.clientId, `Document demandé : ${d.type}`, "#/dash/project/" + p.id); Store.log("Document demandé " + d.type, p.clientId); Store.save(); return render(true);
    }
    if (k === "docstatus") { byId(D().docRequests, d.id).status = d.status; Store.save(); return render(true); }
    if (k === "project-update") {
      const p = proj(d.id), op = e.submitter && e.submitter.value;
      Object.assign(p, {status: d.status, progress: Math.min(100, Math.max(0, Number(d.progress) || 0)), price: Number(d.price) || 0, currency: d.currency, eta: d.eta});
      if (op === "quote") { if (!p.price) return toast("Indiquez un prix pour envoyer un devis."); p.status = "Devis envoyé"; Store.notify(p.clientId, `Devis reçu : ${money(p.price, p.currency)} — ${p.title}`, "#/dash/project/" + p.id); }
      else Store.notify(p.clientId, `Mise à jour du projet : ${p.status} (${p.progress}%)`, "#/dash/project/" + p.id);
      Store.log("Projet mis à jour " + p.id, p.clientId); Store.save(); toast("Enregistré"); return render(true);
    }
    if (k === "contract-create") {
      const p = proj(d.projectId);
      D().contracts.push({id: Store.uid("c"), projectId: p.id, version: 1, status: "draft", text: contractTemplate(p), signatures: [], createdAt: Store.now()});
      Store.log("Contrat préparé " + p.id, p.clientId); Store.save(); return render(true);
    }
    if (k === "contract-save") {
      const c = byId(D().contracts, d.id), p = proj(c.projectId), op = e.submitter && e.submitter.value;
      if (c.status !== "draft") return;
      c.text = d.text;
      if (op === "send") { c.status = "sent"; p.status = "En attente de signature"; Store.notify(p.clientId, `Contrat à signer : ${p.title}`, "#/dash/project/" + p.id); toast("Contrat envoyé au client"); }
      Store.log("Contrat " + (op === "send" ? "envoyé " : "enregistré ") + c.id, p.clientId); Store.save(); return render(true);
    }
    if (k === "sign-admin") {
      const c = byId(D().contracts, d.id), p = proj(c.projectId);
      if (c.status !== "signed_client") return;
      c.signatures.push({role: "admin", userId: me.id, name: me.name, at: Store.now(), ua: navigator.userAgent, hash: await Store.sha256(c.text)});
      c.status = "signed"; if (/attente de signature|Devis/i.test(p.status)) p.status = "Contrat signé";
      Store.notify(p.clientId, `Contrat signé par les deux parties : ${p.title}`, "#/dash/project/" + p.id);
      Store.log("Contrat contresigné " + c.id, p.clientId); Store.save(); toast("Contrat contresigné"); return render(true);
    }
    if (k === "contract-newver") {
      const old = byId(D().contracts, d.id);
      old.status = "superseded";
      D().contracts.push({id: Store.uid("c"), projectId: old.projectId, version: old.version + 1, status: "draft", text: old.text, signatures: [], createdAt: Store.now()});
      Store.log("Nouvelle version du contrat " + old.projectId); Store.save(); return render(true);
    }
    if (k === "pay-create") {
      const p = d.projectId ? proj(d.projectId) : null;
      const x = {id: Store.uid("pay").replace("_", ""), projectId: p ? p.id : null, amount: Number(d.amount), currency: d.currency, description: d.description, clientName: d.clientName, fees: Number(d.fees) || 0, expires: d.expires, status: "pending", createdAt: Store.now()};
      D().payments.push(x);
      if (p) { Store.notify(p.clientId, `Lien de paiement : ${money(x.amount, x.currency)}`, "#/dash/payments"); if (/Contrat signé|Devis|attente de signature/i.test(p.status)) p.status = "En attente de paiement"; }
      Store.log("Lien de paiement créé " + x.id, p ? p.clientId : ""); Store.save();
      toast("Lien créé : utilisez « Copier » dans Paiements"); return render(true);
    }
    if (k === "service-save") {
      let s = d.id && svc(d.id);
      if (!s) { s = {id: Store.uid("svc"), n: D().services.length + 1, image: ""}; D().services.push(s); }
      Object.assign(s, {name: d.name.trim(), price: Number(d.price), currency: d.currency, plus: !!d.plus, desc: d.desc, features: d.features.split("\n").map(x => x.trim()).filter(Boolean), icon: d.icon || "🧩", active: !!d.active});
      const file = f.querySelector("input[type=file]").files[0];
      if (file) s.image = await readFile(file, 300 * 1024);
      Store.log("Service enregistré " + s.name); Store.save(); toast("Service enregistré"); return go("#/admin/services");
    }
    if (k === "settings") { Object.assign(settings(), d); Store.log("Paramètres modifiés"); Store.save(); toast("Enregistré"); return render(true); }
  } catch (ex) { toast(ex.message || "Erreur"); }
});

function contractTemplate(p) {
  const c = user(p.clientId), s = svc(p.serviceId), co = settings();
  return `CONTRAT DE DÉVELOPPEMENT WEB
Référence du projet : ${p.id}
Date : ${fd8(Store.now())}

1. PARTIES
Prestataire : ${co.name} — représenté par ${co.owner}${co.email ? " — " + co.email : ""}${co.phone ? " — " + co.phone : ""}
Client : ${c.name} — ${c.email} — ${c.phone}

2. DESCRIPTION DU PROJET
Projet : ${p.title}
Service : ${s ? s.name : ""}
Description : ${p.description}

3. FONCTIONNALITÉS CONVENUES
${s ? s.features.map(f => "- " + f).join("\n") : "- À préciser"}
(Compléter ou modifier selon l'accord entre les parties.)

4. PRIX ET DEVISE
Prix total convenu : ${p.price ? money(p.price, p.currency) : "[à compléter]"}
Devise : ${p.currency}

5. MODALITÉS DE PAIEMENT
[Ex. acompte de 50 % à la signature, solde à la livraison.] Les paiements sont considérés comme reçus uniquement après vérification par ${co.name}.

6. DÉLAIS
Livraison estimée : ${p.eta ? fd8(p.eta) : "[à compléter]"}. Les délais dépendent de la transmission en temps voulu des documents et informations demandés au client.

7. RESPONSABILITÉS DES PARTIES
Le prestataire réalise le projet selon les règles de l'art. Le client fournit les contenus, informations et validations nécessaires, et garantit détenir les droits sur les contenus fournis.

8. CONDITIONS DE LIVRAISON
Le projet est livré après tests et validation du client. Toute anomalie signalée dans la période de recette sera corrigée.

9. CONDITIONS DE MODIFICATION
Toute modification du périmètre fait l'objet d'un avenant écrit et peut modifier le prix et les délais. Toute modification du présent contrat après signature crée une nouvelle version à signer.

10. CONDITIONS D'ANNULATION
[Préciser les conditions d'annulation et les sommes non remboursables pour le travail déjà réalisé.]

11. PROPRIÉTÉ INTELLECTUELLE
[Préciser le transfert des droits au client après paiement intégral, et les éléments réservés par le prestataire.]

12. SIGNATURES
Les signatures électroniques sont enregistrées avec la date, l'identité du signataire et l'empreinte numérique (SHA-256) de ce texte.

⚠ Modèle à faire valider selon les lois applicables avant usage.`;
}

window.addEventListener("hashchange", () => render());
render();
})();
