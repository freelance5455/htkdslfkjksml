/* SMOCK PAY V3 — catalogue des services, offres et statuts */
const SERVICES = [
  [1,"Site vitrine professionnel",250,false,"🏢","Présentez votre activité avec un site élégant et rapide.",["Design sur mesure","Pages Accueil / À propos / Contact","Formulaire de contact","Responsive"]],
  [2,"Site personnel / Portfolio",250,false,"🎨","Mettez en valeur votre travail et votre parcours.",["Galerie de projets","CV en ligne","Contact direct","Responsive"]],
  [3,"Site Web pour entreprise",300,false,"💼","Un site complet pour crédibiliser votre entreprise.",["Pages services","Équipe & références","Formulaires","SEO de base"]],
  [4,"Site Web pour restaurant",300,false,"🍽️","Menu, réservations et présentation de votre établissement.",["Menu en ligne","Galerie photos","Réservation","Carte & horaires"]],
  [5,"Site Web pour hôtel",350,false,"🏨","Présentez vos chambres et recevez des demandes de réservation.",["Chambres & tarifs","Galerie","Demande de réservation","Carte & contact"]],
  [6,"Site Web pour agence immobilière",400,false,"🏠","Publiez vos biens et captez des prospects.",["Annonces de biens","Filtres de recherche","Fiches détaillées","Contact agent"]],
  [7,"Site Web éducatif / École",400,false,"🎓","Informations, inscriptions et vie de l'établissement.",["Présentation des programmes","Actualités","Formulaire d'inscription","Calendrier"]],
  [8,"Site Web pour université",500,false,"🏛️","Portail institutionnel avec facultés et admissions.",["Facultés & filières","Admissions","Actualités","Espace documents"]],
  [9,"Blog professionnel",250,false,"✍️","Publiez des articles et développez votre audience.",["Articles & catégories","Commentaires","Newsletter","SEO de base"]],
  [10,"Site Web d'actualités / Magazine",350,false,"📰","Un média en ligne clair et facile à alimenter.",["Rubriques","Gestion des articles","Recherche","Partage social"]],
  [11,"Site Web médical / Clinique",450,false,"🩺","Présentez vos services de santé et vos praticiens.",["Services & spécialités","Équipe médicale","Prise de rendez-vous","Informations pratiques"]],
  [12,"Site Web pour ONG",300,false,"🤝","Faites connaître votre mission et mobilisez des soutiens.",["Projets & actions","Actualités","Appel aux dons (info)","Contact bénévoles"]],
  [13,"Site Web pour cabinet juridique",350,false,"⚖️","Une présence sérieuse pour votre cabinet.",["Domaines d'expertise","Équipe","Demande de consultation","Publications"]],
  [14,"Site Web pour agence de voyage",400,false,"✈️","Offres de voyage et demandes de devis.",["Destinations & offres","Galerie","Demande de devis","Contact"]],
  [15,"Site Web pour entreprise de transport",350,false,"🚚","Services, zones desservies et demandes de transport.",["Services & tarifs","Zones desservies","Demande de devis","Suivi (informatif)"]],
  [16,"Site Web événementiel",300,false,"🎉","Promouvez vos événements et gérez les inscriptions.",["Programme","Intervenants","Inscription","Galerie"]],
  [17,"Plateforme de réservation en ligne",500,false,"📅","Réservations de créneaux, salles ou services.",["Calendrier","Gestion des réservations","Notifications","Tableau de bord admin"]],
  [18,"Site Web de petites annonces",500,false,"📌","Publication et recherche d'annonces.",["Dépôt d'annonces","Catégories & filtres","Modération","Comptes utilisateurs"]],
  [19,"Marketplace multi-vendeurs",700,false,"🛍️","Plusieurs vendeurs, une seule plateforme.",["Comptes vendeurs","Catalogues multiples","Commissions","Administration centrale"]],
  [20,"Site e-commerce professionnel",450,false,"🛒","Boutique en ligne avec administration complète.",["Catalogue & panier","Gestion commandes & stocks","Tableau de bord admin","Paiement compatible"]],
  [21,"Boutique e-commerce avancée",600,false,"💎","Boutique évoluée avec suivi et promotions.",["Espace client","Codes promo","Suivi des commandes","Statistiques"]],
  [22,"Plateforme e-commerce personnalisée",900,true,"🚀","Solution e-commerce entièrement adaptée à vos besoins.",["Architecture évolutive","Intégrations API","Automatisations","Fonctionnalités sur mesure"]],
  [23,"Plateforme de gestion d'entreprise",700,false,"📊","Centralisez clients, projets, facturation et rapports.",["Gestion clients","Suivi d'activité","Rôles & permissions","Rapports"]],
  [24,"Application Web personnalisée",900,true,"⚙️","Application métier développée selon votre cahier des charges.",["Analyse des besoins","Développement sur mesure","Tests & recette","Évolutivité"]]
].map(([n,name,price,plus,icon,desc,features]) => ({id:"svc"+n,n,name,price,plus,icon,desc,features,currency:"USD",image:""}));

const OFFERS = [
  {name:"E-commerce Starter",price:250,features:["Design professionnel","Page d'accueil","Catalogue & catégories","Fiches produits détaillées","Panier d'achat","Formulaire de commande","Interface responsive"]},
  {name:"E-commerce Professionnel",price:450,features:["Toutes les fonctionnalités Starter","Tableau de bord administrateur","Gestion produits, commandes, clients","Gestion des stocks et des prix","Intégration d'un système de paiement compatible","Notifications de commandes"]},
  {name:"E-commerce Avancé",price:650,features:["Toutes les fonctionnalités Professionnel","Tableau de bord client","Gestion avancée des commandes","Gestion des livraisons & suivi","Codes promotionnels","Statistiques commerciales","Automatisation de certaines opérations"]},
  {name:"E-commerce sur mesure",price:900,plus:true,features:["Marketplace multi-vendeurs","Plusieurs méthodes de paiement","Gestion de plusieurs boutiques","Système de commissions","Intégration d'API externes","Architecture évolutive"]}
];

const PROJECT_STATUSES = [
  "Demande reçue","Analyse du projet","En attente d'informations","Devis envoyé","En attente de signature",
  "Contrat signé","En attente de paiement","Paiement confirmé","Projet en développement","Tests et corrections",
  "Validation du client","Projet terminé","Projet livré","Projet suspendu","Projet annulé"
];
const DOC_TYPES = ["Photos","Logos","Vidéos","Documents","Textes","Informations sur l'entreprise","Informations techniques","Informations sur le système de paiement souhaité"];
const DOC_STATUSES = ["En attente","Partiellement reçu","Reçu","À compléter"];
const PAY_STATUSES = {pending:"En attente de paiement",awaiting_verification:"Déclaré — en attente de vérification",confirmed:"Confirmé",expired:"Expiré",cancelled:"Annulé"};
