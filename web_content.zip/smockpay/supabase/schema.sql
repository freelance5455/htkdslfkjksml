-- SMOCK PAY V3 — schéma Supabase (PostgreSQL) recommandé
-- À ADAPTER au schéma de SMOCK_PAY_Web_App_v2 pour éviter les tables redondantes.
-- Toutes les tables ont RLS activé : un client ne voit que ses propres données.

create extension if not exists pgcrypto;

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text not null, email text not null, phone text,
  role text not null default 'client' check (role in ('client','admin')),
  created_at timestamptz default now()
);
create or replace function is_admin() returns boolean language sql stable security definer as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;

create table services (
  id uuid primary key default gen_random_uuid(), position int, name text not null, description text,
  features jsonb default '[]', start_price numeric not null, price_plus boolean default false,
  currency text default 'USD', image_url text, icon text, active boolean default true, created_at timestamptz default now()
);
create table projects (
  id uuid primary key default gen_random_uuid(), client_id uuid references profiles(id) not null,
  service_id uuid references services(id), title text not null, description text, kind text default 'order',
  agreed_price numeric, currency text default 'USD', status text not null default 'Demande reçue',
  progress int default 0 check (progress between 0 and 100), eta date, created_at timestamptz default now()
);
create table project_updates (id uuid primary key default gen_random_uuid(), project_id uuid references projects(id) on delete cascade, status text, progress int, by uuid references profiles(id), created_at timestamptz default now());
create table project_messages (id uuid primary key default gen_random_uuid(), project_id uuid references projects(id) on delete cascade, sender_id uuid references profiles(id), recipient_id uuid references profiles(id), body text not null, read_at timestamptz, created_at timestamptz default now());
create table document_requests (id uuid primary key default gen_random_uuid(), project_id uuid references projects(id) on delete cascade, doc_type text, note text, status text default 'En attente', created_at timestamptz default now());
create table project_files (id uuid primary key default gen_random_uuid(), project_id uuid references projects(id) on delete cascade, request_id uuid references document_requests(id), storage_path text not null, file_name text, size_bytes bigint, uploaded_by uuid references profiles(id), created_at timestamptz default now());
create table contracts (id uuid primary key default gen_random_uuid(), project_id uuid references projects(id) on delete cascade, version int not null default 1, status text default 'draft', body text not null, body_sha256 text, created_at timestamptz default now(), unique(project_id, version));
create table contract_signatures (id uuid primary key default gen_random_uuid(), contract_id uuid references contracts(id) on delete cascade, signer_id uuid references profiles(id), role text, signed_name text, body_sha256 text not null, ip inet, user_agent text, signed_at timestamptz default now());
create table payment_providers (id uuid primary key default gen_random_uuid(), name text not null, enabled boolean default false, config_ref text); -- clés API : JAMAIS ici, uniquement dans les secrets serveur
create table payment_requests (id uuid primary key default gen_random_uuid(), public_token text unique not null default encode(gen_random_bytes(16),'hex'), project_id uuid references projects(id), amount numeric not null, fees numeric default 0, currency text default 'USD', description text, client_name text, expires_at timestamptz, status text default 'pending', created_by uuid references profiles(id), created_at timestamptz default now());
create table transactions (id uuid primary key default gen_random_uuid(), payment_request_id uuid references payment_requests(id), provider_id uuid references payment_providers(id), provider_ref text, amount numeric, currency text, status text default 'awaiting_verification', verified_by uuid references profiles(id), verified_at timestamptz, created_at timestamptz default now());
create table payment_events (id uuid primary key default gen_random_uuid(), provider_id uuid references payment_providers(id), event_type text, payload jsonb, signature_valid boolean, received_at timestamptz default now()); -- alimenté par webhooks (Edge Function)
create table notifications (id uuid primary key default gen_random_uuid(), user_id uuid references profiles(id), body text, link text, read boolean default false, created_at timestamptz default now());
create table audit_logs (id uuid primary key default gen_random_uuid(), actor_id uuid, action text, detail jsonb, created_at timestamptz default now());

-- RLS
do $$ declare t text; begin
  foreach t in array array['profiles','services','projects','project_updates','project_messages','document_requests','project_files','contracts','contract_signatures','payment_providers','payment_requests','transactions','payment_events','notifications','audit_logs'] loop
    execute format('alter table %I enable row level security', t);
  end loop; end $$;

create policy "services lisibles" on services for select using (active or is_admin());
create policy "services admin" on services for all using (is_admin()) with check (is_admin());
create policy "profil propre" on profiles for select using (id = auth.uid() or is_admin());
create policy "projets du client" on projects for select using (client_id = auth.uid() or is_admin());
create policy "client crée son projet" on projects for insert with check (client_id = auth.uid());
create policy "admin modifie projets" on projects for update using (is_admin());
create policy "messages du projet" on project_messages for select using (is_admin() or exists (select 1 from projects p where p.id = project_id and p.client_id = auth.uid()));
create policy "envoi message" on project_messages for insert with check (sender_id = auth.uid() and (is_admin() or exists (select 1 from projects p where p.id = project_id and p.client_id = auth.uid())));
create policy "docreq lecture" on document_requests for select using (is_admin() or exists (select 1 from projects p where p.id = project_id and p.client_id = auth.uid()));
create policy "docreq admin" on document_requests for all using (is_admin()) with check (is_admin());
create policy "fichiers lecture" on project_files for select using (is_admin() or exists (select 1 from projects p where p.id = project_id and p.client_id = auth.uid()));
create policy "fichiers envoi" on project_files for insert with check (uploaded_by = auth.uid());
create policy "contrats lecture" on contracts for select using (is_admin() or (status <> 'draft' and exists (select 1 from projects p where p.id = project_id and p.client_id = auth.uid())));
create policy "contrats admin" on contracts for all using (is_admin()) with check (is_admin());
create policy "signatures lecture" on contract_signatures for select using (is_admin() or signer_id = auth.uid());
create policy "signature client" on contract_signatures for insert with check (signer_id = auth.uid());
create policy "paiements lecture" on payment_requests for select using (is_admin() or exists (select 1 from projects p where p.id = project_id and p.client_id = auth.uid()));
create policy "paiements admin" on payment_requests for all using (is_admin()) with check (is_admin());
create policy "transactions lecture" on transactions for select using (is_admin());
create policy "notifs propres" on notifications for select using (user_id = auth.uid());
create policy "audit admin" on audit_logs for select using (is_admin());
-- Les tables payment_providers, payment_events et la CONFIRMATION de transactions ne sont écrites que par des Edge Functions (service role), après vérification serveur.
-- Page de paiement publique : exposer UNIQUEMENT via une fonction RPC/Edge Function qui prend public_token (pas de select public sur payment_requests).
-- Storage : bucket privé 'project-files', accès par URL signée, policies basées sur le projet.
