# My Personal Tracker

This is a mobile-first personal money/tasks/reminders/goals app.

## Build as Android APK
Use Android Studio with a WebView wrapper, or a Capacitor Android project, and load `index.html` as the app content.

The app stores data in browser/app local storage. Export JSON regularly for backup.
