# راهنمای ساخت APK با پرداخت مایکت (SDK 2.2)

1. پروژه را در Android Studio باز کنید (Open → پوشه myket-android) و Sync کنید. مخزن https://maven.myket.ir در settings.gradle اضافه شده است.
2. دیگر نیازی به IInAppBillingService.aidl یا کپی TrivialDrive نیست؛ SDK خودش همه‌چیز را دارد.
3. در پنل توسعه‌دهندگان مایکت برای package `app.tradyar` این محصولات را بسازید (نوع: مصرفی/inapp):
   - بسته‌های توکن: `tradyar_coins_<id>` (مثلاً tradyar_coins_p1 ، p2 ، p3)
   - اشتراک‌ها: `tradyar_sub_<id>` (مثلاً tradyar_sub_sh1 …) — مایکت اشتراک ندارد، پس مصرفی تعریف می‌شوند.
   شناسهٔ <id> باید با id بسته/اشتراک در کاتالوگ برنامه یکی باشد.
4. کلید عمومی جدید در app/build.gradle (IAB_PUBLIC_KEY) قرار گرفته است.
5. Build → Generate Signed Bundle/APK.
توکن اختصاصی `app_v1_…` را داخل برنامه نگذارید؛ فقط برای اعتبارسنجی سمت سرور است.
