package app.tradyar;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import ir.myket.billingclient.IabHelper;
import ir.myket.billingclient.util.IabResult;
import ir.myket.billingclient.util.Inventory;
import ir.myket.billingclient.util.Purchase;

/**
 * MyketBridge — پل جاوااسکریپت ↔ SDK رسمی پرداخت مایکت (نسخه 2.2)
 *
 * طبق مستندات مایکت:
 *  - همهٔ محصولات (از جمله «اشتراک‌ها») از نوع inapp خریداری می‌شوند؛ مایکت از subs پشتیبانی نمی‌کند.
 *  - ابتدا startSetup، سپس queryInventory/launchPurchaseFlow.
 *  - نیازی به onActivityResult نیست؛ SDK خودش نتیجه را به Callback می‌دهد.
 *  - فراخوانی‌های SDK روی thread اصلی انجام می‌شود.
 *
 * هر فراخوانی از JS یک callbackId رشته‌ای می‌گیرد و نتیجه با
 * window.__invokeMyketCallback(callbackId, data) برگردانده می‌شود.
 */
public class MyketBridge {
    private static final String TAG = "MyketBridge";

    private final Activity activity;
    private final WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private IabHelper mHelper;
    private volatile boolean isSetup = false;
    private boolean setupInProgress = false;

    /** خریدهایی که در همین نشست دیده شده‌اند (token → Purchase) تا بتوان مصرفشان کرد */
    private final Map<String, Purchase> knownPurchases = new HashMap<>();
    /** همهٔ SKUهایی که JS تا الان پرسیده؛ برای پیدا کردن خرید با توکن */
    private final Set<String> knownSkus = new LinkedHashSet<>();

    public MyketBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    /* ------------------------------------------------------------------ */
    /* مرحله ۱ — startSetup                                                */
    /* ------------------------------------------------------------------ */
    @JavascriptInterface
    public void startSetup(final String ignoredKeyFromJs) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (isSetup || setupInProgress) {
                    if (isSetup) callJavaScript("myketOnSetupFinished", "{\"success\":true}");
                    return;
                }
                setupInProgress = true;
                try {
                    mHelper = new IabHelper(activity, BuildConfig.IAB_PUBLIC_KEY);
                    mHelper.enableDebugLogging(BuildConfig.DEBUG, TAG);
                    mHelper.startSetup(result -> {
                        setupInProgress = false;
                        if (result == null || !result.isSuccess()) {
                            isSetup = false;
                            String msg = result != null ? result.getMessage() : "unknown";
                            Log.e(TAG, "Setup failed: " + msg);
                            try { if (mHelper != null) mHelper.dispose(); } catch (Throwable ignored) { }
                            mHelper = null; // تا تلاش بعدی از نو شروع شود
                            callJavaScript("myketOnSetupFinished",
                                    "{\"success\":false,\"message\":\"" + esc(msg) + "\"}");
                            return;
                        }
                        isSetup = true;
                        callJavaScript("myketOnSetupFinished", "{\"success\":true}");
                    });
                } catch (Throwable e) {
                    setupInProgress = false;
                    isSetup = false;
                    mHelper = null;
                    Log.e(TAG, "startSetup error", e);
                    callJavaScript("myketOnSetupFinished",
                            "{\"success\":false,\"message\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
                }
            }
        });
    }

    @JavascriptInterface
    public boolean isSetup() {
        return isSetup && mHelper != null;
    }

    /* ------------------------------------------------------------------ */
    /* مرحله ۲ — queryInventory (خریدهای مصرف‌نشده + بازیابی بعد از کرش)   */
    /* ------------------------------------------------------------------ */
    @JavascriptInterface
    public void queryInventoryAsync(boolean querySkuDetails, String itemSkusJson, String subSkusJson,
                                    final String callbackId) {
        final List<String> skus = parseSkus(itemSkusJson);
        // مایکت اشتراک ندارد؛ هر SKU که از سمت JS به‌عنوان sub بیاید هم به‌عنوان inapp پرسیده می‌شود
        for (String s : parseSkus(subSkusJson)) if (!skus.contains(s)) skus.add(s);
        synchronized (knownSkus) { knownSkus.addAll(skus); }
        final boolean details = querySkuDetails;

        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mHelper == null || !isSetup) {
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"not_setup\"}");
                    return;
                }
                if (skus.isEmpty()) {
                    invokeCallback(callbackId, "{\"success\":true,\"purchases\":[],\"purchase\":[]}");
                    return;
                }
                try {
                    mHelper.queryInventoryAsync(details, skus, (result, inventory) -> {
                        if (result == null || result.isFailure() || inventory == null) {
                            invokeCallback(callbackId, "{\"success\":false,\"message\":\""
                                    + esc(result != null ? result.getMessage() : "unknown") + "\"}");
                            return;
                        }
                        try {
                            JSONArray arr = new JSONArray();
                            for (String sku : skus) {
                                Purchase p = inventory.getPurchase(sku);
                                if (p == null) continue;
                                if (p.getToken() != null) knownPurchases.put(p.getToken(), p);
                                arr.put(purchaseJson(p));
                            }
                            JSONObject out = new JSONObject();
                            out.put("success", true);
                            out.put("purchases", arr);
                            out.put("purchase", arr); // سازگاری با کد قدیمی JS
                            invokeCallback(callbackId, out.toString());
                        } catch (Throwable e) {
                            invokeCallback(callbackId, "{\"success\":false,\"message\":\""
                                    + esc(String.valueOf(e.getMessage())) + "\"}");
                        }
                    });
                } catch (Throwable e) {
                    Log.e(TAG, "queryInventoryAsync error", e);
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + errCode(e) + "\",\"message\":\""
                            + esc(String.valueOf(e.getMessage())) + "\"}");
                }
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* مرحله ۳ — launchPurchaseFlow (درگاه پرداخت مایکت)                   */
    /* ------------------------------------------------------------------ */
    @JavascriptInterface
    public void launchPurchaseFlow(final String sku, String itemType, final String developerPayload,
                                   final String callbackId) {
        synchronized (knownSkus) { if (sku != null) knownSkus.add(sku); }
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mHelper == null || !isSetup) {
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"not_ready\",\"message\":\"درگاه مایکت آماده نیست\"}");
                    return;
                }
                String payload = developerPayload == null ? "" : developerPayload;
                if (payload.length() > 800) payload = payload.substring(0, 800); // سقف مستندات مایکت
                try {
                    mHelper.launchPurchaseFlow(activity, sku, (result, purchase) -> {
                        if (result == null || result.isFailure() || purchase == null) {
                            String msg = result != null ? result.getMessage() : "unknown";
                            String low = msg == null ? "" : msg.toLowerCase();
                            boolean cancelled = low.contains("cancel");
                            boolean owned = low.contains("already owned"); // کد ۷: خرید قبلی مصرف‌نشده
                            String code = cancelled ? "cancelled" : (owned ? "already_owned" : "purchase_failed");
                            invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + code
                                    + "\",\"cancelled\":" + cancelled
                                    + ",\"message\":\"" + esc(msg) + "\"}");
                            return;
                        }
                        try {
                            if (purchase.getToken() != null) knownPurchases.put(purchase.getToken(), purchase);
                            JSONObject p = purchaseJson(purchase);
                            JSONObject out = new JSONObject();
                            out.put("success", true);
                            out.put("isSuccess", true);
                            out.put("purchase", p);
                            out.put("token", purchase.getToken());
                            out.put("purchaseToken", purchase.getToken());
                            out.put("orderId", purchase.getOrderId());
                            invokeCallback(callbackId, out.toString());
                        } catch (Throwable e) {
                            invokeCallback(callbackId, "{\"success\":false,\"error\":\"bad_purchase\"}");
                        }
                    }, payload);
                } catch (Throwable e) {
                    Log.e(TAG, "launchPurchaseFlow error", e);
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + errCode(e) + "\",\"message\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
                }
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* مرحله ۴ — consumeAsync                                              */
    /* ------------------------------------------------------------------ */
    @JavascriptInterface
    public void consumeAsync(String tokenOrPurchase, final String callbackId) {
        String t = tokenOrPurchase == null ? "" : tokenOrPurchase.trim();
        if (t.startsWith("{")) {
            try {
                JSONObject o = new JSONObject(t);
                t = o.optString("token", o.optString("purchaseToken", o.optString("mToken", "")));
            } catch (Throwable ignored) { }
        }
        final String token = t;
        if (token.isEmpty()) {
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"invalid_token\"}");
            return;
        }
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mHelper == null || !isSetup) {
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"not_setup\"}");
                    return;
                }
                Purchase known = knownPurchases.get(token);
                if (known != null) {
                    doConsume(known, callbackId);
                    return;
                }
                // خرید در این نشست دیده نشده (مثلاً بعد از ری‌استارت): از موجودی پیدا می‌کنیم
                final List<String> skus;
                synchronized (knownSkus) { skus = new ArrayList<>(knownSkus); }
                if (skus.isEmpty()) {
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"purchase_not_found\"}");
                    return;
                }
                try {
                    mHelper.queryInventoryAsync(false, skus, (result, inventory) -> {
                        Purchase found = null;
                        if (result != null && result.isSuccess() && inventory != null) {
                            for (String sku : skus) {
                                Purchase p = inventory.getPurchase(sku);
                                if (p != null && token.equals(p.getToken())) { found = p; break; }
                            }
                        }
                        if (found == null) {
                            invokeCallback(callbackId, "{\"success\":false,\"error\":\"purchase_not_found\"}");
                            return;
                        }
                        knownPurchases.put(token, found);
                        doConsume(found, callbackId);
                    });
                } catch (Throwable e) {
                    invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
                }
            }
        });
    }

    private void doConsume(final Purchase purchase, final String callbackId) {
        try {
            mHelper.consumeAsync(purchase, (consumed, result) -> {
                if (result != null && result.isSuccess()) {
                    if (purchase.getToken() != null) knownPurchases.remove(purchase.getToken());
                    invokeCallback(callbackId, "{\"success\":true,\"isSuccess\":true}");
                } else {
                    invokeCallback(callbackId, "{\"success\":false,\"message\":\""
                            + esc(result != null ? result.getMessage() : "unknown") + "\"}");
                }
            });
        } catch (Throwable e) {
            Log.e(TAG, "consume error", e);
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
        }
    }

    @JavascriptInterface
    public String generateCallbackId() {
        return "cb_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 8);
    }

    /* ------------------------------------------------------------------ */
    private JSONObject purchaseJson(Purchase p) throws Exception {
        JSONObject o = new JSONObject();
        o.put("sku", p.getSku());
        o.put("token", p.getToken());
        o.put("orderId", p.getOrderId());
        o.put("itemType", p.getItemType());
        o.put("packageName", p.getPackageName());
        o.put("purchaseTime", p.getPurchaseTime());
        o.put("purchaseState", p.getPurchaseState());
        o.put("developerPayload", p.getDeveloperPayload());
        o.put("originalJson", p.getOriginalJson());
        o.put("signature", p.getSignature());
        return o;
    }

    private List<String> parseSkus(String json) {
        List<String> skus = new ArrayList<>();
        if (json == null || json.trim().isEmpty()) return skus;
        try {
            if (json.trim().startsWith("[")) {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length(); i++) {
                    String s = a.optString(i, "").trim();
                    if (!s.isEmpty() && !skus.contains(s)) skus.add(s);
                }
            } else {
                for (String part : json.split(",")) {
                    String s = part.trim().replace("\"", "");
                    if (!s.isEmpty() && !skus.contains(s)) skus.add(s);
                }
            }
        } catch (Throwable e) {
            Log.e(TAG, "parseSkus: " + json, e);
        }
        return skus;
    }

    /** SDK مایکت هم‌زمان فقط یک عملیات می‌پذیرد؛ این حالت را «busy» می‌نامیم تا JS دوباره تلاش کند */
    private String errCode(Throwable e) {
        return e.getClass().getSimpleName().contains("AsyncInProgress") ? "busy" : "failed";
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    private void invokeCallback(final String callbackId, final String data) {
        if (callbackId == null || callbackId.isEmpty()) return;
        final String safe = (data == null || data.equals("null")) ? "null" : data;
        final String js = "if(window.__invokeMyketCallback){window.__invokeMyketCallback(\"" + esc(callbackId) + "\"," + safe + ");}";
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try { webView.evaluateJavascript(js, null); } catch (Throwable e) { Log.e(TAG, "invokeCallback", e); }
            }
        });
    }

    private void callJavaScript(final String fn, final String data) {
        final String safe = (data == null || data.equals("null")) ? "null" : data;
        final String js = "if(window." + fn + "){window." + fn + "(" + safe + ");}";
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try { webView.evaluateJavascript(js, null); } catch (Throwable e) { Log.e(TAG, "callJavaScript", e); }
            }
        });
    }

    /** آزادسازی منابع (مرحلهٔ پنجم مستندات) */
    public void onDestroy() {
        try { if (mHelper != null) mHelper.dispose(); } catch (Throwable e) { Log.w(TAG, "dispose", e); }
        mHelper = null;
        isSetup = false;
        setupInProgress = false;
        knownPurchases.clear();
    }
}
