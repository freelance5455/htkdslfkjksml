package app.tradyar;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * ============================================================
 * CallbackManager — مدیریت متمرکز callbackهای async
 * ============================================================
 * پیاده‌سازی کامل با ConcurrentHashMap + ScheduledExecutorService
 * برای timeout خودکار و thread-safety.
 * ============================================================
 */
public class CallbackManager {
    private static CallbackManager instance;
    private final ConcurrentHashMap<String, CallbackEntry> callbacks = new ConcurrentHashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private static final long DEFAULT_TIMEOUT_MS = 60000;

    private CallbackManager() {}

    public static synchronized CallbackManager getInstance() {
        if (instance == null) {
            instance = new CallbackManager();
        }
        return instance;
    }

    public String register(Callback cb) {
        return register(cb, DEFAULT_TIMEOUT_MS);
    }

    public String register(Callback cb, long timeoutMs) {
        if (cb == null) throw new IllegalArgumentException("callback cannot be null");
        final String id = java.util.UUID.randomUUID().toString();
        callbacks.put(id, new CallbackEntry(cb, System.currentTimeMillis()));
        scheduler.schedule(() -> {
            CallbackEntry entry = callbacks.remove(id);
            if (entry != null) {
                try {
                    entry.cb.onTimeout();
                } catch (Throwable t) {
                    android.util.Log.w("CallbackManager", "onTimeout threw", t);
                }
            }
        }, timeoutMs, TimeUnit.MILLISECONDS);
        return id;
    }

    public boolean resolve(String id, Object result) {
        if (id == null) return false;
        CallbackEntry entry = callbacks.remove(id);
        if (entry == null) return false;
        try {
            entry.cb.onSuccess(result);
        } catch (Throwable t) {
            android.util.Log.w("CallbackManager", "onSuccess threw", t);
        }
        return true;
    }

    public boolean cancel(String id) {
        if (id == null) return false;
        return callbacks.remove(id) != null;
    }

    public int activeCount() {
        return callbacks.size();
    }

    public void shutdown() {
        scheduler.shutdownNow();
        callbacks.clear();
    }

    public interface Callback {
        void onSuccess(Object result);
        void onTimeout();
    }

    private static class CallbackEntry {
        final Callback cb;
        final long createdAt;
        CallbackEntry(Callback cb, long t) {
            this.cb = cb;
            this.createdAt = t;
        }
    }
}
