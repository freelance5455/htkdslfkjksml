package app.tradyar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;

/**
 * ============================================================
 * MainActivity - اکتیویتی اصلی با WebView
 * ============================================================
 * اصلاحات امنیتی اعمال‌شده:
 * 1. WebView.setWebContentsDebuggingEnabled فقط در BuildConfig.DEBUG فعال است
 * 2. MIXED_CONTENT_NEVER_ALLOW به‌جای ALWAYS_ALLOW
 * 3. shouldOverrideUrlLoading از نوع WebResourceRequest (API 24+)
 * 4. URLهای خارجی در مرورگر خارجی باز می‌شوند
 * 5. Hardware acceleration صراحتاً فعال شده
 * ============================================================
 */

public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";

    private WebView webView;
    private MyketBridge myketBridge;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        // Hardware acceleration
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        // SECURITY: Mixed content must NEVER be allowed in release
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // SECURITY: WebView debugging only in debug builds
        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return false;
                String url = uri.toString();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);

                // myket:// scheme — load in WebView
                if ("myket".equals(scheme)) {
                    view.loadUrl(url);
                    return true;
                }
                // http/https — open in external browser to prevent phishing inside WebView
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    openExternal(url);
                    return true;
                }
                return false;
            }

            // Deprecated fallback for older API
            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                if (url.startsWith("myket://")) {
                    view.loadUrl(url);
                    return true;
                }
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    openExternal(url);
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Page loaded: " + url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        request.grant(request.getResources());
                    }
                });
            }
        });

        // MyketBridge — JavaScript interface
        myketBridge = new MyketBridge(this, webView);
        webView.addJavascriptInterface(myketBridge, "MyketBridge");

        // Load HTML from assets
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void openExternal(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Log.w(TAG, "Could not open external URL: " + url, e);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (myketBridge != null) {
            myketBridge.handleActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            CallbackManager.getInstance().shutdown();
        } catch (Throwable t) {
            Log.w(TAG, "CallbackManager shutdown failed", t);
        }
        if (myketBridge != null) {
            myketBridge.onDestroy();
        }
        if (webView != null) {
            webView.destroy();
        }
    }
}
