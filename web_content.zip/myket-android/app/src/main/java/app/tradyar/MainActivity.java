package app.tradyar;

import android.annotation.SuppressLint;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * ============================================================
 * MainActivity - اکتیویتی اصلی با WebView
 * ============================================================
 * اصلاحات امنیتی اعمال‌شده:
 * 1. WebView.setWebContentsDebuggingEnabled فقط در BuildConfig.DEBUG فعال است
 * 2. MIXED_CONTENT_NEVER_ALLOW به‌جای ALWAYS_ALLOW
 * 3. shouldOverrideUrlLoading از نوع WebResourceRequest (API 24+)
 * 4. URLهای خارجی در مرورگر خارجی باز می‌شوند
 * 5. Hardware acceleration صراحتاً فعال شده
 * ============================================================
 */

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private WebView webView;
    private MyketBridge myketBridge;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        // اندروید ۱۵ (targetSdk 35) به‌صورت پیش‌فرض لبه‌به‌لبه است؛ بدون این، بالای صفحه زیر نوار وضعیت و پایین زیر نوار ناوبری
        // و کیبورد روی فرم‌ها می‌افتد. فاصله‌ها را خودمان از Insets می‌دهیم.
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#11392A"));
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets b = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        // Hardware acceleration
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        // صفحهٔ برنامه با file:// بالا می‌آید (Origin=null)؛ بدون این‌ها درخواست به سرور/صرافی‌ها (CORS) رد می‌شود
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        // سرعت: بدون سوسو سفید، رندر از پیش، و بدون بزرگ‌نمایی فونت سیستم
        webView.setBackgroundColor(Color.parseColor("#11392A"));
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= 23) settings.setOffscreenPreRaster(true);
        // SECURITY: Mixed content must NEVER be allowed in release
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // SECURITY: WebView debugging only in debug builds
        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return false;
                return handleUrl(uri.toString(), request.isForMainFrame());
            }

            // Deprecated fallback for older API
            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                return handleUrl(url, true);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Page loaded: " + url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) { fileCallback.onReceiveValue(null); }
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                WebView tmp = new WebView(MainActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                        if (r.getUrl() != null) openExternal(r.getUrl().toString());
                        return true;
                    }
                    @Override
                    @SuppressWarnings("deprecation")
                    public boolean shouldOverrideUrlLoading(WebView v, String url) {
                        if (url != null) openExternal(url);
                        return true;
                    }
                });
                WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
                t.setWebView(tmp);
                resultMsg.sendToTarget();
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        request.grant(request.getResources());
                    }
                });
            }
        });

        // MyketBridge — JavaScript interface
        myketBridge = new MyketBridge(this, webView);
        webView.addJavascriptInterface(myketBridge, "MyketBridge");

        // Load HTML from assets
        webView.loadUrl(pageUrl());
    }

    /** صفحهٔ برنامه؛ اگر آدرس سرور/توکن در gradle.properties پر شده باشد، داخل HTML تزریق می‌شود. */
    private String pageUrl() {
        final String fallback = "file:///android_asset/index.html";
        try {
            String urls = BuildConfig.SERVER_URLS == null ? "" : BuildConfig.SERVER_URLS.trim();
            String token = BuildConfig.SERVER_TOKEN == null ? "" : BuildConfig.SERVER_TOKEN.trim();
            if (urls.isEmpty() && token.isEmpty()) return fallback;
            StringBuilder lit = new StringBuilder();
            for (String u : urls.split(",")) {
                u = u.trim();
                while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
                if (u.matches("https?://[A-Za-z0-9.:_/-]+")) {
                    if (lit.length() > 0) lit.append(',');
                    lit.append('\'').append(u).append('\'');
                }
            }
            String tokLit = token.matches("[A-Za-z0-9]{16,128}") ? "'" + token + "'" : null;
            InputStream in = getAssets().open("index.html");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            String html = new String(bo.toByteArray(), StandardCharsets.UTF_8);
            html = inject(html, "/*OWN_SERVERS_BEGIN*/", "/*OWN_SERVERS_END*/", lit.length() > 0 ? lit.toString() : null);
            html = inject(html, "/*OWN_TOKEN_BEGIN*/", "/*OWN_TOKEN_END*/", tokLit);
            File out = new File(getFilesDir(), "index.html");
            FileOutputStream fo = new FileOutputStream(out);
            fo.write(html.getBytes(StandardCharsets.UTF_8));
            fo.close();
            return "file://" + out.getAbsolutePath();
        } catch (Exception e) {
            Log.w(TAG, "server inject failed", e);
            return fallback;
        }
    }

    private static String inject(String html, String begin, String end, String literal) {
        if (literal == null) return html;
        int a = html.indexOf(begin), b = html.indexOf(end);
        if (a < 0 || b <= a) return html;
        return html.substring(0, a + begin.length()) + literal + html.substring(b);
    }

    private static final int REQ_FILE = 7311;
    private ValueCallback<Uri[]> fileCallback;

    /** true = ناوبری را خودمان گرفتیم (بیرون از برنامه باز شد). فقط صفحهٔ اصلی؛ iframe ها (مثل TradingView) دست نمی‌خورند. */
    private boolean handleUrl(String url, boolean mainFrame) {
        String low = url.toLowerCase(Locale.ROOT);
        if (low.startsWith("file:") || low.startsWith("about:") || low.startsWith("javascript:")
                || low.startsWith("data:") || low.startsWith("blob:")) return false;
        if (low.startsWith("http://") || low.startsWith("https://")) {
            if (!mainFrame) return false;
            openExternal(url);
            return true;
        }
        // myket:// tel: mailto: tg: intent: whatsapp: ... همه با برنامهٔ مربوطه باز شوند
        openExternal(url);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                Uri[] res = null;
                try { res = WebChromeClient.FileChooserParams.parseResult(resultCode, data); } catch (Exception ignored) { }
                fileCallback.onReceiveValue(res);
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void openExternal(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Log.w(TAG, "Could not open external URL: " + url, e);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // SDK مایکت 2.2 نتیجهٔ پرداخت را خودش (با اکتیویتی پروکسی) مدیریت می‌کند؛ onActivityResult لازم نیست.

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) { webView.onPause(); webView.pauseTimers(); }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) { webView.onResume(); webView.resumeTimers(); }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            CallbackManager.getInstance().shutdown();
        } catch (Throwable t) {
            Log.w(TAG, "CallbackManager shutdown failed", t);
        }
        if (myketBridge != null) {
            myketBridge.onDestroy();
        }
        if (webView != null) {
            webView.destroy();
        }
    }
}
