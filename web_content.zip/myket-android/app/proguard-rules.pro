# ProGuard Rules - ترید یار با SDK مایکت 2.2

# Myket Billing Client (طبق مستندات رسمی)
-keep class ir.myket.billingclient.** { *; }
-keep interface ir.myket.billingclient.** { *; }
-keep class com.android.vending.billing.** { *; }
-keepclassmembers class ir.myket.billingclient.util.** {
    public <fields>;
    public <methods>;
}
-dontwarn ir.myket.**

# JavaScript Bridge
-keepclassmembers class app.tradyar.** {
    @android.webkit.JavascriptInterface <methods>;
}

# WebView
-keepclassmembers class * extends android.webkit.WebViewClient {
    public void *(android.webkit.WebView, java.lang.String, android.graphics.Bitmap);
    public boolean *(android.webkit.WebView, java.lang.String);
}
