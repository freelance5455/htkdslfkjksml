package com.privacydisplay

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("privacy_display", Context.MODE_PRIVATE)

    /** Escurecimento em %, de 10 a 90. */
    var intensity: Int
        get() = sp.getInt("intensity", 60)
        set(v) = sp.edit().putInt("intensity", v).apply()

    var focusMode: Boolean
        get() = sp.getBoolean("focus", false)
        set(v) = sp.edit().putBoolean("focus", v).apply()

    /** Centro da faixa nítida em % da altura, de 20 a 80. */
    var bandCenter: Int
        get() = sp.getInt("band_center", 50)
        set(v) = sp.edit().putInt("band_center", v).apply()

    /** Altura da faixa nítida em % da tela, de 10 a 50. */
    var bandSize: Int
        get() = sp.getInt("band_size", 25)
        set(v) = sp.edit().putInt("band_size", v).apply()
}
