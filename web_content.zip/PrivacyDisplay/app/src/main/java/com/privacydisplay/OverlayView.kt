package com.privacydisplay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.view.View

/** Camada escura sobre a tela. No modo foco, abre uma faixa transparente. */
class OverlayView(context: Context) : View(context) {

    var dim = 0.6f
    var focus = false
    var center = 0.5f
    var size = 0.25f

    private val clearPaint = Paint().apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        val layer = canvas.saveLayer(null, null)
        canvas.drawColor(Color.argb((dim * 255).toInt(), 0, 0, 0))
        if (focus) {
            val h = height * size
            val top = height * center - h / 2f
            canvas.drawRect(0f, top, width.toFloat(), top + h, clearPaint)
        }
        canvas.restoreToCount(layer)
    }
}
