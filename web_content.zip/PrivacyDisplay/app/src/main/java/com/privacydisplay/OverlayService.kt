package com.privacydisplay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.service.quicksettings.TileService
import android.view.WindowManager

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "com.privacydisplay.START"
        const val ACTION_STOP = "com.privacydisplay.STOP"
        const val ACTION_UPDATE = "com.privacydisplay.UPDATE"
        private const val CHANNEL_ID = "privacy_display"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false
    }

    private var view: OverlayView? = null
    private lateinit var wm: WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> {
                if (view == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                applyPrefs()
            }
            else -> {
                startInForeground()
                showOverlay()
                applyPrefs()
            }
        }
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Filtro de privacidade", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_shield)
            .setContentTitle("Privacy Display ativo")
            .setContentText("Toque para ajustar o filtro")
            .setContentIntent(openIntent)
            .addAction(Notification.Action.Builder(null, "Desligar", stopIntent).build())
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun showOverlay() {
        if (view != null) return
        val v = OverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, params)
        view = v
        running = true
        refreshTile()
    }

    private fun applyPrefs() {
        val p = Prefs(this)
        view?.apply {
            dim = p.intensity / 100f
            focus = p.focusMode
            center = p.bandCenter / 100f
            size = p.bandSize / 100f
            invalidate()
        }
    }

    private fun refreshTile() {
        TileService.requestListeningState(this, ComponentName(this, PrivacyTileService::class.java))
    }

    override fun onDestroy() {
        running = false
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        refreshTile()
        super.onDestroy()
    }
}
