package com.privacydisplay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

private val C_BG = 0xFF0E1217.toInt()
private val C_CARD = 0xFF171D25.toInt()
private val C_STROKE = 0xFF232B36.toInt()
private val C_TRACK = 0xFF2A333F.toInt()
private val C_TEXT = 0xFFF2F5F8.toInt()
private val C_MUTED = 0xFF8B97A6.toInt()
private val C_ACCENT = 0xFF4C8DFF.toInt()
private val C_ACTIVE = 0xFF34D399.toInt()
private val C_ACTIVE_BG = 0xFF123B2D.toInt()

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var hero: FrameLayout
    private lateinit var heroIcon: ImageView
    private lateinit var statusTitle: TextView
    private lateinit var statusSub: TextView
    private lateinit var preview: PreviewView
    private val focusControls = mutableListOf<View>()
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, top: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    private fun roundBg(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun text(s: String, size: Float, color: Int, medium: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (medium) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = roundBg(C_CARD, 20, C_STROKE)
        setPadding(dp(18), dp(18), dp(18), dp(18))
        layoutParams = lp(top = 12)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        header.addView(
            ImageView(this).apply { setImageResource(R.drawable.logo) },
            LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(14) }
        )
        val headerTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        headerTexts.addView(text("Privacy Display", 24f, C_TEXT, true))
        headerTexts.addView(text("Proteção contra olhares curiosos", 14f, C_MUTED))
        header.addView(headerTexts)
        root.addView(header)

        // Cartão principal: botão de escudo
        val heroCard = card().apply { gravity = Gravity.CENTER_HORIZONTAL }
        hero = FrameLayout(this).apply {
            isClickable = true
            setOnClickListener { toggle(!OverlayService.running) }
        }
        heroIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_shield)
            layoutParams = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER)
        }
        hero.addView(heroIcon)
        heroCard.addView(hero, LinearLayout.LayoutParams(dp(104), dp(104)))
        statusTitle = text("", 20f, C_TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }
        statusSub = text("", 13f, C_MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        }
        heroCard.addView(statusTitle, lp())
        heroCard.addView(statusSub, lp())
        root.addView(heroCard)

        // Pré-visualização
        val previewCard = card()
        previewCard.addView(text("Pré-visualização", 13f, C_MUTED, true))
        preview = PreviewView(this)
        previewCard.addView(preview, lp(h = dp(170), top = 12))
        root.addView(previewCard)

        // Ajustes
        val adjustCard = card()
        adjustCard.addView(text("Escurecimento", 16f, C_TEXT, true))
        adjustCard.addView(
            slider("Intensidade", 10, 90, prefs.intensity, "%") { prefs.intensity = it },
            lp(top = 8)
        )
        root.addView(adjustCard)

        // Modo foco
        val focusCard = card()
        val focusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val focusTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        focusTexts.addView(text("Modo foco", 16f, C_TEXT, true))
        focusTexts.addView(text("Só uma faixa da tela fica nítida", 13f, C_MUTED))
        focusRow.addView(focusTexts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val focusSwitch = Switch(this).apply {
            thumbTintList = ColorStateList(states, intArrayOf(0xFFFFFFFF.toInt(), C_MUTED))
            trackTintList = ColorStateList(states, intArrayOf(C_ACCENT, C_TRACK))
            isChecked = prefs.focusMode
            setOnCheckedChangeListener { _, on ->
                prefs.focusMode = on
                setFocusEnabled(on)
                updatePreview()
                sendUpdate()
            }
        }
        focusRow.addView(focusSwitch)
        focusCard.addView(focusRow)

        val posSlider = slider("Posição da faixa", 20, 80, prefs.bandCenter, "%") { prefs.bandCenter = it }
        val sizeSlider = slider("Altura da faixa", 10, 50, prefs.bandSize, "%") { prefs.bandSize = it }
        focusControls.add(posSlider)
        focusControls.add(sizeSlider)
        focusCard.addView(posSlider, lp(top = 16))
        focusCard.addView(sizeSlider, lp(top = 8))
        root.addView(focusCard)

        root.addView(
            text("Dica: adicione o tile Privacy Display nas Configurações Rápidas para ligar com um toque.", 12f, C_MUTED)
                .apply { gravity = Gravity.CENTER },
            lp(top = 20)
        )

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(C_BG)
            addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })

        setFocusEnabled(prefs.focusMode)
        updatePreview()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun slider(
        title: String, min: Int, max: Int, value: Int, unit: String, onChange: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val valueText = text("$value$unit", 14f, C_ACCENT, true)
        row.addView(text(title, 14f, C_MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(valueText)
        box.addView(row)

        val bar = SeekBar(this).apply {
            this.max = max - min
            progress = value - min
            progressTintList = ColorStateList.valueOf(C_ACCENT)
            thumbTintList = ColorStateList.valueOf(C_ACCENT)
            progressBackgroundTintList = ColorStateList.valueOf(C_TRACK)
            setPadding(dp(4), dp(10), dp(4), dp(10))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    valueText.text = "$v$unit"
                    if (fromUser) {
                        onChange(v)
                        updatePreview()
                        sendUpdate()
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        box.addView(bar, lp())
        return box
    }

    private fun setFocusEnabled(on: Boolean) {
        focusControls.forEach {
            it.alpha = if (on) 1f else 0.4f
            (it as ViewGroup).getChildAt(1).isEnabled = on
        }
    }

    private fun updatePreview() {
        preview.dim = prefs.intensity / 100f
        preview.focus = prefs.focusMode
        preview.center = prefs.bandCenter / 100f
        preview.size = prefs.bandSize / 100f
        preview.invalidate()
    }

    private fun refresh() {
        val on = OverlayService.running
        hero.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) C_ACTIVE_BG else C_BG)
            setStroke(dp(3), if (on) C_ACTIVE else C_TRACK)
        }
        heroIcon.setColorFilter(if (on) C_ACTIVE else C_MUTED)
        statusTitle.text = if (on) "Proteção ativa" else "Proteção desligada"
        statusSub.text = if (on) "Toque no escudo para desligar" else "Toque no escudo para ligar"
    }

    private fun toggle(on: Boolean) {
        if (!on) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            handler.postDelayed({ refresh() }, 300)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(
            Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
        )
        handler.postDelayed({ refresh() }, 400)
    }

    private fun sendUpdate() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_UPDATE))
        }
    }
}
