package com.privacydisplay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.view.View

/** Miniatura de uma tela com texto, mostrando o efeito do filtro em tempo real. */
class PreviewView(context: Context) : View(context) {

    var dim = 0.6f
    var focus = false
    var center = 0.5f
    var size = 0.25f

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2B3440.toInt() }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFC5CEDA.toInt() }
    private val clearPaint = Paint().apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }
    private val clip = Path()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val radius = resources.displayMetrics.density * 14f

        clip.reset()
        clip.addRoundRect(0f, 0f, w, h, radius, radius, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)

        canvas.drawRect(0f, 0f, w, h, bgPaint)

        val pad = w * 0.08f
        val lineH = h * 0.055f
        var y = h * 0.10f
        for (i in 0 until 8) {
            val lineW = if (i % 3 == 2) w * 0.5f else w * 0.84f
            canvas.drawRoundRect(pad, y, pad + lineW, y + lineH, lineH / 2, lineH / 2, linePaint)
            y += lineH * 2.1f
        }

        val layer = canvas.saveLayer(0f, 0f, w, h, null)
        canvas.drawColor(Color.argb((dim * 255).toInt(), 0, 0, 0))
        if (focus) {
            val band = h * size
            val top = h * center - band / 2f
            canvas.drawRect(0f, top, w, top + band, clearPaint)
        }
        canvas.restoreToCount(layer)
        canvas.restore()
    }
}
