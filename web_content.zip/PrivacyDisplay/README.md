# Privacy Display (v0.3)

Filtro de tela anti-espiões para Android.

## Como rodar
1. Abra a pasta no Android Studio (Koala ou mais novo) e deixe o Gradle sincronizar.
2. Rode no celular. Na primeira vez, o app pede a permissão "Exibir sobre outros apps".
3. Adicione o tile "Privacy Display" nas Configurações Rápidas.

## Estrutura
- MainActivity: tema escuro com cartões, botão de escudo, pré-visualização ao vivo e ajustes.
- PreviewView: miniatura que mostra o efeito do filtro em tempo real.
- OverlayView / OverlayService: camada escura e serviço em primeiro plano.
- PrivacyTileService: tile de ligar/desligar.

## Ícone
O ícone oficial fica em app/src/main/res (mipmap-*, drawable-nodpi/ic_launcher_foreground.png e logo.png). A versão de 512 px para a loja vai separada em privacy-display-icon-512.png.

## Gerar o APK sem Android Studio
1. Crie um repositório no GitHub e envie o conteúdo desta pasta (a raiz deve ter settings.gradle.kts e a pasta .github).
2. Abra a aba Actions, rode "Build APK" (ou faça um push).
3. Ao terminar, baixe o artefato PrivacyDisplay-apk, extraia e instale o app-debug.apk.

## Gerar o APK no Android Studio
Build > Build Bundle(s) / APK(s) > Build APK(s). O arquivo fica em app/build/outputs/apk/debug/app-debug.apk.
