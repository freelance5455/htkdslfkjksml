import React, { useEffect, useState } from "react";
import { SafeAreaView, View, Text, TextInput, Button, StyleSheet, Alert, ActivityIndicator } from "react-native";
import { onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "firebase/auth";
import { addDoc, collection, doc, getDocs, query, serverTimestamp, updateDoc, where } from "firebase/firestore";
import { auth, db } from "./src/firebase";
import { beginLocationSharing, endLocationSharing } from "./src/locationTask";

export default function App() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [registration, setRegistration] = useState("");
  const [vehicle, setVehicle] = useState(null);
  const [busy, setBusy] = useState(false);
  const [sharing, setSharing] = useState(false);

  useEffect(() => onAuthStateChanged(auth, async (u) => {
    setUser(u);
    if (u) await loadVehicle(u.uid);
    else setVehicle(null);
  }), []);

  async function loadVehicle(uid) {
    const q = query(collection(db, "vehicles"), where("ownerUid", "==", uid));
    const snap = await getDocs(q);
    setVehicle(snap.empty ? null : { id: snap.docs[0].id, ...snap.docs[0].data() });
  }

  async function authenticate(create) {
    setBusy(true);
    try {
      if (create) await createUserWithEmailAndPassword(auth, email.trim(), password);
      else await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (e) { Alert.alert("Account error", e.message); }
    finally { setBusy(false); }
  }

  async function registerVehicle() {
    const plate = registration.trim().toUpperCase().replace(/\s+/g, " ");
    if (plate.length < 4) return Alert.alert("Check registration", "Enter a valid vehicle registration number.");
    setBusy(true);
    try {
      const ref = await addDoc(collection(db, "vehicles"), {
        ownerUid: user.uid, registrationNumber: plate,
        createdAt: serverTimestamp(), sharing: false
      });
      setVehicle({ id: ref.id, registrationNumber: plate, sharing: false });
    } catch (e) { Alert.alert("Registration failed", e.message); }
    finally { setBusy(false); }
  }

  async function start() {
    setBusy(true);
    try {
      await beginLocationSharing(vehicle.id);
      await updateDoc(doc(db, "vehicles", vehicle.id), { sharing: true });
      setSharing(true);
      Alert.alert("Location sharing started", "Your location is now being shared with your authorized dashboard. Use Stop sharing whenever you want.");
    } catch (e) { Alert.alert("Could not start tracking", e.message); }
    finally { setBusy(false); }
  }

  async function stop() {
    setBusy(true);
    try {
      await endLocationSharing();
      await updateDoc(doc(db, "vehicles", vehicle.id), { sharing: false });
      setSharing(false);
    } catch (e) { Alert.alert("Could not stop", e.message); }
    finally { setBusy(false); }
  }

  if (!user) return (
    <SafeAreaView style={s.page}>
      <Text style={s.title}>TrackMyVehicle</Text>
      <Text style={s.sub}>Driver sign in / create account</Text>
      <TextInput style={s.input} placeholder="Email address" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail}/>
      <TextInput style={s.input} placeholder="Password (6+ characters)" secureTextEntry value={password} onChangeText={setPassword}/>
      {busy ? <ActivityIndicator/> : <>
        <Button title="Create account" onPress={() => authenticate(true)}/>
        <View style={{height:12}}/>
        <Button title="Sign in" onPress={() => authenticate(false)}/>
      </>}
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={s.page}>
      <Text style={s.title}>TrackMyVehicle</Text>
      <Text style={s.sub}>Signed in as {user.email}</Text>
      {!vehicle ? <>
        <Text style={s.heading}>Register your vehicle</Text>
        <TextInput style={s.input} placeholder="Example: TS 08 AB 1234" autoCapitalize="characters" value={registration} onChangeText={setRegistration}/>
        <Button title="Register vehicle" onPress={registerVehicle} disabled={busy}/>
      </> : <>
        <Text style={s.heading}>Your vehicle</Text>
        <Text style={s.plate}>{vehicle.registrationNumber}</Text>
        <Text style={s.note}>Location sharing is controlled by you. Only your authorized signed-in dashboard can read this vehicle's location.</Text>
        {busy ? <ActivityIndicator/> : sharing
          ? <Button title="Stop sharing location" color="#b91c1c" onPress={stop}/>
          : <Button title="Start sharing location" onPress={start}/>}
      </>}
      <View style={{height:24}}/>
      <Button title="Sign out" color="#555" onPress={async () => { if (sharing) await stop(); await signOut(auth); }}/>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  page:{flex:1,backgroundColor:"#f8fafc",padding:24,justifyContent:"center"},
  title:{fontSize:30,fontWeight:"800",color:"#0f172a",marginBottom:8},
  sub:{fontSize:14,color:"#64748b",marginBottom:28},
  heading:{fontSize:20,fontWeight:"700",marginBottom:14,color:"#0f172a"},
  input:{backgroundColor:"#fff",borderWidth:1,borderColor:"#cbd5e1",borderRadius:10,padding:14,marginBottom:14,fontSize:16},
  plate:{fontSize:25,fontWeight:"800",letterSpacing:1,marginBottom:14,color:"#1d4ed8"},
  note:{color:"#475569",lineHeight:21,marginBottom:20}
});
