import * as TaskManager from "expo-task-manager";
import * as Location from "expo-location";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "./firebase";

export const LOCATION_TASK = "TRACKMYVEHICLE_BACKGROUND_LOCATION";

TaskManager.defineTask(LOCATION_TASK, async ({ data, error }) => {
  if (error || !data?.locations?.length) return;
  const user = auth.currentUser;
  const vehicleId = await AsyncStorage.getItem("trackingVehicleId");
  if (!user || !vehicleId) return;

  const loc = data.locations[data.locations.length - 1];
  const latitude = loc.coords.latitude;
  const longitude = loc.coords.longitude;
  const speedMps = loc.coords.speed;
  const speedKmph = speedMps == null || speedMps < 0
    ? null : Math.round(speedMps * 3.6);

  await setDoc(doc(db, "vehicles", vehicleId, "latest", "current"), {
    latitude,
    longitude,
    speedKmph,
    accuracy: loc.coords.accuracy ?? null,
    updatedAt: serverTimestamp(),
    driverUid: user.uid
  }, { merge: true });
});

export async function beginLocationSharing(vehicleId) {
  const foreground = await Location.requestForegroundPermissionsAsync();
  if (foreground.status !== "granted") {
    throw new Error("Location permission was not granted.");
  }

  const background = await Location.requestBackgroundPermissionsAsync();
  if (background.status !== "granted") {
    throw new Error("Background permission was not granted. You can still test while the app is open; enable background access in Android Settings to track with the app in the background.");
  }

  await AsyncStorage.setItem("trackingVehicleId", vehicleId);

  const alreadyStarted = await Location.hasStartedLocationUpdatesAsync(LOCATION_TASK);
  if (!alreadyStarted) {
    await Location.startLocationUpdatesAsync(LOCATION_TASK, {
      accuracy: Location.Accuracy.Balanced,
      timeInterval: 5000,
      distanceInterval: 10,
      pausesUpdatesAutomatically: false,
      foregroundService: {
        notificationTitle: "TrackMyVehicle is sharing location",
        notificationBody: "Your vehicle location is being shared with your authorized dashboard.",
        notificationColor: "#2563eb"
      }
    });
  }
}

export async function endLocationSharing() {
  const started = await Location.hasStartedLocationUpdatesAsync(LOCATION_TASK);
  if (started) await Location.stopLocationUpdatesAsync(LOCATION_TASK);
  await AsyncStorage.removeItem("trackingVehicleId");
}
