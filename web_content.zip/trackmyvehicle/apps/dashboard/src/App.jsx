import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import { onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "firebase/auth";
import { collection, onSnapshot, doc, query, where } from "firebase/firestore";
import { auth, db } from "./firebase";

// Fix Leaflet's default marker assets when bundled by Vite.
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png"
});

function Recenter({ position }) {
  const map = useMap();
  useEffect(() => { if (position) map.setView(position, 15); }, [position, map]);
  return null;
}

export default function App() {
  const [user,setUser] = useState(null);
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [vehicles,setVehicles] = useState([]);
  const [selected,setSelected] = useState(null);
  const [error,setError] = useState("");

  useEffect(() => onAuthStateChanged(auth, setUser), []);
  useEffect(() => {
    if (!user) { setVehicles([]); return; }
    return onSnapshot(collection(db,"vehicles"), snapshot => {
      const owned = snapshot.docs
        .filter(d => d.data().ownerUid === user.uid)
        .map(d => ({id:d.id,...d.data()}));
      setVehicles(owned);
      setSelected(current => current && owned.some(v => v.id === current) ? current : owned[0]?.id ?? null);
    }, e => setError(e.message));
  }, [user]);

  async function login(create) {
    setError("");
    try {
      if(create) await createUserWithEmailAndPassword(auth,email.trim(),password);
      else await signInWithEmailAndPassword(auth,email.trim(),password);
    } catch(e) { setError(e.message); }
  }

  if (!user) return <main className="login">
    <section className="login-card">
      <div className="logo">TMV</div>
      <h1>TrackMyVehicle</h1><p>Sign in to view vehicles you are authorized to track.</p>
      <input placeholder="Email address" value={email} onChange={e=>setEmail(e.target.value)}/>
      <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)}/>
      <button onClick={()=>login(false)}>Sign in</button>
      <button className="secondary" onClick={()=>login(true)}>Create account</button>
      {error && <p className="error">{error}</p>}
      <small>Create the account in the driver app first, or use the same Firebase account.</small>
    </section>
  </main>;

  const active = vehicles.find(v=>v.id===selected);
  return <div className="app">
    <header><div><strong>TrackMyVehicle</strong><span>Vehicle tracking dashboard</span></div><button className="secondary signout" onClick={()=>signOut(auth)}>Sign out</button></header>
    <div className="layout">
      <aside>
        <h2>Your vehicles</h2>
        {vehicles.length===0 && <p className="muted">No vehicles registered to this account yet. Register one in the Android app.</p>}
        {vehicles.map(v=><button key={v.id} className={"vehicle "+(selected===v.id?"chosen":"")} onClick={()=>setSelected(v.id)}>
          <b>{v.registrationNumber}</b><span>{v.sharing?"Sharing enabled":"Not sharing"}</span>
        </button>)}
        {active && <div className="details">
          <h3>{active.registrationNumber}</h3>
          <LocationDetails vehicle={active}/>
        </div>}
      </aside>
      <section className="map-area">
        {active ? <VehicleMap vehicle={active}/> : <div className="empty">Register a vehicle in the Android driver app to see it here.</div>}
      </section>
    </div>
  </div>;
}

function LocationDetails({vehicle}) {
  const [location,setLocation] = useState(null);
  useEffect(()=>onSnapshot(doc(db,"vehicles",vehicle.id,"latest","current"), snap=>setLocation(snap.exists()?snap.data():null)),[vehicle.id]);
  if(!location) return <p className="muted">Waiting for the driver's first GPS update…</p>;
  const updated = location.updatedAt?.toDate?.();
  return <div className="stats">
    <div><span>Speed</span><b>{location.speedKmph == null ? "Unavailable" : `${location.speedKmph} km/h`}</b></div>
    <div><span>Latitude</span><b>{location.latitude.toFixed(5)}</b></div>
    <div><span>Longitude</span><b>{location.longitude.toFixed(5)}</b></div>
    <div><span>GPS accuracy</span><b>{location.accuracy == null ? "—" : `${Math.round(location.accuracy)} m`}</b></div>
    <div><span>Last update</span><b>{updated ? updated.toLocaleString() : "Just received"}</b></div>
  </div>;
}

function VehicleMap({vehicle}) {
  const [location,setLocation] = useState(null);
  useEffect(()=>onSnapshot(doc(db,"vehicles",vehicle.id,"latest","current"),snap=>setLocation(snap.exists()?snap.data():null)),[vehicle.id]);
  const position = location ? [location.latitude,location.longitude] : [17.3850,78.4867];
  return <MapContainer center={position} zoom={location?15:11} scrollWheelZoom className="map">
    <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>
    {location && <><Marker position={position}><Popup>{vehicle.registrationNumber}<br/>{location.speedKmph ?? "—"} km/h</Popup></Marker><Recenter position={position}/></>}
  </MapContainer>;
}
