# TrackMyVehicle — GPS tracking MVP

A consent-based vehicle tracking starter with:
- Android driver app (Expo / React Native)
- Web dashboard (React / Vite)
- Firebase Authentication + Firestore
- Android background location updates
- OpenStreetMap map (Leaflet)

A number plate is only the vehicle's identifier. Location comes from the driver's phone after they sign in and explicitly start sharing.

## 1. Firebase setup
1. Create a Firebase project at https://console.firebase.google.com/
2. Register a **Web app** in Firebase project settings.
3. Enable **Authentication → Email/Password**.
4. Create a **Cloud Firestore** database.
5. Copy the Firebase web config into:
   - `apps/driver/src/firebaseConfig.js`
   - `apps/dashboard/src/firebaseConfig.js`
6. Publish `firestore.rules` from the Firebase console (Firestore → Rules).

For a class/demo project, use test accounts you control. Never publish your Firebase config together with service-account credentials. Firebase web config is not a password; Firestore rules are what protect the data.

## 2. Run the website
```bash
cd apps/dashboard
npm install
npm run dev
```
Open the local URL printed by Vite. Sign in using an account created in the Android app (or create the same account using Firebase Authentication).

## 3. Run the Android app
Install Node.js and Android Studio on a computer first. Then:
```bash
cd apps/driver
npm install
npx expo install expo-location expo-task-manager @react-native-async-storage/async-storage
npx expo install
npx expo run:android
```
Use a physical Android phone with GPS enabled for realistic testing. Background location requires a development/native build; Expo Go is not sufficient for all background-location behavior.

## 4. Test
1. Open the Android app and create an account.
2. Enter a vehicle registration number and tap **Register vehicle**.
3. Tap **Start sharing location** and grant the requested location permissions.
4. Open the website and sign in with the same account.
5. The registered vehicle should appear on the map after the first GPS update.
6. Tap **Stop sharing** in the Android app to end tracking.

## Important Android notes
- Android may pause or limit background work due to battery optimization, device settings, or manufacturer restrictions.
- The driver must grant location permission and keep location services enabled.
- This starter requests foreground and background permission where supported. The operating system may require the user to grant background access separately in Settings.
- Do not use this to track anyone without their informed permission. Provide a clear notice, visible sharing status, and an easy stop control.
- This MVP does not provide guaranteed continuous tracking, emergency dispatch, or theft recovery.

## Data model
`vehicles/{vehicleId}`:
- `ownerUid`, `registrationNumber`, `createdAt`, `sharing`

`vehicles/{vehicleId}/latest/current`:
- `latitude`, `longitude`, `speedKmph`, `accuracy`, `updatedAt`, `driverUid`

## Limitations / next steps
This starter shows the latest location only. For production, add verified driver-to-vehicle assignments, role-based access, trip history, data retention controls, abuse reporting, app signing, privacy policy, and monitoring. Never expose tracking data publicly.
