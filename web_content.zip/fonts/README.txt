Coloque aqui os ficheiros de fonte (opcional): arial.ttf, calibri.ttf, cour.ttf, gara.ttf, georgia.ttf, times.ttf, trebuc.ttf
Assinatura (separador "Escrever"): frscript.ttf (French Script MT) e kunstler.ttf (Kunstler Script).
O editor usa primeiro a fonte instalada no dispositivo e só carrega estes ficheiros se ela não existir.
Atenção: estas fontes são da Microsoft; use-as só localmente. Para publicar na web, use alternativas livres (Carlito, Liberation, EB Garamond...).
No Windows, os ficheiros estão em C:\Windows\Fonts (FRSCRIPT.TTF e KUNSTLER.TTF); copie-os para esta pasta, em minúsculas.
