Urdu font (Jameel Noori Nastaleeq)
1) Put the font file here and name it exactly:  JameelNooriNastaleeq.ttf
2) Zip again / rebuild your APK.
Without this file the app uses a device-installed Jameel Noori or Noto Nastaliq Urdu if available.

اردو فونٹ: جمیل نوری نستعلیق کی فائل یہاں رکھیں اور اس کا نام بالکل یہی رکھیں:
JameelNooriNastaleeq.ttf
