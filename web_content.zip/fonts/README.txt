System fonts only (Roboto/Noto on Android). No web fonts are used, so nothing needs to load from the internet.
