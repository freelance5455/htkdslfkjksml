ORBIT — SELF-HOSTED FONTS
==========================

Why this folder is empty right now
-----------------------------------
I removed the Google Fonts <link> from index.html so the app never makes a
network call for fonts — that's the offline/Iran-access fix you asked for.
The CSS in index.html already points at local files in this folder
(fonts/fredoka-600.woff2, etc). Until those actual files are added, the
browser just falls back to a close system font automatically — nothing
breaks, it just won't be pixel-identical to the original Google Fonts look.

I could not download the real font files myself: doing that needs an open
network connection to fonts.gstatic.com, and this build environment has no
internet access. So this last step needs doing on a machine that does.

How to finish it (5 minutes)
-----------------------------
1. Go to https://gwfh.mranftl.com/fonts (Google Webfonts Helper — free,
   official-style mirror, gives you plain .woff2 files, no account needed).
2. For each font below, select it, tick ONLY the listed weights, choose
   "Modern Browsers" (woff2), download, and rename the files to EXACTLY
   the names listed (the CSS already expects these exact filenames):

   Fredoka        weights 500, 600, 700
     -> fredoka-500.woff2, fredoka-600.woff2, fredoka-700.woff2

   Nunito         weights 400, 600, 700, 800
     -> nunito-400.woff2, nunito-600.woff2, nunito-700.woff2, nunito-800.woff2

   Poppins        weights 500, 600, 700
     -> poppins-500.woff2, poppins-600.woff2, poppins-700.woff2

   Space Grotesk  weights 500, 600, 700
     -> space-grotesk-500.woff2, space-grotesk-600.woff2, space-grotesk-700.woff2

   Quicksand      weights 600, 700
     -> quicksand-600.woff2, quicksand-700.woff2

3. For Persian text (Fredoka/Nunito/etc. have NO Farsi letters at all —
   without this, Farsi text silently falls back to a plain system font):

   Vazirmatn      weights 500, 700
     -> vazirmatn-500.woff2, vazirmatn-700.woff2

   Vazirmatn is on Google Fonts too, or get it directly from
   https://github.com/rastikerdar/vazirmatn (OFL licensed, free to bundle).

4. Drop all 15 .woff2 files straight into this /fonts folder. Nothing else
   needs to change — index.html already references them by these names.
5. Rebuild/re-zip the APK. Once these files are present, the app looks
   identical to the original online version but loads with zero network
   requests, anywhere, including with no signal at all.
