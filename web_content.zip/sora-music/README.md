# SORA — Spotify Edition

Website musik Liquid Glass tanpa akun SORA. Pencarian membuka katalog Spotify; pengguna dapat menyimpan tautan Spotify ke library lokal, favorit, antrean, dan playlist.

## Menjalankan

Buka `index.html` untuk mencoba, atau unggah seluruh folder ini ke hosting HTTPS (misalnya GitHub Pages atau Netlify). PWA/service worker aktif pada HTTPS atau localhost.

## Integrasi Spotify

- Tempel tautan Spotify track, album, playlist, show, atau episode.
- Konten diputar melalui Spotify Embed resmi.
- Pengguna tidak perlu login ke SORA. Tanpa sesi Spotify, Spotify dapat membatasi pemutaran ke preview; pengalaman penuh bergantung pada sesi/akun dan kebijakan Spotify.
- Pemutar embed resmi mengendalikan audio di dalam iframe; tombol buka Spotify membuka konten di Spotify.
- Web Playback SDK untuk streaming penuh di dalam aplikasi memerlukan OAuth dan Spotify Premium, sehingga tidak diaktifkan dalam versi tanpa login ini.

## Data

Library, favorit, antrean, dan playlist disimpan di `localStorage` browser pada perangkat pengguna. Tidak ada backend atau akun SORA.
