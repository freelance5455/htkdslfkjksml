# SimCompanies SP Web
1. Otwórz index.html w przeglądarce.
2. Aby opublikować za darmo: utwórz repozytorium GitHub, wgraj index.html i włącz Settings -> Pages -> Deploy from branch.
3. Otrzymany adres URL wklej do kreatora website-to-APK.
