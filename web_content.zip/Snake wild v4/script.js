"use strict";

/* =========================================================
   SNAKE WILD V4
   100% HORS CONNEXION
   Compatible Acode / Android
   ========================================================= */


/* =========================================================
   CANVAS
   ========================================================= */

const canvas =
    document.getElementById("gameCanvas");

const ctx =
    canvas.getContext("2d");


/* =========================================================
   DIMENSIONS
   ========================================================= */

const SIZE = 600;

const GRID = 24;

const CELL = SIZE / GRID;


/* =========================================================
   DOM
   ========================================================= */

const homeScreen =
    document.getElementById("homeScreen");

const worldScreen =
    document.getElementById("worldScreen");

const missionsScreen =
    document.getElementById("missionsScreen");

const skinsScreen =
    document.getElementById("skinsScreen");

const gameScreen =
    document.getElementById("gameScreen");

const pauseScreen =
    document.getElementById("pauseScreen");

const gameOverScreen =
    document.getElementById("gameOverScreen");


const scoreElement =
    document.getElementById("score");

const highScoreElement =
    document.getElementById("highScore");

const gameLevelElement =
    document.getElementById("gameLevel");

const homeLevelElement =
    document.getElementById("homeLevel");

const homeXPElement =
    document.getElementById("homeXP");

const homeCoinsElement =
    document.getElementById("homeCoins");

const homeHighScoreElement =
    document.getElementById("homeHighScore");

const powerFill =
    document.getElementById("powerFill");

const powerText =
    document.getElementById("powerText");

const livesElement =
    document.getElementById("lives");

const coinsGameElement =
    document.getElementById("coinsGame");

const comboElement =
    document.getElementById("combo");

const worldNameElement =
    document.getElementById("worldName");

const worldIconElement =
    document.getElementById("worldIcon");

const worldDifficultyElement =
    document.getElementById(
        "worldDifficulty"
    );

const messageBox =
    document.getElementById("messageBox");


/* =========================================================
   MONDES
   ========================================================= */

const worlds = [

    {
        id: 0,
        name: "Prairie",
        icon: "🌿",
        difficulty: "Facile",
        unlock: 0,
        speed: 150,
        obstacles: 5,
        type: "rock"
    },

    {
        id: 1,
        name: "Désert",
        icon: "🏜️",
        difficulty: "Normal",
        unlock: 5,
        speed: 135,
        obstacles: 8,
        type: "wall"
    },

    {
        id: 2,
        name: "Forêt",
        icon: "🌲",
        difficulty: "Normal +",
        unlock: 10,
        speed: 120,
        obstacles: 11,
        type: "tree"
    },

    {
        id: 3,
        name: "Volcan",
        icon: "🌋",
        difficulty: "Difficile",
        unlock: 20,
        speed: 108,
        obstacles: 14,
        type: "lava"
    },

    {
        id: 4,
        name: "Glacier",
        icon: "🧊",
        difficulty: "Très difficile",
        unlock: 35,
        speed: 95,
        obstacles: 17,
        type: "ice"
    },

    {
        id: 5,
        name: "Espace",
        icon: "🌌",
        difficulty: "Extrême",
        unlock: 50,
        speed: 82,
        obstacles: 20,
        type: "asteroid"
    }

];


/* =========================================================
   SKINS
   ========================================================= */

const skins = [

    {
        id: "green",
        name: "Serpent sauvage",
        color: "#4fcf4b",
        dark: "#174d20",
        unlock: 0
    },

    {
        id: "blue",
        name: "Serpent marin",
        color: "#45bde8",
        dark: "#16476a",
        unlock: 10
    },

    {
        id: "red",
        name: "Serpent de feu",
        color: "#ef4d38",
        dark: "#641a18",
        unlock: 20
    },

    {
        id: "purple",
        name: "Serpent mystique",
        color: "#b46cff",
        dark: "#3d205f",
        unlock: 35
    },

    {
        id: "gold",
        name: "Serpent royal",
        color: "#ffd84a",
        dark: "#715515",
        unlock: 50
    }

];


/* =========================================================
   SAUVEGARDE
   ========================================================= */

const SAVE_KEY =
    "snakeWildV4Save";


let save = {

    highScore: 0,

    level: 1,

    xp: 0,

    coins: 0,

    selectedSkin: "green",

    unlockedSkins: [
        "green"
    ],

    missions: {},

    totalFood: 0,

    totalCoins: 0,

    totalGames: 0

};


function loadSave() {

    try {

        const stored =
            localStorage.getItem(
                SAVE_KEY
            );

        if (stored) {

            const data =
                JSON.parse(stored);

            save = {
                ...save,
                ...data
            };

        }

    } catch (error) {

        console.log(
            "Sauvegarde impossible",
            error
        );

    }

}


function saveGame() {

    try {

        localStorage.setItem(
            SAVE_KEY,
            JSON.stringify(save)
        );

    } catch (error) {

        console.log(
            "Impossible de sauvegarder",
            error
        );

    }

}


/* =========================================================
   ÉTAT DU JEU
   ========================================================= */

let selectedWorld = 0;

let snake = [];

let direction = {
    x: 1,
    y: 0
};

let nextDirection = {
    x: 1,
    y: 0
};

let food = null;

let bonus = null;

let coinItems = [];

let obstacles = [];

let score = 0;

let coinsThisGame = 0;

let lives = 3;

let combo = 1;

let comboTimer = 0;

let gameTimer = null;

let running = false;

let paused = false;

let gameOver = false;

let power = 0;

let activePower = null;

let activePowerTimer = 0;

let touchStartX = 0;

let touchStartY = 0;


/* =========================================================
   UTILITAIRES
   ========================================================= */

function rand(min, max) {

    return Math.floor(
        Math.random() *
        (max - min + 1)
    ) + min;

}


function distance(a, b) {

    return Math.sqrt(
        Math.pow(a.x - b.x, 2) +
        Math.pow(a.y - b.y, 2)
    );

}


function samePosition(a, b) {

    return (
        a &&
        b &&
        a.x === b.x &&
        a.y === b.y
    );

}


function showMessage(text) {

    messageBox.textContent = text;

    messageBox.classList.add("show");

    setTimeout(() => {

        messageBox.classList.remove(
            "show"
        );

    }, 1700);

}


function vibrate(pattern = 30) {

    if (
        navigator.vibrate
    ) {

        navigator.vibrate(
            pattern
        );

    }

}


/* =========================================================
   NIVEAUX / XP
   ========================================================= */

function xpNeeded() {

    return (
        100 +
        (save.level - 1) * 50
    );

}


function addXP(amount) {

    save.xp += amount;

    while (
        save.xp >= xpNeeded()
    ) {

        save.xp -= xpNeeded();

        save.level++;

        showMessage(
            "🆙 Niveau " +
            save.level +
            " !"
        );

        vibrate(
            [40, 40, 80]
        );

    }

    checkSkinUnlocks();

    saveGame();

    updateHome();

}


function checkSkinUnlocks() {

    skins.forEach(
        skin => {

            if (
                save.highScore >=
                skin.unlock &&
                !save.unlockedSkins.includes(
                    skin.id
                )
            ) {

                save.unlockedSkins.push(
                    skin.id
                );

                showMessage(
                    "🐍 Skin débloqué : " +
                    skin.name
                );

            }

        }
    );

}


/* =========================================================
   ÉCRANS
   ========================================================= */

function showScreen(screen) {

    [
        homeScreen,
        worldScreen,
        missionsScreen,
        skinsScreen,
        gameScreen
    ].forEach(
        s => s.classList.remove(
            "active"
        )
    );

    screen.classList.add(
        "active"
    );

}


function openHome() {

    stopGame();

    pauseScreen.classList.remove(
        "active"
    );

    gameOverScreen.classList.remove(
        "active"
    );

    showScreen(
        homeScreen
    );

    updateHome();

}


function openWorlds() {

    showScreen(
        worldScreen
    );

    renderWorlds();

}


function openMissions() {

    showScreen(
        missionsScreen
    );

    renderMissions();

}


function openSkins() {

    showScreen(
        skinsScreen
    );

    renderSkins();

    drawSkinPreview();

}


/* =========================================================
   ACCUEIL
   ========================================================= */

function updateHome() {

    homeLevelElement.textContent =
        save.level;

    homeXPElement.textContent =
        save.xp +
        "/" +
        xpNeeded();

    homeCoinsElement.textContent =
        save.coins;

    homeHighScoreElement.textContent =
        save.highScore;

}


/* =========================================================
   MONDES
   ========================================================= */

function isWorldUnlocked(world) {

    return (
        save.highScore >=
        world.unlock
    );

}


function renderWorlds() {

    const list =
        document.getElementById(
            "worldList"
        );

    list.innerHTML = "";

    worlds.forEach(
        world => {

            const unlocked =
                isWorldUnlocked(
                    world
                );

            const card =
                document.createElement(
                    "div"
                );

            card.className =
                "worldCard " +
                (
                    unlocked
                        ? ""
                        : "locked"
                );

            card.innerHTML = `

                ${
                    unlocked
                        ? ""
                        : `<div class="lock">🔒</div>`
                }

                <div class="worldIcon">
                    ${world.icon}
                </div>

                <h3>
                    ${world.name}
                </h3>

                <p>
                    ${world.difficulty}
                </p>

                <p>
                    ${
                        unlocked
                            ? "Débloqué"
                            : "Score requis : " +
                              world.unlock
                    }
                </p>

                <button>
                    ${
                        unlocked
                            ? "JOUER"
                            : "VERROUILLÉ"
                    }
                </button>
            `;

            const button =
                card.querySelector(
                    "button"
                );

            if (unlocked) {

                button.onclick = () => {

                    selectedWorld =
                        world.id;

                    startGame();

                };

            } else {

                button.disabled =
                    true;

            }

            list.appendChild(
                card
            );

        }
    );

}


/* =========================================================
   MISSIONS
   ========================================================= */

const missionDefinitions = [

    {
        id: "food10",
        title: "🍎 Petit appétit",
        description:
            "Manger 10 nourritures",
        target: 10,
        reward: 30
    },

    {
        id: "food50",
        title: "🍎 Grand mangeur",
        description:
            "Manger 50 nourritures",
        target: 50,
        reward: 100
    },

    {
        id: "coins20",
        title: "🪙 Collectionneur",
        description:
            "Collecter 20 pièces",
        target: 20,
        reward: 75
    },

    {
        id: "score100",
        title: "🏆 Premier champion",
        description:
            "Atteindre 100 points",
        target: 100,
        reward: 100
    },

    {
        id: "score500",
        title: "👑 Maître du serpent",
        description:
            "Atteindre 500 points",
        target: 500,
        reward: 300
    }

];


function missionProgress(
    mission
) {

    if (
        mission.id ===
        "food10"
    ) {
        return Math.min(
            save.totalFood,
            mission.target
        );
    }

    if (
        mission.id ===
        "food50"
    ) {
        return Math.min(
            save.totalFood,
            mission.target
        );
    }

    if (
        mission.id ===
        "coins20"
    ) {
        return Math.min(
            save.totalCoins,
            mission.target
        );
    }

    if (
        mission.id ===
        "score100"
    ) {
        return Math.min(
            save.highScore,
            mission.target
        );
    }

    if (
        mission.id ===
        "score500"
    ) {
        return Math.min(
            save.highScore,
            mission.target
        );
    }

    return 0;

}


function renderMissions() {

    const list =
        document.getElementById(
            "missionsList"
        );

    list.innerHTML = "";

    missionDefinitions.forEach(
        mission => {

            const progress =
                missionProgress(
                    mission
                );

            const complete =
                progress >=
                mission.target;

            const percent =
                Math.min(
                    100,
                    (
                        progress /
                        mission.target
                    ) * 100
                );

            const div =
                document.createElement(
                    "div"
                );

            div.className =
                "mission " +
                (
                    complete
                        ? "completed"
                        : ""
                );

            div.innerHTML = `

                <div class="missionTop">

                    <strong>
                        ${mission.title}
                    </strong>

                    <span>
                        ${
                            complete
                                ? "✓"
                                : progress +
                                  "/" +
                                  mission.target
                        }
                    </span>

                </div>

                <div>
                    ${mission.description}
                </div>

                <div class="missionBar">

                    <div
                        class="missionFill"
                        style="width:${percent}%">
                    </div>

                </div>

                <small>
                    Récompense :
                    🪙 ${mission.reward}
                </small>

            `;

            list.appendChild(
                div
            );

        }
    );

}


/* =========================================================
   SKINS
   ========================================================= */

function renderSkins() {

    const list =
        document.getElementById(
            "skinList"
        );

    list.innerHTML = "";

    skins.forEach(
        skin => {

            const unlocked =
                save.unlockedSkins.includes(
                    skin.id
                );

            const card =
                document.createElement(
                    "div"
                );

            card.className =
                "skinCard " +
                (
                    unlocked
                        ? ""
                        : "locked"
                );

            card.innerHTML = `

                <div
                    class="skinColor"
                    style="
                        background:
                        linear-gradient(
                            145deg,
                            ${skin.color},
                            ${skin.dark}
                        );
                    ">
                </div>

                <div>
                    <strong>
                        ${skin.name}
                    </strong>

                    <br>

                    <small>
                        ${
                            unlocked
                                ? "Disponible"
                                : "Score : " +
                                  skin.unlock
                        }
                    </small>
                </div>

                <button>
                    ${
                        save.selectedSkin === skin.id
                            ? "✓"
                            : unlocked
                                ? "CHOISIR"
                                : "🔒"
                    }
                </button>
            `;

            const button =
                card.querySelector(
                    "button"
                );

            if (unlocked) {

                button.onclick = () => {

                    save.selectedSkin =
                        skin.id;

                    saveGame();

                    renderSkins();

                    drawSkinPreview();

                };

            } else {

                button.disabled =
                    true;

            }

            list.appendChild(
                card
            );

        }
    );

}


/* =========================================================
   PRÉVISUALISATION DU SERPENT
   ========================================================= */

function drawSkinPreview() {

    const c =
        document.getElementById(
            "skinCanvas"
        );

    const cctx =
        c.getContext("2d");

    cctx.clearRect(
        0,
        0,
        c.width,
        c.height
    );

    const skin =
        skins.find(
            s =>
                s.id ===
                save.selectedSkin
        ) || skins[0];

    cctx.save();

    cctx.shadowColor =
        "rgba(0,0,0,.7)";

    cctx.shadowBlur = 15;

    cctx.shadowOffsetY = 8;

    cctx.fillStyle =
        skin.dark;

    cctx.beginPath();

    cctx.ellipse(
        80,
        90,
        25,
        19,
        0,
        0,
        Math.PI * 2
    );

    cctx.fill();

    for (
        let i = 0;
        i < 5;
        i++
    ) {

        cctx.fillStyle =
            skin.color;

        cctx.beginPath();

        cctx.arc(
            80 + i * 35,
            90 + Math.sin(i) * 14,
            18,
            0,
            Math.PI * 2
        );

        cctx.fill();

    }

    cctx.fillStyle =
        "#111";

    cctx.beginPath();

    cctx.arc(
        72,
        84,
        4,
        0,
        Math.PI * 2
    );

    cctx.fill();

    cctx.restore();

}


/* =========================================================
   DÉMARRAGE
   ========================================================= */

function startGame() {

    const world =
        worlds[selectedWorld];

    if (
        !isWorldUnlocked(
            world
        )
    ) {

        showMessage(
            "🔒 Monde verrouillé"
        );

        return;

    }

    stopGame();

    showScreen(
        gameScreen
    );

    pauseScreen.classList.remove(
        "active"
    );

    gameOverScreen.classList.remove(
        "active"
    );

    score = 0;

    coinsThisGame = 0;

    lives = 3;

    combo = 1;

    comboTimer = 0;

    power = 0;

    activePower = null;

    activePowerTimer = 0;

    gameOver = false;

    paused = false;

    snake = [

        {
            x: 12,
            y: 12
        },

        {
            x: 11,
            y: 12
        },

        {
            x: 10,
            y: 12
        },

        {
            x: 9,
            y: 12
        }

    ];

    direction = {
        x: 1,
        y: 0
    };

    nextDirection = {
        x: 1,
        y: 0
    };

    obstacles = [];

    coinItems = [];

    bonus = null;

    createObstacles();

    createFood();

    createCoins();

    updateGameUI();

    draw();

    running = true;

    gameTimer =
        setInterval(
            update,
            currentSpeed()
        );

    save.totalGames++;

    saveGame();

}


/* =========================================================
   VITESSE
   ========================================================= */

function currentSpeed() {

    const world =
        worlds[selectedWorld];

    let speed =
        world.speed -
        Math.floor(score / 10) * 3;

    speed =
        Math.max(
            55,
            speed
        );

    if (
        activePower ===
        "slow"
    ) {

        speed *= 1.7;

    }

    if (
        activePower ===
        "fury"
    ) {

        speed *= .65;

    }

    return Math.max(
        35,
        Math.floor(speed)
    );

}


function restartTimer() {

    if (!running) {
        return;
    }

    clearInterval(
        gameTimer
    );

    gameTimer =
        setInterval(
            update,
            currentSpeed()
        );

}


/* =========================================================
   OBSTACLES
   ========================================================= */

function positionFree(
    position,
    includeSnake = true
) {

    if (
        position.x < 0 ||
        position.x >= GRID ||
        position.y < 0 ||
        position.y >= GRID
    ) {

        return false;

    }

    if (
        includeSnake &&
        snake.some(
            part =>
                samePosition(
                    part,
                    position
                )
        )
    ) {

        return false;

    }

    if (
        obstacles.some(
            item =>
                samePosition(
                    item,
                    position
                )
        )
    ) {

        return false;

    }

    return true;

}


function createObstacles() {

    const world =
        worlds[selectedWorld];

    let attempts = 0;

    while (
        obstacles.length <
        world.obstacles &&
        attempts < 300
    ) {

        attempts++;

        const p = {

            x: rand(1, GRID - 2),

            y: rand(1, GRID - 2)

        };

        if (
            p.x >= 7 &&
            p.x <= 15 &&
            p.y >= 7 &&
            p.y <= 15
        ) {

            continue;

        }

        if (
            positionFree(
                p,
                false
            )
        ) {

            obstacles.push(
                p
            );

        }

    }

}


/* =========================================================
   NOURRITURE
   ========================================================= */

function randomFreePosition() {

    for (
        let i = 0;
        i < 500;
        i++
    ) {

        const p = {

            x: rand(1, GRID - 2),

            y: rand(1, GRID - 2)

        };

        if (
            positionFree(
                p
            ) &&
            !samePosition(
                food,
                p
            ) &&
            !samePosition(
                bonus,
                p
            )
        ) {

            return p;

        }

    }

    return {
        x: 18,
        y: 18
    };

}


function createFood() {

    food =
        randomFreePosition();

}


function createCoins() {

    coinItems = [];

    const count =
        rand(1, 3);

    for (
        let i = 0;
        i < count;
        i++
    ) {

        coinItems.push(
            randomFreePosition()
        );

    }

}


/* =========================================================
   BONUS
   ========================================================= */

function createBonus() {

    if (
        Math.random() >
        .30
    ) {

        return;

    }

    const types = [
        "shield",
        "fury",
        "slow"
    ];

    bonus = {

        position:
            randomFreePosition(),

        type:
            types[
                rand(
                    0,
                    types.length - 1
                )
            ],

        life: 80

    };

}


/* =========================================================
   UPDATE
   ========================================================= */

function update() {

    if (
        !running ||
        paused ||
        gameOver
    ) {

        return;

    }

    direction =
        nextDirection;

    const head = {

        x:
            snake[0].x +
            direction.x,

        y:
            snake[0].y +
            direction.y

    };


    /* ===== MURS ===== */

    if (
        head.x < 0 ||
        head.x >= GRID ||
        head.y < 0 ||
        head.y >= GRID
    ) {

        handleCollision();

        return;

    }


    /* ===== OBSTACLES ===== */

    if (
        obstacles.some(
            obstacle =>
                samePosition(
                    obstacle,
                    head
                )
        )
    ) {

        handleCollision();

        return;

    }


    /* ===== CORPS ===== */

    if (
        snake.some(
            part =>
                samePosition(
                    part,
                    head
                )
        )
    ) {

        handleCollision();

        return;

    }


    snake.unshift(
        head
    );


    /* ===== NOURRITURE ===== */

    if (
        samePosition(
            head,
            food
        )
    ) {

        eatFood();

    } else {

        snake.pop();

    }


    /* ===== BONUS ===== */

    if (
        bonus &&
        samePosition(
            head,
            bonus.position
        )
    ) {

        activatePower(
            bonus.type
        );

        bonus = null;

    }


    /* ===== PIÈCES ===== */

    coinItems =
        coinItems.filter(
            coin => {

                if (
                    samePosition(
                        head,
                        coin
                    )
                ) {

                    coinsThisGame++;

                    save.coins++;

                    save.totalCoins++;

                    addXP(5);

                    showMessage(
                        "🪙 +1 pièce"
                    );

                    vibrate(20);

                    return false;

                }

                return true;

            }
        );


    /* ===== COMBO ===== */

    if (
        comboTimer > 0
    ) {

        comboTimer--;

    } else {

        combo = 1;

    }


    /* ===== BONUS TIMER ===== */

    if (bonus) {

        bonus.life--;

        if (
            bonus.life <= 0
        ) {

            bonus = null;

        }

    }


    /* ===== POUVOIR ===== */

    if (
        activePowerTimer > 0
    ) {

        activePowerTimer--;

    } else if (
        activePower
    ) {

        activePower = null;

        power = 0;

        restartTimer();

    }


    updateGameUI();

    draw();

}


/* =========================================================
   COLLISION
   ========================================================= */

function handleCollision() {

    if (
        activePower ===
        "shield"
    ) {

        activePower = null;

        activePowerTimer = 0;

        power = 0;

        showMessage(
            "🛡️ Bouclier utilisé !"
        );

        vibrate(
            [20, 20, 20]
        );

        restartTimer();

        return;

    }

    lives--;

    vibrate(
        [50, 40, 50]
    );

    if (
        lives <= 0
    ) {

        endGame();

        return;

    }

    showMessage(
        "❤️ Vie perdue !"
    );

    resetSnakePosition();

}


function resetSnakePosition() {

    snake = [

        {
            x: 12,
            y: 12
        },

        {
            x: 11,
            y: 12
        },

        {
            x: 10,
            y: 12
        }

    ];

    direction = {
        x: 1,
        y: 0
    };

    nextDirection = {
        x: 1,
        y: 0
    };

}


/* =========================================================
   NOURRITURE MANGÉE
   ========================================================= */

function eatFood() {

    const points =
        5 * combo;

    score += points;

    save.totalFood++;

    combo++;

    combo =
        Math.min(
            combo,
            10
        );

    comboTimer = 15;

    power =
        Math.min(
            100,
            power + 12
        );

    createFood();

    createCoins();

    createBonus();

    addXP(4);

    showMessage(
        "🍎 +" +
        points
    );

    vibrate(15);

    if (
        score >
        save.highScore
    ) {

        save.highScore =
            score;

    }

    restartTimer();

}


/* =========================================================
   POUVOIRS
   ========================================================= */

function activatePower(type) {

    activePower =
        type;

    power = 0;

    activePowerTimer =
        35;

    let text = "";

    if (
        type ===
        "shield"
    ) {

        text =
            "🛡️ Bouclier activé";

    }

    if (
        type ===
        "fury"
    ) {

        text =
            "🔥 FURY !";

    }

    if (
        type ===
        "slow"
    ) {

        text =
            "❄️ Ralentissement";

    }

    showMessage(
        text
    );

    vibrate(
        [30, 30, 60]
    );

    restartTimer();

}


/* =========================================================
   UI DU JEU
   ========================================================= */

function updateGameUI() {

    scoreElement.textContent =
        score;

    highScoreElement.textContent =
        save.highScore;

    gameLevelElement.textContent =
        save.level;

    livesElement.textContent =
        "❤️".repeat(
            Math.max(
                0,
                lives
            )
        );

    coinsGameElement.textContent =
        "🪙 " +
        coinsThisGame;

    comboElement.textContent =
        "COMBO ×" +
        combo;

    powerFill.style.width =
        power + "%";

    if (
        activePower
    ) {

        powerText.textContent =
            activePower.toUpperCase();

    } else {

        powerText.textContent =
            power >= 100
                ? "PRÊT"
                : Math.floor(
                    power
                ) + "%";

    }

    document
        .getElementById(
            "shieldButton"
        )
        .classList.toggle(
            "ready",
            activePower ===
            "shield"
        );

    document
        .getElementById(
            "furyButton"
        )
        .classList.toggle(
            "ready",
            activePower ===
            "fury"
        );

    document
        .getElementById(
            "slowButton"
        )
        .classList.toggle(
            "ready",
            activePower ===
            "slow"
        );

}


/* =========================================================
   FIN DE PARTIE
   ========================================================= */

function endGame() {

    gameOver = true;

    running = false;

    clearInterval(
        gameTimer
    );

    if (
        score >
        save.highScore
    ) {

        save.highScore =
            score;

    }

    addXP(
        Math.floor(
            score / 5
        )
    );

    save.coins +=
        coinsThisGame;

    saveGame();

    document
        .getElementById(
            "finalScore"
        )
        .textContent =
        score;

    const next =
        worlds.find(
            world =>
                save.highScore <
                world.unlock
        );

    const message =
        document.getElementById(
            "unlockMessage"
        );

    if (next) {

        message.textContent =
            "🔒 Prochain monde : " +
            next.name +
            " — score " +
            next.unlock;

    } else {

        message.textContent =
            "👑 Tous les mondes sont débloqués !";

    }

    gameOverScreen.classList.add(
        "active"
    );

    renderWorlds();

}


/* =========================================================
   ARRÊT
   ========================================================= */

function stopGame() {

    running = false;

    clearInterval(
        gameTimer
    );

    gameTimer = null;

}


/* =========================================================
   PAUSE
   ========================================================= */

function pauseGame() {

    if (
        !running ||
        gameOver
    ) {

        return;

    }

    paused = true;

    pauseScreen.classList.add(
        "active"
    );

}


function resumeGame() {

    paused = false;

    pauseScreen.classList.remove(
        "active"
    );

}


/* =========================================================
   DIRECTION
   ========================================================= */

function changeDirection(
    dx,
    dy
) {

    if (
        dx ===
        -direction.x &&
        dy ===
        -direction.y
    ) {

        return;

    }

    nextDirection = {
        x: dx,
        y: dy
    };

}


document
    .querySelectorAll(
        ".control[data-direction]"
    )
    .forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    const dir =
                        button.dataset.direction;

                    if (
                        dir ===
                        "up"
                    ) {
                        changeDirection(
                            0,
                            -1
                        );
                    }

                    if (
                        dir ===
                        "down"
                    ) {
                        changeDirection(
                            0,
                            1
                        );
                    }

                    if (
                        dir ===
                        "left"
                    ) {
                        changeDirection(
                            -1,
                            0
                        );
                    }

                    if (
                        dir ===
                        "right"
                    ) {
                        changeDirection(
                            1,
                            0
                        );
                    }

                }
            );

        }
    );


/* =========================================================
   CLAVIER
   ========================================================= */

document.addEventListener(
    "keydown",
    event => {

        switch (
            event.key
                .toLowerCase()
        ) {

            case "arrowup":
            case "z":
                changeDirection(
                    0,
                    -1
                );
                break;

            case "arrowdown":
            case "s":
                changeDirection(
                    0,
                    1
                );
                break;

            case "arrowleft":
            case "q":
                changeDirection(
                    -1,
                    0
                );
                break;

            case "arrowright":
            case "d":
                changeDirection(
                    1,
                    0
                );
                break;

            case "p":
            case "escape":

                if (paused) {
                    resumeGame();
                } else {
                    pauseGame();
                }

                break;

        }

    }
);


/* =========================================================
   SWIPE
   ========================================================= */

canvas.addEventListener(
    "touchstart",
    event => {

        const touch =
            event.touches[0];

        touchStartX =
            touch.clientX;

        touchStartY =
            touch.clientY;

    },
    {
        passive: true
    }
);


canvas.addEventListener(
    "touchend",
    event => {

        const touch =
            event.changedTouches[0];

        const dx =
            touch.clientX -
            touchStartX;

        const dy =
            touch.clientY -
            touchStartY;

        if (
            Math.abs(dx) <
            20 &&
            Math.abs(dy) <
            20
        ) {

            return;

        }

        if (
            Math.abs(dx) >
            Math.abs(dy)
        ) {

            changeDirection(
                dx > 0
                    ? 1
                    : -1,
                0
            );

        } else {

            changeDirection(
                0,
                dy > 0
                    ? 1
                    : -1
            );

        }

    },
    {
        passive: true
    }
);


/* =========================================================
   DESSIN DU FOND
   ========================================================= */

function drawBackground() {

    const world =
        worlds[selectedWorld];

    let gradient;

    if (
        world.type ===
        "rock"
    ) {

        gradient =
            ctx.createLinearGradient(
                0,
                0,
                0,
                SIZE
            );

        gradient.addColorStop(
            0,
            "#78a957"
        );

        gradient.addColorStop(
            1,
            "#304d27"
        );

    }

    else if (
        world.type ===
        "wall"
    ) {

        gradient =
            ctx.createLinearGradient(
                0,
                0,
                0,
                SIZE
            );

        gradient.addColorStop(
            0,
            "#d7a85b"
        );

        gradient.addColorStop(
            1,
            "#81552b"
        );

    }

    else if (
        world.type ===
        "tree"
    ) {

        gradient =
            ctx.createLinearGradient(
                0,
                0,
                0,
                SIZE
            );

        gradient.addColorStop(
            0,
            "#315d3a"
        );

        gradient.addColorStop(
            1,
            "#102a18"
        );

    }

    else if (
        world.type ===
        "lava"
    ) {

        gradient =
            ctx.createLinearGradient(
                0,
                0,
                0,
                SIZE
            );

        gradient.addColorStop(
            0,
            "#5d2016"
        );

        gradient.addColorStop(
            1,
            "#170907"
        );

    }

    else if (
        world.type ===
        "ice"
    ) {

        gradient =
            ctx.createLinearGradient(
                0,
                0,
                0,
                SIZE
            );

        gradient.addColorStop(
            0,
            "#79cbe1"
        );

        gradient.addColorStop(
            1,
            "#164c69"
        );

    }

    else {

        gradient =
            ctx.createLinearGradient(
                0,
                0,
                0,
                SIZE
            );

        gradient.addColorStop(
            0,
            "#101d43"
        );

        gradient.addColorStop(
            1,
            "#030511"
        );

    }

    ctx.fillStyle =
        gradient;

    ctx.fillRect(
        0,
        0,
        SIZE,
        SIZE
    );


    /* grille */

    ctx.strokeStyle =
        "rgba(255,255,255,.035)";

    ctx.lineWidth = 1;

    for (
        let i = 0;
        i <= GRID;
        i++
    ) {

        const p =
            i * CELL;

        ctx.beginPath();

        ctx.moveTo(
            p,
            0
        );

        ctx.lineTo(
            p,
            SIZE
        );

        ctx.stroke();

        ctx.beginPath();

        ctx.moveTo(
            0,
            p
        );

        ctx.lineTo(
            SIZE,
            p
        );

        ctx.stroke();

    }

}


/* =========================================================
   OBSTACLES
   ========================================================= */

function drawObstacles() {

    const world =
        worlds[selectedWorld];

    obstacles.forEach(
        obstacle => {

            const x =
                obstacle.x *
                CELL;

            const y =
                obstacle.y *
                CELL;

            if (
                world.type ===
                "rock"
            ) {

                drawRock(
                    x,
                    y
                );

            }

            else if (
                world.type ===
                "wall"
            ) {

                drawWall(
                    x,
                    y
                );

            }

            else if (
                world.type ===
                "tree"
            ) {

                drawTree(
                    x,
                    y
                );

            }

            else if (
                world.type ===
                "lava"
            ) {

                drawLavaRock(
                    x,
                    y
                );

            }

            else if (
                world.type ===
                "ice"
            ) {

                drawIce(
                    x,
                    y
                );

            }

            else {

                drawAsteroid(
                    x,
                    y
                );

            }

        }
    );

}


/* =========================================================
   ROCHER
   ========================================================= */

function drawRock(
    x,
    y
) {

    ctx.save();

    ctx.fillStyle =
        "#273027";

    ctx.shadowColor =
        "rgba(0,0,0,.6)";

    ctx.shadowBlur = 8;

    ctx.beginPath();

    ctx.moveTo(
        x + 4,
        y + 20
    );

    ctx.lineTo(
        x + 8,
        y + 7
    );

    ctx.lineTo(
        x + 18,
        y + 3
    );

    ctx.lineTo(
        x + 27,
        y + 10
    );

    ctx.lineTo(
        x + 28,
        y + 25
    );

    ctx.lineTo(
        x + 20,
        y + 29
    );

    ctx.lineTo(
        x + 7,
        y + 27
    );

    ctx.closePath();

    ctx.fill();

    ctx.fillStyle =
        "rgba(255,255,255,.13)";

    ctx.beginPath();

    ctx.moveTo(
        x + 9,
        y + 9
    );

    ctx.lineTo(
        x + 18,
        y + 5
    );

    ctx.lineTo(
        x + 14,
        y + 15
    );

    ctx.closePath();

    ctx.fill();

    ctx.restore();

}


/* =========================================================
   MUR
   ========================================================= */

function drawWall(
    x,
    y
) {

    ctx.save();

    ctx.fillStyle =
        "#9d6c35";

    ctx.fillRect(
        x + 2,
        y + 4,
        CELL - 4,
        CELL - 7
    );

    ctx.strokeStyle =
        "#5d3a1e";

    ctx.lineWidth = 2;

    ctx.strokeRect(
        x + 2,
        y + 4,
        CELL - 4,
        CELL - 7
    );

    ctx.strokeStyle =
        "rgba(255,220,140,.2)";

    ctx.beginPath();

    ctx.moveTo(
        x + 5,
        y + 12
    );

    ctx.lineTo(
        x + 27,
        y + 12
    );

    ctx.stroke();

    ctx.restore();

}


/* =========================================================
   ARBRE
   ========================================================= */

function drawTree(
    x,
    y
) {

    ctx.save();

    ctx.fillStyle =
        "#58371f";

    ctx.fillRect(
        x + 11,
        y + 12,
        9,
        18
    );

    const gradient =
        ctx.createRadialGradient(
            x + 15,
            y + 8,
            2,
            x + 15,
            y + 10,
            15
        );

    gradient.addColorStop(
        0,
        "#63ad52"
    );

    gradient.addColorStop(
        1,
        "#123c1d"
    );

    ctx.fillStyle =
        gradient;

    ctx.beginPath();

    ctx.arc(
        x + 10,
        y + 10,
        9,
        0,
        Math.PI * 2
    );

    ctx.arc(
        x + 20,
        y + 9,
        9,
        0,
        Math.PI * 2
    );

    ctx.arc(
        x + 15,
        y + 4,
        9,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.restore();

}


/* =========================================================
   LAVE
   ========================================================= */

function drawLavaRock(
    x,
    y
) {

    ctx.save();

    ctx.fillStyle =
        "#20120e";

    ctx.beginPath();

    ctx.arc(
        x + 15,
        y + 15,
        12,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.strokeStyle =
        "#ff6428";

    ctx.lineWidth = 3;

    ctx.beginPath();

    ctx.moveTo(
        x + 8,
        y + 17
    );

    ctx.lineTo(
        x + 13,
        y + 8
    );

    ctx.lineTo(
        x + 20,
        y + 17
    );

    ctx.stroke();

    ctx.restore();

}


/* =========================================================
   GLACE
   ========================================================= */

function drawIce(
    x,
    y
) {

    ctx.save();

    const gradient =
        ctx.createLinearGradient(
            x,
            y,
            x + CELL,
            y + CELL
        );

    gradient.addColorStop(
        0,
        "#d9fbff"
    );

    gradient.addColorStop(
        .5,
        "#69cfe8"
    );

    gradient.addColorStop(
        1,
        "#267a9c"
    );

    ctx.fillStyle =
        gradient;

    ctx.beginPath();

    ctx.moveTo(
        x + 4,
        y + 25
    );

    ctx.lineTo(
        x + 9,
        y + 5
    );

    ctx.lineTo(
        x + 25,
        y + 8
    );

    ctx.lineTo(
        x + 29,
        y + 26
    );

    ctx.closePath();

    ctx.fill();

    ctx.restore();

}


/* =========================================================
   ASTÉROÏDE
   ========================================================= */

function drawAsteroid(
    x,
    y
) {

    ctx.save();

    ctx.fillStyle =
        "#555a68";

    ctx.beginPath();

    ctx.moveTo(
        x + 5,
        y + 8
    );

    ctx.lineTo(
        x + 15,
        y + 3
    );

    ctx.lineTo(
        x + 27,
        y + 8
    );

    ctx.lineTo(
        x + 25,
        y + 23
    );

    ctx.lineTo(
        x + 13,
        y + 28
    );

    ctx.lineTo(
        x + 4,
        y + 20
    );

    ctx.closePath();

    ctx.fill();

    ctx.fillStyle =
        "#343844";

    ctx.beginPath();

    ctx.arc(
        x + 13,
        y + 13,
        4,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.beginPath();

    ctx.arc(
        x + 22,
        y + 20,
        3,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.restore();

}


/* =========================================================
   NOURRITURE
   ========================================================= */

function drawFood() {

    if (!food) {
        return;
    }

    const x =
        food.x * CELL +
        CELL / 2;

    const y =
        food.y * CELL +
        CELL / 2;

    const pulse =
        Math.sin(
            Date.now() / 180
        ) * 2;

    ctx.save();

    ctx.shadowColor =
        "rgba(255,70,50,.8)";

    ctx.shadowBlur = 15;

    const gradient =
        ctx.createRadialGradient(
            x - 3,
            y - 4,
            1,
            x,
            y,
            11
        );

    gradient.addColorStop(
        0,
        "#fff5a0"
    );

    gradient.addColorStop(
        .3,
        "#ff644a"
    );

    gradient.addColorStop(
        1,
        "#9c1515"
    );

    ctx.fillStyle =
        gradient;

    ctx.beginPath();

    ctx.arc(
        x,
        y + pulse,
        8,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.fillStyle =
        "#4c9b3d";

    ctx.beginPath();

    ctx.ellipse(
        x + 6,
        y - 8,
        6,
        3,
        -.5,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.restore();

}


/* =========================================================
   PIÈCES
   ========================================================= */

function drawCoins() {

    coinItems.forEach(
        coin => {

            const x =
                coin.x *
                CELL +
                CELL / 2;

            const y =
                coin.y *
                CELL +
                CELL / 2;

            ctx.save();

            ctx.shadowColor =
                "rgba(255,220,50,.7)";

            ctx.shadowBlur = 12;

            ctx.fillStyle =
                "#ffd83d";

            ctx.beginPath();

            ctx.arc(
                x,
                y,
                7,
                0,
                Math.PI * 2
            );

            ctx.fill();

            ctx.fillStyle =
                "#8d6311";

            ctx.font =
                "bold 9px Arial";

            ctx.textAlign =
                "center";

            ctx.textBaseline =
                "middle";

            ctx.fillText(
                "$",
                x,
                y + 1
            );

            ctx.restore();

        }
    );

}


/* =========================================================
   BONUS
   ========================================================= */

function drawBonus() {

    if (!bonus) {
        return;
    }

    const x =
        bonus.position.x *
        CELL +
        CELL / 2;

    const y =
        bonus.position.y *
        CELL +
        CELL / 2;

    const symbols = {

        shield: "🛡️",

        fury: "🔥",

        slow: "❄️"

    };

    ctx.save();

    ctx.font =
        "20px Arial";

    ctx.textAlign =
        "center";

    ctx.textBaseline =
        "middle";

    ctx.shadowColor =
        "white";

    ctx.shadowBlur = 12;

    ctx.fillText(
        symbols[
            bonus.type
        ],
        x,
        y
    );

    ctx.restore();

}


/* =========================================================
   SERPENT RÉALISTE
   ========================================================= */

function drawSnake() {

    const skin =
        skins.find(
            s =>
                s.id ===
                save.selectedSkin
        ) || skins[0];


    /* ================= QUEUE ================= */

    for (
        let i =
            snake.length - 1;
        i >= 1;
        i--
    ) {

        const part =
            snake[i];

        const x =
            part.x *
            CELL +
            CELL / 2;

        const y =
            part.y *
            CELL +
            CELL / 2;

        const ratio =
            i /
            snake.length;

        const radius =
            Math.max(
                7,
                13 -
                ratio * 5
            );


        ctx.save();

        /* ombre */

        ctx.shadowColor =
            "rgba(0,0,0,.65)";

        ctx.shadowBlur = 7;

        ctx.shadowOffsetY = 3;


        /* corps */

        const gradient =
            ctx.createRadialGradient(
                x - 5,
                y - 6,
                2,
                x,
                y,
                radius
            );

        gradient.addColorStop(
            0,
            lighten(
                skin.color,
                35
            )
        );

        gradient.addColorStop(
            .45,
            skin.color
        );

        gradient.addColorStop(
            1,
            skin.dark
        );

        ctx.fillStyle =
            gradient;

        ctx.beginPath();

        ctx.arc(
            x,
            y,
            radius,
            0,
            Math.PI * 2
        );

        ctx.fill();


        /* écailles */

        ctx.shadowColor =
            "transparent";

        ctx.strokeStyle =
            "rgba(255,255,255,.13)";

        ctx.lineWidth = 1;

        ctx.beginPath();

        ctx.arc(
            x,
            y,
            radius * .65,
            0,
            Math.PI
        );

        ctx.stroke();

        ctx.restore();

    }


    /* ================= TÊTE ================= */

    const head =
        snake[0];

    if (!head) {
        return;
    }

    const x =
        head.x *
        CELL +
        CELL / 2;

    const y =
        head.y *
        CELL +
        CELL / 2;


    ctx.save();

    ctx.translate(
        x,
        y
    );


    let angle = 0;

    if (
        direction.x === 1
    ) {
        angle = 0;
    }

    else if (
        direction.x === -1
    ) {
        angle = Math.PI;
    }

    else if (
        direction.y === 1
    ) {
        angle = Math.PI / 2;
    }

    else {
        angle =
            -Math.PI / 2;
    }

    ctx.rotate(
        angle
    );


    /* ombre */

    ctx.shadowColor =
        "rgba(0,0,0,.75)";

    ctx.shadowBlur = 10;

    ctx.shadowOffsetY = 5;


    /* tête */

    const headGradient =
        ctx.createRadialGradient(
            -6,
            -7,
            2,
            0,
            0,
            18
        );

    headGradient.addColorStop(
        0,
        lighten(
            skin.color,
            45
        )
    );

    headGradient.addColorStop(
        .45,
        skin.color
    );

    headGradient.addColorStop(
        1,
        skin.dark
    );

    ctx.fillStyle =
        headGradient;

    ctx.beginPath();

    ctx.ellipse(
        0,
        0,
        18,
        14,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();


    /* museau */

    ctx.fillStyle =
        skin.dark;

    ctx.beginPath();

    ctx.ellipse(
        14,
        0,
        7,
        9,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();


    /* narines */

    ctx.fillStyle =
        "#090909";

    ctx.beginPath();

    ctx.arc(
        17,
        -4,
        1.5,
        0,
        Math.PI * 2
    );

    ctx.arc(
        17,
        4,
        1.5,
        0,
        Math.PI * 2
    );

    ctx.fill();


    /* yeux */

    drawSnakeEye(
        2,
        -9
    );

    drawSnakeEye(
        2,
        9
    );


    /* langue */

    const tongueWave =
        Math.sin(
            Date.now() / 100
        ) * 2;

    ctx.strokeStyle =
        "#ef4b5d";

    ctx.lineWidth = 1.5;

    ctx.beginPath();

    ctx.moveTo(
        19,
        0
    );

    ctx.lineTo(
        27,
        tongueWave
    );

    ctx.stroke();

    ctx.beginPath();

    ctx.moveTo(
        27,
        tongueWave
    );

    ctx.lineTo(
        31,
        tongueWave - 3
    );

    ctx.moveTo(
        27,
        tongueWave
    );

    ctx.lineTo(
        31,
        tongueWave + 3
    );

    ctx.stroke();


    /* motif de tête */

    ctx.strokeStyle =
        "rgba(0,0,0,.2)";

    ctx.beginPath();

    ctx.moveTo(
        -8,
        -8
    );

    ctx.lineTo(
        -3,
        0
    );

    ctx.lineTo(
        -8,
        8
    );

    ctx.stroke();

    ctx.restore();

}


function drawSnakeEye(
    x,
    y
) {

    ctx.save();

    ctx.fillStyle =
        "#f3d86a";

    ctx.beginPath();

    ctx.arc(
        x,
        y,
        4,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.fillStyle =
        "#050505";

    ctx.beginPath();

    ctx.ellipse(
        x + 1,
        y,
        1.5,
        3,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.restore();

}


/* =========================================================
   ÉCLAIRCIR UNE COULEUR
   ========================================================= */

function lighten(
    hex,
    amount
) {

    let color =
        hex.replace(
            "#",
            ""
        );

    if (
        color.length !== 6
    ) {

        return hex;

    }

    let r =
        parseInt(
            color.substring(
                0,
                2
            ),
            16
        );

    let g =
        parseInt(
            color.substring(
                2,
                4
            ),
            16
        );

    let b =
        parseInt(
            color.substring(
                4,
                6
            ),
            16
        );


    r =
        Math.min(
            255,
            r + amount
        );

    g =
        Math.min(
            255,
            g + amount
        );

    b =
        Math.min(
            255,
            b + amount
        );


    return (
        "#" +
        r.toString(16)
            .padStart(2, "0") +
        g.toString(16)
            .padStart(2, "0") +
        b.toString(16)
            .padStart(2, "0")
    );

}


/* =========================================================
   DESSIN GLOBAL
   ========================================================= */

function draw() {

    ctx.clearRect(
        0,
        0,
        SIZE,
        SIZE
    );

    drawBackground();

    drawObstacles();

    drawCoins();

    drawFood();

    drawBonus();

    drawSnake();

}


/* =========================================================
   ÉVÉNEMENTS DES BOUTONS
   ========================================================= */

document
    .getElementById(
        "startButton"
    )
    .onclick =
    openWorlds;


document
    .getElementById(
        "missionsButton"
    )
    .onclick =
    openMissions;


document
    .getElementById(
        "skinsButton"
    )
    .onclick =
    openSkins;


document
    .getElementById(
        "worldBackButton"
    )
    .onclick =
    openHome;


document
    .getElementById(
        "missionsBackButton"
    )
    .onclick =
    openHome;


document
    .getElementById(
        "skinsBackButton"
    )
    .onclick =
    openHome;


document
    .getElementById(
        "pauseButton"
    )
    .onclick =
    pauseGame;


document
    .getElementById(
        "resumeButton"
    )
    .onclick =
    resumeGame;


document
    .getElementById(
        "restartPauseButton"
    )
    .onclick =
    startGame;


document
    .getElementById(
        "homePauseButton"
    )
    .onclick =
    openHome;


document
    .getElementById(
        "playAgainButton"
    )
    .onclick =
    startGame;


document
    .getElementById(
        "gameOverHomeButton"
    )
    .onclick =
    openHome;


/* =========================================================
   BOUTONS DE POUVOIRS
   ========================================================= */

document
    .getElementById(
        "shieldButton"
    )
    .onclick =
    () => {

        if (
            power >= 100 &&
            !activePower
        ) {

            activatePower(
                "shield"
            );

        } else {

            showMessage(
                "Le pouvoir n'est pas prêt"
            );

        }

    };


document
    .getElementById(
        "furyButton"
    )
    .onclick =
    () => {

        if (
            power >= 100 &&
            !activePower
        ) {

            activatePower(
                "fury"
            );

        } else {

            showMessage(
                "Le pouvoir n'est pas prêt"
            );

        }

    };


document
    .getElementById(
        "slowButton"
    )
    .onclick =
    () => {

        if (
            power >= 100 &&
            !activePower
        ) {

            activatePower(
                "slow"
            );

        } else {

            showMessage(
                "Le pouvoir n'est pas prêt"
            );

        }

    };


/* =========================================================
   INITIALISATION
   ========================================================= */

loadSave();

updateHome();

draw();

renderWorlds();