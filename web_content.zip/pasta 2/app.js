(function () {
    const SUPABASE_URL = 'https://zntmtfbvxkkkyqvtgsfy.supabase.co';
    const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_dYBQSKOmVMJ6oPfAXhKlAA_B5K7XohC';
    const DOCUMENT_BUCKET = 'courier-documents';
    const COURIER_DEFAULT_MAP_CENTER = [-2.5297, -44.3068];
    const COURIER_GEOCODING_LOCALITY = 'Matões do Norte - MA, Brasil';
    const ADMIN_EMAILS = new Set(['ericksanttos81@gmail.com', 'oklajunior26@gmail.com']);
    const ACTIVE_STATUSES = ['accepted', 'pickup_started', 'collected', 'in_transit'];
    const STATUS_LABELS = {
        pending: 'Aguardando entregador',
        accepted: 'Aceito',
        pickup_started: 'Coleta iniciada',
        collected: 'Produto retirado',
        in_transit: 'Em trajeto',
        delivered: 'Entregue',
        cancelled: 'Cancelado',
        aguardando_entregador: 'Aguardando entregador',
        entregador_a_caminho: 'A caminho da coleta',
        objeto_coletado: 'Produto retirado',
        em_entrega: 'Em trajeto',
        entregue: 'Entregue'
    };
    const app = {
        client: null,
        user: null,
        profile: null,
        courier: null,
        settings: {
            minimum_fee: 8,
            motorcycle_per_km: 2.5,
            bicycle_per_km: 1.8,
            additional_fee: 0,
            commission_enabled: true,
            platform_fee_percent: 15,
            allow_cancel_after_acceptance: false
        },
        orders: [],
        adminOrders: [],
        adminProfileById: new Map(),
        adminOrderOffset: 0,
        adminOrderTotal: 0,
        adminOrderPageSize: 50,
        authMode: 'login',
        passwordRecovery: {
            email: '',
            verified: false
        },
        selectedVehicle: 'motorcycle',
        refreshTimer: null
    };
    let courierMap = null;
    let courierPickupMarker = null;
    let courierDropoffMarker = null;
    let courierRouteLine = null;
    let courierLocationMarker = null;
    let courierMapRouteKey = '';
    let courierMapOrderKey = '';
    let courierMapEnabled = false;
    let lastCourierGeocodeAt = 0;
    let courierLocationWatchId = null;
    let courierTrackingOrderId = null;
    let courierLocationSyncUnavailableOrderId = null;
    let courierLocationLastSentAt = 0;
    let courierLocationRequestPromise = null;
    let courierLocationRequestedAt = 0;
    let clientLocationChannel = null;
    let clientOrdersChannel = null;
    let clientTrackingOrderId = null;
    let clientTrackingVehicleType = null;
    let clientCourierMarker = null;
    let clientLocationUpdatedAt = 0;
    let clientOrdersRefreshTimer = null;
    const markerAnimations = new WeakMap();
    let legalModalTrigger = null;

    function showMessage(message, type) {
        const element = document.getElementById('app-message');
        element.className = `mb-4 rounded-xl px-4 py-3 text-sm ${type === 'error' ? 'bg-rose-50 text-rose-800 border border-rose-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'}`;
        element.textContent = message;
        element.classList.remove('hidden');
        element.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function hideMessage() {
        document.getElementById('app-message').classList.add('hidden');
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, character => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        })[character]);
    }

    function money(value) {
        return Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }

    function fail(error, context) {
        console.error(context, error);
        const detail = error.code === 'PGRST205' || /Could not find the table/i.test(error.message || '')
            ? 'O banco ainda não foi preparado. Execute o arquivo supabase-setup.sql no SQL Editor do Supabase e atualize esta página.'
            : error.message || 'erro inesperado';
        showMessage(`${context}: ${detail}`, 'error');
    }

    function safely(action, context) {
        return async (...args) => {
            try {
                return await action(...args);
            } catch (error) {
                fail(error, context);
            }
        };
    }

    function isAdminEmail(email) {
        return ADMIN_EMAILS.has(String(email || '').trim().toLowerCase());
    }

    function roleIsAdmin() {
        const email = app.user?.email || app.profile?.email;
        return app.user?.app_metadata?.role === 'admin' || isAdminEmail(email);
    }

    async function initialize() {
        if (!window.supabase?.createClient) {
            showMessage('Não foi possível carregar o cliente Supabase. Confira sua conexão e atualize a página.', 'error');
            return;
        }

        app.client = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
        app.client.auth.onAuthStateChange((event, session) => {
            queueMicrotask(() => {
                if (event === 'INITIAL_SESSION' && !session) openAuthForRole('client');
                applySession(session).catch(error => fail(error, 'Erro ao carregar sessão'));
            });
        });

        document.getElementById('auth-role-field').classList.remove('hidden');
        document.getElementById('auth-perfil').value = 'client';
        atualizarCamposCadastroAuth();
        await loadSettings();
    }

    async function loadSettings() {
        const { data, error } = await app.client.from('platform_settings').select('*').eq('id', true).maybeSingle();
        if (error) throw error;
        if (data) app.settings = data;
        carregarTarifasNoForm();
        atualizarEstimativa();
    }

    async function applySession(session) {
        if (app.user?.id !== (session?.user?.id || null)) {
            courierMapEnabled = false;
            setCourierMapVisibility(false);
        }
        stopCourierLocationTracking();
        stopClientLocationTracking();
        removeRealtimeChannel(clientOrdersChannel);
        clientOrdersChannel = null;
        if (clientOrdersRefreshTimer) clearTimeout(clientOrdersRefreshTimer);
        clientOrdersRefreshTimer = null;
        app.user = session?.user || null;
        app.profile = null;
        app.courier = null;
        if (app.refreshTimer) clearInterval(app.refreshTimer);
        app.refreshTimer = null;

        if (app.user) {
            const { data, error } = await app.client.from('profiles')
                .select('id, full_name, phone, email, role, account_status, block_reason')
                .eq('id', app.user.id)
                .maybeSingle();
            if (error) throw error;
            app.profile = data;
            if (!app.profile) {
                throw new Error('Perfil não encontrado. Execute o arquivo supabase-setup.sql no SQL Editor do projeto.');
            }
            if (app.profile.account_status === 'blocked') {
                const reason = app.profile.block_reason ? ` Motivo: ${app.profile.block_reason}` : '';
                await app.client.auth.signOut();
                app.user = null;
                app.profile = null;
                app.courier = null;
                updateHeader();
                clearCourierDashboard();
                showMessage(`Esta conta está bloqueada e não pode acessar o sistema.${reason}`, 'error');
                return;
            }
            if (app.profile.role === 'courier' && !roleIsAdmin()) {
                await loadCourierProfile();
            }
        }

        updateHeader();
        await loadSettings();
        if (!roleIsAdmin()) carregarPedidosCliente().catch(error => fail(error, 'Erro ao carregar pedidos do cliente'));
        if (app.profile?.role === 'client' && !roleIsAdmin()) subscribeClientOrderUpdates();
        if (app.profile?.role === 'courier' && !roleIsAdmin()) {
            await carregarPainelEntregador();
            app.refreshTimer = setInterval(() => {
                Promise.all([carregarPedidosDisponiveisEntregador(), carregarEntregaAtivaEntregador()])
                    .catch(error => fail(error, 'Erro ao atualizar entregas'));
            }, 20000);
        } else {
            clearCourierDashboard();
        }
        if (roleIsAdmin()) await switchTab('admin');
    }

    async function loadCourierProfile() {
        const { data, error } = await app.client.from('courier_profiles').select('*').eq('user_id', app.user.id).maybeSingle();
        if (error) throw error;
        app.courier = data;
        return data;
    }

    function updateHeader() {
        const isAdmin = roleIsAdmin();
        const role = isAdmin ? 'Administrador' : app.profile?.role === 'courier' ? 'Entregador' : 'Cliente';
        document.getElementById('current-user-name').textContent = app.profile?.full_name || app.user?.email || 'Visitante';
        document.getElementById('current-user-role').textContent = role;
        const adminSessionName = document.getElementById('admin-session-name');
        if (adminSessionName) adminSessionName.textContent = app.profile?.full_name || app.user?.email || 'Administrador';
        document.getElementById('auth-btn-label').textContent = app.user ? 'Sair' : 'Entrar';
        document.getElementById('nav-cliente').classList.toggle('hidden', isAdmin || app.profile?.role === 'courier');
        document.getElementById('nav-cliente-mobile').classList.toggle('hidden', isAdmin || app.profile?.role === 'courier');
        document.getElementById('nav-entregador').classList.toggle('hidden', isAdmin || app.profile?.role === 'client');
        document.getElementById('nav-entregador-mobile').classList.toggle('hidden', isAdmin || app.profile?.role === 'client');
        document.getElementById('nav-admin').classList.toggle('hidden', !isAdmin);
        document.getElementById('nav-admin-mobile').classList.toggle('hidden', !isAdmin);
    }

    function clearCourierDashboard() {
        stopCourierLocationTracking();
        document.getElementById('courier-registration-required').classList.remove('hidden');
        document.getElementById('courier-dashboard').classList.add('hidden');
        document.getElementById('courier-work-area').classList.add('hidden');
        courierMapEnabled = false;
        courierMapRouteKey = '';
        courierMapOrderKey = '';
        setCourierMapVisibility(false);
        setCourierAvailableOrdersVisibility(true);
    }

    function setCourierMapVisibility(visible) {
        const mapSection = document.getElementById('courier-map-section');
        if (!mapSection) return;
        mapSection.classList.toggle('hidden', !visible);
        if (visible) {
            initializeCourierMap();
            setTimeout(() => courierMap?.invalidateSize(), 200);
            requestCourierCurrentLocation();
        }
    }

    function setCourierAvailableOrdersVisibility(visible) {
        const section = document.getElementById('courier-available-orders-section');
        if (section) section.classList.toggle('hidden', !visible);
    }

    function initializeCourierMap() {
        if (courierMap) return;
        if (!window.L) throw new Error('O mapa não pôde ser carregado.');
        courierMap = window.L.map('courier-map').setView(COURIER_DEFAULT_MAP_CENTER, 13);
        window.L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 19
        }).addTo(courierMap);
    }

    function getValidCourierCoordinates(latitude, longitude) {
        if (latitude === null || latitude === undefined || latitude === ''
            || longitude === null || longitude === undefined || longitude === '') return null;
        const lat = Number(latitude);
        const lon = Number(longitude);
        if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return null;
        return [lat, lon];
    }

    function withCourierGeocodingLocality(address) {
        const addressText = String(address || '').trim();
        if (!addressText) return '';
        const normalizedAddress = addressText.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
        return /matoes do norte\s*[-,]\s*ma\b/.test(normalizedAddress)
            ? addressText
            : `${addressText}, ${COURIER_GEOCODING_LOCALITY}`;
    }

    async function geocodeCourierAddress(address) {
        const query = withCourierGeocodingLocality(address);
        if (!query) return null;
        const wait = Math.max(0, 1000 - (Date.now() - lastCourierGeocodeAt));
        if (wait) await new Promise(resolve => setTimeout(resolve, wait));
        lastCourierGeocodeAt = Date.now();
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=${encodeURIComponent(query)}`, {
            headers: { Accept: 'application/json' }
        });
        if (!response.ok) throw new Error(`A busca do endereço falhou (HTTP ${response.status}).`);
        const results = await response.json();
        if (!Array.isArray(results) || !results.length) return null;
        return getValidCourierCoordinates(results[0].lat, results[0].lon);
    }

    function buildGoogleMapsDirectionsUrl(order) {
        const origin = withCourierGeocodingLocality(order.pickup_address);
        const destination = withCourierGeocodingLocality(order.dropoff_address);
        const travelMode = order.vehicle_type === 'bicycle' ? 'bicycling' : 'driving';
        return `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&travelmode=${travelMode}`;
    }

    async function atualizarMapaEntregaEntregador(order) {
        const status = document.getElementById('courier-map-status');

        if (!order) {
            courierMapEnabled = false;
            setCourierMapVisibility(false);
            courierMapRouteKey = '';
            courierMapOrderKey = '';
            [courierPickupMarker, courierDropoffMarker, courierRouteLine, courierLocationMarker].forEach(layer => {
                if (layer && courierMap) courierMap.removeLayer(layer);
            });
            courierPickupMarker = null;
            courierDropoffMarker = null;
            courierRouteLine = null;
            courierLocationMarker = null;
            status.textContent = 'Nenhuma entrega em andamento para mostrar no mapa.';
            return;
        }

        setCourierMapVisibility(courierMapEnabled);
        initializeCourierMap();
        const orderKey = `${order.id}|${order.pickup_address}|${order.dropoff_address}|${order.pickup_latitude}|${order.pickup_longitude}|${order.dropoff_latitude}|${order.dropoff_longitude}`;
        if (orderKey === courierMapOrderKey) return;
        status.textContent = 'Localizando automaticamente os endereços da coleta e da entrega...';

        [courierPickupMarker, courierDropoffMarker, courierRouteLine].forEach(layer => {
            if (layer) courierMap.removeLayer(layer);
        });
        courierPickupMarker = null;
        courierDropoffMarker = null;
        courierRouteLine = null;

        let pickupCoordinates = getValidCourierCoordinates(order.pickup_latitude, order.pickup_longitude);
        let dropoffCoordinates = getValidCourierCoordinates(order.dropoff_latitude, order.dropoff_longitude);
        let pickupGeocoded = false;
        let dropoffGeocoded = false;
        const geocodingErrors = [];
        try {
            const coordinates = await geocodeCourierAddress(order.pickup_address);
            if (coordinates) {
                pickupCoordinates = coordinates;
                pickupGeocoded = true;
            }
        } catch (error) {
            geocodingErrors.push(error);
            console.error('Não foi possível localizar automaticamente o endereço de coleta.', error);
        }
        try {
            const coordinates = await geocodeCourierAddress(order.dropoff_address);
            if (coordinates) {
                dropoffCoordinates = coordinates;
                dropoffGeocoded = true;
            }
        } catch (error) {
            geocodingErrors.push(error);
            console.error('Não foi possível localizar automaticamente o endereço de entrega.', error);
        }

        const routeKey = `${orderKey}|${pickupCoordinates?.join(',') || ''}|${dropoffCoordinates?.join(',') || ''}`;
        const points = [pickupCoordinates, dropoffCoordinates].filter(Boolean);
        if (routeKey === courierMapRouteKey) {
            courierMapOrderKey = orderKey;
            return;
        }
        courierMapRouteKey = routeKey;
        courierMapOrderKey = orderKey;
        const createAddressPopup = label => {
            const popup = document.createElement('span');
            popup.textContent = `${label}: ${order[label === 'Coleta' ? 'pickup_address' : 'dropoff_address']}`;
            return popup;
        };
        if (pickupCoordinates) {
            courierPickupMarker = window.L.marker(pickupCoordinates).addTo(courierMap)
                .bindPopup(createAddressPopup('Coleta'));
        }
        if (dropoffCoordinates) {
            courierDropoffMarker = window.L.marker(dropoffCoordinates).addTo(courierMap)
                .bindPopup(createAddressPopup('Destino'));
        }
        if (pickupCoordinates && dropoffCoordinates) {
            courierRouteLine = window.L.polyline([pickupCoordinates, dropoffCoordinates], {
                color: '#0284c7',
                weight: 4,
                dashArray: '6, 8'
            }).addTo(courierMap);
        }
        const targetCoordinates = dropoffCoordinates || pickupCoordinates;
        if (targetCoordinates) courierMap.setView(targetCoordinates, 15);
        if (!points.length) {
            status.textContent = geocodingErrors.length
                ? `Não foi possível localizar os endereços no mapa. Coleta: ${order.pickup_address} · Destino: ${order.dropoff_address}`
                : 'Não foi possível encontrar esses endereços no mapa. Confira os endereços informados pelo cliente.';
            return;
        }
        const routeStatus = pickupCoordinates && dropoffCoordinates
            ? 'Coleta e destino localizados automaticamente; rota exibida no mapa.'
            : pickupCoordinates
                ? 'Coleta localizada; não foi possível localizar o destino no mapa.'
                : 'Destino localizado; não foi possível localizar a coleta no mapa.';
        const usedStoredCoordinates = geocodingErrors.length > 0
            && ((pickupCoordinates && !pickupGeocoded) || (dropoffCoordinates && !dropoffGeocoded));
        status.textContent = usedStoredCoordinates
            ? `${routeStatus} Um endereço usou as coordenadas já salvas no pedido.`
            : geocodingErrors.length
                ? `${routeStatus} Não foi possível consultar um dos endereços.`
                : routeStatus;
    }

    function removeRealtimeChannel(channel) {
        if (!channel || !app.client) return;
        app.client.removeChannel(channel).then(status => {
            if (status !== 'ok') console.error('Não foi possível encerrar o canal Realtime.', status);
        }).catch(error => console.error('Não foi possível encerrar o canal Realtime.', error));
    }

    function stopCourierLocationTracking() {
        if (courierLocationWatchId !== null && navigator.geolocation) {
            navigator.geolocation.clearWatch(courierLocationWatchId);
        }
        courierLocationWatchId = null;
        courierTrackingOrderId = null;
        courierLocationSyncUnavailableOrderId = null;
        courierLocationLastSentAt = 0;
    }

    function stopClientLocationTracking() {
        removeRealtimeChannel(clientLocationChannel);
        clientLocationChannel = null;
        clientTrackingOrderId = null;
        clientTrackingVehicleType = null;
        clientLocationUpdatedAt = 0;
        if (clientCourierMarker && typeof mapa !== 'undefined' && mapa) mapa.removeLayer(clientCourierMarker);
        clientCourierMarker = null;
        setClientTrackingStatus('Quando um entregador aceitar sua entrega, acompanhe a localização em tempo real.');
    }

    function setClientTrackingStatus(message, isError) {
        const status = document.getElementById('client-tracking-status');
        if (!status) return;
        status.className = `text-xs mt-2 ${isError ? 'text-rose-700' : 'text-slate-500'}`;
        status.textContent = message;
    }

    function isCourierLocationTableUnavailable(error) {
        return error?.code === 'PGRST205'
            || error?.code === '42P01'
            || /could not find the table.*courier_locations|relation .*courier_locations.* does not exist/i.test(error?.message || '');
    }

    function createCourierMarkerIcon(vehicleType) {
        const iconHtml = vehicleType === 'bicycle'
            ? '<i class="fa-solid fa-bicycle" aria-label="Entregador em bicicleta" style="font-size:26px;line-height:44px;color:#0c4a6e"></i>'
            : '<svg width="44" height="44" viewBox="0 0 64 64" aria-label="Entregador em motocicleta"><use href="#duck-moto-icon"></use></svg>';
        return window.L.divIcon({
            className: 'duck-moto-marker',
            html: iconHtml,
            iconSize: [48, 48],
            iconAnchor: [24, 24]
        });
    }

    function moveMarkerSmoothly(marker, coordinates) {
        const previousAnimation = markerAnimations.get(marker);
        if (previousAnimation) window.cancelAnimationFrame(previousAnimation.frameId);

        const start = marker.getLatLng();
        const startedAt = performance.now();
        const duration = 700;
        const animation = { frameId: 0 };
        markerAnimations.set(marker, animation);

        function animate(now) {
            const progress = Math.min((now - startedAt) / duration, 1);
            const easedProgress = progress * (2 - progress);
            marker.setLatLng([
                start.lat + (coordinates[0] - start.lat) * easedProgress,
                start.lng + (coordinates[1] - start.lng) * easedProgress
            ]);
            if (progress < 1) animation.frameId = window.requestAnimationFrame(animate);
            else markerAnimations.delete(marker);
        }

        animation.frameId = window.requestAnimationFrame(animate);
    }

    function updateCourierMapLocation(coordinates, centerMap = false) {
        if (!courierMap) return;
        if (!courierLocationMarker) {
            courierLocationMarker = window.L.marker(coordinates, { icon: createCourierMarkerIcon(app.courier?.vehicle_type), zIndexOffset: 1000 })
                .addTo(courierMap)
                .bindPopup('Sua localização atual');
        } else if (centerMap) {
            courierLocationMarker.setLatLng(coordinates);
        } else {
            moveMarkerSmoothly(courierLocationMarker, coordinates);
        }
        if (centerMap && !courierPickupMarker && !courierDropoffMarker) courierMap.setView(coordinates, 16);
        else if (!courierRouteLine) courierMap.panTo(coordinates, { animate: true, duration: 0.5 });
    }

    function isCourierGeolocationSecure() {
        return window.location.protocol !== 'file:' && window.isSecureContext !== false;
    }

    function requestCourierCurrentLocation() {
        if (!courierMap) return;
        if (!navigator.geolocation || !isCourierGeolocationSecure()) {
            if (!courierPickupMarker && !courierDropoffMarker) courierMap.setView(COURIER_DEFAULT_MAP_CENTER, 13);
            setCourierTrackingStatus(
                window.location.protocol === 'file:'
                    ? 'Para localizar você, abra o sistema por HTTPS ou localhost e permita o acesso à localização. O mapa está usando a região padrão.'
                    : 'Permita o acesso à localização em um navegador compatível com HTTPS. O mapa está usando a região padrão.',
                true
            );
            return;
        }
        if (Date.now() - courierLocationRequestedAt < 15000) return;
        if (courierLocationRequestPromise) return courierLocationRequestPromise;

        courierLocationRequestedAt = Date.now();
        setCourierTrackingStatus('Obtendo sua localização atual…');
        courierLocationRequestPromise = new Promise(resolve => {
            const useDefaultCenter = message => {
                if (!courierPickupMarker && !courierDropoffMarker) courierMap.setView(COURIER_DEFAULT_MAP_CENTER, 13);
                if (courierLocationMarker) courierMap.removeLayer(courierLocationMarker);
                courierLocationMarker = null;
                setCourierTrackingStatus(`${message} O mapa está usando a região padrão.`, true);
                resolve();
            };
            try {
                navigator.geolocation.getCurrentPosition(position => {
                    const coordinates = [position.coords.latitude, position.coords.longitude];
                    updateCourierMapLocation(coordinates, true);
                    setCourierTrackingStatus('Sua localização atual foi identificada e o mapa foi centralizado.');
                    resolve();
                }, error => {
                    const messages = {
                        1: 'A permissão de localização foi negada. Autorize o acesso ao GPS para mostrar sua posição.',
                        2: 'Não foi possível determinar sua localização. Verifique o sinal do GPS.',
                        3: 'A localização demorou para responder. Verifique o GPS e tente novamente.'
                    };
                    useDefaultCenter(messages[error.code] || 'Não foi possível obter sua localização.');
                }, {
                    enableHighAccuracy: true,
                    maximumAge: 5000,
                    timeout: 15000
                });
            } catch (error) {
                console.error('Não foi possível solicitar a localização atual do entregador.', error);
                useDefaultCenter('Não foi possível acessar a localização. Verifique a permissão do navegador.');
            }
        }).finally(() => {
            courierLocationRequestPromise = null;
        });
        return courierLocationRequestPromise;
    }

    function setCourierTrackingStatus(message, isError) {
        const status = document.getElementById('courier-map-status');
        if (!status) return;
        status.className = `text-sm mb-4 ${isError ? 'text-rose-700' : 'text-slate-500'}`;
        status.textContent = message;
    }

    function isCourierLocationRpcUnavailable(error) {
        return error?.code === 'PGRST202'
            || /could not find (the )?function.*update_courier_location|update_courier_location.*schema cache/i.test(error?.message || '');
    }

    async function publishCourierLocation(orderId, coordinates) {
        const { error } = await app.client.rpc('update_courier_location', {
            p_order_id: orderId,
            p_latitude: coordinates.latitude,
            p_longitude: coordinates.longitude,
            p_accuracy_m: Number.isFinite(coordinates.accuracy) ? coordinates.accuracy : null,
            p_heading: Number.isFinite(coordinates.heading) ? coordinates.heading : null,
            p_speed_mps: Number.isFinite(coordinates.speed) ? coordinates.speed : null
        });
        if (error) throw error;
    }

    function startCourierLocationTracking(order) {
        if (!app.user || app.profile?.role !== 'courier' || order.courier_id !== app.user.id
            || !ACTIVE_STATUSES.includes(order.status)) {
            stopCourierLocationTracking();
            return;
        }
        if (courierTrackingOrderId === order.id && courierLocationWatchId !== null) return;

        stopCourierLocationTracking();
        courierTrackingOrderId = order.id;
        if (!navigator.geolocation || !isCourierGeolocationSecure()) {
            setCourierTrackingStatus(
                window.location.protocol === 'file:'
                    ? 'Abra o sistema por HTTPS ou localhost e permita o acesso à localização para compartilhar o GPS.'
                    : 'Este navegador não disponibiliza geolocalização segura. Use HTTPS e permita o acesso ao GPS.',
                true
            );
            return;
        }

        setCourierTrackingStatus('Aguardando permissão e sinal do GPS para compartilhar sua localização…');
        try {
            courierLocationWatchId = navigator.geolocation.watchPosition(position => {
                if (courierTrackingOrderId !== order.id) return;
                const coordinates = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                    accuracy: position.coords.accuracy,
                    heading: position.coords.heading,
                    speed: position.coords.speed
                };
                updateCourierMapLocation([coordinates.latitude, coordinates.longitude]);
                const precision = Number.isFinite(coordinates.accuracy)
                    ? ` · precisão ±${Math.round(coordinates.accuracy)} m`
                    : '';
                setCourierTrackingStatus(`GPS ativo · compartilhando localização${precision}. Mantenha esta tela aberta.`);

                const now = Date.now();
                if (courierLocationSyncUnavailableOrderId === order.id || now - courierLocationLastSentAt < 3000) return;
                courierLocationLastSentAt = now;
                publishCourierLocation(order.id, coordinates).catch(error => {
                    if (courierTrackingOrderId !== order.id) return;
                    if (isCourierLocationRpcUnavailable(error)) {
                        courierLocationSyncUnavailableOrderId = order.id;
                        setCourierTrackingStatus('O GPS está ativo neste aparelho, mas a sincronização ainda não foi configurada no Supabase. Execute o bloco de localização do arquivo supabase-setup.sql no SQL Editor e atualize a página.', true);
                        console.error('A função update_courier_location não está disponível no Supabase.', error);
                        return;
                    }
                    setCourierTrackingStatus('GPS ativo, mas não foi possível sincronizar a posição com o cliente.', true);
                    fail(error, 'Não foi possível sincronizar a localização do entregador');
                });
            }, error => {
                const reasons = {
                    1: 'Permissão de localização negada. Autorize o GPS nas configurações do navegador.',
                    2: 'Não foi possível determinar sua posição. Verifique o sinal do GPS.',
                    3: 'A solicitação de localização expirou. Verifique o GPS e mantenha esta tela aberta.'
                };
                setCourierTrackingStatus(reasons[error.code] || `Erro de geolocalização: ${error.message}`, true);
            }, {
                enableHighAccuracy: true,
                maximumAge: 5000,
                timeout: 15000
            });
        } catch (error) {
            courierLocationWatchId = null;
            setCourierTrackingStatus('Não foi possível iniciar o GPS. Verifique a permissão de localização do navegador.', true);
            fail(error, 'Não foi possível iniciar o GPS do entregador');
        }
    }

    function applyClientCourierLocation(location) {
        if (!location || location.order_id !== clientTrackingOrderId) return;
        const timestamp = Date.parse(location.updated_at);
        if (Number.isFinite(timestamp) && timestamp < clientLocationUpdatedAt) return;
        if (Number.isFinite(timestamp)) clientLocationUpdatedAt = timestamp;

        const coordinates = [Number(location.latitude), Number(location.longitude)];
        if (!coordinates.every(Number.isFinite) || typeof mapa === 'undefined' || !mapa) return;
        if (!clientCourierMarker) {
            clientCourierMarker = window.L.marker(coordinates, { icon: createCourierMarkerIcon(clientTrackingVehicleType), zIndexOffset: 1000 })
                .addTo(mapa)
                .bindPopup('Entregador em tempo real');
        } else {
            moveMarkerSmoothly(clientCourierMarker, coordinates);
        }
        mapa.panTo(coordinates, { animate: true, duration: 0.5 });
        const updatedAt = Number.isFinite(timestamp) ? new Date(timestamp).toLocaleTimeString('pt-BR') : 'agora';
        setClientTrackingStatus(`Entregador localizado · última atualização às ${updatedAt}.`);
    }

    async function startClientLocationTracking(order) {
        if (clientTrackingOrderId === order.id) return;
        stopClientLocationTracking();
        clientTrackingOrderId = order.id;
        clientTrackingVehicleType = order.vehicle_type;
        setClientTrackingStatus('Entrega aceita. Aguardando a primeira localização do entregador…');

        clientLocationChannel = app.client.channel(`client-location-${order.id}`)
            .on('postgres_changes', {
                event: '*',
                schema: 'public',
                table: 'courier_locations',
                filter: `order_id=eq.${order.id}`
            }, payload => applyClientCourierLocation(payload.new))
            .subscribe((status, error) => {
                if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
                    setClientTrackingStatus('A localização ainda não está disponível. O acompanhamento será atualizado quando o GPS do entregador estiver conectado.', false);
                    if (error) console.error('Falha no canal Realtime da localização do entregador.', error);
                }
            });

        const { data, error } = await app.client.from('courier_locations')
            .select('order_id, latitude, longitude, updated_at')
            .eq('order_id', order.id)
            .maybeSingle();
        if (error && clientTrackingOrderId === order.id) {
            if (isCourierLocationTableUnavailable(error)) {
                console.error('A tabela courier_locations ainda não está disponível no Supabase.', error);
                setClientTrackingStatus('O rastreamento de localização ainda não foi configurado no banco. Execute a seção de localização do arquivo supabase-setup.sql no SQL Editor do Supabase.', false);
                return;
            }
            throw error;
        }
        if (data) {
            applyClientCourierLocation(data);
        } else if (clientTrackingOrderId === order.id && !clientCourierMarker) {
            setClientTrackingStatus('Entregador conectado à entrega. Aguardando a primeira atualização do GPS…', false);
        }
    }

    function subscribeClientOrderUpdates() {
        if (!app.user || app.profile?.role !== 'client') return;
        removeRealtimeChannel(clientOrdersChannel);
        const clientId = app.user.id;
        clientOrdersChannel = app.client.channel(`client-orders-${clientId}`)
            .on('postgres_changes', {
                event: 'UPDATE',
                schema: 'public',
                table: 'delivery_orders',
                filter: `client_id=eq.${clientId}`
            }, () => {
                if (clientOrdersRefreshTimer) clearTimeout(clientOrdersRefreshTimer);
                clientOrdersRefreshTimer = setTimeout(() => {
                    carregarPedidosCliente().catch(error => fail(error, 'Erro ao atualizar pedidos em tempo real'));
                }, 250);
            })
            .subscribe((status, error) => {
                if ((status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') && error) {
                    console.error('Falha no canal Realtime dos pedidos do cliente.', error);
                    setClientTrackingStatus('A conexão em tempo real dos pedidos falhou. Atualize a página para tentar novamente.', true);
                }
            });
    }

    async function acompanharPedidoCliente(orderId) {
        const order = app.orders.find(item => item.id === orderId);
        if (!order) {
            showMessage('Não foi possível localizar este pedido na lista.', 'error');
            return;
        }
        if (!order.courier_id || !ACTIVE_STATUSES.includes(order.status)) {
            setClientTrackingStatus('O acompanhamento ficará disponível quando um entregador aceitar esta entrega.');
            return;
        }
        await startClientLocationTracking(order);
    }

    function openAuthModal(mode) {
        definirModoAuth(mode || 'login');
        document.getElementById('modal-auth').classList.remove('hidden');
    }

    function atualizarEstadoAceiteTermos() {
        const signup = app.authMode === 'signup';
        const termsField = document.getElementById('auth-terms-field');
        const checkbox = document.getElementById('auth-terms-accepted');
        const accepted = checkbox.checked;
        const error = document.getElementById('auth-terms-error');
        termsField.classList.toggle('hidden', !signup);
        checkbox.required = signup;
        document.getElementById('auth-submit').disabled = signup && !accepted;
        if (accepted) error.classList.add('hidden');
    }

    function openLegalDocument(type, trigger) {
        const isTerms = type === 'terms';
        document.getElementById('legal-document-title').textContent = isTerms ? 'Termos de Uso' : 'Política de Privacidade';
        document.getElementById('legal-terms-content').classList.toggle('hidden', !isTerms);
        document.getElementById('legal-privacy-content').classList.toggle('hidden', isTerms);
        legalModalTrigger = trigger || document.activeElement;
        const modal = document.getElementById('legal-document-modal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.getElementById('legal-document-close').focus();
    }

    function closeLegalDocument() {
        const modal = document.getElementById('legal-document-modal');
        modal.classList.remove('flex');
        modal.classList.add('hidden');
        legalModalTrigger?.focus();
        legalModalTrigger = null;
    }

    function openAuthForRole(role) {
        document.getElementById('auth-perfil').value = role === 'courier' ? 'courier' : 'client';
        openAuthModal('login');
    }

    function startCourierSignup() {
        document.getElementById('auth-perfil').value = 'courier';
        openAuthModal('signup');
        atualizarCamposCadastroAuth();
    }

    function closeAuthModal() {
        const cancelRecoverySession = app.passwordRecovery.verified;
        resetPasswordRecovery();
        document.getElementById('modal-auth').classList.add('hidden');
        if (cancelRecoverySession && app.client) {
            app.client.auth.signOut()
                .then(({ error }) => {
                    if (error) fail(error, 'Não foi possível cancelar a recuperação de senha');
                })
                .catch(error => fail(error, 'Não foi possível cancelar a recuperação de senha'));
        }
    }

    function definirModoAuth(mode) {
        app.authMode = mode === 'signup' ? 'signup' : 'login';
        const signup = app.authMode === 'signup';
        resetPasswordRecovery();
        document.getElementById('auth-flow-message').classList.add('hidden');
        document.getElementById('auth-terms-accepted').checked = false;
        document.getElementById('auth-terms-error').classList.add('hidden');
        document.getElementById('auth-form').classList.remove('hidden');
        document.getElementById('auth-title').textContent = signup ? 'Criar conta Duck Delivery' : 'Acessar conta';
        document.getElementById('auth-mode-login').className = `px-3 py-1.5 rounded-lg text-sm font-semibold ${signup ? 'text-slate-500' : 'bg-brand-50 text-brand-700'}`;
        document.getElementById('auth-mode-signup').className = `px-3 py-1.5 rounded-lg text-sm font-semibold ${signup ? 'bg-brand-50 text-brand-700' : 'text-slate-500'}`;
        document.getElementById('auth-mode-login').classList.remove('hidden');
        document.getElementById('auth-mode-signup').classList.remove('hidden');
        document.getElementById('auth-name-field').classList.toggle('hidden', !signup);
        document.getElementById('auth-phone-field').classList.toggle('hidden', !signup);
        document.getElementById('auth-role-field').classList.remove('hidden');
        document.querySelector('#auth-role-field label').textContent = signup ? 'Tipo de cadastro' : 'Entrar como';
        document.getElementById('auth-password').autocomplete = signup ? 'new-password' : 'current-password';
        document.getElementById('auth-password').minLength = signup ? 8 : 1;
        document.getElementById('auth-nome').required = signup;
        document.getElementById('auth-telefone').required = signup;
        document.getElementById('auth-submit').textContent = signup ? 'Criar conta' : 'Entrar no Duck Delivery';
        document.getElementById('auth-forgot-password').classList.toggle('hidden', signup);
        atualizarEstadoAceiteTermos();
        atualizarCamposCadastroAuth();
    }

    function resetPasswordRecovery() {
        app.passwordRecovery.email = '';
        app.passwordRecovery.verified = false;
        const recoveryPanel = document.getElementById('auth-recovery-panel');
        if (recoveryPanel) recoveryPanel.classList.add('hidden');
        const recoveryMessage = document.getElementById('auth-recovery-message');
        if (recoveryMessage) recoveryMessage.classList.add('hidden');
        ['auth-recovery-email', 'auth-recovery-code', 'auth-recovery-new-password', 'auth-recovery-confirm-password']
            .forEach(id => {
                const field = document.getElementById(id);
                if (field) field.value = '';
            });
        ['auth-recovery-code-step', 'auth-recovery-password-step']
            .forEach(id => {
                const step = document.getElementById(id);
                if (step) step.classList.add('hidden');
            });
        const emailForm = document.getElementById('auth-recovery-email-form');
        if (emailForm) emailForm.classList.remove('hidden');
    }

    function mostrarMensagemRecuperacao(message, type) {
        const element = document.getElementById('auth-recovery-message');
        element.className = `mb-4 rounded-xl px-4 py-3 text-sm ${type === 'error' ? 'bg-rose-50 text-rose-800 border border-rose-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'}`;
        element.textContent = message;
        element.classList.remove('hidden');
    }

    function abrirRecuperacaoSenha() {
        hideMessage();
        resetPasswordRecovery();
        const email = document.getElementById('auth-email').value.trim().toLowerCase();
        document.getElementById('auth-recovery-email').value = email;
        document.getElementById('auth-form').classList.add('hidden');
        document.getElementById('auth-mode-login').classList.add('hidden');
        document.getElementById('auth-mode-signup').classList.add('hidden');
        document.getElementById('auth-title').textContent = 'Recuperar senha';
        document.getElementById('auth-recovery-panel').classList.remove('hidden');
    }

    async function voltarAoLogin() {
        if (app.passwordRecovery.verified) {
            const { error } = await app.client.auth.signOut();
            if (error) throw error;
        }
        resetPasswordRecovery();
        definirModoAuth('login');
    }

    async function enviarCodigoRecuperacao() {
        const emailField = document.getElementById('auth-recovery-email');
        const email = emailField.value.trim().toLowerCase();
        if (!emailField.checkValidity()) {
            emailField.reportValidity();
            return;
        }

        const { error } = await app.client.auth.resetPasswordForEmail(email);
        if (error) throw error;

        app.passwordRecovery.email = email;
        document.getElementById('auth-recovery-email-form').classList.add('hidden');
        document.getElementById('auth-recovery-code-step').classList.remove('hidden');
        document.getElementById('auth-title').textContent = 'Verificar identidade';
        mostrarMensagemRecuperacao('Se este e-mail estiver cadastrado, enviaremos um código de recuperação.', 'success');
    }

    async function verificarCodigoRecuperacao() {
        const code = document.getElementById('auth-recovery-code').value.trim();
        if (!/^\d{6}$/.test(code)) {
            mostrarMensagemRecuperacao('Informe o código de 6 dígitos recebido por e-mail.', 'error');
            return;
        }

        const { data, error } = await app.client.auth.verifyOtp({
            email: app.passwordRecovery.email,
            token: code,
            type: 'recovery'
        });
        if (error) throw error;
        if (!data.session || data.user?.email?.toLowerCase() !== app.passwordRecovery.email) {
            throw new Error('Não foi possível confirmar o código para este e-mail.');
        }

        app.passwordRecovery.verified = true;
        document.getElementById('auth-recovery-code-step').classList.add('hidden');
        document.getElementById('auth-recovery-password-step').classList.remove('hidden');
        document.getElementById('auth-title').textContent = 'Criar nova senha';
        mostrarMensagemRecuperacao('Código validado. Agora escolha sua nova senha.', 'success');
    }

    async function salvarNovaSenha() {
        if (!app.passwordRecovery.verified) {
            throw new Error('Valide o código enviado por e-mail antes de criar uma nova senha.');
        }

        const password = document.getElementById('auth-recovery-new-password').value;
        const confirmation = document.getElementById('auth-recovery-confirm-password').value;
        if (password.length < 8) {
            mostrarMensagemRecuperacao('A nova senha deve ter pelo menos 8 caracteres.', 'error');
            return;
        }
        if (password !== confirmation) {
            mostrarMensagemRecuperacao('As senhas informadas não coincidem.', 'error');
            return;
        }

        const { error } = await app.client.auth.updateUser({ password });
        if (error) throw error;

        resetPasswordRecovery();
        document.getElementById('modal-auth').classList.add('hidden');
        showMessage('Senha alterada com sucesso. Você já está conectado.', 'success');
    }

    function executarAcaoRecuperacao(action, context) {
        return async event => {
            event.preventDefault();
            document.getElementById('auth-recovery-message').classList.add('hidden');
            try {
                await action();
            } catch (error) {
                console.error(context, error);
                mostrarMensagemRecuperacao(`${context}: ${error.message || 'erro inesperado'}`, 'error');
            }
        };
    }

    function atualizarCamposCadastroAuth() {
        document.getElementById('auth-flow-message').classList.add('hidden');
        atualizarEstadoAceiteTermos();
        const courier = app.authMode === 'signup' && document.getElementById('auth-perfil').value === 'courier';
        const motorcycle = document.getElementById('auth-vehicle-type').value === 'motorcycle';
        document.getElementById('auth-courier-fields').classList.toggle('hidden', !courier);
        document.getElementById('auth-motorcycle-fields').classList.toggle('hidden', !motorcycle);
        document.getElementById('auth-plate').required = courier && motorcycle;
        document.getElementById('auth-vehicle-info').required = courier && motorcycle;
        document.getElementById('auth-pix-type').required = courier;
        document.getElementById('auth-pix-key').required = courier;
        document.getElementById('auth-documents').required = false;
    }

    async function enviarFormularioAuth() {
        hideMessage();
        const email = document.getElementById('auth-email').value.trim().toLowerCase();
        const password = document.getElementById('auth-password').value;
        if (app.authMode === 'signup' && !document.getElementById('auth-terms-accepted').checked) {
            const error = document.getElementById('auth-terms-error');
            error.textContent = 'Aceite os Termos de Uso e a Política de Privacidade para criar sua conta.';
            error.classList.remove('hidden');
            document.getElementById('auth-terms-accepted').focus();
            return;
        }
        try {
            if (app.authMode === 'signup') {
                const role = document.getElementById('auth-perfil').value;
                const vehicleType = document.getElementById('auth-vehicle-type').value;
                const signupOptions = {
                    data: {
                        full_name: document.getElementById('auth-nome').value.trim(),
                        phone: document.getElementById('auth-telefone').value.trim(),
                        role,
                        vehicle_type: vehicleType,
                        plate: vehicleType === 'motorcycle' ? document.getElementById('auth-plate').value.trim().toUpperCase() : '',
                        vehicle_info: vehicleType === 'motorcycle' ? document.getElementById('auth-vehicle-info').value.trim() : '',
                        pix_type: role === 'courier' ? document.getElementById('auth-pix-type').value : '',
                        pix_key: role === 'courier' ? document.getElementById('auth-pix-key').value.trim() : ''
                    }
                };
                if (window.location.protocol !== 'file:') signupOptions.emailRedirectTo = window.location.href;
                const { data, error } = await app.client.auth.signUp({
                    email,
                    password,
                    options: signupOptions
                });
                if (error) throw error;
                if (!data.user) {
                    throw new Error('O Supabase não retornou os dados da conta criada.');
                }
                if (Array.isArray(data.user.identities) && data.user.identities.length === 0) {
                    closeAuthModal();
                    showMessage('Já existe uma conta com este e-mail. Entre com sua senha ou use “Esqueci minha senha”.', 'error');
                    return;
                }
                if (data.session && role === 'courier') {
                    await applySession(data.session);
                    const files = document.getElementById('auth-documents').files;
                    if (files.length) await uploadCourierDocuments(files);
                } else if (data.session) {
                    await applySession(data.session);
                }
                if (data.session) {
                    const { error: signOutError } = await app.client.auth.signOut();
                    if (signOutError) throw signOutError;
                    await applySession(null);
                    document.getElementById('auth-email').value = email;
                    definirModoAuth('login');
                    document.getElementById('auth-flow-message').textContent = 'Cadastro concluído. Entre com seu e-mail e senha para continuar.';
                    document.getElementById('auth-flow-message').classList.remove('hidden');
                    return;
                }
                if (role === 'courier') {
                    closeAuthModal();
                    showMessage('Conta criada. Confirme o e-mail e entre para enviar os documentos e acompanhar a análise do cadastro.', 'success');
                    return;
                }
                closeAuthModal();
                showMessage('Conta criada. Confirme o endereço de e-mail para entrar.', 'success');
                return;
            }

            const { data, error } = await app.client.auth.signInWithPassword({ email, password });
            if (error) throw error;
            await applySession(data.session);
            const requestedRole = document.getElementById('auth-perfil').value;
            if (!roleIsAdmin() && app.profile?.role !== requestedRole) {
                const actualRole = app.profile?.role === 'courier' ? 'Entregador' : 'Cliente';
                await app.client.auth.signOut();
                await applySession(null);
                document.getElementById('auth-email').value = email;
                document.getElementById('auth-flow-message').textContent = `Esta conta está cadastrada como ${actualRole}. Selecione esse perfil para entrar.`;
                document.getElementById('auth-flow-message').classList.remove('hidden');
                return;
            }
            closeAuthModal();
            switchTab(roleIsAdmin() ? 'admin' : app.profile?.role === 'courier' ? 'entregador' : 'cliente');
            showMessage('Acesso realizado com sucesso.', 'success');
        } catch (error) {
            fail(error, 'Não foi possível concluir o acesso');
        }
    }

    async function handleAuthButton() {
        if (!app.user) {
            openAuthModal('login');
            return;
        }
        const { error } = await app.client.auth.signOut();
        if (error) {
            fail(error, 'Não foi possível sair da conta');
            return;
        }
        await applySession(null);
        switchTab('cliente');
        showMessage('Você saiu da sua conta.', 'success');
    }

    async function switchTab(tab) {
        hideMessage();
        if ((tab === 'cliente' || tab === 'entregador') && !app.user) {
            openAuthForRole(tab === 'entregador' ? 'courier' : 'client');
            return;
        }
        if (tab === 'cliente' && roleIsAdmin()) {
            showMessage('Administradores devem usar o painel administrativo.', 'error');
            return;
        }
        if (tab === 'entregador' && roleIsAdmin()) {
            showMessage('Administradores não podem usar as funções de entregador.', 'error');
            return;
        }
        if (tab === 'cliente' && app.profile?.role === 'courier') {
            showMessage('Esta conta está cadastrada como entregador.', 'error');
            return;
        }
        if (tab === 'entregador' && app.profile?.role === 'client') {
            showMessage('Esta conta está cadastrada como cliente.', 'error');
            return;
        }
        if (tab === 'admin' && !roleIsAdmin()) {
            showMessage('Acesso restrito à administração.', 'error');
            return;
        }

        ['cliente', 'entregador', 'admin'].forEach(view => {
            document.getElementById(`view-${view}`).classList.toggle('hidden', view !== tab);
            const desktopButton = document.getElementById(`nav-${view}`);
            if (desktopButton && !desktopButton.classList.contains('hidden')) {
                desktopButton.className = `px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${view === tab ? 'text-white bg-brand-500 shadow' : 'text-slate-300 hover:text-white'}`;
            }
        });
        if (tab === 'cliente') setTimeout(() => mapa?.invalidateSize(), 200);
        if (tab === 'entregador') {
            if (app.profile?.role === 'courier') await carregarPainelEntregador();
            else clearCourierDashboard();
        }
        if (tab === 'admin') await carregarDashboardAdmin();
    }

    async function carregarPedidosCliente() {
        const tbody = document.getElementById('lista-pedidos-cliente');
        tbody.innerHTML = '';
        if (!app.user || app.profile?.role !== 'client' || roleIsAdmin()) return;

        const { data, error } = await app.client.from('delivery_orders').select('*').order('created_at', { ascending: false }).limit(50);
        if (error) throw error;
        app.orders = data || [];
        const ratedIds = new Set();
        const { data: ratings, error: ratingError } = await app.client.from('courier_ratings').select('order_id');
        if (ratingError) throw ratingError;
        (ratings || []).forEach(rating => ratedIds.add(rating.order_id));

        app.orders.forEach(order => {
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-slate-50 transition';
            const code = order.id.slice(0, 8).toUpperCase();
            const canRate = order.status === 'delivered' && order.courier_id && !ratedIds.has(order.id);
            const canTrack = Boolean(order.courier_id && ACTIVE_STATUSES.includes(order.status));
            tr.innerHTML = `
                <td class="py-3 px-4 font-bold text-brand-600">${escapeHtml(code)}</td>
                <td class="py-3 px-4"><p class="font-medium text-slate-800">${escapeHtml(order.pickup_address)}</p><p class="text-xs text-slate-400">↳ ${escapeHtml(order.dropoff_address)}</p></td>
                <td class="py-3 px-4 capitalize">${order.vehicle_type === 'motorcycle' ? 'Motocicleta' : 'Bicicleta'}</td>
                <td class="py-3 px-4 font-bold text-slate-900">${money(order.total_amount)}</td>
                <td class="py-3 px-4">${escapeHtml(STATUS_LABELS[order.status] || order.status)}</td>
                <td class="py-3 px-4 text-right">${canTrack ? `<button data-track-id="${escapeHtml(order.id)}" class="text-xs text-emerald-700 hover:underline">Acompanhar</button>` : order.status === 'pending' ? `<button data-cancel-id="${escapeHtml(order.id)}" class="text-xs text-rose-500 hover:underline">Cancelar</button>` : canRate ? `<button data-rate-id="${escapeHtml(order.id)}" class="text-xs text-brand-600 hover:underline">Avaliar entregador</button>` : '—'}</td>
            `;
            tbody.appendChild(tr);
        });
        tbody.querySelectorAll('[data-cancel-id]').forEach(button => button.addEventListener('click', () => cancelarPedido(button.dataset.cancelId)));
        tbody.querySelectorAll('[data-rate-id]').forEach(button => button.addEventListener('click', () => avaliarEntregador(button.dataset.rateId)));
        tbody.querySelectorAll('[data-track-id]').forEach(button => button.addEventListener('click', () => {
            acompanharPedidoCliente(button.dataset.trackId).catch(error => fail(error, 'Não foi possível acompanhar a entrega'));
        }));

        const activeOrders = app.orders.filter(order => order.courier_id && ACTIVE_STATUSES.includes(order.status));
        const orderToTrack = activeOrders.find(order => order.id === clientTrackingOrderId) || activeOrders[0];
        if (orderToTrack) {
            startClientLocationTracking(orderToTrack).catch(error => fail(error, 'Não foi possível carregar a localização do entregador'));
        } else {
            stopClientLocationTracking();
        }
    }

    async function criarPedido() {
        if (!app.user || app.profile?.role !== 'client' || roleIsAdmin()) {
            showMessage('Entre em uma conta de cliente para solicitar uma entrega.', 'error');
            openAuthModal('login');
            return;
        }
        const form = document.getElementById('form-pedido');
        if (!form.reportValidity()) return;

        try {
            await buscarEAtualizarRota();
            const distance = Number(document.getElementById('distancia-simulated').value);
            const vehicle = app.selectedVehicle;
            const payload = {
                client_id: app.user.id,
                pickup_address: document.getElementById('origem').value.trim(),
                dropoff_address: document.getElementById('destino').value.trim(),
                description: document.getElementById('descricao').value.trim(),
                notes: document.getElementById('observacoes').value.trim(),
                vehicle_type: vehicle,
                distance_km: distance,
                pickup_latitude: coordsOrigem?.[0] ?? null,
                pickup_longitude: coordsOrigem?.[1] ?? null,
                dropoff_latitude: coordsDestino?.[0] ?? null,
                dropoff_longitude: coordsDestino?.[1] ?? null
            };
            const { data, error } = await app.client.from('delivery_orders').insert(payload).select().single();
            if (error) throw error;
            form.reset();
            if (typeof window.selecionarVeiculo === 'function') window.selecionarVeiculo('moto');
            await carregarPedidosCliente();
            showMessage(`Solicitação ${data.id.slice(0, 8).toUpperCase()} criada. O valor final foi calculado pelo sistema.`, 'success');
        } catch (error) {
            fail(error, 'Não foi possível criar o pedido');
        }
    }

    async function cancelarPedido(id) {
        if (!confirm('Deseja cancelar este pedido?')) return;
        const { error } = await app.client.rpc('cancel_delivery', { p_order_id: id });
        if (error) {
            fail(error, 'Não foi possível cancelar o pedido');
            return;
        }
        await carregarPedidosCliente();
        showMessage('Pedido cancelado.', 'success');
    }

    async function avaliarEntregador(orderId) {
        const stars = Number(prompt('Qual nota de 1 a 5 você dá para a entrega?'));
        if (!Number.isInteger(stars) || stars < 1 || stars > 5) {
            showMessage('A avaliação deve ser uma nota inteira entre 1 e 5.', 'error');
            return;
        }
        const comment = prompt('Comentário (opcional):') || '';
        const order = app.orders.find(item => item.id === orderId);
        if (!order?.courier_id) return;
        const { error } = await app.client.from('courier_ratings').insert({
            order_id: orderId,
            client_id: app.user.id,
            courier_id: order.courier_id,
            stars,
            comment: comment.trim().slice(0, 500)
        });
        if (error) {
            fail(error, 'Não foi possível salvar a avaliação');
            return;
        }
        await carregarPedidosCliente();
        showMessage('Obrigado pela avaliação.', 'success');
    }

    function carregarTarifasNoForm() {
        document.getElementById('cfg-taxa-minima').value = app.settings.minimum_fee;
        document.getElementById('cfg-km-moto').value = app.settings.motorcycle_per_km;
        document.getElementById('cfg-km-bike').value = app.settings.bicycle_per_km;
        document.getElementById('cfg-taxa-adicional').value = app.settings.additional_fee;
        document.getElementById('cfg-comissao-ativa').checked = app.settings.commission_enabled;
        document.getElementById('cfg-taxa-plataforma').value = app.settings.platform_fee_percent;
        document.getElementById('cfg-cancelamento-apos-aceite').checked = app.settings.allow_cancel_after_acceptance;
    }

    function atualizarEstimativa() {
        const distance = Number(document.getElementById('distancia-simulated').value) || 5;
        const bike = app.selectedVehicle === 'bicycle';
        const rate = bike ? app.settings.bicycle_per_km : app.settings.motorcycle_per_km;
        const price = Number(app.settings.minimum_fee) + distance * Number(rate) + Number(app.settings.additional_fee || 0);
        document.getElementById('estimativa-preco').textContent = money(price);
        document.getElementById('estimativa-tempo').textContent = `Tempo est.: ~${Math.round(distance * (bike ? 5 : 3) + 5)} min`;
    }

    async function salvarTarifas() {
        const values = {
            minimum_fee: Number(document.getElementById('cfg-taxa-minima').value),
            motorcycle_per_km: Number(document.getElementById('cfg-km-moto').value),
            bicycle_per_km: Number(document.getElementById('cfg-km-bike').value),
            additional_fee: Number(document.getElementById('cfg-taxa-adicional').value),
            commission_enabled: document.getElementById('cfg-comissao-ativa').checked,
            platform_fee_percent: Number(document.getElementById('cfg-taxa-plataforma').value),
            allow_cancel_after_acceptance: document.getElementById('cfg-cancelamento-apos-aceite').checked
        };
        const { error } = await app.client.from('platform_settings').update(values).eq('id', true);
        if (error) {
            fail(error, 'Não foi possível salvar as tarifas');
            return;
        }
        app.settings = { ...app.settings, ...values };
        atualizarEstimativa();
        showMessage('Tarifas atualizadas.', 'success');
    }

    function statusApproval(status) {
        return { pending: 'Pendente', approved: 'Aprovado', rejected: 'Recusado', suspended: 'Suspenso' }[status] || status;
    }

    function updateVehicleFields() {
        const motorcycle = document.getElementById('courier-vehicle-type').value === 'motorcycle';
        document.getElementById('courier-motorcycle-fields').classList.toggle('hidden', !motorcycle);
        document.getElementById('courier-plate').required = motorcycle;
        document.getElementById('courier-vehicle-info').required = motorcycle;
    }

    async function carregarPainelEntregador() {
        if (app.profile?.role !== 'courier') return;
        document.getElementById('courier-registration-required').classList.add('hidden');
        document.getElementById('courier-dashboard').classList.remove('hidden');
        await loadCourierProfile();
        if (!app.courier) throw new Error('Cadastro de entregador não encontrado.');

        const approved = app.courier.approval_status === 'approved';
        const statusText = statusApproval(app.courier.approval_status);
        const statusClass = approved ? 'text-emerald-700 bg-emerald-50' : app.courier.approval_status === 'rejected' ? 'text-rose-700 bg-rose-50' : 'text-amber-800 bg-amber-50';
        document.getElementById('courier-status-card').innerHTML = `
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div><h2 class="text-xl font-bold text-dark-900">Painel do entregador</h2>
                <p class="text-sm text-slate-600 mt-1">Cadastro: <span class="inline-flex px-2 py-0.5 rounded-lg font-semibold ${statusClass}">${statusText}</span></p>
                ${app.courier.rejection_reason ? `<p class="text-sm text-rose-700 mt-2">Motivo: ${escapeHtml(app.courier.rejection_reason)}</p>` : ''}
                ${!approved ? '<p class="text-xs text-slate-500 mt-2">Pedidos reais só ficam disponíveis após aprovação administrativa e envio dos documentos.</p>' : ''}
                </div>
            </div>`;
        document.getElementById('courier-profile-card').classList.toggle('hidden', approved);
        document.getElementById('courier-profile-name').value = app.profile.full_name || '';
        document.getElementById('courier-profile-phone').value = app.profile.phone || '';
        document.getElementById('courier-vehicle-type').value = app.courier.vehicle_type;
        document.getElementById('courier-plate').value = app.courier.plate || '';
        document.getElementById('courier-vehicle-info').value = app.courier.vehicle_info || '';
        const profileLocked = approved;
        ['courier-vehicle-type', 'courier-plate', 'courier-vehicle-info'].forEach(id => {
            document.getElementById(id).disabled = profileLocked;
        });
        document.getElementById('courier-profile-name').disabled = false;
        document.getElementById('courier-profile-phone').disabled = false;
        document.getElementById('courier-documents').disabled = approved;
        document.getElementById('courier-save-profile').disabled = approved;
        document.getElementById('courier-save-profile').classList.toggle('opacity-50', approved);
        document.getElementById('courier-motorcycle-fields').classList.toggle('hidden', app.courier.vehicle_type !== 'motorcycle');
        document.getElementById('courier-plate').required = !profileLocked && app.courier.vehicle_type === 'motorcycle';
        document.getElementById('courier-vehicle-info').required = !profileLocked && app.courier.vehicle_type === 'motorcycle';
        document.getElementById('courier-work-area').classList.remove('hidden');
        const availabilityToggle = document.getElementById('toggle-online');
        availabilityToggle.disabled = !approved;
        availabilityToggle.checked = Boolean(approved && app.courier.is_online);
        document.getElementById('status-online-text').textContent = availabilityToggle.checked ? 'ONLINE' : 'OFFLINE';
        if (!approved) {
            document.getElementById('courier-earnings-pending').textContent = 'R$ 0,00';
            document.getElementById('courier-earnings-paid').textContent = 'R$ 0,00';
            document.getElementById('courier-deliveries-count').textContent = '0';
            document.getElementById('courier-rating-average').textContent = '—';
            document.getElementById('badge-count-disponiveis').textContent = '0';
            document.getElementById('container-pedidos-disponiveis').innerHTML = '<p class="text-sm text-slate-500">Solicitações disponíveis após aprovação do cadastro.</p>';
            setCourierAvailableOrdersVisibility(true);
            setCourierMapVisibility(false);
            document.getElementById('courier-toggle-placeholder')?.remove();
            return;
        }
        await Promise.all([
            carregarPedidosDisponiveisEntregador(),
            carregarEntregaAtivaEntregador(),
            carregarHistoricoEntregador()
        ]);
    }

    async function uploadCourierDocuments(fileList) {
        const files = Array.from(fileList || []);
        if (!files.length) return false;
        if (files.length > 5) throw new Error('Envie no máximo 5 documentos.');
        const allowed = ['application/pdf', 'image/jpeg', 'image/png'];
        const uploaded = [];
        try {
            for (const file of files) {
                if (!allowed.includes(file.type) || file.size > 10 * 1024 * 1024) {
                    throw new Error('Use arquivos PDF, JPG ou PNG de até 10 MB.');
                }
                const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
                const path = `${app.user.id}/${crypto.randomUUID()}-${safeName}`;
                const { error } = await app.client.storage.from(DOCUMENT_BUCKET).upload(path, file, {
                    contentType: file.type,
                    upsert: false
                });
                if (error) throw error;
                uploaded.push(path);
            }
            const { error } = await app.client.rpc('submit_courier_documents', { p_paths: uploaded });
            if (error) throw error;
            return true;
        } catch (error) {
            if (uploaded.length) {
                const { error: cleanupError } = await app.client.storage.from(DOCUMENT_BUCKET).remove(uploaded);
                if (cleanupError) console.error('Não foi possível limpar os documentos enviados parcialmente.', cleanupError);
            }
            throw error;
        }
    }

    async function salvarPerfilEntregador() {
        if (app.profile?.role !== 'courier' || !app.courier) return;
        const profileUpdate = {
            full_name: document.getElementById('courier-profile-name').value.trim(),
            phone: document.getElementById('courier-profile-phone').value.trim()
        };
        try {
            const { error: profileError } = await app.client.from('profiles').update(profileUpdate).eq('id', app.user.id);
            if (profileError) throw profileError;
            const vehicleType = document.getElementById('courier-vehicle-type').value;
            const courierUpdate = {
                vehicle_type: vehicleType,
                plate: vehicleType === 'motorcycle' ? document.getElementById('courier-plate').value.trim().toUpperCase() : null,
                vehicle_info: vehicleType === 'motorcycle' ? document.getElementById('courier-vehicle-info').value.trim() : 'Bicicleta'
            };
            const { error: courierError } = await app.client.from('courier_profiles').update(courierUpdate).eq('user_id', app.user.id);
            if (courierError) throw courierError;

            const files = document.getElementById('courier-documents').files;
            if (files.length) await uploadCourierDocuments(files);
            await carregarPainelEntregador();
            showMessage(files.length ? 'Perfil salvo. Documentos enviados para análise administrativa.' : 'Perfil salvo. Envie os documentos para solicitar a análise.', 'success');
        } catch (error) {
            fail(error, 'Não foi possível salvar o cadastro');
        }
    }

    async function toggleOnlineEntregador(online) {
        if (app.courier?.approval_status !== 'approved') {
            showMessage('Somente entregadores aprovados podem ficar online.', 'error');
            return;
        }
        const { error } = await app.client.rpc('set_courier_online', { p_online: online });
        if (error) {
            fail(error, 'Não foi possível alterar sua disponibilidade');
            await carregarPainelEntregador();
            return;
        }
        app.courier.is_online = online;
        const status = document.getElementById('status-online-text');
        if (status) status.textContent = online ? 'ONLINE' : 'OFFLINE';
        await carregarPedidosDisponiveisEntregador();
    }

    async function carregarPedidosDisponiveisEntregador() {
        const container = document.getElementById('container-pedidos-disponiveis');
        const badge = document.getElementById('badge-count-disponiveis');
        if (!container || !app.user || app.courier?.approval_status !== 'approved') return;
        if (!app.courier.is_online) {
            badge.textContent = '0';
            container.innerHTML = '<p class="text-sm text-slate-500">Fique online para receber solicitações.</p>';
            return;
        }
        const [{ data: orders, error }, { data: responses, error: responseError }] = await Promise.all([
            app.client.from('delivery_orders').select('*').eq('status', 'pending').eq('vehicle_type', app.courier.vehicle_type).order('created_at', { ascending: true }).limit(30),
            app.client.from('courier_order_responses').select('order_id').eq('courier_id', app.user.id).eq('response', 'rejected')
        ]);
        if (error) throw error;
        if (responseError) throw responseError;
        const rejected = new Set((responses || []).map(response => response.order_id));
        const available = (orders || []).filter(order => !rejected.has(order.id));
        badge.textContent = String(available.length);
        if (!available.length) {
            container.innerHTML = '<p class="text-sm text-slate-500">Nenhuma solicitação disponível no momento.</p>';
            return;
        }
        container.innerHTML = available.map(order => `
            <article class="border border-slate-200 rounded-xl p-4 space-y-2">
                <div class="flex justify-between gap-2"><strong class="text-sm text-brand-600">Pedido ${escapeHtml(order.id.slice(0, 8).toUpperCase())}</strong><strong class="text-sm text-emerald-700">${money(order.courier_amount)}</strong></div>
                <p class="text-xs text-slate-600"><strong>Coleta:</strong> ${escapeHtml(order.pickup_address)}</p>
                <p class="text-xs text-slate-600"><strong>Destino:</strong> ${escapeHtml(order.dropoff_address)}</p>
                <p class="text-xs text-slate-600"><strong>Distância estimada:</strong> ${Number(order.distance_km).toLocaleString('pt-BR')} km · ${order.vehicle_type === 'motorcycle' ? 'Motocicleta' : 'Bicicleta'}</p>
                <p class="text-xs text-slate-600"><strong>Produto:</strong> ${escapeHtml(order.description)}</p>
                <div class="flex gap-2 pt-1"><button data-accept-id="${escapeHtml(order.id)}" class="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2 rounded-lg">Aceitar</button><button data-reject-id="${escapeHtml(order.id)}" class="border border-slate-200 text-slate-600 text-xs font-semibold px-4 py-2 rounded-lg">Recusar</button></div>
            </article>
        `).join('');
        container.querySelectorAll('[data-accept-id]').forEach(button => button.addEventListener('click', () => aceitarPedido(button.dataset.acceptId)));
        container.querySelectorAll('[data-reject-id]').forEach(button => button.addEventListener('click', () => recusarPedido(button.dataset.rejectId)));
    }

    async function aceitarPedido(id) {
        const { error } = await app.client.rpc('accept_delivery', { p_order_id: id });
        if (error) {
            fail(error, 'Não foi possível aceitar a solicitação');
            return;
        }
        courierMapEnabled = true;
        setCourierMapVisibility(true);
        await Promise.all([carregarPedidosDisponiveisEntregador(), carregarEntregaAtivaEntregador()]);
        showMessage('Entrega aceita. Inicie a coleta quando estiver a caminho.', 'success');
    }

    async function recusarPedido(id) {
        const { error } = await app.client.rpc('respond_to_delivery', { p_order_id: id, p_response: 'rejected' });
        if (error) {
            fail(error, 'Não foi possível recusar a solicitação');
            return;
        }
        await carregarPedidosDisponiveisEntregador();
        showMessage('Solicitação recusada.', 'success');
    }

    async function carregarEntregaAtivaEntregador() {
        const container = document.getElementById('container-entrega-ativa');
        if (!container || !app.user || app.courier?.approval_status !== 'approved') return;
        const { data, error } = await app.client.from('delivery_orders').select('*')
            .eq('courier_id', app.user.id).in('status', ACTIVE_STATUSES)
            .order('created_at', { ascending: false }).limit(1).maybeSingle();
        if (error) throw error;
        if (!data) {
            container.className = 'bg-slate-50 border border-slate-200 rounded-xl p-5 text-center text-slate-500';
            container.textContent = 'Nenhuma entrega em andamento.';
            setCourierAvailableOrdersVisibility(true);
            await atualizarMapaEntregaEntregador(null);
            return;
        }
        courierMapEnabled = true;
        setCourierAvailableOrdersVisibility(false);
        const nextStep = {
            accepted: ['pickup_started', 'Iniciar coleta'],
            pickup_started: ['collected', 'Confirmar retirada do produto'],
            collected: ['in_transit', 'Iniciar trajeto'],
            in_transit: ['delivered', 'Confirmar entrega concluída']
        }[data.status];
        container.className = 'bg-white border-2 border-emerald-500 rounded-xl p-5 space-y-4';
        container.innerHTML = `
            <div class="flex justify-between items-center"><strong>Pedido ${escapeHtml(data.id.slice(0, 8).toUpperCase())}</strong><span class="text-xs font-semibold text-brand-700">${escapeHtml(STATUS_LABELS[data.status])}</span></div>
            <div class="text-xs space-y-1 text-slate-600"><p><strong>Coleta:</strong> ${escapeHtml(data.pickup_address)}</p><p><strong>Destino:</strong> ${escapeHtml(data.dropoff_address)}</p><p><strong>Produto:</strong> ${escapeHtml(data.description)}</p><p><strong>Distância:</strong> ${Number(data.distance_km).toLocaleString('pt-BR')} km</p><p><strong>Valor oferecido:</strong> ${money(data.courier_amount)}</p>${data.notes ? `<p><strong>Instruções:</strong> ${escapeHtml(data.notes)}</p>` : ''}</div>
            <button type="button" data-open-navigation class="w-full border border-brand-600 text-brand-700 hover:bg-brand-50 text-sm font-bold py-2.5 rounded-lg"><i class="fa-solid fa-diamond-turn-right mr-1"></i>Navegar no GPS</button>
            <button data-next-status="${nextStep[0]}" class="w-full bg-brand-600 hover:bg-brand-700 text-white text-sm font-bold py-2.5 rounded-lg">${nextStep[1]}</button>
        `;
        container.querySelector('[data-open-navigation]').addEventListener('click', () => {
            window.location.assign(buildGoogleMapsDirectionsUrl(data));
        });
        await atualizarMapaEntregaEntregador(data);
        startCourierLocationTracking(data);
        container.querySelector('[data-next-status]').addEventListener('click', () => avancarStatus(data.id, nextStep[0]));
    }

    async function avancarStatus(id, nextStatus) {
        const { error } = await app.client.rpc('advance_delivery', { p_order_id: id, p_next_status: nextStatus });
        if (error) {
            fail(error, 'Não foi possível atualizar a entrega');
            return;
        }
        if (nextStatus === 'delivered') stopCourierLocationTracking();
        await Promise.all([carregarEntregaAtivaEntregador(), carregarPedidosDisponiveisEntregador(), carregarHistoricoEntregador()]);
        showMessage(nextStatus === 'delivered' ? 'Entrega concluída. Ganho registrado como pendente.' : `Etapa atualizada: ${STATUS_LABELS[nextStatus]}.`, 'success');
    }

    async function carregarHistoricoEntregador() {
        if (!app.user || app.courier?.approval_status !== 'approved') return;
        const [{ data: earnings, error }, { data: ratings, error: ratingError }] = await Promise.all([
            app.client.from('courier_earnings').select('*, delivery_orders(id,pickup_address,dropoff_address,delivered_at)').eq('courier_id', app.user.id).order('created_at', { ascending: false }).limit(50),
            app.client.from('courier_ratings').select('stars,comment,created_at,order_id').eq('courier_id', app.user.id).order('created_at', { ascending: false }).limit(50)
        ]);
        if (error) throw error;
        if (ratingError) throw ratingError;
        const pending = (earnings || []).filter(item => item.status === 'pending').reduce((sum, item) => sum + Number(item.amount), 0);
        const paid = (earnings || []).filter(item => item.status === 'paid').reduce((sum, item) => sum + Number(item.amount), 0);
        document.getElementById('courier-earnings-pending').textContent = money(pending);
        document.getElementById('courier-earnings-paid').textContent = money(paid);
        document.getElementById('courier-deliveries-count').textContent = String((earnings || []).length);
        const average = ratings?.length ? ratings.reduce((sum, item) => sum + item.stars, 0) / ratings.length : 0;
        document.getElementById('courier-rating-average').textContent = average ? `${average.toFixed(1)} ★ (${ratings.length})` : 'Ainda sem avaliações';
        document.getElementById('courier-ratings-list').innerHTML = ratings.length ? ratings.map(rating => `
            <article class="border-b border-slate-100 pb-3">
                <div class="flex justify-between gap-2"><strong class="text-amber-600">${'★'.repeat(rating.stars)}${'☆'.repeat(5 - rating.stars)}</strong><span class="text-xs text-slate-400">${new Date(rating.created_at).toLocaleDateString('pt-BR')}</span></div>
                <p class="text-sm text-slate-600 mt-1">${escapeHtml(rating.comment || 'Sem comentário.')}</p>
            </article>
        `).join('') : '<p class="text-sm text-slate-500">Ainda não há avaliações.</p>';
        const history = document.getElementById('courier-history');
        history.innerHTML = (earnings || []).length ? earnings.map(item => `
            <article class="flex flex-col sm:flex-row sm:justify-between gap-2 border-b border-slate-100 pb-3 text-sm">
                <div><strong>Pedido ${escapeHtml(item.delivery_orders.id.slice(0, 8).toUpperCase())}</strong><p class="text-xs text-slate-600">${escapeHtml(item.delivery_orders.pickup_address)} → ${escapeHtml(item.delivery_orders.dropoff_address)}</p><p class="text-xs text-slate-400">${item.delivery_orders.delivered_at ? new Date(item.delivery_orders.delivered_at).toLocaleDateString('pt-BR') : ''}</p></div>
                <div class="sm:text-right"><strong>${money(item.amount)}</strong><p class="text-xs ${item.status === 'paid' ? 'text-emerald-700' : 'text-amber-700'}">${item.status === 'paid' ? 'Pagamento concluído' : 'Pagamento pendente'}</p></div>
            </article>
        `).join('') : '<p class="text-sm text-slate-500">Nenhum serviço concluído.</p>';
    }

    async function carregarDadosDashboardAdmin() {
        if (!roleIsAdmin()) return;
        const [
            { data: profiles, error: profileError },
            { data: couriers, error: courierError },
            { data: summaryRows, error: summaryError },
            { data: ratings, error: ratingsError },
            { data: activities, error: activitiesError },
            { data: adminProfiles, error: adminProfilesError },
            { data: currentAdminProfile, error: currentAdminProfileError }
        ] = await Promise.all([
            app.client.from('profiles').select('id,full_name,email,role,phone,account_status,block_reason').order('created_at', { ascending: false }).limit(100),
            app.client.from('courier_profiles').select('*').order('created_at', { ascending: false }).limit(100),
            app.client.rpc('admin_dashboard_summary'),
            app.client.from('courier_ratings').select('*').order('created_at', { ascending: false }).limit(100),
            app.client.from('admin_activity_log').select('*').order('created_at', { ascending: false }).limit(100),
            app.client.from('profiles').select('id,full_name,email,role,phone,account_status,block_reason').in('email', Array.from(ADMIN_EMAILS)),
            app.client.from('profiles').select('id,full_name,email,role,phone,account_status,block_reason').eq('id', app.user.id).maybeSingle()
        ]);
        if (profileError) throw profileError;
        if (courierError) throw courierError;
        if (summaryError) throw summaryError;
        if (ratingsError) throw ratingsError;
        if (activitiesError) throw activitiesError;
        if (adminProfilesError) throw adminProfilesError;
        if (currentAdminProfileError) throw currentAdminProfileError;
        const summary = summaryRows?.[0];
        if (!summary) throw new Error('O relatório administrativo não retornou dados.');
        const allProfiles = [...new Map([...profiles, ...adminProfiles, ...(currentAdminProfile ? [currentAdminProfile] : [])].map(profile => [profile.id, profile])).values()];
        app.adminProfileById = new Map(allProfiles.map(profile => [profile.id, profile]));
        document.getElementById('kpi-total-pedidos').textContent = String(summary.total_orders);
        document.getElementById('kpi-em-andamento').textContent = String(summary.active_orders);
        document.getElementById('kpi-concluidos').textContent = String(summary.completed_orders);
        document.getElementById('kpi-cancelados').textContent = String(summary.cancelled_orders);
        document.getElementById('kpi-faturamento').textContent = money(summary.gross_revenue);
        document.getElementById('kpi-total-clientes').textContent = String(summary.total_clients);
        document.getElementById('kpi-total-entregadores').textContent = String(summary.total_couriers);
        document.getElementById('kpi-entregadores-online').textContent = String(summary.online_couriers);
        document.getElementById('kpi-comissoes').textContent = money(summary.platform_commission);
        document.getElementById('kpi-repasses-pendentes').textContent = money(summary.pending_payouts);
        document.getElementById('kpi-repasses-concluidos').textContent = money(summary.completed_payouts);

        const profileById = app.adminProfileById;
        const reviewList = document.getElementById('admin-courier-review-list');
        reviewList.innerHTML = couriers.length ? '' : '<p class="text-xs text-slate-500">Nenhum entregador cadastrado.</p>';
        couriers.forEach(courier => {
            const profile = profileById.get(courier.user_id) || {};
            const article = document.createElement('article');
            article.className = 'border border-slate-200 rounded-xl p-4 space-y-3';
            article.innerHTML = `
                <div class="flex flex-wrap justify-between gap-2"><div><strong>${escapeHtml(profile.full_name || 'Entregador')}</strong><p class="text-xs text-slate-600">${escapeHtml(profile.email || '')} · ${escapeHtml(profile.phone || '')}</p></div><span class="text-xs font-bold px-2 py-1 rounded bg-amber-50 text-amber-800">${statusApproval(courier.approval_status)}</span></div>
                <p class="text-xs text-slate-600">${courier.vehicle_type === 'motorcycle' ? `Motocicleta · placa ${escapeHtml(courier.plate || 'não informada')} · ${escapeHtml(courier.vehicle_info)}` : 'Bicicleta'} · ${courier.is_online ? 'ONLINE' : 'offline'}${profile.account_status === 'blocked' ? ' · CONTA BLOQUEADA' : ''}</p>
                ${courier.rejection_reason ? `<p class="text-xs text-rose-700">Motivo: ${escapeHtml(courier.rejection_reason)}</p>` : ''}
                <div class="flex flex-wrap gap-2" data-documents></div>
                <div class="flex flex-wrap gap-2"><button data-approve class="bg-emerald-600 text-white text-xs font-bold px-3 py-2 rounded-lg" ${courier.document_paths.length ? '' : 'disabled'}>${courier.approval_status === 'suspended' ? 'Reativar' : 'Aprovar'}</button><button data-reject class="bg-rose-600 text-white text-xs font-bold px-3 py-2 rounded-lg">Recusar</button>${courier.approval_status === 'approved' ? '<button data-suspend class="bg-amber-600 text-white text-xs font-bold px-3 py-2 rounded-lg">Suspender</button>' : ''}</div>`;
            const documentButtons = article.querySelector('[data-documents]');
            if (!courier.document_paths.length) {
                documentButtons.textContent = 'Documentos ainda não enviados.';
            } else {
                courier.document_paths.forEach((path, index) => {
                    const button = document.createElement('button');
                    button.className = 'text-xs text-brand-700 underline';
                    button.textContent = `Abrir documento ${index + 1}`;
                    button.addEventListener('click', () => abrirDocumentoEntregador(path).catch(error => fail(error, 'Não foi possível abrir o documento')));
                    documentButtons.appendChild(button);
                });
            }
            article.querySelector('[data-approve]').addEventListener('click', () => revisarCadastroEntregador(courier.user_id, 'approved').catch(error => fail(error, 'Não foi possível aprovar o entregador')));
            article.querySelector('[data-reject]').addEventListener('click', () => revisarCadastroEntregador(courier.user_id, 'rejected').catch(error => fail(error, 'Não foi possível recusar o entregador')));
            article.querySelector('[data-suspend]')?.addEventListener('click', () => revisarCadastroEntregador(courier.user_id, 'suspended').catch(error => fail(error, 'Não foi possível suspender o entregador')));
            reviewList.appendChild(article);
        });

        await carregarPedidosAdmin(true);
        const usersBody = document.getElementById('lista-usuarios-admin');
        usersBody.innerHTML = allProfiles.map(profile => {
            const blocked = profile.account_status === 'blocked';
            const isSelf = profile.id === app.user.id;
            const isAdminAccount = isAdminEmail(profile.email);
            const accountRole = isAdminAccount ? 'Administrador' : profile.role === 'courier' ? 'Entregador' : 'Cliente';
            const accountAction = isAdminAccount ? 'Administrador protegido' : blocked ? 'Desbloquear' : 'Bloquear';
            const roleClass = isAdminAccount
                ? 'bg-violet-50 text-violet-700'
                : profile.role === 'courier' ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-700';
            return `<tr data-admin-user-row data-user-name="${escapeHtml(profile.full_name)}" data-user-email="${escapeHtml(profile.email)}" data-user-role="${isAdminAccount ? 'admin' : profile.role}" class="border-b border-slate-100 transition hover:bg-slate-50"><td class="whitespace-nowrap px-3 py-3 font-semibold text-slate-800">${escapeHtml(profile.full_name)}</td><td class="px-3 py-3 text-slate-600">${escapeHtml(profile.email)}</td><td class="px-3 py-3"><span class="inline-flex rounded-full px-2.5 py-1 text-[10px] font-bold ${roleClass}">${accountRole}</span></td><td class="px-3 py-3 text-slate-600">${escapeHtml(couriers.find(courier => courier.user_id === profile.id)?.vehicle_type || '—')}</td><td class="px-3 py-3"><span class="inline-flex rounded-full px-2.5 py-1 text-[10px] font-semibold ${blocked ? 'bg-rose-50 text-rose-700' : 'bg-emerald-50 text-emerald-700'}">${blocked ? `Bloqueada${profile.block_reason ? `: ${escapeHtml(profile.block_reason)}` : ''}` : 'Ativa'}</span></td><td class="whitespace-nowrap px-3 py-3"><button data-account-id="${escapeHtml(profile.id)}" data-blocked="${blocked}" class="text-xs font-semibold ${blocked ? 'text-emerald-700' : 'text-rose-700'} underline disabled:cursor-not-allowed disabled:opacity-50" ${isSelf || isAdminAccount ? 'disabled' : ''}>${accountAction}</button></td></tr>`;
        }).join('');
        const noUsersRow = document.createElement('tr');
        noUsersRow.id = 'admin-user-no-results';
        noUsersRow.className = 'hidden';
        noUsersRow.innerHTML = '<td colspan="6" class="px-3 py-8 text-center text-sm text-slate-500">Nenhum usuário corresponde aos filtros.</td>';
        usersBody.appendChild(noUsersRow);
        usersBody.querySelectorAll('[data-account-id]').forEach(button => button.addEventListener('click', () => alterarBloqueioConta(button.dataset.accountId, button.dataset.blocked !== 'true').catch(error => fail(error, 'Não foi possível atualizar o painel administrativo'))));
        filtrarUsuariosAdmin();
        const namesById = new Map(allProfiles.map(profile => [profile.id, profile.full_name]));
        document.getElementById('admin-ratings-list').innerHTML = ratings.length ? ratings.map(rating => `
            <article class="border-b border-slate-100 pb-3 text-sm">
                <div class="flex flex-wrap justify-between gap-2"><strong class="text-amber-600">${'★'.repeat(rating.stars)}${'☆'.repeat(5 - rating.stars)}</strong><span class="text-xs text-slate-400">${new Date(rating.created_at).toLocaleString('pt-BR')}</span></div>
                <p class="text-xs text-slate-600 mt-1">Cliente: ${escapeHtml(namesById.get(rating.client_id) || 'Conta')} · Entregador: ${escapeHtml(namesById.get(rating.courier_id) || 'Conta')} · Pedido ${escapeHtml(rating.order_id.slice(0, 8).toUpperCase())}</p>
                <p class="text-sm text-slate-700 mt-1">${escapeHtml(rating.comment || 'Sem comentário.')}</p>
            </article>
        `).join('') : '<p class="text-xs text-slate-500">Nenhuma avaliação recebida.</p>';
        document.getElementById('admin-activity-list').innerHTML = activities.length ? activities.map(activity => `
            <article class="border-b border-slate-100 pb-2 text-xs">
                <p><strong>${escapeHtml(activity.action)}</strong> · ${escapeHtml(activity.target_type)} ${escapeHtml(activity.target_id || '')}</p>
                <p class="text-slate-500">${escapeHtml(namesById.get(activity.admin_id) || 'Administrador')} · ${new Date(activity.created_at).toLocaleString('pt-BR')}</p>
                <p class="text-slate-500">${escapeHtml(JSON.stringify(activity.details || {}))}</p>
            </article>
        `).join('') : '<p class="text-xs text-slate-500">Nenhuma atividade registrada.</p>';
        carregarTarifasNoForm();
        await carregarPagamentosAdmin(allProfiles);
    }

    async function carregarDashboardAdmin() {
        if (!roleIsAdmin()) return;
        const button = document.getElementById('admin-refresh-button');
        const icon = document.getElementById('admin-refresh-icon');
        const label = document.getElementById('admin-refresh-label');
        if (button) button.disabled = true;
        if (icon) icon.classList.add('fa-spin');
        if (label) label.textContent = 'Atualizando...';
        try {
            await carregarDadosDashboardAdmin();
            const updatedAt = document.getElementById('admin-last-updated');
            if (updatedAt) updatedAt.textContent = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit' }).format(new Date());
        } finally {
            if (button) button.disabled = false;
            if (icon) icon.classList.remove('fa-spin');
            if (label) label.textContent = 'Atualizar painel';
        }
    }

    function filtrarUsuariosAdmin() {
        const search = document.getElementById('admin-user-search')?.value.trim().toLocaleLowerCase('pt-BR') || '';
        const selectedRole = document.getElementById('admin-user-role-filter')?.value || 'all';
        const rows = Array.from(document.querySelectorAll('#lista-usuarios-admin [data-admin-user-row]'));
        let visibleCount = 0;
        rows.forEach(row => {
            const searchableText = `${row.dataset.userName} ${row.dataset.userEmail}`.toLocaleLowerCase('pt-BR');
            const visible = searchableText.includes(search)
                && (selectedRole === 'all' || row.dataset.userRole === selectedRole);
            row.classList.toggle('hidden', !visible);
            if (visible) visibleCount += 1;
        });
        document.getElementById('admin-user-no-results')?.classList.toggle('hidden', visibleCount > 0);
        const count = document.getElementById('admin-user-count');
        if (count) {
            count.textContent = search || selectedRole !== 'all'
                ? `${visibleCount} de ${rows.length} usuários`
                : `${rows.length} usuários na lista`;
        }
    }

    async function carregarPedidosAdmin(reset) {
        if (!roleIsAdmin()) return;
        if (reset) {
            app.adminOrderOffset = 0;
            app.adminOrders = [];
        }
        const selectedFilter = document.getElementById('admin-order-filter').value;
        let request = app.client.from('delivery_orders')
            .select('*', { count: 'exact' })
            .order('created_at', { ascending: false })
            .range(app.adminOrderOffset, app.adminOrderOffset + app.adminOrderPageSize - 1);
        if (selectedFilter === 'active') request = request.in('status', ACTIVE_STATUSES);
        else if (selectedFilter !== 'all') request = request.eq('status', selectedFilter);
        const { data, count, error } = await request;
        if (error) throw error;
        app.adminOrders = reset ? (data || []) : app.adminOrders.concat(data || []);
        app.adminOrderTotal = count || 0;
        app.adminOrderOffset = app.adminOrders.length;
        renderAdminOrders();
        document.getElementById('admin-orders-load-more').classList.toggle('hidden', app.adminOrders.length >= app.adminOrderTotal);
    }

    function renderAdminOrders() {
        const orderBody = document.getElementById('lista-pedidos-admin');
        orderBody.innerHTML = app.adminOrders.map(order => `
            <tr>
                <td class="py-2 px-3 font-bold">${escapeHtml(order.id.slice(0, 8).toUpperCase())}</td>
                <td class="py-2 px-3">${escapeHtml(app.adminProfileById.get(order.client_id)?.full_name || 'Cliente')}</td>
                <td class="py-2 px-3">${escapeHtml(app.adminProfileById.get(order.courier_id)?.full_name || '—')}</td>
                <td class="py-2 px-3">${order.vehicle_type === 'motorcycle' ? 'Motocicleta' : 'Bicicleta'}</td>
                <td class="py-2 px-3">${money(order.total_amount)}</td>
                <td class="py-2 px-3">${escapeHtml(STATUS_LABELS[order.status] || order.status)}</td>
                <td class="py-2 px-3"><button data-order-id="${escapeHtml(order.id)}" class="text-brand-700 underline">Ver</button></td>
            </tr>
        `).join('');
        orderBody.querySelectorAll('[data-order-id]').forEach(button => button.addEventListener('click', () => mostrarDetalhesPedidoAdmin(button.dataset.orderId)));
    }

    async function filtrarPedidosAdmin() {
        try {
            await carregarPedidosAdmin(true);
        } catch (error) {
            fail(error, 'Não foi possível filtrar os pedidos administrativos');
        }
    }

    async function carregarMaisPedidosAdmin() {
        try {
            await carregarPedidosAdmin(false);
        } catch (error) {
            fail(error, 'Não foi possível carregar mais pedidos');
        }
    }

    function mostrarDetalhesPedidoAdmin(orderId) {
        const order = app.adminOrders.find(item => item.id === orderId);
        if (!order || !roleIsAdmin()) return;
        const fields = [
            ['Pedido', order.id],
            ['Cliente', app.adminProfileById.get(order.client_id)?.full_name || order.client_id],
            ['Entregador', order.courier_id ? app.adminProfileById.get(order.courier_id)?.full_name || order.courier_id : 'Ainda não atribuído'],
            ['Status', STATUS_LABELS[order.status] || order.status],
            ['Coleta', order.pickup_address],
            ['Destino', order.dropoff_address],
            ['Descrição', order.description],
            ['Instruções', order.notes || 'Nenhuma'],
            ['Veículo', order.vehicle_type === 'motorcycle' ? 'Motocicleta' : 'Bicicleta'],
            ['Distância', `${Number(order.distance_km).toLocaleString('pt-BR')} km`],
            ['Valor total', money(order.total_amount)],
            ['Repasse ao entregador', money(order.courier_amount)],
            ['Criado em', new Date(order.created_at).toLocaleString('pt-BR')],
            ['Concluído em', order.delivered_at ? new Date(order.delivered_at).toLocaleString('pt-BR') : '—']
        ];
        document.getElementById('admin-order-details').innerHTML = fields.map(([label, value]) =>
            `<p><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</p>`
        ).join('');
        const modal = document.getElementById('admin-order-modal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function fecharDetalhesPedidoAdmin() {
        const modal = document.getElementById('admin-order-modal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }

    async function abrirDocumentoEntregador(path) {
        const documentWindow = window.open('about:blank', '_blank');
        if (!documentWindow) throw new Error('Permita a abertura de janelas para visualizar os documentos.');
        try {
            const { data, error } = await app.client.storage.from(DOCUMENT_BUCKET).createSignedUrl(path, 60);
            if (error) throw error;
            documentWindow.opener = null;
            documentWindow.location = data.signedUrl;
        } catch (error) {
            documentWindow.close();
            throw error;
        }
    }

    async function revisarCadastroEntregador(userId, decision) {
        const reason = decision === 'rejected' || decision === 'suspended'
            ? prompt(decision === 'suspended' ? 'Informe o motivo da suspensão:' : 'Informe o motivo da recusa para o entregador:')
            : null;
        if ((decision === 'rejected' || decision === 'suspended') && !reason?.trim()) {
            showMessage('Informe o motivo da ação administrativa.', 'error');
            return;
        }
        const { error } = await app.client.rpc('review_courier_profile', {
            p_user_id: userId,
            p_decision: decision,
            p_reason: decision === 'rejected' || decision === 'suspended' ? reason.trim().slice(0, 500) : null
        });
        if (error) {
            fail(error, 'Não foi possível revisar o cadastro');
            return;
        }
        await carregarDashboardAdmin();
        const messages = {
            approved: 'Entregador aprovado ou reativado.',
            rejected: 'Cadastro recusado com o motivo informado.',
            suspended: 'Entregador suspenso e removido do modo online.'
        };
        showMessage(messages[decision], 'success');
    }

    async function alterarBloqueioConta(userId, block) {
        if (!roleIsAdmin() || userId === app.user.id) return;
        const reason = block ? prompt('Informe o motivo do bloqueio da conta:') : null;
        if (block && !reason?.trim()) {
            showMessage('Informe o motivo para bloquear a conta.', 'error');
            return;
        }
        if (!block && !confirm('Deseja desbloquear esta conta?')) return;
        const { error } = await app.client.rpc('admin_set_account_blocked', {
            p_user_id: userId,
            p_blocked: block,
            p_reason: reason?.trim().slice(0, 500) || null
        });
        if (error) {
            fail(error, 'Não foi possível alterar o bloqueio da conta');
            return;
        }
        await carregarDashboardAdmin();
        showMessage(block ? 'Conta bloqueada.' : 'Conta desbloqueada.', 'success');
    }

    async function carregarPagamentosAdmin(profiles) {
        const container = document.getElementById('admin-courier-earnings');
        const { data, error } = await app.client.from('courier_earnings').select('*').eq('status', 'pending').order('created_at', { ascending: true }).limit(50);
        if (error) throw error;
        if (!data.length) {
            container.innerHTML = '<p class="text-xs text-slate-500">Nenhum pagamento pendente.</p>';
            return;
        }
        const names = new Map(profiles.map(profile => [profile.id, profile.full_name]));
        container.innerHTML = data.map(item => `<div class="flex items-center justify-between gap-3 border-b pb-2 text-sm"><div><strong>${escapeHtml(names.get(item.courier_id) || 'Entregador')}</strong><p class="text-xs text-slate-500">Pedido ${escapeHtml(item.order_id.slice(0, 8).toUpperCase())} · ${money(item.amount)}</p></div><button data-pay-id="${escapeHtml(item.id)}" class="text-xs bg-emerald-600 text-white px-3 py-2 rounded-lg">Confirmar pagamento</button></div>`).join('');
        container.querySelectorAll('[data-pay-id]').forEach(button => button.addEventListener('click', () => confirmarPagamento(button.dataset.payId).catch(error => fail(error, 'Não foi possível atualizar o painel administrativo'))));
    }

    async function confirmarPagamento(id) {
        if (!confirm('Confirma que o pagamento ao entregador foi realizado?')) return;
        const { error } = await app.client.rpc('mark_courier_earning_paid', { p_earning_id: id });
        if (error) {
            fail(error, 'Não foi possível confirmar o pagamento');
            return;
        }
        await carregarDashboardAdmin();
        showMessage('Pagamento marcado como concluído.', 'success');
    }

    async function renderBadgeStatus(status) {
        const label = STATUS_LABELS[status] || status;
        return `<span class="bg-slate-100 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded">${escapeHtml(label)}</span>`;
    }

    function atualizarCamposVeiculo() {
        updateVehicleFields();
    }

    window.openAuthModal = openAuthModal;
    window.closeAuthModal = safely(closeAuthModal, 'Não foi possível fechar a recuperação de senha');
    window.definirModoAuth = definirModoAuth;
    window.abrirRecuperacaoSenha = abrirRecuperacaoSenha;
    window.voltarAoLogin = executarAcaoRecuperacao(voltarAoLogin, 'Não foi possível voltar ao login');
    window.enviarCodigoRecuperacao = executarAcaoRecuperacao(enviarCodigoRecuperacao, 'Não foi possível enviar o código de recuperação');
    window.verificarCodigoRecuperacao = executarAcaoRecuperacao(verificarCodigoRecuperacao, 'Não foi possível validar o código');
    window.salvarNovaSenha = executarAcaoRecuperacao(salvarNovaSenha, 'Não foi possível salvar a nova senha');
    window.startCourierSignup = startCourierSignup;
    window.atualizarCamposCadastroAuth = atualizarCamposCadastroAuth;
    window.atualizarEstadoAceiteTermos = atualizarEstadoAceiteTermos;
    window.openLegalDocument = openLegalDocument;
    window.closeLegalDocument = closeLegalDocument;
    window.enviarFormularioAuth = enviarFormularioAuth;
    window.handleAuthButton = safely(handleAuthButton, 'Não foi possível sair da conta');
    window.switchTab = tab => switchTab(tab).catch(error => fail(error, 'Não foi possível abrir esta área'));
    window.criarPedido = criarPedido;
    window.cancelarPedido = safely(cancelarPedido, 'Não foi possível cancelar o pedido');
    window.carregarPedidosCliente = () => carregarPedidosCliente().catch(error => fail(error, 'Erro ao carregar pedidos'));
    window.carregarTarifasNoForm = carregarTarifasNoForm;
    window.atualizarEstimativa = atualizarEstimativa;
    window.salvarTarifas = safely(salvarTarifas, 'Não foi possível salvar as tarifas');
    window.selecionarVeiculo = function (type) {
        app.selectedVehicle = type === 'bicicleta' ? 'bicycle' : 'motorcycle';
        document.getElementById('card-moto').className = type === 'moto'
            ? 'cursor-pointer border-2 border-brand-500 bg-brand-50/50 p-3 rounded-xl flex items-center space-x-3 transition'
            : 'cursor-pointer border border-slate-200 p-3 rounded-xl flex items-center space-x-3 transition hover:border-slate-300';
        document.getElementById('card-bike').className = type === 'bicicleta'
            ? 'cursor-pointer border-2 border-brand-500 bg-brand-50/50 p-3 rounded-xl flex items-center space-x-3 transition'
            : 'cursor-pointer border border-slate-200 p-3 rounded-xl flex items-center space-x-3 transition hover:border-slate-300';
        atualizarEstimativa();
    };
    window.carregarDashboardAdmin = () => carregarDashboardAdmin().catch(error => fail(error, 'Erro ao carregar o painel administrativo'));
    window.filtrarUsuariosAdmin = filtrarUsuariosAdmin;
    window.filtrarPedidosAdmin = filtrarPedidosAdmin;
    window.carregarMaisPedidosAdmin = carregarMaisPedidosAdmin;
    window.fecharDetalhesPedidoAdmin = fecharDetalhesPedidoAdmin;
    window.carregarPedidosDisponiveisEntregador = () => carregarPedidosDisponiveisEntregador().catch(error => fail(error, 'Erro ao carregar solicitações'));
    window.carregarEntregaAtivaEntregador = () => carregarEntregaAtivaEntregador().catch(error => fail(error, 'Erro ao carregar entrega ativa'));
    window.carregarPainelEntregador = () => carregarPainelEntregador().catch(error => fail(error, 'Erro ao carregar área do entregador'));
    window.salvarPerfilEntregador = safely(salvarPerfilEntregador, 'Não foi possível salvar o cadastro');
    window.atualizarCamposVeiculo = atualizarCamposVeiculo;
    window.toggleOnlineEntregador = safely(toggleOnlineEntregador, 'Não foi possível alterar a disponibilidade');
    window.aceitarPedido = safely(aceitarPedido, 'Não foi possível aceitar a solicitação');
    window.recusarPedido = safely(recusarPedido, 'Não foi possível recusar a solicitação');
    window.avancarStatus = safely(avancarStatus, 'Não foi possível atualizar a entrega');
    window.avaliarEntregador = safely(avaliarEntregador, 'Não foi possível registrar a avaliação');
    window.revisarCadastroEntregador = safely(revisarCadastroEntregador, 'Não foi possível revisar o cadastro');
    window.abrirDocumentoEntregador = safely(abrirDocumentoEntregador, 'Não foi possível abrir o documento');
    window.confirmarPagamento = safely(confirmarPagamento, 'Não foi possível confirmar o pagamento');
    window.renderBadgeStatus = status => `<span class="bg-slate-100 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded">${escapeHtml(STATUS_LABELS[status] || status)}</span>`;
    window.efetuarLogin = enviarFormularioAuth;
    window.salvarDados = function () {};
    window.atualizarDisponibilidadeEntregador = function () {
        const toggle = document.getElementById('toggle-online');
        const status = document.getElementById('status-online-text');
        if (toggle && status) {
            toggle.checked = Boolean(app.courier?.is_online && app.courier?.approval_status === 'approved');
            status.textContent = toggle.checked ? 'ONLINE' : 'OFFLINE';
        }
    };

    window.addEventListener('DOMContentLoaded', () => {
        window.addEventListener('keydown', event => {
            if (event.key === 'Escape' && !document.getElementById('legal-document-modal').classList.contains('hidden')) {
                closeLegalDocument();
            }
        });
        const passwordField = document.getElementById('auth-password');
        const passwordToggle = document.getElementById('auth-password-toggle');
        passwordToggle.addEventListener('click', () => {
            const showPassword = passwordField.type === 'password';
            passwordField.type = showPassword ? 'text' : 'password';
            passwordToggle.setAttribute('aria-label', showPassword ? 'Ocultar senha' : 'Mostrar senha');
            passwordToggle.setAttribute('aria-pressed', String(showPassword));
            passwordToggle.querySelector('i').classList.toggle('fa-eye', !showPassword);
            passwordToggle.querySelector('i').classList.toggle('fa-eye-slash', showPassword);
        });
        initialize().catch(error => fail(error, 'Não foi possível iniciar o sistema'));
    });
})();
