const allDetails={...DETAIL,...GEO_DETAIL,...CIVIC_DETAIL,...ECON_DETAIL};
const explored=JSON.parse(localStorage.getItem("exploredChapters")||"[]");
const reviews=JSON.parse(localStorage.getItem("reviews")||"[]");
let activeSubject="All", quizIndex=0, quizPoints=0;
const quizQuestions=[
 ["Which event is associated with 1789 in France?",["Storming of the Bastille","Formation of the USSR","Nuremberg Laws","Constitution of India"],0,"History"],
 ["Which is the Standard Meridian of India?",["68°7'E","82°30'E","90°E","77°E"],1,"Geography"],
 ["Which institution conducts elections in India?",["Election Commission","Supreme Court","Finance Commission","Planning body"],0,"Civics"],
 ["Which is a factor of production?",["Land","Only money","Only machines","Only markets"],0,"Economics"],
 ["What is buffer stock?",["Foodgrain stock maintained for public needs","A forest reserve","A population register","A tax record"],0,"Economics"]
];

function chapterRecords(){
 const out=[];
 for(const [subject,s] of Object.entries(SUBJECTS)) s.chapters.forEach((c,i)=>out.push({subject,index:i+1,title:c[0],topics:c[1],accent:s.accent,soft:s.soft}));
 return out;
}
function renderSubjects(){
 document.getElementById("subjectGrid").innerHTML=Object.entries(SUBJECTS).map(([name,s])=>`
 <article class="subject-card" style="--accent:${s.accent}">
  <div class="subject-icon">${s.icon}</div><span class="count">${s.chapters.length} chapters • ${s.book}</span>
  <h3>${name}</h3><p>Complete notes, diagrams, questions, flashcards and quizzes.</p>
  <div class="subject-actions"><button class="mini-btn" onclick="filterSubject('${name}')">Explore</button><button class="mini-btn" onclick="filterSubject('${name}');scrollToId('quiz')">Quiz</button></div>
 </article>`).join("");
}
function renderFilters(){
 const names=["All",...Object.keys(SUBJECTS)];
 document.getElementById("filters").innerHTML=names.map(n=>`<button class="filter ${n===activeSubject?"active":""}" onclick="filterSubject('${n}')">${n}</button>`).join("");
}
function renderChapters(){
 const q=(document.getElementById("searchInput").value||"").toLowerCase();
 const records=chapterRecords().filter(c=>(activeSubject==="All"||c.subject===activeSubject)&&(
  c.title.toLowerCase().includes(q)||c.topics.some(t=>t.toLowerCase().includes(q))||c.subject.toLowerCase().includes(q)));
 document.getElementById("chapterGrid").innerHTML=records.map(c=>`
 <article class="chapter-card" style="--accent:${c.accent};--soft:${c.soft}" onclick="openChapter('${encodeURIComponent(c.title)}')">
   <div class="chapter-top"><span class="chapter-num">${c.subject.toUpperCase()} • CH ${c.index}</span><span class="tag">${c.topics.length} key areas</span></div>
   <h3>${c.title}</h3><p>Summary, important concepts, dates, people, exam questions and revision tools.</p>
   <div class="topic-pills">${c.topics.slice(0,5).map(t=>`<span class="topic-pill">${t}</span>`).join("")}</div>
 </article>`).join("")||`<div class="detail-block"><b>No matching topic.</b><p>Try another keyword.</p></div>`;
}
function filterSubject(s){activeSubject=s;renderFilters();renderChapters();scrollToId("library")}
function scrollToId(id){document.getElementById(id)?.scrollIntoView({behavior:"smooth"})}
function openChapter(encoded){
 const title=decodeURIComponent(encoded), d=allDetails[title]||{};
 const rec=chapterRecords().find(x=>x.title===title);
 if(!explored.includes(title)){explored.push(title);localStorage.setItem("exploredChapters",JSON.stringify(explored));updateDashboard()}
 const questions=d.questions||["What are the key ideas in this chapter?","Which terms should you revise?","How would you explain the topic in your own words?"];
 document.getElementById("modalContent").innerHTML=`
  <span class="eyebrow">${rec?.subject||"SOCIAL SCIENCE"} • CHAPTER ${rec?.index||""}</span>
  <h2>${title}</h2><p>${d.summary||"A structured chapter workspace for understanding concepts, connecting ideas and preparing for assessment."}</p>
  <div class="modal-grid">
   <div class="detail-block"><h4>📌 Key concepts</h4><ul>${(d.concepts||rec?.topics||[]).map(x=>`<li>${x}</li>`).join("")}</ul></div>
   <div class="detail-block"><h4>👤 Important people</h4><ul>${(d.people||[]).map(x=>`<li>${x}</li>`).join("")||"<li>Use the prescribed textbook for chapter-specific names.</li>"}</ul></div>
   <div class="detail-block"><h4>📅 Important dates</h4><ul>${(d.dates||[]).map(x=>`<li>${x}</li>`).join("")||"<li>Review the chapter timeline.</li>"}</ul></div>
   <div class="detail-block"><h4>🧠 Exam idea</h4><p>${d.answer||"Build answers with definition → explanation → example/evidence → conclusion."}</p></div>
  </div>
  <div class="detail-block" style="margin-top:15px"><h4>⭐ Important questions</h4>${questions.map((q,i)=>`<p><b>${i+1}. ${q}</b></p>`).join("")}</div>
  <div class="detail-block" style="margin-top:15px"><h4>🗺️ Visual learning</h4><p>Mind map: <b>${title}</b> → causes/ideas → key events → consequences → examples → exam questions.</p><div class="flashcard">Flashcard: “What is the core idea of this chapter?”<br><small>Tap/extend this component when connected to a real flashcard engine.</small></div></div>
  <div class="integration-note">[Dynamic Content] Connect a CMS/database to expand every chapter into full topic-by-topic notes, image diagrams, map layers, question banks and multilingual explanations.</div>`;
 document.getElementById("chapterModal").classList.add("open");
}
function showToast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function sendChat(){
 const input=document.getElementById("chatInput"), text=input.value.trim(); if(!text)return;
 const body=document.getElementById("chatBody"); body.insertAdjacentHTML("beforeend",`<div class="bubble user">${escapeHtml(text)}</div>`);
 body.insertAdjacentHTML("beforeend",`<div class="bubble bot">Demo response: connect the <b>[AI Teacher Integration]</b> backend to answer this question using chapter context, citations and your chosen LLM.</div>`);
 input.value="";body.scrollTop=body.scrollHeight;
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m]))}
function renderQuiz(){
 const q=quizQuestions[quizIndex%quizQuestions.length];
 document.getElementById("quizMeta").textContent=`Question ${(quizIndex%quizQuestions.length)+1} of ${quizQuestions.length} • ${q[3]}`;
 document.getElementById("quizCard").innerHTML=`<h3>${q[0]}</h3>${q[1].map((o,i)=>`<button class="option" onclick="answerQuiz(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join("")}`;
}
function answerQuiz(i){
 const q=quizQuestions[quizIndex%quizQuestions.length], ok=i===q[2]; if(ok)quizPoints++;
 document.getElementById("quizCard").insertAdjacentHTML("beforeend",`<div class="detail-block" style="margin-top:12px"><b>${ok?"Correct ✓":"Not quite."}</b><p>${ok?"Nice recall.":"Correct answer: "+q[1][q[2]]}</p><button class="btn primary quiz-next" onclick="quizIndex++;renderQuiz();updateDashboard()">Next question →</button></div>`);
 localStorage.setItem("quizScore",String(Math.round((quizPoints/Math.max(1,quizIndex+1))*100)));updateDashboard();
}
function updateDashboard(){
 const total=chapterRecords().length, p=Math.round(explored.length/total*100), score=Number(localStorage.getItem("quizScore")||0);
 document.getElementById("exploredCount").textContent=explored.length;
 document.getElementById("progressValue").textContent=p+"%";document.getElementById("ringText").textContent=p+"%";document.getElementById("quizScore").textContent=score+"%";
 document.getElementById("ringFill").parentElement.style.background=`conic-gradient(#7c5cff ${p*3.6}deg,#eef0f5 0deg)`;
}
function revisionPlan(min){
 const plans={15:["5 min — key concepts","5 min — flashcards","5 min — quick quiz"],30:["10 min — chapter summary","10 min — important dates/terms","5 min — questions","5 min — quiz"],60:["20 min — core concepts","15 min — diagrams/maps","15 min — important questions","10 min — quiz"],120:["35 min — deep notes","25 min — visual maps","30 min — questions","20 min — flashcards","10 min — final quiz"]};
 document.getElementById("revisionResult").innerHTML=`<b>${min}-minute plan</b><ul>${plans[min].map(x=>`<li>${x}</li>`).join("")}</ul>`;
}
function renderReviews(){document.getElementById("reviewList").innerHTML=(reviews.length?reviews: [{name:"StudySphere",topic:"Tip",text:"Write answers in your own words and revise using active recall."}]).slice().reverse().map(r=>`<article class="review-item"><header><b>${escapeHtml(r.name||"Anonymous")}</b><small>${escapeHtml(r.topic)}</small></header><p>${escapeHtml(r.text)}</p><small>Pending/approved depending on moderation settings.</small></article>`).join("")}
document.addEventListener("DOMContentLoaded",()=>{
 renderSubjects();renderFilters();renderChapters();renderQuiz();updateDashboard();renderReviews();
 document.getElementById("searchInput").addEventListener("input",renderChapters);
 document.getElementById("modalClose").onclick=()=>document.getElementById("chapterModal").classList.remove("open");
 document.getElementById("chapterModal").addEventListener("click",e=>{if(e.target.id==="chapterModal")e.currentTarget.classList.remove("open")});
 document.getElementById("sendBtn").onclick=sendChat;document.getElementById("chatInput").addEventListener("keydown",e=>{if(e.key==="Enter")sendChat()});
 document.querySelectorAll(".prompt").forEach(b=>b.onclick=()=>{document.getElementById("chatInput").value=b.dataset.prompt;sendChat()});
 document.querySelectorAll(".time-options button").forEach(b=>b.onclick=()=>revisionPlan(Number(b.dataset.min)));
 document.querySelectorAll("[data-scroll]").forEach(b=>b.onclick=()=>scrollToId(b.dataset.scroll.slice(1)));
 document.querySelectorAll("[data-tool]").forEach(b=>b.onclick=()=>showToast(`${b.dataset.tool} UI is ready for backend integration.`));
 document.getElementById("reviewForm").onsubmit=e=>{e.preventDefault();reviews.push({name:reviewName.value,topic:reviewTopic.value,text:reviewText.value});localStorage.setItem("reviews",JSON.stringify(reviews));e.target.reset();renderReviews();showToast("Saved locally — connect moderation/database before publishing.");};
});
