const SUBJECTS = {
  History:{icon:"🏛️",accent:"#e85d3f",soft:"#fff0ec",book:"India and the Contemporary World - I",chapters:[
    ["The French Revolution",["Ancien Régime","Three Estates","1789","Jacobins","Reign of Terror","Napoleon"]],
    ["Socialism in Europe and the Russian Revolution",["Liberalism","Karl Marx","1905 Revolution","February Revolution","October Revolution","USSR"]],
    ["Nazism and the Rise of Hitler",["Weimar Republic","Treaty of Versailles","Great Depression","Nazi ideology","Holocaust","World War II"]],
    ["Forest Society and Colonialism",["Scientific forestry","Colonial laws","Bastar","Java","Forest communities","Commercialisation"]],
    ["Pastoralists in the Modern World",["Nomadic pastoralism","Grazing laws","Criminal Tribes Act","Maasai","Gujjar Bakarwals","Raikas"]]
  ]},
  Geography:{icon:"🌍",accent:"#159b88",soft:"#e8faf6",book:"Contemporary India - I",chapters:[
    ["India — Size and Location",["Latitudes","Longitudes","Standard Meridian","IST","Tropic of Cancer","Neighbouring countries"]],
    ["Physical Features of India",["Himalayas","Northern Plains","Peninsular Plateau","Indian Desert","Coastal Plains","Islands"]],
    ["Drainage",["Himalayan rivers","Peninsular rivers","Indus","Ganga","Brahmaputra","Lakes"]],
    ["Climate",["Weather vs climate","Monsoon","Winter","Summer","Rainfall","Retreating monsoon"]],
    ["Natural Vegetation and Wildlife",["Evergreen","Deciduous","Thorn forests","Montane","Mangroves","Conservation"]],
    ["Population",["Distribution","Density","Growth","Migration","Age composition","Sex ratio","Literacy"]]
  ]},
  Civics:{icon:"⚖️",accent:"#6f56d9",soft:"#f0edff",book:"Democratic Politics - I",chapters:[
    ["What is Democracy? Why Democracy?",["Meaning","Features","Accountability","Equality","Participation","Arguments"]],
    ["Constitutional Design",["Constitution","Apartheid","South Africa","Constituent Assembly","Preamble","Principles"]],
    ["Electoral Politics",["Elections","Constituencies","Voters","Election Commission","Reserved constituencies","Campaigning"]],
    ["Working of Institutions",["Parliament","Executive","Judiciary","President","Prime Minister","Supreme Court"]],
    ["Democratic Rights",["Fundamental Rights","Equality","Freedom","Religion","Cultural rights","Constitutional remedies"]]
  ]},
  Economics:{icon:"📈",accent:"#c18b2c",soft:"#fff7e7",book:"Economics",chapters:[
    ["The Story of Village Palampur",["Production","Land","Labour","Physical capital","Multiple cropping","Non-farm activities"]],
    ["People as Resource",["Human capital","Education","Health","Economic activities","Unemployment","Disguised unemployment"]],
    ["Poverty as a Challenge",["Poverty line","Vulnerability","Social exclusion","Causes","Anti-poverty programmes","Trends"]],
    ["Food Security in India",["Availability","Accessibility","Affordability","Buffer stock","PDS","MSP","FCI"]]
  ]}
};

const DETAIL = {
  "The French Revolution": {
    summary:"The French Revolution transformed France from an absolute monarchy toward a constitutional and republican political order. It emerged from social inequality, fiscal crisis, food shortages and demands for political representation and rights.",
    concepts:["Three Estates and unequal privileges","Subsistence crisis and rising bread prices","Estates-General and Tennis Court Oath","Bastille and abolition of feudal privileges","Declaration of the Rights of Man and Citizen","Constitution of 1791","Jacobins and Reign of Terror","Women, slavery and changing ideas of citizenship","Napoleon and the revolution's wider influence"],
    people:["Louis XVI","Marie Antoinette","Maximilien Robespierre","Jean-Paul Marat","Olympe de Gouges","Napoleon Bonaparte"],
    dates:["1789 — Estates-General, Tennis Court Oath and Bastille","1791 — Constitution and constitutional monarchy","1792 — France becomes a republic","1793–1794 — Reign of Terror","1804 — Napoleon's empire"],
    questions:["Why did the French Revolution begin?","What was the Third Estate?","What did the Declaration of Rights establish?","Why was the Jacobin period called the Reign of Terror?"],
    answer:"A strong exam answer should connect causes rather than list them: unequal social structure, financial difficulties, food scarcity and political demands interacted and produced a crisis of the old regime."
  },
  "Socialism in Europe and the Russian Revolution": {
    summary:"The chapter traces competing political ideas in nineteenth-century Europe and the Russian revolutions of 1905 and 1917. It explains the impact of war, inequality, industrialisation and political organisation on the collapse of Tsarist rule.",
    concepts:["Liberalism, radicalism and conservatism","Industrial society and socialist criticism","Karl Marx and Friedrich Engels","Tsarist Russia and the 1905 Revolution","February Revolution","Bolsheviks and Mensheviks","October Revolution","Civil War and formation of the USSR","Collectivisation under Stalin"],
    people:["Karl Marx","Friedrich Engels","Vladimir Lenin","Tsar Nicholas II","Joseph Stalin"],
    dates:["1905 — Revolution and Bloody Sunday","February 1917 — Tsar abdicates","October 1917 — Bolsheviks seize power","1922 — USSR formed"],
    questions:["How did socialism challenge capitalism?","What caused the 1905 Revolution?","Differentiate the February and October Revolutions.","What changed after the Bolshevik Revolution?"],
    answer:"For comparison questions, use a cause-event-result structure and clearly distinguish the February Revolution from the later Bolshevik seizure of power."
  },
  "Nazism and the Rise of Hitler": {
    summary:"The chapter explains how the Weimar Republic faced political instability, economic crisis and mass unemployment, creating conditions in which Hitler and the Nazi Party expanded. It also examines dictatorship, propaganda, racism, persecution and the Holocaust.",
    concepts:["Treaty of Versailles and the Weimar Republic","Hyperinflation and Great Depression","Nazi ideology and propaganda","Hitler's consolidation of power","Youth organisations and control of society","Racial persecution and the Holocaust","War and consequences"],
    people:["Adolf Hitler","Paul von Hindenburg","Joseph Goebbels"],
    dates:["1919 — Weimar Republic begins","1929 — Great Depression","1933 — Hitler becomes Chancellor","1935 — Nuremberg Laws","1939 — Second World War begins"],
    questions:["Why did the Weimar Republic face difficulties?","How did Hitler establish dictatorship?","How did Nazi racial ideology affect minorities?","What was the Holocaust?"],
    answer:"Explain Nazi rule through institutional control, propaganda, censorship, repression and racial laws, then connect these mechanisms to persecution and mass murder."
  },
  "Forest Society and Colonialism": {
    summary:"Colonial governments changed forest management to secure timber, revenue and strategic resources. These policies restricted customary use and reshaped the lives of forest communities in India and Southeast Asia.",
    concepts:["Commercial forestry","Scientific forestry","Forest Acts and reserved forests","Railways and timber demand","Bastar rebellion","Dutch policies in Java","Forest communities and resistance"],
    people:["Gunda Dhur","Colonial forest officials"],
    dates:["Late nineteenth century — expansion of scientific forestry","1910 — Bastar rebellion"],
    questions:["Why did colonial governments regulate forests?","What was scientific forestry?","Why did forest communities resist?"],
    answer:"Link forest laws to colonial commercial and strategic needs, then explain how restrictions on shifting cultivation, grazing and forest produce affected communities."
  },
  "Pastoralists in the Modern World": {
    summary:"Pastoral communities move with animals to use seasonal grazing resources. Colonial boundaries, forest laws, taxes and settlement policies narrowed mobility and changed pastoral livelihoods across regions.",
    concepts:["Seasonal migration","Grazing routes","Colonial forest and land policies","Criminal Tribes Act","Indian pastoral groups","Maasai in East Africa","Adaptation and resilience"],
    people:["Gujjar Bakarwals","Gaddis","Dhangars","Raikas","Maasai communities"],
    dates:["1871 — Criminal Tribes Act"],
    questions:["Why do pastoralists move?","How did colonial rule restrict pastoral mobility?","How did pastoralists adapt?"],
    answer:"Use a before/after structure: describe mobile pastoral production first, then show how laws, boundaries, taxes and changing markets altered mobility and livelihoods."
  }
};

const GEO_DETAIL = {
"India — Size and Location":{summary:"India occupies a central position in South Asia, extending from the Himalayas to the Indian Ocean. Its latitude, longitude, size and position influence climate, time and links with neighbouring countries.",concepts:["Tropic of Cancer","Standard Meridian 82°30'E","Indian Standard Time","Arabian Sea and Bay of Bengal","Land and maritime neighbours"],people:[],dates:["82°30'E — Standard Meridian of India"],questions:["Why is there a time difference between eastern and western India?","Why is India's location strategically important?"],answer:"India's longitudinal extent creates local time differences; a single standard meridian provides one official time for the country."},
"Physical Features of India":{summary:"India's relief reflects long geological processes. The major divisions are the Himalayas, Northern Plains, Peninsular Plateau, Indian Desert, Coastal Plains and Islands.",concepts:["Himalayan ranges","Northern Plains","Peninsular Plateau","Thar Desert","Western and Eastern Coastal Plains","Andaman and Nicobar, Lakshadweep"],people:[],dates:[],questions:["Compare the Himalayas and Peninsular Plateau.","How were the Northern Plains formed?"],answer:"The Northern Plains were formed largely by alluvial deposits brought by Himalayan and Peninsular river systems, making them extensive and fertile."},
"Drainage":{summary:"Drainage describes the river system of an area. India's rivers are grouped broadly into Himalayan and Peninsular systems, with differences in origin, flow and seasonal behaviour.",concepts:["Drainage basin","Water divide","Indus system","Ganga system","Brahmaputra system","Peninsular rivers","Lakes","River pollution"],people:[],dates:[],questions:["Distinguish Himalayan and Peninsular rivers.","Why are rivers important to people and ecosystems?"],answer:"Himalayan rivers are generally perennial because they receive water from snow and rain; many Peninsular rivers depend more strongly on seasonal rainfall."},
"Climate":{summary:"India has a monsoon climate shaped by latitude, altitude, pressure and winds, relief, distance from the sea and the seasonal reversal of winds.",concepts:["Weather and climate","Monsoon mechanism","Cold weather season","Hot weather season","Southwest monsoon","Retreating monsoon","Rainfall distribution"],people:[],dates:[],questions:["What factors influence India's climate?","Explain the main seasons of India."],answer:"The Indian monsoon involves a seasonal reversal of winds and uneven rainfall. Himalayan relief, the Indian Ocean and pressure patterns are important controls."},
"Natural Vegetation and Wildlife":{summary:"Natural vegetation varies with temperature and precipitation. India's forests and wildlife support ecological balance and livelihoods, but habitat loss and other pressures require conservation.",concepts:["Tropical evergreen","Tropical deciduous","Thorn forests","Montane vegetation","Mangroves","Biodiversity conservation"],people:[],dates:[],questions:["Where are tropical deciduous forests found?","Why is wildlife conservation important?"],answer:"Vegetation depends strongly on climatic conditions; conservation protects biodiversity, ecological functions and habitats."},
"Population":{summary:"Population geography studies size, distribution, density, growth, composition and movement. Census data help describe demographic patterns and support planning.",concepts:["Population density","Growth and change","Migration","Age composition","Sex ratio","Literacy","Occupational structure"],people:[],dates:["Census of India — decennial population enumeration"],questions:["What factors affect population distribution?","How does migration change population patterns?"],answer:"Relief, climate, water, soils, employment and transport influence distribution, while migration changes population size and composition across places."}
};

const CIVIC_DETAIL = {
"What is Democracy? Why Democracy?":{summary:"Democracy is a system in which rulers are chosen by the people and must remain accountable to them. The chapter examines key features, arguments for democracy and the limits or challenges of democratic decision-making.",concepts:["Elected representatives","Free and fair elections","Universal adult franchise","Rule of law","Accountability","Rights and participation"],people:[],dates:[],questions:["What makes a government democratic?","Why is democracy considered accountable?","What are some limitations of democracy?"],answer:"A democratic system requires meaningful participation, competition and choice, constitutional limits and accountability—not merely the existence of elections."},
"Constitutional Design":{summary:"A constitution establishes the basic rules and institutions of government and protects citizens' rights. The chapter uses South Africa and India's constitution-making experience to show why constitutional design matters.",concepts:["Constitution","Apartheid","Constituent Assembly","Preamble","Federalism","Fundamental rights","Institutional design"],people:["Nelson Mandela","B. R. Ambedkar","Jawaharlal Nehru"],dates:["26 November 1949 — Constitution adopted","26 January 1950 — Constitution came into force"],questions:["Why does a country need a constitution?","What values are expressed in the Preamble?"],answer:"A constitution defines powers, limits government, establishes institutions and expresses shared political values and citizens' rights."},
"Electoral Politics":{summary:"Elections provide a mechanism for citizens to choose representatives and replace governments. The chapter follows the election process from constituencies and voter lists to campaigning, polling and results.",concepts:["Constituency","Voter list","Nomination","Campaign","Polling","Election Commission","Reserved constituencies"],people:[],dates:[],questions:["Why are elections necessary in a democracy?","What makes an election democratic?"],answer:"Democratic elections require genuine choice, regularity, broad participation, fair procedures and the possibility of representatives being replaced."},
"Working of Institutions":{summary:"Democratic institutions divide responsibilities among the legislature, executive and judiciary. The chapter explains how major decisions are made and how constitutional checks operate.",concepts:["Parliament","Lok Sabha","Rajya Sabha","Executive","President","Prime Minister","Council of Ministers","Judiciary"],people:["President of India","Prime Minister of India","Chief Justice of India"],dates:[],questions:["Why is Parliament important?","How does the Council of Ministers work?","Why is an independent judiciary important?"],answer:"Institutions distribute authority and create checks so that decisions follow constitutional procedures rather than depending on one individual."},
"Democratic Rights":{summary:"Fundamental Rights protect essential freedoms and equality. The chapter explains the major rights in the Constitution and the importance of constitutional remedies when rights are violated.",concepts:["Right to Equality","Right to Freedom","Right against Exploitation","Freedom of Religion","Cultural and Educational Rights","Right to Constitutional Remedies"],people:[],dates:[],questions:["Why are Fundamental Rights important?","What is the Right to Constitutional Remedies?"],answer:"Rights protect citizens against arbitrary action and give them enforceable constitutional protections; remedies allow people to approach courts when rights are violated."}
};

const ECON_DETAIL = {
"The Story of Village Palampur":{summary:"Palampur illustrates how production depends on land, labour, physical capital and knowledge. Farming dominates, while non-farm activities provide additional livelihoods.",concepts:["Factors of production","Multiple cropping","Modern farming methods","Fixed and working capital","Small-scale manufacturing","Dairy","Transport"],people:[],dates:[],questions:["What are the factors of production?","How does multiple cropping increase output?"],answer:"Multiple cropping raises the use of the same land by growing more than one crop during a year, when water and other inputs permit."},
"People as Resource":{summary:"People become a productive resource when education, skills and health improve their ability to work. The chapter also examines economic activities and unemployment.",concepts:["Human capital","Education","Health","Market activities","Non-market activities","Seasonal unemployment","Disguised unemployment","Educated unemployment"],people:[],dates:[],questions:["How does education turn people into a resource?","What is disguised unemployment?"],answer:"Education and health improve knowledge, productivity and opportunities. Disguised unemployment occurs when more people work than are required for the existing level of output."},
"Poverty as a Challenge":{summary:"Poverty is more than low income: it can involve inadequate access to food, shelter, health, education and security. The chapter explores measurement, causes, vulnerable groups and anti-poverty measures.",concepts:["Poverty line","Multidimensional poverty","Vulnerability","Social exclusion","Rural and urban poverty","Anti-poverty programmes"],people:[],dates:[],questions:["Why is poverty multidimensional?","Who are vulnerable to poverty?","What approaches can reduce poverty?"],answer:"Poverty can involve several deprivations simultaneously. Reducing it requires income opportunities alongside access to education, health, food and social protection."},
"Food Security in India":{summary:"Food security exists when people have sufficient, accessible and affordable food. India uses procurement, buffer stocks and the Public Distribution System alongside other measures.",concepts:["Availability","Accessibility","Affordability","Buffer stock","FCI","MSP","PDS","Ration shops","Cooperatives"],people:[],dates:[],questions:["What are the three dimensions of food security?","What is buffer stock?","How does the PDS support food security?"],answer:"Availability means enough food exists; accessibility means people can obtain it; affordability means they can purchase it without losing access to other essential needs."}
};
