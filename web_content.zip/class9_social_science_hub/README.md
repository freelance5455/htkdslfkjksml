# Class 9 Social Science — Premium Learning Hub

A multi-file, responsive front-end starter for a Class 9 Social Science study platform.

## Run
Open `index.html` in a browser, or use a local server:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Files
- `index.html` — page structure and sections
- `styles.css` — premium responsive UI
- `data.js` — subject/chapter metadata and original chapter summaries
- `app.js` — search, filters, chapter modal, quiz, revision planner, local progress and reviews

## Backend integration points
The UI intentionally marks dynamic areas:
- `[AI Teacher Integration]`
- `[Dynamic Content]`
- `[Moderation/Admin]`

For production, add:
1. Server-side LLM integration (keep API keys off the client).
2. Database/CMS for complete chapter content.
3. Authentication and student profiles.
4. Question/answer database and quiz engine.
5. Map library for interactive geography/history maps.
6. Moderation workflow for student contributions.
7. Official-source metadata for current statistics and government programmes.

## Content note
The included summaries are original study aids, not a reproduction of textbook chapters. For the complete prescribed syllabus, students should use their current school textbook and official CBSE/NCERT materials as the primary references.
