package az.nt.hava;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;

public class Wx {
    static SharedPreferences sp(Context c) { return c.getSharedPreferences("nt", Context.MODE_PRIVATE); }

    static String[] desc(int c, boolean day) {
        if (c <= 1) return new String[]{day ? "☀️" : "🌙", "Açıq"};
        if (c == 2) return new String[]{day ? "⛅" : "☁️", "Az buludlu"};
        if (c == 3) return new String[]{"☁️", "Buludlu"};
        if (c <= 48) return new String[]{"🌫️", "Dumanlı"};
        if (c <= 57) return new String[]{"🌦️", "Çiskin"};
        if (c <= 67) return new String[]{"🌧️", "Yağış"};
        if (c <= 77) return new String[]{"🌨️", "Qar"};
        if (c <= 82) return new String[]{"🌦️", "Leysan"};
        if (c <= 86) return new String[]{"🌨️", "Qar yağışı"};
        return new String[]{"⛈️", "Tufan"};
    }

    static String temp(double c, String u) {
        return Math.round("F".equals(u) ? c * 9 / 5 + 32 : c) + "°";
    }

    static JSONObject fetch(Context ctx) throws Exception {
        SharedPreferences p = sp(ctx);
        String url = "https://api.open-meteo.com/v1/forecast?latitude=" + p.getString("lat", "40.4093")
            + "&longitude=" + p.getString("lon", "49.8671")
            + "&current=temperature_2m,weather_code,is_day&hourly=precipitation_probability"
            + "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=2";
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(10000);
        h.setReadTimeout(10000);
        BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String l;
        while ((l = r.readLine()) != null) sb.append(l);
        r.close();
        return new JSONObject(sb.toString());
    }

    static String[] morning(Context c) throws Exception {
        SharedPreferences p = sp(c);
        JSONObject j = fetch(c);
        JSONObject cur = j.getJSONObject("current");
        JSONObject d = j.getJSONObject("daily");
        String u = p.getString("u", "C");
        String[] ds = desc(cur.getInt("weather_code"), cur.getInt("is_day") == 1);
        double mx = d.getJSONArray("temperature_2m_max").getDouble(0);
        double mn = d.getJSONArray("temperature_2m_min").getDouble(0);
        int pr = d.getJSONArray("precipitation_probability_max").optInt(0);
        String tip = pr >= 50 ? "☂️ Çətir götürün" : mx < 10 ? "🧥 İsti geyinin" : mx >= 28 ? "🕶️ Çox su için" : "🙂 Gözəl gün";
        String title = "Sabahınız xeyir! " + p.getString("city", "") + " · " + ds[0] + " " + temp(cur.getDouble("temperature_2m"), u);
        String body = ds[1] + ", " + temp(mn, u) + " – " + temp(mx, u) + " · 💧" + pr + "% · " + tip;
        return new String[]{title, body};
    }

    static String rain(Context c) throws Exception {
        SharedPreferences p = sp(c);
        JSONObject j = fetch(c);
        String now = j.getJSONObject("current").getString("time").substring(0, 13);
        JSONArray t = j.getJSONObject("hourly").getJSONArray("time");
        JSONArray pr = j.getJSONObject("hourly").getJSONArray("precipitation_probability");
        int i0 = 0;
        for (int i = 0; i < t.length(); i++) {
            if (t.getString(i).compareTo(now) >= 0) { i0 = i; break; }
        }
        for (int k = 0; k < 4 && i0 + k < t.length(); k++) {
            int v = pr.optInt(i0 + k, 0);
            if (v >= 60) {
                String key = t.getString(i0 + k);
                if (key.equals(p.getString("lastRain", ""))) return null;
                p.edit().putString("lastRain", key).apply();
                return p.getString("city", "") + ": " + key.substring(11, 16) + " radələrində yağış başlaya bilər (" + v + "%). Çətir götürün ☂️";
            }
        }
        return null;
    }

    static void notify(Context c, int id, String title, String text) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("wx", "Hava bildirişləri", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent i = new Intent(c, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, "wx") : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle(title).setContentText(text)
            .setStyle(new Notification.BigTextStyle().bigText(text)).setContentIntent(pi).setAutoCancel(true);
        nm.notify(id, b.build());
    }

    static PendingIntent pend(Context c, String action, int rc, int flag) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction(action);
        return PendingIntent.getBroadcast(c, rc, i, flag | PendingIntent.FLAG_IMMUTABLE);
    }

    static void setAt(Context c, long t, PendingIntent pi) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
        else am.set(AlarmManager.RTC_WAKEUP, t, pi);
    }

    static void armMorning(Context c) {
        SharedPreferences p = sp(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pend(c, "morning", 101, PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(pi);
        if (!p.getBoolean("m", false)) return;
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, p.getInt("h", 7));
        t.set(Calendar.MINUTE, p.getInt("mi", 30));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis() + 1000) t.add(Calendar.DAY_OF_YEAR, 1);
        setAt(c, t.getTimeInMillis(), pi);
    }

    static void armRain(Context c) {
        SharedPreferences p = sp(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pend(c, "rain", 102, PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(pi);
        if (!p.getBoolean("r", false)) return;
        setAt(c, System.currentTimeMillis() + 45 * 60000L, pi);
    }

    static void widgets(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, WeatherWidget.class));
        if (ids.length > 0) {
            Intent i = new Intent(c, WeatherWidget.class);
            i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            c.sendBroadcast(i);
        }
    }
}
