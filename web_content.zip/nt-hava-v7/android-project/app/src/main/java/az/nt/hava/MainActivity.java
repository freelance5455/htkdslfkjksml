package az.nt.hava;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    WebView w;
    final Handler hd = new Handler(Looper.getMainLooper());
    boolean waiting = false;
    LocationListener ll;

    boolean has() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void js(final String code) {
        runOnUiThread(new Runnable() { public void run() { w.evaluateJavascript(code, null); } });
    }

    void send(Location l) {
        js("onLoc(" + l.getLatitude() + "," + l.getLongitude() + "," + (int) l.getAccuracy() + ")");
    }

    void fetchLoc() {
        if (!has()) { js("onLoc(null,null,'perm')"); return; }
        final LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        Location best = null;
        String[] provs = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
        for (String p : provs) {
            try {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            } catch (Exception e) { }
        }
        if (best != null && System.currentTimeMillis() - best.getTime() < 120000) { send(best); return; }
        final Location fb = best;
        String prov = null;
        try { if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) prov = LocationManager.GPS_PROVIDER; } catch (Exception e) { }
        try { if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) prov = LocationManager.NETWORK_PROVIDER; } catch (Exception e) { }
        if (prov == null) {
            if (fb != null) send(fb); else js("onLoc(null,null,'off')");
            return;
        }
        waiting = true;
        ll = new LocationListener() {
            public void onLocationChanged(Location l) {
                if (!waiting) return;
                waiting = false;
                lm.removeUpdates(this);
                send(l);
            }
            public void onStatusChanged(String p, int s, Bundle b) { }
            public void onProviderEnabled(String p) { }
            public void onProviderDisabled(String p) { }
        };
        try {
            lm.requestSingleUpdate(prov, ll, Looper.getMainLooper());
        } catch (Exception e) {
            waiting = false;
            if (fb != null) send(fb); else js("onLoc(null,null,'err')");
            return;
        }
        hd.postDelayed(new Runnable() {
            public void run() {
                if (waiting) {
                    waiting = false;
                    lm.removeUpdates(ll);
                    if (fb != null) send(fb); else js("onLoc(null,null,'time')");
                }
            }
        }, 12000);
    }

    void askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(new Runnable() { public void run() {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
            } });
        }
    }

    class Bridge {
        @JavascriptInterface public boolean hasPerm() { return has(); }
        @JavascriptInterface public void askPerm() {
            runOnUiThread(new Runnable() { public void run() {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            } });
        }
        @JavascriptInterface public void setAlerts(String json) {
            try {
                JSONObject o = new JSONObject(json);
                SharedPreferences p = Wx.sp(MainActivity.this);
                boolean m = o.optBoolean("m"), r = o.optBoolean("r");
                int h = o.optInt("h", 7), mi = o.optInt("mi", 30);
                String lat = String.valueOf(o.optDouble("lat")), lon = String.valueOf(o.optDouble("lon"));
                boolean chM = p.getBoolean("m", false) != m || p.getInt("h", 7) != h || p.getInt("mi", 30) != mi;
                boolean chR = p.getBoolean("r", false) != r;
                boolean chL = !lat.equals(p.getString("lat", "")) || !lon.equals(p.getString("lon", ""));
                p.edit().putString("lat", lat).putString("lon", lon).putString("city", o.optString("city"))
                    .putString("u", o.optString("u", "C")).putBoolean("m", m).putBoolean("r", r)
                    .putInt("h", h).putInt("mi", mi).apply();
                if (chM) Wx.armMorning(MainActivity.this);
                if (chR) Wx.armRain(MainActivity.this);
                if (chL) Wx.widgets(MainActivity.this);
                if (o.optInt("ask") == 1 && (m || r)) askNotif();
            } catch (Exception e) { }
        }
        @JavascriptInterface public void testNotif() {
            askNotif();
            new Thread(new Runnable() { public void run() {
                try {
                    String[] m = Wx.morning(MainActivity.this);
                    Wx.notify(MainActivity.this, 3, m[0], m[1]);
                } catch (Exception e) {
                    Wx.notify(MainActivity.this, 3, "NT Hava", "Məlumat alınmadı — internetə baxın");
                }
            } }).start();
        }
        @JavascriptInterface public void shareImage(String b64) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "share");
                dir.mkdirs();
                FileOutputStream fo = new FileOutputStream(new File(dir, "card.png"));
                fo.write(bytes);
                fo.close();
                runOnUiThread(new Runnable() { public void run() {
                    Uri uri = Uri.parse("content://az.nt.hava.share/card.png");
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/png");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.putExtra(Intent.EXTRA_TEXT, "NT Hava");
                    send.setClipData(ClipData.newRawUri("", uri));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "Paylaş"));
                } });
            } catch (Exception e) { }
        }
        @JavascriptInterface public void getLoc() {
            runOnUiThread(new Runnable() { public void run() { fetchLoc(); } });
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#1e6fd9"));
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);
        w.addJavascriptInterface(new Bridge(), "Android");
        w.setWebViewClient(new WebViewClient());
        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String o, GeolocationPermissions.Callback c) { c.invoke(o, true, false); }
        });
        w.loadUrl("file:///android_asset/index.html");
        if (!has()) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] g) {
        if (rc != 1) return;
        boolean ok = false;
        for (int r : g) if (r == PackageManager.PERMISSION_GRANTED) ok = true;
        js("window.onPerm&&onPerm(" + ok + ")");
    }

    @Override public void onBackPressed() { if (w.canGoBack()) w.goBack(); else super.onBackPressed(); }
}
