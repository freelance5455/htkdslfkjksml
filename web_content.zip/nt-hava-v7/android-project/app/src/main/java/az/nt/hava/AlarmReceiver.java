package az.nt.hava;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(final Context c, Intent in) {
        final String a = in.getAction();
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            public void run() {
                try {
                    SharedPreferences p = Wx.sp(c);
                    if (Intent.ACTION_BOOT_COMPLETED.equals(a)) {
                        Wx.armMorning(c);
                        Wx.armRain(c);
                        Wx.widgets(c);
                    } else if ("morning".equals(a)) {
                        try {
                            if (p.getBoolean("m", false)) {
                                String[] m = Wx.morning(c);
                                Wx.notify(c, 1, m[0], m[1]);
                            }
                        } finally { Wx.armMorning(c); }
                    } else if ("rain".equals(a)) {
                        try {
                            if (p.getBoolean("r", false)) {
                                String m = Wx.rain(c);
                                if (m != null) Wx.notify(c, 2, "🌧 Yağış xəbərdarlığı", m);
                            }
                        } finally { Wx.armRain(c); }
                    }
                } catch (Exception e) { }
                pr.finish();
            }
        }).start();
    }
}
