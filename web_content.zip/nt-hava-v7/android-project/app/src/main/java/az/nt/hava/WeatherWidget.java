package az.nt.hava;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import org.json.JSONObject;

public class WeatherWidget extends AppWidgetProvider {
    @Override public void onUpdate(final Context c, final AppWidgetManager m, final int[] ids) {
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            public void run() {
                SharedPreferences p = Wx.sp(c);
                try {
                    if (p.contains("lat")) {
                        JSONObject j = Wx.fetch(c);
                        JSONObject cur = j.getJSONObject("current");
                        JSONObject d = j.getJSONObject("daily");
                        boolean day = cur.getInt("is_day") == 1;
                        String[] ds = Wx.desc(cur.getInt("weather_code"), day);
                        String u = p.getString("u", "C");
                        int rain = d.getJSONArray("precipitation_probability_max").optInt(0);
                        String hl = "↑" + Wx.temp(d.getJSONArray("temperature_2m_max").getDouble(0), u)
                            + " ↓" + Wx.temp(d.getJSONArray("temperature_2m_min").getDouble(0), u);
                        p.edit().putString("w_city", p.getString("city", "NT Hava"))
                            .putString("w_temp", Wx.temp(cur.getDouble("temperature_2m"), u))
                            .putString("w_icon", ds[0])
                            .putString("w_desc", ds[1] + " · " + hl)
                            .putString("w_rain", "💧 " + rain + "% yağış")
                            .putBoolean("w_day", day).apply();
                    }
                } catch (Exception e) { }
                RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
                v.setTextViewText(R.id.w_city, p.getString("w_city", "NT Hava"));
                v.setTextViewText(R.id.w_temp, p.getString("w_temp", "--"));
                v.setTextViewText(R.id.w_icon, p.getString("w_icon", "🌤️"));
                v.setTextViewText(R.id.w_desc, p.getString("w_desc", "Tətbiqi açın"));
                v.setTextViewText(R.id.w_rain, p.getString("w_rain", ""));
                v.setInt(R.id.w_root, "setBackgroundResource",
                    p.getBoolean("w_day", true) ? R.drawable.widget_bg : R.drawable.widget_bg_night);
                Intent i = new Intent(c, MainActivity.class);
                v.setOnClickPendingIntent(R.id.w_root,
                    PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
                for (int id : ids) m.updateAppWidget(id, v);
                pr.finish();
            }
        }).start();
    }
}
