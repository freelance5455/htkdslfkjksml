NT HAVA v7

web/index.html  -> brauzerde birbasa acin (internet lazimdir)

android-project -> APK hazirlamaq ucun:
 1) Android Studio qurun (pulsuzdur) ve "Open" ile android-project qovlugunu secin
 2) Gradle sync bitenden sonra: Build > Build Bundle(s) / APK(s) > Build APK(s)
 3) APK burada olacaq: app/build/outputs/apk/debug/app-debug.apk
 4) Telefona gonderin ve qurun (namelum menbelerden qurulmaya icaze verin)

Qeyd: Telefonda mekan duzgun islemesi ucun APK versiyasindan istifade edin.
Brauzerde acanda mekan icazesi bezi telefonlarda (fayl menecerinden acilanda) isleme biler.

Yeni (v7): yagis bildirisi, seher xeberdarligi (🔔 duymesi), esas ekran vidceti, hava kartini sekil kimi paylasma (📤).
Vidget: telefonun esas ekraninda uzun basin > Vidcetler > NT Hava.
Bildirisler yalniz APK versiyasinda arxa planda isleyir.
