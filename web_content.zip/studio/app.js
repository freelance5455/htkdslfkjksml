'use strict';
/* ANIME CARD CREATOR STUDIO — vanilla JS.
   Sections: 1 i18n · 2 data · 3 rules/validation · 4 renderer (canvas) · 5 description builder ·
   6 image generator · 7 state/history · 8 storage/export · 9 UI wiring.
   Custom game rules inspired by trading-card mechanics — NOT tournament-legal. */

const $ = id => document.getElementById(id);
const TYPES = ['normal','effect','fusion','ritual','synchro','xyz','pendulum','link','spell','trap'];
const COLORS = {normal:'#e8b923',effect:'#ff6a1a',fusion:'#a24bf0',ritual:'#2e8ff0',synchro:'#d8d8e4',xyz:'#666',pendulum:'#1fb89a',link:'#1f6fe0',spell:'#1fa070',trap:'#c02aa8'};
const ATTR_COLORS = {LIGHT:'#f3d34a',DARK:'#7a4ab0',EARTH:'#8a6a3a',WATER:'#3a8ae0',FIRE:'#e0452a',WIND:'#4ab060',DIVINE:'#d9b13b'};
const SUBS = {spell:['Normal','Continuous','Equip','Field','Quick-Play','Ritual'], trap:['Normal','Continuous','Counter']};
const isMonster = t => !['spell','trap'].includes(t);

/* ---------- 1. i18n ---------- */
const I18N = {
 en:{create:'Create',gallery:'My Cards',settings:'Settings',name:'Card name',concept:'Concept / description',attr:'Attribute',mtype:'Monster type',sub:'Category',linkRating:'Link rating',arrows:'Link arrows',materials:'Summoning materials / requirement',pEffect:'Pendulum effect',effect:'Effect',flavor:'Flavor text',font:'Font size',align:'Text alignment',num:'Card no.',artwork:'Artwork',upload:'Upload image',generate:'Generate art (AI)',clearArt:'Remove',autofill:'Suggest text (editable)',save:'Save',dup:'Duplicate',reset:'Reset',previewZoom:'Preview zoom',exportPng:'Export PNG',exportJson:'Export JSON',importJson:'Import JSON',print:'Print',scaleL:'Left scale',scaleR:'Right scale',level:'Level',rank:'Rank',
  t_normal:'Normal',t_effect:'Effect',t_fusion:'Fusion',t_ritual:'Ritual',t_synchro:'Synchro',t_xyz:'Xyz',t_pendulum:'Pendulum',t_link:'Link',t_spell:'Spell',t_trap:'Trap',empty:'No saved cards yet.',saved:'Saved',valid:'Card is valid.'},
 ar:{create:'إنشاء',gallery:'بطاقاتي',settings:'الإعدادات',name:'اسم البطاقة',concept:'الفكرة / الوصف',attr:'الخاصية',mtype:'نوع الوحش',sub:'الفئة',linkRating:'تصنيف الرابط',arrows:'أسهم الرابط',materials:'مواد الاستدعاء / الشرط',pEffect:'تأثير البندول',effect:'التأثير',flavor:'نص وصفي',font:'حجم الخط',align:'محاذاة النص',num:'رقم البطاقة',artwork:'الصورة',upload:'رفع صورة',generate:'توليد صورة (AI)',clearArt:'حذف',autofill:'اقتراح نص (قابل للتعديل)',save:'حفظ',dup:'نسخ',reset:'إعادة ضبط',previewZoom:'تكبير المعاينة',exportPng:'تصدير PNG',exportJson:'تصدير JSON',importJson:'استيراد JSON',print:'طباعة',scaleL:'المقياس الأيسر',scaleR:'المقياس الأيمن',level:'المستوى',rank:'الرتبة',
  t_normal:'عادي',t_effect:'بتأثير',t_fusion:'اندماج',t_ritual:'طقوس',t_synchro:'تزامن',t_xyz:'إكسيز',t_pendulum:'بندول',t_link:'رابط',t_spell:'سحر',t_trap:'فخ',empty:'لا توجد بطاقات محفوظة.',saved:'تم الحفظ',valid:'البطاقة صالحة.'},
 fr:{create:'Créer',gallery:'Mes cartes',settings:'Réglages',name:'Nom de la carte',concept:'Concept / description',attr:'Attribut',mtype:'Type de monstre',sub:'Catégorie',linkRating:'Valeur Lien',arrows:'Flèches Lien',materials:'Matériaux / condition d’invocation',pEffect:'Effet Pendule',effect:'Effet',flavor:'Texte d’ambiance',font:'Taille du texte',align:'Alignement',num:'N° de carte',artwork:'Illustration',upload:'Importer une image',generate:'Générer (IA)',clearArt:'Retirer',autofill:'Suggérer un texte (modifiable)',save:'Enregistrer',dup:'Dupliquer',reset:'Réinitialiser',previewZoom:'Zoom aperçu',exportPng:'Exporter PNG',exportJson:'Exporter JSON',importJson:'Importer JSON',print:'Imprimer',scaleL:'Échelle gauche',scaleR:'Échelle droite',level:'Niveau',rank:'Rang',
  t_normal:'Normal',t_effect:'Effet',t_fusion:'Fusion',t_ritual:'Rituel',t_synchro:'Synchro',t_xyz:'Xyz',t_pendulum:'Pendule',t_link:'Lien',t_spell:'Magie',t_trap:'Piège',empty:'Aucune carte enregistrée.',saved:'Enregistré',valid:'Carte valide.'}
};
let lang = localStorage.getItem('acs_lang') || 'en';
const t = k => (I18N[lang] && I18N[lang][k]) || I18N.en[k] || k;
function applyLang() {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-i18n]').forEach(e => e.textContent = t(e.dataset.i18n));
  $('lvlLabel').textContent = t(S.type === 'xyz' ? 'rank' : 'level');
  buildTypeBar(); renderGallery();
}

/* ---------- 2. data ---------- */
const newCard = (type = 'normal') => ({
  id: 'c' + Date.now() + Math.random().toString(36).slice(2, 6), type, name: '', concept: '', attr: 'LIGHT', mtype: '', sub: 'Normal',
  level: 4, atk: '', def: '', scaleL: 4, scaleR: 4, link: 2, arrows: [1,0,0,0,1,0,0,0], materials: '', pEffect: '', effect: '', flavor: '',
  font: 9, align: 'left', num: '', image: null, zoom: 1, ox: 0, oy: 0
});
let S = newCard();
const FIELDS = ['name','concept','attr','mtype','sub','level','atk','def','scaleL','scaleR','link','materials','pEffect','effect','flavor','font','align','num','zoom','ox','oy'];
const NUMERIC = ['level','scaleL','scaleR','link','font','zoom','ox','oy'];

/* ---------- 3. rules / validation ---------- */
function validate(c) {
  const out = [], err = m => out.push({l:'err', m}), warn = m => out.push({l:'warn', m});
  const has = v => String(v ?? '').trim() !== '';
  const T = c.type;
  if (!has(c.name)) err('Card name is required.');
  if (isMonster(T)) {
    if (!has(c.mtype)) err('Monster type is required (e.g. Dragon).');
    if (!has(c.atk) || +c.atk < 0) err('ATK is required (0 or more). It is never filled in automatically.');
    if (T !== 'link' && (!has(c.def) || +c.def < 0)) err('DEF is required (0 or more).');
    if (T !== 'link' && (c.level < 1 || c.level > 13)) err((T === 'xyz' ? 'Rank' : 'Level') + ' must be between 1 and 13.');
  }
  const eff = has(c.effect);
  if (T === 'normal') { if (eff) err('Normal Monsters cannot have gameplay effects — use flavor text only.'); if (!has(c.flavor)) err('A flavor description is required.'); }
  if (T === 'effect') { if (!eff) err('Effect Monsters need an effect.'); }
  if (T === 'fusion' && !has(c.materials)) err('Fusion Monsters must list their Fusion materials (e.g. 2 Dragon monsters).');
  if (T === 'ritual' && !has(c.materials)) err('Ritual Monsters must state the Ritual Spell / tribute requirement.');
  if (T === 'synchro') { if (!has(c.materials)) err('Synchro Monsters need materials.'); else if (!/tuner/i.test(c.materials)) err('Synchro materials must include a Tuner (e.g. 1 Tuner + 1 or more non-Tuner monsters).'); }
  if (T === 'xyz' && !has(c.materials)) err('Xyz Monsters must list materials (e.g. 2 Level 4 monsters).');
  if (T === 'pendulum') {
    [c.scaleL, c.scaleR].forEach(v => { if (!Number.isInteger(+v) || v < 0 || v > 13) err('Pendulum Scales must be whole numbers from 0 to 13.'); });
    if (!has(c.pEffect)) warn('No Pendulum Effect written.');
  }
  if (T === 'link') {
    if (!Number.isInteger(+c.link) || c.link < 1 || c.link > 8) err('Link rating must be 1–8.');
    const n = c.arrows.filter(Boolean).length;
    if (n !== +c.link) err(`Link rating (${c.link}) must equal the number of Link Arrows selected (${n}).`);
    if (!has(c.materials)) err('Link Monsters must list Link materials (e.g. 2+ Effect Monsters).');
  }
  if (!isMonster(T)) { if (!eff) err('Spell/Trap cards need activation text.'); if (!SUBS[T].includes(c.sub)) err('Choose a valid category.'); }
  if (eff && T !== 'normal' && !/(once|when|if|during|you can|target|cannot|gain|each|activate|while|negate)/i.test(c.effect)) warn('The effect should state a clear condition and outcome.');
  if (!out.some(o => o.l === 'err')) out.unshift({l:'ok', m:t('valid')});
  return out;
}

/* ---------- 4. renderer (canvas, base frame 286×432) ---------- */
const BASE_W = 286, BASE_H = 432;
const DEF_CAL = {ax:30, ay:72, aw:219, ah:217};
let CAL = Object.assign({}, DEF_CAL, JSON.parse(localStorage.getItem('acs_cal') || '{}'));
const tplImgs = {}, artCache = new Map();
function loadImg(src) { return new Promise(r => { const i = new Image(); i.onload = () => r(i); i.onerror = () => r(null); i.src = src; }); }
async function loadTemplates() {
  await Promise.all(TYPES.map(async k => { tplImgs[k] = await loadImg((window.TEMPLATE_DATA && TEMPLATE_DATA[k]) || `assets/templates/${k}.png`); }));
  draw();
}
async function getArt(src) {
  if (!src) return null;
  if (!artCache.has(src)) artCache.set(src, await loadImg(src));
  return artCache.get(src);
}
function wrap(ctx, text, maxW) {
  const lines = [];
  String(text).split('\n').forEach(par => {
    let cur = '';
    par.split(/\s+/).forEach(w => { const test = cur ? cur + ' ' + w : w; if (ctx.measureText(test).width > maxW && cur) { lines.push(cur); cur = w; } else cur = test; });
    lines.push(cur);
  });
  return lines;
}
function bodyText(c) {
  const T = c.type;
  const j = a => a.filter(x => String(x || '').trim()).join('\n');
  if (T === 'normal') return c.flavor;
  if (T === 'pendulum') return j([c.pEffect && '[Pendulum Effect] ' + c.pEffect, c.materials, c.effect && '[Monster Effect] ' + c.effect]);
  if (['fusion','ritual','synchro','xyz','link'].includes(T)) return j([c.materials, c.effect]);
  return c.effect;
}
function typeLine(c) {
  if (!isMonster(c.type)) return '';
  const sub = {normal:'Normal',effect:'Effect',fusion:'Fusion',ritual:'Ritual',synchro:'Synchro',xyz:'Xyz',pendulum:'Pendulum',link:'Link'}[c.type];
  const parts = [c.mtype || '?', sub];
  if (!['normal','effect'].includes(c.type) && String(c.effect).trim()) parts.push('Effect');
  return '[' + parts.join(' / ') + ']';
}
function star(ctx, x, y, r) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * .45 : r; ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); }
  ctx.closePath(); ctx.fillStyle = '#ffb41f'; ctx.fill(); ctx.strokeStyle = '#7a3a00'; ctx.lineWidth = .7; ctx.stroke();
}
function fitFont(ctx, text, maxW, size, weight, family) {
  do { ctx.font = `${weight} ${size}px ${family}`; if (ctx.measureText(text).width <= maxW) break; size -= .5; } while (size > 7);
  return size;
}
/* Draws the full card on ctx at scale k (k=2 preview, k=4 export). */
function drawCard(ctx, c, art, k) {
  const W = BASE_W * k, H = BASE_H * k;
  ctx.save(); ctx.clearRect(0, 0, W, H); ctx.scale(k, k);
  const tpl = tplImgs[c.type];
  if (tpl) ctx.drawImage(tpl, 0, 0, BASE_W, BASE_H);
  const SERIF = 'Georgia, "Times New Roman", serif', SANS = '"Segoe UI", Tahoma, Arial, sans-serif';
  // artwork window
  const {ax, ay, aw, ah} = CAL;
  ctx.save(); ctx.beginPath(); ctx.rect(ax, ay, aw, ah); ctx.clip();
  if (art) {
    const sc = Math.max(aw / art.width, ah / art.height) * c.zoom, w = art.width * sc, h = art.height * sc;
    ctx.drawImage(art, ax + (aw - w) / 2 + c.ox / 100 * aw / 2, ay + (ah - h) / 2 + c.oy / 100 * ah / 2, w, h);
  } else {
    const g = ctx.createLinearGradient(0, ay, 0, ay + ah); g.addColorStop(0, '#1a2050'); g.addColorStop(1, '#0a0d24');
    ctx.fillStyle = g; ctx.fillRect(ax, ay, aw, ah);
    ctx.fillStyle = '#ffffff44'; ctx.font = `14px ${SANS}`; ctx.textAlign = 'center'; ctx.fillText('NO ARTWORK', ax + aw / 2, ay + ah / 2);
  }
  // pendulum scales & link arrows live inside the artwork window
  if (c.type === 'pendulum') {
    [[ax, '#2a7fff', c.scaleL], [ax + aw - 24, '#ff3b3b', c.scaleR]].forEach(([x, col, v]) => {
      ctx.fillStyle = col; ctx.fillRect(x, ay + ah - 36, 24, 36); ctx.fillStyle = '#fff'; ctx.font = `bold 16px ${SANS}`; ctx.textAlign = 'center'; ctx.fillText(v, x + 12, ay + ah - 12);
    });
  }
  if (c.type === 'link') {
    const P = [[ax + aw / 2, ay + 8, 0], [ax + aw - 9, ay + 9, 45], [ax + aw - 8, ay + ah / 2, 90], [ax + aw - 9, ay + ah - 9, 135],
               [ax + aw / 2, ay + ah - 8, 180], [ax + 9, ay + ah - 9, 225], [ax + 8, ay + ah / 2, 270], [ax + 9, ay + 9, 315]];
    P.forEach(([x, y, a], i) => {
      ctx.save(); ctx.translate(x, y); ctx.rotate(a * Math.PI / 180); ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(8, 6); ctx.lineTo(-8, 6); ctx.closePath();
      ctx.fillStyle = c.arrows[i] ? '#ff2a2a' : '#00000066'; ctx.fill(); ctx.strokeStyle = c.arrows[i] ? '#fff' : '#ffffff55'; ctx.lineWidth = 1; ctx.stroke(); ctx.restore();
    });
  }
  ctx.restore();
  // name
  const light = ['xyz','link'].includes(c.type);
  ctx.textAlign = 'left'; ctx.fillStyle = light ? '#fff' : '#111';
  const nm = c.name || 'CARD NAME', hasAttr = isMonster(c.type);
  const nSize = fitFont(ctx, nm, hasAttr ? 205 : 228, 17, 'bold', SERIF); ctx.font = `bold ${nSize}px ${SERIF}`;
  ctx.fillText(nm, 24, 39 - (17 - nSize) / 3);
  if (hasAttr) { // attribute badge
    ctx.beginPath(); ctx.arc(250, 33, 10, 0, 7); ctx.fillStyle = ATTR_COLORS[c.attr] || '#999'; ctx.fill(); ctx.strokeStyle = '#222'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.fillStyle = '#111'; ctx.font = `bold 7px ${SANS}`; ctx.textAlign = 'center'; ctx.fillText(c.attr.slice(0, 3), 250, 35.5);
  }
  // stars / subtitle
  if (isMonster(c.type) && c.type !== 'link') {
    const n = Math.max(0, Math.min(13, +c.level || 0)), r = 5.6;
    for (let i = 0; i < n; i++) star(ctx, c.type === 'xyz' ? 34 + i * 12.4 : 238 - i * 12.4, 61, r);
  } else if (!isMonster(c.type)) {
    ctx.textAlign = 'right'; ctx.fillStyle = '#111'; ctx.font = `italic bold 9px ${SERIF}`;
    ctx.fillText(`[${c.type === 'spell' ? 'Spell' : 'Trap'} Card]  ${c.sub}`, 252, 64);
  }
  // description box
  const bx = 26, bw = 232, by = 306, bottom = isMonster(c.type) ? 380 : 392;
  ctx.fillStyle = '#111'; ctx.textAlign = 'left';
  let y = by + 11;
  const tl = typeLine(c);
  if (tl) { ctx.font = `bold 8.5px ${SANS}`; ctx.fillText(tl, bx, y); y += 4; }
  const text = bodyText(c) || (isMonster(c.type) ? '…' : '');
  let fs = +c.font || 9, lines, lh;
  do { ctx.font = `${fs}px ${SANS}`; lines = wrap(ctx, text, bw); lh = fs * 1.18; fs -= .5; } while (fs >= 5.5 && y + lines.length * lh > bottom);
  ctx.textAlign = c.align; const tx = c.align === 'left' ? bx : c.align === 'right' ? bx + bw : bx + bw / 2;
  lines.forEach((ln, i) => ctx.fillText(ln, tx, y + (i + 1) * lh - 2));
  // stats
  if (isMonster(c.type)) {
    ctx.textAlign = 'right'; ctx.font = `bold 10.5px ${SANS}`; ctx.fillStyle = '#111';
    const atk = c.atk === '' ? '?' : c.atk, def = c.def === '' ? '?' : c.def;
    ctx.fillText(c.type === 'link' ? `ATK/${atk}    LINK-${c.link}` : `ATK/${atk}   DEF/${def}`, 256, 392);
  }
  if (c.num) { ctx.textAlign = 'left'; ctx.fillStyle = '#000a'; ctx.font = `6.5px ${SANS}`; ctx.fillText(c.num, 20, 424); }
  ctx.restore();
}
let drawToken = 0;
async function draw() {
  const tok = ++drawToken, art = await getArt(S.image);
  if (tok !== drawToken) return;
  const cv = $('card'); cv.width = BASE_W * 2; cv.height = BASE_H * 2;
  drawCard(cv.getContext('2d'), S, art, 2);
  showValidation();
}
function showValidation() {
  $('validation').innerHTML = validate(S).map(v => `<li class="${v.l}"></li>`).join('');
  [...$('validation').children].forEach((li, i) => li.textContent = validate(S)[i].m);
}

/* ---------- 5. description builder (local templates, or optional AI endpoint) ---------- */
function localSuggestions(c) {
  const nm = c.name || 'this card', mt = c.mtype || 'monster', f = {};
  const T = c.type;
  if (T === 'normal') f.flavor = `${c.concept || 'A legendary ' + mt + ' of the battlefield.'}`;
  if (T === 'effect') f.effect = 'Once per turn: You can target 1 card your opponent controls; destroy it.';
  if (T === 'fusion') f.materials = `2 ${mt} monsters`;
  if (T === 'ritual') f.materials = `You can Ritual Summon this card with "${nm} Ritual" Spell Card.`;
  if (T === 'synchro') f.materials = '1 Tuner + 1 or more non-Tuner monsters';
  if (T === 'xyz') f.materials = `2 Level ${c.level} monsters`;
  if (T === 'link') f.materials = '2+ Effect Monsters';
  if (T === 'pendulum') { f.pEffect = `Once per turn: You can add 1 "${mt}" monster from your Deck to your hand.`; f.effect = 'If this card is Summoned: You can draw 1 card.'; }
  if (T === 'spell') f.effect = 'Activate only during your Main Phase: Target 1 monster you control; it gains 500 ATK until the end of this turn.';
  if (T === 'trap') f.effect = 'When your opponent activates a card or effect: You can pay 500 LP; negate the activation.';
  return f;
}
async function suggestText() {
  let f = null; const ep = localStorage.getItem('acs_txt');
  if (ep) {
    try { const r = await fetch(ep, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({type:S.type, name:S.name, concept:S.concept, mtype:S.mtype, sub:S.sub, level:S.level})});
      if (!r.ok) throw new Error(r.status); f = (await r.json()).fields; } catch (e) { toast('AI text endpoint failed (' + e.message + ') — using local templates.'); }
  }
  f = f || localSuggestions(S);
  let n = 0; for (const k in f) if (!String(S[k]).trim() && FIELDS.includes(k)) { S[k] = f[k]; n++; }  // never overwrite user text
  syncForm(); commit(); toast(n ? 'Suggestions added to empty fields — edit them freely. ATK/DEF are never invented.' : 'Fields already filled; nothing overwritten.');
}

/* ---------- 6. image generation (needs a real backend) ---------- */
async function generateArt() {
  const ep = localStorage.getItem('acs_img'), msg = $('genMsg');
  if (!ep) { msg.textContent = 'No image-generation service is configured (Settings). Please upload artwork instead.'; return; }
  msg.textContent = 'Generating…';
  try {
    const prompt = `Anime-style trading-card artwork, centered subject, no text, no borders, portrait framing. ${S.name}. ${S.concept}`;
    const r = await fetch(ep, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({prompt, width: 1024, height: 1024})});
    if (!r.ok) throw new Error('HTTP ' + r.status);
    let img = (await r.json()).image; if (!img) throw new Error('response has no "image"');
    if (!img.startsWith('data:')) { const b = await (await fetch(img)).blob(); img = await new Promise(res => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.readAsDataURL(b); }); }
    S.image = img; commit(); msg.textContent = 'Done.';
  } catch (e) { msg.textContent = 'Generation failed: ' + e.message; }
}

/* ---------- 7. state / history ---------- */
let hist = [], hi = -1, hTimer;
function snap() { clearTimeout(hTimer); const s = JSON.stringify(S); if (hist[hi] !== s) { hist = hist.slice(0, hi + 1); hist.push(s); if (hist.length > 60) hist.shift(); hi = hist.length - 1; } }
function commit() { draw(); clearTimeout(hTimer); hTimer = setTimeout(snap, 400); }
function undo(k) { snap(); const n = hi + k; if (n < 0 || n >= hist.length) return; hi = n; S = JSON.parse(hist[hi]); syncForm(); draw(); }
function readForm() {
  FIELDS.forEach(k => { const v = $('f_' + k).value; S[k] = NUMERIC.includes(k) ? (v === '' ? 0 : +v) : v; });
}
function fillSubs() { const sel = $('f_sub'); sel.innerHTML = (SUBS[S.type] || []).map(o => `<option>${o}</option>`).join(''); if (!SUBS[S.type]?.includes(S.sub)) S.sub = (SUBS[S.type] || ['Normal'])[0]; }
function syncForm() {
  fillSubs();
  FIELDS.forEach(k => $('f_' + k).value = S[k]);
  document.querySelectorAll('#arrows button[data-i]').forEach(b => b.classList.toggle('on', !!S.arrows[+b.dataset.i]));
  document.querySelectorAll('[data-for]').forEach(e => e.hidden = !e.dataset.for.split(',').includes(S.type));
  $('lvlLabel').textContent = t(S.type === 'xyz' ? 'rank' : 'level');
  document.querySelectorAll('.tbtn').forEach(b => b.classList.toggle('on', b.dataset.type === S.type));
  $('pzoom').dispatchEvent(new Event('input'));
}

/* ---------- 8. storage / export ---------- */
const getCards = () => JSON.parse(localStorage.getItem('acs_cards') || '[]');
const putCards = a => { try { localStorage.setItem('acs_cards', JSON.stringify(a)); return true; } catch (e) { toast('Storage full — export JSON instead.'); return false; } };
function toast(m) { const e = $('toast'); e.textContent = m; e.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => e.classList.remove('show'), 3200); }
function saveCard() { const a = getCards(), i = a.findIndex(x => x.id === S.id); if (i >= 0) a[i] = S; else a.push(S); if (putCards(a)) toast(t('saved')); }
async function renderToCanvas(c, k) { const cv = document.createElement('canvas'); cv.width = BASE_W * k; cv.height = BASE_H * k; drawCard(cv.getContext('2d'), c, await getArt(c.image), k); return cv; }
function download(url, name) { const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); }
const fname = () => (S.name || 'card').replace(/[^\w\u0600-\u06FF-]+/g, '_');
async function exportPng() {
  const errs = validate(S).filter(v => v.l === 'err');
  if (errs.length && !confirm(`The card has ${errs.length} validation problem(s). Export anyway?`)) return;
  try { const cv = await renderToCanvas(S, 4); cv.toBlob(b => { download(URL.createObjectURL(b), fname() + '.png'); }, 'image/png'); }
  catch (e) { toast('Export blocked: ' + e.message + ' (serve the folder over http://, see README)'); }
}
function exportJson() { download('data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(S, null, 2)), fname() + '.json'); }
function importJson(file) {
  const fr = new FileReader();
  fr.onload = () => { try { const o = JSON.parse(fr.result); if (!TYPES.includes(o.type)) throw new Error('unknown card type'); S = Object.assign(newCard(o.type), o, {id: newCard().id}); syncForm(); commit(); toast('Imported.'); } catch (e) { toast('Invalid JSON card: ' + e.message); } };
  fr.readAsText(file);
}
async function printCard() { const cv = await renderToCanvas(S, 3), w = window.open('', '_blank'); if (!w) return toast('Allow pop-ups to print.');
  w.document.write(`<title>${S.name}</title><style>body{margin:0;text-align:center}img{width:63mm;height:auto;margin:10mm}</style><img src="${cv.toDataURL()}" onload="print()">`); w.document.close(); }
async function renderGallery() {
  const q = ($('search').value || '').toLowerCase(), box = $('gallery'), a = getCards().filter(c => (c.name + c.type + c.mtype).toLowerCase().includes(q));
  box.innerHTML = a.length ? '' : `<div class="empty">${t('empty')}</div>`;
  for (const c of a) {
    const d = document.createElement('div'); d.className = 'gc';
    const cv = await renderToCanvas(c, 1); cv.style.width = '140px'; cv.style.height = 'auto';
    d.append(cv, Object.assign(document.createElement('b'), {textContent: c.name || '(unnamed)'}));
    const row = document.createElement('div');
    [['Open', () => { S = JSON.parse(JSON.stringify(c)); showView('create'); syncForm(); draw(); snap(); }],
     [t('dup'), () => { const n = JSON.parse(JSON.stringify(c)); n.id = newCard().id; n.name += ' (copy)'; const all = getCards(); all.push(n); putCards(all); renderGallery(); }],
     ['Rename', () => { const n = prompt('New name', c.name); if (n) { const all = getCards(); all.find(x => x.id === c.id).name = n; putCards(all); renderGallery(); } }],
     ['✕', () => { if (confirm('Delete this card?')) { putCards(getCards().filter(x => x.id !== c.id)); renderGallery(); } }]
    ].forEach(([l, f]) => { const b = document.createElement('button'); b.textContent = l; b.onclick = f; row.append(b); });
    d.append(row); box.append(d);
  }
}

/* ---------- 9. UI wiring ---------- */
function buildTypeBar() {
  $('typeBar').innerHTML = '';
  TYPES.forEach(k => { const b = document.createElement('button'); b.className = 'tbtn' + (S.type === k ? ' on' : ''); b.dataset.type = k; b.style.setProperty('--c', COLORS[k]); b.style.borderColor = COLORS[k];
    b.innerHTML = `<i></i>${t('t_' + k)}`; b.onclick = () => { readForm(); S.type = k; fillSubs(); syncForm(); commit(); }; $('typeBar').append(b); });
}
function showView(v) { document.querySelectorAll('.view').forEach(e => e.hidden = e.id !== 'view-' + v); document.querySelectorAll('.nav').forEach(b => b.classList.toggle('active', b.dataset.view === v)); if (v === 'gallery') renderGallery(); }
function init() {
  ['⬉','⬆','⬈','⬅','','➡','⬋','⬇','⬊'].forEach((ch, n) => { // 3×3 grid, centre empty; arrow index order T,TR,R,BR,B,BL,L,TL
    const map = [7,0,1,6,-1,2,5,4,3][n]; const b = document.createElement('button');
    if (map < 0) { b.disabled = true; b.style.visibility = 'hidden'; } else { b.type = 'button'; b.dataset.i = map; b.textContent = ch; b.onclick = () => { S.arrows[map] = S.arrows[map] ? 0 : 1; syncForm(); commit(); }; }
    $('arrows').append(b); });
  $('lang').value = lang; $('lang').onchange = e => { lang = e.target.value; localStorage.setItem('acs_lang', lang); applyLang(); };
  document.querySelectorAll('.nav').forEach(b => b.onclick = () => showView(b.dataset.view));
  FIELDS.forEach(k => $('f_' + k).addEventListener('input', () => { readForm(); commit(); }));
  $('f_file').onchange = e => { const f = e.target.files[0]; if (!f) return; const fr = new FileReader(); fr.onload = () => { S.image = fr.result; S.zoom = 1; S.ox = S.oy = 0; syncForm(); commit(); }; fr.readAsDataURL(f); e.target.value = ''; };
  $('btnClearArt').onclick = () => { S.image = null; commit(); };
  $('btnGen').onclick = generateArt; $('btnAuto').onclick = suggestText;
  $('btnUndo').onclick = () => undo(-1); $('btnRedo').onclick = () => undo(1);
  $('btnSave').onclick = saveCard;
  $('btnDup').onclick = () => { S = Object.assign(JSON.parse(JSON.stringify(S)), {id: newCard().id}); S.name += ' (copy)'; syncForm(); commit(); toast('Duplicated — save to keep it.'); };
  $('btnReset').onclick = () => { if (confirm('Reset this card?')) { S = newCard(S.type); syncForm(); commit(); } };
  $('btnPng').onclick = exportPng; $('btnJson').onclick = exportJson; $('btnPrint').onclick = printCard;
  $('f_import').onchange = e => { if (e.target.files[0]) importJson(e.target.files[0]); e.target.value = ''; };
  $('search').oninput = renderGallery;
  $('pzoom').oninput = e => { const w = 286 * e.target.value / 100; $('card').style.width = w + 'px'; $('card').style.height = (w * BASE_H / BASE_W) + 'px'; };
  // settings & calibration
  $('s_img').value = localStorage.getItem('acs_img') || ''; $('s_txt').value = localStorage.getItem('acs_txt') || '';
  ['ax','ay','aw','ah'].forEach(k => $('s_' + k).value = CAL[k]);
  $('s_save').onclick = () => { localStorage.setItem('acs_img', $('s_img').value.trim()); localStorage.setItem('acs_txt', $('s_txt').value.trim());
    ['ax','ay','aw','ah'].forEach(k => CAL[k] = +$('s_' + k).value || DEF_CAL[k]); localStorage.setItem('acs_cal', JSON.stringify(CAL)); draw(); toast('Settings saved.'); };
  $('s_reset').onclick = () => { CAL = Object.assign({}, DEF_CAL); localStorage.removeItem('acs_cal'); ['ax','ay','aw','ah'].forEach(k => $('s_' + k).value = CAL[k]); draw(); };
  $('s_tpl').onchange = async e => { const f = e.target.files[0]; if (!f) return; const fr = new FileReader(); fr.onload = async () => { tplImgs[S.type] = await loadImg(fr.result); draw(); toast('Custom frame loaded for this type (this session).'); }; fr.readAsDataURL(f); };
  applyLang(); syncForm(); snap(); loadTemplates();
}
init();
