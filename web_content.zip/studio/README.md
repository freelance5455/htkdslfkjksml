# Anime Card Creator Studio

Vanilla HTML/CSS/JS card maker. Ten frames (Normal, Effect, Fusion, Ritual, Synchro, Xyz, Pendulum, Link, Spell, Trap) are cropped from your template sheet into `assets/templates/*.png` (rounded corners, original colours/proportions, never stretched).

## Run
Open `index.html` (works from disk: frames are also embedded in `assets/templates.js` so PNG export is not blocked) or serve it: `python3 -m http.server 8000`.

## Usage
Pick a type → fill the form → card updates live (canvas). Validation messages appear under the preview. Undo/redo, duplicate, reset, preview zoom, font size/alignment, artwork zoom/X/Y. Save to "My Cards" (browser storage, searchable; open/duplicate/rename/delete). Export PNG (1144×1728, card only), JSON export/import, Print. EN / العربية (RTL) / FR.

## AI configuration (optional)
No API key ever goes in the browser. Run your own endpoint and put its URL in Settings:
- Image: `POST {prompt,width,height}` → `{ "image": "data:image/png;base64,…" | "https://…" }`
- Text: `POST {type,name,concept,mtype,sub,level}` → `{ "fields": { "effect": "…", "materials": "…", "flavor": "…", "pEffect": "…" } }`

Without them: upload artwork, and "Suggest text" fills only EMPTY fields from local templates. ATK/DEF are never invented.

## Calibration / own templates
Settings → Art X/Y/W/H (px on a 286×432 frame), or replace the current type's frame with your own blank image (this session only).

## Notes
Custom rules inspired by trading-card games, not tournament-legal. Layout is compact: rules, renderer and generators live in `app.js` sections instead of separate files.
