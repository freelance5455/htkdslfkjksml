'use strict';
/* ============================================================
   Armazenamento, migração v3 → v4, estado, unidades e backup
   ============================================================ */
const STORAGE_KEYS = {
  DATA:'proTrackerData_v4', HISTORY:'proTrackerHistory_v4', ACTIVE:'proTrackerActive_v4', REST:'proTrackerRest_v4',
  V3_DATA:'proTrackerData_v3', V3_HISTORY:'proTrackerHistory_v3', V3_ACTIVE:'proTrackerActiveSession_v3',
  PRE_V4_BACKUP:'proTrackerBackupPreV4'
};
const MAX_SESSION_MS = 4 * 3600000, GHOST_SESSION_MS = 6 * 3600000, BACKUP_REMIND_MS = 30 * 86400000, UNDO_MS = 30000;
const LB = 2.2046226218;
const DOW_BY_ID = { sunday:0, monday:1, tuesday:2, wednesday:3, thursday:4, friday:5, saturday:6 };

const Storage = {
  available:true,
  get(k){ try{ return localStorage.getItem(k); }catch(e){ this.available = false; return null; } },
  set(k,v){ try{ localStorage.setItem(k,v); return true; }catch(e){ this.available = false; return false; } },
  del(k){ try{ localStorage.removeItem(k); return true; }catch(e){ return false; } },
  parse(raw){ if(raw == null) return null; try{ return JSON.parse(raw); }catch(e){ return { __corrupt:true, __raw:raw }; } },
  keys(){ try{ const out = []; for(let i=0;i<localStorage.length;i++) out.push(localStorage.key(i)); return out; }catch(e){ return []; } }
};

function emptyGame(){
  return { xpTotal:0, level:1, rankId:'recruit', rankHistory:{}, streak:{ current:0, best:0, freezes:0, lastCountedDate:null, noticedFreeze:null, noticedBreak:null }, achievements:{}, quests:{}, dailyXp:{} };
}
function defaultData(){
  return {
    version:4,
    profile:{ name:'', goal:'', experience:'', heightCm:null, onboarded:false },
    settings:{ defaultRest:90, autoStartRest:true, sound:true, weeklyGoal:3, language:'auto', weightUnit:'kg', gamificationOff:false, lastBackupAt:null, lastBackupRemindAt:null, installedAt:Date.now() },
    days:[], bodyLog:[], gamification:emptyGame()
  };
}
const keyFromName = name => 'ex_' + U.slug(name);
const newExKey = () => 'ex_' + U.uid('k').slice(2);
const cleanList = (s, max) => String(s == null ? '' : s).slice(0, max || 80);

function normalizeData(d){
  const def = defaultData();
  d.version = 4;
  d.profile = Object.assign(def.profile, d.profile || {});
  d.profile.name = cleanList(d.profile.name, 30);
  d.profile.heightCm = (U.parseNum(d.profile.heightCm) > 0) ? Math.round(U.parseNum(d.profile.heightCm)) : null;
  d.settings = Object.assign(def.settings, d.settings || {});
  const S = d.settings;
  S.weeklyGoal = Math.min(7, Math.max(1, Math.round(U.parseNum(S.weeklyGoal) || 3)));
  S.defaultRest = Math.min(900, Math.max(0, Math.round(U.parseNum(S.defaultRest) ?? 90)));
  if(!['auto','pt-BR','en'].includes(S.language)) S.language = 'auto';
  if(!['kg','lb'].includes(S.weightUnit)) S.weightUnit = 'kg';
  S.autoStartRest = S.autoStartRest !== false; S.sound = S.sound !== false; S.gamificationOff = !!S.gamificationOff;
  if(!Array.isArray(d.days)) d.days = [];
  d.days.forEach(day=>{
    if(!day.id) day.id = U.uid('day');
    if(day.dow === undefined || day.dow === '' || day.dow === null) day.dow = DOW_BY_ID[day.id] !== undefined ? DOW_BY_ID[day.id] : null;
    else { const n = Number(day.dow); day.dow = (Number.isInteger(n) && n >= 0 && n <= 6) ? n : null; }
    if(!/^#[0-9a-f]{6}$/i.test(day.color || '')) day.color = '#00E5FF';
    day.name = String(day.name || '—').slice(0,6); day.title = cleanList(day.title, 40); day.note = cleanList(day.note, 200);
    if(!Array.isArray(day.exercises)) day.exercises = [];
    day.exercises = day.exercises.filter(Boolean);
    day.exercises.forEach(ex=>{
      if(!ex.id) ex.id = U.uid('ex');
      ex.name = cleanList(ex.name || '', 80) || '—';
      if(!ex.key) ex.key = keyFromName(ex.name);
      ex.muscle = muscleKey(ex.muscle); ex.equipment = equipKey(ex.equipment);
      ex.sets = Number.isFinite(Number(ex.sets)) && Number(ex.sets) > 0 ? Math.min(20, Math.round(Number(ex.sets))) : null;
      ex.reps = cleanList(ex.reps, 80); ex.load = cleanList(ex.load, 80);
      ex.rest = Number.isFinite(Number(ex.rest)) ? Math.min(900, Math.max(0, Math.round(Number(ex.rest)))) : 90;
      ex.notes = cleanList(ex.notes, 300);
    });
  });
  d.bodyLog = (Array.isArray(d.bodyLog) ? d.bodyLog : []).filter(b=>b && /^\d{4}-\d{2}-\d{2}$/.test(b.date || '') && U.parseNum(b.kg) > 0 && U.parseNum(b.kg) < 700)
    .map(b=>({ id:b.id || U.uid('bw'), date:b.date, kg:Math.round(U.parseNum(b.kg)*100)/100 })).sort((a,b)=>a.date < b.date ? -1 : 1);
  d.gamification = Object.assign(emptyGame(), d.gamification || {});
  d.gamification.streak = Object.assign(emptyGame().streak, d.gamification.streak || {});
  return d;
}

function normalizeHistory(history, data){
  const byId = {}, byKey = {}, byName = {};
  (data.days || []).forEach(d=>d.exercises.forEach(ex=>{ byId[ex.id] = ex; byKey[ex.key] = ex; byName[U.norm(ex.name)] = ex; }));
  const out = [], seen = new Set();
  (Array.isArray(history) ? history : []).forEach(s=>{
    if(!s || typeof s.completedAt !== 'number' || !Array.isArray(s.exercises)) return;
    const id = s.id && !seen.has(s.id) ? s.id : U.uid('session'); seen.add(id);
    const completedAt = s.completedAt;
    let startedAt = typeof s.startedAt === 'number' ? s.startedAt : completedAt;
    if(completedAt - startedAt > MAX_SESSION_MS) startedAt = completedAt - MAX_SESSION_MS;
    if(startedAt > completedAt) startedAt = completedAt;
    out.push({
      id, dayId: s.dayId || '', dayTitle: cleanList(s.dayTitle, 40), startedAt, completedAt, note: cleanList(s.note, 500),
      exercises: s.exercises.filter(Boolean).map(ex=>{
        const ref = byId[ex.id] || (ex.key && byKey[ex.key]) || byName[U.norm(ex.name)] || null;
        const cardio = !!ex.cardio;
        let muscle = ex.muscle ? muscleKey(ex.muscle) : (ref ? ref.muscle : (cardio ? 'cardio' : 'other'));
        if(cardio && !isCardioKey(muscle)) muscle = 'cardio';
        return {
          id: ex.id || U.uid('ex'), key: ex.key || (ref && ref.key) || keyFromName(ex.name || ''), name: cleanList(ex.name || '—', 80), cardio, muscle,
          sets: (Array.isArray(ex.sets) ? ex.sets : []).filter(Boolean).map(st=> ('minutes' in st || cardio)
            ? { minutes:cleanList(st.minutes, 10), done:!!st.done }
            : { load:cleanList(st.load, 10), reps:cleanList(st.reps, 10), done:!!st.done })
        };
      })
    });
  });
  return out;
}

/* v3 → v4 (dados do usuário migram sem perda; grupos/equipamentos viram chaves neutras) */
function migrateV3(rawData){
  const d = rawData;
  const old = d.profile || {};
  d.profile = { name: old.name === undefined ? '' : old.name, goal:'', experience:'', heightCm:null, onboarded:true };
  const h = U.parseNum(old.height);
  if(h > 0) d.profile.heightCm = Math.round(h < 3 ? h*100 : h);
  d.bodyLog = [];
  const w = U.parseNum(old.weight);
  if(w > 0) d.bodyLog.push({ id:U.uid('bw'), date:U.dayKey(Date.now()), kg:w });
  d.settings = Object.assign({ language:'auto', weightUnit:'kg', gamificationOff:false, lastBackupAt:null, lastBackupRemindAt:null, installedAt:Date.now() }, d.settings || {});
  return d;
}

Storage.loadAll = function(){
  let data = this.parse(this.get(STORAGE_KEYS.DATA));
  let history = this.parse(this.get(STORAGE_KEYS.HISTORY));
  let active = this.parse(this.get(STORAGE_KEYS.ACTIVE));
  let isNew = false, migrated = false;
  if(!data || data.__corrupt || !Array.isArray(data.days)){
    if(data && data.__corrupt) this.set(STORAGE_KEYS.DATA + '_corrupt_' + Date.now(), data.__raw);
    const rawV3 = this.get(STORAGE_KEYS.V3_DATA), v3 = this.parse(rawV3);
    if(v3 && !v3.__corrupt && Array.isArray(v3.days)){
      /* cópia de segurança ANTES de migrar */
      this.set(STORAGE_KEYS.PRE_V4_BACKUP, JSON.stringify({ at:Date.now(), data:rawV3, history:this.get(STORAGE_KEYS.V3_HISTORY), active:this.get(STORAGE_KEYS.V3_ACTIVE) }));
      data = migrateV3(v3);
      const h3 = this.parse(this.get(STORAGE_KEYS.V3_HISTORY));
      history = Array.isArray(h3) ? h3 : [];
      const a3 = this.parse(this.get(STORAGE_KEYS.V3_ACTIVE));
      active = a3 && !a3.__corrupt ? a3 : null;
      migrated = true;
    } else { data = defaultData(); isNew = true; history = []; active = null; }
  }
  normalizeData(data);
  history = normalizeHistory(history, data);
  if(active && (active.__corrupt || typeof active.dayId !== 'string' || !active.sets || typeof active.sets !== 'object' || typeof active.startedAt !== 'number')) active = null;
  return { data, history, active, isNew, migrated };
};
Storage.saveData = d => Storage.set(STORAGE_KEYS.DATA, JSON.stringify(d));
Storage.saveHistory = h => Storage.set(STORAGE_KEYS.HISTORY, JSON.stringify(h));
Storage.saveActive = a => a == null ? Storage.del(STORAGE_KEYS.ACTIVE) : Storage.set(STORAGE_KEYS.ACTIVE, JSON.stringify(a));
Storage.saveRest = r => r == null ? Storage.del(STORAGE_KEYS.REST) : Storage.set(STORAGE_KEYS.REST, JSON.stringify(r));
Storage.loadRest = () => { const r = Storage.parse(Storage.get(STORAGE_KEYS.REST)); return r && !r.__corrupt ? r : null; };

/* ---------- Estado ---------- */
const loaded = Storage.loadAll();
const State = {
  data: loaded.data, history: loaded.history, active: loaded.active, isNew: loaded.isNew, migrated: loaded.migrated,
  game: null, currentDayId: null, currentView: 'train', undo: null,
  rest: { endAt:null, pausedRemaining:null, totalMs:0, interval:null, finished:false }
};
const S = () => State.data.settings;
const gamOn = () => !State.data.settings.gamificationOff;
function persistData(){ if(!Storage.saveData(State.data)) showToast(t('toast.saveFail'), 'error'); }
function persistHistory(){ if(!Storage.saveHistory(State.history)) showToast(t('toast.saveFail'), 'error'); }
function persistActive(){ Storage.saveActive(State.active); }
function todayDay(){ const dow = new Date().getDay(); return State.data.days.find(d=>d.dow === dow) || null; }
function currentDay(){ return State.data.days.find(d=>d.id === State.currentDayId) || null; }
function pickInitialDay(){
  const days = State.data.days;
  if(State.active && !days.some(d=>d.id === State.active.dayId)) State.active = null;
  if(State.active) State.currentDayId = State.active.dayId;
  else { const tday = todayDay(); State.currentDayId = tday ? tday.id : (days[0] ? days[0].id : null); }
}

/* ---------- Gamificação: sempre derivada do histórico ---------- */
function rebuildGamification(){
  const prev = U.clone(State.data.gamification || emptyGame());
  const g = computeGame(State.history, State.data);
  State.game = g;
  const ps = prev.streak || {};
  State.data.gamification = {
    xpTotal:g.xpTotal, level:g.level, rankId:g.rankId, rankHistory:g.rankHistory,
    streak:{ current:g.streak.current, best:g.streak.best, freezes:g.streak.freezes, lastCountedDate:g.streak.lastCountedDate, noticedFreeze:ps.noticedFreeze || null, noticedBreak:ps.noticedBreak || null },
    achievements:g.achievements, quests:g.quests, dailyXp:g.dailyXp
  };
  persistData();
  return { prev, next: State.data.gamification };
}
function gameDiff(prev, next){
  const out = { newAch:[], levelUp:null, promoted:null };
  Object.keys(next.achievements || {}).forEach(id=>{ if(!(prev.achievements || {})[id]) out.newAch.push(id); });
  if(next.level > prev.level) out.levelUp = { from:prev.level, to:next.level };
  const pi = RANKS.findIndex(r=>r.id === prev.rankId), ni = RANKS.findIndex(r=>r.id === next.rankId);
  if(ni > pi) out.promoted = { from:prev.rankId, to:next.rankId, at:(next.rankHistory || {})[next.rankId] };
  return out;
}

/* ---------- Unidades: guarda sempre kg; converte na exibição/digitação ---------- */
const unit = () => State.data.settings.weightUnit;
const unitLabel = () => t(unit() === 'lb' ? 'unit.lb' : 'unit.kg');
function kgToDisp(kg, max){ const n = U.parseNum(kg); if(n == null) return null; return unit() === 'lb' ? n * LB : n; }
function fmtLoad(kg, withUnit){
  const v = kgToDisp(kg); if(v == null) return '';
  return fmtNum(v, 1) + (withUnit ? ' ' + unitLabel() : '');
}
function loadInputValue(kg){ const v = kgToDisp(kg); return v == null ? '' : fmtNum(v, 1, { useGrouping:false }); }
function dispToKg(text){
  const n = U.parseNum(text); if(n == null) return '';
  return String(Math.round((unit() === 'lb' ? n / LB : n) * 1000) / 1000);
}
function fmtWeightKg(kg, withUnit){ return fmtLoad(kg, withUnit); }
/* listas digitadas: ';', '/', espaço ou ', ' separam; vírgula sozinha entre dígitos é decimal (a menos que haja 2+ vírgulas) */
function parseLoadList(text){
  const s = String(text || '').trim(); if(!s) return [];
  const commas = (s.match(/,/g) || []).length;
  let parts;
  if(/[;\/]/.test(s) || /\s/.test(s)) parts = s.split(/\s*[;\/]\s*|\s*,\s+|\s+/);
  else parts = commas >= 2 ? s.split(',') : [s];
  return parts.map(x=>x.trim()).filter(Boolean);
}
const parseRepsList = text => String(text || '').split(/[;\/\s,]+/).map(x=>x.trim()).filter(Boolean);

/* ---------- Domínio: sessões/treino ---------- */
function sessionsDesc(){ return [...State.history].sort((a,b)=>b.completedAt - a.completedAt); }
function lastPerformance(key){
  for(const s of sessionsDesc()){
    const ex = s.exercises.find(e=>e.key === key && (e.sets||[]).some(x=>x.done));
    if(ex) return { date:s.completedAt, cardio:!!ex.cardio, sets:ex.sets.filter(x=>x.done) };
  }
  return null;
}
function buildSets(ex){
  const reps = U.splitList(ex.reps), loads = U.splitList(ex.load);
  const cardio = isCardio(ex);
  const count = cardio ? 1 : Math.max(Number(ex.sets) || 0, reps.length, loads.length, 1);
  const sets = [];
  for(let i=0;i<count;i++){
    if(cardio) sets.push({ minutes: reps[0] || '', done:false });
    else sets.push({ load: loads[i] !== undefined ? loads[i] : (loads.length ? loads[loads.length-1] : ''), reps: reps[i] || reps[reps.length-1] || '', done:false });
  }
  return sets;
}
function ensureSets(ex){
  if(!State.active) return [];
  let sets = State.active.sets[ex.id];
  if(!Array.isArray(sets) || !sets.length){ sets = State.active.sets[ex.id] = buildSets(ex); persistActive(); }
  return sets;
}
function reconcileSets(ex){
  if(!State.active || !State.active.sets[ex.id]) return;
  const cur = State.active.sets[ex.id], fresh = buildSets(ex);
  if(isCardio(ex) !== ('minutes' in (cur[0] || {}))) State.active.sets[ex.id] = fresh;
  else { while(cur.length > fresh.length && !cur[cur.length-1].done) cur.pop(); while(cur.length < fresh.length) cur.push(fresh[cur.length]); }
  persistActive();
}
function exerciseDone(ex){
  if(!State.active) return false;
  const sets = State.active.sets[ex.id];
  return Array.isArray(sets) && sets.length > 0 && sets.every(s=>s.done);
}
/* Meta por DIA: dias distintos com treino na semana (duas sessões no mesmo dia contam 1) */
function weekDaysCount(ts){
  const wk = U.weekKey(U.dayKey(ts)), days = new Set();
  State.history.forEach(s=>{
    if(U.weekKey(U.dayKey(s.completedAt)) !== wk) return;
    if(s.exercises.some(e=>(e.sets||[]).some(x=>x.done))) days.add(U.dayKey(s.completedAt));
  });
  return days.size;
}
function setSummary(s, cardio){
  if(cardio || 'minutes' in s) return fmtNum(U.parseNum(s.minutes) || 0, 1) + ' ' + t('unit.min');
  const l = s.load ? fmtLoad(s.load, true) : '';
  const r = s.reps ? s.reps + (l ? '' : ' ' + t('lbl.repsShort')) : '';
  return [l, r].filter(Boolean).join(' × ') || '—';
}
function compareWithPrev(session){
  const prev = sessionsDesc().find(s=>s.id !== session.id && s.completedAt < session.completedAt && s.dayId && s.dayId === session.dayId);
  if(!prev) return [];
  const out = [];
  session.exercises.forEach(ex=>{
    if(ex.cardio) return;
    const p = prev.exercises.find(e=>e.key === ex.key); if(!p) return;
    const mx = e => Math.max(0, ...(e.sets||[]).filter(x=>x.done).map(x=>U.parseNum(x.load) || 0));
    const tr = e => (e.sets||[]).filter(x=>x.done).reduce((a,x)=>a + (U.parseNum(x.reps) || 0), 0);
    const dl = mx(ex) - mx(p), dr = tr(ex) - tr(p);
    if(Math.abs(dl) > 0.001) out.push({ name:ex.name, kind:'load', delta:dl });
    else if(dr !== 0 && tr(ex) > 0) out.push({ name:ex.name, kind:'reps', delta:dr });
  });
  return out.sort((a,b)=>Math.abs(b.delta) - Math.abs(a.delta)).slice(0, 4);
}

/* ---------- Backup / Desfazer (em memória) ---------- */
function takeSnapshot(){
  State.undo = { snap:{ data:U.clone(State.data), history:U.clone(State.history), active:U.clone(State.active) }, until:Date.now() + UNDO_MS };
}
function buildBackupPayload(){ return { app:APP_NAME, version:4, exportedAt:new Date().toISOString(), data:State.data, history:State.history }; }
function backupFileName(){ return 'protracker_backup_' + U.dayKey(Date.now()) + '.json'; }
function parseBackup(parsed){
  if(!parsed || typeof parsed !== 'object' || !parsed.data || !Array.isArray(parsed.data.days)) throw new Error('invalid');
  const data = U.clone(parsed.data);
  const ver = Number(parsed.version) || Number(data.version) || 3;
  if(ver < 4 || !data.profile || data.profile.onboarded === undefined) migrateV3(data);
  data.profile.onboarded = true;
  normalizeData(data);
  const hist = normalizeHistory(parsed.history, data);
  return { data, history:hist, daysN:data.days.length, exN:data.days.reduce((a,d)=>a + d.exercises.length, 0) };
}
function backupDue(){
  if(!State.history.length) return false;
  const now = Date.now(), base = S().lastBackupAt || S().installedAt || now;
  if(now - base < BACKUP_REMIND_MS) return false;
  if(S().lastBackupRemindAt && now - S().lastBackupRemindAt < 7 * 86400000) return false;
  return true;
}
function eraseAllStorage(){ Storage.keys().filter(k=>k.indexOf('proTracker') === 0).forEach(k=>Storage.del(k)); }
