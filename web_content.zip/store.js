import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { effectivePlayer, FORMATIONS, PLAYERS, PLAYERS_BY_ID, rankName, starterIds } from './data/players.js';
import { nextRank } from './data/ranking.js';
import { calculateMatchCoins } from './data/economy.js';
export { calculateMatchCoins } from './data/economy.js';
export const CHALLENGES = [{ id: 'first', title: 'Get in the game', detail: 'Complete your first match', target: 1, reward: 450, progress: (s) => s.wins + s.draws + s.losses }, { id: 'win3', title: 'Winning form', detail: 'Win 3 matches', target: 3, reward: 1000, progress: (s) => s.wins }, { id: 'score10', title: 'Goalscoring form', detail: 'Score 10 goals', target: 10, reward: 1250, progress: (s) => s.goalsFor }, { id: 'play10', title: 'Club regular', detail: 'Complete 10 matches', target: 10, reward: 1700, progress: (s) => s.wins + s.draws + s.losses }, { id: 'win15', title: 'Title contenders', detail: 'Win 15 matches', target: 15, reward: 3800, progress: (s) => s.wins }, { id: 'score50', title: 'Golden boots', detail: 'Score 50 goals', target: 50, reward: 7000, progress: (s) => s.goalsFor }];
const startingSettings = { graphics: 'High', camera: 'Broadcast', sound: true, halfMinutes: 3, minimap: true, reducedMotion: false, autoSwitch: true, darkMode: false };
const emptyState = { screen: 'Home', clubName: '', clubBadge: 0, clubCreated: false, coins: 2200, owned: [...starterIds, ...PLAYERS.filter(p => p.id >= 24 && p.overall <= 60 && !starterIds.includes(p.id)).slice(0, 4).map(p => p.id)], squad: [...starterIds], formation: '4-3-3', captain: starterIds[9], tactic: 'Balanced', training: {}, rank: 6, championLosses: 0, wins: 0, draws: 0, losses: 0, goalsFor: 0, goalsAgainst: 0, matches: [], claimed: [], lastDaily: '', achievements: [], settings: startingSettings, activeMatch: false, toast: '' };
export function playerWithTraining(id, training) { const p = PLAYERS_BY_ID.get(id); return p ? effectivePlayer(p, training[id] || 0) : PLAYERS[0]; }
export function teamOverall(ids, training) { return Math.round(ids.reduce((sum, id) => sum + playerWithTraining(id, training).overall, 0) / Math.max(ids.length, 1)); }
export function teamChemistry(ids, formation) {
    const roles = FORMATIONS[formation] || FORMATIONS['4-3-3'];
    let amount = 0;
    ids.forEach((id, i) => {
        const p = PLAYERS_BY_ID.get(id);
        if (!p)
            return;
        amount += p.position === roles[i] ? 5 : ['CM', 'CDM', 'CAM'].includes(p.position) && ['CM', 'CDM', 'CAM'].includes(roles[i]) ? 3 : 1;
        const previous = PLAYERS_BY_ID.get(ids[i - 1]);
        if (previous?.country === p.country)
            amount += 2;
    });
    return Math.min(100, Math.round(amount / 76 * 100));
}
export const useGame = create()(persist((set, get) => ({
    ...emptyState,
    setClub: (name, badge) => { const clean = name.trim().replace(/\s+/g, ' ').slice(0, 26); if (clean.length >= 2 && badge >= 0 && badge < 20)
        set({ clubName: clean, clubBadge: badge, clubCreated: true }); },
    navigate: screen => set({ screen }), notify: toast => set({ toast }), dismissToast: () => set({ toast: '' }),
    buy: id => { const s = get(), p = PLAYERS_BY_ID.get(id); if (!p || s.owned.includes(id) || s.coins < p.value)
        return false; set({ coins: s.coins - p.value, owned: [...s.owned, id], toast: `Signed ${p.name} for ${p.value.toLocaleString()} coins` }); return true; },
    sell: id => {
        const s = get(), p = PLAYERS_BY_ID.get(id);
        if (!p || !s.owned.includes(id) || s.squad.includes(id))
            return false;
        const payout = Math.round(p.value * .075);
        const training = { ...s.training };
        delete training[id];
        set({ coins: s.coins + payout, owned: s.owned.filter(x => x !== id), training, toast: `Sold ${p.name} for ${payout.toLocaleString()} coins` });
        return true;
    },
    train: id => { const s = get(), p = PLAYERS_BY_ID.get(id); if (!p || !s.owned.includes(id))
        return false; const lvl = s.training[id] || 0, cost = 300 + lvl * 350; if (lvl >= 5 || s.coins < cost)
        return false; set({ coins: s.coins - cost, training: { ...s.training, [id]: lvl + 1 }, toast: `${p.name} trained to level ${lvl + 1}` }); return true; },
    assign: (slot, id) => { const s = get(); if (!s.owned.includes(id) || slot < 0 || slot >= 11)
        return; const squad = [...s.squad], existing = squad.indexOf(id); if (existing === slot)
        return; if (existing >= 0)
        squad[existing] = squad[slot]; squad[slot] = id; set({ squad }); },
    setFormation: f => { if (FORMATIONS[f])
        set({ formation: f }); }, setCaptain: id => { if (get().squad.includes(id))
        set({ captain: id }); }, setTactic: tactic => set({ tactic }),
    claimDaily: () => { const s = get(), today = new Date().toLocaleDateString('en-CA'); if (s.lastDaily === today)
        return false; set({ coins: s.coins + 350, lastDaily: today, toast: 'Daily reward: +350 coins' }); return true; },
    claimChallenge: id => { const s = get(), c = CHALLENGES.find(c => c.id === id); if (!c || s.claimed.includes(id) || c.progress(s) < c.target)
        return false; set({ claimed: [...s.claimed, id], coins: s.coins + c.reward, toast: `Challenge complete: +${c.reward.toLocaleString()} coins` }); return true; },
    openPack: tier => {
        const s = get(), options = { Academy: { cost: 550, rare: 0.27, elite: 0.025, icon: 0.001 }, Pro: { cost: 2300, rare: 0.72, elite: 0.12, icon: 0.008 }, Elite: { cost: 7500, rare: 0.94, elite: 0.52, icon: 0.055 } }[tier];
        if (s.coins < options.cost)
            return null;
        const available = PLAYERS;
        if (!available.length)
            return null;
        const selected = [];
        // Seven independent rarity rolls, excluding duplicates and already-owned cards.
        for (let i = 0; i < 7 && selected.length < available.length; i++) {
            const roll = Math.random();
            const min = roll < options.icon ? 91 : roll < options.elite ? 82 : roll < options.rare ? 70 : 48;
            const max = min >= 91 ? 99 : min >= 82 ? 94 : min >= 70 ? 81 : 69;
            const remaining = available.filter(p => !selected.some(q => q.id === p.id));
            const tierPool = remaining.filter(p => p.overall >= min && p.overall <= max);
            // Promo drops are rare in lower packs and more common in Elite packs.
            const eventChance = tier === 'Academy' ? .015 : tier === 'Pro' ? .065 : .16;
            const specialPool = remaining.filter(p => p.promo && p.overall >= Math.max(85, min));
            const pool = (Math.random() < eventChance && specialPool.length) ? specialPool : (tierPool.length ? tierPool : remaining);
            // Duplicates are possible but are less likely than unowned cards.
            const weights = pool.map(p => s.owned.includes(p.id) ? 1 : 5);
            const total = weights.reduce((a, b) => a + b, 0);
            let ticket = Math.random() * total, choice = pool[0];
            for (let j = 0; j < pool.length; j++) {
                ticket -= weights[j];
                if (ticket <= 0) {
                    choice = pool[j];
                    break;
                }
            }
            selected.push(choice);
        }
        set({ coins: s.coins - options.cost, owned: [...new Set([...s.owned, ...selected.map(p => p.id)])], toast: `${selected.filter(p => !s.owned.includes(p.id)).length} new players signed` });
        return selected;
    },
    setSetting: (key, value) => set(s => ({ settings: { ...s.settings, [key]: value } })), resetAll: () => { localStorage.removeItem('ultimate-fc-save-v1'); set({ ...emptyState, owned: [...emptyState.owned], squad: [...emptyState.squad], settings: { ...startingSettings }, training: {}, matches: [], claimed: [], achievements: [] }); }, setTestRank: (rank) => set({ rank: Math.max(0, Math.min(18, Math.round(rank))), championLosses: 0 }), startMatch: () => set({ activeMatch: true }), abandonMatch: () => set({ activeMatch: false, screen: 'Home' }),
    endMatch: ({ home, away, stats, scorers, mode = 'ranked' }) => {
        const s = get();
        const result = home > away ? 'W' : home < away ? 'L' : 'D';
        const { rank, championLosses } = mode === 'ranked' ? nextRank(s.rank, s.championLosses, result) : { rank: s.rank, championLosses: s.championLosses };
        const coins = calculateMatchCoins(home, away, stats, mode);
        const record = { id: Date.now(), home, away, mode, result, coins, rankBefore: s.rank, rankAfter: rank, date: new Date().toLocaleString(), stats, scorers };
        const wins = s.wins + (result === 'W' ? 1 : 0), matches = [record, ...s.matches].slice(0, 50);
        const achievements = [...s.achievements];
        if (wins === 1 && !achievements.includes('First win'))
            achievements.push('First win');
        if (wins >= 10 && !achievements.includes('10 wins'))
            achievements.push('10 wins');
        if (rank >= 9 && !achievements.includes('Platinum'))
            achievements.push('Platinum');
        if (rank === 18 && !achievements.includes('World Champion'))
            achievements.push('World Champion');
        set({ activeMatch: false, screen: 'Ranked', rank, championLosses, wins, draws: s.draws + (result === 'D' ? 1 : 0), losses: s.losses + (result === 'L' ? 1 : 0), goalsFor: s.goalsFor + home, goalsAgainst: s.goalsAgainst + away, coins: s.coins + coins, matches, achievements, toast: `${mode === 'friendly' ? 'Friendly' : 'Ranked'} ${result === 'W' ? 'victory' : result === 'L' ? 'defeat' : 'draw'} • ${coins >= 0 ? '+' : ''}${coins.toLocaleString()} coins • ${rankName(rank)}` });
        return record;
    }
}), { name: 'ultimate-fc-save-v1', storage: createJSONStorage(() => localStorage), partialize: s => ({ clubName: s.clubName, clubBadge: s.clubBadge, clubCreated: s.clubCreated, coins: s.coins, owned: s.owned, squad: s.squad, formation: s.formation, captain: s.captain, tactic: s.tactic, training: s.training, rank: s.rank, championLosses: s.championLosses, wins: s.wins, draws: s.draws, losses: s.losses, goalsFor: s.goalsFor, goalsAgainst: s.goalsAgainst, matches: s.matches, claimed: s.claimed, lastDaily: s.lastDaily, achievements: s.achievements, settings: s.settings }) }));
