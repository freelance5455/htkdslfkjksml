// Builds the delivery challan as a real PDF file (A4 portrait) and shares or saves it.
// Uses jsPDF from assets/vendor/ and the logo from assets/logo-data.js. No internet needed.
(() => {
  const L = 12;                 // left margin (mm)
  const W = 186;                // content width (mm)
  const PAGE_LIMIT = 284;       // lowest y used for content (mm)
  const ROW_MIN = 12;           // minimum item row height, matches printed sheet
  const HEADER_H = 11;
  const SIGN_H = 31;
  const COLS = [0.09, 0.39, 0.16, 0.10, 0.10, 0.16];
  const COMPANY_LINES = [
    '282, GOPAL CHARAN INDUSTRIAL HUB,',
    'BAKROL, BUJRANG, AHMEDABAD.',
    'GST IN : 24AMQPP5738P1ZY'
  ];

  const displayDate = (value) => {
    if (!value) return '–';
    const [year, month, day] = String(value).split('-');
    return year && month && day ? `${day}/${month}/${year}` : '–';
  };
  const hasValue = (value) => value !== '' && value !== null && value !== undefined;
  const formatAmount = (value) => {
    if (!hasValue(value)) return '–';
    const number = Number(value);
    return Number.isNaN(number) ? '–' : number.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  // jsPDF's built-in fonts cannot print the ₹ sign, so the PDF uses plain numbers, as the printed sheet does.
  const build = (record) => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' });
    doc.setTextColor(0, 0, 0);
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.3);

    const text = (value, x, y, opts = {}) => doc.text(String(value), x, y, opts);
    const wrap = (value, width) => doc.splitTextToSize(String(value || ''), width);
    const cell = (x, y, w, h) => doc.rect(x, y, w, h);
    const setFont = (style, size) => { doc.setFont('helvetica', style); doc.setFontSize(size); };

    // ---- Header: logo + title ------------------------------------------
    let y = 12;
    cell(L, y, 110, 38);
    cell(L + 110, y, 76, 38);
    if (window.CHALLAN_LOGO_DATA_URL) doc.addImage(window.CHALLAN_LOGO_DATA_URL, 'PNG', L + 10, y + 1.7, 90, 34.7);
    setFont('bold', 19);
    text('DELIVERY CHALLAN', L + 148, y + 17, { align: 'center' });
    setFont('bold', 11);
    text(`DATE : ${displayDate(record.date)}`, L + 148, y + 28, { align: 'center' });

    // ---- Sender and contact ----------------------------------------------
    y = 50;
    cell(L, y, 110, 40);
    cell(L + 110, y, 76, 40);
    setFont('bold', 9.5);
    text('FROM : SHREE BHAGYALAXMI INDUSTRIES', L + 2, y + 6);
    setFont('normal', 9.5);
    COMPANY_LINES.forEach((line, i) => text(line, L + 2, y + 11 + i * 5));
    setFont('normal', 9.5);
    text('CONTACT NO : +91 7984290928', L + 112, y + 6);
    text('+91 9622478418', L + 112 + 27, y + 11);
    text('EMAIL : bhaghyalaxmiind@gmail.com', L + 112, y + 21);

    // ---- Recipient (TO) ----------------------------------------------------
    y = 90;
    setFont('bold', 10);
    const toLines = wrap(record.recipient || '–', W - 20);
    const toH = Math.max(22, 8 + toLines.length * 5);
    cell(L, y, W, toH);
    text('TO :', L + 2, y + 6);
    setFont('normal', 10);
    toLines.forEach((line, i) => text(line, L + 16, y + 6 + i * 5));
    y += toH;

    // ---- Dispatch details ------------------------------------------------
    const dispatchW = [0.3, 0.4, 0.3].map(share => share * W);
    const dispatch = [
      ['CHALLAN NO :', record.number || '–'],
      ['TRANSPORT BY :', record.transport || '–'],
      ['VEHICAL NO :', record.vehicle || '–']
    ];
    let dx = L;
    dispatch.forEach(([label, value], i) => {
      cell(dx, y, dispatchW[i], 15);
      setFont('bold', 9);
      text(label, dx + 2, y + 6);
      setFont('normal', 9);
      wrap(value, dispatchW[i] - 4).slice(0, 2).forEach((line, n) => text(line, dx + 2, y + 10.5 + n * 4));
      dx += dispatchW[i];
    });
    y += 15;

    // ---- Item table ------------------------------------------------------
    const colW = COLS.map(share => share * W);
    colW[colW.length - 1] = W - colW.slice(0, -1).reduce((sum, w) => sum + w, 0);
    const headers = ['SR NO', 'DESCRIPTION', 'HSN CODE', 'NOS', 'SET', 'AMOUNT'];

    const drawHeader = () => {
      let x = L;
      setFont('bold', 9);
      headers.forEach((label, i) => {
        cell(x, y, colW[i], HEADER_H);
        text(label, x + colW[i] / 2, y + HEADER_H / 2 + 1.2, { align: 'center' });
        x += colW[i];
      });
      y += HEADER_H;
    };
    const newPageIfNeeded = (needed) => {
      if (y + needed <= PAGE_LIMIT) return;
      doc.addPage();
      y = 12;
      drawHeader();
    };

    drawHeader();
    const items = Array.isArray(record.items) ? record.items : [];
    const rowCount = Math.max(6, items.length);
    for (let index = 0; index < rowCount; index += 1) {
      const item = items[index] || {};
      const hasItem = Object.values(item).some(hasValue);
      setFont('normal', 9);
      const descLines = wrap(item.description || '', colW[1] - 4);
      const rowH = Math.max(ROW_MIN, descLines.length * 4 + 4);
      newPageIfNeeded(rowH);
      const values = [
        hasItem ? String(index + 1) : '',
        null,
        item.hsn || '',
        item.nos || '–',
        item.set || '–',
        formatAmount(item.amount)
      ];
      let x = L;
      values.forEach((value, i) => {
        cell(x, y, colW[i], rowH);
        if (i === 1) {
          descLines.forEach((line, n) => text(line, x + 2, y + 5 + n * 4));
        } else {
          text(value, x + colW[i] / 2, y + rowH / 2 + 1.2, { align: 'center' });
        }
        x += colW[i];
      });
      y += rowH;
    }

    // ---- Total ------------------------------------------------------------
    newPageIfNeeded(HEADER_H + SIGN_H);
    const priced = items.filter(item => hasValue(item.amount));
    const total = priced.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    const labelW = colW.slice(0, 5).reduce((sum, w) => sum + w, 0);
    cell(L, y, labelW, HEADER_H);
    setFont('bold', 9);
    text('TOTAL :', L + labelW - 4, y + HEADER_H / 2 + 1.2, { align: 'right' });
    cell(L + labelW, y, colW[5], HEADER_H);
    setFont('normal', 9);
    text(priced.length ? formatAmount(total) : '–', L + labelW + colW[5] / 2, y + HEADER_H / 2 + 1.2, { align: 'center' });
    y += HEADER_H;

    // ---- Signature --------------------------------------------------------
    cell(L, y, W, SIGN_H);
    setFont('bold', 9.5);
    text('AUTHORIZED SIGNATORY :', L + 2, y + 7);

    return doc;
  };

  const fileName = (record) => {
    const safe = String(record.number || 'Draft').replace(/[^A-Za-z0-9_-]+/g, '-');
    return `Delivery-Challan-${safe}.pdf`;
  };

  // Opens the Android share sheet with the PDF attached when the browser supports file sharing.
  // Otherwise it downloads the PDF. Returns a short result string for the status line.
  const sharePdf = async (record) => {
    const doc = build(record);
    const name = fileName(record);
    const blob = doc.output('blob');
    const file = typeof File === 'function' ? new File([blob], name, { type: 'application/pdf' }) : null;
    if (file && navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: `Delivery Challan ${record.number || ''}`.trim(), text: `Delivery Challan ${record.number || ''}`.trim() });
        return 'shared';
      } catch (error) {
        if (error && error.name === 'AbortError') return 'cancelled';
      }
    }
    doc.save(name);
    return 'downloaded';
  };

  // Opens the Android share sheet with plain text (WhatsApp appears there). Returns false if unsupported.
  const shareText = async (text, title) => {
    if (!navigator.share) return false;
    try {
      await navigator.share({ title, text });
      return 'shared';
    } catch (error) {
      if (error && error.name === 'AbortError') return 'cancelled';
      return false;
    }
  };

  window.ChallanPdf = { build, fileName, sharePdf, shareText };
})();
