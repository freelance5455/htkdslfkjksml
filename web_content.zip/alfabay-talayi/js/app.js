// الفبای طلایی - منطق اصلی برنامه

const letters = [
    { letter: "ا", word: "انار", slug: "anar", sound: "الف" },
    { letter: "ب", word: "بادکنک", slug: "badkonak", sound: "ب" },
    { letter: "پ", word: "پروانه", slug: "parvane", sound: "پ" },
    { letter: "ت", word: "توپ", slug: "toop", sound: "ت" },
    { letter: "ث", word: "ثریا", slug: "soraya", sound: "ث" },
    { letter: "ج", word: "جوجه", slug: "jooje", sound: "ج" },
    { letter: "چ", word: "چتر", slug: "chatr", sound: "چ" },
    { letter: "ح", word: "حباب", slug: "habab", sound: "ح" },
    { letter: "خ", word: "خرس", slug: "khers", sound: "خ" },
    { letter: "د", word: "درخت", slug: "derakht", sound: "د" },
    { letter: "ذ", word: "ذرت", slug: "zorrat", sound: "ذ" },
    { letter: "ر", word: "روباه", slug: "rubah", sound: "ر" },
    { letter: "ز", word: "زرافه", slug: "zarafe", sound: "ز" },
    { letter: "ژ", word: "ژله", slug: "zhele", sound: "ژ" },
    { letter: "س", word: "سیب", slug: "sib", sound: "س" },
    { letter: "ش", word: "شیر", slug: "shir", sound: "ش" },
    { letter: "ص", word: "صندلی", slug: "sandal", sound: "ص" },
    { letter: "ض", word: "ضفدع", slug: "zofdagh", sound: "ض" },
    { letter: "ط", word: "طوطی", slug: "tooti", sound: "ط" },
    { letter: "ظ", word: "ظرف", slug: "zarf", sound: "ظ" },
    { letter: "ع", word: "عینک", slug: "eynak", sound: "ع" },
    { letter: "غ", word: "غنچه", slug: "ghonche", sound: "غ" },
    { letter: "ف", word: "فیل", slug: "fil", sound: "ف" },
    { letter: "ق", word: "قاشق", slug: "ghashogh", sound: "ق" },
    { letter: "ک", word: "کتاب", slug: "ketab", sound: "ک" },
    { letter: "گ", word: "گربه", slug: "gorbe", sound: "گ" },
    { letter: "ل", word: "لیمو", slug: "limo", sound: "ل" },
    { letter: "م", word: "موز", slug: "moz", sound: "م" },
    { letter: "ن", word: "نان", slug: "nan", sound: "ن" },
    { letter: "و", word: "وانت", slug: "vant", sound: "و" },
    { letter: "ه", word: "هویج", slug: "havij", sound: "ه" },
    { letter: "ی", word: "یخ", slug: "yakh", sound: "ی" }
];

let currentIndex = 0;
let gameScore = 0;
let gameStars = 0;
let totalScore = 0;
let totalStars = 0;
let learnedLetters = new Set();

// بارگذاری پیشرفت از localStorage
function loadProgress() {
    const saved = localStorage.getItem("alfabayProgress");
    if (saved) {
        const data = JSON.parse(saved);
        totalScore = data.totalScore || 0;
        totalStars = data.totalStars || 0;
        learnedLetters = new Set(data.learned || []);
        gameScore = data.gameScore || 0;
        gameStars = data.gameStars || 0;
    }
    updateProgressUI();
}

function saveProgress() {
    const data = {
        totalScore,
        totalStars,
        learned: Array.from(learnedLetters),
        gameScore,
        gameStars
    };
    localStorage.setItem("alfabayProgress", JSON.stringify(data));
}

// نمایش بخش‌ها
function showSection(id) {
    document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));
    document.getElementById(id).classList.add("active");
    if (id === "learn") loadLetter();
    if (id === "games") startGame();
    if (id === "progress") updateProgressUI();
}

// آموزش حروف
function loadLetter() {
    const item = letters[currentIndex];
    document.getElementById("currentLetter").textContent = item.letter;
    document.getElementById("currentWord").textContent = item.word;
    // استفاده از تصاویر واقعی برای حروفی که تولید شده‌اند
    const jpgSlugs = ["anar", "badkonak", "parvane", "toop", "soraya", "jooje", "chatr", "habab"];
    const ext = jpgSlugs.includes(item.slug) ? "jpg" : "svg";
    document.getElementById("letterImage").src = `images/${item.slug}.${ext}`;
    learnedLetters.add(item.letter);
    saveProgress();
}

function nextLetter() {
    currentIndex = (currentIndex + 1) % letters.length;
    loadLetter();
}

function prevLetter() {
    currentIndex = (currentIndex - 1 + letters.length) % letters.length;
    loadLetter();
}

// سیستم صوتی با Speech Synthesis
function speak(text) {
    if (!("speechSynthesis" in window)) {
        showToast("صدای فارسی روی این دستگاه پشتیبانی نمی‌شود.");
        return;
    }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "fa-IR";
    utterance.rate = 0.8;
    utterance.pitch = 1.1;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
}

function speakLetter() {
    const item = letters[currentIndex];
    speak(item.sound);
}

function speakWord() {
    const item = letters[currentIndex];
    speak(item.word);
}

// بازی
let currentGameType = 0;
let correctAnswer = "";

function startGame() {
    gameScore = 0;
    gameStars = 0;
    document.getElementById("gameScore").textContent = gameScore;
    document.getElementById("gameStars").textContent = gameStars;
    nextGameQuestion();
}

function nextGameQuestion() {
    currentGameType = Math.floor(Math.random() * 3);
    const randomLetter = letters[Math.floor(Math.random() * letters.length)];
    correctAnswer = randomLetter.letter;

    const optionsDiv = document.getElementById("gameOptions");
    optionsDiv.innerHTML = "";
    const questionEl = document.getElementById("gameQuestion");

    if (currentGameType === 0) {
        // انتخاب تصویر مرتبط
        questionEl.textContent = `کدام تصویر مربوط به حرف «${randomLetter.letter}» است؟`;
        const options = getRandomOptions(randomLetter, 3, true);
        options.forEach(opt => {
            const btn = document.createElement("button");
            btn.className = "option-btn";
            const jpgSlugs = ["anar", "badkonak", "parvane", "toop", "soraya", "jooje", "chatr", "habab"];
            const ext = jpgSlugs.includes(opt.slug) ? "jpg" : "svg";
            btn.innerHTML = `<img src="images/${opt.slug}.${ext}" style="width:80px;height:80px;border-radius:10px;object-fit:cover;"><br>${opt.word}`;
            btn.onclick = () => checkAnswer(opt.letter, btn, randomLetter.letter);
            optionsDiv.appendChild(btn);
        });
    } else if (currentGameType === 1) {
        // تشخیص حرف
        questionEl.textContent = `کدام حرف مربوط به کلمه «${randomLetter.word}» است؟`;
        const options = getRandomOptions(randomLetter, 3, false);
        options.forEach(opt => {
            const btn = document.createElement("button");
            btn.className = "option-btn";
            btn.textContent = opt.letter;
            btn.onclick = () => checkAnswer(opt.letter, btn, randomLetter.letter);
            optionsDiv.appendChild(btn);
        });
    } else {
        // سؤال چهارگزینه‌ای ساده
        questionEl.textContent = `حرف اول کلمه «${randomLetter.word}» چیست؟`;
        const options = getRandomOptions(randomLetter, 3, false);
        options.forEach(opt => {
            const btn = document.createElement("button");
            btn.className = "option-btn";
            btn.textContent = opt.letter;
            btn.onclick = () => checkAnswer(opt.letter, btn, randomLetter.letter);
            optionsDiv.appendChild(btn);
        });
    }
}

function getRandomOptions(correct, count, withImage) {
    const opts = [correct];
    while (opts.length < count + 1) {
        const rand = letters[Math.floor(Math.random() * letters.length)];
        if (!opts.includes(rand)) opts.push(rand);
    }
    return opts.sort(() => Math.random() - 0.5);
}

function checkAnswer(selected, btn, correct) {
    const buttons = document.querySelectorAll("#gameOptions .option-btn");
    buttons.forEach(b => b.disabled = true);
    if (selected === correct) {
        btn.classList.add("correct");
        gameScore += 10;
        gameStars += 1;
        totalScore += 10;
        totalStars += 1;
        showToast("آفرین! درست بود! ⭐");
        speak("آفرین");
    } else {
        btn.classList.add("wrong");
        // پیدا کردن دکمه درست
        buttons.forEach(b => {
            if (b.textContent === correct || b.innerHTML.includes(correct)) {
                b.classList.add("correct");
            }
        });
        showToast("اشکالی نداره، دوباره تلاش کن!");
    }
    document.getElementById("gameScore").textContent = gameScore;
    document.getElementById("gameStars").textContent = gameStars;
    saveProgress();
}

// معلم کوچولو - پاسخ‌های از پیش تعریف شده
const teacherResponses = {
    "سلام": "سلام کوچولوی باهوش! من معلم کوچولو هستم. امروز می‌خوای کدام حرف رو یاد بگیری؟ یا از من بپرس هر چیزی که دوست داری!",
    "ا": "حرف «ا» اولین حرف الفباست. مثل «انار». انار میوه قرمز و شیرینیه که دانه‌های قرمز زیادی داخلشه. می‌خوای صدای انار رو بشنوی؟",
    "ب": "حرف «ب»! مثل «بادکنک». بادکنک‌ها رنگی هستن و با هوا پر می‌شن و بالا می‌رن. تو دوست داری بادکنک چه رنگی داشته باشی؟",
    "پ": "حرف «پ» مثل «پروانه». پروانه‌ها بال‌های رنگی و قشنگ دارن و روی گل‌ها می‌شینن. بال پروانه چه رنگیه؟",
    "ت": "حرف «ت» مثل «توپ». با توپ می‌تونیم بازی کنیم و شوت کنیم. توپ گرد و قشنگه.",
    "ث": "حرف «ث» مثل «ثریا». ثریا یعنی خوشه‌ای از چند ستاره درخشان در آسمان شب. ستاره‌ها چشمک می‌زنن و خیلی قشنگن!",
    "ج": "حرف «ج» مثل «جوجه». جوجه زرد و بامزه است و «جیک جیک» می‌کنه. جوجه کوچولو دوست داره بدوه.",
    "چ": "حرف «چ» مثل «چتر». وقتی بارون می‌آد، چتر رو باز می‌کنیم تا خیس نشیم. چتر رنگارنگه.",
    "ح": "حرف «ح» مثل «حباب». حباب‌ها سبک هستن و با باد می‌رن بالا و می‌ترکن. دوست داری حباب درست کنی؟",
    "خ": "حرف «خ» مثل «خرس». خرس حیوان بزرگ و قهوه‌ای رنگه که عسل دوست داره. خرس خیلی قویِه.",
    "د": "حرف «د» مثل «درخت». درخت‌ها سبز هستن، برگ دارن و سایه می‌سازن. درخت دوست طبیعت است.",
    "ذ": "حرف «ذ» مثل «ذرت». ذرت زرد و خوشمزه است و می‌تونیم بو بدیم. ذرت روی گیاه بلند می‌روید.",
    "ر": "حرف «ر» مثل «روباه». روباه نارنجی است، دم بزرگ و قشنگی داره و خیلی باهوشه.",
    "ز": "حرف «ز» مثل «زرافه». زرافه گردن خیلی بلندی داره تا از بالای درخت‌ها برگ بخوره.",
    "ژ": "حرف «ژ» مثل «ژله». ژله رنگی و لرزان است و وقتی می‌لرزه خوشمزه به نظر می‌رسه.",
    "س": "حرف «س» مثل «سیب». سیب قرمز یا سبز است و خیلی سالم و خوشمزه است. روزی یک سیب بخور!",
    "ش": "حرف «ش» مثل «شیر». شیر پادشاه جنگل است، قوی و شجاع. یال بلندی داره.",
    "ص": "حرف «ص» مثل «صندلی». روی صندلی می‌شینیم و درس می‌خونیم یا غذا می‌خوریم.",
    "ض": "حرف «ض» مثل «ضفدع». ضفدع سبز است و می‌پره و «قور قور» می‌کنه. تو آب و خشکی زندگی می‌کنه.",
    "ط": "حرف «ط» مثل «طوطی». طوطی پرنده رنگی و زیبایی است که می‌تونه حرف بزنه.",
    "ظ": "حرف «ظ» مثل «ظرف». ظرف برای گذاشتن غذا یا آب استفاده می‌شه. ظرف‌ها شکل‌های مختلفی دارن.",
    "ع": "حرف «ع» مثل «عینک». عینک به چشم‌ها کمک می‌کنه بهتر ببینن. بعضی بچه‌ها عینک می‌زنن.",
    "غ": "حرف «غ» مثل «غنچه». غنچه گل هنوز باز نشده و بسته است. وقتی باز بشه گل قشنگی می‌شه.",
    "ف": "حرف «ف» مثل «فیل». فیل حیوان خیلی بزرگ با خرطوم بلند است. فیل‌ها باهوشن.",
    "ق": "حرف «ق» مثل «قاشق». با قاشق سوپ و غذا می‌خوریم. قاشق فلزی یا پلاستیکی است.",
    "ک": "حرف «ک» مثل «کتاب». کتاب پر از داستان و حرف است. دوست داری کتاب بخونی؟",
    "گ": "حرف «گ» مثل «گربه». گربه حیوان بامزه با سبیل و دم نرم است. «میو میو» می‌کنه.",
    "ل": "حرف «ل» مثل «لیمو». لیمو زرد و ترش است. از لیمو آب لیمو درست می‌کنیم.",
    "م": "حرف «م» مثل «موز». موز زرد و شیرین است و پوستش رو می‌کنیم و می‌خوریم. خیلی انرژی داره.",
    "ن": "حرف «ن» مثل «نان». نان خوشمزه است و با غذا می‌خوریم. نان از آرد درست می‌شه.",
    "و": "حرف «و» مثل «وانت». وانت ماشین حمل بار است و می‌تونه چیزهای سنگین ببره.",
    "ه": "حرف «ه» مثل «هویج». هویج نارنجی و سالم است و برای چشم‌ها خوبه. خرگوش‌ها عاشق هویج هستن.",
    "ی": "حرف «ی» مثل «یخ». یخ سرد و سفید است و در آب حل می‌شه. در تابستان یخ دوست داریم.",
    "حرف": "الفبای فارسی ۳۲ حرف داره. از «ا» شروع می‌شه و به «ی» تموم می‌شه. هر حرف صدای خاص خودش رو داره.",
    "تلفظ": "برای شنیدن تلفظ درست، دکمه صدا رو بزن. من از صدای فارسی استفاده می‌کنم. دوباره بزن تا تکرار بشه!",
    "کمک": "من اینجام تا بهت کمک کنم کوچولو! بگو کدام حرف رو نمی‌دونی یا کدام کلمه رو می‌خوای یاد بگیری. با هم یاد می‌گیریم!",
    "آفرین": "آفرین به تو! خیلی باهوشی. ادامه بده، هر روز بهتر می‌شی!",
    "اشتباه": "اشکالی نداره عزیزم! اشتباه کردن کمک می‌کنه بهتر یاد بگیریم. دوباره سعی کن، من کنارتم. 😊",
    "بازی": "دوست داری بازی کنیم؟ برو به بخش بازی و تمرین و ستاره جمع کن! آفرین اگر امتیاز بگیری.",
    "ستاره": "هر جواب درست یک ستاره می‌گیری. ستاره‌ها رو جمع کن و پیشرفت خودت رو ببین!",
    "چند": "الفبای فارسی ۳۲ حرف داره. بیا یکی یکی با هم یاد بگیریم.",
    "چی": "بگو دقیق‌تر کوچولو. مثلاً بگو «حرف ب چیه؟» یا «سیب چیه؟» تا بهتر جواب بدم."
};

function sendMessage() {
    const input = document.getElementById("chatInput");
    const text = input.value.trim();
    if (!text) return;

    addMessage(text, "user");
    input.value = "";

    setTimeout(() => {
        let response = findResponse(text);
        addMessage(response, "bot");
        // اگر اینترنت باشد می‌توان به AI وصل شد، اما کلید API در کد قرار ندارد
        if (navigator.onLine && text.includes("هوش مصنوعی")) {
            addMessage("در حالت آنلاین می‌توانم به معلم هوشمند وصل شوم، اما برای امنیت کلید API در برنامه قرار داده نشده است. فعلاً از پاسخ‌های آموزشی استفاده می‌کنم.", "bot");
        }
    }, 500);
}

function findResponse(text) {
    const lower = text.toLowerCase().replace(/[؟?!.]/g, '');
    // جستجوی دقیق‌تر
    for (const key in teacherResponses) {
        if (lower.includes(key) || lower === key) return teacherResponses[key];
    }
    // پاسخ‌های هوشمندتر
    if (lower.includes("چیه") || lower.includes("چیست") || lower.includes("یعنی")) {
        return "سوالت عالی است! بگو دقیقاً کدام حرف یا کلمه را می‌پرسی تا کامل برات توضیح بدم. مثلاً «حرف ث چیه؟»";
    }
    if (lower.includes("نمی‌دونم") || lower.includes("نمی دونم") || lower.includes("سخت")) {
        return "اشکالی نداره کوچولو! یادگیری زمان می‌بره. بیا با هم قدم به قدم یاد بگیریم. از حرف «ا» شروع کنیم؟";
    }
    if (lower.includes("آفرین") || lower.includes("خوب")) {
        return "تو خیلی خوب کار می‌کنی! ادامه بده، من بهت افتخار می‌کنم. ⭐";
    }
    if (lower.includes("بازی") || lower.includes("امتیاز")) {
        return "برو به بخش «بازی و تمرین» و سؤال‌ها رو جواب بده تا ستاره و امتیاز بگیری. موفق باشی!";
    }
    // پاسخ پیش‌فرض هوشمند
    return "من معلم کوچولوی باهوشم! درباره هر حرفی از الفبا بپرس، یا بگو «کمک» تا راهنمایی کنم. مثلاً بگو «حرف م» یا «موز چیه؟»";
}

function addMessage(text, type) {
    const messages = document.getElementById("chatMessages");
    const div = document.createElement("div");
    div.className = `message ${type}`;
    div.textContent = text;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}

// پیشرفت
function updateProgressUI() {
    document.getElementById("learnedCount").textContent = learnedLetters.size;
    document.getElementById("totalStars").textContent = totalStars;
    document.getElementById("totalScore").textContent = totalScore;

    const progressDiv = document.getElementById("letterProgress");
    progressDiv.innerHTML = "";
    letters.forEach(item => {
        const badge = document.createElement("div");
        badge.className = "letter-badge" + (learnedLetters.has(item.letter) ? " learned" : "");
        badge.textContent = item.letter;
        progressDiv.appendChild(badge);
    });
}

function resetProgress() {
    if (confirm("آیا مطمئنی می‌خواهی پیشرفت را پاک کنی؟")) {
        localStorage.removeItem("alfabayProgress");
        learnedLetters.clear();
        totalScore = 0;
        totalStars = 0;
        gameScore = 0;
        gameStars = 0;
        updateProgressUI();
        showToast("پیشرفت پاک شد!");
    }
}

function showToast(msg) {
    const toast = document.getElementById("toast");
    toast.textContent = msg;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 2500);
}

// شروع
document.addEventListener("DOMContentLoaded", () => {
    loadProgress();
    // بررسی پشتیبانی از صدا
    if (!("speechSynthesis" in window)) {
        showToast("توجه: تلفظ صوتی روی این دستگاه ممکن است کار نکند.");
    }
});
