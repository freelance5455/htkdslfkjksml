"""Loonie Academy v13 phone-first UI, curriculum, save, quiz, cross-phase smoke."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re,json,sys
ROOT=Path(__file__).parent
h=(ROOT/'index.html').read_text()
for f in ['curriculum-v6.js','curriculum-v7.js','university-v8.js','inquiry-v9.js','kingdom-v10.js','career-v11.js','life-v12.js','curriculum-v13.js','academy-v13.js']:
 assert f'<script src="{f}"></script>' in h,f
 h=h.replace(f'<script src="{f}"></script>','<script>\n'+(ROOT/f).read_text()+'\n</script>')
for f in ['university-v8.css','inquiry-v9.css','kingdom-v10.css','career-v11.css','life-v12.css','academy-v13.css']:
 assert f'<link rel="stylesheet" href="{f}">' in h,f
 h=h.replace(f'<link rel="stylesheet" href="{f}">','<style>'+ (ROOT/f).read_text()+'</style>')
h=re.sub(r'<link rel="preconnect"[^>]*>|<link href="https://fonts.googleapis.com[^>]*>','',h)

with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [320,390,768,1280]:
  ctx=b.new_context(viewport={'width':width,'height':844},accept_downloads=True)
  pg=ctx.new_page();pg.set_default_timeout(7000)
  errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  state={'onboarded':True,'done':{'79':'5/5'},'notes':{'79':'Original note'},'stars':{'79':3},'kingdomV10':{'notes':{'lantern':'Old Kingdom note'}},'careerV11':{'projects':{'accounting-1':{'passedAt':1710000000000}},'active':'accounting','portfolio':{'goal':'Old career goal'}}}
  pg.evaluate('''value=>{window.__db={loonieAcademy_v1:JSON.stringify(value)};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db[k]??null,setItem:(k,v)=>window.__db[k]=String(v),removeItem:k=>delete window.__db[k],clear:()=>{window.__db={}}}})}''',state)
  pg.set_content(h,wait_until='domcontentloaded',timeout=90000)
  pg.wait_for_function('window.LOONIE_UI_V13&&window.LOONIE_CURRICULUM_V13&&window.LOONIE_V12&&window.LOONIE_V8')
  assert not errs,errs
  result=pg.evaluate('LOONIE_CURRICULUM_V13.validate()');assert result['ok'],result
  assert result['subjects']==37 and result['lessons']==807 and result['questions']==3714,(width,result['questions'])
  assert pg.evaluate('state.notes[79]')=='Original note' and pg.evaluate('state.kingdomV10.notes.lantern')=='Old Kingdom note'
  for version in ('LOONIE_V8','LOONIE_V9','LOONIE_V10','LOONIE_V11','LOONIE_V12'):
   valid=pg.evaluate(version+'.validate()');assert valid['ok'],(width,version,valid)
  def nav(fragment):
   pg.evaluate('''h=>{document.querySelectorAll('.overlay').forEach(e=>e.remove());location.hash='#'+h;route();}''',fragment)
   assert 'Something went wrong' not in pg.locator('#screen').inner_text()[:250]
   wid=pg.evaluate('document.documentElement.scrollWidth-window.innerWidth')
   assert wid<=1,(width,fragment,'overflow',wid)
   assert not errs,(width,fragment,errs)
  nav('learn')
  assert pg.locator('.a13-subcard').count()==9,(width,pg.locator('#screen').inner_text()[:350])
  assert pg.locator('.a13-resume').count()==1
  assert pg.locator('a[href="#kingdom"]').count() and pg.locator('a[href="#life12"]').count()
  if width in [390,1280]:pg.screenshot(path=str(ROOT/f'v13-hub-{width}.png'),full_page=True)
  pg.locator('#a13-search').fill('health')
  assert 'Health & Medical' in pg.locator('#a13-matches').inner_text()
  pg.locator('#a13-search').fill('')
  pg.locator('[data-g="trades"]').click()
  assert pg.locator('.a13-subcard').count()==13
  nav('s-hlth')
  assert pg.locator('.a13-stage').count()==3 and pg.locator('.a13-lesson').count()>0
  assert '24 lessons' in pg.locator('#screen').inner_text()
  assert pg.locator('.a13-lesson').count()==24
  if width in [390,1280]:pg.screenshot(path=str(ROOT/f'v13-course-{width}.png'),full_page=True)
  pg.locator('#a13-capstone > summary').click()
  pg.locator('#a13-project').fill('Evidence-based self-study project with sample data, assumptions, and limits.')
  pg.locator('[data-rubric="0"]').check()
  assert 'Evidence-based' in pg.evaluate('state.academyV13.projects.hlth.note')
  assert pg.evaluate('state.academyV13.projects.hlth.checks.includes(0)')
  with pg.expect_download() as export:pg.locator('#a13-export').click()
  assert export.value.suggested_filename=='loonie-project-hlth.md'
  assert 'academyV13' in pg.evaluate('JSON.parse(makeBackup()).state')
  # New lesson opens quiz and earns progress using saved format.
  nav('l-385')
  assert pg.locator('.reader').count()==1
  nav('q-385')
  assert pg.locator('#screen').inner_text() and not errs
  nav('library')
  assert pg.locator('.a13-listitem').count()==24
  pg.locator('#a13-lq').fill('feedback')
  assert pg.locator('.a13-listitem').count()>0
  pg.locator('#a13-lq').fill('')
  pg.locator('#a13-bs').select_option('hlth')
  assert pg.locator('.a13-listitem').count()==24
  nav('s-acct')
  assert pg.locator('.a13-stage').count()==3
  for fragment in ['uni','inquiry','kingdom','career11','life12','me','practice','world']:
   nav(fragment)
  assert pg.evaluate('state.notes[79]')=='Original note'
  print('PASS',width,'UI/SEARCH/COURSE/LIBRARY/CAPSTONE/EXPORT/LEGACY/QUIZ',flush=True)
  ctx.close()
 b.close()
