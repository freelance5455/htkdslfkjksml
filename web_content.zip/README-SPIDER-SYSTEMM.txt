SPIDER-SYSTEMM 0.8 — PC INTERFACE ADAPTADA A MÓVIL

Qué incluye:
- La aplicación abre directamente en la interfaz principal; no hay HUB inicial.
- Diseño tipo cockpit/PC con panel de módulos, visor central y telemetría lateral.
- Adaptación automática a móvil en vertical y horizontal.
- Conserva las funciones existentes del prototipo: cámara, pantalla completa, voz,
  GPS/Google Maps, subtítulos, diagnóstico y respuestas habladas de KAREN.
- La transmisión/emitir queda fuera de esta versión.
- No incluye IA real, reconocimiento facial ni integración con máscara.

Estructura:
- spider-native/: proyecto Android WebView.
- .github/workflows/build-apk.yml: compilación automática mediante GitHub Actions.

Para generar el APK:
1. Subí el contenido de esta carpeta a tu repositorio SPIDER-SYSTEMM.
2. Abrí la pestaña Actions en GitHub.
3. Ejecutá el workflow "Build SPIDER-SYSTEMM APK" (o esperá a que se ejecute al subir cambios).
4. Descargá el artefacto APK desde la ejecución completada.

Importante:
Este paquete contiene el proyecto fuente, no un APK ya compilado. La cámara, GPS y
reconocimiento de voz requieren permisos y compatibilidad del dispositivo/WebView.
