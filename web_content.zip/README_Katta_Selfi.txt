Max Call — katta selfi oynasi

Loyiha interfeysida videoqo‘ng‘iroq paytida selfi preview oynasi kattalashtirildi. Kamera ruxsati berilgan bo‘lishi va ilova mahalliy kamera oqimini ishga tushirishi kerak. Bu ZIP loyiha fayli, tayyor APK emas. Ikki tomonlama jonli video uchun RTC/signaling xizmati kerak.
