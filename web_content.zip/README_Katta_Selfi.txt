Max Call: katta oldi/orqa kamera ekrani uchun CSS yangilanishi. Bu ZIP loyiha fayli, tayyor APK emas. Kamera ruxsati va ishlaydigan kamera oqimi talab qilinadi.
