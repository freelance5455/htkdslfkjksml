DJ File Viewer - Android-ready HTML prototype

Features in this prototype:
- Mobile-friendly home screen
- Photo-to-PDF converter (multi-photo selection, remove photos, offline conversion)
- File picker for PDF, images, Office documents, and all files
- Recent file list (session only)

IMPORTANT: This is a web-app prototype, not a compiled Android APK. An Android APK must be built using an Android packaging tool or Android Studio. This environment has no Android SDK/Gradle installed, so it cannot compile the APK directly.

For phone-based packaging:
1. Extract this ZIP.
2. Use an HTML-to-APK builder that packages a local HTML file as an Android WebView app.
3. Select index.html as the app's start page and enable offline/local assets.
4. App name: DJ File Viewer
5. Package name: com.djfileviewer.reader
6. Version: 1.0
7. Build/download the APK and install it on your Android phone.

The first prototype uses Android/browser file selection and external handlers for file viewing. Native in-app PDF and Office rendering, AdMob integration, and advanced PDF tools are future updates.
