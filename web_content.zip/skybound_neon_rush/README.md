# SKYBOUND: NEON RUSH — Game project

A polished, mobile-first endless runner prototype with a real home screen, procedural soundtrack and sound effects, pause/resume, missions, daily reward, local progression, cosmetic skin shop, stats, settings, keyboard/touch controls and responsive canvas gameplay.

## Play on PC right now
1. Extract this ZIP.
2. Open `www/index.html` in Chrome, Edge or Firefox.
3. Click PLAY. Use Space / Up Arrow / W / mouse click to jump. Press P or Esc to pause.

## Play on Android
The web game can be tested in a browser first. To package it as an Android app:
1. Install Node.js LTS and Android Studio.
2. Open a terminal in this project folder.
3. Run:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. In Android Studio, test on multiple real devices and screen sizes.
5. Set a unique application ID, app icon, version code/name, and signing key.
6. Build a signed Android App Bundle (.aab) and upload to Play Console.

This starter is pinned to Capacitor 7. Add the matching AdMob plugin version 7 if you choose the AdMob integration path below. Do not mix Capacitor major versions.

## Advertising / earning setup (important)
The browser game has no live ads. Ads must be integrated in the native Android wrapper using your own AdMob account and real ad-unit IDs. `docs/ADMOB_SETUP.md` explains a compliant implementation plan and recommended placements.

Recommended user-friendly placements:
- **Rewarded video:** user voluntarily watches an ad to earn a small coin bonus or one revive. The player must be able to decline.
- **Interstitial:** only at a natural break after the results screen, with conservative frequency caps. Never show during active gameplay, at app launch, or immediately after every tap.
- **Banner:** optional on non-gameplay menu screens only, with reserved space so it never covers controls.

Use Google's test ad IDs during development. Never click your own live ads or ask testers to do so. Replace test IDs only after the app is correctly configured and ready for production.

## Data and privacy
This prototype stores game progress/settings locally in browser/device local storage. It does not currently collect account data, analytics, location or contacts. Native advertising SDKs may collect/use data according to their configuration and consent requirements. Your final privacy policy and Play Console Data safety declarations must match the exact SDKs and behavior in your released build.

## Current scope / what is not done
- This is a playable source project, not a signed production AAB.
- AdMob is not activated: you must create your own AdMob app/ad units, configure app ID, add SDK/plugin and test consent flow.
- No online leaderboard, cloud save, multiplayer, backend, anti-cheat or server-side mission verification is included.
- Daily reward uses the device's local date and local storage; it is not tamper-resistant. Do not market it as a cash or redeemable reward.
- There is no guarantee of installs or revenue. Retention, fair ads, device testing, store assets, support and marketing are important.

## Before release checklist
- Replace placeholder package ID and create original icon, feature graphic and screenshots.
- Playtest on low/mid/high-end Android phones and tablets.
- Test offline, audio mute, app pause/resume, screen resize, low memory and ad load failures.
- Add an accurate privacy policy and complete Data safety, ads declaration, content rating and target-audience forms.
- Review current Play policies and AdMob consent requirements.
- If your personal Play developer account was created after 13 Nov 2023, Google currently requires a closed test with at least 12 opted-in testers continuously for 14 days before applying for production access. Verify your account's current Console checklist.
