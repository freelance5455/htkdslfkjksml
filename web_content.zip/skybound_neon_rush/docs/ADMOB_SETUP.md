# AdMob integration plan (Android / Capacitor)

This project intentionally does not contain real ad IDs or show live ads in its browser preview. Ads are a native Android integration step.

## 1. Create AdMob inventory
1. Create an AdMob account and add the Android app (use the final package/application ID).
2. Create ad units for rewarded video and (optionally) interstitial and banner.
3. Copy the AdMob **App ID** and each **Ad Unit ID**. Keep them private until configured; never use another developer's IDs.
4. During development, use Google's official test ad unit IDs. Do not click production ads yourself or ask testers to click them.

## 2. Install the plugin compatible with this Capacitor 7 starter
```bash
npm install @capacitor-community/admob@7
npx cap sync android
```
Follow the current plugin documentation for Capacitor 7, Android manifest App ID, SDK initialization, consent (UMP), and ad event handling:
https://github.com/capacitor-community/admob

The plugin major version must match your Capacitor major version. The current plugin README describes v8 for Capacitor 8; this starter uses Capacitor 7, so use its matching v7 line or upgrade all Capacitor packages together after testing.

## 3. Placement rules recommended for this game
- Rewarded ad: put a clear optional button on the run-results screen: “Watch an ad for +50 sparks” or “Watch an ad for one revive”. Grant the reward only after the SDK confirms the reward event. A close or failed ad gives no reward.
- Interstitial: if used, show only after a natural break such as the results screen, never during a run or at app launch. Add a frequency cap (for example, no more than one every several completed runs) and do not show one after consecutive user actions.
- Banner: optional, menu screens only. Hide it during gameplay, modal dialogs, and sensitive controls.

## 4. Consent and child-directed audiences
Implement the Google User Messaging Platform consent flow where required before requesting ads. Complete Play Console target-audience and ads declarations accurately. If the app is directed to children or mixed audiences, additional Families policy requirements apply; do not use personalized ads or SDKs that are not permitted for the selected audience.

## 5. Production checklist
- Replace test IDs only after verifying the app and consent flow.
- Test ad load failure, no-fill, offline mode, reward callback, app background/resume, and frequency caps.
- Ensure the game remains fully usable if ads fail or the user declines.
- Never make ads look like game buttons, place ads under likely tap targets, or require ad viewing to use core gameplay.
- Review current Google Play Developer Program Ads policy and AdMob policy before each release.

Official references:
- Google Play disruptive ads policy: https://support.google.com/googleplay/android-developer/answer/18265346
- AdMob rewarded ads: https://developers.google.com/admob/android/rewarded
- Capacitor Community AdMob plugin: https://github.com/capacitor-community/admob
