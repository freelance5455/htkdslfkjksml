import { chromium } from 'playwright';
const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium_headless_shell-1148/chrome-linux/headless_shell', args: ['--no-sandbox','--disable-gpu'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors=[]; page.on('pageerror', e=>errors.push(e.message));
await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(400);
for (const lvl of [1, 50, 400]) {
  await page.getByRole('button', { name: 'Levels', exact: true }).first().click();
  await page.waitForTimeout(250);
  const input = page.getByLabel('Jump to level');
  await input.fill(String(lvl));
  await page.getByRole('button', { name: 'Go', exact: true }).click();
  await page.waitForTimeout(500);
  const tut = page.getByRole('button', { name: /Start level/ });
  if (await tut.count()) await tut.click();
  await page.waitForTimeout(300);
  const box = await page.locator('canvas').boundingBox();
  await page.mouse.move(box.x + box.width/2, box.y + box.height*0.44);
  await page.mouse.down();
  await page.waitForTimeout(22000);
  await page.mouse.up();
  await page.waitForTimeout(1200);
  const t = await page.locator('body').innerText();
  const p = t.split('\n').filter(x=>/Score|Layers|Cleared|Core reached|Clean run|Flawless/.test(x)).slice(0,6);
  console.log('LEVEL', lvl, '| result overlay:', /Core reached|Clean run|Flawless/.test(t), '|', JSON.stringify(p));
  await page.screenshot({ path: `qa/play-${lvl}.png` });
  const home = page.getByRole('button', { name: /Back to base/ });
  if (await home.count()) { await home.click(); } else { await page.getByRole('button', { name: 'Back to home' }).click(); }
  await page.waitForTimeout(400);
}
console.log('ERRORS', JSON.stringify(errors));
await browser.close();
