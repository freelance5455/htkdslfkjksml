JARVIS AI - HTML/CSS/JavaScript mobile starter

RUN:
1. Extract the ZIP.
2. Open index.html in a modern Android browser (Chrome recommended).
3. Allow microphone permission for voice input. Speech recognition support varies by browser/device.

WHAT WORKS:
- Futuristic responsive interface
- Hindi/English text-to-speech (device voices)
- Speech recognition where browser supports it
- Time/date and basic command responses
- Chat UI

IMPORTANT:
This is a front-end starter, not a full ChatGPT-like AI. Real AI needs an API and a backend. Do NOT put a secret API key in app.js or any HTML file. A developer should create a small authenticated backend that stores the key securely, applies usage limits, and returns AI responses.

MAKE AN ANDROID APK (Capacitor):
Prerequisites: Node.js LTS, Android Studio, Android SDK.
1. Create a project folder and put index.html, style.css, app.js inside a folder named www.
2. In that project folder run:
   npm init -y
   npm install @capacitor/core @capacitor/cli
   npx cap init "JARVIS AI" "com.example.jarvisai" --web-dir=www
   npm install @capacitor/android
   npx cap add android
   npx cap sync android
   npx cap open android
3. Android Studio opens the project. Wait for Gradle sync.
4. For a test install: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. For a release: Build > Generate Signed Bundle / APK and create a signing key with help from a parent/teacher. Keep the signing key private and backed up.
6. Test microphone permissions and voice recognition on a real phone. Browser speech recognition may not work in every WebView; native speech recognition integration may be needed for reliable voice input.

No APK is included in this ZIP; Android Studio builds it from the project.
