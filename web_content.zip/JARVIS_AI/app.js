const chat=document.getElementById('chat'), input=document.getElementById('message'), mic=document.getElementById('mic'), listening=document.getElementById('listening');
function addMessage(who,text){const d=document.createElement('div');d.className='msg '+(who==='YOU'?'user':'jarvis');const b=document.createElement('b');b.textContent=who;const p=document.createElement('p');p.textContent=text;d.append(b,p);chat.append(d);chat.scrollTop=chat.scrollHeight}
function speak(text){if(!('speechSynthesis'in window))return; speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=/[\u0900-\u097F]/.test(text)?'hi-IN':'en-IN';u.rate=1; speechSynthesis.speak(u)}
function answer(raw){const q=raw.toLowerCase();let a;
 if(q.includes('time')||q.includes('समय')||q.includes('kitne baje'))a='अभी समय है '+new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'});
 else if(q.includes('date')||q.includes('तारीख')||q.includes('आज कौन'))a='आज की तारीख है '+new Date().toLocaleDateString('hi-IN',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
 else if(q.includes('hello')||q.includes('hi')||q.includes('नमस्ते'))a='Hello! नमस्ते। बताइए, मैं आपकी क्या मदद कर सकता हूँ?';
 else if(q.includes('weather')||q.includes('मौसम'))a='मौसम की जानकारी के लिए इंटरनेट और Weather API कनेक्शन चाहिए।';
 else if(q.includes('your name')||q.includes('नाम'))a='मेरा नाम JARVIS है — Just A Rather Very Intelligent System.';
 else if(q.includes('help')||q.includes('command')||q.includes('मदद'))a='आप time, date, weather, hello और अपना सवाल पूछ सकते हैं। You can also use the microphone.';
 else a='मैंने आपका सवाल सुना: “'+raw+'”. अभी मैं basic offline mode में हूँ। सामान्य AI जवाबों के लिए सुरक्षित server के जरिए AI API जोड़नी होगी।';
 addMessage('JARVIS',a);speak(a)}
document.getElementById('chatForm').addEventListener('submit',e=>{e.preventDefault();const v=input.value.trim();if(!v)return;addMessage('YOU',v);input.value='';answer(v)});
document.querySelectorAll('.tile').forEach(b=>b.addEventListener('click',()=>{const c=b.dataset.cmd;addMessage('YOU',c);answer(c)}));
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){const rec=new SR();rec.lang='hi-IN';rec.interimResults=false;rec.onstart=()=>{mic.classList.add('active');listening.textContent='LISTENING... / सुन रहा हूँ'};rec.onend=()=>{mic.classList.remove('active');listening.textContent='SYSTEM STANDBY · तैयार'};rec.onerror=()=>{listening.textContent='MIC ERROR · कृपया दोबारा कोशिश करें'};rec.onresult=e=>{const t=e.results[0][0].transcript;addMessage('YOU',t);answer(t)};mic.addEventListener('click',()=>{try{rec.start()}catch(e){listening.textContent='PLEASE WAIT...'}})}else{mic.addEventListener('click',()=>{listening.textContent='इस browser में voice recognition उपलब्ध नहीं है।'})}
