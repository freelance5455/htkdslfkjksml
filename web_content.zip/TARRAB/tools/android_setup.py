"""يضبط أيقونة TR وشاشة البداية وألوان TARRAB في مشروع الأندرويد (يعمل داخل GitHub Actions)."""
import glob, os, re, shutil

RES = 'android/app/src/main/res'
SRC = 'android-res'
for d in ('mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'):
    out = f'{RES}/mipmap-{d}'
    os.makedirs(out, exist_ok=True)
    shutil.copy(f'{SRC}/android-{d}.png', f'{out}/ic_launcher.png')
    shutil.copy(f'{SRC}/android-{d}.png', f'{out}/ic_launcher_round.png')
    shutil.copy(f'{SRC}/android-fg-{d}.png', f'{out}/ic_launcher_foreground.png')

# لون خلفية الأيقونة التكيفية
bg = f'{RES}/values/ic_launcher_background.xml'
with open(bg, 'w') as f:
    f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
            '    <color name="ic_launcher_background">#0E2B24</color>\n</resources>\n')

# شاشة البداية: لون زمردي مع شعار TR في المنتصف
for p in glob.glob(f'{RES}/drawable*/splash.png'):
    os.remove(p)
os.makedirs(f'{RES}/drawable', exist_ok=True)
shutil.copy(f'{SRC}/splash_logo.png', f'{RES}/drawable/splash_logo.png')
with open(f'{RES}/drawable/splash.xml', 'w') as f:
    f.write('<?xml version="1.0" encoding="utf-8"?>\n'
            '<layer-list xmlns:android="http://schemas.android.com/apk/res/android">\n'
            '    <item><color android:color="#0E2B24"/></item>\n'
            '    <item android:width="120dp" android:height="120dp" android:gravity="center"'
            ' android:drawable="@drawable/splash_logo"/>\n'
            '</layer-list>\n')

# ألوان شريط الحالة
colors = f'{RES}/values/colors.xml'
if os.path.exists(colors):
    s = open(colors).read()
    s = re.sub(r'(name="colorPrimary">)[^<]+', r'\g<1>#0E2B24', s)
    s = re.sub(r'(name="colorPrimaryDark">)[^<]+', r'\g<1>#0E2B24', s)
    s = re.sub(r'(name="colorAccent">)[^<]+', r'\g<1>#C9A45C', s)
    open(colors, 'w').write(s)
print('android resources ready')
