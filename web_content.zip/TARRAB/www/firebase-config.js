// ضع هنا إعدادات مشروع Firebase (من Project settings → Your apps → Web app)
// إذا بقيت فارغة يعمل التطبيق في "وضع المعاينة" والبيانات تُحفظ على الجهاز فقط.
export const firebaseConfig = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
};
