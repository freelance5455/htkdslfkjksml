// تعريف الصفحات: كل تبويبة من الإكسل = صفحة، وكل جدول داخل التبويبة = قسم
export const CURRENCIES = ['$', 'TL', '€', 'S.P'];

// صفحات المصاريف التي تدخل في حساب "الرئيسية"
export const EXPENSE_PAGES = ['transfers', 'site', 'ghufran', 'debts', 'apps'];

export const PAGES = [
  {
    id: 'main', title: 'الرئيسية', short: 'الرئيسية', dashboard: true,
    groups: [{ sections: [{ id: 'received', title: 'المبلغ المستلم' }] }],
  },
  {
    id: 'transfers', title: 'حوالات', short: 'حوالات',
    groups: [{ sections: [{ id: 'main', title: 'الحوالات' }] }],
    summary: [{ label: 'مجموع الحوالات' }],
  },
  {
    id: 'site', title: 'مصاريف الموقع', short: 'مصاريف الموقع',
    groups: [{ sections: [{ id: 'main', title: 'المصاريف' }] }],
    summary: [{ label: 'مجموع مصاريف الموقع' }],
  },
  {
    id: 'ghufran', title: 'غفران', short: 'غفران',
    groups: [{ sections: [{ id: 'main', title: 'حوالات غفران' }] }],
    summary: [{ label: 'مجموع حوالات غفران' }],
  },
  {
    id: 'debts', title: 'ديون', short: 'ديون',
    groups: [{
      sections: [
        { id: 'general', title: 'ديون متفرقة' },
        { id: 'yaman', title: 'ديون يمان' },
        { id: 'mahmoud', title: 'دين محمود', totalLabel: 'الباقي' },
        { id: 'kamel', title: 'دين كامل', totalLabel: 'الباقي' },
        { id: 'saeed', title: 'دين سعيد', totalLabel: 'الباقي' },
      ],
    }],
    summary: [{ label: 'مجموع الديون' }],
  },
  {
    id: 'apps', title: 'التطبيقات الجديدة', short: 'التطبيقات',
    groups: [{ sections: [{ id: 'main', title: 'التطبيقات الجديدة' }] }],
    summary: [{ label: 'مجموع التطبيقات الجديدة' }],
  },
  {
    id: 'sahban', title: 'سحبان', short: 'سحبان',
    groups: [{
      sections: [
        { id: 'received', title: 'المستلم' },
        { id: 'zeina', title: 'تسليم محمد زينة' },
      ],
    }],
    summary: [{ label: 'مجموع المستلم', sections: ['received'] }],
  },
  {
    id: 'syrian', title: 'الحساب السوري', short: 'الحساب السوري',
    groups: [{
      sections: [
        { id: 'main', title: 'الحساب السوري', totalLabel: 'الباقي' },
        { id: 'converted', title: 'الباقي بعد التحويل إلى دولار', totalLabel: 'الباقي' },
      ],
    }],
    summary: [
      { label: 'الباقي بالسوري', sections: ['main'], only: 'S.P' },
      { label: 'الباقي بالدولار', sections: ['converted'] },
    ],
  },
  {
    id: 'family', title: 'دفعات الأهل', short: 'دفعات الأهل', separate: true,
    groups: [
      {
        title: 'دفعات الأهل',
        sections: [
          { id: 'family_iqbal', title: 'إقبال' },
          { id: 'family_yaman', title: 'يمان' },
          { id: 'family_nibal', title: 'نبال' },
        ],
      },
      {
        title: 'دفعات غفران',
        sections: [
          { id: 'ghufran_iqbal', title: 'إقبال' },
          { id: 'ghufran_yaman', title: 'يمان' },
        ],
      },
    ],
    summary: [
      { label: 'مجموع دفعات الأهل', sections: ['family_iqbal', 'family_yaman', 'family_nibal'] },
      { label: 'مجموع دفعات غفران', sections: ['ghufran_iqbal', 'ghufran_yaman'] },
    ],
  },
];

export const pageById = (id) => PAGES.find((p) => p.id === id);
export const sectionsOf = (page) => page.groups.flatMap((g) => g.sections);
