/* =========================================================
   SMART DASHBOARD 2.0
   ========================================================= */


/* =========================================================
   CONFIGURATION
   ========================================================= */

const CONFIG = {

  version: "2.0",

  ntfy: {
    jacob: "request-jacob-only6655223",
    ivy: "request-ivy-only20172010",
    dinner: "dinner-notify-button002211",
    both: "request-both-kids-button290713201017"
  },

  profiles: {

    mum: {
      defaultName: "Mum",
      avatar: "👩",
      colour: "#4d9fff"
    },

    dad: {
      defaultName: "Dad",
      avatar: "👨",
      colour: "#55df8a"
    },

    jacob: {
      defaultName: "Jacob",
      avatar: "👦",
      colour: "#7c5cff"
    },

    ivy: {
      defaultName: "Ivy",
      avatar: "👧",
      colour: "#ff72b6"
    }

  }

};


/* =========================================================
   STATE
   ========================================================= */

let currentProfile = null;

let guestMode = false;

let setupStep = 1;

let setupData = {
  name: "",
  colour: "#7c5cff",
  avatar: "👤"
};

let musicPlaying = false;

let musicProgress = 20;

let screenSaverTimer = null;

let notifications = [];

let shoppingList = [];

let familyPresence = {

  mum: "home",
  dad: "home",
  jacob: "home",
  ivy: "home"

};


/* =========================================================
   STARTUP
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

  loadStoredData();

  updateClock();

  setInterval(updateClock, 1000);

  setTimeout(() => {

    const startup =
      document.getElementById("startupScreen");

    if (startup) {
      startup.classList.add("hidden");
    }

    showProfileScreen();

  }, 3000);

  startScreensaverTimer();

});


/* =========================================================
   STORAGE
   ========================================================= */

function loadStoredData() {

  try {

    const savedProfiles =
      JSON.parse(
        localStorage.getItem(
          "smartDashboardProfiles"
        )
      );

    if (savedProfiles) {

      Object.keys(savedProfiles).forEach(id => {

        if (CONFIG.profiles[id]) {

          CONFIG.profiles[id] = {

            ...CONFIG.profiles[id],

            ...savedProfiles[id]

          };

        }

      });

    }

    shoppingList =
      JSON.parse(
        localStorage.getItem(
          "smartDashboardShopping"
        )
      ) || [];

  } catch (error) {

    console.log(
      "Storage unavailable.",
      error
    );

  }

}


function saveProfiles() {

  try {

    localStorage.setItem(
      "smartDashboardProfiles",
      JSON.stringify(CONFIG.profiles)
    );

  } catch (error) {

    console.error(
      "Could not save profiles.",
      error
    );

  }

}


function saveShopping() {

  try {

    localStorage.setItem(
      "smartDashboardShopping",
      JSON.stringify(shoppingList)
    );

  } catch (error) {

    console.error(
      "Could not save shopping list.",
      error
    );

  }

}


/* =========================================================
   PROFILE SCREEN
   ========================================================= */

function showProfileScreen() {

  const screen =
    document.getElementById(
      "profileScreen"
    );

  if (!screen)
    return;

  screen.classList.remove("hidden");

  renderProfiles();

}


function renderProfiles() {

  const grid =
    document.getElementById(
      "profileGrid"
    );

  if (!grid)
    return;

  grid.innerHTML = "";

  Object.entries(CONFIG.profiles)
    .forEach(([id, profile]) => {

      const button =
        document.createElement("button");

      button.className =
        "profile-card";

      button.style.setProperty(
        "--accent",
        profile.colour
      );

      button.innerHTML = `

        <div class="avatar large">
          ${profile.avatar}
        </div>

        <h2>
          ${escapeHtml(profile.defaultName)}
        </h2>

        <p>
          Family profile
        </p>

      `;

      button.onclick =
        () => selectProfile(id);

      grid.appendChild(button);

    });

}


/* =========================================================
   PROFILE SELECTION
   ========================================================= */

function selectProfile(id) {

  currentProfile = id;

  const profile =
    CONFIG.profiles[id];

  applyProfileTheme(profile);

  const saved =
    localStorage.getItem(
      `profileSetup_${id}`
    );

  if (!saved) {

    setupData = {

      name: profile.defaultName,
      colour: profile.colour,
      avatar: profile.avatar

    };

    setupStep = 1;

    showSetup();

    return;

  }

  try {

    const data =
      JSON.parse(saved);

    setupData = data;

    applyProfileTheme(data);

    enterDashboard();

  } catch (error) {

    console.error(
      "Profile data error.",
      error
    );

    setupStep = 1;

    showSetup();

  }

}


function applyProfileTheme(profile) {

  const colour =
    profile.colour ||
    "#7c5cff";

  document.documentElement
    .style.setProperty(
      "--accent",
      colour
    );

  const rgb =
    hexToRgb(colour);

  document.documentElement
    .style.setProperty(
      "--accent-rgb",
      `${rgb.r}, ${rgb.g}, ${rgb.b}`
    );

}


/* =========================================================
   PROFILE SETUP
   ========================================================= */

function showSetup() {

  const profileScreen =
    document.getElementById(
      "profileScreen"
    );

  const setupScreen =
    document.getElementById(
      "setupScreen"
    );

  if (profileScreen)
    profileScreen.classList.add("hidden");

  if (setupScreen)
    setupScreen.classList.remove("hidden");

  renderSetup();

}


function renderSetup() {

  const content =
    document.getElementById(
      "setupContent"
    );

  const progress =
    document.getElementById(
      "setupProgress"
    );

  const label =
    document.getElementById(
      "setupStepLabel"
    );

  if (!content)
    return;

  if (progress) {

    progress.style.width =
      `${(setupStep / 3) * 100}%`;

  }

  if (label) {

    label.textContent =
      `STEP ${setupStep} OF 3`;

  }


  if (setupStep === 1) {

    content.innerHTML = `

      <div class="setup-content">

        <div class="avatar large">
          ${setupData.avatar}
        </div>

        <h1>
          Welcome to your profile 👋
        </h1>

        <p>
          What would you like Smart Dashboard
          to call you?
        </p>

        <input
          id="setupName"
          class="name-input"
          placeholder="Your name"
          value="${escapeAttribute(
            setupData.name
          )}"
        >

        <button
          class="primary-button"
          onclick="nextSetupStep()">

          Continue →

        </button>

      </div>

    `;

    return;

  }


  if (setupStep === 2) {

    const colours = [

      "#7c5cff",
      "#4d9fff",
      "#55df8a",
      "#ff9f43",
      "#ff647c",
      "#ff72b6",
      "#00c2ff",
      "#ffffff"

    ];

    content.innerHTML = `

      <div class="setup-content">

        <h1>
          Choose your colour 🎨
        </h1>

        <p>
          This colour will personalise
          your dashboard.
        </p>

        <div class="colour-grid">

          ${colours.map(colour => `

            <button
              class="colour-choice
              ${
                setupData.colour === colour
                  ? "selected"
                  : ""
              }"
              style="
                background:${colour};
                color:${colour};
              "
              onclick="chooseColour('${colour}')">
            </button>

          `).join("")}

        </div>

        <button
          class="primary-button"
          onclick="nextSetupStep()">

          Continue →

        </button>

      </div>

    `;

    return;

  }


  if (setupStep === 3) {

    const avatars = [

      "👤",
      "🙂",
      "😎",
      "🤓",
      "⭐",
      "🏠",
      "🐶",
      "🐱",
      "🚀",
      "🎮"

    ];

    content.innerHTML = `

      <div class="setup-content">

        <h1>
          Choose your avatar
        </h1>

        <p>
          Pick something that represents you.
        </p>

        <div class="avatar-choice-grid">

          ${avatars.map(avatar => `

            <button
              class="avatar-choice
              ${
                setupData.avatar === avatar
                  ? "selected"
                  : ""
              }"
              onclick="chooseAvatar('${avatar}')">

              ${avatar}

            </button>

          `).join("")}

        </div>

        <button
          class="primary-button"
          onclick="finishSetup()">

          Finish 🎉

        </button>

      </div>

    `;

  }

}


function nextSetupStep() {

  if (setupStep === 1) {

    const input =
      document.getElementById(
        "setupName"
      );

    if (!input)
      return;

    if (!input.value.trim()) {

      showToast(
        "Please enter a name."
      );

      return;

    }

    setupData.name =
      input.value.trim();

  }

  setupStep++;

  renderSetup();

}


function chooseColour(colour) {

  setupData.colour =
    colour;

  applyProfileTheme(
    setupData
  );

  renderSetup();

}


function chooseAvatar(avatar) {

  setupData.avatar =
    avatar;

  renderSetup();

}


function finishSetup() {

  if (!currentProfile)
    return;

  CONFIG.profiles[currentProfile] = {

    ...CONFIG.profiles[currentProfile],

    defaultName:
      setupData.name,

    colour:
      setupData.colour,

    avatar:
      setupData.avatar

  };

  localStorage.setItem(

    `profileSetup_${currentProfile}`,

    JSON.stringify(setupData)

  );

  saveProfiles();

  applyProfileTheme(
    setupData
  );

  showToast(
    `Perfect, ${setupData.name}! 🎉`
  );

  setTimeout(
    enterDashboard,
    700
  );

}


/* =========================================================
   DASHBOARD
   ========================================================= */

function enterDashboard() {

  const setup =
    document.getElementById(
      "setupScreen"
    );

  const profiles =
    document.getElementById(
      "profileScreen"
    );

  const app =
    document.getElementById(
      "app"
    );

  if (setup)
    setup.classList.add("hidden");

  if (profiles)
    profiles.classList.add("hidden");

  if (app)
    app.classList.remove("hidden");

  updateProfileUI();

  renderCalendar();

  updateShoppingPreview();

  updatePresenceUI();

  showPage(
    "dashboardPage"
  );

}


function updateProfileUI() {

  const profile =
    CONFIG.profiles[currentProfile];

  if (!profile)
    return;

  const name =
    profile.defaultName;

  const headerName =
    document.getElementById(
      "headerName"
    );

  const dashboardName =
    document.getElementById(
      "dashboardName"
    );

  const headerAvatar =
    document.getElementById(
      "headerAvatar"
    );

  if (headerName)
    headerName.textContent =
      name;

  if (dashboardName)
    dashboardName.textContent =
      name;

  if (headerAvatar)
    headerAvatar.textContent =
      profile.avatar;

  updateGreeting();

}


function updateGreeting() {

  const hour =
    new Date().getHours();

  let greeting =
    "GOOD EVENING";

  if (hour < 12)
    greeting =
      "GOOD MORNING";

  else if (hour < 18)
    greeting =
      "GOOD AFTERNOON";

  const element =
    document.getElementById(
      "greetingText"
    );

  if (element)
    element.textContent =
      greeting;

}


/* =========================================================
   CLOCK
   ========================================================= */

function updateClock() {

  const now =
    new Date();

  const time =
    now.toLocaleTimeString(
      "en-GB",
      {
        hour: "2-digit",
        minute: "2-digit"
      }
    );

  const date =
    now.toLocaleDateString(
      "en-GB",
      {
        weekday: "long",
        day: "numeric",
        month: "long"
      }
    );

  const clock =
    document.getElementById(
      "clock"
    );

  const dateElement =
    document.getElementById(
      "date"
    );

  if (clock)
    clock.textContent =
      time;

  if (dateElement)
    dateElement.textContent =
      date;

  const saverTime =
    document.getElementById(
      "screensaverTime"
    );

  const saverDate =
    document.getElementById(
      "screensaverDate"
    );

  if (saverTime)
    saverTime.textContent =
      time;

  if (saverDate)
    saverDate.textContent =
      date;

}


/* =========================================================
   CALENDAR
   ========================================================= */

const calendarData = [

  {
    time: "09:00",
    title: "School",
    detail: "Today"
  },

  {
    time: "17:30",
    title: "Dinner",
    detail: "Family"
  },

  {
    time: "20:00",
    title: "Evening",
    detail: "Home"
  }

];


function renderCalendar() {

  const small =
    document.getElementById(
      "calendarEvents"
    );

  const full =
    document.getElementById(
      "fullCalendar"
    );

  if (!small || !full)
    return;

  const html =
    calendarData.map(
      event => `

        <div class="calendar-event">

          <div class="event-time">
            ${escapeHtml(event.time)}
          </div>

          <div class="event-info">

            <strong>
              ${escapeHtml(event.title)}
            </strong>

            <span>
              ${escapeHtml(event.detail)}
            </span>

          </div>

        </div>

      `
    ).join("");

  small.innerHTML =
    html;

  full.innerHTML =
    html;

}


function openCalendar() {

  showPage(
    "calendarPage"
  );

}


/* =========================================================
   PAGE NAVIGATION
   ========================================================= */

function showPage(pageId) {

  document
    .querySelectorAll(".page")
    .forEach(page => {

      page.classList.add(
        "hidden"
      );

      page.classList.remove(
        "active"
      );

    });

  const page =
    document.getElementById(
      pageId
    );

  if (!page)
    return;

  page.classList.remove(
    "hidden"
  );

  page.classList.add(
    "active"
  );

}


function goHome() {

  if (musicPlaying) {

    showPage(
      "nowPlayingPage"
    );

  } else {

    showPage(
      "dashboardPage"
    );

  }

}


/* =========================================================
   MUSIC
   ========================================================= */

function openMusic() {

  if (musicPlaying) {

    showPage(
      "nowPlayingPage"
    );

    return;

  }

  showToast(
    "Opening Spotify..."
  );

  setTimeout(() => {

    window.open(
      "https://open.spotify.com/",
      "_blank"
    );

  }, 300);

}


function startDemoMusic() {

  musicPlaying =
    true;

  const musicTitle =
    document.getElementById(
      "musicTitle"
    );

  const musicArtist =
    document.getElementById(
      "musicArtist"
    );

  const nowPlayingTitle =
    document.getElementById(
      "nowPlayingTitle"
    );

  const nowPlayingArtist =
    document.getElementById(
      "nowPlayingArtist"
    );

  const playButton =
    document.getElementById(
      "playPauseButton"
    );

  if (musicTitle)
    musicTitle.textContent =
      "Demo Song";

  if (musicArtist)
    musicArtist.textContent =
      "Smart Dashboard";

  if (nowPlayingTitle)
    nowPlayingTitle.textContent =
      "Demo Song";

  if (nowPlayingArtist)
    nowPlayingArtist.textContent =
      "Smart Dashboard";

  if (playButton)
    playButton.textContent =
      "⏸️";

  showPage(
    "nowPlayingPage"
  );

}


function musicAction(action) {

  if (action === "play") {

    musicPlaying =
      !musicPlaying;

    const button =
      document.getElementById(
        "playPauseButton"
      );

    if (button) {

      button.textContent =
        musicPlaying
          ? "⏸️"
          : "▶️";

    }

    if (musicPlaying) {

      showPage(
        "nowPlayingPage"
      );

    }

  }


  if (action === "previous") {

    showToast(
      "Previous track"
    );

  }


  if (action === "next") {

    showToast(
      "Next track"
    );

  }


  if (action === "shuffle") {

    showToast(
      "Shuffle toggled"
    );

  }


  if (action === "repeat") {

    showToast(
      "Repeat toggled"
    );

  }

}


function changeVolume(value) {

  const element =
    document.getElementById(
      "volumeValue"
    );

  if (element)
    element.textContent =
      `${value}%`;

}


/* =========================================================
   NTFY
   ========================================================= */

async function sendNtfy(type) {

  const topic =
    CONFIG.ntfy[type];

  if (!topic) {

    showToast(
      "This ntfy topic isn't configured."
    );

    return;

  }

  let title = "";
  let message = "";

  if (type === "jacob") {

    title =
      "Smart Dashboard";

    message =
      "Jacob, someone needs you! 👋";

  }


  if (type === "ivy") {

    title =
      "Smart Dashboard";

    message =
      "Ivy, someone needs you! 👋";

  }


  if (type === "dinner") {

    title =
      "Dinner Ready 🍽️";

    message =
      "Dinner is ready! 🍽️";

  }


  if (type === "both") {

    title =
      "Smart Dashboard";

    message =
      "Both kids are needed! 👋";

  }


  if (!title || !message) {

    showToast(
      "Notification details are missing."
    );

    return;

  }


  try {

    showToast(
      "Sending notification..."
    );

    const response =
      await fetch(

        `https://ntfy.sh/${encodeURIComponent(
          topic
        )}`,

        {

          method: "POST",

          headers: {

            "Title":
              title,

            "Priority":
              "high",

            "Tags":
              type === "dinner"
                ? "fork_and_knife"
                : "house"

          },

          body:
            message

        }

      );


    /*
      IMPORTANT FIX:
      fetch() does not automatically throw
      when ntfy returns an HTTP error.

      We explicitly check response.ok.
    */

    if (!response.ok) {

      throw new Error(
        `ntfy HTTP ${response.status}`
      );

    }


    addNotification(
      title,
      message
    );

    showToast(
      "Notification sent ✓"
    );


  } catch (error) {

    console.error(
      "NTFY ERROR:",
      error
    );

    showToast(
      "Couldn't send ntfy notification."
    );

  }

}


/* =========================================================
   EASY DINNER BUTTON FUNCTION
   ========================================================= */

function sendDinnerReady() {

  sendNtfy(
    "dinner"
  );

}


/* =========================================================
   NOTIFICATIONS
   ========================================================= */

function addNotification(
  title,
  message
) {

  notifications.unshift({

    title:
      title,

    message:
      message,

    time:
      new Date()

  });

  updateNotificationBadge();

}


function updateNotificationBadge() {

  const badge =
    document.getElementById(
      "notificationBadge"
    );

  if (!badge)
    return;

  badge.textContent =
    notifications.length;

  badge.classList.toggle(
    "hidden",
    notifications.length === 0
  );

}


function openNotifications() {

  const html =
    notifications.length

      ? notifications.map(
          item => `

            <div class="calendar-event">

              <div class="event-time">
                🔔
              </div>

              <div class="event-info">

                <strong>
                  ${escapeHtml(
                    item.title
                  )}
                </strong>

                <span>
                  ${escapeHtml(
                    item.message
                  )}
                </span>

              </div>

            </div>

          `
        ).join("")

      : `

        <p>
          No notifications.
        </p>

      `;

  openModal(`

    <h2>
      Notifications
    </h2>

    ${html}

  `);

}


/* =========================================================
   HOME / PRESENCE
   ========================================================= */

function updatePresenceUI() {

  const people = [

    "mum",
    "dad",
    "jacob",
    "ivy"

  ];

  people.forEach(
    person => {

      const element =
        document.getElementById(
          `${person}Status`
        );

      if (!element)
        return;

      element.textContent =

        familyPresence[person] ===
        "home"

          ? "Home"
          : "Away";

    }
  );


  const allHome =
    people.every(
      person =>
        familyPresence[person] ===
        "home"
    );


  const pill =
    document.getElementById(
      "homeStatusPill"
    );


  if (pill) {

    pill.innerHTML =

      `<span></span>${
        allHome
          ? "Everyone Home"
          : "Someone is Away"
      }`;

    pill.classList.toggle(
      "home",
      allHome
    );

  }

}


function openPresence() {

  openModal(`

    <h2>
      Family Home & Away
    </h2>

    <p>
      Current family presence.
    </p>

    ${Object.entries(
      familyPresence
    ).map(
      ([person, status]) => `

        <div class="calendar-event">

          <div class="event-time">
            ${
              status === "home"
                ? "🟢"
                : "🔴"
            }
          </div>

          <div class="event-info">

            <strong>
              ${personName(person)}
            </strong>

            <span>
              ${
                status === "home"
                  ? "Home"
                  : "Away"
              }
            </span>

          </div>

        </div>

      `
    ).join("")}

  `);

}


/* =========================================================
   SMART HOME
   ========================================================= */

function openHomeControls() {

  openModal(`

    <h2>
      🏠 Home
    </h2>

    <p>
      Smart-home controls will connect
      to your native Android layer.
    </p>

    <button
      class="primary-button"
      onclick="
        showToast('Lights turned on');
        closeModal();
      ">

      💡 Lights On

    </button>

  `);

}


function openRooms() {

  openModal(`

    <h2>
      💡 Rooms
    </h2>

    <div class="settings-grid">

      <button
        class="settings-card"
        onclick="
          showToast('Living Room selected')
        ">

        🛋️

        <strong>
          Living Room
        </strong>

        <span>
          Lights & devices
        </span>

      </button>


      <button
        class="settings-card"
        onclick="
          showToast('Kitchen selected')
        ">

        🍳

        <strong>
          Kitchen
        </strong>

        <span>
          Lights & devices
        </span>

      </button>


      <button
        class="settings-card"
        onclick="
          showToast('Bedroom selected')
        ">

        🛏️

        <strong>
          Bedroom
        </strong>

        <span>
          Lights & devices
        </span>

      </button>

    </div>

  `);

}


function openCameras() {

  openModal(`

    <h2>
      📷 Cameras
    </h2>

    <p>
      Camera feeds will be connected
      through the native Android integration.
    </p>

  `);

}


/* =========================================================
   SHOPPING
   ========================================================= */

function openShopping() {

  openModal(`

    <h2>
      🛒 Shopping List
    </h2>

    <input
      id="shoppingInput"
      class="modal-input"
      placeholder="Add something..."
      onkeydown="
        if(event.key === 'Enter')
          addShoppingItem();
      "
    >

    <button
      class="primary-button"
      onclick="addShoppingItem()">

      Add Item

    </button>

    <div
      id="shoppingItems"
      style="margin-top:20px">

    </div>

  `);

  renderShoppingItems();

}


function addShoppingItem() {

  const input =
    document.getElementById(
      "shoppingInput"
    );

  if (!input)
    return;

  const value =
    input.value.trim();

  if (!value) {

    showToast(
      "Enter something first."
    );

    return;

  }

  shoppingList.push({

    text:
      value,

    bought:
      false,

    time:
      new Date().toISOString()

  });

  saveShopping();

  input.value = "";

  renderShoppingItems();

  updateShoppingPreview();

  showToast(
    "Added to shopping list ✓"
  );

}


function renderShoppingItems() {

  const container =
    document.getElementById(
      "shoppingItems"
    );

  if (!container)
    return;

  if (!shoppingList.length) {

    container.innerHTML = `

      <p>
        Your shopping list is empty.
      </p>

    `;

    return;

  }

  container.innerHTML =
    shoppingList.map(
      (item, index) => `

        <div
          class="calendar-event"
          style="cursor:pointer"
          onclick="
            toggleShoppingItem(${index})
          "
        >

          <div class="event-time">
            ${
              item.bought
                ? "✅"
                : "🛒"
            }
          </div>

          <div class="event-info">

            <strong
              style="
                ${
                  item.bought
                    ? "text-decoration:line-through;opacity:.5"
                    : ""
                }
              "
            >
              ${escapeHtml(item.text)}
            </strong>

            <span>
              ${
                item.bought
                  ? "Bought"
                  : "Tap to mark bought"
              }
            </span>

          </div>

        </div>

      `
    ).join("");

}


function toggleShoppingItem(index) {

  if (!shoppingList[index])
    return;

  shoppingList[index].bought =
    !shoppingList[index].bought;

  saveShopping();

  renderShoppingItems();

  updateShoppingPreview();

}


function clearBoughtShopping() {

  shoppingList =
    shoppingList.filter(
      item => !item.bought
    );

  saveShopping();

  renderShoppingItems();

  updateShoppingPreview();

}


function updateShoppingPreview() {

  const preview =
    document.getElementById(
      "shoppingPreview"
    );

  if (!preview)
    return;

  const remaining =
    shoppingList.filter(
      item => !item.bought
    );

  if (!remaining.length) {

    preview.textContent =
      "Shopping list is empty";

    return;

  }

  preview.textContent =
    `${remaining.length} item${
      remaining.length === 1
        ? ""
        : "s"
    } to get`;

}


/* =========================================================
   GUEST MODE
   ========================================================= */

function enterGuestMode() {

  guestMode =
    true;

  showToast(
    "Guest Mode enabled"
  );

  showPage(
    "dashboardPage"
  );

}


function exitGuestMode() {

  guestMode =
    false;

  showToast(
    "Guest Mode disabled"
  );

  showPage(
    "dashboardPage"
  );

}


/* =========================================================
   MOVIE MODE
   ========================================================= */

function startMovieMode() {

  document.body.classList.add(
    "movie-mode"
  );

  showToast(
    "Movie Mode active 🎬"
  );

}


function stopMovieMode() {

  document.body.classList.remove(
    "movie-mode"
  );

  showToast(
    "Movie Mode ended"
  );

}


/* =========================================================
   SCREENSAVER
   ========================================================= */

function startScreensaverTimer() {

  clearTimeout(
    screenSaverTimer
  );

  screenSaverTimer =
    setTimeout(
      showScreensaver,
      5 * 60 * 1000
    );

}


function resetScreensaverTimer() {

  clearTimeout(
    screenSaverTimer
  );

  startScreensaverTimer();

}


function showScreensaver() {

  const saver =
    document.getElementById(
      "screensaver"
    );

  if (!saver)
    return;

  saver.classList.remove(
    "hidden"
  );

}


function hideScreensaver() {

  const saver =
    document.getElementById(
      "screensaver"
    );

  if (!saver)
    return;

  saver.classList.add(
    "hidden"
  );

  resetScreensaverTimer();

}


/* =========================================================
   MODAL
   ========================================================= */

function openModal(content) {

  const modal =
    document.getElementById(
      "modal"
    );

  const modalContent =
    document.getElementById(
      "modalContent"
    );

  if (!modal || !modalContent)
    return;

  modalContent.innerHTML =
    content;

  modal.classList.remove(
    "hidden"
  );

}


function closeModal() {

  const modal =
    document.getElementById(
      "modal"
    );

  if (!modal)
    return;

  modal.classList.add(
    "hidden"
  );

}


/* =========================================================
   TOAST
   ========================================================= */

function showToast(message) {

  let toast =
    document.getElementById(
      "toast"
    );

  if (!toast) {

    toast =
      document.createElement(
        "div"
      );

    toast.id =
      "toast";

    toast.className =
      "toast";

    document.body.appendChild(
      toast
    );

  }

  toast.textContent =
    message;

  toast.classList.add(
    "show"
  );

  clearTimeout(
    toast._timer
  );

  toast._timer =
    setTimeout(() => {

      toast.classList.remove(
        "show"
      );

    }, 2500);

}


/* =========================================================
   HELPERS
   ========================================================= */

function personName(person) {

  if (
    CONFIG.profiles[person]
  ) {

    return CONFIG.profiles[
      person
    ].defaultName;

  }

  return person;

}


function hexToRgb(hex) {

  const clean =
    String(hex)
      .replace("#", "");

  const bigint =
    parseInt(
      clean,
      16
    );

  return {

    r:
      (bigint >> 16) & 255,

    g:
      (bigint >> 8) & 255,

    b:
      bigint & 255

  };

}


function escapeHtml(value) {

  return String(value)
    .replace(
      /&/g,
      "&amp;"
    )
    .replace(
      /</g,
      "&lt;"
    )
    .replace(
      />/g,
      "&gt;"
    )
    .replace(
      /"/g,
      "&quot;"
    )
    .replace(
      /'/g,
      "&#039;"
    );

}


function escapeAttribute(value) {

  return escapeHtml(
    value
  );

}


/* =========================================================
   ACTIVITY RESET
   ========================================================= */

document.addEventListener(
  "click",
  resetScreensaverTimer
);

document.addEventListener(
  "touchstart",
  resetScreensaverTimer
);


/* =========================================================
   GLOBAL EXPORTS
   ========================================================= */

window.sendNtfy =
  sendNtfy;

window.sendDinnerReady =
  sendDinnerReady;

window.selectProfile =
  selectProfile;

window.nextSetupStep =
  nextSetupStep;

window.chooseColour =
  chooseColour;

window.chooseAvatar =
  chooseAvatar;

window.finishSetup =
  finishSetup;

window.showPage =
  showPage;

window.goHome =
  goHome;

window.openMusic =
  openMusic;

window.startDemoMusic =
  startDemoMusic;

window.musicAction =
  musicAction;

window.changeVolume =
  changeVolume;

window.openCalendar =
  openCalendar;

window.openNotifications =
  openNotifications;

window.openPresence =
  openPresence;

window.openHomeControls =
  openHomeControls;

window.openRooms =
  openRooms;

window.openCameras =
  openCameras;

window.openShopping =
  openShopping;

window.addShoppingItem =
  addShoppingItem;

window.toggleShoppingItem =
  toggleShoppingItem;

window.clearBoughtShopping =
  clearBoughtShopping;

window.enterGuestMode =
  enterGuestMode;

window.exitGuestMode =
  exitGuestMode;

window.startMovieMode =
  startMovieMode;

window.stopMovieMode =
  stopMovieMode;

window.showScreensaver =
  showScreensaver;

window.hideScreensaver =
  hideScreensaver;

window.openModal =
  openModal;

window.closeModal =
  closeModal;

window.showToast =
  showToast;