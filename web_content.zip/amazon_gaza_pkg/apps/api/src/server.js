const express=require('express');const cors=require('cors');const helmet=require('helmet');
const app=express();app.use(helmet());app.use(cors());app.use(express.json({limit:'2mb'}));
app.get('/api/health',(req,res)=>res.json({ok:true,app:'AMAZON GAZA',online:true}));
app.get('/api/products',(req,res)=>res.json({products:[]}));
app.get('/api/categories',(req,res)=>res.json({categories:[]}));
app.listen(process.env.PORT||3000,()=>console.log('AMAZON GAZA API running'));
