package com.example.gpsspoofer

import android.app.Activity
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.provider.Settings
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var spoofing = false
    private var lat = 41.3874
    private var lon = 2.1686

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun setPoint(latitude: Double, longitude: Double) {
            runOnUiThread {
                lat = latitude
                lon = longitude
                if (spoofing) pushMockLocation()
            }
        }

        @JavascriptInterface fun startSpoof() {
            runOnUiThread {
                val selected = Settings.Secure.getString(contentResolver, "mock_location")
                spoofing = true
                val ok = pushMockLocation()
                if (ok) {
                    Toast.makeText(this@MainActivity, "Simulación iniciada. Si no funciona, selecciona GPS Spoofer en Opciones de desarrollador > Aplicación de ubicación ficticia.", Toast.LENGTH_LONG).show()
                } else {
                    spoofing = false
                    Toast.makeText(this@MainActivity, "Android no ha permitido la ubicación ficticia. Activa las Opciones de desarrollador y selecciona GPS Spoofer como aplicación de ubicación ficticia.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                }
            }
        }

        @JavascriptInterface fun stopSpoof() {
            runOnUiThread {
                spoofing = false
                Toast.makeText(this@MainActivity, "Simulación detenida. Si otras apps mantienen la última posición, espera a que actualicen.", Toast.LENGTH_LONG).show()
            }
        }

        @JavascriptInterface fun openDevSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
        }
    }

    private fun pushMockLocation(): Boolean {
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val provider = LocationManager.GPS_PROVIDER
            try { lm.removeTestProvider(provider) } catch (_: Exception) {}
            lm.addTestProvider(provider, false, false, false, false, true, true, true, 0, 5)
            lm.setTestProviderEnabled(provider, true)
            val location = Location(provider).apply {
                latitude = lat
                longitude = lon
                accuracy = 3f
                altitude = 0.0
                time = System.currentTimeMillis()
                elapsedRealtimeNanos = android.os.SystemClock.elapsedRealtimeNanos()
                speed = 0f
                bearing = 0f
            }
            lm.setTestProviderLocation(provider, location)
            true
        } catch (_: SecurityException) {
            false
        } catch (_: IllegalArgumentException) {
            false
        } catch (_: Exception) {
            false
        }
    }

    override fun onDestroy() {
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false)
            lm.removeTestProvider(LocationManager.GPS_PROVIDER)
        } catch (_: Exception) {}
        super.onDestroy()
    }
}
