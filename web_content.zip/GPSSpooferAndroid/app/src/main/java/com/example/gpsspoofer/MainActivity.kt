package com.example.gpsspoofer

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Process
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.provider.Settings
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var spoofing = false
    private var lat = 41.3874
    private var lon = 2.1686

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun setPoint(latitude: Double, longitude: Double) {
            runOnUiThread {
                lat = latitude
                lon = longitude
                if (spoofing) pushMockLocation()
            }
        }

        @JavascriptInterface fun startSpoof() {
            runOnUiThread {
                if (!isMockLocationAllowed()) {
                    showDeveloperOptionsHelp(openSettingsAfter = true)
                    return@runOnUiThread
                }
                spoofing = true
                val ok = pushMockLocation()
                if (ok) {
                    Toast.makeText(this@MainActivity, "Simulación iniciada. Comprueba la ubicación en una app compatible.", Toast.LENGTH_LONG).show()
                } else {
                    spoofing = false
                    Toast.makeText(this@MainActivity, "Android no ha permitido la ubicación de prueba. Comprueba que Fofi está seleccionada como app de ubicación ficticia.", Toast.LENGTH_LONG).show()
                    showDeveloperOptionsHelp(openSettingsAfter = true)
                }
            }
        }

        @JavascriptInterface fun stopSpoof() {
            runOnUiThread {
                spoofing = false
                Toast.makeText(this@MainActivity, "Simulación detenida. Si otras apps mantienen la última posición, espera a que actualicen.", Toast.LENGTH_LONG).show()
            }
        }

        @JavascriptInterface fun openDevSettings() {
            runOnUiThread { showDeveloperOptionsHelp(openSettingsAfter = true) }
        }

        @JavascriptInterface fun openVpnSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Abre Ajustes de Android y busca VPN.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }


    private fun isMockLocationAllowed(): Boolean {
        return try {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            // En algunos fabricantes la comprobación no está disponible; se valida al crear el proveedor.
            true
        }
    }

    private fun showDeveloperOptionsHelp(openSettingsAfter: Boolean) {
        AlertDialog.Builder(this)
            .setTitle("Configurar Fofi en Android")
            .setMessage("Android no permite que Fofi active esta opción automáticamente. En Opciones de desarrollador, busca «Seleccionar aplicación para simular ubicación» (el nombre puede variar) y elige Fofi. Después vuelve a Fofi y pulsa Iniciar. Si las Opciones de desarrollador están desactivadas, actívalas primero desde Ajustes > Información del teléfono > Número de compilación.")
            .setNegativeButton("Ahora no", null)
            .setPositiveButton("Abrir ajustes") { _, _ ->
                if (openSettingsAfter) {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                    } catch (_: Exception) {
                        Toast.makeText(this, "Abre Ajustes y busca «Opciones de desarrollador».", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .show()
    }

    private fun pushMockLocation(): Boolean {
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val provider = LocationManager.GPS_PROVIDER
            try { lm.removeTestProvider(provider) } catch (_: Exception) {}
            lm.addTestProvider(provider, false, false, false, false, true, true, true, 0, 5)
            lm.setTestProviderEnabled(provider, true)
            val location = Location(provider).apply {
                latitude = lat
                longitude = lon
                accuracy = 3f
                altitude = 0.0
                time = System.currentTimeMillis()
                elapsedRealtimeNanos = android.os.SystemClock.elapsedRealtimeNanos()
                speed = 0f
                bearing = 0f
            }
            lm.setTestProviderLocation(provider, location)
            true
        } catch (_: SecurityException) {
            false
        } catch (_: IllegalArgumentException) {
            false
        } catch (_: Exception) {
            false
        }
    }

    override fun onDestroy() {
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false)
            lm.removeTestProvider(LocationManager.GPS_PROVIDER)
        } catch (_: Exception) {}
        super.onDestroy()
    }
}
