FOFI — proyecto Android de GPS de prueba + acceso a ajustes VPN
==============================================================

ESTADO DEL PROYECTO
- Proyecto fuente Android en Kotlin con interfaz web integrada.
- Incluye mapa OpenStreetMap, búsqueda de lugares, selección de coordenadas, copiar coordenadas e inicio/detención de ubicación de prueba.
- Incluye un panel VPN que abre los ajustes VPN del sistema Android.
- IMPORTANTE: todavía NO incorpora un cliente VPN propio ni un servidor VPN. Para disponer de una VPN real, instala/configura un proveedor VPN o integra un cliente compatible con un servidor y credenciales válidos. El panel no afirma que haya conexión activa.
- Este ZIP es código fuente, no un APK compilado. No se ha compilado ni probado en un dispositivo desde este entorno.

COMPILAR APK
1. Instala Android Studio en un ordenador.
2. Descomprime este ZIP.
3. Abre la carpeta GPSSpooferAndroid en Android Studio.
4. Acepta la sincronización de Gradle e instala Android SDK 35 si lo solicita.
5. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
6. El APK de depuración suele quedar en app/build/outputs/apk/debug/app-debug.apk.

PROBAR LA UBICACIÓN DE PRUEBA
1. Instala el APK en tu móvil.
2. Activa las Opciones de desarrollador (toca varias veces Número de compilación en Ajustes > Información del teléfono).
3. En Fofi, pulsa «Configurar ubicación ficticia» y luego «Abrir ajustes». En Opciones de desarrollador, busca «Seleccionar aplicación para simular ubicación» (el texto puede variar según el fabricante) y selecciona Fofi. Android exige que lo hagas manualmente; ninguna app puede activar ese permiso por ti.
4. Abre Fofi, busca un lugar o toca el mapa y pulsa Iniciar.
5. Pulsa Detener para detener la simulación.

VPN
El botón “Configurar VPN en Android” abre los ajustes del sistema. Una VPN necesita una app/proveedor o un servidor VPN real y una configuración válida. Una app no puede cambiar la IP simplemente mostrando un botón; la integración completa requiere implementar un cliente VPN (por ejemplo, mediante Android VpnService y un protocolo compatible) y configurar un endpoint real. No se incluyen credenciales, claves ni servidores inventados.

MAPA Y BÚSQUEDA
El mapa utiliza Leaflet y teselas de OpenStreetMap desde Internet. La búsqueda usa Nominatim. Ambos requieren conexión y están sujetos a sus políticas de uso; no se garantiza disponibilidad continua.

LIMITACIONES
- La compatibilidad de ubicación ficticia depende de la versión de Android, fabricante y aplicaciones receptoras. Algunas apps pueden detectar o rechazar ubicaciones de prueba.
- El botón Detener desactiva el proveedor de prueba gestionado por esta app; otras apps podrían conservar temporalmente la última ubicación.
- Este proyecto es una base de demostración y requiere pruebas en el dispositivo objetivo.
