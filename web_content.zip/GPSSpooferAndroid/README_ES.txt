Fofi — aplicación Android de ubicación simulada

IMPORTANTE
- Este archivo es un proyecto fuente, no un APK ya compilado.
- No se ha podido compilar ni probar en un dispositivo desde este entorno.
- Android y algunos fabricantes restringen la ubicación ficticia. La API de ubicación de prueba cambia según versión/dispositivo, por lo que puede requerir ajustes.
- El mapa usa OpenStreetMap y la búsqueda usa Nominatim; necesitan conexión a Internet y están sujetos a sus políticas de uso.
- Usa la simulación solo para pruebas y con aplicaciones/cuentas donde esté permitido.

Cómo compilar un APK
1. Instala Android Studio en un ordenador.
2. Descomprime este ZIP.
3. En Android Studio, abre la carpeta GPSSpooferAndroid.
4. Acepta la sincronización de Gradle e instala Android SDK 35 si te lo solicita.
5. Usa Build > Build Bundle(s) / APK(s) > Build APK(s).
6. El APK de depuración aparecerá normalmente en app/build/outputs/apk/debug/app-debug.apk.

Cómo habilitar ubicación ficticia
1. En Android, activa Opciones de desarrollador tocando varias veces “Número de compilación” en Ajustes > Información del teléfono.
2. En Opciones de desarrollador, busca “Seleccionar aplicación de ubicación ficticia”.
3. Selecciona Fofi.
4. Vuelve a la app y prueba un punto.

Limitación
Este proyecto es una base funcional de demostración. La compatibilidad con la simulación de ubicación depende de la versión de Android y del fabricante; no se garantiza que todas las aplicaciones acepten o no detecten la ubicación simulada. El botón Detener desactiva el proveedor de prueba gestionado por esta app; algunas apps pueden conservar temporalmente la última ubicación recibida.
