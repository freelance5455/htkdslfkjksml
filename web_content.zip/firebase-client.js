import { firebaseConfig } from './firebase-config.js';

let firebasePromise;

export function hasFirebaseConfig() {
  const required = ['apiKey', 'authDomain', 'projectId', 'appId'];
  return required.every(key => {
    const value = firebaseConfig?.[key];
    return typeof value === 'string' && value.length > 0 && !value.includes('PASTE_');
  });
}

export async function initializeFirebase() {
  if (!hasFirebaseConfig()) return null;
  if (firebasePromise) return firebasePromise;

  firebasePromise = (async () => {
    const [appSdk, authSdk, firestoreSdk] = await Promise.all([
      import('https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js'),
      import('https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js'),
      import('https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js')
    ]);
    const app = appSdk.getApps().length ? appSdk.getApp() : appSdk.initializeApp(firebaseConfig);
    let firestore;
    let persistence = 'memory';
    try {
      firestore = firestoreSdk.initializeFirestore(app, {
        localCache: firestoreSdk.persistentLocalCache({
          tabManager: firestoreSdk.persistentMultipleTabManager()
        })
      });
      persistence = 'persistent';
    } catch (error) {
      console.warn('Persistent Firestore cache is unavailable; using the in-memory Firestore cache.', error);
      firestore = firestoreSdk.getFirestore(app);
    }
    return {
      auth: authSdk.getAuth(app),
      firestore,
      authSdk,
      firestoreSdk,
      persistence
    };
  })();

  try {
    return await firebasePromise;
  } catch (error) {
    firebasePromise = null;
    throw error;
  }
}
