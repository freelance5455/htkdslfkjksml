package com.tetspay.nfc

import android.nfc.cardemulation.HostApduService
import android.os.Bundle

/** Emulates only a harmless TETS PAY game token. It is not a bank card and cannot process payments. */
class GameCardService : HostApduService() {
    private val selectAid = byteArrayOf(0x00, 0xA4.toByte(), 0x04, 0x00, 0x05, 0xF0.toByte(), 0x12, 0x34, 0x56, 0x78)
    private val success = byteArrayOf(0x90.toByte(), 0x00)

    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu != null && commandApdu.contentEquals(selectAid)) return success
        return byteArrayOf(0x6A.toByte(), 0x82.toByte())
    }

    override fun onDeactivated(reason: Int) { }
}
