package com.tetspay.nfc

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private var web: WebView? = null
    private var adapter: NfcAdapter? = null
    @Volatile private var scanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = NfcAdapter.getDefaultAdapter(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(NfcBridge(), "AndroidNfc")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        if (adapter == null) Toast.makeText(this, "На этом устройстве нет NFC", Toast.LENGTH_LONG).show()
    }

    inner class NfcBridge {
        @JavascriptInterface fun startScan() { runOnUiThread { startReader() } }
        @JavascriptInterface fun setPayerMode(enabled: Boolean) {
            runOnUiThread {
                if (enabled) web?.evaluateJavascript("onNativeRole('payer')", null)
                Toast.makeText(this@MainActivity, "Режим карты доступен через системную службу NFC. Оставь приложение открытым.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startReader() {
        val nfc = adapter
        if (nfc == null || !nfc.isEnabled) {
            web?.evaluateJavascript("onNfcDetected(false, 'Включи NFC в настройках Android и повтори попытку.')", null)
            return
        }
        scanning = true
        nfc.enableReaderMode(this, this, NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK, null)
    }

    override fun onTagDiscovered(tag: Tag) {
        if (!scanning) return
        var success = false
        var message = "Не удалось прочитать игровой NFC-токен. Установи companion-приложение на второй телефон."
        try {
            val iso = IsoDep.get(tag) ?: throw IllegalStateException("Устройство не поддерживает ISO-DEP")
            iso.connect()
            iso.timeout = 3000
            // Select the TETS PAY demo AID. This is a game token, not a payment-card command.
            val response = iso.transceive(byteArrayOf(0x00, 0xA4.toByte(), 0x04, 0x00, 0x05, 0xF0.toByte(), 0x12, 0x34, 0x56, 0x78))
            success = response.size >= 2 && response[response.size - 2] == 0x90.toByte() && response.last() == 0x00.toByte()
            if (success) message = "Совместимый игровой NFC-токен обнаружен"
            iso.close()
        } catch (_: Exception) { }
        scanning = false
        runOnUiThread {
            adapter?.disableReaderMode(this)
            web?.evaluateJavascript("onNfcDetected($success, ${jsString(message)})", null)
        }
    }

    private fun jsString(s: String): String = "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"

    override fun onPause() {
        super.onPause()
        try { adapter?.disableReaderMode(this) } catch (_: Exception) { }
        scanning = false
    }

    override fun onDestroy() {
        web?.destroy()
        web = null
        super.onDestroy()
    }
}
