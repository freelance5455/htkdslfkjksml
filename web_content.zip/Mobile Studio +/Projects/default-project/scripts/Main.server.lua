-- Mobile Studio + starter script
print('Mobile Studio + project loaded')
