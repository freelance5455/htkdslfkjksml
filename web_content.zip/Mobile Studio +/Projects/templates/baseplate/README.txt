Template placeholder. Open Mobile Studio + and use New/Add Part to build the scene.
