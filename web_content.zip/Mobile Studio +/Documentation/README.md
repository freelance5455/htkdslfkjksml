# Mobile Studio +

A light-themed, mobile-first Roblox project editor built with HTML/CSS/JS and a Node backend.

## Features
- Responsive landscape 16:9 editor layout
- Three.js 3D viewport
- Orbit/pinch/scroll camera controls
- Select, add, duplicate, delete, undo, redo
- Editable position, size, color, material, and name
- Explorer and Properties panels
- Local save
- PWA manifest
- Roblox Open Cloud backend with server-side API-key handling
- Connection test and Universe/Place lookup

## Run
See `Documentation/SETUP.md`.
