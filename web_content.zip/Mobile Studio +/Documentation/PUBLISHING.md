# Publishing

Mobile Studio + includes a real Open Cloud authentication/validation layer and a Publish workflow.

Important: Roblox place publishing is not the same as uploading JSON scene data. A true place publish requires a valid Roblox place-version payload accepted by the relevant Open Cloud publishing endpoint. This starter intentionally does not pretend that a JSON scene is a valid `.rbxl/.rbxlx` place file.

The current backend verifies that the configured API key can access the selected Universe/Place. The editor's local project, scene, selection, properties, undo/redo, and save system are fully functional in the browser.
