# Roblox Open Cloud API Key Tutorial

1. Sign in to the Roblox Creator Dashboard.
2. Open the API Keys page.
3. Choose **Create API Key**.
4. Give it a name such as `MOBILE_STUDIO_PLUS`.
5. In **Access Permissions**, select the API systems and operations required by your workflow.
6. Restrict the key to the specific experience when the API supports that restriction.
7. Copy the key once and put it in `Backend/.env` as `ROBLOX_API_KEY=...`.
8. Put your experience's Universe ID and Place ID in the same `.env` file, or enter them from the app's Settings dialog.
9. Restart the backend and use Settings > Test Connection.

Security:
- Never put the key in browser JavaScript.
- Never publish `.env`.
- Use the smallest permissions needed.
- Rotate/revoke the key if it is exposed.

The current Roblox documentation says Open Cloud API requests use the `x-api-key` header and API keys can be created/configured in Creator Dashboard.
