# Setup

## Local
```bash
cd Backend
npm install
copy .env.example .env
npm start
```
On macOS/Linux use `cp .env.example .env`.

## Mobile
Use a phone browser on the same network as the computer running Node. Replace `localhost` in the browser URL with the computer's LAN IP, for example `http://192.168.1.10:3000`.

Do not put a Roblox API key in `Frontend/JS` or commit `.env` to source control.
