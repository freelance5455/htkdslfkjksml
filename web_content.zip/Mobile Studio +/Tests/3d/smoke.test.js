// Manual smoke test for Three.js viewport.
