// Manual smoke test on touch device in landscape.
