// Verify publish route returns a clear validation error without IDs/key.
