// Manual smoke tests: add/select/edit/delete/save.
