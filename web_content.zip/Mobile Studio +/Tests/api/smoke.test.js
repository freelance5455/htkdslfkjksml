// Start backend, then GET /api/health and /api/roblox/permissions.
