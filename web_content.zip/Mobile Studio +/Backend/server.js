import express from "express"; import cors from "cors"; import dotenv from "dotenv"; import rateLimit from "express-rate-limit";
import {robloxRouter} from "./Routes/universe.routes.js"; dotenv.config();
const app=express(); app.use(cors()); app.use(express.json({limit:"5mb"})); app.use(rateLimit({windowMs:60_000,max:120}));
app.use("/api/roblox",robloxRouter); app.get("/api/health",(_,res)=>res.json({ok:true,name:"Mobile Studio +"}));
app.use(express.static("../Frontend")); app.get("*",(req,res)=>res.sendFile(process.cwd()+"/../Frontend/index.html"));
app.listen(process.env.PORT||3000,()=>console.log(`Mobile Studio + running on http://localhost:${process.env.PORT||3000}`));
