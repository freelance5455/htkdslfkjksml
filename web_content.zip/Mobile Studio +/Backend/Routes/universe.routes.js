import {Router} from "express"; import {config} from "../Config/config.js"; import {getUniverse,getPlace} from "../Roblox/cloud-api.js"; import {publishProject} from "../Roblox/publish-api.js";
export const robloxRouter=Router();
robloxRouter.get("/connection",async(_,res)=>{try{if(!config.apiKey)return res.status(503).json({ok:false,error:"ROBLOX_API_KEY not configured"});if(!config.universeId)return res.json({ok:true,message:"API key configured; no default Universe ID set."});const u=await getUniverse(config.universeId);res.json({ok:true,universe:u})}catch(e){res.status(502).json({ok:false,error:e.message})}});
robloxRouter.get("/universes/:id",async(req,res)=>{try{res.json(await getUniverse(req.params.id))}catch(e){res.status(502).json({error:e.message})}});
robloxRouter.get("/universes/:u/places/:p",async(req,res)=>{try{res.json(await getPlace(req.params.u,req.params.p))}catch(e){res.status(502).json({error:e.message})}});
robloxRouter.post("/publish",async(req,res)=>{try{res.json(await publishProject(req.body.project))}catch(e){res.status(502).json({error:e.message})}});
robloxRouter.get("/permissions",(_,res)=>res.json({apiKeyConfigured:Boolean(config.apiKey),universeIdConfigured:Boolean(config.universeId),placeIdConfigured:Boolean(config.placeId)}));
