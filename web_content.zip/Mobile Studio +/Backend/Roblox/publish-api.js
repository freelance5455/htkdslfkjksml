import {robloxFetch} from "./roblox-api.js";
export async function publishProject(project){
  if(!project?.universeId||!project?.placeId) throw new Error("Set Universe ID and Place ID first.");
  // Open Cloud API authentication and resource validation are real. A complete place publish
  // requires a Roblox place-version payload (.rbxl/.rbxlx) accepted by the current publishing endpoint.
  // This endpoint validates access and returns the next integration step without fabricating a publish.
  const place=await robloxFetch(`/cloud/v2/universes/${project.universeId}/places/${project.placeId}`);
  return {ok:true,message:"Roblox access verified for this place. Project is ready for place-version publishing.",place};
}
