# properties
Component hook folder for future extracted UI components.
