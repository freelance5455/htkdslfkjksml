import {CONFIG} from "../config.js";
export async function api(path,options={}){const r=await fetch((CONFIG.API_BASE||"")+path,{headers:{"Content-Type":"application/json",...(options.headers||{})},...options});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error||data.message||`HTTP ${r.status}`);return data}
