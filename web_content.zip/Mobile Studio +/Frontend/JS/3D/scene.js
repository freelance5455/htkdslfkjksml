import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js";
export function createScene(){const s=new THREE.Scene();s.background=new THREE.Color(0xe9eef5);return s}