export const state={project:{name:"Untitled Game",universeId:"",placeId:"",objects:[],scripts:[]},selectedId:null,tool:"select",history:[],future:[],dirty:false};
export function markDirty(){state.dirty=true;document.getElementById("status").textContent="Unsaved changes";}
