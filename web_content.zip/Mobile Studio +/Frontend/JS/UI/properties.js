import {state,markDirty} from "../state.js";
export function renderProperties(){const el=document.getElementById("properties");const o=state.project.objects.find(x=>x.id===state.selectedId);if(!o){el.innerHTML='<div class="section">Select an object</div>';return}
el.innerHTML=`<div class="section">${o.name}</div><div class="prop"><label>Name</label><input id="pname" value="${o.name}"></div>
<div class="prop"><label>Position</label><div class="prop-row">${o.position.map((v,i)=>`<input data-pos="${i}" type="number" value="${v}">`).join("")}</div></div>
<div class="prop"><label>Size</label><div class="prop-row">${o.size.map((v,i)=>`<input data-size="${i}" type="number" min=".1" value="${v}">`).join("")}</div></div>
<div class="prop"><label>Color</label><input id="pcolor" type="color" value="${o.color||"#b8c1cc"}"></div>
<div class="prop"><label>Material</label><select id="pmaterial">${["Plastic","Metal","Wood","Concrete","Grass","Sand","Glass","Ice","Brick"].map(x=>`<option ${x===o.material?"selected":""}>${x}</option>`).join("")}</select></div>`;
document.querySelector("#pname").oninput=e=>{o.name=e.target.value;markDirty();window.dispatchEvent(new Event("statechange"))};
document.querySelectorAll("[data-pos]").forEach(i=>i.oninput=e=>{o.position[+e.target.dataset.pos]=+e.target.value;markDirty();window.dispatchEvent(new Event("scenechange"))});
document.querySelectorAll("[data-size]").forEach(i=>i.oninput=e=>{o.size[+e.target.dataset.size]=Math.max(.1,+e.target.value);markDirty();window.dispatchEvent(new Event("scenechange"))});
document.querySelector("#pcolor").oninput=e=>{o.color=e.target.value;markDirty();window.dispatchEvent(new Event("scenechange"))};
document.querySelector("#pmaterial").onchange=e=>{o.material=e.target.value;markDirty();window.dispatchEvent(new Event("scenechange"))};
}
