import {state,markDirty} from "../state.js";
import {uuid} from "../Utils/uuid.js";
export function createDefaultProject(){state.project={name:"Untitled Game",universeId:"",placeId:"",objects:[
{id:uuid(),name:"Baseplate",className:"Part",position:[0,-1,0],size:[64,2,64],rotation:[0,0,0],color:"#70a84f",material:"Grass",anchored:true},
{id:uuid(),name:"SpawnLocation",className:"SpawnLocation",position:[0,1,0],size:[6,1,6],rotation:[0,0,0],color:"#5aa9e6",material:"Plastic",anchored:true}
],scripts:[]}; state.selectedId=null; state.history=[];state.future=[];state.dirty=false;}
export function addPart(){const o={id:uuid(),name:"Part",className:"Part",position:[0,2,0],size:[4,2,4],rotation:[0,0,0],color:"#b8c1cc",material:"Plastic",anchored:true};state.project.objects.push(o);state.selectedId=o.id;markDirty();return o;}
export function duplicateSelected(){const o=state.project.objects.find(x=>x.id===state.selectedId);if(!o)return;const n=structuredClone(o);n.id=uuid();n.name=o.name+" Copy";n.position=[o.position[0]+3,o.position[1],o.position[2]+3];state.project.objects.push(n);state.selectedId=n.id;markDirty();}
export function deleteSelected(){const i=state.project.objects.findIndex(x=>x.id===state.selectedId);if(i<0)return;state.project.objects.splice(i,1);state.selectedId=null;markDirty();}
