import {state} from "../state.js";
export function snapshot(){state.history.push(JSON.stringify(state.project));if(state.history.length>50)state.history.shift();state.future=[];}
export function undo(){if(!state.history.length)return;state.future.push(JSON.stringify(state.project));state.project=JSON.parse(state.history.pop());state.selectedId=null;}
export function redo(){if(!state.future.length)return;state.history.push(JSON.stringify(state.project));state.project=JSON.parse(state.future.pop());}
