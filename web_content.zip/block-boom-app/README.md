# Block Boom – Projekt für Play Store und App Store

Das Spiel ist eine einzige Datei: `www/index.html` (HTML, CSS und JavaScript).
Hier arbeitest du weiter. Zum Testen reicht es, die Datei im Browser zu öffnen
(am besten in der Handy-Ansicht der Browser-Entwicklertools).

## App bauen (Capacitor)

Voraussetzungen: Node.js, für Android Android Studio, für iOS ein Mac mit Xcode.

    npm install
    npx cap add android      # einmalig
    npx cap add ios          # einmalig, nur auf dem Mac
    npm run android          # kopiert www/ in die App und öffnet Android Studio
    npm run ios              # dasselbe für Xcode

In `capacitor.config.json` die `appId` (z. B. com.deinefirma.blockboom) ändern.
Sie muss eindeutig sein und lässt sich nach dem Upload nicht mehr ändern.

## Was noch fehlt, bevor du Geld verdienst

1. **Echte In-App-Käufe.** Im Spiel sind die Münzpakete nur Demo-Buttons
   (Suche im Code nach `DEMO` und `data-a="pack"`). Einbauen mit Google Play Billing
   und Apple StoreKit, am einfachsten über RevenueCat (Plugin `@revenuecat/purchases-capacitor`).
2. **Echte Werbevideos.** Der Button „Video ansehen" gibt aktuell einfach Münzen
   (Suche nach `data-a="ad"`). Einbauen mit AdMob (Rewarded Ad), Plugin z. B. `@capacitor-community/admob`.
3. **Schrift offline.** Oben in `index.html` werden die Schriften Titan One (Logo, Zahlen, Buttons) und Fredoka
   (Fließtext) von Google Fonts geladen. Für die App beide Schriftdateien lokal ins Projekt legen (`@font-face`).
4. **App-Icon, Startbild, Store-Texte, Screenshots, Datenschutzerklärung.**
5. **Entwicklerkonten:** Google Play (einmalig 25 $), Apple Developer (99 $ pro Jahr).

## Wichtige Stellschrauben im Code (in `index.html`)

- `CAP` und `ADCAP`: Münzen pro Tag durch Spielen und Videos pro Tag.
- `PACKS`: Münzpakete und Preise.
- Preise für Hammer, Neue Teile und Weiterspielen: Suche nach `S.coins<`.
- `COL`: Farben der Blöcke. `mkSprites()`: Aussehen der Blöcke (werden einmal vorgerendert).
- `mkBoard()`: Spielfeld-Rahmen und Ablage. `logo()` und die CSS-Klassen `.brick`, `.bm`, `.burst`: das Logo.
- CSS-Variablen ganz oben (`--plum`, `--gold`, `--coral` …): die Farbwelt der Oberfläche.
- `SFX3`: alle Töne. Mit dem Knopf „Ton" im Spiel lässt sich alles abschalten.
- `SH`: alle Bausteinformen.

Der Spielstand liegt im `localStorage` des Geräts (Münzen, Rekord, Tageslimits).
Ein Löschen der App-Daten setzt ihn zurück.

## Neu: Spielstand, Hintergründe, Effekte

- Die laufende Partie wird automatisch gespeichert (`S.run`, Funktion `save()`) und beim Start über `loadRun()` mit "Weiterspielen" fortgesetzt. Nach verlorener Partie wird sie verworfen.
- Hintergründe: Preise in `THEMES` (`logic.js`), Aussehen in `TV` (`index.html`) und `html[data-theme=…]` im CSS. Käuflich im Shop, im Menü oder über den Knopf "Design".
- Effekte: Bildschirmwackeln, Reihen-Blitz, Schockwellen, Ziehspur, Feuerwerk bei Level-Aufstieg (`draw()`).

## Neu: Blöcke, Sprache, Rangliste

- Block-Designs (`SKINS` in `logic.js`, gezeichnet in `skinDraw()`), Sprachen DE/EN (Wörterbuch `DICT`, weitere Sprachen: Spalte ergänzen und in `LANGS` eintragen), Zurück-Pfeil im Spiel, Spielername beim Start.
- Weltrangliste: `server/server.js` auf einem Server starten und die Adresse bei `LB_URL` in `index.html` eintragen. Ohne Server zeigt die Rangliste nur den eigenen Eintrag.
