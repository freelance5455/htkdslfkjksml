> **Aktueller Entwicklungsstand:** Bitte zuerst `EINRICHTUNG.md` lesen. Shop-Zahlungen und Anzeigen sind noch NICHT angebunden.

# Block Boom – Projekt für Play Store und App Store

Das Spiel ist eine einzige Datei: `www/index.html` (HTML, CSS und JavaScript).
Hier arbeitest du weiter. Zum Testen reicht es, die Datei im Browser zu öffnen
(am besten in der Handy-Ansicht der Browser-Entwicklertools).

## App bauen (Capacitor)

Voraussetzungen: Node.js, für Android Android Studio, für iOS ein Mac mit Xcode.

    npm install
    npx cap add android      # einmalig
    npx cap add ios          # einmalig, nur auf dem Mac
    npm run android          # kopiert www/ in die App und öffnet Android Studio
    npm run ios              # dasselbe für Xcode

In `capacitor.config.json` die `appId` (z. B. com.deinefirma.blockboom) ändern.
Sie muss eindeutig sein und lässt sich nach dem Upload nicht mehr ändern.

## Was noch fehlt, bevor du Geld verdienst

1. **Echte In-App-Käufe.** Im Spiel sind die Münzpakete nur Demo-Buttons
   (Suche im Code nach `DEMO` und `data-a="pack"`). Einbauen mit Google Play Billing
   und Apple StoreKit, am einfachsten über RevenueCat (Plugin `@revenuecat/purchases-capacitor`).
2. **Echte Werbevideos.** Der Button „Video ansehen" gibt aktuell einfach Münzen
   (Suche nach `data-a="ad"`). Einbauen mit AdMob (Rewarded Ad), Plugin z. B. `@capacitor-community/admob`.
3. **Schrift offline.** Oben in `index.html` werden die Schriften Titan One (Logo, Zahlen, Buttons) und Fredoka
   (Fließtext) von Google Fonts geladen. Für die App beide Schriftdateien lokal ins Projekt legen (`@font-face`).
4. **App-Icon, Startbild, Store-Texte, Screenshots, Datenschutzerklärung.**
5. **Entwicklerkonten:** Google Play (einmalig 25 $), Apple Developer (99 $ pro Jahr).

## Wichtige Stellschrauben im Code (in `index.html`)

- `CAP` und `ADCAP`: Münzen pro Tag durch Spielen und Videos pro Tag.
- `PACKS`: Münzpakete und Preise.
- Preise für Hammer, Neue Teile und Weiterspielen: Suche nach `S.coins<`.
- `COL`: Farben der Blöcke. `mkSprites()`: Aussehen der Blöcke (werden einmal vorgerendert).
- `mkBoard()`: Spielfeld-Rahmen und Ablage. `logo()` und die CSS-Klassen `.brick`, `.bm`, `.burst`: das Logo.
- CSS-Variablen ganz oben (`--plum`, `--gold`, `--coral` …): die Farbwelt der Oberfläche.
- `SFX3`: alle Töne. Mit dem Knopf „Ton" im Spiel lässt sich alles abschalten.
- `SH`: alle Bausteinformen.

Der Spielstand liegt im `localStorage` des Geräts (Münzen, Rekord, Tageslimits).
Ein Löschen der App-Daten setzt ihn zurück.
