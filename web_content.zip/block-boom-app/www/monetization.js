/* Fail-closed production integration boundary. No mock purchases, no mock ad rewards.
   Configure and verify native providers before enabling these controls. */
const BBMonetization=(()=>{
  const unavailable={ok:false,message:'Noch nicht eingerichtet – siehe EINRICHTUNG.md'};
  let busy=false;
  const purchase=async(index)=>{
    if(busy)return {ok:false,message:'Bitte warten'};
    if(!Number.isInteger(index)||index<0||index>3)return unavailable;
    // Never credit coins from a client-side callback alone. A verified server transaction
    // must return an idempotent grant before coins can be awarded.
    return unavailable;
  };
  const reward=async()=>{
    if(busy)return {ok:false,message:'Bitte warten'};
    // Server-side verification (SSV) and a unique reward transaction are required.
    return unavailable;
  };
  return {purchase,reward};
})();
