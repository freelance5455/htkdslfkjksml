// Reine Spiellogik ohne DOM. Wird im Spiel und in tests/logic.test.js verwendet.
const BB=(()=>{
const DEFAULT={v:4,lang:'',name:'',pid:'',skin:'classic',skins:{classic:true},theme:'night',owned:{night:true},run:null,coins:30,level:1,best:0,day:'',earned:0,ads:0,games:0,rows:0,bestCombo:0,perfects:0,combos:0,streak:0,lastDay:'',ach:{},q:{day:'',p:{},done:{}},mute:false};
const int=(x,min,d)=>{x=Math.floor(Number(x));return Number.isFinite(x)?Math.max(min,x):d};
const target=l=>150+l*100;
const points=(cells,n,combo)=>cells+n*n*10+(combo>1?combo*10:0)+(n>=4?50:0);
const fits=(g,s,x,y)=>s.every((row,r)=>row.every((v,c)=>!v||(y+r>=0&&y+r<g.length&&x+c>=0&&x+c<g.length&&!g[y+r][x+c])));
const canAny=(g,s)=>{for(let y=0;y<g.length;y++)for(let x=0;x<g.length;x++)if(fits(g,s,x,y))return true;return false};
const findClears=g=>{const n=g.length,rows=[],cols=[];for(let r=0;r<n;r++)if(g[r].every(v=>v))rows.push(r);for(let c=0;c<n;c++)if(g.every(row=>row[c]))cols.push(c);return{rows,cols}};
const isOver=(g,shapes)=>!shapes.some(s=>s&&canAny(g,s));
const localDay=(d=new Date())=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const THEMES=[{id:'night',name:'Nachtlila',price:0},{id:'ocean',name:'Tiefsee',price:100},{id:'sunset',name:'Sonnenuntergang',price:150},{id:'forest',name:'Zauberwald',price:200},{id:'candy',name:'Zuckerwelt',price:250},{id:'winter',name:'Winternacht',price:300},{id:'galaxy',name:'Galaxie',price:400}];
const LANGS=['de','en'];
const SKINS=[{id:'classic',name:'Klassisch',price:0},{id:'jelly',name:'Gummi',price:150},{id:'gems',name:'Edelsteine',price:200},{id:'pixel',name:'Pixel',price:250},{id:'neon',name:'Neon',price:300},{id:'fruit',name:'Früchte',price:350}];
const cleanName=x=>String(x==null?'':x).replace(/[<>&"'`\\]/g,'').replace(/\s+/g,' ').trim().slice(0,14).trim();
const sanitizeRun=raw=>{try{if(!raw||typeof raw!=='object'||!Array.isArray(raw.g)||raw.g.length!==8)return null;
 const g=[];for(const row of raw.g){if(!Array.isArray(row)||row.length!==8)return null;g.push(row.map(v=>{v=Math.floor(Number(v));return v>=1&&v<=6?v:0}))}
 if(!Array.isArray(raw.pieces)||raw.pieces.length!==3)return null;const pieces=[];
 for(const p of raw.pieces){if(p==null){pieces.push(null);continue}const sh=p.s;if(!Array.isArray(sh)||!sh.length||sh.length>5||!Array.isArray(sh[0]))return null;const w=sh[0].length;if(!w||w>5)return null;
  const ss=[];for(const r of sh){if(!Array.isArray(r)||r.length!==w)return null;ss.push(r.map(v=>v?1:0))}
  if(!ss.some(r=>r.some(Boolean)))return null;const c=Math.floor(Number(p.c));if(!(c>=1&&c<=6))return null;pieces.push({s:ss,c})}
 if(!pieces.some(Boolean)||isOver(g,pieces.map(p=>p&&p.s)))return null;
 return{g,pieces,score:int(raw.score,0,0),combo:int(raw.combo,0,0),miss:int(raw.miss,0,0),sb:int(raw.sb,0,0)}}catch(e){return null}};
const migrate=raw=>{let o={};try{const p=typeof raw==='string'?JSON.parse(raw):raw;if(p&&typeof p==='object'&&!Array.isArray(p))o=p}catch(e){}
 const S=Object.assign({},DEFAULT,o);
 S.coins=int(S.coins,0,30);S.level=int(S.level,1,1);S.best=int(S.best,0,0);S.earned=int(S.earned,0,0);S.ads=int(S.ads,0,0);
 S.games=int(S.games,0,0);S.rows=int(S.rows,0,0);S.bestCombo=int(S.bestCombo,0,0);S.perfects=int(S.perfects,0,0);S.combos=int(S.combos,0,0);S.streak=int(S.streak,0,0);S.lastDay=typeof S.lastDay==='string'?S.lastDay:'';
 const a={};if(S.ach&&typeof S.ach==='object')for(const k in S.ach)if(S.ach[k]===true)a[k]=true;S.ach=a;
 const q=S.q&&typeof S.q==='object'?S.q:{},qp={},qd={};if(q.p&&typeof q.p==='object')for(const k in q.p)qp[k]=int(q.p[k],0,0);if(q.done&&typeof q.done==='object')for(const k in q.done)if(q.done[k]===true)qd[k]=true;S.q={day:typeof q.day==='string'?q.day:'',p:qp,done:qd};
 const ow={night:true};if(S.owned&&typeof S.owned==='object')THEMES.forEach(t=>{if(S.owned[t.id]===true)ow[t.id]=true});S.owned=ow;S.theme=typeof S.theme==='string'&&ow[S.theme]?S.theme:'night';S.run=sanitizeRun(S.run);
 S.lang=LANGS.includes(S.lang)?S.lang:'';S.name=cleanName(S.name);S.pid=typeof S.pid==='string'?S.pid.replace(/[^a-z0-9]/g,'').slice(0,32):'';
 const sk={classic:true};if(S.skins&&typeof S.skins==='object')SKINS.forEach(t=>{if(S.skins[t.id]===true)sk[t.id]=true});S.skins=sk;S.skin=typeof S.skin==='string'&&sk[S.skin]?S.skin:'classic';
 S.mute=!!S.mute;S.day=typeof S.day==='string'?S.day:'';S.v=4;return S};
const spend=(S,n)=>{if(!Number.isInteger(n)||n<=0||S.coins<n)return false;S.coins-=n;return true};
const add=(S,n)=>{if(!Number.isInteger(n)||n<=0)return 0;S.coins+=n;return n};
const buyTheme=(S,id)=>{const t=THEMES.find(x=>x.id===id);if(!t||S.owned[id])return false;if(!spend(S,t.price))return false;S.owned[id]=true;return true};
const setTheme=(S,id)=>{if(!THEMES.some(t=>t.id===id)||!S.owned[id])return false;S.theme=id;return true};
const buySkin=(S,id)=>{const t=SKINS.find(x=>x.id===id);if(!t||S.skins[id])return false;if(!spend(S,t.price))return false;S.skins[id]=true;return true};
const setSkin=(S,id)=>{if(!SKINS.some(t=>t.id===id)||!S.skins[id])return false;S.skin=id;return true};
const levelUps=(S,score)=>{const out=[];while(score>=target(S.level)){const b=20+S.level*10;S.level++;add(S,b);out.push(b)}return out};
const earn=(S,n,cap,day)=>{if(S.day!==day){S.day=day;S.earned=0;S.ads=0}const q=Math.max(0,Math.min(n,cap-S.earned));S.earned+=q;S.coins+=q;return q};
const POOL=[
 {id:'s2000',stat:'score',goal:2000,reward:15,t:'Erreiche 2.000 Punkte in einer Partie'},
 {id:'s1000',stat:'score',goal:1000,reward:8,t:'Erreiche 1.000 Punkte in einer Partie'},
 {id:'r20',stat:'rows',goal:20,reward:12,t:'Löse 20 Reihen'},
 {id:'r10',stat:'rows',goal:10,reward:8,t:'Löse 10 Reihen'},
 {id:'c3',stat:'combo',goal:3,reward:10,t:'Erreiche eine 3er-Serie'},
 {id:'c5',stat:'combo',goal:5,reward:15,t:'Erreiche eine 5er-Serie'},
 {id:'g3',stat:'games',goal:3,reward:10,t:'Spiele 3 Partien'},
 {id:'pf1',stat:'perfect',goal:1,reward:20,t:'Räume das Spielfeld einmal komplett ab'}];
const ACH=[
 {id:'first',i:'🎮',t:'Erste Partie',d:'Beende deine erste Partie',reward:10,get:S=>S.games,goal:1},
 {id:'p1k',i:'⭐',t:'Tausender',d:'1.000 Punkte in einer Partie',reward:15,get:S=>S.best,goal:1000},
 {id:'p10k',i:'🌟',t:'Zehntausender',d:'10.000 Punkte in einer Partie',reward:100,get:S=>S.best,goal:10000},
 {id:'r100',i:'🧹',t:'Reihenräumer',d:'Löse insgesamt 100 Reihen',reward:25,get:S=>S.rows,goal:100},
 {id:'pf10',i:'✨',t:'Blitzblank',d:'Räume das Feld 10-mal komplett ab',reward:50,get:S=>S.perfects,goal:10},
 {id:'st7',i:'🔥',t:'Treue Seele',d:'Spiele 7 Tage hintereinander',reward:50,get:S=>S.streak,goal:7},
 {id:'g50',i:'🏁',t:'Dauerspieler',d:'Beende 50 Partien',reward:40,get:S=>S.games,goal:50},
 {id:'cb10',i:'💥',t:'Kombo-Meister',d:'Starte 10 Serien',reward:30,get:S=>S.combos,goal:10}];
const hash=s=>{let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0};
const dailyQuests=day=>{let h=hash(day),pool=POOL.slice(),out=[];while(out.length<3){out.push(pool.splice(h%pool.length,1)[0]);h=(Math.imul(h,1664525)+1013904223)>>>0}return out};
const prevDay=day=>{const[y,m,d]=day.split('-').map(Number);return localDay(new Date(y,m-1,d-1))};
const touch=(S,day)=>{if(S.q.day!==day)S.q={day,p:{},done:{}};if(S.lastDay!==day){S.streak=S.lastDay===prevDay(day)?S.streak+1:1;S.lastDay=day}};
// Meldet ein Spielereignis. Belohnt Aufgaben und Erfolge genau einmal. Rückgabe: neu geschaffte Aufgaben/Erfolge.
const track=(S,ev,day)=>{touch(S,day);const res={quests:[],ach:[]},q=S.q;
 const upd=(stat,v,max)=>dailyQuests(day).forEach(Q=>{if(Q.stat!==stat||q.done[Q.id])return;const o=q.p[Q.id]||0;q.p[Q.id]=Math.min(Q.goal,max?Math.max(o,v):o+v);if(q.p[Q.id]>=Q.goal){q.done[Q.id]=true;add(S,Q.reward);res.quests.push(Q)}});
 const v=ev.v|0;
 if(ev.type==='score'){S.best=Math.max(S.best,v);upd('score',v,1)}
 else if(ev.type==='rows'){S.rows+=v;upd('rows',v)}
 else if(ev.type==='combo'){S.bestCombo=Math.max(S.bestCombo,v);if(v===2)S.combos++;upd('combo',v,1)}
 else if(ev.type==='game'){S.games++;upd('games',1)}
 else if(ev.type==='perfect'){S.perfects++;upd('perfect',1)}
 ACH.forEach(A=>{if(!S.ach[A.id]&&A.get(S)>=A.goal){S.ach[A.id]=true;add(S,A.reward);res.ach.push(A)}});
 return res};
return{POOL,ACH,dailyQuests,touch,track,DEFAULT,target,points,fits,canAny,findClears,isOver,localDay,migrate,spend,add,levelUps,earn,THEMES,buyTheme,setTheme,sanitizeRun,SKINS,LANGS,cleanName,buySkin,setSkin}})();
if(typeof module!=='undefined')module.exports=BB;
