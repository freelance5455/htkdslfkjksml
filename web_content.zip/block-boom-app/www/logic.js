// Reine Spiellogik ohne DOM. Wird im Spiel und in tests/logic.test.js verwendet.
const BB=(()=>{
const DEFAULT={v:4,coins:30,level:1,xp:0,inventory:["classic"],theme:"classic",skin:"glossy",skins:["glossy"],best:0,day:'',earned:0,ads:0,games:0,rows:0,bestCombo:0,perfects:0,combos:0,streak:0,lastDay:'',ach:{},q:{day:'',p:{},done:{}},mute:false,noAds:false};
const int=(x,min,d)=>{x=Math.floor(Number(x));return Number.isFinite(x)?Math.max(min,x):d};
const target=l=>150+l*100;
const points=(cells,n,combo)=>cells+n*n*10+(combo>1?combo*10:0)+(n>=4?50:0);
const fits=(g,s,x,y)=>s.every((row,r)=>row.every((v,c)=>!v||(y+r>=0&&y+r<g.length&&x+c>=0&&x+c<g.length&&!g[y+r][x+c])));
const canAny=(g,s)=>{for(let y=0;y<g.length;y++)for(let x=0;x<g.length;x++)if(fits(g,s,x,y))return true;return false};
const findClears=g=>{const n=g.length,rows=[],cols=[];for(let r=0;r<n;r++)if(g[r].every(v=>v))rows.push(r);for(let c=0;c<n;c++)if(g.every(row=>row[c]))cols.push(c);return{rows,cols}};
const isOver=(g,shapes)=>!shapes.some(s=>s&&canAny(g,s));
const localDay=(d=new Date())=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const migrate=raw=>{let o={};try{const p=typeof raw==='string'?JSON.parse(raw):raw;if(p&&typeof p==='object'&&!Array.isArray(p))o=p}catch(e){}
 const S=Object.assign({},DEFAULT,o);
 S.coins=int(S.coins,0,30);S.level=int(S.level,1,1);S.xp=int(S.xp,0,0);S.inventory=Array.isArray(S.inventory)?[...new Set(["classic",...S.inventory.filter(x=>typeof x==="string"&&THEMES.some(t=>t.id===x))])]:["classic"];S.theme=S.inventory.includes(S.theme)?S.theme:"classic";S.skins=Array.isArray(S.skins)?[...new Set(["glossy",...S.skins.filter(x=>typeof x==="string"&&SKINS.some(k=>k.id===x))])]:["glossy"];S.skin=S.skins.includes(S.skin)?S.skin:"glossy";S.best=int(S.best,0,0);S.earned=int(S.earned,0,0);S.ads=int(S.ads,0,0);
 S.games=int(S.games,0,0);S.rows=int(S.rows,0,0);S.bestCombo=int(S.bestCombo,0,0);S.perfects=int(S.perfects,0,0);S.combos=int(S.combos,0,0);S.streak=int(S.streak,0,0);S.lastDay=typeof S.lastDay==='string'?S.lastDay:'';
 const a={};if(S.ach&&typeof S.ach==='object')for(const k in S.ach)if(S.ach[k]===true)a[k]=true;S.ach=a;
 const q=S.q&&typeof S.q==='object'?S.q:{},qp={},qd={};if(q.p&&typeof q.p==='object')for(const k in q.p)qp[k]=int(q.p[k],0,0);if(q.done&&typeof q.done==='object')for(const k in q.done)if(q.done[k]===true)qd[k]=true;S.q={day:typeof q.day==='string'?q.day:'',p:qp,done:qd};
 S.noAds=!!S.noAds;S.mute=!!S.mute;S.day=typeof S.day==='string'?S.day:'';S.v=4;return S};
const spend=(S,n)=>{if(!Number.isInteger(n)||n<=0||S.coins<n)return false;S.coins-=n;return true};
const add=(S,n)=>{if(!Number.isInteger(n)||n<=0)return 0;S.coins+=n;return n};
const levelUps=(S,earnedXp)=>{const out=[];if(!Number.isInteger(earnedXp)||earnedXp<=0)return out;S.xp+=earnedXp;while(S.xp>=target(S.level)){S.xp-=target(S.level);const b=20+S.level*10;S.level++;add(S,b);out.push(b)}return out};
const THEMES=[
 {id:'classic',name:'Klassisch',cost:0,colors:['','#ff4d6d','#ffb02e','#37d67a','#2ec5f0','#4d7cff','#b668ff'],background:'#2b1463'},
 {id:'ocean',name:'Ozean',cost:120,colors:['','#32c5ff','#3a86ff','#5eead4','#00a8e8','#a5f3fc','#3b82f6'],background:'#083b66'},
 {id:'sunset',name:'Sonnenuntergang',cost:180,colors:['','#ff5d73','#ff9f43','#ffd166','#ff6b6b','#f78fb3','#e056fd'],background:'#70204d'},
 {id:'forest',name:'Wald',cost:240,colors:['','#7bd389','#b5e48c','#52b788','#ffd166','#95d5b2','#74c69d'],background:'#174c3c'},
 {id:'candy',name:'Candy',cost:300,colors:['','#ff70a6','#ff9770','#ffd670','#70d6ff','#e9ff70','#c77dff'],background:'#62388b'}];
const SKINS=[
 {id:'glossy',name:'Glänzend',cost:0,desc:'Der originale glänzende Block'},
 {id:'flat',name:'Soft Pop',cost:90,desc:'Sanfte, klare Spielsteine'},
 {id:'glass',name:'Kristallglas',cost:180,desc:'Transparente Glasreflexe'},
 {id:'neon',name:'Neon Glow',cost:260,desc:'Leuchtende Neon-Kanten'},
 {id:'metal',name:'Chrom',cost:340,desc:'Metallischer Glanz'},
 {id:'gem',name:'Edelstein',cost:420,desc:'Facettierte Juwelen'}];
const buySkin=(S,id)=>{const k=SKINS.find(x=>x.id===id);if(!k)return false;if(S.skins.includes(id)){S.skin=id;return true}if(!spend(S,k.cost))return false;S.skins.push(id);S.skin=id;return true};
const buyTheme=(S,id)=>{const t=THEMES.find(x=>x.id===id);if(!t)return false;if(S.inventory.includes(id)){S.theme=id;return true}if(!spend(S,t.cost))return false;S.inventory.push(id);S.theme=id;return true};
const earn=(S,n,cap,day)=>{if(S.day!==day){S.day=day;S.earned=0;S.ads=0}const q=Math.max(0,Math.min(n,cap-S.earned));S.earned+=q;S.coins+=q;return q};
const POOL=[
 {id:'s2000',stat:'score',goal:2000,reward:15,t:'Erreiche 2.000 Punkte in einer Partie'},
 {id:'s1000',stat:'score',goal:1000,reward:8,t:'Erreiche 1.000 Punkte in einer Partie'},
 {id:'r20',stat:'rows',goal:20,reward:12,t:'Löse 20 Reihen'},
 {id:'r10',stat:'rows',goal:10,reward:8,t:'Löse 10 Reihen'},
 {id:'c3',stat:'combo',goal:3,reward:10,t:'Erreiche eine 3er-Serie'},
 {id:'c5',stat:'combo',goal:5,reward:15,t:'Erreiche eine 5er-Serie'},
 {id:'g3',stat:'games',goal:3,reward:10,t:'Spiele 3 Partien'},
 {id:'pf1',stat:'perfect',goal:1,reward:20,t:'Räume das Spielfeld einmal komplett ab'}];
const ACH=[
 {id:'first',i:'🎮',t:'Erste Partie',d:'Beende deine erste Partie',reward:10,get:S=>S.games,goal:1},
 {id:'p1k',i:'⭐',t:'Tausender',d:'1.000 Punkte in einer Partie',reward:15,get:S=>S.best,goal:1000},
 {id:'p10k',i:'🌟',t:'Zehntausender',d:'10.000 Punkte in einer Partie',reward:100,get:S=>S.best,goal:10000},
 {id:'r100',i:'🧹',t:'Reihenräumer',d:'Löse insgesamt 100 Reihen',reward:25,get:S=>S.rows,goal:100},
 {id:'pf10',i:'✨',t:'Blitzblank',d:'Räume das Feld 10-mal komplett ab',reward:50,get:S=>S.perfects,goal:10},
 {id:'st7',i:'🔥',t:'Treue Seele',d:'Spiele 7 Tage hintereinander',reward:50,get:S=>S.streak,goal:7},
 {id:'g50',i:'🏁',t:'Dauerspieler',d:'Beende 50 Partien',reward:40,get:S=>S.games,goal:50},
 {id:'cb10',i:'💥',t:'Kombo-Meister',d:'Starte 10 Serien',reward:30,get:S=>S.combos,goal:10}];
const hash=s=>{let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0};
const dailyQuests=day=>{let h=hash(day),pool=POOL.slice(),out=[];while(out.length<3){out.push(pool.splice(h%pool.length,1)[0]);h=(Math.imul(h,1664525)+1013904223)>>>0}return out};
const prevDay=day=>{const[y,m,d]=day.split('-').map(Number);return localDay(new Date(y,m-1,d-1))};
const touch=(S,day)=>{if(S.q.day!==day)S.q={day,p:{},done:{}};if(S.lastDay!==day){S.streak=S.lastDay===prevDay(day)?S.streak+1:1;S.lastDay=day}};
// Meldet ein Spielereignis. Belohnt Aufgaben und Erfolge genau einmal. Rückgabe: neu geschaffte Aufgaben/Erfolge.
const track=(S,ev,day)=>{touch(S,day);const res={quests:[],ach:[]},q=S.q;
 const upd=(stat,v,max)=>dailyQuests(day).forEach(Q=>{if(Q.stat!==stat||q.done[Q.id])return;const o=q.p[Q.id]||0;q.p[Q.id]=Math.min(Q.goal,max?Math.max(o,v):o+v);if(q.p[Q.id]>=Q.goal){q.done[Q.id]=true;add(S,Q.reward);res.quests.push(Q)}});
 const v=ev.v|0;
 if(ev.type==='score'){S.best=Math.max(S.best,v);upd('score',v,1)}
 else if(ev.type==='rows'){S.rows+=v;upd('rows',v)}
 else if(ev.type==='combo'){S.bestCombo=Math.max(S.bestCombo,v);if(v===2)S.combos++;upd('combo',v,1)}
 else if(ev.type==='game'){S.games++;upd('games',1)}
 else if(ev.type==='perfect'){S.perfects++;upd('perfect',1)}
 ACH.forEach(A=>{if(!S.ach[A.id]&&A.get(S)>=A.goal){S.ach[A.id]=true;add(S,A.reward);res.ach.push(A)}});
 return res};
return{THEMES,buyTheme,SKINS,buySkin,POOL,ACH,dailyQuests,touch,track,DEFAULT,target,points,fits,canAny,findClears,isOver,localDay,migrate,spend,add,levelUps,earn}})();
if(typeof module!=='undefined')module.exports=BB;
