# Block Boom – Android APK erstellen

Das Projekt basiert auf der **Aurora Edition**. Das Block-Boom-Logo ist als App-Icon vorbereitet (`android-icon-assets/`). Eine APK ist in diesem ZIP noch **nicht** enthalten.

## Voraussetzungen
- Computer mit Node.js (LTS), Android Studio und Android SDK
- Android-Smartphone zum Testen

## 1. Android-Projekt erzeugen
Im Ordner `block-boom-app` ein Terminal öffnen:

```bash
npm install
npx cap add android
npx cap sync android
```

## 2. Block-Boom-App-Icon einbauen
Führe anschließend aus:

```bash
python3 install_android_icons.py
```

Das Skript erstellt die Launcher-Icon-Ressourcen für die Android-App und setzt die adaptive Icon-Konfiguration. Danach:

```bash
npx cap open android
```

## 3. Installierbare Test-APK bauen
In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Die Debug-APK liegt typischerweise unter `android/app/build/outputs/apk/debug/app-debug.apk`. Diese APK auf das Android-Handy übertragen, dort öffnen und die Installation aus dieser Quelle erlauben. Für eine private Testinstallation ist die Debug-APK ausreichend.

Alternativ mit installiertem Android SDK im Terminal:

```bash
cd android
./gradlew assembleDebug
```

## Wichtig für kommerzielle Veröffentlichung
Vor einem Store-Release `appId` in `capacitor.config.json` auf deine dauerhaft verwendete, eindeutige Paketkennung ändern, z. B. `com.visionex21.blockboom`, und das Android-Projekt synchronisieren/neu erzeugen. Für den Play Store wird ein signierter Release-Build bzw. AAB benötigt. In-App-Zahlungen, Werbeintegration und die rechtlichen Store-Anforderungen sind noch nicht fertig implementiert.
