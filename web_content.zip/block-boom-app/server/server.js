// Minimaler Ranglisten-Server. Start: node server/server.js (Port 3000). Für den Betrieb hinter HTTPS stellen.
// Trage die Adresse in www/index.html bei LB_URL ein. Achtung: Punkte kommen vom Gerät, ein Betrüger könnte sie fälschen.
const http=require('http'),fs=require('fs'),F=__dirname+'/scores.json';
let D={};try{D=JSON.parse(fs.readFileSync(F,'utf8'))}catch(e){}
const clean=x=>String(x||'').replace(/[<>&"'`\\]/g,'').replace(/\s+/g,' ').trim().slice(0,14);
const send=(r,c,o)=>{r.writeHead(c,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type'});r.end(JSON.stringify(o))};
http.createServer((q,r)=>{const u=new URL(q.url,'http://x');
 if(q.method==='OPTIONS')return send(r,204,{});
 if(q.method==='GET'&&u.pathname==='/top'){const id=u.searchParams.get('id'),L=Object.entries(D).sort((a,b)=>b[1].score-a[1].score),i=L.findIndex(e=>e[0]===id);
  return send(r,200,{top:L.slice(0,20).map(([k,v])=>({name:v.name,score:v.score,me:k===id})),rank:i<0?0:i+1})}
 if(q.method==='POST'&&u.pathname==='/score'){let b='';q.on('data',c=>{b+=c;if(b.length>2000)q.destroy()});q.on('end',()=>{try{const p=JSON.parse(b),id=String(p.id||'').replace(/[^a-z0-9]/g,'').slice(0,32),name=clean(p.name),score=Math.floor(Number(p.score));
   if(id.length<8||name.length<2||!(score>0)||score>1e7)return send(r,400,{});
   const best=Math.max(score,D[id]?D[id].score:0);if(!D[id]||D[id].score!==best||D[id].name!==name){D[id]={name,score:best};fs.writeFileSync(F,JSON.stringify(D))}send(r,200,{ok:1})}catch(e){send(r,400,{})}});return}
 send(r,404,{})}).listen(process.env.PORT||3000);
