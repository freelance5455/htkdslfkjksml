from pathlib import Path
from shutil import copy2

root=Path(__file__).resolve().parent
res=root/'android/app/src/main/res'
if not res.is_dir():
    raise SystemExit('Android-Projekt fehlt: zuerst npm install && npx cap add android ausführen.')
icons=root/'android-icon-assets'
for folder, size in [('mipmap-mdpi',48),('mipmap-hdpi',72),('mipmap-xhdpi',96),('mipmap-xxhdpi',144),('mipmap-xxxhdpi',192)]:
    target=res/folder;target.mkdir(parents=True,exist_ok=True)
    for name in ('ic_launcher.png','ic_launcher_round.png'):
        copy2(icons/f'icon-{size}.png',target/name)
    copy2(icons/'adaptive-foreground.png',target/'ic_launcher_foreground.png')
values=res/'values';values.mkdir(parents=True,exist_ok=True)
(values/'ic_launcher_background.xml').write_text((icons/'adaptive-background.xml').read_text())
xml='''<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background" />\n    <foreground android:drawable="@mipmap/ic_launcher_foreground" />\n</adaptive-icon>\n'''
for folder in ('mipmap-anydpi-v26',):
    d=res/folder;d.mkdir(parents=True,exist_ok=True)
    for name in ('ic_launcher.xml','ic_launcher_round.xml'):
        (d/name).write_text(xml)
print('Block-Boom-Icons installiert.')
