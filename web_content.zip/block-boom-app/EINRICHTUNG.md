# Block Boom – Stand der Umsetzung

## In dieser Version umgesetzt
- Additive XP-Progression über mehrere Partien; XP und Level werden gespeichert.
- Schutz vor mehrfacher Game-Over-Statistik bei Wiederbelebung.
- Fünf Themes (inklusive Klassisch), vier kaufbare kosmetische Themes, dauerhaftes Inventar und Wechsel im Shop.
- Migration auf Speicherformat v3, Prüfung ungültiger Inventare.
- Externe Google-Fonts-Aufrufe entfernt; lokale Systemschrift-Fallbacks. Die Originalschriftarten wurden **nicht** eingebettet (für die Originaloptik sind rechtmäßig beschaffte Fontdateien nötig).
- Keine vorgetäuschten Käufe oder Werbevideos; fehlende Integrationen melden klar „noch nicht eingerichtet“.
- 17 automatisierte Logiktests, JavaScript-Syntaxprüfung.

## Für echte Monetarisierung noch erforderlich
**Nicht fertig und nicht getestet:** RevenueCat, AdMob, serverseitige Verifikation, echte Münzvergabe nach Zahlung/Video. Die Datei `www/monetization.js` ist eine bewusst gesperrte Integrationsschnittstelle und enthält keine simulierte Auszahlung. Es fehlen deine Store-Konten, Produktkennungen, SDK-Konfiguration, Werbe-IDs und ein Backend für signierte, idempotente Transaktionen. Für Consumable-Käufe muss ein verifizierendes Backend die gekauften Münzen genau einmal zuweisen. Für AdMob-Rewarded-Ads wird serverseitige Verifikation empfohlen. Niemals auf Basis einer ungeprüften Browsermeldung Münzen gutschreiben.

## Noch offen vor Veröffentlichung
- Native Builds und echte Touch-Tests auf iOS/Android (hier nicht durchgeführt).
- Backend, Login und sichere Online-Ranglisten.
- Datenschutz, Consent, App-Store-Texte, Icons und Screenshots.
- Integration echter Zahlungs- und Anzeigenanbieter, End-to-End-Tests mit Testkonten.
- Lokale Original-Fontdateien, sofern die exakte bisherige Typografie beibehalten werden soll.
- Geräte-Performance- und Accessibility-Tests.

## Testen
`npm test` im Projektverzeichnis. Für Browser-Tests einen lokalen Webserver mit `www/` als Root verwenden, z. B. `python3 -m http.server 8080 --directory www`.

## Native Builds
`npm install`, `npx cap add android` bzw. `npx cap add ios` (Mac/Xcode nötig), anschließend `npx cap sync`. Die App-ID vor Store-Release in `capacitor.config.json` anpassen.
