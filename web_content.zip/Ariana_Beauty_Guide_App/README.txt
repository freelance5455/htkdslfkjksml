Ariana - د ښکلا توکو جامع مسلکي لارښود
دا د Android لپاره د نصب کېدونکي PWA اپلیکیشن پروژه ده.

د چلولو/نصبولو طریقه:
1) فولډر په یوه ویب کوربه (HTTPS) کې خپور کړئ.
2) په Android Chrome کې یې URL خلاص کړئ.
3) د درې نقطو مېنو کې "Install app" یا "Add to Home screen" وټاکئ.
4) اپلیکیشن د موبایل له کور سکرین څخه پرانیستل کېږي.

یادونه: دا ZIP د APK فایل نه دی؛ د Android اصلي APK جوړولو لپاره د Android Studio/WebView یا TWA build او signing ته اړتیا ده.
