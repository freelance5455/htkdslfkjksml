PANDORA FISH BOT - HTML TO APK

Struktura:
PandoraFishBot/
  web/
    index.html

Ta wersja jest przygotowana pod builder, który szuka pliku:
appassets.androidplatform.net/web/index.html

UWAGA:
HTML/WebView nie może samodzielnie sterować inną aplikacją ani wykonywać
tapnięć w grze. Interfejs jest przygotowany jako front-end. Do działającego
bota potrzebny jest natywny moduł Android (Accessibility/MediaProjection)
dodany przez builder lub projekt Android Studio.
