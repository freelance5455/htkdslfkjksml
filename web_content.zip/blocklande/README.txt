Blocklande - offline:
1) With internet, download this file and save it next to index.html as three.min.js :
https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
2) Give the blocklande folder (index.html + three.min.js) to your APK builder.
