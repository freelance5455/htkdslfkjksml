# V53 — Excel Android Picker and Download Hardened

Built from V52.

- Uses a broad `*/*` native document type for Android file selection, avoiding vendor MIME-filter failures.
- Removes unnecessary persistable-URI flags from the picker path.
- Keeps direct `ACTION_OPEN_DOCUMENT` with `ACTION_GET_CONTENT` fallback.
- Publishes the downloaded Excel template with MediaStore `IS_PENDING` on Android 10+ so the file appears as a complete Downloads file.
- Version code 25 / version name 2.21.
