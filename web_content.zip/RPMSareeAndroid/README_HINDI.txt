RPM Saree Calculator APK बनाने के निर्देश (हिंदी)

इस ZIP में Android Studio का प्रोजेक्ट है। यह आपकी RPM Saree.html फाइल को Android WebView में खोलता है।

APK बनाने के लिए:
1. ZIP को कंप्यूटर पर Extract करें।
2. Android Studio खोलें।
3. File > Open चुनें और Extract किए गए RPMSareeAndroid फ़ोल्डर को खोलें।
4. Gradle Sync पूरा होने दें। यदि Android SDK/Gradle डाउनलोड मांगे, तो इंटरनेट चालू रखें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. बिल्ड पूरा होने पर नीचे दिखने वाले 'locate' लिंक से APK फ़ाइल देखें।
   सामान्य स्थान: app/build/outputs/apk/debug/app-debug.apk
7. APK को फोन में भेजें और इंस्टॉल करें। फोन पर अज्ञात ऐप इंस्टॉल करने की अनुमति मांगी जा सकती है।

महत्वपूर्ण:
- इस प्रोजेक्ट में आपकी मूल HTML फाइल को index.html के रूप में रखा गया है।
- मूल HTML में Bootstrap और jQuery CDN से लोड होते हैं; इसलिए पहली बार उन संसाधनों को लोड करने के लिए इंटरनेट चाहिए।
- यह ZIP तैयार Android Studio प्रोजेक्ट है, पहले से बना/साइन किया हुआ APK नहीं।
- अभी HTML के मूल कैलकुलेशन को बदला नहीं गया है।
