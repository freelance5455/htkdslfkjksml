#if UNITY_EDITOR
using UnityEditor; using UnityEditor.Build; using UnityEditor.SceneManagement; using UnityEngine;
public static class BuildTools {
  [MenuItem("BattleStrike/Setup Project")]
  public static void Setup() {
    System.IO.Directory.CreateDirectory("Assets/Scenes");
    var sc = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single); EditorSceneManager.SaveScene(sc, "Assets/Scenes/Main.unity");
    EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/Scenes/Main.unity", true) };
    PlayerSettings.companyName = "BattleStrike"; PlayerSettings.productName = "Battle Strike 3D";
    PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.battlestrike.game3d");
    PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation; PlayerSettings.allowedAutorotateToPortrait = false; PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
    PlayerSettings.allowedAutorotateToLandscapeLeft = true; PlayerSettings.allowedAutorotateToLandscapeRight = true;
    PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
    PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64; PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
    Debug.Log("Battle Strike 3D: setup selesai. Pastikan Player > Active Input Handling = Input Manager (Old) atau Both.");
  }
  [MenuItem("BattleStrike/Build APK")]
  public static void Build() {
    Setup(); var r = BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes = new[] { "Assets/Scenes/Main.unity" }, locationPathName = "Builds/BattleStrike3D.apk", target = BuildTarget.Android, options = BuildOptions.None });
    Debug.Log("Build: " + r.summary.result);
  }
}
#endif
