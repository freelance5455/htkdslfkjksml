using System.Collections.Generic; using UnityEngine;
namespace BattleStrike {
// Map 3D orisinal 70x70 m dibuat prosedural: bukit bertingkat, rumah, gudang, pohon, crate (cover), tembok batas.
// Static batching dipakai untuk menekan draw call. Untuk map final: ganti dengan scene + baked lightmap + LOD.
public static class ArenaBuilder {
  static GameObject Box(GameObject root, string n, Vector3 c, Vector3 s, Color col, bool cover = false, List<Transform> covers = null) {
    var g = GameObject.CreatePrimitive(PrimitiveType.Cube); g.name = n; g.transform.SetParent(root.transform, false); g.transform.position = c; g.transform.localScale = s;
    g.GetComponent<Renderer>().sharedMaterial = Game.Mat(col); g.isStatic = true; if (cover && covers != null) covers.Add(g.transform); return g;
  }
  static void House(GameObject r, Vector3 c, float w, float d, float h, Color wall, Color roof) {
    float t = .4f; Box(r, "wB", c + new Vector3(0, h / 2, d / 2), new Vector3(w, h, t), wall); Box(r, "wL", c + new Vector3(-w / 2, h / 2, 0), new Vector3(t, h, d), wall);
    Box(r, "wR", c + new Vector3(w / 2, h / 2, 0), new Vector3(t, h, d), wall); float seg = (w - 3f) / 2f;
    Box(r, "wF1", c + new Vector3(-w / 2 + seg / 2, h / 2, -d / 2), new Vector3(seg, h, t), wall); Box(r, "wF2", c + new Vector3(w / 2 - seg / 2, h / 2, -d / 2), new Vector3(seg, h, t), wall);
    Box(r, "lintel", c + new Vector3(0, h - .5f, -d / 2), new Vector3(3, 1, t), wall); Box(r, "roof", c + new Vector3(0, h + .15f, 0), new Vector3(w + .6f, .3f, d + .6f), roof);
  }
  public static GameObject Build(List<Transform> covers) {
    var root = new GameObject("Arena"); var rnd = new System.Random(7);
    Box(root, "Ground", new Vector3(0, -.5f, 0), new Vector3(70, 1, 70), new Color(.35f, .5f, .3f));
    Color gray = new Color(.5f, .5f, .55f);
    Box(root, "N", new Vector3(0, 2, 35.5f), new Vector3(72, 4, 1), gray); Box(root, "S", new Vector3(0, 2, -35.5f), new Vector3(72, 4, 1), gray);
    Box(root, "E", new Vector3(35.5f, 2, 0), new Vector3(1, 4, 72), gray); Box(root, "W", new Vector3(-35.5f, 2, 0), new Vector3(1, 4, 72), gray);
    for (int i = 0; i < 3; i++) {   // bukit (anak tangga 0.4 m <= stepOffset)
      var c = GameObject.CreatePrimitive(PrimitiveType.Cylinder); c.name = "Hill"; c.transform.SetParent(root.transform, false);
      c.transform.position = new Vector3(-8, .2f + i * .4f, 14); c.transform.localScale = new Vector3(16 - i * 5, .2f, 16 - i * 5); c.GetComponent<Renderer>().sharedMaterial = Game.Mat(new Color(.45f, .38f, .26f)); c.isStatic = true;
    }
    House(root, new Vector3(12, 0, -10), 10, 8, 3.5f, new Color(.75f, .7f, .6f), new Color(.5f, .25f, .2f));
    House(root, new Vector3(-14, 0, -8), 14, 10, 5f, new Color(.55f, .6f, .65f), new Color(.3f, .3f, .35f));
    for (int i = 0; i < 14; i++) {   // pohon
      float x = (float)(rnd.NextDouble() * 56 - 28), z = (float)(rnd.NextDouble() * 56 - 28); if (Mathf.Abs(x) > 20) continue;
      Box(root, "Trunk", new Vector3(x, 1.5f, z), new Vector3(.5f, 3f, .5f), new Color(.4f, .27f, .15f));
      var cn = GameObject.CreatePrimitive(PrimitiveType.Sphere); cn.name = "Canopy"; cn.transform.SetParent(root.transform, false); cn.transform.position = new Vector3(x, 4f, z); cn.transform.localScale = Vector3.one * 3f;
      Object.Destroy(cn.GetComponent<Collider>()); cn.GetComponent<Renderer>().sharedMaterial = Game.Mat(new Color(.15f, .4f, .18f)); cn.isStatic = true;
    }
    for (int i = 0; i < 18; i++) {   // crate = cover
      float x = (float)(rnd.NextDouble() * 40 - 20), z = (float)(rnd.NextDouble() * 56 - 28); float s = 1.5f + (float)rnd.NextDouble();
      Box(root, "Crate", new Vector3(x, s / 2, z), new Vector3(s, s, s), new Color(.6f, .45f, .25f), true, covers);
    }
    try { StaticBatchingUtility.Combine(root); } catch (System.Exception e) { Debug.LogWarning(e.Message); }
    return root;
  }
}
}
