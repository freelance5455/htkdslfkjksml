using System.Collections; using System.Collections.Generic; using UnityEngine;
namespace BattleStrike {
public enum Mode { Training, Duel, Team2, Team3, Team4 }
// Mode Team Battle round-based vs BOT LOKAL: tim A (pemain + sekutu bot) vs tim B, tim pertama menang 3 ronde. Bukan multiplayer online.
public class MatchManager : MonoBehaviour {
  public static MatchManager I;
  public List<Health> all = new List<Health>(); public List<Transform> covers = new List<Transform>();
  public bool inputLocked, over, won, inInter; public Mode mode; public int[] score = new int[2]; public int round, kills, deaths, expGain, coinGain; public float roundEndAt, hitTime, dmgTime; public bool hitHead; public string resultText = "";
  public PlayerController pc; public List<KeyValuePair<string, float>> feed = new List<KeyValuePair<string, float>>();
  Health player; GameObject arena; readonly List<GameObject> actors = new List<GameObject>(); readonly Vector3[] alertPos = new Vector3[2]; readonly float[] alertT = { -99, -99 }; float interUntil; int size;

  public static void Begin(Mode m) { var g = new GameObject("Match"); I = g.AddComponent<MatchManager>(); I.Init(m); }
  static void Layer(GameObject g, int l) { foreach (var t in g.GetComponentsInChildren<Transform>()) t.gameObject.layer = l; }
  void Init(Mode m) {
    mode = m; arena = ArenaBuilder.Build(covers); size = m == Mode.Duel ? 1 : m == Mode.Team2 ? 2 : m == Mode.Team3 ? 3 : m == Mode.Team4 ? 4 : 0;
    var acc = Accounts.Current; var pg = CharacterFactory.Create(acc.nickname, 0, new Color(.2f, .5f, .9f)); pc = pg.AddComponent<PlayerController>(); pc.Setup(Game.Cam);
    player = pg.GetComponent<Health>(); Layer(pg, 2); actors.Add(pg); all.Add(player);
    var tc = Game.Cam.gameObject.AddComponent<TPSCamera>(); tc.pc = pc;
    if (m == Mode.Training) { pg.GetComponent<Gun>().unlimited = true; for (int i = 0; i < 3; i++) Spawn("Dummy" + (i + 1), 1, 0, true); }
    else { for (int i = 1; i < size; i++) Spawn("Ally" + i, 0, .5f, false); for (int i = 0; i < size; i++) Spawn("Enemy" + (i + 1), 1, .35f + .1f * Mathf.Min(acc.level, 5) / 5f, false); }
    foreach (var h in all) { h.Died += OnDied; h.Damaged += OnDamaged; }
    StartRound();
  }
  void Spawn(string n, int team, float skill, bool dummy) {
    var g = CharacterFactory.Create(n, team, team == 0 ? new Color(.2f, .7f, .3f) : new Color(.85f, .25f, .2f)); var b = g.AddComponent<Bot>(); b.skill = skill; b.dummy = dummy;
    var gun = g.GetComponent<Gun>(); gun.Equip(WeaponData.All[Random.value < .25f ? 1 : 0], 0, 0); gun.Fill(); if (dummy) gun.unlimited = true; actors.Add(g); all.Add(g.GetComponent<Health>());
  }
  Vector3 SpawnPos(Health h) {
    if (mode == Mode.Training) { if (h == player) return new Vector3(0, 0, -25); int i = all.IndexOf(h); return new Vector3((i - 2) * 9f, 0, 2 + i * 8f); }
    int idx = 0, cnt = 0; foreach (var o in all) if (o.team == h.team) { if (o == h) idx = cnt; cnt++; }
    return new Vector3(h.team == 0 ? -26f : 26f, 0, (idx - (cnt - 1) / 2f) * 5f);
  }
  void Respawn(Health h) {
    h.gameObject.SetActive(true); h.Revive(); var cc = h.GetComponent<CharacterController>(); cc.enabled = false; h.transform.position = SpawnPos(h);
    h.transform.rotation = Quaternion.Euler(0, h.team == 0 ? 90 : -90, 0); cc.enabled = true;
    var b = h.GetComponent<Bot>(); if (b != null) { b.Reset(); h.GetComponent<Gun>().Fill(); }
    if (h == player) { pc.yaw = h.team == 0 ? 90 : -90; if (mode != Mode.Training) pc.RoundReset(); else pc.RoundReset(); }
  }
  void StartRound() { round++; roundEndAt = Time.time + 90f; inInter = false; foreach (var h in all) Respawn(h); }
  void OnDied(Health v, Health by, bool head) {
    feed.Add(new KeyValuePair<string, float>((by != null ? by.displayName : "?") + " > " + v.displayName + (head ? " [HS]" : ""), Time.time));
    if (by == player && v != player) kills++; if (v == player) deaths++;
    v.gameObject.SetActive(false);
    if (mode == Mode.Training && v != player) StartCoroutine(RespawnLater(v));
  }
  IEnumerator RespawnLater(Health h) { yield return new WaitForSeconds(3f); if (!over) Respawn(h); }
  void OnDamaged(Health v, float d, Health by, bool head) {
    if (by == player && v != player) { hitTime = Time.time; hitHead = head; Sfx.Play(Sfx.Hit, Vector3.zero, .6f, true); }
    if (v == player) dmgTime = Time.time;
  }
  int Alive(int t) { int n = 0; foreach (var h in all) if (h.team == t && !h.dead) n++; return n; }
  float HpSum(int t) { float s = 0; foreach (var h in all) if (h.team == t && !h.dead) s += h.hp; return s; }
  void Update() {
    if (over || mode == Mode.Training || Game.Paused) return;
    if (inInter) { if (Time.time >= interUntil) StartRound(); return; }
    int a0 = Alive(0), a1 = Alive(1), w = -2;
    if (a0 == 0 && a1 == 0) w = -1; else if (a1 == 0) w = 0; else if (a0 == 0) w = 1;
    else if (Time.time >= roundEndAt) { float h0 = HpSum(0), h1 = HpSum(1); w = h0 > h1 ? 0 : h1 > h0 ? 1 : -1; }
    if (w == -2) return;
    if (w >= 0) score[w]++; resultText = w == 0 ? "Ronde dimenangkan!" : w == 1 ? "Ronde kalah" : "Ronde seri";
    if (score[0] >= 3 || score[1] >= 3) End(score[0] >= 3 ? 0 : 1); else { inInter = true; interUntil = Time.time + 3f; }
  }
  void End(int winTeam) {
    over = true; inputLocked = true; won = winTeam == 0; var a = Accounts.Current;
    expGain = 40 + kills * 10 + (won ? 60 : 0); coinGain = 30 + kills * 5 + (won ? 50 : 0);   // Reward lokal; versi online dihitung server
    a.AddExp(expGain); a.coin += coinGain; a.matches++; a.kills += kills; a.deaths += deaths; if (won) a.wins++;
    a.history.Insert(0, new MatchRecord { mode = mode.ToString() + " (bot)", won = won, kills = kills, deaths = deaths, exp = expGain, coin = coinGain, date = System.DateTime.Now.ToString("dd/MM HH:mm") });
    if (a.history.Count > 30) a.history.RemoveAt(30); Accounts.Save();
  }
  public void Alert(int team, Vector3 p) { alertPos[team] = p; alertT[team] = Time.time; }
  public bool AlertFor(int team, out Vector3 p, Vector3 from) { p = alertPos[team]; return Time.time - alertT[team] < 8f && Vector3.Distance(p, from) > 4f; }
  public Vector3 RandomPoint() { return new Vector3(Random.Range(-28f, 28f), 0, Random.Range(-28f, 28f)); }
  public void Leave() {
    if (mode == Mode.Training) Accounts.Save();
    foreach (var a in actors) if (a) Destroy(a); if (arena) Destroy(arena); var tc = Game.Cam.GetComponent<TPSCamera>(); if (tc) Destroy(tc);
    I = null; Time.timeScale = 1; Game.Paused = false; Destroy(gameObject); Game.ToLobby();
  }
}
}
