using UnityEngine;
namespace BattleStrike {
public enum Scope { RedDot, X2, X4, Sniper }
// Nama & model ORISINAL. Tiap senjata hanya mewakili tipe gameplay (AR / SMG / shotgun / sniper).
public class WeaponData {
  public string name, type; public bool auto; public int mag, reserve, pellets = 1; public Scope scope;
  public float rps, damage, headMul, reload, spread, spreadShot, spreadMax, recoilUp, recoilSide, range, fallStart, fallMin, adsFov, adsSpread = .5f;
  public float Falloff(float d) { return d <= fallStart ? 1f : Mathf.Lerp(1f, fallMin, Mathf.InverseLerp(fallStart, range, d)); }
  public static readonly WeaponData[] All = {
    new WeaponData { name = "R4 Carbine", type = "Assault Rifle", auto = true, rps = 10, damage = 22, headMul = 2f, mag = 30, reserve = 120, reload = 2f, spread = .5f, spreadShot = .25f, spreadMax = 4, recoilUp = .55f, recoilSide = .25f, range = 120, fallStart = 40, fallMin = .6f, adsFov = 50, scope = Scope.RedDot },
    new WeaponData { name = "Viper SMG", type = "SMG", auto = true, rps = 15, damage = 15, headMul = 1.8f, mag = 35, reserve = 140, reload = 1.7f, spread = .9f, spreadShot = .2f, spreadMax = 5, recoilUp = .35f, recoilSide = .3f, range = 70, fallStart = 20, fallMin = .5f, adsFov = 55, scope = Scope.RedDot },
    new WeaponData { name = "Scorpion SG", type = "Shotgun", auto = false, rps = 1.2f, damage = 9, pellets = 9, headMul = 1.5f, mag = 6, reserve = 30, reload = 2.4f, spread = 4f, spreadShot = 0, spreadMax = 4, recoilUp = 3.5f, recoilSide = .6f, range = 40, fallStart = 8, fallMin = .25f, adsFov = 58, scope = Scope.RedDot, adsSpread = .8f },
    new WeaponData { name = "Longshot", type = "Sniper", auto = false, rps = .8f, damage = 95, headMul = 2.5f, mag = 5, reserve = 25, reload = 2.8f, spread = 2.5f, spreadShot = 0, spreadMax = 2.5f, recoilUp = 3f, recoilSide = .3f, range = 200, fallStart = 120, fallMin = .8f, adsFov = 15, scope = Scope.Sniper, adsSpread = .02f },
  };
}
public class Hitbox : MonoBehaviour { public Health owner; public bool head; }
public class Health : MonoBehaviour {
  public float hp = 100, max = 100, armor; public int team; public string displayName; public bool dead;
  public event System.Action<Health, float, Health, bool> Damaged;   // victim, dmg, attacker, head
  public event System.Action<Health, Health, bool> Died;             // victim, attacker, head
  public void Damage(float d, Health by, bool head) {
    if (dead) return; if (by != null && by != this && by.team == team) return;       // tanpa friendly fire
    if (armor > 0) { float a = Mathf.Min(armor, d * .5f); armor -= a; d -= a; }
    hp -= d; if (Damaged != null) Damaged(this, d, by, head);
    if (hp <= 0) { hp = 0; dead = true; if (Died != null) Died(this, by, head); }
  }
  public void Heal(float v) { hp = Mathf.Min(max, hp + v); }
  public void Revive() { hp = max; armor = 0; dead = false; }
}
public static class Ballistics {
  static readonly System.Comparison<RaycastHit> cmp = (a, b) => a.distance.CompareTo(b.distance);
  // Hitscan. Server-authoritative nanti: pindahkan fungsi ini ke server, klien hanya kirim input.
  public static bool Shoot(Vector3 o, Vector3 d, WeaponData w, Health owner, out Vector3 end) {
    var hits = Physics.RaycastAll(o, d, w.range, ~0, QueryTriggerInteraction.Ignore); System.Array.Sort(hits, cmp);
    foreach (var h in hits) {
      var hb = h.collider.GetComponent<Hitbox>(); var hp = hb != null ? hb.owner : null;
      if (hp != null && hp == owner) continue;
      end = h.point;
      if (hp != null) { hp.Damage(w.damage * w.Falloff(h.distance) * (hb.head ? w.headMul : 1f), owner, hb.head); return true; }
      return false;
    }
    end = o + d * w.range; return false;
  }
  public static Vector3 Probe(Vector3 o, Vector3 d, Health owner) {
    var hits = Physics.RaycastAll(o, d, 150f, ~0, QueryTriggerInteraction.Ignore); System.Array.Sort(hits, cmp);
    foreach (var h in hits) { var hb = h.collider.GetComponent<Hitbox>(); if (hb != null && hb.owner == owner) continue; return h.point; }
    return o + d * 150f;
  }
}
public class Gun : MonoBehaviour {
  public WeaponData w; public int mag, reserve; public Health owner; public Transform muzzle;
  float next, reloadEnd, heat; bool pending; public bool unlimited;
  public bool Reloading { get { return pending; } }
  public float SpreadNow { get { return w == null ? 0 : w.spread + heat; } }
  public void Equip(WeaponData d, int m, int r) { w = d; mag = m; reserve = r; pending = false; heat = 0; }
  public void Fill() { if (w != null) { mag = w.mag; reserve = w.reserve; pending = false; } }
  public bool TryFire(Vector3 o, Vector3 dir, bool ads, out Vector2 kick) {
    kick = Vector2.zero; if (w == null || pending || Time.time < next || mag <= 0) return false;
    next = Time.time + 1f / w.rps; mag--;
    float sp = (w.spread + heat) * (ads ? w.adsSpread : 1f); heat = Mathf.Min(w.spreadMax, heat + w.spreadShot);
    var rot = Quaternion.LookRotation(dir); Vector3 mp = muzzle != null ? muzzle.position : o; Vector3 end = o;
    for (int i = 0; i < w.pellets; i++) {
      Vector2 c = Random.insideUnitCircle * Mathf.Tan(sp * Mathf.Deg2Rad);
      Vector3 d = (dir + rot * Vector3.right * c.x + rot * Vector3.up * c.y).normalized;
      Ballistics.Shoot(o, d, w, owner, out end); Fx.Tracer(mp, end);
    }
    Fx.Flash(mp); Sfx.Play(Sfx.Shot, mp, .8f);
    kick = new Vector2(Random.Range(-w.recoilSide, w.recoilSide), w.recoilUp); return true;
  }
  public void StartReload() {
    if (w == null || pending || mag >= w.mag || (reserve <= 0 && !unlimited)) return;
    pending = true; reloadEnd = Time.time + w.reload; Sfx.Play(Sfx.Reload, transform.position, .6f);
  }
  void Update() {
    heat = Mathf.MoveTowards(heat, 0, Time.deltaTime * 6f);
    if (pending && Time.time >= reloadEnd) {
      pending = false; int need = w.mag - mag; int take = unlimited ? need : Mathf.Min(need, reserve);
      mag += take; if (!unlimited) reserve -= take;
    }
  }
}
}
