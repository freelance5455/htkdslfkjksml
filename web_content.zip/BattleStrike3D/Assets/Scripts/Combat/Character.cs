using UnityEngine;
namespace BattleStrike {
public class Footsteps : MonoBehaviour {
  CharacterController cc; float t;
  void Awake() { cc = GetComponent<CharacterController>(); }
  void Update() {
    if (cc == null || !cc.isGrounded) return; float v = new Vector3(cc.velocity.x, 0, cc.velocity.z).magnitude; if (v < 1f) return;
    t += Time.deltaTime * v; if (t > 3.2f) { t = 0; Sfx.Play(Sfx.Step, transform.position, .5f); }
  }
}
public static class CharacterFactory {
  static GameObject Prim(PrimitiveType t, Transform p, string n, Vector3 pos, Vector3 sc, Color c, bool keepCol) {
    var g = GameObject.CreatePrimitive(t); g.name = n; g.transform.SetParent(p, false); g.transform.localPosition = pos; g.transform.localScale = sc;
    g.GetComponent<Renderer>().sharedMaterial = Game.Mat(c); if (!keepCol) Object.Destroy(g.GetComponent<Collider>()); return g;
  }
  // Karakter placeholder dari primitif (orisinal). Ganti dengan model rigged + Animator untuk animasi sungguhan.
  public static GameObject Create(string name, int team, Color col, bool visualOnly = false) {
    var root = new GameObject(name);
    Prim(PrimitiveType.Capsule, root.transform, "Body", new Vector3(0, .8f, 0), new Vector3(.6f, .8f, .6f), col, false);
    var head = Prim(PrimitiveType.Sphere, root.transform, "Head", new Vector3(0, 1.7f, 0), Vector3.one * .4f, new Color(.9f, .75f, .6f), !visualOnly);
    var gun = Prim(PrimitiveType.Cube, root.transform, "GunVis", new Vector3(.25f, 1.1f, .4f), new Vector3(.08f, .12f, .7f), new Color(.1f, .1f, .12f), false);
    if (visualOnly) return root;
    var cc = root.AddComponent<CharacterController>(); cc.height = 1.6f; cc.radius = .35f; cc.center = new Vector3(0, .8f, 0); cc.stepOffset = .45f;
    var hp = root.AddComponent<Health>(); hp.team = team; hp.displayName = name;
    var hb = root.AddComponent<Hitbox>(); hb.owner = hp;
    var hh = head.AddComponent<Hitbox>(); hh.owner = hp; hh.head = true;
    var g = root.AddComponent<Gun>(); g.owner = hp; g.muzzle = gun.transform;
    root.AddComponent<Footsteps>(); return root;
  }
  public static void SetCrouch(GameObject root, bool c) {
    var cc = root.GetComponent<CharacterController>(); cc.height = c ? 1.1f : 1.6f; cc.center = new Vector3(0, c ? .55f : .8f, 0);
    root.transform.Find("Head").localPosition = new Vector3(0, c ? 1.2f : 1.7f, 0);
    var b = root.transform.Find("Body"); b.localPosition = new Vector3(0, c ? .55f : .8f, 0); b.localScale = new Vector3(.6f, c ? .55f : .8f, .6f);
  }
}
}
