using UnityEngine;
namespace BattleStrike {
// Semua suara dibuat prosedural (tanpa aset berhak cipta). Ganti dengan klip asli untuk kualitas final.
public static class Sfx {
  public static AudioClip Shot, Reload, Hit, Step; static AudioSource[] pool; static int pi;
  delegate float Gen(float t);
  static AudioClip Make(string n, float dur, Gen g) {
    int sr = 22050, len = (int)(sr * dur); var d = new float[len];
    for (int i = 0; i < len; i++) d[i] = Mathf.Clamp(g(i / (float)sr), -.8f, .8f);   // clamp: hindari clipping
    var c = AudioClip.Create(n, len, 1, sr, false); c.SetData(d, 0); return c;
  }
  static float N() { return Random.value * 2 - 1; }
  public static void Init() {
    Shot = Make("shot", .16f, t => N() * Mathf.Exp(-t * 30) * .7f + Mathf.Sin(t * 6.28f * 90) * Mathf.Exp(-t * 20) * .5f);
    Reload = Make("reload", .3f, t => (t < .03f || (t > .15f && t < .18f)) ? N() * .5f : 0);
    Hit = Make("hit", .08f, t => Mathf.Sin(t * 6.28f * 1200) * Mathf.Exp(-t * 40) * .5f);
    Step = Make("step", .12f, t => (Mathf.Sin(t * 6.28f * 60) * .6f + N() * .2f) * Mathf.Exp(-t * 25));
    var g = new GameObject("Sfx"); Object.DontDestroyOnLoad(g); pool = new AudioSource[14];
    for (int i = 0; i < pool.Length; i++) {
      var s = new GameObject("s").AddComponent<AudioSource>(); s.transform.SetParent(g.transform);
      s.spatialBlend = 1; s.rolloffMode = AudioRolloffMode.Linear; s.minDistance = 2; s.maxDistance = 70; s.dopplerLevel = 0; pool[i] = s;
    }
  }
  // spatial 3D: AudioListener ada di kamera, jadi arah kiri/kanan terdengar di headphone stereo
  public static void Play(AudioClip c, Vector3 pos, float vol = 1, bool flat = false) {
    if (c == null || pool == null) return; var st = Game.S; var s = pool[pi++ % pool.Length];
    s.transform.position = pos; s.clip = c; s.volume = Mathf.Clamp01(vol * st.sfx * (st.reduceLoud ? .5f : 1f));
    s.spatialBlend = (flat || st.monoAudio) ? 0 : 1; s.panStereo = 0; s.Play();
  }
}
public class Fx : MonoBehaviour {
  static Fx I; LineRenderer[] lines = new LineRenderer[10]; float[] until = new float[10]; int li; Light flash; float flashUntil;
  public static void Init() { var g = new GameObject("Fx"); DontDestroyOnLoad(g); I = g.AddComponent<Fx>(); I.Build(); }
  void Build() {
    var mat = Game.Mat(new Color(1, .9f, .5f));
    for (int i = 0; i < lines.Length; i++) {
      var lr = new GameObject("t").AddComponent<LineRenderer>(); lr.transform.SetParent(transform); lr.sharedMaterial = mat; lr.startWidth = lr.endWidth = .04f;
      lr.positionCount = 2; lr.enabled = false; lr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off; lines[i] = lr;
    }
    flash = new GameObject("f").AddComponent<Light>(); flash.transform.SetParent(transform); flash.type = LightType.Point; flash.range = 6; flash.intensity = 2; flash.color = new Color(1, .7f, .3f); flash.enabled = false;
  }
  public static void Tracer(Vector3 a, Vector3 b) {
    if (I == null || Game.S.fx == 0) return; int i = I.li++ % I.lines.Length;
    I.lines[i].SetPosition(0, a); I.lines[i].SetPosition(1, b); I.lines[i].enabled = true; I.until[i] = Time.time + .05f;
  }
  public static void Flash(Vector3 p) { if (I == null || Game.S.fx == 0) return; I.flash.transform.position = p; I.flash.enabled = true; I.flashUntil = Time.time + .04f; }
  void Update() { for (int i = 0; i < lines.Length; i++) if (lines[i].enabled && Time.time > until[i]) lines[i].enabled = false; if (flash.enabled && Time.time > flashUntil) flash.enabled = false; }
}
}
