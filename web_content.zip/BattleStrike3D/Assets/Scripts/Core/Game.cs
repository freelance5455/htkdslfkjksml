using System.Collections.Generic; using UnityEngine;
namespace BattleStrike {
public class Bootstrap : MonoBehaviour {
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
  static void Auto() { var g = new GameObject("BattleStrike3D"); DontDestroyOnLoad(g); g.AddComponent<Bootstrap>(); }
  void Awake() {
    Screen.autorotateToPortrait = Screen.autorotateToPortraitUpsideDown = false;
    Screen.autorotateToLandscapeLeft = Screen.autorotateToLandscapeRight = true; Screen.orientation = ScreenOrientation.AutoRotation;
    Screen.sleepTimeout = SleepTimeout.NeverSleep;
    Accounts.Load(); Game.Init(); Sfx.Init(); Fx.Init();
    gameObject.AddComponent<TouchInput>(); gameObject.AddComponent<LobbyUI>(); gameObject.AddComponent<Hud>();
    Game.ToLobby();
  }
  void OnApplicationPause(bool p) { if (p) Accounts.Save(); }
}
public class Spin : MonoBehaviour { void Update() { transform.Rotate(0, 20 * Time.deltaTime, 0); } }

public static class Game {
  public static Camera Cam; public static Light Sun; public static bool Paused;
  static Settings fallback = new Settings(); static Material baseMat; static GameObject stage;
  static Dictionary<Color, Material> mats = new Dictionary<Color, Material>();
  public static Settings S { get { return Accounts.Current != null ? Accounts.Current.settings : fallback; } }

  public static void Init() {
    foreach (var c in Camera.allCameras) c.enabled = false;
    var cg = new GameObject("MainCam"); Object.DontDestroyOnLoad(cg); Cam = cg.AddComponent<Camera>(); cg.tag = "MainCamera"; cg.AddComponent<AudioListener>();
    Cam.clearFlags = CameraClearFlags.SolidColor; Cam.backgroundColor = new Color(.55f, .72f, .88f); Cam.farClipPlane = 140;
    var sg = new GameObject("Sun"); Object.DontDestroyOnLoad(sg); Sun = sg.AddComponent<Light>(); Sun.type = LightType.Directional; Sun.intensity = 1.1f; sg.transform.rotation = Quaternion.Euler(50, -30, 0);
    ApplyGfx();
  }
  public static void ApplyGfx() {
    var s = S; Application.targetFrameRate = s.fps; QualitySettings.vSyncCount = 0;
    switch (s.quality) {
      case 0: QualitySettings.shadows = ShadowQuality.Disable; QualitySettings.antiAliasing = 0; QualitySettings.lodBias = .6f; QualitySettings.shadowDistance = 0; Sun.shadows = LightShadows.None; break;
      case 1: QualitySettings.shadows = ShadowQuality.HardOnly; QualitySettings.antiAliasing = 0; QualitySettings.lodBias = .9f; QualitySettings.shadowDistance = 25; Sun.shadows = LightShadows.Hard; break;
      default: QualitySettings.shadows = ShadowQuality.All; QualitySettings.antiAliasing = 2; QualitySettings.lodBias = 1.2f; QualitySettings.shadowDistance = 50; Sun.shadows = LightShadows.Soft; break;
    }
    AudioListener.volume = s.master;
    Input.gyro.enabled = s.gyroOn && SystemInfo.supportsGyroscope;
  }
  public static Material Mat(Color c) {
    if (baseMat == null) { var p = GameObject.CreatePrimitive(PrimitiveType.Cube); baseMat = p.GetComponent<Renderer>().sharedMaterial; Object.Destroy(p); }
    Material m; if (!mats.TryGetValue(c, out m)) { m = new Material(baseMat); m.color = c; mats[c] = m; } return m;
  }
  public static void ToLobby() {
    Paused = false; Time.timeScale = 1; if (stage) Object.Destroy(stage);
    stage = new GameObject("LobbyStage");
    var fl = GameObject.CreatePrimitive(PrimitiveType.Cylinder); fl.transform.SetParent(stage.transform); fl.transform.localScale = new Vector3(6, .05f, 6); fl.transform.position = new Vector3(0, -.05f, 0); fl.GetComponent<Renderer>().sharedMaterial = Mat(new Color(.25f, .27f, .32f));
    var ch = CharacterFactory.Create(Accounts.Current != null ? Accounts.Current.nickname : "Preview", 0, new Color(.2f, .5f, .9f), true);
    ch.transform.SetParent(stage.transform); ch.transform.position = new Vector3(1.6f, 0, 0); ch.AddComponent<Spin>();
    Cam.transform.SetPositionAndRotation(new Vector3(0, 1.4f, -4.2f), Quaternion.LookRotation(new Vector3(1.1f, 1f, 0) - new Vector3(0, 1.4f, -4.2f))); Cam.fieldOfView = 40;
  }
  public static void StartMatch(Mode m) { if (stage) Object.Destroy(stage); MatchManager.Begin(m); }
}
}
