using System.IO; using System.Linq; using System.Security.Cryptography; using System.Text; using UnityEngine;
namespace BattleStrike {
// Akun LOKAL (offline). Password di-hash PBKDF2 + salt, tidak pernah disimpan plaintext.
// File save diberi HMAC: hanya pencegah edit iseng, BUKAN anti-cheat. Saldo asli butuh server.
public static class Accounts {
  public static Account Current; public static string Notice; static SaveFile file = new SaveFile();
  static string P { get { return Path.Combine(Application.persistentDataPath, "save.json"); } }
  static string Sign(string j) { using (var h = new HMACSHA256(Encoding.UTF8.GetBytes(SystemInfo.deviceUniqueIdentifier + "|bs1"))) return System.Convert.ToBase64String(h.ComputeHash(Encoding.UTF8.GetBytes(j))); }
  static string Hash(string pass, string salt) { using (var d = new Rfc2898DeriveBytes(pass, System.Convert.FromBase64String(salt), 10000, HashAlgorithmName.SHA256)) return System.Convert.ToBase64String(d.GetBytes(32)); }

  public static void Load() {
    try {
      if (File.Exists(P) && File.Exists(P + ".sig")) {
        var j = File.ReadAllText(P);
        if (Sign(j) == File.ReadAllText(P + ".sig")) file = JsonUtility.FromJson<SaveFile>(j) ?? new SaveFile();
        else { Debug.LogWarning("Save korup/diubah"); File.Move(P, P + ".corrupt" + System.DateTime.Now.Ticks); }
      }
    } catch (System.Exception e) { Debug.LogWarning(e.Message); }
    Current = file.accounts.FirstOrDefault(a => a.id == file.lastAccountId);
    if (Current != null) Daily();
  }
  public static void Save() {
    try { file.lastAccountId = Current != null ? Current.id : ""; var j = JsonUtility.ToJson(file); File.WriteAllText(P, j); File.WriteAllText(P + ".sig", Sign(j)); }
    catch (System.Exception e) { Debug.LogWarning(e.Message); }
  }
  static Account New(string nick, bool guest) {
    return new Account { id = "BS" + new System.Random(System.Guid.NewGuid().GetHashCode()).Next(10000000, 99999999), nickname = nick, guest = guest };
  }
  public static bool Register(string nick, string pass, out string err) {
    err = null; nick = (nick ?? "").Trim();
    if (nick.Length < 3 || nick.Length > 16) { err = "Nickname 3-16 karakter"; return false; }
    if ((pass ?? "").Length < 6) { err = "Password minimal 6 karakter"; return false; }
    if (file.accounts.Any(a => !a.guest && string.Equals(a.nickname, nick, System.StringComparison.OrdinalIgnoreCase))) { err = "Nickname sudah dipakai"; return false; }
    var salt = new byte[16]; using (var r = RandomNumberGenerator.Create()) r.GetBytes(salt);
    var a2 = New(nick, false); a2.passSalt = System.Convert.ToBase64String(salt); a2.passHash = Hash(pass, a2.passSalt);
    file.accounts.Add(a2); Current = a2; Daily(); Save(); return true;
  }
  public static bool Login(string nick, string pass, out string err) {
    err = null; var a = file.accounts.FirstOrDefault(x => !x.guest && string.Equals(x.nickname, (nick ?? "").Trim(), System.StringComparison.OrdinalIgnoreCase));
    if (a == null || Hash(pass ?? "", a.passSalt) != a.passHash) { err = "Nickname atau password salah"; return false; }
    Current = a; Daily(); Save(); return true;
  }
  public static void Guest() {
    var g = file.accounts.FirstOrDefault(x => x.guest);
    if (g == null) { g = New("Guest" + Random.Range(1000, 9999), true); file.accounts.Add(g); }
    Current = g; Daily(); Save();
  }
  public static void Logout() { Save(); Current = null; file.lastAccountId = ""; Save(); }
  // Login harian lokal: mengandalkan jam perangkat, jadi mudah dimanipulasi. Versi online harus di server.
  static void Daily() {
    var today = System.DateTime.UtcNow.ToString("yyyy-MM-dd");
    if (Current.lastLoginDay != today) { Current.lastLoginDay = today; Current.coin += 100; Notice = "Login harian: +100 coin"; Save(); }
  }
}
}
