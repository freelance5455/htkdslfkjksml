using System.Collections.Generic;
namespace BattleStrike {
[System.Serializable] public class MatchRecord { public string mode; public bool won; public int kills, deaths, exp, coin; public string date; }

[System.Serializable] public class Settings {
  public int quality = 1, fps = 30, fx = 1;               // quality 0/1/2 = Low/Med/High, fx 0/1/2
  public float general = .5f, ads = .5f, redDot = .45f, scope2x = .4f, scope4x = .3f, sniper = .25f, freeLook = .5f, gyro = .3f;
  public bool gyroOn, aimAssist = true, autoReload = true, holdAds = true, leftFire, monoAudio, reduceLoud;
  public float aimAssistStrength = .25f, master = 1, music = .7f, sfx = 1, voice = 1, hudScale = 1, hudOpacity = .7f;
  public void ResetSens() { general = .5f; ads = .5f; redDot = .45f; scope2x = .4f; scope4x = .3f; sniper = .25f; freeLook = .5f; gyro = .3f; }
  public void Preset(int p) { float k = p == 0 ? .3f : p == 1 ? .5f : .75f; general = k; ads = k * .9f; redDot = k * .9f; scope2x = k * .8f; scope4x = k * .6f; sniper = k * .5f; freeLook = k; }
}

[System.Serializable] public class Account {
  public string id, nickname, passSalt, passHash, lastLoginDay; public bool guest, tutorialDone;
  public int level = 1, exp, coin = 500, diamond, kills, deaths, wins, matches;
  public int[] loadout = { 0, 1, 2 };
  public List<MatchRecord> history = new List<MatchRecord>();
  public Settings settings = new Settings();
  public int ExpNeed { get { return 100 + level * 50; } }
  public void AddExp(int e) { exp += e; while (exp >= ExpNeed) { exp -= ExpNeed; level++; } }
}
[System.Serializable] public class SaveFile { public List<Account> accounts = new List<Account>(); public string lastAccountId; }
}
