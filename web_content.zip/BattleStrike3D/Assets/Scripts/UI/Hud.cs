using UnityEngine;
namespace BattleStrike {
public class Hud : MonoBehaviour {
  float fps = 30; Vector2 scroll;
  void Update() { fps = Mathf.Lerp(fps, 1f / Mathf.Max(.0001f, Time.unscaledDeltaTime), .05f); }
  string Slider(string n, ref float v, float y, float W, float H, int fs) {
    GUI.Label(new Rect(W * .3f, y, W * .2f, H * .05f), n, UIx.Label(fs, TextAnchor.MiddleLeft, Color.white));
    v = GUI.HorizontalSlider(new Rect(W * .5f, y + H * .015f, W * .2f, H * .04f), v, 0f, 1f); return null;
  }
  void OnGUI() {
    var m = MatchManager.I; if (m == null) return;
    float W = Screen.width, H = Screen.height, k = H / 540f; int fs = (int)(H / 32f); var S = Game.S; var pc = m.pc; var gun = pc.gun;
    GUI.skin.button.fontSize = fs; GUI.skin.horizontalSliderThumb.fixedHeight = H * .05f; GUI.skin.horizontalSliderThumb.fixedWidth = H * .05f;
    // atas: ronde/skor/timer
    string top = m.mode == Mode.Training ? "TRAINING GROUND" : "RONDE " + m.round + "   " + m.score[0] + " - " + m.score[1] + "   " + Mathf.CeilToInt(Mathf.Max(0, m.roundEndAt - Time.time)) + "s";
    UIx.Rect(new Rect(W / 2 - 170 * k, 6 * k, 340 * k, 30 * k), new Color(0, 0, 0, .45f)); GUI.Label(new Rect(W / 2 - 170 * k, 6 * k, 340 * k, 30 * k), top, UIx.Label(fs, TextAnchor.MiddleCenter, Color.white));
    if (m.mode != Mode.Training) { int a0 = 0, a1 = 0; foreach (var h in m.all) if (!h.dead) { if (h.team == 0) a0++; else a1++; } GUI.Label(new Rect(W / 2 - 170 * k, 38 * k, 340 * k, 24 * k), "Hidup: kamu " + a0 + "  lawan " + a1, UIx.Label(fs - 4, TextAnchor.MiddleCenter, Color.white)); }
    // minimap
    float ms = H * .26f; Rect mr = new Rect(8 * k, 8 * k, ms, ms); UIx.Rect(mr, new Color(0, 0, 0, .45f));
    foreach (var h in m.all) {
      if (h.dead) continue; bool me = h == m.pc.hp; if (!me && h.team != 0 && m.mode != Mode.Training && Vector3.Distance(h.transform.position, m.pc.transform.position) > 35f) continue;
      float px = mr.x + (h.transform.position.x / 70f + .5f) * ms, py = mr.y + (.5f - h.transform.position.z / 70f) * ms; float s = me ? 8 * k : 6 * k;
      UIx.Rect(new Rect(px - s / 2, py - s / 2, s, s), me ? Color.white : h.team == 0 ? Color.green : Color.red);
    }
    // kill feed
    float fy = 44 * k; for (int i = Mathf.Max(0, m.feed.Count - 5); i < m.feed.Count; i++) { if (Time.time - m.feed[i].Value > 6f) continue; GUI.Label(new Rect(W - 330 * k, fy, 260 * k, 22 * k), m.feed[i].Key, UIx.Label(fs - 4, TextAnchor.MiddleRight, Color.white)); fy += 22 * k; }
    // crosshair + hit marker
    float gap = 6 * k + gun.SpreadNow * 8 * k * (pc.Ads ? .5f : 1f), cx = W / 2, cy = H / 2, L = 8 * k, th = 2 * k; Color cc = new Color(1, 1, 1, .9f);
    UIx.Rect(new Rect(cx - gap - L, cy - th / 2, L, th), cc); UIx.Rect(new Rect(cx + gap, cy - th / 2, L, th), cc); UIx.Rect(new Rect(cx - th / 2, cy - gap - L, th, L), cc); UIx.Rect(new Rect(cx - th / 2, cy + gap, th, L), cc);
    if (Time.time - m.hitTime < .15f) GUI.Label(new Rect(cx - 30, cy - 30, 60, 60), "X", UIx.Label(fs * 2, TextAnchor.MiddleCenter, m.hitHead ? Color.red : Color.white));
    if (Time.time - m.dmgTime < .4f) UIx.Rect(new Rect(0, 0, W, H), new Color(1, 0, 0, .3f * (1 - (Time.time - m.dmgTime) / .4f)));
    // bawah: HP/armor/ammo
    float bw = 260 * k; UIx.Rect(new Rect(W / 2 - bw / 2, H - 38 * k, bw, 14 * k), new Color(0, 0, 0, .5f)); UIx.Rect(new Rect(W / 2 - bw / 2, H - 38 * k, bw * m.pc.hp.hp / m.pc.hp.max, 14 * k), new Color(.9f, .2f, .2f));
    if (m.pc.hp.armor > 0) UIx.Rect(new Rect(W / 2 - bw / 2, H - 52 * k, bw * m.pc.hp.armor / 100f, 8 * k), new Color(.3f, .6f, 1f));
    string ammo = gun.w.name + "  " + gun.mag + " / " + (gun.unlimited ? "INF" : gun.reserve.ToString()) + (gun.Reloading ? "  RELOAD" : "") + "   Medkit x" + pc.medkits;
    GUI.Label(new Rect(W / 2 - 250 * k, H - 70 * k, 500 * k, 26 * k), ammo, UIx.Label(fs, TextAnchor.MiddleCenter, Color.white));
    GUI.Label(new Rect(8 * k, H - 24 * k, 500 * k, 20 * k), "PROTOTYPE OFFLINE - bot lokal | Ping: -- (tidak ada server) | FPS " + Mathf.RoundToInt(fps), UIx.Label(fs - 6, TextAnchor.MiddleLeft, new Color(1, 1, 1, .7f)));
    if (m.inInter) GUI.Label(new Rect(0, H * .3f, W, 50 * k), m.resultText, UIx.Label(fs * 2, TextAnchor.MiddleCenter, Color.yellow));
    else if (m.pc.hp.dead && !m.over) GUI.Label(new Rect(0, H * .3f, W, 50 * k), "Tereliminasi - menunggu ronde selesai", UIx.Label(fs * 2, TextAnchor.MiddleCenter, Color.red));
    // pause
    if (!m.over && !Game.Paused && GUI.Button(new Rect(W - 64 * k, 8 * k, 56 * k, 32 * k), "II")) { Game.Paused = true; Time.timeScale = 0; }
    if (Game.Paused && !m.over) {
      UIx.Rect(new Rect(0, 0, W, H), new Color(0, 0, 0, .75f));
      GUI.Label(new Rect(0, H * .04f, W, H * .08f), "PAUSE (uji sensitivitas di sini)", UIx.Label(fs * 2, TextAnchor.MiddleCenter, Color.white));
      float y = H * .14f, dy = H * .06f;
      Slider("Kamera", ref S.general, y, W, H, fs); y += dy; Slider("ADS", ref S.ads, y, W, H, fs); y += dy; Slider("Red Dot", ref S.redDot, y, W, H, fs); y += dy; Slider("Sniper", ref S.sniper, y, W, H, fs); y += dy; Slider("Aim assist", ref S.aimAssistStrength, y, W, H, fs); y += dy;
      if (GUI.Button(new Rect(W * .3f, y, W * .4f, H * .08f), "Lanjutkan")) { Game.Paused = false; Time.timeScale = 1; Accounts.Save(); }
      if (GUI.Button(new Rect(W * .3f, y + H * .1f, W * .4f, H * .08f), "Keluar ke Lobby")) { m.Leave(); return; }
    }
    if (m.over) {
      UIx.Rect(new Rect(0, 0, W, H), new Color(0, 0, 0, .8f));
      GUI.Label(new Rect(0, H * .12f, W, H * .12f), m.won ? "MENANG" : "KALAH", UIx.Label(fs * 4, TextAnchor.MiddleCenter, m.won ? Color.green : Color.red));
      GUI.Label(new Rect(0, H * .35f, W, H * .3f), "Skor " + m.score[0] + " - " + m.score[1] + "\nKill " + m.kills + "   Death " + m.deaths + "\n+" + m.expGain + " EXP   +" + m.coinGain + " Coin (reward lokal)", new GUIStyle(UIx.Label(fs + 4, TextAnchor.UpperCenter, Color.white)) { wordWrap = true });
      if (GUI.Button(new Rect(W * .35f, H * .7f, W * .3f, H * .1f), "Kembali ke Lobby")) { m.Leave(); return; }
    }
  }
}
}
