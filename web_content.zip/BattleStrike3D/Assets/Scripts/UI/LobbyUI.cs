using UnityEngine;
namespace BattleStrike {
// Lobby IMGUI (cepat dibuat, bisa disentuh). Untuk rilis: ganti dengan uGUI/UI Toolkit + aset visual.
public class LobbyUI : MonoBehaviour {
  enum Page { Login, Home, Modes, Settings, Profile, Inventory, Info }
  Page page = Page.Login; string nick = "", pass = "", err = "", infoTitle = "", infoText = ""; int tab, tutPage; Vector2 scroll;
  void Start() { page = Accounts.Current != null ? Page.Home : Page.Login; }
  void Info(string t, string x) { infoTitle = t; infoText = x; page = Page.Info; }
  static readonly string NeedServer = "BELUM TERSEDIA di prototype ini.\n\nFitur ini butuh backend server (database akun, transaksi server-side, config event, penentuan hasil oleh server). Tanpa server, saldo/hasil hanya disimpan di HP dan mudah dimanipulasi, jadi sengaja tidak dibuat pura-pura jalan.\n\nArsitektur yang disiapkan: lihat README.md bagian 'Roadmap server'.";
  float Slider(string n, float v) {
    GUILayout.BeginHorizontal(); GUILayout.Label(n, GUILayout.Width(220)); v = GUILayout.HorizontalSlider(v, 0f, 1f, GUILayout.Width(300)); GUILayout.Label(Mathf.RoundToInt(v * 100) + "", GUILayout.Width(50)); GUILayout.EndHorizontal(); return v;
  }
  void OnGUI() {
    if (MatchManager.I != null) return;
    float sc = Screen.height / 540f; GUI.matrix = Matrix4x4.Scale(new Vector3(sc, sc, 1)); float W = Screen.width / sc, H = 540f;
    GUI.skin.button.fontSize = 22; GUI.skin.label.fontSize = 20; GUI.skin.textField.fontSize = 22; GUI.skin.toggle.fontSize = 20;
    GUI.skin.horizontalSlider.fixedHeight = 28; GUI.skin.horizontalSliderThumb.fixedHeight = 28; GUI.skin.horizontalSliderThumb.fixedWidth = 28;
    GUI.Label(new Rect(20, 8, 700, 40), "BATTLE STRIKE 3D", new GUIStyle(GUI.skin.label) { fontSize = 34, fontStyle = FontStyle.Bold });
    GUI.Label(new Rect(20, H - 28, 900, 26), "PROTOTYPE OFFLINE: akun & progres lokal, lawan = bot (bukan multiplayer online)", new GUIStyle(GUI.skin.label) { fontSize = 15 });
    var a = Accounts.Current;
    if (a == null) page = Page.Login; else if (page == Page.Login) page = Page.Home;
    GUILayout.BeginArea(new Rect(20, 56, W - 40, H - 90));
    switch (page) {
      case Page.Login: LoginPage(); break; case Page.Home: HomePage(a, W); break; case Page.Modes: ModesPage(); break;
      case Page.Settings: SettingsPage(a); break; case Page.Profile: ProfilePage(a); break; case Page.Inventory: InvPage(a); break;
      default: GUILayout.Label(infoTitle, new GUIStyle(GUI.skin.label) { fontSize = 28, fontStyle = FontStyle.Bold }); GUILayout.Label(infoText, new GUIStyle(GUI.skin.label) { wordWrap = true });
        if (GUILayout.Button("Kembali", GUILayout.Height(50), GUILayout.Width(200))) page = Page.Home; break;
    }
    GUILayout.EndArea();
    if (a != null && page == Page.Home && !a.tutorialDone) Tutorial(a, W, H);
  }
  void LoginPage() {
    GUILayout.Label("Login / Registrasi", new GUIStyle(GUI.skin.label) { fontSize = 26 });
    GUILayout.BeginHorizontal(); GUILayout.Label("Nickname", GUILayout.Width(150)); nick = GUILayout.TextField(nick, 16, GUILayout.Width(320)); GUILayout.EndHorizontal();
    GUILayout.BeginHorizontal(); GUILayout.Label("Password", GUILayout.Width(150)); pass = GUILayout.PasswordField(pass, '*', GUILayout.Width(320)); GUILayout.EndHorizontal();
    GUILayout.BeginHorizontal();
    if (GUILayout.Button("Login", GUILayout.Height(50), GUILayout.Width(150))) { string e; if (!Accounts.Login(nick, pass, out e)) err = e; else { err = ""; Game.ApplyGfx(); Game.ToLobby(); page = Page.Home; } }
    if (GUILayout.Button("Daftar", GUILayout.Height(50), GUILayout.Width(150))) { string e; if (!Accounts.Register(nick, pass, out e)) err = e; else { err = ""; Game.ApplyGfx(); Game.ToLobby(); page = Page.Home; } }
    if (GUILayout.Button("Main sebagai Guest", GUILayout.Height(50), GUILayout.Width(250))) { Accounts.Guest(); Game.ApplyGfx(); Game.ToLobby(); page = Page.Home; }
    GUILayout.EndHorizontal(); GUILayout.Label(err);
  }
  void HomePage(Account a, float W) {
    GUILayout.BeginHorizontal();
    GUILayout.BeginVertical(GUILayout.Width(300));
    GUILayout.Label(a.nickname + (a.guest ? " (Guest)" : "")); GUILayout.Label("ID: " + a.id + "   Lv " + a.level);
    var r = GUILayoutUtility.GetRect(280, 16); UIx.Rect(r, new Color(0, 0, 0, .5f)); UIx.Rect(new Rect(r.x, r.y, r.width * a.exp / a.ExpNeed, r.height), new Color(.3f, .8f, .4f));
    GUILayout.Label("EXP " + a.exp + "/" + a.ExpNeed); GUILayout.Label("Coin: " + a.coin + "     Diamond: " + a.diamond);
    if (!string.IsNullOrEmpty(Accounts.Notice)) GUILayout.Label(Accounts.Notice);
    GUILayout.EndVertical(); GUILayout.FlexibleSpace(); GUILayout.BeginVertical(GUILayout.Width(W * .5f));
    if (GUILayout.Button("PLAY", GUILayout.Height(80))) page = Page.Modes;
    GUILayout.BeginHorizontal();
    if (GUILayout.Button("Ranked", GUILayout.Height(50))) Info("Ranked", NeedServer + "\n\nPoin rank harus dihitung server agar anti-cheat.");
    if (GUILayout.Button("Clash Squad", GUILayout.Height(50))) Info("Clash Squad", "Belum dibuat. Sudah ada: Team Battle round-based vs bot (menu Play). Ekonomi ronde & beli senjata belum diimplementasi.");
    if (GUILayout.Button("Inventory", GUILayout.Height(50))) page = Page.Inventory;
    GUILayout.EndHorizontal(); GUILayout.BeginHorizontal();
    if (GUILayout.Button("Shop", GUILayout.Height(50))) Info("Shop", NeedServer + "\n\nTransaksi diamond wajib divalidasi server.");
    if (GUILayout.Button("Lucky Spin", GUILayout.Height(50))) Info("Lucky Spin", NeedServer + "\n\nHasil spin harus ditentukan server dengan peluang yang ditampilkan transparan.");
    if (GUILayout.Button("Pass", GUILayout.Height(50))) Info("Battle Pass", NeedServer);
    GUILayout.EndHorizontal(); GUILayout.BeginHorizontal();
    if (GUILayout.Button("Event", GUILayout.Height(50))) Info("Event", NeedServer + "\n\nSaat ini hanya Login Harian lokal (+100 coin/hari)." );
    if (GUILayout.Button("Friends", GUILayout.Height(50))) Info("Friends / Party", NeedServer);
    if (GUILayout.Button("Mail", GUILayout.Height(50))) Info("Mail", NeedServer);
    GUILayout.EndHorizontal(); GUILayout.BeginHorizontal();
    if (GUILayout.Button("Settings", GUILayout.Height(50))) page = Page.Settings;
    if (GUILayout.Button("Profile", GUILayout.Height(50))) page = Page.Profile;
    if (GUILayout.Button("Logout", GUILayout.Height(50))) { Accounts.Logout(); page = Page.Login; Game.ToLobby(); }
    GUILayout.EndHorizontal(); GUILayout.EndVertical(); GUILayout.EndHorizontal();
  }
  void ModesPage() {
    GUILayout.Label("Pilih mode (lawan bot lokal)", new GUIStyle(GUI.skin.label) { fontSize = 26 });
    if (GUILayout.Button("Training Ground (uji senjata, recoil, sensitivitas)", GUILayout.Height(55))) Game.StartMatch(Mode.Training);
    if (GUILayout.Button("1v1 Duel (best of 5 ronde)", GUILayout.Height(55))) Game.StartMatch(Mode.Duel);
    if (GUILayout.Button("2v2 Team Battle", GUILayout.Height(55))) Game.StartMatch(Mode.Team2);
    if (GUILayout.Button("3v3 Team Battle", GUILayout.Height(55))) Game.StartMatch(Mode.Team3);
    if (GUILayout.Button("4v4 Team Battle", GUILayout.Height(55))) Game.StartMatch(Mode.Team4);
    GUILayout.Label("Battle Royale, Quick Match online, room privat: belum tersedia (butuh server).");
    if (GUILayout.Button("Kembali", GUILayout.Height(45), GUILayout.Width(200))) page = Page.Home;
  }
  void InvPage(Account a) {
    GUILayout.Label("Loadout (ketuk slot untuk ganti senjata)", new GUIStyle(GUI.skin.label) { fontSize = 26 });
    GUILayout.BeginHorizontal();
    for (int i = 0; i < 3; i++) if (GUILayout.Button("Slot " + (i + 1) + ": " + WeaponData.All[a.loadout[i]].name, GUILayout.Height(60))) { a.loadout[i] = (a.loadout[i] + 1) % WeaponData.All.Length; Accounts.Save(); }
    GUILayout.EndHorizontal(); scroll = GUILayout.BeginScrollView(scroll, GUILayout.Height(250));
    foreach (var w in WeaponData.All) GUILayout.Label(w.name + " [" + w.type + "]  DMG " + w.damage + (w.pellets > 1 ? "x" + w.pellets : "") + "  RPS " + w.rps + "  Mag " + w.mag + "  Head x" + w.headMul + "  Range " + w.range + "m  Reload " + w.reload + "s");
    GUILayout.Label("Skin, emote, attachment: belum tersedia."); GUILayout.EndScrollView();
    if (GUILayout.Button("Kembali", GUILayout.Height(45), GUILayout.Width(200))) page = Page.Home;
  }
  void ProfilePage(Account a) {
    GUILayout.Label(a.nickname + "   ID " + a.id + "   Lv " + a.level, new GUIStyle(GUI.skin.label) { fontSize = 26 });
    GUILayout.Label("Match " + a.matches + "   Menang " + a.wins + "   Kill " + a.kills + "   Death " + a.deaths + "   K/D " + (a.deaths == 0 ? a.kills : Mathf.Round(100f * a.kills / a.deaths) / 100f));
    GUILayout.Label("Riwayat match:"); scroll = GUILayout.BeginScrollView(scroll, GUILayout.Height(220));
    foreach (var h in a.history) GUILayout.Label(h.date + "  " + h.mode + "  " + (h.won ? "MENANG" : "KALAH") + "  K/D " + h.kills + "/" + h.deaths + "  +" + h.exp + "xp +" + h.coin + "c");
    GUILayout.EndScrollView(); if (GUILayout.Button("Kembali", GUILayout.Height(45), GUILayout.Width(200))) page = Page.Home;
  }
  void SettingsPage(Account a) {
    var s = a.settings; GUILayout.BeginHorizontal(); string[] tabs = { "Grafis", "Sensitivitas", "Audio", "Kontrol/HUD" };
    for (int i = 0; i < 4; i++) if (GUILayout.Button(tabs[i], GUILayout.Height(45))) tab = i; GUILayout.EndHorizontal(); scroll = GUILayout.BeginScrollView(scroll, GUILayout.Height(300));
    if (tab == 0) {
      GUILayout.Label("Kualitas grafis"); s.quality = GUILayout.Toolbar(s.quality, new[] { "Low", "Medium", "High" }, GUILayout.Height(45));
      GUILayout.Label("FPS target"); int f = GUILayout.Toolbar(s.fps == 60 ? 1 : 0, new[] { "30", "60" }, GUILayout.Height(45)); s.fps = f == 1 ? 60 : 30;
      GUILayout.Label("Kualitas efek (tracer/flash)"); s.fx = GUILayout.Toolbar(s.fx, new[] { "Off", "Normal", "Tinggi" }, GUILayout.Height(45)); Game.ApplyGfx();
    } else if (tab == 1) {
      GUILayout.BeginHorizontal(); if (GUILayout.Button("Low")) s.Preset(0); if (GUILayout.Button("Medium")) s.Preset(1); if (GUILayout.Button("High")) s.Preset(2); if (GUILayout.Button("Reset default")) s.ResetSens(); GUILayout.EndHorizontal();
      s.general = Slider("General / Kamera", s.general); s.ads = Slider("ADS (pengali)", s.ads); s.redDot = Slider("Red Dot", s.redDot); s.scope2x = Slider("2x Scope", s.scope2x); s.scope4x = Slider("4x Scope", s.scope4x); s.sniper = Slider("Sniper Scope", s.sniper);
      s.freeLook = Slider("Free Look (belum dipakai)", s.freeLook); s.gyroOn = GUILayout.Toggle(s.gyroOn, "Gyroscope " + (SystemInfo.supportsGyroscope ? "" : "(tidak didukung perangkat)")); s.gyro = Slider("Gyro sensitivity", s.gyro); Game.ApplyGfx();
      GUILayout.Label("Uji di Training Ground, lalu buka Pause untuk menggeser slider.");
    } else if (tab == 2) {
      s.master = Slider("Master", s.master); s.music = Slider("Musik (belum ada musik)", s.music); s.sfx = Slider("Efek", s.sfx); s.voice = Slider("Voice chat (belum ada)", s.voice);
      s.monoAudio = GUILayout.Toggle(s.monoAudio, "Audio mono (matikan arah 3D)"); s.reduceLoud = GUILayout.Toggle(s.reduceLoud, "Kurangi suara keras"); Game.ApplyGfx();
      GUILayout.Label("Tes headphone: masuk Training, putar kamera; suara tembakan & langkah bot bersifat 3D stereo.");
    } else {
      s.hudScale = .6f + Slider("Ukuran tombol", (s.hudScale - .6f) / .8f) * .8f; s.hudOpacity = .2f + Slider("Transparansi tombol", (s.hudOpacity - .2f) / .8f) * .8f;
      s.holdAds = GUILayout.Toggle(s.holdAds, "ADS: tahan (nonaktif = ketuk toggle)"); s.autoReload = GUILayout.Toggle(s.autoReload, "Auto reload"); s.leftFire = GUILayout.Toggle(s.leftFire, "Tombol tembak kiri tambahan");
      s.aimAssist = GUILayout.Toggle(s.aimAssist, "Aim assist ringan"); s.aimAssistStrength = Slider("Kekuatan aim assist", s.aimAssistStrength * 2f) / 2f;
      GUILayout.Label("Memindahkan posisi tombol (drag HUD) belum diimplementasi.");
    }
    GUILayout.EndScrollView();
    if (GUILayout.Button("Simpan & Kembali", GUILayout.Height(45), GUILayout.Width(250))) { Accounts.Save(); page = Page.Home; }
  }
  void Tutorial(Account a, float W, float H) {
    string[] t = { "Selamat datang! Joystick KIRI untuk berjalan (dorong penuh = lari).", "Geser layar KANAN untuk membidik. Tombol FIRE bisa ditahan sambil digeser.", "ADS untuk zoom, RLD reload, SWAP ganti senjata, MED medkit, JUMP/DUCK lompat/jongkok.", "Mulai dari Training Ground, lalu coba 1v1 melawan bot. Menang 3 ronde untuk menang." };
    UIx.Rect(new Rect(0, 0, W, H), new Color(0, 0, 0, .8f)); GUI.Label(new Rect(60, 150, W - 120, 160), t[tutPage], new GUIStyle(GUI.skin.label) { fontSize = 28, wordWrap = true, alignment = TextAnchor.MiddleCenter });
    if (GUI.Button(new Rect(W / 2 - 100, 340, 200, 60), tutPage < 3 ? "Lanjut" : "Mengerti")) { if (tutPage < 3) tutPage++; else { a.tutorialDone = true; Accounts.Save(); } }
  }
}
}
