using UnityEngine;
namespace BattleStrike {
// Bot LOKAL: patrol -> engage (strafe, tembak dengan error) -> cover (HP rendah / magazen kosong). Berbagi alert dengan satu tim.
// Memakai CharacterController + raycast (tanpa NavMesh) agar jalan di scene prosedural. Bukan pemain online.
public class Bot : MonoBehaviour {
  public bool dummy; public float skill = .5f;
  enum St { Patrol, Engage, Cover } St st;
  Health hp, target; Gun gun; CharacterController cc; Vector3 lastSeen, wp, coverPos; float lastSeenT, nextThink, reactEnd, strafeUntil, coverUntil, wpUntil, vy; int strafeDir = 1; bool los;
  void Awake() { hp = GetComponent<Health>(); gun = GetComponent<Gun>(); cc = GetComponent<CharacterController>(); }
  public void Reset() { st = St.Patrol; target = null; wpUntil = 0; reactEnd = 0; vy = 0; }
  Vector3 Eye { get { return transform.position + Vector3.up * 1.5f; } }
  static Vector3 Chest(Health h) { return h.transform.position + Vector3.up * 1.2f; }
  static Vector3 Flat(Vector3 v) { v.y = 0; return v; }
  void Update() {
    if (hp.dead || Game.Paused || MatchManager.I == null || MatchManager.I.inputLocked) return;
    if (dummy) { Move(Vector3.zero, 0); return; }
    if (Time.time > nextThink) { nextThink = Time.time + .2f; Think(); }
    if (gun.mag == 0) gun.StartReload(); Act();
  }
  bool Sees(Health e) {
    Vector3 b = Chest(e), a = Eye, d = b - a; if (Vector3.Angle(transform.forward, Flat(d)) > 120f && d.magnitude > 8f) return false;
    RaycastHit h; if (Physics.Linecast(a, b, out h, ~0, QueryTriggerInteraction.Ignore)) { var hb = h.collider.GetComponent<Hitbox>(); return hb != null && hb.owner == e; }
    return true;
  }
  void Think() {
    var m = MatchManager.I; Health best = null; float bd = 45f; los = false;
    foreach (var e in m.all) { if (e.dead || e.team == hp.team) continue; float d = Vector3.Distance(e.transform.position, transform.position); if (d < bd && Sees(e)) { best = e; bd = d; } }
    if (best != null) {
      if (target != best || st == St.Patrol) reactEnd = Time.time + Mathf.Lerp(.9f, .3f, skill);
      target = best; los = true; lastSeen = best.transform.position; lastSeenT = Time.time; m.Alert(hp.team, lastSeen); if (st != St.Cover) st = St.Engage;
    } else if (st == St.Engage && Time.time - lastSeenT > 4f) { st = St.Patrol; target = null; }
    if (st == St.Engage && los && (hp.hp < hp.max * .35f || gun.mag == 0)) PickCover();
    if (st == St.Cover && Time.time > coverUntil) st = target != null ? St.Engage : St.Patrol;
  }
  void PickCover() {
    Transform best = null; float bd = 1e9f;
    foreach (var c in MatchManager.I.covers) { if (c == null) continue; float d = (c.position - transform.position).sqrMagnitude; if (d < bd) { bd = d; best = c; } }
    if (best == null) return;
    Vector3 away = Flat(best.position - target.transform.position).normalized; coverPos = best.position + away * (Mathf.Max(best.localScale.x, best.localScale.z) * .5f + 1f); coverPos.y = 0;
    st = St.Cover; coverUntil = Time.time + 3.5f;
  }
  void Act() {
    Vector3 mv = Vector3.zero; float spd = 0; var m = MatchManager.I;
    switch (st) {
      case St.Patrol:
        Vector3 ap; if (m.AlertFor(hp.team, out ap, transform.position)) wp = ap; else if (Time.time > wpUntil || Flat(wp - transform.position).magnitude < 2f) { wp = m.RandomPoint(); wpUntil = Time.time + 7f; }
        mv = Steer(wp); spd = 3.8f; Face(mv); break;
      case St.Engage:
        if (target == null || target.dead) { st = St.Patrol; break; }
        Vector3 to = Flat(target.transform.position - transform.position); float d = to.magnitude; Face(to);
        if (!los) { mv = Steer(lastSeen); spd = 4.5f; }
        else {
          if (d > 20f) { mv = to.normalized; spd = 4.5f; } else if (d < 7f) { mv = -to.normalized; spd = 3.5f; }
          else { if (Time.time > strafeUntil) { strafeDir = -strafeDir; strafeUntil = Time.time + Random.Range(1f, 2.5f); } mv = Vector3.Cross(Vector3.up, to.normalized) * strafeDir; spd = 3f; }
          mv = Avoid(mv); Shoot(d);
        }
        break;
      case St.Cover:
        mv = Steer(coverPos); spd = 5f; if (Flat(coverPos - transform.position).magnitude < 1f) { mv = Vector3.zero; gun.StartReload(); } if (target != null) Face(Flat(target.transform.position - transform.position)); else Face(mv); break;
    }
    Move(mv, spd);
  }
  void Shoot(float d) {
    if (Time.time < reactEnd || gun.Reloading || d > gun.w.range * .8f) return;
    Vector3 o = transform.position + Vector3.up * 1.35f, aim = Chest(target) + (Random.value < .15f * skill ? Vector3.up * .5f : Vector3.zero);
    float err = Mathf.Lerp(5f, 1.2f, skill) + d * .05f; Vector3 dir = Quaternion.Euler(Random.Range(-err, err), Random.Range(-err, err), 0) * (aim - o).normalized;
    Vector2 k; gun.TryFire(o, dir, false, out k);
  }
  Vector3 Steer(Vector3 p) { Vector3 d = Flat(p - transform.position); return d.magnitude < .5f ? Vector3.zero : Avoid(d.normalized); }
  Vector3 Avoid(Vector3 dir) {
    if (dir == Vector3.zero) return dir; RaycastHit h;
    if (Physics.SphereCast(transform.position + Vector3.up * .6f, .3f, dir, out h, 1.6f, ~0, QueryTriggerInteraction.Ignore) && h.collider.GetComponent<Hitbox>() == null)
      dir = Quaternion.Euler(0, 60f * (GetInstanceID() % 2 == 0 ? 1 : -1), 0) * dir;
    return dir;
  }
  void Face(Vector3 d) { d.y = 0; if (d.sqrMagnitude > .01f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(d), 8f * Time.deltaTime); }
  void Move(Vector3 mv, float spd) { if (cc.isGrounded && vy < 0) vy = -2f; vy -= 20f * Time.deltaTime; cc.Move((mv * spd + Vector3.up * vy) * Time.deltaTime); }
}
}
