using System.Collections.Generic; using UnityEngine;
namespace BattleStrike {
// Multi-touch berbasis fingerId: joystick kiri (floating), drag kanan untuk kamera, tombol melingkar.
// Jari yang menahan tombol FIRE juga bisa digeser untuk membidik (fire + aim satu jari).
public class TouchInput : MonoBehaviour {
  public static TouchInput I;
  public enum B { Fire, Ads, Jump, Crouch, Reload, Switch, Medkit, FireL }
  public Vector2 move, lookDelta; public bool fireHeld, fireDown, adsHeld, adsTap, jump, crouch, reload, sw, med;
  class Bt { public B id; public string label; public Vector2 c; public float r; public int finger = -1; }
  readonly List<Bt> bts = new List<Bt>(); int joyId = -1, lookId = -1; Vector2 joyO, joyP; float joyR;
  public static bool Visible { get { return MatchManager.I != null && !MatchManager.I.over && !Game.Paused; } }
  void Awake() { I = this; string[] l = { "FIRE", "ADS", "JUMP", "DUCK", "RLD", "SWAP", "MED", "FIRE" }; for (int i = 0; i < 8; i++) bts.Add(new Bt { id = (B)i, label = l[i] }); }
  Bt Get(B id) { return bts[(int)id]; }
  void Set(B id, float x, float y, float r) { var b = Get(id); b.c = new Vector2(x, y); b.r = r; }
  void Layout() {
    float W = Screen.width, H = Screen.height, u = H * .14f * Game.S.hudScale; joyR = u * 1.1f;
    Set(B.Fire, W - u * 1.7f, u * 1.5f, u * .85f); Set(B.Ads, W - u * 3.4f, u * 1.0f, u * .6f); Set(B.Jump, W - u * 1.2f, u * 3.3f, u * .6f);
    Set(B.Crouch, W - u * 2.9f, u * 2.9f, u * .55f); Set(B.Reload, W - u * 4.5f, u * 2.0f, u * .55f); Set(B.Switch, W - u * 4.7f, u * 3.5f, u * .5f);
    Set(B.Medkit, W - u * 6.2f, u * 1.2f, u * .5f); Set(B.FireL, u * 1.4f, u * 4.4f, u * .7f);
  }
  void Reset() { foreach (var b in bts) b.finger = -1; joyId = lookId = -1; move = Vector2.zero; fireHeld = adsHeld = false; }
  void Press(B id) {
    switch (id) { case B.Fire: case B.FireL: fireDown = true; break; case B.Ads: adsTap = true; break; case B.Jump: jump = true; break;
      case B.Crouch: crouch = true; break; case B.Reload: reload = true; break; case B.Switch: sw = true; break; case B.Medkit: med = true; break; }
  }
  void Update() {
    lookDelta = Vector2.zero; fireDown = jump = crouch = reload = sw = med = adsTap = false;
    if (!Visible) { Reset(); return; }
    Layout(); if (!Input.touchSupported) { Desktop(); return; }
    foreach (var t in Input.touches) {
      Vector2 p = t.position; int id = t.fingerId;
      if (t.phase == TouchPhase.Began) {
        Bt hit = null;
        foreach (var b in bts) { if (b.id == B.FireL && !Game.S.leftFire) continue; if (b.finger < 0 && (p - b.c).sqrMagnitude <= b.r * b.r) { hit = b; break; } }
        if (hit != null) { hit.finger = id; Press(hit.id); }
        else if (joyId < 0 && p.x < Screen.width * .4f && p.y < Screen.height * .75f) { joyId = id; joyO = joyP = p; }
        else if (lookId < 0 && p.x >= Screen.width * .35f) lookId = id;
      } else if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) {
        if (id == joyId) { joyId = -1; move = Vector2.zero; } if (id == lookId) lookId = -1;
        foreach (var b in bts) if (b.finger == id) b.finger = -1;
      } else {
        if (id == joyId) {
          joyP = p; Vector2 v = p - joyO; if (v.magnitude > joyR) { joyO = p - v.normalized * joyR; v = p - joyO; }
          Vector2 n = v / joyR; float m = n.magnitude; move = m < .12f ? Vector2.zero : n.normalized * Mathf.Clamp01((m - .12f) / .88f);   // dead zone 12%
        } else if (id == lookId) lookDelta += t.deltaPosition;
        else foreach (var b in bts) if (b.finger == id && (b.id == B.Fire || b.id == B.FireL)) lookDelta += t.deltaPosition;
      }
    }
    fireHeld = Get(B.Fire).finger >= 0 || Get(B.FireL).finger >= 0; adsHeld = Get(B.Ads).finger >= 0;
  }
  void Desktop() {   // fallback Editor/PC: WASD, RMB-drag look, LMB fire, F ads, Space, C, R, Q, H
    move = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")); if (move.magnitude > 1) move.Normalize();
    if (Input.GetMouseButton(1)) lookDelta = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * 12f;
    fireHeld = Input.GetMouseButton(0); fireDown = Input.GetMouseButtonDown(0); adsHeld = Input.GetKey(KeyCode.F); adsTap = Input.GetKeyDown(KeyCode.F);
    jump = Input.GetKeyDown(KeyCode.Space); crouch = Input.GetKeyDown(KeyCode.C); reload = Input.GetKeyDown(KeyCode.R); sw = Input.GetKeyDown(KeyCode.Q); med = Input.GetKeyDown(KeyCode.H);
  }
  void OnGUI() {
    if (!Visible || Event.current.type != EventType.Repaint || !Input.touchSupported) return;
    float a = Game.S.hudOpacity, H = Screen.height; var st = UIx.Label((int)(H * .03f), TextAnchor.MiddleCenter, Color.white);
    if (joyId >= 0) { UIx.Disc(joyO, joyR, new Color(1, 1, 1, a * .35f)); UIx.Disc(joyP, joyR * .45f, new Color(1, 1, 1, a)); }
    else UIx.Disc(new Vector2(H * .3f, H * .3f), joyR, new Color(1, 1, 1, a * .15f));
    foreach (var b in bts) {
      if (b.id == B.FireL && !Game.S.leftFire) continue;
      UIx.Disc(b.c, b.r, new Color(b.finger >= 0 ? 1f : .2f, b.id == B.Fire || b.id == B.FireL ? .3f : .2f, .2f, a * (b.finger >= 0 ? 1f : .6f)));
      GUI.Label(new Rect(b.c.x - b.r, H - b.c.y - b.r, b.r * 2, b.r * 2), b.label, st);
    }
  }
}
public static class UIx {
  static Texture2D white, circle; static System.Collections.Generic.Dictionary<int, GUIStyle> cache = new System.Collections.Generic.Dictionary<int, GUIStyle>();
  public static Texture2D White { get { if (white == null) { white = new Texture2D(1, 1); white.SetPixel(0, 0, Color.white); white.Apply(); } return white; } }
  public static Texture2D Circ {
    get {
      if (circle == null) {
        circle = new Texture2D(64, 64, TextureFormat.RGBA32, false);
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) { float d = Vector2.Distance(new Vector2(x, y), new Vector2(31.5f, 31.5f)); circle.SetPixel(x, y, new Color(1, 1, 1, Mathf.Clamp01(31f - d))); }
        circle.Apply();
      }
      return circle;
    }
  }
  public static void Rect(Rect r, Color c) { var o = GUI.color; GUI.color = c; GUI.DrawTexture(r, White); GUI.color = o; }
  // c dalam koordinat layar (origin kiri-bawah)
  public static void Disc(Vector2 c, float r, Color col) { var o = GUI.color; GUI.color = col; GUI.DrawTexture(new Rect(c.x - r, Screen.height - c.y - r, r * 2, r * 2), Circ); GUI.color = o; }
  public static GUIStyle Label(int size, TextAnchor a, Color col) {
    int k = size * 100 + (int)a * 10 + (col == Color.white ? 0 : 1) + (int)(col.r * 1000) * 100000; GUIStyle s;
    if (!cache.TryGetValue(k, out s)) { s = new GUIStyle(GUI.skin.label) { fontSize = size, alignment = a, fontStyle = FontStyle.Bold, wordWrap = false }; s.normal.textColor = col; cache[k] = s; }
    return s;
  }
}
}
