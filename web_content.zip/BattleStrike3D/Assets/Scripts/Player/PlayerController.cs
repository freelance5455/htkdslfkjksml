using UnityEngine;
namespace BattleStrike {
public class PlayerController : MonoBehaviour {
  public Health hp; public Gun gun; public float yaw, pitch = 10; public bool Ads, Crouching; public int medkits = 2, slot;
  CharacterController cc; Camera cam; float vy, medUntil; bool adsToggle; readonly WeaponData[] lo = new WeaponData[3]; readonly int[] mags = new int[3], res = new int[3];
  public void Setup(Camera c) {
    cam = c; cc = GetComponent<CharacterController>(); hp = GetComponent<Health>(); gun = GetComponent<Gun>();
    var acc = Accounts.Current; for (int i = 0; i < 3; i++) { lo[i] = WeaponData.All[Mathf.Clamp(acc.loadout[i], 0, WeaponData.All.Length - 1)]; mags[i] = lo[i].mag; res[i] = lo[i].reserve; }
    slot = 0; gun.Equip(lo[0], mags[0], res[0]);
  }
  public void RoundReset() {
    for (int i = 0; i < 3; i++) { mags[i] = lo[i].mag; res[i] = lo[i].reserve; } gun.Equip(lo[slot], mags[slot], res[slot]);
    medkits = 2; Ads = adsToggle = false; Crouching = false; CharacterFactory.SetCrouch(gameObject, false); vy = 0;
  }
  void Equip(int s) { mags[slot] = gun.mag; res[slot] = gun.reserve; slot = s; gun.Equip(lo[s], mags[s], res[s]); }
  float ScopeSens(Settings S) {
    switch (gun.w.scope) { case Scope.RedDot: return S.redDot; case Scope.X2: return S.scope2x; case Scope.X4: return S.scope4x; default: return S.sniper; }
  }
  float Assist(Settings S) {   // "friction" ringan: kamera melambat saat crosshair dekat musuh. Bukan auto-aim.
    if (!S.aimAssist) return 1f; var m = MatchManager.I;
    foreach (var e in m.all) {
      if (e.dead || e.team == hp.team) continue; Vector3 d = e.transform.position + Vector3.up * 1.2f - cam.transform.position;
      if (d.magnitude < 60f && Vector3.Angle(cam.transform.forward, d) < 4f) return 1f - Mathf.Clamp(S.aimAssistStrength, 0, .5f);
    }
    return 1f;
  }
  void Update() {
    if (hp.dead || Game.Paused || MatchManager.I.inputLocked) return;
    var t = TouchInput.I; var S = Game.S; float dt = Time.deltaTime;
    if (S.holdAds) Ads = t.adsHeld; else { if (t.adsTap) adsToggle = !adsToggle; Ads = adsToggle; }
    float sens = Ads ? ScopeSens(S) * (S.ads * 2f) : S.general;          // general = kamera, ads = pengali saat scope
    Vector2 look = t.lookDelta * (.05f + sens * .25f);
    if (S.gyroOn && SystemInfo.supportsGyroscope) { Vector3 g = Input.gyro.rotationRateUnbiased; look += new Vector2(-g.y, -g.x) * Mathf.Rad2Deg * dt * (S.gyro * 2f); }  // arah sumbu perlu dites di perangkat
    look *= Assist(S);
    yaw += look.x; pitch = Mathf.Clamp(pitch - look.y, -50f, 70f); transform.rotation = Quaternion.Euler(0, yaw, 0);
    Vector3 dir = transform.TransformDirection(new Vector3(t.move.x, 0, t.move.y));
    float spd = Crouching ? 2.5f : (t.move.magnitude > .92f ? 7f : 4.8f); if (Ads) spd *= .6f; if (gun.Reloading) spd *= .9f;
    if (cc.isGrounded && vy < 0) vy = -2f; if (cc.isGrounded && t.jump && !Crouching) vy = 6.5f; vy -= 20f * dt;
    cc.Move((dir * spd + Vector3.up * vy) * dt);
    if (t.crouch) { Crouching = !Crouching; CharacterFactory.SetCrouch(gameObject, Crouching); }
    if (t.reload || (S.autoReload && gun.mag == 0)) gun.StartReload();
    if (t.sw) Equip((slot + 1) % 3);
    if (t.med && medkits > 0 && hp.hp < hp.max && Time.time > medUntil) { medkits--; hp.Heal(50); medUntil = Time.time + 1.5f; }
    if (gun.w.auto ? t.fireHeld : t.fireDown) {
      Vector3 o = transform.position + Vector3.up * (Crouching ? .9f : 1.35f); var ct = cam.transform;
      Vector3 aim = Ballistics.Probe(ct.position + ct.forward * Vector3.Distance(ct.position, o), ct.forward, hp);
      Vector2 kick; if (gun.TryFire(o, (aim - o).normalized, Ads, out kick)) { yaw += kick.x; pitch -= kick.y; }
    }
  }
}
public class TPSCamera : MonoBehaviour {
  public PlayerController pc;
  void LateUpdate() {
    if (pc == null) return; var cam = Game.Cam; Vector3 pivot = pc.transform.position + Vector3.up * (pc.Crouching ? 1.2f : 1.6f);
    Quaternion r = Quaternion.Euler(pc.pitch, pc.yaw, 0); Vector3 off = r * new Vector3(pc.Ads ? .5f : .7f, 0, pc.Ads ? -1.6f : -3f); Vector3 want = pivot + off; Vector3 d = want - pivot; RaycastHit h;
    if (Physics.SphereCast(pivot, .2f, d.normalized, out h, d.magnitude)) want = pivot + d.normalized * Mathf.Max(.3f, h.distance - .1f);   // tabrakan kamera (player di layer Ignore Raycast)
    cam.transform.SetPositionAndRotation(want, r);
    cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, pc.Ads ? pc.gun.w.adsFov : 65f, 12f * Time.unscaledDeltaTime);
  }
}
}
