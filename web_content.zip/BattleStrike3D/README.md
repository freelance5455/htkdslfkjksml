# Battle Strike 3D  (vertical slice, Unity 2022.3 LTS, C#)

Semua nama, karakter, map, UI, dan suara di sini ORIGINAL (primitif + audio prosedural). Tidak ada aset Free Fire.
Nama senjata (R4 Carbine, Viper SMG, Scorpion SG, Longshot) hanya mewakili tipe gameplay.

## STATUS JUJUR
**Source ini BELUM dikompilasi atau dijalankan di Unity/HP** (tidak ada Unity di lingkungan pembuatnya).
Anggap sebagai kode awal: kemungkinan perlu memperbaiki beberapa error kompilasi kecil, lalu tes di perangkat.

### Sudah ditulis (belum teruji di perangkat)
- Akun lokal: register, login, logout, guest, hash PBKDF2, save JSON + HMAC, login harian lokal
- Profil: nickname, ID, level/EXP, statistik, riwayat match
- Lobby (karakter 3D berputar), tutorial 4 langkah, loadout 3 slot dari 4 senjata
- Kontrol touch multi-touch (joystick floating + dead zone, drag kamera, FIRE+drag satu jari), tombol: fire, ADS, jump, crouch, reload, swap, medkit, tembak kiri opsional
- Sensitivitas: general, ADS, Red Dot, 2x, 4x, Sniper, gyro, preset Low/Med/High, reset, tersimpan per akun, bisa digeser di menu Pause saat Training
- Senjata: damage falloff, fire rate, spread dinamis, recoil, headshot multiplier, pellet shotgun, magazen/ammo/reload
- Bot: patrol, deteksi LOS, engage + strafe, cover saat HP rendah/magazen kosong, berbagi alert satu tim
- Mode: Training Ground, 1v1, 2v2, 3v3, 4v4 (round-based, first to 3), HUD (HP/armor/ammo/minimap/kill feed/hit marker/skor/timer), hasil match + EXP/coin lokal
- Audio 3D prosedural (tembakan, reload, langkah, hit), slider volume, mono, kurangi suara keras
- Grafis Low/Med/High, FPS 30/60, kualitas efek, static batching, aim assist ringan

### BELUM ada / sengaja tidak dipalsukan
- **Semua yang butuh server**: multiplayer online, matchmaking, room/party/friends, Ranked + leaderboard, Shop & Diamond, Lucky Spin, Battle Pass, Event, Mail, voice chat, sinkronisasi akun. Tombolnya menampilkan keterangan "belum tersedia".
- Clash Squad (ekonomi ronde), Battle Royale + zona menyusut, granat, melee, knockdown, loot, skin/emote/attachment, free look, drag-ubah posisi tombol HUD, smoothing kamera
- Animasi skeletal (karakter = primitif), model/senjata final, musik, LOD, texture compression (belum ada tekstur), object pooling selain tracer/audio
- Reward lokal TIDAK aman (bisa dimanipulasi di HP). Anti-cheat nyata hanya mungkin dengan server.

## Struktur
```
Assets/Scripts/Core    Data, Accounts (auth+save), Game (bootstrap, grafis, material), Audio (Sfx, Fx)
Assets/Scripts/Combat  Weapons (data, Health, Ballistics, Gun), Character (factory)
Assets/Scripts/Player  TouchInput, PlayerController, TPSCamera
Assets/Scripts/AI      Bot
Assets/Scripts/Match   MatchManager (mode/ronde), ArenaBuilder (map prosedural)
Assets/Scripts/UI      LobbyUI, Hud
Assets/Editor          BuildTools (menu setup + build APK)
```
Game membangun semuanya lewat kode (`RuntimeInitializeOnLoadMethod`), jadi scene cukup kosong.

## Build APK
1. Unity Hub: install Unity 2022.3 LTS + modul Android Build Support (SDK, NDK, OpenJDK).
2. Buat project 3D (Built-in RP paling ringan; URP juga bisa), salin folder `Assets/` ke dalamnya.
3. Player Settings > Other Settings > Active Input Handling = *Input Manager (Old)* atau *Both*.
4. Menu **BattleStrike > Setup Project**, lalu **BattleStrike > Build APK** (hasil: `Builds/BattleStrike3D.apk`), atau Build Settings > Android > Build And Run.
5. Aktifkan USB debugging di HP, pasang APK.
Dependency: hanya modul bawaan Unity, tanpa paket pihak ketiga. Untuk Google Play pakai AAB.

## Cara menguji
Login Guest > Play > Training Ground. Cek: joystick, geser kamera, tembak sambil geser, ADS, reload, swap, headshot (X merah), recoil/spread antar senjata, Pause > geser sensitivitas. Lalu 1v1 melawan bot sampai layar hasil, keluar, cek EXP/riwayat di Profile, tutup-buka app untuk cek save.
Di Editor: WASD, tahan klik kanan untuk melihat, klik kiri tembak, F ADS, Space, C, R, Q, H.

## Roadmap server (urutan disarankan)
1. Auth API (REST, argon2/bcrypt, JWT, rate limit) + database (PostgreSQL) menggantikan `Accounts`.
2. Ekonomi server-side: ledger transaksi, shop, spin (RNG server, peluang dipublikasikan), pass, event dari config server.
3. Game server authoritative (mis. Unity Dedicated Server / Netcode for GameObjects / Mirror / Photon Fusion): `Ballistics.Shoot` dan `Health` pindah ke server, klien hanya kirim input.
4. Matchmaking + rank (Elo/MMR dihitung server), reconnect, region, ping.
