AMINO — THE EMPIRE | Prototype V1.0
===================================

Included
- index.html: responsive interactive prototype
- manifest.json: installable web app metadata
- sw.js: offline cache for the hosted PWA version

Features in this prototype
- Create an empire name, domain, and motto
- XP progression and ranks
- Daily-style missions (the current demo records completion locally)
- Badges and shareable legacy text
- Local saving in the browser on the same device

Important prototype notes
- This is not yet a signed Android APK.
- The current mission list is a starter set; tasks can be completed once in this first prototype.
- Data is stored locally in the browser and is not synced across devices.
- Sharing currently shares/copies a text legacy card, not a rendered image.
- The PWA offline cache works when served over HTTPS or localhost; opening index.html directly may not enable service workers.

Free route to an APK (technical steps)
1. Install Android Studio (free) on a computer.
2. Host this PWA over HTTPS or use a local development server.
3. Wrap it in a WebView/Capacitor Android project, then build a debug APK from Android Studio.
4. Test on your Android phone. A release APK for distribution should be signed and tested.
No paid service is required for local prototype building, but Google Play publishing has its own registration fee.
