AMINO — THE EMPIRE V1.1 (SHARING FIX)
Mobile-first offline prototype.

WHAT'S NEW
- More reliable share flow for Android WebView/APK wrappers.
- If the native Android share menu is unavailable, a fallback panel opens.
- Copy button tries Clipboard API and then document.execCommand('copy').
- If automatic copying is blocked, the text is selected so the user can long-press and copy it manually.

PRESERVING EXISTING DATA
- The app keeps the same localStorage key: aminoEmpireV1.
- This ZIP is a replacement build package; it does not change or delete your installed V1.0.
- To retain saved data after installing an APK update, the new APK must use the same package/application ID and be signed with the same signing key as the previous APK. Otherwise Android may treat it as a different app and the old local data may not carry over.
- Keep the installed V1.0 and do not uninstall it until the replacement APK is installed and tested.

BUILD
1. Upload this ZIP to the same HTML-to-APK builder you used for V1.0.
2. Keep the exact same app/package ID if the builder exposes that setting.
3. Build and download the replacement APK.
4. Install it as an update if Android allows it; do not uninstall V1.0 first.
5. Test sharing and confirm identity/XP/ranks are still present.

NOTE
This is a web-based prototype wrapped as an APK, not a native Android app. The share fallback provides copy-and-paste if Android's native share sheet is not available.
