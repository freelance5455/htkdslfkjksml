# My Payment Tracker — Android project

This Android Studio project wraps the existing payment tracker in an Android WebView.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When complete, use the **locate** link in Android Studio to find `app-debug.apk`.

For a signed release APK, use **Build > Generate Signed Bundle / APK**.

## Data and reminders
- The tracker stores records in the app's WebView local storage on this device.
- The current reminder feature is an in-app reminder checker. It does not guarantee background notifications when the app is closed.
- Export CSV is available inside the tracker.

## Included data
The app includes the user's supplied 15-month plan and 48 payment/savings entries.
