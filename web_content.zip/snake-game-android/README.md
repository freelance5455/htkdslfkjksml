# Snake – Android (Google Play) setup

This folder holds your game (`www/index.html`) ready to be wrapped as an Android app with Capacitor.
The file Google Play needs is an **.aab** (Android App Bundle), not an .apk.

## 1. Install the tools (once)
- Node.js (LTS): https://nodejs.org
- Android Studio: https://developer.android.com/studio (let it install the Android SDK)

## 2. Change the app ID
Open `capacitor.config.json` and change `appId` to your own, e.g. `com.yourname.snakegame`.
It must be unique, lowercase, and can never be changed after you publish.

## 3. Create the Android project
Open a terminal in this folder and run:

    npm install @capacitor/core @capacitor/cli @capacitor/android
    npx cap add android
    npx cap sync
    npx cap open android

Whenever you edit `www/index.html`, run `npx cap sync` again.

## 4. Check these in Android Studio
- Google Play requires new apps and updates to target Android 16 (API 36) from 31 Aug 2026.
  Open `android/variables.gradle` and make sure `compileSdkVersion` and `targetSdkVersion` are 36 or higher.
  (Newer Capacitor versions may already do this.)
- Lock portrait: in `android/app/src/main/AndroidManifest.xml`, add
  `android:screenOrientation="portrait"` to the `<activity ...>` tag.
- App icon: right-click `app` > New > Image Asset, and pick your icon.

## 5. Build the signed .aab
Android Studio: Build > Generate Signed App Bundle / APK > Android App Bundle.
- Create a new keystore and set a strong password.
- BACK UP THE KEYSTORE FILE AND PASSWORD. If you lose them you cannot update the app.
- Choose "release". The .aab appears in `android/app/release/`.
(Optional: to test on your phone first, use Build > Build APK(s) and install the APK. Do not upload the APK to Play.)

## 6. Google Play Console
1. Create a developer account (one-time $25 fee): https://play.google.com/console
2. Create app > fill in name, language, free/paid.
3. Complete: store listing (icon 512x512, feature graphic 1024x500, at least 2 phone screenshots), content rating questionnaire, data safety form, target audience, ads declaration (say the app contains ads), privacy policy URL.
4. New personal accounts must first run a closed test: at least 12 testers opted in for 14 continuous days, then apply for production access.
5. Upload the .aab to the closed testing track, invite testers, wait 14 days, then apply for production.

Privacy policy: see `PRIVACY_POLICY_TEMPLATE.md`. Host it on any public web page and paste its link in Play Console.

## 7. Real ads (AdMob)
`www/index.html` currently shows SAMPLE ads (a coloured box with a countdown, 30-60 s).
They are not real ads and earn nothing. For real ads:
1. Create an AdMob account (https://admob.google.com) and add your app.
2. Create a "Rewarded" ad unit (for Resume and the ad after each level).
3. Add an AdMob plugin for Capacitor (for example `@capacitor-community/admob`), follow its docs, and add your AdMob app ID to AndroidManifest.xml.
4. In `www/index.html`, find the function `showAd(n,total,done)` (comment: "ADS"). Replace its body with a call that shows the rewarded ad and calls `done()` when the ad has finished.
Notes:
- The ad network decides the length of each ad. You cannot force 30-60 seconds.
- If children are part of your audience, Google's Families policy applies: use only Google-certified ad networks and child-directed ad settings.
- Send me your plugin choice and ad unit IDs and I can write the exact `showAd` code.
