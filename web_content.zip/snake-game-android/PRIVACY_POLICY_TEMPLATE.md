# Privacy Policy – Snake

Last updated: [DATE]

[YOUR NAME / COMPANY] ("we") publishes the Snake game ("the app").

**Information we collect.** The app stores your best score on your device only. We do not ask for your name, email, or location.

**Advertising.** The app shows ads provided by [AD NETWORK, e.g. Google AdMob]. The ad provider may collect device identifiers and usage data to show and measure ads. See their privacy policy: [LINK].

**Children.** [Edit to match your audience. If children use the app, say that ads are set to be child-appropriate and that we do not knowingly collect personal data from children.]

**Contact.** [YOUR EMAIL]

We may update this policy. The latest version will always be at [POLICY URL].
