# Dots and Boxes - Android project

1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select this DotsAndBoxes folder. Wait for Gradle sync (needs internet the first time).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. When it finishes, click "locate". The file is app/build/outputs/apk/debug/app-debug.apk
5. Copy the APK to your phone and install it (allow "Install unknown apps" if asked).

The game lives in app/src/main/assets/index.html. Edit it to change the game.
Note: the Google Font link needs internet; offline the game falls back to the system font.
