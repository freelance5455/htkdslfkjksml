NO INTERNET GAMES - ANDROID PROJECT

This is an Android Studio project wrapping your existing offline HTML game collection in an Android WebView.
It includes index.html and all six games in app/src/main/assets.
No INTERNET permission is requested, and the games load from local app assets.

HOW TO BUILD AN APK (computer required)
1. Install Android Studio from the official Android Developers website.
2. Extract this ZIP file.
3. In Android Studio choose Open, then select the extracted NoInternetGames folder.
4. Wait for Gradle sync to finish. Internet may be needed once to download Android build tools.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When finished, click the notification's locate link. The APK is normally in app/build/outputs/apk/debug/app-debug.apk.
7. Transfer app-debug.apk to your Android phone and install it. If prompted, allow installing apps from that source.

IMPORTANT
- This ZIP is the Android Studio project, not a prebuilt APK.
- A compatible computer with Android Studio is required to compile the APK. This chat environment does not have Android SDK/Gradle installed to produce a verified APK directly.
- All games are bundled locally. The app itself does not request internet access.
