تطبيق جدول ساهر الأسبوعي

هذا مشروع Android Studio جاهز، ويحتوي على نسخة HTML/JavaScript التفاعلية داخل التطبيق.
لفتحه وبناء APK:
1) افتح المجلد في Android Studio.
2) انتظر Gradle Sync.
3) اختر Build > Build APK(s).
4) ستجد ملف APK داخل app/build/outputs/apk/.

البيانات تُحفظ محليًا داخل التطبيق عبر localStorage.
لا يحتاج التطبيق إلى الإنترنت.
