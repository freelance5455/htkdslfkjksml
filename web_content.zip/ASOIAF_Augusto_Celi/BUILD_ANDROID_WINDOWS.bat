@echo off
setlocal
cd /d "%~dp0"
echo === GUIA DE AUGUSTO PARA CELI - BUILD ANDROID ===
where node >nul 2>nul || (echo Falta instalar Node.js LTS. & pause & exit /b 1)
where npm >nul 2>nul || (echo No se encontro npm. Reinstala Node.js LTS. & pause & exit /b 1)
call npm install || (echo Error instalando dependencias. & pause & exit /b 1)
if not exist android\app call npx cap add android
call npx cap sync android || (echo Error sincronizando Android. & pause & exit /b 1)
call npx cap open android
pause
