package com.bilalriderhisab.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.database.Cursor;
import android.content.ContentResolver;
import android.content.Context;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.WebChromeClient.FileChooserParams;

import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 701;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(7,7,7));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(7,7,7));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        webView.addJavascriptInterface(new AppBridge(this, webView), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if (scheme.equals("https") || scheme.equals("http") || scheme.equals("mailto") || scheme.equals("tel")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "Is link ko kholne ke liye app nahi mili.", Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception e) { filePathCallback = null; return false; }
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (ActivityNotFoundException e) { filePathCallback = null; Toast.makeText(MainActivity.this, "File picker nahi mil saka.", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
            @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                WebView popup = new WebView(MainActivity.this);
                popup.getSettings().setJavaScriptEnabled(true);
                popup.getSettings().setDomStorageEnabled(true);
                popup.addJavascriptInterface(new AppBridge(MainActivity.this, popup), "AndroidBridge");
                popup.setWebViewClient(new WebViewClient());
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) result = new Uri[]{uri};
                else if (data.getClipData() != null && data.getClipData().getItemCount() > 0)
                    result = new Uri[]{data.getClipData().getItemAt(0).getUri()};
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public static class AppBridge {
        private final Activity activity;
        private final WebView targetWebView;
        AppBridge(Activity activity, WebView targetWebView) { this.activity = activity; this.targetWebView = targetWebView; }

        @JavascriptInterface public void saveDataUrl(String dataUrl, String filename, String mime) {
            activity.runOnUiThread(() -> saveData(dataUrl, filename, mime, false));
        }
        @JavascriptInterface public void shareDataUrl(String dataUrl, String filename, String mime) {
            activity.runOnUiThread(() -> saveData(dataUrl, filename, mime, true));
        }
        @JavascriptInterface public void printCurrentPage() {
            activity.runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                    String jobName = "Bilal-Rider-Hisab";
                    pm.print(jobName, targetWebView.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build());
                } catch (Exception e) { Toast.makeText(activity, "Print/PDF shuru nahi ho saka.", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void openExternal(String url) {
            activity.runOnUiThread(() -> {
                try { activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception e) { Toast.makeText(activity, "Link open nahi ho saka.", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void printHtml(String html) {
            activity.runOnUiThread(() -> {
                WebView printView = new WebView(activity);
                printView.getSettings().setJavaScriptEnabled(true);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        try {
                            PrintManager pm = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                            pm.print("Bilal-Rider-Hisab-Receipt", view.createPrintDocumentAdapter("Bilal-Rider-Hisab-Receipt"), new PrintAttributes.Builder().build());
                        } catch (Exception e) { Toast.makeText(activity, "Receipt PDF shuru nahi ho saka.", Toast.LENGTH_LONG).show(); }
                    }
                });
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
        private void saveData(String dataUrl, String filename, String mime, boolean share) {
            try {
                String encoded = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                String safeName = filename == null || filename.trim().isEmpty() ? "Bilal-Rider-Hisab-file" : filename.replaceAll("[/\\\\]", "_");
                String type = mime == null || mime.isEmpty() ? "application/octet-stream" : mime;
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, type);
                if (type.startsWith("image/")) values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Bilal Rider Hisab");
                else values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Bilal Rider Hisab");
                ContentResolver resolver = activity.getContentResolver();
                Uri collection = type.startsWith("image/") ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                Uri uri = resolver.insert(collection, values);
                if (uri == null) throw new IOException("File create nahi ho saki");
                try (OutputStream out = resolver.openOutputStream(uri)) { if (out == null) throw new IOException("File write nahi hui"); out.write(bytes); }
                if (share) {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(type);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    activity.startActivity(Intent.createChooser(send, "Bill share karein"));
                } else {
                    Toast.makeText(activity, "File save ho gayi: " + safeName, Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(activity, "File save/share nahi ho saki: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
