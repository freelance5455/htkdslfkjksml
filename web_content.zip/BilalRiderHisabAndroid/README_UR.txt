Bilal Rider Hisab — Android App Project
======================================

Yeh Android Studio project aap ke existing black + metallic-gold Bilal Rider Hisab HTML software ko Android WebView app mein pack karta hai.

Is project mein:
- App name: Bilal Rider Hisab
- Black + metallic-gold existing interface
- Existing HTML app, login screen, accounts, transactions, qarz aur saved bills
- Android local browser storage (app data clear/uninstall na karein warna local records mit sakte hain)
- Bill PNG ko Android ke native save/share system se Pictures/Bilal Rider Hisab mein save karna aur WhatsApp/share menu par bhejna
- Reports ki tasveer (PNG) save/share: aaj, pichlay 2 din, pichlay 3 din, hafta, mahina ya custom dates
- CSV aur JSON backup Android ke Downloads/Bilal Rider Hisab mein save karna
- Backup restore ke liye file picker
- Print dialog se PDF save/print integration

ZAROORI:
- Yeh Android Studio source project hai, ready-to-install APK nahin.
- Is environment mein Android SDK/Gradle build available nahin tha, is liye APK compile ya device par test nahin ki gayi.
- Android Studio wala computer chahiye: ZIP extract karein, Android Studio mein folder `BilalRiderHisabAndroid` open karein, Gradle sync hone dein, phir Build > Build APK(s) karein.
- APK aam tor par app/build/outputs/apk/debug/app-debug.apk mein banegi.
- APK install karne se pehle purane HTML software ka JSON Backup bana kar safe jagah rakhein. WebView app ka storage purane Chrome HTML file ke localStorage se alag hota hai; records automatically transfer nahin honge. Backup restore se data la sakte hain.
- Login code local browser/app lock hai; yeh full device-level encryption nahin.

NAYI TABDEELIYAN:
- Bill picture save/share Android native MediaStore aur Android Share Sheet se hoti hai.
- Reports mein Hisaab ki Tasveer Save aur Tasveer WhatsApp Share buttons shamil hain.
- 2 din aur 3 din ke reports select karke unka summary aur transaction list PNG mein export ki ja sakti hai (tasveer mein aakhri 45 entries tak).
- CSV aur JSON backup ko bhi native Android save function par bheja gaya hai.
