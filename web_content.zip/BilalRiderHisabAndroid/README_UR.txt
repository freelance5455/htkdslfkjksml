Bilal Rider Hisab — Android App Project
======================================

Yeh Android Studio project aap ke existing black + metallic-gold Bilal Rider Hisab HTML software ko Android WebView app mein pack karta hai.

Is project mein:
- App name: Bilal Rider Hisab
- Black + metallic-gold existing interface
- Existing HTML app, login screen, accounts, transactions, qarz aur saved bills
- Android local browser storage (app data clear/uninstall na karein warna local records mit sakte hain)
- Bill PNG ko Android share menu se WhatsApp par bhejne ki integration
- Picture/CSV/JSON backup ko device mein save karne ki integration
- Backup restore ke liye file picker
- Print dialog se PDF save/print integration

ZAROORI:
- Yeh Android Studio source project hai, ready-to-install APK nahin.
- Is environment mein Android SDK/Gradle build available nahin tha, is liye APK compile ya device par test nahin ki gayi.
- Android Studio wala computer chahiye: ZIP extract karein, Android Studio mein folder `BilalRiderHisabAndroid` open karein, Gradle sync hone dein, phir Build > Build APK(s) karein.
- APK aam tor par app/build/outputs/apk/debug/app-debug.apk mein banegi.
- APK install karne se pehle purane HTML software ka JSON Backup bana kar safe jagah rakhein. WebView app ka storage purane Chrome HTML file ke localStorage se alag hota hai; records automatically transfer nahin honge. Backup restore se data la sakte hain.
- Login code local browser/app lock hai; yeh full device-level encryption nahin.
