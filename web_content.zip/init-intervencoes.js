createCatalog('3', DATA_NIC, {
  unit: 'intervenção(ões)',
  unitCap: 'Intervenções',
  sourceLabel: 'NIC — Nursing Interventions Classification'
});
