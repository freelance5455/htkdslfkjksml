KOR Overseas Employment Institute – Android Project

ይህ ፋይል የAndroid Studio ፕሮጀክት ነው፤ APK ፋይል አይደለም።

APK ለመስራት:
1. ZIP ፋይሉን Extract ያድርጉ።
2. Android Studio ይክፈቱ።
3. Open በመጫን "KOR_Overseas_Employment_Android" ፎልደርን ይምረጡ።
4. Gradle Sync እስኪጨርስ ይጠብቁ።
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ይምረጡ።
6. APK በ app/build/outputs/apk/debug/app-debug.apk ይገኛል።

ማስታወሻ:
- የመጀመሪያው HTML ዳሽቦርድ እና ዋና ተግባራቱ ተጠብቀዋል።
- የተማሪ መረጃ localStorage ውስጥ በዚያው ስልክ ይቀመጣል።
- አንዳንድ ውጫዊ ላይብረሪዎች (Tailwind, Excel, icons) ለመጫን ኢንተርኔት ይፈልጋሉ።
- ካሜራ ሲጠቀሙ የCamera permission ይፍቀዱ።
- ይህ የምንጭ ፕሮጀክት ነው፤ በቀጥታ ስልክ ላይ ለመጫን APK መገንባት ያስፈልጋል።
