DUITKU - PROYEK APLIKASI ANDROID

Isi:
- Aplikasi Android sederhana bernama DuitKu.
- UI bahasa Indonesia dengan tema terang.
- Pemasukan, pengeluaran, tabungan, investasi.
- Ringkasan per bulan, anggaran pengeluaran, riwayat, ekspor CSV.
- Data disimpan lokal di perangkat melalui localStorage.

CARA MEMBANGUN APK:
1. Install Android Studio versi terbaru di komputer.
2. Ekstrak folder DuitKu_Android_Project.
3. Android Studio > Open > pilih folder DuitKu_Android_Project.
4. Tunggu Gradle sync selesai (perlu internet untuk mengunduh plugin Android Gradle).
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik Locate pada notifikasi build untuk menemukan app-debug.apk.
7. Kirim APK ke HP Android dan buka untuk memasang. Android mungkin meminta izin "Install unknown apps".

Catatan:
- Proyek ini adalah source project Android Studio, bukan APK yang sudah dikompilasi.
- Butuh Android Studio/Android SDK untuk menghasilkan APK.
- Data transaksi tersimpan di perangkat dan tidak otomatis tersinkron ke HP lain.
- Sebaiknya ekspor CSV secara berkala sebagai cadangan.
