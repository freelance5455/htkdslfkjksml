package net.eduspace.advertising;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.*;
import android.view.HapticFeedbackConstants;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.Manifest;
import android.content.pm.PackageManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.view.View;

public class MainActivity extends Activity {
    WebView web;
    private static final String CHANNEL = "eduspace_updates";
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,15,32));
        getWindow().setNavigationBarColor(Color.rgb(8,15,32));
        createNotificationChannel();
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,15,32));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setHapticFeedbackEnabled(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean dialog, boolean userGesture, android.os.Message resultMsg) {
                WebView.HitTestResult hit = view.getHitTestResult();
                String url = hit == null ? null : hit.getExtra();
                if (url != null) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
                }
                return false;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost() == null ? "" : u.getHost().toLowerCase();
                if (host.equals("eduspaceadvertising.netlify.app") || host.equals("script.google.com") ||
                    host.endsWith(".google.com") || host.equals("wa.me") || host.equals("api.whatsapp.com")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("(function(){document.addEventListener('click',function(e){var t=e.target.closest('button,a,[role=button]');if(t&&window.AndroidHaptics){window.AndroidHaptics.tap();}},true);})();", null);
            }
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void tap() { runOnUiThread(() -> web.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)); }
            @JavascriptInterface public void notifyUser(String title, String message) {
                runOnUiThread(() -> showNotification(title, message));
            }
        }, "AndroidHaptics");
        setContentView(web);
        // Prefer the live hosted site so accounts and QR scans use the same online backend.
        web.loadUrl("https://eduspaceadvertising.netlify.app/");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2026);
    }
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "EduSpace updates", NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("Campaign and lead notifications");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    private void showNotification(String title, String message) {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title == null ? "EduSpace Advertising" : title)
         .setContentText(message == null ? "You have an update." : message).setAutoCancel(true);
        nm.notify((int)System.currentTimeMillis(), b.build());
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}