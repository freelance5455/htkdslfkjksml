# EduSpace Advertising Android app project

This Android Studio project wraps the live site at https://eduspaceadvertising.netlify.app/ so the app shares the deployed site's account/backend data rather than using a separate offline-only database.

Included source pages from the upload: index.html, admin.html, client.html, distributor.html, track.html.
QR tracking target: https://eduspaceadvertising.netlify.app/track?q=QR_ID&c=CLIENT_ID
Native additions: vibration/haptic feedback on taps and a notification bridge/channel.

## Build an APK
1. Open this folder in Android Studio (current stable version).
2. Let Gradle sync and install the Android SDK platform 35 if requested.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find the debug APK at app/build/outputs/apk/debug/app-debug.apk.

## Important verification notes
- This project source does not prove that the live Netlify deploy or Google Apps Script backend is healthy.
- Web pages currently contain their own login/backend logic. Push notifications for new leads need server-side event delivery (e.g. Firebase Cloud Messaging) and backend credentials; this wrapper's notification bridge alone cannot detect new leads while the app is closed.
- Please test admin login, QR generation, scan logging, WhatsApp OTP, lead submission and redirect with a test QR before production use.
