// Run: node tests/mode_routing_test.js   (reads ../index.html, tests pure routing code + ask() with a fake AI)
const fs=require("fs"),path=require("path"),assert=require("assert");
const src=fs.readFileSync(path.join(__dirname,"..","index.html"),"utf8");
const js=src.match(/<script>([\s\S]*)<\/script>/)[1];
const a=js.indexOf("const RULES="),b=js.indexOf("/* ---- end modes ---- */");
const askAt=js.indexOf("function ask(signal,onText)"),askEnd=js.indexOf("\n",askAt);
assert(a>0&&b>a&&askAt>b,"markers not found");
const block=js.slice(a,askEnd).replace(/\bhist\b/g,"getHist()");
let calls=[],stText="",hist=[];const cfg={mode:"adaptive"};
const $=()=>({set textContent(v){stText=v}});
const AI=(turns,opts)=>{calls.push({turns,opts});return Promise.resolve({text:"ok",truncated:false})};
const L=new Function("$","cfg","getHist","AI",block+";return {ask,pickStrategy,planRequest,MODE_TEXT,RULES}")($,cfg,()=>hist,AI);
let pass=0,fail=0;const T=(n,f)=>{try{f();pass++;console.log("PASS",n)}catch(e){fail++;console.log("FAIL",n,"-",e.message)}};
const U=c=>({role:"user",content:c}),A=c=>({role:"assistant",content:c});
// --- heuristic (expected labels are my intent; the heuristic is rough by design)
[["What is the capital of France?","fast"],["What is 12*13?","fast"],["What is 15% of 80?","fast"],["Explain photosynthesis briefly","fast"],
 ["Prove that the square root of 2 is irrational","deep"],["Solve 2x^2 - 5x + 3 = 0 step by step","deep"],
 ["Debug this: TypeError, here is the traceback","deep"],["Integrate x*sin(x) dx","deep"],["```js\nfoo()\n``` why does this fail?","deep"]]
 .forEach(([m,e])=>T("adaptive picks "+e+": "+JSON.stringify(m.slice(0,38)),()=>assert.strictEqual(L.pickStrategy(m).strategy,e)));
T("known weak spot: 'Compare REST and GraphQL in detail' scores only 1 -> fast",()=>assert.strictEqual(L.pickStrategy("Compare REST and GraphQL in detail").strategy,"fast"));
// --- planRequest
const h3=[U("hi"),A("hello"),U("What is the capital of France?")];
T("fast mode -> FAST text only",()=>{const p=L.planRequest("fast",h3);assert(p.turns[0].content.includes("FAST")&&!p.turns[0].content.includes("DEEP REASONING"))});
T("deep mode -> DEEP text only",()=>{const p=L.planRequest("deep",h3);assert(p.turns[0].content.includes("DEEP REASONING")&&!p.turns[0].content.includes("FAST"))});
T("base RULES kept in every mode",()=>["fast","deep","adaptive"].forEach(m=>assert(L.planRequest(m,h3).turns[0].content.startsWith(L.RULES))));
T("unknown/stale mode falls back to adaptive",()=>assert.strictEqual(L.planRequest("turbo",h3).mode,"adaptive"));
T("history preserved after leading rules turn",()=>{const p=L.planRequest("deep",h3);assert.deepStrictEqual(p.turns.slice(1),h3)});
T("long history: last 19 turns, starts and ends on user",()=>{const h=[];for(let i=0;i<20;i++)h.push(U("q"+i),A("a"+i));h.push(U("last"));const p=L.planRequest("fast",h);assert.strictEqual(p.turns.length,20);assert.strictEqual(p.turns[1].role,"user");assert.strictEqual(p.turns.at(-1).role,"user");assert.deepStrictEqual(p.turns.slice(1),h.slice(-19));assert.strictEqual(h.length,41)});
T("input history not mutated",()=>{const c=JSON.stringify(h3);L.planRequest("deep",h3);assert.strictEqual(JSON.stringify(h3),c)});
// --- ask() integration with fake AI
(async()=>{
  const ctl=new AbortController(),cb=()=>{};
  cfg.mode="fast";hist=[U("hi")];await L.ask(ctl.signal,cb);
  T("ask(): fast mode reaches request + options intact",()=>{const c=calls.at(-1);assert(c.turns[0].content.includes("FAST"));assert.strictEqual(c.opts.cache,false);assert.strictEqual(c.opts.signal,ctl.signal);assert.strictEqual(c.opts.onText,cb);assert(/Fast instructions/.test(stText))});
  cfg.mode="deep";await L.ask(ctl.signal,cb);
  T("ask(): deep mode reaches request",()=>{assert(calls.at(-1).turns[0].content.includes("DEEP REASONING"));assert(/Deep instructions/.test(stText))});
  cfg.mode="adaptive";hist=[U("Prove that the square root of 2 is irrational")];await L.ask(ctl.signal,cb);
  T("ask(): adaptive -> Deep for a proof",()=>{assert(calls.at(-1).turns[0].content.includes("DEEP REASONING"));assert(/Adaptive → Deep/.test(stText))});
  hist=[U("Prove that the square root of 2 is irrational"),A("..."),U("Thanks! What is the capital of France?")];await L.ask(ctl.signal,cb);
  T("ask(): adaptive recalculated per request -> Fast on next message",()=>{const c=calls.at(-1);assert(c.turns[0].content.includes("FAST"));assert(/Adaptive → Fast/.test(stText));assert.strictEqual(c.turns.length,4)});
  // --- source presence checks (NOT behaviour tests)
  const has=(n,s)=>T("source has "+n,()=>assert(js.includes(s)||src.includes(s)));
  has('claude.use("sample")','claude.use("sample")');has("150 s timeout","150000");has("hist.pop() on failure","hist.pop()");has("Cancelled message",'"Cancelled."');has("ERR table","const ERR=");has("SpeechRecognition","webkitSpeechRecognition");has("speechSynthesis","speechSynthesis.speak");has("Stop handler",'$("bStop").onclick');
  T("no fetch() and no http(s) URLs in script",()=>assert(!/fetch\(|https?:\/\//.test(js)));
  T("mode select values match code",()=>["adaptive","fast","deep"].forEach(v=>assert(src.includes('<option value="'+v+'">'))));
  console.log("\n"+pass+" passed, "+fail+" failed");process.exit(fail?1:0);
})();
