// node mic_error_test.js : tests mic diagnosis + "never re-request once blocked" with fake SpeechRecognition/window/navigator.
const fs=require("fs"),assert=require("assert");
const src=fs.readFileSync(__dirname+"/../index.html","utf8"),js=src.match(/<script>([\s\S]*)<\/script>/)[1];
const block=js.slice(js.indexOf("/* ---- Microphone diagnostics"),js.indexOf('$("bMic").onclick='));
function make({sr=true,framed=true,policy=null,perm=null,secure=true,err="not-allowed"}={}){
  const W={},T=framed?{}:W;let made=0;const failed=[],notes=[];
  const env={window:{self:W,top:T,isSecureContext:secure},
    document:policy===null?{}:{permissionsPolicy:{allowsFeature:()=>policy}},
    navigator:{language:"en-US",permissions:perm?{query:async()=>({state:perm})}:undefined},
    SR:sr?class{constructor(){made++}start(){setTimeout(()=>{this.onerror&&this.onerror({error:err});this.onend&&this.onend()},0)}abort(){}stop(){}}:undefined,
    fail:m=>failed.push(m),add:(c,t)=>notes.push(t),send:()=>{},setState:()=>{}};
  const api=new Function("env",`const {window,document,navigator,SR,fail,add,send,setState}=env;
    let voiceMode=true,busy=false,rec=null,quiet=0,state="idle",errs=[],AI=null;const B={bMic:{},bVoice:{},txt:{value:""}};const $=i=>B[i];const syncV=()=>{};
    ${block};return {listen,initMic,micDiag,micWhy,blockMic,S:()=>({micBlocked,voiceMode,micMsg,errs,B})}`)(env);
  return {api,made:()=>made,failed,notes};
}
let p=0,f=0;const T=async(n,fn)=>{try{await fn();p++;console.log("PASS",n)}catch(e){f++;console.log("FAIL",n,"-",e.message)}};
const why=async(o,code)=>{const m=make(o);return m.api.micWhy(code,await m.api.micDiag())};
(async()=>{
 await T("API missing -> says no speech-recognition API",async()=>assert(/no speech-recognition API/.test(await why({sr:false},"not-allowed"))));
 await T("frame policy false -> blocked by embedding page",async()=>assert(/embeds QUANTUM/.test(await why({policy:false},"not-allowed"))));
 await T("permission state denied -> denied message",async()=>assert(/reports microphone access as denied/.test(await why({perm:"denied"},"not-allowed"))));
 await T("service-not-allowed -> speech service refused",async()=>assert(/speech service/.test(await why({policy:true,perm:"prompt"},"service-not-allowed"))));
 await T("framed + unknown -> admits it cannot tell which",async()=>assert(/can’t tell which/.test(await why({policy:null,perm:"prompt"},"not-allowed"))));
 await T("not framed -> plain permission denied",async()=>assert(/site settings, then reload/.test(await why({framed:false,perm:"prompt"},"not-allowed"))));
 await T("audio-capture -> no usable microphone",async()=>assert(/No usable microphone/.test(await why({},"audio-capture"))));
 await T("not-allowed blocks once; second listen() makes NO new request",async()=>{
   const m=make({policy:null,perm:"prompt"});m.api.listen();await new Promise(r=>setTimeout(r,30));
   const s=m.api.S();assert.strictEqual(m.made(),1);assert(s.micBlocked&&s.B.bMic.disabled&&s.B.bVoice.disabled&&!s.voiceMode);
   assert.strictEqual(m.failed.length,1);assert(/Text input still works/.test(m.failed[0]));assert(s.errs.some(e=>/mic diag/.test(e)));
   m.api.listen();m.api.listen();await new Promise(r=>setTimeout(r,30));assert.strictEqual(m.made(),1)});
 await T("no-speech does NOT block the mic",async()=>{const m=make({err:"no-speech"});m.api.listen();await new Promise(r=>setTimeout(r,30));assert(!m.api.S().micBlocked)});
 await T("preflight: policy false blocks WITHOUT any SpeechRecognition request",async()=>{const m=make({policy:false});await m.api.initMic();assert.strictEqual(m.made(),0);assert(m.api.S().micBlocked);assert(/Text input still works/.test(m.notes[0]))});
 await T("preflight: API missing blocks without request",async()=>{const m=make({sr:false});await m.api.initMic();assert(m.api.S().micBlocked)});
 await T("preflight: unknown state does NOT block (first click may try once)",async()=>{const m=make({policy:null,perm:"prompt"});await m.api.initMic();assert(!m.api.S().micBlocked)});
 console.log("\n"+p+" passed, "+f+" failed");process.exit(f?1:0)})();
