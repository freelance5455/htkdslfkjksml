# QUANTUM AI - source export v3 (reasoning-mode routing + microphone diagnostics)

Exported from the published claude.ai Artifact "QUANTUM - Phase 1 prototype". `index.html` is the exact current file; changes since v1: reasoning-mode instruction routing and microphone-error diagnostics, both described below.

## Files
- `index.html` - the entire app: HTML, CSS and JavaScript in one file. No build step, no npm dependencies, no external scripts, fonts or images.
- `tests/mode_routing_test.js` - Node test for the mode routing, using a fake AI function. It does not call Claude. Run: `node tests/mode_routing_test.js`
- `tests/mic_error_test.js` - Node test for microphone diagnosis, using a fake SpeechRecognition, window and navigator. It does not use a real microphone. Run: `node tests/mic_error_test.js`
- `capabilities.json` - documentation only. The Artifact is published with the runtime capability `sample` (Claude's built-in AI). That declaration is set at publish time, not inside index.html.

## Runtime
- Designed to run as a published claude.ai Artifact. There, `window.claude` exists and `await claude.use("sample")` returns the AI function.
- Opened as a plain file or on another host, `window.claude` is absent, so the app shows a "Built-in AI isn't available" notice and refuses to answer. It never fakes a reply.
- Answers use the viewer's own Claude usage. The first message asks the viewer for permission.

## How AI works (real)
- `initAI()` resolves `AI = await claude.use("sample")`.
- `ask(signal, onText)` calls `AI([{role:"user",content:RULES}, ...hist.slice(-19)], {cache:false, signal, onText})`.
- `RULES` is a fixed instruction turn (plain text, honest about not claiming unverified work).
- `hist` holds user/assistant turns in memory only. It is not persisted.
- `onText` streams the whole answer so far into the chat bubble.
- Timeout 150 s via AbortController; the Stop button aborts.
- Error codes from the runtime map to messages in the `ERR` table and are written to the in-app Log.
- No `fetch`, no API keys, no external servers anywhere in the file.
- No model is named in the code. The default tier is used and the platform chooses the model.

## Orb (real animation, simulated audio)
- Canvas particle sphere (350/650/1000 particles), additive blending, trails via destination-out fade, CSS halo behind it.
- States: idle, listening, processing, speaking, error. Parameters ease between states (`ST` table).
- Listening and speaking pulse levels are SIMULATED with sine waves. The orb does not read real microphone or speech audio levels. `speechSynthesis` boundary events add a small bump where the browser fires them.

## Voice (browser APIs, no backend)
- Speech input: `SpeechRecognition` / `webkitSpeechRecognition`, single utterance per start, interim results shown in the text box.
- Speech output: `speechSynthesis`, voice chosen in Settings, "Speak every reply" toggle.
- Voice conversation button: loops listen -> send -> speak -> listen; ends after 3 silent turns or on Stop/End.
- Microphone errors (see `micDiag`, `micWhy`, `blockMic`, `initMic` between the "Microphone diagnostics" and "end mic" comments):
  - `micDiag()` gathers best-effort hints: speech API present, secure context, framed or not, `permissionsPolicy.allowsFeature("microphone")`, `navigator.permissions` mic state.
  - SpeechRecognition reports "you denied it" and "the embedding frame blocks it" with the SAME error code (`not-allowed`), so the hints are evidence, not proof; the message says "I can't tell which" when they do not settle it.
  - Messages distinguish: API missing, policy-blocked frame, permission state denied, `service-not-allowed` (speech service refused), `audio-capture` (no usable mic), plain denial.
  - Once blocked (any of those errors, or detected at load), the mic and voice buttons are disabled and `start()` is never called again until reload. `no-speech` and `aborted` do not block.
  - Text chat and spoken replies are unaffected. The Log contains a "mic diag" JSON line.
  - If the AI is unavailable (e.g. a standalone copy), a recognised transcript is left in the input box with a "Heard: ..." note instead of being discarded.
- Not implemented: wake word, streaming speech, real audio-level visualisation, interruption by speaking over the assistant.
- Real microphone input has NOT been verified in the claude.ai Android preview, where the user saw a denied/blocked error. Cause unconfirmed (likely the frame is not granted the mic or the app view lacks a speech service). Suggested test: host index.html on an https static host and open it in Chrome for Android.

## Fast / Deep / Adaptive modes - instruction routing (NOT model routing)
- `cfg.mode` ("fast" | "deep" | "adaptive", saved in localStorage) is read by `ask()` on every request through `planRequest(cfg.mode, hist)`.
- Each mode only changes the INSTRUCTION text appended to the leading `RULES` turn (`MODE_TEXT.fast` / `MODE_TEXT.deep`). The call is otherwise identical: same `AI(...)` function, `cache:false`, `signal`, `onText`, and the same last-19-turn history. No `modelTier`, `model` or `effort` option is passed, so the underlying model and thinking effort are NOT changed by the mode.
- Adaptive: `pickStrategy(latestUserMessage)` adds weighted keyword signals (`SIGNALS`, threshold `DEEP_THRESHOLD`=2) and picks Fast or Deep wording. It is recomputed per request, is deterministic, and is a rough guess (known weak spot: e.g. "Compare REST and GraphQL in detail" scores 1 and stays Fast).
- While waiting, the status line shows which instructions were sent, e.g. "Thinking... (Adaptive -> Deep instructions)".
- Deep mode asks for a concise method and verification summary, not private reasoning.
- Not claimed or implemented: faster/stronger model selection, extra inference compute, tier routing.
- Possible next step (unverified here): pass `modelTier` ("quick" | "default" | "complex") from the sample runtime options.

## State and storage
- `cfg` (mode, voice, speak, dens, reduce; `model` and `url` are unused leftovers) persists in localStorage key `q.cfg`.
- Conversation, error log and history live in memory only and vanish on reload.

## Known limitations / audit hints
- Replies render with `textContent` (plain text). No Markdown or math rendering.
- On any failed call the user turn is popped from `hist`; partial text may remain marked "[interrupted]".
- `hist.slice(-19)` keeps the window starting on a user turn; the leading instruction turn is a second consecutive user turn by design.
- Verified so far: `node --check` on the script, 31 mode-routing tests (fake AI) and 12 microphone-diagnosis tests (fake SpeechRecognition). NOT verified: real Claude answers per mode, the permission prompt, streaming, mic, or behaviour on a physical Android device.
- No rate limiting or spend control of its own; relies on the viewer's Claude usage limits.
- No accessibility audit beyond aria labels, live regions and focus outlines.
