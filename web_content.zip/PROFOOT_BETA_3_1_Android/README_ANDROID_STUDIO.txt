PROFOOT BETA 3.1 — PROJETO ANDROID STUDIO

O QUE É
Projeto Android nativo com uma Activity Java que abre a versão web do jogo em um WebView local.
Os arquivos do jogo ficam dentro de app/src/main/assets/www, então o jogo não depende de hospedagem
para abrir. O progresso usa o armazenamento local do WebView.

COMO ABRIR
1. Extraia o ZIP inteiro para uma pasta.
2. Abra Android Studio.
3. Selecione File > Open e escolha a pasta PROFOOT_BETA_3_1_Android (a pasta que contém settings.gradle).
4. Aceite a sincronização do Gradle e instale Android SDK Platform 35 se o Android Studio pedir.
5. Conecte um Android com depuração USB ativada ou crie um emulador.
6. Clique em Run (▶) para instalar e abrir o jogo.

COMO GERAR APK
No Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
O APK de debug costuma ficar em app/build/outputs/apk/debug/app-debug.apk.
Para publicar, gere um APK/AAB assinado pelo menu Build > Generate Signed Bundle / APK.

REQUISITOS
- Android Studio recente
- JDK 17 (normalmente incluído no Android Studio)
- Android SDK Platform 35; minSdk 23 (Android 6.0)
- Primeira sincronização do Gradle precisa de internet para baixar o plugin Android Gradle, caso não esteja em cache.

OBSERVAÇÕES
- Este é um invólucro Android/WebView do jogo existente, não uma reescrita em Kotlin/Java da lógica do jogo.
- Não inclui um APK pré-compilado; o APK deve ser gerado no Android Studio.
- A navegação do jogo e o armazenamento local são habilitados. Teste as telas principais e o salvamento no aparelho antes de distribuir.
