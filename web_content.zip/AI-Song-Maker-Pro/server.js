import express from "express";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(express.json({limit:"200kb"}));
app.use(express.static("public"));

const styles = {
  "Haryanvi DJ": "Haryanvi folk-pop DJ dance, dhol, nagada, tumbi, punchy bass, energetic male vocal, festive Haryana atmosphere",
  "Bhajan": "Indian devotional bhajan, soulful Indian vocals, harmonium, dholak, tabla, manjira, uplifting devotional atmosphere",
  "Bollywood": "modern Bollywood film song, cinematic Indian pop production, expressive lead vocal, catchy chorus",
  "Rap": "Indian hip-hop rap song, punchy drums, bass, rhythmic lead vocal, memorable hook",
  "Kids": "bright children's song, playful friendly vocal, simple catchy melody, claps and light percussion",
  "Romantic": "Hindi romantic pop ballad, warm expressive vocal, piano, acoustic guitar, cinematic strings",
  "EDM": "Indian EDM dance song, energetic vocal hook, four-on-the-floor kick, synths, festival drop",
  "Cinematic": "epic cinematic Indian song, emotional lead vocal, orchestral strings, powerful percussion"
};

app.post("/api/generate", async (req,res)=>{
  const {prompt="", genre="Haryanvi DJ", mood="energetic", duration=360} = req.body || {};
  if(!prompt.trim()) return res.status(400).json({error:"Prompt लिखिए।"});
  if(!process.env.ELEVENLABS_API_KEY) {
    return res.status(503).json({error:"ElevenLabs API key सेट नहीं है। .env में ELEVENLABS_API_KEY डालें।"});
  }

  const seconds = Math.min(Math.max(Number(duration)||360, 180), 600);
  const style = styles[genre] || genre;
  const fullPrompt = `${style}. Mood: ${mood}. Language: Hindi/Hinglish unless the prompt asks for another language. Create a complete original song from beginning to end with intro, verses, pre-chorus, catchy chorus, bridge and final chorus. Do not imitate a named artist or existing copyrighted song. User concept: ${prompt.trim()}`;

  try {
    const r = await fetch("https://api.elevenlabs.io/v1/music", {
      method:"POST",
      headers:{
        "xi-api-key":process.env.ELEVENLABS_API_KEY,
        "Content-Type":"application/json",
        "Accept":"audio/mpeg"
      },
      body:JSON.stringify({
        prompt: fullPrompt.slice(0,4100),
        music_length_ms: seconds*1000,
        model_id:"music_v2_5",
        output_format:"mp3_48000_192",
        force_instrumental:false,
        sign_with_c2pa:false
      })
    });
    if(!r.ok){
      const err = await r.text();
      return res.status(r.status).json({error:"AI music service ने request reject की।", details:err.slice(0,1000)});
    }
    const buf = Buffer.from(await r.arrayBuffer());
    res.set("Content-Type","audio/mpeg");
    res.set("Content-Disposition",'inline; filename="ai-song.mp3"');
    res.send(buf);
  } catch(e) {
    res.status(500).json({error:"Song generation failed.", details:e.message});
  }
});

app.get("*",(req,res)=>res.sendFile(process.cwd()+"/public/index.html"));
app.listen(process.env.PORT||3000,()=>console.log("AI Song Maker Pro running on port "+(process.env.PORT||3000)));
