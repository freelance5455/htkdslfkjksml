# AI Song Maker Pro — 5–6 minute vocal songs

यह mobile-friendly PWA + Node.js backend है। यह Eleven Music API को server-side call करता है ताकि API key browser में दिखाई न दे।

## Setup
1. Node.js 18+ install करें.
2. `npm install`
3. `.env.example` को `.env` नाम दें.
4. `.env` में `ELEVENLABS_API_KEY` डालें.
5. `npm start`
6. Browser में `http://localhost:3000` खोलें.

Android phone पर production use के लिए इसे किसी HTTPS Node hosting पर deploy करें और Chrome → Add to Home screen चुनें।

## क्यों Eleven Music?
यह API prompt से vocal music बना सकता है और `music_length_ms` के जरिए multi-minute generation सपोर्ट करता है; docs के अनुसार Music API 3–600 seconds तक length स्वीकार करता है. 
Reference: https://elevenlabs.io/docs/api-reference/music/compose

## सुरक्षा
API key को frontend JavaScript में कभी न डालें. `.env` server पर रखें.
