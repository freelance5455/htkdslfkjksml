import zipfile, os, base64

# 1. Ensure the zip is fresh
zip_filename = 'traffic_light_app_source_code.zip'
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk('traffic_light_app'):
        for f in files:
            full_p = os.path.join(root, f)
            rel_p = os.path.relpath(full_p, 'traffic_light_app')
            z.write(full_p, rel_p)

with open(zip_filename, 'rb') as f:
    b64_data = base64.b64encode(f.read()).decode('utf-8')

html_content = f"""<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>تحميل ملف المشروع traffic_light_app_source_code.zip</title>
  <style>
    body {{
      font-family: system-ui, -apple-system, sans-serif;
      background: #0b0f17;
      color: #f8fafc;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
      box-sizing: border-box;
      text-align: center;
    }}
    .box {{
      background: #131924;
      border: 1px solid #243046;
      border-radius: 24px;
      padding: 32px 24px;
      max-width: 500px;
      width: 100%;
      box-shadow: 0 20px 50px rgba(0,0,0,0.6);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 18px;
    }}
    .icon {{
      font-size: 3.5rem;
    }}
    h1 {{
      font-size: 1.3rem;
      margin: 0;
      color: #38bdf8;
    }}
    p {{
      font-size: 0.95rem;
      color: #94a3b8;
      line-height: 1.6;
      margin: 0;
    }}
    .btn {{
      background: linear-gradient(135deg, #10b981, #059669);
      color: #ffffff;
      border: none;
      padding: 14px 28px;
      border-radius: 14px;
      font-size: 1.05rem;
      font-weight: bold;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 4px 16px rgba(16, 185, 129, 0.4);
      transition: transform 0.15s ease, background 0.2s ease;
      text-decoration: none;
    }}
    .btn:hover {{
      transform: scale(1.03);
      background: linear-gradient(135deg, #059669, #047857);
    }}
    .files-list {{
      background: #0f1520;
      border: 1px solid #1f293d;
      border-radius: 12px;
      padding: 12px 16px;
      width: 100%;
      text-align: right;
      font-size: 0.85rem;
      color: #cbd5e1;
      box-sizing: border-box;
    }}
  </style>
</head>
<body>
  <div class="box">
    <div class="icon">📦</div>
    <h1>تحميل مشروع إشارة المرور التفاعلي</h1>
    <p>ملف ZIP مستقل ومدمج يحتوي على كافة ملفات التطبيق (HTML + PWA Manifest + Service Worker + README).</p>
    
    <div class="files-list">
      <strong>محتويات الأرشيف:</strong><br>
      • index.html (الكود التفاعلي + المحاكاة)<br>
      • manifest.json (ملف تعريف التطبيق)<br>
      • sw.js (ملف التشغيل بدون إنترنت)<br>
      • README.md (دليل الاستخدام والتثبيت)
    </div>

    <button class="btn" onclick="startDownload()">
      <span>📥</span>
      <span>اضغط هنا لتنزيل ملف ZIP الآن</span>
    </button>
  </div>

  <script>
    const B64 = "{b64_data}";

    function startDownload() {{
      try {{
        const byteCharacters = atob(B64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {{
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }}
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], {{ type: 'application/zip' }});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'traffic_light_app_source_code.zip';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }} catch (e) {{
        alert('خطأ في التنزيل: ' + e.message);
      }}
    }}

    // Auto-trigger on page load
    window.addEventListener('load', () => {{
      setTimeout(startDownload, 500);
    }});
  </script>
</body>
</html>
"""

with open('public/download.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print('public/download.html written successfully!')
