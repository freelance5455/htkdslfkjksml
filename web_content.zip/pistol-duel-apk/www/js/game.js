
(function(){

    const $=id=>document.getElementById(id);
    const body=document.body;

    const SCREENS=["menu","modes","store","rankSkill","bracket","rankResult","eventScr","patchScr","inboxScr","vsScr","vsDraft","lbScr","misScr","admScr","stScr","dlgScr","arcDeck","arcScr","srchScr"];

    let overlayOpen=false;

    function show(id){
        overlayOpen=!!id;
        SCREENS.forEach(s=>{
            $(s).style.display=(s===id)?"flex":"none";
        });
    }

    function hideScreens(){show(null);}

    function setCls(c){
        body.classList.remove("sandbox","ranked","manualOn","spec");
        if(c)body.classList.add(c);
    }

    function snd(t){try{sound(t)}catch(e){}}
    function audio(){try{initAudio()}catch(e){}}

    function resetTransient(){
        bullets=[];
        particles=[];
        clones=[];
        boosters=[];
        blackholes=[];
        explosions=[];
        timeFreeze=null;
        dimension=null;
        spirits=[];
        selected=null;
        dragging=null;
    }

    function shuffle(a){
        for(let i=a.length-1;i>0;i--){
            const j=Math.floor(Math.random()*(i+1));
            [a[i],a[j]]=[a[j],a[i]];
        }
        return a;
    }

    /* ---------- STATE ---------- */

    const ROUND_NAMES=["Perempat Final","Semi Final","Final"];

    const rank={
        active:false,
        inDuel:false,
        skill:null,
        control:"auto",
        rounds:[],
        r:0,
        player:null,
        opp:null,
        t:0,
        bothDead:0,
        mode:"ranked",
        teamSize:1,
        len:"fast",
        stage:"ko",
        isLong:false,
        grp:null,
        gm:null,
        boostSel:{},
        boost:{},
        banner:""
    };

    let sandboxObjects=null;

    /* ---------- PROFIL: KOIN, RANK, SKILL ---------- */

    const memStore={};

    const st={
        get(k){try{return localStorage.getItem(k)}catch(e){return memStore[k]||null}},
        set(k,v){try{localStorage.setItem(k,v)}catch(e){memStore[k]=v}}
    };

    const PRICES={
        speed:260,
        angel:280,
        sniper:320,
        regen:340,
        fireshot:380,
        nuclear:420,
        magnet:460,
        shotgun:500,
        phase:540,
        clone:580,
        burst:620,
        hunter:660,
        hole:700,
        hipo:720,
        dead:760,
        samurai:780,
        lifesteal:800,
        time:800,
        goldentime:800,
        ice:800
    };

    const DESC={
        normal:"Tembakan standar yang seimbang.",
        speed:"Gerak 35% lebih cepat dan peluru lebih kencang. Damage kecil (25).",
        angel:"Bisa menghidupkan teman tim yang gugur. Di duel 1 lawan 1 efeknya kecil.",
        sniper:"Tembakan hampir 100% akurat dengan damage 55. Skill aktif (CD 10 dtk): peluru tembus, tidak bisa ditahan perisai, kebal, atau klon. Kekurangan: gerak -20%.",
        regen:"Pasif: memulihkan diri sendiri 20% HP tiap 6 detik. Aktif (CD 0): sambungkan ke satu teman — teman itu dipulihkan 10 HP tiap 2 detik, permanen sampai kamu atau teman itu gugur.",
        ghost:"Dua skill aktif. 🌫️ Merasuki (CD 15 dtk): roh menyerang musuh terdekat lalu menguasai tubuhnya 5 detik — kamu bisa menembak & memakai skill-nya. Tubuh aslimu diam dan kebal. 🌀 Dimensi (CD 20 dtk): menyeret 1 musuh ke dimensi duel 1 lawan 1 selama 10 detik; kalau tak ada yang mati, keduanya keluar. Selama di dimensi: power +20%, kecepatan +10%, fire rate +5%.",
        fireshot:"Peluru lebih cepat dan makin sering menembak seiring level.",
        samurai:"Tanpa pistol — bertarung dengan katana. Gerak 2x lebih cepat. Harus mepet musuh; begitu menempel langsung menebas terus-menerus tanpa jeda (30 damage per detik). Aktif (CD 15 dtk): tebasan kilat — melesat secepat kilat dan menebas satu musuh 3 kali bolak-balik, 45 damage per tebasan.",
        lifesteal:"Pasif: tiap peluru yang kena musuh mengembalikan 15% HP-mu. Aktif (CD 15 dtk): area sedot di sekitarmu selama 5 detik — musuh di dalam area disedot 10% HP per detik dan HP itu pindah ke kamu. Selama area aktif: kecepatan x1,5 dan pemulihan HP +20%.",
        nuclear:"Pasif: saat gugur, pembunuhnya ikut mati instan. Aktif: radiasi ke seluruh arena 3 detik — damage 3 per detik dan musuh linglung (tembakan & gerak kacau) 2 detik. CD 12 dtk.",
        magnet:"Peluru mengejar musuh, akurasi 100%, damage 47,5 dengan HP 100.",
        shotgun:"Tembakan menyebar dengan damage besar (59).",
        phase:"Perisai 35 berkala dan gerak 2x lebih cepat.",
        clone:"Membuat klon yang ikut menembak dan bisa memperbanyak diri.",
        burst:"Satu tembakan berdamage ±92 dengan jeda panjang.",
        hunter:"Tembakan beruntun 5 pistol plus kebal 2 detik tiap 8 detik.",
        hole:"Black hole yang menarik dan membuat musuh pingsan.",
        dead:"Tidak bisa menyerang, tapi bertahan 30 detik lalu membunuh semua musuh.",
        time:"Menghentikan waktu 1,2 detik dan menembak bertubi-tubi (damage 10 per peluru). CD 13 detik.",
        goldentime:"Mengubah takdir. Saat gugur, kamu bangkit sekali per ronde dengan 60% HP, power x1,5, dan kebal 2 detik. Skill aktif: serangan emas 60 damage ke semua musuh — tapi kalau dipakai saat masih hidup, kesempatan bangkit hangus.",
        hipo:"Menyegel skill satu lawan selama 10 detik (termasuk Dead dan skill pasif), cd 14 detik.",
        ice:"Peluru 35 damage: musuh yang terkena melambat (slow motion) 1,5 detik dan power -5%. Aktif (CD 25 dtk): membekukan seluruh arena 5 detik — semua musuh gerak -5%, fire rate -2%, power -5%."
    };

    const priceOf=k=>PRICES[k]||300;

    const TIERS=[
        {n:"Kadet",max:3,icon:"🪖"},
        {n:"Silver",max:4,icon:"🥈"},
        {n:"Gold",max:5,icon:"🥇"},
        {n:"Legend",max:10,icon:"👑"}
    ];

    const REWARD_ROUND=5;
    const REWARD_CHAMP=50;

    const MATCH_LIMIT=60;

    const BOOSTERS={
        immortal:{icon:"♾️",name:"Immortal",price:30,desc:"Hidup 2x: saat gugur pertama kali, bangkit dengan 50% HP dan kebal 2 detik."},
        cd:{icon:"⏩",name:"Cepat CD",price:20,desc:"Cooldown skill 40% lebih cepat."},
        shield:{icon:"🛡️",name:"Perisai Awal",price:15,desc:"Mulai duel dengan perisai 30."},
        power:{icon:"💥",name:"Power Up",price:20,desc:"Damage tembakan +20% sepanjang duel."},
        hp:{icon:"❤️",name:"HP Plus",price:15,desc:"HP maksimal +30%."}
    };

    function rankInfo(rp){

        let r=rp;

        for(const t of TIERS){

            if(r<t.max){
                return{icon:t.icon,text:t.n+" "+(r+1)};
            }

            r-=t.max;

        }

        return{icon:"🌀",text:"Vortex ★"+(r+1)};

    }

    const rankText=rp=>{
        const i=rankInfo(rp);
        return i.icon+" "+i.text;
    };

    let profile=null;
    let forfeitNote="";

    function isAdmin(){
        return !window.currentIsGuest&&String(window.currentUser||"").toLowerCase()==="admin";
    }

    function pkey(){
        return window.currentIsGuest
            ?"tds_profile_guest"
            :"tds_profile_u_"+String(window.currentUser||"").toLowerCase();
    }

    function saveProfile(){
        if(profile){
            profile._sv=Date.now();
            st.set(pkey(),JSON.stringify(profile));
            if(window.TDSOnline&&TDSOnline.enabled()&&!window.currentIsGuest&&!isAdmin()){
                TDSOnline.queue(String(window.currentUser||""),profile);
            }
        }
    }

    function loadProfile(){

        let p=null;

        try{p=JSON.parse(st.get(pkey())||"null")}catch(e){}

        let created=false;

        if(!p||typeof p!=="object"){
            p={coins:0,unlocked:["normal"],rp:0,pending:false};
            created=true;
        }

        /* GLOBAL v0.01: semua akun direset dari 0; pemain beta dapat hadiah via Inbox */

        let resetNote="";

        if(!p.g001){

            if(!created&&!isAdmin()){

                const keepBio=typeof p.bio==="string"?p.bio:"";

                Object.keys(p).forEach(k=>{delete p[k];});

                Object.assign(p,{
                    coins:0,gems:0,unlocked:["normal"],rp:0,xp:0,peak:0,pulls:0,
                    pending:false,items:{},free:{time:0,ghost:0},
                    streak:0,claimedDays:[],lastClaim:"",bio:keepBio,
                    inbox:[{
                        id:"beta001",
                        title:"🎁 Hadiah Pemain Beta",
                        date:"4 Nov 2026",
                        body:"Terima kasih sudah ikut Beta! Di Global v0.01 semua akun direset dari 0. Sebagai gantinya kamu mendapat 500 koin, 300 💎, dan 10x Gacha gratis di setiap event. Ketuk Klaim untuk mengambilnya.",
                        coins:500,
                        gems:300,
                        free:{time:10,ghost:10},
                        claimed:false
                    }]
                });

                resetNote="🔄 Global v0.01: akun direset. Hadiah Beta ada di ✉️ Inbox!";

            }

            p.g001=true;
            p.mig15=true;
            p.mig182=true;

        }

        p.coins=Math.max(0,Math.floor(Number(p.coins)||0));
        p.rp=Math.max(0,Math.floor(Number(p.rp)||0));

        p.gems=Math.max(0,Math.floor(Number(p.gems)||0));
        p.pulls=Math.max(0,Math.floor(Number(p.pulls)||0));

        if(!p.items||typeof p.items!=="object")p.items={};

        Object.keys(BOOSTERS).forEach(k=>{
            p.items[k]=Math.max(0,Math.floor(Number(p.items[k])||0));
        });

        if(!Array.isArray(p.unlocked))p.unlocked=[];

        p.unlocked=p.unlocked.filter(k=>SKILLS[k]);

        if(!p.unlocked.includes("normal"))p.unlocked.push("normal");

        p.lastClaim=typeof p.lastClaim==="string"?p.lastClaim:"";
        p.streak=Math.max(0,Math.floor(Number(p.streak)||0));
        if(!Array.isArray(p.claimedDays))p.claimedDays=[];
        p.claimedDays=p.claimedDays.filter(x=>typeof x==="string").slice(-62);

        if(!Array.isArray(p.inbox))p.inbox=[];

        p.inbox=p.inbox.filter(m=>m&&typeof m==="object"&&typeof m.id==="string").slice(-50);

        /* GLOBAL v0.05: ID unik 5 digit + preset kartu Arcade */

        if(!window.currentIsGuest&&!/^[1-9][0-9]{4}$/.test(String(p.uid||""))){
            p.uid=String(10000+Math.floor(Math.random()*90000));
        }

        p.agSeen=(Array.isArray(p.agSeen)?p.agSeen:[]).filter(x=>typeof x==="string").slice(-300);

        if(!p.story||typeof p.story!=="object")p.story={done:0};

        p.story.done=Math.max(0,Math.min(50,Math.floor(Number(p.story.done)||0)));

        p.arcPresets=(Array.isArray(p.arcPresets)?p.arcPresets:[]).slice(0,3);

        while(p.arcPresets.length<3)p.arcPresets.push(null);

        p.arcPresets=p.arcPresets.map(d=>
            Array.isArray(d)&&d.length===5&&d.every(k=>typeof k==="string")?d:null
        );

        /* GLOBAL v0.02: kompensasi permintaan maaf admin (semua akun, lama & baru) */

        if(!p.g002){
            p.g002=true;
            p.inbox.push({
                id:"sorry002",
                title:"🙏 Permintaan Maaf dari Admin",
                date:"5 Nov 2026",
                body:"Maaf ya, kami belum sempat memberi hadiah selamat datang. Sebagai kompensasi, ini 250 koin dan 50 💎 untukmu. Ketuk Klaim untuk mengambilnya!",
                coins:250,
                gems:50,
                claimed:false
            });
        }

        let migrated=false;

        if(!p.mig15){

            p.mig15=true;

            if(!isAdmin()&&!created&&(p.unlocked.includes("time")||p.unlocked.includes("goldentime"))){

                p.unlocked=p.unlocked.filter(k=>k!=="time"&&k!=="goldentime");

                p.inbox.push({
                    id:"mig15",
                    title:"📬 Penyesuaian Akun v1.5",
                    date:"24 Okt 2026",
                    body:"⏳ Time dan 🌟 GoldenTime kini menjadi item terbatas (hanya dari Spin). Skill tersebut telah dihapus dari akunmu dan diganti dengan kompensasi berikut. Ketuk Klaim untuk mengambilnya.",
                    coins:1500,
                    gems:200,
                    claimed:false
                });

                migrated=true;

            }

        }

        if(!p.free||typeof p.free!=="object")p.free={};
        p.free.time=Math.max(0,Math.floor(Number(p.free.time)||0));
        p.free.ghost=Math.max(0,Math.floor(Number(p.free.ghost)||0));

        if(!p.mig182){

            p.mig182=true;

            p.inbox.push({
                id:"gift182",
                title:"🎁 Hadiah: Gacha Gratis 10x",
                date:"1 Nov 2026",
                body:"Hadiah untuk semua pemain! Ketuk Klaim untuk mendapat 10x Gacha gratis di setiap event (Time & Golden, dan Ghost). Pull gratis dipakai lebih dulu sebelum koin atau berlian.",
                free:{time:10,ghost:10},
                claimed:false
            });

        }

        p.xp=Math.max(0,Math.floor(Number(p.xp)||0));
        p.peak=Math.max(0,Math.floor(Number(p.peak)||0));
        p.bio=typeof p.bio==="string"?p.bio.slice(0,80):"";

        if(isAdmin()){
            p.unlocked=Object.keys(SKILLS);
            p.rp=Math.max(p.rp,1021);
            p.xp=Math.max(p.xp,9900);
        }

        p.peak=Math.max(p.peak,p.rp);

        let note="";

        if(p.pending){
            const before=rankText(p.rp);
            p.pending=false;
            p.rp=Math.max(0,p.rp-1);
            note="Duel sebelumnya tidak diselesaikan: rank turun 1 poin ("+before+" → "+rankText(p.rp)+").";
        }

        if(resetNote)note=resetNote;

        if(migrated){
            note="📬 Penyesuaian akun v1.5: cek ✉️ Inbox untuk klaim 1500 🪙 + 200 💎";
        }

        if(isAdmin()){
            note="👑 Admin: koin unlimited & rank Vortex ★1000";
        }

        profile=p;

        saveProfile();

        return note;

    }

    function updateWallet(){

        if(!profile)return;

        const t="🪙 "+(isAdmin()?"∞":profile.coins)+"  •  💎 "+(isAdmin()?"∞":profile.gems)+"  •  "+rankText(profile.rp);

        ["menuStats","wallet1","wallet2","wallet3","wallet4","walletInb","walletBuy"].forEach(id=>{
            const e=$(id);
            if(e)e.textContent=t;
        });

    }

    function forfeitIfDueling(){

        if(rank.active&&rank.inDuel&&profile&&rank.mode==="ranked"){

            profile.rp=Math.max(0,profile.rp-1);
            profile.pending=false;

            saveProfile();

            forfeitNote="Keluar saat duel: rank turun 1 poin.";

        }

    }

    function openBuy(k){

        const s=SKILLS[k];
        const price=priceOf(k);

        const lim=LIMITED.includes(k);
        const lore=LORE[k]||{who:"",ttl:"",story:""};

        $("buyArt").style.display="";
        $("buyArt").innerHTML=skillArt(k);
        $("buyIcon").style.display="none";
        $("buyName").textContent=s.icon+" "+s.name;
        $("buyWho").textContent=lore.who?lore.who+" • "+lore.ttl:"";
        $("buyWho").style.display="";
        $("buyLore").textContent=lore.story;
        $("buyLore").style.display="";
        $("buyLoreT").style.display="";
        $("buyDescT").style.display="";
        $("buyDesc").textContent=DESC[k]||"";
        $("buyPrice").textContent=lim?"🎁 Hanya dari Spin":"🪙 "+price;

        const ok=!lim&&(isAdmin()||profile.coins>=price);

        const btn=$("buyYes");

        btn.disabled=!ok;
        btn.textContent=lim?"🎁 Item terbatas — silakan spin":(ok?"Beli":"Koin kurang ("+(price-profile.coins)+" lagi)");

        btn.onclick=()=>{

            if(lim)return;

            if(!isAdmin()&&profile.coins<price)return;

            if(!isAdmin())profile.coins-=price;

            if(!profile.unlocked.includes(k))profile.unlocked.push(k);

            saveProfile();

            closeBuy();

            if(buyReturn==="store"){

                renderStore();

            }
            else{

                openRankSetup();

                $("rankMsg").textContent="✅ "+s.name+" berhasil dibeli!";

            }

        };

        updateWallet();

        $("buyBox").style.display="flex";

    }

    function closeBuy(){
        $("buyBox").style.display="none";
    }

    $("buyNo").onclick=closeBuy;


    const label=e=>{
        const mem=e.members||[e.skill];
        const s=SKILLS[mem[0]];
        let t=s.icon+" "+s.name;
        if(mem.length>1)t+=" "+mem.slice(1).map(k=>SKILLS[k].icon).join("");
        return t+(e.isP?" (P)":" (COM)");
    };

    /* ---------- MENU ---------- */

    function cleanup(){
        vsReset();
        forfeitIfDueling();
        rank.active=false;
        rank.inDuel=false;
        try{stopDuel()}catch(e){}
        resetTransient();
        setCls(null);
        $("rankBanner").textContent="";
    }

    function showMenu(){

        arcBgmStop();

        cleanup();
        closeBuy();
        const note=loadProfile();
        $("menuUser").textContent=$("userChip").textContent||"";
        $("menuNote").textContent=forfeitNote||note||"";
        forfeitNote="";
        homeRefresh();
        cloudTagRender();
        misBadgeRender();
        show("menu");
        startTony();
    }

    function enterSandbox(){

        audio();

        cleanup();

        if(sandboxObjects){

            objects=sandboxObjects;
            sandboxObjects=null;

            objects.forEach(o=>{
                if(o.type==="character"){
                    o.hp=o.maxHp;
                    o.dead=false;
                    o.immuneTimer=0;
                    o.goldenImmune=0;
                    o.goldenRewind=null;
                }
            });

        }

        setCls("sandbox");
        hideScreens();
        updateInfo();

    }

    function openRankSetup(mode){

        if(mode==="ranked"||mode==="classic")rank.mode=mode;

        $("rankTitle").textContent=rank.mode==="classic"?"🎯 Classic":"🏆 Ranked";

        audio();

        const g=$("rankGrid");
        g.innerHTML="";

        if(!profile)loadProfile();

        const owned=k=>profile.unlocked.includes(k);

        Object.keys(SKILLS).sort((a,b)=>{
            const oa=owned(a)?0:1;
            const ob=owned(b)?0:1;
            if(oa!==ob)return oa-ob;
            return priceOf(a)-priceOf(b);
        }).forEach(k=>{
            const s=SKILLS[k];
            const b=document.createElement("button");
            if(owned(k)){
                b.innerHTML="<span>"+s.icon+" "+s.name+"</span>";
                b.onclick=()=>pickSkill(k);
            }
            else{
                b.className="locked";
                b.innerHTML="<span>🔒 "+s.icon+" "+s.name+"</span><small>"+(LIMITED.includes(k)?"🎁 Spin":"🪙 "+priceOf(k))+"</small>";
                b.onclick=()=>{buyReturn="rank";openBuy(k);};
            }
            g.appendChild(b);
        });

        $("rankMsg").textContent="";

        updateWallet();

        $("rankStep1").style.display="";
        $("rankStep2").style.display="none";

        show("rankSkill");

    }

    function pickSkill(k){

        if(!profile||!profile.unlocked.includes(k))return;

        rank.skill=k;

        $("rkIcon").textContent=SKILLS[k].icon;
        $("rkName").textContent=SKILLS[k].name;

        $("rankStep1").style.display="none";
        $("rankStep2").style.display="";

        renderTeamSeg();

        renderBoostPick();

    }

    $("menuLogout").onclick=()=>$("logout").onclick();
    $("rankBack").onclick=showMenu;
    $("rankChange").onclick=()=>openRankSetup();
    $("toMenu").onclick=showMenu;
    $("bkMenu").onclick=showMenu;

    $("ctrlAuto").onclick=()=>startRanked("auto");
    $("ctrlManual").onclick=()=>startRanked("manual");

    /* ---------- TURNAMEN ---------- */

    const TEAM_NAMES={1:"Solo",2:"Duo",4:"Squad"};

    const TEAM_DESC={
        1:"1 lawan 1.",
        2:"2 lawan 2. Rekan satu tim didapat acak.",
        4:"4 lawan 4. Rekan satu tim didapat acak."
    };

    function renderTeamSeg(){

        document.querySelectorAll("#teamSeg button").forEach(b=>{
            b.classList.toggle("on",Number(b.dataset.t)===rank.teamSize);
        });

        $("teamDesc").textContent=TEAM_DESC[rank.teamSize];

        renderLen();

    }

    document.querySelectorAll("#teamSeg button").forEach(b=>{
        b.onclick=()=>{
            rank.teamSize=Number(b.dataset.t);
            renderTeamSeg();
        };
    });

    function pickDistinct(n,exclude){
        return shuffle(
            Object.keys(SKILLS).filter(k=>!exclude.includes(k))
        ).slice(0,n);
    }

    function makeEntry(isP,members){
        return{isP:isP,skill:members[0],members:members};
    }

    function makeRound(es){
        const ms=[];
        for(let i=0;i<es.length;i+=2){
            ms.push({a:es[i],b:es[i+1],w:null});
        }
        return ms;
    }

    function newTournament(){

        const n=rank.teamSize;

        rank.stage="ko";
        rank.isLong=false;
        rank.grp=null;
        rank.gm=null;

        if(rank.mode==="ranked"&&rank.len==="long"&&n===1){
            newGroupStage();
            return;
        }

        let entries;

        if(n===1){

            const others=pickDistinct(7,[rank.skill]);

            entries=[makeEntry(true,[rank.skill])]
                .concat(others.map(k=>makeEntry(false,[k])));

        }
        else{

            /* tim acak penuh: rekan & lawan bebas skill apa saja (boleh kembar) */

            const mates=anySkills(n-1);

            entries=[makeEntry(true,[rank.skill].concat(mates))];

            for(let i=0;i<7;i++){
                entries.push(makeEntry(false,anySkills(n)));
            }

        }

        rank.rounds=[makeRound(shuffle(entries))];
        rank.r=0;

    }

    function startRanked(control){

        audio();

        if(!profile||!profile.unlocked.includes(rank.skill))return;

        rank.control=control;

        lockBoosters();

        newTournament();

        showStart();

    }

    function showBracket(){

        let h="";

        rank.rounds.forEach((rd,ri)=>{

            h+='<div class="rnd">'+ROUND_NAMES[ri].toUpperCase()+'</div>';

            rd.forEach(m=>{

                const me=m.a.isP||m.b.isP;

                const c=x=>m.w?(m.w===x?"win":"lose"):"";

                h+='<div class="match'+(me?" me":"")+'">'
                    +'<span class="'+c(m.a)+'">'+label(m.a)+'</span>'
                    +'<em>vs</em>'
                    +'<span class="'+c(m.b)+'">'+label(m.b)+'</span>'
                    +'</div>';

            });

        });

        $("bkList").innerHTML=h;

        $("bkTitle").textContent=
            (rank.mode==="classic"?"🎯 ":"🏆 ")+
            ROUND_NAMES[rank.r]+" • "+TEAM_NAMES[rank.teamSize];

        updateWallet();

        show("bracket");

        $("bkList").scrollTop=$("bkList").scrollHeight;

    }

    $("bkStart").onclick=beginDuel;

    function spawnTeam(team,members){

        const n=members.length;

        const bx=team==="blue"?W*.25:W*.75;

        const dir=team==="blue"?1:-1;

        return members.map((k,i)=>{

            let px=bx;
            let py=H*.5;

            if(n>1){
                px=bx+dir*(i%2?42:0);
                py=H*.17+(H*.42)*(i/(n-1));
            }

            return addCharacter(px,py,team,k);

        });

    }

    function setSpec(on){
        body.classList.toggle("spec",!!on);
    }

    function beginDuel(){

        audio();

        hideScreens();

        rank.active=true;

        if(profile&&rank.mode==="ranked"){
            profile.pending=true;
            saveProfile();
        }

        setCls("ranked");

        if(!sandboxObjects)sandboxObjects=objects;

        objects=[];

        try{stopDuel()}catch(e){}

        resetTransient();

        const m=rank.stage==="group"
            ?rank.gm
            :rank.rounds[rank.r].find(x=>x.a.isP||x.b.isP);

        const me=m.a.isP?m.a:m.b;
        const opp=m.a.isP?m.b:m.a;

        rank.opp=opp;

        const mine=spawnTeam("blue",me.members);

        spawnTeam("red",opp.members);

        startDuel();

        const p=mine[0];

        rank.player=p;

        applyBoosters(p);

        /* musuh & rekan COM: AI sesuai rank */

        const d=diffOf(profile?profile.rp:0);

        objects.forEach(o=>{
            if(o.type==="character"&&o!==p)o.ai=makeAI(d);
        });

        if(rank.control==="manual"){

            p.manual=true;
            p.mcd=cdStartManual(p);
            p.mcdMax=p.mcd;
            p.mcd2=p.mcdMax2=(SKILLS[p.skill]&&SKILLS[p.skill].ghostSkill)?(SKILLS[p.skill].dimCooldownMax||20):2;
            p.manualCloneDone=false;
            p.boostT=0;
            p.goldenGo=false;
            p.gWasActive=false;

            $("sbIcon").textContent=SKILLS[p.skill].icon;
            $("sbLabel").textContent=abilityOf(p).name;

            body.classList.add("manualOn");

            startHud();

        }

        setSpec(false);

        rank.inDuel=true;
        rank.t=0;
        rank.bothDead=0;

        rank.banner=
            (rank.stage==="group"?"Grup • Hari "+(rank.grp.day+1):ROUND_NAMES[rank.r])+" • "+
            label(me)+
            " vs "+label(opp);

        $("rankBanner").textContent="⏱ "+MATCH_LIMIT+" • "+rank.banner;

    }

    function resultScreen(kind,reward){

        $("rrReward").textContent=(reward||"")+(misMsg?"  •  "+misMsg:"");

        misMsg="";

        const rd=ROUND_NAMES[rank.r];

        const b1=$("rrBtn1");
        const b2=$("rrBtn2");

        b2.style.display="";

        if(kind==="win"){

            $("rrIcon").textContent="✅";
            $("rrTitle").textContent="MENANG!";
            $("rrText").textContent="Lanjut ke "+ROUND_NAMES[rank.r+1]+".";

            b1.textContent="Lanjut ▶";
            b1.onclick=()=>{rank.r++;showBracket();};

            b2.textContent="🏠 Menu";
            b2.onclick=showMenu;

        }
        else if(kind==="champ"){

            $("rrIcon").textContent="🏆";
            $("rrTitle").textContent="JUARA!";
            $("rrText").textContent=
                "Kamu menjuarai turnamen "+(rank.mode==="classic"?"Classic":"Ranked")+
                " ("+TEAM_NAMES[rank.teamSize]+") dengan skill "+
                SKILLS[rank.skill].name+".";

            b1.textContent="🔁 Main Lagi";
            b1.onclick=()=>openRankSetup();

            b2.textContent="🏠 Menu";
            b2.onclick=showMenu;

        }
        else{

            $("rrIcon").textContent="💀";
            $("rrTitle").textContent="KALAH";
            $("rrText").textContent="Kamu tersingkir di "+rd+".";

            b1.textContent="🔁 Coba Lagi";
            b1.onclick=()=>{lockBoosters();newTournament();showStart();};

            b2.textContent="🏠 Menu";
            b2.onclick=showMenu;

        }

        show("rankResult");

    }

    function finish(win){

        rank.inDuel=false;

        body.classList.remove("manualOn");

        setSpec(false);

        if(duelMode)stopDuel();

        if(rank.stage==="story"){
            finishStory(win);
            return;
        }

        if(rank.stage==="mission"){
            finishMission(win);
            return;
        }

        if(win)missionWin();

        if(rank.stage==="group"){
            finishGroup(win);
            return;
        }

        const rd=rank.rounds[rank.r];

        const me=rd.find(m=>m.a.isP||m.b.isP);

        const pe=me.a.isP?me.a:me.b;
        const oe=me.a.isP?me.b:me.a;

        me.w=win?pe:oe;

        rd.forEach(m=>{
            if(!m.w)m.w=Math.random()<.5?m.a:m.b;
        });

        const ranked=rank.mode==="ranked";

        const before=rankText(profile.rp);

        if(!win){

            let rw="Mode Classic: tanpa hadiah, rank tidak berubah.";

            if(ranked){

                profile.rp=Math.max(0,profile.rp-1);
                profile.xp+=5;
                profile.pending=false;
                saveProfile();

                rw="Rank turun: "+before+" → "+rankText(profile.rp)+"  •  +5 XP";

            }

            resultScreen("lose",rw);

            return;

        }

        const champ=rank.r>=ROUND_NAMES.length-1;

        let rw="Mode Classic: tanpa hadiah, rank tidak berubah.";

        if(ranked){

            const gain=champ?REWARD_CHAMP:REWARD_ROUND;
            const xp=champ?100:25;

            if(!isAdmin())profile.coins+=gain;

            profile.xp+=xp;
            profile.pending=false;

            rw="+"+gain+" 🪙  •  +"+xp+" XP";

            if(champ){

                profile.rp+=1;
                profile.peak=Math.max(profile.peak,profile.rp);

                rw+="  •  Rank naik: "+before+" → "+rankText(profile.rp);

            }

            saveProfile();

        }

        if(champ){
            resultScreen("champ",rw);
            return;
        }

        rank.rounds.push(makeRound(rd.map(m=>m.w)));

        resultScreen("win",rw);

    }

    window.onDuelEnd=function(blueAlive){

        if(vsOn()){
            if(vs.role==="host"&&vs.inDuel)vsEnd(blueAlive?"host":"guest");
            return true;
        }

        if(!rank.active||!rank.inDuel)return false;

        finish(!!blueAlive);

        return true;

    };

    function redoRound(){

        if(profile&&rank.mode==="ranked"){
            profile.pending=false;
            saveProfile();
        }

        rank.inDuel=false;

        body.classList.remove("manualOn");

        setSpec(false);

        try{stopDuel()}catch(e){}

        resetTransient();

        setTimeout(()=>{
            if(rank.active){
                if(rank.stage==="story")beginStory();
                else if(rank.stage==="mission")beginMission();
                else beginDuel();
            }
        },400);

    }

    /* seri / macet / spektator */

    setInterval(()=>{

        if(!rank.active||!rank.inDuel||!duelMode)return;

        rank.t+=.5;

        $("rankBanner").textContent="⏱ "+Math.max(0,Math.ceil(MATCH_LIMIT-rank.t))+" • "+rank.banner;

        const ch=objects.filter(o=>o.type==="character");

        const bl=ch.filter(o=>(o.origTeam||o.team)==="blue");
        const rd=ch.filter(o=>(o.origTeam||o.team)==="red");

        const blA=bl.some(o=>o.hp>0);
        const rdA=rd.some(o=>o.hp>0);

        const p=rank.player;

        setSpec(!!p&&p.hp<=0&&blA);

        if(!blA&&!rdA){

            rank.bothDead++;

            if(rank.bothDead>=3)redoRound();

            return;

        }

        rank.bothDead=0;

        if(rank.t>=MATCH_LIMIT){

            /* waktu habis: menang = tim dengan sisa player hidup lebih banyak */

            const aliveN=arr=>arr.filter(o=>o.hp>0).length;

            const ba=aliveN(bl);
            const ra=aliveN(rd);

            if(ba!==ra){
                finish(ba>ra);
                return;
            }

            const ratio=arr=>{
                let h=0;
                let m=0;
                arr.forEach(o=>{h+=Math.max(0,o.hp);m+=o.maxHp;});
                return m?h/m:0;
            };

            const pr=ratio(bl);
            const cr=ratio(rd);

            if(Math.abs(pr-cr)<.001)redoRound();
            else finish(pr>cr);

        }

    },500);

    /* ---------- KONTROL MANUAL ---------- */

    const vs={active:false,role:null,pc:null,cc:null,sc:null,cam:null,connected:false,inDuel:false,me:null,opp:null,d:null,dv:null,sel:null,names:{},again:{host:false,guest:false},cdRemote:null,fx:[],snds:[],bid:0};

    function vsOn(){return vs.active;}

    const joy={x:0,y:0,id:null};
    const keys={};

    const base=$("joy");
    const knob=$("joyKnob");

    function setJoy(e){

        const r=base.getBoundingClientRect();

        const cx=r.left+r.width/2;
        const cy=r.top+r.height/2;

        let dx=e.clientX-cx;
        let dy=e.clientY-cy;

        const max=r.width/2-8;

        const d=Math.hypot(dx,dy);

        if(d>max){
            dx=dx/d*max;
            dy=dy/d*max;
        }

        joy.x=dx/max;
        joy.y=dy/max;

        knob.style.transform="translate("+dx+"px,"+dy+"px)";

    }

    base.addEventListener("pointerdown",e=>{
        joy.id=e.pointerId;
        base.setPointerCapture(e.pointerId);
        setJoy(e);
        e.preventDefault();
    });

    base.addEventListener("pointermove",e=>{
        if(e.pointerId===joy.id)setJoy(e);
    });

    function joyEnd(e){
        if(e.pointerId!==joy.id)return;
        joy.id=null;
        joy.x=0;
        joy.y=0;
        knob.style.transform="";
    }

    base.addEventListener("pointerup",joyEnd);
    base.addEventListener("pointercancel",joyEnd);

    window.addEventListener("keydown",e=>{
        const k=e.key.length===1?e.key.toLowerCase():e.key;
        keys[k]=true;
        if(k===" "&&body.classList.contains("manualOn")){
            e.preventDefault();
            useSkill();
        }
        if((k==="e"||k==="Shift")&&body.classList.contains("manualOn")){
            useSkill2();
        }
    });

    window.addEventListener("keyup",e=>{
        const k=e.key.length===1?e.key.toLowerCase():e.key;
        keys[k]=false;
    });

    function getInput(){

        let x=joy.x;
        let y=joy.y;

        if(joy.id===null){

            x=(keys.ArrowRight||keys.d?1:0)-(keys.ArrowLeft||keys.a?1:0);
            y=(keys.ArrowDown||keys.s?1:0)-(keys.ArrowUp||keys.w?1:0);

            const m=Math.hypot(x,y);

            if(m>1){x/=m;y/=m;}

        }

        if(Math.hypot(x,y)<.12)return{x:0,y:0};

        return{x:x,y:y};

    }

    /* tombol skill */

    function abilityOf(o){

        const s=SKILLS[o.skill]||{};

        if(s.timeSkill)return{k:"time",name:"Time Stop"};
        if(s.holeSkill)return{k:"hole",name:"Black Hole"};
        if(s.hunterSkill)return{k:"hunter",name:"Barrage"};
        if(s.goldenSkill)return{k:"golden",name:"Takdir"};
        if(s.phase)return{k:"phase",name:"Shield"};
        if(s.clone)return{k:"clone",name:"Clone"};
        if(s.deadSkill)return{k:"dead",name:"Ultimate"};
        if(s.hipoSkill)return{k:"hipo",name:"Segel"};
        if(s.sniperSkill)return{k:"sniper",name:"Tembus"};
        if(s.nukeSkill)return{k:"nuke",name:"Radiasi"};
        if(s.lifestealZone)return{k:"lsteal",name:"Sedot"};
        if(s.iceSkill)return{k:"ice",name:"Beku"};
        if(s.samuraiSkill)return{k:"slash",name:"Tebas"};
        if(s.ghostSkill)return{k:"possess",name:"Rasuki"};
        if(s.regen)return{k:"link",name:"Sambung"};
        return{k:"boost",name:"Boost"};
    }

    function cdInfo2(o){
        if(dimension&&(dimension.g===o)){
            const left=Math.max(0,dimension.dur-dimension.t);
            return{ready:false,active:true,frac:left/dimension.dur,txt:Math.ceil(left)};
        }
        const r=!(o.mcd2>0);
        return{
            ready:r,
            frac:1-Math.min(1,(o.mcd2||0)/(o.mcdMax2||1)),
            txt:r?"":Math.ceil(o.mcd2)
        };
    }

    function ctlBody(p){
        return (p&&p.possessing&&p.possessing.hp>0)?p.possessing:p;
    }

    function cycleLink(o){
        const mates=objects.filter(x=>x.type==="character"&&x!==o&&x.team===o.team&&x.hp>0);
        if(!mates.length)return;
        let i=mates.indexOf(o.regenLink);
        o.regenLink=mates[(i+1)%mates.length];
        o.linkT=2;
        burstParticles(o.regenLink.x,o.regenLink.y,14,"heal");
        snd("heal");
    }

    function cdInfo(o){

        const s=SKILLS[o.skill]||{};
        const k=abilityOf(o).k;

        if(o.sealTimer>0){
            return{ready:false,frac:o.sealTimer/10,txt:"🔒"+Math.ceil(o.sealTimer)};
        }

        if(k==="clone"){
            const r=!o.manualCloneDone;
            return{ready:r,frac:1,txt:r?"":"✓"};
        }

        if(k==="dead"){
            const t=s.deadSurviveTime||10;
            const left=Math.max(0,t-(o.deadSurvive||0));
            const done=!!o.deadTriggered;
            const r=!done&&left<=.1;
            return{
                ready:r,
                frac:done?1:1-left/t,
                txt:done?"✓":(r?"":Math.ceil(left))
            };
        }

        if(k==="golden"){

            return{
                ready:!o.fateUsed,
                frac:o.fateUsed?0:1,
                txt:o.fateUsed?"✖":""
            };

        }

        if(k==="time"&&timeFreeze){
            return{ready:false,active:true,frac:1,txt:"⏳"};
        }

        if(k==="boost"&&o.boostT>0){
            return{
                ready:false,
                active:true,
                frac:o.boostT/4,
                txt:Math.ceil(o.boostT)
            };
        }

        const r=o.mcd<=0;

        return{
            ready:r,
            frac:1-Math.min(1,o.mcd/(o.mcdMax||1)),
            txt:r?"":Math.ceil(o.mcd)
        };

    }

    function ctlPlayer(){
        return vsOn()?vs.me:rank.player;
    }

    function useSkill(){

        if(vsOn()){

            if(vs.role==="guest"){
                if(vs.inDuel&&vs.cdRemote&&vs.cdRemote.ready)vsSend({t:"sk"});
                return;
            }

            if(!vs.inDuel)return;

            if(vs.me.possessedBy)return;

            useSkillFor(ctlBody(vs.me));

            return;

        }

        if(!rank.inDuel)return;

        if(rank.player&&rank.player.possessedBy)return;

        useSkillFor(ctlBody(rank.player));

    }

    function useSkill2(){

        if(vsOn()){

            if(vs.role==="guest"){
                if(vs.inDuel&&vs.cdRemote2&&vs.cdRemote2.ready)vsSend({t:"sk2"});
                return;
            }

            if(!vs.inDuel)return;

            useSkillFor2(vs.me);

            return;

        }

        if(!rank.inDuel)return;

        useSkillFor2(rank.player);

    }

    function useSkillFor2(o){

        if(
            !o||
            !o.manual||
            o.hp<=0||
            !duelMode||
            timeFreeze||
            o.possessedBy||
            o.ghostIn
        )return;

        const s=SKILLS[o.skill]||{};

        if(!s.ghostSkill)return;

        if(o.mcd2>0)return;

        if(!manaHas(o,60)){
            o.manaFlashT=.6;
            return;
        }

        if(castDimension(o)){
            o.mcd2=o.mcdMax2=s.dimCooldownMax||20;
            manaPay(o,60);
        }

    }

    function useSkillFor(o){

        if(
            !o||
            !o.manual||
            o.hp<=0||
            !duelMode||
            timeFreeze
        )return;

        if(!cdInfo(o).ready)return;

        const s=SKILLS[o.skill]||{};
        const k=abilityOf(o).k;

        const mc=(k==="link")?0:manaCost(k);

        if(mc&&!manaHas(o,mc)){
            o.manaFlashT=.6;
            return;
        }

        const mcd0=o.mcd;

        audio();

        if(k==="time"){
            triggerTimeSkill(o);
            o.mcd=o.mcdMax=s.timeCooldownMax||10;
        }
        else if(k==="hole"){
            spawnBlackHole(o);
            o.mcd=o.mcdMax=s.holeCooldownMax||8;
        }
        else if(k==="hunter"){
            triggerHunterBarrage(o);
            o.mcd=o.mcdMax=s.hunterCooldownMax||8;
        }
        else if(k==="phase"){
            ultFx(o.x,o.y,"phase",o.team);
            o.shield=35;
            o.shieldTimer=5;
            burstParticles(o.x,o.y,15,"shield");
            snd("phase");
            o.mcd=o.mcdMax=10;
        }
        else if(k==="clone"){
            o.manualCloneDone=true;
            o.cloneUsed=false;
            createClones(o);
        }
        else if(k==="dead"){
            o.deadTriggered=true;
            triggerDeadUltimate(o);
        }
        else if(k==="golden"){
            fateStrike(o);
        }
        else if(k==="hipo"){
            if(castSeal(o))o.mcd=o.mcdMax=s.hipoCooldownMax||14;
        }
        else if(k==="nuke"){
            startRadiation(o);
            o.mcd=o.mcdMax=s.nukeCooldownMax||12;
        }
        else if(k==="lsteal"){
            startLifeZone(o);
            o.mcd=o.mcdMax=s.lsCooldownMax||6;
        }
        else if(k==="ice"){
            startIce(o);
            o.mcd=o.mcdMax=s.iceCooldownMax||25;
        }
        else if(k==="slash"){
            if(castSlash(o))o.mcd=o.mcdMax=s.samCooldownMax||15;
        }
        else if(k==="possess"){
            if(castPossess(o))o.mcd=o.mcdMax=s.possessCooldownMax||15;
        }
        else if(k==="link"){
            ultFx(o.x,o.y,"regen",o.team);
            cycleLink(o);
        }
        else if(k==="sniper"){
            triggerSniperPierce(o);
            o.mcd=o.mcdMax=s.sniperCooldownMax||10;
        }
        else{
            ultFx(o.x,o.y,o.skill,o.team);
            o.boostT=4;
            o.mcd=o.mcdMax=10;
            snd("boost");
            burstParticles(o.x,o.y,18,"heal");
        }

        if(mc){
            const done=(o.mcd>mcd0+.5)||k==="clone"||k==="dead"||k==="golden";
            if(done)manaPay(o,mc);
        }

    }

    const sbtn=$("skillBtn");

    sbtn.addEventListener("pointerdown",e=>{
        e.preventDefault();
        useSkill();
    });

    let hudRun=false;

    let hudSkill=null;

    const sbtn2=$("skillBtn2");

    sbtn2.addEventListener("pointerdown",e=>{
        e.preventDefault();
        useSkill2();
    });

    function startHud(){

        hudSkill=null;

        if(hudRun)return;

        hudRun=true;

        (function loop(){

            if(!body.classList.contains("manualOn")){
                hudRun=false;
                return;
            }

            const o=ctlPlayer();

            if(o&&o.hp<=0){
                body.classList.remove("manualOn");
                hudRun=false;
                return;
            }

            if(o){

                let i,i2=null,bs;

                if(vsOn()&&vs.role==="guest"){
                    i=vs.cdRemote||{frac:0,ready:false,txt:""};
                    i2=vs.cdRemote2||null;
                    bs=vs.bodySkill||o.skill;
                }
                else{
                    const b=ctlBody(o);
                    i=cdInfo(b);
                    bs=b.skill;
                    i2=(SKILLS[b.skill]&&SKILLS[b.skill].ghostSkill)?cdInfo2(b):null;
                }

                if(hudSkill!==bs){
                    hudSkill=bs;
                    $("sbIcon").textContent=SKILLS[bs].icon;
                    $("sbLabel").textContent=abilityOf({skill:bs}).name;
                }

                sbtn.style.setProperty("--p",i.frac);
                const mb=(vsOn()&&vs.role==="guest")?null:ctlBody(o);
                const mOK=!mb||manaHas(mb,abilityOf(mb).k==="dead"?100:(abilityOf(mb).k==="link"?0:60));

                if(mb){
                    $("manaFill").style.width=Math.round(manaOf(mb))+"%";
                    $("manaTxt").textContent="⚡ "+Math.floor(manaOf(mb));
                    $("manaHud").classList.toggle("warn",mb.manaFlashT>0);
                }

                $("manaHud").style.display=mb?"":"none";

                sbtn.classList.toggle("nomana",!mOK);
                sbtn2.classList.toggle("nomana",!!mb&&!manaHas(mb,60));
                sbtn.classList.toggle("ready",!!i.ready&&mOK);
                sbtn.classList.toggle("active",!!i.active);

                $("sbTxt").textContent=i.txt;

                body.classList.toggle("hasSk2",!!i2);

                if(i2){
                    sbtn2.style.setProperty("--p",i2.frac);
                    sbtn2.classList.toggle("ready",!!i2.ready);
                    sbtn2.classList.toggle("active",!!i2.active);
                    $("sb2Txt").textContent=i2.txt;
                }

            }

            requestAnimationFrame(loop);

        })();

    }

    /* dipanggil game loop tiap frame untuk karakter manual */

    window.manualPre=function(o,dt){

        if(!(rank.active||vsOn())||!o.manual)return;

        const s=SKILLS[o.skill]||{};

        if(o.mcd>0)o.mcd=Math.max(0,o.mcd-dt);

        if(o.mcd2>0)o.mcd2=Math.max(0,o.mcd2-dt);

        if(s.ghostSkill){
            o.ghostCooldown=1e9;
            o.dimCooldown=1e9;
        }

        /* matikan trigger otomatis, diganti tombol */

        if(s.timeSkill)o.timeCooldown=1e9;
        if(s.holeSkill)o.holeCooldown=1e9;
        if(s.hunterSkill)o.hunterCooldown=1e9;
        if(s.hipoSkill)o.hipoCooldown=1e9;
        if(s.sniperSkill)o.sniperCooldown=1e9;
        if(s.nukeSkill)o.nukeCooldown=1e9;
        if(s.lifestealZone)o.lsCooldown=1e9;
        if(s.iceSkill)o.iceCooldown=1e9;
        if(s.samuraiSkill)o.samCooldown=1e9;

        if(s.deadSkill){
            const t=s.deadSurviveTime||10;
            if(o.deadSurvive>t-.05)o.deadSurvive=t-.05;
        }

        if(s.clone)o.cloneUsed=true;

        if(s.phase&&o.shield<=5){
            o.shield=0;
            if(o.shieldTimer<=5.2)o.shieldTimer=6;
        }

        /* boost (skill pasif) */

        if(o.boostT>0){

            o.boostT-=dt;

            o.fireCooldown-=dt;

            o.speedBoost=Math.max(o.speedBoost,1.4);
            o.damageBoost=Math.max(o.damageBoost,1.3);

            if(o.boostT<=0){
                o.boostT=0;
                if(o.speedBoost<=1.41)o.speedBoost=1;
                if(o.damageBoost<=1.31)o.damageBoost=1;
            }

        }

        /* gerak dari analog */

        const pulled=blackholes.some(h=>
            !h.exploded&&
            h.team!==o.team&&
            Math.hypot(h.x-o.x,h.y-o.y)<(h.pullRadius||0)
        );

        if(!(o.stunTimer>0)&&!pulled){

            const gh=o.possessedBy;

            if(!(gh&&!gh.humanCtl)){

                const src=gh||o;

                const inp=src.netRemote?(src.remoteInput||{x:0,y:0}):getInput();

                o.vx=inp.x*170;

                o.vy=inp.y*170;

            }

        }

    };

    /* di mode ranked, karakter tidak bisa ditarik/diedit dari canvas */

    ["pointerdown","pointermove","pointerup"].forEach(t=>{
        window.addEventListener(t,e=>{
            if(
                body.classList.contains("ranked")&&
                e.target===document.getElementById("game")
            )e.stopPropagation();
        },true);
    });


    /* ---------- PENGATURAN: GRAFIK & FPS ---------- */

    const QUALITY={
        low:{ui:"low",dpr:1,particles:.25,shadow:0,fx:0,motes:0},
        medium:{ui:"med",dpr:1.25,particles:.5,shadow:.3,fx:1,motes:0},
        high:{ui:"high",dpr:1.5,particles:.7,shadow:.5,fx:2,motes:22},
        vhigh:{ui:"vhigh",dpr:2,particles:1.1,shadow:.8,fx:3,motes:40,rich:true},
        ultra:{ui:"ultra",dpr:3,particles:1.4,shadow:1,fx:3,motes:60,rich:true,ultra:true}
    };

    const Q_DESC={
        low:"Efek sangat tipis dan UI tanpa animasi. Paling ringan.",
        medium:"Efek arena sedang, resolusi dikurangi sedikit. Seimbang.",
        high:"Efek arena lengkap. Tampilan standar game.",
        vhigh:"Efek detail: bayangan kontak, aura skill, gelombang kejut, jejak peluru. Warna kalem, partikel secukupnya.",
        ultra:"Tampilan tertinggi: cahaya lembut, vignette sinematik, detail penuh, resolusi native. Butuh HP kencang."
    };

    const RES_T={auto:0,"1080":1920,"1440":2560,"2160":3840};

    const RES_NEED={"1080":"high","1440":"vhigh","2160":"ultra"};

    const RES_DESC={
        auto:"Resolusi mengikuti layar dan tingkat grafis.",
        "1080":"Full HD: render 1920 piksel. Tajam dan seimbang.",
        "1440":"2K: render 2560 piksel. Garis dan karakter jauh lebih halus.",
        "2160":"4K: render 3840 piksel. Paling tajam, butuh HP sangat kencang."
    };

    const settings={q:"high",fps:60,force:false,potato:false,potatoSet:false,res:"auto",showFps:false,prem:{on:false,chip:12,ram:8}};

    /* ---------- PENGECEKAN HP (MINIMAL SPESIFIKASI) ---------- */

    function gpuName(){

        if(window.__TDS_GPU)return String(window.__TDS_GPU);

        try{

            const c=document.createElement("canvas");

            const gl=c.getContext("webgl")||c.getContext("experimental-webgl");

            if(!gl)return "";

            const e=gl.getExtension("WEBGL_debug_renderer_info");

            const r=e?gl.getParameter(e.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER);

            const l=gl.getExtension("WEBGL_lose_context");

            if(l)l.loseContext();

            return String(r||"");

        }catch(e){return "";}

    }

    /* GPU kelas Helio P22 ke bawah: PowerVR GE8xxx/SGX, Mali-400/450/T-series/G31, Adreno <= 505 */

    const LITE_GPU=/PowerVR|Mali-(400|450|T\d+|G31)\b|Adreno[^0-9]*(2\d\d|3\d\d|4\d\d|50[0-5])\b/i;

    const GPU_NAME=gpuName();

    const LITE_HW=LITE_GPU.test(GPU_NAME)||(navigator.deviceMemory&&navigator.deviceMemory<=1)?true:false;

    let LITE=LITE_HW;

    window.TDS_LITE=LITE;

    /* ---------- v1.00: SET EDIT PREMIUM (simulasi chipset + RAM) ---------- */

    const PREM_CHIPS=[
        ["Helio P22 / Helio G35","low"],
        ["Snapdragon 439 / Unisoc T310","low"],
        ["Helio G85 / G88","medium"],
        ["Snapdragon 680 / 685","medium"],
        ["Snapdragon 720G / 732G","medium"],
        ["Helio G99 / Dimensity 700","high"],
        ["Snapdragon 778G / 7 Gen 1","high"],
        ["Dimensity 8100 / 8200","vhigh"],
        ["Snapdragon 870 / 888","vhigh"],
        ["Snapdragon 8 Gen 1 / 8 Gen 2","vhigh"],
        ["Snapdragon 8 Gen 3","ultra"],
        ["Snapdragon 8 Elite","ultra"],
        ["Snapdragon 8 Elite Gen 5","ultra"],
        ["Dimensity 9300 / 9400","ultra"],
        ["Apple A17 Pro / A18 Pro","ultra"]
    ];

    const PREM_RAMS=[4,6,8,12,16];

    function ramOK(){
        const m=(window.__TDS_RAM!==undefined)?window.__TDS_RAM:navigator.deviceMemory;
        return !m||m>=4;
    }

    function premActive(){
        return !!(settings.prem&&settings.prem.on&&ramOK());
    }

    function premTier(){
        const pr=settings.prem||{};
        const c=PREM_CHIPS[Math.max(0,Math.min(PREM_CHIPS.length-1,pr.chip|0))];
        const ct=Q_ORDER_P.indexOf(c[1]);
        const ram=pr.ram||8;
        const rt=ram>=8?4:ram>=6?3:2;
        return Q_ORDER_P[Math.min(ct,rt)];
    }

    const Q_ORDER_P=["low","medium","high","vhigh","ultra"];

    function syncLite(){
        LITE=LITE_HW&&!premActive();
        window.TDS_LITE=LITE;
        document.body.classList.toggle("lite",LITE);
        const n=document.getElementById("liteNote");
        if(n){
            n.style.display=LITE?"block":"none";
            n.textContent="📱 HP terdeteksi di bawah spesifikasi minimum. Game berjalan di MODE LITE: grafis Kentang dan 30 FPS (tidak bisa diubah).";
        }
    }

    try{
        const sv=JSON.parse(st.get("tds_settings")||"null");
        if(sv&&QUALITY[sv.q])settings.q=sv.q;
        if(sv&&Number.isFinite(sv.fps))settings.fps=Math.max(30,Math.min(60,Math.round(sv.fps)));
        if(sv&&RES_T[sv.res]!==undefined)settings.res=sv.res;
        if(sv&&sv.force===true)settings.force=true;
        if(sv&&sv.potato===true)settings.potato=true;
        if(sv&&sv.potatoSet===true)settings.potatoSet=true;
        if(sv&&sv.showFps===true)settings.showFps=true;
        if(sv&&sv.prem&&typeof sv.prem==="object")settings.prem={on:sv.prem.on===true,chip:Math.max(0,Math.min(PREM_CHIPS.length-1,sv.prem.chip|0)),ram:PREM_RAMS.includes(sv.prem.ram)?sv.prem.ram:8};
    }catch(e){}

    syncLite();

    /* HP kentang: nyalakan Mode Hemat otomatis di perangkat lemah (RAM kecil / core sedikit) */

    if(!settings.potatoSet){
        const mem=navigator.deviceMemory||0,cores=navigator.hardwareConcurrency||0;
        if((mem&&mem<=2)||(cores&&cores<=4&&mem&&mem<=3)){
            settings.potato=true;
            settings.fps=Math.min(settings.fps,30);
        }
    }

    const POTATO_Q=Object.assign({},QUALITY.low,{dpr:.75,particles:.12});

    if(LITE){
        settings.potato=true;
        settings.potatoSet=true;
        settings.fps=30;
        settings.q="low";
        settings.force=false;
        settings.res="auto";
    }

    let Q=QUALITY[settings.q];

    const sbDesc=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,"shadowBlur");
    const scDesc=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,"shadowColor");

    function setShadowMode(f){

        delete ctx.shadowBlur;
        delete ctx.shadowColor;

        if(f===1)return;

        Object.defineProperty(ctx,"shadowBlur",{
            configurable:true,
            get(){return sbDesc.get.call(this)},
            set(v){sbDesc.set.call(this,v*f)}
        });

        if(f===0){
            Object.defineProperty(ctx,"shadowColor",{
                configurable:true,
                get(){return scDesc.get.call(this)},
                set(v){scDesc.set.call(this,"rgba(0,0,0,0)")}
            });
        }

    }

    const origBurst=window.burstParticles;

    window.burstParticles=function(x,y,amount,type){
        if(particles.length>(Q.ultra?650:(Q.rich?420:240)))return;
        const a=(amount===undefined?15:amount);
        const n0=particles.length;
        const tp=type===undefined?"hit":type;
        const r=origBurst(
            x,
            y,
            Math.max(1,Math.round(a*Q.particles*(window.perfScale||1))),
            tp
        );
        if(Q.rich)richTag(n0,x,y,a,tp);
        return r;
    };

    let nextT=0,gLast=0,gEma=0,gBad=0,gGood=0;

    window.perfScale=1;

    window.fpsGate=function(time){

        /* layar menu menutupi game: tidak perlu menggambar */

        if(
            overlayOpen||
            $("auth").style.display==="flex"||
            $("loader").style.display!=="none"||
            $("intro").style.display==="flex"
        )return true;

        const iv=1000/settings.fps;

        if(time<nextT-4)return true;

        nextT=(time-nextT>iv*2)?time+iv:nextT+iv;

        fpsTick();

        /* penjaga performa: kalau frame sering telat, kurangi partikel sementara; naikkan lagi kalau lancar */

        if(gLast){
            const r=Math.min(4,(time-gLast)/iv);
            gEma=gEma?gEma*.9+r*.1:r;
            if(gEma>1.3){gBad++;gGood=0;}
            else if(gEma<1.1){gGood++;gBad=0;}
            else{gBad=0;gGood=0;}
            if(gBad>40){window.perfScale=Math.max(.35,(window.perfScale||1)-.15);gBad=0;}
            if(gGood>240){window.perfScale=Math.min(1,(window.perfScale||1)+.1);gGood=0;}
        }

        gLast=time;

        return false;

    };

/* ---------- v1.8: DETEKSI HP (REFRESH RATE & PERFORMA) ---------- */

    const Q_ORDER=["low","medium","high","vhigh","ultra"];

    const Q_NAME={low:"Rendah",medium:"Medium",high:"High",vhigh:"Very High",ultra:"Ultra High"};

    const TIER_NAME={low:"Rendah",medium:"Sedang",high:"Tinggi",vhigh:"Sangat Tinggi",ultra:"Flagship"};

    const dev={hz:60,tier:"ultra",score:0,ready:false,busy:false};

    const DEV_KEY="tds_device";

    function devSig(){
        return (navigator.userAgent||"")+"|"+screen.width+"x"+screen.height;
    }

    try{
        const dc=JSON.parse(st.get(DEV_KEY)||"null");
        if(dc&&dc.sig===devSig()&&Q_ORDER.includes(dc.tier)&&Date.now()-dc.ts<30*864e5){
            dev.hz=dc.hz;dev.tier=dc.tier;dev.score=dc.score||0;dev.ready=true;
        }
    }catch(e){}

    function qAllowed(k){
        if(settings.force)return true;
        if(premActive())return Q_ORDER.indexOf(k)<=Q_ORDER.indexOf(premTier());
        return !dev.ready||Q_ORDER.indexOf(k)<=Q_ORDER.indexOf(dev.tier);
    }

    function fpsAllowed(f){
        if(LITE)return f===30;
        return f>=30&&f<=60;
    }

    function resAllowed(r){
        if(LITE)return r==="auto";
        if(r==="auto")return true;
        return qAllowed(RES_NEED[r]);
    }

    function clampSettings(){
        if(!qAllowed(settings.q))settings.q=Q_ORDER.slice().reverse().find(qAllowed)||"low";
        settings.fps=LITE?30:Math.max(30,Math.min(60,Math.round(settings.fps)||60));
        if(!resAllowed(settings.res))settings.res="auto";
    }

    function measureHz(cb){
        const ts=[];
        let last=0;
        const t0=performance.now();
        function f(t){
            if(last)ts.push(t-last);
            last=t;
            if(ts.length<50&&performance.now()-t0<2500)requestAnimationFrame(f);
            else done();
        }
        function done(){
            if(ts.length<8){cb(60,false);return;}
            ts.sort((a,b)=>a-b);
            const hz=1000/ts[Math.floor(ts.length*.25)];
            cb(hz>=132?144:hz>=105?120:hz>=75?90:hz>=45?60:30,true);
        }
        requestAnimationFrame(f);
    }

    function benchScore(){
        const t0=performance.now();
        let x=0;
        for(let i=0;i<2500000;i++)x+=Math.sqrt(i)*Math.sin(i);
        dev._x=x;
        const cpu=performance.now()-t0;
        const c=document.createElement("canvas");
        c.width=c.height=320;
        const g=c.getContext("2d");
        const t1=performance.now();
        for(let r=0;r<10;r++){
            for(let i=0;i<40;i++){
                const px=(i*53+r*17)%300+10,py=(i*31+r*23)%300+10;
                const gr=g.createRadialGradient(px,py,2,px,py,34);
                gr.addColorStop(0,"rgba(120,170,255,.9)");
                gr.addColorStop(1,"rgba(120,170,255,0)");
                g.fillStyle=gr;
                g.shadowColor="#4d8dff";
                g.shadowBlur=18;
                g.beginPath();
                g.arc(px,py,26,0,Math.PI*2);
                g.fill();
            }
            g.globalCompositeOperation="lighter";
            g.drawImage(c,0,0,160,160);
            g.globalCompositeOperation="source-over";
        }
        g.getImageData(0,0,1,1);
        const draw=performance.now()-t1;
        return cpu+draw;
    }

    function tierOf(score){
        let i=score<TH[0]?4:score<TH[1]?3:score<TH[2]?2:score<TH[3]?1:0;
        const mem=navigator.deviceMemory||0;
        const cores=navigator.hardwareConcurrency||0;
        if(mem&&mem<=2)i=Math.min(i,1);
        else if(mem&&mem<=3)i=Math.min(i,2);
        if(cores&&cores<=4)i=Math.min(i,3);
        return Q_ORDER[i];
    }

    const TH=[80,160,320,640];

    function runDetect(){
        if(dev.busy)return;
        dev.busy=true;
        renderSettings();
        measureHz((hz,ok)=>{
            setTimeout(()=>{
                const sc=benchScore();
                dev.hz=hz;
                dev.score=Math.round(sc);
                dev.tier=tierOf(sc);
                dev.ready=true;
                dev.busy=false;
                if(ok)st.set(DEV_KEY,JSON.stringify({hz:dev.hz,tier:dev.tier,score:dev.score,sig:devSig(),ts:Date.now()}));
                clampSettings();
                if(LITE){
                    dev.tier="low";
                }
                if(dev.tier==="low"&&!settings.potatoSet&&!premActive()){
                    settings.potato=true;
                    settings.fps=Math.min(settings.fps,30);
                }
                applySettings();
            },60);
        });
    }

    let devMsgT=0;

    function devFlash(t){
        $("devMsg").textContent=t;
        clearTimeout(devMsgT);
        devMsgT=setTimeout(()=>{$("devMsg").textContent="";},3200);
    }

    /* ---------- v1.8: POST-FX ULTRA HIGH ---------- */

    let bloomA=null,bloomB=null,bloomKey="";

    let vigKey="",vigGrad=null;

    /* bayangan kontak halus di bawah karakter (detail tambahan) */

    const _drawChar=window.drawCharacter;

    window.drawCharacter=function(o){

        if(Q.fx>=2&&!window.POTATO&&o.hp>0&&!(typeof dimension!=="undefined"&&dimension)){

            ctx.save();

            const g=ctx.createRadialGradient(o.x,o.y+24,2,o.x,o.y+24,30);

            g.addColorStop(0,"rgba(0,0,0,.32)");
            g.addColorStop(1,"rgba(0,0,0,0)");

            ctx.fillStyle=g;

            ctx.translate(o.x,o.y+24);
            ctx.scale(1,.32);
            ctx.translate(-o.x,-(o.y+24));

            ctx.beginPath();
            ctx.arc(o.x,o.y+24,30,0,Math.PI*2);
            ctx.fill();

            ctx.restore();

        }

        return _drawChar(o);

    };

    /* warna kalem: turunkan kecerahan & kontras sedikit (hemat, 1 fillRect) */

    const _postFX=null;

    function gradeFX(){

        ctx.save();

        ctx.fillStyle="rgba(42,50,68,.16)";

        ctx.fillRect(0,0,W,H);

        ctx.restore();

    }

    window.postFX=function(){

        gradeFX();

        if(!Q.ultra||(window.perfScale||1)<.6)return;

        const t=performance.now()/1000;

        ctx.save();

        /* cahaya lembut di bawah karakter & peluru */

        ctx.globalCompositeOperation="lighter";

        for(let i=0;i<objects.length;i++){

            const o=objects[i];

            if(o.type!=="character"||o.hp<=0)continue;

            const blue=(o.team==="blue");

            const g=ctx.createRadialGradient(o.x,o.y,4,o.x,o.y,92);

            g.addColorStop(0,blue?"rgba(90,150,255,.13)":"rgba(255,90,120,.13)");

            g.addColorStop(1,"rgba(0,0,0,0)");

            ctx.fillStyle=g;

            ctx.fillRect(o.x-92,o.y-92,184,184);

        }

        for(let i=0;i<bullets.length;i++){

            const b=bullets[i];

            if(b.x===undefined)continue;

            const g=ctx.createRadialGradient(b.x,b.y,1,b.x,b.y,20);

            g.addColorStop(0,"rgba(255,240,200,.55)");

            g.addColorStop(1,"rgba(255,200,120,0)");

            ctx.fillStyle=g;

            ctx.fillRect(b.x-20,b.y-20,40,40);

        }

        /* sinar cahaya bergerak pelan */

        for(let i=0;i<3;i++){

            const x=W*(.2+.3*i)+Math.sin(t*.25+i*2)*W*.08;

            ctx.save();

            ctx.translate(x,0);

            ctx.rotate(.38);

            const g=ctx.createLinearGradient(-50,0,50,0);

            g.addColorStop(0,"rgba(150,190,255,0)");

            g.addColorStop(.5,"rgba(150,190,255,"+(.05+.025*Math.sin(t*.7+i))+")");

            g.addColorStop(1,"rgba(150,190,255,0)");

            ctx.fillStyle=g;

            ctx.fillRect(-50,-H*.25,100,H*1.6);

            ctx.restore();

        }

        /* bloom: perkecil frame, ambil bagian terang, tambahkan lagi */

        const key=canvas.width+"x"+canvas.height;

        if(key!==bloomKey||!bloomA){

            bloomKey=key;

            bloomA=document.createElement("canvas");
            bloomA.width=Math.max(8,canvas.width>>3);
            bloomA.height=Math.max(8,canvas.height>>3);

            bloomB=document.createElement("canvas");
            bloomB.width=Math.max(4,canvas.width>>4);
            bloomB.height=Math.max(4,canvas.height>>4);

        }

        const ba=bloomA.getContext("2d");
        const bb=bloomB.getContext("2d");

        ba.setTransform(1,0,0,1,0,0);
        ba.globalCompositeOperation="copy";

        try{ba.filter="brightness(.95) contrast(2.4) saturate(1.5)";}catch(e){}

        ba.drawImage(canvas,0,0,bloomA.width,bloomA.height);

        try{ba.filter="none";}catch(e){}

        bb.setTransform(1,0,0,1,0,0);
        bb.globalCompositeOperation="copy";
        bb.imageSmoothingEnabled=true;
        bb.drawImage(bloomA,0,0,bloomB.width,bloomB.height);

        ctx.setTransform(1,0,0,1,0,0);
        ctx.imageSmoothingEnabled=true;
        try{ctx.imageSmoothingQuality="high";}catch(e){}

        ctx.globalCompositeOperation="screen";

        ctx.globalAlpha=.3;
        ctx.drawImage(bloomB,0,0,canvas.width,canvas.height);

        ctx.globalAlpha=.16;
        ctx.drawImage(bloomA,0,0,canvas.width,canvas.height);

        /* vignette sinematik */

        ctx.setTransform(dpr,0,0,dpr,0,0);

        ctx.globalCompositeOperation="source-over";

        ctx.globalAlpha=1;

        const vk=W+"x"+H;

        if(vk!==vigKey||!vigGrad){

            vigKey=vk;

            vigGrad=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.34,W/2,H/2,Math.hypot(W,H)*.6);

            vigGrad.addColorStop(0,"rgba(3,6,18,0)");

            vigGrad.addColorStop(1,"rgba(3,6,18,.52)");

        }

        ctx.fillStyle=vigGrad;

        ctx.fillRect(0,0,W,H);

        ctx.restore();

    };

    function renderSettings(){

        document.querySelectorAll("#qSeg button").forEach(b=>{
            b.classList.toggle("on",b.dataset.q===settings.q);
        });

        document.querySelectorAll("#rSeg button").forEach(b=>{
            const lk=!resAllowed(b.dataset.r);
            b.classList.toggle("on",b.dataset.r===settings.res);
            b.classList.toggle("lock",lk);
            const nm={auto:"Auto","1080":"Full HD","1440":"2K","2160":"4K"}[b.dataset.r];
            b.textContent=(lk?"🔒 ":"")+nm;
        });

        $("rDesc").textContent=RES_DESC[settings.res];

        $("fRange").value=settings.fps;
        $("fVal").textContent=settings.fps+(LITE?" (dikunci)":"");

        $("liteSet").style.display=LITE?"block":"none";

        $("qDesc").textContent=Q_DESC[settings.q];

        document.querySelectorAll("#qSeg button").forEach(b=>{
            const lk=!qAllowed(b.dataset.q);
            b.classList.toggle("lock",lk);
            const nm=b.dataset.q==="ultra"?"✨ Ultra High":Q_NAME[b.dataset.q];
            b.textContent=(lk?"🔒 ":"")+nm;
        });

        const di=$("devInfo");

        if(di){

            if(dev.busy)di.textContent="Sedang mendeteksi HP… (sebentar)";
            else if(!dev.ready)di.textContent="Belum terdeteksi. Ketuk Deteksi ulang.";
            else{
                const maxQ=Q_ORDER.slice().reverse().find(qAllowed);
                if(premActive()){const pr=settings.prem;di.textContent="💎 PREMIUM: disimulasikan "+PREM_CHIPS[pr.chip][0]+" + "+pr.ram+"GB RAM\nLayar: "+dev.hz+" Hz  •  Grafik maksimal: "+Q_NAME[Q_ORDER.slice().reverse().find(qAllowed)]+"  •  FPS: 30–60";}
                else di.textContent="Layar: "+dev.hz+" Hz  •  Performa: "+TIER_NAME[dev.tier]+" (skor "+dev.score+")\nGrafik maksimal: "+Q_NAME[maxQ]+"  •  FPS: 30–60"+(LITE?" (Lite: 30 dikunci)":"")+(settings.force?"\n🔥 Mode Paksa aktif: semua opsi terbuka.":"\n🔒 = belum didukung HP-mu.");
            }

            $("devRe").disabled=dev.busy;

            $("devPotato").textContent=settings.potato?"🥔 Mode Hemat HP Kentang: AKTIF":"🥔 Mode Hemat HP Kentang: MATI";

            $("devPotato").classList.toggle("on",!!settings.potato);

            $("devForce").textContent=settings.force?"🔥 Mode Paksa: AKTIF":"🔓 Mode Paksa: MATI";

            $("devForce").classList.toggle("on",!!settings.force);

            renderPrem();

            $("fpsBtn").textContent=settings.showFps?"📊 Tampilkan FPS: AKTIF":"📊 Tampilkan FPS: MATI";

            $("fpsBtn").classList.toggle("on",!!settings.showFps);

        }

    }

    function applySettings(){

        Q=settings.potato?POTATO_Q:QUALITY[settings.q];

        window.POTATO=!!settings.potato;

        window.noUltFx=!!settings.potato;

        body.classList.toggle("potato",!!settings.potato);

        body.classList.remove("q-low","q-med","q-high","q-vhigh","q-ultra");
        body.classList.add("q-"+Q.ui);

        window.dprCap=Q.dpr;

        window.resTarget=settings.potato?0:(RES_T[settings.res]||0);

        try{resize()}catch(e){}

        setShadowMode(Q.shadow);

        window.maxDt=Math.max(.035,2.2/settings.fps);

        if(!settings.showFps)$("fpsShow").style.display="none";

        st.set("tds_settings",JSON.stringify(settings));

        renderSettings();

        refreshTony();

    }

    document.querySelectorAll("#qSeg button").forEach(b=>{
        b.onclick=()=>{
            if(!qAllowed(b.dataset.q)){
                devFlash("🔒 "+Q_NAME[b.dataset.q]+" terkunci: performa HP-mu belum cukup.");
                return;
            }
            if(LITE){devFlash("📵 Mode Lite: grafis dikunci Kentang.");return;}
            settings.q=b.dataset.q;
            applySettings();
        };
    });

    document.querySelectorAll("#rSeg button").forEach(b=>{
        b.onclick=()=>{
            if(LITE){devFlash("📵 Mode Lite: resolusi dikunci.");return;}
            if(!resAllowed(b.dataset.r)){
                devFlash("🔒 Resolusi ini butuh grafis "+Q_NAME[RES_NEED[b.dataset.r]]+" ke atas (performa HP-mu belum cukup).");
                return;
            }
            settings.res=b.dataset.r;
            applySettings();
        };
    });

    $("fRange").oninput=()=>{
        if(LITE){$("fRange").value=30;return;}
        settings.fps=Math.max(30,Math.min(60,Number($("fRange").value)||60));
        $("fVal").textContent=settings.fps;
        window.maxDt=Math.max(.035,2.2/settings.fps);
    };

    $("fRange").onchange=()=>{
        if(LITE){devFlash("📵 Mode Lite: FPS dikunci 30.");return;}
        applySettings();
    };

    $("devPotato").onclick=()=>{
        if(LITE){devFlash("📵 Mode Lite: tidak bisa diubah.");return;}
        settings.potato=!settings.potato;
        settings.potatoSet=true;
        if(settings.potato){
            settings.fps=Math.min(settings.fps,30);
            devFlash("🥔 Mode Hemat aktif: efek berat dimatikan, 30 FPS.");
        }
        applySettings();
    };

    $("devRe").onclick=runDetect;

    /* ---- Set Edit Premium ---- */

    (function(){
        const cs=$("premChip"),rs=$("premRam");
        PREM_CHIPS.forEach((c,i)=>{const o=document.createElement("option");o.value=i;o.textContent=c[0];cs.appendChild(o);});
        PREM_RAMS.forEach(r=>{const o=document.createElement("option");o.value=r;o.textContent=r+" GB";rs.appendChild(o);});
    })();

    window.renderPrem=renderPrem;

    function renderPrem(){

        const on=premActive(),ok=ramOK();

        $("premBtn").textContent=!ok?"🔒 Set Edit Premium (butuh RAM 4GB+)":on?"💎 Set Edit Premium: AKTIF":"💎 Set Edit Premium: MATI";

        $("premBtn").classList.toggle("prem",on);

        $("premBox").style.display=on?"block":"none";

        $("premChip").value=String(settings.prem.chip);
        $("premRam").value=String(settings.prem.ram);

        $("premInfo").textContent="Hasil simulasi: grafis maksimal "+Q_NAME[premTier()]+".";

    }

    $("premBtn").onclick=()=>{

        if(!ramOK()){devFlash("🔒 Set Edit Premium hanya untuk HP dengan RAM 4GB ke atas.");return;}

        settings.prem.on=!settings.prem.on;

        syncLite();

        if(settings.prem.on){
            if(premTier()!=="low")settings.potato=false;
            settings.potatoSet=true;
            if(LITE_HW&&settings.fps<=30)settings.fps=60;
            devFlash("💎 Premium aktif: grafis terbuka sampai "+Q_NAME[premTier()]+".");
        }
        else{
            if(LITE_HW){
                settings.potato=true;settings.potatoSet=true;settings.fps=30;settings.q="low";settings.force=false;settings.res="auto";
            }
            devFlash("Premium dimatikan.");
        }

        clampSettings();
        applySettings();

    };

    function premChange(){
        settings.prem.chip=Number($("premChip").value)|0;
        settings.prem.ram=Number($("premRam").value)||8;
        if(premTier()!=="low")settings.potato=false;
        clampSettings();
        applySettings();
    }

    $("premChip").onchange=premChange;
    $("premRam").onchange=premChange;

    /* ---- FPS Show + penjaga performa ---- */

    let fpsN=0,fpsT=performance.now();

    window.fpsTick=function(){fpsN++;};

    $("fpsBtn").onclick=()=>{
        settings.showFps=!settings.showFps;
        applySettings();
    };

    setInterval(()=>{

        const el=$("fpsShow");

        if(!settings.showFps){el.style.display="none";fpsN=0;fpsT=performance.now();return;}

        const now=performance.now();
        const f=fpsN*1000/Math.max(1,now-fpsT);
        fpsN=0;fpsT=now;

        el.style.display="block";
        el.textContent=(f<1?"--":Math.round(f))+" FPS";
        el.className=f>=settings.fps*.9?"":f>=settings.fps*.6?"mid":"bad";

    },500);

    $("devForce").onclick=()=>{
        if(LITE){devFlash("📵 Mode Lite: tidak bisa diubah.");return;}
        settings.force=!settings.force;
        if(settings.force)devFlash("🔥 Semua grafis & FPS terbuka. Patah-patah = tanggung jawab sendiri.");
        else clampSettings();
        applySettings();
    };

    clampSettings();

    if(!dev.ready)setTimeout(runDetect,1800);

    function openSettings(){
        renderSettings();
        $("settings").style.display="flex";
    }

    $("btnSettings").onclick=openSettings;
    $("toSettings").onclick=openSettings;
    $("setClose").onclick=()=>{$("settings").style.display="none";};

    /* ---------- BERANDA: TONY ---------- */

    let tonyRun=false;
    let tonyLast=0;

    function drawTony(t){

        const cv=$("tonyCv");

        if(!cv)return;

        const c=cv.getContext("2d");

        c.clearRect(0,0,360,360);

        let g=c.createRadialGradient(180,300,5,180,300,130);
        g.addColorStop(0,"rgba(93,160,255,.45)");
        g.addColorStop(1,"rgba(93,160,255,0)");
        c.fillStyle=g;
        c.beginPath();
        c.ellipse(180,300,130,34,0,0,Math.PI*2);
        c.fill();

        c.strokeStyle="rgba(150,190,255,.5)";
        c.lineWidth=3;
        c.beginPath();
        c.ellipse(180,300,100,24,0,0,Math.PI*2);
        c.stroke();

        const bob=Math.sin(t*2)*6;

        c.save();

        c.translate(180,176+bob);
        c.scale(3.6,3.6);

        c.fillStyle="#5da0ff";
        c.beginPath();
        c.arc(0,0,24,0,Math.PI*2);
        c.fill();

        c.fillStyle="#f4c7a1";
        c.beginPath();
        c.arc(0,-7,12,0,Math.PI*2);
        c.fill();

        c.fillStyle="#202a40";
        c.fillRect(-14,5,28,18);

        c.save();

        c.rotate(-.25+Math.sin(t*1.3)*.22);

        c.strokeStyle="white";
        c.lineWidth=4;
        c.beginPath();
        c.moveTo(5,0);
        c.lineTo(35,0);
        c.stroke();

        const ph=t%2.4;

        if(ph<.12){
            c.fillStyle="#ffe08a";
            c.globalAlpha=1-ph/.12;
            c.beginPath();
            c.arc(40,0,7,0,Math.PI*2);
            c.fill();
        }

        c.restore();
        c.restore();

    }

    function tonyLoop(now){

        if($("menu").style.display!=="flex"){
            tonyRun=false;
            return;
        }

        if(now-tonyLast>=(1000/settings.fps)*.9){
            tonyLast=now;
            drawTony(now/1000);
            fpsTick();
        }

        requestAnimationFrame(tonyLoop);

    }

    function startTony(){

        if(Q.ui==="low"){
            drawTony(0);
            return;
        }

        if(tonyRun)return;

        tonyRun=true;

        requestAnimationFrame(tonyLoop);

    }

    function refreshTony(){

        if($("menu").style.display==="flex")startTony();

    }

    function homeRefresh(){

        updateWallet();
        updateBadge();

    }

    $("btnPlay").onclick=()=>{audio();renderModes();show("modes");};
    $("modesBack").onclick=showMenu;

    /* ---------- STORE ---------- */

    let buyReturn="rank";

    let storeTab="skill";

    function renderStore(){

        if(!profile)loadProfile();

        document.querySelectorAll("#stTabs button").forEach(b=>{
            b.classList.toggle("on",b.dataset.s===storeTab);
        });

        $("stSub").textContent=storeTab==="boost"
            ?"Booster dipakai sebelum main • dibeli dengan berlian 💎"
            :(storeTab==="topup"
                ?"Tukar berlian 💎 menjadi koin 🪙"
                :"Beli skill baru dengan koin");

        if(storeTab==="boost"){
            renderBoosterStore();
            return;
        }

        if(storeTab==="topup"){
            renderTopUp();
            return;
        }

        const list=$("storeList");

        list.innerHTML="";

        const owned=k=>profile.unlocked.includes(k);

        const note=document.createElement("div");

        note.className="limNote";

        note.innerHTML=
            '<span style="font-size:26px">🎁</span>'+
            '<div><b>⏳ Time, 🌟 GoldenTime &amp; 🌫️ Ghost — Item Terbatas</b>'+
            '<small>Tidak bisa dibeli. Silakan spin di menu Event 🎁</small></div>';

        list.appendChild(note);

        Object.keys(SKILLS).filter(k=>!LIMITED.includes(k)).sort((a,b)=>{
            const oa=owned(a)?1:0;
            const ob=owned(b)?1:0;
            if(oa!==ob)return oa-ob;
            return priceOf(a)-priceOf(b);
        }).forEach(k=>{

            const sk=SKILLS[k];
            const own=owned(k);

            const row=document.createElement("div");

            row.className="srow"+(own?" own":"");

            row.innerHTML=
                '<div class="si">'+sk.icon+'</div>'+
                '<div class="sb"><b>'+sk.name+'</b><small>'+(DESC[k]||"")+'</small></div>'+
                '<div class="sp">'+(own?"✓ Dimiliki":"🪙 "+priceOf(k))+'</div>';

            if(!own){
                row.onclick=()=>{buyReturn="store";openBuy(k);};
            }

            list.appendChild(row);

        });

        updateWallet();

    }

    $("btnStore").onclick=()=>{
        audio();
        renderStore();
        show("store");
    };

    $("storeBack").onclick=showMenu;

    /* ---------- HADIAH HARIAN ---------- */

    const DAILY=30;

    const MONTHS=[
        "Januari","Februari","Maret","April","Mei","Juni",
        "Juli","Agustus","September","Oktober","November","Desember"
    ];

    const pad2=n=>String(n).padStart(2,"0");
    const dstr=d=>d.getFullYear()+"-"+pad2(d.getMonth()+1)+"-"+pad2(d.getDate());
    const todayStr=()=>dstr(new Date());

    const yesterdayStr=()=>{
        const d=new Date();
        d.setDate(d.getDate()-1);
        return dstr(d);
    };

    function claimedToday(){
        return !!profile&&profile.lastClaim===todayStr();
    }

    function updateBadge(){
        $("calBadge").style.display=
            (profile&&!claimedToday()&&!isAdmin())?"flex":"none";

        updateInbBadge();
    }

    function renderCal(){

        const now=new Date();
        const y=now.getFullYear();
        const m=now.getMonth();

        $("calMonth").textContent=MONTHS[m]+" "+y;

        const grid=$("calGrid");

        let h="";

        ["Min","Sen","Sel","Rab","Kam","Jum","Sab"].forEach(n=>{
            h+='<div class="hd">'+n+'</div>';
        });

        const first=new Date(y,m,1).getDay();
        const days=new Date(y,m+1,0).getDate();

        for(let i=0;i<first;i++)h+='<div class="none"></div>';

        for(let d=1;d<=days;d++){

            const key=y+"-"+pad2(m+1)+"-"+pad2(d);

            let c="";

            if(profile.claimedDays.includes(key))c+=" got";
            if(d===now.getDate())c+=" today";

            h+='<div class="'+c.trim()+'">'+(profile.claimedDays.includes(key)?"✓":d)+'</div>';

        }

        grid.innerHTML=h;

        const streak=
            (profile.lastClaim===todayStr()||profile.lastClaim===yesterdayStr())
            ?profile.streak:0;

        $("calStreak").textContent=
            "🔥 Beruntun: "+streak+" hari • login tiap hari dapat "+DAILY+" 🪙";

        const btn=$("calClaim");

        if(isAdmin()){
            btn.disabled=true;
            btn.textContent="Admin: koin ∞";
        }
        else if(claimedToday()){
            btn.disabled=true;
            btn.textContent="Sudah diklaim ✓";
        }
        else{
            btn.disabled=false;
            btn.textContent="Klaim "+DAILY+" 🪙";
        }

    }

    function openCal(){

        if(!profile)loadProfile();

        $("calMsg").textContent="";

        renderCal();

        $("calBox").style.display="flex";

    }

    function claimDaily(){

        if(!profile||claimedToday()||isAdmin())return;

        const t=todayStr();

        profile.streak=(profile.lastClaim===yesterdayStr())?profile.streak+1:1;

        profile.lastClaim=t;

        profile.claimedDays.push(t);

        profile.claimedDays=profile.claimedDays.slice(-62);

        profile.coins+=DAILY;

        saveProfile();

        renderCal();

        updateWallet();

        updateBadge();

        $("calMsg").textContent="+"+DAILY+" 🪙 • Hari ke-"+profile.streak+" beruntun!";

    }

    $("btnCal").onclick=openCal;
    $("calClaim").onclick=claimDaily;
    $("calClose").onclick=()=>{$("calBox").style.display="none";};

    /* ---------- HIPO: SEGEL SKILL ---------- */

    const seals=[];

    function castSeal(o){
        const r=castSeal0(o);
        if(r)ultFx(o.x,o.y,"hipo",o.team);
        return r;
    }

    function castSeal0(o){

        const list=objects.filter(e=>
            e.type==="character"&&e.hp>0&&e.team!==o.team
        );

        if(!list.length)return false;

        const fresh=list.filter(e=>!(e.sealTimer>0));
        const pool=fresh.length?fresh:list;

        const t=pool[Math.floor(Math.random()*pool.length)];

        seals.push({
            x:o.x,
            y:o.y,
            t:t,
            trail:[],
            time:(SKILLS[o.skill]&&SKILLS[o.skill].hipoSealTime)||10
        });

        snd("hipoSeal");

        burstParticles(o.x,o.y,10,"clone");

        return true;

    }

    function applySeal(t,time){

        if(t.hp<=0)return;

        if(t.goldenImmune>0||t.immuneTimer>0||t.goldenRewind){

            burstParticles(t.x,t.y,12,"shield");

            snd("immuneBlock");

            return;

        }

        if(t.sealTimer>0){
            t.sealTimer=Math.max(t.sealTimer,time);
            return;
        }

        const orig=SKILLS[t.skill]||{};

        t.sealedSkill=t.skill;
        t.sealWasNoAttack=!!orig.noAttack;

        if(orig.phase)t.shield=0;

        t.skill="normal";
        t.sealTimer=time;

        burstParticles(t.x,t.y,24,"clone");

        explosions.push({
            x:t.x,
            y:t.y,
            radius:60,
            life:.4,
            max:.4
        });

        snd("hipoSeal");

    }

    function unseal(o){

        if(o.sealedSkill){
            o.skill=o.sealedSkill;
            o.sealedSkill=null;
        }

        o.sealTimer=0;
        o.sealWasNoAttack=false;

        burstParticles(o.x,o.y,14,"heal");

    }

    window.updateHipo=function(o,dt){

        if(o.sealTimer>0){

            o.sealTimer-=dt;

            if(o.sealWasNoAttack){
                o.fireCooldown=Math.max(o.fireCooldown,.3);
            }

            if(o.sealTimer<=0)unseal(o);

        }

        const sk=SKILLS[o.skill];

        if(!sk||!sk.hipoSkill)return;

        o.hipoCooldown-=dt;

        if(o.hipoCooldown<=0){

            if(castSeal(o))o.hipoCooldown=sk.hipoCooldownMax||14;
            else o.hipoCooldown=.5;

        }

    };

    function sealFX(dt){

        for(let i=seals.length-1;i>=0;i--){

            const b=seals[i];
            const t=b.t;

            if(!t||t.hp<=0||!duelMode){
                seals.splice(i,1);
                continue;
            }

            if(!timeFreeze){

                const dx=t.x-b.x;
                const dy=t.y-b.y;
                const d=Math.hypot(dx,dy)||1;
                const step=680*dt;

                if(d<=step+(t.radius||24)){
                    applySeal(t,b.time);
                    seals.splice(i,1);
                    continue;
                }

                b.x+=dx/d*step;
                b.y+=dy/d*step;

                b.trail.push({x:b.x,y:b.y});

                if(b.trail.length>9)b.trail.shift();

            }

            ctx.save();

            for(let j=0;j<b.trail.length;j++){
                const p=b.trail[j];
                ctx.globalAlpha=(j+1)/b.trail.length*.5;
                ctx.fillStyle="#c58bff";
                ctx.beginPath();
                ctx.arc(p.x,p.y,3+j*.6,0,Math.PI*2);
                ctx.fill();
            }

            ctx.globalAlpha=1;

            const g=ctx.createRadialGradient(b.x,b.y,1,b.x,b.y,16);
            g.addColorStop(0,"#ffffff");
            g.addColorStop(.35,"#d9a8ff");
            g.addColorStop(1,"rgba(150,80,255,0)");

            ctx.fillStyle=g;
            ctx.beginPath();
            ctx.arc(b.x,b.y,16,0,Math.PI*2);
            ctx.fill();

            ctx.restore();

        }

    }

    /* segel dilepas bila duel berhenti */

    setInterval(()=>{

        if(duelMode)return;

        objects.forEach(o=>{
            if(o.type==="character"&&(o.sealedSkill||o.sealTimer>0)){
                if(o.sealedSkill)o.skill=o.sealedSkill;
                o.sealedSkill=null;
                o.sealTimer=0;
            }
        });

        seals.length=0;

    },300);

    /* ---------- EFEK ARENA (DI-CACHE) ---------- */

    const motes=[];

    function ensureMotes(){

        while(motes.length<Q.motes){
            motes.push({
                x:Math.random(),
                y:Math.random(),
                s:.4+Math.random()*1.4,
                r:1+Math.random()*1.8,
                p:Math.random()*6.28
            });
        }

        if(motes.length>Q.motes)motes.length=Q.motes;

    }

    let fxCache=null;
    let fxKey="";
    let borderGrad=null;

    /* bagian statis digambar sekali ke kanvas tersembunyi */

    function buildFxCache(L){

        const cv=document.createElement("canvas");

        cv.width=canvas.width;
        cv.height=canvas.height;

        const c=cv.getContext("2d");

        c.setTransform(dpr,0,0,dpr,0,0);

        const ax=12;
        const ay=12;
        const aw=W-24;
        const ah=H*.70-24;

        let g=c.createRadialGradient(0,H*.35,10,0,H*.35,W*.75);
        g.addColorStop(0,"rgba(61,123,255,.22)");
        g.addColorStop(1,"rgba(61,123,255,0)");
        c.fillStyle=g;
        c.fillRect(0,0,W,H*.70);

        g=c.createRadialGradient(W,H*.35,10,W,H*.35,W*.75);
        g.addColorStop(0,"rgba(255,84,104,.20)");
        g.addColorStop(1,"rgba(255,84,104,0)");
        c.fillStyle=g;
        c.fillRect(0,0,W,H*.70);

        if(L>=2){

            g=c.createRadialGradient(W/2,H*.35,0,W/2,H*.35,W*.5);
            g.addColorStop(0,"rgba(150,190,255,.09)");
            g.addColorStop(1,"rgba(150,190,255,0)");
            c.fillStyle=g;
            c.fillRect(0,0,W,H*.70);

            c.save();

            c.beginPath();
            c.rect(ax,ay,aw,ah);
            c.clip();

            c.strokeStyle="rgba(150,190,255,.045)";
            c.lineWidth=1;

            for(let x=ax;x<ax+aw;x+=40){
                c.beginPath();
                c.moveTo(x,ay);
                c.lineTo(x,ay+ah);
                c.stroke();
            }

            for(let y=ay;y<ay+ah;y+=40){
                c.beginPath();
                c.moveTo(ax,y);
                c.lineTo(ax+aw,y);
                c.stroke();
            }

            c.setLineDash([10,10]);
            c.strokeStyle="rgba(180,205,255,.15)";
            c.lineWidth=2;
            c.beginPath();
            c.moveTo(W/2,ay);
            c.lineTo(W/2,ay+ah);
            c.stroke();
            c.setLineDash([]);

            const cr=Math.min(aw,ah)*.16;

            c.strokeStyle="rgba(180,205,255,.12)";
            c.lineWidth=2;
            c.beginPath();
            c.arc(W/2,ay+ah/2,cr,0,Math.PI*2);
            c.stroke();

            c.fillStyle="rgba(150,190,255,.07)";
            c.beginPath();
            c.arc(W/2,ay+ah/2,6,0,Math.PI*2);
            c.fill();

            c.restore();

            g=c.createRadialGradient(
                W/2,H*.35,Math.min(W,H)*.3,
                W/2,H*.35,Math.max(W,H)*.75
            );
            g.addColorStop(0,"rgba(0,0,0,0)");
            g.addColorStop(1,"rgba(0,0,12,.38)");
            c.fillStyle=g;
            c.fillRect(0,0,W,H*.70);

        }

        /* garis neon dasar */

        g=c.createLinearGradient(ax,0,ax+aw,0);
        g.addColorStop(0,"#3d7bff");
        g.addColorStop(.5,"#8a5cff");
        g.addColorStop(1,"#ff5468");

        c.strokeStyle=g;
        c.lineWidth=2.5;
        c.globalAlpha=.55;
        c.shadowColor="#6a8dff";
        c.shadowBlur=14;
        c.strokeRect(ax,ay,aw,ah);
        c.globalAlpha=1;
        c.shadowBlur=0;

        /* siku sudut */

        const C=24;

        c.strokeStyle="rgba(230,240,255,.85)";
        c.lineWidth=3;
        c.lineCap="round";

        [[ax,ay,1,1],[ax+aw,ay,-1,1],[ax,ay+ah,1,-1],[ax+aw,ay+ah,-1,-1]]
        .forEach(k=>{
            c.beginPath();
            c.moveTo(k[0]+k[2]*C,k[1]);
            c.lineTo(k[0],k[1]);
            c.lineTo(k[0],k[1]+k[3]*C);
            c.stroke();
        });

        /* cakrawala lantai */

        g=c.createLinearGradient(0,H*.70,0,H);
        g.addColorStop(0,"rgba(80,120,255,.12)");
        g.addColorStop(1,"rgba(80,120,255,0)");
        c.fillStyle=g;
        c.fillRect(0,H*.70,W,H*.30);

        g=c.createLinearGradient(0,0,W,0);
        g.addColorStop(0,"rgba(61,123,255,0)");
        g.addColorStop(.2,"rgba(61,123,255,.8)");
        g.addColorStop(.5,"rgba(138,92,255,.8)");
        g.addColorStop(.8,"rgba(255,84,104,.8)");
        g.addColorStop(1,"rgba(255,84,104,0)");
        c.strokeStyle=g;
        c.lineWidth=2;
        c.shadowColor="#8a5cff";
        c.shadowBlur=10;
        c.beginPath();
        c.moveTo(0,H*.70);
        c.lineTo(W,H*.70);
        c.stroke();

        fxCache=cv;

    }

    function arenaFX(dt){

        const L=Q.fx;

        const key=W+"x"+H+"@"+dpr+"/"+L;

        if(key!==fxKey){
            buildFxCache(L);
            fxKey=key;
            borderGrad=null;
        }

        ctx.drawImage(fxCache,0,0,W,H);

        const ax=12;
        const ay=12;
        const aw=W-24;
        const ah=H*.70-24;

        const t=performance.now()/1000;
        const live=duelMode?1:.65;

        if(L>=2){

            ensureMotes();

            ctx.save();

            ctx.beginPath();
            ctx.rect(ax,ay,aw,ah);
            ctx.clip();

            const cr=Math.min(aw,ah)*.16;

            const rp=Math.max(0,Math.sin(t*2))*.06*live;

            if(rp>.004){
                ctx.strokeStyle="rgba(180,205,255,"+rp+")";
                ctx.lineWidth=2;
                ctx.beginPath();
                ctx.arc(W/2,ay+ah/2,cr,0,Math.PI*2);
                ctx.stroke();
            }

            if(L>=3){

                const pr=((t*.5)%1);

                ctx.strokeStyle="rgba(180,205,255,"+(.25*(1-pr))+")";
                ctx.lineWidth=2;
                ctx.beginPath();
                ctx.arc(W/2,ay+ah/2,cr*(.6+pr*1.6),0,Math.PI*2);
                ctx.stroke();

            }

            const sweeps=L>=3?2:1;

            for(let k=0;k<sweeps;k++){

                const sx=(((t*.12+k*.8)%1.6)-.3)*W;

                const x0=Math.max(ax,sx-130);
                const x1=Math.min(ax+aw,sx+130);

                if(x1>x0){

                    const g=ctx.createLinearGradient(sx-130,0,sx+130,0);
                    g.addColorStop(0,"rgba(255,255,255,0)");
                    g.addColorStop(.5,"rgba(255,255,255,.055)");
                    g.addColorStop(1,"rgba(255,255,255,0)");
                    ctx.fillStyle=g;
                    ctx.fillRect(x0,ay,x1-x0,ah);

                }

            }

            ctx.fillStyle="#bcd4ff";

            motes.forEach(m=>{

                m.y-=m.s*dt*.03;

                if(m.y<0){
                    m.y=1;
                    m.x=Math.random();
                }

                ctx.globalAlpha=.22+.22*Math.sin(t*2+m.p);
                ctx.beginPath();
                ctx.arc(
                    ax+m.x*aw+Math.sin(t+m.p)*10,
                    ay+m.y*ah,
                    m.r,
                    0,
                    Math.PI*2
                );
                ctx.fill();

            });

            ctx.globalAlpha=1;

            ctx.restore();

        }

        /* denyut garis neon */

        if(!borderGrad){
            borderGrad=ctx.createLinearGradient(ax,0,ax+aw,0);
            borderGrad.addColorStop(0,"#3d7bff");
            borderGrad.addColorStop(.5,"#8a5cff");
            borderGrad.addColorStop(1,"#ff5468");
        }

        ctx.strokeStyle=borderGrad;
        ctx.lineWidth=2.5;
        ctx.globalAlpha=(.1+.18*(Math.sin(t*2)*.5+.5))*live;
        ctx.strokeRect(ax,ay,aw,ah);
        ctx.globalAlpha=1;

        /* bayangan (+ cahaya tim di grafik tertinggi) */

        for(let i=0;i<objects.length;i++){

            const o=objects[i];

            if(o.type!=="character"||o.hp<=0)continue;

            if(L>=3){

                const gc=ctx.createRadialGradient(o.x,o.y+23,2,o.x,o.y+23,38);
                gc.addColorStop(0,o.team==="blue"?"rgba(93,160,255,.35)":"rgba(255,101,120,.35)");
                gc.addColorStop(1,"rgba(0,0,0,0)");
                ctx.fillStyle=gc;
                ctx.beginPath();
                ctx.ellipse(o.x,o.y+23,38,13,0,0,Math.PI*2);
                ctx.fill();

            }

            ctx.fillStyle="rgba(0,0,0,.32)";
            ctx.beginPath();
            ctx.ellipse(o.x,o.y+23,22,7,0,0,Math.PI*2);
            ctx.fill();

        }

    }

    window.drawArenaFX=function(dt){

        if(Q.fx>0)arenaFX(dt);

        sealFX(dt);

    };

    /* ---------- AI MUSUH (menurut rank) ---------- */

    function diffOf(rp){

        /* Global v0.01: musuh sudah sekelas Vortex ★1000 sejak Kadet */

        return 1;

    }

    function makeAI(d){

        return{
            d:d,
            spd:25+200*d,
            fireSlow:Math.max(0,.75-d*1.4),
            fireBonus:d>=.99?.15:0,
            dodge:Math.max(0,Math.min(1,(d-.35)/.5)),
            t:0,
            dx:0,
            dy:0,
            dT:0,
            dv:null,
            seen:new WeakSet()
        };

    }

    window.aiPre=function(o,dt){

        const A=o.ai;

        if(!A)return;

        if(A.fireSlow>0&&o.fireCooldown>0)o.fireCooldown+=dt*A.fireSlow;
        if(A.fireBonus>0&&o.fireCooldown>0)o.fireCooldown-=dt*A.fireBonus;

        if(o.stunTimer>0)return;

        for(let i=0;i<blackholes.length;i++){
            const h=blackholes[i];
            if(
                !h.exploded&&
                h.team!==o.team&&
                Math.hypot(h.x-o.x,h.y-o.y)<(h.pullRadius||0)
            )return;
        }

        /* musuh terdekat */

        let e=null;
        let best=1e9;

        for(let i=0;i<objects.length;i++){
            const c=objects[i];
            if(c.type!=="character"||c.hp<=0||c.team===o.team)continue;
            const dd=Math.hypot(c.x-o.x,c.y-o.y);
            if(dd<best){best=dd;e=c;}
        }

        /* keputusan gerak */

        A.t-=dt;

        if(A.t<=0){

            if(!e){
                A.dx=0;
                A.dy=0;
                A.t=1;
            }
            else if(A.d<.3){

                if(Math.random()<.65-A.d*1.5){
                    A.dx=0;
                    A.dy=0;
                }
                else{
                    const a=Math.random()*Math.PI*2;
                    A.dx=Math.cos(a);
                    A.dy=Math.sin(a);
                }

                A.t=1.2+Math.random()*1.8;

            }
            else{

                const ux=(e.x-o.x)/(best||1);
                const uy=(e.y-o.y)/(best||1);

                const side=Math.random()<.5?-1:1;

                let tx=0;
                let ty=0;

                if(best>300){tx=ux;ty=uy;}
                else if(best<160){tx=-ux;ty=-uy;}

                const sw=.6+.4*A.d;

                let mx=tx*.7+(-uy*side)*sw;
                let my=ty*.7+(ux*side)*sw;

                const ml=Math.hypot(mx,my)||1;

                A.dx=mx/ml;
                A.dy=my/ml;

                A.t=(1.1-.7*A.d)*(.6+Math.random()*.8);

            }

        }

        /* menghindar dari peluru */

        if(A.dT>0)A.dT-=dt;

        if(A.dodge>0&&A.dT<=0){

            for(let i=0;i<bullets.length;i++){

                const b=bullets[i];

                if(b.hit||b.owner===o.team||A.seen.has(b))continue;

                const px=o.x-b.x;
                const py=o.y-b.y;

                if(px*px+py*py>260*260)continue;

                const vv=b.vx*b.vx+b.vy*b.vy;

                if(vv<1)continue;

                const tca=(px*b.vx+py*b.vy)/vv;

                if(tca<0||tca>.6)continue;

                const cx=px-b.vx*tca;
                const cy=py-b.vy*tca;

                if(Math.hypot(cx,cy)>34)continue;

                A.seen.add(b);

                if(Math.random()>A.dodge)continue;

                const vl=Math.sqrt(vv);

                let nx=-b.vy/vl;
                let ny=b.vx/vl;

                if(nx*cx+ny*cy<0){nx=-nx;ny=-ny;}

                A.dv={x:nx,y:ny};
                A.dT=.28;

                break;

            }

        }

        if(A.dT>0&&A.dv){
            o.vx=A.dv.x*A.spd*1.3;
            o.vy=A.dv.y*A.spd*1.3;
        }
        else{
            o.vx=A.dx*A.spd;
            o.vy=A.dy*A.spd;
        }

    };

    /* ---------- PROFIL PLAYER ---------- */

    const levelOf=xp=>Math.floor(xp/100)+1;

    function openProfile(){

        if(!profile)loadProfile();

        const name=window.currentUser||"Tamu";

        $("pfName").textContent=name;
        $("pfAvatar").textContent=name.charAt(0).toUpperCase();

        $("pfLvl").textContent="Level "+levelOf(profile.xp);
        $("pfXpTxt").textContent=(profile.xp%100)+" / 100 XP";
        $("pfXp").style.width=(profile.xp%100)+"%";

        $("pfUid").textContent=window.currentIsGuest?"— (akun Tamu)":"#"+(profile.uid||"-");

        $("pfRank").textContent=rankText(profile.rp);
        $("pfPeak").textContent=rankText(Math.max(profile.peak,profile.rp));

        $("pfBio").value=profile.bio||"";
        $("pfMsg").textContent="";

        $("profileBox").style.display="flex";

    }

    $("pfUid").onclick=()=>{
        if(!profile||!profile.uid)return;
        try{navigator.clipboard.writeText(String(profile.uid));$("pfMsg").textContent="✅ ID disalin";}catch(e){}
    };

    $("btnProfile").onclick=openProfile;
    $("menuUser").onclick=openProfile;
    $("pfClose").onclick=()=>{$("profileBox").style.display="none";};

    $("pfSave").onclick=()=>{

        if(!profile)return;

        profile.bio=$("pfBio").value.slice(0,80);

        saveProfile();

        $("pfMsg").textContent="✅ Bio tersimpan";

    };

    /* ==================================================
       FITUR BARU: BERLIAN, BOOSTER, EVENT GACHA,
       TIM ACAK, RANKED MODE LAMA (GRUP -> 8 BESAR)
    ================================================== */

    function addGems(n){
        if(profile&&!isAdmin()){
            profile.gems+=n;
            saveProfile();
        }
    }

    function randSkill(){
        const ks=Object.keys(SKILLS);
        return ks[Math.floor(Math.random()*ks.length)];
    }

    function anySkills(n){
        const r=[];
        for(let i=0;i<n;i++)r.push(randSkill());
        return r;
    }

    /* ---------- BOOSTER ---------- */

    function renderBoosterStore(){

        const list=$("storeList");

        list.innerHTML="";

        Object.keys(BOOSTERS).forEach(k=>{

            const b=BOOSTERS[k];

            const row=document.createElement("div");

            row.className="srow";

            row.innerHTML=
                '<div class="si">'+b.icon+'</div>'+
                '<div class="sb"><b>'+b.name+'</b><small>'+b.desc+'</small>'+
                '<span class="own2">Dimiliki: '+(isAdmin()?"∞":profile.items[k])+'</span></div>'+
                '<div class="sp">💎 '+b.price+'</div>';

            row.onclick=()=>openBuyBooster(k);

            list.appendChild(row);

        });

        updateWallet();

    }

    function openBuyBooster(k){

        const b=BOOSTERS[k];

        $("buyArt").style.display="none";
        $("buyWho").style.display="none";
        $("buyLore").style.display="none";
        $("buyLoreT").style.display="none";
        $("buyDescT").style.display="none";
        $("buyIcon").style.display="";
        $("buyIcon").textContent=b.icon;
        $("buyName").textContent=b.name;
        $("buyDesc").textContent=b.desc;
        $("buyPrice").textContent="💎 "+b.price;

        const ok=isAdmin()||profile.gems>=b.price;

        const btn=$("buyYes");

        btn.disabled=!ok;
        btn.textContent=ok?"Beli 1x":"Berlian kurang ("+(b.price-profile.gems)+" lagi)";

        btn.onclick=()=>{

            if(!isAdmin()&&profile.gems<b.price)return;

            if(!isAdmin())profile.gems-=b.price;

            profile.items[k]++;

            saveProfile();

            closeBuy();

            renderStore();

        };

        updateWallet();

        $("buyBox").style.display="flex";

    }

    document.querySelectorAll("#stTabs button").forEach(b=>{
        b.onclick=()=>{
            storeTab=b.dataset.s;
            renderStore();
        };
    });

    function renderBoostPick(){

        const box=$("boostPick");

        box.innerHTML="";

        $("boostMsg").textContent="Booster terpakai saat turnamen dimulai.";

        Object.keys(BOOSTERS).forEach(k=>{

            const b=BOOSTERS[k];

            const n=isAdmin()?Infinity:profile.items[k];

            const el=document.createElement("button");

            el.className=n>0?(rank.boostSel[k]?"sel":""):"none";

            el.textContent=b.icon+" "+b.name+" ×"+(isAdmin()?"∞":n);

            el.onclick=()=>{

                $("boostMsg").textContent=b.icon+" "+b.desc;

                if(!(n>0)){
                    $("boostMsg").textContent+=" — belum punya, beli di Store (💎).";
                    return;
                }

                rank.boostSel[k]=!rank.boostSel[k];

                renderBoostPick();

                $("boostMsg").textContent=b.icon+" "+b.desc;

            };

            box.appendChild(el);

        });

    }

    function lockBoosters(){

        rank.boost={};

        if(!profile)return;

        Object.keys(rank.boostSel).forEach(k=>{

            if(!rank.boostSel[k])return;

            if(isAdmin()){
                rank.boost[k]=1;
                return;
            }

            if(profile.items[k]>0){
                profile.items[k]--;
                rank.boost[k]=1;
            }

        });

        saveProfile();

    }

    function applyBoosters(p){

        const bs=rank.boost||{};

        if(bs.immortal)p.extraLives=1;

        if(bs.cd){
            p.cdMul=.6;
            p.hasBoost=true;
        }

        if(bs.power){
            p.pwr=1.2;
            p.hasBoost=true;
        }

        if(bs.shield)p.shield=30;

        if(bs.hp){
            p.maxHp=Math.round(p.maxHp*1.3);
            p.hp=p.maxHp;
        }

    }

    window.boostPre=function(o,dt){

        if(o.hp<=0)return;

        if(o.cdMul){

            const extra=dt*(1/o.cdMul-1);

            ["timeCooldown","holeCooldown","hunterCooldown","goldenCooldown","hipoCooldown","sniperCooldown","lsCooldown","iceCooldown","nukeCooldown","samCooldown","regenCooldown","ghostCooldown","dimCooldown","mcd","mcd2"].forEach(f=>{
                const v=o[f];
                if(typeof v==="number"&&v>0&&v<1e8)o[f]=Math.max(0,v-extra);
            });

        }

        if(o.pwr)o.damageBoost=Math.max(o.damageBoost,o.pwr);

    };

    /* ---------- DURASI RANKED ---------- */

    function renderLen(){

        const ranked=rank.mode==="ranked";

        $("lenWrap").style.display=ranked?"":"none";

        if(!ranked||rank.teamSize!==1)rank.len="fast";

        document.querySelectorAll("#lenSeg button").forEach(b=>{
            b.classList.toggle("on",b.dataset.l===rank.len);
            b.style.opacity=(b.dataset.l==="long"&&rank.teamSize!==1)?".45":"";
        });

        $("lenDesc").textContent=
            rank.len==="long"
            ?"Babak grup (4 pemain, 3 duel) → harus juara grup → 8 Besar → Semi → Final."
            :(rank.teamSize!==1
                ?"Mode Lama hanya tersedia untuk Solo."
                :"Turnamen biasa: 8 Besar → Semi → Final.");

    }

    document.querySelectorAll("#lenSeg button").forEach(b=>{
        b.onclick=()=>{
            if(b.dataset.l==="long"&&rank.teamSize!==1){
                $("lenDesc").textContent="Mode Lama hanya tersedia untuk Solo.";
                return;
            }
            rank.len=b.dataset.l;
            renderLen();
        };
    });

    /* ---------- BABAK GRUP (MODE LAMA, SOLO) ---------- */

    function standings(g){

        const cnt={};

        g.pts.forEach(p=>{cnt[p]=(cnt[p]||0)+1;});

        return [0,1,2,3].sort((a,b)=>{

            if(g.pts[a]!==g.pts[b])return g.pts[b]-g.pts[a];

            if(cnt[g.pts[a]]===2){
                const w=g.h2h[Math.min(a,b)+"-"+Math.max(a,b)];
                if(w===a)return -1;
                if(w===b)return 1;
            }

            return g.tb[a]-g.tb[b];

        });

    }

    function recordG(g,d,k,w){

        const m=g.days[d][k];

        m.w=w;

        g.pts[w]+=3;
        g.w[w]++;
        g.l[w===m.i?m.j:m.i]++;
        g.h2h[Math.min(m.i,m.j)+"-"+Math.max(m.i,m.j)]=w;

    }

    function newGroupStage(){

        rank.stage="group";
        rank.isLong=true;

        const ents=[makeEntry(true,[rank.skill])];

        for(let i=0;i<3;i++)ents.push(makeEntry(false,[randSkill()]));

        const s=shuffle([1,2,3]);

        rank.grp={
            ents:ents,
            day:0,
            pts:[0,0,0,0],
            w:[0,0,0,0],
            l:[0,0,0,0],
            h2h:{},
            tb:[Math.random(),Math.random(),Math.random(),Math.random()],
            days:[
                [{i:0,j:s[0],w:null},{i:s[1],j:s[2],w:null}],
                [{i:0,j:s[1],w:null},{i:s[0],j:s[2],w:null}],
                [{i:0,j:s[2],w:null},{i:s[0],j:s[1],w:null}]
            ]
        };

        rank.gm=null;

    }

    function simGroupWinner(){

        const ents=[0,1,2,3].map(()=>makeEntry(false,[randSkill()]));

        const g={
            pts:[0,0,0,0],
            h2h:{},
            tb:[Math.random(),Math.random(),Math.random(),Math.random()]
        };

        for(let i=0;i<4;i++){
            for(let j=i+1;j<4;j++){
                const w=Math.random()<.5?i:j;
                g.pts[w]+=3;
                g.h2h[i+"-"+j]=w;
            }
        }

        return ents[standings(g)[0]];

    }

    function showStart(){

        if(rank.stage==="group")showGroup();
        else showBracket();

    }

    function showGroup(){

        const g=rank.grp;
        const d=g.day;

        rank.gm={a:g.ents[0],b:g.ents[g.days[d][0].j],w:null};

        let h='<div class="rnd">KLASEMEN GRUP</div>';

        standings(g).forEach((ix,pos)=>{
            h+='<div class="match'+(ix===0?" me":"")+'">'
                +'<span>'+(pos+1)+'. '+label(g.ents[ix])+'</span>'
                +'<em>'+g.w[ix]+'M '+g.l[ix]+'K</em>'
                +'<b>'+g.pts[ix]+' poin</b></div>';
        });

        for(let day=0;day<3;day++){

            h+='<div class="rnd">HARI '+(day+1)+(day===d?' • SEKARANG':'')+'</div>';

            g.days[day].forEach((m,k)=>{

                const c=ix=>m.w===null?"":(m.w===ix?"win":"lose");

                h+='<div class="match'+(k===0?" me":"")+'">'
                    +'<span class="'+c(m.i)+'">'+label(g.ents[m.i])+'</span>'
                    +'<em>vs</em>'
                    +'<span class="'+c(m.j)+'">'+label(g.ents[m.j])+'</span></div>';

            });

        }

        h+='<p class="sub">Hanya juara grup yang lolos ke 8 Besar. 7 grup lain berjalan otomatis.</p>';

        $("bkList").innerHTML=h;

        $("bkTitle").textContent="🕰️ Babak Grup • Hari "+(d+1)+"/3";

        updateWallet();

        show("bracket");

        $("bkList").scrollTop=0;

    }

    function grpScreen(icon,title,text,reward,btn1,fn1){

        $("rrIcon").textContent=icon;
        $("rrTitle").textContent=title;
        $("rrText").textContent=text;
        $("rrReward").textContent=reward||"";

        const b1=$("rrBtn1");
        const b2=$("rrBtn2");

        b1.textContent=btn1;
        b1.onclick=fn1;

        b2.style.display="";
        b2.textContent="🏠 Menu";
        b2.onclick=showMenu;

        show("rankResult");

    }

    function finishGroup(win){

        const g=rank.grp;
        const d=g.day;

        if(profile&&rank.mode==="ranked"){
            profile.pending=false;
            saveProfile();
        }

        const pm=g.days[d][0];
        const om=g.days[d][1];

        recordG(g,d,0,win?0:pm.j);
        recordG(g,d,1,Math.random()<.5?om.i:om.j);

        const res=(win?"Menang":"Kalah")+" lawan "+label(g.ents[pm.j])+". ";

        if(d<2){

            g.day++;

            grpScreen(
                win?"✅":"❌",
                win?"MENANG":"KALAH",
                res+"Lanjut ke Hari "+(g.day+1)+" dari 3.",
                "",
                "Lanjut ▶",
                showGroup
            );

            return;

        }

        const pos=standings(g).indexOf(0)+1;

        if(pos===1){

            const gain=REWARD_ROUND;
            const xp=25;

            if(!isAdmin())profile.coins+=gain;

            profile.xp+=xp;

            saveProfile();

            const entries=[g.ents[0]];

            for(let i=0;i<7;i++)entries.push(simGroupWinner());

            rank.stage="ko";
            rank.rounds=[makeRound(shuffle(entries))];
            rank.r=0;

            grpScreen(
                "🏅",
                "JUARA GRUP!",
                res+"Kamu juara grup dan lolos ke 8 Besar.",
                "+"+gain+" 🪙  •  +"+xp+" XP",
                "Lanjut ke 8 Besar ▶",
                showBracket
            );

        }
        else{

            const before=rankText(profile.rp);

            profile.rp=Math.max(0,profile.rp-1);
            profile.xp+=5;
            saveProfile();

            grpScreen(
                "💀",
                "TERSINGKIR",
                res+"Kamu finis di posisi "+pos+" grup. Hanya juara grup yang lolos.",
                "Rank turun: "+before+" → "+rankText(profile.rp)+"  •  +5 XP",
                "🔁 Coba Lagi",
                ()=>{lockBoosters();newTournament();showStart();}
            );

        }

    }

    /* ---------- EVENT: GACHA ---------- */

    const GACHA_DUP=75;

    const BANNERS={
        time:{
            label:"⏳ Time & 🌟 Golden",
            cost:150,
            skills:[{k:"goldentime",p:.20*2/7},{k:"time",p:.20*5/7}],
            sub:"Putar untuk dapat skill langka ⏳ Time & 🌟 GoldenTime, booster, atau koin",
            pool:["🪙","⏳","🌟","💰","🎰"]
        },
        ghost:{
            label:"🌫️ Ghost (Baru!)",
            cost:250,
            skills:[{k:"ghost",p:.20}],
            sub:"Banner baru! Putar untuk dapat skill 🌫️ Ghost, booster, atau koin",
            pool:["🪙","🌫️","👻","💰","🎰"]
        }
    };

    let curBanner="time";

    function GB(){return BANNERS[curBanner];}

    const GACHA_JUNK=[
        [5,30],[10,24],[15,16],[20,10],[25,7],
        [30,5],[35,3.5],[40,2],[45,1.5],[50,1]
    ];

    let gBusy=false;
    let payGem=false;
    function gemCost(c){return Math.round(c*5/2);}
    const gHist=[];

    const GACHA_BOOST_P=.30;

    function rollGacha(){

        const r=Math.random();

        let acc=0;

        for(const g of GB().skills){
            acc+=g.p;
            if(r<acc)return{type:"skill",k:g.k};
        }

        acc+=GACHA_BOOST_P;

        if(r<acc){
            const bk=Object.keys(BOOSTERS);
            return{type:"boost",k:bk[Math.floor(Math.random()*bk.length)]};
        }

        const tot=GACHA_JUNK.reduce((a,x)=>a+x[1],0);

        let t=Math.random()*tot;

        for(const x of GACHA_JUNK){
            t-=x[1];
            if(t<=0)return{type:"coin",n:x[0]};
        }

        return{type:"coin",n:10};

    }

    function renderEvent(){

        if(!profile)loadProfile();

        const pct=v=>(v*100).toFixed(1).replace(/\.0$/,"")+"%";

        const junkP=1-GACHA_BOOST_P-GB().skills.reduce((a,g)=>a+g.p,0);

        let h="";

        GB().skills.forEach(g=>{
            h+='<div class="oddsRow"><span>'+SKILLS[g.k].icon+' '+SKILLS[g.k].name+'</span><b>'+(g.p*100).toFixed(1)+'%</b></div>';
        });

        h+='<div class="oddsRow"><span>🚀 Booster acak (Immortal, CD, dll)</span><b>'+(GACHA_BOOST_P*100).toFixed(1)+'%</b></div>';
        h+='<div class="oddsRow"><span>🪙 Koin 5–50 (rata-rata ±15)</span><b>'+(junkP*100).toFixed(1)+'%</b></div>';
        h+='<div class="oddsRow"><span>Skill yang sudah dimiliki → '+GACHA_DUP+' 🪙</span><b>—</b></div>';

        $("gOdds").innerHTML=h;

        $("gSub").textContent=GB().sub+(((profile&&profile.free&&profile.free[curBanner])||0)>0?"  •  🎟️ Gacha gratis: "+profile.free[curBanner]+"x":"");

        const ic=payGem?"💎 ":"🪙 ";
        const c1=payGem?gemCost(GB().cost):GB().cost;
        const fr=(profile&&profile.free&&profile.free[curBanner])||0;
        const p1=c1*(1-Math.min(1,fr));
        const p5=c1*(5-Math.min(5,fr));
        $("gPull").innerHTML="🎰 Gacha 1x<br><small>"+(p1?ic+p1:"🎟️ GRATIS")+"</small>";
        $("gPull5").innerHTML="🎰 Gacha 5x<br><small>"+(p5?ic+p5:"🎟️ GRATIS")+"</small>";
        document.querySelectorAll("#gPay button").forEach(b=>{
            b.classList.toggle("on",(b.dataset.p==="gem")===payGem);
        });

        document.querySelectorAll("#gbTabs button").forEach(b=>{
            b.classList.toggle("on",b.dataset.b===curBanner);
        });

        $("gStat").textContent="Total putar: "+profile.pulls;

        $("gHist").textContent=gHist.length?"Terakhir: "+gHist.join("  "):"";

        updateWallet();

    }

    let gwQueue=[];
    let gwDone=null;

    function showWin(){

        if(!gwQueue.length){
            $("gachaWin").style.display="none";
            if(gwDone){const f=gwDone;gwDone=null;f();}
            return;
        }

        const w=gwQueue.shift();

        const sk=SKILLS[w.k];
        const lore=LORE[w.k]||{who:"",ttl:""};

        $("gwArt").innerHTML=skillArt(w.k);
        $("gwName").textContent=sk.icon+" "+sk.name;
        $("gwWho").textContent=lore.who+" • "+lore.ttl;
        $("gwMsg").textContent=w.dup?"Sudah dimiliki → +"+GACHA_DUP+" 🪙":"🎉 SKILL BARU DIDAPAT!";

        const card=document.querySelector("#gachaWin .gwCard");
        card.style.animation="none";
        void card.offsetWidth;
        card.style.animation="";

        $("gachaWin").style.display="flex";

        snd("goldenImmune");

    }

    $("gwNext").onclick=showWin;

    function doPull(n){

        if(gBusy)return;

        if(!profile)loadProfile();

        const frAvail=(profile.free&&profile.free[curBanner])||0;

        const useFree=Math.min(n,frAvail);

        const cost=(payGem?gemCost(GB().cost):GB().cost)*(n-useFree);

        if(!isAdmin()&&cost>0&&(payGem?profile.gems:profile.coins)<cost){
            $("gText").textContent=(payGem?"Berlian kurang! Butuh 💎 ":"Koin kurang! Butuh 🪙 ")+cost;
            return;
        }

        audio();

        if(useFree>0)profile.free[curBanner]-=useFree;

        if(!isAdmin()){
            if(payGem)profile.gems-=cost;
            else profile.coins-=cost;
        }

        profile.pulls+=n;

        const wins=[];
        const icons=[];
        let coinGain=0;
        let junkN=0;
        const boostGot=[];

        for(let i=0;i<n;i++){

            const res=rollGacha();

            if(res.type==="skill"){

                const dup=profile.unlocked.includes(res.k);

                if(dup){
                    if(!isAdmin())profile.coins+=GACHA_DUP;
                    coinGain+=GACHA_DUP;
                }
                else{
                    profile.unlocked.push(res.k);
                }

                wins.push({k:res.k,dup:dup});
                icons.push(SKILLS[res.k].icon);

            }
            else if(res.type==="boost"){

                profile.items[res.k]++;

                boostGot.push(res.k);

                icons.push(BOOSTERS[res.k].icon);

            }
            else{

                if(!isAdmin())profile.coins+=res.n;

                coinGain+=res.n;
                junkN++;

                icons.push("🪙"+res.n);

            }

        }

        saveProfile();

        let msg;

        if(n===1){
            msg=wins.length
                ?"🎉 Hadiah utama: "+SKILLS[wins[0].k].name+"!"
                :(boostGot.length
                    ?"🚀 Booster: "+BOOSTERS[boostGot[0]].icon+" "+BOOSTERS[boostGot[0]].name+" +1"
                    :"+"+coinGain+" 🪙");
        }
        else{
            msg=icons.join("  ")+"  →  +"+coinGain+" 🪙"+(boostGot.length?" • "+boostGot.length+" booster":"");
        }

        gBusy=true;

        $("gPull").disabled=true;
        $("gPull5").disabled=true;
        $("gText").textContent="";
        $("gachaBox").classList.remove("big");
        $("gachaBox").classList.add("spin");

        const pool=GB().pool;

        let t=0;

        const iv=setInterval(()=>{

            $("gIcon").textContent=pool[Math.floor(Math.random()*pool.length)];

            t++;

            if(t>=11){

                clearInterval(iv);

                $("gIcon").textContent=wins.length?SKILLS[wins[0].k].icon:(boostGot.length?BOOSTERS[boostGot[0]].icon:"🪙");
                $("gText").textContent=msg;
                $("gachaBox").classList.remove("spin");
                $("gachaBox").classList.toggle("big",wins.length>0);

                icons.slice().reverse().forEach(h=>{
                    gHist.unshift(h);
                });

                while(gHist.length>8)gHist.pop();

                const done=()=>{
                    gBusy=false;
                    $("gPull").disabled=false;
                    $("gPull5").disabled=false;
                    renderEvent();
                };

                if(wins.length){
                    gwQueue=wins.slice();
                    gwDone=done;
                    showWin();
                }
                else{
                    snd("boost");
                    done();
                }

            }

        },90);

    }

    $("btnEvent").onclick=()=>{
        audio();
        $("gText").textContent="";
        $("gIcon").textContent="🎰";
        $("gachaBox").classList.remove("big","spin");
        renderEvent();
        show("eventScr");
    };

    document.querySelectorAll("#gbTabs button").forEach(b=>{
        b.onclick=()=>{
            if(gBusy)return;
            curBanner=b.dataset.b;
            $("gText").textContent="";
            $("gIcon").textContent="🎰";
            snd("boost");
            renderEvent();
        };
    });

    document.querySelectorAll("#gPay button").forEach(b=>{
        b.onclick=()=>{
            if(gBusy)return;
            payGem=b.dataset.p==="gem";
            snd("boost");
            renderEvent();
        };
    });

    $("gPull").onclick=()=>doPull(1);
    $("gPull5").onclick=()=>doPull(5);

    $("eventBack").onclick=showMenu;

    /* ==================================================
       STORE: DETAIL SKILL (ILUSTRASI ANIME + SEJARAH)
       & ITEM TERBATAS (TIME, GOLDENTIME)
    ================================================== */

    const LIMITED=["time","goldentime","ghost"];

    const ART={
        normal:{hair:"#6b4a2b",eye:"#4d8dff",out:"#4d8dff",aura:"#4d8dff",st:"short"},
        kakek:{hair:"#d9d9d9",eye:"#7a5a3a",out:"#5d4037",aura:"#ffd34d",st:"short"},
        ice:{hair:"#d8f4ff",eye:"#4dd0ff",out:"#4fc3f7",aura:"#9be7ff",st:"long"},
        speed:{hair:"#ffe14d",eye:"#19d3ff",out:"#ff9f00",aura:"#ffd34d",st:"spiky"},
        angel:{hair:"#fff1b8",eye:"#7cc8ff",out:"#ffffff",aura:"#bfe8ff",st:"long"},
        sniper:{hair:"#3a3f55",eye:"#ff4d4d",out:"#2f6b45",aura:"#5dff9a",st:"short"},
        regen:{hair:"#7dffb0",eye:"#1fbf6a",out:"#1f9d5a",aura:"#7dffb0",st:"twin"},
        ghost:{hair:"#e3d8ff",eye:"#b388ff",out:"#4a2c7a",aura:"#b388ff",st:"long"},
        fireshot:{hair:"#ff5a1f",eye:"#ffd34d",out:"#c62828",aura:"#ff7a2d",st:"spiky"},
        samurai:{hair:"#15151f",eye:"#ff3d3d",out:"#8a1c1c",aura:"#ff5252",st:"long"},
        lifesteal:{hair:"#8b0020",eye:"#ff2d55",out:"#3a0f1a",aura:"#ff3355",st:"long"},
        nuclear:{hair:"#c6ff3d",eye:"#39ff14",out:"#e0b400",aura:"#b7ff00",st:"short"},
        magnet:{hair:"#3d5afe",eye:"#ff4081",out:"#c2185b",aura:"#7c4dff",st:"twin"},
        shotgun:{hair:"#8d5a2b",eye:"#ff9800",out:"#6d4c41",aura:"#ffab40",st:"spiky"},
        phase:{hair:"#cfd8ff",eye:"#b388ff",out:"#7e57c2",aura:"#b388ff",st:"long"},
        clone:{hair:"#00bcd4",eye:"#fffde7",out:"#00838f",aura:"#00e5ff",st:"short"},
        burst:{hair:"#ff1744",eye:"#ffffff",out:"#222222",aura:"#ff1744",st:"spiky"},
        hunter:{hair:"#5d4037",eye:"#ffca28",out:"#8d6e63",aura:"#ffb74d",st:"short"},
        hole:{hair:"#1c1c3a",eye:"#8c5cff",out:"#0d0d1a",aura:"#6a00ff",st:"long"},
        dead:{hair:"#e6e6e6",eye:"#ff1744",out:"#141414",aura:"#9c27b0",st:"long"},
        time:{hair:"#4fc3f7",eye:"#fff176",out:"#1565c0",aura:"#4fc3f7",st:"short"},
        goldentime:{hair:"#ffd700",eye:"#ffffff",out:"#b8860b",aura:"#ffd700",st:"long"},
        hipo:{hair:"#ab47bc",eye:"#e040fb",out:"#4a148c",aura:"#e040fb",st:"twin"}
    };

    const LORE={
        normal:{who:"Tony",ttl:"Penembak Pemula",story:"Anak pindahan yang menemukan pistol tua milik kakeknya di loteng. Tanpa trik, tanpa kekuatan — hanya latihan tiap sore hingga bidikannya jadi patokan semua duelis di arena."},
        speed:{who:"Hayate Kaze",ttl:"Kurir Angin",story:"Dulu kurir antar-kota yang tak pernah terlambat. Suatu badai membuatnya berlari lebih cepat dari suara, dan sejak itu ia bertarung dengan satu prinsip: musuh tak boleh sempat berkedip."},
        angel:{who:"Seraphine",ttl:"Penjaga Cahaya",story:"Malaikat yang turun karena tak tega melihat para duelis gugur sendirian. Sekali dalam hidupnya, sayapnya mampu membangkitkan satu sahabat yang telah jatuh."},
        sniper:{who:"Kuro Mizuhara",ttl:"Mata Elang Hutan",story:"Mantan penjaga hutan yang sabar menunggu satu tembakan sempurna. Ia lambat dan tidak selalu tepat, tetapi sekali mengenai, lawan tahu mengapa ia ditakuti."},
        ghost:{who:"Yurei Kageyama",ttl:"Roh Pengembara",story:"Gadis yang kehilangan raganya di sebuah duel lama. Rohnya kini berkelana: merasuki tubuh lawan untuk bertarung dengan tangan mereka sendiri, atau menyeret mereka ke dimensi sunyi tempat hanya satu yang boleh keluar."},
        regen:{who:"Mirai Hanazono",ttl:"Tabib Taman",story:"Putri penjaga taman herbal yang mewarisi doa penyembuh keluarganya. Tiap beberapa detik daun-daun bercahaya memulihkan dirinya, dan akar-akar cahaya menyambung ke seorang sahabat untuk terus menyembuhkannya."},
        fireshot:{who:"Homura Rekka",ttl:"Pewaris Api",story:"Lahir di desa pandai besi, pelurunya dilebur dari bara yang tak pernah padam. Semakin lama duel berlangsung, semakin panas dan cepat tembakannya."},
        samurai:{who:"Kenji Kurogane",ttl:"Pedang Tanpa Pistol",story:"Ronin yang menolak senjata api. Ia melesat mepet ke lawan dan menebas tanpa henti, lalu sekali waktu melepaskan tebasan kilat: tiga sabetan bolak-balik secepat petir."},
        ice:{who:"Yuki Shirogane",ttl:"Putri Salju Abadi",story:"Gadis dari puncak gunung yang tak pernah mencair. Setiap peluru yang menyentuh lawan membuat dunia mereka berjalan lambat, dan dengan satu hembusan napas ia membekukan seluruh arena."},
        lifesteal:{who:"Vlad Crimson",ttl:"Bangsawan Malam",story:"Bangsawan tua yang lapar akan kehidupan. Setiap peluru yang menembus lawan membawa pulang sebagian nyawanya, dan dengan satu lambaian ia membuka lingkaran darah yang menyedot siapa pun yang berani mendekat."},
        nuclear:{who:"Dr. Atomi",ttl:"Ilmuwan Nekat",story:"Peneliti reaktor yang menanamkan inti kecil di jantungnya. Ia sendiri tak takut gugur, sebab siapa pun yang menjatuhkannya akan ikut tumbang seketika — dan radiasi dari tubuhnya bisa menyebar ke seluruh arena."},
        magnet:{who:"Jiro Magneto",ttl:"Si Penarik Takdir",story:"Tubuhnya tak sekuat petarung lain, namun peluru buatannya tak pernah salah arah. Ia menyalakan medan magnet hingga setiap tembakan mengejar lawan ke mana pun mereka lari."},
        shotgun:{who:"Gonzo Barrel",ttl:"Raja Jarak Dekat",story:"Pemburu beruang dari pegunungan utara. Ia tak suka membidik — ia menyebar maut dalam satu dentuman dan membiarkan lawan yang memilih peluru mana yang mengenainya."},
        phase:{who:"Yurei Shizuka",ttl:"Bayangan Tipis",story:"Konon ia sudah mati sekali dan menolak pergi. Tubuhnya setengah bayang, tiap beberapa detik perisai roh menyelimutinya dan langkahnya dua kali lebih gesit."},
        clone:{who:"Rui & Rui",ttl:"Dua Jadi Banyak",story:"Eksperimen kembar yang gagal — atau berhasil, tergantung siapa yang bertanya. Satu klon dilepas, lalu klon itu memperbanyak diri hingga arena terasa penuh dengan dirinya."},
        burst:{who:"Akai Bakuha",ttl:"Satu Tembakan Satu Nyawa",story:"Ia menahan napas, mengumpulkan seluruh tenaga, lalu melepas satu peluru berdamage besar. Jedanya panjang, tetapi lawan jarang sempat membalas."},
        hunter:{who:"Rango Dusk",ttl:"Pemburu Senja",story:"Koboi pengelana yang membawa enam pistol di balik jubahnya. Sekali dalam beberapa detik ia menghujani lawan dengan rentetan peluru dan kebal sejenak dari balasan."},
        hole:{who:"Void Nagumo",ttl:"Penjinak Kehampaan",story:"Peramal yang menatap langit kosong terlalu lama hingga langit itu balas menatap. Ia memanggil lubang hitam yang menyeret musuh lalu meledak, membuat mereka pingsan."},
        dead:{who:"Mortis",ttl:"Utusan Terakhir",story:"Tak pernah menembak sekali pun. Ia hanya bertahan, dan bila ia masih berdiri setelah 30 detik, maut sendiri turun mencabut nyawa semua musuh."},
        time:{who:"Chrono Tokiwa",ttl:"Penjaga Detik",story:"Jam saku pusakanya membuat dunia terdiam selama satu setengah detik. Dalam keheningan itu hanya peluru-peluru miliknya yang bergerak. Item terbatas — hanya dari spin."},
        goldentime:{who:"Aurelia Chronos",ttl:"Ratu Waktu Emas",story:"Keturunan penjaga jam emas kerajaan kuno. Ia memutar waktu semua orang mundur lima detik, lalu kebal terhadap semua serangan selama dua detik berikutnya. Item terbatas — hanya dari spin."},
        hipo:{who:"Mesmera",ttl:"Penyegel Pikiran",story:"Penyihir hipnotis yang menatap mata lawan dan mengunci kekuatannya. Satu musuh kehilangan skill-nya selama 10 detik, bahkan skill pasif dan Dead sekalipun."}
    };

    function skillArt(k){

        const a=ART[k]||ART.normal;
        const H=a.hair,E=a.eye,O=a.out,A=a.aura;

        let back="",front="";

        /* latar & aura */
        let bg='<defs><radialGradient id="ag'+k+'" cx="50%" cy="45%" r="70%"><stop offset="0" stop-color="'+A+'" stop-opacity=".95"/><stop offset=".55" stop-color="'+A+'" stop-opacity=".35"/><stop offset="1" stop-color="#0a1020"/></radialGradient></defs>'
            +'<rect width="240" height="280" fill="url(#ag'+k+')"/>';

        for(let i=0;i<12;i++){
            const r=i*30*Math.PI/180;
            bg+='<path d="M120 130 L'+(120+Math.cos(r)*260)+' '+(130+Math.sin(r)*260)+' L'+(120+Math.cos(r+.12)*260)+' '+(130+Math.sin(r+.12)*260)+'Z" fill="#fff" opacity=".07"/>';
        }

        [[28,40,3],[205,60,2.5],[40,200,2],[210,170,3],[190,25,2],[20,120,2]].forEach(s=>{
            bg+='<circle cx="'+s[0]+'" cy="'+s[1]+'" r="'+s[2]+'" fill="#fff" opacity=".8"/>';
        });

        /* efek khusus (belakang) */
        const X={
            ice:'<g stroke="#fff" stroke-width="4" opacity=".75" fill="none"><path d="M120 18 V238 M30 128 H210 M56 54 L184 202 M184 54 L56 202"/></g><circle cx="120" cy="128" r="98" fill="none" stroke="#e1f5fe" stroke-width="3" opacity=".7"/>',
            angel:'<path d="M70 190 Q8 140 14 70 Q60 110 86 170Z" fill="#fff" opacity=".92"/><path d="M170 190 Q232 140 226 70 Q180 110 154 170Z" fill="#fff" opacity=".92"/>',
            speed:'<g stroke="#fff" stroke-width="3" opacity=".7"><path d="M6 60 H70"/><path d="M0 100 H50"/><path d="M10 150 H60"/><path d="M180 70 H236"/><path d="M196 120 H240"/><path d="M186 170 H232"/></g>',
            ghost:'<g fill="#fff" opacity=".28"><circle cx="40" cy="70" r="12"/><circle cx="200" cy="96" r="16"/><circle cx="28" cy="190" r="9"/><circle cx="214" cy="200" r="11"/></g><path d="M20 250 Q120 150 220 250" fill="none" stroke="#b388ff" stroke-width="3" opacity=".5"/>',
            hole:'<circle cx="120" cy="120" r="96" fill="#000" opacity=".75"/><circle cx="120" cy="120" r="96" fill="none" stroke="#b388ff" stroke-width="4" opacity=".8"/><ellipse cx="120" cy="120" rx="112" ry="26" fill="none" stroke="#fff" stroke-width="2" opacity=".6" transform="rotate(-20 120 120)"/>',
            clone:'<g opacity=".4"><ellipse cx="62" cy="140" rx="40" ry="46" fill="'+H+'"/><path d="M14 280 Q20 214 62 208 Q104 214 110 280Z" fill="'+O+'"/></g><g opacity=".4"><ellipse cx="178" cy="140" rx="40" ry="46" fill="'+H+'"/><path d="M130 280 Q136 214 178 208 Q220 214 226 280Z" fill="'+O+'"/></g>',
            phase:'<ellipse cx="120" cy="140" rx="104" ry="120" fill="#fff" opacity=".12"/>',
            fireshot:'<path d="M20 280 Q10 220 40 190 Q36 230 60 210 Q56 170 86 150 Q84 200 110 190 L110 280Z" fill="#ff9a1f" opacity=".8"/><path d="M130 280 L130 190 Q156 200 154 150 Q184 170 180 210 Q204 230 200 190 Q230 220 220 280Z" fill="#ff5a1f" opacity=".8"/>',
            goldentime:'<circle cx="120" cy="128" r="104" fill="none" stroke="#fff3a0" stroke-width="3" opacity=".8"/><circle cx="120" cy="128" r="92" fill="none" stroke="#ffd700" stroke-width="2" stroke-dasharray="4 8" opacity=".9"/>',
            time:'<circle cx="120" cy="128" r="100" fill="none" stroke="#e1f5fe" stroke-width="3" opacity=".7"/><g stroke="#e1f5fe" stroke-width="3" opacity=".8"><path d="M120 22 V36"/><path d="M120 220 V234"/><path d="M14 128 H28"/><path d="M212 128 H226"/></g>',
            hipo:'<circle cx="120" cy="124" r="100" fill="none" stroke="#f3a6ff" stroke-width="3" opacity=".8"/><path d="M120 24 L148 196 L36 94 L204 94 L92 196Z" fill="none" stroke="#f3a6ff" stroke-width="2" opacity=".6"/>',
            nuclear:'<g opacity=".35" fill="#c6ff3d"><path d="M120 128 L120 20 A108 108 0 0 1 213 74Z"/><path d="M120 128 L27 74 A108 108 0 0 0 120 236Z" transform="rotate(0)"/><path d="M120 128 L213 182 A108 108 0 0 1 120 236Z"/></g>',
            dead:'<ellipse cx="120" cy="260" rx="110" ry="30" fill="#000" opacity=".5"/>',
            regen:'<g fill="#fff" opacity=".85"><rect x="24" y="60" width="8" height="24" rx="2"/><rect x="16" y="68" width="24" height="8" rx="2"/><rect x="200" y="150" width="8" height="24" rx="2"/><rect x="192" y="158" width="24" height="8" rx="2"/></g>',
            magnet:'<g fill="none" stroke="#ff4081" stroke-width="5"><path d="M20 80 V50 A20 20 0 0 1 60 50 V80"/><path d="M180 200 V170 A20 20 0 0 1 220 170 V200"/></g>',
            burst:'<path d="M120 0 L134 90 L240 60 L158 130 L236 220 L136 170 L120 280 L104 170 L4 220 L82 130 L0 60 L106 90Z" fill="#fff" opacity=".18"/>',
            sniper:'<g stroke="#fff" stroke-width="2" fill="none" opacity=".6"><circle cx="120" cy="128" r="100"/><path d="M120 10 V246 M2 128 H238"/></g>'
        };

        back+=X[k]||"";

        /* rambut belakang */
        if(a.st==="long")back+='<path d="M60 118 Q46 214 74 262 L166 262 Q194 214 180 118Z" fill="'+H+'"/>';
        if(a.st==="twin")back+='<path d="M72 104 Q22 150 38 240 Q72 206 82 150Z" fill="'+H+'"/><path d="M168 104 Q218 150 202 240 Q168 206 158 150Z" fill="'+H+'"/>';

        /* tubuh */
        let body='<path d="M44 280 Q52 212 120 204 Q188 212 196 280Z" fill="'+O+'"/>'
            +'<path d="M98 206 L120 238 L142 206Z" fill="#fff" opacity=".9"/>'
            +'<rect x="108" y="176" width="24" height="34" fill="#f6cdb3"/>';

        /* kepala */
        let head='<ellipse cx="120" cy="124" rx="50" ry="56" fill="#ffe6d4"/>';

        /* poni & rambut depan */
        let hairF='<path d="M66 122 Q64 56 120 54 Q176 56 174 122 Q158 86 120 92 Q82 86 66 122Z" fill="'+H+'"/>';

        if(a.st==="spiky"){
            hairF+='<path d="M66 100 L50 60 L88 78 L92 36 L116 72 L134 30 L148 74 L184 48 L174 100 Q150 80 120 86 Q90 80 66 100Z" fill="'+H+'"/>';
        }
        else{
            hairF+='<path d="M80 98 L94 126 L108 92 L122 128 L136 92 L150 126 L162 98 Q150 72 120 70 Q90 72 80 98Z" fill="'+H+'"/>';
        }

        hairF+='<path d="M70 110 Q64 150 74 170 Q72 130 84 108Z" fill="'+H+'"/><path d="M170 110 Q176 150 166 170 Q168 130 156 108Z" fill="'+H+'"/>';

        /* wajah anime */
        let face='';

        [98,142].forEach(cx=>{
            face+='<ellipse cx="'+cx+'" cy="136" rx="15" ry="19" fill="#fff"/>'
                +'<ellipse cx="'+cx+'" cy="139" rx="11" ry="15" fill="'+E+'"/>'
                +'<ellipse cx="'+cx+'" cy="141" rx="5" ry="9" fill="#10121c"/>'
                +'<circle cx="'+(cx-4)+'" cy="132" r="4.2" fill="#fff"/><circle cx="'+(cx+4)+'" cy="145" r="2" fill="#fff"/>'
                +'<path d="M'+(cx-16)+' 130 Q'+cx+' 114 '+(cx+16)+' 130" fill="none" stroke="#10121c" stroke-width="3.5" stroke-linecap="round"/>';
        });

        face+='<path d="M86 114 L108 118" stroke="'+H+'" stroke-width="3.5" stroke-linecap="round"/><path d="M154 114 L132 118" stroke="'+H+'" stroke-width="3.5" stroke-linecap="round"/>'
            +'<ellipse cx="82" cy="158" rx="9" ry="5" fill="#ff8aa8" opacity=".5"/><ellipse cx="158" cy="158" rx="9" ry="5" fill="#ff8aa8" opacity=".5"/>'
            +'<path d="M110 166 Q120 176 130 166" fill="none" stroke="#a8473f" stroke-width="3" stroke-linecap="round"/>';

        /* aksesori depan */
        const F={
            kakek:'<path d="M96 170 Q120 206 144 170 Q120 188 96 170Z" fill="#eee"/><text x="120" y="262" font-size="36" text-anchor="middle">🔫</text>',
            ice:'<text x="120" y="262" font-size="38" text-anchor="middle">❄️</text>',
            angel:'<ellipse cx="120" cy="38" rx="34" ry="9" fill="none" stroke="#ffd700" stroke-width="6"/>',
            hunter:'<ellipse cx="120" cy="76" rx="82" ry="14" fill="#6d4c41"/><path d="M78 76 Q80 28 120 26 Q160 28 162 76Z" fill="#8d6e63"/><rect x="78" y="62" width="84" height="10" fill="#3e2723"/>',
            dead:'<path d="M50 130 Q50 30 120 28 Q190 30 190 130 Q172 70 120 70 Q68 70 50 130Z" fill="#141414" opacity=".95"/><text x="120" y="262" font-size="34" text-anchor="middle">💀</text>',
            sniper:'<circle cx="142" cy="136" r="26" fill="none" stroke="#ff4d4d" stroke-width="3"/><path d="M142 104 V168 M110 136 H174" stroke="#ff4d4d" stroke-width="2"/>',
            samurai:'<text x="120" y="262" font-size="38" text-anchor="middle">⚔️</text>',
            lifesteal:'<path d="M110 166 L114 180 L118 166Z M122 166 L126 180 L130 166Z" fill="#fff"/><path d="M136 186 Q140 200 144 186 Q140 176 136 186Z" fill="#d50000"/>',
            nuclear:'<text x="120" y="262" font-size="40" text-anchor="middle">☢️</text>',
            time:'<text x="120" y="260" font-size="40" text-anchor="middle">⏳</text>',
            goldentime:'<text x="120" y="38" font-size="30" text-anchor="middle">🌟</text><text x="120" y="262" font-size="36" text-anchor="middle">⏳</text>',
            hipo:'<circle cx="120" cy="100" r="9" fill="#f3a6ff" opacity=".9"/><circle cx="120" cy="100" r="4" fill="#4a148c"/>',
            hole:'<circle cx="120" cy="250" r="22" fill="#000" stroke="#b388ff" stroke-width="3"/>',
            ghost:'<text x="120" y="262" font-size="38" text-anchor="middle">🌫️</text><text x="36" y="40" font-size="22" text-anchor="middle" opacity=".8">👻</text><text x="204" y="60" font-size="18" text-anchor="middle" opacity=".7">👻</text>',
            burst:'<text x="120" y="262" font-size="40" text-anchor="middle">💥</text>',
            fireshot:'<text x="120" y="262" font-size="38" text-anchor="middle">🔥</text>',
            regen:'<text x="120" y="262" font-size="38" text-anchor="middle">💚</text>',
            magnet:'<text x="120" y="262" font-size="38" text-anchor="middle">🧲</text>',
            shotgun:'<text x="120" y="262" font-size="38" text-anchor="middle">🔫</text>',
            speed:'<text x="120" y="262" font-size="38" text-anchor="middle">⚡</text>',
            phase:'<text x="120" y="262" font-size="38" text-anchor="middle">👻</text>',
            clone:'<text x="120" y="262" font-size="38" text-anchor="middle">👥</text>',
            normal:'<text x="120" y="262" font-size="38" text-anchor="middle">🎯</text>'
        };

        front+=F[k]||"";

        return '<svg viewBox="0 0 240 280" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="'+(SKILLS[k]?SKILLS[k].name:k)+'">'
            +bg+back+body+head+hairF+face+front+'</svg>';

    }

    /* ---------- TOP UP: TUKAR BERLIAN -> KOIN ---------- */

    const TOPUP_GEM=5;
    const TOPUP_COIN=2;

    let topMsg="";

    function renderTopUp(){

        const list=$("storeList");

        list.innerHTML="";

        const rate=document.createElement("div");

        rate.className="limNote";

        rate.innerHTML=
            '<span style="font-size:26px">💱</span>'+
            '<div><b>Kurs: '+TOPUP_GEM+' 💎 = '+TOPUP_COIN+' 🪙</b>'+
            '<small>Berlaku kelipatan '+TOPUP_GEM+' 💎. Sisa berlian di bawah '+TOPUP_GEM+' tidak bisa ditukar.</small></div>';

        list.appendChild(rate);

        const have=isAdmin()?Infinity:profile.gems;

        [1,2,5,10,25].forEach(m=>{
            addTopRow(m);
        });

        const all=Math.floor((isAdmin()?0:profile.gems)/TOPUP_GEM);

        const row=document.createElement("div");

        row.className="srow"+(all>0?"":" own");

        row.innerHTML=
            '<div class="si">🔁</div>'+
            '<div class="sb"><b>Tukar semua</b><small>'+(all>0?(all*TOPUP_GEM)+' 💎 → '+(all*TOPUP_COIN)+' 🪙':'Berlian belum cukup')+'</small></div>'+
            '<div class="sp">'+(all>0?'+'+(all*TOPUP_COIN)+' 🪙':'—')+'</div>';

        if(all>0)row.onclick=()=>doTopUp(all);

        list.appendChild(row);

        const msg=document.createElement("p");

        msg.className="reward";

        msg.textContent=topMsg;

        list.appendChild(msg);

        updateWallet();

    }

    function addTopRow(m){

        const gems=m*TOPUP_GEM;
        const coins=m*TOPUP_COIN;

        const ok=!isAdmin()&&profile.gems>=gems;

        const row=document.createElement("div");

        row.className="srow"+(ok?"":" own");

        row.innerHTML=
            '<div class="si">💎</div>'+
            '<div class="sb"><b>'+gems+' 💎 → '+coins+' 🪙</b><small>'+(ok?'Ketuk untuk menukar':'Berlian kurang')+'</small></div>'+
            '<div class="sp">+'+coins+' 🪙</div>';

        if(ok)row.onclick=()=>doTopUp(m);

        $("storeList").appendChild(row);

    }

    function doTopUp(m){

        const gems=m*TOPUP_GEM;
        const coins=m*TOPUP_COIN;

        if(isAdmin()||profile.gems<gems)return;

        profile.gems-=gems;
        profile.coins+=coins;

        saveProfile();

        topMsg="✅ "+gems+" 💎 → +"+coins+" 🪙";

        renderStore();

    }

    /* ==================================================
       v1.5: INBOX, UI PEMILIHAN MODE
    ================================================== */

    /* ---------- INBOX ---------- */

    function inboxUnread(){
        return profile&&Array.isArray(profile.inbox)
            ?profile.inbox.filter(m=>!m.claimed).length
            :0;
    }

    function updateInbBadge(){
        const n=inboxUnread();
        $("inbBadge").style.display=n>0?"flex":"none";
        $("inbBadge").textContent=n;
    }

    function renderInbox(){

        if(!profile)loadProfile();

        const list=profile.inbox.slice().reverse();

        let h="";

        if(!list.length){
            h='<p class="sub" style="padding:24px 0">Belum ada pesan.</p>';
        }

        list.forEach(m=>{

            h+='<div class="msg'+(m.claimed?" done":"")+'">'
                +'<div class="msgT">'+m.title+'</div>'
                +'<div class="msgD">'+m.date+'</div>'
                +'<div class="msgB">'+m.body+'</div>'
                +'<div class="msgR">'
                +(m.coins?'<span>🪙 '+m.coins+'</span>':'')
                +(m.gems?'<span>💎 '+m.gems+'</span>':'')
                +(m.free?'<span>🎟️ Gacha gratis '+(m.free.time||0)+'x / event</span>':'')
                +'</div>'
                +'<button data-id="'+m.id+'" '+(m.claimed?'disabled':'')+'>'+(m.claimed?'✓ Sudah diklaim':'🎁 Klaim Hadiah')+'</button>'
                +'</div>';

        });

        $("inbList").innerHTML=h;

        $("inbList").querySelectorAll("button[data-id]").forEach(b=>{

            b.onclick=()=>{

                const m=profile.inbox.find(x=>x.id===b.dataset.id);

                if(!m||m.claimed)return;

                m.claimed=true;

                if(!isAdmin()){
                    profile.coins+=m.coins||0;
                    profile.gems+=m.gems||0;
                }

                if(m.free){
                    if(!profile.free)profile.free={time:0,ghost:0};
                    Object.keys(m.free).forEach(k=>{
                        profile.free[k]=(profile.free[k]||0)+(m.free[k]||0);
                    });
                }

                saveProfile();

                updateWallet();

                updateInbBadge();

                renderInbox();

                snd("goldenImmune");

            };

        });

        updateWallet();

    }

    $("btnInbox").onclick=()=>{
        audio();
        renderInbox();
        show("inboxScr");
        admSyncGifts().then(()=>{if($("inboxScr").style.display==="flex")renderInbox();});
    };

    $("inboxBack").onclick=showMenu;

    /* ---------- UI PEMILIHAN MODE ---------- */

    const MODES={

        ranked:{
            name:"RANKED",
            sub:"Turnamen",
            icon:"🏆",
            badge:"🔥 PALING SERU",
            desc:"Pilih skill andalanmu, tembus turnamen 8 pemain, dan jadi juara. Naikkan rank dari Kadet sampai Vortex!",
            feat:["Solo, Duo, atau Squad (tim acak)","Mode ⚡ Cepat atau 🕰️ Lama (grup → 8 Besar)","Hadiah koin & XP (💎 dari Misi Harian)","Menang naik rank, kalah turun rank"],
            c1:"#ffd34d",c2:"#ff8a3d"
        },

        classic:{
            name:"CLASSIC",
            sub:"Santai",
            icon:"🎯",
            badge:"😌 SANTAI",
            desc:"Format turnamen yang sama seperti Ranked, tapi tanpa tekanan: tidak ada hadiah dan rank tidak berubah.",
            feat:["Turnamen 8 pemain, Solo/Duo/Squad","Tanpa hadiah, rank aman","Cocok untuk latihan skill baru"],
            c1:"#4d8dff",c2:"#8a5cff"
        },

        story:{
            name:"STORY",
            sub:"Petualangan",
            icon:"📖",
            badge:"🆕 BARU • CERITA",
            desc:"Semua orang di dunia ini punya skill — kecuali Tony. Ikuti perjalanan penembak biasa yang bertekad mengalahkan semua skill dan menjadi yang terkuat.",
            feat:["10 bab cerita dengan dialog beranimasi","Lawan para pemilik skill dari Speed sampai Time","Hadiah koin, 💎 & XP saat pertama menamatkan bab","Progres tersimpan di akunmu"],
            c1:"#ffb347",c2:"#ff5f6d"
        },

        friend:{
            name:"1VS1 WITH FRIEND",
            sub:"Lokal • Beta",
            icon:"🤝",
            badge:"🧪 BETA • TANPA INTERNET",
            desc:"Duel manual 1 lawan 1 bareng temanmu lewat hotspot. Satu buat room & tampilkan QR, satunya scan. Semua skill terbuka dan ada sesi Ban Skill.",
            feat:["Tanpa kuota internet (hotspot lokal)","Hanya mode manual, tanpa auto","Semua skill terbuka + sesi Ban Skill","Tanpa hadiah, rank tidak berubah"],
            c1:"#ff4d6d",c2:"#8a5cff"
        },

        arcade:{
            name:"ARCADE",
            sub:"Duel Kartu",
            icon:"🃏",
            badge:"🆕 BARU • DUEL KARTU",
            desc:"Adu kartu skill bergiliran! Satu bar HP 200. Seimbangkan Attack, Magic, dan Defense, lalu hentikan waktu dengan kartu Time di saat yang tepat.",
            feat:["Pilih 5 kartu dari skill yang kamu punya","Serang bergiliran, lawan bisa bertahan pakai kartu Defense","HP 200 untuk kedua pihak","Syarat: 5 skill & Level 15"],
            c1:"#b46bff",c2:"#ff5fa2"
        },

        sandbox:{
            name:"SANDBOX",
            sub:"Bebas",
            icon:"🛠️",
            badge:"🧪 KREATIF",
            desc:"Arena bebas: tambah karakter, atur tim, pilih skill apa pun, lalu adu sesukamu. Semua skill terbuka.",
            feat:["Semua skill terbuka","Atur posisi & tim sendiri","Duel tanpa batas, tanpa hadiah"],
            c1:"#2ecc9a",c2:"#1f8fd1"
        }

    };

    let curMode="ranked";

    function modeArt(m){

        const M=MODES[m];

        const defs='<defs>'
            +'<linearGradient id="mg'+m+'" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="'+M.c1+'"/><stop offset="1" stop-color="'+M.c2+'"/></linearGradient>'
            +'<radialGradient id="mr'+m+'" cx="50%" cy="50%" r="60%"><stop offset="0" stop-color="'+M.c1+'" stop-opacity=".9"/><stop offset="1" stop-color="#070b16" stop-opacity="0"/></radialGradient>'
            +'</defs>';

        let rays="";

        for(let i=0;i<14;i++){
            const a=i*Math.PI*2/14;
            rays+='<path d="M200 150 L'+(200+Math.cos(a)*300)+' '+(150+Math.sin(a)*300)+' L'+(200+Math.cos(a+.1)*300)+' '+(150+Math.sin(a+.1)*300)+'Z" fill="#fff" opacity=".08"/>';
        }

        let hero="";

        if(m==="ranked"){

            hero=
                '<g transform="translate(200 150)">'
                +'<path d="M-70 -70 L0 -96 L70 -70 L70 10 Q70 70 0 100 Q-70 70 -70 10Z" fill="url(#mg'+m+')" stroke="#fff6c8" stroke-width="5"/>'
                +'<path d="M-52 -56 L0 -76 L52 -56 L52 8 Q52 54 0 78 Q-52 54 -52 8Z" fill="#1b1230" opacity=".88"/>'
                +'<path d="M-30 -18 L-20 -44 L-8 -26 L0 -50 L8 -26 L20 -44 L30 -18 L30 4 L-30 4Z" fill="#ffe27a" stroke="#fff" stroke-width="2"/>'
                +'<g stroke="#fff" stroke-width="7" stroke-linecap="round"><path d="M-46 62 L46 -6"/><path d="M46 62 L-46 -6"/></g>'
                +'<g stroke="#ffd34d" stroke-width="3" stroke-linecap="round"><path d="M-46 62 L46 -6"/><path d="M46 62 L-46 -6"/></g>'
                +'<text x="0" y="48" font-size="26" text-anchor="middle" fill="#ffe27a" font-weight="900">★★★</text>'
                +'</g>'
                +'<g fill="#ffd34d"><path d="M70 60 l6 14 14 6 -14 6 -6 14 -6 -14 -14 -6 14 -6z"/><path d="M330 90 l5 11 11 5 -11 5 -5 11 -5 -11 -11 -5 11 -5z"/><path d="M340 230 l4 9 9 4 -9 4 -4 9 -4 -9 -9 -4 9 -4z"/></g>';

        }
        else if(m==="classic"){

            hero=
                '<g transform="translate(200 150)">'
                +'<circle r="104" fill="#0c1424" stroke="url(#mg'+m+')" stroke-width="8"/>'
                +'<circle r="78" fill="none" stroke="#fff" stroke-width="6" opacity=".9"/>'
                +'<circle r="52" fill="none" stroke="url(#mg'+m+')" stroke-width="8"/>'
                +'<circle r="26" fill="#ff4d6d" stroke="#fff" stroke-width="4"/>'
                +'<g stroke="#fff" stroke-width="3" opacity=".7"><path d="M-120 0 H120"/><path d="M0 -120 V120"/></g>'
                +'<g fill="#ffe08a" stroke="#0c1424" stroke-width="2"><circle cx="14" cy="-10" r="6"/><circle cx="-42" cy="30" r="6"/><circle cx="56" cy="40" r="6"/><circle cx="-8" cy="-60" r="6"/></g>'
                +'<g transform="rotate(-35) translate(70 -4)"><rect width="84" height="16" rx="5" fill="#9fb0d3" stroke="#fff" stroke-width="2"/><rect x="-14" y="2" width="22" height="26" rx="4" fill="#6b4a2b"/></g>'
                +'</g>';

        }
        else if(m==="arcade"){

            hero=
                '<g transform="translate(200 150)">'
                +'<g transform="rotate(-18) translate(-70 0)"><rect x="-44" y="-62" width="88" height="124" rx="12" fill="#1b1230" stroke="url(#mg'+m+')" stroke-width="6"/><text y="14" font-size="48" text-anchor="middle">🧲</text></g>'
                +'<g transform="rotate(18) translate(70 0)"><rect x="-44" y="-62" width="88" height="124" rx="12" fill="#1b1230" stroke="url(#mg'+m+')" stroke-width="6"/><text y="14" font-size="48" text-anchor="middle">⏳</text></g>'
                +'<g transform="translate(0 -6)"><rect x="-48" y="-68" width="96" height="136" rx="12" fill="url(#mg'+m+')" stroke="#fff" stroke-width="5"/><text y="16" font-size="56" text-anchor="middle">🃏</text></g>'
                +'</g>';

        }
        else if(m==="story"){

            hero=
                '<g transform="translate(200 150)">'
                +'<path d="M-100 -60 Q-50 -80 0 -56 Q50 -80 100 -60 L100 70 Q50 50 0 72 Q-50 50 -100 70Z" fill="#fff6dc" stroke="#ffd34d" stroke-width="5"/>'
                +'<path d="M0 -56 V72" stroke="#c9a24d" stroke-width="4"/>'
                +'<g stroke="#c9a24d" stroke-width="4" stroke-linecap="round"><path d="M-80 -30 Q-50 -42 -18 -30"/><path d="M-80 -6 Q-50 -18 -18 -6"/><path d="M-80 18 Q-50 6 -18 18"/><path d="M18 -30 Q50 -42 80 -30"/><path d="M18 -6 Q50 -18 80 -6"/></g>'
                +'<text x="52" y="52" font-size="40" text-anchor="middle">⭐</text>'
                +'</g>';

        }
        else if(m==="friend"){

            hero=
                '<g transform="translate(200 150)">'
                +'<g transform="translate(-84 0)"><circle r="54" fill="#0c1424" stroke="#4d8dff" stroke-width="7"/><text y="18" font-size="56" text-anchor="middle">🔵</text></g>'
                +'<g transform="translate(84 0)"><circle r="54" fill="#0c1424" stroke="#ff4d6d" stroke-width="7"/><text y="18" font-size="56" text-anchor="middle">🔴</text></g>'
                +'<text y="22" font-size="64" text-anchor="middle" fill="#fff" font-weight="900" font-style="italic" stroke="#ff8a3d" stroke-width="3">VS</text>'
                +'<g fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".85"><path d="M-30 -84 Q0 -108 30 -84"/><path d="M-18 -72 Q0 -88 18 -72"/></g>'
                +'<circle cy="-60" r="5" fill="#fff"/>'
                +'<g stroke="#fff" stroke-width="4" stroke-linecap="round" opacity=".7"><path d="M-40 80 H40"/><path d="M-26 94 H26"/></g>'
                +'</g>';

        }
        else{

            hero=
                '<g transform="translate(200 150)">'
                +'<g transform="rotate(14)"><circle r="64" fill="url(#mg'+m+')" stroke="#fff" stroke-width="5"/><circle r="26" fill="#0c1424"/>'
                +[0,1,2,3,4,5,6,7].map(i=>'<rect x="-10" y="-84" width="20" height="26" rx="4" fill="url(#mg'+m+')" stroke="#fff" stroke-width="3" transform="rotate('+(i*45)+')"/>').join("")
                +'</g>'
                +'<g transform="translate(-92 56)"><rect width="46" height="46" rx="8" fill="#1f8fd1" stroke="#fff" stroke-width="3"/><rect x="8" y="8" width="30" height="30" rx="4" fill="#0c1424" opacity=".4"/></g>'
                +'<g transform="translate(56 54) rotate(-12)"><rect width="56" height="18" rx="6" fill="#ffd34d" stroke="#fff" stroke-width="3"/><circle cx="12" cy="9" r="3" fill="#0c1424"/><circle cx="28" cy="9" r="3" fill="#0c1424"/><circle cx="44" cy="9" r="3" fill="#0c1424"/></g>'
                +'<text x="0" y="8" font-size="38" text-anchor="middle">🔫</text>'
                +'</g>';

        }

        return '<svg viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">'
            +defs
            +'<rect width="400" height="300" fill="#070b16"/>'
            +'<rect width="400" height="300" fill="url(#mr'+m+')"/>'
            +'<g class="mRays">'+rays+'</g>'
            +'<g class="mHero">'+hero+'</g>'
            +'</svg>';

    }

    function renderModes(){

        arcBgmStop();


        if(!profile)loadProfile();

        updateWallet();

        $("mWallet").textContent=$("menuStats").textContent;

        document.querySelectorAll("#mTabs .mTab").forEach(t=>{
            t.classList.toggle("on",t.dataset.m===curMode);
        });

        const M=MODES[curMode];

        const box=$("mPrev");

        box.style.setProperty("--c1",M.c1);
        box.style.setProperty("--c2",M.c2);

        $("mArt").innerHTML=modeArt(curMode);
        $("mBadge").textContent=M.badge;
        $("mName").textContent=M.icon+" "+M.name;
        $("mDesc").textContent=M.desc;
        $("mFeat").innerHTML=M.feat.map(f=>"<li>"+f+"</li>").join("");

        let extra="";

        if(curMode==="ranked"){
            extra="Rank kamu: "+rankText(profile.rp)+"  •  Juara: "+REWARD_CHAMP+" 🪙";
        }

        const arcOk=arcUnlocked();

        $("mPlay").style.opacity=(curMode==="arcade"&&!arcOk)?".45":"";

        if(curMode==="arcade"){
            extra=arcOk
                ?"Siap bermain! Pilih 5 kartu sebelum bertanding."
                :"🔒 Terkunci • Butuh "+ARC_MIN_SKILL+" skill (kamu: "+profile.unlocked.length+") & Level "+ARC_MIN_LVL+" (kamu: "+levelOf(profile.xp)+")";
        }

        if(curMode==="story")extra="Progres: Bab "+Math.min(10,((profile.story&&profile.story.done)||0))+" / 10"+" selesai";

        if(curMode==="friend")extra="Butuh 2 HP di hotspot yang sama  •  Kamera dipakai untuk scan QR";
        $("mExtra").textContent=extra;

        box.classList.remove("pop");
        void box.offsetWidth;
        box.classList.add("pop");

    }

    document.querySelectorAll("#mTabs .mTab").forEach(t=>{
        t.onclick=()=>{
            if(curMode!==t.dataset.m)snd("boost");
            curMode=t.dataset.m;
            renderModes();
        };
    });

    $("mPlay").onclick=()=>{

        if(curMode==="sandbox")enterSandbox();
        else if(curMode==="friend")openVs();
        else if(curMode==="story")openStory();
        else if(curMode==="arcade"){
            if(!arcUnlocked()){snd("boost");return;}
            openArcDeck();
        }
        else openRankSetup(curMode);

    };

    /* ==================================================
       v1.5: GRAFIK VERY HIGH (EFEK PENUH WARNA)
    ================================================== */

    const spriteCache=new Map();

    function hslRgb(h,s,l){

        h=((h%360)+360)%360/360;

        const f=(p,q,t)=>{
            if(t<0)t+=1;
            if(t>1)t-=1;
            if(t<1/6)return p+(q-p)*6*t;
            if(t<1/2)return q;
            if(t<2/3)return p+(q-p)*(2/3-t)*6;
            return p;
        };

        const q=l<.5?l*(1+s):l+s-l*s;
        const p2=2*l-q;

        return[
            Math.round(f(p2,q,h+1/3)*255),
            Math.round(f(p2,q,h)*255),
            Math.round(f(p2,q,h-1/3)*255)
        ];

    }

    function hexRgb(hex){

        const n=parseInt(hex.slice(1),16);

        return[(n>>16)&255,(n>>8)&255,n&255];

    }

    function spr(rgb){

        const key=(rgb[0]>>4)+","+(rgb[1]>>4)+","+(rgb[2]>>4);

        let c=spriteCache.get(key);

        if(c)return c;

        c=document.createElement("canvas");

        c.width=c.height=64;

        const g=c.getContext("2d");

        const gr=g.createRadialGradient(32,32,0,32,32,32);

        gr.addColorStop(0,"rgba(255,255,255,1)");
        gr.addColorStop(.28,"rgba("+rgb[0]+","+rgb[1]+","+rgb[2]+",.9)");
        gr.addColorStop(1,"rgba("+rgb[0]+","+rgb[1]+","+rgb[2]+",0)");

        g.fillStyle=gr;
        g.fillRect(0,0,64,64);

        spriteCache.set(key,c);

        return c;

    }

    const HUE={
        heal:[95,170],
        shield:[170,225],
        nuclear:[60,130],
        clone:[250,310],
        boost:[0,360],
        muzzle:[30,60],
        death:[320,380],
        hit:[345,385]
    };

    const richRings=[];

    function richTag(n0,x,y,a,type){

        const rg=HUE[type]||[0,360];

        const special=type!=="hit"&&type!=="muzzle";

        for(let i=n0;i<particles.length;i++){

            const p=particles[i];

            let h=rg[0]+Math.random()*(rg[1]-rg[0]);

            if(special&&Math.random()<.35)h=Math.random()*360;

            p.rgb=hslRgb(h,1,.62);

            if(special){
                p.life*=1.35;
                p.max*=1.35;
                p.size*=1.25;
            }

        }

        if(special){

            const extra=Math.min(40,Math.round(a*.7));

            for(let i=0;i<extra;i++){

                const ang=Math.random()*Math.PI*2;
                const sp=90+Math.random()*320;

                const life=.55+Math.random()*.7;

                particles.push({
                    x:x,
                    y:y,
                    vx:Math.cos(ang)*sp,
                    vy:Math.sin(ang)*sp,
                    life:life,
                    max:life,
                    type:"spark",
                    size:2+Math.random()*3,
                    star:true,
                    rgb:hslRgb(Math.random()*360,1,.65)
                });

            }

        }

        if(a>=10&&richRings.length<30){

            richRings.push({
                x:x,
                y:y,
                r:6,
                max:50+Math.min(90,a*2),
                life:.55,
                t:0,
                rgb:hslRgb(rg[0]+Math.random()*(rg[1]-rg[0]),1,.65)
            });

        }

    }

    function richStar(x,y,r,rot){

        ctx.beginPath();

        for(let i=0;i<8;i++){
            const rr=i%2?r*.28:r;
            const a=rot+i*Math.PI/4;
            ctx.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr);
        }

        ctx.closePath();

        ctx.fill();

    }

    let richT=performance.now();

    function richDraw(){

        const nowMs=performance.now();

        const dt=Math.min(.05,(nowMs-richT)/1000);

        richT=nowMs;

        const now=nowMs/1000;

        ctx.save();

        ctx.globalCompositeOperation="lighter";

        /* ---- aura karakter menurut warna skill + bintang pelangi ---- */

        for(let i=0;i<objects.length;i++){

            const o=objects[i];

            if(o.type!=="character"||o.hp<=0)continue;

            const art=ART[o.skill]||ART.normal;

            const rgb=hexRgb(art.aura);

            const pulse=1+.12*Math.sin(now*3+o.id);

            ctx.globalAlpha=.55;

            ctx.drawImage(spr(rgb),o.x-58*pulse,o.y-58*pulse,116*pulse,116*pulse);

            for(let k=0;k<3;k++){

                const a=now*2.2+k*2.094+o.id;

                const ox=o.x+Math.cos(a)*38;
                const oy=o.y+Math.sin(a)*38*.8;

                ctx.globalAlpha=.95;

                ctx.drawImage(spr(hslRgb(now*90+k*120,1,.62)),ox-9,oy-9,18,18);

            }

            if(o.goldenImmune>0||o.immuneTimer>0){

                ctx.globalAlpha=.55+.25*Math.sin(now*12);

                ctx.drawImage(spr([255,214,80]),o.x-70,o.y-70,140,140);

            }

        }

        /* ---- klon ---- */

        for(let i=0;i<clones.length;i++){

            const c=clones[i];

            if(c.dead)continue;

            ctx.globalAlpha=.4;

            ctx.drawImage(spr(c.team==="blue"?[90,170,255]:[255,100,130]),c.x-32,c.y-32,64,64);

        }

        /* ---- peluru: cahaya + jejak berwarna ---- */

        for(let i=0;i<bullets.length;i++){

            const b=bullets[i];

            let rgb;

            if(b.pierce)rgb=[255,60,60];
            else if(b.magnet)rgb=[190,120,255];
            else{
                const sk=b.shooter&&b.shooter.skill?b.shooter.skill:"normal";
                rgb=hexRgb((ART[sk]||ART.normal).aura);
            }

            if(!b.tr)b.tr=[];

            b.tr.push(b.x,b.y);

            if(b.tr.length>20)b.tr.splice(0,2);

            ctx.lineCap="round";

            for(let k=0;k+3<b.tr.length;k+=2){

                const f=k/b.tr.length;

                ctx.globalAlpha=f*.7;

                ctx.strokeStyle="rgb("+rgb[0]+","+rgb[1]+","+rgb[2]+")";

                ctx.lineWidth=2+f*5;

                ctx.beginPath();
                ctx.moveTo(b.tr[k],b.tr[k+1]);
                ctx.lineTo(b.tr[k+2],b.tr[k+3]);
                ctx.stroke();

            }

            ctx.globalAlpha=.95;

            ctx.drawImage(spr(rgb),b.x-15,b.y-15,30,30);

        }

        /* ---- lubang hitam: lengan spiral pelangi ---- */

        for(let i=0;i<blackholes.length;i++){

            const h=blackholes[i];

            if(h.exploded)continue;

            for(let arm=0;arm<4;arm++){

                for(let k=0;k<26;k++){

                    const f=k/26;

                    const a=now*4+arm*Math.PI/2+f*5;

                    const r=f*h.pullRadius*.55;

                    ctx.globalAlpha=(1-f)*.8;

                    ctx.drawImage(
                        spr(hslRgb(now*120+arm*90+f*200,1,.6)),
                        h.x+Math.cos(a)*r-6,
                        h.y+Math.sin(a)*r-6,
                        12,
                        12
                    );

                }

            }

        }

        /* ---- waktu berhenti: gelombang pelangi ---- */

        if(timeFreeze&&timeFreeze.caster&&Math.random()<.25&&richRings.length<30){

            richRings.push({
                x:timeFreeze.caster.x,
                y:timeFreeze.caster.y,
                r:10,
                max:260,
                life:.9,
                t:0,
                rgb:hslRgb(now*160,1,.65)
            });

        }

        /* ---- cincin gelombang kejut ---- */

        for(let i=richRings.length-1;i>=0;i--){

            const r=richRings[i];

            r.t+=dt;

            const f=r.t/r.life;

            if(f>=1){
                richRings.splice(i,1);
                continue;
            }

            const rad=r.r+(r.max-r.r)*Math.sin(f*Math.PI/2);

            ctx.globalAlpha=(1-f)*.9;

            ctx.strokeStyle="rgb("+r.rgb[0]+","+r.rgb[1]+","+r.rgb[2]+")";

            ctx.lineWidth=2+6*(1-f);

            ctx.beginPath();
            ctx.arc(r.x,r.y,rad,0,Math.PI*2);
            ctx.stroke();

            ctx.globalAlpha=(1-f)*.35;

            ctx.lineWidth=1;

            ctx.beginPath();
            ctx.arc(r.x,r.y,rad*.78,0,Math.PI*2);
            ctx.stroke();

        }

        /* ---- partikel berpendar ---- */

        for(let i=0;i<particles.length;i++){

            const p=particles[i];

            const al=Math.max(0,p.life/p.max);

            const rgb=p.rgb||[255,120,140];

            const s=p.size*(p.star?2.2:3.2);

            ctx.globalAlpha=al;

            if(p.star){

                ctx.fillStyle="rgb("+rgb[0]+","+rgb[1]+","+rgb[2]+")";

                richStar(p.x,p.y,s,now*6+i);

            }
            else{

                ctx.drawImage(spr(rgb),p.x-s,p.y-s,s*2,s*2);

            }

        }

        ctx.restore();

        ctx.globalAlpha=1;

    }

    /* ---------- EFEK STATUS (SEMUA KUALITAS): AREA SEDOT, RADIASI, LINGLUNG ---------- */

    function drawStatusFX(){

        const now=performance.now()/1000;

        const rich=!!Q.rich;

        ctx.save();

        for(let i=0;i<objects.length;i++){

            const o=objects[i];

            if(o.type!=="character")continue;

            /* Ice: efek beku pada musuh */

            if(o.hp>0&&(o.iceSlow>0||o.iceFrost>0)){

                const ia=o.iceSlow>0?.75:.4;

                ctx.strokeStyle="rgba(170,230,255,"+ia+")";
                ctx.fillStyle="rgba(160,225,255,"+(ia*.22)+")";
                ctx.lineWidth=2;

                ctx.beginPath();
                ctx.arc(o.x,o.y,30+Math.sin(now*9)*1.5,0,Math.PI*2);
                ctx.fill();
                ctx.stroke();

                if(o.iceSlow>0){
                    for(let k=0;k<6;k++){
                        const a=k*Math.PI/3+now*1.2;
                        ctx.fillStyle="rgba(235,250,255,.9)";
                        ctx.fillRect(o.x+Math.cos(a)*34-2,o.y+Math.sin(a)*34-2,4,4);
                    }
                }

            }

            /* Ice: arena membeku */

            if(o.iceZone&&o.hp>0){

                const z=o.iceZone;

                const k=Math.max(0,Math.min(1,(z.max-z.t)/.6,z.t/.7));

                ctx.save();

                ctx.fillStyle="rgba(150,215,255,"+(.17*k)+")";
                ctx.fillRect(0,0,W,H);

                const g2=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.25,W/2,H/2,Math.max(W,H)*.75);
                g2.addColorStop(0,"rgba(220,245,255,0)");
                g2.addColorStop(1,"rgba(220,245,255,"+(.5*k)+")");
                ctx.fillStyle=g2;
                ctx.fillRect(0,0,W,H);

                ctx.strokeStyle="rgba(230,248,255,"+(.5*k)+")";
                ctx.lineWidth=1.5;

                for(let i=0;i<(window.POTATO?3:14);i++){
                    const sx=(i*137.5)%W;
                    const sy=(i*71.3)%(H*.7);
                    const L=26+(i%4)*10;
                    for(let a=0;a<3;a++){
                        const an=a*Math.PI/3+i;
                        ctx.beginPath();
                        ctx.moveTo(sx-Math.cos(an)*L,sy-Math.sin(an)*L);
                        ctx.lineTo(sx+Math.cos(an)*L,sy+Math.sin(an)*L);
                        ctx.stroke();
                    }
                }

                for(let i=0;i<(window.POTATO?8:46);i++){
                    const sx=(i*97.3+now*(10+(i%5)*6))%W;
                    const sy=(i*53.7+now*(28+(i%7)*9))%H;
                    ctx.fillStyle="rgba(255,255,255,"+(.85*k)+")";
                    ctx.beginPath();
                    ctx.arc(sx,sy,1.2+(i%3),0,Math.PI*2);
                    ctx.fill();
                }

                ctx.restore();

            }

            /* area sedot Lifesteal */

            if(o.lsZone&&o.hp>0){

                const z=o.lsZone;

                const fade=Math.min(1,z.t/.5);

                const pulse=1+.04*Math.sin(now*8);

                const gr=ctx.createRadialGradient(o.x,o.y,10,o.x,o.y,z.r*pulse);

                gr.addColorStop(0,"rgba(255,40,90,0)");
                gr.addColorStop(.7,"rgba(255,40,90,"+(.14*fade)+")");
                gr.addColorStop(1,"rgba(255,60,110,"+(.32*fade)+")");

                ctx.fillStyle=gr;

                ctx.beginPath();
                ctx.arc(o.x,o.y,z.r*pulse,0,Math.PI*2);
                ctx.fill();

                ctx.strokeStyle="rgba(255,90,130,"+(.9*fade)+")";
                ctx.lineWidth=3;
                ctx.setLineDash([14,10]);
                ctx.lineDashOffset=-now*60;

                ctx.beginPath();
                ctx.arc(o.x,o.y,z.r*pulse,0,Math.PI*2);
                ctx.stroke();

                ctx.setLineDash([]);

                /* tetesan darah menuju pusat */

                for(let k=0;k<8;k++){

                    const a=now*1.6+k*Math.PI/4;

                    const f=((now*.9+k*.13)%1);

                    const rr=z.r*(1-f);

                    ctx.fillStyle="rgba(255,"+(60+k*10)+",110,"+(.8*fade*(1-f*.4))+")";

                    ctx.beginPath();
                    ctx.arc(o.x+Math.cos(a)*rr,o.y+Math.sin(a)*rr,3.2,0,Math.PI*2);
                    ctx.fill();

                }

            }

            /* Regen: tali penyembuh ke teman */

            if(o.regenLink&&o.hp>0&&o.regenLink.hp>0){

                const L=o.regenLink;

                ctx.strokeStyle="rgba(125,255,176,.85)";
                ctx.lineWidth=3;
                ctx.setLineDash([8,8]);
                ctx.lineDashOffset=-now*40;
                ctx.shadowColor="#7dffb0";
                ctx.shadowBlur=rich?14:6;

                ctx.beginPath();
                ctx.moveTo(o.x,o.y);
                ctx.lineTo(L.x,L.y);
                ctx.stroke();

                ctx.setLineDash([]);
                ctx.shadowBlur=0;

                const f=(now*.8)%1;

                ctx.fillStyle="#c8ffe0";
                ctx.beginPath();
                ctx.arc(o.x+(L.x-o.x)*f,o.y+(L.y-o.y)*f,4,0,Math.PI*2);
                ctx.fill();

            }

            /* Ghost: tubuh asli diam, tali ke tubuh yang dirasuki */

            if(o.ghostIn&&o.hp>0){

                ctx.fillStyle="rgba(120,60,200,.35)";
                ctx.beginPath();
                ctx.arc(o.x,o.y,34,0,Math.PI*2);
                ctx.fill();

                ctx.font="18px sans-serif";
                ctx.textAlign="center";
                ctx.fillText("💤",o.x,o.y-44+Math.sin(now*3)*3);

                if(o.possessing&&o.possessing.hp>0){

                    ctx.strokeStyle="rgba(190,140,255,.8)";
                    ctx.lineWidth=2;
                    ctx.setLineDash([4,8]);
                    ctx.lineDashOffset=-now*50;
                    ctx.beginPath();
                    ctx.moveTo(o.x,o.y);
                    ctx.lineTo(o.possessing.x,o.possessing.y);
                    ctx.stroke();
                    ctx.setLineDash([]);

                }

            }

            if(o.possessedBy&&o.hp>0){

                const pulse=1+.08*Math.sin(now*9);

                const gr=ctx.createRadialGradient(o.x,o.y,10,o.x,o.y,48*pulse);

                gr.addColorStop(0,"rgba(190,120,255,0)");
                gr.addColorStop(1,"rgba(190,120,255,.55)");

                ctx.fillStyle=gr;
                ctx.beginPath();
                ctx.arc(o.x,o.y,48*pulse,0,Math.PI*2);
                ctx.fill();

                ctx.font="20px sans-serif";
                ctx.textAlign="center";
                ctx.fillStyle="#fff";
                ctx.fillText("👻",o.x,o.y-48+Math.sin(now*5)*3);

                ctx.font="bold 12px sans-serif";
                ctx.fillText(Math.max(0,Math.ceil(o.possT||0))+"s",o.x,o.y+54);

            }

            /* radiasi Nuklir (seluruh arena) */

            if(o.radT>0&&o.hp>0){

                const f=o.radT/(o.radMax||3);

                const al=(.07+.04*Math.sin(now*10))*Math.min(1,f*3);

                ctx.fillStyle=rich?"rgba(140,255,40,"+(al*1.5)+")":"rgba(120,255,60,"+al+")";

                ctx.fillRect(0,0,W,H*.70);

                ctx.save();

                ctx.translate(W/2,H*.35);
                ctx.rotate(now*.8);
                ctx.globalAlpha=.16*Math.min(1,f*3);
                ctx.fillStyle="#b6ff3a";

                for(let k=0;k<3;k++){

                    ctx.rotate(Math.PI*2/3);

                    ctx.beginPath();
                    ctx.moveTo(0,0);
                    ctx.arc(0,0,Math.min(W,H)*.36,-Math.PI/6,Math.PI/6);
                    ctx.closePath();
                    ctx.fill();

                }

                ctx.restore();

                if(Math.random()<.5){
                    const px=Math.random()*W;
                    const py=Math.random()*H*.70;
                    particles.push({
                        x:px,y:py,vx:0,vy:-40-Math.random()*40,
                        life:.9,max:.9,type:"nuclear",size:2+Math.random()*3,
                        rgb:[170,255,60]
                    });
                }

            }

            /* linglung: bintang berputar di atas kepala */

            if(o.dazeTimer>0&&o.hp>0){

                ctx.font="16px sans-serif";
                ctx.textAlign="center";

                for(let k=0;k<3;k++){

                    const a=now*6+k*2.094;

                    ctx.fillText("⭐",o.x+Math.cos(a)*22,o.y-40+Math.sin(a)*6);

                }

            }

        }

        /* roh Ghost yang melesat */

        for(let i=0;i<spirits.length;i++){

            const sp=spirits[i];

            const g=ctx.createRadialGradient(sp.x,sp.y,2,sp.x,sp.y,22);

            g.addColorStop(0,"rgba(255,255,255,1)");
            g.addColorStop(.4,"rgba(190,130,255,.9)");
            g.addColorStop(1,"rgba(120,60,200,0)");

            ctx.fillStyle=g;
            ctx.beginPath();
            ctx.arc(sp.x,sp.y,22,0,Math.PI*2);
            ctx.fill();

            ctx.font="16px sans-serif";
            ctx.textAlign="center";
            ctx.fillText("👻",sp.x,sp.y+6);

        }

        /* dimensi Ghost */

        if(dimension){

            const left=Math.max(0,dimension.dur-dimension.t);

            ctx.fillStyle="rgba(30,0,60,.42)";
            ctx.fillRect(0,0,W,H*.70);

            const cx=W/2,cy=H*.34;

            for(let k=0;k<5;k++){

                const r=((now*70+k*60)%300);

                ctx.strokeStyle="rgba(190,140,255,"+(.5*(1-r/300))+")";
                ctx.lineWidth=3;
                ctx.beginPath();
                ctx.arc(cx,cy,r,0,Math.PI*2);
                ctx.stroke();

            }

            ctx.save();
            ctx.translate(cx,cy);
            ctx.rotate(now*.6);
            ctx.strokeStyle="rgba(220,180,255,.35)";
            ctx.lineWidth=2;

            for(let k=0;k<6;k++){
                ctx.rotate(Math.PI/3);
                ctx.beginPath();
                ctx.moveTo(20,0);
                ctx.quadraticCurveTo(80,40,160,0);
                ctx.stroke();
            }

            ctx.restore();

            ctx.font="bold 18px sans-serif";
            ctx.textAlign="center";
            ctx.fillStyle="#e8d4ff";
            ctx.shadowColor="#b388ff";
            ctx.shadowBlur=12;
            ctx.fillText("👻 DIMENSI "+Math.ceil(left),W/2,34);
            ctx.shadowBlur=0;

        }

        ctx.restore();

    }

    const origDrawP=window.drawParticles;

    window.drawParticles=function(){

        drawStatusFX();

        if(Q.rich)richDraw();
        else origDrawP();

    };


    /* ==================================================
       v1.6: 1VS1 WITH FRIEND (lokal via hotspot, QR)
    ================================================== */

    const VS_BANS_EACH=2;
    const VS_BAN_T=12;
    const VS_PICK_T=20;
    const VS_REVEAL_T=3.5;

    function vsPanel(id){
        document.querySelectorAll("#vsScr .vsPanel").forEach(p=>{
            p.classList.toggle("on",p.id===id);
        });
    }

    function vsMyName(){
        const t=($("userChip").textContent||"").replace("👤","").trim();
        return (t||"Pemain").slice(0,14);
    }

    function vsNameOf(role){
        const n=vs.names[role]||(role==="host"?"Host":"Teman");
        if(vs.names.host&&vs.names.host===vs.names.guest)return n+(role==="host"?" (Host)":" (Teman)");
        return n;
    }

    function vsSend(o){
        try{
            if(vs.cc&&vs.cc.readyState==="open")vs.cc.send(JSON.stringify(o));
        }catch(e){}
    }

    function vsSendFast(o){
        try{
            const ch=(vs.sc&&vs.sc.readyState==="open")?vs.sc:vs.cc;
            if(ch&&ch.readyState==="open")ch.send(JSON.stringify(o));
        }catch(e){}
    }

    /* ---------- QR ---------- */

    function drawQR(id,text){

        const q=new QRLib.QRCode(0,QRLib.ECL.L);
        q.addData(text);
        q.make();

        const n=q.getModuleCount();
        const px=Math.max(3,Math.floor(320/(n+8)));
        const size=(n+8)*px;

        const cv=$(id);
        cv.width=size;
        cv.height=size;

        const g=cv.getContext("2d");

        g.fillStyle="#fff";
        g.fillRect(0,0,size,size);
        g.fillStyle="#000";

        for(let r=0;r<n;r++){
            for(let c=0;c<n;c++){
                if(q.isDark(r,c))g.fillRect((c+4)*px,(r+4)*px,px,px);
            }
        }

    }

    /* ---------- SDP ringkas (muat di QR kecil) ---------- */

    function sdpCompress(desc){

        const sdp=desc.sdp||"";

        const u=/a=ice-ufrag:(\S+)/.exec(sdp);
        const p=/a=ice-pwd:(\S+)/.exec(sdp);
        const f=/a=fingerprint:sha-256 ([0-9A-Fa-f:]+)/.exec(sdp);

        if(!u||!p||!f)throw new Error("SDP tidak lengkap");

        const bytes=f[1].split(":").map(h=>parseInt(h,16));

        const fp=btoa(String.fromCharCode.apply(null,bytes));

        const cands=[];

        sdp.split(/\r?\n/).forEach(l=>{
            const m=/^a=candidate:\S+ \d+ udp \d+ (\S+) (\d+) typ host/.exec(l);
            if(!m)return;
            if(/^\d+\.\d+\.\d+\.\d+$/.test(m[1])||/\.local$/.test(m[1])){
                cands.push(m[1]+":"+m[2]);
            }
        });

        if(!cands.length)throw new Error("NOCAND");

        return "TDS1|"+u[1]+"|"+p[1]+"|"+fp+"|"+cands.join(",");

    }

    function sdpExpand(code,type){

        const parts=code.trim().split("|");

        if(parts[0]!=="TDS1"||parts.length<5)throw new Error("Kode tidak valid");

        const bytes=atob(parts[3]).split("").map(c=>("0"+c.charCodeAt(0).toString(16)).slice(-2).toUpperCase());

        const lines=[
            "v=0",
            "o=- "+Math.floor(Math.random()*1e15)+" 2 IN IP4 127.0.0.1",
            "s=-",
            "t=0 0",
            "a=group:BUNDLE 0",
            "a=extmap-allow-mixed",
            "a=msid-semantic: WMS",
            "m=application 9 UDP/DTLS/SCTP webrtc-datachannel",
            "c=IN IP4 0.0.0.0"
        ];

        parts[4].split(",").forEach((c,i)=>{
            const k=c.lastIndexOf(":");
            lines.push("a=candidate:"+(i+1)+" 1 udp "+(2113937151-i)+" "+c.slice(0,k)+" "+c.slice(k+1)+" typ host generation 0");
        });

        lines.push(
            "a=ice-ufrag:"+parts[1],
            "a=ice-pwd:"+parts[2],
            "a=fingerprint:sha-256 "+bytes.join(":"),
            "a=setup:"+(type==="offer"?"actpass":"active"),
            "a=mid:0",
            "a=sctp-port:5000",
            "a=max-message-size:262144"
        );

        return lines.join("\r\n")+"\r\n";

    }

    function gathered(pc){

        return new Promise(res=>{

            if(pc.iceGatheringState==="complete")return res();

            const to=setTimeout(res,3500);

            pc.addEventListener("icegatheringstatechange",()=>{
                if(pc.iceGatheringState==="complete"){
                    clearTimeout(to);
                    res();
                }
            });

        });

    }

    /* ---------- kamera & pemindai ---------- */

    async function ensureCam(){

        if(vs.cam&&vs.cam.active)return true;

        try{

            vs.cam=await navigator.mediaDevices.getUserMedia({
                video:{facingMode:{ideal:"environment"}},
                audio:false
            });

            return true;

        }
        catch(e){

            vs.cam=null;

            return false;

        }

    }

    function stopCam(){

        if(vs.cam){
            vs.cam.getTracks().forEach(t=>{try{t.stop()}catch(e){}});
            vs.cam=null;
        }

    }

    function stopScan(){

        vs.scanOn=false;

        clearInterval(vs.scanIv);

        vs.scanIv=null;

        try{$("vsVideo").srcObject=null}catch(e){}

    }

    function startScan(title,hint,onCode){

        stopScan();

        $("vsSTitle").textContent=title;
        $("vsSStat").textContent=hint;
        $("vsSIn").value="";

        vsPanel("vsScan");

        const v=$("vsVideo");

        if(!vs.cam){
            $("vsSStat").textContent="Kamera tidak aktif/izin ditolak. Pakai kode manual di bawah.";
            $("vsSMan").open=true;
            vs.onCode=onCode;
            return;
        }

        vs.onCode=onCode;
        vs.scanOn=true;

        v.srcObject=vs.cam;

        v.play().catch(()=>{});

        let busy=false;

        const cv=vs.cv||(vs.cv=document.createElement("canvas"));
        const cx=cv.getContext("2d",{willReadFrequently:true});

        let bd=null;

        try{
            if(window.BarcodeDetector)bd=new BarcodeDetector({formats:["qr_code"]});
        }catch(e){bd=null;}

        vs.scanIv=setInterval(async()=>{

            if(busy||!vs.scanOn||!v.videoWidth)return;

            busy=true;

            try{

                let txt=null;

                if(bd){
                    try{
                        const r=await bd.detect(v);
                        if(r&&r.length)txt=r[0].rawValue;
                    }
                    catch(e){bd=null;}
                }

                if(!txt){

                    const sc=Math.min(1,720/v.videoWidth);

                    cv.width=Math.round(v.videoWidth*sc);
                    cv.height=Math.round(v.videoHeight*sc);

                    cx.drawImage(v,0,0,cv.width,cv.height);

                    txt=QRDec.scan(cx.getImageData(0,0,cv.width,cv.height));

                }

                if(txt&&txt.indexOf("TDS1|")===0){
                    stopScan();
                    snd("boost");
                    onCode(txt);
                }

            }
            catch(e){}

            busy=false;

        },160);

    }

    /* ---------- koneksi WebRTC ---------- */

    function newPC(){

        const pc=new RTCPeerConnection({iceServers:[]});

        pc.onconnectionstatechange=()=>{
            if(vs.pc!==pc)return;
            if(pc.connectionState==="failed"){
                vsLost("Koneksi gagal. Pastikan kedua HP ada di hotspot yang sama.");
            }
        };

        return pc;

    }

    function wireChannel(ch){

        ch.onmessage=vsOnMsg;

        if(ch.label==="c"){

            vs.cc=ch;

            ch.onopen=()=>vsConnected();

            ch.onclose=()=>vsLost("Koneksi dengan teman terputus.");

            if(ch.readyState==="open")setTimeout(vsConnected,0);

        }
        else{

            vs.sc=ch;

        }

    }

    async function vsMake(){

        vsReset();

        vs.active=true;
        vs.role="host";
        vs.names={};

        $("vsWText").textContent="Menyiapkan room...";
        vsPanel("vsWait");

        await ensureCam();

        try{

            const pc=newPC();

            vs.pc=pc;

            wireChannel(pc.createDataChannel("c"));
            wireChannel(pc.createDataChannel("s",{ordered:false,maxRetransmits:0}));

            const off=await pc.createOffer();

            await pc.setLocalDescription(off);

            await gathered(pc);

            const code=sdpCompress(pc.localDescription);

            vs.code=code;

            drawQR("vsQrH",code);

            $("vsHCode").value=code;
            $("vsHStat").textContent="Menunggu teman scan...";

            vsPanel("vsHost");

        }
        catch(e){

            vsFail(e);

        }

    }

    function vsFail(e){

        const msg=(e&&e.message==="NOCAND")
            ?"Tidak ada jaringan lokal. Nyalakan hotspot (atau sambung ke hotspot teman) dulu."
            :"Gagal membuat koneksi: "+(e&&e.message?e.message:e);

        vsReset();

        $("vsHStat").textContent=msg;

        vsPanel("vsHome");

        alert(msg);

    }

    async function vsHostApply(code){

        try{

            $("vsHStat").textContent="Menyambungkan...";

            await vs.pc.setRemoteDescription({type:"answer",sdp:sdpExpand(code,"answer")});

            vsPanel("vsHost");

            $("vsHStat").textContent="Menyambungkan ke teman...";

            clearTimeout(vs.connTo);

            vs.connTo=setTimeout(()=>{
                if(vs.active&&!vs.connected){
                    $("vsHStat").textContent="Belum tersambung. Pastikan kedua HP di hotspot yang sama, lalu coba scan lagi.";
                }
            },15000);

        }
        catch(e){

            $("vsHStat").textContent="Kode tidak valid / sudah kedaluwarsa. Coba scan lagi.";

            vsPanel("vsHost");

        }

    }

    async function vsJoin(){

        vsReset();

        vs.active=true;
        vs.role="guest";
        vs.names={};

        $("vsWText").textContent="Membuka kamera...";
        vsPanel("vsWait");

        await ensureCam();

        startScan("📷 SCAN QR ROOM","Arahkan kamera ke QR di HP host.",vsGuestApply);

    }

    async function vsGuestApply(code){

        try{

            $("vsWText").textContent="Menyambungkan ke room...";
            vsPanel("vsWait");

            const pc=newPC();

            vs.pc=pc;

            pc.ondatachannel=e=>wireChannel(e.channel);

            await pc.setRemoteDescription({type:"offer",sdp:sdpExpand(code,"offer")});

            const ans=await pc.createAnswer();

            await pc.setLocalDescription(ans);

            await gathered(pc);

            const mine=sdpCompress(pc.localDescription);

            drawQR("vsQrG",mine);

            $("vsGCode").value=mine;
            $("vsGStat").textContent="Menunggu host scan QR ini...";

            vsPanel("vsGuest");

            clearTimeout(vs.connTo);

            vs.connTo=setTimeout(()=>{
                if(vs.active&&!vs.connected){
                    $("vsGStat").textContent="Belum tersambung. Minta host scan ulang QR ini.";
                }
            },60000);

        }
        catch(e){

            vsFail(e);

        }

    }

    function vsConnected(){

        if(vs.connected)return;

        vs.connected=true;

        clearTimeout(vs.connTo);

        stopScan();
        stopCam();

        snd("boost");

        vsSend({t:"hi",n:vsMyName()});

        vs.names[vs.role]=vsMyName();

        if(vs.role==="host"){
            setTimeout(vsStartDraft,600);
        }
        else{
            $("vsGStat").textContent="Tersambung! Menyiapkan sesi ban...";
        }

    }

    function vsLeaveDuelState(){

        vs.inDuel=false;

        clearInterval(vs.snapIv);
        clearInterval(vs.timeIv);

        netGuest=false;

        body.classList.remove("manualOn");

        setSpec(false);

        try{stopDuel()}catch(e){}

    }

    function vsLost(msg){

        if(!vs.active)return;

        forfeitNote=msg;

        showMenu();

    }

    function vsReset(){

        if(!vs.active&&!vs.pc&&!vs.cam)return;

        try{vsSend({t:"bye"})}catch(e){}

        clearTimeout(vs.connTo);
        clearInterval(vs.tickIv);
        clearInterval(vs.snapIv);
        clearInterval(vs.timeIv);
        clearInterval(vs.inIv);
        clearTimeout(vs.revealTo);

        stopScan();
        stopCam();

        const pc=vs.pc,cc=vs.cc,sc=vs.sc;

        vs.pc=null;
        vs.cc=null;
        vs.sc=null;

        try{if(cc){cc.onclose=null;cc.close();}}catch(e){}
        try{if(sc)sc.close();}catch(e){}
        try{if(pc){pc.onconnectionstatechange=null;pc.close();}}catch(e){}

        vs.active=false;
        vs.role=null;
        vs.connected=false;
        vs.inDuel=false;
        vs.me=null;
        vs.opp=null;
        vs.d=null;
        vs.cdRemote=null;
        vs.again={host:false,guest:false};

        netGuest=false;

        body.classList.remove("manualOn");

        $("vdReveal").classList.remove("on");

    }

    /* ---------- pesan jaringan ---------- */

    function vsOnMsg(ev){

        let m;

        try{m=JSON.parse(ev.data);}catch(e){return;}

        const host=vs.role==="host";

        switch(m.t){

            case "hi":
                vs.names[host?"guest":"host"]=String(m.n||"").slice(0,14);
                break;

            case "d":
                if(!host)vsDraftMsg(m);
                break;

            case "a":
                if(host)vsAct("guest",m.k,m.s);
                break;

            case "go":
                if(!host)vsGuestGo(m);
                break;

            case "in":
                if(host&&vs.opp&&vs.inDuel){
                    vs.opp.remoteInput={x:Math.max(-1,Math.min(1,+m.x||0)),y:Math.max(-1,Math.min(1,+m.y||0))};
                }
                break;

            case "sk":
                if(host&&vs.inDuel&&vs.opp&&!vs.opp.possessedBy)useSkillFor(ctlBody(vs.opp));
                break;

            case "sk2":
                if(host&&vs.inDuel&&vs.opp)useSkillFor2(vs.opp);
                break;

            case "s":
                if(!host)vsApply(m);
                break;

            case "end":
                if(!host)vsGuestEnd(m);
                break;

            case "again":
                if(host){
                    vs.again.guest=true;
                    if(vs.again.host)vsStartDraft();
                }
                break;

            case "bye":
                vsLost("Teman keluar dari room.");
                break;

        }

    }

    /* ---------- sesi ban & pilih skill ---------- */

    const VS_SKILLS=Object.keys(SKILLS);

    let vdBuilt=false;

    function vsBuildGrid(){

        if(vdBuilt)return;

        vdBuilt=true;

        const g=$("vdGrid");

        g.innerHTML="";

        VS_SKILLS.forEach(k=>{

            const a=ART[k]||ART.normal;

            const b=document.createElement("button");

            b.className="vdCard";
            b.dataset.k=k;
            b.style.setProperty("--c",a.aura);
            b.innerHTML='<span class="ic">'+SKILLS[k].icon+'</span><span class="nm">'+SKILLS[k].name+'</span>';

            b.onclick=()=>{
                if(b.classList.contains("banned")||b.classList.contains("off"))return;
                vs.sel=k;
                snd("boost");
                vsRenderDraft();
            };

            g.appendChild(b);

        });

    }

    function vsStartDraft(){

        if(vs.role!=="host"||!vs.connected)return;

        vsLeaveDuelState();

        vs.again={host:false,guest:false};

        const order=[];

        for(let i=0;i<VS_BANS_EACH;i++){order.push("host");order.push("guest");}

        vs.d={
            ph:"ban",
            idx:0,
            order:order,
            banned:[],
            bansBy:{host:[],guest:[]},
            picks:{host:null,guest:null},
            left:VS_BAN_T,
            max:VS_BAN_T
        };

        vs.sel=null;

        clearInterval(vs.tickIv);

        vs.tickIv=setInterval(vsTick,250);

        vsBroadcast();

        vsShowDraft();

    }

    function vsMsgOf(){

        const d=vs.d;

        return{
            t:"d",
            ph:d.ph,
            turn:d.ph==="ban"?d.order[d.idx]:null,
            banned:d.banned,
            bansBy:d.bansBy,
            left:Math.max(0,Math.round(d.left*10)/10),
            max:d.max,
            pd:{host:!!d.picks.host,guest:!!d.picks.guest},
            picks:d.ph==="reveal"?d.picks:null,
            names:vs.names
        };

    }

    function vsBroadcast(){

        const m=vsMsgOf();

        vsSend(m);

        vsDraftMsg(m,true);

    }

    function vsTick(){

        const d=vs.d;

        if(!d||!vs.active||vs.role!=="host")return;

        d.left-=.25;

        vs.tickN=(vs.tickN||0)+1;

        if(d.left<=0){

            if(d.ph==="ban"){
                d.idx++;
                if(d.idx>=d.order.length)vsToPick();
                else d.left=d.max=VS_BAN_T;
            }
            else if(d.ph==="pick"){
                ["host","guest"].forEach(w=>{
                    if(!d.picks[w]){
                        const ok=VS_SKILLS.filter(k=>d.banned.indexOf(k)<0);
                        d.picks[w]=ok[Math.floor(Math.random()*ok.length)];
                    }
                });
                vsToReveal();
            }
            else if(d.ph==="reveal"){
                clearInterval(vs.tickIv);
                vsBeginMatch();
                return;
            }

            vsBroadcast();

            return;

        }

        if(vs.tickN%4===0)vsBroadcast();
        else vsDraftMsg(vsMsgOf(),true);

    }

    function vsToPick(){

        const d=vs.d;

        d.ph="pick";
        d.left=d.max=VS_PICK_T;

        vs.sel=null;

    }

    function vsToReveal(){

        const d=vs.d;

        d.ph="reveal";
        d.left=d.max=VS_REVEAL_T;

    }

    function vsAct(who,k,s){

        const d=vs.d;

        if(!d||!SKILLS[s])return;

        if(k==="ban"&&d.ph==="ban"&&d.order[d.idx]===who&&d.banned.indexOf(s)<0){

            d.banned.push(s);
            d.bansBy[who].push(s);

            d.idx++;

            if(d.idx>=d.order.length)vsToPick();
            else d.left=d.max=VS_BAN_T;

            vsBroadcast();

        }
        else if(k==="pick"&&d.ph==="pick"&&!d.picks[who]&&d.banned.indexOf(s)<0){

            d.picks[who]=s;

            if(d.picks.host&&d.picks.guest)vsToReveal();

            vsBroadcast();

        }

    }

    function vsDraftMsg(m,local){

        if(!local){

            if(m.names){
                Object.keys(m.names).forEach(k=>{if(m.names[k])vs.names[k]=m.names[k];});
            }

            if(vs.inDuel)vsLeaveDuelState();

        }

        if(!vs.dv||vs.dv.ph!==m.ph)vs.sel=null;

        vs.dv=m;

        vsShowDraft();

        vsRenderDraft();

    }

    function vsShowDraft(){

        vsBuildGrid();

        if($("vsDraft").style.display!=="flex"){
            setCls(null);
            show("vsDraft");
        }

    }

    function vsRenderDraft(){

        const m=vs.dv;

        if(!m)return;

        const me=vs.role,op=me==="host"?"guest":"host";

        const scr=$("vsDraft");

        scr.classList.toggle("pick",m.ph==="pick"||m.ph==="reveal");

        $("vdPhase").textContent=m.ph==="ban"?"FASE BAN":(m.ph==="pick"?"PILIH SKILL":"BERSIAP!");

        const myTurn=m.ph==="ban"&&m.turn===me;

        const tEl=$("vdTurn");

        if(m.ph==="ban"){
            tEl.textContent=myTurn?"🔥 GILIRANMU BAN SKILL":"⏳ "+vsNameOf(op)+" sedang memilih ban...";
        }
        else if(m.ph==="pick"){
            tEl.textContent=m.pd[me]?"✅ Terkunci — menunggu "+vsNameOf(op):"Pilih skill yang akan kamu pakai";
        }
        else{
            tEl.textContent="Skill terkunci!";
        }

        tEl.classList.toggle("you",myTurn||(m.ph==="pick"&&!m.pd[me]));

        $("vdNameMe").textContent="🔵 "+vsNameOf(me);
        $("vdNameOp").textContent="🔴 "+vsNameOf(op);

        const slot=(id,list)=>{
            let h="";
            for(let i=0;i<VS_BANS_EACH;i++){
                const k=list[i];
                h+='<div class="vdBan'+(k?" used":"")+'">'+(k?SKILLS[k].icon:"")+'</div>';
            }
            $(id).innerHTML=h;
        };

        slot("vdBansMe",m.bansBy[me]||[]);
        slot("vdBansOp",m.bansBy[op]||[]);

        const pk=(id,who)=>{
            const el=$(id);
            const k=m.picks?m.picks[who]:null;
            if(k){
                el.className="vdPick done";
                el.textContent=SKILLS[k].icon;
            }
            else if(m.pd[who]){
                el.className="vdPick done";
                el.textContent="🔒";
            }
            else{
                el.className="vdPick";
                el.textContent="?";
            }
        };

        pk("vdPickMe",me);
        pk("vdPickOp",op);

        const sec=Math.ceil(m.left);

        $("vdSec").textContent=sec;

        const tm=$("vdTimer");

        tm.style.setProperty("--p",Math.max(0,Math.min(1,m.left/(m.max||1))));
        tm.classList.toggle("low",m.left<=4);

        /* kartu */

        const canAct=myTurn||(m.ph==="pick"&&!m.pd[me]);

        if(vs.sel&&m.banned.indexOf(vs.sel)>=0)vs.sel=null;

        document.querySelectorAll("#vdGrid .vdCard").forEach(c=>{
            const k=c.dataset.k;
            c.classList.toggle("banned",m.banned.indexOf(k)>=0);
            c.classList.toggle("sel",vs.sel===k&&canAct);
            c.classList.toggle("off",!canAct&&m.banned.indexOf(k)<0);
        });

        const ok=$("vdOk");

        ok.textContent=m.ph==="ban"?"🚫 BAN SKILL INI":"✅ PILIH SKILL INI";

        ok.disabled=!(canAct&&vs.sel);

        ok.style.display=(m.ph==="reveal")?"none":"";

        const info=$("vdInfo");

        if(vs.sel&&canAct){
            info.innerHTML="<b>"+SKILLS[vs.sel].icon+" "+SKILLS[vs.sel].name+"</b> — "+(DESC[vs.sel]||"");
        }
        else if(m.ph==="ban"){
            info.textContent=myTurn?"Pilih 1 skill untuk di-ban (tidak bisa dipakai siapa pun).":"Tunggu giliranmu. Tiap pemain ban "+VS_BANS_EACH+" skill bergantian.";
        }
        else if(m.ph==="pick"){
            info.textContent=m.pd[me]?"Skill kamu sudah terkunci.":"Pilih skill — kalau waktu habis, dipilihkan acak.";
        }
        else{
            info.textContent="";
        }

        /* reveal */

        const rv=$("vdReveal");

        if(m.ph==="reveal"&&m.picks){

            if(!rv.classList.contains("on")){
                rv.classList.add("on");
                $("vdRvMe").innerHTML=skillArt(m.picks[me])+"<div>"+SKILLS[m.picks[me]].icon+" "+SKILLS[m.picks[me]].name+"</div>";
                $("vdRvOp").innerHTML=skillArt(m.picks[op])+"<div>"+SKILLS[m.picks[op]].icon+" "+SKILLS[m.picks[op]].name+"</div>";
                snd("goldenImmune");
            }

            $("vdCount").textContent=Math.max(1,Math.ceil(m.left));

        }
        else{
            rv.classList.remove("on");
        }

    }

    $("vdOk").onclick=()=>{

        const m=vs.dv;

        if(!m||!vs.sel)return;

        const k=m.ph==="ban"?"ban":"pick";

        const s=vs.sel;

        vs.sel=null;

        if(vs.role==="host")vsAct("host",k,s);
        else{
            vsSend({t:"a",k:k,s:s});
            if(k==="pick"){
                vs.dv.pd[vs.role]=true;
            }
            vsRenderDraft();
        }

    };

    $("vdLeave").onclick=()=>{
        showMenu();
    };

    /* ---------- pertandingan ---------- */

    function vsSetHud(skill){

        $("sbIcon").textContent=SKILLS[skill].icon;
        $("sbLabel").textContent=abilityOf({skill:skill}).name;

    }

    function vsBeginMatch(){

        const d=vs.d;

        audio();

        hideScreens();

        $("vdReveal").classList.remove("on");

        setCls("ranked");

        if(!sandboxObjects)sandboxObjects=objects;

        objects=[];

        try{stopDuel()}catch(e){}

        resetTransient();

        const a=addCharacter(W*.2,H*.34,"blue",d.picks.host);
        const b=addCharacter(W*.8,H*.34,"red",d.picks.guest);

        startDuel();

        [a,b].forEach(p=>{
            p.manual=true;
            p.mcd=cdStartManual(p);
            p.mcdMax=p.mcd;
            p.mcd2=p.mcdMax2=(SKILLS[p.skill]&&SKILLS[p.skill].ghostSkill)?(SKILLS[p.skill].dimCooldownMax||20):2;
            p.manualCloneDone=false;
            p.boostT=0;
            p.goldenGo=false;
            p.gWasActive=false;
        });

        b.netRemote=true;
        b.remoteInput={x:0,y:0};

        vs.me=a;
        vs.opp=b;
        vs.picks=d.picks;
        vs.t=0;
        vs.bothDead=0;
        vs.bid=0;
        vs.fx=[];
        vs.snds=[];

        vsSetHud(a.skill);

        body.classList.add("manualOn");

        startHud();

        setSpec(false);

        vs.inDuel=true;

        $("rankBanner").textContent="⏱ "+MATCH_LIMIT+" • "+vsNameOf("host")+" vs "+vsNameOf("guest");

        vsSend({t:"go",picks:d.picks,names:vs.names});

        clearInterval(vs.snapIv);
        clearInterval(vs.timeIv);

        vs.snapIv=setInterval(vsSnap,33);

        vs.timeIv=setInterval(vsTimeTick,500);

    }

    function vsTimeTick(){

        if(!vs.inDuel||!duelMode)return;

        vs.t+=.5;

        const left=Math.max(0,Math.ceil(MATCH_LIMIT-vs.t));

        $("rankBanner").textContent="⏱ "+left+" • "+vsNameOf("host")+" vs "+vsNameOf("guest");

        const ch=objects.filter(o=>o.type==="character");

        const ha=vs.me.hp>0,ga=vs.opp.hp>0;

        if(!ha&&!ga){
            vs.bothDead++;
            if(vs.bothDead>=2)vsEnd("draw");
            return;
        }

        vs.bothDead=0;

        if(vs.t>=MATCH_LIMIT){

            const hr=Math.max(0,vs.me.hp)/vs.me.maxHp;
            const gr=Math.max(0,vs.opp.hp)/vs.opp.maxHp;

            if(Math.abs(hr-gr)<.001)vsEnd("draw");
            else vsEnd(hr>gr?"host":"guest");

        }

    }

    function r4(n){return Math.round(n*10000)/10000;}

    function vsSnap(){

        if(!vs.inDuel||vs.role!=="host")return;

        const ch=objects.filter(o=>o.type==="character").map(o=>({
            id:o.id,
            tm:o.team==="blue"?0:1,
            sk:o.skill,
            x:r4(o.x/W),y:r4(o.y/H),
            vx:r4(o.vx/W),vy:r4(o.vy/H),
            an:Math.round(o.angle*100)/100,
            hp:Math.round(o.hp*10)/10,mh:o.maxHp,
            sh:Math.round(o.shield*10)/10,
            st:Math.round(o.stunTimer*100)/100,
            im:Math.round(o.immuneTimer*100)/100,
            gi:Math.round(o.goldenImmune*100)/100,
            rc:Math.round(o.recoil*100)/100,
            ds:Math.round(o.deadSurvive*10)/10,
            dt:o.deadTriggered?1:0,
            sl:Math.round(o.sealTimer*10)/10,
            dz:Math.round(o.dazeTimer*100)/100,
            rt:Math.round(o.radT*100)/100,
            rm:o.radMax||3,
            gr:o.goldenRewind?1:0,
            lz:o.lsZone?[Math.round(o.lsZone.r),Math.round(o.lsZone.t*100)/100,o.lsZone.max||2.5]:0,
            sf:(o.samFx&&o.samFx.t>0)?[r4(o.samFx.x/W),r4(o.samFx.y/H),r4(o.samFx.tx/W),r4(o.samFx.ty/H),Math.round(o.samFx.t*100)/100]:0,
            sa:o.samAtk>0?1:0,
            pt:Math.round((o.possT||0)*10)/10,
            pb:o.possessedBy?o.possessedBy.id:-1,
            gn:o.ghostIn?1:0,
            dm:dimension?(o.dimId===1?1:0):-1,
            rl:(o.regenLink&&o.regenLink.hp>0)?o.regenLink.id:-1
        }));

        const bl=bullets.map(b=>{
            if(!b._i)b._i=++vs.bid;
            return[b._i,r4(b.x/W),r4(b.y/H),r4(b.vx/W),r4(b.vy/H),b.team==="blue"?0:1,(b.magnet?1:0)|(b.pierce?2:0),b.shooter&&b.shooter.skill?b.shooter.skill:"normal"];
        });

        const cl=clones.filter(c=>!c.dead).map(c=>[r4(c.x/W),r4(c.y/H),c.team==="blue"?0:1,Math.round(c.hp),c.maxHp,Math.round(c.angle*100)/100,c.generation||0,Math.round((c.recoil||0)*100)/100]);

        const bh=blackholes.map(h=>[r4(h.x/W),r4(h.y/H),h.pullMax,h.pullTime,h.exploded?1:0,Math.round((h.life||0)*100)/100,Math.round((h.spin||0)*100)/100,h.explodeRadius,h.pullRadius||280]);

        const ex=explosions.map(e=>[r4(e.x/W),r4(e.y/H),e.radius,Math.round(e.life*100)/100,e.max]);

        const bo=boosters.map(b=>[r4(b.x/W),r4(b.y/H),b.icon,Math.round((b.pulse||0)*100)/100]);

        const m={
            t:"s",
            W:W,H:H,
            c:ch,b:bl,k:cl,h:bh,e:ex,o:bo,
            tf:(timeFreeze&&timeFreeze.caster)?timeFreeze.caster.id:-1,
            tl:Math.max(0,Math.ceil(MATCH_LIMIT-vs.t)),
            fx:vs.fx.splice(0,40),
            sn:vs.snds.splice(0,8),
            cd:cdInfo(ctlBody(vs.opp)),
            cb:ctlBody(vs.opp).skill,
            cd2:(SKILLS[vs.opp.skill]&&SKILLS[vs.opp.skill].ghostSkill)?cdInfo2(vs.opp):null,
            sp:spirits.map(a=>[r4(a.x/W),r4(a.y/H)]),
            dn:dimension?[Math.round(dimension.t*10)/10,dimension.dur,dimension.g.id,dimension.e.id]:0
        };

        vsSendFast(m);

    }

    /* efek & suara host -> guest */

    const _bp2=window.burstParticles;

    window.burstParticles=function(x,y,amount,type){

        if(vs.role==="host"&&vs.inDuel&&vs.fx.length<60){
            vs.fx.push([r4(x/W),r4(y/H),amount===undefined?15:amount,type===undefined?"hit":type]);
        }

        return _bp2(x,y,amount,type);

    };

    const _sound2=window.sound;

    window.sound=function(t){

        if(vs.role==="host"&&vs.inDuel&&vs.snds.length<20)vs.snds.push(t);

        return _sound2.apply(this,arguments);

    };

    /* ---------- sisi guest: terima & gambar ---------- */

    function vsGuestGo(m){

        audio();

        hideScreens();

        $("vdReveal").classList.remove("on");

        setCls("ranked");

        if(!sandboxObjects)sandboxObjects=objects;

        objects=[];

        try{stopDuel()}catch(e){}

        resetTransient();

        if(m.names)Object.keys(m.names).forEach(k=>{if(m.names[k])vs.names[k]=m.names[k];});

        vs.picks=m.picks;
        vs.me=null;
        vs.cdRemote=null;

        netGuest=true;
        duelMode=true;
        winnerTimer=0;

        vsSetHud(m.picks.guest);

        body.classList.add("manualOn");

        startHud();

        vs.inDuel=true;

        $("rankBanner").textContent="⏱ "+MATCH_LIMIT+" • "+vsNameOf("host")+" vs "+vsNameOf("guest");

        clearInterval(vs.inIv);

        let last="",lastT=0;

        vs.inIv=setInterval(()=>{

            if(!vs.inDuel)return;

            const i=getInput();

            const s=Math.round(i.x*100)+","+Math.round(i.y*100);

            const now=performance.now();

            if(s!==last||now-lastT>400){
                last=s;
                lastT=now;
                vsSendFast({t:"in",x:Math.round(i.x*100)/100,y:Math.round(i.y*100)/100});
            }

        },50);

    }

    function vsApply(m){

        if(!vs.inDuel||!netGuest)return;

        const seen={};

        m.c.forEach(c=>{

            seen[c.id]=1;

            let o=objects.find(x=>x.id===c.id);

            if(!o){
                o=addCharacter(c.x*W,c.y*H,c.tm?"red":"blue",c.sk);
                o.id=c.id;
                o.manual=false;
                o.ai=null;
            }

            o.skill=c.sk;
            o.team=c.tm?"red":"blue";
            o.tx=c.x*W;
            o.ty=c.y*H;
            o.vx=c.vx*W;
            o.vy=c.vy*H;
            o.angle=c.an;
            o.hp=c.hp;
            o.maxHp=c.mh;
            o.shield=c.sh;
            o.stunTimer=c.st;
            o.immuneTimer=c.im;
            o.goldenImmune=c.gi;
            o.recoil=c.rc;
            o.deadSurvive=c.ds;
            o.deadTriggered=!!c.dt;
            o.sealTimer=c.sl;
            o.dazeTimer=c.dz;
            o.radT=c.rt;
            o.radMax=c.rm;
            o.goldenRewind=c.gr?{}:null;
            o.lsZone=c.lz?{r:c.lz[0],t:c.lz[1],max:c.lz[2]}:null;
            o.samFx=c.sf?{x:c.sf[0]*W,y:c.sf[1]*H,tx:c.sf[2]*W,ty:c.sf[3]*H,t:c.sf[4]}:null;
            o.samAtk=c.sa?1:0;
            o.dead=c.hp<=0;
            o.possT=c.pt;
            o.ghostIn=!!c.gn;
            o._pb=c.pb;
            o._rl=c.rl;
            o.dimId=c.dm<0?undefined:c.dm;

            if(o.team==="red")vs.me=o;

        });

        objects=objects.filter(o=>o.type!=="character"||seen[o.id]);

        objects.forEach(o=>{
            if(o.type!=="character")return;
            o.possessedBy=o._pb>=0?(objects.find(x=>x.id===o._pb)||null):null;
            o.regenLink=o._rl>=0?(objects.find(x=>x.id===o._rl)||null):null;
        });

        spirits=(m.sp||[]).map(a=>({x:a[0]*W,y:a[1]*H}));

        dimension=m.dn?{t:m.dn[0],dur:m.dn[1],g:objects.find(x=>x.id===m.dn[2])||{},e:objects.find(x=>x.id===m.dn[3])||{}}:null;

        /* peluru */

        const old={};

        bullets.forEach(b=>{if(b._i)old[b._i]=b;});

        bullets=m.b.map(a=>{

            const b=old[a[0]]||{tr:null,life:9,hit:false};

            b._i=a[0];
            b.x=a[1]*W;
            b.y=a[2]*H;
            b.vx=a[3]*W;
            b.vy=a[4]*H;
            b.team=a[5]?"red":"blue";
            b.magnet=!!(a[6]&1);
            b.pierce=!!(a[6]&2);
            b.shooter={skill:a[7]};
            b.life=9;

            return b;

        });

        clones=m.k.map(a=>({x:a[0]*W,y:a[1]*H,team:a[2]?"red":"blue",hp:a[3],maxHp:a[4],angle:a[5],generation:a[6],recoil:a[7],dead:false,id:-1}));

        blackholes=m.h.map(a=>({x:a[0]*W,y:a[1]*H,pullMax:a[2],pullTime:a[3],exploded:!!a[4],life:a[5],spin:a[6],explodeRadius:a[7],pullRadius:a[8]}));

        explosions=m.e.map(a=>({x:a[0]*W,y:a[1]*H,radius:a[2],life:a[3],max:a[4]}));

        boosters=m.o.map(a=>({x:a[0]*W,y:a[1]*H,icon:a[2],pulse:a[3],life:5,type:"x"}));

        timeFreeze=m.tf>=0?{caster:objects.find(o=>o.id===m.tf)||{x:W/2,y:H/2}}:null;

        m.fx.forEach(f=>{
            try{window.burstParticles(f[0]*W,f[1]*H,f[2],f[3]);}catch(e){}
        });

        m.sn.forEach(s=>{try{_sound2(s);}catch(e){}});

        vs.cdRemote=m.cd;
        vs.cdRemote2=m.cd2;
        vs.bodySkill=m.cb;

        $("rankBanner").textContent="⏱ "+m.tl+" • "+vsNameOf("host")+" vs "+vsNameOf("guest");

    }

    window.netExtrap=function(dt){

        const k=Math.min(1,dt*22);

        for(let i=0;i<objects.length;i++){

            const o=objects[i];

            if(o.type!=="character"||o.tx===undefined)continue;

            o.x+=(o.tx-o.x)*k;
            o.y+=(o.ty-o.y)*k;

        }

    };

    function vsGuestEnd(m){

        if(!vs.inDuel)return;

        vs.inDuel=false;

        netGuest=false;

        duelMode=false;

        clearInterval(vs.inIv);

        vsResult(m.w);

    }

    function vsEnd(w){

        if(!vs.inDuel)return;

        vs.inDuel=false;

        clearInterval(vs.snapIv);
        clearInterval(vs.timeIv);

        vsSend({t:"end",w:w});

        vsResult(w);

    }

    function vsResult(w){

        body.classList.remove("manualOn");

        setSpec(false);

        const me=vs.role;

        const op=me==="host"?"guest":"host";

        const b1=$("rrBtn1"),b2=$("rrBtn2");

        b2.style.display="";

        $("rrReward").textContent="";

        if(w==="draw"){
            $("rrIcon").textContent="🤝";
            $("rrTitle").textContent="SERI";
            $("rrText").textContent="Tidak ada pemenang. Hasil imbang!";
        }
        else if(w===me){
            $("rrIcon").textContent="🏆";
            $("rrTitle").textContent="MENANG!";
            $("rrText").textContent="Kamu mengalahkan "+vsNameOf(op)+" dengan skill "+SKILLS[vs.picks[me]].name+".";
        }
        else{
            $("rrIcon").textContent="💀";
            $("rrTitle").textContent="KALAH";
            $("rrText").textContent=vsNameOf(op)+" menang dengan skill "+SKILLS[vs.picks[op]].name+".";
        }

        b1.textContent="🔁 Main Lagi (Ban Ulang)";

        b1.onclick=()=>{

            vs.again[me]=true;

            b1.textContent="⏳ Menunggu teman...";

            if(me==="host"){
                if(vs.again.guest)vsStartDraft();
            }
            else vsSend({t:"again"});

        };

        b2.textContent="🏠 Menu";

        b2.onclick=showMenu;

        show("rankResult");

    }

    /* tombol & menu */

    $("vsMake").onclick=()=>{audio();vsMake();};

    $("vsJoin").onclick=()=>{audio();vsJoin();};

    $("vsBack").onclick=()=>{
        vsReset();
        renderModes();
        show("modes");
    };

    $("vsHScan").onclick=()=>{
        startScan("📷 SCAN QR BALASAN","Arahkan kamera ke QR balasan di HP teman.",vsHostApply);
    };

    $("vsSCancel").onclick=()=>{
        stopScan();
        if(vs.role==="host")vsPanel("vsHost");
        else{
            vsReset();
            vsPanel("vsHome");
        }
    };

    $("vsSApply").onclick=()=>{
        const c=$("vsSIn").value.trim();
        if(c.indexOf("TDS1|")!==0){
            $("vsSStat").textContent="Kode tidak valid.";
            return;
        }
        stopScan();
        if(vs.onCode)vs.onCode(c);
    };

    $("vsHApply").onclick=()=>{
        const c=$("vsHIn").value.trim();
        if(c.indexOf("TDS1|")!==0){
            $("vsHStat").textContent="Kode tidak valid.";
            return;
        }
        vsHostApply(c);
    };

    function copyText(id,btn){
        const el=$(id);
        el.select();
        try{navigator.clipboard.writeText(el.value);}catch(e){try{document.execCommand("copy");}catch(e2){}}
        const t=btn.textContent;
        btn.textContent="✅ Tersalin";
        setTimeout(()=>{btn.textContent=t;},1200);
    }

    $("vsHCopy").onclick=()=>copyText("vsHCode",$("vsHCopy"));

    $("vsGCopy").onclick=()=>copyText("vsGCode",$("vsGCopy"));

    function openVs(){

        audio();

        cleanup();

        vsPanel("vsHome");

        show("vsScr");

    }

    window.vsDebug=vs;


    /* ---------- GLOBAL v0.02: ARCADE (DUEL KARTU) ---------- */

    const ARC_MIN_SKILL=5;
    const ARC_MIN_LVL=15;
    const ARC_HP=200;
    const ARC_E_HP=220;
    const ARC_MANA=100;
    const ARC_REGEN=30;
    const ARC_FOCUS=30;
    const ARC_MOM=20;

    const ARC_COST={normal:20,burst:50,magnet:40,fireshot:35,nuclear:70,sniper:60,shotgun:45,samurai:50,hunter:45,dead:100,
        regen:40,lifesteal:45,clone:25,speed:40,hipo:55,
        time:45,goldentime:65,phase:25,hole:35,angel:30,ghost:20};

    function arcCost(k){
        return ARC_COST[k]!==undefined?ARC_COST[k]:40;
    }

    const ARC_TURN_CAP=24;

    const ARC_TYPE={atk:"⚔️ Attack",mag:"✨ Magic",def:"🛡️ Defense"};

    const ARC_CARDS={
        normal:{t:"atk",d:25,tx:"Tembakan biasa"},
        burst:{t:"atk",d:60,tx:"Ledakan keras"},
        magnet:{t:"atk",d:45,tx:"Tarikan magnet"},
        fireshot:{t:"atk",d:40,burn:10,tx:"+Bakar 10 di giliran lawan"},
        nuclear:{t:"atk",d:85,self:20,tx:"Dirimu -20 HP"},
        sniper:{t:"atk",d:70,pierce:1,tx:"Tembus Defense (kecuali Time)"},
        shotgun:{t:"atk",d:50,tx:"Hantaman jarak dekat"},
        samurai:{t:"atk",d:55,tx:"Tebasan kilat"},
        hunter:{t:"atk",d:50,tx:"Bidikan pemburu"},
        dead:{t:"atk",d:30,exec:60,tx:"Lawan HP ≤60: langsung KO"},
        regen:{t:"mag",heal:40,tx:"Pulihkan 40 HP"},
        lifesteal:{t:"mag",d:35,heal:1,tx:"Sedot 35 HP lawan"},
        clone:{t:"mag",dbl:1,tx:"Serangan berikutnya 2x"},
        speed:{t:"mag",extra:1,tx:"Main sekali lagi"},
        hipo:{t:"mag",stun:1,tx:"Lawan lewat 1 giliran"},
        time:{t:"def",neg:2,tx:"Hentikan waktu: serangan batal"},
        goldentime:{t:"def",neg:2,ctr:40,tx:"Waktu berhenti + balas 40"},
        phase:{t:"def",neg:1,tx:"Hindari serangan (tak berlaku vs tembus)"},
        hole:{t:"def",neg:1,ctr:25,tx:"Hindari + balas 25"},
        angel:{t:"def",cut:.7,heal:20,tx:"Damage -70% & +20 HP"},
        ghost:{t:"def",cut:.5,tx:"Damage -50%"}
    };

    function arcCard(k){
        return ARC_CARDS[k]||{t:"atk",d:40,tx:"Serangan"};
    }

    function arcUnlocked(){
        return !!profile&&profile.unlocked.length>=ARC_MIN_SKILL&&levelOf(profile.xp)>=ARC_MIN_LVL;
    }

    function arcFace(k,extraCls){
        const c=arcCard(k);
        const sk=SKILLS[k];
        const val=c.d?c.d+" dmg":(c.heal&&!c.d?"+"+c.heal:(c.neg?"Blok":(c.cut?"-"+Math.round(c.cut*100)+"%":"")));
        return '<div class="arcCard '+(extraCls||"")+'" data-k="'+k+'">'
            +'<em class="cost">🔷'+arcCost(k)+'</em>'
            +'<div class="ci">'+sk.icon+'</div><b>'+sk.name+'</b>'
            +'<span class="ct '+c.t+'">'+ARC_TYPE[c.t]+'</span>'
            +'<small>'+c.tx+'</small></div>';
    }

    let arcSel=[];
    let A=null;

    function openArcDeck(){

        audio();

        arcBgmStart();

        arcSel=arcSel.filter(k=>profile.unlocked.includes(k));

        renderArcDeck();

        show("arcDeck");

    }

    function renderArcDeck(){

        const tot=arcSel.reduce((a,k)=>a+arcCost(k),0);

        $("arcDeckSub").style.whiteSpace="pre-line";

        $("arcDeckSub").textContent="Pilih tepat 5 kartu ("+arcSel.length+"/5) • Total biaya 🔷"+tot+(arcSel.length?" (rata-rata "+Math.round(tot/arcSel.length)+")":"")
            +"\nMana maks 100, +30 tiap giliranmu. Attack/Magic dibayar saat dimainkan, Defense dibayar saat dipakai. Magic lalu Attack = Momentum +20 damage. Lewati giliran = Fokus +30 mana. HP lawan 220 dan ia menghitung mana.";

        $("arcPick").innerHTML=profile.unlocked.map(k=>arcFace(k,arcSel.includes(k)?"sel":"")).join("");

        $("arcPick").querySelectorAll(".arcCard").forEach(el=>{
            el.onclick=()=>{
                const k=el.dataset.k;
                const i=arcSel.indexOf(k);
                if(i>=0)arcSel.splice(i,1);
                else if(arcSel.length<5)arcSel.push(k);
                snd("boost");
                renderArcDeck();
            };
        });

        $("arcGo").style.opacity=arcSel.length===5?"":".45";

        renderArcPresets();

    }

    function renderArcPresets(){

        const P=profile.arcPresets;

        $("arcPresets").innerHTML=[0,1,2].map(i=>{
            const d=P[i];
            const ic=d?d.map(k=>SKILLS[k]?SKILLS[k].icon:"❔").join(""):"Kosong";
            return '<div class="arcSlot"><div class="asT">Preset '+(i+1)+'</div>'
                +'<div class="asI">'+ic+'</div>'
                +'<div class="asB"><button data-a="load" data-i="'+i+'"'+(d?"":" disabled")+'>📂 Muat</button>'
                +'<button data-a="save" data-i="'+i+'"'+(arcSel.length===5?"":" disabled")+'>💾 Simpan</button></div></div>';
        }).join("");

        $("arcPresets").querySelectorAll("button").forEach(b=>{
            b.onclick=()=>{
                const i=Number(b.dataset.i);
                if(b.dataset.a==="save"){
                    if(arcSel.length!==5)return;
                    profile.arcPresets[i]=arcSel.slice();
                    saveProfile();
                    snd("boost");
                    renderArcDeck();
                    $("arcDeckSub").textContent="✅ Tersimpan di Preset "+(i+1);
                }
                else{
                    const d=profile.arcPresets[i];
                    if(!d)return;
                    const own=d.filter(k=>profile.unlocked.includes(k)&&SKILLS[k]);
                    arcSel=own.slice();
                    snd("boost");
                    renderArcDeck();
                    $("arcDeckSub").textContent=own.length<5
                        ?"⚠️ "+(5-own.length)+" kartu preset tidak kamu miliki lagi — pilih penggantinya."
                        :"✅ Preset "+(i+1)+" dimuat.";
                }
            };
        });

    }

    $("arcGo").onclick=()=>{
        if(arcSel.length!==5)return;
        arcStart(arcSel.slice());
    };

    $("arcDeckBack").onclick=()=>{renderModes();show("modes");};

    const arcWait=ms=>new Promise(r=>setTimeout(r,ms));

    /* ---------- EFEK ARCADE (GLOBAL v0.05) ---------- */

    let arcFxList=[];
    let arcFxRaf=0;

    function arcCenter(side){
        const sc=$("arcScr").getBoundingClientRect();
        const r=$(side==="p"?"arcP":"arcE").getBoundingClientRect();
        const cx=r.left-sc.left+r.width/2;
        const cy=r.top-sc.top+r.height/2;
        const my=sc.height*.46;
        return{x:cx,y:cy+(my-cy)*.5};
    }

    function arcFxAdd(key,side){

        const m=ULT_META[key];

        if(!m||!A)return;

        const c=arcCenter(side);

        arcFxList.push({k:key,x:c.x,y:c.y,t:0,d:m.d,seed:Math.random()*1000,team:side});

        if(arcFxList.length>3)arcFxList.shift();

        arcFxKick();

    }

    function arcFxKick(){

        if(arcFxRaf)return;

        const cv=$("arcFx");
        const c=cv.getContext("2d");

        let last=performance.now();

        const loop=now=>{

            const dt=Math.min(.05,(now-last)/1000);

            last=now;

            const r=$("arcScr").getBoundingClientRect();
            const d=window.devicePixelRatio||1;
            const w=Math.max(1,Math.round(r.width*d));
            const h=Math.max(1,Math.round(r.height*d));

            if(cv.width!==w||cv.height!==h){cv.width=w;cv.height=h;}

            c.setTransform(d,0,0,d,0,0);
            c.clearRect(0,0,r.width,r.height);

            arcFxList.forEach(f=>{f.t+=dt;});
            arcFxList=arcFxList.filter(f=>f.t<f.d);

            UX=c;UW=r.width;UH=r.height;

            arcFxList.forEach(f=>{
                const m=ULT_META[f.k];
                const p=Math.min(1,f.t/f.d);
                const env=Math.sin(Math.PI*Math.min(1,p*1.05));
                c.save();
                c.globalAlpha=1;
                c.setLineDash([]);
                c.lineCap="round";
                try{ULT_DRAW[f.k](f,p,f.t,env,m.c);}catch(e){}
                c.restore();
                uTitle(f,m);
            });

            UX=ctx;UW=W;UH=H;

            if(arcFxList.length&&A&&$("arcScr").style.display==="flex")arcFxRaf=requestAnimationFrame(loop);
            else{
                arcFxRaf=0;
                c.clearRect(0,0,r.width,r.height);
            }

        };

        arcFxRaf=requestAnimationFrame(loop);

    }

    /* ---------- SUARA & BACKSOUND ARCADE (GLOBAL v0.06) ---------- */

    let arcMuted=false;

    try{arcMuted=localStorage.getItem("tds_arc_mute")==="1";}catch(e){}

    let arcNoiseBuf=null;

    function arcTone(f0,t0,dur,type,vol,f1,dest){

        const ac=audioCtx;

        if(!ac)return;

        const o=ac.createOscillator();
        const g=ac.createGain();

        o.type=type||"sine";
        o.frequency.setValueAtTime(f0,t0);

        if(f1)o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t0+dur);

        g.gain.setValueAtTime(.0001,t0);
        g.gain.exponentialRampToValueAtTime(vol,t0+.012);
        g.gain.exponentialRampToValueAtTime(.0001,t0+dur);

        o.connect(g);
        g.connect(dest||ac.destination);
        o.start(t0);
        o.stop(t0+dur+.05);

    }

    function arcNoise(t0,dur,vol,ftype,fa,fb,dest){

        const ac=audioCtx;

        if(!ac)return;

        if(!arcNoiseBuf){
            arcNoiseBuf=ac.createBuffer(1,ac.sampleRate,ac.sampleRate);
            const d=arcNoiseBuf.getChannelData(0);
            for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
        }

        const sr=ac.createBufferSource();
        sr.buffer=arcNoiseBuf;
        sr.loop=true;

        const f=ac.createBiquadFilter();
        f.type=ftype||"bandpass";
        f.frequency.setValueAtTime(fa,t0);
        if(fb&&fb!==fa)f.frequency.exponentialRampToValueAtTime(fb,t0+dur);

        const g=ac.createGain();
        g.gain.setValueAtTime(.0001,t0);
        g.gain.exponentialRampToValueAtTime(vol,t0+.01);
        g.gain.exponentialRampToValueAtTime(.0001,t0+dur);

        sr.connect(f);
        f.connect(g);
        g.connect(dest||ac.destination);
        sr.start(t0);
        sr.stop(t0+dur+.05);

    }

    function arcSfx(kind){

        if(arcMuted)return;

        try{initAudio();}catch(e){}

        const ac=audioCtx;

        if(!ac)return;

        const t=ac.currentTime+.01;

        try{

            switch(kind){

                case "whoosh":arcNoise(t,.45,.35,"bandpass",300,3200);break;

                case "slam":arcTone(160,t,.35,"sawtooth",.3,40);arcNoise(t,.2,.3,"lowpass",900,120);break;

                case "impact":arcTone(130,t,.4,"sine",.7,35);arcNoise(t,.25,.45,"lowpass",2500,200);break;

                case "boom":arcTone(90,t,.9,"sine",.9,28);arcNoise(t,.8,.6,"lowpass",1800,80);arcTone(55,t+.05,.8,"sawtooth",.25,30);break;

                case "shield":arcTone(880,t,.5,"square",.16,440);arcTone(1320,t+.03,.4,"triangle",.2,660);arcNoise(t,.15,.25,"highpass",3000,1500);break;

                case "shatter":
                    arcNoise(t,.6,.5,"highpass",5000,1800);
                    [0,.04,.09,.15,.23].forEach((d,i)=>arcTone(2400-i*260+Math.random()*200,t+d,.25,"triangle",.16));
                    arcTone(110,t,.3,"sine",.5,40);
                    break;

                case "shimmer":[523,659,784,1047,1319].forEach((f,i)=>arcTone(f,t+i*.06,.5,"sine",.17));break;

                case "heal":[392,494,587,784].forEach((f,i)=>arcTone(f,t+i*.08,.45,"triangle",.2));break;

                case "freeze":
                    arcTone(1800,t,1.2,"sine",.14,200);
                    for(let i=0;i<6;i++)arcTone(1000,t+i*.18,.05,"square",.12);
                    break;

                case "ko":arcTone(440,t,1.1,"sawtooth",.28,55);arcNoise(t,1,.5,"lowpass",2000,100);arcTone(70,t,1.2,"sine",.8,25);break;

                case "reset":arcTone(220,t,.7,"sawtooth",.16,880);arcNoise(t,.6,.25,"bandpass",400,4000);break;

                case "win":[523,659,784,1047].forEach((f,i)=>arcTone(f,t+i*.12,.5,"triangle",.25));break;

                case "lose":[392,330,262,196].forEach((f,i)=>arcTone(f,t+i*.18,.55,"sawtooth",.18));break;

            }

        }catch(e){}

    }

    function arcCardSfx(key){

        const c=arcCard(key);

        arcSfx("slam");

        if(key==="time"||key==="goldentime")arcSfx("freeze");
        else if(c.t==="def")arcSfx("shield");
        else if(key==="regen"||key==="angel")arcSfx("heal");
        else if(c.t==="mag")arcSfx("shimmer");
        else arcSfx("whoosh");

    }

    function arcSpeak(text){

        if(arcMuted)return;

        try{

            const ss=window.speechSynthesis;

            if(!ss)return;

            ss.cancel();

            const u=new SpeechSynthesisUtterance(text);

            u.lang="id-ID";

            const v=(ss.getVoices()||[]).find(x=>/^id/i.test(x.lang));

            if(v)u.voice=v;

            u.rate=.95;
            u.pitch=.6;
            u.volume=1;

            ss.speak(u);

        }catch(e){}

    }

    let arcBgm=null;

    function arcBgmStart(){

        if(arcMuted||arcBgm)return;

        try{initAudio();}catch(e){}

        const ac=audioCtx;

        if(!ac)return;

        const master=ac.createGain();

        master.gain.setValueAtTime(.0001,ac.currentTime);
        master.gain.exponentialRampToValueAtTime(.16,ac.currentTime+1.4);
        master.connect(ac.destination);

        const step=60/124/4;

        let next=ac.currentTime+.1;
        let n=0;

        const prog=[55,43.65,65.41,49];

        const chords=[[220,261.6,329.6],[174.6,220,261.6],[261.6,329.6,392],[196,246.9,293.7]];

        const sched=()=>{

            if(!arcBgm)return;

            while(next<ac.currentTime+.35){

                const bar=Math.floor(n/16)%4;
                const st=n%16;
                const cn=chords[bar];

                if(st%4===0)arcTone(120,next,.18,"sine",.5,40,master);

                if(st%2===1)arcNoise(next,.04,.07,"highpass",7000,7000,master);

                if(arcBgm.hot&&st%4===2)arcNoise(next,.05,.1,"highpass",6000,6000,master);

                if(st===4||st===12){
                    arcNoise(next,.14,.2,"bandpass",1800,900,master);
                    arcTone(200,next,.1,"triangle",.14,120,master);
                }

                if(st%2===0)arcTone(prog[bar],next,step*1.8,"sawtooth",.2,0,master);

                arcTone(cn[st%3]*(st%8>=4?2:1),next,step*1.5,"square",.045,0,master);

                if(st===0)cn.forEach(f=>arcTone(f/2,next,step*15,"triangle",.06,0,master));

                next+=step;
                n++;

            }

        };

        arcBgm={master,id:setInterval(sched,120),hot:false};

        sched();

    }

    function arcBgmStop(){

        if(!arcBgm)return;

        const b=arcBgm;

        arcBgm=null;

        clearInterval(b.id);

        try{
            b.master.gain.setTargetAtTime(.0001,audioCtx.currentTime,.25);
            setTimeout(()=>{try{b.master.disconnect();}catch(e){}},1200);
        }catch(e){}

        try{window.speechSynthesis&&window.speechSynthesis.cancel();}catch(e){}

    }

    function arcBgmDuck(on){

        if(!arcBgm)return;

        try{arcBgm.master.gain.setTargetAtTime(on?.05:.16,audioCtx.currentTime,.3);}catch(e){}

    }

    function arcMuteRender(){
        $("arcMute").textContent=arcMuted?"🔇":"🔊";
    }

    $("arcMute").onclick=()=>{

        arcMuted=!arcMuted;

        try{localStorage.setItem("tds_arc_mute",arcMuted?"1":"0");}catch(e){}

        arcMuteRender();

        if(arcMuted)arcBgmStop();
        else arcBgmStart();

    };

    arcMuteRender();

    document.addEventListener("visibilitychange",()=>{

        try{
            if(!audioCtx)return;
            if(document.hidden)audioCtx.suspend();
            else audioCtx.resume();
        }catch(e){}

    });

    /* ---------- KARTU: TERBANG, CALLOUT, HANCUR ---------- */

    const ARC_CALL={
        normal:"Tembakan Presisi",
        burst:"Ledakan Dahsyat",
        magnet:"Tarikan Magnet",
        fireshot:"Badai Api",
        nuclear:"Radiasi Nuklir",
        sniper:"Tembakan Tembus",
        shotgun:"Hantaman Brutal",
        samurai:"Tebasan Kilat",
        hunter:"Hujan Peluru",
        dead:"Sentuhan Kematian",
        regen:"Pemulihan Hidup",
        lifesteal:"Sedot Nyawa",
        clone:"Serangan Ganda",
        speed:"Kecepatan Cahaya",
        hipo:"Kunci Hipnosis",
        time:"Waktu Berhenti",
        goldentime:"Takdir Emas",
        phase:"Lenyap Dimensi",
        hole:"Lubang Hitam",
        angel:"Cahaya Malaikat",
        ghost:"Alam Hantu"
    };

    const ARC_HEAVY=new Set(["hole","time","goldentime","nuclear","dead","ghost","burst","sniper","samurai","angel"]);

    function arcCallout(side,key){

        const c=arcCard(key);

        const sk=SKILLS[key];

        const name=ARC_CALL[key]||sk.name;

        const el=document.createElement("div");

        el.className="arcCall "+c.t;

        el.innerHTML='<b>'+name+'!</b><small>'+sk.icon+' '+sk.name+' • '+ARC_TYPE[c.t]+'</small>';

        $("arcScr").appendChild(el);

        setTimeout(()=>el.remove(),1550);

        arcSpeak(name);

    }

    function arcBarsShow(){

        const el=document.createElement("div");

        el.className="arcBars";

        el.innerHTML="<i></i><i></i>";

        $("arcScr").appendChild(el);

        setTimeout(()=>el.remove(),1700);

    }

    function arcFly(side,key,dx,hold){

        const sc=$("arcScr");

        const src=arcCenter(side);

        const el=document.createElement("div");

        el.className="arcFly";

        el.innerHTML=arcFace(key,"");

        sc.appendChild(el);

        el.style.left=src.x+"px";
        el.style.top=src.y+"px";
        el.style.opacity="0";
        el.style.transform="translate(-50%,-50%) scale(.45) rotate("+(side==="p"?-12:12)+"deg)";

        requestAnimationFrame(()=>requestAnimationFrame(()=>{
            el.style.left=(sc.clientWidth/2+dx)+"px";
            el.style.top=(sc.clientHeight*.44)+"px";
            el.style.opacity="1";
            el.style.transform="translate(-50%,-50%) scale(1.45) rotate(0deg)";
        }));

        if(!hold){
            setTimeout(()=>arcFlyEnd(el,"fade"),1300);
        }

        return el;

    }

    function arcFlyEnd(el,mode){

        if(!el||!el.parentNode)return;

        if(mode==="shatter"){
            arcShatter(el);
            return;
        }

        el.style.opacity="0";
        el.style.transform+=" translateY(-18px)";

        setTimeout(()=>el.remove(),500);

    }

    function arcShatter(el){

        const sc=$("arcScr").getBoundingClientRect();

        const r=el.getBoundingClientRect();

        const inner=el.querySelector(".arcCard");

        const t=inner?(arcCard(inner.dataset.k).t):"atk";

        const col=t==="mag"?"#9b6bff":t==="def"?"#2d9cff":"#ff5a5a";

        const clips=["polygon(0 0,100% 25%,35% 100%)","polygon(20% 0,100% 60%,0 100%)","polygon(0 30%,80% 0,100% 100%)","polygon(50% 0,100% 100%,0 80%)"];

        el.remove();

        const nShard=window.POTATO?8:24;

        for(let i=0;i<nShard;i++){

            const sh=document.createElement("div");

            sh.className="arcShard";

            const sz=14+Math.random()*28;

            sh.style.cssText="left:"+(r.left-sc.left+Math.random()*r.width)+"px;top:"+(r.top-sc.top+Math.random()*r.height)+"px;width:"+sz+"px;height:"+sz+"px;background:linear-gradient(135deg,#fff,"+col+");clip-path:"+clips[i%4];

            $("arcScr").appendChild(sh);

            const dx=(Math.random()-.5)*360;
            const dy=-70+Math.random()*280;
            const rot=(Math.random()-.5)*760;

            const an=sh.animate(
                [
                    {transform:"translate(0,0) rotate(0deg)",opacity:1},
                    {transform:"translate("+dx+"px,"+dy+"px) rotate("+rot+"deg)",opacity:0}
                ],
                {duration:900+Math.random()*500,easing:"cubic-bezier(.2,.6,.4,1)"}
            );

            an.onfinish=()=>sh.remove();

        }

    }

    function arcDmgNum(side,txt,cls){

        const c=arcCenter(side);

        const el=document.createElement("div");

        el.className="arcDmg "+(cls||"");

        el.textContent=txt;

        el.style.left=c.x+"px";
        el.style.top=c.y+"px";

        $("arcScr").appendChild(el);

        setTimeout(()=>el.remove(),1200);

    }

    function arcShake(power){

        const sc=$("arcScr");

        sc.classList.remove("sk1","sk2","sk3");

        void sc.offsetWidth;

        sc.classList.add(power>=60?"sk3":power>=35?"sk2":"sk1");

        setTimeout(()=>sc.classList.remove("sk1","sk2","sk3"),520);

    }

    function arcEnemyDeck(){

        const all=Object.keys(ARC_CARDS).filter(k=>SKILLS[k]);

        const pool=t=>all.filter(k=>ARC_CARDS[k].t===t);

        const pick=a=>a[Math.floor(Math.random()*a.length)];

        const deck=[pick(pool("def"))];

        {
            let k;
            do{k=pick(pool("def"));}while(deck.includes(k));
            deck.push(k);
        }

        while(deck.length<4){
            const k=pick(pool("atk"));
            if(!deck.includes(k)&&k!=="dead")deck.push(k);
        }

        {
            const mg=["regen","clone","speed","lifesteal","hipo"].filter(k=>all.includes(k)&&!deck.includes(k));
            deck.push(pick(mg.length?mg:all.filter(k=>!deck.includes(k))));
        }

        return deck;

    }

    function arcSideObj(deck,max){
        return{hp:max,max:max,deck:deck.slice(),hand:deck.slice(),burn:0,stun:false,dbl:false,mana:ARC_MANA,mom:false};
    }

    function arcStart(deck){

        audio();

        A={p:arcSideObj(deck,ARC_HP),e:arcSideObj(arcEnemyDeck(),ARC_E_HP),turn:0,over:false,res:null,gen:Math.random(),resets:0};

        arcBgmStart();

        arcBgmDuck(false);

        try{window.speechSynthesis&&window.speechSynthesis.cancel();}catch(e){}

        $("arcScr").classList.remove("danger");

        arcFxList=[];

        $("arcE").innerHTML="";
        $("arcP").innerHTML="";

        delete $("arcE").dataset.built;
        delete $("arcP").dataset.built;

        document.querySelectorAll(".arcFly,.arcDmg,.arcKO,.arcCall,.arcBars,.arcShard").forEach(e=>e.remove());

        $("arcEnd").classList.remove("on");

        $("arcFreeze").classList.remove("on");

        $("arcAsk").classList.remove("on");

        $("arcLog").textContent="";

        show("arcScr");

        arcRender();

        arcBanner("🃏 Duel dimulai! Mana 🔷 penuh. Hitung biaya tiap kartu. Kamu jalan duluan.");

        arcLoop(A);

    }

    function arcBanner(t){$("arcBanner").textContent=t;}

    function arcLog(t){
        const el=$("arcLog");
        el.innerHTML=(t+"<br>"+el.innerHTML).split("<br>").slice(0,3).join("<br>");
    }

    function arcChips(o){
        return(o.burn?'<span class="arcChip">🔥 Bakar</span>':"")
            +(o.stun?'<span class="arcChip">😵 Terkunci</span>':"")
            +(o.dbl?'<span class="arcChip">✖️2 Siap</span>':"")
            +(o.mom?'<span class="arcChip">⚡ Momentum +20</span>':"");
    }

    function arcPanel(id,label,o,me){

        const el=$(id);

        if(!el.dataset.built){
            el.dataset.built="1";
            el.innerHTML='<b>'+label+'</b> • ❤️ <span class="hpn"></span> / '+(o.max||ARC_HP)+' • 🔷 <span class="mpn"></span>'
                +'<div class="arcHpBar"><i class="tr"></i><i class="hp"></i></div>'
                +'<div class="arcMpBar"><i class="mp"></i></div>'
                +'<div class="arcInfo"></div>';
        }

        const pct=Math.max(0,o.hp/(o.max||ARC_HP)*100)+"%";

        el.querySelector(".mpn").textContent=Math.round(o.mana);
        el.querySelector(".mp").style.width=Math.max(0,Math.min(100,o.mana))+"%";

        el.querySelector(".hpn").textContent=Math.max(0,Math.round(o.hp));
        el.querySelector(".hp").style.width=pct;
        el.querySelector(".tr").style.width=pct;

        return el.querySelector(".arcInfo");

    }

    function arcRender(){

        if(!A)return;

        $("arcE").className="arcSide";
        $("arcP").className="arcSide me";

        arcPanel("arcE","🤖 Lawan",A.e,false).innerHTML='🃏 Kartu: '+A.e.hand.length+' '+arcChips(A.e);

        arcPanel("arcP","🧑 Kamu",A.p,true).innerHTML='Giliran '+Math.min(A.turn,ARC_TURN_CAP)+' / '+ARC_TURN_CAP+' '+arcChips(A.p);

        arcHand(null);

        $("arcScr").classList.toggle("danger",A.p.hp<=60&&!A.over);

        if(arcBgm)arcBgm.hot=Math.min(A.p.hp,A.e.hp)<=70;

    }

    /* mode: null = tampil saja, "play" = pilih kartu giliran, "def" = pilih defense */
    function arcHand(mode,onPick){

        const hand=A.p.hand;

        $("arcHand").innerHTML=hand.map((k,i)=>{
            const t=arcCard(k).t;
            const aff=arcCost(k)<=A.p.mana;
            const ok=mode==="play"?(t!=="def"&&aff):mode==="def"?(t==="def"&&aff):false;
            return arcFace(k,ok?"":"off").replace('data-k','data-i="'+i+'" data-k');
        }).join("");

        if(mode==="play"){
            $("arcHand").querySelectorAll(".arcCard:not(.off)").forEach(el=>{
                el.onclick=()=>onPick(Number(el.dataset.i));
            });
        }

    }

    function arcPlayerPick(me){

        return new Promise(res=>{

            const playable=me.hand.some(k=>arcCard(k).t!=="def"&&arcCost(k)<=me.mana);

            arcBanner("🟢 Giliranmu! 🔷 "+me.mana+" mana. Pilih kartu Attack/Magic"+(me.mom?" (Momentum +20 aktif!)":"")+".");

            arcHand("play",i=>{
                $("arcPass").classList.remove("on");
                res(i);
            });

            const pb=$("arcPass");

            pb.textContent="🧘 Fokus: lewati giliran, +"+ARC_FOCUS+" mana";
            pb.classList.add("on");
            pb.onclick=()=>{pb.classList.remove("on");res(-1);};

            if(!playable)arcBanner("Tidak ada kartu serang yang mampu dibayar — ambil Fokus (+"+ARC_FOCUS+" mana).");

        });

    }

    function arcEnemyPick(me,foe){

        const idx=me.hand.map((k,i)=>i).filter(i=>arcCard(me.hand[i]).t!=="def"&&arcCost(me.hand[i])<=me.mana);

        if(!idx.length)return-1;

        const dmgOf=i=>{
            const c=arcCard(me.hand[i]);
            let d=c.d||0;
            if(c.t==="atk"&&d){
                if(me.mom)d+=ARC_MOM;
                if(me.dbl)d*=2;
            }
            if(c.exec&&foe.hp<=c.exec)d=foe.hp;
            return d;
        };

        const defs=me.hand.filter(k=>arcCard(k).t==="def").map(arcCost);
        const defCost=defs.length?Math.min.apply(null,defs):0;
        const foeCanDef=foe.mana>=20;
        const foeStrong=foe.mana>=45;

        const kills=idx.filter(i=>dmgOf(i)>=foe.hp);

        if(kills.length){
            const pier=kills.find(i=>arcCard(me.hand[i]).pierce);
            if(pier!==undefined)return pier;
            if(!foeCanDef)return kills[0];
        }

        const atkAfter=(i)=>me.hand.some((k,j)=>j!==i&&arcCard(k).t==="atk"&&arcCost(k)<=me.mana-arcCost(me.hand[i]));

        let best=-1,bs=-1e9;

        idx.forEach(i=>{

            const k=me.hand[i],c=arcCard(k),cost=arcCost(k),d=dmgOf(i);
            let sc=0;

            if(c.t==="atk"){
                sc=d-cost*.35;
                if(!foeCanDef)sc+=d*.5;
                else if(foeStrong)sc-=d*.2;
                if(c.pierce&&foeCanDef)sc+=18;
                if(c.exec)sc=(foe.hp<=c.exec)?999:-40;
                if(c.self){sc-=c.self;if(me.hp<=c.self+15)sc=-999;}
                if(c.burn)sc+=8;
            }
            else{
                if(c.heal&&!c.d){
                    const need=me.max-me.hp;
                    sc=Math.min(c.heal,need)*(me.hp<me.max*.5?1.6:1.0)-cost*.3-(need<25?30:0);
                }
                else if(c.d&&c.heal){sc=d*.9+Math.min(d,me.max-me.hp)*.6-cost*.3;}
                else if(c.dbl){sc=atkAfter(i)&&me.hand.some(kk=>(arcCard(kk).d||0)>=50)?42:-25;}
                else if(c.extra){sc=atkAfter(i)?30:-15;}
                else if(c.stun){sc=48-cost*.2;}
                if(me.hand.some(kk=>arcCard(kk).t==="atk"))sc+=8;
            }

            if(defs.length&&me.mana-cost<defCost&&foe.hp>40)sc-=16;

            sc+=Math.random()*5;

            if(sc>bs){bs=sc;best=i;}

        });

        if(bs<-10)return-1;

        return best;

    }

    function arcDefAsk(card,dmg){

        return new Promise(res=>{

            const defs=A.p.hand.map((k,i)=>i).filter(i=>arcCard(A.p.hand[i]).t==="def"&&arcCost(A.p.hand[i])<=A.p.mana);

            if(!defs.length){
                if(A.p.hand.some(k=>arcCard(k).t==="def"))arcLog("🔷 Mana kurang untuk bertahan!");
                res(-1);
                return;
            }

            const ask=$("arcAsk");

            ask.innerHTML='<div class="q">⚠️ Lawan menyerang! '+(dmg?dmg+" damage":"efek")+' — pakai Defense? (🔷 '+A.p.mana+')</div>';

            ask.classList.add("on");

            arcHand("def");

            $("arcHand").querySelectorAll(".arcCard:not(.off)").forEach(el=>{
                el.onclick=()=>{ask.classList.remove("on");res(Number(el.dataset.i));};
            });

            const b=document.createElement("button");

            b.textContent="Terima serangan";

            b.onclick=()=>{ask.classList.remove("on");res(-1);};

            ask.appendChild(b);

        });

    }

    function arcEnemyDef(me,dmg,card){

        const defs=me.hand.map((k,i)=>i).filter(i=>arcCard(me.hand[i]).t==="def"&&arcCost(me.hand[i])<=me.mana);

        if(!defs.length||dmg<=0)return-1;

        const val=i=>{
            const d=arcCard(me.hand[i]);
            let saved=0;
            if(d.neg===2)saved=dmg;
            else if(d.neg===1&&!card.pierce)saved=dmg;
            if(d.cut)saved=Math.max(saved,dmg*d.cut);
            saved+=(d.heal||0)*.8+(saved>=dmg&&d.ctr?d.ctr*.8:0);
            return saved-arcCost(me.hand[i])*.45;
        };

        const lethal=dmg>=me.hp;

        let best=-1,bv=-1e9;

        defs.forEach(i=>{const v=val(i);if(v>bv){bv=v;best=i;}});

        if(lethal)return best;

        const worth=dmg>=35&&bv>=dmg*.35;

        return worth?best:-1;

    }

    const arcOffense=o=>o.hand.some(k=>arcCard(k).t!=="def");

    async function arcMaybeReset(g){

        if(arcOffense(g.p)||arcOffense(g.e))return;

        g.p.hand=g.p.deck.slice();
        g.e.hand=g.e.deck.slice();

        g.resets=(g.resets||0)+1;

        arcBanner("🔄 KARTU DIRESET DARI AWAL!");

        arcSfx("reset");

        arcLog("🔄 Kedua pihak kehabisan kartu serang — semua kartu kembali");

        arcRender();

        const hd=$("arcHand");

        hd.classList.remove("deal");
        void hd.offsetWidth;
        hd.classList.add("deal");

        const f=document.createElement("div");
        f.className="arcKO reset";
        f.textContent="🔄 RESET";
        $("arcScr").appendChild(f);
        setTimeout(()=>f.remove(),1500);

        arcFxAdd("magnet","p");

        await arcWait(1500);

    }

    async function arcLoop(g){

        let side="p";

        const alive=()=>A===g&&!g.over;

        while(alive()){

            g.turn++;

            if(g.turn>ARC_TURN_CAP){
                arcFinish(g.p.hp>g.e.hp?"win":g.p.hp<g.e.hp?"lose":"draw",true);
                return;
            }

            await arcMaybeReset(g);

            if(!alive())return;

            const me=g[side];
            const foe=g[side==="p"?"e":"p"];
            const who=side==="p"?"Kamu":"Lawan";

            me.mana=Math.min(ARC_MANA,me.mana+ARC_REGEN);

            if(me.burn){
                me.hp-=me.burn;
                arcLog("🔥 "+who+" terbakar -"+me.burn);
                arcDmgNum(side,"-"+me.burn,"hit");
                me.burn=0;
                arcRender();
                if(me.hp<=0){arcFinish(side==="p"?"lose":"win");return;}
                await arcWait(700);
                if(!alive())return;
            }

            if(me.stun){
                me.stun=false;
                arcBanner("😵 "+who+" terkunci, giliran dilewati!");
                arcRender();
                await arcWait(1100);
                side=side==="p"?"e":"p";
                continue;
            }

            arcRender();

            let again=true;

            while(again&&alive()){

                again=false;

                let idx;

                if(side==="p"){
                    idx=await arcPlayerPick(me);
                }
                else{
                    arcBanner("🔴 Giliran lawan...");
                    await arcWait(900);
                    if(!alive())return;
                    idx=arcEnemyPick(me,foe);
                }

                if(!alive())return;

                if(idx<0){
                    me.mana=Math.min(ARC_MANA,me.mana+ARC_FOCUS);
                    me.mom=false;
                    arcLog("🧘 "+who+" Fokus: +"+ARC_FOCUS+" mana");
                    arcRender();
                    await arcWait(600);
                    break;
                }

                again=await arcPlay(g,side,idx);

                if(!alive())return;

                await arcWait(500);

            }

            side=side==="p"?"e":"p";

        }

    }

    async function arcPlay(g,side,idx){

        const me=g[side];
        const foe=g[side==="p"?"e":"p"];
        const key=me.hand.splice(idx,1)[0];
        me.mana=Math.max(0,me.mana-arcCost(key));
        const c=arcCard(key);
        const sk=SKILLS[key];
        const who=side==="p"?"Kamu":"Lawan";
        const foeSide=side==="p"?"e":"p";

        arcBanner(who+" memakai "+sk.icon+" "+sk.name+"!");

        arcRender();

        const atkEl=arcFly(side,key,side==="p"?-62:62,true);

        arcCallout(side,key);

        arcCardSfx(key);

        if(ARC_HEAVY.has(key))arcBarsShow();

        await arcWait(950);

        if(A!==g)return false;

        let dmg=c.d||0;

        if(c.t==="atk"&&dmg&&me.mom){
            dmg+=ARC_MOM;
            arcLog("⚡ Momentum +"+ARC_MOM+" damage!");
        }

        if(c.t==="atk"&&me.dbl&&dmg){
            dmg*=2;
            me.dbl=false;
            arcLog("✖️2 Kloning aktif!");
        }

        if(c.exec&&foe.hp<=c.exec)dmg=foe.hp;

        let final=dmg;
        let negated=false;
        let counter=0;

        if(dmg>0){

            let di;

            if(foeSide==="p")di=await arcDefAsk(c,dmg);
            else di=arcEnemyDef(foe,dmg,c);

            if(A!==g)return false;

            if(di>=0){

                const dk=foe.hand.splice(di,1)[0];
                foe.mana=Math.max(0,foe.mana-arcCost(dk));
                const dc=arcCard(dk);
                const dsk=SKILLS[dk];

                arcBanner((foeSide==="p"?"Kamu":"Lawan")+" bertahan dengan "+dsk.icon+" "+dsk.name+"!");

                arcFly(foeSide,dk,foeSide==="p"?-62:62);

                arcCallout(foeSide,dk);

                arcCardSfx(dk);

                if(ARC_HEAVY.has(dk))arcBarsShow();

                await arcWait(750);

                if(A!==g)return false;

                if(dc.neg===2){

                    final=0;
                    negated=true;

                    $("arcFreeze").classList.add("on");
                    setTimeout(()=>$("arcFreeze").classList.remove("on"),1500);

                }
                else if(dc.neg===1&&!c.pierce){
                    final=0;
                    negated=true;
                }
                else if(dc.neg===1&&c.pierce){
                    arcLog("Serangan menembus pertahanan!");
                }

                if(dc.cut)final=Math.round(final*(1-dc.cut));

                if(dc.heal){
                    foe.hp=Math.min(foe.max,foe.hp+dc.heal);
                    arcDmgNum(foeSide,"+"+dc.heal,"heal");
                }

                if(dc.ctr&&negated)counter=dc.ctr;

                arcFxAdd(dk,foeSide);

                arcRender();

                await arcWait(1100);

                if(A!==g)return false;

            }

        }

        if(final>0){

            arcFlyEnd(atkEl,"fade");

            arcFxAdd(key,foeSide);

            await arcWait(800);

            if(A!==g)return false;

            foe.hp-=final;

            arcLog((side==="p"?"🧑":"🤖")+" "+sk.name+" → "+final+" damage");

            arcDmgNum(foeSide,"-"+final,"hit");

            arcShake(final);

            arcSfx(final>=60?"boom":"impact");

            $("arcMid").classList.remove("pop");
            void $("arcMid").offsetWidth;
            $("arcMid").classList.add("pop");

            $(foeSide==="p"?"arcP":"arcE").classList.add("hit");

            setTimeout(()=>{try{$("arcP").classList.remove("hit");$("arcE").classList.remove("hit")}catch(e){}},450);

            snd("hit");

        }
        else if(dmg>0){

            /* serangan tertahan: kartunya HANCUR */

            arcFlyEnd(atkEl,"shatter");

            arcSfx("shatter");

            arcFxAdd("shatter",foeSide);

            arcShake(45);

            arcLog("🛡️ Serangan "+sk.name+" hancur!");

            arcDmgNum(foeSide,"HANCUR!","block");

            await arcWait(800);

            if(A!==g)return false;

        }
        else{

            arcFlyEnd(atkEl,"fade");

            arcFxAdd(key,c.stun?foeSide:side);

            await arcWait(900);

            if(A!==g)return false;

        }

        if(c.heal&&c.d){
            if(final>0){
                me.hp=Math.min(me.max,me.hp+final);
                arcDmgNum(side,"+"+final,"heal");
                arcSfx("heal");
            }
        }
        else if(c.heal){
            me.hp=Math.min(me.max,me.hp+c.heal);
            arcLog("💚 "+who+" pulih "+c.heal+" HP");
            arcDmgNum(side,"+"+c.heal,"heal");
        }

        if(c.self){
            me.hp-=c.self;
            arcLog("☢️ "+who+" terkena efek -"+c.self);
            arcDmgNum(side,"-"+c.self,"hit");
        }

        if(c.burn&&!negated&&final>0)foe.burn=c.burn;

        if(c.dbl){
            me.dbl=true;
            arcLog("✖️2 Serangan berikutnya "+who.toLowerCase()+" dobel!");
        }

        if(c.stun){
            foe.stun=true;
            arcLog("😵 "+(foeSide==="p"?"Kamu":"Lawan")+" akan melewati giliran");
        }

        if(counter){
            me.hp-=counter;
            arcLog("↩️ Balasan "+counter+" damage ke "+who.toLowerCase());
            arcDmgNum(side,"-"+counter,"hit");
            arcShake(counter);
            arcSfx("impact");
        }

        if(c.t==="atk")me.mom=false;
        else if(c.t==="mag")me.mom=true;

        arcRender();

        if(me.hp<=0){arcFinish(side==="p"?"lose":"win");return false;}

        if(foe.hp<=0){arcFinish(side==="p"?"win":"lose");return false;}

        return !!c.extra;

    }

    function arcFinish(r,timeout){

        if(!A||A.over)return;

        A.over=true;

        $("arcAsk").classList.remove("on");
        $("arcPass").classList.remove("on");

        $("arcEndT").textContent=r==="win"?"🏆 MENANG!":r==="lose"?"💀 KALAH":"🤝 SERI";
        $("arcEndS").textContent=(timeout?"Batas giliran tercapai — dinilai dari sisa HP. ":"")
            +"HP kamu "+Math.max(0,Math.round(A.p.hp))+" • HP lawan "+Math.max(0,Math.round(A.e.hp))+"."
            +(A.resets?" Kartu direset "+A.resets+"x.":"");

        let delay=700;

        arcBgmDuck(true);

        if(timeout||r==="draw")arcSfx(r==="win"?"win":r==="lose"?"lose":"shimmer");

        if(!timeout&&r!=="draw"){

            arcSfx("ko");

            setTimeout(()=>arcSfx(r==="win"?"win":"lose"),1100);


            const loser=r==="win"?"e":"p";

            const f=document.createElement("div");
            f.className="arcKO";
            f.textContent="K.O.!";
            $("arcScr").appendChild(f);
            setTimeout(()=>f.remove(),2000);

            arcFxAdd("burst",loser);
            arcShake(80);

            delay=1800;

        }

        setTimeout(()=>{if(A)$("arcEnd").classList.add("on");},delay);

    }

    $("arcAgain").onclick=()=>{
        const d=A?A.p.deck.slice():arcSel.slice();
        arcStart(d);
    };

    $("arcEndBack").onclick=()=>{A=null;renderModes();show("modes");};

    $("arcExit").onclick=()=>{A=null;renderModes();show("modes");};

    /* ---------- GLOBAL v0.01: MISI HARIAN (sumber 💎) ---------- */

    let misMsg="";

    const MIS_DUEL=[
        {id:"ls40",enemy:"lifesteal",hand:"Power kamu -40%",pow:.6,gems:40},
        {id:"sam50",enemy:"samurai",hand:"HP kamu -50%",hp:.5,gems:40},
        {id:"snp40",enemy:"sniper",hand:"HP kamu -40%",hp:.6,gems:35},
        {id:"hnt30",enemy:"hunter",hand:"Power kamu -30%",pow:.7,gems:35},
        {id:"hol30",enemy:"hole",hand:"HP kamu -30%",hp:.7,gems:35},
        {id:"pha40",enemy:"phase",hand:"Power kamu -40%",pow:.6,gems:40}
    ];

    const MIS_WIN={id:"win3",need:3,gems:30};

    function misHash(t){
        let h=0;
        for(let i=0;i<t.length;i++)h=(h*31+t.charCodeAt(i))>>>0;
        return h;
    }

    function misToday(){
        const h=misHash(todayStr());
        const n=MIS_DUEL.length;
        const a=h%n;
        let b=(Math.floor(h/7)+1+a)%n;
        if(b===a)b=(a+1)%n;
        return[MIS_DUEL[a],MIS_DUEL[b]];
    }

    function misState(){
        if(!profile)return null;
        const t=todayStr();
        if(!profile.mis||profile.mis.day!==t)profile.mis={day:t,done:{},wins:0};
        if(!profile.mis.done)profile.mis.done={};
        return profile.mis;
    }

    function misLeft(){
        const m=misState();
        if(!m)return 0;
        let n=0;
        misToday().forEach(x=>{if(!m.done[x.id])n++;});
        if(!m.done[MIS_WIN.id])n++;
        return n;
    }

    function misBadgeRender(){
        const b=$("misBadge");
        if(!b)return;
        const n=profile?misLeft():0;
        b.style.display=n>0?"flex":"none";
        b.textContent=n;
    }

    function missionWin(){

        const m=misState();

        if(!m)return;

        m.wins=(m.wins||0)+1;

        if(m.wins>=MIS_WIN.need&&!m.done[MIS_WIN.id]){
            m.done[MIS_WIN.id]=true;
            addGems(MIS_WIN.gems);
            misMsg="Misi selesai: +"+MIS_WIN.gems+" 💎";
        }

        saveProfile();

    }

    let misCur=null;
    let misSkillSel="normal";
    let misCtlSel="auto";

    function renderMis(){

        if(!profile)loadProfile();

        const m=misState();

        $("misSub").textContent="Selesaikan untuk dapat 💎. Reset tiap hari. Tantangannya sulit!";

        let h="";

        misToday().forEach(x=>{

            const sk=SKILLS[x.enemy];

            const done=!!m.done[x.id];

            h+='<div class="misCard'+(done?" done":"")+'">'
                +'<div class="misT">⚔️ Kalahkan '+sk.icon+' '+sk.name+'</div>'
                +'<div class="misH">Syarat: '+x.hand+'</div>'
                +'<div class="misR"><b>💎 '+x.gems+'</b>'
                +(done?'<span>✓ Selesai</span>':'<button data-m="'+x.id+'">Mulai ▶</button>')
                +'</div></div>';

        });

        const w=Math.min(MIS_WIN.need,m.wins||0);

        const wd=!!m.done[MIS_WIN.id];

        h+='<div class="misCard'+(wd?" done":"")+'">'
            +'<div class="misT">🏆 Menangkan '+MIS_WIN.need+' duel Ranked/Classic</div>'
            +'<div class="misBar"><i style="width:'+(w/MIS_WIN.need*100)+'%"></i></div>'
            +'<div class="misR"><b>💎 '+MIS_WIN.gems+'</b><span>'+(wd?"✓ Selesai":w+" / "+MIS_WIN.need)+'</span></div></div>';

        $("misList").innerHTML=h;

        $("misList").querySelectorAll("button[data-m]").forEach(b=>{
            b.onclick=()=>{
                misCur=MIS_DUEL.find(x=>x.id===b.dataset.m);
                beginMission();
            };
        });

        const sel=$("misSkill");

        sel.innerHTML=profile.unlocked.map(k=>'<option value="'+k+'">'+SKILLS[k].icon+' '+SKILLS[k].name+'</option>').join("");

        if(!profile.unlocked.includes(misSkillSel))misSkillSel="normal";

        sel.value=misSkillSel;

        document.querySelectorAll("#misCtl button").forEach(b=>{
            b.classList.toggle("on",b.dataset.c===misCtlSel);
        });

        misBadgeRender();

    }

    $("misSkill").onchange=()=>{misSkillSel=$("misSkill").value;};

    document.querySelectorAll("#misCtl button").forEach(b=>{
        b.onclick=()=>{
            misCtlSel=b.dataset.c;
            document.querySelectorAll("#misCtl button").forEach(x=>x.classList.toggle("on",x===b));
        };
    });

    function openMissions(){
        audio();
        renderMis();
        show("misScr");
    }

    $("btnMis").onclick=openMissions;

    $("misBack").onclick=showMenu;

    function beginMission(){

        audio();

        hideScreens();

        const m=misCur;

        rank.active=true;
        rank.stage="mission";
        rank.mode="mission";
        rank.skill=misSkillSel;
        rank.control=misCtlSel;

        setCls("ranked");

        if(!sandboxObjects)sandboxObjects=objects;

        objects=[];

        try{stopDuel()}catch(e){}

        resetTransient();

        const p=addCharacter(W*.25,H*.5,"blue",misSkillSel);

        const foe=addCharacter(W*.75,H*.5,"red",m.enemy);

        startDuel();

        rank.player=p;

        if(m.hp){
            p.maxHp=Math.round(p.maxHp*m.hp);
            p.hp=p.maxHp;
        }

        if(m.pow)p.powMul=m.pow;

        foe.ai=makeAI(diffOf(0));

        if(rank.control==="manual"){

            p.manual=true;
            p.mcd=cdStartManual(p);
            p.mcdMax=p.mcd;
            p.mcd2=p.mcdMax2=(SKILLS[p.skill]&&SKILLS[p.skill].ghostSkill)?(SKILLS[p.skill].dimCooldownMax||20):2;
            p.manualCloneDone=false;
            p.boostT=0;
            p.goldenGo=false;
            p.gWasActive=false;

            $("sbIcon").textContent=SKILLS[p.skill].icon;
            $("sbLabel").textContent=abilityOf(p).name;

            body.classList.add("manualOn");

            startHud();

        }

        setSpec(false);

        rank.inDuel=true;
        rank.t=0;
        rank.bothDead=0;

        rank.banner="📋 Misi • vs "+SKILLS[m.enemy].name+" • "+m.hand;

        $("rankBanner").textContent="⏱ "+MATCH_LIMIT+" • "+rank.banner;

    }

    function finishMission(win){

        const m=misCur;

        const st=misState();

        let rw="";

        if(win){

            if(!st.done[m.id]){
                st.done[m.id]=true;
                addGems(m.gems);
                rw="Misi selesai: +"+m.gems+" 💎";
            }
            else{
                rw="Misi ini sudah selesai hari ini (tanpa hadiah lagi).";
            }

        }

        saveProfile();

        $("rrIcon").textContent=win?"✅":"💀";
        $("rrTitle").textContent=win?"MISI BERHASIL!":"MISI GAGAL";
        $("rrText").textContent=win?"Kamu mengalahkan "+SKILLS[m.enemy].name+" dengan syarat: "+m.hand+".":"Coba lagi — tidak ada batas percobaan.";
        $("rrReward").textContent=rw;

        const b1=$("rrBtn1");
        const b2=$("rrBtn2");

        b2.style.display="";

        b1.textContent="🔁 Coba Lagi";
        b1.onclick=beginMission;

        b2.textContent="📋 Misi";
        b2.onclick=()=>{cleanup();openMissions();};

        show("rankResult");

    }

    /* ==================================================
       GLOBAL v0.08: MODE STORY
    ================================================== */

    const ST_CHARS={
        tony:{n:"Tony",art:"normal",f:560},
        kakek:{n:"Kakek Bram",art:"kakek",f:300}
    };

    function stChar(k){

        if(ST_CHARS[k])return ST_CHARS[k];

        const l=LORE[k];

        const base=[330,380,430,480,520,360,410,460];

        return{n:l?l.who:k,art:k,f:base[(k.charCodeAt(0)+k.length)%base.length]};

    }

    /* baris dialog: [siapa, teks, emote, efek] */

    const STORY=[

        {
            t:"Dunia Penuh Skill",place:"Kota Angin",foe:"speed",bg:["#3a6bd8","#1b2a5c"],d:.3,hp:1.7,pow:1.3,
            reward:{coins:150,gems:0,xp:40},
            pre:[
                ["narr","Di dunia ini, setiap orang lahir membawa satu skill."],
                ["narr","Ada yang berlari secepat angin. Ada yang menghentikan waktu. Ada yang memanggil lubang hitam."],
                ["narr","Dan ada Tony… yang tidak punya apa-apa."],
                ["kakek","Tony, kamu mau ikut turnamen lagi? Orang-orang akan menertawakanmu, Nak.","😟"],
                ["tony","Biar saja, Kek. Aku tidak punya skill, tapi aku punya pistol pemberian Kakek.","🙂"],
                ["kakek","Pistol tua itu tidak punya kekuatan apa pun.","😔"],
                ["tony","Justru itu. Kalau aku bisa menang dengan pistol biasa, berarti tidak ada yang mustahil.","🔥"],
                ["kakek","…Pergilah. Dan jangan lari dari tembakan pertamamu.","🙂"],
                ["narr","Di gerbang kota, seorang kurir berhenti tepat di depan Tony."],
                ["speed","Hah? Anak tanpa skill? Kamu salah masuk arena, ya?","😏"],
                ["tony","Aku Tony. Aku akan mengalahkan SEMUA skill di dunia ini. Mulai darimu.","😤"],
                ["speed","HAHAHA! Semua skill?! Coba tangkap angin dulu, Tony!","😆","flash"]
            ],
            win:[
                ["speed","Mustahil… aku kalah dari orang tanpa skill?","😵","shake"],
                ["tony","Kamu cepat sekali. Tapi kamu tidak pernah melihat ke mana aku membidik.","😌"],
                ["speed","Hmph. Namaku Hayate. Ingat itu. Kalau mau lanjut, hati-hati dengan Kuro di hutan kabut. Dia tidak pernah meleset.","😤"]
            ],
            lose:[
                ["speed","Sudah kubilang. Manusia tidak bisa menangkap angin.","😏"],
                ["tony","Belum selesai… aku akan kembali!","😣"]
            ]
        },

        {
            t:"Mata Elang",place:"Hutan Kabut",foe:"sniper",bg:["#2f7d52","#0f2a1d"],d:.3,hp:2,pow:1.6,
            reward:{coins:170,gems:0,xp:50},
            pre:[
                ["narr","Kabut tebal menelan jalan setapak. Di kejauhan, ada titik merah kecil yang mengikuti Tony."],
                ["tony","Itu… lensa bidik?","😨"],
                ["sniper","Berhenti di situ. Aku sudah membidikmu sejak kamu masuk hutan.","😐"],
                ["tony","Kamu Kuro? Hayate bilang kamu tidak pernah meleset.","😮"],
                ["sniper","Hayate kalah dari anak tanpa skill… jadi rumor itu benar. Menarik.","🧐"],
                ["sniper","Tapi satu tembakanku bisa menembus apa pun. Perisai, kekebalan, bahkan klon.","😎"],
                ["tony","Kalau begitu aku tinggal tidak kena.","😤"],
                ["sniper","Lucu. Buktikan.","😏","shake"]
            ],
            win:[
                ["sniper","Kamu bergerak… sebelum peluruku keluar. Bagaimana?","😳"],
                ["tony","Aku tidak membaca pelurumu. Aku membaca napasmu.","😌"],
                ["sniper","Hmph. Pergilah ke taman di timur. Ada tabib yang tidak bisa dijatuhkan. Hati-hati, Tony.","🙂"]
            ],
            lose:[
                ["sniper","Satu tembakan, satu kemenangan. Latihan lagi.","😐"],
                ["tony","Aku harus lebih sabar dari dia…","😣"]
            ]
        },

        {
            t:"Tabib yang Tak Jatuh",place:"Taman Herbal",foe:"regen",bg:["#4ccf8d","#1b5a43"],d:.35,hp:2,pow:1.7,
            reward:{coins:190,gems:10,xp:60},
            pre:[
                ["narr","Di tengah taman bunga, seorang gadis merawat tanaman sambil bersenandung."],
                ["regen","Oh, ada tamu! Kamu pasti Tony, yang mengalahkan Hayate dan Kuro, kan?","😊"],
                ["tony","Kamu Mirai? Aku diberitahu untuk mengalahkanmu… tapi kamu kelihatan tidak mau bertarung.","😅"],
                ["regen","Aku memang tidak suka bertarung. Tapi aku juga tidak suka kalah.","😊"],
                ["regen","Setiap beberapa detik aku pulih sendiri. Kamu harus menjatuhkanku lebih cepat dari penyembuhanku.","😌"],
                ["tony","Berarti aku harus menembak tanpa henti.","💪"],
                ["regen","Itu pun belum tentu cukup. Ayo, tunjukkan tekadmu!","✨","flash"]
            ],
            win:[
                ["regen","Aduh… ternyata ada yang bisa mengalahkan penyembuhanku. Hebat sekali!","😵"],
                ["tony","Terima kasih sudah menahan diri. Taman ini indah.","🙂"],
                ["regen","Ambil ini sebagai bekal. Di desa bara, ada pewaris api yang sombong. Jangan sampai terbakar ya!","😊"]
            ],
            lose:[
                ["regen","Tidak apa-apa, istirahat dulu. Mau kuobati lukamu?","😊"],
                ["tony","Aku coba lagi… dengan tembakan lebih rapat.","😣"]
            ]
        },

        {
            t:"Bara yang Tak Padam",place:"Desa Bara",foe:"fireshot",bg:["#e8602c","#4a1408"],d:.4,hp:2.2,pow:1.6,
            reward:{coins:210,gems:0,xp:70},
            pre:[
                ["narr","Udara panas. Di sebuah tungku raksasa, pemuda berambut api menempa peluru yang masih membara."],
                ["fireshot","Kamu Tony? Pantas ribut sekali! Orang tanpa skill menjatuhkan para legenda?","😏"],
                ["tony","Aku cuma menembak lurus. Itu saja.","😐"],
                ["fireshot","Lurus?! Peluruku makin panas dan makin cepat setiap detik! Kamu akan hangus sebelum sempat membidik!","🔥","flash"],
                ["tony","Kalau begitu aku akan menyelesaikannya sebelum panasnya memuncak.","😤"],
                ["fireshot","Berani juga! Ayo, nyalakan duelnya!","😆","shake"]
            ],
            win:[
                ["fireshot","Api… padam? Di tanganku sendiri?!","😵","shake"],
                ["tony","Peluruku biasa saja. Tapi aku tidak pernah memberimu waktu untuk memanas.","😌"],
                ["fireshot","Hah… aku ngaku kalah. Aku Homura. Di timur ada Jiro yang pelurunya tidak pernah salah arah. Semoga beruntung!","😅"]
            ],
            lose:[
                ["fireshot","Hangus! Makin lama makin panas, kan?","😆"],
                ["tony","Aku harus menyelesaikannya lebih cepat…","😣"]
            ]
        },

        {
            t:"Peluru yang Mengejar",place:"Lembah Magnet",foe:"magnet",bg:["#7c4dff","#1d1250"],d:.4,hp:2.8,pow:2,
            reward:{coins:230,gems:10,xp:80},
            pre:[
                ["narr","Serpihan logam melayang di udara. Seorang pria dengan jaket penuh magnet berdiri tenang."],
                ["magnet","Aku Jiro. Setiap pelurunya mengejar targetnya. Tidak ada yang bisa lari.","😎"],
                ["tony","Peluru yang tidak bisa dihindari…","😰"],
                ["magnet","Kamu pikir kamu bisa menghindar? Semua orang yang datang ke sini mencoba hal yang sama.","😏"],
                ["tony","Aku tidak berencana menghindar. Aku berencana menembakmu duluan.","😤"],
                ["kakek","(Suara Kakek terngiang) Jangan lari dari tembakan pertamamu, Nak.","🙂"],
                ["magnet","Hmm? Kamu bicara sendiri? Baiklah, mulai!","🤨","flash"]
            ],
            win:[
                ["magnet","Peluruku mengejarmu… tapi kamu sudah menjatuhkanku duluan.","😮"],
                ["tony","Tidak ada yang tak bisa dihindari, kalau lawannya tumbang lebih dulu.","😌"],
                ["magnet","Logika yang nekat. Pergilah ke dojo di utara. Ada pendekar yang tidak memakai pistol sama sekali.","🙂"]
            ],
            lose:[
                ["magnet","Magnet tidak pernah salah.","😎"],
                ["tony","Aku harus lebih cepat dari pelurunya…","😣"]
            ]
        },

        {
            t:"Pedang Tanpa Pistol",place:"Dojo Utara",foe:"samurai",bg:["#b32b3f","#2a0c14"],d:.4,hp:3.4,pow:1.9,
            reward:{coins:250,gems:0,xp:90},
            pre:[
                ["narr","Salju tipis turun di halaman dojo. Seorang pendekar berdiri tegak dengan katana di pinggang."],
                ["samurai","Aku Kenji. Aku tidak memakai pistol. Hanya pedang, dan jarak yang kuhapus.","😐"],
                ["tony","Kamu menolak pistol? Padahal pistol itu hebat.","🤔"],
                ["samurai","Pistol menembak dari jauh. Pedang bicara dari dekat. Kita lihat siapa yang lebih jujur.","🧐"],
                ["tony","Aku hormat padamu, Kenji. Tapi aku tidak akan membiarkanmu mendekat.","😤"],
                ["samurai","Bagus. Tatapan seorang petarung.","🙂","shake"]
            ],
            win:[
                ["samurai","Tebasanku… tidak sempat menyentuhmu.","😳"],
                ["tony","Pistol dan pedang sama saja, Kenji. Keduanya cuma alat. Yang penting tekadnya.","😌"],
                ["samurai","Kalimat yang layak dihormati. Di kastil gelap, ada bangsawan yang menghisap nyawa. Jangan lengah.","🙂"]
            ],
            lose:[
                ["samurai","Belum cukup dekat untuk menembak. Belum cukup jauh untuk lari.","😐"],
                ["tony","Aku harus menjaga jarak lebih baik…","😣"]
            ]
        },

        {
            t:"Bangsawan Malam",place:"Kastil Kegelapan",foe:"lifesteal",bg:["#7a0f2b","#12040a"],d:.45,hp:3,pow:2.2,
            reward:{coins:280,gems:15,xp:100},
            pre:[
                ["narr","Kastil tua. Lilin menyala sendiri. Seorang pria berjubah merah menunggu di aula."],
                ["lifesteal","Selamat datang, anak tanpa skill. Aku Vlad. Aku sudah mendengar kemenanganmu.","😏"],
                ["tony","Kamu yang menghisap nyawa orang?","😠"],
                ["lifesteal","Setiap peluruku mengembalikan nyawaku. Dan jika kamu masuk lingkaranku, aku akan menyedot darahmu tanpa belas kasihan.","🦇","flash"],
                ["tony","Kamu mau mengambil sesuatu dariku? Aku tidak punya apa-apa untuk diambil, Vlad.","😤"],
                ["lifesteal","Kita lihat apakah keberanianmu sebanding dengan darahmu.","😈","shake"]
            ],
            win:[
                ["lifesteal","Mustahil… darahku… tidak cukup menyembuhkan…","😵","shake"],
                ["tony","Kamu hanya bisa mengambil dari orang yang punya sesuatu untuk dilindungi. Aku maju tanpa menahan apa-apa.","😌"],
                ["lifesteal","…Kamu aneh, Tony. Pergilah ke jurang kehampaan. Void di sana lebih menakutkan dariku.","🙂"]
            ],
            lose:[
                ["lifesteal","Hahaha! Darahmu manis sekali.","😈"],
                ["tony","Aku tidak boleh masuk lingkarannya terlalu lama…","😣"]
            ]
        },

        {
            t:"Jurang Kehampaan",place:"Jurang Tanpa Dasar",foe:"hole",bg:["#3d1c8f","#06020f"],d:.6,hp:2.8,pow:1.5,
            reward:{coins:310,gems:0,xp:110},
            pre:[
                ["narr","Langit seakan retak. Di tengah jurang, sebuah bola hitam berputar menarik debu dan cahaya."],
                ["hole","Aku Void. Semua yang bergerak akhirnya tertarik padaku.","😶"],
                ["tony","Lubang hitam…","😨"],
                ["hole","Tidak ada yang bisa melarikan diri. Bahkan waktu pun berhenti di tepiannya.","😐"],
                ["tony","Aku sudah hidup tanpa apa-apa sejak kecil, Void. Kehampaan tidak menakutkanku.","😤"],
                ["hole","Kalau begitu, masuklah dengan tenang.","😶","flash"]
            ],
            win:[
                ["hole","Aku… tidak menarikmu? Kamu… berdiri di tepi tapi tidak jatuh.","😳"],
                ["tony","Karena aku tahu apa yang kucari. Itu yang membuatku tidak tersesat.","😌"],
                ["hole","Pergilah ke puncak salju. Di sana ada gadis yang membekukan segalanya. Dia juga kesepian sepertimu.","🙂"]
            ],
            lose:[
                ["hole","Semua orang akhirnya tertarik juga.","😶"],
                ["tony","Aku harus lebih jauh dari pusatnya…","😣"]
            ]
        },

        {
            t:"Putri Salju",place:"Puncak Es Abadi",foe:"ice",bg:["#6cc8ff","#1b3d63"],d:.65,hp:3,pow:1.4,
            reward:{coins:340,gems:20,xp:120},
            pre:[
                ["narr","Badai salju menyambut Tony. Di pucuk gunung, seorang gadis berambut putih berdiri sendirian."],
                ["ice","Kamu datang jauh-jauh hanya untuk dibekukan? Aku Yuki.","😐"],
                ["tony","Void bilang kamu kesepian.","😌"],
                ["ice","…Aku tidak kesepian. Aku hanya… tidak ingin ada yang bergerak terlalu cepat meninggalkanku.","😔"],
                ["ice","Peluruku memperlambat siapa pun. Dan jika kuhembuskan napasku, seluruh arena membeku.","❄️","flash"],
                ["tony","Kalau begitu aku akan menjatuhkanmu pelan-pelan. Aku tidak akan pergi sebelum duel ini selesai.","🙂"],
                ["ice","…Baiklah. Jangan menyesal.","😤","shake"]
            ],
            win:[
                ["ice","Aku… kalah? Padahal semuanya sudah beku…","😳"],
                ["tony","Kamu sudah tidak sendirian lagi, Yuki.","😊"],
                ["ice","…Terima kasih, Tony. Satu lagi yang tersisa: sang penguasa waktu di menara. Dia yang tertinggi di antara kami.","🥺"]
            ],
            lose:[
                ["ice","Dingin, kan? Istirahatlah.","😐"],
                ["tony","Aku harus menembak lebih cepat sebelum membeku…","😣"]
            ]
        },

        {
            t:"Penguasa Waktu",place:"Menara Waktu",foe:"time",bg:["#e8c34a","#1b2a5c"],d:.7,hp:3.3,pow:1.4,
            reward:{coins:600,gems:60,xp:250},
            pre:[
                ["narr","Menara menjulang menembus awan. Jarum jam raksasa berhenti di langit."],
                ["time","Jadi kamu Tony. Penantang yang mengalahkan para pemilik skill.","😐"],
                ["tony","Kamu Chrono? Yang paling kuat di dunia ini?","😮"],
                ["time","Aku bisa menghentikan waktu. Tidak ada yang bisa menyentuhku saat waktu berhenti.","😎","flash"],
                ["tony","Dunia punya banyak orang kuat. Aku tidak punya skill. Tapi aku datang sejauh ini.","😤"],
                ["kakek","(Kakek Bram muncul di tangga menara) Tony… pistol itu bukan pistol biasa.","😟"],
                ["tony","Kakek?! Kenapa Kakek di sini?","😮"],
                ["time","Bram… sudah lama sekali. Kamu yang dulu menjatuhkanku dengan pistol yang sama.","😳"],
                ["kakek","Dulu aku juga tidak punya skill, Tony. Karena itu aku tidak memberimu skill. Aku memberimu alasan untuk tidak menyerah.","🙂"],
                ["tony","…Aku mengerti, Kek. Kalau begitu, ini saatnya.","🔥","shake"]
            ],
            win:[
                ["time","Waktu… berhenti sekalipun… kamu tetap membidik tepat.","😵","shake"],
                ["time","Pistol itu… milik Bram. Dan sekarang… milikmu.","🙂"],
                ["kakek","Kamu berhasil, Nak. Kamu mengalahkan semuanya.","😭"],
                ["tony","Bukan aku sendiri, Kek. Setiap lawan mengajariku sesuatu.","😌"],
                ["narr","Kabar itu menyebar ke seluruh dunia: seorang penembak tanpa skill telah mengalahkan semua pemilik skill."],
                ["narr","Tony pun dikenal sebagai Orang Terkuat. Bukan karena kekuatan yang dibawanya sejak lahir…"],
                ["narr","…tetapi karena ia tidak pernah berhenti berjuang.","","flash"],
                ["narr","T A M A T  •  Terima kasih sudah bermain! — RapzXdeveloper"]
            ],
            lose:[
                ["time","Waktu selalu berpihak padaku.","😎"],
                ["tony","Aku harus menembak sebelum waktunya berhenti…","😣"]
            ]
        }

    ];

    let stCur=0;
    let stCtl="auto";

    let stMuted=false;

    try{stMuted=localStorage.getItem("tds_st_mute")==="1";}catch(e){}

    function stBlip(f){

        if(stMuted)return;

        try{
            initAudio();
            const ac=audioCtx;
            if(!ac)return;
            const t=ac.currentTime;
            const o=ac.createOscillator();
            const g=ac.createGain();
            o.type="square";
            o.frequency.setValueAtTime(f*(.94+Math.random()*.12),t);
            g.gain.setValueAtTime(.0001,t);
            g.gain.exponentialRampToValueAtTime(.035,t+.005);
            g.gain.exponentialRampToValueAtTime(.0001,t+.07);
            o.connect(g);
            g.connect(ac.destination);
            o.start(t);
            o.stop(t+.09);
        }catch(e){}

    }

    function stDone(i){
        return !!profile&&profile.story&&profile.story.done>i;
    }

    function stUnlocked(i){
        return i===0||stDone(i-1);
    }

    function renderStory(){

        if(!profile)loadProfile();

        const done=profile.story.done;

        $("stSub").textContent="Progres: "+Math.min(done,STORY.length)+" / "+STORY.length+" bab selesai";

        let h="";

        STORY.forEach((c,i)=>{

            const dn=stDone(i);
            const ul=stUnlocked(i);
            const cur=ul&&!dn;
            const lk=LORE[c.foe];

            h+='<div class="stCh'+(dn?" done":"")+(ul?"":" lock")+(cur?" cur":"")+'">'
                +'<div class="stN">'+(dn?"✓":ul?(i+1):"🔒")+'</div>'
                +'<div class="stI"><b>Bab '+(i+1)+' • '+c.t+'</b>'
                +'<small>📍 '+c.place+' • vs '+(lk?lk.who:c.foe)+' '+SKILLS[c.foe].icon+'</small>'
                +'<div class="stR">'+(dn?"Selesai":"Hadiah: 🪙"+c.reward.coins+(c.reward.gems?" 💎"+c.reward.gems:"")+" ⭐"+c.reward.xp+" XP")+'</div></div>'
                +(ul?'<button data-i="'+i+'">'+(dn?"Ulang ▶":"Mulai ▶")+'</button>':'')
                +'</div>';

        });

        $("stList").innerHTML=h;

        $("stList").querySelectorAll("button[data-i]").forEach(b=>{
            b.onclick=()=>startChapter(Number(b.dataset.i));
        });

        document.querySelectorAll("#stCtl button").forEach(b=>{
            b.classList.toggle("on",b.dataset.c===stCtl);
        });

    }

    document.querySelectorAll("#stCtl button").forEach(b=>{
        b.onclick=()=>{
            stCtl=b.dataset.c;
            document.querySelectorAll("#stCtl button").forEach(x=>x.classList.toggle("on",x===b));
        };
    });

    function openStory(){

        audio();

        renderStory();

        show("stScr");

        const cur=document.querySelector("#stList .stCh.cur");

        if(cur)try{cur.scrollIntoView({block:"center"});}catch(e){}

    }

    $("stBack").onclick=showMenu;

    /* ---------- MESIN DIALOG ---------- */

    let dlg=null;

    function dlgOrbsBuild(c){

        const box=$("dlgOrbs");

        if(window.POTATO){box.innerHTML="";return;}

        let h="";

        for(let i=0;i<14;i++){
            h+='<i style="left:'+(Math.random()*100)+'%;animation-duration:'+(6+Math.random()*8)+'s;animation-delay:-'+(Math.random()*10)+'s;opacity:'+(.25+Math.random()*.4)+';background:'+c+'"></i>';
        }

        box.innerHTML=h;

    }

    function dlgSetChar(side,key){

        const el=$(side==="L"?"dlgL":"dlgR");

        if(el.dataset.k===key)return;

        const c=stChar(key);

        $(side==="L"?"dlgAL":"dlgAR").innerHTML=skillArt(c.art);

        el.dataset.k=key;

        el.classList.remove("enter");
        void el.offsetWidth;
        el.classList.add("in","enter");

    }

    function playDialog(opt,lines,done){

        if(dlg&&dlg.timer)clearInterval(dlg.timer);

        dlg={lines:lines||[],i:0,done:done,typing:false,timer:0,auto:false,full:"",autoT:0,f:400,fin:false};

        const bg=opt.bg||["#2b4aa8","#0a1020"];

        $("dlgBg").style.background="radial-gradient(circle at 50% 30%,"+bg[0]+","+bg[1]+" 75%)";

        dlgOrbsBuild(bg[0]);

        ["dlgL","dlgR"].forEach(id=>{
            const e=$(id);
            e.className="dlgChar "+(id==="dlgL"?"left":"right");
            e.dataset.k="";
            e.querySelector(".dlgArt").innerHTML="";
        });

        $("dlgText").textContent="";
        $("dlgName").textContent="";
        $("dlgNext").classList.remove("on");
        $("dlgTitle").textContent=opt.title||"";
        $("dlgAuto").classList.remove("on");
        $("dlgMute").textContent=stMuted?"🔇":"🔊";

        show("dlgScr");

        if(opt.card){

            $("dlgCardA").textContent=opt.card[0];
            $("dlgCardB").textContent=opt.card[1];
            $("dlgCardC").textContent=opt.card[2];

            const cd=$("dlgCard");

            cd.classList.remove("on");
            void cd.offsetWidth;
            cd.classList.add("on");

            dlg.cardT=setTimeout(()=>{cd.classList.remove("on");dlgLine();},1900);

        }
        else dlgLine();

    }

    function dlgLine(){

        if(!dlg||dlg.fin)return;

        const L=dlg.lines[dlg.i];

        if(!L){dlgEnd();return;}

        const who=L[0],text=L[1],emo=L[2],fx=L[3];

        const isN=who==="narr";

        const c=isN?{n:"",f:260}:stChar(who);

        $("dlgBox").classList.toggle("narr",isN);

        $("dlgName").textContent=c.n;

        dlg.f=c.f;

        const sideL=$("dlgL"),sideR=$("dlgR");

        if(!isN){

            const side=who==="tony"?"L":"R";

            dlgSetChar(side,who);

            const act=side==="L"?sideL:sideR;
            const oth=side==="L"?sideR:sideL;

            act.classList.add("talk");
            act.classList.remove("idle");

            oth.classList.remove("talk");

            if(oth.dataset.k)oth.classList.add("idle");

            const em=$(side==="L"?"dlgEL":"dlgER");

            em.classList.remove("pop");

            if(emo){
                em.textContent=emo;
                void em.offsetWidth;
                em.classList.add("pop");
            }

        }
        else{
            sideL.classList.remove("talk");
            sideR.classList.remove("talk");
        }

        if(fx==="shake"){
            const st=$("dlgStage");
            st.classList.remove("shake");
            void st.offsetWidth;
            st.classList.add("shake");
            try{sound("hit");}catch(e){}
        }
        else if(fx==="flash"){
            const fl=$("dlgFlash");
            fl.classList.remove("on");
            void fl.offsetWidth;
            fl.classList.add("on");
            try{sound("boost");}catch(e){}
        }

        dlgType(text);

    }

    function dlgType(text){

        clearInterval(dlg.timer);

        dlg.full=text;

        dlg.typing=true;

        $("dlgNext").classList.remove("on");

        const el=$("dlgText");

        el.textContent="";

        let n=0;

        const idx=dlg.i;

        dlg.timer=setInterval(()=>{

            n++;

            el.textContent=text.slice(0,n);

            if(n%2===0&&text[n-1]!==" ")stBlip(dlg.f);

            if(n>=text.length)dlgTypeDone();

        },window.POTATO?14:26);

    }

    function dlgTypeDone(){

        if(!dlg)return;

        clearInterval(dlg.timer);

        dlg.typing=false;

        $("dlgText").textContent=dlg.full;

        $("dlgNext").classList.add("on");

        $("dlgL").classList.remove("talk");
        $("dlgR").classList.remove("talk");

        ["dlgL","dlgR"].forEach(id=>{
            if($(id).dataset.k)$(id).classList.add("idle");
        });

        if(dlg.auto){

            const idx=dlg.i;

            clearTimeout(dlg.autoT);

            dlg.autoT=setTimeout(()=>{
                if(dlg&&dlg.auto&&dlg.i===idx&&!dlg.fin)dlgAdvance();
            },1200+dlg.full.length*35);

        }

    }

    function dlgAdvance(){

        if(!dlg||dlg.fin)return;

        if(dlg.typing){
            dlgTypeDone();
            return;
        }

        dlg.i++;

        dlgLine();

    }

    function dlgEnd(){

        if(!dlg||dlg.fin)return;

        dlg.fin=true;

        clearInterval(dlg.timer);
        clearTimeout(dlg.autoT);
        clearTimeout(dlg.cardT);

        $("dlgCard").classList.remove("on");

        const cb=dlg.done;

        dlg=null;

        if(cb)cb();

    }

    $("dlgScr").onclick=e=>{

        if(e.target.closest("#dlgTop"))return;

        dlgAdvance();

    };

    $("dlgSkip").onclick=e=>{
        e.stopPropagation();
        dlgEnd();
    };

    $("dlgAuto").onclick=e=>{

        e.stopPropagation();

        if(!dlg)return;

        dlg.auto=!dlg.auto;

        $("dlgAuto").classList.toggle("on",dlg.auto);

        if(dlg.auto&&!dlg.typing)dlgTypeDone();

    };

    $("dlgMute").onclick=e=>{

        e.stopPropagation();

        stMuted=!stMuted;

        try{localStorage.setItem("tds_st_mute",stMuted?"1":"0");}catch(ex){}

        $("dlgMute").textContent=stMuted?"🔇":"🔊";

    };

    /* ---------- ALUR BAB ---------- */

    function startChapter(i){

        stCur=i;

        const c=STORY[i];

        audio();

        playDialog({
            title:"📖 Bab "+(i+1)+" • "+c.t,
            bg:c.bg,
            card:["BAB "+(i+1),c.t,"📍 "+c.place]
        },c.pre,beginStory);

    }

    function beginStory(){

        audio();

        hideScreens();

        const c=STORY[stCur];

        rank.active=true;
        rank.stage="story";
        rank.mode="story";
        rank.skill="normal";
        rank.control=stCtl;

        setCls("ranked");

        if(!sandboxObjects)sandboxObjects=objects;

        objects=[];

        try{stopDuel()}catch(e){}

        resetTransient();

        const p=addCharacter(W*.25,H*.5,"blue","normal");

        const foe=addCharacter(W*.75,H*.5,"red",c.foe);

        startDuel();

        rank.player=p;

        p.maxHp=Math.round(p.maxHp*c.hp);
        p.hp=p.maxHp;

        if(c.pow)p.powMul=c.pow;

        foe.ai=makeAI(c.d);

        if(rank.control==="manual"){

            p.manual=true;
            p.mcd=cdStartManual(p);
            p.mcdMax=p.mcd;
            p.mcd2=p.mcdMax2=2;
            p.manualCloneDone=false;
            p.boostT=0;
            p.goldenGo=false;
            p.gWasActive=false;

            $("sbIcon").textContent=SKILLS[p.skill].icon;
            $("sbLabel").textContent=abilityOf(p).name;

            body.classList.add("manualOn");

            startHud();

        }

        setSpec(false);

        rank.inDuel=true;
        rank.t=0;
        rank.bothDead=0;

        rank.banner="📖 Bab "+(stCur+1)+" • vs "+((LORE[c.foe]||{}).who||c.foe);

        $("rankBanner").textContent="⏱ "+MATCH_LIMIT+" • "+rank.banner;

    }

    function finishStory(win){

        const c=STORY[stCur];

        let rw="";

        if(win){

            const first=!stDone(stCur);

            if(first){

                profile.story.done=Math.max(profile.story.done,stCur+1);

                if(!isAdmin())profile.coins+=c.reward.coins;

                if(c.reward.gems)addGems(c.reward.gems);

                profile.xp+=c.reward.xp;

                rw="Hadiah: +"+c.reward.coins+" 🪙"+(c.reward.gems?"  +"+c.reward.gems+" 💎":"")+"  +"+c.reward.xp+" XP";

            }
            else rw="Bab ini sudah pernah selesai (tanpa hadiah lagi).";

            saveProfile();

        }

        playDialog({title:"📖 Bab "+(stCur+1)+" • "+c.t,bg:c.bg},win?c.win:c.lose,()=>stResult(win,rw));

    }

    function stResult(win,rw){

        const c=STORY[stCur];

        const last=stCur>=STORY.length-1;

        $("rrIcon").textContent=win?(last?"🏆":"✅"):"💀";
        $("rrTitle").textContent=win?(last?"TAMAT!":"BAB SELESAI!"):"KALAH";
        $("rrText").textContent=win
            ?(last?"Tony menjadi Orang Terkuat. Terima kasih sudah memainkan Story!":"Kamu mengalahkan "+((LORE[c.foe]||{}).who||c.foe)+".")
            :"Tony belum menyerah. Coba lagi!";
        $("rrReward").textContent=rw||"";

        const b1=$("rrBtn1");
        const b2=$("rrBtn2");

        b2.style.display="";

        if(win&&!last){
            b1.textContent="Bab Berikutnya ▶";
            b1.onclick=()=>{cleanup();startChapter(stCur+1);};
        }
        else if(win){
            b1.textContent="📖 Daftar Bab";
            b1.onclick=()=>{cleanup();openStory();};
        }
        else{
            b1.textContent="🔁 Coba Lagi";
            b1.onclick=beginStory;
        }

        b2.textContent=win&&!last?"📖 Daftar Bab":"🏠 Menu";
        b2.onclick=win&&!last?()=>{cleanup();openStory();}:showMenu;

        show("rankResult");

    }


    /* ==================================================
       GLOBAL v0.10: TAUTAN PANEL ADMIN
       (maintenance, pengumuman, hadiah, pesan/top up)
    ================================================== */

    let admCfg=null;
    let maintPeek=false;

    function admEsc(t){
        return String(t==null?"":t).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
    }

    function admToast(t){

        const el=document.createElement("div");

        el.className="admToast";
        el.textContent=t;

        document.body.appendChild(el);

        setTimeout(()=>el.remove(),4200);

    }

    function admLogged(){
        return !!(window.currentUser||window.currentIsGuest);
    }

    function admApply(){

        const s=(admCfg&&admCfg.status)||{};

        const logged=admLogged();

        const adm=logged&&isAdmin();

        const on=!!s.maintenance;

        const showM=on&&!adm&&!(maintPeek&&!logged);

        $("maint").style.display=showM?"flex":"none";

        $("maintMsg").textContent=s.message||"Kami sedang memperbaiki dan memperbarui game. Coba lagi beberapa saat lagi ya.";

        /* pengumuman: tampil sekali per pengumuman */

        const aid=String(s.announce_id||"");

        let seen="";

        try{seen=localStorage.getItem("tds_ann_seen")||"";}catch(e){}

        const bar=$("annBar");

        if(s.announce&&aid&&aid!==seen&&!showM){
            $("annText").textContent=s.announce;
            bar.style.display="flex";
            bar.dataset.id=aid;
        }
        else bar.style.display="none";

    }

    async function admPoll(){

        if(!TDSOnline.enabled())return;

        const r=await TDSOnline.config();

        if(!r.ok)return;

        admCfg=r.cfg;

        admApply();

    }

    $("annClose").onclick=()=>{
        try{localStorage.setItem("tds_ann_seen",$("annBar").dataset.id||"");}catch(e){}
        $("annBar").style.display="none";
    };

    $("maintRetry").onclick=async()=>{
        $("maintRetry").textContent="Memeriksa…";
        await admPoll();
        $("maintRetry").textContent="🔄 Cek lagi";
    };

    $("maintAdmin").onclick=()=>{
        maintPeek=true;
        admApply();
    };

    setInterval(admApply,3000);

    setInterval(admPoll,45000);

    setTimeout(admPoll,1200);

    document.addEventListener("visibilitychange",()=>{
        if(!document.hidden)admPoll();
    });

    /* ---------- HADIAH DARI ADMIN -> INBOX ---------- */

    async function admSyncGifts(){

        if(!profile||window.currentIsGuest||!window.currentUser||!TDSOnline.enabled()||!profile.uid)return;

        const r=await TDSOnline.api("/rest/v1/admin_gifts?select=id,title,body,coins,gems,created_at&uid=eq."+encodeURIComponent(profile.uid)+"&order=created_at.asc&limit=50");

        if(!r.ok||!Array.isArray(r.json))return;

        let n=0;

        r.json.forEach(g=>{

            const id="ag_"+g.id;

            if(profile.agSeen.includes(id))return;

            profile.agSeen.push(id);

            let d="";

            try{d=new Date(g.created_at).toLocaleDateString("id-ID",{day:"numeric",month:"short",year:"numeric"});}catch(e){}

            profile.inbox.push({
                id:id,
                title:"🎁 "+admEsc(g.title),
                date:d,
                body:admEsc(g.body),
                coins:Math.max(0,Math.min(1000000,Math.floor(Number(g.coins)||0))),
                gems:Math.max(0,Math.min(100000,Math.floor(Number(g.gems)||0))),
                claimed:false
            });

            n++;

        });

        if(n){

            profile.agSeen=profile.agSeen.slice(-300);

            saveProfile();

            updateInbBadge();

            admToast("🎁 Kamu mendapat hadiah dari admin! Cek Inbox.");

        }

    }

    /* ---------- PESAN ADMIN (DM / TOP UP) ---------- */

    let admKind="chat";

    let admThreadT=0;

    function admSeenKey(){
        return "tds_adm_seen_"+(profile&&profile.uid||"");
    }

    function admSeen(){
        try{return Number(localStorage.getItem(admSeenKey()))||0;}catch(e){return 0;}
    }

    function admSetSeen(n){
        try{localStorage.setItem(admSeenKey(),String(n));}catch(e){}
    }

    function admBadge(n){
        const b=$("admBadge");
        if(!b)return;
        b.style.display=n>0?"inline-block":"none";
        b.textContent=n;
    }

    async function admFetchThread(){

        if(!profile||!profile.uid)return null;

        const r=await TDSOnline.api("/rest/v1/messages?select=id,from_admin,kind,body,created_at&uid=eq."+encodeURIComponent(profile.uid)+"&order=created_at.asc&limit=100");

        if(!r.ok||!Array.isArray(r.json))return null;

        return r.json;

    }

    function admRenderThread(rows){

        const box=$("admThread");

        if(!rows.length){
            box.innerHTML='<p class="sub" style="padding:18px 6px">Belum ada pesan. Tulis pesan pertamamu di bawah.</p>';
            return;
        }

        box.innerHTML="";

        rows.forEach(m=>{

            const d=document.createElement("div");

            d.className="admMsg "+(m.from_admin?"fromA":"fromP");

            const b=document.createElement("div");

            b.textContent=m.body;

            d.appendChild(b);

            const t=document.createElement("small");

            let when="";

            try{when=new Date(m.created_at).toLocaleString("id-ID",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"});}catch(e){}

            t.textContent=(m.from_admin?"👑 Admin • ":(m.kind==="topup"?"💳 Top Up • ":""))+when;

            d.appendChild(t);

            box.appendChild(d);

        });

        box.scrollTop=box.scrollHeight;

    }

    async function admOpenThread(){

        const rows=await admFetchThread();

        if(!rows){
            $("admSub").textContent="⚠️ Tidak bisa memuat pesan. Cek koneksi internetmu.";
            return;
        }

        $("admSub").textContent="Tanya, lapor bug, atau top up koin/💎";

        admRenderThread(rows);

        const mx=rows.filter(m=>m.from_admin).reduce((a,m)=>Math.max(a,m.id),0);

        if(mx>admSeen())admSetSeen(mx);

        admBadge(0);

    }

    function admOpen(){

        audio();

        if(window.currentIsGuest||!window.currentUser||!TDSOnline.enabled()){
            admToast("Fitur ini butuh akun online (bukan Tamu).");
            return;
        }

        const tp=(admCfg&&admCfg.topup&&admCfg.topup.text)||"";

        $("admTopup").style.display=tp?"block":"none";
        $("admTopup").textContent=tp;

        show("admScr");

        $("admThread").innerHTML='<p class="sub" style="padding:18px 6px">Memuat…</p>';

        admOpenThread();

        clearInterval(admThreadT);

        admThreadT=setInterval(()=>{
            if($("admScr").style.display==="flex")admOpenThread();
            else clearInterval(admThreadT);
        },9000);

    }

    $("inbAdmin").onclick=admOpen;

    $("admBack").onclick=()=>{
        clearInterval(admThreadT);
        renderInbox();
        show("inboxScr");
    };

    function admSetKind(k){
        admKind=k;
        $("admKChat").classList.toggle("on",k==="chat");
        $("admKTop").classList.toggle("on",k==="topup");
        $("admIn").placeholder=k==="topup"
            ?"Contoh: Mau top up 1000 koin, bayar lewat DANA"
            :"Tulis pesan untuk admin…";
    }

    $("admKChat").onclick=()=>admSetKind("chat");
    $("admKTop").onclick=()=>admSetKind("topup");

    let admSending=false;

    $("admSend").onclick=async()=>{

        if(admSending)return;

        const t=$("admIn").value.trim();

        if(!t)return;

        if(!profile||!profile.uid||!window.currentUser)return;

        admSending=true;

        $("admSend").textContent="Mengirim…";

        const r=await TDSOnline.api("/rest/v1/messages",{
            method:"POST",
            headers:{"Prefer":"return=minimal"},
            body:{uid:profile.uid,username:window.currentUser,body:t.slice(0,500),kind:admKind}
        });

        admSending=false;

        $("admSend").textContent="Kirim";

        if(r.ok){
            $("admIn").value="";
            admOpenThread();
        }
        else{
            const m=String((r.json&&(r.json.message||r.json.msg))||"");
            admToast(m.toLowerCase().includes("terlalu banyak")?"Terlalu banyak pesan. Tunggu beberapa menit.":"Gagal mengirim. Coba lagi.");
        }

    };

    async function admBg(){

        if(!profile||window.currentIsGuest||!window.currentUser||!TDSOnline.enabled())return;

        await admSyncGifts();

        if($("admScr").style.display==="flex")return;

        const rows=await admFetchThread();

        if(!rows)return;

        const seen=admSeen();

        const n=rows.filter(m=>m.from_admin&&m.id>seen).length;

        if(n>0&&n!==admBg.last){
            admToast("💬 Admin membalas pesanmu. Buka Inbox → Hubungi Admin.");
        }

        admBg.last=n;

        admBadge(n);

    }

    admBg.last=0;

    setInterval(admBg,60000);

    setTimeout(admBg,7000);


    /* ---------- v1.9: ONLINE (PERINGKAT & STATUS CLOUD) ---------- */

    function cloudTagRender(){

        const t=$("cloudTag");

        if(!t)return;

        const on=window.TDSOnline&&TDSOnline.enabled()&&!window.currentIsGuest&&!isAdmin();

        if(!on){t.style.display="none";return;}

        const s=TDSOnline.status();

        t.style.display="block";

        t.className="cloudTag "+(s==="offline"?"off":"ok");

        t.textContent=s==="saving"?"☁️ Menyimpan…":(s==="offline"?"📴 Offline • tersimpan di HP":"☁️ Online • tersimpan");

    }

    if(window.TDSOnline){

        TDSOnline.onStatus(cloudTagRender);

        TDSOnline.onUid=(n,u)=>{
            if(profile&&String(window.currentUser||"").toLowerCase()===String(n).toLowerCase()){
                profile.uid=u;
                st.set(pkey(),JSON.stringify(profile));
            }
        };

        TDSOnline.onRemoteApplied=()=>{
            if(profile&&$("menu").style.display==="flex")showMenu();
        };

    }

    function esc(t){
        return String(t).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
    }

    async function renderLb(){

        const sub=$("lbSub");

        const list=$("lbList");

        if(!window.TDSOnline||!TDSOnline.enabled()){
            sub.textContent="Mode online belum diaktifkan.";
            list.innerHTML='<p class="sub" style="padding:18px 0">Peringkat butuh server online. Lihat panduan SUPABASE_SETUP.md untuk mengaktifkannya.</p>';
            return;
        }

        sub.textContent="Memuat peringkat…";

        list.innerHTML="";

        const r=await TDSOnline.board();

        if(!r.ok){
            sub.textContent="Gagal memuat.";
            list.innerHTML='<p class="sub" style="padding:18px 0">'+(r.net?"Tidak ada koneksi internet.":"Server belum siap. Pastikan SQL setup sudah dijalankan.")+'</p>';
            return;
        }

        const me=String(window.currentUser||"").toLowerCase();

        sub.textContent="Top "+r.rows.length+" pemain • urut rank";

        if(!r.rows.length){
            list.innerHTML='<p class="sub" style="padding:18px 0">Belum ada pemain di peringkat.</p>';
            return;
        }

        let h="";

        r.rows.forEach((x,i)=>{

            const isMe=!window.currentIsGuest&&String(x.username).toLowerCase()===me;

            h+='<div class="lbRow'+(i<3?" t"+(i+1):"")+(isMe?" me":"")+'">'
                +'<span class="n">'+(i===0?"🥇":i===1?"🥈":i===2?"🥉":(i+1))+'</span>'
                +'<span class="u">'+esc(x.username)+(isMe?" (kamu)":"")+'</span>'
                +'<span class="r">'+rankText(Number(x.rp)||0)+'</span>'
                +'</div>';

        });

        list.innerHTML=h;

    }

    $("btnLb").onclick=()=>{
        audio();
        show("lbScr");
        renderLb();
    };

    $("lbRefresh").onclick=renderLb;

    /* ---------- CARI PEMAIN (GLOBAL v0.05) ---------- */

    let srchRows=[];

    function srchOpen(){
        audio();
        $("srchList").innerHTML="";
        $("srchSub").textContent="Cari lewat ID (5 digit) atau nickname.";
        show("srchScr");
    }

    async function srchRun(){

        const q=$("srchIn").value.trim();

        const sub=$("srchSub");

        const list=$("srchList");

        if(!window.TDSOnline||!TDSOnline.enabled()){
            sub.textContent="Mode online belum diaktifkan.";
            return;
        }

        sub.textContent="Mencari…";

        list.innerHTML="";

        const r=await TDSOnline.search(q);

        if(!r.ok){
            sub.textContent=r.bad
                ?"Isi 5 digit ID, atau nickname (2–16 huruf/angka/_)."
                :r.net
                    ?"Tidak ada koneksi internet."
                    :"Server belum diperbarui. Jalankan SQL update v0.05 di Supabase.";
            return;
        }

        srchRows=r.rows;

        if(!r.rows.length){
            sub.textContent="Pemain tidak ditemukan.";
            return;
        }

        sub.textContent=r.rows.length+" pemain ditemukan • ketuk untuk melihat profil";

        list.innerHTML=r.rows.map((x,i)=>
            '<div class="lbRow srchRowItem" data-i="'+i+'" style="cursor:pointer">'
            +'<span class="n">'+esc(x.username).charAt(0).toUpperCase()+'</span>'
            +'<span class="u">'+esc(x.username)+'<small style="display:block;color:#9fb0d3;font-size:11px">ID #'+esc(x.uid||"-")+' • Lv '+levelOf(Number(x.xp)||0)+'</small></span>'
            +'<span class="r">'+rankText(Number(x.peak)||0)+'</span>'
            +'</div>'
        ).join("");

        list.querySelectorAll(".srchRowItem").forEach(el=>{
            el.onclick=()=>srchDetail(srchRows[Number(el.dataset.i)]);
        });

    }

    function srchDetail(x){

        if(!x)return;

        const name=String(x.username||"?");

        $("sbAvatar").textContent=name.charAt(0).toUpperCase();
        $("sbName").textContent=name;
        $("sbLvl").textContent="Level "+levelOf(Number(x.xp)||0);
        $("sbUid").textContent="#"+(x.uid||"-");
        $("sbPeak").textContent=rankText(Math.max(Number(x.peak)||0,Number(x.rp)||0));
        $("sbBio").textContent=String(x.bio||"").trim()||"(belum ada bio)";

        $("srchBox").style.display="flex";

    }

    $("lbSearch").onclick=srchOpen;
    $("srchGo").onclick=srchRun;
    $("srchIn").addEventListener("keydown",e=>{if(e.key==="Enter")srchRun();});
    $("srchBack").onclick=()=>{show("lbScr");renderLb();};
    $("sbClose").onclick=()=>{$("srchBox").style.display="none";};

    $("lbBack").onclick=showMenu;

    /* ---------- PATCH NOTE ---------- */

    const GAME_VERSION="Global v1.01";

    const PATCHES=[
        {v:"Global v1.01",date:"18 Nov 2026",title:"Mana & Arcade Penuh Hitungan",cur:true,groups:[
            {t:"new",l:"🔷 Mekanik Mana",i:["Semua skill aktif sekarang memakai mana. Mana maksimal 100, regen 5 tiap 2 detik.","Skill aktif memakai 60 mana, Dead memakai 100 mana (langsung habis).","Walau cooldown sudah selesai, skill tidak bisa dipakai kalau mana kurang. Berlaku juga untuk bot dan lawan.","Bar mana tampil di bawah tombol skill dan di bawah bar HP karakter."]},
            {t:"new",l:"🃏 Mode Arcade Lebih Sulit",i:["Tiap kartu punya biaya mana. Mana maks 100, +30 tiap giliran. Attack/Magic dibayar saat dimainkan, Defense dibayar saat dipakai.","Momentum: kartu Magic lalu Attack berikutnya +20 damage.","Lewati giliran jadi Fokus: +30 mana.","Lawan punya HP 220 dan AI baru yang menghitung mana, damage, dan kapan bertahan.","Pilih Deck menampilkan total dan rata-rata biaya kartu."]}
        ]},
        {v:"Global v1.00",date:"14 Nov 2026",title:"Set Edit Premium & FPS Show",groups:[
            {t:"new",l:"💎 Set Edit Premium",i:["Di Pengaturan, HP kentang bisa disimulasikan jadi chipset dan RAM pilihan (contoh: Snapdragon 8 Elite Gen 5 + 8GB) untuk membuka semua grafis.","Hanya tersedia di HP dengan RAM 4GB ke atas. Mode Lite ikut terlepas saat Premium aktif."]},
            {t:"new",l:"📊 FPS Show",i:["Opsi baru untuk menampilkan FPS game di pojok kanan atas supaya bisa dipantau saat bermain."]},
            {t:"new",l:"✨ Animasi Lebih Halus",i:["Pergerakan lebih stabil saat ada lonjakan frame.","Penjaga performa otomatis mengurangi partikel saat FPS turun, lalu menaikkannya lagi saat lancar.","Transisi layar dan menu lebih mulus."]}
        ]},
        {v:"Global v0.10",date:"12 Nov 2026",title:"Tautan Panel Admin",groups:[
            {t:"new",l:"🛠️ Maintenance & Pengumuman",i:["Admin bisa mengaktifkan mode Maintenance langsung dari panel. Saat aktif, pemain melihat layar SEDANG MAINTENANCE.","Pengumuman dari admin muncul sebagai banner di atas layar."]},
            {t:"new",l:"💬 Hubungi Admin",i:["Tombol baru di Inbox untuk mengirim pesan ke admin, termasuk permintaan Top Up.","Balasan admin muncul di layar yang sama, dengan notifikasi saat ada balasan baru."]},
            {t:"new",l:"🎁 Hadiah Admin",i:["Koin dan 💎 dari admin masuk ke Inbox dan bisa diklaim."]}
        ]},
        {v:"Global v0.09",date:"12 Nov 2026",title:"Grafik Lebih Halus & Lock FPS",groups:[
            {t:"new",l:"🖼️ Grafik",i:["Pilihan resolusi baru: Full HD, 2K, dan 4K (butuh grafis High, Very High, atau Ultra).","Efek lebih detail: bayangan kontak halus di bawah karakter.","Warna dibuat lebih kalem: kecerahan dan kontras diturunkan, cahaya dan partikel dikurangi.","Animasi lebih halus: lonjakan waktu antar-frame diratakan agar gerakan tidak tersendat."]},
            {t:"new",l:"🎚️ Lock FPS",i:["Pengaturan baru: Lock FPS dengan slider 30 sampai 60. Di luar rentang itu tidak bisa dipilih."]},
            {t:"eco",l:"📵 Spesifikasi Minimum",i:["Saat awal login, game mengecek chipset HP. HP kelas Helio P22 ke bawah otomatis masuk Mode Lite: grafis Kentang dan 30 FPS, dikunci dan tidak bisa diubah."]}
        ]},
        {v:"Global v0.08",date:"11 Nov 2026",title:"Update Besar: Mode Story",groups:[
            {t:"new",l:"📖 Mode Story",i:["Cerita baru: di dunia ini semua orang punya skill, kecuali Tony. Ikuti perjalanannya mengalahkan semua skill.","10 bab dengan dialog beranimasi: karakter bergerak saat bicara, ekspresi, efek layar, dan suara ketik.","Tiap bab ditutup duel melawan pemilik skill. Hadiah koin, 💎 dan XP saat pertama menamatkan bab. Progres tersimpan di akun."]},
            {t:"buff",l:"⏱️ CD Awal Pertandingan",i:["Skill kini mulai dari CD aslinya di awal laga (misal Time 13 detik), tidak langsung bisa dipakai."]},
            {t:"nerf",l:"⏳ Time",i:["Damage tembakan beruntun 25 → 10.","Lama waktu berhenti 2 → 1,2 detik.","CD 20 → 13 detik."]},
            {t:"eco",l:"🥔 Optimasi HP Kentang",i:["Mode Hemat baru di Pengaturan: resolusi turun, efek berat dimatikan, 30 FPS. Aktif otomatis di HP lemah.","Efek es, pecahan kartu, dan animasi menu dibuat lebih ringan."]}
        ]}
    ];

    function renderPatch(){

        $("pnCur").textContent="Versi saat ini: "+GAME_VERSION;

        let h="";

        PATCHES.forEach(p=>{

            h+='<div class="pnVer'+(p.cur?" cur":"")+'"><div class="pnHead"><b>'+p.v+(p.cur?" • TERBARU":"")+'</b><small>'+p.date+'</small></div>'
                +'<div style="font-weight:800;margin:2px 0 4px">'+p.title+'</div>';

            p.groups.forEach(g=>{
                h+='<div class="pnTag '+g.t+'">'+g.l+'</div><ul>'+g.i.map(x=>"<li>"+x+"</li>").join("")+'</ul>';
            });

            h+='</div>';

        });

        $("pnList").innerHTML=h;

    }

    $("btnPatch").onclick=()=>{
        audio();
        renderPatch();
        show("patchScr");
    };

    $("patchBack").onclick=showMenu;

    applySettings();

    window.TDS={
        showMenu:showMenu,
        reset:function(){
            cleanup();
            closeBuy();
            $("calBox").style.display="none";
            $("settings").style.display="none";
            $("profileBox").style.display="none";
            hideScreens();
            profile=null;
        }
    };

})();
