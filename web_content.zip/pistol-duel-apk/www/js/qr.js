
/* QR encoder: Kazuhiko Arase (MIT license) */
var QRLib=(function(){
var __m={},__f={};
function __req(n){n=n.replace('./','');if(!__m[n]){var mod={exports:{}};__f[n](mod,mod.exports,__req);__m[n]=mod.exports;}return __m[n];}
__f['QRMode']=function(module,exports,require){
module.exports = {
    MODE_NUMBER :       1 << 0,
    MODE_ALPHA_NUM :    1 << 1,
    MODE_8BIT_BYTE :    1 << 2,
    MODE_KANJI :        1 << 3
};

};
__f['QRErrorCorrectLevel']=function(module,exports,require){
module.exports = {
	L : 1,
	M : 0,
	Q : 3,
	H : 2
};


};
__f['QRMaskPattern']=function(module,exports,require){
module.exports = {
	PATTERN000 : 0,
	PATTERN001 : 1,
	PATTERN010 : 2,
	PATTERN011 : 3,
	PATTERN100 : 4,
	PATTERN101 : 5,
	PATTERN110 : 6,
	PATTERN111 : 7
};

};
__f['QRMath']=function(module,exports,require){
var QRMath = {

	glog : function(n) {
	
		if (n < 1) {
			throw new Error("glog(" + n + ")");
		}
		
		return QRMath.LOG_TABLE[n];
	},
	
	gexp : function(n) {
	
		while (n < 0) {
			n += 255;
		}
	
		while (n >= 256) {
			n -= 255;
		}
	
		return QRMath.EXP_TABLE[n];
	},
	
	EXP_TABLE : new Array(256),
	
	LOG_TABLE : new Array(256)

};
	
for (var i = 0; i < 8; i++) {
	QRMath.EXP_TABLE[i] = 1 << i;
}
for (var i = 8; i < 256; i++) {
	QRMath.EXP_TABLE[i] = QRMath.EXP_TABLE[i - 4]
		^ QRMath.EXP_TABLE[i - 5]
		^ QRMath.EXP_TABLE[i - 6]
		^ QRMath.EXP_TABLE[i - 8];
}
for (var i = 0; i < 255; i++) {
	QRMath.LOG_TABLE[QRMath.EXP_TABLE[i] ] = i;
}

module.exports = QRMath;

};
__f['QRPolynomial']=function(module,exports,require){
var QRMath = require('./QRMath');

function QRPolynomial(num, shift) {
	if (num.length === undefined) {
		throw new Error(num.length + "/" + shift);
	}

	var offset = 0;

	while (offset < num.length && num[offset] === 0) {
		offset++;
	}

	this.num = new Array(num.length - offset + shift);
	for (var i = 0; i < num.length - offset; i++) {
		this.num[i] = num[i + offset];
	}
}

QRPolynomial.prototype = {

	get : function(index) {
		return this.num[index];
	},
	
	getLength : function() {
		return this.num.length;
	},
	
	multiply : function(e) {
	
		var num = new Array(this.getLength() + e.getLength() - 1);
	
		for (var i = 0; i < this.getLength(); i++) {
			for (var j = 0; j < e.getLength(); j++) {
				num[i + j] ^= QRMath.gexp(QRMath.glog(this.get(i) ) + QRMath.glog(e.get(j) ) );
			}
		}
	
		return new QRPolynomial(num, 0);
	},
	
	mod : function(e) {
	
		if (this.getLength() - e.getLength() < 0) {
			return this;
		}
	
		var ratio = QRMath.glog(this.get(0) ) - QRMath.glog(e.get(0) );
	
		var num = new Array(this.getLength() );
		
		for (var i = 0; i < this.getLength(); i++) {
			num[i] = this.get(i);
		}
		
		for (var x = 0; x < e.getLength(); x++) {
			num[x] ^= QRMath.gexp(QRMath.glog(e.get(x) ) + ratio);
		}
	
		// recursive call
		return new QRPolynomial(num, 0).mod(e);
	}
};

module.exports = QRPolynomial;

};
__f['QRUtil']=function(module,exports,require){
var QRMode = require('./QRMode');
var QRPolynomial = require('./QRPolynomial');
var QRMath = require('./QRMath');
var QRMaskPattern = require('./QRMaskPattern');

var QRUtil = {

    PATTERN_POSITION_TABLE : [
        [],
        [6, 18],
        [6, 22],
        [6, 26],
        [6, 30],
        [6, 34],
        [6, 22, 38],
        [6, 24, 42],
        [6, 26, 46],
        [6, 28, 50],
        [6, 30, 54],        
        [6, 32, 58],
        [6, 34, 62],
        [6, 26, 46, 66],
        [6, 26, 48, 70],
        [6, 26, 50, 74],
        [6, 30, 54, 78],
        [6, 30, 56, 82],
        [6, 30, 58, 86],
        [6, 34, 62, 90],
        [6, 28, 50, 72, 94],
        [6, 26, 50, 74, 98],
        [6, 30, 54, 78, 102],
        [6, 28, 54, 80, 106],
        [6, 32, 58, 84, 110],
        [6, 30, 58, 86, 114],
        [6, 34, 62, 90, 118],
        [6, 26, 50, 74, 98, 122],
        [6, 30, 54, 78, 102, 126],
        [6, 26, 52, 78, 104, 130],
        [6, 30, 56, 82, 108, 134],
        [6, 34, 60, 86, 112, 138],
        [6, 30, 58, 86, 114, 142],
        [6, 34, 62, 90, 118, 146],
        [6, 30, 54, 78, 102, 126, 150],
        [6, 24, 50, 76, 102, 128, 154],
        [6, 28, 54, 80, 106, 132, 158],
        [6, 32, 58, 84, 110, 136, 162],
        [6, 26, 54, 82, 110, 138, 166],
        [6, 30, 58, 86, 114, 142, 170]
    ],

    G15 : (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0),
    G18 : (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0),
    G15_MASK : (1 << 14) | (1 << 12) | (1 << 10)    | (1 << 4) | (1 << 1),

    getBCHTypeInfo : function(data) {
        var d = data << 10;
        while (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G15) >= 0) {
            d ^= (QRUtil.G15 << (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G15) ) );    
        }
        return ( (data << 10) | d) ^ QRUtil.G15_MASK;
    },

    getBCHTypeNumber : function(data) {
        var d = data << 12;
        while (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G18) >= 0) {
            d ^= (QRUtil.G18 << (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G18) ) );    
        }
        return (data << 12) | d;
    },

    getBCHDigit : function(data) {

        var digit = 0;

        while (data !== 0) {
            digit++;
            data >>>= 1;
        }

        return digit;
    },

    getPatternPosition : function(typeNumber) {
        return QRUtil.PATTERN_POSITION_TABLE[typeNumber - 1];
    },

    getMask : function(maskPattern, i, j) {
        
        switch (maskPattern) {
            
        case QRMaskPattern.PATTERN000 : return (i + j) % 2 === 0;
        case QRMaskPattern.PATTERN001 : return i % 2 === 0;
        case QRMaskPattern.PATTERN010 : return j % 3 === 0;
        case QRMaskPattern.PATTERN011 : return (i + j) % 3 === 0;
        case QRMaskPattern.PATTERN100 : return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 === 0;
        case QRMaskPattern.PATTERN101 : return (i * j) % 2 + (i * j) % 3 === 0;
        case QRMaskPattern.PATTERN110 : return ( (i * j) % 2 + (i * j) % 3) % 2 === 0;
        case QRMaskPattern.PATTERN111 : return ( (i * j) % 3 + (i + j) % 2) % 2 === 0;

        default :
            throw new Error("bad maskPattern:" + maskPattern);
        }
    },

    getErrorCorrectPolynomial : function(errorCorrectLength) {

        var a = new QRPolynomial([1], 0);

        for (var i = 0; i < errorCorrectLength; i++) {
            a = a.multiply(new QRPolynomial([1, QRMath.gexp(i)], 0) );
        }

        return a;
    },

    getLengthInBits : function(mode, type) {

        if (1 <= type && type < 10) {

            // 1 - 9

            switch(mode) {
            case QRMode.MODE_NUMBER     : return 10;
            case QRMode.MODE_ALPHA_NUM  : return 9;
            case QRMode.MODE_8BIT_BYTE  : return 8;
            case QRMode.MODE_KANJI      : return 8;
            default :
                throw new Error("mode:" + mode);
            }

        } else if (type < 27) {

            // 10 - 26

            switch(mode) {
            case QRMode.MODE_NUMBER     : return 12;
            case QRMode.MODE_ALPHA_NUM  : return 11;
            case QRMode.MODE_8BIT_BYTE  : return 16;
            case QRMode.MODE_KANJI      : return 10;
            default :
                throw new Error("mode:" + mode);
            }

        } else if (type < 41) {

            // 27 - 40

            switch(mode) {
            case QRMode.MODE_NUMBER     : return 14;
            case QRMode.MODE_ALPHA_NUM  : return 13;
            case QRMode.MODE_8BIT_BYTE  : return 16;
            case QRMode.MODE_KANJI      : return 12;
            default :
                throw new Error("mode:" + mode);
            }

        } else {
            throw new Error("type:" + type);
        }
    },

    getLostPoint : function(qrCode) {
        
        var moduleCount = qrCode.getModuleCount();
        var lostPoint = 0;
        var row = 0; 
        var col = 0;

        
        // LEVEL1
        
        for (row = 0; row < moduleCount; row++) {

            for (col = 0; col < moduleCount; col++) {

                var sameCount = 0;
                var dark = qrCode.isDark(row, col);

                for (var r = -1; r <= 1; r++) {

                    if (row + r < 0 || moduleCount <= row + r) {
                        continue;
                    }

                    for (var c = -1; c <= 1; c++) {

                        if (col + c < 0 || moduleCount <= col + c) {
                            continue;
                        }

                        if (r === 0 && c === 0) {
                            continue;
                        }

                        if (dark === qrCode.isDark(row + r, col + c) ) {
                            sameCount++;
                        }
                    }
                }

                if (sameCount > 5) {
                    lostPoint += (3 + sameCount - 5);
                }
            }
        }

        // LEVEL2

        for (row = 0; row < moduleCount - 1; row++) {
            for (col = 0; col < moduleCount - 1; col++) {
                var count = 0;
                if (qrCode.isDark(row,     col    ) ) count++;
                if (qrCode.isDark(row + 1, col    ) ) count++;
                if (qrCode.isDark(row,     col + 1) ) count++;
                if (qrCode.isDark(row + 1, col + 1) ) count++;
                if (count === 0 || count === 4) {
                    lostPoint += 3;
                }
            }
        }

        // LEVEL3

        for (row = 0; row < moduleCount; row++) {
            for (col = 0; col < moduleCount - 6; col++) {
                if (qrCode.isDark(row, col) && 
                        !qrCode.isDark(row, col + 1) && 
                         qrCode.isDark(row, col + 2) && 
                         qrCode.isDark(row, col + 3) && 
                         qrCode.isDark(row, col + 4) && 
                        !qrCode.isDark(row, col + 5) && 
                         qrCode.isDark(row, col + 6) ) {
                    lostPoint += 40;
                }
            }
        }

        for (col = 0; col < moduleCount; col++) {
            for (row = 0; row < moduleCount - 6; row++) {
                if (qrCode.isDark(row, col) &&
                        !qrCode.isDark(row + 1, col) &&
                         qrCode.isDark(row + 2, col) &&
                         qrCode.isDark(row + 3, col) &&
                         qrCode.isDark(row + 4, col) &&
                        !qrCode.isDark(row + 5, col) &&
                         qrCode.isDark(row + 6, col) ) {
                    lostPoint += 40;
                }
            }
        }

        // LEVEL4
        
        var darkCount = 0;

        for (col = 0; col < moduleCount; col++) {
            for (row = 0; row < moduleCount; row++) {
                if (qrCode.isDark(row, col) ) {
                    darkCount++;
                }
            }
        }
        
        var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
        lostPoint += ratio * 10;

        return lostPoint;       
    }

};

module.exports = QRUtil;

};
__f['QRRSBlock']=function(module,exports,require){
var QRErrorCorrectLevel = require('./QRErrorCorrectLevel');

function QRRSBlock(totalCount, dataCount) {
	this.totalCount = totalCount;
	this.dataCount  = dataCount;
}

QRRSBlock.RS_BLOCK_TABLE = [

	// L
	// M
	// Q
	// H

	// 1
	[1, 26, 19],
	[1, 26, 16],
	[1, 26, 13],
	[1, 26, 9],
	
	// 2
	[1, 44, 34],
	[1, 44, 28],
	[1, 44, 22],
	[1, 44, 16],

	// 3
	[1, 70, 55],
	[1, 70, 44],
	[2, 35, 17],
	[2, 35, 13],

	// 4		
	[1, 100, 80],
	[2, 50, 32],
	[2, 50, 24],
	[4, 25, 9],
	
	// 5
	[1, 134, 108],
	[2, 67, 43],
	[2, 33, 15, 2, 34, 16],
	[2, 33, 11, 2, 34, 12],
	
	// 6
	[2, 86, 68],
	[4, 43, 27],
	[4, 43, 19],
	[4, 43, 15],
	
	// 7		
	[2, 98, 78],
	[4, 49, 31],
	[2, 32, 14, 4, 33, 15],
	[4, 39, 13, 1, 40, 14],
	
	// 8
	[2, 121, 97],
	[2, 60, 38, 2, 61, 39],
	[4, 40, 18, 2, 41, 19],
	[4, 40, 14, 2, 41, 15],
	
	// 9
	[2, 146, 116],
	[3, 58, 36, 2, 59, 37],
	[4, 36, 16, 4, 37, 17],
	[4, 36, 12, 4, 37, 13],
	
	// 10		
	[2, 86, 68, 2, 87, 69],
	[4, 69, 43, 1, 70, 44],
	[6, 43, 19, 2, 44, 20],
	[6, 43, 15, 2, 44, 16],

	// 11
	[4, 101, 81],
	[1, 80, 50, 4, 81, 51],
	[4, 50, 22, 4, 51, 23],
	[3, 36, 12, 8, 37, 13],

	// 12
	[2, 116, 92, 2, 117, 93],
	[6, 58, 36, 2, 59, 37],
	[4, 46, 20, 6, 47, 21],
	[7, 42, 14, 4, 43, 15],

	// 13
	[4, 133, 107],
	[8, 59, 37, 1, 60, 38],
	[8, 44, 20, 4, 45, 21],
	[12, 33, 11, 4, 34, 12],

	// 14
	[3, 145, 115, 1, 146, 116],
	[4, 64, 40, 5, 65, 41],
	[11, 36, 16, 5, 37, 17],
	[11, 36, 12, 5, 37, 13],

	// 15
	[5, 109, 87, 1, 110, 88],
	[5, 65, 41, 5, 66, 42],
	[5, 54, 24, 7, 55, 25],
	[11, 36, 12],

	// 16
	[5, 122, 98, 1, 123, 99],
	[7, 73, 45, 3, 74, 46],
	[15, 43, 19, 2, 44, 20],
	[3, 45, 15, 13, 46, 16],

	// 17
	[1, 135, 107, 5, 136, 108],
	[10, 74, 46, 1, 75, 47],
	[1, 50, 22, 15, 51, 23],
	[2, 42, 14, 17, 43, 15],

	// 18
	[5, 150, 120, 1, 151, 121],
	[9, 69, 43, 4, 70, 44],
	[17, 50, 22, 1, 51, 23],
	[2, 42, 14, 19, 43, 15],

	// 19
	[3, 141, 113, 4, 142, 114],
	[3, 70, 44, 11, 71, 45],
	[17, 47, 21, 4, 48, 22],
	[9, 39, 13, 16, 40, 14],

	// 20
	[3, 135, 107, 5, 136, 108],
	[3, 67, 41, 13, 68, 42],
	[15, 54, 24, 5, 55, 25],
	[15, 43, 15, 10, 44, 16],

	// 21
	[4, 144, 116, 4, 145, 117],
	[17, 68, 42],
	[17, 50, 22, 6, 51, 23],
	[19, 46, 16, 6, 47, 17],

	// 22
	[2, 139, 111, 7, 140, 112],
	[17, 74, 46],
	[7, 54, 24, 16, 55, 25],
	[34, 37, 13],

	// 23
	[4, 151, 121, 5, 152, 122],
	[4, 75, 47, 14, 76, 48],
	[11, 54, 24, 14, 55, 25],
	[16, 45, 15, 14, 46, 16],

	// 24
	[6, 147, 117, 4, 148, 118],
	[6, 73, 45, 14, 74, 46],
	[11, 54, 24, 16, 55, 25],
	[30, 46, 16, 2, 47, 17],

	// 25
	[8, 132, 106, 4, 133, 107],
	[8, 75, 47, 13, 76, 48],
	[7, 54, 24, 22, 55, 25],
	[22, 45, 15, 13, 46, 16],

	// 26
	[10, 142, 114, 2, 143, 115],
	[19, 74, 46, 4, 75, 47],
	[28, 50, 22, 6, 51, 23],
	[33, 46, 16, 4, 47, 17],

	// 27
	[8, 152, 122, 4, 153, 123],
	[22, 73, 45, 3, 74, 46],
	[8, 53, 23, 26, 54, 24],
	[12, 45, 15, 28, 46, 16],

	// 28
	[3, 147, 117, 10, 148, 118],
	[3, 73, 45, 23, 74, 46],
	[4, 54, 24, 31, 55, 25],
	[11, 45, 15, 31, 46, 16],

	// 29
	[7, 146, 116, 7, 147, 117],
	[21, 73, 45, 7, 74, 46],
	[1, 53, 23, 37, 54, 24],
	[19, 45, 15, 26, 46, 16],

	// 30
	[5, 145, 115, 10, 146, 116],
	[19, 75, 47, 10, 76, 48],
	[15, 54, 24, 25, 55, 25],
	[23, 45, 15, 25, 46, 16],

	// 31
	[13, 145, 115, 3, 146, 116],
	[2, 74, 46, 29, 75, 47],
	[42, 54, 24, 1, 55, 25],
	[23, 45, 15, 28, 46, 16],

	// 32
	[17, 145, 115],
	[10, 74, 46, 23, 75, 47],
	[10, 54, 24, 35, 55, 25],
	[19, 45, 15, 35, 46, 16],

	// 33
	[17, 145, 115, 1, 146, 116],
	[14, 74, 46, 21, 75, 47],
	[29, 54, 24, 19, 55, 25],
	[11, 45, 15, 46, 46, 16],

	// 34
	[13, 145, 115, 6, 146, 116],
	[14, 74, 46, 23, 75, 47],
	[44, 54, 24, 7, 55, 25],
	[59, 46, 16, 1, 47, 17],

	// 35
	[12, 151, 121, 7, 152, 122],
	[12, 75, 47, 26, 76, 48],
	[39, 54, 24, 14, 55, 25],
	[22, 45, 15, 41, 46, 16],

	// 36
	[6, 151, 121, 14, 152, 122],
	[6, 75, 47, 34, 76, 48],
	[46, 54, 24, 10, 55, 25],
	[2, 45, 15, 64, 46, 16],

	// 37
	[17, 152, 122, 4, 153, 123],
	[29, 74, 46, 14, 75, 47],
	[49, 54, 24, 10, 55, 25],
	[24, 45, 15, 46, 46, 16],

	// 38
	[4, 152, 122, 18, 153, 123],
	[13, 74, 46, 32, 75, 47],
	[48, 54, 24, 14, 55, 25],
	[42, 45, 15, 32, 46, 16],

	// 39
	[20, 147, 117, 4, 148, 118],
	[40, 75, 47, 7, 76, 48],
	[43, 54, 24, 22, 55, 25],
	[10, 45, 15, 67, 46, 16],

	// 40
	[19, 148, 118, 6, 149, 119],
	[18, 75, 47, 31, 76, 48],
	[34, 54, 24, 34, 55, 25],
	[20, 45, 15, 61, 46, 16]
];

QRRSBlock.getRSBlocks = function(typeNumber, errorCorrectLevel) {
	
	var rsBlock = QRRSBlock.getRsBlockTable(typeNumber, errorCorrectLevel);
	
	if (rsBlock === undefined) {
		throw new Error("bad rs block @ typeNumber:" + typeNumber + "/errorCorrectLevel:" + errorCorrectLevel);
	}

	var length = rsBlock.length / 3;
	
	var list = [];
	
	for (var i = 0; i < length; i++) {

		var count = rsBlock[i * 3 + 0];
		var totalCount = rsBlock[i * 3 + 1];
		var dataCount  = rsBlock[i * 3 + 2];

		for (var j = 0; j < count; j++) {
			list.push(new QRRSBlock(totalCount, dataCount) );	
		}
	}
	
	return list;
};

QRRSBlock.getRsBlockTable = function(typeNumber, errorCorrectLevel) {

	switch(errorCorrectLevel) {
	case QRErrorCorrectLevel.L :
		return QRRSBlock.RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
	case QRErrorCorrectLevel.M :
		return QRRSBlock.RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
	case QRErrorCorrectLevel.Q :
		return QRRSBlock.RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
	case QRErrorCorrectLevel.H :
		return QRRSBlock.RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
	default :
		return undefined;
	}
};

module.exports = QRRSBlock;

};
__f['QRBitBuffer']=function(module,exports,require){
function QRBitBuffer() {
	this.buffer = [];
	this.length = 0;
}

QRBitBuffer.prototype = {

	get : function(index) {
		var bufIndex = Math.floor(index / 8);
		return ( (this.buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
	},
	
	put : function(num, length) {
		for (var i = 0; i < length; i++) {
			this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
		}
	},
	
	getLengthInBits : function() {
		return this.length;
	},
	
	putBit : function(bit) {
	
		var bufIndex = Math.floor(this.length / 8);
		if (this.buffer.length <= bufIndex) {
			this.buffer.push(0);
		}
	
		if (bit) {
			this.buffer[bufIndex] |= (0x80 >>> (this.length % 8) );
		}
	
		this.length++;
	}
};

module.exports = QRBitBuffer;

};
__f['QR8bitByte']=function(module,exports,require){
var QRMode = require('./QRMode');

function QR8bitByte(data) {
	this.mode = QRMode.MODE_8BIT_BYTE;
	this.data = data;
}

QR8bitByte.prototype = {

	getLength : function() {
		return this.data.length;
	},
	
	write : function(buffer) {
		for (var i = 0; i < this.data.length; i++) {
			// not JIS ...
			buffer.put(this.data.charCodeAt(i), 8);
		}
	}
};

module.exports = QR8bitByte;

};
__f['index']=function(module,exports,require){
//---------------------------------------------------------------------
// QRCode for JavaScript
//
// Copyright (c) 2009 Kazuhiko Arase
//
// URL: http://www.d-project.com/
//
// Licensed under the MIT license:
//   http://www.opensource.org/licenses/mit-license.php
//
// The word "QR Code" is registered trademark of 
// DENSO WAVE INCORPORATED
//   http://www.denso-wave.com/qrcode/faqpatent-e.html
//
//---------------------------------------------------------------------
// Modified to work in node for this project (and some refactoring)
//---------------------------------------------------------------------

var QR8bitByte = require('./QR8bitByte');
var QRUtil = require('./QRUtil');
var QRPolynomial = require('./QRPolynomial');
var QRRSBlock = require('./QRRSBlock');
var QRBitBuffer = require('./QRBitBuffer');

function QRCode(typeNumber, errorCorrectLevel) {
	this.typeNumber = typeNumber;
	this.errorCorrectLevel = errorCorrectLevel;
	this.modules = null;
	this.moduleCount = 0;
	this.dataCache = null;
	this.dataList = [];
}

QRCode.prototype = {
	
	addData : function(data) {
		var newData = new QR8bitByte(data);
		this.dataList.push(newData);
		this.dataCache = null;
	},
	
	isDark : function(row, col) {
		if (row < 0 || this.moduleCount <= row || col < 0 || this.moduleCount <= col) {
			throw new Error(row + "," + col);
		}
		return this.modules[row][col];
	},

	getModuleCount : function() {
		return this.moduleCount;
	},
	
	make : function() {
		// Calculate automatically typeNumber if provided is < 1
		if (this.typeNumber < 1 ){
			var typeNumber = 1;
			for (typeNumber = 1; typeNumber < 40; typeNumber++) {
				var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, this.errorCorrectLevel);

				var buffer = new QRBitBuffer();
				var totalDataCount = 0;
				for (var i = 0; i < rsBlocks.length; i++) {
					totalDataCount += rsBlocks[i].dataCount;
				}

				for (var x = 0; x < this.dataList.length; x++) {
					var data = this.dataList[x];
					buffer.put(data.mode, 4);
					buffer.put(data.getLength(), QRUtil.getLengthInBits(data.mode, typeNumber) );
					data.write(buffer);
				}
				if (buffer.getLengthInBits() <= totalDataCount * 8)
					break;
			}
			this.typeNumber = typeNumber;
		}
		this.makeImpl(false, this.getBestMaskPattern() );
	},
	
	makeImpl : function(test, maskPattern) {
		
		this.moduleCount = this.typeNumber * 4 + 17;
		this.modules = new Array(this.moduleCount);
		
		for (var row = 0; row < this.moduleCount; row++) {
			
			this.modules[row] = new Array(this.moduleCount);
			
			for (var col = 0; col < this.moduleCount; col++) {
				this.modules[row][col] = null;//(col + row) % 3;
			}
		}
	
		this.setupPositionProbePattern(0, 0);
		this.setupPositionProbePattern(this.moduleCount - 7, 0);
		this.setupPositionProbePattern(0, this.moduleCount - 7);
		this.setupPositionAdjustPattern();
		this.setupTimingPattern();
		this.setupTypeInfo(test, maskPattern);
		
		if (this.typeNumber >= 7) {
			this.setupTypeNumber(test);
		}
	
		if (this.dataCache === null) {
			this.dataCache = QRCode.createData(this.typeNumber, this.errorCorrectLevel, this.dataList);
		}
	
		this.mapData(this.dataCache, maskPattern);
	},

	setupPositionProbePattern : function(row, col)  {
		
		for (var r = -1; r <= 7; r++) {
			
			if (row + r <= -1 || this.moduleCount <= row + r) continue;
			
			for (var c = -1; c <= 7; c++) {
				
				if (col + c <= -1 || this.moduleCount <= col + c) continue;
				
				if ( (0 <= r && r <= 6 && (c === 0 || c === 6) ) || 
                     (0 <= c && c <= 6 && (r === 0 || r === 6) ) || 
                     (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
					this.modules[row + r][col + c] = true;
				} else {
					this.modules[row + r][col + c] = false;
				}
			}		
		}		
	},
	
	getBestMaskPattern : function() {
	
		var minLostPoint = 0;
		var pattern = 0;
	
		for (var i = 0; i < 8; i++) {
			
			this.makeImpl(true, i);
	
			var lostPoint = QRUtil.getLostPoint(this);
	
			if (i === 0 || minLostPoint >  lostPoint) {
				minLostPoint = lostPoint;
				pattern = i;
			}
		}
	
		return pattern;
	},
	
	createMovieClip : function(target_mc, instance_name, depth) {
	
		var qr_mc = target_mc.createEmptyMovieClip(instance_name, depth);
		var cs = 1;
	
		this.make();

		for (var row = 0; row < this.modules.length; row++) {
			
			var y = row * cs;
			
			for (var col = 0; col < this.modules[row].length; col++) {
	
				var x = col * cs;
				var dark = this.modules[row][col];
			
				if (dark) {
					qr_mc.beginFill(0, 100);
					qr_mc.moveTo(x, y);
					qr_mc.lineTo(x + cs, y);
					qr_mc.lineTo(x + cs, y + cs);
					qr_mc.lineTo(x, y + cs);
					qr_mc.endFill();
				}
			}
		}
		
		return qr_mc;
	},

	setupTimingPattern : function() {
		
		for (var r = 8; r < this.moduleCount - 8; r++) {
			if (this.modules[r][6] !== null) {
				continue;
			}
			this.modules[r][6] = (r % 2 === 0);
		}
	
		for (var c = 8; c < this.moduleCount - 8; c++) {
			if (this.modules[6][c] !== null) {
				continue;
			}
			this.modules[6][c] = (c % 2 === 0);
		}
	},
	
	setupPositionAdjustPattern : function() {
	
		var pos = QRUtil.getPatternPosition(this.typeNumber);
		
		for (var i = 0; i < pos.length; i++) {
		
			for (var j = 0; j < pos.length; j++) {
			
				var row = pos[i];
				var col = pos[j];
				
				if (this.modules[row][col] !== null) {
					continue;
				}
				
				for (var r = -2; r <= 2; r++) {
				
					for (var c = -2; c <= 2; c++) {
					
						if (Math.abs(r) === 2 || 
                            Math.abs(c) === 2 ||
                            (r === 0 && c === 0) ) {
							this.modules[row + r][col + c] = true;
						} else {
							this.modules[row + r][col + c] = false;
						}
					}
				}
			}
		}
	},
	
	setupTypeNumber : function(test) {
	
		var bits = QRUtil.getBCHTypeNumber(this.typeNumber);
        var mod;
	
		for (var i = 0; i < 18; i++) {
			mod = (!test && ( (bits >> i) & 1) === 1);
			this.modules[Math.floor(i / 3)][i % 3 + this.moduleCount - 8 - 3] = mod;
		}
	
		for (var x = 0; x < 18; x++) {
			mod = (!test && ( (bits >> x) & 1) === 1);
			this.modules[x % 3 + this.moduleCount - 8 - 3][Math.floor(x / 3)] = mod;
		}
	},
	
	setupTypeInfo : function(test, maskPattern) {
	
		var data = (this.errorCorrectLevel << 3) | maskPattern;
		var bits = QRUtil.getBCHTypeInfo(data);
        var mod;
	
		// vertical		
		for (var v = 0; v < 15; v++) {
	
			mod = (!test && ( (bits >> v) & 1) === 1);
	
			if (v < 6) {
				this.modules[v][8] = mod;
			} else if (v < 8) {
				this.modules[v + 1][8] = mod;
			} else {
				this.modules[this.moduleCount - 15 + v][8] = mod;
			}
		}
	
		// horizontal
		for (var h = 0; h < 15; h++) {
	
			mod = (!test && ( (bits >> h) & 1) === 1);
			
			if (h < 8) {
				this.modules[8][this.moduleCount - h - 1] = mod;
			} else if (h < 9) {
				this.modules[8][15 - h - 1 + 1] = mod;
			} else {
				this.modules[8][15 - h - 1] = mod;
			}
		}
	
		// fixed module
		this.modules[this.moduleCount - 8][8] = (!test);
	
	},
	
	mapData : function(data, maskPattern) {
		
		var inc = -1;
		var row = this.moduleCount - 1;
		var bitIndex = 7;
		var byteIndex = 0;
		
		for (var col = this.moduleCount - 1; col > 0; col -= 2) {
	
			if (col === 6) col--;
	
			while (true) {
	
				for (var c = 0; c < 2; c++) {
					
					if (this.modules[row][col - c] === null) {
						
						var dark = false;
	
						if (byteIndex < data.length) {
							dark = ( ( (data[byteIndex] >>> bitIndex) & 1) === 1);
						}
	
						var mask = QRUtil.getMask(maskPattern, row, col - c);
	
						if (mask) {
							dark = !dark;
						}
						
						this.modules[row][col - c] = dark;
						bitIndex--;
	
						if (bitIndex === -1) {
							byteIndex++;
							bitIndex = 7;
						}
					}
				}
								
				row += inc;
	
				if (row < 0 || this.moduleCount <= row) {
					row -= inc;
					inc = -inc;
					break;
				}
			}
		}
		
	}

};

QRCode.PAD0 = 0xEC;
QRCode.PAD1 = 0x11;

QRCode.createData = function(typeNumber, errorCorrectLevel, dataList) {
	
	var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectLevel);
	
	var buffer = new QRBitBuffer();
	
	for (var i = 0; i < dataList.length; i++) {
		var data = dataList[i];
		buffer.put(data.mode, 4);
		buffer.put(data.getLength(), QRUtil.getLengthInBits(data.mode, typeNumber) );
		data.write(buffer);
	}

	// calc num max data.
	var totalDataCount = 0;
	for (var x = 0; x < rsBlocks.length; x++) {
		totalDataCount += rsBlocks[x].dataCount;
	}

	if (buffer.getLengthInBits() > totalDataCount * 8) {
		throw new Error("code length overflow. (" + 
            buffer.getLengthInBits() + 
            ">" +  
            totalDataCount * 8 + 
            ")");
	}

	// end code
	if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
		buffer.put(0, 4);
	}

	// padding
	while (buffer.getLengthInBits() % 8 !== 0) {
		buffer.putBit(false);
	}

	// padding
	while (true) {
		
		if (buffer.getLengthInBits() >= totalDataCount * 8) {
			break;
		}
		buffer.put(QRCode.PAD0, 8);
		
		if (buffer.getLengthInBits() >= totalDataCount * 8) {
			break;
		}
		buffer.put(QRCode.PAD1, 8);
	}

	return QRCode.createBytes(buffer, rsBlocks);
};

QRCode.createBytes = function(buffer, rsBlocks) {

	var offset = 0;
	
	var maxDcCount = 0;
	var maxEcCount = 0;
	
	var dcdata = new Array(rsBlocks.length);
	var ecdata = new Array(rsBlocks.length);
	
	for (var r = 0; r < rsBlocks.length; r++) {

		var dcCount = rsBlocks[r].dataCount;
		var ecCount = rsBlocks[r].totalCount - dcCount;

		maxDcCount = Math.max(maxDcCount, dcCount);
		maxEcCount = Math.max(maxEcCount, ecCount);
		
		dcdata[r] = new Array(dcCount);
		
		for (var i = 0; i < dcdata[r].length; i++) {
			dcdata[r][i] = 0xff & buffer.buffer[i + offset];
		}
		offset += dcCount;
		
		var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
		var rawPoly = new QRPolynomial(dcdata[r], rsPoly.getLength() - 1);

		var modPoly = rawPoly.mod(rsPoly);
		ecdata[r] = new Array(rsPoly.getLength() - 1);
		for (var x = 0; x < ecdata[r].length; x++) {
            var modIndex = x + modPoly.getLength() - ecdata[r].length;
			ecdata[r][x] = (modIndex >= 0)? modPoly.get(modIndex) : 0;
		}

	}
	
	var totalCodeCount = 0;
	for (var y = 0; y < rsBlocks.length; y++) {
		totalCodeCount += rsBlocks[y].totalCount;
	}

	var data = new Array(totalCodeCount);
	var index = 0;

	for (var z = 0; z < maxDcCount; z++) {
		for (var s = 0; s < rsBlocks.length; s++) {
			if (z < dcdata[s].length) {
				data[index++] = dcdata[s][z];
			}
		}
	}

	for (var xx = 0; xx < maxEcCount; xx++) {
		for (var t = 0; t < rsBlocks.length; t++) {
			if (xx < ecdata[t].length) {
				data[index++] = ecdata[t][xx];
			}
		}
	}

	return data;

};

module.exports = QRCode;

};
var QRCode=__req('index');
return {QRCode:QRCode,RSBlock:__req('QRRSBlock'),ECL:__req('QRErrorCorrectLevel'),Util:__req('QRUtil')};
})();

/* QR decoder ringkas (mode byte, ECC L/M/Q/H, versi 1-40) - ditulis untuk game ini */
var QRDec=(function(){

    var EXP=new Array(512),LOG=new Array(256);

    (function(){
        var x=1,i;
        for(i=0;i<255;i++){EXP[i]=x;LOG[x]=i;x<<=1;if(x&256)x^=0x11d;}
        for(i=255;i<512;i++)EXP[i]=EXP[i-255];
    })();

    function gmul(a,b){return(a&&b)?EXP[LOG[a]+LOG[b]]:0;}
    function ginv(a){return EXP[255-LOG[a]];}

    /* ---------- Reed-Solomon ---------- */

    function rsCorrect(cw,nsym){

        var n=cw.length,S=[],ok=true,i,j;

        for(j=0;j<nsym;j++){
            var s=0;
            for(i=0;i<n;i++)s=gmul(s,EXP[j])^cw[i];
            S.push(s);
            if(s)ok=false;
        }

        if(ok)return true;

        var C=[1],B=[1],L=0,m=1,b=1;

        for(var nn=0;nn<nsym;nn++){

            var d=S[nn];

            for(i=1;i<=L;i++)d^=gmul(C[i]||0,S[nn-i]);

            if(d===0){m++;continue;}

            var T=C.slice();
            var coef=gmul(d,ginv(b));

            while(C.length<B.length+m)C.push(0);
            for(i=0;i<B.length;i++)C[i+m]^=gmul(coef,B[i]);

            if(2*L<=nn){
                L=nn+1-L;B=T;b=d;m=1;
            }
            else m++;

        }

        if(L===0||L*2>nsym)return false;

        /* posisi error (Chien) */

        var pos=[];

        for(i=0;i<n;i++){
            var p=n-1-i;
            var x=EXP[(255-p)%255];
            var v=0,xp=1;
            for(j=0;j<C.length;j++){v^=gmul(C[j],xp);xp=gmul(xp,x);}
            if(v===0)pos.push(i);
        }

        if(pos.length!==L)return false;

        /* omega = S*C mod x^nsym */

        var om=[];

        for(i=0;i<nsym;i++){
            var o=0;
            for(j=0;j<=i&&j<C.length;j++)o^=gmul(C[j],S[i-j]);
            om.push(o);
        }

        for(var k=0;k<pos.length;k++){

            var pk=n-1-pos[k];
            var X=EXP[pk%255];
            var Xi=EXP[(255-pk)%255];

            var ov=0,xpw=1;
            for(j=0;j<om.length;j++){ov^=gmul(om[j],xpw);xpw=gmul(xpw,Xi);}

            var dv=0;
            xpw=1;
            for(j=1;j<C.length;j+=2){dv^=gmul(C[j],xpw);xpw=gmul(xpw,gmul(Xi,Xi));}

            if(dv===0)return false;

            cw[pos[k]]^=gmul(X,gmul(ov,ginv(dv)));

        }

        for(j=0;j<nsym;j++){
            var s2=0;
            for(i=0;i<n;i++)s2=gmul(s2,EXP[j])^cw[i];
            if(s2)return false;
        }

        return true;

    }

    /* ---------- format info ---------- */

    var FORMATS=[];

    function buildFormats(){

        if(FORMATS.length)return;

        for(var d=0;d<32;d++)FORMATS.push({d:d,code:QRLib.Util.getBCHTypeInfo(d)});

    }

    function popc(x){var c=0;while(x){c+=x&1;x>>=1;}return c;}

    function matchFormat(bits){

        var best=null,bd=99;

        for(var i=0;i<FORMATS.length;i++){
            var dist=popc(FORMATS[i].code^bits);
            if(dist<bd){bd=dist;best=FORMATS[i];}
        }

        return bd<=3?best.d:-1;

    }

    function maskFn(p,r,c){
        switch(p){
            case 0:return(r+c)%2===0;
            case 1:return r%2===0;
            case 2:return c%3===0;
            case 3:return(r+c)%3===0;
            case 4:return(Math.floor(r/2)+Math.floor(c/3))%2===0;
            case 5:return(r*c)%2+(r*c)%3===0;
            case 6:return((r*c)%2+(r*c)%3)%2===0;
            default:return((r+c)%2+(r*c)%3)%2===0;
        }
    }

    function funcMask(dim,ver){

        var m=[],r,c;

        for(r=0;r<dim;r++){m.push(new Uint8Array(dim));}

        function mark(r0,c0,h,w){
            for(var i=0;i<h;i++)for(var j=0;j<w;j++){
                if(r0+i>=0&&r0+i<dim&&c0+j>=0&&c0+j<dim)m[r0+i][c0+j]=1;
            }
        }

        mark(0,0,9,9);
        mark(0,dim-8,9,8);
        mark(dim-8,0,8,9);

        for(i=0;i<dim;i++){m[6][i]=1;m[i][6]=1;}

        var i;

        var pos=QRLib.Util.getPatternPosition(ver);

        for(i=0;i<pos.length;i++){
            for(var j=0;j<pos.length;j++){
                var pr=pos[i],pc=pos[j];
                if((pr<=8&&pc<=8)||(pr<=8&&pc>=dim-9)||(pr>=dim-9&&pc<=8))continue;
                mark(pr-2,pc-2,5,5);
            }
        }

        if(ver>=7){
            mark(0,dim-11,6,3);
            mark(dim-11,0,3,6);
        }

        return m;

    }

    /* ---------- dekode dari matriks bit ---------- */

    function decodeMatrix(M,dim){

        buildFormats();

        var ver=(dim-17)/4;

        if(ver<1||ver>40||ver!==Math.floor(ver))return null;

        /* format copy 1 & 2 */

        var f1=0,f2=0,i;

        for(i=0;i<15;i++){

            var r1,c1,r2,c2;

            if(i<6){r1=i;c1=8;}
            else if(i<8){r1=i+1;c1=8;}
            else{r1=dim-15+i;c1=8;}

            if(i<8){r2=8;c2=dim-i-1;}
            else if(i<9){r2=8;c2=15-i-1+1;}
            else{r2=8;c2=15-i-1;}

            if(M[r1][c1])f1|=(1<<i);
            if(M[r2][c2])f2|=(1<<i);

        }

        var fd=matchFormat(f1);
        if(fd<0)fd=matchFormat(f2);
        if(fd<0)return null;

        var ecl=fd>>3,mask=fd&7;

        var fm=funcMask(dim,ver);

        var bits=[];

        var row=dim-1,inc=-1;

        for(var col=dim-1;col>0;col-=2){

            if(col===6)col--;

            while(true){

                for(var cc=0;cc<2;cc++){
                    var cx=col-cc;
                    if(!fm[row][cx]){
                        var bit=M[row][cx]?1:0;
                        if(maskFn(mask,row,cx))bit^=1;
                        bits.push(bit);
                    }
                }

                row+=inc;

                if(row<0||row>=dim){row-=inc;inc=-inc;break;}

            }

        }

        var cws=[];

        for(i=0;i+7<bits.length;i+=8){
            var v=0;
            for(var k=0;k<8;k++)v=(v<<1)|bits[i+k];
            cws.push(v);
        }

        var blocks=QRLib.RSBlock.getRSBlocks(ver,ecl);

        var maxD=0,maxE=0,bi;

        for(bi=0;bi<blocks.length;bi++){
            maxD=Math.max(maxD,blocks[bi].dataCount);
            maxE=Math.max(maxE,blocks[bi].totalCount-blocks[bi].dataCount);
        }

        var bd=[],be=[];

        for(bi=0;bi<blocks.length;bi++){bd.push([]);be.push([]);}

        var p=0;

        for(i=0;i<maxD;i++){
            for(bi=0;bi<blocks.length;bi++){
                if(i<blocks[bi].dataCount)bd[bi].push(cws[p++]);
            }
        }

        for(i=0;i<maxE;i++){
            for(bi=0;bi<blocks.length;bi++){
                if(i<blocks[bi].totalCount-blocks[bi].dataCount)be[bi].push(cws[p++]);
            }
        }

        var data=[];

        for(bi=0;bi<blocks.length;bi++){
            var all=bd[bi].concat(be[bi]);
            if(!rsCorrect(all,be[bi].length))return null;
            for(i=0;i<bd[bi].length;i++)data.push(all[i]);
        }

        /* parse mode byte */

        var bp=0;

        function rd(n){
            var v=0;
            for(var q=0;q<n;q++){
                var byte=data[bp>>3];
                if(byte===undefined)return -1;
                v=(v<<1)|((byte>>(7-(bp&7)))&1);
                bp++;
            }
            return v;
        }

        var out="";

        while(true){

            var mode=rd(4);

            if(mode<=0)break;

            if(mode!==4)return null;

            var len=rd(ver<10?8:16);

            if(len<0)return null;

            for(i=0;i<len;i++){
                var ch=rd(8);
                if(ch<0)return null;
                out+=String.fromCharCode(ch);
            }

        }

        return out;

    }

    /* ---------- homografi ---------- */

    function homography(src,dst){

        var A=[],i,j,k;

        for(i=0;i<4;i++){
            var u=src[i][0],v=src[i][1],x=dst[i][0],y=dst[i][1];
            A.push([u,v,1,0,0,0,-x*u,-x*v,x]);
            A.push([0,0,0,u,v,1,-y*u,-y*v,y]);
        }

        for(i=0;i<8;i++){

            var mx=i;

            for(j=i+1;j<8;j++)if(Math.abs(A[j][i])>Math.abs(A[mx][i]))mx=j;

            var t=A[i];A[i]=A[mx];A[mx]=t;

            if(Math.abs(A[i][i])<1e-12)return null;

            for(j=i+1;j<8;j++){
                var f=A[j][i]/A[i][i];
                for(k=i;k<9;k++)A[j][k]-=f*A[i][k];
            }

        }

        var h=new Array(8);

        for(i=7;i>=0;i--){
            var s=A[i][8];
            for(j=i+1;j<8;j++)s-=A[i][j]*h[j];
            h[i]=s/A[i][i];
        }

        return h;

    }

    function mapH(h,u,v){
        var w=h[6]*u+h[7]*v+1;
        return[(h[0]*u+h[1]*v+h[2])/w,(h[3]*u+h[4]*v+h[5])/w];
    }

    /* ---------- biner ---------- */

    function binarize(img){

        var w=img.width,h=img.height,d=img.data;

        var gray=new Uint8Array(w*h),i;

        for(i=0;i<w*h;i++){
            gray[i]=(d[i*4]*77+d[i*4+1]*150+d[i*4+2]*29)>>8;
        }

        var W1=w+1;
        var I=new Int32Array(W1*(h+1));

        for(var y=0;y<h;y++){
            var rs=0;
            for(var x=0;x<w;x++){
                rs+=gray[y*w+x];
                I[(y+1)*W1+x+1]=I[y*W1+x+1]+rs;
            }
        }

        var s=Math.max(15,Math.round(Math.min(w,h)/8))|1;
        var hs=s>>1;

        var bw=new Uint8Array(w*h);

        for(y=0;y<h;y++){
            var y0=Math.max(0,y-hs),y1=Math.min(h,y+hs+1);
            for(x=0;x<w;x++){
                var x0=Math.max(0,x-hs),x1=Math.min(w,x+hs+1);
                var sum=I[y1*W1+x1]-I[y0*W1+x1]-I[y1*W1+x0]+I[y0*W1+x0];
                var mean=sum/((x1-x0)*(y1-y0));
                bw[y*w+x]=gray[y*w+x]<mean*0.88?1:0;
            }
        }

        return bw;

    }

    /* ---------- pola finder ---------- */

    var EXPR=[1,1,3,1,1];

    function ratioOk(r){

        var tot=0,i;

        for(i=0;i<5;i++){if(r[i]<=0)return 0;tot+=r[i];}

        if(tot<7)return 0;

        var ms=tot/7;

        for(i=0;i<5;i++){
            var e=EXPR[i]*ms;
            if(Math.abs(r[i]-e)>e*0.6+0.5)return 0;
        }

        return ms;

    }

    /* hitung 5 run (B W B W B) di sekitar titik tengah sepanjang arah (dx,dy) */

    function crossRuns(bw,w,h,cx,cy,dx,dy){

        function at(t){
            var x=cx+dx*t,y=cy+dy*t;
            if(x<0||y<0||x>=w||y>=h)return -1;
            return bw[y*w+x];
        }

        if(at(0)!==1)return null;

        var r=[0,0,0,0,0];

        var t=0;

        /* tengah (hitam) */

        var n=0;
        while(at(-n)===1)n++;
        var back=n-1;
        var fwd=0;
        while(at(fwd+1)===1)fwd++;

        r[2]=back+fwd+1;
        var startC=-back,endC=fwd;

        /* putih kiri */

        t=startC-1;n=0;
        while(at(t)===0){n++;t--;}
        r[1]=n;

        /* hitam kiri */

        n=0;
        while(at(t)===1){n++;t--;}
        r[0]=n;

        /* putih kanan */

        t=endC+1;n=0;
        while(at(t)===0){n++;t++;}
        r[3]=n;

        /* hitam kanan */

        n=0;
        while(at(t)===1){n++;t++;}
        r[4]=n;

        var centerOff=(startC+endC)/2;

        return{r:r,off:centerOff};

    }

    function findFinders(bw,w,h){

        var cands=[];

        var step=h>600?2:1;

        for(var y=0;y<h;y+=step){

            /* run-length baris */

            var runs=[],starts=[],cols=[];

            var x=0;

            while(x<w){
                var v=bw[y*w+x];
                var s=x;
                while(x<w&&bw[y*w+x]===v)x++;
                runs.push(x-s);starts.push(s);cols.push(v);
            }

            for(var k=0;k+4<runs.length;k++){

                if(cols[k]!==1)continue;

                var rr=runs.slice(k,k+5);

                var ms=ratioOk(rr);

                if(!ms)continue;

                var cx=starts[k+2]+runs[k+2]/2;

                var icx=Math.floor(cx);

                var vr=crossRuns(bw,w,h,icx,y,0,1);

                if(!vr)continue;

                var msv=ratioOk(vr.r);

                if(!msv)continue;

                var cy=y+vr.off;

                if(Math.abs(msv-ms)>Math.max(ms,msv)*0.5)continue;

                var hr=crossRuns(bw,w,h,icx,Math.round(cy),1,0);

                var cx2=cx;

                if(hr&&ratioOk(hr.r)){cx2=icx+hr.off+0.5;}

                var m2=(ms+msv)/2;

                var found=false;

                for(var q=0;q<cands.length;q++){
                    var c=cands[q];
                    if(Math.hypot(c.x-cx2,c.y-cy)<Math.max(c.ms,m2)*2.5){
                        var n=c.n;
                        c.x=(c.x*n+cx2)/(n+1);
                        c.y=(c.y*n+cy)/(n+1);
                        c.ms=(c.ms*n+m2)/(n+1);
                        c.n=n+1;
                        found=true;
                        break;
                    }
                }

                if(!found)cands.push({x:cx2,y:cy,ms:m2,n:1});

            }

        }

        return cands.filter(function(c){return c.n>=3;}).sort(function(a,b){return b.n-a.n;}).slice(0,12);

    }

    /* ---------- coba dekode dari tiga finder ---------- */

    function bwAt(bw,w,h,x,y){
        x=Math.round(x);y=Math.round(y);
        if(x<0||y<0||x>=w||y>=h)return 0;
        return bw[y*w+x];
    }

    function attempt(bw,w,h,TL,TR,BL,dim){

        var ver=(dim-17)/4;

        var dmod=dim-7;

        var ux=[(TR.x-TL.x)/dmod,(TR.y-TL.y)/dmod];
        var uy=[(BL.x-TL.x)/dmod,(BL.y-TL.y)/dmod];

        var src=[[3.5,3.5],[dim-3.5,3.5],[3.5,dim-3.5]];
        var dst=[[TL.x,TL.y],[TR.x,TR.y],[BL.x,BL.y]];

        var ax,ay;

        if(ver>=2){

            /* cari pola alignment dekat posisi prediksi */

            var pu=dim-6.5-3.5;
            var px=TL.x+ux[0]*pu+uy[0]*pu;
            var py=TL.y+ux[1]*pu+uy[1]*pu;

            var ms=(Math.hypot(ux[0],ux[1])+Math.hypot(uy[0],uy[1]))/2;

            var best=-1,bx=px,by=py;

            var stp=Math.max(1,ms/3);

            for(var oy=-ms*4;oy<=ms*4;oy+=stp){
                for(var ox=-ms*4;ox<=ms*4;ox+=stp){

                    var sc=0;

                    for(var j=-2;j<=2;j++){
                        for(var i=-2;i<=2;i++){
                            var sx=px+ox+ux[0]*i+uy[0]*j;
                            var sy=py+oy+ux[1]*i+uy[1]*j;
                            var ring=Math.max(Math.abs(i),Math.abs(j));
                            var exp=(ring===1)?0:1;
                            if(bwAt(bw,w,h,sx,sy)===exp)sc++;
                        }
                    }

                    if(sc>best){best=sc;bx=px+ox;by=py+oy;}

                }
            }

            if(best>=22){
                ax=bx;ay=by;
            }
            else{
                ax=px;ay=py;
            }

            src.push([dim-6.5,dim-6.5]);
            dst.push([ax,ay]);

        }
        else{

            src.push([dim-3.5,dim-3.5]);
            dst.push([TR.x+BL.x-TL.x,TR.y+BL.y-TL.y]);

        }

        var H=homography(src,dst);

        if(!H)return null;

        var M=[];

        for(var r=0;r<dim;r++){

            var row=new Uint8Array(dim);

            for(var c=0;c<dim;c++){

                var votes=0;

                var offs=[[.5,.5],[.3,.5],[.7,.5],[.5,.3],[.5,.7]];

                for(var o=0;o<5;o++){
                    var pt=mapH(H,c+offs[o][0],r+offs[o][1]);
                    votes+=bwAt(bw,w,h,pt[0],pt[1]);
                }

                row[c]=votes>=3?1:0;

            }

            M.push(row);

        }

        return decodeMatrix(M,dim);

    }

    function tryTriple(bw,w,h,a,b,c){

        var dab=Math.hypot(a.x-b.x,a.y-b.y);
        var dac=Math.hypot(a.x-c.x,a.y-c.y);
        var dbc=Math.hypot(b.x-c.x,b.y-c.y);

        var TL,P,Q;

        if(dab>=dac&&dab>=dbc){TL=c;P=a;Q=b;}
        else if(dac>=dab&&dac>=dbc){TL=b;P=a;Q=c;}
        else{TL=a;P=b;Q=c;}

        var cross=(P.x-TL.x)*(Q.y-TL.y)-(P.y-TL.y)*(Q.x-TL.x);

        var TR,BL;

        if(cross>0){TR=P;BL=Q;}
        else{TR=Q;BL=P;}

        var ms=(TL.ms+TR.ms+BL.ms)/3;

        var d1=Math.hypot(TR.x-TL.x,TR.y-TL.y);
        var d2=Math.hypot(BL.x-TL.x,BL.y-TL.y);

        var est=((d1+d2)/2)/ms+7;

        var base=Math.round((est-17)/4)*4+17;

        var tries=[base,base+4,base-4,base+8,base-8];

        for(var i=0;i<tries.length;i++){
            var dim=tries[i];
            if(dim<21||dim>177)continue;
            var res=attempt(bw,w,h,TL,TR,BL,dim);
            if(res)return res;
        }

        return null;

    }

    function scan(img){

        var w=img.width,h=img.height;

        var bw=binarize(img);

        var fs=findFinders(bw,w,h);

        if(fs.length<3)return null;

        var trip=[];

        for(var i=0;i<fs.length;i++)for(var j=i+1;j<fs.length;j++)for(var k=j+1;k<fs.length;k++){

            var a=fs[i],b=fs[j],c=fs[k];

            var ratio=Math.max(a.ms,b.ms,c.ms)/Math.min(a.ms,b.ms,c.ms);

            if(ratio>1.7)continue;

            var d=[Math.hypot(a.x-b.x,a.y-b.y),Math.hypot(a.x-c.x,a.y-c.y),Math.hypot(b.x-c.x,b.y-c.y)].sort(function(x,y){return x-y;});

            var leg=Math.abs(d[0]-d[1])/d[1];

            var hyp=Math.abs(d[2]-d[1]*Math.SQRT2)/d[2];

            if(leg>0.4||hyp>0.35)continue;

            trip.push({a:a,b:b,c:c,s:leg+hyp});

        }

        trip.sort(function(x,y){return x.s-y.s;});

        for(i=0;i<trip.length&&i<6;i++){
            var r=tryTriple(bw,w,h,trip[i].a,trip[i].b,trip[i].c);
            if(r)return r;
        }

        return null;

    }

    return{scan:scan};

})();

