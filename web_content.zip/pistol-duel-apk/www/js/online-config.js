
/* ==================================================
   ONLINE (SUPABASE) — akun & data tersimpan di cloud
   Isi 2 nilai di bawah ini (lihat SUPABASE_SETUP.md).
   Kosong = game berjalan offline seperti biasa.
================================================== */
window.TDS_ONLINE_CONFIG={
    url:"https://pkszrrgmloplpjmhvdhn.supabase.co",
    anonKey:"sb_publishable_6NwDDdiKhCMlUZWOYjGJeg_Yd2ZHqZA",
    emailDomain:"gmail.com"
};

(function(){

    let url=String((window.TDS_ONLINE_CONFIG||{}).url||"").replace(/\/+$/,"");
    let key=String((window.TDS_ONLINE_CONFIG||{}).anonKey||"");

    try{
        const o=JSON.parse(localStorage.getItem("tds_online_cfg")||"null");
        if(o&&o.url&&o.anonKey){url=String(o.url).replace(/\/+$/,"");key=String(o.anonKey);}
    }catch(e){}

    const S_KEY="tds_sb_session";

    let sess=null;
    let name="";
    let status="off";
    let pend=null;
    let timer=0;
    let busy=false;
    let syncing=false;
    let late=false;

    const listeners=[];

    const O={};

    function ls(k,v){
        try{
            if(v===undefined)return localStorage.getItem(k);
            if(v===null)localStorage.removeItem(k);
            else localStorage.setItem(k,v);
        }catch(e){}
        return null;
    }

    function setStatus(s){
        status=s;
        listeners.forEach(f=>{try{f(s)}catch(e){}});
    }

    O.enabled=()=>!!(url&&key);
    O.status=()=>status;
    O.user=()=>name;
    O.onStatus=f=>{listeners.push(f);};
    O.onRemoteApplied=null;

    /* ---------- SHA-256 (hex) ---------- */

    function sha256js(str){
        const m=unescape(encodeURIComponent(str));
        const K=[];
        const H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
        for(let i=2,n=0;n<64;i++){
            let p=true;
            for(let j=2;j*j<=i;j++)if(i%j===0){p=false;break;}
            if(p){K[n++]=(Math.pow(i,1/3)%1*4294967296)|0;}
        }
        const w=[];
        const l=m.length;
        for(let i=0;i<l;i++)w[i>>2]|=m.charCodeAt(i)<<(24-(i%4)*8);
        w[l>>2]|=0x80<<(24-(l%4)*8);
        w[(((l+8)>>6)+1)*16-1]=l*8;
        const rot=(x,n)=>(x>>>n)|(x<<(32-n));
        for(let o=0;o<w.length;o+=16){
            const a=H.slice();
            const x=w.slice(o,o+16);
            for(let i=0;i<64;i++){
                if(i>=16){
                    const s0=rot(x[i-15],7)^rot(x[i-15],18)^(x[i-15]>>>3);
                    const s1=rot(x[i-2],17)^rot(x[i-2],19)^(x[i-2]>>>10);
                    x[i]=(x[i-16]+s0+x[i-7]+s1)|0;
                }
                const S1=rot(a[4],6)^rot(a[4],11)^rot(a[4],25);
                const ch=(a[4]&a[5])^(~a[4]&a[6]);
                const t1=(a[7]+S1+ch+K[i]+(x[i]|0))|0;
                const S0=rot(a[0],2)^rot(a[0],13)^rot(a[0],22);
                const mj=(a[0]&a[1])^(a[0]&a[2])^(a[1]&a[2]);
                const t2=(S0+mj)|0;
                a[7]=a[6];a[6]=a[5];a[5]=a[4];a[4]=(a[3]+t1)|0;
                a[3]=a[2];a[2]=a[1];a[1]=a[0];a[0]=(t1+t2)|0;
            }
            for(let i=0;i<8;i++)H[i]=(H[i]+a[i])|0;
        }
        return H.map(v=>(v>>>0).toString(16).padStart(8,"0")).join("");
    }

    async function sha256(str){
        try{
            if(window.crypto&&crypto.subtle&&window.TextEncoder){
                const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(str));
                return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,"0")).join("");
            }
        }catch(e){}
        return sha256js(str);
    }

    O._sha=sha256;

    const emailDom=String((window.TDS_ONLINE_CONFIG||{}).emailDomain||"gmail.com");

    const emailOf=u=>"tdsduel."+String(u).toLowerCase()+"@"+emailDom;

    const pwOf=(u,p)=>sha256("tds1:"+String(u).toLowerCase()+":"+p);

    /* ---------- HTTP ---------- */

    async function req(path,opt){

        opt=opt||{};

        const ctl=typeof AbortController!=="undefined"?new AbortController():null;

        const to=setTimeout(()=>{try{ctl&&ctl.abort()}catch(e){}},opt.timeout||10000);

        try{

            const h={
                "apikey":key,
                "Content-Type":"application/json",
                "Authorization":"Bearer "+(opt.token||key)
            };

            if(opt.headers)Object.assign(h,opt.headers);

            const r=await fetch(url+path,{
                method:opt.method||"GET",
                headers:h,
                body:opt.body?JSON.stringify(opt.body):undefined,
                keepalive:!!opt.keepalive,
                signal:ctl?ctl.signal:undefined
            });

            let j=null;

            try{j=await r.json()}catch(e){}

            return{ok:r.ok,status:r.status,json:j};

        }catch(e){

            return{ok:false,status:0,net:true,json:null};

        }finally{

            clearTimeout(to);

        }

    }

    function errMsg(r){

        if(r.net)return"Tidak ada koneksi internet.";

        const j=r.json||{};

        const m=String(j.msg||j.error_description||j.message||j.error||"").toLowerCase();

        if(m.includes("already")||m.includes("registered"))return"Username sudah dipakai.";
        if(m.includes("invalid login"))return"Username atau password salah.";
        if(m.includes("rate")||r.status===429)return"Terlalu banyak percobaan. Coba lagi sebentar.";
        if(m.includes("confirm"))return"Server meminta konfirmasi email. Matikan 'Confirm email' di Supabase.";
        if(m.includes("signups not allowed")||m.includes("signup is disabled"))return"Pendaftaran dimatikan di Supabase (aktifkan 'Allow new users to sign up').";
        if(m.includes("invalid")&&m.includes("email"))return"Server menolak format email akun (email_address_invalid).";

        return"Gagal terhubung ke server ("+r.status+"): "+String(j.error_code||j.msg||j.message||j.error_description||j.error||"tanpa pesan").slice(0,90);

    }

    /* ---------- SESI ---------- */

    function saveSess(){
        ls(S_KEY,sess?JSON.stringify(sess):null);
    }

    function takeSession(j,uname){

        if(!j||!j.access_token)return false;

        sess={
            at:j.access_token,
            rt:j.refresh_token,
            exp:Date.now()+((Number(j.expires_in)||3600)*1000),
            uid:(j.user&&j.user.id)||(sess&&sess.uid)||"",
            name:uname||(sess&&sess.name)||name
        };

        name=sess.name;

        saveSess();

        return true;

    }

    async function ensureToken(){

        if(!sess)return false;

        if(Date.now()<sess.exp-60000)return true;

        const r=await req("/auth/v1/token?grant_type=refresh_token",{
            method:"POST",
            body:{refresh_token:sess.rt}
        });

        if(r.ok&&takeSession(r.json))return true;

        if(!r.net&&(r.status===400||r.status===401||r.status===403)){
            sess=null;
            saveSess();
        }

        return false;

    }

    /* ---------- AKUN ---------- */

    O.signUp=async function(user,pass){

        const r=await req("/auth/v1/signup",{
            method:"POST",
            body:{
                email:emailOf(user),
                password:await pwOf(user,pass),
                data:{username:user}
            }
        });

        if(r.ok&&r.json&&r.json.access_token){
            takeSession(r.json,user);
            return{ok:true,name:user};
        }

        if(r.ok){
            return{ok:false,code:"confirm",msg:errMsg({json:{msg:"confirm"}})};
        }

        const m=errMsg(r);

        return{ok:false,net:!!r.net,code:m==="Username sudah dipakai."?"exists":"err",msg:m};

    };

    O.signIn=async function(user,pass){

        const r=await req("/auth/v1/token?grant_type=password",{
            method:"POST",
            body:{
                email:emailOf(user),
                password:await pwOf(user,pass)
            }
        });

        if(r.ok&&takeSession(r.json,user))return{ok:true,name:user};

        if(r.net)return{ok:false,net:true,msg:errMsg(r)};

        if(r.status===400||r.status===401)return{ok:false,code:"invalid",msg:errMsg(r)};

        return{ok:false,code:"err",msg:errMsg(r)};

    };

    O.offlineMode=function(user){
        name=user;
        sess=null;
        setStatus("offline");
    };

    /* ---------- DATA ---------- */

    const lkey=n=>"tds_profile_u_"+String(n).toLowerCase();

    const dkey=n=>"tds_dirty_"+String(n).toLowerCase();

    async function pullRow(){

        if(!(await ensureToken()))return{ok:false};

        const r=await req("/rest/v1/profiles?id=eq."+encodeURIComponent(sess.uid)+"&select=data,updated_at",{token:sess.at});

        if(!r.ok)return{ok:false};

        return{ok:true,row:(Array.isArray(r.json)&&r.json[0])||null};

    }

    async function pushNow(n,prof,ka){

        if(!(await ensureToken()))return false;

        const r=await req("/rest/v1/profiles?on_conflict=id&select=uid:data->>uid",{
            method:"POST",
            token:sess.at,
            keepalive:!!ka,
            headers:{"Prefer":"resolution=merge-duplicates,return=representation"},
            body:{id:sess.uid,username:n,data:prof}
        });

        if(r.ok&&Array.isArray(r.json)&&r.json[0]&&r.json[0].uid){
            const u=String(r.json[0].uid);
            if(/^[0-9]{5}$/.test(u)&&u!==String(prof.uid||"")&&O.onUid)O.onUid(n,u);
        }

        return r.ok;

    }

    /* sinkronkan saat masuk: data cloud vs data di HP (yang lebih baru menang) */

    O.pullInto=async function(user){

        syncing=true;

        let applied=false;

        try{

            name=user;

            const pr=await pullRow();

            if(!pr.ok){

                setStatus("offline");

                return{ok:false};

            }

            let local=null;

            try{local=JSON.parse(ls(lkey(user))||"null")}catch(e){}

            const cloud=pr.row&&pr.row.data&&typeof pr.row.data==="object"?pr.row.data:null;

            const lsv=local&&Number(local._sv)||0;

            const csv=cloud&&Number(cloud._sv)||0;

            const dirty=ls(dkey(user))==="1";

            if(!cloud){

                if(local){
                    if(await pushNow(user,local))ls(dkey(user),null);
                }

            }
            else if(local&&(dirty||!csv)&&lsv>csv){

                if(await pushNow(user,local))ls(dkey(user),null);

            }
            else{

                const same=local&&JSON.stringify(local)===JSON.stringify(cloud);

                if(!same){
                    ls(lkey(user),JSON.stringify(cloud));
                    applied=true;
                }

                ls(dkey(user),null);

            }

            setStatus("ok");

            return{ok:true,applied:applied};

        }finally{

            syncing=false;

            if(pend)schedule(600);

        }

    };

    O.resume=async function(user){

        let s=null;

        try{s=JSON.parse(ls(S_KEY)||"null")}catch(e){}

        if(!s||String(s.name).toLowerCase()!==String(user).toLowerCase()){
            name=user;
            setStatus("offline");
            return{ok:false};
        }

        sess=s;
        name=s.name;

        const r=await O.pullInto(s.name);

        if(!r.ok)return r;

        if(late&&r.applied&&O.onRemoteApplied)O.onRemoteApplied();

        return r;

    };

    O.markLate=function(){late=true;};

    /* simpan (debounce) */

    function schedule(ms){
        clearTimeout(timer);
        timer=setTimeout(flush,ms);
    }

    async function flush(ka){

        if(!pend)return;

        if(busy||syncing){
            schedule(1200);
            return;
        }

        if(!sess){
            setStatus("offline");
            return;
        }

        busy=true;

        setStatus("saving");

        const p=pend;

        pend=null;

        let ok=false;

        try{ok=await pushNow(p.n,p.d,ka===true);}catch(e){}

        busy=false;

        if(ok){
            if(!pend)ls(dkey(p.n),null);
            setStatus("ok");
        }
        else{
            if(!pend)pend=p;
            setStatus("offline");
            schedule(20000);
        }

    }

    O.queue=function(n,prof){

        if(!O.enabled()||!n)return;

        ls(dkey(n),"1");

        pend={n:n,d:JSON.parse(JSON.stringify(prof))};

        if(sess)schedule(2500);
        else setStatus("offline");

    };

    O.flushNow=function(){flush(true);};

    O.logout=async function(){

        try{await flush(true);}catch(e){}

        pend=null;
        sess=null;
        name="";
        saveSess();
        setStatus("off");

    };

    /* ---------- PERINGKAT ---------- */

    O.board=async function(){

        if(!O.enabled())return{ok:false,off:true};

        const r=await req("/rest/v1/leaderboard?select=username,rp,peak,xp&order=rp.desc,xp.desc&limit=50",{
            token:(sess&&Date.now()<sess.exp)?sess.at:key
        });

        if(!r.ok)return{ok:false,net:!!r.net};

        return{ok:true,rows:Array.isArray(r.json)?r.json:[]};

    };

    O.config=async function(){

        if(!O.enabled())return{ok:false,off:true};

        const r=await req("/rest/v1/app_config?select=key,value",{timeout:6000});

        if(!r.ok)return{ok:false,net:!!r.net};

        const c={};

        (Array.isArray(r.json)?r.json:[]).forEach(x=>{c[x.key]=x.value;});

        return{ok:true,cfg:c};

    };

    O.api=async function(path,opt){

        if(!O.enabled()||!sess)return{ok:false,off:true};

        if(!await ensureToken())return{ok:false,off:true};

        const o=Object.assign({},opt||{});

        o.token=sess.at;

        return await req(path,o);

    };

    O.onUid=null;

    O.search=async function(q){

        if(!O.enabled())return{ok:false,off:true};

        q=String(q||"").trim();

        let f;

        if(/^#?[0-9]{5}$/.test(q))f="uid=eq."+q.replace("#","");
        else if(/^[A-Za-z0-9_]{2,16}$/.test(q))f="username=ilike.*"+q+"*";
        else return{ok:false,bad:true};

        const r=await req("/rest/v1/leaderboard?select=username,uid,rp,peak,xp,bio&"+f+"&order=rp.desc&limit=20",{
            token:(sess&&Date.now()<sess.exp)?sess.at:key
        });

        if(!r.ok)return{ok:false,net:!!r.net,status:r.status};

        return{ok:true,rows:Array.isArray(r.json)?r.json:[]};

    };

    window.addEventListener("online",()=>{if(pend)schedule(500);});

    document.addEventListener("visibilitychange",()=>{
        if(document.hidden&&pend&&sess)flush(true);
    });

    window.addEventListener("pagehide",()=>{
        if(pend&&sess)flush(true);
    });

    window.TDSOnline=O;

})();
