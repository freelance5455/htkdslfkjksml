
(function(){

    const $=id=>document.getElementById(id);

    const mem={};

    const store={
        get(k){try{return localStorage.getItem(k)}catch(e){return mem[k]||null}},
        set(k,v){try{localStorage.setItem(k,v)}catch(e){mem[k]=v}},
        del(k){try{localStorage.removeItem(k)}catch(e){delete mem[k]}}
    };

    function getAccounts(){
        try{return JSON.parse(store.get("tds_accounts")||"{}")}catch(e){return{}}
    }

    function saveAccounts(a){
        store.set("tds_accounts",JSON.stringify(a));
    }

    async function hashPw(pw,salt){

        const data=salt+":"+pw;

        if(window.crypto&&crypto.subtle&&window.TextEncoder){

            const buf=await crypto.subtle.digest(
                "SHA-256",
                new TextEncoder().encode(data)
            );

            return Array.from(new Uint8Array(buf))
                .map(b=>b.toString(16).padStart(2,"0"))
                .join("");

        }

        let h=5381;

        for(let i=0;i<data.length;i++){
            h=((h<<5)+h+data.charCodeAt(i))|0;
        }

        return "f"+(h>>>0).toString(16);

    }

    /* ---------- LOADING ---------- */

    const TIPS=[
        "Menyiapkan arena duel...",
        "Mengisi peluru pistol...",
        "Memanaskan mesin skill...",
        "Menyusun karakter Blue & Red...",
        "Tips: tarik karakter untuk atur posisi",
        "Tips: coba skill baru GoldenTime 🌟",
        "Hampir siap..."
    ];

    /* ---------- INTRO STUDIO ---------- */

    (function(){
        const t="RapzXdeveloper";
        $("studioTxt").innerHTML=t.split("").map((ch,i)=>
            '<span'+(ch==="X"?' class="x"':'')+' style="transition-delay:'+(i*70)+'ms">'+ch+'</span>'
        ).join("");
    })();

    function runIntro(done){

        const el=$("intro");
        const a=$("introA");
        const b=$("introB");

        let seen=false;

        try{seen=!!localStorage.getItem("tds_intro_seen");}catch(e){}

        let finished=false;

        const timers=[];

        const T=(fn,ms)=>timers.push(setTimeout(fn,ms));

        a.classList.remove("on");
        b.classList.remove("on");

        el.style.display="flex";
        el.style.opacity="1";

        $("introSkip").style.display=seen?"block":"none";

        const end=()=>{

            if(finished)return;

            finished=true;

            timers.forEach(clearTimeout);

            try{localStorage.setItem("tds_intro_seen","1");}catch(e){}

            a.classList.remove("on");
            b.classList.remove("on");

            el.style.opacity="0";

            setTimeout(()=>{
                el.style.display="none";
                el.onclick=null;
                done&&done();
            },700);

        };

        el.onclick=seen?end:null;

        T(()=>a.classList.add("on"),350);
        T(()=>a.classList.remove("on"),3800);
        T(()=>b.classList.add("on"),5600);
        T(()=>b.classList.remove("on"),10000);
        T(end,11600);

    }

    function introThen(use,fn){

        if(use)runIntro(fn);
        else fn();

    }

    function runLoader(duration,done){

        const loader=$("loader");
        const fill=$("barFill");
        const pct=$("loadPct");
        const tip=$("loadTip");

        loader.style.display="flex";
        loader.style.opacity="1";

        let p=0;
        let last=performance.now();
        let tipIdx=-1;
        const speed=100/duration;

        function frame(now){

            const dt=now-last;
            last=now;

            p=Math.min(100,p+dt*speed*(.6+Math.random()*.9));

            fill.style.width=p+"%";
            pct.textContent=Math.floor(p)+"%";

            const idx=Math.min(
                TIPS.length-1,
                Math.floor(p/100*TIPS.length)
            );

            if(idx!==tipIdx){
                tipIdx=idx;
                tip.textContent=TIPS[idx];
            }

            if(p<100){
                requestAnimationFrame(frame);
            }
            else{
                setTimeout(()=>{
                    loader.style.opacity="0";
                    setTimeout(()=>{
                        loader.style.display="none";
                        done&&done();
                    },500);
                },250);
            }

        }

        requestAnimationFrame(frame);

    }

    /* ---------- SESI ---------- */

    function setUser(name){

        window.currentUser=name;

        $("userChip").textContent="👤 "+name;
        $("userChip").style.display="";
        $("logout").style.display="";

    }

    function enterGame(name,persist){

        window.currentIsGuest=!persist;

        $("auth").style.display="none";

        if(persist)store.set("tds_session",name);

        runIntro(()=>runLoader(2400,()=>{setUser(name);TDS.showMenu();}));

    }

    function showAuth(){

        $("auth").style.display="flex";

    }

    /* ---------- FORM ---------- */

    let regMode=false;

    function setMode(reg){

        regMode=reg;

        $("tabLogin").classList.toggle("on",!reg);
        $("tabReg").classList.toggle("on",reg);
        $("confWrap").style.display=reg?"":"none";
        $("authGo").textContent=reg?"✨ Buat Akun":"🚀 Masuk";
        $("authErr").textContent="";

    }

    $("tabLogin").onclick=()=>setMode(false);
    $("tabReg").onclick=()=>setMode(true);

    function err(m){$("authErr").textContent=m}

    async function saveLocalAcc(user,pass){

        const accounts=getAccounts();

        const key=user.toLowerCase();

        if(accounts[key])return accounts[key].name;

        const salt=Math.random().toString(36).slice(2,10);

        accounts[key]={name:user,salt:salt,hash:await hashPw(pass,salt)};

        saveAccounts(accounts);

        return user;

    }

    let authBusy=false;

    async function onlineSubmit(user,pass){

        if(authBusy)return;

        authBusy=true;

        const old=$("authGo").textContent;

        $("authGo").textContent="⏳ Menghubungkan...";

        $("authGo").disabled=true;

        err("");

        try{

            const key=user.toLowerCase();

            const accounts=getAccounts();

            if(regMode){

                if(pass!==$("inPass2").value)return err("Password tidak sama.");

                if(key==="admin")return err("Username sudah dipakai.");

                const r=await TDSOnline.signUp(user,pass);

                if(!r.ok)return err(r.msg);

                await saveLocalAcc(user,pass);

                await TDSOnline.pullInto(user);

                return enterGame(user,true);

            }

            const r=await TDSOnline.signIn(user,pass);

            if(r.ok){

                const nm=await saveLocalAcc(user,pass);

                await TDSOnline.pullInto(nm);

                return enterGame(nm,true);

            }

            const acc=accounts[key];

            const localOk=!!acc&&(await hashPw(pass,acc.salt))===acc.hash;

            if(r.net){

                if(localOk){
                    TDSOnline.offlineMode(acc.name);
                    return enterGame(acc.name,true);
                }

                return err("Tidak ada koneksi internet. Akun ini belum ada di perangkat.");

            }

            if(r.code==="invalid"){

                if(localOk){

                    /* akun lama (lokal) otomatis dipindah ke online */

                    const s2=await TDSOnline.signUp(acc.name,pass);

                    if(s2.ok){
                        await TDSOnline.pullInto(acc.name);
                        return enterGame(acc.name,true);
                    }

                    if(s2.code==="exists")return err("Password salah.");

                    return err(s2.msg);

                }

                return err("Username atau password salah (atau akun belum terdaftar).");

            }

            err(r.msg);

        }
        finally{

            authBusy=false;

            $("authGo").disabled=false;

            $("authGo").textContent=old;

        }

    }

    async function submit(){

        const user=$("inUser").value.trim();
        const pass=$("inPass").value;

        if(user==="Admin"&&pass==="Admin"){
            return enterGame("Admin",true);
        }

        if(!/^[A-Za-z0-9_]{3,16}$/.test(user)){
            return err("Username 3-16 karakter (huruf, angka, _).");
        }

        if(pass.length<4){
            return err("Password minimal 4 karakter.");
        }

        if(window.TDSOnline&&TDSOnline.enabled()){
            return onlineSubmit(user,pass);
        }

        const key=user.toLowerCase();
        const accounts=getAccounts();

        if(regMode){

            if(pass!==$("inPass2").value){
                return err("Password tidak sama.");
            }

            if(accounts[key]||key==="admin"){
                return err("Username sudah dipakai.");
            }

            const salt=Math.random().toString(36).slice(2,10);

            accounts[key]={
                name:user,
                salt:salt,
                hash:await hashPw(pass,salt)
            };

            saveAccounts(accounts);

            return enterGame(user,true);

        }

        const acc=accounts[key];

        if(!acc){
            return err("Akun tidak ditemukan. Daftar dulu ya.");
        }

        if(await hashPw(pass,acc.salt)!==acc.hash){
            return err("Password salah.");
        }

        enterGame(acc.name,true);

    }

    $("authGo").onclick=submit;

    ["inUser","inPass","inPass2"].forEach(id=>{
        $(id).addEventListener("keydown",e=>{
            if(e.key==="Enter")submit();
        });
    });

    $("authGuest").onclick=()=>enterGame("Tamu",false);

    $("logout").onclick=()=>{

        if(typeof stopDuel==="function")stopDuel();

        if(window.TDSOnline)TDSOnline.logout();

        store.del("tds_session");

        $("userChip").style.display="none";
        $("logout").style.display="none";

        $("inPass").value="";
        $("inPass2").value="";

        setMode(false);

        TDS.reset();

        showAuth();

    };

    /* ---------- BOOT ---------- */

    const bootSess=store.get("tds_session");

    let resumeP=null;

    if(bootSess&&window.TDSOnline&&TDSOnline.enabled()&&bootSess.toLowerCase()!=="admin"){
        resumeP=TDSOnline.resume(bootSess).catch(()=>null);
    }

    introThen(!!bootSess,()=>runLoader(1800,async()=>{

        const sess=bootSess;

        if(sess){

            if(resumeP){

                const r=await Promise.race([
                    resumeP.then(()=>"ok"),
                    new Promise(res=>setTimeout(()=>res("late"),1800))
                ]);

                if(r==="late")TDSOnline.markLate();

            }

            setUser(sess);
            TDS.showMenu();
        }
        else{
            showAuth();
        }

    }));

})();
