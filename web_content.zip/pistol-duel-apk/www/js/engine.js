

const canvas=
document.getElementById("game");

const ctx=
canvas.getContext("2d");

let W,H,dpr;

let objects=[];
let bullets=[];
let particles=[];
let boosters=[];
let clones=[];
let blackholes=[];
let explosions=[];
let timeFreeze=null;

let selected=null;
let dragging=null;

let mode="select";
let duelMode=false;
let netGuest=false;
let dimension=null;
let spirits=[];

let lastTime=performance.now();

let slowMotion=0;
let hitFlash=0;

let idCounter=0;

let boosterTimer=0;
let winnerTimer=0;

let currentDelta=0;

let pendingTeam=null;


/* ==================================================
   AUDIO
================================================== */

let audioCtx=null;

function initAudio(){

    if(!audioCtx){

        try{

            audioCtx=
                new (
                    window.AudioContext ||
                    window.webkitAudioContext
                )();

        }catch(e){}

    }

    if(
        audioCtx &&
        audioCtx.state==="suspended"
    ){

        audioCtx.resume();

    }

}

function sound(type){

    initAudio();

    if(!audioCtx)return;

    const osc=
        audioCtx.createOscillator();

    const gain=
        audioCtx.createGain();

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    let freq=300;
    let duration=.08;

    if(type==="shoot"){
        freq=150;
        duration=.05;
    }

    if(type==="hit"){
        freq=75;
        duration=.12;
    }

    if(type==="heal"){
        freq=650;
        duration=.18;
    }

    if(type==="boom"){
        freq=50;
        duration=.35;
    }

    if(type==="boost"){
        freq=800;
        duration=.12;
    }

    if(type==="burst"){
        freq=110;
        duration=.16;
    }

    if(type==="magnet"){
        freq=1300;
        duration=.06;
    }

    if(type==="fireshotShot"){
        freq=420;
        duration=.05;
    }

    if(type==="lifesteal"){
        freq=220;
        duration=.22;
    }

    if(type==="shotgunBlast"){
        freq=130;
        duration=.11;
    }

    if(type==="sniperShot"){
        freq=1050;
        duration=.04;
    }

    if(type==="speedShot"){
        freq=550;
        duration=.05;
    }

    if(type==="phase"){
        freq=950;
        duration=.2;
    }

    if(type==="cloneSpawn"){
        freq=480;
        duration=.09;
    }

    if(type==="vortex"){
        freq=40;
        duration=.3;
    }

    if(type==="voidkill"){
        freq=30;
        duration=.5;
    }

    if(type==="timeStart"){
        freq=900;
        duration=.4;
    }

    if(type==="timeShot"){
        freq=1600;
        duration=.03;
    }

    if(type==="timeEnd"){
        freq=200;
        duration=.3;
    }

    if(type==="angelRevive"){
        freq=700;
        duration=.45;
    }

    if(type==="hunterBarrage"){
        freq=160;
        duration=.18;
    }

    if(type==="immuneBlock"){
        freq=1400;
        duration=.05;
    }

    if(type==="goldenRewind"){
        freq=520;
        duration=.5;
    }

    if(type==="goldenImmune"){
        freq=1250;
        duration=.4;
    }

    if(type==="ice"){
        freq=1500;
        duration=.3;
    }

    if(type==="hipoSeal"){
        freq=330;
        duration=.35;
    }

    if(type==="slash"){
        freq=1800;
        duration=.16;
    }

    if(type==="katana"){
        freq=1250;
        duration=.04;
    }

    osc.frequency.value=freq;

    gain.gain.setValueAtTime(
        .07,
        audioCtx.currentTime
    );

    gain.gain.exponentialRampToValueAtTime(
        .001,
        audioCtx.currentTime+duration
    );

    osc.start();

    osc.stop(
        audioCtx.currentTime+duration
    );

}


/* ==================================================
   RESIZE
================================================== */

function resize(){

    dpr=
        Math.min(
            window.devicePixelRatio||1,
            window.dprCap||2
        );

    W=window.innerWidth;

    H=
        window.innerHeight-60;

    if(window.resTarget){

        dpr=Math.min(
            4,
            Math.max(1,window.resTarget/Math.max(W,H))
        );

        /* batas aman memori kanvas */

        const mp=W*H*dpr*dpr;

        if(mp>8.8e6)dpr*=Math.sqrt(8.8e6/mp);

    }

    canvas.width=W*dpr;
    canvas.height=H*dpr;

    canvas.style.width=W+"px";
    canvas.style.height=H+"px";

    ctx.setTransform(
        dpr,0,0,dpr,0,0
    );

}

window.addEventListener(
    "resize",
    resize
);

resize();


/* ==================================================
   SKILLS
================================================== */

const SKILLS={

    normal:{
        name:"Normal",
        icon:"🎯",
        damage:25,
        cooldown:4
    },

    burst:{
        name:"Burst",
        icon:"💥",
        damage:60*1.70*.90,
        cooldown:4,
        burst:true
    },

    magnet:{
        name:"Magnet",
        icon:"🧲",
        damage:50*.95,
        cooldown:4,
        magnet:true,
        accuracy:1,
        hpMultiplier:1
    },

    fireshot:{
        name:"FireShot",
        icon:"🔥",
        damage:25,
        cooldown:4,
        fireshot:true
    },

    nuclear:{
        name:"Nuklir",
        icon:"☢️",
        damage:25,
        cooldown:4,
        nuclear:true,
        nukeSkill:true,
        nukeCooldownMax:12,
        nukeDuration:3,
        nukeDamage:3,
        nukeDaze:2
    },

    regen:{
        name:"Regen",
        icon:"💚",
        damage:25,
        cooldown:4,
        regen:true
    },

    clone:{
        name:"Clone",
        icon:"👥",
        damage:25,
        cooldown:4,
        clone:true
    },

    speed:{
        name:"Speed",
        icon:"⚡",
        damage:25,
        cooldown:4,
        speedSkill:true
    },

    sniper:{
        name:"Sniper",
        icon:"🎯",
        damage:55,
        cooldown:5,
        accuracy:50,
        sniperSkill:true,
        sniperCooldownMax:10,
        moveMul:.8
    },

    shotgun:{
        name:"Shotgun",
        icon:"🔫",
        damage:59,
        cooldown:4,
        shotgun:true
    },

    lifesteal:{
        name:"LifeSteal",
        icon:"🩸",
        damage:22,
        cooldown:4,
        lifesteal:true,
        lifestealZone:true,
        lsCooldownMax:15,
        lsRadius:125,
        lsDuration:5,
        lsPct:.10,
        lsPassivePct:.15,lsSpeedMul:1.5,lsHealMul:1.2
    },

    samurai:{
        name:"Samurai",
        icon:"⚔️",
        damage:30,
        cooldown:10,
        melee:true,
        meleeReach:62,
        meleeDps:30,
        moveMul:2,
        samuraiSkill:true,
        samCooldownMax:15,
        slashDamage:45,
        slashCount:3
    },

    phase:{
        name:"Phase",
        icon:"👻",
        damage:35,
        cooldown:4,
        phase:true
    },

    hole:{
        name:"Hole",
        icon:"⚫",
        damage:40,
        cooldown:4,
        holeSkill:true,
        holeCooldownMax:8,
        holePullTime:1.4,
        holePullRadius:280,
        holeExplodeRadius:130,
        holeDamage:10,
        holeKnockback:300,
        holeStun:1.2
    },

    dead:{
        name:"Dead",
        icon:"💀",
        damage:0,
        cooldown:9999,
        noAttack:true,
        deadSkill:true,
        deadSurviveTime:30
    },

    time:{
        name:"Time",
        icon:"⏳",
        damage:25,
        cooldown:4,
        timeSkill:true,
        timeCooldownMax:13,
        timeDamage:10,
        timeDuration:1.2,
        timeFireRate:.12
    },

    angel:{
        name:"Angel",
        icon:"😇",
        damage:20,
        cooldown:4,
        angelSkill:true
    },

    hunter:{
        name:"Hunter",
        icon:"🤠",
        damage:35,
        cooldown:4,
        hunterSkill:true,
        hunterCooldownMax:8,
        hunterImmuneTime:2,
        hunterExtraPistols:5
    },

    goldentime:{
        name:"GoldenTime",
        icon:"🌟",
        damage:30,
        cooldown:4,
        goldenSkill:true,
        goldenCooldownMax:13.5,
        goldenImmuneTime:2,
        fateHp:.6,
        fatePower:1.5,
        fateStrikeDamage:60
    },

    hipo:{
        name:"Hipo",
        icon:"🔮",
        damage:30,
        cooldown:4,
        hipoSkill:true,
        hipoCooldownMax:14,
        hipoSealTime:10
    },

    ghost:{
        name:"Ghost",
        icon:"🌫️",
        damage:25,
        cooldown:4,
        ghostSkill:true,
        possessCooldownMax:15,
        possessTime:5,
        dimCooldownMax:20,
        dimTime:10
    },

    ice:{
        name:"Ice",
        icon:"❄️",
        damage:35,
        cooldown:4,
        iceSkill:true,
        iceCooldownMax:25,
        iceDuration:5,
        iceSlowTime:1.5
    }

};


/* ==================================================
   PARTICLES
================================================== */

function burstParticles(
    x,
    y,
    amount=15,
    type="hit"
){

    for(
        let i=0;
        i<amount;
        i++
    ){

        const a=
            Math.random()*
            Math.PI*2;

        const s=
            50+
            Math.random()*220;

        particles.push({

            x:x,
            y:y,

            vx:
                Math.cos(a)*s,

            vy:
                Math.sin(a)*s,

            life:
                .3+
                Math.random()*.5,

            max:.8,

            type:type,

            size:
                2+
                Math.random()*5

        });

    }

}


/* ==================================================
   ADD CHARACTER
================================================== */

function addCharacter(
    x,
    y,
    team,
    skill="normal"
){

    const s=
        SKILLS[skill]||
        SKILLS.normal;

    const maxHp=
        300*
        (s.hpMultiplier||1);

    const obj={

        id:idCounter++,

        type:"character",

        x:x,
        y:y,

        radius:25,

        team:team,

        hp:maxHp,

        maxHp:maxHp,

        skill:skill,

        angle:
            team==="blue"
            ?0
            :Math.PI,

        vx:
            (Math.random()<.5?-1:1)*
            (70+Math.random()*100),

        vy:
            (Math.random()<.5?-1:1)*
            (50+Math.random()*90),

        fireCooldown:
            .5+Math.random(),

        recoil:0,

        shield:0,

        shieldTimer:0,

        speedBoost:1,

        damageBoost:1,

        fireLevel:1,

        regenCooldown:3,

        cloneUsed:false,

        dead:false,

        stunTimer:0,

        holeCooldown:3,

        deadSurvive:0,

        deadTriggered:false,

        timeCooldown:3,

        angelUsed:false,

        hunterCooldown:3,

        immuneTimer:0,

        goldenCooldown:3,

        goldenImmune:0,

        goldenClock:0,

        goldenHistory:[],

        goldenRewind:null,

        fateUsed:false,

        fateBase:0,

        dimBuff:false,

        hipoCooldown:3,

        iceCooldown:3,

        iceZone:null,

        iceSlow:0,

        iceFrost:0,

        sealTimer:0,

        sealedSkill:null

    };

    cdStart(obj);

    objects.push(obj);

    updateInfo();

    return obj;

}


/* ==================================================
   NORMAL OBJECT
================================================== */

function addObject(
    x,
    y
){

    objects.push({

        id:idCounter++,

        type:"object",

        x:x,

        y:y,

        width:80,

        height:20,

        angle:
            Math.random()*
            Math.PI*2

    });

    updateInfo();

}


function updateInfo(){

    document.getElementById(
        "info"
    ).textContent=
        "Objek: "+
        objects.length+
        " • Booster: "+
        boosters.length;

}


/* ==================================================
   POINTER
================================================== */

function getPointer(e){

    const rect=
        canvas.getBoundingClientRect();

    return{

        x:
            e.clientX-
            rect.left,

        y:
            e.clientY-
            rect.top

    };

}


function getObjectAt(p){

    for(
        let i=
            objects.length-1;
        i>=0;
        i--
    ){

        const o=
            objects[i];

        if(
            o.type==="character"
        ){

            if(
                Math.hypot(
                    p.x-o.x,
                    p.y-o.y
                )<
                o.radius+10
            ){

                return o;

            }

        }

        if(
            o.type==="object"
        ){

            if(
                Math.hypot(
                    p.x-o.x,
                    p.y-o.y
                )<50
            ){

                return o;

            }

        }

    }

    return null;

}


canvas.addEventListener(
    "pointerdown",
    e=>{

        initAudio();

        const p=
            getPointer(e);

        const hit=
            getObjectAt(p);

        if(mode==="eraser"){

            if(hit){

                objects.splice(
                    objects.indexOf(hit),
                    1
                );

                selected=null;

                updateInfo();

            }

            return;

        }

        if(
            mode==="select" &&
            hit
        ){

            selected=hit;

            dragging={

                object:hit,

                offsetX:
                    p.x-hit.x,

                offsetY:
                    p.y-hit.y

            };

            canvas.setPointerCapture(
                e.pointerId
            );

        }

    }
);


canvas.addEventListener(
    "pointermove",
    e=>{

        if(!dragging)return;

        const p=
            getPointer(e);

        const o=
            dragging.object;

        o.x=
            p.x-
            dragging.offsetX;

        o.y=
            p.y-
            dragging.offsetY;

        if(
            o.type==="character"
        ){

            o.vx=0;
            o.vy=0;

        }

    }
);


canvas.addEventListener(
    "pointerup",
    ()=>{
        dragging=null;
    }
);


/* ==================================================
   SHOOT
================================================== */

function shoot(
    shooter,
    target
){

    if(
        !shooter ||
        !target ||
        shooter.hp<=0 ||
        target.hp<=0
    )return;

    const targetAngle=
        Math.atan2(
            target.y-shooter.y,
            target.x-shooter.x
        );

    const skill=
        SKILLS[shooter.skill]||
        SKILLS.normal;

    /*
        MAGNET:
        AKURASI 100%
    */

    let angle=
        targetAngle;

    if(!skill.magnet){

        const accuracy=
            skill.accuracy||1;

        const spread=
            Math.max(
                .08,
                1/accuracy
            );

        angle+=
            (Math.random()-.5)*
            spread;

    }


    if(shooter.dazeTimer>0)
        angle+=(Math.random()-.5)*2.4;

    let speed=520;

    if(skill.speedSkill)
        speed*=1.45;

    if(shooter.speedBoost>1)
        speed*=shooter.speedBoost;

    /*
        FIRESHOT:
        PELURU 2X LEBIH CEPAT
    */

    if(skill.fireshot)
        speed*=2;

    /*
        FIRESHOT
    */

    if(skill.fireshot){

        speed*=
            shooter.fireLevel;

        shooter.fireLevel=
            Math.min(
                2.5,
                shooter.fireLevel+.15
            );

    }


    let damage=
        (skill.damage||60)*
        shooter.damageBoost*
        (shooter.powMul||1)*
        (shooter.dimBuff?1.2:1)*
        icePow(shooter);


    /*
        BURST +70%
        sudah dihitung di skill.damage
    */


    /*
        MAGNET +90%
        sudah dihitung di skill.damage
    */


    bullets.push({

        x:
            shooter.x+
            Math.cos(angle)*32,

        y:
            shooter.y+
            Math.sin(angle)*32,

        vx:
            Math.cos(angle)*speed,

        vy:
            Math.sin(angle)*speed,

        owner:
            shooter.team,

        shooter:
            shooter,

        target:
            skill.magnet
            ?target
            :null,

        damage:damage,

        life:2.5,

        hit:false,

        magnet:
            !!skill.magnet,

        pierce:
            !!shooter.pierceNext

    });

    shooter.pierceNext=false;


    /*
        SHOTGUN
    */

    if(skill.shotgun){

        for(
            let i=0;
            i<2;
            i++
        ){

            const a=
                angle+
                (Math.random()-.5)*.35;

            bullets.push({

                x:
                    shooter.x+
                    Math.cos(a)*32,

                y:
                    shooter.y+
                    Math.sin(a)*32,

                vx:
                    Math.cos(a)*
                    speed*.9,

                vy:
                    Math.sin(a)*
                    speed*.9,

                owner:
                    shooter.team,

                shooter:
                    shooter,

                target:null,

                damage:
                    damage*.55,

                life:1.8,

                hit:false,

                magnet:false

            });

        }

    }


    sound("shoot");

    if(skill.burst)
        sound("burst");

    if(skill.magnet)
        sound("magnet");

    if(skill.fireshot)
        sound("fireshotShot");

    if(skill.shotgun)
        sound("shotgunBlast");

    if(shooter.skill==="sniper")
        sound("sniperShot");

    if(skill.speedSkill)
        sound("speedShot");

    shooter.recoil=1;

    burstParticles(
        shooter.x+
        Math.cos(angle)*38,

        shooter.y+
        Math.sin(angle)*38,

        5,

        "muzzle"
    );

}


/* ==================================================
   DAMAGE
================================================== */

function damageTarget(
    target,
    damage,
    bullet=null
){

    if(
        !target ||
        target.hp<=0 ||
        target.ghostIn
    )return;


    /*
        HUNTER IMMUNITY
    */

    const pierce=!!(bullet&&bullet.pierce);

    if(!pierce && (target.immuneTimer>0 || target.goldenImmune>0)){

        burstParticles(
            target.x,
            target.y,
            8,
            "shield"
        );

        sound("immuneBlock");

        return;

    }


    /*
        PHASE SHIELD
    */

    if(target.shield>0 && !pierce){

        const absorbed=
            Math.min(
                target.shield,
                damage
            );

        target.shield-=
            absorbed;

        damage-=
            absorbed;

        burstParticles(
            target.x,
            target.y,
            8,
            "shield"
        );

    }


    if(damage>0){

        target.hp=
            Math.max(
                0,
                target.hp-damage
            );

    }


    burstParticles(
        target.x,
        target.y,
        2,
        "hit"
    );

    target.lastHitBy=bullet?.shooter||null;

    slowMotion=.8;

    hitFlash=.15;

    sound("hit");


    /*
        LIFE STEAL
    */

    const shooter=
        bullet?.shooter;

    if(
        shooter &&
        SKILLS[shooter.skill]?.lifesteal
    ){

        shooter.hp=
            Math.min(
                shooter.maxHp,

                shooter.hp+
                shooter.maxHp*(SKILLS[shooter.skill].lsPassivePct||.15)*(shooter.lsZone?(SKILLS[shooter.skill].lsHealMul||1.2):1)
            );

        sound("lifesteal");

    }


    if(
        shooter &&
        SKILLS[shooter.skill]?.iceSkill &&
        target.hp>0
    ){

        target.iceSlow=SKILLS[shooter.skill].iceSlowTime||1.5;

        burstParticles(target.x,target.y,6,"shield");

    }


    /*
        KNOCKBACK
    */

    if(bullet){

        const len=
            Math.hypot(
                bullet.vx,
                bullet.vy
            )||1;

        target.vx+=
            bullet.vx/
            len*
            65;

        target.vy+=
            bullet.vy/
            len*
            65;

    }


    if(target.hp<=0){

        killCharacter(target);

    }

}


/* ==================================================
   DEATH
================================================== */

function killCharacter(o){

    if(o.dead)return;

    /*
        BOOSTER IMMORTAL: HIDUP LAGI
    */

    if(o.extraLives>0){

        o.extraLives--;

        o.hp=o.maxHp*.5;

        o.stunTimer=0;

        o.immuneTimer=
            Math.max(
                o.immuneTimer||0,
                2
            );

        burstParticles(
            o.x,
            o.y,
            30,
            "heal"
        );

        sound("angelRevive");

        return;

    }

    /*
        GOLDENTIME: MENGUBAH TAKDIR (HIDUP LAGI 1x)
    */

    if(SKILLS[o.skill]&&SKILLS[o.skill].goldenSkill&&!o.fateUsed){

        fateRevive(o);

        return;

    }

    o.dead=true;

    o.hp=0;

    if(o.possessedBy)endPossess(o.possessedBy);

    if(o.possessing)endPossess(o);

    burstParticles(
        o.x,
        o.y,
        30,
        "death"
    );


    /*
        NUKLIR: YANG MEMBUNUH IKUT MATI INSTAN
    */

    if(
        SKILLS[o.skill]?.nuclear
    ){

        const k=o.lastHitBy;

        if(k && k!==o && k.team!==o.team){

            let victim=null;

            if(k.type==="character"){

                victim=k;

            }
            else{

                /* pembunuh adalah klon: klon & pemiliknya ikut mati */

                k.hp=0;
                k.dead=true;

                burstParticles(k.x,k.y,14,"clone");

                victim=
                    objects.find(
                        c=>
                            c.type==="character" &&
                            c.id===k.lineageId
                    )||null;

            }

            if(victim && victim.hp>0 && !victim.dead){

                victim.immuneTimer=0;
                victim.goldenImmune=0;
                victim.shield=0;
                victim.hp=0;

                sound("boom");

                slowMotion=.6;

                burstParticles(
                    victim.x,
                    victim.y,
                    50,
                    "nuclear"
                );

                killCharacter(victim);

            }

        }

    }

}


function rawDamage(t,amount,src){

    if(src&&src.powMul)amount*=src.powMul;
    if(src&&src.dimBuff)amount*=1.2;

    if(!t||t.hp<=0||t.ghostIn)return 0;

    if(t.immuneTimer>0||t.goldenImmune>0){

        burstParticles(t.x,t.y,4,"shield");

        return 0;

    }

    if(t.shield>0){

        const a=Math.min(t.shield,amount);

        t.shield-=a;

        amount-=a;

    }

    if(amount<=0)return 0;

    t.hp=Math.max(0,t.hp-amount);

    t.lastHitBy=src||null;

    burstParticles(t.x,t.y,2,"hit");

    if(t.hp<=0)killCharacter(t);

    return amount;

}


function enemiesOf(o){

    return objects.filter(
        e=>
            e.type==="character" &&
            e.hp>0 &&
            e.team!==o.team
    );

}


function icePow(o){

    return (o.iceSlow>0?.95:1)*(o.iceFrost>0?.95:1);

}


function startIce(o){

    const sk=SKILLS[o.skill]||{};

    o.iceZone={
        t:sk.iceDuration||5,
        max:sk.iceDuration||5
    };

    sound("ice");

    burstParticles(o.x,o.y,28,"shield");

    try{ultFx(o.x,o.y,"ice",o.team);}catch(e){}

}


function updateIce(o,dt){

    if(o.iceSlow>0)o.iceSlow-=dt;

    if(o.iceFrost>0)o.iceFrost-=dt;

    const sk=SKILLS[o.skill];

    if(!sk||!sk.iceSkill){
        if(o.iceZone)o.iceZone=null;
        return;
    }

    if(o.hp<=0){
        o.iceZone=null;
        return;
    }

    if(o.iceCooldown===undefined)o.iceCooldown=3;

    if(o.iceZone){

        o.iceZone.t-=dt;

        enemiesOf(o).forEach(e=>{
            e.iceFrost=Math.max(e.iceFrost||0,.35);
        });

        if(o.iceZone.t<=0)o.iceZone=null;

    }

    o.iceCooldown-=dt;

    if(o.iceCooldown<=0&&enemiesOf(o).length){

        startIce(o);

        o.iceCooldown=sk.iceCooldownMax||25;

    }

}


/* ---------- GLOBAL v1.01: MANA ---------- */

const MANA_MAX=100;
const MANA_REGEN=2.5;   /* 5 tiap 2 detik */

const MANA_FIELDS=[
    ["holeCooldown","holeSkill"],["timeCooldown","timeSkill"],["hunterCooldown","hunterSkill"],
    ["hipoCooldown","hipoSkill"],["sniperCooldown","sniperSkill"],["lsCooldown","lifestealZone"],
    ["iceCooldown","iceSkill"],["nukeCooldown","nukeSkill"],["samCooldown","samuraiSkill"],
    ["ghostCooldown","ghostSkill"],["dimCooldown","ghostSkill"]
];

function manaOf(o){
    if(o.mana===undefined)o.mana=MANA_MAX;
    return o.mana;
}

function manaCost(k){
    return k==="dead"?100:60;
}

function manaHas(o,c){
    return manaOf(o)>=c-1e-6;
}

function manaPay(o,c){
    o.mana=Math.max(0,manaOf(o)-c);
}

/* tiap frame: regen mana + tahan skill otomatis yang cooldown-nya selesai tapi mana kurang */

function manaTick(o,dt){

    if(o.type!=="character")return;

    o.mana=Math.min(MANA_MAX,manaOf(o)+dt*MANA_REGEN);

    if(o.manaFlashT>0)o.manaFlashT-=dt;

    const s=SKILLS[o.skill];

    if(!s||o.manual||o.hp<=0)return;

    const pv=o._mp||(o._mp={});

    MANA_FIELDS.forEach(f=>{

        if(!s[f[1]])return;

        const k=f[0];
        let cur=o[k];

        if(typeof cur!=="number"||cur>1e8){pv[k]=undefined;return;}

        if(pv[k]!==undefined&&cur>pv[k]+1.5)manaPay(o,60);

        if(cur<=dt+.03&&!manaHas(o,60)){
            o[k]=dt+.03;
        }

        pv[k]=o[k];

    });

    if(s.deadSkill){

        if(pv.dt===false&&o.deadTriggered)manaPay(o,100);

        if(!o.deadTriggered){

            const t=s.deadSurviveTime||10;

            if(!manaHas(o,100)&&o.deadSurvive>t-dt-.03)o.deadSurvive=t-dt-.03;

        }

        pv.dt=!!o.deadTriggered;

    }

}


function cdStart(o){

    const s=SKILLS[o.skill]||{};

    o.mana=MANA_MAX;
    o._mp=null;
    o.manaFlashT=0;

    o.regenCooldown=6;
    o.holeCooldown=s.holeCooldownMax||8;
    o.timeCooldown=s.timeCooldownMax||10;
    o.hunterCooldown=s.hunterCooldownMax||8;
    o.goldenCooldown=s.goldenCooldownMax||13.5;
    o.hipoCooldown=s.hipoCooldownMax||14;
    o.sniperCooldown=s.sniperCooldownMax||10;
    o.lsCooldown=s.lsCooldownMax||6;
    o.iceCooldown=s.iceCooldownMax||25;
    o.nukeCooldown=s.nukeCooldownMax||12;
    o.samCooldown=s.samCooldownMax||15;
    o.ghostCooldown=s.possessCooldownMax||15;
    o.dimCooldown=s.dimCooldownMax||20;

}


function cdStartManual(p){

    const s=SKILLS[p.skill]||{};

    if(s.timeSkill)return s.timeCooldownMax||10;
    if(s.holeSkill)return s.holeCooldownMax||8;
    if(s.hunterSkill)return s.hunterCooldownMax||8;
    if(s.hipoSkill)return s.hipoCooldownMax||14;
    if(s.nukeSkill)return s.nukeCooldownMax||12;
    if(s.lifestealZone)return s.lsCooldownMax||6;
    if(s.iceSkill)return s.iceCooldownMax||25;
    if(s.samuraiSkill)return s.samCooldownMax||15;
    if(s.ghostSkill)return s.possessCooldownMax||15;
    if(s.sniperSkill)return s.sniperCooldownMax||10;

    return 2;

}


function startLifeZone(o){

    const sk=SKILLS[o.skill]||{};

    o.lsZone={

        t:sk.lsDuration||2.5,
        max:sk.lsDuration||2.5,
        r:sk.lsRadius||160,
        pct:sk.lsPct||.25,
        tick:0,
        spin:0

    };

    sound("lifesteal");

    burstParticles(o.x,o.y,24,"death");

}


function updateLifeSteal(o,dt){

    const sk=SKILLS[o.skill];

    if(!sk||!sk.lifestealZone)return;

    if(o.hp<=0){
        o.lsZone=null;
        return;
    }

    if(o.lsCooldown===undefined)
        o.lsCooldown=3;

    if(o.lsZone){

        const z=o.lsZone;

        z.t-=dt;
        z.spin+=dt;

        /* musuh di dalam area disedot 25% HP maks per detik (tick 0,25 dtk) */

        z.tick+=dt;

        while(z.tick>=.25){

            z.tick-=.25;

            enemiesOf(o).forEach(e=>{

                if(Math.hypot(e.x-o.x,e.y-o.y)>z.r)return;

                const before=e.hp;

                rawDamage(e,e.maxHp*z.pct*.25,o);

                const got=Math.max(0,before-e.hp);

                if(got>0){

                    o.hp=Math.min(o.maxHp,o.hp+got*(SKILLS[o.skill].lsHealMul||1.2));

                    burstParticles(e.x,e.y,5,"death");
                    burstParticles(o.x,o.y,4,"heal");

                    sound("lifesteal");

                }

            });

        }

        if(z.t<=0)o.lsZone=null;

    }

    o.lsCooldown-=dt;

    if(
        o.lsCooldown<=0 &&
        enemiesOf(o).length
    ){

        startLifeZone(o);

        o.lsCooldown=sk.lsCooldownMax||6;

    }

}


/* ---------- SAMURAI ---------- */

function samEnemies(o){

    return enemiesOf(o).filter(
        e=>!dimension||e.dimId===o.dimId
    );

}

function samNearest(o){

    let t=null,b=Infinity;

    samEnemies(o).forEach(e=>{

        const d=Math.hypot(e.x-o.x,e.y-o.y);

        if(d<b){b=d;t=e;}

    });

    return t;

}

/* serangan katana: harus mepet, damage terus-menerus tanpa jeda */

function meleeStrike(o,t,dt){

    const sk=SKILLS[o.skill]||{};

    const reach=sk.meleeReach||62;

    if(o.samSeq)return;

    if(Math.hypot(t.x-o.x,t.y-o.y)>reach)return;

    o.samAtk=.18;

    o.samAcc=(o.samAcc||0)+dt;

    const step=.1;

    while(o.samAcc>=step){

        o.samAcc-=step;

        rawDamage(
            t,
            (sk.meleeDps||10)*step*(o.damageBoost||1)*icePow(o),
            o
        );

        burstParticles((o.x+t.x)/2,(o.y+t.y)/2,2,"muzzle");

        if(t.hp<=0)break;

    }

    o.samSnd=(o.samSnd||0)-dt;

    if(o.samSnd<=0){

        o.samSnd=.25;

        sound("katana");

    }

}

/* tebasan kilat: melesat secepat kilat, 3 tebasan bolak-balik ke satu musuh */

function samClampPt(x,y){

    return{
        x:Math.max(35,Math.min(W-35,x)),
        y:Math.max(45,Math.min(H*.68-25,y))
    };

}

function castSlash(o){

    const t=samNearest(o);

    if(!t)return false;

    const sk=SKILLS[o.skill]||{};

    const dx=t.x-o.x,dy=t.y-o.y;

    const d=Math.hypot(dx,dy)||1;

    o.samSeq={
        target:t,
        ux:dx/d,
        uy:dy/d,
        n:0,
        total:sk.slashCount||3,
        seg:null
    };

    o.vx=0;
    o.vy=0;

    sound("slash");

    burstParticles(o.x,o.y,14,"boost");

    return true;

}

function samSegStart(o,q){

    const t=q.target;

    const R=70;

    const B=samClampPt(t.x+q.ux*R,t.y+q.uy*R);

    const A=samClampPt(t.x-q.ux*R,t.y-q.uy*R);

    const to=(q.n%2===0)?B:A;

    const dist=Math.hypot(to.x-o.x,to.y-o.y);

    q.seg={
        x0:o.x,
        y0:o.y,
        x1:to.x,
        y1:to.y,
        t:0,
        dur:Math.max(.09,Math.min(.22,dist/2600)),
        hit:false
    };

}

function updateSamSeq(o,dt){

    const q=o.samSeq;

    const sk=SKILLS[o.skill]||{};

    if(!q.target||q.target.hp<=0||o.hp<=0){
        o.samSeq=null;
        return;
    }

    if(!q.seg)samSegStart(o,q);

    const g=q.seg;

    g.t+=dt;

    const u=Math.min(1,g.t/g.dur);

    o.x=g.x0+(g.x1-g.x0)*u;
    o.y=g.y0+(g.y1-g.y0)*u;

    o.vx=0;
    o.vy=0;

    o.samAtk=.2;

    o.angle=Math.atan2(g.y1-g.y0,g.x1-g.x0);

    if(Math.random()<.9)
        burstParticles(o.x,o.y,2,"boost");

    if(!g.hit&&u>=.5){

        g.hit=true;

        rawDamage(q.target,(sk.slashDamage||45)*(o.damageBoost||1)*icePow(o),o);

        o.samFx={x:g.x0,y:g.y0,tx:g.x1,ty:g.y1,t:.32};

        burstParticles(q.target.x,q.target.y,16,"hit");

        burstParticles(q.target.x,q.target.y,6,"muzzle");

        sound("slash");

    }

    if(u>=1){

        q.n++;

        q.seg=null;

        if(q.n>=q.total)o.samSeq=null;

    }

}

function updateSamurai(o,dt){

    const sk=SKILLS[o.skill];

    if(!sk||!sk.samuraiSkill)return;

    if(o.hp<=0){
        o.samFx=null;
        o.samSeq=null;
        return;
    }

    if(o.samAtk>0)o.samAtk=Math.max(0,o.samAtk-dt);

    if(o.samFx){
        o.samFx.t-=dt;
        if(o.samFx.t<=0)o.samFx=null;
    }

    if(o.samSeq){
        updateSamSeq(o,dt);
        return;
    }

    if(o.samCooldown===undefined)
        o.samCooldown=3;

    o.samCooldown-=dt;

    if(o.samCooldown<=0&&samEnemies(o).length){

        if(castSlash(o))
            o.samCooldown=sk.samCooldownMax||15;
        else
            o.samCooldown=.7;

    }

}

function startRadiation(o){

    const sk=SKILLS[o.skill]||{};

    o.radT=sk.nukeDuration||3;
    o.radMax=o.radT;
    o.radTick=0;
    o.radDazed=new Set();

    sound("boom");

    burstParticles(o.x,o.y,40,"nuclear");

}


function updateNuke(o,dt){

    const sk=SKILLS[o.skill];

    if(!sk||!sk.nukeSkill)return;

    if(o.hp<=0){
        o.radT=0;
        return;
    }

    if(o.nukeCooldown===undefined)
        o.nukeCooldown=3;

    if(o.radT>0){

        o.radT-=dt;

        o.radTick-=dt;

        if(o.radT>0 && o.radTick<=0){

            o.radTick+=1;

            enemiesOf(o).forEach(e=>{

                rawDamage(e,sk.nukeDamage||3,o);

                if(!o.radDazed.has(e.id)){

                    o.radDazed.add(e.id);

                    e.dazeTimer=sk.nukeDaze||2;

                }

            });

        }

        if(o.radT<=0)o.radT=0;

    }

    o.nukeCooldown-=dt;

    if(
        o.nukeCooldown<=0 &&
        !(o.radT>0) &&
        enemiesOf(o).length
    ){

        startRadiation(o);

        o.nukeCooldown=sk.nukeCooldownMax||12;

    }

}


/* ==================================================
   GHOST: MERASUKI & DIMENSI
================================================== */

function ghostNearest(o,arr){

    let best=null,bd=Infinity;

    arr.forEach(e=>{
        const d=Math.hypot(e.x-o.x,e.y-o.y);
        if(d<bd){bd=d;best=e;}
    });

    return best;

}

function ghostEnemies(g){

    return objects.filter(x=>
        x.type==="character" &&
        x.hp>0 &&
        x.team!==g.team &&
        !x.possessedBy &&
        !x.ghostIn &&
        (!dimension||x.dimId===1)
    );

}

function castPossess(g){

    if(dimension||g.ghostIn||g.possessing||g.possessedBy||g.hp<=0)return false;

    const t=ghostNearest(g,ghostEnemies(g));

    if(!t)return false;

    spirits.push({
        x:g.x,
        y:g.y,
        owner:g,
        target:t,
        t:0
    });

    burstParticles(g.x,g.y,16,"clone");

    sound("phase");

    return true;

}

function updateSpirits(dt){

    for(let i=spirits.length-1;i>=0;i--){

        const s=spirits[i];

        if(
            s.owner.hp<=0 ||
            s.target.hp<=0 ||
            s.target.possessedBy ||
            s.owner.ghostIn
        ){
            spirits.splice(i,1);
            continue;
        }

        s.t+=dt;

        const dx=s.target.x-s.x;
        const dy=s.target.y-s.y;
        const d=Math.hypot(dx,dy);

        if(d<28||s.t>2){

            spirits.splice(i,1);

            possess(s.owner,s.target);

            continue;

        }

        const sp=680*dt;

        s.x+=dx/d*sp;
        s.y+=dy/d*sp;

        if(Math.random()<.8)burstParticles(s.x,s.y,1,"clone");

    }

}

function possess(g,e){

    g.possessing=e;
    g.possT=5;
    g.ghostIn=true;
    g.vx=0;
    g.vy=0;

    g.humanCtl=!!g.manual;

    e.possessedBy=g;
    e.possT=5;
    e.origTeam=e.team;
    e.team=g.team;

    if(g.humanCtl){

        g.manualWas=true;
        g.manual=false;

        e._man=!!e.manual;
        e._ai=e.ai;
        e.ai=null;
        e.manual=true;
        e.mcd=0;
        e.mcdMax=1;
        e.manualCloneDone=false;
        e.boostT=0;
        e.goldenGo=false;
        e.gWasActive=false;

    }

    e.stunTimer=0;

    if(!g.humanCtl){
        e.vx=(Math.random()<.5?-1:1)*(70+Math.random()*100);
        e.vy=(Math.random()<.5?-1:1)*(50+Math.random()*90);
    }

    burstParticles(e.x,e.y,36,"clone");

    sound("hipoSeal");

    slowMotion=.3;

}

function refreshCd(o){

    ["timeCooldown","holeCooldown","hunterCooldown","goldenCooldown","hipoCooldown","sniperCooldown","lsCooldown","nukeCooldown","samCooldown","ghostCooldown","dimCooldown"].forEach(f=>{
        if(o[f]>100)o[f]=3+Math.random()*2;
    });

}

function endPossess(g){

    const e=g.possessing;

    g.possessing=null;
    g.possT=0;
    g.ghostIn=false;

    if(g.manualWas){
        g.manual=true;
        g.manualWas=false;
    }

    if(e){

        e.team=e.origTeam||e.team;
        e.origTeam=null;
        e.possessedBy=null;
        e.possT=0;

        if(e._ai!==undefined){
            e.ai=e._ai;
            e._ai=undefined;
        }

        if(e._man===false)e.manual=false;

        e._man=undefined;

        refreshCd(e);

        burstParticles(e.x,e.y,22,"clone");

    }

    burstParticles(g.x,g.y,18,"clone");

}

function castDimension(g){

    if(dimension||g.ghostIn||g.possessing||g.possessedBy||g.hp<=0)return false;

    const e=ghostNearest(g,ghostEnemies(g));

    if(!e)return false;

    g.dimBuff=true;

    dimension={
        g:g,
        e:e,
        t:0,
        dur:10,
        saved:bullets,
        pos:[[g.x,g.y],[e.x,e.y]]
    };

    bullets=[];

    objects.forEach(o=>{
        if(o.type==="character")o.dimId=(o===g||o===e)?1:0;
    });

    g.x=W*.25;
    g.y=H*.34;
    e.x=W*.75;
    e.y=H*.34;

    burstParticles(g.x,g.y,30,"clone");
    burstParticles(e.x,e.y,30,"clone");

    sound("vortex");

    slowMotion=.4;

    return true;

}

function endDimension(){

    const d=dimension;

    if(!d)return;

    dimension=null;

    if(d.g)d.g.dimBuff=false;

    bullets=d.saved||[];

    objects.forEach(o=>{o.dimId=undefined;});

    [d.g,d.e].forEach((o,i)=>{
        if(o.hp>0){
            o.x=d.pos[i][0];
            o.y=d.pos[i][1];
            burstParticles(o.x,o.y,24,"clone");
        }
    });

    sound("timeEnd");

}

function updateDimension(dt){

    if(!dimension)return;

    dimension.t+=dt;

    if(
        dimension.g.hp<=0 ||
        dimension.e.hp<=0 ||
        dimension.t>=dimension.dur
    )endDimension();

}

function endAllGhost(){

    objects.forEach(o=>{
        if(o.type!=="character")return;
        if(o.possessing)endPossess(o);
    });

    objects.forEach(o=>{
        if(o.type!=="character")return;
        if(o.possessedBy){
            o.team=o.origTeam||o.team;
            o.possessedBy=null;
            o.possT=0;
        }
        o.ghostIn=false;
        o.dimId=undefined;
        o.dimBuff=false;
    });

    dimension=null;
    spirits=[];

}

function updateGhost(o,dt){

    const sk=SKILLS[o.skill];

    if(!sk||!sk.ghostSkill)return;

    if(o.hp<=0){
        if(o.possessing)endPossess(o);
        return;
    }

    if(o.possessing){

        o.possT-=dt;

        o.vx=0;
        o.vy=0;

        const e=o.possessing;

        if(o.possT<=0||e.hp<=0||e.dead)endPossess(o);

    }

    if(o.manualWas){

        if(o.mcd>0)o.mcd=Math.max(0,o.mcd-dt);
        if(o.mcd2>0)o.mcd2=Math.max(0,o.mcd2-dt);

        return;

    }

    if(o.manual)return;

    if(o.ghostIn||o.possessedBy||dimension)return;

    o.ghostCooldown-=dt;
    o.dimCooldown-=dt;

    if(o.ghostCooldown<=0){

        if(castPossess(o))o.ghostCooldown=sk.possessCooldownMax||15;
        else o.ghostCooldown=.7;

        return;

    }

    if(o.dimCooldown<=0){

        if(castDimension(o))o.dimCooldown=sk.dimCooldownMax||20;
        else o.dimCooldown=.7;

    }

}


function updateDaze(o,dt){

    o.dazeTimer-=dt;

    o.dazeJit=(o.dazeJit||0)-dt;

    if(o.dazeJit<=0){

        o.dazeJit=.25;

        const a=Math.random()*Math.PI*2;

        o.vx=Math.cos(a)*(90+Math.random()*80);
        o.vy=Math.sin(a)*(90+Math.random()*80);

    }

}


/* ==================================================
   REGEN
================================================== */

function regenTeam(o){

    const skill=
        SKILLS[o.skill];

    if(!skill?.regen)return;

    /* PASIF: pulihkan diri sendiri 20% HP tiap 6 detik */

    o.regenCooldown-=
        currentDelta;

    if(o.regenCooldown<=0){

        o.regenCooldown=6;

        o.hp=
            Math.min(
                o.maxHp,
                o.hp+o.maxHp*.20
            );

        burstParticles(
            o.x,
            o.y,
            18,
            "heal"
        );

        sound("heal");

        slowMotion=.35;

    }

    /* SKILL: SAMBUNG KE SATU TEMAN (HEAL 10 HP / 2 DETIK, PERMANEN) */

    const L=o.regenLink;

    if(
        L &&
        (L.hp<=0||L.dead||L.team!==o.team)
    ){
        o.regenLink=null;
    }

    if(!o.regenLink&&!o.manual){

        const mates=
            objects.filter(
                x=>
                    x.type==="character" &&
                    x!==o &&
                    x.team===o.team &&
                    x.hp>0
            );

        if(mates.length){
            o.regenLink=
                mates[Math.floor(Math.random()*mates.length)];
            o.linkT=2;
        }

    }

    if(o.regenLink){

        o.linkT=(o.linkT===undefined?2:o.linkT)-currentDelta;

        if(o.linkT<=0){

            o.linkT=2;

            const t=o.regenLink;

            t.hp=Math.min(t.maxHp,t.hp+10);

            burstParticles(t.x,t.y,10,"heal");

        }

    }

}


/* ==================================================
   CLONE
================================================== */

/* ==================================================
   CLONE SKILL (REVAMPED)
   - 1 clone dilepas, bisa bergerak,
     punya HP & damage sendiri
   - Setiap clone bisa clone lagi
     tiap 4 detik, HP makin tipis
     tiap generasi
================================================== */

const CLONE_BASE_HP=55;
const CLONE_HP_FACTOR=.55;
const CLONE_MIN_HP=10;
const CLONE_DAMAGE=22;
const CLONE_FIRE_COOLDOWN=1.1;
const CLONE_SPAWN_COOLDOWN=4;
const CLONE_MAX_PER_LINEAGE=10;


function spawnCloneUnit(
    x,
    y,
    team,
    generation,
    lineageId
){

    const maxHp=
        Math.max(
            CLONE_MIN_HP*.5,

            CLONE_BASE_HP*
            Math.pow(
                CLONE_HP_FACTOR,
                generation-1
            )
        );


    clones.push({

        id:idCounter++,

        x,y,

        vx:
            (Math.random()<.5?-1:1)*
            (60+Math.random()*80),

        vy:
            (Math.random()<.5?-1:1)*
            (50+Math.random()*70),

        team,

        angle:0,

        hp:maxHp,

        maxHp:maxHp,

        damage:CLONE_DAMAGE,

        generation,

        lineageId,

        radius:18,

        recoil:0,

        fireCooldown:
            .2+Math.random()*.6,

        spawnCooldown:
            CLONE_SPAWN_COOLDOWN,

        dead:false

    });

}


function createClones(o){

    if(o.cloneUsed)return;

    o.cloneUsed=true;

    spawnCloneUnit(
        o.x,
        o.y,
        o.team,
        1,
        o.id
    );

    burstParticles(
        o.x,
        o.y,
        25,
        "clone"
    );

    sound("cloneSpawn");

}


/* ==================================================
   BULLET COLLISION
================================================== */

function checkBulletCollision(){

    for(
        const bullet of bullets
    ){

        if(bullet.hit)
            continue;


        let hitCharacter=false;


        for(
            const target of objects
        ){

            if(
                target.type!=="character" ||
                target.hp<=0 ||
                target.team===bullet.owner
            )continue;


            const distance=
                Math.hypot(
                    bullet.x-target.x,
                    bullet.y-target.y
                );


            if(
                distance<
                target.radius+7
            ){

                damageTarget(
                    target,
                    bullet.damage,
                    bullet
                );

                bullet.hit=true;

                hitCharacter=true;

                break;

            }

        }


        if(hitCharacter || bullet.pierce)
            continue;


        for(
            const clone of clones
        ){

            if(
                clone.dead ||
                clone.team===bullet.owner
            )continue;


            const distance=
                Math.hypot(
                    bullet.x-clone.x,
                    bullet.y-clone.y
                );


            if(
                distance<
                (clone.radius||18)+7
            ){

                damageClone(
                    clone,
                    bullet.damage,
                    bullet
                );

                bullet.hit=true;

                break;

            }

        }

    }

}


/* ==================================================
   BOOSTERS
================================================== */

const boosterTypes=[

    {
        type:"shield",
        icon:"🛡️"
    },

    {
        type:"speed",
        icon:"⚡"
    },

    {
        type:"damage",
        icon:"💥"
    },

    {
        type:"heal",
        icon:"❤️"
    },

    {
        type:"rapid",
        icon:"🔥"
    }

];


function spawnBooster(){

    const b=
        boosterTypes[
            Math.floor(
                Math.random()*
                boosterTypes.length
            )
        ];


    boosters.push({

        x:
            50+
            Math.random()*
            (W-100),

        y:
            60+
            Math.random()*
            (H*.58),

        type:b.type,

        icon:b.icon,

        life:8,

        pulse:0

    });


    updateInfo();

}


function collectBooster(
    o,
    b
){

    if(
        b.type==="shield"
    ){

        o.shield=20;

    }


    if(
        b.type==="speed"
    ){

        o.speedBoost=3.55;

    }


    if(
        b.type==="damage"
    ){

        o.damageBoost=1.5;

    }


    if(
        b.type==="heal"
    ){

        o.hp=
            Math.min(
                o.maxHp,

                o.hp+
                o.maxHp*.35
            );

    }


    if(
        b.type==="rapid"
    ){

        o.fireCooldown=
            Math.min(
                o.fireCooldown,
                .15
            );

        o.fireLevel=
            Math.min(
                2.5,
                o.fireLevel+.4
            );

    }


    burstParticles(
        b.x,
        b.y,
        25,
        "boost"
    );

    sound("boost");

}


/* ==================================================
   CLONES UPDATE
================================================== */

function updateClones(delta){

    clones.forEach(c=>{

        if(c.dead)return;


        /*
            MOVEMENT
        */

        c.x+=
            c.vx*delta;

        c.y+=
            c.vy*delta;


        const minX=35;
        const maxX=W-35;

        const minY=45;
        const maxY=H*.68-25;


        if(c.x<minX){
            c.x=minX;
            c.vx=Math.abs(c.vx);
        }

        if(c.x>maxX){
            c.x=maxX;
            c.vx=-Math.abs(c.vx);
        }

        if(c.y<minY){
            c.y=minY;
            c.vy=Math.abs(c.vy);
        }

        if(c.y>maxY){
            c.y=maxY;
            c.vy=-Math.abs(c.vy);
        }


        c.recoil=
            Math.max(
                0,
                c.recoil-delta*4
            );


        /*
            SHOOTING
        */

        c.fireCooldown-=delta;

        if(c.fireCooldown<=0){

            let target=null;
            let best=Infinity;

            objects
            .filter(
                o=>
                    o.type==="character" &&
                    o.hp>0 &&
                    o.team!==c.team
            )
            .forEach(o=>{

                const d=
                    Math.hypot(
                        o.x-c.x,
                        o.y-c.y
                    );

                if(d<best){
                    best=d;
                    target=o;
                }

            });


            if(target){

                c.angle=
                    Math.atan2(
                        target.y-c.y,
                        target.x-c.x
                    );

                bullets.push({

                    x:
                        c.x+
                        Math.cos(c.angle)*26,

                    y:
                        c.y+
                        Math.sin(c.angle)*26,

                    vx:
                        Math.cos(c.angle)*500,

                    vy:
                        Math.sin(c.angle)*500,

                    owner:c.team,

                    shooter:c,

                    target:null,

                    damage:c.damage,

                    life:1.8,

                    hit:false,

                    magnet:false

                });


                c.recoil=1;

                c.fireCooldown=
                    CLONE_FIRE_COOLDOWN;

                burstParticles(
                    c.x,
                    c.y,
                    4,
                    "muzzle"
                );

                sound("shoot");

            }

        }


        /*
            SELF REPLICATION
            TIAP 4 DETIK
        */

        c.spawnCooldown-=delta;

        if(c.spawnCooldown<=0){

            c.spawnCooldown=
                CLONE_SPAWN_COOLDOWN;

            const lineageCount=
                clones.filter(
                    x=>
                        x.lineageId===c.lineageId &&
                        !x.dead
                ).length;

            const childMaxHp=
                c.maxHp*
                CLONE_HP_FACTOR;

            if(
                lineageCount<CLONE_MAX_PER_LINEAGE &&
                childMaxHp>=CLONE_MIN_HP
            ){

                spawnCloneUnit(
                    c.x+(Math.random()-.5)*30,
                    c.y+(Math.random()-.5)*30,
                    c.team,
                    c.generation+1,
                    c.lineageId
                );

                burstParticles(
                    c.x,
                    c.y,
                    10,
                    "clone"
                );

                sound("cloneSpawn");

            }

        }

    });


    clones=
        clones.filter(
            c=>!c.dead
        );

}


function damageClone(
    clone,
    damage,
    bullet=null
){

    if(
        !clone ||
        clone.dead
    )return;


    clone.hp=
        Math.max(
            0,
            clone.hp-damage
        );

    burstParticles(
        clone.x,
        clone.y,
        4,
        "hit"
    );

    hitFlash=.1;

    sound("hit");


    if(bullet){

        const len=
            Math.hypot(
                bullet.vx,
                bullet.vy
            )||1;

        clone.vx+=
            bullet.vx/len*50;

        clone.vy+=
            bullet.vy/len*50;

    }


    if(clone.hp<=0){

        clone.dead=true;

        burstParticles(
            clone.x,
            clone.y,
            14,
            "clone"
        );

    }

}


/* ==================================================
   HOLE SKILL (BLACK HOLE)
================================================== */

function spawnBlackHole(caster){

    const skill=
        SKILLS[caster.skill];

    if(!skill?.holeSkill)return;


    const enemies=
        objects.filter(
            o=>
                o.type==="character" &&
                o.hp>0 &&
                o.team!==caster.team
        );

    if(!enemies.length)return;


    let cx=0;
    let cy=0;

    enemies.forEach(e=>{

        cx+=e.x;
        cy+=e.y;

    });

    cx/=enemies.length;
    cy/=enemies.length;


    blackholes.push({

        x:cx,
        y:cy,

        team:caster.team,

        pullTime:
            skill.holePullTime||1.4,

        pullMax:
            skill.holePullTime||1.4,

        pullRadius:
            skill.holePullRadius||280,

        explodeRadius:
            skill.holeExplodeRadius||130,

        damage:
            skill.holeDamage||10,

        knockback:
            skill.holeKnockback||300,

        stun:
            skill.holeStun||1.2,

        exploded:false,

        life:.5,

        spin:0

    });


    burstParticles(
        cx,
        cy,
        20,
        "clone"
    );

    sound("vortex");

}


function updateBlackholes(delta){

    blackholes=
        blackholes.filter(h=>{

            h.spin+=delta;

            if(!h.exploded){

                h.pullTime-=delta;


                objects
                .filter(
                    o=>
                        o.type==="character" &&
                        o.hp>0 &&
                        o.team!==h.team
                )
                .forEach(e=>{

                    if(e.goldenImmune>0)return;

                    const dx=h.x-e.x;
                    const dy=h.y-e.y;

                    const dist=
                        Math.hypot(dx,dy)||1;

                    if(dist<h.pullRadius){

                        const pull=550;

                        e.vx=
                            (dx/dist)*pull;

                        e.vy=
                            (dy/dist)*pull;

                    }

                });


                if(h.pullTime<=0){

                    h.exploded=true;
                    h.life=.4;

                    sound("boom");

                    slowMotion=1;


                    objects
                    .filter(
                        o=>
                            o.type==="character" &&
                            o.hp>0 &&
                            o.team!==h.team
                    )
                    .forEach(e=>{

                        if(e.goldenImmune>0)return;

                        const dist=
                            Math.hypot(
                                e.x-h.x,
                                e.y-h.y
                            );

                        if(dist<=h.explodeRadius){

                            damageTarget(
                                e,
                                h.damage
                            );

                            const dx=
                                (e.x-h.x)/
                                (dist||1);

                            const dy=
                                (e.y-h.y)/
                                (dist||1);

                            e.vx=
                                dx*h.knockback;

                            e.vy=
                                dy*h.knockback;

                            e.stunTimer=
                                h.stun;

                        }

                    });


                    burstParticles(
                        h.x,
                        h.y,
                        45,
                        "nuclear"
                    );

                }

            }
            else{

                h.life-=delta;

            }

            return(
                h.exploded
                ?h.life>0
                :true
            );

        });

}


/* ==================================================
   EXPLOSION SHOCKWAVE (VISUAL)
================================================== */

function updateExplosions(delta){

    explosions=
        explosions.filter(e=>{

            e.life-=delta;

            return e.life>0;

        });

}


function drawExplosions(){

    explosions.forEach(e=>{

        const t=
            1-
            Math.max(
                0,
                e.life/e.max
            );

        ctx.save();

        ctx.globalAlpha=
            Math.max(
                0,
                1-t
            );

        ctx.strokeStyle="#ffb84d";

        ctx.lineWidth=6;

        ctx.beginPath();

        ctx.arc(
            e.x,
            e.y,
            e.radius*t,
            0,
            Math.PI*2
        );

        ctx.stroke();


        ctx.strokeStyle="#fff3d0";

        ctx.lineWidth=2;

        ctx.beginPath();

        ctx.arc(
            e.x,
            e.y,
            e.radius*t*.6,
            0,
            Math.PI*2
        );

        ctx.stroke();


        ctx.restore();

    });

}


/* ==================================================
   DEAD SKILL ULTIMATE
================================================== */

function triggerDeadUltimate(caster){

    const enemies=
        objects.filter(
            o=>
                o.type==="character" &&
                o.hp>0 &&
                o.team!==caster.team
        );

    if(!enemies.length)return;


    sound("voidkill");

    slowMotion=1.5;

    hitFlash=.4;


    enemies.forEach(e=>{

        if(e.goldenImmune>0){

            burstParticles(e.x,e.y,12,"shield");

            sound("immuneBlock");

            return;

        }

        e.shield=0;

        e.hp=0;

        killCharacter(e);

        burstParticles(
            e.x,
            e.y,
            40,
            "nuclear"
        );

        explosions.push({

            x:e.x,
            y:e.y,

            radius:90,

            life:.5,
            max:.5

        });

    });


    burstParticles(
        caster.x,
        caster.y,
        30,
        "clone"
    );

}


/* ==================================================
   TIME SKILL
================================================== */

function triggerSniperPierce(o){

    o.pierceNext=true;

    o.fireCooldown=Math.min(o.fireCooldown,.3);

    burstParticles(
        o.x,
        o.y,
        14,
        "boost"
    );

    sound("sniperShot");

}


function triggerTimeSkill(caster){

    const skill=
        SKILLS[caster.skill];

    if(!skill?.timeSkill)return;


    const enemies=
        objects.filter(
            o=>
                o.type==="character" &&
                o.hp>0 &&
                o.team!==caster.team
        );

    if(!enemies.length)return;


    let target=enemies[0];
    let best=Infinity;

    enemies.forEach(e=>{

        const d=
            Math.hypot(
                e.x-caster.x,
                e.y-caster.y
            );

        if(d<best){
            best=d;
            target=e;
        }

    });


    timeFreeze={

        caster,
        target,

        elapsed:0,

        duration:
            skill.timeDuration||3,

        fireTimer:0,

        rate:
            skill.timeFireRate||.12,

        damage:
            skill.timeDamage||skill.damage||25,

        pendingHits:[]

    };


    sound("timeStart");

    burstParticles(
        caster.x,
        caster.y,
        30,
        "shield"
    );

}


function updateTimeFreeze(delta){

    if(!timeFreeze)return;


    const caster=
        timeFreeze.caster;

    if(
        !caster ||
        caster.hp<=0
    ){

        timeFreeze=null;

        return;

    }


    timeFreeze.elapsed+=
        delta;

    timeFreeze.fireTimer-=
        delta;


    if(
        timeFreeze.fireTimer<=0 &&
        timeFreeze.target &&
        timeFreeze.target.hp>0
    ){

        timeFreeze.fireTimer=
            timeFreeze.rate;

        caster.angle=
            Math.atan2(
                timeFreeze.target.y-caster.y,
                timeFreeze.target.x-caster.x
            );

        timeFreeze.pendingHits.push({

            target:
                timeFreeze.target,

            damage:
                timeFreeze.damage

        });


        caster.recoil=1;

        burstParticles(
            caster.x+
            Math.cos(caster.angle)*38,

            caster.y+
            Math.sin(caster.angle)*38,

            4,

            "muzzle"
        );

        sound("timeShot");

    }


    if(
        timeFreeze.elapsed>=
        timeFreeze.duration
    ){

        const hits=
            timeFreeze.pendingHits;

        hits.forEach(h=>{

            if(
                h.target &&
                h.target.hp>0
            ){

                damageTarget(
                    h.target,
                    h.damage
                );

            }

        });


        sound("timeEnd");

        burstParticles(
            caster.x,
            caster.y,
            20,
            "boost"
        );

        timeFreeze=null;

    }

}


/* ==================================================
   ANGEL SKILL
================================================== */

function triggerAngelRevive(
    caster,
    deadTeammates
){

    deadTeammates.forEach(t=>{

        t.dead=false;

        t.hp=t.maxHp;

        t.shield=0;

        t.shieldTimer=0;

        t.stunTimer=0;

        t.immuneTimer=0;

        burstParticles(
            t.x,
            t.y,
            25,
            "heal"
        );

    });


    sound("angelRevive");

    burstParticles(
        caster.x,
        caster.y,
        30,
        "heal"
    );

    slowMotion=.6;


    caster.hp=0;

    killCharacter(caster);

}


/* ==================================================
   HUNTER SKILL
================================================== */

function triggerHunterBarrage(caster){

    const skill=
        SKILLS[caster.skill];

    if(!skill?.hunterSkill)return;


    const enemies=
        objects.filter(
            o=>
                o.type==="character" &&
                o.hp>0 &&
                o.team!==caster.team
        );

    if(!enemies.length)return;


    let target=enemies[0];
    let best=Infinity;

    enemies.forEach(e=>{

        const d=
            Math.hypot(
                e.x-caster.x,
                e.y-caster.y
            );

        if(d<best){
            best=d;
            target=e;
        }

    });


    const baseAngle=
        Math.atan2(
            target.y-caster.y,
            target.x-caster.x
        );

    const extraCount=
        skill.hunterExtraPistols||5;


    for(
        let i=0;
        i<extraCount;
        i++
    ){

        const spread=
            (Math.random()-.5)*.5;

        const a=
            baseAngle+spread;

        bullets.push({

            x:
                caster.x+
                Math.cos(a)*30,

            y:
                caster.y+
                Math.sin(a)*30,

            vx:
                Math.cos(a)*520,

            vy:
                Math.sin(a)*520,

            owner:caster.team,

            shooter:caster,

            target:null,

            damage:
                skill.damage||35,

            life:1.8,

            hit:false,

            magnet:false

        });

    }


    caster.immuneTimer=
        skill.hunterImmuneTime||2;


    burstParticles(
        caster.x,
        caster.y,
        20,
        "muzzle"
    );

    sound("hunterBarrage");

}


/* ==================================================
   GOLDENTIME
   (ULANG WAKTU 5 DETIK -> KEBAL 5 DETIK)
================================================== */

function recordTimeHistory(o,dt){

    if(o.tlRewind||o.goldenRewind)return;

    o.tClock=(o.tClock||0)+dt;

    if(!o.tHist)o.tHist=[];

    o.tHist.push({

        t:o.tClock,

        x:o.x,
        y:o.y,

        hp:o.hp

    });

    while(
        o.tHist.length &&
        o.tHist[0].t<o.tClock-5.5
    ){

        o.tHist.shift();

    }

}


function updateTimeRewind(o,dt){

    const r=o.tlRewind;

    if(!r)return;

    r.t+=dt;

    o.stunTimer=Math.max(o.stunTimer,.15);

    o.vx=0;
    o.vy=0;

    const p=
        Math.min(1,r.t/r.dur);

    const pt=
        r.path[
            Math.min(
                r.path.length-1,
                Math.floor(
                    p*(r.path.length-1)
                )
            )
        ];

    o.x=pt.x;
    o.y=pt.y;

    if(Math.random()<.5){

        burstParticles(
            o.x,
            o.y,
            1,
            "clone"
        );

    }

    if(p>=1){

        const end=
            r.path[r.path.length-1];

        o.hp=
            Math.min(
                o.maxHp,
                o.hp+
                Math.max(0,end.hp-o.hp)*.10
            );

        o.tlRewind=null;

        o.tHist=[];

        o.vx=
            (Math.random()<.5?-1:1)*
            (70+Math.random()*100);

        o.vy=
            (Math.random()<.5?-1:1)*
            (50+Math.random()*90);

    }

}


function updateGoldenTime(o,dt){

    const gs=SKILLS[o.skill];

    if(!gs||!gs.goldenSkill)return;

    if(o.goldenImmune>0)o.goldenImmune=Math.max(0,o.goldenImmune-dt);

}


/* ==================================================
   START DUEL
================================================== */

function startDuel(){

    endAllGhost();

    objects.forEach(o=>{

        if(o.type==="character"&&o.sealedSkill){

            o.skill=o.sealedSkill;

            o.sealedSkill=null;

            o.sealTimer=0;

        }

    });


    const chars=
        objects.filter(
            o=>
                o.type==="character"
        );


    if(
        !chars.some(
            o=>o.team==="blue"
        )
    ){

        addCharacter(
            W*.25,
            H*.5,
            "blue",
            "normal"
        );

    }


    if(
        !chars.some(
            o=>o.team==="red"
        )
    ){

        addCharacter(
            W*.75,
            H*.5,
            "red",
            "normal"
        );

    }


    objects
    .filter(
        o=>
            o.type==="character"
    )
    .forEach(o=>{

        o.hp=o.maxHp;

        o.dead=false;

        o.shield=0;

        o.shieldTimer=0;

        o.speedBoost=1;

        o.damageBoost=1;

        o.fireLevel=1;

        cdStart(o);

        o.cloneUsed=false;

        o.stunTimer=0;

        o.deadSurvive=0;

        o.deadTriggered=false;

        o.angelUsed=false;

        o.immuneTimer=0;

        o.goldenImmune=0;

        o.goldenClock=0;

        o.goldenHistory=[];

        o.goldenRewind=null;

        if(o.fateUsed&&o.fateBase)o.damageBoost=o.fateBase;

        o.fateUsed=false;

        o.fateBase=0;

        o.dimBuff=false;

        o.hipoCooldown=3;

        o.pierceNext=false;

        o.tHist=[];

        o.tClock=0;

        o.tlRewind=null;

        o.lsZone=null;

        o.iceZone=null;

        o.iceSlow=0;

        o.iceFrost=0;

        o.samFx=null;

        o.samSeq=null;

        o.radT=0;

        o.dazeTimer=0;

        o.lastHitBy=null;
        o.possessing=null;
        o.possessedBy=null;
        o.ghostIn=false;
        o.possT=0;
        o.regenLink=null;
        o.linkT=2;
        o.mcd2=(SKILLS[o.skill]&&SKILLS[o.skill].ghostSkill)?(SKILLS[o.skill].dimCooldownMax||20):2;
        o.mcdMax2=o.mcd2;

        o.sealTimer=0;

        o.sealedSkill=null;

        o.fireCooldown=
            .4+
            Math.random()*.8;


        o.vx=
            (Math.random()<.5?-1:1)*
            (70+Math.random()*100);


        o.vy=
            (Math.random()<.5?-1:1)*
            (50+Math.random()*90);

    });


    bullets=[];
    particles=[];
    clones=[];
    boosters=[];
    blackholes=[];
    explosions=[];
    timeFreeze=null;
    dimension=null;
    spirits=[];

    boosterTimer=0;
    winnerTimer=0;

    duelMode=true;

    document.getElementById(
        "duel"
    ).textContent=
        "⏹ Stop Duel";

    sound("boost");

}


/* ==================================================
   STOP
================================================== */

function stopDuel(){

    endAllGhost();

    duelMode=false;

    document.getElementById(
        "duel"
    ).textContent=
        "⚔️ Duel";

}


/* ==================================================
   BUTTONS
================================================== */

const selectBtn=
    document.getElementById("select");

const eraseBtn=
    document.getElementById("eraser");


selectBtn.onclick=()=>{

    mode="select";

    selectBtn.classList.add("active");

    eraseBtn.classList.remove(
        "active"
    );

};


eraseBtn.onclick=()=>{

    mode="eraser";

    eraseBtn.classList.add("active");

    selectBtn.classList.remove(
        "active"
    );

};


/* ==================================================
   ADD BUTTON
================================================== */

document.getElementById(
    "add"
).onclick=()=>{

    document.getElementById(
        "teamModal"
    ).style.display="flex";

};


document.getElementById(
    "cancelTeam"
).onclick=()=>{

    document.getElementById(
        "teamModal"
    ).style.display="none";

};


/* ==================================================
   TEAM SELECTION
================================================== */

function chooseTeam(team){

    pendingTeam=team;

    document.getElementById(
        "teamModal"
    ).style.display="none";

    openSkillMenu();

}


document.getElementById(
    "addBlue"
).onclick=()=>{

    chooseTeam("blue");

};


document.getElementById(
    "addRed"
).onclick=()=>{

    chooseTeam("red");

};


/* ==================================================
   SKILL MENU
================================================== */

function openSkillMenu(){

    const grid=
        document.getElementById(
            "skillGrid"
        );

    grid.innerHTML="";


    Object.keys(SKILLS)
    .forEach(key=>{

        const s=
            SKILLS[key];

        const btn=
            document.createElement(
                "button"
            );

        btn.textContent=
            s.icon+
            " "+
            s.name;

        btn.onclick=()=>{

            createSelectedCharacter(
                pendingTeam,
                key
            );

        };

        grid.appendChild(btn);

    });


    document.getElementById(
        "skillModal"
    ).style.display="flex";

}


function createSelectedCharacter(
    team,
    skill
){

    document.getElementById(
        "skillModal"
    ).style.display="none";


    const count=
        objects.filter(
            o=>
                o.type==="character"
        ).length;


    if(count>=12){

        alert(
            "Maksimal 12 karakter."
        );

        return;

    }


    const x=
        team==="blue"
        ?W*(.12+Math.random()*.32)
        :W*(.56+Math.random()*.32);


    const y=
        H*(.18+Math.random()*.45);


    const obj=
        addCharacter(
            x,
            y,
            team,
            skill
        );


    selected=obj;

}


/* ==================================================
   CANCEL SKILL
================================================== */

document.getElementById(
    "cancelSkill"
).onclick=()=>{

    document.getElementById(
        "skillModal"
    ).style.display="none";

};


/* ==================================================
   RESET
================================================== */

document.getElementById(
    "reset"
).onclick=()=>{

    objects=[];
    bullets=[];
    particles=[];
    boosters=[];
    clones=[];
    blackholes=[];
    explosions=[];
    timeFreeze=null;

    selected=null;

    stopDuel();


    addCharacter(
        W*.25,
        H*.5,
        "blue",
        "normal"
    );


    addCharacter(
        W*.75,
        H*.5,
        "red",
        "normal"
    );


    addObject(
        W*.5,
        H*.5
    );


    updateInfo();

};


/* ==================================================
   DUEL
================================================== */

document.getElementById(
    "duel"
).onclick=()=>{

    if(duelMode){

        stopDuel();

    }
    else{

        startDuel();

    }

};


/* ==================================================
   MODAL
================================================== */

document.getElementById(
    "close"
).onclick=()=>{

    document.getElementById(
        "modal"
    ).style.display="none";

};


document.getElementById(
    "again"
).onclick=()=>{

    document.getElementById(
        "modal"
    ).style.display="none";

    startDuel();

};


/* ==================================================
   DRAW BOOSTER
================================================== */

function drawBooster(b){

    b.pulse+=.08;

    const scale=
        1+
        Math.sin(b.pulse)*.08;


    ctx.save();

    ctx.translate(
        b.x,
        b.y
    );

    ctx.scale(
        scale,
        scale
    );


    ctx.fillStyle="#101827";

    ctx.beginPath();

    ctx.arc(
        0,
        0,
        21,
        0,
        Math.PI*2
    );

    ctx.fill();


    ctx.strokeStyle="#ffffff66";

    ctx.lineWidth=2;

    ctx.stroke();


    ctx.font="20px Arial";

    ctx.textAlign="center";

    ctx.textBaseline="middle";

    ctx.fillText(
        b.icon,
        0,
        1
    );


    ctx.restore();

}


/* ==================================================
   DRAW BLACK HOLE
================================================== */

function drawBlackHole(h){

    ctx.save();

    ctx.translate(
        h.x,
        h.y
    );


    if(!h.exploded){

        const grow=
            1-
            Math.max(
                0,
                h.pullTime/h.pullMax
            );

        const radius=
            16+
            grow*22;


        const grad=
            ctx.createRadialGradient(
                0,0,2,
                0,0,radius+18
            );

        grad.addColorStop(
            0,
            "#000000"
        );

        grad.addColorStop(
            .6,
            "#1a0f2acc"
        );

        grad.addColorStop(
            1,
            "#1a0f2a00"
        );

        ctx.fillStyle=grad;

        ctx.beginPath();

        ctx.arc(
            0,0,
            radius+18,
            0,
            Math.PI*2
        );

        ctx.fill();


        ctx.fillStyle="#000";

        ctx.beginPath();

        ctx.arc(
            0,0,
            radius,
            0,
            Math.PI*2
        );

        ctx.fill();


        ctx.strokeStyle="#b87cffcc";

        ctx.lineWidth=2;

        for(
            let i=0;
            i<3;
            i++
        ){

            ctx.beginPath();

            ctx.arc(
                0,0,
                radius+6+i*5,
                h.spin*3+i,
                h.spin*3+i+2.2
            );

            ctx.stroke();

        }

    }
    else{

        const t=
            1-
            Math.max(
                0,
                h.life/.4
            );

        ctx.globalAlpha=
            Math.max(
                0,
                1-t
            );

        ctx.strokeStyle="#ffe08a";

        ctx.lineWidth=4;

        ctx.beginPath();

        ctx.arc(
            0,0,
            h.explodeRadius*t,
            0,
            Math.PI*2
        );

        ctx.stroke();

    }


    ctx.restore();

}


/* ==================================================
   DRAW OBJECT
================================================== */

function drawObject(o){

    ctx.save();

    ctx.translate(
        o.x,
        o.y
    );

    ctx.rotate(
        o.angle
    );


    ctx.fillStyle="#dce2ed";

    ctx.fillRect(
        -35,
        -8,
        60,
        16
    );


    ctx.fillStyle="#66748e";

    ctx.fillRect(
        15,
        -5,
        28,
        10
    );


    ctx.fillStyle="#303b52";

    ctx.fillRect(
        -22,
        6,
        17,
        14
    );


    ctx.restore();

}


/* ==================================================
   DRAW CHARACTER
================================================== */

function drawCharacter(o){

    ctx.save();

    if(dimension&&o.dimId!==1)ctx.globalAlpha=.28;

    ctx.translate(
        o.x,
        o.y
    );


    /*
        SELECTION
    */

    if(selected===o){

        ctx.strokeStyle="#ffffffaa";

        ctx.lineWidth=2;

        ctx.beginPath();

        ctx.arc(
            0,
            0,
            31,
            0,
            Math.PI*2
        );

        ctx.stroke();

    }


    /*
        PHASE SHIELD
    */

    if(o.shield>0){

        ctx.strokeStyle="#72dfffcc";

        ctx.lineWidth=4;

        ctx.beginPath();

        ctx.arc(
            0,
            0,
            35+
            Math.sin(
                performance.now()/3
            )*2,
            0,
            Math.PI*2
        );

        ctx.stroke();

    }


    /*
        DEAD SKILL
        CHARGE RING
    */

    if(
        SKILLS[o.skill]?.deadSkill &&
        !o.deadTriggered
    ){

        const progress=
            Math.min(
                1,
                o.deadSurvive/
                (SKILLS[o.skill].deadSurviveTime||10)
            );

        ctx.strokeStyle="#c98bffcc";

        ctx.lineWidth=3;

        ctx.beginPath();

        ctx.arc(
            0,
            0,
            35,
            -Math.PI/2,
            -Math.PI/2+
            progress*Math.PI*2
        );

        ctx.stroke();

    }


    /*
        IMMUNE INDICATOR
    */

    if(o.immuneTimer>0){

        ctx.strokeStyle=
            `rgba(255,220,120,${
                .5+
                Math.sin(
                    performance.now()/60
                )*.3
            })`;

        ctx.lineWidth=3;

        ctx.beginPath();

        ctx.arc(
            0,
            0,
            30,
            0,
            Math.PI*2
        );

        ctx.stroke();

    }


    /*
        GOLDENTIME AURA
    */

    if(o.goldenImmune>0 || o.goldenRewind){

        const tt=performance.now()/1000;

        ctx.save();

        if(o.goldenImmune>0){

            const maxImm=
                SKILLS[o.skill]?.goldenImmuneTime||5;

            const frac=
                o.goldenImmune/maxImm;

            ctx.shadowColor="#ffd34d";

            ctx.shadowBlur=18;

            ctx.fillStyle=
                "rgba(255,215,90,.14)";

            ctx.beginPath();

            ctx.arc(0,0,33,0,Math.PI*2);

            ctx.fill();

            ctx.strokeStyle=
                `rgba(255,215,90,${
                    .65+Math.sin(tt*10)*.25
                })`;

            ctx.lineWidth=3;

            ctx.stroke();

            ctx.strokeStyle="#fff3b0";

            ctx.lineWidth=4;

            ctx.beginPath();

            ctx.arc(
                0,
                0,
                39,
                -Math.PI/2,
                -Math.PI/2+Math.PI*2*frac
            );

            ctx.stroke();

        }

        if(o.goldenRewind){

            ctx.rotate(-tt*6);

            ctx.setLineDash([6,6]);

            ctx.strokeStyle="#ffe9a0";

            ctx.shadowColor="#ffd34d";

            ctx.shadowBlur=14;

            ctx.lineWidth=3;

            ctx.beginPath();

            ctx.arc(0,0,36,0,Math.PI*2);

            ctx.stroke();

        }

        ctx.restore();

    }


    /*
        SEGEL HIPO
    */

    if(o.sealTimer>0){

        const tt=performance.now()/1000;

        ctx.save();

        ctx.rotate(tt*3);

        ctx.setLineDash([5,5]);

        ctx.strokeStyle="rgba(190,120,255,.9)";

        ctx.lineWidth=3;

        ctx.beginPath();

        ctx.arc(0,0,34,0,Math.PI*2);

        ctx.stroke();

        ctx.restore();

        ctx.font="bold 12px Arial";

        ctx.textAlign="center";

        ctx.textBaseline="middle";

        ctx.fillStyle="#e3c2ff";

        ctx.fillText("🔒 "+Math.ceil(o.sealTimer),0,-62);

    }


    /*
        STUN INDICATOR
    */

    if(o.stunTimer>0){

        ctx.font=
            "16px Arial";

        ctx.textAlign="center";

        ctx.textBaseline="middle";

        ctx.fillText(
            "💫",
            0,
            -50+
            Math.sin(
                performance.now()/80
            )*3
        );

    }


    /*
        BODY
    */

    ctx.fillStyle=
        o.team==="blue"
        ?" #5da0ff"
        :"#ff6578";

    ctx.fillStyle=
        o.team==="blue"
        ?"#5da0ff"
        :"#ff6578";


    ctx.beginPath();

    ctx.arc(
        0,
        0,
        o.radius,
        0,
        Math.PI*2
    );

    ctx.fill();


    /*
        DEAD
    */

    if(o.hp<=0){

        ctx.globalAlpha=.35;

    }


    /*
        HEAD
    */

    ctx.fillStyle="#f4c7a1";

    ctx.beginPath();

    ctx.arc(
        0,
        -7,
        12,
        0,
        Math.PI*2
    );

    ctx.fill();


    /*
        BODY
    */

    ctx.fillStyle="#202a40";

    ctx.fillRect(
        -14,
        5,
        28,
        18
    );


    /*
        PISTOL
    */

    ctx.save();

    ctx.rotate(
        o.angle
    );

    const mel=!!(SKILLS[o.skill]&&SKILLS[o.skill].melee);

    ctx.strokeStyle=mel?"rgba(0,0,0,0)":"white";

    ctx.lineWidth=4;

    ctx.beginPath();

    ctx.moveTo(
        5,
        0
    );

    ctx.lineTo(
        35,
        0
    );

    ctx.stroke();


    if(o.recoil>0){

        ctx.fillStyle="#ffe08a";

        ctx.globalAlpha=
            o.recoil;

        ctx.beginPath();

        ctx.arc(
            40,
            0,
            7,
            0,
            Math.PI*2
        );

        ctx.fill();

    }


    if(mel){

        const nowT=performance.now();

        const atk=o.samAtk>0;

        const sw=atk?Math.sin(nowT/34)*.85:0;

        ctx.save();

        ctx.lineCap="round";

        /* jejak tebasan (busur cahaya) */

        if(atk){

            ctx.save();

            ctx.shadowColor="#7fd8ff";
            ctx.shadowBlur=14;

            for(let k=0;k<3;k++){

                ctx.globalAlpha=.42-.12*k;
                ctx.strokeStyle=k?"#9fe3ff":"#ffffff";
                ctx.lineWidth=5-1.4*k;

                ctx.beginPath();
                ctx.arc(0,0,46+k*5,sw-1.05-k*.14,sw+.2,false);
                ctx.stroke();

            }

            ctx.restore();

        }

        ctx.rotate(sw);

        /* gagang berlilit */

        ctx.strokeStyle="#2a1a12";
        ctx.lineWidth=5;
        ctx.beginPath();ctx.moveTo(1,0);ctx.lineTo(13,0);ctx.stroke();

        ctx.strokeStyle="#c23a3a";
        ctx.lineWidth=1.6;
        for(let k=0;k<4;k++){
            ctx.beginPath();ctx.moveTo(3+k*3,-2.6);ctx.lineTo(5+k*3,2.6);ctx.stroke();
        }

        /* tsuba emas */

        ctx.fillStyle="#ffd34d";
        ctx.beginPath();ctx.ellipse(14.5,0,2.6,6.6,0,0,Math.PI*2);ctx.fill();

        /* bilah melengkung dengan kilau */

        const bg=ctx.createLinearGradient(15,0,66,0);
        bg.addColorStop(0,"#ffffff");
        bg.addColorStop(.55,"#cfeaff");
        bg.addColorStop(1,"#ffffff");

        ctx.shadowColor="#9fe3ff";
        ctx.shadowBlur=atk?20:10;

        ctx.fillStyle=bg;
        ctx.beginPath();
        ctx.moveTo(16,-2.4);
        ctx.quadraticCurveTo(42,-7.5,68,-1.6);
        ctx.lineTo(70,0.4);
        ctx.quadraticCurveTo(42,2.2,16,2.4);
        ctx.closePath();
        ctx.fill();

        ctx.shadowBlur=0;

        ctx.strokeStyle="rgba(120,170,220,.85)";
        ctx.lineWidth=1;
        ctx.beginPath();ctx.moveTo(18,0.1);ctx.quadraticCurveTo(42,-2.2,66,-.4);ctx.stroke();

        ctx.restore();

    }

    ctx.restore();

    ctx.globalAlpha=1;

    if(o.samFx&&o.samFx.t>0){

        const f=o.samFx,k=Math.min(1,f.t/.35);

        ctx.save();

        ctx.globalAlpha=k;
        ctx.strokeStyle="#ffffff";
        ctx.shadowColor="#7fd8ff";
        ctx.shadowBlur=18;
        ctx.lineWidth=2+6*k;
        ctx.lineCap="round";

        const x0=f.x-o.x,y0=f.y-o.y,x1=f.tx-o.x,y1=f.ty-o.y;

        ctx.beginPath();
        ctx.moveTo(x0,y0);

        for(let i=1;i<8;i++){
            const u=i/8;
            const j=(Math.sin(i*12.9+f.tx)*9)*k;
            ctx.lineTo(x0+(x1-x0)*u+j,y0+(y1-y0)*u-j);
        }

        ctx.lineTo(x1,y1);
        ctx.stroke();

        ctx.restore();

    }


    /*
        HP BAR
    */

    ctx.fillStyle="#111827";

    ctx.fillRect(
        -25,
        -42,
        50,
        6
    );


    ctx.fillStyle="#55d68b";

    ctx.fillRect(
        -25,
        -42,
        50*
        Math.max(
            0,
            o.hp/o.maxHp
        ),
        6
    );


    if(o.mana!==undefined&&duelMode){

        ctx.fillStyle="#0b1325";
        ctx.fillRect(-25,-35,50,3);
        ctx.fillStyle=o.mana>=60?"#5db2ff":"#2f6fbf";
        ctx.fillRect(-25,-35,50*Math.max(0,Math.min(1,o.mana/100)),3);

    }

    /*
        ROLE / SKILL
        DI ATAS KEPALA
    */

    const s=
        SKILLS[o.skill]||
        SKILLS.normal;


    ctx.font=
        "bold 11px Arial";

    ctx.textAlign="center";

    ctx.textBaseline="middle";

    ctx.fillStyle="#ffffff";

    ctx.shadowColor="#000";

    ctx.shadowBlur=4;

    ctx.fillText(
        s.icon+
        " "+
        s.name,
        0,
        -62
    );

    ctx.shadowBlur=0;


    /*
        TEAM LABEL
    */

    ctx.font=
        "bold 8px Arial";

    ctx.fillStyle=
        o.team==="blue"
        ?" #8fc4ff"
        :"#ff9aa8";

    ctx.fillStyle=
        o.team==="blue"
        ?" #8fc4ff"
        :"#ff9aa8";

    ctx.fillStyle=
        o.team==="blue"
        ?"#8fc4ff"
        :"#ff9aa8";

    ctx.fillText(
        o.team==="blue"
        ?"BLUE"
        :"RED",
        0,
        43
    );


    ctx.restore();

}


/* ==================================================
   DRAW CLONE
================================================== */

function drawClone(c){

    if(c.dead)return;

    ctx.save();

    ctx.translate(
        c.x,
        c.y
    );


    const scale=
        Math.max(
            .55,
            1-
            (c.generation-1)*.12
        );


    /*
        RECOIL FLASH
    */

    if(c.recoil>0){

        ctx.globalAlpha=
            .25*c.recoil;

        ctx.fillStyle="#ffffff";

        ctx.beginPath();

        ctx.arc(
            0,
            0,
            20*scale,
            0,
            Math.PI*2
        );

        ctx.fill();

        ctx.globalAlpha=1;

    }


    ctx.globalAlpha=.75;

    ctx.strokeStyle=
        c.team==="blue"
        ?"#67aaff"
        :"#ff7385";

    ctx.lineWidth=3;

    ctx.beginPath();

    ctx.arc(
        0,
        0,
        17*scale,
        0,
        Math.PI*2
    );

    ctx.stroke();


    ctx.fillStyle="#ffffff";

    ctx.beginPath();

    ctx.arc(
        0,
        -3*scale,
        7*scale,
        0,
        Math.PI*2
    );

    ctx.fill();


    /*
        GUN DIRECTION
    */

    ctx.strokeStyle=
        c.team==="blue"
        ?"#67aaff"
        :"#ff7385";

    ctx.lineWidth=3;

    ctx.beginPath();

    ctx.moveTo(0,0);

    ctx.lineTo(
        Math.cos(c.angle)*22*scale,
        Math.sin(c.angle)*22*scale
    );

    ctx.stroke();


    ctx.globalAlpha=1;


    /*
        HP BAR
    */

    ctx.fillStyle="#111827";

    ctx.fillRect(
        -16,
        -30*scale,
        32,
        4
    );

    ctx.fillStyle="#55d68b";

    ctx.fillRect(
        -16,
        -30*scale,
        32*
        Math.max(
            0,
            c.hp/c.maxHp
        ),
        4
    );


    ctx.restore();

}


/* ==================================================
   PARTICLES
================================================== */

function updateParticles(delta){

    particles=
        particles.filter(
            p=>{

                p.life-=delta;

                p.x+=
                    p.vx*delta;

                p.y+=
                    p.vy*delta;

                p.vx*=.94;
                p.vy*=.94;

                return p.life>0;

            }
        );

}


function drawParticles(){

    particles.forEach(p=>{

        ctx.globalAlpha=
            Math.max(
                0,
                p.life/p.max
            );


        if(p.type==="heal")
            ctx.fillStyle="#64ff9b";

        else if(p.type==="shield")
            ctx.fillStyle="#65d9ff";

        else if(p.type==="nuclear")
            ctx.fillStyle="#ffdc66";

        else if(p.type==="clone")
            ctx.fillStyle="#b986ff";

        else if(p.type==="boost")
            ctx.fillStyle="#ffffff";

        else if(p.type==="muzzle")
            ctx.fillStyle="#ffe08a";

        else
            ctx.fillStyle="#ff6578";


        ctx.beginPath();

        ctx.arc(
            p.x,
            p.y,
            p.size,
            0,
            Math.PI*2
        );

        ctx.fill();

    });


    ctx.globalAlpha=1;

}


/* ==================================================
   MAGNET BULLET HOMING
================================================== */

function updateMagnetBullet(
    bullet,
    delta
){

    if(
        !bullet.magnet ||
        !bullet.target ||
        bullet.target.hp<=0
    ){

        return;

    }


    const desired=
        Math.atan2(
            bullet.target.y-bullet.y,
            bullet.target.x-bullet.x
        );


    const current=
        Math.atan2(
            bullet.vy,
            bullet.vx
        );


    let diff=
        desired-current;


    while(
        diff>Math.PI
    )
        diff-=Math.PI*2;


    while(
        diff<-Math.PI
    )
        diff+=Math.PI*2;


    /*
        Magnet mengejar target.
        Turning cukup kuat agar
        peluru bisa membelok sampai kena.
    */

    const turn=
        Math.min(
            Math.abs(diff),
            7*delta
        );


    const newAngle=
        current+
        Math.sign(diff)*turn;


    const speed=
        Math.hypot(
            bullet.vx,
            bullet.vy
        );


    bullet.vx=
        Math.cos(newAngle)*
        speed;

    bullet.vy=
        Math.sin(newAngle)*
        speed;

}


/* ==================================================
   GAME LOOP
================================================== */

/* ==================================================
   GLOBAL v0.03: ANIMASI ULTIMATE TIAP SKILL
================================================== */

let UX=ctx,UW=0,UH=0;

const ULT_META={
    hole:{n:"⚫ BLACK HOLE",c:[184,124,255],d:2.5},
    time:{n:"⏳ TIME STOP",c:[120,220,255],d:2.2},
    goldentime:{n:"🌟 TAKDIR EMAS",c:[255,211,77],d:2.4},
    ghost:{n:"🌀 DIMENSI HANTU",c:[120,255,230],d:2.2},
    nuclear:{n:"☢️ RADIASI NUKLIR",c:[170,255,60],d:2.0},
    lifesteal:{n:"🩸 SEDOT DARAH",c:[255,60,90],d:1.9},
    samurai:{n:"⚔️ TEBASAN KILAT",c:[255,255,255],d:1.4},
    hipo:{n:"🔮 SEGEL HIPO",c:[190,110,255],d:1.9},
    dead:{n:"💀 ULTIMATE KEMATIAN",c:[255,40,60],d:2.3},
    clone:{n:"👥 BANJIR KLON",c:[90,200,255],d:1.7},
    phase:{n:"👻 PERISAI FASE",c:[120,200,255],d:1.5},
    hunter:{n:"🤠 HUJAN PELURU",c:[255,160,60],d:1.6},
    angel:{n:"😇 CAHAYA MALAIKAT",c:[255,240,200],d:2.1},
    sniper:{n:"🎯 TEMBUS",c:[255,70,70],d:1.4},
    regen:{n:"💚 SAMBUNGAN HIDUP",c:[80,255,150],d:1.6},
    speed:{n:"⚡ KECEPATAN CAHAYA",c:[90,230,255],d:1.4},
    magnet:{n:"🧲 MEDAN MAGNET",c:[255,90,120],d:1.8},
    fireshot:{n:"🔥 LEDAKAN API",c:[255,130,40],d:1.6},
    shotgun:{n:"🔫 HANTAMAN",c:[255,200,90],d:1.3},
    burst:{n:"💥 LEDAKAN",c:[255,220,120],d:1.5},
    normal:{n:"🎯 FOKUS",c:[170,200,255],d:1.1}
};

let ultList=[];
const ultLast={};

function ultFx(x,y,key,team){

    const m=ULT_META[key];

    if(!m||window.noUltFx)return;

    const now=performance.now()/1000;

    if(ultLast[key]&&now-ultLast[key]<.9)return;

    ultLast[key]=now;

    ultList.push({k:key,x:x,y:y,t:0,d:m.d,seed:Math.random()*1000,team:team});

    if(ultList.length>3)ultList.shift();

}

function updateUltFx(dt){

    for(let i=ultList.length-1;i>=0;i--){
        ultList[i].t+=dt;
        if(ultList[i].t>=ultList[i].d)ultList.splice(i,1);
    }

}

const uR=(s,i)=>{const v=Math.sin(s*12.9898+i*78.233)*43758.5453;return v-Math.floor(v);};
const uC=(c,a)=>"rgba("+c[0]+","+c[1]+","+c[2]+","+Math.max(0,Math.min(1,a))+")";

function uRing(x,y,r,c,lw,a){
    if(r<=.5||a<=0)return;
    UX.strokeStyle=uC(c,a);
    UX.lineWidth=lw;
    UX.beginPath();
    UX.arc(x,y,r,0,Math.PI*2);
    UX.stroke();
}

function uGlow(x,y,r,c,a){
    if(r<=1||a<=0)return;
    const g=UX.createRadialGradient(x,y,0,x,y,r);
    g.addColorStop(0,uC(c,a));
    g.addColorStop(1,uC(c,0));
    UX.fillStyle=g;
    UX.beginPath();
    UX.arc(x,y,r,0,Math.PI*2);
    UX.fill();
}

function uFlash(c,a){
    if(a<=0)return;
    UX.fillStyle=uC(c,a);
    UX.fillRect(0,0,UW,UH);
}

function uLine(x1,y1,x2,y2,c,lw,a){
    UX.strokeStyle=uC(c,a);
    UX.lineWidth=lw;
    UX.beginPath();
    UX.moveTo(x1,y1);
    UX.lineTo(x2,y2);
    UX.stroke();
}

function uTitle(f,m){

    const tp=f.t/1.2;

    if(tp<1){

        UX.save();

        const a=Math.sin(Math.PI*tp);
        const sc=1+(1-Math.min(1,tp*4))*.5;

        UX.globalAlpha=Math.min(1,a*1.6);
        UX.textAlign="center";
        UX.textBaseline="middle";
        UX.translate(UW/2,UH*.13);
        UX.scale(sc,sc);
        UX.font="900 "+Math.max(18,Math.min(34,UW/22))+"px system-ui,sans-serif";
        UX.lineWidth=5;
        UX.strokeStyle="rgba(0,0,0,.75)";
        UX.strokeText(m.n,0,0);
        UX.fillStyle=uC([Math.min(255,m.c[0]+60),Math.min(255,m.c[1]+60),Math.min(255,m.c[2]+60)],1);
        UX.fillText(m.n,0,0);

        UX.restore();

    }

}

function drawUltFx(){

    if(!ultList.length)return;

    UX=ctx;UW=W;UH=H;

    UX.save();

    UX.setLineDash([]);

    UX.lineCap="round";

    UX.globalCompositeOperation="source-over";

    ultList.forEach(f=>{

        const m=ULT_META[f.k];
        const p=Math.min(1,f.t/f.d);
        const env=Math.sin(Math.PI*Math.min(1,p*1.05));

        UX.save();

        UX.globalAlpha=1;

        try{
            ULT_DRAW[f.k](f,p,f.t,env,m.c);
        }catch(e){}

        UX.restore();

        uTitle(f,m);

    });

    UX.restore();

}

const ULT_DRAW={

    /* ⚫ BLACK HOLE — sinematik epik */
    hole(f,p,t,env,c){

        const cx=f.x,cy=f.y;
        const fadeEnd=1-Math.max(0,(p-.86)/.14);
        const grow=Math.min(1,t/1.5);
        const R0=14+grow*(Math.min(UW,UH)*.1);

        /* langit menggelap */
        uFlash([4,0,14],Math.min(1,t/.45)*.62*fadeEnd);

        /* bintang tersedot dari tepi layar */
        for(let i=0;i<46;i++){
            const u=((t*.55+uR(f.seed,i))%1);
            const ang=uR(f.seed,i+100)*Math.PI*2;
            const far=Math.max(UW,UH)*.75*(1-u*u);
            const near=far*.86;
            const sw=ang+u*2.4;
            uLine(cx+Math.cos(sw)*far,cy+Math.sin(sw)*far*.8,cx+Math.cos(sw+.07)*near,cy+Math.sin(sw+.07)*near*.8,[255,240,255],1.5,(.15+u*.6)*fadeEnd);
        }

        /* kabut ungu & lensa gravitasi */
        uGlow(cx,cy,R0*6,[120,50,230],.5*grow*fadeEnd);
        uGlow(cx,cy,R0*3.2,[255,120,60],.35*grow*fadeEnd);

        for(let k=0;k<4;k++){
            const wob=Math.sin(t*5+k*1.7)*3;
            uRing(cx,cy,R0*(1.9+k*.55)+wob,[200,160,255],1.2,(.28-k*.05)*grow*fadeEnd);
        }

        /* cakram akresi: dua bidang miring */
        [[-.38,.3,1],[.5,.22,-1]].forEach((cfg,ci)=>{
            UX.save();
            UX.translate(cx,cy);
            UX.rotate(cfg[0]);
            UX.scale(1,cfg[1]);
            for(let i=0;i<16;i++){
                const r=R0*(1.25+i*.17+ci*.1);
                const q=i/15;
                const col=[255-q*95,170-q*100,60+q*190];
                const rot=t*cfg[2]*(4.2-i*.2)+i;
                UX.strokeStyle=uC(col,(.75-q*.5)*grow*fadeEnd);
                UX.lineWidth=Math.max(1,4.2-i*.2);
                UX.beginPath();
                UX.arc(0,0,r,rot,rot+2.5+q*1.6);
                UX.stroke();
            }
            UX.restore();
        });

        /* partikel spiral masuk */
        for(let i=0;i<90;i++){
            const u=((t*.8+uR(f.seed,i+300))%1);
            const rad=R0*(.9+6.5*(1-u)*(1-u));
            const ang=uR(f.seed,i+500)*Math.PI*2+u*7+t*1.8;
            const px=cx+Math.cos(ang)*rad;
            const py=cy+Math.sin(ang)*rad*.55;
            const q=u;
            UX.fillStyle=uC([255-q*80,200-q*140,120+q*135],(.2+q*.8)*grow*fadeEnd);
            UX.beginPath();
            UX.arc(px,py,Math.max(.6,2.6*(1-q)+.6),0,Math.PI*2);
            UX.fill();
        }

        /* cincin foton + horizon hitam */
        uRing(cx,cy,R0*1.1,[255,236,210],3.5,.95*fadeEnd);
        uRing(cx,cy,R0*1.18,[255,150,60],2,.7*fadeEnd);
        UX.fillStyle="#000";
        UX.globalAlpha=fadeEnd;
        UX.beginPath();
        UX.arc(cx,cy,R0,0,Math.PI*2);
        UX.fill();
        UX.globalAlpha=1;

        /* ledakan akhir */
        if(p>.7){
            const q=(p-.7)/.3;
            for(let k=0;k<4;k++){
                const qq=Math.max(0,q-k*.1);
                uRing(cx,cy,qq*Math.max(UW,UH)*.7,[255-k*30,220-k*60,255],6-k,(1-qq)*.9);
            }
            uFlash([255,240,255],Math.max(0,.55-q*1.4));
            uGlow(cx,cy,R0*(1+q*4),[255,255,255],(1-q)*.8);
        }

    },

    /* ⏳ TIME STOP */
    time(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([140,200,230],env*.28);
        const r=Math.min(1,t/.5)*Math.max(UW,UH)*.55;
        uRing(cx,cy,r,c,5,.8*(1-p*.7));
        uRing(cx,cy,r*.7,[255,255,255],2,.6*(1-p));
        uGlow(cx,cy,90+env*40,c,.5*env);
        UX.save();
        UX.translate(cx,cy);
        const cr=70;
        uRing(0,0,cr,[255,255,255],4,.9*env);
        for(let i=0;i<12;i++){
            const a=i*Math.PI/6;
            uLine(Math.cos(a)*(cr-10),Math.sin(a)*(cr-10),Math.cos(a)*cr,Math.sin(a)*cr,[255,255,255],3,.9*env);
        }
        uLine(0,0,Math.cos(t*14)*(cr-18),Math.sin(t*14)*(cr-18),[255,255,255],4,env);
        uLine(0,0,Math.cos(t*1.5-1.5)*(cr-34),Math.sin(t*1.5-1.5)*(cr-34),[160,230,255],5,env);
        UX.restore();
        for(let i=0;i<30;i++){
            const a=uR(f.seed,i)*Math.PI*2;
            const d=60+((t*120+uR(f.seed,i+9)*200)%260);
            uLine(cx+Math.cos(a)*d,cy+Math.sin(a)*d,cx+Math.cos(a)*(d+14),cy+Math.sin(a)*(d+14),[220,245,255],2,.5*env);
        }
    },

    /* 🌟 TAKDIR EMAS */
    goldentime(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([255,225,120],Math.max(0,.55-t*1.1)+env*.1);
        const bw=30+env*60;
        const g=UX.createLinearGradient(0,0,0,cy+30);
        g.addColorStop(0,uC([255,240,170],0));
        g.addColorStop(1,uC([255,215,90],.85*env));
        UX.fillStyle=g;
        UX.fillRect(cx-bw/2,0,bw,cy+30);
        uGlow(cx,cy,130,c,.55*env);
        for(let k=0;k<4;k++){
            const q=Math.max(0,Math.min(1,t/1.3-k*.18));
            uRing(cx,cy,q*190,[255,225,120],4,(1-q)*.9);
        }
        for(const s of[-1,1]){
            UX.save();
            UX.translate(cx,cy-10);
            UX.scale(s,1);
            const open=Math.min(1,t/.7);
            for(let i=0;i<6;i++){
                UX.strokeStyle=uC([255,235,150],(.8-i*.1)*env);
                UX.lineWidth=5-i*.5;
                UX.beginPath();
                UX.arc(14,6+i*5,(34+i*13)*open,-Math.PI*.9+i*.05,-Math.PI*.15);
                UX.stroke();
            }
            UX.restore();
        }
        for(let i=0;i<50;i++){
            const u=((t*.6+uR(f.seed,i))%1);
            const x=cx+(uR(f.seed,i+7)-.5)*220;
            const y=cy+40-u*260;
            UX.fillStyle=uC([255,235,150],(1-u)*env);
            UX.beginPath();
            UX.arc(x,y,2.4*(1-u)+.6,0,Math.PI*2);
            UX.fill();
        }
    },

    /* 🌀 DIMENSI HANTU */
    ghost(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([10,0,30],env*.45);
        for(let i=0;i<14;i++){
            const q=i/13;
            const r=(10+q*160)*Math.min(1,t/.6);
            const a=t*(3-q*2)+i*.7;
            UX.strokeStyle=uC([120+q*100,255-q*140,230],(.8-q*.5)*env);
            UX.lineWidth=3;
            UX.beginPath();
            UX.arc(cx,cy,r,a,a+2.2);
            UX.stroke();
        }
        uGlow(cx,cy,60,[200,255,250],.6*env);
        for(let i=0;i<8;i++){
            const a=uR(f.seed,i)*6.28+t*1.4;
            const d=60+Math.sin(t*3+i)*30+i*14;
            const x=cx+Math.cos(a)*d,y=cy+Math.sin(a)*d*.7;
            UX.fillStyle=uC([210,255,245],.55*env);
            UX.beginPath();
            UX.arc(x,y-6,9,Math.PI,0);
            UX.lineTo(x+9,y+10);
            UX.lineTo(x+4,y+6);UX.lineTo(x,y+11);UX.lineTo(x-4,y+6);UX.lineTo(x-9,y+10);
            UX.closePath();
            UX.fill();
        }
    },

    /* ☢️ NUKLIR */
    nuclear(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([200,255,90],Math.max(0,.6-t*1.3));
        for(let k=0;k<3;k++){
            const q=Math.max(0,Math.min(1,t/1.5-k*.15));
            uRing(cx,cy,q*Math.max(UW,UH)*.75,[190,255,70],8-k*2,(1-q)*.85);
        }
        uGlow(cx,cy,150*Math.min(1,t/.5),[200,255,60],.55*env);
        UX.save();
        UX.translate(cx,cy);
        UX.rotate(t*1.5);
        UX.fillStyle=uC([20,30,0],.85*env);
        UX.beginPath();UX.arc(0,0,16,0,Math.PI*2);UX.fill();
        for(let i=0;i<3;i++){
            UX.fillStyle=uC([200,255,60],.9*env);
            UX.beginPath();
            UX.moveTo(0,0);
            UX.arc(0,0,58,i*Math.PI*2/3-.45,i*Math.PI*2/3+.45);
            UX.closePath();
            UX.fill();
        }
        UX.fillStyle=uC([20,30,0],.95*env);
        UX.beginPath();UX.arc(0,0,14,0,Math.PI*2);UX.fill();
        UX.restore();
        for(let i=0;i<40;i++){
            const u=((t*.7+uR(f.seed,i))%1);
            const x=uR(f.seed,i+3)*UW;
            UX.fillStyle=uC([200,255,60],(1-u)*.7*env);
            UX.beginPath();UX.arc(x,UH*.8-u*UH*.8,2,0,6.28);UX.fill();
        }
    },

    /* 🩸 LIFESTEAL */
    lifesteal(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([120,0,20],env*.25);
        const q=Math.min(1,t/.5);
        uRing(cx,cy,125*q,[255,50,80],4,.9*(1-p*.5));
        uGlow(cx,cy,125,[255,30,60],.3*env);
        for(let i=0;i<60;i++){
            const u=((t*.9+uR(f.seed,i))%1);
            const a=uR(f.seed,i+5)*Math.PI*2+u*2.5;
            const d=170*(1-u);
            UX.fillStyle=uC([255,50,80],(.3+u*.7)*env);
            UX.beginPath();
            UX.ellipse(cx+Math.cos(a)*d,cy+Math.sin(a)*d,2.2,4.2*(1-u*.4),a,0,6.28);
            UX.fill();
        }
        uGlow(cx,cy,40+Math.sin(t*14)*8,[255,120,140],.7*env);
    },

    /* ⚔️ SAMURAI */
    samurai(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([255,40,60],Math.max(0,.3-t*.6));
        for(let i=0;i<3;i++){
            const st=i*.22;
            const q=Math.max(0,Math.min(1,(t-st)/.18));
            if(q<=0)continue;
            const ang=(i%2?-1:1)*(.5+i*.25);
            const len=Math.max(UW,UH)*.8;
            const x1=cx-Math.cos(ang)*len*.5,y1=cy-Math.sin(ang)*len*.5;
            const x2=x1+Math.cos(ang)*len*q,y2=y1+Math.sin(ang)*len*q;
            const fade=Math.max(0,1-(t-st)/.9);
            uLine(x1,y1,x2,y2,[255,255,255],10*fade+2,fade);
            uLine(x1,y1,x2,y2,[255,60,80],20*fade+4,fade*.45);
        }
        uGlow(cx,cy,70,[255,255,255],.35*env);
    },

    /* 🔮 HIPO */
    hipo(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([40,0,70],env*.3);
        UX.save();
        UX.translate(cx,cy);
        UX.rotate(t*.9);
        const r=Math.min(1,t/.4)*115;
        uRing(0,0,r,c,4,.9*env);
        uRing(0,0,r*.82,c,2,.8*env);
        for(let k=0;k<2;k++){
            UX.rotate(k?Math.PI/6:0);
            UX.strokeStyle=uC([220,170,255],.9*env);
            UX.lineWidth=3;
            UX.beginPath();
            for(let i=0;i<3;i++){
                const a=i*Math.PI*2/3-Math.PI/2;
                UX[i?"lineTo":"moveTo"](Math.cos(a)*r*.82,Math.sin(a)*r*.82);
            }
            UX.closePath();
            UX.stroke();
        }
        for(let i=0;i<12;i++){
            const a=i*Math.PI/6;
            UX.fillStyle=uC([240,200,255],.9*env);
            UX.font="16px serif";
            UX.textAlign="center";
            UX.fillText("✦",Math.cos(a)*(r*.92),Math.sin(a)*(r*.92)+5);
        }
        UX.restore();
        uGlow(cx,cy,60,[210,150,255],.55*env);
    },

    /* 💀 DEAD */
    dead(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([0,0,0],env*.6);
        for(let i=0;i<22;i++){
            const a=uR(f.seed,i)*Math.PI*2;
            const len=(60+uR(f.seed,i+3)*Math.max(UW,UH)*.5)*Math.min(1,t/.7);
            let x=cx,y=cy;
            UX.strokeStyle=uC([255,30,50],.75*env);
            UX.lineWidth=2.2;
            UX.beginPath();
            UX.moveTo(x,y);
            for(let s=1;s<=8;s++){
                x=cx+Math.cos(a+Math.sin(s*3+i)*.25)*len*s/8;
                y=cy+Math.sin(a+Math.sin(s*3+i)*.25)*len*s/8;
                UX.lineTo(x,y);
            }
            UX.stroke();
        }
        uRing(cx,cy,Math.min(1,t/.9)*Math.max(UW,UH)*.6,[255,30,50],7,(1-p)*.8);
        const sh=(Math.random()-.5)*5*env;
        UX.font="900 "+(90+env*30)+"px serif";
        UX.textAlign="center";
        UX.textBaseline="middle";
        UX.globalAlpha=env;
        UX.fillText("💀",cx+sh,cy-10+sh);
    },

    /* 👥 CLONE */
    clone(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([20,60,120],env*.22);
        for(let i=0;i<6;i++){
            const a=i*Math.PI/3+t*.8;
            const d=Math.min(1,t/.6)*(70+i*6);
            const x=cx+Math.cos(a)*d,y=cy+Math.sin(a)*d;
            uRing(x,y,22,c,3,.8*env);
            uGlow(x,y,26,c,.4*env);
            uLine(cx,cy,x,y,c,1.5,.4*env);
        }
        uRing(cx,cy,24,[255,255,255],3,.9*env);
        for(let k=0;k<2;k++){
            const q=Math.max(0,Math.min(1,t/1.2-k*.25));
            uRing(cx,cy,q*180,c,3,(1-q)*.7);
        }
        for(let y=0;y<UH;y+=6)uLine(0,y,UW,y,[120,220,255],1,.05*env);
    },

    /* 👻 PHASE */
    phase(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        const r=Math.min(1,t/.35)*62;
        uGlow(cx,cy,r*1.5,c,.45*env);
        UX.strokeStyle=uC([180,235,255],.9*env);
        UX.lineWidth=3;
        for(let i=0;i<6;i++){
            const a=i*Math.PI/3+t*1.5;
            UX.beginPath();
            for(let s=0;s<6;s++){
                const aa=s*Math.PI/3;
                const hx=cx+Math.cos(a)*r*.55+Math.cos(aa)*r*.4,hy=cy+Math.sin(a)*r*.55+Math.sin(aa)*r*.4;
                UX[s?"lineTo":"moveTo"](hx,hy);
            }
            UX.closePath();
            UX.stroke();
        }
        uRing(cx,cy,r,[255,255,255],3,.9*env);
        uRing(cx,cy,r+Math.sin(t*10)*4,c,2,.6*env);
    },

    /* 🤠 HUNTER */
    hunter(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([255,120,20],Math.max(0,.25-t*.6));
        const r=90*(1.6-Math.min(1,t/.35)*.6);
        uRing(cx,cy,r,[255,180,70],3,.9*env);
        uLine(cx-r*1.3,cy,cx+r*1.3,cy,[255,200,100],2,.8*env);
        uLine(cx,cy-r*1.3,cx,cy+r*1.3,[255,200,100],2,.8*env);
        for(let i=0;i<5;i++){
            const q=Math.max(0,Math.min(1,(t-i*.12)/.15));
            if(q<=0)continue;
            const a=-Math.PI/2+(i-2)*.38;
            const fade=Math.max(0,1-(t-i*.12)/.5);
            uLine(cx,cy,cx+Math.cos(a)*220*q,cy+Math.sin(a)*220*q,[255,220,120],4,fade);
            uGlow(cx+Math.cos(a)*30,cy+Math.sin(a)*30,26,[255,200,90],.8*fade);
        }
    },

    /* 😇 ANGEL */
    angel(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([255,250,230],Math.max(0,.5-t)+env*.1);
        const g=UX.createLinearGradient(0,0,0,cy+30);
        g.addColorStop(0,uC([255,255,240],0));
        g.addColorStop(1,uC([255,250,220],.7*env));
        UX.fillStyle=g;
        UX.fillRect(cx-26-env*18,0,52+env*36,cy+30);
        uRing(cx,cy-52,26+Math.sin(t*6)*2,[255,235,140],5,.95*env);
        uGlow(cx,cy-52,50,[255,240,160],.5*env);
        for(let i=0;i<34;i++){
            const u=((t*.45+uR(f.seed,i))%1);
            const x=cx+(uR(f.seed,i+4)-.5)*260+Math.sin(u*9+i)*14;
            const y=cy-130+u*300;
            UX.save();
            UX.translate(x,y);
            UX.rotate(Math.sin(u*7+i)*.8);
            UX.fillStyle=uC([255,255,255],(1-u*.6)*.85*env);
            UX.beginPath();
            UX.ellipse(0,0,3,9,0,0,6.28);
            UX.fill();
            UX.restore();
        }
    },

    /* 🎯 SNIPER */
    sniper(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([0,0,0],env*.35);
        for(let i=0;i<24;i++){
            const a=i*Math.PI/12;
            const r0=Math.max(UW,UH)*(.8-Math.min(1,t/.45)*.65);
            uLine(cx+Math.cos(a)*r0,cy+Math.sin(a)*r0,cx+Math.cos(a)*(r0+60),cy+Math.sin(a)*(r0+60),[255,90,90],1.5,.5*env);
        }
        uRing(cx,cy,56,[255,80,80],2.5,.9*env);
        uLine(cx-90,cy,cx+90,cy,[255,80,80],1.5,.9*env);
        uLine(cx,cy-90,cx,cy+90,[255,80,80],1.5,.9*env);
        const q=Math.max(0,Math.min(1,(t-.35)/.15));
        if(q>0){
            const fade=Math.max(0,1-(t-.35)/.8);
            uLine(cx,cy,cx<UW/2?UW:0,cy,[255,255,255],6,fade);
            uLine(cx,cy,cx<UW/2?UW:0,cy,[255,60,60],12,fade*.5);
            uGlow(cx,cy,60,[255,255,255],fade);
        }
    },

    /* 💚 REGEN */
    regen(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uGlow(cx,cy,120,c,.4*env);
        uRing(cx,cy,Math.min(1,t/.6)*110,c,4,.85*(1-p*.6));
        for(let i=0;i<22;i++){
            const u=((t*.6+uR(f.seed,i))%1);
            const x=cx+(uR(f.seed,i+2)-.5)*140;
            const y=cy+30-u*150;
            UX.strokeStyle=uC([150,255,190],(1-u)*env);
            UX.lineWidth=3;
            UX.beginPath();
            UX.moveTo(x-6,y);UX.lineTo(x+6,y);UX.moveTo(x,y-6);UX.lineTo(x,y+6);
            UX.stroke();
        }
    },

    /* ⚡ SPEED */
    speed(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([20,80,120],env*.18);
        for(let i=0;i<34;i++){
            const y=uR(f.seed,i)*UH;
            const u=((t*1.8+uR(f.seed,i+7))%1);
            const x=(1-u)*UW*1.2-UW*.1;
            uLine(x,y,x+120+uR(f.seed,i+9)*160,y,[160,240,255],2,.55*env);
        }
        uRing(cx,cy,Math.min(1,t/.4)*90,c,4,.8*(1-p*.5));
        uGlow(cx,cy,70,[255,255,255],.35*env);
    },

    /* 🧲 MAGNET */
    magnet(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uGlow(cx,cy,110,c,.3*env);
        for(let i=0;i<36;i++){
            const u=((t*.8+uR(f.seed,i))%1);
            const a=uR(f.seed,i+3)*Math.PI*2;
            const d=260*(1-u);
            const col=i%2?[255,90,120]:[90,140,255];
            UX.fillStyle=uC(col,(.3+u*.7)*env);
            UX.beginPath();
            UX.arc(cx+Math.cos(a)*d,cy+Math.sin(a)*d,2.8,0,6.28);
            UX.fill();
        }
        for(let k=0;k<3;k++){
            const q=1-((t*.9+k/3)%1);
            uRing(cx,cy,q*190,c,2,.5*env*(1-q));
        }
        UX.strokeStyle=uC([255,90,120],.9*env);
        UX.lineWidth=8;
        UX.beginPath();UX.arc(cx,cy,30,Math.PI,0);UX.stroke();
        UX.strokeStyle=uC([90,140,255],.9*env);
        UX.beginPath();UX.arc(cx,cy,30,0,Math.PI);UX.stroke();
    },

    /* 🔥 FIRESHOT */
    fireshot(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([255,100,20],Math.max(0,.4-t*.8));
        uGlow(cx,cy,130,[255,120,30],.6*env);
        for(let i=0;i<60;i++){
            const u=((t*.9+uR(f.seed,i))%1);
            const x=cx+(uR(f.seed,i+2)-.5)*150*(1-u*.4);
            const y=cy+20-u*200;
            UX.fillStyle=uC([255,200-u*140,40],(1-u)*env);
            UX.beginPath();
            UX.ellipse(x,y,6*(1-u)+1,10*(1-u)+2,0,0,6.28);
            UX.fill();
        }
        uRing(cx,cy,Math.min(1,t/.5)*150,[255,160,50],5,(1-p)*.8);
    },

    /* 🔫 SHOTGUN */
    shotgun(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([255,200,90],Math.max(0,.4-t*.9));
        for(let i=0;i<14;i++){
            const a=(i-6.5)*.12-Math.PI/2;
            const q=Math.min(1,t/.25);
            const fade=Math.max(0,1-t/.9);
            uLine(cx+Math.cos(a)*30,cy+Math.sin(a)*30,cx+Math.cos(a)*(30+280*q),cy+Math.sin(a)*(30+280*q),[255,230,150],3,fade);
        }
        uRing(cx,cy,Math.min(1,t/.3)*110,[255,200,90],5,(1-p)*.9);
        uGlow(cx,cy,60,[255,255,200],.7*Math.max(0,1-t*2));
    },

    /* 💥 BURST */
    burst(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uFlash([255,230,150],Math.max(0,.6-t*1.2));
        for(let k=0;k<3;k++){
            const q=Math.max(0,Math.min(1,t/1.0-k*.12));
            uRing(cx,cy,q*220,[255,200-k*40,100],8-k*2,(1-q)*.9);
        }
        uGlow(cx,cy,120*Math.min(1,t/.3),[255,230,150],.8*(1-p));
        for(let i=0;i<26;i++){
            const a=uR(f.seed,i)*Math.PI*2;
            const d=Math.min(1,t/.8)*(60+uR(f.seed,i+5)*190);
            UX.fillStyle=uC([255,210,120],(1-p)*.9);
            UX.beginPath();UX.arc(cx+Math.cos(a)*d,cy+Math.sin(a)*d,3.2,0,6.28);UX.fill();
        }
    },

    /* 🎯 NORMAL */
    normal(f,p,t,env,c){
        const cx=f.x,cy=f.y;
        uRing(cx,cy,Math.min(1,t/.5)*80,c,3,(1-p)*.9);
        uRing(cx,cy,Math.min(1,t/.5)*50,[255,255,255],2,(1-p)*.7);
        uGlow(cx,cy,50,c,.4*env);
    }

};

ULT_META.ice={n:"❄️ DUNIA BEKU",c:[150,225,255],d:2.2};

ULT_DRAW.ice=function(f,p,t,env,c){

    const cx=f.x,cy=f.y;

    uFlash([210,240,255],Math.max(0,.55-t*.9));

    const R=Math.min(1,t/.9)*Math.max(UW,UH)*.9;

    uRing(cx,cy,R,[200,240,255],8,(1-p)*.9);
    uRing(cx,cy,R*.8,[255,255,255],3,(1-p)*.7);
    uRing(cx,cy,R*.55,[120,200,255],4,(1-p)*.6);

    for(let i=0;i<10;i++){
        const a=i*Math.PI/5+t*.5;
        const len=Math.min(1,t/.7)*(90+uR(f.seed,i)*130);
        UX.strokeStyle=uC([220,248,255],env*.9);
        UX.lineWidth=3;
        UX.beginPath();
        UX.moveTo(cx,cy);
        UX.lineTo(cx+Math.cos(a)*len,cy+Math.sin(a)*len);
        UX.stroke();
        for(const s of [-1,1]){
            const bx=cx+Math.cos(a)*len*.65,by=cy+Math.sin(a)*len*.65;
            UX.beginPath();
            UX.moveTo(bx,by);
            UX.lineTo(bx+Math.cos(a+s*.7)*len*.28,by+Math.sin(a+s*.7)*len*.28);
            UX.stroke();
        }
    }

    for(let i=0;i<30;i++){
        const a=uR(f.seed,i+20)*Math.PI*2;
        const d=(40+uR(f.seed,i+50)*260)*Math.min(1,t/.8);
        const x=cx+Math.cos(a)*d,y=cy+Math.sin(a)*d-t*14;
        const sz=4+uR(f.seed,i+70)*7;
        UX.fillStyle=uC([225,248,255],env*.85);
        UX.beginPath();
        UX.moveTo(x,y-sz);UX.lineTo(x+sz*.6,y);UX.lineTo(x,y+sz);UX.lineTo(x-sz*.6,y);
        UX.closePath();UX.fill();
    }

    uGlow(cx,cy,90,[200,240,255],env*.6);

};

ULT_META.shatter={n:"💥 SERANGAN HANCUR!",c:[160,220,255],d:1.4};

ULT_DRAW.shatter=function(f,p,t,env,c){

    const cx=f.x,cy=f.y;

    uFlash([200,235,255],Math.max(0,.5-t*1.4));

    for(let i=0;i<14;i++){
        const a=uR(f.seed,i)*Math.PI*2;
        const len=Math.min(1,t/.25)*(70+uR(f.seed,i+9)*150);
        let x=cx,y=cy;
        UX.strokeStyle=uC([230,248,255],(1-p)*.95);
        UX.lineWidth=Math.max(.6,2.2-p);
        UX.beginPath();
        UX.moveTo(x,y);
        for(let k=1;k<=6;k++){
            const aa=a+(uR(f.seed,i*7+k)-.5)*.5;
            x=cx+Math.cos(aa)*len*k/6;
            y=cy+Math.sin(aa)*len*k/6;
            UX.lineTo(x,y);
        }
        UX.stroke();
    }

    uRing(cx,cy,Math.min(1,t/.6)*190,[160,220,255],5,(1-p)*.9);
    uRing(cx,cy,Math.min(1,t/.8)*120,[255,255,255],2,(1-p)*.7);

    for(let i=0;i<26;i++){
        const a=uR(f.seed,i+40)*Math.PI*2;
        const sp=70+uR(f.seed,i+60)*230;
        const d=sp*Math.min(1,t/1.1);
        const x=cx+Math.cos(a)*d;
        const y=cy+Math.sin(a)*d+t*t*120;
        const sz=5+uR(f.seed,i+80)*9;
        UX.save();
        UX.translate(x,y);
        UX.rotate(t*(4+uR(f.seed,i+90)*6)+i);
        UX.fillStyle=uC([190,230,255],(1-p)*.9);
        UX.beginPath();
        UX.moveTo(-sz,sz*.6);
        UX.lineTo(sz,0);
        UX.lineTo(-sz*.3,-sz);
        UX.closePath();
        UX.fill();
        UX.restore();
    }

    uGlow(cx,cy,70,[255,255,255],Math.max(0,.8-t*1.5));

};

(function(){

    const hook=(name,key,test)=>{

        const orig=window[name];

        if(typeof orig!=="function")return;

        window[name]=function(a){

            const r=orig.apply(this,arguments);

            if(r!==false&&(!test||test(a,r))&&a&&typeof a.x==="number")ultFx(a.x,a.y,key,a.team);

            return r;

        };

    };

    hook("triggerTimeSkill","time",()=>!!timeFreeze);
    hook("triggerHunterBarrage","hunter");
    hook("createClones","clone");
    hook("triggerDeadUltimate","dead");
    hook("startRadiation","nuclear");
    hook("startLifeZone","lifesteal");
    hook("castSlash","samurai");
    hook("castDimension","ghost");
    hook("triggerAngelRevive","angel");
    hook("triggerSniperPierce","sniper");

    const osb=window.spawnBlackHole;

    window.spawnBlackHole=function(c){

        const n=blackholes.length;

        const r=osb.apply(this,arguments);

        if(blackholes.length>n){
            const h=blackholes[blackholes.length-1];
            ultFx(h.x,h.y,"hole",c&&c.team);
        }

        return r;

    };

})();

/* GoldenTime baru: Takdir */

function fateRevive(o){

    const gs=SKILLS[o.skill]||{};

    o.fateUsed=true;
    o.fateBase=o.damageBoost||1;
    o.damageBoost=o.fateBase*(gs.fatePower||1.5);

    o.dead=false;
    o.hp=o.maxHp*(gs.fateHp||.6);
    o.shield=0;
    o.stunTimer=0;
    o.goldenImmune=gs.goldenImmuneTime||2;
    o.fireCooldown=Math.min(o.fireCooldown||0,.3);

    burstParticles(o.x,o.y,40,"heal");

    explosions.push({x:o.x,y:o.y,radius:90,life:.5,max:.5});

    sound("angelRevive");

    slowMotion=.35;

    ultFx(o.x,o.y,"goldentime",o.team);

}

function fateStrike(o){

    const gs=SKILLS[o.skill]||{};

    if(o.fateUsed||o.hp<=0)return false;

    o.fateUsed=true;

    const dmg=(gs.fateStrikeDamage||60)*(o.damageBoost||1);

    objects.forEach(e=>{
        if(e.type==="character"&&e.hp>0&&e.team!==o.team){
            e.lastHitBy=o;
            rawDamage(e,dmg,o);
            burstParticles(e.x,e.y,22,"heal");
            explosions.push({x:e.x,y:e.y,radius:70,life:.4,max:.4});
        }
    });

    sound("boom");

    ultFx(o.x,o.y,"goldentime",o.team);

    return true;

}


function gameLoop(time){

    if(window.fpsGate&&window.fpsGate(time)){

        requestAnimationFrame(gameLoop);

        return;

    }

    const rawDt=(time-lastTime)/1000;

    /* haluskan lonjakan waktu antar-frame agar gerakan tidak tersendat */

    const _dq=(window._dq=window._dq||[]);
    _dq.push(rawDt);
    if(_dq.length>3)_dq.shift();
    const _med=_dq.length<3?rawDt:_dq.slice().sort((a,b)=>a-b)[1];
    window._sdt=(window._sdt&&_med<.2)?(window._sdt*.7+_med*.3):_med;

    const realDelta=
        Math.min(
            window.maxDt||.035,
            window._sdt
        );

    lastTime=time;


    /*
        CINEMATIC SLOW MOTION
    */

    const slowFactor=
        slowMotion>0
        ?.12
        :1;


    currentDelta=
        realDelta*
        slowFactor;


    slowMotion=
        Math.max(
            0,
            slowMotion-realDelta
        );


    hitFlash=
        Math.max(
            0,
            hitFlash-realDelta
        );


    ctx.clearRect(
        0,
        0,
        W,
        H
    );


    /*
        ARENA
    */

    ctx.fillStyle="#263653";

    ctx.fillRect(
        0,
        0,
        W,
        H*.70
    );


    ctx.fillStyle="#172033";

    ctx.fillRect(
        0,
        H*.70,
        W,
        H*.30
    );


    /*
        BORDER
    */

    ctx.strokeStyle="#ffffff22";

    ctx.lineWidth=2;

    ctx.strokeRect(
        12,
        12,
        W-24,
        H*.70-24
    );


    /*
        FLOOR GRID
    */

    ctx.strokeStyle="#ffffff0b";

    ctx.lineWidth=1;


    for(
        let x=0;
        x<W;
        x+=40
    ){

        ctx.beginPath();

        ctx.moveTo(
            x,
            H*.70
        );

        ctx.lineTo(
            x,
            H
        );

        ctx.stroke();

    }


    for(
        let y=H*.70;
        y<H;
        y+=40
    ){

        ctx.beginPath();

        ctx.moveTo(
            0,
            y
        );

        ctx.lineTo(
            W,
            y
        );

        ctx.stroke();

    }


    /*
        ARENA FX
    */

    if(window.drawArenaFX){

        window.drawArenaFX(realDelta);

    }


    /*
        TIME FREEZE
        (SKILL "TIME" AKTIF)
    */

    if(duelMode && timeFreeze && !netGuest){

        updateTimeFreeze(
            realDelta
        );

    }


    /*
        BOOSTER SPAWN
        SETIAP 5 DETIK
    */

    if(duelMode && !timeFreeze && !netGuest){

        updateDimension(realDelta);

        updateSpirits(realDelta);

    }

    if(duelMode && !timeFreeze && !netGuest && !dimension){

        boosterTimer+=realDelta;

        if(
            boosterTimer>=5
        ){

            boosterTimer=0;

            spawnBooster();

        }

    }


    /*
        CHARACTER
    */

    if(duelMode && !timeFreeze && !netGuest){

        objects
        .filter(
            o=>
                o.type==="character" &&
                o.hp>0 &&
                (!dimension||o.dimId===1)
        )
        .forEach(o=>{

            if(
                dragging &&
                dragging.object===o
            )
                return;

            manaTick(o,realDelta);


            /*
                MANUAL CONTROL (RANKED)
            */

            if(o.manual&&window.manualPre){

                window.manualPre(
                    o,
                    realDelta
                );

            }


            /*
                AI MUSUH (RANKED / CLASSIC)
            */

            if(o.ai&&window.aiPre){

                window.aiPre(
                    o,
                    realDelta
                );

            }


            /*
                BOOSTER PEMAIN (CD / POWER)
            */

            if(o.hasBoost&&window.boostPre){

                window.boostPre(
                    o,
                    realDelta
                );

            }


            /*
                SAMURAI: KEJAR MUSUH TERDEKAT (JARAK DEKAT)
            */

            if(
                SKILLS[o.skill]?.melee &&
                !o.manual &&
                !o.ghostIn &&
                !o.samSeq &&
                !(o.stunTimer>0) &&
                o.hp>0
            ){

                const sm=samNearest(o);

                if(sm){

                    const dx=sm.x-o.x,dy=sm.y-o.y;

                    const dd=Math.hypot(dx,dy)||1;

                    const sp=dd<(SKILLS[o.skill].meleeReach||62)*.8?0:150;

                    o.vx=dx/dd*sp;

                    o.vy=dy/dd*sp;

                }

            }


            /*
                LINGLUNG (DAZE)
            */

            if(o.dazeTimer>0&&o.hp>0){

                updateDaze(
                    o,
                    realDelta
                );

            }


            /*
                PHASE
            */

            if(
                SKILLS[o.skill]?.phase &&
                o.shieldTimer<=5 &&
                o.shield<=5
            ){

                o.shield=35;

                o.shieldTimer=8.5;

                burstParticles(
                    o.x,
                    o.y,
                    15,
                    "shield"
                );

                sound("phase");

            }


            if(o.shieldTimer>0){

                o.shieldTimer-=
                    realDelta;

                if(
                    o.shieldTimer<=0
                ){

                    o.shield=0;

                }

            }


            let speedMul=
                SKILLS[o.skill]?.speedSkill
                ?1.35
                :1;

            if(
                SKILLS[o.skill]?.phase
            )
                speedMul*=2;

            if(SKILLS[o.skill]?.moveMul)
                speedMul*=SKILLS[o.skill].moveMul;


            if(o.lsZone&&SKILLS[o.skill]&&SKILLS[o.skill].lifestealZone)speedMul*=SKILLS[o.skill].lsSpeedMul||1.5;
            speedMul*=
                o.speedBoost;

            if(o.dimBuff)speedMul*=1.1;

            if(o.iceSlow>0)speedMul*=.35;

            if(o.iceFrost>0)speedMul*=.95;


            o.x+=
                o.vx*
                currentDelta*
                speedMul;

            o.y+=
                o.vy*
                currentDelta*
                speedMul;


            const minX=35;
            const maxX=W-35;

            const minY=45;
            const maxY=H*.68-25;


            if(o.x<minX){

                o.x=minX;

                o.vx=
                    Math.abs(o.vx);

            }


            if(o.x>maxX){

                o.x=maxX;

                o.vx=
                    -Math.abs(o.vx);

            }


            if(o.y<minY){

                o.y=minY;

                o.vy=
                    Math.abs(o.vy);

            }


            if(o.y>maxY){

                o.y=maxY;

                o.vy=
                    -Math.abs(o.vy);

            }


            o.fireCooldown-=
                currentDelta*(o.dimBuff?1.05:1)*(o.iceSlow>0?.35:1)*(o.iceFrost>0?.98:1);


            o.recoil=
                Math.max(
                    0,
                    o.recoil-
                    realDelta*4
                );


            o.speedBoost=
                Math.max(
                    1,
                    o.speedBoost-
                    realDelta*.03
                );


            o.damageBoost=
                Math.max(
                    1,
                    o.damageBoost-
                    realDelta*.03
                );


            /*
                REGEN
            */

            regenTeam(o);


            /*
                CLONE
            */

            if(
                SKILLS[o.skill]?.clone &&
                !o.cloneUsed
            ){

                createClones(o);

            }


            /*
                STUN COUNTDOWN
            */

            if(o.stunTimer>0){

                o.stunTimer=
                    Math.max(
                        0,
                        o.stunTimer-realDelta
                    );

            }


            /*
                HOLE SKILL
                COOLDOWN
            */

            if(
                SKILLS[o.skill]?.holeSkill
            ){

                o.holeCooldown-=
                    realDelta;

                if(
                    o.holeCooldown<=0
                ){

                    spawnBlackHole(o);

                    o.holeCooldown=
                        SKILLS[o.skill].holeCooldownMax||8;

                }

            }


            /*
                DEAD SKILL
                SURVIVE TIMER
            */

            if(
                SKILLS[o.skill]?.deadSkill &&
                !o.deadTriggered
            ){

                o.deadSurvive+=
                    realDelta;

                if(
                    o.deadSurvive>=
                    (SKILLS[o.skill].deadSurviveTime||10)
                ){

                    o.deadTriggered=true;

                    triggerDeadUltimate(o);

                }

            }


            /*
                TIME SKILL
                COOLDOWN
            */

            if(
                SKILLS[o.skill]?.timeSkill
            ){

                o.timeCooldown-=
                    realDelta;

                if(
                    o.timeCooldown<=0 &&
                    !timeFreeze
                ){

                    triggerTimeSkill(o);

                    o.timeCooldown=
                        SKILLS[o.skill].timeCooldownMax||10;

                }

            }


            /*
                SNIPER: PELURU TEMBUS
            */

            if(SKILLS[o.skill]?.sniperSkill){

                if(o.sniperCooldown===undefined)
                    o.sniperCooldown=3;

                o.sniperCooldown-=realDelta;

                if(
                    o.sniperCooldown<=0 &&
                    !timeFreeze &&
                    objects.some(
                        e=>
                            e.type==="character" &&
                            e.hp>0 &&
                            e.team!==o.team
                    )
                ){

                    triggerSniperPierce(o);

                    o.sniperCooldown=
                        SKILLS[o.skill].sniperCooldownMax||10;

                }

            }


            /*
                LIFESTEAL (AREA SEDOT) & NUKLIR (RADIASI)
            */

            updateLifeSteal(
                o,
                realDelta
            );

            updateNuke(
                o,
                realDelta
            );

            updateGhost(
                o,
                realDelta
            );

            updateSamurai(
                o,
                realDelta
            );

            updateIce(
                o,
                realDelta
            );


            /*
                RIWAYAT WAKTU (UNTUK GOLDENTIME)
            */

            if(
                objects.some(
                    g=>
                        g.type==="character" &&
                        g.hp>0 &&
                        false&&SKILLS[g.skill]?.goldenSkill
                )
            ){

                recordTimeHistory(
                    o,
                    realDelta
                );

            }

            if(o.tlRewind){

                updateTimeRewind(
                    o,
                    realDelta
                );

            }


            /*
                GOLDENTIME
            */

            if(SKILLS[o.skill]?.goldenSkill){

                updateGoldenTime(
                    o,
                    realDelta
                );

            }


            /*
                HIPO (SEGEL)
            */

            if(window.updateHipo){

                window.updateHipo(
                    o,
                    realDelta
                );

            }


            /*
                IMMUNE COUNTDOWN
                (HUNTER SKILL)
            */

            if(o.immuneTimer>0){

                o.immuneTimer=
                    Math.max(
                        0,
                        o.immuneTimer-realDelta
                    );

            }


            /*
                ANGEL SKILL
                REVIVE WHEN ALONE
            */

            if(
                SKILLS[o.skill]?.angelSkill &&
                !o.angelUsed
            ){

                const aliveTeammates=
                    objects.filter(
                        x=>
                            x.type==="character" &&
                            x.team===o.team &&
                            x.hp>0
                    ).length;

                const deadTeammates=
                    objects.filter(
                        x=>
                            x.type==="character" &&
                            x.team===o.team &&
                            x!==o &&
                            x.dead
                    );

                if(
                    aliveTeammates===1 &&
                    deadTeammates.length>0 &&
                    manaHas(o,60)
                ){

                    o.angelUsed=true;

                    manaPay(o,60);

                    triggerAngelRevive(
                        o,
                        deadTeammates
                    );

                }

            }


            /*
                HUNTER SKILL
                COOLDOWN
            */

            if(
                SKILLS[o.skill]?.hunterSkill
            ){

                o.hunterCooldown-=
                    realDelta;

                if(
                    o.hunterCooldown<=0
                ){

                    triggerHunterBarrage(o);

                    o.hunterCooldown=
                        SKILLS[o.skill].hunterCooldownMax||8;

                }

            }

        });


        /*
            ALL CHARACTERS
            AUTO TARGET
        */

        const chars=
            objects.filter(
                o=>
                    o.type==="character" &&
                    o.hp>0 &&
                    (!dimension||o.dimId===1)
            );


        chars.forEach(
            shooter=>{

                if(
                    shooter.stunTimer>0 ||
                    shooter.ghostIn
                )return;


                if(
                    SKILLS[shooter.skill]?.noAttack
                )return;


                const enemies=
                    chars.filter(
                        x=>
                            x.team!==shooter.team
                    );


                if(!enemies.length)
                    return;


                let target=
                    enemies[0];

                let best=Infinity;


                enemies.forEach(e=>{

                    const d=
                        Math.hypot(
                            e.x-shooter.x,
                            e.y-shooter.y
                        );


                    if(d<best){

                        best=d;
                        target=e;

                    }

                });


                shooter.angle=
                    Math.atan2(
                        target.y-shooter.y,
                        target.x-shooter.x
                    );


                if(SKILLS[shooter.skill]?.melee){

                    meleeStrike(
                        shooter,
                        target,
                        currentDelta
                    );

                    return;

                }


                if(
                    shooter.fireCooldown<=0
                ){

                    const skill=
                        SKILLS[shooter.skill]||
                        SKILLS.normal;


                    shoot(
                        shooter,
                        target
                    );


                    shooter.fireCooldown=
                        skill.burst
                        ?7
                        :(skill.cooldown||10);


                    /*
                        FIRESHOT
                    */

                    if(skill.fireshot){

                        shooter.fireCooldown=
                            Math.max(
                                .65,
                                shooter.fireCooldown/
                                shooter.fireLevel
                            );

                    }

                }

            }
        );

    }


    /*
        BOOSTER COLLISION
    */

    if(duelMode && !timeFreeze && !netGuest && !dimension){

        boosters=
            boosters.filter(
                b=>{

                    b.life-=realDelta;

                    let collected=false;


                    objects
                    .filter(
                        o=>
                            o.type==="character" &&
                            o.hp>0
                    )
                    .forEach(o=>{

                        const d=
                            Math.hypot(
                                o.x-b.x,
                                o.y-b.y
                            );


                        if(d<35){

                            collectBooster(
                                o,
                                b
                            );

                            collected=true;

                        }

                    });


                    return(
                        b.life>0 &&
                        !collected
                    );

                }
            );

    }


    /*
        CLONES
    */

    if(duelMode && !timeFreeze && !netGuest && !dimension){

        updateClones(
            currentDelta
        );

        updateBlackholes(
            currentDelta
        );

        updateExplosions(
            currentDelta
        );

    }


    /*
        BULLETS
    */

    if(netGuest&&window.netExtrap)window.netExtrap(realDelta);

    bullets=
        bullets.filter(
            bullet=>{

                if(timeFreeze)
                    return(
                        bullet.life>0 &&
                        !bullet.hit
                    );

                if(netGuest){
                    bullet.x+=bullet.vx*realDelta;
                    bullet.y+=bullet.vy*realDelta;
                    return true;
                }


                /*
                    MAGNET HOMING
                */

                updateMagnetBullet(
                    bullet,
                    currentDelta
                );


                bullet.x+=
                    bullet.vx*
                    currentDelta;

                bullet.y+=
                    bullet.vy*
                    currentDelta;


                bullet.life-=
                    realDelta;


                /*
                    WALL BOUNCE
                */

                if(
                    bullet.x<15 ||
                    bullet.x>W-15
                ){

                    bullet.vx*=-1;

                    bullet.x=
                        Math.max(
                            15,
                            Math.min(
                                W-15,
                                bullet.x
                            )
                        );

                }


                if(
                    bullet.y<15 ||
                    bullet.y>H*.68
                ){

                    bullet.vy*=-1;

                    bullet.y=
                        Math.max(
                            15,
                            Math.min(
                                H*.68,
                                bullet.y
                            )
                        );

                }


                return(
                    bullet.life>0 &&
                    !bullet.hit
                );

            }
        );


    /*
        COLLISION
    */

    if(!timeFreeze&&!netGuest){

        checkBulletCollision();

    }


    /*
        DRAW BULLETS
    */

    bullets.forEach(
        bullet=>{

            ctx.save();

            ctx.translate(
                bullet.x,
                bullet.y
            );


            ctx.rotate(
                Math.atan2(
                    bullet.vy,
                    bullet.vx
                )
            );


            /*
                MAGNET BULLET
            */

            if(bullet.pierce){

                ctx.shadowColor="#ff3b3b";
                ctx.shadowBlur=12;

                ctx.fillStyle=
                    "#ff6a6a";

                ctx.fillRect(
                    -12,
                    -3,
                    24,
                    6
                );

            }
            else if(bullet.magnet){

                ctx.fillStyle=
                    "#b87cff";

            }
            else{

                ctx.fillStyle=
                    "#ffe08a";

            }


            ctx.fillRect(
                -7,
                -2,
                14,
                4
            );


            ctx.globalAlpha=.25;

            ctx.fillRect(
                -18,
                -1,
                12,
                2
            );


            ctx.restore();

        }
    );


    /*
        BOOSTERS
    */

    boosters.forEach(
        drawBooster
    );


    /*
        BLACK HOLES
    */

    blackholes.forEach(
        drawBlackHole
    );


    /*
        EXPLOSIONS
    */

    drawExplosions();


    /*
        OBJECTS
    */

    objects
    .filter(
        o=>o.type==="object"
    )
    .forEach(
        drawObject
    );


    /*
        CLONES
    */

    clones.forEach(
        drawClone
    );


    /*
        CHARACTERS
    */

    objects
    .filter(
        o=>
            o.type==="character"
    )
    .forEach(
        drawCharacter
    );


    /*
        PARTICLES
    */

    updateParticles(
        currentDelta
    );

    drawParticles();

    updateUltFx(realDelta);

    drawUltFx();


    /*
        CINEMATIC SLOWMO EFFECT
    */

    if(slowMotion>0){

        ctx.fillStyle=
            `rgba(255,255,255,${
                Math.min(
                    .12,
                    slowMotion*.08
                )
            })`;

        ctx.fillRect(
            0,
            0,
            W,
            H
        );

    }


    if(hitFlash>0){

        ctx.fillStyle=
            `rgba(255,80,80,${
                hitFlash*.25
            })`;

        ctx.fillRect(
            0,
            0,
            W,
            H
        );

    }


    /*
        TIME FREEZE OVERLAY
    */

    if(timeFreeze){

        ctx.fillStyle=
            "rgba(120,180,255,0.14)";

        ctx.fillRect(
            0,
            0,
            W,
            H
        );


        ctx.save();

        ctx.font=
            "bold 15px Arial";

        ctx.textAlign="center";

        ctx.textBaseline="middle";

        ctx.fillStyle=
            `rgba(255,255,255,${
                .6+
                Math.sin(
                    performance.now()/120
                )*.3
            })`;

        ctx.shadowColor="#7db8ff";

        ctx.shadowBlur=10;

        ctx.fillText(
            "⏳ TIME STOP",
            W/2,
            34
        );

        ctx.restore();

    }


    if(window.postFX)window.postFX();


    /*
        WINNER
    */

    if(duelMode&&!netGuest){

        const blueAlive=
            objects.some(
                o=>
                    o.type==="character" &&
                    (o.origTeam||o.team)==="blue" &&
                    o.hp>0
            );


        const redAlive=
            objects.some(
                o=>
                    o.type==="character" &&
                    (o.origTeam||o.team)==="red" &&
                    o.hp>0
            );


        if(
            blueAlive!==redAlive
        ){

            winnerTimer+=
                realDelta;


            if(
                winnerTimer>1
            ){

                winnerTimer=0;

                duelMode=false;


                const winner=
                    blueAlive
                    ?"🔵 BLUE MENANG!"
                    :"🔴 RED MENANG!";


                document.getElementById(
                    "result"
                ).textContent=
                    winner;


                document.getElementById(
                    "resultText"
                ).textContent=
                    "Duel selesai.";


                if(
                    !(
                        window.onDuelEnd &&
                        window.onDuelEnd(blueAlive)
                    )
                ){

                    document.getElementById(
                        "modal"
                    ).style.display=
                        "flex";

                }


                document.getElementById(
                    "duel"
                ).textContent=
                    "⚔️ Duel";

            }

        }
        else{

            winnerTimer=0;

        }

    }


    requestAnimationFrame(
        gameLoop
    );

}


/* ==================================================
   INITIAL
================================================== */

addCharacter(
    W*.25,
    H*.5,
    "blue",
    "normal"
);

addCharacter(
    W*.75,
    H*.5,
    "red",
    "normal"
);

addObject(
    W*.5,
    H*.5
);

updateInfo();

requestAnimationFrame(
    gameLoop
);

