-- =====================================================
--  PISTOL DUEL — setup database Supabase (v1.9)
--  Jalankan SEKALI di: Supabase → SQL Editor → New query → Run
-- =====================================================

-- 1) Tabel data pemain (satu baris per akun)
create table if not exists public.profiles (
    id         uuid primary key references auth.users(id) on delete cascade,
    username   text  not null check (username ~ '^[A-Za-z0-9_]{3,16}$'),
    data       jsonb not null default '{}'::jsonb check (pg_column_size(data) < 100000),
    updated_at timestamptz not null default now()
);

-- username unik (huruf besar/kecil dianggap sama)
create unique index if not exists profiles_username_lower
    on public.profiles (lower(username));

-- 2) Keamanan: tiap pemain hanya boleh membaca & mengubah barisnya sendiri
alter table public.profiles enable row level security;

drop policy if exists "profiles select own" on public.profiles;
drop policy if exists "profiles insert own" on public.profiles;
drop policy if exists "profiles update own" on public.profiles;

create policy "profiles select own" on public.profiles
    for select using (auth.uid() = id);

create policy "profiles insert own" on public.profiles
    for insert with check (auth.uid() = id);

create policy "profiles update own" on public.profiles
    for update using (auth.uid() = id) with check (auth.uid() = id);

-- 3) Isi updated_at otomatis
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
    new.updated_at = now();
    return new;
end $$;

drop trigger if exists profiles_touch on public.profiles;
create trigger profiles_touch before update on public.profiles
    for each row execute function public.touch_updated_at();

-- 4) Papan peringkat: hanya nama + rank yang terlihat publik (data lain tetap privat)
create or replace view public.leaderboard as
select
    username,
    case when data->>'rp'   ~ '^[0-9]{1,7}$' then (data->>'rp')::int   else 0 end as rp,
    case when data->>'peak' ~ '^[0-9]{1,7}$' then (data->>'peak')::int else 0 end as peak,
    case when data->>'xp'   ~ '^[0-9]{1,9}$' then (data->>'xp')::int   else 0 end as xp
from public.profiles;

grant select on public.leaderboard to anon, authenticated;
