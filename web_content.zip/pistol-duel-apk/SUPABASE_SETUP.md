# Mengaktifkan Mode Online (Supabase) — Pistol Duel v1.9

Tanpa langkah ini game tetap jalan **offline** seperti biasa. Setelah diisi,
login/daftar jadi online, data tersimpan di cloud, dan ada Peringkat.

## 1. Buat project Supabase (gratis)
1. Buka https://supabase.com → daftar / login → **New project**.
2. Isi nama (bebas), password database (simpan), region terdekat (Singapore).
3. Tunggu project selesai dibuat (±2 menit).

## 2. Matikan konfirmasi email (penting)
Game memakai username (bukan email asli), jadi konfirmasi email harus mati:
1. **Authentication → Sign In / Providers → Email**.
2. Pastikan **Enable Email provider** nyala.
3. Matikan **Confirm email**, lalu **Save**.

## 3. Jalankan SQL
1. **SQL Editor → New query**.
2. Buka file `supabase_setup.sql`, salin semua isinya, tempel, tekan **Run**.
3. Harus muncul "Success". (Aman dijalankan ulang.)

## 4. Ambil kunci
**Project Settings → API** (atau "API Keys"), salin dua nilai:
- **Project URL** → contoh `https://abcdefgh.supabase.co`
- **anon / public key** (kunci panjang berawalan `eyJ...` atau `sb_publishable_...`)

> Kunci "anon/public" memang aman ditaruh di game. **Jangan** pakai `service_role`.

## 5. Isi ke game
Buka `index.html` (atau `toy_duel_sandbox-XX.html`) dengan editor teks, cari:

```js
window.TDS_ONLINE_CONFIG={
    url:"",
    anonKey:""
};
```
Isi dengan nilai dari langkah 4, simpan. Untuk APK: ganti isi di
`pistol-duel-apk/www/index.html` lalu build ulang.

## Cara kerja singkat
- Daftar/login online memakai username + password. Password tidak dikirim polos (di-hash dulu).
- Akun lama di HP otomatis dipindah ke online saat login pertama (username & password sama).
- Tanpa internet: tetap bisa login dengan akun yang pernah dipakai di HP itu; data
  disimpan di HP dan disinkronkan saat online lagi.
- Peringkat menampilkan 50 pemain teratas (nama + rank saja).

## Batasan (jujur)
- Keamanan hanya mencegah pemain mengubah data **pemain lain**. Pemain yang paham teknis
  masih bisa mengubah data **akunnya sendiri** (koin/rank) lewat API, karena
  game dijalankan di HP pemain. Untuk anti-curang penuh perlu server yang menjalankan
  duel (tahap lanjut).
- Login di dua HP sekaligus: data yang disimpan terakhir yang menang.
- Paket gratis Supabase memadai untuk ratusan-ribuan pemain kecil; project gratis yang
  tidak aktif lama bisa di-pause (tinggal diaktifkan lagi di dashboard).

---

## Update Global v0.05 (ID Pemain & Cari Pemain)

Kalau database kamu sudah dibuat dengan versi sebelumnya, jalankan **sekali** file
`supabase_update_v005.sql`:

1. Supabase → **SQL Editor** → **New query**.
2. Tempel seluruh isi `supabase_update_v005.sql` → **Run**.
3. Selesai. Semua akun lama otomatis mendapat ID 5 digit unik, dan fitur
   **Peringkat → 🔍 Cari Pemain** langsung bisa dipakai.

Catatan:
- ID dibuat dan dijaga oleh server (tidak bisa kembar, tidak bisa diubah pemain).
- Ada 90.000 kemungkinan ID 5 digit (10000–99999). Jika pemain mendekati jumlah itu,
  ID baru akan gagal dibuat — saat itu perlu diperpanjang jadi 6 digit.
- Yang terlihat publik lewat pencarian hanya: nickname, ID, level, rank, dan bio.
- Kalau SQL ini belum dijalankan, pencarian menampilkan pesan
  "Server belum diperbarui".
