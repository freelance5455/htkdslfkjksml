-- =====================================================
--  PISTOL DUEL — UPDATE DATABASE Global v0.05
--  (ID Pemain 5 digit + Cari Pemain)
--  Jalankan SEKALI di: Supabase → SQL Editor → New query → Run
--  Aman dijalankan ulang.
-- =====================================================

-- 1) ID unik: satu ID per akun, tidak boleh kembar
create unique index if not exists profiles_uid_unique
    on public.profiles ((data->>'uid'))
    where data->>'uid' is not null;

-- 2) Server yang menjamin ID: dipakai ID dari pemain kalau valid & belum terpakai,
--    kalau tidak, dibuatkan ID acak 5 digit. ID yang sudah ada tidak bisa diubah.
create or replace function public.assign_uid()
returns trigger language plpgsql as $$
declare
    cand  text;
    prev  text;
    tries int := 0;
begin
    if tg_op = 'UPDATE' then
        prev := old.data->>'uid';
        if prev is not null and prev ~ '^[1-9][0-9]{4}$' then
            new.data := jsonb_set(new.data, '{uid}', to_jsonb(prev), true);
            return new;
        end if;
    end if;

    cand := new.data->>'uid';

    if cand is null or cand !~ '^[1-9][0-9]{4}$'
       or exists (select 1 from public.profiles p where p.data->>'uid' = cand and p.id <> new.id) then
        loop
            cand := (10000 + floor(random() * 90000))::int::text;
            exit when not exists (select 1 from public.profiles p where p.data->>'uid' = cand);
            tries := tries + 1;
            if tries > 60 then
                raise exception 'ID pemain penuh';
            end if;
        end loop;
    end if;

    new.data := jsonb_set(new.data, '{uid}', to_jsonb(cand), true);
    return new;
end $$;

drop trigger if exists profiles_uid on public.profiles;
create trigger profiles_uid before insert or update on public.profiles
    for each row execute function public.assign_uid();

-- 3) Beri ID ke semua akun yang sudah ada
update public.profiles set data = data where data->>'uid' is null;

-- 4) Tampilan publik: tambah ID & bio (data lain tetap privat)
create or replace view public.leaderboard as
select
    username,
    case when data->>'rp'   ~ '^[0-9]{1,7}$' then (data->>'rp')::int   else 0 end as rp,
    case when data->>'peak' ~ '^[0-9]{1,7}$' then (data->>'peak')::int else 0 end as peak,
    case when data->>'xp'   ~ '^[0-9]{1,9}$' then (data->>'xp')::int   else 0 end as xp,
    data->>'uid' as uid,
    left(coalesce(data->>'bio', ''), 80) as bio
from public.profiles;

grant select on public.leaderboard to anon, authenticated;
