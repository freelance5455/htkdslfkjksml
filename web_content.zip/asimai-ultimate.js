/* AsimAI Ultimate layer: local backup/restore, security diagnostics and human-approved task planning. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const wait = (n = 0) => {
    const app = window.appInstance;
    if (app && Array.isArray(app.conversations) && window.Storage) return install(app);
    if (n < 100) setTimeout(() => wait(n + 1), 200);
  };
  function install(app) {
    if (window.__asimUltimateReady) return;
    window.__asimUltimateReady = true;
    const sidebar = $('sidebar');
    if (sidebar) {
      const btn = document.createElement('button');
      btn.id = 'asimUltimateBtn'; btn.type = 'button';
      btn.className = 'w-full flex items-center gap-3 px-3 py-2.5 mt-2 rounded-xl border border-orange-200 bg-orange-50 hover:bg-orange-100 text-sm font-bold text-slate-800';
      btn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles w-4 text-orange-600"></i><span>Ultimate Center</span>';
      ( $('openAllInOneBtn') || $('openHistorySidebarBtn') || sidebar.firstElementChild )?.insertAdjacentElement('afterend', btn);
      btn.addEventListener('click', () => { app.toggleSidebar?.(false); open(); });
    }
    const panel = document.createElement('section');
    panel.id = 'asimUltimatePanel'; panel.hidden = true;
    panel.innerHTML = `
      <header class="au-head"><button id="auBack" type="button" aria-label="Back"><i class="fa-solid fa-arrow-left"></i></button><div><b>AsimAI Ultimate Center</b><small>Control, protect and extend your workspace</small></div><span class="au-version">ULTIMATE</span></header>
      <main class="au-main">
        <section class="au-hero"><div><small>YOUR AI WORKSPACE</small><h1>Make more. Stay in control.</h1><p>Keep your existing tools, protect your data and plan complex work with human approval.</p></div><div class="au-orb"><i class="fa-solid fa-sparkles"></i></div></section>
        <section class="au-grid">
          <article class="au-card"><div class="au-card-icon"><i class="fa-solid fa-shield-halved"></i></div><h2>Security Center</h2><p>Check HTTPS, service worker, manifest and browser-side credential risks.</p><div id="auSecurityStatus" class="au-status">Not checked yet</div><button id="auRunAudit" type="button">Run security check</button><ul id="auAuditList" class="au-audit"></ul></article>
          <article class="au-card"><div class="au-card-icon"><i class="fa-solid fa-box-archive"></i></div><h2>Backup & Restore</h2><p>Export conversations and preferences to a portable JSON backup. Provider secrets are excluded.</p><div class="au-actions"><button id="auExport" type="button">Export backup</button><button id="auImportPick" class="au-secondary" type="button">Restore backup</button><input id="auImportFile" type="file" accept="application/json,.json" hidden></div><small id="auBackupStatus">Backups stay on this device unless you move the file.</small></article>
          <article class="au-card au-wide"><div class="au-card-icon"><i class="fa-solid fa-list-check"></i></div><h2>AI Agent Task Planner</h2><p>Turn a goal into a clear plan and prepare it for AI Chat. AsimAI will not take external actions without your approval.</p><textarea id="auGoal" rows="3" maxlength="3000" placeholder="Example: Build a responsive portfolio website with contact form and dark mode..."></textarea><div class="au-actions"><button id="auPlan" type="button">Prepare task plan</button><button id="auClearGoal" class="au-secondary" type="button">Clear</button></div><small>Creates a structured instruction in your chat composer; review it before sending.</small></article>
          <article class="au-card au-wide"><div class="au-card-icon"><i class="fa-solid fa-gauge-high"></i></div><h2>Workspace snapshot</h2><div class="au-metrics"><div><b id="auChats">0</b><span>Conversations</span></div><div><b id="auMessages">0</b><span>Messages</span></div><div><b id="auMemory">0</b><span>Saved memories</span></div><div><b id="auProviders">0</b><span>Configured providers</span></div></div></article>
        </section>
        <p class="au-footnote"><i class="fa-solid fa-circle-info"></i> This upgrade adds local tools. It does not claim cloud backup, server-side encryption, background autonomy or guaranteed offline access.</p>
      </main>`;
    document.body.appendChild(panel);
    const originalMain = $('mainWrapper');
    function refresh() {
      const chats = app.conversations || [];
      $('auChats').textContent = chats.length.toLocaleString();
      $('auMessages').textContent = chats.reduce((n,c)=>n+(c.messages||[]).length,0).toLocaleString();
      $('auMemory').textContent = (app.settings?.memories || []).length.toLocaleString();
      const keys = app.settings?.providerKeys || {};
      $('auProviders').textContent = Object.values(keys).filter(v=>String(v||'').trim()).length.toLocaleString();
    }
    function open() { refresh(); panel.hidden = false; document.body.classList.add('au-open'); }
    function close() { panel.hidden = true; document.body.classList.remove('au-open'); }
    $('auBack').addEventListener('click', close);
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !panel.hidden) close(); });
    $('auRunAudit').addEventListener('click', async () => {
      const checks = [];
      checks.push([location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1', 'Secure origin (HTTPS or localhost)', 'Use HTTPS for public hosting; localhost is acceptable for local testing.']);
      checks.push([!!document.querySelector('link[rel="manifest"]'), 'Web app manifest linked', 'Manifest link is missing.']);
      checks.push([('serviceWorker' in navigator), 'Service worker supported', 'This browser does not support service workers.']);
      let sw = false; try { sw = !!(await navigator.serviceWorker?.getRegistration()); } catch {}
      checks.push([sw, 'Service worker registered', 'Open over HTTPS/localhost and reload to register the worker.']);
      const secret = Object.entries(app.settings?.providerKeys || {}).some(([k,v]) => String(v||'').trim());
      checks.push([!secret, 'Provider credentials in browser storage', secret ? 'One or more provider keys are stored in this browser. Use a backend proxy for public deployment; never commit keys to source control.' : 'No provider keys are configured in app settings.']);
      const rows = checks.map(([ok,label,detail]) => `<li class="${ok?'ok':'warn'}"><b>${ok?'✓':'!'} ${esc(label)}</b><span>${esc(ok?'Passed':detail)}</span></li>`).join('');
      $('auAuditList').innerHTML = rows;
      const failed = checks.filter(x=>!x[0]).length;
      $('auSecurityStatus').textContent = failed ? `${failed} item(s) need attention` : 'Basic checks passed';
      $('auSecurityStatus').className = `au-status ${failed?'warn':'ok'}`;
    });
    $('auExport').addEventListener('click', () => {
      const safeSettings = JSON.parse(JSON.stringify(app.settings || {}));
      safeSettings.apiKey = ''; safeSettings.providerKeys = {};
      const payload = { format:'asimai-backup', version:1, exportedAt:new Date().toISOString(), conversations:app.conversations || [], settings:safeSettings };
      const blob = new Blob([JSON.stringify(payload,null,2)], {type:'application/json'});
      const url = URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=`asimai-backup-${new Date().toISOString().slice(0,10)}.json`; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1500);
      $('auBackupStatus').textContent = 'Backup exported. API keys were intentionally excluded.';
    });
    $('auImportPick').addEventListener('click', () => $('auImportFile').click());
    $('auImportFile').addEventListener('change', async e => {
      const file=e.target.files?.[0]; if(!file)return;
      try {
        if(file.size>15*1024*1024) throw new Error('Backup is larger than 15 MB.');
        const data=JSON.parse(await file.text());
        if(data.format!=='asimai-backup' || data.version!==1 || !Array.isArray(data.conversations) || !data.settings || typeof data.settings!=='object') throw new Error('This is not a supported AsimAI backup.');
        const valid=data.conversations.filter(c=>c && typeof c.id==='string' && Array.isArray(c.messages) && c.messages.every(m=>m && typeof m==='object'));
        if(!valid.length) throw new Error('No valid conversations were found in this backup.');
        if(!confirm(`Restore ${valid.length} conversations and settings? Existing conversations will be replaced. Current API keys will be preserved.`)) return;
        const currentKeys=app.settings?.providerKeys || {}; const currentKey=app.settings?.apiKey || '';
        app.conversations=valid; app.activeConversationId=valid[0].id; app.settings={...data.settings, providerKeys:currentKeys, apiKey:currentKey};
        await Storage.saveConversations(app.conversations); await Storage.saveSettings(app.settings); await Storage.setActiveId(app.activeConversationId);
        app.renderSidebarHistory?.(); app.renderActiveConversation?.(); app._syncSettingsCache?.();
        $('auBackupStatus').textContent=`Restored ${valid.length} conversations. Reload the app if any view does not refresh.`; refresh();
      } catch(err) { $('auBackupStatus').textContent=`Restore failed: ${err.message}`; }
      finally { e.target.value=''; }
    });
    $('auPlan').addEventListener('click', () => {
      const goal=$('auGoal').value.trim(); if(!goal){$('auGoal').focus();return;}
      const instruction=`Act as AsimAI's careful project agent. First clarify assumptions only if essential. Break this goal into milestones, list files/tools needed, identify risks and dependencies, then execute the work in small verifiable steps. Preserve existing functionality. Before any external, destructive, account, purchase, publishing or data-sharing action, stop and ask for my explicit approval. Do not claim an action succeeded unless verified.\n\nGOAL:\n${goal}\n\nDELIVERABLES:\n1. Implementation plan\n2. Step-by-step execution\n3. Verification checklist\n4. Final summary and known limitations`;
      if(app.chatInput){app.chatInput.value=instruction; app.chatInput.dispatchEvent(new Event('input',{bubbles:true})); app.chatInput.focus(); close(); $('sendBtn')?.scrollIntoView({block:'nearest'});}
      else { $('auBackupStatus').textContent='Chat composer was not found. Open AI Chat and try again.'; }
    });
    $('auClearGoal').addEventListener('click',()=>{$('auGoal').value='';});
    app.openUltimateCenter=open;
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>wait()); else wait();
})();
