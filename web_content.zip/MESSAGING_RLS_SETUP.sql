-- GH MARKETPLACE: safe internal messaging setup
-- Run in Supabase SQL Editor. Keeps RLS enabled and restricts access to participants.
-- Assumes public.listings has id and user_id, and conversations/messages use these columns.

CREATE TABLE IF NOT EXISTS public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  buyer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  seller_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT gh_conversation_distinct_users CHECK (buyer_id <> seller_id)
);

CREATE TABLE IF NOT EXISTS public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL CHECK (length(trim(content)) > 0 AND length(content) <= 5000),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON public.conversations TO authenticated;
GRANT SELECT, INSERT ON public.messages TO authenticated;

DROP POLICY IF EXISTS "GH conversation participants read" ON public.conversations;
CREATE POLICY "GH conversation participants read" ON public.conversations
FOR SELECT TO authenticated
USING (auth.uid() = buyer_id OR auth.uid() = seller_id);

DROP POLICY IF EXISTS "GH buyer starts conversation for listing" ON public.conversations;
CREATE POLICY "GH buyer starts conversation for listing" ON public.conversations
FOR INSERT TO authenticated
WITH CHECK (
  auth.uid() = buyer_id
  AND buyer_id <> seller_id
  AND EXISTS (
    SELECT 1 FROM public.listings l
    WHERE l.id = listing_id AND l.user_id = seller_id
  )
);

DROP POLICY IF EXISTS "GH participants read messages" ON public.messages;
CREATE POLICY "GH participants read messages" ON public.messages
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.conversations c
    WHERE c.id = conversation_id
      AND (c.buyer_id = auth.uid() OR c.seller_id = auth.uid())
  )
);

DROP POLICY IF EXISTS "GH participants send own messages" ON public.messages;
CREATE POLICY "GH participants send own messages" ON public.messages
FOR INSERT TO authenticated
WITH CHECK (
  sender_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.conversations c
    WHERE c.id = conversation_id
      AND (c.buyer_id = auth.uid() OR c.seller_id = auth.uid())
  )
);

CREATE INDEX IF NOT EXISTS gh_conversations_buyer_created_idx
ON public.conversations (buyer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS gh_conversations_seller_created_idx
ON public.conversations (seller_id, created_at DESC);
CREATE INDEX IF NOT EXISTS gh_messages_conversation_created_idx
ON public.messages (conversation_id, created_at ASC);

NOTIFY pgrst, 'reload schema';
