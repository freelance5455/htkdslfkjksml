package com.example.gditroll

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private companion object {
        const val PREFS = "gdi_prefs"
        const val KEY_WARNING_OK = "photosensitivity_ok"
        const val REQ_NOTIFICATIONS = 7
        const val REQ_CAPTURE = 8
        const val DURATION_SEC = 0
    }

    private var pendingStart = false
    private lateinit var webView: WebView
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 700)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(17, 16, 24))
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.domStorageEnabled = false
            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    return request?.url?.host != "appassets.androidplatform.net"
                }

                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    return !url.orEmpty().startsWith("https://appassets.androidplatform.net/")
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    refresh()
                }
            }
            val page = assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            loadDataWithBaseURL(
                "https://appassets.androidplatform.net/",
                page,
                "text/html",
                "UTF-8",
                null
            )
        }
        setContentView(webView)
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun enableOverlay() {
            runOnUiThread { openOverlaySettings() }
        }

        @JavascriptInterface
        fun toggleEffects() {
            runOnUiThread { onActionTapped() }
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        ticker.run()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidBridge")
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun refresh() {
        if (!::webView.isInitialized) return
        val granted = Settings.canDrawOverlays(this)
        val running = GdiOverlayService.isRunning
        webView.evaluateJavascript(
            "if (window.updateNativeState) window.updateNativeState($granted, $running);",
            null
        )
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun onActionTapped() {
        if (GdiOverlayService.isRunning) {
            startService(Intent(this, GdiOverlayService::class.java).setAction(GdiOverlayService.ACTION_STOP))
            handler.postDelayed(ticker, 250)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primeiro permita a sobreposição na tela inicial.", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_WARNING_OK, false)) {
            AlertDialog.Builder(this)
                .setTitle("Aviso de epilepsia e fotossensibilidade")
                .setMessage(
                    "Os efeitos usam cores e movimento na tela inteira. NÃO use se você, ou alguém perto de você, " +
                        "tem epilepsia fotossensível ou sensibilidade a luzes piscantes ou movimento: mesmo com cuidados " +
                        "de segurança, qualquer padrão de tela pode incomodar quem tem essa condição. Você pode parar a " +
                        "qualquer momento pelo botão PARAR, pela notificação ou apagando a tela."
                )
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Entendi, continuar") { _, _ ->
                    prefs.edit().putBoolean(KEY_WARNING_OK, true).apply()
                    ensureNotificationsThenStart()
                }.show()
            return
        }
        ensureNotificationsThenStart()
    }

    private fun ensureNotificationsThenStart() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingStart = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
        } else {
            requestCapture()
        }
    }

    private fun requestCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            startEffects(resultCode, data)
        } else {
            Toast.makeText(this, "Sem a permissão de gravar a tela, os efeitos não iniciam.", Toast.LENGTH_LONG).show()
        }
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIFICATIONS && pendingStart) {
            pendingStart = false
            if (grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notificações negadas: o PARAR fica só neste botão e no tempo limite.", Toast.LENGTH_LONG).show()
            }
            requestCapture()
        }
    }

    private fun startEffects(resultCode: Int, data: Intent) {
        val intent = Intent(this, GdiOverlayService::class.java).apply {
            action = GdiOverlayService.ACTION_START
            putExtra(GdiOverlayService.EXTRA_EFFECT, Effect.SCR_MEMZ_TOTAL.ordinal)
            putExtra(GdiOverlayService.EXTRA_INTENSITY, Intensity.STRONG.ordinal)
            putExtra(GdiOverlayService.EXTRA_SOUND, true)
            putExtra(GdiOverlayService.EXTRA_DURATION_SEC, DURATION_SEC)
            putExtra(GdiOverlayService.EXTRA_RESULT_CODE, resultCode)
            putExtra(GdiOverlayService.EXTRA_RESULT_DATA, data)
        }
        startForegroundService(intent)
        handler.postDelayed(ticker, 250)
    }
}
