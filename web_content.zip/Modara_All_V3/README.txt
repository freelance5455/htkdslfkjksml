MODARA ALL V3 – Browser prototype

Original main menu preserved:
- Water & Electricity
- Petty Cash
- Certificate Register

Water & Electricity:
- Save date, type, start and end meter readings.
- Office usage = same day's end minus start.
- Off usage = next recorded date's start minus current end, same type.
- Daily filter and monthly report with Office / Off / total separately.

Petty Cash:
- Multiple bill lines under one V.No. (same date and V.No. merges into same voucher).
- Each line has Description, Category and Amount.
- Bill Ref removed.
- Add / edit / delete bill lines.

Certificate Register:
- Enter opening stock once with the first month.
- Add received quantities.
- Enter Start and End certificate numbers to calculate inclusive issued count.
- Multiple ranges per day supported.
- Monthly stock = opening stock + received - issued; automatically carries forward.

Use:
1. Extract ZIP and open index.html in Chrome.
2. Use the same browser/device for local data.
3. Export Backup regularly.
This is a browser prototype, NOT an Android APK.
Off Time remains pending until a later date reading is entered.
Certificate Start/End require matching prefixes and an increasing numeric suffix.
