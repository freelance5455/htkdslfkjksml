# Magic Hour deployment notes

1. Keep the current `config.local.php`, SQLite database, `storage/` directory and encryption secret from the live site.
2. Extract this archive into the web root. Its files are at archive root.
3. Ensure PHP has cURL, fileinfo, OpenSSL, PDO and the configured SQLite or MySQL PDO driver.
4. Sign in as admin and open `admin.php?tab=magichour`.
5. Add the Magic Hour API key and save. The API key is encrypted using the existing `admin_api_encryption_key`.
6. Click **Test API connection**. A successful test reads the Magic Hour account tier and current provider credits.
7. Configure the generation modes confirmed for the Magic Hour account. The public Lip Sync example documents `lite`; do not add other mode names without confirmation.
8. Set the Anonymoux credit price and enable the feature.
9. Test with a short clip. Check shared History, playback, download and credit ledger.

PHP-mediated uploads are subject to the hosting account's `upload_max_filesize`, `post_max_size`, `max_execution_time`, outbound HTTPS and available storage limits. This integration deliberately does not switch to browser-direct uploads if PHP upload limits are exceeded.
