document.addEventListener('DOMContentLoaded', () => {
    const startScreen = document.getElementById('start-screen');
    const quizScreen = document.getElementById('quiz-screen');
    const resultScreen = document.getElementById('result-screen');

    const startBtn = document.getElementById('start-btn');
    const restartBtn = document.getElementById('restart-btn');
    const correctBtn = document.getElementById('correct-btn');
    const wrongBtn = document.getElementById('wrong-btn');

    const currentQEl = document.getElementById('current-q');
    const currentScoreEl = document.getElementById('current-score');
    const wordDisplayEl = document.getElementById('word-display');
    const timerTextEl = document.getElementById('timer-text');
    const timerProgressEl = document.getElementById('timer-progress');

    const finalCorrectEl = document.getElementById('final-correct');
    const finalWrongEl = document.getElementById('final-wrong');
    const finalPercentageEl = document.getElementById('final-percentage');
    const resultEmojiEl = document.getElementById('result-emoji');
    const resultTitleEl = document.getElementById('result-title');
    const resultSubtitleEl = document.getElementById('result-subtitle');

    let currentQuestions = [];
    let currentIndex = 0;
    let score = 0;
    let correctCount = 0;
    let wrongCount = 0;
    let timerInterval = null;
    let timeLeft = 60;
    const TOTAL_TIME = 60;
    const CIRCLE_CIRCUMFERENCE = 163.36; // 2 * pi * 26

    startBtn.addEventListener('click', startQuiz);
    restartBtn.addEventListener('click', startQuiz);
    correctBtn.addEventListener('click', () => handleAnswer(true));
    wrongBtn.addEventListener('click', () => handleAnswer(false));

    function startQuiz() {
        // اختيار 20 كلمة عشوائية من بنك الأسئلة (500 كلمة)
        currentQuestions = getRandomElements(ALL_WORDS, 20);
        currentIndex = 0;
        score = 0;
        correctCount = 0;
        wrongCount = 0;

        switchScreen(quizScreen);
        loadQuestion();
    }

    function loadQuestion() {
        if (currentIndex >= currentQuestions.length) {
            endQuiz();
            return;
        }

        currentQEl.textContent = currentIndex + 1;
        currentScoreEl.textContent = score;
        wordDisplayEl.textContent = currentQuestions[currentIndex];

        resetTimer();
        startTimer();
    }

    function startTimer() {
        timeLeft = TOTAL_TIME;
        updateTimerDisplay();

        timerInterval = setInterval(() => {
            timeLeft--;
            updateTimerDisplay();

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                // اعتباره خطأ عند انتهاء الوقت
                handleAnswer(false);
            }
        }, 1000);
    }

    function resetTimer() {
        clearInterval(timerInterval);
        timerProgressEl.style.strokeDashoffset = 0;
        timerTextEl.textContent = TOTAL_TIME;
    }

    function updateTimerDisplay() {
        timerTextEl.textContent = timeLeft;
        const offset = CIRCLE_CIRCUMFERENCE - (timeLeft / TOTAL_TIME) * CIRCLE_CIRCUMFERENCE;
        timerProgressEl.style.strokeDashoffset = offset;

        // تغيير اللون عند اقتراب انتهاء الوقت
        if (timeLeft <= 10) {
            timerProgressEl.style.stroke = 'var(--danger)';
            timerTextEl.style.color = 'var(--danger)';
        } else {
            timerProgressEl.style.stroke = 'var(--primary)';
            timerTextEl.style.color = 'var(--primary)';
        }
    }

    function handleAnswer(isCorrect) {
        clearInterval(timerInterval);

        if (isCorrect) {
            correctCount++;
            score += 10;
        } else {
            wrongCount++;
        }

        currentIndex++;
        loadQuestion();
    }

    function endQuiz() {
        clearInterval(timerInterval);
        switchScreen(resultScreen);

        finalCorrectEl.textContent = correctCount;
        finalWrongEl.textContent = wrongCount;
        
        const percentage = Math.round((correctCount / 20) * 100);
        finalPercentageEl.textContent = percentage + '%';

        if (percentage >= 80) {
            resultEmojiEl.textContent = '🏆';
            resultTitleEl.textContent = 'بطل القراءة!';
            resultSubtitleEl.textContent = 'أداء مذهل وممتاز جداً!';
        } else if (percentage >= 50) {
            resultEmojiEl.textContent = '🌟';
            resultTitleEl.textContent = 'أحسنت صنعاً!';
            resultSubtitleEl.textContent = 'مستوى جيد، استمر في التدريب!';
        } else {
            resultEmojiEl.textContent = '💪';
            resultTitleEl.textContent = 'حاول مرة أخرى!';
            resultSubtitleEl.textContent = 'بالتدريب المستمر ستصبح أفضل!';
        }
    }

    function switchScreen(screen) {
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        screen.classList.add('active');
    }

    function getRandomElements(arr, count) {
        const shuffled = [...arr].sort(() => 0.5 - Math.random());
        return shuffled.slice(0, count);
    }
});