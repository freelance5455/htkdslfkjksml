package id.umaj.kasir;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT_CONNECT = 7101;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView webView;
    private String pendingAddress;
    private String pendingText;
    private boolean pendingPrint;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setDatabaseEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PrinterBridge(), "UMAJPrinter");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasBluetoothPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothPermission(boolean forPrint, String address, String text) {
        pendingPrint = forPrint;
        pendingAddress = address;
        pendingText = text;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_CONNECT);
        } else {
            runPendingBluetoothAction();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_CONNECT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) runPendingBluetoothAction();
            else js("window.onBluetoothPrintResult && window.onBluetoothPrintResult(false,'Izin Bluetooth ditolak');");
        }
    }

    private void runPendingBluetoothAction() {
        if (pendingPrint) doPrint(pendingAddress, pendingText);
        else sendPairedDevices();
        pendingPrint = false;
    }

    private void js(String script) {
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private void sendPairedDevices() {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            JSONArray arr = new JSONArray();
            if (adapter != null && adapter.isEnabled()) {
                Set<BluetoothDevice> devices = adapter.getBondedDevices();
                for (BluetoothDevice device : devices) {
                    JSONObject obj = new JSONObject();
                    obj.put("name", device.getName() == null ? "Printer Bluetooth" : device.getName());
                    obj.put("address", device.getAddress());
                    arr.put(obj);
                }
            }
            String json = arr.toString();
            js("window.onBluetoothDevices && window.onBluetoothDevices(" + JSONObject.quote(json) + ");");
        } catch (Exception e) {
            js("window.onBluetoothDevices && window.onBluetoothDevices('[]');");
            js("window.onBluetoothPrintResult && window.onBluetoothPrintResult(false,'Gagal membaca perangkat Bluetooth');");
        }
    }

    private void doPrint(String address, String text) {
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) throw new Exception("HP tidak mendukung Bluetooth");
                if (!adapter.isEnabled()) throw new Exception("Aktifkan Bluetooth HP terlebih dahulu");
                BluetoothDevice device = adapter.getRemoteDevice(address);
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                adapter.cancelDiscovery();
                socket.connect();
                OutputStream out = socket.getOutputStream();
                out.write(new byte[]{0x1B, 0x40}); // ESC @ initialize
                out.write(new byte[]{0x1B, 0x61, 0x00}); // left align
                out.write(toPrinterBytes(text));
                out.write(new byte[]{0x0A, 0x0A, 0x0A});
                out.write(new byte[]{0x1D, 0x56, 0x00}); // cut where supported
                out.flush();
                js("window.onBluetoothPrintResult && window.onBluetoothPrintResult(true,'Struk dikirim ke printer');");
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "Gagal mencetak. Periksa pasangan Bluetooth dan dukungan ESC/POS." : e.getMessage();
                js("window.onBluetoothPrintResult && window.onBluetoothPrintResult(false," + JSONObject.quote(msg) + ");");
            } finally {
                try { if (socket != null) socket.close(); } catch (Exception ignored) { }
            }
        }).start();
    }

    private byte[] toPrinterBytes(String text) {
        StringBuilder out = new StringBuilder();
        String normalized = text.replace("₨", "Rs").replace("₹", "Rs").replace("·", "-").replace("—", "-");
        for (String line : normalized.split("\\r?\\n", -1)) {
            String ascii = line.replaceAll("[^\\x20-\\x7E]", "?");
            if (ascii.length() == 0) { out.append("\n"); continue; }
            while (ascii.length() > 32) {
                int cut = ascii.lastIndexOf(' ', 32);
                if (cut < 12) cut = 32;
                out.append(ascii, 0, cut).append('\n');
                ascii = ascii.substring(cut).trim();
            }
            out.append(ascii).append('\n');
        }
        return out.toString().getBytes(Charset.forName("US-ASCII"));
    }

    private class PrinterBridge {
        @JavascriptInterface public void listPairedDevices() {
            runOnUiThread(() -> {
                if (!hasBluetoothPermission()) requestBluetoothPermission(false, null, null);
                else sendPairedDevices();
            });
        }
        @JavascriptInterface public void printReceipt(String address, String text) {
            runOnUiThread(() -> {
                if (address == null || address.trim().isEmpty()) {
                    js("window.onBluetoothPrintResult && window.onBluetoothPrintResult(false,'Pilih printer Bluetooth terlebih dahulu');");
                    return;
                }
                if (!hasBluetoothPermission()) requestBluetoothPermission(true, address, text);
                else doPrint(address, text == null ? "" : text);
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
