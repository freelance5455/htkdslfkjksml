# UMAJ Kasir — project awal Android

Identitas: USAHA MANDIRI AL JAYA · ROTI NAROSA

## Isi yang sudah dibuat
- UI kasir responsif untuk layar HP.
- Data produk, harga modal/jual, stok, dan stok minimum.
- Penjualan dengan beberapa produk, pengurangan stok, dan nota.
- Catatan pembayaran sebagian/pelunasan utang pelanggan.
- Laporan omzet, harga pokok, laba kotor, piutang, dan biaya operasional.
- Ekspor riwayat CSV dan cadangan/pemulihan JSON.
- Tampilan berjalan dari aset lokal tanpa internet; data tersimpan di localStorage WebView.
- Kerangka Android Studio untuk membungkus aplikasi web lokal sebagai APK.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `umaj_kasir` menggunakan Android Studio versi baru.
3. Tunggu Gradle sync, lalu pilih Build > Build APK(s).
4. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Batasan penting — belum siap produksi
Ini adalah prototipe awal, bukan APK yang sudah dibangun atau diuji pada HP/printer nyata. Printer thermal Bluetooth belum diintegrasikan secara native; tombol nota saat ini membuka tampilan cetak sistem/browser dan perlu diuji. Dukungan printer Bluetooth ESC/POS berbeda-beda menurut model. Sebelum dipakai untuk pembukuan resmi, uji transaksi, pemulihan cadangan, dan kompatibilitas perangkat.

Data lokal disimpan dalam penyimpanan WebView pada HP. Menghapus data aplikasi dapat menghapus data usaha, jadi ekspor cadangan JSON secara rutin. Laporan laba saat ini menghitung laba kotor penjualan dikurangi biaya operasional yang dicatat pada periode terpilih; bukan laporan akuntansi tersertifikasi.

## Integrasi printer Bluetooth 58 mm (versi 1.1.0)
- Native Android bridge memakai Bluetooth Classic SPP (UUID standar) untuk printer yang sudah dipasangkan di pengaturan Android.
- Mendukung daftar perangkat berpasangan, pilihan printer, cetak uji, dan kirim teks struk dengan inisialisasi ESC/POS.
- Target Android 12 / API 32 meminta izin Bluetooth Connect saat diperlukan.
- Format struk dibungkus sekitar 32 karakter per baris untuk kertas 58 mm; karakter non-ASCII diubah menjadi `?` agar tidak menyebabkan byte tak dikenal pada printer generik.

### Cara membangun APK
1. Ekstrak ZIP, lalu buka folder `umaj_kasir` di Android Studio.
2. Pasang Android SDK Platform 35 dan Android Gradle Plugin yang diminta Gradle Sync.
3. Tunggu Gradle Sync, lalu pilih **Build > Build APK(s)**.
4. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk` jika build berhasil.
5. Di HP, pasangkan printer pada Pengaturan > Bluetooth, buka UMAJ Kasir > Data usaha > Printer thermal Bluetooth, pilih perangkat, lalu cetak struk uji.

### Batasan dan uji wajib
- APK belum dibangun atau diuji di perangkat nyata dalam lingkungan ini karena Android SDK/Gradle build environment tidak tersedia di sini.
- Printer generik harus mendukung **Bluetooth Classic SPP** dan ESC/POS. Printer BLE-only atau printer dengan protokol proprietary tidak otomatis kompatibel.
- Periksa hasil cetak, pemotongan kertas, lebar teks, dan pengkodean karakter di model printer sebenarnya. Perintah potong kertas mungkin diabaikan oleh printer tanpa pemotong otomatis.
- Data usaha tersimpan pada localStorage WebView. Ekspor cadangan JSON rutin; menghapus data aplikasi dapat menghapus data usaha.
- Ini adalah build pengembangan/debug, bukan APK produksi yang telah diuji atau ditandatangani untuk distribusi.
