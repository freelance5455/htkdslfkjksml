UMAJ KASIR — USAHA MANDIRI AL JAYA / ROTI NAROSA

ISI PAKET
1. android-source/ : project Android Studio (Java + WebView + jembatan printer Bluetooth SPP/ESC-POS).
2. pratinjau/      : tampilan aplikasi HTML, manifest, ikon, dan service worker untuk mode offline bila disajikan melalui HTTPS/localhost.

STATUS PENTING
- Paket ini BELUM berupa APK siap instal.
- Lingkungan pembuatan saat ini tidak memiliki Android SDK/Gradle build tools untuk mengompilasi dan menguji APK.
- Printer 58 mm didukung pada project Android untuk printer Bluetooth Classic SPP yang sudah dipasangkan dan menerima ESC/POS. Printer BLE-only/protokol khusus mungkin tidak kompatibel.
- Data pada WebView disimpan lokal. Gunakan fitur cadangan JSON secara berkala. Menghapus data aplikasi dapat menghapus data usaha.

CARA MEMBANGUN APK DI KOMPUTER
1. Instal Android Studio.
2. Ekstrak paket ZIP.
3. Buka folder android-source sebagai project.
4. Pasang Android SDK Platform 35 jika diminta dan tunggu Gradle Sync.
5. Pilih Build > Build APK(s).
6. APK debug umumnya dibuat di android-source/app/build/outputs/apk/debug/app-debug.apk.
7. Pasangkan printer lewat Pengaturan Bluetooth HP. Buka UMAJ Kasir > Data usaha > Printer thermal Bluetooth > pilih printer > cetak struk uji.

CATATAN PRATINJAU
File pratinjau/index.html dapat dibuka untuk melihat dan mencoba antarmuka. Untuk pemasangan PWA dengan cache offline, berkas perlu disajikan dari HTTPS atau localhost lalu pilih menu browser “Tambahkan ke layar utama”. Cetak Bluetooth native hanya tersedia dalam APK Android yang memakai jembatan Java.
