# راه‌اندازی سرور و ساخت APK (به ترتیب)

## ۱) سرور (یک بار)
1. یک VPS با Ubuntu 24.04 + یک دامنه که رکورد A آن به IP سرور اشاره کند.
2. پوشهٔ `server` را روی سرور کپی کن و اجرا کن:
   `sudo ./install.sh api.example.com`
3. آخر نصب، `ADMIN_TOKEN` و `SYNC_TOKEN` چاپ می‌شود؛ هر دو را نگه دار.
4. تست: `curl https://api.example.com/health` باید `ok:true` بدهد.

## ۲) APK
1. فایل `myket-android/gradle.properties` را باز کن و پر کن:
   ```
   TRADYAR_SERVER_URLS=https://api.example.com
   TRADYAR_SYNC_TOKEN=مقدار_SYNC_TOKEN
   ```
2. Android Studio: Build → Clean Project، بعد Rebuild و ساخت APK/AAB امضاشده.
3. نیازی به اجرای `set-server-url.py` نیست (فقط برای نسخهٔ وب لازم است).

## ۳) تست
- با دو گوشی: از گوشی کاربر تیکت بفرست؛ در گوشی مدیر باید دیده شود.
- روی سرور: `curl -H "x-tradyar-token: SYNC_TOKEN" https://api.example.com/sync`

## نکته
اگر صفحه از خود سرور باز شود (https://api.example.com/app)، آن سرور خودکار سرور اصلی است.
سرورهای قدیمی workers.dev فقط پشتیبان‌اند و داده را در سرویس عمومی textdb.dev نگه می‌دارند (محدود و بدون ادغام)؛ به آن‌ها تکیه نکن.

## افزودن سرور از داخل پنل مدیریت (بدون ساخت دوبارهٔ APK)
پنل مدیریت ← تب «سرورها» ← «URL سرور جدید» (مثلاً `https://api.example.com`) + «توکن همگام‌سازی» (`SYNC_TOKEN`) ← «تست اتصال» ← «افزودن سرور».
- آدرس و توکن همراه تنظیمات به همهٔ گوشی‌ها همگام می‌شود.
- سرور اختصاصی همیشه مرجع است؛ سرورهای workers.dev فقط پشتیبان‌اند.
- اگر پیام «توکن اشتباه است (401)» آمد، توکن را از فایل `.env` سرور (`SYNC_TOKEN`) بردار و دوباره وارد کن.

## نگه‌داری همیشگی اطلاعات
- سرور هر ۵ دقیقه (در صورت تغییر) نسخه می‌گیرد، **روزانه تا ۱۰ سال** و **ماهانه بدون پایان** نگه می‌دارد (`/data/backups`).
- بکاپ بیرون از سرور (پیشنهاد جدی): در پوشهٔ `server` اجرا کن `./offsite-backup.sh` و برای اجرای روزانه در `crontab -e` بنویس:
  `0 3 * * * /opt/tradyar/server/offsite-backup.sh`
  اگر `rclone` داری: `RCLONE_REMOTE=mydrive:tradyar-backups` را هم بگذار تا نسخه بیرون از سرور هم برود.
- بازیابی: `./restore.sh` (فهرست) و `./restore.sh monthly-2026-11.json`
- هر گوشی هم یک نسخهٔ کامل محلی دارد؛ اگر سرور خالی شود، گوشی‌ها دوباره داده را می‌فرستند.
