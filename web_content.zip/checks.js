import { parseCSV, MINUTE } from './data.js';
import { Aggregator, Layer, CRT } from './strategy.js';
import { backtest, createBasket, netAt, validateParams } from './engine.js';
const base = { balance: 10000, risk: 100, lots: 0.1, point: 0.01, pointValue: 1, spread: 0, slippage: 0, commission: 0, minStop: 0, maxStop: 0, minLot: 0.01, lotStep: 0.01, pivot: 2, atr: 2, tolerance: 0.35, buffer: 0.2, hold: 60 };
function assert(value, message) { if (!value) throw new Error(message); }
function near(a, b) { assert(Math.abs(a - b) < 1e-7, `Expected ${b}, received ${a}`); }
const candle = (n, open = 100, high = 101, low = 99, close = 100) => ({ t: n * MINUTE, open, high, low, close, volume: 1 });
// Synthetic signal injection is confined to engine tests; actual runs always use CRT.
function onceSignal(side = 'BUY', stop = 90) {
  return () => { let count = 0; return { stats: {}, update() {}, signal(b) { count++; return count === 1 ? { side, stop, signalTime: b.t, level: stop, atr: 1 } : null; } }; };
}
// Controlled indicator states isolate CRT alignment and sweep gates from aggregation tests.
function alignedFixture(buy) {
  const s = new CRT(base, () => {}); const side = buy ? 'BUY' : 'SELL';
  const bar = buy ? candle(20000, 99.5, 103, 99, 102.5) : candle(20000, 100.5, 101, 97, 97.5);
  const low = buy ? 99 : 97; const high = buy ? 103 : 101;
  Object.assign(s.h4, { count: 62, atr: 1, high: { value: buy ? 102 : 101 }, low: { value: buy ? 98 : 97 }, displacement: { side, low, high, mid: (low + high) / 2 } });
  Object.assign(s.m15, { atr: 1, high: { value: 101 }, low: { value: 99 }, displacement: { side, mid: 100 }, bars: Array.from({ length: 8 }, () => ({ ...bar })) });
  Object.assign(s.m1, { atr: 1, low: { value: 100 }, high: { value: 100 } });
  return { s, bar };
}
export async function runChecks() {
  const outcomes = [];
  const check = async (name, fn) => { try { await fn(); outcomes.push({ name, passed: true }); } catch (error) { outcomes.push({ name, passed: false, error: error.message }); } };
  await check('CSV normalization and invalid-row rejection', async () => {
    const parsed = await parseCSV('timestamp,open,high,low,close\n2025-01-01T00:00:00Z,1,2,0.5,1.5\n2025-01-01T00:01:00Z,1.5,2,1,1.8');
    near(parsed.bars[0].t, Date.UTC(2025, 0, 1, 0, 1));
    for (const text of [
      'timestamp,open,high,low,close\n2025-02-30T00:00:00Z,1,2,0.5,1',
      'timestamp,open,high,low,close\n2025-01-01T00:00:00Z,1,0.5,0.4,1',
      'timestamp,open,high,low,close\n2025-01-01T00:00:00Z,1,2,0.5,1\n2025-01-01T00:00:00Z,1,2,0.5,1'
    ]) { let rejected = false; try { await parseCSV(text); } catch { rejected = true; } assert(rejected, 'Malformed input was accepted'); }
  });
  await check('MT5 tab-separated date and time columns', async () => {
    const data = await parseCSV('<DATE>\t<TIME>\t<OPEN>\t<HIGH>\t<LOW>\t<CLOSE>\t<TICKVOL>\n2025.01.01\t00:00:00\t1\t2\t0.5\t1.5\t20');
    near(data.bars[0].volume, 20);
  });
  await check('Complete HTF buckets only; gaps excluded', () => {
    const a = new Aggregator(15); let full = null;
    for (let i = 1; i <= 15; i++) { const result = a.add(candle(i)); if (i < 15) assert(result === null, 'Partial bucket leaked'); full = result; }
    assert(full?.count === 15, 'Full bucket missing');
    const partial = new Aggregator(15); for (let i = 2; i <= 15; i++) assert(partial.add(candle(i)) === null, 'Partial bucket accepted');
    const gap = new Aggregator(15); for (let i = 1; i <= 15; i++) if (i !== 8) assert(gap.add(candle(i)) === null, 'Gap bucket accepted');
  });
  await check('Wilder ATR seed excludes the first true range', () => {
    const layer = new Layer(2, 2); layer.add(candle(1)); layer.add(candle(2, 100, 103, 99, 101));
    assert(layer.atr === null, 'ATR became available too soon');
    layer.add(candle(3, 101, 104, 100, 102)); near(layer.atr, 4);
    layer.add(candle(4, 102, 103, 101, 102)); near(layer.atr, 3);
  });
  await check('Pivots appear after right-window confirmation', () => {
    const layer = new Layer(2, 2);
    [101, 102, 105, 103].forEach((h, i) => layer.add(candle(i + 1, 100, h, 99, 100)));
    assert(layer.high === null, 'Pivot used future bars');
    layer.add(candle(5, 100, 102, 99, 100)); near(layer.high.value, 105); near(layer.high.confirmed, 5 * MINUTE);
  });
  await check('Three equal legs, next-open entry, positive basket exit', async () => {
    const r = await backtest([candle(1), candle(2, 100, 102, 99, 101)], base, { strategyFactory: onceSignal() });
    assert(r.trades.length === 1 && r.trades[0].legs === 3, 'Three-leg basket missing');
    near(r.trades[0].entryTime, MINUTE); near(r.trades[0].entry, 100); near(r.net, 30);
    assert(r.trades[0].reason === 'Positive basket', 'Wrong exit');
  });
  await check('Spread, adverse slippage and round-trip fees', () => {
    const p = { ...base, spread: 2, slippage: 1, commission: 3 };
    const f = createBasket({ side: 'BUY', stop: 90, signalTime: MINUTE }, candle(2), 10000, p);
    near(f.basket.entry, 100.03); near(netAt(f.basket, 101, p).net, 27);
    const s = createBasket({ side: 'SELL', stop: 110, signalTime: MINUTE }, candle(2), 10000, p);
    near(s.basket.entry, 99.99); near(netAt(s.basket, 99, p).net, 27);
  });
  await check('Stop-first ordering and adverse gap fills', async () => {
    const p = { ...base, point: 1 };
    const r = await backtest([candle(1), candle(2, 100, 110, 89, 105)], p, { strategyFactory: onceSignal() });
    assert(r.trades[0].reason === 'Stop loss', 'Profit outranked stop'); near(r.trades[0].exit, 90);
    const gap = await backtest([candle(1), candle(2), candle(3, 85, 88, 80, 86)], p, { strategyFactory: onceSignal() });
    assert(gap.trades[0].reason === 'Stop gap', 'Gap not detected'); near(gap.trades[0].exit, 85);
  });
  await check('SELL stop uses ask rather than bid', async () => {
    const r = await backtest([candle(1), candle(2, 100, 109.99, 99.99, 100)], { ...base, spread: 2 }, { strategyFactory: onceSignal('SELL', 110) });
    assert(r.trades[0].reason === 'Stop loss', 'Ask stop not triggered'); near(r.trades[0].exit, 110);
  });
  await check('Risk rejection; maximum stop never tightens structure', () => {
    const s = { side: 'BUY', stop: 90, signalTime: MINUTE };
    assert(createBasket(s, candle(2), 10000, { ...base, risk: 0.01 }).rejected === 'basket risk cap', 'Risk cap not enforced');
    assert(createBasket(s, candle(2), 10000, { ...base, maxStop: 5 }).rejected === 'maximum stop distance', 'Maximum stop not enforced');
    let rejected = false; try { validateParams({ ...base, lots: 0.015 }); } catch { rejected = true; } assert(rejected, 'Off-step volume accepted');
  });
  await check('Holding timeout, final liquidation, missing-next-bar rejection', async () => {
    const timed = await backtest([candle(1), candle(2), candle(3)], { ...base, hold: 2 }, { strategyFactory: onceSignal() });
    assert(timed.trades[0].reason === 'Time limit' && timed.trades[0].holdMinutes === 2, 'Holding timeout failed');
    const end = await backtest([candle(1), candle(2)], base, { strategyFactory: onceSignal() });
    assert(end.trades[0].reason === 'End of data', 'Final position not liquidated');
    const gap = await backtest([candle(1), candle(4)], base, { strategyFactory: onceSignal() });
    assert(gap.trades.length === 0 && gap.skips.gap === 1, 'Entry survived a missing next candle');
  });
  await check('CRT never produces signals before H4 warm-up', async () => {
    const logs = []; const s = new CRT(base, (...args) => logs.push(args));
    for (let i = 1; i <= 300; i++) { const b = candle(i); s.update(b); assert(s.signal(b) === null, 'Warm-up signal emitted'); }
    assert(s.stats.h4Bars === 1, 'H4 aggregation count incorrect');
  });
  await check('Aligned BUY/SELL CRT sweeps trigger with structural stops', () => {
    for (const buy of [true, false]) {
      const { s, bar } = alignedFixture(buy); const signal = s.signal(bar);
      assert(signal?.side === (buy ? 'BUY' : 'SELL'), 'Aligned sweep did not trigger');
      near(signal.stop, buy ? 98.8 : 101.2);
      const wrongSide = alignedFixture(buy); wrongSide.s.m15.displacement.side = buy ? 'SELL' : 'BUY';
      assert(wrongSide.s.signal(wrongSide.bar) === null, 'Opposite M15 displacement was accepted');
      const weak = alignedFixture(buy); weak.bar.open = weak.bar.close;
      assert(weak.s.signal(weak.bar) === null, 'Weak body was accepted');
    }
  });
  await check('Missing metadata and gapped-through entry stops fail closed', async () => {
    for (const side of ['BUY', 'SELL']) {
      const buy = side === 'BUY'; const signal = { side, stop: buy ? 101 : 99, signalTime: MINUTE };
      assert(createBasket(signal, candle(2), 10000, { ...base, minStop: 500 }).rejected === 'invalid stop after entry gap', 'Broker minimum rescued an invalid setup');
    }
    let rejected = false; try { validateParams({ ...base, spread: undefined }); } catch { rejected = true; } assert(rejected, 'Missing spread accepted');
    rejected = false; try { await backtest([], base); } catch { rejected = true; } assert(rejected, 'Empty history accepted');
  });
  return outcomes;
}
