plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.ibs.dra"
    compileSdk = 34
    defaultConfig { applicationId = "com.ibs.dra"; minSdk = 29; targetSdk = 34; versionCode = 2; versionName = "2.0" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
