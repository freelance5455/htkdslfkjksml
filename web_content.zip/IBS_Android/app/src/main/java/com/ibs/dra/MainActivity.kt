package com.ibs.dra

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.*
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {

    companion object {
        // Offline copy bundled inside the app (works without internet, data stays on this phone).
        const val LOCAL_URL = "https://appassets.androidplatform.net/assets/index.html"
        // Shared online site (all agents, live tracking). Needs internet + claude.ai sign-in.
        // To use the offline copy only, change this to: const val START_URL = LOCAL_URL
        const val START_URL = "https://claude.ai/artifact/QmyYMafFWmvJsZ3BXGqhXG"
    }

    private lateinit var web: WebView
    private var callback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null

    inner class Bridge {
        @JavascriptInterface
        fun save(name: String, text: String) {
            try {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, if (name.endsWith(".json")) "application/json" else "text/csv")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray()) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setGeolocationEnabled(true)
            mediaPlaybackRequiresUserGesture = false
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.addJavascriptInterface(Bridge(), "AndroidApp")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)

            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                // No internet / site unreachable: fall back to the offline copy.
                if (r.isForMainFrame && START_URL != LOCAL_URL && r.url.toString() == START_URL) {
                    Toast.makeText(this@MainActivity, "Offline: using this phone's local copy", Toast.LENGTH_LONG).show()
                    v.loadUrl(LOCAL_URL)
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) {
                val ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                cb.invoke(origin, ok, false)
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }

            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                callback?.onReceiveValue(null)
                callback = cb
                val wantsPhoto = p.isCaptureEnabled || p.acceptTypes.any { it.startsWith("image") }
                val camera = Intent(MediaStore.ACTION_IMAGE_CAPTURE).also {
                    val cv = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "visit_${System.currentTimeMillis()}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    }
                    cameraUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    it.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                }
                try {
                    if (p.isCaptureEnabled) {
                        startActivityForResult(camera, 1)
                    } else {
                        val pick = Intent(Intent.ACTION_GET_CONTENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                        val chooser = Intent.createChooser(pick, "Select file")
                        if (wantsPhoto) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera))
                        startActivityForResult(chooser, 1)
                    }
                } catch (e: Exception) {
                    callback?.onReceiveValue(null); callback = null
                    return false
                }
                return true
            }
        }

        web.loadUrl(START_URL)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1) {
            val u: Array<Uri>? = when {
                res != RESULT_OK -> null
                data?.data != null -> arrayOf(data.data!!)
                cameraUri != null -> arrayOf(cameraUri!!)
                else -> null
            }
            callback?.onReceiveValue(u); callback = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
