# Última Noche: Mundo Muerto — bosque arcano

## Contenido
- Proyecto HTML/JavaScript autocontenido para abrir en un navegador moderno.
- Bosque mágico sin carreteras y cabañas con colisión.
- Seis biomas generados por regiones: bosque esmeralda, pradera luminosa, pantano de hongos, cristal arcano, tundra lunar y tierras de brasa, además de pequeños estanques.
- Música psytrance oscura sintetizada en tiempo real con Web Audio: pad espectral, bajo pulsante, golpes graves y arpegios. Se inicia al tocar «ENTRAR AL MUNDO» para respetar las restricciones de audio de los navegadores móviles. El botón «PSYTRANCE ON/OFF» la silencia o reactiva.
- Controles y HUD adaptables a orientación horizontal. El juego solicita bloquear la orientación en horizontal cuando el navegador lo permite; si no, gira el teléfono manualmente y desactiva el bloqueo de rotación del sistema.

## Cómo probarlo en Android
1. Extrae el ZIP.
2. Abre `index.html` con un navegador moderno (por ejemplo, Chrome).
3. Pulsa «ENTRAR AL MUNDO» para iniciar el juego y la música.
4. Gira el teléfono a horizontal. Si no cambia automáticamente, activa la rotación automática en Android y gira el teléfono.

## Nota
Este ZIP contiene el proyecto web del juego, no un APK compilado. La música es sintetizada en el dispositivo y no necesita descargar archivos de audio. El bloqueo de orientación depende del navegador y de cómo se abra el juego.
