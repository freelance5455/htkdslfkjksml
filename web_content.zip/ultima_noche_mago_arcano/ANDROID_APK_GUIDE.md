ÚLTIMA NOCHE: MUNDO MUERTO — proyecto Android
================================================

Este ZIP contiene un prototipo de supervivencia 2D de mundo abierto para navegador:
- mundo explorable generado alrededor del jugador
- carreteras sinuosas con marcas centrales y bordes
- árboles muertos con colisiones sólidas
- edificios con textura de ladrillos, ventanas rotas y colisiones
- niebla roja y ciclo día/noche
- criaturas deformes que persiguen al mago
- tres hechizos de energía infinita, con destellos, anillos mágicos y partículas al lanzar
- botiquines y piezas para recoger
- minimapa, controles táctiles y controles de teclado
- pantalla de derrota y reinicio

PRUEBA EN ANDROID
1. Extrae el ZIP con el administrador de archivos.
2. Abre index.html con Chrome. Si el gestor de archivos no permite abrirlo, copia la carpeta a un ordenador y abre index.html en Chrome.
3. Pulsa ENTRAR AL MUNDO.

IMPORTANTE: este ZIP NO es un APK compilado. Para instalar como aplicación Android, empaqueta index.html dentro de una app WebView (por ejemplo con Android Studio) y compila un APK. Los pasos básicos están en ANDROID_APK_GUIDE.md.

COMPILAR UN APK CON ANDROID STUDIO (WebView)
1. Instala Android Studio y el Android SDK.
2. Crea un proyecto nuevo Empty Views Activity (Kotlin), Minimum SDK Android 7.0/API 24 o superior.
3. Copia index.html a app/src/main/assets/index.html (crea la carpeta assets si no existe).
4. En activity_main.xml usa un WebView que ocupe toda la pantalla.
5. En MainActivity.kt activa JavaScript y carga file:///android_asset/index.html.
6. En AndroidManifest.xml añade android:screenOrientation="landscape" a la Activity si prefieres jugar horizontal; no hace falta permiso de Internet.
7. Build > Build Bundle(s) / APK(s) > Build APK(s).
8. Android Studio mostrará la ruta del APK generado, normalmente app/build/outputs/apk/debug/app-debug.apk.
9. Pasa ese APK al teléfono y permite instalar aplicaciones desde esa fuente si Android lo solicita.

Código de ejemplo Kotlin para MainActivity.kt:
------------------------------------------------
package com.example.ultimanoche

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.setBackgroundColor(android.graphics.Color.BLACK)
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }
}

Nota: si tu plantilla usa Activity sin AppCompat, cambia la clase base a android.app.Activity y elimina la dependencia AppCompat. El APK debug es para pruebas; para publicar necesitas generar un APK firmado.
