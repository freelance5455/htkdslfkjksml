import 'dotenv/config';
import express from 'express';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import nodemailer from 'nodemailer';
import { OAuth2Client } from 'google-auth-library';
import Anthropic from '@anthropic-ai/sdk';

const { JWT_SECRET, ANTHROPIC_API_KEY, GOOGLE_CLIENT_ID, APP_URL = 'http://localhost:3000', PORT = 3000,
  MODEL = 'claude-sonnet-5-5', SMTP_HOST, SMTP_PORT = 587, SMTP_USER, SMTP_PASS, SMTP_FROM } = process.env;
if (!JWT_SECRET || !ANTHROPIC_API_KEY) throw new Error('Set JWT_SECRET and ANTHROPIC_API_KEY in .env');

const db = new Database(process.env.DB_PATH || 'mo3aw.db');
db.pragma('journal_mode = WAL'); db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT, pw TEXT, memory_on INTEGER DEFAULT 0, reset_hash TEXT, reset_exp INTEGER, created INTEGER);
CREATE TABLE IF NOT EXISTS chats(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, title TEXT, updated INTEGER);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE, role TEXT, content TEXT, created INTEGER);
CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, text TEXT, created INTEGER);
CREATE INDEX IF NOT EXISTS i_chats ON chats(user_id, updated); CREATE INDEX IF NOT EXISTS i_msgs ON messages(chat_id);`);

const ai = new Anthropic({ apiKey: ANTHROPIC_API_KEY });
const gClient = GOOGLE_CLIENT_ID ? new OAuth2Client(GOOGLE_CLIENT_ID) : null;
const mailer = SMTP_HOST ? nodemailer.createTransport({ host: SMTP_HOST, port: +SMTP_PORT, auth: { user: SMTP_USER, pass: SMTP_PASS } }) : null;
const now = () => Date.now();
const sha = s => crypto.createHash('sha256').update(s).digest('hex');

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'", 'https://accounts.google.com'],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ['https://fonts.gstatic.com'],
  imgSrc: ["'self'", 'data:'], frameSrc: ['https://accounts.google.com'], connectSrc: ["'self'", 'https://accounts.google.com'] } } }));
app.use(express.json({ limit: '12mb' }));
app.use(express.static('public'));
const authLimit = rateLimit({ windowMs: 15 * 60e3, limit: 30 });
const chatLimit = rateLimit({ windowMs: 60e3, limit: 20 });

// ---------- auth helpers ----------
const setSession = (res, id) => res.cookie('sid', jwt.sign({ id }, JWT_SECRET, { expiresIn: '30d' }),
  { httpOnly: true, sameSite: 'lax', secure: APP_URL.startsWith('https'), maxAge: 30 * 864e5 });
const auth = (req, res, next) => {
  const m = /(?:^|; )sid=([^;]+)/.exec(req.headers.cookie || '');
  try { req.user = db.prepare('SELECT * FROM users WHERE id=?').get(jwt.verify(m?.[1], JWT_SECRET).id); } catch {}
  req.user ? next() : res.status(401).json({ error: 'unauthorized' });
};
const pub = u => ({ id: u.id, email: u.email, name: u.name, memory_on: !!u.memory_on });
const validEmail = e => typeof e === 'string' && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) && e.length < 255;

app.get('/api/config', (_, res) => res.json({ googleClientId: GOOGLE_CLIENT_ID || null }));

app.post('/api/auth/signup', authLimit, async (req, res) => {
  const { email, password, name } = req.body;
  if (!validEmail(email) || typeof password !== 'string' || password.length < 8) return res.status(400).json({ error: 'bad_input' });
  if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email.toLowerCase())) return res.status(409).json({ error: 'exists' });
  const r = db.prepare('INSERT INTO users(email,name,pw,created) VALUES(?,?,?,?)')
    .run(email.toLowerCase(), String(name || '').slice(0, 80), await bcrypt.hash(password, 12), now());
  setSession(res, r.lastInsertRowid);
  res.json(pub(db.prepare('SELECT * FROM users WHERE id=?').get(r.lastInsertRowid)));
});
app.post('/api/auth/login', authLimit, async (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(String(req.body.email || '').toLowerCase());
  if (!u?.pw || !(await bcrypt.compare(String(req.body.password || ''), u.pw))) return res.status(401).json({ error: 'invalid' });
  setSession(res, u.id); res.json(pub(u));
});
app.post('/api/auth/google', authLimit, async (req, res) => {
  if (!gClient) return res.status(501).json({ error: 'google_not_configured' });
  try {
    const p = (await gClient.verifyIdToken({ idToken: req.body.credential, audience: GOOGLE_CLIENT_ID })).getPayload();
    if (!p.email_verified) return res.status(401).json({ error: 'unverified' });
    let u = db.prepare('SELECT * FROM users WHERE email=?').get(p.email.toLowerCase());
    if (!u) { const r = db.prepare('INSERT INTO users(email,name,created) VALUES(?,?,?)').run(p.email.toLowerCase(), p.name || '', now()); u = db.prepare('SELECT * FROM users WHERE id=?').get(r.lastInsertRowid); }
    setSession(res, u.id); res.json(pub(u));
  } catch { res.status(401).json({ error: 'invalid_google_token' }); }
});
app.post('/api/auth/forgot', authLimit, async (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(String(req.body.email || '').toLowerCase());
  if (u && mailer) {
    const t = crypto.randomBytes(32).toString('hex');
    db.prepare('UPDATE users SET reset_hash=?, reset_exp=? WHERE id=?').run(sha(t), now() + 36e5, u.id);
    mailer.sendMail({ from: SMTP_FROM, to: u.email, subject: 'mo3aw AI — استعادة كلمة المرور',
      html: `<div dir="rtl"><p>اضغط الرابط لتعيين كلمة مرور جديدة (صالح لمدة ساعة):</p><a href="${APP_URL}/?reset=${t}">${APP_URL}/?reset=${t}</a></div>` }).catch(console.error);
  }
  res.json({ ok: true }); // نفس الرد دائمًا لمنع كشف الحسابات
});
app.post('/api/auth/reset', authLimit, async (req, res) => {
  const { token, password } = req.body;
  if (typeof password !== 'string' || password.length < 8 || typeof token !== 'string') return res.status(400).json({ error: 'bad_input' });
  const u = db.prepare('SELECT * FROM users WHERE reset_hash=? AND reset_exp>?').get(sha(token), now());
  if (!u) return res.status(400).json({ error: 'expired' });
  db.prepare('UPDATE users SET pw=?, reset_hash=NULL, reset_exp=NULL WHERE id=?').run(await bcrypt.hash(password, 12), u.id);
  res.json({ ok: true });
});
app.post('/api/auth/logout', (_, res) => res.clearCookie('sid').json({ ok: true }));

// ---------- profile / data ----------
app.get('/api/me', auth, (req, res) => res.json(pub(req.user)));
app.patch('/api/me', auth, (req, res) => {
  const { name, memory_on } = req.body;
  if (name !== undefined) db.prepare('UPDATE users SET name=? WHERE id=?').run(String(name).slice(0, 80), req.user.id);
  if (memory_on !== undefined) db.prepare('UPDATE users SET memory_on=? WHERE id=?').run(memory_on ? 1 : 0, req.user.id);
  res.json(pub(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)));
});
app.delete('/api/me', auth, (req, res) => { db.prepare('DELETE FROM users WHERE id=?').run(req.user.id); res.clearCookie('sid').json({ ok: true }); });
app.get('/api/chats', auth, (req, res) => res.json(db.prepare('SELECT id,title,updated FROM chats WHERE user_id=? ORDER BY updated DESC LIMIT 200').all(req.user.id)));
app.get('/api/chats/:id', auth, (req, res) => {
  const c = db.prepare('SELECT id FROM chats WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
  if (!c) return res.sendStatus(404);
  res.json(db.prepare('SELECT role,content FROM messages WHERE chat_id=? ORDER BY id').all(c.id).map(m => ({ role: m.role, content: JSON.parse(m.content) })));
});
app.delete('/api/chats/:id', auth, (req, res) => { db.prepare('DELETE FROM chats WHERE id=? AND user_id=?').run(req.params.id, req.user.id); res.json({ ok: true }); });
app.get('/api/memories', auth, (req, res) => res.json(db.prepare('SELECT id,text FROM memories WHERE user_id=? ORDER BY id DESC').all(req.user.id)));
app.delete('/api/memories/:id', auth, (req, res) => { db.prepare('DELETE FROM memories WHERE id=? AND user_id=?').run(req.params.id, req.user.id); res.json({ ok: true }); });

// ---------- chat (streaming SSE) ----------
const AGENTS = {
  general: '',
  research: 'أنت وكيل بحث: ابحث في الإنترنت عدة مرات، قارن المصادر، ولخّص النتائج مع ذكر المصادر.',
  coder: 'أنت وكيل برمجة: اكتب كودًا نظيفًا وآمنًا، اشرح القرارات باختصار، وفكّر في الحالات الحدية.',
  writer: 'أنت وكيل كتابة: حرّر النصوص بأسلوب واضح ومناسب للجمهور المطلوب.',
  planner: 'أنت وكيل تخطيط: قسّم أي مهمة كبيرة إلى خطوات قابلة للتنفيذ مع أولويات وتقدير زمني.'
};
const SYSTEM = `أنت mo3aw AI (شعارك: Your Intelligence. Without Limits.)، مساعد ذكاء اصطناعي.
- ردّ بنفس لغة المستخدم. تفهّم اللهجة المصرية تمامًا، ولو كتب بالمصري ردّ بمصرية بسيطة ومهذبة، وإلا بالعربية الفصحى المبسطة.
- كن دقيقًا ومباشرًا، ولا تخترع معلومات؛ قل إنك غير متأكد عند الحاجة.
- ما تعرفه من بحث الويب اذكر مصدره.`;
const MEM_TOOL = { name: 'save_memory', description: 'احفظ معلومة دائمة ومفيدة عن المستخدم (تفضيلات، اسم، مهنة). لا تحفظ بيانات حساسة.',
  input_schema: { type: 'object', properties: { fact: { type: 'string' } }, required: ['fact'] } };

app.post('/api/chat', auth, chatLimit, async (req, res) => {
  const { content, agent = 'general', web = false } = req.body;
  if (!Array.isArray(content) || !content.length) return res.status(400).json({ error: 'bad_input' });
  const blocks = content.filter(b => (b.type === 'text' && typeof b.text === 'string') ||
    (b.type === 'image' && /^image\/(png|jpe?g|gif|webp)$/.test(b.source?.media_type)));
  let chat = req.body.chatId && db.prepare('SELECT * FROM chats WHERE id=? AND user_id=?').get(req.body.chatId, req.user.id);
  if (!chat) {
    const t = (blocks.find(b => b.type === 'text')?.text || 'محادثة جديدة').slice(0, 50);
    const r = db.prepare('INSERT INTO chats(user_id,title,updated) VALUES(?,?,?)').run(req.user.id, t, now());
    chat = { id: r.lastInsertRowid };
  }
  const hist = db.prepare('SELECT role,content FROM messages WHERE chat_id=? ORDER BY id DESC LIMIT 30').all(chat.id).reverse()
    .map(m => ({ role: m.role, content: JSON.parse(m.content) }));
  db.prepare('INSERT INTO messages(chat_id,role,content,created) VALUES(?,?,?,?)').run(chat.id, 'user', JSON.stringify(blocks), now());
  const msgs = [...hist, { role: 'user', content: blocks }];

  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' }); res.flushHeaders();
  const send = o => res.write(`data: ${JSON.stringify(o)}\n\n`);
  send({ chatId: chat.id });
  const ctrl = new AbortController(); res.on('close', () => ctrl.abort());

  const memOn = !!req.user.memory_on;
  const mems = memOn ? db.prepare('SELECT text FROM memories WHERE user_id=? ORDER BY id DESC LIMIT 40').all(req.user.id).map(m => '- ' + m.text) : [];
  const system = [SYSTEM, AGENTS[agent] || '', req.user.name ? `اسم المستخدم: ${req.user.name}` : '',
    mems.length ? 'ذاكرة المستخدم (وافق على حفظها):\n' + mems.join('\n') : ''].filter(Boolean).join('\n\n');
  const tools = [...(web ? [{ type: 'web_search_20250305', name: 'web_search', max_uses: agent === 'research' ? 6 : 3 }] : []), ...(memOn ? [MEM_TOOL] : [])];

  let full = '';
  try {
    for (let i = 0; i < 4; i++) {
      const s = ai.messages.stream({ model: MODEL, max_tokens: 4096, system, messages: msgs, ...(tools.length && { tools }) }, { signal: ctrl.signal });
      s.on('text', t => { full += t; send({ t }); });
      const m = await s.finalMessage();
      const uses = m.content.filter(b => b.type === 'tool_use' && b.name === 'save_memory');
      if (m.stop_reason !== 'tool_use' || !uses.length) break;
      msgs.push({ role: 'assistant', content: m.content });
      msgs.push({ role: 'user', content: uses.map(u => {
        db.prepare('INSERT INTO memories(user_id,text,created) VALUES(?,?,?)').run(req.user.id, String(u.input.fact).slice(0, 300), now());
        send({ memory: u.input.fact }); return { type: 'tool_result', tool_use_id: u.id, content: 'saved' };
      }) });
    }
    db.prepare('INSERT INTO messages(chat_id,role,content,created) VALUES(?,?,?,?)').run(chat.id, 'assistant', JSON.stringify([{ type: 'text', text: full || '…' }]), now());
    db.prepare('UPDATE chats SET updated=? WHERE id=?').run(now(), chat.id);
    send({ done: true });
  } catch (e) { if (!ctrl.signal.aborted) { console.error(e.message); send({ error: 'ai_error' }); } }
  res.end();
});

app.listen(PORT, () => console.log(`mo3aw AI → ${APP_URL}`));
