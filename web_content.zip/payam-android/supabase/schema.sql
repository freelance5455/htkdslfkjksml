-- Payam backend. Run in the Supabase SQL editor. Enable Email OTP (or Phone) in Authentication settings.
create table profiles(
  id uuid primary key references auth.users on delete cascade,
  username text unique, name text default 'User', bio text default '',
  emoji text default '😎', color text default '#2aabee',
  tier text default 'free' check (tier in ('free','plus','pro','ultra')),
  is_admin boolean default false, banned boolean default false,
  created_at timestamptz default now());
create table chats(
  id uuid primary key default gen_random_uuid(),
  kind text check (kind in ('dm','group','channel','saved')) not null,
  title text, description text default '', emoji text default '💬',
  owner uuid references profiles(id), created_at timestamptz default now());
create table members(
  chat_id uuid references chats on delete cascade, user_id uuid references profiles on delete cascade,
  role text default 'member', muted boolean default false, primary key(chat_id,user_id));
create table messages(
  id uuid primary key default gen_random_uuid(),
  chat_id uuid references chats on delete cascade, user_id uuid references profiles,
  body text not null check (length(body)<=4000), reply_to uuid, deleted boolean default false,
  created_at timestamptz default now());
create index on messages(chat_id,created_at);
create table reports(
  id uuid primary key default gen_random_uuid(), reporter uuid references profiles,
  message_id uuid, user_id uuid, reason text, status text default 'open', created_at timestamptz default now());
create table banned_words(word text primary key);

create function is_admin() returns boolean language sql security definer stable as
$$ select coalesce((select is_admin from profiles where id=auth.uid()),false) $$;
create function is_member(c uuid) returns boolean language sql security definer stable as
$$ select exists(select 1 from members where chat_id=c and user_id=auth.uid()) $$;

create table contacts(owner uuid references profiles on delete cascade, contact_id uuid references profiles on delete cascade, primary key(owner,contact_id));
create function can_post(c uuid) returns boolean language sql security definer stable as
$$ select exists(select 1 from chats x where x.id=c and (x.kind<>'channel' or exists(select 1 from members m where m.chat_id=c and m.user_id=auth.uid() and m.role in ('owner','admin')))) $$;
create function new_user() returns trigger language plpgsql security definer as $$
begin insert into profiles(id,username,name) values(new.id,'u'||substr(replace(new.id::text,'-',''),1,8),split_part(coalesce(new.email,'user'),'@',1)); insert into members(chat_id,user_id) values('00000000-0000-0000-0000-000000000001',new.id); return new; end $$;
create trigger on_signup after insert on auth.users for each row execute function new_user();

create function guard_message() returns trigger language plpgsql security definer as $$
begin
  if (select banned from profiles where id=new.user_id) then raise exception 'banned'; end if;
  if exists(select 1 from banned_words w where lower(new.body) like '%'||lower(w.word)||'%') then raise exception 'filtered'; end if;
  return new; end $$;
create trigger msg_guard before insert on messages for each row execute function guard_message();

create function start_dm(other uuid) returns uuid language plpgsql security definer as $$
declare c uuid; begin
  select m1.chat_id into c from members m1 join members m2 on m1.chat_id=m2.chat_id join chats ch on ch.id=m1.chat_id
   where ch.kind='dm' and m1.user_id=auth.uid() and m2.user_id=other limit 1;
  if c is null then
    insert into chats(kind,owner) values('dm',auth.uid()) returning id into c;
    insert into members(chat_id,user_id) values(c,auth.uid()),(c,other);
  end if; return c; end $$;

create function admin_set(uid uuid, b boolean, t text) returns void language plpgsql security definer as $$
begin if not is_admin() then raise exception 'forbidden'; end if;
 update profiles set banned=b, tier=t where id=uid; end $$;

alter table profiles enable row level security; alter table chats enable row level security;
alter table members enable row level security; alter table messages enable row level security;
alter table contacts enable row level security; alter table reports enable row level security; alter table banned_words enable row level security;

create policy p_read on profiles for select to authenticated using(true);
create policy p_upd on profiles for update to authenticated using(id=auth.uid());
revoke update on profiles from authenticated;
grant update(username,name,bio,emoji,color) on profiles to authenticated;

create policy c_read on chats for select to authenticated using(kind in ('group','channel') or is_member(id) or is_admin());
create policy c_ins on chats for insert to authenticated with check(owner=auth.uid() and kind in ('group','channel','saved'));
create policy m_read on members for select to authenticated using(is_member(chat_id) or is_admin());
create policy m_join on members for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from chats where id=chat_id and (kind in ('group','channel') or owner=auth.uid())));
create policy m_upd on members for update to authenticated using(user_id=auth.uid());
create policy m_leave on members for delete to authenticated using(user_id=auth.uid());
create policy g_read on messages for select to authenticated using(is_member(chat_id) or is_admin());
create policy g_ins on messages for insert to authenticated with check(user_id=auth.uid() and is_member(chat_id) and can_post(chat_id));
create policy g_upd on messages for update to authenticated using(user_id=auth.uid() or is_admin());
create policy r_ins on reports for insert to authenticated with check(reporter=auth.uid());
create policy r_read on reports for select to authenticated using(is_admin());
create policy r_upd on reports for update to authenticated using(is_admin());
create policy w_all on banned_words for all to authenticated using(is_admin()) with check(is_admin());
create policy ct_all on contacts for all to authenticated using(owner=auth.uid()) with check(owner=auth.uid());
alter publication supabase_realtime add table messages;
-- Official rules channel (new users are joined to it automatically; only owners/admins can post)
insert into chats(id,kind,title,description,emoji) values('00000000-0000-0000-0000-000000000001','channel','قوانین Payam','قوانین رسمی استفاده از اپ | Official app rules','📜');
insert into messages(chat_id,user_id,body) values('00000000-0000-0000-0000-000000000001',null,$$📜 قوانین Payam

۱. به همه احترام بگذار؛ توهین، تحقیر و تهدید ممنوعه.
۲. محتوای غیرقانونی، خشونت شدید و هر محتوای جنسی مرتبط با کودکان ممنوعه.
۳. تبلیغات مزاحم و اسپم ممنوعه.
۴. اطلاعات خصوصی دیگران رو منتشر نکن.
۵. تخلف رو با دکمه‌ی «گزارش» اعلام کن. مدیران ممکنه پیام رو حذف و حساب متخلف رو مسدود کنند.

Rules: be respectful, no illegal or violent content, no sexual content involving minors, no spam, no doxxing. Use Report for violations; admins may delete messages and ban accounts.$$);
-- First admin (run in the SQL editor as owner): update profiles set is_admin=true where username='YOUR_USERNAME';
