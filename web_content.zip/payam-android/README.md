# Payam: Android messenger (Capacitor + Supabase)

## What is here
- `supabase/schema.sql`: database, row-level security, ban and word-filter enforcement, admin functions
- `www/index.html`: the app (Persian/English, groups, private chats, user and group info, saved messages, search, explore, premium tiers, PIN lock, multi-account, profile)
- `admin/index.html`: admin panel (users, ban/unban, tier, reports, banned words). Host it on any static host (Netlify, Cloudflare Pages) and keep the URL private.

## Steps
1. Create a free project at supabase.com. Run `supabase/schema.sql` in the SQL editor.
2. Authentication > Providers: enable Email (OTP). For phone login enable Phone and connect an SMS provider (cost per SMS).
3. Put your Project URL and anon key in `www/index.html` and `admin/index.html` (`CFG`). The anon key is public by design; security comes from the RLS policies.
4. Make yourself admin: sign up once in the app, then run in the SQL editor:
   `update profiles set is_admin=true where username='YOUR_USERNAME';`
5. Download Vazirmatn-Regular.woff2 into `www/fonts/` so Persian text looks right offline.
6. On a computer with Node and Android Studio:
   ```
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
   Change `appId` in `capacitor.config.json` to your own (it cannot change after publishing). Add your icon and splash, then Build > Generate Signed App Bundle (.aab).
7. Play Console: create the app, upload the .aab, fill Data safety, Content rating, and a Privacy Policy URL.

## Before you publish (important)
- **Premium payments are not wired.** The Premium screen calls `window.PayamBilling.buy(tier)` if present. You need a Capacitor billing plugin (Google Play Billing), then a server-side check (Supabase Edge Function using the Play Developer API) that sets `profiles.tier`. The client can never set the tier itself; only `admin_set` can.
- **No end-to-end encryption.** Messages are protected in transit and by RLS, but the server can read them. Do not market it as E2E.
- **Play policy for chat apps** requires report, block and moderation tools, a privacy policy and account deletion. Reports and admin bans are here; add user blocking and an in-app "delete account" before submitting.
- **Not tested.** This was written without running it. Expect to fix bugs; test with two accounts first.
- Missing on purpose: push notifications (Firebase Cloud Messaging), images and files, voice messages, calls, typing indicators.
