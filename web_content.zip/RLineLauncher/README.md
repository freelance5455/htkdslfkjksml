# R-Line Launcher — PassatCC

Launcher Android personnalisé reproduisant l'écran d'accueil R-Line (horloge analogique
en temps réel, tuiles Navigation/Musique/Téléphone/Bluetooth/Radio/Applications,
barre de navigation inférieure, indicateurs température/batterie/heure).

## Compiler l'APK avec Android Studio

1. Ouvrir Android Studio → **Open** → sélectionner le dossier `RLineLauncher`.
2. Laisser Gradle synchroniser (Android Studio télécharge automatiquement le SDK
   et les build-tools nécessaires — c'est ce qui n'était pas possible dans
   l'environnement de génération, sans accès à dl.google.com).
3. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. L'APK signé debug se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.
5. Transférer l'APK sur la clé USB / carte SD et l'installer sur l'autoradio
   (activer "Sources inconnues" dans les paramètres Android du poste).

## Définir comme launcher par défaut

L'app déclare les catégories `LAUNCHER` + `HOME`, donc à la première ouverture
Android proposera de la définir comme écran d'accueil par défaut.
Sur certains autoradios chinois (MTCB/T100), il faut le faire depuis
**Paramètres → Applications → Application par défaut → Application d'accueil**.

## Structure

- `app/src/main/assets/index.html` — toute l'interface (HTML/CSS/JS), horloge
  pilotée par `setInterval` sur l'heure système du boîtier.
- `app/src/main/java/.../MainActivity.java` — WebView plein écran, immersif,
  bouton retour désactivé (comportement launcher), garde l'écran allumé.
- Icônes générées dans `res/mipmap-*`.

## Prochaines étapes possibles

- Ajouter l'écran "dashboard complet" (2ᵉ maquette) comme second écran
  accessible via la tuile VÉHICULE.
- Brancher les tuiles sur de vrais intents (ouvrir appli GPS/musique/téléphone
  installée sur le boîtier au lieu de placeholders).
- Lire la température/tension batterie réelles via CAN/OBD2 au lieu des
  valeurs statiques du mockup.
