MATHS FORMULA HUB
=================

FILES
- index.html: page structure and content containers
- style.css: responsive dark interface
- script.js: formulas, search/filter, favourites, lessons, spoken quiz, and speech controls

HOW TO RUN
1. Keep all three files in the same folder.
2. Open index.html in a modern browser (Chrome, Edge, Safari, or Firefox).
3. Click "Listen" or open Audio settings to select an installed English voice.
4. The speech engine is provided by the browser/device; voice choices and sound quality vary by device.
5. If you use VS Code, you can open the folder and run index.html with a local server / Live Server extension.

AUDIO NOTES
- Uses the browser Web Speech API (SpeechSynthesis) when supported.
- The requested American English locale is set to en-US; an available en-US voice is selected when possible.
- Browser speech synthesis is not the same as a hosted generative AI voice. For consistent, premium neural voices, connect a speech API and host audio securely.
- Some browsers require a user tap before audio playback. Use the Listen buttons.
- Browser speech synthesis does not expose a reliable duration/progress event in all browsers, so the player shows playback state rather than an exact progress timeline.
- This starter project includes 30 formulas and 8 scripted lessons as a foundation; it is expandable by adding objects to the arrays in script.js.

CUSTOMIZATION
- Add formulas to the `formulas` array in script.js.
- Add lessons to the `lessons` array.
- Add quiz questions to the `quizQuestions` array.
- Favourite formulas are stored in localStorage in the current browser.
