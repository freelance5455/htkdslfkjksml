// Nova AI — small beginner-friendly Gemini chatbot server
// Requires Node.js 18+. Keep your API key in .env, never in public/index.html.
const http = require("http");
const fs = require("fs");
const path = require("path");

// Tiny .env loader so beginners do not need extra packages.
const envPath = path.join(__dirname, ".env");
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, "utf8").split(/\\r?\\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const index = trimmed.indexOf("=");
    if (index < 1) continue;
    const name = trimmed.slice(0, index).trim();
    let value = trimmed.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (name && process.env[name] === undefined) process.env[name] = value;
  }
}

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const PUBLIC_DIR = path.join(__dirname, "public");

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml"
};

function sendJson(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 100_000) {
        reject(new Error("Request is too large."));
        req.destroy();
      }
    });
    req.on("end", () => {
      try { resolve(JSON.parse(body || "{}")); }
      catch { reject(new Error("Invalid JSON request.")); }
    });
    req.on("error", reject);
  });
}

function extractText(result) {
  // Interactions API output commonly contains steps with model_output content blocks.
  if (typeof result.output_text === "string" && result.output_text.trim()) {
    return result.output_text.trim();
  }
  const pieces = [];
  for (const step of (result.steps || [])) {
    if (step.type === "model_output") {
      for (const item of (step.content || [])) {
        if (item.type === "text" && item.text) pieces.push(item.text);
      }
    }
  }
  return pieces.join("\n").trim();
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (req.method === "GET" && url.pathname === "/api/health") {
    return sendJson(res, 200, { ok: true, keyConfigured: Boolean(API_KEY), model: MODEL });
  }

  if (req.method === "POST" && url.pathname === "/api/chat") {
    if (!API_KEY) {
      return sendJson(res, 503, {
        error: "API key is not configured. Add GEMINI_API_KEY to your .env file and restart the server."
      });
    }

    let body;
    try { body = await readBody(req); }
    catch (err) { return sendJson(res, 400, { error: err.message || "Invalid request." }); }

    const messages = Array.isArray(body.messages) ? body.messages : [];
    const cleanMessages = messages
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-20)
      .map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));

    if (!cleanMessages.length || cleanMessages[cleanMessages.length - 1].role !== "user") {
      return sendJson(res, 400, { error: "Send a message to start chatting." });
    }

    // Format the short conversation history into a single prompt.
    const transcript = cleanMessages.map(m =>
      `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`
    ).join("\n\n");

    const prompt = [
      "You are Nova AI, a helpful, friendly general-purpose assistant.",
      "Answer clearly and accurately. Match the user's language when practical.",
      "If you are unsure, say so. Use readable Markdown when it helps.",
      "",
      "Conversation so far:",
      transcript,
      "",
      "Assistant:"
    ].join("\n");

    try {
      const apiResponse = await fetch("https://generativelanguage.googleapis.com/v1beta/interactions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": API_KEY
        },
        body: JSON.stringify({
          model: MODEL,
          input: prompt
        })
      });

      const raw = await apiResponse.text();
      let data;
      try { data = JSON.parse(raw); }
      catch { data = {}; }

      if (!apiResponse.ok) {
        const detail = data.error?.message || `Gemini request failed (${apiResponse.status}).`;
        return sendJson(res, apiResponse.status, { error: detail });
      }

      const reply = extractText(data);
      if (!reply) {
        return sendJson(res, 502, { error: "Gemini returned an empty reply. Try again or choose another model in .env." });
      }
      return sendJson(res, 200, { reply, model: MODEL });
    } catch (err) {
      return sendJson(res, 502, { error: "Could not reach Gemini. Check your internet connection and try again." });
    }
  }

  if (req.method !== "GET" && req.method !== "HEAD") {
    res.writeHead(405, { "Content-Type": "text/plain; charset=utf-8", "Allow": "GET, HEAD, POST" });
    return res.end("Method not allowed");
  }

  const requested = url.pathname === "/" ? "/index.html" : decodeURIComponent(url.pathname);
  const filePath = path.normalize(path.join(PUBLIC_DIR, requested));
  if (!filePath.startsWith(PUBLIC_DIR + path.sep) && filePath !== path.join(PUBLIC_DIR, "index.html")) {
    res.writeHead(403); return res.end("Forbidden");
  }
  fs.readFile(filePath, (err, content) => {
    if (err) { res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" }); return res.end("Not found"); }
    res.writeHead(200, {
      "Content-Type": MIME[path.extname(filePath)] || "application/octet-stream",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      "Cache-Control": "no-cache"
    });
    res.end(content);
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`Nova AI is running at http://localhost:${PORT}`);
  console.log(`Model: ${MODEL}`);
  console.log(API_KEY ? "Gemini API key: configured" : "Gemini API key: MISSING — add GEMINI_API_KEY to .env");
});
