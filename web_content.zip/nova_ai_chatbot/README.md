# Nova AI — Gemini Chatbot

A mobile-friendly ChatGPT-style web app using Gemini through a small Node.js backend. The API key is kept server-side.

## Before you start

- Install Node.js 18 or newer from https://nodejs.org/
- Get a Gemini API key at https://aistudio.google.com/apikey
- Since a key was shared in chat, revoke/rotate that old key first. Use only your new key.

## Setup

1. Extract this ZIP to a folder.
2. Copy `.env.example` to a new file named `.env`.
3. Open `.env` and replace `PASTE_YOUR_NEW_KEY_HERE` with your NEW key. Do not share `.env`.
4. Open a terminal/command prompt in the project folder.
5. Run `npm start`.
6. Open `http://localhost:3000` in your browser.

No `npm install` is needed: the server uses Node.js built-in modules and built-in `fetch`.

## If it does not reply

- Make sure Node.js is version 18+ (`node -v`).
- Confirm `.env` is named exactly `.env`, not `.env.txt`.
- Restart `npm start` after editing `.env`.
- Check the API key is active and the Gemini API is enabled.
- Check your AI Studio usage/quota and that the selected model is available to your account.
- If the model name is unavailable, edit `GEMINI_MODEL` in `.env` to a model currently enabled for your free tier, then restart the server.

## Free tier and privacy

Gemini API free usage has model-specific limits and availability; it is not unlimited. Review current limits in Google AI Studio. Do not send confidential personal information in chats. Chat history is stored in localStorage in the browser you use; use “Clear saved chats” to delete it from that browser.

## Security

- Never paste your API key into `public/index.html`.
- Never upload `.env` to GitHub or share it.
- This server binds to `127.0.0.1`, so it is intended for local use on your own computer. To publish online, deploy the backend with a server-side secret/environment variable and add rate limiting/authentication first.
