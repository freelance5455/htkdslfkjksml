package br.com.casadoscorretores.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
