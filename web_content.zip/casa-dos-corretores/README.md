# Casa dos Corretores — app Android

App em HTML/JS empacotado como app nativo com **Capacitor**.
O código do app fica em `www/index.html`. A pasta `android/` é o projeto Android Studio.

## Como gerar o APK (sem instalar nada no PC)

1. Crie um repositório **privado** no GitHub e envie esta pasta (pelo site: *Add file > Upload files*, arrastando tudo, inclusive a pasta `.github`).
2. No repositório, abra a aba **Actions > Gerar APK e AAB > Run workflow**.
3. Espere uns 5 a 8 minutos. Ao terminar, baixe em **Artifacts** o arquivo `CasaDosCorretores-teste-apk` (um .zip com o `app-debug.apk`).
4. Passe o `.apk` para o celular, abra e permita "instalar apps desconhecidos" quando o Android pedir.

## Como publicar na Play Store

A Play Store exige um arquivo **.aab assinado**. Faça uma vez:

1. Crie a chave de assinatura (precisa do Java instalado):
   `keytool -genkeypair -v -keystore release.jks -alias casa -keyalg RSA -keysize 2048 -validity 10000`
   **Guarde o `release.jks` e as senhas num lugar seguro: sem eles você não consegue atualizar o app.**
2. Converta a chave para texto: `base64 -w0 release.jks` (no Mac: `base64 -i release.jks`).
3. No GitHub: *Settings > Secrets and variables > Actions > New repository secret* e crie:
   - `KEYSTORE_BASE64` (o texto do passo 2)
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS` (no exemplo: `casa`)
   - `KEY_PASSWORD` (opcional, se for igual à senha do keystore)
4. Rode o workflow de novo. Agora sai também o artifact `CasaDosCorretores-playstore` com o `.aab`.
5. Na [Play Console](https://play.google.com/console) (taxa única de US$ 25), crie o app e envie o `.aab`.

## Atualizar o app

- Edite `www/index.html`, suba para o GitHub e rode o workflow.
- A cada versão nova na Play Store, aumente `versionCode` (e `versionName`) em `android/app/build.gradle`.

## Rodar no seu PC (opcional)

`npm install`, `npx cap sync android`, `npx cap open android` (precisa do Android Studio).

## Observações

- O app usa a fonte Figtree do Google Fonts: precisa de internet na primeira abertura.
- Os dados (imóveis, clientes) hoje são de demonstração e ficam só na memória. Para guardar de verdade é preciso adicionar armazenamento ou um servidor.
- O "plano pago" é uma simulação, sem cobrança real. Para cobrar na Play Store é preciso usar o Google Play Billing.
- ID do app: `br.com.casadoscorretores.app` (em `capacitor.config.json`). Troque antes de publicar se quiser outro; depois de publicado não muda.
