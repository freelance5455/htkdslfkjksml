CryptoPulse V101.4
Historical candle fix.
- LBank V2 kline history now includes the required `time` parameter.
- Requests up to 2000 one-minute bars, then aggregates locally to 1m/5m/15m/1h/4h/1d/1w.
- LBank WebSocket kbar ISO timestamps are parsed correctly.
- Shared 1-minute cache now preserves OHLCV from kbar updates.
- V101.3 runtime and V101.2 pull-to-refresh fixes are retained.
