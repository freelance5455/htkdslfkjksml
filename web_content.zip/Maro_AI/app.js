const WORKER_URL = "https://ancient-mouse-890dmaro-ai-api.sr-anis-sr.workers.dev";
const $ = (id) => document.getElementById(id);
const state = { image: null, imageData: null, busy: false, language: localStorage.getItem("maro-language") || "ar", tool: "chat" };
const translations = {
 ar: {tagline:"مساعدك الذكي الشخصي",newChat:"محادثة جديدة",tools:"الأدوات",chat:"محادثة ذكية",image:"فهم الصور",code:"مساعد البرمجة",write:"الكتابة والترجمة",ready:"جاهز للانطلاق",assistant:"مساعد Maro",welcomeTitle:'أهلاً، أنا <span>Maro AI</span>',welcomeText:"مساعدك الذكي للإبداع، التعلّم، البرمجة وكل أفكارك.",ideaTitle:"اشرح فكرة",ideaSub:"بأسلوب بسيط وواضح",writeTitle:"اكتب محتوى",writeSub:"منشور، رسالة أو قصة",codeTitle:"اكتب كوداً",codeSub:"برمجة مع شرح",translateTitle:"ترجم نصاً",translateSub:"بين لغات متعددة",placeholder:"اكتب رسالتك إلى Maro AI...",hint:"Maro AI قد يخطئ أحياناً — راجع المعلومات المهمة.",settingsTitle:"إعدادات Maro AI",settingsIntro:"اربط الموقع بخادم الذكاء الاصطناعي الخاص بك.",endpointLabel:"رابط الخادم (Worker URL)",endpointHelp:"لا تضع مفتاح API هنا. المفتاح يبقى محفوظاً في إعدادات الخادم فقط.",save:"حفظ الإعدادات",privacyTitle:"مهم:",privacyText:"لا تضع مفتاح Gemini أو أي مفتاح سري داخل ملفات الموقع المنشورة.",you:"أنت",thinking:"Maro AI يفكر...",noEndpoint:"أضف رابط خادم الذكاء الاصطناعي من الإعدادات أولاً.",requestError:"تعذر الاتصال بالمساعد. تحقق من رابط الخادم والإنترنت.",voiceUnsupported:"المتصفح لا يدعم الإدخال الصوتي. جرّب Chrome.",listening:"أستمع إليك الآن…",copied:"",imageAttached:"صورة مرفقة",imagePrompt:"حلّل هذه الصورة واشرح محتواها."},
 fr: {tagline:"Votre assistant IA personnel",newChat:"Nouvelle conversation",tools:"OUTILS",chat:"Discussion IA",image:"Comprendre une image",code:"Assistant de code",write:"Écriture et traduction",ready:"Prêt à démarrer",assistant:"Assistant Maro",welcomeTitle:'Bonjour, je suis <span>Maro AI</span>',welcomeText:"Votre assistant pour créer, apprendre, programmer et explorer vos idées.",ideaTitle:"Expliquer une idée",ideaSub:"Simple et clairement",writeTitle:"Créer du contenu",writeSub:"Post, message ou histoire",codeTitle:"Écrire du code",codeSub:"Code avec explications",translateTitle:"Traduire un texte",translateSub:"Entre plusieurs langues",placeholder:"Écrivez à Maro AI...",hint:"Maro AI peut se tromper — vérifiez les informations importantes.",settingsTitle:"Paramètres Maro AI",settingsIntro:"Connectez le site à votre serveur IA.",endpointLabel:"URL du serveur (Worker URL)",endpointHelp:"Ne mettez pas votre clé API ici. Gardez-la dans les paramètres du serveur.",save:"Enregistrer",privacyTitle:"Important :",privacyText:"Ne placez jamais votre clé API dans les fichiers publics du site.",you:"Vous",thinking:"Maro AI réfléchit...",noEndpoint:"Ajoutez d'abord l'URL du serveur dans les paramètres.",requestError:"Connexion impossible. Vérifiez l'URL et Internet.",voiceUnsupported:"La saisie vocale n'est pas prise en charge. Essayez Chrome.",listening:"Je vous écoute…",imageAttached:"Image jointe",imagePrompt:"Analyse cette image et décris son contenu."},
 en: {tagline:"Your personal AI assistant",newChat:"New chat",tools:"TOOLS",chat:"AI chat",image:"Understand images",code:"Coding assistant",write:"Writing & translation",ready:"Ready to go",assistant:"Maro Assistant",welcomeTitle:'Hello, I’m <span>Maro AI</span>',welcomeText:"Your assistant for creating, learning, coding, and exploring ideas.",ideaTitle:"Explain an idea",ideaSub:"Simply and clearly",writeTitle:"Create content",writeSub:"Post, message, or story",codeTitle:"Write code",codeSub:"Code with explanations",translateTitle:"Translate text",translateSub:"Across languages",placeholder:"Message Maro AI...",hint:"Maro AI can make mistakes — verify important information.",settingsTitle:"Maro AI settings",settingsIntro:"Connect the site to your AI server.",endpointLabel:"Server URL (Worker URL)",endpointHelp:"Do not put your API key here. Keep it only in server settings.",save:"Save settings",privacyTitle:"Important:",privacyText:"Never put your Gemini key or other secret keys in public website files.",you:"You",thinking:"Maro AI is thinking...",noEndpoint:"Add your AI server URL in Settings first.",requestError:"Could not reach the assistant. Check the server URL and internet.",voiceUnsupported:"Voice input is not supported. Try Chrome.",listening:"Listening…",imageAttached:"Image attached",imagePrompt:"Analyze this image and describe its contents."}
};
function tr(key){return (translations[state.language]||translations.ar)[key] || translations.ar[key] || key;}
function applyLanguage(){
 const t=translations[state.language]||translations.ar;
 document.documentElement.lang=state.language; document.documentElement.dir=state.language==="ar"?"rtl":"ltr";
 document.querySelectorAll("[data-i18n]").forEach(el=>{const key=el.dataset.i18n;if(t[key]!==undefined)el.innerHTML=t[key];});
 document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>{const key=el.dataset.i18nPlaceholder;if(t[key])el.placeholder=t[key];});
 $("languageSelect").value=state.language; localStorage.setItem("maro-language",state.language);
}
function showSettings(){ $("apiEndpoint").value=localStorage.getItem("maro-endpoint")||WORKER_URL; $("settingsModal").hidden=false; }
function addMessage(role,text,imageUrl=null){
 $("welcome").style.display="none";
 const row=document.createElement("div");row.className="message "+role;
 const avatar=document.createElement("div");avatar.className="avatar";avatar.textContent=role==="user"?"◉":"M";
 const bubble=document.createElement("div");bubble.className="bubble";
 if(imageUrl){const img=document.createElement("img");img.src=imageUrl;img.alt=tr("imageAttached");bubble.appendChild(img);}
 const content=document.createElement("div");content.textContent=text;bubble.appendChild(content);
 row.append(avatar,bubble);$("messages").appendChild(row);$("conversation").scrollTop=$("conversation").scrollHeight;return row;
}
function resizeInput(){const el=$("promptInput");el.style.height="auto";el.style.height=Math.min(el.scrollHeight,150)+"px";}
function setBusy(value){state.busy=value;$("sendBtn").disabled=value;$("sendBtn").innerHTML=value?"…":"<span>➤</span>";}
async function sendMessage(overrideText=null){
 if(state.busy)return;
 let prompt=(overrideText!==null?overrideText:$("promptInput").value).trim();
 if(!prompt && !state.imageData)return;
 if(state.imageData && !prompt)prompt=tr("imagePrompt");
 const endpoint=(localStorage.getItem("maro-endpoint")||WORKER_URL).trim().replace(/\/+$/,"");
 const imgData=state.imageData, imgUrl=state.image?URL.createObjectURL(state.image):null;
 addMessage("user",prompt,imgUrl);
 $("promptInput").value="";resizeInput();
 state.image=null;state.imageData=null;$("imagePreview").hidden=true;
 if(!endpoint){addMessage("assistant",tr("noEndpoint")+" ⚙");showSettings();return;}
 const typing=addMessage("assistant",tr("thinking"));typing.querySelector(".bubble").classList.add("typing");
 setBusy(true);
 try{
   const payload={message:prompt,language:state.language,tool:state.tool};
   if(imgData)payload.image=imgData;
   const response=await fetch(endpoint+"/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
   const data=await response.json().catch(()=>({}));
   if(!response.ok)throw new Error(data.error||"HTTP "+response.status);
   typing.querySelector(".bubble").classList.remove("typing");
   typing.querySelector(".bubble div").textContent=data.reply||"No response.";
 }catch(err){typing.querySelector(".bubble").classList.remove("typing");typing.querySelector(".bubble div").textContent=tr("requestError")+" ("+String(err.message||"").slice(0,120)+")";}
 finally{setBusy(false);$("conversation").scrollTop=$("conversation").scrollHeight;}
}
$("sendBtn").addEventListener("click",()=>sendMessage());
$("promptInput").addEventListener("input",resizeInput);
$("promptInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage();}});
$("newChat").addEventListener("click",()=>{$("messages").innerHTML="";$("welcome").style.display="";$("promptInput").value="";state.image=null;state.imageData=null;$("imagePreview").hidden=true;$("sidebar").classList.remove("open");});
document.querySelectorAll(".quick-card").forEach(b=>b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
document.querySelectorAll(".side-tool").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".side-tool").forEach(x=>x.classList.remove("active"));b.classList.add("active");state.tool=b.dataset.tool;$("sidebar").classList.remove("open");const hints={chat:"",image:tr("imagePrompt"),code:"ساعدني في كتابة كود وشرحه خطوة بخطوة",write:"ساعدني في الكتابة أو الترجمة"};if(hints[state.tool])$("promptInput").value=hints[state.tool];$("promptInput").focus();}));
$("attachBtn").addEventListener("click",()=>$("imageInput").click());
$("imageInput").addEventListener("change",async e=>{const f=e.target.files[0];if(!f)return;if(!f.type.startsWith("image/"))return;if(f.size>8*1024*1024){alert("Choose an image under 8 MB.");return;}state.image=f;const dataUrl=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f);});state.imageData=String(dataUrl).split(",")[1];$("previewImg").src=dataUrl;$("imageName").textContent=f.name;$("imagePreview").hidden=false;e.target.value="";});
$("removeImage").addEventListener("click",()=>{state.image=null;state.imageData=null;$("imagePreview").hidden=true;});
function voiceInput(){
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){alert(tr("voiceUnsupported"));return;}
 const rec=new SR();rec.lang=state.language==="ar"?"ar-DZ":state.language==="fr"?"fr-FR":"en-US";rec.interimResults=false;
 $("micBtn").textContent="●";rec.onresult=e=>{$("promptInput").value=e.results[0][0].transcript;resizeInput();};rec.onerror=()=>{};rec.onend=()=>$("micBtn").textContent="🎙";rec.start();
}
$("micBtn").addEventListener("click",voiceInput);
$("settingsBtn").addEventListener("click",showSettings);$("settingsTop").addEventListener("click",showSettings);
$("closeSettings").addEventListener("click",()=>$("settingsModal").hidden=true);
$("settingsModal").addEventListener("click",e=>{if(e.target===$("settingsModal"))$("settingsModal").hidden=true;});
$("saveSettings").addEventListener("click",()=>{localStorage.setItem("maro-endpoint",$("apiEndpoint").value.trim().replace(/\/+$/,""));$("settingsModal").hidden=true;});
$("languageSelect").addEventListener("change",e=>{state.language=e.target.value;applyLanguage();});
$("menuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
applyLanguage();
