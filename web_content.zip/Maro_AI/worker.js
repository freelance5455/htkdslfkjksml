// Cloudflare Worker backend for Maro AI.
// Add GEMINI_API_KEY as a secret in Cloudflare Worker settings. Never put it in the website.
const MODEL = "gemini-2.5-flash";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*", // For production, replace * with your website's domain.
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8"
};
function json(data, status=200) {
  return new Response(JSON.stringify(data), {status, headers:corsHeaders});
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, {status:204, headers:corsHeaders});
    if (url.pathname === "/") return new Response("Maro AI API is running.", {headers:{"Content-Type":"text/plain; charset=utf-8"}});
    if (url.pathname !== "/api/chat") return json({error:"Not found"},404);
    if (request.method !== "POST") return json({error:"Use POST"},405);
    if (!env.GEMINI_API_KEY) return json({error:"Server API key is not configured"},500);
    let body;
    try { body = await request.json(); } catch { return json({error:"Invalid JSON"},400); }
    const message = String(body.message || "").trim().slice(0,12000);
    if (!message && !body.image) return json({error:"Message is empty"},400);
    const language = ["ar","fr","en"].includes(body.language) ? body.language : "ar";
    const tool = ["chat","image","code","write"].includes(body.tool) ? body.tool : "chat";
    const languageNames = {ar:"Arabic; use Algerian Darija when natural",fr:"French",en:"English"};
    const system = `You are Maro AI, a helpful, safe, friendly personal assistant. Reply in ${languageNames[language]}. The user may speak Algerian Darija. Be clear and practical. Tool focus: ${tool}. For code, use fenced code blocks and explain briefly. For image questions, describe only what can reasonably be inferred. Do not claim to have performed real-world actions you did not perform.`;
    const parts = [{text: system + "\n\nUser message:\n" + message}];
    if (typeof body.image === "string" && body.image.length > 0) {
      if (body.image.length > 11_000_000) return json({error:"Image is too large"},413);
      parts.push({inline_data:{mime_type:"image/jpeg",data:body.image}});
    }
    try {
      const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(env.GEMINI_API_KEY)}`, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          contents:[{role:"user",parts}],
          generationConfig:{temperature:0.7,maxOutputTokens:2048}
        })
      });
      const data = await upstream.json();
      if (!upstream.ok) {
        return json({error:data?.error?.message || "AI provider request failed"}, upstream.status===429?429:502);
      }
      const reply = (data.candidates?.[0]?.content?.parts || []).map(p=>p.text||"").join("").trim();
      if (!reply) return json({error:"The AI returned an empty response"},502);
      return json({reply});
    } catch (e) {
      return json({error:"Could not contact AI provider"},502);
    }
  }
};
