JAMSHEED Calculator - Android Project

How to make APK:
1. Open this folder in Android Studio or AndroidIDE.
2. Let Gradle sync/download the Android Gradle Plugin.
3. Build > Build APK(s), or use AndroidIDE's Build option.
4. The debug APK will be in app/build/outputs/apk/debug/.

Package: com.jamsheed.calculator
Version: 1.0
