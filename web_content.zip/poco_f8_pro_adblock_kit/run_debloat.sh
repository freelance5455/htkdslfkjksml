#!/bin/bash
echo "========================================"
echo "  Poco F8 Pro HyperOS Ad-Blocker Tool"
echo "========================================"
echo ""
echo "[1] Checking ADB connection..."
adb devices
echo ""
echo "Press Enter to start disabling ad packages..."
read

echo "Disabling MSA (MIUI System Ads)..."
adb shell pm uninstall -k --user 0 com.miui.systemAdSolution

echo "Disabling GetApps..."
adb shell pm uninstall -k --user 0 com.xiaomi.mipicks

echo "Disabling MIUI Analytics..."
adb shell pm uninstall -k --user 0 com.miui.analytics

echo ""
echo "========================================"
echo "  Done! Please reboot your phone."
echo "========================================"
