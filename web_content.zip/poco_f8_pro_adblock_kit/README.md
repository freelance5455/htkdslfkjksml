# Poco F8 Pro / HyperOS Ad-Blocking & Debloat Kit

Welcome to your ultimate ad-blocking and optimization kit tailored for the **Poco F8 Pro** running **HyperOS**.

## What's Inside This Package?
1. **Interactive Dashboard (`index.html`)**: Open this in any browser for a fully guided visual checklist, ADB command generator, and step-by-step instructions.
2. **Automated ADB Scripts (`run_debloat.bat` & `run_debloat.sh`)**: Quick scripts to connect via USB debugging and toggle/disable system ad packages safely.
3. **HyperOS Package Reference (`packages.json`)**: Verified package names for MSA, getApps, Analytics, and recommendations on HyperOS.

---

## Quick Start Guide (No Root Required)

### Step 1: Enable Developer Options on Poco F8 Pro
1. Go to **Settings** > **About phone** > **OS version** (tap it 7 times until you see "You are now a developer!").
2. Go back to **Settings** > **Additional settings** > **Developer options**.
3. Enable **USB debugging** and **USB debugging (Security settings)** (the latter requires a SIM card / Mi Account verification on HyperOS).

### Step 2: Use the Automated Script or Dashboard
* **Windows**: Double-click `run_debloat.bat`.
* **Mac/Linux**: Open terminal in folder and run `./run_debloat.sh`.
* **Visual Guide**: Open `index.html` in your web browser.

---
*Created with Hyper Code Forge for Poco F8 Pro.*
