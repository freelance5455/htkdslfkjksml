@echo off
TITLE Poco F8 Pro HyperOS Ad-Blocker & Debloater
COLOR 0A
echo ========================================================
echo   Poco F8 Pro HyperOS Ad-Blocking & Debloat Tool
echo ========================================================
echo.
echo [1] Checking ADB connection...
adb devices
echo.
echo Make sure USB Debugging and USB Debugging (Security) are enabled on your Poco F8 Pro!
echo.
PAUSE

echo.
echo Disabling common HyperOS ad packages safely...
echo.

echo Disabling MSA (MIUI System Ads)...
adb shell pm uninstall -k --user 0 com.miui.systemAdSolution

echo Disabling GetApps...
adb shell pm uninstall -k --user 0 com.xiaomi.mipicks

echo Disabling MIUI Analytics...
adb shell pm uninstall -k --user 0 com.miui.analytics

echo.
echo ========================================================
echo   Process complete! Restart your Poco F8 Pro.
echo ========================================================
PAUSE
