# V73 — Excel Buttons Native GET_CONTENT Fix

Built directly from V72.

## Fix
- Choose File now uses the simplest Android `ACTION_GET_CONTENT` contract (`*/*`) from the native bridge, avoiding vendor-specific failures caused by `ACTION_OPEN_DOCUMENT`, MIME extras, and persistable permission flags.
- Android native import and WebView HTML file chooser retain separate request codes.
- Download Excel template now uses Android's standard `ACTION_CREATE_DOCUMENT` Save As flow as the primary path instead of relying on MediaStore Downloads insertion.
- Added explicit success/error callbacks and Toast feedback for template saving.
- Desktop/browser fallback still uses the HTML file input.
- No Supabase SQL/schema/function changes.
