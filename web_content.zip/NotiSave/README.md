# NotiSave

แอป Android บันทึกประวัติการแจ้งเตือน ใช้ HTML/CSS/JS เป็น UI (WebView) และ Java เป็น Native Backend

## วิธี Build APK

**วิธีที่ 1: Android Studio (ง่ายสุด)**
1. ติดตั้ง Android Studio (Koala หรือใหม่กว่า) แล้วเลือก File > Open ชี้ไปที่โฟลเดอร์ `NotiSave`
2. รอ Gradle Sync (ต้องต่ออินเทอร์เน็ตครั้งแรก เพื่อโหลด Gradle 8.9, Android Gradle Plugin 8.7.3, Room, AndroidX)
3. เมนู Build > Build Bundle(s) / APK(s) > Build APK(s)
4. ได้ไฟล์ที่ `app/build/outputs/apk/debug/app-debug.apk`

**วิธีที่ 2: บรรทัดคำสั่ง** (ต้องมี JDK 17 และ Android SDK, ตั้ง `ANDROID_HOME`)
```
gradle wrapper --gradle-version 8.9   # ครั้งเดียว เพื่อสร้าง gradlew
./gradlew assembleDebug
```

## ติดตั้งและเปิดสิทธิ์
1. ส่ง APK เข้าเครื่องแล้วติดตั้ง (อนุญาต "ติดตั้งแอปจากแหล่งที่ไม่รู้จัก")
2. เปิดแอป > เริ่มต้นใช้งาน > กด "เปิดหน้าตั้งค่า" > เปิดสวิตช์ NotiSave
3. Android 13+ ถ้าสวิตช์เป็นสีเทา: ข้อมูลแอป > ⋮ > อนุญาตการตั้งค่าที่ถูกจำกัด แล้วกลับไปเปิดสวิตช์
4. ไปแท็บ "แอป" เลือกแอปที่ต้องการบันทึก (LINE, Messenger, Telegram, WhatsApp, Instagram, SMS, Gmail เปิดไว้ให้เป็นค่าเริ่มต้น)

## โครงสร้าง
```
app/src/main/java/com/notisave/app/
  MainActivity.java          WebView + โหลด assets แบบ https ภายใน (ไม่ใช้ file://)
  AppBridge.java             window.Android (JavascriptInterface) คืนค่าเป็น JSON
  NotificationService.java   NotificationListenerService (MessagingStyle / BigTextStyle / InboxStyle)
  NotificationDatabase.java  Room Database
  NotificationDao.java       คำสั่ง query/ลบ
  NotificationEntity.java    ตารางข้อมูล
  AppPrefs.java              SharedPreferences (สถานะรายแอป ฯลฯ)
app/src/main/assets/  index.html, css/style.css, js/app.js
```

## ความเป็นส่วนตัว
- ไม่ขอสิทธิ์ INTERNET (ส่งข้อมูลออกนอกเครื่องไม่ได้) และ CSP ในหน้าเว็บปิด connect-src
- ไม่ขอ QUERY_ALL_PACKAGES (แสดงเฉพาะแอปที่มีไอคอนบนหน้าจอหลัก)
- `allowBackup=false` ข้อมูลไม่ถูกสำรองขึ้นคลาวด์
- ข้ามข้อความ OTP โดยค่าเริ่มต้น (ปิดได้ในตั้งค่า)
- อ่านเฉพาะข้อมูลที่ Android เปิดเผยผ่าน Notification API

## ข้อจำกัดที่ควรรู้
- ระบบ Android ให้ข้อความได้เท่าที่แอปต้นทางใส่ในการแจ้งเตือน (บางแอปซ่อนเนื้อหาเมื่อล็อกหน้าจอ หรือส่งเป็น "มีข้อความใหม่")
- ข้อความที่ถูกลบ/ดึงกลับก่อนที่การแจ้งเตือนจะเข้ามา จะไม่มีข้อมูลให้บันทึก
- บางยี่ห้อ (Xiaomi, OPPO, Vivo, Huawei) ฆ่าแอปเบื้องหลังแรง ให้ตั้งแบตเตอรี่ของ NotiSave เป็น "ไม่จำกัด"
- Release build เซ็นด้วย debug key เพื่อให้ติดตั้งได้ง่าย ถ้าจะเผยแพร่ ให้เปลี่ยนเป็น keystore ของคุณเอง
