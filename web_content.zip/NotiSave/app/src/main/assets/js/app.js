(function () {
  'use strict';

  var A = window.Android;
  var PAGE = 40;

  /* ---------- helpers ---------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // เรียกฟังก์ชันของ Android; ถ้าได้ string ที่เป็น JSON จะ parse ให้
  function bridge(fn) {
    var args = Array.prototype.slice.call(arguments, 1);
    if (!A || typeof A[fn] !== 'function') return null;
    try {
      var r = A[fn].apply(A, args);
      if (typeof r === 'string') {
        try { return JSON.parse(r); } catch (e) { return r; }
      }
      return r;
    } catch (e) {
      console.error('bridge ' + fn, e);
      return null;
    }
  }

  var ICONS = {
    home: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    message: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
    layers: '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/>',
    sliders: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
    trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m3 0V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/>',
    search: '<circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
    chev: '<polyline points="15 18 9 12 15 6"/>',
    chevr: '<polyline points="9 18 15 12 9 6"/>',
    alert: '<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>'
  };
  function ic(n) {
    return '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[n] || '') + '</svg>';
  }

  var MON = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function sameDay(a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
  function fmtTime(ts) {
    var d = new Date(ts), n = new Date(), diff = n - d;
    var hm = pad(d.getHours()) + ':' + pad(d.getMinutes());
    if (diff > -60000 && diff < 60000) return 'เมื่อสักครู่';
    if (diff > 0 && diff < 3600000) return Math.floor(diff / 60000) + ' นาทีที่แล้ว';
    if (sameDay(d, n)) return hm;
    var y = new Date(n); y.setDate(n.getDate() - 1);
    if (sameDay(d, y)) return 'เมื่อวาน ' + hm;
    var yr = d.getFullYear() !== n.getFullYear() ? ' ' + (d.getFullYear() + 543) : '';
    return d.getDate() + ' ' + MON[d.getMonth()] + yr + ' ' + hm;
  }
  function fmtNum(n) { return Number(n || 0).toLocaleString('th-TH'); }

  var toastTimer;
  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }

  function confirmDialog(title, text, okLabel, onOk) {
    $('#modal-title').textContent = title;
    $('#modal-text').textContent = text;
    $('#modal-ok').textContent = okLabel;
    var m = $('#modal');
    m.hidden = false;
    function close() { m.hidden = true; $('#modal-ok').onclick = null; $('#modal-cancel').onclick = null; m.onclick = null; }
    $('#modal-cancel').onclick = close;
    m.onclick = function (e) { if (e.target === m) close(); };
    $('#modal-ok').onclick = function () { close(); onOk(); };
  }

  /* ---------- state ---------- */
  var state = {
    access: false,
    asked: false,
    skipPerm: false,
    tab: 'home',
    apps: [],
    appMap: {},
    appsLoaded: false,
    groupPkg: null,
    groupName: ''
  };
  var msgFeed = { list: '#msg-list', more: '#msg-more', empty: '#msg-empty', items: [], total: 0, pkg: '', q: '' };
  var grpFeed = { list: '#gd-list', more: '#gd-more', empty: null, items: [], total: 0, pkg: '', q: '' };

  var TITLES = { home: 'หน้าหลัก', messages: 'ข้อความ', groups: 'กลุ่ม', apps: 'แอป', settings: 'ตั้งค่า' };

  /* ---------- screens ---------- */
  function show(id) {
    ['screen-nobridge', 'screen-welcome', 'screen-permission', 'screen-main'].forEach(function (s) {
      $('#' + s).hidden = (s !== id);
    });
  }

  function route() {
    state.access = bridge('hasNotificationAccess') === true;
    if (!state.access && !state.skipPerm) {
      var sdk = (bridge('getAppInfo') || {}).sdk || 0;
      $('#perm-restricted').hidden = sdk < 33;
      show('screen-permission');
    } else {
      show('screen-main');
      enterMain();
    }
  }

  var mainReady = false;
  function enterMain() {
    if (!mainReady) {
      mainReady = true;
      setTab('home');
      setTimeout(function () { loadApps(); refreshCurrent(); }, 30);
    } else {
      refreshCurrent();
    }
  }

  /* ---------- apps ---------- */
  function loadApps() {
    var list = bridge('getInstalledApps');
    if (!Array.isArray(list)) list = [];
    // เปิดบันทึกอยู่ขึ้นก่อน แล้วเรียงตามชื่อ
    list.sort(function (a, b) {
      if (a.enabled !== b.enabled) return a.enabled ? -1 : 1;
      return a.name.localeCompare(b.name, 'th');
    });
    state.apps = list;
    state.appMap = {};
    list.forEach(function (a) { state.appMap[a.packageName] = a; });
    state.appsLoaded = true;
  }

  function colorClass(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    return 'c' + (h % 6);
  }
  function avatar(pkg, name, cls) {
    var a = state.appMap[pkg];
    var c = cls ? ' ' + cls : '';
    if (a && typeof a.icon === 'string' && a.icon.indexOf('data:image/png;base64,') === 0) {
      return '<div class="avatar' + c + '"><img alt="" src="' + esc(a.icon) + '"></div>';
    }
    var letter = (name || pkg || '?').trim().charAt(0).toUpperCase();
    return '<div class="avatar ' + colorClass(pkg || name || '') + c + '">' + esc(letter) + '</div>';
  }

  function renderApps() {
    var q = $('#app-q').value.trim().toLowerCase();
    var html = '';
    var shown = 0;
    state.apps.forEach(function (a) {
      if (q && a.name.toLowerCase().indexOf(q) < 0 && a.packageName.toLowerCase().indexOf(q) < 0) return;
      shown++;
      html += '<div class="app">' + avatar(a.packageName, a.name) +
        '<div class="grow"><b>' + esc(a.name) + '</b><span class="sub">' + esc(a.packageName) + '</span></div>' +
        '<label class="switch"><input type="checkbox" data-pkg="' + esc(a.packageName) + '" aria-label="บันทึกการแจ้งเตือนของ ' + esc(a.name) + '"' + (a.enabled ? ' checked' : '') + '><span class="track"></span></label></div>';
    });
    $('#app-list').innerHTML = html;
    $('#app-empty').hidden = shown > 0;
    updateAppSummary();
  }
  function updateAppSummary() {
    var on = state.apps.filter(function (a) { return a.enabled; }).length;
    $('#app-summary').textContent = 'เปิดบันทึก ' + on + ' จาก ' + state.apps.length + ' แอป';
  }

  /* ---------- feeds (messages / group detail) ---------- */
  function msgHTML(m) {
    var title = m.title && m.title !== m.sender ? '<div class="conv">' + esc(m.title) + '</div>' : '';
    var who = m.sender || m.title || m.appName;
    var body = m.content || m.subText || '';
    return '<article class="msg" data-id="' + esc(m.id) + '">' + avatar(m.packageName, m.appName) +
      '<div class="body"><div class="top"><span class="who">' + esc(who) + '</span><time>' + esc(fmtTime(m.postTime)) + '</time></div>' +
      '<div class="app">' + esc(m.appName) + '</div>' + title +
      '<p class="text">' + esc(body) + '</p></div>' +
      '<button class="del" aria-label="ลบข้อความนี้">' + ic('trash') + '</button></article>';
  }

  function feedLoad(feed, mode) {
    var limit = PAGE, offset = 0, keep = [];
    if (mode === 'more') { offset = feed.items.length; keep = feed.items; }
    else if (mode === 'refresh') { limit = Math.max(PAGE, feed.items.length); }
    var r = bridge('getNotifications', feed.q, feed.pkg, limit, offset);
    if (!r || !Array.isArray(r.items)) r = { items: [], total: 0 };
    feed.items = keep.concat(r.items);
    feed.total = r.total || 0;
    feedRender(feed);
  }

  function feedRender(feed) {
    $(feed.list).innerHTML = feed.items.map(msgHTML).join('');
    var more = $(feed.more);
    var left = feed.total - feed.items.length;
    more.hidden = left <= 0;
    more.textContent = 'โหลดเพิ่ม (เหลือ ' + fmtNum(left) + ')';
    if (feed.empty) {
      var e = $(feed.empty);
      if (feed.items.length === 0) {
        var filtering = feed.q || feed.pkg;
        e.innerHTML = '<div class="empty-ic">' + ic(filtering ? 'search' : 'message') + '</div>' +
          '<h3>' + (filtering ? 'ไม่พบข้อความที่ตรงกัน' : 'ยังไม่มีข้อความ') + '</h3>' +
          '<p>' + (filtering ? 'ลองเปลี่ยนคำค้นหาหรือเลือกแอปอื่น' : 'ข้อความจากแอปที่เปิดบันทึกไว้จะแสดงที่นี่ทันทีที่มีการแจ้งเตือนเข้ามา') + '</p>';
        e.hidden = false;
      } else {
        e.hidden = true;
      }
    }
  }

  function deleteOne(feed, id) {
    if (bridge('deleteNotification', Number(id)) !== true) { toast('ลบไม่สำเร็จ'); return; }
    feed.items = feed.items.filter(function (m) { return String(m.id) !== String(id); });
    feed.total = Math.max(0, feed.total - 1);
    feedRender(feed);
    toast('ลบข้อความแล้ว');
    if (feed === grpFeed) updateGroupCount();
    if (state.tab === 'messages') loadChips();
  }

  function bindFeed(feed) {
    $(feed.list).addEventListener('click', function (e) {
      var card = e.target.closest('.msg');
      if (!card) return;
      if (e.target.closest('.del')) { deleteOne(feed, card.getAttribute('data-id')); return; }
      card.classList.toggle('open');
    });
    $(feed.more).addEventListener('click', function () { feedLoad(feed, 'more'); });
  }

  /* ---------- Home ---------- */
  function renderHome() {
    var banner = $('#home-banner');
    if (!state.access) {
      banner.innerHTML = '<div class="banner">' + ic('alert') +
        '<div class="grow"><b>ยังไม่ได้เปิดสิทธิ์</b><br>ข้อความใหม่จะไม่ถูกบันทึกจนกว่าจะเปิดสิทธิ์</div>' +
        '<button class="btn" id="banner-open">เปิดสิทธิ์</button></div>';
    } else {
      banner.innerHTML = '';
    }
    var s = bridge('getStats') || {};
    $('#st-total').textContent = fmtNum(s.total);
    $('#st-today').textContent = fmtNum(s.today);
    $('#st-apps').textContent = fmtNum(state.apps.filter(function (a) { return a.enabled; }).length);

    var r = bridge('getNotifications', '', '', 5, 0) || { items: [] };
    var items = Array.isArray(r.items) ? r.items : [];
    $('#home-list').innerHTML = items.map(msgHTML).join('');
    $('#home-empty').hidden = items.length > 0;
    $('#btn-all').hidden = items.length === 0;
  }

  /* ---------- Messages ---------- */
  function loadChips() {
    var groups = bridge('getGroups');
    if (!Array.isArray(groups)) groups = [];
    var html = '<button class="chip' + (msgFeed.pkg === '' ? ' on' : '') + '" data-pkg="">ทั้งหมด</button>';
    groups.forEach(function (g) {
      html += '<button class="chip' + (msgFeed.pkg === g.packageName ? ' on' : '') + '" data-pkg="' + esc(g.packageName) + '">' + esc(g.appName) + '</button>';
    });
    $('#msg-chips').innerHTML = html;
  }

  /* ---------- Groups ---------- */
  function renderGroups() {
    var groups = bridge('getGroups');
    if (!Array.isArray(groups)) groups = [];
    $('#groups-list').innerHTML = groups.map(function (g) {
      return '<button class="grp" data-pkg="' + esc(g.packageName) + '" data-name="' + esc(g.appName) + '">' +
        avatar(g.packageName, g.appName) +
        '<div class="grow"><b>' + esc(g.appName) + '</b><span class="sub">ล่าสุด ' + esc(fmtTime(g.lastTime)) + '</span></div>' +
        '<span class="badge">' + esc(fmtNum(g.count)) + '</span></button>';
    }).join('');
    $('#groups-empty').hidden = groups.length > 0;
  }

  function openGroup(pkg, name) {
    state.groupPkg = pkg;
    state.groupName = name;
    grpFeed.pkg = pkg;
    $('#groups-root').hidden = true;
    $('#group-detail').hidden = false;
    $('#gd-avatar').outerHTML = avatar(pkg, name, 'lg').replace('class="avatar', 'id="gd-avatar" class="avatar');
    $('#gd-name').textContent = name;
    feedLoad(grpFeed, 'reset');
    updateGroupCount();
    updateHeader();
    $('#view-groups').scrollTop = 0;
  }
  function updateGroupCount() { $('#gd-count').textContent = fmtNum(grpFeed.total) + ' ข้อความ'; }
  function closeGroup() {
    state.groupPkg = null;
    $('#group-detail').hidden = true;
    $('#groups-root').hidden = false;
    renderGroups();
    updateHeader();
  }

  /* ---------- Settings ---------- */
  function renderSettings() {
    state.access = bridge('hasNotificationAccess') === true;
    var pill = $('#set-access-pill');
    pill.textContent = state.access ? 'เปิดอยู่' : 'ปิดอยู่';
    pill.className = 'pill ' + (state.access ? 'ok' : 'no');
    $('#set-access-text').textContent = state.access ? 'NotiSave กำลังบันทึกการแจ้งเตือน' : 'ยังบันทึกการแจ้งเตือนไม่ได้';
    var st = bridge('getSettings') || {};
    $('#set-otp').checked = st.skipOtp !== false;
    $('#set-retention').value = String(st.retentionDays || 0);
    var s = bridge('getStats') || {};
    $('#set-stored').textContent = 'บันทึกไว้ ' + fmtNum(s.total) + ' ข้อความ ในเครื่องนี้เท่านั้น';
    var info = bridge('getAppInfo') || {};
    $('#set-version').textContent = info.version ? 'เวอร์ชัน ' + info.version : '';
  }

  /* ---------- tabs / navigation ---------- */
  function updateHeader() {
    var inGroup = state.tab === 'groups' && state.groupPkg;
    $('#page-title').textContent = inGroup ? state.groupName : TITLES[state.tab];
    $('#btn-back').hidden = !inGroup;
    $('.topbar').querySelector('h2').style.marginLeft = inGroup ? '0' : '';
  }

  function setTab(tab) {
    state.tab = tab;
    ['home', 'messages', 'groups', 'apps', 'settings'].forEach(function (t) {
      $('#view-' + t).hidden = (t !== tab);
    });
    $$('.nav-btn').forEach(function (b) {
      var on = b.getAttribute('data-tab') === tab;
      b.classList.toggle('on', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    updateHeader();
    refreshCurrent(true);
  }

  function refreshCurrent(entering) {
    switch (state.tab) {
      case 'home': renderHome(); break;
      case 'messages':
        loadChips();
        feedLoad(msgFeed, entering ? 'reset' : 'refresh');
        break;
      case 'groups':
        if (state.groupPkg) { feedLoad(grpFeed, entering ? 'refresh' : 'refresh'); updateGroupCount(); }
        else renderGroups();
        break;
      case 'apps': renderApps(); break;
      case 'settings': renderSettings(); break;
    }
  }

  // ปุ่มย้อนกลับของระบบ: คืน true ถ้าจัดการเองแล้ว
  window.handleBack = function () {
    if (!$('#modal').hidden) { $('#modal').hidden = true; return true; }
    if ($('#screen-main').hidden) return false;
    if (state.tab === 'groups' && state.groupPkg) { closeGroup(); return true; }
    if (state.tab !== 'home') { setTab('home'); return true; }
    return false;
  };

  // เรียกโดย MainActivity เมื่อกลับเข้ามาในแอป
  window.onAppResume = function () {
    var was = state.access;
    state.access = bridge('hasNotificationAccess') === true;
    if (!$('#screen-permission').hidden) {
      if (state.access) { toast('เปิดสิทธิ์เรียบร้อยแล้ว'); route(); }
      else if (state.asked) {
        $('#perm-denied').hidden = false;
        $('#btn-perm-skip').hidden = false;
      }
      return;
    }
    if (!$('#screen-main').hidden) {
      if (was && !state.access) { toast('สิทธิ์ถูกปิด ข้อความใหม่จะไม่ถูกบันทึก'); }
      refreshCurrent();
    }
  };

  // เรียกโดย MainActivity เมื่อ NotificationService บันทึกข้อความใหม่
  var newTimer;
  window.onNewNotification = function () {
    clearTimeout(newTimer);
    newTimer = setTimeout(function () { if (!$('#screen-main').hidden) refreshCurrent(); }, 350);
  };

  /* ---------- init ---------- */
  function init() {
    $$('[data-ic]').forEach(function (el) { el.innerHTML = ic(el.getAttribute('data-ic')); });

    if (!A) { show('screen-nobridge'); return; }

    // Welcome / Permission
    $('#btn-start').addEventListener('click', function () { bridge('setOnboarded'); route(); });
    $('#btn-open-settings').addEventListener('click', function () { state.asked = true; bridge('openNotificationSettings'); });
    $('#btn-appinfo').addEventListener('click', function () { bridge('openAppInfo'); });
    $('#btn-perm-skip').addEventListener('click', function () { state.skipPerm = true; route(); });

    // Nav
    $('.nav').addEventListener('click', function (e) {
      var b = e.target.closest('.nav-btn');
      if (!b) return;
      var t = b.getAttribute('data-tab');
      if (t === state.tab && !(t === 'groups' && state.groupPkg)) return;
      if (t === 'groups' && state.groupPkg) closeGroup();
      setTab(t);
    });
    $('#btn-back').addEventListener('click', function () { window.handleBack(); });
    $('#btn-all').addEventListener('click', function () { setTab('messages'); });
    $('#home-banner').addEventListener('click', function (e) {
      if (e.target.closest('#banner-open')) { state.skipPerm = false; state.asked = false; route(); }
    });
    $('#home-list').addEventListener('click', function (e) {
      var card = e.target.closest('.msg');
      if (!card) return;
      if (e.target.closest('.del')) {
        var id = card.getAttribute('data-id');
        if (bridge('deleteNotification', Number(id)) === true) { toast('ลบข้อความแล้ว'); renderHome(); }
        else toast('ลบไม่สำเร็จ');
        return;
      }
      card.classList.toggle('open');
    });

    // Messages
    bindFeed(msgFeed);
    var qTimer;
    $('#msg-q').addEventListener('input', function (e) {
      clearTimeout(qTimer);
      var v = e.target.value;
      qTimer = setTimeout(function () { msgFeed.q = v.trim(); feedLoad(msgFeed, 'reset'); }, 250);
    });
    $('#msg-chips').addEventListener('click', function (e) {
      var c = e.target.closest('.chip');
      if (!c) return;
      msgFeed.pkg = c.getAttribute('data-pkg') || '';
      loadChips();
      feedLoad(msgFeed, 'reset');
    });

    // Groups
    bindFeed(grpFeed);
    $('#groups-list').addEventListener('click', function (e) {
      var g = e.target.closest('.grp');
      if (g) openGroup(g.getAttribute('data-pkg'), g.getAttribute('data-name'));
    });
    $('#gd-delete').addEventListener('click', function () {
      var pkg = state.groupPkg, name = state.groupName;
      confirmDialog('ลบประวัติของ ' + name + '?', 'ข้อความทั้งหมดจากแอปนี้ในเครื่องจะถูกลบ และกู้คืนไม่ได้', 'ลบกลุ่มนี้', function () {
        var n = bridge('deleteByPackage', pkg) || 0;
        toast('ลบแล้ว ' + fmtNum(n) + ' ข้อความ');
        if (msgFeed.pkg === pkg) msgFeed.pkg = '';
        closeGroup();
      });
    });

    // Apps
    $('#app-q').addEventListener('input', renderApps);
    $('#app-list').addEventListener('change', function (e) {
      var input = e.target;
      if (!input || input.type !== 'checkbox') return;
      var pkg = input.getAttribute('data-pkg');
      var on = input.checked;
      if (bridge('saveAppSettings', pkg, on) === true) {
        if (state.appMap[pkg]) state.appMap[pkg].enabled = on;
        updateAppSummary();
      } else {
        input.checked = !on;
        toast('บันทึกการตั้งค่าไม่สำเร็จ');
      }
    });

    // Settings
    $('#set-open').addEventListener('click', function () { state.asked = true; bridge('openNotificationSettings'); });
    $('#set-battery').addEventListener('click', function () { bridge('openBatterySettings'); });
    $('#set-otp').addEventListener('change', function (e) { bridge('setSkipOtp', e.target.checked); });
    $('#set-retention').addEventListener('change', function (e) {
      var d = parseInt(e.target.value, 10) || 0;
      bridge('setRetentionDays', d);
      toast(d ? 'จะลบประวัติที่เก่ากว่า ' + (d === 365 ? '1 ปี' : d + ' วัน') : 'ปิดการลบอัตโนมัติแล้ว');
      setTimeout(renderSettings, 400);
    });
    $('#set-clear').addEventListener('click', function () {
      confirmDialog('ล้างประวัติทั้งหมด?', 'ข้อความที่บันทึกไว้ทั้งหมดจะถูกลบจากเครื่องและกู้คืนไม่ได้', 'ล้างทั้งหมด', function () {
        var n = bridge('clearNotifications') || 0;
        msgFeed.items = []; grpFeed.items = [];
        toast('ล้างแล้ว ' + fmtNum(n) + ' ข้อความ');
        renderSettings();
      });
    });

    // เริ่มต้น
    if (bridge('isOnboarded') === true) route(); else show('screen-welcome');
  }

  document.addEventListener('DOMContentLoaded', init);
})();
