package com.notisave.app;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {NotificationEntity.class}, version = 1, exportSchema = false)
public abstract class NotificationDatabase extends RoomDatabase {

    public abstract NotificationDao dao();

    private static volatile NotificationDatabase instance;

    public static NotificationDatabase get(Context context) {
        if (instance == null) {
            synchronized (NotificationDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(
                            context.getApplicationContext(),
                            NotificationDatabase.class,
                            "notisave.db").build();
                }
            }
        }
        return instance;
    }
}
