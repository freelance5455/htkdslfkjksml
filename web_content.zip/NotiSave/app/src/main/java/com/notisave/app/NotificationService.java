package com.notisave.app;

import android.app.Notification;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.Person;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * ดักจับการแจ้งเตือนผ่าน NotificationListenerService
 * อ่านเฉพาะข้อมูลที่ Android เปิดเผยใน Notification (title/text/bigText/MessagingStyle)
 * ไม่เข้าถึงฐานข้อมูลของแอปอื่น และไม่มีสิทธิ์ INTERNET จึงส่งข้อมูลออกนอกเครื่องไม่ได้
 */
public class NotificationService extends NotificationListenerService {

    private static final String TAG = "NotiSave";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final int MAX_TEXT = 8000;
    private static final int MAX_MESSAGES_PER_POST = 20;

    // ข้อความที่น่าจะเป็นรหัส OTP/ยืนยันตัวตน: มีคำเตือน + ตัวเลข 4-8 หลัก
    private static final Pattern OTP_NUM = Pattern.compile("(?<![0-9])[0-9]{4,8}(?![0-9])");
    private static final Pattern OTP_WORD = Pattern.compile(
            "(otp|one[- ]?time|verification|verify|passcode|security code|2fa|\\bpin\\b|รหัส|ยืนยัน)",
            Pattern.CASE_INSENSITIVE);

    private static volatile Runnable changeListener;

    public static void setChangeListener(Runnable r) { changeListener = r; }

    private final Map<String, String> labelCache = new HashMap<>();

    @Override
    public void onListenerConnected() {
        IO.execute(() -> {
            try { pruneIfDue(NotificationDatabase.get(this).dao()); } catch (Throwable t) { Log.w(TAG, t); }
        });
    }

    @Override
    public void onListenerDisconnected() {
        // ให้ระบบเชื่อมต่อ service ใหม่เองเมื่อหลุด
        try {
            requestRebind(new ComponentName(this, NotificationService.class));
        } catch (Throwable t) {
            Log.w(TAG, "rebind failed", t);
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        IO.execute(() -> {
            try {
                process(sbn);
            } catch (Throwable t) {
                // ไม่ให้ service ล้มเพราะการแจ้งเตือนรูปแบบแปลก ๆ
                Log.w(TAG, "process failed", t);
            }
        });
    }

    private void process(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        if (pkg == null || pkg.equals(getPackageName())) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;

        int skipFlags = Notification.FLAG_GROUP_SUMMARY
                | Notification.FLAG_ONGOING_EVENT
                | Notification.FLAG_FOREGROUND_SERVICE;
        if ((n.flags & skipFlags) != 0) return;

        String cat = n.category;
        if (Notification.CATEGORY_TRANSPORT.equals(cat) || Notification.CATEGORY_PROGRESS.equals(cat)
                || Notification.CATEGORY_SERVICE.equals(cat) || Notification.CATEGORY_STATUS.equals(cat)
                || Notification.CATEGORY_SYSTEM.equals(cat)) return;

        if (!AppPrefs.isEnabled(this, pkg)) return;

        Bundle ex = n.extras;
        String appName = labelFor(pkg);
        boolean skipOtp = AppPrefs.skipOtp(this);
        NotificationDao dao = NotificationDatabase.get(this).dao();
        long now = System.currentTimeMillis();

        String title = str(ex.getCharSequence(Notification.EXTRA_TITLE));
        if (title.isEmpty()) title = str(ex.getCharSequence(Notification.EXTRA_TITLE_BIG));
        String sub = str(ex.getCharSequence(Notification.EXTRA_SUB_TEXT));

        List<NotificationEntity> toSave = new ArrayList<>();

        NotificationCompat.MessagingStyle ms = null;
        try {
            ms = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n);
        } catch (Throwable ignored) { }

        if (ms != null && !ms.getMessages().isEmpty()) {
            // รูปแบบ MessagingStyle: แยกทีละข้อความ พร้อมชื่อผู้ส่งและเวลาจริงของข้อความ
            String conv = str(ms.getConversationTitle());
            if (conv.isEmpty()) conv = title;
            List<NotificationCompat.MessagingStyle.Message> msgs = ms.getMessages();
            int start = Math.max(0, msgs.size() - MAX_MESSAGES_PER_POST);
            for (int i = start; i < msgs.size(); i++) {
                NotificationCompat.MessagingStyle.Message m = msgs.get(i);
                String text = str(m.getText());
                if (text.isEmpty()) continue;
                Person p = m.getPerson();
                String sender = p != null ? str(p.getName()) : "";
                if (sender.isEmpty()) sender = !title.isEmpty() ? title : conv;
                long ts = m.getTimestamp() > 0 ? m.getTimestamp() : sbn.getPostTime();
                if (skipOtp && looksSensitive(conv + " " + text)) continue;
                String key = sha(pkg + "|m|" + sender + "|" + text + "|" + ts);
                if (dao.countKey(key) > 0) continue;
                toSave.add(build(sbn, appName, sender, conv, text, sub, ts, key));
            }
        } else {
            // BigTextStyle / InboxStyle / ข้อความธรรมดา
            String text = str(ex.getCharSequence(Notification.EXTRA_BIG_TEXT));
            if (text.isEmpty()) {
                CharSequence[] lines = ex.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
                if (lines != null && lines.length > 0) {
                    StringBuilder sb = new StringBuilder();
                    for (CharSequence l : lines) {
                        if (l == null) continue;
                        if (sb.length() > 0) sb.append('\n');
                        sb.append(l);
                    }
                    text = sb.toString().trim();
                }
            }
            if (text.isEmpty()) text = str(ex.getCharSequence(Notification.EXTRA_TEXT));
            if (title.isEmpty() && text.isEmpty()) return;
            if (skipOtp && looksSensitive(title + " " + text + " " + sub)) return;

            String key = sha(pkg + "|n|" + sbn.getId() + "|" + title + "|" + text + "|" + sub);
            // อัปเดตซ้ำของ notification เดิมภายใน 15 วินาที ไม่นับเป็นข้อความใหม่
            if (dao.countKeySince(key, now - 15_000L) > 0) return;
            toSave.add(build(sbn, appName, title, title, text, sub, sbn.getPostTime(), key));
        }

        if (toSave.isEmpty()) return;
        for (NotificationEntity e : toSave) dao.insert(e);
        pruneIfDue(dao);

        Runnable l = changeListener;
        if (l != null) l.run();
    }

    private NotificationEntity build(StatusBarNotification sbn, String appName, String sender,
                                     String title, String text, String sub, long ts, String key) {
        NotificationEntity e = new NotificationEntity();
        e.appName = appName;
        e.packageName = sbn.getPackageName();
        e.sender = cut(sender, 300);
        e.title = cut(title, 300);
        e.content = cut(text, MAX_TEXT);
        e.subText = cut(sub, 300);
        e.postTime = ts;
        e.notificationId = sbn.getId();
        e.notificationKey = cut(sbn.getKey() == null ? "" : sbn.getKey(), 500);
        e.dedupeKey = key;
        return e;
    }

    private void pruneIfDue(NotificationDao dao) {
        int days = AppPrefs.retentionDays(this);
        if (days <= 0) return;
        long now = System.currentTimeMillis();
        if (now - AppPrefs.lastPrune(this) < 6L * 3600_000L) return;
        dao.deleteOlderThan(now - days * 86_400_000L);
        AppPrefs.setLastPrune(this, now);
    }

    private static boolean looksSensitive(String s) {
        return OTP_WORD.matcher(s).find() && OTP_NUM.matcher(s).find();
    }

    private String labelFor(String pkg) {
        String cached = labelCache.get(pkg);
        if (cached != null) return cached;
        String label = pkg;
        try {
            PackageManager pm = getPackageManager();
            label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Throwable ignored) { }
        labelCache.put(pkg, label);
        return label;
    }

    private static String str(CharSequence cs) { return cs == null ? "" : cs.toString().trim(); }

    private static String cut(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max) : s;
    }

    private static String sha(String in) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-1").digest(in.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(in.hashCode());
        }
    }
}
