package com.notisave.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Base64;

import android.webkit.JavascriptInterface;

import androidx.core.app.NotificationManagerCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * สะพานเชื่อม HTML ↔ Android (window.Android)
 * ทุกฟังก์ชันที่ส่งข้อมูลกลับเป็น JSON string ที่สร้างด้วย org.json (escape ให้ถูกต้อง)
 * ฝั่ง JS ต้องแสดงผลด้วยการ escape HTML เสมอ
 */
public class AppBridge {

    private static final Pattern PKG = Pattern.compile("[A-Za-z0-9_.]{1,200}");
    private static final Map<String, String> ICON_CACHE = new ConcurrentHashMap<>();

    private final Activity activity;

    AppBridge(Activity activity) { this.activity = activity; }

    private Context ctx() { return activity.getApplicationContext(); }
    private NotificationDao dao() { return NotificationDatabase.get(ctx()).dao(); }

    // ---------- สิทธิ์ / หน้าตั้งค่าระบบ ----------

    @JavascriptInterface
    public boolean hasNotificationAccess() {
        return NotificationManagerCompat.getEnabledListenerPackages(ctx()).contains(ctx().getPackageName());
    }

    @JavascriptInterface
    public void openNotificationSettings() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 30) {
            i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS);
            i.putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                    new ComponentName(ctx(), NotificationService.class).flattenToString());
        } else {
            i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        }
        if (!launch(i)) {
            if (!launch(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))) openAppInfo();
        }
    }

    /** Android 13+: แอปที่ติดตั้งนอก Play Store ต้องกด "อนุญาตการตั้งค่าที่ถูกจำกัด" ที่หน้านี้ก่อน */
    @JavascriptInterface
    public void openAppInfo() {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + ctx().getPackageName()));
        launch(i);
    }

    @JavascriptInterface
    public void openBatterySettings() {
        if (!launch(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) openAppInfo();
    }

    private boolean launch(Intent i) {
        try {
            activity.startActivity(i);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------- ข้อมูลทั่วไป / onboarding ----------

    @JavascriptInterface
    public boolean isOnboarded() { return AppPrefs.isOnboarded(ctx()); }

    @JavascriptInterface
    public void setOnboarded() { AppPrefs.setOnboarded(ctx()); }

    @JavascriptInterface
    public String getAppInfo() {
        JSONObject o = new JSONObject();
        try {
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("version", ctx().getPackageManager().getPackageInfo(ctx().getPackageName(), 0).versionName);
        } catch (Exception ignored) { }
        return o.toString();
    }

    // ---------- Application Manager ----------

    @SuppressWarnings("deprecation")
    @JavascriptInterface
    public String getInstalledApps() {
        JSONArray arr = new JSONArray();
        try {
            PackageManager pm = ctx().getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN, null);
            q.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(q, 0);

            List<String[]> apps = new ArrayList<>();
            Map<String, ResolveInfo> info = new ConcurrentHashMap<>();
            Set<String> seen = new HashSet<>();
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(ctx().getPackageName()) || !seen.add(pkg)) continue;
                String name = String.valueOf(ri.loadLabel(pm));
                apps.add(new String[]{pkg, name});
                info.put(pkg, ri);
            }
            Collections.sort(apps, (a, b) -> a[1].compareToIgnoreCase(b[1]));

            for (String[] a : apps) {
                JSONObject o = new JSONObject();
                o.put("packageName", a[0]);
                o.put("name", a[1]);
                o.put("enabled", AppPrefs.isEnabled(ctx(), a[0]));
                String icon = ICON_CACHE.get(a[0]);
                if (icon == null) {
                    try {
                        icon = toDataUri(info.get(a[0]).loadIcon(pm));
                        ICON_CACHE.put(a[0], icon);
                    } catch (Throwable t) {
                        icon = "";
                    }
                }
                o.put("icon", icon);
                arr.put(o);
            }
        } catch (Throwable ignored) { }
        return arr.toString();
    }

    private static String toDataUri(Drawable d) {
        int size = 72;
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        d.setBounds(0, 0, size, size);
        d.draw(c);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        bmp.recycle();
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    @JavascriptInterface
    public boolean saveAppSettings(String packageName, boolean enabled) {
        if (packageName == null || !PKG.matcher(packageName).matches()) return false;
        AppPrefs.setEnabled(ctx(), packageName, enabled);
        return true;
    }

    // ---------- Messages / Groups ----------

    @JavascriptInterface
    public String getNotifications(String query, String packageName, int limit, int offset) {
        JSONObject res = new JSONObject();
        JSONArray items = new JSONArray();
        try {
            String q = escapeLike(query == null ? "" : query.trim());
            String pkg = packageName == null ? "" : packageName;
            int lim = Math.max(1, Math.min(limit, 200));
            int off = Math.max(0, offset);
            for (NotificationEntity e : dao().search(q, pkg, lim, off)) items.put(toJson(e));
            res.put("items", items);
            res.put("total", dao().searchCount(q, pkg));
        } catch (Throwable t) {
            try { res.put("items", items); res.put("total", 0); } catch (JSONException ignored) { }
        }
        return res.toString();
    }

    @JavascriptInterface
    public String getGroups() {
        JSONArray arr = new JSONArray();
        try {
            for (GroupRow g : dao().groups()) {
                JSONObject o = new JSONObject();
                o.put("packageName", g.packageName);
                o.put("appName", g.appName);
                o.put("count", g.cnt);
                o.put("lastTime", g.lastTime);
                arr.put(o);
            }
        } catch (Throwable ignored) { }
        return arr.toString();
    }

    @JavascriptInterface
    public String getStats() {
        JSONObject o = new JSONObject();
        try {
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            o.put("total", dao().total());
            o.put("today", dao().countSince(c.getTimeInMillis()));
        } catch (Throwable ignored) { }
        return o.toString();
    }

    // ---------- ลบข้อมูล ----------

    @JavascriptInterface
    public boolean deleteNotification(long id) {
        try { return dao().deleteById(id) > 0; } catch (Throwable t) { return false; }
    }

    @JavascriptInterface
    public int deleteByPackage(String packageName) {
        if (packageName == null || !PKG.matcher(packageName).matches()) return 0;
        try { return dao().deleteByPackage(packageName); } catch (Throwable t) { return 0; }
    }

    @JavascriptInterface
    public int clearNotifications() {
        try { return dao().deleteAll(); } catch (Throwable t) { return 0; }
    }

    // ---------- ตั้งค่า ----------

    @JavascriptInterface
    public String getSettings() {
        JSONObject o = new JSONObject();
        try {
            o.put("skipOtp", AppPrefs.skipOtp(ctx()));
            o.put("retentionDays", AppPrefs.retentionDays(ctx()));
        } catch (JSONException ignored) { }
        return o.toString();
    }

    @JavascriptInterface
    public void setSkipOtp(boolean on) { AppPrefs.setSkipOtp(ctx(), on); }

    @JavascriptInterface
    public void setRetentionDays(int days) {
        if (days < 0 || days > 3650) return;
        AppPrefs.setRetentionDays(ctx(), days);
        if (days > 0) {
            new Thread(() -> {
                try {
                    dao().deleteOlderThan(System.currentTimeMillis() - days * 86_400_000L);
                    AppPrefs.setLastPrune(ctx(), System.currentTimeMillis());
                } catch (Throwable ignored) { }
            }).start();
        }
    }

    // ---------- helpers ----------

    private static String escapeLike(String s) {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }

    private static JSONObject toJson(NotificationEntity e) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", e.id);
        o.put("appName", e.appName);
        o.put("packageName", e.packageName);
        o.put("sender", e.sender);
        o.put("title", e.title);
        o.put("content", e.content);
        o.put("subText", e.subText);
        o.put("postTime", e.postTime);
        o.put("notificationId", e.notificationId);
        return o;
    }
}
