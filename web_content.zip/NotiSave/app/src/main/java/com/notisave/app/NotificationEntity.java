package com.notisave.app;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "notifications",
        indices = {@Index("postTime"), @Index("packageName"), @Index("dedupeKey")}
)
public class NotificationEntity {
    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull public String appName = "";
    @NonNull public String packageName = "";
    /** ชื่อผู้ส่ง (สำหรับแชต) หรือหัวข้อ (สำหรับการแจ้งเตือนทั่วไป) */
    @NonNull public String sender = "";
    /** หัวข้อการแจ้งเตือน หรือชื่อห้องแชต/กลุ่ม */
    @NonNull public String title = "";
    @NonNull public String content = "";
    @NonNull public String subText = "";
    public long postTime;
    public int notificationId;
    @NonNull public String notificationKey = "";
    /** แฮชไว้กันบันทึกซ้ำ */
    @NonNull public String dedupeKey = "";
}
