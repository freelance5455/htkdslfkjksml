package com.notisave.app;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface NotificationDao {

    @Insert
    long insert(NotificationEntity e);

    @Query("SELECT COUNT(*) FROM notifications WHERE dedupeKey = :key")
    int countKey(String key);

    @Query("SELECT COUNT(*) FROM notifications WHERE dedupeKey = :key AND postTime >= :since")
    int countKeySince(String key, long since);

    // :q ต้อง escape อักขระ % _ \ มาก่อน (ทำใน AppBridge)
    @Query("SELECT * FROM notifications "
            + "WHERE (:pkg = '' OR packageName = :pkg) "
            + "AND (:q = '' OR title LIKE '%' || :q || '%' ESCAPE '\\' "
            + "OR sender LIKE '%' || :q || '%' ESCAPE '\\' "
            + "OR content LIKE '%' || :q || '%' ESCAPE '\\' "
            + "OR appName LIKE '%' || :q || '%' ESCAPE '\\') "
            + "ORDER BY postTime DESC, id DESC LIMIT :limit OFFSET :offset")
    List<NotificationEntity> search(String q, String pkg, int limit, int offset);

    @Query("SELECT COUNT(*) FROM notifications "
            + "WHERE (:pkg = '' OR packageName = :pkg) "
            + "AND (:q = '' OR title LIKE '%' || :q || '%' ESCAPE '\\' "
            + "OR sender LIKE '%' || :q || '%' ESCAPE '\\' "
            + "OR content LIKE '%' || :q || '%' ESCAPE '\\' "
            + "OR appName LIKE '%' || :q || '%' ESCAPE '\\')")
    int searchCount(String q, String pkg);

    @Query("SELECT packageName AS packageName, MAX(appName) AS appName, COUNT(*) AS cnt, "
            + "MAX(postTime) AS lastTime FROM notifications "
            + "GROUP BY packageName ORDER BY lastTime DESC")
    List<GroupRow> groups();

    @Query("SELECT COUNT(*) FROM notifications")
    int total();

    @Query("SELECT COUNT(*) FROM notifications WHERE postTime >= :since")
    int countSince(long since);

    @Query("DELETE FROM notifications WHERE id = :id")
    int deleteById(long id);

    @Query("DELETE FROM notifications WHERE packageName = :pkg")
    int deleteByPackage(String pkg);

    @Query("DELETE FROM notifications")
    int deleteAll();

    @Query("DELETE FROM notifications WHERE postTime < :before")
    int deleteOlderThan(long before);
}
