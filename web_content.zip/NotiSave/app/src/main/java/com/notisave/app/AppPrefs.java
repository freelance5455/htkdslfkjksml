package com.notisave.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** SharedPreferences: การตั้งค่ารายแอปและการตั้งค่าทั่วไป */
public final class AppPrefs {
    private static final String FILE = "notisave_prefs";

    /** แอปแชต/อีเมลหลักที่เปิดบันทึกให้เป็นค่าเริ่มต้น (ผู้ใช้ปิดได้ในหน้า Apps) */
    public static final Set<String> DEFAULT_ON = new HashSet<>(Arrays.asList(
            "jp.naver.line.android",
            "com.facebook.orca",
            "org.telegram.messenger",
            "org.telegram.messenger.web",
            "com.whatsapp",
            "com.whatsapp.w4b",
            "com.instagram.android",
            "com.google.android.apps.messaging",
            "com.android.messaging",
            "com.android.mms",
            "com.samsung.android.messaging",
            "com.google.android.gm"
    ));

    private AppPrefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static boolean isEnabled(Context c, String pkg) {
        SharedPreferences s = sp(c);
        String k = "app_" + pkg;
        return s.contains(k) ? s.getBoolean(k, false) : DEFAULT_ON.contains(pkg);
    }

    public static void setEnabled(Context c, String pkg, boolean on) {
        sp(c).edit().putBoolean("app_" + pkg, on).apply();
    }

    public static boolean isOnboarded(Context c) { return sp(c).getBoolean("onboarded", false); }
    public static void setOnboarded(Context c) { sp(c).edit().putBoolean("onboarded", true).apply(); }

    public static boolean skipOtp(Context c) { return sp(c).getBoolean("skip_otp", true); }
    public static void setSkipOtp(Context c, boolean v) { sp(c).edit().putBoolean("skip_otp", v).apply(); }

    public static int retentionDays(Context c) { return sp(c).getInt("retention_days", 0); }
    public static void setRetentionDays(Context c, int d) { sp(c).edit().putInt("retention_days", d).apply(); }

    public static long lastPrune(Context c) { return sp(c).getLong("last_prune", 0L); }
    public static void setLastPrune(Context c, long t) { sp(c).edit().putLong("last_prune", t).apply(); }
}
