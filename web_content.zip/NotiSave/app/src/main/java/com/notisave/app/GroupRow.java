package com.notisave.app;

/** ผลลัพธ์การจัดกลุ่มตามแอปต้นทาง */
public class GroupRow {
    public String packageName;
    public String appName;
    public int cnt;
    public long lastTime;
}
