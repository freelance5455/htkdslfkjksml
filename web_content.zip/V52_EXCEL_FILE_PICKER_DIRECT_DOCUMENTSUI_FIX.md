# V52 — Excel File Picker / Download Android Fix

Built from V51.

- Removes `Intent.createChooser()` from the Android Excel picker path.
- Removes `EXTRA_MIME_TYPES`, which can prevent DocumentsUI from opening on some Android 14/TECNO builds.
- Uses `ACTION_OPEN_DOCUMENT` directly with a broad MIME type, then `ACTION_GET_CONTENT` as fallback.
- Keeps WebChromeClient file-input fallback.
- Keeps Android template download and system save fallback.
- Android versionCode 24 / versionName 2.20.
