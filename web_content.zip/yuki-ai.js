window.YukiAI = {
  async request(endpoint, data) {
    const config = window.YukiConfig || {};
    const base = String(config.apiBase || '').replace(/\/+$/, '');

    if (!base) {
      throw new Error(
        'Сервер Юки пока не подключён. Настрой подключение к ИИ.'
      );
    }

    const response = await fetch(
      base + '/.netlify/functions/' + endpoint,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data),
        signal: AbortSignal.timeout(30000)
      }
    );

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error || 'Ошибка сервера Юки');
    }

    return result;
  }
};
