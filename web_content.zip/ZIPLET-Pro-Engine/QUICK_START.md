# ZIPLET Pro Engine — Quick Start

## Open the Android project
1. Install Android Studio on a computer.
2. Extract this ZIP file.
3. In Android Studio choose **Open** and select the `ZIPLET-Pro-Engine` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync to finish, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK can be found under `app/build/outputs/apk/debug/` if the build succeeds.

## Important
- This ZIP is Android source code, not a prebuilt APK.
- Android Studio needs internet access for the initial Gradle sync and dependency downloads.
- The ZIP-to-APK feature also needs the separate Python Build Agent and a compatible JDK, Gradle, and Android SDK. Read `README.md` for setup.
- The included Python smoke tests passed in this environment, but Android compilation and APK installation have not been verified here.
- Only build Android projects you trust: Gradle build scripts can execute code.
