"""Fast smoke tests for ZIPLET Build Agent safety and Web project generation."""
import importlib.util, tempfile, zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('ziplet_agent', HERE/'ziplet_build_agent.py')
agent=importlib.util.module_from_spec(spec); spec.loader.exec_module(agent)
with tempfile.TemporaryDirectory() as temp:
    temp=Path(temp); z=temp/'site.zip'
    with zipfile.ZipFile(z,'w') as f:
        f.writestr('index.html','<h1>Offline</h1>')
        f.writestr('assets/style.css','body{}')
    extracted=temp/'extract'; extracted.mkdir(); agent.safe_extract(z,extracted)
    project=temp/'project'; agent.web_zip_to_android_project(extracted,project,'Smoke Test','com.example.smoketest')
    assert (project/'settings.gradle').is_file()
    assert (project/'app/src/main/AndroidManifest.xml').is_file()
    assert (project/'app/src/main/assets/site/index.html').is_file()
    assert (project/'app/src/main/java/com/example/smoketest/MainActivity.java').is_file()
    bad=temp/'bad.zip'
    with zipfile.ZipFile(bad,'w') as f: f.writestr('../escape.txt','nope')
    try: agent.safe_extract(bad,temp/'bad-out')
    except agent.BuildError: pass
    else: raise AssertionError('path traversal test failed')
print('PASS: website project generation and path traversal rejection')
