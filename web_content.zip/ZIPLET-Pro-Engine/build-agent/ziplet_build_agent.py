#!/usr/bin/env python3
"""ZIPLET Build Agent: local/companion Gradle build worker.

Binds to loopback by default. LAN exposure requires HTTPS certificate/key and a strong token.
Build scripts in Android projects are executable code; run this only for projects you trust.
"""
from __future__ import annotations
import argparse, hashlib, hmac, http.server, json, os, re, shutil, ssl, subprocess, tempfile, threading, time, zipfile
from pathlib import Path, PurePosixPath

MAX_ZIP = 120 * 1024 * 1024
MAX_UNPACKED = 500 * 1024 * 1024
MAX_FILES = 30000
MAX_SECONDS = 900

class BuildError(Exception): pass

def safe_extract(zip_path: Path, dest: Path):
    total = 0; count = 0; seen = set()
    try:
        with zipfile.ZipFile(zip_path) as zf:
            for info in zf.infolist():
                name = info.filename.replace('\\', '/')
                p = PurePosixPath(name)
                if p.is_absolute() or any(part in ('..', '') for part in p.parts):
                    raise BuildError(f'Unsafe archive path: {name[:160]}')
                if ':' in name or name.startswith('/'):
                    raise BuildError(f'Unsafe archive path: {name[:160]}')
                key = name.casefold()
                if key in seen: raise BuildError(f'Duplicate archive path: {name[:160]}')
                seen.add(key); count += 1
                if count > MAX_FILES: raise BuildError('ZIP contains too many entries.')
                if info.is_dir():
                    (dest / Path(*p.parts)).mkdir(parents=True, exist_ok=True); continue
                total += info.file_size
                if total > MAX_UNPACKED: raise BuildError('Expanded ZIP exceeds 500 MB.')
                if info.file_size and info.compress_size == 0: raise BuildError('Suspicious compressed entry.')
                if info.compress_size and info.file_size / info.compress_size > 2000:
                    raise BuildError('Suspicious compression ratio.')
                out = dest.joinpath(*p.parts)
                out.parent.mkdir(parents=True, exist_ok=True)
                # Resolve containment before writing.
                if dest.resolve() not in out.resolve().parents:
                    raise BuildError('Archive path escaped workspace.')
                with zf.open(info) as src, open(out, 'wb') as dst:
                    shutil.copyfileobj(src, dst, 1024 * 1024)
    except zipfile.BadZipFile as e: raise BuildError('Invalid ZIP archive.') from e

def write(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True); path.write_text(text, encoding='utf-8')

def web_zip_to_android_project(source: Path, project: Path, app_name: str, package_id: str):
    site = project / 'app/src/main/assets/site'; site.mkdir(parents=True)
    files = [p for p in source.rglob('*') if p.is_file()]
    index = next((p for p in files if p.name.lower() in ('index.html','index.htm')), None)
    if not index: raise BuildError('Web ZIP must contain index.html or index.htm.')
    for src in files:
        rel = src.relative_to(source)
        out = site / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, out)
    rel_index = index.relative_to(source).as_posix()
    # Escape Android XML label.
    label = app_name.replace('&','&amp;').replace('<','&lt;').replace('"','&quot;')[:60] or 'Offline App'
    write(project/'settings.gradle', "pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name = 'ZipletGenerated'\ninclude ':app'\n")
    write(project/'build.gradle', "plugins { id 'com.android.application' version '8.7.3' apply false }\n")
    write(project/'gradle.properties', 'org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\n')
    write(project/'app/build.gradle', f"""plugins {{ id 'com.android.application' }}
android {{
 namespace '{package_id}'
 compileSdk 35
 defaultConfig {{ applicationId '{package_id}'; minSdk 23; targetSdk 35; versionCode 1; versionName '1.0' }}
 buildTypes {{ release {{ minifyEnabled false }} }}
}}
""")
    write(project/'app/src/main/AndroidManifest.xml', f'''<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="{label}" android:theme="@android:style/Theme.Material.Light.NoActionBar"><activity android:name=".{"MainActivity"}" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>''')
    java_path = Path('app/src/main/java') / Path(*package_id.split('.')) / 'MainActivity.java'
    write(project/java_path, f'''package {package_id};
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebViewClient; import android.webkit.WebSettings;
public class MainActivity extends Activity {{ @Override public void onCreate(Bundle b) {{ super.onCreate(b); WebView w = new WebView(this); w.setWebViewClient(new WebViewClient()); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(false); setContentView(w); w.loadUrl("file:///android_asset/site/{rel_index}"); }} }}
''')
    write(project/'.gitignore', 'local.properties\n*.jks\n*.keystore\nsigning.properties\n.gradle/\nbuild/\napp/build/\n')

def find_project(root: Path) -> Path:
    settings = next((p for p in root.rglob('*') if p.is_file() and p.name in ('settings.gradle', 'settings.gradle.kts')), None)
    if settings is None:
        raise BuildError('No Android Gradle project found (settings.gradle[.kts] missing).')
    project = settings.parent
    if not ((project/'app/src/main/AndroidManifest.xml').is_file() or (project/'app/build.gradle').is_file() or (project/'app/build.gradle.kts').is_file()):
        raise BuildError('Found Gradle settings but no recognizable Android app module at app/.')
    return project

def run_build(project: Path, gradle: str, mode: str):
    if mode not in ('debug','release'): raise BuildError('Unsupported build mode.')
    task = 'assembleDebug' if mode == 'debug' else 'assembleRelease'
    # Never use a shell. Note: Gradle project build scripts still execute code; build only trusted projects.
    cmd = [gradle, '--no-daemon', '--offline', '--stacktrace', task]
    try:
        p = subprocess.run(cmd, cwd=project, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                           timeout=MAX_SECONDS, env={**os.environ, 'CI':'1'})
    except FileNotFoundError as e: raise BuildError(f'Gradle executable not found: {gradle}') from e
    except subprocess.TimeoutExpired as e: raise BuildError(f'Build timed out after {MAX_SECONDS}s.') from e
    log = p.stdout[-60000:]
    if p.returncode != 0: raise BuildError('Gradle build failed. Tail of build log:\n' + log[-12000:])
    outdir = project/'app/build/outputs/apk'/mode
    apks = sorted(outdir.glob('*.apk'), key=lambda p:p.stat().st_mtime, reverse=True) if outdir.exists() else []
    if not apks: raise BuildError('Gradle reported success but no APK was found. Build log:\n'+log[-6000:])
    apk = apks[0]
    if apk.stat().st_size < 1024: raise BuildError('Output APK is unexpectedly small.')
    return apk, log

class Handler(http.server.BaseHTTPRequestHandler):
    server_version = 'ZIPLET-Build-Agent/1.0'
    def log_message(self, fmt, *args): print('[%s] %s' % (self.log_date_time_string(), fmt % args))
    def send_json(self, status, data):
        b=json.dumps(data).encode(); self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path != '/health': return self.send_json(404, {'ok':False,'error':'not found'})
        self.send_json(200, {'ok':True,'agent':'ZIPLET Build Agent','offline_builds':True,'gradle':self.server.gradle,'time':int(time.time())})
    def do_POST(self):
        if self.path != '/build': return self.send_json(404, {'ok':False,'error':'not found'})
        token=self.headers.get('X-Ziplet-Token','')
        if not token or not hmac.compare_digest(token, self.server.token):
            return self.send_json(401, {'ok':False,'error':'invalid token'})
        try: length=int(self.headers.get('Content-Length','0'))
        except ValueError: return self.send_json(400, {'ok':False,'error':'invalid content length'})
        if length < 1 or length > MAX_ZIP: return self.send_json(413, {'ok':False,'error':'ZIP must be between 1 byte and 120 MB'})
        mode=self.headers.get('X-Ziplet-Mode','auto').lower()
        app_name=self.headers.get('X-Ziplet-App-Name','Offline App')[:60]
        package_id=self.headers.get('X-Ziplet-Package-Id','com.ziplet.generated').lower()
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+', package_id):
            return self.send_json(400, {'ok':False,'error':'invalid package id'})
        if mode not in ('auto','web','android'): return self.send_json(400, {'ok':False,'error':'mode must be auto, web, or android'})
        with tempfile.TemporaryDirectory(prefix='ziplet-build-') as tmp:
            tmp=Path(tmp); zpath=tmp/'input.zip'; root=tmp/'unpacked'; root.mkdir()
            try:
                remaining=length
                with open(zpath,'wb') as f:
                    while remaining:
                        chunk=self.rfile.read(min(1024*1024,remaining))
                        if not chunk: raise BuildError('Upload ended unexpectedly.')
                        f.write(chunk); remaining-=len(chunk)
                safe_extract(zpath,root)
                project_dir=None
                has_gradle=any(p.name in ('settings.gradle','settings.gradle.kts') for p in root.rglob('*') if p.is_file())
                has_html=any(p.name.lower() in ('index.html','index.htm') for p in root.rglob('*') if p.is_file())
                chosen = 'android' if mode=='android' or (mode=='auto' and has_gradle) else 'web'
                if chosen=='web':
                    project=tmp/'generated-project'; web_zip_to_android_project(root,project,app_name,package_id); project_dir=project
                else:
                    project_dir=find_project(root)
                apk,log=run_build(project_dir,self.server.gradle,self.server.build_mode)
                body=apk.read_bytes()
                self.send_response(200); self.send_header('Content-Type','application/vnd.android.package-archive'); self.send_header('Content-Length',str(len(body))); self.send_header('X-Ziplet-Project-Type',chosen); self.send_header('X-Ziplet-Apk-Sha256',hashlib.sha256(body).hexdigest()); self.send_header('X-Ziplet-Build-Log-Sha256',hashlib.sha256(log.encode()).hexdigest()); self.end_headers(); self.wfile.write(body)
            except BuildError as e: self.send_json(422, {'ok':False,'error':str(e)})
            except Exception as e: self.send_json(500, {'ok':False,'error':f'agent error: {type(e).__name__}: {e}'})

def main():
    ap=argparse.ArgumentParser(description='ZIPLET Gradle build agent')
    ap.add_argument('--bind',default='127.0.0.1',help='Default localhost only. For LAN use TLS options.')
    ap.add_argument('--port',type=int,default=8765)
    ap.add_argument('--token',required=True,help='Long random secret; never reuse passwords.')
    ap.add_argument('--gradle',default='gradle',help='Gradle executable path')
    ap.add_argument('--mode',choices=['debug','release'],default='debug')
    ap.add_argument('--cert',help='TLS certificate PEM (required for non-loopback bind)')
    ap.add_argument('--key',help='TLS private key PEM (required for non-loopback bind)')
    ap.add_argument('--i-understand-build-scripts-execute-code',action='store_true',help='Required acknowledgement before builds are accepted')
    args=ap.parse_args()
    if not args.i_understand_build_scripts_execute_code: ap.error('Refusing to run without --i-understand-build-scripts-execute-code. Imported Gradle build scripts can execute code.')
    loopback=args.bind in ('127.0.0.1','::1','localhost')
    if not loopback and not (args.cert and args.key): ap.error('Non-loopback bind requires --cert and --key (HTTPS only).')
    if len(args.token)<24: ap.error('Token must be at least 24 characters; generate a random token.')
    server=http.server.ThreadingHTTPServer((args.bind,args.port),Handler); server.token=args.token; server.gradle=args.gradle; server.build_mode=args.mode
    if not loopback:
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(args.cert,args.key); server.socket=ctx.wrap_socket(server.socket,server_side=True)
    print(f'ZIPLET Build Agent listening on {args.bind}:{args.port} (TLS={not loopback}); mode={args.mode}; Gradle={args.gradle}')
    print('Only build ZIPs you trust. Builds run with --offline; missing dependencies cause a clear failure.')
    try: server.serve_forever()
    except KeyboardInterrupt: print('\nStopping ZIPLET Build Agent.')
    finally: server.server_close()
if __name__=='__main__': main()
