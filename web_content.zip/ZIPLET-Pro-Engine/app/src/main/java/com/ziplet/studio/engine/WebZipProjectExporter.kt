package com.ziplet.studio.engine

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Safe first-stage Web ZIP pipeline.
 * Produces a self-contained Android Studio wrapper project (NOT an APK).
 * The generated project can be opened in Android Studio and built there.
 */
object WebZipProjectExporter {
    data class Result(val projectDir: File, val entryHtml: String, val extractedBytes: Long, val fileCount: Int)

    private const val MAX_ARCHIVE = 120L * 1024 * 1024
    private const val MAX_UNPACKED = 350L * 1024 * 1024
    private const val MAX_FILES = 20_000

    fun export(context: Context, uri: Uri, appName: String, applicationId: String): Result {
        val safeName = appName.trim().replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifBlank { "My Offline App" }.take(60)
        val appId = applicationId.trim()
        require(appId.matches(Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+"))) { "Enter a valid package ID, e.g. com.example.myapp" }
        val size = context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
        require(size in 1..MAX_ARCHIVE) { "ZIP must be non-empty and no larger than 120 MB." }

        val root = File(context.filesDir, "exports/${System.currentTimeMillis()}")
        val assets = File(root, "app/src/main/assets/site")
        check(assets.mkdirs()) { "Could not create project workspace." }
        var unpacked = 0L
        var count = 0
        val paths = mutableSetOf<String>()
        context.contentResolver.openInputStream(uri)?.use { raw -> ZipInputStream(raw).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) { zip.closeEntry(); continue }
                count++
                require(count <= MAX_FILES) { "ZIP has too many files (limit $MAX_FILES)." }
                val normalized = entry.name.replace('\\', '/')
                require(!normalized.startsWith('/') && !normalized.split('/').any { it == ".." || it.isBlank() }) { "Unsafe ZIP path blocked." }
                require(!normalized.contains(':')) { "Suspicious ZIP path blocked." }
                require(paths.add(normalized.lowercase())) { "Duplicate file path blocked: $normalized" }
                val dest = File(assets, normalized)
                check(dest.canonicalPath.startsWith(assets.canonicalPath + File.separator)) { "ZIP path escaped workspace." }
                dest.parentFile?.mkdirs()
                dest.outputStream().use { out ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = zip.read(buf)
                        if (n < 0) break
                        unpacked += n
                        require(unpacked <= MAX_UNPACKED) { "Expanded ZIP exceeds 350 MB safety limit." }
                        out.write(buf, 0, n)
                    }
                }
                zip.closeEntry()
            }
        } } ?: error("Could not read selected ZIP.")
        require(count > 0) { "ZIP is empty." }
        val index = listOf("index.html", "Index.html", "index.htm").map { File(assets, it) }.firstOrNull { it.isFile }
            ?: assets.walkTopDown().firstOrNull { it.isFile && it.name.equals("index.html", true) }
            ?: error("No index.html found. Put the site's entry page at the ZIP root for this first version.")
        val relativeIndex = index.relativeTo(assets).invariantSeparatorsPath
        writeText(root, "settings.gradle", "pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name = \"ZipletGenerated\"\ninclude(\":app\")\n")
        writeText(root, "build.gradle", "plugins { id 'com.android.application' version '8.7.3' apply false }\n")
        writeText(root, "gradle.properties", "org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\n")
        writeText(root, "app/build.gradle", """plugins { id 'com.android.application' }

// Optional release signing: create signing.properties locally (never commit/share it).
def signingFile = rootProject.file('signing.properties')
def signing = new Properties()
if (signingFile.exists()) signingFile.withInputStream { signing.load(it) }

android {
    namespace '$appId'
    compileSdk 35
    defaultConfig { applicationId '$appId'; minSdk 23; targetSdk 35; versionCode 1; versionName '1.0' }
    signingConfigs {
        release {
            if (signingFile.exists()) {
                storeFile rootProject.file(signing['storeFile'])
                storePassword signing['storePassword']
                keyAlias signing['keyAlias']
                keyPassword signing['keyPassword']
            }
        }
    }
    buildTypes { release { if (signingFile.exists()) signingConfig signingConfigs.release; minifyEnabled false } }
}
""")
        writeText(root, ".gitignore", "signing.properties\n*.jks\n*.keystore\nlocal.properties\n.gradle/\nbuild/\napp/build/\n")
        writeText(root, "app/src/main/AndroidManifest.xml", """<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="${xml(safeName)}" android:usesCleartextTraffic="false" android:theme="@android:style/Theme.Material.Light.NoActionBar"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>""")
        val javaPath = "app/src/main/java/" + appId.replace('.', '/')
        writeText(root, "$javaPath/MainActivity.java", """package $appId;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebViewClient;
public class MainActivity extends Activity { @Override public void onCreate(Bundle b) { super.onCreate(b); WebView w = new WebView(this); w.setWebViewClient(new WebViewClient()); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); setContentView(w); w.loadUrl("file:///android_asset/site/$relativeIndex"); } }
""")
        writeText(root, "BUILD-NOTES.txt", """Generated by ZIPLET Web ZIP exporter. This is an Android project, not an APK.

BUILD
1) Open this folder in Android Studio on a compatible computer with JDK 17, Android SDK 35 and Gradle plugin dependencies.
2) Sync Gradle, then run :app:assembleDebug for a test APK.
3) For a release APK, create a private signing key and a local signing.properties file (template below), then run :app:assembleRelease.
4) Verify the output APK before distributing it. Keep the keystore and passwords backed up privately.

signing.properties template (replace every value; keep this file private):
storeFile=release-key.jks
storePassword=YOUR_STORE_PASSWORD
keyAlias=YOUR_KEY_ALIAS
keyPassword=YOUR_KEY_PASSWORD

KEY GENERATION (run on trusted machine with JDK keytool):
keytool -genkeypair -v -keystore release-key.jks -alias YOUR_KEY_ALIAS -keyalg RSA -keysize 3072 -validity 10000

OFFLINE/SAFETY
Review website assets before distributing. JavaScript is enabled for site compatibility; only use ZIPs you trust. External APIs, remote fonts, server login and online features will not work offline without adaptation. This template does not bundle an Android SDK, Gradle distribution or plugin dependencies, so first build setup requires them. Signing configuration only signs when the private local properties and keystore are provided. Do not send your keystore to ZIPLET or share it.
""")
        return Result(root, relativeIndex, unpacked, count)
    }

    private fun writeText(root: File, relative: String, value: String) {
        val f = File(root, relative); f.parentFile?.mkdirs(); f.writeText(value)
    }
    private fun xml(s: String) = s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;")
}
