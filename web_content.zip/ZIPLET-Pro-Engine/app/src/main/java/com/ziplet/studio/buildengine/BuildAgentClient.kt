package com.ziplet.studio.buildengine

import android.content.Context
import android.net.Uri
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Connects ZIPLET to the real Gradle Build Agent. The agent can run on this device
 * (for example via a local Linux/Termux environment) or a paired companion device.
 * HTTP is allowed only for loopback endpoints; companion endpoints must use HTTPS.
 */
object BuildAgentClient {
    data class Result(val apk: File, val sha256: String, val projectType: String)
    private const val MAX_ZIP = 120L * 1024 * 1024

    fun build(
        context: Context,
        zipUri: Uri,
        endpoint: String,
        token: String,
        mode: String = "auto",
        appName: String = "Offline App",
        packageId: String = "com.ziplet.generated"
    ): Result {
        require(token.length >= 24) { "Build Agent token must be at least 24 characters." }
        val normalized = endpoint.trim().trimEnd('/')
        require(normalized.isNotBlank()) { "Enter a Build Agent URL in Settings." }
        val url = URL("$normalized/build")
        val host = url.host.lowercase()
        val loopback = host == "127.0.0.1" || host == "localhost" || host == "::1" || host == "[::1]"
        require(url.protocol == "https" || (url.protocol == "http" && loopback)) {
            "Companion devices require HTTPS. HTTP is allowed only for localhost."
        }
        val staged = File(context.cacheDir, "ziplet-upload-${System.currentTimeMillis()}.zip")
        try {
            context.contentResolver.openInputStream(zipUri)?.use { input -> staged.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024); var total = 0L
                while (true) {
                    val n = input.read(buffer); if (n < 0) break
                    total += n; require(total <= MAX_ZIP) { "ZIP exceeds the 120 MB limit." }
                    output.write(buffer, 0, n)
                }
            } } ?: error("Cannot read selected ZIP.")
            require(staged.length() > 0) { "Selected ZIP is empty." }
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 15 * 60 * 1000
                doOutput = true
                setFixedLengthStreamingMode(staged.length())
                setRequestProperty("Content-Type", "application/zip")
                setRequestProperty("X-Ziplet-Token", token)
                setRequestProperty("X-Ziplet-Mode", mode)
                setRequestProperty("X-Ziplet-App-Name", appName.take(60))
                setRequestProperty("X-Ziplet-Package-Id", packageId)
            }
            try {
                conn.outputStream.use { out -> staged.inputStream().use { it.copyTo(out, 64 * 1024) } }
                val status = conn.responseCode
                if (status != 200) {
                    val message = try { conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "No error details returned." } catch (_: Throwable) { "No error details returned." }
                    throw IllegalStateException("Build Agent returned HTTP $status: ${message.take(5000)}")
                }
                val outDir = File(context.filesDir, "builds").apply { mkdirs() }
                val apk = File(outDir, "ziplet-${System.currentTimeMillis()}.apk")
                conn.inputStream.use { input -> apk.outputStream().use { input.copyTo(it, 64 * 1024) } }
                require(apk.length() > 1024) { "Build Agent returned an invalid or empty APK." }
                val actual = sha256(apk)
                val expected = conn.getHeaderField("X-Ziplet-Apk-Sha256")
                require(!expected.isNullOrBlank() && actual.equals(expected, ignoreCase = true)) {
                    apk.delete(); "APK checksum verification failed. The APK was discarded."
                }
                return Result(apk, actual, conn.getHeaderField("X-Ziplet-Project-Type") ?: "unknown")
            } finally { conn.disconnect() }
        } finally { staged.delete() }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input -> val buffer = ByteArray(64 * 1024); while (true) { val n=input.read(buffer); if(n<0) break; digest.update(buffer,0,n) } }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
