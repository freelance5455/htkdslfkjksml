package com.ziplet.studio

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.ziplet.studio.buildengine.ApkInstallWorkflow
import com.ziplet.studio.buildengine.BuildAgentClient
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.util.zip.ZipInputStream

private val Ink = Color(0xFF211633)
private val Plum = Color(0xFF6F45D8)
private val Lilac = Color(0xFFEDE5FF)
private val Canvas = Color(0xFFF8F6FC)
private val Mint = Color(0xFFBFF4DE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZipletApp(this) }
    }
}

data class ProjectItem(val name: String, val kind: String, val size: String, val note: String)

@Composable
fun ZipletApp(context: Context) {
    var tab by remember { mutableStateOf(0) }
    var current by remember { mutableStateOf<ProjectItem?>(null) }
    var banner by remember { mutableStateOf("Your tiny app studio is ready ✨") }
    var isBuilding by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(loadHistory(context)) }
    val scope = rememberCoroutineScope()
    val apkPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ApkInstallWorkflow.launchInstaller(context, uri) }
            catch (t: Throwable) { banner = "Could not open Android installer: ${t.message ?: "unknown error"}" }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            banner = "Inspecting your ZIP…"
            val result = withContext(Dispatchers.IO) { inspectZip(context, uri) }
            if (result.first != null) {
                current = result.first
                banner = result.second
                history = listOf(result.first!!) + history.filterNot { it.name == result.first!!.name }.take(9)
                saveHistory(context, history)
                tab = 1
            } else banner = result.second
        }
    }
    val buildPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val prefs = context.getSharedPreferences("ziplet", Context.MODE_PRIVATE)
            val endpoint = prefs.getString("agent_endpoint", "http://127.0.0.1:8765") ?: "http://127.0.0.1:8765"
            val token = prefs.getString("agent_token", "") ?: ""
            if (token.length < 24) {
                banner = "Set a 24+ character Build Agent token in Settings first."
            } else {
                isBuilding = true
                banner = "Uploading project to Build Agent. Compilation may take several minutes…"
                try {
                    val result = withContext(Dispatchers.IO) { BuildAgentClient.build(context, uri, endpoint, token) }
                    banner = "APK built and SHA-256 verified (${result.projectType}). Opening Android installer…"
                    val apkUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", result.apk)
                    ApkInstallWorkflow.launchInstaller(context, apkUri)
                } catch (t: Throwable) {
                    banner = "Build failed: ${t.message ?: "unknown error"}"
                } finally { isBuilding = false }
            }
        }
    }
    Scaffold(containerColor = Canvas, bottomBar = {
        NavigationBar(containerColor = Color.White, tonalElevation = 0.dp) {
            listOf("Studio", "Projects", "Settings").forEachIndexed { index, label ->
                NavigationBarItem(selected = tab == index, onClick = { tab = index },
                    icon = { Icon(when(index){0->Icons.Default.AutoAwesome;1->Icons.Default.FolderOpen;else->Icons.Default.Tune}, null) },
                    label = { Text(label, fontWeight = if (tab == index) FontWeight.SemiBold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor=Plum, indicatorColor=Lilac, selectedTextColor=Plum))
            }
        }
    }) { pad ->
        AnimatedContent(targetState = tab, label = "screen", modifier = Modifier.padding(pad)) { selected ->
            when(selected) {
                0 -> StudioScreen(banner, current, history.size, isBuilding, onImport = { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, onBuild = { buildPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, onHistory={tab=1}, onInstall={apkPicker.launch(arrayOf("application/vnd.android.package-archive"))})
                1 -> ProjectsScreen(history, current, onImport={picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))})
                else -> SettingsScreen(context)
            }
        }
    }
}

@Composable private fun StudioScreen(banner: String, current: ProjectItem?, builds: Int, isBuilding: Boolean, onImport:()->Unit, onBuild:()->Unit, onHistory:()->Unit, onInstall:()->Unit) {
    LazyColumn(modifier=Modifier.fillMaxSize(), contentPadding=PaddingValues(start=20.dp,end=20.dp,top=22.dp,bottom=26.dp), verticalArrangement=Arrangement.spacedBy(18.dp)) {
        item { Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween, modifier=Modifier.fillMaxWidth()) {
            Column { Text("ZIPLET", color=Ink, fontSize=29.sp, fontWeight=FontWeight.Black, letterSpacing=(-1).sp); Text("YOUR POCKET APP STUDIO", color=Plum, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=2.sp) }
            Box(Modifier.size(48.dp).clip(CircleShape).background(Lilac), contentAlignment=Alignment.Center) { Text("✦", fontSize=28.sp, color=Plum) }
        } }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(Brush.linearGradient(listOf(Color(0xFF30204B),Color(0xFF6744B8),Color(0xFF9B78EC)))).padding(22.dp)) {
                Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Big ideas.\nTiny packages.", color=Color.White, fontSize=30.sp, fontWeight=FontWeight.ExtraBold, lineHeight=34.sp); Text("Turn supported projects into Android apps.", color=Color(0xFFE5DDF9), fontSize=13.sp, modifier=Modifier.padding(top=9.dp)) }
                        Box(Modifier.size(82.dp).clip(RoundedCornerShape(26.dp)).background(Color.White.copy(.14f)), contentAlignment=Alignment.Center) { Text("📦", fontSize=48.sp) }
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.OfflineBolt, null, tint=Mint, modifier=Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("LOCAL-FIRST  •  ZIP LIMIT 120 MB", color=Mint, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=1.sp) }
                    Button(onClick=onImport, colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Ink), shape=RoundedCornerShape(16.dp), modifier=Modifier.fillMaxWidth().height(54.dp)) { Icon(Icons.Default.AddCircle, null, tint=Plum); Spacer(Modifier.width(9.dp)); Text("Create an app", fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); Icon(Icons.Default.ArrowForward, null) }
                }
            }
        }
        item { Text("CHOOSE YOUR STARTING POINT", color=Color(0xFF82788F), fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=1.5.sp) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            ModeCard("Web ZIP", "HTML · CSS · JS", "🌐", Modifier.weight(1f), "Package a self-contained site")
            ModeCard("Android project", "Gradle project", "🤖", Modifier.weight(1f), "Build a compatible source project")
        } }
        item { Row(verticalAlignment=Alignment.CenterVertically) { Text("Your workspace", fontSize=20.sp, color=Ink, fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); TextButton(onClick=onHistory) { Text("View all  ↗", color=Plum) } } }
        item { Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            MetricCard("PROJECTS", builds.toString(), "▦", Modifier.weight(1f)); MetricCard("BUILD ENGINE", "Agent mode", "⚙", Modifier.weight(1f))
        } }
        item { Surface(shape=RoundedCornerShape(20.dp), color=Color.White, modifier=Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment=Alignment.Top) { Text("✿", fontSize=25.sp); Spacer(Modifier.width(12.dp)); Column { Text("Studio note", color=Ink, fontWeight=FontWeight.Bold); Text(banner, color=Color(0xFF766C82), fontSize=13.sp); if(current!=null) Text("Latest: ${current.name} · ${current.kind}", color=Plum, fontSize=12.sp, fontWeight=FontWeight.SemiBold, modifier=Modifier.padding(top=5.dp)) } } } }
        item { Button(onClick=onBuild, enabled=!isBuilding, modifier=Modifier.fillMaxWidth().height(54.dp), shape=RoundedCornerShape(16.dp), colors=ButtonDefaults.buttonColors(containerColor=Plum)) { if(isBuilding) { CircularProgressIndicator(modifier=Modifier.size(18.dp), color=Color.White, strokeWidth=2.dp); Spacer(Modifier.width(10.dp)); Text("Building APK…", color=Color.White, fontWeight=FontWeight.Bold) } else { Icon(Icons.Default.Build,null); Spacer(Modifier.width(8.dp)); Text("Build APK from ZIP", color=Color.White, fontWeight=FontWeight.Bold) } } }
        item { OutlinedButton(onClick=onInstall, modifier=Modifier.fillMaxWidth().height(50.dp), shape=RoundedCornerShape(15.dp)) { Icon(Icons.Default.InstallMobile,null,tint=Plum); Spacer(Modifier.width(8.dp)); Text("Install an existing APK", color=Plum, fontWeight=FontWeight.Bold) } }
        item { Text("Build APK sends your ZIP to the configured local/companion Build Agent. Gradle build scripts execute code: only build projects you trust. The APK checksum is verified before the Android installer opens.", color=Color(0xFF877D90), fontSize=11.sp, lineHeight=16.sp) }
    }
}

@Composable private fun ModeCard(title:String, subtitle:String, emoji:String, modifier:Modifier, caption:String) {
    Surface(modifier=modifier, color=Color.White, shape=RoundedCornerShape(22.dp), shadowElevation=1.dp) { Column(Modifier.padding(15.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) { Text(emoji,fontSize=27.sp); Text(title,color=Ink,fontSize=15.sp,fontWeight=FontWeight.Bold); Text(subtitle,color=Plum,fontSize=10.sp,fontWeight=FontWeight.Bold); Text(caption,color=Color(0xFF887E94),fontSize=11.sp,lineHeight=15.sp) } }
}
@Composable private fun MetricCard(label:String, value:String, emoji:String, modifier:Modifier) { Surface(modifier=modifier, color=Color.White, shape=RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Text(emoji,fontSize=23.sp); Text(value,color=Ink,fontSize=18.sp,fontWeight=FontWeight.ExtraBold, modifier=Modifier.padding(top=8.dp)); Text(label,color=Color(0xFF877D90),fontSize=9.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp) } } }

@Composable private fun ProjectsScreen(history:List<ProjectItem>, current:ProjectItem?, onImport:()->Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal=20.dp)) {
        Text("Your projects", color=Ink, fontSize=28.sp, fontWeight=FontWeight.Black, modifier=Modifier.padding(top=28.dp))
        Text("A little shelf for your big ideas.", color=Color(0xFF82788F), modifier=Modifier.padding(top=4.dp,bottom=20.dp))
        Button(onClick=onImport, modifier=Modifier.fillMaxWidth().height(50.dp), shape=RoundedCornerShape(15.dp), colors=ButtonDefaults.buttonColors(containerColor=Plum)) { Icon(Icons.Default.Add,null); Spacer(Modifier.width(8.dp)); Text("Import ZIP") }
        Spacer(Modifier.height(16.dp))
        if(history.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("🪴",fontSize=48.sp); Text("Nothing on your shelf yet",color=Ink,fontWeight=FontWeight.Bold); Text("Import a ZIP to begin your first project.",color=Color.Gray,fontSize=12.sp) } }
        else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) { items(history) { item -> Surface(color=Color.White,shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) { Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Lilac),contentAlignment=Alignment.Center) { Icon(Icons.Default.FolderZip,null,tint=Plum) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(item.name,color=Ink,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis); Text(item.kind,color=Plum,fontSize=11.sp,fontWeight=FontWeight.SemiBold); Text("${item.size}  •  ${item.note}",color=Color.Gray,fontSize=10.sp) }; Icon(Icons.Default.ChevronRight,null,tint=Color.LightGray) } } } }
    }
}

@Composable private fun SettingsScreen(context: Context) {
    var offline by remember { mutableStateOf(true) }
    var maxZip by remember { mutableFloatStateOf(120f) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Your studio",color=Ink,fontSize=28.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=10.dp))
        Text("Make it feel like yours.",color=Color(0xFF82788F),modifier=Modifier.padding(top=4.dp,bottom=20.dp))
        val prefs = remember { context.getSharedPreferences("ziplet", Context.MODE_PRIVATE) }
        var agentEndpoint by remember { mutableStateOf(prefs.getString("agent_endpoint", "http://127.0.0.1:8765") ?: "http://127.0.0.1:8765") }
        var agentToken by remember { mutableStateOf(prefs.getString("agent_token", "") ?: "") }
        Surface(color=Color.White,shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Text("BUILD ENGINE CONNECTION",color=Plum,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp)
            Text("Local on this device: http://127.0.0.1:8765. Companion device: use its HTTPS URL and a trusted certificate.",color=Color.Gray,fontSize=11.sp,lineHeight=16.sp)
            OutlinedTextField(value=agentEndpoint,onValueChange={agentEndpoint=it; prefs.edit().putString("agent_endpoint",it).apply()},label={Text("Build Agent URL")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=agentToken,onValueChange={agentToken=it; prefs.edit().putString("agent_token",it).apply()},label={Text("Build Agent token")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Text("Use the same 24+ character token on the agent. Never share it publicly.",color=Color.Gray,fontSize=11.sp)
        } }
        Spacer(Modifier.height(14.dp))
        Surface(color=Color.White,shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
            Text("PREFERENCES",color=Plum,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp)
            Row(Modifier.fillMaxWidth().padding(top=15.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Offline-first mode",color=Ink,fontWeight=FontWeight.SemiBold); Text("Keep project work on this device",color=Color.Gray,fontSize=11.sp) }; Switch(offline,{offline=it}) }
            HorizontalDivider(Modifier.padding(vertical=12.dp),color=Canvas)
            Text("ZIP size limit",color=Ink,fontWeight=FontWeight.SemiBold); Text("${maxZip.toInt()} MB",color=Plum,fontSize=22.sp,fontWeight=FontWeight.ExtraBold); Slider(value=maxZip,onValueChange={maxZip=it},valueRange=10f..120f,steps=10,colors=SliderDefaults.colors(thumbColor=Plum,activeTrackColor=Plum))
        } }
        Spacer(Modifier.height(14.dp))
        Surface(color=Color.White,shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text("ABOUT ZIPLET",color=Plum,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp); Text("ZIPLET · Pocket App Studio",color=Ink,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp)); Text("Build Agent edition · v0.2.0",color=Color.Gray,fontSize=12.sp); Text("APK compilation is performed by the configured Gradle Build Agent. Debug APKs are signed by the Android Gradle build, and ZIPLET verifies the transferred APK checksum before handing it to Android.",color=Color(0xFF82788F),fontSize=12.sp,lineHeight=18.sp,modifier=Modifier.padding(top=8.dp)) } }
    }
}

private fun inspectZip(context: Context, uri: Uri): Pair<ProjectItem?,String> {
    return try {
        val name = queryName(context,uri) ?: "Imported project.zip"
        val size = context.contentResolver.openFileDescriptor(uri,"r")?.use { it.statSize } ?: -1L
        if(size > 120L*1024*1024) return null to "ZIP is over the 120 MB limit. Choose a smaller file."
        if(!name.lowercase().endsWith(".zip")) return null to "Please select a ZIP file."
        var entries=0; var html=false; var gradle=false; var manifest=false; var appGradle=false; var suspicious=false
        context.contentResolver.openInputStream(uri)?.use { stream ->
            ZipInputStream(stream).use { zip ->
                while(true) {
                    val e=zip.nextEntry ?: break
                    entries++
                    val p=e.name.replace('\\','/').lowercase()
                    if(p.startsWith("/") || p.split('/').any { it==".." }) suspicious=true
                    if(p.endsWith("index.html")) html=true
                    if(p.endsWith("settings.gradle") || p.endsWith("settings.gradle.kts")) gradle=true
                    if(p.endsWith("androidmanifest.xml")) manifest=true
                    if(p.endsWith("app/build.gradle") || p.endsWith("app/build.gradle.kts")) appGradle=true
                    zip.closeEntry()
                    if(entries>100000) throw IllegalStateException("ZIP contains too many entries.")
                }
            }
        } ?: return null to "Unable to open this file."
        if(entries==0) return null to "This ZIP appears to be empty or invalid."
        if(suspicious) return null to "ZIP has unsafe path entries. Import blocked."
        val kind = when { gradle && manifest -> "Android project candidate"; html -> "Web project candidate"; else -> "Unclassified ZIP" }
        val advice = when { gradle && manifest -> "Project detected. Build compatibility needs checking."; html -> "Website files detected. Check external dependencies for offline use."; else -> "ZIP inspected, but project type was not recognized." }
        ProjectItem(name,kind,if(size>=0) "${(size/1024/1024).coerceAtLeast(1)} MB" else "Size unknown", "$entries entries") to advice
    } catch(t:Throwable) { null to ("Could not inspect ZIP: ${t.message ?: "unknown error"}") }
}
private fun queryName(context:Context,uri:Uri):String? = context.contentResolver.query(uri,null,null,null,null)?.use { c -> if(c.moveToFirst()) { val i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(i>=0)c.getString(i) else null } else null }
private fun loadHistory(context:Context):List<ProjectItem> = try { val arr=JSONArray(context.getSharedPreferences("ziplet",0).getString("history","[]")); (0 until arr.length()).map { val o=arr.getJSONObject(it); ProjectItem(o.getString("name"),o.getString("kind"),o.getString("size"),o.getString("note")) } } catch(_:Throwable){ emptyList() }
private fun saveHistory(context:Context,items:List<ProjectItem>) { val arr=JSONArray(); items.take(20).forEach { arr.put(JSONObject().put("name",it.name).put("kind",it.kind).put("size",it.size).put("note",it.note)) }; context.getSharedPreferences("ziplet",0).edit().putString("history",arr.toString()).apply() }
