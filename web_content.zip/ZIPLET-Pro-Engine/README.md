# ZIPLET Pro Engine — Android source + real Gradle build agent

This is an **engineering implementation pack**, not a prebuilt APK. It connects the Android ZIPLET app to a separate Python Build Agent that invokes a real installed Gradle/Android SDK toolchain. The agent can run on the same Android device in a Linux environment, or on another companion device. The APK is returned to ZIPLET, SHA-256 checked, and handed to Android's package installer.

## What is implemented in this pack

- Android ZIPLET app source with an actual **Build APK from ZIP** action.
- Configurable Build Agent endpoint and shared token in Settings.
- Uploads ZIPs up to 120 MB to the configured agent without loading the full ZIP into RAM.
- Build Agent performs safe ZIP extraction, archive path checks, expanded-size and entry-count limits.
- Website ZIP with `index.html` → generated Android WebView project with website assets bundled locally.
- Android Gradle project ZIP → invokes the installed Gradle executable with `assembleDebug`.
- Real Gradle build invocation, captured failure logs, APK existence/size checks, APK SHA-256 response header.
- ZIPLET verifies the received APK checksum before opening Android's system installer.
- APK installation is user-confirmed by Android; ZIPLET does not silently install packages.
- Local loopback mode defaults to `http://127.0.0.1:8765`. Companion mode requires HTTPS.

## Important limits — please read

- The Android app does **not** contain the JDK, Gradle, Android SDK or Android Gradle Plugin. Those are provided by the Build Agent host. This is a real external build worker, not an embedded compiler.
- For true same-phone mode, run the agent inside a local Linux environment on Android (for example Debian in Termux/proot) and install a compatible JDK, Gradle, Android SDK platform/build-tools, and required Gradle/Maven dependencies. This setup is advanced and device-dependent.
- For companion mode, the other device must run the agent in a Linux environment with the build toolchain. Use HTTPS with a certificate trusted by Android; self-signed certificates are not trusted by default.
- Builds use `--offline`. The first-time build may fail until Gradle, the Android SDK and all plugin/dependency artifacts have already been installed/cached. This is intentional: the build itself does not fetch dependencies.
- Android project Gradle scripts can execute arbitrary code. The agent refuses to start unless you pass `--i-understand-build-scripts-execute-code`; only build projects you trust. This is not a hardened multi-tenant sandbox.
- Website projects require a root or nested `index.html`/`index.htm`. External APIs, remote fonts, online login and server-dependent features will not magically work offline.
- The generated APK is a debug APK signed by Gradle's debug key. It is installable for testing but is not a production release signature. Release signing requires a private keystore and a separate secure signing workflow.
- Android Studio ZIP builds use the installed Gradle version and cached toolchain. Projects that need a different Gradle/AGP/JDK version may fail and need compatibility setup.
- This source project has not been compiled in this environment because an Android SDK/Gradle toolchain is not installed here. Do not treat it as a verified release APK.

## 1. Build the ZIPLET Android app

Open the `ZIPLET-Pro-Engine` folder in Android Studio. Initial Gradle sync requires network access unless dependencies are already cached. Build and install ZIPLET on an Android device. On first install, Android may ask permission to install APKs from ZIPLET when you build an app.

## 2. Start the Build Agent on the same device (advanced)

The agent requires Python 3, Java/JDK, Gradle, Android SDK platform 35/build-tools, and cached Android Gradle Plugin/dependencies. A practical route on Android is a Debian environment in Termux/proot; compatibility varies by device.

From the folder containing `build-agent/ziplet_build_agent.py`:

```bash
python3 build-agent/ziplet_build_agent.py \
  --bind 127.0.0.1 --port 8765 \
  --token 'PASTE_A_RANDOM_SECRET_AT_LEAST_24_CHARS_LONG' \
  --gradle gradle --mode debug \
  --i-understand-build-scripts-execute-code
```

Use the exact same token in ZIPLET Settings and keep the agent running while building. The default agent is loopback-only and is not reachable by other devices.

Before attempting offline builds, install/accept Android SDK components and warm the Gradle caches in a trusted workspace while internet is available. Afterwards use the agent's offline build workflow. The agent returns a clear failure if required dependencies are missing.

## 3. Companion-device mode

On the companion device, run the agent with a trusted TLS certificate/key and a LAN bind address, for example:

```bash
python3 build-agent/ziplet_build_agent.py \
  --bind 0.0.0.0 --port 8765 \
  --token 'PASTE_A_RANDOM_SECRET_AT_LEAST_24_CHARS_LONG' \
  --gradle gradle --mode debug \
  --cert /path/to/fullchain.pem --key /path/to/private-key.pem \
  --i-understand-build-scripts-execute-code
```

Only use a certificate trusted by the Android device, firewall the port to the trusted LAN, and do not expose the service to the public internet. ZIPLET's endpoint must be `https://trusted-host:8765`. The agent requires HTTPS for non-loopback interfaces.

## 4. Use ZIPLET

1. Start the Build Agent.
2. In ZIPLET → Settings, enter the agent URL and exact token.
3. Return to Studio → **Build APK from ZIP**.
4. Select a website ZIP or Android Studio project ZIP.
5. Wait for Gradle to finish. The app reports actual server/compiler errors rather than fake progress.
6. ZIPLET checks the returned APK's SHA-256 and opens Android's system installer.

## Build modes

The current UI uses `auto` mode: if a Gradle project is detected, it builds Android source; otherwise it tries website packaging. The Python agent also accepts explicit `web` or `android` modes at API level. APK builds run `assembleDebug`; release signing is not included in this milestone.

## Security notes

- The agent requires an explicit command-line acknowledgement because Gradle build scripts execute code.
- Only use ZIPs you trust. Archive validation is not a sandbox for malicious build scripts.
- Companion builds use HTTPS and a long random bearer token. Do not use a public endpoint.
- Do not upload private keystores or signing passwords to the build agent.
