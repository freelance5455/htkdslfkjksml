# ZIPLET build engine status — Pro Engine pack

## Implemented in source
- Android UI action to upload a ZIP to a configured Build Agent.
- Endpoint/token settings.
- Localhost HTTP is allowed; non-loopback endpoints must use HTTPS.
- Python Build Agent with token authentication, upload size limit, safe extraction checks, decompressed size cap, duplicate/path checks and build timeout.
- Web ZIP to generated Android WebView project.
- Android Gradle project ZIP detection and Gradle `assembleDebug` invocation.
- Agent returns the built APK, project type and SHA-256.
- ZIPLET verifies the APK checksum before handing it to Android's system installer.
- Companion mode can be exposed over TLS with a trusted certificate.

## Not included / not verified
- Embedded compiler inside the Android APK. The compiler runs in the configured local/companion Build Agent process.
- Release keystore creation/management and production release signing.
- A hardened sandbox for malicious Gradle projects. Build scripts execute code; only trusted projects should be built.
- Automatic SDK/Gradle/dependency installation. Toolchain and dependencies must be installed and cached before offline builds.
- Successful Android Studio compilation or device installation test in this environment; no Android SDK/Gradle toolchain is installed here.

## Build acceptance criteria
A build is only successful if the Gradle process exits 0, an APK exists, it is larger than 1 KB, ZIPLET verifies its SHA-256 against the agent response, and Android's package installer accepts the package/signature.
