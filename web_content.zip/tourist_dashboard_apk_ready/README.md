# Tourist Dashboard v3 - Android save fix

NOT a built APK (no Android SDK here, and the Java wrapper is uncompiled/untested). Build it yourself:

## Build (Android Studio, recommended)
1. Open the folder `android_studio_project/` in Android Studio (let it sync Gradle; needs internet once).
   If it complains about the Gradle wrapper: File > New > New Project (Empty Views Activity, package com.example.touristdashboard),
   then copy this folder's `app/src/main` (MainActivity.java, AndroidManifest.xml, assets/) and app/build.gradle dependency `androidx.webkit:webkit:1.11.0` into it.
2. Build > Build APK(s) -> install on phone.

## Why v2 saved nothing
Plain WebView cannot download blob files. This wrapper adds `AndroidBridge.saveFile()` which writes into the phone's Downloads folder (MediaStore, Android 10+; app folder on older) and shows a "Saved:" toast.

## Test order inside the app
1. Delivery = auto (tries androidBridge -> capFilesystem -> share -> anchor). Tap `test_save_txt`; look for the toast and the file in Downloads.
2. Then try each PDF / Excel button. Log shows which delivery path actually ran; "UNVERIFIED" means the browser path was used.
3. `*_cdn` buttons need internet (or files in www/lib/).
4. Backups: storage/IndexedDB/clipboard, `backup_json_file` (saves to Downloads), `restore_json_file` (file picker), `restore_paste_textarea`.

## Capacitor alternative
`www/` + capacitor.config.json: `npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/filesystem`, `npx cap add android`, `npx cap sync`; then capFilesystem works (saves to Documents).
