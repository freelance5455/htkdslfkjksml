# Tourist Dashboard - APK ready project

Contents: www/ (the app), capacitor.config.json, package.json.
NOTE: this is an APK-READY project, not a built APK (no Android SDK here). Build it with ONE of:

## A. Capacitor (recommended - gives real file saving)
    npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/filesystem @capacitor/share
    npx cap add android
    npx cap sync
    npx cap open android      # Android Studio -> Build > Build APK(s)
Then test export buttons with Delivery = capFilesystem (saves to Documents) or share.

## B. No-code: zip the www/ folder and upload to a WebView-to-APK site, or host www/ on HTTPS and use PWABuilder.

## Which export methods to expect in a WebView
- Native/no-library methods (pdf_native_builder, xlsx_native_zip, csv_blob, backup_*) work offline.
- Delivery 'anchor' often does NOTHING in Android WebView -> use capFilesystem / share, or the bridge below.
- pdf_print_window needs a WebView print bridge; usually fails in plain WebView.
- *_cdn methods need internet or files in www/lib/.
- Custom WebView: expose window.AndroidBridge.saveFile(name, mime, base64) via @JavascriptInterface, then choose Delivery = androidBridge.
The Log panel in the app shows which method worked/failed.
