# Tourist Dashboard - APK ready project (v2, verified methods only)
Not a built APK (no Android SDK here). Build: zip www/ into any WebView wrapper, or use Capacitor:
    npm i @capacitor/core @capacitor/cli @capacitor/android
    npx cap add android && npx cap sync && npx cap open android
Methods kept (all logged OK on your Android install):
PDF: pdf_native_builder, pdf_jspdf_autotable_cdn, pdf_html2pdf_cdn
Excel/data: xlsx_native_zip, xlsx_sheetjs_aoa_cdn, xlsx_sheetjs_table_to_book_cdn, xls_html_blob, csv_blob
Backup/restore: localStorage, indexedDB (both directions), backup_clipboard, backup_json_file
Delivery: anchor, openTab. NOTE: a log OK means the file was generated; confirm it actually lands in Downloads on the phone.
CDN methods need internet or the files listed in www/lib/README.txt.
