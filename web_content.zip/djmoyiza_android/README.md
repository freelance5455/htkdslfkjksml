# DJ MOYIZA STUDIO (prototype)

Android landscape app prototype for TECNO POP 8.

Features currently implemented: 8 track control strips (7 voice + instrumental), landscape layout, local instrumental file selection/playback, microphone recording, pause/stop, take download/save, basic track faders and mute UI.

Important limitations: this is a prototype. It does not yet perform true multi-track recording/mixing, Auto-Tune, reverb/echo processing, or save a project session. The Auto-Tune and effects controls are UI placeholders. Recording is a single microphone take saved as WebM.

## Build APK via GitHub Actions
1. Create a GitHub repository and upload the contents of this project.
2. Open Actions > Build DJ Moyiza APK > Run workflow.
3. After the workflow completes, download the artifact `DJ-Moyiza-Studio-APK`.
4. Extract it and install `app-debug.apk` on your TECNO POP 8. Allow installation from the file manager if Android asks.
