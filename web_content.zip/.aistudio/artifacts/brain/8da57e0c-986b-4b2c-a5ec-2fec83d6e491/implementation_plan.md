# Yiffy - Live Multi-Platform Media Ingestion & Expanded Gender Filtering

Transition Yiffy from seed catalogs to real-time live network ingestion across all platforms (Reddit, e621, Rule34, Pornhub, E-Hentai, MyReadingManga), backed by an offline cache and an expanded gender filter system (Female, Male, Trans/Herm, and Any) with customizable query configurations per source.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural refinements incorporate your latest specifications:

- **Confirmed Decision (Live REST Ingestion + Graceful Offline Cache)**: Implement real network fetchers for all platforms via OkHttp/Retrofit with dedicated User-Agent headers. If a network call fails, is rate-limited (HTTP 429), or Cloudflare-protected, the app automatically serves cached responses from Room database, ensuring an uninterrupted browsing experience.
- **Confirmed Decision (Expanded Gender Filter System)**: Move beyond a simple boolean switch into a comprehensive 4-way filter (`Any`, `Female Only`, `Male Only`, `Trans / Herm`) integrated directly into the sidebar drawer, feed top bar, and profile dropdown filters.
- **Confirmed Decision (Configurable Source Queries & Subreddits)**: Users can define custom default search tags and comma-separated subreddits (e.g., `furry, yiff, anthro`) directly inside Settings for Reddit, e621, and Rule34.

---

## 1. Overview & Core Concept

**Yiffy** evolves into a fully live, multi-network scraper and aggregator:
- **Live Video Feed**: Real video streams pulled live from e621 (filtered by animated/webm), Rule34 animated, and Pornhub endpoints.
- **Live Picture Stream**: Real-time booru and Reddit image feeds fetched from e621, Rule34, and Reddit JSON endpoints.
- **Live Comics & Manga**: Real multi-page comic pools and doujinshi galleries fetched from e621 pools, MyReadingManga, and E-Hentai.
- **Live Miscellaneous**: Live Reddit, Bluesky, and Twitter social streams displaying real community posts, user flairs, captions, and platform chips.
- **Robust Multi-Layer Gender Filter**: Automatic tag inspection that categorizes posts into Female, Male, Trans/Herm, or Any, strictly enforcing user preference across all tabs.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Filtering by Gender & Source in Feeds**:
   - Tapping the **Filter** icon or opening the sidebar drawer exposes the expanded **Gender Filter** section:
     - 🟣 **Any**: No gender restrictions.
     - 🌸 **Female Only**: Excludes all male, yaoi, bara, and 1boy tags; enforces female/1girl.
     - 🔷 **Male Only**: Excludes female/yuri tags; shows male/bara/yaoi content.
     - 🌈 **Trans / Herm**: Filters for intersex, gynomorph, andromorph, and trans tags.
   - The active gender mode is displayed as a glowing badge on the top bar for quick toggling.
2. **Live Feed Pull & Infinite Scrolling**:
   - The feed queries live endpoints in the background as the user scrolls, seamlessly appending new pages of media.
   - When offline or during rate-limiting, a subtle toast or banner alerts the user while loading cached posts without interrupting playback.
3. **Custom Subreddit & Tag Customization in Settings**:
   - Settings includes an expanded **Source Configuration** panel:
     - Reddit subreddits editor (e.g. `furry, yiff, anthro, furryartschool`).
     - e621 default tags (e.g. `order:score score:>20`).
     - Rule34 default query tags.
     - Pornhub search keywords.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Direct Live REST with Room Fallback**
  - *Approach*: Directly query public JSON endpoints (e621 `/posts.json`, Rule34 dapi JSON, Reddit `hot.json`) with an OkHttp client, caching valid responses in Room `history_items` and `cached_feed_items`.
  - *Rationale*: Maximum responsiveness and zero server dependency, with 100% offline resilience if public APIs encounter temporary throttles.
- **Decision 2: Comprehensive Multi-Tag Gender Classifier**
  - *Approach*: Tag evaluation engine that examines booru tag categories, post titles, Reddit post flairs, and metadata to classify each item into gender buckets.
  - *Rationale*: Boorus and Reddit have divergent tag nomenclatures (`1girl` vs `female`, `1boy` vs `male`, `gynomorph` vs `trans`). A unified mapper provides accurate filtering across disparate sources.

---

## 4. Technical Architecture & Data Strategy

### System Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                UI Layer                                     │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │  Top Bar: Gender Badge (Any / Female / Male / Trans) + Source Filter     │ │
│ ├───────────────────────┬─────────────────────────┬───────────────────────┤ │
│ │ Videos Vertical Pager │ Pictures Staggered Grid │ Comics Mihon Reader   │ │
│ └───────────────────────┴─────────────────────────┴───────────────────────┘ │
│                                      │                                      │
│                                      ▼                                      │
│                       FeedViewModel / ProfileViewModel                      │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
┌──────────────────────────────────────▼──────────────────────────────────────┐
│                            MediaRepository                                  │
│ ┌───────────────────────────┐ ┌───────────────────┐ ┌────────────────────┐  │
│ │ GenderFilterEngine        │ │ QueryConfigurator │ │ CacheManager       │  │
│ └─────────────┬─────────────┘ └─────────┬─────────┘ └──────────┬─────────┘  │
└───────────────┼─────────────────────────┼──────────────────────┼────────────┘
                │                         │                      │
┌───────────────▼─────────────────────────▼──────────────────────▼────────────┐
│                             Network Source Clients                          │
│ ┌──────────────────────┐ ┌──────────────────────┐ ┌───────────────────────┐ │
│ │   E621ApiClient      │ │   Rule34ApiClient    │ │   RedditApiClient     │ │
│ ├──────────────────────┤ ├──────────────────────┤ ├───────────────────────┤ │
│ │   PornhubApiClient   │ │   EHentaiApiClient   │ │  MyReadingMangaClient │ │
│ └──────────────────────┘ └──────────────────────┘ └───────────────────────┘ │
│                                      │                                      │
│                                      ▼                                      │
│                         Local Room Database Cache                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Gender Filter Entities

- `enum class GenderFilter { ANY, FEMALE_ONLY, MALE_ONLY, TRANS_HERM }`
- `data class SourceQueryConfig`:
  - `redditSubreddits: String = "furry,yiff,anthro"`
  - `e621DefaultTags: String = "order:score"`
  - `rule34DefaultTags: String = "sort:score:desc"`
  - `pornhubSearchQuery: String = "furry animation"`
- Enhanced `MediaItem`: holds resolved media streams, fallbacks, and parsed gender category.
