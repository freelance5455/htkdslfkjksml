# Yiffy - Native Android Multi-Platform Media Discovery & Reader

A minimalist, high-performance native Android application delivering an immersive, TikTok-style vertical scrolling feed across boorus, social networks, and manga repositories, coupled with comic reading capabilities, Google Account Drive document synchronization, and customizable profile and download management.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following core behaviors have been aligned based on your initial specifications and clarification responses:

- **Confirmed Decision (Google Account Sync)**: The app will authenticate with your Google Account to manage a dedicated Drive folder containing the 4 required plaintext synchronization files: `History.txt` (last 100 viewed items), `Algorithm_keeping.txt` (tag affinities and feed scoring weights), `Liked_posts.txt` (all user-liked posts with platform metadata), and `Favorite_posts.txt` (segregated by platform sections).
- **Confirmed Decision (Feed & API Key Flow)**: Feeds will load public endpoints (e.g. e621, Rule34, Reddit JSON, Bluesky public feeds) right away with clear inline badges/prompts to configure personal API keys for bidirectional interaction (e.g., syncing likes directly back to the native platform). A built-in WebView launcher in Settings allows completing Cloudflare challenges or interactive captchas when needed.
- **Confirmed Decision (Viewing Experience)**: Immersive edge-to-edge full-screen vertical swipe feed with single-tap pause/play, double-tap to like with haptic feedback, floating interactive right-side action rail (Like, Favorite, Comments & Tags, Share, Source), and swipe-to-read comic viewer.
- **Confirmed Decision (MalesOnly Filter)**: An instant toggle in the Sources panel that strips out posts/media containing male tags (e.g., `male`, `1boy`, `yaoi`, `bara`, `male/male`, etc.) across all platforms and content types.

---

## 1. Overview & Core Concept

**Yiffy** is designed as a lightweight, clean, and distraction-free media aggregator for Android. Inspired by Mihon's modular source architecture and TikTok's addictive, fluid gestures:
- **Unified Media Streams**: Seamless switching across **Videos**, **Pictures**, **Comics**, and **Miscellaneous** (social posts with author badges, text captions, and platform chips).
- **Multi-Source Ecosystem**: Integrates e621, Rule34, Pornhub, Bluesky, Reddit, Twitter/X, Myreadingmanga, and E-Hentai.
- **Two-Way Engagement**: When API keys are supplied (e.g. Bluesky AT Protocol, Reddit OAuth, e621 login/api_key), liking or favoriting in Yiffy automatically synchronizes the reaction to your external account.
- **Inspection & Comments**: Comments sheet with a fluid horizontal swipe transition into a categorized tags list (artist, character, copyright, general, meta) for booru-supported posts.
- **Local Privacy & Hidden Downloads**: Downloaded comics, videos, and images are saved to a configurable hidden directory (`.yiffy_media` by default) with an in-app browser segregated by platform and format.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Main Feed Discovery**:
   - The user opens the app directly into an edge-to-edge vertical pager.
   - Right-side action rail displays: Creator avatar / platform badge, Heart (Like count), Star (Favorite), Speech Bubble (Comments), Tag Chip (Tags preview), and Download button.
   - Swiping vertically switches smoothly to the next video or image. Tapping toggles controls and playback.
2. **Comments & Tags Drawer**:
   - Tapping the comment icon opens an expandable bottom sheet showing comments fetched from the platform's API.
   - Swiping left within the sheet transitions seamlessly into the **Tags Inspector**, displaying color-coded tags (e.g., Artist in amber, Character in teal, Copyright in purple, General in slate).
3. **Comics / Manga Reader**:
   - In the **Comics** bottom tab, users browse comic pools and manga galleries from Myreadingmanga, E-Hentai, and e621 Pools.
   - Tapping a title opens a gallery detail sheet with chapter lists and metadata.
   - Launching the reader switches to an uninterrupted horizontal/vertical reading pager with zoom, thumbnail scrub bar, and page jump.
4. **Profile & Library Management**:
   - Opening the Profile tab (accessible via the left bottom navigation or sidebar gesture) reveals a TikTok-inspired layout: customizable banner, circular profile picture, and stats counter (**Favorites**, **Likes**, **Comments**).
   - Below the header, interactive tab sliders partition user media:
     - **Favorites**: Segmented by platform dropdown.
     - **Likes**: Chronological liked posts.
     - **Comments**: History of posted comments.
     - **Downloaded**: All offline comics, videos, and pictures with filter dropdowns (format and platform).
   - Clicking active tab icons reveals a filter popup to change media format (All, Videos, Pictures, Comics, Misc) and platform source.
5. **Settings & Verification**:
   - Top-right gear icon in the Profile tab opens Settings:
     - **Google Account Sync**: Connect Google Account, trigger sync or view last synced timestamp for the 4 Drive documents.
     - **API Key Vault**: Config fields for Bluesky, Reddit, Twitter/X, e621 (Username + API Key), Rule34.
     - **Interactive Webview / Captcha Solver**: Launch an embedded browser to resolve Cloudflare / hCaptcha sessions for protected domains.
     - **Sources & Content Filter**: Source toggles, default search tags, and the global **MalesOnly** modifier switch.
     - **Display & Storage**: UI scaling slider (0.85x to 1.15x), download path picker.

### Visual Identity & Theme

- **Aesthetic Direction**: Stealth Dark Minimalist. High-contrast typography over deep obsidian surfaces (`#0D0E12` and `#14161D`) with subtle neon coral/violet accents (`#FF4081` / `#7C4DFF`).
- **Layout Rhythm**: Strict 48dp interactive touch targets, pill-shaped source chips, translucent blurred floating chrome (`Modifier.blur` / dark glassmorphism), and zero-friction gesture navigation.
- **Typography**: Clean, geometric sans typography with tabular numerals for like counters, timestamps, and page indices.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Modular Source Client Architecture**
  - *Approach*: Implement a clean `SourceClient` interface with distinct drivers for Boorus (e621, Rule34), Social feeds (Reddit JSON, Bluesky ATProto), and Manga/Comic engines (E-Hentai, Myreadingmanga).
  - *Rationale*: Isolates rate limits, tag schemas, and API authentication variations, allowing the app to degrade gracefully into public scraping/APIs when keys are missing.
- **Decision 2: Google Drive Text File Synchronization**
  - *Approach*: Use Android Credential Manager / Google Drive REST API integration to identify or create an application folder named `Yiffy_Sync` and maintain the 4 specified text documents (`History.txt`, `Algorithm_keeping.txt`, `Liked_posts.txt`, `Favorite_posts.txt`).
  - *Rationale*: Completely fulfills the requirement for user-accessible plaintext files on Google Drive while keeping local copies in Room for offline responsiveness.
- **Decision 3: Recommendation Algorithm & Feedback Loop**
  - *Approach*: A lightweight on-device tag scoring engine that logs tag interactions into `Algorithm_keeping.txt`. Positive signals (watch time > 80%, like, favorite) boost tag affinity scores; skips (< 2s) decay scores.
  - *Rationale*: Allows smart personalized feed ranking without requiring heavy server infrastructure or privacy intrusions.
- **Decision 4: Hidden Storage & Download Manager**
  - *Approach*: App-scoped or user-specified directory with `.downloads` prefix (e.g. `/Android/data/com.example/files/.yiffy_media/`) to keep saved media hidden from standard device galleries unless exported.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                 UI Layer                                    │
│ ┌──────────────┬──────────────┬──────────────┬──────────────┬─────────────┐ │
│ │ Videos Feed  │ Pictures Feed│  Comics Feed │  Misc Feed   │ Profile View│ │
│ │(Vertical Pager│ (Grid/Pager) │ (Reader & Pool│ (Card Stream)│(Tabs, Stats,│ │
│ │+ Action Rail)│+ Source Add) │ + Mihon Style│ + Badges)    │ Downloads)  │ │
│ └───────┬──────┴──────┬───────┴──────┬───────┴──────┬───────┴──────┬──────┘ │
│         │             │              │              │              │        │
│         └─────────────┼──────────────┼──────────────┘              │        │
│                       ▼              ▼                             ▼        │
│           ┌─────────────────────────────────────┐      ┌──────────────────┐ │
│           │            FeedViewModel            │      │ ProfileViewModel │ │
│           └──────────────────┬──────────────────┘      └────────┬─────────┘ │
└──────────────────────────────┼──────────────────────────────────┼───────────┘
                               │                                  │
┌──────────────────────────────▼──────────────────────────────────▼───────────┐
│                              Domain / Repository Layer                      │
│ ┌───────────────────────────┐ ┌──────────────────────┐ ┌──────────────────┐ │
│ │     MediaRepository       │ │  SyncRepository      │ │DownloadRepository│ │
│ │ (Aggregates Feed Sources) │ │ (Google Drive 4-Docs)│ │ (Hidden Files)   │ │
│ └─────────────┬─────────────┘ └──────────┬───────────┘ └────────┬─────────┘ │
└───────────────┼──────────────────────────┼──────────────────────┼───────────┘
                │                          │                      │
┌───────────────▼──────────────────────────▼──────────────────────▼───────────┐
│                              Data & Network Layer                           │
│ ┌──────────────────────────────────────────────┐ ┌────────────────────────┐ │
│ │             Source Client Engine             │ │    Local Persistence   │ │
│ │ ├─ E621Client        ├─ RedditClient         │ │ ├─ Room Database       │ │
│ │ ├─ Rule34Client      ├─ BlueskyClient        │ │ ├─ DataStore (Prefs/   │ │
│ │ ├─ PornhubClient     ├─ TwitterClient        │ │ │   API Keys/Settings) │ │
│ │ ├─ MyReadingManga    ├─ EHentaiClient        │ │ └─ Hidden File Storage │ │
│ └──────────────────────┬───────────────────────┘ └────────────────────────┘ │
│                        ▼                                                    │
│ ┌──────────────────────────────────────────────┐                            │
│ │      Google Drive API & In-App Captcha       │                            │
│ └──────────────────────────────────────────────┘                            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Data Entities & Schema

- **MediaItem**: `id`, `source` (E621, RULE34, REDDIT, BLUESKY, TWITTER, PORNHUB, EHENTAI, MYREADINGMANGA), `type` (VIDEO, PICTURE, COMIC_SERIES, MISC), `title`, `author`, `mediaUrl`, `previewUrl`, `caption`, `tags: List<String>`, `likesCount`, `commentsCount`, `isLiked`, `isFavorited`, `timestamp`.
- **ComicGallery**: `id`, `source`, `title`, `coverUrl`, `author`, `pagesCount`, `pages: List<String>`, `tags: List<String>`.
- **CommentItem**: `id`, `author`, `authorAvatar`, `content`, `createdAt`, `likes`.
- **SyncDocumentState**:
  - `historyDoc`: Queue of last 100 media items formatted as timestamped log lines.
  - `algorithmDoc`: Tag weight vector `{ tag: score }` serialized as readable text.
  - `likedDoc`: List of liked items with ID, source, title, URL.
  - `favoritesDoc`: Grouped sections `[PORNHUB]`, `[E621]`, `[REDDIT]`, etc., listing user favorites.

### Interactive Component & State Mapping

- **Feed Navigation & Pager**: Handled via `VerticalPager` with snap fling behavior, preloading adjacent media for zero latency.
- **Comments & Tags Swipe Transition**: Bottom sheet holding a `HorizontalPager(pageCount = 2)`:
  - Page 0: Comments list + text input box.
  - Page 1: Tag chips categorized by type with search filter.
- **Comic Reader**: Supports `HorizontalPager` or continuous vertical scroll with pinch-to-zoom and double-tap toggle overlay.
- **Download Manager**: Background coroutine downloader storing bytes into user-configured hidden paths (e.g., `Context.filesDir / .downloads`) with notification and library indexing.
- **Captcha Solver**: Dialog launching an Android `WebView` pointing to the target challenge URL so cookies and clearance tokens can be acquired for Cloudflare-protected endpoints.
