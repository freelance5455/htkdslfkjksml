# 7-Day Survival, Predator Hazards & Bird Rescue Expansion

This update introduces a structured **7-Day Campaign** to the neighborhood, adding prowling **Alley Cats**, soaring **Sky Eagles**, **Human Bait Traps**, and **Captive Songbird Rescues** that escalate in challenge across seven days.

## User Review & Critical Decisions

> [!IMPORTANT]
> Because the clarifying questions were skipped, the plan uses the recommended defaults below so the game remains playful, fair, and rewarding across all 7 days.

- **Capture & Recovery (Confirmed Default)**: Getting caught by a cat pounce, eagle stoop, or bait trap triggers a brief feather-burst capture vignette and respawns the sparrow at the Sky Sanctuary Nest (or Atelier window sill early on). Each day grants **3 Feather Hearts**; losing all 3 hearts restarts the current day without losing progress from earlier days.
- **7-Day Progression & Victory (Confirmed Default)**: The game tracks **Day 1 through Day 7** alongside the live Day/Night clock. Each day spawns trapped neighborhood birds to rescue and escalates predator activity. Freeing a day's captive birds (or surviving through nightfall into dawn) advances to the next day, culminating in a **Day 7 Grand Sanctuary Celebration**.
- **Human Traps & Bird Interaction (Confirmed Default)**: Human trappers place baited spring-cages around plazas and rooftops. Stepping on the interior bait pad snaps the trap shut, whereas perching beside the cage and pecking (`F`) the outer brass latch springs the door open and frees the trapped songbird to join your flock.

---

## 1. Overview & Core Concept

- **What It Does**: Transforms the sandbox neighborhood into a lively 7-day adventure where the sparrow must outsmart ground predators (Cats), aerial predators (Eagles), and human snares (Bait Traps) while rescuing captured companion birds and completing mischief deeds.
- **Target Audience / Persona**: Players who enjoy expressive 3D animal adventure games with tactile flight evasion, stealthy ground mischief, and clear day-by-day progression.
- **Key Value**: Adds tension, altitude-based risk/reward (ground vs. canopy vs. high sky), and a clear 7-day goal arc without sacrificing the cozy storybook charm.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Daily Dawn Briefing**: At the start of each day (`Day 1`–`Day 7`), a French-postcard banner announces the current day, active predator threats, and how many captive birds need rescue.
  2. **Evading Prowling Cats (Ground Hazard)**: Ginger and tuxedo alley cats patrol bistro tables, alleys, and park hedges. When the sparrow hops nearby on the ground, the cat flattens into a stalk pose with an amber warning indicator before pouncing; taking flight or perching high keeps you safe.
  3. **Outflying Sky Eagles (High-Altitude Hazard)**: Golden eagles circle high above the rooftops casting a visible shadow ring below. If the sparrow flies exposed at high altitude for too long, the eagle cries out and dives; barrel-rolling (`Shift`), diving under café awnings, or ducking into tree canopies breaks the pursuit.
  4. **Disarming Human Traps & Rescuing Birds**: Trappers patrol near baited wooden-and-brass cages containing fluttering songbirds. Pecking (`F`) the external release latch frees the bird in a celebratory burst of feathers and music, whereas hopping onto the interior bait plate triggers the snare.
  5. **Day Completion & Day 7 Finale**: Completing the daily rescue quota or surviving until dawn advances the calendar (`Day 1/7` → `Day 7/7`), unlocking a celebratory flock parade on Day 7.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Hand-crafted European gouache storybook illustration with expressive cel-shaded silhouettes and readable telegraphing cues.
  - *Color Palette & Mood*: Warm amber warning glints (`#F59E0B`), crimson danger rings (`#DC2626`) on active trap plates and eagle dive locks, and emerald rescue bursts (`#10B981`) against the parchment HUD (`#FBF5E8`).
  - *Typography & Hierarchy*: Editorial serif headers for Day banners (`Day 1 of 7`) paired with crisp `tabular-nums` counters for Feather Hearts and Rescued Birds in the top HUD bar.
  - *Component Styling & Layout*: Compact top-left status bar additions (Day counter, Feather Hearts, and Rescue tally) plus a clean threat-proximity indicator and end-of-day summary toast that never obstruct the central 3D viewport.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Telegraphed Predator State Machines over Instant Hits**
  - *Chosen Approach*: Both the Cat and the Eagle use a 3-stage behavioral state machine (`Patrol` → `Alert / Wind-up` → `Strike / Cooldown`) with unmistakable audio-visual cues (cat hiss + crouch wiggle; eagle screech + shadow ring).
  - *Why*: Gives the player a fair ~1.2-second reaction window to flap away, dive under cover, or barrel-roll.
  - *Alternatives Considered*: Instant collision capture on contact, which feels unfair in a 3D third-person flight game.
- **Decision 2: Dual-Zone Bait Traps (Danger Inside vs. Disarm Outside)**
  - *Chosen Approach*: Bait cages separate the interior bait trigger zone (which snaps shut on the player) from the exterior latch perch (where pecking `F` safely springs the door open and rescues the captive bird).
  - *Why*: Rewards observant positioning and integrates naturally with the existing peck (`F`) and perch mechanics.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       7-Day Campaign & Director                         │
│  ┌───────────────────┐   ┌────────────────────┐   ┌──────────────────┐  │
│  │ Day 1..7 Calendar │──▶│ Daily Threat Quota │──▶│ Day / Victory UI │  │
│  │ & 3-Heart Stamina │   │ & Bird Rescue Goal │   │ Banner & HUD Bar │  │
│  └─────────┬─────────┘   └─────────┬──────────┘   └──────────────────┘  │
└────────────┼───────────────────────┼────────────────────────────────────┘
             │                       ▼
             │       ┌───────────────────────────────┐
             │       │   Predator & Hazard System    │
             │       └───────┬───────────────┬───────┘
             ▼               ▼               ▼
┌────────────────────┐ ┌───────────────────┐ ┌────────────────────────────┐
│ Prowling Alley Cat │ │ Soaring Sky Eagle │ │ Human Trapper & Bait Cages │
│  • Ground Patrol   │ │  • High Orbit     │ │  • Trapper NPC Patrol      │
│  • Crouch Wind-Up  │ │  • Dive Telegraph │ │  • Interior Snare Trigger  │
│  • Pounce Arc      │ │  • Cover Break    │ │  • Exterior Peck Release   │
└─────────┬──────────┘ └─────────┬─────────┘ └─────────────┬──────────────┘
          └──────────────────────┼─────────────────────────┘
                                 ▼
              ┌─────────────────────────────────────┐
              │   Player Sparrow & Audio/FX Engine  │
              │  • Evasion (Flap / Dive / Awning)   │
              │  • Capture Vignette & Nest Respawn  │
              │  • Rescued Companion Flock Join     │
              └─────────────────────────────────────┘
```

- **Data Model & State**:
  - **7-Day Campaign State**: Tracks `currentDay` (`1..7`), `featherHearts` (`1..3`), `rescuedToday` vs. `dailyRescueTarget`, and `campaignCompleted`.
  - **Alley Cat Entity**: Articulated 3D cat mesh (sculpted head, ears, arched back, articulated legs, and whipping tail) with states `'patrol' | 'stalk' | 'pounce' | 'cooldown'`.
  - **Sky Eagle Entity**: Sculpted broad-winged raptor mesh with states `'soar' | 'lock_on' | 'stoop' | 'recover'`, checking line-of-sight cover (indoors, under awnings, or inside tree canopies).
  - **Bait Trap Entity**: Mechanical wire-and-wood trap with hinged spring door, bait seed cluster, captive `SparrowMesh` bird, interior trigger radius, and exterior disarm latch perch.
- **Interactive Component & State Mapping**:
  - **Pecking a Trap Latch (`Key F`)**: Opens the cage door, plays a spring-release chime, increments `rescuedToday`, and transitions the captive bird into a free flying companion.
  - **Predator/Trap Capture**: Deducts 1 Feather Heart, plays a startled chirp + feather burst, and smoothly repositions the camera and sparrow to the safe perch; if `featherHearts === 0`, resets the current day's traps and hearts.
  - **Day Transition**: Crossing midnight/dawn or completing all rescues for the day advances `currentDay` up to Day 7, scaling active cats (`1 -> 3`), eagles (`1 -> 2`), and bait cages (`2 -> 4`).
