---
name: Aether Personal OS
colors:
  surface: '#13131a'
  surface-dim: '#13131a'
  surface-bright: '#393841'
  surface-container-lowest: '#0d0e15'
  surface-container-low: '#1b1b23'
  surface-container: '#1f1f27'
  surface-container-high: '#292932'
  surface-container-highest: '#34343d'
  on-surface: '#e4e1ec'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e4e1ec'
  inverse-on-surface: '#303038'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#cfbdff'
  on-secondary: '#371d76'
  secondary-container: '#4e368e'
  on-secondary-container: '#bfa8ff'
  tertiary: '#ffb869'
  on-tertiary: '#482900'
  tertiary-container: '#ca801e'
  on-tertiary-container: '#3f2300'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#e8ddff'
  secondary-fixed-dim: '#cfbdff'
  on-secondary-fixed: '#22005d'
  on-secondary-fixed-variant: '#4e368e'
  tertiary-fixed: '#ffdcbb'
  tertiary-fixed-dim: '#ffb869'
  on-tertiary-fixed: '#2c1700'
  on-tertiary-fixed-variant: '#673d00'
  background: '#13131a'
  on-background: '#e4e1ec'
  surface-variant: '#34343d'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system targets users invested in an intentional, high-performance personal Android computing ecosystem. The personality is focused, sophisticated, and kinetic—evoking the quiet precision of high-end consumer hardware and pro-grade mobile tooling.

The aesthetic fuses **Tactile Minimalism** with **Native Modern Android** design patterns. Instead of relying on simulated skeuomorphic textures, heavy drop shadows, or diffuse glass blurs, depth is expressed through calibrated tonal plateaus, hairline structural strokes, and tactile micro-interactions. Dynamic ripple feedbacks, deliberate compression on active states, and high-legibility typographic hierarchies establish an interface that feels fast, responsive, and engineered for single-handed mobile ergonomic flow.

## Colors

The palette is engineered exclusively for an OLED-first, dark-mode native Android environment. The deep space black background (`#0B0B0F`) conserves battery while providing an infinite depth plane that recedes behind active workspace components.

### Canvas & Surface Hierarchy
- **Base Background:** `#0B0B0F` — Root canvas layer behind scroll views and bottom sheets.
- **Surface Level 1 (Charcoal):** `#1A1A22` — Primary containers, system bars, app drawers, and main modular cards.
- **Surface Level 2 (Elevated):** `#252530` — Interactive tiles, floating cards, modal sheets, and active app controls.
- **Surface Level 3 (Highest State):** `#323240` — Hovered/focused cards, nested input containers, and active pill backgrounds.

### Accents & Indicators
- **Primary Accent (Electric Violet):** `#8B5CF6` — Used for hero actions, toggles, slider tracks, focused input outlines, and primary system status indications.
- **Secondary Accent (Soft Lavender):** `#B9A0FF` — Utilized for secondary action fills, subtle focus states, badges, and contextual metadata emphasis.
- **Border Subtle:** `rgba(255, 255, 255, 0.08)` — Precise hairline separator creating edge definition on charcoal containers without visual weight.

### Typography Colors
- **Primary Text:** `#F1F0F5` — 94% perceived luminance for high-readability body copy, titles, and numeric readouts.
- **Secondary Text:** `#8E8D9A` — Muted slate for metadata, disabled states, unselected icons, and secondary labels.

## Typography

The typographic hierarchy combines the approachable, structured geometry of **Plus Jakarta Sans** for prominent headers with the utilitarian clarity of **Inter** for dense interface data, inputs, and systemic controls.

### Implementation Directives
- **Tabular Figures:** Always apply `font-variant-numeric: tabular-nums` (or OpenType feature `'tnum' on`) across all metric cards, time indicators, timers, dynamic percentages, and battery indicators to ensure vertical alignment during value transitions.
- **Optical Kerning:** Large headlines use negative tracking (`-0.01em` to `-0.02em`) to maintain cohesion, while small uppercase labels feature positive letter spacing (`0.02em` to `0.04em`) to safeguard legibility against charcoal surface backgrounds.

## Layout & Spacing

The layout is built around an 8-point base grid tailored for mobile ergonomics and adaptive handheld scaling.

### Grid & Form Factors
- **Mobile Handheld (0 - 599dp):** Single column fluid container with a 4-column layout for widgets, a fixed canvas margin of `1rem` (16dp), and an inter-item gutter of `1rem` (16dp). Interactive touch targets conform to a minimum dimension of 48×48dp, placed primarily in the lower 60% of the display zone for easy one-thumb reach.
- **Foldables & Tablets (600 - 1023dp):** 8-column layout with split-pane capability, utilizing `1.5rem` gutters and `2rem` margins. Navigation switches from bottom bar to a vertical rail.
- **Large Format / DeX Mode (1024dp+):** 12-column structured grid centered within a maximum width of 1280dp, anchored by `3rem` canvas margins.

### Vertical Rhythm & Density
Layout gaps strictly adhere to the defined space tokens: micro-element gaps within controls use `space-xs` (4dp) and `space-sm` (8dp); component internal paddings use `space-md` (16dp); section separating block margins deploy `space-lg` (24dp) and `space-xl` (32dp).

## Elevation & Depth

Visual hierarchy is achieved via **Tonal Stacking** paired with crisp **Hairline Outlines**, strictly eliminating heavy drop shadows, colored ambient glows, and deep blurs.

### Surface Tiers & Architecture
1. **Baseplate (Level 0):** `#0B0B0F` — The root void. Zero elevation, no border.
2. **Structural Surfaces (Level 1):** `#1A1A22` — Dashboard cards, list sections, and persistent toolbars. Outlined with a 1px solid stroke of `rgba(255, 255, 255, 0.08)`.
3. **Elevated Overlays (Level 2):** `#252530` — Quick settings tiles, modals, floating action pills, and dropdown sheets. Outlined with 1px `rgba(255, 255, 255, 0.12)`. When separation from Level 1 is required, apply a crisp, ultra-subtle contact shadow: `box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4)`.
4. **Focused / Pressed (Level 3):** `#323240` — Transient layer for pressed item feedback and active selections.

### Border Rules
Borders must remain exactly 1 physical CSS pixel (or 1dp in Android vector drawables). Avoid gradient borders or high-contrast white borders; edge highlights should feel like machined metal facets catching ambient light.

## Shapes

The design system maintains a coherent, dual-tier geometric logic: **Soft Rounded Rectangles** for grouping content and **True Pills / Circles** for actions, indicators, and toggles.

### Geometric Rules
- **Container Surfaces & Cards:** Implement 1rem (16dp, matching `rounded-2xl` scale) corner radii across all cards, list clusters, and bottom sheets to evoke an ergonomic, handheld device feel.
- **Interactive Controls & Keycaps:** Quick-action keys, notification chips, and text inputs utilize 1rem (16dp) radius.
- **Pills & Circles (`rounded-full`):** Toggles, icon-only utility triggers, avatar frames, status badges, and primary pill buttons use continuous full-radius curves (`9999px`).

## Components

### Buttons
- **Primary:** Filled `#8B5CF6` with `#F1F0F5` bold typography. Height is 48dp, border radius is `rounded-full` or `rounded-2xl` depending on density. Active state triggers a physical scale compression (`scale(0.97)`) and shifts fill to `#7C3AED`.
- **Secondary / Tonal:** Filled `#252530` with a 1px border of `rgba(255, 255, 255, 0.08)`. Text is `#F1F0F5`.
- **Ghost:** Transparent background with `#B9A0FF` text. Active state renders a subtle `#252530` tint.

### Cards & Modules
- Single flat containers wrapped in Level 1 surface (`#1A1A22`) with hairline border (`rgba(255, 255, 255, 0.08)`), padding of `space-md` (16dp), and `rounded-2xl` corners.
- Interactive cards elevate to `#252530` on hover/touch, accompanied by a scale transition of 100ms ease-out.

### Input Fields
- Background is `#1A1A22` with a 1px border of `rgba(255, 255, 255, 0.08)`. Height is 52dp with `space-md` internal padding. Text is `#F1F0F5`.
- Focus state highlights the border with `#8B5CF6` (1.5px thickness) without external glows. Placeholder text rests at `#8E8D9A`.

### Chips & Filters
- Compact 32dp height, `rounded-full` contour, background `#252530`.
- Selected state adopts `#8B5CF6` background with high-contrast `#F1F0F5` typography, or an outlined active style using `#8B5CF6` border with `#B9A0FF` text.

### Checkboxes, Switches & Radio Controls
- **Switches:** 52×32dp track using `#252530` when inactive and `#8B5CF6` when active. 24dp circular thumb (`#F1F0F5`) with immediate haptic-style transition timing.
- **Checkboxes & Radios:** Hairline bordered `#252530` base expanding into `#8B5CF6` with crisp white checkmark vector icons on selection.

### Ecosystem Widgets & Indicators
- **Quick Settings Modular Tiles:** 2-column wide, 72dp high `#252530` rounded rectangles containing tabular status metrics and clean 20dp outline icons (stroke weight: 1.75dp).
- **Metric Badges:** Monospace/tabular numerical readouts embedded in `#1A1A22` capsules with a trailing dot indicator lit by `#8B5CF6`.