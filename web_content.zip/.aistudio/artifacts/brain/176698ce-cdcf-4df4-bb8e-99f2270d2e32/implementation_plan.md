# Apple TV Inspired Android TV Launcher (AuraTV)

A lightweight, high-performance Android TV launcher inspired by Apple TV tvOS, featuring a dynamic Top Shelf banner, fluid spatial D-pad focus navigation, tile customization, and instant deep linking to third-party streaming services optimized for low-end hardware.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during clarification and govern the architecture of the launcher:

- **Top Shelf Presentation**: Dynamic Top Shelf banner showcasing cinematic media backdrops, trailer/poster art, metadata, and quick-action play controls that dynamically update as tiles are highlighted.
- **Navigation & Control Engine**: Dual 10-foot TV remote D-pad controller (keyboard arrow keys, Enter, Back, Menu, plus an on-screen interactive floating Apple TV-style Siri Remote simulator) and smooth pointer/touch support.
- **Streaming & Deep Linking**: Curated streaming catalog (Netflix, YouTube, Prime Video, Disney+, Apple TV+, Plex, Spotify, Twitch, SmartTube, Kodi, Stremio) with direct Android intent schemas (`android-app://`, `intent://`, custom schemes), web fallbacks, and a full custom tile editor.
- **Hardware Optimization**: Low-end hardware performance mode with GPU-accelerated CSS transforms (`translate3d`), synthetic Web Audio navigation sounds (0ms latency, zero audio asset downloads), and an optional Low-Spec Performance Mode (disables heavy backdrop blurs).

---

## 1. Overview & Core Concept

**AuraTV** is a responsive, lightweight 10-foot TV launcher that brings the fluid, clutter-free elegance of Apple TV tvOS to Android TV and smart television boxes.

- **What It Does**: Serves as a full-featured television home screen providing smooth spatial tile navigation, dynamic backdrop crossfades, deep link execution into Android streaming apps, tile customization (add/edit/delete/reorder), and a system status overlay (time, Wi-Fi, audio output, settings).
- **Target Persona & Context**: Android TV, Google TV, FireTV, and low-spec TV box users who find stock interfaces cluttered with sponsored ads and sluggish on 1GB/2GB RAM hardware.
- **Key Value**: Instant 60 FPS spatial navigation, zero bloatware/ad clutter, authentic Apple TV glassmorphic aesthetics, and reliable deep linking directly into media content.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Spatial Navigation & Dynamic Top Shelf**:
   - The user browses app tiles using arrow keys or the on-screen virtual remote.
   - Hovering or navigating onto any tile (e.g. Netflix, YouTube, Apple TV+) instantly triggers a smooth crossfade of the Top Shelf showcase banner with the app's spotlight cinematic media, synopsis, genre tags, and a "Resume / Open" action.
   - Focused tiles scale smoothly with an authentic tvOS specular reflection rim and soft drop shadow.

2. **Deep-Link Launching & Android Package Routing**:
   - Pressing `Enter` / `OK` triggers a TV launch animation.
   - The deep-link engine executes the configured Android intent schema or web fallback with parameters (e.g. launching YouTube to a specific video ID or Netflix to a title).
   - An interactive "Launch Inspector" shows Android intent details, package names, and fallback options.

3. **Tile Customization & Reordering**:
   - Long-press `Enter` or click "Customize" enters tvOS "Wiggle / Edit Mode".
   - Tiles can be moved left/right/up/down across rows, hidden, or edited.
   - A modal lets users add custom apps (specifying title, icon, color, Android package name, deep link URL, and category).

4. **10-Foot Remote Simulator & Hardware Mapping**:
   - Fully controllable via hardware keyboard (`ArrowUp`, `ArrowDown`, `ArrowLeft`, `ArrowRight`, `Enter`, `Escape`/`Backspace` for Back, `M` or `Home` for Menu).
   - Includes a collapsible floating Apple TV-style aluminum remote with clickpad, volume rocker, back, play/pause, and power buttons for desktop/touch testing.

5. **Settings & Low-End Hardware Tuning**:
   - Settings drawer with toggles for:
     - **Low-End Hardware Mode**: Replaces real-time backdrop blur filters with flat translucent dark scrims for stutter-free 60 FPS on low-power quad-core chips.
     - **Synthetic UI Sound Effects**: tvOS-style clicks and pops generated on-the-fly via Web Audio API.
     - **Grid Density**: 4, 5, or 6 columns per row.
     - **Wallpaper Theme**: Dynamic App Backdrop, Deep Space, Midnight Navy, or Pure OLED Black.

### Visual Identity & Theme

- **Aesthetic Direction**: Apple tvOS minimalist glassmorphism with high contrast typography and clean layout spacing.
- **Color Palette & Tokens**:
  - Dominant Canvas: Deep Midnight Slate (`#0a0d14` / `#05070a`) with 4.5:1+ contrast against light text.
  - Surface Glass: Translucent white overlays (`rgba(255, 255, 255, 0.08)` to `0.18`) with crisp 1px hairline borders (`rgba(255, 255, 255, 0.14)`).
  - Focus Ring: High-visibility specular white glow with scale transform (`scale(1.08)`).
  - Accent Color: Apple electric blue (`#0071e3`) and translucent frosted highlights.
- **Typography**: Clean neo-grotesque sans (`system-ui`, `-apple-system`, `Outfit` / `Inter` fallback) with generous letter spacing, bold title weights, and balanced headlines.
- **Zero-Pill Discipline**: Metadata (ratings, release years, audio codecs like 4K HDR, Dolby Atmos) rendered as crisp text with subtle `·` separators, avoiding cluttered pill chips.

---

## 3. Key Product Decisions & Trade-Offs

- **Synthetic Web Audio Navigation Sound Effects**:
  - *Chosen Approach*: Lightweight Web Audio oscillator generating 8ms subtle click/pop bursts on focus change.
  - *Why*: Instant zero-latency audio feedback without downloading external MP3/WAV assets or consuming memory on low-end devices.
  - *Alternative Considered*: External audio files (rejected due to loading delays and potential memory churn).

- **Hardware-Accelerated Focus Engine with CSS Compositor**:
  - *Chosen Approach*: Pure CSS transforms (`translate3d`, `scale3d`) and `will-change: transform` with active index tracking in React.
  - *Why*: Keeps CPU usage below 5% and avoids layout reflows (`width`/`height` thrashing), guaranteeing smooth 60 FPS even on cheap Android TV HDMI sticks.

- **Multi-Level Deep Linking Architecture**:
  - *Chosen Approach*: Support Android package intents (`intent://...#Intent;package=...;end`), direct URI schemes (`netflix://`, `vnd.youtube://`), and graceful web URLs.
  - *Why*: Ensures the launcher works seamlessly whether running in an embedded Android WebView / TV shell or in a browser test environment.

- **Local Storage Persistence**:
  - *Chosen Approach*: Browser `localStorage` for tiles, order, custom apps, and user settings.
  - *Why*: Zero network latency on boot, completely private, works offline, and preserves custom launcher layouts across restarts.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       AuraTV Android TV Launcher                        │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │ Status Bar: Time · Wi-Fi · Audio · Search Trigger · Settings Icon │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │ Dynamic Top Shelf Showcase (Cinematic Backdrop, Synopsis, Actions)│  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │ Category Filter Bar: All · Favorites · Streaming · Video · Audio  │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │ Interactive App Grid (Spatial D-Pad Navigation & tvOS Scale Tilt) │  │
│  │                                                                   │  │
│  │  [ Netflix ]  [ YouTube ]  [ Prime Video ]  [ Disney+ ]  [ Plex ] │  │
│  │  [ Apple TV ] [ Spotify ]  [ Twitch ]      [ SmartTube]  [ +Add ] │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │
           ┌─────────────────────────┴────────────────────────┐
           ▼                                                  ▼
┌──────────────────────────────┐          ┌──────────────────────────────┐
│  Spatial D-Pad Focus Engine  │          │    Interactive TV Remote     │
│  - Arrow Keys / Gamepad      │          │    - On-screen D-Pad clickpad│
│  - Web Audio Synthetic Sound │          │    - Back, Home, Menu, Play  │
│  - Auto-Scroll Into View     │          │    - Collapsible / Draggable │
└──────────────┬───────────────┘          └──────────────┬───────────────┘
               │                                         │
               ▼                                         ▼
┌────────────────────────────────────────────────────────────────────────┐
│  Deep Link & App Management Engine                                     │
│  - Intent URI builder (Android TV package intents)                     │
│  - Custom App Tile Creator & Reorder Mode                              │
│  - Performance Mode (High FPS / Low-Spec blur disable)                 │
│  - LocalStorage State Manager                                          │
└────────────────────────────────────────────────────────────────────────┘
```

### Component Hierarchy

- `App.tsx`: Main launcher coordinator, state provider, and global keydown listener.
- `components/TopShelf.tsx`: Apple TV cinematic hero showcase with backdrop crossfade, title, rating, overview, and quick-launch CTA.
- `components/AppGrid.tsx`: Responsive grid with rows, focus management, scale/tilt effects, and reorder controls.
- `components/AppTile.tsx`: Individual tvOS tile with icon, title, focus ring, specular gloss, and custom context menu.
- `components/VirtualRemote.tsx`: Floating Apple TV Siri-style remote with tactile clickpad, buttons, and keyboard shortcut guides.
- `components/DeepLinkModal.tsx`: Launch dialog showing intent schemas, direct launch actions, and package parameters.
- `components/TileEditorModal.tsx`: Form to add or edit custom streaming apps and Android packages.
- `components/SettingsDrawer.tsx`: Configuration for performance mode, audio feedback, grid density, and themes.
- `services/soundService.ts`: Zero-dependency Web Audio API synthesizer for realistic navigation audio.
- `services/catalogData.ts`: Default curated streaming apps with verified icons, package names, deep links, and showcase media.

### Implementation Next Steps (Upon Approval)

1. Set application metadata in `metadata.json` and sync `index.html`.
2. Implement `soundService.ts` for synthetic audio feedback.
3. Build `catalogData.ts` with rich streaming services, intent schemes, and backdrop media.
4. Implement the Spatial D-Pad focus engine and keyboard listener.
5. Build the Dynamic `TopShelf` showcase with smooth backdrop crossfading.
6. Build the `AppGrid` and `AppTile` components with tvOS focus physics and reorder support.
7. Build the `VirtualRemote` controller and deep linking modals.
8. Verify compilation and test 60 FPS performance.
