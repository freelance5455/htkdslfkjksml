# JARVIS Adaptive Themes Mode

Adds an automatic time-of-day **Adaptive Themes** system to JARVIS that smoothly transitions both accent colors and day/night HUD luminance across a 4-phase solar schedule, with full Settings and voice control.

## User Review & Critical Decisions

> [!IMPORTANT]
> All Adaptive Themes behaviors were confirmed during discovery and are incorporated below.

- **Confirmed Decision 1 (4-Phase Cycle & Luminance)**:
  - **Dawn (`05:00 – 08:59`)**: `Gold` accents with balanced early-morning glow.
  - **Day (`09:00 – 16:59`)**: `Cyan` accents with brighter, high-clarity daytime highlights and panel contrast.
  - **Dusk (`17:00 – 20:59`)**: `Blue` accents with twilight navy depth.
  - **Night (`21:00 – 04:59`)**: `Deep Violet` accents paired with darker background tones, deeper panel opacity, and reduced night glare.
- **Confirmed Decision 2 (Default State & Voice Control)**: Enabled by default on launch, with an interactive toggle in Settings and voice command support (`enable` / `disable` Adaptive Themes).
- **Confirmed Decision 3 (Manual Override Behavior)**: Picking any manual color swatch in Settings or requesting a specific color theme by voice automatically pauses/disables Adaptive Themes so the manual selection stays active.

---

## 1. Overview & Core Concept

- **What It Does**: Dynamically aligns JARVIS's visual atmosphere—CSS color tokens, HUD panel backdrop contrast, ambient grid glow, and the Three.js/Canvas 2D holographic orb—to the user's local clock without manual intervention.
- **Target Audience & Context**: Improves eye comfort in dark rooms at night (darker violet-navy surfaces and softer bloom) while keeping daytime visibility crisp (brighter cyan highlights).
- **Key Value**: Seamless ambient personalization that respects explicit user overrides at any moment.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Automatic Launch & Live Phase Rotation**: On boot and on every minute tick, JARVIS evaluates the current local hour (`0–23`), determines the active phase (`DAWN`, `DAY`, `DUSK`, `NIGHT`), applies the corresponding theme and luminance posture (`day` vs `night` tone), and keeps the 3D orb and HUD synchronized.
2. **Manual Theme Pause**: Opening Settings and tapping any of the 6 color swatches—or speaking a command such as *"Switch theme to red"*—immediately switches to that theme and turns `Adaptive Themes` off with clear status feedback.
3. **Re-Enabling via Settings or Voice**: Users can re-enable Adaptive Themes from the Settings toggle (which also shows the active phase badge, e.g., `Day · Cyan` or `Night · Violet`) or by speaking *"Turn on adaptive theme"*.

### Visual Identity & Theme

- **Luminance Posture (`data-luminance="day" | "night" | "dawn" | "dusk"`)**:
  - **Daytime (`DAY` & `DAWN`)**: Brighter accent saturation, higher border/grid visibility, and energized orb glow (`--bg-0` to `--bg-2` lifted slightly for crisp daylight readability).
  - **Nighttime (`NIGHT`)**: Deeper obsidian-navy backgrounds (`#02050d`–`#050a18`), dimmer ambient gridlines, softer orb bloom intensity, and darker glass panels for comfortable low-light viewing.
- **Smooth Transitions**: CSS transitions on `body`, `.chamfer-panel`, and `.hud-backdrop` blend background gradients, border luminescence, and text shadows smoothly across phase boundaries, while `OrbRenderer` interpolates shader/ring colors.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Separate `data-luminance` Attribute Alongside `data-theme`**
  - *Chosen Approach*: Keep the existing 6 color themes (`blue`, `cyan`, `red`, `violet`, `green`, `gold`) intact while introducing a complementary `data-luminance` posture (`dawn`, `day`, `dusk`, `night`) controlled by the time-of-day scheduler (or defaulting to balanced night/standard when Adaptive Themes is paused).
  - *Why*: Preserves all existing color themes cleanly and allows Night mode (`Deep Violet`) to genuinely darken backgrounds and tame glow without breaking manual theme swatches.
  - *Alternatives Considered*: Creating separate hardcoded duplicate themes (`cyan-day`, `violet-night`), which would clutter the 6-swatch palette.

- **Decision 2: Minute-Aligned Timer + Immediate Re-Evaluation on Resume**
  - *Chosen Approach*: Check the time phase inside the existing clock tick and on `visibilitychange` when returning to the app/tab, only mutating DOM/WebGL state when the calculated phase actually changes.
  - *Why*: Zero unnecessary DOM repaints or shader uniform churn every second while remaining instant across sleep/wake and timezone changes.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌──────────────────────────────────────────────────────────────────────┐
│                   Storage (localStorage settings)                    │
│     adaptiveTheme: true (default)  |  theme: 'blue' (manual fallback)│
└───────────────────────────────┬──────────────────────────────────────┘
                                │
             ┌──────────────────▼──────────────────┐
             │      AdaptiveThemeScheduler         │
             │  05–08 Dawn (Gold)  | 09–16 Day(Cyan)│
             │  17–20 Dusk (Blue)  | 21–04 Night(Violet)
             └──────────┬───────────────┬──────────┘
                        │               │
       ┌────────────────▼───┐       ┌───▼─────────────────┐
       │     HudPanels      │       │     OrbRenderer     │
       │  • data-theme      │       │  • Plasma shader    │
       │  • data-luminance  │       │  • Ring & bloom     │
       │  • Settings toggle │       │    intensity scale  │
       └────────▲───────────┘       └─────────────────────┘
                │
       ┌────────┴───────────┐
       │   CommandRouter    │
       │  • set_adaptive_theme
       │  • set_theme (pauses adaptive)
       └────────────────────┘
```

### Data Model & State

- **`Storage.settings` Addition**:
  - `adaptiveTheme` (`boolean`, default `true`): Controls whether the time-of-day scheduler drives the active `theme` and `luminance` posture.
- **Phase Mapping**:
  - `5 <= h < 9` → `{ phase: 'Dawn', theme: 'gold', luminance: 'dawn' }`
  - `9 <= h < 17` → `{ phase: 'Day', theme: 'cyan', luminance: 'day' }`
  - `17 <= h < 21` → `{ phase: 'Dusk', theme: 'blue', luminance: 'dusk' }`
  - Otherwise (`21..23, 0..4`) → `{ phase: 'Night', theme: 'violet', luminance: 'night' }`

### Interactive Component & State Mapping

- **Settings Modal (`HudPanels.openSettingsModal`)**: Adds an **Adaptive Themes (Time-of-Day)** toggle with a live phase pill (e.g., `Active: Day · Cyan` or `Paused (Manual)`). Toggling it ON immediately applies the current time-of-day phase; clicking any manual color swatch sets `adaptiveTheme = false` and applies that swatch.
- **Voice Command Integration (`CommandRouter`)**: Adds `set_adaptive_theme` (`{ enabled: boolean }`) for spoken commands (e.g., *"Enable adaptive themes"*, *"Turn off auto theme"*), and updates `set_theme` so spoken manual theme changes also set `adaptiveTheme = false` and confirm aloud.
- **Android Asset Sync**: Mirrors the updated `index.html` into the Android app's bundled assets and verifies compilation.
