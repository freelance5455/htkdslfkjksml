# Galaxy My Files AI

A native Android file manager built with Kotlin and Jetpack Compose that faithfully captures the tactile ergonomics and layout clarity of Samsung Galaxy's One UI "My Files", enhanced with real on-device file operations, USB OTG hardware detection, ZIP archiving, and multimodal Gemini AI tools for smart search, image editing, and video editing.

## User Review & Critical Decisions

> [!IMPORTANT]
> Below are the architectural decisions confirmed from our planning interview, along with the Firebase AI Logic provisioning step that will run immediately after you approve this plan.

- **Confirmed Decision 1 — Native Kotlin & Jetpack Compose**: Built directly as a native Android APK with Material 3 One UI styling, adaptivephone/tablet two-pane support, and direct Android OS integrations rather than a web wrapper.
- **Confirmed Decision 2 — Strict Device Storage & SAF Folders Only**: Operates strictly on real device storage (app-scoped Internal Workspace, user-granted Storage Access Framework directory trees with persisted URI permissions, MediaStore category queries, and physical USB OTG volumes) with zero fake/mock file trees.
- **Confirmed Decision 3 — Full Gemini AI Suite**: Includes Natural-Language Smart Search, AI Image Studio (prompt-based image editing, background removal, and AI enhancement via `gemini-nano-banana-2.1`), and AI Video Studio (real trim/mute/speed/text overlay export paired with `gemini-3.8-flash` multimodal captions, summaries, scene highlights, and edit suggestions).
- **Upcoming Provisioning Gate (Firebase AI Logic)**: Upon plan approval, we will prompt you once to accept Firebase setup for `ai_logic` so Gemini API calls authenticate securely via Firebase App Check without hardcoding client API keys.

---

## 1. Overview & Core Concept

- **What It Does**: Provides a unified command center to browse, organize, preview, compress, inspect, capture, and AI-transform files across internal workspace storage, user-granted SAF directories (such as `Downloads`, `Documents`, `DCIM`), and connected USB/OTG drives.
- **Target Audience / Persona**: Mobile power users and creators who want Samsung One UI's thumb-friendly reachability—collapsing headers, large rounded surface cards, decimal GB/MB storage telemetry, and rich multi-select actions—combined with built-in AI media editing and natural-language file discovery.
- **Key Value**: Eliminates app-switching by combining authentic file system management (copy/move conflict resolution, recycle bin with 30-day auto-purge, ZIP compression/extraction, APK package & double-extension security inspection) with direct CameraX capture and Gemini multimodal intelligence.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **First-Run Onboarding & Permissions**: Clear, transparent permission cards explaining Folder/SAF access (`OpenDocumentTree`), Camera (`CAMERA`), Microphone (`RECORD_AUDIO` for video capture), Notifications (`POST_NOTIFICATIONS` for background copy/export status), and USB OTG hardware access—with graceful denial states and a dedicated Settings > Permissions dashboard to re-request or manage granted SAF roots at any time.
2. **One UI Home Dashboard**:
   - Collapsing large-title header ("My Files") shifting smoothly into a compact top bar with Smart Search and overflow menu (`⋮`).
   - **Recent Files** horizontal carousel showing recently modified or captured media and documents.
   - **Categories Grid** (Images, Audio, Videos, Documents, Downloads, Installation files, Compressed files, Favorites) displaying live file counts and decimal byte totals (`1 GB = 1,000,000,000 bytes`).
   - **Storage Section**: Internal Storage (`StatFs` device telemetry + mounted SAF folders) and connected SD/USB OTG volumes with animated usage bars (e.g., `52.3 GB / 128 GB`), filesystem badges (`FAT32`, `exFAT`, `NTFS`, `ext4`), `Read-only` indicators where applicable, and Safe Eject controls.
   - **Utilities**: Cloud Drive connection row (SAF cloud document provider picker for Google Drive / cloud roots), Trash (Recycle Bin with Restore and Empty actions), and **Analyze Storage** (interactive donut chart by category, Large Files, Duplicate Files via content hash, and Unused/Old Files with one-tap Clean to Trash).
3. **File Browser & Multi-Select Operations**:
   - Interactive breadcrumb path bar with live folder/file sub-counts, pull-to-refresh, List / Grid / Detail view switcher, and Sort sheet (Name, Date, Type, Size; Ascending/Descending).
   - Long-press multi-select activating a One UI bottom action bar: Share, Copy, Move, Delete (to Trash), Rename, and More (Compress to ZIP, Extract ZIP, Details, Add Shortcut to Home, Favorite, Hide/Unhide).
   - Copy/Move "Paste here" floating bar with real-time progress dialog, cancellation support, and interactive conflict resolution (**Skip**, **Replace**, **Keep both**).
   - Built-in previewers for Images, Video (ExoPlayer/Media3), Audio (waveform/seek player), PDF (`PdfRenderer`), Text/Code viewer, and an **APK / Security Inspector** bottom sheet parsing package name, version code/name, SDK targets, and flagging suspicious double extensions (e.g., `photo.jpg.exe`) or incompatible Windows binaries (`.exe`, `.msi`).
4. **Integrated Camera & Gemini AI Studios**:
   - **In-App CameraX Capture**: Capture high-res photos or audio-enabled MP4 videos directly into the currently open folder or `DCIM/Camera` SAF root.
   - **AI Image Editor**: Crop, 90° rotate, color filters, brightness/contrast sliders, plus Gemini AI "Edit with Prompt", "Remove Background", and "AI Enhance", saving either as a new copy or overwriting the original.
   - **AI Video Editor**: Trim start/end, speed adjustment, audio mute, text overlay, and real MP4 export, paired with Gemini multimodal analysis to auto-generate timed captions/summaries, detect scene highlights, and apply AI edit suggestions.

### Visual Identity & Theme
- **Aesthetic Direction**: Authentic Samsung One UI 7 tactile modernism—generous top reachability zones, squircle `26.dp` surface cards, crisp iconography, subtle tonal elevation, and zero visual clutter.
- **Color Palette & Mood**:
  - Clean light mode (`#F6F6F8` background with `#FFFFFF` elevated cards) and deep dark mode (`#121214` background with `#1C1C20` cards), plus an optional **AMOLED Pure Black** (`#000000`) toggle.
  - **8+ Curated Accent Palettes** (One UI Blue `#0381FE`, Teal `#00A896`, Green `#2B9348`, Purple `#7B2CBF`, Pink `#E01E5A`, Red `#D90429`, Orange `#F77F00`, Amber `#FFB703`) plus a **Dynamic Image Palette** option that extracts dominant and vibrant swatches directly from any user-selected image via Android Palette / pixel quantization.
- **Typography & Hierarchy**: Bundled Google Fonts pairing **Plus Jakarta Sans** (bold, clean geometric One UI-inspired display headers and category titles) with **Inter** (crisp, highly legible body metadata, breadcrumbs, and tabular file sizes).
- **Adaptive Layout**: Mobile-first single-column reachability on phones (`Compact`), automatically expanding to a canonical **Two-Pane Navigation Rail + Split Sidebar/Browser** layout on tablets and unfolded foldables (`Medium`/`Expanded`).

### Interactive Feedback & Motion (`AnimationContext`)
- Governed globally through a single Compose `CompositionLocal` (`LocalAnimationMode`) persisted via DataStore:
  - **Off**: Instant state transitions (`0ms`), zero stagger, static progress/donut charts (auto-suggested if system animator duration scale / reduced motion is active).
  - **Medium (Default)**: Crisp `180ms` fade/slide transitions, standard Material 3 ripples, smooth progress bar fills.
  - **High**: Expressive spring physics (`Spring.DampingRatioLowBouncy`), animated list item placement, animated storage bars and category donut sweeps, collapsing parallax header dynamics, and spring-scaled multi-select checkmarks.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Storage Access Architecture (`StorageProvider` Interface)**
  - *Chosen Approach*: Define a clean, suspend/Flow-based `StorageProvider` contract (`listRoots`, `list`, `read`, `write`, `copy`, `move`, `delete`, `rename`, `mkdir`, `stat`, `getStorageInfo`) backed by two strict real implementations: `AppStorageAndSafAdapter` (combining real app-private storage, persisted SAF `DocumentFile` trees, and MediaStore category indexing) and `UsbOtgStorageAdapter` (`UsbManager` + `StorageManager` volume inspection).
  - *Why*: Respects Android 14–16 Scoped Storage & Google Play policies (avoiding restricted `MANAGE_EXTERNAL_STORAGE` while giving full read/write/ZIP/rename power inside user-granted folders and internal workspace) and surfaces clear capability banners whenever a folder tree hasn't been granted yet or a USB filesystem is read-only.
  - *Alternatives Considered*: Broad `MANAGE_EXTERNAL_STORAGE` permission (violates Google Play policy Compliance rules) or synthetic mock folders (explicitly ruled out in favor of strict real device storage).
- **Decision 2: Magic-Byte + Extension File Type & APK Inspection**
  - *Chosen Approach*: Inspect both file extensions and the first 16 magic bytes (`50 4B 03 04` for ZIP/APK, `4D 5A` for Windows PE `.exe`/`.msi`, `25 50 44 46` for PDF, `89 50 4E 47` for PNG, `FF D8 FF` for JPEG, `37 7A BC AF` for 7z, `52 61 72 21` for RAR, `1F 8B` for GZ) alongside Android's native `PackageManager.getPackageArchiveInfo()` for `.apk` and ZIP entry manifest inspection for `.xapk`/`.apks`.
  - *Why*: Catches disguised or corrupted files, flags suspicious double extensions (`invoice.pdf.exe`) with a prominent security warning, and shows authentic APK package metadata with an honest explanation note on Play-compliant package installation constraints.
- **Decision 3: Real On-Device Media Editing + Firebase AI Logic**
  - *Chosen Approach*: Combine deterministic native processing (`Bitmap` Canvas/ColorMatrix for crop, rotate, brightness/contrast, filters; Jetpack Media3 `Transformer` for real MP4 video trim, speed, audio mute, and text overlay export) with Firebase AI Logic (`gemini-nano-banana-2.1` for generative image edits/background removal/enhancement, and `gemini-3.8-flash` with `responseSchema` for natural-language smart search filters and multimodal video caption/scene analysis).
  - *Why*: Ensures instant, reliable offline media manipulation while delivering genuine cloud AI capabilities protected by Firebase App Check without exposing API keys.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Jetpack Compose UI Layer                             │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌───────────────────┐  │
│  │  One UI Home Screen  │  │  Adaptive Browser    │  │ Settings & Perms  │  │
│  │ • Categories & Recent│  │ • Breadcrumb & Sort  │  │ • Theme & Palette │  │
│  │ • Storage & USB Cards│  │ • Multi-Select & Copy│  │ • Animation Mode  │  │
│  │ • Analyze Donut Chart│  │ • Built-in Previewers│  │ • Trash & SAF Mgr │  │
│  └──────────┬───────────┘  └──────────┬───────────┘  └─────────┬─────────┘  │
│             │                         │                        │            │
│  ┌──────────┴─────────────────────────┴────────────────────────┴─────────┐  │
│  │        Media & AI Studios (CameraX • Image AI • Video AI • Search)    │  │
│  └────────────────────────────────────┬──────────────────────────────────┘  │
└───────────────────────────────────────┼─────────────────────────────────────┘
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                  ViewModel & Global Context StateFlows                      │
│  • FilesViewModel (Browser, Clipboard, Conflict Queue, Analyze, Search)     │
│  • AiStudioViewModel (Smart Search JSON, Nano Banana Image, Video AI)       │
│  • SettingsViewModel (Theme, Accent/Dynamic Color, AnimationContext, Trash) │
└───────────────┬───────────────────────┼───────────────────────┬─────────────┘
                ▼                       ▼                       ▼
┌───────────────────────────┐ ┌─────────────────────┐ ┌───────────────────────┐
│  StorageProvider Layer    │ │ Local Metadata/Prefs│ │  Firebase AI Logic    │
│ • AppStorageAndSafAdapter │ │ • DataStore (Prefs) │ │ • App Check (Debug/RC)│
│ • UsbOtgStorageAdapter    │ │ • Room DB (Trash,   │ │ • gemini-3.8-flash    │
│ • ZipArchiver & MagicBytes│ │   Favorites, Hidden,│ │ • gemini-nano-        │
│ • PackageArchiveInspector │ │   Home Shortcuts)   │ │   banana-2.1          │
└───────────────────────────┘ └─────────────────────┘ └───────────────────────┘
```

### Data Model & State
- **`FileNode` & `StorageVolumeInfo`**: Normalized representation of files/directories across internal app storage (`java.io.File`) and SAF URIs (`Uri` / `DocumentFile`), carrying decimal byte size, MIME type, magic-byte signature badge, double-extension warning flag, hidden status, and thumbnail URI.
- **Room Local Metadata Database** (strictly device-local file manager state):
  - `TrashEntry`: Tracks soft-deleted file paths/URIs, original parent location, deletion timestamp (for automatic 30-day cleanup), and byte size for accurate Restore and Empty Trash operations.
  - `BookmarkEntry`: Persists Favorites, Home Screen Shortcuts, Hidden path overrides, and Persisted SAF Root labels.
- **DataStore Preferences**: Stores Onboarding completion, Theme mode (`SYSTEM`, `LIGHT`, `DARK`, `AMOLED`), Accent Color / Dynamic Image seed ARGB, `AnimationMode` (`OFF`, `MEDIUM`, `HIGH`), Default View (`LIST`, `GRID`, `DETAIL`), Sort preferences, Show Hidden Files, Show File Extensions, and Auto-empty Trash toggle.

### Interactive Component & State Mapping
- **Copy/Move & Conflict Engine**: Runs in an IO coroutine with progress flow (`bytesCopied / totalBytes`, current filename). If a destination name collision occurs, suspends on a `CompletableDeferred<ConflictResolution>` surfaced as a modal dialog (**Skip**, **Replace**, **Keep both** with an "Apply to all" checkbox) before continuing or cancelling cleanly.
- **Storage Analyzer**: Scans accessible roots + MediaStore categories asynchronously, computing category slices for the Canvas Donut Chart, >50 MB Large Files, SHA-256 size-grouped Duplicate Files, and >90-day Old Files, allowing multi-select cleanup directly into Trash.
- **Smart Search**: Parses natural-language queries (e.g., *"PDFs from last week larger than 2 MB"*) via `gemini-3.8-flash` structured JSON output (`extensions`, `category`, `minSizeBytes`, `maxSizeBytes`, `modifiedAfterEpochMs`, `keywords`) and filters live device storage results, with instant keyword fallback if offline.
- **USB / OTG Hardware Monitor**: Listens to `UsbManager` attach/detach broadcasts and `StorageManager.storageVolumes`, inspecting USB mass storage descriptors and volume filesystems (`FAT32`, `exFAT`, `NTFS`, `ext2/3/4`), surfacing `Read-only` or `Unsupported filesystem` explanations, and guiding SAF root mounting or safe ejection.
