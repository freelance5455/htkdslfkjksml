# ChatGPT-Inspired AI Assistant Upgrade

Comprehensive implementation plan to elevate the current Onyx AI codebase into a modern, responsive ChatGPT-style interface with full dark/light modes, dynamic Arabic RTL & English LTR auto-detection, robust Google authentication, streaming chat controls, file & image capabilities, and isolated database persistence.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following design and architectural choices have been confirmed based on user feedback:

- **Confirmed Decision 1: Visual Layout Style**
  - **ChatGPT Clean Style**: Collapsible minimalist left/right sidebar ($260\text{px}$ width), clean centered chat conversation container ($800\text{px}$ max-width), subtle floating input box, refined action buttons (copy, retry, regenerate, voice, delete) with zero clutter.
- **Confirmed Decision 2: Direction & Multilingual Handling**
  - **Dynamic Auto-Detect (Arabic RTL or English LTR)**: Detects paragraph and message language automatically (`dir="rtl"` for Arabic text, `dir="ltr"` for English/code/Latin text), ensuring natural punctuation and flow across both languages without layout distortion.
- **Confirmed Decision 3: Google Authentication Architecture**
  - **One-Tap Google & Email with Instant Demo**: Secure server-side Google OAuth token verification and credential-based profile sync via `/api/auth/google`, with persistent 30-day session cookies/Bearer tokens, plus instant email and demo login pathways.

---

## 1. Overview & Core Concept

- **What It Does**: Upgrades the full-stack chat application into a production-grade, responsive AI assistant with ChatGPT aesthetics. Users can authenticate securely with Google or email, manage persistent conversations with search and auto-naming, stream fast responses using Google Gemini API with real-time markdown, code highlighting, tables, stop generation, and retry, upload images/spreadsheets/PDFs, generate images, listen to audio via streaming Gemini TTS, and tailor custom instructions, themes, and memory settings.
- **Target Audience**: Bilingual Arabic/English professionals, developers, students, and creators who need a fast, reliable, and aesthetically refined AI workspace.
- **Key Value**: Delivers the fluid speed and clean usability of ChatGPT with genuine Google Gemini intelligence, server-side data isolation, and multilingual RTL/LTR mastery.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Authentication Flow**: Clean modal or header entry point offering one-click "Continue with Google", Email/Password login, or instant "Demo Account". Authenticated state immediately populates user avatar, name, and user-isolated chats.
2. **Conversation Management**:
   - Sidebar with "New chat" button (+ shortcut `Ctrl/Cmd+K` for search).
   - Real-time search filter for past chats.
   - Pinned chats, auto-generated semantic titles from the first message, inline renaming, and safe deletion with confirmation.
   - Collapsible sidebar on desktop with a clean toggle icon; smooth mobile drawer overlay.
3. **Chat & Streaming Flow**:
   - Message bubbles follow ChatGPT clean lines: User bubbles positioned right/left based on direction, Assistant responses cleanly rendered with full Markdown, syntax-highlighted code with language tag and copy button, structured tables, and bold headers.
   - Streaming SSE responses with a prominent "Stop Generating" square button.
   - Once completed, action bar provides **Copy**, **Regenerate**, **Retry / Edit**, **TTS Voice Playback**, and **Delete**.
4. **Multimodal Inputs & File Attachments**:
   - Plus menu with Image upload, Document/PDF upload, Spreadsheet analysis, and direct camera capture.
   - Live thumbnails and remove tags before sending.
5. **Settings Management**:
   - Comprehensive settings modal: Theme (Dark / Light / System), Language & Direction, Custom System Instructions, AI model preference, Voice speed/name, Memory management, and Data export/clear.

### Design System & Theme Tokens
```
Theme Tokens (Dark / Light):
- Surface Background:       #0e0f12 (Dark) / #f8fafc (Light)
- Sidebar Background:       #13141a (Dark) / #f1f5f9 (Light)
- Card / Input Bubble:      #1a1b24 (Dark) / #ffffff (Light)
- Primary Accent:           #38bdf8 (Sky) / #2563eb (Blue)
- Text Primary:             #f3f4f6 (Dark) / #0f172a (Light)
- Text Secondary:           #9ca3af (Dark) / #64748b (Light)
- Hairline Borders:         rgba(255, 255, 255, 0.08) / rgba(0, 0, 0, 0.08)
- Typography:               'Cairo', 'Plus Jakarta Sans', system-ui, sans-serif
```

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dynamic Language & Direction Handling**
  - *Chosen Approach*: Automatic per-message and per-block direction analysis (`dir="auto"` and helper function `detectLanguageDirection(text)`), while maintaining overall UI direction aligned with user language preference (`ar` or `en`).
  - *Why*: Allows seamless bilingual conversations where an Arabic prompt gets an English code explanation or vice versa without text clipping or reverse punctuation.
- **Decision 2: Streaming Protocol (HTTP SSE vs. WebSocket)**
  - *Chosen Approach*: HTTP Server-Sent Events (SSE) via `/api/chat/stream` as the primary streaming transport for Gemini `generateContentStream`, with robust `AbortController` cancellation.
  - *Why*: SSE is lightweight, firewall-friendly, resilient, and standard for modern chat streaming, avoiding unnecessary WebSocket reconnection overhead.
- **Decision 3: Database & Multi-User Data Isolation**
  - *Chosen Approach*: Keep the existing JSON database (`data/db.json`) schema and enforce strict `userId` scoping across all sessions, messages, settings, and memories on the server.
  - *Why*: Ensures zero data leakage between accounts, preserves all existing user records safely, and guarantees backward compatibility.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                        React SPA Client (Vite)                         │
│                                                                        │
│  ┌──────────────────────┐  ┌────────────────────────────────────────┐  │
│  │   Sidebar Component  │  │          Chat Area Viewport            │  │
│  │  - New Chat Button   │  │  - Header with Model Badge & Sidebar   │  │
│  │  - Search Filter     │  │  - Message Stream (Markdown, Code,     │  │
│  │  - Session List      │  │    Tables, Images, Action Bar)         │  │
│  │  - Rename / Delete   │  │  - Floating Input (File Attachments,   │  │
│  │  - User Profile/Menu │  │    Voice Input, Stop Button)           │  │
│  └──────────┬───────────┘  └───────────────────┬────────────────────┘  │
│             │                                  │                       │
│             ▼                                  ▼                       │
│    authClient / storage             speechPlayer / streamClient        │
└─────────────┬──────────────────────────────────┬───────────────────────┘
              │                                  │
              │  HTTP / SSE Requests             │
              ▼                                  ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        Express Node.js Server                          │
│                                                                        │
│  ┌──────────────────────┐  ┌────────────────────────────────────────┐  │
│  │   Auth & Sessions    │  │       Gemini AI Controller             │  │
│  │  - /api/auth/google  │  │  - /api/chat/stream (SSE Flash stream) │  │
│  │  - /api/auth/login   │  │  - /api/tts/stream (Voice streaming)   │  │
│  │  - /api/auth/user    │  │  - /api/generate-image                 │  │
│  │  - Token middleware │  │  - /api/transcribe (Audio mic input)   │  │
│  └──────────┬───────────┘  └───────────────────┬────────────────────┘  │
│             │                                  │                       │
│             ▼                                  ▼                       │
│    Local Database (db.json)              Google Gemini API             │
│    (Users, Settings, Sessions,           (@google/genai SDK)           │
│     Memories - strictly isolated)                                      │
└────────────────────────────────────────────────────────────────────────┘
```

### Component Implementation Tasks
1. **Sidebar Enhancements (`src/components/Sidebar.tsx`)**:
   - Collapsible panel toggle (desktop collapse/expand, mobile drawer).
   - Instant search query bar with matching highlights.
   - Clear session grouping (Today, Yesterday, Previous 7 Days, Older).
   - Dropdown menu for session actions (Rename, Pin, Delete with confirmation modal/prompt).
   - Bottom user profile pill with quick-access settings and logout.
2. **Chat Experience & Actions (`src/components/ChatArea.tsx` & `src/components/ChatInput.tsx`)**:
   - ChatGPT centered container layout with auto-scroll lock during user scrolling.
   - Regenerate response and Retry action buttons on message bubbles.
   - Text editing for user messages to fork or retry inquiries.
   - File drag-and-drop support on the entire chat viewport.
3. **Markdown, Code & Tables (`src/components/MarkdownRenderer.tsx`)**:
   - Full GitHub Flavored Markdown (tables, blockquotes, ordered/unordered lists, inline math/code).
   - Code blocks with language detection, syntax styling, and 1-click copy with feedback.
   - Table styling with responsive horizontal scroll and clear alternating borders.
4. **Google & Session Auth (`src/lib/authClient.ts`, `server.ts`, `src/components/AuthModal.tsx`)**:
   - Real Google OAuth integration flow and token verification endpoint.
   - Persistent session storage in `localStorage` and `httpOnly`/header token sync.
   - Clear documentation in `.env.example` and modal instructions for adding real Google Client ID if needed.
5. **Settings & Customization (`src/components/SettingsModal.tsx`)**:
   - Responsive tabbed navigation: Account, AI Instructions & Model, Appearance (Themes, Font sizes, LTR/RTL), Voice/Audio, Privacy & Memory.
   - Instant live preview when switching themes or languages.
6. **Data Isolation & Backend Route Verification (`server.ts`)**:
   - Verify every CRUD endpoint (`/api/sessions`, `/api/settings`, `/api/memories`) enforces `userId` matching.
   - Never send passwords or sensitive credentials in API responses.
   - Safe backup handling for `data/db.json`.

---

## 5. Verification & Testing Checklist

- [ ] **Build Verification**: `npm run build` / `compile_applet` succeeds with 0 TypeScript and bundling errors.
- [ ] **Auth Flow**: Test email registration, email login, Google connect, Demo login, and Logout. Verify session persistence after reload.
- [ ] **Chat & Streaming**: Test prompt submission, real-time SSE token stream, Stop button, Markdown rendering, Code copy button, and Regenerate button.
- [ ] **Directionality**: Verify both Arabic (RTL) and English (LTR) prompts display with correct text alignment and punctuation.
- [ ] **Sidebar Features**: Create new chat, rename chat, delete chat with confirmation, and filter chats via search.
- [ ] **Attachments & Images**: Test image upload and AI image generation.
- [ ] **User Isolation**: Log in as User A, create chats; log in as User B, verify User A's chats are completely hidden.
