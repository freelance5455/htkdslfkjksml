# Mobile-Only Direct Downloads for OmniPrompt Studio APK & Full App ZIP

Enable 100% computer-free saving of the main **OmniPrompt Studio** signed `.apk` installer and complete **Full App `.zip`** directly into the phone's `Downloads` folder with a single tap, paired with an on-device mobile installation & sharing guide.

## User Review & Critical Decisions

> [!IMPORTANT]
> Based on your selections, this update focuses exclusively on the **main OmniPrompt Studio APK and Full App ZIP** and implements **1-Tap Direct Save to the Phone Downloads Folder** without requiring a computer or Android Studio.

- **Confirmed Decision 1 (Target Scope)**: Focus on exporting the main **OmniPrompt Studio** signed `.apk` and full `.zip` bundle rather than separate per-project APKs.
- **Confirmed Decision 2 (Export Mechanism)**: Use zero-permission Android `MediaStore.Downloads` direct writing so tapping **Save APK to Downloads** or **Save Full ZIP to Downloads** writes immediately to `Internal Storage/Downloads/` without forcing a multi-step folder picker.

---

## 1. Overview & Core Concept

- **What It Does**:
  - **1-Tap Direct Save to `Downloads/`**: Writes `OmniPromptStudio-v1.0-signed.apk` and `OmniPromptStudio-Full-App-and-APK.zip` directly into the phone's public `Downloads` directory using `MediaStore.Downloads` (with automatic fallback to the system file saver if needed).
  - **Complete Self-Contained App Source + Signed APK Bundle**: Packages the app's Kotlin source files, Gradle build scripts, AndroidManifest, adaptive icon resources, and the signed `.apk` binary into `OmniPromptStudio-Full-App-and-APK.zip`.
  - **Phone-Only Browser & Device Guide**: Includes a clear expandable guide inside the card showing how to download the `.apk` and `.zip` directly to a phone when using AI Studio in a mobile browser (Chrome/Safari on Android) without a PC.
- **Target Audience / Persona**: Mobile-first creators and developers operating entirely from an Android smartphone without access to a desktop computer.
- **Key Value**: Eliminates the need for a PC, USB cable, or Android Studio to obtain, back up, share, or install the OmniPrompt Studio `.apk` and `.zip` archive.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Direct APK Save Flow**: The user taps **Save `.APK` to Downloads** on the Studio Dashboard card -> the app streams the signed APK directly into `Downloads/OmniPromptStudio-v1.0-signed.apk` -> displays a confirmation banner with file size, exact path (`Downloads/OmniPromptStudio-v1.0-signed.apk`), and a **Share APK** button.
  2. **Direct Full ZIP Save Flow**: The user taps **Save Full `.ZIP` to Downloads** -> the app packages the signed APK, full Android project structure (`MainActivity`, `AndroidManifest.xml`, `build.gradle.kts`, UI screens, and workspace projects) into `Downloads/OmniPromptStudio-Full-App-and-APK.zip` -> displays a confirmation banner with a **Share ZIP** button.
  3. **No-Computer Mobile Browser Instructions**: A collapsible **"Using a Phone Browser? How to Download Without a PC"** tip box explains how to tap the top-right AI Studio menu in mobile Chrome (or switch to "Desktop site" view in Chrome mobile menu) to trigger direct browser downloads of the APK and project ZIP.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: High-contrast dark studio engineering card with emerald (`#10B981`) and cyan (`#38BDF8`) accents matching the OmniPrompt Studio dark palette.
  - *Color Palette & Mood*: Deep slate card surface (`#0F172A` / `MaterialTheme.colorScheme.surface`), emerald primary CTA for APK download, cyan secondary CTA for Full ZIP download, and subtle status badges.
  - *Typography & Hierarchy*: Bold title headers, monospace path readouts (`Downloads/OmniPromptStudio-v1.0-signed.apk`) using `JetBrainsMonoFontFamily`, and concise helper copy that fits strictly within the mobile screen width without horizontal scrolling.
- **Interactive Feedback & Motion**:
  - Instant progress indicator during file streaming, animated confirmation banner showing exact saved path in `Downloads/`, and native Android Share Sheet integration (`FileProvider` / `MediaStore` URI sharing) so the saved `.apk` or `.zip` can be sent immediately via WhatsApp, Telegram, Google Drive, or Files.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Zero-Permission `MediaStore.Downloads` Direct Write**
  - *Chosen Approach*: Write directly to `MediaStore.Downloads.EXTERNAL_CONTENT_URI` with `RELATIVE_PATH = Environment.DIRECTORY_DOWNLOADS` on Android 10+ (API 29+), with a fallback "Choose Folder" option alongside it.
  - *Why*: Saves the file into the phone's `Downloads` folder in a single tap without requiring any dangerous storage permissions or navigating complex directory trees on a phone screen.
  - *Alternatives Considered*: Only using `ActivityResultContracts.CreateDocument` (requires the user to manually navigate the system file picker every time).
- **Decision 2: Sharing Saved APK & ZIP Directly from the Confirmation Banner**
  - *Chosen Approach*: Keep the returned `MediaStore` content `Uri` in component state and provide a 1-tap **Share File** button using `Intent.ACTION_SEND` with `FLAG_GRANT_READ_URI_PERMISSION`.
  - *Why*: On a phone without a computer, users frequently want to open the saved file in their Files/Archive app or send it to another device via WhatsApp, Telegram, or Drive immediately after saving.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:
```
┌──────────────────────────────────────────────────────────────────────┐
│                   StudioDashboardScreen (Jetpack Compose)            │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │           DirectPhoneDownloadsCard (Mobile-Only Hub)           │  │
│  │  • [Save .APK to Phone Downloads] (1-Tap MediaStore Write)     │  │
│  │  • [Save Full .ZIP to Phone Downloads] (1-Tap MediaStore Write)│  │
│  │  • [Share Saved File] / [Choose Custom Folder Fallback]        │  │
│  │  • [No-Computer Mobile Browser Download Guide]                 │  │
│  └──────────────────────────────┬─────────────────────────────────┘  │
└─────────────────────────────────┼────────────────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────────┐
│                 ProjectArchiveExporter (IO Dispatcher)               │
│  ┌──────────────────────────────┐  ┌──────────────────────────────┐  │
│  │ saveApkDirectlyToDownloads() │  │ saveFullZipDirectlyToDownl() │  │
│  │ • Reads installed base.apk   │  │ • Packages signed .apk +     │  │
│  │ • Inserts MediaStore entry   │  │   full Android Studio Gradle │  │
│  │   in Environment.DOWNLOADS   │  │   scaffold + source code     │  │
│  │ • Returns Content Uri + size │  │ • Writes to MediaStore       │  │
│  └──────────────────────────────┘  └──────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - `DirectDownloadResult`: Holds `fileName`, `displayPath` (`Downloads/OmniPromptStudio-v1.0-signed.apk`), `totalBytes`, `contentUri`, and `mimeType`.
- **Interactive Component & State Mapping**:
  - Tapping **Save .APK to Downloads** invokes `ProjectArchiveExporter.saveApkDirectlyToDownloads(context)` on `Dispatchers.IO`, updates `lastSavedResult`, and reveals a **Share Saved File** button that launches `Intent.createChooser` with the `MediaStore` URI.
  - Tapping **Save Full .ZIP to Downloads** invokes `ProjectArchiveExporter.saveFullZipDirectlyToDownloads(context, projects)`, writes the complete archive into `Downloads/OmniPromptStudio-Full-App-and-APK.zip`, and reveals the saved path and share action.
