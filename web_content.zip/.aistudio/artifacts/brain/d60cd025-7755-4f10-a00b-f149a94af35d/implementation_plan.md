# Pass & Play Chess — React 19 Native Board & Neo-Staunton SVG Pieces Fix

This plan resolves the blank white screen / missing piece rendering issue by replacing fragile `react-dnd` internals with a zero-crash, React 19-compatible interactive chessboard engine with built-in Neo-Staunton vector SVG pieces, smooth pointer drag-and-drop, and two-click movement.

## User Review & Critical Decisions

> [!IMPORTANT]
> Confirmed user preferences from our clarification step are locked in below and govern the implementation.

- **Confirmed Decision 1 — Board & Piece Rendering**: Use built-in **Neo-Staunton SVG vector pieces** inside a dedicated, React 19-native interactive board engine with full pointer drag-and-drop and click-to-move support, eliminating any runtime crash or invisible SVG issue.
- **Confirmed Decision 2 — Surround & Board Theme**: Maintain the **Dark Slate surround** (`#262522` canvas, `#302E2B` elevated panels) paired with the classic Chess.com **Green (`#739552`) and Off-White Cream (`#EBECD0`)** checkered board.

---

## 1. Overview & Core Concept

- **What It Does**: A standalone, in-person "Pass & Play" 2D chess web application where two players share the same screen with full FIDE rule enforcement powered by `chess.js`.
- **Root Cause Fixed**: `react-chessboard` relies on older `react-dnd` context providers that can fail to mount or fail to render piece SVGs under React 19 + Vite 8 without a server restart. By rendering high-contrast Neo-Staunton SVG pieces directly and handling pointer drag-and-drop + click-to-move natively in React 19, pieces are guaranteed to render immediately on every device.
- **Key Value**: Instant, rock-solid piece visibility with high-contrast outlines and shading, responsive drag-and-drop ghost tracking, legal target square dots/rings, check alerts, and complete game controls.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Zero-State Start**: The board opens immediately in the standard starting position oriented to White at the bottom, displaying crisp White and Black Neo-Staunton pieces on `#EBECD0` (light) and `#739552` (dark) squares.
  2. **Click-to-Move Flow**: Clicking any piece of the active color highlights its square in warm yellow (`rgba(255, 255, 51, 0.55)`) and displays legal target indicators—translucent dark center dots on empty squares and circular rings around enemy pieces eligible for capture (including en passant). Clicking a highlighted target square executes the move immediately.
  3. **Drag-and-Drop Flow**: Pressing and dragging a piece of the active color lifts the piece smoothly under the cursor/finger while highlighting all legal target squares on the board; releasing over a valid target square completes the move.
  4. **Pawn Promotion Flow**: Moving a pawn to the 8th or 1st rank opens an inline promotion overlay on the board allowing the player to choose Queen, Rook, Bishop, or Knight rendered with matching Neo-Staunton SVGs.
  5. **End-of-Game Flow**: When `chess.js` detects Checkmate, Stalemate, Threefold Repetition, Insufficient Material, or the 50-Move Rule, a clear modal overlay announces the result and winner, with options to **Play Again** or **Inspect Board**.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Clean, tournament-grade tactical utility inspired by Chess.com.
  - *Color Palette & Mood*:
    - Dominant Canvas (60%): Deep Charcoal Slate (`#262522`) and Header/Sidebar (`#1F1E1B`).
    - Structural Surfaces & Board (30%): Elevated Panels (`#302E2B`), Light Squares (`#EBECD0`), Dark Squares (`#739552`).
    - Accent & Semantic Cues (10%): Tournament Green (`#81B64C`), Active Highlight (`#A3D160`), Check Crimson (`#EF4444`), and Last-Move Gold (`rgba(245, 246, 130, 0.55)`).
  - *Typography & Hierarchy*:
    - Display & UI Labels: `Plus Jakarta Sans` (600/700 weights for headers and player strips).
    - Move Notation & Coordinates: `JetBrains Mono` with `tabular-nums` for algebraic move tables, rank/file coordinates, and material advantage counters (`+3`).
  - *Component Styling & Layout*:
    - Responsive layout that fills mobile width like a native standalone app and centers the board column up to `600px` max-width on desktop alongside the algebraic move notation sheet.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Self-Contained Neo-Staunton SVG Board Engine vs. Third-Party `react-dnd` Wrapper**
  - *Chosen Approach*: Build a dedicated interactive board component using inline Neo-Staunton vector SVG artwork and native Pointer Events (`onPointerDown`, `onPointerMove`, `onPointerUp`) alongside click handlers.
  - *Why*: Eliminates the React 19 `react-dnd` crash that caused the blank screen, ensures crisp scaling at any resolution, and gives unified control over both touch/mouse drag-and-drop and click-to-move highlights.
  - *Alternatives Considered*: Patching `react-chessboard` with custom piece renderers still leaves `react-dnd` context provider crashes in React 19.
- **Decision 2: Immutable `chess.js` History State**
  - *Chosen Approach*: Maintain the array of validated `Move` objects and FEN snapshots in React state and derive the active `Chess` instance deterministically.
  - *Why*: Guarantees instantaneous **Undo Move** and **Restart Game** behavior while keeping move history, captured piece tallies, and check/checkmate detection strictly synchronized.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        Pass & Play Chess App                            │
│  State: moveHistory[], fenHistory[], selectedSquare, boardOrientation   │
└───────────────┬─────────────────────────────────────────┬───────────────┘
                │                                         │
                ▼                                         ▼
┌───────────────────────────────────────┐ ┌───────────────────────────────┐
│        Main Board Column (≤600px)     │ │    Move Notation & Info       │
│  ┌─────────────────────────────────┐  │ │  ┌─────────────────────────┐  │
│  │ Turn & Check Status Header      │  │ │  │ Paired SAN Move Table   │  │
│  ├─────────────────────────────────┤  │ │  │ (1. e4 e5  2. Nf3 Nc6)  │  │
│  │ Top Player Strip + Captures     │  │ │  ├─────────────────────────┤  │
│  ├─────────────────────────────────┤  │ │  │ FIDE Rules & Status     │  │
│  │ Interactive 8×8 Chessboard      │  │ │  └─────────────────────────┘  │
│  │  • Neo-Staunton SVG Pieces      │  │ └───────────────────────────────┘
│  │  • Pointer Drag & Click-to-Move │  │
│  │  • Legal Dots & Capture Rings   │  │
│  │  • Promotion & Game-Over Modals │  │
│  ├─────────────────────────────────┤  │
│  │ Bottom Player Strip + Captures  │  │
│  ├─────────────────────────────────┤  │
│  │ Controls: Undo | Restart | Flip │  │
│  └─────────────────────────────────┘  │
└───────────────────────────────────────┘
```

### Interactive Component & State Mapping

- **Square Click & Pointer Drag (`InteractiveChessboard`)**:
  - Pressing a piece of the active player's color selects that square (`selectedSquare`), computes legal moves via `game.moves({ square, verbose: true })`, and starts tracking pointer coordinates for smooth drag ghost rendering.
  - Releasing the pointer over a valid target square—or clicking a valid target square on a subsequent tap—checks whether the move is a pawn promotion (`rank 8` for White, `rank 1` for Black).
  - Standard moves execute `chess.move({ from, to })`, append the new FEN and move to state, trigger Web Audio API sound synthesis (move, capture, check, or game-over), and optionally flip the board if **Auto-Flip** is enabled.
- **Undo & Restart Controls**:
  - **Undo Move** pops the latest entry from `moveHistory` and `fenHistory`, clears any active selection or modal, and restores the previous player's turn.
  - **Restart Game** resets `fenHistory` to the initial starting FEN, clears `moveHistory`, and resets the board orientation to White.
