# Cubix Vouches & Customer Reputation System

This plan delivers **Cubix Vouches**, a complete customer reputation and review management system integrated into Cubix Studio's homepage, a dedicated `/vouches` page, the Admin Panel, and the existing Firebase Firestore database. It replaces the AI Assistant section on the homepage and in the Admin Panel with live reputation metrics, the newest approved customer vouch, a validated submission workflow with mandatory Discord username and 1–5 golden star rating, and a full three-tier moderation suite (`Pending`, `Approved`, `Rejected`) with manual **Verified Client** badge control.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following product and design choices have been confirmed and incorporated into this plan:

- **Confirmed Decision 1 — Inline Submission Form on `/vouches`**: Clicking **Add a Vouch** on the Homepage navigates to `/vouches` and smoothly scrolls to the dedicated inline **"Share Your Experience"** submission form section; clicking **Add a Vouch** on `/vouches` scrolls directly to and focuses that inline form section.
- **Confirmed Decision 2 — Dark Navy & Slate Review Cards**: The `/vouches` page uses a classic, single-column vertical list layout with dark navy and slate surfaces (`#060f1d` / `#081426`), subtle hairline borders, golden 1–5 star ratings, and understated typography matching the Cubix Studio identity.
- **Confirmed Decision 3 — Admin Panel Category Replacement**: In the Admin Panel sidebar, **Vouch Management** replaces the AI Assistant category, providing dedicated tabs for `Pending`, `Approved`, and `Rejected` vouches.

---

## 1. Overview & Core Concept

- **What It Does**: Replaces the homepage AI Assistant section with **CUBIX VOUCHES** ("Trust is built, not claimed."), dynamically calculating **Total Vouches** and **Client Rating** (`N/5`, e.g., `4.8/5` or `0.0/5` when empty) strictly from approved submissions, showcasing the single newest approved review (by `approvedAt` timestamp), and linking to a dedicated `/vouches` page with an inline submission form and full Admin moderation.
- **Target Audience / Persona**: Prospective and returning Cubix Studio clients evaluating studio reliability, submitting feedback after project delivery, and administrators moderating incoming vouches.
- **Key Value**: Establishes authentic, verifiable social proof backed by real-time Firestore synchronization, strict moderation gates (no unapproved public reviews), and automatic arithmetic rating calculation without hardcoded numbers.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Homepage Discovery (`CUBIX VOUCHES`)**:
   - Visitors see the **CUBIX VOUCHES** section directly below the Hero area with the heading *"Trust is built, not claimed."* and description *"Real feedback from people who have experienced Cubix Studio."*
   - **Reputation Statistics**: Displays **Total Vouches** (exact count of `status === 'approved'` vouches) and **Client Rating** (arithmetic mean of approved ratings formatted to one decimal place as `N/5`, e.g., `4.8/5`, or `0.0/5` if zero approved vouches exist) using tabular numerals (`tabular-nums`).
   - **Latest Vouch**: Displays only the single most recently approved vouch (sorted strictly by `approvedAt` descending, never by highest rating), including customer name, Discord username, product/service purchased, written feedback, 1–5 golden stars, **Verified Client** indicator (only if enabled by Admin), and publication date. If no approved vouches exist yet, a clean empty state invites the first client review.
   - **Homepage Actions**:
     - **Add a Vouch**: Navigates to `/vouches#submit-vouch` and focuses the inline submission form.
     - **View All Vouches**: Navigates to `/vouches` to browse the full vertical review list.

2. **Dedicated `/vouches` Page (All Approved Reviews + Inline Submission Form)**:
   - **Header & Summary Bar**: Shows page title, live **Total Vouches** and **Client Rating (`N/5`)** counters, and a primary **Add a Vouch** button that smoothly scrolls to the inline submission form.
   - **Filtering & Sorting Toolbar**:
     - Default sort: **Newest first** (`approvedAt` descending).
     - **Product / Service Filter**: Dropdown populated dynamically from Admin Panel products/services plus any products referenced in approved vouches.
     - **Star Rating Filter**: Filter by All Ratings or specific star tiers (`5★`, `4★`, `3★`, `2★`, `1★`).
   - **Classic Vertical List Layout**:
     - Renders one review card below another in a centered single-column container (`max-w-3xl mx-auto`) with consistent spacing (`space-y-4`), subtle rounded corners (`rounded-xl`), and thin borders (`border-slate-800/90`).
     - Includes **Load More** pagination (e.g., 8 vouches per page) for smooth mobile and desktop performance.
   - **Inline "Share Your Experience" Submission Form**:
     - Heading: *"Share Your Experience"* | Description: *"Your feedback helps others discover Cubix Studio."*
     - **Your Name** (Required text input, 2–80 characters).
     - **Discord Username** (Required text input, mandatory validation, 2–50 characters).
     - **Product / Service Purchased** (Required dropdown dynamically populated from Admin Panel `serviceProducts` and `services` lists, plus `"Other"`).
     - **Your Vouch** (Required multiline textarea with live character counter, 15–1,000 characters).
     - **Your Rating** (Required interactive 1–5 golden star selector with hover/selection preview and rating label).
     - **Submit Vouch**: Disables button while submitting, prevents duplicate rapid submissions, saves the record with `status: 'pending'` and `isVerified: false`, and displays the confirmation message: *"Your vouch has been submitted successfully and is awaiting approval."*

3. **Admin Panel – Vouch Management**:
   - Accessible from the Admin Sidebar under **Vouch Management** (with a live badge showing pending submission count).
   - **Three Status Categories (`Pending`, `Approved`, `Rejected`)**:
     - **Pending Tab**: View all awaiting submissions with full feedback, customer name, Discord username, selected product/service, and star rating. Actions: **Approve** (sets `status: 'approved'` and records `approvedAt`), **Approve & Verify** (approves and sets `isVerified: true`), or **Reject** (sets `status: 'rejected'`).
     - **Approved Tab**: View all published reviews. Actions: **Toggle Verified Client** status (`isVerified: true/false`), **Edit Review Details** (modal/inline editor for name, Discord username, product/service, feedback, and rating), **Move to Pending / Unpublish**, or **Delete Review**.
     - **Rejected Tab**: View rejected submissions. Actions: **Restore to Pending** (`status: 'pending'`) or **Permanently Delete**.

### Visual Identity & Theme

- **Aesthetic Direction**: Minimal, authoritative studio dark palette matching Cubix Studio's existing identity—no neon clutter, no masonry grids, and no flashy animations.
- **Color Palette & Mood**:
  - Dominant Canvas: Deep Obsidian Navy (`#030712`)
  - Card & Form Surfaces: Dark Slate Navy (`#060f1d` and `#081426`) with hairline borders (`border-slate-800/90`)
  - Primary Accent: Cubix Cyan (`#22d3ee`) for primary action buttons and active filter states
  - Rating Stars: Warm Golden Amber (`#fbbf24` / `text-amber-400 fill-amber-400`) for 1–5 star ratings
  - Verified Client Indicator: Subtle emerald/cyan check indicator with clean text (`Verified Client`)
- **Typography & Hierarchy**:
  - Display Headings: `Plus Jakarta Sans` (`font-extrabold tracking-tight`, `text-wrap: balance`)
  - Body Copy: `Plus Jakarta Sans` (`text-slate-200` / `text-slate-300`, `leading-relaxed`)
  - Numeric Metrics & Dates: `JetBrains Mono` with `tabular-nums` for rating averages (`4.8/5`), counts, and timestamps.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Strict Moderation Gate & Timestamp Ordering**:
  - *Chosen Approach*: Every public submission is created with `status: 'pending'`, `isVerified: false`, and `approvedAt: null`. Only when an Admin approves a vouch does `status` become `'approved'` and `approvedAt` get stamped. Both the Homepage "Latest Vouch" card and the `/vouches` list filter strictly by `status === 'approved'` and sort by `approvedAt` descending.
  - *Why*: Guarantees unapproved or rejected submissions never leak into public statistics or review cards, and ensures the homepage always highlights the most recently approved review rather than cherry-picking by rating.
- **Decision 2 — Real-Time Arithmetic Rating Engine**:
  - *Chosen Approach*: `Total Vouches` and `Client Rating` are derived dynamically from the live `approvedVouches` collection (`approved.reduce((sum, v) => sum + v.rating, 0) / approved.length`, formatted to `toFixed(1) + '/5'`, defaulting to `0.0/5` when `approved.length === 0`).
  - *Why*: Eliminates synchronization drift—any approval, edit, status change, or deletion immediately updates both the Homepage and `/vouches` rating displays across all connected clients.
- **Decision 3 — Dual-Layer Persistence & Validation (Firestore `vouches/{vouchId}` + Express API)**:
  - *Chosen Approach*: Store vouches in the dedicated Firestore collection `vouches/{vouchId}` on the existing named database (`ai-studio-cubixstudiogloba-56ae10ae-a948-4558-ab74-2c1a5de01e30`) with real-time `onSnapshot` listeners, backed by validated server endpoints (`/api/vouches` and `/api/admin/vouches/*`) and rate/duplicate guards.
  - *Why*: Provides instant real-time updates across all visitor devices while enforcing server-side input sanitization and spam protection.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                     Firebase Firestore (Named Database)                      │
│       Collection: vouches/{vouchId}  │  Document: cubix_store/main_store     │
└──────────────────┬───────────────────────────────────────┬───────────────────┘
                   │ Real-Time onSnapshot & SDK Writes     │ Server Sync & API
                   ▼                                       ▼
┌──────────────────────────────────────┐   ┌───────────────────────────────────┐
│      DataContext (React State)       │◄─►│       Express Backend API         │
│ • vouches[] (All for Admin)          │   │ • GET    /api/vouches             │
│ • approvedVouches[] (Sorted Newest)  │   │ • POST   /api/vouches (Rate-limit)│
│ • vouchStats { total, avgRating }    │   │ • PATCH  /api/admin/vouches/:id   │
│ • Dynamic Product/Service Options    │   │ • DELETE /api/admin/vouches/:id   │
└──────┬───────────────────────┬───────┘   └───────────────────────────────────┘
       │                       │
       ▼                       ▼
┌──────────────────────────────┐  ┌────────────────────────────────────────────┐
│     Public Website Views     │  │      Admin Panel (Vouch Management)        │
│                              │  │                                            │
│ 1. Homepage (HeroSection)    │  │ • Pending Tab:                             │
│    • CUBIX VOUCHES Header    │  │   Approve, Reject, Read Full Feedback      │
│    • Total Vouches & N/5     │  │ • Approved Tab:                            │
│    • Latest Approved Vouch   │  │   Edit Details, Toggle Verified Client,    │
│    • Add a Vouch / View All  │  │   Unpublish, Delete                        │
│                              │  │ • Rejected Tab:                            │
│ 2. /vouches (VouchesPage)    │  │   Restore to Pending, Permanently Delete   │
│    • Product & Rating Filter │  └────────────────────────────────────────────┘
│    • Classic Vertical List   │
│    • Load More Pagination    │
│    • Inline Submission Form  │
└──────────────────────────────┘
```

### Data Model & State (`vouches/{vouchId}`)

Each document in `vouches/{vouchId}` adheres to the following structure:
- `id`: Unique identifier string (`vch_<timestamp>_<random>`)
- `name`: Customer name (`string`, required, 2–80 chars)
- `discordUsername`: Customer Discord username (`string`, required, 2–50 chars)
- `productOrService`: Selected product/service name (`string`, required, 2–120 chars)
- `feedback`: Written review content (`string`, required, 15–1,000 chars)
- `rating`: Integer star rating from `1` to `5` (`number`, required)
- `status`: Moderation state (`'pending' | 'approved' | 'rejected'`)
- `isVerified`: Admin-controlled Verified Client badge flag (`boolean`, defaults to `false`)
- `createdAt`: ISO timestamp of submission (`string`)
- `approvedAt`: ISO timestamp when approved (`string | null`, used to sort newest approved reviews)
- `updatedAt`: ISO timestamp of last modification (`string`)

### Interactive Component & State Mapping

- **Dynamic Product/Service Dropdown**: Aggregates published items from `data.serviceProducts` and `data.services` (deduplicated by name) and appends `"Other"` (with an optional custom product specification input when `"Other"` is chosen) so every studio offering managed in the Admin Panel is automatically selectable.
- **Spam & Duplicate Submission Guard**: Client-side submission lock + 60-second cooldown per identical Discord username/feedback pair, paired with server-side validation and per-IP rate limiting on `POST /api/vouches`.
- **Firestore Security Rules (`firestore.rules` & `firebase-blueprint.json`)**:
  - Public visitors can `create` a vouch in `vouches/{vouchId}` only when `status == 'pending'` and `isVerified == false`, and can `read` vouches.
  - Status transitions (`approved`, `rejected`), edits, verification badge toggles, and deletions are restricted to authenticated Admin sessions and the Admin Panel workflow.
