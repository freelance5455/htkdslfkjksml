# ChirpCoop: 2D Baby Chicken Raising Game

An interactive, responsive 2D baby chicken raising simulation featuring an extended wooden coop environment, procedural chick physics and personalities, strict real-world feeding schedules, interactive inspection and calming mechanics, and synthesized audio effects.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and gameplay choices have been confirmed and will guide the implementation:

- **Rendering Engine & Host Environment**: Fullscreen Android WebView hosting an optimized HTML5 Canvas 2D engine with JavaScript and Tailwind CSS. This ensures 60 FPS ragdoll chick physics, smooth horizontal scrolling, responsive touch gestures, and synthesized Web Audio API.
- **Feeding Schedule & Penalties**: Strict real-world device time checking. Feeding windows occur at **7:00 AM** and **4:00 PM** local time (with water and grain troughs filled via the Feed Call Bell). If the morning feeding is missed by **2:00 PM** or the afternoon feeding by **9:00 PM**, unfed chicks starve and perish.
- **Visual Aesthetic**: Vibrant cartoon storybook style with warm wooden coop textures, straw bedding, wooden perches, ramps, and expressive, fluffy baby chicks with animated wings, beaks, and eyes.
- **Data Persistence**: HTML5 `localStorage` automatically saves chick states (names, genders, birth times, health, moods), high score / survival streaks, and user settings across sessions.

---

## 1. Overview & Core Concept

- **What It Does**: Puts the player in charge of raising a flock of up to 20 lively, fluffy baby chicks inside a wide, horizontally scrollable wooden coop. Players must feed chicks on schedule, calm angry bullies by petting them, startle sleepy chicks with cage slams, and ensure their flock thrives over days.
- **Target Audience / Persona**: Casual gamers, virtual pet enthusiasts, and anyone looking for a charming, tactile, and slightly chaotic flock-care simulator.
- **Key Value**: Delivers tangible, expressive virtual pet interactions with autonomous flock behaviors, satisfying ragdoll physics, and high-fidelity audiovisual feedback.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **First Hatch / Welcome Flow**:
   - The user opens the app to an extended sunny wooden chicken coop filled with fresh straw, perches, and ramps.
   - A flock of fluffy yellow chicks hatch with procedurally generated names (e.g., "Pip", "Buttercup", "Nugget"), gender symbols (♂ / ♀), and timestamps.
2. **Horizontal Coop Exploration**:
   - Users swipe or drag horizontally to pan across the 2.5x wide coop, viewing feeding troughs, high perches, climbing ramps, and cozy straw nests.
3. **Flock Interactions & Troublemaker Calming**:
   - Chicks wander, hop up ramps, perch, and occasionally stumble or tumble down.
   - When a chick turns red with angry eyes and begins poking siblings, the player taps on it to comfort and calm it down, producing floating heart particles and soothing chirps.
   - When chicks are asleep with floating "zZZ" particles, pressing the **Slam Cage** button triggers screen shake, a heavy wooden thud sound, and sends chicks flying upward in startled surprise.
4. **Scheduled Feeding Flow**:
   - At 7:00 AM and 4:00 PM, food & water troughs are ready. Pressing the **Feed Bell** (🔔) rings a resonant chime and spawns grain feed. Chicks rush toward the troughs to eat, keeping them nourished.
   - If chicks are neglected past the 2:00 PM or 9:00 PM deadlines, they pass away (turning pale grey with "X" eyes).
   - If all chicks perish, a dramatic **Game Over - Retry Raising** curtain displays survival stats and lets the player hatch a new batch.
5. **Chick Inspector**:
   - Tapping any living chick pauses focus and opens a glassmorphic card with the chick's identity, birth date/time, mood status, hunger bar, and a "Comfort / Pet" action button.
6. **Settings & Customization**:
   - Accessible via the ⚙️ button: Timezone toggle (Local vs. UTC), Sound volume sliders (Chirps, Cage Thuds, Bell, Coop Ambience), and Chick Flock Size slider (5 to 20 chicks).

### Visual Identity & Theme
- **Aesthetic**: Warm storybook farm cartoon with rich wooden coop textures, warm amber sunlight, and fluffy pastel-yellow chicks.
- **Color Palette**:
  - Coop Wood: Warm cedar (`#8B5A2B`), amber pine (`#C19A6B`), deep shadow timber (`#4A2E12`).
  - Straw & Bedding: Soft golden straw (`#FDE68A`, `#F59E0B`).
  - Chicks: Sunshine fluff (`#FACC15`), angry bully crimson (`#EF4444`), deceased ghost grey (`#9CA3AF`).
  - UI Accents: Glassmorphic dark slate with amber rim lights (`rgba(30, 27, 24, 0.85)`).
- **Typography**: Clean, friendly rounded sans-serif with legible numeric badges for the time display and inspector cards.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Architecture via Fullscreen Android WebView**:
  - *Chosen Approach*: Embed the single-page HTML5 Canvas, Web Audio API, and Tailwind CSS app directly inside a hardware-accelerated Android WebView loaded from local assets.
  - *Why*: Perfectly satisfies the user's explicit specification for HTML5 Canvas, pure Web Audio, and Tailwind CSS while delivering native Android APK packaging and 60 FPS performance without network latency.
- **Decision 2: Procedural Web Audio API Sound Generation**:
  - *Chosen Approach*: Synthesize all sound effects (gentle chirps, angry squawks, heavy wood cage slam thud, bell chime, and gentle rustling ambience) using the Web Audio API oscillators and gain envelopes.
  - *Why*: Zero external asset dependencies, instant load times, zero audio latency, and total dynamic control over pitch and volume.
- **Decision 3: Strict Real-World Time Check with Visual Window Status**:
  - *Chosen Approach*: Check device local clock against the 7:00 AM and 4:00 PM feeding windows, while displaying the current feeding window status and deadline warnings directly in the HUD so players always know the health state of their flock.
  - *Why*: Satisfies the strict real-world time requirement without leaving the player confused about why or when feeding is required.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                        MainActivity (Android)                          │
│  - Android Edge-to-Edge Container & Fullscreen WebView                 │
│  - Hardware Acceleration & Web Chrome Client                           │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ Loads asset:///coop/index.html
┌───────────────────────────────────▼────────────────────────────────────┐
│                  HTML5 Canvas 2D Game Loop (60 FPS)                    │
│                                                                        │
│  ┌───────────────────────┐  ┌─────────────────┐  ┌──────────────────┐  │
│  │   Camera & Viewport   │  │ Chick Physics    │  │ Audio Engine     │  │
│  │   Horizontal Panning  │  │ & Ragdoll Solver │  │ (Web Audio API)  │  │
│  └───────────┬───────────┘  └────────┬────────┘  └────────┬─────────┘  │
│              │                       │                    │            │
│  ┌───────────▼───────────────────────▼────────────────────▼─────────┐  │
│  │                     Coop State Manager                            │  │
│  │  - Flock List (1-20 chicks with mood, hunger, gender, birth)      │  │
│  │  - Troughs (Grain & Water Level)                                  │  │
│  │  - Time & Feeding Deadline Watcher (7 AM / 4 PM; 2 PM / 9 PM)    │  │
│  │  - LocalStorage Persistence Engine (flock, settings, records)     │  │
│  └───────────────────────────────────┬───────────────────────────────┘  │
│                                      │                                  │
│  ┌───────────────────────────────────▼───────────────────────────────┐  │
│  │                     Glassmorphic HUD & Overlays                   │  │
│  │  - Top-Left: Digital Clock ("HH:MM") + Feed Window Status         │  │
│  │  - Bottom-Right: Action FABs (Settings, Slam Cage 💥, Feed Bell🔔)│  │
│  │  - Chick Inspector Modal (Details, Status, "Comfort / Pet")       │  │
│  │  - Settings Modal (Timezone, Audio Sliders, Population, Reset)    │  │
│  │  - Game Over Overlay (Flock tribute & Hatch New Batch)            │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State
```typescript
interface Chick {
  id: string;
  name: string;
  gender: 'male' | 'female';
  birthTimestamp: number;
  birthFormatted: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  facing: 1 | -1;
  state: 'idle' | 'walking' | 'jumping' | 'sleeping' | 'angry' | 'eating' | 'startled' | 'dead';
  sleepTimer: number;
  angryTimer: number;
  lastFedTimestamp: number;
  isFedMorning: boolean;
  isFedEvening: boolean;
  petCount: number;
  rotation: number;
  angularVelocity: number;
  isGrounded: boolean;
}

interface GameSettings {
  maxChicks: number;
  timezoneMode: 'device' | 'utc';
  soundVolume: number;
  chirpVolume: number;
  slamVolume: number;
  bellVolume: number;
  ambienceEnabled: boolean;
}

interface CoopState {
  chicks: Chick[];
  settings: GameSettings;
  troughGrain: number;
  troughWater: number;
  highScoreHours: number;
  hatchDate: number;
}
```

### Interactive Component & State Mapping
- **Canvas Drag/Swipe**: Calculates drag velocity and updates camera X clamped between 0 and `coopWidth - viewportWidth`. Smooth damping ensures fluid scrolling on both mobile touch and desktop drag.
- **Slam Cage Button (💥)**: Adds high impulse screenshake, generates a resonant low-frequency wooden thump via Web Audio, and iterates over all sleeping chicks: switches state to `startled`, sets `vy = -12`, opens eyes wide with startled sweat droplets.
- **Feed Bell Button (🔔)**: Plays a metallic chime, fills troughs to 100%, and sets hungry chicks into `eating` pathfinding mode toward trough coordinates.
- **Angry / Bully Mechanic**: Every 15-30 seconds, a random healthy chick has a chance to turn angry (crimson tint, sharp eyebrows, lunges at nearby chicks). Tapping on the angry chick plays a soft chirp, spawns heart particles, and calms it down back to `happy`.
- **Inspector Popup**: Clicking any living chick anchors a glassmorphic tooltip card showing its portrait, name, gender, age, mood, and a "Comfort / Pet" button that increments pet counter and calms the chick.
- **Settings Modal**: Sliders reactively update audio volume, flock size, and timezone preference; saves immediately to `localStorage`.
- **Game Over & Reset**: When all chicks are dead, triggers a clean game-over screen with total survival time and a "Hatch New Batch" button that re-spawns a fresh flock.

---

## 5. Implementation Steps

1. **Platform Identity**:
   - Update `metadata.json` with App Name "ChirpCoop: Baby Chickens" and description.
   - Update `app/src/main/res/values/strings.xml` to match.
2. **Android WebView Setup**:
   - Configure `MainActivity.kt` with an edge-to-edge hardware-accelerated `AndroidView` running a responsive `WebView`.
   - Enable DOM storage, local asset access, and touch gesture handling.
3. **HTML5 Canvas Coop Engine & Web Audio (`index.html`, `app.js`, `styles.css`)**:
   - Build the 2.5x wide wooden coop layout with platforms, ramps, perches, nest boxes, and food/water troughs.
   - Implement the physics loop: gravity, platforms collision, ramp climbing, tumbling ragdoll rotation.
   - Implement chick procedural generator (cute names, male/female icons, birth timestamps).
   - Implement chick AI states (pecking, walking, jumping, sleeping with zZZ particles, angry bully mode with red tint, startled jumps, eating, and death states).
   - Implement procedural Web Audio synthesizer (chirp, angry squawk, cage slam thud, bell chime, ambient rustle).
4. **HUD & Interaction Layer**:
   - Floating real-time clock ("HH:MM") with feeding window indicator.
   - Floating action button group: Settings (⚙️), Slam Cage (💥), Feed Bell (🔔).
   - Chick Inspector popup with smooth glassmorphism and "Comfort / Pet" interaction.
   - Settings Modal (Timezone, SFX volumes, flock capacity slider, reset hatchery).
   - Game Over screen with restart button.
   - `localStorage` serialization & persistence.
5. **Compilation & Verification**:
   - Compile via `compile_applet` and verify zero errors.
