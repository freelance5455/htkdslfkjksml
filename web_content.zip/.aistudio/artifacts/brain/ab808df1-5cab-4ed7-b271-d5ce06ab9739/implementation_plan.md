# Amazing Sect Cultivation — Grand Economy, Arena, Lineage & Visual Overhaul

A comprehensive expansion introducing a real-time calendar and simulated day/week/month progression, balanced resource scarcity (~60–70% reduced passive yields), floating income popups, a fixed 5-round Peak Tournament with slow-motion (`-3x` to `3x`) playback, a Life-and-Death Grudge Arena with permanent Lineage archiving, deeper Bond XP and adoption mechanics, daily Travelling Merchant limits with Sect Storage, annual Year-End Sect Awards, and high-craft visual artwork across icons, items, portraits, and arenas.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> All ambiguous requirements have been confirmed and locked into this design blueprint.

- **Confirmed Decision 1 — Settings Save Card**: Remove JSON export, JSON import, and progress reset controls from the Settings storage card, leaving only **Save Game** and **Save & Exit to Main Menu**.
- **Confirmed Decision 2 — Life-and-Death Arena Outcome**: When two rivals with an **80–100 Grudge** duel in the Life-and-Death Battle Arena, the defeated disciple **perishes permanently**, moving into the unlimited **Lineage & Ancestral Archive** with their final stats, contributions, and sins intact while clearing the victor's hatred.
- **Confirmed Decision 3 — Minimized Resource Accumulation**: Apply **Balanced Scarcity (~60–70% lower passive income)** across Spirit Stones, Qi, Pills, and Merit so progression rewards missions, expeditions, ceremonies, and deliberate sect management.
- **Confirmed Decision 4 — Bespoke AI Artwork & Portrait Upgrade**: Generate high-craft custom visual art for **all categories** (items/treasures/pills, currency emblems, and combat/breakthrough arena backdrops) alongside upgraded multi-layer vector iconography and more lifelike disciple portrait rendering.

---

### 1. Overview & Core Concept

- **What It Does**: Deepens the xianxia sect simulation from a rapid idle loop into a lived-in cultivation world driven by daily time cycles, meaningful scarcity, social karma, permanent generational lineage, and high-stakes martial duels.
- **Target Experience**: Players govern a mountain sect starting from a tight roster cap of **5 disciples** (expanding up to **30 max**), rationing daily training actions, curating a daily Traveling Merchant stock into physical Sect Storage, nurturing multi-tier bonds or settling fatal grudges, and striving for three prestigious Year-End Sect Awards.
- **Key Value**: Fixes tournament bracket bugs and rushed battle animations, replaces abstract symbols with bespoke artwork and clear spatial hierarchy, and ensures time-skipping (`Next Day` / `Next Week` / `Next Month`) leaves detailed historical traces in the Sect Chronicle.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Live Calendar & Time Flow (Header & Sect Hub)**:
     - Top bar displays the real calendar date and sect year on the left (`November 16, 2026 · Year 1`) and a live ticking game clock on the opposite side (`12:01 PM` → `12:04 PM` → `12:06 PM`), keeping mobile sticky header height compact ($\le 15\%$ viewport).
     - Subtle floating resource delta popups (`+2 Stones`, `+3 Qi`, `+1 Pill`, `+1 Merit`) rise smoothly beside resource meters whenever passive ticks or daily bonuses arrive.
     - Instead of a single `"Next Season"` button, players choose **Next Day**, **Next Week**, or **Next Month**. Advancing by week or month simulates every intermediate day (daily cooldown resets, aging, bottleneck checks, merchant restocks, annual ceremonies) and records a detailed itemized log inside the Chronicle.
     - **Daily Action Rationing**: `Train All`, `Meditate`, `Leyline Surge`, and `Pill Infusion` display remaining daily charges (`e.g., 2/2 Left Today`) and reset at midnight when a new day begins.
  2. **5-Round Peak Tournament & Slow-Motion Choreography**:
     - Selecting an eligible disciple and optional booster enters a true **5-Opponent Gauntlet (`Round 1/5` through `Round 5/5`)**. Winning advances round-by-round through all 5 bouts until the Finals; losing ends the run early and passes the crown to the victor.
     - Playback controls include **Pause/Play** plus 6 speed steps: **`-3x`, `-2x`, `-1x` (slow motion)** and **`1x`, `2x`, `3x` (fast-forward)**. Slow modes expand turn intervals and VFX linger windows (`~1.5s–3.4s` per turn) so players can clearly read technique names, elemental counters, status effects, and spectator cheers.
  3. **Life-and-Death Battle Arena**:
     - Unlocked inside the Sect Arena / Social Matrix for disciple pairs whose Grudge reaches **80–100**.
     - Pairs with **1–79 Grudge** are explicitly barred from the Life-and-Death ring and guided to resolve conflict peacefully through Bonds, Gifts, Dates, or Mediation.
     - Uses the same turn-by-turn slow/fast battle simulator (`-3x` to `3x`). Grants **zero Spirit Stones/Pills/Merit**; the victor clears their crippling Dao-heart hatred, while the loser perishes and is immortalized in the Lineage Archive.
  4. **Massive Breakthrough Spectacle**:
     - Expands the Breakthrough Chamber with full-bleed cosmic storm art, multi-forked heavenly lightning strikes, rotating Bagua formation rings, radial Qi vortex shockwaves, screen-flash impact pulses, and dramatic Realm Seal shatter choreography—while keeping **Skip Animation** and **Instant Breakthrough** responsive on all hardware.
  5. **Travelling Merchant & Sect Storage**:
     - Each daily visit stocks limited-quantity offerings (`Stock: 1` per slot). Purchased items immediately mark `Purchased Today` and move into **Sect Storage**, where players inspect requirements (`Min Realm`, `Slot`, `Cultivation Path`) and equip or consume them directly on disciples.
     - Players get **1 Free Refresh per day** (automatic at dawn or claimed once daily) plus an optional **Paid Refresh** (`60 Spirit Stones` or `15 Merit`) to roll fresh wares early.
  6. **Bonds, Gifts, Dates, Shared Deployments & Lineage Archive**:
     - Bonding moves beyond instant upgrades: **Level 1 (`Unknown`)** and Levels 2–5 require accumulating **Bond XP** through concrete interactions—**Bestow Gift** (consumes items from Sect Storage; higher tiers and alignment/preference matches grant higher XP), **Daoist Date / Outing** (daily limited), and **Deploy Together** (bonus Bond XP when assigned to the same Building or Expedition squad).
     - Includes **Adopt** (`Adoptive Father/Mother` ↔ `Adopted Son/Daughter` based on gender and elder realm/age) and **Take Disciple / Bow to Master** (enforces strictly higher realm OR higher sect rank).
     - **Lineage & Ancestral Archive**: Unbounded historical roster preserving both living and **perished** disciples. **Long-pressing** (or holding) any disciple's name reveals their full Ancestral Card: last recorded Realm, Combat Power, Sect Position, Family/Master-Disciple Lineage links, Biggest Contributions, and Specific Crimes/Sins.
  7. **Invasion Army Scale & Year-End Sect Ceremony**:
     - Invasion alerts display exact **Invader Headcount** (e.g., `42 Hostile Cultivators` or `7 Crimson Pack Beasts`) alongside total Threat Power.
     - At the close of each year (December 31 → January 1), the **Year-End Sect Awards Ceremony** evaluates and awards 3 categories: **Strongest Sect** (`3x` cultivation resource boost for 5 months), **Most Contributions** (combined disciple contributions; `2x` resource boost for 5 months), and **Most Prodigies & Talents** (`3 random mid-tier equipment treasures` added to Sect Storage).
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Classical Xianxia Jade & Ink Sanctuary grounded in `#072018` / `#09261d` deep jade backgrounds, warm antique parchment callouts (`#f9f5ea`), brushed imperial gold borders (`#e2b054`, `#fce18b`), and crimson/ember accents exclusively for lethal combat and tribulations.
  - *Typography & Hierarchy*: `Cinzel` / Daoist serif display headings (`text-wrap: balance`) paired with clean sans-serif body prose and strict `font-mono tabular-nums` on every date, clock tick, currency counter, Bond XP bar, and battle HP/damage gauge. Zero decorative pulsing dots, zero thick left accent stripes, and clean unboxed typographic separators (`·`) for metadata instead of pill-badge clutter.
  - *Bespoke Visual Assets & Icons*: Dedicated custom illustrations for currency emblems, treasure tiers (Elixirs, Talismans, Weapons, Robes, Spirit Companions), Breakthrough storm backdrops, and Peak/Life-and-Death Arena stages, paired with upgraded realistic facial contours, hair silhouettes, lighting, and attire shading in disciple portraits.
- **Interactive Feedback & Motion**:
  - Compositor-only (`transform`, `opacity`, `filter`) floating resource popups (`1.1s` ease-out rise), crisp `< 200ms` button settle responses, and tactile long-press ring feedback (`500ms` hold threshold) on Lineage names and Champion titles.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Client-Side Simulation Engine + Local Storage Persistence**:
  - *Chosen Approach*: Keep the expanded calendar clock, daily cooldown ledger, Sect Storage inventory, Bond XP matrix, Perished Lineage archive, and ceremony buff timers in unified client state synchronized with local storage.
  - *Why*: Matches existing zero-latency offline play and save slot continuity without requiring server round-trips on every clock tick or combat turn.
  - *Alternatives Considered*: Moving simulation ticks to a backend API; avoided because per-second passive resource ticks and multi-speed turn-by-turn duels require immediate local reactivity.
- **Decision 2 — Integrated Multi-Day Simulation on Week/Month Skip**:
  - *Chosen Approach*: Pressing `Next Week` (+7 days) or `Next Month` (+30 days) executes a deterministic loop day-by-day rather than multiplying static rates blindly.
  - *Why*: Ensures multi-day skips trigger authentic daily Merchant refreshes, bottleneck aging, grudge/stress progression, year-end awards ceremonies when crossing year boundaries, and granular historical Chronicle entries for every notable occurrence.
- **Decision 3 — Unified Dual-Mode Duel Engine for Peak Tournament & Life-and-Death Arena**:
  - *Chosen Approach*: Refactor the battle arena engine to support both `tournament` (5-round gauntlet with champion rewards) and `life_death` (single 80–100 grudge mortal duel with zero loot and permanent Lineage archiving on defeat).
  - *Why*: Guarantees identical high-craft visual choreography, `-3x` to `3x` playback speeds, Manual/Auto controls, and zero duplicated combat math.
- **Decision 4 — Balanced Scarcity & Tighter Roster Cap (`5` → `30`)**:
  - *Chosen Approach*: Lower baseline passive generation by ~65%, drop starting max disciples from `10` to `5` (`+2` per Grand Dao Hall level + `+1` per major realm milestone, hard-capped at `30`), and gate `Train All`, `Meditate`, `Leyline Surge`, and `Pill Infusion` to 2–3 daily charges.
  - *Why*: Restores strategic tension so Traveling Merchant refreshes, Bonds, Sect Sectors, Expeditions, and Year-End Awards multipliers feel genuinely transformative.

---

### 4. Technical Architecture & Data Strategy

```
┌───────────────────────────────────────────────────────────────────────────┐
│                        Core Sect Simulation Engine                        │
│  ┌─────────────────────┐  ┌──────────────────┐  ┌──────────────────────┐  │
│  │ Real-Time Calendar  │  │ Scarcity Economy │  │ Social & Lineage DB  │  │
│  │  • Date + Clock     │  │  • -65% Base     │  │  • Bond XP (Lv 1–5)  │  │
│  │  • +1d / +7d / +30d │  │  • Buff Timers   │  │  • Living + Perished │  │
│  │  • Daily Action Cap │  │  • 5–30 Roster   │  │  • Contributions/Sins│  │
│  └──────────┬──────────┘  └────────┬─────────┘  └──────────┬───────────┘  │
└─────────────┼──────────────────────┼────────────────────────┼──────────────┘
              │                      │                        │
              ▼                      ▼                        ▼
┌──────────────────────┐  ┌──────────────────────┐  ┌───────────────────────┐
│     HUD & Sect Hub   │  │   Market & Storage   │  │  Arena & Breakthrough │
│ • Dual Date/Clock    │  │ • 1/day Item Caps    │  │ • 5-Round Gauntlet    │
│ • Floating +Income   │  │ • Free/Paid Refresh  │  │ • -3x to 3x Speeds    │
│ • Daily Limit Badges │  │ • Use/Equip Inventory│  │ • Life-Death (80-100) │
│ • Invader Headcount  │  │ • Year-End Awards    │  │ • Massive Storm VFX   │
└──────────────────────┘  └──────────────────────┘  └───────────────────────┘
```

- **Data Model & State Extensions**:
  - **Time & Buff State**: Tracks current in-game `currentDateIso` (`2026-11-16` starting baseline), `inGameMinutes` driving the `12:01 → 12:04 → 12:06` clock, `year` (1+), `dailyActionCounts` (`meditate`, `trainAll`, `leylineSurge`, `pillInfusion`), `freeMerchantRefreshUsedToday`, `purchasedMerchantIdsToday`, and `activeCeremonyBuffs` (5-month expiration dates for `3x` / `2x` cultivation yields).
  - **Sect Storage & Merchant Stock**: Typed `StorageItem` entries storing equipment, pills, elixirs, manuals, and gift treasures with `tier`, `category`, `quantity`, `minRealmIndex`, `preferredByTemperament`, and usable/equippable effects.
  - **Expanded Bonds & Lineage Records**: `DiscipleRelation` adds `xp`, `xpRequired`, and daily `lastInteractedDay`; `Disciple` tracks `parents`, `children`, `adoptedBy`, `biggestContribution`, `crimesSins[]`, and `perishedInfo` (`perishedYear`, `causeOfDeath`) preserved in an unbounded `lineageArchive[]` collection.
  - **Incursion Metadata**: `IncursionInvader` and hostile sect incursion payloads include `invaderCount` scaled by sect strength and threat level.
- **Interactive Component & State Mapping**:
  - **Calendar Skip Simulator**: Executing `+1 Day`, `+7 Days`, or `+30 Days` iteratively steps through dates, resets daily counters/merchant stock, ticks aging/negative trait drift, evaluates Year-End Sect Award winners (`Strongest Sect`, `Most Contributions`, `Most Prodigies`) on year rollover, and appends detailed chronological entries to Chronicle History.
  - **Long-Press Lineage Inspector**: Unified pointer/touch long-press handler (`onPointerDown` / `500ms` timer + click fallback hint) on Lineage rows opens a read-only modal presenting the disciple's final snapshot, relational family tree, honors, and recorded crimes.
  - **Settings Archive Simplification**: Strips Export JSON, Load JSON, and Reset controls from the Settings storage card while preserving Sound Adjustments (5 themes + volume/SFX), Graphics Quality, Expanded Help & Tutorials, Developer Console (hidden beetle), **Save Game**, and **Save & Exit to Main Menu**.
  - **Visual Asset Pipeline**: All custom item, currency, breakthrough, and arena artwork will be generated in a single parallel batch before updating UI components, wrapped with fallback SVG containers to guarantee zero broken image frames.
