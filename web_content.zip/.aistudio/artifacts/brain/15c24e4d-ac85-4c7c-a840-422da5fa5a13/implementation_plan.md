# Calculator v1.1 — Release & Interaction-Polish Plan

Prepare both the native Android (Kotlin/Jetpack Compose) and Web (HTML5/CSS3/Vanilla JS) Calculator applications for the **v1.1 (version code 2)** release with instant launch directly into the main calculator, fast tactile micro-interactions, reduced-motion accessibility, synchronized PWA caching, and full regression test verification.

### User Review & Critical Decisions

> [!IMPORTANT] The following release scope and polish choices were confirmed and govern this plan:
> - **Confirmed Target Scope**: Apply the v1.1 release updates, startup audit, and verification to **both** the Web app and the native Android app.
> - **Confirmed Interaction Polish**: Include **fast tactile keycap press & toggle transitions**, **reduced-motion accessibility with zero blocking animations**, and **service worker cache & web manifest version synchronization**.
> - **Unchanged Baseline**: All calculation engines (`BigDecimal` arbitrary precision, scientific functions, 16-category unit converter, 21 everyday/finance tools), Aether design tokens, and existing navigation flows remain completely unchanged.

---

### 1. Overview & Core Concept

- **What It Does**: Locks Calculator in as an instant-open utility release (`v1.1`, build `2`) that launches straight onto the main Calculator keypad with zero splash delays, intro carousels, or welcome gates, while tightening tactile tap responsiveness and accessibility across touch and keyboard inputs.
- **Target Audience / Persona**: Everyday, engineering, and finance users opening Calculator for immediate computation on mobile, tablet, or desktop.
- **Key Value**: Sub-second time-to-first-calculation paired with crisp, non-blocking UI feedback and clean v1.1 version/cache parity across Android and Web builds.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  - **Instant Startup**: Opening the Web app or launching the Android `MainActivity` renders the main **Calculator** tab (`0` initial readout, Standard keypad ready, optional Scientific drawer collapsed) immediately on first paint/frame—zero splash overlay, onboarding step, or timed fade-in delay.
  - **Immediate Input**: Tapping digits, operators, memory keys, or desktop keyboard keys updates the live preview and triggers crisp `80ms` tactile press compression without waiting on animations or double-tap zoom heuristics.
  - **About & Release Identity**: Opening Settings displays `Calculator` and `v1.1 (2)` cleanly in the About card on both platforms.
- **Visual Identity & Theme**:
  - Preserves the existing **Aether Design System** in full across OLED Dark (`#0B0B0F`), Slate Dark (`#13131A`), and Light (`#F7F7FA`) with Electric Violet (`#8B5CF6` / `#7C3AED`) accents, Soft Lavender (`#B9A0FF` / `#5B21B6`) highlights, `Plus Jakarta Sans` headings, and tabular-numeral `Inter` readouts.
- **Interactive Feedback & Motion**:
  - **Allowed & Tightened**: Fast keycap press feedback (`scale(0.95)` + elevated surface tint within `80ms`), `touch-action: manipulation` on interactive buttons/keypads to eliminate browser tap delay, keyboard-driven brief press highlight matching pointer taps, smooth `160ms` drawer/switch/nav transitions, and instant tab/sheet dismissal.
  - **Accessibility & Strictly Disallowed Motion**: Full `@media (prefers-reduced-motion: reduce)` support on Web collapsing transition/animation durations without hiding state changes; zero intro animations, zero startup timers, and zero interaction-blocking overlays.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Pointer & Keyboard Tactile Pulse without Input Delay**
  - *Chosen Approach*: Add `touch-action: manipulation` on Web interactive controls alongside lightweight pointerdown/keyboard-triggered `.is-pressed` pulse and existing CSS `:active` rules.
  - *Why*: Eliminates the mobile browser 300ms double-tap detection pause and gives physical keyboard users the same instant tactile feedback as touch taps, while keeping rapid sequential keystrokes unblocked.
  - *Alternatives Considered*: Relying solely on CSS `:active` misses keyboard presses and can feel sticky or sluggish on mobile touch browsers.
- **Decision 2: Coordinated Version & Offline Cache Rollout**
  - *Chosen Approach*: Increment Android `versionCode` to `2` / `versionName` to `"1.1"`, expose shared version constants in the Web About view (`v1.1 (2)`), sync the Web app manifest metadata, and bump the Service Worker cache key (`aether-calculator-v1.1`) so `activate` automatically purges older `v1` caches.
  - *Why*: Ensures returning PWA users do not remain stuck on cached v1.0 assets after deployment while keeping Android and Web About readouts identical.
  - *Alternatives Considered*: Keeping the old Service Worker cache name could serve stale v1.0 JS/CSS bundles indefinitely.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    Instant App Entry (No Splash / Intro)                │
│     Android MainActivity -> MainTab.CALCULATOR                          │
│     Web Bootstrap        -> CALCULATOR Stage                            │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        ▼                       ▼                       ▼
┌───────────────┐      ┌────────────────┐      ┌─────────────────┐
│ Aether UI &   │      │ Core Engines   │      │ Release & Cache │
│ Polish Layer  │      │ (Unchanged)    │      │ Identity        │
│               │      │                │      │                 │
│ • TactileKey  │      │ • BigDecimal   │      │ • Version 1.1   │
│ • Press Pulse │      │ • CalcEngine   │      │ • Code 2        │
│ • Prefers     │      │ • UnitConverter│      │ • SW Cache v1.1 │
│   Reduced     │      │ • ToolsEngine  │      │ • About Card    │
│   Motion      │      │ • Stores/Room  │      │   v1.1 (2)      │
└───────────────┘      └────────────────┘      └─────────────────┘
```

- **State & Version Data**:
  - Android consumes `BuildConfig.VERSION_NAME` (`"1.1"`) and `BuildConfig.VERSION_CODE` (`2`) directly inside the existing Settings About card.
  - Web exports centralized release constants (`1.1`, `2`) consumed by the Settings About panel and aligns the PWA manifest and Service Worker cache identifier (`aether-calculator-v1.1`).
- **Interactive Component & Verification Mapping**:
  - Touch, pointer, and physical keyboard handlers trigger non-blocking tactile states (`80ms`) without delaying expression evaluation or queued rapid inputs.
  - Both automated test suites (`node --test` for Web engine + UI DOM harness + asset/version/reduced-motion/startup assertions, and `gradle :app:testDebugUnitTest` for Kotlin engines + Robolectric startup/version verification) validate immediate launch into the Calculator screen and full mathematical parity.
