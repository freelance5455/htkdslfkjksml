package com.coffeemist.pos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.net.Socket
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var btSocket: BluetoothSocket? = null
    private var wifiHost: String? = null
    private var wifiPort = 9100
    private var statusCallback: String = ""
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val prefs by lazy { getSharedPreferences("coffee_printer", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifiHost = prefs.getString("wifi_host", null)
        wifiPort = prefs.getInt("wifi_port", 9100)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(PrinterBridge(), "CoffeePrinter")
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun sayStatus(message: String) {
        runOnUiThread { web.evaluateJavascript("window.onNativePrinterStatus && window.onNativePrinterStatus(${JSONObjectEscape.quote(message)})", null) }
    }

    inner class PrinterBridge {
        @JavascriptInterface fun connectBluetooth() { runOnUiThread { showBluetoothPicker() } }
        @JavascriptInterface fun configureWifi() { runOnUiThread { showWifiDialog() } }
        @JavascriptInterface fun printReceipt(html: String, callbackId: String) {
            thread {
                var wifiSocket: Socket? = null
                try {
                    val bitmap = renderReceipt(html)
                    val stream = printerStream().also { wifiSocket = activeWifiSocket } ?: throw IllegalStateException("Printer not connected. Connect Bluetooth or configure Wi-Fi first.")
                    stream.write(byteArrayOf(0x1B, 0x40)) // ESC @ initialize
                    sendBitmap(stream, bitmap)
                    stream.write(byteArrayOf(0x1B, 0x64, 0x03)) // feed 3 lines
                    stream.write(byteArrayOf(0x1D, 0x56, 0x00)) // full cut (if cutter supported)
                    stream.flush()
                    // Do not close Bluetooth output stream here: closing it disconnects the SPP socket.
                    wifiSocket?.close(); wifiSocket = null
                    if (btSocket?.isConnected != true) stream.close()
                    sayStatus("Print sent successfully")
                    runOnUiThread { web.evaluateJavascript("window.onNativePrintDone && window.onNativePrintDone(${JSONObjectEscape.quote(callbackId)},true)", null) }
                } catch (e: Exception) {
                    wifiSocket?.close(); wifiSocket = null
                    val msg = "Print failed: ${e.message ?: e.javaClass.simpleName}"
                    sayStatus(msg)
                    runOnUiThread { web.evaluateJavascript("window.onNativePrintDone && window.onNativePrintDone(${JSONObjectEscape.quote(callbackId)},false,${JSONObjectEscape.quote(msg)})", null) }
                }
            }
        }
        @JavascriptInterface fun testPrint() {
            val test = "<html><head><meta charset='utf-8'></head><body style='font-family:Arial;width:280px;text-align:center'><h2>COFFEE MIST</h2><h3>PRINTER TEST</h3><p>Bluetooth / Wi-Fi test</p><p>Life Begins After Tea</p></body></html>"
            thread {
                try {
                    val bitmap = renderReceipt(test)
                    val stream = printerStream() ?: throw IllegalStateException("No printer connected. Pair Bluetooth or configure Wi-Fi first.")
                    stream.write(byteArrayOf(0x1B, 0x40))
                    sendBitmap(stream, bitmap)
                    stream.write(byteArrayOf(0x1B, 0x64, 0x03))
                    stream.write(byteArrayOf(0x1D, 0x56, 0x00))
                    stream.flush()
                    activeWifiSocket?.close(); activeWifiSocket = null
                    if (btSocket?.isConnected != true) stream.close()
                    sayStatus("TEST PRINT sent successfully")
                } catch (e: Exception) {
                    activeWifiSocket?.close(); activeWifiSocket = null
                    sayStatus("TEST PRINT failed: ${e.message ?: e.javaClass.simpleName}")
                }
            }
        }
        @JavascriptInterface fun printerStatus(): String = if (btSocket?.isConnected == true) "Bluetooth connected" else if (!wifiHost.isNullOrBlank()) "Wi-Fi configured: $wifiHost:$wifiPort" else "Not connected"
    }

    private fun showBluetoothPicker() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { sayStatus("Bluetooth is not available on this tablet"); return }
        val neededPermissions = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = neededPermissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            sayStatus("Requesting Bluetooth scan/connect permission…")
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 501)
            return
        }
        if (!adapter.isEnabled) {
            AlertDialog.Builder(this)
                .setTitle("Bluetooth is OFF")
                .setMessage("Turn Bluetooth on, then pair the TVS printer in Android Bluetooth settings. Return here and press Connect Bluetooth again.")
                .setPositiveButton("Open Bluetooth Settings") { _, _ -> startActivity(android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }
                .setNegativeButton("Cancel", null).show()
            sayStatus("Bluetooth is OFF — enable it and pair the printer first")
            return
        }
        val discovered = mutableListOf<BluetoothDevice>()
        val labels = mutableListOf<String>()
        val listAdapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels)
        val listView = ListView(this).apply { adapter = listAdapter }
        val dialog = AlertDialog.Builder(this).setTitle("Search Bluetooth Printers")
            .setView(listView).setNegativeButton("Close", null).create()
        fun addDevice(device: BluetoothDevice, prefix: String) {
            if (discovered.any { it.address == device.address }) return
            discovered.add(device)
            val deviceName = try { device.name ?: "Unknown Bluetooth device" } catch (_: SecurityException) { "Bluetooth device" }
            labels.add("$prefix$deviceName\n${device.address}")
            listAdapter.notifyDataSetChanged()
        }
        try { adapter.bondedDevices.forEach { addDevice(it, "Paired: ") } } catch (_: SecurityException) { }
        listView.setOnItemClickListener { _, _, position, _ ->
            try { if (adapter.isDiscovering) adapter.cancelDiscovery() } catch (_: SecurityException) { }
            dialog.dismiss()
            connectBluetoothDevice(discovered[position])
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: android.content.Context, intent: android.content.Intent) {
                when (intent.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                        device?.let { addDevice(it, "Found: ") }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> sayStatus("Bluetooth scan finished. Select your printer from the list.")
                }
            }
        }
        val filter = IntentFilter().apply { addAction(BluetoothDevice.ACTION_FOUND); addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED) }
        registerReceiver(receiver, filter)
        dialog.setOnDismissListener {
            try { if (adapter.isDiscovering) adapter.cancelDiscovery() } catch (_: SecurityException) { }
            try { unregisterReceiver(receiver) } catch (_: Exception) { }
        }
        dialog.show()
        sayStatus("Scanning nearby Bluetooth devices… select TVS printer when it appears")
        try {
            if (adapter.isDiscovering) adapter.cancelDiscovery()
            val started = adapter.startDiscovery()
            if (!started) sayStatus("Bluetooth scan could not start. Pair printer in Android Bluetooth Settings, then retry.")
        } catch (e: SecurityException) { sayStatus("Bluetooth scan permission error: ${e.message}") }
        Handler(Looper.getMainLooper()).postDelayed({ if (dialog.isShowing) sayStatus("Scan is running. If printer is not found, pair it in Android Bluetooth Settings first.") }, 12000)
    }

    private fun connectBluetoothDevice(device: BluetoothDevice) {
        sayStatus("Connecting Bluetooth printer…")
        thread {
            try {
                btSocket?.close()
                val socket = device.createRfcommSocketToServiceRecord(sppUuid)
                BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                socket.connect()
                btSocket = socket
                sayStatus("Bluetooth connected: ${device.name ?: device.address}")
            } catch (e: Exception) { btSocket = null; sayStatus("Bluetooth connection failed: ${e.message}") }
        }
    }

    private fun showWifiDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 12, 32, 0) }
        val ip = EditText(this).apply { hint = "Printer IP address (example 192.168.1.100)"; setText(wifiHost ?: "") }
        val port = EditText(this).apply { hint = "Port (usually 9100)"; inputType = 2; setText(wifiPort.toString()) }
        layout.addView(ip); layout.addView(port)
        AlertDialog.Builder(this).setTitle("Wi-Fi thermal printer").setView(layout).setPositiveButton("Save & Test") { _, _ ->
            val host = ip.text.toString().trim(); val p = port.text.toString().toIntOrNull() ?: 9100
            if (host.isBlank()) { sayStatus("Enter printer IP address"); return@setPositiveButton }
            wifiHost = host; wifiPort = p; prefs.edit().putString("wifi_host", host).putInt("wifi_port", p).apply()
            sayStatus("Wi-Fi printer saved: $host:$p. Test print next.")
            PrinterBridge().testPrint()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun printerStream(): OutputStream? {
        val socket = btSocket
        if (socket?.isConnected == true) return socket.outputStream
        val host = wifiHost ?: return null
        activeWifiSocket = Socket(host, wifiPort)
        return activeWifiSocket!!.getOutputStream()
    }
    @Volatile private var activeWifiSocket: Socket? = null

    private fun renderReceipt(html: String): Bitmap {
        var result: Bitmap? = null
        val latch = java.util.concurrent.CountDownLatch(1)
        runOnUiThread {
            val renderer = WebView(this)
            renderer.settings.javaScriptEnabled = true
            renderer.setBackgroundColor(Color.WHITE)
            renderer.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            renderer.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    view.postDelayed({
                        val width = 576 // 80mm printer raster width; 58mm devices may crop, change to 384 if needed
                        val height = maxOf(view.contentHeight * view.scale.toInt().coerceAtLeast(1), 400)
                        view.measure(android.view.View.MeasureSpec.makeMeasureSpec(width, android.view.View.MeasureSpec.EXACTLY), android.view.View.MeasureSpec.makeMeasureSpec(height, android.view.View.MeasureSpec.AT_MOST))
                        view.layout(0, 0, width, height)
                        val bmp = Bitmap.createBitmap(width, maxOf(view.height, 400), Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(bmp); canvas.drawColor(Color.WHITE); view.draw(canvas)
                        result = bmp; renderer.destroy(); latch.countDown()
                    }, 500)
                }
            }
        }
        if (!latch.await(15, java.util.concurrent.TimeUnit.SECONDS)) throw IllegalStateException("Receipt rendering timed out")
        return result ?: throw IllegalStateException("Could not render receipt")
    }

    private fun sendBitmap(out: OutputStream, bitmap: Bitmap) {
        val width = bitmap.width
        val height = bitmap.height
        val bytesPerRow = (width + 7) / 8
        for (y in 0 until height step 24) {
            val chunkHeight = minOf(24, height - y)
            out.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00, (bytesPerRow and 0xFF).toByte(), (bytesPerRow shr 8).toByte(), (chunkHeight and 0xFF).toByte(), (chunkHeight shr 8).toByte()))
            val rowBytes = ByteArray(bytesPerRow * chunkHeight)
            for (yy in 0 until chunkHeight) for (x in 0 until width) {
                val pixel = bitmap.getPixel(x, y + yy)
                val gray = (Color.red(pixel) + Color.green(pixel) + Color.blue(pixel)) / 3
                if (gray < 180) rowBytes[yy * bytesPerRow + x / 8] = (rowBytes[yy * bytesPerRow + x / 8].toInt() or (0x80 shr (x % 8))).toByte()
            }
            out.write(rowBytes)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 501) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) showBluetoothPicker()
            else sayStatus("Bluetooth permission denied. Allow Nearby devices / Location permission in Android app settings and retry.")
        }
    }
}

private object JSONObjectEscape { fun quote(s: String): String = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\"" }
