COFFEE MIST POS — Android Printer Bridge (Prototype)

இந்த project-ல் தற்போதைய POS HTML asset ஆக சேர்க்கப்பட்டுள்ளது. Android WebView bridge வழியாக:
- Bluetooth: Android settings-ல் printer pair செய்த பிறகு, POS Printer Settings > Connect Bluetooth மூலம் paired device தேர்வு.
- Wi-Fi: POS Printer Settings > Wi-Fi / IP Setup-ல் printer IP மற்றும் port (பொதுவாக 9100) கொடுக்கவும்.
- Native Test Print
- POS receipt print: Token / Customer bill / Token + Bill sequencing existing JS flow-ல் bridge promise மூலம் காத்திருக்கிறது.
- ESC/POS initialize, raster image print, feed, cut command (printer cutter support இருந்தால்).

முக்கியம்:
1. இது Android Studio project; APK build செய்ய Android Studio-ல் project folder open செய்து Gradle sync/build செய்ய வேண்டும்.
2. முதலில் Android settings-ல் TVS printer-ஐ Bluetooth pairing செய்யவும்.
3. Wi-Fi printing: printer மற்றும் tablet ஒரே Wi-Fi network-ல் இருக்க வேண்டும். Printer IP-ஐ network/router/printer utility-ல் கண்டறியவும்.
4. Printer variant மற்றும் paper width (58/80mm) அடிப்படையில் raster width 576px மாற்ற வேண்டியிருக்கலாம். 58mmக்கு 384px.
5. இந்த prototype Bluetooth SPP மற்றும் Wi-Fi raw TCP 9100 பயன்படுத்துகிறது. TVS RP 3230 variant-ல் connectivity/port/protocol verify செய்ய வேண்டும்.
6. Actual device print, Tamil glyph rendering, cut command ஆகியவை tablet + printer-ல் test செய்யப்படவில்லை. APK build & device testing அவசியம்.
7. Android Studio project-ல் Gradle wrapper files இல்லை; Android Studio installed Gradle மூலம் project sync/build செய்யும்.
