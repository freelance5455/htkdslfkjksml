Sara AI — Pashto assistant starter package

Files:
- index.html: app interface and basic local responses
- manifest.webmanifest: installable web app metadata
- sw.js: simple offline caching for hosted PWA use

APK builder:
Upload this ZIP to a reputable HTML-to-APK builder and follow its build flow.
This package is NOT an APK. It is a website package ready to be wrapped by an APK builder.

Limitations:
- No online AI backend is connected; do not put private API keys in this HTML.
- Speech recognition and Pashto voice support depend on browser/device support and may need internet.
- Microphone generally requires permission and a secure HTTPS origin; support in Android WebView varies.
- This app does not control phone settings, calls, messages, or other apps.
