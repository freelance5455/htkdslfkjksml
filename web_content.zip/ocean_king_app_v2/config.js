window.OK_CONFIG = {
  supabaseUrl: 'https://uflpcaibgawzzlshmdip.supabase.co',
  supabaseKey: 'sb_publishable_cHAJzUbGBjO4xu9yDy_F_g_wsOSEVD6'
};
