OCEAN-KING TRACKER UPDATED PACKAGE

Files:
index.html       Customer tracking app
admin.html       Admin login and shipment manager
config.js        Supabase connection
logo.png         Transparent Ocean-King logo

Customer privacy:
The customer page does not list recent shipments. It calls the Supabase get_public_shipment function for the exact order number entered.

Admin:
Open /admin.html. Sign in with an approved Supabase account that also exists in public.admin_users.

Do not change the Supabase tables or privacy SQL that are already working.

The customer page includes a lightweight branded splash screen, animated progress bar and animated journey timeline. It is designed to remain lightweight for Android packaging later.
