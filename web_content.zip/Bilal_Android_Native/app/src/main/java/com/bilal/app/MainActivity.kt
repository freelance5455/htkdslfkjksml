package com.bilal.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), LocationListener {
    private lateinit var webView: WebView
    private lateinit var locationManager: LocationManager
    private val io = Executors.newSingleThreadExecutor()
    private val requestCode = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannels(this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.setGeolocationEnabled(true)
        webView.addJavascriptInterface(NativeBridge(), "BilalAndroid")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, true, false)
            }
        }
        webView.webViewClient = WebViewClient()
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
        askNotificationPermission()
        requestLocationAndPrayerTimes()
        scheduleDuaReminders(this)
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestCode)
        }
    }

    private fun requestLocationAndPrayerTimes() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCode + 1)
            return
        }
        try {
            locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
            val last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (last != null) fetchPrayerTimes(last)
            val provider = if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            locationManager.requestLocationUpdates(provider, 60_000L, 1000f, this)
        } catch (_: Exception) { /* Permission or provider unavailable; reminders still work. */ }
    }

    override fun onLocationChanged(location: Location) { fetchPrayerTimes(location) }
    @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    private fun fetchPrayerTimes(location: Location) {
        io.execute {
            try {
                val url = URL("https://api.aladhan.com/v1/timings?latitude=${location.latitude}&longitude=${location.longitude}&method=5")
                val connection = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 10000; requestMethod = "GET" }
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val timings = JSONObject(response).getJSONObject("data").getJSONObject("timings")
                val names = linkedMapOf("Fajr" to "الفجر", "Dhuhr" to "الظهر", "Asr" to "العصر", "Maghrib" to "المغرب", "Isha" to "العشاء")
                val prefs = getSharedPreferences(ReminderReceiver.PREFS, Context.MODE_PRIVATE).edit()
                names.forEach { (key, name) ->
                    val hhmm = timings.getString(key).substringBefore(" ").split(":")
                    val minute = hhmm[0].toInt() * 60 + hhmm[1].toInt()
                    prefs.putInt("prayer_$key", minute)
                    if (getSharedPreferences(ReminderReceiver.PREFS, Context.MODE_PRIVATE).getBoolean("prayer_alerts_enabled", true)) {
                        scheduleDaily(this, 100 + names.keys.indexOf(key), minute, "حان وقت صلاة $name", "حان الآن وقت صلاة $name. تقبّل الله طاعتك.", "prayer")
                    } else cancelDaily(this, 100 + names.keys.indexOf(key))
                }
                prefs.putBoolean("prayer_notifications", true).apply()
            } catch (_: Exception) { }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode + 1 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) requestLocationAndPrayerTimes()
    }

    override fun onDestroy() {
        try { if (::locationManager.isInitialized) locationManager.removeUpdates(this) } catch (_: Exception) {}
        io.shutdown()
        webView.destroy()
        super.onDestroy()
    }

    inner class NativeBridge {
        
        }
        @JavascriptInterface fun saveDuaSchedule(enabled: Boolean, t1: String, t2: String, t3: String) {
            val times = listOf(t1, t2, t3).map { value ->
                val parts = value.split(":")
                if (parts.size == 2) ((parts[0].toIntOrNull() ?: 8).coerceIn(0, 23)) * 60 + (parts[1].toIntOrNull() ?: 0).coerceIn(0, 59) else 8 * 60
            }
            getSharedPreferences(ReminderReceiver.PREFS, Context.MODE_PRIVATE).edit().apply {
                putBoolean("dua_alerts_enabled", enabled)
                times.forEachIndexed { i, minute -> putInt("dua_minute_$i", minute) }
            }.apply()
            if (enabled) scheduleDuaReminders(this@MainActivity, times)
            else (201..203).forEach { cancelDaily(this@MainActivity, it) }
        }
        @JavascriptInterface fun savePrayerAlerts(enabled: Boolean) {
            getSharedPreferences(ReminderReceiver.PREFS, Context.MODE_PRIVATE).edit().putBoolean("prayer_alerts_enabled", enabled).apply()
            if (!enabled) (100..104).forEach { cancelDaily(this@MainActivity, it) } else requestLocationAndPrayerTimes()
        }
        @JavascriptInterface fun testDuaNotification() {
            val intent = Intent(this@MainActivity, ReminderReceiver::class.java).apply {
                putExtra("alarm_id", 299); putExtra("minute", 8 * 60)
                putExtra("title", "تذكير بالدعاء لبلال محسن")
                putExtra("body", "اللهم اغفر لبلال محسن وارحمه وأسكنه فسيح جناتك.")
                putExtra("kind", "dua")
            }
            this@MainActivity.sendBroadcast(intent)
        }
    }

    companion object {
        fun scheduleDuaReminders(context: Context, times: List<Int>? = null) {
            val stored = context.getSharedPreferences(ReminderReceiver.PREFS, Context.MODE_PRIVATE)
            val enabled = stored.getBoolean("dua_alerts_enabled", true)
            val actualTimes = times ?: (0..2).map { stored.getInt("dua_minute_$it", listOf(8 * 60, 14 * 60, 20 * 60)[it]) }
            actualTimes.forEachIndexed { index, minute ->
                if (enabled) scheduleDaily(context, 201 + index, minute, "تذكير بالدعاء لبلال محسن", "اللهم اغفر لبلال محسن وارحمه، وعافه واعف عنه، وأسكنه فسيح جناتك.", "dua")
                else cancelDaily(context, 201 + index)
            }
        }

        fun cancelDaily(context: Context, id: Int) {
            val intent = Intent(context, ReminderReceiver::class.java)
            val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
            pending.cancel()
        }

        fun scheduleDaily(context: Context, id: Int, minuteOfDay: Int, title: String, body: String, kind: String) {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, minuteOfDay / 60)
                set(Calendar.MINUTE, minuteOfDay % 60)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (!after(now)) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("alarm_id", id); putExtra("minute", minuteOfDay); putExtra("title", title); putExtra("body", body); putExtra("kind", kind)
            }
            val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pending)
                } else manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pending)
            } catch (_: SecurityException) { manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pending) }
        }
    }
}
