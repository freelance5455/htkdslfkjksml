package com.bilal.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

const val CHANNEL_PRAYER = "bilal_prayer_notifications"
const val CHANNEL_DUA = "bilal_dua_notifications"

fun createNotificationChannels(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(CHANNEL_PRAYER, "إشعارات الصلاة", NotificationManager.IMPORTANCE_HIGH).apply { description = "تنبيه عند دخول وقت الصلاة بصوت إشعارات الهاتف" })
        manager.createNotificationChannel(NotificationChannel(CHANNEL_DUA, "تذكير الدعاء لبلال", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "ثلاثة تذكيرات يومية بصوت إشعارات الهاتف" })
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("alarm_id", 201)
        val minute = intent.getIntExtra("minute", 8 * 60)
        val title = intent.getStringExtra("title") ?: "تذكير من بلال"
        val body = intent.getStringExtra("body") ?: "اللهم اغفر لبلال محسن وارحمه"
        val kind = intent.getStringExtra("kind") ?: "dua"
        createNotificationChannels(context)
        val openApp = PendingIntent.getActivity(context, 9000, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val channel = if (kind == "prayer") CHANNEL_PRAYER else CHANNEL_DUA
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, channel).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(body).setStyle(Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(openApp).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(openApp).build()
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(id, notification)
        // AlarmManager alarms are one-shot; queue the same event for tomorrow.
        MainActivity.scheduleDaily(context, id, minute, title, body, kind)
    }

    companion object { const val PREFS = "bilal_native_settings" }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        MainActivity.scheduleDuaReminders(context)
        val prefs = context.getSharedPreferences(ReminderReceiver.PREFS, Context.MODE_PRIVATE)
        val names = listOf("Fajr" to "الفجر", "Dhuhr" to "الظهر", "Asr" to "العصر", "Maghrib" to "المغرب", "Isha" to "العشاء")
        names.forEachIndexed { index, pair ->
            val minute = prefs.getInt("prayer_${pair.first}", -1)
            if (minute >= 0) MainActivity.scheduleDaily(context, 100 + index, minute, "حان وقت صلاة ${pair.second}", "حان الآن وقت صلاة ${pair.second}. تقبّل الله طاعتك.", "prayer")
        }
    }
}
