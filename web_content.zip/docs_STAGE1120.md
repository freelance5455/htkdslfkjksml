# CPLS V2 — Stage 1120

## هدف
پایدارسازی Feed واقعی Futures بدون اینکه خطای یک کانال، کانال دیگر را متوقف کند.

## تغییرات
- بودجه خطا و backoff مربوط به Market و Order Book از هم جدا شد.
- شکست موقت Market دیگر باعث توقف Order Book نمی‌شود.
- شکست موقت Order Book دیگر باعث توقف Market نمی‌شود.
- آخرین Market سالم همچنان در cache می‌ماند.
- آخرین Order Book سالم همچنان در cache می‌ماند.
- timestamp آخرین tick واقعی Futures ثبت می‌شود.
- وضعیت خطا به‌صورت channel-specific به WebView ارسال می‌شود.
- سقف backoff همچنان ۳۰ ثانیه است تا در rate-limit شدن، درخواست‌ها به‌صورت انفجاری تکرار نشوند.
- مسیر رسمی Contract REST حفظ شد: `https://lbkperp.lbank.com/cfd/openApi/v1/pub/...`.
- WebSocket Futures همچنان فقط Diagnostic است و تا وقتی فرمت subscription قابل اتکا پیدا نشود، پیام حدسی ارسال نمی‌شود.

## نکته تست
محیط ساخت فعلی دسترسی DNS/شبکه خروجی مستقیم به `lbkperp.lbank.com` ندارد؛ بنابراین تست live از داخل این محیط ممکن نیست و نسخه را به‌عنوان «تست‌شده روی LBank» اعلام نمی‌کنیم. تست واقعی باید روی گوشی/شبکه کاربر انجام شود.
