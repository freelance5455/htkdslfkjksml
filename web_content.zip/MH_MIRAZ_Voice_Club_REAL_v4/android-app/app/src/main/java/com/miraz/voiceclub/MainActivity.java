package com.miraz.voiceclub;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private FirebaseAuth auth;
    private String phoneVerificationId;
    private PhoneAuthProvider.ForceResendingToken resendToken;
    private static final int MIC=71;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        auth = FirebaseAuth.getInstance();
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(final PermissionRequest r){runOnUiThread(()->r.grant(r.getResources()));}});
        web.addJavascriptInterface(new FirebaseBridge(), "FirebaseBridge");
        web.loadUrl("file:///android_asset/www/index.html");
    }

    private void sendCallback(String cb, JSONObject obj){
        String js="javascript:"+cb+"("+JSONObject.quote(obj.toString())+")";
        runOnUiThread(()->web.evaluateJavascript(js,null));
    }
    private JSONObject okToken(FirebaseUser u) throws Exception {
        return new JSONObject().put("ok",true).put("idToken","");
    }
    private void tokenResult(FirebaseUser u, String cb, String name){
        if(u==null){ try{sendCallback(cb,new JSONObject().put("ok",false).put("error","AUTH_FAILED"));}catch(Exception ignored){} return; }
        u.getIdToken(true).addOnCompleteListener(task->{
            try{
                if(!task.isSuccessful() || task.getResult()==null){ sendCallback(cb,new JSONObject().put("ok",false).put("error","TOKEN_FAILED")); return; }
                sendCallback(cb,new JSONObject().put("ok",true).put("idToken",task.getResult().getToken()).put("name",name==null?"":name));
            }catch(Exception e){ try{sendCallback(cb,new JSONObject().put("ok",false).put("error","TOKEN_FAILED"));}catch(Exception ignored){} }
        });
    }

    public class FirebaseBridge {
        @JavascriptInterface public void signInEmail(String raw, String cb){
            try{
                JSONObject o=new JSONObject(raw); String email=o.optString("email"); String password=o.optString("password");
                if(email.isEmpty()){sendCallback(cb,new JSONObject().put("ok",false).put("error","EMAIL_INVALID"));return;}
                auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(t->{
                    if(t.isSuccessful()) tokenResult(auth.getCurrentUser(),cb,auth.getCurrentUser()!=null?auth.getCurrentUser().getDisplayName():"");
                    else { String code=t.getException()!=null?t.getException().getMessage():"INVALID_LOGIN"; sendSafe(cb,code); }
                });
            }catch(Exception e){sendSafe(cb,"AUTH_FAILED");}
        }
        @JavascriptInterface public void createEmail(String raw, String cb){
            try{
                JSONObject o=new JSONObject(raw); String email=o.optString("email"); String password=o.optString("password"); String name=o.optString("name");
                auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(t->{
                    if(t.isSuccessful()){
                        FirebaseUser u=auth.getCurrentUser();
                        if(u!=null && name!=null && !name.isEmpty()){
                            com.google.firebase.auth.UserProfileChangeRequest req=new com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(name).build();
                            u.updateProfile(req).addOnCompleteListener(x->tokenResult(u,cb,name));
                        } else tokenResult(u,cb,name);
                    } else { String msg=t.getException()!=null?t.getException().getMessage():"EMAIL_EXISTS"; sendSafe(cb,msg); }
                });
            }catch(Exception e){sendSafe(cb,"AUTH_FAILED");}
        }
        @JavascriptInterface public void sendPhoneOtp(String raw, String cb){
            try{ JSONObject o=new JSONObject(raw); String phone=o.optString("phone"); if(phone.isEmpty()){sendSafe(cb,"PHONE_INVALID");return;}
                PhoneAuthOptions options=PhoneAuthOptions.newBuilder(auth).setPhoneNumber(phone).setTimeout(60L, TimeUnit.SECONDS).setActivity(MainActivity.this).setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
                    @Override public void onVerificationCompleted(PhoneAuthCredential credential){ auth.signInWithCredential(credential).addOnCompleteListener(t->{ if(t.isSuccessful()) tokenResult(auth.getCurrentUser(),cb,auth.getCurrentUser()!=null?auth.getCurrentUser().getDisplayName():""); else sendSafe(cb,"PHONE_AUTH_FAILED"); }); }
                    @Override public void onVerificationFailed(com.google.firebase.FirebaseException e){ sendSafe(cb,e.getMessage()); }
                    @Override public void onCodeSent(String id, PhoneAuthProvider.ForceResendingToken token){ phoneVerificationId=id; resendToken=token; sendCallback(cb,new JSONObject().put("ok",true).put("otpSent",true)); }
                }).build(); PhoneAuthProvider.verifyPhoneNumber(options);
            }catch(Exception e){sendSafe(cb,"PHONE_AUTH_FAILED");}
        }
        @JavascriptInterface public void verifyPhoneOtp(String raw, String cb){
            try{ JSONObject o=new JSONObject(raw); String code=o.optString("code"); if(phoneVerificationId==null){sendSafe(cb,"OTP_NOT_SENT");return;} PhoneAuthCredential cred=PhoneAuthProvider.getCredential(phoneVerificationId,code); auth.signInWithCredential(cred).addOnCompleteListener(t->{ if(t.isSuccessful()) tokenResult(auth.getCurrentUser(),cb,auth.getCurrentUser()!=null?auth.getCurrentUser().getDisplayName():""); else sendSafe(cb,"OTP_INVALID"); }); }catch(Exception e){sendSafe(cb,"OTP_INVALID");}
        }
        @JavascriptInterface public void preparePhone(String raw, String cb){ sendCallback(cb,new JSONObject().put("ok",true)); }
        @JavascriptInterface public void signInGoogle(String cb){ sendSafe(cb,"GOOGLE_SIGNIN_NEEDS_OAUTH_CONFIG"); }
        private void sendSafe(String cb,String error){
            try{String e=error==null?"AUTH_FAILED":error; if(e.contains("already in use")) e="EMAIL_EXISTS"; else if(e.contains("badly formatted")) e="EMAIL_INVALID"; else if(e.contains("no user record")) e="EMAIL_NOT_FOUND"; else if(e.contains("password is invalid")) e="INVALID_PASSWORD"; sendCallback(cb,new JSONObject().put("ok",false).put("error",e));}catch(Exception ignored){}
        }
    }

    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
