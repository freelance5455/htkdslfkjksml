const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
let server=localStorage.getItem('vc_server')||'http://10.0.2.2:8080';
let token=localStorage.getItem('vc_token');
let me=null,ws=null,currentRoom=null,roomPeers=new Map(),localStream=null,activeChat=null;
let audioCtx=null,localAnalyser=null,speakRaf=null,speakingUids=new Set();
const remoteAnalysers=new Map(); // uid -> {analyser, data, src}
const themes={moonlight:'Moonlight',ocean:'Ocean Blue',forest:'Forest Green',sunset:'Sunset Gold',cyber:'Cyber Neon'};

async function api(path,opt={}){
  const h={'Content-Type':'application/json',...(opt.headers||{})};
  if(token)h.Authorization='Bearer '+token;
  const r=await fetch(server+path,{...opt,headers:h});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(d.error||'REQUEST_FAILED');
  return d;
}
function toast(s){
  const x=document.createElement('div');
  x.className='toast';
  x.textContent=s;
  document.body.appendChild(x);
  setTimeout(()=>x.remove(),2200);
}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function go(id){
  $$('.screen').forEach(x=>x.classList.remove('active'));
  $('#'+id).classList.add('active');
  $$('nav button').forEach(x=>x.classList.toggle('active',x.dataset.go===id));
}
function modal(html){$('#modalBox').innerHTML=html;$('#modal').classList.remove('hidden')}
function closeModal(){$('#modal').classList.add('hidden')}
function fileData(file){
  return new Promise((res,rej)=>{
    if(!file)return res('');
    if(file.size>2*1024*1024)return rej(new Error('IMAGE_TOO_LARGE'));
    const r=new FileReader();
    r.onload=()=>res(r.result);
    r.onerror=rej;
    r.readAsDataURL(file);
  });
}

/* ========== AUTH — no preview, no fake user ========== */
function showAuth(){
  $('#login').classList.remove('hidden');
  $('#app').classList.add('hidden');
}
function showApp(){
  $('#login').classList.add('hidden');
  $('#app').classList.remove('hidden');
}

$('#tabLogin').onclick=()=>{
  $('#tabLogin').classList.add('active');
  $('#tabRegister').classList.remove('active');
  $('#loginForm').classList.remove('hidden');
  $('#registerForm').classList.add('hidden');
};
$('#tabRegister').onclick=()=>{
  $('#tabRegister').classList.add('active');
  $('#tabLogin').classList.remove('active');
  $('#registerForm').classList.remove('hidden');
  $('#loginForm').classList.add('hidden');
};

function nativeFirebase(action, payload={}){
  return new Promise((resolve,reject)=>{
    if(!window.FirebaseBridge || !window.FirebaseBridge[action]){
      reject(new Error('FIREBASE_BRIDGE_UNAVAILABLE')); return;
    }
    const cb='__fbcb_'+Date.now()+'_'+Math.random().toString(36).slice(2);
    window[cb]=(raw)=>{
      try{
        const d=typeof raw==='string'?JSON.parse(raw):raw;
        delete window[cb];
        d?.ok?resolve(d):reject(new Error(d?.error||'FIREBASE_AUTH_FAILED'));
      }catch(e){delete window[cb];reject(e)}
    };
    try{ window.FirebaseBridge[action](JSON.stringify(payload), cb); }
    catch(e){delete window[cb];reject(e)}
  });
}

async function finishFirebaseAuth(d, extra={}){
  if(!d?.idToken) throw new Error('FIREBASE_TOKEN_MISSING');
  const body={idToken:d.idToken,...extra};
  const r=await fetch(server+'/api/auth/firebase',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||'FIREBASE_LOGIN_FAILED');
  token=data.token;
  localStorage.setItem('vc_token',token);
  me=data.user;
  await afterLogin();
}

$('#loginBtn').onclick=async()=>{
  const username=$('#username').value.trim();
  const password=$('#password').value;
  if(!username||!password){toast('Gmail/Email ও Password দিন');return}
  try{
    const d=await nativeFirebase('signInEmail', {email:username,password});
    await finishFirebaseAuth(d);
  }catch(e){
    const m=String(e.message||e);
    toast(m==='EMAIL_NOT_FOUND'||m==='INVALID_PASSWORD'?'ভুল Gmail/Email বা password':m==='EMAIL_INVALID'?'সঠিক Gmail/Email দিন':(m||'Login ব্যর্থ'));
  }
};

$('#registerBtn').onclick=async()=>{
  const email=$('#regUsername').value.trim();
  const name=$('#regName').value.trim();
  const password=$('#regPassword').value;
  const age=Number($('#regAge')?.value)||null;
  if(!email||!name||!password){toast('Gmail/Email, নাম ও Password দিন');return}
  if(!/^\S+@\S+\.\S+$/.test(email)){toast('একটি সঠিক Gmail/Email দিন');return}
  if(password.length<6){toast('Password কমপক্ষে ৬ অক্ষর');return}
  try{
    const d=await nativeFirebase('createEmail', {email,password,name});
    await finishFirebaseAuth(d,{name,age});
  }catch(e){
    const m=String(e.message||e);
    toast(m==='EMAIL_EXISTS'?'এই Gmail/Email ইতিমধ্যে আছে':(m||'Register ব্যর্থ'));
  }
};

// ===== AUTH METHOD SWITCH + PHONE OTP =====
function authTab(boxA,boxB,tabA,tabB){ document.querySelector(boxA)?.classList.remove('hidden'); document.querySelector(boxB)?.classList.add('hidden'); document.querySelector(tabA)?.classList.add('active'); document.querySelector(tabB)?.classList.remove('active'); }
$('#loginEmailTab')?.addEventListener('click',()=>authTab('#loginEmailBox','#loginPhoneBox','#loginEmailTab','#loginPhoneTab'));
$('#loginPhoneTab')?.addEventListener('click',()=>authTab('#loginPhoneBox','#loginEmailBox','#loginPhoneTab','#loginEmailTab'));
$('#regEmailTab')?.addEventListener('click',()=>authTab('#regEmailBox','#regPhoneBox','#regEmailTab','#regPhoneTab'));
$('#regPhoneTab')?.addEventListener('click',()=>authTab('#regPhoneBox','#regEmailBox','#regPhoneTab','#regEmailTab'));
let loginVerifier=null, regVerifier=null;
async function setupPhoneVerifier(containerId){ return await nativeFirebase('preparePhone', {container:containerId}); }
$('#sendLoginOtp')?.addEventListener('click',async()=>{ try{ const phone=$('#loginPhone').value.trim(); if(!/^\+\d{8,15}$/.test(phone)){toast('Phone number +countrycode সহ দিন');return} await nativeFirebase('sendPhoneOtp',{phone,container:'loginRecaptcha'}); $('#loginOtp').classList.remove('hidden'); $('#verifyLoginOtp').classList.remove('hidden'); toast('OTP পাঠানো হয়েছে'); }catch(e){toast(String(e.message||e))} });
$('#verifyLoginOtp')?.addEventListener('click',async()=>{ try{ const code=$('#loginOtp').value.trim(); if(code.length<4){toast('OTP দিন');return} const d=await nativeFirebase('verifyPhoneOtp',{code}); await finishFirebaseAuth(d); }catch(e){toast(String(e.message||e))} });
$('#sendRegOtp')?.addEventListener('click',async()=>{ try{ const phone=$('#regPhone').value.trim(), name=$('#regPhoneName').value.trim(), age=Number($('#regPhoneAge').value)||null; if(!/^\+\d{8,15}$/.test(phone)){toast('Phone number +countrycode সহ দিন');return} if(!name){toast('নাম দিন');return} await nativeFirebase('sendPhoneOtp',{phone,container:'regRecaptcha',name,age}); $('#regOtp').classList.remove('hidden'); $('#verifyRegOtp').classList.remove('hidden'); toast('OTP পাঠানো হয়েছে'); }catch(e){toast(String(e.message||e))} });
$('#verifyRegOtp')?.addEventListener('click',async()=>{ try{ const code=$('#regOtp').value.trim(), name=$('#regPhoneName').value.trim(), age=Number($('#regPhoneAge').value)||null; const d=await nativeFirebase('verifyPhoneOtp',{code}); await finishFirebaseAuth(d,{name,age}); }catch(e){toast(String(e.message||e))} });

function setServerUrl(){
  const v=prompt('Backend server URL (যেমন http://YOUR_IP:8080)',server);
  if(v){
    server=v.replace(/\/$/,'');
    localStorage.setItem('vc_server',server);
    toast('Server URL সেভ হয়েছে');
  }
}
$('#serverBtnAuth').onclick=setServerUrl;
$('#serverBtn').onclick=setServerUrl;

async function afterLogin(){
  showApp();
  connectWS();
  await loadProfile();
  await loadRooms();
}

async function boot(){
  if(!token){
    showAuth();
    return;
  }
  try{
    me=(await api('/api/me')).user;
    await afterLogin();
  }catch{
    token=null;
    localStorage.removeItem('vc_token');
    showAuth();
  }
}

function logout(reload=true){
  token=null;
  me=null;
  localStorage.removeItem('vc_token');
  try{ws?.close()}catch{}
  if(reload)location.reload();
  else showAuth();
}

/* ========== WebSocket ========== */
function connectWS(){
  try{
    ws&&ws.close();
    const wsUrl=server.replace(/^http/,'ws')+'/ws?token='+encodeURIComponent(token);
    ws=new WebSocket(wsUrl);
    ws.onmessage=e=>handleWS(JSON.parse(e.data));
    ws.onclose=()=>setTimeout(()=>token&&connectWS(),2500);
  }catch{}
}

function handleWS(m){
  if(m.type==='private_message'){
    if(activeChat&&(m.message.senderId===activeChat||m.message.receiverId===activeChat)){
      loadChatMessages(activeChat);
    }
    loadChats();
  }else if(m.type==='room_state'&&currentRoom?.id===m.room.id){
    currentRoom=m.room;
    renderSeats();
    $('#rcount').textContent=m.room.currentUsers+'/15';
  }else if(m.type==='room_message'&&currentRoom?.id===m.message.roomId){
    appendRoomMessage(m.message);
  }else if(m.type==='peer_joined'&&currentRoom){
    startPeer(m.uid,true);
  }else if(m.type==='peer_left'&&currentRoom){
    removePeer(m.uid);
  }else if(m.type==='webrtc_offer'){
    receiveOffer(m);
  }else if(m.type==='webrtc_answer'){
    receiveAnswer(m);
  }else if(m.type==='ice_candidate'){
    receiveIce(m);
  }else if(m.type==='force_mute'||m.type==='force_mute_all'){
    if(localStream){
      localStream.getAudioTracks().forEach(t=>t.enabled=!m.muted);
      $('#mic').textContent=m.muted?'🔇':'🎤';
    }
    toast(m.muted?'Admin muted your mic':'Admin unmuted your mic');
  }else if(m.type==='kicked'){
    toast('আপনাকে রুম থেকে রিমুভ করা হয়েছে');
    if(currentRoom){
      for(const [id,p] of roomPeers){p.close();removePeer(id)}
      currentRoom=null;
      if(localStream){localStream.getTracks().forEach(t=>t.stop());localStream=null}
      go('home');
      loadRooms();
    }
  }
}

/* ========== Profile ========== */
async function loadProfile(){
  const d=(await api('/api/me')).user;
  me=d;
  $('#pname').textContent=d.name;
  $('#pmeta').textContent=(d.language||'বাংলা')+' · '+(d.age||'Age not set');
  $('#langV').textContent=d.language||'বাংলা';
  $('#ageV').textContent=d.age||'-';
  $('#notifV').textContent=d.notifications?'ON':'OFF';
  $('#privacyV').textContent=d.privacy||'public';
  if(d.photoURL){
    $('#avatar').style.backgroundImage=`url(${d.photoURL})`;
    $('#avatar').textContent='';
  }else{
    $('#avatar').style.backgroundImage='';
    $('#avatar').textContent=(d.name||'U')[0].toUpperCase();
  }
  if(d.coverURL)$('#cover').style.backgroundImage=`url(${d.coverURL})`;
  else $('#cover').style.backgroundImage='';
}

$('#editProfile').onclick=()=>{
  modal(`<h3 class="shimmer-text">✏️ Edit Profile</h3>
    <input id="en" placeholder="Name" value="${esc(me.name||'')}">
    <input id="ea" type="number" min="13" placeholder="Age" value="${me.age||''}">
    <label>Profile photo <input id="ep" type="file" accept="image/*"></label>
    <label>Cover / Banner <input id="ec" type="file" accept="image/*"></label>
    <button id="saveP" class="primary wide">Save Changes</button>
    <button id="closeM" class="wide secondary">Cancel</button>`);
  setTimeout(()=>{
    const btn=document.getElementById('saveP');
    if(!btn)return;
    btn.onclick=async()=>{
      try{
        const photo=await fileData(document.getElementById('ep')?.files?.[0]);
        const cover=await fileData(document.getElementById('ec')?.files?.[0]);
        const nameVal=(document.getElementById('en')?.value||'').trim()||'User';
        const ageVal=Number(document.getElementById('ea')?.value)||null;
        const patch={name:nameVal,age:ageVal};
        if(photo)patch.photoURL=photo;
        if(cover)patch.coverURL=cover;
        await api('/api/me',{method:'PATCH',body:JSON.stringify(patch)});
        await loadProfile();
        closeModal();
        toast('Profile updated');
      }catch(e){toast(e.message||'Failed to save')}
    };
  },50);
};
$('#coverEdit').onclick=()=>$('#editProfile').click();
$('#avatarEdit').onclick=()=>$('#editProfile').click();
$('#profileShare').onclick=()=>{
  navigator.clipboard?.writeText('Social Media • '+ (me?.name||'User')).catch(()=>{});
  toast('Profile share text copied');
};

$('#lang').onclick=()=>modal(`<h3>🌐 Language</h3>
  <div class="settingChoices">
    <button onclick="setLang('বাংলা')">বাংলা</button>
    <button onclick="setLang('English')">English</button>
    <button onclick="setLang('Hindi')">Hindi</button>
  </div>
  <button id="closeM" class="wide secondary">Cancel</button>`);
window.setLang=async v=>{
  await api('/api/me',{method:'PATCH',body:JSON.stringify({language:v})});
  await loadProfile();
  closeModal();
};
$('#ageSetting').onclick=()=>$('#editProfile').click();
$('#notif').onclick=async()=>{
  await api('/api/me',{method:'PATCH',body:JSON.stringify({notifications:!me.notifications})});
  await loadProfile();
};
$('#privacy').onclick=()=>modal(`<h3>🔐 Privacy</h3>
  <div class="settingChoices">
    <button onclick="setPrivacy('public')">Public</button>
    <button onclick="setPrivacy('private')">Private</button>
  </div>
  <button id="closeM" class="wide secondary">Cancel</button>`);
window.setPrivacy=async v=>{
  await api('/api/me',{method:'PATCH',body:JSON.stringify({privacy:v})});
  await loadProfile();
  closeModal();
};
$('#account').onclick=()=>modal(`<h3>👤 Account</h3>
  <p>Username: <b>${esc(me.username||'')}</b></p>
  <p>Account ID: ${esc(me.id)}</p>
  <p class="hint">রিয়েল অ্যাকাউন্ট — সব ডাটা সার্ভারে সেভ হয়।</p>
  <button id="closeM" class="wide secondary">Close</button>`);

/* ========== Rooms / Broadcast — always real ========== */
async function loadRooms(){
  try{
    const {rooms}=await api('/api/rooms');
    $('#rooms').innerHTML=rooms.length?rooms.map(r=>`<div class="roomCard ${r.theme||''}" data-id="${r.id}">
      <div class="roomCardCover" style="background-image:url('${r.coverURL||'home-hero-new.jpg'}')"></div>
      <div class="roomCardBody">
        <span class="pill">● LIVE</span>
        <h3>${esc(r.name)}</h3>
        <p>${esc(r.topic||r.description||'Open Conversation')}</p>
        <div class="meta"><span>🎤 ${r.currentUsers||0}/15 online</span><span>👥 ${r.memberCount||0} members</span></div>
      </div>
    </div>`).join(''):'<div class="emptyState">এখন কোনো live room নেই। ＋ দিয়ে নতুন Broadcast তৈরি করুন।</div>';
  }catch(e){
    $('#rooms').innerHTML='<div class="emptyState">সার্ভার কানেক্ট হয়নি। Settings → Server URL চেক করুন।</div>';
    toast('Server connect হয়নি');
  }
}

$('#rooms').onclick=e=>{
  const c=e.target.closest('.roomCard');
  if(c)openRoom(c.dataset.id);
};

$('#createRoom').onclick=()=>{
  let chosenTheme='moonlight';
  let coverData='';
  modal(`<h3 class="shimmer-text">＋ Create Broadcast</h3>
    <input id="rn" placeholder="Broadcast / Room name *">
    <input id="rt" placeholder="Topic (e.g. বন্ধুদের আড্ডা)">
    <textarea id="rd" placeholder="Description / বিবরণ" rows="3" style="width:100%;margin:6px 0;padding:12px;border-radius:13px;border:1px solid rgba(255,255,255,.1);background:#0a0a12;color:#fff;resize:vertical"></textarea>
    <label style="display:block;color:#a0a0b0;font-size:12px;margin:8px 0 4px">Broadcast Cover Photo</label>
    <input id="rc" type="file" accept="image/*">
    <div id="coverPreview" style="margin:8px 0;min-height:80px;border-radius:14px;background:#111;border:1px dashed rgba(155,92,255,.3);display:grid;place-items:center;color:#666;font-size:12px;overflow:hidden">Gallery থেকে ছবি সিলেক্ট করুন</div>
    <div class="themeGrid" style="margin-top:12px">${Object.entries(themes).map(([k,v])=>`<button class="themePick ${k}" data-theme="${k}"><span>${v}</span></button>`).join('')}</div>
    <button id="makeRoom" class="primary wide">Create Broadcast</button>
    <button id="closeM" class="wide secondary">Cancel</button>`);
  $('#rc')?.addEventListener('change',async e=>{
    const f=e.target.files?.[0];
    if(!f)return;
    try{
      coverData=await fileData(f);
      $('#coverPreview').innerHTML=`<img src="${coverData}" style="width:100%;height:120px;object-fit:cover;border-radius:14px">`;
    }catch(err){toast(err.message)}
  });
  $$('[data-theme]').forEach(b=>b.onclick=()=>{
    chosenTheme=b.dataset.theme;
    $$('[data-theme]').forEach(x=>x.style.outline='');
    b.style.outline='2px solid #ffd700';
  });
  $('#makeRoom').onclick=async()=>{
    const name=$('#rn').value.trim();
    if(!name)return toast('Broadcast name required');
    try{
      const body={name,topic:$('#rt').value.trim(),description:$('#rd').value.trim(),coverURL:coverData,theme:chosenTheme};
      const d=await api('/api/rooms',{method:'POST',body:JSON.stringify(body)});
      closeModal();
      openRoom(d.room.id);
      loadRooms();
    }catch(e){toast(e.message||'Room create ব্যর্থ')}
  };
};

function isRoomOwner(){
  return currentRoom&&me&&(currentRoom.ownerId===me.id||currentRoom.owner_id===me.id);
}

function applyRoomUI(room){
  currentRoom=room;
  $('#rname').textContent=room.name||'Room';
  $('#rtopic').textContent=room.topic||room.description||'';
  $('#rtheme').textContent=(themes[room.theme]||room.theme||'MOONLIGHT').toUpperCase();
  const bg=$('#roomBg');
  if(room.coverURL){
    bg.className='roomBg hasCover';
    bg.style.backgroundImage=`url(${room.coverURL})`;
  }else{
    bg.style.backgroundImage='';
    bg.className='roomBg '+(themes[room.theme]?room.theme:'moonlight');
  }
  if(room.currentUsers!=null)$('#rcount').textContent=(room.currentUsers||0)+'/15';
  const mb=$('#rMemberCount'); if(mb) mb.textContent=(room.memberCount||0)+' members';
  const fb=$('#followOwnerBtn'); if(fb) fb.textContent=room.ownerId===me?.id?'Your Broadcast':(room.isFollowing?'✓ Following':'＋ Follow Owner');
  const jb=$('#joinMemberBtn'); if(jb) jb.textContent=room.isMember?'✓ Joined':'👥 Join Broadcast';
  renderSeats();
}

document.addEventListener('click',async e=>{
  if(e.target.id==='joinMemberBtn'){
    if(!currentRoom)return;
    try{ const d=await api('/api/rooms/'+currentRoom.id+'/member',{method:'POST'}); currentRoom.memberCount=d.memberCount; currentRoom.isMember=true; applyRoomUI(currentRoom); toast('Broadcast member হিসেবে যুক্ত হয়েছেন'); }catch(err){toast(err.message||'Join failed')}
  }
  if(e.target.id==='followOwnerBtn'){
    if(!currentRoom||currentRoom.ownerId===me?.id)return;
    try{
      if(currentRoom.isFollowing){ await api('/api/users/'+currentRoom.ownerId+'/follow',{method:'DELETE'}); currentRoom.isFollowing=false; toast('Unfollow করা হয়েছে'); }
      else { await api('/api/users/'+currentRoom.ownerId+'/follow',{method:'POST'}); currentRoom.isFollowing=true; toast('Owner-কে Follow করা হয়েছে'); }
      applyRoomUI(currentRoom);
    }catch(err){toast(err.message||'Follow failed')}
  }
});

let _prevSeatUids=new Set();
function renderSeats(){
  const seats=currentRoom?.seats||[];
  const map={};
  seats.forEach(s=>map[s.seat]=s);
  const nowUids=new Set(seats.map(s=>String(s.uid)));
  // detect new joiners for entry effect
  if(_prevSeatUids.size>0){
    for(const s of seats){
      if(!_prevSeatUids.has(String(s.uid)) && String(s.uid)!==String(me?.id)){
        showEntryEffect(s);
      }
    }
  }
  _prevSeatUids=nowUids;

  let html='';
  for(let i=1;i<=15;i++){
    const s=map[i];
    if(s){
      const mine=s.uid===me.id;
      html+=`<div class="seat ${s.muted?'muted':''} ${mine?'mine':''}" data-seat="${i}" data-uid="${s.uid}">
        <div class="seatAvatar" style="${s.photoURL?`background-image:url(${s.photoURL})`:''}">${s.photoURL?'':esc((s.name||'U')[0])}</div>
        <div class="seatName">${esc(s.name||'User')}${s.muted?' 🔇':''}</div>
      </div>`;
    }else{
      html+=`<div class="seat empty" data-seat="${i}"><div class="seatAvatar">+</div><div class="seatName">Empty</div></div>`;
    }
  }
  $('#seats').innerHTML=html;
  $$('#seats .seat.empty').forEach(el=>el.onclick=()=>joinSeat(Number(el.dataset.seat)));
  // occupied seats: long-press / click opens emoji reaction or gift
  $$('#seats .seat:not(.empty)').forEach(el=>{
    el.onclick=(e)=>{
      if(el.classList.contains('mine'))return;
      const seat=Number(el.dataset.seat);
      const uid=el.dataset.uid;
      const name=el.querySelector('.seatName')?.textContent?.replace(' 🔇','')||'User';
      // quick menu
      modal(`<h3 class="shimmer-text">${esc(name)}</h3>
        <button id="reactToSeat" class="wide primary" style="margin:8px 0">😊 Emoji রিঅ্যাক্ট</button>
        <button id="giftToSeat" class="wide" style="background:linear-gradient(135deg,#3a2a10,#1a1510);color:#ffc107;margin-bottom:8px">🎁 Gift দাও</button>
        <button id="closeM" class="wide secondary">বন্ধ</button>`);
      $('#reactToSeat').onclick=()=>{closeModal();openEmojiPicker(seat)};
      $('#giftToSeat').onclick=()=>{closeModal();openGiftPicker(uid,name)};
    };
  });
  // re-apply speaking glow after re-render
  speakingUids.forEach(uid=>{
    const el=document.querySelector(`.seat[data-uid="${uid}"]`);
    if(el)el.classList.add('speaking');
  });
}

function showEntryEffect(user){
  const ov=$('#entryOverlay');
  if(!ov)return;
  const letter=esc((user.name||'U')[0]);
  const photo=user.photoURL?`style="background-image:url(${user.photoURL})"`:'';
  ov.innerHTML=`<div class="entryCard">
    <div class="entryAvatar" ${photo}>${user.photoURL?'':letter}</div>
    <h3>✨ ${esc(user.name||'User')} ✨</h3>
    <p>রুম এ প্রবেশ করেছে!</p>
  </div>`;
  ov.classList.remove('hidden');
  // welcome message in comments
  appendRoomMessage({
    name:'System',
    text:`🎉 ওয়েলকাম ${user.name||'User'}! রুমে স্বাগতম। গিফট দিয়ে অভ্যর্থনা জানাও 🎁`,
    kind:'welcome'
  });
  setTimeout(()=>{ov.classList.add('hidden');ov.innerHTML=''},2800);
}


/* ===== Speaking visual effect (audio level) ===== */
function ensureAudioCtx(){
  if(!audioCtx){
    audioCtx=new (window.AudioContext||window.webkitAudioContext)();
  }
  if(audioCtx.state==='suspended')audioCtx.resume().catch(()=>{});
  return audioCtx;
}

function startLocalSpeakDetect(){
  stopLocalSpeakDetect();
  if(!localStream)return;
  try{
    const ctx=ensureAudioCtx();
    const src=ctx.createMediaStreamSource(localStream);
    localAnalyser=ctx.createAnalyser();
    localAnalyser.fftSize=256;
    localAnalyser.smoothingTimeConstant=0.7;
    src.connect(localAnalyser);
    const data=new Uint8Array(localAnalyser.frequencyBinCount);
    const loop=()=>{
      speakRaf=requestAnimationFrame(loop);
      if(!localAnalyser||!localStream)return;
      const track=localStream.getAudioTracks()[0];
      if(!track||!track.enabled){
        setSpeaking(me?.id,false);
        pollRemoteSpeaking();
        return;
      }
      localAnalyser.getByteFrequencyData(data);
      let sum=0;
      for(let i=0;i<data.length;i++)sum+=data[i];
      const avg=sum/data.length;
      // threshold ~18–25 works for most mics
      setSpeaking(me?.id, avg>20);
      pollRemoteSpeaking();
    };
    loop();
  }catch(e){console.warn('speak detect',e)}
}

function stopLocalSpeakDetect(){
  if(speakRaf){cancelAnimationFrame(speakRaf);speakRaf=null}
  localAnalyser=null;
  if(me)setSpeaking(me.id,false);
}

function attachRemoteSpeakDetect(uid,stream){
  try{
    detachRemoteSpeakDetect(uid);
    const ctx=ensureAudioCtx();
    const src=ctx.createMediaStreamSource(stream);
    const an=ctx.createAnalyser();
    an.fftSize=256;
    an.smoothingTimeConstant=0.75;
    src.connect(an);
    const data=new Uint8Array(an.frequencyBinCount);
    remoteAnalysers.set(String(uid),{analyser:an,data,src});
  }catch(e){console.warn('remote speak',e)}
}

function detachRemoteSpeakDetect(uid){
  remoteAnalysers.delete(String(uid));
  setSpeaking(uid,false);
}

function pollRemoteSpeaking(){
  remoteAnalysers.forEach((obj,uid)=>{
    try{
      obj.analyser.getByteFrequencyData(obj.data);
      let sum=0;
      for(let i=0;i<obj.data.length;i++)sum+=obj.data[i];
      const avg=sum/obj.data.length;
      setSpeaking(uid, avg>18);
    }catch{}
  });
}

// also poll remotes in the same raf as local if needed
function setSpeaking(uid,on){
  if(!uid)return;
  const key=String(uid);
  const was=speakingUids.has(key);
  if(on)speakingUids.add(key);else speakingUids.delete(key);
  if(was===on)return;
  // find seat by uid
  const el=document.querySelector(`.seat[data-uid="${key}"]`);
  if(el)el.classList.toggle('speaking',!!on);
}

async function openRoom(id){
  try{
    const d=await api('/api/rooms/'+id);
    applyRoomUI(d.room);
    $('#comments').innerHTML='';
    (d.messages||[]).forEach(appendRoomMessage);
    go('room');
    if(ws&&ws.readyState===1)ws.send(JSON.stringify({type:'room_join_signal',roomId:id}));
    try{
      localStream=await navigator.mediaDevices.getUserMedia({audio:true});
      localStream.getAudioTracks().forEach(t=>t.enabled=false);
    }catch{toast('Microphone permission লাগবে')}
    for(const s of currentRoom.seats||[])if(s.uid!==me.id)startPeer(s.uid,false);
  }catch(e){toast(e.message||'Room খোলা যায়নি')}
}

async function joinSeat(seat){
  if((currentRoom.seats||[]).some(s=>s.uid===me.id)){toast('তুমি ইতিমধ্যে seat-এ আছো');return}
  try{
    const d=await api('/api/rooms/'+currentRoom.id+'/join',{method:'POST',body:JSON.stringify({seat})});
    currentRoom=d.room;
    renderSeats();
    if(ws&&ws.readyState===1)ws.send(JSON.stringify({type:'room_join_signal',roomId:currentRoom.id}));
    if(localStream){
      localStream.getAudioTracks().forEach(t=>t.enabled=true);
      startLocalSpeakDetect();
    }
  }catch(e){toast(e.message==='SEAT_TAKEN'?'Seat নেওয়া যাচ্ছে না':'Seat unavailable')}
}

$('#leaveRoom').onclick=async()=>{
  if(currentRoom){
    try{await api('/api/rooms/'+currentRoom.id+'/leave',{method:'POST'})}catch{}
    if(ws&&ws.readyState===1)ws.send(JSON.stringify({type:'room_leave_signal',roomId:currentRoom.id}));
    for(const [id,p] of roomPeers){p.close();removePeer(id)}
    currentRoom=null;
    stopLocalSpeakDetect();
    remoteAnalysers.clear();
    speakingUids.clear();
    if(localStream){localStream.getTracks().forEach(t=>t.stop());localStream=null}
  }
  go('home');
  loadRooms();
};
$('#leaveBottom').onclick=()=>$('#leaveRoom').click();

$('#mic').onclick=async()=>{
  if(!localStream){toast('আগে seat নাও');return}
  const t=localStream.getAudioTracks()[0];
  const newEnabled=!t.enabled;
  t.enabled=newEnabled;
  $('#mic').textContent=newEnabled?'🎤':'🔇';
  if(newEnabled){
    startLocalSpeakDetect();
  }else{
    setSpeaking(me?.id,false);
  }
  if(currentRoom){
    try{await api('/api/rooms/'+currentRoom.id+'/self-mute',{method:'POST',body:JSON.stringify({muted:!newEnabled})})}catch{}
  }
};

/* WebRTC (voice later you can upgrade to SFU / Firebase) */
async function startPeer(uid,offer){
  if(!currentRoom||uid===me.id||roomPeers.has(uid))return;
  const pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
  roomPeers.set(uid,pc);
  if(localStream)localStream.getTracks().forEach(t=>pc.addTrack(t,localStream));
  pc.onicecandidate=e=>e.candidate&&ws&&ws.send(JSON.stringify({type:'ice_candidate',to:uid,candidate:e.candidate}));
  pc.ontrack=e=>{
    let a=document.getElementById('a_'+uid);
    if(!a){a=document.createElement('audio');a.id='a_'+uid;a.autoplay=true;document.body.appendChild(a)}
    a.srcObject=e.streams[0];
    if(e.streams[0])attachRemoteSpeakDetect(uid,e.streams[0]);
  };
  if(offer){
    const o=await pc.createOffer();
    await pc.setLocalDescription(o);
    ws.send(JSON.stringify({type:'webrtc_offer',to:uid,roomId:currentRoom.id,description:o}));
  }
  return pc;
}
async function receiveOffer(m){
  if(!currentRoom||(m.roomId&&m.roomId!==currentRoom.id))return;
  const pc=await startPeer(m.from,false);
  if(!pc)return;
  await pc.setRemoteDescription(m.description);
  const a=await pc.createAnswer();
  await pc.setLocalDescription(a);
  ws.send(JSON.stringify({type:'webrtc_answer',to:m.from,roomId:currentRoom.id,description:a}));
}
async function receiveAnswer(m){
  const pc=roomPeers.get(m.from);
  if(pc)await pc.setRemoteDescription(m.description);
}
async function receiveIce(m){
  const pc=roomPeers.get(m.from);
  if(pc)try{await pc.addIceCandidate(m.candidate)}catch{}
}
function removePeer(uid){
  const p=roomPeers.get(uid);
  if(p)p.close();
  roomPeers.delete(uid);
  document.getElementById('a_'+uid)?.remove();
  detachRemoteSpeakDetect(uid);
}

function appendRoomMessage(m){
  const d=document.createElement('div');
  let cls='comment';
  if(m.kind==='welcome')cls+=' welcome';
  if(m.kind==='gift')cls+=' giftMsg';
  if(m.kind==='pk')cls+=' pkMsg';
  d.className=cls;
  const avatar=esc((m.name||'U')[0]);
  d.innerHTML=`<div class="avatar mini">${avatar}</div><div><b>${esc(m.name||'User')}</b><p>${esc(m.text)}</p></div>`;
  $('#comments').appendChild(d);
  $('#comments').scrollTop=$('#comments').scrollHeight;
}

/* ===== Emoji data ===== */
const EMOJI_CATS={
  'হাসি':['😀','😁','😂','🤣','😃','😄','😅','😆','😉','😊','😋','😎','😍','🥰','😘','😗','😙','😚','🙂','🤗','🤩','🥳'],
  'রাগ':['😠','😡','🤬','😤','💢','😈','👿','💀','☠️','😾','🔥','⚡'],
  'ভালোবাসা':['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💕','💞','💓','💗','💖','💘','💝','💟','💌'],
  'গিফট':['🎁','🎀','🎉','🎊','🎈','🏆','🥇','🥈','🥉','⭐','🌟','✨','💎','👑'],
  'রিঅ্যাক্ট':['👍','👎','👏','🙌','🤝','✌️','🤞','🤟','🤘','👌','🤌','🤏','👋','💪','🫡','🫶'],
  'অন্যান্য':['😮','😲','😳','🥺','😢','😭','😱','😨','😰','😥','😓','🤔','🤨','😐','😑','😶','🙄','😏','😣','😖']
};
let emojiTargetSeat=null; // seat number or null = just insert in comment

function openEmojiPicker(targetSeat){
  emojiTargetSeat=targetSeat||null;
  let catsHtml=Object.keys(EMOJI_CATS).map((c,i)=>`<button type="button" data-ecat="${c}" class="${i===0?'active':''}">${c}</button>`).join('');
  let first=Object.keys(EMOJI_CATS)[0];
  let grid=EMOJI_CATS[first].map(e=>`<button type="button" data-em="${e}">${e}</button>`).join('');
  modal(`<h3 class="shimmer-text">😊 Emoji</h3>
    <div class="emojiCats">${catsHtml}</div>
    <div class="emojiGrid" id="emojiGrid">${grid}</div>
    <p style="font-size:11px;color:#888;margin:8px 0 0">${targetSeat?'সিটের উপর রিঅ্যাকশন যাবে':'কমেন্টে যোগ হবে'} · সিটে ক্লিক করেও পাঠাতে পারো</p>
    <button id="closeM" class="wide secondary" style="margin-top:10px">বন্ধ</button>`);
  $$('[data-ecat]').forEach(b=>b.onclick=()=>{
    $$('[data-ecat]').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    $('#emojiGrid').innerHTML=EMOJI_CATS[b.dataset.ecat].map(e=>`<button type="button" data-em="${e}">${e}</button>`).join('');
    bindEmojiClicks();
  });
  bindEmojiClicks();
}
function bindEmojiClicks(){
  $$('[data-em]').forEach(b=>b.onclick=()=>{
    const em=b.dataset.em;
    if(emojiTargetSeat!=null){
      showSeatReaction(emojiTargetSeat,em);
      // also post as public comment so everyone sees
      sendRoomText(`${em} (সিট ${emojiTargetSeat}-এ)`);
    }else{
      $('#comment').value=($('#comment').value||'')+em;
      $('#comment').focus();
    }
    closeModal();
  });
}

function showSeatReaction(seatNum,emoji){
  const seatEl=document.querySelector(`.seat[data-seat="${seatNum}"] .seatAvatar`);
  if(!seatEl)return;
  const r=document.createElement('span');
  r.className='seatReact';
  r.textContent=emoji;
  seatEl.appendChild(r);
  setTimeout(()=>r.remove(),2300);
}

$('#sendComment').onclick=async()=>{
  const t=$('#comment').value.trim();
  if(!t||!currentRoom)return;
  try{
    await api('/api/rooms/'+currentRoom.id+'/messages',{method:'POST',body:JSON.stringify({text:t})});
    $('#comment').value='';
  }catch(e){toast(e.message)}
};
async function sendRoomText(t){
  if(!t||!currentRoom)return;
  try{await api('/api/rooms/'+currentRoom.id+'/messages',{method:'POST',body:JSON.stringify({text:t})})}catch(e){toast(e.message)}
}
$('#emoji').onclick=()=>openEmojiPicker(null);
$('#emojiBottom').onclick=()=>openEmojiPicker(null);

/* ===== Gift ===== */
const GIFTS=[
  {id:'rose',icon:'🌹',name:'Rose',price:10},
  {id:'heart',icon:'💖',name:'Heart',price:20},
  {id:'diamond',icon:'💎',name:'Diamond',price:50},
  {id:'crown',icon:'👑',name:'Crown',price:100},
  {id:'rocket',icon:'🚀',name:'Rocket',price:80},
  {id:'star',icon:'⭐',name:'Star',price:30},
  {id:'cake',icon:'🎂',name:'Cake',price:40},
  {id:'trophy',icon:'🏆',name:'Trophy',price:150},
  {id:'fire',icon:'🔥',name:'Fire',price:25}
];
function openGiftPicker(toUid,toName){
  const seats=(currentRoom?.seats||[]).filter(s=>s.uid!==me.id);
  let targetHtml='';
  if(!toUid){
    targetHtml=`<p style="font-size:12px;color:#aaa;margin-bottom:8px">কার কাছে গিফট পাঠাবে?</p>
      <div class="pkSeatPick">${seats.map(s=>`<button type="button" data-gift-to="${s.uid}" data-gift-name="${esc(s.name||'User')}">${esc(s.name||'User')}</button>`).join('')||'<span style="color:#666">কেউ নেই</span>'}</div>`;
  }else{
    targetHtml=`<p style="font-size:13px;color:#ffc107;margin-bottom:8px">🎁 ${esc(toName||'User')}-কে গিফট</p>`;
  }
  const grid=GIFTS.map(g=>`<div class="giftItem" data-gift="${g.id}" data-icon="${g.icon}" data-name="${g.name}" data-price="${g.price}">
    <span class="gIcon">${g.icon}</span><span class="gName">${g.name}</span><span class="gPrice">${g.price} 🪙</span>
  </div>`).join('');
  modal(`<h3 class="shimmer-text">🎁 Gift / রিওয়ার্ড</h3>
    ${targetHtml}
    <div class="giftGrid">${grid}</div>
    <button id="closeM" class="wide secondary">বন্ধ</button>`);
  let selectedTo=toUid,selectedName=toName;
  $$('[data-gift-to]').forEach(b=>b.onclick=()=>{
    selectedTo=b.dataset.giftTo;selectedName=b.dataset.giftName;
    $$('[data-gift-to]').forEach(x=>x.style.borderColor='rgba(255,107,157,.3)');
    b.style.borderColor='#ffc107';
  });
  $$('[data-gift]').forEach(b=>b.onclick=async()=>{
    if(!selectedTo&&!toUid){toast('আগে একজন সিলেক্ট করো');return}
    const uid=selectedTo||toUid;
    const name=selectedName||toName||'User';
    const icon=b.dataset.icon,gname=b.dataset.name,price=b.dataset.price;
    // show on their seat if present
    const seat=(currentRoom.seats||[]).find(s=>String(s.uid)===String(uid));
    if(seat)showSeatReaction(seat.seat,icon);
    // public message so everyone sees
    const msg=`🎁 ${me.name} পাঠিয়েছে ${icon} ${gname} → ${name} (${price}🪙)`;
    try{
      await api('/api/rooms/'+currentRoom.id+'/messages',{method:'POST',body:JSON.stringify({text:msg})});
    }catch(e){
      // fallback local display
      appendRoomMessage({name:me.name,text:msg,kind:'gift'});
    }
    closeModal();
    toast(`${icon} ${gname} পাঠানো হয়েছে!`);
  });
}
$('#giftBtn').onclick=()=>openGiftPicker();
$('#giftBottom').onclick=()=>openGiftPicker();
$('#rewardBtn').onclick=()=>openGiftPicker(); // reward uses same gift UI

/* ===== PK ===== */
$('#pkBtn').onclick=()=>{
  if(!currentRoom)return;
  const seats=(currentRoom.seats||[]).filter(s=>s.uid!==me.id);
  if(seats.length<1){toast('PK করার জন্য অন্তত আর একজন লাগবে');return}
  modal(`<h3 class="shimmer-text">⚔ PK Battle</h3>
    <div class="pkPanel">
      <p style="font-size:12px;color:#aaa">কার সাথে PK করতে চাও?</p>
      <div class="pkVs">⚔ VS ⚔</div>
      <div class="pkSeatPick">${seats.map(s=>`<button type="button" data-pk="${s.uid}" data-pkname="${esc(s.name||'User')}">${esc(s.name||'User')}</button>`).join('')}</div>
      <p style="font-size:11px;color:#888;margin-top:8px">PK শুরু হলে রুমে ঘোষণা হবে</p>
    </div>
    <button id="closeM" class="wide secondary">বন্ধ</button>`);
  $$('[data-pk]').forEach(b=>b.onclick=async()=>{
    const name=b.dataset.pkname;
    const msg=`⚔ PK শুরু! ${me.name} VS ${name} — কে জিতবে? গিফট দিয়ে সাপোর্ট করো!`;
    try{
      await api('/api/rooms/'+currentRoom.id+'/messages',{method:'POST',body:JSON.stringify({text:msg})});
    }catch{
      appendRoomMessage({name:'System',text:msg,kind:'pk'});
    }
    closeModal();
    toast('PK শুরু হয়েছে!');
  });
};

$('#roomThemeBtn').onclick=()=>{
  if(!isRoomOwner()){toast('শুধু রুম মালিক থিম চেঞ্জ করতে পারেন');return}
  const cur=currentRoom?.theme||'moonlight';
  modal(`<h3 class="shimmer-text">🎨 Room Theme</h3>
    <div class="themeGrid">${Object.entries(themes).map(([k,v])=>`<button class="themePick ${k}" data-theme-pick="${k}"><span>${v}${k===cur?' ✓':''}</span></button>`).join('')}</div>
    <button id="closeM" class="wide secondary">Close</button>`);
  $$('[data-theme-pick]').forEach(b=>b.onclick=()=>applyTheme(b.dataset.themePick));
};
async function applyTheme(theme){
  if(!currentRoom||!isRoomOwner())return;
  try{
    const d=await api('/api/rooms/'+currentRoom.id,{method:'PATCH',body:JSON.stringify({theme})});
    currentRoom=d.room||currentRoom;
    $('#roomBg').className='roomBg '+theme;
    $('#rtheme').textContent=(themes[theme]||theme).toUpperCase();
    closeModal();
    toast('Theme applied');
  }catch(e){toast(e.message==='OWNER_ONLY'?'শুধু মালিক পরিবর্তন করতে পারেন':'Theme save হয়নি')}
}

$('#roomAdmin').onclick=()=>{
  if(!currentRoom)return;
  if(!isRoomOwner()){toast('শুধু রুম মালিক অ্যাডমিন প্যানেল খুলতে পারেন');return}
  const seats=(currentRoom.seats||[]).filter(s=>s.uid!==me.id);
  const seatList=seats.length
    ?seats.map(s=>`<div class="adminUserRow" style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.06)">
        <span>${esc(s.name||'User')} ${s.muted?'🔇':''}</span>
        <span>
          <button data-mute-uid="${s.uid}" data-muted="${s.muted?0:1}" class="adminAct">${s.muted?'Unmute':'Mute'}</button>
          <button data-kick-uid="${s.uid}" class="adminAct kick">Kick</button>
        </span>
      </div>`).join('')
    :'<p style="color:#888;font-size:12px">কোনো অন্য ইউজার নেই</p>';
  modal(`<h3 class="shimmer-text">👑 Room Admin</h3>
    <div style="max-height:220px;overflow-y:auto;margin:10px 0">${seatList}</div>
    <button id="muteAllBtn" class="wide primary">🔇 Mute Everyone</button>
    <button id="unmuteAllBtn" class="wide secondary">🎤 Unmute Everyone</button>
    <button id="closeRoom" class="wide" style="background:#3a1010;color:#ff8a8a;margin-top:8px">🚪 Close Live Room</button>
    <button id="closeM" class="wide secondary">Cancel</button>`);
  $$('[data-mute-uid]').forEach(b=>b.onclick=async()=>{
    try{
      await api('/api/rooms/'+currentRoom.id+'/mute',{method:'POST',body:JSON.stringify({uid:b.dataset.muteUid,muted:Number(b.dataset.muted)})});
      toast(Number(b.dataset.muted)?'User muted':'User unmuted');
      closeModal();
    }catch(e){toast(e.message)}
  });
  $$('[data-kick-uid]').forEach(b=>b.onclick=async()=>{
    if(!confirm('এই ইউজারকে রুম থেকে রিমুভ করবেন?'))return;
    try{
      await api('/api/rooms/'+currentRoom.id+'/kick',{method:'POST',body:JSON.stringify({uid:b.dataset.kickUid})});
      toast('User removed');
      closeModal();
    }catch(e){toast(e.message)}
  });
  $('#muteAllBtn').onclick=async()=>{
    try{await api('/api/rooms/'+currentRoom.id+'/mute-all',{method:'POST',body:JSON.stringify({muted:true})});toast('Everyone muted');closeModal()}catch(e){toast(e.message)}
  };
  $('#unmuteAllBtn').onclick=async()=>{
    try{await api('/api/rooms/'+currentRoom.id+'/mute-all',{method:'POST',body:JSON.stringify({muted:false})});toast('Everyone unmuted');closeModal()}catch(e){toast(e.message)}
  };
  $('#closeRoom').onclick=async()=>{
    try{await api('/api/rooms/'+currentRoom.id+'/close',{method:'POST'});closeModal();$('#leaveRoom').click()}catch(e){toast(e.message)}
  };
};

$('#roomMore').onclick=()=>modal(`<h3>Room</h3><p>Theme: ${esc(themes[currentRoom?.theme]||currentRoom?.theme||'')}</p><button id="closeM">Close</button>`);

$('#roomBg').onclick=()=>{
  if(!currentRoom)return;
  if(!isRoomOwner()){toast('শুধু মালিক সেটিংস খুলতে পারেন');return}
  openBroadcastSettings();
};
function openBroadcastSettings(){
  if(!currentRoom||!isRoomOwner())return;
  let coverData=currentRoom.coverURL||'';
  modal(`<h3 class="shimmer-text">⚙️ Broadcast Settings</h3>
    <input id="enName" placeholder="Broadcast name" value="${esc(currentRoom.name||'')}">
    <input id="enTopic" placeholder="Topic" value="${esc(currentRoom.topic||'')}">
    <textarea id="enDesc" placeholder="Description" rows="3" style="width:100%;margin:6px 0;padding:12px;border-radius:13px;border:1px solid rgba(255,255,255,.1);background:#0a0a12;color:#fff;resize:vertical">${esc(currentRoom.description||'')}</textarea>
    <label style="display:block;color:#a0a0b0;font-size:12px;margin:8px 0 4px">Cover Photo (Gallery)</label>
    <input id="enCover" type="file" accept="image/*">
    <div id="enCoverPrev" style="margin:8px 0;height:100px;border-radius:14px;background-size:cover;background-position:center;background-image:url('${coverData||''}');background-color:#111;border:1px solid rgba(155,92,255,.3)"></div>
    <div class="themeGrid">${Object.entries(themes).map(([k,v])=>`<button class="themePick ${k}" data-set-theme="${k}"><span>${v}${k===(currentRoom.theme||'')?' ✓':''}</span></button>`).join('')}</div>
    <button id="saveBroadcast" class="primary wide">Save Changes</button>
    <button id="closeM" class="wide secondary">Cancel</button>`);
  let chosenTheme=currentRoom.theme||'moonlight';
  $('#enCover')?.addEventListener('change',async e=>{
    const f=e.target.files?.[0];if(!f)return;
    try{coverData=await fileData(f);$('#enCoverPrev').style.backgroundImage=`url(${coverData})`}catch(err){toast(err.message)}
  });
  $$('[data-set-theme]').forEach(b=>b.onclick=()=>{chosenTheme=b.dataset.setTheme});
  $('#saveBroadcast').onclick=async()=>{
    const patch={
      name:($('#enName').value||'').trim()||currentRoom.name,
      topic:($('#enTopic').value||'').trim(),
      description:($('#enDesc').value||'').trim(),
      theme:chosenTheme
    };
    if(coverData)patch.coverURL=coverData;
    try{
      const d=await api('/api/rooms/'+currentRoom.id,{method:'PATCH',body:JSON.stringify(patch)});
      applyRoomUI(d.room||currentRoom);
      closeModal();
      toast('Broadcast updated');
      loadRooms();
    }catch(e){toast(e.message)}
  };
}

/* ========== PRIVATE CHAT — clearly different from room comments ========== */
async function loadChats(){
  try{
    const {chats}=await api('/api/chats');
    $('#chatList').innerHTML=chats.length?chats.map(c=>`<button class="chatRow" data-uid="${c.otherUid}">
      <div class="avatar mini">${esc((c.name||'U')[0])}</div>
      <div class="chatRowBody">
        <b>${esc(c.name||'User')}</b>
        <span class="chatPreview">${esc(c.lastMessage||'No messages yet')}</span>
      </div>
      <span class="chatTime">${c.updatedAt?new Date(c.updatedAt).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):''}</span>
    </button>`).join(''):'<div class="emptyState">কোনো প্রাইভেট কথোপকথন নেই। ＋ দিয়ে মা/বাবা/বন্ধুকে সার্চ করে মেসেজ শুরু করুন।</div>';
  }catch{
    $('#chatList').innerHTML='<div class="emptyState">সার্ভার কানেক্ট হয়নি।</div>';
  }
}

$('#chatList').onclick=e=>{
  const x=e.target.closest('[data-uid]');
  if(x)openChat(x.dataset.uid);
};

async function openChat(uid){
  activeChat=uid;
  let displayName='User';
  try{
    const d=await api('/api/users/search?q='+encodeURIComponent(uid));
    const found=(d.users||[]).find(x=>x.id===uid);
    if(found)displayName=found.name||found.username||'User';
  }catch{}
  const row=$('#chatList [data-uid="'+uid+'"] b');
  if(row)displayName=row.textContent||displayName;

  modal(`<div class="pmHeader">
      <span class="pmBadge">PRIVATE</span>
      <h3 class="shimmer-text">💬 ${esc(displayName)}</h3>
      <p class="pmSub">শুধু তোমার ও ${esc(displayName)}-এর মধ্যে — মা/বাবা/বন্ধু যে কেউ</p>
    </div>
    <div id="private" class="pmThread"></div>
    <div class="pmInputRow">
      <input id="pm" placeholder="প্রাইভেট মেসেজ লিখুন...">
      <button id="sendPM" class="sendBtn">➤</button>
    </div>
    <div class="row" style="margin-top:10px;display:flex;gap:8px">
      <button id="closeM" class="wide secondary" style="margin:0;flex:1">Close</button>
    </div>`);
  await loadChatMessages(uid);
  $('#sendPM').onclick=sendPM;
  $('#pm').onkeydown=e=>{if(e.key==='Enter')sendPM()};
  $('#closeM').onclick=()=>{activeChat=null;closeModal()};
}

async function loadChatMessages(uid){
  const box=$('#private');
  if(!box)return;
  try{
    const {messages}=await api('/api/chats/'+uid+'/messages');
    box.innerHTML=messages.length?messages.map(m=>{
      const mine=m.senderId===me.id;
      return `<div class="pmBubble ${mine?'mine':'theirs'}">
        <div class="pmMeta">${mine?'You':'Them'}</div>
        <div class="pmText">${esc(m.text)}</div>
      </div>`;
    }).join(''):'<p class="pmEmpty">এখনো কোনো মেসেজ নেই। প্রথম মেসেজ পাঠান।</p>';
    box.scrollTop=box.scrollHeight;
  }catch{
    box.innerHTML='<p class="pmEmpty">মেসেজ লোড হয়নি</p>';
  }
}

async function sendPM(){
  const t=$('#pm').value.trim();
  if(!t||!activeChat)return;
  try{
    await api('/api/chats/'+activeChat+'/messages',{method:'POST',body:JSON.stringify({text:t})});
    $('#pm').value='';
    await loadChatMessages(activeChat);
    loadChats();
  }catch(e){toast(e.message||'পাঠানো যায়নি')}
}

$('#newChat').onclick=()=>{
  modal(`<h3 class="shimmer-text">＋ New Private Chat</h3>
    <p class="hint">মা, বাবা, বন্ধু — username বা নাম দিয়ে সার্চ করুন। শুধু দুজনের মধ্যে মেসেজ হবে।</p>
    <input id="userSearch" placeholder="Username or name">
    <div id="results" class="searchResults"></div>
    <button id="closeM" class="wide secondary">Close</button>`);
  $('#userSearch')?.addEventListener('input',async e=>{
    const q=e.target.value.trim();
    if(!q){$('#results').innerHTML='';return}
    try{
      const d=await api('/api/users/search?q='+encodeURIComponent(q));
      $('#results').innerHTML=(d.users||[]).length
        ?(d.users||[]).map(u=>`<button class="searchResult" data-uid="${u.id}">
            <div class="avatar mini">${esc((u.name||'U')[0])}</div>
            <div><b>${esc(u.name)}</b><small>@${esc(u.username)}</small></div>
          </button>`).join('')
        :'<p class="hint">কেউ পাওয়া যায়নি</p>';
      $$('#results [data-uid]').forEach(btn=>btn.onclick=()=>{
        closeModal();
        openChat(btn.dataset.uid);
      });
    }catch{
      $('#results').innerHTML='<p class="hint">সার্চ ব্যর্থ</p>';
    }
  });
};

/* ========== Nav & misc ========== */
$$('nav button').forEach(b=>b.onclick=()=>{
  const id=b.dataset.go;
  if(id==='roomShortcut'){
    if(currentRoom)go('room');
    else toast('আগে একটি live room খুলুন');
    return;
  }
  go(id);
  if(id==='home')loadRooms();
  if(id==='chats')loadChats();
  if(id==='profile')loadProfile();
});

$('#heroRooms').onclick=()=>{go('home');loadRooms()};
$('#heroChat').onclick=()=>{go('chats');loadChats()};

$('#logoutBtn').onclick=()=>{
  modal(`<h3 class="shimmer-text">Menu</h3>
    <button id="doLogout" class="wide primary">🚪 Logout</button>
    <button id="closeM" class="wide secondary">Cancel</button>`);
  $('#doLogout').onclick=()=>{closeModal();logout(true)};
};

$('#modal').onclick=e=>{if(e.target.id==='modal')closeModal()};
document.addEventListener('click',e=>{
  if(e.target.id==='closeM')closeModal();
});

/* Google/Gmail sign-in: native Google provider requires the updated OAuth-enabled google-services.json. */
function gmailFlow(isRegister){
  if(window.FirebaseBridge?.signInGoogle){
    const cb='__googlecb_'+Date.now();
    window[cb]=(raw)=>{
      try{
        const d=typeof raw==='string'?JSON.parse(raw):raw;
        delete window[cb];
        if(!d?.ok){toast(d?.error||'Google login failed');return}
        finishFirebaseAuth(d,{name:d.name||''}).catch(e=>toast(e.message||'Google login failed'));
      }catch(e){toast('Google login failed')}
    };
    try{window.FirebaseBridge.signInGoogle(cb)}catch(e){toast('Google login শুরু করা যায়নি')}
  }else toast('Google login-এর জন্য Firebase Google provider ও OAuth setup বাকি আছে।');
}
document.getElementById('gmailBtn')?.addEventListener('click',()=>gmailFlow(false));
document.getElementById('gmailBtnReg')?.addEventListener('click',()=>gmailFlow(true));

boot();boot();
