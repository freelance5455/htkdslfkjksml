plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.miraz.voiceclub"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.miraz.voiceclub"
        minSdk = 24
        targetSdk = 35
        versionCode = 4
        versionName = "4.0"
    }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:34.19.0"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-auth")
}
