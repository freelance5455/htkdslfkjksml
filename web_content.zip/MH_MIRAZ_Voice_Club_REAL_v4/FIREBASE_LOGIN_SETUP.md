# Firebase Login Setup

This build wires the Android WebView login/register to Firebase Authentication for email/password and exchanges the Firebase ID token with the existing server session.

## Firebase Console
Enable **Authentication > Sign-in method > Email/Password** for project `social-media-79470` before testing.

Google login is intentionally not enabled in this build yet because the supplied `google-services.json` has no OAuth client entries. Firebase's Android Google sign-in setup requires SHA-1, Google provider enabled, and an updated `google-services.json` containing OAuth client information.

## Server
Run the server with Node.js 18+:

```bash
cd server
npm install
npm start
```

Set the app's Server URL to the reachable backend URL (for a phone on the same Wi-Fi, use the computer's LAN IP, e.g. `http://192.168.1.10:8080`).

## Android
Open the `android-app` folder in Android Studio and build/install the debug APK. The Firebase config is already in `android-app/app/google-services.json` and the package is `com.miraz.voiceclub`.
