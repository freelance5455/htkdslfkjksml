const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_THIS_SECRET_BEFORE_PUBLIC_DEPLOYMENT';
const db = new Database(process.env.DB_FILE || 'voiceclub.db');
db.pragma('journal_mode = WAL');

try { db.exec("ALTER TABLE rooms ADD COLUMN description TEXT DEFAULT ''"); } catch(e) {}
try { db.exec("ALTER TABLE rooms ADD COLUMN cover_url TEXT DEFAULT ''"); } catch(e) {}

db.exec(`
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,name TEXT NOT NULL,age INTEGER,language TEXT DEFAULT 'বাংলা',photo_url TEXT DEFAULT '',cover_url TEXT DEFAULT '',notifications INTEGER DEFAULT 1,privacy TEXT DEFAULT 'public',created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS rooms(id TEXT PRIMARY KEY,name TEXT NOT NULL,topic TEXT DEFAULT '',description TEXT DEFAULT '',cover_url TEXT DEFAULT '',owner_id TEXT NOT NULL,theme TEXT DEFAULT 'moonlight',is_live INTEGER DEFAULT 1,max_seats INTEGER DEFAULT 15,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,chat_key TEXT NOT NULL,sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,text TEXT NOT NULL,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS room_messages(id TEXT PRIMARY KEY,room_id TEXT NOT NULL,sender_id TEXT NOT NULL,text TEXT NOT NULL,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS room_seats(room_id TEXT NOT NULL,seat INTEGER NOT NULL,user_id TEXT NOT NULL,muted INTEGER DEFAULT 0,PRIMARY KEY(room_id,seat),UNIQUE(room_id,user_id));
CREATE TABLE IF NOT EXISTS follows(follower_id TEXT NOT NULL,following_id TEXT NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(follower_id,following_id));
CREATE TABLE IF NOT EXISTS room_members(room_id TEXT NOT NULL,user_id TEXT NOT NULL,joined_at INTEGER NOT NULL,last_seen_at INTEGER NOT NULL,PRIMARY KEY(room_id,user_id));
`);

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const sockets = new Map();
const roomSockets = new Map();
const calls = new Map();

function uid() { return crypto.randomUUID(); }
function sign(u) { return jwt.sign({ uid: u.id || u }, JWT_SECRET, { expiresIn: '30d' }); }
function auth(req, res, next) {
  try {
    const h = req.headers.authorization || '';
    const t = h.startsWith('Bearer ') ? h.slice(7) : '';
    req.user = jwt.verify(t, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'UNAUTHORIZED' });
  }
}
function userById(id) {
  return db.prepare('SELECT id,username,name,age,language,photo_url AS photoURL,cover_url AS coverURL,notifications,privacy FROM users WHERE id=?').get(id);
}
function publicUser(id) {
  return userById(id) || null;
}
function send(ws, obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function broadcastRoom(roomId, obj, except) {
  const set = roomSockets.get(roomId);
  if (!set) return;
  for (const id of set) {
    if (id !== except) send(sockets.get(id), obj);
  }
}
function roomSnapshot(roomId, viewerId = '') {
  const r = db.prepare('SELECT * FROM rooms WHERE id=?').get(roomId);
  if (!r) return null;
  const seats = db.prepare(`
    SELECT s.seat, s.user_id AS uid, s.muted, u.name, u.photo_url AS photoURL
    FROM room_seats s JOIN users u ON u.id = s.user_id
    WHERE s.room_id = ? ORDER BY s.seat
  `).all(roomId).map(x => ({ ...x, muted: !!x.muted }));
  return {
    id: r.id,
    name: r.name,
    topic: r.topic || '',
    description: r.description || '',
    coverURL: r.cover_url || '',
    ownerId: r.owner_id,
    theme: r.theme || 'moonlight',
    isLive: !!r.is_live,
    maxSeats: r.max_seats,
    createdAt: r.created_at,
    currentUsers: seats.length,
    memberCount: db.prepare('SELECT COUNT(*) c FROM room_members WHERE room_id=?').get(roomId).c,
    isMember: !!db.prepare('SELECT 1 FROM room_members WHERE room_id=? AND user_id=?').get(roomId, viewerId).c,
    seats
  };
}
function chatKey(a, b) { return [a, b].sort().join(':'); }
function isOwner(roomId, userId) {
  const r = db.prepare('SELECT owner_id FROM rooms WHERE id=?').get(roomId);
  return r && r.owner_id === userId;
}

// ========== AUTH ==========
app.get('/api/health', (req, res) => res.json({ ok: true, time: Date.now() }));

app.post('/api/auth/register', async (req, res) => {
  const { username, password, name, age, language = 'বাংলা' } = req.body || {};
  if (!username || !password || !name || password.length < 6)
    return res.status(400).json({ error: 'USERNAME_PASSWORD_NAME_REQUIRED' });
  if (db.prepare('SELECT 1 FROM users WHERE username=?').get(username))
    return res.status(409).json({ error: 'USERNAME_EXISTS' });
  const id = uid();
  const hash = await bcrypt.hash(password, 12);
  db.prepare('INSERT INTO users(id,username,password_hash,name,age,language,created_at) VALUES(?,?,?,?,?,?,?)')
    .run(id, username, hash, name, age || null, language, Date.now());
  const u = userById(id);
  res.json({ token: sign({ id }), user: u });
});

async function verifyFirebaseIdToken(idToken) {
  const parts = String(idToken || '').split('.');
  if (parts.length !== 3) throw new Error('INVALID_FIREBASE_TOKEN');
  const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
  const resp = await fetch('https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com');
  if (!resp.ok) throw new Error('FIREBASE_CERTS_UNAVAILABLE');
  const certs = await resp.json();
  const cert = certs[header.kid];
  if (!cert) throw new Error('INVALID_FIREBASE_TOKEN');
  const payload = jwt.verify(idToken, cert, {
    algorithms: ['RS256'],
    audience: 'social-media-79470',
    issuer: 'https://securetoken.google.com/social-media-79470'
  });
  if (!payload.sub || payload.sub.length > 128) throw new Error('INVALID_FIREBASE_TOKEN');
  return payload;
}

app.post('/api/auth/firebase', async (req, res) => {
  try {
    const { idToken, name = '', age = null } = req.body || {};
    const claims = await verifyFirebaseIdToken(idToken);
    const firebaseUid = claims.sub;
    const email = String(claims.email || '').trim().toLowerCase();
    const phone = String(claims.phone_number || '').trim();
    const username = email || phone;
    const displayName = String(name || claims.name || (email ? email.split('@')[0] : (phone ? phone : 'User'))).trim() || 'User';
    if (!username) return res.status(400).json({ error: 'IDENTITY_REQUIRED' });

    let u = db.prepare('SELECT * FROM users WHERE id=?').get(firebaseUid);
    if (!u) u = db.prepare('SELECT * FROM users WHERE username=?').get(username);
    if (!u) {
      const randomHash = await bcrypt.hash(crypto.randomBytes(24).toString('hex'), 12);
      db.prepare('INSERT INTO users(id,username,password_hash,name,age,language,created_at) VALUES(?,?,?,?,?,?,?)')
        .run(firebaseUid, username, randomHash, displayName, age || null, 'বাংলা', Date.now());
    } else if (u.id !== firebaseUid) {
      db.prepare('UPDATE users SET id=? WHERE id=?').run(firebaseUid, u.id);
    } else {
      const updates=[]; const vals=[];
      if (displayName && displayName !== u.name) { updates.push('name=?'); vals.push(displayName); }
      if (age) { updates.push('age=?'); vals.push(age); }
      if (updates.length) db.prepare(`UPDATE users SET ${updates.join(',')} WHERE id=?`).run(...vals, firebaseUid);
    }
    u = userById(firebaseUid);
    res.json({ token: sign({ id: firebaseUid }), user: u });
  } catch (e) {
    console.error('Firebase auth error:', e.message);
    res.status(401).json({ error: 'INVALID_FIREBASE_TOKEN' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(username);
  if (!u || !(await bcrypt.compare(password, u.password_hash)))
    return res.status(401).json({ error: 'INVALID_LOGIN' });
  res.json({ token: sign(u), user: userById(u.id) });
});

app.get('/api/me', auth, (req, res) => res.json({ user: userById(req.user.uid) }));

app.patch('/api/me', auth, (req, res) => {
  const allowed = ['name', 'age', 'language', 'photoURL', 'coverURL', 'notifications', 'privacy'];
  const d = req.body || {};
  const sets = [], vals = [];
  for (const k of allowed) {
    if (Object.prototype.hasOwnProperty.call(d, k)) {
      const col = { photoURL: 'photo_url', coverURL: 'cover_url' }[k] || k;
      sets.push(`${col}=?`);
      vals.push(d[k]);
    }
  }
  if (sets.length) db.prepare(`UPDATE users SET ${sets.join(',')} WHERE id=?`).run(...vals, req.user.uid);
  res.json({ user: userById(req.user.uid) });
});

// ========== USERS / CHATS ==========
app.get('/api/users/search', auth, (req, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) return res.json({ users: [] });
  const rows = db.prepare(`SELECT id,username,name,photo_url AS photoURL FROM users WHERE username LIKE ? OR name LIKE ? LIMIT 20`)
    .all('%' + q + '%', '%' + q + '%').filter(x => x.id !== req.user.uid);
  res.json({ users: rows });
});

app.get('/api/chats', auth, (req, res) => {
  const me = req.user.uid;
  const rows = db.prepare(`
    SELECT m.* FROM messages m
    JOIN (SELECT chat_key, MAX(created_at) max_time FROM messages WHERE sender_id=? OR receiver_id=? GROUP BY chat_key) x
    ON x.chat_key = m.chat_key AND x.max_time = m.created_at
    ORDER BY m.created_at DESC
  `).all(me, me);
  res.json({
    chats: rows.map(m => {
      const other = m.sender_id === me ? m.receiver_id : m.sender_id;
      const u = userById(other);
      return { chatKey: m.chat_key, otherUid: other, name: u?.name || 'User', photoURL: u?.photoURL || '', lastMessage: m.text, updatedAt: m.created_at };
    })
  });
});

app.get('/api/chats/:uid/messages', auth, (req, res) => {
  const key = chatKey(req.user.uid, req.params.uid);
  const rows = db.prepare('SELECT id,sender_id AS senderId,receiver_id AS receiverId,text,created_at AS createdAt FROM messages WHERE chat_key=? ORDER BY created_at ASC LIMIT 200').all(key);
  res.json({ messages: rows });
});

app.post('/api/chats/:uid/messages', auth, (req, res) => {
  const text = String(req.body?.text || '').trim();
  if (!text) return res.status(400).json({ error: 'EMPTY_MESSAGE' });
  const to = req.params.uid;
  const key = chatKey(req.user.uid, to);
  const id = uid();
  const now = Date.now();
  db.prepare('INSERT INTO messages(id,chat_key,sender_id,receiver_id,text,created_at) VALUES(?,?,?,?,?,?)')
    .run(id, key, req.user.uid, to, text, now);
  const msg = { id, senderId: req.user.uid, receiverId: to, text, createdAt: now };
  send(sockets.get(to), { type: 'private_message', message: msg });
  res.json(msg);
});

// ========== FOLLOWS / FRIENDS ==========
app.get('/api/users/:id/follow-status', auth, (req,res)=>{
  const target=req.params.id;
  if(target===req.user.uid) return res.json({following:false});
  res.json({following:!!db.prepare('SELECT 1 FROM follows WHERE follower_id=? AND following_id=?').get(req.user.uid,target)});
});
app.post('/api/users/:id/follow', auth, (req,res)=>{
  const target=req.params.id;
  if(target===req.user.uid) return res.status(400).json({error:'CANNOT_FOLLOW_SELF'});
  if(!db.prepare('SELECT 1 FROM users WHERE id=?').get(target)) return res.status(404).json({error:'USER_NOT_FOUND'});
  db.prepare('INSERT OR IGNORE INTO follows(follower_id,following_id,created_at) VALUES(?,?,?)').run(req.user.uid,target,Date.now());
  res.json({following:true});
});
app.delete('/api/users/:id/follow', auth, (req,res)=>{
  db.prepare('DELETE FROM follows WHERE follower_id=? AND following_id=?').run(req.user.uid,req.params.id);
  res.json({following:false});
});
app.get('/api/me/following', auth, (req,res)=>{
  const rows=db.prepare(`SELECT u.id,u.username,u.name,u.photo_url AS photoURL FROM follows f JOIN users u ON u.id=f.following_id WHERE f.follower_id=? ORDER BY f.created_at DESC`).all(req.user.uid);
  res.json({users:rows});
});

// ========== ROOMS ==========
app.get('/api/rooms', auth, (req, res) => {
  const rows = db.prepare('SELECT id,name,topic,description,cover_url AS coverURL,owner_id AS ownerId,theme,is_live AS isLive,max_seats AS maxSeats,created_at AS createdAt FROM rooms WHERE is_live=1 ORDER BY created_at DESC').all();
  res.json({
    rooms: rows.map(r => ({
      ...r,
      isLive: !!r.isLive,
      currentUsers: db.prepare('SELECT COUNT(*) c FROM room_seats WHERE room_id=?').get(r.id).c,
      memberCount: db.prepare('SELECT COUNT(*) c FROM room_members WHERE room_id=?').get(r.id).c,
      isMember: !!db.prepare('SELECT 1 FROM room_members WHERE room_id=? AND user_id=?').get(r.id, req.user.uid).c
    }))
  });
});

app.post('/api/rooms', auth, (req, res) => {
  const { name, topic = '', description = '', coverURL = '', theme = 'moonlight' } = req.body || {};
  if (!name) return res.status(400).json({ error: 'ROOM_NAME_REQUIRED' });
  const id = uid();
  db.prepare('INSERT INTO rooms(id,name,topic,description,cover_url,owner_id,theme,is_live,max_seats,created_at) VALUES(?,?,?,?,?,?,?,1,15,?)')
    .run(id, name, topic, description, coverURL, req.user.uid, theme, Date.now());
  res.json({ room: roomSnapshot(id) });
});

app.get('/api/rooms/:id', auth, (req, res) => {
  const room = roomSnapshot(req.params.id, req.user.uid);
  if (!room || !room.isLive) return res.status(404).json({ error: 'ROOM_NOT_FOUND' });
  const messages = db.prepare(`
    SELECT m.id, m.room_id AS roomId, m.sender_id AS senderId, m.text, m.created_at AS createdAt, u.name, u.photo_url AS photoURL
    FROM room_messages m JOIN users u ON u.id = m.sender_id
    WHERE m.room_id = ? ORDER BY m.created_at ASC LIMIT 100
  `).all(req.params.id);
  res.json({ room, messages });
});

// Theme change — OWNER ONLY
app.patch('/api/rooms/:id', auth, (req, res) => {
  if (!isOwner(req.params.id, req.user.uid))
    return res.status(403).json({ error: 'OWNER_ONLY' });
  const { theme, name, topic, description, coverURL } = req.body || {};
  if (theme) {
    const allowed = ['moonlight', 'ocean', 'forest', 'sunset', 'cyber'];
    if (!allowed.includes(theme)) return res.status(400).json({ error: 'INVALID_THEME' });
    db.prepare('UPDATE rooms SET theme=? WHERE id=?').run(theme, req.params.id);
  }
  if (name) db.prepare('UPDATE rooms SET name=? WHERE id=?').run(name, req.params.id);
  if (topic !== undefined) db.prepare('UPDATE rooms SET topic=? WHERE id=?').run(topic, req.params.id);
  if (description !== undefined) db.prepare('UPDATE rooms SET description=? WHERE id=?').run(description, req.params.id);
  if (coverURL !== undefined) db.prepare('UPDATE rooms SET cover_url=? WHERE id=?').run(coverURL, req.params.id);
  const snap = roomSnapshot(req.params.id);
  broadcastRoom(req.params.id, { type: 'room_state', room: snap });
  res.json({ room: snap });
});

app.post('/api/rooms/:id/messages', auth, (req, res) => {
  const text = String(req.body?.text || '').trim();
  if (!text) return res.status(400).json({ error: 'EMPTY_MESSAGE' });
  const room = roomSnapshot(req.params.id);
  if (!room || !room.isLive) return res.status(404).json({ error: 'ROOM_NOT_FOUND' });
  const m = { id: uid(), roomId: req.params.id, senderId: req.user.uid, text, createdAt: Date.now() };
  db.prepare('INSERT INTO room_messages(id,room_id,sender_id,text,created_at) VALUES(?,?,?,?,?)')
    .run(m.id, m.roomId, m.senderId, m.text, m.createdAt);
  const u = publicUser(req.user.uid);
  broadcastRoom(req.params.id, { type: 'room_message', message: { ...m, name: u.name, photoURL: u.photoURL } });
  res.json(m);
});

app.post('/api/rooms/:id/member', auth, (req,res)=>{
  const roomId=req.params.id;
  const r=db.prepare('SELECT id,is_live FROM rooms WHERE id=?').get(roomId);
  if(!r || !r.is_live) return res.status(404).json({error:'ROOM_NOT_FOUND'});
  const now=Date.now();
  db.prepare('INSERT OR IGNORE INTO room_members(room_id,user_id,joined_at,last_seen_at) VALUES(?,?,?,?)').run(roomId,req.user.uid,now,now);
  db.prepare('UPDATE room_members SET last_seen_at=? WHERE room_id=? AND user_id=?').run(now,roomId,req.user.uid);
  res.json({member:true,memberCount:db.prepare('SELECT COUNT(*) c FROM room_members WHERE room_id=?').get(roomId).c});
});
app.get('/api/rooms/:id/members', auth, (req,res)=>{
  const rows=db.prepare(`SELECT u.id,u.username,u.name,u.photo_url AS photoURL,m.joined_at AS joinedAt,m.last_seen_at AS lastSeenAt FROM room_members m JOIN users u ON u.id=m.user_id WHERE m.room_id=? ORDER BY m.joined_at ASC`).all(req.params.id);
  res.json({members:rows.map(u=>({...u,online:!!sockets.get(u.id)}))});
});

app.post('/api/rooms/:id/join', auth, (req, res) => {
  const roomId = req.params.id;
  const seat = Number(req.body?.seat);
  if (!Number.isInteger(seat) || seat < 1 || seat > 15)
    return res.status(400).json({ error: 'INVALID_SEAT' });
  const r = roomSnapshot(roomId);
  if (!r || !r.isLive) return res.status(404).json({ error: 'ROOM_NOT_FOUND' });
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM room_seats WHERE room_id=? AND user_id=?').run(roomId, req.user.uid);
    const taken = db.prepare('SELECT 1 FROM room_seats WHERE room_id=? AND seat=?').get(roomId, seat);
    const count = db.prepare('SELECT COUNT(*) c FROM room_seats WHERE room_id=?').get(roomId).c;
    if (taken || count >= 15) throw new Error('SEAT_TAKEN');
    db.prepare('INSERT INTO room_seats(room_id,seat,user_id,muted) VALUES(?,?,?,0)').run(roomId, seat, req.user.uid);
    const now=Date.now();
    db.prepare('INSERT OR IGNORE INTO room_members(room_id,user_id,joined_at,last_seen_at) VALUES(?,?,?,?)').run(roomId,req.user.uid,now,now);
    db.prepare('UPDATE room_members SET last_seen_at=? WHERE room_id=? AND user_id=?').run(now,roomId,req.user.uid);
  });
  try { tx(); } catch (e) { return res.status(409).json({ error: e.message }); }
  const snap = roomSnapshot(roomId);
  broadcastRoom(roomId, { type: 'room_state', room: snap });
  res.json({ room: snap });
});

app.post('/api/rooms/:id/leave', auth, (req, res) => {
  db.prepare('DELETE FROM room_seats WHERE room_id=? AND user_id=?').run(req.params.id, req.user.uid);
  broadcastRoom(req.params.id, { type: 'room_state', room: roomSnapshot(req.params.id) });
  res.json({ ok: true });
});

// Self mute/unmute — any user can mute only themselves
app.post('/api/rooms/:id/self-mute', auth, (req, res) => {
  const muted = req.body?.muted ? 1 : 0;
  const seat = db.prepare('SELECT 1 FROM room_seats WHERE room_id=? AND user_id=?').get(req.params.id, req.user.uid);
  if (!seat) return res.status(400).json({ error: 'NOT_IN_ROOM' });
  db.prepare('UPDATE room_seats SET muted=? WHERE room_id=? AND user_id=?').run(muted, req.params.id, req.user.uid);
  const snap = roomSnapshot(req.params.id);
  broadcastRoom(req.params.id, { type: 'room_state', room: snap });
  res.json({ room: snap, muted: !!muted });
});

// Owner mute one user
app.post('/api/rooms/:id/mute', auth, (req, res) => {
  if (!isOwner(req.params.id, req.user.uid))
    return res.status(403).json({ error: 'OWNER_ONLY' });
  const targetUid = req.body?.uid;
  if (!targetUid) return res.status(400).json({ error: 'UID_REQUIRED' });
  const muted = req.body?.muted ? 1 : 0;
  db.prepare('UPDATE room_seats SET muted=? WHERE room_id=? AND user_id=?').run(muted, req.params.id, targetUid);
  const snap = roomSnapshot(req.params.id);
  broadcastRoom(req.params.id, { type: 'room_state', room: snap });
  // notify the muted user
  send(sockets.get(targetUid), { type: 'force_mute', muted: !!muted, roomId: req.params.id });
  res.json({ room: snap });
});

// Owner mute ALL users in room
app.post('/api/rooms/:id/mute-all', auth, (req, res) => {
  if (!isOwner(req.params.id, req.user.uid))
    return res.status(403).json({ error: 'OWNER_ONLY' });
  const muted = req.body?.muted !== false ? 1 : 0;
  db.prepare('UPDATE room_seats SET muted=? WHERE room_id=? AND user_id!=?').run(muted, req.params.id, req.user.uid);
  const snap = roomSnapshot(req.params.id);
  broadcastRoom(req.params.id, { type: 'room_state', room: snap });
  broadcastRoom(req.params.id, { type: 'force_mute_all', muted: !!muted, roomId: req.params.id }, req.user.uid);
  res.json({ room: snap });
});

// Owner kick / remove user from room
app.post('/api/rooms/:id/kick', auth, (req, res) => {
  if (!isOwner(req.params.id, req.user.uid))
    return res.status(403).json({ error: 'OWNER_ONLY' });
  const targetUid = req.body?.uid;
  if (!targetUid) return res.status(400).json({ error: 'UID_REQUIRED' });
  if (targetUid === req.user.uid) return res.status(400).json({ error: 'CANNOT_KICK_SELF' });
  db.prepare('DELETE FROM room_seats WHERE room_id=? AND user_id=?').run(req.params.id, targetUid);
  const snap = roomSnapshot(req.params.id);
  broadcastRoom(req.params.id, { type: 'room_state', room: snap });
  send(sockets.get(targetUid), { type: 'kicked', roomId: req.params.id });
  // remove from roomSockets
  const set = roomSockets.get(req.params.id);
  if (set) set.delete(targetUid);
  broadcastRoom(req.params.id, { type: 'peer_left', uid: targetUid });
  res.json({ room: snap });
});

app.post('/api/rooms/:id/close', auth, (req, res) => {
  if (!isOwner(req.params.id, req.user.uid))
    return res.status(403).json({ error: 'OWNER_ONLY' });
  db.prepare('UPDATE rooms SET is_live=0 WHERE id=?').run(req.params.id);
  broadcastRoom(req.params.id, { type: 'room_closed' });
  res.json({ ok: true });
});

// ========== WEBSOCKET ==========
wss.on('connection', (ws, req) => {
  const u = new URL(req.url, 'http://localhost');
  const token = u.searchParams.get('token');
  let decoded;
  try { decoded = jwt.verify(token, JWT_SECRET); } catch { return ws.close(1008, 'unauthorized'); }
  const userId = decoded.uid;
  sockets.set(userId, ws);

  ws.on('message', raw => {
    let m;
    try { m = JSON.parse(raw); } catch { return; }
    if (m.type === 'room_join_signal') {
      let set = roomSockets.get(m.roomId) || new Set();
      set.add(userId);
      roomSockets.set(m.roomId, set);
      broadcastRoom(m.roomId, { type: 'peer_joined', uid: userId }, userId);
    } else if (m.type === 'room_leave_signal') {
      const set = roomSockets.get(m.roomId);
      if (set) {
        set.delete(userId);
        broadcastRoom(m.roomId, { type: 'peer_left', uid: userId }, userId);
      }
    } else if (m.type === 'webrtc_offer' || m.type === 'webrtc_answer' || m.type === 'ice_candidate') {
      send(sockets.get(m.to), { ...m, from: userId });
    } else if (m.type === 'call_invite') {
      calls.set(m.callId, { from: userId, to: m.to });
      send(sockets.get(m.to), { ...m, from: userId });
    } else if (m.type === 'call_accept') {
      send(sockets.get(m.to), { ...m, from: userId });
    }
  });

  ws.on('close', () => {
    sockets.delete(userId);
    for (const [rid, set] of roomSockets) {
      if (set.delete(userId)) broadcastRoom(rid, { type: 'peer_left', uid: userId });
    }
  });
});

server.listen(PORT, '0.0.0.0', () => console.log(`MH MIRAZ Voice Club server listening on ${PORT}`));
