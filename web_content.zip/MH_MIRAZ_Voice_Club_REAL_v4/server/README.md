# Real backend

This is a real Node.js + SQLite + WebSocket backend. It does not use Firebase.

## Run
1. Install Node.js 20+.
2. `npm install`
3. Set `JWT_SECRET` to a long random value.
4. `npm start`

The API listens on port 8080. The Android app can point to this server URL.

For remote phones, deploy this server on a public HTTPS host. The app's WebSocket URL must use `wss://` when the API uses HTTPS.

The voice room uses real WebRTC peer-to-peer audio signaling through this server. It is a true connection, not simulated audio. A production 15-user room should later be moved to an SFU such as LiveKit/mediasoup for better scalability.
