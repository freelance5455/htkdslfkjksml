# Social Media - UI v5 (Real only)

App name: **Social Media**

## What changed
- **All fake / preview mode removed.** No bypass login. No fake rooms.
- Users must **Register or Login** with real account → data saved on server (SQLite).
- Creating Broadcast / Live Room is always real (saved on server).
- **Private messages** (মা/বাবা/বন্ধু) are separate from Live Room public comments.
  - Chat tab = 1-to-1 private only
  - Room comments = public live comments inside broadcast
- Login / Register UI added.
- Private chat UI uses chat bubbles (left/right), gold PRIVATE badge — looks different from room comments.

## Firebase & full voice
- You said you will add Firebase service and voice connection later.
- Current WebRTC signaling stays for peer audio; upgrade to SFU (LiveKit/mediasoup) or Firebase later as planned.

## How to run
1. Backend: `cd server && npm install && JWT_SECRET=your-secret npm start` (port 8080)
2. Open `index.html` in browser or Android WebView.
3. Settings / Login screen → set Server URL (e.g. `http://YOUR_PC_IP:8080` or emulator `http://10.0.2.2:8080`)
4. Register → Login → create rooms / private chat — everything real.

## Notes
- Nothing is simulated when logged in.
- Without server, login/register will fail (correct — no fake fallback).

## Broadcast room updates (v5+)
- **Public comments only** in Live Room — everyone sees messages (private chat stays separate).
- **Emoji picker**: many categories (হাসি, রাগ, ভালোবাসা, গিফট, রিঅ্যাক্ট…) — beautiful grid.
- **Seat reaction**: tap a seat → send emoji → shows floating on their avatar for a few seconds.
- **Gift & Reward**: 🎁 button + gift grid (Rose, Diamond, Crown…). Sends public gift message + reaction on seat.
- **PK**: ⚔ button to challenge another seat user — announces in room comments.
- **Entry effect**: when someone joins a seat, beautiful overlay + “ওয়েলকাম [নাম]” in comments + gift invite.
- **Layout**: seats on top (talk), comments at bottom (public), small controls (Emoji / Mic / Gift / PK / Reward / Admin / Leave).

## Firebase Android configuration
The Android app now includes the supplied `google-services.json` and Google Services Gradle plugin, plus Firebase Analytics using the supplied Firebase BoM. The Firebase project/package pairing is `social-media-79470` / `com.miraz.voiceclub`.

Important: the existing Login/Register implementation in this version is still backed by the bundled Node.js/SQLite server (`server/`), not Firebase Authentication. A working login on a physical phone therefore still requires the backend to be running at a reachable server URL. Firebase Analytics integration alone does not replace that authentication backend.
