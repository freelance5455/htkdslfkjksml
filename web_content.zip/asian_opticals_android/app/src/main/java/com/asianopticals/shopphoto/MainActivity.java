package com.asianopticals.shopphoto;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.*;
import android.view.*;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    WebView web; ValueCallback<Uri[]> uploadCallback; Uri cameraUri;
    static final int REQ_CAMERA=7, REQ_FILE=8;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(false); s.setDomStorageEnabled(false); s.setMediaPlaybackRequiresUserGesture(true);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient(){ @Override public WebResourceResponse shouldInterceptRequest(WebView v, android.webkit.WebResourceRequest r){ return loader.shouldInterceptRequest(r.getUrl()); } @Override public WebResourceResponse shouldInterceptRequest(WebView v, String url){ return loader.shouldInterceptRequest(Uri.parse(url)); }});
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                uploadCallback=cb;
                if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.CAMERA},REQ_CAMERA); return true;}
                launchChooser(); return true;
            }
        });
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }
    void launchChooser(){
        Intent camera=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File dir=new File(getCacheDir(),"camera"); dir.mkdirs();
        File f=new File(dir,"shop_"+System.currentTimeMillis()+".jpg");
        cameraUri=FileProvider.getUriForFile(this,"com.asianopticals.shopphoto.fileprovider",f);
        camera.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri); camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent pick=new Intent(Intent.ACTION_GET_CONTENT); pick.setType("image/*"); pick.addCategory(Intent.CATEGORY_OPENABLE);
        Intent chooser=Intent.createChooser(pick,"Select shop photo"); chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS,new Intent[]{camera}); startActivityForResult(chooser,REQ_FILE);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); if(r==REQ_CAMERA && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) launchChooser(); else if(r==REQ_CAMERA && uploadCallback!=null){uploadCallback.onReceiveValue(null);uploadCallback=null;}}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data); if(r!=REQ_FILE||uploadCallback==null)return; Uri u=null; if(c==RESULT_OK){u=data!=null?data.getData():null; if(u==null)u=cameraUri;} uploadCallback.onReceiveValue(u==null?null:new Uri[]{u}); uploadCallback=null;}
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
