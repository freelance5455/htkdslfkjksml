package com.route.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.util.Locale;

public class OverlayService extends Service {
    public static final String ACTION_UPDATE = "com.route.app.UPDATE_OFFER";
    private WindowManager wm;
    private View panel;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !ACTION_UPDATE.equals(intent.getAction())) return START_NOT_STICKY;
        double fare = intent.getDoubleExtra("fare", 0);
        double km = intent.getDoubleExtra("km", 0);
        double minutes = intent.getDoubleExtra("minutes", 0);
        String platform = intent.getStringExtra("platform");
        int confidence = intent.getIntExtra("confidence", 0);
        if (fare > 0 && km > 0 && minutes > 0)
            showReview(fare, km, minutes, platform == null ? "Não identificada" : platform, confidence);
        return START_NOT_STICKY;
    }

    private TextView label(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color); t.setTextSize(size);
        return t;
    }

    private EditText field(String value, String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setText(value); e.setHint(hint);
        e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF9AABC5);
        e.setInputType(8194); e.setPadding(10, 4, 10, 4);
        e.setBackgroundColor(0xFF203957);
        return e;
    }

    private void showReview(double fareValue, double kmValue, double minuteValue,
                            String platform, int confidence) {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        removePanel();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 14, 18, 12);
        box.setBackgroundColor(0xFF0C1D34);
        TextView title = label("ROUTE  •  " + platform.toUpperCase(Locale.ROOT), 13, 0xFF65D4E8);
        box.addView(title);
        box.addView(label("Leitura preliminar: " + confidence + "% de confiança. Confira os dados.", 11, 0xFFB3C4DA));
        EditText fare = field(String.format(Locale.US, "%.2f", fareValue), "Valor (R$)");
        EditText km = field(String.format(Locale.US, "%.2f", kmValue), "Distância (km)");
        EditText minutes = field(String.format(Locale.US, "%.0f", minuteValue), "Tempo (min)");
        box.addView(fare); box.addView(km); box.addView(minutes);
        TextView result = label("Aguardando conferência", 13, Color.WHITE);
        result.setPadding(0, 8, 0, 8); box.addView(result);
        LinearLayout actions = new LinearLayout(this);
        Button confirm = new Button(this); confirm.setText("Confirmar");
        Button ignore = new Button(this); ignore.setText("Ignorar");
        actions.addView(confirm, new LinearLayout.LayoutParams(0, -2, 1));
        actions.addView(ignore, new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(actions);

        confirm.setOnClickListener(v -> {
            double f = parse(fare.getText().toString());
            double k = parse(km.getText().toString());
            double m = parse(minutes.getText().toString());
            if (f <= 0 || k <= 0 || m <= 0) {
                result.setText("Revise os campos: todos devem ser maiores que zero.");
                result.setTextColor(0xFFFF9CA4); return;
            }
            result.setText(String.format(new Locale("pt","BR"),
                "R$/km %.2f  •  R$/min %.2f  •  R$/hora %.2f", f/k, f/m, f/m*60));
            result.setTextColor(0xFF7FE4BD);
            confirm.setEnabled(false); confirm.setText("Conferido");
        });
        ignore.setOnClickListener(v -> { removePanel(); stopSelf(); });

        panel = box;
        int type = Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        // Janela focável para permitir edição dos campos; pode receber teclado.
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = 90;
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        try { wm.addView(panel, lp); } catch (Exception ignored) { panel = null; }
    }

    private double parse(String value) {
        try { return Double.parseDouble(value.trim().replace(',', '.')); }
        catch (Exception e) { return 0; }
    }
    private void removePanel() {
        if (panel != null && wm != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
    }
    @Override public void onDestroy() { removePanel(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
