package com.route.app;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import androidx.annotation.Nullable;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.ByteBuffer;

public class CaptureService extends Service {
    public static final String ACTION_STOP = "com.route.app.STOP_CAPTURE";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    private static final String CHANNEL = "route_capture";
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private TextRecognizer recognizer;
    private Handler handler;
    private long lastRun = 0;
    private boolean processing = false;
    private String lastOfferKey = "";
    private long lastOfferShownAt = 0;
    private String lastRawText = "";
    private int screenWidth, screenHeight, density;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopCapture();
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(77, notification());
        if (intent == null || !intent.hasExtra(EXTRA_RESULT_DATA)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        projection = mgr.getMediaProjection(resultCode, data);
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        screenWidth = dm.widthPixels; screenHeight = dm.heightPixels; density = dm.densityDpi;
        reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(r -> readFrame(r), handler);
        display = projection.createVirtualDisplay("ROUTE_SCREEN",
                screenWidth, screenHeight, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, handler);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopCapture(); stopSelf(); }
        }, handler);
        return START_NOT_STICKY;
    }

    private void readFrame(ImageReader source) {
        Image image = null;
        try {
            image = source.acquireLatestImage();
            long now = System.currentTimeMillis();
            if (image == null || processing || now - lastRun < 1400) return;
            lastRun = now; processing = true;
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int rowPadding = rowStride - pixelStride * screenWidth;
            Bitmap padded = Bitmap.createBitmap(screenWidth + rowPadding / pixelStride,
                    screenHeight, Bitmap.Config.ARGB_8888);
            padded.copyPixelsFromBuffer(buffer);
            Bitmap bitmap = Bitmap.createBitmap(padded, 0, 0, screenWidth, screenHeight);
            padded.recycle();
            InputImage input = InputImage.fromBitmap(bitmap, 0);
            recognizer.process(input)
                .addOnSuccessListener(text -> handleText(text))
                .addOnFailureListener(e -> { })
                .addOnCompleteListener(task -> {
                    processing = false;
                    bitmap.recycle();
                });
        } catch (Exception ignored) {
            processing = false;
        } finally {
            if (image != null) image.close();
        }
    }

    private void handleText(Text text) {
        String raw = text.getText();
        OfferParser.Offer offer = OfferParser.parse(raw);
        if (offer != null) {
            String key = String.format(java.util.Locale.US, "%s|%.2f|%.2f|%.0f",
                    offer.platform, offer.fare, offer.km, offer.minutes);
            long now = System.currentTimeMillis();
            // A mesma oferta permanece visível por vários frames. Não reapresentá-la
            // a cada captura; permitir reapresentação após 45 segundos.
            if (key.equals(lastOfferKey) && now - lastOfferShownAt < 45000) return;
            lastOfferKey = key;
            lastOfferShownAt = now;
            lastRawText = offer.rawText;
            Intent update = new Intent(this, OverlayService.class);
            update.setAction(OverlayService.ACTION_UPDATE);
            update.putExtra("fare", offer.fare);
            update.putExtra("km", offer.km);
            update.putExtra("minutes", offer.minutes);
            update.putExtra("raw", raw);
            update.putExtra("platform", offer.platform);
            update.putExtra("confidence", offer.confidence);
            startService(update);
        }
    }

    private Notification notification() {
        Intent stop = new Intent(this, CaptureService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 9, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("ROUTE está lendo a tela")
                .setContentText("Captura ativa. Toque em Parar para encerrar.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(new Notification.Action.Builder(null, "Parar leitura", pi).build())
                .setOngoing(true).build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Leitura ROUTE",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void stopCapture() {
        if (display != null) { display.release(); display = null; }
        if (reader != null) { reader.close(); reader = null; }
        if (projection != null) { projection.stop(); projection = null; }
        if (recognizer != null) recognizer.close();
        stopForeground(true);
    }

    @Override public void onDestroy() { stopCapture(); super.onDestroy(); }
    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
