package com.route.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_CAPTURE = 4102;
    private MediaProjectionManager projectionManager;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        projectionManager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF081225);

        LinearLayout controls = new LinearLayout(this);
        controls.setPadding(12, 12, 12, 8);
        controls.setGravity(Gravity.CENTER_VERTICAL);

        Button start = new Button(this);
        start.setText("Iniciar leitura da tela");
        start.setOnClickListener(v -> requestCapture());

        Button stop = new Button(this);
        stop.setText("Parar");
        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, CaptureService.class);
            i.setAction(CaptureService.ACTION_STOP);
            startService(i);
            status.setText("Leitura parada.");
        });

        controls.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        controls.addView(stop, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(controls);

        status = new TextView(this);
        status.setTextColor(0xFFB7C8DF);
        status.setText("A leitura só começa após sua autorização.");
        status.setPadding(16, 4, 16, 10);
        root.addView(status);

        WebView web = new WebView(this);
        web.setBackgroundColor(0xFF081225);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/route.html");
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Intent overlay = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(overlay);
            status.setText("Autorize 'Aparecer sobre outros apps' e toque novamente.");
            return;
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_CAPTURE && result == Activity.RESULT_OK && data != null) {
            Intent service = new Intent(this, CaptureService.class);
            service.putExtra(CaptureService.EXTRA_RESULT_CODE, result);
            service.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
            status.setText("Leitura autorizada. Mantenha a notificação ROUTE ativa.");
        } else if (request == REQ_CAPTURE) {
            status.setText("Captura não autorizada.");
        }
    }
}
