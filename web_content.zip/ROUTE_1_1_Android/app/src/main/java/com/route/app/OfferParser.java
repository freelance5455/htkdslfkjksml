package com.route.app;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ROUTE 1.3 — parser heurístico de ofertas.
 * Os padrões precisam ser calibrados com telas reais de cada versão de app.
 */
public class OfferParser {
    public static class Offer {
        public final double fare, km, minutes;
        public final String platform, rawText;
        public final int confidence;
        Offer(double f, double k, double m, String p, String raw, int c) {
            fare=f; km=k; minutes=m; platform=p; rawText=raw; confidence=c;
        }
    }

    private static final Pattern PRICE = Pattern.compile(
        "R\\s*\\$\\s*(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern KM = Pattern.compile(
        "(\\d{1,3}(?:[.,]\\d{1,2})?)\\s*(?:km|quil[oô]metros?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern MIN = Pattern.compile(
        "(\\d{1,3})\\s*(?:min|minuto|minutos)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern HOUR = Pattern.compile(
        "(\\d{1,2})\\s*(?:h|hora|horas)\\b", Pattern.CASE_INSENSITIVE);

    public static Offer parse(String input) {
        if (input == null || input.trim().isEmpty()) return null;
        String s = input.replace('\n', ' ').replace('\r', ' ').replaceAll("\\s+", " ").trim();

        double fare = first(PRICE, s);
        double km = first(KM, s);
        double minutes = duration(s);
        if (fare < 1 || fare > 5000 || km <= 0 || km > 1000 ||
                minutes <= 0 || minutes > 1440) return null;

        String lower = s.toLowerCase(Locale.ROOT);
        String platform = detectPlatform(lower);
        int confidence = 55;
        if (lower.contains("uber") || lower.contains("99") ||
                lower.contains("indrive") || lower.contains("lalamove")) confidence += 15;
        if (lower.contains("buscar") || lower.contains("embarque") ||
                lower.contains("destino") || lower.contains("passageiro")) confidence += 10;
        if (lower.contains("km") && (lower.contains("min") || lower.contains("hora"))) confidence += 10;
        if (lower.contains("r$")) confidence += 10;
        if (confidence > 95) confidence = 95;
        return new Offer(fare, km, minutes, platform, s, confidence);
    }

    private static String detectPlatform(String text) {
        if (text.contains("uber")) return "Uber";
        if (text.contains("99app") || text.contains("99pop") || text.matches(".*\\b99\\b.*")) return "99";
        if (text.contains("indrive")) return "InDrive";
        if (text.contains("lalamove")) return "Lalamove";
        return "Não identificada";
    }

    private static double first(Pattern p, String text) {
        Matcher m = p.matcher(text);
        if (!m.find()) return 0;
        try { return Double.parseDouble(m.group(1).replace(',', '.')); }
        catch (Exception e) { return 0; }
    }

    private static double duration(String text) {
        double h = first(HOUR, text);
        double m = first(MIN, text);
        return h > 0 ? h * 60 + m : m;
    }
}
