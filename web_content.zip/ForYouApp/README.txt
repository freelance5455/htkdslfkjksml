Build steps (Android Studio):
1. File > Open > select this ForYouApp folder; let Gradle sync (needs internet once).
2. Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
3. Install it on your phone.

BEFORE replacing your current app: open the old app and back up your diary and photos.
This build has a different package name and signing key than the old APK, so it installs
alongside it with EMPTY storage; import your backup JSON into the new one.
