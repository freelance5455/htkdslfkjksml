ALLIANCE COMPANION — NATIVE ANDROID PROJECT

This is an Android Studio project for an installable Android app, intended for the Google Pixel 7.
It packages the Alliance setup prototype into a native Android application shell.

WHAT WORKS:
- Setup welcome screen
- Simulated Alliance Ring pairing
- Simulated ChatGPT account linking
- Theme preferences
- Test Complete screen
- Home screen and chat preview

WHAT IS SIMULATED:
- No actual Bluetooth pairing with ring hardware
- No real ChatGPT account sign-in/link
- No live AI connection
- No microphone or wake-word listening

HOW TO BUILD AN APK:
1. Install Android Studio on your Windows PC or compatible computer.
2. Open the folder AllianceCompanionAndroid in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).
6. Transfer that APK to your Pixel 7, open it, and allow installation from that source if Android asks.

This environment did not have the Android SDK or Gradle installed, so it cannot compile the APK here. The included project is the buildable source project, not an APK itself.
