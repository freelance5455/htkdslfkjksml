# Auditoría de componentes — Pulguita IA v1.1

## Código específico del proyecto
- `index.html`: núcleo conversacional, memoria, relaciones, corrector, motor matemático, detección de idioma y recuperación local.
- `main.py`: lanzador Android/WebView específico del proyecto.
- `buildozer.spec`: configuración de empaquetado.
- `README.md`: documentación.
- `THIRD_PARTY_NOTICES.md`: avisos y dependencias.

## Dependencias de terceros
1. Kivy — necesario para la aplicación Android.
2. PyJNIus — necesario para puente Python/Java Android.
3. Python — runtime de construcción/ejecución.

No se eliminan estas dependencias porque reemplazarlas por código propio no aporta una ventaja práctica y puede romper la capacidad de generar el APK.

## Eliminado del núcleo
- No se incluye un modelo comercial de IA.
- No se incluye código de un proveedor de IA.
- No se incluye una copia de un diccionario comercial.
- No se incluye directamente una implementación de Wikipedia dentro del código.

## Sobre Internet
El acceso a Internet es una capacidad opcional y desacoplada. Si posteriormente se conecta un buscador o una API, ese servicio será identificado como externo y no se presentará como código propio.

## Registro
Esta auditoría es técnica, no un dictamen jurídico. La DNDA permite registrar software de autoría propia; para una presentación formal conviene conservar el código, historial de versiones, documentación y avisos de terceros.
