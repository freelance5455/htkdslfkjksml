-- Movement panel for a Roblox experience you own / are authorized to edit.
-- Place this LocalScript in StarterPlayer > StarterPlayerScripts.

local Players = game:GetService("Players")
local player = Players.LocalPlayer
local normalSpeed = 16
local boostedSpeed = 28
local normalJumpPower = 50
local boostedJumpPower = 75
local speedEnabled = false
local jumpEnabled = false

local gui = Instance.new("ScreenGui")
gui.Name = "MovementTestPanel"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Name = "Panel"
frame.Size = UDim2.fromOffset(190, 132)
frame.Position = UDim2.new(0, 12, 0.5, -66)
frame.BackgroundColor3 = Color3.fromRGB(28, 31, 42)
frame.BackgroundTransparency = 0.08
frame.Parent = gui
Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 12)

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -12, 0, 28)
title.Position = UDim2.fromOffset(6, 4)
title.BackgroundTransparency = 1
title.Text = "Movement Test"
title.TextColor3 = Color3.new(1, 1, 1)
title.TextScaled = true
title.Font = Enum.Font.GothamBold
title.Parent = frame

local function makeButton(text, y)
    local button = Instance.new("TextButton")
    button.Size = UDim2.new(1, -16, 0, 38)
    button.Position = UDim2.fromOffset(8, y)
    button.BackgroundColor3 = Color3.fromRGB(70, 95, 170)
    button.TextColor3 = Color3.new(1, 1, 1)
    button.TextScaled = true
    button.Font = Enum.Font.GothamSemibold
    button.Text = text
    button.Parent = frame
    Instance.new("UICorner", button).CornerRadius = UDim.new(0, 8)
    return button
end

local speedButton = makeButton("Speed: OFF", 36)
local jumpButton = makeButton("Jump: OFF", 80)

local function applySettings()
    local character = player.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    if not humanoid then return end
    humanoid.WalkSpeed = speedEnabled and boostedSpeed or normalSpeed
    humanoid.UseJumpPower = true
    humanoid.JumpPower = jumpEnabled and boostedJumpPower or normalJumpPower
end

speedButton.Activated:Connect(function()
    speedEnabled = not speedEnabled
    speedButton.Text = speedEnabled and "Speed: ON" or "Speed: OFF"
    applySettings()
end)

jumpButton.Activated:Connect(function()
    jumpEnabled = not jumpEnabled
    jumpButton.Text = jumpEnabled and "Jump: ON" or "Jump: OFF"
    applySettings()
end)

player.CharacterAdded:Connect(function(character)
    character:WaitForChild("Humanoid", 10)
    task.wait(0.1)
    applySettings()
end)

applySettings()
