# JIN — MADE BY AZAN

A mobile-first, iOS-inspired self-improvement web app prototype.

## Run
Open `index.html` in a modern browser. On Android, open it in Chrome. Data is saved locally in that browser using localStorage.

## Included in this prototype
- Animated JIN splash screen and Made by Azan credit
- Liquid-glass-inspired dashboard
- Finance income/expense log
- Discipline habit tracker with daily completion
- Fitness weight and activity log
- Trading journal (record-keeping only)
- Daily journal
- Mojin coach placeholder (live AI requires an API integration)
- Widget visibility settings
- Local JSON data export and reset

## Notes
This is a functional first prototype, not the complete production app. Data remains on the device/browser and is not synced between devices. Keep a backup using Export my data.
