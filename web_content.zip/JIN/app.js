const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const todayKey=()=>new Date().toISOString().slice(0,10);
const defaults=[{id:1,name:"Wake up on time",done:false},{id:2,name:"Read for 20 minutes",done:false},{id:3,name:"Exercise",done:false},{id:4,name:"Learn something new",done:false}];
let state=JSON.parse(localStorage.getItem("jin_state")||"null")||{habits:defaults,coins:0,weights:[],workouts:[],money:[],journal:[],theme:"obsidian",daily:{},streak:0};
function save(){localStorage.setItem("jin_state",JSON.stringify(state));render()}
function toast(msg){let t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}
function completed(){return state.habits.filter(h=>h.done).length}
function score(){return state.habits.length?Math.round(completed()/state.habits.length*100):0}
function render(){
 const s=score();$("#score").textContent=s;$("#ringScore").textContent=s+"%";$("#scoreRing").style.background=`conic-gradient(var(--accent) ${s*3.6}deg,rgba(255,255,255,.09) 0deg)`;
 $("#coins").textContent=state.coins;$("#coinStat").textContent=state.coins+" JN";$("#level").textContent=String(Math.floor(state.coins/200)+1).padStart(2,"0");
 $("#habitCount").textContent=`${completed()} of ${state.habits.length} habits completed`;$("#streak").textContent=(state.streak||0)+" days";
 $("#weightStat").textContent=state.weights.length?state.weights.at(-1).value+" kg":"— kg";
 const net=state.money.reduce((a,m)=>a+(m.type==="income"?m.amount:-m.amount),0);$("#savedStat").textContent="Rs "+net.toLocaleString("en-PK");$("#netSavings").textContent="Rs "+net.toLocaleString("en-PK");
 $("#habitList").innerHTML=state.habits.map(h=>habitHTML(h)).join("")||'<div class="panel muted">No habits yet. Add one above to begin.</div>';
 $("#homeHabits").innerHTML=state.habits.slice(0,4).map(h=>habitHTML(h,false)).join("")||'<p class="muted">Add your first habit to get started.</p>';
 $("#weightHistory").innerHTML=state.weights.slice().reverse().map(w=>item(`${w.value} kg`,` ${w.date}`)).join("");
 $("#workoutHistory").innerHTML=state.workouts.slice().reverse().map(w=>item(w.name,w.date)).join("");
 $("#moneyHistory").innerHTML=state.money.slice().reverse().map(m=>item(`${m.type==="income"?"+":"−"} Rs ${m.amount.toLocaleString("en-PK")} · ${m.note}`,m.date)).join("");
 $("#journalHistory").innerHTML=state.journal.slice().reverse().map(j=>item(j.text,j.date)).join("");
 document.body.dataset.theme=state.theme;
 $$(".theme-card").forEach(b=>b.classList.toggle("selected",b.dataset.theme===state.theme));
}
function item(a,b){return `<div class="history-item"><span>${escapeHTML(a)}</span><small>${escapeHTML(b||"")}</small></div>`}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function habitHTML(h,del=true){return `<div class="habit-row ${h.done?"done":""}"><button class="habit-check" data-toggle="${h.id}">${h.done?"✓":""}</button><span class="habit-name">${escapeHTML(h.name)}</span><span class="habit-reward">${h.done?"DONE":"+10 JN"}</span>${del?`<button class="delete-btn" data-delete="${h.id}" aria-label="Delete habit">×</button>`:""}</div>`}
function go(page){$$(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+page));$$(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.page===page));$(".sidebar").classList.remove("open");window.scrollTo(0,0)}
$("#today").textContent=new Intl.DateTimeFormat("en",{weekday:"short",month:"short",day:"numeric"}).format(new Date());
const hour=new Date().getHours();$("#greeting").textContent=(hour<12?"Good morning":hour<18?"Good afternoon":"Good evening")+", Azan.";
$("#nav").addEventListener("click",e=>{let b=e.target.closest("[data-page]");if(b)go(b.dataset.page)});
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("#menuBtn").onclick=()=>$(".sidebar").classList.toggle("open");
$("#addHabit").onclick=()=>{let v=$("#habitInput").value.trim();if(!v)return toast("Enter a habit first");state.habits.push({id:Date.now(),name:v,done:false});$("#habitInput").value="";save();toast("Habit added")};
$("#habitInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("#addHabit").click()});
document.addEventListener("click",e=>{
 let t=e.target.closest("[data-toggle]");if(t){let h=state.habits.find(x=>x.id==t.dataset.toggle);if(h&&!h.done){h.done=true;state.coins+=10;let doneToday=state.daily[todayKey()]||0;state.daily[todayKey()]=doneToday+1;toast("+10 JN earned")}else if(h){h.done=false;state.coins=Math.max(0,state.coins-10)}save()}
 let d=e.target.closest("[data-delete]");if(d){state.habits=state.habits.filter(h=>h.id!=d.dataset.delete);save();toast("Habit removed")}
});
$("#saveWeight").onclick=()=>{let v=Number($("#weightInput").value);if(!v||v<1||v>500)return toast("Enter a valid weight");state.weights.push({value:v,date:todayKey()});$("#weightInput").value="";save();toast("Weight saved")};
$("#saveWorkout").onclick=()=>{let v=$("#workoutInput").value.trim();if(!v)return toast("Describe your workout");state.workouts.push({name:v,date:todayKey()});$("#workoutInput").value="";save();toast("Workout logged")};
$("#addMoney").onclick=()=>{let amount=Number($("#moneyAmount").value),note=$("#moneyNote").value.trim()||"No note";if(!amount||amount<0)return toast("Enter a valid amount");state.money.push({type:$("#moneyType").value,amount,note,date:todayKey()});$("#moneyAmount").value="";$("#moneyNote").value="";save();toast("Transaction added")};
$("#saveJournal").onclick=()=>{let v=$("#journalText").value.trim();if(!v)return toast("Write something first");state.journal.push({text:v,date:todayKey()});$("#journalText").value="";save();toast("Journal entry saved")};
$$(".theme-card").forEach(b=>b.onclick=()=>{let cost={obsidian:0,violet:150,ocean:250,ember:350}[b.dataset.theme];if(state.theme===b.dataset.theme)return;if(state.coins<cost)return toast("Not enough JN yet");state.coins-=cost;state.theme=b.dataset.theme;save();toast("Theme unlocked")});
render();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
