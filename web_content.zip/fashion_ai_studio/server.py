"""Small backend proxy for FASHN Virtual Try-On. Keep API keys on the server."""
import os, time, base64, re
from flask import Flask, request, jsonify, send_from_directory
import requests

ROOT = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=ROOT, static_url_path='')
app.config['MAX_CONTENT_LENGTH'] = 12 * 1024 * 1024
FASHN_API_KEY = os.getenv('FASHN_API_KEY', '').strip()
API_BASE = 'https://api.fashn.ai/v1'


def data_uri(value, field):
    if not isinstance(value, str) or not value.startswith('data:image/') or ';base64,' not in value:
        raise ValueError(f'{field} की image सही तरह से upload नहीं हुई।')
    header, payload = value.split(',', 1)
    if not re.match(r'^data:image/(png|jpeg|jpg|webp);base64$', header, re.I):
        raise ValueError(f'{field} में JPG, PNG या WEBP फोटो इस्तेमाल करें।')
    try:
        raw = base64.b64decode(payload, validate=True)
    except Exception:
        raise ValueError(f'{field} की image data पढ़ी नहीं जा सकी।')
    if len(raw) > 5 * 1024 * 1024:
        raise ValueError(f'{field} फोटो 5 MB से छोटी रखें।')
    return value


@app.get('/')
def home():
    return send_from_directory(ROOT, 'index.html')


@app.get('/api/health')
def health():
    return jsonify({'ok': True, 'api_key_configured': bool(FASHN_API_KEY)})


@app.post('/api/tryon')
def tryon():
    if not FASHN_API_KEY:
        return jsonify({'error': 'सर्वर पर FASHN_API_KEY सेट नहीं है। पहले API key सेट करें।'}), 503
    try:
        body = request.get_json(force=True)
        model_image = data_uri(body.get('model_image'), 'मॉडल')
        garment_image = data_uri(body.get('garment_image'), 'कपड़े')
        # Cultural garments are best sent through automatic classification.
        kind = body.get('kind', 'top')
        category = 'tops' if kind == 'top' else ('bottoms' if kind == 'bottoms' else 'auto')
        payload = {
            'model_name': 'tryon-v1.6',
            'inputs': {
                'model_image': model_image,
                'garment_image': garment_image,
                'category': category,
                'mode': 'balanced',
                'num_samples': 1,
                'output_format': 'jpeg',
                'return_base64': True,
                'moderation_level': 'conservative'
            }
        }
        r = requests.post(f'{API_BASE}/run', headers={'Authorization': f'Bearer {FASHN_API_KEY}', 'Content-Type': 'application/json'}, json=payload, timeout=60)
        if r.status_code >= 400:
            try: details = r.json().get('message') or r.json().get('error') or 'FASHN API error'
            except Exception: details = 'FASHN API error'
            return jsonify({'error': f'FASHN API ने अनुरोध अस्वीकार किया ({r.status_code}): {details}'}), 502
        result = r.json()
        prediction_id = result.get('id')
        if not prediction_id:
            return jsonify({'error': 'AI सेवा से prediction ID नहीं मिला।'}), 502
        deadline = time.time() + 110
        while time.time() < deadline:
            time.sleep(2)
            poll = requests.get(f'{API_BASE}/status/{prediction_id}', headers={'Authorization': f'Bearer {FASHN_API_KEY}'}, timeout=30)
            if poll.status_code >= 400:
                return jsonify({'error': 'AI status जाँचने में समस्या हुई।'}), 502
            status = poll.json()
            if status.get('status') == 'completed':
                output = status.get('output') or []
                if output:
                    image = output[0]
                    if isinstance(image, str) and image.startswith('data:image/'):
                        return jsonify({'image': image})
                    # When service returns a CDN URL, download and return it as data URI.
                    img_resp = requests.get(image, timeout=45)
                    img_resp.raise_for_status()
                    mime = img_resp.headers.get('content-type', 'image/jpeg').split(';')[0]
                    encoded = base64.b64encode(img_resp.content).decode('ascii')
                    return jsonify({'image': f'data:{mime};base64,{encoded}'})
                return jsonify({'error': 'AI ने कोई image output नहीं दिया।'}), 502
            if status.get('status') == 'failed':
                err = status.get('error') or {}
                return jsonify({'error': err.get('message', 'AI generation failed')}), 502
        return jsonify({'error': 'AI को अधिक समय लग रहा है। थोड़ी देर बाद फिर कोशिश करें।'}), 504
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except requests.RequestException:
        return jsonify({'error': 'इंटरनेट या AI सेवा से कनेक्शन नहीं हो पाया।'}), 502
    except Exception:
        app.logger.exception('Virtual try-on error')
        return jsonify({'error': 'सर्वर में समस्या हुई। सर्वर लॉग जाँचें।'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', '8000')), debug=False)
