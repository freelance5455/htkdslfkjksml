FASHION AI STUDIO — AI VIRTUAL TRY-ON

This starter includes:
- Responsive Hindi/English web app and PWA manifest
- Model and garment photo upload
- FASHN Virtual Try-On backend proxy (API key stays server-side)
- Render deployment configuration
- Capacitor Android wrapper starter configuration
- Hindi instructions for phone use, website deployment, and APK building in ALL_THREE_SETUP_HINDI.txt

REAL AI REQUIREMENTS
A valid FASHN API key must be configured as the server environment variable FASHN_API_KEY. FASHN account, credits and current pricing/terms may apply. No private API key is included, and live AI generation has not been tested with a real key.

WEBSITE
See ALL_THREE_SETUP_HINDI.txt for deployment steps. The included render.yaml and Procfile are deployment helpers.

ANDROID PHONE
After deploying the HTTPS website, open it in Chrome and use Add to Home screen / Install app for the PWA experience.

ANDROID APK
The package.json and capacitor.config.json are starter files for a Capacitor Android wrapper. Replace the example HTTPS URL with your deployed site, then use Node.js and Android Studio on a computer to build an APK. This ZIP is not itself a compiled APK.

SECURITY
Never put FASHN_API_KEY into browser JavaScript, the Android app, or a public repository. Add it only as a secret environment variable in your hosting dashboard. Upload photos only with permission.
