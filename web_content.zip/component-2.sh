npm install @base-ui/react@1.6.0 class-variance-authority@0.7.1 clsx@2.1.1 \
  lucide-react@1.23.0 react@19.2.7 react-dom@19.2.7 sonner@2.0.7 \
  tailwind-merge@3.6.0 tailwindcss @tailwindcss/vite