'use strict';
const CACHE_PREFIX = 'dark-mohkam-pro74';
const STATIC_CACHE = `${CACHE_PREFIX}-static-v3`;
const RUNTIME_CACHE = `${CACHE_PREFIX}-runtime-v3`;
const CORE_ASSETS = ['./', './index.html', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(STATIC_CACHE).then(cache => cache.addAll(CORE_ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith(CACHE_PREFIX) && ![STATIC_CACHE, RUNTIME_CACHE].includes(key)).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  const isAsset = ['script', 'style', 'font', 'image'].includes(request.destination);

  if (url.origin === self.location.origin) {
    if (request.mode === 'navigate') {
      event.respondWith((async () => {
        try {
          const response = await fetch(request);
          if (response && response.ok) {
            const cache = await caches.open(STATIC_CACHE);
            await cache.put('./index.html', response.clone());
          }
          return response;
        } catch (_) {
          return (await caches.match(request)) || (await caches.match('./index.html'));
        }
      })());
      return;
    }
    event.respondWith((async () => {
      const cached = await caches.match(request);
      if (cached) return cached;
      const response = await fetch(request);
      if (response && response.ok) {
        const cache = await caches.open(STATIC_CACHE);
        await cache.put(request, response.clone());
      }
      return response;
    })());
    return;
  }

  // Cache CDN scripts/styles/fonts after the first successful online load.
  // Opaque cross-origin responses are cacheable and can be reused offline.
  if (isAsset) {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response && (response.ok || response.type === 'opaque')) {
          const cache = await caches.open(RUNTIME_CACHE);
          await cache.put(request, response.clone());
        }
        return response;
      } catch (_) {
        return (await caches.match(request)) || Response.error();
      }
    })());
  }
});
