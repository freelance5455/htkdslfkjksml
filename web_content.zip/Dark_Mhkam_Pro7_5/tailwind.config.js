/** Local Tailwind build: removes the dependency on the Play CDN (which is not meant for production). */
module.exports = {
  content: ['./www/index.html'],
  theme: { extend: {} },
  plugins: []
};
