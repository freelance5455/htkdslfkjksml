    (function () {
        'use strict';

        // ===== حماية من الـ Clickjacking: لو الصفحة اتفتحت جوه iframe نخفيها ونحاول نخرج منه =====
        if (window.top !== window.self) {
            document.documentElement.style.display = 'none';
            try { window.top.location.href = window.self.location.href; } catch (e) { /* متحجوب */ }
            return;
        }

        //  إعدادات 
        const HISTORY_CODE = '250'; 
        const HISTORY_KEY = 'examLinkHistory';
        const MAX_HISTORY = 50;
        const TYPING_DELAY = 2000;

        const $ = (id) => document.getElementById(id);
        const input = $('examLink');
        const errorText = $('errorText');
        const historyBox = $('history');
        const historyList = $('historyList');

        // اللغات
        const I18N = {
            ar: {
                dir: 'rtl', locale: 'ar-EG', switchTo: 'EN',
                title: 'Exam - واجهة الامتحان',
                label: 'رابط الامتحان:',
                placeholder: 'الصق الرابط هنا وسيتم التوجيه تلقائياً...',
                hint: 'دعاء🌿: قل اللهم لا سهل الا ما جعلتة سهلا تجعل الصعب ان شئت سهلا .',
                start: 'امتحني؟ ',
                historyTitle: 'سجل الروابط',
                clearAll: 'مسح الكل',
                empty: 'لسه مفيش روابط. أي رابط تفتحه هيتسجل هنا.',
                del: 'حذف الرابط',
                theme: 'تبديل الوضع',
                lang: 'Switch to English',
                contact: 'تواصل معي',
                web: 'ويب',
                invalid: 'الرابط غير صحيح! تأكد من كتابة الموقع بشكل'
            },
            en: {
                dir: 'ltr', locale: 'en-US', switchTo: 'عربي',
                title: 'Exam',
                label: 'Exam link:',
                placeholder: "Paste the link here and you'll be redirected automatically...",
                hint: '🌿Supplication: Say, "O Allah, there is nothing easy except what You make easy; You make the difficult easy if You will." .',
                start: 'Start the exam',
                historyTitle: 'Link history',
                clearAll: 'Clear all',
                empty: 'No links yet. Any link you open will be saved here.',
                del: 'Delete link',
                theme: 'Toggle theme',
                lang: 'التبديل إلى العربية',
                contact: 'Contact me',
                web: 'Web',
                invalid: 'Invalid link! Check the address (http or https only).'
            }
        };
        // تجميد النصوص عشان محدّش يعدّل عليها وقت التشغيل
        Object.freeze(I18N.ar);
        Object.freeze(I18N.en);
        Object.freeze(I18N);

        let lang = storageGet('lang') === 'en' ? 'en' : 'ar';
        // قراءة آمنة: بس المفاتيح الموجودة فعلاً (بدون الوصول لـ __proto__ أو constructor)
        const t = (key) => (Object.prototype.hasOwnProperty.call(I18N[lang], key) ? I18N[lang][key] : '');

        // ===== أيقونات الوضع =====
        const svgNS = 'http://www.w3.org/2000/svg';
        function makeIcon(paths) {
            const svg = document.createElementNS(svgNS, 'svg');
            svg.setAttribute('class', 'icon');
            svg.setAttribute('viewBox', '0 0 24 24');
            svg.setAttribute('aria-hidden', 'true');
            paths.forEach((d) => {
                const p = document.createElementNS(svgNS, 'path');
                p.setAttribute('d', d);
                svg.appendChild(p);
            });
            return svg;
        }
        const ICONS = {
            moon: ['M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z'],
            sun: ['M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z', 'M12 2v2', 'M12 20v2', 'm4.93 4.93 1.41 1.41', 'm17.66 17.66 1.41 1.41', 'M2 12h2', 'M20 12h2', 'm6.34 17.66-1.41 1.41', 'm19.07 4.93-1.41 1.41'],
            x: ['M18 6 6 18', 'm6 6 12 12']
        };

        // ===== تخزين آمن =====
        function storageGet(key) {
            try { return localStorage.getItem(key); } catch (e) { return null; }
        }
        function storageSet(key, value) {
            try { localStorage.setItem(key, value); } catch (e) { /* التخزين غير متاح */ }
        }

        // ===== الوضع الداكن/الفاتح =====
        const themeToggle = $('themeToggle');
        function applyTheme(dark) {
            document.body.classList.toggle('dark-mode', dark);
            themeToggle.replaceChildren(makeIcon(dark ? ICONS.sun : ICONS.moon));
        }
        const savedTheme = storageGet('theme');
        applyTheme(savedTheme ? savedTheme === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches);
        themeToggle.addEventListener('click', () => {
            const dark = !document.body.classList.contains('dark-mode');
            applyTheme(dark);
            storageSet('theme', dark ? 'dark' : 'light');
        });

        // ===== التحقق من الرابط (http/https فقط) =====
        function normalizeUrl(raw) {
            let value = String(raw).trim();
            // يرفض المسافات وحروف التحكم والحروف المخفية وحروف قلب الاتجاه (تُستخدم في تزييف الروابط)
            if (!value || value.length > 2048 || /[\s\u0000-\u001f\u007f-\u009f\u00ad\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]/.test(value)) return null;

            if (!/^https?:\/\//i.test(value)) {
                // أي بروتوكول تاني (javascript: data: file: ...) مرفوض
                if (/^[a-z][a-z0-9+.\-]*:(?!\d)/i.test(value) || value.startsWith('//')) return null;
                value = 'https://' + value;
            }

            let url;
            try { url = new URL(value); } catch (e) { return null; }

            if (url.protocol !== 'https:' && url.protocol !== 'http:') return null;
            if (url.username || url.password) return null; // يمنع روابط التصيّد user@site
            // دومين حقيقي فقط: آخر جزء لازم يبدأ بحرف (يرفض عناوين IP زي 127.0.0.1 و192.168.x.x)
            if (!/^(?:[a-z0-9-]+\.)+[a-z][a-z0-9-]+$/i.test(url.hostname)) return null;
            // يرفض الدومينات الداخلية
            if (/\.(?:local|localhost|internal|lan|home|corp)$/i.test(url.hostname)) return null;
            if (url.href.length > 2048) return null;
            return url;
        }

        let errorKey = '';
        function showError(key) {
            errorKey = key || '';
            errorText.textContent = errorKey ? t(errorKey) : '';
        }

        // ===== السجل =====
        function loadHistory() {
            let items;
            const raw = storageGet(HISTORY_KEY) || '[]';
            if (raw.length > 200000) return []; // حجم غير طبيعي = تلاعب
            try { items = JSON.parse(raw); } catch (e) { items = []; }
            if (!Array.isArray(items)) return [];
            // نعيد التحقق من كل عنصر قبل استخدامه
            return items
                .filter((it) => it && typeof it.url === 'string' && normalizeUrl(it.url))
                .map((it) => ({ url: normalizeUrl(it.url).href, time: Number.isFinite(Number(it.time)) ? Number(it.time) : 0 }))
                .slice(0, MAX_HISTORY);
        }
        function saveHistory(items) { storageSet(HISTORY_KEY, JSON.stringify(items.slice(0, MAX_HISTORY))); }

        function addToHistory(href) {
            const items = loadHistory().filter((it) => it.url !== href);
            items.unshift({ url: href, time: Date.now() });
            saveHistory(items);
        }

        function formatTime(ts) {
            if (!ts) return '';
            try {
                return new Date(ts).toLocaleString(t('locale'), { dateStyle: 'medium', timeStyle: 'short' });
            } catch (e) { return ''; }
        }

        function renderHistory() {
            const items = loadHistory();
            historyList.replaceChildren();

            if (!items.length) {
                const empty = document.createElement('li');
                empty.className = 'history-empty';
                empty.textContent = t('empty');
                historyList.appendChild(empty);
                return;
            }

            items.forEach((it) => {
                const url = new URL(it.url);
                const li = document.createElement('li');

                const open = document.createElement('button');
                open.type = 'button';
                open.className = 'history-open';
                open.title = it.url;

                const host = document.createElement('b');
                host.textContent = url.hostname;
                const full = document.createElement('small');
                full.textContent = it.url;
                const time = document.createElement('time');
                time.textContent = formatTime(it.time);
                open.append(host, full, time);
                open.addEventListener('click', () => go(url));

                const del = document.createElement('button');
                del.type = 'button';
                del.className = 'history-del';
                del.setAttribute('aria-label', t('del'));
                del.appendChild(makeIcon(ICONS.x));
                del.addEventListener('click', () => {
                    saveHistory(loadHistory().filter((x) => x.url !== it.url));
                    renderHistory();
                });

                li.append(open, del);
                historyList.appendChild(li);
            });
        }

        function showHistory() {
            renderHistory();
            historyBox.hidden = false;
            showError('');
        }
        function hideHistory() { historyBox.hidden = true; }

        $('clearAll').addEventListener('click', () => {
            saveHistory([]);
            renderHistory();
        });

        // ===== تطبيق اللغة =====
        const langToggle = $('langToggle');
        function applyLang() {
            const d = I18N[lang];
            document.documentElement.lang = lang;
            document.documentElement.dir = d.dir;
            document.title = d.title;
            document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
            document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => { el.placeholder = t(el.dataset.i18nPlaceholder); });
            themeToggle.setAttribute('aria-label', d.theme);
            themeToggle.title = d.theme;
            langToggle.setAttribute('aria-label', d.lang);
            langToggle.title = d.lang;
            $('langLabel').textContent = d.switchTo;
            historyBox.setAttribute('aria-label', d.historyTitle);
            showError(errorKey);
            if (!historyBox.hidden) renderHistory();
        }
        langToggle.addEventListener('click', () => {
            lang = lang === 'ar' ? 'en' : 'ar';
            storageSet('lang', lang);
            applyLang();
        });
        applyLang();

        // ===== التوجيه =====
        function go(url) {
            addToHistory(url.href);
            window.location.assign(url.href);
        }

        let typingTimer;

        function startExam() {
            clearTimeout(typingTimer);
            const value = input.value.trim();
            if (value === '') return;

            if (value === HISTORY_CODE) {
                showHistory();
                input.value = '';
                return;
            }

            const url = normalizeUrl(value);
            if (!url) {
                showError('invalid');
                return;
            }
            showError('');
            go(url);
        }

        // نقبل بس الأحداث الحقيقية من المستخدم (مش اللي يتولّدها سكربت)
        $('startBtn').addEventListener('click', (e) => { if (e.isTrusted) startExam(); });

        // لصق الرابط = توجيه فوري
        input.addEventListener('paste', (e) => {
            if (!e.isTrusted) return;
            setTimeout(startExam, 400);
        });

        // كتابة يدوية = توجيه بعد التوقف
        input.addEventListener('input', (e) => {
            if (!e.isTrusted) return;
            clearTimeout(typingTimer);
            showError('');
            const value = input.value.trim();

            if (value === HISTORY_CODE) {
                typingTimer = setTimeout(startExam, 300);
                return;
            }
            hideHistory();

            if (value.length > 5 && (value.includes('.') || value.includes('http')) && normalizeUrl(value)) {
                typingTimer = setTimeout(startExam, TYPING_DELAY);
            }
        });

        input.addEventListener('keydown', (event) => {
            if (event.isTrusted && event.key === 'Enter') {
                event.preventDefault();
                startExam();
            }
        });
    })();
