BIN GOLD & SILVER — Android Studio project

This is an Android WebView wrapper around the offline gold mixing calculator.
It does not require internet access after installation.

Build APK:
1. Install Android Studio on a computer.
2. Open this folder (BinGoldMixerAndroid) in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be at:
   app/build/outputs/apk/debug/app-debug.apk

For a signed release APK:
Build > Generate Signed Bundle / APK > APK, then create/select a keystore.

Application ID: com.bingold.mixer
Minimum Android: 6.0 (API 23)
