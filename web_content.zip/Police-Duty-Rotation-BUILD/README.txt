Police Duty Rotation - Build Package

MASTER SOURCE:
index.html is an unchanged copy of Police-Duty-Rotation-FINAL-PRODUCTION-V3.html.

Targets:
1. Android APK (WebView/Capacitor wrapper)
2. Windows EXE (Electron wrapper)

IMPORTANT:
Do not edit index.html. Use the supplied Police logo as the launcher/application icon when available.
This package is source/build-ready, but binary compilation requires Android SDK/Gradle for APK and a Windows build environment (or electron-builder on a compatible environment) for EXE.
