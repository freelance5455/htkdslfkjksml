# Sunset Beach Gestão v5 — PC + Caixa + Garçom + Cozinha + Sincronização

## O que esta versão estrutura
- PC como caixa/gerência principal.
- Modo Garçom para Android/iPhone via navegador/PWA.
- Tela de Cozinha.
- Fila de pedidos.
- Produtos, mesas e relatórios.
- Sincronização por API quando os aparelhos têm acesso ao servidor.
- Fila local de ações para continuar trabalhando quando o aparelho fica offline.
- Impressão por diálogo do navegador; impressão física automática ainda requer integração específica com a impressora.

## Rodar no PC
1. Instale Node.js 18+.
2. Abra um terminal nesta pasta.
3. Execute `npm start`.
4. No PC, abra `http://localhost:8080`.
5. Para celulares na mesma rede Wi-Fi, descubra o IP do PC (ex.: 192.168.0.10) e abra `http://192.168.0.10:8080`.

## Importante sobre sincronização
Esta v5 usa um servidor local simples com arquivo `data.json`. Isso é uma base funcional para teste e operação em rede local. Para produção, recomenda-se trocar o arquivo por PostgreSQL/Supabase/Firebase ou outro banco central, com autenticação, HTTPS, controle de concorrência, backup e logs.

## APK
O HTML pode continuar sendo empacotado no APK para operação offline, mas o APK sozinho não cria sincronização entre celulares. Para sincronizar, o app precisa alcançar este servidor/API (local ou na nuvem).
