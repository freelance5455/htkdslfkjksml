const http=require('http'), fs=require('fs'), path=require('path'), crypto=require('crypto');
const PORT=process.env.PORT||8080, ROOT=__dirname, DATA=path.join(ROOT,'data.json');
function initial(){return {version:1,products:[
{id:'p1',name:'Cerveja',price:10,category:'Bebidas'},{id:'p2',name:'Porção',price:35,category:'Porções'},{id:'p3',name:'Refrigerante',price:7,category:'Bebidas'},{id:'p4',name:'Jantinha',price:25,category:'Pratos'}],tables:Array.from({length:25},(_,i)=>({id:i+1,name:'Mesa '+(i+1),customer:'',items:[]})),orders:[],sales:[],payments:[],deliveries:[],staff:[]}}
let db=fs.existsSync(DATA)?JSON.parse(fs.readFileSync(DATA)):initial();
function save(){fs.writeFileSync(DATA,JSON.stringify(db,null,2))}
const clients=new Set();
function send(res,status,obj,headers={}){const b=JSON.stringify(obj);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers,'Content-Length':Buffer.byteLength(b)});res.end(b)}
function parse(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>s+=c);req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}})})}
function broadcast(){const msg=`data: ${JSON.stringify({type:'state',at:Date.now()})}\n\n`;for(const r of clients){try{r.write(msg)}catch{clients.delete(r)}}}
function mutate(fn){fn();db.version++;save();broadcast()}
function notFound(res){send(res,404,{error:'Não encontrado'})}
const server=http.createServer(async(req,res)=>{
 try{
  if(req.url==='/api/events'){res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','Access-Control-Allow-Origin':'*'});res.write(`data: ${JSON.stringify({type:'state',at:Date.now()})}\n\n`);clients.add(res);req.on('close',()=>clients.delete(res));return}
  if(req.url==='/api/state'&&req.method==='GET')return send(res,200,db);
  if(req.url==='/api/health')return send(res,200,{ok:true,version:db.version});
  if(req.url==='/api/products'&&req.method==='POST'){const x=await parse(req);if(!x.name)return send(res,400,{error:'Nome obrigatório'});const p={id:crypto.randomUUID(),name:String(x.name),price:Number(x.price||0),category:String(x.category||'Geral')};mutate(()=>db.products.push(p));return send(res,201,p)}
  if(req.url==='/api/orders'&&req.method==='POST'){const x=await parse(req);if(!x.table||!Array.isArray(x.items)||!x.items.length)return send(res,400,{error:'Pedido inválido'});const o={id:crypto.randomUUID(),table:x.table,tableId:x.tableId||null,customer:x.customer||'',waiter:x.waiter||'Garçom',items:x.items,total:Number(x.total||0),status:'novo',createdAt:new Date().toISOString()};mutate(()=>db.orders.push(o));return send(res,201,o)}
  const m=req.url.match(/^\/api\/orders\/([^/]+)\/status$/); if(m&&req.method==='POST'){const x=await parse(req),o=db.orders.find(z=>z.id===m[1]);if(!o)return notFound(res);mutate(()=>{o.status=String(x.status||'novo');o.updatedAt=new Date().toISOString();if(o.status==='pago'){db.sales.push({id:crypto.randomUUID(),orderId:o.id,total:o.total,items:o.items,waiter:o.waiter,table:o.table,payment:x.payment||'Não informado',date:new Date().toISOString()})}});return send(res,200,o)}
  const tm=req.url.match(/^\/api\/tables\/(\d+)$/); if(tm&&req.method==='PUT'){const x=await parse(req),t=db.tables.find(z=>z.id===Number(tm[1]));if(!t)return notFound(res);mutate(()=>{if(x.name!==undefined)t.name=String(x.name);if(x.customer!==undefined)t.customer=String(x.customer);if(Array.isArray(x.items))t.items=x.items});return send(res,200,t)}
  if(req.url==='/api/sync'&&req.method==='POST'){const x=await parse(req);const results=[];for(const a of (x.actions||[])){try{if(a.type==='order'){const o=a.order;const existing=db.orders.find(z=>z.id===o.id);if(!existing)db.orders.push(o);results.push({id:o.id,ok:true})}else if(a.type==='table'){const t=db.tables.find(z=>z.id===a.table.id);if(t)Object.assign(t,a.table);results.push({id:a.table.id,ok:true})}else results.push({ok:false,error:'Ação desconhecida'})}catch(e){results.push({ok:false,error:e.message})}}db.version++;save();broadcast();return send(res,200,{version:db.version,results})}
  if(req.url.startsWith('/api/') ) return notFound(res);
  let u=req.url.split('?')[0]; if(u==='/')u='/index.html'; const fp=path.join(ROOT,'www',path.normalize(u).replace(/^\/+/,''));if(!fp.startsWith(path.join(ROOT,'www')))return notFound(res);if(!fs.existsSync(fp))return notFound(res);const ext=path.extname(fp),types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':'no-cache'});fs.createReadStream(fp).pipe(res)
 }catch(e){console.error(e);send(res,500,{error:'Erro interno',detail:e.message})}
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Sunset Beach Gestão: http://0.0.0.0:${PORT}`));
