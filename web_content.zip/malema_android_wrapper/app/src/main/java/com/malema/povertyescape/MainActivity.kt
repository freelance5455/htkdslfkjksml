package com.malema.povertyescape

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var webView: WebView
    private var pageLoaded = false

    // NOTE: For stronger security, replace this with a server-verified credential or Android Keystore-backed design.
    // This app password is not the same as your Deriv password or PAT token.
    private val fallbackPassword = "MosMal_Kolobe"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        val title = TextView(this).apply {
            text = "💀  MALEMA POVERTY ESCAPE\n\nVerify your fingerprint to unlock"
            setTextColor(android.graphics.Color.WHITE)
            textSize = 20f
            gravity = android.view.Gravity.CENTER
            setPadding(24, 48, 24, 24)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val hint = TextView(this).apply {
            text = "If fingerprint is unavailable, choose Use password."
            setTextColor(android.graphics.Color.LTGRAY)
            textSize = 14f
            gravity = android.view.Gravity.CENTER
            setPadding(24, 12, 24, 24)
        }
        root.addView(hint, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        authenticate()
    }

    private fun authenticate() {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            showPasswordFallback("Fingerprint authentication isn't available on this device.")
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                unlockApp()
            }
            override fun onAuthenticationFailed() {
                Toast.makeText(this@MainActivity, "Fingerprint not recognised. Try again or use password.", Toast.LENGTH_SHORT).show()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON ||
                    errorCode == BiometricPrompt.ERROR_USER_CANCELED ||
                    errorCode == BiometricPrompt.ERROR_CANCELED ||
                    errorCode == BiometricPrompt.ERROR_NO_BIOMETRICS ||
                    errorCode == BiometricPrompt.ERROR_HW_NOT_PRESENT ||
                    errorCode == BiometricPrompt.ERROR_HW_UNAVAILABLE) {
                    showPasswordFallback(errString.toString())
                } else {
                    Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show()
                }
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("MALEMA POVERTY ESCAPE")
            .setSubtitle("Unlock with your fingerprint")
            .setNegativeButtonText("Use password")
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(info)
    }

    private fun showPasswordFallback(message: String) {
        val input = EditText(this).apply {
            hint = "Enter app password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val pad = (resources.displayMetrics.density * 24).toInt()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, 0, pad, 0)
            addView(TextView(this@MainActivity).apply {
                text = message
                setPadding(0, 0, 0, pad / 2)
            })
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Password fallback")
            .setView(container)
            .setCancelable(false)
            .setPositiveButton("Unlock") { _, _ ->
                if (input.text.toString() == fallbackPassword) unlockApp()
                else {
                    Toast.makeText(this, "Incorrect password", Toast.LENGTH_LONG).show()
                    showPasswordFallback("Incorrect password. Try again.")
                }
            }
            .setNegativeButton("Retry fingerprint") { _, _ -> authenticate() }
            .show()
    }

    private fun unlockApp() {
        if (pageLoaded) return
        pageLoaded = true
        root.removeAllViews()
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(webView, LinearLayout.LayoutParams(-1, -1))
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
