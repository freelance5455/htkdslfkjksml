MALEMA POVERTY ESCAPE — Android biometric wrapper starter project

WHAT THIS PROJECT DOES
- Wraps the supplied HTML bot in an Android WebView.
- Shows Android's real biometric prompt before the HTML app is opened.
- Offers the app password as a fallback when biometrics are unavailable or the user chooses Use password.
- Keeps the HTML bot's interface and Deriv controls in the packaged assets.

IMPORTANT
- This is an Android Studio project, not a compiled APK. It has not been built or tested on a phone in this environment.
- To build an APK for free, install Android Studio, open this folder, allow Gradle sync, then choose Build > Build APK(s).
- Fingerprint only works on a phone/tablet that has biometric hardware and at least one fingerprint enrolled in Android Settings.
- The fallback password is embedded in the app source and can be extracted by a determined person. This is a basic personal lock, not high-security authentication. For stronger security we should change the fallback design before using it to protect sensitive information.
- Do not paste your Deriv PAT token into chats or share the APK with anyone you don't trust.
- This wrapper does not repair or validate the Deriv API/WebSocket trading logic. Test the connection and any trade logic on demo before risking money.
