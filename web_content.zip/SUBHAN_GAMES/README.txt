SUBHAN GAMES

Open index.html in Chrome or another modern browser. This is an offline mini-game hub with six games: Subhan Battle Arena, Snake Rush, Tic Tac Toe, Memory Match, Sky Dodge, and Number Rush. Tap PLAY NOW on a game card.

The Arena is the existing browser demo. This package is not a Roblox clone, does not include online multiplayer, and is not an installable APK.
