SUBHAN GAMES — DELUXE OFFLINE DEMO

START:
1. Extract this ZIP.
2. Open index.html in a modern browser (Chrome recommended).
3. Type a player name and tap OK / ENTER ARENA.

FEATURES:
- Neon pseudo-3D arena with perspective floor and 3D-style buildings
- Buildings block movement and shots, so use them as cover
- Three weapons: Rifle, Shotgun, Rapid
- Visible player projectiles and muzzle flashes
- Enemy bots now shoot back with red projectiles and can be blocked by buildings
- Touch joystick, FIRE, DASH, weapon switch, heal, pause and restart
- Coins, health, enemy waves, saved player name and best wave on this device
- Keyboard support: WASD / arrow keys to move, Space to fire, Shift to dash, Escape to pause

IMPORTANT:
This is an offline HTML canvas demo with 3D-style/pseudo-3D graphics, not a full 3D engine or installable APK. Real online multiplayer between phones requires a server and networking code. If your app-builder shows an error for a local HTML file, use its local assets / web folder import option rather than opening a temporary preview URL.
