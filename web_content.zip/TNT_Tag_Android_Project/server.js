const WebSocket = require('ws');
const http = require('http');
const crypto = require('crypto');
const PORT = process.env.PORT || 8080;
const server = http.createServer((req,res)=>{ res.writeHead(200, {'Content-Type':'text/plain'}); res.end('TNT Tag multiplayer server is running.'); });
const wss = new WebSocket.Server({server});
const rooms = new Map();
const COLORS = ['#ffd83d','#ffffff','#ff4c4c','#46a6ff','#4fe078','#b77aff'];
const now = () => Date.now();
function code(){ return Math.random().toString(36).slice(2,6).toUpperCase(); }
function send(ws,obj){ if(ws.readyState===WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function publicRoom(r){ return {code:r.code, status:r.status, players:[...r.players.values()].map(p=>({id:p.id,name:p.name,color:p.color,x:p.x,y:p.y,alive:p.alive,hasTnt:p.hasTnt,ready:p.ready})),round:r.round,deadline:r.deadline,tagHolder:r.tagHolder}; }
function broadcast(r){ const msg=JSON.stringify({type:'state',room:publicRoom(r)}); for(const p of r.players.values()) if(p.ws.readyState===WebSocket.OPEN) p.ws.send(msg); }
function resetRound(r){
 const all=[...r.players.values()];
 if(r.round===1) all.forEach(p=>{p.alive=true;});
 const ps=all.filter(p=>p.alive);
 if(ps.length<2){r.status='finished';r.deadline=null;r.tagHolder=null;r.winner=ps[0]?.id||null;return;}
 r.status='playing'; r.deadline=now()+30000; r.tagHolder=ps[Math.floor(Math.random()*ps.length)].id;
 ps.forEach((p,i)=>{p.hasTnt=p.id===r.tagHolder;p.x=80+i*95;p.y=280;p.vx=0;p.vy=0;});
 all.filter(p=>!p.alive).forEach(p=>p.hasTnt=false);
}
function finishRound(r){
 const alive=[...r.players.values()].filter(p=>p.alive);
 if(alive.length<=1){r.status='finished';r.winner=alive[0]?.id||null;r.deadline=null;r.tagHolder=null;}
 else { r.round++; resetRound(r); }
}
function removePlayer(p){
 const r=rooms.get(p.roomCode); if(!r)return;
 r.players.delete(p.id);
 if(r.players.size===0){rooms.delete(r.code);return;}
 if(r.status==='playing') finishRound(r);
 broadcast(r);
}
wss.on('connection', ws=>{
 ws.id=crypto.randomUUID(); ws.roomCode=null;
 send(ws,{type:'hello',id:ws.id});
 ws.on('message', raw=>{
  let m; try{m=JSON.parse(raw.toString())}catch{return;}
  if(m.type==='create' || m.type==='join'){
   if(ws.roomCode) return;
   let r;
   if(m.type==='create'){
    let c=code(); while(rooms.has(c)) c=code();
    r={code:c,players:new Map(),status:'waiting',round:1,deadline:null,tagHolder:null,winner:null}; rooms.set(c,r);
   } else r=rooms.get(String(m.code||'').toUpperCase());
   if(!r){send(ws,{type:'error',message:'Room not found. Check the code.'});return;}
   if(r.players.size>=6){send(ws,{type:'error',message:'Room is full (maximum 6 players).'});return;}
   if(r.status==='playing'||r.status==='finished'){send(ws,{type:'error',message:'This match has already started.'});return;}
   const p={id:ws.id,ws,roomCode:r.code,name:String(m.name||'Player').slice(0,14),color:COLORS[r.players.size%COLORS.length],x:100+r.players.size*90,y:280,vx:0,vy:0,alive:true,hasTnt:false,ready:false,lastMove:0};
   r.players.set(p.id,p); ws.roomCode=r.code;
   send(ws,{type:'joined',id:p.id,roomCode:r.code,color:p.color}); broadcast(r); return;
  }
  const r=rooms.get(ws.roomCode); if(!r)return; const p=r.players.get(ws.id); if(!p)return;
  if(m.type==='ready'){p.ready=!!m.ready;broadcast(r); if(r.players.size>=2 && [...r.players.values()].every(x=>x.ready)){r.round=1;resetRound(r);broadcast(r);}return;}
  if(m.type==='move' && r.status==='playing' && p.alive){
   // Starter prototype: clamp reported coordinates and broadcast at a limited rate.
   p.x=Math.max(24,Math.min(776,Number(m.x)||p.x)); p.y=Math.max(120,Math.min(300,Number(m.y)||p.y)); p.vx=Math.max(-5,Math.min(5,Number(m.vx)||0)); p.lastMove=now();
   if(!p.lastBroadcast || now()-p.lastBroadcast>75){p.lastBroadcast=now();broadcast(r);}
   return;
  }
  if(m.type==='pass' && r.status==='playing' && p.alive && p.hasTnt){
   const target=r.players.get(m.targetId);
   if(target && target.id!==p.id && target.alive){
    const d=Math.hypot(target.x-p.x,target.y-p.y);
    if(d<125){p.hasTnt=false;target.hasTnt=true;r.tagHolder=target.id;broadcast(r);}
   }return;
  }
  if(m.type==='leave'){removePlayer(p);ws.roomCode=null;send(ws,{type:'left'});return;}
  if(m.type==='restart' && r.status==='finished' && r.players.size>=2){r.round=1;r.winner=null;r.players.forEach(x=>{x.ready=false;x.alive=true;x.hasTnt=false;});r.status='waiting';broadcast(r);return;}
 });
 ws.on('close',()=>{const r=rooms.get(ws.roomCode);if(r){const p=r.players.get(ws.id);if(p)removePlayer(p);}});
});
setInterval(()=>{
 for(const r of rooms.values()){
  if(r.status==='playing' && r.deadline && now()>=r.deadline){
   const holder=r.players.get(r.tagHolder); if(holder) holder.alive=false;
   if(holder) holder.hasTnt=false;
   finishRound(r); broadcast(r);
  }
 }
},200);
server.listen(PORT,()=>console.log(`TNT Tag server listening on ${PORT}`));
