# TNT Tag Online — Android Studio project

هذه ملفات مشروع Android لتغليف نموذج TNT Tag داخل تطبيق Android بوضع أفقي.

## بناء APK
1. نزّل وثبّت Android Studio على كمبيوتر.
2. افتح مجلد `TNT_Tag_Android_Project` من Android Studio.
3. انتظر مزامنة Gradle وتنزيل Android SDK المطلوب.
4. من القائمة اختر **Build > Build APK(s)**.
5. عند نجاح البناء ستجد APK عادةً داخل `app/build/outputs/apk/debug/app-debug.apk`.

## مهم قبل اللعب عبر الإنترنت
- هذا المشروع يحتوي على واجهة اللعبة داخل التطبيق، لكنه لا يتضمن خادمًا عامًا منشورًا.
- يجب نشر `server.js` على استضافة Node.js تدعم WebSockets وTLS، ثم إدخال عنوان `wss://...` في شاشة اللعبة على كل جهاز.
- لا يمكن تأكيد عمل اللعب بين أجهزة مختلفة قبل نشر الخادم واختباره.
- يتطلب البناء اتصال إنترنت لتنزيل مكونات Android/Gradle في المرة الأولى.
