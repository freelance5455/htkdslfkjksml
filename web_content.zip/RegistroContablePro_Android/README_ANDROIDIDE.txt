REGISTRO CONTABLE PRO 5.6 — PROYECTO ANDROID

Este paquete es un proyecto Android (WebView) preparado para abrirse y compilarse en AndroidIDE.
No es todavía un APK. Para crear el APK necesitas AndroidIDE con soporte para Gradle, Android SDK y JDK 17.

PASOS EN ANDROIDIDE
1. Extrae RegistroContablePro_Android.zip en una carpeta del teléfono.
2. Abre AndroidIDE y selecciona Open Project / Abrir proyecto.
3. Elige la carpeta RegistroContablePro_Android (la que contiene settings.gradle).
4. Espera a que Gradle sincronice. Si solicita instalar SDK Platform 35 o Build Tools, acepta.
5. En el menú Build, selecciona Assemble/Build APK.
6. El APK de depuración normalmente queda en app/build/outputs/apk/debug/app-debug.apk.
7. Instala ese APK. Android puede pedir permiso para instalar aplicaciones desde AndroidIDE o el gestor de archivos.

CARACTERÍSTICAS DEL ENVOLTORIO
- Nombre e icono de Registro Contable Pro.
- Interfaz web cargada localmente dentro de WebView.
- JavaScript y almacenamiento DOM habilitados para conservar los datos locales.
- Importación de respaldo JSON mediante el selector de documentos de Android.
- Exportación JSON/CSV mediante el cuadro Guardar como de Android.
- No necesita conexión a Internet para abrir la interfaz local.

IMPORTANTE SOBRE LOS DATOS
La aplicación guarda sus datos localmente. El almacenamiento del APK es independiente del almacenamiento que tenías en el navegador. Antes de empezar a usar el APK, exporta un respaldo JSON desde la copia anterior y luego impórtalo en la nueva aplicación. No desinstales ni borres los datos de la copia anterior hasta verificar que el respaldo se importó correctamente.

ID DE APLICACIÓN: com.figueroa.registrocontablepro
VERSIÓN: 5.6 (versionCode 56)
MINIMUM ANDROID: 6.0 (API 23)
