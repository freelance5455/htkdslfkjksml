헵타폼 스튜디오 PWA 배포 파일

1. GitHub에서 새 저장소를 만듭니다.
2. 이 폴더 안의 파일 5개(index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png)를 저장소 최상위에 업로드합니다.
3. 저장소 Settings > Pages > Deploy from a branch에서 main / /(root)를 선택해 저장합니다.
4. 잠시 기다린 뒤 표시된 https://...github.io/... 주소를 Android Chrome에서 엽니다.
5. Chrome 메뉴(⋮) > 홈 화면에 추가 또는 앱 설치를 선택합니다.

레벨은 브라우저의 localStorage/IndexedDB에 저장됩니다. 웹 주소(도메인/경로)를 바꾸거나 브라우저 데이터를 지우면 레벨이 보이지 않을 수 있으므로, 레벨을 ZIP으로 내보내 백업하세요.
이 패키지는 HTML을 공개 웹사이트로 배포하는 용도입니다. 공개 저장소에 올리면 누구나 소스 코드를 볼 수 있습니다.
