(() => {
  const KEY = "five-min-v1", DAY = 864e5, TOTAL = 300, CIRC = 553;
  const $ = id => document.getElementById(id);
  const ar = n => String(n).replace(/\d/g, d => "٠١٢٣٤٥٦٧٨٩"[d]);
  const dkey = (d = new Date()) => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);

  let st = { history: {}, skips: {}, remind: "20:00", notified: "" };
  try { st = Object.assign(st, JSON.parse(localStorage.getItem(KEY) || "{}")); } catch (e) {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {} };

  // seeded random so the same day always gives the same task
  function rng(seed) { let h = 2166136261; for (const c of seed) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return () => (h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0) / 4294967296; }

  function pick(key) {
    if (st.history[key]) return st.history[key].id;
    const recent = new Set(Object.entries(st.history).filter(([k]) => k !== key).sort().slice(-14).map(([, v]) => v.id));
    let pool = TASKS.filter(t => !recent.has(t.id));
    if (!pool.length) pool = TASKS;
    // categories you skip often appear less
    const w = pool.map(t => 1 / (1 + (st.skips[t.cat] || 0)));
    let r = rng(key)() * w.reduce((a, b) => a + b, 0), i = 0;
    while (r > w[i] && i < pool.length - 1) r -= w[i++];
    const id = pool[i].id;
    st.history[key] = { id, status: "pending" };
    save();
    return id;
  }

  function streak() {
    let d = new Date(), n = 0;
    if (!(st.history[dkey(d)] || {}).status || st.history[dkey(d)].status !== "done") d = addDays(d, -1);
    while ((st.history[dkey(d)] || {}).status === "done") { n++; d = addDays(d, -1); }
    return n;
  }

  let timer = null, left = TOTAL;
  function drawClock() {
    $("clock").textContent = ar(Math.floor(left / 60)) + ":" + ar(String(left % 60).padStart(2, "0"));
    $("prog").style.strokeDashoffset = CIRC * (left / TOTAL);
  }
  function stopTimer() { clearInterval(timer); timer = null; $("start").textContent = "ابدأ المؤقت"; }
  function startTimer() {
    if (timer) { stopTimer(); return; }
    $("start").textContent = "إيقاف مؤقت";
    timer = setInterval(() => {
      left = Math.max(0, left - 1); drawClock();
      if (!left) { stopTimer(); if (navigator.vibrate) navigator.vibrate(300); }
    }, 1000);
  }

  function render() {
    const key = dkey(), t = TASKS.find(x => x.id === pick(key)), h = st.history[key], c = CATEGORIES[t.cat];
    $("task").textContent = t.text;
    $("cat").textContent = c.name; $("cat").style.background = c.color;
    $("streak").textContent = ar(streak());
    const fin = h.status !== "pending";
    $("done").disabled = $("skip").disabled = $("start").disabled = fin;
    $("status").hidden = !fin;
    $("status").textContent = h.status === "done" ? "أحسنت، أنجزت مهمة اليوم. نراك غداً." : "تخطّيت مهمة اليوم. غداً مهمة جديدة.";
    $("status").style.color = h.status === "done" ? "var(--ok)" : "var(--muted)";
    if (fin) { stopTimer(); left = h.status === "done" ? 0 : TOTAL; drawClock(); }
    // dots
    $("dots").innerHTML = "";
    for (let i = 13; i >= 0; i--) {
      const k = dkey(addDays(new Date(), -i)), e = document.createElement("i");
      e.className = ((st.history[k] || {}).status || "").replace("pending", "") + (i === 0 ? " today" : "");
      $("dots").append(e);
    }
    const doneN = Object.values(st.history).filter(v => v.status === "done").length;
    $("count").textContent = "أنجزت " + ar(doneN) + " مهمة حتى الآن.";
    // log
    $("log").innerHTML = "";
    const rows = Object.entries(st.history).filter(([, v]) => v.status !== "pending").sort().reverse().slice(0, 30);
    if (!rows.length) $("log").innerHTML = '<li><small>لا يوجد سجل بعد. أنجز مهمة اليوم لتبدأ.</small></li>';
    rows.forEach(([k, v]) => {
      const task = TASKS.find(x => x.id === v.id), li = document.createElement("li");
      li.className = "s-" + v.status;
      li.innerHTML = "<span></span><small></small>";
      li.firstChild.textContent = task.text; li.lastChild.textContent = ar(k.slice(5).replace("-", "/"));
      $("log").append(li);
    });
  }

  function finish(status) {
    const h = st.history[dkey()];
    if (h.status !== "pending") return;
    h.status = status;
    if (status === "skipped") { const t = TASKS.find(x => x.id === h.id); st.skips[t.cat] = (st.skips[t.cat] || 0) + 1; }
    else { const t = TASKS.find(x => x.id === h.id); st.skips[t.cat] = Math.max(0, (st.skips[t.cat] || 0) - 1); }
    save(); render();
  }

  $("start").onclick = startTimer;
  $("done").onclick = () => finish("done");
  $("skip").onclick = () => finish("skipped");
  $("remind").value = st.remind;
  $("remind").onchange = e => {
    st.remind = e.target.value; save();
    if ("Notification" in window && Notification.permission === "default") Notification.requestPermission();
  };
  setInterval(() => {
    const now = new Date(), hm = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
    if (hm === st.remind && st.notified !== dkey() && (st.history[dkey()] || {}).status === "pending" &&
        "Notification" in window && Notification.permission === "granted") {
      st.notified = dkey(); save();
      new Notification("٥ دقائق", { body: "مهمة اليوم بانتظارك، تأخذ خمس دقائق فقط." });
    }
  }, 20000);

  drawClock(); render();
  // refresh at midnight if the tab stays open
  setInterval(() => { if (!st.history[dkey()]) { left = TOTAL; drawClock(); render(); } }, 60000);
})();
