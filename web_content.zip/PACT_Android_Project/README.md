# PACT Android project

This project wraps the PACT v15 HTML application in Android WebView and uses WebViewAssetLoader's HTTPS-style local origin for improved media/geolocation compatibility.

## Build APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder (`PACT_Android_Project`) as a project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build > Build APK(s)**.
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- App permissions for camera, microphone and location are requested when needed.
- The HTML app is included at `app/src/main/assets/index.html` and can be edited for future PACT versions.
- This is a WebView wrapper. Live multi-user voice/video calling still needs a backend and WebRTC signaling; this project alone does not provide a server.
