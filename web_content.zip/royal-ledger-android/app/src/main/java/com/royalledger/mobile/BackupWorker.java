package com.royalledger.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.documentfile.provider.DocumentFile;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BackupWorker extends Worker {
    public BackupWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        Context context = getApplicationContext();
        SharedPreferences prefs = context.getSharedPreferences("royal_ledger", Context.MODE_PRIVATE);
        String treeString = prefs.getString("backup_tree_uri", null);
        File snapshot = new File(context.getFilesDir(), "backup-data.json");
        if (treeString == null || !snapshot.isFile()) return Result.retry();
        try {
            String bundleText;
            try (FileInputStream in = new FileInputStream(snapshot); ByteArrayOutputStream buffer = new ByteArrayOutputStream()) { byte[] chunk = new byte[8192]; int count; while ((count = in.read(chunk)) != -1) buffer.write(chunk, 0, count); bundleText = new String(buffer.toByteArray(), StandardCharsets.UTF_8); }
            JSONObject bundle = new JSONObject(bundleText);
            JSONObject db = bundle.optJSONObject("db");
            if (db == null || !db.has("products") || !db.has("invoices")) return Result.retry();
            JSONObject offers = bundle.optJSONObject("offers");
            if (offers != null) db.put("__royalOffers", offers);

            DocumentFile root = DocumentFile.fromTreeUri(context, Uri.parse(treeString));
            if (root == null || !root.canWrite()) return Result.retry();
            DocumentFile folder = root.findFile("Royal Ledger Backups");
            if (folder == null) folder = root.createDirectory("Royal Ledger Backups");
            if (folder == null || !folder.canWrite()) return Result.retry();

            String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault()).format(new Date());
            writeJson(context, folder, "نسخة_احتياطية_المعرض_الملكي_" + stamp + ".json", db.toString(2));
            if (offers != null) writeJson(context, folder, "نسخة_عروض_الأسعار_" + stamp + ".json", offers.toString(2));
            return Result.success();
        } catch (Exception e) {
            android.util.Log.e("RoyalLedger", "Automatic backup failed", e);
            return Result.retry();
        }
    }

    private void writeJson(Context context, DocumentFile folder, String name, String json) throws Exception {
        DocumentFile file = folder.createFile("application/json", name);
        if (file == null) throw new IllegalStateException("Cannot create backup file");
        try (OutputStream out = context.getContentResolver().openOutputStream(file.getUri(), "wt")) {
            if (out == null) throw new IllegalStateException("Cannot open backup file");
            out.write(json.getBytes(StandardCharsets.UTF_8)); out.flush();
        }
    }
}
