package com.royalledger.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int REQUEST_USB_TREE = 701;
    private static final int REQUEST_EXPORT = 702;
    private static final int REQUEST_FILE = 703;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingExport;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 13, 19));
        getWindow().setNavigationBarColor(Color.rgb(8, 13, 19));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 16, 24));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(false);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return false;
                openExternal(uri.toString());
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("application/json");
                try { startActivityForResult(Intent.createChooser(pick, "اختيار نسخة احتياطية"), REQUEST_FILE); }
                catch (ActivityNotFoundException ex) { fileCallback = null; callback.onReceiveValue(null); }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        if (getSharedPreferences("royal_ledger", MODE_PRIVATE).getString("backup_tree_uri", null) != null) scheduleBackup();
    }

    private void scheduleBackup() {
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(BackupWorker.class, 5, TimeUnit.HOURS)
                .setInitialDelay(5, TimeUnit.HOURS).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("royal-ledger-usb-backup", ExistingPeriodicWorkPolicy.UPDATE, request);
    }

    private void openExternal(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { runOnUiThread(() -> Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show()); }
    }

    private void writeExport(Uri uri) {
        if (pendingExport == null) return;
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new IllegalStateException("تعذر فتح الملف");
            JSONObject bundle = new JSONObject(pendingExport);
            JSONObject db = bundle.optJSONObject("db");
            if (db != null && bundle.optJSONObject("offers") != null) db.put("__royalOffers", bundle.optJSONObject("offers"));
            out.write((db == null ? pendingExport : db.toString(2)).getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
        } finally { pendingExport = null; }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_USB_TREE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try { getContentResolver().takePersistableUriPermission(tree, flags); } catch (Exception ignored) {}
                getSharedPreferences("royal_ledger", MODE_PRIVATE).edit().putString("backup_tree_uri", tree.toString()).apply();
                scheduleBackup();
                Toast.makeText(this, "تم اختيار المجلد؛ النسخ التلقائي كل 5 ساعات", Toast.LENGTH_LONG).show();
                if (webView != null) webView.evaluateJavascript("if(window.updateAndroidBackupStatus)updateAndroidBackupStatus(true)", null);
            }
        } else if (requestCode == REQUEST_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) writeExport(data.getData());
            else pendingExport = null;
        } else if (requestCode == REQUEST_FILE) {
            if (fileCallback != null) {
                Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        }
    }

    private void showExitConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("تأكيد الخروج")
                .setMessage("هل تريد الخروج من البرنامج؟")
                .setPositiveButton("نعم", (dialog, which) -> finish())
                .setNegativeButton("لا", (dialog, which) -> dialog.dismiss())
                .setCancelable(true)
                .show();
    }

    private void showLogoutConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("تأكيد تسجيل الخروج")
                .setMessage("هل تريد تسجيل الخروج من الحساب؟")
                .setPositiveButton("نعم", (dialog, which) -> {
                    if (webView != null) webView.evaluateJavascript("if(window.__royalConfirmedLogout)window.__royalConfirmedLogout()", null);
                })
                .setNegativeButton("لا", (dialog, which) -> dialog.dismiss())
                .setCancelable(true)
                .show();
    }

    @Override public void onBackPressed() {
        showExitConfirmation();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy(); }
        io.shutdown();
        super.onDestroy();
    }

    private final class AndroidBridge {
        @JavascriptInterface public void saveBackupData(String json) {
            if (json == null) return;
            io.execute(() -> {
                File dest = new File(getFilesDir(), "backup-data.json");
                File temp = new File(getFilesDir(), "backup-data.tmp");
                try (FileOutputStream out = new FileOutputStream(temp)) {
                    out.write(json.getBytes(StandardCharsets.UTF_8)); out.getFD().sync();
                    if (!temp.renameTo(dest)) { try (FileOutputStream copy = new FileOutputStream(dest)) { copy.write(json.getBytes(StandardCharsets.UTF_8)); } temp.delete(); }
                } catch (Exception e) { android.util.Log.e("RoyalLedger", "Backup snapshot write failed", e); }
            });
        }
        @JavascriptInterface public void chooseUsbBackupFolder() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try { startActivityForResult(intent, REQUEST_USB_TREE); }
                catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "ما فيش مدير ملفات يدعم اختيار الفلاش", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void exportBackup(String json) {
            runOnUiThread(() -> {
                pendingExport = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "نسخة_احتياطية_المعرض_الملكي.json");
                try { startActivityForResult(intent, REQUEST_EXPORT); }
                catch (ActivityNotFoundException e) { pendingExport = null; Toast.makeText(MainActivity.this, "تعذر فتح مدير الملفات", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void confirmLogout() { runOnUiThread(() -> showLogoutConfirmation()); }
        @JavascriptInterface public void openExternal(String url) { runOnUiThread(() -> MainActivity.this.openExternal(url)); }
        @JavascriptInterface public void printHtml(String html) {
            runOnUiThread(() -> {
                WebView printView = new WebView(MainActivity.this);
                printView.getSettings().setJavaScriptEnabled(true);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager) getSystemService(PRINT_SERVICE);
                        manager.print("المعرض الملكي", view.createPrintDocumentAdapter("المعرض الملكي"), new PrintAttributes.Builder().build());
                    }
                });
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
    }
}
