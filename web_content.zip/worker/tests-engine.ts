import type {
  AttemptAnswer, AttemptReport, Difficulty, EvaluatedQuestion, MistakeType, QuestionRow, QuestionType, TestConfig,
} from '../shared/types';
import { EXAM_PATTERNS, isObjective } from '../shared/exam';
import type { Env } from './lib';
import { addDays, clamp, nowISO, num, parseJSON, str, todayISO } from './lib';
import { aiEnabled, aiJSON, AIError } from './ai';

export function mapQuestion(r: Record<string, unknown>): QuestionRow {
  return {
    id: Number(r.id),
    subject: String(r.subject),
    chapter: String(r.chapter),
    topic: (r.topic as string) ?? null,
    type: String(r.type) as QuestionType,
    difficulty: String(r.difficulty) as Difficulty,
    prompt: String(r.prompt),
    options: parseJSON(r.options, null),
    correct: parseJSON<string[]>(r.correct, []),
    numericAnswer: (r.numeric_answer as string) ?? null,
    marks: Number(r.marks ?? 1),
    negative: Number(r.negative ?? 0),
    solution: String(r.solution ?? ''),
    source: String(r.source) as QuestionRow['source'],
    sourceLabel: String(r.source_label ?? 'EduMentor practice'),
    verified: Boolean(r.verified),
    year: r.year == null ? null : Number(r.year),
    resourceId: r.resource_id == null ? null : Number(r.resource_id),
    resourcePages: (r.resource_pages as string) ?? null,
    testId: r.test_id == null ? null : Number(r.test_id),
    createdAt: String(r.created_at ?? ''),
  };
}

export function normaliseText(value: string): string {
  return value.toLowerCase().replace(/[\s,]/g, '').replace(/[−–]/g, '-').trim();
}

function numericMatch(response: string, answer: string): boolean {
  const a = Number(normaliseText(answer));
  const b = Number(normaliseText(response));
  if (!Number.isFinite(a) || !Number.isFinite(b)) return normaliseText(answer) === normaliseText(response);
  const tolerance = Math.max(0.01, Math.abs(a) * 0.01);
  return Math.abs(a - b) <= tolerance;
}

export interface ObjectiveResult {
  status: 'correct' | 'incorrect' | 'unattempted';
  awarded: number;
}

export function gradeObjective(question: QuestionRow, answer: AttemptAnswer | undefined, config: TestConfig): ObjectiveResult {
  const negative = config.negativeMarking ? question.negative || Math.abs(EXAM_PATTERNS[config.exam].marking.incorrect ?? 0) : 0;
  if (!answer) return { status: 'unattempted', awarded: 0 };

  if (['numerical', 'integer'].includes(question.type)) {
    if (!answer.numeric || !answer.numeric.trim()) return { status: 'unattempted', awarded: 0 };
    const expected = question.numericAnswer ?? question.correct[0] ?? '';
    return numericMatch(answer.numeric, expected)
      ? { status: 'correct', awarded: question.marks }
      : { status: 'incorrect', awarded: -negative };
  }

  const response = (answer.response ?? []).map((r) => r.trim()).filter(Boolean).sort();
  if (!response.length) return { status: 'unattempted', awarded: 0 };
  const expected = [...question.correct].map((c) => c.trim()).sort();
  const equal = response.length === expected.length && response.every((r, i) => normaliseText(r) === normaliseText(expected[i]));
  return equal ? { status: 'correct', awarded: question.marks } : { status: 'incorrect', awarded: -negative };
}

function classifyMistake(question: QuestionRow, answer: AttemptAnswer | undefined, status: string): MistakeType | null {
  if (status === 'correct') return null;
  if (status === 'unattempted') return 'incomplete-preparation';
  if (['numerical', 'integer'].includes(question.type)) return 'calculation';
  if (!answer?.visited) return 'time-management';
  if (question.type === 'assertion-reason') return 'conceptual';
  if (question.difficulty === 'hard' || question.difficulty === 'advanced') return 'conceptual';
  if ((answer?.timeSpentSeconds ?? 0) < 8) return 'careless';
  if (question.options && question.correct.length === 1) {
    const chosen = answer?.response?.[0];
    return chosen && /formula|equation/i.test(question.prompt) ? 'formula' : 'conceptual';
  }
  return 'misinterpretation';
}

export interface SubmissionPayload {
  answers: Record<string, AttemptAnswer>;
  timeSpentSeconds: number;
}

/** Grades objective questions exactly and descriptive answers with AI when available. */
export async function evaluateAttempt(
  env: Env,
  userId: number,
  questions: QuestionRow[],
  payload: SubmissionPayload,
  config: TestConfig,
): Promise<{
  report: AttemptReport;
  score: number;
  maxScore: number;
  correct: number;
  incorrect: number;
  unattempted: number;
  accuracy: number;
}> {
  const answers = payload.answers ?? {};
  const evaluated: EvaluatedQuestion[] = [];
  const subjective: { question: QuestionRow; answer: AttemptAnswer }[] = [];

  for (const question of questions) {
    const answer = answers[String(question.id)];
    const base = {
      questionId: question.id,
      subject: question.subject,
      chapter: question.chapter,
      type: question.type,
      difficulty: question.difficulty,
      prompt: question.prompt,
      correct: question.correct,
      numericAnswer: question.numericAnswer,
      response: answer?.response ?? [],
      numericResponse: answer?.numeric ?? null,
      solution: question.solution,
      timeSpentSeconds: answer?.timeSpentSeconds ?? 0,
    };

    if (isObjective(question.type)) {
      const result = gradeObjective(question, answer, config);
      evaluated.push({
        ...base,
        status: result.status,
        awarded: result.awarded,
        maxMarks: question.marks,
        explanation: null,
        mistakeType: classifyMistake(question, answer, result.status),
      });
    } else if (!answer || !(answer.response ?? []).join('').trim()) {
      evaluated.push({
        ...base,
        status: 'unattempted',
        awarded: 0,
        maxMarks: question.marks,
        explanation: null,
        mistakeType: 'incomplete-preparation',
      });
    } else {
      subjective.push({ question, answer });
      evaluated.push({
        ...base,
        status: 'partial',
        awarded: 0,
        maxMarks: question.marks,
        explanation: 'Awaiting evaluation',
        mistakeType: null,
      });
    }
  }

  if (subjective.length && aiEnabled(env)) {
    try {
      const grading = await aiJSON<{ gradings: { questionId: number; awarded: number; feedback: string; mistakeType?: string }[] }>(
        env,
        [
          {
            role: 'system',
            content:
              'You are an experienced CBSE examiner. Grade descriptive answers strictly against the model answer and allocated marks. Award partial marks only for the points actually made. Return JSON only.',
          },
          {
            role: 'user',
            content: [
              'Grade these answers. For each return {questionId, awarded (0..maxMarks in 0.5 steps), feedback (2-3 sentences: what was earned, what was missing), mistakeType (one of conceptual, incomplete-preparation, misinterpretation, careless, formula) }.',
              'Return {"gradings":[...]}',
              ...subjective.map(({ question, answer }) =>
                `Question ${question.id} [${question.subject} / ${question.chapter}, max ${question.marks} marks]\nQ: ${question.prompt}\nModel answer: ${question.solution}\nStudent answer: ${(answer.response ?? []).join('\n').slice(0, 2500)}`,
              ),
            ].join('\n\n'),
          },
        ],
        { temperature: 0.15, maxTokens: 2500, timeoutMs: 90000 },
      );
      for (const g of grading.gradings ?? []) {
        const target = evaluated.find((e) => e.questionId === Number(g.questionId));
        if (!target || target.status !== 'partial') continue;
        const awarded = clamp(num(g.awarded, 0, 0, target.maxMarks), 0, target.maxMarks);
        target.awarded = awarded;
        target.status = awarded >= target.maxMarks ? 'correct' : awarded > 0 ? 'partial' : 'incorrect';
        target.explanation = str(g.feedback, 1200);
        target.mistakeType = (g.mistakeType as MistakeType) ?? (awarded >= target.maxMarks ? null : 'conceptual');
      }
    } catch {
      // Keep descriptive answers unscored but visible; never fabricate a mark.
      for (const e of evaluated) {
        if (e.status === 'partial' && e.explanation === 'Awaiting evaluation') {
          e.explanation = 'Automatic grading was unavailable, so this descriptive answer has not been marked. Review it against the model answer.';
        }
      }
    }
  } else {
    for (const e of evaluated) {
      if (e.status === 'partial' && e.explanation === 'Awaiting evaluation') {
        e.explanation = 'Descriptive answers are not auto-graded on this deployment (AI grading is not configured). Compare with the model answer.';
      }
    }
  }

  const maxScore = questions.reduce((s, q) => s + q.marks, 0);
  const score = Math.round(evaluated.reduce((s, e) => s + e.awarded, 0) * 100) / 100;
  const correct = evaluated.filter((e) => e.status === 'correct').length;
  const incorrect = evaluated.filter((e) => e.status === 'incorrect').length;
  const unattempted = evaluated.filter((e) => e.status === 'unattempted').length;
  const attempted = correct + incorrect + evaluated.filter((e) => e.status === 'partial').length;
  const accuracy = attempted ? Math.round((correct / attempted) * 1000) / 10 : 0;
  const attemptRate = questions.length ? Math.round((attempted / questions.length) * 1000) / 10 : 0;

  const subjects = groupPerformance(evaluated, (e) => e.subject).map((g) => ({
    subject: g.key,
    correct: g.correct,
    incorrect: g.incorrect,
    unattempted: g.unattempted,
    score: g.score,
    max: g.max,
    accuracy: g.accuracy,
  }));
  const chapters = groupPerformance(evaluated, (e) => `${e.subject}::${e.chapter}`).map((g) => ({
    chapter: g.key.split('::')[1] ?? g.key,
    subject: g.key.split('::')[0] ?? '',
    correct: g.correct,
    total: g.total,
    accuracy: g.accuracy,
  }));
  const difficulties = groupPerformance(evaluated, (e) => e.difficulty).map((g) => ({
    difficulty: g.key as Difficulty,
    correct: g.correct,
    total: g.total,
    accuracy: g.accuracy,
  }));

  const mistakeCounts: Record<string, number> = {};
  for (const e of evaluated) {
    if (e.mistakeType) mistakeCounts[e.mistakeType] = (mistakeCounts[e.mistakeType] ?? 0) + 1;
  }

  const slowQuestions = evaluated.filter((e) => e.status !== 'unattempted' && e.timeSpentSeconds > 150).length;
  const timeEfficiency =
    unattempted === 0 && slowQuestions === 0
      ? 'You attempted every question without stalling — pacing was solid.'
      : unattempted > 0
        ? `${unattempted} question${unattempted === 1 ? '' : 's'} were left unattempted. Skipping is a choice; check whether it was strategic or time pressure.`
        : `${slowQuestions} question${slowQuestions === 1 ? '' : 's'} took over 2.5 minutes. Practise a per-question time cap for those chapters.`;

  const weakest = [...chapters].sort((a, b) => a.accuracy - b.accuracy).filter((ch) => ch.total >= 1).slice(0, 4);
  const strongest = [...chapters].sort((a, b) => b.accuracy - a.accuracy).slice(0, 3);

  let summary = `You scored ${score} out of ${maxScore} with ${accuracy}% accuracy on attempted questions.`;
  let improvementPlan = rulePlan(weakest, mistakeCounts, attemptRate);
  let analysisSource: 'ai' | 'rules' = 'rules';

  if (aiEnabled(env)) {
    try {
      const aiReport = await aiJSON<{
        summary: string;
        strengths: string[];
        improvements: string[];
        improvementPlan: { title: string; detail: string; priority: 'high' | 'medium' | 'low' }[];
      }>(
        env,
        [
          {
            role: 'system',
            content:
              'You are an academic performance analyst for Indian board and entrance exams. Be honest, specific and practical. Do not promise marks, ranks or guaranteed outcomes. Return JSON only.',
          },
          {
            role: 'user',
            content: [
              `Exam: ${EXAM_PATTERNS[config.exam].label}. Score ${score}/${maxScore}; accuracy ${accuracy}%; attempt rate ${attemptRate}%; unattempted ${unattempted}.`,
              `Subject results: ${subjects.map((s) => `${s.subject} ${s.score}/${s.max} (${s.accuracy}%)`).join('; ')}`,
              `Chapter results: ${chapters.map((ch) => `${ch.subject}/${ch.chapter} ${ch.accuracy}%`).join('; ')}`,
              `Mistake tags: ${JSON.stringify(mistakeCounts)}`,
              `Wrong or partial questions: ${evaluated.filter((e) => e.status !== 'correct').slice(0, 12).map((e) => `${e.subject}/${e.chapter}: ${e.prompt.slice(0, 160)} (${e.status})`).join(' | ')}`,
              'Return {"summary": "3-4 sentences", "strengths": ["..."], "improvements": ["..."], "improvementPlan": [{"title","detail","priority"}]} with 3-5 plan items ordered by priority.',
            ].join('\n'),
          },
        ],
        { temperature: 0.3, maxTokens: 1600, timeoutMs: 60000 },
      );
      if (aiReport.summary) {
        summary = aiReport.summary;
        improvementPlan = (aiReport.improvementPlan ?? []).slice(0, 5);
        analysisSource = 'ai';
      }
      const report: AttemptReport = {
        evaluated,
        subjects,
        chapters,
        difficulties,
        mistakeCounts,
        attemptRate,
        timeEfficiency,
        summary,
        strengths: (aiReport.strengths ?? strongest.map((s) => `${s.chapter} (${s.accuracy}%)`)).slice(0, 5),
        improvements: (aiReport.improvements ?? weakest.map((w) => `${w.chapter} needs revision`)).slice(0, 6),
        improvementPlan,
        analysisSource,
        generatedAt: nowISO(),
      };
      return { report, score, maxScore, correct, incorrect, unattempted, accuracy };
    } catch {
      analysisSource = 'rules';
    }
  }

  const report: AttemptReport = {
    evaluated,
    subjects,
    chapters,
    difficulties,
    mistakeCounts,
    attemptRate,
    timeEfficiency,
    summary,
    strengths: strongest.map((s) => `${s.chapter} — ${s.accuracy}% accuracy`),
    improvements: weakest.map((w) => `${w.chapter} — ${w.accuracy}% accuracy`),
    improvementPlan,
    analysisSource,
    generatedAt: nowISO(),
  };
  return { report, score, maxScore, correct, incorrect, unattempted, accuracy };
}

function rulePlan(
  weakest: { subject: string; chapter: string; accuracy: number }[],
  mistakes: Record<string, number>,
  attemptRate: number,
): AttemptReport['improvementPlan'] {
  const plan: AttemptReport['improvementPlan'] = [];
  if (weakest[0]) {
    plan.push({
      title: `Relearn ${weakest[0].chapter}`,
      detail: `You scored ${weakest[0].accuracy}% here. Re-read the chapter, write a one-page summary from memory, then solve 10 fresh questions from this chapter before your next test.`,
      priority: 'high',
    });
  }
  if (weakest[1]) {
    plan.push({
      title: `Targeted practice: ${weakest[1].chapter}`,
      detail: `Schedule two 40-minute practice blocks on ${weakest[1].chapter} this week, mixing easy and medium questions.`,
      priority: 'medium',
    });
  }
  if ((mistakes.calculation ?? 0) >= 2) {
    plan.push({
      title: 'Slow down on arithmetic',
      detail: 'You lost marks to calculation slips. For the next three tests, re-check each numeric answer once before moving on.',
      priority: 'high',
    });
  }
  if (attemptRate < 75) {
    plan.push({
      title: 'Improve attempt strategy',
      detail: `You attempted ${attemptRate}% of the paper. In the next mock, attempt all questions you can rule out two options on — with negative marking, be deliberate but not timid.`,
      priority: 'medium',
    });
  }
  if (!plan.length) {
    plan.push({
      title: 'Raise the difficulty',
      detail: 'Your accuracy is strong on this set. Move to harder questions and full-length timed papers to build exam stamina.',
      priority: 'low',
    });
  }
  return plan;
}

function groupPerformance(
  evaluated: EvaluatedQuestion[],
  keyFn: (e: EvaluatedQuestion) => string,
): { key: string; correct: number; incorrect: number; unattempted: number; score: number; max: number; total: number; accuracy: number }[] {
  const groups = new Map<string, { correct: number; incorrect: number; unattempted: number; score: number; max: number; total: number; partial: number }>();
  for (const item of evaluated) {
    const key = keyFn(item);
    const group = groups.get(key) ?? { correct: 0, incorrect: 0, unattempted: 0, score: 0, max: 0, total: 0, partial: 0 };
    group.total += 1;
    group.max += item.maxMarks;
    group.score += item.awarded;
    if (item.status === 'correct') group.correct += 1;
    else if (item.status === 'incorrect') group.incorrect += 1;
    else if (item.status === 'unattempted') group.unattempted += 1;
    else group.partial += 1;
    groups.set(key, group);
  }
  return [...groups.entries()].map(([key, g]) => ({
    key,
    correct: g.correct,
    incorrect: g.incorrect,
    unattempted: g.unattempted,
    score: Math.round(g.score * 100) / 100,
    max: Math.round(g.max * 100) / 100,
    total: g.total,
    accuracy: g.correct + g.incorrect + g.partial > 0 ? Math.round((g.correct / (g.correct + g.incorrect + g.partial)) * 1000) / 10 : 0,
  }));
}

/** Applies attempt outcomes to chapter mastery and revision scheduling. */
export async function applyAttemptToProgress(
  db: D1Database,
  userId: number,
  evaluated: EvaluatedQuestion[],
): Promise<void> {
  const byChapter = new Map<string, { subject: string; chapter: string; correct: number; total: number; mistakes: MistakeType[] }>();
  for (const item of evaluated) {
    const key = `${item.subject}::${item.chapter}`;
    const entry = byChapter.get(key) ?? { subject: item.subject, chapter: item.chapter, correct: 0, total: 0, mistakes: [] };
    entry.total += 1;
    if (item.status === 'correct') entry.correct += 1;
    if (item.mistakeType) entry.mistakes.push(item.mistakeType);
    byChapter.set(key, entry);
  }

  for (const entry of byChapter.values()) {
    const accuracy = entry.total ? entry.correct / entry.total : 0;
    const existing = await db
      .prepare('SELECT * FROM chapter_progress WHERE user_id = ? AND subject = ? AND chapter = ?')
      .bind(userId, entry.subject, entry.chapter)
      .first<Record<string, unknown>>();

    const prior = existing ? Number(existing.mastery ?? 0) : 0;
    const mastery = clamp(prior * 0.6 + accuracy * 0.4, 0, 1);
    const status = mastery >= 0.8 ? 'confident' : masterYStatus(mastery);
    const interval = accuracy >= 0.8 ? 4 : accuracy >= 0.5 ? 2 : 1;
    if (existing) {
      await db
        .prepare(
          `UPDATE chapter_progress SET mastery = ?, status = ?, last_studied = ?, next_review = ?, interval_days = ?, updated_at = ?
           WHERE user_id = ? AND subject = ? AND chapter = ?`,
        )
        .bind(mastery, status, todayISO(), addDays(todayISO(), interval), interval, nowISO(), userId, entry.subject, entry.chapter)
        .run();
    } else {
      await db
        .prepare(
          `INSERT INTO chapter_progress (user_id, subject, chapter, status, mastery, last_studied, next_review, interval_days, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .bind(userId, entry.subject, entry.chapter, status, mastery, todayISO(), addDays(todayISO(), interval), interval, nowISO())
        .run();
    }
  }
}

function masterYStatus(mastery: number): 'not-started' | 'learning' | 'revising' | 'confident' {
  if (mastery <= 0.05) return 'not-started';
  if (mastery < 0.5) return 'learning';
  return 'revising';
}

export async function gradeFromBank(
  env: Env,
  userId: number,
  question: QuestionRow,
  response: string[],
  numeric: string | null,
): Promise<{ correct: boolean; awarded: number; solution: string }> {
  const config: TestConfig = {
    exam: 'custom', subjects: [], chapters: [], types: [], difficulty: 'medium', questionCount: 1,
    durationMinutes: 1, negativeMarking: false, useResources: false, resourceIds: [], generatedBy: 'bank',
  };
  const result = gradeObjective(question, { questionId: question.id, response, numeric, timeSpentSeconds: 0, marked: false, visited: true }, config);
  return { correct: result.status === 'correct', awarded: result.awarded, solution: question.solution };
}

export async function insertGeneratedQuestions(
  env: Env,
  userId: number,
  testId: number,
  raw: Record<string, unknown>[],
  config: TestConfig,
): Promise<number> {
  const pattern = EXAM_PATTERNS[config.exam];
  const statements = raw
    .map((q) => {
      const prompt = str(q.prompt, 6000);
      if (prompt.length < 8) return null;
      const type = (['mcq', 'multiple-correct', 'numerical', 'integer', 'assertion-reason', 'case-based', 'short-answer', 'long-answer', 'competency'].includes(str(q.type, 30))
        ? str(q.type, 30)
        : 'mcq') as QuestionType;
      const marks = type === 'long-answer' ? 5 : type === 'short-answer' || type === 'case-based' ? (config.exam.startsWith('cbse') ? 3 : 2) : pattern.marking.correct || 4;
      const options = Array.isArray(q.options)
        ? (q.options as Record<string, unknown>[]).map((o) => ({ key: str(o.key, 3), text: str(o.text, 900) })).filter((o) => o.key && o.text)
        : null;
      const correct = Array.isArray(q.correct) ? (q.correct as unknown[]).map((c) => str(c, 300)).filter(Boolean) : [];
      const numericAnswer = q.numericAnswer == null ? null : str(q.numericAnswer, 80);
      if (isObjective(type) && !correct.length && !numericAnswer) return null;
      return env.DB.prepare(
        `INSERT INTO questions (user_id, subject, chapter, topic, type, difficulty, prompt, options, correct, numeric_answer, marks, negative, solution, source, source_label, verified, resource_id, resource_pages, test_id, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ai', ?, 0, ?, ?, ?, ?)`,
      ).bind(
        userId,
        str(q.subject, 60) || config.subjects[0] || 'General',
        str(q.chapter, 120) || 'General',
        str(q.topic, 120) || null,
        type,
        ['easy', 'medium', 'hard', 'advanced'].includes(str(q.difficulty, 20)) ? str(q.difficulty, 20) : config.difficulty,
        prompt,
        options && options.length >= 2 ? JSON.stringify(options) : null,
        JSON.stringify(correct),
        numericAnswer,
        num(q.marks, marks, 0.5, 10),
        config.negativeMarking ? Math.abs(pattern.marking.incorrect ?? 0) : 0,
        str(q.solution, 6000) || 'Solution not generated — review the concept in your resource before retrying.',
        `AI-generated (${pattern.label} style)`,
        isObjective(type) ? null : null,
        q.page == null ? null : `p. ${num(q.page, 0, 0, 5000)}`,
        testId,
        nowISO(),
      );
    })
    .filter((s): s is D1PreparedStatement => Boolean(s));

  for (let i = 0; i < statements.length; i += 30) await env.DB.batch(statements.slice(i, i + 30));
  return statements.length;
}

export async function generateWithAI(
  env: Env,
  userId: number,
  testId: number,
  config: TestConfig,
  profileSummary: string,
  contextBlock: string,
): Promise<number> {
  const pattern = EXAM_PATTERNS[config.exam];
  const result = await aiJSON<{ questions: Record<string, unknown>[] }>(
    env,
    [
      {
        role: 'system',
        content: [
          'You generate examination practice papers for Indian students. Follow the requested count, types, chapters and marking exactly.',
          'Every question must be solvable and factually correct with no internal contradictions. Provide a complete worked solution.',
          'For MCQs provide exactly four options A-D and one correct key. For multiple-correct, list every correct key. For numerical/integer, put the answer in numericAnswer and leave correct empty.',
          'Never claim a question is from a previous year or from a textbook. Return JSON only.',
        ].join(' '),
      },
      {
        role: 'user',
        content: [
          `Exam style: ${pattern.label}. ${pattern.description}`,
          `Question types allowed: ${config.types.join(', ')}. Difficulty: ${config.difficulty}. Number of questions: ${config.questionCount}.`,
          `Subjects: ${config.subjects.join(', ')}.${config.chapters.length ? ` Chapters: ${config.chapters.join(', ')}.` : ' Cover the syllabus broadly.'}`,
          `Marking: correct ${pattern.marking.correct}, incorrect ${pattern.marking.incorrect ?? 0}.${config.negativeMarking ? ' Negative marking applies.' : ' No negative marking.'}`,
          `Student context:\n${profileSummary}`,
          contextBlock ? `Base the questions on these excerpts from the student's own uploaded resources, and include the page number used:\n${contextBlock}` : '',
          'Return {"questions":[{"subject","chapter","topic","type","difficulty","prompt","options":[{"key":"A","text":"..."}],"correct":["A"],"numericAnswer":null,"solution":"full worked solution","page":null}]}',
        ].join('\n\n'),
      },
    ],
    { temperature: 0.55, maxTokens: 4000, timeoutMs: 120000 },
  );

  return insertGeneratedQuestions(env, userId, testId, result.questions ?? [], config);
}

export { isObjective };
