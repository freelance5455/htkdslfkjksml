/**
 * D1-compatible adapter over a libSQL client (Turso or a local file database).
 *
 * The application is written against Cloudflare D1's prepared-statement API.
 * libSQL speaks the same SQLite dialect, so only the small surface used by this
 * codebase needs translating: prepare/bind/first/all/run/batch/exec.
 */

type SqlValue = string | number | null | Uint8Array | ArrayBuffer;

export interface LibsqlResult {
  rows: Record<string, unknown>[];
  lastInsertRowid?: bigint | number;
  rowsAffected: number;
}

export interface LibsqlClientLike {
  execute(stmt: { sql: string; args: SqlValue[] }): Promise<LibsqlResult>;
  batch?(stmts: { sql: string; args: SqlValue[] }[], mode?: 'write' | 'read' | 'deferred'): Promise<LibsqlResult[]>;
  executeMultiple?(sql: string): Promise<void>;
}

function normalize(value: unknown): SqlValue {
  if (value === undefined || value === null) return null;
  if (typeof value === 'boolean') return value ? 1 : 0;
  if (value instanceof Date) return value.toISOString();
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (value instanceof Uint8Array || typeof value === 'string' || typeof value === 'number') return value;
  return String(value);
}

function metaOf(result: LibsqlResult) {
  const id = result.lastInsertRowid;
  return {
    last_row_id: id === undefined ? 0 : Number(id),
    changes: result.rowsAffected,
    rows_written: result.rowsAffected,
    rows_read: result.rows.length,
    duration: 0,
  };
}

export function d1FromClient(client: LibsqlClientLike): D1Database {
  const prepare = (sql: string) => {
    let args: SqlValue[] = [];
    const statement = {
      bind(...values: unknown[]) {
        args = values.map(normalize);
        return statement;
      },
      async first<T>(column?: string): Promise<T | null> {
        const result = await client.execute({ sql, args });
        const row = result.rows[0];
        if (!row) return null;
        return (column ? row[column] : row) as T;
      },
      async all<T>() {
        const result = await client.execute({ sql, args });
        return { results: result.rows as T[], success: true, meta: metaOf(result) };
      },
      async run() {
        const result = await client.execute({ sql, args });
        return { success: true, meta: metaOf(result) };
      },
      toStatement() {
        return { sql, args };
      },
    };
    return statement;
  };

  const adapter = {
    prepare,
    async batch(statements: { toStatement(): { sql: string; args: SqlValue[] } }[]) {
      const mapped = statements.map((statement) => statement.toStatement());
      if (mapped.length === 0) return [];
      if (client.batch) {
        const results = await client.batch(mapped, 'write');
        return results.map((result) => ({ success: true, results: result.rows, meta: metaOf(result) }));
      }
      const out = [];
      for (const statement of mapped) {
        const result = await client.execute(statement);
        out.push({ success: true, results: result.rows, meta: metaOf(result) });
      }
      return out;
    },
    async exec(sql: string) {
      await client.executeMultiple?.(sql);
      return { count: 0, duration: 0 };
    },
    async dump() {
      throw new Error('Database export is not supported on this deployment.');
    },
  };

  return adapter as unknown as D1Database;
}
