import { Hono } from 'hono';
import auth from './routes/auth';
import profile from './routes/profile';
import dashboard from './routes/dashboard';
import teacher from './routes/teacher';
import resources from './routes/resources';
import tests from './routes/tests';
import bank from './routes/bank';
import revision from './routes/revision';
import planner from './routes/planner';
import analytics from './routes/analytics';
import type { AppEnv } from './lib';
import { ensureSchema, json, todayISO } from './lib';
import { EXAM_LIST } from '../shared/exam';
import { SYLLABUS } from '../shared/syllabus';
import { SEED_QUESTIONS } from '../shared/questionSeed';

const app = new Hono<AppEnv>();

app.use('/api/*', async (c, next) => {
  await next();
  c.header('x-content-type-options', 'nosniff');
  c.header('referrer-policy', 'strict-origin-when-cross-origin');
  c.header('cache-control', 'no-store');
});

app.get('/api/health', async (c) => {
  try {
    await ensureSchema(c.env.DB);
    const row = await c.env.DB.prepare('SELECT COUNT(*) AS n FROM questions WHERE user_id IS NULL').first<{ n: number }>();
    return json({
      ok: true,
      today: todayISO(),
      seedQuestions: row?.n ?? 0,
      storage: Boolean(c.env.FILES),
      ai: Boolean(c.env.OPENAI_API_KEY),
      database: 'ok',
    });
  } catch (err) {
    // Health is the first place to look when a deployment misbehaves, so it
    // reports the database failure instead of failing the same way.
    return json({
      ok: false,
      database: 'error',
      error: err instanceof Error ? err.message : String(err),
      hint: 'Check TURSO_DATABASE_URL and TURSO_AUTH_TOKEN in Vercel → Settings → Environment Variables, then redeploy.',
      storage: Boolean(c.env.FILES),
      ai: Boolean(c.env.OPENAI_API_KEY),
    });
  }
});

app.get('/api/meta/exams', (c) => json({ exams: EXAM_LIST, syllabus: SYLLABUS }));

// Seed the shared practice bank once per database.
app.use('/api/*', async (c, next) => {
  if (c.env?.DB) {
    try {
      await ensureSchema(c.env.DB);
    const seeded = await c.env.DB.prepare("SELECT value FROM meta WHERE key = 'seed_questions'").first<{ value: string }>().catch(() => null);
    if (!seeded) {
      const ts = new Date().toISOString();
      const statements = SEED_QUESTIONS.map((q) =>
        c.env.DB.prepare(
          `INSERT INTO questions (user_id, subject, chapter, topic, type, difficulty, prompt, options, correct, numeric_answer, marks, negative, solution, source, source_label, verified, created_at)
           VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 'seed', 'EduMentor practice', 0, ?)`,
        ).bind(
          q.subject, q.chapter, q.topic, q.type, q.difficulty, q.prompt,
          q.options ? JSON.stringify(q.options) : null,
          JSON.stringify(q.correct),
          q.numericAnswer, q.marks, q.solution, ts,
        ),
      );
      for (let i = 0; i < statements.length; i += 40) {
        await c.env.DB.batch(statements.slice(i, i + 40)).catch((err) => console.warn('[seed] batch insert failed:', err));
      }
      await c.env.DB.prepare("INSERT OR REPLACE INTO meta (key, value) VALUES ('seed_questions', ?)")
        .bind(String(SEED_QUESTIONS.length)).run().catch((err) => console.warn('[seed] meta update failed:', err));
    }
  } catch (err) {
    console.error('[seed/schema error]', err);
  }

  await next();
});

app.route('/api/auth', auth);
app.route('/api', profile);
app.route('/api', dashboard);
app.route('/api', teacher);
app.route('/api', resources);
app.route('/api', tests);
app.route('/api', bank);
app.route('/api', revision);
app.route('/api', planner);
app.route('/api', analytics);

app.notFound((c) => {
  if (c.req.path.startsWith('/api/') || c.req.path === '/api') {
    return json({ error: 'Endpoint not found.', code: 'not_found' }, { status: 404 });
  }
  if (c.env?.ASSETS?.fetch) {
    return c.env.ASSETS.fetch(c.req.raw);
  }
  return new Response('Not found', { status: 404 });
});

app.onError((err, c) => {
  const detail = err instanceof Error ? err.message : String(err);
  console.error('[error]', c.req.method, c.req.path, detail, err instanceof Error ? err.stack : '');
  const lower = detail.toLowerCase();
  const looksLikeDatabase =
    /unauthorized|forbidden|401|403|auth|token|libsql|turso|econnrefused|enotfound|fetch failed|network|connect|scheme|server_error|http status|no such table/.test(lower);
  if (looksLikeDatabase) {
    return json(
      {
        error: `Database error: ${detail}`,
        code: 'database_error',
        setupRequired: true,
        hint: 'Check your database configuration (Cloudflare D1 binding "DB" or TURSO_DATABASE_URL and TURSO_AUTH_TOKEN).',
      },
      { status: 503 },
    );
  }
  return json({ error: `Server error: ${detail}`, code: 'server_error' }, { status: 500 });
});

export default app;
