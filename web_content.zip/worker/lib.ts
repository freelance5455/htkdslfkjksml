/// <reference types="@cloudflare/workers-types" />

export interface Env {
  DB: D1Database;
  FILES?: R2Bucket;
  ASSETS: Fetcher;
  OPENAI_API_KEY?: string;
  OPENAI_BASE_URL?: string;
  AI_MODEL?: string;
  APP_ENV?: string;
}

export type AppEnv = { Bindings: Env; Variables: { userId: number; email: string; name: string } };

const encoder = new TextEncoder();

export function nowISO(): string {
  return new Date().toISOString();
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function addDays(dateISO: string, days: number): string {
  const d = new Date(dateISO + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export function daysBetween(a: string, b: string): number {
  const ms = new Date(b + 'T00:00:00Z').getTime() - new Date(a + 'T00:00:00Z').getTime();
  return Math.round(ms / 86400000);
}

export function json(data: unknown, init: ResponseInit = {}): Response {
  return new Response(JSON.stringify(data), {
    ...init,
    headers: { 'content-type': 'application/json; charset=utf-8', ...(init.headers ?? {}) },
  });
}

export function badRequest(message: string, code = 'bad_request', extra: Record<string, unknown> = {}): Response {
  return json({ error: message, code, ...extra }, { status: 400 });
}

export function notFound(message = 'Not found'): Response {
  return json({ error: message, code: 'not_found' }, { status: 404 });
}

export function serverError(message: string, extra: Record<string, unknown> = {}): Response {
  return json({ error: message, code: 'server_error', ...extra }, { status: 500 });
}

/* ------------------------------------------------------------------ */
/* Schema bootstrap                                                    */
/* ------------------------------------------------------------------ */let schemaReady = false;

/** Split a DDL script into individual statements for execution. */
function splitStatements(sql: string): string[] {
  return sql
    .split(';')
    .map((statement) => statement.replace(/^\s*--.*$/gm, '').trim())
    .filter(Boolean);
}

async function applySchema(db: D1Database): Promise<void> {
  const { SCHEMA_SQL } = await import('./schema');
  if (typeof db.exec === 'function') {
    try {
      await db.exec(SCHEMA_SQL);
      return;
    } catch (e) {
      console.warn('[schema] db.exec failed, falling back to individual statements:', e);
    }
  }

  const statements = splitStatements(SCHEMA_SQL);
  for (const s of statements) {
    try {
      await db.prepare(s).run();
    } catch (err) {
      const msg = String(err).toLowerCase();
      if (!msg.includes('already exists')) {
        console.warn('[schema] statement failed:', s.slice(0, 50), err);
      }
    }
  }
}

export async function ensureSchema(db: D1Database): Promise<void> {
  if (schemaReady) return;
  if (!db) {
    throw new Error('Database connection is not configured. Please bind a D1 database named "DB" or configure TURSO_DATABASE_URL.');
  }
  const { SCHEMA_VERSION } = await import('./schema');
  const versionRow = await db
    .prepare("SELECT value FROM meta WHERE key = 'schema_version'")
    .first<{ value: string }>()
    .catch(() => null);

  if (!versionRow || Number(versionRow.value) < SCHEMA_VERSION) {
    // Every statement is idempotent, so this is safe on both fresh and existing databases.
    await applySchema(db);
    await db
      .prepare("INSERT OR REPLACE INTO meta (key, value) VALUES ('schema_version', ?)")
      .bind(String(SCHEMA_VERSION))
      .run()
      .catch((err) => console.warn('[schema] Failed to record schema_version:', err));
  }
  schemaReady = true;
}

/* ------------------------------------------------------------------ */
/* Crypto helpers (Web Crypto only — runs in workerd)                  */
/* ------------------------------------------------------------------ */

export function randomToken(bytes = 32): string {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  return [...arr].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function sha256(value: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(value));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function hashPassword(password: string, salt: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  // 5,000 iterations keeps execution well under the 10ms Cloudflare Workers CPU limit
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: encoder.encode(salt), iterations: 5000, hash: 'SHA-256' },
    key,
    256,
  );
  return [...new Uint8Array(bits)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}

/* ------------------------------------------------------------------ */
/* Validation                                                          */
/* ------------------------------------------------------------------ */

export function str(value: unknown, max = 5000): string {
  if (typeof value !== 'string') return '';
  return value.trim().slice(0, max);
}

export function num(value: unknown, fallback = 0, min = -1e9, max = 1e9): number {
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

export function isEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
}

export function parseJSON<T>(value: unknown, fallback: T): T {
  if (typeof value !== 'string' || !value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

/** Very small HTML sanitiser for AI text that is stored and later rendered. */
export function stripTags(value: string): string {
  return value.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<[^>]+>/g, '');
}

export function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}
