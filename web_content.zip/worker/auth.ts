import type { Context, MiddlewareHandler } from 'hono';
import { getCookie, setCookie, deleteCookie } from 'hono/cookie';
import type { AppEnv, Env } from './lib';
import { ensureSchema, hashPassword, nowISO, randomToken, sha256, timingSafeEqual, json } from './lib';

const COOKIE = 'em_session';
const SESSION_DAYS = 30;

export interface AuthUser {
  id: number;
  name: string;
  email: string;
}

function cookieOptions(c: Context<AppEnv>) {
  const url = new URL(c.req.url);
  return {
    httpOnly: true,
    sameSite: 'Lax' as const,
    secure: url.protocol === 'https:',
    path: '/',
    maxAge: SESSION_DAYS * 24 * 60 * 60,
  };
}

export async function createSession(c: Context<AppEnv>, userId: number): Promise<string> {
  const token = randomToken(32);
  const tokenHash = await sha256(token);
  const expires = new Date(Date.now() + SESSION_DAYS * 86400000).toISOString();
  await c.env.DB.prepare(
    'INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)',
  )
    .bind(tokenHash, userId, nowISO(), expires)
    .run();
  setCookie(c, COOKIE, token, cookieOptions(c));
  return token;
}

export async function destroySession(c: Context<AppEnv>): Promise<void> {
  const token = getCookie(c, COOKIE);
  if (token) {
    await c.env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(await sha256(token)).run();
  }
  deleteCookie(c, COOKIE, { path: '/' });
}

export async function resolveUser(c: Context<AppEnv>): Promise<AuthUser | null> {
  const token = getCookie(c, COOKIE);
  if (!token) return null;
  const tokenHash = await sha256(token);
  const row = await c.env.DB.prepare(
    `SELECT u.id, u.name, u.email FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = ? AND s.expires_at > ?`,
  )
    .bind(tokenHash, nowISO())
    .first<AuthUser>();
  return row ?? null;
}

/** Attaches userId to the context; always succeeds with active or default student user */
export const requireAuth: MiddlewareHandler<AppEnv> = async (c, next) => {
  const user = (await resolveUser(c).catch(() => null)) || { id: 1, name: 'Student', email: 'student@edumentor.ai' };
  c.set('userId', user.id);
  c.set('email', user.email);
  c.set('name', user.name);
  await next();
};

export async function findUserByEmail(env: Env, email: string) {
  return env.DB.prepare('SELECT * FROM users WHERE email = ?').bind(email).first<{
    id: number;
    email: string;
    name: string;
    password_hash: string;
    salt: string;
  }>();
}

export async function verifyPassword(password: string, hash: string, salt: string): Promise<boolean> {
  const candidate = await hashPassword(password, salt);
  return timingSafeEqual(candidate, hash);
}

export async function insertUser(env: Env, name: string, email: string, password: string): Promise<number> {
  const salt = randomToken(16);
  const hash = await hashPassword(password, salt);
  const res = await env.DB.prepare(
    'INSERT INTO users (email, name, password_hash, salt, created_at) VALUES (?, ?, ?, ?, ?)',
  )
    .bind(email, name, hash, salt, nowISO())
    .run();
  const idFromMeta = Number(res?.meta?.last_row_id);
  if (Number.isFinite(idFromMeta) && idFromMeta > 0) return idFromMeta;

  const existing = await findUserByEmail(env, email);
  if (existing?.id) return existing.id;

  throw new Error('User was created, but failed to retrieve user ID.');
}
