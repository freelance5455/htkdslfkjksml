import { Hono } from 'hono';
import type { AppEnv } from '../lib';
import type { AttemptReport } from '../../shared/types';
import { addDays, json, parseJSON, todayISO } from '../lib';
import { requireAuth } from '../auth';

const analytics = new Hono<AppEnv>();
analytics.use('*', requireAuth);

analytics.get('/analytics', async (c) => {
  const userId = c.get('userId');
  const { results: attempts } = await c.env.DB.prepare(
    `SELECT a.*, t.title, t.exam, t.duration_minutes, t.total_marks
     FROM attempts a JOIN tests t ON t.id = a.test_id
     WHERE a.user_id = ? AND a.status = 'submitted' ORDER BY a.submitted_at ASC`,
  ).bind(userId).all<Record<string, unknown>>();

  const rows = attempts ?? [];
  const reports = rows.map((r) => parseJSON<AttemptReport | null>(r.report, null));

  const subjectMap = new Map<string, { correct: number; total: number; score: number; max: number }>();
  const chapterMap = new Map<string, { subject: string; chapter: string; correct: number; total: number }>();
  const mistakeTotals: Record<string, number> = {};
  const difficultyMap = new Map<string, { correct: number; total: number }>();

  reports.forEach((report, index) => {
    if (!report) return;
    const attempt = rows[index];
    for (const s of report.subjects ?? []) {
      const entry = subjectMap.get(s.subject) ?? { correct: 0, total: 0, score: 0, max: 0 };
      entry.correct += s.correct;
      entry.total += s.correct + s.incorrect;
      entry.score += s.score;
      entry.max += s.max;
      subjectMap.set(s.subject, entry);
    }
    for (const chapter of report.chapters ?? []) {
      const key = `${chapter.subject}::${chapter.chapter}`;
      const entry = chapterMap.get(key) ?? { subject: chapter.subject, chapter: chapter.chapter, correct: 0, total: 0 };
      entry.correct += chapter.correct;
      entry.total += chapter.total;
      chapterMap.set(key, entry);
    }
    for (const [key, value] of Object.entries(report.mistakeCounts ?? {})) {
      mistakeTotals[key] = (mistakeTotals[key] ?? 0) + Number(value);
    }
    for (const d of report.difficulties ?? []) {
      const entry = difficultyMap.get(d.difficulty) ?? { correct: 0, total: 0 };
      entry.correct += d.correct;
      entry.total += d.total;
      difficultyMap.set(d.difficulty, entry);
    }
    void attempt;
  });

  const { results: studyDays } = await c.env.DB.prepare(
    'SELECT date, SUM(minutes) AS minutes, COUNT(*) AS sessions FROM study_sessions WHERE user_id = ? AND date >= ? GROUP BY date ORDER BY date',
  ).bind(userId, addDays(todayISO(), -29)).all<{ date: string; minutes: number; sessions: number }>();

  const cardStats = await c.env.DB.prepare(
    'SELECT COUNT(*) AS total, SUM(CASE WHEN repetitions > 0 THEN 1 ELSE 0 END) AS reviewed FROM revision_cards WHERE user_id = ?',
  ).bind(userId).first<{ total: number; reviewed: number }>();

  const progress = await c.env.DB.prepare(
    'SELECT subject, COUNT(*) AS total, AVG(mastery) AS mastery, SUM(CASE WHEN status = \'confident\' THEN 1 ELSE 0 END) AS confident FROM chapter_progress WHERE user_id = ? GROUP BY subject',
  ).bind(userId).all<{ subject: string; total: number; mastery: number; confident: number }>();

  const trend = rows.map((r, i) => {
    const previous = i > 0 ? Number(rows[i - 1].accuracy ?? 0) : null;
    return {
      attemptId: Number(r.id),
      title: String(r.title),
      exam: String(r.exam),
      date: String(r.submitted_at ?? '').slice(0, 10),
      score: Number(r.score ?? 0),
      max: Number(r.max_score ?? 0),
      percent: Number(r.max_score ?? 0) ? Math.round((Number(r.score) / Number(r.max_score)) * 1000) / 10 : 0,
      accuracy: Number(r.accuracy ?? 0),
      change: previous === null ? null : Math.round((Number(r.accuracy ?? 0) - previous) * 10) / 10,
      timeMinutes: Math.round(Number(r.time_spent ?? 0) / 60),
      mistakes: reports[i]?.mistakeCounts ?? {},
    };
  });

  const totalMinutes = (studyDays ?? []).reduce((s, d) => s + Number(d.minutes ?? 0), 0);
  const totalAttempts = rows.length;
  const totalSolved = reports.reduce((s, r) => s + (r?.evaluated?.length ?? 0), 0);
  const totalCorrect = rows.reduce((s, r) => s + Number(r.correct ?? 0), 0);

  return json({
    summary: {
      attempts: totalAttempts,
      questionsAttempted: totalSolved,
      accuracy: totalAttempts ? Math.round((totalCorrect / Math.max(1, totalSolved)) * 1000) / 10 : null,
      studyMinutes: totalMinutes,
      studyDays: studyDays?.length ?? 0,
      averageScorePercent: totalAttempts
        ? Math.round((rows.reduce((s, r) => s + (Number(r.max_score) ? Number(r.score) / Number(r.max_score) : 0), 0) / totalAttempts) * 1000) / 10
        : null,
      bestScorePercent: rows.length
        ? Math.round(Math.max(...rows.map((r) => (Number(r.max_score) ? Number(r.score) / Number(r.max_score) : 0))) * 1000) / 10
        : null,
      revisionCards: Number(cardStats?.total ?? 0),
      revisionReviewed: Number(cardStats?.reviewed ?? 0),
    },
    trend,
    subjects: [...subjectMap.entries()].map(([subject, v]) => ({
      subject,
      accuracy: v.correct + (v.total - v.correct) > 0 ? Math.round((v.correct / Math.max(1, v.total)) * 1000) / 10 : 0,
      score: Math.round(v.score * 10) / 10,
      max: Math.round(v.max * 10) / 10,
      correct: v.correct,
      attempted: v.total,
    })),
    chapters: [...chapterMap.values()]
      .map((ch) => ({ ...ch, accuracy: ch.total ? Math.round((ch.correct / ch.total) * 1000) / 10 : 0 }))
      .sort((a, b) => a.accuracy - b.accuracy),
    mistakes: Object.entries(mistakeTotals)
      .map(([type, count]) => ({ type, count }))
      .sort((a, b) => b.count - a.count),
    difficulties: [...difficultyMap.entries()].map(([difficulty, v]) => ({
      difficulty,
      accuracy: v.total ? Math.round((v.correct / v.total) * 1000) / 10 : 0,
      total: v.total,
    })),
    studyByDay: (studyDays ?? []).map((d) => ({ date: d.date, minutes: Number(d.minutes), sessions: Number(d.sessions) })),
    subjectProgress: (progress.results ?? []).map((p) => ({
      subject: p.subject,
      chapters: p.total,
      mastery: Math.round(Number(p.mastery ?? 0) * 100),
      confident: p.confident,
    })),
  });
});

export default analytics;
