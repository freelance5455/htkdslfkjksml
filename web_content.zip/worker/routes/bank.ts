import { Hono } from 'hono';
import type { AppEnv } from '../lib';
import { badRequest, json, notFound, nowISO, num, str } from '../lib';
import { requireAuth } from '../auth';
import { aiEnabled, aiJSON, AIError, profileContext } from '../ai';
import { mapQuestion } from '../tests-engine';
import { getProfile, listProgress } from '../store';

const bank = new Hono<AppEnv>();
bank.use('*', requireAuth);

bank.get('/bank', async (c) => {
  const userId = c.get('userId');
  const subject = str(c.req.query('subject'), 60);
  const chapter = str(c.req.query('chapter'), 140);
  const type = str(c.req.query('type'), 30);
  const difficulty = str(c.req.query('difficulty'), 20);
  const source = str(c.req.query('source'), 30);
  const search = str(c.req.query('search'), 200);
  const bookmarkedOnly = c.req.query('bookmarked') === 'true';
  const attempted = str(c.req.query('attempted'), 20);
  const limit = Math.round(num(c.req.query('limit'), 40, 1, 200));
  const offset = Math.round(num(c.req.query('offset'), 0, 0, 100000));

  const where: string[] = ['(q.user_id IS NULL OR q.user_id = ?)'];
  const params: unknown[] = [userId];
  if (subject) { where.push('q.subject = ?'); params.push(subject); }
  if (chapter) { where.push('q.chapter = ?'); params.push(chapter); }
  if (type) { where.push('q.type = ?'); params.push(type); }
  if (difficulty) { where.push('q.difficulty = ?'); params.push(difficulty); }
  if (source) { where.push('q.source = ?'); params.push(source); }
  if (search) { where.push('(q.prompt LIKE ? OR q.chapter LIKE ? OR q.topic LIKE ?)'); params.push(`%${search}%`, `%${search}%`, `%${search}%`); }
  if (bookmarkedOnly) { where.push('bm.question_id IS NOT NULL'); }
  if (attempted === 'unattempted') where.push('qa.correct IS NULL');
  if (attempted === 'correct') where.push('qa.correct = 1');
  if (attempted === 'incorrect') where.push('qa.correct = 0');

  const sql = `
    SELECT q.*, bm.question_id AS bookmarked,
      (SELECT qa.correct FROM question_attempts qa WHERE qa.question_id = q.id AND qa.user_id = ? ORDER BY qa.id DESC LIMIT 1) AS last_correct,
      (SELECT COUNT(*) FROM question_attempts qa2 WHERE qa2.question_id = q.id AND qa2.user_id = ?) AS attempt_count
    FROM questions q
    LEFT JOIN bookmarks bm ON bm.question_id = q.id AND bm.user_id = ?
    LEFT JOIN (SELECT question_id, MAX(id) AS last_id FROM question_attempts WHERE user_id = ? GROUP BY question_id) latest ON latest.question_id = q.id
    LEFT JOIN question_attempts qa ON qa.id = latest.last_id
    WHERE ${where.join(' AND ')}
    ORDER BY q.id DESC LIMIT ? OFFSET ?`;

  const { results } = await c.env.DB.prepare(sql)
    .bind(userId, userId, userId, userId, ...params, limit, offset)
    .all<Record<string, unknown>>();

  const total = await c.env.DB.prepare(
    `SELECT COUNT(*) AS n FROM questions q
     LEFT JOIN bookmarks bm ON bm.question_id = q.id AND bm.user_id = ?
     WHERE ${where.join(' AND ')}`,
  )
    .bind(userId, ...params)
    .first<{ n: number }>();

  return json({
    questions: (results ?? []).map((r) => ({
      ...mapQuestion(r),
      bookmarked: Boolean(r.bookmarked),
      lastCorrect: r.last_correct == null ? null : Boolean(r.last_correct),
      attemptCount: Number(r.attempt_count ?? 0),
    })),
    total: total?.n ?? 0,
    limit,
    offset,
  });
});

bank.get('/bank/bookmarks', async (c) => {
  const userId = c.get('userId');
  const { results } = await c.env.DB.prepare(
    `SELECT q.* FROM questions q JOIN bookmarks bm ON bm.question_id = q.id
     WHERE bm.user_id = ? ORDER BY bm.created_at DESC LIMIT 200`,
  )
    .bind(userId)
    .all<Record<string, unknown>>();
  return json({ questions: (results ?? []).map(mapQuestion) });
});

bank.post('/bank/:id/bookmark', async (c) => {
  const userId = c.get('userId');
  const questionId = Number(c.req.param('id'));
  const existing = await c.env.DB.prepare('SELECT 1 AS x FROM bookmarks WHERE user_id = ? AND question_id = ?')
    .bind(userId, questionId)
    .first();
  if (existing) {
    await c.env.DB.prepare('DELETE FROM bookmarks WHERE user_id = ? AND question_id = ?').bind(userId, questionId).run();
    return json({ bookmarked: false });
  }
  await c.env.DB.prepare('INSERT INTO bookmarks (user_id, question_id, created_at) VALUES (?, ?, ?)')
    .bind(userId, questionId, nowISO())
    .run();
  return json({ bookmarked: true });
});

bank.post('/bank/:id/attempt', async (c) => {
  const userId = c.get('userId');
  const questionId = Number(c.req.param('id'));
  const question = await c.env.DB.prepare('SELECT * FROM questions WHERE id = ? AND (user_id IS NULL OR user_id = ?)')
    .bind(questionId, userId)
    .first<Record<string, unknown>>();
  if (!question) return notFound('Question not found.');

  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const response = Array.isArray(body.response) ? (body.response as unknown[]).map((v) => str(v, 200)).filter(Boolean) : [];
  const numeric = body.numeric == null ? null : str(body.numeric, 80);
  const q = mapQuestion(question);

  let correct = false;
  let awarded = 0;
  let feedback = '';
  if (['numerical', 'integer'].includes(q.type)) {
    const expected = Number(q.numericAnswer);
    const given = Number(numeric);
    correct = Number.isFinite(expected) && Number.isFinite(given) && Math.abs(expected - given) <= Math.max(0.01, Math.abs(expected) * 0.01);
    feedback = correct ? 'Correct.' : `Not quite — the expected value is ${q.numericAnswer ?? q.correct[0] ?? 'not stored'}.`;
    awarded = correct ? q.marks : 0;
  } else if (q.correct.length) {
    const given = [...response].sort();
    const expected = [...q.correct].sort();
    correct = given.length === expected.length && given.every((v, i) => v.trim() === expected[i].trim());
    feedback = correct ? 'Correct.' : `The correct option is ${q.correct.join(', ')}.`;
    awarded = correct ? q.marks : 0;
  } else {
    // Descriptive bank questions: no automatic marking without AI.
    feedback = 'This is a descriptive question. Compare your answer with the model solution below.';
  }

  await c.env.DB.prepare(
    'INSERT INTO question_attempts (user_id, question_id, correct, response, created_at) VALUES (?, ?, ?, ?, ?)',
  )
    .bind(userId, questionId, correct ? 1 : 0, JSON.stringify({ response, numeric }), nowISO())
    .run();

  return json({ correct, awarded, feedback, solution: q.solution, autoGraded: q.correct.length > 0 || Boolean(q.numericAnswer) });
});

/** Generates extra practice questions with AI, saved to the student's own bank. */
bank.post('/bank/generate', async (c) => {
  const userId = c.get('userId');
  if (!aiEnabled(c.env)) {
    return json({ error: 'AI question generation needs OPENAI_API_KEY to be configured.', code: 'ai_not_configured', setupRequired: true }, { status: 503 });
  }
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const subject = str(body.subject, 60);
  const chapter = str(body.chapter, 140);
  const type = ['mcq', 'multiple-correct', 'numerical', 'integer', 'assertion-reason', 'short-answer', 'long-answer', 'case-based'].includes(str(body.type, 30))
    ? str(body.type, 30)
    : 'mcq';
  const difficulty = ['easy', 'medium', 'hard', 'advanced'].includes(str(body.difficulty, 20)) ? str(body.difficulty, 20) : 'medium';
  const count = Math.round(num(body.count, 5, 1, 10));
  if (!subject || !chapter) return badRequest('Choose a subject and chapter first.', 'missing_fields');

  const profile = await getProfile(c.env.DB, userId);
  const progress = await listProgress(c.env.DB, userId);
  const existing = progress.find((p) => p.subject === subject && p.chapter === chapter);

  const prompt = `Generate ${count} ${difficulty} ${type} questions for ${subject} — ${chapter} for a student preparing for ${profile?.examLabel ?? 'CBSE'}.\nStudent context:\n${profileContext(profile as unknown as Record<string, unknown> | null)}\nMastery on this chapter: ${existing ? Math.round(existing.mastery * 100) + '%' : 'unknown'}.\nReturn {"questions":[{"subject","chapter","topic","type","difficulty","prompt","options":[{"key":"A","text":""}],"correct":["A"],"numericAnswer":null,"solution"}]} with exactly ${count} items.`;

  try {
    const result = await aiJSON<{ questions: Record<string, unknown>[] }>(
      c.env,
      [
        {
          role: 'system',
          content:
            'You write original practice questions for Indian board and entrance exams. Every question must be correct and self-consistent with a complete worked solution. Return JSON only.',
        },
        { role: 'user', content: prompt },
      ],
      { temperature: 0.5, maxTokens: 3000, timeoutMs: 90000 },
    );

    const inserted: number[] = [];
    for (const q of result.questions ?? []) {
      const text = str(q.prompt, 5000);
      if (text.length < 8) continue;
      const options = Array.isArray(q.options)
        ? (q.options as Record<string, unknown>[]).map((o) => ({ key: str(o.key, 3), text: str(o.text, 800) })).filter((o) => o.key && o.text)
        : null;
      const correct = Array.isArray(q.correct) ? (q.correct as unknown[]).map((v) => str(v, 200)).filter(Boolean) : [];
      const res = await c.env.DB.prepare(
        `INSERT INTO questions (user_id, subject, chapter, topic, type, difficulty, prompt, options, correct, numeric_answer, marks, negative, solution, source, source_label, verified, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, 'ai', 'AI-generated practice', 0, ?)`,
      ).bind(
        userId, subject, chapter, str(q.topic, 120) || chapter,
        (['mcq', 'multiple-correct', 'numerical', 'integer', 'assertion-reason', 'short-answer', 'long-answer', 'case-based'].includes(str(q.type, 30)) ? str(q.type, 30) : type),
        difficulty, text, options ? JSON.stringify(options) : null, JSON.stringify(correct),
        q.numericAnswer == null ? null : str(q.numericAnswer, 80),
        str(q.solution, 4000) || 'Solution not generated.', nowISO(),
      ).run();
      inserted.push(Number(res.meta.last_row_id));
    }
    const { results } = await c.env.DB.prepare(
      `SELECT * FROM questions WHERE id IN (${inserted.length ? inserted.map(() => '?').join(',') : 'NULL'})`,
    )
      .bind(...inserted)
      .all<Record<string, unknown>>();
    return json({ questions: (results ?? []).map(mapQuestion), saved: inserted.length });
  } catch (err) {
    if (err instanceof AIError) return json({ error: err.message, code: 'ai_error', setupRequired: err.setupRequired }, { status: err.status });
    throw err;
  }
});

/* --------------------------- collections --------------------------- */

bank.get('/collections', async (c) => {
  const { results } = await c.env.DB.prepare(
    `SELECT c.id, c.name, c.created_at, (SELECT COUNT(*) FROM collection_items ci WHERE ci.collection_id = c.id) AS count
     FROM collections c WHERE c.user_id = ? ORDER BY c.id DESC`,
  )
    .bind(c.get('userId'))
    .all<{ id: number; name: string; created_at: string; count: number }>();
  return json({
    collections: (results ?? []).map((r) => ({ id: Number(r.id), name: r.name, count: Number(r.count ?? 0), createdAt: r.created_at })),
  });
});

bank.post('/collections', async (c) => {
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const name = str(body.name, 80);
  if (name.length < 2) return badRequest('Give the collection a name.', 'invalid_name');
  const res = await c.env.DB.prepare('INSERT INTO collections (user_id, name, created_at) VALUES (?, ?, ?)')
    .bind(c.get('userId'), name, nowISO())
    .run();
  return json({ collection: { id: Number(res.meta.last_row_id), name, count: 0 } }, { status: 201 });
});

bank.delete('/collections/:id', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const owned = await c.env.DB.prepare('SELECT id FROM collections WHERE id = ? AND user_id = ?').bind(id, userId).first();
  if (!owned) return notFound('Collection not found.');
  await c.env.DB.batch([
    c.env.DB.prepare('DELETE FROM collection_items WHERE collection_id = ?').bind(id),
    c.env.DB.prepare('DELETE FROM collections WHERE id = ? AND user_id = ?').bind(id, userId),
  ]);
  return json({ ok: true });
});

bank.get('/collections/:id', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const collection = await c.env.DB.prepare('SELECT id, name FROM collections WHERE id = ? AND user_id = ?')
    .bind(id, userId)
    .first<{ id: number; name: string }>();
  if (!collection) return notFound('Collection not found.');
  const { results } = await c.env.DB.prepare(
    `SELECT q.*, bm.question_id AS bookmarked FROM questions q
     JOIN collection_items ci ON ci.question_id = q.id
     LEFT JOIN bookmarks bm ON bm.question_id = q.id AND bm.user_id = ?
     WHERE ci.collection_id = ? AND (q.user_id IS NULL OR q.user_id = ?) ORDER BY ci.created_at DESC`,
  )
    .bind(userId, id, userId)
    .all<Record<string, unknown>>();
  return json({
    collection,
    questions: (results ?? []).map((r) => ({ ...mapQuestion(r), bookmarked: Boolean(r.bookmarked), lastCorrect: null, attemptCount: 0 })),
  });
});

bank.post('/collections/:id/items', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const owned = await c.env.DB.prepare('SELECT id FROM collections WHERE id = ? AND user_id = ?').bind(id, userId).first();
  if (!owned) return notFound('Collection not found.');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const questionId = Number(body.questionId);
  const question = await c.env.DB.prepare('SELECT id FROM questions WHERE id = ? AND (user_id IS NULL OR user_id = ?)')
    .bind(questionId, userId)
    .first();
  if (!question) return notFound('Question not found.');
  await c.env.DB.prepare('INSERT OR IGNORE INTO collection_items (collection_id, question_id, created_at) VALUES (?, ?, ?)')
    .bind(id, questionId, nowISO())
    .run();
  return json({ ok: true });
});

bank.delete('/collections/:id/items/:questionId', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const owned = await c.env.DB.prepare('SELECT id FROM collections WHERE id = ? AND user_id = ?').bind(id, userId).first();
  if (!owned) return notFound('Collection not found.');
  await c.env.DB.prepare('DELETE FROM collection_items WHERE collection_id = ? AND question_id = ?')
    .bind(id, Number(c.req.param('questionId')))
    .run();
  return json({ ok: true });
});

bank.get('/bank/stats', async (c) => {
  const userId = c.get('userId');
  const row = await c.env.DB.prepare(
    `SELECT COUNT(*) AS solved, SUM(correct) AS correct FROM question_attempts WHERE user_id = ?`,
  )
    .bind(userId)
    .first<{ solved: number; correct: number | null }>();
  const perSubject = await c.env.DB.prepare(
    `SELECT q.subject, COUNT(*) AS n, SUM(qa.correct) AS correct FROM question_attempts qa
     JOIN questions q ON q.id = qa.question_id WHERE qa.user_id = ? GROUP BY q.subject`,
  )
    .bind(userId)
    .all<{ subject: string; n: number; correct: number }>();
  return json({
    solved: row?.solved ?? 0,
    correct: row?.correct ?? 0,
    accuracy: row?.solved ? Math.round(((row.correct ?? 0) / row.solved) * 1000) / 10 : null,
    subjects: (perSubject.results ?? []).map((s) => ({
      subject: s.subject,
      solved: s.n,
      correct: s.correct,
      accuracy: s.n ? Math.round((s.correct / s.n) * 1000) / 10 : 0,
    })),
  });
});

export default bank;
