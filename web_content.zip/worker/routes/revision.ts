import { Hono } from 'hono';
import type { AppEnv } from '../lib';
import { badRequest, json, notFound, nowISO, num, parseJSON, str, todayISO, addDays } from '../lib';
import { requireAuth } from '../auth';
import { aiEnabled, aiJSON, AIError, profileContext } from '../ai';
import { buildContextBlock, retrieve } from '../rag';
import { getProfile, nextSchedule } from '../store';
import { mapQuestion } from '../tests-engine';

const revision = new Hono<AppEnv>();
revision.use('*', requireAuth);

function mapCard(row: Record<string, unknown>) {
  return {
    id: Number(row.id),
    front: String(row.front),
    back: String(row.back),
    subject: (row.subject as string) ?? null,
    chapter: (row.chapter as string) ?? null,
    source: String(row.source),
    due: String(row.due),
    intervalDays: Number(row.interval_days ?? 1),
    ease: Number(row.ease ?? 2.5),
    repetitions: Number(row.repetitions ?? 0),
    lapses: Number(row.lapses ?? 0),
    questionId: row.question_id == null ? null : Number(row.question_id),
  };
}

revision.get('/revision', async (c) => {
  const userId = c.get('userId');
  const today = todayISO();
  const { results: cards } = await c.env.DB.prepare(
    'SELECT * FROM revision_cards WHERE user_id = ? AND due <= ? ORDER BY due, id LIMIT 60',
  )
    .bind(userId, today)
    .all<Record<string, unknown>>();

  const upcoming = await c.env.DB.prepare(
    'SELECT COUNT(*) AS n FROM revision_cards WHERE user_id = ? AND due > ? AND due <= ?',
  )
    .bind(userId, today, addDays(today, 7))
    .first<{ n: number }>();
  const totalCards = await c.env.DB.prepare('SELECT COUNT(*) AS n FROM revision_cards WHERE user_id = ?')
    .bind(userId)
    .first<{ n: number }>();
  const reviewed = await c.env.DB.prepare(
    'SELECT COUNT(*) AS n FROM revision_cards WHERE user_id = ? AND repetitions > 0',
  )
    .bind(userId)
    .first<{ n: number }>();

  const { results: chapters } = await c.env.DB.prepare(
    `SELECT subject, chapter, mastery, status, next_review, interval_days FROM chapter_progress
     WHERE user_id = ? AND status != 'not-started' AND (next_review IS NULL OR next_review <= ?)
     ORDER BY mastery ASC, next_review ASC LIMIT 30`,
  )
    .bind(userId, today)
    .all<Record<string, unknown>>();

  const { results: formulaRows } = await c.env.DB.prepare(
    `SELECT ri.payload, r.name FROM resource_insights ri JOIN resources r ON r.id = ri.resource_id
     WHERE ri.user_id = ? AND ri.kind IN ('summary','formulas') ORDER BY ri.id DESC LIMIT 6`,
  )
    .bind(userId)
    .all<{ payload: string; name: string }>();

  const formulas: { name: string; expression: string; whereUsed?: string; source: string }[] = [];
  for (const row of formulaRows ?? []) {
    const payload = parseJSON<Record<string, unknown>>(row.payload, {});
    const list = Array.isArray(payload.formulas) ? (payload.formulas as Record<string, unknown>[]) : [];
    for (const f of list.slice(0, 12)) {
      const name = str(f.name, 160);
      const expression = str(f.expression, 300);
      if (name && expression) formulas.push({ name, expression, whereUsed: str(f.whereUsed, 200), source: row.name });
    }
  }

  return json({
    cards: (cards ?? []).map(mapCard),
    dueCount: cards?.length ?? 0,
    upcomingCount: upcoming?.n ?? 0,
    totalCards: totalCards?.n ?? 0,
    reviewedCards: reviewed?.n ?? 0,
    dueChapters: (chapters ?? []).map((ch) => ({
      subject: String(ch.subject),
      chapter: String(ch.chapter),
      mastery: Number(ch.mastery ?? 0),
      status: String(ch.status),
      nextReview: (ch.next_review as string) ?? null,
    })),
    formulas: formulas.slice(0, 40),
    today,
  });
});

revision.post('/revision/cards', async (c) => {
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const front = str(body.front, 1000);
  const back = str(body.back, 3000);
  if (front.length < 3 || back.length < 1) return badRequest('A flashcard needs a front and a back.', 'invalid_card');
  const res = await c.env.DB.prepare(
    `INSERT INTO revision_cards (user_id, front, back, subject, chapter, source, due, created_at)
     VALUES (?, ?, ?, ?, ?, 'manual', ?, ?)`,
  )
    .bind(c.get('userId'), front, back, str(body.subject, 60) || null, str(body.chapter, 120) || null, todayISO(), nowISO())
    .run();
  return json({ card: { id: Number(res.meta.last_row_id), front, back, due: todayISO() } }, { status: 201 });
});

revision.delete('/revision/cards/:id', async (c) => {
  await c.env.DB.prepare('DELETE FROM revision_cards WHERE id = ? AND user_id = ?')
    .bind(Number(c.req.param('id')), c.get('userId'))
    .run();
  return json({ ok: true });
});

revision.post('/revision/cards/:id/review', async (c) => {
  const userId = c.get('userId');
  const cardId = Number(c.req.param('id'));
  const card = await c.env.DB.prepare('SELECT * FROM revision_cards WHERE id = ? AND user_id = ?')
    .bind(cardId, userId)
    .first<Record<string, unknown>>();
  if (!card) return notFound('Card not found.');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const grade = Math.round(num(body.grade, 2, 0, 3));
  const schedule = nextSchedule(
    {
      ease: Number(card.ease ?? 2.5),
      intervalDays: Number(card.interval_days ?? 1),
      repetitions: Number(card.repetitions ?? 0),
    },
    grade,
  );
  await c.env.DB.prepare(
    'UPDATE revision_cards SET due = ?, interval_days = ?, ease = ?, repetitions = ?, lapses = lapses + ? WHERE id = ? AND user_id = ?',
  )
    .bind(schedule.due, schedule.intervalDays, schedule.ease, schedule.repetitions, grade === 0 ? 1 : 0, cardId, userId)
    .run();
  return json({ ok: true, due: schedule.due, intervalDays: schedule.intervalDays });
});

/** AI-generated flashcards for a chapter, grounded in uploaded resources when available. */
revision.post('/revision/generate', async (c) => {
  const userId = c.get('userId');
  if (!aiEnabled(c.env)) {
    return json({ error: 'AI flashcard generation needs OPENAI_API_KEY to be configured.', code: 'ai_not_configured', setupRequired: true }, { status: 503 });
  }
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const subject = str(body.subject, 60);
  const chapter = str(body.chapter, 140);
  const count = Math.round(num(body.count, 8, 3, 15));
  if (!subject || !chapter) return badRequest('Choose a subject and chapter.', 'missing_fields');

  const profile = await getProfile(c.env.DB, userId);
  const retrieved = await retrieve(c.env.DB, userId, `${subject} ${chapter} formulas definitions key points`, { limit: 4 });
  const contextBlock = buildContextBlock(retrieved, 5000);

  try {
    const result = await aiJSON<{ cards: { front: string; back: string }[] }>(
      c.env,
      [
        {
          role: 'system',
          content:
            'You create concise revision flashcards for exam preparation. Each card tests exactly one fact, formula or distinction. Front is a short prompt or question; back is a precise answer. Return JSON only.',
        },
        {
          role: 'user',
          content: [
            `Create ${count} flashcards for ${subject} — ${chapter} for ${profile?.examLabel ?? 'CBSE'} level.`,
            contextBlock ? `Use these excerpts from the student's material where relevant:\n${contextBlock}` : '',
            'Return {"cards":[{"front":"...","back":"..."}]}. No duplicates, no trivial cards.',
          ].join('\n\n'),
        },
      ],
      { temperature: 0.4, maxTokens: 2200, timeoutMs: 90000 },
    );

    let saved = 0;
    for (const card of result.cards ?? []) {
      const front = str(card.front, 900);
      const back = str(card.back, 2200);
      if (front.length < 5 || back.length < 1) continue;
      await c.env.DB.prepare(
        `INSERT INTO revision_cards (user_id, front, back, subject, chapter, source, due, created_at)
         VALUES (?, ?, ?, ?, ?, 'ai', ?, ?)`,
      ).bind(userId, front, back, subject, chapter, todayISO(), nowISO()).run();
      saved++;
    }
    return json({ saved });
  } catch (err) {
    if (err instanceof AIError) return json({ error: err.message, code: 'ai_error', setupRequired: err.setupRequired }, { status: err.status });
    throw err;
  }
});

/** Quick quiz assembled from the student's bank for a chapter. */
revision.post('/revision/quiz', async (c) => {
  const userId = c.get('userId');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const subject = str(body.subject, 60);
  const chapter = str(body.chapter, 140);
  const count = Math.round(num(body.count, 8, 3, 25));
  const where = ['(user_id IS NULL OR user_id = ?)', "type IN ('mcq','numerical','integer','assertion-reason')"];
  const params: unknown[] = [userId];
  if (subject) { where.push('subject = ?'); params.push(subject); }
  if (chapter) { where.push('chapter = ?'); params.push(chapter); }
  const { results } = await c.env.DB.prepare(
    `SELECT * FROM questions WHERE ${where.join(' AND ')} ORDER BY RANDOM() LIMIT ?`,
  )
    .bind(...params, count)
    .all<Record<string, unknown>>();
  return json({
    questions: (results ?? []).map(mapQuestion).map((q) => ({
      id: q.id, subject: q.subject, chapter: q.chapter, type: q.type, difficulty: q.difficulty,
      prompt: q.prompt, options: q.options, marks: q.marks, solution: q.solution,
      correct: q.correct, numericAnswer: q.numericAnswer,
    })),
  });
});

/** Marks a due chapter as revised, pushing its next review out. */
revision.post('/revision/chapters', async (c) => {
  const userId = c.get('userId');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const subject = str(body.subject, 60);
  const chapter = str(body.chapter, 140);
  const grade = Math.round(num(body.grade, 2, 0, 3));
  if (!subject || !chapter) return badRequest('Subject and chapter are required.', 'missing_fields');
  const row = await c.env.DB.prepare(
    'SELECT * FROM chapter_progress WHERE user_id = ? AND subject = ? AND chapter = ?',
  ).bind(userId, subject, chapter).first<Record<string, unknown>>();
  if (!row) return notFound('Chapter not found.');

  const schedule = nextSchedule(
    { ease: Number(row.ease ?? 2.5), intervalDays: Number(row.interval_days ?? 1), repetitions: Number(row.repetitions ?? 0) },
    grade,
  );
  const mastery = Math.min(1, Number(row.mastery ?? 0) + (grade === 3 ? 0.1 : grade === 2 ? 0.05 : -0.1));
  const status = mastery >= 0.8 ? 'confident' : mastery >= 0.5 ? 'revising' : 'learning';
  await c.env.DB.prepare(
    `UPDATE chapter_progress SET next_review = ?, interval_days = ?, ease = ?, repetitions = repetitions + 1,
       mastery = ?, status = ?, last_studied = ?, updated_at = ? WHERE user_id = ? AND subject = ? AND chapter = ?`,
  )
    .bind(schedule.due, schedule.intervalDays, schedule.ease, Math.max(0, mastery), status, todayISO(), nowISO(), userId, subject, chapter)
    .run();
  return json({ ok: true, nextReview: schedule.due, mastery });
});

export default revision;
