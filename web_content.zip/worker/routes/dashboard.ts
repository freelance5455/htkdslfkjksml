import { Hono } from 'hono';
import type { AppEnv } from '../lib';
import { addDays, clamp, json, parseJSON, todayISO } from '../lib';
import { requireAuth } from '../auth';
import { getProfile, listProgress, scheduleItems, studyStreak } from '../store';

const dashboard = new Hono<AppEnv>();
dashboard.use('*', requireAuth);

dashboard.get('/dashboard', async (c) => {
  const db = c.env.DB;
  const userId = c.get('userId') || 1;
  const profile = await getProfile(db, userId);

  let progress: any[] = [];
  let streak = 1;
  let studyRow: any = null;
  let attemptRows: any[] = [];
  let dueCards: any = null;
  let resources: any = null;
  let solved: any = null;
  let todayItems: any[] = [];
  let upcomingItems: any[] = [];

  if (db) {
    try {
      [progress, streak] = await Promise.all([listProgress(db, userId).catch(() => []), studyStreak(db, userId).catch(() => 1)]);

      studyRow = await db
        .prepare(
          `SELECT
             SUM(CASE WHEN date >= ? THEN minutes ELSE 0 END) AS last7,
             SUM(CASE WHEN date >= ? THEN minutes ELSE 0 END) AS last30,
             SUM(minutes) AS total
           FROM study_sessions WHERE user_id = ?`,
        )
        .bind(addDays(todayISO(), -6), addDays(todayISO(), -29), userId)
        .first<{ last7: number | null; last30: number | null; total: number | null }>()
        .catch(() => null);

      attemptRows = (
        await db
          .prepare(
            `SELECT a.id, a.accuracy, a.score, a.max_score, a.submitted_at, t.title, t.exam, t.id AS test_id
             FROM attempts a JOIN tests t ON t.id = a.test_id
             WHERE a.user_id = ? AND a.status = 'submitted'
             ORDER BY a.submitted_at DESC LIMIT 30`,
          )
          .bind(userId)
          .all<Record<string, unknown>>()
          .catch(() => ({ results: [] }))
      ).results ?? [];

      dueCards = await db
        .prepare("SELECT COUNT(*) AS n FROM revision_cards WHERE user_id = ? AND due <= ?")
        .bind(userId, todayISO())
        .first<{ n: number }>()
        .catch(() => null);

      resources = await db
        .prepare("SELECT COUNT(*) AS n FROM resources WHERE user_id = ? AND status = 'ready'")
        .bind(userId)
        .first<{ n: number }>()
        .catch(() => null);

      solved = await db
        .prepare('SELECT COUNT(*) AS n FROM question_attempts WHERE user_id = ?')
        .bind(userId)
        .first<{ n: number }>()
        .catch(() => null);

      const today = todayISO();
      [todayItems, upcomingItems] = await Promise.all([
        scheduleItems(db, userId, today, today).catch(() => []),
        scheduleItems(db, userId, addDays(today, 1), addDays(today, 7)).catch(() => []),
      ]);
    } catch (e) {
      console.warn('[dashboard query warning]', e);
    }
  }

  const chaptersTotal = progress.length;
  const chaptersDone = progress.filter((p) => p.status === 'confident').length;
  const dueChapters = progress.filter((p) => p.nextReview && p.nextReview <= todayISO() && p.status !== 'confident').length;
  const syllabusCompletion = chaptersTotal
    ? Math.round((progress.reduce((sum, p) => sum + clamp(p.mastery, 0, 1), 0) / chaptersTotal) * 100)
    : 0;

  const recentAccuracies = attemptRows.slice(0, 5).map((a) => Number(a.accuracy ?? 0));
  const avgAccuracy = attemptRows.length
    ? Math.round((attemptRows.reduce((s, a) => s + Number(a.accuracy ?? 0), 0) / attemptRows.length) * 10) / 10
    : null;
  const recentAccuracy = recentAccuracies.length
    ? recentAccuracies.reduce((s, a) => s + a, 0) / recentAccuracies.length
    : null;
  const revisionHealth = dueCards?.n || dueChapters
    ? clamp(1 - Math.min(1, ((dueCards?.n ?? 0) + dueChapters * 2) / Math.max(12, chaptersTotal)), 0, 1)
    : 1;

  const preparation = Math.round(
    syllabusCompletion * 0.5 +
      (recentAccuracy === null ? 0 : recentAccuracy) * 0.3 +
      revisionHealth * 100 * 0.2,
  );

  const bySubject = new Map<string, { total: number; confident: number; learning: number; notStarted: number; mastery: number }>();
  for (const p of progress) {
    const entry = bySubject.get(p.subject) ?? { total: 0, confident: 0, learning: 0, notStarted: 0, mastery: 0 };
    entry.total += 1;
    entry.mastery += p.mastery;
    if (p.status === 'confident') entry.confident += 1;
    else if (p.status === 'learning' || p.status === 'revising') entry.learning += 1;
    else entry.notStarted += 1;
    bySubject.set(p.subject, entry);
  }
  const subjects = [...bySubject.entries()].map(([subject, v]) => ({
    subject,
    total: v.total,
    confident: v.confident,
    learning: v.learning,
    notStarted: v.notStarted,
    completion: v.total ? Math.round(((v.confident + v.learning * 0.5) / v.total) * 100) : 0,
    mastery: v.total ? Math.round((v.mastery / v.total) * 100) : 0,
  }));

  const sorted = [...progress].filter((p) => p.status !== 'not-started').sort((a, b) => a.mastery - b.mastery);
  const weakest = sorted.slice(0, 5).map((p) => ({ subject: p.subject, chapter: p.chapter, mastery: Math.round(p.mastery * 100), status: p.status }));
  const strongest = [...sorted].reverse().slice(0, 5).map((p) => ({ subject: p.subject, chapter: p.chapter, mastery: Math.round(p.mastery * 100), status: p.status }));

  const today = todayISO();

  const trend = [...attemptRows]
    .reverse()
    .slice(-12)
    .map((a) => ({
      date: String(a.submitted_at ?? '').slice(0, 10),
      accuracy: Number(a.accuracy ?? 0),
      score: Number(a.max_score ?? 0) > 0 ? Math.round((Number(a.score ?? 0) / Number(a.max_score)) * 1000) / 10 : 0,
    }));

  const nextExam = profile.examDate
    ? {
        label: profile.examLabel,
        date: profile.examDate,
        daysLeft: Math.max(0, Math.ceil((new Date(profile.examDate + 'T00:00:00Z').getTime() - new Date(today + 'T00:00:00Z').getTime()) / 86400000)),
      }
    : { label: profile.examLabel, date: null, daysLeft: null };

  const hours7 = Math.round(((studyRow?.last7 ?? 0) / 60) * 10) / 10;
  const badges = [
    { id: 'first-test', label: 'First Paper', description: 'Submit your first test', earned: attemptRows.length >= 1, icon: 'file' },
    { id: 'streak-3', label: 'Momentum', description: 'Study 3 days in a row', earned: streak >= 3, icon: 'flame' },
    { id: 'streak-7', label: 'Week Warrior', description: 'Study 7 days in a row', earned: streak >= 7, icon: 'zap' },
    { id: 'ten-chapters', label: 'Syllabus Builder', description: 'Mark 10 chapters confident', earned: chaptersDone >= 10, icon: 'book' },
    { id: 'five-tests', label: 'Test Ready', description: 'Complete 5 full tests', earned: attemptRows.length >= 5, icon: 'target' },
    { id: 'ten-hours', label: 'Deep Work', description: 'Study 10 hours in a week', earned: hours7 >= 10, icon: 'clock' },
    { id: 'hundred-questions', label: 'Question Machine', description: 'Solve 100 questions', earned: (solved?.n ?? 0) >= 100, icon: 'check' },
    { id: 'revision-master', label: 'Revision Master', description: 'Clear 30 revision cards', earned: false, icon: 'repeat' },
  ];

  return json({
    profile,
    stats: {
      preparation,
      syllabusCompletion,
      chaptersTotal,
      chaptersDone,
      studyMinutes7d: studyRow?.last7 ?? 0,
      studyMinutes30d: studyRow?.last30 ?? 0,
      streak,
      testsTaken: attemptRows.length,
      avgAccuracy,
      revisionDue: (dueCards?.n ?? 0) + dueChapters,
      resourcesReady: resources?.n ?? 0,
      questionsSolved: solved?.n ?? 0,
    },
    subjects,
    weakest,
    strongest,
    recentTests: attemptRows.slice(0, 5).map((a) => ({
      id: Number(a.id),
      title: String(a.title),
      score: Number(a.score ?? 0),
      max: Number(a.max_score ?? 0),
      accuracy: Number(a.accuracy ?? 0),
      submittedAt: String(a.submitted_at ?? ''),
      exam: String(a.exam) as never,
    })),
    trend,
    today: todayItems,
    upcoming: upcomingItems,
    badges,
    nextExam,
    dailyGoalMinutes: Math.round((profile.dailyHours || 3) * 60),
  });
});

export default dashboard;
