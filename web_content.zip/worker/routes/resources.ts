import { Hono } from 'hono';
import type { AppEnv } from '../lib';
import { badRequest, json, notFound, nowISO, num, parseJSON, str } from '../lib';
import { requireAuth } from '../auth';
import { aiEnabled, aiJSON, AIError, profileContext } from '../ai';
import { chunkPages, citationsFrom, retrieve } from '../rag';
import { getProfile } from '../store';

const resources = new Hono<AppEnv>();
resources.use('*', requireAuth);

const KINDS = ['ncert', 'notes', 'module', 'reference', 'previous-year', 'sample-paper', 'formula-sheet', 'other'];

resources.get('/resources', async (c) => {
  const { results } = await c.env.DB.prepare(
    `SELECT id, name, kind, size_bytes, page_count, chunk_count, status, subject, chapters, error, summary, created_at
     FROM resources WHERE user_id = ? ORDER BY id DESC`,
  )
    .bind(c.get('userId'))
    .all<Record<string, unknown>>();
  return json({
    resources: (results ?? []).map(mapResource),
    aiEnabled: aiEnabled(c.env),
  });
});

function mapResource(r: Record<string, unknown>) {
  return {
    id: Number(r.id),
    name: String(r.name),
    kind: String(r.kind),
    sizeBytes: Number(r.size_bytes ?? 0),
    pageCount: Number(r.page_count ?? 0),
    chunkCount: Number(r.chunk_count ?? 0),
    status: String(r.status),
    subject: (r.subject as string) ?? null,
    chapters: parseJSON<string[]>(r.chapters, []),
    error: (r.error as string) ?? null,
    summary: (r.summary as string) ?? null,
    createdAt: String(r.created_at),
  };
}

/**
 * Creates a resource from text extracted in the browser. Text is chunked and
 * embedded here; no content is invented if the PDF had no text layer.
 */
resources.post('/resources', async (c) => {
  const userId = c.get('userId');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const name = str(body.name, 200);
  if (name.length < 2) return badRequest('Give the resource a file name.', 'invalid_name');

  const kind = KINDS.includes(str(body.kind, 30)) ? str(body.kind, 30) : 'other';
  const subject = str(body.subject, 60) || null;
  const sizeBytes = num(body.sizeBytes, 0, 0, 200 * 1024 * 1024);
  const pagesRaw = Array.isArray(body.pages) ? (body.pages as unknown[]) : [];
  if (!pagesRaw.length) {
    return badRequest(
      'No text was extracted from this file. Scanned/image-only PDFs need OCR before they can be used — you can paste the chapter text instead.',
      'no_text_extracted',
    );
  }
  if (pagesRaw.length > 2000) return badRequest('This document has too many pages for one upload (max 2000).', 'too_many_pages');

  const pages = pagesRaw
    .slice(0, 2000)
    .map((p, i) => {
      const row = p as Record<string, unknown>;
      return { page: num(row.page, i + 1, 1, 5000), text: str(row.text, 30000) };
    })
    .filter((p) => p.text.length > 0);

  const totalChars = pages.reduce((s, p) => s + p.text.length, 0);
  if (totalChars < 40) {
    return badRequest(
      'Only a tiny amount of text was found — this looks like a scanned PDF. Paste the text manually to use it with the tutor.',
      'no_text_extracted',
    );
  }
  if (totalChars > 4_000_000) return badRequest('This document is too large (over ~4 million characters). Split it into chapters.', 'document_too_large');

  const ts = nowISO();
  const inserted = await c.env.DB.prepare(
    `INSERT INTO resources (user_id, name, kind, size_bytes, page_count, chunk_count, status, subject, chapters, created_at)
     VALUES (?, ?, ?, ?, ?, 0, 'processing', ?, '[]', ?)`,
  )
    .bind(userId, name, kind, Math.round(sizeBytes), pages.length, subject, ts)
    .run();
  const resourceId = Number(inserted.meta.last_row_id);

  const chunks = chunkPages(pages);
  if (!chunks.length) {
    await c.env.DB.prepare("UPDATE resources SET status = 'empty', error = ? WHERE id = ? AND user_id = ?")
      .bind('No usable text could be indexed from this document.', resourceId, userId)
      .run();
    return json({ resource: { id: resourceId, status: 'empty', chunkCount: 0 } }, { status: 201 });
  }

  const statements = chunks.map((chunk) =>
    c.env.DB.prepare(
      'INSERT INTO resource_chunks (resource_id, user_id, page, text, vector) VALUES (?, ?, ?, ?, ?)',
    ).bind(resourceId, userId, chunk.page, chunk.text.slice(0, 4000), JSON.stringify(chunk.vector)),
  );
  for (let i = 0; i < statements.length; i += 40) {
    await c.env.DB.batch(statements.slice(i, i + 40));
  }

  await c.env.DB.prepare("UPDATE resources SET status = 'ready', chunk_count = ?, error = NULL WHERE id = ? AND user_id = ?")
    .bind(chunks.length, resourceId, userId)
    .run();

  const row = await c.env.DB.prepare('SELECT * FROM resources WHERE id = ? AND user_id = ?').bind(resourceId, userId).first<Record<string, unknown>>();
  return json({ resource: row ? mapResource(row) : { id: resourceId } }, { status: 201 });
});

/** Stores the original file in R2, scoped to the owner. */
resources.put('/resources/:id/file', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const owned = await c.env.DB.prepare('SELECT id FROM resources WHERE id = ? AND user_id = ?').bind(id, userId).first();
  if (!owned) return notFound('Resource not found.');
  if (!c.env.FILES) return json({ error: 'File storage is not configured on this deployment.', code: 'no_storage' }, { status: 501 });

  const length = Number(c.req.header('content-length') ?? 0);
  if (length > 25 * 1024 * 1024) return badRequest('Files must be 25 MB or smaller.', 'file_too_large');
  const buffer = await c.req.arrayBuffer();
  if (!buffer.byteLength) return badRequest('Empty file.', 'empty_file');
  if (buffer.byteLength > 25 * 1024 * 1024) return badRequest('Files must be 25 MB or smaller.', 'file_too_large');

  await c.env.FILES.put(`users/${userId}/resources/${id}/${encodeURIComponent(c.req.header('x-filename') || 'document.pdf')}`, buffer, {
    httpMetadata: { contentType: c.req.header('content-type') || 'application/pdf' },
  });
  return json({ ok: true, stored: true });
});

resources.get('/resources/:id/file', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  if (!c.env.FILES) return notFound('File storage is not configured.');
  const listed = await c.env.FILES.list({ prefix: `users/${userId}/resources/${id}/`, limit: 1 });
  const object = listed.objects[0];
  if (!object) return notFound('Original file was not stored for this resource.');
  const body = await c.env.FILES.get(object.key);
  if (!body) return notFound('File not found.');
  return new Response(body.body, {
    headers: {
      'content-type': object.httpMetadata?.contentType ?? 'application/octet-stream',
      'content-disposition': `inline; filename="${encodeURIComponent(object.key.split('/').pop() ?? 'file')}"`,
    },
  });
});

/** Registered before /resources/:id so "search" is not treated as an id. */
resources.get('/resources/search', async (c) => {
  const userId = c.get('userId');
  const q = str(c.req.query('q'), 300);
  if (q.length < 2) return badRequest('Enter at least two characters to search.', 'query_too_short');
  const resourceId = Number(c.req.query('resourceId') ?? 0);
  const chunks = await retrieve(c.env.DB, userId, q, {
    resourceIds: Number.isFinite(resourceId) && resourceId > 0 ? [resourceId] : undefined,
    limit: 20,
    minScore: 0.02,
  });
  return json({ chunks, citations: citationsFrom(chunks) });
});

resources.get('/resources/:id', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const row = await c.env.DB.prepare('SELECT * FROM resources WHERE id = ? AND user_id = ?')
    .bind(id, userId)
    .first<Record<string, unknown>>();
  if (!row) return notFound('Resource not found.');
  const { results: chunks } = await c.env.DB.prepare(
    'SELECT id, page, text FROM resource_chunks WHERE resource_id = ? AND user_id = ? ORDER BY page, id LIMIT 40',
  )
    .bind(id, userId)
    .all<{ id: number; page: number; text: string }>();
  const { results: insights } = await c.env.DB.prepare(
    'SELECT kind, payload, created_at FROM resource_insights WHERE resource_id = ? AND user_id = ? ORDER BY id DESC LIMIT 12',
  )
    .bind(id, userId)
    .all<{ kind: string; payload: string; created_at: string }>();
  return json({
    resource: mapResource(row),
    chunks: (chunks ?? []).map((ch) => ({
      id: ch.id,
      resourceId: id,
      resourceName: String(row.name),
      page: ch.page,
      text: ch.text,
    })),
    insights: (insights ?? []).map((i) => ({ kind: i.kind, payload: parseJSON(i.payload, null), createdAt: i.created_at })),
  });
});

resources.delete('/resources/:id', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const owned = await c.env.DB.prepare('SELECT id FROM resources WHERE id = ? AND user_id = ?').bind(id, userId).first();
  if (!owned) return notFound('Resource not found.');
  await c.env.DB.batch([
    c.env.DB.prepare('DELETE FROM resource_chunks WHERE resource_id = ? AND user_id = ?').bind(id, userId),
    c.env.DB.prepare('DELETE FROM resource_insights WHERE resource_id = ? AND user_id = ?').bind(id, userId),
    c.env.DB.prepare('DELETE FROM resources WHERE id = ? AND user_id = ?').bind(id, userId),
  ]);
  if (c.env.FILES) {
    const listed = await c.env.FILES.list({ prefix: `users/${userId}/resources/${id}/` });
    for (const obj of listed.objects) await c.env.FILES.delete(obj.key);
  }
  return json({ ok: true });
});

function documentText(chunks: { page: number; text: string }[], limit = 22000): string {
  let out = '';
  for (const chunk of chunks) {
    const entry = `--- page ${chunk.page} ---\n${chunk.text}\n`;
    if (out.length + entry.length > limit) break;
    out += entry;
  }
  return out;
}

/** AI analysis of a processed resource: summary, formulas, questions, chapter map. */
resources.post('/resources/:id/analyze', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const kind = str(body.kind, 30) || 'summary';
  if (!['summary', 'formulas', 'questions', 'topics'].includes(kind)) return badRequest('Unknown analysis type.', 'invalid_kind');

  const resource = await c.env.DB.prepare('SELECT * FROM resources WHERE id = ? AND user_id = ?')
    .bind(id, userId)
    .first<Record<string, unknown>>();
  if (!resource) return notFound('Resource not found.');
  if (String(resource.status) !== 'ready') return badRequest('This document has not been processed successfully yet.', 'not_ready');
  if (!aiEnabled(c.env)) {
    return json(
      { error: 'Document analysis needs OPENAI_API_KEY to be configured for this project.', code: 'ai_not_configured', setupRequired: true },
      { status: 503 },
    );
  }

  const { results: chunks } = await c.env.DB.prepare(
    'SELECT page, text FROM resource_chunks WHERE resource_id = ? AND user_id = ? ORDER BY id LIMIT 200',
  )
    .bind(id, userId)
    .all<{ page: number; text: string }>();
  const text = documentText(chunks ?? []);
  const profile = await getProfile(c.env.DB, userId);

  const instructions: Record<string, string> = {
    summary:
      'Return JSON with keys: overview (string, 4-6 sentences), keyConcepts (string[]), formulas (array of {name, expression, whereUsed}), definitions (array of {term, definition}), importantQuestions (array of {question, marks, page}), chapters (array of {name, pageStart, pageEnd}). Every page must come from the markers in the text.',
    formulas:
      'Return JSON with key formulas: array of {name, expression, whereUsed, page}. Only formulas that literally appear in the text.',
    questions:
      'Return JSON with key questions: array of 10 items {prompt, type (mcq|short-answer|numerical), difficulty (easy|medium|hard), marks, options (array of {key,text} for mcq else null), correct (array of option keys or []), numericAnswer (string or null), solution, page}. Questions must be answerable only from the supplied text; include the page for each.',
    topics:
      'Return JSON with keys: chapters (array of {name, pageStart, pageEnd}), topics (array of {name, chapter}), gaps (string[] describing topics the document does not cover).',
  };

  try {
    const result = await aiJSON<Record<string, unknown>>(
      c.env,
      [
        {
          role: 'system',
          content:
            'You analyse a student\'s own study material. Use ONLY the supplied document text. Never add content that is not present, and never invent page numbers. If a requested item is missing from the text, omit it. Return JSON only.',
        },
        {
          role: 'user',
          content: `Document: "${resource.name}" (${resource.page_count} pages). Student context:\n${profileContext(profile as unknown as Record<string, unknown> | null)}\n\n${instructions[kind]}\n\nDOCUMENT TEXT:\n${text}`,
        },
      ],
      { temperature: 0.2, maxTokens: 3200 },
    );

    await c.env.DB.prepare(
      'INSERT INTO resource_insights (resource_id, user_id, kind, payload, created_at) VALUES (?, ?, ?, ?, ?)',
    )
      .bind(id, userId, kind, JSON.stringify(result), nowISO())
      .run();

    if (kind === 'summary' && typeof result.overview === 'string') {
      await c.env.DB.prepare('UPDATE resources SET summary = ? WHERE id = ? AND user_id = ?')
        .bind(String(result.overview).slice(0, 1200), id, userId)
        .run();
    }
    if ((kind === 'topics' || kind === 'summary') && Array.isArray(result.chapters)) {
      const names = (result.chapters as { name?: string }[]).map((ch) => str(ch?.name, 120)).filter(Boolean).slice(0, 40);
      if (names.length) {
        await c.env.DB.prepare('UPDATE resources SET chapters = ? WHERE id = ? AND user_id = ?')
          .bind(JSON.stringify(names), id, userId)
          .run();
      }
    }
    if (kind === 'questions' && Array.isArray(result.questions)) {
      const statements = (result.questions as Record<string, unknown>[])
        .map((q) => normalizeResourceQuestion(q, String(resource.name), id, userId))
        .filter((q): q is NonNullable<typeof q> => Boolean(q))
        .map((q) =>
          c.env.DB.prepare(
            `INSERT INTO questions (user_id, subject, chapter, topic, type, difficulty, prompt, options, correct, numeric_answer, marks, negative, solution, source, source_label, verified, resource_id, resource_pages, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 'resource', ?, 0, ?, ?, ?)`,
          ).bind(
            userId,
            q.subject,
            q.chapter,
            q.topic,
            q.type,
            q.difficulty,
            q.prompt,
            q.options ? JSON.stringify(q.options) : null,
            JSON.stringify(q.correct),
            q.numericAnswer,
            q.marks,
            q.solution,
            `From "${resource.name}"`,
            id,
            q.page,
            nowISO(),
          ),
        );
      for (let i = 0; i < statements.length; i += 30) await c.env.DB.batch(statements.slice(i, i + 30));
      (result as Record<string, unknown>).savedQuestionCount = statements.length;
    }

    return json({ insight: { kind, payload: result, createdAt: nowISO() } });
  } catch (err) {
    if (err instanceof AIError) {
      return json({ error: err.message, code: 'ai_error', setupRequired: err.setupRequired }, { status: err.status });
    }
    throw err;
  }
});

function normalizeResourceQuestion(
  q: Record<string, unknown>,
  name: string,
  resourceId: number,
  userId: number,
): {
  subject: string; chapter: string; topic: string; type: string; difficulty: string; prompt: string;
  options: { key: string; text: string }[] | null; correct: string[]; numericAnswer: string | null; marks: number;
  solution: string; page: string | null;
} | null {
  const prompt = str(q.prompt, 4000);
  if (prompt.length < 8) return null;
  const type = ['mcq', 'short-answer', 'numerical', 'integer', 'long-answer', 'assertion-reason', 'case-based', 'competency', 'multiple-correct'].includes(str(q.type, 30))
    ? str(q.type, 30)
    : 'short-answer';
  const difficulty = ['easy', 'medium', 'hard', 'advanced'].includes(str(q.difficulty, 20)) ? str(q.difficulty, 20) : 'medium';
  const options = Array.isArray(q.options)
    ? (q.options as Record<string, unknown>[]).map((o) => ({ key: str(o.key, 3), text: str(o.text, 800) })).filter((o) => o.key && o.text).slice(0, 6)
    : null;
  const correct = Array.isArray(q.correct) ? (q.correct as unknown[]).map((v) => str(v, 200)).filter(Boolean) : [];
  return {
    subject: str(q.subject, 60) || 'General',
    chapter: str(q.chapter, 120) || name.slice(0, 100),
    topic: str(q.topic, 120) || name.slice(0, 100),
    type,
    difficulty,
    prompt,
    options: options && options.length >= 2 ? options : null,
    correct,
    numericAnswer: q.numericAnswer == null ? null : str(q.numericAnswer, 60),
    marks: num(q.marks, 1, 1, 10),
    solution: str(q.solution, 5000) || 'Solution not provided by the source document; review the referenced page.',
    page: q.page == null ? null : `p. ${num(q.page, 0, 0, 5000)}`,
  };
}


export default resources;
