import { Hono } from 'hono';
import type { AppEnv } from '../lib';
import { badRequest, json, notFound, nowISO, num, parseJSON, str } from '../lib';
import { requireAuth } from '../auth';
import { aiEnabled, aiText, AIError, cleanAIText, profileContext } from '../ai';
import { buildContextBlock, citationsFrom, retrieve } from '../rag';
import { getProfile } from '../store';

const teacher = new Hono<AppEnv>();
teacher.use('*', requireAuth);

const MODE_GUIDE: Record<string, string> = {
  beginner:
    'BEGINNER MODE: Assume no prior knowledge. Build the idea from first principles using everyday analogies, then a simple worked example, then a slightly harder one. Avoid jargon until you define it. Never skip steps.',
  exam:
    'EXAM MODE: Teach to the examination. State exactly what the syllabus expects, the marks typically attached, the wording examiners use, common traps, and a model answer structure. Prioritise scoring technique and time management over exotic theory.',
  advanced:
    'ADVANCED MODE: Assume solid fundamentals. Go deep: derive results, discuss assumptions and edge cases, connect multiple concepts, and finish with a multi-step JEE Advanced-level application. Do not pad with basics.',
};

function systemPrompt(mode: string, profileContextText: string, examLabel: string, subject: string, chapter: string, hasContext: boolean): string {
  return [
    'You are EduMentor AI, an expert personal academic tutor for Indian school and competitive examinations.',
    `The student is preparing for: ${examLabel}.${subject ? ` Subject: ${subject}.` : ''}${chapter ? ` Chapter: ${chapter}.` : ''}`,
    MODE_GUIDE[mode] ?? MODE_GUIDE.beginner,
    'STUDENT PROFILE:',
    profileContextText,
    'RULES:',
    '- Be a teacher, not an answer machine: explain the reasoning, then check understanding by ending with one short verification question.',
    '- Use Markdown with short paragraphs, numbered steps and LaTeX inside $...$ for mathematics.',
    '- Never invent formulas, definitions, page numbers or claims about the student\'s books.',
    hasContext
      ? '- The student supplied document excerpts below. Use them when relevant, cite them inline as [1], [2] matching the excerpt numbers, and say plainly if the excerpts do not cover the question.'
      : '- The student has no retrieved document excerpts for this question. If they ask what their book says, tell them to upload the material rather than guessing.',
    '- If a question is outside the selected syllabus, say so briefly and connect it to what is in scope.',
    '- Keep the reply focused: 250-500 words unless the student asks for a long derivation.',
  ].join('\n');
}

teacher.get('/teacher/chats', async (c) => {
  const kind = str(c.req.query('kind'), 20) || 'teach';
  const { results } = await c.env.DB.prepare(
    `SELECT id, title, mode, subject, chapter, kind, updated_at FROM chats
     WHERE user_id = ? AND kind = ? ORDER BY updated_at DESC LIMIT 50`,
  )
    .bind(c.get('userId'), kind)
    .all<Record<string, unknown>>();
  return json({
    chats: (results ?? []).map((r) => ({
      id: Number(r.id),
      title: String(r.title),
      mode: String(r.mode),
      subject: (r.subject as string) ?? null,
      chapter: (r.chapter as string) ?? null,
      kind: String(r.kind),
      updatedAt: String(r.updated_at),
    })),
  });
});

teacher.post('/teacher/chats', async (c) => {
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const mode = ['beginner', 'exam', 'advanced'].includes(str(body.mode, 20)) ? str(body.mode, 20) : 'beginner';
  const subject = str(body.subject, 60) || null;
  const chapter = str(body.chapter, 120) || null;
  const kind = ['teach', 'doubt'].includes(str(body.kind, 20)) ? str(body.kind, 20) : 'teach';
  const title = str(body.title, 120) || (chapter ? `${chapter}` : kind === 'doubt' ? 'New doubt' : 'New lesson');
  const ts = nowISO();
  const res = await c.env.DB.prepare(
    'INSERT INTO chats (user_id, title, mode, subject, chapter, kind, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
  )
    .bind(c.get('userId'), title, mode, subject, chapter, kind, ts, ts)
    .run();
  return json({
    chat: { id: Number(res.meta.last_row_id), title, mode, subject, chapter, kind, updatedAt: ts },
  });
});

teacher.get('/teacher/chats/:id', async (c) => {
  const chatId = Number(c.req.param('id'));
  const chat = await c.env.DB.prepare('SELECT * FROM chats WHERE id = ? AND user_id = ?')
    .bind(chatId, c.get('userId'))
    .first<Record<string, unknown>>();
  if (!chat) return notFound('Conversation not found.');
  const { results } = await c.env.DB.prepare(
    'SELECT id, role, content, citations, created_at FROM messages WHERE chat_id = ? AND user_id = ? ORDER BY id',
  )
    .bind(chatId, c.get('userId'))
    .all<Record<string, unknown>>();
  return json({
    chat: {
      id: Number(chat.id),
      title: String(chat.title),
      mode: String(chat.mode),
      subject: (chat.subject as string) ?? null,
      chapter: (chat.chapter as string) ?? null,
      kind: String(chat.kind),
      updatedAt: String(chat.updated_at),
    },
    messages: (results ?? []).map((m) => ({
      id: Number(m.id),
      role: String(m.role),
      content: String(m.content),
      citations: parseJSON(m.citations, []),
      createdAt: String(m.created_at),
    })),
  });
});

teacher.delete('/teacher/chats/:id', async (c) => {
  const chatId = Number(c.req.param('id'));
  const userId = c.get('userId');
  await c.env.DB.batch([
    c.env.DB.prepare('DELETE FROM messages WHERE chat_id = ? AND user_id = ?').bind(chatId, userId),
    c.env.DB.prepare('DELETE FROM chats WHERE id = ? AND user_id = ?').bind(chatId, userId),
  ]);
  return json({ ok: true });
});

teacher.post('/teacher/chats/:id/messages', async (c) => {
  const userId = c.get('userId');
  const chatId = Number(c.req.param('id'));
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const content = str(body.content, 6000);
  if (content.length < 2) return badRequest('Write a question or topic first.', 'empty_message');

  const chat = await c.env.DB.prepare('SELECT * FROM chats WHERE id = ? AND user_id = ?')
    .bind(chatId, userId)
    .first<Record<string, unknown>>();
  if (!chat) return notFound('Conversation not found.');

  const mode = ['beginner', 'exam', 'advanced'].includes(str(body.mode, 20)) ? str(body.mode, 20) : String(chat.mode);
  const subject = str(body.subject, 60) || String(chat.subject ?? '');
  const chapter = str(body.chapter, 120) || String(chat.chapter ?? '');
  const resourceIds = Array.isArray(body.resourceIds) ? (body.resourceIds as unknown[]).map(Number).filter(Number.isFinite) : [];
  const profile = await getProfile(c.env.DB, userId);

  if (!aiEnabled(c.env)) {
    return json(
      {
        error: 'The AI tutor is not configured yet. Add OPENAI_API_KEY to this project (Settings → Secrets), then reload.',
        code: 'ai_not_configured',
        setupRequired: true,
      },
      { status: 503 },
    );
  }

  const history = (
    await c.env.DB.prepare(
      'SELECT role, content FROM messages WHERE chat_id = ? AND user_id = ? ORDER BY id DESC LIMIT 8',
    )
      .bind(chatId, userId)
      .all<{ role: string; content: string }>()
  ).results ?? [];

  const retrieved = await retrieve(c.env.DB, userId, content, { resourceIds: resourceIds.length ? resourceIds : undefined, limit: 6 });
  const contextBlock = buildContextBlock(retrieved);

  const messages = [
    {
      role: 'system' as const,
      content: systemPrompt(
        mode,
        profileContext(profile as unknown as Record<string, unknown> | null),
        profile?.examLabel ?? 'CBSE/JEE',
        subject,
        chapter,
        Boolean(contextBlock),
      ),
    },
    ...[...history].reverse().map((m) => ({ role: m.role === 'assistant' ? ('assistant' as const) : ('user' as const), content: m.content })),
  ];

  if (contextBlock) {
    messages.push({
      role: 'user' as const,
      content: `Retrieved excerpts from the student's uploaded documents (cite as [n] with document name and page):\n\n${contextBlock}`,
    });
  }
  messages.push({ role: 'user' as const, content });

  let reply: string;
  try {
    reply = cleanAIText(
      await aiText(c.env, messages, { temperature: mode === 'advanced' ? 0.3 : 0.5, maxTokens: 2200 }),
    );
  } catch (err) {
    if (err instanceof AIError) {
      return json({ error: err.message, code: 'ai_error', setupRequired: err.setupRequired }, { status: err.status });
    }
    throw err;
  }

  const citations = citationsFrom(retrieved);
  const ts = nowISO();
  await c.env.DB.prepare(
    'INSERT INTO messages (chat_id, user_id, role, content, citations, created_at) VALUES (?, ?, ?, ?, ?, ?)',
  )
    .bind(chatId, userId, 'user', content, '[]', ts)
    .run();
  const inserted = await c.env.DB.prepare(
    'INSERT INTO messages (chat_id, user_id, role, content, citations, created_at) VALUES (?, ?, ?, ?, ?, ?)',
  )
    .bind(chatId, userId, 'assistant', reply, JSON.stringify(citations), nowISO())
    .run();

  const titleUpdate = String(chat.title) === 'New lesson' || String(chat.title) === 'New doubt'
    ? content.slice(0, 70)
    : String(chat.title);
  await c.env.DB.prepare('UPDATE chats SET updated_at = ?, title = ?, mode = ? WHERE id = ? AND user_id = ?')
    .bind(nowISO(), titleUpdate, mode, chatId, userId)
    .run();

  return json({
    userMessage: { role: 'user', content, createdAt: ts },
    assistantMessage: {
      id: Number(inserted.meta.last_row_id),
      role: 'assistant',
      content: reply,
      citations,
      createdAt: nowISO(),
    },
  });
});

/** Dedicated doubt solver: one-shot, no chat session required. */
teacher.post('/doubts', async (c) => {
  const userId = c.get('userId');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const question = str(body.question, 6000);
  if (question.length < 3) return badRequest('Describe your doubt first.', 'empty_doubt');
  if (!aiEnabled(c.env)) {
    return json(
      { error: 'The doubt solver needs OPENAI_API_KEY to be configured for this project.', code: 'ai_not_configured', setupRequired: true },
      { status: 503 },
    );
  }

  const subject = str(body.subject, 60);
  const chapter = str(body.chapter, 120);
  const level = str(body.level, 30) || 'exam';
  const resourceIds = Array.isArray(body.resourceIds) ? (body.resourceIds as unknown[]).map(Number).filter(Number.isFinite) : [];
  const profile = await getProfile(c.env.DB, userId);
  const retrieved = await retrieve(c.env.DB, userId, `${question} ${subject} ${chapter}`, {
    resourceIds: resourceIds.length ? resourceIds : undefined,
    limit: 5,
  });
  const contextBlock = buildContextBlock(retrieved);

  const prompt = [
    `Subject: ${subject || 'not specified'}; Chapter: ${chapter || 'not specified'}.`,
    MODE_GUIDE[level] ?? MODE_GUIDE.exam,
    'Answer this doubt. First name the underlying concept in one line, then solve step by step, then give the final answer clearly, then state the most likely mistake a student makes here. Use $...$ for maths.',
    contextBlock ? `\nRelevant excerpts from the student's uploaded documents:\n${contextBlock}` : '',
    `\nStudent's doubt:\n${question}`,
  ].join('\n');

  let answer: string;
  try {
    answer = cleanAIText(
      await aiText(
        c.env,
        [
          {
            role: 'system',
            content: `You are EduMentor AI, a precise doubt-solving tutor for ${profile?.examLabel ?? 'CBSE/JEE'} students. Never invent textbook page references.`,
          },
          { role: 'user', content: prompt },
        ],
        { temperature: 0.25, maxTokens: 2200 },
      ),
    );
  } catch (err) {
    if (err instanceof AIError) return json({ error: err.message, code: 'ai_error', setupRequired: err.setupRequired }, { status: err.status });
    throw err;
  }

  const citations = citationsFrom(retrieved);
  const res = await c.env.DB.prepare(
    'INSERT INTO doubts (user_id, question, subject, answer, citations, created_at) VALUES (?, ?, ?, ?, ?, ?)',
  )
    .bind(userId, question, subject, answer, JSON.stringify(citations), nowISO())
    .run();

  return json({ doubt: { id: Number(res.meta.last_row_id), question, subject, answer, citations, createdAt: nowISO() } });
});

teacher.get('/doubts', async (c) => {
  const { results } = await c.env.DB.prepare(
    'SELECT id, question, subject, answer, citations, created_at FROM doubts WHERE user_id = ? ORDER BY id DESC LIMIT 50',
  )
    .bind(c.get('userId'))
    .all<Record<string, unknown>>();
  return json({
    doubts: (results ?? []).map((d) => ({
      id: Number(d.id),
      question: String(d.question),
      subject: (d.subject as string) ?? null,
      answer: String(d.answer ?? ''),
      citations: parseJSON(d.citations, []),
      createdAt: String(d.created_at),
    })),
  });
});

teacher.post('/study-sessions', async (c) => {
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const minutes = num(body.minutes, 0, 1, 600);
  if (!minutes) return badRequest('Session length must be at least one minute.', 'invalid_minutes');
  const subject = str(body.subject, 60) || null;
  const chapter = str(body.chapter, 120) || null;
  const source = ['timer', 'manual', 'schedule', 'test'].includes(str(body.source, 20)) ? str(body.source, 20) : 'timer';
  await c.env.DB.prepare(
    'INSERT INTO study_sessions (user_id, date, minutes, subject, chapter, source, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
  )
    .bind(c.get('userId'), new Date().toISOString().slice(0, 10), Math.round(minutes), subject, chapter, source, nowISO())
    .run();
  return json({ ok: true, minutes: Math.round(minutes) });
});

export default teacher;
