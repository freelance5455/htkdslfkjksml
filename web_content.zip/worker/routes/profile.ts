import { Hono } from 'hono';
import type { ExamId, StudentProfile } from '../../shared/types';
import { EXAM_PATTERNS } from '../../shared/exam';
import { chaptersFor, subjectsForExam } from '../../shared/syllabus';
import { addDays, badRequest, json, num, nowISO, str, todayISO, clamp } from '../lib';
import { requireAuth } from '../auth';
import { getProfile, listProgress, nextSchedule, saveProfile, seedChapters } from '../store';

const profileRoutes = new Hono<AppEnv>();
profileRoutes.use('*', requireAuth);

import type { AppEnv } from '../lib';

const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

profileRoutes.get('/profile', async (c) => {
  const profile = await getProfile(c.env.DB, c.get('userId'));
  return json({ profile });
});

profileRoutes.put('/profile', async (c) => {
  const userId = c.get('userId');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const existing = await getProfile(c.env.DB, userId);

  const exam = str(body.exam, 30) as ExamId;
  if (!EXAM_PATTERNS[exam]) return badRequest('Choose a valid target examination.', 'invalid_exam');

  const name = str(body.name, 80) || existing?.name || c.get('name');
  if (name.length < 2) return badRequest('Please enter the student name.', 'invalid_name');

  const examDate = str(body.examDate, 10);
  if (examDate && !/^\d{4}-\d{2}-\d{2}$/.test(examDate)) return badRequest('Exam date must be a valid date.', 'invalid_date');

  const subjects = Array.isArray(body.subjects)
    ? (body.subjects as unknown[]).map((s) => str(s, 60)).filter(Boolean).slice(0, 12)
    : [];
  const validSubjects = subjects.length ? subjects : subjectsForExam(exam, str(body.classLevel, 20));

  const time = (v: unknown, fallback: string) => {
    const s = str(v, 5);
    return TIME_RE.test(s) ? s : fallback;
  };
  const weak = Array.isArray(body.weakSubjects)
    ? (body.weakSubjects as unknown[]).map((s) => str(s, 60)).filter((s) => validSubjects.includes(s))
    : [];
  const strong = Array.isArray(body.strongSubjects)
    ? (body.strongSubjects as unknown[]).map((s) => str(s, 60)).filter((s) => validSubjects.includes(s) && !weak.includes(s))
    : [];

  const dailyHours = num(body.dailyHours, 3, 1, 16);
  const sleepAt = time(body.sleepAt, '23:00');
  const wakeAt = time(body.wakeAt, '06:30');
  const sleepHours = sleepDuration(sleepAt, wakeAt);
  if (sleepHours < 6) {
    return badRequest(
      `Your sleep window is only ${sleepHours.toFixed(1)} hours. EduMentor will not build a plan on under 6 hours of sleep — adjust your sleep or wake time.`,
      'insufficient_sleep',
    );
  }

  const profile: StudentProfile = {
    userId,
    name,
    email: str(body.email, 160) || existing?.email || c.get('email'),
    exam,
    examLabel: EXAM_PATTERNS[exam].label,
    examDate: examDate || null,
    classLevel: str(body.classLevel, 20) || existing?.classLevel || '10',
    board: str(body.board, 40) || 'CBSE',
    targetScore: str(body.targetScore, 60),
    dailyHours,
    schoolStart: TIME_RE.test(str(body.schoolStart, 5)) ? str(body.schoolStart, 5) : null,
    schoolEnd: TIME_RE.test(str(body.schoolEnd, 5)) ? str(body.schoolEnd, 5) : null,
    coachingStart: TIME_RE.test(str(body.coachingStart, 5)) ? str(body.coachingStart, 5) : null,
    coachingEnd: TIME_RE.test(str(body.coachingEnd, 5)) ? str(body.coachingEnd, 5) : null,
    sleepAt,
    wakeAt,
    preferredStart: time(body.preferredStart, '17:00'),
    preferredEnd: time(body.preferredEnd, '21:00'),
    subjects: validSubjects,
    weakSubjects: weak,
    strongSubjects: strong,
    learningStyle: str(body.learningStyle, 120) || 'Balanced — explanations, practice and visual examples',
    currentPerformance: str(body.currentPerformance, 300),
    commitments: str(body.commitments, 300),
    onboarded: true,
    createdAt: existing?.createdAt ?? nowISO(),
  };

  await saveProfile(c.env.DB, userId, profile);
  await seedChapters(
    c.env.DB,
    userId,
    validSubjects.flatMap((s) => chaptersFor(exam, s).map((chapter) => ({ subject: s, chapter }))),
  );

  return json({ profile });
});

function sleepDuration(sleepAt: string, wakeAt: string): number {
  const [sh, sm] = sleepAt.split(':').map(Number);
  const [wh, wm] = wakeAt.split(':').map(Number);
  const start = sh * 60 + sm;
  const end = wh * 60 + wm;
  const diff = end >= start ? end - start : 1440 - start + end;
  return diff / 60;
}

profileRoutes.get('/syllabus', async (c) => {
  const exam = (str(c.req.query('exam'), 30) || 'cbse10') as ExamId;
  const subjects = subjectsForExam(exam);
  return json({
    exam,
    subjects: subjects.map((name) => ({ name, chapters: chaptersFor(exam, name) })),
  });
});

profileRoutes.get('/progress', async (c) => {
  const progress = await listProgress(c.env.DB, c.get('userId'));
  return json({ progress });
});

profileRoutes.patch('/progress', async (c) => {
  const userId = c.get('userId');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const subject = str(body.subject, 60);
  const chapter = str(body.chapter, 120);
  if (!subject || !chapter) return badRequest('Subject and chapter are required.', 'missing_fields');

  const existing = await c.env.DB.prepare(
    'SELECT * FROM chapter_progress WHERE user_id = ? AND subject = ? AND chapter = ?',
  )
    .bind(userId, subject, chapter)
    .first<Record<string, unknown>>();

  const requested = str(body.status, 20) || (existing?.status as string) || 'learning';
  const status = ['not-started', 'learning', 'revising', 'confident'].includes(requested) ? requested : 'learning';
  const ts = nowISO();

  if (!existing) {
    await c.env.DB.prepare(
      `INSERT INTO chapter_progress (user_id, subject, chapter, status, mastery, last_studied, next_review, interval_days, ease, repetitions, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, 2.5, 0, ?)`,
    )
      .bind(userId, subject, chapter, status, status === 'confident' ? 0.85 : 0.25, todayISO(), addDays(todayISO(), 1), ts)
      .run();
  } else {
    const baseMastery = Number(existing.mastery ?? 0);
    const mastery = clamp(
      typeof body.mastery === 'number' ? (body.mastery as number) : status === 'confident' ? 0.9 : status === 'revising' ? Math.max(baseMastery, 0.6) : status === 'learning' ? Math.max(baseMastery, 0.3) : 0,
      0,
      1,
    );
    const schedule = nextSchedule(
      {
        ease: Number(existing.ease ?? 2.5),
        intervalDays: Number(existing.interval_days ?? 1),
        repetitions: Number(existing.repetitions ?? 0),
      },
      mastery >= 0.85 ? 3 : mastery >= 0.6 ? 2 : 0,
    );
    await c.env.DB.prepare(
      `UPDATE chapter_progress SET status = ?, mastery = ?, last_studied = ?, next_review = ?, interval_days = ?, ease = ?, repetitions = ?, updated_at = ?
       WHERE user_id = ? AND subject = ? AND chapter = ?`,
    )
      .bind(status, mastery, status === 'not-started' ? existing.last_studied ?? null : todayISO(), schedule.due, schedule.intervalDays, schedule.ease, status === 'not-started' ? 0 : (existing.repetitions as number ?? 0) + 1, ts, userId, subject, chapter)
      .run();
  }

  const progress = await c.env.DB.prepare(
    'SELECT id, subject, chapter, status, mastery, last_studied, next_review, interval_days, ease, repetitions FROM chapter_progress WHERE user_id = ? AND subject = ? AND chapter = ?',
  )
    .bind(userId, subject, chapter)
    .first();
  return json({ progress });
});

export default profileRoutes;
