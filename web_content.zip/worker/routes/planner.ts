import { Hono } from 'hono';
import type { AppEnv } from '../lib';
import { addDays, badRequest, json, notFound, nowISO, num, str, todayISO } from '../lib';
import { requireAuth } from '../auth';
import { EXAM_PATTERNS } from '../../shared/exam';
import { chaptersFor } from '../../shared/syllabus';
import { addMinutesToTime, getProfile, listProgress, mapScheduleRow, minutesBetweenTimes, recordStudy } from '../store';

const planner = new Hono<AppEnv>();
planner.use('*', requireAuth);

interface ItemDraft {
  date: string;
  start: string;
  end: string;
  title: string;
  kind: 'learn' | 'revise' | 'practice' | 'mock' | 'break';
  subject: string | null;
  chapter: string | null;
  priority: number;
  notes?: string;
}

const toMinutes = (t: string) => {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
};
const toTime = (m: number) => `${String(Math.floor((m % 1440) / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;

/**
 * Adaptive planner.
 *
 * Builds real sessions from the student's constraints: fixed school/coaching
 * blocks, sleep window, daily hour budget, weak chapters, spaced repetition due
 * dates and exam proximity. No AI is needed for the schedule itself, so the
 * plan is deterministic, explainable and always respects sleep.
 */
planner.post('/planner/generate', async (c) => {
  const userId = c.get('userId');
  const profile = await getProfile(c.env.DB, userId);
  if (!profile) return badRequest('Complete onboarding before generating a study plan.', 'no_profile');

  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const days = Math.round(num(body.days, 7, 1, 30));
  const startDate = /^\d{4}-\d{2}-\d{2}$/.test(str(body.startDate, 10)) ? str(body.startDate, 10) : todayISO();
  const focus = Array.isArray(body.focusSubjects)
    ? (body.focusSubjects as unknown[]).map((s) => str(s, 60)).filter(Boolean)
    : [];
  if (!profile.subjects.length) return badRequest('Add subjects in your profile first.', 'no_subjects');

  const progress = await listProgress(c.env.DB, userId);
  const examDate = profile.examDate;
  const pattern = EXAM_PATTERNS[profile.exam];
  const sleepStart = toMinutes(profile.sleepAt || '23:00');
  const wakeAt = toMinutes(profile.wakeAt || '06:30');

  // Clear only future pending sessions from previous plans; history is preserved.
  await c.env.DB.prepare(
    "DELETE FROM schedule_items WHERE user_id = ? AND date >= ? AND status = 'pending' AND plan_id IS NOT NULL",
  )
    .bind(userId, startDate)
    .run();

  const plan = await c.env.DB.prepare(
    'INSERT INTO plans (user_id, title, start_date, end_date, config, created_at) VALUES (?, ?, ?, ?, ?, ?)',
  )
    .bind(
      userId,
      `${profile.examLabel} plan · ${startDate} → ${addDays(startDate, days - 1)}`,
      startDate,
      addDays(startDate, days - 1),
      JSON.stringify({ days, focus }),
      nowISO(),
    )
    .run();
  const planId = Number(plan.meta.last_row_id);

  const fixedBlocks: { start: number; end: number; label: string; kind: 'school' | 'coaching' }[] = [];
  if (profile.schoolStart && profile.schoolEnd) {
    fixedBlocks.push({ start: toMinutes(profile.schoolStart), end: toMinutes(profile.schoolEnd), label: 'School', kind: 'school' });
  }
  if (profile.coachingStart && profile.coachingEnd) {
    fixedBlocks.push({ start: toMinutes(profile.coachingStart), end: toMinutes(profile.coachingEnd), label: 'Coaching', kind: 'coaching' });
  }

  const items: ItemDraft[] = [];
  const dailyBudget = Math.round((profile.dailyHours || 3) * 60);
  const blockLength = dailyBudget >= 240 ? 55 : 45;
  const breakLength = 10;

  // Candidate chapters ranked by weakness, revision due date and exam proximity.
  const candidates = progress
    .filter((p) => profile.subjects.includes(p.subject))
    .map((p) => {
      const overdue = p.nextReview && p.nextReview <= addDays(startDate, days) ? 1 : 0;
      const weakness = 1 - p.mastery;
      const focusBoost = focus.includes(p.subject) ? 0.25 : 0;
      const priority = weakness * 2 + overdue * 0.9 + focusBoost + (p.status === 'not-started' ? 0.35 : 0);
      return { ...p, priority };
    })
    .sort((a, b) => b.priority - a.priority);

  if (!candidates.length) {
    for (const subject of profile.subjects) {
      for (const chapter of chaptersFor(profile.exam, subject).slice(0, 6)) {
        candidates.push({
          id: 0, subject, chapter, status: 'not-started', mastery: 0,
          lastStudied: null, nextReview: null, intervalDays: 1, ease: 2.5, repetitions: 0, priority: 1,
        });
      }
    }
  }

  let cursor = 0;
  for (let d = 0; d < days; d++) {
    const date = addDays(startDate, d);
    const weekday = new Date(date + 'T00:00:00Z').getUTCDay();

    // Fixed commitments are shown on the calendar (they do not count as study).
    for (const block of fixedBlocks) {
      items.push({
        date, start: toTime(block.start), end: toTime(block.end), title: block.label,
        kind: block.kind as unknown as ItemDraft['kind'], subject: null, chapter: null, priority: 3,
        notes: 'Fixed commitment',
      });
    }

    // Study window: preferred hours, trimmed to wake/sleep and free time.
    const dayStart = Math.max(wakeAt, toMinutes(profile.preferredStart || '17:00'));
    let dayEnd = Math.min(sleepStart, toMinutes(profile.preferredEnd || '21:30'));
    if (dayEnd - dayStart < 60) dayEnd = Math.min(sleepStart, dayStart + dailyBudget + 30);
    if (weekday === 0 && dayEnd - dayStart < 180) dayEnd = Math.min(sleepStart, dayStart + 240);
    if (dayEnd <= dayStart) continue;

    const free: { start: number; end: number }[] = [];
    let pointer = dayStart;
    for (const block of [...fixedBlocks].sort((a, b) => a.start - b.start)) {
      if (block.end <= dayStart || block.start >= dayEnd) continue;
      if (block.start > pointer) free.push({ start: pointer, end: Math.min(block.start, dayEnd) });
      pointer = Math.max(pointer, block.end);
    }
    if (pointer < dayEnd) free.push({ start: pointer, end: dayEnd });

    let remaining = weekday === 0 ? dailyBudget + 45 : dailyBudget;
    let placed = 0;
    let breakAfter = 0;

    // A weekly full mock keeps exam pacing honest.
    if (weekday === 0 || (weekday === 6 && examDate && daysLeft(examDate, date) <= 30)) {
      const slot = free[0];
      if (slot && slot.end - slot.start >= 90) {
        items.push({
          date, start: toTime(slot.start), end: toTime(Math.min(slot.start + 90, slot.end)),
          title: `${pattern.label} mock test`, kind: 'mock', subject: null, chapter: null, priority: 1,
          notes: 'Full-length timed practice in the Test Centre',
        });
        slot.start = Math.min(slot.start + 100, slot.end);
        remaining -= 100;
      }
    }

    for (const slot of free) {
      let t = slot.start;
      while (t + blockLength <= slot.end && remaining >= blockLength) {
        const candidate = candidates[cursor % candidates.length];
        cursor++;
        const isRevision = candidate.status === 'revising' || candidate.status === 'confident' || (candidate.nextReview !== null && candidate.nextReview <= date);
        const kind: ItemDraft['kind'] = isRevision ? 'revise' : 'learn';
        items.push({
          date,
          start: toTime(t),
          end: toTime(t + blockLength),
          title: `${isRevision ? 'Revise' : 'Learn'} ${candidate.chapter}`,
          kind,
          subject: candidate.subject,
          chapter: candidate.chapter,
          priority: candidate.priority > 1.4 ? 1 : candidate.priority > 0.9 ? 2 : 3,
          notes: isRevision
            ? `Priority: ${candidate.mastery < 0.5 ? 'weak chapter' : 'spaced repetition due'}`
            : `Syllabus gap — ${Math.round(candidate.mastery * 100)}% mastery so far`,
        });
        t += blockLength;
        remaining -= blockLength;
        placed++;
        if (++breakAfter % 2 === 0 && breakLength && t + breakLength <= slot.end && remaining >= breakLength) {
          items.push({
            date, start: toTime(t), end: toTime(t + breakLength), title: 'Break — walk, water, no screen',
            kind: 'break', subject: null, chapter: null, priority: 3,
          });
          t += breakLength;
          remaining -= breakLength;
        }
      }
      if (remaining < blockLength) break;
    }
    if (!placed && weekday !== 0) {
      // Never force study into the last 45 minutes before sleep.
      continue;
    }
  }

  const statements = items.map((item) =>
    c.env.DB.prepare(
      `INSERT INTO schedule_items (user_id, plan_id, date, start_time, end_time, title, kind, subject, chapter, status, priority, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)`,
    ).bind(
      userId, planId, item.date, item.start, item.end, item.title, item.kind, item.subject, item.chapter,
      Math.round(item.priority), item.notes ?? null, nowISO(),
    ),
  );
  for (let i = 0; i < statements.length; i += 40) await c.env.DB.batch(statements.slice(i, i + 40));

  const { results } = await c.env.DB.prepare(
    'SELECT * FROM schedule_items WHERE user_id = ? AND plan_id = ? ORDER BY date, start_time',
  ).bind(userId, planId).all<Record<string, unknown>>();

  return json({
    plan: { id: planId, title: `${profile.examLabel} plan`, startDate, endDate: addDays(startDate, days - 1), days },
    items: (results ?? []).map(mapScheduleRow),
    generated: statements.length,
    note: 'Sessions were scheduled inside your preferred hours, around school/coaching, and before your sleep time.',
  });
});

function daysLeft(examDate: string, from: string): number {
  return Math.round((new Date(examDate + 'T00:00:00Z').getTime() - new Date(from + 'T00:00:00Z').getTime()) / 86400000);
}

planner.get('/planner', async (c) => {
  const userId = c.get('userId');
  const from = /^\d{4}-\d{2}-\d{2}$/.test(str(c.req.query('from'), 10)) ? str(c.req.query('from'), 10) : addDays(todayISO(), -7);
  const to = /^\d{4}-\d{2}-\d{2}$/.test(str(c.req.query('to'), 10)) ? str(c.req.query('to'), 10) : addDays(todayISO(), 21);
  const { results } = await c.env.DB.prepare(
    'SELECT * FROM schedule_items WHERE user_id = ? AND date >= ? AND date <= ? ORDER BY date, start_time',
  ).bind(userId, from, to).all<Record<string, unknown>>();
  const plan = await c.env.DB.prepare('SELECT * FROM plans WHERE user_id = ? ORDER BY id DESC LIMIT 1')
    .bind(userId)
    .first<Record<string, unknown>>();
  return json({
    items: (results ?? []).map(mapScheduleRow),
    plan: plan
      ? { id: Number(plan.id), title: String(plan.title), startDate: String(plan.start_date), endDate: String(plan.end_date) }
      : null,
    from,
    to,
  });
});

planner.patch('/planner/items/:id', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const item = await c.env.DB.prepare('SELECT * FROM schedule_items WHERE id = ? AND user_id = ?')
    .bind(id, userId)
    .first<Record<string, unknown>>();
  if (!item) return notFound('Session not found.');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const status = str(body.status, 20);
  if (!['pending', 'done', 'missed'].includes(status)) return badRequest('Invalid status.', 'invalid_status');

  await c.env.DB.prepare('UPDATE schedule_items SET status = ? WHERE id = ? AND user_id = ?')
    .bind(status, id, userId)
    .run();

  if (status === 'done') {
    const minutes = minutesBetweenTimes(String(item.start_time), String(item.end_time));
    if (item.kind !== 'break' && item.kind !== 'school' && item.kind !== 'coaching') {
      await recordStudy(c.env.DB, userId, minutes, (item.subject as string) ?? null, (item.chapter as string) ?? null, 'schedule');
    }
    if (item.subject && item.chapter) {
      const progress = await c.env.DB.prepare(
        'SELECT * FROM chapter_progress WHERE user_id = ? AND subject = ? AND chapter = ?',
      ).bind(userId, item.subject, item.chapter).first<Record<string, unknown>>();
      if (progress) {
        const mastery = Math.min(1, Number(progress.mastery ?? 0) + 0.05);
        await c.env.DB.prepare(
          `UPDATE chapter_progress SET mastery = ?, status = CASE WHEN ? >= 0.8 THEN 'confident' WHEN status = 'not-started' THEN 'learning' WHEN status = 'confident' THEN 'confident' ELSE 'revising' END,
             last_studied = ?, updated_at = ? WHERE user_id = ? AND subject = ? AND chapter = ?`,
        ).bind(mastery, mastery, todayISO(), nowISO(), userId, String(item.subject), String(item.chapter)).run();
      }
    }
  }

  const updated = await c.env.DB.prepare('SELECT * FROM schedule_items WHERE id = ? AND user_id = ?').bind(id, userId).first<Record<string, unknown>>();
  return json({ item: updated ? mapScheduleRow(updated) : null });
});

/** Moves missed sessions into free upcoming slots instead of rebuilding the plan. */
planner.post('/planner/reschedule', async (c) => {
  const userId = c.get('userId');
  const profile = await getProfile(c.env.DB, userId);
  if (!profile) return badRequest('Complete onboarding first.', 'no_profile');
  const today = todayISO();

  await c.env.DB.prepare(
    "UPDATE schedule_items SET status = 'missed' WHERE user_id = ? AND date < ? AND status = 'pending' AND kind NOT IN ('school','coaching','break')",
  ).bind(userId, today).run();

  const { results: missed } = await c.env.DB.prepare(
    "SELECT * FROM schedule_items WHERE user_id = ? AND status = 'missed' ORDER BY priority, date LIMIT 8",
  ).bind(userId).all<Record<string, unknown>>();
  if (!missed?.length) return json({ moved: 0, items: [] });

  const sleepStart = toMinutes(profile.sleepAt || '23:00');
  const preferredEnd = Math.min(sleepStart, toMinutes(profile.preferredEnd || '21:30'));
  const moved: { from: string; to: string; title: string }[] = [];
  let dayOffset = 0;

  for (const item of missed) {
    let placed = false;
    for (let attempt = 0; attempt < 7 && !placed; attempt++) {
      const date = addDays(today, (dayOffset + attempt) % 7);
      const { results: existing } = await c.env.DB.prepare(
        "SELECT start_time, end_time FROM schedule_items WHERE user_id = ? AND date = ? AND status != 'missed' AND kind != 'break'",
      ).bind(userId, date).all<{ start_time: string; end_time: string }>();
      const busy = (existing ?? []).map((e) => ({ start: toMinutes(e.start_time), end: toMinutes(e.end_time) }));
      const length = Math.max(30, minutesBetweenTimes(String(item.start_time), String(item.end_time)));
      let start = Math.max(toMinutes(profile.preferredStart || '17:00'), toMinutes(profile.wakeAt || '06:30'));
      while (start + length <= preferredEnd) {
        const conflict = busy.some((b) => start < b.end && start + length > b.start);
        if (!conflict) {
          await c.env.DB.prepare(
            `INSERT INTO schedule_items (user_id, plan_id, date, start_time, end_time, title, kind, subject, chapter, status, priority, notes, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)`,
          ).bind(
            userId, item.plan_id ?? null, date, toTime(start), toTime(start + length), String(item.title),
            String(item.kind), item.subject ?? null, item.chapter ?? null, Number(item.priority ?? 2),
            `Rescheduled from ${item.date}`, nowISO(),
          ).run();
          moved.push({ from: String(item.date), to: date, title: String(item.title) });
          placed = true;
          break;
        }
        start += 30;
      }
    }
    if (!placed) dayOffset++;
  }

  return json({ moved: moved.length, items: moved, note: moved.length ? 'Missed sessions were moved into the next free slots; the rest of your plan is unchanged.' : 'No free slots were found in the next week. Consider adjusting your daily hours.' });
});

/* ------------------------------ goals ------------------------------ */

planner.get('/planner/goals', async (c) => {
  const date = /^\d{4}-\d{2}-\d{2}$/.test(str(c.req.query('date'), 10)) ? str(c.req.query('date'), 10) : todayISO();
  const { results } = await c.env.DB.prepare('SELECT * FROM goals WHERE user_id = ? AND date = ? ORDER BY id')
    .bind(c.get('userId'), date)
    .all<Record<string, unknown>>();
  return json({
    goals: (results ?? []).map((g) => ({
      id: Number(g.id), date: String(g.date), minutes: Number(g.minutes), title: (g.title as string) ?? null, status: String(g.status),
    })),
    date,
  });
});

planner.post('/planner/goals', async (c) => {
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const date = /^\d{4}-\d{2}-\d{2}$/.test(str(body.date, 10)) ? str(body.date, 10) : todayISO();
  const minutes = Math.round(num(body.minutes, 60, 10, 720));
  const title = str(body.title, 160) || 'Study session';
  const res = await c.env.DB.prepare(
    'INSERT INTO goals (user_id, date, minutes, title, status, created_at) VALUES (?, ?, ?, ?, \'pending\', ?)',
  ).bind(c.get('userId'), date, minutes, title, nowISO()).run();
  return json({ goal: { id: Number(res.meta.last_row_id), date, minutes, title, status: 'pending' } }, { status: 201 });
});

planner.patch('/planner/goals/:id', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const status = str(body.status, 20) === 'done' ? 'done' : 'pending';
  const goal = await c.env.DB.prepare('SELECT * FROM goals WHERE id = ? AND user_id = ?').bind(id, userId).first<Record<string, unknown>>();
  if (!goal) return notFound('Goal not found.');
  await c.env.DB.prepare('UPDATE goals SET status = ? WHERE id = ? AND user_id = ?').bind(status, id, userId).run();
  if (status === 'done') {
    await recordStudy(c.env.DB, userId, Number(goal.minutes), null, null, 'manual');
  }
  return json({ ok: true, status });
});

export default planner;
