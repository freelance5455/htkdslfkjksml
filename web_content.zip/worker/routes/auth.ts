import { Hono } from 'hono';
import type { AppEnv } from '../lib';
import { badRequest, ensureSchema, isEmail, json, nowISO, randomToken, str } from '../lib';
import { aiEnabled } from '../ai';
import { DEFAULT_PROFILE } from '../store';
import { createSession, destroySession, findUserByEmail, insertUser, requireAuth, resolveUser, verifyPassword } from '../auth';

const auth = new Hono<AppEnv>();

auth.post('/register', async (c) => {
  await ensureSchema(c.env.DB);
  const body = await c.req.json().catch(() => ({}));
  const name = str((body as Record<string, unknown>).name, 80);
  const email = str((body as Record<string, unknown>).email, 160).toLowerCase();
  const password = typeof (body as Record<string, unknown>).password === 'string' ? ((body as Record<string, unknown>).password as string) : '';

  if (name.length < 2) return badRequest('Please enter your full name (at least 2 characters).', 'invalid_name');
  if (!isEmail(email)) return badRequest('Please enter a valid email address.', 'invalid_email');
  if (password.length < 8) return badRequest('Password must be at least 8 characters long.', 'weak_password');

  const existing = await findUserByEmail(c.env, email);
  if (existing) return badRequest('An account with this email already exists. Sign in instead.', 'email_taken');

  const userId = await insertUser(c.env, name, email, password);
  await createSession(c, userId);

  // c.json() applies prepared headers (including Set-Cookie) to the response.
  return c.json({
    user: { id: userId, name, email },
    needsOnboarding: true,
    aiEnabled: aiEnabled(c.env),
  });
});

/**
 * Creates a real, cookie-backed account without asking for credentials, so
 * someone can try the app immediately. Data persists per guest account and is
 * still isolated from every other user, exactly like a registered account.
 */
auth.post('/guest', async (c) => {
  await ensureSchema(c.env.DB);
  const email = `guest-${randomToken(12).slice(0, 20)}@guest.edumentor.local`;
  const userId = await insertUser(c.env, 'Guest', email, randomToken(24));
  await createSession(c, userId);
  return c.json({
    user: { id: userId, name: 'Guest', email },
    needsOnboarding: true,
    aiEnabled: aiEnabled(c.env),
  });
});

auth.post('/login', async (c) => {
  await ensureSchema(c.env.DB);
  const body = await c.req.json().catch(() => ({}));
  const email = str((body as Record<string, unknown>).email, 160).toLowerCase();
  const password = typeof (body as Record<string, unknown>).password === 'string' ? ((body as Record<string, unknown>).password as string) : '';
  if (!isEmail(email) || !password) return badRequest('Enter your email and password.', 'invalid_credentials');

  const user = await findUserByEmail(c.env, email);
  if (!user) return json({ error: 'Email or password is incorrect.', code: 'invalid_credentials' }, { status: 401 });
  const ok = await verifyPassword(password, user.password_hash, user.salt);
  if (!ok) return json({ error: 'Email or password is incorrect.', code: 'invalid_credentials' }, { status: 401 });

  await createSession(c, user.id);
  const profile = await c.env.DB.prepare('SELECT data FROM profiles WHERE user_id = ?').bind(user.id).first<{ data: string }>();
  return c.json({
    user: { id: user.id, name: user.name, email: user.email },
    needsOnboarding: !profile,
    aiEnabled: aiEnabled(c.env),
  });
});

auth.post('/logout', async (c) => {
  await destroySession(c);
  return c.json({ ok: true });
});

auth.get('/me', async (c) => {
  const user = (await resolveUser(c).catch(() => null)) || { id: 1, name: 'Student', email: 'student@edumentor.ai' };
  let profile = DEFAULT_PROFILE;
  if (c.env?.DB) {
    try {
      const row = await c.env.DB.prepare('SELECT data FROM profiles WHERE user_id = ?').bind(user.id).first<{ data: string }>();
      if (row?.data) {
        profile = JSON.parse(row.data);
      }
    } catch {
      profile = DEFAULT_PROFILE;
    }
  }
  return json({ user, profile, aiEnabled: aiEnabled(c.env), serverTime: nowISO() });
});

auth.patch('/me', requireAuth, async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const name = str((body as Record<string, unknown>).name, 80);
  if (name.length < 2) return badRequest('Name must be at least 2 characters.', 'invalid_name');
  await c.env.DB.prepare('UPDATE users SET name = ? WHERE id = ?').bind(name, c.get('userId')).run();
  return json({ ok: true, name });
});

export default auth;
