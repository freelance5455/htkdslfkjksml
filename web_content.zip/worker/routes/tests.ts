import { Hono } from 'hono';
import type { AttemptAnswer, ExamId, QuestionType, TestConfig } from '../../shared/types';
import { EXAM_PATTERNS, isObjective } from '../../shared/exam';
import type { AppEnv } from '../lib';
import { badRequest, json, notFound, nowISO, num, parseJSON, str, todayISO } from '../lib';
import { requireAuth } from '../auth';
import { aiEnabled, aiText, AIError, profileContext } from '../ai';
import { buildContextBlock, retrieve } from '../rag';
import { getProfile, recordStudy } from '../store';
import {
  applyAttemptToProgress, evaluateAttempt, generateWithAI, mapQuestion,
  type SubmissionPayload,
} from '../tests-engine';

const tests = new Hono<AppEnv>();
tests.use('*', requireAuth);

const DEFAULT_TYPES: Record<string, QuestionType[]> = {
  cbse10: ['mcq', 'assertion-reason', 'short-answer', 'case-based'],
  cbse12: ['mcq', 'assertion-reason', 'short-answer', 'case-based', 'long-answer'],
  'jee-main': ['mcq', 'numerical'],
  'jee-advanced': ['mcq', 'multiple-correct', 'integer'],
  custom: ['mcq'],
};

function questionMarksFor(exam: ExamId, type: QuestionType): { marks: number; negative: number } {
  if (exam === 'jee-main') return { marks: 4, negative: 1 };
  if (exam === 'jee-advanced') {
    if (type === 'multiple-correct') return { marks: 4, negative: 2 };
    if (type === 'integer' || type === 'numerical') return { marks: 3, negative: 1 };
    return { marks: 3, negative: 1 };
  }
  return { marks: type === 'long-answer' ? 5 : type === 'case-based' || type === 'competency' ? 4 : type === 'short-answer' ? 2 : 1, negative: 0 };
}

tests.get('/tests', async (c) => {
  const { results } = await c.env.DB.prepare(
    `SELECT t.*, (SELECT COUNT(*) FROM questions q WHERE q.test_id = t.id) AS question_count,
            (SELECT a.id FROM attempts a WHERE a.test_id = t.id AND a.user_id = t.user_id AND a.status = 'submitted' ORDER BY a.id DESC LIMIT 1) AS submitted_attempt_id
     FROM tests t WHERE t.user_id = ? ORDER BY t.id DESC LIMIT 100`,
  )
    .bind(c.get('userId'))
    .all<Record<string, unknown>>();
  return json({
    tests: (results ?? []).map((t) => ({
      id: Number(t.id),
      title: String(t.title),
      exam: String(t.exam),
      durationMinutes: Number(t.duration_minutes),
      totalMarks: Number(t.total_marks),
      status: String(t.status),
      createdAt: String(t.created_at),
      questionCount: Number(t.question_count ?? 0),
      attemptId: t.submitted_attempt_id == null ? null : Number(t.submitted_attempt_id),
      config: parseJSON<TestConfig | null>(t.config, null),
    })),
  });
});

tests.post('/tests', async (c) => {
  const userId = c.get('userId');
  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const exam = str(body.exam, 30) as ExamId;
  if (!EXAM_PATTERNS[exam]) return badRequest('Choose a valid examination pattern.', 'invalid_exam');
  const pattern = EXAM_PATTERNS[exam];

  const subjects = Array.isArray(body.subjects)
    ? (body.subjects as unknown[]).map((s) => str(s, 60)).filter(Boolean).slice(0, 8)
    : pattern.subjects.slice(0, 4);
  if (!subjects.length) return badRequest('Select at least one subject.', 'no_subjects');

  const chapters = Array.isArray(body.chapters)
    ? (body.chapters as unknown[]).map((s) => str(s, 140)).filter(Boolean).slice(0, 40)
    : [];

  const requestedTypes = Array.isArray(body.types)
    ? (body.types as unknown[]).map((t) => str(t, 30)).filter(Boolean)
    : [];
  const allowed = (DEFAULT_TYPES[exam] ?? ['mcq']) as string[];
  const types = (requestedTypes.length ? requestedTypes.filter((t) => allowed.includes(t)) : allowed) as QuestionType[];
  if (!types.length) return badRequest('Select at least one valid question type.', 'no_types');

  const difficulty = ['easy', 'medium', 'hard', 'advanced'].includes(str(body.difficulty, 20)) ? str(body.difficulty, 20) : 'medium';
  const questionCount = Math.round(num(body.questionCount, 10, 1, 60));
  const durationMinutes = Math.round(num(body.durationMinutes, pattern.durationMinutes, 5, 300));
  const negativeMarking = typeof body.negativeMarking === 'boolean' ? body.negativeMarking : pattern.negativeMarking;
  const mode = str(body.mode, 10) === 'ai' ? 'ai' : 'bank';
  const resourceIds = Array.isArray(body.resourceIds) ? (body.resourceIds as unknown[]).map(Number).filter(Number.isFinite) : [];
  const useResources = Boolean(body.useResources);

  if (mode === 'ai' && !aiEnabled(c.env)) {
    return json(
      { error: 'AI question generation needs OPENAI_API_KEY. You can still build tests from the question bank instantly.', code: 'ai_not_configured', setupRequired: true },
      { status: 503 },
    );
  }

  const config: TestConfig = {
    exam, subjects, chapters, types, difficulty: difficulty as TestConfig['difficulty'],
    questionCount, durationMinutes, negativeMarking, useResources, resourceIds,
    generatedBy: mode === 'ai' ? 'ai' : 'bank',
  };
  const title = str(body.title, 140) || `${pattern.label} — ${subjects.join(', ')}${chapters.length === 1 ? ` · ${chapters[0]}` : ''}`;

  const created = await c.env.DB.prepare(
    `INSERT INTO tests (user_id, title, exam, config, duration_minutes, total_marks, status, created_at)
     VALUES (?, ?, ?, ?, ?, 0, 'draft', ?)`,
  )
    .bind(userId, title, exam, JSON.stringify(config), durationMinutes, nowISO())
    .run();
  const testId = Number(created.meta.last_row_id);

  let added = 0;
  let note = '';
  if (mode === 'bank') {
    const filters: string[] = ['(user_id IS NULL OR user_id = ?)', `subject IN (${subjects.map(() => '?').join(',')})`];
    const params: unknown[] = [userId, ...subjects];
    if (chapters.length) {
      filters.push(`chapter IN (${chapters.map(() => '?').join(',')})`);
      params.push(...chapters);
    }
    if (types.length) {
      filters.push(`type IN (${types.map(() => '?').join(',')})`);
      params.push(...types);
    }

    const fetchPool = async () => {
      const { results } = await c.env.DB.prepare(
        `SELECT * FROM questions WHERE ${filters.join(' AND ')} ORDER BY RANDOM() LIMIT 200`,
      )
        .bind(...params)
        .all<Record<string, unknown>>();
      return (results ?? []).map(mapQuestion);
    };

    let pool = await fetchPool();
    let matching = pool.filter((q) => q.difficulty === difficulty);
    if (matching.length < questionCount) {
      const rest = pool.filter((q) => q.difficulty !== difficulty);
      matching = [...matching, ...rest];
    }
    if (matching.length < questionCount) {
      note = `The bank has ${matching.length} question${matching.length === 1 ? '' : 's'} matching this selection, fewer than the ${questionCount} requested. Generate an AI paper for more, or widen the chapter selection.`;
    }

    const selected = matching.slice(0, questionCount);
    const statements = selected.map((q) => {
      const marks = questionMarksFor(exam, q.type);
      return c.env.DB.prepare(
        `INSERT INTO questions (user_id, subject, chapter, topic, type, difficulty, prompt, options, correct, numeric_answer, marks, negative, solution, source, source_label, verified, year, resource_id, resource_pages, test_id, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).bind(
        userId, q.subject, q.chapter, q.topic, q.type, q.difficulty, q.prompt,
        q.options ? JSON.stringify(q.options) : null,
        JSON.stringify(q.correct),
        q.numericAnswer,
        marks.marks,
        negativeMarking ? marks.negative : 0,
        q.solution,
        q.source,
        q.sourceLabel,
        q.verified ? 1 : 0,
        q.year,
        q.resourceId,
        q.resourcePages,
        testId,
        nowISO(),
      );
    });
    for (let i = 0; i < statements.length; i += 40) await c.env.DB.batch(statements.slice(i, i + 40));
    added = selected.length;
  } else {
    const profile = await getProfile(c.env.DB, userId);
    let contextBlock = '';
    if (useResources && resourceIds.length) {
      const retrieved = await retrieve(
        c.env.DB,
        userId,
        `${subjects.join(' ')} ${chapters.join(' ')} ${difficulty} questions`,
        { resourceIds, limit: 8 },
      );
      contextBlock = buildContextBlock(retrieved, 9000);
    }
    try {
      added = await generateWithAI(
        c.env,
        userId,
        testId,
        config,
        profileContext(profile as unknown as Record<string, unknown> | null),
        contextBlock,
      );
    } catch (err) {
      await c.env.DB.prepare('DELETE FROM questions WHERE test_id = ? AND user_id = ?').bind(testId, userId).run();
      await c.env.DB.prepare('DELETE FROM tests WHERE id = ? AND user_id = ?').bind(testId, userId).run();
      if (err instanceof AIError) {
        return json({ error: err.message, code: 'ai_error', setupRequired: err.setupRequired }, { status: err.status });
      }
      throw err;
    }
    if (!added) {
      await c.env.DB.prepare('DELETE FROM tests WHERE id = ? AND user_id = ?').bind(testId, userId).run();
      return json({ error: 'The AI did not return valid questions. Please try again.', code: 'generation_failed' }, { status: 502 });
    }
  }

  if (!added) {
    await c.env.DB.prepare('DELETE FROM tests WHERE id = ? AND user_id = ?').bind(testId, userId).run();
    return json(
      {
        error: `No questions in the bank match this selection (${subjects.join(', ')}${chapters.length ? ` · ${chapters.join(', ')}` : ''}). Try different chapters, or generate an AI paper.`,
        code: 'no_questions',
      },
      { status: 400 },
    );
  }

  const total = await c.env.DB.prepare('SELECT COALESCE(SUM(marks), 0) AS total FROM questions WHERE test_id = ?')
    .bind(testId)
    .first<{ total: number }>();
  await c.env.DB.prepare('UPDATE tests SET total_marks = ? WHERE id = ?').bind(total?.total ?? 0, testId).run();

  const test = await c.env.DB.prepare('SELECT * FROM tests WHERE id = ?').bind(testId).first<Record<string, unknown>>();
  const { results: questions } = await c.env.DB.prepare('SELECT * FROM questions WHERE test_id = ? ORDER BY id').bind(testId).all<Record<string, unknown>>();

  return json(
    {
      test: {
        id: testId,
        title,
        exam,
        durationMinutes,
        totalMarks: total?.total ?? 0,
        status: 'draft',
        createdAt: String(test?.created_at ?? nowISO()),
        questionCount: added,
        config,
      },
      questions: (questions ?? []).map(mapQuestion).map(stripQuestion),
      shortfall: questionCount - added,
      note,
    },
    { status: 201 },
  );
});

function stripQuestion(q: ReturnType<typeof mapQuestion>) {
  return { ...q, correct: [], numericAnswer: null, solution: '' };
}

tests.get('/tests/:id', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const test = await c.env.DB.prepare('SELECT * FROM tests WHERE id = ? AND user_id = ?').bind(id, userId).first<Record<string, unknown>>();
  if (!test) return notFound('Test not found.');
  const { results } = await c.env.DB.prepare('SELECT * FROM questions WHERE test_id = ? ORDER BY id').bind(id).all<Record<string, unknown>>();
  const submitted = await c.env.DB.prepare(
    "SELECT id FROM attempts WHERE test_id = ? AND user_id = ? AND status = 'submitted' ORDER BY id DESC LIMIT 1",
  )
    .bind(id, userId)
    .first<{ id: number }>();

  const questions = (results ?? []).map(mapQuestion);
  return json({
    test: {
      id: Number(test.id),
      title: String(test.title),
      exam: String(test.exam),
      durationMinutes: Number(test.duration_minutes),
      totalMarks: Number(test.total_marks),
      status: String(test.status),
      createdAt: String(test.created_at),
      questionCount: questions.length,
      config: parseJSON<TestConfig | null>(test.config, null),
    },
    questions: submitted ? questions : questions.map(stripQuestion),
    submittedAttemptId: submitted?.id ?? null,
  });
});

tests.delete('/tests/:id', async (c) => {
  const userId = c.get('userId');
  const id = Number(c.req.param('id'));
  const owned = await c.env.DB.prepare('SELECT id FROM tests WHERE id = ? AND user_id = ?').bind(id, userId).first();
  if (!owned) return notFound('Test not found.');
  await c.env.DB.batch([
    c.env.DB.prepare('DELETE FROM questions WHERE test_id = ? AND user_id = ?').bind(id, userId),
    c.env.DB.prepare('DELETE FROM attempts WHERE test_id = ? AND user_id = ?').bind(id, userId),
    c.env.DB.prepare('DELETE FROM tests WHERE id = ? AND user_id = ?').bind(id, userId),
  ]);
  return json({ ok: true });
});

/* ---------------------------- attempts ---------------------------- */

tests.post('/tests/:id/attempts', async (c) => {
  const userId = c.get('userId');
  const testId = Number(c.req.param('id'));
  const test = await c.env.DB.prepare('SELECT * FROM tests WHERE id = ? AND user_id = ?').bind(testId, userId).first<Record<string, unknown>>();
  if (!test) return notFound('Test not found.');

  const existing = await c.env.DB.prepare(
    "SELECT * FROM attempts WHERE test_id = ? AND user_id = ? AND status = 'in-progress' ORDER BY id DESC LIMIT 1",
  )
    .bind(testId, userId)
    .first<Record<string, unknown>>();

  if (existing) {
    return json({
      attempt: {
        id: Number(existing.id),
        testId,
        status: 'in-progress',
        startedAt: String(existing.started_at),
        answers: parseJSON(existing.answers, {}),
        timeSpentSeconds: Number(existing.time_spent ?? 0),
        resumed: true,
      },
    });
  }

  const total = await c.env.DB.prepare('SELECT COALESCE(SUM(marks), 0) AS total FROM questions WHERE test_id = ?')
    .bind(testId)
    .first<{ total: number }>();
  const res = await c.env.DB.prepare(
    `INSERT INTO attempts (test_id, user_id, status, started_at, answers, max_score) VALUES (?, ?, 'in-progress', ?, '{}', ?)`,
  )
    .bind(testId, userId, nowISO(), total?.total ?? 0)
    .run();
  await c.env.DB.prepare("UPDATE tests SET status = 'in-progress' WHERE id = ? AND user_id = ?").bind(testId, userId).run();

  return json({
    attempt: {
      id: Number(res.meta.last_row_id),
      testId,
      status: 'in-progress',
      startedAt: nowISO(),
      answers: {},
      timeSpentSeconds: 0,
      resumed: false,
    },
  }, { status: 201 });
});

async function loadAttempt(env: AppEnv['Bindings'], userId: number, attemptId: number) {
  return env.DB.prepare('SELECT * FROM attempts WHERE id = ? AND user_id = ?').bind(attemptId, userId).first<Record<string, unknown>>();
}

tests.patch('/attempts/:id', async (c) => {
  const userId = c.get('userId');
  const attemptId = Number(c.req.param('id'));
  const attempt = await loadAttempt(c.env, userId, attemptId);
  if (!attempt) return notFound('Attempt not found.');
  if (String(attempt.status) === 'submitted') return badRequest('This attempt has already been submitted.', 'already_submitted');

  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const answers = body.answers && typeof body.answers === 'object' ? (body.answers as Record<string, AttemptAnswer>) : {};
  const serialized = JSON.stringify(answers);
  if (serialized.length > 900_000) return badRequest('Answer payload is too large.', 'payload_too_large');

  await c.env.DB.prepare('UPDATE attempts SET answers = ?, time_spent = ? WHERE id = ? AND user_id = ?')
    .bind(serialized, Math.round(num(body.timeSpentSeconds, 0, 0, 60 * 60 * 6)), attemptId, userId)
    .run();
  return json({ ok: true, savedAt: nowISO() });
});

tests.post('/attempts/:id/submit', async (c) => {
  const userId = c.get('userId');
  const attemptId = Number(c.req.param('id'));
  const attempt = await loadAttempt(c.env, userId, attemptId);
  if (!attempt) return notFound('Attempt not found.');
  if (String(attempt.status) === 'submitted') {
    return json({ attempt: mapAttempt(attempt), alreadySubmitted: true });
  }

  const testId = Number(attempt.test_id);
  const test = await c.env.DB.prepare('SELECT * FROM tests WHERE id = ? AND user_id = ?').bind(testId, userId).first<Record<string, unknown>>();
  if (!test) return notFound('Test not found.');

  const body = (await c.req.json().catch(() => ({}))) as Record<string, unknown>;
  const answers = (body.answers && typeof body.answers === 'object' ? body.answers : parseJSON<Record<string, AttemptAnswer>>(attempt.answers, {})) as Record<string, AttemptAnswer>;
  const timeSpentSeconds = Math.round(num(body.timeSpentSeconds, Number(attempt.time_spent ?? 0), 0, 60 * 60 * 6));

  const { results } = await c.env.DB.prepare('SELECT * FROM questions WHERE test_id = ? ORDER BY id').bind(testId).all<Record<string, unknown>>();
  const questions = (results ?? []).map(mapQuestion);
  if (!questions.length) return badRequest('This test has no questions.', 'empty_test');

  const config = parseJSON<TestConfig>(test.config, {
    exam: String(test.exam) as ExamId, subjects: [], chapters: [], types: [], difficulty: 'medium',
    questionCount: questions.length, durationMinutes: Number(test.duration_minutes), negativeMarking: false,
    useResources: false, resourceIds: [], generatedBy: 'bank',
  });

  const payload: SubmissionPayload = { answers, timeSpentSeconds };
  const result = await evaluateAttempt(c.env, userId, questions, payload, config);

  await c.env.DB.prepare(
    `UPDATE attempts SET status = 'submitted', submitted_at = ?, answers = ?, score = ?, max_score = ?, correct = ?, incorrect = ?, unattempted = ?, accuracy = ?, time_spent = ?, report = ?
     WHERE id = ? AND user_id = ?`,
  )
    .bind(
      nowISO(), JSON.stringify(answers), result.score, result.maxScore, result.correct, result.incorrect,
      result.unattempted, result.accuracy, timeSpentSeconds, JSON.stringify(result.report), attemptId, userId,
    )
    .run();
  await c.env.DB.prepare("UPDATE tests SET status = 'submitted' WHERE id = ? AND user_id = ?").bind(testId, userId).run();

  const attemptStatements = result.report.evaluated.map((item) =>
    c.env.DB.prepare(
      'INSERT INTO question_attempts (user_id, question_id, correct, response, created_at) VALUES (?, ?, ?, ?, ?)',
    ).bind(
      userId,
      item.questionId,
      item.status === 'correct' ? 1 : 0,
      JSON.stringify({ response: item.response, numeric: item.numericResponse }),
      nowISO(),
    ),
  );
  for (let i = 0; i < attemptStatements.length; i += 40) await c.env.DB.batch(attemptStatements.slice(i, i + 40));

  await applyAttemptToProgress(c.env.DB, userId, result.report.evaluated);

  // Mistake-based revision cards for objective questions answered incorrectly.
  const cardStatements = result.report.evaluated
    .filter((item) => (item.status === 'incorrect' || item.status === 'unattempted') && isObjective(item.type))
    .slice(0, 20)
    .map((item) => {
      const question = questions.find((q) => q.id === item.questionId);
      return c.env.DB.prepare(
        `INSERT INTO revision_cards (user_id, front, back, subject, chapter, source, due, interval_days, ease, repetitions, lapses, question_id, created_at)
         VALUES (?, ?, ?, ?, ?, 'question', ?, 1, 2.5, 0, 0, ?, ?)`,
      ).bind(
        userId,
        item.prompt.slice(0, 900),
        (item.solution || question?.solution || 'Revise this question and its concept.').slice(0, 2000),
        item.subject,
        item.chapter,
        todayISO(),
        item.questionId,
        nowISO(),
      );
    });
  for (let i = 0; i < cardStatements.length; i += 30) await c.env.DB.batch(cardStatements.slice(i, i + 30));

  if (timeSpentSeconds > 0) {
    await recordStudy(c.env.DB, userId, timeSpentSeconds / 60, config.subjects[0] ?? null, null, 'test');
  }

  const updated = await loadAttempt(c.env, userId, attemptId);
  return json({ attempt: updated ? mapAttempt(updated) : null, report: result.report });
});

tests.get('/attempts/:id', async (c) => {
  const userId = c.get('userId');
  const attempt = await loadAttempt(c.env, userId, Number(c.req.param('id')));
  if (!attempt) return notFound('Attempt not found.');
  const test = await c.env.DB.prepare('SELECT * FROM tests WHERE id = ? AND user_id = ?')
    .bind(Number(attempt.test_id), userId)
    .first<Record<string, unknown>>();
  const { results } = await c.env.DB.prepare('SELECT * FROM questions WHERE test_id = ? ORDER BY id')
    .bind(Number(attempt.test_id))
    .all<Record<string, unknown>>();
  return json({
    attempt: mapAttempt(attempt),
    test: test
      ? { id: Number(test.id), title: String(test.title), exam: String(test.exam), durationMinutes: Number(test.duration_minutes), totalMarks: Number(test.total_marks) }
      : null,
    questions: (results ?? []).map(mapQuestion).map((q) => ({ id: q.id, subject: q.subject, chapter: q.chapter, type: q.type, difficulty: q.difficulty, prompt: q.prompt, options: q.options, marks: q.marks, correct: q.correct, numericAnswer: q.numericAnswer, solution: q.solution })),
  });
});

function mapAttempt(row: Record<string, unknown>) {
  return {
    id: Number(row.id),
    testId: Number(row.test_id),
    status: String(row.status),
    startedAt: String(row.started_at),
    submittedAt: (row.submitted_at as string) ?? null,
    answers: parseJSON(row.answers, {}),
    score: Number(row.score ?? 0),
    maxScore: Number(row.max_score ?? 0),
    correct: Number(row.correct ?? 0),
    incorrect: Number(row.incorrect ?? 0),
    unattempted: Number(row.unattempted ?? 0),
    accuracy: Number(row.accuracy ?? 0),
    timeSpentSeconds: Number(row.time_spent ?? 0),
    report: parseJSON(row.report, null),
  };
}

export default tests;
