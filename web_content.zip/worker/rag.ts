/**
 * Retrieval engine for uploaded resources.
 *
 * PDF text is extracted in the browser (pdf.js), chunked and embedded here with
 * a deterministic hashed term-frequency vector (a sparse bag-of-words
 * embedding). Retrieval is cosine similarity over those vectors. This runs
 * entirely inside the Worker with no external embedding API, so it works
 * offline and cannot fabricate content: every retrieved passage carries its
 * source document and page number.
 */

const STOPWORDS = new Set(
  `a an the and or but if then than that this these those of in on at to for from by with as is are was were be been being it its it's we you they he she i not no nor so such can could should would will shall may might must do does did done have has had about into over under between among during before after above below up down out off again further once here there when where why how all any both each few more most other some only own same very s t just don now also use used using thus hence therefore figure fig example solution step steps given find value`.split(/\s+/),
);

export function tokenize(text: string): string[] {
  return (text.toLowerCase().match(/[a-z0-9]+/g) ?? [])
    .filter((t) => t.length > 1 && !STOPWORDS.has(t))
    .map(stem);
}

/** Extremely light stemmer: strips common suffixes, enough for lexical recall. */
function stem(word: string): string {
  if (word.length <= 4) return word;
  for (const suffix of ['ations', 'ation', 'ments', 'ment', 'ings', 'ing', 'ies', 'ied', 'es', 'ed', 'ly', 's']) {
    if (word.endsWith(suffix) && word.length - suffix.length >= 3) {
      return word.slice(0, word.length - suffix.length);
    }
  }
  return word;
}

export const VECTOR_DIM = 256;

/** Hashed TF vector with sublinear term frequency, L2-normalised. */
export function embed(text: string): number[] {
  const tokens = tokenize(text);
  const vec = new Array<number>(VECTOR_DIM).fill(0);
  if (!tokens.length) return vec;
  const counts = new Map<string, number>();
  for (const t of tokens) counts.set(t, (counts.get(t) ?? 0) + 1);
  for (const [term, count] of counts) {
    let h = 2166136261;
    for (let i = 0; i < term.length; i++) {
      h ^= term.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    const idx = Math.abs(h) % VECTOR_DIM;
    vec[idx] += 1 + Math.log(count);
  }
  let norm = 0;
  for (const v of vec) norm += v * v;
  norm = Math.sqrt(norm) || 1;
  return vec.map((v) => Math.round((v / norm) * 10000) / 10000);
}

export function cosine(a: number[], b: number[]): number {
  let dot = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) dot += a[i] * b[i];
  return dot; // both vectors are unit length
}

export interface PageText {
  page: number;
  text: string;
}

export interface Chunk {
  page: number;
  text: string;
  vector: number[];
}

const CHUNK_CHARS = 1100;
const CHUNK_OVERLAP = 160;

/** Split page text into overlapping chunks that keep their page number. */
export function chunkPages(pages: PageText[]): Chunk[] {
  const chunks: Chunk[] = [];
  for (const page of pages) {
    const clean = page.text.replace(/\s+\n/g, '\n').replace(/[ \t]{2,}/g, ' ').trim();
    if (!clean) continue;
    if (clean.length <= CHUNK_CHARS) {
      chunks.push({ page: page.page, text: clean, vector: embed(clean) });
      continue;
    }
    const sentences = clean.split(/(?<=[.!?])\s+/);
    let buffer = '';
    for (const sentence of sentences) {
      if (buffer.length + sentence.length + 1 > CHUNK_CHARS && buffer.length > 0) {
        chunks.push({ page: page.page, text: buffer.trim(), vector: embed(buffer) });
        buffer = buffer.slice(Math.max(0, buffer.length - CHUNK_OVERLAP));
      }
      buffer += (buffer ? ' ' : '') + sentence;
      // A single huge sentence (dense formula blocks) still needs splitting.
      while (buffer.length > CHUNK_CHARS * 2) {
        chunks.push({ page: page.page, text: buffer.slice(0, CHUNK_CHARS), vector: embed(buffer.slice(0, CHUNK_CHARS)) });
        buffer = buffer.slice(CHUNK_CHARS - CHUNK_OVERLAP);
      }
    }
    if (buffer.trim()) chunks.push({ page: page.page, text: buffer.trim(), vector: embed(buffer) });
  }
  return chunks;
}

export interface RetrievedChunk {
  id: number;
  resourceId: number;
  resourceName: string;
  page: number;
  text: string;
  score: number;
}

/**
 * Load a user's chunks and rank them against the query.
 * `resourceIds` narrows retrieval to specific documents.
 */
export async function retrieve(
  db: D1Database,
  userId: number,
  query: string,
  opts: { resourceIds?: number[]; limit?: number; minScore?: number } = {},
): Promise<RetrievedChunk[]> {
  const limit = opts.limit ?? 6;
  const minScore = opts.minScore ?? 0.06;
  const queryVector = embed(query);
  if (queryVector.every((v) => v === 0)) return [];

  const ids = opts.resourceIds?.filter((n) => Number.isFinite(n)) ?? [];
  const idFilter = ids.length ? ` AND c.resource_id IN (${ids.map(() => '?').join(',')})` : '';
  const { results } = await db
    .prepare(
      `SELECT c.id, c.resource_id, c.page, c.text, c.vector, r.name AS resource_name
       FROM resource_chunks c JOIN resources r ON r.id = c.resource_id
       WHERE c.user_id = ? AND r.status = 'ready'${idFilter}
       LIMIT 4000`,
    )
    .bind(userId, ...ids)
    .all<{ id: number; resource_id: number; page: number; text: string; vector: string; resource_name: string }>();

  const scored: RetrievedChunk[] = [];
  for (const row of results ?? []) {
    let vector: number[];
    try {
      vector = JSON.parse(row.vector) as number[];
    } catch {
      continue;
    }
    const score = cosine(queryVector, vector);
    if (score >= minScore) {
      scored.push({
        id: row.id,
        resourceId: row.resource_id,
        resourceName: row.resource_name,
        page: row.page,
        text: row.text,
        score,
      });
    }
  }
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit);
}

export function buildContextBlock(chunks: RetrievedChunk[], maxChars = 7000): string {
  if (!chunks.length) return '';
  let out = '';
  let index = 1;
  for (const chunk of chunks) {
    const entry = `[${index}] ${chunk.resourceName}, page ${chunk.page}\n${chunk.text}\n\n`;
    if (out.length + entry.length > maxChars) break;
    out += entry;
    index++;
  }
  return out.trim();
}

export function citationsFrom(chunks: RetrievedChunk[]): { resourceName: string; page: number }[] {
  const seen = new Set<string>();
  const out: { resourceName: string; page: number }[] = [];
  for (const c of chunks) {
    const key = `${c.resourceName}::${c.page}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ resourceName: c.resourceName, page: c.page });
  }
  return out.slice(0, 8);
}
