import type { Env } from './lib';
import { stripTags } from './lib';

/**
 * LLM access layer.
 *
 * Any OpenAI-compatible endpoint can be used. On Freebuff deployments the
 * default is the Freebuff API, read server-side from env.OPENAI_API_KEY — the
 * key is never sent to the browser.
 */

export class AIError extends Error {
  status: number;
  setupRequired: boolean;
  constructor(message: string, status = 502, setupRequired = false) {
    super(message);
    this.name = 'AIError';
    this.status = status;
    this.setupRequired = setupRequired;
  }
}

export function aiConfig(env: Env) {
  return {
    key: env.OPENAI_API_KEY?.trim() ?? '',
    base: (env.OPENAI_BASE_URL?.trim() || 'https://freebuff.com/api/v1/paid').replace(/\/+$/, ''),
    model: env.AI_MODEL?.trim() || 'gpt-4o-mini',
  };
}

export function aiEnabled(env: Env): boolean {
  return Boolean(aiConfig(env).key);
}

export interface AIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface AIOptions {
  temperature?: number;
  maxTokens?: number;
  json?: boolean;
  timeoutMs?: number;
}

export async function aiText(env: Env, messages: AIMessage[], options: AIOptions = {}): Promise<string> {
  const { key, base, model } = aiConfig(env);
  if (!key) {
    throw new AIError(
      'AI features need an API key. Add OPENAI_API_KEY to this project (Settings → Secrets) and reload.',
      503,
      true,
    );
  }

  const timeout = options.timeoutMs ?? 60000;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);

  try {
    const res = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        messages,
        temperature: options.temperature ?? 0.4,
        max_tokens: options.maxTokens ?? 2500,
        ...(options.json ? { response_format: { type: 'json_object' } } : {}),
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      const body = (await res.text().catch(() => '')).slice(0, 400);
      const lower = body.toLowerCase();
      if (res.status === 401 || res.status === 403 || res.status === 402) {
        throw new AIError(
          `The AI provider rejected the key or the account has no available credits (HTTP ${res.status}). Check OPENAI_API_KEY and your API billing.`,
          res.status === 402 ? 402 : 502,
          true,
        );
      }
      if (res.status === 429) {
        throw new AIError('The AI provider is rate-limiting requests. Wait a few seconds and try again.', 429);
      }
      if (lower.includes('model')) {
        throw new AIError(`The configured AI model "${model}" was rejected by the provider. Set AI_MODEL to a model your account can use. (${body})`, 502);
      }
      throw new AIError(`AI request failed (HTTP ${res.status}). ${body}`, 502);
    }

    const data = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
      error?: { message?: string };
    };
    const content = data.choices?.[0]?.message?.content;
    if (!content || !content.trim()) {
      throw new AIError(data.error?.message || 'The AI returned an empty response. Try again.', 502);
    }
    return content;
  } catch (err) {
    if (err instanceof AIError) throw err;
    if (err instanceof Error && err.name === 'AbortError') {
      throw new AIError('The AI took too long to respond. Try a shorter request.', 504);
    }
    throw new AIError(`Could not reach the AI provider: ${(err as Error).message}`, 502);
  } finally {
    clearTimeout(timer);
  }
}

/** Extract the first JSON object/array from a model reply, tolerating fences. */
export function extractJSON<T>(raw: string): T {
  const cleaned = raw
    .replace(/^\s*```(?:json)?/i, '')
    .replace(/```\s*$/i, '')
    .trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    /* fall through to bracket scan */
  }
  const start = cleaned.search(/[[{]/);
  if (start === -1) throw new AIError('The AI response was not valid JSON. Please retry.', 502);
  const open = cleaned[start];
  const close = open === '{' ? '}' : ']';
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < cleaned.length; i++) {
    const ch = cleaned[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === open) depth++;
    else if (ch === close) {
      depth--;
      if (depth === 0) {
        try {
          return JSON.parse(cleaned.slice(start, i + 1)) as T;
        } catch {
          break;
        }
      }
    }
  }
  throw new AIError('The AI response was not valid JSON. Please retry.', 502);
}

export async function aiJSON<T>(env: Env, messages: AIMessage[], options: AIOptions = {}): Promise<T> {
  const reply = await aiText(env, messages, { ...options, json: true });
  return extractJSON<T>(reply);
}

export function cleanAIText(value: string): string {
  return stripTags(value).trim();
}

/** Prompt-side academic context shared by teacher, planner and test prompts. */
export function profileContext(profile: Record<string, unknown> | null): string {
  if (!profile) return 'The student has not completed onboarding yet; keep guidance general and ask what they are studying.';
  const p = profile as Record<string, string | number | string[] | boolean>;
  const list = (v: unknown) => (Array.isArray(v) ? v.join(', ') : String(v ?? '—'));
  return [
    `Name: ${p.name ?? 'Student'}`,
    `Class: ${p.classLevel ?? '—'}; Board: ${p.board ?? '—'}`,
    `Target exam: ${p.examLabel ?? p.exam ?? '—'}; Exam date: ${p.examDate || 'not set'}`,
    `Subjects: ${list(p.subjects)}`,
    `Current performance: ${p.currentPerformance || 'not provided'}; Target: ${p.targetScore || 'not provided'}`,
    `Daily study hours available: ${p.dailyHours ?? '—'}`,
    `Preferences: ${p.learningStyle || 'not provided'}`,
    `Weak subjects: ${list(p.weakSubjects)}; Strong subjects: ${list(p.strongSubjects)}`,
    `School: ${p.schoolStart || '—'} to ${p.schoolEnd || '—'}; Coaching: ${p.coachingStart || '—'} to ${p.coachingEnd || '—'}`,
    `Sleep: ${p.sleepAt || '—'} to ${p.wakeAt || '—'}`,
    `Other commitments: ${p.commitments || 'none stated'}`,
  ].join('\n');
}
