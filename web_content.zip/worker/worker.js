// ============================================================
//  RadLedger — License Server + Telegram Admin Bot  (v2)
//  Cloudflare Workers + KV  |  Developer: Shahyad Rahmani — t.me/RadOriginal
//
//  ✅ این فایل دیگر هیچ رمز و توکنی ندارد و بدون خطر می‌توان آن را در گیت‌هاب گذاشت.
//  رمزها را فقط در داشبورد Cloudflare بگذارید:
//     Workers ▸ (سرویس شما) ▸ Settings ▸ Variables and Secrets
//       BOT_TOKEN       (Secret)  توکن ربات از BotFather
//       ADMIN_ID        (Text)    چت‌آیدی عددی مدیر
//       WEBHOOK_SECRET  (Secret)  یک رشتهٔ تصادفی بلند (فقط A-Z a-z 0-9 _ -)
//       SIGN_KEY        (Secret)  کلید خصوصی امضا (JSON) — با tools/gen-keys.mjs بسازید
//       SUPPORT_URL     (Text, اختیاری) پیش‌فرض: https://t.me/RadOriginal
//     Settings ▸ Bindings ▸ KV namespace  با نام  DB
//     Settings ▸ Triggers ▸ Cron  (اختیاری، گزارش روزانهٔ انقضا):  0 5 * * *
// ============================================================

const DAY = 864e5;
const HOUR = 36e5;
const TEHRAN_OFFSET = 3.5 * HOUR; // ایران از ۱۴۰۱ ساعت تابستانی ندارد
const CODE_RE = /^RL-[A-Z2-9]{8}$/;
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers': 'content-type',
  'Access-Control-Max-Age': '86400',
};

// ---------- helpers ----------
const json = (o, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json', 'cache-control': 'no-store', ...CORS } });
const esc = (s) => String(s == null ? '' : s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const fa = (s) => String(s).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);
const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);

function g2j(gy, gm, gd) {
  const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  const g2 = gm > 2 ? gy + 1 : gy;
  let days = 365 * gy + ~~((g2 + 3) / 4) - ~~((g2 + 99) / 100) + ~~((g2 + 399) / 400) - 80 + gd + gdm[gm - 1];
  jy += 33 * ~~(days / 12053); days %= 12053;
  jy += 4 * ~~(days / 1461); days %= 1461;
  if (days > 365) { jy += ~~((days - 1) / 365); days = (days - 1) % 365; }
  const jm = days < 186 ? 1 + ~~(days / 31) : 7 + ~~((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}
function jdate(ms) {
  if (!ms) return '—';
  const d = new Date(ms + TEHRAN_OFFSET);
  const [y, m, dd] = g2j(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
  return fa(`${y}/${String(m).padStart(2, '0')}/${String(dd).padStart(2, '0')}`);
}
const daysLeft = (exp, now = Date.now()) => Math.ceil((exp - now) / DAY);

// ---------- config (secrets از env خوانده می‌شوند) ----------
function cfg(env) {
  const admin = Number(env.ADMIN_ID);
  if (!env.BOT_TOKEN || !admin || !env.WEBHOOK_SECRET || !env.SIGN_KEY || !env.DB) return null;
  let key;
  try { key = typeof env.SIGN_KEY === 'string' ? JSON.parse(env.SIGN_KEY) : env.SIGN_KEY; } catch (e) { return null; }
  return { token: env.BOT_TOKEN, admin, hook: String(env.WEBHOOK_SECRET), key, keyStr: JSON.stringify(key), support: env.SUPPORT_URL || 'https://t.me/RadOriginal' };
}

// ---------- crypto ----------
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
let _key, _keyStr;
async function sign(C, text) {
  if (!_key || _keyStr !== C.keyStr) {
    _key = await crypto.subtle.importKey('jwk', C.key, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
    _keyStr = C.keyStr;
  }
  const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, _key, new TextEncoder().encode(text));
  return b64(sig);
}
function safeEq(a, b) {
  a = String(a || ''); b = String(b || '');
  let d = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) d |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return d === 0;
}

// ---------- telegram ----------
async function tg(C, method, body) {
  try {
    const r = await fetch(`https://api.telegram.org/bot${C.token}/${method}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    return await r.json();
  } catch (e) {
    return { ok: false, description: String(e) };
  }
}
const say = (C, text, extra = {}) =>
  tg(C, 'sendMessage', { chat_id: C.admin, text: text.slice(0, 4000), parse_mode: 'HTML', disable_web_page_preview: true, ...extra });

// ---------- storage ----------
const getRec = (env, c) => env.DB.get('u:' + c, 'json');
const putRec = (env, r) =>
  env.DB.put('u:' + r.c, JSON.stringify(r), {
    metadata: { n: String(r.name || '').slice(0, 40), p: String(r.phone || '').slice(0, 20), a: +!!r.act, b: +!!r.blk, pl: r.plan || '', e: r.exp || 0, g: r.reg || 0 },
  });
async function allMeta(env) {
  const out = [];
  let cursor;
  do {
    const l = await env.DB.list({ prefix: 'u:', cursor });
    l.keys.forEach((k) => out.push({ c: k.name.slice(2), ...(k.metadata || {}) }));
    cursor = l.list_complete ? null : l.cursor;
  } while (cursor);
  return out;
}
// محدودیت نرخ ساده (برای جلوگیری از اسپم ثبت‌نام)
async function limited(env, req, bucket, max, ttl) {
  const ip = req.headers.get('CF-Connecting-IP') || 'x';
  const k = `z:${bucket}:${ip}`;
  const n = parseInt(await env.DB.get(k), 10) || 0;
  if (n >= max) return true;
  await env.DB.put(k, String(n + 1), { expirationTtl: ttl });
  return false;
}

// ---------- license logic ----------
function stat(r, now) {
  if (!r) return { st: 'none', exp: 0, plan: '' };
  if (r.blk) return { st: 'blocked', exp: 0, plan: '' };
  if (!r.act) return { st: 'pending', exp: 0, plan: '' };
  if (r.plan === 'life') return { st: 'active', exp: 0, plan: 'life' };
  if (r.exp > now) return { st: 'active', exp: r.exp, plan: 'time' };
  return { st: 'expired', exp: r.exp, plan: '' };
}
const metaStat = (m, now) => stat({ act: m.a, blk: m.b, plan: m.pl, exp: m.e }, now);
async function signed(C, c, n, r) {
  const now = Date.now();
  const s = stat(r, now);
  const p = JSON.stringify({ c, n, st: s.st, exp: s.exp, plan: s.plan, iat: now });
  return { p, s: await sign(C, p) };
}
function grant(r, days) {
  const now = Date.now();
  r.act = true;
  r.blk = false;
  if (days === 0) { r.plan = 'life'; r.exp = 0; }
  else {
    const base = r.plan !== 'life' && r.exp > now ? r.exp : now;
    r.plan = 'time';
    r.exp = base + days * DAY;
  }
}

// ---------- admin UI ----------
function label(r) {
  const now = Date.now();
  const s = stat(r, now);
  if (s.st === 'blocked') return '⛔ مسدود';
  if (s.st === 'pending') return '🟡 در انتظار تأیید';
  if (s.st === 'expired') return `🔴 منقضی (${jdate(s.exp)})`;
  if (s.plan === 'life') return '🟢 فعال — دائمی ♾';
  return `🟢 فعال تا ${jdate(s.exp)} (${fa(Math.max(0, daysLeft(s.exp, now)))} روز مانده)`;
}
function card(r) {
  return [
    `👤 <b>${esc(r.name) || '—'}</b>`,
    `📱 ${esc(r.phone) || '—'}`,
    r.biz ? `🏢 ${esc(r.biz)}` : null,
    `🔑 <code>${r.c}</code>`,
    `وضعیت: ${label(r)}`,
    `📅 ثبت‌نام: ${jdate(r.reg)}   👁 آخرین اتصال: ${jdate(r.seen)}`,
    r.ver ? `📦 نسخهٔ اپ: ${esc(r.ver)}` : null,
  ].filter(Boolean).join('\n');
}
function kb(r) {
  return {
    inline_keyboard: [
      [
        { text: '✅ +۳۰ روز', callback_data: `g:${r.c}:30` },
        { text: '✅ +۹۰ روز', callback_data: `g:${r.c}:90` },
        { text: '✅ +۱ سال', callback_data: `g:${r.c}:365` },
      ],
      [
        { text: '♾ دائمی', callback_data: `g:${r.c}:0` },
        r.blk ? { text: '🔓 رفع مسدودی', callback_data: `ub:${r.c}` } : { text: '⛔ مسدود', callback_data: `b:${r.c}` },
      ],
      [{ text: '🗑 حذف کاربر', callback_data: `d:${r.c}` }],
    ],
  };
}
const HELP = `🛡 <b>مدیریت لایسنس RadLedger</b>

/pending — درخواست‌های در انتظار
/users — فهرست همهٔ کاربران
/find متن — جستجو (نام / تلفن / کد)
/user کد — کارت کاربر (مثلاً <code>/user RL-AB12CD34</code>)
/grant کد روز — افزودن روز (۰ = دائمی)
/block کد — مسدود
/unblock کد — رفع مسدودی
/del کد — حذف
/expiring [روز] — لایسنس‌های نزدیک به انقضا (پیش‌فرض ۷ روز)
/export — دریافت فایل فهرست کاربران
/stats — آمار

وقتی کاربر جدید در اپ ثبت‌نام کند، همین‌جا پیام با دکمه‌های فعال‌سازی می‌گیرید.`;

function normCode(s) {
  s = String(s || '').trim().toUpperCase();
  if (/^[A-Z2-9]{8}$/.test(s)) s = 'RL-' + s;
  return CODE_RE.test(s) ? s : null;
}
const lineOf = (m, now) => {
  const s = metaStat(m, now);
  const e = { active: '🟢', pending: '🟡', expired: '🔴', blocked: '⛔' }[s.st] || '⚪';
  const extra = s.st === 'active' && s.plan === 'time' ? ` · ${fa(Math.max(0, daysLeft(s.exp, now)))} روز` : '';
  return `${e} ${esc(m.n) || '—'} ${m.p ? '· ' + esc(m.p) : ''}${extra}\n   /u_${m.c.slice(3)}`;
};
const delKb = (c) => ({ inline_keyboard: [[{ text: '🗑 بله، حذف شود', callback_data: `dd:${c}` }, { text: 'انصراف', callback_data: `i:${c}` }]] });

async function onMessage(env, C, msg) {
  if (msg.chat.id !== C.admin || (msg.from && msg.from.id !== C.admin)) {
    if (msg.chat.type === 'private') await tg(C, 'sendMessage', { chat_id: msg.chat.id, text: `این ربات اختصاصی است.\nپشتیبانی: ${C.support}` });
    return;
  }
  const text = (msg.text || '').trim();
  if (!text.startsWith('/')) return say(C, 'دستور را با / شروع کنید. برای راهنما: /help');
  const parts = text.split(/\s+/);
  let cmd = parts[0].slice(1).split('@')[0].toLowerCase();
  let args = parts.slice(1);
  if (cmd.startsWith('u_')) { args = ['RL-' + cmd.slice(2).toUpperCase()]; cmd = 'user'; }

  if (cmd === 'start' || cmd === 'help') return say(C, HELP);

  if (['stats', 'pending', 'users', 'find', 'expiring', 'export'].includes(cmd)) {
    const all = await allMeta(env);
    const now = Date.now();
    if (cmd === 'stats') {
      const c = { active: 0, pending: 0, expired: 0, blocked: 0 };
      all.forEach((m) => c[metaStat(m, now).st]++);
      const soon = all.filter((m) => { const s = metaStat(m, now); return s.st === 'active' && s.plan === 'time' && daysLeft(s.exp, now) <= 7; }).length;
      return say(C, `📊 <b>آمار</b>\nکل: ${fa(all.length)}\n🟢 فعال: ${fa(c.active)}\n🟡 در انتظار: ${fa(c.pending)}\n🔴 منقضی: ${fa(c.expired)}\n⛔ مسدود: ${fa(c.blocked)}\n⏰ انقضا تا ۷ روز آینده: ${fa(soon)}`);
    }
    if (cmd === 'export') {
      const rows = all.map((m) => {
        const s = metaStat(m, now);
        return { code: m.c, name: m.n, phone: m.p, status: s.st, plan: s.plan, expires: s.exp ? new Date(s.exp).toISOString() : null, registered: m.g ? new Date(m.g).toISOString() : null };
      });
      const fd = new FormData();
      fd.append('chat_id', String(C.admin));
      fd.append('caption', `فهرست ${rows.length} کاربر`);
      fd.append('document', new Blob([JSON.stringify(rows, null, 2)], { type: 'application/json' }), 'radledger-users.json');
      try { await fetch(`https://api.telegram.org/bot${C.token}/sendDocument`, { method: 'POST', body: fd }); } catch (e) { return say(C, 'خطا در ارسال فایل'); }
      return;
    }
    let list = all.sort((a, b) => (b.g || 0) - (a.g || 0));
    if (cmd === 'pending') list = list.filter((m) => metaStat(m, now).st === 'pending');
    if (cmd === 'expiring') {
      const d = Math.min(365, Math.max(1, parseInt(args[0], 10) || 7));
      list = list.filter((m) => { const s = metaStat(m, now); return s.st === 'active' && s.plan === 'time' && daysLeft(s.exp, now) <= d; })
        .sort((a, b) => a.e - b.e);
    }
    if (cmd === 'find') {
      const q = args.join(' ').toLowerCase();
      if (!q) return say(C, 'مثال: /find احمد');
      list = list.filter((m) => `${m.n} ${m.p} ${m.c}`.toLowerCase().includes(q));
    }
    if (!list.length) return say(C, 'موردی پیدا نشد.');
    const page = cmd === 'users' ? Math.max(1, parseInt(args[0], 10) || 1) : 1;
    const per = 25;
    const slice = list.slice((page - 1) * per, page * per);
    const title = { pending: '🟡 در انتظار', expiring: '⏰ نزدیک به انقضا' }[cmd] || 'کاربران';
    let t = `${title} (${fa(list.length)})\n\n` + slice.map((m) => lineOf(m, now)).join('\n');
    if (list.length > page * per) t += `\n\nصفحهٔ بعد: /users ${page + 1}`;
    return say(C, t);
  }

  const c = normCode(args[0]);
  if (!['user', 'grant', 'block', 'unblock', 'del'].includes(cmd)) return say(C, 'دستور ناشناخته. /help');
  if (!c) return say(C, 'کد نامعتبر است. مثال: <code>RL-AB12CD34</code>');
  const r = await getRec(env, c);
  if (!r) return say(C, 'کاربری با این کد پیدا نشد.');

  if (cmd === 'user') return say(C, card(r), { reply_markup: kb(r) });
  if (cmd === 'grant') {
    const d = parseInt(args[1], 10);
    if (isNaN(d) || d < 0 || d > 3650) return say(C, 'مثال: <code>/grant RL-AB12CD34 30</code>  (۰ = دائمی)');
    grant(r, d); await putRec(env, r);
    return say(C, '✅ انجام شد\n\n' + card(r), { reply_markup: kb(r) });
  }
  if (cmd === 'block' || cmd === 'unblock') {
    r.blk = cmd === 'block'; await putRec(env, r);
    return say(C, (r.blk ? '⛔ مسدود شد' : '🔓 رفع مسدودی شد') + '\n\n' + card(r), { reply_markup: kb(r) });
  }
  if (cmd === 'del') return say(C, `حذف ${r.c} (${esc(r.name)})؟`, { reply_markup: delKb(r.c) });
}

async function onCallback(env, C, q) {
  if (q.from.id !== C.admin) return tg(C, 'answerCallbackQuery', { callback_query_id: q.id, text: 'مجاز نیستید' });
  if (!q.message) return tg(C, 'answerCallbackQuery', { callback_query_id: q.id });
  const [act, c, arg] = String(q.data || '').split(':');
  const chat_id = q.message.chat.id, message_id = q.message.message_id;
  const r = CODE_RE.test(c) ? await getRec(env, c) : null;
  if (!r) return tg(C, 'answerCallbackQuery', { callback_query_id: q.id, text: 'کاربر پیدا نشد', show_alert: true });
  let note = '';
  if (act === 'g') {
    const d = parseInt(arg, 10);
    if (![0, 30, 90, 365].includes(d)) return tg(C, 'answerCallbackQuery', { callback_query_id: q.id });
    grant(r, d); await putRec(env, r); note = '✅ فعال شد';
  } else if (act === 'b') { r.blk = true; await putRec(env, r); note = '⛔ مسدود شد'; }
  else if (act === 'ub') { r.blk = false; await putRec(env, r); note = '🔓 رفع مسدودی'; }
  else if (act === 'i') { note = ''; }
  else if (act === 'd') {
    await tg(C, 'answerCallbackQuery', { callback_query_id: q.id });
    return tg(C, 'editMessageReplyMarkup', { chat_id, message_id, reply_markup: delKb(c) });
  } else if (act === 'dd') {
    await env.DB.delete('u:' + c);
    await tg(C, 'answerCallbackQuery', { callback_query_id: q.id, text: 'حذف شد' });
    return tg(C, 'editMessageText', { chat_id, message_id, text: `🗑 ${c} حذف شد.` });
  }
  await tg(C, 'answerCallbackQuery', { callback_query_id: q.id, text: note });
  return tg(C, 'editMessageText', { chat_id, message_id, text: card(r), parse_mode: 'HTML', reply_markup: kb(r) });
}

// ---------- app API ----------
async function apiRegister(env, C, ctx, req) {
  let b;
  try { b = JSON.parse(await req.text()); } catch (e) { return json({ error: 'bad json' }, 400); }
  const c = String(b.c || ''), n = String(b.n || '');
  if (!CODE_RE.test(c) || n.length < 8 || n.length > 64) return json({ error: 'bad request' }, 400);
  const name = clean(b.name, 60), phone = clean(b.phone, 20), biz = clean(b.biz, 60), ver = clean(b.ver, 12);
  if (name.length < 2 || phone.replace(/\D/g, '').length < 7) return json({ error: 'name/phone required' }, 400);
  const now = Date.now();
  let r = await getRec(env, c);
  if (!r) {
    if (await limited(env, req, 'reg', 20, 3600)) return json({ error: 'rate limited' }, 429);
    r = { c, name, phone, biz, reg: now, seen: now, act: false, blk: false, plan: '', exp: 0, ver };
    await putRec(env, r);
    ctx.waitUntil(say(C, '🆕 <b>درخواست فعال‌سازی جدید</b>\n\n' + card(r), { reply_markup: kb(r) }));
  } else {
    const changed = r.name !== name || r.phone !== phone || r.biz !== biz;
    if (changed && (await limited(env, req, 'upd', 30, 3600))) return json({ error: 'rate limited' }, 429);
    Object.assign(r, { name, phone, biz, seen: now, ver: ver || r.ver });
    await putRec(env, r);
    if (changed) ctx.waitUntil(say(C, '✏️ پروفایل کاربر به‌روز شد\n\n' + card(r), { reply_markup: kb(r) }));
  }
  return json(await signed(C, c, n, r));
}

async function apiStatus(env, C, url) {
  const c = url.searchParams.get('c') || '', n = url.searchParams.get('n') || '';
  if (!CODE_RE.test(c) || n.length < 8 || n.length > 64) return json({ error: 'bad request' }, 400);
  const r = await getRec(env, c);
  if (r && Date.now() - (r.seen || 0) > 6 * HOUR) { // کاهش نوشتن در KV: حداکثر هر ۶ ساعت
    r.seen = Date.now();
    const v = clean(url.searchParams.get('v'), 12); if (v) r.ver = v;
    await putRec(env, r);
  }
  return json(await signed(C, c, n, r));
}

// ---------- cron: گزارش روزانهٔ انقضا ----------
async function daily(env, C) {
  const now = Date.now();
  const all = await allMeta(env);
  const soon = all.filter((m) => { const s = metaStat(m, now); return s.st === 'active' && s.plan === 'time' && daysLeft(s.exp, now) <= 3; });
  const gone = all.filter((m) => m.a && !m.b && m.pl === 'time' && m.e <= now && now - m.e < DAY);
  const pend = all.filter((m) => metaStat(m, now).st === 'pending');
  if (!soon.length && !gone.length && !pend.length) return;
  let t = '🗓 <b>گزارش روزانه</b>\n';
  if (pend.length) t += `\n🟡 در انتظار تأیید (${fa(pend.length)}):\n` + pend.slice(0, 10).map((m) => lineOf(m, now)).join('\n') + '\n';
  if (soon.length) t += `\n⏰ تا ۳ روز دیگر منقضی می‌شوند (${fa(soon.length)}):\n` + soon.slice(0, 15).map((m) => lineOf(m, now)).join('\n') + '\n';
  if (gone.length) t += `\n🔴 دیروز/امروز منقضی شدند (${fa(gone.length)}):\n` + gone.slice(0, 15).map((m) => lineOf(m, now)).join('\n');
  await say(C, t);
}

// ---------- entry ----------
export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);
    try {
      if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
      const C = cfg(env);
      const text = (s, status = 200) => new Response(s, { status, headers: { 'content-type': 'text/plain; charset=utf-8' } });

      if (url.pathname === '/setup') {
        if (!C) return text('❌ تنظیمات ناقص است: BOT_TOKEN, ADMIN_ID, WEBHOOK_SECRET, SIGN_KEY و KV binding با نام DB را بررسی کنید.', 500);
        if (!safeEq(url.searchParams.get('key'), C.hook)) return text('forbidden — آدرس را با ?key=WEBHOOK_SECRET باز کنید', 403);
        const hook = await tg(C, 'setWebhook', { url: url.origin + '/tg', secret_token: C.hook, allowed_updates: ['message', 'callback_query'], drop_pending_updates: true });
        await tg(C, 'setMyCommands', { commands: [
          { command: 'pending', description: 'درخواست‌های در انتظار' },
          { command: 'users', description: 'فهرست کاربران' },
          { command: 'find', description: 'جستجوی کاربر' },
          { command: 'expiring', description: 'نزدیک به انقضا' },
          { command: 'stats', description: 'آمار' },
          { command: 'export', description: 'خروجی فهرست کاربران' },
          { command: 'help', description: 'راهنما' },
        ] });
        if (hook.ok) await say(C, '✅ سرور لایسنس RadLedger فعال شد.\n/help');
        return text(hook.ok ? '✅ OK — ربات متصل شد. به تلگرام بروید و /start بزنید.' : '❌ ' + JSON.stringify(hook), hook.ok ? 200 : 500);
      }

      if (url.pathname.startsWith('/api/') || url.pathname === '/tg') {
        if (!C) return json({ error: 'server not configured' }, 500);
        if (url.pathname === '/api/status' && req.method === 'GET') return await apiStatus(env, C, url);
        if (url.pathname === '/api/register' && req.method === 'POST') return await apiRegister(env, C, ctx, req);
        if (url.pathname === '/tg' && req.method === 'POST') {
          if (!safeEq(req.headers.get('X-Telegram-Bot-Api-Secret-Token'), C.hook)) return new Response('forbidden', { status: 403 });
          try {
            const u = await req.json();
            if (u.message) await onMessage(env, C, u.message);
            else if (u.callback_query) await onCallback(env, C, u.callback_query);
          } catch (e) { /* همیشه 200 تا تلگرام آپدیت را دوباره نفرستد */ }
          return new Response('ok');
        }
      }
      return text('RadLedger license server — OK');
    } catch (e) {
      return json({ error: 'server error' }, 500);
    }
  },

  async scheduled(event, env, ctx) {
    const C = cfg(env);
    if (C) ctx.waitUntil(daily(env, C));
  },
};
