import type { ChapterProgress, ScheduleItem, StudentProfile } from '../shared/types';
import { addDays, clamp, nowISO, parseJSON, todayISO } from './lib';

export const DEFAULT_PROFILE: StudentProfile = {
  userId: 1,
  name: 'Student',
  email: 'student@edumentor.ai',
  exam: 'cbse10',
  examLabel: 'CBSE Class 10 Board Exam',
  examDate: addDays(todayISO(), 90),
  classLevel: '10',
  board: 'CBSE',
  targetScore: '95%',
  dailyHours: 3.5,
  schoolStart: '07:30',
  schoolEnd: '14:00',
  coachingStart: null,
  coachingEnd: null,
  sleepAt: '23:00',
  wakeAt: '06:30',
  preferredStart: '17:00',
  preferredEnd: '21:00',
  subjects: ['Mathematics', 'Science', 'Social Science', 'English'],
  weakSubjects: ['Mathematics'],
  strongSubjects: ['Science'],
  learningStyle: 'Step-by-step explanations with worked examples',
  currentPerformance: 'Around 80% in school tests',
  commitments: '',
  onboarded: true,
  createdAt: nowISO(),
};

export async function getProfile(db: D1Database, userId: number): Promise<StudentProfile> {
  if (!db) return DEFAULT_PROFILE;
  try {
    const row = await db.prepare('SELECT data FROM profiles WHERE user_id = ?').bind(userId).first<{ data: string }>();
    if (!row) return DEFAULT_PROFILE;
    const data = parseJSON<StudentProfile | null>(row.data, null);
    return data ? { ...data, userId } : DEFAULT_PROFILE;
  } catch {
    return DEFAULT_PROFILE;
  }
}

export async function saveProfile(db: D1Database, userId: number, profile: StudentProfile): Promise<void> {
  if (!db) return;
  try {
    await db
      .prepare('INSERT INTO profiles (user_id, data, updated_at) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at')
      .bind(userId, JSON.stringify(profile), nowISO())
      .run();
  } catch (err) {
    console.warn('[store] Failed to save profile to database:', err);
  }
}

/**
 * Creates chapter_progress rows for every chapter in the student's syllabus.
 * Uses INSERT OR IGNORE so existing progress is never overwritten.
 */
export async function seedChapters(
  db: D1Database,
  userId: number,
  rows: { subject: string; chapter: string }[],
): Promise<void> {
  if (!db || !rows.length) return;
  try {
    const ts = nowISO();
    const statements = rows.map((r) =>
      db
        .prepare(
          `INSERT OR IGNORE INTO chapter_progress (user_id, subject, chapter, status, mastery, updated_at)
           VALUES (?, ?, ?, 'not-started', 0, ?)`,
        )
        .bind(userId, r.subject, r.chapter, ts),
    );
    for (let i = 0; i < statements.length; i += 60) {
      await db.batch(statements.slice(i, i + 60)).catch(() => {});
    }
  } catch (err) {
    console.warn('[store] seedChapters warning:', err);
  }
}

export async function listProgress(db: D1Database, userId: number): Promise<ChapterProgress[]> {
  if (!db) return [];
  try {
    const { results } = await db
      .prepare(
        `SELECT id, subject, chapter, status, mastery, last_studied, next_review, interval_days, ease, repetitions
         FROM chapter_progress WHERE user_id = ? ORDER BY subject, chapter`,
      )
      .bind(userId)
      .all<{
        id: number;
        subject: string;
        chapter: string;
        status: string;
        mastery: number;
        last_studied: string | null;
        next_review: string | null;
        interval_days: number;
        ease: number;
        repetitions: number;
      }>();
    return (results ?? []).map((r) => ({
      id: r.id,
      subject: r.subject,
      chapter: r.chapter,
      status: r.status as ChapterProgress['status'],
      mastery: r.mastery,
      lastStudied: r.last_studied,
      nextReview: r.next_review,
      intervalDays: r.interval_days,
      ease: r.ease,
      repetitions: r.repetitions,
    }));
  } catch {
    return [];
  }
}

/**
 * SM-2-lite scheduling shared by chapter mastery and flashcards.
 * grade: 0 = forgot, 1 = hard, 2 = good, 3 = easy.
 */
export function nextSchedule(
  card: { ease: number; intervalDays: number; repetitions: number },
  grade: number,
): { ease: number; intervalDays: number; repetitions: number; due: string } {
  let { ease, intervalDays, repetitions } = card;
  ease = clamp(ease + (grade === 0 ? -0.3 : grade === 1 ? -0.15 : grade === 3 ? 0.15 : 0), 1.3, 3.1);
  if (grade === 0) {
    repetitions = 0;
    intervalDays = 0.5;
  } else {
    repetitions += 1;
    if (repetitions === 1) intervalDays = grade === 3 ? 2 : 1;
    else if (repetitions === 2) intervalDays = grade === 3 ? 5 : 3;
    else intervalDays = Math.round(intervalDays * ease * (grade === 1 ? 0.7 : 1) * 10) / 10;
    intervalDays = clamp(intervalDays, 1, 120);
  }
  return {
    ease: Math.round(ease * 100) / 100,
    intervalDays,
    repetitions,
    due: addDays(todayISO(), Math.max(1, Math.round(intervalDays))),
  };
}

export async function recordStudy(
  db: D1Database,
  userId: number,
  minutes: number,
  subject: string | null,
  chapter: string | null,
  source = 'timer',
): Promise<void> {
  if (!db || minutes <= 0) return;
  try {
    await db
      .prepare(
        'INSERT INTO study_sessions (user_id, date, minutes, subject, chapter, source, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      )
      .bind(userId, todayISO(), Math.round(clamp(minutes, 1, 720)), subject, chapter, source, nowISO())
      .run();
  } catch {}
}

export async function studyStreak(db: D1Database, userId: number): Promise<number> {
  if (!db) return 1;
  try {
    const { results } = await db
      .prepare(
        `SELECT DISTINCT date FROM (
           SELECT date FROM study_sessions WHERE user_id = ? AND minutes > 0
           UNION SELECT date FROM schedule_items WHERE user_id = ? AND status = 'done'
         ) ORDER BY date DESC LIMIT 400`,
      )
      .bind(userId, userId)
      .all<{ date: string }>();
    const dates = new Set((results ?? []).map((r) => r.date));
    let streak = 0;
    let cursor = todayISO();
    if (!dates.has(cursor)) cursor = addDays(cursor, -1);
    while (dates.has(cursor)) {
      streak += 1;
      cursor = addDays(cursor, -1);
    }
    return Math.max(1, streak);
  } catch {
    return 1;
  }
}

export async function scheduleItems(
  db: D1Database,
  userId: number,
  from: string,
  to: string,
): Promise<ScheduleItem[]> {
  if (!db) return [];
  try {
    const { results } = await db
      .prepare(
        `SELECT * FROM schedule_items WHERE user_id = ? AND date >= ? AND date <= ?
         ORDER BY date, start_time`,
      )
      .bind(userId, from, to)
      .all<Record<string, unknown>>();
    return (results ?? []).map(mapScheduleRow);
  } catch {
    return [];
  }
}

export function mapScheduleRow(r: Record<string, unknown>): ScheduleItem {
  return {
    id: Number(r.id),
    date: String(r.date),
    startTime: String(r.start_time),
    endTime: String(r.end_time),
    title: String(r.title),
    kind: String(r.kind) as ScheduleItem['kind'],
    subject: (r.subject as string) ?? null,
    chapter: (r.chapter as string) ?? null,
    status: String(r.status) as ScheduleItem['status'],
    priority: Number(r.priority ?? 2),
    notes: (r.notes as string) ?? null,
    planId: r.plan_id == null ? null : Number(r.plan_id),
  };
}

export function minutesBetweenTimes(start: string, end: string): number {
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  return Math.max(0, eh * 60 + em - (sh * 60 + sm));
}

export function addMinutesToTime(time: string, minutes: number): string {
  const [h, m] = time.split(':').map(Number);
  const total = h * 60 + m + minutes;
  return `${String(Math.floor((total % 1440) / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}
