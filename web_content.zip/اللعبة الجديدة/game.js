(() => {

"use strict";

/* =====================================================
   من الصفر إلى الملك 3D
   إصدار GLB للشخصية
   ===================================================== */

const canvas = document.getElementById("world");
const $ = id => document.getElementById(id);

const state = {
    gold: 100,
    wood: 0,
    stone: 0,
    land: 1,
    population: 1,
    houses: 0,
    largeHouses: 0,
    income: 0,
    ironAxe: false,
    stonePick: false,
    pickUpgrade1: false,
    pickUpgrade2: false,
    oreUpgrade: false,
    paused: false,
    expansion: 0,
    woodHits: 8,
    lastTool: 0,
    usedCodes: {}
};

const expansionPrices = [100, 350, 680, 980, 1430];

/* =====================================================
   THREE.JS
   ===================================================== */

const scene = new THREE.Scene();

/* =====================================================
   نظام الصوت — موسيقى هادئة + مؤثرات الموارد
   ===================================================== */

const audioSystem = {
    music: null,
    wood: null,
    stone: null,
    ready: false,
    unlocked: false
};

function initAudio() {
    try {
        audioSystem.music = new Audio("./music.wav");
        audioSystem.wood = new Audio("./wood_break.wav");
        audioSystem.stone = new Audio("./stone_break.wav");

        audioSystem.music.loop = true;
        audioSystem.music.volume = 0.72;
        audioSystem.wood.volume = 0.78;
        audioSystem.stone.volume = 0.78;

        audioSystem.ready = true;
    } catch (e) {
        console.warn("تعذر تجهيز الصوت", e);
    }
}

function unlockAudio() {
    if (!audioSystem.ready || audioSystem.unlocked) return;
    audioSystem.unlocked = true;

    const p = audioSystem.music.play();
    if (p && p.catch) p.catch(() => { audioSystem.unlocked = false; });
}

function playSfx(type) {
    if (!audioSystem.ready) return;

    const src = type === "wood" ? audioSystem.wood : audioSystem.stone;
    if (!src) return;

    try {
        const s = src.cloneNode(true);
        s.volume = src.volume;
        s.play().catch(() => {});
    } catch (e) {}
}

initAudio();

document.addEventListener("pointerdown", unlockAudio, { passive: true });
document.addEventListener("touchstart", unlockAudio, { passive: true });
document.addEventListener("keydown", unlockAudio);

scene.background = new THREE.Color(0x79c7e5);
scene.fog = new THREE.Fog(0x79c7e5, 260, 1050);

const camera = new THREE.PerspectiveCamera(62, 1, 0.05, 1600);
camera.position.set(0, 17, 25);

const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    powerPreference: "high-performance"
});

renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

/* =====================================================
   الإضاءة
   ===================================================== */

const ambient = new THREE.HemisphereLight(0xffffff, 0x4d7045, 1.25);
scene.add(ambient);

const sun = new THREE.DirectionalLight(0xffffff, 1.6);
sun.position.set(40, 80, 30);
sun.castShadow = true;

sun.shadow.mapSize.width = 1536;
sun.shadow.mapSize.height = 1536;

scene.add(sun);

/* =====================================================
   العالم
   ===================================================== */

const world = new THREE.Group();
scene.add(world);

const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(3040, 1920),
    new THREE.MeshStandardMaterial({ color: 0x4c963f, roughness: 1 })
);

ground.rotation.x = -Math.PI / 2;
ground.receiveShadow = true;
world.add(ground);

const road = new THREE.Mesh(
    new THREE.PlaneGeometry(13, 1920),
    new THREE.MeshStandardMaterial({ color: 0x92724d })
);

road.rotation.x = -Math.PI / 2;
road.position.y = 0.015;
world.add(road);

/* =====================================================
   دائرة البناء
   ===================================================== */

const buildCircle = new THREE.Mesh(
    new THREE.RingGeometry(15, 15.2, 64),
    new THREE.MeshBasicMaterial({
        color: 0x123a78,
        transparent: true,
        opacity: 0.65,
        side: THREE.DoubleSide
    })
);

buildCircle.rotation.x = -Math.PI / 2;
buildCircle.position.set(0, 0.04, 20);
world.add(buildCircle);

/* =====================================================
   المصفوفات
   ===================================================== */

const trees = [];
const rocks = [];
const buildings = [];
const npcs = [];

/* =====================================================
   أدوات مساعدة
   ===================================================== */

function rnd(a, b) {
    return a + Math.random() * (b - a);
}

function clamp(v, a, b) {
    return Math.max(a, Math.min(b, v));
}

function show(text) {
    const msg = $("message");
    msg.textContent = text;
    msg.style.opacity = "1";

    clearTimeout(show.timer);
    show.timer = setTimeout(() => {
        msg.style.opacity = "0";
    }, 1600);
}

function insideBuild(x, z) {
    const radius = 15 + state.expansion * 2.9;
    return Math.hypot(x, z - 20) <= radius;
}

/* =====================================================
   تحميل GLTFLoader + SkeletonUtils
   ===================================================== */

function loadScript(src) {
    return new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = src;
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
    });
}

async function prepareGLBTools() {
    if (!THREE.GLTFLoader) {
        await loadScript(
            "https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js"
        );
    }

    if (!THREE.SkeletonUtils) {
        await loadScript(
            "https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/utils/SkeletonUtils.js"
        );
    }
}

/* =====================================================
   الشخصية
   ===================================================== */

const PLAYER_MODEL_URL = "./male-adventurer.glb";

let characterTemplate = null;
let characterAnimations = [];

function findAnimation(animations, patterns) {
    for (const pattern of patterns) {
        const found = animations.find(anim => {
            const name = (anim.name || "").toLowerCase();
            return name.includes(pattern);
        });

        if (found) return found;
    }

    return null;
}

/* =====================================================
   معلومات Animation
   ===================================================== */

const animationNames = {
    idle: null,
    walk: null,
    run: null,
    chop: null,
    mine: null
};

/* =====================================================
   تحميل الشخصية
   ===================================================== */

async function loadCharacter() {
    try {
        await prepareGLBTools();

        const loader = new THREE.GLTFLoader();

        const gltf = await new Promise((resolve, reject) => {
            loader.load(PLAYER_MODEL_URL, resolve, undefined, reject);
        });

        characterTemplate = gltf.scene;
        characterAnimations = gltf.animations || [];

        animationNames.idle = findAnimation(characterAnimations, ["idle", "stand", "breath", "wait"]);
        animationNames.walk = findAnimation(characterAnimations, ["walk", "walking"]);
        animationNames.run = findAnimation(characterAnimations, ["run", "running", "jog"]);
        animationNames.chop = findAnimation(characterAnimations, ["chop", "axe", "attack", "hit"]);
        animationNames.mine = findAnimation(characterAnimations, ["mine", "mining", "pickaxe", "pick", "attack"]);

        characterTemplate.traverse(object => {
            if (object.isMesh) {
                object.castShadow = true;
                object.receiveShadow = true;
                if (object.material) {
                    object.material.needsUpdate = true;
                }
            }
        });

        console.log("Animations:", characterAnimations.map(a => a.name));
        return true;
    } catch (error) {
        console.error("تعذر تحميل male-adventurer.glb", error);
        show("❌ تعذر تحميل male-adventurer.glb");
        return false;
    }
}

/* =====================================================
   إنشاء نسخة شخصية
   ===================================================== */

function createGLBCharacter(scale = 1) {
    /*
       نستخدم شخصية رجل ثلاثية الأبعاد مضمونة الظهور.
       إذا كان ملف GLB صالحًا فسيُستخدم، وإلا يتم إنشاء
       رجل 3D محليًا حتى لا تتوقف اللعبة بسبب ملف خارجي.
    */
    if (characterTemplate) {
        try {
            const model = THREE.SkeletonUtils.clone(characterTemplate);
            model.scale.set(scale, scale, scale);
            model.traverse(o => {
                if (o.isMesh) {
                    o.castShadow = true;
                    o.receiveShadow = true;
                }
            });
            model.userData.isProceduralMale = false;
            return model;
        } catch (e) {
            console.warn("GLB clone failed, using procedural male", e);
        }
    }

    const male = new THREE.Group();
    male.scale.set(scale, scale, scale);
    male.userData.isProceduralMale = true;

    const skin = new THREE.MeshStandardMaterial({ color: 0xc98b62, roughness: 0.8 });
    const shirt = new THREE.MeshStandardMaterial({ color: 0x315fa8, roughness: 0.9 });
    const pants = new THREE.MeshStandardMaterial({ color: 0x26324a, roughness: 0.9 });
    const boots = new THREE.MeshStandardMaterial({ color: 0x3b261c, roughness: 1 });
    const hair = new THREE.MeshStandardMaterial({ color: 0x24180f, roughness: 1 });

    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.15, 0.5), shirt);
    torso.name = "torso";
    torso.position.y = 1.45;
    torso.castShadow = true;
    male.add(torso);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.34, 16, 12), skin);
    head.position.y = 2.35;
    head.castShadow = true;
    male.add(head);

    const hairCap = new THREE.Mesh(
        new THREE.SphereGeometry(0.35, 16, 8, 0, Math.PI * 2, 0, Math.PI * 0.48),
        hair
    );
    hairCap.position.y = 2.48;
    hairCap.castShadow = true;
    male.add(hairCap);

    const armL = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.95, 0.25), shirt);
    armL.name = "armL";
    armL.position.set(-0.58, 1.5, 0);
    armL.rotation.z = -0.08;
    armL.castShadow = true;
    male.add(armL);

    const armR = armL.clone();
    armR.name = "armR";
    armR.position.x = 0.58;
    armR.rotation.z = 0.08;
    male.add(armR);

    const handL = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), skin);
    handL.position.set(-0.59, 0.98, 0);
    handL.castShadow = true;
    male.add(handL);

    const handR = handL.clone();
    handR.position.x = 0.59;
    male.add(handR);

    const legL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.9, 0.32), pants);
    legL.name = "legL";
    legL.position.set(-0.23, 0.65, 0);
    legL.castShadow = true;
    male.add(legL);

    const legR = legL.clone();
    legR.name = "legR";
    legR.position.x = 0.23;
    male.add(legR);

    const bootL = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.25, 0.5), boots);
    bootL.position.set(-0.23, 0.15, -0.07);
    bootL.castShadow = true;
    male.add(bootL);

    const bootR = bootL.clone();
    bootR.position.x = 0.23;
    male.add(bootR);

    male.position.y = 0;
    return male;
}

/* =====================================================
   نظام Animation للشخصية
   ===================================================== */

function setupCharacterAnimation(group) {
    group.userData.mixer = null;

    if (!characterAnimations.length) return;

    const mixer = new THREE.AnimationMixer(group);
    group.userData.mixer = mixer;
    group.userData.actions = {};

    for (const animation of characterAnimations) {
        const action = mixer.clipAction(animation);
        group.userData.actions[animation.name] = action;
    }

    group.userData.currentAnimation = null;
}

function playCharacterAnimation(group, type, loop = true) {
    if (!group) return;

    const mixer = group.userData.mixer;
    const actions = group.userData.actions;

    if (!mixer || !actions) return;

    let clip = null;

    if (type === "idle") clip = animationNames.idle;
    if (type === "walk") clip = animationNames.walk || animationNames.run;
    if (type === "run") clip = animationNames.run || animationNames.walk;
    if (type === "chop") clip = animationNames.chop;
    if (type === "mine") clip = animationNames.mine;

    if (!clip) return;

    if (group.userData.currentAnimation === clip.name) return;

    const newAction = actions[clip.name];
    if (!newAction) return;

    if (group.userData.currentAction) {
        group.userData.currentAction.fadeOut(0.15);
    }

    newAction.reset();
    newAction.enabled = true;
    newAction.setLoop(loop ? THREE.LoopRepeat : THREE.LoopOnce, loop ? Infinity : 1);
    newAction.clampWhenFinished = !loop;
    newAction.fadeIn(0.15);
    newAction.play();

    group.userData.currentAction = newAction;
    group.userData.currentAnimation = clip.name;

    if (!loop) {
        const duration = clip.duration * 1000;
        clearTimeout(group.userData.animationTimer);

        group.userData.animationTimer = setTimeout(() => {
            playCharacterAnimation(group, group.userData.moving ? "walk" : "idle", true);
        }, duration);
    }
}

/* =====================================================
   اللاعب
   ===================================================== */

const player = new THREE.Group();
player.position.set(0, 0, 20);
world.add(player);

player.userData = {
    moving: false,
    walk: 0,
    actionGroup: null
};

/* =====================================================
   إنشاء اللاعب
   ===================================================== */

function createMainCharacter() {
    const model = createGLBCharacter(1);
    model.position.y = 0;
    player.add(model);

    setupCharacterAnimation(model);
    player.userData.actionGroup = model;

    playCharacterAnimation(model, "idle", true);
    return model;
}

/* =====================================================
   NPC
   ===================================================== */

function createNPC() {
    const npc = new THREE.Group();
    const model = createGLBCharacter(0.72);
    npc.add(model);
    setupCharacterAnimation(model);

    npc.userData = {
        targetX: 0,
        targetZ: 20,
        speed: rnd(0.5, 1.2),
        phase: rnd(0, Math.PI * 2),
        home: null,
        moving: false,
        actionGroup: model
    };

    playCharacterAnimation(model, "idle", true);
    return npc;
}

/* =====================================================
   الأشجار
   ===================================================== */

function createTree(x, z) {
    const tree = new THREE.Group();

    const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.22, 0.3, 2, 8),
        new THREE.MeshStandardMaterial({ color: 0x704526 })
    );

    trunk.position.y = 1;
    trunk.castShadow = true;
    tree.add(trunk);

    const leaves = new THREE.Mesh(
        new THREE.ConeGeometry(1.25, 3.2, 8),
        new THREE.MeshStandardMaterial({ color: 0x246a32 })
    );

    leaves.position.y = 3;
    leaves.castShadow = true;
    tree.add(leaves);

    tree.position.set(x, 0, z);

    tree.userData = {
        hp: state.woodHits,
        max: state.woodHits
    };

    world.add(tree);
    trees.push(tree);
}

/* =====================================================
   الصخور
   ===================================================== */

function rarityRock() {
    const r = Math.random();

    if (r < 0.08) {
        return { kind: "very", hp: 84, max: 84, gain: 130 };
    }

    if (r < (state.oreUpgrade ? 0.59 : 0.39)) {
        return { kind: "good", hp: 45, max: 45, gain: 100 };
    }

    return { kind: "normal", hp: 11, max: 11, gain: 20 };
}

function createRock(x, z) {
    const data = rarityRock();

    let color = 0x777c7b;
    if (data.kind === "good") color = 0xe0c24c;
    if (data.kind === "very") color = 0x7b5cff;

    const rock = new THREE.Mesh(
        new THREE.DodecahedronGeometry(0.9, 0),
        new THREE.MeshStandardMaterial({ color, roughness: 0.9 })
    );

    rock.position.set(x, 0.75, z);
    rock.scale.set(1.25, 0.8, 1);
    rock.rotation.y = rnd(0, Math.PI);
    rock.castShadow = true;
    rock.userData = data;

    world.add(rock);
    rocks.push(rock);
}

/* =====================================================
   العالم
   ===================================================== */

function createWorld() {
    for (let i = 0; i < 2500; i++) {
        createTree(rnd(-1450, 1450), rnd(-950, 950));
    }

    for (let i = 0; i < 1000; i++) {
        createRock(rnd(-1450, 1450), rnd(-950, 950));
    }
}

/* =====================================================
   أقرب مورد
   ===================================================== */

function nearest(array, range = 6) {
    let best = null;
    let bestDistance = range;

    for (const object of array) {
        const d = Math.hypot(
            object.position.x - player.position.x,
            object.position.z - player.position.z
        );

        if (d < bestDistance) {
            bestDistance = d;
            best = object;
        }
    }

    return best;
}

/* =====================================================
   حركة الشخصية المحلية
   ===================================================== */

function animateProceduralCharacter(group, moving, dt, action) {
    if (!group || !group.userData.isProceduralMale) return;

    group.userData.animTime = (group.userData.animTime || 0) + (dt || 0);
    const t = group.userData.animTime;
    const speed = moving ? 9 : 2.2;
    const swing = moving ? Math.sin(t * speed) * 0.45 : Math.sin(t * speed) * 0.025;

    const armL = group.getObjectByName("armL");
    const armR = group.getObjectByName("armR");
    const legL = group.getObjectByName("legL");
    const legR = group.getObjectByName("legR");
    const torso = group.getObjectByName("torso");

    if (action === "chop" || action === "mine") {
        if (armR) armR.rotation.x = -0.9 + Math.sin(t * 14) * 0.55;
        if (armL) armL.rotation.x = -0.65 + Math.sin(t * 14) * 0.45;
    } else {
        if (armL) armL.rotation.x = swing;
        if (armR) armR.rotation.x = -swing;
        if (legL) legL.rotation.x = -swing;
        if (legR) legR.rotation.x = swing;
    }

    if (torso) {
        torso.position.y = 1.45 + (moving ? Math.abs(Math.sin(t * speed)) * 0.035 : 0);
    }
}

/* =====================================================
   حركة ضربة اللاعب
   ===================================================== */

function playerToolAnimation(type) {
    const model = player.userData.actionGroup;
    if (!model) return;
    playCharacterAnimation(model, type, false);
}

/* =====================================================
   إعادة إنشاء الموارد
   ===================================================== */

function respawnTree() {
    const angle = Math.random() * Math.PI * 2;
    const radius = 250 + Math.random() * 1250;
    createTree(Math.cos(angle) * radius, Math.sin(angle) * 820);
}

function respawnRock() {
    const angle = Math.random() * Math.PI * 2;
    const radius = 250 + Math.random() * 1250;
    createRock(Math.cos(angle) * radius, Math.sin(angle) * 620);
}

/* =====================================================
   قطع الأشجار
   ===================================================== */

function chop() {
    if (state.paused) return;

    const now = performance.now();
    if (now - state.lastTool < 500) return;
    state.lastTool = now;

    const tree = nearest(trees);

    if (!tree) {
        show("🪓 اقترب من شجرة");
        return;
    }

    playerToolAnimation("chop");
    playSfx("wood");

    tree.userData.hp--;
    tree.rotation.z = 0.12;

    setTimeout(() => {
        if (tree.parent) tree.rotation.z = 0;
    }, 100);

    if (tree.userData.hp > 0) {
        show("🪓 ضربة • المتبقي " + tree.userData.hp + "/" + tree.userData.max);
        return;
    }

    state.wood += 5;

    const index = trees.indexOf(tree);
    if (index >= 0) trees.splice(index, 1);

    world.remove(tree);
    setTimeout(respawnTree, 120);

    show("🪵 +5 خشب");

    save();
    updateUI();
}

/* =====================================================
   تعدين الحجر
   ===================================================== */

function mine() {
    if (state.paused) return;

    if (!state.stonePick) {
        show("⛏️ اشترِ فأس الحجر أولًا");
        return;
    }

    const now = performance.now();
    if (now - state.lastTool < 500) return;
    state.lastTool = now;

    const rock = nearest(rocks);

    if (!rock) {
        show("⛏️ اقترب من صخرة");
        return;
    }

    playerToolAnimation("mine");
    playSfx("stone");

    const damage = state.pickUpgrade2 ? 4 : state.pickUpgrade1 ? 2 : 1;
    rock.userData.hp -= damage;
    rock.scale.multiplyScalar(0.96);

    setTimeout(() => {
        if (rock.parent) {
            rock.scale.x += 0.05;
            rock.scale.y += 0.05;
            rock.scale.z += 0.05;
        }
    }, 80);

    if (rock.userData.hp > 0) {
        show("⛏️ ضربة • المتبقي " + rock.userData.hp + "/" + rock.userData.max);
        return;
    }

    const bonus = state.pickUpgrade2 ? 1.25 : state.pickUpgrade1 ? 1.15 : 1;
    const amount = Math.round(rock.userData.gain * bonus);

    state.stone += amount;

    const index = rocks.indexOf(rock);
    if (index >= 0) rocks.splice(index, 1);

    world.remove(rock);
    setTimeout(respawnRock, 120);

    show("🪨 +" + amount + " حجر");

    save();
    updateUI();
}

/* =====================================================
   البيوت
   ===================================================== */

function createHouse(type, x, z) {
    const house = new THREE.Group();
    const big = type === "large";
    const width = big ? 4 : 3;
    const height = big ? 2.8 : 2.3;

    const body = new THREE.Mesh(
        new THREE.BoxGeometry(width, height, width),
        new THREE.MeshStandardMaterial({ color: 0x9a7650 })
    );

    body.position.y = height / 2;
    body.castShadow = true;
    house.add(body);

    const roof = new THREE.Mesh(
        new THREE.ConeGeometry(big ? 3.1 : 2.4, big ? 2 : 1.6, 4),
        new THREE.MeshStandardMaterial({ color: 0x71392f })
    );

    roof.position.y = height + (big ? 0.8 : 0.6);
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;
    house.add(roof);

    const door = new THREE.Mesh(
        new THREE.BoxGeometry(0.65, 1.1, 0.08),
        new THREE.MeshStandardMaterial({ color: 0x4b2b20 })
    );

    door.position.set(0, 0.55, -width / 2 - 0.05);
    house.add(door);

    house.position.set(x, 0, z);
    house.userData = { type };

    world.add(house);
    buildings.push(house);
}

/* =====================================================
   البناء
   ===================================================== */

function recalculateIncome() {
    // الدخل الحقيقي يعتمد مباشرة على عدد البيوت:
    // المنزل الصغير = +1 عملة/ثانية، والمنزل الكبير = +3 عملات/ثانية.
    state.houses = Math.max(0, Number(state.houses) || 0);
    state.largeHouses = Math.max(0, Number(state.largeHouses) || 0);
    state.income = state.houses + (state.largeHouses * 3);
}

function addHouseIncome(type) {
    state.income += type === "large" ? 3 : 1;
}

function removeHouseIncome(type) {
    state.income = Math.max(0, state.income - (type === "large" ? 3 : 1));
}

function addBuilding(type) {
    const cost = type === "small" ? 40 : 100;

    if (state.gold < cost) {
        show("❌ لا تملك ما يكفي من العملات");
        return;
    }

    if (!insideBuild(player.position.x, player.position.z)) {
        show("🚫 قف داخل منطقة البناء");
        return;
    }

    const radius = type === "small" ? 2.2 : 3;

    for (const b of buildings) {
        const d = Math.hypot(
            b.position.x - player.position.x,
            b.position.z - player.position.z
        );

        const otherRadius = b.userData.type === "small" ? 2.2 : 3;

        if (d < radius + otherRadius + 1) {
            show("🚫 المكان مشغول");
            return;
        }
    }

    state.gold -= cost;

    if (type === "small") {
        state.houses++;
        state.population++;
        addHouseIncome("small");
    } else {
        state.largeHouses++;
        state.population += 3;
        addHouseIncome("large");
    }

    createHouse(type, player.position.x, player.position.z);
    syncNPCs();

    save();
    updateUI();

    show(type === "small" ? "🏠 +1 ساكن" : "🏡 +3 سكان");
}

/* =====================================================
   السكان
   ===================================================== */

function syncNPCs() {
    while (npcs.length < state.population) {
        const npc = createNPC();

        npc.position.set(rnd(-10, 10), 0, rnd(10, 30));
        npc.userData.targetX = npc.position.x;
        npc.userData.targetZ = npc.position.z;

        world.add(npc);
        npcs.push(npc);
    }

    while (npcs.length > state.population) {
        const npc = npcs.pop();
        world.remove(npc);
    }
}

/* =====================================================
   حركة السكان
   ===================================================== */

function updateNPCs(dt) {
    for (const npc of npcs) {
        const data = npc.userData;
        data.phase += dt * data.speed;

        if (
            Math.hypot(
                npc.position.x - data.targetX,
                npc.position.z - data.targetZ
            ) < 0.7
        ) {
            data.targetX = rnd(-12, 12);
            data.targetZ = rnd(10, 35);
        }

        const dx = data.targetX - npc.position.x;
        const dz = data.targetZ - npc.position.z;
        const len = Math.hypot(dx, dz);

        if (len > 0.01) {
            data.moving = true;

            npc.position.x += (dx / len) * data.speed * dt;
            npc.position.z += (dz / len) * data.speed * dt;

            npc.rotation.y = Math.atan2(dx, dz);

            playCharacterAnimation(data.actionGroup, "walk", true);

            if (data.actionGroup.userData.mixer) {
                data.actionGroup.userData.mixer.update(dt);
            }

            animateProceduralCharacter(data.actionGroup, true, dt, null);
        } else {
            data.moving = false;

            playCharacterAnimation(data.actionGroup, "idle", true);

            if (data.actionGroup.userData.mixer) {
                data.actionGroup.userData.mixer.update(dt);
            }

            animateProceduralCharacter(data.actionGroup, false, dt, null);
        }
    }
}

/* =====================================================
   أزرار الحركة
   ===================================================== */

const keys = {
    up: false,
    down: false,
    left: false,
    right: false
};

function movePlayer(dt) {
    let forward = 0;
    let strafe = 0;

    if (keys.up) forward++;
    if (keys.down) forward--;
    if (keys.left) strafe--;
    if (keys.right) strafe++;

    const model = player.userData.actionGroup;

    if (!forward && !strafe) {
        player.userData.moving = false;

        if (model) {
            playCharacterAnimation(model, "idle", true);
        }

        return;
    }

    player.userData.moving = true;

    const len = Math.hypot(forward, strafe);
    forward /= len;
    strafe /= len;

    const fx = -Math.sin(cameraState.yaw);
    const fz = -Math.cos(cameraState.yaw);
    const rx = Math.cos(cameraState.yaw);
    const rz = -Math.sin(cameraState.yaw);

    const speed = 12;
    const moveX = fx * forward + rx * strafe;
    const moveZ = fz * forward + rz * strafe;

    player.position.x += moveX * speed * dt;
    player.position.z += moveZ * speed * dt;

    player.position.x = clamp(player.position.x, -1450, 1450);
    player.position.z = clamp(player.position.z, -950, 950);

    if (Math.abs(moveX) + Math.abs(moveZ) > 0.001) {
        player.rotation.y = Math.atan2(moveX, moveZ);
    }

    player.userData.walk += dt * 14;

    if (model) {
        playCharacterAnimation(model, "walk", true);
    }
}

/* =====================================================
   الكاميرا
   ===================================================== */

const cameraState = {
    yaw: 0,
    pitch: 0.55,
    distance: 25,
    minDistance: 9,
    maxDistance: 78,
    minPitch: 0.08,
    maxPitch: 1.25,
    targetHeight: 1.35,
    dragging: false,
    lastX: 0,
    lastY: 0,
    pointers: new Map(),
    pinchStartDistance: 0,
    pinchStartCameraDistance: 25
};

function updateCamera() {
    const target = new THREE.Vector3(
        player.position.x,
        cameraState.targetHeight,
        player.position.z
    );

    const horizontal = Math.cos(cameraState.pitch) * cameraState.distance;
    const vertical = Math.sin(cameraState.pitch) * cameraState.distance;

    const desired = new THREE.Vector3(
        target.x + Math.sin(cameraState.yaw) * horizontal,
        target.y + vertical,
        target.z + Math.cos(cameraState.yaw) * horizontal
    );

    camera.position.lerp(desired, 0.16);
    camera.lookAt(target);
}

/* =====================================================
   لمس الكاميرا
   ===================================================== */

function pointerDistance() {
    const p = [...cameraState.pointers.values()];
    if (p.length < 2) return 0;

    return Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y);
}

canvas.addEventListener("pointerdown", e => {
    cameraState.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

    try {
        canvas.setPointerCapture(e.pointerId);
    } catch (_) {}

    if (cameraState.pointers.size === 1) {
        cameraState.dragging = true;
        cameraState.lastX = e.clientX;
        cameraState.lastY = e.clientY;
    } else if (cameraState.pointers.size === 2) {
        cameraState.pinchStartDistance = pointerDistance();
        cameraState.pinchStartCameraDistance = cameraState.distance;
        cameraState.dragging = false;
    }
});

canvas.addEventListener("pointermove", e => {
    if (!cameraState.pointers.has(e.pointerId)) return;

    cameraState.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (cameraState.pointers.size >= 2) {
        const d = pointerDistance();

        if (cameraState.pinchStartDistance > 0 && d > 0) {
            const ratio = cameraState.pinchStartDistance / d;

            cameraState.distance = clamp(
                cameraState.pinchStartCameraDistance * ratio,
                cameraState.minDistance,
                cameraState.maxDistance
            );
        }

        return;
    }

    if (!cameraState.dragging) return;

    const dx = e.clientX - cameraState.lastX;
    const dy = e.clientY - cameraState.lastY;

    cameraState.lastX = e.clientX;
    cameraState.lastY = e.clientY;

    cameraState.yaw -= dx * 0.008;
    cameraState.pitch = clamp(
        cameraState.pitch - dy * 0.006,
        cameraState.minPitch,
        cameraState.maxPitch
    );
});

function endPointer(e) {
    cameraState.pointers.delete(e.pointerId);

    if (cameraState.pointers.size === 0) {
        cameraState.dragging = false;
    } else if (cameraState.pointers.size === 1) {
        const p = [...cameraState.pointers.values()][0];
        cameraState.lastX = p.x;
        cameraState.lastY = p.y;
        cameraState.dragging = true;
    }
}

canvas.addEventListener("pointerup", endPointer);
canvas.addEventListener("pointercancel", endPointer);

canvas.addEventListener("pointerleave", e => {
    if (e.pointerType === "mouse") endPointer(e);
});

canvas.addEventListener("wheel", e => {
    e.preventDefault();

    cameraState.distance = clamp(
        cameraState.distance * (e.deltaY > 0 ? 1.08 : 0.92),
        cameraState.minDistance,
        cameraState.maxDistance
    );
}, { passive: false });

/* =====================================================
   منع تكبير المتصفح
   ===================================================== */

document.addEventListener("gesturestart", e => e.preventDefault(), { passive: false });
document.addEventListener("gesturechange", e => e.preventDefault(), { passive: false });
document.addEventListener("gestureend", e => e.preventDefault(), { passive: false });

/* =====================================================
   UI
   ===================================================== */

function updateUI() {
    $("gold").textContent = Math.floor(state.gold);
    $("wood").textContent = state.wood;
    $("stone").textContent = state.stone;
    $("land").textContent = state.land;
    $("population").textContent = state.population;
    $("houses").textContent = state.houses + state.largeHouses;
    $("income").textContent = Math.max(0, Math.floor(Number(state.income) || 0));

    $("rank").textContent =
        state.land >= 6 ? "👑 الملك" :
        state.land >= 4 ? "🏰 الحاكم" :
        state.land >= 2 ? "🏘️ زعيم القرية" :
        "🪙 فقير";

    $("smallHouse").disabled = state.gold < 40;
    $("largeHouse").disabled = state.gold < 100;

    $("buyAxe").disabled = state.ironAxe || state.gold < 100;
    $("buyPick").disabled = state.stonePick || state.gold < 130;

    renderUpgrades();
}

/* =====================================================
   التطويرات
   ===================================================== */

function renderUpgrades() {
    const box = $("pickUpgrades");
    box.innerHTML = "";

    if (!state.stonePick) return;

    addUpgrade(
        "upgrade1",
        "⚒️ تطوير فأس الحجر 1 — 270 🪙",
        "الضربة = 2 ضرر",
        state.pickUpgrade1,
        state.gold < 270
    );

    if (state.pickUpgrade1) {
        addUpgrade(
            "upgrade2",
            "⚒️ تطوير فأس الحجر 2 — 720 🪙",
            "الضربة = 4 ضرر",
            state.pickUpgrade2,
            state.gold < 720
        );
    }

    if (state.pickUpgrade2) {
        addUpgrade(
            "oreUpgrade",
            "💎 تطوير الحجر والمعادن — 2400 🪙",
            "حجر بنفسجي 8% (84 HP / 130 حجر)",
            state.oreUpgrade,
            state.gold < 2400
        );
    }
}

function addUpgrade(id, title, description, bought, disabled) {
    const div = document.createElement("div");
    div.className = "item";

    const titleEl = document.createElement("b");
    titleEl.textContent = title;

    const p = document.createElement("p");
    p.textContent = description;

    const button = document.createElement("button");
    button.textContent = bought ? "تم الشراء ✅" : "شراء";
    button.disabled = bought || disabled;
    button.onclick = () => buyUpgrade(id);

    div.append(titleEl, p, button);
    $("pickUpgrades").appendChild(div);
}

function buyUpgrade(id) {
    const prices = {
        upgrade1: 270,
        upgrade2: 720,
        oreUpgrade: 2400
    };

    const price = prices[id];

    if (!price || state.gold < price) return;

    if (id === "upgrade1" && !state.stonePick) {
        show("❌ اشترِ فأس الحجر أولًا");
        return;
    }

    if (id === "upgrade2" && !state.pickUpgrade1) {
        show("❌ اشترِ التطوير الأول أولًا");
        return;
    }

    if (id === "oreUpgrade" && !state.pickUpgrade2) {
        show("❌ اشترِ التطوير الثاني أولًا");
        return;
    }

    state.gold -= price;

    if (id === "upgrade1") state.pickUpgrade1 = true;
    if (id === "upgrade2") state.pickUpgrade2 = true;
    if (id === "oreUpgrade") state.oreUpgrade = true;

    save();
    updateUI();

    show("✅ تم شراء التطوير");
}

/* =====================================================
   الأدوات
   ===================================================== */

$("buyAxe").onclick = () => {
    if (state.ironAxe || state.gold < 100) return;

    state.gold -= 100;
    state.ironAxe = true;
    state.woodHits = 6;

    for (const tree of trees) {
        tree.userData.max = 6;
        tree.userData.hp = Math.min(tree.userData.hp, 6);
    }

    save();
    updateUI();

    show("⚒️ الفأس الحديدي جاهز");
};

$("buyPick").onclick = () => {
    if (state.stonePick || state.gold < 130) return;

    state.gold -= 130;
    state.stonePick = true;

    save();
    updateUI();

    show("⛏️ فأس الحجر جاهز");
};

/* =====================================================
   توسعة الأرض
   ===================================================== */

$("expandLand").onclick = () => {
    if (state.expansion >= expansionPrices.length) {
        show("✅ اكتملت توسعة الأرض");
        return;
    }

    const price = expansionPrices[state.expansion];

    if (state.gold < price) {
        show("❌ تحتاج " + price + " 🪙");
        return;
    }

    state.gold -= price;
    state.expansion++;
    state.land++;

    const scale = 1 + state.expansion * 0.12;
    buildCircle.scale.set(scale, scale, scale);

    save();
    updateUI();

    show("🗺️ تم توسيع الأرض");
};

/* =====================================================
   حذف منزل
   ===================================================== */

$("deleteHouse").onclick = () => {
    let closest = null;
    let best = 7;

    buildings.forEach(building => {
        const d = Math.hypot(
            building.position.x - player.position.x,
            building.position.z - player.position.z
        );

        if (d < best) {
            best = d;
            closest = building;
        }
    });

    if (!closest) {
        show("🚫 اقترب من منزل");
        return;
    }

    const type = closest.userData.type;
    const refund = type === "small" ? 20 : 50;

    state.gold += refund;

    if (type === "small") {
        state.houses = Math.max(0, state.houses - 1);
        state.population = Math.max(1, state.population - 1);
        removeHouseIncome("small");
    } else {
        state.largeHouses = Math.max(0, state.largeHouses - 1);
        state.population = Math.max(1, state.population - 3);
        removeHouseIncome("large");
    }

    const index = buildings.indexOf(closest);
    if (index >= 0) buildings.splice(index, 1);

    world.remove(closest);

    syncNPCs();

    save();
    updateUI();

    show("🗑️ تم حذف المنزل");
};

/* =====================================================
   الأكواد
   ===================================================== */

const rewards = {};

for (let i = 1; i <= 50; i++) {
    rewards["KING" + String(i).padStart(2, "0")] = i <= 10 ? 3500 : 2000;
}

["Mouhapro", "Mouha_and_najou", "najoupro"].forEach(code => {
    rewards[code.toUpperCase()] = 3900;
});

["Mouha2000", "Najou1617", "Ismail4321", "Meriem1234", "Sarra1324"].forEach(code => {
    rewards[code.toUpperCase()] = 3100;
});

[
    "Najouplus",
    "Najouplusmax",
    "Mouhaplus",
    "Mouhaplusmax",
    "Mouhapromax",
    "Najoupromax"
].forEach(code => {
    rewards[code.toUpperCase()] = 2500;
});

$("codeSend").onclick = () => {
    const code = $("codeInput").value.trim().toUpperCase();

    if (!rewards[code]) {
        show("❌ الكود غير صحيح");
        return;
    }

    if (state.usedCodes[code]) {
        show("❌ هذا الكود استُخدم من قبل");
        return;
    }

    state.usedCodes[code] = true;
    state.gold += rewards[code];
    $("codeInput").value = "";

    show("🎁 +" + rewards[code] + " عملة");

    save();
    updateUI();
};

/* =====================================================
   بيع الموارد
   ===================================================== */

function sell(resource, input) {
    const amount = Math.floor(Number($(input).value));

    if (!Number.isFinite(amount) || amount <= 0) {
        show("❌ أدخل كمية صحيحة");
        return;
    }

    if (state[resource] < amount) {
        show("❌ الكمية غير متوفرة");
        return;
    }

    state[resource] -= amount;
    state.gold += amount * 2;

    save();
    updateUI();
}

$("sellWood").onclick = () => sell("wood", "woodAmt");
$("sellStone").onclick = () => sell("stone", "stoneAmt");

/* =====================================================
   القوائم
   ===================================================== */

function menu(id) {
    const element = $(id);
    const open = element.style.display === "block";

    document.querySelectorAll(".menu").forEach(m => {
        m.style.display = "none";
    });

    if (!open) element.style.display = "block";
}

$("buildBtn").onclick = () => menu("buildMenu");
$("shopBtn").onclick = () => menu("shopMenu");
$("settingsBtn").onclick = () => menu("settingsMenu");

document.querySelectorAll(".close").forEach(button => {
    button.onclick = () => {
        $(button.dataset.close).style.display = "none";
    };
});

$("smallHouse").onclick = () => addBuilding("small");
$("largeHouse").onclick = () => addBuilding("large");

/* =====================================================
   الإيقاف وإعادة اللعبة
   ===================================================== */

$("pause").onclick = () => {
    state.paused = !state.paused;
    $("pause").textContent = state.paused ? "▶️ متابعة" : "⏸️ إيقاف مؤقت";
};

$("reset").onclick = () => {
    localStorage.removeItem("kingGame3D");
    location.reload();
};

/* =====================================================
   لوحة المفاتيح
   ===================================================== */

addEventListener("keydown", event => {
    const key = event.key.toLowerCase();

    if (key === "w" || key === "arrowup") keys.up = true;
    if (key === "s" || key === "arrowdown") keys.down = true;
    if (key === "a" || key === "arrowleft") keys.left = true;
    if (key === "d" || key === "arrowright") keys.right = true;
});

addEventListener("keyup", event => {
    const key = event.key.toLowerCase();

    if (key === "w" || key === "arrowup") keys.up = false;
    if (key === "s" || key === "arrowdown") keys.down = false;
    if (key === "a" || key === "arrowleft") keys.left = false;
    if (key === "d" || key === "arrowright") keys.right = false;
});

/* =====================================================
   أزرار الحركة للهاتف
   ===================================================== */

document.querySelectorAll("#move button").forEach(button => {
    const key = button.dataset.k;

    button.onpointerdown = e => {
        e.preventDefault();
        keys[key] = true;
    };

    button.onpointerup =
    button.onpointercancel =
    button.onpointerleave = () => {
        keys[key] = false;
    };
});

/* =====================================================
   الحفظ
   ===================================================== */

function save() {
    localStorage.setItem("kingGame3D", JSON.stringify(state));
}

function load() {
    const old = localStorage.getItem("kingGame3D");

    if (!old) return;

    try {
        Object.assign(state, JSON.parse(old));
        recalculateIncome();
    } catch (error) {
        console.warn("تعذر تحميل الحفظ", error);
    }

    // تصحيح الدخل دائمًا اعتمادًا على عدد البيوت المحفوظ.
    state.income = (Number(state.houses) || 0) + (Number(state.largeHouses) || 0) * 3;
}

/* =====================================================
   تغيير الحجم
   ===================================================== */

function resize() {
    const width = Math.max(1, canvas.clientWidth || window.innerWidth);
    const height = Math.max(1, canvas.clientHeight || window.innerHeight);

    camera.aspect = width / height;
    camera.updateProjectionMatrix();

    renderer.setSize(width, height, false);
}

addEventListener("resize", resize);

addEventListener("orientationchange", () => {
    setTimeout(resize, 100);
});

/* =====================================================
   جمع الموارد تلقائيًا
   ===================================================== */

function autoGather() {
    if (state.paused) return;

    const tree = nearest(trees, 6);
    const rock = nearest(rocks, 6);

    if (tree && rock) {
        const td = Math.hypot(
            tree.position.x - player.position.x,
            tree.position.z - player.position.z
        );

        const rd = Math.hypot(
            rock.position.x - player.position.x,
            rock.position.z - player.position.z
        );

        if (rd < td) mine(); else chop();
        return;
    }

    if (tree) {
        chop();
        return;
    }

    if (rock) {
        mine();
        return;
    }

    show(
        state.stonePick
            ? "🪓 اقترب من شجرة أو صخرة"
            : "🪓 اقترب من شجرة (ولكسر الحجر اشترِ فأس الحجر)"
    );
}

$("resourceBtn").onclick = autoGather;

/* =====================================================
   الإعدادات: FPS / الجودة / مدى الرؤية
   ===================================================== */

const SETTINGS_KEY = "kingGame3D_settings";

const graphicsSettings = {
    fps: 60,
    quality: 1080,
    view: "medium"
};

let targetFPS = 60;
let renderInterval = 1000 / 60;
let lastRenderTime = 0;
let fpsSampleFrames = 0;
let fpsSampleStart = performance.now();
let displayedFPS = 0;

function saveGraphicsSettings() {
    try {
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(graphicsSettings));
    } catch (_) {}
}

function loadGraphicsSettings() {
    try {
        const saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "null");

        if (saved && typeof saved === "object") {
            if ([30, 60, 90, 120].includes(Number(saved.fps))) {
                graphicsSettings.fps = Number(saved.fps);
            }

            if ([760, 1080, 1440].includes(Number(saved.quality))) {
                graphicsSettings.quality = Number(saved.quality);
            }

            if (["low", "medium", "high"].includes(saved.view)) {
                graphicsSettings.view = saved.view;
            }
        }
    } catch (_) {}
}

function updateSettingsButtons() {
    document.querySelectorAll("[data-fps]").forEach(b =>
        b.classList.toggle("active", Number(b.dataset.fps) === graphicsSettings.fps)
    );

    document.querySelectorAll("[data-quality]").forEach(b =>
        b.classList.toggle("active", Number(b.dataset.quality) === graphicsSettings.quality)
    );

    document.querySelectorAll("[data-view]").forEach(b =>
        b.classList.toggle("active", b.dataset.view === graphicsSettings.view)
    );
}

function applyFPS(value, persist = true) {
    const fps = Number(value);
    if (![30, 60, 90, 120].includes(fps)) return;

    graphicsSettings.fps = fps;
    targetFPS = fps;
    renderInterval = 1000 / targetFPS;

    /* إعادة ضبط مؤقت الجدولة حتى لا ننتظر فترة قديمة عند تغيير FPS. */
    lastRenderTime = performance.now();

    updateSettingsButtons();
    if (persist) saveGraphicsSettings();
}

function applyQuality(value, persist = true) {
    const q = Number(value);
    if (![760, 1080, 1440].includes(q)) return;

    graphicsSettings.quality = q;

    /*
       الجودة هنا تحدد الدقة الداخلية للرندر، وليس مجرد رقم شكلي.
       نحافظ على نسبة الشاشة، ونسمح للجهاز بتحديد سقف DPR إذا كانت
       شاشته أصغر من الجودة المطلوبة.
    */
    const cssWidth = Math.max(1, canvas.clientWidth || window.innerWidth);
    const cssHeight = Math.max(1, canvas.clientHeight || window.innerHeight);
    const targetHeight = q;
    const qualityScale = Math.max(0.5, targetHeight / cssHeight);
    const deviceCap = q >= 1440 ? 2.0 : q >= 1080 ? 1.75 : 1.35;
    const dpr = Math.min(
        deviceCap,
        qualityScale * Math.min(window.devicePixelRatio || 1, 2)
    );

    renderer.setPixelRatio(Math.max(0.75, dpr));
    renderer.shadowMap.enabled = q >= 1080;

    const shadowSize = q >= 1440 ? 2048 : q >= 1080 ? 1536 : 1024;
    sun.shadow.mapSize.width = shadowSize;
    sun.shadow.mapSize.height = shadowSize;

    resize();
    updateSettingsButtons();
    if (persist) saveGraphicsSettings();
}

function applyView(value, persist = true) {
    const settings = {
        low:    { far: 650,  fog: 220 },
        medium: { far: 1100, fog: 300 },
        high:   { far: 1800, fog: 500 }
    };

    if (!settings[value]) value = "medium";

    graphicsSettings.view = value;
    const v = settings[value];

    camera.far = v.far;
    camera.updateProjectionMatrix();

    scene.fog.near = v.fog * 0.55;
    scene.fog.far = v.far;

    updateSettingsButtons();
    if (persist) saveGraphicsSettings();
}

function updateFPSDisplay(now) {
    fpsSampleFrames++;
    const elapsed = now - fpsSampleStart;

    if (elapsed >= 250) {
        displayedFPS = (fpsSampleFrames * 1000) / elapsed;
        fpsSampleFrames = 0;
        fpsSampleStart = now;

        const el = $("fpsDisplay");
        if (el) {
            el.textContent = `FPS: ${displayedFPS.toFixed(1)}`;
        }
    }
}

document.querySelectorAll("[data-fps]").forEach(b =>
    b.addEventListener("click", () => applyFPS(b.dataset.fps))
);

document.querySelectorAll("[data-quality]").forEach(b =>
    b.addEventListener("click", () => applyQuality(b.dataset.quality))
);

document.querySelectorAll("[data-view]").forEach(b =>
    b.addEventListener("click", () => applyView(b.dataset.view))
);

/* زر الأكواد */
if ($("codeBtn")) $("codeBtn").onclick = () => menu("codeBox");

/* موسيقى هادئة مولدة محليًا، بلا ملف خارجي */
let audioCtx = null;
let musicGain = null;
let musicTimer = null;

function startMusic() {
    if (audioCtx) return;

    try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        musicGain = audioCtx.createGain();
        musicGain.gain.value = 0.045;
        musicGain.connect(audioCtx.destination);

        const notes = [220, 261.63, 329.63, 392, 329.63, 261.63];
        let i = 0;

        const play = () => {
            if (!audioCtx || audioCtx.state === "closed") return;

            const o = audioCtx.createOscillator();
            const g = audioCtx.createGain();

            o.type = "sine";
            o.frequency.value = notes[i++ % notes.length];

            g.gain.setValueAtTime(0, audioCtx.currentTime);
            g.gain.linearRampToValueAtTime(0.18, audioCtx.currentTime + 0.35);
            g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 2.6);

            o.connect(g);
            g.connect(musicGain);
            o.start();
            o.stop(audioCtx.currentTime + 2.7);
        };

        play();
        musicTimer = setInterval(play, 2700);
    } catch (e) {
        console.warn("Audio unavailable", e);
    }
}

["pointerdown", "keydown", "touchstart"].forEach(ev =>
    window.addEventListener(ev, startMusic, { once: true, passive: true })
);

/* =====================================================
   التحديث الرئيسي
   ===================================================== */

let previous = performance.now();

function animate(now) {
    requestAnimationFrame(animate);

    /*
       محدد FPS حقيقي: نرندر فقط عند حلول موعد الإطار التالي.
       بذلك 30 = نحو 30 إطار/ث، 60 = نحو 60، 90 = نحو 90،
       و120 = نحو 120 إذا كانت شاشة الجهاز والمتصفح يدعمان ذلك.
    */
    if (lastRenderTime === 0) lastRenderTime = now;
    if (now - lastRenderTime + 0.05 < renderInterval) return;

    /* نحافظ على التوقيت الحقيقي حتى لا تتراكم إطارات بعد تغيير FPS. */
    lastRenderTime = now;

    const dt = Math.min(0.25, Math.max(0, (now - previous) / 1000));
    previous = now;

    if (!state.paused) {
        movePlayer(dt);
        updateNPCs(dt);

        /* تحديث Animation اللاعب. */
        const playerModel = player.userData.actionGroup;

        if (playerModel && playerModel.userData.mixer) {
            playerModel.userData.mixer.update(dt);
        }

        animateProceduralCharacter(playerModel, player.userData.moving, dt, null);
    }

    updateCamera();

    // الدخل يُضاف مرة واحدة فقط، حسب الدخل في الثانية، مستقلًا عن FPS.
    if (!state.paused && state.income > 0) {
        state.gold += state.income * dt;
    }

    renderer.render(scene, camera);
    updateFPSDisplay(now);
}

/* =====================================================
   بدء اللعبة
   ===================================================== */

async function startGame() {
    load();
    loadGraphicsSettings();

    createWorld();
    resize();

    /* تطبيق الإعدادات المحفوظة فعليًا عند بدء اللعبة. */
    applyFPS(graphicsSettings.fps, false);
    applyQuality(graphicsSettings.quality, false);
    applyView(graphicsSettings.view, false);

    /*
       تحميل الشخصية قبل إنشاء اللاعب
       حتى يظهر GLB مباشرة.
    */
    const loaded = await loadCharacter();

    createMainCharacter();
    syncNPCs();
    updateUI();
    resize();

    /* تعديل حجم دائرة البناء حسب الحفظ. */
    const scale = 1 + state.expansion * 0.12;
    buildCircle.scale.set(scale, scale, scale);

    const loading = $("loading");
    if (loading) {
        loading.style.opacity = "0";
        setTimeout(() => loading.remove(), 550);
    }

    requestAnimationFrame(animate);

    if (loaded) {
        show("👨 تم تحميل شخصية المغامر");
    }
}

/* =====================================================
   الحفظ التلقائي
   ===================================================== */

setInterval(save, 1000);

/* =====================================================
   شاشة التحميل
   ===================================================== */

startGame()
    .catch(error => {
        console.error(error);

        const loading = $("loading");
        if (loading) {
            loading.style.opacity = "0";
            setTimeout(() => loading.remove(), 550);
        }

        show("❌ حدث خطأ أثناء تشغيل اللعبة");
    });

})();