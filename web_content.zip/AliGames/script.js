const $ = (s) => document.querySelector(s);
const grid = $("#gameGrid");
const dialog = $("#gameDialog");
const settingsDialog = $("#settingsDialog");
let games = [];
let filter = "all";
let editingId = null;

const starterGames = [
  {id:1,name:"Minecraft",link:"",color:"green",favorite:true,icon:"⛏️"},
  {id:2,name:"Car Parking",link:"",color:"blue",favorite:false,icon:"🏎️"},
  {id:3,name:"Roblox",link:"",color:"purple",favorite:false,icon:"🧱"},
  {id:4,name:"Subway Surfers",link:"",color:"orange",favorite:false,icon:"🏃"}
];

function loadGames(){
  try { games = JSON.parse(localStorage.getItem("aligames-list")) || starterGames.map(x=>({...x})); }
  catch { games = starterGames.map(x=>({...x})); }
  render();
}
function save(){ localStorage.setItem("aligames-list", JSON.stringify(games)); render(); }
function render(){
  const query = $("#searchInput").value.trim().toLocaleLowerCase("tr");
  const shown = games.filter(g => (filter==="all" || g.favorite) && g.name.toLocaleLowerCase("tr").includes(query));
  grid.innerHTML = "";
  shown.forEach(g => {
    const card = document.createElement("article");
    card.className = "game-card";
    const cover = document.createElement("div"); cover.className = `cover ${g.color}`;
    const icon = document.createElement("span"); icon.className = "game-icon"; icon.textContent = g.icon || "🎮"; cover.append(icon);
    const name = document.createElement("h3"); name.className="game-name"; name.textContent=g.name;
    const sub = document.createElement("div"); sub.className="game-sub"; sub.textContent=g.link ? "Bağlantı eklendi" : "Kişisel koleksiyon";
    const actions = document.createElement("div"); actions.className="card-actions";
    const launch = document.createElement("button"); launch.className="launch-btn"; launch.textContent="▶ AÇ";
    launch.addEventListener("click",()=>launchGame(g));
    const fav = document.createElement("button"); fav.className="fav-btn"+(g.favorite?" on":""); fav.textContent=g.favorite?"★":"☆"; fav.setAttribute("aria-label","Favori");
    fav.addEventListener("click",()=>{g.favorite=!g.favorite;save();});
    const del = document.createElement("button"); del.className="delete-btn"; del.textContent="×"; del.setAttribute("aria-label","Sil");
    del.addEventListener("click",()=>{if(confirm(`${g.name} listeden silinsin mi?`)){games=games.filter(x=>x.id!==g.id);save();}});
    actions.append(launch,fav,del); card.append(cover,name,sub,actions); grid.append(card);
  });
  $("#gameCount").textContent=games.length;
  $("#favCount").textContent=games.filter(g=>g.favorite).length;
  $("#emptyState").classList.toggle("hidden",shown.length!==0);
}
function launchGame(g){
  if(!g.link){alert(`${g.name} için bağlantı eklenmemiş. Oyunu eklerken bağlantı girebilirsin.\n\nNot: Tarayıcı, telefondaki yüklü oyunları otomatik açmayı veya listelemeyi garanti edemez.`);return;}
  let url=g.link.trim();
  if(!/^https?:\/\//i.test(url) && !/^[a-z][a-z0-9+.-]*:/i.test(url)) url="https://"+url;
  window.open(url,"_blank","noopener");
}
function openAdd(){
  editingId=null; $("#dialogTitle").textContent="Oyun ekle"; $("#gameForm").reset(); dialog.showModal();
}
$("#addGame").addEventListener("click",openAdd);
$("#addGameTop").addEventListener("click",openAdd);
$("#emptyAdd").addEventListener("click",openAdd);
$("#closeDialog").addEventListener("click",()=>dialog.close());
$("#settingsBtn").addEventListener("click",()=>settingsDialog.showModal());
$("#closeSettings").addEventListener("click",()=>settingsDialog.close());
$("#searchInput").addEventListener("input",render);
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  filter=btn.dataset.filter;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===btn));render();
}));
$("#gameForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  const name=$("#gameName").value.trim();
  if(!name)return;
  const icons={purple:"🎮",blue:"🚀",green:"⛏️",orange:"🏎️",pink:"👾"};
  games.push({id:Date.now(),name,link:$("#gameLink").value.trim(),color:$("#gameColor").value,favorite:$("#gameFavorite").checked,icon:icons[$("#gameColor").value]});
  save();dialog.close();
});
$("#resetDemo").addEventListener("click",()=>{games=starterGames.map(x=>({...x}));save();settingsDialog.close();});
loadGames();
