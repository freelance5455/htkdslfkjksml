AliGames HTML sürümü
====================

Dosyalar:
- index.html: uygulamanın ekranı
- style.css: tasarım
- script.js: oyun listesi ve etkileşimler

Telefonda deneme:
1. ZIP'i çıkar.
2. index.html dosyasını bir HTML görüntüleyicide veya tarayıcıda aç.
3. Oyun ekle düğmesiyle kendi listenin kartlarını oluştur.

APK hakkında önemli bilgi:
Bu klasör, HTML/CSS/JavaScript web uygulamasıdır; hazır APK değildir.
APK'ya çevirmek için bir WebView tabanlı paketleyici veya Android projesi gerekir.
Bu web sürümü Android'in yüklü uygulamalarını tarayamaz. Bu nedenle oyunlar elle eklenir.
Uygulama listesi aynı tarayıcı/WebView depolamasında saklanır; farklı paketleyicilerde
depolama davranışı değişebilir.
