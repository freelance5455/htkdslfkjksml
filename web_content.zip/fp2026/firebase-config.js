// ==========================================
// QUIKTEMO - FIREBASE CONFIGURATION
// ==========================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-database.js";

const firebaseConfig = {
    apiKey: "AIzaSyC1qusMOZC4U38EMBKdyixpAzSfaB4X2uA",
    authDomain: "quicktempo-89055.firebaseapp.com",
    databaseURL: "https://quicktempo-89055-default-rtdb.firebaseio.com",
    projectId: "quicktempo-89055",
    storageBucket: "quicktempo-89055.firebasestorage.app",
    messagingSenderId: "813695756465",
    appId: "1:813695756465:web:3d0143ffeebf86324c5a90"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Realtime Database
const db = getDatabase(app);

export { app, db };