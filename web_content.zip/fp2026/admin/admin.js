/* =========================================================
   QUIKTEMO ADMIN PANEL
   COMPLETE UPDATED JAVASCRIPT
   DRIVER AVAILABILITY + FIREBASE
========================================================= */


/* =========================================================
   ADMIN LOGIN DETAILS
========================================================= */

const ADMIN_MOBILE = "9876543210";
const ADMIN_PASSWORD = "admin123";
const ADMIN_SESSION_KEY = "quiktempo_admin_logged_in";


/* =========================================================
   FIREBASE CONFIG
========================================================= */

const firebaseConfig = {
    apiKey: "AIzaC1qusMOZC4U38EMBKdyixpAzSfaB4X2uA",
    authDomain: "quicktempo-89055.firebaseapp.com",
    databaseURL: "https://quicktempo-89055-default-rtdb.firebaseio.com",
    projectId: "quicktempo-89055",
    storageBucket: "quicktempo-89055.firebasestorage.app",
    messagingSenderId: "813695756465",
    appId: "1:813695756465:web:3d0143ffeebf86324c5a90"
};


let firebaseDatabase = null;

let adminBookings = [];
let adminUsers = [];
let currentAdminBooking = null;

let adminDrivers = [];


/* =========================================================
   DEFAULT DRIVER DATA
========================================================= */

/*
   Initial demo setup:

   Rajesh Kumar  -> Available
   Rahul Patil   -> Available
   Amit Shinde   -> On Trip
   Suresh More   -> Available

   Firebase will store these drivers under:

   drivers/
*/


const defaultDrivers = [

    {
        id: "driver1",
        name: "Rajesh Kumar",
        number: "MH-04-AB-1234",
        vehicle: "Mini Tempo",
        status: "Available"
    },

    {
        id: "driver2",
        name: "Rahul Patil",
        number: "MH-03-AB-4521",
        vehicle: "Tata Ace",
        status: "Available"
    },

    {
        id: "driver3",
        name: "Amit Shinde",
        number: "MH-04-CD-2211",
        vehicle: "Pickup Truck",
        status: "On Trip"
    },

    {
        id: "driver4",
        name: "Suresh More",
        number: "MH-05-EF-3344",
        vehicle: "Mini Tempo",
        status: "Available"
    }

];


/* =========================================================
   STATIC VEHICLE DATA
========================================================= */

const adminVehicles = [

    {
        name: "Mini Tempo",
        number: "MH-04-AB-1234",
        capacity: "Up to 500 kg",
        status: "Available"
    },

    {
        name: "Tata Ace",
        number: "MH-03-AB-4521",
        capacity: "Up to 750 kg",
        status: "Available"
    },

    {
        name: "Pickup Truck",
        number: "MH-04-CD-2211",
        capacity: "Up to 1500 kg",
        status: "Available"
    }

];


/* =========================================================
   VEHICLE EMOJIS
========================================================= */

const vehicleEmojis = {

    "Mini Tempo": "🚚",

    "Tata Ace": "🚛",

    "Pickup Truck": "🛻"

};


/* =========================================================
   FIREBASE INITIALIZATION
========================================================= */

function initializeAdminFirebase() {

    try {

        if (typeof firebase === "undefined") {

            console.error(
                "Firebase SDK is not loaded."
            );

            return false;

        }


        if (!firebase.apps.length) {

            firebase.initializeApp(
                firebaseConfig
            );

        }


        firebaseDatabase =
            firebase.database();


        console.log(
            "QuikTemo Admin Firebase Connected"
        );


        return true;

    }

    catch (error) {

        console.error(
            "Firebase initialization error:",
            error
        );

        return false;

    }

}


/* =========================================================
   DOM READY
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        initializeAdminFirebase();

        setAdminDate();

        setupAdminEvents();

        checkAdminPage();

        loadAdminData();

        initializeDriversInFirebase();

    }
);


/* =========================================================
   ADMIN PAGE CHECK
========================================================= */

function checkAdminPage() {

    const isDashboard =
        document.getElementById(
            "totalBookings"
        ) ||
        document.getElementById(
            "bookingsTableBody"
        );


    const isLoginPage =
        document.getElementById(
            "adminLoginForm"
        );


    if (isDashboard) {

        if (
            localStorage.getItem(
                ADMIN_SESSION_KEY
            ) !== "true"
        ) {

            window.location.href =
                "admin-login.html";

        }

    }


    if (isLoginPage) {

        /*
           Login page does not automatically
           redirect.
        */

    }

}


/* =========================================================
   SETUP ADMIN EVENTS
========================================================= */

function setupAdminEvents() {


    /* -----------------------------------------
       LOGIN FORM
    ----------------------------------------- */

    const loginForm =
        document.getElementById(
            "adminLoginForm"
        );


    if (loginForm) {

        loginForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();

                handleAdminLogin();

            }
        );

    }


    /* -----------------------------------------
       MOBILE INPUT
    ----------------------------------------- */

    const mobileInput =
        document.getElementById(
            "adminMobile"
        );


    if (mobileInput) {

        mobileInput.addEventListener(
            "input",
            function () {

                this.value =
                    this.value
                        .replace(
                            /[^0-9]/g,
                            ""
                        )
                        .slice(0, 10);

            }
        );

    }


    /* -----------------------------------------
       BACK TO CUSTOMER APP
    ----------------------------------------- */

    const backButton =
        document.getElementById(
            "backCustomerButton"
        );


    if (backButton) {

        backButton.addEventListener(
            "click",
            function () {

                window.location.href =
                    "../index.html";

            }
        );

    }


    /* -----------------------------------------
       BOOKING SEARCH
    ----------------------------------------- */

    const bookingSearch =
        document.getElementById(
            "bookingSearch"
        );


    if (bookingSearch) {

        bookingSearch.addEventListener(
            "input",
            function () {

                renderBookingsTable();

            }
        );

    }


    /* -----------------------------------------
       BOOKING STATUS FILTER
    ----------------------------------------- */

    const statusFilter =
        document.getElementById(
            "bookingStatusFilter"
        );


    if (statusFilter) {

        statusFilter.addEventListener(
            "change",
            function () {

                renderBookingsTable();

            }
        );

    }


    /* -----------------------------------------
       SIDEBAR
    ----------------------------------------- */

    const sidebarToggle =
        document.querySelector(
            ".menu-toggle"
        );


    if (sidebarToggle) {

        sidebarToggle.addEventListener(
            "click",
            function () {

                const sidebar =
                    document.querySelector(
                        ".sidebar"
                    );


                if (sidebar) {

                    sidebar.classList.toggle(
                        "active"
                    );

                }

            }
        );

    }

}


/* =========================================================
   ADMIN LOGIN
========================================================= */

function handleAdminLogin() {

    const mobileInput =
        document.getElementById(
            "adminMobile"
        );


    const passwordInput =
        document.getElementById(
            "adminPassword"
        );


    const errorBox =
        document.getElementById(
            "loginError"
        );


    const mobile =
        mobileInput
            ? mobileInput.value.trim()
            : "";


    const password =
        passwordInput
            ? passwordInput.value
            : "";


    if (errorBox) {

        errorBox.textContent = "";

    }


    if (!/^[0-9]{10}$/.test(mobile)) {

        if (errorBox) {

            errorBox.textContent =
                "Please enter a valid 10-digit mobile number.";

        }

        return;

    }


    if (!password) {

        if (errorBox) {

            errorBox.textContent =
                "Please enter password.";

        }

        return;

    }


    if (
        mobile === ADMIN_MOBILE &&
        password === ADMIN_PASSWORD
    ) {

        localStorage.setItem(
            ADMIN_SESSION_KEY,
            "true"
        );


        const loginData = {

            mobile: mobile,

            role: "Admin",

            loginTime:
                new Date().toISOString(),

            status: "Active"

        };


        if (firebaseDatabase) {

            firebaseDatabase
                .ref("adminLogins")
                .push(loginData)
                .then(function () {

                    console.log(
                        "Admin login saved to Firebase"
                    );

                    openAdminDashboard();

                })
                .catch(function (error) {

                    console.error(
                        "Admin Firebase login error:",
                        error
                    );

                    openAdminDashboard();

                });

        }

        else {

            openAdminDashboard();

        }


        return;

    }


    if (errorBox) {

        errorBox.textContent =
            "Invalid admin mobile number or password.";

    }

}


/* =========================================================
   OPEN ADMIN DASHBOARD
========================================================= */

function openAdminDashboard() {

    window.location.href =
        "admin-dashboard.html";

}


/* =========================================================
   LOAD ADMIN DATA
========================================================= */

function loadAdminData() {

    loadBookings();

    loadUsers();

    loadDriversFromFirebase();

    renderVehicles();

}


/* =========================================================
   INITIALIZE DRIVERS IN FIREBASE
========================================================= */

function initializeDriversInFirebase() {

    if (!firebaseDatabase) {

        console.warn(
            "Firebase database not available for drivers."
        );

        return;

    }


    firebaseDatabase
        .ref("drivers")
        .once("value")
        .then(function (snapshot) {

            const data =
                snapshot.val();


            /*
               If drivers already exist,
               do NOT overwrite their status.
            */

            if (data) {

                console.log(
                    "Drivers already exist in Firebase."
                );

                return;

            }


            const updates = {};


            defaultDrivers.forEach(
                function (driver) {

                    updates[
                        driver.id
                    ] = driver;

                }
            );


            return firebaseDatabase
                .ref("drivers")
                .set(updates);

        })
        .then(function () {

            console.log(
                "Default drivers initialized in Firebase."
            );

        })
        .catch(function (error) {

            console.error(
                "Driver initialization error:",
                error
            );

        });

}


/* =========================================================
   LOAD DRIVERS FROM FIREBASE
========================================================= */

function loadDriversFromFirebase() {

    if (!firebaseDatabase) {

        adminDrivers =
            defaultDrivers.map(
                function (driver) {

                    return {
                        ...driver
                    };

                }
            );


        renderDrivers();

        return;

    }


    firebaseDatabase
        .ref("drivers")
        .on(
            "value",
            function (snapshot) {

                const data =
                    snapshot.val();


                if (!data) {

                    adminDrivers =
                        defaultDrivers.map(
                            function (driver) {

                                return {
                                    ...driver
                                };

                            }
                        );

                }

                else {

                    adminDrivers =
                        Object.keys(data)
                            .map(
                                function (key) {

                                    return {

                                        id: key,

                                        ...data[key]

                                    };

                                }
                            );

                }


                /*
                   Keep drivers in a predictable order.
                */

                const driverOrder = {

                    "Rajesh Kumar": 1,

                    "Rahul Patil": 2,

                    "Amit Shinde": 3,

                    "Suresh More": 4

                };


                adminDrivers.sort(
                    function (a, b) {

                        return (
                            (driverOrder[a.name] || 99) -
                            (driverOrder[b.name] || 99)
                        );

                    }
                );


                renderDrivers();

                updateVehicleStatuses();

            },
            function (error) {

                console.error(
                    "Driver load error:",
                    error
                );

            }
        );

}


/* =========================================================
   MAKE DRIVER AVAILABLE
========================================================= */

function makeDriverAvailable(driverId) {

    if (!firebaseDatabase) {

        showAdminToast(
            "Firebase is not connected."
        );

        return;

    }


    if (!driverId) {

        return;

    }


    const driver =
        adminDrivers.find(
            function (item) {

                return (
                    String(item.id) ===
                    String(driverId)
                );

            }
        );


    if (!driver) {

        showAdminToast(
            "Driver not found."
        );

        return;

    }


    firebaseDatabase
        .ref(
            "drivers/" +
            driverId +
            "/status"
        )
        .set("Available")
        .then(function () {

            showAdminToast(
                driver.name +
                " is now Available."
            );


            /*
               This event is important.

               script.js will listen to the
               same Firebase driver status and
               assign any waiting booking.
            */

        })
        .catch(function (error) {

            console.error(
                "Driver status update error:",
                error
            );

            showAdminToast(
                "Could not update driver status."
            );

        });

}


/* =========================================================
   SET DRIVER ON TRIP
========================================================= */

function setDriverOnTrip(driverId) {

    if (!firebaseDatabase) {

        showAdminToast(
            "Firebase is not connected."
        );

        return;

    }


    if (!driverId) {

        return;

    }


    firebaseDatabase
        .ref(
            "drivers/" +
            driverId +
            "/status"
        )
        .set("On Trip")
        .then(function () {

            showAdminToast(
                "Driver marked as On Trip."
            );

        })
        .catch(function (error) {

            console.error(
                "Driver status update error:",
                error
            );

            showAdminToast(
                "Could not update driver status."
            );

        });

}


/* =========================================================
   DRIVER RENDER
========================================================= */

function renderDrivers() {

    const grid =
        document.getElementById(
            "driversGrid"
        );


    const overview =
        document.getElementById(
            "driverOverview"
        );


    /* -----------------------------------------
       DRIVER OVERVIEW
    ----------------------------------------- */

    if (overview) {

        if (!adminDrivers.length) {

            overview.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">👨‍✈️</div>
                    <h3>No drivers found</h3>
                    <p>Driver information will appear here.</p>
                </div>
            `;

        }

        else {

            overview.innerHTML =
                adminDrivers.map(
                    function (driver) {

                        const emoji =
                            getDriverEmoji(
                                driver.name
                            );


                        const statusClass =
                            String(
                                driver.status || ""
                            )
                                .toLowerCase()
                                .replace(
                                    /\s+/g,
                                    "-"
                                );


                        return `

                            <div class="driver-overview-row">

                                <div class="driver-overview-icon">
                                    ${emoji}
                                </div>

                                <div class="driver-overview-info">

                                    <strong>
                                        ${escapeHtml(
                                            driver.name
                                        )}
                                    </strong>

                                    <span>
                                        ${escapeHtml(
                                            driver.vehicle
                                        )}
                                    </span>

                                    <small>
                                        ${escapeHtml(
                                            driver.number
                                        )}
                                    </small>

                                </div>

                                <div class="driver-overview-status ${statusClass}">

                                    <span class="status-dot"></span>

                                    ${escapeHtml(
                                        driver.status
                                    )}

                                </div>

                            </div>

                        `;

                    }
                ).join("");

        }

    }


    /* -----------------------------------------
       DRIVER CARDS
    ----------------------------------------- */

    if (grid) {

        if (!adminDrivers.length) {

            grid.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">👨‍✈️</div>
                    <h3>No drivers found</h3>
                    <p>Driver information will appear here.</p>
                </div>
            `;

        }

        else {

            grid.innerHTML =
                adminDrivers.map(
                    function (driver) {

                        const emoji =
                            getDriverEmoji(
                                driver.name
                            );


                        const isAvailable =
                            String(
                                driver.status || ""
                            ).toLowerCase() ===
                            "available";


                        const actionButton =
                            isAvailable

                                ? `
                                    <button
                                        class="driver-action-btn on-trip-btn"
                                        onclick="setDriverOnTrip('${escapeJs(driver.id)}')"
                                    >
                                        Mark On Trip
                                    </button>
                                  `

                                : `
                                    <button
                                        class="driver-action-btn available-btn"
                                        onclick="makeDriverAvailable('${escapeJs(driver.id)}')"
                                    >
                                        ✓ Make Available
                                    </button>
                                  `;


                        return `

                            <div class="driver-admin-card">

                                <div class="driver-card-top">

                                    <div class="driver-large-icon">
                                        ${emoji}
                                    </div>

                                    <span class="driver-status-badge ${isAvailable ? "available" : "on-trip"}">
                                        ${escapeHtml(
                                            driver.status
                                        )}
                                    </span>

                                </div>


                                <h3>
                                    ${escapeHtml(
                                        driver.name
                                    )}
                                </h3>


                                <p class="driver-vehicle">

                                    🚛

                                    ${escapeHtml(
                                        driver.vehicle
                                    )}

                                </p>


                                <p class="driver-number">

                                    🚘

                                    ${escapeHtml(
                                        driver.number
                                    )}

                                </p>


                                <div class="driver-action-area">

                                    ${actionButton}

                                </div>

                            </div>

                        `;

                    }
                ).join("");

        }

    }

}


/* =========================================================
   DRIVER EMOJIS
========================================================= */

function getDriverEmoji(name) {

    if (name === "Rajesh Kumar") {

        return "🧑‍✈️";

    }


    if (name === "Rahul Patil") {

        return "👨‍✈️";

    }


    if (name === "Amit Shinde") {

        return "🧔‍♂️";

    }


    if (name === "Suresh More") {

        return "👨‍💼";

    }


    return "👨‍✈️";

}


/* =========================================================
   UPDATE VEHICLE STATUS
========================================================= */

function updateVehicleStatuses() {

    adminVehicles.forEach(
        function (vehicle) {

            const matchingDriver =
                adminDrivers.find(
                    function (driver) {

                        return (
                            driver.vehicle ===
                            vehicle.name
                        );

                    }
                );


            if (matchingDriver) {

                vehicle.status =
                    matchingDriver.status;

            }

        }
    );


    renderVehicles();

}


/* =========================================================
   VEHICLE RENDER
========================================================= */

function renderVehicles() {

    const grid =
        document.getElementById(
            "vehiclesGrid"
        );


    const overview =
        document.getElementById(
            "vehicleOverview"
        );


    /* -----------------------------------------
       VEHICLES SECTION
    ----------------------------------------- */

    if (grid) {

        grid.innerHTML =
            adminVehicles.map(
                function (vehicle) {

                    const emoji =
                        vehicleEmojis[
                            vehicle.name
                        ] || "🚛";


                    return `

                        <div class="vehicle-admin-card">

                            <div class="vehicle-image-wrapper">

                                <div class="vehicle-icon">
                                    ${emoji}
                                </div>

                            </div>


                            <div class="vehicle-info">

                                <h3>
                                    ${escapeHtml(
                                        vehicle.name
                                    )}
                                </h3>


                                <p>
                                    ${escapeHtml(
                                        vehicle.number
                                    )}
                                </p>


                                <span>
                                    ${escapeHtml(
                                        vehicle.capacity
                                    )}
                                </span>

                            </div>


                            <div class="vehicle-status">

                                ${escapeHtml(
                                    vehicle.status
                                )}

                            </div>

                        </div>

                    `;

                }
            ).join("");

    }


    /* -----------------------------------------
       VEHICLE OVERVIEW
    ----------------------------------------- */

    if (overview) {

        overview.innerHTML =
            adminVehicles.map(
                function (vehicle) {

                    const emoji =
                        vehicleEmojis[
                            vehicle.name
                        ] || "🚛";


                    const statusClass =
                        String(
                            vehicle.status || ""
                        )
                            .toLowerCase()
                            .replace(
                                /\s+/g,
                                "-"
                            );


                    return `

                        <div class="overview-row">

                            <div class="vehicle-small-image">

                                <span class="vehicle-overview-emoji">
                                    ${emoji}
                                </span>

                            </div>


                            <div class="overview-info">

                                <strong>
                                    ${escapeHtml(
                                        vehicle.name
                                    )}
                                </strong>


                                <small>
                                    ${escapeHtml(
                                        vehicle.capacity
                                    )}
                                </small>

                            </div>


                            <span class="overview-status ${statusClass}">
                                ${escapeHtml(
                                    vehicle.status
                                )}
                            </span>

                        </div>

                    `;

                }
            ).join("");

    }

}


/* =========================================================
   LOAD BOOKINGS FROM FIREBASE
========================================================= */

function loadBookings() {

    if (!firebaseDatabase) {

        console.warn(
            "Firebase database not available."
        );

        updateDashboardStats();

        renderBookingsTable();

        return;

    }


    firebaseDatabase
        .ref("bookings")
        .on(
            "value",
            function (snapshot) {

                const data =
                    snapshot.val();


                if (!data) {

                    adminBookings = [];

                }

                else {

                    adminBookings =
                        Object.values(data);

                }


                adminBookings.sort(
                    function (a, b) {

                        return (
                            new Date(
                                b.createdAt || 0
                            ) -
                            new Date(
                                a.createdAt || 0
                            )
                        );

                    }
                );


                updateDashboardStats();

                renderRecentBookings();

                renderBookingsTable();

            },
            function (error) {

                console.error(
                    "Booking load error:",
                    error
                );

            }
        );

}


/* =========================================================
   LOAD USERS FROM FIREBASE
========================================================= */

function loadUsers() {

    if (!firebaseDatabase) {

        console.warn(
            "Firebase database not available."
        );

        return;

    }


    firebaseDatabase
        .ref("users")
        .on(
            "value",
            function (snapshot) {

                const data =
                    snapshot.val();


                if (!data) {

                    adminUsers = [];

                }

                else {

                    adminUsers =
                        Object.values(data);

                }


                renderCustomers();

            },
            function (error) {

                console.error(
                    "Customer load error:",
                    error
                );

            }
        );

}


/* =========================================================
   DASHBOARD STATS
========================================================= */

function updateDashboardStats() {

    const total =
        adminBookings.length;


    const confirmed =
        adminBookings.filter(
            function (booking) {

                return (
                    String(
                        booking.status || ""
                    )
                        .toLowerCase()
                        === "confirmed"
                );

            }
        ).length;


    const active =
        adminBookings.filter(
            function (booking) {

                const status =
                    String(
                        booking.status || ""
                    )
                        .toLowerCase();


                return (

                    status ===
                        "driver assigned" ||

                    status ===
                        "on the way" ||

                    status ===
                        "arriving" ||

                    status ===
                        "in progress"

                );

            }
        ).length;


    const completed =
        adminBookings.filter(
            function (booking) {

                return (
                    String(
                        booking.status || ""
                    )
                        .toLowerCase()
                        === "completed"
                );

            }
        ).length;


    const cancelled =
        adminBookings.filter(
            function (booking) {

                return (
                    String(
                        booking.status || ""
                    )
                        .toLowerCase()
                        === "cancelled"
                );

            }
        ).length;


    setText(
        "totalBookings",
        total
    );


    setText(
        "confirmedBookings",
        confirmed
    );


    setText(
        "activeBookings",
        active
    );


    setText(
        "completedBookings",
        completed
    );


    setText(
        "cancelledBookings",
        cancelled
    );

}


/* =========================================================
   RECENT BOOKINGS
========================================================= */

function renderRecentBookings() {

    const container =
        document.getElementById(
            "recentBookings"
        );


    if (!container) return;


    const recent =
        adminBookings.slice(0, 5);


    if (!recent.length) {

        container.innerHTML = `

            <div class="empty-state">

                <div class="empty-icon">
                    📦
                </div>

                <h3>
                    No bookings yet
                </h3>

                <p>
                    Customer bookings will appear here.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        recent.map(
            function (booking) {

                const driver =
                    booking.driver &&
                    booking.driver.name

                        ? booking.driver.name

                        : "Not Assigned";


                return `

                    <div class="recent-booking-row">

                        <div class="recent-booking-icon">
                            🚛
                        </div>


                        <div class="recent-booking-info">

                            <strong>
                                ${escapeHtml(
                                    booking.id ||
                                    "Booking"
                                )}
                            </strong>


                            <span>
                                ${escapeHtml(
                                    booking.userName ||
                                    "Customer"
                                )}
                            </span>

                        </div>


                        <div class="recent-booking-route">

                            <small>
                                ${escapeHtml(
                                    booking.pickup ||
                                    "Pickup"
                                )}
                            </small>


                            <span>→</span>


                            <small>
                                ${escapeHtml(
                                    booking.drop ||
                                    "Drop"
                                )}
                            </small>

                        </div>


                        <div class="recent-booking-driver">

                            <span class="driver-mini-icon">
                                👨‍✈️
                            </span>


                            <span>
                                ${escapeHtml(
                                    driver
                                )}
                            </span>

                        </div>


                        <div class="recent-booking-status">

                            ${getStatusBadge(
                                booking.status
                            )}

                        </div>

                    </div>

                `;

            }
        ).join("");

}


/* =========================================================
   ALL BOOKINGS TABLE
========================================================= */

function renderBookingsTable() {

    const tableBody =
        document.getElementById(
            "bookingsTableBody"
        );


    const emptyState =
        document.getElementById(
            "emptyBookings"
        );


    if (!tableBody) return;


    const searchInput =
        document.getElementById(
            "bookingSearch"
        );


    const statusFilter =
        document.getElementById(
            "bookingStatusFilter"
        );


    const search =
        searchInput
            ? searchInput.value
                .trim()
                .toLowerCase()
            : "";


    const selectedStatus =
        statusFilter
            ? statusFilter.value
            : "";


    const filtered =
        adminBookings.filter(
            function (booking) {

                const searchableText =
                    [

                        booking.id,

                        booking.userName,

                        booking.userId,

                        booking.pickup,

                        booking.drop,

                        booking.vehicle,

                        booking.driver &&
                            booking.driver.name,

                        booking.driverName,

                        booking.assignedDriver

                    ]
                        .join(" ")
                        .toLowerCase();


                const matchesSearch =
                    !search ||
                    searchableText.includes(
                        search
                    );


                const matchesStatus =
                    !selectedStatus ||
                    String(
                        booking.status || ""
                    )
                        .toLowerCase()
                        ===
                        selectedStatus.toLowerCase();


                return (
                    matchesSearch &&
                    matchesStatus
                );

            }
        );


    if (!filtered.length) {

        tableBody.innerHTML = "";


        if (emptyState) {

            emptyState.style.display =
                "block";

        }

        return;

    }


    if (emptyState) {

        emptyState.style.display =
            "none";

    }


    tableBody.innerHTML =
        filtered.map(
            function (booking) {

                const created =
                    formatDate(
                        booking.createdAt
                    );


                const driverName =
                    booking.driver?.name ||
                    booking.driverName ||
                    booking.assignedDriver ||
                    "Not Assigned";


                return `

                    <tr>

                        <td>

                            <strong>
                                ${escapeHtml(
                                    booking.id ||
                                    "-"
                                )}
                            </strong>

                        </td>


                        <td>

                            ${escapeHtml(
                                booking.userName ||
                                "Customer"
                            )}

                        </td>


                        <td>

                            <div class="route-cell">

                                <span>
                                    ${escapeHtml(
                                        booking.pickup ||
                                        "-"
                                    )}
                                </span>


                                <b>→</b>


                                <span>
                                    ${escapeHtml(
                                        booking.drop ||
                                        "-"
                                    )}
                                </span>

                            </div>

                        </td>


                        <td>

                            ${escapeHtml(
                                booking.vehicle ||
                                "-"
                            )}

                        </td>


                        <td>

                            ${escapeHtml(
                                driverName
                            )}

                        </td>


                        <td>

                            ₹${Number(
                                booking.total || 0
                            ).toFixed(0)}

                        </td>


                        <td>

                            <div class="status-driver-cell">

                                ${getStatusBadge(
                                    booking.status
                                )}

                                <span class="table-driver-name">

                                    👨‍✈️

                                    ${escapeHtml(
                                        driverName
                                    )}

                                </span>

                            </div>

                        </td>


                        <td>

                            ${created}

                        </td>


                        <td>

                            <button
                                class="view-booking-btn"
                                onclick="viewBooking('${escapeJs(
                                    booking.id || ""
                                )}')"
                            >
                                View
                            </button>

                        </td>

                    </tr>

                `;

            }
        ).join("");

}


/* =========================================================
   CUSTOMERS
========================================================= */

function renderCustomers() {

    const tableBody =
        document.getElementById(
            "customersTableBody"
        );


    if (!tableBody) return;


    if (!adminUsers.length) {

        tableBody.innerHTML = `

            <tr>

                <td
                    colspan="6"
                    style="text-align:center;padding:30px;"
                >

                    No customers registered yet.

                </td>

            </tr>

        `;

        return;

    }


    tableBody.innerHTML =
        adminUsers.map(
            function (user) {

                const customerBookings =
                    adminBookings.filter(
                        function (booking) {

                            return (
                                booking.userId ===
                                user.id
                            );

                        }
                    ).length;


                return `

                    <tr>

                        <td>

                            <div class="customer-name-cell">

                                <div class="customer-avatar">
                                    👤
                                </div>


                                <strong>
                                    ${escapeHtml(
                                        user.name ||
                                        "Customer"
                                    )}
                                </strong>

                            </div>

                        </td>


                        <td>

                            ${escapeHtml(
                                user.phone ||
                                user.mobile ||
                                "-"
                            )}

                        </td>


                        <td>

                            ${escapeHtml(
                                user.email ||
                                "-"
                            )}

                        </td>


                        <td>

                            ${customerBookings}

                        </td>


                        <td>

                            <span class="customer-active">
                                Active
                            </span>

                        </td>

                    </tr>

                `;

            }
        ).join("");

}


/* =========================================================
   VIEW BOOKING
========================================================= */

function viewBooking(bookingId) {

    const booking =
        adminBookings.find(
            function (item) {

                return (
                    String(item.id) ===
                    String(bookingId)
                );

            }
        );


    if (!booking) {

        showAdminToast(
            "Booking not found"
        );

        return;

    }


    currentAdminBooking =
        booking;


    const modal =
        document.getElementById(
            "bookingModal"
        );


    const modalId =
        document.getElementById(
            "modalBookingId"
        );


    const modalContent =
        document.getElementById(
            "bookingModalContent"
        );


    if (!modal) return;


    if (modalId) {

        modalId.textContent =
            booking.id ||
            "Booking Details";

    }


    if (modalContent) {

        const driver =
            booking.driver || {};


        modalContent.innerHTML = `

            <div class="booking-detail-grid">

                <div class="detail-item">

                    <label>Customer</label>

                    <strong>
                        ${escapeHtml(
                            booking.userName ||
                            "Customer"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <label>Phone</label>

                    <strong>
                        ${escapeHtml(
                            booking.phone ||
                            booking.userPhone ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item full">

                    <label>Pickup Location</label>

                    <strong>
                        ${escapeHtml(
                            booking.pickup ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item full">

                    <label>Drop Location</label>

                    <strong>
                        ${escapeHtml(
                            booking.drop ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <label>Goods</label>

                    <strong>
                        ${escapeHtml(
                            booking.goods ||
                            booking.goodsDescription ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <label>Vehicle</label>

                    <strong>
                        ${escapeHtml(
                            booking.vehicle ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <label>Driver</label>

                    <strong>
                        ${escapeHtml(
                            driver.name ||
                            "Not Assigned"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <label>Vehicle Number</label>

                    <strong>
                        ${escapeHtml(
                            driver.number ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <label>Payment Method</label>

                    <strong>
                        ${escapeHtml(
                            booking.paymentMethod ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <label>Payment Status</label>

                    <strong>
                        ${escapeHtml(
                            booking.paymentStatus ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <label>Total Fare</label>

                    <strong class="fare-value">

                        ₹${Number(
                            booking.total || 0
                        ).toFixed(0)}

                    </strong>

                </div>


                <div class="detail-item">

                    <label>Status</label>

                    <strong>

                        ${getStatusBadge(
                            booking.status
                        )}

                    </strong>

                </div>


                <div class="detail-item">

                    <label>Booking Date</label>

                    <strong>

                        ${formatDate(
                            booking.createdAt
                        )}

                    </strong>

                </div>

            </div>

        `;

    }


    modal.classList.add(
        "active"
    );

}


/* =========================================================
   CLOSE BOOKING MODAL
========================================================= */

function closeBookingModal() {

    const modal =
        document.getElementById(
            "bookingModal"
        );


    if (modal) {

        modal.classList.remove(
            "active"
        );

    }


    currentAdminBooking = null;

}


/* =========================================================
   SECTION SWITCHING
========================================================= */

function showSection(sectionName) {

    const sections =
        document.querySelectorAll(
            ".admin-section"
        );


    sections.forEach(
        function (section) {

            section.style.display =
                "none";

        }
    );


    const target =
        document.getElementById(
            sectionName
        );


    if (target) {

        target.style.display =
            "block";

    }


    const navItems =
        document.querySelectorAll(
            ".nav-item"
        );


    navItems.forEach(
        function (item) {

            item.classList.remove(
                "active"
            );

        }
    );


    const activeNav =
        document.querySelector(
            `[data-section="${sectionName}"]`
        );


    if (activeNav) {

        activeNav.classList.add(
            "active"
        );

    }

}


/* =========================================================
   DATE
========================================================= */

function setAdminDate() {

    const dateElement =
        document.getElementById(
            "adminDate"
        );


    if (!dateElement) return;


    const today =
        new Date();


    dateElement.textContent =
        today.toLocaleDateString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );

}


/* =========================================================
   STATUS BADGE
========================================================= */

function getStatusBadge(status) {

    const value =
        String(
            status || "Pending"
        );


    const className =
        value
            .toLowerCase()
            .replace(
                /\s+/g,
                "-"
            );


    return `

        <span class="status-badge ${className}">

            ${escapeHtml(value)}

        </span>

    `;

}


/* =========================================================
   FORMAT DATE
========================================================= */

function formatDate(dateValue) {

    if (!dateValue) {

        return "-";

    }


    const date =
        new Date(dateValue);


    if (isNaN(date.getTime())) {

        return "-";

    }


    return date.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


/* =========================================================
   SET TEXT
========================================================= */

function setText(id, value) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}


/* =========================================================
   HTML ESCAPE
========================================================= */

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


/* =========================================================
   JAVASCRIPT STRING ESCAPE
========================================================= */

function escapeJs(value) {

    return String(
        value || ""
    )

        .replace(
            /\\/g,
            "\\\\"
        )

        .replace(
            /'/g,
            "\\'"
        )

        .replace(
            /\r?\n/g,
            "\\n"
        );

}


/* =========================================================
   ADMIN TOAST
========================================================= */

function showAdminToast(message) {

    const toast =
        document.getElementById(
            "adminToast"
        );


    if (!toast) return;


    toast.textContent =
        message;


    toast.classList.add(
        "show"
    );


    setTimeout(
        function () {

            toast.classList.remove(
                "show"
            );

        },
        2500
    );

}


/* =========================================================
   LOGOUT
========================================================= */

function adminLogout() {

    localStorage.removeItem(
        ADMIN_SESSION_KEY
    );


    window.location.href =
        "admin-login.html";

}


/* =========================================================
   GO TO CUSTOMER APP
========================================================= */

function goToCustomerApp() {

    window.location.href =
        "../index.html";

}


/* =========================================================
   CLOSE MODAL OUTSIDE CLICK
========================================================= */

window.addEventListener(
    "click",
    function (event) {

        const modal =
            document.getElementById(
                "bookingModal"
            );


        if (
            modal &&
            event.target === modal
        ) {

            closeBookingModal();

        }

    }
);


/* =========================================================
   EXPOSE FUNCTIONS TO HTML
========================================================= */

window.handleAdminLogin =
    handleAdminLogin;

window.openAdminDashboard =
    openAdminDashboard;

window.adminLogout =
    adminLogout;

window.goToCustomerApp =
    goToCustomerApp;

window.initializeAdminFirebase =
    initializeAdminFirebase;

window.loadAdminData =
    loadAdminData;

window.loadBookings =
    loadBookings;

window.loadUsers =
    loadUsers;

window.loadDriversFromFirebase =
    loadDriversFromFirebase;

window.initializeDriversInFirebase =
    initializeDriversInFirebase;

window.renderDrivers =
    renderDrivers;

window.renderVehicles =
    renderVehicles;

window.makeDriverAvailable =
    makeDriverAvailable;

window.setDriverOnTrip =
    setDriverOnTrip;

window.viewBooking =
    viewBooking;

window.closeBookingModal =
    closeBookingModal;

window.showSection =
    showSection;

window.showAdminToast =
    showAdminToast;