/* =========================================================
   QUIKTEMO - CUSTOMER APP
   COMPLETE UPDATED JAVASCRIPT
========================================================= */


/* =========================================================
   FIREBASE INITIALIZATION
========================================================= */

const firebaseConfig = {
    apiKey: "AIzaC1qusMOZC4U38EMBKdyixpAzSfaB4X2uA",
    authDomain: "quicktempo-89055.firebaseapp.com",
    databaseURL: "https://quicktempo-89055-default-rtdb.firebaseio.com",
    projectId: "quicktempo-89055",
    storageBucket: "quicktempo-89055.firebasestorage.app",
    messagingSenderId: "813695756465",
    appId: "1:813695756465:web:3d0143ffeebf86324c5a90"
};

let firebaseDatabase = null;

try {

    if (typeof firebase !== "undefined") {

        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }

        firebaseDatabase = firebase.database();

        console.log("Firebase connected successfully");

    } else {

        console.warn("Firebase SDK not loaded");

    }

} catch (error) {

    console.error(
        "Firebase initialization error:",
        error
    );

}


/* =========================================================
   ADMIN LOGIN CREDENTIALS
========================================================= */

const ADMIN_EMAIL =
    "admin@quiktemo.com";

const ADMIN_PASSWORD =
    "Admin@123";


/* =========================================================
   GLOBAL STATE
========================================================= */

let isSignupMode = false;

let currentPage = "home";

let locationMode = "pickup";

let selectedGoods = "";

let selectedVehicle = {
    name: "Mini Tempo",
    price: 300
};

let selectedSchedule = "Now";

let selectedPayment = "UPI";

let currentBooking = null;

let currentLocationData = {
    lat: null,
    lng: null,
    address: ""
};

let routeMap = null;

let trackingMap = null;

let routeDirectionsService = null;

let routeDirectionsRenderer = null;

let routeDistanceKm = 0;

let locationAutocomplete = null;


/* =========================================================
   DRIVER DEFAULT DATA
========================================================= */

/*
   DEMO DRIVER SETUP

   Rajesh  -> Available
   Rahul   -> Available
   Amit    -> On Trip
   Suresh  -> Available

   Firebase will use this data only if
   the drivers node does not already exist.
*/

const defaultDrivers = [

    {
        id: "DRV001",
        name: "Rajesh Kumar",
        vehicle: "MH-04-AB-1234",
        vehicleType: "Mini Tempo",
        status: "Available"
    },

    {
        id: "DRV002",
        name: "Rahul Patil",
        vehicle: "MH-03-AB-4521",
        vehicleType: "Tata Ace",
        status: "Available"
    },

    {
        id: "DRV003",
        name: "Amit Shinde",
        vehicle: "MH-04-CD-2211",
        vehicleType: "Pickup Truck",
        status: "On Trip"
    },

    {
        id: "DRV004",
        name: "Suresh More",
        vehicle: "MH-05-EF-3344",
        vehicleType: "Mini Tempo",
        status: "Available"
    }

];


/* =========================================================
   NOTIFICATION TRACKING
========================================================= */

const notifiedDriverBookings = new Set();


/* =========================================================
   STORAGE HELPERS
========================================================= */

function getUsers() {

    try {

        return JSON.parse(
            localStorage.getItem("quiktempo_users")
        ) || [];

    } catch (error) {

        return [];

    }

}


function saveUsers(users) {

    localStorage.setItem(
        "quiktempo_users",
        JSON.stringify(users)
    );

}


function getBookings() {

    try {

        return JSON.parse(
            localStorage.getItem("quiktempo_bookings")
        ) || [];

    } catch (error) {

        return [];

    }

}


function saveBookings(bookings) {

    localStorage.setItem(
        "quiktempo_bookings",
        JSON.stringify(bookings)
    );

}


function getCurrentUser() {

    try {

        return JSON.parse(
            localStorage.getItem("quiktempo_current_user")
        );

    } catch (error) {

        return null;

    }

}


function saveCurrentUser(user) {

    localStorage.setItem(
        "quiktempo_current_user",
        JSON.stringify(user)
    );

}


function removeCurrentUser() {

    localStorage.removeItem(
        "quiktempo_current_user"
    );

}


/* =========================================================
   ADMIN LOGIN CHECK
========================================================= */

function checkAdminLogin(
    loginValue,
    password
) {

    const enteredValue =
        String(loginValue || "")
            .trim()
            .toLowerCase();

    const enteredPassword =
        String(password || "");

    if (
        enteredValue ===
        ADMIN_EMAIL.toLowerCase() &&
        enteredPassword ===
        ADMIN_PASSWORD
    ) {

        localStorage.setItem(
            "quiktempo_admin_logged_in",
            "true"
        );

        removeCurrentUser();

        showToast(
            "Admin login successful"
        );

        setTimeout(function () {

            window.location.href =
                "admin/admin-dashboard.html";

        }, 300);

        return true;

    }

    return false;

}


/* =========================================================
   DOM HELPER
========================================================= */

function $(id) {

    return document.getElementById(id);

}


function setText(id, value) {

    const element = $(id);

    if (element) {
        element.textContent = value;
    }

}


function showElement(id) {

    const element = $(id);

    if (element) {
        element.style.display = "";
    }

}


function hideElement(id) {

    const element = $(id);

    if (element) {
        element.style.display = "none";
    }

}


/* =========================================================
   INITIALIZATION
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        initializeApp();

    }
);


function initializeApp() {

    const splash = $("splashScreen");

    const auth = $("authScreen");

    const app = $("mainApp");


    if (auth) {
        auth.style.display = "none";
    }


    if (app) {
        app.style.display = "none";
    }


    /*
       Initialize driver system.
    */

    initializeDriversInFirebase();

    listenForDriverAvailability();


    setTimeout(function () {

        if (splash) {
            splash.style.display = "none";
        }


        const user =
            getCurrentUser();


        if (user) {

            showMainApp();

            syncBookingsFromFirebase();

        } else {

            showAuthScreen();

        }

    }, 1200);


    initializeInputFormatting();

    updateHistory();

}


/* =========================================================
   AUTH SCREEN
========================================================= */

function showAuthScreen() {

    if ($("authScreen")) {
        $("authScreen").style.display = "flex";
    }


    if ($("mainApp")) {
        $("mainApp").style.display = "none";
    }

}


/* =========================================================
   SHOW MAIN APP
========================================================= */

function showMainApp() {

    if ($("authScreen")) {
        $("authScreen").style.display = "none";
    }


    if ($("mainApp")) {
        $("mainApp").style.display = "block";
    }


    updateProfile();

    navigate("home");

    updateHistory();

}


/* =========================================================
   TOGGLE LOGIN / SIGNUP
========================================================= */

function toggleAuth() {

    isSignupMode =
        !isSignupMode;


    const signupFields =
        $("signupFields");


    if (isSignupMode) {

        if (signupFields) {
            signupFields.style.display =
                "block";
        }


        setText(
            "authTitle",
            "Create your QuikTempo account"
        );


        setText(
            "authSubtitle",
            "Sign up to book a tempo"
        );


        setText(
            "authButtonText",
            "Sign Up"
        );


        setText(
            "authSwitchText",
            "Already have an account?"
        );


        setText(
            "authSwitchBtn",
            "Login"
        );

    } else {

        if (signupFields) {
            signupFields.style.display =
                "none";
        }


        setText(
            "authTitle",
            "Welcome to QuikTempo"
        );


        setText(
            "authSubtitle",
            "Book a tempo for your goods"
        );


        setText(
            "authButtonText",
            "Login"
        );


        setText(
            "authSwitchText",
            "Don't have an account?"
        );


        setText(
            "authSwitchBtn",
            "Sign Up"
        );

    }

}


/* =========================================================
   LOGIN / SIGNUP
========================================================= */

function handleAuth() {

    const phone =
        $("authPhone")
            ? $("authPhone").value.trim()
            : "";


    const password =
        $("authPassword")
            ? $("authPassword").value
            : "";


    if (!phone || !password) {

        showToast(
            "Please enter login details"
        );

        return;

    }


    /* =====================================================
       ADMIN LOGIN
    ===================================================== */

    const ADMIN_PHONE =
        "9876543210";

    const ADMIN_PASSWORD =
        "admin123";


    if (!isSignupMode) {

        if (
            phone === ADMIN_PHONE &&
            password === ADMIN_PASSWORD
        ) {

            /*
               IMPORTANT:
               Set admin session before redirect.
            */

            localStorage.setItem(
                "quiktempo_admin_logged_in",
                "true"
            );


            showToast(
                "Admin login successful"
            );


            setTimeout(function () {

                window.location.href =
                    "admin/admin-dashboard.html";

            }, 500);


            return;

        }

    }


    /* =====================================================
       CUSTOMER SIGNUP
    ===================================================== */

    if (isSignupMode) {

        if (phone === ADMIN_PHONE) {

            showToast(
                "This mobile number is reserved for Admin"
            );

            return;

        }


        if (!/^\d{10}$/.test(phone)) {

            showToast(
                "Enter a valid 10-digit phone number"
            );

            return;

        }


        const users =
            getUsers();


        const name =
            $("signupName")
                ? $("signupName")
                    .value
                    .trim()
                : "";


        const signupPhone =
            $("signupPhone")
                ? $("signupPhone")
                    .value
                    .trim()
                : "";


        const confirmSignupPhone =
            $("confirmSignupPhone")
                ? $("confirmSignupPhone")
                    .value
                    .trim()
                : signupPhone;


        if (!name) {

            showToast(
                "Please enter your name"
            );

            return;

        }


        if (!/^\d{10}$/.test(signupPhone)) {

            showToast(
                "Enter a valid signup phone number"
            );

            return;

        }


        if (
            signupPhone !==
            confirmSignupPhone
        ) {

            showToast(
                "Phone numbers do not match"
            );

            return;

        }


        if (
            signupPhone !==
            phone
        ) {

            showToast(
                "Signup phone and login phone should match"
            );

            return;

        }


        const alreadyExists =
            users.some(
                function (user) {

                    return (
                        user.phone ===
                        phone
                    );

                }
            );


        if (alreadyExists) {

            showToast(
                "Account already exists. Please login."
            );

            return;

        }


        const newUser = {

            id:
                "USR-" +
                Date.now(),

            name:
                name,

            phone:
                phone,

            password:
                password,

            createdAt:
                new Date().toISOString()

        };


        users.push(
            newUser
        );


        saveUsers(
            users
        );


        saveCurrentUser(
            newUser
        );


        saveUserToFirebase(
            newUser
        );


        showToast(
            "Account created successfully"
        );


        setTimeout(function () {

            showMainApp();

            syncBookingsFromFirebase();

        }, 500);


        return;

    }


    /* =====================================================
       CUSTOMER LOGIN
    ===================================================== */

    if (!/^\d{10}$/.test(phone)) {

        showToast(
            "Enter a valid 10-digit phone number"
        );

        return;

    }


    const users =
        getUsers();


    const user =
        users.find(
            function (item) {

                return (
                    item.phone === phone &&
                    item.password === password
                );

            }
        );


    if (!user) {

        showToast(
            "Invalid phone number or password"
        );

        return;

    }


    saveCurrentUser(
        user
    );


    showToast(
        "Login successful"
    );


    setTimeout(function () {

        showMainApp();

        syncBookingsFromFirebase();

    }, 400);

}


/* =========================================================
   SAVE USER TO FIREBASE
========================================================= */

function saveUserToFirebase(user) {

    if (
        !firebaseDatabase ||
        !user
    ) {

        return;

    }


    firebaseDatabase
        .ref(
            "users/" +
            user.id
        )
        .set({

            id:
                user.id,

            name:
                user.name,

            phone:
                user.phone,

            createdAt:
                user.createdAt

        })
        .then(function () {

            console.log(
                "User saved to Firebase:",
                user.id
            );

        })
        .catch(function (error) {

            console.error(
                "Firebase user save error:",
                error
            );

        });

}


/* =========================================================
   GUEST LOGIN
========================================================= */

function guestLogin() {

    const guest = {

        id:
            "GUEST-" +
            Date.now(),

        name:
            "Guest User",

        phone:
            "",

        guest:
            true

    };


    saveCurrentUser(
        guest
    );


    showToast(
        "Continuing as Guest"
    );


    setTimeout(function () {

        showMainApp();

        syncBookingsFromFirebase();

    }, 400);

}


/* =========================================================
   LOGOUT
========================================================= */

function logout() {

    const confirmLogout =
        confirm(
            "Are you sure you want to logout?"
        );


    if (!confirmLogout) {
        return;
    }


    currentBooking =
        null;


    removeCurrentUser();


    closeAllModals();


    showToast(
        "Logged out successfully"
    );


    setTimeout(function () {

        isSignupMode =
            false;

        showAuthScreen();

    }, 300);

}


/* =========================================================
   PROFILE
========================================================= */

function updateProfile() {

    const user =
        getCurrentUser();


    if (!user) {
        return;
    }


    setText(
        "profileName",
        user.name ||
        "Guest User"
    );


    setText(
        "profilePhone",
        user.phone ||
        "Guest account"
    );

}


/* =========================================================
   NAVIGATION
========================================================= */

function navigate(page) {

    const pages = [

        "home",
        "booking",
        "tracking",
        "history",
        "profile"

    ];


    if (!pages.includes(page)) {
        page = "home";
    }


    currentPage =
        page;


    pages.forEach(
        function (pageName) {

            const pageElement =
                $(
                    pageName +
                    "Page"
                );


            if (!pageElement) {
                return;
            }


            if (
                pageName ===
                page
            ) {

                pageElement.classList.add(
                    "active-page"
                );

                pageElement.style.display =
                    "";

            } else {

                pageElement.classList.remove(
                    "active-page"
                );

                pageElement.style.display =
                    "none";

            }

        }
    );


    document
        .querySelectorAll(".nav-item")
        .forEach(
            function (item) {

                item.classList.toggle(
                    "active",
                    item.dataset.page ===
                    page
                );

            }
        );


    if (page === "history") {

        updateHistory();

    }


    if (page === "profile") {

        updateProfile();

    }


    if (page === "tracking") {

        updateTrackingPage();


        setTimeout(
            function () {

                initializeTrackingMap();

            },
            100
        );

    }


    window.scrollTo({

        top: 0,

        behavior: "smooth"

    });

}


/* =========================================================
   BOOKING START
========================================================= */

function startBooking() {

    const pickup =
        getLocationValue(
            "pickup"
        );


    const drop =
        getLocationValue(
            "drop"
        );


    if (!pickup) {

        showToast(
            "Please select pickup location"
        );

        return;

    }


    if (!drop) {

        showToast(
            "Please select drop location"
        );

        return;

    }


    setText(
        "bookingPickup",
        pickup
    );


    setText(
        "bookingDrop",
        drop
    );


    navigate(
        "booking"
    );


    showBookingStep(
        1
    );


    calculateRoute();

}


/* =========================================================
   QUICK BOOKING
========================================================= */

function quickBooking(goods) {

    selectedGoods =
        goods;


    navigate(
        "booking"
    );


    showBookingStep(
        1
    );


    document
        .querySelectorAll(".goods-btn")
        .forEach(
            function (button) {

                button.classList.remove(
                    "selected"
                );


                const buttonText =
                    button.textContent
                        .trim()
                        .replace(
                            /\s+/g,
                            " "
                        );


                if (
                    buttonText.includes(
                        goods
                    )
                ) {

                    button.classList.add(
                        "selected"
                    );

                }

            }
        );


    const details =
        $("goodsDetails");


    if (details) {

        details.style.display =
            "block";

    }


    showToast(
        goods +
        " selected"
    );

}


/* =========================================================
   LOCATION VALUES
========================================================= */

function getLocationValue(type) {

    if (
        type ===
        "pickup"
    ) {

        const element =
            $("pickupInput");


        return element
            ? element.textContent.trim()
            : "";

    }


    if (
        type ===
        "drop"
    ) {

        const element =
            $("dropInput");


        return element
            ? element.textContent.trim()
            : "";

    }


    return "";

}


/* =========================================================
   SWAP LOCATIONS
========================================================= */

function swapLocations() {

    const pickup =
        getLocationValue(
            "pickup"
        );


    const drop =
        getLocationValue(
            "drop"
        );


    if (
        !pickup ||
        pickup ===
        "Select pickup location"
    ) {

        showToast(
            "Select pickup location first"
        );

        return;

    }


    if (
        !drop ||
        drop ===
        "Select drop location"
    ) {

        showToast(
            "Select drop location first"
        );

        return;

    }


    setLocationValue(
        "pickup",
        drop
    );


    setLocationValue(
        "drop",
        pickup
    );


    showToast(
        "Locations swapped"
    );


    calculateRoute();

}


/* =========================================================
   SET LOCATION
========================================================= */

function setLocationValue(
    type,
    value
) {

    if (
        type ===
        "pickup"
    ) {

        setText(
            "pickupInput",
            value
        );


        setText(
            "bookingPickup",
            value
        );

    }


    if (
        type ===
        "drop"
    ) {

        setText(
            "dropInput",
            value
        );


        setText(
            "bookingDrop",
            value
        );

    }

}


/* =========================================================
   LOCATION PICKER
========================================================= */

function openLocationPicker(type) {

    locationMode =
        type;


    const title =
        type === "pickup"
            ? "Select Pickup Location"
            : "Select Drop Location";


    setText(
        "locationModalTitle",
        title
    );


    const modal =
        $("locationModal");


    if (modal) {

        modal.style.display =
            "flex";

    }


    const input =
        $("locationSearchInput");


    if (input) {

        input.value =
            "";


        setTimeout(
            function () {

                input.focus();

            },
            100
        );

    }


    renderLocationSuggestions(
        ""
    );

}


/* =========================================================
   CLOSE LOCATION MODAL
========================================================= */

function closeLocationModal() {

    const modal =
        $("locationModal");


    if (modal) {

        modal.style.display =
            "none";

    }

}


/* =========================================================
   CLEAR LOCATION SEARCH
========================================================= */

function clearLocationSearch() {

    const input =
        $("locationSearchInput");


    if (input) {

        input.value =
            "";

    }


    renderLocationSuggestions(
        ""
    );

}


/* =========================================================
   COMMON LOCATIONS
========================================================= */

const commonLocations = [

    "Kharghar, Navi Mumbai",

    "Panvel, Navi Mumbai",

    "Belapur, Navi Mumbai",

    "Vashi, Navi Mumbai",

    "Nerul, Navi Mumbai",

    "Seawoods, Navi Mumbai",

    "CBD Belapur, Navi Mumbai",

    "Sanpada, Navi Mumbai",

    "Airoli, Navi Mumbai",

    "Ghansoli, Navi Mumbai",

    "Thane, Maharashtra",

    "Dadar, Mumbai",

    "Andheri, Mumbai",

    "Bandra, Mumbai",

    "Kurla, Mumbai",

    "Vashi Railway Station",

    "Panvel Railway Station",

    "Kharghar Railway Station",

    "Taloja, Navi Mumbai"

];


/* =========================================================
   LOCATION SEARCH
========================================================= */

function searchLocations(query) {

    query =
        String(
            query || ""
        ).trim();


    if (!query) {

        renderLocationSuggestions(
            ""
        );

        return;

    }


    if (
        window.google &&
        google.maps &&
        google.maps.places
    ) {

        const service =
            new google.maps.places
                .AutocompleteService();


        service.getPlacePredictions(

            {

                input:
                    query,

                componentRestrictions: {

                    country:
                        "in"

                }

            },

            function (
                predictions,
                status
            ) {

                if (
                    status ===
                    google.maps.places
                        .PlacesServiceStatus.OK &&
                    predictions
                ) {

                    renderGoogleSuggestions(
                        predictions
                    );

                } else {

                    renderLocationSuggestions(
                        query
                    );

                }

            }

        );


        return;

    }


    renderLocationSuggestions(
        query
    );

}


/* =========================================================
   RENDER LOCAL SUGGESTIONS
========================================================= */

function renderLocationSuggestions(
    query
) {

    const container =
        $("locationSuggestions");


    if (!container) {
        return;
    }


    const lowerQuery =
        String(
            query || ""
        ).toLowerCase();


    const filtered =
        commonLocations.filter(
            function (location) {

                return location
                    .toLowerCase()
                    .includes(
                        lowerQuery
                    );

            }
        );


    let results =
        filtered.slice(
            0,
            6
        );


    if (
        query &&
        results.length === 0
    ) {

        results = [
            query
        ];

    }


    container.innerHTML =
        "";


    if (results.length === 0) {

        container.innerHTML = `

            <div class="location-suggestion">
                No locations found
            </div>

        `;

        return;

    }


    results.forEach(
        function (location) {

            const item =
                document.createElement(
                    "button"
                );


            item.type =
                "button";


            item.className =
                "location-suggestion";


            item.innerHTML = `

                <span>📍</span>

                <span>
                    ${escapeHtml(location)}
                </span>

            `;


            item.addEventListener(
                "click",
                function () {

                    selectLocation(
                        location
                    );

                }
            );


            container.appendChild(
                item
            );

        }
    );

}


/* =========================================================
   GOOGLE LOCATION SUGGESTIONS
========================================================= */

function renderGoogleSuggestions(
    predictions
) {

    const container =
        $("locationSuggestions");


    if (!container) {
        return;
    }


    container.innerHTML =
        "";


    predictions
        .slice(
            0,
            6
        )
        .forEach(
            function (prediction) {

                const item =
                    document.createElement(
                        "button"
                    );


                item.type =
                    "button";


                item.className =
                    "location-suggestion";


                item.innerHTML = `

                    <span>📍</span>

                    <span>
                        ${escapeHtml(
                            prediction.description
                        )}
                    </span>

                `;


                item.addEventListener(
                    "click",
                    function () {

                        selectLocation(
                            prediction.description,
                            prediction.place_id
                        );

                    }
                );


                container.appendChild(
                    item
                );

            }
        );

}


/* =========================================================
   SELECT LOCATION
========================================================= */

function selectLocation(
    address,
    placeId = null
) {

    setLocationValue(
        locationMode,
        address
    );


    closeLocationModal();


    showToast(
        locationMode ===
        "pickup"

            ? "Pickup location selected"

            : "Drop location selected"
    );


    if (
        placeId &&
        window.google
    ) {

        getPlaceCoordinates(
            placeId,
            locationMode
        );

    }


    calculateRoute();

}


/* =========================================================
   GET PLACE COORDINATES
========================================================= */

function getPlaceCoordinates(
    placeId,
    selectedMode = locationMode
) {

    if (
        !window.google ||
        !google.maps ||
        !google.maps.places
    ) {

        return;

    }


    const tempDiv =
        document.createElement(
            "div"
        );


    const service =
        new google.maps.places
            .PlacesService(
                tempDiv
            );


    service.getDetails(

        {

            placeId:
                placeId,

            fields: [

                "geometry",

                "formatted_address"

            ]

        },

        function (
            place,
            status
        ) {

            if (
                status ===
                google.maps.places
                    .PlacesServiceStatus.OK &&
                place &&
                place.geometry
            ) {

                const location =
                    place.geometry.location;


                if (
                    selectedMode ===
                    "pickup"
                ) {

                    window.pickupCoords = {

                        lat:
                            location.lat(),

                        lng:
                            location.lng()

                    };

                } else {

                    window.dropCoords = {

                        lat:
                            location.lat(),

                        lng:
                            location.lng()

                    };

                }


                calculateRoute();

            }

        }

    );

}


/* =========================================================
   CURRENT LOCATION
========================================================= */

function detectCurrentLocation(
    closeModalAfter = false
) {

    if (
        !navigator.geolocation
    ) {

        showToast(
            "Geolocation is not supported by this browser"
        );

        return;

    }


    showToast(
        "Getting your current location..."
    );


    navigator.geolocation.getCurrentPosition(

        function (position) {

            const lat =
                position.coords.latitude;


            const lng =
                position.coords.longitude;


            currentLocationData = {

                lat:
                    lat,

                lng:
                    lng,

                address:
                    "Current Location"

            };


            if (
                window.google &&
                google.maps
            ) {

                const geocoder =
                    new google.maps.Geocoder();


                geocoder.geocode(

                    {

                        location: {

                            lat:
                                lat,

                            lng:
                                lng

                        }

                    },

                    function (
                        results,
                        status
                    ) {

                        let address =
                            "Current Location";


                        if (
                            status ===
                            "OK" &&
                            results &&
                            results.length
                        ) {

                            address =
                                results[0]
                                    .formatted_address;

                        }


                        currentLocationData
                            .address =
                            address;


                        setLocationValue(
                            locationMode,
                            address
                        );


                        updateHeaderLocation(
                            address
                        );


                        if (
                            closeModalAfter
                        ) {

                            closeLocationModal();

                        }


                        showToast(
                            "Current location selected"
                        );


                        calculateRoute();

                    }
                );

            } else {

                setLocationValue(
                    locationMode,
                    "Current Location"
                );


                updateHeaderLocation(
                    "Current Location"
                );


                if (
                    closeModalAfter
                ) {

                    closeLocationModal();

                }


                showToast(
                    "Current location selected"
                );

            }

        },

        function () {

            showToast(
                "Unable to get current location"
            );

        },

        {

            enableHighAccuracy:
                true,

            timeout:
                10000,

            maximumAge:
                60000

        }

    );

}


/* =========================================================
   USE CURRENT LOCATION
========================================================= */

function useCurrentLocation() {

    locationMode =
        "pickup";


    detectCurrentLocation(
        false
    );

}


/* =========================================================
   HEADER LOCATION
========================================================= */

function updateHeaderLocation(
    address
) {

    if (!address) {
        return;
    }


    let shortAddress =
        address;


    if (
        address.includes(",")
    ) {

        shortAddress =
            address
                .split(",")
                .slice(
                    0,
                    2
                )
                .join(",");

    }


    setText(
        "currentLocation",
        shortAddress
    );

}


/* =========================================================
   GOODS
========================================================= */

function selectGoods(
    button,
    goods
) {

    selectedGoods =
        goods;


    document
        .querySelectorAll(
            ".goods-btn"
        )
        .forEach(
            function (item) {

                item.classList.remove(
                    "selected"
                );

            }
        );


    if (button) {

        button.classList.add(
            "selected"
        );

    }


    const details =
        $("goodsDetails");


    if (details) {

        details.style.display =
            "block";

    }


    showToast(
        goods +
        " selected"
    );

}


/* =========================================================
   VEHICLE
========================================================= */

function selectVehicle(
    button
) {

    if (!button) {
        return;
    }


    document
        .querySelectorAll(
            ".vehicle-option"
        )
        .forEach(
            function (item) {

                item.classList.remove(
                    "selected"
                );

            }
        );


    button.classList.add(
        "selected"
    );


    selectedVehicle = {

        name:
            button.dataset.name ||
            "Mini Tempo",

        price:
            Number(
                button.dataset.price
            ) || 300

    };


    updateFare();


    showToast(
        selectedVehicle.name +
        " selected"
    );

}


/* =========================================================
   FARE CALCULATION
========================================================= */

function updateFare() {

    const baseFare =
        Number(
            selectedVehicle?.price
        ) || 300;


    const distance =
        Number(
            routeDistanceKm
        ) || 0;


    const distanceFare =
        Math.round(
            distance * 40
        );


    const platformFee =
        20;


    const discount =
        isFirstBooking()
            ? 100
            : 0;


    const total =
        Math.max(

            0,

            baseFare +
            distanceFare +
            platformFee -
            discount

        );


    setText(
        "baseFare",
        formatCurrency(
            baseFare
        )
    );


    setText(
        "distanceFare",
        formatCurrency(
            distanceFare
        )
    );


    setText(
        "platformFee",
        formatCurrency(
            platformFee
        )
    );


    setText(
        "discount",

        discount > 0

            ? "-" +
              formatCurrency(
                  discount
              )

            : formatCurrency(
                  0
              )

    );


    setText(
        "totalFare",
        formatCurrency(
            total
        )
    );

}


/* =========================================================
   FIRST BOOKING CHECK
========================================================= */

function isFirstBooking() {

    const bookings =
        getBookings();


    const user =
        getCurrentUser();


    if (!user) {

        return (
            bookings.length ===
            0
        );

    }


    const userBookings =
        bookings.filter(
            function (booking) {

                return (
                    booking.userId ===
                    user.id
                );

            }
        );


    return (
        userBookings.length ===
        0
    );

}


/* =========================================================
   CURRENT FARE
========================================================= */

function getCurrentFare() {

    const baseFare =
        Number(
            selectedVehicle?.price
        ) || 300;


    const distanceFare =
        Math.round(
            (
                Number(
                    routeDistanceKm
                ) || 0
            ) * 40
        );


    const platformFee =
        20;


    const discount =
        isFirstBooking()
            ? 100
            : 0;


    return Math.max(

        0,

        baseFare +
        distanceFare +
        platformFee -
        discount

    );

}


/* =========================================================
   SCHEDULE
========================================================= */

function selectSchedule(
    button,
    type
) {

    if (!button) {
        return;
    }


    document
        .querySelectorAll(
            ".schedule-btn"
        )
        .forEach(
            function (item) {

                item.classList.remove(
                    "selected"
                );

            }
        );


    button.classList.add(
        "selected"
    );


    selectedSchedule =
        type;


    if (
        type ===
        "Now"
    ) {

        setText(
            "selectedScheduleText",
            "Now - Pickup in ~15 mins"
        );


        setText(
            "selectedScheduleDisplay",
            "Now"
        );


        hideElement(
            "scheduleError"
        );


        return;

    }


    openScheduleModal();

}


/* =========================================================
   SCHEDULE MODAL
========================================================= */

function openScheduleModal() {

    const modal =
        $("scheduleModal");


    if (modal) {

        modal.style.display =
            "flex";

    }


    const dateInput =
        $("scheduleDate");


    const timeInput =
        $("scheduleTime");


    if (
        dateInput &&
        !dateInput.value
    ) {

        const tomorrow =
            new Date();


        tomorrow.setDate(
            tomorrow.getDate() +
            1
        );


        dateInput.value =
            formatDateInput(
                tomorrow
            );

    }


    if (
        timeInput &&
        !timeInput.value
    ) {

        const future =
            new Date(
                Date.now() +
                60 *
                60 *
                1000
            );


        timeInput.value =
            formatTimeInput(
                future
            );

    }

}


function closeScheduleModal() {

    const modal =
        $("scheduleModal");


    if (modal) {

        modal.style.display =
            "none";

    }

}


/* =========================================================
   CONFIRM SCHEDULE
========================================================= */

function confirmSchedule() {

    const date =
        $("scheduleDate")
            ? $("scheduleDate").value
            : "";


    const time =
        $("scheduleTime")
            ? $("scheduleTime").value
            : "";


    const error =
        $("scheduleError");


    if (
        !date ||
        !time
    ) {

        if (error) {

            error.textContent =
                "Please select date and time";

            error.style.display =
                "block";

        }

        return;

    }


    const selectedDateTime =
        new Date(
            `${date}T${time}`
        );


    if (
        Number.isNaN(
            selectedDateTime.getTime()
        )
    ) {

        if (error) {

            error.textContent =
                "Please select a valid date and time";

            error.style.display =
                "block";

        }

        return;

    }


    if (
        selectedDateTime.getTime() <=
        Date.now()
    ) {

        if (error) {

            error.textContent =
                "Please select a future time";

            error.style.display =
                "block";

        }

        return;

    }


    selectedSchedule =
        "Schedule";


    const displayDate =
        selectedDateTime.toLocaleDateString(
            "en-IN",
            {

                day:
                    "2-digit",

                month:
                    "short",

                year:
                    "numeric"

            }
        );


    const displayTime =
        selectedDateTime.toLocaleTimeString(
            "en-IN",
            {

                hour:
                    "2-digit",

                minute:
                    "2-digit"

            }
        );


    const display =
        `${displayDate} at ${displayTime}`;


    setText(
        "selectedScheduleText",
        display
    );


    setText(
        "selectedScheduleDisplay",
        display
    );


    closeScheduleModal();


    showToast(
        "Schedule selected"
    );

}


/* =========================================================
   BOOKING STEPS
========================================================= */

function showBookingStep(
    step
) {

    const steps = [
        1,
        2,
        3
    ];


    steps.forEach(
        function (number) {

            const element =
                $(
                    "bookingStep" +
                    number
                );


            if (!element) {
                return;
            }


            element.style.display =
                number === step
                    ? "block"
                    : "none";

        }
    );


    steps.forEach(
        function (number) {

            const progress =
                $(
                    "progressStep" +
                    number
                );


            if (!progress) {
                return;
            }


            if (
                number <= step
            ) {

                progress.classList.add(
                    "active"
                );

            } else {

                progress.classList.remove(
                    "active"
                );

            }

        }
    );


    if (
        step ===
        3
    ) {

        updateBookingSummary();

    }

}


/* =========================================================
   NEXT BOOKING STEP
========================================================= */

function nextBookingStep() {

    const step1 =
        $("bookingStep1");


    const step2 =
        $("bookingStep2");


    const step3 =
        $("bookingStep3");


    if (
        step1 &&
        step1.style.display !==
        "none"
    ) {

        const pickup =
            getLocationValue(
                "pickup"
            );


        const drop =
            getLocationValue(
                "drop"
            );


        if (
            !pickup ||
            pickup ===
            "Select pickup location"
        ) {

            showToast(
                "Please select pickup location"
            );

            return;

        }


        if (
            !drop ||
            drop ===
            "Select drop location"
        ) {

            showToast(
                "Please select drop location"
            );

            return;

        }


        if (!selectedGoods) {

            showToast(
                "Please select what you are transporting"
            );

            return;

        }


        showBookingStep(
            2
        );


        return;

    }


    if (
        step2 &&
        step2.style.display !==
        "none"
    ) {

        updateFare();

        showBookingStep(
            3
        );

        return;

    }


    if (
        step3 &&
        step3.style.display !==
        "none"
    ) {

        openPayment();

    }

}


/* =========================================================
   ROUTE CALCULATION
========================================================= */

function calculateRoute() {

    const pickup =
        getLocationValue(
            "pickup"
        );


    const drop =
        getLocationValue(
            "drop"
        );


    if (
        !pickup ||
        !drop ||
        pickup ===
        "Select pickup location" ||
        drop ===
        "Select drop location"
    ) {

        return;

    }


    if (
        window.google &&
        google.maps &&
        google.maps.DirectionsService
    ) {

        if (
            !routeDirectionsService
        ) {

            routeDirectionsService =
                new google.maps.DirectionsService();

        }


        if (!routeMap) {

            initializeRouteMap();

        }


        if (
            !routeDirectionsRenderer
        ) {

            routeDirectionsRenderer =
                new google.maps.DirectionsRenderer({

                    map:
                        routeMap,

                    suppressMarkers:
                        false

                });

        } else {

            routeDirectionsRenderer.setMap(
                routeMap
            );

        }


        routeDirectionsService.route(

            {

                origin:
                    pickup,

                destination:
                    drop,

                travelMode:
                    google.maps.TravelMode.DRIVING

            },

            function (
                result,
                status
            ) {

                if (
                    status ===
                    "OK" &&
                    result &&
                    result.routes &&
                    result.routes.length
                ) {

                    routeDirectionsRenderer
                        .setDirections(
                            result
                        );


                    const leg =
                        result.routes[0]
                            .legs[0];


                    routeDistanceKm =
                        leg.distance.value /
                        1000;


                    setText(
                        "routeDistanceText",
                        `${leg.distance.text} • ${leg.duration.text}`
                    );


                    showElement(
                        "routeDistanceInfo"
                    );


                    updateFare();

                } else {

                    routeDistanceKm =
                        5;


                    setText(
                        "routeDistanceText",
                        "Approx. 5 km"
                    );


                    showElement(
                        "routeDistanceInfo"
                    );


                    updateFare();

                }

            }

        );


        return;

    }


    routeDistanceKm =
        5;


    setText(
        "routeDistanceText",
        "Approx. 5 km"
    );


    showElement(
        "routeDistanceInfo"
    );


    updateFare();

}


/* =========================================================
   GOOGLE MAPS INITIALIZATION
========================================================= */

function initGoogleMaps() {

    try {

        initializeRouteMap();

        initializeTrackingMap();

        calculateRoute();

    } catch (error) {

        console.warn(
            "Google Maps initialization error:",
            error
        );

    }

}


/* =========================================================
   ROUTE MAP
========================================================= */

function initializeRouteMap() {

    const mapElement =
        $("routeMap");


    if (
        !mapElement ||
        !window.google ||
        !google.maps
    ) {

        return;

    }


    if (!routeMap) {

        routeMap =
            new google.maps.Map(

                mapElement,

                {

                    center: {

                        lat:
                            19.0473,

                        lng:
                            73.0699

                    },

                    zoom:
                        12,

                    mapTypeControl:
                        false,

                    streetViewControl:
                        false,

                    fullscreenControl:
                        false

                }

            );

    }


    if (
        routeDirectionsRenderer
    ) {

        routeDirectionsRenderer.setMap(
            routeMap
        );

    }

}


/* =========================================================
   TRACKING MAP
========================================================= */

function initializeTrackingMap() {

    const mapElement =
        $("trackingMap");


    if (
        !mapElement ||
        !window.google ||
        !google.maps
    ) {

        return;

    }


    if (!trackingMap) {

        trackingMap =
            new google.maps.Map(

                mapElement,

                {

                    center: {

                        lat:
                            19.0473,

                        lng:
                            73.0699

                    },

                    zoom:
                        13,

                    mapTypeControl:
                        false,

                    streetViewControl:
                        false,

                    fullscreenControl:
                        false

                }

            );


        new google.maps.Marker({

            position: {

                lat:
                    19.0473,

                lng:
                    73.0699

            },

            map:
                trackingMap,

            title:
                "Driver location"

        });

    }

}


/* =========================================================
   BOOKING SUMMARY
========================================================= */

function updateBookingSummary() {

    const pickup =
        getLocationValue(
            "pickup"
        );


    const drop =
        getLocationValue(
            "drop"
        );


    updateFare();


    const bookingId =
        currentBooking?.id ||
        generateBookingId();


    setText(
        "summaryBookingId",
        bookingId
    );


    setText(
        "summaryPickup",
        pickup ||
        "—"
    );


    setText(
        "summaryDrop",
        drop ||
        "—"
    );


    setText(
        "summaryGoods",
        selectedGoods ||
        "—"
    );


    setText(
        "summaryVehicle",
        selectedVehicle.name
    );


    setText(
        "summarySchedule",
        getScheduleDisplay()
    );


    setText(
        "modalPaymentAmount",

        formatCurrency(
            getCurrentFare()
        )

    );

}


/* =========================================================
   SCHEDULE DISPLAY
========================================================= */

function getScheduleDisplay() {

    if (
        selectedSchedule ===
        "Now"
    ) {

        return "Now - Pickup in ~15 mins";

    }


    const date =
        $("scheduleDate")
            ? $("scheduleDate").value
            : "";


    const time =
        $("scheduleTime")
            ? $("scheduleTime").value
            : "";


    if (
        !date ||
        !time
    ) {

        return "Scheduled";

    }


    const dateObject =
        new Date(
            `${date}T${time}`
        );


    return (

        dateObject.toLocaleDateString(

            "en-IN",

            {

                day:
                    "2-digit",

                month:
                    "short",

                year:
                    "numeric"

            }

        )

        +

        " at "

        +

        dateObject.toLocaleTimeString(

            "en-IN",

            {

                hour:
                    "2-digit",

                minute:
                    "2-digit"

            }

        )

    );

}


/* =========================================================
   PAYMENT SELECTION
========================================================= */

function selectPayment(
    button,
    method
) {

    selectedPayment =
        method;


    document
        .querySelectorAll(
            ".payment-option"
        )
        .forEach(
            function (item) {

                item.classList.remove(
                    "selected"
                );

            }
        );


    if (button) {

        button.classList.add(
            "selected"
        );

    }


    showToast(
        method +
        " selected"
    );

}


/* =========================================================
   OPEN PAYMENT
========================================================= */

function openPayment() {

    updateBookingSummary();

    updateFare();


    const payment =
        $("paymentModal");


    if (!payment) {
        return;
    }


    payment.style.display =
        "flex";


    showPaymentForm(
        selectedPayment
    );

}


/* =========================================================
   PAYMENT FORM
========================================================= */

function showPaymentForm(
    method
) {

    hideElement(
        "upiForm"
    );


    hideElement(
        "cardForm"
    );


    hideElement(
        "cashForm"
    );


    if (
        method ===
        "UPI"
    ) {

        showElement(
            "upiForm"
        );

    } else if (
        method ===
        "Card"
    ) {

        showElement(
            "cardForm"
        );

    } else {

        showElement(
            "cashForm"
        );

    }

}


/* =========================================================
   CLOSE PAYMENT
========================================================= */

function closePaymentModal() {

    const modal =
        $("paymentModal");


    if (modal) {

        modal.style.display =
            "none";

    }

}


/* =========================================================
   PROCESS PAYMENT
========================================================= */

function processPayment() {

    if (
        selectedPayment ===
        "UPI"
    ) {

        const upi =
            $("upiId")
                ? $("upiId")
                    .value
                    .trim()
                : "";


        if (!upi) {

            showToast(
                "Please enter your UPI ID"
            );

            return;

        }


        if (
            !/^[\w.-]+@[\w.-]+$/.test(
                upi
            )
        ) {

            showToast(
                "Enter a valid UPI ID"
            );

            return;

        }

    }


    if (
        selectedPayment ===
        "Card"
    ) {

        const card =
            $("cardNumber")
                ? $("cardNumber")
                    .value
                    .replace(
                        /\s/g,
                        ""
                    )
                : "";


        const expiry =
            $("cardExpiry")
                ? $("cardExpiry")
                    .value
                    .trim()
                : "";


        const cvv =
            $("cardCvv")
                ? $("cardCvv")
                    .value
                    .trim()
                : "";


        if (
            !/^\d{16}$/.test(card)
        ) {

            showToast(
                "Enter a valid 16-digit card number"
            );

            return;

        }


        if (
            !/^(0[1-9]|1[0-2])\/\d{2}$/.test(
                expiry
            )
        ) {

            showToast(
                "Enter expiry as MM/YY"
            );

            return;

        }


        if (
            !/^\d{3}$/.test(cvv)
        ) {

            showToast(
                "Enter a valid CVV"
            );

            return;

        }

    }


    closePaymentModal();

    createBooking(
        "Paid"
    );

}


/* =========================================================
   CASH PAYMENT
========================================================= */

function processCashPayment() {

    selectedPayment =
        "Cash";


    closePaymentModal();

    createBooking(
        "Cash"
    );

}


/* =========================================================
   DRIVER SYSTEM
========================================================= */

/*
   Initialize drivers only once.

   Existing Firebase driver statuses are NOT overwritten.
*/

function initializeDriversInFirebase() {

    if (!firebaseDatabase) {
        return;
    }


    const driversRef =
        firebaseDatabase.ref(
            "drivers"
        );


    driversRef
        .once("value")
        .then(
            function (snapshot) {

                if (
                    snapshot.exists()
                ) {

                    console.log(
                        "Driver data already exists"
                    );

                    return null;

                }


                const driverData =
                    {};


                defaultDrivers.forEach(
                    function (driver) {

                        driverData[
                            driver.id
                        ] =
                            driver;

                    }
                );


                return driversRef.set(
                    driverData
                );

            }
        )
        .then(
            function () {

                console.log(
                    "Driver system ready"
                );

            }
        )
        .catch(
            function (error) {

                console.error(
                    "Driver initialization error:",
                    error
                );

            }
        );

}


/* =========================================================
   GET DRIVERS FROM FIREBASE
========================================================= */

function getDriversFromFirebase() {

    if (!firebaseDatabase) {

        return Promise.resolve(
            []
        );

    }


    return firebaseDatabase
        .ref("drivers")
        .once("value")
        .then(
            function (snapshot) {

                const data =
                    snapshot.val();


                if (!data) {

                    return [];

                }


                return Object.values(
                    data
                );

            }
        )
        .catch(
            function (error) {

                console.error(
                    "Driver fetch error:",
                    error
                );


                return [];

            }
        );

}


/* =========================================================
   FIND AVAILABLE DRIVER
========================================================= */

function findAvailableDriver(
    vehicleName
) {

    return getDriversFromFirebase()
        .then(
            function (drivers) {

                /*
                   IMPORTANT:

                   Only a driver with:
                   1. Matching vehicle type
                   2. Available status

                   can be assigned.

                   No fallback to another busy driver.
                */

                const driver =
                    drivers.find(
                        function (item) {

                            return (

                                item.vehicleType ===
                                vehicleName

                                &&

                                item.status ===
                                "Available"

                            );

                        }
                    );


                return driver ||
                    null;

            }
        );

}


/* =========================================================
   UPDATE DRIVER STATUS
========================================================= */

function updateDriverStatus(
    driverId,
    status
) {

    if (
        !firebaseDatabase ||
        !driverId
    ) {

        return Promise.resolve();

    }


    return firebaseDatabase
        .ref(
            "drivers/" +
            driverId
        )
        .update({

            status:
                status,

            updatedAt:
                new Date().toISOString()

        })
        .then(
            function () {

                console.log(
                    "Driver status updated:",
                    driverId,
                    status
                );

            }
        )
        .catch(
            function (error) {

                console.error(
                    "Driver status update error:",
                    error
                );

            }
        );

}


/* =========================================================
   ASSIGN AVAILABLE DRIVER
========================================================= */

function assignDriverAutomatically(
    vehicleName
) {

    return findAvailableDriver(
        vehicleName
    )
    .then(
        function (driver) {

            /*
               No driver available.
            */

            if (!driver) {

                return null;

            }


            /*
               Driver becomes On Trip.
            */

            return updateDriverStatus(
                driver.id,
                "On Trip"
            )
            .then(
                function () {

                    return {

                        id:
                            driver.id,

                        name:
                            driver.name,

                        vehicle:
                            driver.vehicle,

                        vehicleType:
                            driver.vehicleType,

                        status:
                            "Assigned",

                        assignedAt:
                            new Date()
                                .toISOString()

                    };

                }
            );

        }
    );

}


/* =========================================================
   CREATE BOOKING
========================================================= */

async function createBooking(
    paymentStatus
) {

    const pickup =
        getLocationValue(
            "pickup"
        );


    const drop =
        getLocationValue(
            "drop"
        );


    if (
        !pickup ||
        !drop
    ) {

        showToast(
            "Please select pickup and drop"
        );

        return;

    }


    const fare =
        getCurrentFare();


    showToast(
        "Checking driver availability..."
    );


    let assignedDriver =
        null;


    try {

        assignedDriver =
            await assignDriverAutomatically(
                selectedVehicle.name
            );

    } catch (error) {

        console.error(
            "Driver assignment error:",
            error
        );

        assignedDriver =
            null;

    }


    /*
       IMPORTANT:

       Driver available:
       Driver Assigned

       No driver:
       Waiting for Driver
    */

    const bookingStatus =
        assignedDriver

            ? "Driver Assigned"

            : "Waiting for Driver";


    const booking = {

        id:
            generateBookingId(),

        userId:
            getCurrentUser()?.id ||
            "GUEST",

        userName:
            getCurrentUser()?.name ||
            "Guest User",

        pickup:
            pickup,

        drop:
            drop,

        goods:
            selectedGoods ||
            "Other",

        goodsDescription:

            $("goodsDescription")

                ? $("goodsDescription")
                    .value
                    .trim()

                : "",

        vehicle:
            selectedVehicle.name,

        baseFare:
            Number(
                selectedVehicle.price
            ),

        distanceKm:
            Number(
                routeDistanceKm
            ) || 0,

        distanceFare:
            Math.round(
                (
                    Number(
                        routeDistanceKm
                    ) || 0
                ) * 40
            ),

        platformFee:
            20,

        discount:
            isFirstBooking()
                ? 100
                : 0,

        total:
            fare,

        paymentMethod:
            selectedPayment,

        paymentStatus:
            paymentStatus,

        schedule:
            getScheduleDisplay(),

        status:
            bookingStatus,

        createdAt:
            new Date().toISOString(),

        driver:
            assignedDriver ||
            null

    };


    currentBooking =
        booking;


    /*
       Save locally.
    */

    const bookings =
        getBookings();


    bookings.unshift(
        booking
    );


    saveBookings(
        bookings
    );


    /*
       Save Firebase.
    */

    saveBookingToFirebase(
        booking
    );


    /*
       Update UI.
    */

    updateSuccessModal(
        booking
    );


    updateTrackingData(
        booking
    );


    updateHistory();


    showSuccessModal();


    if (assignedDriver) {

        showToast(
            "Booking confirmed • " +
            assignedDriver.name +
            " assigned"
        );

    } else {

        showToast(
            "Booking confirmed • Waiting for Driver"
        );

    }

}


/* =========================================================
   SAVE BOOKING TO FIREBASE
========================================================= */

function saveBookingToFirebase(
    booking
) {

    if (
        !firebaseDatabase ||
        !booking
    ) {

        console.warn(
            "Firebase booking save skipped"
        );

        return;

    }


    firebaseDatabase
        .ref(
            "bookings/" +
            booking.id
        )
        .set(
            booking
        )
        .then(
            function () {

                console.log(
                    "Booking saved to Firebase:",
                    booking.id
                );

            }
        )
        .catch(
            function (error) {

                console.error(
                    "Firebase booking save error:",
                    error
                );

            }
        );

}


/* =========================================================
   UPDATE BOOKING IN FIREBASE
========================================================= */

function updateBookingInFirebase(
    booking
) {

    if (
        !firebaseDatabase ||
        !booking
    ) {

        return;

    }


    firebaseDatabase
        .ref(
            "bookings/" +
            booking.id
        )
        .update(
            booking
        )
        .then(
            function () {

                console.log(
                    "Firebase booking updated:",
                    booking.id
                );

            }
        )
        .catch(
            function (error) {

                console.error(
                    "Firebase booking update error:",
                    error
                );

            }
        );

}


/* =========================================================
   ASSIGN WAITING BOOKING
========================================================= */

function assignWaitingBooking(
    driver
) {

    if (
        !firebaseDatabase ||
        !driver ||
        driver.status !==
        "Available"
    ) {

        return Promise.resolve();

    }


    return firebaseDatabase
        .ref("bookings")
        .once("value")
        .then(
            function (snapshot) {

                const data =
                    snapshot.val();


                if (!data) {
                    return null;
                }


                /*
                   Find oldest waiting booking
                   matching this driver's vehicle.
                */

                const waitingBookings =
                    Object.values(data)

                        .filter(
                            function (booking) {

                                return (

                                    booking.status ===
                                    "Waiting for Driver"

                                    &&

                                    booking.vehicle ===
                                    driver.vehicleType

                                );

                            }
                        )

                        .sort(
                            function (a, b) {

                                return (

                                    new Date(
                                        a.createdAt ||
                                        0
                                    )

                                    -

                                    new Date(
                                        b.createdAt ||
                                        0
                                    )

                                );

                            }
                        );


                if (
                    !waitingBookings.length
                ) {

                    return null;

                }


                const booking =
                    waitingBookings[0];


                const assignedDriver = {

                    id:
                        driver.id,

                    name:
                        driver.name,

                    vehicle:
                        driver.vehicle,

                    vehicleType:
                        driver.vehicleType,

                    status:
                        "Assigned",

                    assignedAt:
                        new Date()
                            .toISOString()

                };


                const updatedBooking = {

                    ...booking,

                    status:
                        "Driver Assigned",

                    driver:
                        assignedDriver,

                    driverAssignedAt:
                        new Date()
                            .toISOString()

                };


                /*
                   Update booking first.
                */

                return firebaseDatabase
                    .ref(
                        "bookings/" +
                        booking.id
                    )
                    .set(
                        updatedBooking
                    )
                    .then(
                        function () {

                            return updateDriverStatus(
                                driver.id,
                                "On Trip"
                            );

                        }
                    )
                    .then(
                        function () {

                            /*
                               Update local booking.
                            */

                            const localBookings =
                                getBookings();


                            const index =
                                localBookings
                                    .findIndex(
                                        function (item) {

                                            return (
                                                item.id ===
                                                booking.id
                                            );

                                        }
                                    );


                            if (
                                index !==
                                -1
                            ) {

                                localBookings[
                                    index
                                ] =
                                    updatedBooking;


                                saveBookings(
                                    localBookings
                                );

                            }


                            /*
                               Update current booking
                               if it belongs to this user.
                            */

                            const user =
                                getCurrentUser();


                            if (
                                user &&
                                booking.userId ===
                                user.id
                            ) {

                                if (
                                    currentBooking &&
                                    currentBooking.id ===
                                    booking.id
                                ) {

                                    currentBooking =
                                        updatedBooking;

                                    updateTrackingData(
                                        currentBooking
                                    );

                                }

                            }


                            /*
                               Notification only for
                               current user's waiting booking.
                            */

                            if (
                                user &&
                                booking.userId ===
                                user.id &&
                                !notifiedDriverBookings
                                    .has(
                                        booking.id
                                    )
                            ) {

                                notifiedDriverBookings
                                    .add(
                                        booking.id
                                    );


                                showDriverAvailableNotification(
                                    updatedBooking,
                                    driver
                                );

                            }


                            updateHistory();


                            console.log(
                                "Waiting booking assigned:",
                                booking.id,
                                driver.name
                            );


                            return updatedBooking;

                        }
                    );

            }
        )
        .catch(
            function (error) {

                console.error(
                    "Waiting booking assignment error:",
                    error
                );

            }
        );

}


/* =========================================================
   DRIVER AVAILABLE NOTIFICATION
========================================================= */

function showDriverAvailableNotification(
    booking,
    driver
) {

    if (
        !booking ||
        !driver
    ) {

        return;

    }


    const message =
        "🔔 Driver Available — " +
        driver.name +
        " is now available. Your booking has been assigned.";


    showToast(
        message
    );


    const panel =
        $("notificationPanel");


    if (!panel) {
        return;
    }


    const content =
        panel.querySelector(
            ".notification-content"
        );


    if (!content) {
        return;
    }


    const notification =
        document.createElement(
            "div"
        );


    notification.className =
        "notification-item";


    notification.innerHTML = `

        <div class="notification-icon">
            🔔
        </div>

        <div>

            <strong>
                Driver Available
            </strong>

            <p>
                ${escapeHtml(
                    driver.name
                )}
                is now available.
                Your booking has been assigned.
            </p>

        </div>

    `;


    content.prepend(
        notification
    );

}


/* =========================================================
   LISTEN FOR DRIVER AVAILABILITY
========================================================= */

function listenForDriverAvailability() {

    if (!firebaseDatabase) {
        return;
    }


    firebaseDatabase
        .ref("drivers")
        .on(
            "value",
            function (snapshot) {

                const data =
                    snapshot.val();


                if (!data) {
                    return;
                }


                const drivers =
                    Object.values(
                        data
                    );


                /*
                   Whenever a driver is Available,
                   check waiting bookings.
                */

                drivers.forEach(
                    function (driver) {

                        if (
                            driver.status ===
                            "Available"
                        ) {

                            assignWaitingBooking(
                                driver
                            );

                        }

                    }
                );

            }
        );

}


/* =========================================================
   SUCCESS MODAL
========================================================= */

function updateSuccessModal(
    booking
) {

    if (!booking) {
        return;
    }


    setText(
        "successBookingId",
        booking.id
    );


    setText(
        "successVehicle",
        booking.vehicle
    );


    setText(
        "successPickup",
        booking.pickup
    );


    setText(
        "successDrop",
        booking.drop
    );


    setText(
        "successSchedule",
        booking.schedule
    );


    setText(
        "successTotal",

        formatCurrency(
            booking.total
        )

    );


    const details =
        $("successBookingDetails");


    if (details) {

        let driverText =
            "Waiting for Driver";


        if (
            booking.driver &&
            booking.driver.name
        ) {

            driverText =
                booking.driver.name;

        }


        details.innerHTML = `

            <p>

                <strong>
                    Payment:
                </strong>

                ${escapeHtml(
                    booking.paymentMethod
                )}

            </p>

            <p>

                <strong>
                    Goods:
                </strong>

                ${escapeHtml(
                    booking.goods
                )}

            </p>

            <p>

                <strong>
                    Driver:
                </strong>

                ${escapeHtml(
                    driverText
                )}

            </p>

        `;

    }

}


/* =========================================================
   SUCCESS MODAL
========================================================= */

function showSuccessModal() {

    const modal =
        $("successModal");


    if (modal) {

        modal.style.display =
            "flex";

    }

}


function closeSuccess() {

    const modal =
        $("successModal");


    if (modal) {

        modal.style.display =
            "none";

    }

}


function closeSuccessAndTrack() {

    closeSuccess();


    navigate(
        "tracking"
    );

}


/* =========================================================
   TRACKING DATA
========================================================= */

function updateTrackingData(
    booking
) {

    if (!booking) {
        return;
    }


    setText(
        "trackingBookingId",
        booking.id
    );


    setText(
        "trackingPickup",
        booking.pickup
    );


    setText(
        "trackingDrop",
        booking.drop
    );


    setText(
        "trackingVehicle",
        booking.vehicle
    );


    setText(
        "trackingSchedule",
        booking.schedule
    );


    setText(
        "trackingFare",

        formatCurrency(
            booking.total
        )

    );


    /*
       WAITING FOR DRIVER
    */

    if (
        booking.status ===
        "Waiting for Driver"
    ) {

        setText(
            "driverName",
            "Waiting for Driver"
        );


        setText(
            "driverVehicle",
            "—"
        );


        setText(
            "trackingStatus",
            "Waiting for Driver"
        );


        setText(
            "driverStatus",
            "Searching for an available driver"
        );


        setText(
            "trackingEta",
            "—"
        );

    }


    /*
       DRIVER ASSIGNED
    */

    else if (
        booking.driver
    ) {

        setText(
            "driverName",

            booking.driver.name ||
            "Driver Assigned"
        );


        setText(
            "driverVehicle",

            booking.driver.vehicle ||
            "Vehicle Assigned"
        );


        setText(
            "trackingStatus",

            booking.status ===
            "Cancelled"

                ? "Booking Cancelled"

                : booking.status ===
                  "Completed"

                    ? "Booking Completed"

                    : "Driver Assigned"

        );


        setText(
            "driverStatus",

            booking.status ===
            "Cancelled"

                ? "Booking cancelled"

                : booking.status ===
                  "Completed"

                    ? "Trip completed"

                    : "Driver is on the way"

        );


        setText(
            "trackingEta",

            booking.status ===
            "Cancelled" ||

            booking.status ===
            "Completed"

                ? "—"

                : "Arriving in 8 mins"

        );

    }


    /*
       NO DRIVER
    */

    else {

        setText(
            "driverName",
            "Driver Assigned"
        );


        setText(
            "driverVehicle",
            "Vehicle Assigned"
        );


        setText(
            "trackingStatus",
            "Driver Assigned"
        );


        setText(
            "driverStatus",
            "Driver is on the way"
        );


        setText(
            "trackingEta",
            "Arriving in 8 mins"
        );

    }


    const cancelButton =
        $("cancelBookingButton");


    if (cancelButton) {

        cancelButton.style.display =

            booking.status ===
            "Cancelled" ||

            booking.status ===
            "Completed"

                ? "none"

                : "block";

    }

}


/* =========================================================
   TRACKING PAGE
========================================================= */

function updateTrackingPage() {

    if (!currentBooking) {

        setText(
            "trackingBookingId",
            "No active booking available"
        );


        setText(
            "trackingPickup",
            "—"
        );


        setText(
            "trackingDrop",
            "—"
        );


        setText(
            "trackingVehicle",
            "—"
        );


        setText(
            "trackingSchedule",
            "—"
        );


        setText(
            "trackingFare",
            "—"
        );


        setText(
            "driverName",
            "No driver assigned"
        );


        setText(
            "driverVehicle",
            "—"
        );


        setText(
            "trackingStatus",
            "No active booking"
        );


        setText(
            "driverStatus",
            "Book a tempo to start tracking"
        );


        setText(
            "trackingEta",
            "—"
        );


        const cancelButton =
            $("cancelBookingButton");


        if (cancelButton) {

            cancelButton.style.display =
                "none";

        }


        return;

    }


    if (
        currentBooking.status ===
        "Cancelled" ||

        currentBooking.status ===
        "Completed"
    ) {

        setText(
            "trackingBookingId",
            "No active booking available"
        );


        setText(
            "trackingPickup",
            "—"
        );


        setText(
            "trackingDrop",
            "—"
        );


        setText(
            "trackingVehicle",
            "—"
        );


        setText(
            "trackingSchedule",
            "—"
        );


        setText(
            "trackingFare",
            "—"
        );


        setText(
            "driverName",
            "No active driver"
        );


        setText(
            "driverVehicle",
            "—"
        );


        setText(
            "trackingStatus",
            "No active booking"
        );


        setText(
            "driverStatus",
            "Book a tempo to start tracking"
        );


        setText(
            "trackingEta",
            "—"
        );


        const cancelButton =
            $("cancelBookingButton");


        if (cancelButton) {

            cancelButton.style.display =
                "none";

        }


        return;

    }


    updateTrackingData(
        currentBooking
    );

}


/* =========================================================
   CALL DRIVER
========================================================= */

function callDriver() {

    if (
        currentBooking &&
        currentBooking.driver
    ) {

        showToast(
            "Calling " +
            currentBooking.driver.name +
            "..."
        );

    } else {

        showToast(
            "No driver assigned yet"
        );

    }

}


/* =========================================================
   MESSAGE DRIVER
========================================================= */

function messageDriver() {

    if (
        currentBooking &&
        currentBooking.driver
    ) {

        showToast(
            "Opening driver chat..."
        );

    } else {

        showToast(
            "Driver is not assigned yet"
        );

    }

}


/* =========================================================
   CANCEL BOOKING
========================================================= */

function cancelBooking() {

    if (!currentBooking) {

        showToast(
            "No active booking found"
        );

        return;

    }


    if (
        currentBooking.status ===
        "Cancelled"
    ) {

        showToast(
            "This booking is already cancelled"
        );

        return;

    }


    if (
        currentBooking.status ===
        "Completed"
    ) {

        showToast(
            "This booking is already completed"
        );

        return;

    }


    /*
       OPEN CANCELLATION
       CONFIRMATION MODAL
    */

    const modal =
        $("cancelModal");


    if (modal) {

        modal.style.display =
            "flex";

    }

}
/* =========================================================
   CLOSE CANCEL MODAL
========================================================= */

function closeCancelModal() {

    const modal =
        $("cancelModal");


    if (modal) {

        modal.style.display =
            "none";

    }

}

/* =========================================================
   CONFIRM CANCELLATION
========================================================= */

async function confirmCancellation() {

    if (!currentBooking) {

        closeCancelModal();

        showToast(
            "No active booking found"
        );

        return;

    }

    const bookings =
        getBookings();


    const index =
        bookings.findIndex(
            function (booking) {

                return (
                    booking.id ===
                    currentBooking.id
                );

            }
        );


    if (index === -1) {

        closeCancelModal();

        showToast(
            "Booking not found"
        );

        return;

    }


    /*
       GET ASSIGNED DRIVER
    */

    const driver =
        bookings[index].driver;


    /*
       UPDATE BOOKING STATUS
    */

    bookings[index].status =
        "Cancelled";


    bookings[index].cancelledAt =
        new Date().toISOString();


    /*
       REMOVE OLD CANCELLATION CHARGE DATA
    */

    bookings[index].cancellationCharge =
        0;


    /*
       FULL REFUND FOR PAID BOOKING
    */

    if (
        bookings[index].paymentStatus ===
        "Paid"
    ) {

        bookings[index].refundAmount =
            Number(
                bookings[index].total
            ) || 0;

    } else {

        bookings[index].refundAmount =
            0;

    }


    /*
       MAKE DRIVER AVAILABLE AGAIN
    */

    if (driver) {

        bookings[index].driver.status =
            "Available";

    }


    /*
       UPDATE CURRENT BOOKING
    */

    currentBooking =
        bookings[index];


    /*
       SAVE LOCALLY
    */

    saveBookings(
        bookings
    );


    /*
       UPDATE FIREBASE BOOKING
    */

    updateBookingInFirebase(
        currentBooking
    );


    /*
       FREE DRIVER IN FIREBASE
    */

    if (
        driver &&
        driver.id
    ) {

        await updateDriverStatus(
            driver.id,
            "Available"
        );


        /*
           ASSIGN DRIVER TO
           WAITING BOOKING
        */

        await assignWaitingBooking({

            id:
                driver.id,

            name:
                driver.name,

            vehicle:
                driver.vehicle,

            vehicleType:
                driver.vehicleType,

            status:
                "Available"

        });

    }


    /*
       CLOSE MODAL
    */

    closeCancelModal();


    /*
       UPDATE TRACKING
    */

    updateTrackingData(
        currentBooking
    );


    /*
       UPDATE HISTORY
    */

    updateHistory();


    /*
       SUCCESS MESSAGE
    */

    if (
        bookings[index].paymentStatus ===
        "Paid"
    ) {

        showToast(
            "Booking cancelled successfully • Full refund initiated"
        );

    } else {

        showToast(
            "Booking cancelled successfully"
        );

    }

}/* =========================================================
   HISTORY
========================================================= */

function updateHistory(
    filter = "all"
) {

    const container =
        $("bookingHistoryList");


    if (!container) {
        return;
    }


    const user =
        getCurrentUser();


    let bookings =
        getBookings();


    if (
        user &&
        user.id
    ) {

        bookings =
            bookings.filter(
                function (booking) {

                    return (
                        booking.userId ===
                        user.id
                    );

                }
            );

    }


    if (
        filter ===
        "completed"
    ) {

        bookings =
            bookings.filter(
                function (booking) {

                    return (
                        booking.status ===
                        "Completed"
                    );

                }
            );

    }


    if (
        filter ===
        "cancelled"
    ) {

        bookings =
            bookings.filter(
                function (booking) {

                    return (
                        booking.status ===
                        "Cancelled"
                    );

                }
            );

    }


    if (
        bookings.length ===
        0
    ) {

        container.innerHTML = `

            <div class="empty-history">

                <div class="empty-history-icon">
                    📦
                </div>

                <h3>
                    No bookings yet
                </h3>

                <p>
                    Your bookings will appear here.
                </p>

                <button
                    class="primary-btn"
                    onclick="navigate('home')"
                >
                    Book a Tempo
                </button>

            </div>

        `;

        return;

    }


    container.innerHTML =
        bookings
            .map(
                createHistoryCard
            )
            .join("");

}


/* =========================================================
   HISTORY CARD
========================================================= */

function createHistoryCard(
    booking
) {

    let statusClass =
        "confirmed";


    if (
        booking.status ===
        "Cancelled"
    ) {

        statusClass =
            "cancelled";

    } else if (
        booking.status ===
        "Completed"
    ) {

        statusClass =
            "completed";

    } else if (
        booking.status ===
        "Waiting for Driver"
    ) {

        statusClass =
            "confirmed";

    }


    return `

        <div class="history-card">

            <div class="history-card-header">

                <div>

                    <strong>
                        ${escapeHtml(
                            booking.vehicle
                        )}
                    </strong>

                    <small>
                        ${escapeHtml(
                            booking.id
                        )}
                    </small>

                </div>

                <span
                    class="history-status ${statusClass}"
                >

                    ${escapeHtml(
                        booking.status
                    )}

                </span>

            </div>


            <div class="history-route">

                <div>

                    <span>●</span>

                    ${escapeHtml(
                        booking.pickup
                    )}

                </div>


                <div>

                    <span>●</span>

                    ${escapeHtml(
                        booking.drop
                    )}

                </div>

            </div>


            <div class="history-card-footer">

                <span>

                    ${escapeHtml(
                        booking.schedule
                    )}

                </span>


                <strong>

                    ${formatCurrency(
                        booking.total
                    )}

                </strong>

            </div>

        </div>

    `;

}


/* =========================================================
   BOOKING HISTORY TAB
========================================================= */

function bookingTab(
    button,
    filter
) {

    document
        .querySelectorAll(
            ".history-tab"
        )
        .forEach(
            function (tab) {

                tab.classList.remove(
                    "active"
                );

            }
        );


    if (button) {

        button.classList.add(
            "active"
        );

    }


    updateHistory(
        filter
    );

}


/* =========================================================
   COUPON
========================================================= */

function copyCoupon() {

    const coupon =
        "QT100";


    if (
        navigator.clipboard &&
        navigator.clipboard.writeText
    ) {

        navigator.clipboard
            .writeText(
                coupon
            )
            .then(
                function () {

                    showToast(
                        "Coupon QT100 copied"
                    );

                }
            )
            .catch(
                function () {

                    showToast(
                        "Coupon: QT100"
                    );

                }
            );

    } else {

        showToast(
            "Coupon: QT100"
        );

    }

}


/* =========================================================
   NOTIFICATIONS
========================================================= */

function openNotifications() {

    const panel =
        $("notificationPanel");


    if (panel) {

        panel.style.display =
            "flex";

    }

}


function closeNotifications() {

    const panel =
        $("notificationPanel");


    if (panel) {

        panel.style.display =
            "none";

    }

}


/* =========================================================
   SUPPORT
========================================================= */

function openSupport() {

    const modal =
        $("supportModal");


    if (modal) {

        modal.style.display =
            "flex";

    }

}


function closeSupport() {

    const modal =
        $("supportModal");


    if (modal) {

        modal.style.display =
            "none";

    }

}


/* =========================================================
   TOAST
========================================================= */

let toastTimer =
    null;


function showToast(
    message
) {

    const toast =
        $("toast");


    const toastMessage =
        $("toastMessage");


    if (
        !toast ||
        !toastMessage
    ) {

        return;

    }


    toastMessage.textContent =
        message;


    toast.style.display =
        "flex";


    clearTimeout(
        toastTimer
    );


    toastTimer =
        setTimeout(
            function () {

                toast.style.display =
                    "none";

            },
            3000
        );

}


/* =========================================================
   CLOSE ALL MODALS
========================================================= */

function closeAllModals() {

    [

        "locationModal",

        "scheduleModal",

        "paymentModal",

        "successModal",

        "cancelModal",

        "supportModal",

        "notificationPanel"

    ].forEach(
        function (id) {

            const element =
                $(id);


            if (element) {

                element.style.display =
                    "none";

            }

        }
    );

}


/* =========================================================
   INPUT FORMATTING
========================================================= */

function initializeInputFormatting() {

    const phoneInputs =
        document.querySelectorAll(
            'input[type="tel"]'
        );


    phoneInputs.forEach(
        function (input) {

            input.addEventListener(
                "input",
                function () {

                    const value =
                        this.value
                            .trim()
                            .toLowerCase();


                    /*
                       Allow Admin email
                       if entered in the
                       login field.
                    */

                    if (
                        value.includes("@")
                    ) {

                        return;

                    }


                    this.value =
                        this.value
                            .replace(
                                /\D/g,
                                ""
                            )
                            .slice(
                                0,
                                10
                            );

                }
            );

        }
    );


    const cardNumber =
        $("cardNumber");


    if (cardNumber) {

        cardNumber.addEventListener(
            "input",
            function () {

                let value =
                    this.value
                        .replace(
                            /\D/g,
                            ""
                        )
                        .slice(
                            0,
                            16
                        );


                value =
                    value.replace(
                        /(.{4})/g,
                        "$1 "
                    )
                    .trim();


                this.value =
                    value;

            }
        );

    }


    const expiry =
        $("cardExpiry");


    if (expiry) {

        expiry.addEventListener(
            "input",
            function () {

                let value =
                    this.value
                        .replace(
                            /\D/g,
                            ""
                        )
                        .slice(
                            0,
                            4
                        );


                if (
                    value.length >
                    2
                ) {

                    value =
                        value.slice(
                            0,
                            2
                        ) +
                        "/" +
                        value.slice(
                            2
                        );

                }


                this.value =
                    value;

            }
        );

    }


    const cvv =
        $("cardCvv");


    if (cvv) {

        cvv.addEventListener(
            "input",
            function () {

                this.value =
                    this.value
                        .replace(
                            /\D/g,
                            ""
                        )
                        .slice(
                            0,
                            3
                        );

            }
        );

    }

}


/* =========================================================
   DATE / TIME HELPERS
========================================================= */

function formatDateInput(
    date
) {

    const year =
        date.getFullYear();


    const month =
        String(
            date.getMonth() +
            1
        ).padStart(
            2,
            "0"
        );


    const day =
        String(
            date.getDate()
        ).padStart(
            2,
            "0"
        );


    return `${year}-${month}-${day}`;

}


function formatTimeInput(
    date
) {

    const hours =
        String(
            date.getHours()
        ).padStart(
            2,
            "0"
        );


    const minutes =
        String(
            date.getMinutes()
        ).padStart(
            2,
            "0"
        );


    return `${hours}:${minutes}`;

}


/* =========================================================
   ID GENERATOR
========================================================= */

function generateBookingId() {

    const random =
        Math.floor(
            1000 +
            Math.random() *
            9000
        );


    return (
        "QT" +
        Date.now()
            .toString()
            .slice(-6) +
        random
    );

}


/* =========================================================
   CURRENCY
========================================================= */

function formatCurrency(
    amount
) {

    return (
        "₹" +
        Number(
            amount || 0
        ).toLocaleString(
            "en-IN"
        )
    );

}


/* =========================================================
   HTML ESCAPE
========================================================= */

function escapeHtml(
    value
) {

    return String(
        value ?? ""
    )

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


/* =========================================================
   GLOBAL MODAL CLICK HANDLING
========================================================= */

document.addEventListener(
    "click",
    function (event) {

        const target =
            event.target;


        const notificationPanel =
            $("notificationPanel");


        if (
            notificationPanel &&
            notificationPanel.style.display !==
                "none" &&
            target ===
                notificationPanel
        ) {

            closeNotifications();

        }

    }
);


/* =========================================================
   ESC KEY
========================================================= */

document.addEventListener(
    "keydown",
    function (event) {

        if (
            event.key !==
            "Escape"
        ) {

            return;

        }


        closeLocationModal();

        closeScheduleModal();

        closePaymentModal();

        closeSuccess();

        closeCancelModal();

        closeSupport();

        closeNotifications();

    }
);


/* =========================================================
   EXPORT GLOBAL FUNCTIONS
   Required by index.html inline onclick
========================================================= */

window.toggleAuth =
    toggleAuth;

window.handleAuth =
    handleAuth;

window.guestLogin =
    guestLogin;

window.logout =
    logout;


window.navigate =
    navigate;


window.startBooking =
    startBooking;

window.quickBooking =
    quickBooking;


window.openLocationPicker =
    openLocationPicker;

window.closeLocationModal =
    closeLocationModal;

window.clearLocationSearch =
    clearLocationSearch;

window.searchLocations =
    searchLocations;

window.detectCurrentLocation =
    detectCurrentLocation;

window.useCurrentLocation =
    useCurrentLocation;

window.swapLocations =
    swapLocations;


window.selectGoods =
    selectGoods;

window.selectVehicle =
    selectVehicle;


window.selectSchedule =
    selectSchedule;

window.openScheduleModal =
    openScheduleModal;

window.closeScheduleModal =
    closeScheduleModal;

window.confirmSchedule =
    confirmSchedule;


window.nextBookingStep =
    nextBookingStep;

window.showBookingStep =
    showBookingStep;


window.selectPayment =
    selectPayment;

window.openPayment =
    openPayment;

window.closePaymentModal =
    closePaymentModal;

window.processPayment =
    processPayment;

window.processCashPayment =
    processCashPayment;


window.closeSuccess =
    closeSuccess;

window.closeSuccessAndTrack =
    closeSuccessAndTrack;


window.cancelBooking =
    cancelBooking;

window.closeCancelModal =
    closeCancelModal;

window.confirmCancellation =
    confirmCancellation;


window.bookingTab =
    bookingTab;


window.callDriver =
    callDriver;

window.messageDriver =
    messageDriver;


window.copyCoupon =
    copyCoupon;


window.openNotifications =
    openNotifications;

window.closeNotifications =
    closeNotifications;


window.openSupport =
    openSupport;

window.closeSupport =
    closeSupport;


window.showToast =
    showToast;


window.initGoogleMaps =
    initGoogleMaps;


/* =========================================================
   END OF SCRIPT
========================================================= */