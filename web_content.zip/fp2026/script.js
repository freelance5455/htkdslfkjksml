/* =========================================================
   QUIKTEMPO - MAIN JAVASCRIPT
   Matches the current index.html
========================================================= */


/* =========================================================
   GLOBAL STATE
========================================================= */

let isSignupMode = false;

let currentPage = "home";

let locationMode = "pickup";

let selectedGoods = "";

let selectedVehicle = {
    name: "Mini Tempo",
    price: 300
};

let selectedSchedule = "Now";

let selectedPayment = "UPI";

let currentBooking = null;

let currentLocationData = {
    lat: null,
    lng: null,
    address: ""
};

let routeMap = null;
let trackingMap = null;

let routeDirectionsService = null;
let routeDirectionsRenderer = null;

let routeDistanceKm = 0;

let locationAutocomplete = null;


/* =========================================================
   STORAGE HELPERS
========================================================= */

function getUsers() {
    try {
        return JSON.parse(localStorage.getItem("quiktempo_users")) || [];
    } catch (error) {
        return [];
    }
}


function saveUsers(users) {
    localStorage.setItem("quiktempo_users", JSON.stringify(users));
}


function getBookings() {
    try {
        return JSON.parse(localStorage.getItem("quiktempo_bookings")) || [];
    } catch (error) {
        return [];
    }
}


function saveBookings(bookings) {
    localStorage.setItem(
        "quiktempo_bookings",
        JSON.stringify(bookings)
    );
}


function getCurrentUser() {
    try {
        return JSON.parse(
            localStorage.getItem("quiktempo_current_user")
        );
    } catch (error) {
        return null;
    }
}


function saveCurrentUser(user) {
    localStorage.setItem(
        "quiktempo_current_user",
        JSON.stringify(user)
    );
}


function removeCurrentUser() {
    localStorage.removeItem("quiktempo_current_user");
}


/* =========================================================
   DOM HELPER
========================================================= */

function $(id) {
    return document.getElementById(id);
}


function setText(id, value) {
    const element = $(id);

    if (element) {
        element.textContent = value;
    }
}


function showElement(id) {
    const element = $(id);

    if (element) {
        element.style.display = "";
    }
}


function hideElement(id) {
    const element = $(id);

    if (element) {
        element.style.display = "none";
    }
}


/* =========================================================
   INITIALIZATION
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    initializeApp();

});


function initializeApp() {

    const splash = $("splashScreen");
    const auth = $("authScreen");
    const app = $("mainApp");

    if (auth) {
        auth.style.display = "none";
    }

    if (app) {
        app.style.display = "none";
    }

    /*
       Show splash first.
    */

    setTimeout(function () {

        if (splash) {
            splash.style.display = "none";
        }

        const user = getCurrentUser();

        if (user) {
            showMainApp();
        } else {
            showAuthScreen();
        }

    }, 1200);


    initializeInputFormatting();

    updateHistory();

}


/* =========================================================
   AUTH SCREEN
========================================================= */

function showAuthScreen() {

    if ($("authScreen")) {
        $("authScreen").style.display = "flex";
    }

    if ($("mainApp")) {
        $("mainApp").style.display = "none";
    }

}


function showMainApp() {

    if ($("authScreen")) {
        $("authScreen").style.display = "none";
    }

    if ($("mainApp")) {
        $("mainApp").style.display = "block";
    }

    updateProfile();

    navigate("home");

    updateHistory();

}


/* =========================================================
   TOGGLE LOGIN / SIGNUP
========================================================= */

function toggleAuth() {

    isSignupMode = !isSignupMode;

    const signupFields = $("signupFields");
    const authTitle = $("authTitle");
    const authSubtitle = $("authSubtitle");
    const authButtonText = $("authButtonText");
    const authSwitchText = $("authSwitchText");
    const authSwitchBtn = $("authSwitchBtn");

    if (isSignupMode) {

        if (signupFields) {
            signupFields.style.display = "block";
        }

        setText(
            "authTitle",
            "Create your QuikTempo account"
        );

        setText(
            "authSubtitle",
            "Sign up to book a tempo"
        );

        setText(
            "authButtonText",
            "Sign Up"
        );

        setText(
            "authSwitchText",
            "Already have an account?"
        );

        setText(
            "authSwitchBtn",
            "Login"
        );

    } else {

        if (signupFields) {
            signupFields.style.display = "none";
        }

        setText(
            "authTitle",
            "Welcome to QuikTempo"
        );

        setText(
            "authSubtitle",
            "Book a tempo for your goods"
        );

        setText(
            "authButtonText",
            "Login"
        );

        setText(
            "authSwitchText",
            "Don't have an account?"
        );

        setText(
            "authSwitchBtn",
            "Sign Up"
        );

    }

}


/* =========================================================
   LOGIN / SIGNUP
========================================================= */

function handleAuth() {

    const phone = $("authPhone")
        ? $("authPhone").value.trim()
        : "";

    const password = $("authPassword")
        ? $("authPassword").value
        : "";

    if (!phone || !password) {

        showToast("Please enter phone number and password");

        return;
    }


    if (!/^\d{10}$/.test(phone)) {

        showToast("Enter a valid 10-digit phone number");

        return;
    }


    const users = getUsers();


    /* ---------------- SIGN UP ---------------- */

    if (isSignupMode) {

        const name = $("signupName")
            ? $("signupName").value.trim()
            : "";

        const signupPhone = $("signupPhone")
            ? $("signupPhone").value.trim()
            : "";


        if (!name) {

            showToast("Please enter your name");

            return;
        }


        if (!/^\d{10}$/.test(signupPhone)) {

            showToast(
                "Enter a valid 10-digit signup phone number"
            );

            return;
        }


        if (signupPhone !== phone) {

            showToast(
                "Signup phone and login phone should match"
            );

            return;
        }


        const alreadyExists = users.some(
            user => user.phone === phone
        );


        if (alreadyExists) {

            showToast("Account already exists. Please login.");

            return;
        }


        const newUser = {
            id: "USR-" + Date.now(),
            name: name,
            phone: phone,
            password: password,
            createdAt: new Date().toISOString()
        };


        users.push(newUser);

        saveUsers(users);

        saveCurrentUser(newUser);

        showToast("Account created successfully");

        setTimeout(function () {
            showMainApp();
        }, 500);

        return;
    }


    /* ---------------- LOGIN ---------------- */

    const user = users.find(
        item =>
            item.phone === phone &&
            item.password === password
    );


    if (!user) {

        showToast(
            "Invalid phone number or password"
        );

        return;
    }


    saveCurrentUser(user);

    showToast("Login successful");

    setTimeout(function () {
        showMainApp();
    }, 400);

}


/* =========================================================
   GUEST LOGIN
========================================================= */

function guestLogin() {

    const guest = {
        id: "GUEST-" + Date.now(),
        name: "Guest User",
        phone: "",
        guest: true
    };

    saveCurrentUser(guest);

    showToast("Continuing as Guest");

    setTimeout(function () {
        showMainApp();
    }, 400);

}


/* =========================================================
   LOGOUT
========================================================= */

function logout() {

    const confirmLogout = confirm(
        "Are you sure you want to logout?"
    );

    if (!confirmLogout) {
        return;
    }

    removeCurrentUser();

    closeAllModals();

    showToast("Logged out successfully");

    setTimeout(function () {

        isSignupMode = false;

        toggleAuth();

        showAuthScreen();

    }, 300);

}


/* =========================================================
   PROFILE
========================================================= */

function updateProfile() {

    const user = getCurrentUser();

    if (!user) {
        return;
    }


    setText(
        "profileName",
        user.name || "Guest User"
    );


    setText(
        "profilePhone",
        user.phone || "Guest account"
    );

}


/* =========================================================
   NAVIGATION
========================================================= */

function navigate(page) {

    const pages = [
        "home",
        "booking",
        "tracking",
        "history",
        "profile"
    ];


    if (!pages.includes(page)) {
        page = "home";
    }


    currentPage = page;


    pages.forEach(function (pageName) {

        const pageElement = $(pageName + "Page");

        if (!pageElement) {
            return;
        }

        if (pageName === page) {

            pageElement.classList.add("active-page");
            pageElement.style.display = "";

        } else {

            pageElement.classList.remove("active-page");
            pageElement.style.display = "none";

        }

    });


    document.querySelectorAll(".nav-item").forEach(
        function (item) {

            item.classList.toggle(
                "active",
                item.dataset.page === page
            );

        }
    );


    if (page === "history") {
        updateHistory();
    }


    if (page === "profile") {
        updateProfile();
    }


    if (page === "tracking") {
        updateTrackingPage();

        setTimeout(function () {
            initializeTrackingMap();
        }, 100);
    }


    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


/* =========================================================
   BOOKING START
========================================================= */

function startBooking() {

    const pickup = getLocationValue("pickup");
    const drop = getLocationValue("drop");


    if (!pickup) {

        showToast("Please select pickup location");

        return;
    }


    if (!drop) {

        showToast("Please select drop location");

        return;
    }


    setText("bookingPickup", pickup);
    setText("bookingDrop", drop);


    navigate("booking");

    showBookingStep(1);

    calculateRoute();

}


function quickBooking(goods) {

    selectedGoods = goods;

    navigate("booking");

    showBookingStep(1);


    document.querySelectorAll(".goods-btn").forEach(
        function (button) {

            button.classList.remove("selected");

            const buttonText =
                button.textContent
                    .trim()
                    .replace(/\s+/g, " ");

            if (buttonText.includes(goods)) {
                button.classList.add("selected");
            }

        }
    );


    const details = $("goodsDetails");

    if (details) {
        details.style.display = "block";
    }

    showToast(goods + " selected");

}


/* =========================================================
   LOCATION VALUES
========================================================= */

function getLocationValue(type) {

    if (type === "pickup") {

        const element = $("pickupInput");

        return element
            ? element.textContent.trim()
            : "";

    }


    if (type === "drop") {

        const element = $("dropInput");

        return element
            ? element.textContent.trim()
            : "";

    }


    return "";
}


/* =========================================================
   SWAP LOCATIONS
========================================================= */

function swapLocations() {

    const pickup = getLocationValue("pickup");
    const drop = getLocationValue("drop");


    if (
        !pickup ||
        pickup === "Select pickup location"
    ) {
        showToast("Select pickup location first");
        return;
    }


    if (
        !drop ||
        drop === "Select drop location"
    ) {
        showToast("Select drop location first");
        return;
    }


    setLocationValue("pickup", drop);
    setLocationValue("drop", pickup);

    showToast("Locations swapped");

    calculateRoute();

}


function setLocationValue(type, value) {

    if (type === "pickup") {

        setText("pickupInput", value);
        setText("bookingPickup", value);

    }


    if (type === "drop") {

        setText("dropInput", value);
        setText("bookingDrop", value);

    }

}


/* =========================================================
   LOCATION PICKER
========================================================= */

function openLocationPicker(type) {

    locationMode = type;

    const title =
        type === "pickup"
            ? "Select Pickup Location"
            : "Select Drop Location";

    setText(
        "locationModalTitle",
        title
    );


    const modal = $("locationModal");

    if (modal) {
        modal.style.display = "flex";
    }


    const input = $("locationSearchInput");

    if (input) {

        input.value = "";

        setTimeout(function () {
            input.focus();
        }, 100);

    }


    renderLocationSuggestions("");

}


function closeLocationModal() {

    const modal = $("locationModal");

    if (modal) {
        modal.style.display = "none";
    }

}


function clearLocationSearch() {

    const input = $("locationSearchInput");

    if (input) {
        input.value = "";
    }

    renderLocationSuggestions("");

}


/* =========================================================
   LOCATION SEARCH
========================================================= */

const commonLocations = [
    "Kharghar, Navi Mumbai",
    "Panvel, Navi Mumbai",
    "Belapur, Navi Mumbai",
    "Vashi, Navi Mumbai",
    "Nerul, Navi Mumbai",
    "Seawoods, Navi Mumbai",
    "CBD Belapur, Navi Mumbai",
    "Sanpada, Navi Mumbai",
    "Airoli, Navi Mumbai",
    "Ghansoli, Navi Mumbai",
    "Thane, Maharashtra",
    "Dadar, Mumbai",
    "Andheri, Mumbai",
    "Bandra, Mumbai",
    "Kurla, Mumbai",
    "Vashi Railway Station",
    "Panvel Railway Station",
    "Kharghar Railway Station",
    "Taloja, Navi Mumbai"
];


function searchLocations(query) {

    query = String(query || "").trim();


    if (!query) {

        renderLocationSuggestions("");

        return;
    }


    /*
       Use Google Places if available.
    */

    if (
        window.google &&
        google.maps &&
        google.maps.places
    ) {

        const service =
            new google.maps.places.AutocompleteService();


        service.getPlacePredictions(
            {
                input: query,
                componentRestrictions: {
                    country: "in"
                }
            },
            function (predictions, status) {

                if (
                    status ===
                    google.maps.places.PlacesServiceStatus.OK &&
                    predictions
                ) {

                    renderGoogleSuggestions(
                        predictions
                    );

                } else {

                    renderLocationSuggestions(query);

                }

            }
        );

        return;
    }


    renderLocationSuggestions(query);

}


function renderLocationSuggestions(query) {

    const container = $("locationSuggestions");

    if (!container) {
        return;
    }


    const lowerQuery =
        String(query || "").toLowerCase();


    const filtered = commonLocations.filter(
        location =>
            location.toLowerCase().includes(lowerQuery)
    );


    let results = filtered.slice(0, 6);


    if (
        query &&
        results.length === 0
    ) {

        results = [
            query
        ];

    }


    container.innerHTML = "";


    if (results.length === 0) {

        container.innerHTML = `
            <div class="location-suggestion">
                No locations found
            </div>
        `;

        return;
    }


    results.forEach(function (location) {

        const item =
            document.createElement("button");

        item.type = "button";

        item.className =
            "location-suggestion";

        item.innerHTML = `
            <span>📍</span>
            <span>${escapeHtml(location)}</span>
        `;


        item.addEventListener(
            "click",
            function () {
                selectLocation(location);
            }
        );


        container.appendChild(item);

    });

}


function renderGoogleSuggestions(predictions) {

    const container = $("locationSuggestions");

    if (!container) {
        return;
    }


    container.innerHTML = "";


    predictions.slice(0, 6).forEach(
        function (prediction) {

            const item =
                document.createElement("button");

            item.type = "button";

            item.className =
                "location-suggestion";

            item.innerHTML = `
                <span>📍</span>
                <span>
                    ${escapeHtml(
                        prediction.description
                    )}
                </span>
            `;


            item.addEventListener(
                "click",
                function () {

                    selectLocation(
                        prediction.description,
                        prediction.place_id
                    );

                }
            );


            container.appendChild(item);

        }
    );

}


function selectLocation(
    address,
    placeId = null
) {

    setLocationValue(
        locationMode,
        address
    );


    closeLocationModal();


    showToast(
        locationMode === "pickup"
            ? "Pickup location selected"
            : "Drop location selected"
    );


    if (placeId && window.google) {

        getPlaceCoordinates(placeId);

    }


    calculateRoute();

}


/* =========================================================
   GET PLACE COORDINATES
========================================================= */

function getPlaceCoordinates(placeId) {

    if (
        !window.google ||
        !google.maps ||
        !google.maps.places
    ) {
        return;
    }


    const tempDiv =
        document.createElement("div");


    const service =
        new google.maps.places.PlacesService(
            tempDiv
        );


    service.getDetails(
        {
            placeId: placeId,
            fields: [
                "geometry",
                "formatted_address"
            ]
        },
        function (place, status) {

            if (
                status ===
                google.maps.places.PlacesServiceStatus.OK &&
                place &&
                place.geometry
            ) {

                const location =
                    place.geometry.location;


                if (locationMode === "pickup") {

                    window.pickupCoords = {
                        lat: location.lat(),
                        lng: location.lng()
                    };

                } else {

                    window.dropCoords = {
                        lat: location.lat(),
                        lng: location.lng()
                    };

                }


                calculateRoute();

            }

        }
    );

}


/* =========================================================
   CURRENT LOCATION
========================================================= */

function detectCurrentLocation(closeModalAfter = false) {

    if (!navigator.geolocation) {

        showToast(
            "Geolocation is not supported by this browser"
        );

        return;
    }


    showToast("Getting your current location...");


    navigator.geolocation.getCurrentPosition(

        function (position) {

            const lat =
                position.coords.latitude;

            const lng =
                position.coords.longitude;


            currentLocationData = {
                lat: lat,
                lng: lng,
                address: "Current Location"
            };


            if (
                window.google &&
                google.maps
            ) {

                const geocoder =
                    new google.maps.Geocoder();


                geocoder.geocode(
                    {
                        location: {
                            lat: lat,
                            lng: lng
                        }
                    },
                    function (results, status) {

                        let address =
                            "Current Location";


                        if (
                            status === "OK" &&
                            results &&
                            results.length
                        ) {

                            address =
                                results[0]
                                    .formatted_address;

                        }


                        currentLocationData.address =
                            address;


                        setLocationValue(
                            locationMode,
                            address
                        );


                        updateHeaderLocation(address);


                        if (closeModalAfter) {
                            closeLocationModal();
                        }


                        showToast(
                            "Current location selected"
                        );


                        calculateRoute();

                    }
                );

            } else {

                const address =
                    "Current Location";


                currentLocationData.address =
                    address;


                setLocationValue(
                    locationMode,
                    address
                );


                updateHeaderLocation(address);


                if (closeModalAfter) {
                    closeLocationModal();
                }


                showToast(
                    "Current location selected"
                );

            }

        },

        function () {

            showToast(
                "Unable to get current location"
            );

        },

        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 60000
        }

    );

}


function useCurrentLocation() {

    locationMode = "pickup";

    detectCurrentLocation(false);

}


/* =========================================================
   HEADER LOCATION
========================================================= */

function updateHeaderLocation(address) {

    if (!address) {
        return;
    }


    let shortAddress = address;


    if (address.includes(",")) {

        shortAddress =
            address.split(",").slice(0, 2).join(",");

    }


    setText(
        "currentLocation",
        shortAddress
    );

}


/* =========================================================
   GOODS
========================================================= */

function selectGoods(button, goods) {

    selectedGoods = goods;


    document.querySelectorAll(
        ".goods-btn"
    ).forEach(function (item) {

        item.classList.remove("selected");

    });


    if (button) {
        button.classList.add("selected");
    }


    const details = $("goodsDetails");

    if (details) {
        details.style.display = "block";
    }


    showToast(goods + " selected");

}


/* =========================================================
   VEHICLE
========================================================= */

function selectVehicle(button) {

    if (!button) {
        return;
    }


    document.querySelectorAll(
        ".vehicle-option"
    ).forEach(function (item) {

        item.classList.remove("selected");

    });


    button.classList.add("selected");


    selectedVehicle = {
        name:
            button.dataset.name ||
            "Mini Tempo",

        price:
            Number(button.dataset.price) || 300
    };


    updateFare();

    showToast(
        selectedVehicle.name + " selected"
    );

}

/* =========================================================
   FARE CALCULATION
========================================================= */

function updateFare() {

    const baseFare =
        Number(selectedVehicle?.price) || 300;

    const distance =
        Number(routeDistanceKm) || 0;

    // ₹40 per KM
    const distanceFare =
        Math.round(distance * 40);

    // Platform fee
    const platformFee = 20;

    // ₹100 discount ONLY for first booking
    const discount =
        isFirstBooking() ? 100 : 0;

    const total =
        Math.max(
            0,
            baseFare +
            distanceFare +
            platformFee -
            discount
        );


    setText(
        "baseFare",
        formatCurrency(baseFare)
    );

    setText(
        "distanceFare",
        formatCurrency(distanceFare)
    );

    setText(
        "platformFee",
        formatCurrency(platformFee)
    );

    setText(
        "discount",
        discount > 0
            ? "-" + formatCurrency(discount)
            : formatCurrency(0)
    );

    setText(
        "totalFare",
        formatCurrency(total)
    );

}
/* =========================================================
   FIRST BOOKING CHECK
========================================================= */

function isFirstBooking() {

    const bookings =
        getBookings();

    return bookings.length === 0;

}


/* =========================================================
   GET CURRENT FARE
========================================================= */

function getCurrentFare() {

    const baseFare =
        Number(selectedVehicle?.price) || 300;

    const distanceFare =
        Math.round(
            (Number(routeDistanceKm) || 0) * 40
        );

    const platformFee = 20;

    // ₹100 discount ONLY for first booking
    const discount =
        isFirstBooking() ? 100 : 0;

    return Math.max(
        0,
        baseFare +
        distanceFare +
        platformFee -
        discount
    );
}

/* =========================================================
   FIRST BOOKING CHECK
========================================================= */

function isFirstBooking() {

    const bookings = getBookings();

    return bookings.length === 0;
}

/* =========================================================
   SCHEDULE
========================================================= */

function selectSchedule(button, type) {

    if (!button) {
        return;
    }


    document.querySelectorAll(
        ".schedule-btn"
    ).forEach(function (item) {

        item.classList.remove("selected");

    });


    button.classList.add("selected");


    selectedSchedule = type;


    if (type === "Now") {

        setText(
            "selectedScheduleText",
            "Now - Pickup in ~15 mins"
        );


        setText(
            "selectedScheduleDisplay",
            "Now"
        );


        hideElement("scheduleError");

        return;
    }


    openScheduleModal();

}


function openScheduleModal() {

    const modal = $("scheduleModal");

    if (modal) {
        modal.style.display = "flex";
    }


    const dateInput = $("scheduleDate");
    const timeInput = $("scheduleTime");


    if (dateInput && !dateInput.value) {

        const tomorrow =
            new Date();

        tomorrow.setDate(
            tomorrow.getDate() + 1
        );


        dateInput.value =
            formatDateInput(tomorrow);

    }


    if (timeInput && !timeInput.value) {

        const future =
            new Date(
                Date.now() + 60 * 60 * 1000
            );


        timeInput.value =
            formatTimeInput(future);

    }

}


function closeScheduleModal() {

    const modal = $("scheduleModal");

    if (modal) {
        modal.style.display = "none";
    }

}


function confirmSchedule() {

    const date =
        $("scheduleDate")
            ? $("scheduleDate").value
            : "";

    const time =
        $("scheduleTime")
            ? $("scheduleTime").value
            : "";


    const error = $("scheduleError");


    if (!date || !time) {

        if (error) {

            error.textContent =
                "Please select date and time";

            error.style.display = "block";

        }

        return;
    }


    const selectedDateTime =
        new Date(
            `${date}T${time}`
        );


    if (
        Number.isNaN(
            selectedDateTime.getTime()
        )
    ) {

        if (error) {

            error.textContent =
                "Please select a valid date and time";

            error.style.display = "block";

        }

        return;
    }


    if (
        selectedDateTime.getTime() <=
        Date.now()
    ) {

        if (error) {

            error.textContent =
                "Please select a future time";

            error.style.display = "block";

        }

        return;
    }


    selectedSchedule = "Schedule";


    const displayDate =
        selectedDateTime.toLocaleDateString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );


    const displayTime =
        selectedDateTime.toLocaleTimeString(
            "en-IN",
            {
                hour: "2-digit",
                minute: "2-digit"
            }
        );


    const display =
        `${displayDate} at ${displayTime}`;


    setText(
        "selectedScheduleText",
        display
    );


    setText(
        "selectedScheduleDisplay",
        display
    );


    closeScheduleModal();

    showToast("Schedule selected");

}


/* =========================================================
   BOOKING STEPS
========================================================= */

function showBookingStep(step) {

    const steps = [1, 2, 3];


    steps.forEach(function (number) {

        const element =
            $("bookingStep" + number);

        if (!element) {
            return;
        }

        element.style.display =
            number === step
                ? "block"
                : "none";

    });


    steps.forEach(function (number) {

        const progress =
            $("progressStep" + number);

        if (!progress) {
            return;
        }


        if (number <= step) {
            progress.classList.add("active");
        } else {
            progress.classList.remove("active");
        }

    });


    if (step === 3) {
        updateBookingSummary();
    }

}


function nextBookingStep() {

    const step1 =
        $("bookingStep1");

    const step2 =
        $("bookingStep2");

    const step3 =
        $("bookingStep3");


    if (
        step1 &&
        step1.style.display !== "none"
    ) {

        const pickup =
            getLocationValue("pickup");

        const drop =
            getLocationValue("drop");


        if (
            !pickup ||
            pickup === "Select pickup location"
        ) {

            showToast(
                "Please select pickup location"
            );

            return;
        }


        if (
            !drop ||
            drop === "Select drop location"
        ) {

            showToast(
                "Please select drop location"
            );

            return;
        }


        if (!selectedGoods) {

            showToast(
                "Please select what you are transporting"
            );

            return;
        }


        showBookingStep(2);

        return;
    }


    if (
        step2 &&
        step2.style.display !== "none"
    ) {

        updateFare();

        showBookingStep(3);

        return;
    }


    if (
        step3 &&
        step3.style.display !== "none"
    ) {

        openPayment();

    }

}


/* =========================================================
   ROUTE CALCULATION
========================================================= */

function calculateRoute() {

    const pickup =
        getLocationValue("pickup");

    const drop =
        getLocationValue("drop");


    if (
        !pickup ||
        !drop ||
        pickup === "Select pickup location" ||
        drop === "Select drop location"
    ) {
        return;
    }


    if (
        window.google &&
        google.maps &&
        google.maps.DirectionsService
    ) {

        if (!routeDirectionsService) {

            routeDirectionsService =
                new google.maps.DirectionsService();

        }


        if (!routeDirectionsRenderer) {

            routeDirectionsRenderer =
                new google.maps.DirectionsRenderer({
 		    map: routeMap,
                    suppressMarkers: false
                });

        }


        if (!routeMap) {
            initializeRouteMap();
        }


        routeDirectionsService.route(
            {
                origin: pickup,
                destination: drop,
                travelMode:
                    google.maps.TravelMode.DRIVING
            },
            function (result, status) {

                if (
                    status === "OK" &&
                    result &&
                    result.routes &&
                    result.routes.length
                ) {

                    routeDirectionsRenderer.setDirections(
                        result
                    );


                    const leg =
                        result.routes[0]
                            .legs[0];


                    routeDistanceKm =
                        leg.distance.value / 1000;


                    setText(
                        "routeDistanceText",
                        `${leg.distance.text} • ${leg.duration.text}`
                    );


                    showElement(
                        "routeDistanceInfo"
                    );


                    updateFare();

                } else {

                    /*
                       Fallback approximate distance.
                    */

                    routeDistanceKm = 5;

                    setText(
                        "routeDistanceText",
                        "Approx. 5 km"
                    );

                    showElement(
                        "routeDistanceInfo"
                    );

                    updateFare();

                }

            }
        );

        return;
    }


    /*
       Google Maps not available.
       Use a demo distance.
    */

    routeDistanceKm = 5;

    setText(
        "routeDistanceText",
        "Approx. 5 km"
    );

    showElement(
        "routeDistanceInfo"
    );

    updateFare();

}


/* =========================================================
   GOOGLE MAPS INITIALIZATION
========================================================= */

function initGoogleMaps() {

    try {

        initializeRouteMap();

        initializeTrackingMap();

        calculateRoute();

    } catch (error) {

        console.warn(
            "Google Maps initialization error:",
            error
        );

    }

}


/* =========================================================
   ROUTE MAP
========================================================= */

function initializeRouteMap() {

    const mapElement =
        $("routeMap");


    if (
        !mapElement ||
        !window.google ||
        !google.maps
    ) {
        return;
    }


    if (!routeMap) {

        routeMap =
            new google.maps.Map(
                mapElement,
                {
                    center: {
                        lat: 19.0473,
                        lng: 73.0699
                    },
                    zoom: 12,
                    mapTypeControl: false,
                    streetViewControl: false,
                    fullscreenControl: false
                }
            );

    }


    if (routeDirectionsRenderer) {

        routeDirectionsRenderer.setMap(
            routeMap
        );

    }

}


/* =========================================================
   TRACKING MAP
========================================================= */

function initializeTrackingMap() {

    const mapElement =
        $("trackingMap");


    if (
        !mapElement ||
        !window.google ||
        !google.maps
    ) {
        return;
    }


    if (!trackingMap) {

        trackingMap =
            new google.maps.Map(
                mapElement,
                {
                    center: {
                        lat: 19.0473,
                        lng: 73.0699
                    },
                    zoom: 13,
                    mapTypeControl: false,
                    streetViewControl: false,
                    fullscreenControl: false
                }
            );


        new google.maps.Marker({
            position: {
                lat: 19.0473,
                lng: 73.0699
            },
            map: trackingMap,
            title: "Driver location"
        });

    }

}

/* =========================================================
   BOOKING SUMMARY
========================================================= */

function updateBookingSummary() {

    const pickup =
        getLocationValue("pickup");

    const drop =
        getLocationValue("drop");


    updateFare();


    const bookingId =
        currentBooking?.id ||
        generateBookingId();


    setText(
        "summaryBookingId",
        bookingId
    );


    setText(
        "summaryPickup",
        pickup || "—"
    );


    setText(
        "summaryDrop",
        drop || "—"
    );


    setText(
        "summaryGoods",
        selectedGoods || "—"
    );


    setText(
        "summaryVehicle",
        selectedVehicle.name
    );


    setText(
        "summarySchedule",
        getScheduleDisplay()
    );


    setText(
        "modalPaymentAmount",
        formatCurrency(
            getCurrentFare()
        )
    );

}


function getScheduleDisplay() {

    if (selectedSchedule === "Now") {
        return "Now - Pickup in ~15 mins";
    }


    const date =
        $("scheduleDate")
            ? $("scheduleDate").value
            : "";

    const time =
        $("scheduleTime")
            ? $("scheduleTime").value
            : "";


    if (!date || !time) {
        return "Scheduled";
    }


    const dateObject =
        new Date(`${date}T${time}`);


    return (
        dateObject.toLocaleDateString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        ) +
        " at " +
        dateObject.toLocaleTimeString(
            "en-IN",
            {
                hour: "2-digit",
                minute: "2-digit"
            }
        )
    );

}


/* =========================================================
   PAYMENT SELECTION
========================================================= */

function selectPayment(button, method) {

    selectedPayment = method;


    document.querySelectorAll(
        ".payment-option"
    ).forEach(function (item) {

        item.classList.remove("selected");

    });


    if (button) {
        button.classList.add("selected");
    }


    showToast(
        method + " selected"
    );

}


/* =========================================================
   OPEN PAYMENT
========================================================= */

function openPayment() {

    updateBookingSummary();

    updateFare();


    const payment =
        $("paymentModal");


    if (!payment) {
        return;
    }


    payment.style.display = "flex";


    showPaymentForm(
        selectedPayment
    );

}


function showPaymentForm(method) {

    hideElement("upiForm");
    hideElement("cardForm");
    hideElement("cashForm");


    if (method === "UPI") {

        showElement("upiForm");

    } else if (method === "Card") {

        showElement("cardForm");

    } else {

        showElement("cashForm");

    }

}


function closePaymentModal() {

    const modal =
        $("paymentModal");

    if (modal) {
        modal.style.display = "none";
    }

}


/* =========================================================
   PROCESS UPI / CARD PAYMENT
========================================================= */

function processPayment() {

    if (selectedPayment === "UPI") {

        const upi =
            $("upiId")
                ? $("upiId").value.trim()
                : "";


        if (!upi) {

            showToast(
                "Please enter your UPI ID"
            );

            return;
        }


        if (
            !/^[\w.-]+@[\w.-]+$/.test(upi)
        ) {

            showToast(
                "Enter a valid UPI ID"
            );

            return;
        }

    }


    if (selectedPayment === "Card") {

        const card =
            $("cardNumber")
                ? $("cardNumber").value
                    .replace(/\s/g, "")
                : "";

        const expiry =
            $("cardExpiry")
                ? $("cardExpiry").value.trim()
                : "";

        const cvv =
            $("cardCvv")
                ? $("cardCvv").value.trim()
                : "";


        if (!/^\d{16}$/.test(card)) {

            showToast(
                "Enter a valid 16-digit card number"
            );

            return;
        }


        if (
            !/^(0[1-9]|1[0-2])\/\d{2}$/.test(
                expiry
            )
        ) {

            showToast(
                "Enter expiry as MM/YY"
            );

            return;
        }


        if (!/^\d{3}$/.test(cvv)) {

            showToast(
                "Enter a valid CVV"
            );

            return;
        }

    }


    closePaymentModal();

    createBooking("Paid");

}


/* =========================================================
   CASH PAYMENT
========================================================= */

function processCashPayment() {

    selectedPayment = "Cash";

    closePaymentModal();

    createBooking("Cash");

}


/* =========================================================
   CREATE BOOKING
========================================================= */

function createBooking(paymentStatus) {

    const pickup =
        getLocationValue("pickup");

    const drop =
        getLocationValue("drop");


    if (!pickup || !drop) {

        showToast(
            "Please select pickup and drop"
        );

        return;
    }


    const fare =
        getCurrentFare();


    const booking = {

        id: generateBookingId(),

        userId:
            getCurrentUser()?.id ||
            "GUEST",

        pickup: pickup,

        drop: drop,

        goods:
            selectedGoods || "Other",

        goodsDescription:
            $("goodsDescription")
                ? $("goodsDescription").value.trim()
                : "",

        vehicle:
            selectedVehicle.name,

        baseFare:
            Number(selectedVehicle.price),

        distanceKm:
            Number(routeDistanceKm) || 0,

        distanceFare:
            Math.round(
                (Number(routeDistanceKm) || 0) * 15
            ),

        platformFee: 20,

        discount:
            isFirstBooking()
                ? 100
                : 0,

        total:
            fare,

        paymentMethod:
            selectedPayment,

        paymentStatus:
            paymentStatus,

        schedule:
            getScheduleDisplay(),

        status:
            "Confirmed",

        createdAt:
            new Date().toISOString(),

        driver: {
            name: "Rajesh Kumar",
            vehicle: "MH-04-AB-1234"
        }

    };


    currentBooking = booking;


    const bookings =
        getBookings();


    bookings.unshift(booking);

    saveBookings(bookings);


    updateSuccessModal(booking);

    updateTrackingData(booking);

    updateHistory();


    showSuccessModal();

}


/* =========================================================
   SUCCESS MODAL
========================================================= */

function updateSuccessModal(booking) {

    if (!booking) {
        return;
    }


    setText(
        "successBookingId",
        booking.id
    );


    setText(
        "successVehicle",
        booking.vehicle
    );


    setText(
        "successPickup",
        booking.pickup
    );


    setText(
        "successDrop",
        booking.drop
    );


    setText(
        "successSchedule",
        booking.schedule
    );


    setText(
        "successTotal",
        formatCurrency(
            booking.total
        )
    );


    const details =
        $("successBookingDetails");


    if (details) {

        details.innerHTML = `
            <p>
                <strong>Payment:</strong>
                ${escapeHtml(booking.paymentMethod)}
            </p>
            <p>
                <strong>Goods:</strong>
                ${escapeHtml(booking.goods)}
            </p>
        `;

    }

}


function showSuccessModal() {

    const modal =
        $("successModal");

    if (modal) {
        modal.style.display = "flex";
    }

}


function closeSuccess() {

    const modal =
        $("successModal");

    if (modal) {
        modal.style.display = "none";
    }

}


function closeSuccessAndTrack() {

    closeSuccess();

    navigate("tracking");

}


/* =========================================================
   TRACKING
========================================================= */

function updateTrackingData(booking) {

    if (!booking) {
        return;
    }


    setText(
        "trackingBookingId",
        booking.id
    );


    setText(
        "trackingPickup",
        booking.pickup
    );


    setText(
        "trackingDrop",
        booking.drop
    );


    setText(
        "trackingVehicle",
        booking.vehicle
    );


    setText(
        "trackingSchedule",
        booking.schedule
    );


    setText(
        "trackingFare",
        formatCurrency(
            booking.total
        )
    );


    setText(
        "driverName",
        booking.driver?.name ||
        "Rajesh Kumar"
    );


    setText(
        "driverVehicle",
        booking.driver?.vehicle ||
        "MH-04-AB-1234"
    );


    setText(
        "trackingStatus",
        booking.status === "Cancelled"
            ? "Booking Cancelled"
            : "Driver Assigned"
    );


    setText(
        "driverStatus",
        booking.status === "Cancelled"
            ? "Booking cancelled"
            : "Driver is on the way"
    );


    setText(
        "trackingEta",
        booking.status === "Cancelled"
            ? "—"
            : "Arriving in 8 mins"
    );


    const cancelButton =
        $("cancelBookingButton");


    if (cancelButton) {

        cancelButton.style.display =
            booking.status === "Cancelled"
                ? "none"
                : "block";

    }

}


function updateTrackingPage() {

    const bookings =
        getBookings();


    if (
        !currentBooking &&
        bookings.length
    ) {

        currentBooking =
            bookings.find(
                booking =>
                    booking.status !== "Cancelled"
            ) || bookings[0];

    }


    if (currentBooking) {

        updateTrackingData(
            currentBooking
        );

    }

}


/* =========================================================
   CALL / MESSAGE DRIVER
========================================================= */

function callDriver() {

    showToast(
        "Calling driver..."
    );


    /*
       Demo only.
       No real driver phone number is stored.
    */

}


function messageDriver() {

    showToast(
        "Opening driver chat..."
    );

}

/* =========================================================
   CANCEL BOOKING
========================================================= */

function cancelBooking() {

    if (!currentBooking) {

        const bookings =
            getBookings();

        currentBooking =
            bookings[0] || null;

    }


    if (!currentBooking) {

        showToast(
            "No active booking found"
        );

        return;
    }


    if (
        currentBooking.status === "Cancelled"
    ) {

        showToast(
            "This booking is already cancelled"
        );

        return;
    }


    const modal =
        $("cancelModal");


    if (modal) {

        modal.style.display = "flex";

    }


    const original =
        Number(currentBooking.total) || 0;


    // ₹50 cancellation charge for paid booking
    const charge =
        currentBooking.paymentStatus === "Paid"
            ? 50
            : 0;


    const refund =
        currentBooking.paymentStatus === "Paid"
            ? Math.max(0, original - charge)
            : 0;


    setText(
        "cancelOriginalFare",
        formatCurrency(original)
    );


    setText(
        "cancelCharge",
        formatCurrency(charge)
    );


    setText(
        "cancelFinalAmount",
        formatCurrency(refund)
    );

}


function closeCancelModal() {

    const modal =
        $("cancelModal");

    if (modal) {
        modal.style.display = "none";
    }

}


function confirmCancellation() {

    if (!currentBooking) {
        return;
    }


    const bookings =
        getBookings();


    const index =
        bookings.findIndex(
            booking =>
                booking.id ===
                currentBooking.id
        );


    if (index === -1) {

        closeCancelModal();

        showToast(
            "Booking not found"
        );

        return;
    }


    const original =
        Number(
            bookings[index].total
        ) || 0;


    // ₹50 cancellation charge for paid booking
    const charge =
        bookings[index].paymentStatus === "Paid"
            ? 50
            : 0;


    const refund =
        bookings[index].paymentStatus === "Paid"
            ? Math.max(0, original - charge)
            : 0;


    bookings[index].status =
        "Cancelled";


    bookings[index].cancelledAt =
        new Date().toISOString();


    bookings[index].cancellationCharge =
        charge;


    bookings[index].refundAmount =
        refund;


    currentBooking =
        bookings[index];


    saveBookings(bookings);


    closeCancelModal();

    updateTrackingData(
        currentBooking
    );

    updateHistory();


    showToast(
        "Booking cancelled successfully"
    );

}

/* =========================================================
   HISTORY
========================================================= */

function updateHistory(filter = "all") {

    const container =
        $("bookingHistoryList");


    if (!container) {
        return;
    }


    const user =
        getCurrentUser();


    let bookings =
        getBookings();


    if (user && user.id) {

        bookings =
            bookings.filter(
                booking =>
                    booking.userId ===
                    user.id
            );

    }


    if (filter === "completed") {

        bookings =
            bookings.filter(
                booking =>
                    booking.status === "Completed"
            );

    }


    if (filter === "cancelled") {

        bookings =
            bookings.filter(
                booking =>
                    booking.status === "Cancelled"
            );

    }


    if (bookings.length === 0) {

        container.innerHTML = `
            <div class="empty-history">
                <div class="empty-history-icon">
                    📦
                </div>

                <h3>
                    No bookings yet
                </h3>

                <p>
                    Your bookings will appear here.
                </p>

                <button
                    class="primary-btn"
                    onclick="navigate('home')"
                >
                    Book a Tempo
                </button>
            </div>
        `;

        return;
    }


    container.innerHTML =
        bookings.map(
            createHistoryCard
        ).join("");

}


function createHistoryCard(booking) {

    const statusClass =
        booking.status === "Cancelled"
            ? "cancelled"
            : booking.status === "Completed"
                ? "completed"
                : "confirmed";


    return `
        <div class="history-card">

            <div class="history-card-header">

                <div>
                    <strong>
                        ${escapeHtml(booking.vehicle)}
                    </strong>

                    <small>
                        ${escapeHtml(booking.id)}
                    </small>
                </div>

                <span class="history-status ${statusClass}">
                    ${escapeHtml(booking.status)}
                </span>

            </div>

            <div class="history-route">

                <div>
                    <span>●</span>
                    ${escapeHtml(booking.pickup)}
                </div>

                <div>
                    <span>●</span>
                    ${escapeHtml(booking.drop)}
                </div>

            </div>

            <div class="history-card-footer">

                <span>
                    ${escapeHtml(booking.schedule)}
                </span>

                <strong>
                    ${formatCurrency(booking.total)}
                </strong>

            </div>

        </div>
    `;

}


function bookingTab(button, filter) {

    document.querySelectorAll(
        ".history-tab"
    ).forEach(function (tab) {

        tab.classList.remove("active");

    });


    if (button) {
        button.classList.add("active");
    }


    updateHistory(filter);

}


/* =========================================================
   COUPON
========================================================= */

function copyCoupon() {

    const coupon = "QT100";


    if (
        navigator.clipboard &&
        navigator.clipboard.writeText
    ) {

        navigator.clipboard.writeText(
            coupon
        ).then(function () {

            showToast(
                "Coupon QT100 copied"
            );

        }).catch(function () {

            showToast(
                "Coupon: QT100"
            );

        });

    } else {

        showToast(
            "Coupon: QT100"
        );

    }

}


/* =========================================================
   NOTIFICATIONS
========================================================= */

function openNotifications() {

    const panel =
        $("notificationPanel");


    if (panel) {
        panel.style.display = "flex";
    }

}


function closeNotifications() {

    const panel =
        $("notificationPanel");


    if (panel) {
        panel.style.display = "none";
    }

}


/* =========================================================
   SUPPORT
========================================================= */

function openSupport() {

    const modal =
        $("supportModal");


    if (modal) {
        modal.style.display = "flex";
    }

}


function closeSupport() {

    const modal =
        $("supportModal");


    if (modal) {
        modal.style.display = "none";
    }

}


/* =========================================================
   TOAST
========================================================= */

let toastTimer = null;


function showToast(message) {

    const toast =
        $("toast");

    const toastMessage =
        $("toastMessage");


    if (!toast || !toastMessage) {
        return;
    }


    toastMessage.textContent =
        message;


    toast.style.display =
        "flex";


    clearTimeout(toastTimer);


    toastTimer =
        setTimeout(function () {

            toast.style.display =
                "none";

        }, 2500);

}


/* =========================================================
   CLOSE ALL MODALS
========================================================= */

function closeAllModals() {

    [
        "locationModal",
        "scheduleModal",
        "paymentModal",
        "successModal",
        "cancelModal",
        "supportModal",
        "notificationPanel"
    ].forEach(function (id) {

        const element = $(id);

        if (element) {
            element.style.display = "none";
        }

    });

}


/* =========================================================
   INPUT FORMATTING
========================================================= */

function initializeInputFormatting() {

    const phoneInputs =
        document.querySelectorAll(
            'input[type="tel"]'
        );


    phoneInputs.forEach(function (input) {

        input.addEventListener(
            "input",
            function () {

                this.value =
                    this.value
                        .replace(/\D/g, "")
                        .slice(0, 10);

            }
        );

    });


    const cardNumber =
        $("cardNumber");


    if (cardNumber) {

        cardNumber.addEventListener(
            "input",
            function () {

                let value =
                    this.value
                        .replace(/\D/g, "")
                        .slice(0, 16);


                value =
                    value.replace(
                        /(.{4})/g,
                        "$1 "
                    )
                    .trim();


                this.value = value;

            }
        );

    }


    const expiry =
        $("cardExpiry");


    if (expiry) {

        expiry.addEventListener(
            "input",
            function () {

                let value =
                    this.value
                        .replace(/\D/g, "")
                        .slice(0, 4);


                if (value.length > 2) {

                    value =
                        value.slice(0, 2) +
                        "/" +
                        value.slice(2);

                }


                this.value = value;

            }
        );

    }


    const cvv =
        $("cardCvv");


    if (cvv) {

        cvv.addEventListener(
            "input",
            function () {

                this.value =
                    this.value
                        .replace(/\D/g, "")
                        .slice(0, 3);

            }
        );

    }

}


/* =========================================================
   DATE / TIME HELPERS
========================================================= */

function formatDateInput(date) {

    const year =
        date.getFullYear();


    const month =
        String(
            date.getMonth() + 1
        ).padStart(2, "0");


    const day =
        String(
            date.getDate()
        ).padStart(2, "0");


    return `${year}-${month}-${day}`;

}


function formatTimeInput(date) {

    const hours =
        String(
            date.getHours()
        ).padStart(2, "0");


    const minutes =
        String(
            date.getMinutes()
        ).padStart(2, "0");


    return `${hours}:${minutes}`;

}


/* =========================================================
   ID GENERATOR
========================================================= */

function generateBookingId() {

    const random =
        Math.floor(
            1000 +
            Math.random() * 9000
        );


    return `QT${Date.now()
        .toString()
        .slice(-6)}${random}`;

}


/* =========================================================
   CURRENCY
========================================================= */

function formatCurrency(amount) {

    return "₹" +
        Number(amount || 0).toLocaleString(
            "en-IN"
        );

}


/* =========================================================
   HTML ESCAPE
========================================================= */

function escapeHtml(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* =========================================================
   GLOBAL MODAL CLICK HANDLING
========================================================= */

document.addEventListener(
    "click",
    function (event) {

        const target =
            event.target;


        /*
           Close side panel when clicking
           outside it.
        */

        const notificationPanel =
            $("notificationPanel");


        if (
            notificationPanel &&
            notificationPanel.style.display !== "none" &&
            target === notificationPanel
        ) {

            closeNotifications();

        }

    }
);


/* =========================================================
   ESC KEY
========================================================= */

document.addEventListener(
    "keydown",
    function (event) {

        if (event.key !== "Escape") {
            return;
        }


        closeLocationModal();
        closeScheduleModal();
        closePaymentModal();
        closeSuccess();
        closeCancelModal();
        closeSupport();
        closeNotifications();

    }
);


/* =========================================================
   EXPORT GLOBAL FUNCTIONS
   Needed because index.html uses inline onclick.
========================================================= */

window.toggleAuth = toggleAuth;
window.handleAuth = handleAuth;
window.guestLogin = guestLogin;
window.logout = logout;

window.navigate = navigate;

window.startBooking = startBooking;
window.quickBooking = quickBooking;

window.openLocationPicker =
    openLocationPicker;

window.closeLocationModal =
    closeLocationModal;

window.clearLocationSearch =
    clearLocationSearch;

window.searchLocations =
    searchLocations;

window.detectCurrentLocation =
    detectCurrentLocation;

window.useCurrentLocation =
    useCurrentLocation;

window.swapLocations =
    swapLocations;

window.selectGoods =
    selectGoods;

window.selectVehicle =
    selectVehicle;

window.selectSchedule =
    selectSchedule;

window.openScheduleModal =
    openScheduleModal;

window.closeScheduleModal =
    closeScheduleModal;

window.confirmSchedule =
    confirmSchedule;

window.nextBookingStep =
    nextBookingStep;

window.showBookingStep =
    showBookingStep;

window.selectPayment =
    selectPayment;

window.openPayment =
    openPayment;

window.closePaymentModal =
    closePaymentModal;

window.processPayment =
    processPayment;

window.processCashPayment =
    processCashPayment;

window.closeSuccess =
    closeSuccess;

window.closeSuccessAndTrack =
    closeSuccessAndTrack;

window.cancelBooking =
    cancelBooking;

window.closeCancelModal =
    closeCancelModal;

window.confirmCancellation =
    confirmCancellation;

window.bookingTab =
    bookingTab;

window.callDriver =
    callDriver;

window.messageDriver =
    messageDriver;

window.copyCoupon =
    copyCoupon;

window.openNotifications =
    openNotifications;

window.closeNotifications =
    closeNotifications;

window.openSupport =
    openSupport;

window.closeSupport =
    closeSupport;

window.showToast =
    showToast;

window.initGoogleMaps =
    initGoogleMaps;


/* =========================================================
   END OF SCRIPT
========================================================= */