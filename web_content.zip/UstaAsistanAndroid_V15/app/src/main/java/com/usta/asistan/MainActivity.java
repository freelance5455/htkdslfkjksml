package com.usta.asistan;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView mainWebView;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        mainWebView = new WebView(this);
        mainWebView.setWebViewClient(new WebViewClient());
        WebSettings s = mainWebView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        mainWebView.addJavascriptInterface(new PdfBridge(this), "Android");
        mainWebView.loadUrl("file:///android_asset/protherm_teknik_servis.html");
        setContentView(mainWebView);
    }

    @Override public void onBackPressed() {
        if (mainWebView != null && mainWebView.canGoBack()) mainWebView.goBack();
        else super.onBackPressed();
    }

    public static class PdfBridge {
        private final Activity activity;
        PdfBridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface
        public void shareReceiptPdf(final String html) {
            activity.runOnUiThread(() -> createPdfAndShare(html));
        }

        @JavascriptInterface
        public void saveReceiptPdf(final String html) {
            activity.runOnUiThread(() -> createPdfAndSave(html));
        }

        private void createPdfAndSave(String html) {
            final WebView pdfWebView = buildPdfWebView(html, false);
            // buildPdfWebView writes the PDF and leaves it in Downloads without opening the share sheet.
        }

        private WebView buildPdfWebView(String html, boolean shareAfter) {
            final WebView pdfWebView = new WebView(activity);
            WebSettings settings = pdfWebView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            pdfWebView.setBackgroundColor(Color.WHITE);
            pdfWebView.setTag(shareAfter);
            pdfWebView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    view.postDelayed(() -> writePdf(pdfWebView), 700);
                }
            });
            String css = "<style>body{margin:0;background:#fff;font-family:Arial,sans-serif;color:#222}.receipt{max-width:720px;margin:auto;padding:28px}.receiptLogo{display:block;width:210px;max-height:75px;object-fit:contain;object-position:left center;margin-bottom:8px}.receipt h2{margin:4px 0 8px;font-size:20px}.rgrid{display:grid;grid-template-columns:1fr 1fr;gap:7px 18px;font-size:13px}.box{border:1px solid #ddd;padding:10px;margin-top:10px}.total{text-align:right;font-size:18px;font-weight:bold;margin-top:18px}.techsign{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:22px}.sigarea{border:1px solid #ddd;min-height:72px;padding:10px}.sigline{border-bottom:1px solid #222;margin-top:38px}.foot{text-align:center;margin-top:25px;font-size:11px;color:#666}</style>";
            String doc = "<html><head><meta charset='utf-8'>" + css + "</head><body>" + html + "</body></html>";
            pdfWebView.loadDataWithBaseURL("https://www.vaillant-group.com/", doc, "text/html", "UTF-8", null);
            return pdfWebView;
        }

        private void createPdfAndShare(String html) {
            final WebView pdfWebView = buildPdfWebView(html, true);
        }

        private void writePdf(final WebView pdfWebView) {
            final String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            final String fileName = "Protherm_Servis_Fisi_" + stamp + ".pdf";
            final PrintDocumentAdapter adapter = pdfWebView.createPrintDocumentAdapter("Protherm_Servis_Fisi");
            final PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("pdf", "pdf", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();

            adapter.onLayout(null, attrs, new CancellationSignal(), new PrintDocumentAdapter.LayoutResultCallback() {
                @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                    Uri uri = createDownloadsUri(fileName);
                    if (uri == null) {
                        Toast.makeText(activity, "PDF oluşturulamadı.", Toast.LENGTH_LONG).show();
                        pdfWebView.destroy();
                        return;
                    }
                    try {
                        android.os.ParcelFileDescriptor pfd = activity.getContentResolver().openFileDescriptor(uri, "w");
                        adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, pfd, new CancellationSignal(), new PrintDocumentAdapter.WriteResultCallback() {
                            @Override public void onWriteFinished(PageRange[] pages) {
                                try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
                                markReady(uri);
                                boolean shouldShare = Boolean.TRUE.equals(pdfWebView.getTag());
                                pdfWebView.destroy();
                                if (shouldShare) {
                                    sharePdf(uri);
                                } else {
                                    Toast.makeText(activity, "PDF indirildi: Downloads klasörüne kaydedildi.", Toast.LENGTH_LONG).show();
                                }
                            }
                            @Override public void onWriteFailed(CharSequence error) {
                                try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
                                Toast.makeText(activity, "PDF yazılamadı: " + error, Toast.LENGTH_LONG).show();
                                pdfWebView.destroy();
                            }
                        });
                    } catch (Exception e) {
                        Toast.makeText(activity, "PDF dosyası açılamadı: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        pdfWebView.destroy();
                    }
                }
                @Override public void onLayoutFailed(CharSequence error) {
                    Toast.makeText(activity, "PDF hazırlanamadı: " + error, Toast.LENGTH_LONG).show();
                    pdfWebView.destroy();
                }
            }, null);
        }

        private Uri createDownloadsUri(String fileName) {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                return activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            }
            try {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                return Uri.fromFile(new File(dir, fileName));
            } catch (Exception e) { return null; }
        }

        private void markReady(Uri uri) {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                activity.getContentResolver().update(uri, values, null, null);
            }
        }

        private void sharePdf(Uri uri) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("application/pdf");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                activity.startActivity(Intent.createChooser(intent, "Servis fişini paylaş"));
            } catch (Exception e) {
                Toast.makeText(activity, "PDF Downloads klasörüne kaydedildi.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
