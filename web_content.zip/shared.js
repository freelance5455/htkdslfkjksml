const KEY="shesha_delivery_v1";
const DEMO={settings:{kmRate:8,handlingFee:15,serviceFee:5},products:[
{id:"f1",category:"Food",name:"Chicken Burger",price:55,stock:true,icon:"🍔"},
{id:"f2",category:"Food",name:"Chips",price:30,stock:true,icon:"🍟"},
{id:"f3",category:"Food",name:"Chicken & Chips",price:75,stock:true,icon:"🍗"},
{id:"p1",category:"Car Parts",name:"Brake Pads",price:450,stock:true,icon:"🛞"},
{id:"p2",category:"Car Parts",name:"Oil Filter",price:120,stock:true,icon:"🔧"},
{id:"p3",category:"Car Parts",name:"Spark Plugs",price:180,stock:true,icon:"⚙️"},
{id:"p4",category:"Car Parts",name:"Car Battery",price:1450,stock:true,icon:"🔋"}],
orders:[],requests:[],drivers:[{id:"d1",name:"Demo Driver",vehicle:"Bike",available:true}],packers:[{id:"pk1",name:"Demo Packer",available:true}]};
function load(){let x=localStorage.getItem(KEY);if(!x){save(DEMO);return JSON.parse(JSON.stringify(DEMO))}return JSON.parse(x)}
function save(x){localStorage.setItem(KEY,JSON.stringify(x));window.dispatchEvent(new Event("sd"))}
function money(x){return "R "+Number(x||0).toFixed(2)}
function esc(x){return String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function uid(p){return p+Date.now().toString(36)+Math.random().toString(36).slice(2,5)}
function stamp(){return new Date().toLocaleString("en-ZA")}
function km(address){let h=0,s=String(address||"");for(let c of s)h=(h*31+c.charCodeAt(0))>>>0;return s.trim()?2+(h%1800)/100:0}
function totals(items,address,tip){let d=load(),sub=items.reduce((a,x)=>a+x.price*x.qty,0),k=km(address),del=k*d.settings.kmRate,h=d.settings.handlingFee,sv=d.settings.serviceFee,t=Number(tip||0);return{subtotal:sub,km:k,delivery:del,handling:h,service:sv,tip:t,total:sub+del+h+sv+t}}
function cls(s){return"status "+String(s||"").toLowerCase().replaceAll(" ","-")}
