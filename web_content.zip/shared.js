(function () {
  'use strict';
  const KEY = 'kurumsal_envanter_v1';
  const seed = () => ({
    schemaVersion: 1,
    nextInventory: 1,
    nextMovement: 1,
    products: [], movements: [], units: [], people: [],
    categories: [
      {id:'cat_machine',name:'Makine',sub:['Çim Biçme Makinesi','Motorlu Tırpan','Su Motoru'],active:true},
      {id:'cat_equipment',name:'Ekipman',sub:['El Aletleri','Ölçüm Cihazları'],active:true},
      {id:'cat_furniture',name:'Demirbaş',sub:['Masa','Dolap'],active:true},
      {id:'cat_supply',name:'Sarf Malzemesi',sub:[],active:true}
    ],
    maintenanceLogs: [], renewalLogs: [],
    settings: {excelEntry:true,excelExit:true,printEntry:true,printExit:true},
    createdAt: new Date().toISOString(), changedAt: new Date().toISOString()
  });
  const clone = v => JSON.parse(JSON.stringify(v));
  const load = () => { try { const data = JSON.parse(localStorage.getItem(KEY)); return data && Array.isArray(data.products) && Array.isArray(data.movements) ? data : seed(); } catch(e) { return seed(); } };
  const save = d => { d.changedAt = new Date().toISOString(); localStorage.setItem(KEY,JSON.stringify(d)); window.dispatchEvent(new Event('envanter-change')); };
  const uid = () => (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : 'x'+Date.now()+Math.random().toString(36).slice(2));
  const esc = (str) => String(str==null?'':str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const pad = (n) => String(n).padStart(6,'0');
  const fmtDate = iso => { if (!iso) return '—'; const d = new Date(iso); return isNaN(+d)?'—':new Intl.DateTimeFormat('tr-TR',{day:'2-digit',month:'2-digit',year:'numeric'}).format(d); };
  const fmtTime = iso => { if(!iso) return '—'; const d=new Date(iso); return isNaN(+d)?'—':new Intl.DateTimeFormat('tr-TR',{dateStyle:'short',timeStyle:'short'}).format(d); };
  const isoDay = d => { const x=d instanceof Date?d:new Date(d);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0'); };
  const stock = (db,id) => {const product=db.products.find(p=>p.id===id);if(!product)return 0;const out=db.movements.filter(m=>m.productId===id).reduce((a,m)=>a+(m.kind==='out'?-Number(m.quantity):Number(m.quantity)),0);return Number(product.quantity)+out;};
  const addMonths = (date,months) => {if(!date)return '';const base=new Date(date+'T12:00:00');if(isNaN(+base))return '';const day=base.getDate();base.setDate(1);base.setMonth(base.getMonth()+Number(months));const max=new Date(base.getFullYear(),base.getMonth()+1,0).getDate();base.setDate(Math.min(day,max));return isoDay(base);};
  const nextDue = p => p.maintenance && p.maintenance.enabled ? addMonths(p.maintenance.lastDate||p.maintenance.startDate,p.maintenance.months) : '';
  const daysUntil = date => {if(!date)return Infinity;const at=new Date(date+'T12:00:00');const today=new Date();today.setHours(12,0,0,0);return Math.round((at-today)/86400000);};
  const dueStatus = p => {const due=nextDue(p);if(!due)return {key:'none',label:'Gerekmiyor',days:Infinity,date:''};const days=daysUntil(due);if(days<0)return {key:'late',label:'Gecikmiş',days,date:due};if(days<=Number(p.maintenance.warnDays||15))return {key:'soon',label:days===0?'Bugün':'Yaklaşıyor',days,date:due};return {key:'normal',label:'Planlı',days,date:due};};
  const renewalStatus = p => {
    const ren=p.renewal;
    if(!ren?.enabled||!ren.date)return {key:'none',label:'Gerekmiyor',days:Infinity,date:''};
    const days=daysUntil(ren.date);
    if(days<0)return {key:'late',label:'Yenileme gecikmiş',days,date:ren.date};
    if(days<=Number(ren.warnDays||30))return {key:'soon',label:days===0?'Yenileme bugün':'Yenileme yaklaşıyor',days,date:ren.date};
    return {key:'normal',label:'Planlı',days,date:ren.date};
  };
  const alertItems = db => db.products.flatMap(p => {
    const result=[];
    const m=dueStatus(p);if(['soon','late'].includes(m.key))result.push({id:p.id,no:p.no,name:p.name,kind:'Bakım',route:'#admin/maintenance',...m});
    const r=renewalStatus(p);if(['soon','late'].includes(r.key))result.push({id:p.id,no:p.no,name:p.name,kind:'Yenileme',route:'#admin/renewal',...r});
    return result;
  }).sort((a,b)=>a.days-b.days);
  const csvDownload = (filename,rows) => {const text='\ufeff'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');download(filename,new Blob([text],{type:'text/csv;charset=utf-8'}));};
  const download=(filename,blob)=>{
    if(window.Android&&typeof window.Android.saveBase64File==='function'){
      const reader=new FileReader();reader.onload=()=>{try{const b64=String(reader.result).split(',')[1];window.Android.saveBase64File(filename,blob.type||'application/octet-stream',b64);toast('Android dosya kaydetme penceresi açılıyor.');}catch(e){toast('Android dosya kaydı başarısız.');}};
      reader.onerror=()=>toast('Dosya hazırlanamadı.');reader.readAsDataURL(blob);return;
    }
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},5000);
  };
  const xml = s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
  // Standalone XLSX writer (uncompressed ZIP) to keep desktop and phone packages fully offline.
  const enc=new TextEncoder();
  const toU8=s=>enc.encode(s);
  const crc32=data=>{let c=0xffffffff;for(const b of data){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^(c&1?0xedb88320:0);}return (c^0xffffffff)>>>0;};
  const zip=(files)=>{
    const chunks=[],cent=[];let offset=0;
    const word=(v)=>{const a=new Uint8Array(2);new DataView(a.buffer).setUint16(0,v,true);return a;};
    const dword=(v)=>{const a=new Uint8Array(4);new DataView(a.buffer).setUint32(0,v>>>0,true);return a;};
    const join=pieces=>{const len=pieces.reduce((n,x)=>n+x.length,0);const a=new Uint8Array(len);let o=0;for(const x of pieces){a.set(x,o);o+=x.length;}return a;};
    for(const [name,content] of files){const n=toU8(name),d=toU8(content),crc=crc32(d);
      const local=join([dword(0x04034b50),word(20),word(0x0800),word(0),word(0),word(0),dword(crc),dword(d.length),dword(d.length),word(n.length),word(0),n,d]);
      chunks.push(local);
      cent.push(join([dword(0x02014b50),word(20),word(20),word(0x0800),word(0),word(0),word(0),dword(crc),dword(d.length),dword(d.length),word(n.length),word(0),word(0),word(0),word(0),dword(0),dword(offset),n]));
      offset+=local.length;
    }
    const central=join(cent);const end=join([dword(0x06054b50),word(0),word(0),word(files.length),word(files.length),dword(central.length),dword(offset),word(0)]);
    return join([...chunks,central,end]);
  };
  const excelBlob=(table)=>{
    const rows=table.map((r,i)=>'<row r="'+(i+1)+'">'+r.map((v,j)=>{let x=j+1,col='';while(x>0){x--;col=String.fromCharCode(65+x%26)+col;x=Math.floor(x/26);}return '<c r="'+col+(i+1)+'" t="inlineStr"><is><t>'+xml(v)+'</t></is></c>';}).join('')+'</row>').join('');
    const files=[
    ['[Content_Types].xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'],
    ['_rels/.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
    ['xl/workbook.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Kurumsal Envanter" sheetId="1" r:id="rId1"/></sheets></workbook>'],
    ['xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'],
    ['xl/worksheets/sheet1.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetData>'+rows+'</sheetData></worksheet>']];
    return new Blob([zip(files)],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
  };
  const xlsx=(name,rows)=>download(name,excelBlob(rows));
  const $ = (s,root=document)=>root.querySelector(s);
  const $$ = (s,root=document)=>Array.from(root.querySelectorAll(s));
  const toast=message=>{let el=$('#toast');if(!el){el=document.createElement('div');el.id='toast';el.className='toast';document.body.appendChild(el);}el.textContent=message;el.classList.add('visible');clearTimeout(window.__t);window.__t=setTimeout(()=>el.classList.remove('visible'),3500);};
  const option=(v,label,sel)=>'<option value="'+esc(v)+'"'+(sel===v?' selected':'')+'>'+esc(label)+'</option>';
  const nameOf=(items,id)=>items.find(x=>x.id===id)?.name||'—';
  const printTable=(title,headers,rows)=>{
    const tr=rows.map(r=>'<tr>'+r.map(c=>'<td>'+esc(c)+'</td>').join('')+'</tr>').join('');
    const html='<!doctype html><html lang="tr"><meta charset="UTF-8"><title>'+esc(title)+'</title><style>body{font-family:Arial,sans-serif;padding:30px;color:#213647}h1{font-size:21px}small{color:#667b85}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #a9b7c1;padding:7px;text-align:left}th{background:#e3eef0}@page{size:A4 landscape;margin:14mm}</style><h1>'+esc(title)+'</h1><p><small>Oluşturulma: '+esc(fmtTime(new Date().toISOString()))+'</small></p><table><thead><tr>'+headers.map(h=>'<th>'+esc(h)+'</th>').join('')+'</tr></thead><tbody>'+tr+'</tbody></table><script>setTimeout(()=>window.print(),350);<\/script></html>';
    if(window.Android&&typeof window.Android.printHtml==='function'){window.Android.printHtml(title,html);return;}
    const w=window.open('','_blank');if(!w){toast('Yazdırma penceresine izin veriniz.');return;}w.document.write(html);w.document.close();
  };
  const exportInventory=(db,kind='stock')=>{
    if(kind==='stock')return [['Envanter No','Ürün','Kategori','Alt Kategori','Birim','Giriş','Çıkış','Mevcut','Giriş Tarihi','Teslim Alan','Bakım Durumu','Sonraki Bakım','Yenileme Durumu','Yenileme Tarihi'],...db.products.map(p=>[p.no,p.name,p.category,p.subCategory,nameOf(db.units,p.unitId),p.quantity,db.movements.filter(m=>m.productId===p.id&&m.kind==='out').reduce((a,b)=>a+Number(b.quantity),0),stock(db,p.id),fmtTime(p.createdAt),nameOf(db.people,p.receivedById),dueStatus(p).label,fmtDate(nextDue(p)),renewalStatus(p).label,fmtDate(p.renewal?.date)])];
    if(kind==='entry')return [['Envanter No','Ürün','Kategori','Alt Kategori','Miktar','Birim','Teslim Alan','Giriş Tarihi ve Saati'],...db.products.map(p=>[p.no,p.name,p.category,p.subCategory,p.quantity,nameOf(db.units,p.unitId),nameOf(db.people,p.receivedById),fmtTime(p.createdAt)])];
    if(kind==='exit')return [['Çıkış No','Envanter No','Ürün','Miktar','Teslim Alan / Birim','Çıkış Tarihi ve Saati','Açıklama'],...db.movements.filter(m=>m.kind==='out').map(m=>[m.no,db.products.find(p=>p.id===m.productId)?.no||'',db.products.find(p=>p.id===m.productId)?.name||'',m.quantity,m.recipientLabel,fmtTime(m.createdAt),m.note])];
    if(kind==='renewal')return [['Envanter No','Ürün','Yenileme Durumu','Yenileme Tarihi','Önceden Uyarı (Gün)'],...db.products.filter(p=>p.renewal?.enabled).map(p=>[p.no,p.name,renewalStatus(p).label,fmtDate(p.renewal.date),p.renewal.warnDays])];
    return [['Envanter No','Ürün','Bakım Durumu','Sonraki Bakım','Periyot (Ay)','Önceden Uyarı (Gün)','Bakım Sorumlusu'],...db.products.filter(p=>p.maintenance?.enabled).map(p=>[p.no,p.name,dueStatus(p).label,fmtDate(nextDue(p)),p.maintenance.months,p.maintenance.warnDays,nameOf(db.people,p.maintenance.responsibleId)])];
  };
  // Native Android app opens the management panel in a separate Activity.
  document.addEventListener('click',event=>{
    if(!window.Android || typeof window.Android.openAdmin!=='function')return;
    const anchor=event.target.closest('a[href]');if(!anchor)return;
    const target=new URL(anchor.getAttribute('href'),document.baseURI);
    if(target.pathname.endsWith('/admin.html')){
      event.preventDefault();window.Android.openAdmin(target.hash||'');
    }
  });
  window.KENV = {KEY,seed,load,save,uid,esc,pad,fmtDate,fmtTime,isoDay,stock,addMonths,nextDue,daysUntil,dueStatus,renewalStatus,alertItems,csvDownload,download,excelBlob,xlsx,$,$$,toast,option,nameOf,printTable,exportInventory,clone};
})();
