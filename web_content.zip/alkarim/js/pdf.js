/* Bengali-safe PDF via print dialog (works reliably for Unicode) */
function generatePDF({ title, subtitle, meta = [], tables = [], summary = [], signature = true }) {
  const s = APP.settings || {};
  const now = new Date().toLocaleString('bn-BD');
  const logoOrg = s.orgLogo ? `<img src="${s.orgLogo}" style="height:56px">` : '';
  const logoCo  = s.companyLogo ? `<img src="${s.companyLogo}" style="height:56px">` : '';

  const head = `
    <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:3px double #1e6f4c;padding-bottom:10px;margin-bottom:10px;">
      <div>${logoOrg}</div>
      <div style="text-align:center;flex:1">
        <h1 style="margin:0;color:#1e6f4c;font-size:20px">${s.orgName || 'এনাম ফিড পুকুর ম্যানেজমেন্ট'} পুকুর ব্যবস্থাপনা</h1>
        <div style="font-size:13px;color:#444">কোম্পানি: ${s.companyName || 'এনাম ফিড'}</div>
        <div style="font-size:12px;color:#666">ম্যানেজার: ${s.managerName || '-'} • পরিচালক: ${s.directorName || '-'} • মালিক: ${s.ownerName || '-'}</div>
        ${s.address ? `<div style="font-size:11px;color:#666">ঠিকানা: ${s.address} • মোবাইল: ${s.phone || '-'}</div>` : ''}
      </div>
      <div>${logoCo}</div>
    </div>`;

  const metaBox = meta.length ? `
    <table style="width:100%;font-size:12px;margin-bottom:12px;border-collapse:collapse">
      ${meta.map(m => `<tr><td style="padding:3px 6px;color:#555;width:150px">${m.label}</td>
        <td style="padding:3px 6px;font-weight:600">${m.value}</td></tr>`).join('')}
    </table>` : '';

  const tablesHTML = tables.map(t => {
    const cols = t.columns;
    const rows = t.rows.length ? t.rows.map(r =>
      `<tr>${cols.map(c => `<td style="padding:6px 8px;border:1px solid #ccc;text-align:${c.align||'left'}">${r[c.key]??''}</td>`).join('')}</tr>`
    ).join('') : `<tr><td colspan="${cols.length}" style="text-align:center;padding:14px;color:#888">কোনো তথ্য নেই</td></tr>`;
    return `
      <h3 style="margin:14px 0 6px;color:#1e6f4c;font-size:14px">${t.title}</h3>
      <table style="width:100%;border-collapse:collapse;font-size:12px">
        <thead><tr>${cols.map(c => `<th style="background:#1e6f4c;color:#fff;padding:7px 8px;border:1px solid #14503a;text-align:${c.align||'left'}">${c.label}</th>`).join('')}</tr></thead>
        <tbody>${rows}</tbody>
      </table>`;
  }).join('');

  const summaryHTML = summary.length ? `
    <div style="margin-top:14px;padding:10px 12px;background:#f0f7f2;border:1px solid #1e6f4c;border-radius:6px;font-size:13px">
      <strong style="color:#1e6f4c">সারাংশ:</strong>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:4px 20px;margin-top:6px">
        ${summary.map(x => `<div>${x.label}: <b>${x.value}</b></div>`).join('')}
      </div>
    </div>` : '';

  const sign = signature ? `
    <div style="margin-top:60px;display:flex;justify-content:space-between;font-size:12px">
      <div style="text-align:center;border-top:1px solid #333;padding-top:6px;min-width:180px">ম্যানেজার</div>
      <div style="text-align:center;border-top:1px solid #333;padding-top:6px;min-width:180px">পরিচালক</div>
      <div style="text-align:center;border-top:1px solid #333;padding-top:6px;min-width:180px">মালিক</div>
    </div>` : '';

  const html = `<!DOCTYPE html><html lang="bn"><head>
    <meta charset="UTF-8">
    <title>${title}</title>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
      body{font-family:'Hind Siliguri',sans-serif;color:#222;padding:22px;max-width:900px;margin:auto}
      h2{text-align:center;color:#1e6f4c;margin:8px 0 4px;font-size:17px}
      .subt{text-align:center;font-size:12px;color:#666;margin-bottom:14px}
      @media print{ @page{size:A4;margin:12mm} body{padding:0} }
    </style></head><body>
    ${head}
    <h2>${title}</h2>
    <div class="subt">${subtitle || ''} • রিপোর্টের তারিখ: ${now}</div>
    ${metaBox}
    ${tablesHTML}
    ${summaryHTML}
    ${sign}
    <script>window.onload=()=>{setTimeout(()=>window.print(),300)}<\/script>
    </body></html>`;

  const w = window.open('', '_blank');
  w.document.write(html);
  w.document.close();
}
