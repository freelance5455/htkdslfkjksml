// ==== Firebase Configuration ====
// Firebase Console → Project Settings → Web App থেকে কপি করে বসান
const firebaseConfig = {
  apiKey: "AIzaSyAYRIyFb8YSq64B1Uj0G5zEpYKAi26qBhc",
  authDomain: "anamfeed-60489.firebaseapp.com",
  projectId: "anamfeed-60489",
  storageBucket: "anamfeed-60489.firebasestorage.app",
  messagingSenderId: "702206479094",
  appId: "1:702206479094:web:121387a7791f79c1ec7ad7"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
db.settings({ ignoreUndefinedProperties: true });

// Collections
const COL = {
  settings:  db.collection('settings'),
  ponds:     db.collection('ponds'),
  foods:     db.collection('foodEntries'),
  medicines: db.collection('medicines'),
  purchases: db.collection('fishPurchases'),
  sales:     db.collection('fishSales'),
  persons:   db.collection('persons'),
  logs:      db.collection('activityLogs'),
  backups:   db.collection('backups')
};

// Activity log helper
async function logActivity(action, details) {
  const u = auth.currentUser;
  await COL.logs.add({
    action, details,
    uid: u ? u.uid : 'anon',
    email: u ? u.email : 'anon',
    time: firebase.firestore.FieldValue.serverTimestamp()
  });
}
