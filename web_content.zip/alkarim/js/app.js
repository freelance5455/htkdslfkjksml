/* =========================================================
   এনাম ফিড পুকুর ম্যানেজমেন্ট — Main Application
   ========================================================= */
const APP = {
  user: null,
  settings: {},
  ponds: [],
  foods: [],
  medicines: [],
  purchases: [],
  sales: [],
  persons: [],
  route: 'dashboard',
  charts: {}
};

const $  = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const fmt = n => (Number(n)||0).toLocaleString('bn-BD', {maximumFractionDigits:2});
const today = () => new Date().toISOString().slice(0,10);
const esc = s => (s??'').toString().replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num = v => { const n = parseFloat(v); return isNaN(n) ? 0 : n; };

/* ---------- AUTH ---------- */
auth.onAuthStateChanged(async u => {
  if (!u) return location.href = 'index.html';
  APP.user = u;
  $('#userChip').textContent = (u.displayName || u.email || 'ইউজার').split(' ')[0];
  await loadSettings();
  await loadAll();
  route(location.hash.replace('#','') || 'dashboard');
});

$('#logoutBtn').onclick = async () => { await auth.signOut(); location.href='index.html'; };

/* ---------- SETTINGS ---------- */
async function loadSettings() {
  const doc = await COL.settings.doc('org').get();
  APP.settings = doc.exists ? doc.data() : {
    orgName:'এনাম ফিড পুকুর ম্যানেজমেন্ট', companyName:'এনাম ফিড',
    managerName:'', directorName:'', ownerName:''
  };
  $('#brandOrgName').textContent = APP.settings.orgName || 'এনাম ফিড পুকুর ম্যানেজমেন্ট';
  $('#brandCompany').textContent = APP.settings.companyName || 'এনাম ফিড';
}
async function saveSettings(data) {
  await COL.settings.doc('org').set(data, { merge:true });
  APP.settings = { ...APP.settings, ...data };
  $('#brandOrgName').textContent = APP.settings.orgName;
  $('#brandCompany').textContent = APP.settings.companyName;
  logActivity('settings-update', data);
}

/* ---------- LOAD ALL ---------- */
async function loadAll() {
  const [p,f,m,pu,s,pe] = await Promise.all([
    COL.ponds.get(), COL.foods.orderBy('date','desc').get(),
    COL.medicines.orderBy('date','desc').get(),
    COL.purchases.orderBy('date','desc').get(),
    COL.sales.orderBy('date','desc').get(),
    COL.persons.get()
  ]);
  APP.ponds    = p.docs.map(d => ({ id:d.id, ...d.data() }));
  APP.foods    = f.docs.map(d => ({ id:d.id, ...d.data() }));
  APP.medicines= m.docs.map(d => ({ id:d.id, ...d.data() }));
  APP.purchases= pu.docs.map(d => ({ id:d.id, ...d.data() }));
  APP.sales    = s.docs.map(d => ({ id:d.id, ...d.data() }));
  APP.persons  = pe.docs.map(d => ({ id:d.id, ...d.data() }));
}

/* ---------- ROUTER ---------- */
function route(r) {
  APP.route = r;
  location.hash = r;
  $$('.nav a').forEach(a => a.classList.toggle('active', a.dataset.route===r));
  $$('.bottom-nav button').forEach(b => b.classList.toggle('active', b.dataset.route===r));
  $('#sidebar').classList.remove('open');
  const titles = { dashboard:'ড্যাশবোর্ড', ponds:'পুকুর', food:'খাদ্য যোগ', 'monthly-food':'মাসিক খাদ্য',
    medicine:'মেডিসিন', purchase:'মাছ ক্রয়', sale:'মাছ বিক্রি', sold:'বিক্রিত পুকুর',
    company:'এনাম ফিড হিসাব', finance:'আয়-ব্যয়', reports:'রিপোর্ট', management:'দায়িত্বশীল ব্যক্তিবর্গ',
    settings:'সেটিংস', 'pond-details':'পুকুরের বিস্তারিত' };
  $('#pageTitle').textContent = titles[r] || 'ড্যাশবোর্ড';
  const fn = ({ dashboard:renderDashboard, ponds:renderPonds, food:renderFood,
    'monthly-food':renderMonthlyFood, medicine:renderMedicine, purchase:renderPurchase,
    sale:renderSale, sold:renderSold, company:renderCompany, finance:renderFinance,
    reports:renderReports, management:renderManagement, settings:renderSettings,
    'pond-details':renderPondDetails })[r] || renderDashboard;
  fn();
}

$$('.nav a').forEach(a => a.onclick = () => route(a.dataset.route));
$$('.bottom-nav button').forEach(b => b.onclick = () => route(b.dataset.route));
$('#menuBtn').onclick = () => $('#sidebar').classList.toggle('open');
window.addEventListener('hashchange', () => {
  const r = location.hash.replace('#','');
  if (r && r !== APP.route) route(r);
});

/* ---------- THEME ---------- */
$('#themeBtn').onclick = () => {
  document.body.classList.toggle('dark');
  localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
  $('#themeBtn').textContent = document.body.classList.contains('dark') ? '☀️' : '🌙';
  Object.values(APP.charts).forEach(c => c && c.destroy());
  APP.charts = {};
  route(APP.route);
};
if (localStorage.getItem('theme') === 'dark') { document.body.classList.add('dark'); $('#themeBtn').textContent='☀️'; }

/* ---------- MODAL ---------- */
function openModal(html) {
  $('#modalBox').innerHTML = html;
  $('#modalWrap').classList.remove('hidden');
}
function closeModal() { $('#modalWrap').classList.add('hidden'); }
$('#modalWrap').onclick = e => { if (e.target.id==='modalWrap') closeModal(); };

/* =========================================================
   CALCULATIONS
   ========================================================= */
function calcPond(pondId) {
  const foods     = APP.foods.filter(x => x.pondId === pondId);
  const medicines = APP.medicines.filter(x => x.pondId === pondId);
  const purchases = APP.purchases.filter(x => x.pondId === pondId);
  const sales     = APP.sales.filter(x => x.pondId === pondId);

  const fFloatQty = foods.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalKg),0);
  const fSinkQty  = foods.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalKg),0);
  const fFloatCost= foods.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalCost),0);
  const fSinkCost = foods.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalCost),0);
  const medCost   = medicines.reduce((s,x)=>s+num(x.totalCost),0);
  const purCost   = purchases.reduce((s,x)=>s+num(x.totalCost),0);
  const saleTotal = sales.reduce((s,x)=>s+num(x.totalSale),0);
  const received  = sales.reduce((s,x)=>s+num(x.received),0);
  const due       = saleTotal - received;
  const salesOtherCost = sales.reduce((s,x)=>s+num(x.transport)+num(x.other),0);
  // Purchase totalCost already includes purchase transport/other; do not add it twice.
  const otherCost = salesOtherCost;

  const totalFood = fFloatQty + fSinkQty;
  const totalFoodCost = fFloatCost + fSinkCost;
  const totalCost = purCost + totalFoodCost + medCost + salesOtherCost;
  const profit = saleTotal - totalCost;

  return { foods, medicines, purchases, sales,
    fFloatQty, fSinkQty, totalFood, fFloatCost, fSinkCost, totalFoodCost,
    medCost, purCost, saleTotal, received, due, otherCost, totalCost, profit };
}

function calcAll() {
  const fFloatQty = APP.foods.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalKg),0);
  const fSinkQty  = APP.foods.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalKg),0);
  const fFloatCost= APP.foods.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalCost),0);
  const fSinkCost = APP.foods.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalCost),0);
  const medCost   = APP.medicines.reduce((s,x)=>s+num(x.totalCost),0);
  const purCost   = APP.purchases.reduce((s,x)=>s+num(x.totalCost),0);
  const salesOtherCost = APP.sales.reduce((s,x)=>s+num(x.transport)+num(x.other),0);
  const saleTotal = APP.sales.reduce((s,x)=>s+num(x.totalSale),0);
  const received  = APP.sales.reduce((s,x)=>s+num(x.received),0);
  const due       = saleTotal - received;
  const pondCount = APP.ponds.length;
  const activePonds = APP.ponds.filter(p => p.status !== 'closed').length;
  const closedPonds = APP.ponds.filter(p => p.status === 'closed').length;
  const totalFood = fFloatQty + fSinkQty;
  const totalFoodCost = fFloatCost + fSinkCost;
  const totalCost = purCost + totalFoodCost + medCost + salesOtherCost;
  const profit = saleTotal - totalCost;
  return { pondCount, activePonds, closedPonds, purCost, saleTotal, received, due,
    fFloatQty, fSinkQty, totalFood, fFloatCost, fSinkCost, totalFoodCost,
    medCost, salesOtherCost, totalCost, profit };
}

/* =========================================================
   DASHBOARD
   ========================================================= */
function renderDashboard() {
  const t = calcAll();
  const medQty = APP.medicines.reduce((s,x)=>s+num(x.quantity),0);

  const cards = [
    { cls:'green',  icon:'🌊', label:'মোট পুকুর',         value: fmt(t.pondCount) },
    { cls:'teal',   icon:'✅', label:'সক্রিয় পুকুর',       value: fmt(t.activePonds) },
    { cls:'amber',  icon:'📦', label:'বিক্রি সম্পন্ন',     value: fmt(t.closedPonds) },
    { cls:'blue',   icon:'🐟', label:'মোট মাছ ক্রয় খরচ',  value: '৳'+fmt(t.purCost) },
    { cls:'green',  icon:'💰', label:'মোট মাছ বিক্রি',     value: '৳'+fmt(t.saleTotal) },
    { cls:'purple', icon:'🍚', label:'মোট খাদ্য (কেজি)',  value: fmt(t.totalFood)+' কেজি' },
    { cls:'blue',   icon:'🌊', label:'ভাসমান খাদ্য',      value: fmt(t.fFloatQty)+' কেজি' },
    { cls:'teal',   icon:'⬇️', label:'ডুবন্ত খাদ্য',       value: fmt(t.fSinkQty)+' কেজি' },
    { cls:'amber',  icon:'💵', label:'ভাসমান খাদ্য খরচ',   value: '৳'+fmt(t.fFloatCost) },
    { cls:'amber',  icon:'💵', label:'ডুবন্ত খাদ্য খরচ',   value: '৳'+fmt(t.fSinkCost) },
    { cls:'red',    icon:'📉', label:'সর্বমোট খাদ্য খরচ',  value: '৳'+fmt(t.totalFoodCost) },
    { cls:'purple', icon:'💊', label:'মেডিসিন ব্যবহার',    value: fmt(medQty) },
    { cls:'red',    icon:'💊', label:'মেডিসিন খরচ',       value: '৳'+fmt(t.medCost) },
    { cls:'green',  icon:'📈', label:'মোট আদায়',          value: '৳'+fmt(t.received) },
    { cls:'red',    icon:'⏳', label:'মোট বকেয়া',         value: '৳'+fmt(t.due) },
    { cls:'red',    icon:'💸', label:'সর্বমোট খরচ',        value: '৳'+fmt(t.totalCost) },
    { cls: t.profit>=0?'green':'red', icon: t.profit>=0?'✅':'⚠️',
      label: t.profit>=0?'মোট লাভ':'মোট ক্ষতি',
      value: '৳'+fmt(Math.abs(t.profit)) }
  ];

  const html = `
    <div class="stats-grid">
      ${cards.map(c => `
        <div class="stat-card ${c.cls}">
          <div class="icon">${c.icon}</div>
          <div class="label">${c.label}</div>
          <div class="value">${c.value}</div>
        </div>`).join('')}
    </div>

    <div class="charts-grid">
      <div class="neu-card chart-card"><h4>দৈনিক খাদ্য ব্যবহার (শেষ ১০ দিন)</h4><canvas id="chDaily"></canvas></div>
      <div class="neu-card chart-card"><h4>ভাসমান বনাম ডুবন্ত খাদ্য</h4><canvas id="chType"></canvas></div>
      <div class="neu-card chart-card"><h4>মাসিক খাদ্য (কেজি)</h4><canvas id="chMonthly"></canvas></div>
      <div class="neu-card chart-card"><h4>পুকুরভিত্তিক খরচ</h4><canvas id="chPondCost"></canvas></div>
      <div class="neu-card chart-card"><h4>মাছ ক্রয় vs বিক্রয়</h4><canvas id="chPurSale"></canvas></div>
      <div class="neu-card chart-card"><h4>মাসিক লাভ / ক্ষতি</h4><canvas id="chProfit"></canvas></div>
    </div>
  `;
  $('#view').innerHTML = html;
  setTimeout(() => buildCharts(), 50);
}

function buildCharts() {
  // Daily feed (last 10 days)
  const days = [...Array(10)].map((_,i) => {
    const d = new Date(); d.setDate(d.getDate() - (9-i)); return d.toISOString().slice(0,10);
  });
  const dailyData = days.map(d => APP.foods.filter(f=>f.date===d).reduce((s,x)=>s+num(x.totalKg),0));
  APP.charts.daily && APP.charts.daily.destroy();
  APP.charts.daily = new Chart($('#chDaily'), {
    type:'line', data:{ labels: days.map(d=>d.slice(5)), datasets:[{ label:'কেজি', data:dailyData,
      borderColor:'#1e6f4c', backgroundColor:'rgba(30,111,76,.15)', fill:true, tension:.35 }] },
    options:{ responsive:true, plugins:{legend:{display:false}} }
  });

  // Type split
  const tf = APP.foods.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalKg),0);
  const ts = APP.foods.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalKg),0);
  APP.charts.type && APP.charts.type.destroy();
  APP.charts.type = new Chart($('#chType'), {
    type:'doughnut',
    data:{ labels:['ভাসমান','ডুবন্ত'], datasets:[{ data:[tf,ts], backgroundColor:['#1e6f4c','#f59e0b'] }] },
    options:{ responsive:true, plugins:{legend:{position:'bottom'}} }
  });

  // Monthly feed
  const mapM = {};
  APP.foods.forEach(f => { const k = (f.date||'').slice(0,7); mapM[k] = (mapM[k]||0) + num(f.totalKg); });
  const mKeys = Object.keys(mapM).sort().slice(-6);
  APP.charts.monthly && APP.charts.monthly.destroy();
  APP.charts.monthly = new Chart($('#chMonthly'), {
    type:'bar',
    data:{ labels:mKeys, datasets:[{ label:'কেজি', data:mKeys.map(k=>mapM[k]), backgroundColor:'#2d8f65' }] },
    options:{ responsive:true, plugins:{legend:{display:false}} }
  });

  // Pond cost
  const pondCost = APP.ponds.map(p => {
    const c = calcPond(p.id); return { name: p.name || '—', cost: c.totalCost };
  }).slice(0,8);
  APP.charts.pond && APP.charts.pond.destroy();
  APP.charts.pond = new Chart($('#chPondCost'), {
    type:'bar',
    data:{ labels:pondCost.map(x=>x.name), datasets:[{ label:'খরচ (৳)', data:pondCost.map(x=>x.cost), backgroundColor:'#2563eb' }] },
    options:{ responsive:true, plugins:{legend:{display:false}} }
  });

  // Purchase vs Sale
  const mp = {}; APP.purchases.forEach(x => { const k=(x.date||'').slice(0,7); mp[k]=(mp[k]||0)+num(x.totalCost); });
  const ms = {}; APP.sales.forEach(x => { const k=(x.date||'').slice(0,7); ms[k]=(ms[k]||0)+num(x.totalSale); });
  const keys = [...new Set([...Object.keys(mp),...Object.keys(ms)])].sort().slice(-6);
  APP.charts.ps && APP.charts.ps.destroy();
  APP.charts.ps = new Chart($('#chPurSale'), {
    type:'bar',
    data:{ labels:keys, datasets:[
      { label:'ক্রয়', data:keys.map(k=>mp[k]||0), backgroundColor:'#f59e0b' },
      { label:'বিক্রয়', data:keys.map(k=>ms[k]||0), backgroundColor:'#1e6f4c' }
    ]},
    options:{ responsive:true, plugins:{legend:{position:'bottom'}} }
  });

  // Monthly profit
  const profitByMonth = {};
  keys.forEach(k => {
    const foodCost = APP.foods.filter(f=>(f.date||'').startsWith(k)).reduce((s,x)=>s+num(x.totalCost),0);
    const medCost  = APP.medicines.filter(f=>(f.date||'').startsWith(k)).reduce((s,x)=>s+num(x.totalCost),0);
    const purCost  = APP.purchases.filter(f=>(f.date||'').startsWith(k)).reduce((s,x)=>s+num(x.totalCost),0);
    const saleTot  = ms[k] || 0;
    profitByMonth[k] = saleTot - (foodCost + medCost + purCost);
  });
  APP.charts.profit && APP.charts.profit.destroy();
  APP.charts.profit = new Chart($('#chProfit'), {
    type:'line',
    data:{ labels:keys, datasets:[{ label:'লাভ/ক্ষতি', data:keys.map(k=>profitByMonth[k]),
      borderColor:'#8b5cf6', backgroundColor:'rgba(139,92,246,.2)', fill:true, tension:.35 }] },
    options:{ responsive:true, plugins:{legend:{display:false}} }
  });
}

/* =========================================================
   PONDS
   ========================================================= */
function renderPonds() {
  const rows = APP.ponds.map(p => `
    <tr>
      <td><a href="#pond-details" onclick="openPond('${p.id}')"><b>${esc(p.name)}</b></a>
        <div style="font-size:11px;color:var(--muted)">ID: ${p.id.slice(0,6)}</div></td>
      <td>${esc(p.location||'—')}</td>
      <td>${fmt(p.area)} ${esc(p.areaUnit||'শতক')}</td>
      <td>${esc(p.fishSpecies||'—')}</td>
      <td>${fmt(p.initialFishCount)}</td>
      <td>${p.status==='closed'?'<span style="color:var(--danger)">বিক্রি সম্পন্ন</span>':'<span style="color:var(--primary)">সক্রিয়</span>'}</td>
      <td>${esc(p.releaseDate||'—')}</td>
      <td><div class="row-actions">
        <button class="mini-btn" onclick="openPond('${p.id}')">বিস্তারিত</button>
        <button class="mini-btn edit" onclick="editPond('${p.id}')">এডিট</button>
        <button class="mini-btn danger" onclick="deletePond('${p.id}')">ডিলিট</button>
      </div></td>
    </tr>`).join('') || `<tr><td colspan="8" class="empty">কোনো পুকুর যোগ করা হয়নি</td></tr>`;

  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>➕ নতুন পুকুর যোগ করুন</h3></div>
      <form id="pondForm">
        <div class="form-grid">
          <div class="input-group"><label>পুকুরের নাম*</label><input name="name" required></div>
          <div class="input-group"><label>অবস্থান</label><input name="location"></div>
          <div class="input-group"><label>আয়তন</label><input name="area" type="number" step="0.01"></div>
          <div class="input-group"><label>একক</label>
            <select name="areaUnit"><option>শতক</option><option>একর</option><option>বিঘা</option><option>বর্গফুট</option></select></div>
          <div class="input-group"><label>পুকুরের ধরন</label>
            <select name="pondType"><option>নতুন</option><option>পুরাতন</option><option>পুনঃখনন</option></select></div>
          <div class="input-group"><label>মাছ ছাড়ার তারিখ</label><input name="releaseDate" type="date"></div>
          <div class="input-group"><label>মাছের প্রজাতি</label><input name="fishSpecies" placeholder="রুই, কাতলা, তেলাপিয়া..."></div>
          <div class="input-group"><label>প্রাথমিক মাছের সংখ্যা</label><input name="initialFishCount" type="number"></div>
          <div class="input-group"><label>প্রাথমিক ওজন (কেজি)</label><input name="initialWeight" type="number" step="0.01"></div>
          <div class="input-group"><label>পুকুরের ছবি URL</label><input name="image" placeholder="https://..."></div>
          <div class="input-group full"><label>মন্তব্য</label><textarea name="note" rows="2"></textarea></div>
        </div>
        <button type="submit" class="btn btn-primary">💾 পুকুর সংরক্ষণ করুন</button>
      </form>
    </div>

    <div class="neu-card">
      <div class="section-head"><h3>📋 পুকুরের তালিকা</h3>
        <input class="neu-inset" id="pondSearch" placeholder="🔍 খুঁজুন..." style="max-width:220px"></div>
      <div class="table-wrap">
        <table class="data"><thead><tr>
          <th>নাম</th><th>অবস্থান</th><th>আয়তন</th><th>প্রজাতি</th><th>সংখ্যা</th><th>অবস্থা</th><th>ছাড়ার তারিখ</th><th></th>
        </tr></thead><tbody id="pondTableBody">${rows}</tbody></table>
      </div>
    </div>`;

  $('#pondForm').onsubmit = async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(e.target));
    await COL.ponds.add({ ...d, status:'active', createdBy:APP.user.uid,
      createdAt: firebase.firestore.FieldValue.serverTimestamp() });
    await logActivity('pond-add', d.name);
    await loadAll(); renderPonds();
  };

  $('#pondSearch').oninput = e => {
    const q = e.target.value.toLowerCase();
    $$('#pondTableBody tr').forEach(tr => tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none');
  };
}

async function deletePond(id) {
  if (!confirm('পুকুরটি ডিলিট করবেন? সংশ্লিষ্ট সব লেনদেনও থাকবে না।')) return;
  await COL.ponds.doc(id).delete();
  await logActivity('pond-delete', id);
  await loadAll(); route(APP.route);
}
window.deletePond = deletePond;

function editPond(id) {
  const p = APP.ponds.find(x=>x.id===id); if (!p) return;
  openModal(`
    <h3>পুকুর এডিট</h3>
    <form id="editPondForm">
      <div class="form-grid">
        <div class="input-group"><label>নাম</label><input name="name" value="${esc(p.name)}" required></div>
        <div class="input-group"><label>অবস্থান</label><input name="location" value="${esc(p.location||'')}"></div>
        <div class="input-group"><label>আয়তন</label><input name="area" type="number" value="${p.area||''}"></div>
        <div class="input-group"><label>প্রজাতি</label><input name="fishSpecies" value="${esc(p.fishSpecies||'')}"></div>
        <div class="input-group"><label>সংখ্যা</label><input name="initialFishCount" type="number" value="${p.initialFishCount||''}"></div>
        <div class="input-group"><label>অবস্থা</label>
          <select name="status"><option value="active" ${p.status!=='closed'?'selected':''}>সক্রিয়</option>
            <option value="closed" ${p.status==='closed'?'selected':''}>বিক্রি সম্পন্ন</option></select></div>
        <div class="input-group full"><label>মন্তব্য</label><textarea name="note">${esc(p.note||'')}</textarea></div>
      </div>
      <div class="modal-actions">
        <button type="button" class="neu-btn" onclick="closeModal()">বাতিল</button>
        <button type="submit" class="btn btn-primary">আপডেট</button>
      </div>
    </form>`);
  $('#editPondForm').onsubmit = async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(e.target));
    d.area = num(d.area); d.initialFishCount = num(d.initialFishCount);
    await COL.ponds.doc(id).update(d);
    await logActivity('pond-update', { id, ...d });
    closeModal(); await loadAll(); route(APP.route);
  };
}

/* =========================================================
   POND DETAILS
   ========================================================= */
window.openPond = id => {
  APP.currentPondId = id;
  route('pond-details');
};

function renderPondDetails() {
  const p = APP.ponds.find(x => x.id === APP.currentPondId);
  if (!p) { $('#view').innerHTML = '<div class="neu-card empty">পুকুর পাওয়া যায়নি</div>'; return; }
  const c = calcPond(p.id);

  const foods = c.foods.slice(0,10).map(f => `
    <tr><td>${f.date||''}</td><td>${esc(f.type)}</td><td>${esc(f.foodName||'')}</td>
    <td>${fmt(f.totalKg)}</td><td>৳${fmt(f.totalCost)}</td></tr>`).join('')
    || '<tr><td colspan="5" class="empty">কোনো খাদ্য নেই</td></tr>';

  const sales = c.sales.map(s => `
    <tr><td>${s.date||''}</td><td>${fmt(s.weightKg)}</td><td>৳${fmt(s.pricePerKg)}</td>
    <td>৳${fmt(s.totalSale)}</td><td>৳${fmt(s.received)}</td><td>৳${fmt(num(s.totalSale)-num(s.received))}</td></tr>`).join('')
    || '<tr><td colspan="6" class="empty">কোনো বিক্রি নেই</td></tr>';

  $('#view').innerHTML = `
    <div class="section-head">
      <h3>🌊 ${esc(p.name)} <span style="font-size:12px;color:var(--muted)">ID: ${p.id.slice(0,6)}</span></h3>
      <div style="display:flex;gap:8px">
        <button class="neu-btn" onclick="printPondReport('${p.id}')">🖨️ PDF</button>
        <button class="neu-btn" onclick="editPond('${p.id}')">✏️ এডিট</button>
      </div>
    </div>

    <div class="stats-grid">
      <div class="stat-card green"><div class="icon">🍚</div><div class="label">মোট খাদ্য</div><div class="value">${fmt(c.totalFood)} কেজি</div></div>
      <div class="stat-card blue"><div class="icon">🌊</div><div class="label">ভাসমান খাদ্য</div><div class="value">${fmt(c.fFloatQty)} কেজি</div></div>
      <div class="stat-card teal"><div class="icon">⬇️</div><div class="label">ডুবন্ত খাদ্য</div><div class="value">${fmt(c.fSinkQty)} কেজি</div></div>
      <div class="stat-card amber"><div class="icon">💵</div><div class="label">খাদ্য খরচ</div><div class="value">৳${fmt(c.totalFoodCost)}</div></div>
      <div class="stat-card purple"><div class="icon">💊</div><div class="label">মেডিসিন খরচ</div><div class="value">৳${fmt(c.medCost)}</div></div>
      <div class="stat-card red"><div class="icon">🐟</div><div class="label">মাছ ক্রয় খরচ</div><div class="value">৳${fmt(c.purCost)}</div></div>
      <div class="stat-card green"><div class="icon">💰</div><div class="label">মোট বিক্রয়</div><div class="value">৳${fmt(c.saleTotal)}</div></div>
      <div class="stat-card green"><div class="icon">📥</div><div class="label">মোট আদায়</div><div class="value">৳${fmt(c.received)}</div></div>
      <div class="stat-card red"><div class="icon">⏳</div><div class="label">বকেয়া</div><div class="value">৳${fmt(c.due)}</div></div>
      <div class="stat-card red"><div class="icon">💸</div><div class="label">সর্বমোট খরচ</div><div class="value">৳${fmt(c.totalCost)}</div></div>
      <div class="stat-card ${c.profit>=0?'green':'red'}"><div class="icon">${c.profit>=0?'📈':'📉'}</div>
        <div class="label">${c.profit>=0?'লাভ':'ক্ষতি'}</div>
        <div class="value">৳${fmt(Math.abs(c.profit))}</div></div>
    </div>

    <div class="charts-grid">
      <div class="neu-card chart-card"><h4>খাদ্য ধরন</h4><canvas id="chPondFeed"></canvas></div>
      <div class="neu-card chart-card"><h4>মাসিক খাদ্য</h4><canvas id="chPondMonthly"></canvas></div>
    </div>

    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>🍚 সাম্প্রতিক খাদ্য</h3></div>
      <div class="table-wrap"><table class="data">
        <thead><tr><th>তারিখ</th><th>ধরন</th><th>নাম</th><th>কেজি</th><th>খরচ</th></tr></thead>
        <tbody>${foods}</tbody></table></div>
    </div>

    <div class="neu-card">
      <div class="section-head"><h3>💰 বিক্রয়</h3></div>
      <div class="table-wrap"><table class="data">
        <thead><tr><th>তারিখ</th><th>কেজি</th><th>প্রতি কেজি</th><th>মোট</th><th>প্রাপ্ত</th><th>বকেয়া</th></tr></thead>
        <tbody>${sales}</tbody></table></div>
    </div>`;

  setTimeout(() => {
    new Chart($('#chPondFeed'), { type:'doughnut',
      data:{ labels:['ভাসমান','ডুবন্ত'], datasets:[{ data:[c.fFloatQty, c.fSinkQty], backgroundColor:['#1e6f4c','#f59e0b'] }] },
      options:{ plugins:{legend:{position:'bottom'}} } });
    const mm = {};
    c.foods.forEach(f => { const k=(f.date||'').slice(0,7); mm[k]=(mm[k]||0)+num(f.totalKg); });
    const kk = Object.keys(mm).sort().slice(-6);
    new Chart($('#chPondMonthly'), { type:'bar',
      data:{ labels:kk, datasets:[{ label:'কেজি', data:kk.map(k=>mm[k]), backgroundColor:'#2d8f65' }] },
      options:{ plugins:{legend:{display:false}} } });
  }, 50);
}

function printPondReport(id) {
  const p = APP.ponds.find(x => x.id === id); const c = calcPond(id);
  generatePDF({
    title: `পুকুরের সম্পূর্ণ হিসাব — ${p.name}`,
    subtitle: `অবস্থান: ${p.location||'-'} • প্রজাতি: ${p.fishSpecies||'-'}`,
    meta: [
      { label:'পুকুর ID', value: p.id.slice(0,8) },
      { label:'মাছ ছাড়ার তারিখ', value: p.releaseDate || '-' },
      { label:'আয়তন', value: `${fmt(p.area)} ${p.areaUnit||''}` }
    ],
    tables: [
      { title:'খাদ্যের হিসাব', columns:[
          {key:'k',label:'বিবরণ'},{key:'v',label:'পরিমাণ',align:'right'}],
        rows:[
          { k:'ভাসমান খাদ্য (কেজি)', v:fmt(c.fFloatQty) },
          { k:'ডুবন্ত খাদ্য (কেজি)', v:fmt(c.fSinkQty) },
          { k:'মোট খাদ্য (কেজি)', v:fmt(c.totalFood) },
          { k:'ভাসমান খাদ্য খরচ', v:'৳'+fmt(c.fFloatCost) },
          { k:'ডুবন্ত খাদ্য খরচ', v:'৳'+fmt(c.fSinkCost) },
          { k:'মোট খাদ্য খরচ', v:'৳'+fmt(c.totalFoodCost) }
        ]},
      { title:'মাছ ক্রয়/বিক্রয় ও অন্যান্য', columns:[
          {key:'k',label:'বিবরণ'},{key:'v',label:'পরিমাণ',align:'right'}],
        rows:[
          { k:'মাছ ক্রয় খরচ', v:'৳'+fmt(c.purCost) },
          { k:'মেডিসিন খরচ', v:'৳'+fmt(c.medCost) },
          { k:'পরিবহন ও অন্যান্য', v:'৳'+fmt(c.otherCost) },
          { k:'মোট বিক্রয়', v:'৳'+fmt(c.saleTotal) },
          { k:'মোট আদায়', v:'৳'+fmt(c.received) },
          { k:'মোট বকেয়া', v:'৳'+fmt(c.due) },
          { k:'সর্বমোট খরচ', v:'৳'+fmt(c.totalCost) }
        ]},
      { title:'খাদ্যের বিস্তারিত', columns:[
          {key:'date',label:'তারিখ'},{key:'type',label:'ধরন'},{key:'name',label:'নাম'},
          {key:'kg',label:'কেজি',align:'right'},{key:'cost',label:'খরচ',align:'right'}],
        rows: c.foods.map(f => ({ date:f.date||'', type:f.type||'', name:f.foodName||'', kg:fmt(f.totalKg), cost:'৳'+fmt(f.totalCost) })) },
      { title:'মাছ বিক্রি', columns:[
          {key:'date',label:'তারিখ'},{key:'kg',label:'কেজি',align:'right'},
          {key:'price',label:'প্রতি কেজি',align:'right'},{key:'total',label:'মোট',align:'right'},
          {key:'recv',label:'প্রাপ্ত',align:'right'},{key:'due',label:'বকেয়া',align:'right'}],
        rows: c.sales.map(s => ({ date:s.date||'', kg:fmt(s.weightKg), price:'৳'+fmt(s.pricePerKg),
          total:'৳'+fmt(s.totalSale), recv:'৳'+fmt(s.received), due:'৳'+fmt(num(s.totalSale)-num(s.received)) })) }
    ],
    summary: [
      { label:'সর্বমোট খরচ', value:'৳'+fmt(c.totalCost) },
      { label:'মোট আয়', value:'৳'+fmt(c.saleTotal) },
      { label: c.profit>=0?'নিট লাভ':'নিট ক্ষতি', value:'৳'+fmt(Math.abs(c.profit)) }
    ]
  });
}

/* =========================================================
   FOOD
   ========================================================= */
function renderFood() {
  const pondOpts = APP.ponds.filter(p => p.status !== 'closed')
    .map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('')
    || '<option value="">— পুকুর নেই —</option>';

  const rows = APP.foods.slice(0,100).map(f => {
    const pond = APP.ponds.find(p => p.id===f.pondId);
    return `<tr>
      <td>${f.date||''}</td>
      <td>${esc(pond?.name||'—')}</td>
      <td>${esc(f.type||'')}</td>
      <td>${esc(f.foodName||'')}</td>
      <td>${esc(f.company||'এনাম ফিড')}</td>
      <td>${fmt(f.bagCount)}</td>
      <td>${fmt(f.bagWeight)}</td>
      <td>${fmt(f.totalKg)}</td>
      <td>৳${fmt(f.totalCost)}</td>
      <td><div class="row-actions">
        <button class="mini-btn edit" onclick="editFood('${f.id}')">এডিট</button>
        <button class="mini-btn danger" onclick="delDoc('foodEntries','${f.id}')">ডিলিট</button>
      </div></td>
    </tr>`;
  }).join('') || '<tr><td colspan="10" class="empty">কোনো খাদ্য যোগ করা হয়নি</td></tr>';

  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>🍚 আজকের খাদ্য যোগ</h3></div>
      <form id="foodForm">
        <div class="form-grid">
          <div class="input-group"><label>পুকুর*</label><select name="pondId" required>${pondOpts}</select></div>
          <div class="input-group"><label>তারিখ*</label><input name="date" type="date" value="${today()}" required></div>
          <div class="input-group"><label>কোম্পানি</label><input name="company" value="${esc(APP.settings.companyName||'এনাম ফিড')}"></div>
          <div class="input-group"><label>খাদ্যের ধরন*</label>
            <select name="type" required><option value="ভাসমান">ভাসমান (Floating)</option>
              <option value="ডুবন্ত">ডুবন্ত (Sinking)</option></select></div>
          <div class="input-group"><label>খাদ্যের নাম</label><input name="foodName" placeholder="যেমন: নিউ কেডা ২৮%"></div>
          <div class="input-group"><label>খাদ্যের কোড</label><input name="foodCode"></div>
          <div class="input-group"><label>প্রতি বস্তার ওজন (কেজি)*</label><input name="bagWeight" type="number" step="0.01" value="25" required></div>
          <div class="input-group"><label>বস্তার সংখ্যা*</label><input name="bagCount" type="number" required></div>
          <div class="input-group"><label>মূল্য পদ্ধতি*</label>
            <select name="priceMode" id="priceMode">
              <option value="kg">প্রতি কেজি দর</option>
              <option value="bag">প্রতি বস্তা দর</option>
            </select></div>
          <div class="input-group"><label>দর (৳)*</label><input name="rate" type="number" step="0.01" required></div>
          <div class="input-group"><label>সরবরাহকারী</label><input name="supplier"></div>
          <div class="input-group"><label>ম্যানেজারের নাম</label><input name="manager" value="${esc(APP.settings.managerName||'')}"></div>
          <div class="input-group full"><label>মন্তব্য</label><textarea name="note" rows="2"></textarea></div>
        </div>
        <div class="neu-inset" style="margin-bottom:14px">
          মোট পরিমাণ: <b id="foodTotalKg">0</b> কেজি &nbsp; | &nbsp;
          মোট টাকা: <b id="foodTotalCost">৳0</b>
        </div>
        <button type="submit" class="btn btn-primary">💾 খাদ্য সংরক্ষণ</button>
      </form>
    </div>

    <div class="neu-card">
      <div class="section-head"><h3>📋 খাদ্যের তালিকা</h3></div>
      <div class="table-wrap"><table class="data"><thead><tr>
        <th>তারিখ</th><th>পুকুর</th><th>ধরন</th><th>নাম</th><th>কোম্পানি</th>
        <th>বস্তা</th><th>প্রতি বস্তা</th><th>মোট কেজি</th><th>মোট ৳</th><th></th>
      </tr></thead><tbody>${rows}</tbody></table></div>
    </div>`;

  const form = $('#foodForm');
  const recalc = () => {
    const d = Object.fromEntries(new FormData(form));
    const kg = num(d.bagWeight) * num(d.bagCount);
    const cost = d.priceMode==='kg' ? kg * num(d.rate) : num(d.bagCount) * num(d.rate);
    $('#foodTotalKg').textContent = fmt(kg);
    $('#foodTotalCost').textContent = '৳'+fmt(cost);
  };
  form.oninput = recalc;
  form.onchange = recalc;
  recalc();

  form.onsubmit = async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(form));
    d.bagWeight = num(d.bagWeight); d.bagCount = num(d.bagCount); d.rate = num(d.rate);
    d.totalKg = d.bagWeight * d.bagCount;
    d.totalCost = d.priceMode==='kg' ? d.totalKg * d.rate : d.bagCount * d.rate;
    d.pricePerKg = d.totalKg ? d.totalCost/d.totalKg : 0;
    d.pricePerBag = d.bagCount ? d.totalCost/d.bagCount : 0;
    d.createdBy = APP.user.uid;
    d.createdAt = firebase.firestore.FieldValue.serverTimestamp();
    await COL.foods.add(d);
    await logActivity('food-add', { pondId:d.pondId, kg:d.totalKg });
    await loadAll(); renderFood();
  };
}

function editFood(id) {
  const f = APP.foods.find(x=>x.id===id); if (!f) return;
  const pondOpts = APP.ponds.map(p => `<option value="${p.id}" ${p.id===f.pondId?'selected':''}>${esc(p.name)}</option>`).join('');
  openModal(`
    <h3>খাদ্য এডিট</h3>
    <form id="editFoodForm">
      <div class="form-grid">
        <div class="input-group"><label>পুকুর</label><select name="pondId">${pondOpts}</select></div>
        <div class="input-group"><label>তারিখ</label><input name="date" type="date" value="${f.date||''}"></div>
        <div class="input-group"><label>ধরন</label>
          <select name="type"><option ${f.type==='ভাসমান'?'selected':''}>ভাসমান</option>
            <option ${f.type==='ডুবন্ত'?'selected':''}>ডুবন্ত</option></select></div>
        <div class="input-group"><label>নাম</label><input name="foodName" value="${esc(f.foodName||'')}"></div>
        <div class="input-group"><label>প্রতি বস্তা ওজন</label><input name="bagWeight" type="number" value="${f.bagWeight||0}"></div>
        <div class="input-group"><label>বস্তা সংখ্যা</label><input name="bagCount" type="number" value="${f.bagCount||0}"></div>
        <div class="input-group"><label>প্রতি কেজি দর</label><input name="pricePerKg" type="number" step="0.01" value="${f.pricePerKg||0}"></div>
      </div>
      <div class="modal-actions">
        <button type="button" class="neu-btn" onclick="closeModal()">বাতিল</button>
        <button type="submit" class="btn btn-primary">আপডেট</button>
      </div>
    </form>`);
  $('#editFoodForm').onsubmit = async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(e.target));
    d.bagWeight = num(d.bagWeight); d.bagCount = num(d.bagCount); d.pricePerKg = num(d.pricePerKg);
    d.totalKg = d.bagWeight * d.bagCount;
    d.totalCost = d.totalKg * d.pricePerKg;
    await COL.foods.doc(id).update(d);
    await logActivity('food-update', id);
    closeModal(); await loadAll(); route(APP.route);
  };
}

async function delDoc(coll, id) {
  if (!confirm('ডিলিট করবেন?')) return;
  await COL[coll === 'foodEntries' ? 'foods' :
            coll === 'medicines' ? 'medicines' :
            coll === 'fishPurchases' ? 'purchases' :
            coll === 'fishSales' ? 'sales' : coll].doc(id).delete();
  await logActivity('delete', { coll, id });
  await loadAll(); route(APP.route);
}
window.delDoc = delDoc;

/* =========================================================
   MONTHLY FOOD
   ========================================================= */
function renderMonthlyFood() {
  const now = new Date();
  const def = now.toISOString().slice(0,7);
  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>📅 মাসিক খাদ্য হিসাব</h3></div>
      <div class="form-grid">
        <div class="input-group"><label>মাস</label><input type="month" id="mFilter" value="${def}"></div>
        <div class="input-group"><label>পুকুর</label>
          <select id="mPond"><option value="">সব পুকুর</option>
            ${APP.ponds.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div>
      </div>
      <button class="neu-btn" id="mBtn">🔍 হিসাব দেখুন</button>
    </div>
    <div id="mResult"></div>`;

  const run = () => {
    const month = $('#mFilter').value;
    const pondId = $('#mPond').value;
    let rows = APP.foods.filter(f => (f.date||'').startsWith(month));
    if (pondId) rows = rows.filter(f => f.pondId === pondId);

    const tf = rows.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalKg),0);
    const ts = rows.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalKg),0);
    const cf = rows.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalCost),0);
    const cs = rows.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalCost),0);

    const html = `
      <div class="neu-card" style="margin-bottom:14px">
        <div class="summary-row">
          <div class="summary-pill">ভাসমান: <span>${fmt(tf)} কেজি</span></div>
          <div class="summary-pill">ডুবন্ত: <span>${fmt(ts)} কেজি</span></div>
          <div class="summary-pill">মোট: <span>${fmt(tf+ts)} কেজি</span></div>
          <div class="summary-pill">ভাসমান খরচ: <span>৳${fmt(cf)}</span></div>
          <div class="summary-pill">ডুবন্ত খরচ: <span>৳${fmt(cs)}</span></div>
          <div class="summary-pill">সর্বমোট খরচ: <span>৳${fmt(cf+cs)}</span></div>
        </div>
      </div>
      <div class="neu-card">
        <div class="table-wrap"><table class="data"><thead><tr>
          <th>তারিখ</th><th>পুকুর</th><th>ধরন</th><th>নাম</th>
          <th>কেজি</th><th>খরচ</th>
        </tr></thead><tbody>
        ${rows.map(f => {
          const p = APP.ponds.find(x=>x.id===f.pondId);
          return `<tr><td>${f.date||''}</td><td>${esc(p?.name||'—')}</td>
            <td>${esc(f.type||'')}</td><td>${esc(f.foodName||'')}</td>
            <td>${fmt(f.totalKg)}</td><td>৳${fmt(f.totalCost)}</td></tr>`;
        }).join('') || '<tr><td colspan="6" class="empty">এই মাসে কোনো খাদ্য নেই</td></tr>'}
        </tbody></table></div>
      </div>`;
    $('#mResult').innerHTML = html;
  };
  $('#mBtn').onclick = run;
  run();
}

/* =========================================================
   MEDICINE
   ========================================================= */
function renderMedicine() {
  const pondOpts = APP.ponds.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('')
    || '<option value="">— পুকুর নেই —</option>';
  const rows = APP.medicines.map(m => {
    const p = APP.ponds.find(x=>x.id===m.pondId);
    return `<tr>
      <td>${m.date||''}</td><td>${esc(p?.name||'—')}</td>
      <td>${esc(m.name||'')}</td><td>${esc(m.company||'')}</td>
      <td>${fmt(m.quantity)} ${esc(m.unit||'')}</td>
      <td>৳${fmt(m.pricePerUnit)}</td><td>৳${fmt(m.totalCost)}</td>
      <td>${esc(m.reason||'')}</td>
      <td><div class="row-actions">
        <button class="mini-btn danger" onclick="delDoc('medicines','${m.id}')">ডিলিট</button>
      </div></td></tr>`;
  }).join('') || '<tr><td colspan="9" class="empty">কোনো মেডিসিন নেই</td></tr>';

  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>💊 মেডিসিন যোগ</h3></div>
      <form id="medForm">
        <div class="form-grid">
          <div class="input-group"><label>পুকুর*</label><select name="pondId" required>${pondOpts}</select></div>
          <div class="input-group"><label>তারিখ*</label><input name="date" type="date" value="${today()}" required></div>
          <div class="input-group"><label>মেডিসিনের নাম*</label><input name="name" required></div>
          <div class="input-group"><label>কোম্পানি</label><input name="company"></div>
          <div class="input-group"><label>পরিমাণ*</label><input name="quantity" type="number" step="0.01" required></div>
          <div class="input-group"><label>একক</label>
            <select name="unit"><option>মিলি</option><option>গ্রাম</option><option>কেজি</option><option>প্যাকেট</option><option>বোতল</option></select></div>
          <div class="input-group"><label>প্রতি একক দাম*</label><input name="pricePerUnit" type="number" step="0.01" required></div>
          <div class="input-group full"><label>ব্যবহারের কারণ</label><input name="reason"></div>
          <div class="input-group"><label>ম্যানেজার</label><input name="manager" value="${esc(APP.settings.managerName||'')}"></div>
          <div class="input-group full"><label>মন্তব্য</label><textarea name="note" rows="2"></textarea></div>
        </div>
        <div class="neu-inset" style="margin-bottom:14px">মোট খরচ: <b id="medTotal">৳0</b></div>
        <button type="submit" class="btn btn-primary">💾 সংরক্ষণ</button>
      </form>
    </div>
    <div class="neu-card">
      <div class="section-head"><h3>📋 মেডিসিনের তালিকা</h3></div>
      <div class="table-wrap"><table class="data"><thead><tr>
        <th>তারিখ</th><th>পুকুর</th><th>নাম</th><th>কোম্পানি</th>
        <th>পরিমাণ</th><th>দর</th><th>খরচ</th><th>কারণ</th><th></th>
      </tr></thead><tbody>${rows}</tbody></table></div>
    </div>`;

  const form = $('#medForm');
  form.oninput = () => {
    const d = Object.fromEntries(new FormData(form));
    $('#medTotal').textContent = '৳' + fmt(num(d.quantity) * num(d.pricePerUnit));
  };
  form.onsubmit = async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(form));
    d.quantity = num(d.quantity); d.pricePerUnit = num(d.pricePerUnit);
    d.totalCost = d.quantity * d.pricePerUnit;
    d.createdBy = APP.user.uid;
    d.createdAt = firebase.firestore.FieldValue.serverTimestamp();
    await COL.medicines.add(d);
    await logActivity('medicine-add', d.name);
    await loadAll(); renderMedicine();
  };
}

/* =========================================================
   FISH PURCHASE
   ========================================================= */
function renderPurchase() {
  const pondOpts = APP.ponds.filter(p=>p.status!=='closed').map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')
    || '<option value="">— পুকুর নেই —</option>';
  const rows = APP.purchases.map(x => {
    const p = APP.ponds.find(z=>z.id===x.pondId);
    return `<tr><td>${x.date||''}</td><td>${esc(p?.name||'—')}</td>
      <td>${esc(x.species||'')}</td><td>${fmt(x.count)}</td>
      <td>${fmt(x.weightKg)}</td><td>৳${fmt(x.pricePerKg)}</td>
      <td>৳${fmt(x.fishCost)}</td><td>৳${fmt(x.transport)}</td>
      <td>৳${fmt(x.totalCost)}</td><td>${esc(x.seller||'')}</td>
      <td><button class="mini-btn danger" onclick="delDoc('fishPurchases','${x.id}')">ডিলিট</button></td></tr>`;
  }).join('') || '<tr><td colspan="11" class="empty">কোনো ক্রয় নেই</td></tr>';

  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>🐠 মাছ ক্রয়</h3></div>
      <form id="purForm">
        <div class="form-grid">
          <div class="input-group"><label>পুকুর*</label><select name="pondId" required>${pondOpts}</select></div>
          <div class="input-group"><label>তারিখ*</label><input name="date" type="date" value="${today()}" required></div>
          <div class="input-group"><label>প্রজাতি</label><input name="species"></div>
          <div class="input-group"><label>সংখ্যা</label><input name="count" type="number"></div>
          <div class="input-group"><label>মোট ওজন (কেজি)*</label><input name="weightKg" type="number" step="0.01" required></div>
          <div class="input-group"><label>প্রতি কেজি দাম*</label><input name="pricePerKg" type="number" step="0.01" required></div>
          <div class="input-group"><label>পরিবহন খরচ</label><input name="transport" type="number" step="0.01" value="0"></div>
          <div class="input-group"><label>অন্যান্য খরচ</label><input name="other" type="number" step="0.01" value="0"></div>
          <div class="input-group"><label>বিক্রেতার নাম</label><input name="seller"></div>
          <div class="input-group"><label>মোবাইল</label><input name="mobile"></div>
          <div class="input-group"><label>ম্যানেজার</label><input name="manager" value="${esc(APP.settings.managerName||'')}"></div>
          <div class="input-group full"><label>মন্তব্য</label><textarea name="note" rows="2"></textarea></div>
        </div>
        <div class="neu-inset" style="margin-bottom:14px">
          মাছের দাম: <b id="purFishCost">৳0</b> &nbsp; | &nbsp;
          সর্বমোট: <b id="purTotal">৳0</b>
        </div>
        <button class="btn btn-primary">💾 সংরক্ষণ</button>
      </form>
    </div>
    <div class="neu-card">
      <div class="section-head"><h3>📋 ক্রয় তালিকা</h3></div>
      <div class="table-wrap"><table class="data"><thead><tr>
        <th>তারিখ</th><th>পুকুর</th><th>প্রজাতি</th><th>সংখ্যা</th><th>কেজি</th>
        <th>প্রতি কেজি</th><th>মাছের দাম</th><th>পরিবহন</th><th>মোট</th><th>বিক্রেতা</th><th></th>
      </tr></thead><tbody>${rows}</tbody></table></div>
    </div>`;

  const form = $('#purForm');
  form.oninput = () => {
    const d = Object.fromEntries(new FormData(form));
    const fish = num(d.weightKg) * num(d.pricePerKg);
    $('#purFishCost').textContent = '৳'+fmt(fish);
    $('#purTotal').textContent = '৳'+fmt(fish + num(d.transport) + num(d.other));
  };
  form.onsubmit = async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(form));
    ['count','weightKg','pricePerKg','transport','other'].forEach(k => d[k]=num(d[k]));
    d.fishCost = d.weightKg * d.pricePerKg;
    d.totalCost = d.fishCost + d.transport + d.other;
    d.createdBy = APP.user.uid;
    d.createdAt = firebase.firestore.FieldValue.serverTimestamp();
    await COL.purchases.add(d);
    await logActivity('purchase-add', d);
    await loadAll(); renderPurchase();
  };
}

/* =========================================================
   FISH SALE
   ========================================================= */
function renderSale() {
  const pondOpts = APP.ponds.filter(p=>p.status!=='closed').map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')
    || '<option value="">— পুকুর নেই —</option>';
  const rows = APP.sales.map(x => {
    const p = APP.ponds.find(z=>z.id===x.pondId);
    const due = num(x.totalSale) - num(x.received);
    return `<tr><td>${x.date||''}</td><td>${esc(p?.name||'—')}</td>
      <td>${esc(x.species||'')}</td><td>${fmt(x.weightKg)}</td>
      <td>৳${fmt(x.pricePerKg)}</td><td>৳${fmt(x.totalSale)}</td>
      <td>৳${fmt(x.received)}</td><td>৳${fmt(due)}</td>
      <td>${esc(x.buyer||'')}</td>
      <td><button class="mini-btn danger" onclick="delDoc('fishSales','${x.id}')">ডিলিট</button></td></tr>`;
  }).join('') || '<tr><td colspan="10" class="empty">কোনো বিক্রি নেই</td></tr>';

  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>💰 মাছ বিক্রি</h3></div>
      <form id="saleForm">
        <div class="form-grid">
          <div class="input-group"><label>পুকুর*</label><select name="pondId" required>${pondOpts}</select></div>
          <div class="input-group"><label>তারিখ*</label><input name="date" type="date" value="${today()}" required></div>
          <div class="input-group"><label>প্রজাতি</label><input name="species"></div>
          <div class="input-group"><label>বিক্রিত ওজন (কেজি)*</label><input name="weightKg" type="number" step="0.01" required></div>
          <div class="input-group"><label>প্রতি কেজি দাম*</label><input name="pricePerKg" type="number" step="0.01" required></div>
          <div class="input-group"><label>প্রাপ্ত টাকা*</label><input name="received" type="number" step="0.01" required></div>
          <div class="input-group"><label>ক্রেতার নাম</label><input name="buyer"></div>
          <div class="input-group"><label>মোবাইল</label><input name="mobile"></div>
          <div class="input-group"><label>পরিবহন খরচ</label><input name="transport" type="number" step="0.01" value="0"></div>
          <div class="input-group"><label>অন্যান্য খরচ</label><input name="other" type="number" step="0.01" value="0"></div>
          <div class="input-group"><label>পরিচালক/ম্যানেজার</label><input name="manager" value="${esc(APP.settings.managerName||'')}"></div>
          <div class="input-group full"><label>মন্তব্য</label><textarea name="note" rows="2"></textarea></div>
        </div>
        <div class="neu-inset" style="margin-bottom:14px">
          মোট বিক্রয়: <b id="saleTotal">৳0</b> &nbsp; | &nbsp;
          বকেয়া: <b id="saleDue">৳0</b>
        </div>
        <button class="btn btn-primary">💾 সংরক্ষণ</button>
      </form>
    </div>
    <div class="neu-card">
      <div class="section-head"><h3>📋 বিক্রয় তালিকা</h3></div>
      <div class="table-wrap"><table class="data"><thead><tr>
        <th>তারিখ</th><th>পুকুর</th><th>প্রজাতি</th><th>কেজি</th>
        <th>প্রতি কেজি</th><th>মোট</th><th>প্রাপ্ত</th><th>বকেয়া</th><th>ক্রেতা</th><th></th>
      </tr></thead><tbody>${rows}</tbody></table></div>
    </div>`;

  const form = $('#saleForm');
  form.oninput = () => {
    const d = Object.fromEntries(new FormData(form));
    const total = num(d.weightKg) * num(d.pricePerKg);
    $('#saleTotal').textContent = '৳'+fmt(total);
    $('#saleDue').textContent = '৳'+fmt(total - num(d.received));
  };
  form.onsubmit = async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(form));
    ['weightKg','pricePerKg','received','transport','other'].forEach(k=>d[k]=num(d[k]));
    d.totalSale = d.weightKg * d.pricePerKg;
    d.createdBy = APP.user.uid;
    d.createdAt = firebase.firestore.FieldValue.serverTimestamp();
    await COL.sales.add(d);
    await logActivity('sale-add', d);
    await loadAll(); renderSale();
  };
}

/* =========================================================
   SOLD PONDS
   ========================================================= */
function renderSold() {
  const closed = APP.ponds.filter(p => p.status === 'closed');
  $('#view').innerHTML = `
    <div class="section-head"><h3>📦 বিক্রিত পুকুর (${closed.length})</h3></div>
    ${closed.length ? closed.map(p => {
      const c = calcPond(p.id);
      return `<div class="neu-card" style="margin-bottom:14px">
        <div class="section-head">
          <h3>🌊 ${esc(p.name)} <small style="color:var(--muted);font-size:12px">ID: ${p.id.slice(0,6)}</small></h3>
          <div style="display:flex;gap:8px">
            <button class="neu-btn" onclick="printPondReport('${p.id}')">🖨️ PDF</button>
            <button class="neu-btn" onclick="reopenPond('${p.id}')">🔄 পুনরায় চালু</button>
          </div>
        </div>
        <div class="summary-row">
          <div class="summary-pill">ভাসমান: <span>${fmt(c.fFloatQty)} কেজি / ৳${fmt(c.fFloatCost)}</span></div>
          <div class="summary-pill">ডুবন্ত: <span>${fmt(c.fSinkQty)} কেজি / ৳${fmt(c.fSinkCost)}</span></div>
          <div class="summary-pill">খাদ্য মোট: <span>৳${fmt(c.totalFoodCost)}</span></div>
          <div class="summary-pill">মেডিসিন: <span>৳${fmt(c.medCost)}</span></div>
          <div class="summary-pill">ক্রয়: <span>৳${fmt(c.purCost)}</span></div>
          <div class="summary-pill">বিক্রয়: <span>৳${fmt(c.saleTotal)}</span></div>
          <div class="summary-pill">আদায়: <span>৳${fmt(c.received)}</span></div>
          <div class="summary-pill">বকেয়া: <span>৳${fmt(c.due)}</span></div>
          <div class="summary-pill">সর্বমোট খরচ: <span>৳${fmt(c.totalCost)}</span></div>
          <div class="summary-pill"><b>${c.profit>=0?'লাভ':'ক্ষতি'}: <span style="color:${c.profit>=0?'var(--primary)':'var(--danger)'}">৳${fmt(Math.abs(c.profit))}</span></b></div>
        </div>
      </div>`;
    }).join('') : '<div class="neu-card empty">এখনো কোনো পুকুর বিক্রি সম্পন্ন হয়নি</div>'}`;
}
async function reopenPond(id) {
  if (!confirm('পুকুরটি পুনরায় চালু করবেন?')) return;
  await COL.ponds.doc(id).update({ status:'active' });
  await logActivity('pond-reopen', id);
  await loadAll(); route(APP.route);
}
window.reopenPond = reopenPond;

/* =========================================================
   COMPANY (Enam Feed)
   ========================================================= */
function renderCompany() {
  const feeds = APP.foods;
  const tf = feeds.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalKg),0);
  const ts = feeds.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalKg),0);
  const cf = feeds.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalCost),0);
  const cs = feeds.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalCost),0);
  const byName = {};
  feeds.forEach(f => {
    const k = (f.foodName||'অজানা') + ' • ' + (f.type||'');
    byName[k] = byName[k] || { kg:0, cost:0 };
    byName[k].kg += num(f.totalKg); byName[k].cost += num(f.totalCost);
  });
  const s = APP.settings;

  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:16px">
      <div class="section-head"><h3>🏢 ${esc(s.companyName||'এনাম ফিড')} — কোম্পানি হিসাব</h3></div>
      <div class="summary-row">
        <div class="summary-pill">মালিক: <span>${esc(s.ownerName||'—')}</span></div>
        <div class="summary-pill">পরিচালক: <span>${esc(s.directorName||'—')}</span></div>
        <div class="summary-pill">ম্যানেজার: <span>${esc(s.managerName||'—')}</span></div>
      </div>
    </div>

    <div class="stats-grid">
      <div class="stat-card green"><div class="icon">🌊</div><div class="label">ভাসমান মোট</div><div class="value">${fmt(tf)} কেজি</div></div>
      <div class="stat-card teal"><div class="icon">⬇️</div><div class="label">ডুবন্ত মোট</div><div class="value">${fmt(ts)} কেজি</div></div>
      <div class="stat-card purple"><div class="icon">🍚</div><div class="label">সর্বমোট খাদ্য</div><div class="value">${fmt(tf+ts)} কেজি</div></div>
      <div class="stat-card amber"><div class="icon">💵</div><div class="label">ভাসমান খরচ</div><div class="value">৳${fmt(cf)}</div></div>
      <div class="stat-card amber"><div class="icon">💵</div><div class="label">ডুবন্ত খরচ</div><div class="value">৳${fmt(cs)}</div></div>
      <div class="stat-card red"><div class="icon">📉</div><div class="label">সর্বমোট খরচ</div><div class="value">৳${fmt(cf+cs)}</div></div>
    </div>

    <div class="neu-card">
      <div class="section-head"><h3>খাদ্যের নাম অনুযায়ী</h3></div>
      <div class="table-wrap"><table class="data"><thead><tr>
        <th>খাদ্যের নাম • ধরন</th><th>মোট কেজি</th><th>মোট খরচ</th>
      </tr></thead><tbody>
        ${Object.entries(byName).map(([k,v]) =>
          `<tr><td>${esc(k)}</td><td>${fmt(v.kg)}</td><td>৳${fmt(v.cost)}</td></tr>`
        ).join('') || '<tr><td colspan="3" class="empty">কোনো ডাটা নেই</td></tr>'}
      </tbody></table></div>
    </div>`;
}

/* =========================================================
   FINANCE
   ========================================================= */
function renderFinance() {
  const t = calcAll();
  const rows = [...APP.foods.map(x=>({date:x.date, type:'খাদ্য', desc:x.foodName||x.type, cost:num(x.totalCost), income:0})),
    ...APP.medicines.map(x=>({date:x.date, type:'মেডিসিন', desc:x.name, cost:num(x.totalCost), income:0})),
    ...APP.purchases.map(x=>({date:x.date, type:'মাছ ক্রয়', desc:x.species||'', cost:num(x.totalCost), income:0})),
    ...APP.sales.map(x=>({date:x.date, type:'মাছ বিক্রি', desc:x.species||'', cost:0, income:num(x.totalSale)}))
  ].sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,150);

  $('#view').innerHTML = `
    <div class="stats-grid" style="margin-bottom:20px">
      <div class="stat-card green"><div class="icon">📈</div><div class="label">মোট আয়</div><div class="value">৳${fmt(t.saleTotal)}</div></div>
      <div class="stat-card red"><div class="icon">📉</div><div class="label">মোট ব্যয়</div><div class="value">৳${fmt(t.totalCost)}</div></div>
      <div class="stat-card ${t.profit>=0?'green':'red'}"><div class="icon">💼</div>
        <div class="label">${t.profit>=0?'লাভ':'ক্ষতি'}</div>
        <div class="value">৳${fmt(Math.abs(t.profit))}</div></div>
      <div class="stat-card green"><div class="icon">📥</div><div class="label">আদায়</div><div class="value">৳${fmt(t.received)}</div></div>
      <div class="stat-card red"><div class="icon">⏳</div><div class="label">বকেয়া</div><div class="value">৳${fmt(t.due)}</div></div>
    </div>
    <div class="neu-card">
      <div class="section-head"><h3>📋 সাম্প্রতিক লেনদেন</h3></div>
      <div class="table-wrap"><table class="data"><thead><tr>
        <th>তারিখ</th><th>ধরন</th><th>বিবরণ</th><th>আয়</th><th>ব্যয়</th>
      </tr></thead><tbody>
        ${rows.map(r => `<tr><td>${r.date||''}</td><td>${esc(r.type)}</td>
          <td>${esc(r.desc)}</td>
          <td style="color:var(--primary)">${r.income?'৳'+fmt(r.income):'—'}</td>
          <td style="color:var(--danger)">${r.cost?'৳'+fmt(r.cost):'—'}</td></tr>`).join('')
        || '<tr><td colspan="5" class="empty">কোনো লেনদেন নেই</td></tr>'}
      </tbody></table></div>
    </div>`;
}

/* =========================================================
   REPORTS
   ========================================================= */
function renderReports() {
  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>📄 রিপোর্ট ও PDF ডাউনলোড</h3></div>
      <div class="form-grid">
        <div class="input-group"><label>শুরুর তারিখ</label>
          <input type="date" id="repFrom" value="${new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0,10)}"></div>
        <div class="input-group"><label>শেষ তারিখ</label><input type="date" id="repTo" value="${today()}"></div>
        <div class="input-group"><label>পুকুর</label>
          <select id="repPond"><option value="">সব পুকুর</option>
            ${APP.ponds.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div>
      </div>
    </div>

    <div class="stats-grid">
      ${reportButtons()}
    </div>`;

  $('#view').onclick = e => {
    const btn = e.target.closest('[data-report]');
    if (!btn) return;
    buildReport(btn.dataset.report);
  };
}
function reportButtons() {
  const list = [
    ['all-ponds','🌊 সকল পুকুরের তালিকা'],
    ['daily-food','🍚 দৈনিক খাদ্য রিপোর্ট'],
    ['monthly-food','📅 মাসিক খাদ্য রিপোর্ট'],
    ['float-food','🌊 ভাসমান খাদ্য রিপোর্ট'],
    ['sink-food','⬇️ ডুবন্ত খাদ্য রিপোর্ট'],
    ['all-food','🍚 সর্বমোট খাদ্য রিপোর্ট'],
    ['medicine','💊 মেডিসিন রিপোর্ট'],
    ['purchase','🐠 মাছ ক্রয় রিপোর্ট'],
    ['sale','💰 মাছ বিক্রি রিপোর্ট'],
    ['sold','📦 বিক্রিত পুকুরের রিপোর্ট'],
    ['monthly-fin','📊 মাসিক আয়-ব্যয়'],
    ['yearly-fin','📆 বার্ষিক আয়-ব্যয়'],
    ['profit','💼 লাভ-ক্ষতি রিপোর্ট'],
    ['company','🏢 এনাম ফিড রিপোর্ট'],
    ['management','👥 দায়িত্বশীল ব্যক্তিদের রিপোর্ট'],
    ['all-txn','📋 সকল লেনদেন রিপোর্ট']
  ];
  return list.map(([k,l]) => `<button class="neu-card" style="text-align:left;cursor:pointer;border:none;font-family:inherit;color:inherit" data-report="${k}">
    <div style="font-size:26px;margin-bottom:6px">${l.split(' ')[0]}</div>
    <div style="font-weight:600;font-size:14px">${l.split(' ').slice(1).join(' ')}</div>
  </button>`).join('');
}
function buildReport(kind) {
  const from = $('#repFrom').value;
  const to = $('#repTo').value;
  const pondId = $('#repPond').value;
  const within = d => (!from || d>=from) && (!to || d<=to);
  const byPond = f => !pondId || f.pondId === pondId;

  const fFoods = APP.foods.filter(f => within(f.date) && byPond(f));
  const fMeds  = APP.medicines.filter(f => within(f.date) && byPond(f));
  const fPur   = APP.purchases.filter(f => within(f.date) && byPond(f));
  const fSale  = APP.sales.filter(f => within(f.date) && byPond(f));
  const pondName = pondId ? (APP.ponds.find(p=>p.id===pondId)?.name||'—') : 'সব পুকুর';

  const meta = [
    { label:'সময়কাল', value: `${from} → ${to}` },
    { label:'পুকুর', value: pondName }
  ];

  let title = '', tables = [], summary = [];

  switch(kind) {
    case 'all-ponds':
      title = 'সকল পুকুরের তালিকা';
      tables = [{ title:'পুকুর তালিকা', columns:[
        {key:'name',label:'নাম'},{key:'loc',label:'অবস্থান'},{key:'area',label:'আয়তন'},
        {key:'species',label:'প্রজাতি'},{key:'status',label:'অবস্থা'}],
        rows: APP.ponds.map(p => ({ name:p.name, loc:p.location||'', area:`${fmt(p.area)} ${p.areaUnit||''}`,
          species:p.fishSpecies||'', status:p.status==='closed'?'বিক্রি সম্পন্ন':'সক্রিয়' })) }];
      break;
    case 'daily-food':
      title = 'দৈনিক খাদ্য রিপোর্ট';
      tables = [{ title:'খাদ্য বিবরণ', columns:[
        {key:'date',label:'তারিখ'},{key:'pond',label:'পুকুর'},{key:'type',label:'ধরন'},
        {key:'name',label:'নাম'},{key:'kg',label:'কেজি',align:'right'},{key:'cost',label:'খরচ',align:'right'}],
        rows: fFoods.map(f => { const p = APP.ponds.find(x=>x.id===f.pondId);
          return { date:f.date, pond:p?.name||'—', type:f.type, name:f.foodName||'',
            kg:fmt(f.totalKg), cost:'৳'+fmt(f.totalCost) }; }) }];
      summary = [
        { label:'ভাসমান', value: fmt(fFoods.filter(f=>f.type==='ভাসমান').reduce((s,x)=>s+num(x.totalKg),0))+' কেজি' },
        { label:'ডুবন্ত',  value: fmt(fFoods.filter(f=>f.type==='ডুবন্ত').reduce((s,x)=>s+num(x.totalKg),0))+' কেজি' },
        { label:'মোট খরচ', value:'৳'+fmt(fFoods.reduce((s,x)=>s+num(x.totalCost),0)) }
      ];
      break;
    case 'monthly-food':
    case 'float-food':
    case 'sink-food':
    case 'all-food': {
      title = kind==='float-food' ? 'ভাসমান খাদ্য রিপোর্ট' :
              kind==='sink-food'  ? 'ডুবন্ত খাদ্য রিপোর্ট' :
              kind==='all-food'   ? 'সর্বমোট খাদ্য রিপোর্ট' : 'মাসিক খাদ্য রিপোর্ট';
      const filtered = kind==='float-food' ? fFoods.filter(f=>f.type==='ভাসমান') :
                      kind==='sink-food'  ? fFoods.filter(f=>f.type==='ডুবন্ত') : fFoods;
      tables = [{ title:'খাদ্য', columns:[
        {key:'date',label:'তারিখ'},{key:'pond',label:'পুকুর'},{key:'type',label:'ধরন'},
        {key:'name',label:'নাম'},{key:'kg',label:'কেজি',align:'right'},{key:'cost',label:'খরচ',align:'right'}],
        rows: filtered.map(f => { const p = APP.ponds.find(x=>x.id===f.pondId);
          return { date:f.date, pond:p?.name||'—', type:f.type, name:f.foodName||'',
            kg:fmt(f.totalKg), cost:'৳'+fmt(f.totalCost) }; }) }];
      summary = [{ label:'মোট পরিমাণ', value: fmt(filtered.reduce((s,x)=>s+num(x.totalKg),0))+' কেজি' },
                 { label:'মোট খরচ', value:'৳'+fmt(filtered.reduce((s,x)=>s+num(x.totalCost),0)) }];
      break;
    }
    case 'medicine':
      title = 'মেডিসিন রিপোর্ট';
      tables = [{ title:'মেডিসিন', columns:[
        {key:'date',label:'তারিখ'},{key:'pond',label:'পুকুর'},{key:'name',label:'নাম'},
        {key:'qty',label:'পরিমাণ',align:'right'},{key:'cost',label:'খরচ',align:'right'}],
        rows: fMeds.map(m => { const p = APP.ponds.find(x=>x.id===m.pondId);
          return { date:m.date, pond:p?.name||'—', name:m.name, qty:`${fmt(m.quantity)} ${m.unit||''}`,
            cost:'৳'+fmt(m.totalCost) }; }) }];
      summary = [{ label:'মোট খরচ', value:'৳'+fmt(fMeds.reduce((s,x)=>s+num(x.totalCost),0)) }];
      break;
    case 'purchase':
      title = 'মাছ ক্রয় রিপোর্ট';
      tables = [{ title:'ক্রয়', columns:[
        {key:'date',label:'তারিখ'},{key:'pond',label:'পুকুর'},{key:'species',label:'প্রজাতি'},
        {key:'kg',label:'কেজি',align:'right'},{key:'cost',label:'মোট',align:'right'},{key:'seller',label:'বিক্রেতা'}],
        rows: fPur.map(x => { const p = APP.ponds.find(z=>z.id===x.pondId);
          return { date:x.date, pond:p?.name||'—', species:x.species||'', kg:fmt(x.weightKg),
            cost:'৳'+fmt(x.totalCost), seller:x.seller||'' }; }) }];
      summary = [{ label:'মোট ক্রয় খরচ', value:'৳'+fmt(fPur.reduce((s,x)=>s+num(x.totalCost),0)) }];
      break;
    case 'sale':
      title = 'মাছ বিক্রি রিপোর্ট';
      tables = [{ title:'বিক্রয়', columns:[
        {key:'date',label:'তারিখ'},{key:'pond',label:'পুকুর'},{key:'species',label:'প্রজাতি'},
        {key:'kg',label:'কেজি',align:'right'},{key:'total',label:'মোট',align:'right'},
        {key:'recv',label:'প্রাপ্ত',align:'right'},{key:'due',label:'বকেয়া',align:'right'},{key:'buyer',label:'ক্রেতা'}],
        rows: fSale.map(x => { const p = APP.ponds.find(z=>z.id===x.pondId);
          return { date:x.date, pond:p?.name||'—', species:x.species||'', kg:fmt(x.weightKg),
            total:'৳'+fmt(x.totalSale), recv:'৳'+fmt(x.received),
            due:'৳'+fmt(num(x.totalSale)-num(x.received)), buyer:x.buyer||'' }; }) }];
      summary = [
        { label:'মোট বিক্রয়', value:'৳'+fmt(fSale.reduce((s,x)=>s+num(x.totalSale),0)) },
        { label:'মোট আদায়',  value:'৳'+fmt(fSale.reduce((s,x)=>s+num(x.received),0)) },
        { label:'মোট বকেয়া', value:'৳'+fmt(fSale.reduce((s,x)=>s+num(x.totalSale)-num(x.received),0)) }
      ];
      break;
    case 'sold': {
      title = 'বিক্রিত পুকুরের রিপোর্ট';
      const closed = APP.ponds.filter(p => p.status==='closed');
      tables = closed.map(p => {
        const c = calcPond(p.id);
        return { title: `পুকুর: ${p.name}`, columns:[
          {key:'k',label:'বিবরণ'},{key:'v',label:'মান',align:'right'}],
          rows:[
            { k:'ভাসমান খাদ্য', v:`${fmt(c.fFloatQty)} কেজি` },
            { k:'ডুবন্ত খাদ্য', v:`${fmt(c.fSinkQty)} কেজি` },
            { k:'খাদ্য খরচ', v:'৳'+fmt(c.totalFoodCost) },
            { k:'মেডিসিন খরচ', v:'৳'+fmt(c.medCost) },
            { k:'ক্রয় খরচ', v:'৳'+fmt(c.purCost) },
            { k:'মোট বিক্রয়', v:'৳'+fmt(c.saleTotal) },
            { k:'মোট আদায়', v:'৳'+fmt(c.received) },
            { k:'বকেয়া', v:'৳'+fmt(c.due) },
            { k:'সর্বমোট খরচ', v:'৳'+fmt(c.totalCost) },
            { k: c.profit>=0?'নিট লাভ':'নিট ক্ষতি', v:'৳'+fmt(Math.abs(c.profit)) }
          ] };
      });
      break;
    }
    case 'monthly-fin':
    case 'yearly-fin':
    case 'profit': {
      title = kind==='yearly-fin'?'বার্ষিক আয়-ব্যয় রিপোর্ট': kind==='profit'?'লাভ-ক্ষতি রিপোর্ট':'মাসিক আয়-ব্যয় রিপোর্ট';
      const mapM = {};
      fFoods.forEach(f => { const k=(f.date||'').slice(0,7); mapM[k]=mapM[k]||{ inc:0,exp:0 }; mapM[k].exp += num(f.totalCost); });
      fMeds.forEach(f => { const k=(f.date||'').slice(0,7); mapM[k]=mapM[k]||{ inc:0,exp:0 }; mapM[k].exp += num(f.totalCost); });
      fPur.forEach(f  => { const k=(f.date||'').slice(0,7); mapM[k]=mapM[k]||{ inc:0,exp:0 }; mapM[k].exp += num(f.totalCost); });
      fSale.forEach(f => { const k=(f.date||'').slice(0,7); mapM[k]=mapM[k]||{ inc:0,exp:0 }; mapM[k].inc += num(f.totalSale); });
      tables = [{ title:'মাসভিত্তিক', columns:[
        {key:'m',label:'মাস'},{key:'inc',label:'আয়',align:'right'},
        {key:'exp',label:'ব্যয়',align:'right'},{key:'profit',label:'লাভ/ক্ষতি',align:'right'}],
        rows: Object.entries(mapM).sort().map(([m,v]) => ({ m, inc:'৳'+fmt(v.inc), exp:'৳'+fmt(v.exp),
          profit:'৳'+fmt(v.inc-v.exp) })) }];
      break;
    }
    case 'company':
      title = 'এনাম ফিড কোম্পানির রিপোর্ট';
      tables = [{ title:'খাদ্যের হিসাব', columns:[
        {key:'name',label:'নাম'},{key:'type',label:'ধরন'},{key:'kg',label:'কেজি',align:'right'},{key:'cost',label:'খরচ',align:'right'}],
        rows: fFoods.map(f => ({ name:f.foodName||'', type:f.type||'', kg:fmt(f.totalKg), cost:'৳'+fmt(f.totalCost) })) }];
      break;
    case 'management':
      title = 'দায়িত্বশীল ব্যক্তিদের রিপোর্ট';
      tables = [{ title:'ব্যক্তিবর্গ', columns:[
        {key:'name',label:'নাম'},{key:'role',label:'পদবি'},{key:'phone',label:'মোবাইল'},{key:'addr',label:'ঠিকানা'}],
        rows: APP.persons.map(p => ({ name:p.name||'', role:p.role||'', phone:p.phone||'', addr:p.address||'' })) }];
      break;
    case 'all-txn': {
      title = 'সকল লেনদেনের রিপোর্ট';
      const all = [
        ...fFoods.map(x=>({date:x.date, type:'খাদ্য', desc:x.foodName||x.type, amt:'৳'+fmt(x.totalCost), sign:'-'})),
        ...fMeds.map(x=>({date:x.date, type:'মেডিসিন', desc:x.name, amt:'৳'+fmt(x.totalCost), sign:'-'})),
        ...fPur.map(x=>({date:x.date, type:'ক্রয়', desc:x.species||'', amt:'৳'+fmt(x.totalCost), sign:'-'})),
        ...fSale.map(x=>({date:x.date, type:'বিক্রি', desc:x.species||'', amt:'৳'+fmt(x.totalSale), sign:'+' }))
      ].sort((a,b)=>(b.date||'').localeCompare(a.date||''));
      tables = [{ title:'লেনদেন', columns:[
        {key:'date',label:'তারিখ'},{key:'type',label:'ধরন'},{key:'desc',label:'বিবরণ'},
        {key:'sign',label:'',align:'center'},{key:'amt',label:'পরিমাণ',align:'right'}],
        rows: all.map(x => ({...x, sign:x.sign==='+'?'আয়':'ব্যয়'})) }];
      break;
    }
  }

  generatePDF({ title, subtitle:`সময়কাল: ${from} → ${to}`, meta, tables, summary });
}

/* =========================================================
   MANAGEMENT (Persons)
   ========================================================= */
function renderManagement() {
  const rows = APP.persons.map(p => `
    <tr><td>${esc(p.name)}</td><td>${esc(p.role||'')}</td><td>${esc(p.phone||'')}</td>
    <td>${esc(p.address||'')}</td>
    <td><div class="row-actions">
      <button class="mini-btn danger" onclick="delPerson('${p.id}')">ডিলিট</button>
    </div></td></tr>`).join('') || '<tr><td colspan="5" class="empty">কোনো ব্যক্তি নেই</td></tr>';

  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>👥 নতুন ব্যক্তি যোগ</h3></div>
      <form id="personForm">
        <div class="form-grid">
          <div class="input-group"><label>নাম*</label><input name="name" required></div>
          <div class="input-group"><label>পদবি</label>
            <select name="role"><option>মালিক</option><option>পরিচালক</option><option>ম্যানেজার</option>
              <option>হিসাবরক্ষক</option><option>খাদ্য সরবরাহকারী</option><option>কর্মকর্তা</option></select></div>
          <div class="input-group"><label>মোবাইল</label><input name="phone"></div>
          <div class="input-group"><label>ইমেইল</label><input name="email" type="email"></div>
          <div class="input-group full"><label>ঠিকানা</label><input name="address"></div>
          <div class="input-group"><label>ছবি URL</label><input name="photo"></div>
        </div>
        <button class="btn btn-primary">💾 যোগ করুন</button>
      </form>
    </div>
    <div class="neu-card">
      <div class="section-head"><h3>📋 ব্যক্তিবর্গ</h3></div>
      <div class="table-wrap"><table class="data"><thead><tr>
        <th>নাম</th><th>পদবি</th><th>মোবাইল</th><th>ঠিকানা</th><th></th>
      </tr></thead><tbody>${rows}</tbody></table></div>
    </div>`;

  $('#personForm').onsubmit = async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(e.target));
    d.createdAt = firebase.firestore.FieldValue.serverTimestamp();
    await COL.persons.add(d);
    await logActivity('person-add', d.name);
    await loadAll(); renderManagement();
  };
}
async function delPerson(id) {
  if (!confirm('ডিলিট করবেন?')) return;
  await COL.persons.doc(id).delete();
  await logActivity('person-delete', id);
  await loadAll(); renderManagement();
}
window.delPerson = delPerson;

/* =========================================================
   SETTINGS
   ========================================================= */
function renderSettings() {
  const s = APP.settings;
  $('#view').innerHTML = `
    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>🏛️ প্রতিষ্ঠান ও কোম্পানির তথ্য</h3></div>
      <form id="settingsForm">
        <div class="form-grid">
          <div class="input-group"><label>প্রতিষ্ঠানের নাম</label>
            <input name="orgName" value="${esc(s.orgName||'এনাম ফিড পুকুর ম্যানেজমেন্ট')}"></div>
          <div class="input-group"><label>প্রতিষ্ঠানের লোগো URL</label>
            <input name="orgLogo" value="${esc(s.orgLogo||'')}" placeholder="https://..."></div>
          <div class="input-group"><label>কোম্পানির নাম</label>
            <input name="companyName" value="${esc(s.companyName||'এনাম ফিড')}"></div>
          <div class="input-group"><label>কোম্পানির লোগো URL</label>
            <input name="companyLogo" value="${esc(s.companyLogo||'')}" placeholder="https://..."></div>
          <div class="input-group full"><label>ঠিকানা</label>
            <input name="address" value="${esc(s.address||'')}"></div>
          <div class="input-group"><label>যোগাযোগ নম্বর</label>
            <input name="phone" value="${esc(s.phone||'')}"></div>
          <div class="input-group"><label>মালিকের নাম</label>
            <input name="ownerName" value="${esc(s.ownerName||'')}"></div>
          <div class="input-group"><label>পরিচালকের নাম</label>
            <input name="directorName" value="${esc(s.directorName||'')}"></div>
          <div class="input-group"><label>ম্যানেজারের নাম</label>
            <input name="managerName" value="${esc(s.managerName||'')}"></div>
          <div class="input-group"><label>ম্যানেজারের মোবাইল</label>
            <input name="managerPhone" value="${esc(s.managerPhone||'')}"></div>
        </div>
        <button class="btn btn-primary">💾 সংরক্ষণ করুন</button>
      </form>
    </div>

    <div class="neu-card" style="margin-bottom:18px">
      <div class="section-head"><h3>🔐 নিরাপত্তা ও Backup</h3></div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="neu-btn" id="backupBtn">⬇️ ডাটা Backup</button>
        <button class="neu-btn" id="restoreBtn">⬆️ Restore</button>
        <input type="file" id="restoreFile" accept=".json" class="hidden">
      </div>
    </div>`;

  $('#settingsForm').onsubmit = async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(e.target));
    await saveSettings(d);
    alert('সেটিংস সংরক্ষিত হয়েছে ✅');
    route('dashboard');
  };

  $('#backupBtn').onclick = async () => {
    const data = { settings: APP.settings, ponds: APP.ponds, foods: APP.foods,
      medicines: APP.medicines, purchases: APP.purchases, sales: APP.sales, persons: APP.persons,
      exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type:'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `alkarim-backup-${today()}.json`;
    a.click();
  };
  $('#restoreBtn').onclick = () => $('#restoreFile').click();
  $('#restoreFile').onchange = async e => {
    const file = e.target.files[0]; if (!file) return;
    if (!confirm('Restore করলে বর্তমান ডাটার সাথে merge হবে। চালিয়ে যাবেন?')) return;
    const data = JSON.parse(await file.text());
    const batches = ['ponds','foods','medicines','purchases','sales','persons'];
    for (const coll of batches) {
      for (const item of (data[coll]||[])) {
        const { id, ...rest } = item;
        await COL[coll].add(rest);
      }
    }
    if (data.settings) await saveSettings(data.settings);
    await loadAll(); alert('Restore সম্পন্ন ✅'); route('dashboard');
  };
}

/* =========================================================
   INIT
   ========================================================= */
window.closeModal = closeModal;
window.editPond = editPond;
window.editFood = editFood;
window.calcPond = calcPond;
window.printPondReport = printPondReport;
window.APP = APP;

/* PWA */
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('service-worker.js').catch(()=>{});
}
