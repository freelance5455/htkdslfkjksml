# এনাম ফিড পুকুর ম্যানেজমেন্ট — পুকুর ব্যবস্থাপনা সিস্টেম

## 🚀 সেটআপ (Firebase)

1. https://console.firebase.google.com এ একটি নতুন প্রজেক্ট খুলুন।
2. **Authentication** → Sign-in method → **Email/Password** এবং **Google** চালু করুন।
3. **Firestore Database** তৈরি করুন (Production mode)।
4. Project Settings → Web App যোগ করে `firebaseConfig` কপি করুন।
5. `js/firebase-config.js` ফাইলে কনফিগ বসান।
6. Firestore-এ একটি ডকুমেন্ট তৈরি করুন:
   - Collection: `settings`
   - Document ID: `org`
   - Fields: `orgName` = `এনাম ফিড পুকুর ম্যানেজমেন্ট`, `companyName` = `এনাম ফিড`

## 🔒 Security Rules (V2 জরুরি)

প্রথমে `SETUP-SECURITY-BN.txt` পড়ুন। `firestore.rules`-এ `REPLACE_WITH_ADMIN_UID`-এর জায়গায় Firebase Authentication থেকে পাওয়া অনুমোদিত UID বসিয়ে তারপর Firebase Console → Firestore → Rules-এ Publish করুন। UID না বসালে ডেটাবেস অ্যাক্সেস বন্ধ থাকবে।

## ⚠️ Firebase কনফিগারেশন

`js/firebase-config.js`-এর `YOUR_...` মানগুলো আপনার Firebase Web App-এর আসল কনফিগ দিয়ে বদলাতে হবে।

## 🌐 Netlify Deploy

1. Netlify-তে গিয়ে **Deploy manually**।
2. পুরো ফোল্ডার zip আকারে ড্র্যাগ করে ছেড়ে দিন।
3. Site URL পেয়ে যাবেন।

## 📱 PWA ইনস্টল

Chrome/Safari-তে সাইট খুলে **Add to Home Screen** করলেই অ্যাপ হিসেবে কাজ করবে।

## ✅ যা কাজ করে

- Email/Password + Google লগইন
- পুকুর CRUD (Active/Closed)
- খাদ্য (ভাসমান / ডুবন্ত) — অটো হিসাব
- মেডিসিন, মাছ ক্রয়, মাছ বিক্রি
- প্রতিটি পুকুরের আলাদা হিসাব
- বিক্রিত পুকুরের রিপোর্ট
- এনাম ফিড কোম্পানির হিসাব
- ড্যাশবোর্ডে ৬টি চার্ট
- আয়-ব্যয়, লাভ-ক্ষতি
- PDF (বাংলা ফন্ট সহ) প্রিন্ট/ডাউনলোড
- Backup / Restore (JSON)
- Dark / Light Mode
- Responsive (Mobile-first)

## ⚠️ বাংলা ফন্ট PDF-এ

PDF জেনারেট হয় **প্রিন্ট ডায়ালগের** মাধ্যমে, তাই ব্রাউজার যে ফন্ট সাপোর্ট করে (Hind Siliguri) সেই ফন্টেই বাংলা সঠিক দেখায় — "Save as PDF" দিয়ে নামান।
