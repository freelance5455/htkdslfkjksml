# مدیریت کارکرد نیروها — پروژه اندروید

## ساخت APK
1. Android Studio (Koala یا جدیدتر) را باز کنید → **Open** → پوشه‌ی `CrewPro`.
2. صبر کنید Gradle Sync تمام شود (اینترنت لازم است).
3. برای نسخه تست: **Build ▸ Build APK(s)** → فایل در `app/build/outputs/apk/debug/app-debug.apk`.
4. برای انتشار: **Build ▸ Generate Signed App Bundle / APK**.

## تغییراتی که برای اندروید در HTML داده شد (app/src/main/assets/index.html)
| قابلیت | روش |
|---|---|
| خروجی Excel و فایل پشتیبان | منوی اشتراک‌گذاری اندروید (FileProvider) |
| ذخیره PDF | پنجره‌ی چاپ بومی اندروید ← Save as PDF |
| ارسال واتساپ / پیامک / تلگرام | Intent بومی |
| اشتراک‌گذاری متن | Share Sheet |
| بازیابی از فایل پشتیبان | File Chooser |
| دکمه‌ی Back | بستن پنجره‌ها ← بازگشت به «ثبت روزانه» ← خروج |
| داده‌ها | localStorage + کپی دوم در حافظه‌ی خصوصی برنامه |
| Google Drive | ورود بومی گوگل (بدون نیاز به Client ID داخل برنامه) |

## تنظیم Google Drive (یک‌بار)
در Google Cloud Console:
1. پروژه بسازید و **Google Drive API** را Enable کنید.
2. OAuth consent screen ← ایمیل خودتان را در Test users اضافه کنید.
3. Credentials ← Create OAuth client ID ← نوع **Android**
   - Package name: `com.crewpro.app`
   - SHA-1: خروجی `./gradlew signingReport` (برای debug و برای release جداگانه)
بدون این مرحله بقیه‌ی برنامه کار می‌کند و فقط پشتیبان Drive خطا می‌دهد.
