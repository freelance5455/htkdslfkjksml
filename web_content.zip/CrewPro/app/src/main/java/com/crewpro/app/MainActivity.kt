package com.crewpro.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            fileCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            )
            fileCallback = null
        }

    private val authLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            try {
                val res = Identity.getAuthorizationClient(this)
                    .getAuthorizationResultFromIntent(r.data)
                deliverToken(res.accessToken, null)
            } catch (e: Exception) {
                deliverToken(null, "popup_closed")
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF0B3D82.toInt()) }
        web = WebView(this)
        root.addView(
            web,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)

        // Edge-to-edge (Android 15+): keep the page clear of status/navigation bars and keyboard
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars: Insets = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            textZoom = 100
            setSupportZoom(false)
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val u = request.url
                return if (u.host == WebViewAssetLoader.DEFAULT_DOMAIN) false
                else { openExternal(u.toString()); true }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    fileChooser.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.__back?window.__back():false)") { r ->
                    if (r != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState == null) {
            web.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        // make sure the latest data is flushed to disk
        web.evaluateJavascript(
            "try{window.Android&&Android.persist(localStorage.getItem('crew')||'')}catch(e){}", null
        )
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "برنامه‌ی مناسبی برای باز کردن این لینک نصب نیست", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deliverToken(token: String?, error: String?) {
        val t = JSONObject.quote(token ?: "")
        val e = if (error == null) "null" else JSONObject.quote(error)
        runOnUiThread {
            web.evaluateJavascript("window.__gTok&&window.__gTok($t,$e)", null)
        }
    }

    inner class Bridge {

        private val stateFile get() = File(filesDir, "state.json")

        /** Save a generated file (xlsx / json) and open the Android share sheet. */
        @JavascriptInterface
        fun shareFile(name: String, mime: String, base64: String) {
            try {
                val dir = File(cacheDir, "exports").apply { mkdirs() }
                val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val f = File(dir, safe)
                f.writeBytes(Base64.decode(base64, Base64.DEFAULT))
                val uri = FileProvider.getUriForFile(
                    this@MainActivity, "$packageName.fileprovider", f
                )
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { startActivity(Intent.createChooser(send, name)) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "ذخیره‌ی فایل ناموفق بود", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            runOnUiThread { startActivity(Intent.createChooser(send, null)) }
        }

        /** WhatsApp / SMS / Telegram links. */
        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread { openExternal(url) }
        }

        /** Native print dialog -> "Save as PDF". Uses the page's @media print CSS. */
        @JavascriptInterface
        fun printPage(title: String) {
            runOnUiThread {
                val pm = getSystemService(PRINT_SERVICE) as PrintManager
                val job = title.ifBlank { "report" }
                pm.print(
                    job,
                    web.createPrintDocumentAdapter(job),
                    PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                        .build()
                )
            }
        }

        /** Mirror of localStorage data kept in app-private storage (extra safety). */
        @JavascriptInterface
        fun persist(json: String) {
            if (json.isEmpty()) return
            try {
                val tmp = File(filesDir, "state.json.tmp")
                tmp.writeText(json)
                tmp.renameTo(stateFile)
            } catch (_: Exception) {
            }
        }

        @JavascriptInterface
        fun loadState(): String =
            try { if (stateFile.exists()) stateFile.readText() else "" } catch (_: Exception) { "" }

        /** Google Drive access token via Google Play services (no Client ID needed in the page). */
        @JavascriptInterface
        fun requestDriveToken() {
            runOnUiThread {
                val req = AuthorizationRequest.builder()
                    .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.file")))
                    .build()
                Identity.getAuthorizationClient(this@MainActivity)
                    .authorize(req)
                    .addOnSuccessListener { res ->
                        val pi = res.pendingIntent
                        if (res.hasResolution() && pi != null) {
                            authLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                        } else {
                            deliverToken(res.accessToken, null)
                        }
                    }
                    .addOnFailureListener { deliverToken(null, it.message ?: "auth_failed") }
            }
        }
    }
}
