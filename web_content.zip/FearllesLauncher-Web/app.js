const $=id=>document.getElementById(id);
const apps=[["☎","Телефон"],["◎","Браузер"],["▧","Галерея"],["♫","Музыка"],["✉","Почта"],["⚙","Настройки"],["▣","Календарь"],["◈","Файлы"],["✦","Помощник"]];
function updateClock(){const d=new Date();const t=d.toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"});$("lockTime").textContent=t;$("homeTime").textContent=t;$("lockDate").textContent=d.toLocaleDateString("ru-RU",{weekday:"long",day:"numeric",month:"long"}).toUpperCase();}
updateClock();setInterval(updateClock,10000);
function toast(s){$("toast").textContent=s;$("toast").classList.remove("hidden");setTimeout(()=>$("toast").classList.add("hidden"),2200)}
function open(id){$(id).classList.remove("hidden")}function close(id){$(id).classList.add("hidden")}
let holdTimer,holding=false,scanDuration=Number(localStorage.scanDuration||1450);
const scan=$("scanButton");
function startHold(e){e.preventDefault();holding=true;scan.classList.add("holding");holdTimer=setTimeout(unlock,scanDuration)}
function endHold(){holding=false;clearTimeout(holdTimer);scan.classList.remove("holding")}
function unlock(){if(!holding)return;holding=false;$("blackHole").classList.remove("hidden");setTimeout(()=>{$("blackHole").classList.add("hidden");close("lockScreen");open("homeScreen")},1600)}
scan.addEventListener("pointerdown",startHold);["pointerup","pointerleave","pointercancel"].forEach(ev=>scan.addEventListener(ev,endHold));
$("settingsOpen").onclick=()=>open("settings");$("drawerOpen").onclick=()=>{renderApps();open("drawer")};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>close(b.dataset.close));
function renderApps(q=""){const list=$("appList");list.innerHTML="";apps.filter(a=>a[1].toLowerCase().includes(q.toLowerCase())).forEach(a=>{const b=document.createElement("button");b.className="app-item";b.innerHTML=`<b>${a[0]}</b>${a[1]}`;b.onclick=()=>{close("drawer");if(a[1]==="Настройки")open("settings");else toast("Демо: "+a[1])};list.append(b)})}
$("appSearch").addEventListener("input",e=>renderApps(e.target.value));
const settings={
gestures:["Swipe actions","Свайп вверх — приложения; свайп вниз — центр управления.","Свайп вверх","Свайп вниз","Двойное касание"],
control:["Control center","Быстрые плитки и панель управления.","Wi-Fi","Звук","Яркость"],
assistant:["Show assistant","Показывать декоративную кнопку помощника.","Включить помощника"],
lock:["Lock Screen","Настройка часов и экрана блокировки.","Показывать дату","Размытие фона"],
fingerprint:["Fake fingerprint scanner","Декоративный эффект чёрной дыры при удержании кнопки.","Длительность анимации"],
services:["Services","Быстрый переход к системным настройкам Android.","Открыть настройки обоев","Настройки экрана"],
security:["Fingerprint and passcode","Для настоящей защиты используй системную блокировку Android.","Открыть системные настройки"],
appearance:["Appearance","Стеклянные панели, оттенок подсветки и фон.","Фиолетовый акцент","Сильное размытие"],
icons:["App icons","Выбери стиль значков приложений.","Округлые","Минималистичные"]
};
document.querySelectorAll("[data-setting]").forEach(b=>b.onclick=()=>showSetting(b.dataset.setting));
function showSetting(key){const s=settings[key];$("subTitle").textContent=s[0];let html=`<p class="footnote">${s[1]}</p>`;
if(key==="fingerprint"){html+=`<div class="option-row"><span>Scan duration<small>Время удержания до запуска эффекта</small></span><input id="duration" type="range" min="500" max="3000" step="100" value="${scanDuration}"></div><button class="action-button" id="previewHole">Предпросмотр чёрной дыры</button>`}
else if(key==="services"){html+=`<button class="action-button" id="wallpaperSettings">Открыть системные настройки обоев</button><button class="action-button" id="systemSettings">Открыть настройки Android</button>`}
else if(key==="security"){html+=`<button class="action-button" id="systemSettings">Открыть системные настройки</button>`}
else{s.slice(2).forEach((x,i)=>html+=`<label class="option-row"><span>${x}<small>Настраиваемая опция интерфейса</small></span><input class="switch" type="checkbox" ${i===0?"checked":""}></label>`)}
$("subContent").innerHTML=html;open("subSettings");
const dur=$("duration");if(dur)dur.oninput=()=>{scanDuration=Number(dur.value);localStorage.scanDuration=scanDuration};
const preview=$("previewHole");if(preview)preview.onclick=()=>{close("subSettings");demoHole()};
const ws=$("wallpaperSettings");if(ws)ws.onclick=()=>toast("Открой настройки Android → Обои");
const ss=$("systemSettings");if(ss)ss.onclick=()=>toast("Веб-версия не может открыть системную защиту Android");
}
$("settingsBack").onclick=()=>{close("subSettings");open("settings")};
function demoHole(){open("blackHole");setTimeout(()=>close("blackHole"),1600)}
document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>{const a=b.dataset.action;if(a==="apps"){renderApps();open("drawer")}else if(a==="wallpaper")toast("Живые обои настраиваются в Android");else toast("Демо-плитка: "+a)});
document.querySelectorAll(".dock-app").forEach(b=>b.onclick=()=>{if(b.dataset.app==="Настройки")open("settings");else toast("Демо: "+b.dataset.app)});
let touchY=0;document.addEventListener("touchstart",e=>touchY=e.touches[0].clientY,{passive:true});document.addEventListener("touchend",e=>{const dy=e.changedTouches[0].clientY-touchY;if(!$("homeScreen").classList.contains("hidden")&&dy>100)toast("Центр управления — демонстрация");if(!$("homeScreen").classList.contains("hidden")&&dy< -100){renderApps();open("drawer") }},{passive:true});
