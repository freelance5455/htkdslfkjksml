/*
  CONFIGURAÇÃO OPCIONAL DO FIREBASE
  Esta versão funciona localmente sem Firebase.
  Para sincronizar contas e publicações entre aparelhos, configure Firebase
  Authentication + Firestore e implemente as regras de segurança antes de publicar.
*/
window.FIREBASE_CONFIG = {
  apiKey: "COLOQUE_SUA_API_KEY",
  authDomain: "SEU_PROJETO.firebaseapp.com",
  projectId: "SEU_PROJECT_ID",
  storageBucket: "SEU_PROJETO.appspot.com",
  messagingSenderId: "SEU_MESSAGING_SENDER_ID",
  appId: "SEU_APP_ID"
};