const $ = (id) => document.getElementById(id);
const STORE = {users:"orkut26_users", posts:"orkut26_posts", profile:"orkut26_profile"};
let authMode = "login", session = null, selectedMedia = null, selectedMediaType = "";
let posts = JSON.parse(localStorage.getItem(STORE.posts) || "[]");
const communities = [
 ["🎮","Gamers do Brasil","Jogos, novidades e partidas."],
 ["🎵","Música para todos","Compartilhe suas músicas favoritas."],
 ["📼","Nostalgia anos 2000","Memórias da internet antiga."],
 ["🐱","Amantes de gatos","Fotos e histórias dos felinos."],
 ["💻","Tecnologia","Conversas sobre tecnologia e criatividade."],
 ["🎬","Cinema e séries","Indicações e papo sobre filmes."]
];
function users(){return JSON.parse(localStorage.getItem(STORE.users)||"[]")}
function saveUsers(v){localStorage.setItem(STORE.users,JSON.stringify(v))}
function safe(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2300)}
function showAuth(){ $("authScreen").classList.remove("hidden");$("app").classList.add("hidden") }
function showApp(){ $("authScreen").classList.add("hidden");$("app").classList.remove("hidden");renderUser();renderFeed();renderCommunities(); }
function renderUser(){
 const name=session?.name||"Visitante";$("currentUser").textContent=name;$("sideName").textContent=name;
 $("sideAvatar").textContent=session?.guest?"👋":"🙂";$("profileAvatar").textContent=session?.guest?"👋":"🙂";
 $("sideStatus").textContent=session?.guest?"Visitante temporário":"No Orkut2026";
 $("profileName").value=session?.name||"";$("profileBio").value=session?.bio||"";
}
document.querySelectorAll("[data-auth-tab]").forEach(b=>b.addEventListener("click",()=>{
 authMode=b.dataset.authTab;document.querySelectorAll("[data-auth-tab]").forEach(x=>x.classList.toggle("active",x===b));
 $("nameLabel").classList.toggle("hidden",authMode!=="register");$("authSubmit").textContent=authMode==="register"?"Criar minha conta":"Entrar";
 $("authPassword").autocomplete=authMode==="register"?"new-password":"current-password";$("authMessage").textContent="";
}));
async function hashPassword(value){
 const data=new TextEncoder().encode(value);
 try {
  if(window.crypto && window.crypto.subtle){
   const digest=await window.crypto.subtle.digest("SHA-256",data);
   return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,"0")).join("");
  }
 } catch (err) { /* fallback para navegadores/arquivos locais */ }
 // Fallback funcional para testes locais; não é indicado para contas online.
 return btoa(unescape(encodeURIComponent(value)));
}
$("authForm").addEventListener("submit",async e=>{
 e.preventDefault();const email=$("authEmail").value.trim().toLowerCase(),password=$("authPassword").value;
 const list=users(),hash=await hashPassword(password);
 if(authMode==="register"){
  const name=$("authName").value.trim();if(!name){$("authMessage").textContent="Digite seu nome.";return}
  if(list.some(u=>u.email===email)){$("authMessage").textContent="Este e-mail já está cadastrado neste aparelho.";return}
  list.push({email,passwordHash:hash,name,bio:""});saveUsers(list);session={email,name,bio:"",guest:false};toast("Conta criada!");
 }else{
  const user=list.find(u=>u.email===email&&u.passwordHash===hash);
  if(!user){$("authMessage").textContent="E-mail ou senha incorretos.";return}
  session={email:user.email,name:user.name,bio:user.bio||"",guest:false};
 }
 showApp();
});
$("guestBtn").addEventListener("click",()=>{
 try { session={name:"Visitante",bio:"",guest:true}; showApp(); toast("Você entrou como visitante temporário."); }
 catch(err) { $("authMessage").textContent="Não foi possível abrir o app: "+err.message; }
});
$("logoutBtn").addEventListener("click",()=>{
 if(session?.guest){posts=posts.filter(p=>p.author!=="Visitante");localStorage.setItem(STORE.posts,JSON.stringify(posts))}
 session=null;selectedMedia=null;showAuth();toast("Você saiu. A sessão temporária foi encerrada.");
});
function navigate(page){
 document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));$(page+"Page").classList.remove("hidden");
 document.querySelectorAll("[data-page]").forEach(b=>b.classList.toggle("selected",b.dataset.page===page));
 if(page==="profile")renderUser();
}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.page)));
function fileToData(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)})}
async function setMedia(file,type){
 if(!file)return;if(file.size>4*1024*1024){toast("Escolha um arquivo de até 4 MB.");return}
 if(type==="image"&&!file.type.startsWith("image/")){toast("Escolha uma imagem.");return}
 if(type==="gif"&&file.type!=="image/gif"){toast("Escolha um arquivo GIF.");return}
 selectedMedia=await fileToData(file);selectedMediaType=type;renderMediaPreview();
}
function renderMediaPreview(){
 const box=$("mediaPreview");box.classList.toggle("hidden",!selectedMedia);box.innerHTML=selectedMedia?`<img src="${selectedMedia}" alt="Prévia"><span class="tiny muted">${selectedMediaType==="gif"?"GIF selecionado":"Imagem selecionada"}</span><button id="removeMedia">Remover</button>`:"";
 const rm=$("removeMedia");if(rm)rm.onclick=()=>{selectedMedia=null;selectedMediaType="";renderMediaPreview()}
}
$("postImage").addEventListener("change",e=>setMedia(e.target.files[0],"image"));
$("postGif").addEventListener("change",e=>setMedia(e.target.files[0],"gif"));
$("gifUrlBtn").addEventListener("click",()=>{const url=prompt("Cole o endereço direto de um GIF (terminando em .gif):");if(!url)return;if(!/^https?:\/\//i.test(url)||!url.toLowerCase().split("?")[0].endsWith(".gif")){toast("Use um link direto para um arquivo .gif.");return}selectedMedia=url;selectedMediaType="gif";renderMediaPreview()});
$("publishBtn").addEventListener("click",()=>{
 const text=$("postText").value.trim();if(!text&&!selectedMedia){toast("Escreva algo ou adicione uma imagem.");return}
 posts.unshift({id:Date.now(),author:session.name,text,media:selectedMedia,mediaType:selectedMediaType,likes:0,liked:false,comments:[],date:new Date().toLocaleString("pt-BR")});
 try{localStorage.setItem(STORE.posts,JSON.stringify(posts))}catch(e){toast("Armazenamento cheio. Remova uma imagem grande.");return}
 $("postText").value="";selectedMedia=null;selectedMediaType="";renderMediaPreview();renderFeed();toast("Publicação criada!");
});
function renderFeed(){
 const feed=$("feed");if(!posts.length){feed.innerHTML='<div class="panel muted">Ainda não há publicações. Seja a primeira pessoa a compartilhar algo! 💙</div>';return}
 feed.innerHTML=posts.map(p=>`<article class="post" data-id="${p.id}">
 <div class="post-head"><div class="post-avatar">🙂</div><div><strong>${safe(p.author)}</strong><small>${safe(p.date||"Agora")}</small></div></div>
 ${p.text?`<div class="post-text">${safe(p.text)}</div>`:""}
 ${p.media?`<img class="post-media" src="${safe(p.media)}" alt="${p.mediaType==="gif"?"GIF publicado":"Imagem publicada"}" loading="lazy">`:""}
 <div class="post-actions"><button data-like="${p.id}">♡ ${p.likes||0} Curtir</button><button data-focus-comment="${p.id}">💬 ${p.comments?.length||0} Comentar</button></div>
 <div class="comments">${(p.comments||[]).map(c=>`<div class="comment"><strong>${safe(c.author)}:</strong> ${safe(c.text||"")}${c.gif?`<img src="${safe(c.gif)}" alt="GIF">`:""}</div>`).join("")}
 <form class="comment-form" data-comment="${p.id}"><input name="comment" maxlength="300" placeholder="Escreva um comentário..." required><button>Enviar</button></form>
 <button class="attach-btn" data-comment-gif="${p.id}" type="button">GIF no comentário</button></div></article>`).join("");
 feed.querySelectorAll("[data-like]").forEach(b=>b.onclick=()=>{const p=posts.find(x=>x.id==b.dataset.like);p.likes=(p.likes||0)+(p.liked?-1:1);p.liked=!p.liked;persistPosts();renderFeed()});
 feed.querySelectorAll("[data-focus-comment]").forEach(b=>b.onclick=()=>feed.querySelector(`[data-comment="${b.dataset.focusComment}"] input`).focus());
 feed.querySelectorAll(".comment-form").forEach(f=>f.onsubmit=e=>{e.preventDefault();const p=posts.find(x=>x.id==f.dataset.comment);p.comments.push({author:session.name,text:f.comment.value});persistPosts();renderFeed()});
 feed.querySelectorAll("[data-comment-gif]").forEach(b=>b.onclick=()=>{const url=prompt("Cole o link direto de um GIF (.gif):");if(!url)return;if(!/^https?:\/\//i.test(url)||!url.toLowerCase().split("?")[0].endsWith(".gif")){toast("Use um link direto para um arquivo .gif.");return}const p=posts.find(x=>x.id==b.dataset.commentGif);p.comments.push({author:session.name,gif:url});persistPosts();renderFeed()});
}
function persistPosts(){try{localStorage.setItem(STORE.posts,JSON.stringify(posts))}catch(e){toast("Não foi possível salvar. O armazenamento pode estar cheio.")}}
function renderCommunities(){$("communityGrid").innerHTML=communities.map(c=>`<article class="community"><div class="emoji">${c[0]}</div><h3>${c[1]}</h3><p>${c[2]}</p><button class="secondary" style="margin-top:14px" onclick="toast('Comunidade de demonstração: em breve!')">Ver comunidade</button></article>`).join("")}
$("saveProfile").addEventListener("click",()=>{
 if(session.guest){session.name=$("profileName").value.trim()||"Visitante";session.bio=$("profileBio").value.trim();renderUser();toast("Perfil temporário atualizado.");return}
 const name=$("profileName").value.trim();if(!name){$("profileMessage").textContent="Digite um nome.";return}
 session.name=name;session.bio=$("profileBio").value.trim();const list=users(),u=list.find(x=>x.email===session.email);if(u){u.name=session.name;u.bio=session.bio;saveUsers(list)}renderUser();$("profileMessage").textContent="Perfil salvo!";
});
function aiReply(input){
 const s=input.toLowerCase();
 if(/^(oi|olá|ola|e aí|eai|bom dia|boa tarde|boa noite)/.test(s))return "Oi! Que bom conversar com você! 😊 Como está seu dia?";
 if(s.includes("orkut"))return "O Orkut marcou uma época na internet! 💙 Qual era a parte de que você mais gostava: comunidades, depoimentos ou scraps?";
 if(s.includes("jogo")||s.includes("game"))return "Legal! 🎮 Que tipo de jogo você curte: aventura, construção, corrida ou outro estilo?";
 if(s.includes("música")||s.includes("musica"))return "Música é um ótimo assunto! 🎵 Que estilo você costuma ouvir?";
 if(s.includes("triste")||s.includes("difícil")||s.includes("dificil"))return "Poxa, sinto que as coisas não estão fáceis agora. Se quiser, pode me contar um pouco mais. Posso ouvir sem julgar.";
 if(s.includes("?"))return "Boa pergunta! Ainda estou no modo de demonstração, então não consigo pesquisar ou saber tudo. Mas posso conversar e ajudar a organizar suas ideias. Quer me contar mais sobre o assunto?";
 return "Entendi! 😊 Me conta um pouco mais. O que você acha mais interessante nisso?";
}
$("chatForm").addEventListener("submit",e=>{
 e.preventDefault();const input=$("chatInput"),value=input.value.trim();if(!value)return;
 addBubble(value,"me");input.value="";setTimeout(()=>addBubble(aiReply(value),"ai"),450);
});
function addBubble(text,kind){const el=document.createElement("div");el.className="bubble "+kind;el.textContent=text;$("chatMessages").appendChild(el);$("chatMessages").scrollTop=$("chatMessages").scrollHeight}
renderCommunities();