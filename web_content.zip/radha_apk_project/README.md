# श्री राधे नाम जप — Android APK Project

यह Android Studio project आपके मौजूदा Daily Reset web app को WebView app में पैक करता है।

## APK बनाने का तरीका
1. इस project ZIP को extract करें।
2. Android Studio में **Open** करके इस folder को चुनें।
3. Gradle sync पूरा होने दें।
4. **Build → Generate App Bundles or APKs → Generate APKs** चुनें।
5. APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।

### खास बातें
- Daily Reset वाला मौजूदा JavaScript logic सुरक्षित है।
- राधा-कृष्ण फोटो और टैप साउंड app के `assets` में bundled हैं।
- Internet permission की जरूरत नहीं है।
