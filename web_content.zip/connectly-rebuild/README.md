# Connectly Full-Stack v2.0

A self-hosted social-media platform starter built with Node.js, Express, SQLite and a responsive vanilla-JS frontend.

## Included
- Multi-user registration/login with bcrypt + JWT
- Profiles, avatars, bios and privacy modes (public/followers/private)
- Posts, media uploads, visibility controls, likes, comments and feed
- Search, follows, notifications and direct messages
- 24-hour stories with views
- Reels/video feed with likes
- Groups, membership and group posts API
- Pages, followers and page posts API
- Live rooms with hosts/viewers API (room management; WebRTC streaming provider can be added)
- Email verification and password recovery token flows
- Blocking and user/report moderation APIs
- Admin report endpoint controlled by ADMIN_USER_IDS
- Dark/light responsive UI
- Upload limits and security middleware

## Run
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and set `JWT_SECRET` to a random value of at least 32 characters.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## Production notes
SMTP credentials are required to actually deliver verification/recovery emails. The current starter logs generated tokens for development. Live rooms manage hosts/viewers but do not provide a media SFU/WebRTC server; connect a provider such as LiveKit, Janus or mediasoup for production streaming. For scale, move SQLite/uploads to PostgreSQL and object storage, add HTTPS, backups, CSRF/origin controls, malware scanning and a full moderation/admin UI.
