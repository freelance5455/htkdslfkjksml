/* JOSTECH — MANUEL 04 : CYBERSÉCURITÉ NIVEAU 2 */
registerLessonDetail(4, 2, "sec-2-1-1", {
  title: "Leçon 1 : Cryptographie Appliquée (AES, RSA, Hachage & TLS)",
  duration: "45 min (Manuel complet)",
  objectives: [
    "Distinguer chiffrement symétrique (AES), asymétrique (RSA/ECC) et hachage (SHA-256, Argon2).",
    "Comprendre le stockage sécurisé des mots de passe avec Sel (Salt).",
    "Expliquer le mécanisme hybride de la poignée de main TLS (HTTPS)."
  ],
  prerequisites: ["Niveau 1 — Cybersécurité et notions de binaire/hexadécimal."],
  sections: [
    {
      type: "theory",
      title: "1. Chiffrement vs Hachage : ne jamais confondre !",
      text: "Le chiffrement (Encryption) transforme un texte clair en texte chiffré de manière RÉVERSIBLE : quiconque possède la clé de déchiffrement retrouve l'original. À l'inverse, une fonction de hachage cryptographique est IRRÉVERSIBLE (à sens unique) : elle calcule une empreinte fixe (ex. 256 bits pour SHA-256). Modifier une seule virgule dans un fichier de 10 Go change radicalement toute l'empreinte (effet avalanche) !"
    },
    {
      type: "table",
      title: "2. Les trois piliers cryptographiques modernes",
      headers: ["Famille", "Clés", "Algorithmes & Usages"],
      rows: [
        ["Symétrique", "1 seule clé secrète partagée", "AES-256, ChaCha20 : ultra rapide pour chiffrer disques et flux réseau."],
        ["Asymétrique", "Paire Clé Publique + Clé Privée", "RSA, ECDSA : échange sécurisé de clés et signature numérique."],
        ["Hachage", "Aucune clé (sens unique)", "SHA-256 (intégrité fichiers), Argon2 / bcrypt (mots de passe)."]
      ]
    },
    {
      type: "definition",
      term: "Signature Numérique et Protocole TLS (HTTPS)",
      text: "En cryptographie asymétrique :\n• Pour chiffrer un message pour Amina : on chiffre avec la Clé PUBLIQUE d'Amina (seule sa Clé PRIVÉE peut le lire).\n• Pour signer numériquement : on signe avec sa propre Clé PRIVÉE (tout le monde vérifie avec la Clé PUBLIQUE).\n\nDans HTTPS (TLS), on combine les deux mondes : le serveur prouve son identité par certificat asymétrique, négocie secrètement une clé temporaire, puis tout le trafic rapide utilise le chiffrement symétrique AES !"
    },
    {
      type: "code",
      lang: "Stockage sûr des mots de passe (Hachage + Sel)",
      code: [
        "// MAUVAIS : SHA256('123456') donne toujours la même empreinte → cassé par Rainbow Tables !",
        "// BON     : On ajoute un Sel aléatoire unique (Salt) + algorithme lent (Argon2/bcrypt) :",
        "Sel aléatoire pour Jos : '9f8a2b!'",
        "Empreinte stockée      : Argon2('monMotDePasse' + '9f8a2b!')",
        "// Deux utilisateurs ayant le même mot de passe auront ainsi deux empreintes différentes !"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Pièges cryptographiques célèbres",
      text: "1) N'inventez JAMAIS votre propre algorithme de chiffrement : utilisez toujours des standards audités (AES-GCM, TLS 1.3).\n2) Ne confondez pas Encodage (Base64, UTF-8, lisible par tous sans clé) avec Chiffrement (protégé par une clé secrète)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Choix d'algorithme",
      question: "Quel outil cryptographique précis utilisez-vous pour :\n1) Chiffrer un disque dur entier de 1 To rapidement.\n2) Vérifier qu'un fichier téléchargé n'a pas été modifié par un virus.\n3) Stocker les mots de passe d'une base utilisateurs.",
      solution: "1) Chiffrement symétrique (AES-256).\n2) Fonction de hachage rapide (SHA-256).\n3) Hachage lent salé (Argon2 ou bcrypt)."
    },
    {
      title: "Exercice 2 — Clé publique vs Clé privée",
      question: "Mivumbi veut envoyer un document confidentiel à Sarah en utilisant la cryptographie asymétrique. Quelle clé exacte utilise-t-il pour chiffrer, et quelle clé Sarah utilise-t-elle pour déchiffrer ?",
      solution: "Mivumbi chiffre avec la Clé PUBLIQUE de Sarah. Sarah déchiffre avec sa propre Clé PRIVÉE (qu'elle ne partage jamais)."
    }
  ],
  summary: "La cryptographie moderne allie rapidité du symétrique (AES), échange sûr et signature de l'asymétrique (RSA/ECC) dans TLS, et irréversibilité du hachage salé (Argon2) pour les mots de passe.",
  references: ["Schneier, B. — Applied Cryptography.", "Aumasson, J.-P. — Serious Cryptography."]
});