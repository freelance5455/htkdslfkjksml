# CARGPT + Backend Asli + ALDY AI Engine

Paket ini menggabungkan backend dari ZIP yang kamu kirim dengan halaman CARGPT dan endpoint AI lokal. Fitur server asal dipertahankan; endpoint baru ditambahkan di `/api/aldy-ai`.

## Kebutuhan
- Node.js 18 atau lebih baru
- Ollama terpasang pada mesin server
- Model lokal, contoh: `ollama pull qwen2.5:3b`

## Menjalankan
1. Ekstrak paket ke folder server.
2. Jalankan `npm install`.
3. Pastikan Ollama berjalan dan model sudah diunduh.
4. Jalankan server dengan `npm start`. Backend asal memakai port API dari `API_PORT` (default 2035) dan WebSocket dari `WS_PORT` (default 3001).
5. Pada startup pertama, server membuat `aldy-ai-config.json` dan mencetak API key ALDY ke terminal. Simpan key itu secara privat. File konfigurasi memiliki permission terbatas pada sistem yang mendukungnya.
6. Buka `http://ALAMAT-SERVER:2035/cargpt`, tekan ikon pengaturan, masukkan alamat server (contoh `http://ALAMAT-SERVER:2035`) dan API key ALDY.

## Endpoint baru
- `GET /api/aldy-ai/health` — status engine dan nama model.
- `POST /api/aldy-ai/chat` — chat dengan header `Authorization: Bearer API_KEY_ALDY`.

## Konfigurasi model
Edit `aldy-ai-config.json` setelah pertama kali server dijalankan:
- `ollamaUrl`: default `http://127.0.0.1:11434`
- `model`: default `qwen2.5:3b`
Restart server setelah perubahan.

## Catatan keamanan dan kompatibilitas
- API key ALDY adalah kunci akses endpoint server sendiri, bukan API key penyedia AI.
- Model berjalan lokal melalui Ollama; kualitas dan kecepatan bergantung pada RAM/CPU/GPU server.
- Jangan publikasikan `aldy-ai-config.json`, file session, token bot, atau file konfigurasi privat.
- ZIP sumber berisi konfigurasi dan kemungkinan kredensial layanan yang sudah ada. Karena file itu telah dibagikan, rotasi/ganti token Telegram, WhatsApp, dan kredensial terkait sebelum dipasang di server publik.
- Backend sumber memiliki banyak fitur dan dependensi eksternal. Paket gabungan belum dapat dianggap teruji end-to-end tanpa instalasi dependensi dan pengujian pada server target.
- Jangan membuka server ke internet tanpa HTTPS, firewall, pembatasan akses, serta audit keamanan.
