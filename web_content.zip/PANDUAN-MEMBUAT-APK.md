# Panduan Membuat File APK (Wallet - Atur Uang Harian)

Paket ini berisi proyek Android lengkap yang sudah menyertakan aplikasi **Wallet - Atur Uang Harian** secara offline di dalam `app/src/main/assets/index.html`.

## Cara 1: Build APK Otomatis Tanpa Install Aplikasi di PC/HP (via GitHub Actions)
1. Buat repository baru di GitHub.com.
2. Ekstrak file ZIP ini, lalu upload semua isinya ke repository GitHub tersebut.
3. Buka tab **Actions** di repository GitHub Anda, lalu jalankan workflow **Build Wallet Android APK**.
4. Dalam ~2 menit, file **Wallet-Android-APK.zip** yang berisi `app-debug.apk` siap diunduh dan langsung di-install di HP Android Anda!

## Cara 2: Buka di Android Studio (PC/Laptop) atau AndroidIDE (HP Android)
1. Ekstrak folder ini dan buka di **Android Studio** atau **AndroidIDE**.
2. Pilih menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. File `.apk` akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara 3: Menggunakan Website 2 APK / HopWeb di HP Android
- Anda juga bisa langsung mengambil file `app/src/main/assets/index.html` dan membukanya di aplikasi pembuat APK instan di Android seperti **HopWeb** atau **Web2APK**.
