/**
 * Mod Porter Orchestrator
 * 
 * The main coordinator that brings together all components:
 * - Java mod analysis (via Rust analyzer)
 * - IR transformation
 * - Bedrock mapping
 * - Degradation handling
 * - Code generation
 * - Validation
 * - Report generation
 */

import * as fs from 'fs';
import * as path from 'path';
import { execSync, spawn } from 'child_process';
import { ModIR, createEmptyModIR } from './ir/java-ir';
import { MappingEngine, MappingResult } from './mapping';
import { DegradationPolicy } from './degradation';
import { BedrockGenerator, GeneratorOptions } from './generator';
import { AddonValidator, ValidationResult } from './validation';
import { ReportGenerator, PortingReport, ReportOptions } from './report';
import { Logger, ProgressIndicator } from './utils/logger';

export interface PorterConfig {
  /** Path to input Java mod (.jar or folder) */
  input: string;
  
  /** Output directory for generated addon */
  output: string;
  
  /** Mod loader hint (forge, fabric, auto) */
  loader: 'forge' | 'fabric' | 'quilt' | 'auto';
  
  /** Generate .mcpack/.mcaddon files */
  createPackages: boolean;
  
  /** Validate output before finalizing */
  validate: boolean;
  
  /** Generate porting report */
  generateReport: boolean;
  
  /** Report format */
  reportFormat: 'markdown' | 'json' | 'html';
  
  /** Logging level */
  logLevel: 'error' | 'warn' | 'info' | 'debug' | 'verbose';
  
  /** Path to Rust analyzer binary */
  analyzerPath?: string;
  
  /** Skip Rust analyzer and use existing IR file */
  irFile?: string;
  
  /** Minify JSON output */
  minifyJson: boolean;
  
  /** Compile TypeScript to JavaScript */
  compileScripts: boolean;
}

const DEFAULT_CONFIG: PorterConfig = {
  input: '',
  output: './output',
  loader: 'auto',
  createPackages: true,
  validate: true,
  generateReport: true,
  reportFormat: 'markdown',
  logLevel: 'info',
  minifyJson: false,
  compileScripts: true,
};

export interface PorterResult {
  success: boolean;
  outputPath: string;
  mappingResult: MappingResult;
  validationResult: ValidationResult;
  report?: PortingReport;
  errors: string[];
  warnings: string[];
}

export class ModPorter {
  private config: PorterConfig;
  private logger: Logger;
  
  constructor(config: Partial<PorterConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.logger = new Logger({ level: this.config.logLevel });
  }
  
  /**
   * Run the complete porting pipeline
   */
  async port(): Promise<PorterResult> {
    const result: PorterResult = {
      success: false,
      outputPath: this.config.output,
      mappingResult: {
        addon: null as any,
        mappings: [],
        degradations: [],
        warnings: [],
        errors: [],
      },
      validationResult: {
        valid: false,
        errors: [],
        warnings: [],
        info: [],
      },
      errors: [],
      warnings: [],
    };
    
    try {
      this.logger.info('='.repeat(60));
      this.logger.info('Java-to-Bedrock Mod Porter');
      this.logger.info('='.repeat(60));
      
      // Step 1: Analyze Java mod
      this.logger.info('Step 1/6: Analyzing Java mod...');
      const javaIR = await this.analyzeJavaMod();
      this.logger.info(`  Detected: ${javaIR.metadata.name} (${javaIR.loader})`);
      this.logger.info(`  ${javaIR.blocks.length} blocks, ${javaIR.items.length} items, ${javaIR.entities.length} entities`);
      
      // Step 2: Initialize engines
      this.logger.info('Step 2/6: Initializing mapping engine...');
      const degradationPolicy = new DegradationPolicy(this.logger);
      const mappingEngine = new MappingEngine(this.logger, degradationPolicy);
      
      // Step 3: Map to Bedrock
      this.logger.info('Step 3/6: Mapping to Bedrock format...');
      result.mappingResult = await mappingEngine.map(javaIR);
      this.logger.info(`  Mapped ${result.mappingResult.mappings.filter(m => m.success).length} features`);
      this.logger.info(`  ${result.mappingResult.degradations.length} features required degradation`);
      
      // Step 4: Generate addon files
      this.logger.info('Step 4/6: Generating Bedrock addon...');
      const generator = new BedrockGenerator(this.logger, {
        outputDir: this.config.output,
        generatePackages: this.config.createPackages,
        minifyJson: this.config.minifyJson,
        compileScripts: this.config.compileScripts,
      });
      await generator.generate(result.mappingResult.addon);
      
      // Step 5: Validate
      if (this.config.validate) {
        this.logger.info('Step 5/6: Validating addon...');
        const validator = new AddonValidator(this.logger);
        result.validationResult = validator.validateIR(result.mappingResult.addon);
        
        if (result.validationResult.valid) {
          this.logger.info('  ✓ Validation passed');
        } else {
          this.logger.warn(`  ✗ Validation failed with ${result.validationResult.errors.length} errors`);
        }
      } else {
        this.logger.info('Step 5/6: Skipping validation...');
        result.validationResult = { valid: true, errors: [], warnings: [], info: [] };
      }
      
      // Step 6: Generate report
      if (this.config.generateReport) {
        this.logger.info('Step 6/6: Generating report...');
        const reportGenerator = new ReportGenerator({ format: this.config.reportFormat });
        result.report = reportGenerator.generate(javaIR, result.mappingResult, result.validationResult);
        
        const reportExt = { markdown: 'md', json: 'json', html: 'html' }[this.config.reportFormat];
        const reportPath = path.join(this.config.output, `porting-report.${reportExt}`);
        reportGenerator.save(result.report, reportPath);
        this.logger.info(`  Report saved to ${reportPath}`);
      } else {
        this.logger.info('Step 6/6: Skipping report generation...');
      }
      
      // Done!
      result.success = true;
      result.errors = result.mappingResult.errors;
      result.warnings = result.mappingResult.warnings;
      
      this.logger.info('');
      this.logger.info('='.repeat(60));
      this.logger.info('Porting complete!');
      this.logger.info(`Output: ${this.config.output}`);
      this.logger.info(`Success rate: ${result.report?.statistics.successRate.toFixed(1) || 'N/A'}%`);
      this.logger.info('='.repeat(60));
      
    } catch (error) {
      result.success = false;
      result.errors.push(`Fatal error: ${(error as Error).message}`);
      this.logger.error(`Porting failed: ${(error as Error).message}`);
      this.logger.debug((error as Error).stack || '');
    }
    
    return result;
  }
  
  /**
   * Analyze Java mod using Rust analyzer or from existing IR file
   */
  private async analyzeJavaMod(): Promise<ModIR> {
    // If IR file is provided, use it directly
    if (this.config.irFile) {
      this.logger.debug(`Loading IR from file: ${this.config.irFile}`);
      const content = fs.readFileSync(this.config.irFile, 'utf-8');
      return this.parseAnalyzerOutput(JSON.parse(content));
    }
    
    // Verify input exists
    if (!fs.existsSync(this.config.input)) {
      throw new Error(`Input not found: ${this.config.input}`);
    }
    
    // Try to find the Rust analyzer
    const analyzerPath = this.findAnalyzer();
    
    if (analyzerPath) {
      return await this.runRustAnalyzer(analyzerPath);
    } else {
      this.logger.warn('Rust analyzer not found, using built-in JavaScript analyzer');
      return await this.runJsAnalyzer();
    }
  }
  
  /**
   * Find the Rust analyzer binary
   */
  private findAnalyzer(): string | null {
    if (this.config.analyzerPath && fs.existsSync(this.config.analyzerPath)) {
      return this.config.analyzerPath;
    }
    
    // Check common locations
    const locations = [
      path.join(__dirname, '..', 'rust-analyzer', 'target', 'release', 'java-analyzer'),
      path.join(__dirname, '..', 'rust-analyzer', 'target', 'release', 'java-analyzer.exe'),
      path.join(__dirname, '..', 'bin', 'java-analyzer'),
      path.join(__dirname, '..', 'bin', 'java-analyzer.exe'),
    ];
    
    for (const loc of locations) {
      if (fs.existsSync(loc)) {
        return loc;
      }
    }
    
    return null;
  }
  
  /**
   * Run the Rust analyzer
   */
  private async runRustAnalyzer(analyzerPath: string): Promise<ModIR> {
    const tempOutput = path.join(this.config.output, '.temp', 'analysis.json');
    fs.mkdirSync(path.dirname(tempOutput), { recursive: true });
    
    return new Promise((resolve, reject) => {
      const args = [
        '--input', this.config.input,
        '--output', tempOutput,
        '--loader', this.config.loader,
      ];
      
      if (this.config.logLevel === 'debug' || this.config.logLevel === 'verbose') {
        args.push('--verbose');
      }
      
      this.logger.debug(`Running: ${analyzerPath} ${args.join(' ')}`);
      
      const proc = spawn(analyzerPath, args, {
        stdio: ['ignore', 'pipe', 'pipe'],
      });
      
      let stdout = '';
      let stderr = '';
      
      proc.stdout.on('data', (data) => {
        stdout += data.toString();
        this.logger.verbose(data.toString().trim());
      });
      
      proc.stderr.on('data', (data) => {
        stderr += data.toString();
        this.logger.debug(data.toString().trim());
      });
      
      proc.on('close', (code) => {
        if (code === 0 && fs.existsSync(tempOutput)) {
          try {
            const content = fs.readFileSync(tempOutput, 'utf-8');
            const ir = this.parseAnalyzerOutput(JSON.parse(content));
            resolve(ir);
          } catch (error) {
            reject(new Error(`Failed to parse analyzer output: ${error}`));
          }
        } else {
          reject(new Error(`Analyzer failed with code ${code}: ${stderr}`));
        }
      });
      
      proc.on('error', (error) => {
        reject(new Error(`Failed to run analyzer: ${error.message}`));
      });
    });
  }
  
  /**
   * Run built-in JavaScript analyzer as fallback
   */
  private async runJsAnalyzer(): Promise<ModIR> {
    // This is a simplified analyzer that handles basic cases
    // The Rust analyzer is preferred for full analysis
    
    const ir = createEmptyModIR();
    
    // Check if input is a jar file
    if (this.config.input.endsWith('.jar')) {
      const AdmZip = require('adm-zip');
      const zip = new AdmZip(this.config.input);
      const entries = zip.getEntries();
      
      // Look for metadata files
      for (const entry of entries) {
        if (entry.entryName === 'fabric.mod.json') {
          const content = entry.getData().toString('utf-8');
          const json = JSON.parse(content);
          ir.metadata.modId = json.id || 'unknown';
          ir.metadata.name = json.name || json.id;
          ir.metadata.version = json.version || '1.0.0';
          ir.metadata.description = json.description || '';
          ir.loader = 'fabric';
        } else if (entry.entryName.includes('mods.toml')) {
          // Parse TOML for Forge
          ir.loader = 'forge';
        }
        
        // Count class files
        if (entry.entryName.endsWith('.class')) {
          // Would analyze classes here
        }
        
        // Parse recipe JSONs
        if (entry.entryName.includes('recipes/') && entry.entryName.endsWith('.json')) {
          try {
            const content = entry.getData().toString('utf-8');
            const recipe = JSON.parse(content);
            ir.recipes.push({
              id: path.basename(entry.entryName, '.json'),
              recipeType: this.parseRecipeType(recipe.type),
              inputs: [],
              output: { itemId: '', count: 1 },
              conditions: [],
            });
          } catch {
            // Skip invalid JSON
          }
        }
      }
    }
    
    if (!ir.metadata.modId) {
      ir.metadata.modId = path.basename(this.config.input, '.jar').replace(/[^a-z0-9]/gi, '_').toLowerCase();
      ir.metadata.name = ir.metadata.modId;
    }
    
    this.logger.warn('JavaScript analyzer provides limited analysis. Build the Rust analyzer for full support.');
    
    return ir;
  }
  
  /**
   * Parse Rust analyzer output to TypeScript IR
   */
  private parseAnalyzerOutput(data: any): ModIR {
    // Convert snake_case to camelCase
    const convertKeys = (obj: any): any => {
      if (Array.isArray(obj)) {
        return obj.map(convertKeys);
      }
      if (obj !== null && typeof obj === 'object') {
        return Object.keys(obj).reduce((result, key) => {
          const camelKey = key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
          result[camelKey] = convertKeys(obj[key]);
          return result;
        }, {} as any);
      }
      return obj;
    };
    
    return convertKeys(data) as ModIR;
  }
  
  private parseRecipeType(type: string): any {
    const typeMap: Record<string, string> = {
      'minecraft:crafting_shaped': 'shaped',
      'crafting_shaped': 'shaped',
      'minecraft:crafting_shapeless': 'shapeless',
      'crafting_shapeless': 'shapeless',
      'minecraft:smelting': 'smelting',
      'smelting': 'smelting',
    };
    return typeMap[type] || 'unknown';
  }
}
