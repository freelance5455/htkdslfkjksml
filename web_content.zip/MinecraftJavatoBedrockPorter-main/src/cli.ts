#!/usr/bin/env node

/**
 * Java-to-Bedrock Mod Porter CLI
 * 
 * Command-line interface for the mod porting tool.
 */

import { Command } from 'commander';
import * as path from 'path';
import * as fs from 'fs';
import chalk from 'chalk';
import { ModPorter, PorterConfig } from './porter';

const packageJson = require('../package.json');

const program = new Command();

program
  .name('modporter')
  .description('Fully autonomous Java-to-Bedrock Minecraft mod porting tool')
  .version(packageJson.version);

program
  .command('port')
  .description('Port a Java mod to Bedrock addon')
  .argument('<input>', 'Path to Java mod (.jar file or source directory)')
  .option('-o, --output <path>', 'Output directory', './output')
  .option('-l, --loader <type>', 'Mod loader hint (forge, fabric, quilt, auto)', 'auto')
  .option('--no-packages', 'Skip creating .mcpack/.mcaddon files')
  .option('--no-validate', 'Skip addon validation')
  .option('--no-report', 'Skip generating porting report')
  .option('-f, --format <type>', 'Report format (markdown, json, html)', 'markdown')
  .option('-v, --verbose', 'Enable verbose logging')
  .option('--debug', 'Enable debug logging')
  .option('--minify', 'Minify JSON output')
  .option('--analyzer <path>', 'Path to Rust analyzer binary')
  .option('--ir <path>', 'Use existing IR file instead of analyzing')
  .action(async (input: string, options: Record<string, any>) => {
    console.log(chalk.cyan('╔═══════════════════════════════════════════════════════════╗'));
    console.log(chalk.cyan('║         Java-to-Bedrock Mod Porter                        ║'));
    console.log(chalk.cyan('║         Fully Autonomous Porting Tool                     ║'));
    console.log(chalk.cyan('╚═══════════════════════════════════════════════════════════╝'));
    console.log();
    
    // Resolve paths
    const inputPath = path.resolve(input);
    const outputPath = path.resolve(options.output);
    
    // Validate input
    if (!fs.existsSync(inputPath)) {
      console.error(chalk.red(`Error: Input not found: ${inputPath}`));
      process.exit(1);
    }
    
    // Determine log level
    let logLevel: 'error' | 'warn' | 'info' | 'debug' | 'verbose' = 'info';
    if (options.debug) logLevel = 'debug';
    if (options.verbose) logLevel = 'verbose';
    
    // Create config
    const config: Partial<PorterConfig> = {
      input: inputPath,
      output: outputPath,
      loader: options.loader as any,
      createPackages: options.packages !== false,
      validate: options.validate !== false,
      generateReport: options.report !== false,
      reportFormat: options.format as any,
      logLevel,
      minifyJson: options.minify || false,
      analyzerPath: options.analyzer,
      irFile: options.ir,
    };
    
    console.log(chalk.gray(`Input:  ${inputPath}`));
    console.log(chalk.gray(`Output: ${outputPath}`));
    console.log();
    
    // Run porter
    const porter = new ModPorter(config);
    const result = await porter.port();
    
    console.log();
    
    if (result.success) {
      console.log(chalk.green('✓ Porting completed successfully!'));
      console.log();
      console.log('Output files:');
      console.log(chalk.gray(`  Behavior Pack: ${path.join(outputPath, 'behavior_pack')}`));
      console.log(chalk.gray(`  Resource Pack: ${path.join(outputPath, 'resource_pack')}`));
      
      if (options.packages !== false) {
        console.log(chalk.gray(`  Addon:         ${path.join(outputPath, 'addon.mcaddon')}`));
      }
      
      if (result.warnings.length > 0) {
        console.log();
        console.log(chalk.yellow(`⚠ ${result.warnings.length} warnings during porting`));
      }
    } else {
      console.log(chalk.red('✗ Porting failed'));
      console.log();
      for (const error of result.errors) {
        console.log(chalk.red(`  • ${error}`));
      }
      process.exit(1);
    }
  });

program
  .command('analyze')
  .description('Analyze a Java mod without porting')
  .argument('<input>', 'Path to Java mod (.jar file or source directory)')
  .option('-o, --output <path>', 'Output path for IR JSON', './analysis.json')
  .option('-l, --loader <type>', 'Mod loader hint (forge, fabric, quilt, auto)', 'auto')
  .option('--analyzer <path>', 'Path to Rust analyzer binary')
  .action(async (input: string, options: Record<string, any>) => {
    console.log(chalk.cyan('Analyzing Java mod...'));
    console.log();
    
    const inputPath = path.resolve(input);
    const outputPath = path.resolve(options.output);
    
    if (!fs.existsSync(inputPath)) {
      console.error(chalk.red(`Error: Input not found: ${inputPath}`));
      process.exit(1);
    }
    
    // For now, we just run the porter with special options
    const config: Partial<PorterConfig> = {
      input: inputPath,
      output: path.dirname(outputPath),
      loader: options.loader as any,
      createPackages: false,
      validate: false,
      generateReport: false,
      logLevel: 'info',
      analyzerPath: options.analyzer,
    };
    
    // TODO: Add analyze-only mode
    console.log(chalk.yellow('Note: Full analysis requires the Rust analyzer to be built.'));
    console.log(chalk.gray(`Build it with: cd rust-analyzer && cargo build --release`));
  });

program
  .command('validate')
  .description('Validate an existing Bedrock addon')
  .argument('<path>', 'Path to addon directory or .mcaddon file')
  .option('--strict', 'Enable strict validation mode')
  .action(async (inputPath: string, options: Record<string, any>) => {
    console.log(chalk.cyan('Validating Bedrock addon...'));
    console.log();
    
    const addonPath = path.resolve(inputPath);
    
    if (!fs.existsSync(addonPath)) {
      console.error(chalk.red(`Error: Addon not found: ${addonPath}`));
      process.exit(1);
    }
    
    // TODO: Implement standalone validation
    console.log(chalk.gray('Validation coming soon...'));
  });

program
  .command('init')
  .description('Initialize a new Bedrock addon project')
  .argument('[name]', 'Project name', 'my-addon')
  .option('-d, --directory <path>', 'Project directory', '.')
  .action(async (name: string, options: Record<string, any>) => {
    console.log(chalk.cyan(`Creating new addon project: ${name}`));
    console.log();
    
    const projectDir = path.resolve(options.directory, name);
    
    // Create directory structure
    fs.mkdirSync(path.join(projectDir, 'behavior_pack', 'scripts'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, 'behavior_pack', 'blocks'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, 'behavior_pack', 'items'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, 'behavior_pack', 'entities'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, 'resource_pack', 'textures', 'blocks'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, 'resource_pack', 'textures', 'items'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, 'resource_pack', 'models', 'blocks'), { recursive: true });
    
    // Create manifest files
    const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    
    const bpManifest = {
      format_version: 2,
      header: {
        name: name,
        description: `Behavior pack for ${name}`,
        uuid: uuid(),
        version: [1, 0, 0],
        min_engine_version: [1, 20, 0],
      },
      modules: [
        {
          type: 'data',
          uuid: uuid(),
          version: [1, 0, 0],
        },
        {
          type: 'script',
          uuid: uuid(),
          version: [1, 0, 0],
          entry: 'scripts/main.js',
          language: 'javascript',
        },
      ],
      dependencies: [
        {
          module_name: '@minecraft/server',
          version: '1.12.0',
        },
      ],
    };
    
    const rpManifest = {
      format_version: 2,
      header: {
        name: `${name} Resources`,
        description: `Resource pack for ${name}`,
        uuid: uuid(),
        version: [1, 0, 0],
        min_engine_version: [1, 20, 0],
      },
      modules: [
        {
          type: 'resources',
          uuid: uuid(),
          version: [1, 0, 0],
        },
      ],
    };
    
    fs.writeFileSync(
      path.join(projectDir, 'behavior_pack', 'manifest.json'),
      JSON.stringify(bpManifest, null, 2)
    );
    
    fs.writeFileSync(
      path.join(projectDir, 'resource_pack', 'manifest.json'),
      JSON.stringify(rpManifest, null, 2)
    );
    
    // Create starter script
    const starterScript = `/**
 * ${name} - Main Entry Point
 */

import { world, system } from '@minecraft/server';

world.afterEvents.worldInitialize.subscribe(() => {
  console.log('${name} loaded!');
});
`;
    
    fs.writeFileSync(
      path.join(projectDir, 'behavior_pack', 'scripts', 'main.js'),
      starterScript
    );
    
    console.log(chalk.green(`✓ Created project at ${projectDir}`));
    console.log();
    console.log('Next steps:');
    console.log(chalk.gray(`  1. cd ${name}`));
    console.log(chalk.gray('  2. Add your content to behavior_pack/ and resource_pack/'));
    console.log(chalk.gray('  3. Copy packs to Minecraft development folders'));
  });

program
  .command('build-analyzer')
  .description('Build the Rust analyzer component')
  .action(async () => {
    console.log(chalk.cyan('Building Rust analyzer...'));
    console.log();
    
    const analyzerDir = path.join(__dirname, '..', 'rust-analyzer');
    
    if (!fs.existsSync(analyzerDir)) {
      console.error(chalk.red('Rust analyzer source not found.'));
      process.exit(1);
    }
    
    try {
      const { execSync } = require('child_process');
      execSync('cargo build --release', {
        cwd: analyzerDir,
        stdio: 'inherit',
      });
      console.log(chalk.green('✓ Rust analyzer built successfully'));
    } catch (error) {
      console.error(chalk.red('Failed to build Rust analyzer. Is Rust installed?'));
      console.log(chalk.gray('Install Rust from: https://rustup.rs/'));
      process.exit(1);
    }
  });

// Parse command line arguments
program.parse();
