/**
 * Java-to-Bedrock Mod Porter
 * 
 * Public API exports for programmatic usage.
 */

// Core porter
export { ModPorter, PorterConfig, PorterResult } from './porter';

// IR types
export * from './ir';

// Engines
export { MappingEngine, MappingResult, MappingRecord } from './mapping';
export { DegradationPolicy, DegradationResult, DegradationStrategy } from './degradation';
export { BedrockGenerator, GeneratorOptions } from './generator';
export { AddonValidator, ValidationResult, ValidationError } from './validation';
export { ReportGenerator, PortingReport, ReportOptions } from './report';

// Utilities
export { Logger, ProgressIndicator } from './utils/logger';
