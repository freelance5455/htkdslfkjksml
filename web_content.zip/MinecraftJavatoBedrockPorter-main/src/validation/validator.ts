/**
 * Validation System
 * 
 * Validates generated Bedrock addon content:
 * - JSON schema validation
 * - Script linting
 * - Reference resolution
 * - Identifier validation
 * - Optional runtime smoke tests
 */

import * as fs from 'fs';
import * as path from 'path';
import { BedrockAddonIR } from '../ir/bedrock-ir';
import { Logger } from '../utils/logger';

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
  info: ValidationInfo[];
}

export interface ValidationError {
  type: 'schema' | 'reference' | 'identifier' | 'script' | 'structure';
  file?: string;
  path?: string;
  message: string;
  line?: number;
  column?: number;
}

export interface ValidationWarning {
  type: string;
  file?: string;
  message: string;
  suggestion?: string;
}

export interface ValidationInfo {
  type: string;
  message: string;
}

export interface ValidationOptions {
  /** Validate JSON schemas */
  validateSchemas: boolean;
  
  /** Check reference resolution */
  validateReferences: boolean;
  
  /** Lint TypeScript/JavaScript */
  lintScripts: boolean;
  
  /** Validate identifiers match Bedrock conventions */
  validateIdentifiers: boolean;
  
  /** Check file structure */
  validateStructure: boolean;
  
  /** Run basic runtime checks if possible */
  runtimeChecks: boolean;
  
  /** Bedrock format version to validate against */
  formatVersion: string;
}

const DEFAULT_OPTIONS: ValidationOptions = {
  validateSchemas: true,
  validateReferences: true,
  lintScripts: true,
  validateIdentifiers: true,
  validateStructure: true,
  runtimeChecks: false,
  formatVersion: '1.20.80',
};

export class AddonValidator {
  private options: ValidationOptions;
  private logger: Logger;
  private result: ValidationResult;
  
  constructor(logger: Logger, options: Partial<ValidationOptions> = {}) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
    this.logger = logger;
    this.result = this.createEmptyResult();
  }
  
  /**
   * Validate a Bedrock addon IR before generation
   */
  validateIR(addon: BedrockAddonIR): ValidationResult {
    this.result = this.createEmptyResult();
    
    // Validate metadata
    this.validateMetadata(addon);
    
    // Validate blocks
    for (const block of addon.behaviorPack.blocks) {
      this.validateBlock(block);
    }
    
    // Validate items
    for (const item of addon.behaviorPack.items) {
      this.validateItem(item);
    }
    
    // Validate entities
    for (const entity of addon.behaviorPack.entities) {
      this.validateEntity(entity);
    }
    
    // Validate recipes
    for (const recipe of addon.behaviorPack.recipes) {
      this.validateRecipe(recipe);
    }
    
    // Validate scripts
    for (const module of addon.scripts) {
      for (const file of module.files) {
        this.validateScript(file.path, file.content);
      }
    }
    
    // Validate references
    if (this.options.validateReferences) {
      this.validateReferences(addon);
    }
    
    this.result.valid = this.result.errors.length === 0;
    return this.result;
  }
  
  /**
   * Validate generated addon files
   */
  async validateFiles(bpPath: string, rpPath: string): Promise<ValidationResult> {
    this.result = this.createEmptyResult();
    
    // Validate directory structure
    if (this.options.validateStructure) {
      this.validateDirectoryStructure(bpPath, 'behavior');
      this.validateDirectoryStructure(rpPath, 'resource');
    }
    
    // Validate all JSON files
    if (this.options.validateSchemas) {
      await this.validateAllJsonFiles(bpPath);
      await this.validateAllJsonFiles(rpPath);
    }
    
    // Validate scripts
    if (this.options.lintScripts) {
      const scriptsPath = path.join(bpPath, 'scripts');
      if (fs.existsSync(scriptsPath)) {
        await this.validateScriptFiles(scriptsPath);
      }
    }
    
    this.result.valid = this.result.errors.length === 0;
    return this.result;
  }
  
  private createEmptyResult(): ValidationResult {
    return {
      valid: true,
      errors: [],
      warnings: [],
      info: [],
    };
  }
  
  private validateMetadata(addon: BedrockAddonIR): void {
    // Validate UUIDs
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    
    if (!uuidRegex.test(addon.behaviorPack.manifest.header.uuid)) {
      this.result.errors.push({
        type: 'schema',
        message: 'Invalid behavior pack UUID format',
        path: 'behaviorPack.manifest.header.uuid',
      });
    }
    
    if (!uuidRegex.test(addon.resourcePack.manifest.header.uuid)) {
      this.result.errors.push({
        type: 'schema',
        message: 'Invalid resource pack UUID format',
        path: 'resourcePack.manifest.header.uuid',
      });
    }
    
    // Validate version format
    const validateVersion = (version: [number, number, number], location: string) => {
      if (!Array.isArray(version) || version.length !== 3) {
        this.result.errors.push({
          type: 'schema',
          message: `Invalid version format at ${location}`,
          path: location,
        });
      }
    };
    
    validateVersion(addon.metadata.version, 'metadata.version');
    validateVersion(addon.metadata.minEngineVersion, 'metadata.minEngineVersion');
    
    this.result.info.push({
      type: 'metadata',
      message: `Addon: ${addon.metadata.name} v${addon.metadata.version.join('.')}`,
    });
  }
  
  private validateBlock(block: any): void {
    // Validate identifier
    if (this.options.validateIdentifiers) {
      this.validateIdentifier(block.identifier, 'block');
    }
    
    // Validate components
    const validComponents = [
      'minecraft:destructible_by_mining',
      'minecraft:destructible_by_explosion',
      'minecraft:friction',
      'minecraft:flammable',
      'minecraft:light_emission',
      'minecraft:light_dampening',
      'minecraft:loot',
      'minecraft:map_color',
      'minecraft:geometry',
      'minecraft:material_instances',
      'minecraft:collision_box',
      'minecraft:selection_box',
      'minecraft:placement_filter',
      'minecraft:tick',
      'minecraft:crafting_table',
      'minecraft:custom_components',
    ];
    
    for (const component of Object.keys(block.components || {})) {
      if (!validComponents.includes(component) && !component.startsWith('tag:')) {
        this.result.warnings.push({
          type: 'component',
          message: `Unknown block component: ${component}`,
          file: block.identifier,
          suggestion: 'Check Bedrock documentation for valid components',
        });
      }
    }
    
    // Validate block states
    if (block.description?.states) {
      const stateCount = Object.keys(block.description.states).length;
      if (stateCount > 16) {
        this.result.errors.push({
          type: 'schema',
          message: `Block ${block.identifier} has ${stateCount} states (max 16)`,
        });
      }
    }
  }
  
  private validateItem(item: any): void {
    // Validate identifier
    if (this.options.validateIdentifiers) {
      this.validateIdentifier(item.identifier, 'item');
    }
    
    // Validate stack size
    const stackSize = item.components?.['minecraft:max_stack_size'];
    if (stackSize && (stackSize < 1 || stackSize > 64)) {
      this.result.errors.push({
        type: 'schema',
        message: `Invalid stack size ${stackSize} for item ${item.identifier}`,
      });
    }
    
    // Validate durability
    const durability = item.components?.['minecraft:durability'];
    if (durability?.maxDurability && durability.maxDurability > 32767) {
      this.result.warnings.push({
        type: 'component',
        message: `High durability value for ${item.identifier}`,
        suggestion: 'Maximum recommended durability is 32767',
      });
    }
  }
  
  private validateEntity(entity: any): void {
    // Validate identifier
    if (this.options.validateIdentifiers) {
      this.validateIdentifier(entity.identifier, 'entity');
    }
    
    // Validate health
    const health = entity.components?.['minecraft:health'];
    if (health) {
      if (health.value > health.max) {
        this.result.errors.push({
          type: 'schema',
          message: `Entity ${entity.identifier} has health value > max`,
        });
      }
    }
    
    // Validate collision box
    const collision = entity.components?.['minecraft:collision_box'];
    if (collision) {
      if (collision.width <= 0 || collision.height <= 0) {
        this.result.errors.push({
          type: 'schema',
          message: `Entity ${entity.identifier} has invalid collision box`,
        });
      }
    }
  }
  
  private validateRecipe(recipe: any): void {
    // Validate identifier
    if (this.options.validateIdentifiers) {
      this.validateIdentifier(recipe.identifier, 'recipe');
    }
    
    // Validate shaped recipe pattern
    if (recipe.pattern) {
      if (recipe.pattern.length > 3) {
        this.result.errors.push({
          type: 'schema',
          message: `Recipe ${recipe.identifier} pattern has more than 3 rows`,
        });
      }
      
      const maxWidth = Math.max(...recipe.pattern.map((r: string) => r.length));
      if (maxWidth > 3) {
        this.result.errors.push({
          type: 'schema',
          message: `Recipe ${recipe.identifier} pattern is wider than 3`,
        });
      }
      
      // Validate all keys are defined
      const usedKeys = new Set(recipe.pattern.join('').replace(/ /g, '').split(''));
      const definedKeys = new Set(Object.keys(recipe.key || {}));
      
      for (const key of usedKeys) {
        if (!definedKeys.has(key as string)) {
          this.result.errors.push({
            type: 'reference',
            message: `Recipe ${recipe.identifier} uses undefined key: ${key}`,
          });
        }
      }
    }
    
    // Validate output
    if (!recipe.result && !recipe.output) {
      this.result.errors.push({
        type: 'schema',
        message: `Recipe ${recipe.identifier} has no output`,
      });
    }
  }
  
  private validateScript(filePath: string, content: string): void {
    // Basic syntax validation
    const errors = this.lintScript(content);
    
    for (const error of errors) {
      this.result.errors.push({
        type: 'script',
        file: filePath,
        message: error.message,
        line: error.line,
        column: error.column,
      });
    }
    
    // Check for common issues
    if (content.includes('require(')) {
      this.result.warnings.push({
        type: 'script',
        file: filePath,
        message: 'Using require() - Bedrock scripts should use ES modules',
        suggestion: 'Use import/export syntax instead',
      });
    }
    
    if (content.includes('console.log') && !content.includes('// debug')) {
      this.result.warnings.push({
        type: 'script',
        file: filePath,
        message: 'console.log statements found',
        suggestion: 'Consider removing for production',
      });
    }
  }
  
  private lintScript(content: string): Array<{ message: string; line: number; column: number }> {
    const errors: Array<{ message: string; line: number; column: number }> = [];
    const lines = content.split('\n');
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const lineNum = i + 1;
      
      // Check for obvious syntax errors
      const openBraces = (line.match(/{/g) || []).length;
      const closeBraces = (line.match(/}/g) || []).length;
      const openParens = (line.match(/\(/g) || []).length;
      const closeParens = (line.match(/\)/g) || []).length;
      
      // Check for unclosed strings
      const singleQuotes = (line.match(/'/g) || []).length;
      const doubleQuotes = (line.match(/"/g) || []).length;
      const backticks = (line.match(/`/g) || []).length;
      
      if (singleQuotes % 2 !== 0 && !line.includes('\\\'')) {
        errors.push({
          message: 'Unclosed string literal',
          line: lineNum,
          column: line.indexOf('\''),
        });
      }
      
      // Check for common typos
      if (line.includes('funciton') || line.includes('fucntion')) {
        errors.push({
          message: 'Possible typo: "function"',
          line: lineNum,
          column: line.indexOf('funciton') !== -1 ? line.indexOf('funciton') : line.indexOf('fucntion'),
        });
      }
    }
    
    return errors;
  }
  
  private validateIdentifier(identifier: string, type: string): void {
    if (!identifier) {
      this.result.errors.push({
        type: 'identifier',
        message: `Missing ${type} identifier`,
      });
      return;
    }
    
    // Check namespace
    if (!identifier.includes(':')) {
      this.result.warnings.push({
        type: 'identifier',
        message: `${type} identifier missing namespace: ${identifier}`,
        suggestion: 'Add namespace prefix (e.g., mymod:item_name)',
      });
    }
    
    // Check for invalid characters
    const parts = identifier.split(':');
    const name = parts[parts.length - 1];
    
    if (!/^[a-z0-9_]+$/.test(name)) {
      this.result.errors.push({
        type: 'identifier',
        message: `Invalid ${type} identifier: ${identifier}`,
      });
    }
    
    // Check for reserved names
    const reservedPrefixes = ['minecraft', 'mojang', 'realms'];
    const namespace = parts[0];
    
    if (reservedPrefixes.includes(namespace) && namespace !== 'minecraft') {
      this.result.warnings.push({
        type: 'identifier',
        message: `${type} uses reserved namespace: ${namespace}`,
        suggestion: 'Use a unique namespace for your addon',
      });
    }
  }
  
  private validateReferences(addon: BedrockAddonIR): void {
    // Collect all defined identifiers
    const definedBlocks = new Set(addon.behaviorPack.blocks.map(b => b.identifier));
    const definedItems = new Set(addon.behaviorPack.items.map(i => i.identifier));
    const definedEntities = new Set(addon.behaviorPack.entities.map(e => e.identifier));
    
    // Check recipe references
    for (const recipe of addon.behaviorPack.recipes) {
      const checkItem = (itemId: string, context: string) => {
        if (itemId.startsWith('minecraft:')) return; // Vanilla item
        if (!definedItems.has(itemId) && !definedBlocks.has(itemId)) {
          this.result.warnings.push({
            type: 'reference',
            message: `Recipe ${recipe.identifier} ${context} references unknown item: ${itemId}`,
          });
        }
      };
      
      // Check inputs
      if (recipe.ingredients) {
        for (const ing of recipe.ingredients) {
          if (ing.item) checkItem(ing.item, 'ingredient');
        }
      }
      if (recipe.key) {
        for (const key of Object.values(recipe.key)) {
          if (key.item) checkItem(key.item, 'key');
        }
      }
      
      // Check output
      if (recipe.result?.item) {
        checkItem(recipe.result.item, 'result');
      }
      if (recipe.output) {
        const outputs = Array.isArray(recipe.output) ? recipe.output : [recipe.output];
        for (const output of outputs) {
          if (output.item) checkItem(output.item, 'output');
        }
      }
    }
    
    // Check loot table references
    for (const block of addon.behaviorPack.blocks) {
      const loot = block.components?.['minecraft:loot'];
      if (loot && typeof loot === 'string') {
        // Would check if loot table exists
      }
    }
    
    for (const entity of addon.behaviorPack.entities) {
      const loot = entity.components?.['minecraft:loot'];
      if (loot && typeof loot === 'object' && 'table' in loot) {
        // Would check if loot table exists
      }
    }
  }
  
  private validateDirectoryStructure(packPath: string, packType: 'behavior' | 'resource'): void {
    if (!fs.existsSync(packPath)) {
      this.result.errors.push({
        type: 'structure',
        message: `${packType} pack directory does not exist: ${packPath}`,
      });
      return;
    }
    
    // Check for manifest
    const manifestPath = path.join(packPath, 'manifest.json');
    if (!fs.existsSync(manifestPath)) {
      this.result.errors.push({
        type: 'structure',
        file: manifestPath,
        message: `Missing manifest.json in ${packType} pack`,
      });
    }
    
    // Check expected directories
    const expectedDirs = packType === 'behavior'
      ? ['entities', 'items', 'blocks', 'recipes']
      : ['textures', 'texts'];
    
    for (const dir of expectedDirs) {
      const dirPath = path.join(packPath, dir);
      if (!fs.existsSync(dirPath)) {
        this.result.info.push({
          type: 'structure',
          message: `Optional directory not present: ${dir}`,
        });
      }
    }
  }
  
  private async validateAllJsonFiles(dirPath: string): Promise<void> {
    if (!fs.existsSync(dirPath)) return;
    
    const files = this.getAllFiles(dirPath);
    
    for (const file of files) {
      if (file.endsWith('.json')) {
        try {
          const content = fs.readFileSync(file, 'utf-8');
          JSON.parse(content);
        } catch (error) {
          this.result.errors.push({
            type: 'schema',
            file,
            message: `Invalid JSON: ${(error as Error).message}`,
          });
        }
      }
    }
  }
  
  private async validateScriptFiles(scriptsPath: string): Promise<void> {
    const files = this.getAllFiles(scriptsPath);
    
    for (const file of files) {
      if (file.endsWith('.ts') || file.endsWith('.js')) {
        const content = fs.readFileSync(file, 'utf-8');
        this.validateScript(file, content);
      }
    }
  }
  
  private getAllFiles(dirPath: string): string[] {
    const files: string[] = [];
    
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      if (entry.isDirectory()) {
        files.push(...this.getAllFiles(fullPath));
      } else {
        files.push(fullPath);
      }
    }
    
    return files;
  }
}
