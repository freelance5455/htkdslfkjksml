/**
 * Report Generator
 * 
 * Outputs a detailed summary of the porting process:
 * - What was ported successfully
 * - What was approximated with differences noted
 * - What was omitted and why
 * - Behavioral differences
 * - TODO notes for advanced users
 */

import * as fs from 'fs';
import * as path from 'path';
import { ModIR } from '../ir/java-ir';
import { MappingResult, MappingRecord } from '../mapping';
import { DegradationResult } from '../degradation';
import { ValidationResult } from '../validation';

export interface ReportOptions {
  /** Output format */
  format: 'markdown' | 'json' | 'html';
  
  /** Include detailed mapping information */
  includeDetails: boolean;
  
  /** Include code snippets for differences */
  includeCode: boolean;
  
  /** Include TODO items */
  includeTodos: boolean;
  
  /** Include statistics */
  includeStats: boolean;
}

const DEFAULT_OPTIONS: ReportOptions = {
  format: 'markdown',
  includeDetails: true,
  includeCode: true,
  includeTodos: true,
  includeStats: true,
};

export interface PortingReport {
  /** Report generation timestamp */
  timestamp: string;
  
  /** Source mod information */
  sourceMod: {
    name: string;
    version: string;
    loader: string;
  };
  
  /** Summary statistics */
  statistics: PortingStatistics;
  
  /** Successfully ported features */
  ported: PortedFeature[];
  
  /** Features that required approximation */
  approximated: ApproximatedFeature[];
  
  /** Features that were omitted */
  omitted: OmittedFeature[];
  
  /** Validation results */
  validation: ValidationSummary;
  
  /** TODO items for manual review */
  todos: TodoItem[];
  
  /** Known behavioral differences */
  differences: BehavioralDifference[];
}

export interface PortingStatistics {
  totalFeatures: number;
  portedSuccessfully: number;
  approximated: number;
  simplified: number;
  omitted: number;
  
  blocks: { total: number; ported: number };
  items: { total: number; ported: number };
  entities: { total: number; ported: number };
  recipes: { total: number; ported: number };
  eventHandlers: { total: number; ported: number };
  
  successRate: number;
}

export interface PortedFeature {
  type: string;
  sourceId: string;
  targetId: string;
  strategy: string;
  notes: string[];
}

export interface ApproximatedFeature {
  type: string;
  sourceId: string;
  targetId: string;
  originalBehavior: string;
  approximatedBehavior: string;
  differences: string[];
  severity: string;
}

export interface OmittedFeature {
  type: string;
  sourceId: string;
  reason: string;
  suggestion?: string;
}

export interface ValidationSummary {
  passed: boolean;
  errorCount: number;
  warningCount: number;
  errors: string[];
  warnings: string[];
}

export interface TodoItem {
  priority: 'high' | 'medium' | 'low';
  category: string;
  description: string;
  file?: string;
  code?: string;
}

export interface BehavioralDifference {
  feature: string;
  javaVersion: string;
  bedrockVersion: string;
  impact: 'cosmetic' | 'functional' | 'significant';
}

export class ReportGenerator {
  private options: ReportOptions;
  
  constructor(options: Partial<ReportOptions> = {}) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
  }
  
  /**
   * Generate a complete porting report
   */
  generate(
    javaIR: ModIR,
    mappingResult: MappingResult,
    validationResult: ValidationResult
  ): PortingReport {
    const report: PortingReport = {
      timestamp: new Date().toISOString(),
      sourceMod: {
        name: javaIR.metadata.name,
        version: javaIR.metadata.version,
        loader: javaIR.loader,
      },
      statistics: this.calculateStatistics(javaIR, mappingResult),
      ported: this.extractPortedFeatures(mappingResult),
      approximated: this.extractApproximatedFeatures(mappingResult),
      omitted: this.extractOmittedFeatures(mappingResult),
      validation: this.summarizeValidation(validationResult),
      todos: this.generateTodos(javaIR, mappingResult),
      differences: this.identifyDifferences(javaIR, mappingResult),
    };
    
    return report;
  }
  
  /**
   * Format report as markdown
   */
  formatMarkdown(report: PortingReport): string {
    const lines: string[] = [];
    
    // Header
    lines.push(`# Porting Report: ${report.sourceMod.name}`);
    lines.push('');
    lines.push(`**Generated:** ${new Date(report.timestamp).toLocaleString()}`);
    lines.push(`**Source Version:** ${report.sourceMod.version}`);
    lines.push(`**Mod Loader:** ${report.sourceMod.loader}`);
    lines.push('');
    
    // Summary
    lines.push('## Summary');
    lines.push('');
    lines.push(`| Metric | Value |`);
    lines.push(`|--------|-------|`);
    lines.push(`| Total Features | ${report.statistics.totalFeatures} |`);
    lines.push(`| Successfully Ported | ${report.statistics.portedSuccessfully} |`);
    lines.push(`| Approximated | ${report.statistics.approximated} |`);
    lines.push(`| Simplified | ${report.statistics.simplified} |`);
    lines.push(`| Omitted | ${report.statistics.omitted} |`);
    lines.push(`| **Success Rate** | **${report.statistics.successRate.toFixed(1)}%** |`);
    lines.push('');
    
    // Detailed breakdown
    if (this.options.includeStats) {
      lines.push('### Feature Breakdown');
      lines.push('');
      lines.push(`| Feature Type | Total | Ported |`);
      lines.push(`|--------------|-------|--------|`);
      lines.push(`| Blocks | ${report.statistics.blocks.total} | ${report.statistics.blocks.ported} |`);
      lines.push(`| Items | ${report.statistics.items.total} | ${report.statistics.items.ported} |`);
      lines.push(`| Entities | ${report.statistics.entities.total} | ${report.statistics.entities.ported} |`);
      lines.push(`| Recipes | ${report.statistics.recipes.total} | ${report.statistics.recipes.ported} |`);
      lines.push(`| Event Handlers | ${report.statistics.eventHandlers.total} | ${report.statistics.eventHandlers.ported} |`);
      lines.push('');
    }
    
    // Successfully ported
    if (this.options.includeDetails && report.ported.length > 0) {
      lines.push('## Successfully Ported Features');
      lines.push('');
      
      const byType = this.groupBy(report.ported, 'type');
      for (const [type, features] of Object.entries(byType)) {
        lines.push(`### ${this.capitalize(type)}s`);
        lines.push('');
        for (const feature of features as PortedFeature[]) {
          lines.push(`- **${feature.sourceId}** → \`${feature.targetId}\``);
          if (feature.notes.length > 0) {
            for (const note of feature.notes) {
              lines.push(`  - ${note}`);
            }
          }
        }
        lines.push('');
      }
    }
    
    // Approximated features
    if (report.approximated.length > 0) {
      lines.push('## Approximated Features');
      lines.push('');
      lines.push('> These features were ported with modifications. Review the differences carefully.');
      lines.push('');
      
      for (const feature of report.approximated) {
        lines.push(`### ${feature.sourceId}`);
        lines.push('');
        lines.push(`- **Type:** ${feature.type}`);
        lines.push(`- **Target:** \`${feature.targetId}\``);
        lines.push(`- **Severity:** ${feature.severity}`);
        lines.push('');
        lines.push('**Differences:**');
        for (const diff of feature.differences) {
          lines.push(`- ${diff}`);
        }
        lines.push('');
      }
    }
    
    // Omitted features
    if (report.omitted.length > 0) {
      lines.push('## Omitted Features');
      lines.push('');
      lines.push('> These features could not be ported to Bedrock Edition.');
      lines.push('');
      
      for (const feature of report.omitted) {
        lines.push(`- **${feature.sourceId}** (${feature.type})`);
        lines.push(`  - Reason: ${feature.reason}`);
        if (feature.suggestion) {
          lines.push(`  - Suggestion: ${feature.suggestion}`);
        }
      }
      lines.push('');
    }
    
    // Behavioral differences
    if (report.differences.length > 0) {
      lines.push('## Behavioral Differences');
      lines.push('');
      lines.push('| Feature | Java Behavior | Bedrock Behavior | Impact |');
      lines.push('|---------|---------------|------------------|--------|');
      for (const diff of report.differences) {
        lines.push(`| ${diff.feature} | ${diff.javaVersion} | ${diff.bedrockVersion} | ${diff.impact} |`);
      }
      lines.push('');
    }
    
    // Validation
    lines.push('## Validation Results');
    lines.push('');
    if (report.validation.passed) {
      lines.push('✅ **Validation passed**');
    } else {
      lines.push('❌ **Validation failed**');
    }
    lines.push('');
    lines.push(`- Errors: ${report.validation.errorCount}`);
    lines.push(`- Warnings: ${report.validation.warningCount}`);
    lines.push('');
    
    if (report.validation.errors.length > 0) {
      lines.push('### Errors');
      for (const error of report.validation.errors) {
        lines.push(`- ❌ ${error}`);
      }
      lines.push('');
    }
    
    if (report.validation.warnings.length > 0) {
      lines.push('### Warnings');
      for (const warning of report.validation.warnings) {
        lines.push(`- ⚠️ ${warning}`);
      }
      lines.push('');
    }
    
    // TODOs
    if (this.options.includeTodos && report.todos.length > 0) {
      lines.push('## TODO Items');
      lines.push('');
      lines.push('> Manual review and implementation needed for these items.');
      lines.push('');
      
      const byPriority = this.groupBy(report.todos, 'priority');
      
      if (byPriority['high']) {
        lines.push('### High Priority');
        for (const todo of byPriority['high'] as TodoItem[]) {
          lines.push(`- [ ] **[${todo.category}]** ${todo.description}`);
          if (todo.file) {
            lines.push(`  - File: \`${todo.file}\``);
          }
        }
        lines.push('');
      }
      
      if (byPriority['medium']) {
        lines.push('### Medium Priority');
        for (const todo of byPriority['medium'] as TodoItem[]) {
          lines.push(`- [ ] **[${todo.category}]** ${todo.description}`);
          if (todo.file) {
            lines.push(`  - File: \`${todo.file}\``);
          }
        }
        lines.push('');
      }
      
      if (byPriority['low']) {
        lines.push('### Low Priority');
        for (const todo of byPriority['low'] as TodoItem[]) {
          lines.push(`- [ ] **[${todo.category}]** ${todo.description}`);
          if (todo.file) {
            lines.push(`  - File: \`${todo.file}\``);
          }
        }
        lines.push('');
      }
    }
    
    // Footer
    lines.push('---');
    lines.push('');
    lines.push('*Generated by Java-to-Bedrock Mod Porter*');
    
    return lines.join('\n');
  }
  
  /**
   * Format report as JSON
   */
  formatJson(report: PortingReport): string {
    return JSON.stringify(report, null, 2);
  }
  
  /**
   * Format report as HTML
   */
  formatHtml(report: PortingReport): string {
    const markdown = this.formatMarkdown(report);
    
    // Basic markdown to HTML conversion
    let html = markdown
      .replace(/^# (.+)$/gm, '<h1>$1</h1>')
      .replace(/^## (.+)$/gm, '<h2>$1</h2>')
      .replace(/^### (.+)$/gm, '<h3>$1</h3>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/`(.+?)`/g, '<code>$1</code>')
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/^\| (.+) \|$/gm, (match) => {
        const cells = match.split('|').filter(c => c.trim());
        return '<tr>' + cells.map(c => `<td>${c.trim()}</td>`).join('') + '</tr>';
      });
    
    return `<!DOCTYPE html>
<html>
<head>
  <title>Porting Report: ${report.sourceMod.name}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; }
    h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
    h2 { color: #34495e; margin-top: 30px; }
    h3 { color: #7f8c8d; }
    table { border-collapse: collapse; width: 100%; margin: 15px 0; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #3498db; color: white; }
    tr:nth-child(even) { background-color: #f9f9f9; }
    code { background-color: #f4f4f4; padding: 2px 6px; border-radius: 3px; }
    blockquote { border-left: 4px solid #3498db; padding-left: 15px; color: #666; }
    .success { color: #27ae60; }
    .error { color: #e74c3c; }
    .warning { color: #f39c12; }
  </style>
</head>
<body>
  ${html}
</body>
</html>`;
  }
  
  /**
   * Save report to file
   */
  save(report: PortingReport, outputPath: string): void {
    let content: string;
    
    switch (this.options.format) {
      case 'json':
        content = this.formatJson(report);
        break;
      case 'html':
        content = this.formatHtml(report);
        break;
      case 'markdown':
      default:
        content = this.formatMarkdown(report);
        break;
    }
    
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    fs.writeFileSync(outputPath, content);
  }
  
  private calculateStatistics(javaIR: ModIR, result: MappingResult): PortingStatistics {
    const total = result.mappings.length;
    const ported = result.mappings.filter(m => m.success && m.strategy === 'direct').length;
    const approximated = result.degradations.filter(d => d.strategy === 'approximate').length;
    const simplified = result.degradations.filter(d => d.strategy === 'simplify').length;
    const omitted = result.degradations.filter(d => d.strategy === 'omit').length;
    
    const countByType = (type: string) => ({
      total: result.mappings.filter(m => m.sourceType === type).length,
      ported: result.mappings.filter(m => m.sourceType === type && m.success).length,
    });
    
    return {
      totalFeatures: total,
      portedSuccessfully: ported,
      approximated,
      simplified,
      omitted,
      blocks: countByType('block'),
      items: countByType('item'),
      entities: countByType('entity'),
      recipes: countByType('recipe'),
      eventHandlers: countByType('event'),
      successRate: total > 0 ? ((ported + approximated + simplified) / total) * 100 : 0,
    };
  }
  
  private extractPortedFeatures(result: MappingResult): PortedFeature[] {
    return result.mappings
      .filter(m => m.success)
      .map(m => ({
        type: m.sourceType,
        sourceId: m.sourceId,
        targetId: m.targetId,
        strategy: m.strategy,
        notes: m.notes,
      }));
  }
  
  private extractApproximatedFeatures(result: MappingResult): ApproximatedFeature[] {
    return result.degradations
      .filter(d => d.strategy === 'approximate' || d.strategy === 'simplify')
      .map(d => ({
        type: d.category,
        sourceId: d.originalFeature,
        targetId: d.replacement || 'N/A',
        originalBehavior: d.explanation,
        approximatedBehavior: d.replacement || 'Simplified version',
        differences: d.differences,
        severity: d.severity,
      }));
  }
  
  private extractOmittedFeatures(result: MappingResult): OmittedFeature[] {
    return result.degradations
      .filter(d => d.strategy === 'omit' || d.strategy === 'stub')
      .map(d => ({
        type: d.category,
        sourceId: d.originalFeature,
        reason: d.explanation,
        suggestion: d.suggestions[0],
      }));
  }
  
  private summarizeValidation(result: ValidationResult): ValidationSummary {
    return {
      passed: result.valid,
      errorCount: result.errors.length,
      warningCount: result.warnings.length,
      errors: result.errors.slice(0, 10).map(e => e.message),
      warnings: result.warnings.slice(0, 10).map(w => w.message),
    };
  }
  
  private generateTodos(javaIR: ModIR, result: MappingResult): TodoItem[] {
    const todos: TodoItem[] = [];
    
    // Add TODOs for complex behaviors
    for (const degradation of result.degradations) {
      if (degradation.severity === 'high' || degradation.severity === 'critical') {
        todos.push({
          priority: degradation.severity === 'critical' ? 'high' : 'medium',
          category: degradation.category,
          description: `Review ${degradation.originalFeature}: ${degradation.explanation}`,
        });
      }
    }
    
    // Add TODOs for advanced features
    if (javaIR.advancedFeatures.usesMixins) {
      todos.push({
        priority: 'high',
        category: 'mixin',
        description: `Review mixin classes for manual implementation: ${javaIR.advancedFeatures.mixinClasses.join(', ')}`,
      });
    }
    
    // Add TODOs for GUIs
    for (const gui of javaIR.guis) {
      todos.push({
        priority: 'medium',
        category: 'gui',
        description: `GUI ${gui.id} converted to forms - review user experience`,
      });
    }
    
    // Add TODOs for renderers
    for (const renderer of javaIR.renderers) {
      todos.push({
        priority: 'low',
        category: 'rendering',
        description: `Custom renderer ${renderer.className} was omitted - visual differences expected`,
      });
    }
    
    return todos;
  }
  
  private identifyDifferences(javaIR: ModIR, result: MappingResult): BehavioralDifference[] {
    const differences: BehavioralDifference[] = [];
    
    // Standard platform differences
    differences.push({
      feature: 'NBT Data',
      javaVersion: 'Full NBT compound support',
      bedrockVersion: 'Limited dynamic properties',
      impact: 'functional',
    });
    
    if (javaIR.guis.length > 0) {
      differences.push({
        feature: 'Custom GUIs',
        javaVersion: 'Pixel-perfect custom screens',
        bedrockVersion: 'Form-based or JSON UI',
        impact: 'significant',
      });
    }
    
    if (javaIR.eventHandlers.length > 0) {
      differences.push({
        feature: 'Event Timing',
        javaVersion: 'Before/After events with cancellation',
        bedrockVersion: 'Some events not cancellable',
        impact: 'functional',
      });
    }
    
    return differences;
  }
  
  private groupBy<T>(array: T[], key: keyof T): Record<string, T[]> {
    return array.reduce((result, item) => {
      const group = String(item[key]);
      (result[group] = result[group] || []).push(item);
      return result;
    }, {} as Record<string, T[]>);
  }
  
  private capitalize(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
}
