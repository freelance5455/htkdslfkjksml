/**
 * Mapping Engine
 * 
 * Maps Java mod IR to Bedrock addon IR using various strategies:
 * - Direct mappings (1:1 property conversions)
 * - Pattern mappings (common Forge/Fabric patterns)
 * - AI-assisted mappings (for complex logic)
 * - Fallback mappings (when direct translation isn't possible)
 */

import { v4 as uuidv4 } from 'uuid';
import {
  ModIR,
  BlockIR,
  ItemIR,
  EntityIR,
  RecipeIR,
  BehaviorIR,
  Complexity,
  EntityType,
  RecipeType,
} from '../ir/java-ir';
import {
  BedrockAddonIR,
  BedrockBlock,
  BedrockItem,
  BedrockEntity,
  BedrockRecipe,
  BlockComponents,
  ItemComponents,
  EntityComponents,
  ScriptFile,
  createEmptyBedrockAddonIR,
} from '../ir/bedrock-ir';
import { BEDROCK_CAPABILITIES, getScriptEventMapping } from '../capabilities';
import { DegradationPolicy, DegradationResult } from '../degradation';
import { Logger } from '../utils/logger';

export interface MappingResult {
  addon: BedrockAddonIR;
  mappings: MappingRecord[];
  degradations: DegradationResult[];
  warnings: string[];
  errors: string[];
}

export interface MappingRecord {
  sourceType: 'block' | 'item' | 'entity' | 'recipe' | 'event' | 'worldgen' | 'gui';
  sourceId: string;
  targetId: string;
  strategy: 'direct' | 'pattern' | 'ai' | 'fallback';
  success: boolean;
  notes: string[];
}

export class MappingEngine {
  private logger: Logger;
  private degradationPolicy: DegradationPolicy;
  private namespace: string = '';
  
  constructor(logger: Logger, degradationPolicy: DegradationPolicy) {
    this.logger = logger;
    this.degradationPolicy = degradationPolicy;
  }
  
  /**
   * Map a complete Java mod IR to Bedrock addon IR
   */
  async map(javaIR: ModIR): Promise<MappingResult> {
    this.namespace = javaIR.metadata.modId.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    
    const result: MappingResult = {
      addon: createEmptyBedrockAddonIR(),
      mappings: [],
      degradations: [],
      warnings: [],
      errors: [],
    };
    
    // Set up metadata
    this.mapMetadata(javaIR, result);
    
    // Map blocks
    for (const block of javaIR.blocks) {
      try {
        const mapped = await this.mapBlock(block);
        result.addon.behaviorPack.blocks.push(mapped.block);
        result.mappings.push(mapped.record);
        if (mapped.degradation) {
          result.degradations.push(mapped.degradation);
        }
      } catch (error) {
        result.errors.push(`Failed to map block ${block.id}: ${error}`);
      }
    }
    
    // Map items
    for (const item of javaIR.items) {
      try {
        const mapped = await this.mapItem(item);
        result.addon.behaviorPack.items.push(mapped.item);
        result.mappings.push(mapped.record);
        if (mapped.degradation) {
          result.degradations.push(mapped.degradation);
        }
      } catch (error) {
        result.errors.push(`Failed to map item ${item.id}: ${error}`);
      }
    }
    
    // Map entities
    for (const entity of javaIR.entities) {
      try {
        const mapped = await this.mapEntity(entity);
        result.addon.behaviorPack.entities.push(mapped.entity);
        result.mappings.push(mapped.record);
        if (mapped.degradation) {
          result.degradations.push(mapped.degradation);
        }
      } catch (error) {
        result.errors.push(`Failed to map entity ${entity.id}: ${error}`);
      }
    }
    
    // Map recipes
    for (const recipe of javaIR.recipes) {
      try {
        const mapped = this.mapRecipe(recipe);
        if (mapped) {
          result.addon.behaviorPack.recipes.push(mapped.recipe);
          result.mappings.push(mapped.record);
        }
      } catch (error) {
        result.errors.push(`Failed to map recipe ${recipe.id}: ${error}`);
      }
    }
    
    // Generate scripts for behaviors and events
    const scripts = await this.generateScripts(javaIR, result);
    result.addon.scripts = scripts;
    
    // Generate texture atlases
    this.generateTextureAtlases(javaIR, result);
    
    // Generate lang files
    this.generateLangFiles(javaIR, result);
    
    // Log summary
    this.logger.info(`Mapped ${result.mappings.filter(m => m.success).length}/${result.mappings.length} features`);
    this.logger.info(`${result.degradations.length} features required degradation`);
    
    return result;
  }
  
  private mapMetadata(javaIR: ModIR, result: MappingResult): void {
    const bpUuid = uuidv4();
    const rpUuid = uuidv4();
    const bpModuleUuid = uuidv4();
    const rpModuleUuid = uuidv4();
    const scriptModuleUuid = uuidv4();
    
    result.addon.metadata = {
      name: javaIR.metadata.name || javaIR.metadata.modId,
      description: javaIR.metadata.description || `Ported from ${javaIR.metadata.modId}`,
      version: this.parseVersion(javaIR.metadata.version),
      minEngineVersion: BEDROCK_CAPABILITIES.minVersion,
      uuid: bpUuid,
      authors: javaIR.metadata.authors,
      license: 'MIT',
    };
    
    // Behavior pack manifest
    result.addon.behaviorPack.manifest = {
      formatVersion: 2,
      header: {
        name: `${javaIR.metadata.name} (Behavior)`,
        description: result.addon.metadata.description,
        uuid: bpUuid,
        version: result.addon.metadata.version,
        minEngineVersion: result.addon.metadata.minEngineVersion,
      },
      modules: [
        {
          type: 'data',
          uuid: bpModuleUuid,
          version: result.addon.metadata.version,
        },
        {
          type: 'script',
          uuid: scriptModuleUuid,
          version: result.addon.metadata.version,
          entry: 'scripts/main.js',
          language: 'javascript',
        },
      ],
      dependencies: [
        {
          uuid: rpUuid,
          version: result.addon.metadata.version,
        },
        {
          moduleName: '@minecraft/server',
          version: [1, 12, 0],
        },
        {
          moduleName: '@minecraft/server-ui',
          version: [1, 3, 0],
        },
      ],
    };
    
    // Resource pack manifest
    result.addon.resourcePack.manifest = {
      formatVersion: 2,
      header: {
        name: `${javaIR.metadata.name} (Resources)`,
        description: result.addon.metadata.description,
        uuid: rpUuid,
        version: result.addon.metadata.version,
        minEngineVersion: result.addon.metadata.minEngineVersion,
      },
      modules: [
        {
          type: 'resources',
          uuid: rpModuleUuid,
          version: result.addon.metadata.version,
        },
      ],
      dependencies: [],
    };
  }
  
  private parseVersion(version: string): [number, number, number] {
    const parts = version.replace(/[^0-9.]/g, '').split('.');
    return [
      parseInt(parts[0] || '1', 10),
      parseInt(parts[1] || '0', 10),
      parseInt(parts[2] || '0', 10),
    ];
  }
  
  private async mapBlock(block: BlockIR): Promise<{
    block: BedrockBlock;
    record: MappingRecord;
    degradation?: DegradationResult;
  }> {
    const identifier = `${this.namespace}:${block.registryName}`;
    const record: MappingRecord = {
      sourceType: 'block',
      sourceId: block.id,
      targetId: identifier,
      strategy: 'direct',
      success: true,
      notes: [],
    };
    
    const components: BlockComponents = {};
    
    // Map hardness to destructible_by_mining
    if (block.properties.hardness >= 0) {
      components['minecraft:destructible_by_mining'] = {
        secondsToDestroy: block.properties.hardness * 1.5,
      };
    }
    
    // Map resistance to destructible_by_explosion
    if (block.properties.resistance > 0) {
      components['minecraft:destructible_by_explosion'] = {
        explosionResistance: block.properties.resistance,
      };
    }
    
    // Map light level
    if (block.properties.lightLevel > 0) {
      components['minecraft:light_emission'] = block.properties.lightLevel;
    }
    
    // Map flammability
    if (block.properties.flammable) {
      components['minecraft:flammable'] = {
        catchChanceModifier: 20,
        destroyChanceModifier: 20,
      };
    }
    
    // Map collision
    if (!block.properties.hasCollision) {
      components['minecraft:collision_box'] = false;
    }
    
    // Map loot table
    if (block.lootTable) {
      components['minecraft:loot'] = `loot_tables/blocks/${block.registryName}.json`;
    }
    
    // Check for behaviors that need script components
    const complexBehaviors = block.behaviors.filter(
      (b) => b.complexity === 'complex' || b.complexity === 'very_complex'
    );
    
    if (complexBehaviors.length > 0) {
      components['minecraft:custom_components'] = [`${this.namespace}:${block.registryName}_behavior`];
      record.notes.push(`${complexBehaviors.length} behaviors converted to custom components`);
    }
    
    // Build block states
    const states: Record<string, string[] | number[] | boolean[]> = {};
    for (const state of block.states) {
      if (state.values.every((v) => v === 'true' || v === 'false')) {
        states[`${this.namespace}:${state.name}`] = [true, false];
      } else if (state.values.every((v) => !isNaN(parseInt(v, 10)))) {
        states[`${this.namespace}:${state.name}`] = state.values.map((v) => parseInt(v, 10));
      } else {
        states[`${this.namespace}:${state.name}`] = state.values;
      }
    }
    
    const bedrockBlock: BedrockBlock = {
      identifier,
      formatVersion: '1.20.80',
      description: {
        identifier,
        menuCategory: {
          category: 'construction',
          group: 'itemGroup.name.custom',
        },
        states: Object.keys(states).length > 0 ? states : undefined,
      },
      components,
    };
    
    return { block: bedrockBlock, record };
  }
  
  private async mapItem(item: ItemIR): Promise<{
    item: BedrockItem;
    record: MappingRecord;
    degradation?: DegradationResult;
  }> {
    const identifier = `${this.namespace}:${item.registryName}`;
    const record: MappingRecord = {
      sourceType: 'item',
      sourceId: item.id,
      targetId: identifier,
      strategy: 'direct',
      success: true,
      notes: [],
    };
    
    const components: ItemComponents = {
      'minecraft:icon': { texture: item.registryName },
      'minecraft:max_stack_size': item.properties.maxStackSize,
    };
    
    // Map durability
    if (item.properties.durability) {
      components['minecraft:durability'] = {
        maxDurability: item.properties.durability,
      };
    }
    
    // Map food properties
    if (item.properties.isFood && item.properties.foodProperties) {
      const food = item.properties.foodProperties;
      components['minecraft:food'] = {
        nutrition: food.nutrition,
        saturationModifier: food.saturation,
        canAlwaysEat: food.canAlwaysEat,
        effects: food.effects.map((e) => ({
          name: this.mapEffectId(e.effectId),
          duration: e.duration,
          amplifier: e.amplifier,
          chance: e.probability,
        })),
      };
    }
    
    // Map tool properties
    if (item.properties.toolProperties) {
      const tool = item.properties.toolProperties;
      components['minecraft:damage'] = tool.attackDamage;
      components['minecraft:hand_equipped'] = true;
      
      // Add digger component based on tool type
      record.notes.push(`Tool type: ${tool.toolType}`);
    }
    
    // Map armor properties
    if (item.properties.armorProperties) {
      const armor = item.properties.armorProperties;
      components['minecraft:wearable'] = {
        slot: this.mapArmorSlot(armor.slot),
      };
      record.notes.push(`Armor slot: ${armor.slot}`);
    }
    
    // Check for behaviors that need script components
    const complexBehaviors = item.behaviors.filter(
      (b) => b.complexity === 'complex' || b.complexity === 'very_complex'
    );
    
    if (complexBehaviors.length > 0) {
      components['minecraft:custom_components'] = [`${this.namespace}:${item.registryName}_behavior`];
      record.notes.push(`${complexBehaviors.length} behaviors converted to custom components`);
    }
    
    const bedrockItem: BedrockItem = {
      identifier,
      formatVersion: '1.20.80',
      description: {
        identifier,
        menuCategory: {
          category: this.mapCreativeTab(item.properties.creativeTab),
        },
      },
      components,
    };
    
    return { item: bedrockItem, record };
  }
  
  private async mapEntity(entity: EntityIR): Promise<{
    entity: BedrockEntity;
    record: MappingRecord;
    degradation?: DegradationResult;
  }> {
    const identifier = `${this.namespace}:${entity.registryName}`;
    const record: MappingRecord = {
      sourceType: 'entity',
      sourceId: entity.id,
      targetId: identifier,
      strategy: 'direct',
      success: true,
      notes: [],
    };
    
    const components: EntityComponents = {
      'minecraft:type_family': {
        family: [this.mapEntityFamily(entity.entityType)],
      },
      'minecraft:collision_box': {
        width: entity.properties.width,
        height: entity.properties.height,
      },
      'minecraft:health': {
        value: entity.properties.maxHealth,
        max: entity.properties.maxHealth,
      },
      'minecraft:movement': {
        value: entity.properties.movementSpeed,
      },
      'minecraft:physics': {},
      'minecraft:pushable': {},
    };
    
    // Add navigation and basic movement
    components['minecraft:movement.basic'] = {};
    components['minecraft:jump.static'] = {};
    components['minecraft:navigation.walk'] = {
      canWalk: true,
      canSwim: true,
    };
    
    // Add attack if applicable
    if (entity.properties.attackDamage > 0) {
      components['minecraft:attack'] = {
        damage: entity.properties.attackDamage,
      };
    }
    
    // Add behaviors based on entity type
    this.addEntityBehaviors(entity.entityType, components);
    
    // Map fire immunity
    if (entity.properties.isFireImmune) {
      components['minecraft:fire_immune'] = {};
    }
    
    // Add loot table
    components['minecraft:loot'] = {
      table: `loot_tables/entities/${entity.registryName}.json`,
    };
    
    // Add despawn rules
    components['minecraft:despawn'] = {
      despawnFromDistance: {
        minDistance: 32,
        maxDistance: 128,
      },
    };
    
    const bedrockEntity: BedrockEntity = {
      identifier,
      formatVersion: '1.20.80',
      description: {
        identifier,
        isSpawnable: entity.properties.isSummonable,
        isSummonable: entity.properties.isSummonable,
      },
      components,
    };
    
    return { entity: bedrockEntity, record };
  }
  
  private addEntityBehaviors(entityType: EntityType, components: EntityComponents): void {
    // Float behavior for all entities
    components['minecraft:behavior.float'] = { priority: 0 };
    
    // Common behaviors
    components['minecraft:behavior.random_stroll'] = { priority: 6, speedMultiplier: 1.0 };
    components['minecraft:behavior.look_at_player'] = { priority: 7, lookDistance: 8 };
    components['minecraft:behavior.random_look_around'] = { priority: 8 };
    
    switch (entityType) {
      case 'monster':
        components['minecraft:behavior.melee_attack'] = { priority: 3, speedMultiplier: 1.2, trackTarget: true };
        components['minecraft:behavior.nearest_attackable_target'] = {
          priority: 2,
          entityTypes: [
            {
              filters: { test: 'is_family', subject: 'other', value: 'player' },
              maxDist: 16,
            },
          ],
        };
        break;
      case 'animal':
        components['minecraft:behavior.panic'] = { priority: 1, speedMultiplier: 1.5 };
        components['minecraft:behavior.tempt'] = { priority: 4, speedMultiplier: 1.0 };
        break;
      case 'water_creature':
        components['minecraft:navigation.swim'] = { canSink: false };
        break;
    }
  }
  
  private mapRecipe(recipe: RecipeIR): {
    recipe: BedrockRecipe;
    record: MappingRecord;
  } | null {
    const identifier = `${this.namespace}:${recipe.id}`;
    const record: MappingRecord = {
      sourceType: 'recipe',
      sourceId: recipe.id,
      targetId: identifier,
      strategy: 'direct',
      success: true,
      notes: [],
    };
    
    let bedrockRecipe: BedrockRecipe;
    
    switch (recipe.recipeType) {
      case 'shaped':
        bedrockRecipe = {
          identifier,
          formatVersion: '1.20.80',
          type: 'crafting_shaped',
          tags: ['crafting_table'],
          pattern: recipe.pattern,
          key: this.mapRecipeKey(recipe.inputs),
          result: {
            item: this.mapItemId(recipe.output.itemId),
            count: recipe.output.count,
          },
        };
        break;
        
      case 'shapeless':
        bedrockRecipe = {
          identifier,
          formatVersion: '1.20.80',
          type: 'crafting_shapeless',
          tags: ['crafting_table'],
          ingredients: recipe.inputs.map((i) => ({
            item: this.mapItemId(i.itemId),
            count: i.count,
          })),
          result: {
            item: this.mapItemId(recipe.output.itemId),
            count: recipe.output.count,
          },
        };
        break;
        
      case 'smelting':
      case 'blasting':
      case 'smoking':
      case 'campfire':
        bedrockRecipe = {
          identifier,
          formatVersion: '1.20.80',
          type: 'furnace',
          tags: ['furnace', 'blast_furnace', 'smoker'],
          input: {
            item: this.mapItemId(recipe.inputs[0]?.itemId || 'minecraft:air'),
          },
          output: {
            item: this.mapItemId(recipe.output.itemId),
          },
        };
        record.notes.push('All furnace types consolidated into one recipe');
        break;
        
      default:
        record.success = false;
        record.notes.push(`Recipe type ${recipe.recipeType} not directly supported`);
        return null;
    }
    
    return { recipe: bedrockRecipe, record };
  }
  
  private mapRecipeKey(inputs: RecipeIR['inputs']): Record<string, { item?: string; tag?: string }> {
    const key: Record<string, { item?: string; tag?: string }> = {};
    
    for (const input of inputs) {
      if (input.key) {
        if (input.tag) {
          key[input.key] = { tag: input.tag };
        } else {
          key[input.key] = { item: this.mapItemId(input.itemId) };
        }
      }
    }
    
    return key;
  }
  
  private async generateScripts(javaIR: ModIR, result: MappingResult): Promise<typeof result.addon.scripts> {
    const scripts: ScriptFile[] = [];
    
    // Main entry point
    let mainScript = `/**
 * ${javaIR.metadata.name} - Ported from Java Edition
 * Generated by Java-to-Bedrock Mod Porter
 */

import { world, system } from '@minecraft/server';
import * as ui from '@minecraft/server-ui';

// Register custom components for blocks
`;

    // Generate block custom components
    for (const block of javaIR.blocks) {
      const complexBehaviors = block.behaviors.filter(
        (b) => b.complexity !== 'simple'
      );
      
      if (complexBehaviors.length > 0) {
        mainScript += this.generateBlockComponent(block, complexBehaviors);
      }
    }
    
    // Generate item custom components
    mainScript += `\n// Register custom components for items\n`;
    for (const item of javaIR.items) {
      const complexBehaviors = item.behaviors.filter(
        (b) => b.complexity !== 'simple'
      );
      
      if (complexBehaviors.length > 0) {
        mainScript += this.generateItemComponent(item, complexBehaviors);
      }
    }
    
    // Generate event handlers
    mainScript += `\n// Event handlers\n`;
    for (const handler of javaIR.eventHandlers) {
      const bedrockEvent = getScriptEventMapping(handler.eventType);
      if (bedrockEvent) {
        mainScript += this.generateEventHandler(handler, bedrockEvent);
      } else {
        result.warnings.push(`Event ${handler.eventType} has no Bedrock equivalent`);
      }
    }
    
    // Add initialization
    mainScript += `
// Initialize addon
world.afterEvents.worldInitialize.subscribe(() => {
  console.log('[${javaIR.metadata.name}] Addon initialized');
});
`;

    scripts.push({
      path: 'scripts/main.ts',
      content: mainScript,
    });
    
    return [{
      name: 'main',
      entryPoint: 'scripts/main.js',
      files: scripts,
      dependencies: [
        { moduleName: '@minecraft/server', version: '1.12.0' },
        { moduleName: '@minecraft/server-ui', version: '1.3.0' },
      ],
    }];
  }
  
  private generateBlockComponent(block: BlockIR, behaviors: BehaviorIR[]): string {
    const componentName = `${this.namespace}:${block.registryName}_behavior`;
    
    let code = `
world.beforeEvents.worldInitialize.subscribe((event) => {
  event.blockComponentRegistry.registerCustomComponent('${componentName}', {
`;

    for (const behavior of behaviors) {
      const handler = this.behaviorToHandler(behavior);
      if (handler) {
        code += handler;
      }
    }
    
    code += `  });
});
`;
    
    return code;
  }
  
  private generateItemComponent(item: ItemIR, behaviors: BehaviorIR[]): string {
    const componentName = `${this.namespace}:${item.registryName}_behavior`;
    
    let code = `
world.beforeEvents.worldInitialize.subscribe((event) => {
  event.itemComponentRegistry.registerCustomComponent('${componentName}', {
`;

    for (const behavior of behaviors) {
      const handler = this.behaviorToHandler(behavior);
      if (handler) {
        code += handler;
      }
    }
    
    code += `  });
});
`;
    
    return code;
  }
  
  private behaviorToHandler(behavior: BehaviorIR): string {
    switch (behavior.behaviorType) {
      case 'on_use':
        return `    onUse(event) {
      const player = event.source;
      const item = event.itemStack;
      // TODO: Implement use behavior
      // Original: ${behavior.methodName}
    },
`;
      case 'on_interact':
        return `    onPlayerInteract(event) {
      const player = event.player;
      const block = event.block;
      // TODO: Implement interact behavior
      // Original: ${behavior.methodName}
    },
`;
      case 'on_place':
        return `    beforeOnPlayerPlace(event) {
      const player = event.player;
      const block = event.block;
      // TODO: Implement place behavior
      // Original: ${behavior.methodName}
    },
`;
      case 'on_break':
        return `    onPlayerDestroy(event) {
      const player = event.player;
      const block = event.block;
      // TODO: Implement break behavior
      // Original: ${behavior.methodName}
    },
`;
      case 'on_tick':
        return `    onTick(event) {
      const block = event.block;
      // TODO: Implement tick behavior
      // Original: ${behavior.methodName}
    },
`;
      default:
        return '';
    }
  }
  
  private generateEventHandler(handler: any, bedrockEvent: string): string {
    return `
world.afterEvents.${bedrockEvent}.subscribe((event) => {
  // Original handler: ${handler.handlerClass}.${handler.handlerMethod}
  // Complexity: ${handler.complexity}
  // TODO: Implement event logic
});
`;
  }
  
  private generateTextureAtlases(javaIR: ModIR, result: MappingResult): void {
    const itemTextures: Record<string, { textures: string }> = {};
    const terrainTextures: Record<string, { textures: string }> = {};
    
    for (const item of javaIR.items) {
      itemTextures[item.registryName] = {
        textures: `textures/items/${item.registryName}`,
      };
    }
    
    for (const block of javaIR.blocks) {
      terrainTextures[block.registryName] = {
        textures: `textures/blocks/${block.registryName}`,
      };
    }
    
    result.addon.resourcePack.textureAtlases = [
      {
        type: 'item_texture',
        resourcePackName: this.namespace,
        textureName: 'atlas.items',
        textureData: itemTextures,
      },
      {
        type: 'terrain_texture',
        resourcePackName: this.namespace,
        textureName: 'atlas.terrain',
        textureData: terrainTextures,
      },
    ];
  }
  
  private generateLangFiles(javaIR: ModIR, result: MappingResult): void {
    const entries: Record<string, string> = {};
    
    for (const block of javaIR.blocks) {
      entries[`tile.${this.namespace}:${block.registryName}.name`] = 
        block.displayName || this.formatDisplayName(block.id);
    }
    
    for (const item of javaIR.items) {
      entries[`item.${this.namespace}:${item.registryName}.name`] = 
        item.displayName || this.formatDisplayName(item.id);
    }
    
    for (const entity of javaIR.entities) {
      entries[`entity.${this.namespace}:${entity.registryName}.name`] = 
        this.formatDisplayName(entity.id);
    }
    
    result.addon.resourcePack.langFiles = [
      {
        locale: 'en_US',
        entries,
      },
    ];
  }
  
  private formatDisplayName(id: string): string {
    return id
      .replace(/([A-Z])/g, ' $1')
      .replace(/_/g, ' ')
      .trim()
      .split(' ')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');
  }
  
  private mapEffectId(javaEffect: string): string {
    const effectMap: Record<string, string> = {
      'minecraft:speed': 'speed',
      'minecraft:slowness': 'slowness',
      'minecraft:haste': 'haste',
      'minecraft:mining_fatigue': 'mining_fatigue',
      'minecraft:strength': 'strength',
      'minecraft:instant_health': 'instant_health',
      'minecraft:instant_damage': 'instant_damage',
      'minecraft:jump_boost': 'jump_boost',
      'minecraft:nausea': 'nausea',
      'minecraft:regeneration': 'regeneration',
      'minecraft:resistance': 'resistance',
      'minecraft:fire_resistance': 'fire_resistance',
      'minecraft:water_breathing': 'water_breathing',
      'minecraft:invisibility': 'invisibility',
      'minecraft:blindness': 'blindness',
      'minecraft:night_vision': 'night_vision',
      'minecraft:hunger': 'hunger',
      'minecraft:weakness': 'weakness',
      'minecraft:poison': 'poison',
      'minecraft:wither': 'wither',
      'minecraft:health_boost': 'health_boost',
      'minecraft:absorption': 'absorption',
      'minecraft:saturation': 'saturation',
    };
    
    return effectMap[javaEffect] || javaEffect.replace('minecraft:', '');
  }
  
  private mapArmorSlot(javaSlot: string): string {
    const slotMap: Record<string, string> = {
      'head': 'slot.armor.head',
      'chest': 'slot.armor.chest',
      'legs': 'slot.armor.legs',
      'feet': 'slot.armor.feet',
    };
    
    return slotMap[javaSlot.toLowerCase()] || 'slot.armor.chest';
  }
  
  private mapCreativeTab(javaTab: string): string {
    const tabMap: Record<string, string> = {
      'building_blocks': 'construction',
      'decorations': 'construction',
      'redstone': 'equipment',
      'transportation': 'equipment',
      'misc': 'items',
      'food': 'items',
      'tools': 'equipment',
      'combat': 'equipment',
      'brewing': 'items',
    };
    
    return tabMap[javaTab.toLowerCase()] || 'items';
  }
  
  private mapItemId(javaId: string): string {
    if (javaId.startsWith('minecraft:')) {
      return javaId; // Vanilla items keep their ID
    }
    if (javaId.includes(':')) {
      const [ns, name] = javaId.split(':');
      return `${this.namespace}:${name}`;
    }
    return `${this.namespace}:${javaId}`;
  }
  
  private mapEntityFamily(entityType: EntityType): string {
    const familyMap: Record<EntityType, string> = {
      'unknown': 'mob',
      'mob': 'mob',
      'animal': 'animal',
      'monster': 'monster',
      'projectile': 'projectile',
      'vehicle': 'inanimate',
      'ambient': 'ambient',
      'water_creature': 'fish',
      'boss': 'monster',
    };
    
    return familyMap[entityType];
  }
}
