export * from './java-ir';
export * from './bedrock-ir';
