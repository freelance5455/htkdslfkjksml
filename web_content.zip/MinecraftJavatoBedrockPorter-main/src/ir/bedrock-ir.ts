/**
 * Intermediate Representation for Bedrock Add-ons
 * Represents the target structure for generated packs
 */

export interface BedrockAddonIR {
  metadata: BedrockMetadata;
  behaviorPack: BehaviorPack;
  resourcePack: ResourcePack;
  scripts: ScriptModule[];
}

export interface BedrockMetadata {
  name: string;
  description: string;
  version: [number, number, number];
  minEngineVersion: [number, number, number];
  uuid: string;
  authors: string[];
  license: string;
}

export interface BehaviorPack {
  manifest: BehaviorManifest;
  blocks: BedrockBlock[];
  items: BedrockItem[];
  entities: BedrockEntity[];
  recipes: BedrockRecipe[];
  lootTables: BedrockLootTable[];
  tradeTables: BedrockTradeTable[];
  spawnRules: BedrockSpawnRule[];
  features: BedrockFeature[];
  featureRules: BedrockFeatureRule[];
  functions: BedrockFunction[];
  animations: BedrockAnimation[];
  animationControllers: BedrockAnimationController[];
}

export interface ResourcePack {
  manifest: ResourceManifest;
  textures: BedrockTexture[];
  models: BedrockModel[];
  sounds: BedrockSound[];
  particles: BedrockParticle[];
  renderControllers: BedrockRenderController[];
  attachables: BedrockAttachable[];
  uiDefinitions: BedrockUI[];
  langFiles: BedrockLang[];
  textureAtlases: TextureAtlas[];
}

export interface BehaviorManifest {
  formatVersion: number;
  header: ManifestHeader;
  modules: ManifestModule[];
  dependencies: ManifestDependency[];
}

export interface ResourceManifest {
  formatVersion: number;
  header: ManifestHeader;
  modules: ManifestModule[];
  dependencies: ManifestDependency[];
}

export interface ManifestHeader {
  name: string;
  description: string;
  uuid: string;
  version: [number, number, number];
  minEngineVersion: [number, number, number];
}

export interface ManifestModule {
  type: 'data' | 'resources' | 'script';
  uuid: string;
  version: [number, number, number];
  entry?: string;
  language?: 'javascript';
}

export interface ManifestDependency {
  uuid?: string;
  version: [number, number, number];
  moduleName?: string;
}

export interface BedrockBlock {
  identifier: string;
  formatVersion: string;
  description: BlockDescription;
  components: BlockComponents;
  permutations?: BlockPermutation[];
  events?: Record<string, BlockEvent>;
}

export interface BlockDescription {
  identifier: string;
  menuCategory?: MenuCategory;
  states?: Record<string, string[] | number[] | boolean[]>;
  traits?: Record<string, unknown>;
}

export interface MenuCategory {
  category: string;
  group?: string;
  isHiddenInCommands?: boolean;
}

export interface BlockComponents {
  'minecraft:destructible_by_mining'?: { secondsToDestroy: number };
  'minecraft:destructible_by_explosion'?: { explosionResistance: number };
  'minecraft:friction'?: number;
  'minecraft:light_emission'?: number;
  'minecraft:light_dampening'?: number;
  'minecraft:map_color'?: string;
  'minecraft:flammable'?: { catchChanceModifier: number; destroyChanceModifier: number };
  'minecraft:loot'?: string;
  'minecraft:geometry'?: string | { identifier: string };
  'minecraft:material_instances'?: Record<string, MaterialInstance>;
  'minecraft:collision_box'?: CollisionBox | boolean;
  'minecraft:selection_box'?: CollisionBox | boolean;
  'minecraft:crafting_table'?: CraftingTableComponent;
  'minecraft:placement_filter'?: PlacementFilter;
  'minecraft:tick'?: { intervalRange: [number, number]; looping: boolean };
  'minecraft:custom_components'?: string[];
  [key: string]: unknown;
}

export interface MaterialInstance {
  texture: string;
  renderMethod?: 'opaque' | 'alpha_test' | 'blend' | 'double_sided';
  faceDimming?: boolean;
  ambientOcclusion?: boolean;
}

export interface CollisionBox {
  origin: [number, number, number];
  size: [number, number, number];
}

export interface CraftingTableComponent {
  tableName: string;
  craftingTags: string[];
}

export interface PlacementFilter {
  conditions: PlacementCondition[];
}

export interface PlacementCondition {
  allowedFaces?: string[];
  blockFilter?: BlockFilter[];
}

export interface BlockFilter {
  tags?: string;
  name?: string;
}

export interface BlockPermutation {
  condition: string;
  components: Partial<BlockComponents>;
}

export interface BlockEvent {
  sequence?: EventAction[];
  randomize?: EventAction[];
  condition?: string;
}

export interface EventAction {
  condition?: string;
  trigger?: { event: string; target?: string };
  setBlockState?: Record<string, string | number | boolean>;
  setBlockProperty?: Record<string, unknown>;
  runCommand?: { command: string | string[] };
  damage?: { type: string; amount: number };
  playSound?: { sound: string };
  spawnLoot?: { table: string };
  swing?: Record<string, never>;
  transformItem?: { transform: string };
  teleport?: { destination: [number, number, number] };
}

export interface BedrockItem {
  identifier: string;
  formatVersion: string;
  description: ItemDescription;
  components: ItemComponents;
  events?: Record<string, ItemEvent>;
}

export interface ItemDescription {
  identifier: string;
  category?: string;
  menuCategory?: MenuCategory;
}

export interface ItemComponents {
  'minecraft:icon'?: { texture: string };
  'minecraft:display_name'?: { value: string };
  'minecraft:max_stack_size'?: number;
  'minecraft:durability'?: { maxDurability: number; damageChance?: { min: number; max: number } };
  'minecraft:food'?: FoodComponent;
  'minecraft:cooldown'?: { category: string; duration: number };
  'minecraft:hand_equipped'?: boolean;
  'minecraft:wearable'?: { dispensable?: boolean; slot: string };
  'minecraft:throwable'?: { doSwingAnimation?: boolean; launchPowerScale?: number; maxDrawDuration?: number; maxLaunchPower?: number; minDrawDuration?: number; scalePowerByDrawDuration?: boolean };
  'minecraft:projectile'?: { minimumCriticalPower?: number; projectileEntity: string };
  'minecraft:shooter'?: { ammunition: ShooterAmmo[]; chargeOnDraw?: boolean; maxDrawDuration?: number; scalePowerByDrawDuration?: boolean };
  'minecraft:damage'?: number;
  'minecraft:enchantable'?: { slot: string; value: number };
  'minecraft:repairable'?: { repairItems: RepairItem[] };
  'minecraft:custom_components'?: string[];
  [key: string]: unknown;
}

export interface FoodComponent {
  nutrition: number;
  saturationModifier: number;
  canAlwaysEat?: boolean;
  effects?: StatusEffectEntry[];
}

export interface StatusEffectEntry {
  name: string;
  chance?: number;
  duration: number;
  amplifier: number;
}

export interface ShooterAmmo {
  item: string;
  useOffhand?: boolean;
  searchInventory?: boolean;
  useInCreative?: boolean;
}

export interface RepairItem {
  items: string[];
  repairAmount?: number;
}

export interface ItemEvent {
  sequence?: EventAction[];
  randomize?: EventAction[];
}

export interface BedrockEntity {
  identifier: string;
  formatVersion: string;
  description: EntityDescription;
  componentGroups?: Record<string, EntityComponents>;
  components: EntityComponents;
  events?: Record<string, EntityEvent>;
}

export interface EntityDescription {
  identifier: string;
  isSpawnable?: boolean;
  isSummonable?: boolean;
  isExperimental?: boolean;
  runtimeIdentifier?: string;
  animations?: Record<string, string>;
  scripts?: EntityScripts;
}

export interface EntityScripts {
  animate?: (string | Record<string, string>)[];
}

export interface EntityComponents {
  'minecraft:type_family'?: { family: string[] };
  'minecraft:collision_box'?: { width: number; height: number };
  'minecraft:health'?: { value: number; max: number };
  'minecraft:movement'?: { value: number };
  'minecraft:movement.basic'?: Record<string, unknown>;
  'minecraft:jump.static'?: Record<string, unknown>;
  'minecraft:navigation.walk'?: NavigationComponent;
  'minecraft:physics'?: { hasGravity?: boolean; hasCollision?: boolean };
  'minecraft:pushable'?: { isPushable?: boolean; isPushableByPiston?: boolean };
  'minecraft:behavior.float'?: { priority: number };
  'minecraft:behavior.panic'?: { priority: number; speedMultiplier?: number };
  'minecraft:behavior.random_stroll'?: { priority: number; speedMultiplier?: number };
  'minecraft:behavior.look_at_player'?: { priority: number; lookDistance?: number };
  'minecraft:behavior.random_look_around'?: { priority: number };
  'minecraft:behavior.melee_attack'?: { priority: number; speedMultiplier?: number; trackTarget?: boolean };
  'minecraft:behavior.nearest_attackable_target'?: { priority: number; entityTypes: EntityTypeFilter[] };
  'minecraft:attack'?: { damage: number | [number, number] };
  'minecraft:loot'?: { table: string };
  'minecraft:experience_reward'?: { onDeath?: string };
  'minecraft:is_hidden_when_invisible'?: Record<string, never>;
  'minecraft:scale'?: { value: number };
  'minecraft:despawn'?: DespawnComponent;
  [key: string]: unknown;
}

export interface NavigationComponent {
  canPathOverWater?: boolean;
  canSink?: boolean;
  canWalk?: boolean;
  canSwim?: boolean;
  avoidDamageBlocks?: boolean;
  avoidSun?: boolean;
}

export interface EntityTypeFilter {
  filters: EntityFilter;
  maxDist?: number;
  mustSee?: boolean;
}

export interface EntityFilter {
  test?: string;
  subject?: string;
  operator?: string;
  value?: string | number | boolean;
  allOf?: EntityFilter[];
  anyOf?: EntityFilter[];
}

export interface DespawnComponent {
  despawnFromDistance?: { minDistance: number; maxDistance: number };
}

export interface EntityEvent {
  add?: { componentGroups: string[] };
  remove?: { componentGroups: string[] };
  sequence?: EntityEventAction[];
  randomize?: EntityEventAction[];
}

export interface EntityEventAction {
  add?: { componentGroups: string[] };
  remove?: { componentGroups: string[] };
  trigger?: { event: string; target?: string };
  filters?: EntityFilter;
  weight?: number;
}

export interface BedrockRecipe {
  identifier: string;
  formatVersion: string;
  type: 'crafting_shaped' | 'crafting_shapeless' | 'furnace' | 'brewing' | 'smithing_transform';
  description?: { identifier: string };
  tags: string[];
  pattern?: string[];
  key?: Record<string, RecipeItem>;
  ingredients?: RecipeItem[];
  input?: RecipeItem | RecipeItem[];
  output?: RecipeItem | RecipeItem[];
  result?: RecipeItem;
  priority?: number;
}

export interface RecipeItem {
  item?: string;
  tag?: string;
  data?: number;
  count?: number;
}

export interface BedrockLootTable {
  identifier: string;
  pools: LootPool[];
}

export interface LootPool {
  rolls: number | { min: number; max: number };
  entries: LootEntry[];
  conditions?: LootCondition[];
}

export interface LootEntry {
  type: 'item' | 'loot_table' | 'empty';
  name?: string;
  weight?: number;
  functions?: LootFunction[];
}

export interface LootFunction {
  function: string;
  count?: { min: number; max: number } | number;
  conditions?: LootCondition[];
  [key: string]: unknown;
}

export interface LootCondition {
  condition: string;
  [key: string]: unknown;
}

export interface BedrockTradeTable {
  identifier: string;
  tiers: TradeTier[];
}

export interface TradeTier {
  trades: Trade[];
}

export interface Trade {
  wants: TradeItem[];
  gives: TradeItem[];
  maxUses?: number;
  traderExp?: number;
}

export interface TradeItem {
  item: string;
  quantity?: number | { min: number; max: number };
}

export interface BedrockSpawnRule {
  identifier: string;
  formatVersion: string;
  description: { identifier: string; populationControl: string };
  conditions: SpawnCondition[];
}

export interface SpawnCondition {
  'minecraft:spawns_on_surface'?: Record<string, never>;
  'minecraft:spawns_underground'?: Record<string, never>;
  'minecraft:spawns_underwater'?: Record<string, never>;
  'minecraft:brightness_filter'?: { min: number; max: number; adjustForWeather: boolean };
  'minecraft:difficulty_filter'?: { min: string; max: string };
  'minecraft:weight'?: { default: number };
  'minecraft:herd'?: { minSize: number; maxSize: number };
  'minecraft:biome_filter'?: BiomeFilter;
}

export interface BiomeFilter {
  test?: string;
  operator?: string;
  value?: string;
  allOf?: BiomeFilter[];
  anyOf?: BiomeFilter[];
}

export interface BedrockFeature {
  identifier: string;
  formatVersion: string;
  type: 'ore_feature' | 'tree_feature' | 'scatter_feature' | 'aggregate_feature';
  description: { identifier: string };
  config: unknown;
}

export interface BedrockFeatureRule {
  identifier: string;
  formatVersion: string;
  description: { identifier: string; placesFeature: string };
  conditions: FeatureRuleCondition;
  distribution: FeatureDistribution;
}

export interface FeatureRuleCondition {
  placementPass: string;
  'minecraft:biome_filter': BiomeFilter;
}

export interface FeatureDistribution {
  iterations: number | string;
  x: FeatureCoordinate;
  y: FeatureCoordinate;
  z: FeatureCoordinate;
}

export interface FeatureCoordinate {
  distribution: string;
  extent: [number | string, number | string];
}

export interface BedrockFunction {
  name: string;
  commands: string[];
}

export interface BedrockAnimation {
  identifier: string;
  formatVersion: string;
  animations: Record<string, AnimationData>;
}

export interface AnimationData {
  animationLength?: number;
  loop?: boolean;
  bones?: Record<string, BoneAnimation>;
  timeline?: Record<string, string | string[]>;
}

export interface BoneAnimation {
  rotation?: AnimationValue;
  position?: AnimationValue;
  scale?: AnimationValue;
}

export type AnimationValue =
  | [number, number, number]
  | Record<string, [number, number, number] | { pre?: [number, number, number]; post?: [number, number, number] }>;

export interface BedrockAnimationController {
  identifier: string;
  formatVersion: string;
  animationControllers: Record<string, AnimationControllerData>;
}

export interface AnimationControllerData {
  initialState: string;
  states: Record<string, AnimationState>;
}

export interface AnimationState {
  animations?: (string | Record<string, string>)[];
  transitions?: Record<string, string>[];
  onEntry?: string[];
  onExit?: string[];
}

export interface BedrockTexture {
  path: string;
  data: Buffer;
}

export interface BedrockModel {
  identifier: string;
  formatVersion: string;
  geometry: GeometryData[];
}

export interface GeometryData {
  description: {
    identifier: string;
    textureWidth: number;
    textureHeight: number;
    visibleBoundsWidth?: number;
    visibleBoundsHeight?: number;
    visibleBoundsOffset?: [number, number, number];
  };
  bones: ModelBone[];
}

export interface ModelBone {
  name: string;
  parent?: string;
  pivot?: [number, number, number];
  rotation?: [number, number, number];
  cubes?: ModelCube[];
  locators?: Record<string, [number, number, number] | { offset: [number, number, number]; rotation: [number, number, number] }>;
}

export interface ModelCube {
  origin: [number, number, number];
  size: [number, number, number];
  pivot?: [number, number, number];
  rotation?: [number, number, number];
  uv: [number, number] | Record<string, { uv: [number, number]; uvSize: [number, number] }>;
  inflate?: number;
  mirror?: boolean;
}

export interface BedrockSound {
  identifier: string;
  category: string;
  sounds: SoundEntry[];
}

export interface SoundEntry {
  name: string;
  volume?: number;
  pitch?: number;
  weight?: number;
  stream?: boolean;
}

export interface BedrockParticle {
  identifier: string;
  formatVersion: string;
  particleEffect: ParticleEffect;
}

export interface ParticleEffect {
  description: {
    identifier: string;
    basicRenderParameters: {
      material: string;
      texture: string;
    };
  };
  components: Record<string, unknown>;
}

export interface BedrockRenderController {
  identifier: string;
  formatVersion: string;
  renderControllers: Record<string, RenderControllerData>;
}

export interface RenderControllerData {
  geometry: string;
  materials: { '*': string }[];
  textures: string[];
}

export interface BedrockAttachable {
  identifier: string;
  formatVersion: string;
  description: {
    identifier: string;
    materials: Record<string, string>;
    textures: Record<string, string>;
    geometry: Record<string, string>;
    scripts?: { animate?: string[] };
    animations?: Record<string, string>;
    renderControllers: string[];
  };
}

export interface BedrockUI {
  namespace: string;
  elements: Record<string, UIElement>;
}

export interface UIElement {
  type: string;
  [key: string]: unknown;
}

export interface BedrockLang {
  locale: string;
  entries: Record<string, string>;
}

export interface TextureAtlas {
  type: 'item_texture' | 'terrain_texture';
  resourcePackName: string;
  textureName: string;
  textureData: Record<string, { textures: string | string[] }>;
}

export interface ScriptModule {
  name: string;
  entryPoint: string;
  files: ScriptFile[];
  dependencies: ScriptDependency[];
}

export interface ScriptFile {
  path: string;
  content: string;
}

export interface ScriptDependency {
  moduleName: string;
  version: string;
}

/**
 * Creates an empty Bedrock addon IR
 */
export function createEmptyBedrockAddonIR(): BedrockAddonIR {
  return {
    metadata: {
      name: '',
      description: '',
      version: [1, 0, 0],
      minEngineVersion: [1, 20, 0],
      uuid: '',
      authors: [],
      license: 'MIT',
    },
    behaviorPack: {
      manifest: {
        formatVersion: 2,
        header: {
          name: '',
          description: '',
          uuid: '',
          version: [1, 0, 0],
          minEngineVersion: [1, 20, 0],
        },
        modules: [],
        dependencies: [],
      },
      blocks: [],
      items: [],
      entities: [],
      recipes: [],
      lootTables: [],
      tradeTables: [],
      spawnRules: [],
      features: [],
      featureRules: [],
      functions: [],
      animations: [],
      animationControllers: [],
    },
    resourcePack: {
      manifest: {
        formatVersion: 2,
        header: {
          name: '',
          description: '',
          uuid: '',
          version: [1, 0, 0],
          minEngineVersion: [1, 20, 0],
        },
        modules: [],
        dependencies: [],
      },
      textures: [],
      models: [],
      sounds: [],
      particles: [],
      renderControllers: [],
      attachables: [],
      uiDefinitions: [],
      langFiles: [],
      textureAtlases: [],
    },
    scripts: [],
  };
}
