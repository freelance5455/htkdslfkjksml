/**
 * Intermediate Representation (IR) for Java Mods
 * This mirrors the Rust IR for TypeScript consumption
 */

export interface ModIR {
  metadata: ModMetadata;
  loader: ModLoader;
  blocks: BlockIR[];
  items: ItemIR[];
  entities: EntityIR[];
  recipes: RecipeIR[];
  eventHandlers: EventHandlerIR[];
  worldgen: WorldGenIR[];
  guis: GuiIR[];
  renderers: RendererIR[];
  advancedFeatures: AdvancedFeatures;
  classes: ClassIR[];
  assets: ModAssets;
}

export interface ModMetadata {
  modId: string;
  name: string;
  version: string;
  description: string;
  authors: string[];
  dependencies: ModDependency[];
  minecraftVersion: string;
}

export interface ModDependency {
  modId: string;
  versionRange: string;
  required: boolean;
}

export type ModLoader = 'unknown' | 'forge' | 'fabric' | 'quilt' | 'neoforge';

export interface BlockIR {
  id: string;
  registryName: string;
  displayName?: string;
  properties: BlockProperties;
  states: BlockState[];
  behaviors: BehaviorIR[];
  lootTable?: LootTableIR;
  model?: string;
  textures: Record<string, string>;
}

export interface BlockProperties {
  hardness: number;
  resistance: number;
  lightLevel: number;
  requiresTool: boolean;
  harvestLevel: number;
  material: string;
  soundType: string;
  isSolid: boolean;
  isTransparent: boolean;
  hasCollision: boolean;
  flammable: boolean;
  replaceable: boolean;
}

export interface BlockState {
  name: string;
  values: string[];
  defaultValue: string;
}

export interface ItemIR {
  id: string;
  registryName: string;
  displayName?: string;
  properties: ItemProperties;
  behaviors: BehaviorIR[];
  model?: string;
  texture?: string;
}

export interface ItemProperties {
  maxStackSize: number;
  durability?: number;
  isFood: boolean;
  foodProperties?: FoodProperties;
  creativeTab: string;
  rarity: string;
  isFireResistant: boolean;
  toolProperties?: ToolProperties;
  armorProperties?: ArmorProperties;
}

export interface FoodProperties {
  nutrition: number;
  saturation: number;
  isMeat: boolean;
  canAlwaysEat: boolean;
  effects: FoodEffect[];
}

export interface FoodEffect {
  effectId: string;
  duration: number;
  amplifier: number;
  probability: number;
}

export interface ToolProperties {
  toolType: string;
  tier: string;
  attackDamage: number;
  attackSpeed: number;
  efficiency: number;
}

export interface ArmorProperties {
  slot: string;
  defense: number;
  toughness: number;
  knockbackResistance: number;
  material: string;
}

export interface EntityIR {
  id: string;
  registryName: string;
  entityType: EntityType;
  properties: EntityProperties;
  behaviors: BehaviorIR[];
  components: EntityComponent[];
  model?: string;
  textures: string[];
  animations: AnimationIR[];
}

export type EntityType =
  | 'unknown'
  | 'mob'
  | 'animal'
  | 'monster'
  | 'projectile'
  | 'vehicle'
  | 'ambient'
  | 'water_creature'
  | 'boss';

export interface EntityProperties {
  width: number;
  height: number;
  maxHealth: number;
  movementSpeed: number;
  attackDamage: number;
  followRange: number;
  isSummonable: boolean;
  isFireImmune: boolean;
  spawnGroup: string;
}

export interface EntityComponent {
  componentType: string;
  data: unknown;
}

export interface AnimationIR {
  name: string;
  animationType: string;
  duration: number;
  keyframes: unknown[];
}

export interface BehaviorIR {
  behaviorType: BehaviorType;
  eventType: string;
  code: string;
  methodName: string;
  className: string;
  parameters: ParameterIR[];
  complexity: Complexity;
}

export type BehaviorType =
  | 'unknown'
  | 'on_use'
  | 'on_attack'
  | 'on_place'
  | 'on_break'
  | 'on_tick'
  | 'on_interact'
  | 'on_equip'
  | 'on_collision'
  | 'on_projectile_hit'
  | 'on_spawn'
  | 'on_death'
  | 'on_damage'
  | 'custom';

export type Complexity = 'simple' | 'moderate' | 'complex' | 'very_complex' | 'impossible';

export interface ParameterIR {
  name: string;
  paramType: string;
  javaType: string;
}

export interface RecipeIR {
  id: string;
  recipeType: RecipeType;
  inputs: RecipeIngredient[];
  output: RecipeOutput;
  pattern?: string[];
  group?: string;
  conditions: string[];
}

export type RecipeType =
  | 'unknown'
  | 'shaped'
  | 'shapeless'
  | 'smelting'
  | 'blasting'
  | 'smoking'
  | 'campfire'
  | 'stonecutting'
  | 'smithing'
  | 'brewing'
  | 'custom';

export interface RecipeIngredient {
  itemId: string;
  count: number;
  tag?: string;
  key?: string;
}

export interface RecipeOutput {
  itemId: string;
  count: number;
  nbt?: unknown;
}

export interface EventHandlerIR {
  eventType: string;
  handlerClass: string;
  handlerMethod: string;
  priority: string;
  cancellable: boolean;
  code: string;
  complexity: Complexity;
}

export interface WorldGenIR {
  featureType: WorldGenType;
  id: string;
  config: unknown;
  placement: PlacementIR;
  complexity: Complexity;
}

export type WorldGenType =
  | 'unknown'
  | 'ore'
  | 'tree'
  | 'flower'
  | 'lake'
  | 'structure'
  | 'biome'
  | 'dimension'
  | 'custom';

export interface PlacementIR {
  biomes: string[];
  heightRange: [number, number];
  frequency: number;
  rarity: number;
}

export interface GuiIR {
  id: string;
  guiType: GuiType;
  components: GuiComponent[];
  handlerClass: string;
  inventorySlots: SlotIR[];
}

export type GuiType = 'unknown' | 'container' | 'screen' | 'menu' | 'overlay';

export interface GuiComponent {
  componentType: string;
  x: number;
  y: number;
  width: number;
  height: number;
  properties: Record<string, unknown>;
}

export interface SlotIR {
  slotIndex: number;
  slotType: string;
  x: number;
  y: number;
}

export interface RendererIR {
  rendererType: RendererType;
  target: string;
  className: string;
  complexity: Complexity;
}

export type RendererType =
  | 'unknown'
  | 'block'
  | 'entity'
  | 'item'
  | 'tile_entity'
  | 'particle'
  | 'shader';

export interface LootTableIR {
  pools: LootPoolIR[];
}

export interface LootPoolIR {
  rolls: [number, number];
  entries: LootEntryIR[];
  conditions: string[];
}

export interface LootEntryIR {
  itemId: string;
  weight: number;
  count: [number, number];
  functions: string[];
}

export interface AdvancedFeatures {
  usesMixins: boolean;
  mixinClasses: string[];
  usesAsm: boolean;
  asmClasses: string[];
  usesReflection: boolean;
  reflectionUsages: ReflectionUsage[];
  usesCoremods: boolean;
  coremodClasses: string[];
  usesAccessTransformers: boolean;
  networkHandlers: NetworkHandlerIR[];
  capabilities: CapabilityIR[];
}

export interface ReflectionUsage {
  className: string;
  methodName: string;
  targetClass: string;
  targetMember: string;
}

export interface NetworkHandlerIR {
  channel: string;
  packetClass: string;
  direction: string;
}

export interface CapabilityIR {
  name: string;
  interfaceClass: string;
  implementationClass: string;
}

export interface ClassIR {
  name: string;
  package: string;
  superclass?: string;
  interfaces: string[];
  annotations: AnnotationIR[];
  methods: MethodIR[];
  fields: FieldIR[];
  isAbstract: boolean;
  isInterface: boolean;
  isEnum: boolean;
}

export interface AnnotationIR {
  name: string;
  values: Record<string, string>;
}

export interface MethodIR {
  name: string;
  returnType: string;
  parameters: ParameterIR[];
  annotations: AnnotationIR[];
  isStatic: boolean;
  visibility: string;
  bodySummary: string;
}

export interface FieldIR {
  name: string;
  fieldType: string;
  annotations: AnnotationIR[];
  isStatic: boolean;
  isFinal: boolean;
  initialValue?: string;
}

export interface ModAssets {
  textures: AssetIR[];
  models: AssetIR[];
  sounds: AssetIR[];
  langFiles: AssetIR[];
  recipesJson: AssetIR[];
  lootTablesJson: AssetIR[];
  blockstates: AssetIR[];
}

export interface AssetIR {
  path: string;
  contentType: string;
  content?: string;
}

/**
 * Creates an empty ModIR with default values
 */
export function createEmptyModIR(): ModIR {
  return {
    metadata: {
      modId: '',
      name: '',
      version: '1.0.0',
      description: '',
      authors: [],
      dependencies: [],
      minecraftVersion: '',
    },
    loader: 'unknown',
    blocks: [],
    items: [],
    entities: [],
    recipes: [],
    eventHandlers: [],
    worldgen: [],
    guis: [],
    renderers: [],
    advancedFeatures: {
      usesMixins: false,
      mixinClasses: [],
      usesAsm: false,
      asmClasses: [],
      usesReflection: false,
      reflectionUsages: [],
      usesCoremods: false,
      coremodClasses: [],
      usesAccessTransformers: false,
      networkHandlers: [],
      capabilities: [],
    },
    classes: [],
    assets: {
      textures: [],
      models: [],
      sounds: [],
      langFiles: [],
      recipesJson: [],
      lootTablesJson: [],
      blockstates: [],
    },
  };
}
