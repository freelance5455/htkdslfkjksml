/**
 * Bedrock Code Generator
 * 
 * Produces complete, ready-to-use Bedrock packs:
 * - Behavior pack (JSON + scripts)
 * - Resource pack (models, textures, animations)
 * - TypeScript scripts for all behaviors
 * - Valid manifests and folder structure
 */

import * as fs from 'fs';
import * as path from 'path';
import AdmZip from 'adm-zip';
import {
  BedrockAddonIR,
  BedrockBlock,
  BedrockItem,
  BedrockEntity,
  BedrockRecipe,
  BedrockLootTable,
  BedrockSpawnRule,
  BedrockFeature,
  BedrockFeatureRule,
} from '../ir/bedrock-ir';
import { Logger } from '../utils/logger';

export interface GeneratorOptions {
  /** Output directory for the addon */
  outputDir: string;
  
  /** Whether to generate .mcpack/.mcaddon files */
  generatePackages: boolean;
  
  /** Whether to minify JSON output */
  minifyJson: boolean;
  
  /** Whether to compile TypeScript to JavaScript */
  compileScripts: boolean;
  
  /** Whether to include source maps */
  sourceMaps: boolean;
  
  /** Format version for Bedrock JSON */
  formatVersion: string;
}

const DEFAULT_OPTIONS: GeneratorOptions = {
  outputDir: './output',
  generatePackages: true,
  minifyJson: false,
  compileScripts: true,
  sourceMaps: true,
  formatVersion: '1.20.80',
};

export class BedrockGenerator {
  private options: GeneratorOptions;
  private logger: Logger;
  private bpPath: string = '';
  private rpPath: string = '';
  
  constructor(logger: Logger, options: Partial<GeneratorOptions> = {}) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
    this.logger = logger;
  }
  
  /**
   * Generate complete Bedrock addon from IR
   */
  async generate(addon: BedrockAddonIR): Promise<void> {
    const namespace = addon.metadata.name.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    
    // Create output directories
    this.bpPath = path.join(this.options.outputDir, `${namespace}_BP`);
    this.rpPath = path.join(this.options.outputDir, `${namespace}_RP`);
    
    this.createDirectoryStructure();
    
    // Generate behavior pack
    await this.generateBehaviorPack(addon);
    
    // Generate resource pack
    await this.generateResourcePack(addon);
    
    // Generate packages if requested
    if (this.options.generatePackages) {
      await this.createPackages(namespace);
    }
    
    this.logger.info(`Addon generated at ${this.options.outputDir}`);
  }
  
  /**
   * Create the directory structure for both packs
   */
  private createDirectoryStructure(): void {
    const bpDirs = [
      'blocks',
      'items',
      'entities',
      'recipes',
      'loot_tables/blocks',
      'loot_tables/entities',
      'spawn_rules',
      'features',
      'feature_rules',
      'functions',
      'scripts',
      'animations',
      'animation_controllers',
    ];
    
    const rpDirs = [
      'textures/blocks',
      'textures/items',
      'textures/entity',
      'models/blocks',
      'models/entity',
      'sounds',
      'particles',
      'render_controllers',
      'attachables',
      'ui',
      'texts',
      'animations',
      'animation_controllers',
    ];
    
    for (const dir of bpDirs) {
      fs.mkdirSync(path.join(this.bpPath, dir), { recursive: true });
    }
    
    for (const dir of rpDirs) {
      fs.mkdirSync(path.join(this.rpPath, dir), { recursive: true });
    }
  }
  
  /**
   * Generate the behavior pack
   */
  private async generateBehaviorPack(addon: BedrockAddonIR): Promise<void> {
    const bp = addon.behaviorPack;
    
    // Manifest
    this.writeJson(path.join(this.bpPath, 'manifest.json'), bp.manifest);
    
    // Blocks
    for (const block of bp.blocks) {
      this.writeBlockJson(block);
    }
    
    // Items
    for (const item of bp.items) {
      this.writeItemJson(item);
    }
    
    // Entities
    for (const entity of bp.entities) {
      this.writeEntityJson(entity);
    }
    
    // Recipes
    for (const recipe of bp.recipes) {
      this.writeRecipeJson(recipe);
    }
    
    // Loot tables
    for (const loot of bp.lootTables) {
      this.writeLootTableJson(loot);
    }
    
    // Spawn rules
    for (const spawn of bp.spawnRules) {
      this.writeSpawnRuleJson(spawn);
    }
    
    // Features
    for (const feature of bp.features) {
      this.writeFeatureJson(feature);
    }
    
    // Feature rules
    for (const featureRule of bp.featureRules) {
      this.writeFeatureRuleJson(featureRule);
    }
    
    // Functions
    for (const func of bp.functions) {
      this.writeFunctionFile(func);
    }
    
    // Scripts
    await this.generateScripts(addon);
    
    // Animations
    for (const anim of bp.animations) {
      this.writeJson(
        path.join(this.bpPath, 'animations', `${anim.identifier.split(':')[1]}.json`),
        anim
      );
    }
    
    // Animation controllers
    for (const controller of bp.animationControllers) {
      this.writeJson(
        path.join(this.bpPath, 'animation_controllers', `${controller.identifier.split(':')[1]}.json`),
        controller
      );
    }
    
    this.logger.info(`Generated behavior pack with ${bp.blocks.length} blocks, ${bp.items.length} items, ${bp.entities.length} entities`);
  }
  
  /**
   * Generate the resource pack
   */
  private async generateResourcePack(addon: BedrockAddonIR): Promise<void> {
    const rp = addon.resourcePack;
    
    // Manifest
    this.writeJson(path.join(this.rpPath, 'manifest.json'), rp.manifest);
    
    // Texture atlases
    for (const atlas of rp.textureAtlases) {
      const filename = atlas.type === 'item_texture' 
        ? 'item_texture.json' 
        : 'terrain_texture.json';
      
      this.writeJson(path.join(this.rpPath, 'textures', filename), {
        resource_pack_name: atlas.resourcePackName,
        texture_name: atlas.textureName,
        texture_data: atlas.textureData,
      });
    }
    
    // Copy textures
    for (const texture of rp.textures) {
      const destPath = path.join(this.rpPath, texture.path);
      fs.mkdirSync(path.dirname(destPath), { recursive: true });
      if (texture.data) {
        fs.writeFileSync(destPath, texture.data);
      }
    }
    
    // Models
    for (const model of rp.models) {
      const parts = model.identifier.split(':');
      const filename = parts.length > 1 ? parts[1] : parts[0];
      this.writeJson(
        path.join(this.rpPath, 'models', 'entity', `${filename}.geo.json`),
        {
          format_version: model.formatVersion,
          'minecraft:geometry': model.geometry,
        }
      );
    }
    
    // Render controllers
    for (const rc of rp.renderControllers) {
      const parts = rc.identifier.split(':');
      const filename = parts.length > 1 ? parts[1] : parts[0];
      this.writeJson(
        path.join(this.rpPath, 'render_controllers', `${filename}.render_controllers.json`),
        {
          format_version: rc.formatVersion,
          render_controllers: rc.renderControllers,
        }
      );
    }
    
    // Lang files
    for (const lang of rp.langFiles) {
      const content = Object.entries(lang.entries)
        .map(([key, value]) => `${key}=${value}`)
        .join('\n');
      
      fs.writeFileSync(
        path.join(this.rpPath, 'texts', `${lang.locale}.lang`),
        content
      );
    }
    
    // Languages.json
    this.writeJson(path.join(this.rpPath, 'texts', 'languages.json'), 
      rp.langFiles.map(l => l.locale)
    );
    
    // Sound definitions
    if (rp.sounds.length > 0) {
      const soundDefs: Record<string, unknown> = {};
      for (const sound of rp.sounds) {
        soundDefs[sound.identifier] = {
          category: sound.category,
          sounds: sound.sounds.map(s => ({
            name: s.name,
            volume: s.volume,
            pitch: s.pitch,
          })),
        };
      }
      this.writeJson(path.join(this.rpPath, 'sounds', 'sound_definitions.json'), {
        format_version: '1.14.0',
        sound_definitions: soundDefs,
      });
    }
    
    // Particles
    for (const particle of rp.particles) {
      const parts = particle.identifier.split(':');
      const filename = parts.length > 1 ? parts[1] : parts[0];
      this.writeJson(
        path.join(this.rpPath, 'particles', `${filename}.json`),
        {
          format_version: particle.formatVersion,
          particle_effect: particle.particleEffect,
        }
      );
    }
    
    // Attachables
    for (const attachable of rp.attachables) {
      const parts = attachable.identifier.split(':');
      const filename = parts.length > 1 ? parts[1] : parts[0];
      this.writeJson(
        path.join(this.rpPath, 'attachables', `${filename}.json`),
        {
          format_version: attachable.formatVersion,
          'minecraft:attachable': {
            description: attachable.description,
          },
        }
      );
    }
    
    // Blocks.json for block rendering
    await this.generateBlocksJson(addon);
    
    this.logger.info(`Generated resource pack`);
  }
  
  /**
   * Generate blocks.json for resource pack
   */
  private async generateBlocksJson(addon: BedrockAddonIR): Promise<void> {
    const blocks: Record<string, { sound?: string; textures?: string | Record<string, string> }> = {};
    
    for (const block of addon.behaviorPack.blocks) {
      const parts = block.identifier.split(':');
      const name = parts.length > 1 ? parts[1] : parts[0];
      
      blocks[block.identifier] = {
        textures: name,
        sound: 'stone',
      };
    }
    
    if (Object.keys(blocks).length > 0) {
      this.writeJson(path.join(this.rpPath, 'blocks.json'), {
        format_version: [1, 1, 0],
        ...blocks,
      });
    }
  }
  
  /**
   * Generate scripts
   */
  private async generateScripts(addon: BedrockAddonIR): Promise<void> {
    for (const module of addon.scripts) {
      for (const file of module.files) {
        const filePath = path.join(this.bpPath, file.path);
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
        fs.writeFileSync(filePath, file.content);
        
        // If compiling TypeScript, also generate JS
        if (this.options.compileScripts && file.path.endsWith('.ts')) {
          const jsPath = filePath.replace('.ts', '.js');
          const jsContent = this.transpileTypeScript(file.content);
          fs.writeFileSync(jsPath, jsContent);
        }
      }
    }
    
    // Generate package.json for scripts
    const packageJson = {
      name: addon.metadata.name.toLowerCase().replace(/\s/g, '-'),
      version: addon.metadata.version.join('.'),
      type: 'module',
      dependencies: {
        '@minecraft/server': '^1.12.0',
        '@minecraft/server-ui': '^1.3.0',
      },
    };
    
    this.writeJson(path.join(this.bpPath, 'scripts', 'package.json'), packageJson);
  }
  
  /**
   * Simple TypeScript to JavaScript transpilation
   */
  private transpileTypeScript(tsCode: string): string {
    // Basic transpilation - in production, use actual TypeScript compiler
    let jsCode = tsCode;
    
    // Remove type annotations
    jsCode = jsCode.replace(/:\s*\w+(\[\])?(\s*[=,\)])/g, '$2');
    jsCode = jsCode.replace(/:\s*\w+(\[\])?$/gm, '');
    
    // Remove interface declarations
    jsCode = jsCode.replace(/interface\s+\w+\s*\{[\s\S]*?\}/g, '');
    
    // Remove type declarations
    jsCode = jsCode.replace(/type\s+\w+\s*=\s*[^;]+;/g, '');
    
    // Remove generic parameters
    jsCode = jsCode.replace(/<[^>]+>/g, '');
    
    // Remove 'as' type assertions
    jsCode = jsCode.replace(/\s+as\s+\w+/g, '');
    
    return jsCode;
  }
  
  /**
   * Write block JSON file
   */
  private writeBlockJson(block: BedrockBlock): void {
    const identifier = block.identifier.split(':')[1] || block.identifier;
    this.writeJson(
      path.join(this.bpPath, 'blocks', `${identifier}.json`),
      {
        format_version: block.formatVersion,
        'minecraft:block': {
          description: block.description,
          components: block.components,
          permutations: block.permutations,
          events: block.events,
        },
      }
    );
  }
  
  /**
   * Write item JSON file
   */
  private writeItemJson(item: BedrockItem): void {
    const identifier = item.identifier.split(':')[1] || item.identifier;
    this.writeJson(
      path.join(this.bpPath, 'items', `${identifier}.json`),
      {
        format_version: item.formatVersion,
        'minecraft:item': {
          description: item.description,
          components: item.components,
          events: item.events,
        },
      }
    );
  }
  
  /**
   * Write entity JSON file
   */
  private writeEntityJson(entity: BedrockEntity): void {
    const identifier = entity.identifier.split(':')[1] || entity.identifier;
    this.writeJson(
      path.join(this.bpPath, 'entities', `${identifier}.json`),
      {
        format_version: entity.formatVersion,
        'minecraft:entity': {
          description: entity.description,
          component_groups: entity.componentGroups,
          components: entity.components,
          events: entity.events,
        },
      }
    );
  }
  
  /**
   * Write recipe JSON file
   */
  private writeRecipeJson(recipe: BedrockRecipe): void {
    const identifier = recipe.identifier.split(':')[1] || recipe.identifier;
    const recipeData: Record<string, unknown> = {
      format_version: recipe.formatVersion,
    };
    
    const recipeKey = `minecraft:recipe_${recipe.type.replace('crafting_', '')}`;
    recipeData[recipeKey] = {
      description: recipe.description || { identifier: recipe.identifier },
      tags: recipe.tags,
    };
    
    const recipeContent = recipeData[recipeKey] as Record<string, unknown>;
    
    if (recipe.pattern) {
      recipeContent['pattern'] = recipe.pattern;
    }
    if (recipe.key) {
      recipeContent['key'] = recipe.key;
    }
    if (recipe.ingredients) {
      recipeContent['ingredients'] = recipe.ingredients;
    }
    if (recipe.input) {
      recipeContent['input'] = recipe.input;
    }
    if (recipe.output) {
      recipeContent['output'] = recipe.output;
    }
    if (recipe.result) {
      recipeContent['result'] = recipe.result;
    }
    
    this.writeJson(
      path.join(this.bpPath, 'recipes', `${identifier}.json`),
      recipeData
    );
  }
  
  /**
   * Write loot table JSON file
   */
  private writeLootTableJson(loot: BedrockLootTable): void {
    const parts = loot.identifier.split('/');
    const filename = parts[parts.length - 1];
    const subdir = parts.slice(0, -1).join('/') || 'entities';
    
    this.writeJson(
      path.join(this.bpPath, 'loot_tables', subdir, `${filename}.json`),
      { pools: loot.pools }
    );
  }
  
  /**
   * Write spawn rule JSON file
   */
  private writeSpawnRuleJson(spawn: BedrockSpawnRule): void {
    const identifier = spawn.identifier.split(':')[1] || spawn.identifier;
    this.writeJson(
      path.join(this.bpPath, 'spawn_rules', `${identifier}.json`),
      {
        format_version: spawn.formatVersion,
        'minecraft:spawn_rules': {
          description: spawn.description,
          conditions: spawn.conditions,
        },
      }
    );
  }
  
  /**
   * Write feature JSON file
   */
  private writeFeatureJson(feature: BedrockFeature): void {
    const identifier = feature.identifier.split(':')[1] || feature.identifier;
    const featureKey = `minecraft:${feature.type}`;
    
    const featureContent: Record<string, unknown> = {
      description: feature.description,
    };
    
    if (feature.config && typeof feature.config === 'object') {
      Object.assign(featureContent, feature.config);
    }
    
    this.writeJson(
      path.join(this.bpPath, 'features', `${identifier}.json`),
      {
        format_version: feature.formatVersion,
        [featureKey]: featureContent,
      }
    );
  }
  
  /**
   * Write feature rule JSON file
   */
  private writeFeatureRuleJson(rule: BedrockFeatureRule): void {
    const identifier = rule.identifier.split(':')[1] || rule.identifier;
    this.writeJson(
      path.join(this.bpPath, 'feature_rules', `${identifier}.json`),
      {
        format_version: rule.formatVersion,
        'minecraft:feature_rules': {
          description: rule.description,
          conditions: rule.conditions,
          distribution: rule.distribution,
        },
      }
    );
  }
  
  /**
   * Write mcfunction file
   */
  private writeFunctionFile(func: { name: string; commands: string[] }): void {
    const content = func.commands.join('\n');
    fs.writeFileSync(
      path.join(this.bpPath, 'functions', `${func.name}.mcfunction`),
      content
    );
  }
  
  /**
   * Write JSON file with formatting
   */
  private writeJson(filePath: string, data: unknown): void {
    const content = this.options.minifyJson
      ? JSON.stringify(data)
      : JSON.stringify(data, null, 2);
    
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, content);
  }
  
  /**
   * Create .mcpack and .mcaddon packages
   */
  private async createPackages(namespace: string): Promise<void> {
    // Create behavior pack .mcpack
    const bpZip = new AdmZip();
    this.addDirectoryToZip(bpZip, this.bpPath, '');
    bpZip.writeZip(path.join(this.options.outputDir, `${namespace}_BP.mcpack`));
    
    // Create resource pack .mcpack
    const rpZip = new AdmZip();
    this.addDirectoryToZip(rpZip, this.rpPath, '');
    rpZip.writeZip(path.join(this.options.outputDir, `${namespace}_RP.mcpack`));
    
    // Create combined .mcaddon
    const addonZip = new AdmZip();
    addonZip.addLocalFile(path.join(this.options.outputDir, `${namespace}_BP.mcpack`));
    addonZip.addLocalFile(path.join(this.options.outputDir, `${namespace}_RP.mcpack`));
    addonZip.writeZip(path.join(this.options.outputDir, `${namespace}.mcaddon`));
    
    this.logger.info(`Created packages: ${namespace}.mcaddon`);
  }
  
  /**
   * Add directory contents to ZIP
   */
  private addDirectoryToZip(zip: AdmZip, dirPath: string, zipPath: string): void {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      const entryZipPath = zipPath ? `${zipPath}/${entry.name}` : entry.name;
      
      if (entry.isDirectory()) {
        this.addDirectoryToZip(zip, fullPath, entryZipPath);
      } else {
        zip.addLocalFile(fullPath, zipPath || undefined);
      }
    }
  }
}
