/**
 * Bedrock Capability Model
 * 
 * A machine-readable description of what Bedrock Edition can and cannot do.
 * This guides all translation decisions in the mapping engine.
 */

export interface BedrockCapabilities {
  /** Minimum supported Bedrock version for features */
  minVersion: [number, number, number];
  
  /** Block capabilities */
  blocks: BlockCapabilities;
  
  /** Item capabilities */
  items: ItemCapabilities;
  
  /** Entity capabilities */
  entities: EntityCapabilities;
  
  /** Recipe capabilities */
  recipes: RecipeCapabilities;
  
  /** World generation capabilities */
  worldgen: WorldGenCapabilities;
  
  /** GUI/UI capabilities */
  gui: GuiCapabilities;
  
  /** Script API capabilities */
  scripting: ScriptingCapabilities;
  
  /** Rendering capabilities */
  rendering: RenderingCapabilities;
  
  /** Networking capabilities */
  networking: NetworkingCapabilities;
  
  /** Features that are completely unsupported */
  unsupportedFeatures: UnsupportedFeature[];
  
  /** Performance limits */
  limits: PerformanceLimits;
}

export interface BlockCapabilities {
  /** Maximum custom blocks per addon */
  maxCustomBlocks: number;
  
  /** Supported block components */
  supportedComponents: string[];
  
  /** Supported block properties/states */
  maxBlockStates: number;
  maxStatesPerProperty: number;
  supportedPropertyTypes: ('bool' | 'int' | 'enum')[];
  
  /** Supported block events */
  supportedEvents: string[];
  
  /** Geometry support */
  supportsCustomGeometry: boolean;
  maxGeometrySize: [number, number, number];
  
  /** Material support */
  supportedRenderMethods: string[];
  
  /** Custom block scripts */
  supportsCustomComponents: boolean;
  
  /** Limitations */
  limitations: string[];
}

export interface ItemCapabilities {
  /** Maximum custom items per addon */
  maxCustomItems: number;
  
  /** Supported item components */
  supportedComponents: string[];
  
  /** Tool/weapon support */
  supportedToolTypes: string[];
  supportedArmorSlots: string[];
  
  /** Food support */
  supportsFoodEffects: boolean;
  maxFoodEffects: number;
  
  /** Durability support */
  supportsDurability: boolean;
  maxDurability: number;
  
  /** Enchantability */
  supportsEnchanting: boolean;
  
  /** Custom item behaviors */
  supportsCustomComponents: boolean;
  
  /** Limitations */
  limitations: string[];
}

export interface EntityCapabilities {
  /** Maximum custom entities per addon */
  maxCustomEntities: number;
  
  /** Supported components */
  supportedComponents: string[];
  
  /** Supported behaviors (AI goals) */
  supportedBehaviors: string[];
  
  /** Supported sensors */
  supportedSensors: string[];
  
  /** Animation support */
  supportsCustomAnimations: boolean;
  supportsAnimationControllers: boolean;
  
  /** Spawn rules */
  supportsCustomSpawnRules: boolean;
  
  /** Loot tables */
  supportsLootTables: boolean;
  
  /** Trade tables */
  supportsTradeTables: boolean;
  
  /** Boss entities */
  supportsBossBar: boolean;
  
  /** Entity scripting */
  supportsCustomComponents: boolean;
  
  /** Limitations */
  limitations: string[];
}

export interface RecipeCapabilities {
  /** Supported recipe types */
  supportedTypes: string[];
  
  /** Shaped recipe limits */
  maxShapedWidth: number;
  maxShapedHeight: number;
  
  /** Ingredient support */
  supportsNbtIngredients: boolean;
  supportsTagIngredients: boolean;
  
  /** Output support */
  supportsNbtOutput: boolean;
  maxOutputCount: number;
  
  /** Custom recipe types */
  supportsCustomRecipeTypes: boolean;
  
  /** Limitations */
  limitations: string[];
}

export interface WorldGenCapabilities {
  /** Supported feature types */
  supportedFeatureTypes: string[];
  
  /** Ore generation */
  supportsOreGeneration: boolean;
  
  /** Tree generation */
  supportsTreeGeneration: boolean;
  
  /** Structure generation */
  supportsCustomStructures: boolean;
  maxStructureSize: [number, number, number];
  
  /** Biome modification */
  supportsBiomeModification: boolean;
  supportsCustomBiomes: boolean;
  
  /** Dimension support */
  supportsCustomDimensions: boolean;
  
  /** Limitations */
  limitations: string[];
}

export interface GuiCapabilities {
  /** Form types */
  supportedFormTypes: ('simple' | 'modal' | 'action')[];
  
  /** Custom UI */
  supportsCustomUI: boolean;
  
  /** Container types */
  supportedContainerTypes: string[];
  
  /** Custom container slots */
  maxCustomSlots: number;
  
  /** Limitations */
  limitations: string[];
}

export interface ScriptingCapabilities {
  /** Script API version */
  apiVersion: string;
  
  /** Supported modules */
  supportedModules: ScriptModule[];
  
  /** Event support */
  supportedEvents: string[];
  
  /** Block interaction */
  canModifyBlocks: boolean;
  canReadBlockState: boolean;
  
  /** Entity interaction */
  canSpawnEntities: boolean;
  canModifyEntities: boolean;
  canReadEntityData: boolean;
  
  /** Player interaction */
  canSendMessages: boolean;
  canShowForms: boolean;
  canModifyInventory: boolean;
  
  /** World interaction */
  canRunCommands: boolean;
  canScheduleTasks: boolean;
  
  /** Custom components */
  supportsBlockCustomComponents: boolean;
  supportsItemCustomComponents: boolean;
  
  /** Performance */
  maxScriptRuntime: number;
  
  /** Limitations */
  limitations: string[];
}

export interface ScriptModule {
  name: string;
  version: string;
  features: string[];
}

export interface RenderingCapabilities {
  /** Custom models */
  supportsCustomBlockModels: boolean;
  supportsCustomEntityModels: boolean;
  supportsCustomItemModels: boolean;
  
  /** Shaders */
  supportsCustomShaders: boolean;
  
  /** Particles */
  supportsCustomParticles: boolean;
  
  /** Render controllers */
  supportsRenderControllers: boolean;
  
  /** Limitations */
  limitations: string[];
}

export interface NetworkingCapabilities {
  /** Script events */
  supportsScriptEvents: boolean;
  
  /** Custom packets */
  supportsCustomPackets: boolean;
  
  /** Limitations */
  limitations: string[];
}

export interface UnsupportedFeature {
  /** Feature name */
  name: string;
  
  /** Category */
  category: 'mixin' | 'asm' | 'reflection' | 'coremod' | 'rendering' | 'worldgen' | 'networking' | 'other';
  
  /** Why it's unsupported */
  reason: string;
  
  /** Possible workaround, if any */
  workaround?: string;
  
  /** Degradation strategy */
  degradation: 'omit' | 'stub' | 'approximate' | 'simplify';
}

export interface PerformanceLimits {
  /** Maximum entities per chunk */
  maxEntitiesPerChunk: number;
  
  /** Maximum particles */
  maxParticles: number;
  
  /** Script execution time per tick (ms) */
  maxScriptTimePerTick: number;
  
  /** Maximum addon file size (MB) */
  maxAddonSize: number;
  
  /** Maximum texture size */
  maxTextureSize: number;
  
  /** Maximum model complexity */
  maxBoneCount: number;
  maxCubesPerBone: number;
}

/**
 * Current Bedrock capabilities (1.20+)
 */
export const BEDROCK_CAPABILITIES: BedrockCapabilities = {
  minVersion: [1, 20, 0],
  
  blocks: {
    maxCustomBlocks: 4096,
    supportedComponents: [
      'minecraft:destructible_by_mining',
      'minecraft:destructible_by_explosion',
      'minecraft:friction',
      'minecraft:flammable',
      'minecraft:light_emission',
      'minecraft:light_dampening',
      'minecraft:loot',
      'minecraft:map_color',
      'minecraft:geometry',
      'minecraft:material_instances',
      'minecraft:collision_box',
      'minecraft:selection_box',
      'minecraft:placement_filter',
      'minecraft:tick',
      'minecraft:crafting_table',
      'minecraft:custom_components',
    ],
    maxBlockStates: 16,
    maxStatesPerProperty: 16,
    supportedPropertyTypes: ['bool', 'int', 'enum'],
    supportedEvents: [
      'minecraft:on_player_placing',
      'minecraft:on_placed',
      'minecraft:on_player_destroyed',
      'minecraft:on_step_on',
      'minecraft:on_fall_on',
      'minecraft:on_interact',
      'minecraft:queue_custom_tick',
      'minecraft:random_tick',
    ],
    supportsCustomGeometry: true,
    maxGeometrySize: [16, 16, 16],
    supportedRenderMethods: ['opaque', 'alpha_test', 'blend', 'double_sided'],
    supportsCustomComponents: true,
    limitations: [
      'Cannot modify vanilla block behavior',
      'Block entity data is limited',
      'No tile entity equivalent for complex storage',
      'Custom block textures must use texture atlases',
    ],
  },
  
  items: {
    maxCustomItems: 4096,
    supportedComponents: [
      'minecraft:icon',
      'minecraft:display_name',
      'minecraft:max_stack_size',
      'minecraft:durability',
      'minecraft:food',
      'minecraft:cooldown',
      'minecraft:hand_equipped',
      'minecraft:wearable',
      'minecraft:throwable',
      'minecraft:projectile',
      'minecraft:shooter',
      'minecraft:damage',
      'minecraft:enchantable',
      'minecraft:repairable',
      'minecraft:custom_components',
    ],
    supportedToolTypes: ['pickaxe', 'axe', 'shovel', 'hoe', 'sword', 'shears'],
    supportedArmorSlots: ['head', 'chest', 'legs', 'feet', 'offhand'],
    supportsFoodEffects: true,
    maxFoodEffects: 8,
    supportsDurability: true,
    maxDurability: 32767,
    supportsEnchanting: true,
    supportsCustomComponents: true,
    limitations: [
      'No custom item models (only 2D icons)',
      'Limited item use animations',
      'Cannot create new enchantments',
      'No NBT data on items beyond basics',
    ],
  },
  
  entities: {
    maxCustomEntities: 4096,
    supportedComponents: [
      'minecraft:type_family',
      'minecraft:collision_box',
      'minecraft:health',
      'minecraft:attack',
      'minecraft:movement',
      'minecraft:movement.basic',
      'minecraft:navigation.walk',
      'minecraft:physics',
      'minecraft:pushable',
      'minecraft:loot',
      'minecraft:experience_reward',
      'minecraft:scale',
      'minecraft:despawn',
      'minecraft:is_hidden_when_invisible',
    ],
    supportedBehaviors: [
      'minecraft:behavior.float',
      'minecraft:behavior.panic',
      'minecraft:behavior.random_stroll',
      'minecraft:behavior.look_at_player',
      'minecraft:behavior.random_look_around',
      'minecraft:behavior.melee_attack',
      'minecraft:behavior.ranged_attack',
      'minecraft:behavior.nearest_attackable_target',
      'minecraft:behavior.hurt_by_target',
      'minecraft:behavior.follow_owner',
      'minecraft:behavior.breed',
      'minecraft:behavior.tempt',
    ],
    supportedSensors: [
      'minecraft:environment_sensor',
      'minecraft:damage_sensor',
    ],
    supportsCustomAnimations: true,
    supportsAnimationControllers: true,
    supportsCustomSpawnRules: true,
    supportsLootTables: true,
    supportsTradeTables: true,
    supportsBossBar: true,
    supportsCustomComponents: true,
    limitations: [
      'Limited AI goal complexity',
      'No custom pathfinding algorithms',
      'Entity data is less flexible than Java NBT',
    ],
  },
  
  recipes: {
    supportedTypes: [
      'crafting_shaped',
      'crafting_shapeless',
      'furnace',
      'brewing_mix',
      'brewing_container',
      'smithing_transform',
    ],
    maxShapedWidth: 3,
    maxShapedHeight: 3,
    supportsNbtIngredients: false,
    supportsTagIngredients: true,
    supportsNbtOutput: false,
    maxOutputCount: 64,
    supportsCustomRecipeTypes: false,
    limitations: [
      'No stonecutting recipes for custom items',
      'No campfire/smoking/blasting distinction',
      'Limited recipe conditions',
      'No custom recipe serializers',
    ],
  },
  
  worldgen: {
    supportedFeatureTypes: [
      'ore_feature',
      'tree_feature',
      'scatter_feature',
      'aggregate_feature',
    ],
    supportsOreGeneration: true,
    supportsTreeGeneration: true,
    supportsCustomStructures: true,
    maxStructureSize: [64, 64, 64],
    supportsBiomeModification: true,
    supportsCustomBiomes: true,
    supportsCustomDimensions: false,
    limitations: [
      'No custom dimensions',
      'Limited structure complexity',
      'Biome modification is experimental',
      'Cannot replicate complex Java worldgen',
    ],
  },
  
  gui: {
    supportedFormTypes: ['simple', 'modal', 'action'],
    supportsCustomUI: true,
    supportedContainerTypes: ['inventory', 'chest', 'hopper', 'dispenser', 'dropper'],
    maxCustomSlots: 27,
    limitations: [
      'No pixel-perfect custom GUIs like Java',
      'Limited to form-based or JSON UI',
      'No custom container logic without scripts',
      'Forms are modal and blocking',
    ],
  },
  
  scripting: {
    apiVersion: '1.12.0',
    supportedModules: [
      { name: '@minecraft/server', version: '1.12.0', features: ['world', 'entity', 'block', 'player', 'events'] },
      { name: '@minecraft/server-ui', version: '1.3.0', features: ['forms', 'modals', 'action_forms'] },
      { name: '@minecraft/server-net', version: '1.0.0-beta', features: ['http_requests'] },
      { name: '@minecraft/server-admin', version: '1.0.0-beta', features: ['secrets', 'variables'] },
    ],
    supportedEvents: [
      'worldInitialize',
      'playerJoin',
      'playerLeave',
      'playerSpawn',
      'beforeChatSend',
      'chatSend',
      'entityHitEntity',
      'entityHitBlock',
      'entityHurt',
      'entityDie',
      'blockBreak',
      'blockPlace',
      'beforeExplosion',
      'explosion',
      'itemUse',
      'itemUseOn',
      'itemStartUse',
      'itemStopUse',
      'itemCompleteUse',
      'projectileHitBlock',
      'projectileHitEntity',
      'playerInteractWithBlock',
      'playerInteractWithEntity',
    ],
    canModifyBlocks: true,
    canReadBlockState: true,
    canSpawnEntities: true,
    canModifyEntities: true,
    canReadEntityData: true,
    canSendMessages: true,
    canShowForms: true,
    canModifyInventory: true,
    canRunCommands: true,
    canScheduleTasks: true,
    supportsBlockCustomComponents: true,
    supportsItemCustomComponents: true,
    maxScriptRuntime: 200, // ms per tick
    limitations: [
      'No direct NBT access',
      'Limited async operations',
      'Cannot modify vanilla behavior deeply',
      'Watchdog kills long-running scripts',
    ],
  },
  
  rendering: {
    supportsCustomBlockModels: true,
    supportsCustomEntityModels: true,
    supportsCustomItemModels: false,
    supportsCustomShaders: false,
    supportsCustomParticles: true,
    supportsRenderControllers: true,
    limitations: [
      'No custom shaders',
      'Items are 2D only',
      'Limited render pipeline access',
      'No post-processing effects',
    ],
  },
  
  networking: {
    supportsScriptEvents: true,
    supportsCustomPackets: false,
    limitations: [
      'No custom network packets',
      'Script events for client-server sync',
      'Limited to JSON-like data transfer',
    ],
  },
  
  unsupportedFeatures: [
    {
      name: 'Mixins',
      category: 'mixin',
      reason: 'Bedrock has no bytecode modification system',
      workaround: 'Use Script API custom components or events',
      degradation: 'approximate',
    },
    {
      name: 'ASM Transformations',
      category: 'asm',
      reason: 'Bedrock has no bytecode modification system',
      degradation: 'omit',
    },
    {
      name: 'Core Mods',
      category: 'coremod',
      reason: 'Bedrock has no mod loader hooks',
      degradation: 'omit',
    },
    {
      name: 'Custom Shaders',
      category: 'rendering',
      reason: 'Bedrock uses fixed render pipeline',
      degradation: 'omit',
    },
    {
      name: 'Custom Dimensions',
      category: 'worldgen',
      reason: 'Bedrock does not support custom dimensions',
      workaround: 'Use Nether/End modification or custom biomes',
      degradation: 'omit',
    },
    {
      name: 'Complex NBT',
      category: 'other',
      reason: 'Bedrock has limited dynamic component data',
      workaround: 'Use dynamic properties or scoreboard',
      degradation: 'simplify',
    },
    {
      name: 'Reflection',
      category: 'reflection',
      reason: 'Script API has no reflection capabilities',
      degradation: 'omit',
    },
  ],
  
  limits: {
    maxEntitiesPerChunk: 100,
    maxParticles: 1000,
    maxScriptTimePerTick: 200,
    maxAddonSize: 256,
    maxTextureSize: 2048,
    maxBoneCount: 256,
    maxCubesPerBone: 64,
  },
};

/**
 * Check if a Java feature can be ported to Bedrock
 */
export function canPortFeature(feature: string, category: string): {
  supported: boolean;
  partial: boolean;
  workaround?: string;
  degradation?: string;
} {
  const unsupported = BEDROCK_CAPABILITIES.unsupportedFeatures.find(
    (f) => f.name.toLowerCase() === feature.toLowerCase() || f.category === category
  );
  
  if (unsupported) {
    return {
      supported: false,
      partial: unsupported.degradation === 'approximate' || unsupported.degradation === 'simplify',
      workaround: unsupported.workaround,
      degradation: unsupported.degradation,
    };
  }
  
  return { supported: true, partial: false };
}

/**
 * Get the Script API event equivalent for a Java event
 */
export function getScriptEventMapping(javaEvent: string): string | null {
  const eventMap: Record<string, string> = {
    'PlayerInteractEvent': 'playerInteractWithBlock',
    'BlockBreakEvent': 'blockBreak',
    'BlockPlaceEvent': 'blockPlace',
    'EntityDamageEvent': 'entityHurt',
    'EntityDeathEvent': 'entityDie',
    'PlayerJoinEvent': 'playerJoin',
    'PlayerQuitEvent': 'playerLeave',
    'ChatEvent': 'chatSend',
    'ProjectileHitEvent': 'projectileHitBlock',
    'EntitySpawnEvent': 'entitySpawn',
    'ItemUseEvent': 'itemUse',
    'RightClickBlock': 'playerInteractWithBlock',
    'RightClickItem': 'itemUse',
    'AttackEntity': 'entityHitEntity',
  };
  
  for (const [java, bedrock] of Object.entries(eventMap)) {
    if (javaEvent.includes(java)) {
      return bedrock;
    }
  }
  
  return null;
}
