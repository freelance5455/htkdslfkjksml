export * from './bedrock-capabilities';
