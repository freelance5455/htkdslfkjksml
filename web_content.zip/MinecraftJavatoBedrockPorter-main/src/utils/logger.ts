/**
 * Logger Utility
 * 
 * Provides consistent logging throughout the application
 */

import winston from 'winston';

export type LogLevel = 'error' | 'warn' | 'info' | 'debug' | 'verbose';

export interface LoggerOptions {
  level: LogLevel;
  outputFile?: string;
  silent?: boolean;
}

export class Logger {
  private logger: winston.Logger;
  
  constructor(options: Partial<LoggerOptions> = {}) {
    const transports: winston.transport[] = [];
    
    // Console transport
    if (!options.silent) {
      transports.push(
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.timestamp({ format: 'HH:mm:ss' }),
            winston.format.printf(({ timestamp, level, message }) => {
              return `${timestamp} ${level}: ${message}`;
            })
          ),
        })
      );
    }
    
    // File transport
    if (options.outputFile) {
      transports.push(
        new winston.transports.File({
          filename: options.outputFile,
          format: winston.format.combine(
            winston.format.timestamp(),
            winston.format.json()
          ),
        })
      );
    }
    
    this.logger = winston.createLogger({
      level: options.level || 'info',
      transports,
    });
  }
  
  error(message: string, ...args: unknown[]): void {
    this.logger.error(this.format(message, args));
  }
  
  warn(message: string, ...args: unknown[]): void {
    this.logger.warn(this.format(message, args));
  }
  
  info(message: string, ...args: unknown[]): void {
    this.logger.info(this.format(message, args));
  }
  
  debug(message: string, ...args: unknown[]): void {
    this.logger.debug(this.format(message, args));
  }
  
  verbose(message: string, ...args: unknown[]): void {
    this.logger.verbose(this.format(message, args));
  }
  
  private format(message: string, args: unknown[]): string {
    if (args.length === 0) return message;
    return `${message} ${args.map(a => JSON.stringify(a)).join(' ')}`;
  }
  
  /**
   * Create a child logger with a prefix
   */
  child(prefix: string): Logger {
    const child = new Logger({ silent: true });
    child.logger = this.logger.child({ prefix });
    return child;
  }
}

/**
 * Progress indicator for CLI
 */
export class ProgressIndicator {
  private current: number = 0;
  private total: number;
  private label: string;
  private startTime: number;
  
  constructor(total: number, label: string = 'Progress') {
    this.total = total;
    this.label = label;
    this.startTime = Date.now();
  }
  
  update(current: number, message?: string): void {
    this.current = current;
    const percent = Math.round((current / this.total) * 100);
    const elapsed = ((Date.now() - this.startTime) / 1000).toFixed(1);
    
    const bar = this.createBar(percent);
    const status = message ? ` - ${message}` : '';
    
    process.stdout.write(`\r${this.label}: ${bar} ${percent}% (${current}/${this.total}) [${elapsed}s]${status}`);
    
    if (current >= this.total) {
      process.stdout.write('\n');
    }
  }
  
  increment(message?: string): void {
    this.update(this.current + 1, message);
  }
  
  private createBar(percent: number): string {
    const width = 20;
    const filled = Math.round((percent / 100) * width);
    const empty = width - filled;
    return `[${'█'.repeat(filled)}${'░'.repeat(empty)}]`;
  }
}
