use anyhow::{Context, Result};
use clap::Parser;
use log::{info, warn};
use std::path::PathBuf;

mod analyzer;
mod bytecode;
mod extractor;
mod ir;
mod patterns;

use analyzer::ModAnalyzer;
use extractor::ModExtractor;

#[derive(Parser, Debug)]
#[command(name = "java-analyzer")]
#[command(about = "Analyzes Java Minecraft mods for Bedrock porting")]
struct Args {
    /// Path to the Java mod (.jar file or source folder)
    #[arg(short, long)]
    input: PathBuf,

    /// Output path for the analysis JSON
    #[arg(short, long)]
    output: PathBuf,

    /// Mod loader type (forge, fabric, auto)
    #[arg(short, long, default_value = "auto")]
    loader: String,

    /// Enable verbose output
    #[arg(short, long)]
    verbose: bool,
}

fn main() -> Result<()> {
    let args = Args::parse();

    // Initialize logging
    env_logger::Builder::new()
        .filter_level(if args.verbose {
            log::LevelFilter::Debug
        } else {
            log::LevelFilter::Info
        })
        .init();

    info!("Java Mod Analyzer v{}", env!("CARGO_PKG_VERSION"));
    info!("Input: {:?}", args.input);

    // Extract mod contents
    let extractor = ModExtractor::new(&args.input)?;
    let extracted = extractor.extract()?;
    info!("Extracted {} class files", extracted.classes.len());

    // Analyze the mod
    let analyzer = ModAnalyzer::new(&args.loader);
    let analysis = analyzer.analyze(&extracted)?;

    // Write output
    let json = serde_json::to_string_pretty(&analysis)?;
    std::fs::write(&args.output, &json)
        .with_context(|| format!("Failed to write output to {:?}", args.output))?;

    info!("Analysis complete. Output written to {:?}", args.output);
    Ok(())
}
