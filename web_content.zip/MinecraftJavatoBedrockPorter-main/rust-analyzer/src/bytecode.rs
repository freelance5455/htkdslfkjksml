use anyhow::Result;
use classfile_parser::ClassFile;
use classfile_parser::class_parser;
use classfile_parser::types::ClassAccessFlags;
use classfile_parser::field_info::FieldAccessFlags;
use classfile_parser::method_info::MethodAccessFlags;

use crate::ir::*;

/// Analyzes Java bytecode to extract class information
pub struct BytecodeAnalyzer {}

impl BytecodeAnalyzer {
    pub fn new() -> Self {
        Self {}
    }

    pub fn analyze_class(&self, bytes: &[u8]) -> Result<ClassIR> {
        let class_file = class_parser(bytes)
            .map_err(|e| anyhow::anyhow!("Failed to parse class file: {:?}", e))?
            .1;

        let mut class_ir = ClassIR::default();

        // Extract class name
        class_ir.name = self.get_class_name(&class_file, class_file.this_class)?;

        // Extract package
        if let Some(pos) = class_ir.name.rfind('/') {
            class_ir.package = class_ir.name[..pos].to_string();
        }

        // Extract superclass
        if class_file.super_class != 0 {
            class_ir.superclass = Some(self.get_class_name(&class_file, class_file.super_class)?);
        }

        // Extract interfaces
        for interface_idx in &class_file.interfaces {
            if let Ok(name) = self.get_class_name(&class_file, *interface_idx) {
                class_ir.interfaces.push(name);
            }
        }

        // Extract access flags - use bitflags contains method
        class_ir.is_abstract = class_file.access_flags.contains(ClassAccessFlags::ABSTRACT);
        class_ir.is_interface = class_file.access_flags.contains(ClassAccessFlags::INTERFACE);
        class_ir.is_enum = class_file.access_flags.contains(ClassAccessFlags::ENUM);

        // Extract fields
        for field in &class_file.fields {
            let field_ir = self.analyze_field(&class_file, field)?;
            class_ir.fields.push(field_ir);
        }

        // Extract methods
        for method in &class_file.methods {
            let method_ir = self.analyze_method(&class_file, method)?;
            class_ir.methods.push(method_ir);
        }

        // Extract annotations
        class_ir.annotations = self.extract_annotations(&class_file)?;

        Ok(class_ir)
    }

    fn get_class_name(&self, class_file: &ClassFile, index: u16) -> Result<String> {
        let constant = &class_file.const_pool[(index - 1) as usize];
        match constant {
            classfile_parser::constant_info::ConstantInfo::Class(class_info) => {
                self.get_utf8(class_file, class_info.name_index)
            }
            _ => Err(anyhow::anyhow!("Expected class constant at index {}", index)),
        }
    }

    fn get_utf8(&self, class_file: &ClassFile, index: u16) -> Result<String> {
        let constant = &class_file.const_pool[(index - 1) as usize];
        match constant {
            classfile_parser::constant_info::ConstantInfo::Utf8(utf8_info) => {
                Ok(utf8_info.utf8_string.clone())
            }
            _ => Err(anyhow::anyhow!("Expected UTF8 constant at index {}", index)),
        }
    }

    fn analyze_field(
        &self,
        class_file: &ClassFile,
        field: &classfile_parser::field_info::FieldInfo,
    ) -> Result<FieldIR> {
        let name = self.get_utf8(class_file, field.name_index)?;
        let descriptor = self.get_utf8(class_file, field.descriptor_index)?;

        Ok(FieldIR {
            name,
            field_type: self.descriptor_to_type(&descriptor),
            annotations: Vec::new(), // TODO: Extract field annotations
            is_static: field.access_flags.contains(FieldAccessFlags::STATIC),
            is_final: field.access_flags.contains(FieldAccessFlags::FINAL),
            initial_value: None,
        })
    }

    fn analyze_method(
        &self,
        class_file: &ClassFile,
        method: &classfile_parser::method_info::MethodInfo,
    ) -> Result<MethodIR> {
        let name = self.get_utf8(class_file, method.name_index)?;
        let descriptor = self.get_utf8(class_file, method.descriptor_index)?;

        let (params, return_type) = self.parse_method_descriptor(&descriptor);

        let mut method_ir = MethodIR {
            name,
            return_type,
            parameters: params,
            annotations: Vec::new(),
            is_static: method.access_flags.contains(MethodAccessFlags::STATIC),
            visibility: self.access_flags_to_visibility(method.access_flags.bits()),
            body_summary: String::new(),
        };

        // Extract method annotations
        for attr in &method.attributes {
            let attr_name = self.get_utf8(class_file, attr.attribute_name_index)?;
            if attr_name.contains("Annotation") {
                // Parse annotation data
                if let Some(annotation) = self.parse_annotation_attribute(&attr.info, class_file) {
                    method_ir.annotations.push(annotation);
                }
            }
        }

        Ok(method_ir)
    }

    fn parse_method_descriptor(&self, descriptor: &str) -> (Vec<ParameterIR>, String) {
        let mut params = Vec::new();
        let mut return_type = "void".to_string();

        if let Some(paren_start) = descriptor.find('(') {
            if let Some(paren_end) = descriptor.find(')') {
                let params_str = &descriptor[paren_start + 1..paren_end];
                let return_str = &descriptor[paren_end + 1..];

                // Parse parameters
                let mut i = 0;
                let chars: Vec<char> = params_str.chars().collect();
                let mut param_idx = 0;
                while i < chars.len() {
                    let (param_type, consumed) = self.parse_type_descriptor(&chars[i..]);
                    params.push(ParameterIR {
                        name: format!("param{}", param_idx),
                        param_type: param_type.clone(),
                        java_type: param_type,
                    });
                    i += consumed;
                    param_idx += 1;
                }

                // Parse return type
                let (ret, _) = self.parse_type_descriptor(&return_str.chars().collect::<Vec<_>>());
                return_type = ret;
            }
        }

        (params, return_type)
    }

    fn parse_type_descriptor(&self, chars: &[char]) -> (String, usize) {
        if chars.is_empty() {
            return ("void".to_string(), 0);
        }

        match chars[0] {
            'B' => ("byte".to_string(), 1),
            'C' => ("char".to_string(), 1),
            'D' => ("double".to_string(), 1),
            'F' => ("float".to_string(), 1),
            'I' => ("int".to_string(), 1),
            'J' => ("long".to_string(), 1),
            'S' => ("short".to_string(), 1),
            'Z' => ("boolean".to_string(), 1),
            'V' => ("void".to_string(), 1),
            '[' => {
                let (inner, consumed) = self.parse_type_descriptor(&chars[1..]);
                (format!("{}[]", inner), consumed + 1)
            }
            'L' => {
                // Object type - read until ;
                let mut end = 1;
                while end < chars.len() && chars[end] != ';' {
                    end += 1;
                }
                let class_name: String = chars[1..end].iter().collect();
                let simple_name = class_name.split('/').last().unwrap_or(&class_name);
                (simple_name.to_string(), end + 1)
            }
            _ => ("unknown".to_string(), 1),
        }
    }

    fn descriptor_to_type(&self, descriptor: &str) -> String {
        let chars: Vec<char> = descriptor.chars().collect();
        let (t, _) = self.parse_type_descriptor(&chars);
        t
    }

    fn access_flags_to_visibility(&self, flags: u16) -> String {
        if (flags & 0x0001) != 0 {
            "public".to_string()
        } else if (flags & 0x0002) != 0 {
            "private".to_string()
        } else if (flags & 0x0004) != 0 {
            "protected".to_string()
        } else {
            "package".to_string()
        }
    }

    fn extract_annotations(&self, class_file: &ClassFile) -> Result<Vec<AnnotationIR>> {
        let mut annotations = Vec::new();

        for attr in &class_file.attributes {
            let attr_name = self.get_utf8(class_file, attr.attribute_name_index)?;
            if attr_name.contains("Annotation") {
                if let Some(annotation) = self.parse_annotation_attribute(&attr.info, class_file) {
                    annotations.push(annotation);
                }
            }
        }

        Ok(annotations)
    }

    fn parse_annotation_attribute(
        &self,
        _data: &[u8],
        _class_file: &ClassFile,
    ) -> Option<AnnotationIR> {
        // Simplified annotation parsing - would need full implementation for production
        // This would parse the RuntimeVisibleAnnotations attribute format
        None
    }
}
