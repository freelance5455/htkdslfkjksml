use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// The complete Intermediate Representation of a Java mod
#[derive(Debug, Serialize, Deserialize, Default)]
pub struct ModIR {
    /// Mod metadata
    pub metadata: ModMetadata,
    /// Detected mod loader
    pub loader: ModLoader,
    /// All registered blocks
    pub blocks: Vec<BlockIR>,
    /// All registered items
    pub items: Vec<ItemIR>,
    /// All registered entities
    pub entities: Vec<EntityIR>,
    /// All recipes
    pub recipes: Vec<RecipeIR>,
    /// Event handlers
    pub event_handlers: Vec<EventHandlerIR>,
    /// World generation features
    pub worldgen: Vec<WorldGenIR>,
    /// GUI definitions
    pub guis: Vec<GuiIR>,
    /// Custom renderers
    pub renderers: Vec<RendererIR>,
    /// Detected advanced features (mixins, ASM, reflection)
    pub advanced_features: AdvancedFeatures,
    /// Raw class information for complex analysis
    pub classes: Vec<ClassIR>,
    /// Assets found in the mod
    pub assets: ModAssets,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct ModMetadata {
    pub mod_id: String,
    pub name: String,
    pub version: String,
    pub description: String,
    pub authors: Vec<String>,
    pub dependencies: Vec<ModDependency>,
    pub minecraft_version: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct ModDependency {
    pub mod_id: String,
    pub version_range: String,
    pub required: bool,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone, PartialEq)]
pub enum ModLoader {
    #[default]
    Unknown,
    Forge,
    Fabric,
    Quilt,
    NeoForge,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct BlockIR {
    pub id: String,
    pub registry_name: String,
    pub display_name: Option<String>,
    pub properties: BlockProperties,
    pub states: Vec<BlockState>,
    pub behaviors: Vec<BehaviorIR>,
    pub loot_table: Option<LootTableIR>,
    pub model: Option<String>,
    pub textures: HashMap<String, String>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct BlockProperties {
    pub hardness: f32,
    pub resistance: f32,
    pub light_level: u8,
    pub requires_tool: bool,
    pub harvest_level: u8,
    pub material: String,
    pub sound_type: String,
    pub is_solid: bool,
    pub is_transparent: bool,
    pub has_collision: bool,
    pub flammable: bool,
    pub replaceable: bool,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct BlockState {
    pub name: String,
    pub values: Vec<String>,
    pub default_value: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct ItemIR {
    pub id: String,
    pub registry_name: String,
    pub display_name: Option<String>,
    pub properties: ItemProperties,
    pub behaviors: Vec<BehaviorIR>,
    pub model: Option<String>,
    pub texture: Option<String>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct ItemProperties {
    pub max_stack_size: u8,
    pub durability: Option<u16>,
    pub is_food: bool,
    pub food_properties: Option<FoodProperties>,
    pub creative_tab: String,
    pub rarity: String,
    pub is_fire_resistant: bool,
    pub tool_properties: Option<ToolProperties>,
    pub armor_properties: Option<ArmorProperties>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct FoodProperties {
    pub nutrition: i32,
    pub saturation: f32,
    pub is_meat: bool,
    pub can_always_eat: bool,
    pub effects: Vec<FoodEffect>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct FoodEffect {
    pub effect_id: String,
    pub duration: i32,
    pub amplifier: i32,
    pub probability: f32,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct ToolProperties {
    pub tool_type: String,
    pub tier: String,
    pub attack_damage: f32,
    pub attack_speed: f32,
    pub efficiency: f32,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct ArmorProperties {
    pub slot: String,
    pub defense: i32,
    pub toughness: f32,
    pub knockback_resistance: f32,
    pub material: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct EntityIR {
    pub id: String,
    pub registry_name: String,
    pub entity_type: EntityType,
    pub properties: EntityProperties,
    pub behaviors: Vec<BehaviorIR>,
    pub components: Vec<EntityComponent>,
    pub model: Option<String>,
    pub textures: Vec<String>,
    pub animations: Vec<AnimationIR>,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub enum EntityType {
    #[default]
    Unknown,
    Mob,
    Animal,
    Monster,
    Projectile,
    Vehicle,
    Ambient,
    WaterCreature,
    Boss,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct EntityProperties {
    pub width: f32,
    pub height: f32,
    pub max_health: f32,
    pub movement_speed: f32,
    pub attack_damage: f32,
    pub follow_range: f32,
    pub is_summonable: bool,
    pub is_fire_immune: bool,
    pub spawn_group: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct EntityComponent {
    pub component_type: String,
    pub data: serde_json::Value,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct AnimationIR {
    pub name: String,
    pub animation_type: String,
    pub duration: f32,
    pub keyframes: Vec<serde_json::Value>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct BehaviorIR {
    pub behavior_type: BehaviorType,
    pub event_type: String,
    pub code: String,
    pub method_name: String,
    pub class_name: String,
    pub parameters: Vec<ParameterIR>,
    pub complexity: Complexity,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub enum BehaviorType {
    #[default]
    Unknown,
    OnUse,
    OnAttack,
    OnPlace,
    OnBreak,
    OnTick,
    OnInteract,
    OnEquip,
    OnCollision,
    OnProjectileHit,
    OnSpawn,
    OnDeath,
    OnDamage,
    Custom,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub enum Complexity {
    #[default]
    Simple,
    Moderate,
    Complex,
    VeryComplex,
    Impossible,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ParameterIR {
    pub name: String,
    pub param_type: String,
    pub java_type: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct RecipeIR {
    pub id: String,
    pub recipe_type: RecipeType,
    pub inputs: Vec<RecipeIngredient>,
    pub output: RecipeOutput,
    pub pattern: Option<Vec<String>>,
    pub group: Option<String>,
    pub conditions: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub enum RecipeType {
    #[default]
    Unknown,
    Shaped,
    Shapeless,
    Smelting,
    Blasting,
    Smoking,
    Campfire,
    Stonecutting,
    Smithing,
    Brewing,
    Custom,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct RecipeIngredient {
    pub item_id: String,
    pub count: u8,
    pub tag: Option<String>,
    pub key: Option<char>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct RecipeOutput {
    pub item_id: String,
    pub count: u8,
    pub nbt: Option<serde_json::Value>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct EventHandlerIR {
    pub event_type: String,
    pub handler_class: String,
    pub handler_method: String,
    pub priority: String,
    pub cancellable: bool,
    pub code: String,
    pub complexity: Complexity,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct WorldGenIR {
    pub feature_type: WorldGenType,
    pub id: String,
    pub config: serde_json::Value,
    pub placement: PlacementIR,
    pub complexity: Complexity,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub enum WorldGenType {
    #[default]
    Unknown,
    Ore,
    Tree,
    Flower,
    Lake,
    Structure,
    Biome,
    Dimension,
    Custom,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct PlacementIR {
    pub biomes: Vec<String>,
    pub height_range: (i32, i32),
    pub frequency: f32,
    pub rarity: i32,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct GuiIR {
    pub id: String,
    pub gui_type: GuiType,
    pub components: Vec<GuiComponent>,
    pub handler_class: String,
    pub inventory_slots: Vec<SlotIR>,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub enum GuiType {
    #[default]
    Unknown,
    Container,
    Screen,
    Menu,
    Overlay,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct GuiComponent {
    pub component_type: String,
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
    pub properties: HashMap<String, serde_json::Value>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct SlotIR {
    pub slot_index: u8,
    pub slot_type: String,
    pub x: i32,
    pub y: i32,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct RendererIR {
    pub renderer_type: RendererType,
    pub target: String,
    pub class_name: String,
    pub complexity: Complexity,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub enum RendererType {
    #[default]
    Unknown,
    Block,
    Entity,
    Item,
    TileEntity,
    Particle,
    Shader,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct LootTableIR {
    pub pools: Vec<LootPoolIR>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct LootPoolIR {
    pub rolls: (f32, f32),
    pub entries: Vec<LootEntryIR>,
    pub conditions: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct LootEntryIR {
    pub item_id: String,
    pub weight: i32,
    pub count: (i32, i32),
    pub functions: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct AdvancedFeatures {
    pub uses_mixins: bool,
    pub mixin_classes: Vec<String>,
    pub uses_asm: bool,
    pub asm_classes: Vec<String>,
    pub uses_reflection: bool,
    pub reflection_usages: Vec<ReflectionUsage>,
    pub uses_coremods: bool,
    pub coremod_classes: Vec<String>,
    pub uses_access_transformers: bool,
    pub network_handlers: Vec<NetworkHandlerIR>,
    pub capabilities: Vec<CapabilityIR>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct ReflectionUsage {
    pub class_name: String,
    pub method_name: String,
    pub target_class: String,
    pub target_member: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct NetworkHandlerIR {
    pub channel: String,
    pub packet_class: String,
    pub direction: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct CapabilityIR {
    pub name: String,
    pub interface_class: String,
    pub implementation_class: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct ClassIR {
    pub name: String,
    pub package: String,
    pub superclass: Option<String>,
    pub interfaces: Vec<String>,
    pub annotations: Vec<AnnotationIR>,
    pub methods: Vec<MethodIR>,
    pub fields: Vec<FieldIR>,
    pub is_abstract: bool,
    pub is_interface: bool,
    pub is_enum: bool,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct AnnotationIR {
    pub name: String,
    pub values: HashMap<String, String>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct MethodIR {
    pub name: String,
    pub return_type: String,
    pub parameters: Vec<ParameterIR>,
    pub annotations: Vec<AnnotationIR>,
    pub is_static: bool,
    pub visibility: String,
    pub body_summary: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
pub struct FieldIR {
    pub name: String,
    pub field_type: String,
    pub annotations: Vec<AnnotationIR>,
    pub is_static: bool,
    pub is_final: bool,
    pub initial_value: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ModAssets {
    pub textures: Vec<AssetIR>,
    pub models: Vec<AssetIR>,
    pub sounds: Vec<AssetIR>,
    pub lang_files: Vec<AssetIR>,
    pub recipes_json: Vec<AssetIR>,
    pub loot_tables_json: Vec<AssetIR>,
    pub blockstates: Vec<AssetIR>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct AssetIR {
    pub path: String,
    pub content_type: String,
    pub content: Option<String>,
}
