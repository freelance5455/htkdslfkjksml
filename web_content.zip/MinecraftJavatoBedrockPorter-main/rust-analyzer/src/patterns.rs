use std::collections::HashMap;

use crate::ir::*;

/// Pattern matching for common Minecraft mod constructs
pub struct PatternMatcher {}

impl PatternMatcher {
    pub fn new() -> Self {
        Self {}
    }

    pub fn extract_block_properties(&self, method: &MethodIR) -> BlockProperties {
        let mut props = BlockProperties::default();
        props.hardness = 1.5;
        props.resistance = 6.0;
        props.is_solid = true;
        props.has_collision = true;
        props.material = "stone".to_string();
        props.sound_type = "stone".to_string();
        props
    }

    pub fn extract_item_properties(&self, method: &MethodIR) -> ItemProperties {
        let mut props = ItemProperties::default();
        props.max_stack_size = 64;
        props.creative_tab = "misc".to_string();
        props.rarity = "common".to_string();
        props
    }

    pub fn extract_block_states(&self, class: &ClassIR) -> Vec<BlockState> {
        let mut states = Vec::new();

        // Look for static PropertyInteger, PropertyBool, PropertyDirection fields
        for field in &class.fields {
            if field.field_type.contains("Property") {
                let state = BlockState {
                    name: field.name.to_lowercase(),
                    values: vec!["0".to_string(), "1".to_string()],
                    default_value: "0".to_string(),
                };
                states.push(state);
            }
        }

        states
    }

    pub fn method_to_behavior(&self, method: &MethodIR, context: &str) -> Option<BehaviorIR> {
        let behavior_methods = [
            ("use", BehaviorType::OnUse),
            ("onUse", BehaviorType::OnUse),
            ("interactionHand", BehaviorType::OnInteract),
            ("attack", BehaviorType::OnAttack),
            ("onBlockPlaced", BehaviorType::OnPlace),
            ("onPlace", BehaviorType::OnPlace),
            ("onBreak", BehaviorType::OnBreak),
            ("onRemove", BehaviorType::OnBreak),
            ("tick", BehaviorType::OnTick),
            ("randomTick", BehaviorType::OnTick),
            ("neighborChanged", BehaviorType::OnTick),
            ("entityInside", BehaviorType::OnCollision),
            ("onProjectileHit", BehaviorType::OnProjectileHit),
            ("onEntityCollision", BehaviorType::OnCollision),
            ("finishUsing", BehaviorType::OnUse),
            ("inventoryTick", BehaviorType::OnTick),
            ("releaseUsing", BehaviorType::OnUse),
            ("hurt", BehaviorType::OnDamage),
            ("die", BehaviorType::OnDeath),
        ];

        for (pattern, behavior_type) in behavior_methods {
            if method.name.contains(pattern) {
                return Some(BehaviorIR {
                    behavior_type,
                    event_type: pattern.to_string(),
                    code: method.body_summary.clone(),
                    method_name: method.name.clone(),
                    class_name: String::new(),
                    parameters: method.parameters.clone(),
                    complexity: self.assess_complexity(&method.body_summary),
                });
            }
        }

        None
    }

    pub fn classify_entity_type(&self, class: &ClassIR) -> EntityType {
        if let Some(ref superclass) = class.superclass {
            if superclass.contains("Monster") || superclass.contains("Enemy") {
                return EntityType::Monster;
            }
            if superclass.contains("Animal") || superclass.contains("TamableAnimal") {
                return EntityType::Animal;
            }
            if superclass.contains("Projectile") || superclass.contains("ThrowableItem") {
                return EntityType::Projectile;
            }
            if superclass.contains("Vehicle") || superclass.contains("Boat") || superclass.contains("Minecart") {
                return EntityType::Vehicle;
            }
            if superclass.contains("WaterAnimal") || superclass.contains("Fish") {
                return EntityType::WaterCreature;
            }
            if superclass.contains("Boss") || superclass.contains("EnderDragon") || superclass.contains("Wither") {
                return EntityType::Boss;
            }
            if superclass.contains("Mob") || superclass.contains("PathfinderMob") {
                return EntityType::Mob;
            }
        }
        EntityType::Unknown
    }

    pub fn extract_entity_properties(&self, class: &ClassIR) -> EntityProperties {
        let mut props = EntityProperties::default();
        props.width = 0.6;
        props.height = 1.8;
        props.max_health = 20.0;
        props.movement_speed = 0.25;
        props.follow_range = 16.0;
        props.is_summonable = true;
        props
    }

    pub fn parse_recipe_json(&self, json: &serde_json::Value, path: &str) -> Option<RecipeIR> {
        let recipe_type = json.get("type")?.as_str()?;

        let mut recipe = RecipeIR::default();
        recipe.id = path
            .split('/')
            .last()?
            .trim_end_matches(".json")
            .to_string();

        recipe.recipe_type = match recipe_type {
            "minecraft:crafting_shaped" | "crafting_shaped" => RecipeType::Shaped,
            "minecraft:crafting_shapeless" | "crafting_shapeless" => RecipeType::Shapeless,
            "minecraft:smelting" | "smelting" => RecipeType::Smelting,
            "minecraft:blasting" | "blasting" => RecipeType::Blasting,
            "minecraft:smoking" | "smoking" => RecipeType::Smoking,
            "minecraft:campfire_cooking" | "campfire_cooking" => RecipeType::Campfire,
            "minecraft:stonecutting" | "stonecutting" => RecipeType::Stonecutting,
            "minecraft:smithing" | "smithing_transform" => RecipeType::Smithing,
            _ => RecipeType::Custom,
        };

        // Parse pattern for shaped recipes
        if let Some(pattern) = json.get("pattern") {
            recipe.pattern = pattern
                .as_array()
                .map(|arr| arr.iter().filter_map(|v| v.as_str().map(|s| s.to_string())).collect());
        }

        // Parse key mappings
        if let Some(key) = json.get("key").and_then(|k| k.as_object()) {
            for (k, v) in key {
                let item_id = v.get("item").or_else(|| v.get("tag"))
                    .and_then(|i| i.as_str())
                    .unwrap_or("unknown")
                    .to_string();

                recipe.inputs.push(RecipeIngredient {
                    item_id,
                    count: 1,
                    tag: v.get("tag").and_then(|t| t.as_str()).map(|s| s.to_string()),
                    key: k.chars().next(),
                });
            }
        }

        // Parse ingredients for shapeless recipes
        if let Some(ingredients) = json.get("ingredients").and_then(|i| i.as_array()) {
            for ing in ingredients {
                let item_id = ing.get("item").or_else(|| ing.get("tag"))
                    .and_then(|i| i.as_str())
                    .unwrap_or("unknown")
                    .to_string();

                recipe.inputs.push(RecipeIngredient {
                    item_id,
                    count: 1,
                    tag: ing.get("tag").and_then(|t| t.as_str()).map(|s| s.to_string()),
                    key: None,
                });
            }
        }

        // Parse result
        if let Some(result) = json.get("result") {
            recipe.output = RecipeOutput {
                item_id: result.get("item").or_else(|| result.get("id"))
                    .and_then(|i| i.as_str())
                    .unwrap_or("unknown")
                    .to_string(),
                count: result.get("count").and_then(|c| c.as_u64()).unwrap_or(1) as u8,
                nbt: result.get("nbt").cloned(),
            };
        }

        recipe.group = json.get("group").and_then(|g| g.as_str()).map(|s| s.to_string());

        Some(recipe)
    }

    pub fn extract_programmatic_recipes(&self, _method: &MethodIR) -> Vec<RecipeIR> {
        // This would analyze method bytecode for recipe registration calls
        Vec::new()
    }

    pub fn determine_event_type(&self, method: &MethodIR) -> String {
        // Try to determine from first parameter type
        if let Some(param) = method.parameters.first() {
            return param.param_type.clone();
        }
        "UnknownEvent".to_string()
    }

    pub fn assess_complexity(&self, code: &str) -> Complexity {
        let lines = code.lines().count();
        let has_loops = code.contains("for") || code.contains("while");
        let has_conditionals = code.contains("if");
        let has_reflection = code.contains("reflect") || code.contains("invoke");
        let has_nbt = code.contains("CompoundTag") || code.contains("NBT");

        if has_reflection || lines > 100 {
            Complexity::VeryComplex
        } else if has_loops && has_conditionals && lines > 50 {
            Complexity::Complex
        } else if has_loops || (has_conditionals && lines > 20) || has_nbt {
            Complexity::Moderate
        } else {
            Complexity::Simple
        }
    }

    pub fn classify_worldgen_type(&self, class: &ClassIR) -> WorldGenType {
        let name_lower = class.name.to_lowercase();

        if name_lower.contains("ore") {
            WorldGenType::Ore
        } else if name_lower.contains("tree") || name_lower.contains("trunk") {
            WorldGenType::Tree
        } else if name_lower.contains("flower") || name_lower.contains("plant") {
            WorldGenType::Flower
        } else if name_lower.contains("lake") || name_lower.contains("pond") {
            WorldGenType::Lake
        } else if name_lower.contains("structure") || name_lower.contains("building") {
            WorldGenType::Structure
        } else if name_lower.contains("biome") {
            WorldGenType::Biome
        } else if name_lower.contains("dimension") {
            WorldGenType::Dimension
        } else {
            WorldGenType::Custom
        }
    }

    pub fn assess_worldgen_complexity(&self, class: &ClassIR) -> Complexity {
        let method_count = class.methods.len();
        let has_structure = class.name.to_lowercase().contains("structure");
        let has_dimension = class.name.to_lowercase().contains("dimension");

        if has_dimension {
            Complexity::Impossible // Dimensions cannot be ported
        } else if has_structure && method_count > 10 {
            Complexity::VeryComplex
        } else if method_count > 5 {
            Complexity::Complex
        } else {
            Complexity::Moderate
        }
    }

    pub fn classify_gui_type(&self, class: &ClassIR) -> GuiType {
        if let Some(ref superclass) = class.superclass {
            if superclass.contains("ContainerScreen") || superclass.contains("AbstractContainerScreen") {
                return GuiType::Container;
            }
            if superclass.contains("Screen") {
                return GuiType::Screen;
            }
            if superclass.contains("Menu") || superclass.contains("AbstractContainerMenu") {
                return GuiType::Menu;
            }
        }
        GuiType::Unknown
    }

    pub fn extract_inventory_slots(&self, class: &ClassIR) -> Vec<SlotIR> {
        let mut slots = Vec::new();

        // Look for addSlot calls or Slot field declarations
        for method in &class.methods {
            if method.name == "<init>" || method.name.contains("Slot") {
                // Would need bytecode analysis for exact slot positions
                // For now, return empty
            }
        }

        slots
    }

    pub fn classify_renderer_type(&self, class: &ClassIR) -> RendererType {
        let name_lower = class.name.to_lowercase();

        if name_lower.contains("block") {
            RendererType::Block
        } else if name_lower.contains("entity") || name_lower.contains("mob") {
            RendererType::Entity
        } else if name_lower.contains("item") {
            RendererType::Item
        } else if name_lower.contains("tileentity") || name_lower.contains("blockentity") {
            RendererType::TileEntity
        } else if name_lower.contains("particle") {
            RendererType::Particle
        } else if name_lower.contains("shader") {
            RendererType::Shader
        } else {
            RendererType::Unknown
        }
    }
}
