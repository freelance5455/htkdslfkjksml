use anyhow::{Context, Result};
use std::collections::HashMap;
use std::fs::{self, File};
use std::io::Read;
use std::path::{Path, PathBuf};
use walkdir::WalkDir;
use zip::ZipArchive;

use crate::ir::{AssetIR, ModAssets};

/// Extracted mod contents ready for analysis
#[derive(Debug, Default)]
pub struct ExtractedMod {
    /// Raw class file bytes
    pub classes: HashMap<String, Vec<u8>>,
    /// Mod metadata files (fabric.mod.json, mods.toml, etc.)
    pub metadata_files: HashMap<String, String>,
    /// Assets organized by type
    pub assets: ModAssets,
    /// Temporary extraction path (if extracted from jar)
    pub temp_path: Option<PathBuf>,
}

/// Handles extraction of Java mods from various sources
pub struct ModExtractor {
    input_path: PathBuf,
    is_jar: bool,
}

impl ModExtractor {
    pub fn new(input: &Path) -> Result<Self> {
        if !input.exists() {
            anyhow::bail!("Input path does not exist: {:?}", input);
        }

        let is_jar = input.extension().map_or(false, |ext| ext == "jar");

        Ok(Self {
            input_path: input.to_path_buf(),
            is_jar,
        })
    }

    pub fn extract(&self) -> Result<ExtractedMod> {
        if self.is_jar {
            self.extract_jar()
        } else {
            self.extract_folder()
        }
    }

    fn extract_jar(&self) -> Result<ExtractedMod> {
        let file = File::open(&self.input_path)
            .with_context(|| format!("Failed to open jar: {:?}", self.input_path))?;

        let mut archive = ZipArchive::new(file)?;
        let mut extracted = ExtractedMod::default();

        for i in 0..archive.len() {
            let mut entry = archive.by_index(i)?;
            let name = entry.name().to_string();

            if entry.is_dir() {
                continue;
            }

            // Extract class files
            if name.ends_with(".class") {
                let mut bytes = Vec::new();
                entry.read_to_end(&mut bytes)?;
                extracted.classes.insert(name, bytes);
            }
            // Extract metadata files
            else if Self::is_metadata_file(&name) {
                let mut content = String::new();
                entry.read_to_string(&mut content)?;
                extracted.metadata_files.insert(name, content);
            }
            // Extract assets
            else {
                Self::categorize_asset(&name, &mut entry, &mut extracted.assets)?;
            }
        }

        Ok(extracted)
    }

    fn extract_folder(&self) -> Result<ExtractedMod> {
        let mut extracted = ExtractedMod::default();

        for entry in WalkDir::new(&self.input_path) {
            let entry = entry?;
            if !entry.file_type().is_file() {
                continue;
            }

            let path = entry.path();
            let relative = path
                .strip_prefix(&self.input_path)
                .unwrap_or(path)
                .to_string_lossy()
                .replace('\\', "/");

            // Extract class files
            if relative.ends_with(".class") {
                let bytes = fs::read(path)?;
                extracted.classes.insert(relative, bytes);
            }
            // Extract metadata files
            else if Self::is_metadata_file(&relative) {
                let content = fs::read_to_string(path)?;
                extracted.metadata_files.insert(relative, content);
            }
            // Handle Java source files if no class files
            else if relative.ends_with(".java") {
                let content = fs::read_to_string(path)?;
                extracted.metadata_files.insert(relative, content);
            }
            // Extract assets
            else {
                let mut file = File::open(path)?;
                Self::categorize_asset(&relative, &mut file, &mut extracted.assets)?;
            }
        }

        Ok(extracted)
    }

    fn is_metadata_file(name: &str) -> bool {
        let metadata_files = [
            "fabric.mod.json",
            "quilt.mod.json",
            "META-INF/mods.toml",
            "mcmod.info",
            "pack.mcmeta",
            "META-INF/MANIFEST.MF",
            "META-INF/accesstransformer.cfg",
            "mixins.json",
        ];

        metadata_files.iter().any(|f| name.ends_with(f))
            || name.contains("mixin") && name.ends_with(".json")
    }

    fn categorize_asset<R: Read>(
        path: &str,
        reader: &mut R,
        assets: &mut ModAssets,
    ) -> Result<()> {
        let asset = |content_type: &str| -> Result<AssetIR> {
            Ok(AssetIR {
                path: path.to_string(),
                content_type: content_type.to_string(),
                content: None,
            })
        };

        let text_asset = |content_type: &str, reader: &mut R| -> Result<AssetIR> {
            let mut content = String::new();
            reader.read_to_string(&mut content)?;
            Ok(AssetIR {
                path: path.to_string(),
                content_type: content_type.to_string(),
                content: Some(content),
            })
        };

        // Textures
        if path.ends_with(".png") {
            if path.contains("textures/") {
                assets.textures.push(asset("texture/png")?);
            }
        }
        // Models
        else if path.contains("models/") && path.ends_with(".json") {
            assets.models.push(text_asset("model/json", reader)?);
        }
        // Blockstates
        else if path.contains("blockstates/") && path.ends_with(".json") {
            assets.blockstates.push(text_asset("blockstate/json", reader)?);
        }
        // Recipes
        else if path.contains("recipes/") && path.ends_with(".json") {
            assets.recipes_json.push(text_asset("recipe/json", reader)?);
        }
        // Loot tables
        else if path.contains("loot_tables/") && path.ends_with(".json") {
            assets.loot_tables_json.push(text_asset("loot_table/json", reader)?);
        }
        // Lang files
        else if path.contains("lang/") && (path.ends_with(".json") || path.ends_with(".lang")) {
            assets.lang_files.push(text_asset("lang", reader)?);
        }
        // Sounds
        else if path.ends_with(".ogg") || path.ends_with(".wav") {
            assets.sounds.push(asset("audio")?);
        }

        Ok(())
    }
}
