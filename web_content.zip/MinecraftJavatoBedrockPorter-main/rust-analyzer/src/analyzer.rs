use anyhow::Result;
use log::{debug, info, warn};
use std::collections::HashMap;

use crate::bytecode::BytecodeAnalyzer;
use crate::extractor::ExtractedMod;
use crate::ir::*;
use crate::patterns::PatternMatcher;

/// Analyzes extracted Java mods and produces structured IR
pub struct ModAnalyzer {
    loader_hint: String,
    bytecode_analyzer: BytecodeAnalyzer,
    pattern_matcher: PatternMatcher,
}

impl ModAnalyzer {
    pub fn new(loader_hint: &str) -> Self {
        Self {
            loader_hint: loader_hint.to_string(),
            bytecode_analyzer: BytecodeAnalyzer::new(),
            pattern_matcher: PatternMatcher::new(),
        }
    }

    pub fn analyze(&self, extracted: &ExtractedMod) -> Result<ModIR> {
        let mut ir = ModIR::default();

        // Detect mod loader
        ir.loader = self.detect_loader(extracted);
        info!("Detected mod loader: {:?}", ir.loader);

        // Parse metadata
        ir.metadata = self.parse_metadata(extracted, &ir.loader)?;
        info!("Mod ID: {}", ir.metadata.mod_id);

        // Analyze all classes
        let classes = self.analyze_classes(extracted)?;
        ir.classes = classes;

        // Detect registered content
        ir.blocks = self.detect_blocks(&ir.classes, extracted);
        ir.items = self.detect_items(&ir.classes, extracted);
        ir.entities = self.detect_entities(&ir.classes, extracted);
        ir.recipes = self.detect_recipes(&ir.classes, extracted);

        info!(
            "Detected: {} blocks, {} items, {} entities, {} recipes",
            ir.blocks.len(),
            ir.items.len(),
            ir.entities.len(),
            ir.recipes.len()
        );

        // Detect event handlers
        ir.event_handlers = self.detect_event_handlers(&ir.classes);
        info!("Detected {} event handlers", ir.event_handlers.len());

        // Detect world generation
        ir.worldgen = self.detect_worldgen(&ir.classes);

        // Detect GUIs
        ir.guis = self.detect_guis(&ir.classes);

        // Detect renderers
        ir.renderers = self.detect_renderers(&ir.classes);

        // Detect advanced features
        ir.advanced_features = self.detect_advanced_features(&ir.classes, extracted);
        if ir.advanced_features.uses_mixins {
            warn!("Mod uses Mixins - some features may not be portable");
        }

        // Include assets
        ir.assets = extracted.assets.clone();

        Ok(ir)
    }

    fn detect_loader(&self, extracted: &ExtractedMod) -> ModLoader {
        if self.loader_hint != "auto" {
            return match self.loader_hint.as_str() {
                "forge" => ModLoader::Forge,
                "fabric" => ModLoader::Fabric,
                "quilt" => ModLoader::Quilt,
                "neoforge" => ModLoader::NeoForge,
                _ => ModLoader::Unknown,
            };
        }

        // Auto-detect based on metadata files
        if extracted.metadata_files.contains_key("fabric.mod.json") {
            return ModLoader::Fabric;
        }
        if extracted.metadata_files.contains_key("quilt.mod.json") {
            return ModLoader::Quilt;
        }
        if extracted.metadata_files.keys().any(|k| k.contains("mods.toml")) {
            // Check for NeoForge vs Forge
            if let Some(content) = extracted.metadata_files.values().find(|v| v.contains("neoforge")) {
                return ModLoader::NeoForge;
            }
            return ModLoader::Forge;
        }
        if extracted.metadata_files.contains_key("mcmod.info") {
            return ModLoader::Forge;
        }

        // Check class names for loader hints
        for class_name in extracted.classes.keys() {
            if class_name.contains("net/fabricmc") {
                return ModLoader::Fabric;
            }
            if class_name.contains("net/minecraftforge") || class_name.contains("cpw/mods/fml") {
                return ModLoader::Forge;
            }
        }

        ModLoader::Unknown
    }

    fn parse_metadata(&self, extracted: &ExtractedMod, loader: &ModLoader) -> Result<ModMetadata> {
        let mut metadata = ModMetadata::default();

        match loader {
            ModLoader::Fabric | ModLoader::Quilt => {
                let key = if *loader == ModLoader::Fabric {
                    "fabric.mod.json"
                } else {
                    "quilt.mod.json"
                };

                if let Some(content) = extracted.metadata_files.get(key) {
                    if let Ok(json) = serde_json::from_str::<serde_json::Value>(content) {
                        metadata.mod_id = json["id"].as_str().unwrap_or("unknown").to_string();
                        metadata.name = json["name"].as_str().unwrap_or(&metadata.mod_id).to_string();
                        metadata.version = json["version"].as_str().unwrap_or("1.0.0").to_string();
                        metadata.description = json["description"].as_str().unwrap_or("").to_string();

                        if let Some(authors) = json["authors"].as_array() {
                            metadata.authors = authors
                                .iter()
                                .filter_map(|a| a.as_str().map(|s| s.to_string()))
                                .collect();
                        }

                        if let Some(deps) = json["depends"].as_object() {
                            metadata.minecraft_version = deps
                                .get("minecraft")
                                .and_then(|v| v.as_str())
                                .unwrap_or("*")
                                .to_string();
                        }
                    }
                }
            }
            ModLoader::Forge | ModLoader::NeoForge => {
                // Parse mods.toml
                for (key, content) in &extracted.metadata_files {
                    if key.contains("mods.toml") {
                        // Simple TOML parsing for key fields
                        for line in content.lines() {
                            let line = line.trim();
                            if line.starts_with("modId") {
                                metadata.mod_id = Self::extract_toml_value(line);
                            } else if line.starts_with("displayName") {
                                metadata.name = Self::extract_toml_value(line);
                            } else if line.starts_with("version") {
                                metadata.version = Self::extract_toml_value(line);
                            } else if line.starts_with("description") {
                                metadata.description = Self::extract_toml_value(line);
                            }
                        }
                        break;
                    }
                }
            }
            _ => {}
        }

        if metadata.mod_id.is_empty() {
            metadata.mod_id = "unknown_mod".to_string();
        }
        if metadata.name.is_empty() {
            metadata.name = metadata.mod_id.clone();
        }

        Ok(metadata)
    }

    fn extract_toml_value(line: &str) -> String {
        line.split('=')
            .nth(1)
            .map(|s| s.trim().trim_matches('"').to_string())
            .unwrap_or_default()
    }

    fn analyze_classes(&self, extracted: &ExtractedMod) -> Result<Vec<ClassIR>> {
        let mut classes = Vec::new();

        for (name, bytes) in &extracted.classes {
            match self.bytecode_analyzer.analyze_class(bytes) {
                Ok(class_ir) => classes.push(class_ir),
                Err(e) => {
                    debug!("Failed to analyze class {}: {}", name, e);
                }
            }
        }

        Ok(classes)
    }

    fn detect_blocks(&self, classes: &[ClassIR], extracted: &ExtractedMod) -> Vec<BlockIR> {
        let mut blocks = Vec::new();

        for class in classes {
            // Check if class extends Block
            let is_block = class.superclass.as_ref().map_or(false, |s| {
                s.contains("Block") && !s.contains("BlockEntity") && !s.contains("BlockState")
            });

            if !is_block {
                continue;
            }

            let mut block = BlockIR::default();
            block.id = class.name.split('/').last().unwrap_or(&class.name).to_string();
            block.registry_name = Self::to_registry_name(&block.id);

            // Analyze block properties from constructor and fields
            for method in &class.methods {
                if method.name == "<init>" || method.name == "Properties" {
                    block.properties = self.pattern_matcher.extract_block_properties(method);
                }
            }

            // Detect behaviors from methods
            for method in &class.methods {
                if let Some(behavior) = self.pattern_matcher.method_to_behavior(method, "block") {
                    block.behaviors.push(behavior);
                }
            }

            // Extract states from blockstate definition
            block.states = self.pattern_matcher.extract_block_states(class);

            blocks.push(block);
        }

        // Also parse blockstate JSON files
        for asset in &extracted.assets.blockstates {
            if let Some(content) = &asset.content {
                if let Ok(json) = serde_json::from_str::<serde_json::Value>(content) {
                    // Merge with existing block or create stub
                    let block_name = asset
                        .path
                        .split('/')
                        .last()
                        .unwrap_or("")
                        .trim_end_matches(".json");

                    if !blocks.iter().any(|b| b.registry_name == block_name) {
                        let mut block = BlockIR::default();
                        block.registry_name = block_name.to_string();
                        block.id = block_name.to_string();
                        blocks.push(block);
                    }
                }
            }
        }

        blocks
    }

    fn detect_items(&self, classes: &[ClassIR], extracted: &ExtractedMod) -> Vec<ItemIR> {
        let mut items = Vec::new();

        for class in classes {
            // Check if class extends Item (but not BlockItem)
            let is_item = class.superclass.as_ref().map_or(false, |s| {
                s.contains("Item") && !s.contains("BlockItem")
            });

            if !is_item {
                continue;
            }

            let mut item = ItemIR::default();
            item.id = class.name.split('/').last().unwrap_or(&class.name).to_string();
            item.registry_name = Self::to_registry_name(&item.id);

            // Analyze item properties
            for method in &class.methods {
                if method.name == "<init>" {
                    item.properties = self.pattern_matcher.extract_item_properties(method);
                }
            }

            // Detect behaviors from methods
            for method in &class.methods {
                if let Some(behavior) = self.pattern_matcher.method_to_behavior(method, "item") {
                    item.behaviors.push(behavior);
                }
            }

            items.push(item);
        }

        items
    }

    fn detect_entities(&self, classes: &[ClassIR], extracted: &ExtractedMod) -> Vec<EntityIR> {
        let mut entities = Vec::new();

        for class in classes {
            // Check if class extends Entity/LivingEntity/Mob
            let is_entity = class.superclass.as_ref().map_or(false, |s| {
                s.contains("Entity") || s.contains("Mob") || s.contains("Monster") || s.contains("Animal")
            });

            if !is_entity {
                continue;
            }

            let mut entity = EntityIR::default();
            entity.id = class.name.split('/').last().unwrap_or(&class.name).to_string();
            entity.registry_name = Self::to_registry_name(&entity.id);

            // Determine entity type
            entity.entity_type = self.pattern_matcher.classify_entity_type(class);

            // Extract properties
            entity.properties = self.pattern_matcher.extract_entity_properties(class);

            // Extract behaviors (AI goals, event handlers)
            for method in &class.methods {
                if let Some(behavior) = self.pattern_matcher.method_to_behavior(method, "entity") {
                    entity.behaviors.push(behavior);
                }
            }

            entities.push(entity);
        }

        entities
    }

    fn detect_recipes(&self, classes: &[ClassIR], extracted: &ExtractedMod) -> Vec<RecipeIR> {
        let mut recipes = Vec::new();

        // Parse recipe JSON files first (most reliable)
        for asset in &extracted.assets.recipes_json {
            if let Some(content) = &asset.content {
                if let Ok(json) = serde_json::from_str::<serde_json::Value>(content) {
                    if let Some(recipe) = self.pattern_matcher.parse_recipe_json(&json, &asset.path) {
                        recipes.push(recipe);
                    }
                }
            }
        }

        // Also look for programmatically registered recipes
        for class in classes {
            if class.name.contains("Recipe") || class.interfaces.iter().any(|i| i.contains("RecipeProvider")) {
                for method in &class.methods {
                    recipes.extend(self.pattern_matcher.extract_programmatic_recipes(method));
                }
            }
        }

        recipes
    }

    fn detect_event_handlers(&self, classes: &[ClassIR]) -> Vec<EventHandlerIR> {
        let mut handlers = Vec::new();

        for class in classes {
            for method in &class.methods {
                // Check for event handler annotations
                let has_event_annotation = method.annotations.iter().any(|a| {
                    a.name.contains("SubscribeEvent")
                        || a.name.contains("EventHandler")
                        || a.name.contains("Inject")
                        || a.name.contains("Listener")
                });

                if has_event_annotation {
                    let handler = EventHandlerIR {
                        event_type: self.pattern_matcher.determine_event_type(method),
                        handler_class: class.name.clone(),
                        handler_method: method.name.clone(),
                        priority: method
                            .annotations
                            .iter()
                            .find(|a| a.name.contains("Priority"))
                            .and_then(|a| a.values.get("value"))
                            .cloned()
                            .unwrap_or_else(|| "NORMAL".to_string()),
                        cancellable: true, // Assume cancellable, could analyze further
                        code: method.body_summary.clone(),
                        complexity: self.pattern_matcher.assess_complexity(&method.body_summary),
                    };
                    handlers.push(handler);
                }
            }
        }

        handlers
    }

    fn detect_worldgen(&self, classes: &[ClassIR]) -> Vec<WorldGenIR> {
        let mut features = Vec::new();

        for class in classes {
            let is_worldgen = class.superclass.as_ref().map_or(false, |s| {
                s.contains("Feature")
                    || s.contains("OreFeature")
                    || s.contains("TreeFeature")
                    || s.contains("Structure")
            }) || class.interfaces.iter().any(|i| i.contains("WorldGenerator"));

            if is_worldgen {
                let mut feature = WorldGenIR::default();
                feature.id = class.name.split('/').last().unwrap_or(&class.name).to_string();
                feature.feature_type = self.pattern_matcher.classify_worldgen_type(class);
                feature.complexity = self.pattern_matcher.assess_worldgen_complexity(class);
                features.push(feature);
            }
        }

        features
    }

    fn detect_guis(&self, classes: &[ClassIR]) -> Vec<GuiIR> {
        let mut guis = Vec::new();

        for class in classes {
            let is_gui = class.superclass.as_ref().map_or(false, |s| {
                s.contains("Screen")
                    || s.contains("ContainerScreen")
                    || s.contains("GuiContainer")
                    || s.contains("AbstractContainerMenu")
            });

            if is_gui {
                let mut gui = GuiIR::default();
                gui.id = class.name.split('/').last().unwrap_or(&class.name).to_string();
                gui.handler_class = class.name.clone();
                gui.gui_type = self.pattern_matcher.classify_gui_type(class);
                gui.inventory_slots = self.pattern_matcher.extract_inventory_slots(class);
                guis.push(gui);
            }
        }

        guis
    }

    fn detect_renderers(&self, classes: &[ClassIR]) -> Vec<RendererIR> {
        let mut renderers = Vec::new();

        for class in classes {
            let is_renderer = class.superclass.as_ref().map_or(false, |s| {
                s.contains("Renderer")
                    || s.contains("RenderType")
                    || s.contains("ShaderInstance")
            }) || class.interfaces.iter().any(|i| i.contains("Renderer"));

            if is_renderer {
                let renderer = RendererIR {
                    renderer_type: self.pattern_matcher.classify_renderer_type(class),
                    target: String::new(),
                    class_name: class.name.clone(),
                    complexity: Complexity::Complex, // Renderers are typically complex
                };
                renderers.push(renderer);
            }
        }

        renderers
    }

    fn detect_advanced_features(
        &self,
        classes: &[ClassIR],
        extracted: &ExtractedMod,
    ) -> AdvancedFeatures {
        let mut features = AdvancedFeatures::default();

        // Check for mixin usage
        features.uses_mixins = extracted
            .metadata_files
            .keys()
            .any(|k| k.contains("mixin"))
            || classes.iter().any(|c| {
                c.annotations.iter().any(|a| a.name.contains("Mixin"))
            });

        if features.uses_mixins {
            features.mixin_classes = classes
                .iter()
                .filter(|c| c.annotations.iter().any(|a| a.name.contains("Mixin")))
                .map(|c| c.name.clone())
                .collect();
        }

        // Check for ASM usage
        features.uses_asm = classes.iter().any(|c| {
            c.name.contains("asm/") || c.superclass.as_ref().map_or(false, |s| s.contains("ClassVisitor"))
        });

        // Check for reflection
        for class in classes {
            for method in &class.methods {
                if method.body_summary.contains("getMethod")
                    || method.body_summary.contains("getDeclaredField")
                    || method.body_summary.contains("invoke(")
                {
                    features.uses_reflection = true;
                    features.reflection_usages.push(ReflectionUsage {
                        class_name: class.name.clone(),
                        method_name: method.name.clone(),
                        target_class: String::new(),
                        target_member: String::new(),
                    });
                }
            }
        }

        // Check for coremods
        features.uses_coremods = extracted
            .metadata_files
            .keys()
            .any(|k| k.contains("coremod") || k.contains("coremods.json"))
            || classes.iter().any(|c| c.interfaces.iter().any(|i| i.contains("IFMLLoadingPlugin")));

        // Check for access transformers
        features.uses_access_transformers = extracted
            .metadata_files
            .keys()
            .any(|k| k.contains("accesstransformer") || k.contains("_at.cfg"));

        // Detect network handlers
        for class in classes {
            if class.name.contains("Packet")
                || class.interfaces.iter().any(|i| i.contains("CustomPayload"))
            {
                features.network_handlers.push(NetworkHandlerIR {
                    channel: String::new(),
                    packet_class: class.name.clone(),
                    direction: "BIDIRECTIONAL".to_string(),
                });
            }
        }

        // Detect capabilities
        for class in classes {
            if class.interfaces.iter().any(|i| i.contains("ICapabilityProvider")) {
                features.capabilities.push(CapabilityIR {
                    name: class.name.clone(),
                    interface_class: String::new(),
                    implementation_class: class.name.clone(),
                });
            }
        }

        features
    }

    fn to_registry_name(class_name: &str) -> String {
        // Convert CamelCase to snake_case
        let mut result = String::new();
        for (i, ch) in class_name.chars().enumerate() {
            if ch.is_uppercase() && i > 0 {
                result.push('_');
            }
            result.push(ch.to_lowercase().next().unwrap());
        }
        result
    }
}
