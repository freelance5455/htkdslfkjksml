# Java-to-Bedrock Mod Porter

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node.js](https://img.shields.io/badge/Node.js-18%2B-green.svg)](https://nodejs.org/)
[![Rust](https://img.shields.io/badge/Rust-1.70%2B-orange.svg)](https://www.rust-lang.org/)
[![Status](https://img.shields.io/badge/Status-Work%20in%20Progress-blue.svg)]()
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0%2B-blue.svg)](https://www.typescriptlang.org/)

A tool for porting Minecraft Java Edition mods to Bedrock Edition addons.

> ⚠️ **Work in Progress**: This tool is under active development. Features are being tested and refined. Complex mods will require manual adjustments.

![GUI Screenshot](docs/screenshot.png)

## Quick Start

1. **Download or build the tool** ([see Installation](#installation))
   ```bash
   git clone https://github.com/JacYosAkiCra/MinecraftJavatoBedrockPorter.git
   cd MinecraftJavatoBedrockPorter
   npm install && npm run build
   ```

2. **Run the GUI** ([see Usage](#gui-application))
   ```bash
   cd gui && npm install && npm run build && npm run start
   ```

3. **Drag a simple Forge mod** (e.g., 1.16–1.20 content mod) into the window ([see What This Tool Can Currently Do](#what-this-tool-can-currently-do))

4. **Review the generated addon and porting report** ([see Output Structure](#output-structure))

## Features (In Development)

- **Java Mod Analysis**: Extracts blocks, items, entities, and recipes from .jar files and source directories
- **Mapping Engine**: Maps Java mod concepts to Bedrock equivalents where possible
- **Graceful Degradation**: Applies fallback strategies when features can't be directly ported
- **Addon Generation**: Generates Bedrock addon structure with behavior packs and resource packs
- **Validation**: Basic schema and reference validation
- **Reporting**: Generates porting reports in Markdown, JSON, or HTML
- **GUI Application**: Electron-based desktop interface (experimental)

## What This Tool Can Currently Do

### ✅ Can Port Today
- **Simple Blocks**: Basic blocks with standard properties (hardness, resistance, material)
- **Simple Items**: Items with basic properties (stack size, durability, food values)
- **Crafting Recipes**: Shaped, shapeless, and smelting recipes from JSON files
- **Basic Entities**: Entity definitions with standard components (health, movement, spawning)
- **Mod Metadata**: Extracts mod info and generates proper Bedrock manifests
- **Asset Structure**: Maps texture/model paths to Bedrock addon structure

### ⚠️ Ports with Manual Work Required
- **Block States**: Detected but may need manual property mapping
- **Custom Items**: Tool/weapon/armor items with custom behaviors need script work
- **Entity Behaviors**: Basic behaviors mapped; complex AI needs manual scripting
- **Loot Tables**: Structure converted; item references may need adjustment
- **Lang Files**: Translations extracted; format converted to Bedrock .lang

### 🚫 Cannot Port (Yet)
- **Custom Rendering**: Shaders, custom block models with Java-specific features
- **Mixins/ASM**: Bytecode modifications require complete reimplementation
- **Complex GUIs**: Custom screens beyond Bedrock's form system
- **World Generation**: Custom biomes, structures, dimensions
- **Networking**: Custom packets and client-server communication
- **Mod Integrations**: Cross-mod compatibility features

### Best Results With
- Small to medium-sized mods
- Mods with mostly content additions (blocks, items, recipes)
- Standard Forge/Fabric registration patterns
- JSON-based recipes and loot tables
- Mods without heavy custom logic or rendering

## Tested Mods

| Mod | Loader | Version | Result | Notes |
|-----|--------|---------|--------|-------|
| *None yet* | - | - | - | Testing in progress |

> **Help wanted!** If you test this tool with a mod, please [open an issue](https://github.com/JacYosAkiCra/MinecraftJavatoBedrockPorter/issues) with your results so we can update this list.

## Implementation Status

### Rust Analyzer (Java Bytecode Analysis)

| Status | Feature | Description |
|--------|---------|-------------|
| ✅ | JAR Extraction | Extracts classes, assets, and metadata from .jar files |
| ✅ | Bytecode Parsing | Parses Java .class files to extract class structure |
| ✅ | Mod Loader Detection | Auto-detects Forge/Fabric/Quilt from metadata files |
| ✅ | Metadata Parsing | Reads fabric.mod.json, mods.toml, mcmod.info |
| ✅ | Block/Item/Entity Detection | Finds classes extending Block, Item, Entity |
| ✅ | Recipe JSON Parsing | Parses recipe JSON files from mod assets |
| ✅ | Event Handler Detection | Identifies `@SubscribeEvent` annotated methods |
| ⚠️ | Behavior Detection | Recognizes method names but doesn't deeply analyze logic |
| ⚠️ | Method Body Analysis | Captured as stubs; actual logic not translated |
| ⚠️ | Annotation Parsing | Basic values extracted; complex structures may be missed |
| ⚠️ | Mixin Awareness | Flags presence but can't analyze mixin targets |
| 🚧 | Full Method Translation | Converting Java methods to intermediate representation |
| 🚧 | Entity AI Detection | Extracting AI goal patterns from bytecode |
| 🚧 | World Gen Detection | Identifying biome and structure registration |

### TypeScript Porter (Mapping & Generation)

| Status | Feature | Description |
|--------|---------|-------------|
| ✅ | CLI Interface | `port`, `analyze`, `validate`, `init` commands |
| ✅ | Mapping Engine | Maps Java IR to Bedrock addon IR |
| ✅ | Degradation Strategies | Approximate, Simplify, Script, Stub, Omit |
| ✅ | Bedrock JSON Generation | Outputs valid addon structure with manifests |
| ✅ | Basic Validation | Schema validation for generated files |
| ✅ | Report Generation | Markdown, JSON, HTML report formats |
| ✅ | .mcpack/.mcaddon Creation | Packages addons for distribution |
| ⚠️ | Texture/Model Copying | Paths mapped but files need manual copying |
| ⚠️ | Script Generation | Generates stubs; complex logic needs manual work |
| 🚧 | Script API Translation | Converting behaviors to Bedrock Script API |
| 🚧 | Entity AI Mapping | Translating AI goals to behavior packs |
| 🚧 | Particle Effects | Java particle systems to Bedrock format |
| 🚧 | Sound Events | Sound mapping and conversion |

### GUI Application (Electron)

| Status | Feature | Description |
|--------|---------|-------------|
| ✅ | Desktop Interface | Electron + React + Tailwind application |
| ✅ | Drag-and-Drop | File/folder selection via drag or click |
| ✅ | Configuration Panel | Porting options and settings |
| ✅ | Progress Display | Visual progress during porting |
| ⚠️ | CLI Integration | Basic connection; full workflow testing in progress |
| 🚧 | Settings Persistence | Saving user preferences |

**Legend:** ✅ Implemented | ⚠️ Partial/Basic | 🚧 In Development

## Targeted Mod Loaders

- Forge (1.16 - 1.20)
- Fabric
- Quilt

> Note: Mod loader detection is heuristic-based. Results may vary depending on how mods register their content.

## Installation

```bash
# Clone the repository
git clone <repository-url>
cd ModPorter

# Install dependencies
npm install

# Build TypeScript
npm run build

# (Optional) Build Rust analyzer for enhanced analysis
npm run build:rust
```

### Prerequisites

- Node.js 18+
- TypeScript 5+
- Rust (for building the Java analyzer - optional but recommended)

## Usage

### GUI Application

```bash
# Navigate to GUI directory
cd gui

# Install dependencies
npm install

# Build and run
npm run build
npm run start
```

The GUI provides:
- Drag-and-drop mod file selection
- Visual configuration options
- Real-time porting progress
- Output log viewer

### Command Line

```bash
# Port a Java mod
npx modporter port path/to/mod.jar -o ./output

# Port with verbose logging
npx modporter port mod.jar -o ./output --verbose

# Port without creating .mcpack/.mcaddon files
npx modporter port mod.jar -o ./output --no-packages

# Generate HTML report instead of Markdown
npx modporter port mod.jar -o ./output -f html

# Analyze a mod without porting
npx modporter analyze mod.jar -o analysis.json

# Validate an existing addon
npx modporter validate ./my-addon

# Create a new addon project
npx modporter init my-new-addon
```

### Programmatic API

```typescript
import { ModPorter } from 'modporter';

const porter = new ModPorter({
  input: './my-mod.jar',
  output: './output',
  loader: 'auto',
  createPackages: true,
  validate: true,
  generateReport: true,
});

const result = await porter.port();

if (result.success) {
  console.log(`Ported successfully! Success rate: ${result.report?.statistics.successRate}%`);
} else {
  console.error('Porting failed:', result.errors);
}
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Java Mod Input                                  │
│                       (.jar file or source directory)                       │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Rust Java Analyzer                                 │
│  • Bytecode parsing          • AST extraction        • Pattern matching     │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Java Intermediate Representation                      │
│  • Blocks    • Items    • Entities    • Recipes    • Events    • WorldGen   │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                             Mapping Engine                                   │
│  • Feature mapping           • Capability checking   • Script generation    │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Degradation Policy                                  │
│  • Approximate   • Simplify   • Script fallback   • Stub   • Omit          │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                       Bedrock Intermediate Representation                    │
│  • Behavior Pack    • Resource Pack    • Scripts    • Manifests            │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            Code Generator                                    │
│  • JSON definitions          • TypeScript scripts    • Pack structure       │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Validator                                       │
│  • Schema validation         • Reference checking    • Script verification  │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Report Generator                                   │
│  • Porting statistics        • Feature mapping       • Recommendations      │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            Bedrock Addon Output                              │
│            (.mcpack / .mcaddon + behavior_pack + resource_pack)             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Output Structure

```
output/
├── behavior_pack/
│   ├── manifest.json
│   ├── blocks/
│   │   └── *.json
│   ├── items/
│   │   └── *.json
│   ├── entities/
│   │   └── *.json
│   ├── recipes/
│   │   └── *.json
│   ├── loot_tables/
│   │   └── *.json
│   └── scripts/
│       └── *.js
├── resource_pack/
│   ├── manifest.json
│   ├── textures/
│   │   ├── blocks/
│   │   ├── items/
│   │   └── entity/
│   ├── models/
│   │   └── *.json
│   ├── texts/
│   │   └── en_US.lang
│   └── sounds/
│       └── sound_definitions.json
├── addon.mcaddon          # Combined pack for distribution
├── behavior_pack.mcpack   # Standalone behavior pack
├── resource_pack.mcpack   # Standalone resource pack
└── porting-report.md      # Detailed porting report
```

## Degradation Strategies

When a Java feature cannot be perfectly mapped to Bedrock, the porter applies degradation strategies:

| Strategy | Description |
|----------|-------------|
| **Approximate** | Use a similar feature that preserves most functionality |
| **Simplify** | Reduce complexity while maintaining core behavior |
| **Script** | Implement in TypeScript using Bedrock Script API |
| **Stub** | Create a non-functional placeholder with TODO comments |
| **Omit** | Remove the feature entirely (with documentation) |

## Configuration

Create a `modporter.config.json` file for project-specific settings:

```json
{
  "output": "./dist",
  "loader": "auto",
  "createPackages": true,
  "validate": true,
  "generateReport": true,
  "reportFormat": "markdown",
  "minifyJson": false,
  "compileScripts": true
}
```

## Known Limitations

- **Custom rendering**: Advanced Java rendering techniques may not have Bedrock equivalents
- **Mixins/ASM**: Bytecode modifications cannot be directly ported
- **Complex GUIs**: Limited to Bedrock's form system (dialogs, action forms)
- **World generation**: Significant differences in biome and structure systems
- **Networking**: Custom packets require Script API reimplementation
- **Complex logic**: Java methods are stubbed; manual Script API implementation needed
- **Pattern detection**: Heuristic-based; may not recognize custom registration patterns
- **Textures**: Paths are mapped but images need manual copying to output

## Current Status

This tool is in **active development**. It works best for:
- Simple mods with standard blocks, items, and recipes
- Mods using common Forge/Fabric registration patterns
- Generating a starting scaffold that you can refine

For complex mods, expect to manually adjust the generated output.

## Roadmap

### Phase 1 - Core Foundation ✅
- [x] Project structure and CLI
- [x] Rust-based Java bytecode analyzer
- [x] Basic block, item, entity extraction
- [x] Mapping engine with degradation strategies
- [x] Bedrock addon JSON generation
- [x] Basic validation
- [x] Report generation (MD/JSON/HTML)
- [x] Electron GUI scaffold

### Phase 2 - Improved Analysis (In Progress)
- [ ] Better Forge annotation detection
- [ ] Fabric mixin awareness
- [ ] Recipe pattern recognition improvements
- [ ] Texture/model file copying
- [ ] GUI ↔ CLI integration testing

### Phase 3 - Enhanced Generation
- [ ] Script API code generation for behaviors
- [ ] Entity AI mapping
- [ ] Particle effect conversion
- [ ] Sound event mapping
- [ ] Loot table conversion improvements

### Phase 4 - Polish & Distribution
- [ ] Comprehensive test suite with real mods
- [ ] Pre-built binaries (Windows, macOS, Linux)
- [ ] Documentation and tutorials
- [ ] Community feedback integration

## Planned Features

Long-term goals for the tool:

- [ ] Expand Rust analyzer to detect behaviors and events
- [ ] Implement full IR schema for blocks, items, entities, recipes
- [ ] Add Fabric and Quilt registry detection
- [ ] Improve mapping engine with pattern-based rules
- [ ] Add AI-assisted behavior translation
- [ ] Implement worldgen degradation strategies
- [ ] Add automated test suite with sample mods

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT License - see [LICENSE](LICENSE) for details.
