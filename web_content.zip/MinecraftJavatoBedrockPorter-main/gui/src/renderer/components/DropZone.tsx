import React, { useState, useCallback } from 'react';

interface DropZoneProps {
  value: string;
  onSelectFile: () => void;
  onSelectFolder: () => void;
}

export const DropZone: React.FC<DropZoneProps> = ({ value, onSelectFile, onSelectFolder }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    // Note: In Electron, we'd need to handle file drops differently
    // For now, just use the dialog
  }, []);

  const fileName = value ? value.split(/[/\\]/).pop() : null;

  return (
    <div
      className={`
        drop-zone glass rounded-2xl p-8 text-center transition-all duration-300
        border-2 border-dashed
        ${isDragging ? 'dragging border-green-500' : 'border-slate-600 hover:border-slate-500'}
        ${value ? 'bg-green-900/10' : ''}
      `}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {value ? (
        <div className="space-y-4">
          <div className="w-16 h-16 mx-auto bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center">
            <span className="text-3xl">📦</span>
          </div>
          <div>
            <p className="text-lg font-semibold text-white">{fileName}</p>
            <p className="text-sm text-slate-400 truncate max-w-md mx-auto">{value}</p>
          </div>
          <div className="flex justify-center gap-3">
            <button
              onClick={onSelectFile}
              className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm transition-colors"
            >
              Change File
            </button>
            <button
              onClick={onSelectFolder}
              className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm transition-colors"
            >
              Select Folder
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="w-20 h-20 mx-auto bg-slate-700/50 rounded-2xl flex items-center justify-center">
            <svg className="w-10 h-10 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
          </div>
          <div>
            <p className="text-lg font-semibold text-white">Drop your Java mod here</p>
            <p className="text-slate-400">or click to browse</p>
          </div>
          <div className="flex justify-center gap-3">
            <button
              onClick={onSelectFile}
              className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 rounded-xl font-medium transition-all hover:scale-105"
            >
              📁 Select .jar File
            </button>
            <button
              onClick={onSelectFolder}
              className="px-6 py-3 bg-slate-700 hover:bg-slate-600 rounded-xl font-medium transition-colors"
            >
              📂 Select Folder
            </button>
          </div>
          <p className="text-xs text-slate-500">
            Supports Forge, Fabric, and Quilt mods
          </p>
        </div>
      )}
    </div>
  );
};
