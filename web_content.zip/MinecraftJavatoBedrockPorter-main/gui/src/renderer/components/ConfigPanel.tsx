import React from 'react';
import { PortingConfig } from '../types';

interface ConfigPanelProps {
  config: PortingConfig;
  onChange: (config: PortingConfig) => void;
  onSelectOutput: () => void;
}

export const ConfigPanel: React.FC<ConfigPanelProps> = ({ config, onChange, onSelectOutput }) => {
  const outputName = config.output ? config.output.split(/[/\\]/).pop() : 'Select output folder...';

  return (
    <div className="glass rounded-2xl p-6 space-y-6">
      <h3 className="text-lg font-semibold flex items-center gap-2">
        <span>⚙️</span>
        Configuration
      </h3>

      {/* Output Folder */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-slate-300">Output Folder</label>
        <button
          onClick={onSelectOutput}
          className="w-full px-4 py-3 bg-slate-800 hover:bg-slate-700 rounded-xl text-left transition-colors flex items-center justify-between"
        >
          <span className={config.output ? 'text-white' : 'text-slate-500'}>{outputName}</span>
          <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
          </svg>
        </button>
      </div>

      {/* Options Grid */}
      <div className="grid grid-cols-2 gap-4">
        {/* Mod Loader */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Mod Loader</label>
          <select
            value={config.loader}
            onChange={(e) => onChange({ ...config, loader: e.target.value as PortingConfig['loader'] })}
            className="w-full px-4 py-3 bg-slate-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="auto">Auto Detect</option>
            <option value="forge">Forge</option>
            <option value="fabric">Fabric</option>
            <option value="quilt">Quilt</option>
          </select>
        </div>

        {/* Report Format */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Report Format</label>
          <select
            value={config.reportFormat}
            onChange={(e) => onChange({ ...config, reportFormat: e.target.value as PortingConfig['reportFormat'] })}
            className="w-full px-4 py-3 bg-slate-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="markdown">Markdown</option>
            <option value="html">HTML</option>
            <option value="json">JSON</option>
          </select>
        </div>
      </div>

      {/* Toggles */}
      <div className="grid grid-cols-2 gap-4">
        <Toggle
          label="Create .mcpack/.mcaddon"
          checked={config.createPackages}
          onChange={(checked) => onChange({ ...config, createPackages: checked })}
        />
        <Toggle
          label="Validate Output"
          checked={config.validate}
          onChange={(checked) => onChange({ ...config, validate: checked })}
        />
        <Toggle
          label="Generate Report"
          checked={config.generateReport}
          onChange={(checked) => onChange({ ...config, generateReport: checked })}
        />
        <Toggle
          label="Verbose Logging"
          checked={config.verbose}
          onChange={(checked) => onChange({ ...config, verbose: checked })}
        />
      </div>
    </div>
  );
};

interface ToggleProps {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

const Toggle: React.FC<ToggleProps> = ({ label, checked, onChange }) => {
  return (
    <label className="flex items-center justify-between p-3 bg-slate-800/50 rounded-xl cursor-pointer hover:bg-slate-800 transition-colors">
      <span className="text-sm text-slate-300">{label}</span>
      <div
        className={`
          w-10 h-6 rounded-full transition-colors relative
          ${checked ? 'bg-green-600' : 'bg-slate-600'}
        `}
        onClick={() => onChange(!checked)}
      >
        <div
          className={`
            absolute top-1 w-4 h-4 bg-white rounded-full transition-transform
            ${checked ? 'translate-x-5' : 'translate-x-1'}
          `}
        />
      </div>
    </label>
  );
};
