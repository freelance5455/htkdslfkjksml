import React from 'react';
import { PortingState } from '../types';

interface ResultPanelProps {
  state: PortingState;
  outputPath: string;
  onOpenOutput: () => void;
  onReset: () => void;
}

export const ResultPanel: React.FC<ResultPanelProps> = ({
  state,
  outputPath,
  onOpenOutput,
  onReset,
}) => {
  const isSuccess = state.step === 'complete';

  return (
    <div className={`glass rounded-2xl p-8 text-center space-y-6 ${
      isSuccess ? 'border-green-500/30' : 'border-red-500/30'
    } border`}>
      {/* Status Icon */}
      <div className={`
        w-24 h-24 mx-auto rounded-full flex items-center justify-center
        ${isSuccess
          ? 'bg-gradient-to-br from-green-500 to-emerald-600'
          : 'bg-gradient-to-br from-red-500 to-rose-600'
        }
      `}>
        {isSuccess ? (
          <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        ) : (
          <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        )}
      </div>

      {/* Title */}
      <div>
        <h3 className={`text-2xl font-bold ${isSuccess ? 'text-green-400' : 'text-red-400'}`}>
          {isSuccess ? 'Porting Complete!' : 'Porting Failed'}
        </h3>
        <p className="text-slate-400 mt-2">
          {isSuccess
            ? 'Your Bedrock addon is ready to use'
            : state.result?.error || 'An error occurred during porting'
          }
        </p>
      </div>

      {/* Output Files */}
      {isSuccess && (
        <div className="glass-dark rounded-xl p-4 text-left space-y-3">
          <h4 className="font-semibold text-slate-300">Generated Files:</h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-3 text-slate-400">
              <span className="text-lg">📦</span>
              <span>Behavior Pack</span>
            </div>
            <div className="flex items-center gap-3 text-slate-400">
              <span className="text-lg">🎨</span>
              <span>Resource Pack</span>
            </div>
            <div className="flex items-center gap-3 text-slate-400">
              <span className="text-lg">📄</span>
              <span>.mcaddon Package</span>
            </div>
            <div className="flex items-center gap-3 text-slate-400">
              <span className="text-lg">📋</span>
              <span>Porting Report</span>
            </div>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex justify-center gap-4">
        {isSuccess && (
          <button
            onClick={onOpenOutput}
            className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 rounded-xl font-medium transition-all hover:scale-105"
          >
            📂 Open Output Folder
          </button>
        )}
        <button
          onClick={onReset}
          className="px-6 py-3 bg-slate-700 hover:bg-slate-600 rounded-xl font-medium transition-colors"
        >
          🔄 Port Another Mod
        </button>
      </div>

      {/* Quick Info */}
      {isSuccess && (
        <div className="text-sm text-slate-500">
          <p>Output saved to: <code className="bg-slate-800 px-2 py-1 rounded">{outputPath}</code></p>
        </div>
      )}
    </div>
  );
};
