import React from 'react';
import { PortingState } from '../types';

interface ProgressPanelProps {
  state: PortingState;
  onCancel: () => void;
}

const steps = [
  { id: 'analyzing', label: 'Analyzing', icon: '🔍', description: 'Parsing Java mod structure...' },
  { id: 'mapping', label: 'Mapping', icon: '🗺️', description: 'Mapping features to Bedrock...' },
  { id: 'generating', label: 'Generating', icon: '⚙️', description: 'Creating addon files...' },
  { id: 'validating', label: 'Validating', icon: '✅', description: 'Checking for errors...' },
];

export const ProgressPanel: React.FC<ProgressPanelProps> = ({ state, onCancel }) => {
  const currentStepIndex = steps.findIndex(s => s.id === state.step);
  const currentStep = steps[currentStepIndex] || steps[0];

  return (
    <div className="glass rounded-2xl p-8 space-y-8">
      {/* Main Progress */}
      <div className="text-center space-y-4">
        <div className="w-24 h-24 mx-auto relative">
          {/* Spinning circle */}
          <svg className="w-24 h-24 animate-spin-slow" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke="#334155"
              strokeWidth="8"
            />
            <circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke="url(#gradient)"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={`${state.progress * 2.83} 283`}
              transform="rotate(-90 50 50)"
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#22c55e" />
                <stop offset="100%" stopColor="#4ade80" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-3xl">{currentStep.icon}</span>
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-bold text-white">{currentStep.label}</h3>
          <p className="text-slate-400">{currentStep.description}</p>
        </div>

        <div className="text-4xl font-bold gradient-text">{state.progress}%</div>
      </div>

      {/* Step indicators */}
      <div className="flex justify-center gap-8">
        {steps.map((step, index) => {
          const isActive = index === currentStepIndex;
          const isComplete = index < currentStepIndex;
          
          return (
            <div
              key={step.id}
              className={`
                flex flex-col items-center gap-2 transition-all
                ${isActive ? 'scale-110' : ''}
              `}
            >
              <div
                className={`
                  w-10 h-10 rounded-full flex items-center justify-center transition-all
                  ${isComplete
                    ? 'bg-green-600 text-white'
                    : isActive
                    ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white animate-pulse'
                    : 'bg-slate-700 text-slate-400'
                  }
                `}
              >
                {isComplete ? (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                ) : (
                  <span>{step.icon}</span>
                )}
              </div>
              <span className={`text-xs ${isActive ? 'text-white' : 'text-slate-500'}`}>
                {step.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Cancel button */}
      <div className="flex justify-center">
        <button
          onClick={onCancel}
          className="px-6 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded-lg transition-colors"
        >
          Cancel Porting
        </button>
      </div>
    </div>
  );
};
