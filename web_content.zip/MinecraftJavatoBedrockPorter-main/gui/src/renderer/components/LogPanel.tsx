import React, { useRef, useEffect } from 'react';
import { LogEntry } from '../types';

interface LogPanelProps {
  logs: LogEntry[];
}

export const LogPanel: React.FC<LogPanelProps> = ({ logs }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [logs]);

  const getLevelColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'error': return 'text-red-400';
      case 'warn': return 'text-yellow-400';
      case 'debug': return 'text-slate-500';
      default: return 'text-slate-300';
    }
  };

  const getLevelIcon = (level: LogEntry['level']) => {
    switch (level) {
      case 'error': return '❌';
      case 'warn': return '⚠️';
      case 'debug': return '🔍';
      default: return '📝';
    }
  };

  return (
    <div className="glass rounded-2xl overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-700/50 flex items-center justify-between">
        <h3 className="font-semibold text-sm flex items-center gap-2">
          <span>📋</span>
          Output Log
        </h3>
        <span className="text-xs text-slate-500">{logs.length} entries</span>
      </div>
      
      <div
        ref={containerRef}
        className="h-64 overflow-y-auto p-4 font-mono text-xs space-y-1"
      >
        {logs.map((log, index) => (
          <div key={index} className="flex gap-2">
            <span className="text-slate-600 flex-shrink-0">
              {log.timestamp.toLocaleTimeString()}
            </span>
            <span className="flex-shrink-0">{getLevelIcon(log.level)}</span>
            <span className={getLevelColor(log.level)}>
              {log.message}
            </span>
          </div>
        ))}
        {logs.length === 0 && (
          <div className="text-slate-500 text-center py-8">
            No log entries yet
          </div>
        )}
      </div>
    </div>
  );
};
