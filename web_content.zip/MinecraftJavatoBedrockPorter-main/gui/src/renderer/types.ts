// API interface exposed by preload script
export interface API {
  selectModFile: () => Promise<string | null>;
  selectModFolder: () => Promise<string | null>;
  selectOutputFolder: () => Promise<string | null>;
  startPorting: (config: PortingConfig) => Promise<PortingResult>;
  cancelPorting: () => Promise<boolean>;
  openFolder: (path: string) => Promise<void>;
  openFile: (path: string) => Promise<void>;
  getAppInfo: () => Promise<AppInfo>;
  checkRustAnalyzer: () => Promise<boolean>;
  onPorterOutput: (callback: (output: string) => void) => () => void;
  onPorterError: (callback: (error: string) => void) => () => void;
  minimizeWindow: () => void;
  maximizeWindow: () => void;
  closeWindow: () => void;
}

declare global {
  interface Window {
    api: API;
  }
}

export interface PortingConfig {
  input: string;
  output: string;
  loader: 'forge' | 'fabric' | 'quilt' | 'auto';
  createPackages: boolean;
  validate: boolean;
  generateReport: boolean;
  reportFormat: 'markdown' | 'json' | 'html';
  verbose: boolean;
}

export interface PortingResult {
  success: boolean;
  output: string;
  error?: string;
}

export interface AppInfo {
  version: string;
  platform: string;
  isDev: boolean;
}

export type PortingStep = 
  | 'idle' 
  | 'analyzing' 
  | 'mapping' 
  | 'generating' 
  | 'validating' 
  | 'complete' 
  | 'error';

export interface PortingState {
  step: PortingStep;
  progress: number;
  logs: LogEntry[];
  result?: PortingResult;
}

export interface LogEntry {
  timestamp: Date;
  level: 'info' | 'warn' | 'error' | 'debug';
  message: string;
}
