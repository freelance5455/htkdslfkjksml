import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DropZone } from './components/DropZone';
import { ConfigPanel } from './components/ConfigPanel';
import { ProgressPanel } from './components/ProgressPanel';
import { ResultPanel } from './components/ResultPanel';
import { LogPanel } from './components/LogPanel';
import { PortingConfig, PortingState, LogEntry } from './types';

const defaultConfig: PortingConfig = {
  input: '',
  output: '',
  loader: 'auto',
  createPackages: true,
  validate: true,
  generateReport: true,
  reportFormat: 'markdown',
  verbose: false,
};

const App: React.FC = () => {
  const [config, setConfig] = useState<PortingConfig>(defaultConfig);
  const [portingState, setPortingState] = useState<PortingState>({
    step: 'idle',
    progress: 0,
    logs: [],
  });
  const [hasRustAnalyzer, setHasRustAnalyzer] = useState(false);
  const [activeTab, setActiveTab] = useState<'home' | 'settings' | 'about'>('home');

  useEffect(() => {
    // Check for Rust analyzer on startup
    window.api.checkRustAnalyzer().then(setHasRustAnalyzer);
  }, []);

  useEffect(() => {
    // Listen for porter output
    const unsubOutput = window.api.onPorterOutput((output) => {
      const lines = output.split('\n').filter(Boolean);
      const newLogs: LogEntry[] = lines.map(line => ({
        timestamp: new Date(),
        level: line.includes('error') ? 'error' : line.includes('warn') ? 'warn' : 'info',
        message: line,
      }));
      
      setPortingState(prev => ({
        ...prev,
        logs: [...prev.logs, ...newLogs],
      }));

      // Update step based on output
      if (output.includes('Step 1/6')) {
        setPortingState(prev => ({ ...prev, step: 'analyzing', progress: 10 }));
      } else if (output.includes('Step 3/6')) {
        setPortingState(prev => ({ ...prev, step: 'mapping', progress: 35 }));
      } else if (output.includes('Step 4/6')) {
        setPortingState(prev => ({ ...prev, step: 'generating', progress: 55 }));
      } else if (output.includes('Step 5/6')) {
        setPortingState(prev => ({ ...prev, step: 'validating', progress: 75 }));
      } else if (output.includes('Step 6/6')) {
        setPortingState(prev => ({ ...prev, progress: 90 }));
      } else if (output.includes('Porting complete')) {
        setPortingState(prev => ({ ...prev, step: 'complete', progress: 100 }));
      }
    });

    const unsubError = window.api.onPorterError((error) => {
      setPortingState(prev => ({
        ...prev,
        logs: [...prev.logs, {
          timestamp: new Date(),
          level: 'error',
          message: error,
        }],
      }));
    });

    return () => {
      unsubOutput();
      unsubError();
    };
  }, []);

  const handleSelectInput = useCallback(async () => {
    const path = await window.api.selectModFile();
    if (path) {
      setConfig(prev => ({ ...prev, input: path }));
    }
  }, []);

  const handleSelectFolder = useCallback(async () => {
    const path = await window.api.selectModFolder();
    if (path) {
      setConfig(prev => ({ ...prev, input: path }));
    }
  }, []);

  const handleSelectOutput = useCallback(async () => {
    const path = await window.api.selectOutputFolder();
    if (path) {
      setConfig(prev => ({ ...prev, output: path }));
    }
  }, []);

  const handleStartPorting = useCallback(async () => {
    if (!config.input || !config.output) return;

    setPortingState({
      step: 'analyzing',
      progress: 0,
      logs: [{
        timestamp: new Date(),
        level: 'info',
        message: 'Starting porting process...',
      }],
    });

    try {
      const result = await window.api.startPorting(config);
      setPortingState(prev => ({
        ...prev,
        step: result.success ? 'complete' : 'error',
        progress: result.success ? 100 : prev.progress,
        result,
      }));
    } catch (error) {
      setPortingState(prev => ({
        ...prev,
        step: 'error',
        result: {
          success: false,
          output: '',
          error: String(error),
        },
      }));
    }
  }, [config]);

  const handleCancelPorting = useCallback(async () => {
    await window.api.cancelPorting();
    setPortingState(prev => ({
      ...prev,
      step: 'idle',
      logs: [...prev.logs, {
        timestamp: new Date(),
        level: 'warn',
        message: 'Porting cancelled by user',
      }],
    }));
  }, []);

  const handleReset = useCallback(() => {
    setConfig(defaultConfig);
    setPortingState({ step: 'idle', progress: 0, logs: [] });
  }, []);

  const handleOpenOutput = useCallback(() => {
    if (config.output) {
      window.api.openFolder(config.output);
    }
  }, [config.output]);

  const isPorting = ['analyzing', 'mapping', 'generating', 'validating'].includes(portingState.step);
  const canStart = config.input && config.output && !isPorting;

  return (
    <div className="h-full flex flex-col">
      <Header />
      
      <div className="flex-1 flex overflow-hidden">
        <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
        
        <main className="flex-1 p-6 overflow-y-auto">
          {activeTab === 'home' && (
            <div className="max-w-4xl mx-auto space-y-6">
              {/* Status Banner */}
              {!hasRustAnalyzer && (
                <div className="glass rounded-xl p-4 border-l-4 border-yellow-500">
                  <div className="flex items-center gap-3">
                    <div className="text-yellow-500">⚠️</div>
                    <div>
                      <p className="font-medium text-yellow-200">Rust Analyzer Not Found</p>
                      <p className="text-sm text-slate-400">
                        Build the Rust analyzer for full Java bytecode analysis. Run: <code className="bg-slate-800 px-2 py-0.5 rounded">npm run build:rust</code>
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Input Section */}
              {portingState.step === 'idle' && (
                <>
                  <DropZone
                    value={config.input}
                    onSelectFile={handleSelectInput}
                    onSelectFolder={handleSelectFolder}
                  />
                  
                  <ConfigPanel
                    config={config}
                    onChange={setConfig}
                    onSelectOutput={handleSelectOutput}
                  />

                  <div className="flex justify-center">
                    <button
                      onClick={handleStartPorting}
                      disabled={!canStart}
                      className={`
                        px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300
                        ${canStart
                          ? 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white shadow-lg shadow-green-900/30 hover:shadow-green-800/40 hover:scale-105'
                          : 'bg-slate-700 text-slate-400 cursor-not-allowed'
                        }
                      `}
                    >
                      🚀 Start Porting
                    </button>
                  </div>
                </>
              )}

              {/* Progress Section */}
              {isPorting && (
                <ProgressPanel
                  state={portingState}
                  onCancel={handleCancelPorting}
                />
              )}

              {/* Result Section */}
              {(portingState.step === 'complete' || portingState.step === 'error') && (
                <ResultPanel
                  state={portingState}
                  outputPath={config.output}
                  onOpenOutput={handleOpenOutput}
                  onReset={handleReset}
                />
              )}

              {/* Log Panel */}
              {portingState.logs.length > 0 && (
                <LogPanel logs={portingState.logs} />
              )}
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="max-w-2xl mx-auto">
              <h2 className="text-2xl font-bold mb-6">Settings</h2>
              <div className="glass rounded-xl p-6 space-y-4">
                <p className="text-slate-400">Settings panel coming soon...</p>
              </div>
            </div>
          )}

          {activeTab === 'about' && (
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-4xl font-bold gradient-text mb-4">Mod Porter</h2>
              <p className="text-slate-400 text-lg mb-8">
                Java to Bedrock Mod Porting Tool
              </p>
              <div className="glass rounded-xl p-6 space-y-4">
                <p className="text-slate-300">
                  Fully autonomous tool for porting Minecraft Java Edition mods
                  to Bedrock Edition addons.
                </p>
                <p className="text-sm text-slate-500">Version 1.0.0</p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default App;
