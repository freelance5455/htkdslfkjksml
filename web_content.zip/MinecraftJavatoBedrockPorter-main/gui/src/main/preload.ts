/**
 * Preload Script
 * 
 * Exposes safe APIs to the renderer process via contextBridge.
 */

import { contextBridge, ipcRenderer } from 'electron';

const api = {
  // File dialogs
  selectModFile: (): Promise<string | null> => ipcRenderer.invoke('select-mod-file'),
  selectModFolder: (): Promise<string | null> => ipcRenderer.invoke('select-mod-folder'),
  selectOutputFolder: (): Promise<string | null> => ipcRenderer.invoke('select-output-folder'),
  
  // Porting
  startPorting: (config: PortingConfig): Promise<PortingResult> => 
    ipcRenderer.invoke('start-porting', config),
  cancelPorting: (): Promise<boolean> => ipcRenderer.invoke('cancel-porting'),
  
  // File operations
  openFolder: (path: string): Promise<void> => ipcRenderer.invoke('open-folder', path),
  openFile: (path: string): Promise<void> => ipcRenderer.invoke('open-file', path),
  
  // App info
  getAppInfo: (): Promise<AppInfo> => ipcRenderer.invoke('get-app-info'),
  checkRustAnalyzer: (): Promise<boolean> => ipcRenderer.invoke('check-rust-analyzer'),
  
  // Event listeners
  onPorterOutput: (callback: (output: string) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, output: string) => callback(output);
    ipcRenderer.on('porter-output', listener);
    return () => ipcRenderer.removeListener('porter-output', listener);
  },
  
  onPorterError: (callback: (error: string) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, error: string) => callback(error);
    ipcRenderer.on('porter-error', listener);
    return () => ipcRenderer.removeListener('porter-error', listener);
  },
  
  // Window controls
  minimizeWindow: () => ipcRenderer.send('window-minimize'),
  maximizeWindow: () => ipcRenderer.send('window-maximize'),
  closeWindow: () => ipcRenderer.send('window-close'),
};

contextBridge.exposeInMainWorld('api', api);

interface PortingConfig {
  input: string;
  output: string;
  loader: string;
  createPackages: boolean;
  validate: boolean;
  generateReport: boolean;
  reportFormat: string;
  verbose: boolean;
}

interface PortingResult {
  success: boolean;
  output: string;
  error?: string;
}

interface AppInfo {
  version: string;
  platform: string;
  isDev: boolean;
}

export type API = typeof api;
