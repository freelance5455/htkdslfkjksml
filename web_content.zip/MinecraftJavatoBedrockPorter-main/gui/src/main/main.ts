/**
 * Electron Main Process
 * 
 * Handles window creation and IPC communication with the renderer process.
 */

import { app, BrowserWindow, ipcMain, dialog, shell } from 'electron';
import * as path from 'path';
import * as fs from 'fs';
import { spawn, ChildProcess } from 'child_process';

let mainWindow: BrowserWindow | null = null;
let porterProcess: ChildProcess | null = null;

const isDev = process.env.NODE_ENV === 'development';

function createWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#0f172a',
    titleBarStyle: 'hiddenInset',
    frame: process.platform === 'darwin' ? true : false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  const indexPath = path.join(__dirname, 'renderer', 'index.html');

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    const fileUrl = `file://${indexPath.replace(/\\/g, '/')}`;
    mainWindow.loadURL(fileUrl);
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});

// IPC Handlers

ipcMain.handle('select-mod-file', async () => {
  const result = await dialog.showOpenDialog(mainWindow!, {
    title: 'Select Java Mod',
    filters: [
      { name: 'Java Mod', extensions: ['jar'] },
      { name: 'All Files', extensions: ['*'] },
    ],
    properties: ['openFile'],
  });

  if (result.canceled) return null;
  return result.filePaths[0];
});

ipcMain.handle('select-mod-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow!, {
    title: 'Select Mod Source Folder',
    properties: ['openDirectory'],
  });

  if (result.canceled) return null;
  return result.filePaths[0];
});

ipcMain.handle('select-output-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow!, {
    title: 'Select Output Folder',
    properties: ['openDirectory', 'createDirectory'],
  });

  if (result.canceled) return null;
  return result.filePaths[0];
});

ipcMain.handle('start-porting', async (_event, config: PortingConfig) => {
  return new Promise((resolve, reject) => {
    const cliPath = path.join(__dirname, '..', '..', 'dist', 'cli.js');
    
    const args = [
      cliPath,
      'port',
      config.input,
      '-o', config.output,
      '-l', config.loader,
      '-f', config.reportFormat,
    ];

    if (!config.createPackages) args.push('--no-packages');
    if (!config.validate) args.push('--no-validate');
    if (!config.generateReport) args.push('--no-report');
    if (config.verbose) args.push('--verbose');

    porterProcess = spawn('node', args, {
      cwd: path.join(__dirname, '..', '..'),
    });

    let output = '';
    let errorOutput = '';

    porterProcess.stdout?.on('data', (data: Buffer) => {
      const text = data.toString();
      output += text;
      mainWindow?.webContents.send('porter-output', text);
    });

    porterProcess.stderr?.on('data', (data: Buffer) => {
      const text = data.toString();
      errorOutput += text;
      mainWindow?.webContents.send('porter-error', text);
    });

    porterProcess.on('close', (code: number) => {
      porterProcess = null;
      if (code === 0) {
        resolve({ success: true, output });
      } else {
        resolve({ success: false, output, error: errorOutput });
      }
    });

    porterProcess.on('error', (err: Error) => {
      porterProcess = null;
      reject(err);
    });
  });
});

ipcMain.handle('cancel-porting', async () => {
  if (porterProcess) {
    porterProcess.kill();
    porterProcess = null;
    return true;
  }
  return false;
});

ipcMain.handle('open-folder', async (_event, folderPath: string) => {
  shell.openPath(folderPath);
});

ipcMain.handle('open-file', async (_event, filePath: string) => {
  shell.openPath(filePath);
});

ipcMain.handle('get-app-info', async () => {
  return {
    version: app.getVersion(),
    platform: process.platform,
    isDev,
  };
});

ipcMain.handle('check-rust-analyzer', async () => {
  const analyzerPath = path.join(__dirname, '..', '..', 'rust-analyzer', 'target', 'release', 
    process.platform === 'win32' ? 'java-analyzer.exe' : 'java-analyzer');
  return fs.existsSync(analyzerPath);
});

interface PortingConfig {
  input: string;
  output: string;
  loader: string;
  createPackages: boolean;
  validate: boolean;
  generateReport: boolean;
  reportFormat: string;
  verbose: boolean;
}
