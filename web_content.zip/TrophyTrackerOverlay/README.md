# Trophy Tracker — Overlay Android

Projeto Android híbrido: interface em HTML + bolha flutuante nativa do Android.

## O que faz
- Mostra um quadradinho 🏆 por cima de outros apps, inclusive durante o Brawl Stars.
- O quadrado pode ser arrastado.
- Tocar no quadrado abre o Trophy Tracker.
- Registrar vitória/derrota no painel atualiza o mesmo total mostrado no quadrado.
- O total fica salvo no Android.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Extraia este ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `TrophyTrackerOverlay`.
4. Aguarde o Gradle Sync. Se pedir, instale Android SDK 35.
5. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de debug costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

## Primeiro uso no celular
1. Instale o APK.
2. Abra Trophy Tracker.
3. Quando o Android abrir a tela de permissão, ative **Permitir sobreposição a outros apps**.
4. Volte ao app. O quadrado 🏆 deve aparecer.
5. Abra o Brawl Stars: o quadrado fica por cima da tela.
6. Arraste para posicionar. Toque para abrir o painel e registrar.

## Observações
- Este ZIP é o projeto-fonte, não um APK já compilado.
- O Android exige a permissão especial de sobreposição.
- Alguns fabricantes podem limitar serviços em segundo plano; se o quadrado sumir, permita atividade em segundo plano para o Trophy Tracker.
- O overlay usa um serviço Android e o painel usa HTML em WebView. O contador é compartilhado por uma ponte JavaScript/Android.
