package com.example.trophytracker;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class FloatingWidgetService extends Service {
    public static final String ACTION_START = "com.example.trophytracker.START";
    public static final String ACTION_REFRESH = "com.example.trophytracker.REFRESH";
    private WindowManager wm;
    private View bubble;
    private TextView amount;
    private int total;
    private WindowManager.LayoutParams params;
    private BroadcastReceiver receiver;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(71, notification());
        total = getSharedPreferences("trophies", MODE_PRIVATE).getInt("total", 70000);
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                total = getSharedPreferences("trophies", MODE_PRIVATE).getInt("total", 70000);
                updateBubble();
            }
        };
        registerReceiver(receiver, new IntentFilter(ACTION_REFRESH));
        if (Settings.canDrawOverlays(this)) createBubble();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (ACTION_START.equals(intent == null ? null : intent.getAction()) && bubble == null && Settings.canDrawOverlays(this)) createBubble();
        return START_STICKY;
    }

    private void createBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return;
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(18, 24, 30));
        bg.setCornerRadius(dp(17));
        bg.setStroke(dp(2), Color.rgb(40, 220, 130));
        box.setBackground(bg);
        TextView trophy = new TextView(this);
        trophy.setText("🏆");
        trophy.setTextSize(20);
        trophy.setGravity(Gravity.CENTER);
        amount = new TextView(this);
        amount.setTextColor(Color.WHITE);
        amount.setTextSize(11);
        amount.setTypeface(Typeface.DEFAULT_BOLD);
        amount.setGravity(Gravity.CENTER);
        box.addView(trophy, new LinearLayout.LayoutParams(-1, dp(28)));
        box.addView(amount, new LinearLayout.LayoutParams(-1, dp(20)));
        updateBubble();
        params = new WindowManager.LayoutParams(dp(68), dp(64),
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(14); params.y = dp(170);
        box.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; long downAt;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; downAt=System.currentTimeMillis(); return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x=startX+(int)(e.getRawX()-downX); params.y=startY+(int)(e.getRawY()-downY);
                        try { wm.updateViewLayout(bubble, params); } catch(Exception ignored) {} return true;
                    case MotionEvent.ACTION_UP:
                        if (Math.abs(e.getRawX()-downX)<12 && Math.abs(e.getRawY()-downY)<12) openTracker();
                        return true;
                }
                return true;
            }
        });
        bubble = box;
        wm.addView(bubble, params);
    }

    private void openTracker() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.putExtra("open_panel", true);
        startActivity(i);
    }

    private void updateBubble() {
        if (amount != null) amount.setText(total >= 1000 ? String.format(java.util.Locale.US, "%.1fk", total/1000.0) : String.valueOf(total));
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("tracker_overlay", "Contador flutuante", NotificationManager.IMPORTANCE_MIN);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "tracker_overlay") : new Notification.Builder(this);
        return b.setContentTitle("Trophy Tracker ativo").setContentText("O contador flutuante está disponível.").setSmallIcon(android.R.drawable.star_on).build();
    }

    @Override public void onDestroy() {
        if (receiver != null) unregisterReceiver(receiver);
        if (bubble != null && wm != null) try { wm.removeView(bubble); } catch(Exception ignored) {}
        bubble = null;
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
