package com.example.trophytracker;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int OVERLAY_REQUEST = 4102;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (getIntent() != null && getIntent().getBooleanExtra("open_panel", false)) {
                    view.evaluateJavascript("openQuickPanel()", null);
                    getIntent().removeExtra("open_panel");
                }
            }
        });
        webView.addJavascriptInterface(new TrophyBridge(), "AndroidTrophy");
        webView.loadUrl("file:///android_asset/index.html");

        if (Settings.canDrawOverlays(this)) {
            startOverlay();
        } else {
            Toast.makeText(this, "Ative 'Permitir sobreposição a outros apps' para usar o contador flutuante.", Toast.LENGTH_LONG).show();
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, OVERLAY_REQUEST);
        }
    }

    private void startOverlay() {
        Intent service = new Intent(this, FloatingWidgetService.class);
        service.setAction(FloatingWidgetService.ACTION_START);
        startService(service);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST) {
            if (Settings.canDrawOverlays(this)) startOverlay();
            else Toast.makeText(this, "Sem essa permissão, o quadradinho não aparece sobre o Brawl Stars.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (webView != null) webView.evaluateJavascript("openQuickPanel()", null);
    }

    public class TrophyBridge {
        @JavascriptInterface public int getTotal() { return getSharedPreferences("trophies", MODE_PRIVATE).getInt("total", 70000); }
        @JavascriptInterface public void setTotal(int total) {
            getSharedPreferences("trophies", MODE_PRIVATE).edit().putInt("total", Math.max(0, total)).apply();
            sendBroadcast(new Intent(FloatingWidgetService.ACTION_REFRESH).setPackage(getPackageName()));
        }
        @JavascriptInterface public void closePanel() { runOnUiThread(() -> moveTaskToBack(true)); }
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("closeQuickPanel()", null);
        else super.onBackPressed();
    }
}
