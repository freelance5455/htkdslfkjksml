Unser Vorrat – STEP 12
Erweitert den Vorrat zu einer echten Haushaltszentrale: Lebensmittel, Haushalt, Körperpflege, Tierbedarf, Baby/Kinder, Gesundheit und Sonstiges. Kategorien sind gruppiert und der Artikel-Editor erkennt typische Begriffe automatisch (z.B. Shampoo, Klopapier, Katzenfutter, Waschmittel), bleibt aber jederzeit manuell änderbar.
