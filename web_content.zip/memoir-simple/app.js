(() => {
  const cfg = window.MEMOIR_CONFIG || {};
  const configured = cfg.supabaseUrl && cfg.supabaseAnonKey &&
    !cfg.supabaseUrl.includes("YOUR_") && !cfg.supabaseAnonKey.includes("YOUR_");
  const $ = id => document.getElementById(id);
  let supabase = null, user = null, authMode = "signin";
  let movies = [], quotes = [], movieFilter = "all", favouritesOnly = false;

  const showMessage = (id, message, error=true) => {
    const el = $(id); el.textContent = message || ""; el.style.color = error ? "var(--rose)" : "var(--accent)";
  };
  const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const dateLabel = value => value ? new Date(value).toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"}) : "";

  function setSignedIn(session) {
    user = session?.user || null;
    $("auth-view").classList.toggle("hidden", !!user);
    $("app-view").classList.toggle("hidden", !user);
    $("signout-btn").classList.toggle("hidden", !user);
    $("user-email").textContent = user?.email || "";
    if (user) loadData();
  }

  async function loadData() {
    showMessage("app-message", "");
    const [m, q] = await Promise.all([
      supabase.from("movies").select("*").order("created_at",{ascending:false}),
      supabase.from("quotes").select("*").order("created_at",{ascending:false})
    ]);
    if (m.error || q.error) { showMessage("app-message", (m.error || q.error).message); return; }
    movies = m.data || []; quotes = q.data || [];
    renderMovies(); renderQuotes();
  }

  function renderMovies() {
    const term = $("movie-search").value.trim().toLowerCase();
    const shown = movies.filter(m => (movieFilter==="all" || (movieFilter==="watched" ? m.watched : !m.watched)) && m.name.toLowerCase().includes(term));
    $("movie-list").innerHTML = shown.map(m => `
      <article class="movie-card">
        <div class="movie-top"><h3>${escapeHtml(m.name)}</h3><span class="status ${m.watched?"watched":""}">${m.watched?"Watched":"To watch"}</span></div>
        <div class="movie-meta">${m.rating ? `Your rating: ${"★".repeat(m.rating)}${"☆".repeat(5-m.rating)}` : "No rating added"}${m.created_at ? ` · Added ${dateLabel(m.created_at)}` : ""}</div>
        <div class="card-actions"><button class="link-button" data-action="edit-movie" data-id="${m.id}">Edit</button><button class="link-button" data-action="delete-movie" data-id="${m.id}">Delete</button></div>
      </article>`).join("");
    $("movie-empty").classList.toggle("hidden", shown.length>0);
  }

  function renderQuotes() {
    const term = $("quote-search").value.trim().toLowerCase();
    const shown = quotes.filter(q => (!favouritesOnly || q.favourite) &&
      [q.text,q.author,q.source].some(v => String(v||"").toLowerCase().includes(term)));
    $("quote-list").innerHTML = shown.map(q => `
      <article class="quote-card">
        <div class="quote-mark">“</div>
        <p class="quote-text">${escapeHtml(q.text)}</p>
        <div class="quote-by">${q.author ? "— "+escapeHtml(q.author) : "Unknown author"}</div>
        ${q.source ? `<div class="quote-source">${escapeHtml(q.source)}</div>` : ""}
        <div class="quote-actions"><button class="link-button heart" data-action="toggle-favourite" data-id="${q.id}">${q.favourite?"♥ Favourite":"♡ Add to favourites"}</button><span class="card-actions"><button class="link-button" data-action="edit-quote" data-id="${q.id}">Edit</button><button class="link-button" data-action="delete-quote" data-id="${q.id}">Delete</button></span></div>
      </article>`).join("");
    $("quote-empty").classList.toggle("hidden", shown.length>0);
  }

  function openMovie(movie) {
    $("movie-form").reset(); $("movie-id").value = movie?.id || "";
    $("movie-name").value = movie?.name || ""; $("movie-watched").checked = !!movie?.watched;
    $("movie-rating").value = movie?.rating || "";
    $("movie-dialog-title").textContent = movie ? "Edit movie" : "Add a movie";
    $("movie-dialog").showModal(); $("movie-name").focus();
  }
  function openQuote(quote) {
    $("quote-form").reset(); $("quote-id").value = quote?.id || "";
    $("quote-text").value = quote?.text || ""; $("quote-author").value = quote?.author || "";
    $("quote-source").value = quote?.source || ""; $("quote-favourite").checked = !!quote?.favourite;
    $("quote-dialog-title").textContent = quote ? "Edit quote" : "Save a quote";
    $("quote-dialog").showModal(); $("quote-text").focus();
  }

  async function saveRecord(table, id, data) {
    const result = id
      ? await supabase.from(table).update(data).eq("id",id).select().single()
      : await supabase.from(table).insert({...data,user_id:user.id}).select().single();
    if (result.error) throw result.error;
  }

  $("auth-form").addEventListener("submit", async e => {
    e.preventDefault(); showMessage("auth-message","");
    if (!configured) { showMessage("auth-message","Add your Supabase URL and anon key in config.js first."); return; }
    $("auth-submit").disabled = true;
    const email=$("email").value.trim(), password=$("password").value;
    const result = authMode==="signup"
      ? await supabase.auth.signUp({email,password})
      : await supabase.auth.signInWithPassword({email,password});
    $("auth-submit").disabled = false;
    if (result.error) showMessage("auth-message",result.error.message);
    else if (authMode==="signup" && !result.data.session) showMessage("auth-message","Account created. Check your email to confirm, then sign in.",false);
  });

  document.querySelectorAll("[data-auth]").forEach(btn=>btn.addEventListener("click",()=>{
    authMode=btn.dataset.auth;
    document.querySelectorAll("[data-auth]").forEach(b=>b.classList.toggle("active",b===btn));
    $("auth-submit").textContent=authMode==="signup"?"Create account":"Sign in";
    $("password").autocomplete=authMode==="signup"?"new-password":"current-password";
    showMessage("auth-message","");
  }));
  $("signout-btn").addEventListener("click",()=>supabase.auth.signOut());
  $("add-movie-open").addEventListener("click",()=>openMovie());
  $("add-quote-open").addEventListener("click",()=>openQuote());
  document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>$(b.dataset.close).close()));
  $("movie-form").addEventListener("submit",async e=>{
    e.preventDefault();
    try {
      await saveRecord("movies",$("movie-id").value||null,{name:$("movie-name").value.trim(),watched:$("movie-watched").checked,rating:$("movie-rating").value?Number($("movie-rating").value):null});
      $("movie-dialog").close(); await loadData();
    } catch(err) { showMessage("app-message",err.message); }
  });
  $("quote-form").addEventListener("submit",async e=>{
    e.preventDefault();
    try {
      await saveRecord("quotes",$("quote-id").value||null,{text:$("quote-text").value.trim(),author:$("quote-author").value.trim()||null,source:$("quote-source").value.trim()||null,favourite:$("quote-favourite").checked});
      $("quote-dialog").close(); await loadData();
    } catch(err) { showMessage("app-message",err.message); }
  });

  document.querySelectorAll(".main-tab").forEach(btn=>btn.addEventListener("click",()=>{
    document.querySelectorAll(".main-tab").forEach(b=>b.classList.toggle("active",b===btn));
    $("movies-section").classList.toggle("hidden",btn.dataset.section!=="movies");
    $("quotes-section").classList.toggle("hidden",btn.dataset.section!=="quotes");
  }));
  document.querySelectorAll("#movie-filters .filter").forEach(btn=>btn.addEventListener("click",()=>{
    movieFilter=btn.dataset.filter; document.querySelectorAll("#movie-filters .filter").forEach(b=>b.classList.toggle("active",b===btn)); renderMovies();
  }));
  $("movie-search").addEventListener("input",renderMovies);
  $("quote-search").addEventListener("input",renderQuotes);
  $("favourites-filter").addEventListener("click",()=>{
    favouritesOnly=!favouritesOnly; $("favourites-filter").classList.toggle("active",favouritesOnly); renderQuotes();
  });

  document.addEventListener("click",async e=>{
    const btn=e.target.closest("[data-action]"); if(!btn)return;
    const {action,id}=btn.dataset;
    try {
      if(action==="edit-movie") openMovie(movies.find(x=>String(x.id)===id));
      if(action==="edit-quote") openQuote(quotes.find(x=>String(x.id)===id));
      if(action==="delete-movie" || action==="delete-quote") {
        if(!confirm("Delete this item? This cannot be undone.")) return;
        const table=action==="delete-movie"?"movies":"quotes";
        const result=await supabase.from(table).delete().eq("id",id);
        if(result.error) throw result.error; await loadData();
      }
      if(action==="toggle-favourite") {
        const q=quotes.find(x=>String(x.id)===id);
        const result=await supabase.from("quotes").update({favourite:!q.favourite}).eq("id",id);
        if(result.error) throw result.error; await loadData();
      }
    } catch(err) { showMessage("app-message",err.message); }
  });

  document.querySelectorAll("dialog").forEach(d=>d.addEventListener("click",e=>{if(e.target===d)d.close()}));

  if (!configured) {
    $("auth-view").classList.remove("hidden");
    showMessage("auth-message","Setup needed: add your Supabase project URL and anon key in config.js.");
  } else if (window.supabase?.createClient) {
    supabase=window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey);
    supabase.auth.getSession().then(({data})=>setSignedIn(data.session));
    supabase.auth.onAuthStateChange((_event,session)=>setSignedIn(session));
  } else showMessage("auth-message","Could not load the sign-in service. Check your internet connection.");

  if ("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
})();
