// Add your Supabase project details here. Never put a service_role key in this file.
window.MEMOIR_CONFIG = {
  supabaseUrl: "YOUR_SUPABASE_PROJECT_URL",
  supabaseAnonKey: "YOUR_SUPABASE_ANON_PUBLIC_KEY"
};
