# Memoir — simple starter

Memoir contains only two collections:
- **My Movies:** movie name, watched/to-watch status, optional rating.
- **Quote Library:** quote, author/speaker, optional source, favourite toggle.

It includes account sign-in, per-user cloud storage through Supabase, search, edit/delete, and installable PWA files.

## 1. Create the cloud database
1. Create a project at https://supabase.com/
2. Open **SQL Editor** in the Supabase dashboard.
3. Paste and run `supabase/schema.sql`.

## 2. Connect the app
1. In Supabase, open **Project Settings → API** (or API Keys).
2. Copy the Project URL and the `anon` / publishable public key.
3. Put them in `config.js`:
   - `supabaseUrl`
   - `supabaseAnonKey`

Use only the public anon/publishable key in the browser. Never put a `service_role` or secret key in this project.

## 3. Run and publish
For a quick local preview, use a local web server (not by opening the HTML file directly). For example, in this folder run `python -m http.server 8000`, then visit `http://localhost:8000`.

To use it on Android and sync across devices, publish the folder using a static HTTPS host such as Netlify, Vercel, or GitHub Pages. Then open the website in Chrome on Android and choose **Install app** / **Add to Home screen**.

## 4. Email confirmation
Supabase may require email confirmation for new accounts. Confirm the email before signing in. You can adjust this in Supabase Authentication settings.

## Important
- Cloud sync starts only after you configure Supabase and publish/run the app.
- Each account can read and change only its own records (row-level security is enabled).
- This starter does not include movie posters or an external movie database; movie entries stay deliberately simple.
