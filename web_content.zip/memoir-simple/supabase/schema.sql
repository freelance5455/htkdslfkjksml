-- Run this once in Supabase Dashboard > SQL Editor.
create table if not exists public.movies (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  watched boolean not null default false,
  rating smallint null check (rating between 1 and 5),
  created_at timestamptz not null default now()
);

create table if not exists public.quotes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  text text not null check (char_length(text) between 1 and 1500),
  author text null,
  source text null,
  favourite boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.movies enable row level security;
alter table public.quotes enable row level security;

drop policy if exists "Users manage their own movies" on public.movies;
create policy "Users manage their own movies" on public.movies
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Users manage their own quotes" on public.quotes;
create policy "Users manage their own quotes" on public.quotes
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists movies_user_created_idx on public.movies(user_id, created_at desc);
create index if not exists quotes_user_created_idx on public.quotes(user_id, created_at desc);
