/* Learnova Creator Studio v2 — list pages */
(function(){
const page=document.body.dataset.page,ps=data.projects;
document.querySelectorAll(".js-new").forEach(b=>b.addEventListener("click",newDialog));
document.querySelectorAll(".js-ideas").forEach(b=>b.addEventListener("click",ideas));
function ideas(){if(!$("ideasDlg"))document.body.insertAdjacentHTML("beforeend",`<dialog id="ideasDlg"><form method="dialog" onsubmit="return false"><div class="dialog-head"><div><p class="eyebrow">AI</p><h2>Video ideas</h2></div><button type="button" class="icon-btn light-icon" id="ideaX">×</button></div><label>Topic / niche<input id="ideaNiche" value="study tips and learning science"></label><button type="button" class="primary-btn" id="ideaGo">✨ Generate 5 ideas</button><div id="ideaOut" style="margin-top:14px"></div></form></dialog>`);
 let L=[];$("ideasDlg").showModal();$("ideaX").onclick=()=>$("ideasDlg").close();
 $("ideaGo").onclick=async()=>{const b=$("ideaGo");b.disabled=true;b.textContent="Thinking…";try{const t=await ai(`Suggest 5 fresh faceless educational YouTube video ideas about: ${$("ideaNiche").value}. Avoid these existing titles: ${ps.map(x=>x.title||x.name).join("; ")||"none"}. Return ONLY a JSON array of 5 objects: {"title":"under 70 chars, honest","format":"Long-form video" or "YouTube Short","hook":"one-sentence opening hook"}.`,1200);if(t){L=J(t);$("ideaOut").innerHTML=L.map((x,i)=>`<div class="row"><span><strong>${esc(x.title)}</strong><br><small>${esc(x.format)} · ${esc(x.hook)}</small></span><button type="button" class="primary-btn" data-i="${i}">Create</button></div>`).join("");}}catch(e){toast("AI error: "+e.message);}b.disabled=false;b.textContent="✨ Generate 5 ideas";};
 $("ideaOut").onclick=e=>{const x=L[e.target.dataset.i];if(!x)return;const p=blankProject(x.title,x.format==="YouTube Short"?"YouTube Short":"Long-form video","blank");p.name=p.title=x.title;p.hook=x.hook||"";data.projects.unshift(p);save();location.href="overview.html?id="+p.id;};}
if(page==="home"){
 const n=s=>ps.filter(p=>s.includes(p.status)).length;
 $("totalMetric").textContent=ps.length;$("productionMetric").textContent=n(["Scripting","Production"]);$("scheduledMetric").textContent=n(["Scheduled"]);$("publishedMetric").textContent=n(["Published"]);
 const recent=[...ps].sort((a,b)=>(b.updated||"").localeCompare(a.updated||"")).slice(0,3);
 $("recentGrid").innerHTML=recent.length?recent.map(card).join(""):'<div class="empty"><strong>Your studio is ready for its first video.</strong><p>Create a project to start.</p></div>';
 const up=ps.filter(p=>p.publishDate&&p.status!=="Published"&&p.publishDate>=today()).sort((a,b)=>a.publishDate.localeCompare(b.publishDate)).slice(0,3);
 $("upcoming").innerHTML=up.length?up.map(row).join(""):'<div class="empty">Nothing scheduled yet. Set a publish date in a project\'s Schedule page.</div>';
}
if(page==="projects"){
 let f="All";const render=()=>{const s=$("searchInput").value.trim().toLowerCase();const l=ps.filter(p=>(f==="All"||p.status===f)&&[p.name,p.title,p.pillar,p.goal].join(" ").toLowerCase().includes(s));
  $("projectGrid").innerHTML=l.length?l.map(card).join(""):`<div class="empty"><strong>${ps.length?"No matching projects":"No projects yet"}</strong><p>${ps.length?"Try another search or filter.":"Create your first project."}</p></div>`;};
 $("searchInput").addEventListener("input",render);
 document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{f=b.dataset.status;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));render();}));
 render();
}
if(page==="calendar"){
 const t=today(),wk=new Date(Date.now()+7*864e5).toLocaleDateString("en-CA");
 const by=(a,b)=>(a.publishDate||"").localeCompare(b.publishDate||"");
 const live=ps.filter(p=>p.status!=="Published");
 const G=[["⚠ Overdue",live.filter(p=>p.publishDate&&p.publishDate<t)],["This week",live.filter(p=>p.publishDate>=t&&p.publishDate<=wk)],["Later",live.filter(p=>p.publishDate>wk)],["Not scheduled",live.filter(p=>!p.publishDate)],["Published",ps.filter(p=>p.status==="Published")]];
 $("calList").innerHTML=G.filter(g=>g[1].length).map(([h,l])=>`<h3 class="grp">${h} (${l.length})</h3>`+l.sort(by).map(row).join("")).join("")||'<div class="empty">No projects yet.</div>';
 let cm=new Date();cm.setDate(1);
 const mon=()=>{const y=cm.getFullYear(),m=cm.getMonth(),first=new Date(y,m,1).getDay(),dim=new Date(y,m+1,0).getDate();let h=`<div class="inline-actions" style="margin:0"><button class="secondary-btn" id="cPrev">‹</button><strong style="align-self:center">${cm.toLocaleDateString([],{month:"long",year:"numeric"})}</strong><button class="secondary-btn" id="cNext">›</button></div><div class="cal">`+"SMTWTFS".split("").map(d=>`<b>${d}</b>`).join("");
  for(let i=0;i<first;i++)h+="<div></div>";
  for(let d=1;d<=dim;d++){const ds=`${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;h+=`<div class="${ds===t?"td":""}"><span>${d}</span>${ps.filter(p=>p.publishDate===ds).map(p=>`<a class="chip" href="schedule.html?id=${p.id}">${esc(p.title||p.name)}</a>`).join("")}</div>`;}
  $("calMonth").innerHTML=h+"</div>";$("cPrev").onclick=()=>{cm.setMonth(cm.getMonth()-1);mon();};$("cNext").onclick=()=>{cm.setMonth(cm.getMonth()+1);mon();};};
 mon();const V=m=>{$("calMonth").classList.toggle("hidden",!m);$("calList").classList.toggle("hidden",m);};$("vList").onclick=()=>V(0);$("vMonth").onclick=()=>V(1);V(1);
}
if(page==="settings"){
 $("exportBtn").onclick=exportProjects;
 $("importFile").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(!Array.isArray(d.projects))throw 0;const m=new Map(data.projects.map(p=>[p.id,p]));let c=0;d.projects.forEach(p=>{if(!p.id)return;const o=m.get(p.id);if(!o||(p.updated||"")>(o.updated||"")){m.set(p.id,p);c++;}});data.projects=[...m.values()];(d.templates||[]).forEach(t=>{if(!data.templates.some(x=>x.id===t.id))data.templates.push(t);});save();toast(c+" project(s) imported.");stats();}catch(x){toast("That file is not a valid backup.");}};r.readAsText(f);};
 $("clearBtn").onclick=()=>{if(confirm("Delete ALL projects on this device? Export a backup first.")){data.projects=[];data.seeded=true;save();stats();toast("All projects deleted.");}};
 $("seedBtn").onclick=()=>{data.projects.unshift(blankProject("5 Science-Backed Ways to Study Smarter","Long-form video","study"));save();stats();toast("Example project added.");};
 function stats(){let b=0;try{b=(localStorage.getItem(KEY)||"").length;}catch(e){}$("stats").textContent=data.projects.length+" projects · "+(b/1024).toFixed(1)+" KB used in this browser";}
 stats();
 const tl=()=>{$("tplList").innerHTML=data.templates.map(t=>`<div class="row"><span>★ ${esc(t.name)}</span><button class="danger-btn" data-t="${t.id}">Delete</button></div>`).join("")||"<small>No templates yet.</small>";};
 $("tplList").onclick=e=>{const id=e.target.dataset.t;if(id&&confirm("Delete this template?")){data.templates=data.templates.filter(x=>x.id!==id);save();tl();}};tl();
 const P=$("aiProv");P.innerHTML=Object.entries(AIP).map(([k,v])=>`<option value="${k}">${v[0]}</option>`).join("");P.value=aiCfg().provider;
 const st=()=>{const c=aiCfg(),k=P.value;$("aiModel").value=c.models[k]||AIP[k][1];$("aiKey").placeholder=c.keys[k]?"✓ Key saved (paste to replace)":"Paste key "+(AIP[k][2]?"("+AIP[k][2]+"…)":"");$("aiState").textContent=c.keys[k]?"✓ Key saved for this provider":"No key saved for this provider";};
 P.onchange=st;
 $("aiSave").onclick=()=>{const c=aiCfg(),k=P.value,v=$("aiKey").value.trim();if(v&&AIP[k][2]&&!v.startsWith(AIP[k][2])){toast("That key doesn't look like a "+AIP[k][0]+" key.");return;}if(v)c.keys[k]=v;c.models[k]=$("aiModel").value.trim()||AIP[k][1];c.provider=k;c.pinned=1;try{localStorage.setItem("learnova_ai",JSON.stringify(c));$("aiKey").value="";st();toast("AI settings saved.");}catch(e){toast("Could not save settings in this browser.");}};
 $("aiTest").onclick=async()=>{const b=$("aiTest"),state=$("aiState");b.disabled=true;b.textContent="Testing…";state.textContent="Sending a short test request…";try{const c=aiCfg(),k=P.value,v=$("aiKey").value.trim();if(v){if(AIP[k][2]&&!v.startsWith(AIP[k][2]))throw new Error("The API key format does not match this provider.");c.keys[k]=v;}c.models[k]=$("aiModel").value.trim()||AIP[k][1];c.provider=k;c.pinned=1;if(!c.keys[k])throw new Error("Add an API key and save settings first.");localStorage.setItem("learnova_ai",JSON.stringify(c));const reply=await ai("Reply with exactly these words: Learnova AI connected.",60);if(reply){state.textContent="✓ Connection works. Reply: "+reply;toast("AI connection successful.");}else{state.textContent="No reply received. Check your provider key and settings.";}}catch(e){state.textContent="Connection failed: "+(e&&e.message?e.message:"Unknown error")+". Check internet, key, model, and provider limits.";}finally{b.disabled=false;b.textContent="Test connection";}};
 $("aiRemove").onclick=()=>{const c=aiCfg();delete c.keys[P.value];localStorage.setItem("learnova_ai",JSON.stringify(c));st();toast("Key removed.");};st();
}
})();
