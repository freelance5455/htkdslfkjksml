# Word Hunt

Android Studio project for Word Hunt.

## WebView loading fix
The game HTML is bundled at `app/src/main/assets/index.html` and is loaded directly into the WebView with `loadDataWithBaseURL`. This avoids `https://appassets.androidplatform.net/web/index.html` and fixes the `net::ERR_HTTP_RESPONSE_CODE_FAILURE` error shown on some Android/WebView installations.

Package name / application ID: `com.samstudio.wordhunt`
