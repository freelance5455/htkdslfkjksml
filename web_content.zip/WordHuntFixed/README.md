# Word Hunt Android Studio Project

Fixed version of the Word Hunt 100-level game.

## Main fix
The game is bundled in `app/src/main/assets/index.html` and loaded with:

`file:///android_asset/index.html`

This avoids the `https://appassets.androidplatform.net/web/index.html` WebView error shown in the previous APK.

## Open/build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect your Android phone or use an emulator.
4. Run the `app` configuration.
5. For an APK: Build > Build APK(s).
