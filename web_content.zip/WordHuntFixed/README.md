# Word Hunt Android project

## WebView loading fix

The bundled game page is stored at `app/src/main/assets/web/index.html`. `MainActivity` loads it directly from the APK with `file:///android_asset/web/index.html`, so the app does not request `https://appassets.androidplatform.net/web/index.html` and does not depend on a remote server for its main screen.

## Build
1. Open this project in Android Studio.
2. Allow Gradle sync to finish.
3. Select **Build > Clean Project**, then **Build > Build APK(s)**.
4. Uninstall the old Word Hunt app from the device before installing the newly built APK, to avoid testing the old broken build.
