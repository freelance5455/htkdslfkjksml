Word Hunt Android Studio project

Updated vocabulary: common English words from many categories including colors, animals, countries, cities, food, nature, weather, body, home, school, sports, music, jobs, clothing, feelings, actions, and everyday vocabulary. Category words are prioritized and duplicates are removed case-insensitively. The existing level progression is retained.
