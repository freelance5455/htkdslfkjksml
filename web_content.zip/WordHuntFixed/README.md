# Word Hunt Android Studio Project

Package / Application ID: `com.app.wordhunt`

## WebView error fix

The game is bundled inside the APK at `app/src/main/assets/index.html`.
The app now opens it directly with:

`file:///android_asset/index.html`

It no longer depends on `https://appassets.androidplatform.net/web/index.html`, which was causing:

`net::ERR_HTTP_RESPONSE_CODE_FAILURE`

## Build

1. Open this `WordHuntFixed` folder in Android Studio.
2. Let Gradle sync complete.
3. Select **Build > Build APK(s)**.
4. Install the generated APK.

Package ID remains `com.app.wordhunt`.
