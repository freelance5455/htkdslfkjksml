# Word Hunt — Android Studio Project

A ready-to-open Android Studio project for the **Word Hunt** game.

## Project configuration

- **Package / Application ID:** `com.samstudio.wordhunt`
- **Namespace:** `com.samstudio.wordhunt`
- **App name:** Word Hunt
- **Version:** 1.0 (versionCode 1)
- **Minimum Android:** API 23 (Android 6.0)
- **Target / Compile SDK:** API 35
- **Android Gradle Plugin:** 8.6.1
- **Recommended Gradle:** 8.7

## Open in Android Studio

1. Extract this ZIP.
2. Open **Android Studio**.
3. Select **Open** and choose the `WordHuntFixed` folder (the folder containing `settings.gradle`).
4. Allow Android Studio to complete Gradle Sync and install any requested Android SDK components.
5. Select the **debug** build variant if Android Studio asks.

## Build APK with one click

Use:

**Build → Build Bundle(s) / APK(s) → Build APK(s)**

The debug APK will be created at:

`app/build/outputs/apk/debug/app-debug.apk`

You can also run the app directly from Android Studio using the **Run ▶** button on a connected Android device or emulator.

## Release APK

For a Play Store/uploadable release build, use:

**Build → Generate Signed App Bundle / APK**

Create or select a signing key when prompted. Do not share the keystore or passwords.

## WebView fix

The game HTML is bundled at `app/src/main/assets/index.html` and loaded locally. The WebView client also serves local asset requests from the APK, avoiding the previous `appassets.androidplatform.net` loading problem.
