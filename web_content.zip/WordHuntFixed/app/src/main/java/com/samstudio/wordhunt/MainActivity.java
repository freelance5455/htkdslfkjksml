package com.samstudio.wordhunt;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.util.Map;
import java.util.HashMap;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new VibrationBridge(this), "AndroidVibration");

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new LocalWebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        // Load the bundled game HTML directly into WebView.
        // Using loadDataWithBaseURL avoids any dependency on
        // appassets.androidplatform.net and fixes the ERR_HTTP_RESPONSE_CODE_FAILURE
        // seen on some Android/WebView versions. Relative URLs still resolve
        // against the APK's assets directory.
        loadBundledGame();
    }



    /**
     * Prevents Android WebView from trying to fetch the game's local files from
     * the network. Some WebView versions rewrite local asset URLs to
     * appassets.androidplatform.net/web/*. This client serves those requests
     * directly from APK assets instead.
     */
    private class LocalWebViewClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return serveLocalAsset(request.getUrl().toString());
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            return serveLocalAsset(url);
        }

        private WebResourceResponse serveLocalAsset(String url) {
            try {
                if (url == null) return null;
                String lower = url.toLowerCase();
                String path = null;

                if (lower.startsWith("https://appassets.androidplatform.net/web/")) {
                    path = url.substring("https://appassets.androidplatform.net/web/".length());
                } else if (lower.startsWith("file:///android_asset/")) {
                    path = url.substring("file:///android_asset/".length());
                } else {
                    return null;
                }

                if (path.isEmpty()) path = "index.html";
                InputStream input = getAssets().open(path);
                String mime = "text/plain";
                String encoding = "UTF-8";
                String lowerPath = path.toLowerCase();
                if (lowerPath.endsWith(".html") || lowerPath.endsWith(".htm")) mime = "text/html";
                else if (lowerPath.endsWith(".js")) mime = "application/javascript";
                else if (lowerPath.endsWith(".css")) mime = "text/css";
                else if (lowerPath.endsWith(".json")) mime = "application/json";
                else if (lowerPath.endsWith(".png")) { mime = "image/png"; encoding = null; }
                else if (lowerPath.endsWith(".jpg") || lowerPath.endsWith(".jpeg")) { mime = "image/jpeg"; encoding = null; }
                else if (lowerPath.endsWith(".webp")) { mime = "image/webp"; encoding = null; }
                else if (lowerPath.endsWith(".svg")) mime = "image/svg+xml";
                else if (lowerPath.endsWith(".mp3")) { mime = "audio/mpeg"; encoding = null; }
                else if (lowerPath.endsWith(".wav")) { mime = "audio/wav"; encoding = null; }

                Map<String, String> headers = new HashMap<>();
                headers.put("Cache-Control", "no-cache");
                return new WebResourceResponse(mime, encoding, 200, "OK", headers, input);
            } catch (Exception ignored) {
                return null;
            }
        }
    }

    private void loadBundledGame() {
        try (InputStream input = getAssets().open("index.html");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            String html = output.toString(StandardCharsets.UTF_8.name());
            webView.loadDataWithBaseURL(
                    "file:///android_asset/",
                    html,
                    "text/html",
                    "UTF-8",
                    null
            );
        } catch (Exception e) {
            webView.loadData(
                    "<html><body style='font-family:sans-serif;padding:24px'>" +
                    "<h2>Word Hunt could not start</h2><p>Please restart the app.</p></body></html>",
                    "text/html",
                    "UTF-8"
            );
        }
    }

    public static class VibrationBridge {
        private final Context context;
        VibrationBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface
        public void vibrate(int milliseconds) {
            Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(milliseconds);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
