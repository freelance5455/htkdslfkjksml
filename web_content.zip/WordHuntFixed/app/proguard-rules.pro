# Word Hunt does not require custom ProGuard rules.
