مدينة النيون - لعبة 3D مفتوحة العالم

التشغيل: افتح الملف index.html في أي متصفح (Chrome / Safari / Edge).
ملاحظة: اللعبة تحمّل مكتبة three.js من الإنترنت، فتحتاج اتصالًا عند أول تشغيل.
للعمل بدون إنترنت: نزّل three.min.js (الإصدار r128) وضعه بجانب index.html،
ثم غيّر في index.html سطر <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js">
إلى <script src="three.min.js">.

التحكم: الأسهم/WASD حركة، Space إطلاق، E تفاعل، R تعبئة، Shift ركض، السحب بالماوس/الإصبع للكاميرا.
