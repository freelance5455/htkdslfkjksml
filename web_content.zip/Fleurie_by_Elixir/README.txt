FLEURIE BY ELIXIR - versión HTML

Archivo principal: index.html

Puedes abrir index.html en el navegador para probar la app. Los registros se guardan en el almacenamiento local del navegador de ese dispositivo.

Para crear una APK desde Android:
- Sube index.html a tu repositorio.
- Puedes empaquetarlo con una herramienta Android WebView o un servicio de conversión HTML a APK.
- Esta versión es una aplicación web local; no incluye backend ni funciones multiusuario reales.

No incluye anuncios, suscripciones, música, películas ni series.
