BRAIN TEST 1000 - HTML game -> Android APK

OPTION A (easiest, no install): online converters
 1. Upload this ZIP (or the www folder zipped) to https://www.websitetoapk.com or https://appmaker.xyz
 2. Download the APK.

OPTION B (Capacitor + Android Studio):
 1. Install Node.js and Android Studio.
 2. In this folder run:  npm install
 3. Run:  npx cap add android
 4. Run:  npx cap sync android
 5. Run:  npx cap open android   -> in Android Studio: Build > Build APK(s)

Change app name/id in capacitor.config.json. Game code is www/index.html.
