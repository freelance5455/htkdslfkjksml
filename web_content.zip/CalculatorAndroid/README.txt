Calculator Android - HTML WebView project

1. Extract this ZIP.
2. Open Android Studio > Open > select CalculatorAndroid folder.
3. Wait for Gradle Sync (internet may be needed for initial dependencies).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK path: app/build/outputs/apk/debug/app-debug.apk

The calculator itself runs fully offline. No INTERNET permission is requested.
Note: The ZIP contains an Android Studio source project, not a precompiled APK.
