(() => {
  const cfg={enabled:false,boost:48,drive:0,echo:0,delay:110,feedback:0,bass:0,presence:100,treble:0,reverb:0,echoFx:0,chorus:0,distortion:0,tremolo:0,compressor:50,flanger:0};
  const trackCache=new WeakMap(), streamCache=new WeakMap(), graphs=new Set(), peerConnections=new Set(), senderOriginals=new WeakMap();
  const gain=db=>Math.pow(10,db/20);
  function makeCurve(amount){const c=new Float32Array(2048),k=1+Math.max(0,Math.min(1,amount))*7;for(let i=0;i<c.length;i++){const x=i*2/(c.length-1)-1;c[i]=Math.tanh(k*x)/Math.tanh(k)}return c}
  function processor(stream){
    if(streamCache.has(stream)) return streamCache.get(stream);
    const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return stream;
    let ctx;try{ctx=new AC({latencyHint:'interactive'});}catch(_){return stream;}
    const src=ctx.createMediaStreamSource(stream), dst=ctx.createMediaStreamDestination(), analyser=ctx.createAnalyser();
    analyser.fftSize=1024; src.connect(analyser);
    let meterTimer=null, lastAudioState='';
    const meterData=new Uint8Array(analyser.fftSize);
    const setAudioState=(status)=>{if(status!==lastAudioState){lastAudioState=status;window.postMessage({source:'DJ_SHAKIL',type:'VD_SENT_STATUS',status},'*')}};
    meterTimer=setInterval(()=>{try{analyser.getByteTimeDomainData(meterData);let sum=0;for(let i=0;i<meterData.length;i++){const v=(meterData[i]-128)/128;sum+=v*v;}const rms=Math.sqrt(sum/meterData.length);if(rms>0.012)setAudioState('🟢 ATTACK ACTIVE — MIC AUDIO DETECTED');else setAudioState('🟡 WAITING FOR VOICE — MIC TRACK READY');}catch(_){ }},350);
    const inputGain=ctx.createGain(), drive=ctx.createWaveShaper(), bass=ctx.createBiquadFilter(), mid=ctx.createBiquadFilter(), treble=ctx.createBiquadFilter(), comp=ctx.createDynamicsCompressor();
    const dry=ctx.createGain(), echoDelay=ctx.createDelay(.5), echoFb=ctx.createGain(), echoWet=ctx.createGain();
    const convolver=ctx.createConvolver(), reverbWet=ctx.createGain();
    const chorusDelay=ctx.createDelay(.05), chorusWet=ctx.createGain(), chorusOsc=ctx.createOscillator(), chorusDepth=ctx.createGain();
    const tremGain=ctx.createGain(), tremOsc=ctx.createOscillator(), tremDepth=ctx.createGain();
    const flangeDelay=ctx.createDelay(.03), flangeWet=ctx.createGain(), flangeOsc=ctx.createOscillator(), flangeDepth=ctx.createGain();
    // Short generated impulse response for reverb; no external asset needed.
    const ir=ctx.createBuffer(2,Math.floor(ctx.sampleRate*1.8),ctx.sampleRate);
    for(let ch=0;ch<2;ch++){const d=ir.getChannelData(ch);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,2.4)}
    convolver.buffer=ir;
    bass.type='lowshelf';bass.frequency.value=180;
    mid.type='peaking';mid.frequency.value=1000;mid.Q.value=0.8;
    treble.type='highshelf';treble.frequency.value=3500;
    comp.threshold.value=-6;comp.knee.value=12;comp.ratio.value=6;comp.attack.value=.003;comp.release.value=.12;
    echoOscStart(chorusOsc,ctx); chorusOsc.frequency.value=0.8; chorusDepth.gain.value=0;
    tremOsc.frequency.value=5; tremDepth.gain.value=0; tremOscStart(tremOsc,ctx);
    flangeOsc.frequency.value=.25; flangeDepth.gain.value=0; tremOscStart(flangeOsc,ctx);
    src.connect(inputGain).connect(drive).connect(bass).connect(mid).connect(treble).connect(comp).connect(dry).connect(dst);
    // Effects run in parallel; all are bypassed by default.
    comp.connect(echoDelay); echoDelay.connect(echoWet).connect(dst); echoDelay.connect(echoFb).connect(echoDelay);
    comp.connect(convolver);convolver.connect(reverbWet).connect(dst);
    comp.connect(chorusDelay);chorusDelay.connect(chorusWet).connect(dst);chorusOsc.connect(chorusDepth);chorusDepth.connect(chorusDelay.delayTime);
    comp.connect(tremGain);tremGain.connect(dst);tremOsc.connect(tremDepth);tremDepth.connect(tremGain.gain);
    comp.connect(flangeDelay);flangeDelay.connect(flangeWet).connect(dst);flangeOsc.connect(flangeDepth);flangeDepth.connect(flangeDelay.delayTime);
    function echoOscStart(o,c){try{o.start()}catch(_){}}
    function tremOscStart(o,c){try{o.start()}catch(_){}}
    const g={ctx,src,dst,analyser,meterTimer,inputGain,drive,bass,mid,treble,comp,dry,echoDelay,echoFb,echoWet,convolver,reverbWet,chorusDelay,chorusWet,chorusOsc,chorusDepth,tremGain,tremOsc,tremDepth,flangeDelay,flangeWet,flangeOsc,flangeDepth};
    graphs.add(g); apply(g);
    // Resume suspended Web Audio contexts when the microphone graph is created.
    try { ctx.resume(); } catch (_) {}
    const out=dst.stream;out.__vdClose=()=>{graphs.delete(g);if(meterTimer)clearInterval(meterTimer);ctx.close().catch(()=>{})};streamCache.set(stream,out);return out;
  }
  function apply(g){
    const c=cfg, master=!!c.enabled, set=(node,param,val)=>{try{node[param].setTargetAtTime(val,g.ctx.currentTime,.025)}catch(_){try{node[param].value=val}catch(__){}}};
    const amt=k=>Math.max(0,Math.min(100,Number(c[k])||0))/100;
    set(g.inputGain,'gain',gain(master?Math.max(-6,Math.min(60,+c.boost||0)):0));
    const dist=Math.max(amt('distortion'),Math.max(0,Math.min(100,+c.drive||0))/100);
    g.drive.curve=makeCurve(master?dist:0);
    g.bass.gain.value=Math.max(-12,Math.min(12,+c.bass||0));
    g.mid.gain.value=Math.max(-12,Math.min(12,(+c.presence-100)/10||0));
    g.treble.gain.value=Math.max(-12,Math.min(12,+c.treble||0));
    set(g.dry,'gain',1);
    set(g.echoDelay,'delayTime',Math.max(.02,Math.min(.25,(+c.delay||110)/1000)));
    const echoMix=Math.max(amt('echo'),amt('echoFx'));
    set(g.echoFb,'gain',Math.min(.75,amt('feedback')*.75));
    set(g.echoWet,'gain',echoMix*.7);
    set(g.reverbWet,'gain',amt('reverb')*.45);
    set(g.chorusWet,'gain',amt('chorus')*.45);
    set(g.chorusDelay,'delayTime',.012+amt('chorus')*.012);
    set(g.chorusDepth,'gain',amt('chorus')*.004);
    set(g.tremGain,'gain',1);
    set(g.tremDepth,'gain',master?amt('tremolo')*.45:0);
    set(g.flangeWet,'gain',master?amt('flanger')*.45:0);
    set(g.flangeDepth,'gain',master?amt('flanger')*.006:0);
    const compAmt=master?amt('compressor'):0;
    set(g.comp,'threshold',compAmt>0?(-3-compAmt*24):0);
    set(g.comp,'ratio',1+compAmt*11);
    set(g.comp,'knee',compAmt*20);
  }
  function processedTrack(track){
    if(!track||track.kind!=='audio'||!cfg.enabled)return track;
    if(trackCache.has(track))return trackCache.get(track);
    try{const p=processor(new MediaStream([track]));const t=p.getAudioTracks()[0];if(t){t.contentHint='speech';window.postMessage({source:'DJ_SHAKIL',type:'VD_SENT_STATUS',status:'🟡 CALL TRACK ATTACHED — SPEAK TO TEST AUDIO'},'*');trackCache.set(track,t);return t}}catch(_){}
    return track;
  }
  function maybeProcessStream(s){if(!cfg.enabled||!s||!s.getAudioTracks||!s.getAudioTracks().length)return s;return processor(s)}
  if(navigator.mediaDevices?.getUserMedia){const old=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);navigator.mediaDevices.getUserMedia=async function(c){const s=await old(c);if(cfg.enabled&&c?.audio){window.postMessage({source:'DJ_SHAKIL',type:'VD_SENT_STATUS',status:'MIC STREAM ACTIVE — CALL TRACK NOT YET CONFIRMED'},'*');return maybeProcessStream(s)}return s}}
  if(window.RTCPeerConnection){
    const p=RTCPeerConnection.prototype;
    const OriginalPC=window.RTCPeerConnection;
    try { window.RTCPeerConnection=new Proxy(OriginalPC,{construct(target,args,newTarget){const pc=Reflect.construct(target,args,newTarget);peerConnections.add(pc);return pc;}}); } catch(_) {}
    if(p.addTrack){const old=p.addTrack;p.addTrack=function(t,...streams){if(t&&t.kind==='audio'){const sender=old.call(this,processedTrack(t),...streams);senderOriginals.set(sender,t);return sender}return old.call(this,t,...streams)}}
    if(p.addTransceiver){const old=p.addTransceiver;p.addTransceiver=function(t,...args){const isAudio=t&&typeof t==='object'&&t.kind==='audio';const tr=old.call(this,isAudio?processedTrack(t):t,...args);if(isAudio&&tr?.sender)senderOriginals.set(tr.sender,t);return tr}}
    if(window.RTCRtpSender?.prototype.replaceTrack){const old=RTCRtpSender.prototype.replaceTrack;window.RTCRtpSender.prototype.replaceTrack=function(t){if(t&&t.kind==='audio'&&!senderOriginals.has(this))senderOriginals.set(this,t);return old.call(this,processedTrack(t))}}
  }
  async function refreshCallTracks(){
    for(const pc of peerConnections){
      try { for(const sender of pc.getSenders()){const original=senderOriginals.get(sender);if(!original||original.kind!=='audio')continue;const wanted=cfg.enabled?processedTrack(original):original;if(sender.track!==wanted)await sender.replaceTrack(wanted);} } catch(_) {}
    }
  }
  window.addEventListener('message',e=>{if(e.source!==window||e.data?.source!=='DJ_SHAKIL')return;const m=e.data;
    if(m.type==='VD_CONFIG')Object.assign(cfg,m.config||{});
    if(m.type==='VD_ENABLE'){cfg.enabled=!!m.enabled;refreshCallTracks();}
    if(m.type==='VD_SET')cfg[m.key]=m.value;
    if(m.type==='VD_FX')cfg[m.key]=!!m.value;
    graphs.forEach(g=>{apply(g); try{g.ctx.resume()}catch(_){}});
    if(m.type==='VD_TEST'){navigator.mediaDevices?.getUserMedia({audio:true}).then(s=>{const p=processor(s);const a=document.createElement('audio');a.autoplay=true;a.controls=true;a.srcObject=p;a.style.cssText='position:fixed;right:18px;bottom:18px;z-index:2147483647';document.body?.appendChild(a)}).catch(err=>alert('Microphone permission/error: '+err.message))}
  });
})();