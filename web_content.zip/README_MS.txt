KiraTandan Sawit - fail website untuk pembungkus APK

Kandungan utama: index.html (di root ZIP)
Gunakan pilihan "ZIP File to APK" dalam pembina, bukan "HTML File to APK".
Pastikan index.html berada terus di root ZIP, bukan dalam subfolder.
Aplikasi HTML ini menyimpan rekod secara setempat dalam WebView/localStorage dan direka untuk offline.
Nota: ZIP ini bukan APK siap dan belum diuji melalui pembina pihak ketiga.
