# Black Clover: A Lenda do Rei Mago — RPG Pixel Art de Turnos

Feito com a Rogue. O site publicado: https://black-efa1.p.rogueon.ai/

## Pedido

O último pedido desta conversa foi:

> Faz um coliseu, dentro desse coliseu o Asta tem q pagar 100 de dinheiro pra pagar, ele deve enfrentar 10 magos diferentes, casa ganhe o player ganha 2500 de dinheiro, faz o coliseu grande com um grande movimento de pessoas

## Abrir no seu computador

O site é o `index.html`, com as imagens em `public/`. Abra o `index.html` no navegador e pronto. Se preferir servir a pasta, qualquer servidor estático funciona:

```sh
python3 -m http.server 8000
```

Depois abra http://localhost:8000. Com Node instalado, `npx serve .` faz o mesmo.

## Hospedar

Não tem etapa de build: a pasta como está já é o site. Suba o conteúdo dela em qualquer hospedagem de site estático.

## Aviso

A Rogue reescreve `index.html`, as imagens que ela publicou e o `README.md` a cada mudança pedida na conversa, e remove só o que ela mesma publicou antes e deixou de existir. O que for seu, coloque em outra pasta ou em outro branch.

Se o branch `main` receber commits que não são da Rogue, a próxima versão vai para um branch `rogue/<id>`, para você comparar antes de juntar.
