// Payment provider webhook starter.
// Verify the provider's signature using its official SDK/specification before updating any purchase.
// Never accept client-side claims, screenshots, or unverified redirects as proof of payment.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

serve(async (_req) => {
  return new Response("Payment webhook not configured", { status: 501 });
});
