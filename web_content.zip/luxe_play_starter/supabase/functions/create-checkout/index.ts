// Supabase Edge Function starter: create-checkout
// Configure a payment provider's server API here. Do not trust amount/song data from the client.
// This placeholder deliberately does not create a real charge.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

serve(async (_req) => {
  return new Response(JSON.stringify({
    error: "PAYMENT_PROVIDER_NOT_CONFIGURED",
    message: "Configure your chosen provider's server-side checkout API before enabling purchases."
  }), {
    status: 501,
    headers: { "content-type": "application/json" }
  });
});
