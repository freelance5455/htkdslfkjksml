-- LuXe PLAY starter database schema for Supabase.
-- Run this in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.songs (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  artist_name text not null check (char_length(artist_name) between 1 and 120),
  price_cents integer not null check (price_cents >= 100 and price_cents <= 100000),
  audio_path text not null,
  cover_path text,
  status text not null default 'published' check (status in ('draft','published','removed')),
  created_at timestamptz not null default now()
);
alter table public.songs enable row level security;

drop policy if exists "Published songs visible to everyone" on public.songs;
create policy "Published songs visible to everyone"
on public.songs for select using (status = 'published' or auth.uid() = artist_id);

drop policy if exists "Artists insert own songs" on public.songs;
create policy "Artists insert own songs"
on public.songs for insert to authenticated with check (auth.uid() = artist_id);

drop policy if exists "Artists update own songs" on public.songs;
create policy "Artists update own songs"
on public.songs for update to authenticated using (auth.uid() = artist_id) with check (auth.uid() = artist_id);

drop policy if exists "Artists delete own songs" on public.songs;
create policy "Artists delete own songs"
on public.songs for delete to authenticated using (auth.uid() = artist_id);

create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references auth.users(id) on delete set null,
  song_id uuid not null references public.songs(id),
  amount_cents integer not null check (amount_cents > 0),
  currency text not null default 'ZAR' check (currency = 'ZAR'),
  payment_provider text not null,
  provider_reference text unique,
  status text not null default 'pending' check (status in ('pending','paid','failed','refunded')),
  created_at timestamptz not null default now(),
  paid_at timestamptz
);
alter table public.purchases enable row level security;

-- Customers may see only their own purchases. Inserts/updates must be performed by trusted server functions.
drop policy if exists "Customers view own purchases" on public.purchases;
create policy "Customers view own purchases"
on public.purchases for select to authenticated using (auth.uid() = customer_id);

create table if not exists public.artist_payout_profiles (
  artist_id uuid primary key references auth.users(id) on delete cascade,
  payout_method text not null default 'manual_review',
  account_holder_name text,
  bank_name text,
  account_number_last4 text,
  payout_reference text,
  verified boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table public.artist_payout_profiles enable row level security;

drop policy if exists "Artist views own payout profile" on public.artist_payout_profiles;
create policy "Artist views own payout profile"
on public.artist_payout_profiles for select to authenticated using (auth.uid() = artist_id);

-- Do not collect full bank account details in this starter table.
-- Store full bank details only through a verified, access-controlled backend/payout provider.

create table if not exists public.artist_ledger (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid not null references auth.users(id) on delete cascade,
  purchase_id uuid not null references public.purchases(id),
  gross_cents integer not null,
  platform_fee_cents integer not null,
  artist_net_cents integer not null,
  status text not null default 'pending' check (status in ('pending','payable','paid','reversed')),
  created_at timestamptz not null default now(),
  unique(purchase_id)
);
alter table public.artist_ledger enable row level security;

drop policy if exists "Artists view own ledger" on public.artist_ledger;
create policy "Artists view own ledger"
on public.artist_ledger for select to authenticated using (auth.uid() = artist_id);

-- Storage buckets:
-- Create private bucket "music-private" and public bucket "covers" in Storage UI.
-- Never make music-private public. Access to purchased files must be granted by a trusted server
-- after a provider webhook has verified payment.


-- Withdrawal commission policy: 30% of the requested withdrawal goes to LuXe PLAY;
-- 70% is the artist's payout. This is calculated in the database, never trusted from the browser.
create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid not null references auth.users(id) on delete cascade,
  requested_cents integer not null check (requested_cents >= 100),
  platform_fee_cents integer not null check (platform_fee_cents >= 0),
  artist_payout_cents integer not null check (artist_payout_cents >= 0),
  commission_rate numeric(5,4) not null default 0.3000 check (commission_rate = 0.3000),
  status text not null default 'pending' check (status in ('pending','approved','processing','paid','rejected','cancelled')),
  payout_reference text,
  admin_note text,
  created_at timestamptz not null default now(),
  processed_at timestamptz,
  check (requested_cents = platform_fee_cents + artist_payout_cents)
);
create index if not exists withdrawal_requests_artist_status_idx
  on public.withdrawal_requests(artist_id, status, created_at desc);
alter table public.withdrawal_requests enable row level security;
drop policy if exists "Artists view own withdrawal requests" on public.withdrawal_requests;
create policy "Artists view own withdrawal requests"
  on public.withdrawal_requests for select to authenticated using (auth.uid() = artist_id);
-- No client insert/update/delete policy: withdrawals must be created through the trusted RPC
-- and reviewed/paid through a trusted admin or payout-provider backend.

create or replace function public.request_artist_withdrawal(p_requested_cents integer)
returns table (
  withdrawal_id uuid,
  requested_cents integer,
  platform_fee_cents integer,
  artist_payout_cents integer,
  available_after_cents bigint
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_artist uuid := auth.uid();
  v_available bigint;
  v_fee integer;
  v_payout integer;
  v_id uuid;
begin
  if v_artist is null then
    raise exception 'You must be signed in to request a withdrawal.';
  end if;
  if p_requested_cents is null or p_requested_cents < 100 then
    raise exception 'Minimum withdrawal request is R1.00.';
  end if;

  -- Serialize requests for the same artist to prevent simultaneous over-withdrawals.
  perform pg_advisory_xact_lock(hashtextextended(v_artist::text, 0));

  select coalesce(sum(l.artist_net_cents), 0)
    into v_available
    from public.artist_ledger l
   where l.artist_id = v_artist and l.status = 'payable';

  v_available := v_available - coalesce((
    select sum(w.requested_cents)
      from public.withdrawal_requests w
     where w.artist_id = v_artist
       and w.status in ('pending','approved','processing')
  ), 0);

  if p_requested_cents > v_available then
    raise exception 'Requested amount exceeds your available balance.';
  end if;

  v_fee := round(p_requested_cents * 0.30)::integer;
  v_payout := p_requested_cents - v_fee;

  insert into public.withdrawal_requests
    (artist_id, requested_cents, platform_fee_cents, artist_payout_cents)
  values (v_artist, p_requested_cents, v_fee, v_payout)
  returning id into v_id;

  return query select v_id, p_requested_cents, v_fee, v_payout,
    (v_available - p_requested_cents)::bigint;
end;
$$;
revoke all on function public.request_artist_withdrawal(integer) from public;
grant execute on function public.request_artist_withdrawal(integer) to authenticated;

-- IMPORTANT: an admin/payout backend must mark the request paid and mark the corresponding
-- artist_ledger rows paid in one audited transaction. Do not mark requests paid from the browser.
