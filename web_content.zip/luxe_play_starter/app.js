// LuXe PLAY starter frontend. Replace these values with your Supabase project details.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY_HERE";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const sb = configured ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const $ = id => document.getElementById(id);
let currentUser = null;

function msg(id, text) { $(id).textContent = text || ""; }
function money(cents) { return new Intl.NumberFormat("en-ZA",{style:"currency",currency:"ZAR"}).format(cents/100); }
function escapeHtml(s="") { return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function requireConfig() {
  if (!sb) throw new Error("First connect your Supabase project: edit SUPABASE_URL and SUPABASE_ANON_KEY in app.js.");
}
function showArtist() {
  $("artistPanel").classList.remove("hidden");
  $("authPanel").classList.toggle("hidden", !!currentUser);
  $("storePanel").classList.add("hidden");
}
function showStore() {
  $("storePanel").classList.remove("hidden");
  $("artistPanel").classList.add("hidden");
  if (!currentUser) $("authPanel").classList.remove("hidden");
}
$("showArtistBtn").addEventListener("click", showArtist);
$("showStoreBtn").addEventListener("click", showStore);
$("refreshBtn").addEventListener("click", loadStore);
$("signOutBtn").addEventListener("click", async () => {
  try { requireConfig(); await sb.auth.signOut(); currentUser = null; updateAuthUI(); msg("authMessage","Signed out."); }
  catch(e){ msg("authMessage",e.message); }
});

$("authForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    requireConfig();
    const {data,error} = await sb.auth.signInWithPassword({email:$("email").value.trim(),password:$("password").value});
    if(error) throw error;
    currentUser = data.user; updateAuthUI(); msg("authMessage","Signed in successfully."); await loadMySongs();
  } catch(err) { msg("authMessage",err.message); }
});
$("signUpBtn").addEventListener("click", async () => {
  try {
    requireConfig();
    const email = $("email").value.trim(), password = $("password").value;
    if(!email || password.length < 8) throw new Error("Enter an email and a password of at least 8 characters.");
    const {data,error} = await sb.auth.signUp({email,password});
    if(error) throw error;
    msg("authMessage", data.session ? "Account created. You can start uploading." : "Account created. Check your email to confirm, then sign in.");
  } catch(err) { msg("authMessage",err.message); }
});
function updateAuthUI(){
  $("authPanel").classList.toggle("hidden",!!currentUser);
  $("artistPanel").classList.toggle("hidden",!currentUser);
  $("signedInAs").textContent = currentUser ? currentUser.email : "";
}

$("uploadForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    requireConfig();
    if(!currentUser) throw new Error("Sign in first.");
    const audio = $("audioFile").files[0], cover = $("coverFile").files[0];
    if(!audio) throw new Error("Choose an audio file.");
    if(audio.size > 100*1024*1024) throw new Error("Starter limit: audio file must be under 100 MB.");
    const title = $("songTitle").value.trim(), artist = $("artistName").value.trim();
    const price = Math.round(Number($("songPrice").value)*100);
    if(!title || !artist || !Number.isFinite(price) || price < 100) throw new Error("Enter title, artist, and a price of at least R1.");
    msg("uploadMessage","Uploading audio…");
    const id = crypto.randomUUID();
    const audioPath = `${currentUser.id}/${id}-${safeName(audio.name)}`;
    const audioUpload = await sb.storage.from("music-private").upload(audioPath,audio,{upsert:false,contentType:audio.type||"application/octet-stream"});
    if(audioUpload.error) throw audioUpload.error;
    let coverPath = null;
    if(cover) {
      if(cover.size > 8*1024*1024) throw new Error("Cover image must be under 8 MB.");
      coverPath = `${currentUser.id}/${id}-${safeName(cover.name)}`;
      const coverUpload = await sb.storage.from("covers").upload(coverPath,cover,{upsert:false,contentType:cover.type});
      if(coverUpload.error) throw coverUpload.error;
    }
    const {error} = await sb.from("songs").insert({
      id, artist_id:currentUser.id, title, artist_name:artist, price_cents:price,
      audio_path:audioPath, cover_path:coverPath, status:"published"
    });
    if(error) {
      await sb.storage.from("music-private").remove([audioPath]);
      if(coverPath) await sb.storage.from("covers").remove([coverPath]);
      throw error;
    }
    $("uploadForm").reset(); $("songPrice").value="20.00";
    msg("uploadMessage","Song uploaded and published."); await loadMySongs(); await loadStore();
  } catch(err) { msg("uploadMessage",err.message); }
});
function safeName(name){return name.toLowerCase().replace(/[^a-z0-9._-]/g,"-").slice(-90)||"track.bin";}
async function coverUrl(path){
  if(!path) return "";
  const {data,error}=await sb.storage.from("covers").createSignedUrl(path,3600);
  return error ? "" : data.signedUrl;
}
function card(song, cover, mine=false){
  const el=document.createElement("article"); el.className="song-card";
  const image=cover || "";
  el.innerHTML=`${image?`<img class="cover" src="${escapeHtml(image)}" alt="Cover artwork">`:`<div class="cover"></div>`}
    <div class="song-info"><h3>${escapeHtml(song.title)}</h3><p>${escapeHtml(song.artist_name)}</p><p>${money(song.price_cents)}</p>
    <div class="song-actions">${mine?`<button class="secondary" data-preview="${escapeHtml(song.id)}">Preview</button>`:`<button data-buy="${escapeHtml(song.id)}">Buy & Download</button>`}</div>
    </div>`;
  if(mine) el.querySelector("[data-preview]").addEventListener("click",()=>previewSong(song.id));
  else el.querySelector("[data-buy]").addEventListener("click",()=>buySong(song.id));
  return el;
}
async function loadStore(){
  if(!configured){msg("storeMessage","Connect Supabase first (see README.md).");return;}
  try{
    msg("storeMessage","Loading releases…");
    const {data,error}=await sb.from("songs").select("id,title,artist_name,price_cents,cover_path").eq("status","published").order("created_at",{ascending:false}).limit(100);
    if(error) throw error;
    const grid=$("storeSongs");grid.replaceChildren();
    for(const song of data||[]) grid.appendChild(card(song,await coverUrl(song.cover_path)));
    msg("storeMessage",data?.length?`${data.length} release(s) available.`:"No releases yet. Artists can publish the first song.");
  }catch(e){msg("storeMessage",e.message);}
}
async function loadMySongs(){
  if(!configured||!currentUser)return;
  try{
    const {data,error}=await sb.from("songs").select("*").eq("artist_id",currentUser.id).order("created_at",{ascending:false});
    if(error)throw error;
    const grid=$("mySongs");grid.replaceChildren();
    for(const song of data||[])grid.appendChild(card(song,await coverUrl(song.cover_path),true));
  }catch(e){msg("uploadMessage",e.message);}
}
async function previewSong(songId){
  try{
    const {data:song,error}=await sb.from("songs").select("audio_path").eq("id",songId).single();
    if(error)throw error;
    const {data,error:storageError}=await sb.storage.from("music-private").createSignedUrl(song.audio_path,300);
    if(storageError)throw storageError;
    const audio=new Audio(data.signedUrl); audio.controls=true; audio.play();
    const old=$("previewPlayer"); if(old)old.remove();
    audio.id="previewPlayer"; audio.style.width="100%"; $("mySongs").prepend(audio);
  }catch(e){msg("uploadMessage",e.message);}
}
async function buySong(songId){
  // Intentionally fail closed: never unlock a paid track before server-side verification.
  alert("Purchasing is not active yet. A payment gateway and verified server-side checkout must be configured before customers can buy music.");
}

function updateWithdrawalBreakdown(){
  const cents=Math.max(0,Math.round(Number($("withdrawAmount").value||0)*100));
  const fee=Math.round(cents*0.30), payout=cents-fee;
  $("withdrawBreakdown").textContent=`LuXe PLAY (30%): ${money(fee)} · Artist receives (70%): ${money(payout)}. Final figures are calculated by the database.`;
}
$("withdrawAmount").addEventListener("input",updateWithdrawalBreakdown);
$("withdrawForm").addEventListener("submit",async e=>{
  e.preventDefault();
  try{
    requireConfig();
    if(!currentUser)throw new Error("Sign in first.");
    const cents=Math.round(Number($("withdrawAmount").value)*100);
    if(!Number.isFinite(cents)||cents<100)throw new Error("Enter at least R1.00.");
    msg("withdrawMessage","Submitting withdrawal request…");
    const {data,error}=await sb.rpc("request_artist_withdrawal",{p_requested_cents:cents});
    if(error)throw error;
    const row=Array.isArray(data)?data[0]:data;
    msg("withdrawMessage",`Request submitted. LuXe PLAY: ${money(row.platform_fee_cents)} (30%); artist payout: ${money(row.artist_payout_cents)} (70%). This is a request, not an instant bank transfer.`);
    $("withdrawForm").reset();updateWithdrawalBreakdown();
    await loadWithdrawals();
  }catch(err){msg("withdrawMessage",err.message);}
});
async function loadWithdrawals(){
  if(!configured||!currentUser)return;
  try{
    const {data:ledger,error:ledgerError}=await sb.from("artist_ledger").select("artist_net_cents").eq("artist_id",currentUser.id).eq("status","payable");
    if(ledgerError)throw ledgerError;
    const {data:requests,error}=await sb.from("withdrawal_requests").select("id,requested_cents,platform_fee_cents,artist_payout_cents,status,created_at").eq("artist_id",currentUser.id).order("created_at",{ascending:false}).limit(50);
    if(error)throw error;
    const reserved=(requests||[]).filter(r=>["pending","approved","processing"].includes(r.status)).reduce((sum,r)=>sum+r.requested_cents,0);
    const gross=(ledger||[]).reduce((sum,r)=>sum+r.artist_net_cents,0);
    $("availableBalance").textContent=money(Math.max(0,gross-reserved));
    const list=$("withdrawalList");list.replaceChildren();
    for(const r of requests||[]){
      const item=document.createElement("div");item.className="withdrawal-item";
      item.textContent=`${new Date(r.created_at).toLocaleDateString("en-ZA")} · Request ${money(r.requested_cents)} · LuXe PLAY ${money(r.platform_fee_cents)} · Artist ${money(r.artist_payout_cents)} · Status: ${r.status}`;
      list.appendChild(item);
    }
    if(!requests?.length)list.textContent="No withdrawal requests yet.";
  }catch(e){msg("withdrawMessage",e.message);}
}

async function init(){
  if(!configured){msg("storeMessage","Setup required: create a Supabase project, run supabase/schema.sql, then add your project URL and anon key to app.js.");return;}
  const {data}=await sb.auth.getSession(); currentUser=data.session?.user||null; updateAuthUI();
  sb.auth.onAuthStateChange((_event,session)=>{currentUser=session?.user||null;updateAuthUI();if(currentUser){loadMySongs();loadWithdrawals();}});
  await loadStore(); if(currentUser){await loadMySongs();await loadWithdrawals();}
}
init();
