# LuXe PLAY — starter project

This is a starter marketplace web app designed to be edited from a phone. It includes:
- Artist email/password registration and sign-in via Supabase Auth
- Song and optional cover uploads
- Music store listing
- Private audio storage and temporary signed URLs for artist previews
- Database schema for purchases, artist payout profiles, an artist earnings ledger, and withdrawal requests
- Database-calculated withdrawal split: 30% to LuXe PLAY and 70% to the artist
- Artist screen to request a withdrawal and view the 30/70 breakdown and request status
- Payment function placeholders that fail safely until a payment provider is configured
- No advertising SDKs

## Important limitations
This is NOT a production-ready payment marketplace yet. Purchases are intentionally disabled. You must select a payment provider and implement server-side checkout, signature-verified webhooks, refunds, reconciliation, and artist payouts before accepting real money. Provider availability and marketplace/payout support must be confirmed for your South African business.

The artist payout table intentionally does not store full bank account numbers. Use a secure, verified backend/provider flow for sensitive bank details. Do not put service-role keys, payment secret keys, or bank credentials in browser code or an APK.

## Quick setup
1. Create a project at https://supabase.com.
2. In the Supabase dashboard, open SQL Editor and run `supabase/schema.sql`.
3. In Storage, create:
   - `music-private` as a PRIVATE bucket
   - `covers` as a PUBLIC bucket (artwork only)
4. In Project Settings > API, copy the Project URL and anon/public key.
5. Edit `app.js` and replace:
   - `PASTE_YOUR_SUPABASE_PROJECT_URL_HERE`
   - `PASTE_YOUR_SUPABASE_ANON_KEY_HERE`
6. Publish the files to a static hosting service, or use a local HTML preview/editor for initial design testing.
7. Test artist sign-up, sign-in, upload, and store listing. Test withdrawal requests only with test data and confirm the SQL schema has been run.

## Storage policies
The SQL creates table policies but storage policies should also be added in Supabase Storage. Recommended initial rules:
- Authenticated artists can upload/read/delete objects only under a folder whose first path segment equals their auth user ID.
- Keep `music-private` private.
- Only make cover artwork public.
- For production, enforce file size and MIME restrictions in Storage settings.

## Building an APK
This starter is a responsive web app, not a compiled APK. First get the web version working. It can later be wrapped in an Android app (e.g. a WebView/Capacitor shell) or rebuilt natively in Kotlin. A proper native music player with background playback can be added as a separate Android project.

## LuXe PLAY withdrawal commission
- Each withdrawal request is for the gross amount the artist wants to withdraw.
- The database calculates 30% as LuXe PLAY's platform share and 70% as the artist payout. Example: a R100.00 request allocates R30.00 to LuXe PLAY and R70.00 to the artist.
- The app records a pending request only. It does not move money to a bank account automatically.
- A trusted admin/payout backend must verify the artist's payout details, process the transfer, keep an audit trail, and update both the withdrawal request and ledger consistently. Never mark a payout paid from browser code.
- Tell artists about the 30% fee before they confirm a request and get appropriate legal/accounting advice before launch.

## Payment integration checklist
1. Confirm provider supports South African merchants and your business type.
2. Confirm payment methods and whether artist split payments or bank payouts are supported.
3. Implement `create-checkout` on the server. Look up the song and price from the database; do not accept the amount from the browser.
4. Create a pending purchase record.
5. Verify provider webhook signatures.
6. Mark purchase paid only after provider confirmation.
7. Create an artist ledger entry idempotently and calculate platform commission server-side.
8. Generate a short-lived download URL only after checking the authenticated customer's paid purchase.
9. Add refunds, chargeback handling, payout reconciliation, and audit logs.

## Phone workflow
On your Samsung Galaxy A32, download and extract the ZIP using My Files, then edit files with a code editor or open the repository in a browser-based development workspace. Supabase setup is easiest in your browser. Do not paste private keys into chat or share them publicly.
