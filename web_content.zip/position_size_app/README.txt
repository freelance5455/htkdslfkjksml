Position Size Calculator - Android packaging

App name: Position Size Calculator
Suggested package ID: com.positioncalculator.risk
Start page: index.html

This package contains the standalone offline HTML app. To build an APK, upload index.html or this ZIP to an HTML-to-APK builder (for example htmltoapp.dev), set the app name and package ID, and download its signed APK.

IMPORTANT: Contract sizes for CFDs (indices, commodities, crypto) vary by broker. Adjust contract size/value in the calculator as needed.
