var c=document.getElementById("c"),ctx=c.getContext("2d"),mm=document.getElementById("mm"),mctx=mm.getContext("2d"),W,H;
var pCvs=document.getElementById("catPreview"),pCtx=pCvs.getContext("2d");
function rs(){W=c.width=innerWidth;H=c.height=innerHeight}
rs();onresize=rs;

var actx=null,sndOn=1,bgmStep=0;
function initAudio(){try{if(!actx)actx=new(window.AudioContext||window.webkitAudioContext)();if(actx&&actx.state==="suspended")actx.resume()}catch(e){}}
function sfx(f1,f2,dur,tp,vol){if(!sndOn||!actx)return;try{var o=actx.createOscillator(),g=actx.createGain();o.type=tp||"square";o.frequency.setValueAtTime(f1,actx.currentTime);o.frequency.exponentialRampToValueAtTime(f2,actx.currentTime+dur);g.gain.setValueAtTime(vol||.12,actx.currentTime);g.gain.exponentialRampToValueAtTime(.001,actx.currentTime+dur);o.connect(g);g.connect(actx.destination);o.start();o.stop(actx.currentTime+dur)}catch(e){}}

var TRACKS=[
  {bass:[130.8,130.8,130.8,130.8,130.8,130.8,130.8,130.8,130.8,130.8,130.8,130.8,130.8,130.8,130.8,130.8],lead:[[523.2,659.2,784],0,[523.2,659.2,784],[587.3,740,880],0,[587.3,740,880],[493.8,587.3,784],0,[493.8,587.3,784],[523.2,659.2,784],0,[493.8,587.3,784],[440,523.2,659.2],0,[392,493.8,587.3],0],tp:"sawtooth"},
  {bass:[110,220,110,220,130.8,261.6,130.8,261.6,146.8,293.6,146.8,293.6,164.8,329.6,146.8,293.6],lead:[[523.2],0,[523.2],0,[659.2],0,[587.3],[523.2],[587.3],0,[587.3],0,[440,523.2],0,[493.8],0],tp:"square"},
  {bass:[82.4,82.4,98,82.4,82.4,82.4,110,98,82.4,82.4,98,82.4,116.5,110,98,87.3],lead:[[329.6,493.8],0,0,[349.2,523.2],0,0,[392,587.3],0,[415.3,622.2],0,[392,587.3],0,[329.6,493.8],0,[246.9],0],tp:"sawtooth"},
  {bass:[146.8,146.8,293.6,146.8,174.6,174.6,349.2,174.6,196,196,392,196,220,220,440,220],lead:[[587.3],[659.2],[698.4],0,0,[698.4],[659.2],[587.3],[659.2],0,[880,1174.6],0,0,0,[659.2],0],tp:"triangle"}
];
setInterval(function(){if(!run||paused||over||!sndOn||!actx)return;var tr=TRACKS[(lvl-1)%TRACKS.length],s=bgmStep%16;sfx(tr.bass[s],tr.bass[s]*.97,.13,"sawtooth",.042);var ch=tr.lead[s];if(ch)ch.forEach(function(f){sfx(f,f,.17,tr.tp,.03)});bgmStep++},160);
function togAudio(){sndOn=!sndOn;document.getElementById("btnM").innerText="AUDIO: "+(sndOn?"ON":"OFF")}

var CATS=[
  {name:"MICIO",cost:0,hp:3500,spd:4.1,dmg:500,rel:55,type:0,desc:"Spara a ventaglio • Furia: Raffica 360°",
   skins:[
     {name:"Classico",cost:0,col:"#f39c12",helm:"#27ae60",acc:"#fff"},
     {name:"Tigre Bianca",cost:8,col:"#ecf0f1",helm:"#2980b9",acc:"#3498db"},
     {name:"Micio Dorato",cost:18,col:"#f1c40f",helm:"#e67e22",acc:"#fff200"},
     {name:"Infernale",cost:30,col:"#c0392b",helm:"#2c3e50",acc:"#ff4757"}
   ]},
  {name:"NINJA",cost:5,hp:2800,spd:5.4,dmg:380,rel:36,type:1,desc:"Shuriken rapidi • Furia: Cura + Scatto",
   skins:[
     {name:"Ombra",cost:0,col:"#2c3e50",helm:"#8e44ad",acc:"#a55eea"},
     {name:"Samurai Rosso",cost:10,col:"#922b21",helm:"#f1c40f",acc:"#ff6b81"},
     {name:"Fantasma",cost:20,col:"#7f8fa6",helm:"#00d2d3",acc:"#7bed9f"},
     {name:"Drago Giada",cost:35,col:"#16a085",helm:"#f39c12",acc:"#2ecc71"}
   ]},
  {name:"PANZER",cost:10,hp:5200,spd:3.3,dmg:1050,rel:72,type:2,desc:"Cannone pesante • Furia: Scudo + Bomba",
   skins:[
     {name:"Acciaio",cost:0,col:"#7f8c8d",helm:"#d35400",acc:"#e67e22"},
     {name:"Mimetico",cost:12,col:"#556b2f",helm:"#2f3640",acc:"#badc58"},
     {name:"Magma",cost:24,col:"#2f3542",helm:"#ff4757",acc:"#ffa502"},
     {name:"Titanio Oro",cost:40,col:"#dcdde1",helm:"#fbc531",acc:"#fff"}
   ]},
  {name:"CYBER",cost:20,hp:3800,spd:4.7,dmg:450,rel:42,type:3,desc:"Doppio Laser • Furia: Tempesta Elettrica",
   skins:[
     {name:"Neon Blu",cost:0,col:"#00a8ff",helm:"#fbc531",acc:"#00d2d3"},
     {name:"Matrix",cost:15,col:"#1e272e",helm:"#2ecc71",acc:"#0be881"},
     {name:"Synthwave",cost:28,col:"#8c7ae6",helm:"#ff6b81",acc:"#ff9ff3"},
     {name:"Ologramma",cost:45,col:"#48dbfb",helm:"#ffffff",acc:"#feca57"}
   ]},
  {name:"MAGO",cost:35,hp:3400,spd:4.4,dmg:780,rel:58,type:4,desc:"Sfere Arcane • Furia: Cura Totale",
   skins:[
     {name:"Arcano",cost:0,col:"#9b59b6",helm:"#1abc9c",acc:"#e056fd"},
     {name:"Negromante",cost:18,col:"#2f3640",helm:"#2ecc71",acc:"#badc58"},
     {name:"Solare",cost:32,col:"#e67e22",helm:"#f1c40f",acc:"#fffa65"},
     {name:"Cosmico",cost:50,col:"#192a56",helm:"#00a8ff",acc:"#fbc531"}
   ]}
];

var WEAPONS=[
  {id:1,name:"Base",cost:0,col:"#95a5a6",tip:"#d63031",bonus:"Danno Standard"},
  {id:2,name:"Plasma Felino",cost:12,col:"#ff6b81",tip:"#fffa65",bonus:"+35% Danno"},
  {id:3,name:"Tri-Laser",cost:25,col:"#00d2d3",tip:"#ffffff",bonus:"+70% Danno + Ventaglio"},
  {id:4,name:"Supernova",cost:45,col:"#fbc531",tip:"#ff4757",bonus:"+105% Danno Massimo"}
];

var tunaBank=parseInt(localStorage.getItem("bg_tuna")||"0");
var unlocked=JSON.parse(localStorage.getItem("bg_unl")||"null")||new Array(1,0,0,0,0);
var unlSkins=JSON.parse(localStorage.getItem("bg_skins")||"null")||new Array(new Array(1,0,0,0),new Array(1,0,0,0),new Array(1,0,0,0),new Array(1,0,0,0),new Array(1,0,0,0));
var eqSkins=JSON.parse(localStorage.getItem("bg_eqskin")||"null")||new Array(0,0,0,0,0);
var unlWpns=JSON.parse(localStorage.getItem("bg_wpns")||"null")||new Array(1,0,0,0);
var eqWpn=parseInt(localStorage.getItem("bg_eqwpn")||"1");
var freeClaimed=parseInt(localStorage.getItem("bg_free")||"0");

var curCat=0,lobTab=0;
function saveAll(){
  localStorage.setItem("bg_tuna",tunaBank);
  localStorage.setItem("bg_unl",JSON.stringify(unlocked));
  localStorage.setItem("bg_skins",JSON.stringify(unlSkins));
  localStorage.setItem("bg_eqskin",JSON.stringify(eqSkins));
  localStorage.setItem("bg_wpns",JSON.stringify(unlWpns));
  localStorage.setItem("bg_eqwpn",eqWpn);
  localStorage.setItem("bg_free",freeClaimed);
}

