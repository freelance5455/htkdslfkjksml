MY SALARY WALLET PREMIUM — HINDI GUIDE

ZIP mein index.html editable app file hai.

FEATURES
- Premium black & gold design
- Monthly salary ₹12,000 default; salary calculation days 30; daily rate ₹400 default
- Present, Absent, Half Day, Weekly Off, Paid Leave
- Date-wise attendance; edit/delete; Time In/Out and overnight shift support
- Lunch and optional tea break
- OT automatic/manual; default ₹50/hour, editable
- Separate night allowance, extra/conveyance, deductions
- Monthly and yearly reports
- CSV export; JSON backup and restore
- Local phone storage; works offline after the HTML is loaded or bundled in an APK

IMPORTANT
This is an HTML app, NOT an APK yet. It stores data locally. Internet can be on or off, but this version does not automatically sync to Google Drive/cloud and Telegram is not connected. Cloud sync requires secure backend/Firebase configuration. Never place a Telegram bot token inside HTML.

APK TIP
For offline use, package index.html inside the Android app as a local asset/WebView page. If you only load a website URL, offline use may not work. Test storage, CSV export, and JSON backup in the final APK.

DEFAULT CALCULATION
₹12,000 ÷ 30 = ₹400 daily. Full shift threshold 8.5 paid hours, half day threshold 4 hours, lunch 30 minutes, OT ₹50/hour. All settings can be edited. Present gets full daily base, Half Day gets 50%, Paid Leave gets full base, Absent and Weekly Off get ₹0 base.
