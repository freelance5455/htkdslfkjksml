# সেটআপ (Firebase)
1. console.firebase.google.com এ প্রজেক্ট বানান → Authentication → Sign-in method → **Google** চালু করুন।
2. Firestore Database (production mode) ও Storage চালু করুন। (নতুন প্রজেক্টে Storage-এর জন্য Blaze প্ল্যান লাগতে পারে।)
3. Project settings → Web app যোগ করে কনফিগ `public/firebase-config.js` এ বসান।
4. Authentication → Settings → Authorized domains এ আপনার হোস্টিং ডোমেইন আছে কিনা দেখুন।
5. `npm i -g firebase-tools && firebase login && firebase use <project-id>`
6. `firebase deploy --only firestore:rules,storage,hosting`
7. সাইটে একবার লগইন করুন → Authentication > Users থেকে আপনার UID কপি করুন।
8. Project settings → Service accounts → key ডাউনলোড (গোপন রাখুন, গিটে দেবেন না), তারপর:
   `cd scripts && npm i && GOOGLE_APPLICATION_CREDENTIALS=../key.json node set-admin.js <UID>`
   এরপর লগআউট করে আবার লগইন করুন। এখন আপনিই একমাত্র অ্যাডমিন (রুলস `token.admin` দেখে)।
9. রিকভারি: নতুন Google অ্যাকাউন্টের UID দিয়ে ধাপ ৮ আবার চালান (service account key দরকার)।
## নিরাপত্তা চেকলিস্ট
- রুলস Rules Playground-এ anonymous / সাধারণ ইউজার / অ্যাডমিন দিয়ে টেস্ট করুন।
- App Check ও Firestore backup (export) চালু করুন।
