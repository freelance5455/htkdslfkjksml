# AJMEER KHAN HACKER KING - Tools Hub
Static site. Open index.html, or upload the folder to GitHub Pages / any static host / InfinityFree htdocs. No PHP, API keys or libraries needed.
WhatsApp support: wa.me/923225533619 (03225533619 + Pakistan code 92 - change WA in assets/js/tools.js if wrong). Channel: https://whatsapp.com/channel/0029Vb8plMY7j6g1IBJxFE23
## Status: PARTIAL - 44 of the 100 requested tools are implemented.
Not yet built: Text Repeater, Fancy Text, Find & Replace, Random Letter/Symbol, Gradient/Shadow/Radius/Button/Animation generators, Color Picker, Font Previewer, Palette, HTML/JS/XML formatters, JS minifier, Regex Tester, all QR tools, URL shortener, Link Opener, Metadata Viewer, Scientific Calc, Date Difference, Unit Converter, all File tools, all Image tools, all Audio/Speech tools, Stopwatch, Countdown, Notes, To-Do.
Notes: QR, ZIP and JS formatting need bundled libraries (not yet included). Privacy: nothing is uploaded.
