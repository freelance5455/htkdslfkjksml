No third-party libraries are bundled in this version. All code is original.
