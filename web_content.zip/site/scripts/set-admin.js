// ব্যবহার: GOOGLE_APPLICATION_CREDENTIALS=key.json node scripts/set-admin.js <আপনার-UID>
// key.json কখনো গিটে/ফ্রন্টএন্ডে রাখবেন না।
const admin = require('firebase-admin');
admin.initializeApp({ credential: admin.credential.applicationDefault() });
const uid = process.argv[2];
if (!uid) { console.error('UID দিন'); process.exit(1); }
admin.auth().setCustomUserClaims(uid, { admin: true })
  .then(() => { console.log('অ্যাডমিন সেট হয়েছে। একবার লগআউট/লগইন করুন।'); process.exit(0); });
