'use strict';
const WA='923225533619'; // 03225533619 with Pakistan country code 92 (leading 0 removed)
const L=s=>s.split('\n'),b64=s=>btoa(unescape(encodeURIComponent(s))),
rnd=n=>{const a=new Uint32Array(n);crypto.getRandomValues(a);return a},
pick=(cs,n)=>Array.from(rnd(n),x=>cs[x%cs.length]).join(''),
num=(s,d)=>{const n=parseInt(s,10);if(!Number.isInteger(n)||n<1||n>d)throw Error('Enter a whole number from 1 to '+d+'.');return n},
parts=s=>s.split('|').map(x=>x.trim()),
ent={'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};
// [category,name,instructions,fn,generatorFlag]
const T=[
['Text','Uppercase Converter','Paste text to convert to UPPERCASE.',s=>s.toUpperCase()],
['Text','Lowercase Converter','Paste text to convert to lowercase.',s=>s.toLowerCase()],
['Text','Case Converter (Title Case)','Paste text to convert to Title Case.',s=>s.toLowerCase().replace(/(^|\s)\S/g,c=>c.toUpperCase())],
['Text','Reverse Text','Reverses the whole text.',s=>[...s].reverse().join('')],
['Text','Word Reverser','Reverses the letters of every word.',s=>s.replace(/\S+/g,w=>[...w].reverse().join(''))],
['Text','Line Sorter','One item per line. Sorted A to Z.',s=>L(s).sort((a,b)=>a.localeCompare(b)).join('\n')],
['Text','Duplicate Line Remover','Removes repeated lines, keeping the first.',s=>[...new Set(L(s))].join('\n')],
['Text','Extra Space Remover','Collapses repeated spaces and trims line ends.',s=>s.replace(/[ \t]+/g,' ').replace(/^ | $/gm,'')],
['Text','Word Counter','Counts words, characters and lines.',s=>`Words: ${s.trim().split(/\s+/).length}\nCharacters: ${s.length}\nLines: ${L(s).length}`],
['Text','Character Counter','Counts characters with and without spaces.',s=>`With spaces: ${s.length}\nWithout spaces: ${s.replace(/\s/g,'').length}`],
['Text','Text Encoder','Encodes text to Base64 (UTF-8). Encoding is not encryption.',b64],
['Text','Text Decoder','Decodes Base64 (UTF-8) text.',s=>decodeURIComponent(escape(atob(s.trim())))],
['Security','Password Generator','Enter the length (4-128). Uses crypto random.',s=>pick('abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*-_',num(s||16,128)<4?(()=>{throw Error('Minimum length is 4.')})():num(s||16,128)),1],
['Security','Password Strength Checker','Paste a password. It is checked locally.',s=>{let p=0;[/[a-z]/,/[A-Z]/,/\d/,/[^\w]/].forEach(r=>r.test(s)&&p++);if(s.length>=12)p++;if(s.length>=16)p++;return 'Strength: '+['Very weak','Very weak','Weak','Fair','Good','Strong','Very strong'][p]+' (score '+p+'/6)'}],
['Security','PIN Generator','Enter the number of digits (4-12).',s=>pick('0123456789',num(s||4,12)),1],
['Security','Random Number Generator','Enter min,max e.g. 1,100.',s=>{const[a,b]=(s||'1,100').split(',').map(Number);if(!Number.isInteger(a)||!Number.isInteger(b)||a>b)throw Error('Use two whole numbers: min,max.');return String(a+rnd(1)[0]%(b-a+1))},1],
['Security','Base64 Encoder','Encodes text to Base64.',b64],
['Security','Base64 Decoder','Decodes Base64 to text.',s=>decodeURIComponent(escape(atob(s.trim())))],
['Security','UUID Generator','Click Run for a random UUID v4.',()=>crypto.randomUUID(),1],
['Security','SHA-256 Hash Generator','Hashes text with SHA-256. A hash is not encryption.',async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(x=>x.toString(16).padStart(2,'0')).join('')],
['Design','HEX to RGB Converter','Enter a HEX color e.g. #1a56db.',s=>{const m=/^#?([0-9a-f]{6}|[0-9a-f]{3})$/i.exec(s.trim());if(!m)throw Error('Invalid HEX color.');let h=m[1];if(h.length==3)h=[...h].map(c=>c+c).join('');return `rgb(${parseInt(h.slice(0,2),16)}, ${parseInt(h.slice(2,4),16)}, ${parseInt(h.slice(4),16)})`}],
['Design','RGB to HEX Converter','Enter r,g,b e.g. 26,86,219.',s=>{const v=s.split(',').map(x=>+x.trim());if(v.length!=3||v.some(x=>!Number.isInteger(x)||x<0||x>255))throw Error('Enter three whole numbers 0-255.');return '#'+v.map(x=>x.toString(16).padStart(2,'0')).join('')}],
['Developer','JSON Formatter','Paste JSON to pretty-print it.',s=>JSON.stringify(JSON.parse(s),null,2)],
['Developer','JSON Validator','Paste JSON to check validity.',s=>{JSON.parse(s);return 'Valid JSON.'}],
['Developer','CSS Minifier','Paste CSS to minify (simple, comment/whitespace based).',s=>s.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\s+/g,' ').replace(/\s*([{}:;,])\s*/g,'$1').replace(/;}/g,'}').trim()],
['Developer','HTML Minifier','Paste HTML. Removes comments and extra whitespace between tags. Do not use on <pre>.',s=>s.replace(/<!--[\s\S]*?-->/g,'').replace(/>\s+</g,'><').replace(/\s{2,}/g,' ').trim()],
['Developer','URL Encoder','Encodes text for use in a URL.',encodeURIComponent],
['Developer','URL Decoder','Decodes a URL-encoded string.',decodeURIComponent],
['Developer','HTML Entity Encoder','Escapes & < > " \'.',s=>s.replace(/[&<>"']/g,c=>ent[c])],
['Developer','HTML Entity Decoder','Decodes common HTML entities.',s=>s.replace(/&(amp|lt|gt|quot|#39);/g,(m,e)=>({amp:'&',lt:'<',gt:'>',quot:'"','#39':"'"}[e]))],
['Developer','Timestamp Converter','Enter a Unix timestamp (seconds) or a date like 2026-01-31 10:00.',s=>{s=s.trim();if(/^\d+$/.test(s))return new Date(+s*1e3).toISOString();const t=Date.parse(s);if(isNaN(t))throw Error('Unrecognized date.');return 'Unix: '+Math.floor(t/1e3)}],
['Links','URL Validator','Enter a full URL including https://.',s=>{const u=new URL(s.trim());if(!/^https?:$/.test(u.protocol))throw Error('Only http/https allowed.');return 'Valid URL: '+u.href}],
['Links','URL Information Extractor','Shows the parts of a URL.',s=>{const u=new URL(s.trim());return ['Protocol: '+u.protocol,'Host: '+u.host,'Path: '+u.pathname,'Query: '+u.search,'Hash: '+u.hash].join('\n')}],
['Links','Email Link Generator','Format: email | subject | body',s=>{const[a,b='',c='']=parts(s);if(!/^\S+@\S+\.\S+$/.test(a))throw Error('Invalid email.');return `mailto:${a}?subject=${encodeURIComponent(b)}&body=${encodeURIComponent(c)}`}],
['Links','Telephone Link Generator','Enter a phone number.',s=>{const n=s.replace(/[^\d+]/g,'');if(n.replace(/\D/g,'').length<6)throw Error('Enter a valid phone number.');return 'tel:'+n}],
['Links','WhatsApp Chat Link Generator','Format: number with country code | message',s=>{const[a,b='']=parts(s),n=a.replace(/\D/g,'');if(n.length<8)throw Error('Include country code, digits only.');return `https://wa.me/${n}?text=${encodeURIComponent(b)}`}],
['Calculators','Basic Calculator','Enter an expression e.g. (12+8)*3/4.',s=>{if(!/^[\d+\-*/().%\s^]+$/.test(s))throw Error('Only numbers and + - * / ( ) % ^ allowed.');const r=Function('"use strict";return ('+s.replace(/\^/g,'**')+')')();if(!isFinite(r))throw Error('Result is not finite.');return String(r)}],
['Calculators','Percentage Calculator','Enter percent,total e.g. 15,200.',s=>{const[p,t]=s.split(',').map(Number);if(isNaN(p)||isNaN(t))throw Error('Use: percent,total');return `${p}% of ${t} = ${p*t/100}`}],
['Calculators','BMI Calculator','Enter weight(kg),height(cm) e.g. 70,175.',s=>{const[w,h]=s.split(',').map(Number);if(!(w>0&&h>0))throw Error('Use: kg,cm');const b=w/((h/100)**2);return `BMI: ${b.toFixed(1)} (${b<18.5?'Underweight':b<25?'Normal':b<30?'Overweight':'Obese'}). Not medical advice.`}],
['Calculators','Age Calculator','Enter birth date as YYYY-MM-DD.',s=>{const d=new Date(s.trim()),n=new Date();if(isNaN(d)||d>n)throw Error('Enter a valid past date.');let y=n.getFullYear()-d.getFullYear(),m=n.getMonth()-d.getMonth();if(n.getDate()<d.getDate())m--;if(m<0){y--;m+=12}return `${y} years, ${m} months`}],
['Calculators','Temperature Converter','Enter value and unit e.g. 25 C, 77 F or 300 K.',s=>{const m=/^(-?[\d.]+)\s*([CFK])$/i.exec(s.trim());if(!m)throw Error('Use e.g. 25 C');const v=+m[1],u=m[2].toUpperCase(),c=u=='C'?v:u=='F'?(v-32)*5/9:v-273.15;return `${c.toFixed(2)} C\n${(c*9/5+32).toFixed(2)} F\n${(c+273.15).toFixed(2)} K`}],
['Calculators','Number System Converter','Enter a decimal whole number.',s=>{if(!/^\d+$/.test(s.trim()))throw Error('Enter a non-negative whole number.');const n=BigInt(s.trim());return `Binary: ${n.toString(2)}\nOctal: ${n.toString(8)}\nHex: ${n.toString(16).toUpperCase()}`}],
['Calculators','Dice Simulator','Enter number of dice (1-20).',s=>{const n=num(s||1,20),r=Array.from(rnd(n),x=>x%6+1);return r.join(', ')+'\nTotal: '+r.reduce((a,b)=>a+b)},1],
['Productivity','Digital Clock','Click Run to see your local time.',()=>new Date().toString(),1]
];
const $=i=>document.getElementById(i);let cur=null;
function toast(m){const t=$('toast');t.textContent=m;t.style.display='block';setTimeout(()=>t.style.display='none',1800)}
function grid(f=''){const g=$('grid');g.replaceChildren();T.filter(t=>(t[0]+t[1]).toLowerCase().includes(f.toLowerCase())).forEach(t=>{const b=document.createElement('button');b.className='card';const s=document.createElement('small');s.textContent=t[0];b.append(s,t[1]);b.onclick=()=>open(t);g.append(b)});
 if(!g.children.length)g.textContent='No tools found.'}
function open(t){cur=t;$('grid').hidden=true;$('panel').hidden=false;$('tt').textContent=t[1];$('td').textContent=t[2];$('in').value='';$('out').value='';$('err').textContent='';$('in').focus()}
$('back').onclick=()=>{$('panel').hidden=true;$('grid').hidden=false};
$('run').onclick=async()=>{$('err').textContent='';$('out').value='';const v=$('in').value;if(!cur[4]&&!v.trim()){$('err').textContent='Please enter some input first.';return}
 try{$('out').value=await cur[3](v)}catch(e){$('err').textContent='Error: '+(e.message||'Invalid input.')}};
$('clr').onclick=()=>{$('in').value='';$('out').value='';$('err').textContent=''};
$('cp').onclick=async()=>{if(!$('out').value)return toast('Nothing to copy.');try{await navigator.clipboard.writeText($('out').value);toast('Copied.')}catch{$('out').select();toast('Press Ctrl+C to copy.')}};
$('dl').onclick=()=>{if(!$('out').value)return toast('Nothing to download.');const a=document.createElement('a'),u=URL.createObjectURL(new Blob([$('out').value],{type:'text/plain'}));a.href=u;a.download='result.txt';a.click();URL.revokeObjectURL(u)};
$('q').oninput=e=>{$('panel').hidden=true;$('grid').hidden=false;grid(e.target.value)};
const root=document.documentElement;try{root.dataset.t=localStorage.getItem('t')||''}catch{}
$('theme').onclick=()=>{root.dataset.t=root.dataset.t=='dark'?'':'dark';try{localStorage.setItem('t',root.dataset.t)}catch{}};
function wl(){const u=`https://wa.me/${WA}?text=${encodeURIComponent($('msg').value)}`;$('sup').href=u;$('fab').href=`https://wa.me/${WA}?text=${encodeURIComponent('Hello, I need support.')}`}
$('msg').oninput=wl;wl();$('count').textContent=T.length+' tools available now.';grid();
