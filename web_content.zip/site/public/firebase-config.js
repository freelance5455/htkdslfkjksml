// Firebase Console > Project settings > Your apps (Web) থেকে মান বসান। এগুলো পাবলিক কনফিগ, সিক্রেট নয়।
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.firebasestorage.app",
  appId: "YOUR_APP_ID"
};
export const SITE = { name: "আমার সাইট / MY SITE", owner: "আপনার নাম / YOUR NAME" };
