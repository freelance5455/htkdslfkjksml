const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const R = path.resolve(__dirname, '..'), res = R + '/android/app/src/main/res';
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const fg = fs.readFileSync(R + '/resources/icon-foreground.svg', 'utf8');
  const bg = fs.readFileSync(R + '/resources/icon.svg', 'utf8');
  async function shot(html, w, h, out, transparent) {
    await page.setViewportSize({ width: w, height: h });
    await page.setContent(`<html><body style="margin:0;background:transparent">${html}</body></html>`);
    fs.mkdirSync(path.dirname(out), { recursive: true });
    await page.screenshot({ path: out, omitBackground: !!transparent, clip: { x: 0, y: 0, width: w, height: h } });
  }
  const svgAt = (svg, s) => svg.replace(/width="432" height="432"/, `width="${s}" height="${s}"`);
  const dens = { mdpi: [48, 108], hdpi: [72, 162], xhdpi: [96, 216], xxhdpi: [144, 324], xxxhdpi: [192, 432] };
  for (const [d, [legacy, adaptive]] of Object.entries(dens)) {
    const dir = `${res}/mipmap-${d}`;
    await shot(svgAt(fg, adaptive), adaptive, adaptive, `${dir}/ic_launcher_foreground.png`, true);
    // legacy square (rounded) + round, foreground scaled up a bit (safe zone cropped)
    const comp = (shape) => `<div style="position:relative;width:${legacy}px;height:${legacy}px;overflow:hidden;border-radius:${shape}">${svgAt(bg, legacy)}<div style="position:absolute;left:${-legacy*0.22}px;top:${-legacy*0.22}px;width:${legacy*1.44}px;height:${legacy*1.44}px">${svgAt(fg, legacy*1.44)}</div></div>`;
    await shot(comp(legacy * 0.22 + 'px'), legacy, legacy, `${dir}/ic_launcher.png`, true);
    await shot(comp('50%'), legacy, legacy, `${dir}/ic_launcher_round.png`, true);
  }
  // store / pwa icons
  const full = (s, r) => `<div style="position:relative;width:${s}px;height:${s}px;overflow:hidden;border-radius:${r}">${svgAt(bg, s)}<div style="position:absolute;left:${-s*0.22}px;top:${-s*0.22}px;width:${s*1.44}px;height:${s*1.44}px">${svgAt(fg, s*1.44)}</div></div>`;
  for (const s of [512, 192]) await shot(full(s, (s*0.2)+'px'), s, s, `${R}/www/icons/icon-${s}.png`, true);
  await shot(full(512, '0'), 512, 512, `${R}/resources/icon-512-playstore.png`, false);
  await shot(full(512, '0'), 512, 512, `${R}/www/icons/maskable-512.png`, false);
  // splash: solid green + centered logo
  const sizes = {};
  for (const f of fs.readdirSync(res)) if (f.startsWith('drawable') ) { const p = `${res}/${f}/splash.png`; if (fs.existsSync(p)) { const buf = fs.readFileSync(p); sizes[p] = [buf.readUInt32BE(16), buf.readUInt32BE(20)]; } }
  for (const [p, [w, h]] of Object.entries(sizes)) {
    const s = Math.round(Math.min(w, h) * 0.34);
    await shot(`<div style="width:${w}px;height:${h}px;background:#1E7145;display:flex;align-items:center;justify-content:center"><div style="width:${s}px;height:${s}px;border-radius:${s*0.22}px;overflow:hidden;position:relative">${svgAt(bg, s)}<div style="position:absolute;left:${-s*0.22}px;top:${-s*0.22}px;width:${s*1.44}px;height:${s*1.44}px">${svgAt(fg, s*1.44)}</div></div></div>`, w, h, p, false);
  }
  await b.close(); console.log('ok', Object.keys(sizes).length, 'splash');
})();
