No custom icon or splash image assets are included. VoltBuilder will use its default app icon unless you add platform icon resources.
