# Rota — YKS Planlayıcım (PWA)

Bu klasör, Rota'nın Android/tablet ana ekranına kurulabilir web uygulaması paketidir.

## Kurulum için
PWA kurulumu için dosyaların HTTPS kullanan bir web adresinde yayımlanması gerekir. Dosyayı doğrudan `file://` ile açmak, uygulama kurulumu ve çevrimdışı önbelleği etkinleştirmez.

### Kolay yayımlama seçenekleri
1. GitHub hesabı aç ve yeni bir repository oluştur (ör. `rota-yks`).
2. Bu klasördeki dört dosyayı repository'nin ana dizinine yükle.
3. Repository Settings → Pages → Deploy from a branch → `main` ve `/ (root)` seçip kaydet.
4. GitHub Pages bir HTTPS adresi verdiğinde tabletten o adresi Chrome'da aç.
5. Chrome menüsü (⋮) → “Uygulamayı yükle” veya “Ana ekrana ekle” seçeneğine dokun.

## Mevcut işlevler
- Haftalık, yedi sütunlu ders takvimi
- TYT/AYT sınav geri sayımı
- Kronometre ve Pomodoro
- Soru sayacı
- Deneme netleri
- Tarayıcıda yerel kayıt ve JSON yedekleme
- PWA manifest ve service worker önbelleği

## Sınırlar
Bu paket henüz gerçek e-posta/parola üyeliği veya bulut eşitleme sağlamaz. Kayıtlar aynı tarayıcı/cihazdaki yerel depolamada tutulur. Gerçek kullanıcı hesabı ve çoklu cihaz eşitlemesi için kimlik doğrulama servisi ve veritabanı eklenmelidir. GitHub Pages statik barındırmadır; hesap sunucusu değildir.
