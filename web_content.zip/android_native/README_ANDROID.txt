PNG Download کے لیے Android (Native) حصہ
=========================================

index.html اب خود پہچان لیتی ہے کہ APK میں window.AndroidDownloader موجود ہے یا نہیں:
  • موجود ہو  -> تصویر Native کوڈ کے ذریعے گیلری (Pictures/QuadMap) میں محفوظ ہوتی ہے، نام کے ساتھ Success پیغام آتا ہے۔
  • موجود نہ ہو -> عام <a download> استعمال ہوتا ہے (Chrome/براؤزر میں ٹھیک چلتا ہے)۔

اگر آپ Android Studio سے اپنی WebView ایپ بناتے ہیں (APK = Android WebView):
  1. MapDownloadBridge.java کو اپنے package میں کاپی کریں (پہلی لائن میں package کا نام بدلیں)۔
  2. MainActivity_example.java میں  // <<< NEW  والی لائنیں اپنی MainActivity میں ڈالیں:
       - bridge بنانا اور addJavascriptInterface(bridge, "AndroidDownloader")  (نام ہوبہو یہی رکھیں)
       - setDownloadListener(...)
       - onRequestPermissionsResult(...)
  3. AndroidManifest_snippet.xml کی Permission شامل کریں۔
  4. index.html کو app/src/main/assets/ میں رکھیں۔

Android ورژن:
  • Android 10 اور اوپر: MediaStore، کوئی Permission نہیں مانگی جاتی۔
  • Android 9 اور نیچے: WRITE_EXTERNAL_STORAGE کی اجازت پہلی بار پوچھی جاتی ہے؛ اجازت ملتے ہی تصویر خود محفوظ ہو جاتی ہے۔

اہم: اگر آپ کوئی آن لائن "Website to APK" سروس استعمال کرتے ہیں جس میں Java کوڈ بدلا نہیں جا سکتا، تو
یہ Native حصہ شامل نہیں ہو سکتا۔ ایسی صورت میں اس سروس کی Settings میں "File Download / Allow Downloads / Storage Permission"
آن کریں۔ اگر پھر بھی ڈاؤن لوڈ نہ ہو تو ایپ واضح پیغام دیتی ہے اور نیچے والی ہدایت (تصویر دیر تک دبا کر Save) کام کرتی ہے۔
