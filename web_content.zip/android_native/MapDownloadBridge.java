package com.example.quadangle;   // <-- اپنے پروجیکٹ کے package نام سے بدل لیں

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * JavaScript میں اس کا نام: window.AndroidDownloader
 *   savePng(base64, fileName) -> "OK:<نام>" | "PENDING" | "ERR:<وجہ>"
 *
 * Android 10 (API 29) اور اس سے اوپر: MediaStore (کسی Permission کی ضرورت نہیں)
 * Android 9 (API 28) اور اس سے نیچے: WRITE_EXTERNAL_STORAGE Permission + Pictures/QuadMap فولڈر
 * فائل گیلری کی Pictures/QuadMap میں محفوظ ہوتی ہے۔
 */
public class MapDownloadBridge {
    public static final int REQ_STORAGE = 7311;
    private static final String FOLDER = "QuadMap";

    private final Activity activity;
    private final WebView web;
    private byte[] pendingData;
    private String pendingName;

    public MapDownloadBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
    }

    @JavascriptInterface
    public String savePng(String base64, String fileName) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            if (data == null || data.length == 0) return "ERR:تصویر کا ڈیٹا خالی ہے۔";
            String name = cleanName(fileName);

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && !hasLegacyPermission()) {
                pendingData = data;
                pendingName = name;
                activity.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        activity.requestPermissions(
                                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                    }
                });
                return "PENDING";
            }
            return "OK:" + write(data, name);
        } catch (Throwable t) {
            return "ERR:" + describe(t);
        }
    }

    /** MainActivity.onRequestPermissionsResult سے بلائیں۔ True لوٹائے تو یہ کوڈ ہمارا تھا۔ */
    public boolean onPermissionResult(int requestCode, int[] grantResults) {
        if (requestCode != REQ_STORAGE) return false;
        final byte[] data = pendingData;
        final String name = pendingName;
        pendingData = null;
        pendingName = null;
        if (data == null) return true;
        if (grantResults != null && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            try {
                callJs(true, write(data, name));
            } catch (Throwable t) {
                callJs(false, describe(t));
            }
        } else {
            callJs(false, "Storage کی اجازت نہیں دی گئی۔ فون کی Settings > Apps > اس ایپ > Permissions میں اجازت دیں۔");
        }
        return true;
    }

    // ---------------------------------------------------------------- internals

    private boolean hasLegacyPermission() {
        return activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private String write(byte[] data, String name) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return writeMediaStore(data, name);
        return writeLegacy(data, name);
    }

    private String writeMediaStore(byte[] data, String name) throws Exception {
        ContentResolver cr = activity.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + FOLDER);
        v.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new Exception("MediaStore میں فائل نہیں بن سکی۔");
        try {
            OutputStream os = cr.openOutputStream(uri);
            if (os == null) throw new Exception("فائل کھل نہیں سکی۔");
            try { os.write(data); os.flush(); } finally { os.close(); }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            cr.update(uri, done, null, null);
        } catch (Throwable t) {
            try { cr.delete(uri, null, null); } catch (Throwable ignore) { }
            throw t instanceof Exception ? (Exception) t : new Exception(t);
        }
        // اصل نام (اگر Android نے نام میں تبدیلی کی ہو)
        android.database.Cursor c = null;
        try {
            c = cr.query(uri, new String[]{MediaStore.Images.Media.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Throwable ignore) {
        } finally {
            if (c != null) c.close();
        }
        return name;
    }

    @SuppressWarnings("deprecation")
    private String writeLegacy(byte[] data, String name) throws Exception {
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), FOLDER);
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("فولڈر نہیں بن سکا۔");
        File f = new File(dir, name);
        FileOutputStream fos = new FileOutputStream(f);
        try { fos.write(data); fos.flush(); } finally { fos.close(); }
        MediaScannerConnection.scanFile(activity, new String[]{f.getAbsolutePath()}, new String[]{"image/png"}, null);
        return f.getName();
    }

    private void callJs(final boolean ok, final String info) {
        final String js = "window.onNativeSaveResult&&window.onNativeSaveResult("
                + ok + "," + JSONObject.quote(info) + ");";
        web.post(new Runnable() {
            @Override public void run() { web.evaluateJavascript(js, null); }
        });
    }

    private static String cleanName(String n) {
        if (n == null || n.trim().isEmpty()) n = "QuadMap_" + System.currentTimeMillis() + ".png";
        n = n.replaceAll("[^A-Za-z0-9._-]", "_");
        if (!n.toLowerCase().endsWith(".png")) n += ".png";
        return n;
    }

    private static String describe(Throwable t) {
        String m = t.getMessage();
        return (m == null || m.isEmpty()) ? t.getClass().getSimpleName() : m;
    }
}
