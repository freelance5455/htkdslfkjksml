package com.example.quadangle;   // <-- اپنے package نام سے بدلیں

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/**
 * مثال: اپنی موجودہ MainActivity میں صرف وہ لائنیں شامل کریں جن کے ساتھ  // <<< NEW  لکھا ہے۔
 */
public class MainActivity extends Activity {
    private WebView webView;
    private MapDownloadBridge bridge;                               // <<< NEW

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());

        bridge = new MapDownloadBridge(this, webView);              // <<< NEW
        webView.addJavascriptInterface(bridge, "AndroidDownloader"); // <<< NEW (نام نہ بدلیں)

        webView.setDownloadListener(new DownloadListener() {         // <<< NEW (بیک اپ طریقہ)
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                final String name = URLUtil.guessFileName(url, cd, "image/png").replaceAll("\\.bin$", ".png");
                if (url.startsWith("data:")) {
                    int i = url.indexOf(',');
                    if (i > 0) toastResult(bridge.savePng(url.substring(i + 1), name));
                } else if (url.startsWith("blob:")) {
                    String js = "fetch('" + url + "').then(function(r){return r.blob();}).then(function(b){"
                            + "var f=new FileReader();f.onload=function(){AndroidDownloader.savePng(f.result.split(',')[1],'"
                            + name + "');};f.readAsDataURL(b);});";
                    webView.evaluateJavascript(js, null);
                } else {
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType(mime);
                    r.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void toastResult(String r) {
        Toast.makeText(this, r.startsWith("OK:") ? "محفوظ ہو گئی: " + r.substring(3) : r, Toast.LENGTH_LONG).show();
    }

    @Override                                                        // <<< NEW
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        bridge.onPermissionResult(code, results);
    }
}
