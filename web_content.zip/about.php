<?php
session_start(); require_once __DIR__ . '/includes.php';
$pageTitle = 'О проекте'; include __DIR__ . '/header.php';
?>
<section class="page-heading"><div class="eyebrow">О ПРОЕКТЕ</div><h1>Просто начать.<br><span>Легко развивать.</span></h1><p>Это учебный шаблон для тестирования регистрации и авторизации на PHP-хостинге.</p></section>
<div class="panel prose"><h2>Что включено</h2><ul><li>Отдельные страницы и адаптивная вёрстка.</li><li>Регистрация с проверкой формата email и сложности пароля.</li><li>Хранение паролей в виде хешей.</li><li>Авторизация, выход и закрытая страница личного кабинета.</li><li>CSRF-токен для форм.</li></ul><p class="muted">Для настоящего публичного сервиса лучше использовать MySQL, HTTPS, ограничения частоты входа и дополнительные меры защиты.</p></div>
<?php include __DIR__ . '/footer.php'; ?>