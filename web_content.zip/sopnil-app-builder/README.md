# Forge — Simple App Builder (Starter)

A beginner-friendly browser prototype for creating HTML/CSS/JavaScript app projects.

## Included
- Light white-and-blue interface
- File Manager for creating, editing, deleting and uploading project files
- Live Preview
- Design & Photos panel for background image, content image, welcome heading, button text and colors
- Sound Manager for background music and click sound
- App Profile settings for app name, icon and description
- Save project data in the current browser and export a web HTML file
- APK build instructions for wrapping the web project with Capacitor

## Run
Open `index.html` in a modern browser. For best compatibility, use a local static server when testing complex projects.

## Important limitations
This is a front-end starter, not a production APK compiler. It does not build Android APKs on its own. To produce installable APKs, connect a real build pipeline (for example Capacitor + Android Studio or a secure cloud build server). Browser local storage is device/browser-specific; export backups regularly.
