# Quiz Master Hindi

## फोन पर चलाना
1. ZIP को Extract/Unzip करें।
2. `index.html`, `style.css`, और `app.js` एक ही फ़ोल्डर में रखें।
3. `index.html` को किसी ऐसे HTML preview/local server ऐप से खोलें जो JavaScript और localStorage सपोर्ट करता हो। केवल साधारण file preview में कुछ सुविधाएँ काम न भी करें।

## Admin Panel
- होम स्क्रीन पर Admin Panel खोलें।
- डेमो PIN: `1234`
- सवाल जोड़ें, बदलें या हटाएँ।
- सवाल इस ब्राउज़र के localStorage में सेव होते हैं। ब्राउज़र डेटा साफ़ करने से सवाल मिट सकते हैं।
- Export से सवालों का JSON बैकअप लें।

## APK
यह ZIP एक वेब ऐप प्रोजेक्ट है, तैयार APK नहीं। इसे APK बनाने के लिए Android पर समर्थित build service या Android IDE की अतिरिक्त प्रक्रिया चाहिए। Admin PIN `1234` केवल डेमो सुरक्षा है; इसे सार्वजनिक/प्रोडक्शन ऐप के लिए सुरक्षित लॉगिन न मानें।
