-- Runner Short v1.31.02: tabela de autorizações para itens exclusivos.
-- Execute no SQL Editor do SEU projeto Supabase.
create table if not exists public.exclusive_entitlements (
  user_id uuid not null references auth.users(id) on delete cascade,
  item_id text not null check (length(item_id) between 1 and 80),
  granted_at timestamptz not null default now(),
  primary key (user_id, item_id)
);

alter table public.exclusive_entitlements enable row level security;
revoke all on table public.exclusive_entitlements from anon, authenticated;
grant select on table public.exclusive_entitlements to authenticated;

drop policy if exists "Players can read their own exclusive entitlements" on public.exclusive_entitlements;
create policy "Players can read their own exclusive entitlements"
  on public.exclusive_entitlements
  for select
  to authenticated
  using (auth.uid() = user_id);

-- Não crie policies INSERT/UPDATE/DELETE para authenticated ou anon.
-- Conceda itens pelo SQL Editor, após confirmar a conta do vencedor.
-- Exemplo (substitua o e-mail e o ID do item):
-- insert into public.exclusive_entitlements (user_id, item_id)
-- select id, 'orbital_slayer'
-- from auth.users
-- where lower(email) = lower('amigo@exemplo.com')
-- on conflict (user_id, item_id) do nothing;
