BIXI UI polish
- Removed the top BIXI wordmark/header title and duplicate top home heading.
- Kept navigation only at the bottom and made all items smaller and consistent.
- Changed notifications icon to a bell.
- Removed the “هذا بالضبط ما سيعرضه تطبيقك” footer text.
- Double-tap Home scrolls back to the top.
- Pull down from the top reveals a reset prompt; tap it to reset.
- Added image/video selection and local preview in Create.
Note: this is a front-end preview. Real posting, storage, accounts, notifications, and AI need backend integration.
