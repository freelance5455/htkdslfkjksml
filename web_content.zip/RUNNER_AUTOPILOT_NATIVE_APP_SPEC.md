# Runner Autopilot --- Android APK App-Builder Specification

## Project goal

Build an Android app called **Runner Autopilot** that can observe an
endless-runner game on the same Android phone, detect upcoming obstacles
from the screen, choose an action, and perform supported taps/swipes
through Android accessibility gestures.

The first goal is a working prototype for **one runner game**, with a
configurable detection system that can later be adapted to other endless
runners. Do not claim that the first version will work perfectly with
every game.

**Development constraints** - Phone-first workflow; the user may not
have access to a PC. - Deliver an installable Android APK, plus
source/project files if the builder supports them. - Internet may be
used, but the core MVP should not require cloud AI. - User will
explicitly grant screen-capture and accessibility permissions when
Android requests them. - Do not request root access. - Do not bypass
game security, anti-cheat, or access controls.

## Reference project supplied by the user

The uploaded `Coin Runner Autopilot.html` is a small HTML canvas runner
game. It already includes: - Three fixed lanes. - Game objects with
known lane and vertical position. - A `think()` function that scores
lanes, penalizes barriers, and rewards coins. - An autopilot that
changes the target lane. - Manual swipe/arrow controls, restart, coin
count, distance, and best distance.

This is useful as a reference for decision logic and for a demo/test
mode. It is **not** an external-game bot yet: its current autopilot
reads objects directly from its own JavaScript game state. The Android
app must not assume it can access another game's internal objects.

## Required architecture

### 1. Android screen capture

-   Use Android's official MediaProjection screen-capture flow.
-   Explain why capture is needed and request permission through the
    system dialog.
-   Process frames locally when possible; avoid storing or uploading
    screenshots by default.
-   Handle permission denial, capture termination, screen rotation,
    resolution changes, and app switching gracefully.

### 2. Visual detection

Build a replaceable detection module with two levels:

**MVP (recommended):** - Use image processing / computer vision where
practical (for example, OpenCV or native Android image operations). -
Let the user select the play area and calibrate the player location,
obstacle regions, and safe/unsafe visual cues. - Support simple
configurable rules such as: - Detect an obstacle entering a defined
region. - Estimate its movement direction/speed from successive
frames. - Estimate time-to-contact. - Detect a lane or gap when the game
layout makes that possible. - Include a debug overlay showing detected
regions and the reason for each action.

**Later extension:** - Optional on-device vision model or remote model
adapter. - Do not send every frame to an LLM. Use deterministic
vision/rules for time-critical actions; call an AI model only when
useful. - Any model integration must be optional, with a clear offline
mode and error handling.

Do not claim universal recognition of arbitrary game graphics. Each game
may require calibration or a game-specific detector.

### 3. Decision engine

Create a game-independent interface, for example:

-   `observe(frame, calibration) -> scene`
-   `decide(scene, settings) -> action`
-   `execute(action)`

Actions should include only controls relevant to the configured game: -
tap / short press - hold for a bounded duration, if supported - swipe in
a selected direction - wait / no-op - stop automation

For the first runner profile, prioritize simple rules and short
prediction horizons. Add adjustable reaction lead time, action cooldown,
and a safe maximum action rate. Include a manual stop button that
remains easy to reach.

### 4. Android action controller

-   Use an Android Accessibility Service with supported gesture dispatch
    (for example, `dispatchGesture`) where applicable.
-   Clearly guide the user through enabling the service in Android
    Settings.
-   Never hide the service, start controlling games without an explicit
    user action, or make the stop control difficult to reach.
-   Explain that gesture support can vary by Android version, app, and
    game.
-   If the selected builder cannot implement a real Accessibility
    Service or MediaProjection, it must say so. Do not fake these
    features with a web page or a normal auto-clicker.

### 5. User interface

Build a simple, mobile-friendly UI with: - **Start capture** button. -
**Calibrate game** flow. - **Start autopilot** and **Stop** buttons. -
Selected game profile and control mapping. - Sensitivity / reaction lead
/ cooldown settings. - Debug overlay toggle. - Status messages:
permission needed, calibrating, detecting, acting, paused, unsupported
screen, capture stopped, error. - A prominent stop control while
automation is active.

### 6. Profiles and compatibility

-   Ship with a demo profile based on the supplied Coin Runner concept
    to test decision logic.
-   Add a configurable generic runner profile.
-   Allow saving a calibration/profile locally.
-   Do not label a game "supported" until it has been tested on that
    game.
-   If a game cannot be detected reliably, pause and ask the user to
    recalibrate rather than tapping randomly.

## Important technical limitations

1.  **Any endless runner is an ambitious long-term goal, not a
    guaranteed first-release feature.** Games differ in camera angle,
    graphics, physics, controls, lane layouts, obstacle types, and UI.
2.  The provided HTML autopilot reads game state directly. An external
    game requires visual inference from screen frames and has less
    reliable information.
3.  Small LLMs are often too slow or inconsistent for frame-by-frame
    timing. Prefer local computer vision plus rules for fast reactions.
4.  Android screen capture and accessibility gestures require
    user-granted permissions and may behave differently across devices
    and apps.
5.  Some games may restrict overlays, capture, or automation. Do not
    bypass protections or anti-cheat.
6.  A phone-only app builder may not support native MediaProjection or
    AccessibilityService code. Verify these capabilities **before**
    building the UI. If not supported, choose a builder that can include
    native Android code or a project export that another tool can
    compile.
7.  Do not promise a successful APK until it has been built and tested
    on a real Android device.

## Recommended build order

### Phase 1 --- validate the builder

Before creating the full app, confirm the chosen tool can produce an
Android APK and implement: - MediaProjection screen capture -
AccessibilityService gesture dispatch - Android permission/settings
flow - Local image processing

If any are unsupported, stop and recommend a suitable alternative
instead of producing a fake prototype.

### Phase 2 --- test with the supplied demo

Use the existing Coin Runner HTML as a controlled demo. First validate
the decision engine in the original game. Then, if possible, display the
demo on the phone and test the capture/detection/action pipeline against
it.

### Phase 3 --- one real runner

Choose one installed runner game. Calibrate player area, obstacle
region, action mapping, and reaction lead. Test slowly, show the debug
overlay, and log only local diagnostic summaries by default.

### Phase 4 --- expand cautiously

Add additional game profiles one at a time. Track tested compatibility,
known limitations, and settings for each game.

## Acceptance criteria for the first prototype

The prototype is acceptable only if: - It installs and launches on
Android without root. - Screen capture permission is requested through
the official Android prompt. - Accessibility permission is requested
transparently and can be disabled in Android Settings. - The user can
select/calibrate the play region and control mapping. - It displays what
it detects and why it is acting. - Start and Stop work reliably;
stopping prevents further gestures. - It can demonstrate obstacle-aware
actions in the supplied demo or one explicitly tested runner. - It
pauses on uncertain detection rather than continuously issuing blind
taps. - It does not claim to support every game unless that has been
demonstrated. - The builder supplies the APK and, if possible,
source/project files and build instructions.

## Instructions to the app builder

First inspect this specification and identify whether your platform can
implement native Android MediaProjection and AccessibilityService. State
any blockers before generating code. Then create the smallest testable
APK, not a large polished app. Prioritize real screen capture,
transparent permissions, safe stop controls, and a working single-game
demo. Do not substitute simulated capture or fake tap actions for actual
Android functionality.

## Suggested short prompt to paste into an AI app builder

Build an Android APK named Runner Autopilot from this specification. It
should capture the current screen only after the user grants Android's
MediaProjection permission, detect obstacles using configurable local
computer vision/rules, and perform supported taps/swipes through a
transparent Accessibility Service. Use my uploaded Coin Runner Autopilot
HTML as a reference for the lane-scoring decision logic, but do not
assume its internal JavaScript game state is accessible in other games.
Start with one configurable endless runner and a demo profile; do not
promise universal compatibility. Include calibration, a visible
Start/Stop control, debug overlays, local settings, and clear
permission/error messages. No root, no hidden actions, and no bypassing
anti-cheat. Before coding, confirm that the builder can implement
MediaProjection and AccessibilityService and deliver a real installable
APK. If it cannot, explain the limitation and recommend a tool that can.
