SYASYA KIDSWEAR - NETLIFY PWA

CARA PUBLISH:
1. Ekstrak ZIP ini di komputer atau HP.
2. Login / daftar di https://app.netlify.com/drop
3. Seret folder hasil ekstrak (folder yang berisi index.html, netlify.toml, manifest.webmanifest, dan sw.js) ke area deploy Netlify Drop.
4. Tunggu deploy selesai. Netlify akan memberi URL publik.
5. Buka URL tersebut di Chrome Android. Pilih tombol Instal bila tersedia, atau menu browser > Tambahkan ke layar utama.

ISI:
- Aplikasi kasir SYASYA KIDSWEAR
- Manifest PWA dan service worker untuk cache/offline shell
- Logo toko
- Konfigurasi Netlify

CATATAN PENTING:
- ZIP ini adalah paket website siap deploy, bukan APK Android.
- Setelah deploy, situs dapat dibuka dengan URL Netlify. Untuk install seperti aplikasi, gunakan Tambahkan ke layar utama.
- Data penjualan disimpan di localStorage browser/perangkat. Data TIDAK otomatis tersinkron antar HP/komputer, dan bisa hilang jika data browser dihapus.
- Lakukan ekspor/cadangan JSON berkala. Pembayaran digital hanya dicatat sebagai metode; tidak ada pemrosesan pembayaran otomatis.
- Untuk penggunaan multi-kasir atau data pelanggan/penjualan penting, diperlukan database dan autentikasi backend.
