import { jsxDEV } from "react/jsx-dev-runtime";
import { useEffect, useState } from "react";
function beep() {
  try {
    const C = window.AudioContext || window.webkitAudioContext;
    const ctx = new C();
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = "sine";
    o.frequency.value = 880;
    g.gain.value = 0.12;
    o.connect(g);
    g.connect(ctx.destination);
    o.start();
    o.stop(ctx.currentTime + 0.35);
    o.onended = () => ctx.close();
  } catch {
  }
}
function Timer({ exercise, lang, t, onClose }) {
  const saved = (() => {
    try {
      return JSON.parse(localStorage.getItem("iron-timer") || "{}");
    } catch {
      return {};
    }
  })();
  const [duration, setDuration] = useState(Number(saved.duration) || 60), [sets, setSets] = useState(Number(saved.sets) || 3), [custom, setCustom] = useState(""), [left, setLeft] = useState(Number(saved.duration) || 60), [running, setRunning] = useState(false), [deadline, setDeadline] = useState(null), [phase, setPhase] = useState("rest"), [completed, setCompleted] = useState(0), [up, setUp] = useState(false);
  useEffect(() => {
    localStorage.setItem("iron-timer", JSON.stringify({ duration, sets }));
  }, [duration, sets]);
  useEffect(() => {
    if (!running || deadline === null) return;
    const tick = () => {
      const n = Math.max(0, Math.ceil((deadline - Date.now()) / 1e3));
      setLeft(n);
      if (n === 0) {
        if (phase === "rest") {
          beep();
          setUp(true);
          window.setTimeout(() => setUp(false), 2500);
          const done = completed + 1;
          setCompleted(done);
          if (done < sets) {
            setPhase("transition");
            setDeadline(Date.now() + 15e3);
          } else {
            setRunning(false);
            setDeadline(null);
          }
        } else {
          setPhase("rest");
          setDeadline(Date.now() + duration * 1e3);
          setLeft(duration);
        }
      }
    };
    tick();
    const id = window.setInterval(tick, 200);
    return () => clearInterval(id);
  }, [running, deadline, phase, completed, sets, duration]);
  const start = () => {
    const remain = left > 0 ? left : duration;
    setLeft(remain);
    setPhase("rest");
    setDeadline(Date.now() + remain * 1e3);
    setRunning(true);
    setUp(false);
  };
  const pause = () => {
    if (deadline) setLeft(Math.max(0, Math.ceil((deadline - Date.now()) / 1e3)));
    setRunning(false);
    setDeadline(null);
  };
  const reset = () => {
    setRunning(false);
    setDeadline(null);
    setPhase("rest");
    setCompleted(0);
    setLeft(duration);
    setUp(false);
  };
  const pick = (n) => {
    setDuration(n);
    setLeft(n);
    setRunning(false);
    setDeadline(null);
    setPhase("rest");
    setCompleted(0);
  };
  const display = String(Math.floor(left / 60)).padStart(2, "0") + ":" + String(left % 60).padStart(2, "0");
  return /* @__PURE__ */ jsxDEV("div", { className: "modal-backdrop", onClick: onClose, children: /* @__PURE__ */ jsxDEV("section", { className: "timer-modal", role: "dialog", "aria-modal": "true", "aria-label": t.timer, dir: lang === "fa" ? "rtl" : "ltr", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "timer-head", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { children: t.timer }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2,
          columnNumber: 2143
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "timer-exercise", children: exercise }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2,
          columnNumber: 2161
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 2,
        columnNumber: 2138
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "close-btn", onClick: onClose, "aria-label": t.close, children: "\xD7" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 2,
        columnNumber: 2211
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 2,
      columnNumber: 2110
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "timer-digits", "aria-live": "polite", children: display }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 2,
      columnNumber: 2296
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "timer-status " + (up ? "flash" : ""), children: up ? t.timesUp : running && phase === "transition" ? t.transition + " " + left + " " + t.seconds : running ? t.setOf + " " + Math.min(completed + 1, sets) + " " + (lang === "fa" ? "\u0627\u0632" : "of") + " " + sets : t.ready }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 2,
      columnNumber: 2360
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "timer-presets", children: [30, 45, 60, 90, 120].map((n) => /* @__PURE__ */ jsxDEV("button", { className: "preset " + (duration === n ? "active" : ""), onClick: () => pick(n), children: [
      n,
      "s"
    ] }, n, true, {
      fileName: "<stdin>",
      lineNumber: 2,
      columnNumber: 2644
    }, this)) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 2,
      columnNumber: 2587
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "custom-time", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "custom-seconds", children: t.custom }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 2,
        columnNumber: 2781
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "custom-seconds", type: "number", min: "1", max: "3600", value: custom, onChange: (e) => setCustom(e.target.value), onKeyDown: (e) => {
        if (e.key === "Enter" && Number(custom) > 0) pick(Number(custom));
      } }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 2,
        columnNumber: 2831
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "small-btn", onClick: () => Number(custom) > 0 && pick(Number(custom)), children: "\u2713" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 2,
        columnNumber: 3022
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 2,
      columnNumber: 2752
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "set-row", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "set-count", children: t.customSets }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 2,
        columnNumber: 3146
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "set-count", type: "number", min: "1", max: "20", value: sets, onChange: (e) => {
        const n = Math.max(1, Math.min(20, Number(e.target.value) || 1));
        setSets(n);
        setCompleted(0);
      } }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 2,
        columnNumber: 3195
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 2,
      columnNumber: 3121
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "timer-actions", children: [
      /* @__PURE__ */ jsxDEV("button", { className: "primary-btn", onClick: running ? pause : start, children: running ? t.pause : left < duration ? t.resume : t.start }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 2,
        columnNumber: 3401
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "ghost-btn", onClick: reset, children: t.resetTimer }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 2,
        columnNumber: 3522
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 2,
      columnNumber: 3370
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "modal-note", children: [
      t.transition,
      " \xB7 15 ",
      t.seconds
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 2,
      columnNumber: 3597
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 2,
    columnNumber: 1961
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 2,
    columnNumber: 1911
  }, this);
}
export {
  Timer as default
};
