# MAYRA COMPLETE — Web + Android

This package contains the Android project plus a web UI under `web/` with `index.html`, `style.css`, and `app.js`.

The web version is a local browser companion demo. The Android project is the build target for an APK/AAB. A real online AI backend is still required for open-ended cloud AI conversations.
