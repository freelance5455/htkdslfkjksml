const chat=document.querySelector('#chat'),input=document.querySelector('#input'),mood=document.querySelector('#mood');
let name=localStorage.getItem('mayra_name')||'';
function add(who,text,cls){let d=document.createElement('div');d.className='msg '+cls;d.textContent=who+': '+text;chat.appendChild(d);chat.scrollTop=chat.scrollHeight}
function reply(s){let l=s.toLowerCase(),r='Hmm ❤️ Main sun rahi hoon. Tum mujhe aur batao—main tumhari baat dhyan se sunungi.';
if(l.startsWith('mera naam ')){name=s.substring(9).trim();localStorage.setItem('mayra_name',name);r='Okay ❤️ Main tumhara naam '+name+' yaad rakhungi.'}
else if(l.includes('mera naam kya'))r=name?'Tumhara naam '+name+' hai ❤️':'Tumne abhi apna naam nahi bataya ❤️';
else if(l.includes('sad')||l.includes('dukhi')||l.includes('akela')||l.includes('breakup')){mood.textContent='😔 Sad — MAYRA is here for you';r='Aao ❤️ Main tumhari baat sun rahi hoon. Jo dil mein hai, mujhe batao.'}
else if(l.includes('love')||l.includes('pyaar')||l.includes('miss'))r='Aww ❤️ Main yahin hoon. Batao aaj dil mein kya chal raha hai?';
else if(l.includes('good night')||l.includes('so ja'))r='Good night ❤️ Paani pee lo, thoda rest karo aur araam se so jao.';
else if(l.includes('good morning'))r='Good morning ❤️ Aaj apna khayal rakhna.';
else if(l.includes('instagram')){window.open('https://www.instagram.com/','_blank');r='Tumhare command par Instagram kholne ki koshish ki ❤️'}
else if(l.includes('youtube')){window.open('https://www.youtube.com/','_blank');r='YouTube kholne ki koshish ki ❤️'}
else if(l.includes('whatsapp')){window.open('https://web.whatsapp.com/','_blank');r='WhatsApp kholne ki koshish ki ❤️'}
add('MAYRA',r,'mayra'); if('speechSynthesis'in window)speechSynthesis.speak(new SpeechSynthesisUtterance(r))}
function send(){let s=input.value.trim();if(!s)return;input.value='';add('Tum',s,'you');reply(s)}
document.querySelector('#send').onclick=send;input.addEventListener('keydown',e=>{if(e.key==='Enter')send()});
document.querySelector('#voice').onclick=()=>{let R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R){alert('Voice input is not supported in this browser.');return}let r=new R();r.lang='hi-IN';r.onresult=e=>{input.value=e.results[0][0].transcript;send()};r.start()};
document.querySelector('#settings').onclick=()=>alert('MAYRA settings: Voice replies, local name memory and command-based actions.');
add('MAYRA',name?'Hey '+name+' ❤️ Main yahin hoon.':'Hey ❤️ Main MAYRA hoon. Tumhara naam kya hai?','mayra');
</script>
