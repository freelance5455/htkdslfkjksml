// Oyunun istifadə etdiyi kitabxanaları internetsiz işləsin deyə www/lib qovluğuna kopyalayır
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), out = path.join(root, 'www', 'lib');
fs.mkdirSync(out, { recursive: true });
const files = [
  ['three/build/three.min.js', 'three.min.js'],
  ['three/examples/js/loaders/FBXLoader.js', 'FBXLoader.js'],
  ['three/examples/js/libs/fflate.min.js', 'fflate.min.js'],
  ['peerjs/dist/peerjs.min.js', 'peerjs.min.js']
];
for (const [src, dst] of files) {
  const from = path.join(root, 'node_modules', src);
  if (!fs.existsSync(from)) { console.error('TAPILMADI: ' + from + '  (əvvəl "npm install" işlət)'); process.exit(1); }
  fs.copyFileSync(from, path.join(out, dst)); console.log('OK  ' + dst);
}
