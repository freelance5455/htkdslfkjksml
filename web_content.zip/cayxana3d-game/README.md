# Çayxana 3D — quraşdırılan oyun (Android · Windows · Mac · iPhone)

Bu qovluq oyunu brauzersiz, öz ikonu olan həqiqi tətbiqə çevirir.
Oyun faylı: `www/index.html`. Kitabxanalar (three.js və s.) build zamanı oyunun içinə qoyulur, ona görə tətbiq internetsiz də açılır
(yalnız onlayn dostlarla oynamaq üçün internet lazımdır).

## Ən asan yol: GitHub hər şeyi özü qurur (pulsuz, heç nə quraşdırmaq lazım deyil)
1. github.com-da hesab aç və yeni repo yarat (məsələn `cayxana3d`).
2. Bu qovluğun içindəkiləri repoya yüklə: **Add file → Upload files**. `.github` qovluğu da daxil olmalıdır.
3. Repoda **Actions** tabına keç → **Build** → **Run workflow**.
4. 5–15 dəqiqə sonra işin içindəki **Artifacts** bölməsindən yüklə:
   - `Cayxana3D-Android` → `app-debug.apk` (telefonda aç, "naməlum mənbədən quraşdırma"ya icazə ver)
   - `Cayxana3D-Windows` → `Çayxana 3D Setup.exe` (quraşdırıcı) və portable `.exe`
   - `Cayxana3D-Mac` → `.dmg` (imzasızdır: sağ klik → Open)

## Kompüterdə özün qurmaq (Node.js 20 lazımdır)
```
npm install
npm start            # oyunu proqram kimi test et
npm run build:win    # dist/ qovluğunda .exe
npm run build:mac    # Mac-də
npm run build:linux
```
Tam ekran: F11. Mahnı proqramda dərhal çalır.

## Android (özün)
```
npm install && npm run libs
npx cap add android && npx cap sync android
npx cap open android   # Android Studio → Run / Build APK
```

## iPhone / iPad (yalnız Mac + Xcode ilə)
```
npm install && npm run libs
npx cap add ios && npx cap sync ios
npx cap open ios       # Xcode → öz Apple ID-ni seç → telefonda Run
```
Apple siyasətinə görə iPhone-a quraşdırmaq üçün Mac və Apple hesabı lazımdır. Pulsuz hesabla tətbiq 7 gün işləyir, ildə 99$ Apple Developer hesabı ilə
isə TestFlight/App Store-a çıxarmaq olar. Windows və ya Android-də iOS tətbiqi qurmaq mümkün deyil.

## Qeyd
- Oyunda dəyişiklik edəndə `www/index.html`-i əvəz et və yenidən build et.
- Android APK "debug" imzalıdır: telefonda quraşdırmaq üçün yetərlidir. Google Play üçün release imzası lazımdır.
