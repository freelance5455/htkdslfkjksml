SH. USMAN SCHOOL — ANDROID APP PROJECT

Mashruucan wuxuu ku duubayaa website-ka V13 gudaha Android WebView si loogu dhiso APK.

SIDA APK LOOGA DHISO:
1. Fur mashruuca Android Studio (waxaa loo baahan yahay kombiyuutar leh Android Studio).
2. Dooro Open, kadibna dooro folder-ka ShUsmanSchoolApp (folder-ka mashruuca oo dhan).
3. Sug Gradle Sync iyo in Android Studio soo dejiyo qalabka loo baahan yahay.
4. Dooro Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK-ga waxaa laga heli karaa app/build/outputs/apk/debug/app-debug.apk.

WAXYAABAHA KU JIRA:
- app/src/main/assets/index.html: website-ka V13.
- Java WebView wrapper: JavaScript, localStorage iyo file chooser waa la taageeray.

MUHIIM:
- Tani waa Android Studio source project, ma aha APK diyaar ah.
- Website-ku wuxuu isticmaalaa localStorage; xogtu waxay ku kaydsan tahay qalabka/app-kaas. Ma jiro database online ama isku-xir xog qalabyo kala duwan.
- Sawirrada la geliyo waxay ku xiran yihiin habka website-ku u kaydiyo; ha u qaadan in dhammaan xogta si toos ah cloud ugu kaydsan tahay.
- Si loo helo APK la rakibi karo, mashruuca waa in la build-gareeyaa.
