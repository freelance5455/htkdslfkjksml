const express = require('express');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 4242);
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || '';
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || '';
const MODE = process.env.GMM_MODE || 'live';

app.use(cors());

const transactions = new Map();
function id(prefix='txn') { return `${prefix}_${crypto.randomBytes(8).toString('hex')}`; }
function stripeClient() {
  if (!STRIPE_SECRET_KEY) throw new Error('STRIPE_SECRET_KEY is not configured');
  const Stripe = require('stripe');
  return new Stripe(STRIPE_SECRET_KEY);
}

app.get('/health', (req,res) => res.json({
  ok:true,
  service:'GET MONEY MACHINE Stripe backend',
  mode:MODE,
  stripe_configured:Boolean(STRIPE_SECRET_KEY),
  stripe_live_key:STRIPE_SECRET_KEY.startsWith('sk_live_')
}));


const SCANNERS = [
  'Free-Money','Unclaimed Property','Refund','Rebate','Cashback','Rewards','Promotional Bonus',
  'Fee-Recovery','Overpayment','Subscription-Credit','Settlement/Claim','Business Incentive',
  'Public Opportunity','Revenue Opportunity','Reinvestment Engine'
];

app.get('/opportunities/sources', (req,res) => {
  res.json({ok:true, sources:SCANNERS.map((name,i)=>({scanner_id:i+1,name,status:'READY'}))});
});

app.post('/opportunities/scan', (req,res) => {
  const enabled=Array.isArray(req.body?.enabled)?req.body.enabled:[];
  const scanners=SCANNERS.map((name,i)=>({
    id:i+1,name,
    status:enabled.some(x=>Number(x.id)===i+1)?'IDLE':'DISABLED',
    results:0,eligible:0,error:0
  }));
  res.json({ok:true,opportunities:[],opportunities_count:0,scanners});
});

app.get('/payments/status', (req,res) => res.json({count:transactions.size, mode:MODE}));

app.get('/payments/:id/status', async (req,res) => {
  const tx=transactions.get(req.params.id);
  if(!tx) return res.status(404).json({error:'transaction_not_found'});
  try {
    if (tx.stripe_session_id) {
      const stripe=stripeClient();
      const session=await stripe.checkout.sessions.retrieve(tx.stripe_session_id);
      if(session.payment_status==='paid') tx.status='SETTLED';
      else if(session.status==='expired') tx.status='CANCELLED';
      else tx.status='PENDING';
      tx.stripe_payment_status=session.payment_status;
      tx.stripe_session_status=session.status;
      tx.updated_at=new Date().toISOString();
    }
    res.json(tx);
  } catch(e) {
    res.status(502).json({error:'stripe_status_failed',message:e.message});
  }
});

// Stripe signs webhook payloads against the raw request body.
app.post('/stripe/webhook', express.raw({type:'application/json'}), (req,res) => {
  if(!STRIPE_WEBHOOK_SECRET) return res.status(503).json({error:'webhook_not_configured'});
  const signature=req.headers['stripe-signature'];
  let event;
  try {
    const stripe=stripeClient();
    event=stripe.webhooks.constructEvent(req.body,signature,STRIPE_WEBHOOK_SECRET);
  } catch(e) {
    return res.status(400).json({error:'invalid_webhook_signature'});
  }
  const session=event.data?.object;
  const transaction_id=session?.metadata?.gmm_transaction_id;
  if(transaction_id && transactions.has(transaction_id)) {
    const tx=transactions.get(transaction_id);
    if(event.type==='checkout.session.completed' || event.type==='checkout.session.async_payment_succeeded') tx.status='SETTLED';
    if(event.type==='checkout.session.async_payment_failed') tx.status='FAILED';
    tx.updated_at=new Date().toISOString();
    tx.stripe_event_type=event.type;
  }
  res.json({received:true});
});

app.use(express.json());

app.post('/payments/create', async (req,res) => {
  const amount=Number(req.body?.amount);
  const currency=String(req.body?.currency||'usd').toLowerCase();
  const description=String(req.body?.description||'GET MONEY MACHINE payment');
  if(!Number.isFinite(amount)||amount<=0) return res.status(400).json({error:'invalid_amount'});
  if(!STRIPE_SECRET_KEY) return res.status(503).json({error:'stripe_not_configured',message:'Configure STRIPE_SECRET_KEY on the secure backend.'});
  if(MODE !== 'live' || !STRIPE_SECRET_KEY.startsWith('sk_live_')) {
    return res.status(503).json({error:'live_mode_required',message:'This build is configured for live Stripe and requires an sk_live_ secret key.'});
  }
  try {
    const stripe=stripeClient();
    const transaction_id=id();
    const session=await stripe.checkout.sessions.create({
      mode:'payment',
      line_items:[{price_data:{currency,product_data:{name:description},unit_amount:Math.round(amount*100)},quantity:1}],
      success_url: process.env.STRIPE_SUCCESS_URL || 'https://example.com/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: process.env.STRIPE_CANCEL_URL || 'https://example.com/cancel',
      metadata:{gmm_transaction_id:transaction_id}
    });
    const tx={transaction_id,status:'PENDING',amount,currency,description,created_at:new Date().toISOString(),stripe_session_id:session.id,mode:'live'};
    transactions.set(transaction_id,tx);
    res.status(201).json({transaction_id,status:tx.status,checkout_url:session.url});
  } catch(e) {
    res.status(502).json({error:'stripe_request_failed',message:e.message});
  }
});

app.listen(PORT,()=>console.log(`GET MONEY MACHINE Stripe backend listening on ${PORT} (${MODE})`));
