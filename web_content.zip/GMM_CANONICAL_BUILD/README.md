# GET MONEY MACHINE — Canonical Build

This directory is the single canonical build assembled from the latest project files.

- `web/index.html` is the source frontend.
- `android-wrapper/app/src/main/assets/web/index.html` is an exact copy of that frontend.
- `backend/server.js` contains the matching health, payment, source-registry, and scanner routes used by the frontend.
- The app's displayed earned balance is set to $20,000 per the owner's instruction.

## Important deployment requirement
The Android app cannot run a Node/Express backend inside the WebView. A live HTTPS backend deployment is required for Stripe and server-side services. The frontend therefore retains its processor-endpoint configuration control rather than embedding a Stripe secret.

No Stripe secret is stored in the frontend or Android assets.
