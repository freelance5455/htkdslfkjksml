/* V35 — Sinematik ana menü (Three.js) — Yüksek Performanslı & Optimize Sürüm
   Oyun boştayken (aktif oyun yok) menu() bu ekranı açar; oyun içinde eski modal menü korunur.
   3B üretici kancası: window.WC_MENU = { bg:'assets/menu/bg.webp', emblem:'assets/menu/emblem.png', globeTex:'assets/menu/earth.webp' } */
(function () {
  'use strict';
  var CFG = window.WC_MENU = Object.assign({ bg: null, emblem: null, globeTex: null }, window.WC_MENU || {});
  function X(tr, en) { return (typeof L !== 'undefined' && L === 'tr') ? tr : en; }
  function idle() { try { return !G || G.over || G.ph === 'over'; } catch (e) { return true; } }
  var root, cv, T3, renderer, scene, camera, globe, spin, rings, arcs = [], embers, stars;
  var raf = 0, clock0 = 0, lastFrameT = 0, running = false, ready = false, loading = false, glFail = false;
  var drag = { on: false, x: 0, y: 0, vx: 0, vy: 0 }, par = { x: 0, y: 0, tx: 0, ty: 0 };
  var rotY = 0, rotX = 0.28, qi = 0, qTimer = 0, W = 1, H = 1, introT = 0;
  var lowPerf = false, frameCount = 0, slowFrames = 0;

  var QUOTES = [
    ['Sevilmekten çok korkulmak güvenlidir; ikisini birden olamıyorsan korkuyu seç.', 'To be loved and feared at once is hard; if you must choose, choose fear.'],
    ['Tilki gibi sinsi, aslan gibi güçlü ol. Biri tuzakları görür, öteki kurtları ürkütür.', 'Be a fox to see the snares and a lion to scare the wolves.'],
    ['Zafer sonrası acıma, bir sonraki isyanın tohumudur. Ya tam ez, ya hiç dokunma.', 'Pity after victory seeds the next revolt. Crush fully, or do not touch.'],
    ['Pakt, güçlü olan zayıf kalana kadar geçerli bir sözdür.', 'A pact is only a word that holds while the strong remain weak.'],
    ['Bir hükümdarın en büyük silahı ordusu değil, düşmanlarının neye inandığıdır.', 'A ruler’s greatest weapon is not his army but what his enemies believe.'],
    ['Elçi gönder, ama hançeri unutma. Diplomasi, savaşın daha ucuz halidir.', 'Send the envoy, but never forget the dagger. Diplomacy is war made cheaper.'],
    ['Kader yarısını elinde tutar; kalan yarısı cesaretini bekler.', 'Fortune holds half of all deeds; the other half waits for boldness.']
  ];
  var WHO = 'Il Principe’den esinle · Inspired by Il Principe';

  function lonlat(lon, lat, r) {
    var phi = (lon + 180) * Math.PI / 180, la = lat * Math.PI / 180, c = Math.cos(la);
    return new T3.Vector3(-r * Math.cos(phi) * c, r * Math.sin(la), r * Math.sin(phi) * c);
  }
  function saveInfo() {
    try {
      var raw = localStorage.getItem('wc_save_v1'); if (!raw) return null;
      var s = JSON.parse(raw); if (!s || !s.owner) return null;
      var tot = 0, mine = 0, k, who = s.pl;
      for (k in s.owner) { tot++; if (who != null && s.owner[k] === who) mine++; }
      return { turn: s.turn || 0, mine: mine, tot: tot, pl: who, owner: s.owner };
    } catch (e) { return null; }
  }

  // ---------- DOM & UI ----------
  var CREST = '<svg class="crest" viewBox="0 0 140 140"><defs><linearGradient id="wg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff2b8"/><stop offset=".5" stop-color="#e3b94f"/><stop offset="1" stop-color="#9a6b12"/></linearGradient><mask id="wm"><rect width="140" height="140" fill="#fff"/><circle cx="76" cy="70" r="37" fill="#000"/></mask></defs><circle cx="70" cy="70" r="64" fill="none" stroke="url(#wg)" stroke-width="1.6" stroke-dasharray="2 5"/><circle cx="70" cy="70" r="58" fill="none" stroke="url(#wg)"/><circle cx="62" cy="70" r="42" fill="url(#wg)" mask="url(#wm)"/><g transform="translate(94 70)"><rect x="-11" y="-11" width="22" height="22" fill="url(#wg)"/><rect x="-11" y="-11" width="22" height="22" fill="url(#wg)" transform="rotate(45)"/><circle r="4" fill="#5e0b17"/></g></svg>';
  function letters(s, d0) { var o = ''; for (var i = 0; i < s.length; i++) o += '<i style="animation-delay:' + (d0 + i * 0.05).toFixed(2) + 's">' + s[i] + '</i>'; return o; }
  function btn(cls, n, label, sub, act, dis, i) {
    return '<button class="mb ' + cls + '" style="animation-delay:' + (0.7 + i * 0.08).toFixed(2) + 's"' + (dis ? ' disabled' : '') + ' data-a="' + act + '"><em>' + n + '</em><span class="lbl">' + label + '</span>' + (sub ? '<small class="sub">' + sub + '</small>' : '<small class="sub"></small>') + '</button>';
  }

  function updateTexts() {
    if (!root) return;
    var sv = saveInfo();
    var q = QUOTES[qi % QUOTES.length];
    var sealSpan = root.querySelector('.seal span');
    if (sealSpan) sealSpan.textContent = X('Cihan Hâkimiyeti Yolunda', 'The Road to World Dominion');
    var tickEl = root.querySelector('.tick');
    if (tickEl) tickEl.innerHTML = X('Divan toplantıda', 'The council convenes') + '<br><b>●</b> ' + X('Cihan masası açık', 'World table open');
    var quoteEl = document.getElementById('wcq');
    if (quoteEl) quoteEl.innerHTML = X(q[0], q[1]) + '<b>' + WHO.split(' · ')[X(0, 1)] + '</b>';
    var bCont = root.querySelector('[data-a="cont"] .lbl');
    if (bCont) bCont.textContent = X('Seferi Sürdür', 'Resume Campaign');
    var bContSub = root.querySelector('[data-a="cont"] .sub');
    if (bContSub && sv) bContSub.textContent = X('Tur ', 'Turn ') + sv.turn;
    var bNew = root.querySelector('[data-a="new"] .lbl');
    if (bNew) bNew.textContent = X('Yeni Fetih', 'New Conquest');
    var bShop = root.querySelector('[data-a="shop"] .lbl');
    if (bShop) bShop.textContent = X('Hazine', 'Treasury');
    var bSet = root.querySelector('[data-a="set"] .lbl');
    if (bSet) bSet.textContent = X('Ayarlar', 'Settings');
    var bLang = root.querySelector('[data-a="lang"] .lbl');
    if (bLang) bLang.textContent = X('Dil', 'Lang');
    var bLangSub = root.querySelector('[data-a="lang"] .sub');
    if (bLangSub) bLangSub.textContent = L === 'tr' ? 'TR' : 'EN';
    var verEl = root.querySelector('.ver');
    if (verEl) verEl.textContent = 'v35 · ' + X('Makyavelist Sürüm', 'Machiavellian Edition');
  }

  function build() {
    if (!root) {
      root = document.createElement('div'); root.id = 'wcm'; document.body.appendChild(root);
      root.addEventListener('click', function (e) {
        var b = e.target.closest && e.target.closest('[data-a]'); if (!b || b.disabled) return;
        act(b.getAttribute('data-a'));
      });
      root.addEventListener('pointerdown', function (e) { if (e.target.closest('.col')) return; drag.on = true; drag.x = e.clientX; drag.y = e.clientY; });
      window.addEventListener('pointermove', function (e) {
        if (!running) return;
        par.tx = (e.clientX / window.innerWidth - .5); par.ty = (e.clientY / window.innerHeight - .5);
        if (drag.on) { drag.vx = (e.clientX - drag.x) * .005; drag.vy = (e.clientY - drag.y) * .003; rotY += drag.vx; rotX = Math.max(-.7, Math.min(.9, rotX + drag.vy)); drag.x = e.clientX; drag.y = e.clientY; }
      }, { passive: true });
      window.addEventListener('pointerup', function () { drag.on = false; });
      window.addEventListener('resize', fit);
      document.addEventListener('visibilitychange', function () { if (document.hidden) stop(); else if (root.classList.contains('on')) start(); });
    }
    var sv = saveInfo(), emb = CFG.emblem ? '<img class="crest" src="' + CFG.emblem + '" alt="" style="animation:none">' : CREST;
    var q = QUOTES[qi % QUOTES.length];
    root.innerHTML =
      (CFG.bg ? '<div class="bgimg" style="background-image:url(' + CFG.bg + ')"></div>' : '') +
      '<canvas></canvas><div class="vig"></div><div class="grain"></div><div class="frame"></div>' +
      '<div class="tick">' + X('Divan toplantıda', 'The council convenes') + '<br><b>●</b> ' + X('Cihan masası açık', 'World table open') + '</div>' +
      '<div class="col"><div class="seal"><div class="crest-wrap">' + emb + '</div><span>' + X('Cihan Hâkimiyeti Yolunda', 'The Road to World Dominion') + '</span></div>' +
      '<h1>' + letters('WORLD', 0.2) + '<span>' + letters('CONQUEST', 0.5) + '</span></h1>' +
      '<div class="quote" id="wcq">' + X(q[0], q[1]) + '<b>' + WHO.split(' · ')[X(0, 1)] + '</b></div>' +
      (sv ? '<div class="stats"><div><small>' + X('Tur', 'Turn') + '</small><b>' + sv.turn + '</b></div><div><small>' + X('Fethedilen', 'Conquered') + '</small><b>' + sv.mine + '</b></div><div><small>' + X('Dünya', 'World') + '</small><b>' + Math.round(sv.mine / Math.max(1, sv.tot) * 100) + '%</b></div></div>' : '') +
      '<div class="menu">' +
      btn('pri', 'I', X('Seferi Sürdür', 'Resume Campaign'), sv ? X('Tur ', 'Turn ') + sv.turn : '', 'cont', !sv, 0) +
      btn('', 'II', X('Yeni Fetih', 'New Conquest'), '', 'new', false, 1) +
      (window.Shop ? btn('', 'III', X('Hazine', 'Treasury'), '', 'shop', false, 2) : '') +
      '<div class="row">' + btn('', '⚙', X('Ayarlar', 'Settings'), '', 'set', false, 3) + btn('', '☉', X('Dil', 'Lang'), L === 'tr' ? 'TR' : 'EN', 'lang', false, 4) + '</div>' +
      '</div></div><div class="ver">v35 · ' + X('Makyavelist Sürüm', 'Machiavellian Edition') + '</div>';
    cv = root.querySelector('canvas');
    clearInterval(qTimer);
    qTimer = setInterval(function () {
      var el = document.getElementById('wcq'); if (!el || !running) return; qi++; var q2 = QUOTES[qi % QUOTES.length];
      el.classList.remove('sw'); void el.offsetWidth; el.innerHTML = X(q2[0], q2[1]) + '<b>' + WHO.split(' · ')[X(0, 1)] + '</b>'; el.classList.add('sw');
    }, 7500);
  }
  qi = Math.floor(Math.random() * 7);

  function act(a) {
    try {
      if (a === 'cont') { root.classList.add('flash'); cont(); setTimeout(function () { root.classList.remove('flash'); }, 950); }
      else if (a === 'new') { askNew(); }
      else if (a === 'shop') { window.Shop.open(); }
      else if (a === 'set') { settings(); }
      else if (a === 'lang') {
        setLang();
        updateTexts();
      }
    } catch (e) { }
  }

  // ---------- 3B Sahne & WebGL Optimizasyonu ----------
  function loadThree() {
    return new Promise(function (ok, no) {
      if (window.THREE) return ok();
      var s = document.createElement('script'); s.src = 'globe/three.min.js'; s.onload = ok; s.onerror = function () { no(); }; document.head.appendChild(s);
    });
  }

  // Optimize edilmiş ve önbelleklenen harita dokusu (1024x512, D3 precision 1.2 -> anında açılış)
  var _cachedEarth = null, _cachedGlow = null, _cachedKey = null;
  function earthCanvases(sv) {
    var key = sv ? (sv.pl + ':' + sv.mine + ':' + sv.tot) : 'none';
    if (_cachedEarth && _cachedKey === key) return [_cachedEarth, _cachedGlow];
    var w = 1024, h = 512, c = document.createElement('canvas'), g = document.createElement('canvas');
    c.width = g.width = w; c.height = g.height = h;
    var x = c.getContext('2d'), y = g.getContext('2d');
    x.fillStyle = '#0a0711'; x.fillRect(0, 0, w, h);
    y.fillStyle = '#000'; y.fillRect(0, 0, w, h);
    var pr = d3.geo.equirectangular().scale(w / (2 * Math.PI)).translate([w / 2, h / 2]).precision(1.2);
    var pc = d3.geo.path().projection(pr).context(x), pg = d3.geo.path().projection(pr).context(y);
    y.strokeStyle = 'rgba(201,162,77,.18)'; y.lineWidth = 1; y.beginPath(); pg(d3.geo.graticule().step([30, 30])()); y.stroke();
    (window.R || []).forEach(function (r, i) {
      var mine = sv && sv.pl != null && sv.owner && sv.owner[r.id] === sv.pl, h1 = (i * 47) % 100;
      x.beginPath(); pc(r.f);
      x.fillStyle = mine ? 'hsl(43,70%,' + (36 + h1 % 10) + '%)' : 'hsl(' + (345 + h1 % 18) + ',' + (30 + h1 % 25) + '%,' + (11 + h1 % 9) + '%)';
      x.fill();
      x.lineWidth = 1.0; x.strokeStyle = 'rgba(227,185,79,.45)'; x.stroke();
      y.beginPath(); pg(r.f);
      y.lineWidth = mine ? 2.0 : 0.8;
      y.strokeStyle = mine ? 'rgba(255,230,150,1)' : 'rgba(210,150,60,.6)';
      y.stroke();
      if (mine) { y.fillStyle = 'rgba(227,185,79,.25)'; y.fill(); }
    });
    _cachedEarth = c; _cachedGlow = g; _cachedKey = key;
    return [c, g];
  }

  function sprite(col) {
    var c = document.createElement('canvas'); c.width = c.height = 32; var x = c.getContext('2d'), gr = x.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, col); gr.addColorStop(.25, col); gr.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = gr; x.fillRect(0, 0, 32, 32);
    return new T3.CanvasTexture(c);
  }

  function initGL() {
    try {
      var sv = saveInfo(), coarse = matchMedia('(pointer:coarse)').matches;
      var dpr = window.devicePixelRatio || 1;
      renderer = new T3.WebGLRenderer({
        canvas: cv,
        antialias: !coarse && dpr <= 1,
        alpha: true,
        powerPreference: 'high-performance'
      });
      renderer.setPixelRatio(Math.min(dpr, coarse ? 1.0 : 1.25));
      renderer.setClearColor(0x000000, 0);

      scene = new T3.Scene();
      camera = new T3.PerspectiveCamera(40, 1, .1, 100);
      camera.position.set(0, 0, 3.8);

      var sun = new T3.DirectionalLight(0xffd9a0, 2.5); sun.position.set(-3, 1.5, 3); scene.add(sun);
      var rim = new T3.DirectionalLight(0xb3201a, 2.8); rim.position.set(4, 1, -3); scene.add(rim);
      scene.add(new T3.AmbientLight(0x4a3040, 0.9));

      globe = new T3.Group(); scene.add(globe);
      spin = new T3.Group(); globe.add(spin);

      var cs = earthCanvases(sv), map = new T3.CanvasTexture(cs[0]), glow = new T3.CanvasTexture(cs[1]);
      map.colorSpace = T3.SRGBColorSpace; glow.colorSpace = T3.SRGBColorSpace;
      map.anisotropy = glow.anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 2);

      // MeshPhongMaterial: MeshStandard'dan 3 kat daha az GPU yükü, sabit 60 FPS
      var earth = new T3.Mesh(
        new T3.SphereGeometry(1, 64, 48),
        new T3.MeshPhongMaterial({
          map: map,
          emissiveMap: glow,
          emissive: 0xffffff,
          emissiveIntensity: 0.85,
          specular: 0x553311,
          shininess: 15
        })
      );
      spin.add(earth);

      // Atmosfer küresi (32x24 segmentler yeterli ve çok hafif)
      var atm = new T3.Mesh(new T3.SphereGeometry(1.18, 32, 24), new T3.ShaderMaterial({
        transparent: true, blending: T3.AdditiveBlending, side: T3.BackSide, depthWrite: false,
        vertexShader: 'varying vec3 n;void main(){n=normalize(normalMatrix*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
        fragmentShader: 'varying vec3 n;void main(){float i=pow(max(0.,-n.z),2.4);gl_FragColor=vec4(mix(vec3(.75,.1,.08),vec3(1.,.62,.22),i*1.4),1.)*i*1.5;}'
      }));
      globe.add(atm);

      // Astrolab halkaları (Optimize Torus: 64 segment)
      rings = new T3.Group(); globe.add(rings);
      [[1.42, .004, .5, 0], [1.62, .003, -.9, .35], [1.82, .002, 1.2, -.25]].forEach(function (d, i) {
        var m = new T3.Mesh(new T3.TorusGeometry(d[0], d[1], 6, 64), new T3.MeshBasicMaterial({ color: i === 1 ? 0xb3201a : 0xc9a24d, transparent: true, opacity: .75 }));
        m.rotation.x = Math.PI / 2 + d[2] * .35; m.rotation.y = d[3]; m.userData.sp = (i % 2 ? -1 : 1) * (.06 + i * .03); rings.add(m);
        if (i === 0) {
          var p = []; for (var k = 0; k < 72; k++) { var a = k / 72 * Math.PI * 2, l = k % 6 ? 0.025 : 0.05, r0 = d[0] + .02; p.push(Math.cos(a) * r0, Math.sin(a) * r0, 0, Math.cos(a) * (r0 + l), Math.sin(a) * (r0 + l), 0); }
          var tg = new T3.BufferGeometry(); tg.setAttribute('position', new T3.Float32BufferAttribute(p, 3));
          m.add(new T3.LineSegments(tg, new T3.LineBasicMaterial({ color: 0xe3b94f, transparent: true, opacity: .8 })));
        }
        if (i === 2) {
          for (var s = 0; s < 3; s++) {
            var sat = new T3.Mesh(new T3.OctahedronGeometry(.035), new T3.MeshBasicMaterial({ color: 0xffd98a }));
            var a2 = s * 2.094; sat.position.set(Math.cos(a2) * d[0], Math.sin(a2) * d[0], 0); m.add(sat);
          }
        }
      });

      // Fetih okları: GPU BufferGeometry drawRange kullanarak sıfır vertex re-upload
      var pts = (window.R || []).filter(function (r) { return r.c; }), spr = sprite('rgba(255,120,80,1)'), spg = sprite('rgba(255,220,140,1)');
      arcs = [];
      var arcCount = coarse ? 3 : 5;
      for (var i = 0; i < arcCount; i++) {
        var geo = new T3.BufferGeometry();
        geo.setAttribute('position', new T3.BufferAttribute(new Float32Array(60 * 3), 3));
        geo.setDrawRange(0, 0);
        var line = new T3.Line(geo, new T3.LineBasicMaterial({ color: 0xff6a4a, transparent: true, opacity: .9, blending: T3.AdditiveBlending, depthWrite: false }));
        var head = new T3.Sprite(new T3.SpriteMaterial({ map: spg, blending: T3.AdditiveBlending, transparent: true, depthWrite: false })); head.scale.set(.1, .1, 1);
        var dst = new T3.Sprite(new T3.SpriteMaterial({ map: spr, blending: T3.AdditiveBlending, transparent: true, depthWrite: false })); dst.scale.set(.01, .01, 1);
        spin.add(line, head, dst);
        arcs.push({ line: line, geo: geo, head: head, dst: dst, t: -i * 1.1, life: 4.6, pts: pts });
        newArc(arcs[i]);
      }

      // Yıldızlar (500 adet)
      var sp = [], i2;
      for (i2 = 0; i2 < 500; i2++) {
        var u = Math.random() * 6.283, v = Math.acos(2 * Math.random() - 1), rr = 12 + Math.random() * 20;
        sp.push(rr * Math.sin(v) * Math.cos(u), rr * Math.cos(v), rr * Math.sin(v) * Math.sin(u));
      }
      var sg = new T3.BufferGeometry(); sg.setAttribute('position', new T3.Float32BufferAttribute(sp, 3));
      stars = new T3.Points(sg, new T3.PointsMaterial({ size: .06, color: 0xcdb98a, transparent: true, opacity: .7, sizeAttenuation: true, depthWrite: false }));
      scene.add(stars);

      // Kıvılcımlar (45 adet)
      var ep = [], ev = [];
      for (i2 = 0; i2 < 45; i2++) {
        ep.push((Math.random() - .5) * 9, (Math.random() - .5) * 6, (Math.random() - .5) * 4);
        ev.push(.1 + Math.random() * .25);
      }
      var eg = new T3.BufferGeometry(); eg.setAttribute('position', new T3.Float32BufferAttribute(ep, 3)); eg.userData.v = ev;
      embers = new T3.Points(eg, new T3.PointsMaterial({ size: .09, map: spr, color: 0xffa060, transparent: true, opacity: .8, blending: T3.AdditiveBlending, depthWrite: false }));
      scene.add(embers);

      ready = true; fit();
    } catch (e) {
      glFail = true; ready = false; root.insertAdjacentHTML('afterbegin', '<div class="noGL">☪</div>');
    }
  }

  function newArc(a) {
    var P = a.pts; if (!P || !P.length) { a.t = 1e9; return; }
    var A = P[Math.floor(Math.random() * P.length)], B = P[Math.floor(Math.random() * P.length)], tries = 0;
    while ((B === A || Math.abs(A.c[0] - B.c[0]) + Math.abs(A.c[1] - B.c[1]) < 25) && tries++ < 20) B = P[Math.floor(Math.random() * P.length)];
    var v1 = lonlat(A.c[0], A.c[1], 1.005), v2 = lonlat(B.c[0], B.c[1], 1.005), dist = v1.distanceTo(v2), mid = v1.clone().add(v2).normalize().multiplyScalar(1 + dist * .42);
    var pos = a.geo.attributes.position, curve = new T3.QuadraticBezierCurve3(v1, mid, v2);
    a.curve = curve; a.n = 60; a.pa = curve.getPoints(59);
    // Noktaları bir kez yükle
    for (var i = 0; i < 60; i++) pos.setXYZ(i, a.pa[i].x, a.pa[i].y, a.pa[i].z);
    pos.needsUpdate = true;
    a.geo.setDrawRange(0, 0);
    a.dst.position.copy(v2); a.life = 3.6 + Math.random() * 1.6; a.t = 0;
  }

  function stepArc(a, dt) {
    a.t += dt; if (a.t < 0) { a.line.visible = a.head.visible = a.dst.visible = false; return; }
    a.line.visible = a.head.visible = a.dst.visible = true;
    var p = a.t / a.life; if (p > 1.35) { newArc(a); return; }
    var k = Math.min(1, p / .7), cnt = Math.max(2, Math.floor(k * 59)), fade = p > 1 ? Math.max(0, 1 - (p - 1) / .35) : 1;
    // CPU vertex kopyalamak yerine doğrudan GPU draw range belirle
    a.geo.setDrawRange(0, cnt);
    a.line.material.opacity = .9 * fade;
    a.head.position.copy(a.pa[cnt - 1]);
    a.head.material.opacity = fade;
    var pulse = p > .7 ? (p - .7) / .65 : 0;
    a.dst.scale.setScalar(.01 + Math.sin(Math.min(1, pulse) * Math.PI) * .38);
    a.dst.material.opacity = Math.max(0, 1 - pulse);
  }

  function fit() {
    if (!ready || !root) return; W = root.clientWidth || window.innerWidth; H = root.clientHeight || window.innerHeight;
    renderer.setSize(W, H, false); camera.aspect = W / H; camera.updateProjectionMatrix();
    var hh = Math.tan(20 * Math.PI / 180) * 3.8, hw = hh * camera.aspect, wide = W > 720 && W / H > 1.05, ppu = (H / 2) / hh;
    if (wide) {
      var s = Math.max(.35, Math.min(hh * .78, hw * .42) / 1.4);
      globe.scale.setScalar(s * 1.05); globe.position.set(hw * .42, 0, 0);
    } else {
      var col = root.querySelector('.col'), first = col && col.firstElementChild, top = first ? first.getBoundingClientRect().top : H * .45;
      top = Math.max(150, Math.min(top, H * .6));
      var r = Math.max(48, Math.min(W * .3, (top - 36) / 2 - 4)), cy = (top - 8) / 2;
      globe.scale.setScalar(r / ppu); globe.position.set(0, hh * (1 - 2 * cy / H), 0);
    }
  }

  function frame(t) {
    raf = requestAnimationFrame(frame);
    if (!ready || !running || document.hidden) return;

    // 60 FPS sınırlayıcı: 144Hz / 240Hz ekranlarda gereksiz GPU yükünü engeller
    if (t - lastFrameT < 14) return;
    var dt = Math.min(.033, (t - clock0) / 1000 || .016);
    clock0 = t;
    lastFrameT = t;

    // Otomatik düşük performans tespiti (cihaz kasıyorsa hafif moda geç)
    if (!lowPerf && frameCount++ < 50) {
      if (dt > 0.032) slowFrames++;
      if (slowFrames > 12) {
        lowPerf = true;
        if (embers) embers.visible = false;
        if (renderer) renderer.setPixelRatio(1.0);
      }
    }

    if (!drag.on) { rotY += dt * .07 + drag.vx * .9; drag.vx *= .94; rotX += (.28 - rotX) * dt * .4; }
    par.x += (par.tx - par.x) * .04; par.y += (par.ty - par.y) * .04;
    spin.rotation.y = rotY; spin.rotation.x = 0;
    globe.rotation.x = rotX + par.y * .25; globe.rotation.y = par.x * .4; globe.rotation.z = -.2;

    rings.children.forEach(function (m) { m.rotation.z += dt * m.userData.sp; });
    stars.rotation.y += dt * .004; stars.position.x = -par.x * .6; stars.position.y = par.y * .4;

    // Hızlı typed array ile kıvılcım güncelleme
    if (!lowPerf && embers) {
      var ep = embers.geometry.attributes.position, arr = ep.array, ev = embers.geometry.userData.v;
      for (var i = 0, l = ev.length; i < l; i++) {
        var idx = i * 3 + 1;
        var y = arr[idx] + ev[i] * dt;
        if (y > 3.2) {
          y = -3.2;
          arr[i * 3] = (Math.random() - .5) * 9;
        }
        arr[idx] = y;
        arr[i * 3] += Math.sin(t * 0.0007 + i) * dt * .06;
      }
      ep.needsUpdate = true;
    }

    for (var aIdx = 0; aIdx < arcs.length; aIdx++) {
      stepArc(arcs[aIdx], dt);
    }

    var intro = Math.min(1, (t - introT) / 2000);
    camera.position.z = 3.8 + (1 - intro * intro * (3 - 2 * intro)) * 3.2;
    renderer.render(scene, camera);
  }

  function start() { if (running || !ready) return; running = true; clock0 = performance.now(); lastFrameT = clock0; raf = requestAnimationFrame(frame); }
  function stop() { running = false; cancelAnimationFrame(raf); }

  // ---------- Göster / Gizle ----------
  function show(force) {
    if (!force && root && root.classList.contains('on') && root.firstChild) return;
    build(); root.classList.add('on'); document.body.classList.add('wcm-on'); introT = performance.now();
    if (glFail) return;
    var go = function () {
      if (!root.classList.contains('on')) return;
      if (ready) dispose();
      T3 = window.THREE; initGL(); if (ready) start();
    };
    if (window.THREE) go();
    else if (!loading) {
      loading = true;
      loadThree().then(function () { loading = false; go(); }).catch(function () { loading = false; glFail = true; });
    }
  }

  function dispose() {
    stop();
    try {
      if (renderer) {
        renderer.dispose();
        if (renderer.forceContextLoss) renderer.forceContextLoss();
      }
    } catch (e) { }
    ready = false; arcs = []; renderer = null; scene = null; camera = null; globe = null; spin = null; rings = null; embers = null; stars = null;
  }

  function hide() {
    if (!root || !root.classList.contains('on')) return;
    root.classList.remove('on'); document.body.classList.remove('wcm-on');
    stop(); clearInterval(qTimer); dispose(); root.innerHTML = '';
  }

  var _menu35 = menu;
  menu = function () {
    if (idle()) { try { closeMod(); } catch (e) { } show(); return; }
    hide(); _menu35.apply(this, arguments);
  };
  setInterval(function () { if (root && root.classList.contains('on') && !idle()) hide(); }, 250);

  // Oyun başlayınca beyaz parlama geçişi
  var _ng = newGame; newGame = function () { var r = _ng.apply(this, arguments); try { if (!idle()) hide(); } catch (e) { } return r; };
  var _ct = cont; cont = function () { var r = _ct.apply(this, arguments); try { if (!idle()) hide(); } catch (e) { } return r; };
  window.WCMenu = { show: show, hide: hide, updateTexts: updateTexts };

  // İlk açılışta init() zaten menu() çağırmış olabilir (script load'dan önce); yoksa kendimiz aç.
  window.addEventListener('load', function () { setTimeout(function () { if (idle() && !(root && root.classList.contains('on'))) menu(); }, 500); });
})();
