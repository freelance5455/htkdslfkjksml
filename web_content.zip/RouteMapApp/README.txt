ROUTE MAP - Android App

Features:
- Internet map using OpenStreetMap (no Google Maps API key)
- GPS route tracking with red line
- Start / Stop
- Save routes with custom names
- Search saved routes
- View/delete saved routes
- Local storage on phone

Build:
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).

Note: background tracking while the app is fully killed is not included in v1. Screen-off/Android power restrictions may require a foreground service in the next version.
