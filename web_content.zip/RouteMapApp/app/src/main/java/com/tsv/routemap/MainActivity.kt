package com.tsv.routemap

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity(), LocationListener {
    private lateinit var web: WebView
    private lateinit var lm: LocationManager
    private var tracking = false
    private val points = mutableListOf<Pair<Double,Double>>()
    private val prefs by lazy { getSharedPreferences("routes", Context.MODE_PRIVATE) }
    private val REQ = 7

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.setGeolocationEnabled(true)
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQ)
    }

    inner class Bridge {
        @JavascriptInterface fun startTracking() {
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQ); return@runOnUiThread
                }
                points.clear(); tracking = true
                try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 3f, this@MainActivity) } catch (_: Exception) {}
                try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 5f, this@MainActivity) } catch (_: Exception) {}
                web.evaluateJavascript("setTracking(true)", null)
                Toast.makeText(this, "Tracking started", Toast.LENGTH_SHORT).show()
            }
        }
        @JavascriptInterface fun stopTracking() {
            runOnUiThread {
                tracking = false; lm.removeUpdates(this@MainActivity); web.evaluateJavascript("setTracking(false)", null)
                if (points.size >= 2) web.evaluateJavascript("showSaveDialog()", null) else Toast.makeText(this, "Not enough GPS points", Toast.LENGTH_SHORT).show()
            }
        }
        @JavascriptInterface fun saveRoute(name: String) {
            if (points.size < 2) return
            val arr = JSONArray(); points.forEach { arr.put(JSONArray().put(it.first).put(it.second)) }
            val route = JSONObject().put("name", name).put("time", System.currentTimeMillis()).put("points", arr)
            val all = JSONArray(prefs.getString("data", "[]")); val out = JSONArray(); out.put(route)
            for (i in 0 until all.length()) out.put(all.getJSONObject(i))
            prefs.edit().putString("data", out.toString()).apply()
            runOnUiThread { web.evaluateJavascript("loadRoutes()", null); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() }
        }
        @JavascriptInterface fun getRoutes(): String = prefs.getString("data", "[]") ?: "[]"
        @JavascriptInterface fun deleteRoute(index: Int) {
            val all = JSONArray(prefs.getString("data", "[]")); val out = JSONArray()
            for (i in 0 until all.length()) if (i != index) out.put(all.getJSONObject(i))
            prefs.edit().putString("data", out.toString()).apply(); runOnUiThread { web.evaluateJavascript("loadRoutes()", null) }
        }
    }

    override fun onLocationChanged(l: Location) {
        if (!tracking) return
        val p = l.latitude to l.longitude
        if (points.isEmpty() || distance(points.last(), p) > 1.0) {
            points.add(p)
            val js = "addPoint(${p.first},${p.second})"
            runOnUiThread { web.evaluateJavascript(js, null) }
        }
    }
    private fun distance(a: Pair<Double,Double>, b: Pair<Double,Double>): Float {
        val r = FloatArray(1); Location.distanceBetween(a.first,a.second,b.first,b.second,r); return r[0]
    }
    @Deprecated("Deprecated") override fun onStatusChanged(p:String?,s:Int,e:Bundle?) {}
    override fun onProviderEnabled(p:String) {}
    override fun onProviderDisabled(p:String) {}
    override fun onDestroy(){ lm.removeUpdates(this); super.onDestroy() }
}
