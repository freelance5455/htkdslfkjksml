# TUNIR — One World. One TUNIR.

Professional single-file front-end prototype for TUNIR.

## Included
- Professional mobile-first product UI
- TUNIR brand identity
- Global language selector with 70+ language options
- Unicode-friendly UI and RTL support for Arabic, Persian, Hebrew, Urdu, Pashto and Kurdish
- Home, Chat, AI, Calls, Business, Marketplace, Wallet and Profile entry points
- Universal search entry point
- Responsive desktop/mobile layout
- Local language preference

## Important
The interface is production-oriented, but real messaging, calling, AI, authentication, payments, marketplace orders and databases require a secure backend and authorized third-party services before public launch.
