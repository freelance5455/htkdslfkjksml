# V71 — Excel Choose File root fix

Built directly from V70.

Fixes the Android Choose File button by:
- removing the READ_EXTERNAL_STORAGE permission gate from the bridge path;
- launching ACTION_GET_CONTENT directly with a simple */* type and no storage permission dependency;
- tracking native picker requests separately from WebView HTML file-input callbacks;
- processing the selected URI through the existing native XLSX/CSV parser and `handleAndroidImportRows`;
- retaining the WebView callback path for normal HTML `<input type=file>` requests.

No Supabase schema/functions were changed.
