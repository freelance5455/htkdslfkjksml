package ir.parsnet.client

import java.lang.reflect.InvocationHandler
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import java.lang.reflect.Proxy

/**
 * کتابخانه‌ی libbox بین نسخه‌ها امضای متدها را کمی تغییر می‌دهد؛ برای همین
 * ارتباط با آن از طریق reflection انجام می‌شود تا برنامه با نسخه‌های مختلف کامپایل شود.
 */
object Refl {
    const val PKG = "io.nekohasekai.libbox."

    fun cls(name: String): Class<*> = Class.forName(PKG + name)

    private fun find(o: Any, name: String, argc: Int): Method? =
        o.javaClass.methods.firstOrNull { it.name.equals(name, true) && it.parameterTypes.size == argc }

    fun call(o: Any, name: String, vararg a: Any?): Any? {
        val m = find(o, name, a.size) ?: throw NoSuchMethodException(o.javaClass.name + "." + name)
        m.isAccessible = true
        try {
            return m.invoke(o, *a)
        } catch (e: InvocationTargetException) {
            throw e.targetException ?: e
        }
    }

    fun callStatic(c: Class<*>, name: String, vararg a: Any?): Any? {
        val m = c.methods.firstOrNull { it.name.equals(name, true) && it.parameterTypes.size == a.size }
            ?: throw NoSuchMethodException(c.name + "." + name)
        try {
            return m.invoke(null, *a)
        } catch (e: InvocationTargetException) {
            throw e.targetException ?: e
        }
    }

    /** getX() یا isX() — اگر نبود null. */
    fun opt(o: Any?, prop: String): Any? {
        if (o == null) return null
        val m = find(o, "get$prop", 0) ?: find(o, "is$prop", 0) ?: return null
        m.isAccessible = true
        return try { m.invoke(o) } catch (e: InvocationTargetException) { null }
    }

    fun set(o: Any, prop: String, v: Any?) {
        val m = find(o, "set$prop", 1) ?: return
        m.isAccessible = true
        m.invoke(o, v)
    }

    fun items(o: Any?): List<Any> {
        if (o == null) return emptyList()
        val out = ArrayList<Any>()
        while (call(o, "hasNext") as Boolean) out.add(call(o, "next")!!)
        return out
    }

    fun defaultFor(t: Class<*>): Any? = when (t) {
        java.lang.Boolean.TYPE -> false
        java.lang.Integer.TYPE -> 0
        java.lang.Long.TYPE -> 0L
        java.lang.Double.TYPE -> 0.0
        else -> null
    }

    fun proxy(iface: Class<*>, h: (Method, Array<Any?>) -> Any?): Any =
        Proxy.newProxyInstance(iface.classLoader, arrayOf(iface), InvocationHandler { p, m, a ->
            val args = a ?: emptyArray()
            when (m.name) {
                "toString" -> iface.simpleName + "Proxy"
                "hashCode" -> System.identityHashCode(p)
                "equals" -> p === args[0]
                else -> h(m, args)
            }
        })

    fun stringIterator(type: Class<*>, list: List<String>): Any {
        var i = 0
        return proxy(type) { m, _ ->
            when (m.name) {
                "hasNext" -> i < list.size
                "next" -> list[i++]
                "len" -> list.size - i
                else -> defaultFor(m.returnType)
            }
        }
    }

    fun listIterator(type: Class<*>, list: List<Any>): Any {
        var i = 0
        return proxy(type) { m, _ ->
            when (m.name) {
                "hasNext" -> i < list.size
                "next" -> list[i++]
                "len" -> list.size - i
                else -> defaultFor(m.returnType)
            }
        }
    }

    fun rootMessage(e: Throwable): String {
        var t: Throwable = e
        while (t.cause != null && t.cause !== t) t = t.cause!!
        return when (t) {
            is ClassNotFoundException, is NoClassDefFoundError ->
                "کتابخانه libbox بارگذاری نشد؛ اتصال اینترنت هنگام Gradle Sync و دریافت وابستگی را بررسی کنید."
            else -> t.message ?: t.javaClass.simpleName
        }
    }
}
