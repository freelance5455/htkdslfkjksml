package ir.parsnet.client

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

class Parsed(val protocol: Protocol, val name: String, val host: String, val port: Int, val outbound: JSONObject)

/** تبدیل لینک vless/vmess/trojan/ss به outbound فرمت sing-box. */
object LinkParser {
    fun parse(link: String): Parsed? = runCatching { parseOrThrow(link.trim()) }.getOrNull()

    fun parseOrThrow(link: String): Parsed = when (link.substringBefore("://", "").lowercase()) {
        "vless" -> vless(link)
        "vmess" -> vmess(link)
        "trojan" -> trojan(link)
        "ss", "shadowsocks" -> shadowsocks(link)
        else -> throw IllegalArgumentException("پروتکل پشتیبانی نمی‌شود")
    }

    private fun b64(s: String): String? = runCatching {
        var t = s.trim().replace('-', '+').replace('_', '/')
        while (t.length % 4 != 0) t += "="
        String(Base64.decode(t, Base64.DEFAULT), Charsets.UTF_8)
    }.getOrNull()

    private fun cleanHost(h: String?): String =
        (h ?: throw IllegalArgumentException("آدرس سرور ندارد")).trim().trim('[', ']')

    private fun nameOf(n: String?, host: String): String = n?.takeIf { it.isNotBlank() } ?: host

    private fun queryMap(u: Uri): Map<String, String> =
        u.queryParameterNames.associateWith { u.getQueryParameter(it) ?: "" }

    private fun Map<String, String>.v(k: String): String? = this[k]?.takeIf { it.isNotBlank() }

    private fun vless(link: String): Parsed {
        val u = Uri.parse(link)
        val host = cleanHost(u.host)
        val port = u.port.takeIf { it > 0 } ?: 443
        val uuid = u.userInfo ?: throw IllegalArgumentException("uuid ندارد")
        val p = queryMap(u)
        val ob = JSONObject().put("type", "vless").put("tag", "proxy")
            .put("server", host).put("server_port", port).put("uuid", uuid)
        p.v("flow")?.let { ob.put("flow", it) }
        ob.put("packet_encoding", "xudp")
        applyTransportTls(ob, p, false)
        return Parsed(Protocol.VLESS, nameOf(u.fragment, host), host, port, ob)
    }

    private fun vmess(link: String): Parsed {
        val body = link.substringAfter("://").substringBefore("#")
        val j = JSONObject(b64(body) ?: throw IllegalArgumentException("vmess نامعتبر"))
        val host = j.getString("add").trim()
        val port = j.get("port").toString().toInt()
        val ob = JSONObject().put("type", "vmess").put("tag", "proxy")
            .put("server", host).put("server_port", port)
            .put("uuid", j.getString("id"))
            .put("security", j.optString("scy").ifBlank { "auto" })
            .put("alter_id", j.optString("aid", "0").toIntOrNull() ?: 0)
        val p = mapOf(
            "type" to j.optString("net", "tcp"),
            "host" to j.optString("host"),
            "path" to j.optString("path"),
            "serviceName" to j.optString("path"),
            "sni" to j.optString("sni"),
            "alpn" to j.optString("alpn"),
            "fp" to j.optString("fp"),
            "security" to if (j.optString("tls") == "tls") "tls" else "none"
        )
        applyTransportTls(ob, p, false)
        return Parsed(Protocol.VMESS, nameOf(j.optString("ps"), host), host, port, ob)
    }

    private fun trojan(link: String): Parsed {
        val u = Uri.parse(link)
        val host = cleanHost(u.host)
        val port = u.port.takeIf { it > 0 } ?: 443
        val pw = u.userInfo ?: throw IllegalArgumentException("رمز ندارد")
        val ob = JSONObject().put("type", "trojan").put("tag", "proxy")
            .put("server", host).put("server_port", port).put("password", pw)
        applyTransportTls(ob, queryMap(u), true)
        return Parsed(Protocol.TROJAN, nameOf(u.fragment, host), host, port, ob)
    }

    private fun shadowsocks(link: String): Parsed {
        var rest = link.substringAfter("://")
        val frag = Uri.decode(rest.substringAfter("#", ""))
        rest = rest.substringBefore("#")
        val query = rest.substringAfter("?", "")
        rest = rest.substringBefore("?")
        if (query.contains("plugin=")) throw IllegalArgumentException("پلاگین ss پشتیبانی نمی‌شود")
        var method = ""; var password = ""; var hostPort = ""
        if (rest.contains("@")) {
            val ui = rest.substringBeforeLast("@")
            hostPort = rest.substringAfterLast("@")
            val dec = if (ui.contains(":")) Uri.decode(ui) else (b64(ui) ?: throw IllegalArgumentException("ss نامعتبر"))
            method = dec.substringBefore(":"); password = dec.substringAfter(":")
        } else {
            val dec = b64(rest) ?: throw IllegalArgumentException("ss نامعتبر")
            val ui = dec.substringBeforeLast("@")
            hostPort = dec.substringAfterLast("@")
            method = ui.substringBefore(":"); password = ui.substringAfter(":")
        }
        val host = cleanHost(hostPort.substringBeforeLast(":"))
        val port = hostPort.substringAfterLast(":").trim('/').toInt()
        val ob = JSONObject().put("type", "shadowsocks").put("tag", "proxy")
            .put("server", host).put("server_port", port)
            .put("method", method).put("password", password)
        return Parsed(Protocol.SHADOWSOCKS, nameOf(frag, host), host, port, ob)
    }

    private fun applyTransportTls(ob: JSONObject, p: Map<String, String>, forceTls: Boolean) {
        val sec = p.v("security") ?: if (forceTls) "tls" else "none"
        if (sec == "tls" || sec == "reality") {
            val t = JSONObject().put("enabled", true)
            (p.v("sni") ?: p.v("peer"))?.let { t.put("server_name", it) }
            if (p.v("allowInsecure") == "1" || p.v("insecure") == "1") t.put("insecure", true)
            p.v("alpn")?.let { a ->
                t.put("alpn", JSONArray(a.split(",").map { it.trim() }.filter { it.isNotEmpty() }))
            }
            val fp = p.v("fp") ?: if (sec == "reality") "chrome" else null
            fp?.let { t.put("utls", JSONObject().put("enabled", true).put("fingerprint", it)) }
            if (sec == "reality") {
                t.put("reality", JSONObject().put("enabled", true)
                    .put("public_key", p.v("pbk") ?: throw IllegalArgumentException("reality بدون کلید"))
                    .put("short_id", p.v("sid") ?: ""))
            }
            ob.put("tls", t)
        }
        val type = (p.v("type") ?: "tcp").lowercase()
        when (type) {
            "tcp", "raw" -> Unit
            "ws" -> {
                val t = JSONObject().put("type", "ws").put("path", p.v("path") ?: "/")
                p.v("host")?.let { t.put("headers", JSONObject().put("Host", it)) }
                ob.put("transport", t)
            }
            "grpc" -> ob.put("transport", JSONObject().put("type", "grpc").put("service_name", p.v("serviceName") ?: ""))
            "httpupgrade" -> {
                val t = JSONObject().put("type", "httpupgrade").put("path", p.v("path") ?: "/")
                p.v("host")?.let { t.put("host", it) }
                ob.put("transport", t)
            }
            "http", "h2" -> {
                val t = JSONObject().put("type", "http").put("path", p.v("path") ?: "/")
                p.v("host")?.let { t.put("host", JSONArray(it.split(",").map { s -> s.trim() })) }
                ob.put("transport", t)
            }
            else -> throw IllegalArgumentException("ترنسپورت $type پشتیبانی نمی‌شود")
        }
    }
}
