package ir.parsnet.client

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class CatalogResult(
    val servers: List<ServerConfig>,
    val announcement: String,
    val ad: String,
    val offline: Boolean
)

/**
 * فهرست سرورها را از یک فایل متنی آنلاین (فقط ویرایش‌شده توسط مدیر) می‌خواند.
 * فرمت: هر خط یک لینک. خط‌های «#announce: ...» و «#ad: ...» اعلان و تبلیغ هستند.
 * فایل می‌تواند به‌صورت base64 هم باشد (مثل اشتراک v2rayNG).
 */
object Catalog {
    suspend fun load(ctx: Context): CatalogResult = withContext(Dispatchers.IO) {
        val prefs = ctx.getSharedPreferences("parsnet_catalog", Context.MODE_PRIVATE)
        val url = BuildConfig.CATALOG_URL
        var text: String? = null
        var offline = false
        if (url.startsWith("https://") && !url.contains("example.com")) {
            text = runCatching { download(url) }.getOrNull()
            if (text != null) prefs.edit().putString("raw", text).apply() else offline = true
        }
        if (text == null) text = prefs.getString("raw", null)
        if (text == null) text = runCatching { ctx.assets.open("servers.txt").bufferedReader().use { it.readText() } }.getOrNull()
        parse(text.orEmpty(), offline)
    }

    private fun download(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "PARSNET")
        try {
            if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
            return c.inputStream.use { st ->
                val out = java.io.ByteArrayOutputStream()
                val tmp = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = st.read(tmp)
                    if (n < 0) break
                    total += n
                    if (total > 1_000_000) throw IllegalStateException("فایل بیش از حد بزرگ است")
                    out.write(tmp, 0, n)
                }
                String(out.toByteArray(), Charsets.UTF_8)
            }
        } finally {
            c.disconnect()
        }
    }

    fun parse(raw: String, offline: Boolean): CatalogResult {
        var text = raw.trim('\uFEFF', ' ', '\n', '\r', '\t')
        if (!text.contains("://")) {
            runCatching {
                var t = text.replace("\n", "").replace("\r", "").replace('-', '+').replace('_', '/')
                while (t.length % 4 != 0) t += "="
                String(Base64.decode(t, Base64.DEFAULT), Charsets.UTF_8)
            }.getOrNull()?.let { text = it }
        }
        var announce = ""
        var ad = ""
        val servers = LinkedHashMap<String, ServerConfig>()
        for (line in text.lines()) {
            val l = line.trim()
            when {
                l.startsWith("#announce:", true) -> announce = l.substringAfter(":").trim()
                l.startsWith("#ad:", true) -> ad = l.substringAfter(":").trim()
                l.startsWith("#") || l.isEmpty() -> Unit
                else -> ServerConfig.parse(l)?.let { servers[it.id] = it }
            }
        }
        return CatalogResult(servers.values.toList(), announce, ad, offline)
    }
}
