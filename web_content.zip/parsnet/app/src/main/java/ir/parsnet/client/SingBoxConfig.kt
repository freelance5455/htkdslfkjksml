package ir.parsnet.client

import org.json.JSONArray
import org.json.JSONObject

/** ساخت کانفیگ کامل sing-box (۱.۱۳) برای یک لینک. */
object SingBoxConfig {
    fun build(link: String): String {
        val outbound = LinkParser.parseOrThrow(link.trim()).outbound

        val dns = JSONObject()
            .put("servers", JSONArray()
                .put(JSONObject().put("type", "tls").put("tag", "dns-remote").put("server", "1.1.1.1").put("detour", "proxy"))
                .put(JSONObject().put("type", "udp").put("tag", "dns-local").put("server", "223.5.5.5")))
            .put("final", "dns-remote")
            .put("strategy", "prefer_ipv4")

        val tun = JSONObject()
            .put("type", "tun").put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
            .put("mtu", 9000)
            .put("auto_route", true)
            .put("stack", "mixed")

        val route = JSONObject()
            .put("rules", JSONArray()
                .put(JSONObject().put("action", "sniff"))
                .put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
                .put(JSONObject().put("ip_is_private", true).put("action", "route").put("outbound", "direct")))
            .put("final", "proxy")
            .put("auto_detect_interface", true)
            .put("default_domain_resolver", JSONObject().put("server", "dns-local"))

        return JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(tun))
            .put("outbounds", JSONArray().put(outbound).put(JSONObject().put("type", "direct").put("tag", "direct")))
            .put("route", route)
            .toString()
    }
}
