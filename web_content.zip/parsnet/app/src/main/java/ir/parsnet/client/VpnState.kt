package ir.parsnet.client

import kotlinx.coroutines.flow.MutableStateFlow

enum class Phase { OFF, CONNECTING, ON, ERROR }

/** وضعیت اتصال که سرویس می‌نویسد و صفحه می‌خواند. */
object VpnState {
    val phase = MutableStateFlow(Phase.OFF)
    val message = MutableStateFlow("")
    @Volatile var startedAt: Long = 0L
}
