package ir.parsnet.client

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.IpPrefix
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.net.InetAddress
import java.net.NetworkInterface

/**
 * سرویس VPN: کانفیگ sing-box را به libbox می‌دهد و رابط TUN و شبکه را برایش فراهم می‌کند.
 */
class ParsnetVpnService : VpnService() {
    companion object {
        const val ACTION_START = "ir.parsnet.client.START"
        const val ACTION_STOP = "ir.parsnet.client.STOP"
        const val EXTRA_CONFIG = "config"
        const val EXTRA_NAME = "name"
        private const val TAG = "PARSNET"
        private const val CHANNEL = "parsnet_vpn"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private var box: Any? = null
    private var tun: ParcelFileDescriptor? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var monitorListener: Any? = null
    private var stopping = false

    private val cm: ConnectivityManager get() = getSystemService(ConnectivityManager::class.java)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutdown(null); return START_NOT_STICKY }
            ACTION_START -> {
                val cfg = intent.getStringExtra(EXTRA_CONFIG)
                if (cfg == null) { stopSelf(); return START_NOT_STICKY }
                goForeground(intent.getStringExtra(EXTRA_NAME).orEmpty())
                begin(cfg)
                return START_NOT_STICKY
            }
        }
        stopSelf()
        return START_NOT_STICKY
    }

    override fun onRevoke() { shutdown(null) }

    override fun onDestroy() {
        runCatching { closeCore() }
        scope.coroutineContext[Job]?.cancel()
        if (VpnState.phase.value != Phase.ERROR) VpnState.phase.value = Phase.OFF
        super.onDestroy()
    }

    /* ---------------- lifecycle ---------------- */

    private fun begin(config: String) {
        stopping = false
        VpnState.message.value = ""
        VpnState.phase.value = Phase.CONNECTING
        job?.cancel()
        job = scope.launch {
            try {
                setupLibbox()
                runCatching { Refl.callStatic(Refl.cls("Libbox"), "checkConfig", config) }
                    .onFailure { if (it !is NoSuchMethodException) throw it }
                val service = Refl.callStatic(Refl.cls("Libbox"), "newService", config, createPlatform())
                    ?: throw IllegalStateException("libbox سرویس را نساخت")
                box = service
                Refl.call(service, "start")
                VpnState.startedAt = System.currentTimeMillis()
                VpnState.phase.value = Phase.ON
            } catch (e: Throwable) {
                Log.e(TAG, "start failed", e)
                shutdown(Refl.rootMessage(e))
            }
        }
    }

    /** error != null → حالت خطا با همان پیام؛ در غیر این صورت قطع عادی. */
    private fun shutdown(error: String?) {
        if (stopping) return
        stopping = true
        if (error != null) {
            VpnState.message.value = error
            VpnState.phase.value = Phase.ERROR
        }
        scope.launch {
            job?.cancel()
            runCatching { closeCore() }
            if (error == null) VpnState.phase.value = Phase.OFF
            main.post {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun closeCore() {
        runCatching { box?.let { Refl.call(it, "close") } }
        box = null
        stopMonitor()
        runCatching { tun?.close() }
        tun = null
    }

    private fun setupLibbox() {
        val c = Refl.cls("Libbox")
        val m = c.methods.first { it.name.equals("setup", true) }
        val types = m.parameterTypes
        val args: Array<Any?>
        if (types.size == 1) {
            val o = types[0].getDeclaredConstructor().newInstance()
            Refl.set(o, "BasePath", filesDir.path)
            Refl.set(o, "WorkingPath", (getExternalFilesDir(null) ?: filesDir).path)
            Refl.set(o, "TempPath", cacheDir.path)
            if (Build.VERSION.SDK_INT in 31..33) Refl.set(o, "FixAndroidStack", true)
            args = arrayOf(o)
        } else {
            val strings = listOf(filesDir.path, (getExternalFilesDir(null) ?: filesDir).path, cacheDir.path)
            val stringCount = types.count { it == String::class.java }
            val wanted = if (stringCount == 2) listOf(strings[0], strings[2]) else strings
            var si = 0
            args = Array(types.size) { i ->
                when (types[i]) {
                    String::class.java -> wanted.getOrElse(si++) { "" }
                    java.lang.Boolean.TYPE -> false
                    java.lang.Integer.TYPE -> 0
                    java.lang.Long.TYPE -> 0L
                    else -> null
                }
            }
        }
        try { m.invoke(null, *args) } catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException ?: e }
    }

    /* ---------------- notification ---------------- */

    private fun goForeground(name: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "PARSNET", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = android.app.Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("PARSNET")
            .setContentText(if (name.isBlank()) "VPN فعال است" else "متصل به $name")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(1, n)
        }
    }

    /* ---------------- libbox platform interface ---------------- */

    private fun createPlatform(): Any {
        val iface = Refl.cls("PlatformInterface")
        return Refl.proxy(iface) { m, a ->
            when (m.name) {
                "usePlatformAutoDetectInterfaceControl" -> true
                "autoDetectInterfaceControl" -> { protect(a[0] as Int); null }
                "openTun" -> openTun(a[0])
                "writeLog" -> { Log.i(TAG, a[0].toString()); null }
                "useProcFS" -> false
                "usePlatformDefaultInterfaceMonitor" -> true
                "startDefaultInterfaceMonitor" -> { startMonitor(a[0]); null }
                "closeDefaultInterfaceMonitor" -> { stopMonitor(); null }
                "usePlatformInterfaceGetter" -> true
                "getInterfaces" -> interfaces(m.returnType)
                "underNetworkExtension" -> false
                "includeAllNetworks" -> false
                "systemCertificates" -> Refl.stringIterator(m.returnType, emptyList())
                "clearDNSCache" -> null
                else -> Refl.defaultFor(m.returnType)
            }
        }
    }

    private fun openTun(o: Any?): Int {
        if (prepare(this) != null) throw IllegalStateException("android: missing vpn permission")
        val b = Builder().setSession("PARSNET")
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        (Refl.opt(o, "MTU") as? Int)?.let { if (it > 0) b.setMtu(it) }

        val v4 = Refl.items(Refl.opt(o, "Inet4Address"))
        val v6 = Refl.items(Refl.opt(o, "Inet6Address"))
        for (p in v4 + v6) b.addAddress(Refl.call(p, "address") as String, Refl.call(p, "prefix") as Int)

        if (Refl.opt(o, "AutoRoute") != false) {
            val dnsRaw = Refl.opt(o, "DNSServerAddress")
            val dns = when (dnsRaw) {
                is String -> dnsRaw
                null -> "172.19.0.2"
                else -> runCatching { Refl.call(dnsRaw, "getValue") as String }.getOrDefault("172.19.0.2")
            }
            b.addDnsServer(dns)

            val r4 = Refl.items(Refl.opt(o, "Inet4RouteAddress"))
            if (r4.isNotEmpty()) r4.forEach { b.addRoute(Refl.call(it, "address") as String, Refl.call(it, "prefix") as Int) }
            else if (v4.isNotEmpty()) b.addRoute("0.0.0.0", 0)
            val r6 = Refl.items(Refl.opt(o, "Inet6RouteAddress"))
            if (r6.isNotEmpty()) r6.forEach { b.addRoute(Refl.call(it, "address") as String, Refl.call(it, "prefix") as Int) }
            else if (v6.isNotEmpty()) b.addRoute("::", 0)

            if (Build.VERSION.SDK_INT >= 33) {
                for (name in listOf("Inet4RouteExcludeAddress", "Inet6RouteExcludeAddress")) {
                    for (p in Refl.items(Refl.opt(o, name))) {
                        b.excludeRoute(IpPrefix(InetAddress.getByName(Refl.call(p, "address") as String), Refl.call(p, "prefix") as Int))
                    }
                }
            }
            val inc = Refl.items(Refl.opt(o, "IncludePackage"))
            val exc = Refl.items(Refl.opt(o, "ExcludePackage"))
            if (inc.isNotEmpty()) inc.forEach { runCatching { b.addAllowedApplication(it.toString()) } }
            else exc.forEach { runCatching { b.addDisallowedApplication(it.toString()) } }
        }

        val pfd = b.establish() ?: throw IllegalStateException("android: دسترسی VPN داده نشده یا لغو شده است")
        tun = pfd
        return pfd.fd
    }

    private fun underlying(): Network? {
        val nets = cm.allNetworks.filter {
            val c = cm.getNetworkCapabilities(it)
            c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                !c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        }
        return nets.firstOrNull { cm.getNetworkCapabilities(it)!!.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) }
            ?: nets.firstOrNull { cm.getNetworkCapabilities(it)!!.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) }
            ?: nets.firstOrNull()
    }

    private fun startMonitor(listener: Any?) {
        monitorListener = listener
        val req = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = reportDefault()
            override fun onLost(network: Network) = reportDefault()
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = reportDefault()
        }
        netCallback = cb
        cm.registerNetworkCallback(req, cb)
        reportDefault()
    }

    private fun stopMonitor() {
        netCallback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        netCallback = null
        monitorListener = null
    }

    private fun reportDefault() {
        val l = monitorListener ?: return
        val net = underlying()
        val name = net?.let { cm.getLinkProperties(it)?.interfaceName }.orEmpty()
        val index = if (name.isEmpty()) -1 else runCatching { NetworkInterface.getByName(name).index }.getOrDefault(-1)
        runCatching {
            val m = l.javaClass.methods.first { it.name.equals("updateDefaultInterface", true) }
            m.isAccessible = true
            var strings = 0
            val args = m.parameterTypes.map { t ->
                when (t) {
                    String::class.java -> if (strings++ == 0) name else ""
                    java.lang.Integer.TYPE -> index
                    java.lang.Boolean.TYPE -> false
                    else -> null
                }
            }.toTypedArray()
            m.invoke(l, *args)
        }.onFailure { Log.w(TAG, "updateDefaultInterface: $it") }
    }

    private fun libboxInt(field: String): Int =
        runCatching { Refl.cls("Libbox").getField(field).getInt(null) }.getOrDefault(0)

    private fun interfaces(iteratorType: Class<*>): Any {
        val ifaceCls = Refl.cls("NetworkInterface")
        val javaIfaces = NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
        val out = ArrayList<Any>()
        for (net in cm.allNetworks) {
            val lp = cm.getLinkProperties(net) ?: continue
            val caps = cm.getNetworkCapabilities(net) ?: continue
            val name = lp.interfaceName ?: continue
            val ji = javaIfaces.firstOrNull { it.name == name } ?: continue
            val o = ifaceCls.getDeclaredConstructor().newInstance()
            Refl.set(o, "Name", name)
            Refl.set(o, "Index", ji.index)
            Refl.set(o, "MTU", runCatching { ji.mtu }.getOrDefault(1500))
            Refl.set(o, "Type", when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> libboxInt("InterfaceTypeWIFI")
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> libboxInt("InterfaceTypeCellular")
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> libboxInt("InterfaceTypeEthernet")
                else -> libboxInt("InterfaceTypeOther")
            })
            var flags = 0
            if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) flags = OsConstants.IFF_UP or OsConstants.IFF_RUNNING
            if (ji.isLoopback) flags = flags or OsConstants.IFF_LOOPBACK
            if (ji.isPointToPoint) flags = flags or OsConstants.IFF_POINTOPOINT
            if (ji.supportsMulticast()) flags = flags or OsConstants.IFF_MULTICAST
            Refl.set(o, "Flags", flags)
            Refl.set(o, "Metered", !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED))

            val addrs = ji.interfaceAddresses.map { it.address.hostAddress.orEmpty().substringBefore('%') + "/" + it.networkPrefixLength }
            val dnsList = lp.dnsServers.mapNotNull { it.hostAddress?.substringBefore('%') }
            ifaceCls.methods.firstOrNull { it.name.equals("setAddresses", true) }?.let {
                it.invoke(o, Refl.stringIterator(it.parameterTypes[0], addrs))
            }
            ifaceCls.methods.firstOrNull { it.name.equals("setDNSServer", true) }?.let {
                it.invoke(o, Refl.stringIterator(it.parameterTypes[0], dnsList))
            }
            out.add(o)
        }
        return Refl.listIterator(iteratorType, out)
    }
}
