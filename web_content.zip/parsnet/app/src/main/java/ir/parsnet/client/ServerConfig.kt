package ir.parsnet.client

enum class Protocol { VLESS, VMESS, TROJAN, SHADOWSOCKS }

data class ServerConfig(
    val id: String,
    val name: String,
    val link: String,
    val protocol: Protocol,
    val host: String,
    val port: Int
) {
    companion object {
        /** null اگر لینک نامعتبر یا پشتیبانی‌نشده باشد (در فهرست نمایش داده نمی‌شود). */
        fun parse(line: String): ServerConfig? {
            val link = line.trim()
            val p = LinkParser.parse(link) ?: return null
            return ServerConfig(Integer.toHexString(link.hashCode()), p.name, link, p.protocol, p.host, p.port)
        }
    }
}
