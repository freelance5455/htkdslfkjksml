package ir.parsnet.client

import android.content.Intent
import android.net.VpnService
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.json.JSONObject

/** Native Android host for the HTML UI. The WebView never creates a VPN itself;
 * it calls this bridge, which starts the real Android VpnService + libbox core.
 */
class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var pendingConfig: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val config = pendingConfig
        pendingConfig = null
        if (result.resultCode == RESULT_OK && config != null) startVpn(config)
        else notifyJs("error", "مجوز VPN تأیید نشد.")
    }

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = fileCallback
        fileCallback = null
        val uri = if (result.resultCode == RESULT_OK) result.data?.data else null
        callback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.addJavascriptInterface(NativeBridge(), "PARSNET_NATIVE")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return uri.scheme !in listOf("file", "about", "data")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                filePicker.launch(intent)
                return true
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/www/npv.html")
    }

    private inner class NativeBridge {
        @JavascriptInterface fun connect(link: String) {
            runOnUiThread { requestVpn(link) }
        }
        @JavascriptInterface fun disconnect() {
            runOnUiThread {
                startService(Intent(this@MainActivity, ParsnetVpnService::class.java).setAction(ParsnetVpnService.ACTION_STOP))
            }
        }
        @JavascriptInterface fun getState(): String = JSONObject()
            .put("phase", VpnState.phase.value.name.lowercase())
            .put("message", VpnState.message.value)
            .put("startedAt", VpnState.startedAt)
            .toString()
    }

    private fun requestVpn(link: String) {
        try {
            val parsed = LinkParser.parseOrThrow(link)
            val config = SingBoxConfig.build(link)
            val permission = VpnService.prepare(this)
            if (permission != null) {
                pendingConfig = config
                vpnPermission.launch(permission)
            } else startVpn(config, parsed.name)
            notifyJs("connecting", "در حال برقراری اتصال…")
        } catch (e: Throwable) {
            notifyJs("error", e.message ?: "کانفیگ قابل استفاده نیست.")
        }
    }

    private fun startVpn(config: String, name: String = "PARSNET") {
        val intent = Intent(this, ParsnetVpnService::class.java)
            .setAction(ParsnetVpnService.ACTION_START)
            .putExtra(ParsnetVpnService.EXTRA_CONFIG, config)
            .putExtra(ParsnetVpnService.EXTRA_NAME, name)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(this, intent)
        else startService(intent)
    }

    private fun notifyJs(phase: String, message: String) {
        if (!::web.isInitialized) return
        val safe = JSONObject.quote(message)
        runOnUiThread {
            if (!isFinishing) web.evaluateJavascript("window.onParsnetVpnState && window.onParsnetVpnState('$phase',$safe);", null)
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            fileCallback?.onReceiveValue(null)
            fileCallback = null
            web.removeJavascriptInterface("PARSNET_NATIVE")
            web.destroy()
        }
        super.onDestroy()
    }
}
